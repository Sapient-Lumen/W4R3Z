# Abuse cases (pressure tests)

Format: attacker → preconditions → steps → expected prevention → required invariants → evidence.

## AC-001: capability forgery / confused deputy
- attacker: ADV-GUEST
- goal: obtain authority without a valid capability chain
- required invariants: I-CAP-1, I-OBJ-1
- supports claim: C-CAP-1
- evidence targets: EVID-2026-002 (bounded model check), later E3 proof

## AC-002: DMA overwrite of privileged memory
- attacker: ADV-GUEST with device access, or ADV-PHYS
- goal: corrupt page tables / dispatch / object tables
- required invariants: I-DMA-1
- supports claim: C-ISO-2 (conditional on A-DMA-1)
- evidence targets: platform enforcement demo + configuration proof obligations

## AC-003: rollback update to vulnerable build
- attacker: ADV-SUPPLY
- goal: install older known-vulnerable artifact
- required invariants: I-BOOT-2
- supports claim: C-BOOT-1
- evidence targets: update metadata tests; provenance checks

## AC-067: repository freeze / stale-metadata attack (D-TUF)
- attacker: ADV-SUPPLY or ADV-NET (mirror/operator-path control)
- goal: keep clients on a vulnerable build by serving *old but correctly signed* repository metadata (freeze) or withholding fresh timestamp/snapshot updates
- required invariants: I-TUF-1, I-TIME-1
- supports claim: C-BOOT-1 (conditional on D-TUF)
- evidence targets: expiry/staleness negative tests; rotation drill harness (EVID-2026-077)



## AC-059: boot-success marking bypass commits a bad deployment
- attacker: ADV-GUEST (compromised early-boot service) or ADV-SUPPLY (malicious update)
- goal: mark a pending deployment as “successful” without satisfying the profile’s health predicate, defeating automatic rollback
- required invariants: I-ATOMICUPD-3, I-HEALTH-1, I-HEALTH-2, I-LOG-1
- supports claim: C-BOOT-1
- evidence targets: negative tests for wrong/mismatched success marks; transcript binding tests; state-machine tests for bounded tries and fallback


## AC-004: concurrency race violates isolation/authority
- attacker: ADV-GUEST (timing) + weak concurrency controls
- goal: exploit interleavings for privilege escalation or DoS
- required invariants: I-CONC-1
- supports claim: C-CONC-1 (required for flagship builds; UP-only bring-up is explicitly non-claim)


## AC-005: prompt injection causes privileged effect
- attacker: ADV-SERVICE or ADV-GUEST (via context influence)
- goal: model output triggers a privileged action without explicit authorization
- required invariants: I-LLM-1, I-ENC-1
- supports claim: C-LLM-1
- evidence targets: adversarial prompt corpus + validator tests; bounded model check of validator semantics


## AC-006: tool output spoofing launders authority
- attacker: ADV-SERVICE (compromised tool/plugin) + prompt influence
- goal: crafted tool output steers proposals and attempts to affect authorization decisions, causing a privileged effect not explicitly authorized
- required invariants: I-LLM-1, I-AUTHZ-1, I-OBS-2, I-SBX-1
- supports claim: C-LLM-1
- evidence targets: malicious tool corpus; validator acceptance independent of tool output fields (PO-OBS-NOTAUTH); validator rejects absent/bad binding; sandbox confinement tests


## AC-007: observation export exfiltrates secrets
- attacker: ADV-SERVICE or ADV-GUEST (coercion) + operator workflow mistakes
- goal: secrets leave via telemetry/log/export
- required invariants: I-OBS-1, I-LOG-1
- supports claim: C-OBS-1
- evidence targets: redaction tests + replayable transcript checks; negative tests for secret-bearing fields

## AC-008: namespace/view confusion yields unintended authority
- attacker: ADV-GUEST or ADV-SERVICE
- goal: trick privileged code into resolving a name via an unintended ambient/default namespace to obtain a more powerful capability
- required invariants: I-VIEW-1, I-VIEW-2
- supports claim: C-CAP-1 (and C-OBS-1 if observation scoping uses views)
- evidence targets: E1 tests for "no ambient fallback"; E2 model check of small view graphs

## AC-009: boot-manifest substitution / binding mismatch
- attacker: ADV-SUPPLY
- goal: supply a validly signed config or manifest but mismatch them (policy says A, boot applies B)
- required invariants: I-BOOT-1, I-ENC-1
- supports claim: C-BOOT-1
- evidence targets: negative tests for digest-binding (PO-BOOT-BIND); later provenance attestation checks

## AC-010: privileged service forgets to seal after initialization
- attacker: ADV-SERVICE or ADV-GUEST (via crafted inputs to the service)
- goal: exploit a bug in a long-running service that retained broad init authority (files/network/devices) to escalate impact
- required invariants: I-SEAL-1, I-CAP-1, I-VIEW-2
- supports claim: C-CAP-1 (and any microVM/profile claims that assume minimized service authority)
- evidence targets: E1 negative tests for “cannot regain dropped rights”; service hardening checklist

## AC-011: replay divergence undermines evidence and incident response
- attacker: ADV-SERVICE (non-determinism injection) or ADV-GUEST (timing inputs)
- goal: cause the system to produce a transcript that cannot be replayed to reproduce a privileged effect, masking root cause
- required invariants: I-LOG-1, I-ENC-1, I-RR-1
- supports claim: C-OBS-1 (replayable transcript), C-STATE-1 (well-formed state evolution)
- evidence targets: E2 replay harness on CH-KABI/CH-LOG streams; fuzz nondeterminism boundaries

## AC-012: delegation token confusion (caveat stripping / binding swap)
- attacker: ADV-SERVICE
- goal: turn a delegated/attenuated token into broader authority (remove constraints, swap binding to a more powerful local object)
- required invariants: I-CAPX-1, I-CAPX-2, I-ENC-1
- supports direction: D-CAPX (and any future <C-CAPX-*>)
- evidence targets: E1 negative tests for binding mismatches; E2 bounded checks of attenuation monotonicity for the chosen token form

## AC-013: Wasm host boundary grants ambient authority
- attacker: ADV-SERVICE (untrusted plugin/module)
- goal: obtain filesystem/network/time authority from the runtime/host without explicit handles/caps
- required invariants: I-WASM-1, I-VIEW-1, I-SEAL-1 (if the host seals after init)
- supports direction: D-WASM
- evidence targets: E1 conformance tests for host-import allowlists; fuzz host boundary with “ambient access” probes

## AC-014: membrane revocation bypass (raw capability leak)
- attacker: ADV-SERVICE or ADV-GUEST
- goal: retain or regain authority after revocation by obtaining an unwrapped/raw capability that bypasses the boundary wrappers
- required invariants: I-MEMBRANE-1, I-MEMBRANE-2, I-CAP-1
- supports direction: D-MEMBRANE (and any future <C-REVOC-*> claim)
- evidence targets: E1 tests that exported handles are wrapped; negative tests that revocation disables all wrapped uses; bounded model check on a tiny wrapper+revocation automaton

## AC-015: auth agent coerced to leak or misuse keys
- attacker: ADV-SERVICE (compromised client) or ADV-GUEST
- goal: extract raw key material or induce signing beyond delegated authority (e.g., replay/malleability misuse)
- required invariants: I-AUTHAGENT-1, I-CRYPTO-2, I-LOG-1, I-ENC-1
- supports direction: D-AUTHAGENT
- evidence targets: API conformance tests (“no key export”); CH-KEYPOL negative tests; transcript/audit checks using CH-CRYPTOAUDIT; protocol misuse tests (nonce binding; replay resistance where claimed)

## AC-016: protocol confusion / desynchronization
- attacker: ADV-SERVICE or ADV-GUEST
- goal: exploit protocol ambiguity (unexpected message order/kind) to trigger unintended state transitions or authority use
- required invariants: I-CONTRACT-1, I-ENC-1, I-STATE-1
- supports direction: D-CONTRACT
- evidence targets: generated-wrapper negative tests; bounded model checks of selected contract FSMs; fuzzing of message reordering/duplication within the declared transport model

## AC-017: event-bus injection / ambient broadcast
- attacker: ADV-SERVICE or ADV-GUEST
- goal: inject or observe control/ops events without holding the relevant event authority
- required invariants: I-EVENT-1, I-EVENT-2, I-ENC-1
- supports direction: D-EVENTBUS (and indirectly C-LLM-1/C-OBS-1 if events feed ACP/observations)
- evidence targets: E1 negative tests (no wildcard subscribe); E2 bounded model check of route/rights graph

## AC-018: temporal-capability misuse (budget forgery / DoS)
- attacker: ADV-GUEST
- goal: exceed granted CPU budget or mint stronger scheduling rights than delegated
- required invariants: I-TCAP-1, I-CAP-1
- supports direction: D-TCAP (and D-METER if budgets are charged)
- evidence targets: E1 scheduler budget tests; E2 model check of mint/attenuate/charge rules

## AC-019: driver-domain escape via I/O resource confusion
- attacker: ADV-SERVICE (compromised driver) or ADV-GUEST with device access
- goal: access MMIO/IRQ/DMA outside the assigned resource set to corrupt/exfiltrate
- required invariants: I-IORES-1, I-DMA-1
- supports direction: D-DRVDOM; supports claim: C-ISO-2 (conditional on A-DMA-1)
- evidence targets: E1 pass-through demo with negative tests for out-of-window accesses; configuration validation tests

## AC-020: meter bypass / quota forgery
- attacker: ADV-GUEST or ADV-SERVICE
- goal: allocate/retain resources without a corresponding meter charge, or trick a privileged service into charging a higher meter than intended
- required invariants: I-METER-1, I-CAP-1, I-STATE-1
- supports direction: D-METER (and any future <C-DOS-*> claim)
- evidence targets: E1 negative tests for “no meter => no resource”; E2 bounded model check of split/charge rules

## AC-021: sturdyref restore confusion
- attacker: ADV-SERVICE
- goal: use a public bootstrap interface to obtain authority, guess/brute-force sturdyref bearer material, or cause restore() to return more authority than intended
- required invariants: I-SREF-1, I-SREF-2, I-CAPX-1, I-ENC-1
- supports direction: D-CAPX adjunct (CH-SREF)
- evidence targets: E1 restore API tests (bootstrap gives no power; invalid refs fail); E2 bounded model check of restore/attenuation automaton

## AC-022: restart storm / reincarnation abuse
- attacker: ADV-SERVICE or ADV-GUEST
- goal: induce repeated crashes/restarts of a component (especially a driver domain) to consume CPU/memory/log bandwidth, wedge recovery logic, or mask a persistent fault
- required invariants: I-METER-1 (if restart budgets are charged), I-STATE-1, I-LOG-1
- supports direction: RFC-0017 (supervision policy); D-METER/D-TCAP (budgeted recovery)
- evidence targets: E1 restart state-machine tests (rate limits/backoff); E2 bounded model check of a tiny supervisor automaton with an adversarial “crash injector”

## AC-023: epoch wrap / object-ID reuse resurrects authority
- attacker: ADV-GUEST or ADV-SERVICE
- goal: make a revoked capability become valid again by exploiting generation-counter wrap or object-ID reuse
- required invariants: I-REVOKE-2, I-STATE-1
- supports direction: RFC-0019 (revocation epochs)
- evidence targets: E1 property tests for no-resurrection; E2 bounded model check of a simplified cap-table + generation model

## AC-024: partition policy overlap creates hidden sharing
- attacker: ADV-SUPPLY or ADV-OPS (misconfiguration)
- goal: induce unintended cross-partition memory/device overlap (silent isolation break)
- required invariants: I-PART-1, I-ENC-1, I-BOOT-1
- supports direction: D-PART (CH-PART)
- evidence targets: E1 validator negative tests (overlaps/aliasing); E2 bounded model check of overlap constraints

## AC-025: device/IRQ assignment confusion crosses partition boundary
- attacker: ADV-SUPPLY or ADV-OPS
- goal: assign the same MMIO/IRQ endpoint to multiple partitions without explicit sharing semantics, enabling interference or data exposure
- required invariants: I-PART-1, I-IORES-1 (if D-DRVDOM), I-STATE-1
- supports direction: D-PART; D-DRVDOM
- evidence targets: E1 validation tests for disjoint MMIO/IRQ sets; E1 integration test with a deliberately misassigned device

## AC-026: DMA window bypass under static partitioning
- attacker: ADV-GUEST (malicious driver/OS in a partition)
- goal: use DMA-capable device to read/write outside the partition’s assigned memory
- required invariants: I-DMA-1, I-PART-1
- supports direction: D-PART; D-DMA; supports claim: C-ISO-2 (conditional)
- evidence targets: E1 negative tests for out-of-window DMA; E2 bounded check of IOMMU window constraints

## AC-027: address decoding net omits a translation path
- attacker: ADV-SUPPLY or ADV-OPS
- goal: omit or misrepresent a translation edge so generated tables do not match actual hardware translation, producing unintended reachability
- required invariants: I-ADDRNET-1, I-PTGEN-1, I-BOOT-1
- supports direction: D-ADDRNET (CH-ADDRNET)
- evidence targets: E1 validator negative tests; E2 bounded reachability comparison (net vs tables)

## AC-028: page-table generator drift / mismatch
- attacker: ADV-SUPPLY
- goal: replace or subtly alter the generator so tables installed at boot no longer correspond to the pinned CH-ADDRNET
- required invariants: I-PTGEN-1, I-PROV-CHAIN-1, I-BOOT-1
- supports direction: D-ADDRNET; D-PCP/D-BOOT
- evidence targets: E1 “mismatched digest” tests; bind generator/tool digest in CH-BOOT artifacts when used

## AC-029: local-name confusion amplifies authority
- attacker: ADV-SERVICE
- goal: exploit ambiguous name normalization or shadowing to resolve a name to stronger authority than intended
- required invariants: I-NAME-1, I-NAME-2, I-ENC-1
- supports direction: D-NAMECERT
- evidence targets: E1 canonicalization tests (confusables/normalization); bounded model check of name graph resolution

## AC-030: certificate chain substitution / delegation bypass
- attacker: ADV-SERVICE or ADV-NET
- goal: swap in a different chain/bundle (or omit constraints) so a verifier accepts stronger delegation than intended
- required invariants: I-NAME-2, I-CAPX-2 (if D-CAPX), I-LOG-1
- supports direction: D-NAMECERT; D-CAPX
- evidence targets: E1 negative tests for chain substitution; transcript-log the bundle digest for decisions that affect authority

## AC-031: authority laundering via sequences of valid ACP actions
- attacker: ADV-SERVICE (prompt influence) or ADV-GUEST (via inputs/telemetry shaping)
- goal: reach a privileged end state by composing individually-validated ACP actions that each look harmless in isolation
- required invariants: I-LLM-2 (if sequence claims are enabled), I-LOG-1
- supports claim: C-LLM-1 (only if I-LLM-2 profile is claimed)
- evidence targets: E2 bounded model check of the validator+ledger for the declared bounds; negative tests that “exceed bound → reject + log”

## AC-032: adversarial observations steer ACP proposals toward unsafe behavior
- attacker: ADV-SERVICE (compromised tool) or ADV-GUEST (controls observable inputs)
- goal: manipulate IF-OBS/tool outputs to steer proposal generation and induce acceptance via confused-decision logic
- required invariants: I-OBS-2, I-AUTHZ-1, I-SBX-1
- supports claim: C-LLM-1
- evidence targets: E1 malicious observation/tool corpus; validator acceptance is independent of untrusted observation fields (PO-OBS-NOTAUTH)

## AC-033: attestation replay / stale boot claim
- attacker: ADV-NET or ADV-OPS
- goal: present an old/other-boot attestation as evidence of current compliant state to an update gate / remote policy engine
- required invariants: I-ATTEST-1 (if D-ATTEST), I-BOOT-1, I-TIME-1 (if freshness is claimed)
- supports direction: D-ATTEST; D-BOOT
- evidence targets: E1 negative tests (wrong nonce, wrong boot_digest, wrong key); if freshness enabled, replay must fail closed (PO-ATTEST-FRESH)

## AC-034: RPC endpoint confusion reintroduces ambient authority
- attacker: ADV-SERVICE
- goal: cause an RPC runtime to invoke an effectful endpoint without holding an explicit object reference (e.g., via name-based resolution or default/global endpoints)
- required invariants: I-CAPRPC-1 (if D-CAPRPC), I-VIEW-1 (if names/views exist)
- supports direction: D-CAPRPC; D-CAPX
- evidence targets: E2 bounded model check on a small RPC graph showing all effectful calls require a held handle; E1 negative tests for “missing handle → reject” (PO-CAPRPC-NOAMBIENT)

## AC-035: artifact reference substitution / digest mismatch
- attacker: ADV-SUPPLY or ADV-OPS
- goal: cause verifiers/operators to accept or fetch the wrong artifact by substituting a locator or confusing metadata, potentially bypassing evidence requirements
- required invariants: I-AREF-1, I-ENC-1, I-LOG-1 (if logged)
- supports direction: D-AREF (CH-AREF)
- evidence targets: E1 negative tests for “locator changes ignored” + “digest mismatch → reject”; policy tests for allowlisted locator schemes (PO-AREF-VERIFY)

## AC-036: consent mediator confused deputy (powerbox)
- attacker: ADV-SERVICE
- goal: trick a human/operator consent flow into approving an unintended privileged action by presenting a misleading summary or by reusing an approval for a different action
- required invariants: I-CONSENT-1, I-AUTHZ-1, I-ENC-1
- supports direction: D-POWERBOX (IF-CONSENT) and ACP guardrails
- evidence targets: E1 golden tests that approval tokens bind to action digests; UX harness tests that displayed summaries are derived from canonical bytes (not raw untrusted text)

## AC-037: disposable domain leaks persistence or bypasses export mediation
- attacker: ADV-GUEST (code running inside disposable) or ADV-SERVICE
- goal: persist state across disposal (write into persistent store) or exfiltrate data/capabilities without an explicit portal/export grant
- required invariants: I-EPHEM-1, I-EPHEM-2, I-PLUMB-1, I-VIEW-1
- supports direction: D-EPHEM, D-PLUMB
- evidence targets: E1 teardown tests (no residual overlay); E1 negative tests for implicit export channels (clipboard/drag-drop/path tricks); cap-graph diff gates for `Export*` intents (PO-EPHEM-EXPORT)

## AC-038: rollback-to-vulnerable deployment (anti-rollback bypass)
- attacker: ADV-SUPPLY or ADV-OPS
- goal: cause the system to activate an older, vulnerable deployment while presenting it as compliant (or bypassing a required rollback floor)
- required invariants: I-BOOT-2 (if claimed), I-ATOMICUPD-1, I-ATOMICUPD-2
- supports direction: D-ATOMICUPD, D-BOOT
- evidence targets: E1 negative tests for rollback floor violations; E1 tests that activation is atomic and logged with CH-UPD digest; replay/selection tests for deterministic rollback rules (PO-ATOMICUPD-ROLLBACK)

## AC-039: functional build store poisoning / impurity
- attacker: ADV-SUPPLY (or ADV-SERVICE controlling a builder/cache)
- goal: cause the system to execute/store bytes that do not correspond to the declared derivation inputs (or to smuggle in undeclared “impure” inputs)
- required invariants: I-FPM-1, I-FPM-2, I-FPM-3, I-AREF-1
- supports claim: C-PROV-2 (supply-chain posture, conditional)
- evidence targets: EVID-2026-040 (hermetic build harness), EVID-2026-045 (negative tests)

## AC-040: quarantine laundering via containers / extraction
- attacker: ADV-SERVICE or ADV-GUEST
- goal: cause quarantined content to be treated as trusted (strip/quench quarantine tags, bypass safe-open routing)
- required invariants: I-QUAR-1, I-QUAR-2, I-QUAR-3, I-QUAR-4, I-PLUMB-1
- supports claim: C-LLM-1 (workflow safety, conditional) and any “safe-open default” claim if made
- evidence targets: EVID-2026-043, EVID-2026-044

## AC-041: Wasm extension escapes sandbox boundary
- attacker: ADV-GUEST (malicious extension/component)
- goal: achieve privileged effects or escape confinement via import confusion, handle forgery, or runtime/JIT vulnerability
- required invariants: I-WASM-1, I-WASM-4, I-WASM-2, I-WASM-3, I-SBX-1
- supports claim: C-ISO-1 (conditional on SBX profile) and any D-WASM safety claim if made
- evidence targets: EVID-2026-042

## AC-042: consent summary mismatch / authority-diff spoofing
- attacker: ADV-SERVICE
- goal: obtain approval for an action that grants *more* authority than the user was shown (summary/diff mismatch), or produce a misleading receipt that understates what executed
- required invariants: I-EXPLAIN-1, I-EXPLAIN-2, I-CONSENT-1, I-AUTHZ-1 (and I-VOLITION-1 if enabled)
- supports direction: D-EXPLAIN, D-POWERBOX, D-VOLITION, D-PLUMB
- evidence targets: E1 golden tests that UI summaries/diffs are derived from canonical action bytes; E1 tests that receipts bind action+summary+result digests; negative tests for race/TOCTOU between preview and execution

## AC-043: phishing/spam via notifications (origin spoofing)
- attacker: ADV-SERVICE (trojan app/extension)
- goal: trick the user via notifications that impersonate another origin (bank/system) or overwhelm them with spam to induce blind clicking
- required invariants: I-ATTN-1, I-ATTN-3 (and I-EXPLAIN-1 if notification actions can grant authority)
- supports direction: D-ATTN, D-EXPLAIN
- evidence targets: EVID-2026-049 (branding tests), EVID-2026-050 (budget/coalescing tests)

## AC-044: notification action clickjacking / volition bypass
- attacker: ADV-SERVICE
- goal: cause a notification click/button press to execute a privileged or authority-granting action without a trusted UI gesture (volition) or without showing the true authority delta
- required invariants: I-ATTN-2, I-VOLITION-1 (if enabled), I-EXPLAIN-1/I-EXPLAIN-2 (if enabled), I-AUTHZ-1
- supports direction: D-ATTN, D-VOLITION, D-EXPLAIN, D-PLUMB
- evidence targets: EVID-2026-051 (action binding tests), negative tests for post-render intent swapping, and TOCTOU between preview and execution

## AC-068: UI spoofing, input snooping, and screen scrape (desktop boundary)
- attacker: ADV-GUEST (untrusted app), or ADV-SERVICE (compromised component)
- goal: steal secrets or approvals by:
  - globally keylogging or observing input meant for another surface,
  - scraping pixels from other apps’ windows (screenshot without consent),
  - presenting a fake login/consent UI that is indistinguishable from the real one,
  - stealing focus or injecting input outside explicit automation/accessibility rights.
- required invariants:
  - I-UICAP-1 (no ambient readback / surface isolation)
  - I-UICAP-2 (focus-gated input; no global intercept/inject)
  - I-VOLITION-1 + I-CONSENT-1 for any approval-granting actions
  - I-SAS-1 if SAS is enabled for secure-mode entry
- supports direction: D-UICAP, D-VOLITION, D-POWERBOX, D-PLUMB, D-LEASE
- evidence targets:
  - EVID-2026-078: compositor harness negative tests (no input to unfocused clients; no cross-surface pixels)
  - portal capture lease tests: screenshot/screencast/remote-control require an explicit portal-issued lease + (optionally) volition binding

## AC-045 — Record/replay artifact exfiltration (privacy leak)
**Setup:** D-RR enabled; replay artifacts (CH-RR and/or CH-RRBUNDLE payloads) exist on disk or in a ring buffer.  
**Attack:** untrusted code reads or tricks the user into exporting replay artifacts that include secrets/user content; attacker gains sensitive data.  
**Impact:** privacy compromise; credential/session leakage; incident evidence exposure.  
**Mitigations:** I-RR-3; PO-RR-ACCESS; default minimal profiles (kabi-only); bundle encryption; D-EXPLAIN receipts for export showing payload kinds + size.

## AC-046: promise-mask bypass / self-restriction confusion
- attacker: ADV-SERVICE (compromised component) or ADV-GUEST (malicious extension)
- goal: cause a domain that has installed a CH-PLEDGE promise mask to still perform a forbidden privileged effect, via:
  - validator bugs (accepting unknown tokens / non-canonical encodings),
  - mapping drift (promise token → effect allowlist mismatch),
  - inheritance mistakes (child starts broader than parent), or
  - unguarded dispatch fast paths.
- required invariants: I-PLEDGE-1, I-PLEDGE-2, I-PLEDGE-3, I-ENC-1, I-IF-1
- supports direction: D-SEAL
- evidence targets: PO-PLEDGE-VALIDATE/PO-PLEDGE-ENFORCE/PO-PLEDGE-INHERIT; E1 negative tests for forbidden effect attempts; fuzz corpus for CH-PLEDGE decoding; regression tests that promised tokens map to exactly the intended closed effect set

## AC-047: network lease bypass / over-broad outbound grants
- attacker: ADV-SERVICE (malicious app/component) or ADV-GUEST (extension)
- goal: obtain outbound connectivity beyond what policy/user intended, via:
  - requesting a deceptively broad lease (wildcard/suffix tricks),
  - DNS rebinding / name→IP drift to reach disallowed endpoints,
  - using an out-of-band resolver/transport path, or
  - reusing a stale lease beyond its TTL.
- required invariants: I-NETLEASE-1, I-NETLEASE-2, I-NETLEASE-3 (if enabled), I-ENC-1
- supports direction: D-NETLEASE (portal.net), D-EXPLAIN, D-PLUMB, D-ATTN
- evidence targets: PO-NETLEASE-VALIDATE/PO-NETLEASE-ENFORCE/PO-NETLEASE-DNSBIND; negative tests for DNS rebinding/local-network access; regression tests that disposables start with no network lease in D-QUAR profiles

## AC-048: confused-deputy billing / sponsorship DoS
- attacker: ADV-SERVICE (malicious client) or ADV-GUEST (extension)
- goal: induce a privileged service to spend its own meter unexpectedly (resource exhaustion) or to charge a victim’s meter without an explicit payer handoff, by crafting requests that trigger allocations/expensive work
- required invariants: I-METER-1, I-METER-3, I-CAP-1, I-LOG-1
- supports direction: D-METER, D-TCAP (optional), and any “bounded DoS” claim if made
- evidence targets: EVID-2026-060 (payer-required negative tests), EVID-2026-061 (sponsorship API tests)
## AC-049: budget laundering / sponsorship by stealth
- attacker: ADV-SERVICE (malicious client) or ADV-GUEST (extension)
- goal: induce a mediator/service to (a) spend its own budget implicitly, or (b) pass along a powerful budget lease to an unintended recipient, enabling unbounded work or misattributed billing
- steps:
  - craft a request that triggers expensive work in a helper service that has ambient access to a meter,
  - rely on an API that doesn’t require an explicit budget parameter, or
  - trick a portal/mediator into returning a reusable long-lived budget lease and then exfiltrate it.
- required invariants: I-BUDGET-1, I-BUDGET-2, I-METER-3, I-LOG-1
- supports direction: D-BUDGET, D-METER
- evidence targets: EVID-2026-063 (budget-required negative tests; attenuation properties; receipt/log binding)

## AC-050: pressure oracle / cross-domain inference
- attacker: ADV-SERVICE or ADV-GUEST
- goal: infer other domains’ activity by observing high-resolution or global resource pressure signals (e.g., memory pressure spikes reveal a victim’s workload)
- steps:
  - obtain a pressure monitor with overly broad scope, or
  - exploit overly fine-grained/too-frequent event delivery as a timing oracle.
- required invariants: I-PRESSURE-1, I-PRESSURE-2, I-PRESSURE-3, I-OBS-1
- supports direction: D-PRESSURE
- evidence targets: EVID-2026-064 (scope gating tests; rate-limit/coarsening tests; “no global monitor unless granted”)

## AC-051: memory corruption → capability theft inside a risky compartment
- attacker: ADV-SERVICE (malicious component) or ADV-GUEST (extension) exploiting a memory-safety bug in a privileged-enough user-space compartment (driver domain, parser, gateway)
- goal: steal capabilities from memory, corrupt in-domain control flow, and use the stolen authority to produce effects outside the intended blast radius
- steps:
  - trigger UAF/overflow to read/write capability-bearing structures,
  - pivot control flow to capability-bearing call sites (or forge request payloads),
  - exfiltrate or misuse stolen authority before the compartment is restarted.
- required invariants (if enabled): I-MEMTAG-1, I-HARDEN-1, I-WX-1/I-EXECMOD-1, I-CAP-1, I-COMP-1
- supports direction: D-MEMTAG (CH-HARDEN), D-DYNCODE, D-DRVDOM, D-SUPV
- evidence targets: PO-MEMTAG-ENF, PO-HARDEN-BIND, PO-WX-ENF/PO-EXECMOD-ENF; exploit-regression corpus showing tag-fault detection or earlier kill in hardened profiles

## AC-052: nondeterminism confusion / bypass (fine clock + deterministic entropy)
- attacker: ADV-SERVICE (malicious component) or ADV-GUEST (extension)
- goal:
  - obtain high-resolution timing without explicit grant (fingerprinting / oracle hygiene bypass), or
  - induce security-sensitive code to use deterministic/low-quality entropy (predictable tokens/keys).
- steps:
  - exploit an ambient API path to clock/entropy despite D-NONDET, or
  - trick a portal/host into issuing a `monotonic_fine` clock when only coarse timing was intended, or
  - pass a deterministic entropy handle into a component that assumes cryptographic randomness.
- required invariants: I-NONDET-1, I-NONDET-2, I-NONDET-3, I-ENC-1 (and I-WASM-1 if in D-WASM profiles)
- supports direction: D-NONDET, D-WASM, D-RR
- evidence targets: PO-NONDET-NOAMBIENT, PO-CLOCK-VALIDATE, PO-ENTROPY-VALIDATE; negative tests ensuring deterministic entropy cannot satisfy “crypto RNG required” preconditions; cap-graph leak tests ensuring fine-clock handles do not appear by default

## AC-053: CC attestation replay / “verified the wrong thing” secret release
- attacker: ADV-NET (remote attacker) or ADV-OPS (malicious operator) depending on deployment
- setup: D-CC and/or D-ATTEST used to gate secret release (keys/decryption material) from a remote system
- goal: obtain a secret by presenting attestation evidence that is (a) stale/replayed, or (b) valid but for a *different* boot/config than the one the relying party intended to trust
- steps:
  - replay an old quote/report when freshness is not enforced, or exploit nonce confusion (wrong session/tenant), or
  - present evidence for a different OS build/config (measurement digest mismatch) when the verifier does not bind the evidence to our CH-BOOT digest
- impact: remote secret release to an untrusted state; enables offline decryption or privileged access
- required invariants: I-ATTEST-1, I-ENC-1; plus A-CC-1 when “enforced isolation” is claimed
- supports direction: D-CC, D-ATTEST, D-AREF
- mitigations:
  - RFC-0064: require technology-native REPORTDATA/user-data binding to `H(boot_digest || nonce)` and verify it
  - enforce nonce freshness (PO-ATTEST-FRESH) and reject mismatched boot/prov digests
  - prefer digest-addressed evidence containers (CH-AREF) to avoid “best effort parsing” of untrusted blobs
- evidence targets: binder negative tests (replay, substituted CH-BOOT, substituted evidence); verifier harness tests that fail closed on any mismatch
## AC-054: persistent rollback/resurrection (D-PERSIST)
- attacker: ADV-OPS (or ADV-PHYS with storage access)
- goal: restore an older durable root to re-enable revoked authority, reintroduce vulnerable state, or bypass “last seen” policy
- preconditions: D-PERSIST enabled; attacker can substitute/restore older CH-CAPSTORE commits or replay storage snapshots
- steps:
  - present an older commit/root set (or a storage snapshot) as the “current” durable state
  - system resumes, inadvertently resurrecting stale sturdyrefs/caps or vulnerable configuration
- impact: authority resurrection, policy rollback, secrets released under stale assumptions
- required invariants: I-PERSIST-2, I-PERSIST-3, I-TIME-1
- supports direction: D-PERSIST, D-UPD-SIGN, D-PCP, D-TLOG
- mitigations:
  - enforce epoch monotonicity for durable roots; fail closed on epoch decrease unless explicit rollback_allowed=true (dev/test only)
  - bind last-seen epoch into CH-BOOT/CH-PROV (and into D-CC attestation binding when used) so audited boots can detect rollback
  - gate secret release (key custody) on non-rollback mode; treat rollback as adversarial state
- evidence targets: negative tests that replay older commits/snapshots and verify fail-closed behavior; end-to-end “rollback allowed” profile tests that demonstrate explicit downgrade and explicit secret-release refusal

## AC-055: lease confusion / bypass (D-LEASE)
**Story:** A portal/gateway intends to delegate a *leased* capability (“valid for 10 minutes” or “1 use”), but accidentally leaks the **raw underlying capability** (or renews/extends leases implicitly). The recipient retains unbounded authority, defeating least-authority sharing and enabling persistence/leak escalation.

**Vectors:**
- boundary wrapper forgets to wrap one method/path; raw cap escapes via a side-channel or debug API
- renewal occurs implicitly (auto-refresh) without explicit renewal authority, turning “temporary share” into “permanent share”
- time-based leases consult ambient time despite D-NONDET posture, creating un-audited backdoors or nondeterminism that breaks replay

**Impact:**
- unbounded authority retention across trust boundaries
- hard-to-audit “grant creep” (diffs/receipts misrepresent the true delegated power)
- persistence + rollback interactions if leaked caps are made durable (D-PERSIST)

**Mitigations:**
- enforce I-MEMBRANE-2 (no unwrapped leakage) with cap-graph leak tests (D-CAPAUD)
- require explicit renewal caps for extending TTL/uses (I-LEASE-2)
- fail-closed expiry checks using explicit Clock handles (I-LEASE-1; D-NONDET)
- include `digest(CH-CAPLEASE)` in receipts/logs so audits can validate intended bounds (D-EXPLAIN)

## AC-056: trace processor exfil / covert channel (D-TRACEPROC)
**Story:** Operators enable trace processing to get safe aggregated diagnostics, but an untrusted processor (or a compromised trace portal) encodes secrets into “allowed” outputs (e.g., counters keyed by attacker-chosen strings) or uses output rates as a covert channel. Raw trace export is avoided, yet leakage still occurs through aggregates.

**Vectors:**
- processor emits attacker-controlled high-entropy labels/keys (e.g., digest fragments) that reconstruct secrets out-of-band
- processor exploits “top-N” lists to smuggle bits by ordering/selection
- rate/timing modulation in outputs if the export path exposes fine-grained timing or unbounded throughput
- portal fails to clamp probe sets and allows processors to subscribe to events that include secret-derived tags

**Impact:**
- secret leakage through “safe” observability channels
- widened side-channel surface beyond the intended D-SIDECH posture
- misleading audits (operators believe only aggregates left the box)

**Mitigations:**
- strict bounds + allowlists on output keys/types (PO-TRACEPROC-BOUNDS; I-OBS-1)
- prefer digest/counter outputs with fixed tag vocabularies; forbid free-form strings by default
- clamp probe sets to a profile-defined allowlist; deny secret-bearing probes unless explicitly authorized
- run processors under explicit budgets and deterministic overflow/drop behavior (no timing oracle via backpressure)

**Evidence targets:**
- negative tests that attempt high-entropy label injection and verify rejection/clamping
- covert-channel red-team harness over output ordering/selection within bounds
- policy regression tests ensuring “secret-bearing probes” cannot be subscribed to in default profiles

## AC-066: trace predicate abuse / filter-DoS (D-TPRED)
**Story:** A caller supplies a trace filter predicate that is (a) too large/complex, (b) exploits a validator bug, or (c) uses high-rate probes with ineffective filtering to cause buffer pressure/CPU spikes. In the worst case, malformed predicates crash the trace portal or (in source-prefilter profiles) stress privileged evaluation paths.

**Vectors:**
- expression-tree complexity bomb (deep nesting, large membership sets)
- type confusion (field type mismatch) used to trigger undefined behavior in evaluators
- fuel/overflow behavior used as an oracle (timing/covert channel)

**Impact:**
- observability subsystem DoS; loss of diagnostics
- increased side-channel surface if evaluation cost varies widely

**Mitigations:**
- strict structural bounds + closed operators (PO-TPRED-VALIDATE/BOUNDS)
- deterministic fail-closed behavior on fuel exhaustion/overflow
- prefer portal-only evaluation in early profiles; gate any source-prefilter behind extra review/evidence

**Evidence targets:**
- fuzz + differential tests for predicate validation/evaluation
- stress tests at worst-case bounds; verify deterministic overflow/drop semantics

## AC-057: consent diff spoofing / confused-deputy (D-EXPLAIN)

**Scenario:**
- An untrusted component tries to obtain extra authority by:
  - presenting misleading prose or UI context (“this is just a settings change”) while requesting a broader `cap.grant`,
  - exploiting a TOCTOU/serialization bug so the UI shows a benign diff but the approved action digest corresponds to a different grant,
  - causing the UI to render a non-canonical summary (e.g., localization/formatting differences) that is not actually bound to what is executed.

**Impact:**
- user grants unintended authority (grant creep)
- approvals become non-auditable (“what did I actually approve?”)

**Mitigations:**
- canonical, deterministic diff/summary derived from canonical inputs (I-EXPLAIN-1; PO-EXPLAIN-SUMMARY)
- bind UI gesture evidence to the *action digest* and *summary/diff digest* (CH-VOL; I-VOLITION-1)
- emit CH-RECEIPT binding (action_digest, summary_digest, authz_digest, optional vol_digest) to the outcome (I-EXPLAIN-2; PO-EXPLAIN-RECEIPT-BIND)
- use a bounded/redacted diff structure (CH-CAPDIFF) and fail closed on truncation unless explicitly indicated (I-EXPLAIN-4; PO-CAPDIFF-REDACT)
- origin branding (derive from CH-COMP identity; never from requester text) and clamp any requester-controlled strings

**Evidence targets:**
- negative tests: fuzz consent/receipt parsers and UI binding logic; ensure mismatches reject deterministically
- red-team harness: attempt to vary requester text, locale hints, or timing to change what is shown vs what is approved



## AC-058: Secret release confused deputy (vault bypass / wrong-context release)
**Scenario:** an attacker controls (or compromises) a component that can talk to the vault provider and attempts to get a secret revealed/exported by:
- supplying a misleading or ambiguous `context` string,
- replaying an old approval (CH-AUTHZ / CH-VOL) against a different secret/policy digest,
- inducing a “policy downgrade” (e.g., rotate into a weaker policy) via rollback or race,
- or exploiting indexing/metadata surfaces to learn secret-bearing information.

**Impact:**
- credential exfiltration (tokens/passwords/recovery material)
- cross-protocol misuse (e.g., using an OAuth refresh secret for a different relying party)
- audit gaps (“we can’t explain why the secret was released”)

**Mitigations:**
- enforce CH-SECRETPOL per-operation with closed enums + fail-closed validation (I-VAULT-1; PO-SECRETPOL-ENF)
- require explicit `contexts` and reject unknown/missing contexts deterministically (I-VAULT-2)
- bind approvals to action+policy digests (CH-AUTHZ; CH-VOL; CH-RECEIPT/CH-CAPDIFF when used) to prevent replay to a different secret/policy (I-VOLITION-1; I-EXPLAIN-2)
- treat vault metadata/indexing as an observation surface; restrict export/query by capability and redact by default (I-OBS-1)
- when D-PERSIST is enabled, apply rollback/resurrection defenses for durable secret references (align with I-REVOKE-2 and CapStore rollback notes)

**Evidence targets:**
- negative tests: mismatched (secret_id, policy_digest, context, authz) tuples must reject
- fuzzing: parsers/validators for CH-SECRETPOL/CH-SECRETREF must fail closed
- replay tests: attempt to reuse a valid approval on a different secret/policy digest; must reject deterministically


## AC-060: Ordinal collision/reuse causes misdispatch (confused deputy)
- **Surface**: CapRPC runtimes / generated stubs (CH-CAPRPC.method_id; D-IDL).
- **Attacker**: malicious or buggy component that can influence IDL/codegen inputs, or can cause an upgrade that renumbers/reuses ordinals.
- **Goal**: have a caller believe it invoked method **A** while the callee dispatches method **B** (or vice versa), potentially widening effects.
- **Failure mode**:
  - method ids are derived from unstable ordering (e.g., “position in file”), or
  - ordinals are reused after removal, or
  - hash-derived ordinals collide and the collision is ignored.
- **Impact**: misdispatch can act like an implicit adapter with undefined semantics; in the presence of authority-bearing methods, this can create confused-deputy style escalation.
- **Mitigations**:
  - Pin and validate ordinal mapping via **CH-ORD v0**; reject duplicates and reserved-range violations.
  - For hash-derived ordinals, generators MUST collision-check within the declared set and fail closed.
  - Tooling gates MUST reject ordinal reuse for different semantics (upgrade-time drift guard).
  - Prefer closed interfaces (fail-closed) for high-assurance privileged surfaces.

## AC-061: diagnostic snapshot bundle exfiltration (support bundle as a covert channel)
- **Surface**: snapshot tooling / IF-OBS exports / diagnostics collectors (D-INSPECT).
- **Attacker**: a compromised component, or a social attacker who convinces an operator to export a “support bundle.”
- **Goal**: exfiltrate secrets (credentials, bearer tokens, private identifiers) via an apparently legitimate diagnostic snapshot.
- **Failure mode**:
  - snapshot tooling includes high-risk data by default (raw configs, sturdyrefs, secrets)
  - inspect trees/logs contain bearer material and are exported without redaction
  - bundles are shareable without strong scoping or verification of what\x27s inside
- **Impact**: loss of confidentiality; may enable lateral movement if bearer material leaks.
- **Mitigations**:
  - Treat bundle creation/export as **explicit authority** (I-SNAP-1): no ambient “dump everything” path.
  - Default to sanitized bundles and require explicit workflow for sensitive entries (PO-SNAP-REDACT).
  - Bind bundles to declared redaction_profile + entry digests so consumers can verify scope (I-SNAP-2; PO-SNAP-BIND).
  - Prefer digests/refs for sensitive identifiers (e.g., CH-KEYREF/CH-SECRETREF) over raw values.

## AC-062: inspect-tree DoS / high-entropy channel (structured diagnostics abuse)
- **Surface**: per-component inspect publishing (D-INSPECT).
- **Attacker**: adversarial component instance that can publish its own inspect region.
- **Goal**: consume collector CPU/memory, or create a high-entropy covert channel through exported diagnostics.
- **Failure mode**:
  - unbounded inspect regions or snapshots
  - collector performs expensive parsing/aggregation on attacker-controlled data
  - high-rate updates cause continual rescans and backpressure failures
- **Impact**: degraded observability, incident response interference, or secondary resource exhaustion.
- **Mitigations**:
  - hard size limits per inspect region and per snapshot (I-INSPECT-2; PO-INSPECT-BOUNDS)
  - total decoding/validation must be deterministic and bounded (PO-INSPECT-VALIDATE)
  - sampling/rate limiting at the collector boundary; drop behavior is explicit and policy-driven

## AC-063: trace schema confusion / redaction bypass via misdescribed fields
- **Surface**: trace export (D-TRACE) + predicates/processors (D-TPRED/D-TRACEPROC), especially when traces are shared offline.
- **Attacker**: component that can emit traces, or a compromised trace-export pipeline that can substitute schema bytes.
- **Goal**: exfiltrate sensitive data by getting consumers/exporters to interpret a sensitive field as “public/sanitized”, or to apply a predicate to the wrong field (schema mismatch).
- **Failure mode**:
  - consumers guess field order/types from build lore or heuristics
  - a substituted/incorrect schema table maps `args[i]` to the wrong semantic meaning
  - exporters apply policy to the wrong semantic field, leaking raw addrs/IDs or other sensitive values
- **Impact**: confidentiality breach (unexpected sensitive export), or integrity failure in debugging workflows (filters/processors operate on the wrong data).
- **Mitigations**:
  - pin a tracepoint descriptor manifest digest (D-TPROBE; CH-TPROBE) and treat schema bytes as untrusted unless they match the pinned digest (I-TPROBE-1; PO-TPROBE-VALIDATE)
  - enforce descriptor↔event agreement at emission/export time; mismatches drop/fail closed and are diagnostics-visible (PO-TPROBE-MATCH)
  - apply export policy using field-level `redaction`/`sem` metadata (CH-TPROBE + CH-OBSPOL) rather than ad hoc per-probe assumptions
  - when in doubt, export less: omit raw traces or export only derived aggregates (D-TRACEPROC) under strict bounds

## AC-064: reentrancy via inbox-pumping RPC stubs (confused deputy)

**Scenario:**
- A service uses a “convenient” synchronous/await-style RPC stub that blocks waiting for a reply.
- To avoid deadlock, the runtime keeps the service responsive by processing inbound requests while blocked (“pump the inbox”).
- An attacker triggers a callback/reentrant request that arrives **mid-update**, observing inconsistent state or causing state machine violations.

**Impact:**
- broken local invariants (“half-mutated” state becomes observable)
- confused-deputy escalation if reentrant callbacks are authority-bearing
- nondeterministic bugs that defeat replay/testing and complicate verification

**Mitigations:**
- adopt **D-TURNS** (RFC-0078) for selected services: turn-atomic delivery; forbid hidden inbox pumping (I-TURNS-1; PO-TURNS-NOREENTR)
- prefer promise-based CapRPC APIs (RFC-0026) and explicit continuations over blocking calls
- include explicit reentrancy probes in service test suites (negative tests)

**Evidence targets:**
- regression harness that attempts to callback into a service during an in-flight call/await; must not interleave inside the same turn
- differential test: D-TURNS runtime vs non-D-TURNS runtime demonstrates the hazard and the mitigation

## AC-069: activation/handle-store misuse (seal bypass or wrong-instance restore)
- **Surface**: D-ACTIVATE stable handles + per-component handle store (RFC-0081), especially across supervised restarts.
- **Attacker**: compromised component trying to (a) stash init-only authority for later, or (b) retrieve another component’s stored handles via confusion.
- **Goal**: widen authority after seal/restart, or cause cross-component impersonation by acquiring the wrong stable endpoints.
- **Failure modes**:
  - handle-store writes allowed pre-seal by default, enabling “stash init cap → seal → restart → retrieve”
  - store namespace not bound to `cid` (or instance) allowing cross-component retrieval
  - unbounded store growth causes memory/FD exhaustion DoS
- **Mitigations**:
  - phase gating: default `steady_only` store writes; `init_ok` is explicit and allowlisted (I-ACTIVATE-2)
  - store namespace is per-`cid` and wrong-instance retrieval fails closed; restores are deterministic and logged (PO-ACTIVATE-HANDOFF)
  - strict bounds on key length, item count, and metadata size; deterministic overflow behavior
  - restarts remain non-amplifying w.r.t. CH-COMP routes and seal posture (I-SUPV-1)


## AC-070: split-view transparency log attack / targeted invisibility

**Scenario:**
- A publisher (or attacker who has compromised publisher infrastructure) releases a targeted malicious build (or a targeted downgrade).
- The attacker controls distribution/mirrors and can influence what victims and auditors fetch.
- A standalone transparency log is used, but victims/auditors do not require witnessed checkpoints.
- The attacker attempts either:
  - **equivocation**: present different checkpoint histories to different parties (split view), or
  - **targeted invisibility**: delay or suppress the targeted release’s visibility to independent monitors until after impact.

**Impact:**
- a targeted release can be difficult to prove existed (or existed *when*) without a commonly witnessed checkpoint
- monitors may be unable to converge on a shared history, weakening ecosystem accountability
- downstream “binary transparency” expectations degrade into best-effort forensics

**Mitigations:**
- enable **D-WITNESS** (RFC-0082) for high-assurance channels: require threshold witness signatures over checkpoints for “audit-complete” releases (I-TLOG-2; PO-TLOG-WITNESS)
- run independent monitors that verify checkpoint consistency across time (PO-TLOG-VERIFY) and alert on regressions
- optionally anchor releases to **multiple independent logs** (multi-log anchoring) to reduce single-log trust
- keep installation gates independent: TUF freshness/consistency (D-TUF) and provenance gates (D-PCP) still apply even if transparency monitoring is degraded

**Evidence targets:**
- negative tests: insufficient witness threshold / mismatched witness signatures must fail an “audit-complete” check
- monitor exercise: two divergent checkpoints must be detected as a split-view attempt


## AC-071: compatibility capsule escape / ambient host effects

**Scenario:**
- The system runs a compatibility runtime capsule (D-RUMPK), e.g., a rump domain, LKL-style donor subsystem, or another legacy driver/FS stack in user space.
- The donor stack expects “host services” (names, files, sockets, timers, debug channels) and obtains them through a portability shim.
- A bug or deliberate backdoor in the shim (or an unintended integration channel) allows the compat capsule to:
  - reach privileged effects (e.g., ACP actions) through an ambient path,
  - acquire broad naming authority (“open-by-path” escape), or
  - access other components’ resources (e.g., global debug sockets) outside declared routes.

**Impact:**
- authority amplification across the membrane (violates capability discipline)
- hidden exfiltration channels (logs/debug ports)
- fragile “it’s isolated until it isn’t” failures that are hard to audit

**Mitigations:**
- enforce the compatibility membrane invariants:
  - I-COMPAT-1 (no ambient host effects; effects only via portals/translators/views)
  - I-COMPAT-2 (fail-closed ABI/hostcall surface)
- use D-SEAL on compat capsules: broad bring-up authority is dropped after init and cannot be reacquired
- ensure all integration surfaces are transcript-visible (CH-LOG) and composition-linted (CH-COMP routes)
- prefer IO access via explicit leases (D-IOLEASE) rather than raw access paths

**Evidence targets:**
- negative tests: attempt ambient filesystem/network acquisition from inside a compat capsule must fail deterministically
- “escape channel” audit: enumerate and fuzz hostcall/ABI surfaces; unknown operations must fail closed
- composition test: cap-graph export shows only intended authority edges, even after restart


## AC-072: label laundering / confused-declassifier

**Scenario:**
- D-IFC (RFC-0047) is enabled for an IFC-lite profile: some channels/objects are labeled, and some export surfaces (IF-OBS, portals) are treated as sinks.
- A component (or a wrapper/adapter around it) attempts to **widen allowable flows** by:
  - removing secrecy tags (declassification), and/or
  - adding integrity tags (endorsement),
  without holding the corresponding privilege capabilities.
- Alternatively, a privileged declassifier/endorser exists, but an untrusted component tricks it into acting as a **confused deputy** (e.g., by presenting a misleading request, or by exploiting an ambiguous API that doesn’t bind the request to a specific digest/intent).

**Impact:**
- confidentiality breach: secrets can flow to export sinks or lower-labeled domains
- integrity breach: high-integrity decisions can be influenced by tainted inputs without detection
- audit confusion: if label changes are not transcript-visible, post-incident reconstruction cannot distinguish allowed declassification from laundering

**Mitigations:**
- enforce **I-IFC-3**: only explicit privilege tokens can widen flows; successful declassify/endorse is transcript-visible
- enforce **PO-IFC-DECLASS**: tag removal / integrity-add without privilege fails closed; error paths are non-bypassing
- if declassification is mediated by portals/consent:
  - bind declassification actions to canonical digests (I-AUTHZ-1/I-CONSENT-1) so a declassifier cannot be tricked into applying the wrong change
  - seal declassifiers after init (D-SEAL) so they cannot regain broad authority
- prefer quarantine-as-tag interop: “clear quarantine” becomes a single, auditable declassify operation rather than bespoke state mutations

**Evidence targets:**
- negative tests: attempts to remove secrecy tags or add integrity tags without privileges fail deterministically
- transcript tests: successful declassify/endorse emits a CH-LOG record that can be tied to a specific request/action
- differential tests: model-vs-impl for flow_ok + label-change rules on a chosen primitive subset (EVID-2026-082)


## AC-073: shared-buffer TOCTTOU / mutation-after-send

**Scenario:**
- D-IOBUF (RFC-0084) is enabled for performance, and components exchange large payloads via shared buffer handles (shared regions) rather than copying.
- A sender provides a receiver with a reference to bytes in shared memory, and the receiver treats those bytes as stable for parsing/validation/authorization.
- The sender (malicious or compromised) then **mutates the bytes after “send”** (or races updates), aiming to:
  - change a validated request after checks (“validated then swapped”),
  - cause the receiver to act on unintended data (confused deputy),
  - or smuggle data across policy gates by exploiting inconsistent views.

**Impact:**
- integrity breach: receiver performs actions based on data it did not actually validate
- confidentiality breach: shared memory becomes a covert channel across trust boundaries
- audit confusion: without descriptors, post-incident analysis cannot tell whether sharing was intended to be mutable or immutable

**Mitigations:**
- enforce **I-IOBUF-2**: cross-trust shares must be **immutable or snapshot-based** (CH-IOBUF `immutability != mutable`) or the share is rejected
- require CH-IOBUF descriptors on trust-boundary crossings and make share events transcript-visible (CH-LOG by digest)
- for streaming/rings: require a **pinned contract** (RFC-0006) that defines ownership/commit rules; treat contract violations as deterministic failures
- bound buffer sizes, participant counts, and lifetimes (CH-IOBUF validator + policy)

**Evidence targets:**
- negative tests: `cross_trust + immutability=mutable` is rejected in hardened profiles
- race probes: attempt mutation-after-send against a parser/validator harness; verify the only permitted path is immutable/snapshot semantics
- contract tests: ring ordering/ownership violations deterministically fail (no silent “best effort”)


AC-074: malicious peripherals, hotplug DMA, and auto-attach footguns

**Scenario:**
- An attacker gains brief physical-adjacent access (or supplies a “helpful” peripheral) and plugs in a device that:
  - impersonates **HID** (keyboard/mouse) to inject commands,
  - impersonates a **network adapter** to bypass network policy,
  - impersonates storage/camera to trigger parser bugs,
  - or (Thunderbolt/USB4/PCIe hotplug) attempts **DMA-class** compromise.
- A too-permissive policy (or “auto-attach for convenience”) silently routes the device into a sensitive workload domain.

**Impact:**
- integrity: injected input drives privileged workflows; confused-deputy attacks via UI or portals
- confidentiality: exfil via rogue NIC/storage paths; covert channels
- system compromise: DMA-capable device reaches memory absent proper IOMMU confinement

**Mitigations / design pressure:**
- enable D-DEVGUARD: **deny-by-default hotplug** + explicit attach portals; keep “inventory visibility” separate from “device authority”
- prefer a dedicated **untrusted peripheral domain** (Qubes-style) that owns raw devices; expose higher-level mediated services by default
- if raw device access is required, grant only via **bounded leases** (D-IOLEASE/CH-IOLEASE) with explicit DMA posture (D-DMA) and deterministic revoke
- for HID: treat input endpoints as **UI capabilities** (RFC-0080); require a trusted attention path (SAS) for sensitive entry points
- ban/strongly gate auto-attach in hardened profiles; if allowed, make it explicit as data (CH-DEVGUARD) and transcript-visible

**Evidence targets:**
- negative tests: hotplug without policy results in deny/quarantine; no caps appear in the target domain
- fuzz: device descriptor parsing and attach workflows are fuzzed under hostile input
- DMA: IOMMU mapping tests demonstrate confinement for leased queues/resources; missing IOMMU ⇒ fail closed for DMA-capable buses
- regression: attempts to bypass attach portals (e.g., via auto-attach drift) are detected by transcript-based policy drift checks


## AC-075: triage-triggered sensitive export / diagnostic exfil / rule DoS

**Scenario:**
- D-INSPECT and/or CH-CRASHCAP are enabled, and an operator workflow exists to export sanitized snapshots by default.
- D-TRIAGE is enabled and on-device tooling evaluates CH-TRIAGE over inspect/crash artifacts.
- An attacker controls some observable state (e.g., untrusted service inputs that are reflected into logs/inspect counters) and attempts to:
  - trigger repeated “collect more” recommendations,
  - induce frequent escalation requests (“need full tier”) to fatigue operators into approving sensitive exports,
  - or drive CPU/IO overhead via pathological rule evaluation.

**Impact:**
- confidentiality risk: increased pressure to export larger/more sensitive bundles
- availability risk: repeated snapshot assembly or elevated diagnostics overhead
- audit confusion: if the system cannot explain why escalation was requested/approved

**Mitigations:**
- enforce **I-TRIAGE-1**: bounded, closed-set, deterministic evaluation (no regex/VM)
- enforce **I-TRIAGE-2** + **I-OBSPOL-1**: triage is advisory; CH-OBSPOL allowlists/bounds and capability gates always apply
- prefer **rate limits/budgets** in snapshot/export tooling (D-BUDGET/D-METER adjunct) rather than in rule logic
- make escalation approvals transcript-visible with receipts/diffs when used (D-EXPLAIN), so “why did we allow full?” is mechanically answerable

**Evidence targets:**
- negative tests: triage requesting forbidden entry kinds/tier is rejected by CH-OBSPOL enforcement (no partial export)
- boundedness tests: rule evaluation cost remains within fixed caps under adversarial inputs
- workflow tests: escalation approvals require explicit workflow authority and produce audit-visible receipts

## AC-076: durable document handle confusion / bookmark-style sandbox escape

**Scenario:**
- D-PLUMB/D-POWERBOX are enabled and apps use durable “recent document” handles.
- A document portal mints CH-DOCREF entries for user-chosen files/dirs.
- An attacker attempts to:
  - exfiltrate a CH-DOCREF to another component/user and re-open it as a bearer token,
  - trick the portal into retargeting a durable grant to a different underlying object (swap/replace), or
  - exploit weak validation/key management around persistence to broaden access beyond the original consent.

**Impact:**
- confidentiality breach: unauthorized access to previously user-authorized documents
- integrity breach: write access to a different target than the user intended
- policy drift: persistent grants become ambient, hard-to-revoke authority

**Mitigations:**
- enforce **I-DOCREF-1**: CH-DOCREF is non-bearer; portal must authenticate caller and enforce `origin.comp_id` binding before issuing any handle
- enforce **I-DOCREF-2**: portal never returns host paths; reopening re-checks stable target identity; replaced targets fail closed or require fresh consent
- make persistence explicit and transcript-visible (D-POWERBOX + CH-RECEIPT + D-EXPLAIN); avoid “always persistent” chooser defaults
- provide clear, user-facing revoke/inspect UI for persistent grants; revocation survives restart/restore (D-PERSIST revocation epoch posture)
- negative tests: stolen docrefs, swapped targets, and origin mismatches reject deterministically (PO-DOCREF-REOPEN)

**Evidence targets:**
- harness tests: (1) origin mismatch denies, (2) revoke/expiry denies, (3) rename/move succeeds, (4) replace/swap triggers deny or re-consent
- export tests: sanitized bundles redact labels and (optionally) forbid exporting docrefs via CH-OBSPOL
- regression tests: policy/receipt binding remains stable under UI spoof attempts (D-VOLITION/D-EXPLAIN adjunct)

## AC-077: time rollback / time authority injection (expiry + audit weakening)

**Scenario:**
- The system enforces expiry/freshness (C-TIME-1) for updates, approvals, or policy.
- A deployment either:
  - relies on unauthenticated network time (classic NTP), or
  - enables D-TIMEPROOF but misconfigures verification (wrong key allowlist, missing nonce binding), or
  - updates “security time” directly from a wall clock that can move backward.

An attacker (ADV-NET or ADV-OPS) attempts to:
- push time **backward** to accept expired metadata/approvals,
- stall time to keep a frozen view “apparently fresh,” or
- induce large jumps to confuse logs/leases and create audit gaps.

**Impact:**
- rollback/freeze bypass of expiry-based protections (update metadata, approvals)
- misleading audit timelines (forensics confusion)
- lease/TTL confusion if time-based leases consult the wrong clock

**Mitigations:**
- enforce **I-TIME-1**: security checks use a monotonic source and fail closed.
- if D-TIMEPROOF is enabled, enforce **I-TIMEPROOF-1**: proofs are verified per allowlisted authority keys and nonce binding; invalid proofs reject deterministically.
- enforce **I-TIMEPROOF-2**: the “secure wall time” lower bound used for expiry never decreases; backward adjustments require explicit, transcript-visible override and must not silently weaken enforcement.
- keep time sync in user space: wall-clock for UX/log display is not directly trusted for security decisions.

**Evidence targets:**
- negative tests: injected unauthenticated NTP packets do not change `secure_time_lb` under D-TIMEPROOF.
- verification tests: wrong authority keys, wrong nonce binding, and malformed proofs reject deterministically (PO-TIMEPROOF-VERIFY).
- monotonic-apply tests: backward time attempts reject; unreasonable jumps require explicit override token and are logged (PO-TIMEPROOF-APPLY).

## AC-078: SBOM mismatch / injection (misleading audits and metadata exfil)

**Scenario:**
- The ecosystem uses SBOMs for vulnerability scanning, compliance, or incident response.
- A release/boot includes a CH-SBOM digest (or an external SBOM document) as an “audit attachment.”

An attacker (ADV-SUPPLY or ADV-OPS) attempts to:
- attach an SBOM for a *different* deployment/component (drift),
- swap SBOMs in transit so auditors see “clean” inventory while compromised bits run,
- use oversized SBOM metadata as an export/exfil channel ("SBOM as covert channel").

**Impact:**
- false confidence ("SBOM says patched" while vulnerable/compromised bits are installed)
- missed vulnerability exposure or incorrect triage
- privacy leakage via exported dependency/version metadata

**Mitigations:**
- enforce **I-SBOM-1**: SBOM subject binding is checked when referenced by CH-UPD/CH-BOOT artifacts (role `sbom`); mismatches are treated as non-compliant.
- enforce **PO-SBOM-VALIDATE**: CH-SBOM decode/validation is total, canonical, and bounded; unknown variants reject.
- keep SBOMs **non-authoritative**: do not accept SBOM fields as authorization evidence.
- export hygiene: govern SBOM export via **CH-OBSPOL** tiers; redact supplier/purl/license fields when needed; forbid exporting large external SBOM docs unless explicitly allowed.

**Evidence targets:**
- binder tests: mismatched `sbom.subject.digest` is rejected deterministically (PO-SBOM-BIND)
- export tests: SBOM exports remain bounded; redaction tiers remove sensitive fields
- negative tests: external_doc_aref over-size/unsupported schemes rejected via PO-AREF-VERIFY allowlists

## AC-079: VEX misuse / suppression (false “not affected” + covert disclosure)

**Scenario:**
- The ecosystem uses VEX statements to reduce vulnerability-scanner noise.
- A release/boot includes a CH-VEX digest (or an external VEX document) as an “audit attachment.”

An attacker (ADV-SUPPLY or ADV-OPS) attempts to:
- attach a VEX document for a *different* deployment/component (drift),
- publish “not_affected” statements with misleading justifications to suppress remediation,
- smuggle sensitive topology/mitigation details through oversized exports ("VEX as covert channel").

**Impact:**
- false confidence (vulnerabilities are silently ignored)
- incident response confusion (“we thought it was not affected”)
- privacy leakage (internal component IDs, mitigation notes, build metadata)

**Mitigations:**
- enforce **I-VEX-1**: VEX subject binding is checked when referenced by CH-UPD/CH-BOOT artifacts (role `vex`); mismatches are treated as non-compliant.
- enforce **I-VEX-2**: closed status/justification enums + bounded statements; unknown variants reject.
- enforce **PO-VEX-VALIDATE**: CH-VEX decode/validation is total, canonical, and bounded; unknown variants reject.
- keep VEX **non-authoritative**: do not accept VEX fields as authorization evidence; treat it as reviewable claims.
- export hygiene: govern VEX export via **CH-OBSPOL** tiers; redact optional component identifiers and notes; forbid exporting large external VEX docs unless explicitly allowed.

**Evidence targets:**
- binder tests: mismatched `vex.subject.digest` is rejected deterministically (PO-VEX-BIND)
- export tests: VEX exports remain bounded; redaction tiers remove component identifiers/notes
- negative tests: external_doc_aref over-size/unsupported schemes rejected via PO-AREF-VERIFY allowlists


## AC-080: Keyless signing identity spoofing / policy confusion (Sigstore-style)

**Scenario:**
- The ecosystem accepts keyless signatures (D-KEYLESS) for CH-UPD / CH-PROV / other release artifacts.
- Signers authenticate via an OIDC issuer and obtain short-lived certificates.

An attacker (ADV-SUPPLY or ADV-OPS) attempts to:
- obtain a valid keyless certificate for an identity that is *too broad* (e.g., “any GitHub user”),
- exploit policy gaps so a signature from an unintended workflow/repo is accepted,
- replay old-but-valid certs where time/freshness is weak,
- present “log evidence” without a real inclusion proof or with a split-view log.

**Impact:**
- unauthorized artifacts appear “properly signed”
- targeted compromise via mis-scoped identity allowlists
- audit confusion (“signed” but by whom/what?)

**Mitigations:**
- enforce **I-SIGENV-1**: signatures are verified over DSSE-style `(payload.schema, payload.digest)` binding; type-confusion attempts reject.
- enforce **I-KEYLESS-1**: keyless acceptance is policy-driven: issuer allowlists + identity allowlists (repo/workflow/email); envelope identity hints are not authoritative.
- require deterministic verification (fail closed): **PO-SIGENV-VERIFY** and **PO-KEYLESS-VERIFY**.
- for higher-assurance channels, require transparency anchoring (D-TLOG) and/or witness checkpoints (D-WITNESS) for “audit-complete” criteria.
- couple validity checks to the profile time posture: use **I-TIME-1** / D-TIMEPROOF to avoid rollback/freeze acceptance.

**Evidence targets:**
- negative tests: wrong issuer, wrong repo/workflow identity, expired cert, and type-swapped payload all reject deterministically.
- transparency tests (if enabled): “anchor missing” or invalid checkpoint signatures reject; split-view simulation is detected in witness-enabled profiles.


## AC-081: Clipboard/drag-drop exfiltration + covert channels (ambient transfer surfaces)

**Scenario:**
- The system supports desktop workflows (clipboard, drag-drop, share) between isolated components.
- Some apps are untrusted or partially compromised (ADV-APP).

An attacker attempts to:
- read clipboard contents opportunistically (background snooping),
- trick the user into drag-dropping/exporting data to a less-trusted component (confused deputy),
- use oversized clipboard metadata/payload descriptors as a covert channel,
- keep sensitive clipboard content resident long after the user’s intent (stale-grant leakage).

**Impact:**
- silent cross-domain data exfiltration
- loss of least-privilege posture for desktop sandboxes (“clipboard makes everything ambient”)
- privacy leaks via exported diagnostics (snapshots/crashcaps)

**Mitigations:**
- model clipboard/drag-drop as **portal-mediated transfers** (D-PLUMB): no ambient “read clipboard” capability exists after init; all cross-component transfers require explicit portal grants.
- require **focus/volition gating** for cross-trust paste/drop (D-VOLITION where enabled); bind grants to a transcript entry and (optionally) an authority diff receipt.
- default to **leased payload handles** (D-LEASE): short TTL and/or single-use; recommended **auto-clear** semantics for clipboard-style transfers.
- clamp formats and bounds: default-to-plain-text for cross-domain clipboard in strict profiles; enforce max bytes and close-set format identifiers.
- standardize **CH-XFER v0** as a bounded, redaction-aware descriptor (no payload bytes) so grants are auditable without becoming an export channel.
- export hygiene: obey CH-OBSPOL tiers; redact/forbid exporting transfer descriptors for `sensitive=true` transfers.

**Evidence targets:**
- negative tests: background app cannot observe clipboard; transfer attempts without portal grants fail closed.
- bounds tests: oversized `offered` lists, huge labels, or over-limit payload offers reject deterministically.
- lifecycle tests: single-use/TTL expiry and auto-clear are enforced; stale transfer references cannot be reused.

## AC-082: Silent media capture / indicator spoofing / scope escalation (camera/mic/screencast)

**Scenario:**
- The system supports multimedia capture (camera, microphone) and UI capture (screencast, remote desktop).
- Some apps are untrusted or partially compromised (ADV-APP).

An attacker attempts to:
- record microphone audio via an “ambient” audio-server socket or unmediated device open,
- start a screencast without user awareness (or keep it running after the user’s intent),
- escalate capture scope (window → whole screen) without a fresh consent/volition step,
- suppress or spoof capture indicators (LED/OSD),
- exfiltrate sensitive metadata via exported diagnostics (who/what was being shared, when).

**Impact:**
- privacy compromise (audio/video capture, screen contents)
- credential theft via remote-desktop input injection
- durable surveillance via long-lived capture grants

**Mitigations:**
- portalize capture: treat camera/mic/screencast/remote-desktop as **high-risk portals** (D-PLUMB + D-UICAP); no ambient capture paths after init.
- lease-first posture (D-LEASE): short TTL by default; renew and scope escalation require portal mediation and (in strict profiles) fresh D-VOLITION.
- indicator discipline: drive capture indicators from the portal/OS shell (not the requesting app); require indicators for active capture sessions in strict profiles.
- bound and audit session metadata: emit **CH-CAPTURE v0** descriptors (no media bytes/paths), logged/receipted by digest; apply CH-OBSPOL export tiers (redact/forbid by default).
- device plumbing: confine raw device access via D-IOLEASE; apps receive only constrained capture endpoints.

**Evidence targets:**
- negative tests: background app cannot start mic/camera capture; screencast start/renew requires portal grants.
- escalation tests: scope escalation requires fresh consent/volition; renewal without required UX fails closed.
- indicator tests: indicators are present while capture is active and cannot be disabled by the requester.
- export tests: CH-CAPTURE redaction/forbid rules enforced under CH-OBSPOL.

## AC-083: Background job abuse / wakeup storms / timing channels (alarm-as-authority)

**Scenario:**
- The system supports deferrable background work (periodic refresh, maintenance, uploads).
- Some apps are untrusted or partially compromised (ADV-APP).

An attacker attempts to:
- schedule frequent jobs to drain battery or monopolize background runtime (wakeup storm),
- use job triggers as a covert timing channel (high-resolution wakeups),
- arrange background network activity without explicit network authority,
- keep background work persistent across reboot without explicit durability authority,
- exfiltrate metadata via exported diagnostics (job schedules, identities, timing).

**Impact:**
- power and performance denial of service
- privacy leaks via timing behavior and exported job metadata
- erosion of least-privilege (“background daemon by another name”)

**Mitigations:**
- eliminate ambient alarms: model background work as a **portal-mediated job request** (D-JOBS); no cron/alarm constructors exist after init.
- clamp and coalesce: enforce minimum periods, bounded flex windows, and pressure-aware deferral (D-PRESSURE); prefer coarse scheduling to reduce timing channels.
- bound runtime: each job run is bounded (wall-time and, where enabled, TCaps via D-TCAP); overrun triggers deterministic termination.
- no implicit networking: background jobs do not imply outbound network access; networking remains lease-based (D-NETLEASE) and must be requested explicitly.
- durability requires explicit authority: persistent job schedules require D-PERSIST durability authority; restores are non-amplifying (I-PERSIST-2).
- audit/export hygiene: emit bounded CH-JOBREQ descriptors; exports obey CH-OBSPOL tiers (redact/forbid when `sensitive=true`).

**Evidence targets:**
- negative tests: untrusted app cannot schedule high-rate jobs; jobs cannot bypass portal mediation.
- bounds tests: minimum period clamps and runtime caps are enforced; cancellation/expiry works.
- side-channel tests: high-resolution wakeups are not achievable via the job API in strict profiles (coarse scheduling + randomization).
- export tests: CH-JOBREQ redaction/forbid rules enforced under CH-OBSPOL.


## AC-084: Accessibility/automation abuse (ambient UI observation + input injection)

Threat: “accessibility” and “automation” APIs are a frequent real-world footgun: they are often implemented as global hooks that can observe UI structure/text and inject input system-wide. Malware uses these channels for credential theft, click fraud, and persistence.

Attack sketch:
- A malicious component obtains (or tricks a user into granting) an accessibility/automation right.
- It observes focus/UI tree/text to scrape secrets (2FA codes, password manager prompts) and/or injects input to approve prompts, drive a browser, or automate exfiltration.
- If these APIs are ambient, attackers can use them without a visible workflow, and defenders cannot reliably audit attribution or scope.

Mitigations direction:
- **D-UIAUT (RFC-0099):** treat UI observation/injection as explicit, portal-mediated **leased sessions** (CH-UIAUT) with rights separation (observe ≠ inject), TTL/renew, and shell-driven indicators.
- **D-UICAP (RFC-0080):** focus-gated input + no ambient surface readback; focus chain treated as sensitive metadata.
- **D-VOLITION/D-EXPLAIN:** any high-risk automation escalation (e.g., injection rights) requires fresh volition and an authority diff/receipt; renewals are auditable.

Pressure tests:
- No ambient “global accessibility hook” constructor exists after init.
- Observation-only sessions cannot inject.
- Revocation/expiry is deterministic and returns input routing to focus-only delivery.
- Indicators cannot be spoofed by the requestor.


## AC-085: Attribute index/query leakage + query-as-DoS

**Scenario:**
- D-ATTRFS is enabled with indexed attributes and query support.
- A compromised or malicious app (ADV-APP) can request queries against a view it holds.

An attacker attempts to:
- infer the existence of objects outside its view by observing query result counts/timing,
- learn sensitive metadata from indexed attributes that were not meant to be observable,
- use “live query” subscriptions as a high-rate metadata oracle,
- submit worst-case queries to exhaust CPU/memory in the index service.

**Impact:**
- privacy leaks via metadata inference
- integrity confusion if schema/type mismatches cause “best effort” coercions
- availability degradation (index/query DoS)

**Mitigations:**
- **view scoping (I-VIEW-1/I-VIEW-2):** queries MUST execute against an explicit view; no ambient global index exists.
- **bounded, closed predicates (I-ATTRQ-1):** CH-ATTRQ is validated as closed/bounded; evaluation is fuel-bounded and fail-closed.
- **attribute visibility discipline (CH-ATTR):** only keys declared `indexed=true` may be indexed; private/sensitive keys are non-indexable by policy; schema/type mismatches reject.
- **live-query hygiene:** subscriptions are capability-scoped, rate-limited, and overflow behavior is deterministic/observable.
- **resource accounting (optional):** if D-METER/D-BUDGET are enabled, indexing and worst-case query evaluation are charged to explicit payers.

**Evidence targets:**
- negative tests: queries cannot enumerate or infer objects outside the provided view; “count-only” or timing channels are clamped by scoping + bounded evaluation.
- validation tests: unknown operators/keys/types reject deterministically; no implicit coercions.
- DoS tests: worst-case predicates hit deterministic bounds; live subscriptions cannot flood beyond declared limits.


## AC-086: Location service abuse (covert tracking + background surveillance)

**Scenario:**
- The system provides a location subsystem (GPS/Wi‑Fi/cell/IP-derived) and applications want “near me” features.
- Some apps are untrusted or partially compromised (ADV-APP).

An attacker attempts to:
- obtain continuous location updates without obvious user action or visibility,
- request “precise” location when coarse would suffice, then correlate over time to infer home/work,
- smuggle location via low-grade side channels (timing/cadence, receipt metadata, export logs),
- keep tracking running in the background (or after “close”),
- use location workflows to indirectly gain outbound network authority.

**Impact:**
- privacy loss (covert tracking, stalking risk)
- user trust collapse for sandboxing/consent flows
- metadata leakage through diagnostics and receipts

**Mitigations:**
- **D-LOCLEASE (RFC-0101):** treat location as a portal-mediated **leased workflow** (`portal.location`) that returns scoped location capabilities and emits a redaction-aware **CH-LOCLEASE** descriptor.
- **explicit accuracy class:** requests declare `coarse` vs `precise`; policy can clamp downward; “precise” is treated as higher risk.
- **TTL + cadence bounds:** continuous updates are bounded, renewable, and revocable; portals clamp cadence upward (coarsen) by policy.
- **foreground/background posture:** background tracking is profile-gated and SHOULD require explicit consent + (in strict profiles) fresh volition.
- **indicators + transcript visibility:** continuous tracking implies non-spoofable UI indicators and transcript-visible grant/renew/revoke events.
- **no implicit net:** location grants do not imply networking; any provider network use stays inside the portal/service and composes with D-NETLEASE.
- **export redaction:** treat CH-LOCLEASE as sensitive metadata; default exports to hash-only redaction; location samples are not exported unless explicitly allowed by CH-OBSPOL.

**Evidence targets:**
- negative tests: no ambient location constructors after init; clients cannot get samples without a lease.
- clamp tests: cadence/TTL clamps work; expiry/revocation is deterministic.
- policy tests: background/precise requests require stronger approvals and are denied/clamped in strict profiles.
- export tests: receipts/logs are redacted by default; no coordinate leakage via CH-LOCLEASE; no implicit network authority leakage.


## AC-087: Inhibit misuse (battery drain, persistence, and transition DoS)

**Scenario:**
- Applications want to prevent screen blanking/suspend during playback, prevent logout during critical work, or prevent shutdown during updates.
- Some applications are untrusted or compromised (ADV-APP).

An attacker attempts to:
- hold the system awake indefinitely (battery drain; “never sleep” persistence),
- block shutdown/logout to frustrate user control,
- use inhibit status/idle transitions as an oracle (timing/behavioral metadata),
- renew inhibit locks at a high rate to evade TTL clamps.

**Impact:**
- availability degradation (refuses to suspend/shutdown; interferes with updates)
- battery drain and thermal issues
- user trust collapse in “least privilege” promises

**Mitigations:**
- **D-INHIBITLEASE (RFC-0102):** treat inhibit as a portal-mediated **leased workflow** (`portal.inhibit`) that returns inhibition handles and emits a redaction-aware **CH-INHIBITLEASE** descriptor.
- **delay-by-default:** untrusted apps get `delay` inhibits with bounded grace windows; `block` is reserved for allowlisted system components under policy.
- **TTL + renewal clamps:** portal clamps max TTL and limits renewal rate; expiry forces deterministic release.
- **visibility:** long-lived inhibits imply non-spoofable indicators; strict profiles require consent/volition binding.
- **no ambient APIs:** remove “keep awake” constructors after init; all inhibits go through portal mediation.
- **export redaction:** treat CH-INHIBITLEASE as sensitive metadata in strict profiles; default exports prefer hash-only.

**Evidence targets:**
- negative tests: no ambient inhibit constructors; non-allowlisted requesters cannot obtain `block`.
- clamp tests: TTL/renewal clamps prevent indefinite keeps; expiry/release deterministic.
- UI tests: indicator and consent posture triggers for long-lived inhibits.


## AC-088: Background/autostart abuse (stealth persistence and battery drain)

**Scenario:**
- Applications want to keep syncing, stay “online”, provide notifications, or run helper services.
- Some applications are untrusted or compromised (ADV-APP).

An attacker attempts to:
- obtain **stealth persistence** by running continuously in the background,
- register **autostart** so the app returns after reboot/login,
- combine background + other grants to enable continuous tracking/exfiltration,
- degrade availability via CPU/network churn and battery drain.

**Impact:**
- durable compromise persistence (“always-on” spyware/miner)
- battery drain / thermal issues / degraded responsiveness
- user trust collapse in “least privilege” claims

**Mitigations:**
- **D-BGLEASE (RFC-0103):** treat background execution and autostart as a portal-mediated **leased workflow** (`portal.background`) that returns BackgroundLease handles and emits a redaction-aware **CH-BGLEASE** descriptor.
- **prefer D-JOBS:** deferrable work uses the job portal; background leases are reserved for narrow cases (continuous presence) under policy.
- **TTL + renewal clamps:** portal clamps TTL and rate-limits renewals; expiry forces deterministic revocation.
- **visibility:** long-lived background grants imply non-spoofable indicators/status surfaces; strict profiles require consent/volition binding.
- **no implicit authority:** background/autostart grants do not imply network/file/device/location authority (compose with other portals explicitly).
- **export redaction:** treat CH-BGLEASE as sensitive metadata in strict profiles; default exports prefer hash-only.

**Evidence targets:**
- negative tests: no ambient autostart registration or background execution after init.
- clamp tests: TTL/renew clamps prevent “infinite background” loops; revocation/expiry is deterministic.
- UI tests: indicators/status surfaces appear for active background grants.
- composition tests: background grants do not create implicit network authority.


## AC-089: Secret portal misuse (cross-app correlation, secret oracle, stealth rotation)

**Scenario:**
- Applications use per-app secret seeds for local encryption/integrity.
- Some applications are untrusted or compromised (ADV-APP).

An attacker attempts to:
- abuse a “secret retrieval” API as an **oracle** (unbounded length, high-rate calls, metadata leaks),
- induce **cross-app correlation** by forcing shared scope or by observing deterministic identifiers,
- trigger **stealth rotation** to break availability (data becomes unreadable) or to cause churn,
- exfiltrate secrets via logs/telemetry/receipts.

**Impact:**
- privacy leaks (correlation, behavioral metadata)
- availability degradation (data locked out after rotation)
- erosion of the “no ambient authority” posture if secret lookup becomes name-based

**Mitigations:**
- **D-APPSECRET (RFC-0104):** expose secret access only via a secret portal (`portal.secret`) that returns per-app secret seeds under explicit scope and bounded parameters.
- **bounds + closed enums:** clamp lengths and request rates; reject unknown variants/keys; keep request parameters closed and reviewable.
- **no cross-app sharing:** derive secrets from canonical component identity; no “secret-by-name” APIs.
- **rotation is policy-gated:** rotation requires explicit authorization (and may require D-VOLITION in strict profiles); epoch bumps are transcript-visible.
- **no secret bytes in transcripts:** CH-APPSECRET is redaction-safe; logs/receipts never contain secret bytes.
- **export redaction:** treat CH-APPSECRET as sensitive metadata in strict profiles; prefer hash-only exports.

**Evidence targets:**
- negative tests: no ambient lookup; no cross-app derivation.
- clamp tests: length/rate clamps; rotation gating; monotonic epoch.
- export tests: no secret bytes in CH-LOG/CH-RECEIPT exports.


## AC-090: Plumb injection / confused deputy (intent forgery, unsafe opens/exports)

**Scenario:**
- D-PLUMB is enabled (workflow router + portals).
- Some components are untrusted or compromised (ADV-APP).
- The workflow router accepts CH-PLUMBMSG intents from apps and CLI tools.

An attacker attempts to:
- forge an intent that causes a privileged helper (viewer, exporter, converter) to open or export sensitive data,
- trick the router into routing an intent to a handler that runs with broader authority than the requester,
- exploit “open-with” / “export-as” defaults to induce exfiltration (e.g., export to network, clipboard, or broad filesystem view),
- spam ports or exploit parsing ambiguity to cause denial-of-service.

**Impact:**
- data exfiltration via confused-deputy flows
- integrity violations via unintended exports
- reliability issues if the router becomes a shared choke point

**Mitigations:**
- **source identity binding:** `src.component_id` is derived from runtime identity (CH-COMP), not trusted from message fields; rules match on canonical identity.
- **deny-by-default routing:** CH-ROUTE default is deny; only allowlisted (kind, source) pairs route without mediation.
- **portal mediation for risky intents:** any intent that can widen authority (OpenFile outside view, Share, Export, Print, Capture, Device pick) requires portal mediation (D-POWERBOX/D-VOLITION) and receipts (D-EXPLAIN).
- **non-authoritative envelopes:** CH-PLUMBMSG carries no raw capabilities or bearer secrets (I-PLUMB-3); authority transfer occurs only via explicit portal grants or subscription-bound redemption.
- **bounds + closed enums:** strict CH-PLUMBMSG validation (PO-PLUMBMSG-VALIDATE) rejects unknown variants/keys and enforces size bounds; rule evaluation is deterministic.
- **capgraph diff gating:** portal completion is gated by CH-CAPDIFF tests (PO-PLUMB-NOAMP) to prevent unexpected new authority edges.

**Evidence targets:**
- negative tests: forged source identity cannot influence routing; unallowlisted intents fail closed.
- drift tests: authority widening via helper flows is caught by capgraph-diff gating.
- fuzz tests: malformed CH-PLUMBMSG inputs reject deterministically; oversized messages are clamped.


## AC-091: In-process confused deputy (library uses privileged caps on behalf of untrusted caller)

**Scenario:**
- A component hosts a helper/library that holds broad internal authority (e.g., network export, filesystem view outside the caller’s scope, crypto/key use).
- The component also services untrusted inputs (plugins, script hooks, embedded documents, LLM tools, or compatibility code).

An attacker attempts to:
- induce a privileged helper to perform an effect using the helper’s own authority (export, fetch, open outside view),
- bypass “just pass handles” discipline via globals/singletons inside the process,
- exploit a mismatch between *who requested* and *what authority the callee has*.

**Impact:**
- data exfiltration (confused-deputy export)
- integrity violations (writes/changes outside caller-intended scope)
- audit failures (“why did this happen?” cannot be answered with receipts)

**Mitigations:**
- **D-BRACKET (RFC-0118):** adopt a user-space runtime convention where privileged capabilities are **inaccessible by default** while servicing inbound requests (borrowed mode).
- **Scoped privileged blocks:** privilege elevation requires an explicit, exception-safe block (`with_privileged { ... }`) and SHOULD be transcript-visible for high-risk helpers.
- **Call-chain descriptors (CH-CALLCHAIN) + CH-REQCTX v1:** optional bounded provenance metadata supports audit and *deny-only* routing/policy decisions.
- **Veto-only posture:** call-chain/context metadata must not grant authority; it may only narrow or deny.

**Evidence targets:**
- negative tests: privileged singleton paths fail closed in borrowed mode.
- scope tests: privilege does not leak across requests/tasks or panic paths.
- routing demo: deny a dangerous intent when call-chain includes an untrusted origin.


## AC-092: Cross-cluster metadata divergence / split-brain (Hybrid)

**Scenario:**
- Under Hybrid (ADR-0005), some metadata is visible across clusters via replication/caching.
- A buggy or compromised service (or a topology/config mismatch) causes different clusters to hold **inconsistent** views of that metadata.

An attacker attempts to:
- exploit divergence to bypass a deny-only rule (“cluster A thinks X is allowed; cluster B executes”),
- induce routing to the wrong owner cluster for an owner-sharded object,
- hide actions by causing receipts/transcripts to be recorded in one replica set but not another.

**Impact:**
- policy bypass via inconsistent deny-only inputs
- integrity failures (writes/attach/detach routed incorrectly)
- audit failures (partial transcripts, non-reconcilable histories)

**Mitigations:**
- **Explicit replication contract (D-REPL; ADR-0006):** CH-REPLCONTRACT pins which families are local vs owner-sharded vs commutative-merge vs ordered-log; missing/invalid contracts fail closed.
- **Owner-sharded routing (RC1/RC2):** authoritative mutations route to the owner cluster; replicas may cache read-only summaries only with explicit epoch tags and monotonic-epoch validation.
- **Ordered-log semantics when order matters (RC4):** if global order is required, use append-only logs with checkpoint consistency proofs (and witnesses in strict profiles) rather than implicit “everyone agrees” assumptions.
- **Receipt binding:** receipts/transcripts for cross-cluster-sensitive actions should include (or bind by digest) the active CH-CLUSTERMAP and CH-REPLCONTRACT digests so mismatched partitions/contracts are detectable.

**Evidence targets:**
- negative tests: missing/invalid CH-REPLCONTRACT causes deny-by-default on cross-cluster operations.
- split-brain simulation: divergent epochs/checkpoints must be detected (or operations must fail closed) under profiles that enable RC4/witnessing.
- routing tests: wrong-owner routing cannot succeed; owner mismatch is transcript-visible.
