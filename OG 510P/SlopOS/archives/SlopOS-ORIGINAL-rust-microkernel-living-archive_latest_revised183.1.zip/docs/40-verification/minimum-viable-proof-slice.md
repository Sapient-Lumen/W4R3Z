# Minimum viable A2 proof slice (MVP-A2)

Purpose: prevent scope explosion by defining the smallest slice that yields a meaningful A2 claim.

## Target slice (candidate)

- **Multicore kernel correctness (scoped)**: at least an **SMP profile** (D-CONC/D-MEMMODEL) with a mechanically justified concurrency story for the claimed kernel transitions (C-CONC-1).
- Capability integrity for core operations (C-CAP-1).
- Mapping discipline for domain/VM memory isolation (C-ISO-1).
- Well-formed state evolution for the above transitions (C-STATE-1).
- `unsafe` obligations confined to a minimal HAL + page-table/trap boundary (C-UNSAFE-1).

UP-only prototypes are acceptable for bring-up, but **UP-only proofs are not the intended flagship outcome** (see `docs/30-architecture/multicore-architecture-options.md`).

## Concurrency baseline (avoid a proof cliff)

We want multicore verification *early* without committing to the most complex scalable structure on day 0.
Recommended staged path:

1) **SMP-big-lock baseline**: a global kernel lock provides a sequentialization point for kernel critical sections, while still requiring multicore correctness of the lock/preemption/interrupt story.
   - Evidence precedent: REF-SEL4-BIGLOCK-APSYS15.

2) **SMP-refined baseline** (optional): introduce narrower critical sections / verified lock protocols when performance or scheduling structure demands it.
   - Evidence precedent: REF-SEL4-LOCK-VERIF-ARXIV24.

3) **Hybrid/multikernel evolution** (optional, if scale requires it): adopt explicit state ownership and topology-driven replication so we can scale across NUMA/many-core without retrofitting “hidden sharing” out of the design.
   - See: D-MK and `docs/30-architecture/multicore-architecture-options.md`.

Meta-constraint: even in a big-lock baseline, phrase invariants in terms of **ownership + explicit transfer** so that future sharding/replication can reuse safety arguments.

## Explicit exclusions (for MVP)

- DMA-aware isolation unless an IOMMU policy is in place (C-ISO-2 deferred or explicitly scoped).
- Side-channel claims (non-claim).
- Full device driver stack (outside TCB).

## Success criteria

- Abstract spec + invariants are stable for the slice.
- Machine-checked proof (or equivalent mechanized correctness argument) for the slice, including the declared SMP profile.
- Clear A-IDs for hardware/boot assumptions (A-HW-1 at minimum).
- Evidence recorded as EVID entries; decision recorded as ADR(s).



### Added constraint: commutativity evidence on the hot action surface (D-COMMUTE)

Because our long-term multicore posture is Hybrid, we want early evidence that the *interface* does not accidentally force global serialization.

Include in the MVP slice:
- the pinned hot action surface v0 annotated with conflict keys and commutation predicates (see `docs/30-architecture/hot-action-surface-v0.md`),
- generated commutativity tests (PO-COMMUTE-TEST),
- a fuzz seed that attempts to find order-dependence regressions (EVID-2026-119),
- and a microbench harness that measures the declared serialization points and makes contention visible (EVID-2026-120).
