# CLI plumbing tooling (make terminal workflows capability-safe)

Goal: prevent the terminal ecosystem from reintroducing ambient authority via paths, helper sockets, or ad-hoc IPC.

Baseline rule: **CLI tools talk to the workflow router** (D-PLUMB) using **CH-PLUMBMSG** envelopes (RFC-0117), and any authority acquisition happens via portals (RFC-0046).

## Design principles
- **Handles, not paths:** CLI verbs should accept `docref`/`sturdyref`/cap handles. If a human needs to pick a file, invoke the file chooser portal and receive a handle.
- **No ambient “open”:** avoid `PATH`-style helper discovery or global “default app” sockets. Routing is explicit (CH-ROUTE) and auditable.
- **Dry-run is normal:** every plumb action should support `--explain` to show the resolved route and the predicted authority diff (CH-CAPDIFF) before execution.
- **Wallet-aware:** when a wallet is present (CH-WALLET), attach `wallet_core_digest` so prompts/receipts/CI drift gates can key off stable authority.
- **Capmode-safe:** tools must operate correctly under D-SEAL/D-CAPMODE (no fallback to ambient namespaces).

## Recommended CLI verbs (v0)
These are the “xdg-open equivalents”, but capability-safe:
- `open <subject>`
  - subject: `docref:<id>` | `sref:<digest>` | `uri:<...>`
  - emits `intent.kind=open` or `open_uri`
- `save-as <subject> --format <fmt>`
  - emits `intent.kind=export` with explicit format bounds
- `share <subject> --to <target>`
  - routes through transfer portal (CH-XFER)
- `paste` / `copy` / `drag`
  - routes through transfer portal; never reads global clipboard state
- `print <subject>`
  - routes through print portal

Each verb is implemented as:
1) construct CH-PLUMBMSG
2) call `Workflow.Plumb.Send`
3) if mediation is required, the workflow router runs the portal session and emits receipts/transcripts

## Debugging + safety rails

### `plumb explain`
A non-effectful path that returns:
- matched CH-ROUTE rule (name + digest)
- whether mediation is required
- predicted `capdiff` (as a digest reference), when possible

Use cases:
- packaging checks: confirm a CLI tool does not silently widen authority
- CI gates: reject merges that widen wallet digests without an explicit approval

### “Safe-open” defaults
For `open` on quarantined/origin-tagged objects (D-QUAR), the CLI should default to:
- `intent.kind=open_untrusted` (disposable) unless explicitly overridden

## Plan 9 lineage without Plan 9 footguns
Plan 9 plumbing (REF-PLAN9-PLUMB) is the inspiration: send typed messages to a central router; rules decide dispatch.

Key adaptation for a capability OS:
- CH-PLUMBMSG is **non-authoritative** (no raw caps)
- all authority handoff is portalized and transcripted

## Integration with capshell
- Capshell scripts should emit CH-PLUMBMSG intents rather than invoking ambient helpers.
- Learn-mode can record “this script invoked open/share/print” as intents and then tighten contracts.
- When capshell executes external tools, it MUST bind execution context via **CH-EXECPACK v2** (which bundles **CH-REQCTX v1**, **CH-ARGV v0**, **CH-ENV v0**, **CH-CWD v0**, **CH-STDIO v0**, and **CH-FDSET v0** plus the bound **CH-EFFCON v0** effect contract).
  - No ambient PATH resolution, no ambient env inheritance, no ambient cwd inheritance, no ambient stdio/TTY inheritance, and no ambient inherited handle/FD tables.
  - Any authority acquisition happens only via portals (RFC-0046) and is receipt/transcript-visible.
- Strict profiles MUST NOT select an executable from a literal argv token or ambient PATH; the executable is chosen only from a CH-ARGV `desc` token with `role="exec"` bound to already-held authority.
- Strict profiles SHOULD require explicit `cwd.kind="empty"` (CH-CWD) and an empty CH-ENV by default, so legacy tools cannot accidentally pick up host namespaces.

References: RFC-0046, RFC-0115, RFC-0117.
