# Portal design playbook (D-PLUMB family)

Goal: keep portal workflows (open/save/share/net/device/location/clipboard/capture/etc.) **capability-pure**, **bounded**, and **auditable**, without turning portals into a hidden policy TCB.

This is an engineering checklist. It is not a kernel spec.

## 0) Portal invariants (non-negotiable)
1) **Handles, not paths**: a portal returns handles/caps (or sturdyrefs), never ambient paths or ambient endpoints.
2) **Default deny**: “no matching rule / no consent / no policy” must deterministically deny.
3) **No authority amplification**: a portal can only hand out authority it already has (or that was explicitly delegated to it). Prefer leases (D-LEASE) and attenuation.
4) **Transcriptability**: high-risk grants produce a bounded descriptor (CH-*) whose digest can be logged/receipted (D-EXPLAIN).
5) **Redaction-first**: descriptors must be redaction-safe by default (no payload bytes; avoid raw identifiers unless needed).

## 1) Treat portals as *usage-control* boundaries (UCON lens)
Many OSes treat permissions as a one-time yes/no. Real workflows need *ongoing* control:
- **Authorizations**: is this action allowed right now?
- **Conditions**: must the caller be foreground? on AC power? on a trusted network?
- **Obligations**: must we show an indicator, produce a receipt, or auto-expire the grant?
- **Continuity**: do we keep enforcing while the capability is in use?

We can model most of this **without new kernel mechanisms** by combining:
- **leases** (TTL/use bounds; explicit renewal),
- **portal session state** (foreground/background gating, indicators),
- **pinned descriptors** (CH-* lease/session descriptors + CH-RECEIPT/CH-CAPDIFF digests),
- **explicit revocation epochs** (where needed),
- and **policy bundles** (veto-only by default) for deterministic deny paths.

Refs: REF-UCON-ABC, REF-UCON-ABC-ACM.

## 2) Shape of a good portal API
### Requests
A portal request should be:
- **bounded** (no unbounded lists/strings; closed enums),
- **non-authoritative** (metadata is not authority),
- **idempotent where possible** (retries don’t mint new authority unless intended),
- **explicit about user intent** (volition binding when required).

### Grants
A portal grant should:
- return a **capability handle** (or a small set) with the *minimum* necessary rights,
- be **lease-based** by default (TTL/use bounds; close-to-revoke),
- surface a **cap-diff** digest (CH-CAPDIFF) and a **receipt** digest (CH-RECEIPT) for audit,
- make renewal/escalation explicit (fresh consent/volition if it widens authority).

### Denials
Denials should be:
- deterministic (closed enums for error causes),
- explainable (surface a redaction-safe reason category for UX),
- safe for replay (avoid time-sensitive text).

## 3) “Boring glue” is where sandboxes die
Treat these as first-class portal families (even if implemented later):
- open/save/document handles (D-POWERBOX adjunct)
- open-uri / “open with” routing
- clipboard / drag-drop / share (CH-XFER)
- printing
- network dial (CH-NETLEASE)
- device attach/hotplug (CH-DEVGUARD)

This prevents the ecosystem from inventing ambient helper sockets or global daemons.

## 4) Indicators and spoof-resistance
If a portal issues high-risk *continuous* authority (capture, location tracking, background execution, automation injection):
- require a **non-spoofable indicator** in strict profiles,
- prefer a **trusted UI path** (D-UICAP + D-VOLITION) for approvals,
- ensure a deterministic recovery path for “stuck” sessions.

## 5) Revocation, expiry, and “least surprise”
- Prefer **expiry-first** (leases) over global kill switches.
- Make revocation explicit and testable (epoch bump, lease close, or portal session end).
- Never silently “refresh” authority in the background.

## 6) Testing checklist (pressure tests)
Minimum negative tests for any new portal family:
- **No ambient bypass**: the same action fails without the portal-granted handle.
- **TTL/use bounds**: expiry and use exhaustion fail closed (I-LEASE-1).
- **Escalation**: widening authority requires a new consent/receipt path.
- **Redaction**: exporting transcripts/descriptors never reveals payload bytes or high-risk identifiers by default.
- **Replay sanity**: recorded/receipted decisions can be replayed deterministically within the declared boundary.

## 7) Implementation guidance (keep portals non-TCB)
- Keep the “policy engine” veto-only by default (D-POLICY) and treat it as replaceable.
- Keep the trusted slice small: validator + UI path (if any) + lease gate logic.
- Prefer interpretable descriptors and tiny validators over complex runtime code.

See also:
- RFC-0046 (workflow plumbing + portals)
- RFC-0031 (powerbox)
- RFC-0066 (leases)
- RFC-0115 (capability-safe automation as a portal client)
