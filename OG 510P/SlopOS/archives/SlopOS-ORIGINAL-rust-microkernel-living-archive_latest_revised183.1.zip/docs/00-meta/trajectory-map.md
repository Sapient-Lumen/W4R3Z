# Trajectory map (4 profile stacks + non-negotiables)

This doc records a *mile-high* synthesis of what we are building and the constraints we are choosing.
It is intentionally short: it exists to reduce “local optimum” design drift.

## Non-negotiables (current intent)

1) **One core substrate, four profile stacks** (no forked OSes):
- **Workstation/developer OS** (human-usable daily driver)
- **Cloud substrate / microVM host** (fleet-managed isolation boundary)
- **Embedded / separation-kernel-ish deployments** (small TCB, narrow surface)
- **Agent/automation OS** (LLM-first workflows; auditable actions)

2) **Compatibility is always sealed**: POSIX/legacy environments are treated as **foreign cells** behind an explicit, fail-closed membrane. We may host them for bootstrap and compatibility, but we do not accept their ambient authority model as a system design constraint.

3) **Multicore verification is required**: we do not plan a “single-core-only proof” as our flagship outcome. UP-only prototypes may exist for bring-up, but they are not the verification end state.

4) **Interface-first scalability discipline**: prefer action surfaces whose common-case operations **commute** (D-COMMUTE), so we can scale by sharding/replication and keep global serialization explicit and rare.
   - Composes with Hybrid multicore (D-MK) and keeps the four profile stacks aligned.

5) **LLMs are first-class developers and users** (humans still matter): the stable product surface must be machine-consumable (schemas + validators + receipts), and all high-risk actions must remain deterministic and reviewable.

## What we are (one sentence)

A capability OS whose core product is **explicit, auditable, and enforceable authority** across humans *and* agents, with legacy runtimes hosted only as sealed foreign cells.

## One substrate, four profile stacks

We preserve all four trajectories by keeping the privileged core stable and treating “the rest” as composable stacks.

### Shared substrate (always)
- Capability-mediated resources + IPC + mapping discipline (D-CAP/D-KABI).
- **Portals + receipts** for high-risk authority changes (D-PLUMB/D-VOLITION/D-EXPLAIN).
- A closed, schema-pinned **intent envelope** for workflow glue (CH-PLUMBMSG) and capability-safe automation (D-CAPSHELL/D-WALLET).
- Deterministic validator semantics (“propose → validate → authorize → execute → log”) for both humans and LLMs (docs/70-llm-control).
- A sealed-compat membrane for foreign cells (D-FCELL + I-COMPAT-1, I-COMPAT-2, I-FCELL-1).

### Workstation profile
Goal: make least-privilege usable.
- Rich portals (open/share/print/screenshot/input/capture/net) with usage-control framing.
- First-class CLI plumbing so terminal workflows do not reintroduce ambient authority (D-PLUMB).

### Cloud substrate profile
Goal: measurable isolation + operability.
- MicroVM profile (D-MICROVM), fleet-friendly provenance/boot binding (CH-BOOT/CH-PROV), optional CC annex (D-CC).
- Ops surfaces are capability-mediated services, not ambient daemons.

### Embedded / separation profile
Goal: narrow surface + static composition.
- Static CH-INIT/CH-COMP instantiation, small exit surface budget.
- Profile gates to disable dynamic code, broad I/O, rich portals (D-SEAL/D-DYNCODE/D-DRVDOM).

### Agent/automation profile
Goal: action safety at scale.
- Capshell + wallets + drift gates as first-class workflow tooling (D-CAPSHELL/D-WALLET).
- Receipts/transcripts are default outputs; replay/diff is expected (D-RR).

## Profile compatibility contract (design constraints)

These constraints exist to prevent “silent divergence” between profiles:

- **Core primitives must serve ≥2 profiles** or be explicitly profile-scoped.
- **No ambient “escape hatches”**: if humans can do it, agents can propose it, and validators must enforce it.
- **Legacy/POSIX is never policy-authoritative**: it is always a foreign cell.
- **Authority must be legible**: every grant or widening has a diff/receipt path (D-EXPLAIN) and can be gated in CI (authority drift gates).
- **Multicore is not an afterthought**: concurrency choices must be compatible with the verification strategy from day 0.

## Proof-bearing slice (candidate)

We should pursue a small end-to-end slice that exercises the non-negotiables:

- Multicore kernel core (at least an SMP profile) + explicit memory model scope (D-CONC/D-MEMMODEL).
- One portal workflow (e.g., `portal.uri.*` or `portal.net.*`) with receipts (CH-RECEIPT) and authority diffs (CH-CAPDIFF).
- One capshell flow (learn → tighten → drift-gate) that uses a wallet digest.
- One foreign POSIX cell demonstrating “attempted escape” failing closed.

See: `docs/40-verification/minimum-viable-proof-slice.md` and `docs/30-architecture/multicore-architecture-options.md`.

## Open questions (tracked as decision surfaces)

- **Hybrid follow-ups (ADR-0005)**: keep CH-CLUSTERMAP stable while tightening topology facts only as needed; keep cross-cluster replication contracts bounded and decide which object families require RC4 ordered semantics vs RC3 commutative semantics; clarify scale target and NUMA posture for Phase 1 vs later.
- **D-FCELL**: pin the compatibility *membrane* contract for foreign cells (fail-closed; portalized; policy-killable).
- **D-RUMPK**: select the legacy/POSIX runtime strategy *inside* the foreign cell (rump/LKL/userspace kernel/library-OS) for bootstrap and/or compatibility.
- **D-UICAP / portals**: how much trusted UI is required for workstation-level workflows.
- **D-ATTN attention leases**: D-ATTN now treats notifications as a portal family (`portal.attn.*`, CH-NOTIF). Open question: do we need a first-class “attention lease” descriptor for urgent/critical alerts (or can we reuse existing lease patterns), and how should it bind to CH-VOL/CH-AUTHZ and `cfg.params.lane.portal.attn` fail-closed semantics?
- **Portal lane defaults (D-PLUMB)**: v0 recommended A–D defaults for `cfg.params.lane.*` keys are now pinned (non-authoritatively) in `docs/30-architecture/profile-lane-defaults.md` as a stable diff surface. Remaining question: whether to later encode these defaults as machine-checked CH-CFG templates (still veto-only) or keep them as guidance consumed by policy-bundle tooling.
- **Conflict key derivation hygiene (D-COMMUTE follow-up):** v0 now pins canonical family vocabulary and derivation for the digest-valued `*_key` payload fields used by hot actions and ACP seams via `conflict-key-derivation-registry.md` (and keeps CH-ORDERTOK `scope.family` on the same closed family vocabulary). Remaining follow-up: decide where to pin the canonical encoding for each profile’s typed ids (`as_id`, `endpoint_id`, `view_id`, `log_id`, `meter_id`, `budget_id`) so `ck_id(..)` inputs remain deterministic and closed-world without bloating core schemas.
- **CH-EXECPACK replay-safety follow-up (D-CAPSHELL / D-RETRYSAFE):** request-context binding is pinned (CH-EXECPACK v2 carries `reqctx_digest = digest(CH-REQCTX v1)` and validators require coherence with CH-ACP `meta.reqctx_digest`). CH-EXECPACK v2 also supports an optional non-authoritative intent envelope (`plumbmsg_digest = digest(CH-PLUMBMSG v0)`) that strict profiles may require to keep workflow intent explicit. D-RETRYSAFE treats CH-EFFCON `contract_id` as the canonical idempotency key for `capshell.exec` duplicate suppression. Remaining question: pin the minimal *output* normal form needed to make at-least-once-safe execution practical (content-addressed outputs + deterministic “already done” outcomes) without introducing a new nonce field in early schemas.
- **CH-REQCTX budget reference typing (D-BUDGET follow-up):** CH-REQCTX v1 `budget_desc_digests` is an untyped digest list. We now allow profiles to require that `capshell.exec` binds at least one digest that resolves/validates as CH-BUDGET v0 when metering is enabled (no implicit sponsorship). Open question: introduce a future CH-REQCTX revision with typed `{schema,digest}` budget refs (and/or separate lease vs meter lists) to make budget policy checks local and remove resolver ambiguity without bloating early schemas.
