# Claim registry (C-IDs)

Claims are explicit, scoped, and paired with assumptions (A-IDs) + deployment profiles (P0–P2) + evidence. Maturity: A0–A3 (see `assurance-claims.md`).

## Authority / capabilities
- **C-CAP-1 (Capability integrity)**: no operation grants authority absent an explicit capability derivation chain, under A-HW-1. Evidence: (target) E3 refinement for cap ops.

## Isolation
- **C-ISO-1 (Spatial isolation)**: domains/VMs cannot read/write each other absent explicit sharing objects, under A-HW-1 + mapping invariants.
- **C-ISO-2 (DMA-aware isolation)**: C-ISO-1 extends to DMA *only if* A-DMA-1 holds with IOMMU enforcement (or devices in TCB, explicitly weakening claim).

## State evolution
- **C-STATE-1 (Well-formed transitions)**: every privileged transition preserves object well-formedness + authority/mapping invariants.

## Boot / provenance
- **C-BOOT-1 (Boot integrity profile)**: system boots only/attests to approved artifacts, resists rollback per policy, under A-BOOT-1. (Schemas: CH-BOOT v0 / CH-CFG v0; see `docs/30-architecture/boot-manifest-schema-v0.md` and `docs/30-architecture/config-schema-v0.md`.)
- **C-ATTEST-1 (Remote boot attestation, optional)**: if D-ATTEST is enabled, a remote verifier can validate a signed CH-ATTEST bound to the active CH-BOOT digest (and optional provenance digest), under A-ATTEST-1 (and A-ATTEST-2 if freshness is claimed).

## Unsafe obligations
- **C-UNSAFE-1 (Unsafe confinement)**: all `unsafe` in core is isolated to listed modules, with documented pre/postconditions linked to invariants.

## Concurrency (staged)
- **C-CONC-1 (Concurrency safety, scoped)**: for the declared concurrency model (D-CONC/D-MEMMODEL), critical invariants are preserved under allowed interleavings; no liveness claims unless explicitly stated.

## LLM-assisted operations (scoped)
- **C-LLM-1 (Non-authoritative proposals)**: untrusted text/model outputs cannot directly cause privileged effects; only deterministic validation + explicit authorization can (under A-TOOL-1 for toolchain trust assumptions).

## Supply chain / reproducibility
- **C-PROV-1 (Provenance + reproducibility, scoped)**: trusted release artifacts are reproducible and carry signed provenance attestations under A-BOOT-1/A-TOOL-1; rollback policy is enforced if claimed.
- **C-PROV-2 (End-to-end proof-carrying provenance, aspirational)**: for the chosen D-PCP scope, the running image is attestably linked to source + build recipe + selected proof/model-check artifacts, under A-BOOT-1/A-TOOL-1. (Binding hook: CH-BOOT `prov_attestation_digest`; see PO-PROV-BIND.)

## Information flow (optional)
- **C-IFC-1 (Scoped information-flow, optional)**: under a declared D-IFC observation/channel model, labeled objects/channels enforce the chosen flow policy (no unauthorized flow) for the scoped subset only; side channels remain non-claims unless explicitly modeled.

## Observation / audit (scoped)
- **C-OBS-1 (Redacted observations, scoped)**: privileged observation export (IF-OBS) leaks no secrets except those explicitly authorized, under A-HW-1 and the redaction policy. (Schema: CH-OBS v0; see `docs/30-architecture/observation-schema-v0.md`.)

## Time / expiry (scoped)
- **C-TIME-1 (Monotonic expiry enforcement, conditional)**: if time-based security policies (expiry/anti-rollback) are enabled, checks use a monotonic source per A-BOOT-2 and are enforced at the point of effect.

## Interface/ABI (scoped)
- **C-ABI-1 (Total, fail-closed privileged ABI)**: privileged dispatch/decoding is total over the declared input space; unknown or malformed inputs reject deterministically without side effects beyond explicit error signaling.

## Drivers / device handling (scoped)
- **C-DRV-1 (Device logic outside core, conditional)**: where possible, device-specific logic runs outside the privileged core; the core exposes minimal, policy-checked primitives and treats devices/DMAs per D-DMA and A-DMA-1.

## Hypervisor-first properties (conditional)
- **C-HV-1 (Closed exit handling, conditional)**: for a hypervisor-first architecture, VM-exit handling is a closed, explicitly enumerated action set with fail-closed decoding and no hidden emulation paths beyond those declared. (Schema: CH-KABI v0; see `docs/30-architecture/kabi-action-schema-v0.md`.)
