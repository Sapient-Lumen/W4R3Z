# Non-claims (canonical exclusions)

Purpose: freeze what we are **not** claiming by default so scope cannot silently drift.
Rule: if we want to claim one of these, we must add a new C-ID, invariants/POs, evidence, and an ADR that scopes the model.

## Default non-claims (until explicitly promoted)
### Side channels / covert channels
- No blanket resistance to cache/timing/speculation/power/EM/acoustic side channels.
- No claim that shared microarchitectural state cannot create covert channels.
See: `docs/10-threat-model/sidechannels.md`.

### Availability / liveness / real-time
- No guarantee of progress, fairness, starvation freedom, bounded latency, or DoS resistance.
- “Correctness” does not imply “always responsive.”
If we later care: add an explicit liveness model and a C-ID for it.

### Physical / fault injection / malicious hardware
- No protection against fault injection, invasive physical attacks, or malicious hardware/firmware beyond stated A-IDs.
- No assumption of tamper resistance unless an ADR adds it and updates <A-OPS-*>.

### Malicious peripherals (without explicit mediation)
- If A-DMA-1 is not satisfied, we do not claim DMA-safe isolation; devices become part of effective TCB for isolation claims.

### Toolchain / solver soundness
- We do not claim absolute correctness of compilers/solvers/proof assistants.
We record trust assumptions as A-TOOL-1 and mitigate with replay/diverse checking where feasible.

### “LLM correctness”
- We do not claim the model outputs are correct, safe, or policy-compliant.
What we *may* claim (C-LLM-1): untrusted text cannot directly create privileged effects because IF-ACP is deterministic and authorization-bound.

### Complete provenance beyond declared artifact set
- We do not claim “the whole universe is reproducible.”
C-PROV-1 is scoped to the declared artifacts and build inputs in `docs/60-engineering/supply-chain-repro.md`.

## Promotion checklist (when adding a new claim)
1) Update threat model + abuse cases; add/adjust A-IDs.
2) Add a C-ID; link to I-IDs and PO-IDs; add EVID plan.
3) Add an ADR describing scope, model, and acceptance criteria.
