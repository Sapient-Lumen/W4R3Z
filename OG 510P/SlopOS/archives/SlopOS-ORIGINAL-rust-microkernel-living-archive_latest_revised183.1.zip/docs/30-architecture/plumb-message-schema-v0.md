# CH-PLUMBMSG v0: Workflow intent message envelope (schema)

Purpose: pin a deterministic, auditable, **non-authoritative** envelope for cross-application workflow “plumbing” messages (D-PLUMB).

CH-PLUMBMSG is a *workflow router input*, not an authority token:
- it MUST NOT contain raw capabilities or bearer secrets (I-PLUMB-3),
- it is a routing/UX hint only (never authorization evidence),
- any authority transfer occurs only via explicit portals/sessions/receipts.

References: RFC-0046, RFC-0117, REF-PLAN9-PLUMB, REF-XDG-PORTAL.

## Encoding
Candidate baseline: canonical CBOR (D-ENC), optionally wrapped with COSE for signatures.
Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Design constraints (v0)
- Deterministic parsing + rejection on unknown keys/variants (fail closed).
- Bounded sizes and closed enums to prevent router/port DoS.
- `intent.kind` is a **closed-world** vocabulary pinned *only* in `docs/30-architecture/intent-kind-registry.md` (I-INTENTKIND-1; PO-INTENTKIND-CLOSE).
- Digest-only references: attachments/subjects are digests or stable handles, never bearer capability material.

## Data model (conceptual)

CH-PLUMBMSG v0 := {
  v: 0,

  msg_id: bstr,                 ; opaque identifier (random or derived), for correlation
  issued_at?: uint,             ; optional (profile-defined)

  src: {
    component_id: bstr,         ; derived from runtime identity (CH-COMP), not trusted from sender strings
    instance_id?: bstr
  },

  dst_port?: tstr,              ; optional port name; if absent, routing rules choose

  intent: {
    kind: tstr,                 ; closed enum (canonical list in intent-kind-registry.md)
    subject: Subject,
    constraints?: { * tstr => tstr }  ; bounded, closed keys (profile-defined)
  },

  tags?: [* tstr],              ; bounded list of short strings (mime-like/purpose-like)
  attrs?: { * tstr => tstr },   ; bounded small-string map for hints only

  wallet_core_digest?: bstr,    ; digest(CH-WALLET v0) core (optional; correlation only)
  receipt_hint?: {
    want_receipt: bool,
    sensitivity: tstr           ; closed enum (profile-defined; ties to CH-OBSPOL tiers)
  },

  attachments?: [* Attachment]  ; bounded
}

Subject := {
  kind: tstr,                   ; closed enum: "none" | "docref" | "sturdyref" | "uri" | "xfer" | "capture"
  docref_id?: tstr,             ; stable handle id (resolved via doc portal)
  sturdyref_digest?: bstr,      ; digest(CH-SREF v0)
  uri?: tstr,                   ; bounded; only for intent.kind == "open_uri"
  xfer_digest?: bstr,           ; digest(CH-XFER v0)
  capture_digest?: bstr         ; digest(CH-CAPTURE v0)
}

Attachment := {
  kind: tstr,                   ; closed enum: "aref" | "capdiff" | "receipt" | "wallet"
  schema?: tstr,                ; optional schema tag for the digest (preferred)
  digest: bstr
}

## Bounds (v0 seed; profiles may narrow)
These bounds exist to keep plumbing surfaces non-ambient and DoS-resistant:
- `tags`: ≤ 16 entries; each entry ≤ 32 bytes.
- `attrs`: ≤ 16 pairs; keys ≤ 24 bytes; values ≤ 96 bytes.
- `attachments`: ≤ 16 entries.
- `dst_port`: ≤ 64 bytes.
- `subject.uri`: ≤ 256 bytes.

## Validation rules (minimum)
A CH-PLUMBMSG validator MUST be total and fail closed (PO-PLUMBMSG-VALIDATE):
1) `v == 0` and required fields present.
2) Unknown keys reject (or are rejected by canonical decode).
3) `intent.kind` MUST be allowlisted by `docs/30-architecture/intent-kind-registry.md` (unknown kinds reject).
4) `Subject.kind` selects exactly one subject form; mismatched/extra fields reject.
5) `Attachment.kind` is allowlisted and `digest` length matches the profile hash; unknown attachment kinds reject.
6) Bounds are enforced deterministically (tags/attrs/attachments/strings).
7) Non-authoritative constraint: the validator MUST NOT treat CH-PLUMBMSG as approval/authorization evidence.

## Security notes
- CH-PLUMBMSG is **non-authoritative**: it can request and describe workflows but cannot grant authority.
- Avoid embedding ambient-authority surrogates (raw paths, ambient env keys, implicit DNS names) in `attrs` or `tags`.
- If a workflow needs rich metadata, carry it in a separate pinned CH-* descriptor and reference it by digest.
- Any portal completion that can increase authority should be gated by capgraph diff + explicit consent receipts (PO-PLUMB-NOAMP).
