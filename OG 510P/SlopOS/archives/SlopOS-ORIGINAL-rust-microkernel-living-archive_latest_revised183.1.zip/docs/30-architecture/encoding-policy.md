# Encoding policy (D-ENC / D-UPD-SIGN; candidate baseline)

Purpose: keep CH-* schemas hashable/signable with deterministic decoding, without inventing bespoke formats.

Non-goal: commit to a specific crypto suite (that is D-UPD-SIGN + later ADRs).

## Candidate baseline
- **Payload encoding:** canonical CBOR (REF-CBOR-RFC8949)
- **Signed container:** COSE envelopes (REF-COSE-RFC9052) for signatures/MACs over canonical payload bytes

Authoring note (optional): tooling MAY accept JSON input for human-authored artifacts, but it must be canonicalized using JCS (REF-JCS-RFC8785) and deterministically transcoded to canonical CBOR before hashing/signing. Signed/wire forms are always CBOR+COSE.

## Requirements (must hold regardless of format)
- total parsing, fail closed (PO-ENC-DECODE)
- canonical bytes are well-defined for hashing/signing (I-ENC-1)
- version pinning: schema version is inside the signed bytes

## Where it applies first
- CH-CFG v0 (IF-CFG / IF-BOOT)
- CH-BOOT v0 (IF-BOOT)
- CH-ACP v0 + CH-LOG v0 (IF-ACP)
- CH-CAPX v0 (optional; delegation envelope for user-space cap gateways)

## Evidence plan (keep it small)
- E1: property tests on decoders: non-canonical encodings reject; canonical round-trip stable
- E2: bounded model check of decoder totality for a minimal CH (e.g., CH-ACP or CH-KABI)
