# CH-KEYPOL v0: Key usage policy descriptor

Purpose: a redaction-safe description of **how a key may be used** (D-CRYPTOSVC).  
This schema carries **no private key material**; it exists to make key usage reviewable, lintable, and enforceable.

Refs: REF-PLAN9-FACTOTUM, REF-OPENSSH-AGENTRESTRICT.

## Encoding
Candidate baseline: canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-KEYPOL v0 := {
  v: 0,

  ; allowed operation kinds (closed enum)
  ops: [ tstr ],                ; e.g., ["sign", "decrypt", "derive", "attest"]

  ; purpose/context tags to prevent “signing-oracle” cross-protocol misuse
  ; (clients must supply exactly one context string on each operation)
  contexts?: [ tstr ],          ; e.g., ["ssh", "update-signing", "tlog-anchor", "oauth-dpop"]

  ; optional hints/policies enforced by the provider (user space)
  confirm?: bool,               ; if true, require explicit approval/UI for each op (like ssh-agent -c)
  rate?: {
    max_per_min?: uint,         ; bounded
    burst?: uint,               ; bounded
  },

  ; optional time/epoch binding (explicit clock kind; see D-NONDET)
  ; used for “only valid after T” / “expires at deadline”
  time_bounds?: {
    mode: tstr,                 ; "none" | "not_before" | "not_after" | "window"
    clock_kind?: tstr,          ; "monotonic_coarse" | "realtime_coarse" | "logical"
    not_before?: uint,
    not_after?: uint,
  },

  ; algorithm family hints (non-authoritative unless enforced)
  alg?: tstr,                   ; e.g., "ed25519" | "p256" | "rsa3072" | "x25519" | "aes-gcm-256"

  ; optional audit classification
  class?: tstr,                 ; e.g., "user_auth", "device_attest", "release_signing"

  ; free-form policy notes (non-authoritative)
  note?: tstr,
}

## Validation notes
- `ops` MUST be non-empty and use the closed enum.
- If `contexts` is present, it MUST be non-empty and bounded length.
- Providers MUST fail closed if a requested op/context is not permitted (I-CRYPTO-2).
