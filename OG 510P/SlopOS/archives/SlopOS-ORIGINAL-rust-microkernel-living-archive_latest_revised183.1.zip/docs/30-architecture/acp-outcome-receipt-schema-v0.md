# CH-ACPOUT v0: ACP outcome receipt (schema)

Purpose: record a **non-authoritative**, redaction-safe receipt for an ACP validator outcome.

This receipt is distinct from:
- **CH-LOG v0** (transcript entries): compact replay/audit binding for `validate` (I-LOG-1).
- **CH-DENY v0** (denial receipts): structured, deterministic reject classification (deny_code + bounded reason).
- **CH-RECEIPT v0** (consent receipts): binds what was shown + approval evidence (consent/UI path).

CH-ACPOUT provides a stable, schema-pinned *result envelope* for tooling:
- binds `action_digest` (digest of canonical CH-ACP bytes),
- carries D-COMMUTE observability metadata (`conflict_key_digest`, `order_digest`) when applicable,
- and optionally references other emitted receipts by digest.

Design constraints:
- MUST NOT contain raw capability material, bearer secrets, or ambient-authority surrogates (paths/env/implicit network names).
- MUST be mechanically checkable and stable for audits and LLM tooling.
- MUST be safe to store/export under CH-OBSPOL redaction tiers (digests/keys only).

## Encoding
Candidate baseline: canonical CBOR (D-ENC), optionally wrapped with COSE for signatures.
Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-ACPOUT v0 := {
  v: 0,

  out_id: bstr,                 ; random 128-bit (or more) identifier, for local indexing
  issued_at?: uint,             ; optional monotonic or wall-clock (profile-defined)

  ; what was evaluated
  action_schema: tstr,          ; "CH-ACP v0" (v0); future-proofed for other action schemas
  action_digest: bstr,          ; digest of canonical bytes of the action value
  reqctx_digest: bstr,          ; digest(CH-REQCTX v1) (non-authoritative correlation + veto-only context)
  kind: tstr,                   ; action kind name (e.g., "capshell.exec")

  ; outcome classification (closed)
  outcome: tstr,                ; "accept" | "reject" | "error"

  ; optional effect classification (non-authoritative; helps make retries/no-ops auditable)
  effect?: tstr,                ; "applied" | "no_op" | "duplicate_suppressed" (only meaningful when outcome="accept")

  ; optional commutativity/ordering observability (non-authoritative)
  conflict_key_digest?: bstr,   ; digest(CH-CONFLICTKEY v0) when derivable (D-COMMUTE)
  order_digest?: bstr,          ; digest(CH-ORDERTOK v0) when present/required (D-COMMUTE)

  ; structured denial linkage (non-authoritative)
  deny_digest?: bstr,           ; digest(CH-DENY v0) when `outcome == "reject"` and a denial receipt was emitted

  ; optional references to other receipts emitted during the outcome path
  ; (digests only; schemas are identifiers from the schema registry).
  receipt_refs?: [ * {
    schema: tstr,               ; e.g., "CH-RECEIPT v0" | "CH-FADAPT v0" | "CH-BUDGET v0" (digest-only reference)
    digest: bstr
  } ],

  ; bounded, profile-defined metadata (ignored unless allowlisted)
  meta?: { * tstr => any }
}

### Outcome values (v0; closed)

`outcome` MUST be one of:
- `accept`
- `reject`
- `error`

Decoders MUST reject unknown values (fail closed).


### Effect status values (v0; closed, optional)

If `effect` is present, it MUST be one of:
- `applied` (a privileged effect was performed)
- `no_op` (the action was accepted but produced no state change; e.g., idempotent detach of an already-detached binding)
- `duplicate_suppressed` (the action was accepted but an equivalent prior accepted action with the same schema-pinned dedupe key was detected; no duplicate effect was performed)

Notes:
- `effect` is **non-authoritative** metadata. It MUST NOT be treated as authorization evidence.
- Producers SHOULD omit `effect` for `reject`/`error` outcomes.
- Consumers MUST treat a missing `effect` on `accept` as `applied` (for backward compatibility).

## Validation rules (minimum)
Decoders and validators MUST be total and fail closed:
1) `v == 0` and required fields are present.
2) `action_schema` is allowlisted (v0: must equal `"CH-ACP v0"`).
3) `action_digest` and `reqctx_digest` lengths match the profile hash.
4) `outcome` is one of the closed values above.
5) If `effect` is present, it MUST be one of the closed values in **Effect status values** above.

6) If `conflict_key_digest`/`order_digest`/`deny_digest` are present, they MUST match profile digest length.
7) If `receipt_refs` is present, each element MUST include `{schema,digest}` and `digest` MUST match profile digest length.

Producer rules (ACP-focused, normative):
- IF-ACP validators SHOULD emit CH-ACPOUT for **every** `Accept/Reject` decision on CH-ACP actions.
- Producers MUST include `reqctx_digest` matching the evaluated action’s `meta.reqctx_digest` (PO-ACT-REQCTX).
- If the action kind has a declared conflict key family (per `acp-action-kind-registry.md`), producers SHOULD include `conflict_key_digest`.
- If the action kind is **ordered**, producers MUST include `order_digest` and SHOULD include `conflict_key_digest`.
- For deterministic rejections where CH-DENY is emitted, producers SHOULD set `deny_digest = digest(CH-DENY v0)`.
- Producers SHOULD include `receipt_refs` only for **non-secret** receipts that are already safe to reference by digest (digests/keys only).
- For kinds whose retry-safety declares **at-least-once-safe** (D-RETRYSAFE), when a proposal is accepted but deduped, producers SHOULD set `effect = "duplicate_suppressed"` and SHOULD include a `receipt_refs` entry pointing at the prior relevant receipt/outcome digest (when safe) so tooling can correlate retries deterministically.
- When an accept path performs no state change due to idempotent semantics, producers MAY set `effect = "no_op"` (optional; profile-gated).


## Security notes
- **Non-authoritative rule**: no validator, executor, or UI may treat CH-ACPOUT as authorization evidence.
  - Authorization binds via explicit approvals/capabilities (e.g., CH-AUTHZ), never via receipts.
- Prefer digests over values. If a consumer needs detail, it must obtain it via authorized portals/capabilities, not by replaying receipts.