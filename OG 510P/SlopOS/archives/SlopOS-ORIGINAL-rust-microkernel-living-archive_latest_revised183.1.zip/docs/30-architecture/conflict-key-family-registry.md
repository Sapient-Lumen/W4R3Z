# Conflict key family registry (v0 seed)

This registry is the **canonical allowlist** for `CH-CONFLICTKEY v0 family` strings.

- The family set is **closed-world**: validators MUST reject unknown families (I-CONFLICTKEY-1; PO-CONFLICTKEY-VALIDATE).
- Families are **non-authoritative** metadata used for D-COMMUTE reasoning, CH-ORDERTOK scoping, receipts, and Hybrid routing.
- Adding a new family requires an RFC + updates to:
  - this registry,
  - `conflict-key-schema-v0.md` (payload definition), and
  - at least one evidence hook (new tests/harness plan).

## Families (v0)

| family | Payload definition | Primary use surfaces | Notes |
|---|---|---|---|
| `mem.range` | `conflict-key-schema-v0.md` §1 | `hot-action-boundaries-v0.md` (mem.map/unmap/protect) | range identity within an address space |
| `ipc.endpoint` | `conflict-key-schema-v0.md` §2 | `hot-action-boundaries-v0.md` (ipc.send/recv/close) | endpoint identity |
| `view.slot` | `conflict-key-schema-v0.md` §3 | `hot-action-boundaries-v0.md` (view.bind/unbind) | slot identity within a view |
| `log.eventset` | `conflict-key-schema-v0.md` §4 | `hot-action-boundaries-v0.md` (log.append/rotate) | event-set identity (bounded log key) |
| `budget.issuer` | `conflict-key-schema-v0.md` §5 | `hot-action-boundaries-v0.md` (budget.mint/revoke) | issuer/meter identity |
| `budget.lease` | `conflict-key-schema-v0.md` §6 | `hot-action-boundaries-v0.md` (budget.spend) | lease identity |
| `policy.param` | `conflict-key-schema-v0.md` §7 | ACP kinds that mutate policy/config | exact `cfg.params.*` key string; no aliasing |
| `domain.id` | `conflict-key-schema-v0.md` §8 | ACP kinds scoped to a domain | avoids double-hash for digest-sized domain ids |
| `cell.id` | `conflict-key-schema-v0.md` §9 | sealed compat receipts (CH-FCELL/CH-FADAPT) | foreign-cell identity (opaque) |
| `cell.adapter` | `conflict-key-schema-v0.md` §10 | sealed compat adapter receipts | binds adapter ops to `(cell_id, portal_token)` |

## Wiring requirements

- `docs/README.md` MUST link this registry.
- `conflict-key-schema-v0.md` MUST reference this registry as the canonical family list.
- CI MUST fail if any `family="..."` reference uses a family not listed here.
- `ordering-token-schema-v0.md` MUST treat `scope.family` as using this same closed family vocabulary (no shadow allowlists).
