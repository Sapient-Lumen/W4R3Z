# Cross-cluster replication & consistency contracts (v0)

Hybrid multicore (ADR-0005) assumes **explicit cross-cluster ownership** rather than accidental shared state.
This doc pins the **v0 contract vocabulary** for cross-cluster metadata so that:
- we can state (and later verify) what must be single-owner vs replicated,
- we avoid reintroducing an ambient “global kernel” via hidden coordination,
- and we keep authority non-amplifying when state is copied/merged across clusters.

**Status:** v0 contract vocabulary + CH-REPLCONTRACT v0 seam. This is intentionally conservative.

## Non-negotiable posture

- **Replication is non-authoritative.** Replicated artifacts must not grant authority; at most they can *describe* state (or support deny-only routing/policy).
- **Capabilities are local.** Raw kernel capabilities/handles are not “replicated.” Cross-cluster access is via explicit gateways/proxies/portals (e.g., CapRPC), not by copying bearer handles.
- **Fail closed.** If the replication contract is missing/invalid for a profile, cross-cluster operations that depend on it must deny/stop rather than guess.

## What we need from a replication contract

For each object family that can be observed or used across clusters, we want to write down:
- **owner model**: who is allowed to mutate authoritative state (one cluster? a set?)
- **replication class**: how replicas are updated/merged (if at all)
- **coordination requirement**: whether order is part of the spec (D-COMMUTE + hot-action boundaries)
- **evidence hooks**: what tests/proofs we need to prevent accidental order dependence or authority amplification

We pin this as an explicit artifact seam: **CH-REPLCONTRACT v0**.

## Replication classes (RC-v0)

These are *contract classes*, not implementation mandates. Implementations MAY be stricter than required, but must not be weaker.

- **RC0 Local-only**
  - State is meaningful only within one cluster.
  - Cross-cluster references must be via a proxy object that is itself explicitly routed.

- **RC1 Owner-sharded (single-writer)**
  - Each object instance has exactly one **owner cluster**.
  - Other clusters may cache read-only summaries (bounded, epoch-tagged), but updates are routed to the owner.

- **RC2 Epoch snapshots (replace-with-epoch)**
  - The owner periodically publishes a bounded snapshot with a monotonic **epoch**.
  - Replicas accept only non-decreasing epochs; merges are `max(epoch)` with replace semantics.
  - Suitable for read-mostly metadata where “latest wins” is acceptable.

- **RC3 Commutative merge (SEC-style)**
  - Replicas can accept updates locally and merge without coordination because updates are designed to commute/merge safely.
  - Use only for *bounded* metadata with explicit monotonic/merge semantics (CRDT-like patterns; REF-CRDT-INRIA11).

- **RC4 Ordered log (append-only, consistency-checkable)**
  - Global order is required by the spec (non-commutative by definition).
  - Express this as an **append-only log** with signed checkpoints / consistency proofs when enabled (REF-CT-RFC6962).
  - Prefer moving “order-required” semantics to an ordered log rather than smearing ordering constraints across many objects.

## Default stance for the v0 hot action surface

This does **not** expand the hot surface; it states how cross-cluster concerns should be handled for the already-pinned families:

- **mem.map / mem.unmap**
  - Default: **RC0 local-only** per address-space home cluster.
  - If a profile allows cross-cluster shared regions, it must be explicit (D-IOBUF) and use owner-sharded metadata; the mapping primitive itself remains local.

- **ipc.* endpoint operations**
  - Endpoints are **RC0 local-only**.
  - Cross-cluster calls are via capability-RPC/proxies; any ordering requirements live in the proxy protocol contract (CH-CONTRACT) and are transcript-visible.

- **view.attach / view.detach**
  - Default: **RC1 owner-sharded** per `view_id`.
  - Read-only view summaries may be cached with epochs (RC2) but authoritative attach/detach is routed to the owner cluster.

- **transcript/receipt append**
  - Default: **RC3 commutative merge**: transcripts are treated as a content-addressed event set; append is commutative and export order is canonicalized.
  - If a profile needs strict “timeline order,” it must use RC4 ordered log semantics explicitly.

- **quota/budget charge**
  - Default: **RC3 commutative merge** for charges (additive, bounded), but **mint/revoke** is **RC1 owner-sharded** (non-commutative boundary lives with the owner).

These defaults are intended to keep global order rare and explicit.

## Evidence hooks (v0)

- **PO-REPLCONTRACT-VALIDATE**: CH-REPLCONTRACT decode is total/bounded/closed-enum; owner cluster ids are valid under CH-CLUSTERMAP.
- **PO-REPL-NOAMP**: replication artifacts cannot grant authority (they may only narrow/deny or describe).
- **PO-REPL-MERGE**: for RC3 objects, merge/apply is commutative/associative/idempotent (bounded domains), and is compatible with D-COMMUTE tests.

See also: `commutativity-and-interface-scalability.md`, `hot-action-boundaries-v0.md`, and `cluster-derivation.md`.
