# Intent kind registry (workflow `intent.kind` taxonomy)

Purpose: provide a **single canonical** closed-world set of `intent.kind` values used by workflow plumbing (D-PLUMB), including:
- CH-PLUMBMSG v0 (`plumb-message-schema-v0.md`) intent messages
- CH-ROUTE v0 (`route-rules-schema-v0.md`) routing rules
- any portal/validator layer that compiles a higher-level UI/CLI workflow into plumbing messages

Non-negotiable: `intent.kind` is **non-authoritative**. It is a routing/UX hint only. Any authority transfer must occur only via explicit portal sessions/intents/receipts, and must remain policy-killable.

Stability: treat this file as a **stable diff surface**. Adding a new kind changes interoperability and must be justified via an RFC (and, if it materially affects isolation/authority, a decision-map update).

## Canonical kind set (v0; alphabetical)

Each kind is a *verb-like* intent. The actual effect (if any) is performed only by a mediator (router/portal) under explicit policy.

- `background`: request background work scheduling (non-authoritative; any actual background capability is mediated by `portal.background` / CH-BGREQ/CH-BGLEASE when enabled).
- `capture`: request a capture workflow (e.g., screenshot/audio/video) mediated by `portal.capture` under explicit leases/policy.
- `drag`: request drag-and-drop style transfer (typically mediated via an explicit transfer descriptor such as CH-XFER when enabled).
- `export`: request an explicit export workflow (typically mediated by a transfer portal; never raw path/FS access).
- `notify`: request an attention workflow (notification), mediated by `portal.attn` with CH-NOTIF (D-ATTN) when enabled.
- `open`: request opening an object in an appropriate handler; subject resolution must occur via explicit portals/handles (no ambient PATH/FS).
- `open_untrusted`: request opening in an *untrusted/sandboxed* viewer by default (composes with D-EPHEM/D-QUAR).
- `open_uri`: request opening a bounded URI (subject.kind=`uri`); any network access is mediated by `portal.net` leases (no ambient net).
- `paste`: request paste/import from clipboard-like sources; mediated by a clipboard/transfer portal and explicit receipts.
- `pick_device`: request selecting a device/resource; mediated by device portals/leasing (D-DEVGUARD/D-IOLEASE when enabled).
- `print`: request print/render output; mediated by print/spool portals (no ambient printer access).
- `save`: request saving to a destination handle; mediated by document/file portals with explicit handle selection.
- `share`: request share/export to another component/user; mediated via transfer/consent portals.

## Validation hooks
- **PO-ENC-DECODE**: unknown `intent.kind` values reject deterministically (no permissive fallback).
- **PO-INTENTKIND-CLOSE**: the canonical kind list is defined **only here** and is kept mechanically closed by CI (no shadow enums elsewhere).

## Notes
- Do not treat `intent.kind` as an authorization check. Policy/authorization must be based on explicit capabilities/leases and explicit portal/validator outcomes.
- If a new kind is proposed, prefer expressing it as a composition of existing kinds + a pinned CH-* descriptor digest rather than expanding the vocabulary.
