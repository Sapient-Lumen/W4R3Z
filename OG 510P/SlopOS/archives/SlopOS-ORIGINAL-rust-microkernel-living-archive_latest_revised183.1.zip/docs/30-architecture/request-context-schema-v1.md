# CH-REQCTX v1: request context descriptor (optional)

Purpose: same as CH-REQCTX v0, with an optional hook to reference a bounded **call chain** descriptor.

Used by:
- CapRPC runtimes (via CH-CAPRPC v1 `ctx_digest`, optional).
- IF-ACP / CH-ACP proposals as `meta.reqctx_digest` (required; non-authoritative; veto-only narrowing).

Additions vs v0:
- `call_chain_digest?: bytes32` referencing **CH-CALLCHAIN v0**.

Non-goal: carrying authority. CH-REQCTX contains **no capabilities** and must not be treated as authorization evidence.

## Canonicalization requirements
- Encoded canonically per **I-ENC-1**.
- Unknown enum variants and unknown top-level keys reject deterministically.

## Descriptor

```text
CH-REQCTX-v1 {
  schema: "CH-REQCTX";
  version: 1;

  # Correlation
  ctx_id: u64;
  parent_ctx_digest?: bytes32;

  # Deadline intent (optional)
  monotonic_deadline_ms?: u64;

  # Trace correlation (optional)
  trace?: {
    trace_id: bytes16;
    span_id: bytes8;
    flags?: u8;
  };

  # Optional links to related descriptor digests (audit-only)
  budget_desc_digests?: list<bytes32>;
  tcap_desc_digests?: list<bytes32>;

  # Optional call-chain reference (audit/deny-only)
  call_chain_digest?: bytes32;   # digest(CH-CALLCHAIN v0)

  # Bounded informational tags (optional)
  tags?: list<{ k: tstr; v: tstr }>;
}
```

## Validation rules (summary)
All CH-REQCTX v0 rules apply, plus:
- `call_chain_digest` (if present) must be 32 bytes.

Bounds:
- `budget_desc_digests` length ≤ 8; `tcap_desc_digests` length ≤ 8.
- `tags` length ≤ 16; each `k`/`v` length ≤ 64; keys must contain only letters, digits, and `._-`.

## Security notes
- CH-REQCTX is **non-authoritative**: it does not grant rights.
- `call_chain_digest` is for audit/correlation and *veto-only* decisions.
  - It must not be used to grant authority.
  - It may be used to deny or narrow behavior.
