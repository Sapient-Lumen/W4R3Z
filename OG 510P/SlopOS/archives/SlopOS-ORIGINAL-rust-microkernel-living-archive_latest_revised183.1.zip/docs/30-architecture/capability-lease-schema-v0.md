# CH-CAPLEASE v0: Capability lease descriptor

Purpose: a redaction-safe, audit-friendly descriptor for **leased proxy capabilities** (D-LEASE).
This schema describes **bounds** (time/uses) and attribution; it is **not** the authority itself and carries no secrets.

References: REF-CAPMYTHS, REF-OCAP-AOCS, REF-KOPPMANN-ES.

## Encoding
Candidate baseline: canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-CAPLEASE v0 := {
  v: 0,

  ; optional coarse classification for UX/audit (non-authoritative)
  class?: tstr,               ; e.g., "File", "Directory", "NetDialer", "Clipboard", bounded

  ; bounds (at least one required)
  bounds: {
    mode: tstr,               ; closed enum: "uses" | "ttl" | "deadline" | "uses+ttl" | "uses+deadline"

    max_uses?: uint,          ; required if mode includes "uses" (bounded)

    ; time bounds are relative to an explicit clock kind/descriptor
    clock?: {
      kind: tstr,             ; closed enum: "monotonic_coarse" | "monotonic_fine" | "realtime_coarse" | "logical"
      clock_desc_digest?: bstr ; optional digest(CH-CLOCK) for the handle used (if representable)
    },

    issued_at?: uint,         ; optional clock ticks / policy epoch units (audit only)
    ttl_units?: uint,         ; required if mode includes "ttl" (bounded)
    deadline?: uint,          ; required if mode includes "deadline" (bounded)
  },

  ; optional attenuation hints (non-authoritative; enforcement is by the proxy)
  attenuate?: {
    method_allowlist?: [tstr], ; bounded list of method names/ids
    rights?: [tstr],           ; bounded list of semantic rights labels
  },

  ; renewal is explicit (do not imply ambient refresh)
  renew?: {
    allowed: bool,
    max_renewals?: uint,       ; bounded
  },

  ; stable identifiers for attribution (no secrets)
  origin: {
    comp_id: tstr,             ; canonical component name/id (e.g., CH-COMP name), bounded
    instance?: tstr,           ; optional instance label (bounded)
  },

  purpose?: tstr,              ; bounded, non-authoritative note for UI/audit

  redaction?: {
    mode: tstr,                ; closed enum: "none" | "drop_times" | "drop_attenuate"
  }
}

Notes:
- `class`, `attenuate`, and `purpose` are for UX/audit only; they must never be treated as authorization evidence.
- `issued_at`, `ttl_units`, and `deadline` are interpretive fields whose meaning depends on the clock `kind`. Time-based enforcement is done by the lease proxy using an explicit Clock handle (D-NONDET); the descriptor is only a transcript artifact.

## Validation rules (minimum)
A CH-CAPLEASE validator MUST be total and fail closed:
1) `v == 0`.
2) `bounds.mode` is allowlisted; required fields for the selected mode are present.
3) At least one of (uses, ttl/deadline) is present via `mode`.
4) `max_uses`, `ttl_units`, `deadline`, and list lengths are bounded; zero/overflow values reject.
5) If any time mode is selected, `clock.kind` is allowlisted; unknown kinds reject.
6) `origin.comp_id` is present and bounded.
7) Unknown keys reject (or are rejected by canonical CBOR decoding).

## Privacy notes
Leases can encode behavioral intent (“valid for 10 minutes”). Export via IF-OBS should consider redacting `issued_at`/time fields by default (`redaction.mode="drop_times"`) unless explicitly authorized (C-OBS-1).
