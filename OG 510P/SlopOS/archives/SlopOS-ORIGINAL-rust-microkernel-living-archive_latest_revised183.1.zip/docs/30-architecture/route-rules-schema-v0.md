# CH-ROUTE v0 (workflow routing rules, informal)

Purpose: pin a deterministic, auditable rule set for the user-space workflow router (RFC-0046 / D-PLUMB).

Design constraints (v0)
- deterministic evaluation: first-match-wins, no backtracking
- closed enum of `action.kind` and `intent.kind` (canonical kind list in `docs/30-architecture/intent-kind-registry.md`)
- total parsing + deterministic rejection on unknown fields (I-ENC-1)
- canonical encoding (RFC-0001) so deployments can hash and audit rule sets
- no secrets: rules may reference ports and intent kinds, but must not embed capabilities

## Top-level shape
`RouteRules`:
- `version`: `"v0"`
- `rules`: list of `Rule` (evaluated in order)
- `default`: `deny` | `deliver(port)` | `mediate(kind)` (recommended: `deny`)

## Rule
`Rule` fields:
- `name`: short string (for audit logs)
- `match`: `Match`
- `action`: `Action`

### Match
`Match` fields (all optional; absent means wildcard):
- `intent_kinds`: list of intent kinds (closed enum)
- `contract_ids`: list of contract IDs (RFC-0006 IDs, e.g., `"CONTRACT-FOO-v0"`)
- `src_component`: component identity selector (exact or prefix)
- `tags_any`: list of tags (mime-like or purpose-like)
- `tags_all`: list of tags

### Action
`Action.kind` (closed enum):
- `deliver`: deliver a message/grant to `port`
- `mediate_powerbox`: invoke IF-CONSENT to obtain a grant; may require CH-VOL (if enabled)
- `rewrite`: apply a normalization profile to metadata (must be a closed profile ID)
- `deny`: fail-closed

`Action` fields:
- `port` (for `deliver`)
- `requires_volition` bool (for `mediate_powerbox`)
- `rewrite_profile` (for `rewrite`)

## Canonicalization notes
- rule order is semantically meaningful; canonicalization must preserve order
- any maps/objects must be key-sorted as per RFC-0001
- strings are UTF-8 NFC

## Validation hooks
- `PO-PLUMB-NOAMP`: a portal completion must pass capgraph-diff gating (RFC-0035 tool)
- `PO-ENC-DECODE`: decoding rejects unknown fields/kinds

This schema is intentionally minimal; richer rule languages can be layered above by compiling down into CH-ROUTE v0.
