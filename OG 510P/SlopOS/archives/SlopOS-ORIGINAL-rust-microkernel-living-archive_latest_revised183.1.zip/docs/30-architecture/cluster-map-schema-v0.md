# CH-CLUSTERMAP v0 (cluster map, derived)

Purpose: pin a **deterministic, bounded** representation of the cluster partition used by the Hybrid multicore posture (ADR-0005), so that:
- cross-cluster state ownership and replication contracts can be stated against stable identifiers, and
- the chosen partition is auditable and replayable (bindable via CH-BOOT / CH-LOG if enabled).

Primary producer: user-space topology/placement logic (typically SKB when D-SKB is enabled).
Primary consumers: init/config checker (IF-BOOT / IF-CFG), sched/placement policy (user space), and audit/replay tooling.

Notes:
- CH-CLUSTERMAP is **non-authoritative**: it cannot grant authority, only describe a chosen partition.
- CH-CLUSTERMAP should be treated as a *derived artifact* from CH-HWFACT (+ optional profile policy knobs).

## Constraints (v0)
- deterministic decode + canonical bytes (I-ENC-1)
- bounded lists; no unbounded topology dumps
- stable identifiers within the scope of the boot/config generation

## Shape (v0)
A cluster map `m` contains:
- `schema`: fixed `CH-CLUSTERMAP v0`
- `inputs`:
  - `hwfact_digest`: digest of the CH-HWFACT record used
  - `policy_digest` (optional): digest of a profile policy fragment that influenced clustering (e.g., “prefer NUMA”, “cap cluster size”)
- `clusters`: bounded list of `Cluster` entries
- `cpu_index` (optional): bounded map from `cpu_id` to `{ cluster_id, local_cpu_ordinal }` for quick checks

### Cluster entries
Each `Cluster` contains:
- `cluster_id`: opaque identifier (bytes or short string) unique within this map
- `kind`: one of:
  - `numa` (preferred when NUMA boundaries are reliable)
  - `socket`
  - `die`
  - `core_group` (fallback bounded grouping)
- `members`:
  - `cpu_ids`: bounded list of `cpu_id` values (from CH-HWFACT `cpu_topology`)
- `locality` (optional, bounded):
  - `numa_node_ids`: bounded list
  - `l3_cache_ids`: bounded list (if discoverable)
- `notes` (optional, bounded):
  - `reason_tag`: short enum explaining why this cluster boundary was chosen (e.g., `prefer_numa`, `fallback_socket`, `cap_size_split`)

## Validation obligations
- reject unknown `kind` values
- enforce bounds: `clusters` length, `cpu_ids` per cluster, string/byte lengths
- enforce partition sanity:
  - every `cpu_id` appears in **at most one** cluster
  - (if `cpu_index` present) it must agree with `clusters`
- reject missing/empty `clusters`

## Interop / evidence
- If D-RR is enabled, CH-CLUSTERMAP should be included in the “initial conditions” artifact set.
- If D-BOOT measured path is enabled, bind `hwfact_digest` (+ `policy_digest` if present) in CH-BOOT.
