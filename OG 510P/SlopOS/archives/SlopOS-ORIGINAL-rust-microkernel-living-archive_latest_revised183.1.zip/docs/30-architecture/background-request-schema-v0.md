# CH-BGREQ v0: background/autostart request descriptor (optional)

Purpose: a **bounded, normalized descriptor** for requesting a background execution and/or login autostart grant from the background portal (D-BGLEASE).

CH-BGREQ is not authority. It is a stable, redaction-safe request artifact that:
- records the requester identity and declared intent (background, autostart),
- supports deterministic policy clamps and renew/review flows,
- enables LLM-first submission via ACP (`portal.background.request`) without ambient scheduler/daemon APIs,
- and stays exportable without embedding capability material.

Related:
- Output descriptor: **CH-BGLEASE v0** (`background-lease-schema-v0.md`).
- Portal family: `portal.background.*` (`portal-family-registry.md`).

References: REF-XDG-PORTAL-BACKGROUND, REF-ANDROID-BG-EXEC-LIMITS, REF-ANDROID-FGS-RESTRICTIONS, REF-APPLE-BG-MODES.

## Canonicalization requirements
- Encoded canonically per **I-ENC-1**.
- Unknown fields/variants **MUST** be rejected (fail-closed).

## Data model (conceptual)

```text
CH-BGREQ-v0 {
  schema: "CH-BGREQ";
  version: 0;

  # Client-generated request identifier.
  #
  # Used for replay/deduplication under at-least-once delivery: the requester SHOULD
  # keep `req_id` stable across retries.
  req_id: bytes16;

  # Requested grant kinds (at least one must be true)
  request: {
    background: bool;         # permission to continue running while backgrounded
    autostart: bool;          # permission to start automatically at user login
  };

  # Stable attribution (no secrets)
  origin: {
    comp_id: tstr;            # bounded; canonical component identity label
    instance?: tstr;          # optional bounded instance label
  };

  # Bounded, user-visible rationale
  reason: tstr;

  # Optional short status suitable for a system “background apps” surface
  status_message?: tstr;      # single line; bounded length

  # Policy posture hints (non-authoritative)
  ttl_hint_s?: uint;          # portal clamps; may be ignored
  indicators?: {
    required?: bool;          # requester may ask, policy may enforce regardless
  };

  # Export posture hint
  redaction?: {
    mode: tstr;               # closed enum: "none" | "hash_only"
  };

  # Optional correlation bindings (veto-only; non-authoritative)
  boot_digest?: bytes32;      # digest(CH-BOOT) if explicitly bound
  policy_revision?: u64;
}
```

## Validation rules (minimum)
A CH-BGREQ validator MUST be total and fail closed:
1) `schema == "CH-BGREQ"` and `version == 0`.
2) `req_id` is exactly 16 bytes.
3) At least one of `request.background` or `request.autostart` is true.
4) `origin.comp_id` is present and bounded.
5) `origin.instance` (if present) is bounded.
6) `reason` is present, bounded, and non-empty.
7) `status_message` (if present) is bounded and single-line.
8) `ttl_hint_s` (if present) is bounded by policy (portal clamps/ignores).
9) `redaction.mode` is allowlisted when present.
10) Unknown fields reject (or are rejected by canonical CBOR decode).

## Security posture
- CH-BGREQ is **observational** and contains **no authority** (I-BGREQ-1).
- Grants/leases are issued only by `portal.background` and remain policy-killable via `cfg.params.lane.portal.background` (PO-LANE-KILL).
- In LLM-first stacks, background requests SHOULD be mediated via ACP kind `portal.background.request`, binding `bgreq_digest = digest(CH-BGREQ v0)` and emitting transcript-visible outcomes (CH-ACPOUT/CH-DENY) (PO-ACP-BGLEASE-REQUEST).

## Privacy notes
Background/autostart requests leak behavioral metadata (“this app wants to run continuously”). Exports SHOULD treat CH-BGREQ as sensitive metadata in strict profiles and prefer `redaction.mode="hash_only"` for routine telemetry.
