# CH-XFER v0: Transfer descriptor (clipboard/drag-drop/share)

Purpose: a redaction-aware, audit-friendly descriptor for a **portal-mediated data transfer**.
This schema is **not** authority; it describes the bounds and attribution of a transfer whose payload is delivered via capabilities (typically leased).

References: REF-QUBES-CLIPBOARD, REF-WAYLAND-CH04, REF-WAYLAND-APA-DATADEVICE, REF-XDG-PORTAL-CLIPBOARD, REF-ANDROID-SECURE-CLIPBOARD.

## Encoding
Candidate baseline: canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-XFER v0 := {
  v: 0,

  xfer_id: bstr,               ; random 128-bit (or more) identifier

  kind: tstr,                  ; closed enum: "clipboard" | "drag_drop" | "share"

  ; Attribution (informational but policy-relevant for routing/audit)
  origin: {
    comp_id: tstr,             ; canonical component identity providing the data
    instance?: tstr,           ; optional instance label (bounded)
  },

  sink: {
    comp_id: tstr,             ; canonical component identity receiving the data
    instance?: tstr,           ; optional instance label (bounded)
  },

  ; Formats and bounds
  offered: [ + tstr ],         ; 1+ offered format identifiers (e.g., MIME types)
  chosen?: tstr,               ; chosen format (if negotiated)

  size_max_b?: uint,           ; maximum payload bytes this transfer may deliver (bounds enforcement)

  sensitive?: bool,            ; optional privacy hint: if true, exports SHOULD redact/deny per CH-OBSPOL

  ; Lease intent (descriptor only; no secrets). Actual leasing is via D-LEASE proxies.
  lease: {
    ttl_s: uint,               ; time-to-live in seconds (profile-bounded)
    max_uses?: uint,           ; optional use limit (1 recommended for clipboard cross-domain)
    clear_on_use?: bool,       ; if true, portal clears payload after successful delivery
  },

  issued_at_s: uint,           ; monotonic or policy-defined epoch seconds
  exp_s?: uint,                ; optional explicit expiry (>= issued_at_s)

  provider: {
    comp_id: tstr,             ; identity of the portal service that minted the descriptor
  },

  label?: tstr,                ; optional bounded label for UX (“pasted from …”); may be redacted

  meta?: { * tstr => any }     ; optional; MUST be ignored unless explicitly allowlisted
}

Notes:
- `xfer_id` is a lookup/debugging key, not an authorization token.
- `offered/chosen` are identifiers only. Payload bytes are never embedded.

## Validation rules (minimum)
A CH-XFER validator MUST be total and fail closed:
1) `v == 0`.
2) `xfer_id` is present and length-bounded (>= 16 bytes; profile may require more).
3) `kind` is a closed enum.
4) `origin.comp_id`, `sink.comp_id`, and `provider.comp_id` are present and bounded.
5) `offered` has 1+ items; each item is length-bounded; maximum list length is profile-bounded.
6) If `chosen` is present, it MUST match one of `offered`.
7) `size_max_b` is present and within profile bounds.
8) `lease.ttl_s` is present and bounded; if `max_uses` is present it is bounded; if `clear_on_use` is present it is boolean.
9) `issued_at_s` is present and bounded; if `exp_s` is present, `exp_s >= issued_at_s` and bounded.
10) Unknown fields reject (or are rejected by canonical CBOR decode); `meta` MUST be ignored unless explicitly allowlisted.

## Security notes
- **Non-bearer posture**: CH-XFER is never sufficient proof of access. Payload delivery requires portal-mediated capability grants.
- **No covert payload channels**: CH-XFER must not contain raw payload bytes or host paths; keep labels and metadata bounded.
- **Export hygiene**: CH-XFER may leak sensitive UX metadata. Snapshot/export tiers SHOULD redact `label` and MAY forbid exporting CH-XFER entirely for sensitive transfers via CH-OBSPOL.
