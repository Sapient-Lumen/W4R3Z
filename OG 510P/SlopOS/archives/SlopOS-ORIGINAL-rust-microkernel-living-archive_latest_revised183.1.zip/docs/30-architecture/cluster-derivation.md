# Cluster derivation for Hybrid multicore (D-MK adjunct)

ADR-0005 adopts Hybrid multicore: **multikernel across clusters/NUMA/chiplets; SMP within a cluster**.
This document pins a **deterministic v0 derivation** for clusters so that:
- “cluster” is not a hand-wavy term (it becomes a reviewable artifact), and
- cross-cluster replication and ownership contracts can be stated and validated.

Inputs:
- CH-HWFACT `cpu_topology` facts (and optionally `iommu_presence`, platform tags).
- Optional, profile-scoped clustering knobs (digest-binded as `policy_digest` in CH-CLUSTERMAP).

Output:
- CH-CLUSTERMAP v0.

## Design goals
- Deterministic: same inputs ⇒ same CH-CLUSTERMAP bytes (after canonicalization).
- Bounded: avoid importing full firmware topology dumps into the living contracts.
- Conservative: prefer boundaries that reduce shared-state coupling (NUMA / socket / die).
- Profile-aware but killable: clustering knobs may vary by profile, but the mechanism stays the same.

## v0 clustering policy knobs (bounded)
Represented as a small profile fragment (digest-binded via `policy_digest`):
- `preferred_boundary`: `numa | socket | die | auto`
- `max_cpus_per_cluster`: small integer cap (optional)
- `allow_cross_numa_clusters`: bool (default false)

## v0 derivation algorithm (deterministic)
Given CH-HWFACT and optional policy knobs:

1) **Extract topology sets** from `cpu_topology`:
   - `cpu_ids`
   - `numa_node_id(cpu_id)` if present
   - `socket_id(cpu_id)` if present
   - `die_id(cpu_id)` if present

2) **Choose the initial partition key** `K`:
   - If `preferred_boundary = numa` and `numa_node_id` is present for all CPUs: use `K = numa_node_id`.
   - Else if `preferred_boundary = die` and `die_id` present for all CPUs: use `K = die_id`.
   - Else if `preferred_boundary = socket` and `socket_id` present for all CPUs: use `K = socket_id`.
   - Else (`auto` or missing facts): choose the strongest available in this order:
     `numa` > `die` > `socket` > `core_group`.

3) **Form initial clusters** by grouping CPUs by `K`.

4) **Apply size cap** (`max_cpus_per_cluster`) if present:
   - For any cluster with `N > cap`, split deterministically into `ceil(N/cap)` subclusters by sorting `cpu_id` ascending and chunking.
   - Set `reason_tag = cap_size_split` for the derived subclusters.

5) **Finalize cluster ids** deterministically:
   - Compute `cluster_id = H("cluster" || kind || sorted(cpu_ids) || locality_tags)` (digest truncated to a bounded display form).
   - Sort clusters by `cluster_id` (lexicographic) for canonical order.

6) **Emit CH-CLUSTERMAP v0**:
   - `hwfact_digest = digest(CH-HWFACT bytes)`
   - `policy_digest` if knobs supplied
   - `clusters` with `kind`, `members.cpu_ids` (sorted), optional locality hints

## Validation and proof obligations
This derivation introduces mechanical obligations:
- PO-CLUSTERMAP-VALIDATE: CH-CLUSTERMAP decode is total, bounded, and rejects overlaps.
- PO-CLUSTERMAP-DERIVE: the derivation is deterministic given the declared inputs.
- PO-CLUSTERMAP-AGREE: if a `cpu_index` is present, it agrees with the cluster list.

These POs are intentionally small and “toolable” (property tests + golden fixtures).

## Relationship to commutativity (D-COMMUTE)
Hybrid reduces cross-cluster shared state. D-COMMUTE reduces the remaining coordination.
Cluster boundaries should therefore be chosen to:
- minimize the set of actions that must cross clusters, and
- make any cross-cluster ordering surfaces explicit (and pinned in hot-action boundaries).

## Open follow-ups
- Keep the replication contract surface bounded: only add new `object_family` entries with explicit commutativity/ordering stance (see `replication-contracts-v0.md` and CH-REPLCONTRACT v0).
- Decide whether to include cache-group facts in CH-HWFACT v0 (v1 candidate) to improve chiplet clustering.
- For profiles that demand strict ordering, decide whether to use RC4 ordered-log semantics or to redesign the interface to commute (D-COMMUTE).
