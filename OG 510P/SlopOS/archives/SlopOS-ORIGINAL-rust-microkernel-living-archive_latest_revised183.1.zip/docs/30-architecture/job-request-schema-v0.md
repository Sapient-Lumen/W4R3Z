# CH-JOBREQ v0: background job request descriptor (optional)

Purpose: a **bounded, normalized descriptor** for a scheduled background job request.

CH-JOBREQ is not a scheduler protocol and is not authority. It is a stable receipt-like artifact that:
- identifies the submitter + target,
- records declared constraints and trigger windows,
- records runtime bounds expectations, and
- supports audit/export hygiene without embedding capability material.

## Canonicalization requirements
- Encoded canonically per **I-ENC-1**.
- Unknown fields/variants **MUST** be rejected (fail-closed).

## Top-level fields

```text
CH-JOBREQ-v0 {
  schema: "CH-JOBREQ";
  version: 0;

  # Portal-issued opaque job identifier (not a digest)
  job_id: bytes16;

  # Who requested the job (component identity is profile-defined)
  submitter: {
    comp_id: string;           # bounded (suggested ≤ 96 bytes)
    comp_digest?: bytes32;     # optional digest(CH-COMP entry or component image)
  };

  # Which portal issued/recorded this request
  issuer: {
    comp_id: string;           # e.g., "portal.jobs" (bounded)
  };

  # What will run on trigger
  target: {
    comp_id: string;           # component to notify/activate
    mode: enum { message, activate };
    entry?: string;            # optional bounded label (e.g., "job.refresh")
  };

  # Trigger semantics (best-effort, not a hard schedule)
  trigger: {
    earliest?: { unix_sec: u64; unix_nsec: u32; };
    latest?:   { unix_sec: u64; unix_nsec: u32; };

    # Optional periodic profile (coalesced; exact cadence not guaranteed)
    periodic?: {
      interval_sec: u32;        # min clamp is profile-defined (suggested ≥ 900)
      flex_sec?: u32;           # optional flex window (≤ interval_sec)
    };
  };

  # Closed-set constraints
  constraints: {
    network: enum { none, any, unmetered, local_only };
    requires_charging?: bool;
    requires_device_idle?: bool;
    battery_not_low?: bool;
    storage_not_low?: bool;
    expedited?: bool;
  };

  # Runtime bounds expectations
  runtime: {
    max_runtime_ms: u32;        # profile clamps (suggested default ≤ 600000)
    max_runs?: u32;             # optional: cap total executions before expiry
  };

  # Optional opaque payload reference (avoid inlining large params)
  payload_ref?: CH-AREF-v0;

  # Optional correlation bindings
  boot_digest?: bytes32;        # digest(CH-BOOT) if explicitly bound
  policy_revision?: u64;

  # Export posture hint
  sensitive?: bool;             # if true, exports are redacted/blocked by CH-OBSPOL profiles
}
```

## Validation rules (summary)
- `schema` and `version` must match exactly.
- `job_id` must be exactly 16 bytes.
- `comp_id` and `entry` are bounded strings.
- `unix_nsec` must be < 1e9.
- If `periodic` is present:
  - `interval_sec` must be ≥ profile minimum.
  - `flex_sec` must be ≤ `interval_sec`.
- `max_runtime_ms` must be > 0 and bounded by policy.
- `payload_ref` must satisfy CH-AREF validation if present.

## Security posture
- CH-JOBREQ is **observational** and contains **no authority**.
- In LLM-first stacks, job submission SHOULD be mediated via ACP kind `portal.jobs.submit`, binding `jobreq_digest = digest(CH-JOBREQ v0)` and enforcing lane gate `cfg.params.lane.portal.jobs` fail-closed (PO-ACP-JOBS-SUBMIT).
- Treat as potentially sensitive metadata (scheduling + app identity). Exports should be scoped by CH-OBSPOL.

References: REF-ANDROID-JOBINFO; REF-ANDROID-WORKMANAGER; REF-APPLE-BGTASKS; REF-SYSTEMD-TIMER.
