# CH-CRYPTOAUDIT v0: Crypto operation transcript payload (redaction-safe)

Purpose: a **transcript/log payload** for crypto usage that does not leak secrets (D-CRYPTOSVC).  
This schema is intended to be embedded (or referenced-by-digest) in CH-LOG entries (D-EXPLAIN).

Refs: REF-OPENSSH-AGENTRESTRICT, REF-TPM2-PART1.

## Encoding
Candidate baseline: canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-CRYPTOAUDIT v0 := {
  v: 0,

  op: tstr,                     ; closed enum: "sign" | "decrypt" | "derive" | "attest"

  ; key attribution (no private material)
  kid: bstr,
  provider_uri?: tstr,

  ; context/purpose tag used to prevent cross-protocol misuse
  context?: tstr,

  ; redaction-safe payload descriptors
  in_digest?: bstr,             ; digest of input bytes (or digest of input buffer handle contents)
  out_digest?: bstr,            ; digest of output bytes
  in_len?: uint,
  out_len?: uint,

  ; operation decision
  allowed: bool,                ; true if performed; false if rejected
  reason?: tstr,                ; short code ("policy_denied", "confirm_denied", "rate_limited", "invalid_args")

  ; optional link to the effective policy pin
  policy_digest?: bstr,

  ; optional lease binding (if op authority was leased)
  lease_digest?: bstr,          ; digest(CH-CAPLEASE) when applicable

  ; optional monotonic/audit time (explicit clock kind; see D-NONDET)
  clock_kind?: tstr,
  t?: uint,
}

## Validation notes
- Providers MUST NOT include raw key bytes or plaintext secrets in this payload (PO-CRYPTOAUDIT-REDACT).
- `op` MUST be from the closed enum; unknown ops reject (I-ENC-1 + fail-closed decoding).
