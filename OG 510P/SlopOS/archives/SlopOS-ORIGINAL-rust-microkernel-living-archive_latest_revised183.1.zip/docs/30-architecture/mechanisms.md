# Core mechanisms (spec-oriented)

This is the narrative counterpart to the abstract machine spec (to be added in Phase 1). Keep it minimal.

## Objects (v0)
- Domain/VM
- Thread/vCPU
- Endpoint/channel
- Memory objects: frames, page tables, shared regions
- Interrupt objects
- View objects (optional): explicit name→cap mappings (see `view-objects.md`)

## Capabilities (v0)
- Cap = (object_ref, rights, metadata)
- Derivation is explicit; revocation is a design choice (see decision map)

## IPC (v0)
- Message IPC: bounded copy for simplicity
- Shared-memory IPC: explicit shared-region objects (no hidden sharing)


## Wait sets + object signals (optional)
If **D-WAITSET** is enabled, standardize a small set of pollable **signal bits** per object type (readable/writable/terminated/etc.) and an efficient **WaitSet** object (epoll/kqueue/IOCP/Zircon ports–style) to wait on many handles without O(n) polling loops.

Waiting must be **non-amplifying**: registering and waiting cannot create authority (I-WAITSET-1). Bindings and returned batches are bounded and overflow is explicit and deterministic (I-WAITSET-2; PO-WAITSET-BOUND).

Cancellation/deadlines should compose cleanly with request contexts (D-REQCTX) without introducing ambient time: deadlines use explicit Clock handles when D-NONDET is enabled.

## Wait-on-address (futex) primitives (optional)
If **D-UWAIT** is enabled, provide a minimal **wait-on-address** primitive (futex/WaitOnAddress/umtx/Zircon-futex lineage) so user-space can implement mutexes/condvars efficiently: uncontended operations stay in user space; the kernel is entered only under contention to sleep/wake waiters.

The primitive must be **bounded and attributable** (D-METER when enabled): waiter state is charged and hard-capped; exhaustion fails closed and deterministically. v0 should be **process-local by default** to avoid creating new cross-process signaling channels.

Wait operations should compose with request contexts (D-REQCTX) for cancellation/deadlines without introducing ambient time.

## Robust locks + owner-death semantics (optional)
If **D-ROBUSTLOCK** is enabled, add an opt-in kernel assist for **shared user-space locks** (stored in shared regions) so that if a thread/process terminates while holding a lock, other participants do **not** block forever.

Minimal seam:
- A **RobustSet** capability (quota-bounded) can register lock-word addresses within writable/shared regions.
- On abnormal owner exit, the kernel sets an **OWNER_DIED** flag in the lock word (atomic) and performs a bounded wake (typically via D-UWAIT).
- The next acquirer receives an explicit **owner-died** result and must either repair the protected state and call `make_consistent()` (clears OWNER_DIED) or fail-close (restart/supervise).

This is an ecosystem reliability primitive (pthread robust mutex / Windows WAIT_ABANDONED lineage) that composes cleanly with supervision trees (D-SUPV) and deterministic replay (D-RR).


## Grace periods + deferred reclamation for read-mostly shared state (optional)
If **D-RCU** is enabled, standardize a small **grace-period** seam (RCU/QSBR/EBR lineage) so components can publish new versions of read-mostly shared state and safely reclaim old nodes after readers have quiesced. This is especially valuable for shared inspect state and routing/handle tables, where coarse locks harm latency and snapshot ergonomics.

Minimal seam:
- a per-subsystem **GraceDomain** handle (user-space service/library preferred) that supports `read_enter/read_exit` (or explicit quiescent points in QSBR profiles) and `synchronize()` (wait for a grace period).
- optional `defer_free` queues that reclaim only after `synchronize()` completes.

Waiting must not devolve into polling: implementations SHOULD block via D-UWAIT when available, or surface completion as a D-WAITSET signal bit. Deferred frees and participant counts must be **bounded and attributable** (D-METER when enabled); overflow is explicit and deterministic.

This seam does **not** eliminate stalls: production profiles treat prolonged non-quiescence as a liveness failure under D-SUPV rather than silently growing limbo state.
See RFC-0112.


## Restartable sequences + CPU-local fast paths (optional)
If **D-RSEQ** is enabled, provide a small **restartable-sequence** seam (Linux rseq lineage) so user-space runtimes can implement bounded **CPU-local fast paths**: short regions that are intended to run start→commit on a single CPU, and if the thread is preempted/migrated/interrupt-delivered before commit, control is redirected to a user-provided abort handler.

This is a performance primitive, not a correctness crutch: regions must be **short and non-blocking** (no faults/IPC/sleeps), and the contract must have a single crisp commit point (“no partial commit”). Registration and metadata are bounded and attributable (D-METER when enabled); high abort rates are observable to supervision.

D-RSEQ must be **profile-gated**: exposing cpu/vcpu identifiers and fine-grained abort behavior is part of the D-NONDET posture, and deterministic replay profiles (D-RR) must disable or virtualize this seam.
See RFC-0113.


## I/O submission queues + completion events (optional)
If **D-IOQ** is enabled, provide a bounded submission/completion **IoQueue** object (shared rings + doorbell) so I/O-heavy services can batch operations without per-op boundary crossings.

Operations must target only explicit handles (no ambient paths) and, when D-IOBUF is enabled, use explicit shared buffer objects. Completions should surface as WaitSet signals when D-WAITSET is enabled (avoid a second bespoke polling API).

Queue sizing and outstanding operations must be bounded and charged (D-METER when enabled); overflow and teardown behavior must be explicit and deterministic (I-IOQ-2; PO-IOQ-BOUND).

## Quiescence + drain protocol (optional)
If **D-QUIESCE** is enabled, standardize a small cooperative maintenance handshake so supervisors/checkpoint tooling can request “stop accepting new work; drain/cancel in-flight work” with a bounded deadline intent (D-REQCTX).

Prefer a two-step pattern: `BeginQuiesce(DRAIN|CANCEL)` → wait for `QUIESCENT` (via D-WAITSET signal bit where supported, or bounded status polling) → perform maintenance (swap/checkpoint/export) → `EndQuiesce`.

Quiesce is **control authority**: it must be capability-gated and non-amplifying (I-QUIESCE-1). New-work gating must be complete while QUIESCING (PO-QUIESCE-GATE), and cancellation outcomes must be explicit with no silent background continuation (I-QUIESCE-2).


## Resource meters + kernel object quotas (optional)
If D-METER is enabled, treat resource consumption (memory objects, CPU time, endpoint objects) as **explicit authority**: allocations present meter/budget caps and are charged deterministically. If D-KOBJQ is enabled, kernel-maintained references (cap slots/endpoints/notifications) are also charged to prevent resource-exhaustion DoS.

Design note: keep charging rules *mechanistic* and fail-closed; leave policy (who gets budget) in user space.
## Contract-based channels (optional)
For selected endpoints/channels, treat the allowed message sequences as a **protocol contract** (finite-state machine) and generate wrappers/monitors that reject illegal transitions (supports D-CONTRACT). This is a cheap way to prevent protocol confusion and makes bounded model checking feasible.

## Scheduling (v0)
Start with an SMP-safe baseline: an explicit sequentialization point (e.g., a per-cluster big lock) is acceptable early, but the privileged core MUST run correctly on multiple cores and the concurrency model MUST be pinned (D-CONC/D-MEMMODEL). Refinements (sharding, per-core queues) are staged; the existence of multicore is not.

## Temporal capabilities (optional)
If D-TCAP is enabled, represent CPU time/budget/scheduling authority as explicit capabilities (“time as authority”), so policy can live in user space while the core enforces mechanistic charging and fail-closed exceed behavior (I-TCAP-1; PO-TCAP-ENF). Start with deterministic profiles before expanding scheduling expressiveness.

## Event plumbing (optional)
If D-EVENTBUS is enabled, provide a user-space “plumber”-style event router whose publish/subscribe and routing are capability-mediated (I-EVENT-1) and whose cross-boundary payloads are schema-pinned + canonically encoded (I-EVENT-2; PO-EVENT-NOAMBIENT, PO-EVENT-SCHEMA). This can serve as a composition layer for ops/control workflows without introducing ambient broadcast channels.

## Driver domains (optional)
If D-DRVDOM is enabled, keep device logic outside the privileged core. Mediate MMIO/PIO, IRQ delivery, and DMA/IOMMU mappings via explicit I/O resource objects/capabilities (I-IORES-1) and compose with the chosen DMA posture (D-DMA; I-DMA-1).

## Init→seal authority narrowing (optional)
Services may start with broader authority during initialization, then **seal** into a steady-state by dropping rights/promises and locking down view objects (supports D-SEAL).

## Constructors and confinement tests (optional)
If **D-CONSTR** is enabled, treat “build a confined subsystem” as a repeatable user-space pattern:
- constructor/factory components instantiate a subsystem from pinned template digests + parameter data,
- a standard confinement test (cap-graph diff) checks no authority leaks beyond the declared exported surface.
See RFC-0042.

## Copyless buffer objects (optional)
If IPC/I/O costs dominate, consider immutable buffer objects as explicit shared regions to avoid redundant copies while preserving I-SHARE-1 (supports D-IOBUF).

## Deterministic replay substrate (optional)
Treat CH-KABI + CH-LOG as a stable “privileged action trace” format suitable for replay/testing profiles (supports D-RR).

## Tracing and tracepoints (optional)
If D-TRACE is enabled, add predeclared tracepoints that emit bounded CH-TRACE records and export them via IF-OBS under redaction policy (I-OBS-1). Keep tracing mechanistic (no in-kernel scripting) and fail-closed on overflow (PO-TRACE-NOSTATE). If D-TPROBE is enabled, ship a pinned tracepoint descriptor table (CH-TPROBE v0) so probe IDs have an authoritative field mapping (names/types/redaction) for predicates and tooling. If D-TPRED is enabled, portals MAY accept bounded CH-TPRED predicates for prefiltering (portal-only by default; optional source-prefilter for selected probes per profile). If D-TRACEPROC is enabled, support user-space **trace processors** configured via CH-TRACEPROC v1 (v0 compatible) (often Wasm components, D-WASM) that consume CH-TRACE streams and emit bounded, redaction-safe aggregates under explicit budgets (D-BUDGET).

## Structured diagnostics trees + snapshot bundles (optional)
If **D-INSPECT** is enabled, components MAY publish a bounded, structured “inspect tree” (hierarchical typed state) in a shared region that a diagnostics collector can snapshot without syscalls.
- Exported snapshots use **CH-INSPECT v0** (canonical, bounded; no secrets by default).
- Operators/tools can assemble **support/incident bundles described by **CH-SNAPSHOT v0** (and smaller crash reports via **CH-CRASHCAP v0**), which references logs/traces/inspect snapshots and other artifacts by digest (optionally via CH-AREF).

Adjunct seam:
- If **D-FLIGHTREC** is enabled, the diagnostics collector MAY retain bounded “last N seconds” rings of selected logs/traces/inspect snapshots and assemble a CH-SNAPSHOT capture on crash/watchdog/operator triggers (no ambient auto-export; still CH-OBSPOL scoped). See: RFC-0109.
Snapshot export is explicit authority (capability-gated) and must enforce redaction/minimization (I-OBS-1); treat bundles as sensitive objects by default.

## Memory mappings (v0)
All mapping ops require authority; must preserve I-MAP-1 and I-SHARE-1.

Executable mappings follow D-DYNCODE posture:
- W^X is the default (no RWX).
- RW→RX flips (“execmod”) are capability-gated effects.
- in sealed profiles, executable pages are provenance-bound to signed artifacts (synergy with D-ATOMICUPD).

## User-mode pager / exception servers (optional)
If D-PAGER is enabled, selected faults/exceptions are delivered as *typed IPC messages* to declared pager/exception endpoints. Any mapping/grant decisions remain capability-mediated and must preserve I-MAP-1/I-CAP-1 (see I-PAGER-1; PO-PAGER-ROUTE). If we adopt more deprivileged paging, “self-paging” style designs (apps participate in paging under explicit responsibility) are worth evaluating as an optional profile.

## Verified blobs + Merkle integrity (optional)
If **D-VERITY** is enabled, immutable content MAY be represented as **VerifiedBlob** handles: reads are verified against a pinned Merkle tree (or equivalent) and **fail closed** on mismatch (no silent corruption).

- Identity/intent can be recorded as **CH-VBLOB v0** (bounded, non-authoritative) for binding into CH-BOOT/CH-UPD artifacts, transcripts (CH-LOG), and incident bundles under CH-OBSPOL.
- Prefer implementations in user-space storage/pager domains (synergy with D-PAGER) to avoid expanding the privileged core.
- Verification caches and hash-tree metadata MUST be bounded and (when D-METER is enabled) attributable, so verified reads cannot be abused as unbounded CPU/I/O work.
See: RFC-0114.

## Networked capability delegation (optional)
If D-CAPX is enabled, delegated authority that crosses a trust boundary is represented as an explicit envelope (CH-CAPX) that binds opaque token/reference bytes to local cap/proxy IDs. Keep token/runtime complexity in user space; the privileged core should only validate canonical bytes + bindings (I-CAPX-1/I-ENC-1).

## Membranes + sealers/unsealers (optional)
Across trust boundaries (components, plugins, remote gateways), consider **membranes** (revocable forwarders) and **sealers/unsealers** to keep authority mediated and optionally revocable without leaking raw capabilities (supports D-MEMBRANE).

## Capability leases + limited-use proxies (optional)
If D-LEASE is enabled, prefer **leased proxy capabilities** at boundaries and portal grants: proxy objects enforce **time-limited** and/or **use-limited** bounds before forwarding to an underlying cap, without leaking the raw cap.  
Time-based leases depend on explicit Clock handles (D-NONDET) so “no ambient time” profiles stay honest; expiry must fail closed.  
For audit/UX, emit a redaction-safe **CH-CAPLEASE** descriptor digest in CH-LOG/receipts (D-EXPLAIN), and treat leases as non-durable by default (D-PERSIST).

## Key-holding authentication agent (optional)
Consider a factotum/ssh-agent style user-space **crypto provider** that holds long-lived keys and exports only capability-mediated operations (sign/decrypt/derive/attest), so key material is never handed to clients (supports D-AUTHAGENT).  

If D-CRYPTOSVC is enabled, pin the key interface as data:
- key usage policy is explicit (**CH-KEYPOL**) and operations are checked against it (purpose/context tags; optional confirm/rate hints)
- durable references use **CH-KEYREF** (CapStore stores references, not secrets)
- crypto usage is audit-visible without leaking payloads via **CH-CRYPTOAUDIT** embedded/referenced in **CH-LOG**

If D-VAULT is enabled, extend the same pattern from keys to **credentials and opaque secrets**:
- secret usage policy is explicit (**CH-SECRETPOL**) and enforced by the vault provider (context + evidence requirements)
- durable references use **CH-SECRETREF** (CapStore stores references, not secret blobs)
- high-risk secret release can be consent/receipt bound (CH-AUTHZ + CH-VOL + CH-RECEIPT/CH-CAPDIFF) or attestation-gated in D-CC profiles, without pushing policy into the privileged core

Bind operations to meters/budgets (optional) and to transcripts (CH-LOG) for auditability, and prefer leased delegation (D-LEASE) when sharing key authority across boundaries.


## Capability store / orthogonal persistence (optional)
If D-PERSIST is enabled, implement a user-space **CapStore** service that persists **named roots** and durable capability graphs (via sturdyrefs).  
Persistence must be **explicit authority**: clients need a CapStoreCap / DurableRootCap to make state durable; otherwise authority dies on reboot.  
Boot/resume can then treat “resume is boot”: CH-BOOT may point at a CapStore root commit (CH-CAPSTORE) and init chooses fresh-boot vs resume. Pair with D-CHKPT (CH-CKPT) for snapshot/migration semantics and with D-RR for auditable recovery traces.

## Sandboxed component runtime (optional)
If D-WASM is enabled, a user-space Wasm runtime can serve as a plugin boundary. Treat the host boundary as “imports are capabilities”: no ambient filesystem/network/time access by default (I-WASM-1), and pair with init→seal for long-lived hosts (D-SEAL).
