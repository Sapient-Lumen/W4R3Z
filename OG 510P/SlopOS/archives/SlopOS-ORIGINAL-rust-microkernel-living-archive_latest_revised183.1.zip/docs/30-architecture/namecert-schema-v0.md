# CH-NAMECERT v0: Local naming certificate bundle schema

Purpose: represent a **bounded set of local name bindings + delegation statements** as a canonical artifact (D-NAMECERT).

This schema is meant to be easy to validate and audit. Complex chain discovery/policy reasoning remains in user space.

## Design rules
- closed-world: unknown keys/variants reject
- bounded sizes: cap number of bindings/delegations
- canonical encoding: I-ENC-1

## Canonical shape (informal)

```text
NameCertBundle {
  schema: "CH-NAMECERT-v0",
  bundle_id: String,
  issuer: PrincipalRef,
  created_ms: u64,
  bindings: [Binding],
  delegations: [Delegation],
  sig: Signature,
}

PrincipalRef {
  kind: "key_hash" | "pubkey",
  alg: String,
  data: Bytes,
}

Binding {
  name: String,              // local name (no global semantics)
  target: TargetRef,
}

TargetRef {
  kind: "principal" | "sturdyref" | "proxy",
  ref: Bytes,                // opaque bytes interpreted by the consumer
}

Delegation {
  role: String,              // local role label
  subject: PrincipalRef,
  rights: RightsRef,
  not_after_ms?: u64,
  constraints?: [Constraint],
}

RightsRef {
  kind: "cap_set" | "tag" | "opaque",
  ref: Bytes,
}

Constraint { kind: "label" | "caveat" | "opaque", ref: Bytes }
Signature { alg: String, sig: Bytes }
```

## Validation requirements (must)
- `issuer` matches `sig` verifier key/hash (according to profile)
- bounds on `bindings` and `delegations`
- `name` and `role` must be canonical strings (no ambiguous normalization)
- expiry fields (if present) are enforced by the consumer at use sites

## Notes
- The privileged core should *not* parse CH-NAMECERT by default; it is a user-space feature.
- If CH-NAMECERT affects privileged configuration, ensure the relevant digest is recorded in CH-LOG and/or listed in CH-BOOT `artifacts`.
