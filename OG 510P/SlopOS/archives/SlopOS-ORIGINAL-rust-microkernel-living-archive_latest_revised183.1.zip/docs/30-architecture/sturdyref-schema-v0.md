# CH-SREF v0: Sturdy reference (offline capability) schema

Purpose: represent an **offline capability reference** (“sturdyref”) that can later be restored to a live capability/proxy by an introducer/persistence service.

CH-SREF is a capability-bearing object: treat it as a secret unless it is explicitly attenuated for disclosure.

References: REF-ROBUST-COMPOSITION, REF-CAPTP, REF-TAHOE-LAFS, REF-W3C-CAPURLS.

## Encoding
Use the archive’s canonical encoding policy (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1).

## Data model (conceptual)

CH-SREF v0 := {
  v: 0,

  issuer: {
    kid: bstr,                ; key identifier / introducer identity
    locator?: tstr            ; optional network locator / service name (profile-defined)
  },

  token_kind: tstr,           ; "opaque" | "macaroon" | "biscuit" | "captp" (closed set per profile)
  token: bstr,                ; unguessable bearer material or structured token bytes

  exp?: uint,                 ; optional expiry (see D-TIME / I-TIME-1)
  caveats_hint?: [ tstr ],    ; audit/display only unless the validator models them

  meta?: { * tstr => any }    ; ignored unless allowlisted
}

## Validation rules (minimum)
Validators MUST be total and fail closed:
1) `v == 0` and required fields present.
2) `token_kind` is in the enabled set; unknown kinds reject.
3) If `exp` is present and expiry is enforced in the profile, enforce with monotonic time (I-TIME-1).
4) `meta` ignored unless allowlisted.

## Restore semantics (conceptual)
CH-SREF does not define the transport protocol; it constrains authority semantics:
- a restore operation presented with CH-SREF canonical bytes either:
  - yields **no authority** (invalid/expired), or
  - yields a live capability/proxy whose authority is ≤ the delegated authority encoded by the CH-SREF token.

Public bootstrap interfaces MUST NOT grant meaningful authority; CH-SREF presentation is the authority-bearing step.

## Operational notes
- Treat CH-SREF like a password: redact in logs/telemetry by default.
- Prefer short-lived CH-SREFs (expiry) for operator workflows.
