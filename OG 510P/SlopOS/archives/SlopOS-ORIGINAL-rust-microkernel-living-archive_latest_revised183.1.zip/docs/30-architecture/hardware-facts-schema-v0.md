# CH-HWFACT v0 (hardware facts record, informal)

Purpose: provide a **bounded, canonical** record of hardware discovery results so that policy decisions can be audited and (optionally) replayed without embedding complex probing logic in the privileged core.

Primary consumer: a user-space SKB (RFC-0018).

Refs: REF-MULTIKERNEL-SOSP09, REF-BARRELFISH-SKB, REF-DECLARATIVE-OS.

## Constraints (v0)
- deterministic decode + canonical bytes (I-ENC-1)
- closed enum of fact kinds (no free-form key/value bags)
- bounded payloads; large tables are represented as digests
- may be signed/bound via CH-BOOT/CH-PROV depending on profile

## Shape (v0)
A hardware facts record `h` contains:
- `schema`: fixed `CH-HWFACT v0`
- `facts`: bounded list of `Fact` entries
- `digests`: bounded list of `{ tag, digest }` for large external blobs (e.g., ACPI tables)

### Fact entries (closed kinds)
Each `Fact` entry contains:
- `kind`: one of:
  - `cpu_topology` (cores/threads/NUMA nodes; bounded)
  - `virt_features` (VMX/SVM/EL2/H extension presence; bounded)
  - `iommu_presence` (bool + feature tag)
  - `timer_sources` (bounded set of timer IDs)
  - `pci_device` (vendor/device/class + location; no BAR payloads)
  - `acpi_ref` (digest tag reference only)
  - `platform_id` (bounded string tag)
- `payload`: kind-specific, bounded fields


## `cpu_topology` payload (v0, bounded)

When `kind = cpu_topology`, `payload` contains:
- `cpus`: bounded list of `Cpu` entries (default max 4096)
- `numa_nodes` (optional): bounded list of discovered NUMA node ids (default max 512)

Each `Cpu` entry contains:
- `cpu_id`: small integer, unique within the record
- `socket_id` (optional): small integer
- `die_id` (optional): small integer (chiplet/CCD/cluster within socket)
- `core_id` (optional): small integer (physical core id within socket/die)
- `thread_id` (optional): small integer (SMT index within core)
- `numa_node_id` (optional): small integer
- `l3_cache_id` (optional): small integer (shared last-level cache group)

Canonicalization rules (required if D-SKB or D-MK is enabled):
- `cpus` must be sorted by ascending `cpu_id`.
- When present, `numa_nodes` must be sorted ascending and must cover exactly the set of `numa_node_id` values present in `cpus`.

Notes:
- This remains a **bounded summary**; full firmware/ACPI tables belong in `digests` by reference.
- Future versions may add additional locality hints (cache groups, distances) but must remain bounded.

## Validation obligations
- reject unknown `kind` values
- enforce bounds on lists and strings
- reject embedded “raw table dumps” (must be via `digests`)

## Notes
- CH-HWFACT is not required for Phase 0 bring-up.
- If D-RR is enabled, CH-HWFACT can be treated as part of the replay “initial conditions” artifact set.
