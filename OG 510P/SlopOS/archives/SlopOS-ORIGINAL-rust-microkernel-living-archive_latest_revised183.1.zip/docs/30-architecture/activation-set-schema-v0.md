# CH-ACTSET v0 (activation set manifest, informal)

Purpose: a small, deterministic manifest describing which **activation handles** a supervisor delivered to a component instance at start.

This is a *user-space* contract used for:
- deterministic startup wiring,
- logging/audit (“what did the component receive at launch?”),
- restart continuity (stable handles + restored handle-store items).

CH-ACTSET **does not contain capabilities**. It only describes them (kind + key + rights summary), so it is safe to log/export under the usual redaction rules.

## Shape (v0)
An activation set `a` contains:
- `schema`: fixed `CH-ACTSET v0`
- `cid`: component id (bounded)
- `instance_nonce`: bounded fresh id for this instance (debug/audit; not authority)
- `stable`: bounded list of stable handles delivered (supervisor-owned exports)
- `restored`: bounded list of handles restored from the per-component handle store

Each entry in `stable` or `restored` contains:
- `key`: bounded label (e.g., `"http"`, `"metrics"`, `"ctl"`) — **not authority**
- `cap_kind`: closed-world enum (must match `capability-rights-registry.md`)
- `rights`: bounded rights subset summary (closed-world)
- `origin`: one of `{ stable_export, handle_store }`

## Constraints
- deterministic decode + canonical bytes (I-ENC-1)
- closed set of keys/variants (unknown keys reject)
- bounded list lengths and bounded `key` length
- `rights` must be a subset of rights permitted for `cap_kind`

## Validation notes
- The supervisor SHOULD validate that:
  - `stable[*].cap_kind` appears in the component’s `activation.stable_exports` allowlist (CH-COMP)
  - `restored[*].key` appears in the component’s `activation.handle_store.key_allowlist`
  - no duplicate `(origin,key)` entries exist

## Logging guidance
- A digest of CH-ACTSET SHOULD be logged in CH-LOG as part of a component start/restart record.
- CH-ACTSET should be considered **redaction-safe** by default (no bearer tokens, no raw pointers, no secret bytes).
