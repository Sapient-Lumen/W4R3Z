# Portal family registry (v0)

Purpose: keep portal families **stable and reviewable** as the ecosystem grows.

Portals are user-space mediation services that implement high-risk workflows (open/save/share, open-uri, printing, device selection, capture, etc.) and return **capability-bearing handles** instead of ambient strings/paths.

This registry ties together:
- the **portal family name** (`portal.*`),
- the **primary RFC(s)** that define the seam,
- any **bounded descriptor artifacts** (CH-*), and
- the corresponding **CH-PLEDGE tokens** used for voluntary self-restriction.

See: RFC-0046 (workflow plumbing + portals) and `pledge-token-mapping.md`.

## Portal families

| Portal family | Primary workflow(s) | Descriptor artifact(s) (optional) | Primary decision(s) | CH-PLEDGE token | Notes |
|---|---|---|---|---|---|
| `portal.file.*` | open/save/export/share via chooser/powerbox | CH-DOCREF (durable handles) | D-PLUMB, D-POWERBOX | `portal.file` | return handles/caps, not host paths (RFC-0046, RFC-0089) |
| `portal.uri.*` | open external URIs / open directory / show item | (none required) | D-PLUMB | `portal.uri` | treat “open a link” as a mediation flow, not ambient `exec`/`xdg-open` |
| `portal.print.*` | print workflow (dialog + submit) | (none required) | D-PLUMB | `portal.print` | printing is an exfiltration + parser surface; prefer portal mediation |
| `portal.device.*` | pick device / request device lease (e.g., USB) | CH-HWEVENT (if D-SKB) | D-DEVGUARD, D-IOLEASE | `portal.device` | “device access” is a workflow: user intent + policy + lease bounds |
| `portal.net.*` | outbound connectivity lease/session grants | (session descriptors optional) | D-NETLEASE, D-LEASE | `portal.net` | no ambient `connect-by-name`; scope split (local vs internet) is policy |
| `portal.clock.*` | clock handle/lease issuance (coarse by default; fine by explicit grant) | CH-CLOCK, CH-TIMEREQ, CH-TIMEPROOF | D-NONDET, D-LEASE, D-TIMEPROOF (optional) | `portal.clock` | time is nondeterminism; prefer coarse timers; fine clocks are explicit authority (RFC-0063); optional authenticated time proofs bind CH-TIMEREQ→CH-TIMEPROOF (RFC-0090) |
| `portal.entropy.*` | entropy handle/lease issuance (seed-by-default) | CH-ENTROPY | D-NONDET, D-CRYPTOSVC (adjunct) | `portal.entropy` | treat privileged entropy primarily as bounded seed material; deterministic entropy is explicit for test/replay; ACP kind portal.entropy.request binds `digest(CH-ENTREQ v0)` (RFC-0063) |
| `portal.location.*` | location (one-shot, updates, geofences) | CH-LOCLEASE | D-LOCLEASE, D-LEASE | `portal.location` | coarse/precise + TTL/cadence; treat as sensitive metadata; indicators for continuous tracking |
| `portal.secret.*` | per-application secret seed retrieval/rotation | CH-APPSECRET | D-APPSECRET, D-CRYPTOSVC (adjunct), D-VAULT (optional) | `portal.secret` | app-scoped seed for encrypting local data; no ambient "secret by name" APIs; rotation is explicit |
| `portal.capture.*` | camera/mic/screencast/remote desktop | CH-CAPTURE | D-CAPTURE, D-LEASE | `portal.capture` | leased sessions + indicators; no ambient capture (RFC-0095) |
| `portal.xfer.*` | clipboard/drag-drop/share transfers | CH-XFER | D-PLUMB, D-LEASE | `portal.xfer` | leased payload handles + bounded transfer descriptors (RFC-0094) |
| `portal.attn.*` | notifications / attention prompts | CH-NOTIF | D-ATTN, D-VOLITION | `portal.attn` | origin branding + budgets; notification actions bind to CH-ROUTE/CH-ACP digests (RFC-0055) |
| `portal.jobs.*` | constraint-based background work | CH-JOBREQ | D-JOBS, D-TCAP | `portal.jobs` | coalesced scheduling; no precise alarms by default (RFC-0096) |
| `portal.background.*` | background execution + login autostart grants | CH-BGREQ, CH-BGLEASE | D-BGLEASE, D-JOBS | `portal.background` | prefer D-JOBS for deferrable work; background presence/autostart are visible, bounded, and revocable (RFC-0103) |
| `portal.inhibit.*` | inhibit idle/suspend/logout/shutdown transitions | CH-INHIBITLEASE | D-INHIBITLEASE, D-LEASE | `portal.inhibit` | delay-by-default for apps; block reserved for privileged components; indicators for long-lived inhibits (RFC-0102) |
| `portal.a11y.*` | accessibility / automation sessions | CH-UIAUT | D-UIAUT, D-UICAP | `portal.a11y` | observe ≠ inject; leased sessions + non-spoof indicators (RFC-0099) |

## Lane kill switches

Every portal family is an explicit workflow authority seam and MUST be policy-killable:
- For each CH-PLEDGE token `portal.<family>` in this registry, there is a corresponding CH-CFG kill switch `cfg.params.lane.portal.<family>` (closed set in `config-toggle-registry.md`).
- Portal invocations MUST treat missing/unknown lane toggle values as disabled (fail closed) and emit transcript-visible denial/receipt evidence when rejected (PO-LANE-KILL; I-LANEGATE-1).

This prevents “ambient portal enablement” drift and keeps sealed-compat and workflows honest across profiles.
CI drift gate: docs must not introduce new backticked `portal.*` tokens without updating this registry; `tools/check_portal_token_refs.py` fails `make lint` if any doc references an unknown portal family (PO-PORTALREF-CLOSE).


## Reference precedents
These families intentionally mirror the shape of widely deployed desktop portals:
- OpenURI (open external links) and Print portals. (REF-XDG-PORTAL-OPENURI, REF-XDG-PORTAL-PRINT)
- Notifications as a mediated attention workflow. (REF-XDG-PORTAL-NOTIFICATION)
- USB device access as a mediated workflow. (REF-XDG-PORTAL-USB)
- Inhibit portal for session-transition inhibition. (REF-XDG-PORTAL-INHIBIT)
- Secret portal for per-application secret seeds. (REF-XDG-PORTAL-SECRET)

The goal is not “Linux compatibility”; it is to bake the **mediation pattern** (handles/caps, consent, leases, receipts, bounded descriptors) into the OS ecosystem from day one.
