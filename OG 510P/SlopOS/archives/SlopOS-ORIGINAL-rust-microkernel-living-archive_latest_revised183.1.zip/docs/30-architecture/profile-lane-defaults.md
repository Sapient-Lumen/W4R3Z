# Profile lane defaults matrix (A–D; no forks)

Purpose: pin **non-authoritative** default guidance for `cfg.params.lane.*` kill switches across the four product shapes:

- (A) secure workstation,
- (B) cloud micro-VM / hosted compute substrate,
- (C) embedded / separation-kernel-ish appliance,
- (D) agent/automation OS.

This matrix is a **composition aid**, not a fork mechanism:
- Profiles may override these defaults in signed CH-CFG / policy bundles.
- Missing/unknown keys MUST be treated as disabled (fail closed) per `config-toggle-registry.md` and PO-LANE-KILL.
- Enabling a lane **never grants authority**; it only permits a lane to exist. Authority remains capability/approval/portal mediated.

Stability rule: treat this file as a **stable diff surface**. Any changes must:
- keep A–D viable (no forks),
- preserve sealed-compat posture (foreign cell stays portal/intent/receipt only; killable), and
- preserve “no ambient authority” (lanes don’t create implicit channels).

## Defaults (v0 seed; conservative)

Values:
- `on`: recommended to be enabled in the profile’s default policy bundle.
- `off`: recommended to be disabled in the profile’s default policy bundle.

| Param key | A (workstation) | B (cloud substrate) | C (embedded/separation) | D (agent/automation) | Notes |
|---|---|---|---|---|---|
| `cfg.params.lane.fcell` | off | off | off | off | sealed POSIX/legacy lane; enable only for explicit bootstrap/compat needs; always killable |
| `cfg.params.lane.fcell.adapter.posix_open_via_doc_portal` | off | off | off | off | compat adapter gate; requires `cfg.params.lane.fcell` + `cfg.params.lane.portal.file`; keep off unless explicitly needed |
| `cfg.params.lane.fcell.adapter.posix_socket_via_net_portal` | off | off | off | off | compat adapter gate; requires `cfg.params.lane.fcell` + `cfg.params.lane.portal.net`; keep off unless explicitly needed |
| `cfg.params.lane.capshell` | on | on | off | on | workflow glue is allowed only when effect-contract/exec-pack gates are enforced (D-CAPSHELL) |
| `cfg.params.lane.metering` | off | on | off | on | enables D-METER/D-BUDGET surfaces; keeps DoS controls explicit and attributable |
| `cfg.params.lane.portal.file` | on | off | off | on | explicit open/save/share workflows (no ambient paths) |
| `cfg.params.lane.portal.uri` | on | off | off | on | explicit OpenURI workflows |
| `cfg.params.lane.portal.print` | on | off | off | off | human-centric portal; disable for non-desktop profiles |
| `cfg.params.lane.portal.device` | on | off | off | off | device pick/lease workflows; disable for headless profiles |
| `cfg.params.lane.portal.net` | on | on | off | on | mediated networking only; no ambient sockets |
| `cfg.params.lane.portal.location` | off | off | off | off | location is high-sensitivity; prefer strict opt-in |
| `cfg.params.lane.portal.secret` | off | off | off | off | prefer explicit vault/secret portals with tight audit; enable only with strong export posture |
| `cfg.params.lane.portal.clock` | on | on | on | on | explicit clock handles/leases (D-NONDET); coarse by default; fine clock is explicit authority |
| `cfg.params.lane.timeproof` | on | on | off | on | authenticated time bootstrap/proofs (D-TIMEPROOF); can be disabled for fully offline or RTC-trust profiles; portal may require `portal.net` internally; export is redaction-scoped |
| `cfg.params.lane.portal.entropy` | on | on | on | on | explicit entropy handles/leases (D-NONDET); seed-by-default; deterministic is explicit for test/replay |
| `cfg.params.lane.portal.capture` | on | off | off | off | camera/mic/screencast; requires leased sessions + indicators |
| `cfg.params.lane.portal.xfer` | on | off | off | on | explicit transfer workflows; policy-killable to clamp sharing/export |
| `cfg.params.lane.portal.attn` | on | off | off | on | notifications/attention portal (D-ATTN); phishing surface, so keep origin branding + volition gates strict |
| `cfg.params.lane.portal.jobs` | on | on | off | on | background work is portalized (D-JOBS) |
| `cfg.params.lane.portal.background` | off | off | off | off | long-lived background/autostart is high-risk; prefer D-JOBS |
| `cfg.params.lane.portal.inhibit` | on | off | off | off | workstation UX only (sleep inhibition) |
| `cfg.params.lane.portal.a11y` | off | off | off | off | observe/inject is sensitive; enable only with strict indicators + audit |

## Guardrail

CI enforces:
- every `cfg.params.lane.*` key in `config-toggle-registry.md` appears in the table above,
- no extra keys are introduced here,
- values are from the closed set `{on, off}`.

Tool: `tools/check_profile_lane_defaults.py`.
