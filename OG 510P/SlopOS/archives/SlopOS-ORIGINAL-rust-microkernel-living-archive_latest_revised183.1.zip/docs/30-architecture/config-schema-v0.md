# CH-CFG v0 (privileged configuration schema, informal)

Purpose: a small, signed, canonical configuration artifact applied by IF-CFG and bound into IF-BOOT policy checks.

Constraints (v0)
- deterministic decode + canonical bytes for hashing/signing (I-ENC-1)
- closed set of keys (no free-form maps)
- explicit deployment profile (P0–P2)

Closure rule (v0): the allowed `feature_flags` values and `params` keys are pinned in
`config-toggle-registry.md` and are enforced by IF-CFG (PO-CFGTOGGLE-VERIFY).

## Shape (v0)
A config `cfg` contains:
- `schema`: fixed `CH-CFG v0`
- `profile`: one of `{ P0, P1, P2 }`
- `policy_rev`: monotonically increasing policy revision identifier
- `params`: closed map of typed parameters (bounded)
- `feature_flags`: closed set (off by default)
- `bindings`: digests of dependent artifacts (optional; if present must match IF-BOOT records)

Optional (adjunct seams)
- `data_contracts`: optional bounded list of dataset compatibility declarations used by update tooling
  - entry shape: `{ dataset, writer_rev, reader_min, rollback_floor?, notes_tag? }`
  - semantics are defined in RFC-0097 (data contracts + migration gates)

## Validation obligations (PO-CFG-VERIFY)
- reject unknown keys/flags
- enforce bounds + cross-field consistency
- enforce toggle closure: unknown `feature_flags` values or `params` keys reject (PO-CFGTOGGLE-VERIFY)
- if `bindings` present: verify digest matches the boot manifest / measurement log
- if `data_contracts` present:
  - enforce list bounds, identifier format, and numeric bounds
  - require `reader_min <= writer_rev`
  - if `rollback_floor` present: require `rollback_floor <= writer_rev`
- config must not widen authority without an explicit capability path (I-CAP-1)
