# Capability semantics (from-scratch, proof-shaped)

Purpose: pin down the *minimal* authority model we will later prove correct (C-CAP-1) without importing seL4 code or proofs.

Decision hook: D-CAP (decision-map). Until ADR, this is an RFC-quality spec.

## Core objects (v0)
- **Cap**: an unforgeable reference to a target object + rights + metadata (derivation info).
- **CapNode**: a container of capability slots (tree/graph structure is a design choice).
- **Objects**: frames (memory), endpoints (IPC), threads/vCPUs, address spaces, interrupt tokens, device windows (if any).

## Authority principle
- **No ambient authority**: privileged effects require possession of an appropriate capability.
- **No implicit amplification**: capabilities cannot be “strengthened” by default operations (attenuation-only unless an explicit authority object exists).

Maps to: I-CAP-1 (conservation/unforgeability).

## Derivation (attenuation-only baseline)
Define a relation `derive(parent_cap, request) -> child_cap` such that:
- child rights ⊆ parent rights
- child target is either the same object or a designated sub-object (if the object supports it)
- derivation metadata records a parent link (if revocation is supported)

This is the default posture because it is tractable to specify and verify.

### Proof obligation shape
- **PO-CAP-ATTEN**: every derivation step is attenuation-only and cannot create new authority edges.

## Revocation (optional; must be explicit)
Revocation is a *design choice*; it is not free. We treat it as a profile decision and keep semantics small.

Options (bounded):
- **None**: no revocation; rely on confinement + domain teardown.
- **Epoch/generation (coarse)**: each revocable object has a generation counter; capabilities carry `gen_at_issue`; use checks `cap.gen == obj.gen`; revoke by bumping `obj.gen`.
  - requires **no-resurrection** discipline (I-REVOKE-2): ID reuse or counter wrap must not make revoked caps valid again.
- **Indirection/membranes (selective)**: delegate via a revocable forwarder object; revoke disables forwarding (D-MEMBRANE).
- **Derivation-tree revoke (avoid early)**: sub-tree revocation tends to expand book-keeping and proof surface quickly.

Design note: prefer membranes for selective cross-boundary revocation; use epoch revocation only for small object sets where “revoke all outstanding caps” is acceptable.

See [RFC-0019](../../rfcs/0019-revocation-epochs-and-indirection.md).

## Leases / limited-use proxies (optional)
Leases are a practical attenuation pattern for “temporary authority”:
- **Use-limited:** forward at most N successful invocations.
- **Time-limited:** forward only until a deadline.

In v0, leases are expressed as *capabilities to proxy objects* (LeaseGates) that hold the raw target capability privately and enforce bounds before forwarding (synergy with D-MEMBRANE). Time-based leases, if used, require explicit Clock handles (D-NONDET); expiry must fail closed (I-LEASE-1).

See RFC-0066 and CH-CAPLEASE v0.

## Interfaces
Capability operations should ideally be expressed as a closed action set in IF-KABI:
- `cap.derive` (attenuate)
- `cap.move` (transfer ownership)
- `cap.copy` (duplicate within rules)
- `cap.revoke` (only if ADR decides)

Keep parsing and dispatch total and fail-closed (C-ABI-1; PO-ABI-TOTAL).


See `capability-rights-registry.md` for a v0, reviewable list of object classes + rights bits (including the exec/execmod seam for D-DYNCODE).

## OS lessons applied (tight)
- Capability OS lineage: keep mint/derive rules tiny and explicit.
- Plan 9 “namespaces”: treat “views” as capability-mediated objects rather than global configuration switches.

See `view-objects.md` for a candidate Plan 9-inspired "view object" mechanism that enforces non-ambient name resolution (I-VIEW-1/I-VIEW-2).
