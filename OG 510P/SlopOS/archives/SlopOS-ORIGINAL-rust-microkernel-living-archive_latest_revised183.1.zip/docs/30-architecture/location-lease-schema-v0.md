# CH-LOCLEASE v0: Location lease descriptor

Purpose: a redaction-safe, audit-friendly descriptor for **scoped location authority** granted by a location portal (D-LOCLEASE).
This schema is **not** the authority itself; it describes the bounds of a capability (e.g., a `LocStream` / `LocOneShot` handle).

References: REF-XDG-PORTAL-LOCATION, REF-ANDROID-LOC-PERMS, REF-ANDROID-LOC-BACKGROUND, REF-APPLE-LOCATION-PRECISE, REF-GEOCLUE-DBUS.

## Encoding
Candidate baseline: canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-LOCLEASE v0 := {
  v: 0,

  kind: tstr,                 ; closed enum: "oneshot" | "updates" | "geofence"

  accuracy: tstr,             ; closed enum: "coarse" | "precise"
  max_accuracy_m?: uint,      ; optional hint (portal may clamp); bounds depend on profile

  providers: [* tstr],        ; closed set elements: "gps" | "wifi" | "cell" | "ip" | "manual"
                              ; list length bounded; unknown entries reject

  ; lifetime
  issued_at_s: uint,          ; monotonic time or policy-defined epoch seconds
  ttl_s: uint,                ; lease duration (portal may clamp)

  ; update cadence (only if kind == "updates")
  updates?: {
    min_interval_s: uint,     ; portal clamps upward (coarsens) by policy
    max_rate_hz?: uint,       ; optional explicit cap (e.g., 1 Hz); portal clamps
  },

  ; geofence shape is not stored verbatim here (privacy). Instead, we bind to a
  ; canonical geofence spec digest (which may be stored out-of-band).
  geofence?: {
    shape: tstr,              ; closed enum: "circle" | "polygon"
    region_hash: bstr,        ; digest of canonical geofence spec bytes
  },

  ; background posture (only meaningful for kind != "oneshot")
  background?: tstr,          ; closed enum: "no" | "while_in_use" | "always"
                              ; "always" is expected to be rare and profile-gated

  ; stable identifiers for attribution (no secrets)
  origin: {
    comp_id: tstr,            ; canonical component name/id (e.g., CH-COMP name), bounded
    instance?: tstr,          ; optional instance label (bounded)
  },

  purpose?: tstr,             ; bounded, non-authoritative note; for UI/audit only

  redaction?: {
    mode: tstr,               ; closed enum: "none" | "hash_only"
    ; In "hash_only" mode, exports MUST drop any optional hints and keep only hashes.
    ; (CH-LOCLEASE should avoid embedding raw coordinates in v0 regardless.)
  }
}

Notes:
- This descriptor intentionally avoids carrying raw coordinates. Location **samples** are delivered over the capability channel and are subject to policy/redaction.
- `region_hash` allows auditors to check that “this geofence lease corresponds to the requested region” without exporting the region itself.

## Validation rules (minimum)
A CH-LOCLEASE validator MUST be total and fail closed:
1) `v == 0`.
2) `kind` and `accuracy` are allowlisted closed enums.
3) `providers` is non-empty, length-bounded, no duplicates, all entries allowlisted.
4) `issued_at_s` and `ttl_s` are present and bounded; `ttl_s` is clamped by profile.
5) If `kind == "updates"`, `updates.min_interval_s` is present and bounded; `updates.max_rate_hz` (if present) is bounded.
6) If `kind == "geofence"`, `geofence.shape` and `geofence.region_hash` are present and bounded; `updates` MUST be absent.
7) If `background` is present, it is allowlisted and MUST be compatible with the deployment profile.
8) `origin.comp_id` is present and bounded; unknown fields reject (or are rejected by canonical CBOR decode).

## Privacy notes
Location authority is highly sensitive. Export via IF-OBS SHOULD:
- treat CH-LOCLEASE as **sensitive metadata** by default,
- prefer `redaction.mode="hash_only"` unless explicit authorization exists,
- avoid exporting location samples unless the export policy explicitly allows them (CH-OBSPOL).
