# CH-CAPRPC v0: capability-RPC frame (optional)

Purpose: a minimal, canonical outer frame for object-capability RPC.

This is a **frame**, not an IDL: the `payload` bytes are interpreted according to a pinned interface definition under D-IDL.

## Canonicalization requirements
- Encoded canonically per **I-ENC-1**.
- Unknown `msg_kind` values reject deterministically.

## Frame

```text
CH-CAPRPC-v0 {
  schema: "CH-CAPRPC";
  version: 0;

  msg_kind: enum { call, return };

  # Correlation
  call_id: u64;                  # chosen by caller; stable within a session

  # Target
  target: {
    kind: enum { local_handle, exported_token };
    handle_id?: u64;             # opaque local handle id
    token_digest?: bytes32;      # digest of CH-CAPX/CH-SREF token if used
  };

  method_id: u32;                # method selector (ordinal) within the target interface
                                 # MUST follow the D-IDL ordinal policy; see CH-ORD and
                                 # docs/60-engineering/idl-digest-and-ordinal-policy.md

  # Payload
  iface_digest: bytes32;         # digest of the pinned interface descriptor (CH-IFACE)
  payload: bytesN;               # bounded; interpreted by IDL

  # Capability attachments
  caps: list<CapRef>;

  # Return fields (for msg_kind=return)
  status?: enum { ok, err };
  err_code?: u32;                # stable error taxonomy for replay/logging
}

CapRef {
  kind: enum { handle, export };
  handle_id?: u64;
  token_digest?: bytes32;
  rights_hint?: u32;             # optional; non-authoritative; for diagnostics only
}
```

## Validation rules (summary)
- `schema` and `version` must match exactly.
- `iface_digest` is mandatory and must be 32 bytes.
- `payload` length ≤ 4096 bytes (default bound; profile may lower).
- `caps` length ≤ 64 (default bound; profile may lower).
- For `msg_kind=call`, `status/err_code` must be absent.
- For `msg_kind=return`, `status` must be present.



## Method ordinal policy (D-IDL)
- `method_id` values MUST be stable for the lifetime of an interface family.
- For **open** interfaces, prefer hash-derived ordinals so new methods can be added without renumbering; collisions must fail closed.
- For **closed** interfaces, prefer explicit numeric ordinals and treat removals as permanently reserved.
- Recommendation: reserve the high bit of `method_id` (0x8000_0000..0xffff_ffff) for framework/runtime internal selectors; application methods keep the high bit clear.

Tooling may pin and validate the mapping using **CH-ORD v0**.

## Forward-compat notes (D-APIEVO)
- `iface_digest` binds the call/return to a **specific** interface descriptor (CH-IFACE). Receivers MUST NOT silently “guess” a different interface.
- Recommended framework-level error codes (stable, replay-friendly):
  - `1` = `UNKNOWN_IFACE` (callee does not support `iface_digest`)
  - `2` = `UNKNOWN_METHOD` (callee supports `iface_digest` but does not implement `method_id`)

Policy guidance:
- For **closed** interfaces (CH-IFACE.openness=`closed`), unknown `method_id` should fail closed (e.g., close channel or return an error that triggers caller abort), to avoid accidental confused-deputy fallbacks.
- For **open** interfaces, prefer returning `UNKNOWN_METHOD` for forward compatibility, *without* producing side effects.

## Binding and logging
- A CH-CAPRPC frame may be included in CH-LOG entries by digesting its canonical bytes.
- Authorization is not carried by this frame; effectful operations depend on the target’s capability semantics and the outer system policy.
