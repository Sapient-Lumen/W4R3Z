# Privileged interface registry (IF-IDs)

Purpose: enumerate all privileged entrypoints/control surfaces so we can bound and verify them.
Rule: if it can change privileged state, it must be in this registry (and referenced by claims/invariants/evidence).

## Interfaces (seed; keep small)

| IF-ID | Surface | What it can do | Why it exists | Primary risks | Controls (I-/PO-) |
|---|---|---|---|---|---|
| IF-KABI | Syscall/hypercall/VM-exit dispatch | Decode + dispatch a **closed** set of privileged actions (CH-KABI v0); fail closed on unknown/malformed inputs (see `hot-action-surface-v0.md` for v0 hot-action focus) | Small, explicit effect surface | parser bugs; hidden emulation; confused deputy via “magic” calls | I-IF-1, I-ENC-1, PO-ABI-TOTAL, PO-XS-CLOSESET |
| IF-BOOT | boot + update verifier | Verify/measure boot artifacts; enforce policy (CH-BOOT v0); validate optional selector state (CH-BOOTSEL v0) and optional measured-log artifact (CH-MEASLOG v0) | provenance + integrity | rollback/tamper; policy downgrade | I-BOOT-1, I-BOOT-2, I-MEASLOG-1, I-ATOMICUPD-1, PO-BOOT-VERIFY, PO-BOOT-BIND, PO-MEASLOG-VALIDATE, PO-BOOTSEL-VALIDATE |
| IF-CFG | privileged config loader | Validate/apply privileged config (CH-CFG v0) | explicit, reviewable policy changes | authority widening via misconfig | I-ENC-1, PO-CFG-VERIFY |
| IF-OBS | privileged observation export | Export telemetry/diagnostics (CH-OBS v0) under optional CH-OBSPOL v0 | audit + operator visibility | data exfiltration; side channels | C-OBS-1, I-OBS-1, I-OBSPOL-1, PO-OBS-REDACT, PO-OBSPOL-APPLY, PO-LOG-REPLAY |
| IF-ACP | Agent Control Plane (deterministic validator) | Validate and apply approved actions (CH-ACP v0) | safe automation | prompt/tool abuse; confused deputy | I-LLM-1, I-AUTHZ-1, I-TIME-1, I-ACTMETA-1, PO-ACT-VALIDATE, PO-ACT-BIND, PO-ACT-KINDMETA, PO-EXPIRY-ENF |
| IF-CAPSHELL | capability-safe automation runner (optional) | Execute automation steps under explicit effect contracts (CH-EFFCON v0), typed argv tokens (CH-ARGV v0), typed environment tokens (CH-ENV v0), typed working-directory selectors (CH-CWD v0), typed stdio bindings (CH-STDIO v0), and typed extra descriptor bindings (CH-FDSET v0), using already-held caps/leases/portals; emit transcript-visible receipts | eliminate ambient authority in “glue” workflows | ambient authority reintroduction; contract drift; confused deputy via wrappers | I-EFFCON-1, I-EFFCON-2, I-ARGV-1, I-ARGV-2, I-ARGV-3, I-ENV-1, I-ENV-2, I-CWD-1, I-CWD-2, I-STDIO-1, I-STDIO-2, I-FDSET-1, I-FDSET-2, I-CAP-1, PO-EFFCON-VALIDATE, PO-ARGV-VALIDATE, PO-ENV-VALIDATE, PO-CWD-VALIDATE, PO-STDIO-VALIDATE, PO-FDSET-VALIDATE, PO-CAPSHELL-ENF, PO-CAPSHELL-ARGV-BIND, PO-CAPSHELL-ENV-BIND, PO-CAPSHELL-CWD-BIND, PO-CAPSHELL-STDIO-BIND, PO-CAPSHELL-FDSET-BIND |
| IF-CONSENT | consent mediator / powerbox service (optional) | Issue CH-AUTHZ approvals for high-risk actions, via human UI or pinned workflow | least-authority UX + explicit approvals | confused-deputy via misleading prompts; approval misuse | I-AUTHZ-1, I-LOG-1, I-CONSENT-1, I-VOLITION-1 (if enabled), PO-CONSENT-VALIDATE, PO-VOL-VALIDATE (if enabled) |
| IF-SBX | tool sandbox boundary | Execute tools/plugins as untrusted | extensibility without core bloat | breakout; covert channels | I-SBX-1, PO-SBX-CONFINE |
| IF-ATTEST | attestation token exporter (optional) | Produce a signed CH-ATTEST bound to the current CH-BOOT digest (may call into hardware RoT via D-AUTHAGENT) | remote verification / update gates | replay/forgery; binding confusion; key exposure | I-ATTEST-1, I-BOOT-1, PO-ATTEST-BIND, PO-ATTEST-VERIFY |

## CH schemas (wire contracts; seed)
We use **CH-*** IDs to name versioned schemas for serialized data crossing trust boundaries (e.g., CH-ACP, CH-OBS, CH-CFG).
Schemas must be deterministic, pinned by version, and validated before effect (I-ENC-1; PO-ENC-DECODE).


See `exit-surface-budget.md` for a bounded-variation policy and budget ledger across IF-IDs.

CI drift gate:
- `tools/check_interface_registry_refs.py` enforces IF-ID reference closure: any `IF-...` token referenced in repo markdown must be present in this registry (prevents typo'd "shadow" interfaces and keeps privileged-surface discovery stable).
