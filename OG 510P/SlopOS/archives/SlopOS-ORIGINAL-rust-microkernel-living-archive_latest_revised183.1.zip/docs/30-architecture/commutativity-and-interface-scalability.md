# Interface-first scalability via commutativity (D-COMMUTE)

This doc records an *orthogonal* scalability lever that composes with our multicore architecture choice (SMP, multikernel, hybrid).
It is most useful when we want to keep **one substrate + four profiles** while still scaling across cores/NUMA without accidental global bottlenecks.

**Status**: Hybrid multicore is the committed default direction (ADR-0005); D-COMMUTE is a required spec/test discipline that keeps Hybrid scalable.

## Core idea

If the **spec** of two operations says their effects are independent of order (they *commute*), then there exists an implementation that can scale those operations on multicore by avoiding unnecessary coordination (REF-SCR-TOCS15).

We treat commutativity as:
- a **spec property** (what is allowed / what outcomes are observable),
- a **design constraint** (avoid introducing order-dependence unless we truly need it),
- and a **test target** (we can mechanically check commutativity claims).

## Why this composes with Hybrid (Option 5)

Hybrid/multikernel decides *where state lives* and *how cores communicate*.
Commutativity decides *how much coordination is fundamentally required*.

Combined:
- within a cluster: commutative actions can run concurrently with minimal locking (or per-shard locking);
- across clusters: commutative actions admit replication, batching, or CRDT-like patterns (REF-CRDT-INRIA11) for specific objects when appropriate;
- non-commutative actions are isolated behind explicit serialization points, making the “cost of global order” visible and reviewable.

## Hot action surface (first-class targets)

We pin a small set of **hot** privileged actions and explicitly mark which ones are **non-commutative** (i.e., where order is part of the spec). This keeps serialization points visible and turns them into first-class proof/performance targets.

See: `hot-action-surface-v0.md` (v0 seed set) and `hot-action-boundaries-v0.md` (non-commutative sub-actions).

## Serialization boundary tokens (stable diff surface)

For any **ordered** CH-ACP kind, the ACP kind registry pins *where* correctness-required serialization lives.
The allowed serialization-boundary tokens are registry-closed in:
- `serialization-boundary-registry.md` (v0; closed)

CI guardrail:
- `make lint` runs `tools/check_acp_serialization_boundary_registry.py` to enforce that the ACP kind registry uses only the tokens in the registry.


## What we must write down per action (CH-KABI / service ABI)

For each externally visible action (including portal-backed actions), record:

1) **Conflict key**: what resource identity (if any) this action mutates or depends on.
   - Normative artifact: represent conflict keys as `digest(CH-CONFLICTKEY v0)` whenever the key must cross trust boundaries (validators/receipts/tests).
   - Examples: `view_id`, `endpoint_id`, `quota_pool`, `wallet_core_digest`, `artifact_digest`.

2) **Commutation predicate**: conditions under which `A ∘ B == B ∘ A` (same observable result / same authorized receipts).
   - Often: *different conflict keys commute*; same conflict key may or may not.

3) **Retry safety**: idempotent / at-least-once-safe / exactly-once-required.
   - This matters more in hybrid/multikernel where retries are common.

4) **Visibility boundary**: what is externally observable (receipts, logs, timing).
   - Avoid making *order* observable unless needed.

We represent this as metadata attached to the action spec (see D-COMMUTE and the commutativity test harness plan below).

For **CH-ACP** actions specifically, we pin per-kind conflict key derivation + commutativity/ordering stance in `docs/70-llm-control/acp-action-kind-registry.md` and require validators/receipts to carry derived conflict key digests (and ordering witnesses for ordered kinds). The kind registry also pins the **serialization boundary** for any ordered kind (`validator` or `svc:<name>`), making explicit where non-commutativity is actually enforced and audited. This keeps LLM planning safely reorderable *when allowed* while remaining correctness-neutral: validators still enforce all ordering boundaries.

To keep commutativity claims *testable* (and planner-safe), we also pin the **per-kind commutation predicates** and the **normalized observation boundary** used by swap-order tests in `docs/70-llm-control/acp-commutativity-predicate-registry.md` (stable diff surface; D-COMMUTE).

Receipt note: when a stable result envelope is useful for tooling, IF-ACP may emit **CH-ACPOUT v0** (ACP outcome receipt), which carries `conflict_key_digest` / `order_digest` as non-authoritative observability metadata.


## What is allowed to be non-commutative

Some things are inherently order-sensitive:
- global unique allocation (unless we accept per-shard allocation + later reconciliation),
- revocation/expiry semantics with strict ordering,
- “first writer wins” policies by definition,
- monotonic counters that must be exact and globally ordered.

Rule of thumb: if an action is non-commutative, it must:
- have an explicit serialization owner (cluster/service),
- be visible in receipts as “ordered”,
- and be rare on hot paths.

## Verification + evidence hooks

We aim for *mechanical* evidence that commutativity claims match reality.

- **PO-COMMUTE-SPEC**: given a spec model, prove commutation for declared commuting pairs under predicates.
- **PO-COMMUTE-TEST**: generate tests that execute `A` then `B` vs `B` then `A` and compare normalized outcomes.
  - Outcomes include: return values + relevant receipts + externally visible state digests.

- **EVID-2026-119**: fuzz-generated commuting pairs (bounded domains) to catch “oops, order leaked” regressions.
- **EVID-2026-120**: microbench + regression harness for the declared serialization points on the pinned hot action surface.

For **ordered** boundaries, we may also use linearizability-style checkers to validate that the declared serialization owner actually enforces the intended order (REF-KNOSSOS-JEPSEN).

Commutativity metadata is also useful for LLM tooling:
- planners can safely reorder/batch commuting actions,
- validators can reject plans that cross non-commuting boundaries without explicit ordering tokens (CH-ORDERTOK v0) referenced by digest.

## Related docs

- Multicore architecture options: `multicore-architecture-options.md`
- Cross-cluster replication contracts: `replication-contracts-v0.md` (D-REPL; CH-REPLCONTRACT)
- Conflict key descriptor: `conflict-key-schema-v0.md` (CH-CONFLICTKEY v0)
- Conflict key family registry: `conflict-key-family-registry.md` (closed family allowlist)
- Ordering token descriptor: `ordering-token-schema-v0.md` (CH-ORDERTOK v0)
- Decision map entries: D-CONC / D-MK / D-COMMUTE
