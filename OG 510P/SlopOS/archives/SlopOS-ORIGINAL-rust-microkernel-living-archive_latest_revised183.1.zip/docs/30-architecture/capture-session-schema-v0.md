# CH-CAPTURE v0: Capture session descriptor (camera/mic/screencast/remote desktop)

Purpose: a redaction-aware, audit-friendly descriptor for a **portal-mediated capture session**.
This schema is **not** authority; it describes the bounds and attribution of a capture whose actual media bytes are delivered via capabilities (typically leased endpoints/buffers).

References: REF-PIPEWIRE-ACCESS, REF-PIPEWIRE-SESSMGR, REF-XDG-PORTAL-SCREENCAST, REF-XDG-PORTAL-REMOTEDESKTOP, REF-XDG-PORTAL-CAMERA.

## Encoding
Candidate baseline: canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-CAPTURE v0 := {
  v: 0,

  capture_id: bstr,            ; random 128-bit (or more) identifier

  kind: tstr,                  ; closed enum: "screenshot" | "screencast" | "remotedesktop" | "camera" | "microphone"

  requestor: {
    comp_id: tstr,             ; canonical component identity requesting capture
    instance?: tstr,           ; optional instance label (bounded)
  },

  ; Capture scope (informational, but policy-relevant)
  scope: {
    source_type: tstr,         ; closed enum by kind:
                              ;  - screen kinds: "monitor" | "window" | "region" | "virtual"
                              ;  - device kinds: "device"

    selector?: tstr,           ; optional bounded selector token (e.g., "monitor-1", "window:<opaque>")
                              ; never a host path; never a stable kernel ID

    label?: tstr,              ; optional bounded UX label (may be redacted)
  },

  ; Bounds (profile-bounded; informational but SHOULD be enforced by issued capabilities)
  bounds: {
    max_duration_s?: uint,     ; if present, clamp capture duration

    ; video bounds
    max_w_px?: uint,
    max_h_px?: uint,
    max_fps?: uint,

    ; audio bounds
    max_rate_hz?: uint,
    max_channels?: uint,

    max_bytes?: uint,          ; maximum delivered bytes (for snapshot-style outputs)
  },

  sensitive?: bool,            ; privacy hint; default SHOULD be true for capture sessions

  lease: {
    ttl_s: uint,               ; session TTL in seconds (profile-bounded)
    max_uses?: uint,           ; optional use limit for snapshot-style outputs
    renewable?: bool,          ; if true, renew requires portal mediation (and possibly fresh consent)
  },

  issued_at_s: uint,           ; monotonic or policy-defined epoch seconds
  exp_s?: uint,                ; optional explicit expiry (>= issued_at_s)

  provider: {
    comp_id: tstr,             ; identity of the portal service that minted the descriptor
  },

  meta?: { * tstr => any }     ; optional; MUST be ignored unless explicitly allowlisted
}

Notes:
- `capture_id` is a lookup/debugging key, not an authorization token.
- `selector` MUST NOT be a raw host path or stable kernel object identifier.

## Validation rules (minimum)
A CH-CAPTURE validator MUST be total and fail closed:
1) `v == 0`.
2) `capture_id` is present and length-bounded (>= 16 bytes; profile may require more).
3) `kind` is a closed enum.
4) `requestor.comp_id` and `provider.comp_id` are present and bounded.
5) `scope.source_type` is present and closed under the chosen `kind`.
6) All optional `bounds.*` fields (if present) are within profile limits; unknown `bounds` keys reject.
7) `lease.ttl_s` is present and bounded; if `max_uses` is present it is bounded; if `renewable` is present it is boolean.
8) `issued_at_s` is present and bounded; if `exp_s` is present, `exp_s >= issued_at_s` and bounded.
9) Unknown top-level fields reject (or are rejected by canonical decode); `meta` MUST be ignored unless explicitly allowlisted.

## Security notes
- **Non-bearer posture**: CH-CAPTURE is never sufficient proof of access. Capture requires portal-mediated capability grants.
- **Indicator discipline**: profiles SHOULD require that capture sessions imply a user-visible indicator (LED/OSD) that is driven by the portal/OS shell rather than by the requesting app.
- **Export hygiene**: CH-CAPTURE may leak sensitive metadata (what was shared, when). Snapshot/export tiers SHOULD redact `scope.label` and MAY forbid exporting CH-CAPTURE entirely for sensitive sessions via CH-OBSPOL.
