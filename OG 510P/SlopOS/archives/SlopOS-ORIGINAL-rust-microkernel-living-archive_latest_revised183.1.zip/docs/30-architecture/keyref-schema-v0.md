# CH-KEYREF v0: Durable key reference (no secrets)

Purpose: a durable, shareable reference to a key object and its usage policy (D-CRYPTOSVC).  
This schema is suitable for **CapStore persistence** (D-PERSIST), receipts, and audits. It contains **no private key bytes**.

Refs: REF-PLAN9-FACTOTUM, REF-OPENSSH-AGENTRESTRICT.

## Encoding
Candidate baseline: canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-KEYREF v0 := {
  v: 0,

  ; stable identifier (provider-defined, collision-resistant)
  kid: bstr,                    ; e.g., 16–32 bytes (opaque)

  ; where the key “lives”
  provider: {
    ; opaque authority reference to the provider component (often a sturdyref)
    uri: tstr,                  ; e.g., "cap://.../crypto-provider/..."
    realm?: tstr,               ; optional realm/namespace label for human audit
  },

  ; public metadata
  alg: tstr,                    ; algorithm family string
  pub?: bstr,                   ; optional public key bytes (if exportable by policy)
  class?: tstr,                 ; "user_auth" | "device_attest" | "release_signing" | ...

  ; policy (and pin)
  policy?: CH-KEYPOL v0,
  policy_digest?: bstr,          ; digest(CH-KEYPOL) if policy redacted/not embedded

  ; provenance hooks (optional)
  created_by?: bstr,            ; digest of a CH-PROV record / build identity (if applicable)
  created_at?: uint,            ; optional logical/monotonic timestamp (see D-NONDET)

  note?: tstr,
}

## Notes
- If `policy` is present, `policy_digest` SHOULD equal digest(policy) for easy cross-checking.
- CapStore roots SHOULD prefer storing CH-KEYREF rather than raw key blobs; actual authority remains the key capability held by the provider.
