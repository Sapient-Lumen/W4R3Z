# CH-ATTR v0: Attribute schema declaration (optional)

Purpose: bound the key space and types for filesystem (or resource) **attributes** when D-ATTRFS is enabled, so that:
- applications can interoperate without guessing,
- validators and indexers can stay small and deterministic,
- we can reason about covert-channel / integrity risks by restricting what is indexed and exposed.

This schema is **not** required for basic xattr-style key/value metadata. It is only a standard *declaration format* for systems that want portable, reviewable attribute sets.

## Canonical encoding
CH-ATTR follows D-ENC/RFC-0001 rules.

**Normative bytes:** canonical CBOR (RFC 8949) suitable for hashing/signing.
- no floats (deterministic integers/bytes/text only)
- reject unknown keys (closed world)

**Optional authoring form:** tools MAY accept JSON for human authoring, but MUST normalize it deterministically and transcode to canonical CBOR **before** hashing/signing. See `encoding-policy.md`.

## Data model (v0)

Top-level object:
- `version`: `"0"`
- `namespace`: a stable identifier for the attribute family (e.g. `"media"`, `"mail"`, `"pkg"`)
- `keys`: array of attribute key declarations

Attribute key declaration fields:
- `key`: string key name (no path separators)
- `type`: one of: `"bytes"`, `"utf8"`, `"u64"`, `"i64"`, `"bool"`, `"time_ns"`
- `indexed`: boolean (default false)
- `visibility`: one of: `"private"`, `"view"` (default `"view"`)
- `max_len`: optional maximum length for `"bytes"`/`"utf8"` payloads

Notes:
- `visibility="view"` means the attribute can be queried/exposed only through a view that already authorizes reading the underlying file/object.
- `indexed=true` is a high-risk knob: it increases observability. If enabled, the indexing/query service must be capability-mediated and redactable (align with D-TRACE / IF-OBS).

## Minimal validation rules
- reject unknown fields
- enforce unique `key` values
- enforce type/max_len constraints
- enforce that indexed keys are explicitly declared (no implicit indexing)

## Links
- D-ATTRFS (decision)
- RFC-0003 §16 (feature seed)
