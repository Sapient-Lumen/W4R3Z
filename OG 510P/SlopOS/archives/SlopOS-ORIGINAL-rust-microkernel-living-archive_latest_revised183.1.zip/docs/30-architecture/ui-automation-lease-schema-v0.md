# CH-UIAUT v0: UI accessibility/automation session descriptor (observation + injection)

Purpose: a redaction-aware, audit-friendly descriptor for **portal-mediated UI observation and/or input injection authority**.

This schema is **not** authority; it describes the bounds of a capability (e.g., a `UiA11y` / `UiAutomation` handle) granted by an accessibility/automation portal under D-UICAP.

References: REF-ANDROID-ACCESSIBILITYSERVICE, REF-APPLE-ACCESSIBILITY-TRUST, REF-WIN-UIACCESS.

## Encoding
Candidate baseline: canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-UIAUT v0 := {
  v: 0,

  session_id: bstr,            ; random 128-bit (or more) identifier

  kind: tstr,                  ; closed enum:
                              ;  - "a11y_observe"      (global observation under explicit policy)
                              ;  - "a11y_inject"       (injection permitted; higher-risk)
                              ;  - "automation_test"   (dev/test harness automation)
                              ;  - "automation_remote" (remote control; typically via portal.remotedesktop)

  requestor: {
    comp_id: tstr,             ; canonical component identity requesting the session
    instance?: tstr,           ; optional instance label (bounded)
  },

  ; Scope is informational but policy-relevant.
  ; The descriptor MUST NOT embed window titles, UI text, host paths, or stable kernel IDs.
  scope: {
    target_type: tstr,         ; closed enum: "global" | "app" | "view"

    target?: tstr,             ; opaque selector token (e.g., "app:<comp_id>" or "view:<opaque>")
                              ; never a host path; never a stable kernel object identifier

    label?: tstr,              ; optional bounded UX label (may be redacted)
  },

  ; Declared rights (closed allowlist). Rights are descriptive, but issued capabilities SHOULD enforce them.
  rights: [ tstr ],            ; elements are closed enum:
                              ;  - "observe_focus"
                              ;  - "observe_tree"
                              ;  - "observe_text"
                              ;  - "inject_keyboard"
                              ;  - "inject_pointer"
                              ;  - "global_hotkeys"

  ; Bounds (profile-bounded). Prefer tight defaults and leases.
  lease: {
    ttl_s: uint,               ; session TTL in seconds (portal may clamp)
    renewable?: bool,          ; if true, renew requires portal mediation (and possibly fresh consent)
  },

  ; Optional rate limits (best-effort; enforcement lives in the portal/issued proxies).
  limits?: {
    max_events?: uint,         ; optional total injected events
    max_events_per_s?: uint,   ; optional injection rate clamp
  },

  ; Attribution (no secrets)
  provider: {
    comp_id: tstr,             ; identity of the portal service that minted the descriptor
  },

  sensitive?: bool,            ; privacy hint; default SHOULD be true for global observation

  issued_at_s: uint,           ; monotonic or policy-defined epoch seconds
  exp_s?: uint,                ; optional explicit expiry (>= issued_at_s)

  meta?: { * tstr => any }     ; optional; MUST be ignored unless explicitly allowlisted
}

Notes:
- `session_id` is a lookup/debugging key, not an authorization token.
- `rights` SHOULD be minimal for accessibility: many assistive tools require observation but not injection.

## Validation rules (minimum)
A CH-UIAUT validator MUST be total and fail closed:
1) `v == 0`.
2) `session_id` is present and length-bounded (>= 16 bytes; profile may require more).
3) `kind` is a closed enum.
4) `requestor.comp_id` and `provider.comp_id` are present and bounded.
5) `scope.target_type` is present and closed; `scope.target` (if present) is bounded.
6) `rights` elements are from a closed allowlist; unknown rights reject.
7) `lease.ttl_s` is present and bounded; if `exp_s` is present, `exp_s >= issued_at_s` and bounded.
8) If `limits` is present, all keys are allowlisted and values are bounded.
9) Unknown top-level fields reject (or are rejected by canonical decode); `meta` MUST be ignored unless explicitly allowlisted.

## Security + privacy notes
- **Non-bearer posture**: CH-UIAUT is never sufficient proof of access. Observation/injection requires portal-mediated capability grants.
- **Indicator discipline**: profiles SHOULD require that active observation/injection sessions imply a user-visible indicator (shell chrome), and that indicators are driven by the OS shell/portal rather than by the requesting app.
- **Export hygiene**: CH-UIAUT can leak sensitive metadata (which assistive tooling exists, when). Export via IF-OBS should redact `scope.label` and MAY forbid exporting CH-UIAUT entirely under strict CH-OBSPOL.
