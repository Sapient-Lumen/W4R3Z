# CH-BUDGET v0 (operation budget lease schema, informal)

Purpose: a pinned, redaction-safe descriptor for **operation-scoped budget leases** (D-BUDGET).
A budget lease is a short-lived “payment token” derived from a meter (D-METER) that a caller can attach to a request so the callee can perform metered work **without implicit sponsorship**.

This schema carries **no capability secrets**; it is meant for logs/receipts/audit.

## Design constraints (v0)
- Canonical decode/encode (I-ENC-1) for hashing/logging.
- Monotonic attenuation: budgets can only narrow limits/scope (I-BUDGET-2).
- Explicit payer linkage to avoid confused-deputy billing (I-BUDGET-1).

## Descriptor shape (v0)

A budget descriptor `B` contains:
- `schema`: fixed `CH-BUDGET v0`
- `budget_id`: small opaque string/id (bounded) for correlation in logs
- `payer`:
  - `meter_digest`: digest of CH-METER v0 from which this budget lease was minted
- `kind`: closed enum (subset of CH-METER kinds):
  - `mem_bytes`
  - `kernel_refs`
  - `io_buf_bytes`
  - `net_bytes`
  - `cpu_ticks`
  - `other` (reserved; profile-approved)
- `limit`: `{ unit: bytes|ticks|count, value: u64 }`
- `scope` (optional, profile-defined narrowing):
  - e.g., `net_dest_digest` (digest of CH-NETLEASE), or `service_label`, or `object_digest`
- `expiry` (optional):
  - `{ monotonic_deadline_ms }` (requires D-TIME / D-TCAP support)
- `notes` (optional):
  - bounded plain text for auditors

## Intended uses
- Portal grants often return a capability **plus** a budget lease describing “this operation may spend up to X”.
- CH-LOG / CH-RECEIPT records include `budget_ref = digest(CH-BUDGET v0)` when a budget lease gates an effect.
- In debug builds, “missing budget” can be a hard error for metered interfaces (PO-BUDGET-NOIMPLICIT).

Refs: REF-BANGA-RESCONTAINERS, REF-CGROUPV2, REF-FUCHSIA-JOBS.
