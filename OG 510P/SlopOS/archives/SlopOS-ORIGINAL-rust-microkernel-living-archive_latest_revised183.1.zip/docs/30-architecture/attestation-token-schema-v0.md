# CH-ATTEST v0: attestation token payload-to-sign (optional)

Purpose: define a **small, stable payload** that a device can sign to allow a verifier to check **(a)** which boot state is running and **(b)** whether the signer is an accepted device identity.

This is intentionally **not** the full protocol: transport, signature container, endorsement retrieval, and verifier policy are out of scope.

## Canonicalization requirements
- Encoded canonically per **I-ENC-1**.
- Payload hashing is over the canonical bytes.
- Unknown fields/variants **MUST** be rejected by validators (fail-closed).

## Top-level fields

```text
CH-ATTEST-v0 {
  schema: "CH-ATTEST";
  version: 0;

  # Binding to local boot/provenance
  boot_digest: bytes32;          # digest(CH-BOOT canonical bytes)
  policy_revision: u64;          # monotonically increasing policy/config revision (if used)
  prov_digest?: bytes32;         # optional digest of CH-PROV payload/proof bundle

  # Device identity / signing context
  device_id: {
    kind: enum { dice_key, tpm_ek, tee_report_key, other };
    pubkey_hash: bytes32;        # hash of the public key used to verify the signature
    endorsement_digest?: bytes32;# optional digest of endorsement set
  };

  # Freshness (optional)
  freshness?: {
    kind: enum { none, nonce, challenge };
    nonce?: bytesN;              # verifier-provided nonce (bounded length)
    issued_at?: u64;             # optional monotonic counter/time, if claimed
  };

  # Claims payload (optional)
  eat_payload?: bytesN;          # optional EAT payload bytes (CBOR), bounded length
}
```

### Notes
- `boot_digest` is the **primary binding**: it ties the attestation to the measured boot record.
- `policy_revision` is included only if the deployment uses a monotonic policy counter (otherwise set 0 and treat as non-claim).
- `eat_payload` allows embedding an EAT claims set; verifiers may ignore it if the binding fields are sufficient.

## Validation rules (summary)
- `schema` and `version` must match exactly.
- `boot_digest` must be exactly 32 bytes.
- `device_id.pubkey_hash` must be exactly 32 bytes.
- `nonce` length must be ≤ 64 bytes (bounded).
- `eat_payload` length must be ≤ 2048 bytes (bounded; can be reduced per profile).

## Binding rules
- Verifier computes `digest(CH-BOOT)` and checks equality to `boot_digest`.
- If `prov_digest` is present, verifier checks it matches the active provenance artifact referenced by CH-BOOT.
- If freshness is enabled, verifier must check the nonce/challenge binding according to the protocol profile.

## Security posture
- CH-ATTEST is **observational**: producing it must not change privileged state.
- Secret material must not appear in CH-ATTEST; keys live behind D-AUTHAGENT / hardware RoT.
