# Effect lanes and pipelines

Classic shells excel at payload text streams, but they often hide control and effect structure. Schell explores a multi-lane model.

## Founding lanes

- **payload lane** — the ordinary stdout/stderr-adjacent data path; initially text-first
- **diagnostic lane** — structured warnings, trace hints, and postmortem annotations
- **effect lane** — side-effect summary or mediation surface for environment changes, file mutation intent, network use, secret access, and terminal control
- **status lane** — exit status, signal outcome, and process lineage data

## Why lanes matter

A pipeline is not only “bytes moving left to right.” It is also:

- authority propagation,
- failure propagation,
- environmental mutation,
- and diagnostic context.

The founding assumption is that Schell can surface those without denying ordinary Unix text composition.

## Open edge

Schell has **not** yet decided whether the payload lane becomes typed, optionally typed, or remains text-first with sidecar structure.
