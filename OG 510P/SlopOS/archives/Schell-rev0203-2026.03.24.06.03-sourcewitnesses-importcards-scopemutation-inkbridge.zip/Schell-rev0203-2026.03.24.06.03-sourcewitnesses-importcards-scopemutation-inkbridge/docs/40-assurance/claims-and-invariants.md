# Claims and invariants

## Founding claims

1. **Legibility claim:** every command should have an inspectable meaning boundary before execution.
2. **Effect claim:** nontrivial side effects should be classifiable before or during execution, not reconstructed only after the fact.
3. **Lineage claim:** command history should be upgradeable into receipts and replay traces.
4. **Boundary claim:** automation assistance should not silently collapse request, suggestion, approval, and execution into one actor.

## Founding invariants

- A command envelope exists before execution.
- Expansion order is explicit.
- Status outcomes are preserved even when output is piped or redirected.
- Revisions that widen shell scope must say so explicitly.
- A packaged archive release must synchronize manifest, receipt, status, and index surfaces.

## Near-term failure classes

- parse/expand ambiguity,
- hidden ambient authority,
- builtin side effects without durable representation,
- replay mismatch,
- false confidence from pretty summaries that omit the actual command lineage.
