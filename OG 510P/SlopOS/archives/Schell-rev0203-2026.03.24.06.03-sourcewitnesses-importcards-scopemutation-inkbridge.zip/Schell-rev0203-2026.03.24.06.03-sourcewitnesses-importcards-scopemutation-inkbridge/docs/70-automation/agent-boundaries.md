# Agent boundaries

A modern shell will increasingly be paired with assistants. Schell treats that as a first-class boundary problem.

## Founding lanes

- **request lane** — what the user asked for
- **proposal lane** — what an assistant suggested
- **approval lane** — what the user accepted
- **execution lane** — what the shell actually ran
- **receipt lane** — what the shell recorded afterward

## Rule

No single pleasant summary should be allowed to erase those distinctions.

## Immediate consequence

Agent-authored shell text may be useful, but Schell should preserve whether execution happened because:
- the user typed it directly,
- the user approved a proposal,
- or an automation policy executed a pre-approved pattern.
