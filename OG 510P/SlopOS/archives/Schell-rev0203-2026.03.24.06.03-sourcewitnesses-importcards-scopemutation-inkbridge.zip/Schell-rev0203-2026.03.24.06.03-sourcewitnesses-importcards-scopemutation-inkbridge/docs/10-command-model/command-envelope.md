# Command envelope

The founding Schell object is the **command envelope**: an inspectable representation of one command before execution.

## Envelope fields

- `raw_input`: original user/program text
- `parse_tree`: syntax after tokenization and grammatical binding
- `expansion_trace`: staged record of quote removal, substitutions, globbing, and word formation
- `argv`: final payload argument vector(s)
- `redirections`: redirection bindings after expansion
- `environment_delta`: requested environment changes
- `builtin_intent`: whether the command targets a builtin, external process, or compound form
- `effect_hints`: declared or inferred side-effect classes
- `authority_hints`: any sensitive capability or policy-relevant request
- `session_parent`: lineage pointer to the surrounding session or command block

## Why this object exists

Traditional shells often fuse several of these layers into one irreversible control path. Schell wants a stable inspection boundary where:

- a human can preview what the shell thinks the command means,
- an automated helper can annotate risk without owning execution,
- and a future replay engine can explain why a command behaved the way it did.

## Non-goal

The command envelope is not yet a commitment to a typed AST ABI or a stable wire format.
