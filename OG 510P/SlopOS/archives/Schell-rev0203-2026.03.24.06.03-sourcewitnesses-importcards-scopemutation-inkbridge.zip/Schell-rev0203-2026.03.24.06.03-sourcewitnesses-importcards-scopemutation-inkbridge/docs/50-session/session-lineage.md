# Session lineage

A shell session is more than an append-only history file.

## Founding lineage objects

- session id
- command id
- parent/child relation for compound commands, pipelines, and subshells
- approval marker when a previewed or assisted command is explicitly accepted
- environment delta summary
- outcome summary (status, signal, major effects, artifacts)
- replay or postmortem references

## Why this matters

Without lineage, a shell can tell you *what text happened* but not:

- what command it normalized to,
- what authority it exercised,
- what environment state changed,
- or what downstream failure inherited from it.

Schell aims to preserve just enough session structure that operators, auditors, and future automation can reason about real command trajectories.
