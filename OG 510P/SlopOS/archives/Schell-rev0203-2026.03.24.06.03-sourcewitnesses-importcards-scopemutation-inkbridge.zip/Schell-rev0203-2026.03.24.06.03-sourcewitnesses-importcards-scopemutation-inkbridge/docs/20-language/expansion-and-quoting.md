# Expansion and quoting

Schell treats expansion as a staged pipeline, not folklore.

## Founding phase order

1. Tokenization and grammatical binding
2. Quote classification
3. Tilde or home-style expansion
4. Parameter and environment substitution
5. Command substitution
6. Arithmetic or expression substitution (if adopted)
7. Word splitting under explicit rules
8. Globbing / pathname expansion
9. Redirection target binding
10. Envelope finalization

## Design aims

- Keep the order explicit enough to be teachable.
- Preserve an expansion trace for postmortem and replay.
- Avoid inheriting historical ambiguity unless Schell chooses a compatibility mode that requires it.

## Known hard parts

- heredoc binding and quote interaction,
- command substitution nesting,
- IFS-like splitting rules,
- and portability differences across existing shells.
