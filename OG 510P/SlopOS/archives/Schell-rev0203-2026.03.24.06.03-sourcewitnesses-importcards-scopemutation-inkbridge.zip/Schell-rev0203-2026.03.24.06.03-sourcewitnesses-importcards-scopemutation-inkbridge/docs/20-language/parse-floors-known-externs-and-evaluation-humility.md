# Parse floors, known externs, and evaluation humility

**A custom shell+terminal gets more luxurious when its command language gets less magical.**
Schell should absolutely collect brilliant terminal ideas.
But one of the highest-leverage ways to make those ideas safe is to keep the command-language floor small, explicit, and reviewable.

This surface is not a final language design.
It is a bounded phase-zero rule:
**before Schell tries to be dazzling, it should become unusually honest about which command lane is in effect, how text becomes argv, and whether an external command is merely opaque bytes or a known tool with an explicit signature.**

## 1) The lesson from the past: shells become dangerous when the parser becomes folklore

Classic shells often force users to remember multiple hidden stories at once:
- what the current shell parser will do,
- what later expansion stages will do,
- what an external command will see,
- and what helpers or wrappers quietly changed at startup.

That is one reason shell comfort so often decays into superstition.
Users stop asking “what will this mean?” and start asking “what incantation do I need for this environment?”

Schell should not repeat that.
A brand new shell+terminal has a rare chance to make the boring part better:
- fewer hidden parse stories,
- fewer ambient expansion rules,
- and a more visible boundary between native shell meaning and external tool meaning.

## 2) SlopOS pressures Schell toward exact front-end meaning

The companion archive is unusually clear about this family of mistakes.
Its capshell posture already says:
- `capshell.exec` takes structured argv rather than a free-form command string,
- the runner must not become a hidden `sh -c` adapter,
- front-end tokens stay exact unless an explicitly chosen interpreter expands them,
- learn mode stays observational,
- and execution meaning should stay bound to one exact executable object rather than a late mutable-name reopen.

That is powerful pressure for Schell.
It suggests the shell should not treat parsing cleverness as a local UX detail.
It is part of authority truth.

For Schell this implies:
- the native lane should prefer exact token meaning over shell folklore,
- expansion should be opt-in and explicitly named when it exists,
- explicit interpreter hops should remain explicit,
- and terminal luxuries should decorate that exactness instead of compensating for hidden language tricks.

## 3) Steal Oil's parser pressure before deciding whether to steal Oil's whole shell

One of the best ideas available right now is not a widget.
It is Oil/YSH's pressure toward simpler word evaluation.

The specific thing worth stealing is not “be Oil.”
It is the rule that command meaning gets safer when words are parsed more like a normal language instead of being reinterpreted by a stack of delayed folklore stages.

Schell should therefore consider a **parse floor** with these qualities:
- a command lane that is parsed in one obvious pass,
- literal words that stay literal unless the operator asked for something stronger,
- a small number of explicit substitution/evaluation forms,
- and review surfaces that can reveal exact argv without reconstructing a secret expansion drama.

That would make the terminal better too.
A terminal can only show an honest chapter, preview, or rerun card if the shell can honestly say what command meaning was.

## 4) Steal Nushell's `extern` pressure without freezing one giant object shell

Nushell carries another excellent idea:
**external commands can be known well enough to offer help, completions, highlighting, and parameter understanding without pretending that every external tool is a native object pipeline primitive.**

That suggests a strong Schell move:
introduce **known extern cards** or **extern signature packs**.

A known-extern artifact could carry:
- command name and provenance,
- argument and flag signatures,
- help/usage summaries,
- enum suggestions where they are actually known,
- completion hooks,
- and shape hints for output or side effects when trustworthy enough.

But it should still remain weaker than the exact reviewed action.
A known extern is a lens over a tool.
It is not permission to hide the external boundary.

## 5) The right lane split is smaller than a giant shell redesign

Schell does not need one final grammar to learn from this.
It can begin with a small lane split:

### A) Native Schell lane
A tighter, more explicit command language with a small parse floor.
This is where the shell can promise the most about meaning.

### B) Known external lane
An external command remains external, but Schell can attach a known signature pack for completions, docs, preflight hints, workflow cards, and better review.

### C) Opaque external lane
An external command with no trustworthy signature still gets exact argv reveal, explicit execution-ground posture, and result receipts — just with fewer luxuries.

### D) Explicit interpreter / compatibility lane
If the user wants `bash -lc`, `pwsh -Command`, a script interpreter, or another compatibility membrane, that remains a named lane rather than a hidden fallback.

This is already enough to make the shell+terminal feel dramatically smarter.
It is also small enough to keep major architecture decisions open.

## 6) Nifty ideas worth stealing right now

### Command-lane badges
Every command chapter should be able to say:
- native,
- known external,
- opaque external,
- or explicit interpreter.

That single badge family would prevent a huge amount of confusion.

### Parse-floor explainer
A compact reveal should show:
- the input buffer text,
- the lane,
- the exact argv or native slots,
- and any explicit substitution/evaluation forms that were used.

This is more helpful than generic “debug the parser” dumps.

### Known-extern packs as pure data
Extern packs should be easy to author, inspect, diff, share, and disable.
They should look more like typed data or signed metadata than arbitrary startup code.

### Insert / review / run for workflows
Saved workflows should land in active input with lane badges and exact signature help.
They should not skip directly to execution just because a pack exists.

### Compatibility as a named membrane
When Schell cannot honestly promise native-lane clarity, it should be able to say so cleanly.
“Explicit interpreter” is much better than silent reparsing.

## 7) fish still teaches the discipline rule

fish's design pressure matters here too.
A smaller, more orthogonal language surface is not anti-ambition.
It is one of the conditions for making ambition survivable.

Schell should therefore prefer:
- fewer overlapping command-language features,
- fewer hidden compatibility modes,
- and fewer configuration-driven meaning changes.

That makes every future terminal luxury easier to trust.

## 8) What not to decide yet

This surface intentionally does **not** decide:
- the final Schell grammar,
- the final expression language,
- the final substitution vocabulary,
- the final extern-signature schema,
- the final structured pipeline ontology,
- or the final compatibility story for importing other shell ecosystems.

It only says the shell should probably earn luxury by simplifying meaning first.

## 9) Compact phase-zero answer

If Schell wants to become super awesome without overcommitting, one of the best moves available is this:

**make command meaning more boring, make external boundaries more visible, and make rich help/preview/workflow luxuries ride on top of that boring truth.**

That gives the archive a path to steal:
- Oil's parser pressure,
- Nushell's known-extern signatures,
- Warp-style parameterized workflow comfort,
- Ghostty/kitty/VS Code command-boundary luxury,
- and fish's orthogonality discipline,

without forcing the project to settle one final shell language before it has earned the right.
