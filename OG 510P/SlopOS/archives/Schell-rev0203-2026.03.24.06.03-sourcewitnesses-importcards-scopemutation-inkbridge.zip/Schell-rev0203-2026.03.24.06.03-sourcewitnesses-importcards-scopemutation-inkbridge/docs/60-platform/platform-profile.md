# Platform profile

## Initial stance

- POSIX and common Unix shell practice are reference material.
- Linux and macOS are the initial mental targets.
- Schell should avoid immediate dependence on a custom kernel or capability OS.
- Compatibility is profile-driven: strict mode, compatibility mode, and experimental mode may eventually differ.
- The first portable promise is **text truth**, not full feature parity with a richer terminal.

## Anti-goal

Do not let compatibility drag Schell into preserving every historical footgun by default.

## Current implementation posture

The implementation language is Rust, but stack choices remain open until prototype pressure earns them.
Portable Schell must preserve review, receipts, denials, and replay handles even when rich terminal affordances degrade away.
