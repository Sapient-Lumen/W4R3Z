# Rust prototype slice

This surface narrows the first Rust proving lane without freezing the future stack.

## Goal

Prove one humane reviewed action and its transcript/receipt behavior with the lightest stack that can still teach us something real.

## Bounded first slice

### Likely in-scope

- a humane text input/editing layer,
- structured tracing and span/event lineage,
- plain-text review cards,
- plain-text receipts and denials,
- and transcript emission that preserves semantic boundaries.

### Likely out-of-scope for the first slice

- a full TUI layout system,
- a custom terminal emulator,
- PTY-heavy compatibility plumbing,
- async-runtime lock-in,
- and rich pane/shelf rendering.

## Current best guess

The first Rust prototype should bias toward:

1. text interaction first,
2. trace/receipt truth first,
3. transcript round-tripping next,
4. and only then richer local rendering.

## Why this is healthy

A transcript-backed prototype is easier to audit, easier to compare across revisions, and much less likely to decide terminal architecture by accident.

## Admission rule for more stack

A new crate or subsystem should normally arrive because one of these is true:

- a prototyping question cannot advance without it,
- transcript truth cannot be preserved without it,
- or repo hygiene materially improves because of it.
