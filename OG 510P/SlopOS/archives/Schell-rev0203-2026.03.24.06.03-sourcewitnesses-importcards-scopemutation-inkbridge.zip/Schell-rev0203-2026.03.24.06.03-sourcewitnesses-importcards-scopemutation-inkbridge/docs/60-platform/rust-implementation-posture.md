# Rust implementation posture

## Bound decision

Schell will be implemented in **Rust**.

## Why this is now bound

This is a reasonable commitment to carry even while the shell itself stays largely in research mode because Rust fits the current pressure:

- exact modeling of reviewed objects,
- strong enums and pattern matching for stateful execution/review flows,
- memory safety for a process/terminal-heavy program,
- structured instrumentation support,
- and a strong ecosystem for CLIs, TUIs, and systems programming.

## What this does *not* settle

Binding Rust does **not** yet settle:

- async runtime,
- line editor,
- PTY crate,
- rendering stack,
- GUI toolkit,
- serialization format,
- plugin/extension ABI,
- or long-term cross-platform promise.

## Current bounded prototype pressure

The archive now has a more specific first stack slice candidate:

- likely adopt `tracing` first for lineage and receipts,
- likely prototype `reedline` first for humane line editing,
- keep `ratatui`, `crossterm`, and `portable-pty` as explicit candidates until the first reviewed interaction proves it needs them.

## Implementation law

Rust code should grow only where the archive already has one of:

- a question in `prototyping`,
- an RFC that needs an executable probe,
- or a hygiene/instrumentation requirement that prose alone cannot satisfy.
