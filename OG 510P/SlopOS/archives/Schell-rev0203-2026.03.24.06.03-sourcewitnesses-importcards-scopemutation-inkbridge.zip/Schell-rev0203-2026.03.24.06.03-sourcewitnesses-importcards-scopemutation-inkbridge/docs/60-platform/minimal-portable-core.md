# Minimal portable core

This surface exists to answer a question the archive can no longer leave vague:

> what must remain true about Schell when no rich terminal features are available?

## Working answer

The smallest portable Schell core should support:

1. **exact action preview in text**
2. **approve / deny / revise in text**
3. **durable text receipts**
4. **durable text denial explanations**
5. **replay handles in text**
6. **stable command/session lineage in text logs**

If these do not survive SSH, plain terminals, transcripts, and headless automation, then the rich terminal has become a hidden correctness dependency.

## Portable obligations

### Review card

A plain terminal should still be able to show a compact review card containing at least:

- exact artifact identity,
- proposed action,
- requested authority scope,
- expiry / one-shot posture,
- and expected receipt handle.

### Receipt block

A plain terminal should still be able to emit a stable receipt block containing at least:

- request id,
- receipt id,
- action outcome,
- exact artifact reference,
- and replay / explain handles.

### Denial block

A plain terminal should still be able to emit a denial block containing at least:

- attempted action,
- missing grant / lease / portal,
- whether retry is safe,
- and the narrowest likely-successful next request.

## What the portable core does *not* require

- block selection UI,
- click-to-jump navigation,
- inline artifact previews,
- rich panes or shelves,
- embedded graphics,
- mouse-aware prompt editing.

Those may all be excellent.
They are not part of the minimum truth surface.

## Working law

A rich Schell terminal may accelerate understanding.
It may not be the only place where understanding exists.
