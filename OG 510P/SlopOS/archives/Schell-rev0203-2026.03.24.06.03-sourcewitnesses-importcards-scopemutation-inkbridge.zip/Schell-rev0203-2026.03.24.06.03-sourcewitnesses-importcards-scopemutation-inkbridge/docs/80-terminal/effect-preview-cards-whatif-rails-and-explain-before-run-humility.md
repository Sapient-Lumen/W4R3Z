# Effect-preview cards, WhatIf rails, and explain-before-run humility

This surface keeps one boundary explicit:
**a great shell+terminal should be able to show what a command or workflow is likely to affect, what exact basis it was understood against, where parsing or conversion boundaries sit, and what remains uncertain — but it should not let dry-run stories, pretty previews, or helper prose impersonate exact execution truth.**

Schell already has review cards, trusted command blocks, execution grounds, workflow seeds, assistant lanes, output capsules, render humility, and time-ground posture.
This pass narrows the seam those surfaces still leave open:
**how the shell+terminal should expose predicted effects and parser boundaries before run without quietly turning previews into permission or rendering into exact meaning.**

The design pressure now comes from four directions:
- SlopOS keeps insisting on exact mutable basis, exact exec identity, observational learn mode, and no hidden fallback.
- PowerShell proves that first-class `WhatIf` and `Confirm` behavior is genuinely useful rather than luxury theater.
- fish proves that responsiveness, discoverability, and good defaults matter more than infinite configuration.
- Nushell and modern shell-integrated terminals prove that structured inspection, command boundaries, exit-code UX, and output navigation are worth stealing if they remain honest about what is exact.

## 1) First rule: preview is not one thing

Schell should keep at least these preview kinds separately named:
- **exact basis preview** — exact command or action on an exact mutable basis,
- **descriptive effect hint** — a best-effort explanation of likely changes,
- **parser reveal** — how text becomes argv, pipeline shape, or external-command input,
- **render preview** — a human-friendly view of output or subject matter,
- **contract preview** — requested authority, likely capability use, and drift from a known wallet,
- **uncertainty confession** — what the shell cannot know without running or re-inspecting.

A super-awesome shell+terminal should be able to move between those layers fluidly.
It should not flatten them into one persuasive panel.

## 2) Basis honesty matters more than explanation style

The shell world is full of helpful explanations that stop being true the moment the mutable basis changes.
That is exactly the trap SlopOS’s approval-basis posture warns about.

So an effect-preview card should be able to say:
- exact file/tree/handle/process subject,
- exact mutable basis if one was reviewed,
- current drift state,
- and whether the preview is still exact, stale, descriptive-only, or unknown.

If basis drift happens, the preview should not quietly follow the new world.
It should confess.

## 3) Parse honesty deserves its own witness family

A huge amount of historical shell pain comes from pretending that what the user sees inline is the same as what the callee receives.
That is often false.

Schell should therefore make room for:
- **exact argv reveal** for shell-known commands,
- **external-boundary reveal** for native commands,
- **raw literal lane** when the operator wants the shell to stop being clever,
- **text-versus-structured badges** on pipeline edges,
- and **interpreter-choice badges** when a script or workflow crosses into another execution substrate.

This should feel luxurious, not punitive.
The point is to reduce surprise, not to force constant low-level reading.

## 4) Rendered output must stay weaker than pipeline truth

Nushell’s strongest teaching is not just “structured data is nice.”
It is that rendered tables and external-text boundaries are different things.
That is a profound shell lesson.

Schell should steal the good part without overcommitting early:
- let output carry **shape chips** like `text`, `rows`, `kv`, `bytes`, `rendered-table`, `rendered-diff`,
- let previews explain when a conversion to text will occur,
- and never let a beautiful table or diff stand in for the exact value or byte stream being reviewed.

## 5) Discoverability should be built into the shell, not paid for with folklore

fish is right about three things Schell should copy shamelessly:
- responsiveness is part of trust,
- completions and errors should explain themselves,
- and giant configuration surfaces usually mean the design punted on good defaults.

So explain-before-run should not feel like opening a giant expert dashboard.
It should be cheap:
- a one-line WhatIf summary by default,
- a compact expand-for-why strip,
- and a richer inspector only when the operator asks.

## 6) Shell integration marks are worth stealing

WezTerm, Ghostty, and VS Code terminal features all reinforce the same point: command boundaries, exit-code decorations, and output navigation are much better when the shell emits honest marks.

Schell should lean into that.
Effect previews should attach to shell-authenticated command chapters, not to guessed text regions.
That enables:
- jump to command start/output start,
- select exact output for one command chapter,
- pin the WhatIf summary next to the eventual receipt,
- and compare preview versus result without guessing where the command began.

## 7) WhatIf should become a first-class lane, not an afterthought flag

One of the niftiest ideas worth stealing is the dignity of `WhatIf`.
Not just a boolean option, but a real lane with recognizable semantics:
- no side effects,
- exact basis when available,
- explicit uncertainty when not,
- and a visual split between predicted mutation and observed result.

That suggests a small but potent Schell rail set:
- **Explain** — describe likely effect and parsing posture,
- **WhatIf** — execute only the non-effectful planning path,
- **Review** — bind exact basis and requested authority,
- **Run** — perform the action,
- **Compare** — show preview versus receipt.

## 8) Super-awesome specimen ideas that still stay decision-light

A first specimen set could stay compact but teach a lot:
1. one command chapter with a default one-line WhatIf summary and an expandable exact-basis strip;
2. one parse card showing input text, exact argv, external-boundary mode, and any raw-literal rail taken;
3. one output-shape strip showing whether downstream consumers will get text, bytes, rows, or a rendered view;
4. one wallet-diff chip showing requested capability change or network/file/process effect posture;
5. one stale-basis confession state that clearly invalidates the old preview without dramatics;
6. one compare view that places preview and receipt side by side;
7. one shell-integration chapter marker set so command boundaries, exit codes, and exact-output selection become trivial.

## 9) The no-regret move

The best move right now is not to freeze one final shell grammar, one universal structured-object pipeline, one AI planner contract, one transport stack, or one automation policy language.
It is to pin one stronger rule:
**Schell should model pre-run understanding as effect-preview cards, WhatIf rails, parser reveals, output-shape chips, stale-basis confession, and preview-versus-receipt comparison before it lets dry-run stories, render views, or helper prose masquerade as exact execution truth.**

That keeps the archive free to defer:
- the final shell language,
- the final structured-pipeline ontology,
- the final preview/explanation protocol,
- the final transport stack,
- and the final extension ecosystem.
