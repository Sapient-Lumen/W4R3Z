# Active-input leases, scoped work lanes, and workflow seeds

This surface names one possible Schell ratchet that feels both **super awesome** and still low-regret:
make the shell+terminal visibly smarter about **where live authority is** and **which lane a visible object belongs to**.

The point is not to turn the terminal into a giant window manager for state.
The point is to stop pretending that all visible text in a terminal has the same meaning.

## Core idea

Schell should likely expose a small set of explicit work lanes:

- **active-input lane** — the one live field that currently accepts shell input,
- **direct-command lane** — blocks created from user-run terminal commands,
- **proposal/agent lane** — blocks created inside an assistant or proposal scope,
- **receipt/denial lane** — durable decision/result objects,
- **background-residue lane** — output that arrived later but lacks exact foreground ownership,
- **workflow lane** — explicit saved command templates or reusable reviewed recipes.

The terminal can make these lanes easy to search together.
The shell should keep their authority stories distinct.

## 1) Active-input lease

The active prompt should behave like a field, not like dead glass.

That means:

- clicking inside it moves the cursor,
- selection and insertion work naturally there,
- suggestions and structured argument filling happen there,
- and the terminal can style it as the one currently editable place.

But the important part is the authority model:

- there is one active-input lease at a time,
- the shell tells the terminal where it begins and ends,
- historical blocks do not inherit edit authority,
- and replay/read-only views never masquerade as live input.

This is a very strong user-facing affordance with relatively low architectural regret.

## 2) Scoped block identities

Every visible block should answer at least three questions plainly:

1. **what lane am I in?**
2. **what trust/status do I have?**
3. **what strong actions am I allowed to unlock?**

Example status vocabulary:

- draft,
- marked,
- shell-authenticated,
- reviewed,
- running,
- receipt,
- denial,
- workflow,
- background residue.

The exact vocabulary may change.
The important point is that the terminal should stop pretending every visible block is just “history.”

## 3) Background residue honesty

Background output is a classic place where terminals accidentally flatter themselves.
Sometimes they know the owning action.
Sometimes they do not.

Schell should preserve both possibilities:

- **linked background event** when the shell knows which reviewed/running action it belongs to,
- **background residue** when provenance is partial,
- and explicit warnings when concurrent writers or lane mixing weaken ownership claims.

That makes the terminal much more honest than a single undifferentiated scrollback.

## 4) Proposal and agent scope separation

The terminal should become better, not worse, when assistants are present.
That means proposal/agent work probably needs its own visible lane.

Good consequences:

- direct user commands stay clearly direct,
- agent-generated commands stay clearly scoped,
- conversation-local context can remain local,
- and “attach to conversation” can become an explicit action instead of hidden carry.

This is one of the best ways to keep automation helpful without erasing authorship.

## 5) Workflow seeds

Schell should probably have a better story than aliases for reusable commands.
A good early answer is **workflow seeds**:
explicit named templates that can be created from a trusted block or from a reviewed proposal result.

Workflow seeds should preserve:

- source lane,
- source trust grade,
- command template,
- parameter placeholders,
- optional descriptions,
- and whether the seed is merely reusable text or a reviewed reusable action shape.

Crucially:

- a workflow seed is not the same thing as a live approval,
- a workflow seed is not ambient startup magic,
- and a workflow seed should still require exact basis binding when used for strong actions.

## 6) Lane-aware search and palette

A custom shell+terminal becomes much more powerful once search is not just text grep over scrollback.

A lane-aware search or palette could search across:

- direct commands,
- workflows,
- receipts,
- denials,
- background events,
- and agent conversation artifacts.

But results should always disclose:

- lane,
- trust/status,
- exact object id or digest if any,
- and which actions are safe from that result.

## 7) Transcript truth remains non-negotiable

All of this still has to survive plain text.
A transcript should still be able to say:

- which lane a thing belonged to,
- whether it was draft/reviewed/receipt/background residue,
- whether it was direct or agent-scoped,
- and whether an action was blocked because provenance or basis was too weak.

If the lane model only exists in the rich renderer, Schell has not actually learned the lesson.

## Why this is promising

This move feels unusually strong because it improves all three of these at once:

- **operator comfort** — the terminal becomes easier to navigate and safer to edit,
- **authority honesty** — stronger actions depend on real scope/trust/status rather than vibes,
- **decision deferral** — the archive can prototype lanes and workflow seeds without freezing the final renderer, transport, or pipeline ontology.

## Current bounded reading

The likely low-regret first slice is:

1. one active-input lease,
2. a visible distinction between direct / receipt / background / proposal lanes,
3. trust/status tags on blocks,
4. a transcript-safe notation for those tags,
5. and one explicit conversion from trusted block to workflow seed.

That would already make Schell feel like a genuinely new shell+terminal without forcing too many deep decisions too soon.
