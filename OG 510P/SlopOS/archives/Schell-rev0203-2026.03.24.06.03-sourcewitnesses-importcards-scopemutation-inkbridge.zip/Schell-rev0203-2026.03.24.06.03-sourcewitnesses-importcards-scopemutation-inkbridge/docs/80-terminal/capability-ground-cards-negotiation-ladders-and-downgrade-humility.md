# Capability-ground cards, negotiation ladders, and downgrade humility

This surface keeps one boundary explicit:
**a great shell+terminal should be able to negotiate richer capabilities across terminal, shell, mux, remote, and helper layers, but it should not let advertised features, compatibility brands, or lucky fallbacks impersonate exact current truth.**

Schell already has input downgrade, startup footing, file/path ground, pager witnesses, render grounds, and config-ground cards.
This pass narrows the seam those surfaces still left open:
**how the shell+terminal should treat capability claims, runtime queries, adapters, and fallbacks as explicit posture rather than as one flattering terminal-brand myth.**

The design pressure comes from three directions:
- SlopOS keeps pushing explicit interface identity, no guessing, local policy over imported claims, and adapters as first-class components rather than hidden fallback.
- Current terminals keep proving that static capability databases, runtime state queries, and protocol-level progressive enhancement are all useful but distinct.
- Current remote and mux stacks keep proving that compatibility often depends on TERM rewriting, terminfo distribution, protocol translation, or helper injection rather than on one honest native footing.

## 1) The first rule: capability claims are not all the same kind of truth

A humane shell+terminal should keep at least these things separately named:
- **static capability ground** — what TERM/terminfo claims in the current environment,
- **runtime capability ground** — what the terminal actually reports when queried now,
- **shell-known capability ground** — what the shell has explicitly marked or observed,
- **adapter posture** — what a mux, bridge, helper, or transport translated,
- **fallback posture** — what weaker behavior is in effect now,
- and **acceptance posture** — what the current application/session has actually chosen to rely on.

That sounds fussy until you look at the current ecosystem.
A terminal may have a rich terminfo entry, yet a remote host may not have that entry installed.
A mux may translate key events or clipboard behavior.
A shell helper may rewrite TERM or inject startup behavior.
And an application may still only be safely using a downgraded path.

## 2) Terminfo is necessary, but static claims are not the same as live state

`terminfo` remains the baseline capability vocabulary, and ncurses still supports extended entries and user-defined capabilities loaded at runtime.
But xterm’s control-sequence docs make the stronger lesson explicit: some queried values can differ from startup resources, and xterm provides direct state-query controls because startup resource values may not reflect current state.

Schell should steal that lesson rather than pretending one source of capability truth is enough.
A good shell+terminal should be able to answer:
- what did TERM/terminfo claim,
- what did the live terminal actually report,
- what did the mux/bridge preserve or translate,
- and what is the current safe fallback?

## 3) Capability negotiation should be a ladder, not a hidden leap

Modern input protocols are already teaching the right shape.
kitty’s keyboard protocol is progressive enhancement: applications ask for stronger reporting incrementally, support can be queried, and a few legacy keys intentionally stay usable so the user can still recover when a program crashes without resetting modes.
WezTerm’s keyboard docs also show why negotiation matters: xterm-style `modifyOtherKeys` is requestable, kitty-style enhancement can be honored, and CSI-u support is explicitly not recommended as a default because it changes behavior in backwards-incompatible ways and applications cannot detect or request it.

The import for Schell is strong:
- richer behavior should usually be **requested**,
- support should usually be **detectable or explicitly admitted**,
- and fallback should remain **recoverable and legible**.

## 4) Adapters and multiplexers must confess translation

tmux is especially helpful here.
It documents `terminal-features` and `terminal-overrides` because terminfo alone often does not say enough.
It can request extended keys itself if the terminal supports them, and it exposes named feature families like `extkeys`, `focus`, `hyperlinks`, and `clipboard`.
It also says to take care to configure only features the terminal actually supports.

That is exactly the shape Schell should steal.
A mux/adapter should not merely “make things work.”
It should confess:
- what it detected,
- what it translated,
- what it inferred from terminal family or TERM pattern,
- what it had to override,
- and what was left downgraded.

## 5) Compatibility brands are evidence of ecosystem pressure, not native truth

Ghostty’s current terminfo docs are unusually honest here.
It uses `xterm-ghostty` because too many applications string-search for `xterm`; it provides an opt-in `ssh-terminfo` feature to copy terminfo to a remote host; and it also provides an opt-in `ssh-env` fallback that sets `TERM=xterm-256color` on remote hosts, explicitly calling that a band-aid that is “not strictly correct” but often helpful.
Those features are opt-in because they override `ssh` in the shell and are not risk-free.

WezTerm’s docs show the same family of pressure from another angle: using `TERM=wezterm` depends on the terminfo entry being available, older ncurses versions may need local installation, and on Windows the ConPTY layer can strip some escape sequences so a different transport path may be needed.

Schell should steal the honesty, not the blur.
A terminal brand, TERM value, or helper-installed fallback is useful evidence.
It is **not** the same thing as exact current capability truth.

## 6) SlopOS makes the import sharper: no guessing, explicit acceptance, adapters as components

The companion archive rewards a very crisp posture here.
RFC-0071 says interface identity should be explicit, unknown interfaces or methods should fail deterministically rather than guess, and real compatibility should ship as explicit adapters or translators instead of hidden fallback logic.
The signature-algorithm acceptance boundary says imported algorithm identifiers are exact evidence of how something was produced, but acceptance remains explicit local policy and Phase 1 declines any hidden strongest-wins or negotiate-until-one-works plane.

That is an excellent fit for Schell.
The shell+terminal should not treat imported capability claims as automatic permission to spend richer behavior.
It should instead keep:
- capability claim,
- capability query result,
- local acceptance,
- adapter translation,
- and downgraded fallback

separately named.

## 7) Capability-ground cards should answer “why did this feature work here?”

A humane v0 could keep compact **capability-ground cards** that answer questions like:
- why do extended keys work locally but not through this remote hop,
- why did hyperlinks disappear inside this mux,
- why is undercurl present here but not on that machine,
- why did paste protection downgrade,
- why did the shell choose a weaker TERM remotely,
- or why is this feature marked unknown instead of absent?

Useful card labels could include:
- native static claim,
- runtime-confirmed,
- shell-marked,
- mux-adapted,
- helper-projected,
- remote-fallback,
- degraded-safe,
- unsupported,
- and unknown.

## 8) Super-awesome specimen ideas that still stay decision-light

A first specimen set could stay small but teach a lot:
1. one key-input card showing static terminfo claim, runtime enhancement query, current accepted mode, and recovery-safe fallback;
2. one remote capability card showing native terminfo install versus TERM fallback and clearly badging the fallback as weaker;
3. one mux bridge card showing which features are passed through, translated, or suppressed;
4. one “why didn’t this render here?” card tying graphics/hyperlink/focus/clipboard behavior to specific capability posture;
5. one startup-footing card showing when helper injection, ssh wrapper behavior, or TERMINFO_DIRS made a feature possible;
6. one support/export witness that preserves capability basis, query results, and downgrade badges rather than only the visible symptom;
7. one explicit ladder that says native -> adapter -> degraded-safe -> plain legacy -> unknown.

## 9) The no-regret move

The best move right now is not to freeze one universal negotiation bus, one final feature-bit registry, one final TERM family, one final mux bridge protocol, or one final remote capability story.
It is to pin one stronger rule:
**Schell should model terminal and shell capabilities as capability-ground cards, explicit negotiation ladders, adapter confession strips, and downgrade badges before it lets terminal branding, startup helpers, TERM rewriting, or lucky runtime queries masquerade as exact truth.**

That keeps the archive free to defer:
- the final capability registry,
- the final runtime query set,
- the final mux bridge protocol,
- the final TERM/terminfo strategy,
- and the final remote feature-install/fallback story.
