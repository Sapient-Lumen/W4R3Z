# Autonomy postures, permission dials, and stop humility

This surface exists to keep one especially tempting shell+terminal luxury honest:
**current agentic terminals and coding CLIs increasingly offer visible posture switches like ask, plan, auto-edit, bypass, autopilot, or yolo, but Schell should treat those as bounded operator postures with explicit stop/revoke truth rather than as flattering permanent trust upgrades.**

This is worth stealing.
The current tools are proving that operators like fast posture changes.
Sometimes they want read-only exploration.
Sometimes they want auto-accepted edits but not shell commands.
Sometimes they want a narrowly trusted allowlist.
Sometimes they want a genuinely aggressive run-until-completion burst.
Those are real luxuries.
They become dangerous when one session-level convenience toggle quietly turns into ambient policy, silently outlives the current basis, or hides how to stop the agent once it is moving.

## 1) Keep posture, scope, and stop truth separate

At minimum Schell should keep these as different objects:

1. **autonomy posture chip** — ask / plan / bounded-auto / explicit-never / yolo-like / unknown
2. **scope chip** — once / current question / current room / current shell session / current project / managed policy / unknown
3. **allow surface** — exact commands, tools, tool families, data sources, edit classes, or provider lanes that gained speed
4. **deny floor** — what still cannot run automatically even in a more permissive posture
5. **stop handle** — the explicit operator path that halts the current burst of autonomy
6. **revoke handle** — how the operator removes a remembered allowance or posture widening
7. **drift badge** — whether cwd, repo, attachments, tool set, or prompt basis changed since the posture was chosen
8. **receipt residue** — what actually ran under the posture, which parts were merely proposed, and where later review still begins

That is the honesty line.
A visible mode toggle is not enough.
The operator also needs to know what widened, how far the widening reaches, what still remains denied, and how to stop or revoke it.

## 2) “More autonomy” should be shaped like a narrower question, not a bigger vibe

The best posture systems do not just say “trust the assistant more.”
They narrow the question.
Examples include:
- read-only planning,
- auto-accept file edits but still ask before shell commands,
- allow only a short command regex set,
- allow only one MCP/tool family,
- allow only until this task completes,
- or deny everything except pre-approved tools.

Schell should copy that shape.
A good posture chip should answer:
- **what can move faster now?**
- **what still blocks?**
- **how long does this widening live?**
- **what changed since I chose it?**

That makes the shell+terminal feel powerfully ergonomic without pretending that “autonomy” is one single scalar.

## 3) Plan posture is the cleanest luxury

One of the strongest current ideas in the ecosystem is a genuine plan or read-only posture.
The assistant can inspect, summarize, and propose.
It cannot yet spend side effects.
That is unusually Schell-friendly because it improves quality and comfort without forcing a deep architecture choice.

Schell should therefore prefer a visible ladder such as:
- `observe`
- `plan`
- `auto-accept local draft/edit`
- `bounded auto on explicit tool family`
- `task burst`
- `never`

The exact names can stay open.
The important design move is that **planning and observing remain first-class postures rather than merely weaker failures of a run posture.**

## 4) Stop handles deserve first-class chrome

Aggressive posture is only humane if stopping it is easy and legible.
A good stop handle should be:
- always visible while autonomy is active,
- local to the active room/task/session,
- stronger than ordinary conversation interruption,
- and explicit about whether it stops proposals, tool execution, retries, auto-replies, or only future steps.

This is one of the easiest places to make Schell feel super awesome.
The operator should never wonder whether `Ctrl+C`, a stop button, or a close action actually halts the current autonomous burst.
The shell+terminal should confess what kind of stop it can still honor.

## 5) Remembered approval should decay on drift

A posture chip becomes much safer when it visibly weakens as the basis changes.
Useful drift dimensions include:
- cwd/repo root,
- active branch or worktree,
- attached files or provider sidecars,
- tool catalog or MCP set,
- prompt fingerprint family,
- workspace trust posture,
- and restored-versus-live room state.

That means a great shell+terminal can still be fast.
It simply says:
- this allowance is still exact,
- this one is now project-only,
- this one degraded to review-first,
- this one died on restore,
- or this one is now invalid because the basis changed.

## 6) Allowlists and deny floors should be explicit and separately named

Current tools keep rediscovering the same thing:
operators want small allowlists and hard deny floors.
Schell should make both explicit.

A posture card should be able to say things like:
- `allow: Read, Grep, Glob, git status, npm test`
- `allow: file edits only`
- `allow: this provider only`
- `deny floor: network, rm, shell eval, secret reveals, grant prompts`

That is much healthier than a single flattering badge like “autonomous mode.”
A shell+terminal is not honest unless the operator can tell which families stayed blocked.

## 7) Revocation is not the same as stop

Stopping a running autonomous burst and revoking a remembered allowance are different acts.
Schell should model both.

- **stop** halts or interrupts the current run loop
- **revoke** removes a widened rule, remembered allowance, or temporary profile
- **downgrade** keeps the session alive but pushes it back to ask/plan/review-first posture

That separation matters because otherwise users will think the scary part has ended when only the current motion stopped.

## 8) SlopOS pressure: posture should stay lease-shaped, operation-shaped, and diffable

SlopOS keeps pushing Schell toward a narrower and more truthful answer:
- veto-only automation bundles are safer than ambient allow-everything policy,
- operation-scoped budget leases are safer than one giant trust flip,
- capability leases and authority diffs are better than vague “trusted mode” wording,
- and trusted chrome should stay descriptive unless a separately named seam grants power.

That means the companion-safe move is not to invent one master autonomy switch.
It is to treat posture as a lease-shaped, scope-shaped, revocable operator object with exact widening and exact downgrade conditions.

## 9) The super-awesome move is visible autonomy comfort

This pass points to a very strong delight upgrade:
**make autonomy comfort fast to enter, obvious while active, and trivial to stop or downgrade.**

That means:
- one-chip switching between ask / plan / bounded auto / burst,
- exact allow surface reveal,
- hard deny floor reveal,
- one-shot and session/project scopes,
- drift badges that quietly downgrade remembered speed,
- and a stop handle that never hides.

That is much better than a hidden preference toggle or one giant “danger mode.”
It collects a real modern luxury without prematurely freezing the full policy architecture.

## 10) First specimen set this seam wants

A good first proof set would show:
1. one plan posture that permits inspection but not edits or shell commands,
2. one auto-edit posture that still asks before shell execution,
3. one bounded command/tool allowlist with an explicit deny floor,
4. one task-burst posture that is visibly current-task only,
5. one stop handle that halts autonomous iteration without pretending it revoked all allowances,
6. one revoke handle that removes a remembered allowance while leaving the room/session alive,
7. one restored session where the prior aggressive posture downgrades on drift,
8. and one transcript-safe notation for posture chip, scope chip, allow surface, deny floor, stop outcome, and later receipt residue.

## 11) Bounded conclusion

One of the safest ways to make Schell feel much better than legacy terminals is also one of the clearest:

**separate posture, scope, deny floor, stop, revoke, and later receipt truth.**

The shell+terminal can absolutely offer plan mode, auto-edit comfort, bounded command allowlists, task-burst autonomy, and quick toggles between them.
But the archive should keep posture chips, scope chips, stop handles, revoke handles, drift badges, and later receipts separately named so a convenient mode switch never quietly becomes ambient authority.
