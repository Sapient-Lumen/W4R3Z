# Activation batons, armed rails, and focus-second humility

**Schell should absolutely steal modern comfort around notification clicks, shortcut summons, chooser accept flows, browser returns, and open-this-exact-thing affordances — but it must keep the exact target, the transferred activation baton, the merely armed lane, and actual active control visibly separate so “bring me there” never quietly becomes “I already have focus, control, or approval.”**

## 1) The next no-regret luxury move is not smarter click-through

The archive already has:
- wake tickets,
- fresh-intent witnesses,
- launch sheets,
- drift cards,
- witness packets,
- and action floors.

What is still missing is the tiny object for **target first, activation second**.
Current products keep giving us better ways to jump back to the right place.
That is good.
But a click, shortcut, or routed open should still be able to say:
- this is the exact thing we mean,
- this is only a baton asking the UI/compositor to activate or foreground it,
- this lane is prepared but not yet active,
- and control may still be refused, expire, or land elsewhere.

That is a much safer move than letting wake tickets, global shortcuts, or chooser accepts quietly impersonate active control.

## 2) Current platforms already separate these classes on purpose

The current platform story is unusually clear.
HTML distinguishes transient activation from activation-*consuming* use.
The XDG Notification portal says a notification action carries an **activation token** plus an application-defined target.
The XDG GlobalShortcuts portal emits a shortcut activation event plus an optional activation token.
The XDG InputCapture portal explicitly distinguishes **enabled** from **active**, and the compositor decides when active capture really begins.

That is the shape Schell should steal.
One event may prove recent user action.
One token may request foregrounding.
One route may identify the target.
But none of those automatically prove the target is active **now**.

## 3) The right object is an activation baton witness

A **baton witness** is a tiny local explanation object that accompanies an exact reveal/open/focus-capable action.
It is not:
- the target itself,
- a durable capability,
- fresh-intent proof for arbitrary spend,
- a completion receipt,
- or proof that foreground control already happened.

A useful v0 baton witness can stay compact:
- `baton_ref`
- `source_kind` — notification action / global shortcut / chooser accept / browser return / trusted review lane / unknown
- `target_ref` — exact chapter / exact receipt / exact output span / room / window / unknown
- `target_strength` — exact / narrowed / weak / history-only / unknown
- `baton_posture` — fresh / passed / spent / expired / refused / unknown
- `route_posture` — target-only / target-plus-raise-request / target-plus-armed-lane / target-plus-active / unknown
- `foreground_claim` — not-requested / requested / granted / denied / ignored / unknown
- `downgrade_floor` — reveal / focus-best-effort / review / history-only / blocked / unknown

That is already enough to make return comfort feel brilliant without lying about active control.

## 4) Keep four nearby classes visibly separate

### a) Exact target
What are we acting on?
A chapter, receipt, output span, room, helper lane, or exact frame.

### b) Activation baton
What short-lived baton lets the UI *ask* to foreground or activate?
This may come from a notification click, shortcut, browser return, or chooser accept.

### c) Armed lane
What lane is prepared or enabled but not yet active?
A review card may be open.
A helper lane may be staged.
An attach path may be ready.
That is not the same thing as active control.

### d) Active control
What currently owns focus or active input delivery *now*?
This is the strongest and narrowest fact of the four.
It should never be inferred from the other three.

## 5) “Focus second” is the product move worth stealing

The clever move here is not only safer — it is also better UX.
Resolve the exact target first.
Only then let the UI say whether it can also raise, focus, or activate that target.

That gives Schell a much healthier ladder:
1. identify the exact target,
2. reveal or open it,
3. request activation if a baton exists,
4. show whether activation was granted,
5. and only then offer any stronger next action through the usual review rules.

This means a refused or expired baton does not make the target ambiguous.
You can still open the right thing and confess that the foreground request did not land.

## 6) Where this seam immediately helps

### a) Wake tickets and notifications
A notification click can redeem the exact wake ticket and *also* carry a raise request.
But it should be able to say `target opened, focus request denied` instead of turning that into a mysterious failure.

### b) Global shortcuts
A shortcut can summon the right room or command card quickly.
But the shortcut event and any activation token should stay separate from later spend-ready authority.

### c) Browser-return and auth handoff
A browser return can identify the exact auth card or helper lane.
Its baton can ask to foreground the right shell surface.
That still does not prove active control or approval.

### d) Chooser accept / quick open / exact reveal
A chooser accept can resolve the target and optionally request activation.
This is much better than one ambiguous `open` that smuggles focus, selection, and action into a single opaque success state.

### e) Helper-here and nearby spawn comfort
A launch sheet may already explain inheritance and downgrade.
An activation baton can separately explain whether the new lane should also take foreground now.

## 7) Tiny visible posture beats invisible magic

Schell does not need giant permission theater.
A tiny local strip is enough:
- `target exact`,
- `raise requested`,
- `active now`,
- `armed only`,
- `focus denied`,
- `history only`.

That one strip would make notification clicks, global shortcuts, browser returns, and chooser accepts feel dramatically more trustworthy.

## 8) Companion-cube pressure is strongly aligned here

- **SlopOS** already keeps OpenURI activation control shell/compositor-owned and refuses to treat open actions as portable foreground authority.
- **Steward** already says request-carried activation tokens remain freshness-scoped, one-shot, and clearly separate from lifecycle truth.
- **ViewFS** now explicitly argues that gesture evidence, activation batons, armed state, active control, and receipts should stay separate classes.
- **Harbor** keeps stoplines visible, which makes `focus denied` or `armed only` a useful risk confession rather than a product embarrassment.
- **Ward** keeps status and event receivers continuous, which suggests baton residue should be recoverable without pretending it is still live.

## 9) Great ideas worth stealing now

### a) Target-first wake-ticket cards
A notification card should first answer *what exact thing is this?* before it tries to focus anything.

### b) Baton chips on exact cards
Let chapter cards, receipt cards, or chooser rows show `baton present`, `spent`, or `expired`.

### c) Armed-not-active rails
A helper lane or review lane can show `armed only` until it actually owns active input.

### d) Refusal residue
Keep a tiny note like `target opened; foreground request refused` so the operator does not have to guess what happened.

### e) Focus-second defaults
Make `reveal exact target` the resilient default and `raise/focus` the optional second field.

## 10) What not to decide yet

Do **not** decide yet:
- one universal activation-token format,
- one final cross-platform foreground-control treaty,
- one final click-action doctrine,
- one final durable inbox/history system for baton residue,
- or one final shell↔terminal active-control protocol.

The smaller no-regret move is enough:
**give Schell an activation-baton witness family with target-first, focus-second posture, explicit armed-vs-active truth, and durable refusal residue so modern return/summon/open comfort stays brilliant without pretending that a click, token, or wake ticket already proved active control.**
