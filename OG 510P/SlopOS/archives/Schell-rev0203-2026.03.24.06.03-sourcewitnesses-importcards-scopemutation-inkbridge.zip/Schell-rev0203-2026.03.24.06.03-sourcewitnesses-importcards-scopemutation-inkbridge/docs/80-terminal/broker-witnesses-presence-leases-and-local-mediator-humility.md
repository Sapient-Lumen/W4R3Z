# Broker witnesses, presence leases, and local-mediator humility

This surface narrows the next seam modern CLIs keep rediscovering:
**local broker comfort is worth stealing, but “the broker approved”, “the app unlocked”, “a token was cached”, and “this shell now has current exact authority” are not the same fact.**

That seam matters even more because SlopOS is still in design phase.
If Schell gets this wrong early, the shell+terminal quietly grows a second invisible trust system made of broker residue, local app state, and fuzzy account assumptions.

## 1) Modern CLI auth is no longer just browser versus no browser

Current tools now mix several mediator families:
- **OS auth brokers** like Windows WAM,
- **desktop-app mediators** like 1Password CLI integration,
- **browser-first flows** that may still end in local sink choice,
- **cross-device relays** where another trusted machine finishes the browser step,
- and **credential sinks** such as keyrings, app-held sessions, disk caches, or plaintext fallback.

The right design lesson is not “support all auth flows”.
It is smaller.
A shell+terminal should become excellent at naming which mediator is active, what human presence just happened, what lease was created, what sink changed, and what exact account/profile became active here.

## 2) A compact broker witness is enough

Schell does not need a giant account subsystem to improve this seam.
A compact **broker witness** could keep fields such as:
- `broker_family` — none / OS broker / desktop app mediator / credential-store helper / browser helper / unknown,
- `presence_proof` — none / biometric / device-password / OS-account / hardware-key / unknown,
- `subject_scope` — exact account / tenant / profile / vault / subscription / unknown,
- `session_scope` — terminal-local / tab-local / window-local / host-local / profile-local / unknown,
- `session_lease` — one-shot / idle-TTL / hard-cap / refresh-on-use / unknown,
- `sink_posture` — broker-held / keyring / app-held / disk-cache / plain-file fallback / env-only / unknown,
- `adoption_posture` — pending / imported / active-binding-updated / historical / revoked / expired,
- `issuer_posture` — shell-known / host-mediated / provider-local / imported / unknown,
- `reveal_target` — exact card explaining what is live, what is historical, and what stronger act remains separate.

That is enough to make brokered auth dramatically more understandable without freezing one final broker, keychain, vault helper, or OS-specific secure-attention path.

## 3) The shell should be great at the parts current CLIs hide

Classic CLI auth often hides the most important local facts:
- the broker or mediator that actually asked for presence,
- whether the approval is scoped to this terminal or just this host,
- whether the lease refreshes on use,
- where the resulting session now lives,
- and whether the shell has actually adopted a new active account/profile.

Schell can do much better with small luxuries.

### a) Mediator chip
Show the exact mediator in play: `WAM`, `desktop app`, `system browser`, `remote bootstrap`, `none`, or `unknown`.

### b) Presence-proof chip
Show whether the operator used fingerprint, face, hardware key, OS password, or no local presence challenge at all.

### c) Lease card
If a local mediator established a refreshable session, show its scope, idle expiry, hard cap, and refresh posture.

### d) Subject card
Keep exact account / tenant / profile / vault / subscription separate from the mediator itself.
A nice broker is not the same thing as the chosen subject.

### e) Sink reveal
Show whether the resulting session lives in an app, keyring, disk cache, plaintext fallback, or environment-only lane.

### f) Adopt-into-shell barrier
Even after a broker says yes, keep `mediator approved` weaker than `active binding updated here`.
That avoids the common lie that pleasant broker UX automatically equals current shell authority.

## 4) Great ideas worth stealing now

### Per-terminal lease honesty
1Password’s terminal-local authorization idea is brilliant.
Schell should steal the honesty, not the exact implementation: this terminal, this subject, this lease, this expiry.

### Account-switch reveal
If the broker or mediator returns a different account/profile than the current shell intended, make that mismatch obvious before any stronger act.

### Reauth rails
Expired local lease, revoked app state, missing broker, stale disk cache, and subject drift should each point at a different retry rail.

### Historical fade
A broker approval or cache record from earlier should stay visible enough to diagnose but visibly weaker than a live current lease.

### Host-versus-terminal scope badges
A host-wide mediator session and a terminal-local approval should not look the same.
That one distinction will prevent a lot of false confidence.

## 5) The strongest lesson from SlopOS and the companion cubes

SlopOS keeps imported auth mechanics provider-local.
ViewFS keeps offers, handles, adopted objects, and live state separate.
Steward keeps retry posture exact.
Helm keeps historical success from flattering itself into present footing.

That combination points Schell at a very small rule:
**a local broker or mediator may create helpful evidence and helpful continuity, but it should not silently collapse mediator, presence proof, session lease, sink posture, and active shell authority into one generic success story.**

## 6) What Schell should refuse now

Schell should refuse:
- `broker approved` counting as durable shell approval,
- `app unlocked` counting as exact current account binding,
- `token cached` counting as active local authority in this terminal,
- `host-level SSO exists` counting as terminal-local footing,
- and `same mediator as before` counting as fresh proof for a different subject or different shell basis.

## 7) The no-regret move

The best move right now is not to freeze one broker stack, one vault architecture, one credential-store treaty, or one secure-attention path.
It is to pin one smaller rule:
**Schell should treat local brokers, presence checks, session leases, sink posture, and adopted current binding as a family of broker witnesses before modern CLI comfort quietly becomes a second hidden authority plane.**
