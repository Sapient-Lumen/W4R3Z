# Chapter inspectors, hover why, and rerun humility

**Schell should absolutely steal the best modern command decorations, hovers, output selection, and command-context attachment — but it should do so by making every chapter easy to inspect and explain instead of letting marks, history rows, or hover chrome quietly become a second shell.**

## 1) Why this seam matters now

The archive already has:
- command chapters,
- semantic marks,
- output capsules,
- outcome witnesses,
- execution-ground cards,
- recall aging,
- typed action ladders,
- and attach-for-help humility.

What is still worth isolating is the operator question that follows every clever command block:
**what exactly is this chapter, why does the shell think it knows that, what drift has happened since then, and why is the stronger next action allowed or refused?**

That question is becoming more important because the current terminal world is no longer satisfied with plain marks.
It keeps adding:
- command decorations,
- command hover details,
- select-whole-command or output affordances,
- richer scrollback search,
- attached command context for help lanes,
- and prompt-aware suggestions.

Those are all good moves.
They just need a stronger truth contract than “a pretty block exists.”

## 2) Learn the old lesson: hidden smartness rots first

The shell world keeps showing the same pattern.
When comfort features stay under-explained, they quietly choose semantics.
Startup hooks become execution ground.
Smart parsing becomes an invisible policy engine.
History rows start feeling executable even when the footing changed.
Selection or hover begins smuggling open/run authority.

So Schell should steal modern luxury under one stricter law:
**every stronger chapter affordance should be explainable in one cheap inspect path.**

That means a future custom shell+terminal should not say only:
- “this command succeeded,”
- “this looks rerunnable,”
- or “attach this to help.”

It should also be able to answer:
- why this chapter boundary is trusted,
- where the command identity came from,
- what footing was bound then,
- what footing is different now,
- and why stronger actions are currently allowed, downgraded, or blocked.

## 3) A chapter inspector is the right luxury object

The right center of gravity is not one hover tooltip and not one giant details panel.
It is one compact **chapter inspector object** that can project into multiple local views.

A chapter inspector should be able to expose at least:
- `chapter_identity` — exact chapter id plus source family,
- `provenance_grade` — shell-authenticated / shell-reported-relay-weakened / terminal-inferred / imported / spoof-suspect,
- `prompt_and_input` — exact reviewed input or the best weaker available representation,
- `command_identity` — exec identity, invoker footing, and parser/translation posture,
- `grounding` — cwd, env, activation, peer, subject, and repo basis witnesses,
- `timeline` — start, finish, duration, and whether those came from shell-owned or imported timing,
- `outcome` — exit family, pipeline-member truth, drain posture, and settlement posture,
- `typed_objects` — files, links, receipts, ports, errors, or object cards discovered inside the chapter,
- `freshness_and_drift` — what changed compared with current footing,
- `action_floor` — inspect / insert / attach / compare-current-basis / derive reviewed action / stronger rerun,
- `why_not` — the compact reason a stronger next act is downgraded or blocked.

That is already enough to make a chapter feel dramatically better than plain history.
It is also still architecture-light.

## 4) Hovers should stay cheap and local, not magical

Current terminals are teaching a useful pattern:
very small chapter chrome becomes much more valuable once hover reveals duration, exit posture, or captured output context.
Schell should steal that.

But the hover should stay cheap.
A good chapter hover might show only:
- provenance grade,
- start/duration/outcome summary,
- current drift summary,
- strongest honest next verbs,
- and one `why?` / `why not?` affordance.

That keeps the first reveal humane without hiding expensive lookup, route resolution, or replay policy inside the hover itself.
The hover is a summary surface.
The inspector is the exact object.
Stronger acts still happen somewhere else.

## 5) “Why this chapter?” is as important as “Run again”

One of the best moves Schell can make is to normalize a tiny explanation lane.
The shell+terminal should be able to answer:
- why this boundary is exact or inferred,
- why these output lines belong to this chapter,
- why this cwd/env/peer/subject context is attached,
- why this output token became a typed object card,
- why this chapter is still fresh enough for compare,
- and why the current action floor is inspect-only, insert-first, or rerun-after-review.

This is a very current opportunity.
Most tools are getting better at command blocks.
Far fewer are making those blocks legible enough to trust under drift.

## 6) “Why not rerun?” should become a first-class answer

History systems often fail at the exact moment the operator wants speed.
The row looks runnable.
The footing changed.
The UI offers either false confidence or a vague refusal.

Schell should do better with a compact **rerun guard explanation**.
A chapter should be able to say things like:
- repo basis drifted,
- peer changed,
- cwd moved,
- activation overlay expired,
- env source changed,
- authority wallet narrowed,
- output object was historical/imported only,
- provenance grade too weak for strong replay,
- or settlement never reached the durable/adopted state you probably wanted.

That makes the shell feel strict in the useful way.
The refusal becomes legible and actionable instead of ceremonial.

## 7) The most super-awesome moves this seam unlocks

### 7.1 Hover summaries over command chapters

A chapter badge or gutter mark can reveal:
- provenance,
- duration,
- exit family,
- current drift,
- and strongest honest next verbs.

This is an unusually high leverage steal because it gives immediate delight without forcing one final database or protocol.

### 7.2 Expand-to-inspector from any chapter

Any chapter row, chapter-browser hit, timeline row, or hover can open the same exact inspector object.
That keeps chapter truth stable while views multiply.

### 7.3 Watch this exact chapter

The operator should be able to attach attention to one chapter object rather than one whole tab or one vague process name.
Useful watch outcomes include:
- chapter finishes,
- settlement changes,
- output continues after a long quiet gap,
- stronger typed object appears,
- or current footing drifts before a deferred next act.

### 7.4 Compare chapter footing with current footing

A chapter inspector should make current drift obvious.
That means side-by-side cards for:
- then-cwd vs now-cwd,
- then-peer vs now-peer,
- then-repo basis vs now-basis,
- then-env layer sources vs now-sources,
- then-authority summary vs now-summary.

This is where ViewFS pressure becomes genuinely exciting.
It makes compare-before-rerun feel precise rather than preachy.

### 7.5 Attach exact chapter context to help or review lanes

Attaching a chapter to a help lane is one of the clearest modern steals.
But Schell should make the attached object exact and explainable:
- exact or graded command text,
- selected or whole output capsule,
- outcome witness,
- grounding witnesses,
- drift summary,
- redaction posture,
- and current action floor.

That is a much stronger and safer move than copy/paste folklore.

### 7.6 Typed object ladders inside the inspector

The inspector should not auto-open every detected object.
Instead it should show typed object ladders such as:
- reveal exact source,
- inspect object card,
- insert path/ref,
- attach object,
- safe-open,
- derive reviewed action,
- stronger execute/open only after review.

### 7.7 Freshness halos and aging-down action floors

Chapter luxury gets safer when freshness becomes visible.
A chapter that was shell-authenticated twenty seconds ago on the same peer may deserve compare or derive.
A chapter that is two days old, imported, and basis-drifted should age down to inspect or insert.

The shell should make that downgrade feel natural instead of punitive.

## 8) Companion-cube pressure makes this better, not heavier

This seam becomes stronger when read as a datacube companion rather than a standalone terminal feature pile.

- **SlopOS** says exact launch footing already exists; the inspector should reveal it rather than recreate it from folklore.
- **ViewFS** says visible object, basis, delta, and adopted result are not one thing; chapter inspect should preserve that split.
- **Helm** says acceptance, exit, drain, durable receipt, and downstream adoption are different endings; chapter inspectors should surface settlement cards.
- **Harbor** says stronger actions should climb risk ladders rather than teleport from history to execution.
- **Foundry** says overlays/config activation are mutable ground and should be visible as gates, not silently reinstated.
- **Ward** and **Steward** say watches and live status should be source-labeled, freshness-bearing, and lease-shaped.

The inspector is where those pressures become operator-comprehensible.

## 9) What Schell should refuse for now

Refuse for now:
- one giant universal chapter schema that decides every future storage and sync detail,
- one final hover/inspector rendering stack,
- one assumption that all chapters will always be shell-authenticated,
- one policy that every inspector-opened object can also be opened or rerun,
- or one promise that attaching a chapter to help is the same thing as granting execution authority over it.

Those are closure moves.
The better move is to prove small specimens.

## 10) First specimen set this seam wants

A good first proof set would show:
1. one shell-authenticated chapter with a cheap hover summary,
2. one inferred or relay-weakened chapter with visibly lower action floor,
3. one chapter inspector exposing exact exec/cwd/env/outcome links,
4. one `why this chapter?` explainer,
5. one `why not rerun?` refusal that points at real drift,
6. one compare-current-basis card,
7. one watch-this-exact-chapter affordance,
8. one attach-for-help bundle with redaction posture,
9. one settlement card separating exit from downstream adoption,
10. and one typed object ladder that stops at inspect/insert/attach before stronger acts.

## 11) The no-regret next move

The strongest next move is not to choose the final chapter store or hover protocol.
It is smaller:

**prove one chapter inspector object with hover summary, why/why-not lanes, compare-current-basis cards, watch-exact-chapter affordances, and attach-for-help bundles so Schell can feel super awesome without letting command decorations, history rows, or marks quietly become a second shell.**
