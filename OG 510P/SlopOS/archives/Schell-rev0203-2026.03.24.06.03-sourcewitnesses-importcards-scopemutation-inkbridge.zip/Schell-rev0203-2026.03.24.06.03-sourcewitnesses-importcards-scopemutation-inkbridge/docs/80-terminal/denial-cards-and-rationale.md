# Denial cards and rationale

This surface narrows what a humane denial should teach without turning denial help into hidden authority synthesis.

## Shell truth a denial must preserve

A denial card or block should preserve at least:

- attempted action,
- exact object or artifact reference,
- what was missing,
- whether retry is safe,
- the narrowest likely-successful next request,
- and the denial handle needed for later explanation or replay comparison.

## Good denial posture

A good Schell denial should be:

- **specific** about the missing scope,
- **local** to the stage or action that failed,
- **honest** about whether the system knows the likely next step,
- **non-widening** unless the operator explicitly asks to broaden the request,
- and **cheap to revisit** later through a denial handle.

## What should stay out

- auto-approve,
- auto-edit of the reviewed action,
- silent widening from one-shot to durable access,
- and giant policy essays that make the original task harder to understand.

## Local luxury UX candidates

A richer terminal may add:

- denial shelves,
- jump-to-missing-scope explanation,
- compare requested vs granted scope,
- and one-click reopen into a narrower revised review card.

## Prototype success condition

A first-time operator should be able to answer these after reading one denial:

- What failed?
- What exact thing was affected?
- What is missing?
- Is it safe to try again?
- What is the smallest changed request that might work?
