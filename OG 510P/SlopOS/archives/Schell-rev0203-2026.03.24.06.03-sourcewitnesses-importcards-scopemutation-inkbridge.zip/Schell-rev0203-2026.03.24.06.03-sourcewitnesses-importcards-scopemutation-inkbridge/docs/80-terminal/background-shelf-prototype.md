# Background shelf prototype

This surface narrows what a Schell background shelf should mean without importing legacy job-control semantics.

## Shell truth the shelf must preserve

A background shelf entry should preserve at least:

- request id,
- live-grant state,
- requested action summary,
- current expiry / TTL,
- autostart posture,
- last receipt or denial handle,
- and whether the current live state differs from the last reviewed request.

## Semantic transport pressure

The shell↔terminal boundary should be able to signal:

- shelf entry created,
- shelf entry changed,
- shelf entry expired,
- shelf entry revoked,
- and shelf entry promoted or denied.

These should be reference-heavy signals, not giant payload dumps.

## Local luxury UX candidates

A richer terminal may add:

- a side shelf,
- quick jump to last state change,
- renew / revoke affordances,
- receipt preview,
- and highlighting for state drift since review.

## What this explicitly refuses

- calling these entries `jobs` by default,
- pretending request state and live state are the same,
- or treating `&`, `bg`, and `fg` as honest operator metaphors before the semantics actually match.

## Prototype success condition

A plain text transcript should still make it obvious:

- what was requested,
- what is live now,
- why it changed,
- and what the operator can safely do next.
