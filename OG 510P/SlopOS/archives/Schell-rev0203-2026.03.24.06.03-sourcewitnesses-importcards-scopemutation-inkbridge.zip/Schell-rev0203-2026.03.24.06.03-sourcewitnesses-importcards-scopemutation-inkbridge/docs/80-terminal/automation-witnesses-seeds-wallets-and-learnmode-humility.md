# Automation witnesses, workflow seeds, wallets, and learn-mode humility

This surface records a new no-regret candidate cluster for Schell:
**make reviewed automation feel luxurious without letting saved commands, workflow search, or learn reports become a second execution plane.**

The pressure here comes from multiple directions at once:
- SlopOS D-CAPSHELL keeps automation explicit, wallet-scoped, and exact at the execution boundary,
- SlopOS D-PLUMB keeps intent routing canonical but non-authoritative,
- current terminals keep proving that command blocks, command palettes, captured output, and quick summon are humane,
- and current workflow products keep proving that command reuse becomes dangerous the moment selection silently means execution.

## 1) Keep the nearby objects separate

Schell should probably distinguish at least six nearby things:

- **command chapter** — one exact shell-known past action,
- **workflow seed** — a reusable scaffold with named parameters and provenance,
- **reviewed automation pack** — a stronger future-run candidate with explicit execution footing,
- **learn report** — an observational-only explanation of what was missing or denied,
- **live automation run** — one current execution with current wallet/peer/ground truth,
- **receipt / denial** — the durable post-run or refused-action object.

These are related.
They are not the same object.

## 2) Search and palette comfort should land in review first

One of the best current product ideas is searchable reusable commands with visible arguments.
Schell should absolutely steal that class of move.

But the safe version is:
- search finds a seed,
- selecting it lands it into active input or a review card,
- parameter fill remains editable,
- current drift and wallet posture are shown,
- and only then can execution be requested.

That makes workflow luxury feel fast without turning selection into hidden approval.

## 3) Captured output is a ladder, not a trapdoor

Captured-output decks, semantic rows, and chapter-linked highlights are excellent.
They become dangerous when a row hit quietly sends text as though typed or silently runs the nearest helper.

The safer ladder is:
- inspect row,
- reveal exact chapter,
- derive seed,
- insert into input,
- or build a fresh reviewed action.

If a stronger action is offered, it should say exactly why it is admitted.

## 4) A reviewed automation pack needs exact footing

A reusable command artifact should preserve more than command text.
A compact reviewed-automation pack could preserve:
- `source_ref` — exact chapter / runbook / imported artifact,
- `source_kind` — operator / workflow / proposal / imported / replay,
- `exec_selector_ref` — the exact interpreter or executable footing expected,
- `code_input_ref` — when code-bearing input is distinct from the interpreter,
- `wallet_baseline_ref` — current or last-reviewed wallet summary,
- `ground_ref` — cwd / env / activation / peer footing,
- `drift_posture` — same / widened / drifted / unknown,
- `parameter_slots[]` — named, typed, still-editable inputs,
- `review_requirement` — insert-only / review-first / exact-rerun-possible,
- `transcript_expectation` — what durable text truth should remain.

That keeps reusable automation much more honest than aliases while remaining much smaller than a full workflow platform.

## 5) Learn mode should teach without widening

SlopOS is extremely clear that learn mode is observational only.
Schell should import that discipline directly.

A learn report may show:
- missing wallet capability families,
- missing exact handles or object bindings,
- stage-local denials,
- likely smaller-successful next requests,
- or current drift between saved footing and live footing.

A learn report is **not**:
- an approval,
- an auto-edit,
- an auto-request,
- an auto-rerun,
- or a hidden policy memory object.

The right emotional target is:
**helpful enough to reduce frustration, strict enough to preserve review truth.**

## 6) Wallet strips and diff cards belong on the automation path

A super awesome shell+terminal should not make people infer current power from prompt mood.
Reusable automation especially needs compact authority cues.

At minimum Schell should show:
- wallet digest or short id,
- widening or drift posture,
- lease hints when relevant,
- exact diff card when power must rise,
- and whether the current footing came from direct review, restore, proposal, or imported context.

This is one of the cleanest places to make the custom shell+terminal feel obviously better than bash.

## 7) Journal hygiene matters more once commands are reusable

The archive already knows that command chapters, direct work, proposal work, and receipts should stay separately named.
Reusable automation makes that even more important.

A good default would keep distinct journal classes for:
- direct operator chapters,
- proposal-lane chapters,
- imported or external artifacts,
- workflow seeds,
- and live automation runs.

Promotion between those classes should be explicit.
Otherwise the most convenient search surface becomes the easiest place for hidden authority drift.

## 8) Quick summon can become the humane automation cockpit

Schell should probably steal quick-terminal / cockpit luxury aggressively.
A fast summon surface is one of the most obviously delightful available moves.

But the cockpit should remain honest about what it is showing:
- live runs,
- pending reviews,
- seeds,
- learn reports,
- denials,
- and receipts.

It should help an operator jump quickly between those things without flattening them into one “go do it again” menu.

## 9) Things Schell should steal now

### Review-landed workflow search
Searchable named commands with visible descriptions and parameter slots are a real win.

### Chapter-to-seed promotion
Harvesting reusable structure from exact command chapters is safer than starting from raw snippets.

### Captured-output decks tied to chapters
Warnings, errors, and interesting rows should not die as scrollback.

### Tiny authority strips and diff cards
Automation should make power more visible, not less.

### Quick summon for automation state
A compact cockpit for seeds, pending reviews, denials, and live runs is high-value and still reversible.

## 10) Things Schell should refuse

### Refuse palette-select equals execute
Search should be fast.
Execution should still be explicit.

### Refuse learn-report equals policy memory
A helpful suggestion should not silently become a lasting grant.

### Refuse saved seed equals current authority
A familiar command does not prove current wallet, peer, or ground match.

### Refuse hidden interpreter fallback
Reusable automation should not quietly rediscover meaning through shebang/env/path folklore.

### Refuse one giant workflow bureaucracy first
One seed object, one reviewed-automation pack, one learn report, and one cockpit view are enough to learn a lot.

## 11) No-regret first specimen set

A compact first cut could show:
1. one exact command chapter promoted into a workflow seed,
2. one workflow search result that lands into review rather than execution,
3. one reviewed automation pack with explicit exec selector, wallet baseline, and drift posture,
4. one learn report that explains a denial without widening authority,
5. one wallet diff card for a stronger rerun attempt,
6. and one transcript slice showing seed selection → parameter fill → review → admit or deny.

That is enough to make Schell feel substantially more powerful than shell folklore without freezing a final workflow engine, notebook product shape, sync model, or automation policy language.
