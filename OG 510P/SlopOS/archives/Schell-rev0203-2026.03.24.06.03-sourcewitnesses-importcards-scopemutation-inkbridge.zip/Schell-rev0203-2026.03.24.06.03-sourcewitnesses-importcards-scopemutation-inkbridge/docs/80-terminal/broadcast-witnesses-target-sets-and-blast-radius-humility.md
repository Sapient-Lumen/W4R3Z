# Broadcast witnesses, target sets, and blast-radius humility

This surface exists to keep one especially seductive luxury bundle honest:
**Schell should absolutely steal broadcast input, selected target groups, and reviewed fanout comfort — but it must not let one keystroke silently become hidden fleet authority.**

The point is not to avoid multi-target work.
The point is to keep it legible.
A shell+terminal can feel dramatically better when a few panes, hosts, replicas, or workers can be touched together.
It becomes dangerous when the operator can no longer tell whether they are mirroring keystrokes into a local set of panes, running one exact reviewed action across a fixed target set, or launching durable background work whose members may already have diverged.

## 1) Keep broadcast input weaker than reviewed fanout execution

At minimum, Schell should separate:
- **broadcast input**,
- **targeted per-member input**,
- **reviewed fanout execution**,
- **rolling/waved multi-target execution**,
- and **durable background multi-target work**.

Those actions are adjacent.
They are not interchangeable.
Broadcast input is a local interactive convenience.
Reviewed fanout execution is a stronger admitted action with per-target execution truth.
Durable background work is stronger again.

## 2) A target-set witness should describe actual footing

A healthy target-set witness should carry things like:
- target identities,
- membership source or selection reason,
- target count,
- scope or route (tab, pane group, peer set, host set, worker set),
- arm/disarm state per member,
- divergence hints,
- per-member parameter posture,
- blast-radius posture,
- and timeout/cancel honesty posture.

It should also make clear what it is **not**:
- not proof that all targets are semantically equivalent,
- not proof that all targets are still live,
- not proof that all members remain in the set forever,
- and not proof that one cancellation gesture stopped every target.

## 3) Broadcast input should be an armed local lane

A strong broadcast-input lane should say:
- which members are armed,
- which members are disarmed,
- whether the current pane itself is armed,
- how the scope was chosen,
- and how to end the session quickly.

The operator should be able to unplug one member without destroying the whole set.
The system should prefer an obvious “armed” indicator over invisible magic.

## 4) Divergence warnings matter more than glamour

Targets often diverge.
One pane may be at a shell prompt.
Another may be in a pager.
Another may be at a password prompt.
Another may have a file open at a different cursor position.
Another may be running a different host profile entirely.

So Schell should support divergence warnings like:
- interactive-fullscreen target,
- editor/pager mode,
- waiting for hidden input,
- target no longer at prompt,
- target identity drift,
- or target membership drift.

Broadcast luxury is still valuable in the presence of warnings.
It just should not pretend the warnings are irrelevant.

## 5) Per-target parameter fills should be stronger than plain mirroring, but weaker than hidden fleet automation

Sometimes the operator wants:
- the same bytes to every member,
- and sometimes they want one field to vary per member.

That difference should stay visible.
A targeted fill should say that the target-set witness now includes **per-member values**.
That makes it stronger than simple mirrored typing.
But it should still stay visibly weaker than durable workflow automation or background orchestration.

## 6) Blast radius should be explicit before stronger admission

For reviewed fanout actions, the shell+terminal should show things like:
- member count,
- member class,
- action strength,
- whether secrets are involved,
- whether ordering matters,
- and whether the action is foreground-only or may outlive the current local lane.

One command touching one target is not the same thing as one command touching twelve targets.
The system should say so.

## 7) Keep multi-target verbs separate

Schell should not collapse all multi-target moves into one “run everywhere” button.
At minimum, the verbs should stay separately named:
- inspect target set,
- arm member,
- disarm member,
- mirror input,
- send targeted input,
- review fanout command,
- run on all armed members,
- run as rolling wave,
- stop waiting,
- request remote stop,
- and promote to durable background job.

Those verbs imply different risk and different truth.
The shell+terminal should say so.

## 8) Secret-bearing fanout deserves stricter posture

A hidden local echo or masked local entry field is not enough to make bulk secret fanout feel safe.
If secret-bearing data is going to multiple targets, Schell should prefer a stricter lane:
- explicit secret-bearing badge,
- explicit target count,
- explicit non-recording or residue posture,
- or even outright refusal for ordinary broadcast input.

The rule should be:
local masking is not equivalent to multi-target secret safety.

## 9) Outcomes should become per-target truth, not one blended summary myth

For stronger reviewed fanout execution, Schell should prefer per-target results such as:
- target identity,
- exact command form,
- stdout/stderr availability,
- exit code,
- exception or transport failure,
- completion state,
- and cancellation/timeout posture.

A good summary row can still exist.
But it should stay derived from explicit per-target truth.

## 10) Timeout and cancellation need humility

A timeout may mean the controller stopped waiting.
It may not mean the remote target stopped running.
A cancellation request may be issued.
It may not mean every target honored it.

So Schell should distinguish:
- controller wait ended,
- stop request sent,
- remote stop confirmed,
- target unreachable,
- and target may still be running.

That is much more honest than one generic timeout/cancel badge.

## 11) A compact first proving slice

A compact first specimen should show:
1. one local pane-broadcast witness with explicit members,
2. one temporarily disarmed member,
3. one divergence warning because a member is not in a safe interactive footing,
4. one per-target parameter-fill variant,
5. one stronger reviewed fanout card with exact target set and exact command shape,
6. one blast-radius badge before admission,
7. one mixed outcome table with exit and exception columns,
8. one timeout result that says controller wait ended but remote liveness remains uncertain,
9. and one refusal path for secret-bearing bulk injection.

That is enough to make Schell feel unusually capable without freezing the final inventory model, orchestrator, transport stack, or cluster policy engine.

## 12) Things to refuse for now

Refuse for now:
- one generic “run everywhere” action that hides whether the move is mirroring, fanout, rolling apply, or background orchestration,
- target groups that silently refresh to a newer membership than the reviewed set,
- multi-target cancellation wording that overclaims remote-stop truth,
- secret-bearing bulk injection treated as ordinary broadcast input,
- and helper-owned inventory or hidden policy that silently widens shell authority.

The right law is:
**steal broadcast input, selected target groups, and reviewed fanout luxury — but keep exact target shape, divergence warnings, blast-radius posture, and per-target outcome truth visibly stronger than charm.**
