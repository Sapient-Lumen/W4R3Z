# Borrowed screen leases, shell reentry, and prompt-reclaim humility

**Schell should absolutely steal full-screen/TUI comfort, active-prompt clicks, semantic prompt jumps, and command-aware output browsing — but it must not let a visible prompt or restored normal screen impersonate fresh shell-owned footing after the screen was borrowed by something else.**

## 1) Why this seam matters

A modern shell+terminal becomes dramatically better the moment it can:
- let `vim`, `less`, `top`, fuzzy finders, monitors, agentic CLIs, and other resident rooms borrow the screen without feeling scary,
- preserve useful residue or prompt jumps when they give the floor back,
- support prompt-click and prompt-local editing luxuries when a live prompt is really present,
- and keep copy/search/history comfort nearby instead of forcing the operator to mentally reset everything from scratch.

But this is also exactly where terminal folklore overclaims.
A prompt-like line can be historical residue.
A normal screen can be visible before the shell has reasserted baseline.
Mouse or wheel behavior can still reflect borrowed-screen posture.
And command-local browsing or sticky prompt chrome can accidentally flatter whatever region happens to be on screen.

So Schell should treat **borrowed screen ownership** and **shell reclaim** as explicit first-class witnesses.

## 2) Keep these truth families separately named

At minimum Schell should keep these distinct:

1. **borrowed screen lease** — some foreground app, room, or relay currently owns the visible floor
2. **normal-screen return** — the alternate/full-screen lease appears to have ended
3. **prompt-like residue** — a line looks like a prompt, but shell truth is weak or inferred
4. **prompt reclaim witness** — the shell or trusted semantic marks say the prompt is live again
5. **baseline reassertion** — the shell has explicitly re-established the local prompt/mode baseline it depends on
6. **reset-required card** — the shell can name what still needs reset before strong prompt-local luxuries are honest
7. **completion / receipt / chapter close** — a different stronger truth family that should stay separate from mere floor handback

These can happen near each other.
They should not collapse into one flattering “the prompt came back.”

## 3) The screen can be borrowed without becoming shell truth

Alternate-screen life, full-screen TUIs, pagers, editors, copy modes, and resident rooms all borrow pieces of the floor.
That can be wonderful.
Schell should lean into it.

But the shell should still know:
- who seems to own the floor now,
- whether the visible region is main screen, alternate screen, or replay residue,
- whether local gestures are being routed to the app or the terminal,
- and whether any live prompt affordance is based on shell marks or only on visual inference.

That is the difference between a shell+terminal that feels luxurious and one that quietly lies.

## 4) Prompt reclaim is a stronger event than normal-screen return

A useful compact rule is:
**normal-screen return is weaker than prompt reclaim, and prompt reclaim is weaker than baseline reassertion when stronger prompt-local affordances depend on it.**

That means Schell could honestly show postures like:
- `borrowed floor live`,
- `normal screen returned`,
- `prompt-like residue`,
- `shell-marked prompt reclaim`,
- `baseline reasserted`,
- `reset required`,
- `historical only`.

The shell does not need to be melodramatic about this.
It only needs to refuse the old habit of letting one visible prompt-like line settle every nearby truth question.

## 5) Prompt-local luxury should key off reclaim confidence

Current terminals already point toward the right split.
Prompt clicks, cursor repositioning, jump-to-prompt, command-aware output browsing, sticky prompt chrome, and prompt-local editing are all terrific ideas.

But in Schell they should ride on reclaim confidence:
- **visual-only** — prompt-like residue; no strong edit/click promises
- **mark-assisted** — shell integration or semantic marks exist, but footing is not yet fully reasserted
- **shell-reclaimed** — live prompt witness is strong enough for prompt-local luxuries
- **baseline-reasserted** — shell can safely offer stronger prompt-local or helper-local affordances that depend on fresh footing

This keeps the UX excellent without teaching operators that every visible prompt is equally alive.

## 6) A small v0 borrowed-screen witness is enough

Schell does not need one final TUI broker, alt-screen capture treaty, or prompt-mark protocol to get value.
A compact v0 witness could keep:
- `screen_lease_id`,
- `owner_kind` — shell / fullscreen_app / resident_room / relay / copy_overlay / unknown,
- `display_family` — main / alternate / replay / residue / unknown,
- `return_posture` — not_returned / normal_screen_returned / prompt_like / prompt_reclaimed / baseline_reasserted / reset_required / historical,
- `gesture_posture` — wheel_scrollback / wheel_to_app / app_mouse / prompt_click / blocked / unknown,
- `mark_confidence` — shell_known / semantic_marked / injected / inferred / none,
- `promotion_options` — reveal chapter / reopen exact output / freeze residue / copy excerpt / reset baseline / stay historical.

That is enough to power much better behavior while keeping the final renderer, event model, and PTY-control stack open.

## 7) Reentry cards and reset cards should be tiny and exact

A **prompt reclaim card** should say something like:
- which room/app/lease released the floor,
- whether return was ordinary, abrupt, or ambiguous,
- what evidence says a live prompt exists again,
- and what stronger affordances just became available.

A **baseline reassert card** should say:
- which marks or modes were freshly re-established,
- what changed compared with the pre-borrow baseline,
- and what still remains degraded or blocked.

A **reset-required card** should say:
- what exact floor/mode/prompt basis is missing or contradictory,
- whether the shell can repair it locally,
- and which luxuries remain intentionally downranked until that happens.

That is much better than a dead click target, ghost prompt, or silently overconfident sticky chrome.

## 8) Super-awesome ideas worth stealing now

- active-prompt click-to-move only after reclaim,
- jump-to-prompt and command-output browsing that confess mark strength,
- tiny borrowed-floor strips showing `app owns floor`, `shell reclaim pending`, or `baseline reasserted`,
- alt-screen exit cards that say `residue only` versus `exact chapter available`,
- one-command “reset baseline” rails when full-screen life strands modes or marks,
- and side-by-side `prompt returned` versus `command completed` chips so finish and handback stop impersonating each other.

The especially good Schell twist would be:
**make borrowed-screen handback feel elegant while still naming the stronger thing the operator is waiting for.**

## 9) What to refuse for now

Refuse for now:
- any rule that a visible prompt line is enough for strong prompt-local actions,
- any flattening of floor handback into command completion or receipt truth,
- any hidden carry-forward of borrowed-screen state as unquestioned shell baseline,
- and any terminal-local sticky chrome that keeps pretending a region is an active shell prompt after confidence dropped.

## 10) Bounded conclusion

The no-regret move is smaller than it sounds:
**treat fullscreen or room-owned screen time as a borrowed lease, treat prompt return as a reclaim witness rather than a magical reset, and keep baseline reassertion or reset-required posture explicit before stronger prompt luxuries fire.**

That is enough to make Schell feel unusually polished without deciding the whole shell+terminal architecture too early.
