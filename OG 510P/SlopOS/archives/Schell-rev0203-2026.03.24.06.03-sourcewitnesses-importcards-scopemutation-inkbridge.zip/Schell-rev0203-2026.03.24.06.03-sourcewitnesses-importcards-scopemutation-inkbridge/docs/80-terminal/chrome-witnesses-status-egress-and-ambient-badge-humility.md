# Chrome witnesses, status egress, and ambient-badge humility

This surface names another easy place for a shell+terminal to become brilliant or misleading:
**ambient chrome outside the pane can make the operator experience dramatically better, but tab titles, badges, titlebar pills, dock/taskbar indicators, and status strips should remain projections of exact shell-owned truth rather than becoming truth by themselves.**

A custom shell+terminal can feel super awesome here.
It can show the current peer, cwd, git branch, running progress, review-needed state, or historical/restored caution without requiring the operator to stare at one pane.
That is real value.
But if Schell does not keep this seam explicit, the title bar and taskbar will slowly become a second folklore status system.

## 1) Ambient chrome is a different lane from transcript, pane, and notification

At least four nearby surfaces exist:
- **in-pane status** — exact shell output, cards, receipts, and review surfaces,
- **ambient chrome** — title, tab text, badges, titlebar pills, dock/taskbar indicators, status strips,
- **transient notification** — toast, banner, finish notice,
- **durable history** — transcript, receipt, journal, residue shelf.

Those surfaces can cooperate.
They should not collapse.
A command-finished badge is not the receipt.
A taskbar progress ring is not the progress scope.
A tab title showing `prod` is not exact peer proof.
A titlebar pill saying `needs review` is not durable acknowledgement state.

## 2) Schell should mint a small chrome witness before it projects status outward

A useful first move is one shell-owned **chrome witness**.
This is smaller than a whole notification center or desktop API.
It is just a bounded object saying what status the shell is willing to project into local chrome.

A v0 chrome witness could keep:
- `subject_ref` — exact command chapter / progress scope / review card / peer witness / execution ground / service witness,
- `origin_posture` — shell-known / workflow-known / renderer-derived / restored / imported / historical,
- `claim_kind` — identity / progress / warning / problem-count / review-needed / completion-hint / historical-caution / service-exposure / unknown,
- `claim_strength` — exact / bounded-summary / inferred / local-only,
- `chrome_targets[]` — tab-title / window-title / tab-badge / titlebar-pill / dock-badge / taskbar-progress / status-strip / request-attention,
- `freshness_posture` — current / current-but-local / restored / historical / unknown,
- `clear_rule` — clear-on-focus / clear-on-input / clear-on-state-transition / manual / ttl / unknown,
- `transcript_summary` — text-safe one-line summary.

That is enough to keep chrome helpful without freezing one graphics/window-manager stack.

## 3) Identity summaries should stay clearly weaker than exact identity

One of the niftiest ideas to steal is ambient orientation:
- current host,
- cwd,
- git branch,
- current foreground job,
- remote/local posture,
- or `prod` / `staging` / `quarantine` warnings.

Those are excellent title/badge candidates.
But Schell should never let them silently outrank exact peer witnesses or execution-ground witnesses.

The rule should be simple:
**chrome may summarize identity; exact objects still own identity.**

That means a tab title can say `ssh: prod` and still remain weaker than the exact peer card.
It also means restored titles should degrade until the current peer is re-proved.

## 4) Progress egress should be explicit and shell-owned

Taskbar rings, tab progress, and tiny titlebar pills are among the best things modern terminals and IDE-terminals do.
Schell should steal that.
But progress egress should begin from exact progress scopes, not from PTY heuristics.

A good compact ladder is:
- `running-indeterminate`,
- `running-fractional`,
- `running-warning`,
- `running-error`,
- `completed-clearable`,
- `historical-progress`.

The main discipline is:
- progress chrome can summarize,
- progress chrome can go quiet when the operator returns,
- but it does not become the durable account of what the work concluded.

## 5) Review-needed and hold state deserve ambient surfacing too

One genuinely great move for Schell would be ambient review surfacing.
Examples:
- a tab badge for `1 review needed`,
- a titlebar pill for `hold card raised`,
- a status strip cell for `permission denied`,
- a quiet dock/taskbar mark for `background lane needs input`.

This is better than making the operator poll every pane.
But these should still jump back to exact objects.
Clicking the badge or pill should usually reveal the review card, hold card, or receipt rather than granting approval or hiding the problem.

## 6) Chrome egress should be progressive enhancement, not portable truth

Different terminals and desktops support different things:
- some have tab bars,
- some have taskbar progress,
- some have dock badges,
- some have titlebar pills,
- some only have the pane.

So Schell should keep the portable center tiny.
The shell emits exact chrome witnesses.
The renderer projects them locally when it can.
If a platform cannot express a given target, the witness does not lose meaning; it just projects to fewer places.

That prevents chrome semantics from being held hostage by any one emulator's proprietary control sequence.

## 7) Restore and replay need explicit downgrade posture

This is a subtle but important lesson from the past.
Terminal chrome lingers.
Old titles, old badges, old progress states, old status strips, and remembered tab names can stick around long after the truth changed.

So restored chrome should carry visible posture such as:
- `historical title`,
- `restored progress`,
- `old peer summary`,
- `needs refresh`,
- `renderer-local only`.

That one small downgrade family would make a custom shell+terminal much more trustworthy.

## 8) Great steals that still stay decision-light

### a) Ambient orientation
A tab can show host, cwd, job, and lane posture from exact shell-known witnesses.

### b) Taskbar/dock progress
Long-running builds, deploys, and downloads can project a tiny shell-owned progress witness outward.

### c) Quiet warning badges
A tab or dock badge can show review-needed, denied, or waiting-input without popping a full notification.

### d) Local status strip
A small strip can show one current progress scope, one problem count, one peer summary, and one historical/restored caution.

### e) Clear-on-focus behavior
Some chrome should auto-clear or downgrade when the operator focuses the window or returns to the relevant lane.
That keeps ambient signals helpful instead of sticky folklore.

## 9) The no-regret move

The best move right now is not to freeze one desktop-integration API or one badge taxonomy.
It is to pin one rule:
**Schell should model ambient terminal chrome as a projection lane for exact shell-owned chrome witnesses, with explicit freshness and claim-strength posture, before titles, badges, pills, and taskbar progress quietly become a second truth system.**

That keeps the archive free to defer:
- one final escape-sequence set,
- one final title/badge vocabulary,
- one final cross-platform desktop API,
- one final status-strip layout,
- and one final policy for how many ambient signals can be visible at once.
