# Composition witnesses, preedit clauses, and text-commit humility

**Schell should absolutely steal excellent text-entry comfort — IME support, dead-key handling, clause/candidate UI, composition-aware cursors, grapheme-correct rendering, and layout-aware commit hints — but it must not let visible preedit state, candidate windows, or display-width heuristics flatten into one flattering “the text looked right, therefore the shell received exactly that” story.**

## 1) Why this seam matters

A super-awesome shell+terminal gets dramatically better the moment it handles real text entry well:
- dead keys and AltGr feel ordinary instead of fragile,
- IME preedit text is readable and visually anchored,
- candidate/clauses stay understandable while composing,
- emoji and combining marks stop breaking cursor placement,
- and prompt/editor comfort works across more languages and layouts.

But this is also a classic place where terminals and shells lie by accident.
A visible preedit underline is not yet committed shell text.
A clause cursor is not the shell cursor.
A user-perceived character is not always one code point.
A glyph that seems to occupy one cell is not always measured the same way by every application.

Schell should therefore keep at least these families separately named:
- **composition/preedit state**,
- **live editable buffer text**,
- **candidate/clauses owned by the OS or IME**,
- **committed text that actually entered the shell/editor buffer**,
- **measured display width/grapheme posture**,
- and **later exact parse / argv / reviewed action truth**.

## 2) The historical lesson: text entry is a state machine, not a stream of innocent keys

The current terminal ecosystem keeps proving the same thing.
Text entry is not just “a key happened.”
Some layouts hold a dead key and wait.
Some IMEs hold a whole clause, show candidates, and only later commit text.
Some systems expose composition state in the terminal UI.
Some terminals still need compatibility knobs because applications disagree about how many cells a user-perceived character should occupy.

The design lesson is not “avoid IMEs” or “pick one width algorithm and force everyone to adapt.”
It is:
**never let preedit state, candidate UI, committed buffer text, and measured display width collapse into one hidden truth object.**

So Schell should carry explicit composition posture badges such as:
- `preedit-none`,
- `preedit-dead-key`,
- `preedit-ime`,
- `candidate-owned-by-os`,
- `candidate-owned-by-ime`,
- `commit-pending`,
- `text-committed`,
- `grapheme-measured`,
- `compat-width-mode`.

## 3) Preedit is a local promise, not committed shell text

A modern terminal can render preedit beautifully.
Windows Terminal now blends IME composition into TUI colors and exposes richer underline styles.
Ghostty recently switched IME preedit text to underlines for readability and consistency.
WezTerm can expose composition state directly so the UI can badge it.
These are excellent ideas.

But Schell should import the right lesson:
**visible composition text remains weaker than committed shell/editor text until a commit event lands.**

That means a composition card may honestly say:
- `preedit visible`,
- `dead key hold active`,
- `candidate selection open`,
- `committed text not yet available`,
- `shell parse not yet updated`.

The shell should not treat preedit as authored input.
History should not record preedit as if it were submitted text.
Review should not attach meaning to it.
And prompt widgets should not “help” by reparsing it as though it had already committed.

## 4) User-perceived characters are not a safe substitute for exact committed text

The other historical scar is measurement.
Combining marks, emoji sequences, joiners, and grapheme clusters keep proving that code points, glyphs, cursor cells, and user-perceived characters are different things.
Modern terminals now expose this reality openly, sometimes even with compatibility options for older applications.

Schell should steal the comfort while refusing the lie.
The terminal may:
- render grapheme-correctly,
- move the cursor by user-perceived characters,
- or expose a compatibility width mode,

but exact committed text still needs its own stronger object.
That means Schell should separate:
- **what the operator sees**,
- **how the local renderer measures it**,
- **what text committed to the buffer**,
- and **what the shell later parsed or passed onward**.

## 5) Candidate windows and clause cursors are higher-level local UI, not shell-owned proof

IME candidate windows, clause cursors, and composition widgets are often owned by the platform or IME rather than by the shell.
They are valuable, but they are not the same thing as the shell’s live prompt cursor.
They should therefore stay explicitly local and explicitly weaker.

Schell can become unusually good here by making the distinction obvious:
- **composition cursor** versus **shell/editor cursor**,
- **candidate owner** versus **prompt owner**,
- **composition acceptance** versus **buffer acceptance**,
- **buffer acceptance** versus **reviewed action**.

That creates room for excellent operator comfort without pretending the shell authored UI it did not own.

## 6) What Schell should do now

### A. Add **composition witnesses**
Each composition-capable input surface should carry:
- `composition_family`,
- `preedit_state`,
- `candidate_owner`,
- `commit_state`,
- `text_commit_basis`,
- `measurement_posture`,
- and `strongest_safe_next_action`.

### B. Add **text-commit receipts**
When composition commits, Schell should be able to show a tiny exact object such as:
- committed text,
- whether it replaced a preedit region,
- whether normalization/compat width affected rendering only,
- and whether shell parse/argv changed yet.

### C. Add **measurement chips**
Do not hide width policy.
When relevant, a compact chip should admit whether the local view is:
- grapheme-based,
- compatibility-width-based,
- renderer-local,
- or unknown/downgraded.

### D. Keep **composition weaker than authorship**
Preedit visibility, candidate windows, dead-key holds, and clause movement all remain editing/composition facts.
They are not authored shell text and they are not reviewed action.

### E. Keep **assistant/help logic away from preedit**
Autosuggestions, remediation offers, and command explanations should trigger from committed buffer text or a stronger shell-owned surface — not from transient preedit state.

## 7) Super-awesome ideas worth stealing now

- composition-aware cursor/posture chips,
- a tiny “Composing…” badge with source/owner confession,
- exact post-commit reveal cards when text changes meaningfully,
- grapheme/compat-width badges when cursor behavior would otherwise feel mysterious,
- dead-key hold hints that never overwrite committed text,
- and shell/editor history that records committed text only.

The especially good Schell twist would be:
**make multilingual text entry feel first-class, then keep preedit, committed text, measurement posture, and later exact shell meaning separately named.**

## 8) Decisions intentionally kept open

This pass does **not** freeze:
- one final IME API strategy,
- one final dead-key model,
- one final grapheme measurement rule for every host,
- one final candidate-window ownership protocol,
- one final text-normalization policy,
- or one final editor engine.

The no-regret move is smaller:
**make composition first-class and luxurious, but keep preedit state, candidate UI, committed text, measured display width, and later exact shell meaning separately named.**
