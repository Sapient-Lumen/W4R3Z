# Credential witnesses, escalation ladders, and umask humility

This surface keeps one boundary explicit:
**a great shell+terminal should let operators review identity footing, escalation posture, and file-creation defaults — but it should not let ambient caller identity, supplementary groups, namespace remapping, `umask`, or privileged-exec metadata impersonate one another.**

Modern systems already have real identity and privilege machinery:
- shells carry caller identity, environment, and file-creation mask as part of execution footing,
- policy tools can switch target user/group and rebuild or preserve the environment,
- safer elevated-edit paths can separate writeback from full privileged interactivity,
- launchers can explicitly clear groups or set no-new-privileges posture,
- and namespaces can remap what numeric UID/GID values even mean.

That is all worth stealing.
The failure mode is equally consistent:
- “who am I?” gets flattened into one prompt glyph,
- `sudo`/`doas`/helper policy stays invisible until a command behaves strangely,
- full privileged editors get used where elevated writeback would have been enough,
- `umask` surprises show up only after file creation,
- and user-namespace-mapped identity pretends to be the same thing as host identity.

Schell can do better without picking one final elevation tool, broker, or namespace substrate.

## 1) The shell needs one exact credential witness family

A good first object is **credential witness**.

A credential witness is a compact shell-owned descriptor for the identity footing a reviewed action will enter.
It is not a universal account-management API.
It is not a final RBAC browser.
It is the thing the terminal can point at when it says “this command will run under *this exact credential posture*.”

A v0 family probably needs:
- `caller_identity_posture` — same_as_executor / different / unavailable,
- `executor_identity_posture` — fixed_executor / switched_target / service_isolated / compat / unknown,
- `target_identity` — explicit user/group if reviewed, else provider-fixed / unknown,
- `group_posture` — clear / keep / init / explicit-set / unknown,
- `namespace_mapping_posture` — host_basis / remapped / mixed / unknown,
- `privgain_posture` — no_new_privs / provider_asserted_non_gain / may_gain / unknown,
- `umask_posture` — explicit / provider_fixed / compat_inherited / unknown,
- `receipt_posture` — exact_shell_outcome / provider_addendum / unavailable,
- `notes_ref` — optional explanation or refusal card.

That is enough to make identity truth real without freezing a giant privilege ontology.

## 2) Caller, executor, and target identity should never collapse into one badge

A shell prompt that merely says `root` or `user` is often lying by omission.
Useful distinctions include:
- the identity that asked for the action,
- the identity that will actually execute it,
- the reviewed target identity requested by policy,
- and whether the action is launched fresh from an isolated service or by inheritance.

Schell should therefore separate:
- **caller identity**,
- **executor identity**,
- **requested target identity**,
- and **isolated-service posture**.

That lets the terminal say:
- “same caller and executor”,
- “target switched from alice to root via reviewed policy”,
- “fresh isolated executor with no inherited security context”,
- “identity degraded/unknown under compat membrane”.

That is dramatically more honest than one generic “elevated” pill.

## 3) Group posture is authority and deserves first-class review

Supplementary groups often decide real filesystem and service reachability.
So Schell should be able to say:
- groups cleared,
- groups kept,
- groups reinitialized from target identity,
- explicit group set reviewed,
- or group posture unknown/degraded.

That is a super practical luxury.
It prevents the common debugging spiral where the operator only discovers hidden group posture after permissions or socket access behave strangely.

## 4) Namespace-mapped identity should stay separately named

A process may see one UID/GID while host permission checks and file ownership semantics still involve mapped values.
So a reviewed action should be able to confess:
- host-basis IDs,
- remapped IDs,
- mixed or provider-specific basis,
- or unknown.

This is not a universal namespace browser.
It is simply enough honesty to prevent numeric identity from masquerading as globally stable truth.

## 5) Umask and file-creation footing deserve their own witness

This is a crucial shell lesson.
The permissions a new file or directory gets are part of execution footing.
The operator should not have to discover after the fact that:
- the current shell's `umask` widened a created file,
- a compat layer inherited host session defaults,
- a provider forced a secure owner-only mask,
- or the launch boundary could not prove anything at all.

Schell should therefore show a **umask witness**:
- explicit `umask` value,
- provider-fixed default,
- compat inheritance,
- or unknown/degraded.

That is small, useful, and very decision-light.

## 6) Escalation should be a ladder, not a single mode bit

One especially good idea worth stealing is an explicit **escalation ladder**.
At minimum the shell should distinguish:
- inspect identity posture,
- insert a reviewed user/group switch into active input,
- use an elevated-writeback edit lane,
- launch one privileged non-interactive command,
- launch a stronger privileged interactive session.

Those are all valuable.
They are not the same.

A very nice practical rung is **elevated writeback edit**:
edit with the ordinary user-facing editor posture, but write changes back through a stronger reviewed lane.
That is weaker than “run the whole editor as root/admin”.
Schell should absolutely steal that idea.

## 7) Privilege-gain posture should stay humble and exact

A shell can gain a lot by showing:
- no-new-privileges asserted,
- provider guarantees no gain across `exec`,
- reviewed target switch but no implicit capability gain,
- degraded/unknown privilege-gain posture.

But it should avoid pretending to prove:
- that the entire privilege picture is now known forever,
- that a historical receipt proves current live identity,
- that namespace-mapped or capability-bearing state can be reduced to one badge,
- or that one host's elevation tool is Schell's universal privilege model.

A **privgain witness** should remain narrower than a full account/ACL inspector.

## 8) Historical identity and creation receipts should stay bounded

A good identity/creation receipt might include:
- exact reviewed action basis,
- executor and target identity posture at review time,
- group posture at review time,
- namespace-mapping posture if known,
- `umask` / file-creation footing,
- optional no-new-privileges or non-gain badge,
- exact exit / signal posture,
- optional created-path ownership/mode summary,
- and a claim-strength badge when the runtime could not prove more.

It should avoid pretending to prove:
- current login/session identity,
- current namespace mappings,
- current prompt truth,
- current policy configuration,
- or that a privileged session is still live now.

## 9) Great ideas worth stealing right now

### a) Caller / executor / target split
Tiny but high value.
Do not flatten who asked, who will run, and who is being targeted.

### b) Group posture badges
Clear / keep / init / explicit / unknown.
Wonderful operator hygiene.

### c) Elevated-writeback edit
A safer edit rung that is weaker than launching a privileged editor/session.

### d) Fresh isolated escalation lanes
A reviewed badge that says the launch is fresh and isolated rather than inheriting the caller's security context.

### e) Umask witnesses
Make file-creation footing visible before run and explainable after run.

### f) Non-gain posture badges
A compact no-new-privileges / no-priv-gain witness that stays weaker than full account policy truth.

### g) Namespace-mapping honesty
Admit when numeric identity is remapped instead of pretending it is universal truth.

## 10) Things Schell should refuse

### Refuse ambient-caller-identity-as-meaning
The current login/session identity should not silently define reviewed workflow meaning.

### Refuse elevated-editor folklore
Editing a protected file is not the same as running an entire privileged interactive editor/session.

### Refuse group invisibility
Supplementary groups are authority, not harmless residue.

### Refuse umask folklore
File-creation posture should be visible, not guessed after the fact.

### Refuse namespace-number romanticism
A UID/GID number alone is not enough truth when mapping is in play.

### Refuse one giant privilege plane too early
Schell should not yet freeze one universal run-as grammar, token model, or elevation backend.

### Refuse stale identity chrome as live authority
A restored badge or old receipt should never impersonate current credential truth.
