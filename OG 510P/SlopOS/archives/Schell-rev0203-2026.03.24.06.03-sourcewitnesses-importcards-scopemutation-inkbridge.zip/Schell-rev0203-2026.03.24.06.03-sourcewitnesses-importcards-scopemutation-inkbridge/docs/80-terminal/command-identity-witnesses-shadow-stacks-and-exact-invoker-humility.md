# Command-identity witnesses, shadow stacks, and exact-invoker humility

This surface narrows another shell+terminal seam that classic shells still handle with folklore:
**before a pending action spends, Schell should be excellent at answering what this bare command name will actually become right now — alias, abbreviation, function, builtin, module-provided command, hashed path hit, or exact external file — without forcing operators to learn five different introspection commands or trust a lying `which`-style story.**

That seam matters even more because SlopOS is still in design phase.
If Schell gets this wrong early, prompt badges, repo-local helpers, shell functions, autoloaded command families, and remembered path hits quietly become a second hidden execution plane.

## 1) Modern shells already reveal the problem

Current shells keep rediscovering the same truth:
- Bash distinguishes functions, builtins, keywords, files, and hashed paths.
- PowerShell distinguishes aliases, functions, cmdlets, scripts, applications, and module-qualified names.
- fish distinguishes functions, builtins, and path-resolved executables, with separate force-path queries.
- Nushell distinguishes internal commands from external commands and can attach explicit extern signatures.

The design lesson is not “pick one universal resolver model now”.
It is smaller.
A shell+terminal should become excellent at showing the exact **command identity stack** that a pending invocation will use.

## 2) One compact command-identity witness is enough

Schell does not need one grand final resolver architecture to improve this seam.
A compact **command-identity witness** could keep fields such as:
- `invocation_token` — the exact command word the operator typed,
- `winner_kind` — alias / abbreviation / function / builtin / keyword / module command / script / external file / unknown,
- `winner_label` — exact chosen name or path,
- `source_lane` — interactive definition / rc or profile load / repo accelerator / module import / PATH search / hashed path / explicit path / restored / unknown,
- `shadow_stack` — the ordered nearby contenders that would also answer this name,
- `bypass_forms` — exact stronger verbs such as module-qualified name, `command`, `builtin`, explicit path, or exact invoker pin,
- `freshness` — current / command-local / hashed / restored / staleable / unknown,
- `basis_ref` — exact file, env var, module, receipt, profile card, or path slot that established the winning answer,
- `reveal_target` — exact card explaining why this answer won and what other answers remain nearby.

That is enough to make resolver truth dramatically clearer without freezing one final plugin ABI, completion treaty, or external-command ontology.

## 3) The shell should be great at the parts older shells blur

Classic shell UX usually leaves crucial resolution facts annoyingly ambient:
- whether a friendly name is really a function or alias instead of an executable,
- whether a builtin is shadowing a file on disk,
- whether a remembered hash/path hit is stale relative to the current `PATH`,
- whether discovery imported a module or command family into the session,
- whether the current directory is being searched at all,
- and whether a command-local bypass would invoke something different.

Schell can do much better with small luxuries.

### a) Exact-invoker strip
Show a compact winner chip such as `ls → function`, `help → alias → builtin help system`, `kubectl → /opt/homebrew/bin/kubectl`, or `Get-Date → function shadows cmdlet`.

### b) Shadow stack card
Every command chip should answer “what else answers this name?” with a small ordered stack.
That card is the humane shell-native version of `type -a` / `Get-Command -All`.

### c) Bypass ladder
If the operator wants the weaker or stronger neighbor, make the bypass forms visible: exact path, module-qualified name, `command`, `builtin`, or “pin exact invoker for this run”.

### d) Hash drift beacon
If the shell is relying on a remembered path hit or stale module/layout residue, show that explicitly and offer re-search or reset rather than pretending the current `PATH` still obviously agrees.

### e) Resolver witness in the receipt
A reviewed execution receipt should preserve the exact invoker identity that actually ran, not merely the token the user typed.

## 4) Great ideas worth stealing now

### Stack, not scalar
Do not compress command identity into one pretty path label.
Show the winning answer and the nearby shadow stack.

### Discovery without spending
Let operators reveal the exact invoker before execution without auto-importing helper systems or silently changing session state.

### Exact-path pinning
A bareword may be pleasant for authoring, but receipts and replay bundles should be able to pin the exact winner that actually answered the call.

### Bypass verbs stay visible
The shell should teach `use this exact path`, `ignore functions`, `use builtin`, or `use module-qualified name` as separately named moves instead of folklore.

### Signature help stays weaker than identity
Known extern signatures, completions, and syntax coloring are wonderful, but they should not impersonate proof about which concrete invoker will answer the name.

## 5) The strongest lesson from SlopOS and the companion cubes

SlopOS keeps selectors exact and routing explicit rather than ambient.
ViewFS keeps accepted insertions, compiled command packets, prepared actions, and receipts separate.
Steward keeps correction and retry posture exact rather than atmospheric.
Helm keeps changed-basis and reset truth visible instead of flattering the last known anchor.

That combination points Schell at one small rule:
**the shell should treat command resolution as its own typed witness stack rather than letting aliases, functions, builtins, autoloaded commands, and path hits hide behind one cozy command name.**

## 6) What Schell should refuse now

Schell should refuse:
- a path-only answer counting as full command identity truth,
- a pretty prompt/tool badge counting as proof of which invoker will answer,
- discovery side effects counting as harmless when they import commands,
- hashed path hits counting as fresh current-path proof,
- and remediation/install suggestions counting as resolution itself.

## 7) The no-regret move

The best move right now is not to freeze one universal resolver engine or one final command namespace treaty.
It is to pin one smaller rule:
**Schell should treat the winning invoker for a command name as a family of command-identity witnesses with visible source, shadow order, and bypass forms before ambient command folklore becomes a second hidden execution plane.**
