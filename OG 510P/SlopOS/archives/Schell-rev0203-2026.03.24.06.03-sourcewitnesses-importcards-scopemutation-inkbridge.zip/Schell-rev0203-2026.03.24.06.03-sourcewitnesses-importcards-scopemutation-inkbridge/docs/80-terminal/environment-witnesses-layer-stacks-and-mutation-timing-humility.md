# Environment witnesses, layer stacks, and mutation-timing humility

**a great shell+terminal should make environment activation feel legible and luxurious — but it should not let startup files, terminal injection, repo-local hooks, overlays, or one-off exports collapse into one flattering “this is just my environment now” story.**

Schell already has broad surfaces for execution grounds, startup footing, config-ground cards, command identity, subject stacks, and cwd truth.
This pass narrows one especially dangerous seam those earlier surfaces leave open:
**what environment mutations exist right now, where did they come from, when do they take effect, and which of them are still weak enough that a reviewed action should not quietly trust them yet?**

The pressure is easy to see across current tools:
- Bash inherits exported names from the parent environment and can also run startup files like `BASH_ENV` before non-interactive scripts.
- fish separates scope from export state and treats PATH-like variables specially.
- PowerShell profiles can customize every session while environment variables also live in Machine/User/Process scope.
- Nushell lets environment values be typed and introduces overlays that can be activated and deactivated.
- direnv loads and unloads project-specific environment changes only after authorization.
- VS Code and Windows Terminal can inject or define terminal-specific environment deltas outside the shell’s own config files.

That means “the current env” is not one thing.
It is a stack of claims with different source, scope, lifetime, and admission posture.

## 1) The shell needs an exact environment-layer witness family

A useful first object is **environment-layer witness**.

An environment-layer witness is not the whole environment.
It is one declared mutation lane that contributes to the effective environment.
The shell should be able to name several at once.

A v0 witness probably needs:
- `layer_ref` — exact identity for the mutation layer,
- `source_lane` — inherited parent / login startup / rc or profile / terminal injection / repo overlay / overlay module / command-local / restored / unknown,
- `timing_lane` — process creation / shell init / prompt-time / command-local preflight / historical residue,
- `scope_posture` — machine / user / process / shell session / block / command / pane or tab / repo / unknown,
- `mutation_kind` — replace / prepend / append / unset / typed overlay / opaque helper,
- `keys_touched` — exact variables changed when known,
- `code_posture` — pure data / shell code / helper-derived / imported / unknown,
- `admission_posture` — native / trusted / repo-leased / terminal-provided / imported / restored / unknown,
- `lifetime_posture` — durable / session / pane / command / lease / until-exit / historical,
- `reveal_ref` — exact diff or card showing the before/after set.

That is enough to keep the environment legible without freezing one universal env model.

## 2) Effective environment should be a visible stack, not a scalar snapshot

Operators keep getting surprised because environment presentation usually jumps straight from hidden mutation to final value.
The shell should instead show a small **environment stack** when it matters:
- inherited base,
- startup/profile layers,
- terminal-provided deltas,
- repo-local or task-local overlays,
- activation tools,
- and command-local overrides.

Each row should say whether it still matters to the pending command or whether it is only historical residue.
That alone would make “why is PATH different here?” and “why did auth or tool lookup change?” dramatically easier.

## 3) Timing matters as much as value

A huge source of confusion is not just *what* changed, but *when* it becomes real.
Current tools already show this pressure:
- startup files affect shell birth,
- terminal profiles may inject values before the shell even starts,
- shell-integration or extension mutators may apply after shell init,
- repo-local activators may apply on directory entry or prompt-time,
- command-local overrides may matter only for one spend.

Schell should therefore keep a **timing chip** on every environment layer witness.
An operator should be able to ask:
- did this exist before the shell launched,
- did startup code create it,
- did the terminal inject it,
- did repo-local code adopt it later,
- or is it only attached to the pending command?

That makes luxurious environment help possible without turning timing into folklore.

## 4) PATH deserves a special row family without becoming the whole model

PATH is special because it changes command identity and tool discovery, but it should not hijack the entire environment design.
A good compromise is a dedicated **search-path row family** inside the wider environment stack.

Each PATH row can show:
- prepend versus append,
- exact source lane,
- whether it is path-typed or raw string text,
- whether it is inherited, profile-made, repo-leased, or command-local,
- and whether it changed the winning invoker for a relevant command.

That composes cleanly with the command-identity seam instead of replacing it.

## 5) Repo-local activation should stay leased and diffable

direnv and similar tools are wonderful because they keep per-repo environment work local.
They are risky because they can quietly become ambient authorship.

Schell should keep repo-local env mutation as a **leased activation layer** with:
- source path,
- authorization posture,
- changed keys,
- PATH/search-path changes,
- timing lane,
- and a quick suspend / reauthorize / compare-to-basis card.

That lets Schell steal project-local delight without deciding that every folder deserves hidden code-bearing authorship.

## 6) Terminal-local env mutation should confess itself

Current terminals and editors increasingly modify environment for convenience.
That may be great.
It should still confess itself.

Schell should therefore keep **terminal-provided env layers** separate from shell-native layers.
Examples include:
- authentication helpers,
- per-profile dev variables,
- locale fixes,
- and integration shims.

These should carry a weaker posture than shell-authored basis until the operator deliberately adopts them.
A hover or reveal card should explain the exact delta and whether relaunch is required.

## 7) Activation should be additive evidence, not prompt folklore

Virtual environments, toolchain shells, dev shells, overlays, and project kits often announce themselves with a prompt segment or banner.
That is helpful but too weak.

Schell should prefer:
- an activation witness,
- an environment-layer diff,
- a PATH/search-path diff when relevant,
- and a basis comparison for rerun/replay.

That keeps cute prompt segments descriptive instead of letting them masquerade as precise execution footing.

## 8) Rerun and replay need environment drift posture

The archive already learned that rerun should care about mutable basis.
Environment is one of the most common drift families.

A pending or historical action should therefore know whether:
- environment still matches exactly,
- only irrelevant keys changed,
- search path changed in a way that could affect invoker selection,
- repo activation changed,
- or a terminal/helper layer appeared or disappeared.

That is enough to offer strong rerun, compare-and-set rerun, inspect-only, or re-arm review without freezing one total environment digest law.

## 9) Great luxury moves that stay decision-light

Schell can steal several excellent moves now:
1. one **env strip** that blooms only when the active environment stack differs meaningfully from durable basis,
2. a **why-did-this-key-change?** card that shows source lane, timing lane, and diff,
3. **PATH row cards** that explain prepend/append and winner changes without swallowing the whole environment model,
4. a **repo activation lease** with reauthorize/suspend/compare controls,
5. a **terminal injection badge** with hoverable delta and relaunch posture,
6. a **pending-command env preview** showing command-local overrides before spend,
7. and a **receipt-level environment pin** that records relevant layer refs rather than only flattening final values.

## 10) The no-regret move

The best move now is not to settle one final plugin runtime, env serialization format, or universal activation treaty.
It is to pin one stronger rule:

**Schell should model effective environment as a stack of environment-layer witnesses with visible source lane, timing lane, scope posture, mutation kind, admission posture, and revealable diff before startup scripts, repo hooks, terminal injections, overlays, and one-off exports masquerade as one generic shell-environment truth.**
