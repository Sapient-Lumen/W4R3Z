# Baseline cards, safe sets, and silent-approval humility

This surface names a shell+terminal seam that current tools keep drifting toward:
**the operator increasingly experiences “no prompt appeared” as a product feature, but the quietness may come from several very different sources, and Schell should make that source visible instead of letting silence impersonate understanding or durable trust.**

Modern tools now quiet prompts through several different mechanisms:
- built-in read-only or safe-command classes,
- per-project or per-user allow rules,
- deny floors that still override those rules,
- sandbox-backed auto-allow,
- isolated worktree or disposable-workspace lanes,
- managed organization policy,
- and remembered replay from exact prior review.

Those are not one thing.
They should not look like one thing.

## 1) Name the problem: quietness provenance

If an action runs without asking, the shell+terminal should be able to answer:

- **why** was this quiet,
- **who** established that quietness,
- **what exact scope** is carrying it,
- **which deny floors** still apply,
- and **what would make the same action ask next time**.

Without that, the operator sees the same observable effect for very different cases:
- “this command is in a built-in safe set,”
- “this command matched my project allowlist,”
- “this action ran inside a constrained sandbox lane,”
- “this whole isolated worktree lane auto-approves by construction,”
- or “this exact reviewed basis reused a replay lease.”

Those should not collapse into one flattering story of “the system trusted it.”

## 2) The shell should surface baseline cards

A **baseline card** is a compact explanation of a quiet approval source.
It is not the approval itself.
It is not the receipt.
It is not a capability.
It is an operator-facing explanation packet that says why the prompt stayed quiet.

A baseline card should answer at least:
- source family,
- rule or lane identity,
- scope,
- active deny floors,
- expiry or drift conditions,
- and where to inspect or change the rule.

A first useful baseline taxonomy could include:
- **vendor safe set**,
- **local allow rule**,
- **managed org policy**,
- **sandbox lane**,
- **isolated worktree lane**,
- **replay lease**,
- **read-only class**,
- **provider-local auto-allow**.

That is enough to make quietness legible without freezing the final permission engine.

## 3) Safe sets should be explicit classes, not folklore

Many tools now ship with some notion of “safe enough to stop asking.”
That can be useful.
It can also rot into folklore.

Schell should therefore refuse the usual pattern where a vendor or local implementation quietly grows a list of implicitly allowed actions while the operator only learns about it from behavior.

A safe set in Schell should be:
- named,
- inspectable,
- classed by effect family,
- bounded by scope,
- and receipt-visible when used.

Even if Schell later adopts a default read-only family or a starter allow bundle, the operator should be able to open the card and see what is actually inside that class.

## 4) Isolation-backed quietness should stay different from rule-backed quietness

One of the most useful lessons from current tools is that some quietness comes from **bounded environment shape**, not from command-pattern blessing.

That matters.
A command that auto-runs because it is inside a worktree-isolated lane or an OS-enforced sandbox is not the same as a command that auto-runs because it matched a regex allowlist.

Schell should therefore keep separate baseline families for:
- **rule-backed quietness** — because a rule matched,
- **isolation-backed quietness** — because the action stayed inside a constrained lane,
- **read-only-class quietness** — because the action stayed inside a named non-effect class,
- and **replay quietness** — because an exact reviewed basis still matched.

That distinction is one of the best no-regret honesty upgrades Schell can make.

## 5) Deny floors should always be visible

If quietness exists, the operator also needs to know what still **cannot** become quiet.

A Schell baseline card should therefore always carry a **deny floor strip** or expandable floor section.
That floor can say things like:
- network egress still asks,
- credential prompts never auto-answer,
- writes outside the current footing still ask,
- protected config roots still ask,
- imported foreign text still needs endorsement,
- and secret-bearing flows still downgrade.

This is the shell+terminal equivalent of saying:
“yes, some speed happened here — but not all caution disappeared.”

## 6) Quietness should become receipt-visible without becoming noisy

Schell should not reintroduce friction by prompting again just to explain the absence of a prompt.
The right move is quieter than that.

Good operator surfaces would be:
- a compact **baseline chip** near the command or action,
- a hover or drawer that explains the quietness source,
- an optional session strip listing recent quiet approvals,
- and a receipt field that records baseline family, scope, and any deny-floor overlap.

That gives the operator reviewable provenance later without making every fast path feel ceremonial.

## 7) SlopOS pressure wants vetoes and explicit payers, not hidden safe folklore

SlopOS is a strong companion check here.
Its veto-only policy-bundle posture says policy should narrow, not grant.
Its operation-scoped budget-lease posture says costs and sponsorship should be explicit rather than ambient.
Its upcall and wait-set posture refuses magical callback folklore that outruns named seams.

That pressure points Schell away from “the product just knows what is safe now.”
It points toward:
- explicit baseline families,
- visible deny floors,
- quietness provenance,
- and exact receipt residue when speed paths fire.

## 8) Companion-cube alignment

The other companion cubes help the same answer hold shape.

ViewFS keeps object classes separate instead of flattening every useful thing into one state.
Steward keeps trusted chrome descriptive and explicit.
Helm keeps endorsement narrower than convenience.

Together they suggest that Schell should make these distinctions first-class:
- **built-in baseline**,
- **local reviewed rule**,
- **managed policy baseline**,
- **sandbox-backed lane**,
- **isolated worktree lane**,
- **replay lease**,
- **denied regardless**.

That gives the operator fast comfort with object-class honesty.

## 9) Great moves worth stealing now

### Baseline chips on quiet commands
A command that ran without asking should show *why* it was quiet.

### Inspectable safe-set cards
A built-in safe family should be openable and diffable.

### Isolation badges that name their basis
If the quietness came from a sandbox or worktree lane, the card should say so explicitly.

### Deny-floor preview
Operators should be able to see what still asks even in a fast lane.

### Receipt residue for later audit
Receipts should say whether silence came from a rule, a lane, a class, or a replay lease.

### Managed-vs-local separation
Org policy quietness should not masquerade as personal choice.

## 10) Things Schell should refuse

### Refuse “no prompt” as an untyped state
Silence without provenance is a trust bug.

### Refuse hidden vendor baselines
If there is a starter safe set, it should be inspectable.

### Refuse sandbox-equals-trust shorthand
A constrained lane may justify faster execution without implying broad safety.

### Refuse replay-equals-baseline
Remembered exact review is a different family from a standing safe set.

### Refuse deny-floor disappearance
Fast paths should still show the remaining hard stops.

## 11) No-regret first specimen set

A compact first cut could prove the seam with:
1. one quiet read-only command showing a **vendor safe-set** baseline chip,
2. one command matched by a **project allow rule** with exact rule reveal,
3. one sandboxed command showing **lane-backed auto-allow** instead of rule-backed quietness,
4. one worktree-isolated lane showing **all tools quiet here because the lane is isolated**, not because the commands are blessed globally,
5. one command blocked by a **deny floor** even though another baseline might otherwise have allowed it,
6. one receipt slice showing **quietness provenance** for later audit,
7. one managed-policy card that clearly says it came from org scope,
8. and one replay lease card that stays visibly separate from baseline safe sets.

That is enough to make Schell faster and more legible without deciding the final policy language, safe-command catalog format, or agent runtime architecture.
