# Assistant-lane witnesses, separate modes, and approval humility

This surface exists to keep one very stealable luxury bundle honest:
**Schell should absolutely steal natural-language assistance, plan mode, checkpoints, reusable prompts/skills, and scoped agent tooling, but it must not let assistant conversation collapse into shell input or hidden execution authority.**

The point is not to keep AI away from the terminal.
The point is to keep roles legible.
A shell+terminal can feel dramatically better when assistant help is nearby.
It becomes confusing when chat, commands, permissions, and execution all pretend to be the same thing.

## 1) Assistant work deserves its own lane

A healthy assistant system belongs in a visibly distinct lane or mode.
That lane may be a side pane, a dedicated conversation view, a clearly marked overlay, or a strongly marked input state.
What matters is that the operator can always tell whether they are:
- typing exact shell input,
- talking to an assistant,
- reviewing a generated action,
- or authorizing a stronger move.

One blended field is not clarity.
It is ambiguity with better typography.

## 2) An assistant witness is not a command witness

An assistant-lane witness should describe things like:
- lane kind or current mode,
- assistant authorship,
- which context packets were attached,
- which tools or tool groups are currently allowed,
- whether the assistant is in plan/read-only posture,
- what kind of output it produced (explanation, inserted text, runnable proposal, file edit, scout summary),
- and what approval or trust decision would be required for stronger moves.

An assistant witness is **not**:
- proof that a generated command is safe,
- proof that external side effects can be undone,
- or permission for the runner to skip explicit review.

## 3) Insert, review, and run should stay different verbs

The most stealable interaction law here is very small:
**generated commands should have at least an insert path and a stronger run path.**

Insert keeps the shell-owned active input field authoritative.
Review keeps exact argv/text reveal possible before launch.
Run may still be useful, but it should remain a clearly stronger action.
If the operator can only “accept” a suggestion and the product decides the rest, the shell has already become less honest.

## 4) Plan mode is worth stealing

Read-only scouting is a real luxury.
A good assistant lane can inspect state, search docs, summarize likely next steps, and prepare candidate actions without crossing into side effects.
That deserves a first-class label such as:
- plan,
- scout,
- read-only,
- or propose-only.

This is one of the nicest ways to make Schell feel super awesome without deciding the final backend too early.

## 5) Saved prompts and skills should be reusable playbooks, not ambient authority

Reusable natural-language playbooks are clearly worth stealing.
Operators should be able to save named prompts, parameterize them, search them, and invoke them deliberately.
But Schell should keep a strong split between:
- a saved assistant playbook,
- a workflow seed,
- an exact shell artifact,
- and a runtime-capable function/tool surface.

Saved prompts and skills may guide work.
They should not quietly become execution-grade policy or startup magic.

## 6) Isolated scouts are healthier than one giant chat

Assistant work often benefits from context isolation.
A scout or subagent can inspect a large codebase, summarize findings, or propose next steps without polluting the main input lane.
Schell should prefer:
- isolated scouting contexts,
- compact summary return,
- explicit attachment of the resulting object,
- and a new review decision before stronger action.

That is cleaner than one giant immortal terminal chat with ever-growing hidden assumptions.

## 7) Permission posture should stay visible

A good assistant lane should keep permission posture explicit.
The operator should be able to see whether the assistant currently has:
- read-only file inspection,
- write permission,
- command execution permission,
- network/tool access,
- or a narrower trusted subset.

Stronger trust moves should say what they widen.
“Trust me” is too vague.
“Allow this tool family for this scope” is much healthier.

## 8) Checkpoints need humility

Checkpoints are great.
They make ambitious edits less scary.
But they are not universal rollback.
Schell should say exactly what a checkpoint covers.
For example:
- local file edits,
- active input text,
- temporary review objects,
- or shell-local cards.

It should not imply that API calls, browser actions, database writes, or external service changes can be undone just because a rewind button exists.

## 9) A compact first proving slice

A compact first specimen should show:
1. one visibly separate assistant lane or mode,
2. one natural-language request yielding both **Insert** and **Run** paths,
3. one read-only plan/scout mode,
4. one permission strip showing current tool posture,
5. one checkpoint card labeled with exact coverage,
6. one saved parameterized playbook/prompt,
7. one isolated scout summary attached back into the main flow,
8. and one refused auto-run or auto-hook pattern that would have widened authority too far.

That is enough to make Schell feel unusually good without freezing a final agent architecture, plugin substrate, or transport.

## 10) Things to refuse for now

Refuse for now:
- one blended shell+assistant input field as the only mode,
- hidden auto-run of generated commands,
- prompt metadata or skills acting as permission,
- ambient tool discovery that silently widens power,
- invisible trust carryover across changed basis,
- and checkpoint wording that overclaims external rollback.

The right law is:
**steal separate assistant lanes, insert/review/run splits, plan mode, playbook reuse, and explicit tool posture — but keep assistant conversation weaker than exact reviewed shell truth.**
