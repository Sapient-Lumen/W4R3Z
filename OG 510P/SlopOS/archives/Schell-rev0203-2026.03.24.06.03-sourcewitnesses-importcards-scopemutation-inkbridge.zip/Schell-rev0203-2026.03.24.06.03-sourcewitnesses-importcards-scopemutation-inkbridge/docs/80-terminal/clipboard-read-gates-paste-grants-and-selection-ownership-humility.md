# Clipboard-read gates, paste grants, and selection-ownership humility

This surface records a new no-regret candidate cluster for Schell:
**treat copy, clipboard access, and paste as a small family of explicit transfer/grant objects instead of letting selection, system clipboards, OSC 52 bridges, prompt-aware paste transforms, or persisted paste history collapse into one flattering ambient clipboard story.**

Schell already has ingress packets, selection packets, and clipboard-egress witnesses in the archive.
This pass narrows a seam those earlier surfaces left deliberately open:
**clipboard readback, selection ownership, and target-specific paste approval.**

The design pressure comes from three directions:
- SlopOS keeps forcing clipboard-like movement onto explicit D-PLUMB and transfer seams while refusing ambient host↔guest clipboard mythology.
- Current terminals and editors keep proving that multiline paste safety, prompt-aware transforms, and remote clipboard bridges are real product surfaces.
- The broader ecosystem keeps admitting that clipboard reads, clipboard writes, and user-triggered paste are not the same power.

## 1) One rule to keep visible: copy is not paste, and paste is not generic clipboard authority

Classic terminal folklore still talks as though there is a single clipboard event:
text is selected, then somehow it is “copied”, then somehow it is “pasted.”
That old story hides too much.

A better first Schell rule is smaller and more honest:
- **selection** chooses a visible subject,
- **copy offer** packages one or more payload forms,
- **clipboard write** mutates a wider substrate,
- **clipboard read** asks for data from that substrate,
- **paste event** is a user-triggered delivery moment,
- and **paste grant** is the exact act of delivering one chosen payload into one chosen target under current posture.

That one split already removes a surprising amount of ambiguity.

## 2) Selection ownership should stay separately named

On some systems selection and clipboard are already different objects.
On others they are blurred in practice.
Nested terminals and multiplexers blur them further.

Schell should therefore keep a small explicit **selection-ownership badge** that can say things like:
- active prompt selection only,
- shell-local selection packet,
- primary-selection owner,
- system clipboard recently written,
- remote/mux-local buffer only,
- inter-domain bridge holding copy offer,
- cleared,
- restored historical residue,
- or unknown.

This does not require a giant desktop-integration stack.
It only requires refusing to overstate what happened.

## 3) Copy offers should exist before broader egress

The archive already learned this lesson for exports and evidence.
It is equally useful for clipboard behavior.

A **copy offer** is a compact object that says:
- exact source,
- payload forms,
- secrecy posture,
- current ownership/egress state,
- whether anything has left the shell yet,
- and what stronger egress actions are possible.

That lets Schell keep the following distinct:
- selected text,
- local ring-only retention,
- primary-selection write,
- system clipboard write,
- remote/local bridge write,
- and durable share/export.

## 4) Clipboard reads need a stronger gate than clipboard writes

This is one of the clearest fresh lessons from current tools.
A program asking “what is currently on the clipboard?” is not doing the same thing as the operator pressing paste.
Clipboard readback is a data-access request.
Paste is a target-specific transfer event.

Schell should therefore have a dedicated **clipboard-read gate**.
Useful first-cut outcomes:
- deny,
- ask once,
- allow once for this tty/session,
- allow under named password/lease,
- allow only MIME listing,
- or allow only as part of a user-triggered paste event.

That keeps clipboard introspection explicit without freezing one protocol or one UX.

## 5) Paste grants should be target-aware

The nicest modern systems no longer pretend every paste target is the same.
Prompt-aware shells, bracketed-paste detection, multiline warning paths, and “advanced paste” tools all prove that target posture matters.

Schell should therefore model **paste grants** rather than raw paste success.
A paste grant can carry:
- source ref / copy-offer ref,
- payload form,
- target ref,
- target posture (prompt, editor, fullscreen app, secret-bearing, elevated, remote, historical, unknown),
- transform posture (literal, quoted, sanitized, slow-paste, scratch-stage, denied),
- and residue posture afterwards.

This is a delight multiplier because it makes advanced paste feel principled rather than magical.

## 6) Prompt-aware transforms are great, but they should stay explicit

There are some wonderful stealable luxuries here:
- URL quote-at-prompt,
- strip or reveal control codes,
- newline replacement,
- convert tabs to spaces,
- slow-paste into fragile targets,
- base64-encode before insert,
- or stage large pastes into scratch.

The wrong move is to treat these as silent rewrites.
The right move is to present them as **paste-grant variants**.
That way Schell can be very smart while keeping exact human intent legible.

## 7) Bridge crossings deserve their own strip

A remote shell causing a local clipboard write is not an ordinary local copy.
A tmux pane writing the outer terminal clipboard is not the same as a local process updating a local ring.
A VM helper or inter-domain clipboard is stronger still.

Schell should therefore keep a compact **bridge strip** near the action that says things like:
- local only,
- nested/mux-local,
- remote-to-local bridge,
- VM/guest helper bridge,
- inter-domain clipboard,
- denied by outer terminal,
- or unknown bridge posture.

This alone would prevent a lot of misleading “copied” success messages.

## 8) Residue is real and should not be flattened away

Paste/copy history, local rings, restored residue, and secret-bearing retention policy are separate truths.
A copy offer that has not left the shell is not the same as a persisted paste history row.
A current clipboard write is not the same as a restored remembered payload.

Schell should therefore attach a small **residue badge** such as:
- none,
- local ring only,
- system clipboard live,
- primary live,
- inter-domain staging live,
- durable history,
- cleared-on-delivery,
- ttl pending,
- expired,
- restored historical.

## 9) Super-awesome specimen ideas that still stay decision-light

A first specimen set could stay small but teach a lot:
1. one local selection becoming a copy offer without writing any external clipboard;
2. one system clipboard write that remains distinct from the source selection packet;
3. one clipboard-read request that gets ask/deny/allow-once treatment;
4. one multiline newline-bearing paste at a shell prompt that branches into literal / quoted / scratch / deny;
5. one remote or mux-local copy that clearly fails to claim a local clipboard write;
6. one inter-domain paste grant that clears after delivery;
7. one secret-bearing copy offer that refuses durable history;
8. and one transcript witness showing selection → offer → bridge/read/write/grant → residue.

## 10) The no-regret move

The best move right now is not to freeze a clipboard manager or a universal paste protocol.
It is to pin one stronger rule:
**Schell should model clipboard behavior as selection-ownership badges, copy offers, clipboard-read gates, bridge strips, and target-aware paste grants before it lets selection, system clipboards, OSC 52 bridges, or persisted paste history masquerade as one generic clipboard success story.**

That keeps the archive free to defer:
- the final clipboard backend story,
- the final OSC 52 / richer protocol mix,
- the final paste-history engine,
- the final secret auto-clear rules,
- the final cross-domain bridge policy,
- and the final approval UI for privileged paste.
