# Enrichment packets, freshness budgets, and speculation refusal

This surface keeps one design rule in view:
**make the custom shell+terminal brilliantly informative without letting hidden enrichers, hidden prefetch, or stale cached help impersonate shell truth.**

This is a cross-cutting terminal surface.
It touches completion, semantic links, object hints, workflow summon, chapter history, diagnostics, and preview.
The goal is not to freeze one backend.
The goal is to make “smart terminal help” explicit enough that Schell can keep getting better without regrowing the old shell diseases.

## Why this surface exists

Schell already has:
- completion cards,
- parameter help,
- object cards,
- transcript cards,
- command chapters,
- workflow seeds,
- shell-known packets,
- and restored-session honesty.

Those are all useful.
But they also imply a new risk.
A custom terminal can become so eager to help that it starts:
- running hidden generators,
- fetching remote metadata during hover,
- pre-resolving targets just because a menu opened,
- promoting cached summaries to current truth,
- or materializing objects behind the user's back.

That is exactly the kind of flattering convenience SlopOS keeps warning against.

## The compact answer: enrichment packets

Schell should probably name one compact family of **enrichment packets**.
These are non-authoritative UI facts or hints attached to a live shell context.

Examples:
- completion rows,
- focused parameter help,
- semantic-link candidates,
- workflow/history summon rows,
- object metadata hints,
- diagnostics summaries,
- safe preview snippets,
- and “you may want to refresh this” notices.

They are **not** receipts.
They are **not** approvals.
They are **not** exact-open or exact-rerun truth.
They are help.

## A minimal packet shape

A bounded v0 packet probably needs only:
- `enrichment_kind` — completion / param_help / semantic_link / workflow_hit / history_hit / object_hint / preview_snippet / diagnostic_hint,
- `subject_ref` — what current chapter, prompt, selection, object, or row this help is about,
- `display_value` — what the operator sees,
- `insert_value` — what lands in input if the operator chooses insert,
- `source_kind` — shell-static / shell-witnessed / cached-local / live-local / remote / agent,
- `freshness_grade` — static / cached / live / historical,
- `cost_grade` — free / local-io / local-exec / remote-read,
- `effect_grade` — observational / materializing / authority-sensitive,
- `refresh_action` — absent unless stronger acquisition is explicitly available,
- and `historical_badge` — restored / imported / cached / replay-derived when relevant.

That is enough structure to keep help honest without freezing one storage engine or policy language.

## Rule 1: rich display must stay separate from inserted value

Rows may be colorful, multi-column, source-badged, or richly annotated.
That should not change what lands in the command line.

This applies to:
- completion rows,
- workflow seeds,
- history hits,
- semantic object rows,
- and parameter fills.

A fancy row can show:
- the actual value,
- a human description,
- source/freshness badges,
- and a warning that refresh would do more work.

It should still insert exactly the named value or exact token chosen by the operator.

## Rule 2: opening a menu must not count as permission to do work

This is the central anti-folklore rule.

Schell should avoid:
- running executables merely because a completion menu opened,
- issuing remote queries merely because the cursor paused on a token,
- warming remote sessions just because attach candidates were listed,
- dereferencing URIs merely to decorate a row,
- or materializing historical objects just because search hit them.

If stronger acquisition is worth doing, Schell should expose it as:
- `refresh`,
- `materialize`,
- `inspect more`,
- or another explicit second step.

## Rule 3: freshness must be visible when it matters

Not every hint needs the same truth badge.
But the operator should be able to tell whether something is:
- timeless/static,
- recently cached,
- freshly observed,
- or visibly historical.

This matters especially for:
- workflow recall,
- history recall,
- object metadata,
- session lists,
- preview snippets,
- and diagnostics summaries.

A cached row can still be very useful.
It just should not look identical to fresh shell-witnessed truth.

## Rule 4: cost and effect should be visible before stronger acquisition

The terminal should be able to say, in compact form:
- this is free,
- this would touch local disk,
- this would run a local helper,
- this would read remotely,
- or this stronger action may materialize or touch authority-sensitive state.

That is enough to make the terminal feel trustworthy.
The operator can decide whether the nicer answer is worth the extra work.

## Rule 5: preview is a second workflow

Safe preview snippets are often useful.
But preview must remain weaker than open/materialize truth.

So Schell should separate:
- metadata-safe preview,
- stronger inspect,
- materialize,
- open,
- safe-open,
- and run.

The surface can still feel fast and delightful.
It just should not pretend that “I saw a snippet” means “the object is now locally present and approved for stronger action.”

## Rule 6: enrichment history must not masquerade as current truth

Restored, replayed, imported, and cached enrichments need visible posture.

For example:
- a restored completion shelf,
- a replay-derived object hint,
- an imported preview card,
- or a cached semantic-link resolution

should remain visibly weaker than fresh shell-witnessed or freshly inspected truth.

This is the same historical-honesty rule Schell already applies to sessions and transcripts.
It should apply to enrichers too.

## Rule 7: the shell still owns exact truth

The terminal may host many enrichers.
But exact truth still belongs to the shell-owned seams:
- active input,
- command chapter boundaries,
- execution grounds,
- explicit object selection,
- receipts,
- and approved actions.

Enrichment packets may decorate or accelerate those seams.
They should not replace them.

## Stealable “super awesome” moves under this model

This model still allows a lot of brilliance:

### Clickable active prompts
Prompt clicks work because the shell tells the terminal what the active editable region is.
Historical prompts remain read-only.

### Cwd-aware semantic links
The terminal can resolve a `package.json` or path-like token more intelligently when the shell chapter carries cwd witness.

### Focused parameter help
The terminal can show help below the current slot without leaving the edit flow.

### Rich summon rows
History hits, workflow seeds, and command chapters can appear as richly badged rows that land into input or review rather than running directly.

### Refresh-on-demand
A cached or historical row can offer explicit refresh when better acquisition is available.

### Materialize-on-demand
A preview card can remain safe and cheap until the operator explicitly asks to materialize or inspect more deeply.

These are the kinds of moves that make a terminal feel magical without becoming deceitful.

## The no-regret packet ladder

A good default ladder might be:
1. **shell-static** — grammar/help/spec rows,
2. **shell-witnessed** — chapter/cwd/ground facts,
3. **cached-local** — previously computed local hints,
4. **live-local** — explicit local refresh,
5. **remote-read** — explicit remote refresh,
6. **materialize / authority-sensitive** — separate stronger step.

That gives Schell a huge amount of flexibility while keeping the honesty boundary crisp.

## Decisions intentionally kept open

This surface does **not** freeze:
- one cache backend,
- one refresh scheduler,
- one plugin/completer API,
- one preview engine,
- one remote metadata substrate,
- one workflow store,
- or one sync/collaboration story.

The only real commitment is smaller:
**smart enrichment is a named, graded, explicit lane rather than hidden helper folklore.**

## Followthrough still owed

The archive now owes a specimen set showing at least:
1. one cached completion row with distinct display vs insert value,
2. one focused parameter-help card,
3. one semantic-link row that upgrades via explicit refresh,
4. one metadata-safe preview snippet that stays weaker than materialize/open,
5. one restored or replay-derived enrichment with clear historical badges,
6. one row whose stronger refresh is refused because cost/effect posture is too strong,
7. and one transcript slice showing enrichment-vs-truth honesty.

That is enough to learn a lot before freezing any large enrichment architecture.
