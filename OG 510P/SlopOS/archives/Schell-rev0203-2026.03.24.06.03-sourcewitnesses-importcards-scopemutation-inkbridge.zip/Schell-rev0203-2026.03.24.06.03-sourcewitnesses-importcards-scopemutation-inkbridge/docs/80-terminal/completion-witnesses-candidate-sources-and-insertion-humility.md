# Completion witnesses, candidate sources, and insertion humility

This surface exists to keep one especially tempting shell myth honest:
**Schell should absolutely steal world-class completion menus, descriptions, parameter fills, and typed candidate search — but it should do so by keeping candidate generation, candidate presentation, buffer insertion, and later reviewed action separately named.**

That is the small discipline that lets completion feel luxurious without letting runtime lookup code, bridged shell helpers, or fuzzy menus become a hidden second parser or a quiet execution path.

## 1) Why this surface exists

The archive already has:
- help grounds and query scopes,
- input authorship and prediction witnesses,
- parse floors and known externs,
- workflow seeds and slot-linked edits,
- chooser witnesses and preview humility,
- integration witnesses and hop downgrade honesty,
- and shell-known packets for prompt/output truth.

But there is still one missing seam between them:
**what exactly is a completion candidate, who produced it, what did it cost to obtain, and what changes when it is accepted?**

That matters because modern completion stacks increasingly mix:
- native command signatures,
- dynamic shell code,
- external helper commands,
- bridged completers from other shells,
- workflow parameter menus,
- directory/file fallback,
- caching layers,
- and descriptive candidate metadata.

Without an explicit witness split, “tab completed it” becomes a flattering but mushy story.

## 2) Keep these truths distinct

At minimum Schell should treat these as different objects:

1. **candidate generation** — how possible fills were discovered
2. **candidate presentation** — how they were shown (inline/list/menu/card/palette)
3. **candidate insertion** — what exact bytes or structured slot values entered the buffer
4. **reviewed action** — the later stronger object that the operator explicitly runs/reviews

These truths are adjacent.
They are not interchangeable.

## 3) A completion witness should name source, cost, and insertion posture

A completion witness should probably be able to say at least:
- `source_family` — native-signature / builtin-spec / known-extern / filesystem / history / workflow-seed / project-pack / bridge / imported / unknown
- `generator_family` — static-table / shell-function / external-command / structured-query / cached / mixed / unknown
- `side_effect_posture` — inert-table / shell-eval / command-spawn / bridged / imported / unknown
- `freshness_posture` — current-local / cached / remote-current / historical / unknown
- `presentation_mode` — inline / menu / list / palette / slot-fill / unknown
- `insertion_mode` — next-token / replace-token / slot-fill / path-fill / whole-fragment / unknown
- `value_shape` — exact-bytes / path / enum / structured-slot / label+value / unknown
- `fallback_posture` — no-fallback / file-fallback / shell-default / bridge-default / unknown

This does not require one final completion engine.
It only requires Schell to stop pretending every completion has the same truth story.

## 4) Candidate labels are not candidate values

One of the nicest things modern shells do is show descriptions, icons, groups, and richer labels.
Schell should steal that.
But it should keep at least these separately named:
- **display label** — what the user sees in the menu
- **inserted value** — what actually enters the buffer or slot
- **annotation** — description, source, deprecation, warning, or freshness hint
- **post-insert transform** — quoting/escaping or slot wrapping done at insertion time

That keeps “the menu looked right” from becoming the whole parser story.

## 5) Acceptance should insert, not execute

The safest law remains simple:
**accepting a completion should change the buffer or slot, not spend the action.**

That means Schell should prefer a ladder like:
1. show candidates,
2. optionally reveal where they came from,
3. insert one into the live prompt or parameter slot,
4. let the operator keep editing,
5. and only later enter the review/run path.

This keeps completion comfort editor-first instead of execution-first.

## 6) Dynamic completion is still active code and should be treated as such

The historical lesson from bash, zsh, fish, PowerShell, and modern bridges is unavoidable:
**completion is often executable logic, not a static lookup table.**

So Schell should distinguish:
- cheap static candidates,
- shell-evaluated conditions,
- command-spawned dynamic candidates,
- remote/provider-backed candidate fetches,
- and bridged completers imported from a foreign shell/runtime.

That does not mean dynamic completion is bad.
It means completion cost and completion side-effect posture belong on the honest path, not hidden behind the tab key.

## 7) Fallback ladders should stay visible

Classic shells keep proving that completion is often a stack of fallback behaviors:
- command-specific candidates,
- default shell completion,
- file/path fallback,
- bridge fallback,
- or no completion at all.

Schell should make that ladder explicit.
The operator should be able to tell whether the current menu is:
- native command knowledge,
- a workflow slot enum,
- filesystem/path fallback,
- a cached bridge result,
- or a generic default fallback.

That one distinction already makes completion much more trustworthy.

## 8) Bridged completers should stay visibly weaker than native knowledge

Borrowing completions is worth stealing.
Nushell's explicit external completers and fish bridge are excellent proof of that.
But Schell should tag bridged candidates as exactly that.

A bridged completion witness should say:
- bridge family,
- source shell/runtime,
- quoting/escaping translation posture,
- cache posture,
- and known downgrade notes.

That keeps “we have completions” from becoming “we natively understand this command.”

## 9) Workflow and parameter fills are completion too, but a nicer kind

One of the best stealable ideas in the current ecosystem is parameter-aware fill.
Workflow enums, slot-targeted fills, and searchable command templates should be treated as a first-class completion family rather than as magic snippets.

That means Schell should explore:
- slot-targeted enum menus,
- argument descriptions next to candidate values,
- dynamic candidate sets for one parameter only,
- and the rule that parameter fills remain editable after insertion.

This is a much safer way to make the shell feel form-aware without freezing one giant shell language.

## 10) Caching is worth stealing, but only with honesty

zsh's completion cache and other shell caches prove a useful point: expensive candidate generation can be made pleasant with explicit cache posture.
Schell should steal caching, but cache-backed completion should still say when it is:
- fresh current data,
- cached recent data,
- historical data,
- or a stale bridge import awaiting refresh.

A stale candidate may still be helpful.
It just should not impersonate a live query.

## 11) First specimen set this surface wants

A good first proof set would show:
1. one native known-extern completion with value+description split,
2. one filesystem fallback card that stays visibly fallback,
3. one dynamic shell-code completer with an explicit cost/side-effect badge,
4. one bridged completion whose quoting translation stays visible,
5. one workflow enum fill that inserts into a specific slot rather than a whole line,
6. one cached candidate set with freshness posture,
7. one menu that can explain why a candidate appeared,
8. one refusal to auto-run merely because a completion was accepted,
9. one transcript slice proving the inserted value is durable while the whole candidate menu is not,
10. and one compare view between candidate label and exact inserted bytes.

## 12) What to refuse for now

Refuse for now:
- one undifferentiated “tab knows best” story,
- hidden command-spawning completers on the cheapest keystroke path,
- bridged completions posing as native command understanding,
- descriptions/icons/groups posing as inserted value truth,
- auto-run or auto-review on completion acceptance,
- and shell fallback stacks that become invisible once the UI looks polished.

## 13) Bounded conclusion

One of the easiest ways to make Schell feel dramatically better than classic shells is also one of the safest:

**treat completion as witnessed candidate generation plus inert insertion.**
The menu can be rich.
The candidates can be typed.
The fills can be slot-aware.
The bridges can be clever.
But the reviewed action still comes later.

That is enough to steal a lot of brilliance without freezing the architecture too early.
