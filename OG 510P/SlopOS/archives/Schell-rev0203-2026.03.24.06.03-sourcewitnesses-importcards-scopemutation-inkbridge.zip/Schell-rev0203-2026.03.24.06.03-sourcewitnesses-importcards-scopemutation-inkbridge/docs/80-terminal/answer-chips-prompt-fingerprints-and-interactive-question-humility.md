# Answer chips, prompt fingerprints, and interactive-question humility

This surface exists to keep one very current shell+terminal temptation honest:
**modern terminal and agent products increasingly know how to answer prompts, auto-reply to repeated questions, or paste a remembered response back into a live PTY — but Schell should steal that comfort only if it keeps exact prompt identity, scope, and answer strength visibly separate.**

That is the smaller discipline that lets the shell feel luxurious without teaching operators that every repeated `y/N`, password prompt, menu choice, or helper question is semantically understood just because it looks familiar.

## 1) Why this surface exists

The archive already has:
- resident rooms and handback leases,
- input hosts and prompt leases,
- replay leases and quiet-authority strips,
- provider sidecars and input-needed checkpoints,
- quarantine/endorsement posture for imported text,
- and trusted chrome / anti-spoof separation.

But another seam has become more obvious in current tools:
**the product often sees a question-shaped prompt before it knows what kind of authority that prompt is really asking for.**

That matters because the current ecosystem now mixes at least these postures:
- exact auto-reply on a known byte sequence,
- regex-triggered send-text / inject-data actions,
- interactive agents that can respond to prompts inside a live PTY,
- hooks or notifications when a session needs input,
- and custom overlays that ask for input locally and then paste or send text back.

Without a named split, those postures collapse into one flattering but mushy “the terminal answered the prompt” story.

## 2) Keep these truths distinct

At minimum Schell should keep these as different objects:

1. **prompt witness** — the exact visible bytes / spans / provenance the operator or helper saw
2. **prompt fingerprint** — a bounded identity for the prompt instance or recognized family
3. **prompt owner** — shell-native, room-local program, provider-local sidecar, imported helper, or unknown
4. **answer chip** — a proposed reply object with exact bytes, source, scope, and expiry
5. **submit path** — paste, typed send, PTY write, helper callback, local sidecar only, or notify-only
6. **review strength** — observed / suggested / exact-known / endorsed / lease-reusable
7. **reviewed action** — the later stronger shell-owned chapter / receipt / launch object if the answer changes durable truth

These truths sit near each other.
They should not impersonate each other.

## 3) Schell probably needs a small prompt-answer taxonomy

A low-regret first taxonomy looks like:

- **notify-only checkpoint** — the product noticed that input is needed and asks the operator to answer directly
- **one-shot answer chip** — an exact proposed reply for this exact witnessed prompt instance only
- **family-scoped answer chip** — a reply reusable for a narrow recognized prompt family, still visibly weaker than exact fresh review
- **room-scoped answer lease** — a temporary permission to reuse a family answer inside one live room/session
- **provider-local reply rule** — useful for a sidecar/provider lane, but not shell-owned prompt truth
- **reviewed shell consequence** — a later stronger object only if the answer meaningfully changes shell-owned state or durable receipts

The exact names can change.
The important part is not treating every repeated answer as “the product understands the question now.”

## 4) Exact fingerprint beats fuzzy folklore

The safest convenience starts with exact witnessed identity.
If the product saw the exact same bytes in the same room/owner/posture, a one-shot or narrowly reusable answer chip can be reasonable.
But regex matches, confusable text, locale changes, theme wrappers, line wrapping, terminal noise, helper banners, or shell-integration drift should downgrade confidence quickly.

So Schell should prefer this ladder:
- **exact prompt fingerprint**,
- then **explicit prompt-family witness**,
- then **notify-only**.

That keeps comfort real without pretending fuzzy visual familiarity is semantic certainty.

## 5) Answer chips should confess their source and blast radius

Every answer chip should advertise:
- what prompt witness it came from,
- who proposed it,
- what bytes will actually be sent,
- which scope it applies to (`once`, `this room`, `this session`, `this command family`),
- whether it is exact or family-matched,
- and whether it will be sent as typed bytes, pasted text, or helper-side callback material.

That is the small honesty move that turns a dangerous auto-answer feature into a reviewable shell luxury.

## 6) “Needs input” is often better than “I answered it”

Current tools are quietly teaching an important lesson:
**notification can be the better luxury.**
A session that can tell the operator “this room needs input now” is already much better than a legacy blind terminal.
Schell should treat notify/watch/focus/resume as a first-class alternative to auto-answer, especially when prompt provenance or semantic meaning is weak.

That suggests a healthy escalation ladder:
- notify me,
- focus the right room,
- show the exact prompt witness,
- offer one or more answer chips,
- require explicit send unless a narrow lease exists,
- and mint stronger receipts only when a separately named seam justifies it.

## 7) Passwords, tokens, and high-risk prompts need a harder boundary

Not every question-shaped prompt belongs on the same answer path.
Schell should distinguish:
- harmless confirmations,
- bounded menu/choice prompts,
- idempotent room-local helper questions,
- secret entry,
- capability grant / approval,
- and unknown/high-risk interactive prompts.

Secret or grant-shaped prompts should not be solved by generic answer-chip reuse.
They need a stronger trusted-input / approval / secret-portal path, or a strict notify-only downgrade.

## 8) The super-awesome move is narrow reuse with visible humility

The right move to steal is not “automatic yes mode.”
It is **narrow reuse with visible humility**:
- exact prompt fingerprints,
- family cards that confess their weaker footing,
- once/room/session scope chips,
- explicit notify-versus-answer controls,
- and visible reply bytes before send.

That gives Schell a real delight upgrade for interactive work — confirmations, REPL prompts, helper questions, dev-server choices, room-local menus — without turning “looks familiar” into ambient authority.

## 9) First specimen set this surface wants

A good first proof set would show:
1. one exact byte-matched confirmation prompt that yields a one-shot answer chip,
2. one family-matched prompt that visibly downgrades from exact to heuristic,
3. one provider-local “needs input” checkpoint that stays notify-only,
4. one secret-shaped prompt that refuses generic answer-chip reuse,
5. one room-scoped lease that expires on room change or basis drift,
6. one replay view that shows the exact prompt witness plus reply bytes,
7. one spoof/confusable downgrade case,
8. and one transcript-safe notation for prompt owner / fingerprint class / answer scope / send path.

## 10) Bounded conclusion

One of the safest ways to make Schell feel radically better than legacy terminals is also one of the clearest:

**treat interactive questions as first-class witnessed objects rather than as loose text patterns that happen to look familiar.**

The terminal can absolutely help.
It can watch.
It can notify.
It can offer answer chips.
It can even reuse narrow answers when the fingerprint is strong enough.
But the archive should keep prompt witness, prompt fingerprint, prompt owner, answer chip, send path, and later reviewed action separately named.

That is enough to steal a lot of brilliance without freezing the architecture too early.
