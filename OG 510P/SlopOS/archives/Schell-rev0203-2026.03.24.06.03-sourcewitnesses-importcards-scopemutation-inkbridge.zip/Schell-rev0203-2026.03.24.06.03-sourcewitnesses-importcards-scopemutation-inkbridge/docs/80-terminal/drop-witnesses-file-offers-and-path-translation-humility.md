# Drop witnesses, file offers, path translation, and import humility

This surface narrows an older ingress family into a more specific seam:
**dropped text, dropped file offers, path-translated insertion, and remote upload helpers are neighboring conveniences, but they do not mean the same thing and Schell should stop letting them share one flattering “drag/drop happened” story.**

The current ecosystem is unusually explicit here.
Wayland models drag-and-drop as typed offers with advertised MIME types, accept/deny, and a chosen action.
The XDG File Transfer portal goes further by treating file-bearing drag/drop and copy-paste as a transfer session with a key, exported document access, optional writability, and automatic stop behavior.
Modern terminals then flatten or reshape that structure in product-specific ways: WezTerm pastes dropped file paths with configurable quoting, Windows Terminal can translate dropped paths for WSL/Cygwin/MSYS2/Mingw, Ghostty now shell-escapes pasted file paths and recently fixed a control-character issue in drag-and-dropped text, and iTerm2 can turn a modifier-qualified drop into an `scp` upload to a remote host.

Schell should steal the comfort while keeping the truth smaller.

## 1) Dropped text and dropped files are different ingress families

A dropped snippet of text is one kind of ingress.
A dropped file list is another.
A portal-backed file-transfer token is a third.
A remote-upload helper proposal is a fourth.

Legacy terminals often crush those differences into one outcome: insert something into the shell.
That is convenient, but it launders too much meaning.
The shell+terminal should instead keep a compact **drop witness** with fields like:
- `drop_family`,
- `payload_family`,
- `mime_posture`,
- `path_count`,
- `transfer_posture`,
- `translation_posture`,
- `target_posture`,
- `remote_helper_posture`.

That is enough to stop “I dropped it” from overclaiming what actually arrived.

## 2) Path quoting and path translation are transforms, not truth

WezTerm's `quote_dropped_files` setting and Windows Terminal's `pathTranslationStyle` are both valuable clues.
They show that terminals already know dropped paths may need adaptation before insertion.
But the adapted string is not the original object and it is not a durable file-transfer contract.
It is a transform for one target environment.

So Schell should keep these separately named:
- the offered file object or file list,
- the inserted path string,
- the quoting policy used,
- the path-translation family used,
- and the live target that requested the transform.

That keeps WSL/Cygwin/MSYS2/Mingw translation, shell escaping, or path quoting from impersonating canonical object identity.

## 3) File-bearing drop should usually prefer import or attach over raw insertion

The XDG File Transfer portal is the cleanest outside proof here.
It treats file transfer as an explicit session with retrieval and document-store export, not as magical path paste.
That is exactly the pressure Schell should absorb.

For file-bearing drops, better first actions are usually:
- import as fresh local object,
- attach as a reviewed input object,
- safe-open / inspect,
- quote a path into the prompt on purpose,
- or seed a workflow slot.

The bad default is to treat every dropped file as though the operator obviously meant “insert a shell-ready path right now.”

## 4) Remote upload helpers are stronger than ordinary drop

One of the nicest flashy steals in the current ecosystem is iTerm2's option-drag `scp` upload.
But that feature is also the perfect warning label.
A local file drop that becomes a remote file transfer is not just text insertion with extra glitter.
It is a separate action family with remote target identity, path selection, transfer progress, and failure posture.

So Schell should keep **insert path**, **import locally**, **attach to pending action**, **offer remote upload**, and **start reviewed transfer** as separately named rails.
That is how the shell+terminal gets to feel magical without letting a drag gesture widen authority silently.

## 5) Control bytes and hidden structure deserve their own warning lane

Ghostty's 2026 control-character fix is a useful reminder that dropped text can carry more than visible content.
The right move is not to panic about every drop.
The right move is to make structure visible when it matters.

A small witness should be able to say:
- dropped text contains hidden controls,
- dropped files were offered through a portal session,
- multiple files were offered,
- writable export was requested,
- translation to WSL path form was applied,
- remote upload was proposed but not started.

That keeps the comfort while refusing the folklore.

## 6) Super-awesome specimen moves that still stay decision-light

A small early specimen set could be excellent:

### a) File-offer chip instead of blind path insert
Show `drop:file-offer 3 items · import / attach / insert path` instead of pasting three paths immediately.

### b) Translation badge on inserted paths
Show `inserted as WSL path` or `shell-escaped for prompt` when the terminal transformed the visible text.

### c) Remote-upload proposal card
Turn a remote-upload-capable drop into `upload / inspect / cancel` rather than silently starting transport.

### d) Portal/session confession
If the source is a portal/file-transfer session, say so.
If it is a raw local path paste, say that instead.

### e) Transcript witness
A plain log should still be able to say `drop:file-offer 2 items · imported as fresh objects` or `drop:text 4 lines · held because hidden controls detected`.

## 7) The no-regret move

The best move right now is not to freeze one final drag/drop stack, one final portal treaty, one final remote upload engine, or one final file-object model.
It is to pin a smaller rule:
**Schell should model dropped text, dropped file offers, path translation/quoting, and remote upload helpers as first-class drop witnesses before it lets drag/drop convenience masquerade as plain typing, canonical object identity, or reviewed transfer authority.**

That keeps open:
- the final Wayland/X11/macOS/Windows drop plumbing,
- the final document/import object model,
- the final remote-upload backend,
- the final rich-payload MIME taxonomy,
- and the final approval UI for stronger transfer actions.
