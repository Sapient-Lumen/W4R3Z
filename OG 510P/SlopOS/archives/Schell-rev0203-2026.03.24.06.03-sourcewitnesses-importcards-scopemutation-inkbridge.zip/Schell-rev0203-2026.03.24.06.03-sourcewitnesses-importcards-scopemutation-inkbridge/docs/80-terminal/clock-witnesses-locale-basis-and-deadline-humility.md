# Clock witnesses, locale basis, and deadline humility

This surface keeps one boundary explicit:
**a great shell+terminal should let operators review clock kind, locale/timezone basis, and deadline posture — but it should not let ambient `LC_*`, `TZ`, host sync state, clock namespaces, or historical receipts impersonate one another.**

Modern systems already have real clock/locale machinery:
- POSIX locale categories can change shell pattern behavior and text ordering,
- ordinary tools render timestamps according to locale and timezone rules,
- runtimes can distinguish monotonic from realtime clocks,
- containers/namespaces can change clock footing,
- and time-sync systems can expose both rough and stronger synchronization states.

That is all worth stealing.
The failure mode is equally consistent:
- locale stays invisible until sorting/globbing surprises someone,
- wall clock and elapsed time get flattened into one “time” story,
- timezone rendering gets mistaken for deadline enforcement,
- sync enabled gets mistaken for accurate reference time,
- and stale badges or receipts start pretending to prove present authority.

Schell can do better without picking one final locale engine, timeproof stack, or clock-admin substrate.

## 1) The shell needs one exact clock witness

A good first object is **clock witness**.

A clock witness is a compact shell-owned descriptor for the temporal footing a reviewed action will enter.
It is not a full calendar/time API.
It is not a final timer subsystem.
It is the thing the terminal can point at when it says “this command depends on *this exact kind* of clock footing.”

A v0 witness probably needs:
- `clock_kind` — `monotonic_coarse` / `monotonic_fine` / `realtime` / `mixed` / `unknown`,
- `resolution_posture` — coarse / fine / provider-declared / unknown,
- `adjustable` — yes / no / unknown,
- `deadline_basis` — monotonic_intent / wallclock_render_only / mixed / none,
- `sync_posture` — live / historical / unavailable / degraded,
- `proof_posture` — none / lower_bound_only / historical_only / unknown,
- `receipt_posture` — exact_shell_outcome / provider_addendum / unavailable,
- `notes_ref` — optional explanation or refusal card.

That is enough to make clock truth real without freezing a giant portability model.

## 2) Locale basis should be named, not implied

Current shells still hide one of the most common sources of confusion:
locale changes meaning.
A reviewed action can differ materially depending on:
- explicit `LC_ALL`,
- category-specific `LC_COLLATE`, `LC_CTYPE`, `LC_TIME`, and friends,
- fallback `LANG`,
- or explicit omission.

Schell should therefore show named locale posture up front.
The operator should not have to reconstruct it from:
- host login state,
- inherited rc/profile behavior,
- a container image default,
- or a mysterious difference in sort/order/glob behavior.

A **locale witness** can stay small and still be useful:
- exact explicit env entries,
- exact omission,
- compat/default host basis,
- or unknown/degraded basis.

## 3) Timezone basis deserves its own witness family

A command can have a reviewed clock witness and still differ radically in timestamp meaning.
Useful distinctions include:
- explicit `TZ`,
- default host/system timezone,
- UTC-locked compatibility posture,
- unknown compat timezone.

This matters because timezone is not just presentation trivia.
It affects how the operator reads timestamps, compares receipts, and interprets deadline displays.

A **timezone witness** should therefore say:
- where timezone rules come from,
- whether the basis is explicit or ambient,
- whether the runtime is degraded from the archive's preferred posture,
- and whether UTC-locking is a reviewed compatibility choice rather than folklore.

## 4) Deadlines should say which clock they stand on

This is a crucial shell lesson.
A timeout, retry window, or cancel-at time can rest on:
- monotonic elapsed-time intent,
- realtime calendar intent,
- a wall-clock rendering of a monotonic intent,
- or historical receipt metadata.

Those are all valuable.
They are not the same.

Schell should let the terminal render them richly:
- “monotonic deadline, rendered in local wall clock for convenience”,
- “realtime deadline from reviewed schedule source”,
- “historical receipt only; not current timer state”,
- “sync/proof unavailable; display only”.

That is a genuine super-awesome move that still stays decision-light.

## 5) Sync state and proof state should stay humble

A shell can gain a lot by showing:
- whether time sync is enabled,
- whether the last sync is fresh or stale,
- whether proof-backed lower-bound state exists,
- whether a current runtime is degraded.

But it should avoid pretending to prove:
- that the current wall clock is globally correct,
- that a historical proof still speaks for the present,
- that deadline enforcement used the same source now visible in chrome,
- or that a container/namespace shares the same footing as the host.

A **sync/proof badge** should remain weaker than present authority.

## 6) Reproducibility rails are a luxury worth stealing

One especially good idea worth stealing is an explicit **repro rail**.
For many commands, the operator may want a reviewed insertion offer that says:
- use `LC_ALL=C` for stable byte-ish collation and diagnostics posture,
- use `TZ=UTC0` for unambiguous timestamps,
- keep the original command visible beside the adjusted one,
- and confess that this is a compatibility/repro choice rather than inherent command truth.

That gives Schell a luxurious practical move without prematurely standardizing one universal locale/time contract.

## 7) Historical time receipts should stay bounded

A good time receipt might include:
- exact command/action basis,
- clock kind and resolution posture at review time,
- locale/timezone basis at review time,
- optional deadline basis,
- exact exit status / signal posture,
- optional sync/proof badge,
- optional redacted provider/source facts,
- and a claim-strength badge when the runtime could not prove more.

It should avoid pretending to prove:
- current clock footing,
- current timezone configuration,
- current locale inheritance,
- current sync freshness,
- or that the same deadline still exists now.

## 8) Great ideas worth stealing right now

### a) Named clock-kind badges
Tiny but very high value:
- monotonic coarse,
- monotonic fine,
- realtime,
- mixed,
- unknown.

### b) Locale and timezone provenance badges
A command should be able to say “explicit `LC_ALL=C`, explicit `TZ=UTC0`” or “host default locale, unknown timezone override”.
That is excellent operator hygiene.

### c) Deadline chips with basis honesty
A timeout pill should say whether it rests on monotonic intent or wall-clock rendering.

### d) Repro rails
Wonderful and practical:
- insert reproducible locale/time posture,
- compare before/after,
- run only after fresh review.

### e) Sync/proof badges that stay weaker than time authority
Useful without overclaiming.

### f) Historical time receipts with claim-strength posture
Keep post-run evidence useful without turning old time facts into live authority.

## 9) Things Schell should refuse

### Refuse ambient-locale-as-baseline
Locale should be explicit, not invisible.

### Refuse wallclock-equals-deadline folklore
Displayed time and elapsed-time enforcement are different things.

### Refuse sync-enabled-equals-correctness
A sync badge is not the same as trustworthy current time.

### Refuse timezone-collapse
Timestamp rendering and security/deadline semantics are not the same object.

### Refuse stale-status-equals-live-footing
Historical sync/proof/time receipts should never impersonate current authority.
