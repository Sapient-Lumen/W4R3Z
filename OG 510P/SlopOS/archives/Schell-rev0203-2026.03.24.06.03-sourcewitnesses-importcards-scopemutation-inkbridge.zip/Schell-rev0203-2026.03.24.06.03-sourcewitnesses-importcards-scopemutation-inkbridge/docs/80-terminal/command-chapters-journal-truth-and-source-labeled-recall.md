# Command chapters, journal truth, and source-labeled recall

This surface records a new no-regret candidate cluster for Schell:
**make command chapters exact and journals brilliant without letting history, recall, or search quietly become approval cache, live-state proof, or hidden rerun power.**

The design pressure comes from three directions:

- SlopOS keeps control state, request state, recent-items/history posture, and session-selection posture sharply separated.
- Modern terminal shell integration keeps proving that prompt / input / output / outcome boundaries should be shell-known.
- Current tools are finally admitting that operator history and tool-issued commands should not silently merge into one recall story.

## 1) A command chapter is not just a nice visual block

Schell should treat each shell-known command as a compact **command chapter**.
That chapter is not merely whatever the renderer grouped together.
It is a shell-owned object with explicit boundaries.

A v0 chapter probably needs:
- `chapter_ref` — durable exact identity,
- `prompt_ref` — the prompt boundary that led into it,
- `input_ref` — the exact input or reviewed-action object,
- `output_refs` — bounded output capsule refs,
- `outcome_ref` — receipt / denial / exit witness when present,
- `ground_ref` — cwd/env/activation witness,
- `peer_ref` — remote peer witness when relevant,
- `lane_kind` — direct / proposal / workflow / replay / background-inspect,
- `source_kind` — operator / workflow-seed / agent / plugin / imported / replay,
- `trust_grade` — guessed / marked / shell-authenticated.

That is enough to stop chapter UX from depending on fragile renderer folklore.

## 2) Journal entries should stay exact and non-authoritative

A **journal entry** is the chapter’s durable recall surface.
It is excellent for navigation, search, browsing, comparison, and suggestion.
It is not proof that the old action is safe to repeat now.

Good journal posture:
- journal entries preserve chapter identity and chapter-local context,
- journal entries can be searched and filtered aggressively,
- journal entries may be promoted into explicit workflow seeds later,
- but journal entries are **not** live handles,
- **not** remembered approvals,
- and **not** evidence that current ground/peer/authority still matches.

The shell should make that distinction obvious.

## 3) Partition the journal on purpose

One huge historical mistake is flattening everything into one giant history file.
Schell should refuse that.

A good first partition set is probably:
- **peer scope** — local vs exact remote peer,
- **lane kind** — direct / proposal / replay / workflow,
- **source kind** — operator / agent / plugin / imported,
- **visibility class** — operator-private / lane-local / shared artifact / ephemeral only.

That lets the shell stay helpful without turning one prompt’s past into another prompt’s silent authority story.

## 4) Add explicit history-pollution guards

Operator history should be protected.
Commands that were:
- proposed by an agent,
- run as tool assistance,
- executed only for replay/testing,
- or imported from another surface,

should not silently colonize the operator’s personal recall journal.

A good default would keep those chapters visible in a chapter browser, but place them under a distinct badge or journal class until the operator explicitly promotes them.

That is one of the cleanest quality-of-life wins available.
It makes journals more useful while also making them more honest.

## 5) Recall should have a ladder, not one ambiguous rerun button

A recalled chapter should offer bounded next moves.
Candidate ladder:
- **inspect chapter** — read the exact input/output/outcome again,
- **insert command** — place the literal command into active input,
- **quote-insert** — preserve suspicious text literally,
- **derive reviewed action** — build a fresh reviewed action on current basis,
- **attach chapter** — send the exact chapter to a help or workflow lane.

A stronger “review-rerun” action should downgrade when:
- ground drifted,
- peer drifted,
- authority widened,
- the source was non-operator,
- or the chapter was only heuristically grouped.

Then the right answer is a hold card, not a brave rerun.

## 6) Chapter browsers are worth stealing

A custom shell+terminal should have one excellent way to browse recent chapters.
This could be:
- a palette,
- a side strip,
- a quick terminal,
- or a dedicated observational lane.

The exact UI is still open.
The important part is that chapter browsing is:
- fast,
- searchable,
- source-labeled,
- peer-aware,
- and observational by default.

That can make the terminal feel dramatically smarter without claiming any extra authority.

## 7) Chapter-local fields should stay visible enough to teach the model

A chapter browser or hover surface should be able to show at least:
- source badge,
- lane badge,
- peer badge,
- outcome badge,
- ground drift badge,
- and trust grade.

That is how the terminal teaches the operator not to confuse:
- “I can find this again,”
- with “I can safely do this again right now.”

## 8) Transcript truth still matters

The transcript does not need every ranking signal or browse-state change.
It does need the load-bearing truths:
- that a command chapter existed,
- what its exact source/lane/peer class was,
- whether it entered the operator journal or a separate journal class,
- whether recall produced insert / review / attach / hold,
- and whether stronger replay/rerun was downgraded due to drift.

That is the portable minimum.

## 9) No-regret first cut

A first specimen set could stay small:

1. one shell-authenticated local command chapter with exact output selection,
2. one remote command chapter that lands in a separate peer partition,
3. one agent-issued chapter that is visible but excluded from the operator journal by default,
4. one recall attempt that downgrades to hold because ground drifted,
5. one exact chapter attachment into a help lane,
6. and one transcript slice showing chapter creation → journal classification → recall outcome.

That is enough to learn a lot without freezing a history database, chapter-sync model, notebook architecture, or plugin ecosystem.
