# Drift cards, then/now footing, and refresh-before-rerun humility

**Schell should absolutely steal the best current command-decoration, command-info, and attach-context ideas — but the next truly great luxury is cheap then-versus-now footing comparison, not stronger default replay.**

## 1) Why this seam matters now

The archive now has:
- command chapters,
- semantic marks,
- chapter inspectors,
- why / why-not rails,
- settlement cards,
- and attach-for-help bundles.

The next high-value question is narrower:
**once a chapter is inspectable, how cheaply can the operator compare the chapter's original footing with the current footing before taking the next stronger act?**

That question matters because the shell+terminal is about to feel very capable.
Once that happens, the dangerous shortcut is obvious:
- a remembered command looks runnable,
- a chapter hover looks authoritative,
- a help bundle looks exact,
- and one visible success row starts feeling like permission to repeat.

The right luxury answer is not “make rerun easier first.”
It is **make drift obvious first.**

## 2) Learn the old lesson: remembered footing decays faster than remembered text

The past keeps repeating the same warning in different clothes.
Remembered text ages more slowly than remembered footing.
A command line can still look right after:
- cwd moved,
- peer changed,
- repo basis advanced,
- overlay/config activation drifted,
- borrowed authority narrowed,
- tool origin changed,
- or startup semantics stopped matching what produced the old result.

That means the shell+terminal should avoid treating a chapter's remembered text as the thing to trust most.
The stronger object is the **footing packet** around that text:
- exact or graded command identity,
- cwd family,
- env/activation layers,
- peer/subject posture,
- authority summary,
- tool origin,
- timing/freshness,
- and settlement.

## 3) The right object is a then/now compare card

A chapter inspector should be able to open one compact **then/now compare card**.
Not one giant diff dump.
Not one vague “environment changed” toast.
One typed card with rows like:
- `command_identity_then` vs `command_identity_now`,
- `cwd_then` vs `cwd_now`,
- `peer_then` vs `peer_now`,
- `repo_basis_then` vs `repo_basis_now`,
- `activation_then` vs `activation_now`,
- `authority_then` vs `authority_now`,
- `tool_origin_then` vs `tool_origin_now`,
- `settlement_then` vs `current_derivability_now`.

Each row should answer four things quickly:
1. **same / changed / unknown / unavailable**
2. **what changed**
3. **why it matters for the next act**
4. **what the strongest honest next verb is**

That makes compare practical instead of ceremonial.

## 4) “Refresh before rerun” should feel like help, not punishment

The custom shell+terminal should normalize a small set of refresh verbs:
- refresh footing,
- reacquire cwd/basis,
- restate overlay/config gates,
- rebind authority summary,
- derive reviewed action on current basis,
- or fall back to insert-only.

That is much better than one binary:
- rerun,
- or hard refusal.

A good compare card can say:
- `same command, changed basis — derive reviewed action`,
- `same basis, narrower authority — inspect or re-review`,
- `same peer, stale overlay — refresh activation first`,
- `remote hop changed — attach or re-enter clean`,
- `command identity drifted — reveal exact invoker before anything stronger`.

## 5) Drift should be typed, not flattened

Different changes deserve different operator instincts.
Schell should keep them distinct.

### 5.1 Basis drift

A repo head change, worktree dirtiness change, or imported artifact basis change is not the same thing as env drift.
This should trigger compare-current-basis behavior, not a generic stale badge.

### 5.2 Activation drift

A different overlay, profile, hook pack, or env layer source is not the same thing as a cwd move.
This should trigger a refresh-activation lane.

### 5.3 Peer drift

A resumed room, a different host, a different container, or a replaced remote session is not the same thing as a local process restart.
This should trigger peer reassertion or attach honesty.

### 5.4 Authority drift

A narrowed wallet, missing grant, or different borrowed-authority strip is not the same thing as historical command recall.
This should trigger review or derivation, not optimistic replay.

### 5.5 Settlement drift

A chapter that exited once is not the same thing as a chapter whose downstream adoption still holds.
This should trigger settlement inspection rather than a cozy success badge.

## 6) The shell+terminal can steal several brilliant ideas here

### 6.1 Cheap drift halos in hovers

The hover does not need the full compare card.
It can show:
- same / changed / unknown,
- the two or three load-bearing changed rows,
- and the strongest honest next verbs.

### 6.2 Compare chips beside history/recall rows

A chapter browser row can carry tiny chips such as:
- `basis changed`,
- `peer changed`,
- `overlay stale`,
- `authority narrower`,
- `history only`.

These are much more actionable than “old.”

### 6.3 Refresh bundles instead of rerun shortcuts

When drift is real, the better button is often:
- `derive on current basis`,
- not `run exactly this again`.

### 6.4 Attach exact chapter plus current drift

If a user asks for help, the bundle should include both:
- the original chapter footing,
- and the current drift summary.

That is materially stronger than attaching only command text and output.

### 6.5 Typed refusal cards

A refusal should say which drift class blocked the stronger act and how to regain footing.
That makes the shell feel expert rather than obstinate.

## 7) Companion-cube pressure makes compare cards especially powerful

- **SlopOS** gives Schell exact launch objects, explicit cwd/env/startup posture, and bounded result meaning. Compare cards should expose those truths rather than reconstruct them from prompt folklore.
- **ViewFS** says exact basis, delta recipe, apply session, reconstructed object, and fallback lane are different objects. Compare cards should preserve that discipline.
- **Foundry** says config layers and overlays are mutable footing, not ambient comfort.
- **Harbor** says stronger acts should climb visible risk ladders.
- **Helm** says exit, drain, durable receipt, and downstream adoption are different endings.
- **Ward** and **Steward** say freshness and liveness should stay source-labeled.

This means compare cards are not extra bureaucracy.
They are where the datacube's best distinctions become operator-usable.

## 8) What Schell should refuse for now

Refuse for now:
- one universal drift score,
- one final serialized footing-diff schema,
- one assumption that compare always has a live “now” side,
- one policy that every changed row automatically blocks replay,
- or one requirement that every terminal path preserve enough truth to compare everything.

The better move is one small typed compare specimen set.

## 9) First specimen set this seam wants

1. one chapter whose footing still matches now,
2. one chapter with repo-basis drift,
3. one chapter with overlay/env-layer drift,
4. one chapter with peer drift,
5. one chapter with narrower authority than before,
6. one compare card opened from a hover,
7. one compare card opened from a history row,
8. one attach-for-help bundle that includes original footing plus current drift,
9. one derive-on-current-basis path,
10. and one typed refusal card that explains why exact rerun is blocked.

## 10) Compact conclusion

The next super-awesome move is not smarter replay.
It is **cheap, typed then-versus-now comparison**.

That makes history faster to trust, not merely faster to trigger.
It also lets Schell stay loyal to SlopOS exactness while stealing the best local delight from modern terminals.
