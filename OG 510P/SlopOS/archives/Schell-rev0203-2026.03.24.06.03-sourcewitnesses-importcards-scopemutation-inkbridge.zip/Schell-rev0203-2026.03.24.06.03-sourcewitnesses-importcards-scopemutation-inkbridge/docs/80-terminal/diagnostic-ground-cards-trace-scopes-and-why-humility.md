# Diagnostic-ground cards, trace scopes, and why-humility

This surface records a new no-regret candidate cluster for Schell:
**treat explanation, tracing, and support export as a small family of explicit diagnostic objects instead of letting xtrace chatter, helper logs, replay residue, and giant debug bundles collapse into one flattering “debug mode tells the truth” story.**

Schell already has shell-integration humility, config-ground cards, execution-ground witnesses, pager witnesses, history honesty, and recording/support-adjacent surfaces.
This pass narrows a seam those earlier surfaces left deliberately open:
**how the shell+terminal should answer “why did this happen?”, “what exactly did you observe?”, and “what evidence can I safely share?” without letting diagnosis quietly become authority.**

The design pressure comes from three directions:
- SlopOS keeps pushing tracing, inspect snapshots, and triage toward bounded observational export rather than ambient power.
- Current shells and terminals keep proving that narrow diagnostic lenses are dramatically nicer than one giant debug mode.
- The broader ecosystem keeps admitting that trace logs, replay, config snapshots, performance captures, and support bundles are all different kinds of evidence.

## 1) One rule to keep visible: narrow why beats giant trace

Classic shell debugging still over-relies on trace floods.
`set -x`, prompt-time echo, stderr braids, and support logs are useful, but they answer too many different questions at once.

A better first Schell rule is smaller and more honest:
- **diagnostic ground** says what question is being answered,
- **trace scope** says which subsystem or chapter is being observed,
- **evidence posture** says whether the surface is live, historical, exported, or replayed,
- **share tier** says whether a bundle is local-only, sanitized, or stronger,
- and **authority posture** says whether the surface can only explain or can also ask for a stronger reviewed action.

That split removes a lot of operator confusion before any big architecture is chosen.

## 2) Diagnostic-ground cards should stay separately named

A user-friendly shell+terminal should let someone ask:
- why did that keybinding fire,
- why did the prompt resize strangely,
- why did that completion appear,
- why is startup slow,
- why is shell integration missing,
- why is this env value different,
- or why did the terminal warn about this paste.

Schell should therefore keep compact **diagnostic-ground cards** that can say things like:
- input decode,
- prompt composition,
- config winner,
- env/export delta,
- shell integration posture,
- helper authorship,
- command launch plan,
- progress/profiler slice,
- renderer/perf issue,
- or exported support evidence.

This does not require a giant observability stack.
It only requires refusing to overstate what one diagnostic surface proves.

## 3) Trace scopes should be local and visibly diagnostic

Bash and fish already teach an important lesson: trace output should have its own sink.
PowerShell sharpens the lesson further by separating traceable components from listeners and destinations.

Schell should therefore keep **trace scopes** that are:
- subsystem-specific,
- chapter-local by default,
- visibly routed to a diagnostic sink,
- bounded in size/time,
- and easy to export as evidence without confusing them with command output.

Good first scopes might include:
- input/key decoding,
- startup/config load,
- prompt/completion decisions,
- env activation delta,
- command launch/cancellation/progress,
- terminal integration/helper behavior,
- and renderer/performance diagnostics.

## 4) Helper breadcrumbs matter more than heroic inference

If a terminal or helper changed behavior, Schell should not make the operator guess.
A helper should leave a breadcrumb.

Schell should therefore keep a **helper-breadcrumb card** that can say:
- native shell behavior,
- manually sourced helper,
- terminal-injected helper,
- adapted remote/mux helper,
- recovered historical residue,
- or unknown.

This is one of the highest-value small moves available.

## 5) Replay, snapshots, and support bundles should confess their historical posture

Replay views, debug overlays, instant replay, config snapshots, and performance captures are useful because they preserve evidence.
But they are not exact live truth.

Schell should therefore keep:
- **live explain cards**,
- **historical snapshot cards**,
- **replay cards**,
- and **support-bundle cards**
separately named.

A support bundle card should carry:
- included entry kinds,
- sanitization tier,
- correlation ids / chapter ids,
- whether the bundle is local-only or exported,
- and whether it was assembled automatically, by operator request, or by a diagnostic rule.

## 6) Triage should recommend, not secretly spend authority

The best diagnostic next step is often obvious:
collect a sanitized bundle, compare two configs, or open a prompt/input trace.
That is useful.
The danger begins when diagnosis quietly performs stronger action.

Schell should therefore keep triage/explain output in a **recommendation lane**:
- explain,
- diff,
- collect suggested evidence,
- ask for stronger export,
- or propose a reviewed action.

That lets the shell be smart without becoming sneaky.

## 7) Super-awesome specimen ideas that still stay decision-light

A first specimen set could stay small but teach a lot:
1. one keybinding why-card showing raw input, winning rule, and losers;
2. one prompt why-card separating config ground from runtime fact;
3. one shell-integration why-card with helper breadcrumb and expected markers;
4. one chapter-local startup trace scope with a separate trace sink;
5. one slow-command profile card that stays chapter-local and explicitly historical once saved;
6. one sanitized support bundle card that lists exact included artifacts;
7. one replay card that links back to the live command chapter it came from;
8. and one diagnostic receipt that binds a why-card to the bundle exported from it.

## 8) The no-regret move

The best move right now is not to freeze a tracing daemon, one support-bundle format, one helper log schema, or one always-on telemetry policy.
It is to pin one stronger rule:
**Schell should model diagnosis as diagnostic-ground cards, bounded trace scopes, helper breadcrumbs, historical-evidence badges, chapter correlation ids, and explicit support-bundle tiers before it lets xtrace, replay, exported logs, or giant debug bundles masquerade as one generic shell-truth surface.**

That keeps the archive free to defer:
- the final tracing engine,
- the final diagnostics helper stack,
- the final snapshot/export schema,
- the final triage-rule engine,
- the final correlation-id protocol,
- and the final always-on observability policy.
