# Chapterbooks, narrative cells, and state-order humility

This surface exists to keep one especially tempting luxury bundle honest:
**Schell should absolutely steal narrative runbooks and notebook-like chapterbooks, but it must not let prose, runnable shell chapters, reactive cells, stored outputs, and durable document handles collapse into one flattering “this page is the live shell” story.**

The point is not to avoid narrative documents.
The point is to keep them legible.
A shell+terminal becomes dramatically more useful when an operator can explain an incident in prose, pin exact command chapters next to a diagnosis, embed parameterized recovery steps, reopen that work later, and share selected parts.
It becomes dangerous when opening the page implies trust, when trust implies execution, when execution implies durable persistence, or when the document itself quietly becomes an authority token for the underlying repo/files/services.

## 1) Keep narrative blocks weaker than shell truth

At minimum, Schell should separate:
- **prose block**,
- **exact command chapter block**,
- **workflow seed block**,
- **reactive/runtime block**,
- **historical output artifact**,
- and **durable chapterbook handle**.

Those blocks can live near one another.
They should not impersonate one another.
A prose block is narration.
A command chapter block is a reviewed action candidate.
A workflow seed is a reusable scaffold.
A runtime block implies a runtime kind and state-order rules.
A historical output artifact is evidence, not live truth.
A durable chapterbook handle is a document identity, not execution authority.

## 2) A chapterbook witness should describe actual footing

A healthy chapterbook witness should carry things like:
- chapterbook identity,
- scratch versus durable posture,
- block kind,
- runtime kind when applicable,
- historical-versus-live output posture,
- share/publication posture,
- selected included artifacts,
- docref or local-handle posture,
- secret/redaction posture,
- and reopen-versus-run posture.

It should also make clear what it is **not**:
- not proof that the page is currently trusted for execution,
- not proof that referenced files or services were granted,
- not proof that stored outputs match the current world,
- and not proof that reopening the document revives its old runtime.

## 3) Shell-bearing blocks should default to insert, not auto-run

The default action for an exact command chapter block should usually be:
- inspect,
- insert into active input,
- or promote into a workflow seed.

It should usually **not** be:
- run immediately on focus,
- run merely because the page reopened,
- or inherit execution authority from nearby prose.

The whole design benefit is that a chapterbook can make shell work easier **without** pretending the document itself is the shell.

## 4) Runtime blocks need visible state-order posture

If Schell ever supports richer non-shell blocks, the page must say what sort of state story applies.
At minimum, a runtime-bearing block should say:
- exact runtime kind,
- reactive versus manual execution posture,
- deterministic versus historical-only posture,
- whether outputs are recomputed, stale, or captured,
- and whether side effects are possible.

That one witness family would prevent a lot of notebook folklore from sneaking in by default.

## 5) Historical output should stay smaller than live output

A chapterbook may very reasonably contain prior output:
- an error excerpt,
- a metrics snapshot,
- a rendered chart,
- or one saved service status artifact.

That is useful evidence.
But it is still **historical output** unless recomputed now under a visible runtime.
Schell should say so.
A historical artifact should remain copyable, exportable, and citable without claiming it is still live.

## 6) Durable chapterbooks need explicit promotion and explicit reopen posture

A scratch narrative page should be cheap.
A durable chapterbook should be stronger.
So Schell should keep separately named moves like:
- create scratch page,
- promote to durable chapterbook,
- reopen chapterbook,
- clone chapterbook as scratch,
- publish selected parts,
- and export exact local artifact.

A durable handle should recover the document.
It should not automatically recover all referenced runtime state or silently widen access to the underlying local objects.

## 7) Publication remains a second workflow

Even when a chapterbook exists, sharing still belongs to the separate share ladder.
A chapterbook can be:
- local only,
- durable but private,
- selectively exported,
- or published/shared through a stronger lane.

The shell+terminal should say which one happened.
A durable page existing locally is not the same thing as a published chapterbook link.

## 8) Secret-bearing or authority-bearing pages deserve stricter posture

A chapterbook may include:
- hostnames,
- repo coordinates,
- parameter defaults,
- incident timelines,
- service URLs,
- or secret-adjacent command shapes.

So Schell should support stronger rails like:
- secret-bearing badges,
- redaction preview before durable promotion or publication,
- output-history badges on stored artifacts,
- refusal to auto-run shell-bearing blocks from untrusted pages,
- and refusal to publish unsafe pages without a stronger review step.

## 9) Keep the verbs separate

Schell should not collapse all chapterbook actions into one verb.
At minimum, the verbs should stay separately named:
- inspect block,
- insert chapter,
- promote to workflow seed,
- run with review,
- capture historical output,
- recompute runtime block,
- promote page to durable chapterbook,
- reopen chapterbook,
- export exact artifact,
- publish selected parts,
- and revoke publication.

Those verbs imply different residue and different authority.
The shell+terminal should say so.

## 10) A compact first proving slice

A compact first specimen should show:
1. one prose block explaining an incident,
2. one exact command chapter block that inserts into input,
3. one parameterized recovery block with visible arguments,
4. one embedded workflow seed,
5. one historical output artifact explicitly marked non-live,
6. one stronger runtime block with visible runtime/state-order posture,
7. one promote-to-durable chapterbook step that mints a distinct document identity,
8. one reopen flow that is weaker than execution,
9. one publication path that still routes through the share witness family,
10. and one refusal to auto-run shell-bearing blocks from an opened or shared page.

That is enough to make Schell feel unusually capable without freezing the final notebook runtime, document model, persistence stack, publication backend, or collaboration architecture.

## 11) Things to refuse for now

Refuse for now:
- one generic “runbook page” action that hides whether the move is inspect, insert, run, recompute, persist, or publish,
- opening a page silently trusting or executing its shell-bearing blocks,
- durable chapterbook handles acting as bearer access to referenced local objects,
- historical output artifacts masquerading as live state,
- and narrative prose implicitly approving nearby actions.

The right law is:
**steal the comfort of narrative runbooks and notebook-like chapterbooks — but keep document identity, runtime state, execution authority, and publication posture visibly stronger than charm.**
