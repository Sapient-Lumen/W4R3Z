# Capability witnesses, profile budgets, and degrade honesty

This surface names a terminal seam that modern tools keep proving is real:
**Schell should aggressively steal brilliant terminal luxuries, but it should do that by naming capability posture explicitly so shell truth survives when shell integration, terminfo, keyboard upgrades, graphics, SSH wrappers, mux passthrough, or platform shims are absent, partial, or degraded.**

SlopOS already gives the right design pressure here.
Open protocols beat hidden lock-in.
Adapters should be named and auditable.
Exact execution truth stays stronger than nearby convenience.
That is exactly the posture Schell should import while both datacubes are still design-phase.

## 1) The shell should know when a luxury is real, adapted, or absent

Classic terminals often push capability discovery into folklore:
- inspect `$TERM`,
- guess from terminal brand,
- hope the remote machine has the right terminfo,
- hope tmux forwards the sequence,
- hope the platform does not strip it,
- and if it fails, blame the application.

That is not good enough for Schell.
A custom shell+terminal can do better by naming capability posture directly.

## 2) Preserve portable baseline truth before enhancement

The first rule should stay simple:
- reviewed action truth,
- transcript truth,
- chapter boundaries,
- explicit receipts/denials,
- and exact open/insert/review flows
should never depend on rich terminal enhancement.

A session may be luxurious or degraded, but the operator should not lose the ability to understand what happened.

## 3) A compact capability witness family would already be enough

Schell likely does not need giant negotiation machinery first.
A compact witness family could already make the system much more honest:
- `baseline_profile` — plain text / baseline semantic / transcript-safe
- `prompt_profile` — no marks / native marks / injected shell marks / historical-only
- `input_profile` — legacy keys / upgraded keys / partial-upgrade / unknown
- `media_profile` — none / local render / tunneled / degraded / historical residue
- `route_profile` — local / remote / mux / remote+mx / platform-shimmed
- `adapter_posture` — none / ssh-env fallback / terminfo-copied / passthru / wrapper-risk
- `degrade_reason` — no terminfo / unsupported shell / platform strip / mux redraw loss / unknown

That is enough to unlock much better operator honesty without freezing a protocol stack.

## 4) One profile ladder would keep the system luxurious without overclaiming

A practical v0 ladder could look like this:

1. **Portable baseline** — transcript-safe text truth only.
2. **Shell-known semantic** — prompt/command/cwd witnesses exist.
3. **Input enhancement** — richer keyboard/reporting features are active.
4. **Renderer-local enhancement** — media, chrome, richer viewlets, or stronger selection luxuries are active.
5. **Adapted enhancement** — luxuries survive through a named adapter or passthrough.
6. **Historical enhancement** — restored or replayed luxury surfaces are visible but weaker than live truth.

The key is that every stronger level stays visibly weaker than exact shell truth.

## 5) Remote and mux hops should be first-class degrade events

One of the oldest terminal mistakes is pretending that SSH or tmux is transparent.
It is not.
A capability-rich shell+terminal should say so explicitly.

At minimum, Schell should be able to distinguish:
- local native support,
- local support tunneled through SSH wrapper help,
- local support degraded to a safer fallback,
- mux passthrough with caveats,
- platform-stripped behavior,
- and unknown/legacy posture.

That would make many current terminal frustrations legible instead of mysterious.

## 6) A great UX move is capability-aware feature offers

One genuinely brilliant idea worth stealing is not just hiding unavailable features.
It is offering them honestly.

For example:
- “enable prompt marks here”
- “copy/install terminfo on this peer”
- “fall back to portable profile for this remote”
- “view why click-to-move is unavailable”
- “open this chapter in transcript-safe mode”
- “show current enhancement losses across SSH/mux/platform”

That makes the terminal feel smart without pretending detection is certainty or upgrades are free.

## 7) Protocol choice should remain deferred

This is the most important discipline on this pass.
Schell should **not** answer capability posture by prematurely freezing:
- one shell-integration mechanism,
- one keyboard protocol,
- one graphics protocol,
- one TERM value,
- one mux passthrough story,
- or one platform-specific fallback path.

The archive only needs a smaller commitment:
**every powerful terminal luxury should declare whether it is baseline, shell-known, negotiated, adapted, degraded, or historical.**

## 8) A narrow v0 is enough

Schell can start very small here:
- one capability-witness family,
- one portable baseline profile,
- one degrade-honesty surface for SSH/mux/platform hops,
- one rule that transcripts stay truthful when luxuries disappear,
- and one requirement that capability upgrades be queryable or visibly configured rather than guessed from terminal folklore.

That is already enough to make the shell+terminal materially better than the old ecosystem without choosing the final protocol stack too early.
