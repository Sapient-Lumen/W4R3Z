# Editor-bridge witnesses, draft roundtrips, and autorun humility

**Schell should absolutely steal excellent “open this command in a real editor” comfort — multiline drafting, syntax-aware editing, external-IDE roundtrips, and rich compare-on-return — but it must not let temp files, editor exit, autosave, or historical `fc` folklore flatten into one flattering “I edited it, therefore it should now run” story.**

## 1) Why this seam matters

A super-awesome shell+terminal gets dramatically better the moment long commands, structured invocations, and reusable snippets can leave the tiny prompt and spend a moment in a real editor.
That helps when operators need to:
- reshape a large multiline command,
- tune environment blocks or structured arguments,
- compare a generated command against an older runbook,
- bring a repo-local helper draft into a proper editor,
- or keep editing comfort high without turning the prompt itself into a full IDE.

But this is also a classic place where shells blur too much.
A draft exported to a temp file is not the live prompt.
A saved editor buffer is not yet reviewed execution.
An editor process exiting successfully is not proof the operator meant to run the result.
A bridge that reopens “the same file” later is not automatically the same mutable basis.
And a historical shell feature that edits then executes should not quietly define the safety floor for a brand-new shell.

Schell should therefore keep at least these families separately named:
- **live prompt buffer**,
- **externalized draft object**,
- **editor session / bridge witness**,
- **return diff / merge result**,
- **accepted buffer text after return**,
- and **later reviewed action truth**.

## 2) The must-learn lesson: external editing should return to the buffer, not spend the action

The historical ecosystem gives Schell a very clean lesson.
Bash's `fc` builtin edits commands in an editor and then **reads, echoes, and executes** the edited file.
That is useful history, but it is a bad safety floor for a shell that cares about exact review and explicit authorship.

The better current pattern is visible elsewhere:
- zsh's `edit-command-line` opens the current command in an external editor and returns to command-line editing without automatically executing,
- fish's `edit_command_buffer` opens the visual editor for the current command-line contents,
- and Nushell's line editor lets `Ctrl+O` open the current commandline in an editor and then updates the commandline when the file is saved and the editor exits.

That is the pattern to steal:
**external editing should usually roundtrip back into a live editable buffer, then wait for fresh review or explicit submit.**

## 3) The bridge needs its own witness, not just a tempfile

A good first object here is an **editor-bridge witness**.
It does not need to freeze one final editor protocol, one final temp-file scheme, or one final IDE adapter stack.
It only needs to name the truth we already know is real.

A compact v0 bridge witness might carry:
- `bridge_ref` — the exact editor roundtrip instance,
- `source_buffer_ref` — the live prompt/draft buffer that exported the text,
- `draft_object_ref` — the externalized draft object or temp identity,
- `editor_source` — `VISUAL` / `EDITOR` / explicit style / explicit command / helper bridge,
- `edit_mode` — readonly-inspect / writable-draft / compare-only / unknown,
- `basis_posture` — exact-current / compare-and-set / historical / restored / unknown,
- `return_posture` — returned-to-buffer / saved-no-merge / editor-exited-no-save / merge-conflict / unknown,
- `diff_posture` — identical / textual-delta / structural-delta / parse-changed / unknown,
- `submit_posture` — buffer-only / requires-review / submit-allowed / unknown.

That is enough structure to make the bridge feel luxurious without pretending a temp file or editor subprocess is itself shell truth.

## 4) Saving, exiting, and returning should stop blurring together

A humane shell should keep at least these events distinct:
- **opened in editor** — a draft left the prompt,
- **saved externally** — the draft object changed,
- **returned to shell buffer** — the shell accepted a new buffer candidate,
- **accepted into live buffer** — the prompt now contains the returned text,
- **reviewed for execution** — the operator explicitly reviewed the post-return text,
- **submitted** — the action was actually spent.

That sounds obvious, but old shell behavior repeatedly flattens it.
Schell should not.

## 5) Compare-and-set matters here more than shell folklore admits

The editor roundtrip can take time.
While the operator is away, the live situation may drift:
- the current buffer may already have changed locally,
- generated suggestions may have produced newer drafts,
- repo context or machine posture may have shifted,
- or the operator may intentionally reopen an old draft as inspiration rather than as the current command.

So the right Schell import is not “trust whatever came back.”
It is:
**treat editor return as a compare-and-set merge back into a named buffer with visible basis posture.**

If the basis still matches, the buffer can update cleanly.
If not, the shell should offer explicit rails such as:
- replace buffer,
- insert as alternate draft,
- open diff/compare,
- mine snippets,
- or keep the roundtrip historical.

## 6) The super-awesome product moves are excellent here

Once editor bridges are first-class, Schell can steal several genuinely great moves without overcommitting the architecture:

### a) One exact “Edit in editor” rail
A compact rail from the live prompt or runbook cell into a known editor bridge with source and basis badges.

### b) Return diff cards
When the editor closes, Schell can show a tiny exact compare card:
- what changed,
- whether parse shape changed,
- whether argv/external-lane shape changed,
- and whether the result is merely back in buffer or actually ready for review.

### c) Alternate-draft shelving
If basis drift happened, keep the returned text as an alternate draft rather than forcing unsafe overwrite or silent discard.

### d) Explicit editor provenance
Show whether the bridge used `VISUAL`, `EDITOR`, a shell-configured editor style, or an explicit helper/IDE command.
That is configuration provenance, not authority — but it is still worth admitting.

### e) Readonly editor export
Sometimes the right move is not “edit this and return.”
Sometimes it is “inspect this command/runbook/output in a real editor without spending it.”
Schell should keep readonly export and writable roundtrip separately named.

## 7) What Schell should do now

### A. Add **editor-bridge witnesses**
Treat every external-edit roundtrip as a witnessed seam rather than a magic tempfile.

### B. Keep **autorun out of the default bridge**
Bash-style edit-then-execute can remain a consciously stronger rail if it ever exists at all, but it should not be the ordinary roundtrip story.

### C. Add **return-to-buffer compare cards**
The key delight is not just opening an editor.
It is returning with exact diff, basis, and parse-shape honesty.

### D. Keep **editor exit weaker than review**
Successful editor exit is not a receipt and not a submit.
It is only a bridge event.

### E. Keep **draft objects weaker than live shell truth**
Draft files, temp paths, and editor session state are useful implementation surfaces, but they should not quietly become durable shell identity or reviewed action truth.

## 8) Decisions intentionally kept open

This pass does **not** freeze:
- one final external-editor transport,
- one final temp-file versus pipe scheme,
- one final IDE bridge protocol,
- one final buffer-merge algorithm,
- one final readonly-preview representation,
- or one final runbook/document bridge.

The no-regret move is smaller:
**make editor roundtrips first-class and delightful, but keep exported draft, editor session, return diff, accepted buffer text, and reviewed execution separately named.**
