# Config-ground cards, startup footing, and overlay-truth humility

This surface records a new no-regret candidate cluster for Schell:
**treat startup, configuration, and runtime overlays as a small family of explicit provenance objects instead of letting rc files, shell profiles, project hooks, terminal injection, environment capture, and restored state collapse into one flattering “this is just my shell config” story.**

Schell already has shell-integration humility, environment/execution-ground witnesses, add-on-pack humility, compatibility ladders, machine cards, and history/session residue surfaces.
This pass narrows a seam those earlier surfaces left deliberately open:
**who configured the current behavior, how that behavior entered the shell, and which current layer should be trusted as durable basis versus temporary overlay.**

The design pressure comes from three directions:
- SlopOS keeps pushing durable config toward reviewed compiled basis and keeps activation/inbound continuity descriptive rather than ambient.
- Current shells and terminals keep proving that startup files, host-specific profiles, prompt hooks, terminal injection, project-local overlays, and hot reload are real product surfaces.
- The broader ecosystem keeps admitting that config, state, cache, and restored residue are not the same drawer.

## 1) One rule to keep visible: startup footing is execution footing

Classic shell folklore still treats startup as setup noise.
That story is too weak.
Login versus non-login, interactive versus non-interactive, host-level profiles, shell-specific rc files, project-local hooks, and terminal-injected integration all alter real behavior.

A better first Schell rule is smaller and more honest:
- **startup footing** says how the shell was launched and what startup paths were eligible,
- **config ground** says which durable layers can claim the current setting,
- **overlay** says what narrower or newer layer changed the result,
- **runtime override** says what changed only for this session/window/process,
- and **restored residue** says what was merely carried forward from earlier state.

That split already removes a large amount of ambiguity.

## 2) Config ground should stay separately named

A user-friendly shell+terminal should let someone ask “why is this prompt/env/keybinding/completion/theme behaving this way?” without sending them on a hunt across half a dozen startup files and helper docs.

Schell should therefore keep a compact **config-ground card** that can say things like:
- built-in default,
- global/host profile,
- user config,
- imported prompt/theme pack,
- project overlay,
- terminal-provided integration,
- runtime/session override,
- restored historical residue,
- or unknown.

This does not require a giant config architecture.
It only requires refusing to overstate provenance.

## 3) Effective config flatten is worth stealing early

Nushell is especially helpful here because it already separates env and config files and provides `config flatten`.
That is a very strong model for Schell.

A **flattened effective-config view** should exist for at least:
- prompt composition,
- environment/path mutation,
- keybindings,
- completion behavior,
- terminal integration state,
- and theme/styling.

Each row should show:
- current winner,
- loser layers that were overridden,
- source path or source family,
- whether the value is pure data or code-bearing,
- and whether it is durable basis, lease-like overlay, or restored residue.

## 4) Startup-footing badges should confess helper authorship

Terminals and editors increasingly become startup participants.
Some inject shell integration.
Some launch shells to resolve environment.
Some apply per-window overrides.
Some replay restored state.

Schell should therefore keep a **startup-footing badge** that can say things like:
- native shell only,
- login startup,
- non-login interactive,
- terminal-injected integration,
- manually sourced integration,
- resolving-environment helper launch,
- project overlay active,
- restored session footing,
- adapted remote/mux footing,
- or unknown.

This one badge would prevent a lot of operator confusion.

## 5) Project overlays should be offers or leases, not ambient fate

Project-local env activation and prompt/theme behavior can be wonderful.
The danger is when they become silent destiny.

Schell should therefore treat project-local mutation as an **overlay card** rather than as generic shell truth.
A minimal overlay card can carry:
- source path,
- admission posture,
- what fields it changes,
- whether it runs code or is pure data,
- lifetime/scope,
- suspend/resume controls,
- and compare-to-basis controls.

That gives users real power without pretending their whole shell has permanently changed.

## 6) Side-effect fences matter more than config language debates

Live reload and flexible config are delightful.
Repeated config evaluation with hidden side effects is not.

Schell should prefer one narrow discipline:
- **config main flow should be observational or pure-data whenever possible**,
- while side effects belong in explicit hooks or actions with blameable names.

This is stronger and more useful than arguing early about TOML versus Lua versus DSL versus shell syntax.

## 7) Config, state, cache, and restored residue should stop borrowing each other’s drawers

This pass suggests four different visible drawers:
- **config intent** — durable authored preferences and reviewed basis,
- **live state** — current window/session behavior,
- **accelerator/cache** — indices, prompt caches, compiled pack residue, warm helpers,
- **restored residue** — what survived from a prior session.

Many shell irritations come from pretending these are one thing.
Schell can get far just by making the drawers visible.

## 8) Super-awesome specimen ideas that still stay decision-light

A first specimen set could stay small but teach a lot:
1. one prompt color/segment whose effective-config card shows default → pack → user → runtime override;
2. one PATH delta whose current value can be traced to login startup, project overlay, and manual session tweak separately;
3. one terminal-injected shell integration that is visibly weaker than native manual config;
4. one environment-resolving helper launch that leaves a startup-footing breadcrumb rather than pretending it was an ordinary shell;
5. one project overlay that can be suspended for a single pane or shadow-compared against basis;
6. one hot reload that updates pure-data config immediately while fencing code-bearing hooks;
7. one restored workspace/theme override that stays historical until re-promoted;
8. and one transcript witness showing startup footing → config ground → overlay → effective result.

## 9) The no-regret move

The best move right now is not to freeze a plugin runtime, config language, or universal rc story.
It is to pin one stronger rule:
**Schell should model startup and configuration as startup-footing badges, config-ground cards, effective-config flatten, overlay cards, and side-effect fences before it lets rc files, shell profiles, project hooks, terminal injection, or restored residue masquerade as one generic shell-config truth.**

That keeps the archive free to defer:
- the final config language,
- the final pack/plugin/theme model,
- the final startup-trace protocol,
- the final overlay runtime,
- the final hot-reload engine,
- and the final generation/rollback substrate.
