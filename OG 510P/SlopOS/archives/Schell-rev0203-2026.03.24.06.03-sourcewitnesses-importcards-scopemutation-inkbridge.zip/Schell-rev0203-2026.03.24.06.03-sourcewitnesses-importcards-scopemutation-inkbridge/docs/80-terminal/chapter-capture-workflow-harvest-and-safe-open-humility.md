# Chapter capture, workflow harvest, and safe-open humility

This surface exists to keep one very tempting cluster of ideas honest:
**Schell should absolutely make command chapters easier to capture, promote, and act on — but it must not let chapter history, semantic-history hints, or visible links quietly become hidden execution or hidden browser authority.**

This is where three attractive terminal stories meet:
- command chapters and sticky command-local navigation,
- saving useful commands as reusable workflow seeds,
- and opening/revealing visible objects directly from terminal output.

All three are great.
All three become dangerous if they collapse into one flattering “just do the smart thing” surface.

## 1) Command chapters are the right parent object

A command chapter is still the best parent object for this seam.
One shell-known chapter can carry:
- exact command text or command packet ref,
- exact output capsule refs,
- execution-ground witness,
- source/authorship lane,
- outcome/receipt refs,
- and historical/local/peer posture.

That chapter is richer than plain history and still weaker than live authority.
That makes it the right place to hang reuse and open gestures.

## 2) Capture actions should stay weak and exact

A good chapter-capture ladder looks like:
- **copy command**,
- **copy output**,
- **re-input command**,
- **bookmark chapter**,
- **inspect chapter**,
- **promote to workflow seed**.

None of those should silently run.
Even “re-input” should land in the active shell-owned input field rather than crossing straight into effect.

## 3) Workflow harvest should preserve provenance instead of bleaching it away

Promoting a chapter into a workflow seed is one of the highest-value luxuries Schell can steal.
But the promotion must preserve at least:
- source chapter ref,
- source lane and authorship,
- old peer / execution ground,
- parameter extraction suggestions,
- drift posture,
- and share posture.

A harvested workflow seed is **not**:
- standing approval,
- a hidden alias,
- or proof that current ground still matches old basis.

Useful extra rule:
if the source chapter was low-trust, imported, restored, or proposal-only, the harvested seed should keep that badge.

## 4) Parameter extraction should stay suggestive, not magical

The best workflow-harvest UX is not “we found the variables, trust us.”
It is a visible proposal.

A v0 harvest card can suggest:
- path-like slots,
- enum-like flags,
- host/peer selectors,
- branch or target names,
- secret handles,
- and values copied from the original chapter.

But each slot should still say where it came from:
- original chapter literal,
- current execution ground guess,
- imported runbook default,
- or operator-provided fresh value.

That keeps reuse humane without letting remembered convenience impersonate current truth.

## 5) Safe-open ladders should remain separately named

Command output often contains things worth acting on:
- files,
- directories,
- URLs,
- services,
- ports,
- errors with source locations,
- receipts,
- and object identifiers.

Schell should not flatten these into one generic click.
A healthier ladder is:
- **inspect destination**,
- **reveal exact object**,
- **open**,
- **safe-open**,
- **copy destination**,
- **insert destination**,
- **attach destination to help lane**.

That ladder should be available from chapter context, object cards, and selection packets.

## 6) “Open” should stay admission-scoped

A terminal action that launches something externally should produce a compact route witness and a compact receipt.
That receipt should be strong about what Schell actually knows and weak about everything else.

Good v0 truth:
- the destination class,
- the route family,
- whether the operator chose inspect/open/safe-open/reveal,
- whether the mediation request was admitted,
- and whether the action was local, remote, restored, or imported.

Bad v0 overclaim:
- which app definitely handled it,
- whether the content rendered,
- whether the user saw it,
- whether a page loaded fully,
- whether a later permission prompt occurred,
- or whether the downstream task completed.

## 7) Full-destination reveal is mandatory when display text is weaker than target truth

Whenever visible text is not identical to the underlying destination, Schell should make the stronger target inspectable before strong action.
That applies to:
- OSC-8 hyperlinks,
- shortened labels,
- cwd-relative paths,
- line/column source jumps,
- remote-object wrappers,
- and restored historical links.

Hover or inspect should show:
- full destination,
- source class,
- normalization posture,
- local/remote basis,
- and which stronger actions are available.

No-fetch hover remains the safest default.
Richer metadata should remain an explicit second workflow.

## 8) Reveal is not browse-nearby

Schell should import the strongest object lesson here:
**reveal exact object** and **browse nearby** are not synonyms.

If a surface can only open a containing folder or a broader browser view, that should be named honestly.
Do not silently degrade reveal/select into “well, here is something close.”

The same rule applies to source jumps, object explorers, and service previews.
Approximate browse is still useful.
It is just not exact reveal.

## 9) Good first proving slice

A compact proof could show:
1. one command chapter with marks, sticky header, and re-input,
2. one workflow-harvest card derived from that chapter,
3. one parameter suggestion row with explicit provenance,
4. one visible destination with inspect / reveal / open / safe-open split,
5. one route witness showing local vs remote basis,
6. and one launch receipt that remains admission-scoped.

That would already demonstrate a custom shell+terminal that is meaningfully better than ordinary terminal folklore.

## 10) Things to refuse for now

Refuse for now:
- automatic workflow harvesting from every command,
- save-and-run in one gesture,
- handler probing or chooser scripting as portable chapter action,
- hidden preview fetch on hover,
- raw-destination durable history by default,
- and chapter capture that becomes the only truth path instead of one shell-witnessed path.

The right law is:
**capture exactly, promote explicitly, and open humbly.**
