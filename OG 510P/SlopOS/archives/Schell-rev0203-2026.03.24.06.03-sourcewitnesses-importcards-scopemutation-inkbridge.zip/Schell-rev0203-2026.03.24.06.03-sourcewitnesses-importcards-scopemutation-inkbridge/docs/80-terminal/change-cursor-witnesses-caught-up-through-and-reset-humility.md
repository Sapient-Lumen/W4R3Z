# Change-cursor witnesses, caught-up-through chips, and reset-card humility

This surface keeps one very tempting shell+terminal move honest:
**Schell should be exceptional at helping operators jump back to prior prompts, prior command output, remembered directories, historical file lines, and stream positions, but those affordances should travel as explicit cursor witnesses — not as fake proof that old context is still live.**

Modern terminals keep getting better at marks, prompt jumps, semantic history, recent directories, and command-history rows.
That is worth stealing.
The risk is not historical comfort itself.
The risk is letting “I can jump back here” quietly become “this is current truth.”

The right import is therefore not “better recents.”
It is a compact family of **change cursors** and **reset cards**.
Each shell-visible cursor should say:
- what exact thing it points at,
- what scope and basis it came from,
- what verbs it still supports,
- and what reset is required if the bookmark drifted or expired.

## 1) “Where I am now” and “where I last saw” are different objects

Schell already has soft-state classes and revivability grades.
This seam adds another necessary split.

The shell+terminal should distinguish:
- a **live prompt witness**,
- a **historical prompt mark**,
- a **command-output anchor**,
- a **directory cursor**,
- a **line-relative file/designator cue**,
- a **caught-up-through stream cursor**,
- and an **expired cursor**.

Those are not cosmetic labels.
They prevent history, scrollback, and bookmarks from flattering themselves into live shell footing.

## 2) A historical cursor should advertise verbs, not vibes

One row may support:
- `jump`,
- `reveal`,
- `select output`,
- `insert`,
- `cd`,
- `open relative`,
- `compare with live`,
- or `reset`.

That means a cursor witness should carry a small verb ladder.
For example:
- a prompt mark may support `jump` and `reveal`,
- a command-history row may support `reveal` and `insert`,
- a remembered directory may support `insert path` and `cd`,
- a semantic-history line may support `open relative` and `reveal path`,
- a stream cursor may support `resume from here` only if the source and epoch still match,
- an expired cursor may support only `inspect why expired` and `reset`.

The product win is not a generic smart click.
It is a visible ladder of exact weaker and stronger acts.

## 3) “Caught up through” is stronger than “unread” but weaker than “live now”
Streams, watches, logs, room chapters, and long command output often need one compact truth:
**what exact boundary have I already seen?**

That is a useful object, but it is not the same as:
- current live prompt,
- source health,
- latest available output,
- or durable completion.

So Schell should expose compact **caught-up-through chips** that say:
- exact source,
- exact cursor/epoch,
- freshness horizon,
- whether forward resume is still legal,
- and whether the source changed in a way that requires reset.

This is better than a generic unread dot because it names the exact claim.

## 4) Reset cards matter because history and streams mutate

Bookmarks die for many reasons:
- history pruning,
- source replacement,
- semantic-epoch changes,
- peer drift,
- cwd/workspace drift,
- process/session loss,
- output compaction,
- and authority drift.

A great shell+terminal should not hide that.
It should surface a **reset card** that says:
- what exact cursor died,
- why it died,
- what scope is affected,
- whether a nearest-safe reveal still exists,
- and what reset options remain (`jump to latest`, `pick older boundary`, `start fresh`, `forget`).

Silent jump-to-latest repair is delightful right up until it lies.
Reset cards keep the delight and remove the lie.

## 5) Semantic history should stay history-shaped

Semantic history is worth stealing aggressively:
- line-relative cwd,
- filename+line extraction,
- prompt/output boundaries,
- command marks,
- directory memory,
- and output-of-last-command browsing.

But the shell+terminal should keep the verbs distinct.
A line-derived file target might support:
- `reveal`,
- `safe open`,
- `open with editor`,
- `copy path`,
- `insert path`,
- and only later perhaps a stronger routed action.

What it should not do is silently inherit the authority of the line it came from.
History-shaped evidence should stay history-shaped.

## 6) Scope is part of cursor truth

A good cursor witness should usually carry at least some of these scope axes:
- peer/host,
- user/session,
- cwd or workspace,
- shell/runtime epoch,
- source kind (`prompt`, `output`, `directory`, `line`, `stream`),
- and freshness posture.

That is enough to keep many excellent moves humane without freezing a final storage backend or cross-terminal protocol.

## 7) Things Schell should steal now

### Prompt-zone jump and output-boundary selection
Make command and prompt boundaries a first-class navigation object.

### Per-peer command and directory memory
History gets much better when old rows stay attached to peer/user/session footing.

### Reveal vs insert vs `cd` ladders
A historical row should offer several exact verbs instead of one flattering default.

### Caught-up-through chips
Treat stream/bookmark posture as an exact boundary witness rather than a fuzzy unread count.

### Reset cards with scope
When a cursor dies, explain what died and what reset options remain.

## 8) Things Schell should refuse now

### Refuse one generic recent/unread/resume badge
Those hide too many distinct truths.

### Refuse historical prompt marks that look identical to the live prompt
The live prompt needs stronger visual footing.

### Refuse history rows that silently spend authority
Insert, reveal, compare, and stronger acts should stay distinct.

### Refuse stale bookmarks that silently jump to latest
Repair should be explicit.

### Refuse semantic-history clicks that collapse reveal/open/execute
Historical context is evidence, not blanket action authority.

## 9) No-regret first specimen set

A compact first proof could show:
1. one live prompt witness,
2. one historical prompt mark with `jump` and `reveal`,
3. one command-history row with `reveal`, `insert`, and `cd`,
4. one recent-directory row with `insert path` and `cd`,
5. one line-relative file cue with `reveal` and `safe open`,
6. one stream card with a `caught up through` chip,
7. one expired cursor reset card,
8. one side-by-side `jump latest` versus `start fresh` decision,
9. and one transcript slice showing when a cursor demoted from resumable to reveal-only.

That would make Schell feel dramatically more capable without freezing the history store, bookmark format, terminal escape profile, or stream-watch protocol.
