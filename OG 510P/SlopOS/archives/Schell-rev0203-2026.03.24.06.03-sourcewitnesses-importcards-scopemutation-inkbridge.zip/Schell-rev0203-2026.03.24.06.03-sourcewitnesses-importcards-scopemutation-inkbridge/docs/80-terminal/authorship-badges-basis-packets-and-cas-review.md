# Authorship badges, basis packets, and compare-and-set review

This surface records a new no-regret candidate cluster for Schell:
**make every strong terminal action visibly answer two questions before it runs: who authored this object, and what exact basis is it still bound to?**

The design pressure comes from SlopOS approval-basis exactness plus DelayBasin's authorship and basis-witness discipline.
The shell+terminal opportunity is simple:
people should not have to infer authorship and same-basis validity from nearby scrollback, remembered context, or product glow.

## 1) Authorship badges

Every visible actionable object should be able to carry a tiny **authorship badge**.
Not a long provenance essay.
Just enough to stop strong actions from riding on ambiguity.

Candidate badge families:

- `direct` — typed by the operator in the active-input lane,
- `proposed` — assembled in an assistant/proposal lane,
- `workflow` — saved reusable command artifact,
- `receipt` — durable historical result object,
- `replay` — reconstructed from prior execution truth,
- `residue` — output with partial provenance only.

Important posture:

- the badge is **descriptive**,
- it is not a grant,
- it does not auto-approve,
- and it should remain possible to flatten into transcript-safe text.

## 2) Basis packets

A strong action should not depend on “latest” or “nearby”.
It should depend on an exact **basis packet**.

A good first basis packet could include:

- source object id or digest,
- relevant revision or epoch witness,
- environment or authority digest when that matters,
- lane and trust grade,
- and a compact compare result such as `match`, `drifted`, `partial`, or `unknown`.

The basis packet is where Schell can steal SlopOS's exact mutable-basis discipline without importing a whole policy language.

## 3) Compare-and-set review gates

Once basis packets exist, strong actions can become much more honest.

Candidate gate behavior:

### Strong rerun / attach / execute is available when

- authorship is in an allowed family,
- trust grade is high enough,
- and the basis packet still matches exactly.

### Review-again is required when

- the basis packet drifted,
- the authority shape widened,
- or the object is only a saved template with no fresh binding.

### Inspect-only is the right fallback when

- the object is historical,
- current live state is unknown,
- or provenance is too weak for strong action.

That is the compare-and-set move Schell should probably earn before it promises powerful history-driven actions.

## 4) Workflow seeds with provenance

A workflow seed should preserve more than a command string.
At minimum it should remember:

- source lane,
- source authorship badge,
- source trust grade,
- command template,
- parameter placeholders,
- and whether the saved artifact carries a basis contract or only reusable text.

That would make saved work far more honest than aliases while still remaining lighter than a full workflow bureaucracy.

## 5) How this plays with authority strips and lanes

These objects answer different questions:

- **lane** — where in the shell+terminal this object lives,
- **authorship badge** — who/what kind of object produced it,
- **authority strip** — what compact power summary is visible now,
- **basis packet** — what exact reviewed basis a strong action still depends on.

Schell should keep these related but separate.
That is how the terminal can get much smarter without turning one tiny visual object into the whole authority system.

## 6) Things Schell should refuse

### Refuse latest-following execution

A historical or saved object should not silently retarget itself to whatever the newest revision or state now is.

### Refuse provenance erasure on save

Saving as a workflow should not bleach away lane, authorship, and trust information.

### Refuse self-approval theater

If the same assistant-originated object can propose, summarize, and execute without a separately legible review seam, the shell+terminal becomes less honest exactly where it feels most futuristic.

### Refuse giant compare-and-set machinery first

One authorship badge family, one compact basis packet, and one stale-basis refusal specimen are likely enough to start.

## 7) No-regret first cut

A first specimen set could stay very small:

1. one direct command with a strong-action-safe basis packet,
2. one agent proposal with `review again` because authorship is proposal-scoped,
3. one saved workflow seed that preserves provenance and basis contract,
4. one historical receipt that downgrades to inspect-only,
5. and one stale-basis rerun refusal that explains exactly what drifted.

That is enough to learn a lot without freezing the final renderer, transport, workflow schema, or remote execution story.
