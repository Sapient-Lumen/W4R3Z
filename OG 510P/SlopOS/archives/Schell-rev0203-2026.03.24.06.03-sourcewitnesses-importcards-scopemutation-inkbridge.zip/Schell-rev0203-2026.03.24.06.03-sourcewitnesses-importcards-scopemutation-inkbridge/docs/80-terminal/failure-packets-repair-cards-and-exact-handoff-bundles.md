# Failure packets, repair cards, and exact handoff bundles

This surface records a new no-regret candidate cluster for Schell:
**be superb after failure, but keep help proposal-only, source-labeled, and exact-basis-bound instead of turning the shell+terminal into an ambient repair engine.**

The design pressure comes from three directions:

- SlopOS learn-mode posture says post-failure learning is observational only and must not auto-widen, auto-edit, or auto-rerun.
- SlopOS explain and result posture says canonical summaries and outputs should stay exact and descriptive rather than becoming a reusable approval cache.
- Current shells and terminals show the value of inline suggestions, quick fixes, and exact command-context handoff once command boundaries and outcomes are known.

## 1) Failure should become an object, not a mood in scrollback

Schell should treat a failed or suspicious outcome as a compact **failure packet**.
That packet should stay shell-owned.
It is not just “some text near a red badge.”

A v0 packet probably needs:
- `command_ref` — exact reviewed action / command block / receipt origin,
- `outcome_ref` — exact receipt or denial when present,
- `output_refs` — exact output capsule refs or bounded slices,
- `exit_status` or `signal_posture`,
- `ground_ref` — cwd/env/activation witness,
- `peer_ref` — remote peer witness when relevant,
- `wallet_hint` — descriptive only,
- `failure_class` — parse / exec / denied / missing-input / remote-drift / unknown,
- `confidence_class` — shell-known / interpreter-known / heuristic / imported,
- `repair_families` — which next moves are even in bounds.

That is enough to make post-failure help explicit without freezing a giant taxonomy.

## 2) Repair cards should remain proposals, not hidden reruns

A **repair card** is a proposed next move derived from a failure packet.
It is not execution.
It is not a remembered grant.
It is not a magic “do what I meant” button.

A good first repair-card family could keep:
- `source_kind` — history / recipe / plugin / agent / operator-authored,
- `source_grade` — shell-authenticated / shell-derived / external / heuristic,
- `proposal_ref` — the replacement argv / workflow / explanation object,
- `basis_ref` — what exact failure packet or output slice it answers,
- `apply_strength` — insert / quote-insert / review-rerun / attach-help / inspect-only,
- `required_diffs` — ground drift, authority diff, remote drift, or none,
- `counterfactual_nearby_action` — what stronger move was refused.

That keeps help rich without silently widening authority.

## 3) Suggestion sources should stay visible

One of the easiest ways to lie is to flatten all suggestions into one glossy “recommended fix.”
Schell should resist that.

Operators should be able to see at least:
- **history-derived**,
- **shell-derived**,
- **operator-authored recipe**,
- **agent-proposed**,
- **plugin-proposed**,
- **heuristic guess**.

That source badge matters because identical-looking fixes deserve very different trust.

## 4) Apply paths should stay narrow and compare-and-set aware

A repair card should not have one giant “apply” button.
It should have a bounded ladder.

Candidate ladder:
- **inspect-only** — view reasoning and exact evidence,
- **insert-only** — paste proposal into active input,
- **quote-and-insert** — preserve literal safety for suspicious text,
- **review-rerun** — build a new reviewed action from the proposal,
- **attach-for-help** — send an exact handoff bundle to another lane.

And the apply path should downgrade when the world drifted:
- current ground changed,
- remote peer changed,
- wallet/core digest changed,
- mutable basis changed,
- or the original packet was only heuristic.

Then the right landing is a hold card, not a brave rerun.

## 5) Exact handoff bundles are one of the best super-awesome moves available

A custom shell+terminal becomes dramatically better once help handoff stops being paste ritual.
A bounded **handoff bundle** could keep:
- exact command line or reviewed action ref,
- exact output slice or output capsule refs,
- exit code / denial class,
- execution-ground witness,
- remote peer witness when present,
- descriptive wallet/authority summary,
- redaction posture,
- and the exact repair cards already considered.

That bundle can then move to:
- another local lane,
- an agent lane,
- a teammate-facing artifact later,
- or a workflow seed.

The point is not who receives it.
The point is that the bundle is exact and bounded.

## 6) Hold cards should be first-class here too

Some of the most honest post-failure states are:
- the system has only a likely guess,
- the proposal was good but basis drifted,
- the proposal would need more authority than the original command had,
- the remote peer is now uncertain,
- or the output slice is only terminal-inferred rather than shell-attested.

Schell should answer those with a compact **hold card** that says:
- what evidence it had,
- why the stronger move is blocked,
- and what exact step would upgrade the posture.

That is much better than hiding the option or auto-escalating it.

## 7) Keep the shell fast enough to deserve this feature

Repair help is only delightful if it stays cheap.
That suggests a few construction rules:
- async suggestion work,
- small bounded evidence packets,
- explicit source-labeled proposal providers,
- cached shell-known witnesses rather than repeated prompt scraping,
- and no prompt-time disk or network heroics in the critical path unless explicitly enabled.

This is a humane requirement, not just a performance nice-to-have.

## 8) Transcript truth still matters

The transcript does not need every hover, ranking tweak, or local scoring detail.
It does need the important truths:
- that a failure packet existed,
- what exact command/outcome it referred to,
- which repair card was offered,
- what source grade it carried,
- whether it was inserted, reviewed, attached, held, or denied,
- and whether apply was downgraded because basis drifted.

That is the portable minimum.

## 9) No-regret first cut

A first specimen set could stay small:

1. one missing-file failure packet with insert-only repair,
2. one denied-effect failure packet with inspect-only and attach-for-help,
3. one remote-drift failure packet whose repair downgrades to hold,
4. one history-derived repair card versus one agent-derived repair card for the same failure,
5. one exact handoff bundle attached to a help lane,
6. and one transcript slice showing failure packet → repair card → hold or review-rerun.

That is enough to learn a lot without freezing a full help engine, plugin API, or AI architecture.
