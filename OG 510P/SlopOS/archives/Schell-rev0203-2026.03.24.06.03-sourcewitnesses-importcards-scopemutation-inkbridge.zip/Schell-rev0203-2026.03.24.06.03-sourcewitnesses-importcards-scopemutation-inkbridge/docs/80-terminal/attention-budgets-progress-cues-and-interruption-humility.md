# Attention budgets, progress cues, and interruption humility

This surface exists to keep one very easy shell+terminal temptation honest:
**Schell should be unusually good at calling attention to progress, completion, blocked commands, and meaningful remote/task events — but it should keep transient attention cues, urgency hints, focus-aware delivery, and exact durable outcome truth separately named, because “the terminal tried to get my attention” is not the same fact as “the terminal proved what happened, what is still live, or what I have already approved.”**

The point is not to avoid notifications.
The point is to keep them smaller than authority.
A custom shell+terminal can feel super awesome here if it treats attention as a bounded object family rather than one flattering stream of bells, badges, and popups.

## 1) Separate the attention object family

At minimum Schell should keep these objects distinct:
- **progress cue** — a lightweight in-flight indication that work is happening,
- **completion cue** — a transient signal that a command or task reached a terminal state,
- **blocked-input cue** — a transient signal that the shell or task needs fresh user input,
- **attention budget** — the current per-origin/per-pane/per-task interruption allowance,
- **focus posture** — whether the originating pane/tab/window is focused, visible, backgrounded, detached, or unknown,
- **interrupt level** — background / visible-only / offscreen-only / local-only / urgent-hint / secure-review-required,
- **durable result** — a reviewable receipt, task card, or chapter state that survives after the cue disappears,
- **approval path** — the exact local review/consent surface for any actionful follow-up,
- **origin truth** — which pane/task/room/tool/agent actually caused the cue,
- **clearance rule** — whether the cue clears on focus, on next cue, on explicit dismiss, or on durable-state acknowledgment.

Those facts are adjacent.
They are not interchangeable.

## 2) Keep cues weaker than durable result truth

A progress ring, taskbar badge, bell, toast, dock bounce, or flashing tab is useful because it is fast.
It is dangerous when it is the only place meaning lived.

Schell should therefore insist on a durable split:
- progress cues say **something is happening**,
- completion cues say **something likely finished or needs attention**,
- durable result surfaces say **what finished, with what status, under what footing, and what next actions are available**.

This keeps the terminal from turning a vanished popup or a red tab icon into the only durable record of consequence.

## 3) Focus posture should shape delivery, not meaning

Current tools already prove that focus-aware delivery matters.
That is good.
But focus posture should only influence **how loudly** Schell alerts, not **what it claims is true**.

A healthy attention model should separate:
- focused pane,
- focused tab,
- focused window,
- visible but inactive,
- hidden/offscreen,
- detached/restored,
- remote-mirrored,
- unknown.

Then attention policy can make sensible choices without changing the underlying result truth.
A command that succeeded is not “more successful” because the window was visible.
A blocked task is not “less blocked” because the tab was backgrounded.

## 4) The best alert is chapter-bound, not ambient

One of the nicest old ideas still worth stealing is the command-bound alert.
Instead of saying “notify me when something happens somewhere in this terminal,” the user can say:
- alert on the **next command chapter**,
- alert when this **task shelf item** exits,
- alert when this **pane** needs input,
- alert when this **queue item** reaches a durable state,
- alert when this **remote watch** changes posture.

That is much stronger than an ambient bell because it binds the cue to a real semantic object.
It also stays comfortably smaller than freezing one final notification backend.

## 5) Progress should be first-class and weaker than completion

Progress deserves its own object family.
A shell+terminal can feel much better if it supports:
- indeterminate progress,
- bounded percentage progress,
- warning/error progress posture,
- queue-wide aggregate progress,
- quiet progress for visible panes,
- louder progress for backgrounded or detached work,
- and explicit progress clear/reset.

But progress is not completion.
Progress should never be mistaken for an exit code, a receipt, or an approved next step.

## 6) Use attention budgets, not one giant mute switch

A luxury shell should support interruption budgets such as:
- per-origin caps,
- per-task caps,
- cooldown windows,
- coalescing repeated events,
- summary folding for bursty queues,
- escalation only after durable state changed,
- and explicit quiet hours / focus mode / do-not-disturb posture.

This is better than pretending every event deserves the same channel and better than a single global mute switch.
It makes attention feel governed rather than spammy.

## 7) Urgency should stay a hint until secure review exists

Schell should absolutely support stronger attention posture than an ordinary background cue.
But urgency should stay visibly smaller than authority.

A healthy ladder might be:
1. passive badge,
2. tab/window attention,
3. desktop notification,
4. repeated but budgeted urgent hint,
5. secure local review lane for any consequential follow-up.

That means an urgent cue can call the user back.
It cannot itself approve, widen authority, reroute work, or confirm a dangerous action.

## 8) Actionful notifications should degrade into navigation and review first

The safest default for notification actions is to prefer:
- focus/open the originating pane,
- jump to the exact command chapter,
- open the durable task/result card,
- reveal the diff/receipt/review surface,
- or stage a next step for local review.

The stronger thing — actually executing a consequential follow-up from the attention surface — should require a visibly stronger local approval path.
This is especially important once commands, tasks, queues, agents, or remote sessions can all ask for attention.

## 9) Payloads should stay plain and origin-branded

A great shell+terminal does not need rich executable notifications.
It needs trustworthy ones.

So early Schell should strongly prefer:
- plain text payloads,
- canonical origin chips,
- task/pane/chapter identity,
- concise progress or status summary,
- exact jump-back handle,
- and explicit redaction posture for sensitive text.

Rich HTML, arbitrary links, hidden actions, or user-supplied branding can all wait unless a later proof surface earns them.

## 10) Protocol posture should stay adapter-first

The outside ecosystem is already fragmented across bells, proprietary marks, OSC 9, OSC 9;4, OSC 99, OSC 777, taskbar hooks, badges, and shell-integration-specific completion signals.
That is useful evidence, but not a reason to freeze Schell’s external wire protocol too early.

The right first move is smaller:
- define Schell’s internal attention object family,
- adapt outward to current escape-code ecosystems where useful,
- and always preserve claim strength when crossing an adapter.

That keeps current integrations possible without pretending the ecosystem has already converged.

## 11) A compact first proving slice

A strong first specimen set would show:
1. one progress cue that stays visible in-tab and task-local without becoming completion truth,
2. one alert-on-next-command chapter object,
3. one focus-aware completion cue that suppresses itself when already visible,
4. one blocked-input cue for password/review that routes back to the exact originating chapter,
5. one urgent-hint downgrade when budget or focus mode forbids stronger interruption,
6. one cue that auto-clears on focus and one that persists until the durable result card is opened,
7. one per-origin budget ledger that coalesces repeated events,
8. one secure-review handoff for an actionful follow-up,
9. one redacted notification body when the command/output is sensitive,
10. one restored historical cue that stays visibly weaker than live state,
11. and one durable result card that survives after every transient cue is gone.

That is already enough to make Schell feel much more polished than a classic shell without freezing the final notification backend, inbox/history model, or wire protocol.

## 12) Things to refuse for now

Refuse for now:
- one undifferentiated “notify me about terminal stuff” stream,
- actionful popups that silently spend authority,
- progress cues masquerading as durable result truth,
- urgency bypassing budgets or review,
- user-provided notification branding that can spoof origin,
- restored/offscreen cues posing as live completion proof,
- and one final cross-terminal notification protocol chosen just because today’s ecosystem happens to expose escape codes.

The right law is:
**steal progress rings, completion alerts, blocked-input reminders, focus-aware suppression, and command-bound watchpoints — but keep transient attention cues, urgency hints, durable outcomes, and approval paths separately named.**
