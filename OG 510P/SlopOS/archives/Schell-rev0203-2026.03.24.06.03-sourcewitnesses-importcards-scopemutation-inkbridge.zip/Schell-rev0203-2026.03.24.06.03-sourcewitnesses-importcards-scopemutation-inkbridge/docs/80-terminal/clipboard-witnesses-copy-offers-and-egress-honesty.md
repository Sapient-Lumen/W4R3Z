# Clipboard witnesses, copy offers, and egress honesty

This surface keeps one easy-to-forget boundary explicit:
**a great shell+terminal should make copy feel much smarter than legacy terminals, but it should not let selection, OSC 52, multiplexer buffers, remote shells, or shared exports collapse into one flattering ambient clipboard story.**

Schell already has an ingress model for paste and drop.
It now needs the matching **egress** discipline.
Copying out of the terminal is not the same thing as pasting into it.
A selected region, a shell-known object ref, a copied path, a system pasteboard write, a remote-to-local clipboard bridge, and a durable shared export are related, but they are not the same action.

That distinction matters because current terminals already support real host effects here:
- PTY output can ask the host terminal to write the system clipboard,
- multiplexers keep their own buffers and may forward to the outer terminal clipboard,
- remote shells can target the local clipboard through OSC 52 bridges,
- and richer terminals can copy more than plain text.

If Schell does not name that seam, copy will quietly become folklore again.

## 1) Copy should mint an explicit copy offer before it leaves the shell

A useful first move is to treat copy as creation of a **copy offer**.

A copy offer is smaller than a giant export subsystem.
It is just a bounded object saying:
- what exact source was selected,
- which payload forms are available,
- what secrecy posture it has,
- which egress actions are currently allowed,
- and whether anything has actually left the shell yet.

That one step is enough to keep a very important distinction alive:
- **selection** is not yet clipboard mutation,
- **copy offer** is not yet cross-app delivery,
- **system clipboard write** is stronger than local copy-ring retention,
- and **share/export** is stronger again.

This is the same kind of no-regret move Schell has been learning elsewhere.
Do not flatten adjacent workflows just because they often happen near each other.

## 2) Internal copy rings and system clipboards should stay separately named

One of the best lessons from current terminal practice is that there is not one clipboard.
There are usually several nearby things:
- a terminal or mux-local copy buffer,
- the host OS clipboard,
- sometimes a primary selection,
- maybe a remote-to-local bridge,
- and sometimes a richer typed clipboard or file/document export lane.

Schell should steal the good part of this complexity without making users memorize emulator folklore.
A simple ladder would already help a lot:
- `copy local` — keep a Schell-local copy pack only,
- `write clipboard` — write the local system clipboard,
- `write primary` — only where that notion exists,
- `bridge to local clipboard` — from a remote or nested session,
- `attach/share/export` — a stronger outward move with its own audit posture.

That is enough to make copy behavior honest without freezing one OS integration stack or one clipboard protocol.

## 3) One compact clipboard witness object could carry the truth

A small first-cut object here is **clipboard witness**.

A clipboard witness does not need to model every clipboard backend.
It only needs to say what happened clearly enough that Schell can stay luxurious without lying.

A v0 clipboard witness might keep:
- `source_ref` — exact selection packet / chapter slice / object ref / object card,
- `payload_forms` — plain text / shell-literal / path-list / object-ref / markdown excerpt / rich local derivative / unknown,
- `origin_posture` — shell-known / selection-derived / object-derived / heuristic / restored,
- `egress_target` — local-copy-pack / system-clipboard / primary-selection / remote-local-bridge / shared-export / unknown,
- `secrecy_posture` — ordinary / sensitive / secret-bearing / export-discouraged,
- `delivery_posture` — prepared / asked / granted / denied / cleared / expired / historical,
- `freshness_posture` — current / restored / historical / unknown,
- `clear_policy` — none / one-shot / ttl / clear-on-use,
- `transcript_summary` — a text-safe witness line.

That gives Schell a compact truth carrier for copy/export UX without choosing:
- one clipboard daemon design,
- one secure pasteboard service,
- one global history engine,
- or one typed-payload ontology.

## 4) Remote-to-local clipboard bridges deserve their own verb

This may be the single most important import from current practice.
A remote shell that writes the **local** clipboard is not doing an ordinary local copy.
It is crossing a boundary.

Schell should therefore name that move separately.
Good names might be:
- `copy to local clipboard`,
- `bridge clipboard to host`,
- or `export selection via OSC 52`.

The wrong move is to let a remote or nested program quietly overclaim:
- “copied” when only a mux buffer changed,
- “copied” when the host terminal denied the request,
- or “clipboard updated” when the request only succeeded in a local nested layer.

The terminal should be able to say:
- local copy pack created,
- host clipboard write attempted,
- host clipboard write denied,
- or host clipboard write succeeded via terminal bridge.

That is both more honest and more helpful.

## 5) Structured copy packs are a brilliant idea worth stealing carefully

Modern terminals and adjacent tools are quietly showing that copy does not have to be one raw text string.
A single selected subject might reasonably offer:
- plain text,
- shell-literal text,
- normalized path,
- file-line ref,
- exact object ref,
- markdown excerpt,
- or a richer local-only derivative.

That does **not** mean Schell should rush into a giant clipboard type algebra.
It does mean the archive should preserve the difference between:
- what is **displayed** to the user,
- what would be **inserted** into active input,
- and what would be **copied/exported** to a clipboard or share lane.

One powerful early example would be a path/object copy card with three separate actions:
- `copy display text`,
- `copy shell-literal`,
- `copy exact object ref`.

That makes the terminal feel much smarter without making selection magical.

## 6) Secret-bearing copy should be explicit, narrow, and often auto-clearing

Copy is one of the easiest ways to leak more than intended.
That is why Schell should steal the stronger lessons here too:
- secret-bearing copy offers should be visibly marked,
- cross-boundary writes should often prefer ask/confirm posture,
- sensitive copy should avoid durable history by default,
- and some offers should support `clear-on-use` or short TTL posture.

The key design point is not “be annoying about everything.”
It is to keep the shell honest about when copied material has actually crossed into a broader ambient substrate.
A secret copied into a local scratch pack is not yet the same as a secret written to the global clipboard.

## 7) Transcript truth matters here just as much as it does elsewhere

A transcript should be able to say things like:
- `clipboard witness: selected output lines 14-19; copy offer created; payload plain-text + shell-literal`,
- `clipboard witness: host clipboard write granted via OSC 52 bridge`,
- `clipboard witness: host clipboard write denied by terminal policy`,
- `clipboard witness: sensitive copy offer auto-cleared after one delivery`,
- or `clipboard witness: restored historical copy offer; re-export required`.

That keeps copy/export behavior understandable even when the rich local terminal is gone.

## 8) Great steals that still stay decision-light

### a) Copy-as variants on exact selection
A selection packet can offer `copy text`, `copy shell-literal`, `copy path`, and `copy object ref` as separately named actions.

### b) Local copy pack before external clipboard write
Selection can first land in a local Schell copy pack, then optionally escalate to system clipboard or share/export.

### c) Remote-local bridge badges
When the operator copies from a remote pane, Schell can show whether the result landed in a mux buffer, a terminal bridge, or the actual local clipboard.

### d) Sensitive copy with clear-on-use posture
For secret-bearing or privileged material, Schell can support one-shot or short-lived clipboard offers instead of pretending the global clipboard is a harmless scratchpad.

### e) Copy witnesses for object cards and chapter slices
Exact object refs, chapter excerpts, and selected output ranges can all reuse the same witness family instead of inventing separate folklore for each surface.

## 9) The no-regret move

The best move right now is not to freeze a clipboard manager architecture.
It is to pin one rule:
**Schell should model copy/export as explicit clipboard witnesses and copy offers before it lets visible selection, OSC 52, remote bridges, or share actions masquerade as one generic “copied” success story.**

That keeps the archive free to defer:
- the final clipboard protocol story,
- the final copy-ring/history policy,
- the final secret auto-clear rules,
- the final typed-payload schema,
- and the final remote-clipboard bridge posture.
