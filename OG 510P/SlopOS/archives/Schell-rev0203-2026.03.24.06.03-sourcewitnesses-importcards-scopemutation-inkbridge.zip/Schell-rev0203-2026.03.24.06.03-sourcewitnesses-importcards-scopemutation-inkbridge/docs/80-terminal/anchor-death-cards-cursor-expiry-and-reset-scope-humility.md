# Anchor death cards, cursor expiry, and reset-scope humility

**Schell should absolutely steal prompt jumps, sticky command headers, preserved command cards, recent-command reopening, and local review watermarks — but once the shell+terminal can say _what you reviewed_ and _where first unseen begins_, it also needs one more brutally honest answer: _does that anchor still survive, and if not, what exactly killed it?_**

## 1) Review comfort only works while the anchor still exists

A **review watermark** says what this viewer reviewed through.
A **first-unseen anchor** says where resume should land next.
A **change-digest card** says what changed since the last cut.

Those are all valuable.
But they quietly depend on something smaller:
**the underlying anchor still being representable.**

That stops being true whenever:
- scrollback trimmed the old boundary away,
- restore only brought back a bounded slice,
- the source compacted or expired the old cursor,
- the room was cleared/reset/replaced,
- or a semantic epoch changed so the old anchor is only historical residue.

Without one explicit death object, operators end up guessing whether `jump to first unseen` still means anything.

## 2) Separate five truths that often get flattened

Schell should keep these distinct:
- **review watermark** — what this viewer reviewed through,
- **first-unseen anchor** — where resume should land if the anchor still survives,
- **source cursor** — what the source is caught up through,
- **survival posture** — whether the old anchor still exists in the current representable world,
- **death/reset receipt** — what exact event invalidated it and what reset scope follows.

That split matters because these can diverge in normal ways:
- the source cursor may advance while the review watermark stands still,
- the review watermark may remain meaningful while the exact first-unseen anchor is gone,
- a restore may preserve a digest and a watermark but not the exact historical boundary,
- a compacted stream may still have current data while the old cursor is dead,
- a room may visibly reopen even though the old anchor only survives as historical text.

## 3) Name the new object family

### Anchor survival strip
A tiny visible strip that says whether an old resume/review anchor is:
- `survives exact`,
- `survives approximate`,
- `trimmed by scrollback`,
- `restore bounded`,
- `cursor expired`,
- `epoch changed`,
- `cleared/reset`,
- `room replaced`,
- or `unknown`.

### Anchor death card
A compact receipt that says:
- what exact anchor died,
- what killed it,
- what scope is affected,
- what weaker residue still exists,
- and what the strongest honest next verb is now.

### Reset-scope chip
A tiny scope witness like:
- `reset this digest only`,
- `refresh later-change lane`,
- `re-list from latest`,
- `reopen live room`,
- `start fresh`,
- `historical reveal only`.

## 4) The survival question is more important than “unread”

A vague unread badge can only say “something changed.”
The operator question is narrower and more useful:

- `can I still jump to the first unseen thing exactly?`
- `did restore preserve enough scrollback to keep that anchor honest?`
- `did a clear/reset kill only the visible marker or the whole historical lane?`
- `did the source expire the cursor, forcing relist/reopen?`
- `what still survives as weaker historical evidence?`

This is where great shell+terminal UX gets more trustworthy than folklore.
Instead of silently jumping to latest or pretending the old anchor still exists, Schell should leave a tiny death card.

## 5) A first v0 shape

A useful **anchor death card** probably needs fields like:
- `anchor_receipt_id`
- `subject_ref` — exact room / command card / watch lane / transcript slice / digest card
- `anchor_kind` — first-unseen / review-watermark / source-cursor / prompt-mark / bookmark / row-anchor / other
- `anchor_ref` — exact prior boundary when known
- `survival_posture` — exact / approximate / trimmed / restore-bounded / expired / cleared / replaced / epoch-changed / unknown
- `death_cause` — scrollback-limit / restore-limit / clear-screen / terminal-reset / source-compaction / cursor-expiry / source-replacement / user-forget / unknown
- `death_scope` — prompt-boundary / command-card / later-change-lane / whole-room / whole-subject / whole-source / unknown
- `residue_posture` — historical-text-survives / digest-survives / watermark-survives-no-anchor / no-useful-residue / unknown
- `source_cursor_posture` — still-advancing / preserved-historical / unavailable / unknown
- `recommended_next_verbs` — jump-nearest / inspect-residue / refresh / relist / reopen-live / mark-reviewed-through-current / start-fresh
- `why_note` — compact human text such as `prompt 42 trimmed by scrollback`, `rv=10245 expired at source`, `restore kept only last 200 lines`, `room replaced after reset`

The point is not to build one final sync protocol.
The point is to leave an exact explanation when an old anchor stops being honest.

## 6) Great tiny UX moves worth stealing

### a) “First unseen survived?” strip on reopen
When a hidden room or preserved command card reappears, show one tiny answer immediately:
- `first unseen still exact at prompt 42`,
- `first unseen lost · restore kept last 200 lines only`,
- `cursor expired · relist required`,
- `historical reveal only · room replaced after reset`.

### b) Jump-nearest versus jump-latest separation
If the exact anchor died but a nearby surviving boundary still exists, offer:
- `jump nearest surviving boundary`,
- `show historical residue`,
- `refresh from latest`,
- `start fresh`.

Do not collapse those into one flattering `resume` button.

### c) Reset-scope chips
When something died, show how much died:
- `digest reset only`,
- `watch cursor reset`,
- `room history trimmed`,
- `whole lane replaced`.

### d) Residue-first fallback
If only weaker evidence remains, keep it useful:
- old text can still be revealed,
- old digest can still be inspected,
- old review watermark can remain historical,
- but the strip should say the stronger jump anchor is gone.

## 7) Keep anchor death weaker than source failure

A dead anchor does **not** necessarily mean the source failed.
It may only mean:
- local scrollback trimmed,
- persistent restore was bounded,
- an old cursor aged out,
- a named cursor moved forward and cannot roll back,
- or the room was intentionally cleared.

That is why Schell should separate:
- **source unhealthy**,
- **source advanced**,
- **source compacted/expired old cursor**,
- **local history trimmed**,
- **restore bounded**,
- **review anchor dead**.

This makes the terminal feel much more exact than one generic `lost state` toast.

## 8) Why the companion datacubes point here

The companion pressure is strong:
- **SlopOS** keeps reviewed basis exact and keeps mutable current state from silently inheriting old approval, so dead anchors should not quietly remap to newer basis.
- **Steward** already keeps snapshot-plus-change, caught-up posture, and reset-required honesty visible, which makes anchor-death receipts a natural shell+terminal import.
- **ViewFS** explicitly pushes continuation cursors, sync watermarks, rebuilt snapshots, and gap/reset verdicts apart, which strongly supports a distinct `anchor survived?` witness.
- **Ward** keeps continuous signals and attenuation separate, which argues that a dead review anchor is not the same thing as no new change.
- **Harbor** keeps risk ladders explicit, which argues that stronger actions should stop at `inspect residue` or `refresh` when the anchor died.
- **Helm** keeps settlement narrower than local success, which argues that surviving text should not quietly become surviving exact footing.

So this seam fits the family without requiring one universal history store, watch engine, or resume treaty.

## 9) What Schell should refuse here

### Refuse silent jump-to-latest repair
If the exact anchor died, say so.

### Refuse treating restore-bounded history as exact continuity
A partial restore is useful, but it is not the same as full anchor survival.

### Refuse merging local trim and source expiry
`scrollback trimmed` and `cursor expired at source` should not become one blob.

### Refuse deleting weaker residue just because the strong anchor died
Historical text, digest cards, and old review watermarks may still help.
Keep them, but demote them honestly.

### Refuse a single “resume unavailable” message without reset scope
The user should know whether to refresh the digest, relist the source, reopen live, or start fresh.

## 10) No-regret first specimen set

A compact first proof could show:
1. one hidden room reopened with `first unseen exact at prompt 42`,
2. one restored room with `first unseen lost · restore kept last 200 lines`,
3. one watch lane with `rv=10245 expired · relist required`,
4. one local scrollback trim case where the digest survives but the exact prompt anchor dies,
5. one clear/reset case where old text survives historically but exact jump no longer does,
6. one `jump nearest surviving boundary` fallback,
7. one `historical reveal only` demotion,
8. one transcript-safe notation for anchor death plus reset scope,
9. and one refusal to promote dead-anchor residue into rerun/apply authority.

That would make Schell much more trustworthy around reopen/restore/watch flows without freezing a final replay database, watch protocol, or collaborative read-state system.

## 11) The no-regret move

The next good move is not a bigger resume engine.
It is this:

**after review watermarks and first-unseen anchors exist, give Schell tiny anchor-survival strips and anchor-death cards so the shell+terminal can say whether the old resume anchor still survives, what killed it when it does not, what weaker residue remains, and what reset scope is actually honest now.**
