# Auth handoff witnesses, browser returns, and callback humility

This surface narrows another seam that modern CLIs keep rediscovering:
**browser-auth comfort is worth stealing, but a shell+terminal should not flatten “opened a browser”, “showed a code”, “received a callback”, “stored something locally”, and “this account can now act here” into one flattering login story.**

That seam matters even more because SlopOS is still in design phase.
If Schell gets this wrong early, the shell+terminal quietly grows a second approval, browser, secret, and account-binding system before the real shell contract is even earned.

## 1) The historical lesson is already clear: native auth should leave the shell, then return exactly

The old temptation is to stuff web login into a terminal-local pane, webview, helper overlay, or invisible browser bridge and then call the whole thing “authenticated”.
The better lesson is smaller.
A shell+terminal should be excellent at:
- launching the right return path,
- keeping the pending auth object visible,
- helping the operator get back to the exact point of completion,
- and refusing to let browser residue or callback folklore impersonate durable shell truth.

That means the shell should get better at handoff honesty, not at pretending it is itself the browser or the authorization server.

## 2) Browser open, device-code prompt, and loopback callback are different flows

Current ecosystems already prove that “CLI login” is not one thing.
Sometimes the terminal opens the browser locally.
Sometimes it prints a URL and asks the operator to continue elsewhere.
Sometimes it shows a user code and polls.
Sometimes it listens on loopback for an exact redirect.
Sometimes the browser step succeeds but the local import step still fails or is deferred.

Schell should keep these families separately named:
- **browser-open flow** — shell asks the host to open an exact external URI,
- **console-bootstrap flow** — shell prints or copies a URL/code for another device or browser,
- **device-code flow** — shell shows a user code and verification target while polling a narrower pending-auth object,
- **loopback-return flow** — shell waits for an exact local callback on a bounded listener,
- **manual-import flow** — shell receives a code/result later through an explicit import lane,
- **environment-provided flow** — credentials came from a preexisting environment/helper path and should not borrow the narrative strength of an interactive browser-auth success.

## 3) A compact auth-handoff witness is enough

Schell does not need a giant auth subsystem to improve this seam.
A compact **auth handoff witness** could keep fields such as:
- `flow_family` — browser-open / console-bootstrap / device-code / loopback-return / manual-import / env-provided,
- `request_subject` — exact server / exact account target / exact scope challenge / exact resource target / unknown,
- `browser_posture` — not-opened / opened-here / copied-for-elsewhere / declined / unknown,
- `return_channel` — loopback / pasted-code / device-poll / host callback / none / unknown,
- `pending_state` — waiting-open / waiting-code-entry / waiting-callback / callback-seen-pending-import / imported / expired / cancelled / failed,
- `import_posture` — nothing-imported / token-ref-imported / account-binding-updated / env-only / unknown,
- `credential_sink` — keyring / helper / plain-file fallback / memory-only / provider-local / unknown,
- `freshness_posture` — live / waiting / historical / expired / replaced,
- `reveal_target` — exact card or chapter that explains what is still pending and what really completed.

That is enough to make auth handoffs dramatically better without freezing one final broker, keyring, browser helper, or callback substrate.

## 4) The shell should be fantastic at the parts terminals are usually bad at

Classic CLIs often handle auth in a barely-visible blur:
- some text scrolls by,
- a browser opens,
- maybe a code appears,
- maybe the terminal polls silently,
- and eventually a success line appears.

Schell can do much better with small luxuries:

### a) Browser return ticket
When a browser is opened, mint an exact return ticket that says which auth handoff is pending and where the operator will land when it completes.

### b) Device-code card
Show the user code, verification target, expiry, and polling cadence as a typed card rather than as easily-lost output prose.

### c) Callback listener chip
If a loopback callback is in use, show whether the listener is armed, what exact redirect it expects, and whether anything has arrived yet.

### d) Import barrier card
Even after callback success, keep `callback received` weaker than `import accepted here`.
This avoids the common lie that browser completion automatically equals local shell authority.

### e) Safe copy lanes
Copy URL, copy code, copy exact redirect host, or copy troubleshooting summary should stay separate from stronger acts.

### f) Historical fade
Expired or superseded auth handoffs should stay visible enough to diagnose but visibly weaker than a live pending flow.

## 5) The strongest lesson from SlopOS: provider-local auth mechanics are not portable shell truth

SlopOS already keeps PKCE handling, redirect return channels, auth discovery, pending-auth continuation, and browser/session export from silently widening into generic platform truth.
That is excellent pressure for Schell.
The terminal should help the operator finish one exact auth handoff.
It should not quietly become:
- a generic callback broker,
- a portable verifier/proof wallet,
- a trusted browser-session oracle,
- a reusable pending-auth mailbox,
- or a hidden account-binding registry.

So Schell should prefer **auth-handoff witnesses** over ambient “logged in” folklore.

## 6) Great ideas worth stealing now

### Reveal-before-import
After browser or device completion, reveal the exact local import card before claiming that the shell now has usable authority.

### Exact-host display
If a browser handoff is going out to another site, show the exact host or return endpoint clearly in the terminal-owned witness.

### Expiry and retry rails
Auth is full of expiry, cooldown, and stale browser tabs.
Surface those as first-class rails instead of vague “please try again” prose.

### Account-switch witness
If the browser returns a different account than the shell expected, say so explicitly instead of silently replacing the apparent subject.

### Auth result sinks stay separate
`stored in keyring`, `stored in helper`, `plain-file fallback`, `memory-only`, and `provider-local only` should stay visibly different.
That one move prevents a lot of false confidence.

## 7) What Schell should refuse now

Schell should refuse:
- embedded-browser heroics becoming shell truth,
- callback-received counting as approval or durable login success,
- browser-opened counting as callback-armed,
- user-code copied counting as device-flow completion,
- environment-provided credentials counting as interactive-auth success,
- and imported provider-local auth mechanics counting as generic shell proof or account truth.

## 8) The no-regret move

The best move right now is not to freeze one browser helper stack, one keyring, one loopback listener architecture, one account model, or one auth broker.
It is to pin one rule:
**Schell should treat browser/device/loopback auth as a family of auth-handoff witnesses with exact return tickets, pending-state posture, and import barriers, before CLI login comfort quietly becomes a second hidden shell, browser, and approval system.**
