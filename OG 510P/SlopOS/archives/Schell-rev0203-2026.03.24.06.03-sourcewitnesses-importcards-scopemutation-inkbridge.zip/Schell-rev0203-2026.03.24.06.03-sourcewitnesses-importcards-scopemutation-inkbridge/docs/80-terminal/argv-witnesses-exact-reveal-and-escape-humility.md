# Argv witnesses, exact reveal, and escape humility

This surface exists to keep another tempting luxury honest:
**Schell should absolutely make active input more pleasant than raw shell folklore, but it must not let pretty tokens, quote cleanup, or input normalization quietly become a hidden second parser or a stronger truth than exact argv/text reveal.**

This is where several attractive stories meet:
- workflow seeds landing in editable input,
- parameter slots and repeated-slot editing,
- completions that want to insert cleaner-looking text,
- and shells that would love to hide quoting or escaping ugliness from the operator.

All four are worth stealing.
All four become dangerous if Schell starts pretending there is no longer an exact launch shape underneath them.

## 1) The pretty view is allowed only inside active input

If Schell ever offers token chips, softened quoting, or a cleaner argument-local view, that belongs in the one shell-owned active input lane.
Historical command chapters, output capsules, transcript cards, copied snippets, and helper notes may seed that field.
They should not themselves become equally authoritative editable objects.

## 2) Every pretty token should have an exact reveal

A humane surface should let the operator inspect at least:
- the exact argv token/value,
- the exact shell-text rendering that would be inserted or copied,
- the token kind or role,
- and whether the token came from literal text, workflow defaults, completion help, or a current-ground guess.

The point is not to make operators stare at ugly escapes all day.
The point is to ensure that exact launch meaning is never hidden behind a prettier façade.

## 3) Escape and quote decisions deserve witnesses

Sometimes the shell or a helper will need to insert quotes or escapes.
That is fine.
But Schell should say when that happened.
Useful witness examples include:
- **quoted for one-token shell text**,
- **literal argv token; no shell quoting applied**,
- **pretty display differs from copyable shell text**,
- **binary/byte lane; do not stringify**,
- **operator-edited raw text**.

That kind of cue turns shell-escape folklore into something inspectable and reversible.

## 4) Executable-bearing and authority-bearing tokens deserve stronger reveal

Not all tokens are equally harmless.
These usually deserve stronger exactness ladders:
- executable selectors,
- script/interpreter pairs,
- writable paths,
- peer/service targets,
- secret-bearing handles,
- open/share destinations,
- authority-bearing flags.

For these, Schell should prefer exact reveal, provenance badges, and basis-drift warnings over cosmetic cleanliness.

## 5) Pretty text and exact argv should support different copy actions

One of the easiest ways shells lie is by copying the wrong representation.
Schell should therefore keep distinct actions for things like:
- **copy shell text**,
- **copy exact argv/value list**,
- **copy token only**,
- **copy redacted pretty view**.

Those are meaningfully different outputs.
They should not collapse into one flattering clipboard story.

## 6) Slot editing and argv reveal should compose cleanly

Slot-linked editing from the previous surface still matters.
A good composition looks like this:
- slots stay field-local,
- repeated slots may mirror edits,
- provenance stays visible,
- pretty-token view may reduce escape noise,
- and exact reveal can still show the real token/value shape.

The luxury is strongest when slot editing and exact reveal cooperate instead of competing.

## 7) Byte/string truth deserves an explicit seam

Sooner or later operators will care whether a token, pipe, or file-like handoff is exact bytes or human-oriented text.
Schell should not wait until damage happens to admit that difference.
If the shell is showing a display-friendly rendering but transport or copy wants exact bytes, that should be visible.
Pretty display remains weaker than transport truth.

## 8) Good first proving slice

A compact proof could show:
1. one command seed landing in active input,
2. one pretty token row for the input,
3. one exact-reveal drawer for each token,
4. one quote/escape witness when a token required help,
5. one authority-bearing executable/path token surfacing basis drift,
6. and one explicit copy split between shell text and exact argv.

That is already enough to make Schell feel custom, careful, and obviously more humane than shell folklore.

## 9) Things to refuse for now

Refuse for now:
- hidden reparsing from pretty token view back into command strings,
- silent quote cleanup with no exact reveal,
- helper-owned normalization that changes launch meaning,
- historical/prettified command cards becoming live authority by themselves,
- and one mandatory pretty-token UI as the only input surface.

The right law is:
**make input nicer, keep exact reveal nearby, and let launch truth stay stronger than display convenience.**
