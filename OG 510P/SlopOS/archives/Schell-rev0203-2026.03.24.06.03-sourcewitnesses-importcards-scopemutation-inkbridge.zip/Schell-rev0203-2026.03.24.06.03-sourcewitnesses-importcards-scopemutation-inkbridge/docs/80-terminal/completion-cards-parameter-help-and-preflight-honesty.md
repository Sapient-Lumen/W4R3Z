# Completion cards, parameter help, and preflight honesty

This surface records another low-regret move for Schell:
**make command entry dramatically smarter while refusing to let completion, parameter prompting, or preflight previews impersonate execution authority.**

The point is not to build an omniscient AI shell first.
The point is to give the shell+terminal a much better answer to:
- “what can I type here?”
- “which value or flag is this slot expecting?”
- “where did this suggestion come from?”
- “what looks missing or drifted before I run this?”
- and “help me fill the line without deciding the run for me.”

## Core idea

Schell should probably distinguish at least six nearby things:

- **completion card** — one candidate value with type, description, and origin,
- **parameter-help card** — focused explanation for the currently selected slot,
- **argument slot** — a typed place in active input that may accept one or more candidate families,
- **preflight card** — a compact summary of missing parameters, drift, or likely effect posture,
- **insert action** — land text or a typed ref into active input without running,
- **review/run action** — a stronger lane than insertion.

Those are related.
They are not the same action.

## 1) Completion cards should be richer than plain text rows

A useful completion row is not just a string.
It should probably preserve at least:
- `value`,
- `description?`,
- `candidate_kind` — subcommand / flag / enum / path / object / peer / seed / history / snippet,
- `origin_kind` — shell-static / framework-spec / bridged-engine / history / plugin / dynamic / agent,
- `scope_grade` — current-view / current-peer / workspace / imported / unknown,
- `freshness_grade` — static / cached / live,
- `insert_mode` — literal / quoted / path-ref / object-ref,
- `risk_badges[]`,
- and `why_shown?`.

Important posture:
- a completion card is a **candidate**,
- not proof the command is correct,
- not proof the candidate is current,
- and not permission to run.

## 2) Origin badges matter a lot

Legacy shells often flatten all suggestions into one menu.
That hides the most important truth.

Schell should probably badge where a row came from:
- **shell-known**,
- **framework spec**,
- **bridged engine**,
- **history**,
- **plugin**,
- **dynamic local search**,
- **remote/provider**,
- **agent proposal**.

That lets the operator prefer the rows they trust most.
It also makes it much easier to degrade safely when a slower or riskier source is unavailable.

## 3) Parameter help should bind to one focused slot

The shell+terminal becomes much nicer once help stops being a giant manual lookup.
A focused slot should be able to ask:
- what kind of value belongs here,
- whether the slot is required or optional,
- whether the slot is repeatable,
- what the current default or inherited value might be,
- what nearby enum values exist,
- and whether the slot implies a likely peer / view / authority change.

That is different from completion.
Completion proposes candidates.
Parameter help explains the current slot.

## 4) Insert-first should be the default outcome

The default success case should usually be:
- insert value,
- quote/escape correctly,
- move to the next slot,
- optionally keep the completion surface open.

That keeps Schell powerful without becoming presumptuous.
A stronger outcome such as “review this preflight” or “run now” should remain visibly stronger.

## 5) Dynamic completion needs its own honesty rules

Dynamic generators can be wonderful.
They can also quietly become a second shell runtime.

So dynamic completion should probably carry a compact policy ladder:
- **static** — no extra lookup,
- **cached local** — previously computed local facts,
- **live local** — current scoped lookup,
- **portal-backed** — requires mediated selection or helper,
- **remote/provider** — slower or broader query,
- **agent/computed** — heuristic proposal.

And Schell should be willing to say:
- generator unavailable,
- downgraded to cached results,
- refused in secure/review lane,
- or too broad for current scope.

That honesty is better than silent fallback.

## 6) Preflight cards should explain without granting

A **preflight card** is where Schell can start to feel genuinely super awesome.
It can summarize things like:
- required slot still missing,
- target peer changed,
- authority wallet widened,
- path/object candidate is ambiguous,
- command implies network / write / export / open,
- cached completion may be stale,
- or exact target resolution failed and the result downgraded to hold.

But the preflight card should stay descriptive.
It is not approval.
It is not a guarantee.
It is not a hidden confirmation dialog pretending to be harmless help.

## 7) Completion should compose with object cards and seeds

Completion is not only about bare strings.
A custom shell+terminal can do much better when the candidate can be:
- an exact object card,
- a workflow seed,
- a launch kit,
- a recent peer,
- a known directory,
- or a previously reviewed chapter ref.

The key rule is that insertion still needs to say what kind of thing is landing in input.
A typed insert is better than flattening everything to text.

## 8) Bridge existing ecosystems instead of reauthoring everything first

Schell does not need to author a universal completion corpus on day one.
A better first step is probably:
- ingest static shell/framework specs,
- bridge existing completion engines where they behave well enough,
- preserve provenance and freshness grade,
- and reserve custom Schell-native cards for the places where existing ecosystems are weak.

That is a much better learning posture than trying to replace every existing completion system at once.

## 9) Things Schell should steal now

### Value + description rows

A row should usually explain itself.

### Source and freshness badges

Trust gets much better when rows say where they came from.

### Focused parameter help

Explain the exact slot the cursor is in.

### Insert-first menus

Most picks should land in input, not run.

### Preflight cards

Missing parameters, drift, and likely effect posture deserve one compact review surface.

### Completion bridges

Import framework- and shell-generated knowledge instead of pretending Schell starts from zero.

## 10) Things Schell should refuse

### Refuse completion-equals-run

A good suggestion is still weaker than execution.

### Refuse hidden command execution as baseline completion behavior

If a generator runs code or performs a lookup, say so.

### Refuse one giant omniscient completion pool

Static, history, bridged, dynamic, and agent suggestions should remain visibly distinct.

### Refuse parameter prompting that rewrites by surprise

Filling slots should stay visible and reversible.

### Refuse preflight-equals-approval

A helpful card can explain risk or drift without granting permission.

### Refuse giant AI-completion architecture first

One completion-card family, one parameter-help family, one preflight-card family, and one origin-badge family are enough to learn a lot.
