# File cards, watch roots, and path-ground humility

This surface exists to keep one tempting shell+terminal move honest:
**Schell should be unusually good at turning terminal text into useful file interaction — insertions, reveals, verified opens, editor jumps, remote-file actions, and watched file decks — but it should keep path text, path ground, locality, existence proof, watch freshness, and strongest next action separately named, because “this looks like a file path” is not the same fact as “this is the exact file object I can safely act on now.”**

The point is not to avoid clickable file UX.
The point is to keep it smaller than authority.
A custom shell+terminal can feel super awesome here if it treats file/path comfort as a bounded object family rather than one flattering blur of prompts, hyperlinks, watch rows, and inferred cwd state.

## 1) Separate the file/path object family

At minimum Schell should keep these objects distinct:
- **path text** — raw rendered bytes that merely look path-like,
- **file card** — an exact or promoted file-like target with visible provenance,
- **path-ground witness** — the basis used to interpret the path (cwd/view/descriptor/hyperlink/remote),
- **locality chip** — local / remote / synthetic / imported / historical / unknown,
- **existence posture** — exact-verified / shell-attested / watch-observed / stale / unknown,
- **resolution posture** — literal / cwd-relative / view-relative / descriptor-relative / hyperlink-exact / remote-mediated / unknown,
- **watch-root card** — the watched root plus freshness/overflow posture,
- **source chip** — plain text / explicit hyperlink / shell-known chapter / search result / watch row / imported,
- **action ladder** — insert / reveal / inspect / open / edit / download / watch / derive,
- **strong-action gate** — the exact point where Schell re-establishes target truth before a higher-authority action.

Those facts are adjacent.
They are not interchangeable.

## 2) Path text is not file identity

A rendered path can depend on:
- the cwd in effect when the line was produced,
- the view/namespace the process lived in,
- symlink or magic-link behavior during resolution,
- host-versus-remote interpretation,
- and later filesystem drift after the line was printed.

So Schell should be willing to say:
- “this is only text,”
- “this is cwd-grounded text,”
- “this came from an explicit hyperlink,”
- “this was promoted from a watch row,”
- “this is a synthetic/index-backed subject,”
- or “this is already an exact file card.”

That one distinction would prevent a huge amount of accidental overclaim.

## 3) Local, remote, and synthetic views should stay visibly distinct

A super-awesome shell+terminal will inevitably make it easier to click things across:
- the current local project tree,
- a remote SSH host,
- a container or synthetic view,
- a generated build tree,
- a watched index/search result,
- or a historical transcript/export.

Those should not collapse into one “file” badge.
A remote file card can still be great.
A synthetic/generated file card can still be useful.
A historical subject can still be excellent for inspect or derive.
The mistake is flattening all of them into “openable local file.”

## 4) Existence needs a posture ladder, not a boolean

A useful first ladder probably includes:
- **exact-verified** — the shell or trusted helper re-resolved the target now,
- **shell-attested** — the shell emitted or carried enough ground to make the target strong,
- **watch-observed** — a watcher/index recently reported the item,
- **hyperlink-exact** — the producing program emitted an explicit exact target,
- **stale** — once known but now drifted or freshness-weakened,
- **unknown** — no current proof.

That is a practical luxury.
It lets Schell keep fast file UX while refusing the old trick where path-like text plus user hope becomes proof.

## 5) Watch roots should be separate objects, not hidden implementation detail

A watch-backed row is useful precisely because it knows something about a changing root.
So Schell should keep a first-class **watch-root card** that can say:
- what root is being watched,
- whether the root is project-scoped, manually chosen, or imported,
- whether freshness is current, lagged, overflowed, recrawled, paused, or unknown,
- whether the backend is filesystem events, polling, or a provider feed,
- and whether the current row is still only observational.

That means the terminal can say:
- “observed under watched root `project-alpha`, later recrawled,”
- “watch freshness weakened after overflow,”
- “row is still observational; promote to exact file card before edit/open,”
- or “network filesystem watch refused; inspect only.”

That is much better than treating watch state as hidden plumbing.

## 6) Insert, reveal, open, edit, download, and watch should form an action ladder

Many terminals already make file-like text easier to use.
Schell should go further, but with named rungs:
- **insert** the path or ref into active input,
- **reveal** the exact card/provenance without opening content,
- **inspect** metadata in a safe local lane,
- **open** using the current locality and handler posture,
- **edit** only when the target and locality are explicit enough,
- **download** only when the locality is remote/imported and the user is really asking for a transfer,
- **watch** only after the watch root and freshness posture are visible,
- **derive** when a synthetic or historical subject should seed a fresh proposal instead of direct action.

This is where Schell can feel luxurious without lying.

## 7) Parent-browse and path-expansion magic need stronger refusal than terminals usually give

Classic terminal/file UX often turns near-misses into broader browsing:
- file missing, so open parent directory,
- exact line target missing, so open file anyway,
- remote file unavailable, so browse remote tree,
- watched row stale, so hope the same path still means the same thing now.

Schell should be firmer.
A non-exact target can still be useful, but it should land in:
- inspect,
- reveal,
- derive fresh proposal,
- or explicit browse-with-new-ground.

It should not quietly upgrade itself into broader authority.

## 8) Symlink and synthetic-link posture deserve a visible downgrade

Some file-like subjects are more slippery than others:
- symlink-based paths,
- procfs-style magic links,
- generated paths that only exist within one view,
- and imported/historical paths that may not be live anywhere now.

Schell should therefore have a small downgrade family such as:
- symlink-following required,
- magic-link blocked,
- synthetic-view local only,
- historical only,
- remote mediation required,
- or unknown.

That keeps “looks file-like” smaller than “safe exact object.”

## 9) A compact first proving slice

A strong first specimen set would show:
1. one exact local file card with verified existence and editor open,
2. one cwd-grounded path text promoted into an exact file card before stronger action,
3. one explicit hyperlink-exact file target,
4. one remote-file card with edit/open/download split rather than generic open,
5. one synthetic/generated result that defaults to inspect or derive,
6. one watch-root card with freshness and backend posture,
7. one watch-backed row that holds because overflow/recrawl weakened freshness,
8. one symlink or magic-link reveal that downgrades before open,
9. one refusal to parent-browse from a non-exact miss,
10. and one transcript witness showing path text, path ground, file card promotion, and resulting action separately.

That is already enough to make Schell feel much more polished than a classic terminal without freezing the final file browser, watcher backend, or namespace algebra.

## 10) Things to refuse for now

Refuse for now:
- one undifferentiated “file click” object that mixes text, exact files, remote subjects, and watched rows,
- watch-backed rows that silently count as exact current state,
- parent-browse fallbacks that silently widen authority,
- remote/imported file actions that silently materialize local copies,
- prompt/cwd/path text pretending to be the whole file truth,
- and one final filesystem/index/browser architecture just because the UX pressure is real.

The right law is:
**steal verified file links, cwd-aware semantic history, explicit file hyperlinks, remote-file actions, and root-scoped watchers — but keep path text, path ground, locality, existence proof, watch freshness, and strongest action separately named.**
