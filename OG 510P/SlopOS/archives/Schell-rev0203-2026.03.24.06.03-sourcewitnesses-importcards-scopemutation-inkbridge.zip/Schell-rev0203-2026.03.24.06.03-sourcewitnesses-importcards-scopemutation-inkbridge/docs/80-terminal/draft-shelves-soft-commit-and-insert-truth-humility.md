# Draft shelves, soft commit, and insert-truth humility

**Schell should absolutely steal modern terminal luxuries like scratch panes, snippet palettes, command-search summon, and AI/chat suggestions — but it must keep parked draft, inserted input, reviewed run candidate, and spent action visibly separate so “sent to the command line” never quietly means “already executed.”**

## 1) The ecosystem is converging on a draft-before-run layer

A striking amount of current terminal and shell tooling now lands on the same humane shape:
- search or summon a thing,
- inspect or edit it as text,
- place it into an input surface,
- and only then decide whether to run it.

That pattern shows up across very different products:
- Warp Command Search searches across command history, workflows, env vars, notebooks, prompts, and agent history, but pressing Enter puts the selected result into the **Input Editor** rather than spending the action immediately.
- VS Code's Run Recent Command lets the operator browse multiple history sources, pin favorites, open output in an editor, and hold Alt to write the selected text to the terminal **without running it**.
- Windows Terminal's Scratchpad is explicitly a **non-terminal pane** for drafting text, while its Snippets Pane shows saved commands and lets the operator send them to the command line.
- Windows Terminal's GitHub Copilot chat copies a suggestion to the input line and explicitly says it will **not** run the suggestion automatically.

The important lesson is not merely “people like snippets.”
The important lesson is that modern terminal UX keeps rebuilding a distinct middle state between discovery and execution.
Schell should name that state directly.

## 2) The missing shell+terminal object is a parked draft with a softer commit than execution

Classic shell folklore tends to flatten all of this into a small handful of stories:
- a command is in history,
- or a command is on the prompt,
- or a command ran.

That is now too small for humane tooling.
There is a real class of object that is:
- more deliberate than random clipboard residue,
- less durable than a workflow seed,
- more attached than a mere suggestion,
- but still weaker than a reviewed execution.

That object is a **parked draft**.
And the move that places it into the active input lane is a **soft commit**.
A soft commit says:
- this text is now the candidate I am looking at,
- its source and basis still matter,
- it may deserve diff/review/privacy treatment,
- and it is still not the same thing as spending the action.

## 3) Why this matters more in a custom shell+terminal than in legacy shells

Schell is trying to become unusually good at:
- imported commands,
- command search,
- workflow reuse,
- assistant suggestions,
- runbook cells,
- editor roundtrips,
- and later resident-room help.

All of those surfaces want to place text near execution.
Without a stronger draft story, they start borrowing one another's trust language:
- a snippet can look like a workflow,
- a restored command can look like a fresh run candidate,
- an assistant suggestion can look like typed authorship,
- and a scratch pane can quietly turn into shadow history.

A parked-draft / soft-commit seam prevents that flattening.
It lets Schell stay luxurious while remaining exact about which step actually spent authority.

## 4) A small v0 ladder is already enough

Schell does not need a giant drafting subsystem first.
A useful first ladder would already separate:

- **suggestion row** — discovered, recalled, imported, or proposed text
- **parked draft** — held aside for inspection, editing, or later reuse
- **soft-committed input** — inserted into the live input lane but not yet reviewed as action
- **reviewed run candidate** — exact current input after operator review
- **spent action** — the shell actually launched it
- **receipt/history** — what remains afterward

That one ladder would already make many existing Schell seams easier to keep honest.

## 5) The strongest product moves to steal

### a) A real draft shelf

The operator should be able to park things intentionally:
- current prompt text,
- a found command,
- a snippet,
- an assistant answer,
- a captured-output follow-on,
- or a repaired command.

The shelf should preserve source, maybe a tiny diff basis, privacy posture, and whether the draft was ever soft-committed.
It should not pretend every parked item is a saved workflow or durable history row.

### b) Soft-commit chips in the active input lane

When text came from a search result, snippet pane, runbook, AI answer, or recent-command picker, the input lane should say so.
The operator should be able to see:
- source,
- whether it is exact or derived,
- whether it came from history, snippet, chat, workflow, or draft shelf,
- and whether it has changed since insertion.

That gives Schell a way to be honest without making insertion clumsy.

### c) Clear scrollback, keep parked draft

A beautiful shell+terminal move is to let operators reduce visual noise without discarding the thing they were still shaping.
Viewport residue and parked draft are different classes.
The shell should be proud enough to say so.

### d) Save to seed is stronger than park draft

A parked draft is not yet a workflow seed, shared command object, or endorsed reusable artifact.
Promotion should stay explicit.
That keeps the archive aligned with earlier Schell work on quarantine, endorsement, shared-seed humility, and replay leases.

### e) A “send here, do not run” default for many affordances

A lot of terminal delight becomes much safer if the default action is:
- insert,
- park,
- compare,
- or edit,

instead of run.
This is one of the clearest no-regret imports from the modern ecosystem.

## 6) What the shell should witness

A compact **draft witness** could carry:
- `draft_ref`
- `source_class` — history / workflow / snippet / chat / captured-output / manual / unknown
- `source_ref`
- `draft_state` — parked / soft_committed / reviewed / promoted / discarded / unknown
- `history_posture` — none / private / session / durable / shared / unknown
- `basis_posture` — exact / derived / imported / restored / unknown
- `privacy_posture` — ordinary / private / redact_on_receipt / secret_adjacent / unknown
- `promotion_posture` — park_only / promote_allowed / endorsed_seed / unknown

That is enough to make draft behavior truthful without freezing one final shelf implementation, snippet format, sync model, or editor transport.

## 7) Companion-cube pressure points

This seam fits the companion datacubes unusually well:
- **SlopOS** keeps exact execution footing and typed plumb/open flows separate, which pressures Schell not to confuse inserted text with launched intent.
- **ViewFS** already has draft-capsule, publication, and suggestion-tray instincts, which pressure Schell to keep parked draft separate from named reusable artifact.
- **Steward** keeps UI-originated session change weaker than typed input and prefers staged injection over silent execution.
- **Helm** keeps endorsement and receipt pressure alive, which argues that promotion from draft to stronger reusable object should remain explicit and exact.

## 8) Decisions intentionally kept open

This pass does **not** freeze:
- one final scratch-pane UI,
- one final snippet store,
- one final shelf retention policy,
- one final history/privacy backend,
- one final assistant-insertion protocol,
- or one final workflow promotion path.

The no-regret move is smaller:
**give Schell a first-class parked-draft / soft-commit seam so current-command search, snippets, scratch panes, repair suggestions, and assistant answers can all be luxurious without pretending that “inserted into input” already means “reviewed” or “run.”**
