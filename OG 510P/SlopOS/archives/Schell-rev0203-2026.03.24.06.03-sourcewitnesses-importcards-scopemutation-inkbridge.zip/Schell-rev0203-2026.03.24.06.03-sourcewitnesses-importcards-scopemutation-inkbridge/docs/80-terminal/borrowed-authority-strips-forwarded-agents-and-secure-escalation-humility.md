# Borrowed-authority strips, forwarded agents, and secure escalation humility

This surface keeps one boundary explicit:
**a great shell+terminal should make remote comfort, local-power bridges, and privileged edits feel dramatically better than today — but it should not let forwarded local power, helper-installed bridges, or terminal-side host effects impersonate ordinary shell truth.**

Modern terminal comfort keeps rediscovering the same temptations:
- borrow the local SSH agent,
- borrow the local clipboard,
- borrow the local open/edit bridge,
- install remote helpers automatically,
- expose a terminal-control bridge,
- and jump into privilege because the operator only needed one file changed.

These are all excellent when named honestly.
They become dangerous when the shell stops saying what is really happening.
The operator can very quickly stop knowing:
- whether a remote pane can spend local cryptographic authority,
- whether a clipboard request will ask, allow, deny, or silently no-op,
- whether a remote helper already changed startup footing,
- whether a privileged edit is narrow writeback or a whole stronger shell,
- and whether the final approval surface is trusted local chrome or just text in the session.

Schell should steal the delight.
It should refuse the flattening.

## 1) Borrowed authority deserves one compact strip

Schell should have a **borrowed-authority strip** on any lane that can cause local power to be exercised from a remote or helper-shaped context.

A useful first strip could enumerate:
- `local_agent_use` — absent / requestable / confirmed-per-use / timeboxed / unknown,
- `clipboard_access` — none / write_request / read_request / granted / denied / unknown,
- `host_open_bridge` — none / reveal_only / safe_open / strong_open / unknown,
- `terminal_remote_control` — none / local_only / bridged / password_gated / unknown,
- `helper_install_posture` — none / files_copied / env_injected / integration_enabled / unknown,
- `privileged_writeback` — none / available / active / unknown,
- `notes_ref` — optional hold card or explanation.

This is not a full privilege inspector.
It is a compact honesty surface.

## 2) Forwarded agent posture should be a lease, not a mode bit

Agent forwarding is one of the clearest places where the shell needs to do better than a generic icon.
A first **forwarded-agent lease** could carry:
- `availability` — absent / offered / active / denied / unknown,
- `confirm_posture` — per_use / session / none / unknown,
- `time_posture` — one_shot / timeboxed / session / unknown,
- `constraint_posture` — destination_bound / policy_narrowed / unconstrained / unknown,
- `subcapabilities` — sign_only / provider_load / websafe_restricted / unknown,
- `peer_binding_posture` — bound / stale / mismatched / unknown.

That gives the operator something much more truthful than “agent forwarded: yes”.

## 3) Helper posture should stay visibly helper-shaped

Remote wrappers and shell integration helpers are useful.
But copied files, injected environment, integration scripts, and remote-control bridge setup should never disappear into myth.

Schell should therefore emit a **helper posture card** whenever the terminal or wrapper:
- copies files to the peer,
- injects environment values,
- enables shell integration,
- changes terminal description/terminfo footing,
- or activates a local-to-remote control bridge.

The card should stay weaker than shell truth.
It is a sidecar about how comfort arrived, not proof that the remote environment is now intrinsically native.

## 4) Clipboard and host-effect power should ask rather than happen

Clipboard reads/writes, host-open requests, and terminal remote-control effects are exactly the sort of powers that should not hide behind escape-sequence trivia.
Schell should turn them into small ask/allow/deny surfaces with transcript-visible posture.

A first host-effect witness might only need:
- `effect_kind` — clipboard_read / clipboard_write / host_open / remote_control / other,
- `origin_grade` — raw_pty / inferred / shell_attested / trusted_local,
- `policy_result` — allowed / denied / held / downgraded,
- `subject_ref` — optional path/URI/object handle,
- `reason_ref` — optional denial or hold card.

That is enough to keep the shell honest before the ecosystem decides one final policy grammar.

## 5) Privileged edits should get a narrower rung than “open a root shell”

One of the best ideas worth stealing is **elevated writeback**.
The shell+terminal should distinguish at least:
- inspect protected object,
- stage an ordinary-user edit buffer,
- write back through a stronger reviewed lane,
- run one stronger non-interactive command,
- launch a stronger interactive session.

Those are all valuable.
They are not the same.

Schell should make the narrow rung beautiful.
A huge amount of real operator work becomes safer if “change this protected file” does not immediately mean “become root everywhere in this pane.”

## 6) Trusted approval path matters most when local power is at stake

The strongest approvals — especially ones that spend local key power, read the clipboard, or widen privilege — should land in trusted local chrome.
That does not require one final secure-attention implementation today.
It only requires that Schell keep the strongest approvals visibly separate from ordinary PTY flow.

The terminal can still render shell-known context beautifully.
But the final “yes, spend local authority now” surface should have a stronger lane.

## 7) Historical and restored posture should stay humble

A restored pane, revived connection, or reused helper state should not silently inherit strong borrowed authority.
Schell should keep historical posture separate from current live posture and prefer:
- restored but inactive,
- restored and awaiting rebind,
- stale peer binding,
- helper state historical only,
- or unknown.

That makes comfort durable without making it overconfident.

## 8) Super-awesome moves worth stealing now

### a) Borrowed-authority strips
Make local power visible whenever a remote or helper-shaped lane can spend it.

### b) Confirmation-gated leases
Per-use confirmation, timeboxes, and destination binding are much better defaults than one flat forwarding bit.

### c) Elevated-writeback edits
A narrower, more humane privilege rung.

### d) Helper posture cards
Copied files, env injection, shell integration, and bridge activation should be reviewable facts.

### e) Clipboard / host-effect ask surfaces
Permissioned host effects are much better than escape-sequence folklore.

### f) Trusted approval lane
Keep the strongest approvals off ordinary PTY flow.

### g) Freshness and peer-binding chips
Show when a borrowed-authority bridge is fresh, stale, rebound, or unknown.

### h) Downgrade-to-inspect rules
When peer truth or approval truth is weak, collapse strong actions back to inspect-only instead of bluffing.

## 9) What Schell should refuse

### Refuse remote-only mythology
A remote shell can still spend local power.
Say so.

### Refuse flat agent badges
Forwarded key use has constraint edges and deserves more than yes/no.

### Refuse privileged-edit folklore
Editing one protected file is not automatically a reason for a whole elevated session.

### Refuse silent host-side side effects
Clipboard reads, writes, opens, and terminal control should not hide behind obscure sequences.

### Refuse helper amnesia
If the terminal copied files, changed env, or enabled bridges, that should remain visible.

### Refuse stale borrowed authority as live truth
Restored or historical comfort must not impersonate current power.

## 10) Decision-light proving slice

A compact proof could show:
- one borrowed-authority strip on a remote pane,
- one forwarded-agent lease with confirm/timebox/constraint posture,
- one helper posture card for copied files + integration,
- one clipboard ask/deny card,
- one elevated-writeback edit rung,
- one trusted local approval card for spending local authority,
- one stale-peer-binding downgrade,
- and one restored pane that comes back historical until rebind succeeds.

That is enough to make Schell dramatically more trustworthy and more luxurious without freezing one final auth-agent backend, remote-control protocol, helper transport, secure-attention story, or privilege broker.
