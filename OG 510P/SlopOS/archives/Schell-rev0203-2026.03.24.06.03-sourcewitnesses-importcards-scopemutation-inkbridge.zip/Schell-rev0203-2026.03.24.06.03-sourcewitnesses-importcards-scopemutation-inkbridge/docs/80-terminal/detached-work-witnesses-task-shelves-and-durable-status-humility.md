# Detached-work witnesses, task shelves, and durable-status humility

This surface keeps one boundary explicit:
**a great shell+terminal should make project command decks, detached queues, rerunnable panes, finish cues, and restored task context feel exceptional — but it should not let `&`, task ids, finish toasts, or restored panes impersonate durable current task truth.**

The shell+terminal world keeps rediscovering the same family of comforts:
- backgrounding work,
- rerunning repeated project commands,
- detaching work from one terminal,
- surfacing finish notices,
- and restoring work context later.

These are all excellent.
They also sit right on a dangerous seam.
The operator can very quickly stop knowing:
- whether the work is still local,
- whether it can still accept input,
- whether the task id is current or merely historical,
- whether a finish cue is only a cue,
- and whether a restored pane is live or merely rerunnable.

Schell should steal the delight.
It should not inherit the flattening.

## 1) Detached work should arrive as a witness, not as one generic “job”

Schell should have a **detached-work witness** for any work that is not simply the current live foreground prompt.

A witness should say:
- `work_kind` — local_job / project_deck / pane_command / detached_queue / promoted_service / restored_history / unknown,
- `owner_posture` — current_shell / current_terminal / queue_daemon / service_manager / imported_runtime / unknown,
- `interaction_posture` — foreground / background-no-stdin / pane-attached / pane-hidden / detached-log-only / restored / unknown,
- `identity_posture` — exact-live / exact-historical / request-key-only / task-id-only / restored / guessed,
- `cue_posture` — none / status-strip / finish-cue / alert-flag / historical-only,
- `result_posture` — pending / running / completed / completed-with-problems / cancelled / expired / unknown,
- `closing_witness` — exact-receipt / exit-status / queue-record / historical-pane / none,
- `claim_strength` — native_live / native_attested / adapted / historical / guessed.

This turns non-foreground work into a truth surface rather than one background myth.

## 2) A task shelf should separate request identity from live state

Schell should have a **task shelf** or equivalent compact deck where every entry preserves at least:
- exact task/work ref,
- request key or task id when relevant,
- current owner,
- live state,
- cue state,
- input posture,
- last durable closing witness,
- and whether the entry is current, detached, restored, or historical.

The key rule is simple:
**request identity and current live state must not be the same field in disguise.**

## 3) Orphan posture needs names

One of the oldest terminal confusions is that work keeps existing after the operator loses a good way to reason about it.
Schell should name that explicitly.

Useful first values:
- `tracked` — shell or terminal still has current direct tracking,
- `detached` — another owner now carries liveness,
- `owner-exited` — the orchestrator that owned the work is gone,
- `shell-untracked` — the work may still exist but local shell truth no longer tracks it,
- `historical` — only history or restored state remains,
- `unknown` — current owner truth was not reacquired.

This makes “where did that thing go?” much less mysterious.

## 4) Finish cues and durable results should stay on different rungs

A threshold notification, badge, or finish glow is useful.
It is not the durable result.

So Schell should keep:
- **cue state** — the thing that helps a human notice,
- **durable result state** — the thing that remains true after the cue disappears,
- **closing witness** — the exact receipt, exit status, queue record, or denial surface that closes the story.

A cue may:
- summarize,
- update,
- focus,
- or invite re-entry.

It should not become the only durable evidence that work completed.

## 5) Attach, inspect, rerun, and promote should be different buttons

A single vague “resume” button is usually dishonest.
Schell should probably keep at least this small ladder:
- **bring-forward** — focus the current live pane or exact status entry,
- **inspect-log** — open durable output or bounded history,
- **attach-live** — reattach to a still-live interactive owner,
- **rerun-reviewed** — re-execute the exact reviewed task basis,
- **promote** — move the work into a stronger/different owner such as a service or queue,
- **retire-local-tracking** — forget local waiting/cue state without claiming the work ended.

Those are different strengths.
They should feel different.

## 6) Project command decks deserve first-class treatment

There is a large category of work that is neither:
- one foreground shell command,
- nor a durable queue/service.

It is the project command deck:
- run these known commands together,
- keep their outputs separate,
- restart them often,
- and let them die when the deck dies.

Schell should make that category first-class.
It is one of the nicest modern luxuries.
It should still remain visibly weaker than detached service supervision or durable queue truth.

## 7) Detached queue cards deserve their own honesty

Detached queue work should show things local jobs and project decks usually do not need:
- group membership,
- parallelism/ordering posture,
- durable log posture,
- current wait/follow state,
- callback/notification posture,
- and whether the queue owner remains reachable.

The important design move is not “build Pueue inside Schell tomorrow.”
It is: **give detached queue work its own witness family instead of flattening it into local job control.**

## 8) Restoration should keep task context without borrowing liveness

A restored pane, revived deck, or reopened task shelf entry is valuable.
It should still say:
- what exact owner used to exist,
- what exact task basis was serialized,
- whether rerun is exact / lossy / unavailable,
- and whether current live state has been reacquired.

The good default is:
**restored is historical until live ownership returns.**

## 9) Super-awesome moves worth stealing now

### a) Task shelf with cue/result split
A compact deck where badges, finish cues, and durable closing witnesses are visibly separate.

### b) Orphan posture chips
Tracked / detached / owner-exited / shell-untracked / historical.

### c) Project command deck cards
Excellent for common local multi-process workflows without pretending they are durable services.

### d) Queue cards with follow/log/wait posture
Perfect for detached work that outlives one shell session.

### e) Exact attach/rerun/promote ladder
Make different strengths obvious before the operator commits.

### f) Cue identifiers that can update in place
Great for long-running work, while still weaker than durable results.

### g) Restored-work banners
Keep old context usable without pretending it is live.

## 10) What Schell should refuse

### Refuse one giant “job” category
Foreground jobs, local background jobs, project decks, detached queues, services, and restored panes are not one thing.

### Refuse task ids as present-tense proof
Ids correlate stories; they do not by themselves prove current liveness.

### Refuse cue/result collapse
A finish cue is not the durable outcome.

### Refuse project decks as fake supervision
Finite repeated workflows are not durable background presence by default.

### Refuse restored panes as live truth
Historical context should stay historically badged until reacquired.

## 11) Decision-light proving slice

A compact proof could show:
- one local background job witness,
- one project command deck entry,
- one detached queue card with follow/log posture,
- one threshold finish cue that updates in place,
- one durable result card separate from the cue,
- one orphan posture transition,
- one exact attach/rerun/promote ladder,
- and one restored entry that stays historical until live state is reacquired.

That is enough to make Schell feel dramatically more capable without freezing one final queue backend, deck format, notification stack, or resurrection substrate.
