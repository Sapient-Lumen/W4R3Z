# Detector witnesses, quick-fix rails, and action humility

This surface keeps one boundary explicit:
**a great shell+terminal should be able to notice likely next moves in command output, but it should not let regexes, heuristics, quick-fix providers, or restored detector residue become hidden execution authority or fake proof of what the shell actually knows.**

Modern terminals increasingly do more than render bytes:
- they detect paths, URLs, ports, commands, stack traces, and error shapes,
- they decorate command boundaries and output ranges,
- they surface quick fixes, clickable file/line ranges, or next-step menus,
- and they increasingly let the operator jump from visible output to a stronger action.

That is excellent.
It is also one of the easiest ways to let local cleverness overclaim truth.

The dangerous flattening looks like this:
- detection quietly becomes diagnosis,
- diagnosis quietly becomes a command rewrite,
- command rewrite quietly becomes auto-rerun,
- and restored or heuristic matches quietly impersonate exact shell knowledge.

SlopOS is already giving Schell a very strong lesson here.
Its learn-mode work says observational suggestions are not an authorization mode.
Its acceptance/completion posture says admitted is not completed.
Its preview/open boundaries keep second workflows separately named.
Schell should import all of that before “smart terminal actions” become a second shell.

## Why this surface exists

There are at least seven distinct things a terminal can do after it notices something interesting in output:
1. detect a candidate,
2. highlight or decorate it,
3. explain why it matched,
4. prepare a possible action,
5. insert a proposed command or argument,
6. open/reveal/inspect a subject,
7. or review and run a stronger follow-up action.

History says systems love to compress those into one flattering click or lightbulb.
That is the exact mistake to avoid.

A path-like token, a failing port, a stack-trace line, or a git error suggestion may come from very different bases:
- shell-known chapter metadata,
- exact command output plus exit code,
- tool-emitted structured markers,
- cwd-aware contextual resolution,
- heuristic regex or fuzzy matching,
- provider-local enrichment,
- or restored detector residue from a previous session.

Those origins matter.
They should stay visible.

## The compact answer: detector witnesses and action rails

A useful small object here is **detector witness**.

A detector witness is not a giant IDE subsystem.
It is a compact Schell object that says:
“some local detector noticed a bounded candidate here, here is exactly what evidence it used, here is how strong the match is, and here is the ordered action rail the UI may offer without pretending stronger truth than it has.”

A v0 detector witness probably needs:
- `chapter_ref` — which command chapter or bounded output range this came from,
- `subject_basis` — exact output range / exact object ref / cwd-contextual path / tool marker / unknown,
- `detector_family` — shell-witnessed / tool-emitted / contextual / regex-heuristic / restored / imported,
- `candidate_kind` — file-line / url / port-conflict / retry-shape / similar-command / stack-trace / pid / process / unknown,
- `evidence_posture` — exact-output / exact-exit / exact-marker / contextual / heuristic / restored,
- `confidence_posture` — exact / strong / heuristic / historical / unknown,
- `freshness_posture` — current / repaired / restored / historical / unknown,
- `action_posture` — inspect-only / insert-first / reveal / open / review-rerun / safe-open / blocked,
- `notes_ref` — optional explanation card or command-context bundle.

That is enough to power rich operator delight without freezing:
- one detector DSL,
- one regex engine,
- one shell-integration provider format,
- one AI fixer stack,
- or one persistent action-index architecture.

## 1) Detection should stay weaker than shell-known truth

If the shell already knows something exactly, use that.
If the terminal inferred something heuristically, say so.

A path emitted as a shell-known object ref is not the same thing as:
- text that merely looks path-like,
- a regex match over stderr,
- or a restored hit remembered from earlier.

Schell should therefore rank detector sources rather than flatten them.
A useful order is:
1. shell-witnessed,
2. tool-emitted,
3. cwd-contextual,
4. heuristic,
5. restored/imported.

That order should affect not only badges but also which actions are even allowed.

## 2) Action rails should keep weak and strong moves separate

A detector witness should not map straight to “do the thing.”
It should map to an **action rail**.

An action rail is an ordered ladder such as:
- explain,
- copy,
- insert,
- reveal,
- inspect,
- open,
- compose patched rerun,
- review stronger action,
- run after review.

That keeps the terminal honest.
The same detected port conflict might support:
- reveal which process owns the port,
- insert a kill command,
- compose a patched rerun,
- or review a combined action bundle,

without any of those silently becoming automatic.

## 3) No auto-edit, auto-rerun, or auto-kill just because a detector fired

This is one of the strongest imports from SlopOS.
Observational help is not a second authorization path.

Schell should refuse the classic slippery moves:
- “we detected the fix, so we edited your command,”
- “we detected the missing flag, so we retried,”
- “we detected the port owner, so we killed it and reran,”
- or “we detected the target file, so we opened it in the strongest available way.”

Detector-driven help should remain proposal-only until a new explicit review path is taken.

## 4) Chapter-bounded evidence is better than whole-history folklore

A detector is much more trustworthy when it can say:
- this match belongs to command chapter X,
- this line range and exit code produced it,
- this cwd or object basis was active,
- and this explanation card records why the suggestion appeared.

That is far better than a floating terminal lightbulb with no provenance.

It also means restored or copied output can stay visibly weaker.
A detector hit from a transcript replay or restored session may still be useful, but it should not pretend to be the same as a live shell-known chapter on current basis.

## 5) Heuristic scans should prefer summon or visible-region scopes over ambient full-history parsing

Some of the coolest ideas in the current ecosystem come from visible-region hint modes and focused detection.
That is worth stealing.

A good decision-light rule is:
- shell-known detection may stay ambient when the shell emitted exact boundaries,
- tool-emitted markers may stay local to the owning chapter,
- but broad heuristic matching should prefer explicit summon, current viewport, or bounded-chapter scope rather than a hidden full-history crawler that invents actions everywhere.

That keeps delightful discovery without normalizing ambient parser work over everything you have ever scrolled past.

## 6) Restored detector residue should stay historical until re-proved

This archive already learned the restored-vs-live lesson for sessions, links, and preview.
The same applies here.

A previously useful quick fix may still be helpful after relaunch, but it should wear posture like:
- `restored`,
- `historical`,
- `recheck required`,
- or `compose again on current basis`.

That is especially important for actions tied to:
- ports,
- running processes,
- current branches,
- temporary files,
- or failing commands whose environment/cwd may have changed.

## 7) Great ideas worth stealing that still stay decision-light

### a) Chapter-bound quick-fix cards
A command chapter can surface one small card for known failure families with exact command context, exit code, and one ordered action rail.

### b) Insert-first file and path affordances
When a detector notices a likely path or file-line reference, Schell can offer `insert path`, `reveal`, `open`, and `safe-open` separately rather than forcing “click means open.”

### c) Port-conflict bundles
For “address already in use,” the UI can show the owning process, explain the basis, and compose a reviewed kill-and-rerun bundle without ever auto-running it.

### d) Exact handoff bundles
When the operator wants help, the terminal can hand off an exact command-context bundle containing command line, output slice, exit code, and detector witness instead of vague copied screenshots.

### e) Detector palettes or hint mode
A visible-region or current-chapter hints mode can turn rich detection into an explicit summon surface instead of ambient noise.

### f) Tool-emitted richer witnesses
Some tools can eventually emit richer markers than regexes can infer.
Schell should leave room to privilege those later without requiring them today.

## 8) The no-regret move

The best move right now is not to freeze a giant quick-fix engine.
It is to pin one rule:
**detector-driven affordances in Schell should become explicit detector witnesses with source/confidence posture and bounded action rails before they become magical local quick fixes.**

That keeps the archive free to defer:
- the first detector DSL,
- the first structured marker protocol beyond shell-known chapters,
- the first AI fixer backend,
- the first persistent affordance index,
- and the final policy for which detectors get ambient versus summoned UI.

## 9) Sources worth stealing from

- VS Code quick fixes, command guide, sticky scroll, and exact command-context handoff bundles
- kitty hints mode and customizable actions over visible snippets
- iTerm2 triggers and semantic history as both inspiration and warning
- Windows Terminal suggestion menus as a reminder that suggestion sources can stay explicit and filterable
- xterm.js security guidance as a reminder that terminal output is untrusted and detector/link handlers are a real boundary
