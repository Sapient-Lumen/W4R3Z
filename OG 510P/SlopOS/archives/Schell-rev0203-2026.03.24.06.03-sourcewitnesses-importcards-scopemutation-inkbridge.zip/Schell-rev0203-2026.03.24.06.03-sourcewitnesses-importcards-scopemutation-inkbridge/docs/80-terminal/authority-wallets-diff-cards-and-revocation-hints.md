# Authority wallets, diff cards, and revocation hints

This surface records a new no-regret candidate cluster for Schell:
**make authority visible as compact descriptive objects without turning those objects into a second authority plane.**

The design pressure comes from SlopOS wallets/diffs/leases plus current shell-integration and workflow products.
The shell+terminal opportunity is simple:
people should not have to infer current power from prompt folklore, stale receipts, or hidden startup state.

## 1) Authority wallet strip

A current lane should be able to render a tiny **authority strip**.
Not a giant dashboard.
Just enough to orient the operator.

Candidate fields:

- wallet core digest or short stable id,
- lane name,
- trust grade,
- widening state (`same`, `widened`, `drifted`, `unknown`),
- lease summary (`ttl`, `uses`, `scope` when applicable),
- and maybe one “show diff” action when there is an unresolved widening.

Important posture:

- the strip is **descriptive**,
- it is not a bearer object,
- it does not reopen or reacquire authority,
- and it should remain valid to hide it entirely in plain-text fallback.

## 2) Exact authority diff cards

When a command, workflow, or proposal needs more authority than the current reviewed baseline, Schell should prefer a compact **authority diff card** over a vague permission prompt.

A good diff card would show:

- exact reviewed baseline identity,
- exact requested widening,
- which bounds apply now,
- what remains absent,
- what will expire or revoke,
- and the exact diff digest or equivalent approval-basis identity.

This is one of the cleanest ways to steal from SlopOS without overcommitting architecture.
The archive does not need a giant policy UI.
It only needs review cards that are exact enough to be worth trusting.

## 3) Lease pills and bounded-grant hints

Schell should make bounded authority look bounded.
A few small affordances may be enough:

- `10m left`,
- `1 use left`,
- `cwd-only`,
- `network denied`,
- `bg until revoke`,
- `receipt only`,
- `historical`,
- `live state unknown`.

The point is not decoration.
The point is to stop temporary or partial power from masquerading as ordinary ambient shell state.

## 4) Revocation and basis-drift hints

The shell+terminal should keep naming two different problems:

### Basis drift

The exact reviewed basis changed, so a previously approved action does not mean the same thing anymore.

### Live-state drift

The historical descriptor is still true about the past, but current provider-owned live state may have changed or become unknown.

These need different cues because they ask different operator questions.
A past receipt may still be a perfectly good receipt while also being a bad current-state oracle.

## 5) Where these objects should live

Do **not** limit this to the prompt.
The better design is probably:

- authority strip on the active-input lane,
- fuller diff card on review surfaces,
- compact wallet/diff references on receipts,
- workflow artifacts carrying their own reviewed baseline summaries,
- and background residue carrying explicit “partial provenance” or “live state unknown” markers when needed.

That would let Schell keep one truth family visible across lanes without implying that all lanes have the same power.

## 6) Things Schell should refuse

### Refuse wallet-as-container

The summary object should not become the authority object.

### Refuse giant dashboards first

Earn a tiny strip and one good diff card before inventing an operations cockpit.

### Refuse reusable approval by visual similarity

A previous diff card can inform the operator.
It should not silently authorize a new action just because the card looks nearby.

### Refuse current-live-state claims from descriptor presence alone

A wallet or receipt can be present, expired, historical, drifted, or current.
Schell should say which one it knows.

## 7) No-regret first cut

A first specimen set could stay very small:

1. one active-input strip,
2. one widening diff card,
3. one receipt with wallet/diff references,
4. one expired lease hint,
5. and one drifted historical object that refuses a strong action.

That is enough to learn a lot without freezing the final renderer, transport, or policy model.
