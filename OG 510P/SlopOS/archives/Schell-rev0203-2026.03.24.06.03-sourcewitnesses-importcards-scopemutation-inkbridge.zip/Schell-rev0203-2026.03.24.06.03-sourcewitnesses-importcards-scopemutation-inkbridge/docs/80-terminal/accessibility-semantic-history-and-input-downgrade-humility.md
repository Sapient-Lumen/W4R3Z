# Accessibility, semantic history, and input-downgrade humility

This surface keeps one boundary explicit:
**a great shell+terminal should make interaction richly semantic and genuinely accessible — but it should not let semantic-history guesses, upgraded input channels, or restored context impersonate live shell truth.**

A lot of modern terminal delight comes from the same family of moves:
- clickable filenames and command output,
- prompt-aware navigation,
- richer keyboard/input protocols,
- narrated structure for screen readers,
- and restored sessions that remember where you were.

These ideas are excellent.
They also sit right on a dangerous boundary.
A terminal can easily drift from:
- *I can help you inspect and navigate this shell state*
into
- *I am now silently deciding what object this is, what action to take, and how strongly you should trust it.*

Schell should steal the delight.
It should not inherit the overclaim.

## 1) Semantic history should arrive as a witness, not a magic click

Schell should have a **semantic-history witness** for any clickable or narratable object discovered in the visible terminal.

A witness should say:
- `subject_kind` — file / uri / host / command_output / stack_frame / process_hint / other,
- `identity_posture` — exact / shell_marked / cwd_derived / text_guessed / restored / unknown,
- `source` — shell_mark / terminal_semantic_history / visible_text / imported_index / restored_snapshot,
- `basis` — cwd / host / session / transcript chapter / none,
- `freshness` — live / same-session / restored / historical / unknown,
- `strong_actions` — reveal / review / open / export / share / rerun,
- `claim_strength` — native_exact / native_attested / adapted / degraded / guessed.

This turns smart clicks into a truth surface.
It keeps convenience high without letting the terminal quietly hide how it recognized the target.

## 2) Exact-reveal should sit between seeing and doing

For strong actions, Schell should prefer an **exact-reveal ladder**:
1. inspect the discovered object,
2. reveal the exact resolved target or exact failure to resolve,
3. then offer stronger actions such as open/export/share/rerun.

That matters especially when the visible thing is:
- a path-like token,
- a stack frame,
- command output that looks file-like,
- or a restored object from an older session.

The terminal should be allowed to guess.
It should not be allowed to disguise a guess as exact target identity.

## 3) Accessibility should narrate command chapters, not just colors and blocks

Schell should have **accessibility-aware command chapters**.
That means the shell should expose structure that a screen reader or dense keyboard workflow can traverse:
- prompt boundary,
- command input,
- command output,
- warnings/denials,
- receipts or result cards,
- and restore/historical badges.

The core design move is simple:
**structure should be narratable in shell-owned terms, not merely implied by color, padding, or mouse affordances.**

That makes the terminal better not only for assistive tech but also for:
- keyboard-only use,
- high-compression workflows,
- remote sessions,
- and plain-text transcript fallbacks.

## 4) Observation and injection must stay on different rungs

Schell should keep at least four interaction strengths visibly separate:
- **observe** — inspect, narrate, select, and navigate,
- **prepare** — move focus, stage edits, reveal targets,
- **inject** — place cursor, insert text, or synthesize input,
- **commit** — run, rerun, restore, export, or share.

This prevents accessibility or semantic-history luxuries from quietly becoming a hidden automation plane.
A narrated command chapter is not the same as input injection.
A semantic selection is not the same as re-running a command.
A restored pane is not the same as a live shell.

## 5) Rich keyboard/input support needs its own capability card

Schell should expose an **input-capability card** that says how strong the current input stack really is.

Possible posture values:
- `native_full` — rich input protocol fully negotiated,
- `native_basic` — standard terminal keys only,
- `adapted` — host-specific translation or bridge in use,
- `downgraded` — richer protocol available elsewhere but intentionally disabled here,
- `disabled` — safety or compatibility rule turned it off,
- `unknown` — terminal capability not yet attested.

This is important because richer input is not just a feature.
It affects whether Schell can honestly promise:
- precise cursor motion,
- exact modifier-aware shortcuts,
- robust screen-reader navigation shortcuts,
- and prompt-local editing behavior.

Downgrade honesty is a feature, not a failure.

## 6) Restored state should stay historical until live truth returns

A **safe resurrection banner** should keep restored context visibly weaker than live state.

A restored chapter or pane should show:
- `restored_from` — serialized session / imported transcript / bridge residue,
- `state_posture` — historical / view-only / ready-to-rerun / reattached-live,
- `rerun_basis` — exact / lossy / unavailable / dangerous,
- `claim_strength` — historical_exact / historical_lossy / guessed.

This lets Schell preserve context without teaching the operator a bad reflex.
The right reflex is:
*restored is useful, but restored is not live until reacquired.*

## 7) Super-awesome moves worth stealing now

### a) Command-chapter rotor
A keyboard and screen-reader-friendly index of prompt, input, output, warning, receipt, and restore badges.

### b) Semantic-history provenance pills
Badge a discovered target as exact / cwd-derived / guessed / restored.

### c) Input downgrade rail
Explain why a richer key/mouse protocol is adapted, disabled, or downgraded.

### d) Exact-reveal before open
Let clicks stay fast while still surfacing exact target identity before stronger actions.

### e) Safe resurrection banner
Restore layout and context without silently re-running commands.

### f) Contrast-safe authority chrome
Never rely on color alone to distinguish warning, denial, restore, degraded, or guessed posture.

### g) Narrated result cards
Let result/receipt surfaces be traversable as structured objects rather than as anonymous text mass.

## 8) What Schell should refuse

### Refuse semantic magic without provenance
Clickable is not enough.
The terminal should say why it thinks the object is what it is.

### Refuse upgraded input as silent baseline truth
If richer protocols are adapted or downgraded, that should be visible.

### Refuse accessibility as visual polish only
Structure must survive narration, keyboard-only use, and transcript fallback.

### Refuse restored context masquerading as live authority
Historical state should stay historically badged until reattached or rerun.

### Refuse observation/injection collapse
Inspecting, navigating, editing, injecting, and committing are different strengths.

## 9) Decision-light proving slice

A compact proof could show:
- one semantic-history witness for a clickable stack frame or file path,
- one exact-reveal step before open,
- one command-chapter rotor or narrated chapter specimen,
- one input-capability card showing downgraded protocol posture,
- one restore banner for a historical pane,
- and one refusal case where a guessed object is denied strong action without fresh review.

That is enough to make Schell feel dramatically more modern and humane without freezing one final semantic-history protocol, accessibility API, keyboard stack, or resurrection format.
