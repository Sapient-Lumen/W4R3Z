# Bracketed-paste witnesses, multiline grants, and clipboard-query humility

This surface narrows an earlier clipboard family seam rather than widening it:
**typed text, pasted text, multiline command-send, and clipboard readback are nearby powers, but they are not the same thing and Schell should stop letting them share one flattering “input” story.**

The ecosystem is unusually clear here.
Readline's bracketed-paste mode exists so pasted characters are inserted as one string instead of replaying editing bindings.
fish enables bracketed paste so it can distinguish paste from manual entry, and it even escapes pasted quotes/backslashes inside single quotes.
zsh's `bracketed-paste-magic` shows how much target-aware paste behavior can happen before insertion.
VS Code warns on multiline paste when the shell does not support bracketed paste, but also uses bracketed paste when it sends multiline commands back into the terminal.
kitty and WezTerm then make the clipboard boundary sharper still: clipboard write and user-triggered paste are not the same power as clipboard query.

Schell should steal the luxury but keep the truth smaller.

## 1) Typed input, pasted input, and selected-text send are not the same authorship event

A shell prompt needs at least three separately named ingress families:
- **typed keystrokes**,
- **pasted text**,
- **tool- or UI-originated send-as-paste**.

That is not overdesign.
It is the minimum needed to stop a terminal from pretending that replayed text and authored keystrokes carry the same review meaning.
A multiline history recall sent back through bracketed paste should not masquerade as manual typing.
A selected snippet injected by a terminal command should not masquerade as a clipboard event.

So Schell should keep a compact ingress witness with fields like:
- `ingress_family`,
- `paste_posture`,
- `source_posture`,
- `target_posture`,
- `multiline_posture`,
- `transform_posture`,
- `control_structure_posture`.

## 2) Bracketed paste should be a visible witness, not hidden trivia

Legacy terminals made paste safer by adding bracketed-paste mode, but most shells still treat that as a mostly invisible implementation detail.
Schell can do better by making it visible whenever it matters.

A small badge can say:
- bracketed paste active,
- plain typed input,
- pasted as one edit,
- shell lacks bracketed-paste footing,
- multiline replay held,
- or unknown lane posture.

That already answers the operator question that old shells leave fuzzy:
**did this arrive as ordinary typed text, or as one bounded paste event?**

## 3) Multiline insert should become a grant, not a gamble

The most valuable practical lesson here is simple:
**multiline delivery should be explicitly granted per target posture.**

A prompt with bracketed-paste support can often accept multi-line text as one edit.
A fragile prompt or non-bracketed lane may need a hold card instead.
A fullscreen program may want literal delivery.
A secret-bearing or elevated target may want inspect-first or deny-first posture.

So Schell should not model “paste succeeded” as one binary.
It should model a **multiline grant**:
- literal insert,
- quoted insert,
- scratch-stage,
- slow-paste,
- single-line split preview,
- deny,
- or hold-for-review.

That is both safer and more delightful than pretending all text entry is the same.

## 4) Paste transforms should stay explicit and target-aware

There are excellent moves worth stealing here:
- quote paths or values before insert,
- preserve literal newlines,
- normalize line endings,
- strip or reveal hidden controls,
- stage large pastes into scratch,
- or send text back into the shell using bracketed-paste posture on purpose.

The wrong move is silent rewrite.
The right move is to present these as named **paste-grant variants**.
Then Schell can be extremely smart without making the shell boundary mysterious.

## 5) Clipboard query is a stronger power than user paste

This is the most important authority lesson in the current terminal landscape.
A user pressing paste is asking for delivery into one current target.
A program asking to **read the clipboard** is asking for ambient data access.
Those should not share the same permission story.

So Schell should keep a dedicated **clipboard-query gate** with outcomes like:
- deny,
- ask once,
- allow once for this lane,
- allow only after a user-triggered paste,
- allow metadata only,
- or allow under a stronger named lease.

That keeps paste comfort and clipboard introspection from blurring together.

## 6) Remote and nested paste stories deserve bridge humility

A remote shell, nested multiplexer, or VM helper may be able to influence local clipboard or paste behavior, but that should never be allowed to overclaim locality.
A terminal-originated “send selected text” command is also not the same thing as a local clipboard paste.

So Schell should keep bridge posture visible:
- local paste,
- terminal-sent paste,
- mux-local replay,
- remote-to-local bridge,
- VM/helper bridge,
- denied by outer terminal,
- or unknown.

That one strip would eliminate a lot of misleading “pasted” success stories.

## 7) Super-awesome specimen moves that still stay decision-light

A small early specimen set could be wonderful:

### a) A paste chip on the live prompt
Show `pasted 12 lines as one edit` or `multiline paste held for review` instead of silently changing behavior.

### b) A compare card for multiline grants
Offer `literal`, `quoted`, `scratch`, and `slow` variants before delivery into sensitive or elevated targets.

### c) Send-selected-text with explicit authorship
If the terminal sends a multi-line command back to the prompt, show that as `ui-sent / bracketed / multiline` rather than typed.

### d) Clipboard-query confession
If something asked to read the clipboard, show the request family, source lane, and result instead of flattening it into “paste happened”.

### e) Control-structure inspector
Reveal newline count, tabs, escapes, hidden controls, and line-ending posture before large or suspicious paste grants.

## 8) The no-regret move

The best move right now is not to freeze one final clipboard subsystem or one final paste-policy engine.
It is to pin a smaller rule:
**Schell should model bracketed paste posture, multiline grants, target-aware paste transforms, and clipboard-query gates as first-class witnesses before it lets typed input, pasted input, selected-text send, or ambient clipboard reads masquerade as one generic input story.**

That keeps open:
- the final clipboard backend mix,
- the final paste-history story,
- the final approval UI for privileged paste,
- the final remote/mux bridge policy,
- and the final rich-payload transform stack.
