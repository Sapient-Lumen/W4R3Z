# Assistive witnesses, accessibility lanes, and automation humility

This surface names another place where a shell+terminal can become genuinely great or quietly dangerous:
**assistive access should be treated as a first-class operator lane, but “screen reader friendly” must not silently widen into ambient UI observation, keyboard injection, or cross-app automation authority.**

Schell can become super awesome here.
It can make command chapters, object cards, prompts, progress, and failure packets much easier to review through screen readers, braille displays, high-contrast themes, magnifiers, and alternative navigation surfaces.
But it needs a better story than “the terminal is text, so accessibility will just happen.”
Modern terminals, editors, and desktop platforms keep showing that accessibility is both a performance question and an authority boundary.

## 1) Accessibility is not one thing

At least five nearby lanes exist:
- **assistive observation** — expose structure, labels, state, output, and focus in a way assistive tech can consume,
- **assistive narration/review** — accessible view, chapter jumps, list-form summaries, braille-friendly output, and predictable announcement surfaces,
- **assistive presentation** — contrast, reduced motion, cursor shape, focus clarity, magnification friendliness, and color fallback,
- **assistive input** — keyboard navigation, alternate command navigation, speech or switch-friendly movement,
- **UI automation/injection** — programmatic clicks, key injection, focus moves, app control, or cross-window scripting.

Those lanes overlap.
They should not collapse.
A screen-reader-friendly command chapter is not permission to inject keys.
An accessible output mirror is not a global UI hook.
A braille-friendly view is not automation.
A trusted assistive observer is not a blanket right to drive the whole desktop.

## 2) Schell should mint a small assistive witness family

A good first move is not a huge accessibility subsystem.
It is one shell-owned **assistive witness** family that lets the shell and terminal name what assistive tools can rely on.

A v0 assistive witness could keep:
- `subject_ref` — command chapter / active input / object card / progress scope / review card / failure packet / peer witness,
- `subject_kind` — prompt / output / object / progress / review / denial / historical / unknown,
- `access_mode` — observe-only / review-only / structured-summary / announce / navigate / inject / unknown,
- `structure_ref` — exact lines / command chapter boundaries / object-card fields / parameter slots / failure reasons / progress milestones,
- `freshness_posture` — current / restored / historical / imported / unknown,
- `render_posture` — transcript-derived / shell-known / renderer-derived / accessibility-cache / externalized,
- `announcement_policy` — quiet / on-focus / on-change / on-request / sticky / unknown,
- `alternate_surfaces[]` — accessible-view / list-summary / object-field reader / braille-summary / exported-csv / exported-html / reveal-in-tool,
- `authority_posture` — observation-only / local-review / explicit-injection-needed / unknown.

That is enough to ground accessibility work without freezing one accessibility API, one OS toolkit bridge, or one final screen-reader protocol.

## 3) The strongest design lesson: observe and inject must stay different

The past keeps teaching this the hard way.
Accessibility APIs often expose both observation and action.
That can be necessary.
It can also become a malware-grade seam.

Schell should therefore keep a hard split:
- **observe shell truth**,
- **review shell truth**,
- **navigate shell truth**,
- **request stronger automation**,
- and **inject into unrelated UI**.

The shell+terminal itself only needs the early parts of that ladder for a long time.
It does not need to smuggle in global automation just because accessible navigation is valuable.

## 4) Great steals: accessible review should be chapter-aware, not scrollback-only

One of the best ideas to steal from modern editor-terminals is the accessible review surface:
- accessible view of the current terminal buffer,
- jump by command chapter,
- jump by recent command,
- jump by recent directory,
- jump by semantic symbol or section.

Schell can do even better because it is designing the shell and terminal together.
If command chapters, progress scopes, object cards, and denial cards already exist, then assistive review does not need to reconstruct structure from a flat matrix of characters.

That suggests a no-regret move:
**make assistive review hang off shell-known chapters and cards before trying to make raw scrollback inference magical.**

## 5) Prompting and progress should have non-redraw alternates

Rich terminal prompts and animated spinners are often fine visually and miserable for speech output.
So Schell should keep simple alternates nearby:
- prompt questions as stable fields with explicit labels,
- progress as milestone announcements or list-like state,
- optional accessible summaries for long, dynamic interactions,
- and a quiet mode where redraw-heavy visual polish yields to stable announced structure.

This does not mean abandoning rich interaction.
It means every redraw-heavy interaction should have a reviewable low-churn counterpart.

## 6) Output should sometimes escape the terminal on purpose

One of the niftiest ideas worth stealing is not “keep everything inside the PTY.”
It is the opposite:
for some data, the humane move is to offer a better review surface.

Examples:
- a list-style summary for dense objects,
- an accessible table or grid in a host-native view,
- export to CSV or HTML,
- an object-card reader that speaks labels and values cleanly,
- or a one-shot accessible detail sheet for a command result.

The key rule is that those are **alternate review surfaces**, not hidden upgrades of authority.
Opening an accessible result sheet is not approval, not replay, and not current live truth by itself.

## 7) Accessibility caches and mirrors should stay visibly weaker than live truth

Assistive systems often benefit from local snapshots.
That is good.
But Schell already knows the historical trap here.
A restored chapter, cached accessible tree, or frozen accessible summary can help orientation while still being weaker than current shell truth.

So any assistive cache should keep visible posture such as:
- `historical`,
- `restored`,
- `last witnessed`,
- `not live`,
- `press to refresh`,
- or `shell not attached`.

That keeps accessibility aids from becoming another stale truth plane.

## 8) Shell-known accessibility beats terminal-only accessibility

A modern terminal may improve accessibility on its own.
That is good.
But Schell should prefer the stronger order:
- shell-known chapter / object / progress truth first,
- terminal projection second,
- assistive bridge third,
- OS-global automation only when separately asked.

That order preserves portability and transcript truth.
It also means SSH, replay, logs, and plain terminals can still degrade honestly instead of losing all structure.

## 9) Great steals that still stay decision-light

### a) Accessible chapter browser
A review surface that jumps by exact command chapter, failure packet, review-needed object, or progress scope.

### b) Stable prompt forms
When a prompt becomes complex, render a stable labeled-question form for assistive review instead of relying on redraw-heavy inline widgets alone.

### c) Accessible object cards
Every object card should have a clean field/value narration order and a low-noise list mode.

### d) Progressive output alternates
Offer `summarize accessibly`, `open in accessible view`, `export csv`, or `export html` without pretending those surfaces are the new authority source.

### e) Observation/injection split indicators
If stronger assistive or automation rights exist, surface that explicitly in chrome and receipts.

## 10) The no-regret move

The best move right now is not to choose one accessibility API or one automation story.
It is to pin one rule:
**Schell should model assistive access as a shell-known witness lane with explicit observe-vs-inject posture, stable review alternates, and historical freshness labels before accessibility quietly collapses into ambient UI automation or redraw-heavy terminal folklore.**

That keeps the archive free to defer:
- one final macOS accessibility bridge,
- one final Windows UI Automation provider/client story,
- one final Wayland or AT-SPI bridge,
- one final braille/export protocol,
- and one final automation-permission UX.
