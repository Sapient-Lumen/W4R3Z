# Abbreviation witnesses, late expansion, and alias humility

This surface exists to keep one very stealable luxury bundle honest:
**Schell should absolutely steal late-expanding abbreviations, command-scoped shorthand, cursor landing, and one-keystroke expansion preview, but it must not let alias folklore, global macros, or rc-file shorthand become hidden execution semantics.**

The point is not to abolish short forms.
The point is to make short forms happen at the right time and in the right lane.
Typing convenience is fantastic when it stays inside active input.
It becomes confusing when it migrates into parse-time rules, ambient startup code, or script-visible meaning.

## 1) Abbreviation luxury belongs in active input

A healthy abbreviation system belongs in the one shell-owned active input field.
That is where operators should be able to:
- type a short form,
- see what it will become,
- accept or reject the expansion,
- adjust the resulting text,
- and only then run.

Historical transcripts, workflow seeds, copied snippets, and recalled command chapters may all seed active input.
They should not inherit the same shorthand-expansion privileges as the live editable field.

## 2) An abbreviation witness is an editing witness, not a runtime rule

An abbreviation witness should describe:
- the trigger text,
- where expansion is allowed,
- whether it is command-position-only or command-scoped,
- what expansion preview will appear,
- where the cursor lands after expansion,
- and whether promotion to a stronger reusable artifact is available.

An abbreviation witness is **not**:
- permission for the runner to re-expand text during launch,
- a hidden alias resolver inside historical replay,
- or a script-time macro mechanism.

## 3) Position and scope matter

One of the nicest things to steal from modern shorthand design is scope.
Not every short form should mean the same thing everywhere.
Useful scope kinds include:
- command-position only,
- anywhere in active input,
- only when following a named command,
- or only inside a visibly selected field family.

That is a much healthier default than one global alias table with too much reach.

## 4) Expansion should be previewable before acceptance

Schell should not force the operator to memorize what every shorthand means.
A good abbreviation surface can show:
- the exact expansion,
- the exact executable/object that expansion points toward when relevant,
- whether the rule came from a local pack, workflow seed, built-in help, or explicit user definition,
- and whether accepting it will introduce suspicious tokens that deserve stronger reveal.

That makes shorthand nicer without turning it into folklore.

## 5) Cursor landing is a real luxury worth stealing

Some expansions are not complete commands.
They are scaffolds.
A shorthand may expand into a larger pattern with a natural next place to type.
So Schell should support explicit cursor landing after expansion.
That can make command authoring feel much faster without deciding the whole workflow/template architecture up front.

## 6) Promotion should be explicit

A healthy ladder looks like this:
- abbreviation for typing comfort,
- promote to snippet/template if field behavior is needed,
- promote to workflow seed if reusable reviewed structure is needed,
- promote to function/tool artifact if runtime behavior deserves a stable named unit.

That is much cleaner than asking aliases to do every job badly.

## 7) Global alias power is the thing to fear

The dangerous class to refuse is shorthand that rewrites too much of the line.
Global aliases, runtime macro rules, and parse-time replacements make it too easy to:
- change a pipe,
- rewrite a hostname,
- reinterpret a path,
- or smuggle surprising meaning into a visually ordinary command.

Schell should keep abbreviation power narrower than that by default.

## 8) Scripts and exported artifacts should stay more explicit than interactive shorthand

A strong rule for Schell is:
**interactive shorthand is not automatically script truth.**

If something deserves to survive export, replay, collaboration, or policy review, it should probably graduate into a clearer artifact:
- explicit text,
- a workflow seed,
- a function-like artifact,
- or another separately named surface.

That keeps transcripts legible and shared automation less folkloric.

## 9) A compact first proving slice

A compact first specimen should show:
1. one command-position abbreviation,
2. one command-scoped abbreviation,
3. one expansion preview card,
4. one cursor-landing expansion,
5. one visible provenance badge for where the shorthand came from,
6. one explicit promote-to-workflow or promote-to-function move,
7. and one refused global/runtime expansion that would have rewritten too much.

That is enough to make Schell feel substantially better than ordinary shell alias culture without freezing the final parser, config format, startup model, or function/workflow boundary.

## 10) Things to refuse for now

Refuse for now:
- runtime alias expansion during launch,
- global aliases that rewrite arbitrary positions by default,
- hidden rc/profile-loaded shorthand packs,
- shorthand that hides executable identity drift,
- and automatic export of local shorthand into shared scripts or workflows.

The right law is:
**steal late expansion and cursor landing, keep shorthand interactive-first, and make exact reviewed launch truth stronger than alias folklore.**
