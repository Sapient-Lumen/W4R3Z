# Compatibility ladders, shadow packs, and migration humility

This surface keeps one boundary explicit:
**a great shell+terminal should make migration merciful — but it should not let imported profiles, prompt hooks, ranking stores, or legacy bridges impersonate native shell truth.**

People do not arrive in a new shell empty-handed.
They arrive with:
- prompt themes,
- profile stacks,
- directory-memory habits,
- per-project tool activation,
- persistent history state,
- and dozens of tiny expectations about what appears when they type.

That means migration is not an afterthought.
It is part of the product.
The right move is not “just support all the old stuff” and it is not “burn the boats.”
The right move is a ladder.

## 1) Schell needs one exact compatibility report card

Before a bridge is enabled, Schell should be able to produce a **compatibility report card**.

A report card should say:
- `bridge_id` — stable bridge identity,
- `source_shell` — bash / zsh / fish / powershell / mixed / unknown,
- `imported_surfaces` — profiles / prompt helpers / env hooks / completions / history store / dir ranking / aliases / functions,
- `payload_posture` — pure_data / generated_data / code / mixed / unknown,
- `startup_posture` — none / explicit / compat_profile / prompt_hook / cwd_hook / unknown,
- `history_posture` — none / local_store / synced / imported_unknown,
- `ranking_posture` — none / dir_memory / command_memory / mixed / unknown,
- `claim_strength` — native_exact / compat_bridge / degraded / guessed,
- `native_replacements_available` — list of nearby native packs or witness models,
- `disable_path` — exact off switch.

This card is not a wizard.
It is a truth surface.

## 2) Migration should happen on a ladder, not with one giant compat switch

A strong Schell migration ladder could be:
1. **observe only** — inventory the legacy setup without running imported code,
2. **shadow compare** — run native and bridged behavior side by side,
3. **one-shot bridge** — apply imported posture to one reviewed command only,
4. **session bridge** — temporary bridge for the current interactive session,
5. **project lease** — reviewed project-scoped bridge,
6. **native pack** — bridge retired.

This makes migration reversible and measurable.
It also keeps bridge authority proportionate.

## 3) Shadow packs are the highest-value migration idea right now

A **shadow pack** lets Schell compare:
- native prompt versus bridged prompt,
- native completion bundle versus imported completion helper,
- native env-overlay card versus old activation hook,
- native directory-memory chooser versus imported ranking bridge.

The operator sees both.
The bridge does not become truth merely because it is familiar.
That is an unusually powerful move because it lets Schell win by clarity instead of by force.

## 4) Prompt luxury should migrate as retired breadcrumbs, not giant profile authority

There are three especially stealable ideas from prompt ecosystems:
- context segments that appear only when relevant,
- retired prompts that shrink after command acceptance,
- and fast startup feedback.

Schell should steal those ideas, but it should preserve a minimal historical breadcrumb for retired prompts:
- cwd basis,
- exit/failure badge,
- maybe time,
- maybe target context.

That gives the operator dense scrollback without erasing what command context actually was.

## 5) Directory memory should become a chooser deck with provenance, not an invisible replacement for `cd`

Directory-memory tools are lovable because they compress repetition.
Schell should absolutely support a **directory-memory deck**.
But the deck should show:
- why a directory is ranked highly,
- whether the source is native history or imported bridge state,
- whether the ranking is recent, decayed, or stale,
- and the exact resolved path before stronger action.

That keeps convenience high without turning frecency into authority.

## 6) Tool and env activation should prefer one-shot rails over prompt-hook mutation

A migration-safe shell should distinguish:
- **preview overlay**,
- **run once with overlay**,
- **lease overlay for this session**,
- **lease overlay for this project**,
- **convert to native pack**.

That is far better than one old pattern where every prompt redraw can mutate the shell.
The one-shot rail is especially important because it gives the operator full utility before long-lived trust exists.

## 7) Interactive convenience state needs its own wallet

Schell should keep an **interactive state wallet** for things like:
- command history,
- directory memory,
- imported ranking stores,
- prompt-local preferences,
- and optional sync posture.

The wallet should say what is:
- local only,
- synced,
- imported,
- script-invisible,
- or fully retired.

That makes migration residue honest.
It also makes native execution truth cleaner.

## 8) What Schell should refuse

### Refuse “import all startup files” as the native story
A bridge may exist.
It should not masquerade as baseline truth.

### Refuse hidden prompt-hook mutation
Prompt redraw is not a secret policy engine.

### Refuse ranked guesses as exact navigation truth
Chooser comfort stays weaker than reviewed target identity.

### Refuse hidden imported history widening
Imported stores need explicit wallet posture.

### Refuse auto-enable migration
Observation, summary, compare, and suggestion are fine.
Enablement still needs review.

## 9) Super-awesome moves worth stealing now

### a) Bridge diff cards
Show exactly what a bridged profile or env helper would add, remove, or override.

### b) Native-vs-bridge split view
Let operators compare prompt, completion, or env outcomes side by side before switching.

### c) Retired-prompt breadcrumbs
Keep just enough old prompt context to preserve forensic readability.

### d) Directory-memory provenance pills
Badge a directory suggestion as native history / imported zoxide-like store / imported shell store / guessed.

### e) One-shot activation button
"Run this command with the project overlay once" is a fantastic migration move.

### f) Bridge debt meter
Count how much of the current session still depends on bridged legacy behavior.
That is a humane way to make progress visible.

## 10) Decision-light proving slice

A compact proof could show:
- one compatibility report card for a legacy shell profile stack,
- one shadow pack comparing native and bridged prompt behavior,
- one retired-prompt breadcrumb specimen,
- one directory-memory deck with provenance badge,
- one one-shot env/tool activation rail,
- one interactive-state wallet showing local/imported/synced posture,
- and one refusal case where a bridge tries to claim native truth without enough witness.

That is enough to make Schell feel dramatically better to adopt without freezing one final importer, ranking engine, profile ABI, or migration runtime.
