- `80-terminal/source-witnesses-import-cards-and-scope-mutation-humility.md` — load-form cards, scope badges, path/source notes, export-posture chips, reversible overlay receipts, and the rule that helper loading stays weaker than exact reviewed spend.
- `80-terminal/option-witnesses-strictness-scopes-and-startup-mode-humility.md` — inherited baseline cards, startup-influence notes, strictness/version chips, local-scope badges, restore receipts, and the rule that shell mode stays weaker than exact reviewed spend.
- `80-terminal/substitution-witnesses-capture-residue-and-helper-sidecar-humility.md` — typed substitution tokens, helper-footing badges, capture-form chips, trim/split residue labels, sidecar route cards, and the rule that capture help stays weaker than exact reviewed spend.
- `redirection-witnesses-heredoc-cards-and-fd-lease-humility.md`
- `history-substitution-witnesses-event-designators-and-reedit-humility.md`
- `expansion-witnesses-glob-reveals-and-match-residue-humility.md`
- `abbreviations-alias-reveals-and-expansion-humility.md`
- `transient-prompt-final-rendering-and-history-chip-humility.md`
- `edit-journals-kill-rings-and-paste-history-humility.md`
- `preview-settlements-miss-ledgers-and-outcome-gap-humility.md`
# Terminal surfaces
- `redirection-witnesses-heredoc-cards-and-fd-lease-humility.md`
- `history-substitution-witnesses-event-designators-and-reedit-humility.md`
- `expansion-witnesses-glob-reveals-and-match-residue-humility.md`
- `autocd-cdpath-reveals-and-navigation-truth-humility.md`
- `abbreviations-alias-reveals-and-expansion-humility.md`
- `transient-prompt-final-rendering-and-history-chip-humility.md`
- `paste-filters-quote-at-prompt-and-control-code-humility.md`
- `fold-receipts-summary-headers-and-reveal-debt-humility.md`
- `capability-witnesses-degradation-receipts-and-hop-lineage-humility.md`
- `prompt-regions-continuation-cards-and-multiline-input-humility.md`
- `parse-lenses-diagnostic-rails-and-packet-gutters-humility.md`
- `anchor-death-cards-cursor-expiry-and-reset-scope-humility.md`
- `change-digest-cards-what-changed-since-and-unread-humility.md`
- `since-cut-supplements-snapshot-plus-change-and-refresh-humility.md`
- `snapshot-receipts-cut-watermarks-and-partial-capture-humility.md`
- `quiescence-strips-calm-windows-and-silence-is-not-proof-humility.md`
- `stability-strips-generation-lamps-and-warming-truth-humility.md`
- `readiness-strips-prompt-caught-and-integration-truth-humility.md`
- `placement-receipts-requested-lanes-and-realized-landings-humility.md`
- `arrival-strips-start-causes-and-summon-humility.md`
- `activation-receipts-baton-spend-and-denial-residue-humility.md`
- `activation-batons-armed-rails-and-focus-second-humility.md`
- `launch-sheets-inherit-diffs-and-fresh-instead-humility.md`
- `witness-packets-carried-truth-and-claim-handoff-humility.md`
- `footing-strips-action-floors-and-strongest-next-verb-humility.md`
- `drift-cards-then-now-basis-and-refresh-humility.md`
- `chapter-inspectors-hover-why-and-rerun-humility.md`
- `semantic-marks-command-chapters-and-attach-humility.md`
- `outcome-witnesses-exit-families-and-pipefail-humility.md`
- `environment-witnesses-layer-stacks-and-mutation-timing-humility.md`
- `cwd-witnesses-logical-physical-and-provider-humility.md`
- `command-identity-witnesses-shadow-stacks-and-exact-invoker-humility.md`
- `subject-witnesses-target-stacks-and-override-humility.md`
- `broker-witnesses-presence-leases-and-local-mediator-humility.md`
- `return-ticket-projections-title-badges-and-click-humility.md`
- `landing-zone-witnesses-drop-targets-and-object-route-humility.md`
- `paste-witnesses-trailing-newline-and-submit-separation-humility.md`
- `submit-witnesses-rearm-stamps-and-double-spend-humility.md`
- `redraw-witnesses-live-rows-and-freeze-before-act-humility.md`
- `timeline-witnesses-mixed-event-rows-and-now-humility.md`
- `change-cursor-witnesses-caught-up-through-and-reset-humility.md`
- `revivability-grades-resume-honesty-and-stale-truth-humility.md`
- `soft-state-ladders-remembered-saved-restored-and-provisional-humility.md`
- `provenance-first-luxury-stack.md`
- `parallel-repo-lanes-adoption-gates-and-live-checkout-humility.md`
- `baseline-cards-safe-sets-and-silent-approval-humility.md`
- `autonomy-postures-permission-dials-and-stop-humility.md`
- `wake-tickets-return-paths-and-acknowledgement-humility.md`
- `provider-sidecars-task-mirrors-and-completion-humility.md`
- `draft-shelves-soft-commit-and-insert-truth-humility.md`

These docs keep the custom terminal in research mode.
They name candidate operator moves and protocol pressures without freezing the final shell↔terminal contract.

Read next:

- `option-witnesses-strictness-scopes-and-startup-mode-humility.md`

- `substitution-witnesses-capture-residue-and-helper-sidecar-humility.md`

- `redirection-witnesses-heredoc-cards-and-fd-lease-humility.md`
- `history-substitution-witnesses-event-designators-and-reedit-humility.md`
- `expansion-witnesses-glob-reveals-and-match-residue-humility.md`
- `autocd-cdpath-reveals-and-navigation-truth-humility.md`

- `abbreviations-alias-reveals-and-expansion-humility.md`

- `transient-prompt-final-rendering-and-history-chip-humility.md`

- `paste-filters-quote-at-prompt-and-control-code-humility.md`

- `edit-journals-kill-rings-and-paste-history-humility.md`

- `preview-settlements-miss-ledgers-and-outcome-gap-humility.md`

- `command-decks-marks-annotations-and-discovery-honesty.md`

- `abandon-receipts-buried-sessions-and-prompt-aware-close-humility.md`

- `capability-witnesses-degradation-receipts-and-hop-lineage-humility.md`

- `prompt-regions-continuation-cards-and-multiline-input-humility.md`

- `parse-lenses-diagnostic-rails-and-packet-gutters-humility.md`

- `change-digest-cards-what-changed-since-and-unread-humility.md`

- `snapshot-receipts-cut-watermarks-and-partial-capture-humility.md`

- `quiescence-strips-calm-windows-and-silence-is-not-proof-humility.md`

- `stability-strips-generation-lamps-and-warming-truth-humility.md`

- `readiness-strips-prompt-caught-and-integration-truth-humility.md`

- `placement-receipts-requested-lanes-and-realized-landings-humility.md`

- `arrival-strips-start-causes-and-summon-humility.md`

- `activation-receipts-baton-spend-and-denial-residue-humility.md`

- `activation-batons-armed-rails-and-focus-second-humility.md`

- `witness-packets-carried-truth-and-claim-handoff-humility.md`

- `footing-strips-action-floors-and-strongest-next-verb-humility.md`

- `drift-cards-then-now-basis-and-refresh-humility.md`

- `chapter-inspectors-hover-why-and-rerun-humility.md`

- `semantic-marks-command-chapters-and-attach-humility.md`

- `outcome-witnesses-exit-families-and-pipefail-humility.md`

- `environment-witnesses-layer-stacks-and-mutation-timing-humility.md`

- `cwd-witnesses-logical-physical-and-provider-humility.md`

- `command-identity-witnesses-shadow-stacks-and-exact-invoker-humility.md`

- `subject-witnesses-target-stacks-and-override-humility.md`

- `broker-witnesses-presence-leases-and-local-mediator-humility.md`

- `auth-handoff-witnesses-browser-returns-and-callback-humility.md`

- `landing-zone-witnesses-drop-targets-and-object-route-humility.md`
- `paste-witnesses-trailing-newline-and-submit-separation-humility.md`
- `submit-witnesses-rearm-stamps-and-double-spend-humility.md`
- `redraw-witnesses-live-rows-and-freeze-before-act-humility.md`
- `timeline-witnesses-mixed-event-rows-and-now-humility.md`
- `change-cursor-witnesses-caught-up-through-and-reset-humility.md`
- `revivability-grades-resume-honesty-and-stale-truth-humility.md`
- `soft-state-ladders-remembered-saved-restored-and-provisional-humility.md`
- `provenance-first-luxury-stack.md`
- `parallel-repo-lanes-adoption-gates-and-live-checkout-humility.md`
- `baseline-cards-safe-sets-and-silent-approval-humility.md`
- `autonomy-postures-permission-dials-and-stop-humility.md`
- `wake-tickets-return-paths-and-acknowledgement-humility.md`
- `provider-sidecars-task-mirrors-and-completion-humility.md`
- `pinned-summons-floating-fronts-and-shared-seed-humility.md`
- `text-shape-witnesses-visual-certainty-and-commit-humility.md`
- `secure-input-witnesses-sensitive-entry-and-keywatcher-humility.md`
- `terminal-identity-claims-terminfo-drift-and-version-humility.md`
- `file-transfer-bridges-landing-zones-and-archive-humility.md`
- `clipboard-bridges-read-write-asymmetry-and-export-humility.md`
- `mode-leases-save-restore-and-stranded-toggle-humility.md`
- `terminal-query-witnesses-reply-lanes-and-introspection-humility.md`
- `semantic-provenance-grades-nonce-rails-and-spoof-humility.md`
- `semantic-fixtures-loss-harness-and-specimen-humility.md`
- `semantic-transport-profiles-projection-loss-and-portable-humility.md`
- `recall-half-lives-rerun-leases-and-aging-humility.md`
- `replay-leases-scope-chips-and-quiet-authority-humility.md`
- `quarantine-ribbons-endorsement-receipts-and-imported-command-humility.md`
- `memory-gravity-hints-sticky-exclusions-and-promotion-budgets-humility.md`
- `memory-residency-lanes-sync-boundaries-and-publication-humility.md`
- `peer-scoped-recall-directory-memory-and-authority-drift-humility.md`
- `observe-lanes-attach-rails-control-panes-and-sideband-honesty.md`
- `resync-witnesses-semantic-epochs-and-baseline-reassertion-humility.md`
- `semantic-command-frames-sidecars-stale-fences-and-provisional-truth.md`
- `title-witnesses-display-labels-and-override-humility.md`
- `drop-witnesses-file-offers-and-path-translation-humility.md`
- `bracketed-paste-witnesses-multiline-grants-and-clipboard-query-humility.md`
- `signal-witnesses-interrupt-ladders-and-hangup-humility.md`
- `notification-witnesses-bell-routing-and-click-humility.md`
- `font-witnesses-glyph-fallback-and-ligature-humility.md`
- `editor-bridge-witnesses-draft-roundtrips-and-autorun-humility.md`
- `geometry-witnesses-grid-pixels-and-reflow-humility.md`
- `composition-witnesses-preedit-clauses-and-text-commit-humility.md`
- `fullscreen-witnesses-alt-screen-and-copy-mode-humility.md`
- `pointer-witnesses-mouse-reporting-and-prompt-click-humility.md`
- `key-transport-witnesses-negotiated-encodings-and-fallback-humility.md`
- `prompt-witnesses-segment-provenance-and-async-humility.md`
- `keymap-witnesses-chord-discoverability-and-editor-humility.md`
- `completion-witnesses-candidate-sources-and-insertion-humility.md`
- `history-lessons-stealable-bundles-and-luxury-vetoes.md`
- `integration-witnesses-semantic-negotiation-and-hop-downgrade-humility.md`
- `../20-language/parse-floors-known-externs-and-evaluation-humility.md`
- `shell-terminal-co-design-for-slopos.md`
- `no-regret-shell-terminal-moves.md`
- `stealable-luxury-bundles-and-phase-zero-proof-humility.md`
- `trusted-command-blocks-and-action-gates.md`
- `shell-integration-marks-startup-humility-and-command-block-honesty.md`
- `config-ground-cards-startup-footing-and-overlay-truth-humility.md`
- `active-input-leases-and-scoped-work-lanes.md`
- `minimal-semantic-protocol.md`
- `semantic-terminal-moves.md`
- `review-flow-prototype.md`
- `superawesome-terminal-moves.md`
- `rust-terminal-stack-notes.md`
- `transcript-truth-and-zone-persistence.md`
- `denial-cards-and-rationale.md`
- `background-shelf-prototype.md`
- `authority-wallets-diff-cards-and-revocation-hints.md`
- `automation-witnesses-seeds-wallets-and-learnmode-humility.md`
- `resurrection-lockers-clean-starts-and-runtime-preservation-humility.md`
- `authorship-badges-basis-packets-and-cas-review.md`
- `reentry-cues-session-restoration-and-historical-honesty.md`
- `attention-hints-finish-notices-and-interruption-budgets.md`
- `assistive-witnesses-accessibility-lanes-and-automation-humility.md`
- `secret-witnesses-reveal-ladders-and-masking-humility.md`
- `chrome-witnesses-status-egress-and-ambient-badge-humility.md`
- `ingress-packets-paste-drop-and-clipboard-honesty.md`
- `clipboard-witnesses-copy-offers-and-egress-honesty.md`
- `selection-packets-primary-targets-and-action-ladders.md`
- `view-trees-pane-leases-and-mux-honesty.md`
- `output-capsules-stream-braid-witnesses-and-ordering-humility.md`
- `pager-witnesses-alt-screen-and-search-hit-humility.md`
- `intent-packets-plumb-routes-and-exact-open-bridges.md`
- `progress-scopes-cancellation-and-drain-honesty.md`
- `detached-work-witnesses-task-shelves-and-durable-status-humility.md`
- `execution-grounds-env-capsules-and-activation-witnesses.md`
- `trusted-chrome-secure-review-lanes-and-anti-spoof-separation.md`
- `remote-hops-peer-witnesses-and-attach-honesty.md`
- `failure-packets-repair-cards-and-exact-handoff-bundles.md`
- `command-chapters-journal-truth-and-source-labeled-recall.md`
- `workflow-seeds-parameter-cards-and-runbook-honesty.md`
- `chapterbooks-narrative-cells-and-state-order-humility.md`
- `slot-linked-edits-synced-cursors-and-parameter-fill-humility.md`
- `argv-witnesses-exact-reveal-and-escape-humility.md`
- `tabstop-witnesses-mirrored-fields-and-transform-humility.md`
- `chooser-witnesses-ranked-recall-and-preview-humility.md`
- `abbreviation-witnesses-late-expansion-and-alias-humility.md`
- `assistant-lane-witnesses-separate-modes-and-approval-humility.md`
- `tool-catalog-witnesses-resource-attachments-and-elicitation-humility.md`
- `launch-kits-quick-summon-and-cockpit-honesty.md`
- `command-decks-marks-annotations-and-discovery-honesty.md`
- `query-witnesses-smart-decks-and-saved-view-humility.md`
- `watch-witnesses-live-inspectors-and-subscription-humility.md`
- `object-cards-exact-reveal-and-safe-open-honesty.md`
- `transcript-cards-replay-bundles-and-redaction-honesty.md`
- `shell-known-packets-local-luxuries-and-portable-humility.md`
- `enrichment-packets-freshness-budgets-and-speculation-refusal.md`
- `prompt-budgets-idle-lanes-and-cheap-delight.md`
- `handoff-ladders-observation-truth-and-completion-humility.md`
- `repo-accelerators-trust-leases-and-hook-quarantine.md`
- `hyperlink-witnesses-unfurl-gates-and-hover-humility.md`
- `inline-media-witnesses-render-lanes-and-preview-residue-humility.md`
- `detector-witnesses-quick-fix-rails-and-action-humility.md`
- `resolver-witnesses-remediation-offers-and-install-humility.md`
- `service-witnesses-port-offers-and-exposure-humility.md`
- `tty-witnesses-process-group-lanes-and-promotion-humility.md`
- `scheduled-work-witnesses-window-offers-and-replay-debt-humility.md`
- `forget-rails-retention-lanes-and-history-residue-humility.md`
- `guest-witnesses-share-ladders-and-codrive-humility.md`
- `unicode-witnesses-bidi-gates-and-confusable-humility.md`
- `share-witnesses-replay-capsules-and-publication-humility.md`
- `broadcast-witnesses-target-sets-and-blast-radius-humility.md`
- `patch-witnesses-dirty-isolation-and-undo-humility.md`

- `nondeterminism-witnesses-seed-lanes-and-replay-humility.md`

- `borrowed-screen-leases-shell-reentry-and-prompt-reclaim-humility.md`

- `auth-handoff-witnesses-browser-returns-and-callback-humility.md`


- `fresh-intent-witnesses-consumed-gestures-and-replay-humility.md`

- `review-watermarks-first-unseen-and-seen-state-humility.md`
