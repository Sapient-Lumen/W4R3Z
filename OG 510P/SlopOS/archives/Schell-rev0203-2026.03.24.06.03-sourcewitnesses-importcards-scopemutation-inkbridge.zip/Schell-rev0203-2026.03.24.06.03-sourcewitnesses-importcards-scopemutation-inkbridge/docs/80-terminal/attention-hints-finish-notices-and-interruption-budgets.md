# Attention hints, finish notices, and interruption budgets

This surface records a new no-regret candidate cluster for Schell:
**make the shell+terminal much better at getting the operator's attention while refusing to treat attention as completion proof, acknowledgement, or authority.**

The design pressure comes from three directions:

- SlopOS keeps strict boundaries between attention hints, durable truth, request identity, and current live state.
- DelayBasin keeps arguing that suppression, blocked output, and explicit non-movement should stay public rather than dissolving into vibe.
- Current terminals and platforms show that bounded finish notices, prompt-safe interaction, and policy-owned interruption can feel excellent without requiring a giant new subsystem.

## 1) Exact attention events should come from shell truth

Schell should not guess “something interesting probably happened” from scrollback alone.
The shell should be able to emit exact attention events bound to exact objects.

Candidate event family:

- `review-needed`
- `denied`
- `hold-card-raised`
- `command-finished`
- `background-drift`
- `receipt-ready`

Each event should point at one exact lane object.
That makes attention cue actions much safer: the cue can jump to the exact review card, receipt, or hold card rather than to a vague region of scrollback.

## 2) A tiny attention ladder is enough to start

The first cut should stay compact.

Candidate ladder:

- `quiet` — never interrupt; badge or residue only,
- `default` — visible in-lane,
- `noteworthy` — eligible for stronger surfacing under local policy,
- `urgent-hint` — requests stronger interruption but still remains policy-gated and non-authoritative.

Important posture:

- `urgent-hint` is not a lease,
- it does not grant focus-steering authority,
- and it does not bypass review just because it looked important.

## 3) “Command finished” is an attention hint, not outcome truth

A long-running command finishing is a perfect example of why this surface matters.
The operator often does want to know.
But the terminal should say only what it actually knows.

A bounded finish notice can honestly mean:

- the shell marked a command as finished,
- this command belonged to a named lane,
- it exceeded a threshold or matched a watch condition,
- and the terminal surfaced a cue according to current focus and interruption policy.

It should not silently mean:

- the result was good,
- the user saw the output,
- the next step is approved,
- or the operator has now acknowledged completion.

## 4) Cue actions should route back to exact objects

A cue click should usually do one of these:

- jump to the exact receipt,
- jump to the exact review card,
- jump to the exact hold card,
- or focus the exact lane object that raised the cue.

It should usually **not** do this directly:

- rerun work,
- widen authority,
- dismiss safety review,
- or attach to a merely historical object.

If a stronger action is really wanted, the cue can be the fast path back to the object that still carries the normal authorship/basis review rules.

## 5) Suppression and downgrade should be visible

Quiet mode, focus filters, or spent interruption budgets should not force Schell to lie by omission.
If a cue was requested but not surfaced strongly, that fact should remain available.

Candidate residue states:

- `requested-not-shown`
- `downgraded`
- `expired`
- `dismissed`
- `jumped-to-object`

This is a DelayBasin-style honesty move.
A suppressed cue is not fake nothingness.
It is real state that the operator may need later.

## 6) Attention residue should be durable but modest

Schell does not need a giant notification center to learn from this.
A first residue shelf can stay tiny:

- timestamp,
- originating lane,
- event kind,
- attention level requested,
- attention level actually used,
- exact object reference,
- and current residue state.

That is enough to make quiet mode and over-budget interruptions auditable without turning attention into a second history empire.

## 7) Transcript truth still matters here too

The text transcript should be able to preserve the important part of an attention event:

- what event was raised,
- what exact object it referred to,
- and what surface the operator should inspect next.

The transcript should not claim more than that.
It should not imply that the user saw the cue, clicked it, or approved anything merely because the cue was emitted.

## 8) No-regret first cut

A first specimen set could stay small:

1. one long-running command finish notice,
2. one denial cue that jumps to a hold card,
3. one background-drift cue,
4. one quiet-mode downgrade example,
5. and one residue shelf row showing what was requested versus what was surfaced.

That is enough to learn a lot without freezing a notification backend, a durable inbox, a cross-device sync story, or a full policy algebra.
