# Chooser witnesses, ranked recall, and preview humility

This surface exists to keep one very stealable luxury bundle honest:
**Schell should absolutely steal interactive chooser magic — fuzzy recall, ranked candidates, directory jump lists, quick-pick menus, and preview panes — but it must not let hidden ranking, hidden preview work, or implicit accept actions become a second authority plane.**

Terminal culture already knows how delightful choosers can be.
The problem is that most chooser stacks blur together:
- what generated the candidate,
- why it ranked highly,
- what the preview did,
- and what pressing Enter actually means.

Schell can make that whole seam much more humane without freezing the final ranking engine, fuzzy matcher, preview protocol, or menu toolkit.

## 1) A chooser belongs beside active input, not above shell truth

Chooser surfaces should help the operator:
- find prior command chapters,
- find likely directories,
- recall workflow seeds,
- inspect visible services or object cards,
- and route selections into the next action.

But the chooser should stay weaker than shell truth.
It is a selection aid, not the new source of authority.
The exact chosen command, cwd target, object handle, or open action still needs its own explicit lane.

## 2) A chooser witness should name the candidate source

Every chooser should say where candidates came from.
Useful source families include:
- chapter history,
- directory recall,
- workflow seeds,
- repo accelerator suggestions,
- visible object cards,
- service witnesses,
- file/object search,
- and explicit fresh queries.

If the operator cannot tell whether a candidate is historical, local, helper-generated, or freshly queried, the chooser is probably too magical already.

## 3) Ranking posture should stay revealable

Ranking is one of the nicest luxuries to steal.
Recency, frequency, success history, cwd-locality, and explicit query score can all make a chooser feel brilliant.

But ranking should be revealable.
A chooser witness should be able to say at least:
- unranked,
- recency-ranked,
- frecency-ranked,
- success-biased,
- source-order,
- or explicit-query-score.

Better still, the operator should be able to ask:
- why this result is first,
- what else nearly won,
- and whether the ordering is advisory or decisive.

## 4) Preview posture needs its own vocabulary

Preview is where chooser luxury gets dangerous.
A preview might be:
- none,
- metadata-only,
- inert local render,
- helper summary,
- subprocess preview,
- remote fetch,
- or risky content preview.

Those are not equivalent.
They should not all show up under one flattering “preview available” glow.
A metadata-only preview should feel cheap and weak.
A subprocess preview should wear a stronger badge.
A risky preview should often downgrade to metadata or require an explicit reveal/open step.

## 5) Accept lanes should stay split

A very strong Schell chooser should support different accept meanings:
- **insert** into active input,
- **reveal** the exact candidate,
- **stage** a follow-up action,
- **open**,
- **safe-open**,
- **cd**,
- **rerun after review**,
- or **copy exact identity**.

The same Enter key should not have to mean all of those at once.
Even if the UI offers a default accept action, the witness should keep that action visible.

## 6) History choosers should prefer edit and reveal over blind rerun

History choosers are wonderful when they stop being string archaeology.
They should absolutely support:
- filtering by directory,
- filtering by success/failure,
- session-local versus global recall,
- and richer context like duration or peer identity.

But a history hit is still not current authority.
Good defaults are:
- insert the command,
- reveal the full historical chapter,
- or ask for rerun under current-basis review.

Blind replay should remain the stronger lane.

## 7) Directory choosers should reveal exact target and ranking reason

Directory choosers can feel magical very quickly.
That is useful until “magic” becomes hidden cwd policy.
So a directory chooser should preferably expose:
- exact target path/handle identity,
- ranking posture or score,
- match fragments,
- and whether acceptance will change cwd immediately or merely stage the change.

A nice operator move might be:
- first hit inserts `cd` into active input,
- a stronger gesture commits the cwd move,
- and a reveal gesture shows why that directory won.

## 8) Preview-on-focus should be weaker than preview-on-demand

Many chooser systems automatically preview the focused item.
That can be fine for cheap metadata.
It is much riskier for richer or content-bearing previews.

So Schell should probably distinguish:
- **focus metadata**,
- **toggle richer preview**,
- **explicit inspect**,
- and **open/safe-open**.

That gives the operator the delight of fluid navigation without pretending that every cursor movement authorizes more work.

## 9) A chooser witness is not a hidden oracle

Chooser witnesses should not quietly become:
- a handler inventory API,
- a complete hidden-state catalog,
- a remembered-grant browser,
- a raw-recents authority surface,
- or a secret list of every “best” next move.

If a chooser depends on privileged inventory or helper-owned recall, that should stay visibly sourced and visibly weaker than exact object or workflow truth.

## 10) A compact first proving slice

A compact first specimen should show:
1. one history chooser with cwd and exit filters,
2. one directory chooser with visible ranking posture,
3. one preview toggle that distinguishes metadata from richer preview,
4. one split accept ladder between insert, reveal, and act,
5. one refused risky preview that downgrades to metadata,
6. and one visible explanation of why the current top hit ranked first.

That is enough to make Schell feel significantly more advanced than bash while still keeping final ranking, preview, and palette architecture open.

## 11) Things to refuse for now

Refuse for now:
- auto-run the top result on mere selection,
- hidden single-winner policies when ambiguity matters,
- subprocess or networked preview without visible posture,
- risky content preview on focus alone,
- and recents/history rows that masquerade as durable authority.

The right law is:
**steal chooser delight, keep ranking revealable, keep previews honest, and keep acceptance visibly weaker than automatic execution.**
