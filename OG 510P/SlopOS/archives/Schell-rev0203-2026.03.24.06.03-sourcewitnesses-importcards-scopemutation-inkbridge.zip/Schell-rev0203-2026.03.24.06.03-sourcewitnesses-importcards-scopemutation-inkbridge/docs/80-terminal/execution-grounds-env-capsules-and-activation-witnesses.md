# Execution grounds, env capsules, and activation witnesses

This surface records a new no-regret candidate cluster for Schell:
**make cwd root, environment capsule, activation state, and namespace/view posture explicit shell-owned execution grounds, while letting the terminal render them richly without letting prompt-time magic become hidden authority or silent rerun drift.**

The design pressure comes from three directions:

- SlopOS already refuses ambient env/cwd/startup-profile inheritance and keeps execution grounds explicit by omission.
- DelayBasin keeps demanding compact public witnesses for any state that will matter later.
- Current terminals and shells keep proving how much better navigation and activation feel once cwd/context is explicit.

## 1) The shell needs one exact ground object

A good first object is **execution ground packet**.

An execution ground packet is a compact shell-owned descriptor for the current command ground.
It is not a final workspace model.
It is not a package-manager treaty.
It is not authority by itself.
It is the thing the terminal can point at when it says “this is the ground this command is actually standing on.”

A v0 packet probably needs:
- `ground_ref` — exact ground identity,
- `cwd_ref` — exact cwd / root witness,
- `env_ref` — exact environment-capsule digest or packet,
- `activation_ref` — optional toolchain / overlay / dev-shell / profile witness,
- `namespace_ref` — optional view or imported-root witness,
- `source_family` — default / manual / imported / workflow / restored,
- `authorship_ref` — who established the ground when that matters,
- `drift_flags` — cwd drift / env drift / activation drift / namespace drift,
- `replay_posture` — exact / compare-and-set / inspect-only,
- `notes_ref` — optional explanatory witness or hold card.

That is enough to make execution ground truth real without freezing a giant compatibility model.

## 2) Prompt-time hooks should not be the truth surface

Legacy shells and tool managers keep using prompt-time hooks to update environment and cwd-adjacent behavior.
That is useful, but it is a poor truth surface.

Schell should therefore prefer:
- prompt-time hooks as *one possible source family*,
- explicit activation witnesses,
- explicit changed-ground diffs,
- and exact transcript-visible transitions.

What Schell should refuse is the old story where:
- the prompt changed color,
- PATH changed somewhere,
- a banner flashed once,
- and the operator is expected to infer the current execution ground from vibes.

## 3) Cwd/view root should be exact, not merely helpful

The terminal gets much better when cwd is known.
But Schell should keep multiple truths separate:
- exact current cwd/view root,
- historical per-command cwd witness,
- selected-text context witness,
- and guessed nearby path context.

These are all valuable.
They are not the same.

This directly improves:
- click-open,
- semantic history,
- path insertion,
- workflow seeds,
- split/tab inheritance,
- and restored session landings.

## 4) Activation needs its own witness family

A useful early family could be **activation witness**.

An activation witness says:
- what activation entered or exited,
- what files/digests or external source it came from when known,
- what changed in the ground,
- whether the activation is still live,
- and whether a reviewed action still matches the ground it assumed.

This is much better than trying to infer everything from:
- PATH text,
- shell banners,
- rc/profile side effects,
- or a toolchain name embedded in the prompt.

## 5) Rerun should care about ground drift

Schell already cares about exact mutable basis.
Execution grounds are part of that story.

A very strong no-regret rule is:
- if the current ground still matches the reviewed ground, strong rerun may stay available,
- if it drifted in a meaningful way, downgrade to compare-and-set review or inspect-only,
- and say exactly what drifted.

Good drift categories are probably enough for v0:
- cwd/root drift,
- env digest drift,
- activation witness drift,
- namespace/view drift,
- unknown live ground.

## 6) The terminal can become much more delightful here

Once ground packets exist, Schell can do genuinely excellent things:
- a tiny **ground strip** beside the active lane,
- one-click “why did PATH change?” diff cards,
- exact “entered dev-shell” and “left dev-shell” cards,
- a current-ground palette section,
- compare-ground-on-rerun,
- restored historical ground badges,
- and readonly ground inspectors attached to receipts or replay panes.

This is a strong source of “super awesome” without forcing the final dev-environment architecture.

## 7) Ground packets should compose with earlier surfaces

This seam should not replace earlier work.
It should compose with it:
- basis packets can include ground refs,
- reentry cards can say a historical object was created under a different ground,
- selection packets can include cwd/ground context,
- intent packets can route through exact current ground or historical ground,
- progress scopes can carry the ground they are running under,
- and output capsules can preserve the ground witness relevant to their command.

That is how the shell+terminal keeps getting smarter without becoming blurrier.

## 8) Transcript truth needs only the important ground transitions

The transcript does not need every temporary export or internal cache tick.
It does need:
- ground established,
- activation entered,
- activation exited,
- ground drift detected,
- strong rerun downgraded due to drift,
- and exact command execution under a named ground.

That is the portable minimum.

## 9) No-regret first cut

A first specimen set could stay small:

1. one command with an exact cwd witness and ground strip,
2. one explicit activation enter card with a compact env diff,
3. one rerun that succeeds only because the ground still matches,
4. one rerun that downgrades because cwd or env digest drifted,
5. one restored command block that keeps a historical-ground badge,
6. one click-open path action that uses exact per-command cwd rather than generic workspace search,
7. and one transcript slice showing ground transitions plus one compare-and-set refusal.

That is enough to learn a great deal without freezing the final environment capsule format, dev-shell integration story, or namespace algebra.
