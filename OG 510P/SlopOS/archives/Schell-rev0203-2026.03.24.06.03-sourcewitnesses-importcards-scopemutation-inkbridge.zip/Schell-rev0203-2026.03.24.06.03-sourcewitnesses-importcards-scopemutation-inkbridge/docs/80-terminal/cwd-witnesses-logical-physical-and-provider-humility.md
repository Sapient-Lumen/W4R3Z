# CWD witnesses, logical/physical paths, and provider humility

This surface narrows another old shell seam that still causes accidental confidence:
**the current directory is rarely just one string.**
Schell should be excellent at answering what ground a relative path or bare location-sensitive command will actually stand on right now, without forcing operators to choose one universal canonicalization law too early.

That seam matters even more because SlopOS is still in design phase.
If Schell gets it wrong early, prompt paths, pretty breadcrumbs, symlink-preserved labels, provider-style pseudo-paths, remote translations, and restored working-directory residue quietly become a second hidden targeting plane.

## 1) Modern shells already show that “cwd” is plural

Current shell docs keep rediscovering the same truth:
- Bash distinguishes **logical** and **physical** directory handling through `cd -L/-P` and `pwd -L/-P`.
- fish explicitly distinguishes **logical string normalization** from **physical resolution** with `path normalize` versus `path resolve`.
- Nushell recently moved `$env.PWD` and `pwd` toward **logical path** behavior by default, while adding explicit `--physical` posture.
- PowerShell treats locations as **provider-backed drives**, keeps a current location per drive, and also distinguishes runspace-local location from the host process directory.

The design lesson is not “pick one universal cwd law now”.
It is smaller.
A shell+terminal should become excellent at showing the exact **cwd witness family** that a pending relative operation will use.

## 2) One compact cwd witness family is enough

Schell does not need one grand final path ontology to improve this seam.
A compact **cwd witness** family could keep fields such as:
- `entered_path` — the exact path token or route the operator used,
- `display_path` — the humane label currently shown in prompt or chrome,
- `logical_pwd` — the shell’s logical current directory, preserving symlink-intent where that still matters,
- `physical_pwd` — the canonicalized physical location when resolvable,
- `ground_kind` — filesystem / provider drive / virtual namespace / remote-translated / unknown,
- `provider_or_drive` — filesystem, registry, env, alias, bucket, remote view, or other route family,
- `source_lane` — typed `cd`, `CDPATH`, project launch, restored session, imported handoff, replay, or unknown,
- `divergence_posture` — same / logical-vs-physical diverged / provider-only / unresolved / translated,
- `basis_ref` — exact witness object explaining why this location claim currently stands,
- `reveal_target` — the card that explains what relative paths, opens, and receipts will bind against.

That is enough to make directory truth dramatically clearer without freezing one final namespace model, portal treaty, or cross-platform path canonicalizer.

## 3) The shell should be great at the parts older shells blur

Classic shell UX still leaves crucial location facts annoyingly ambient:
- whether the prompt is showing a logical symlink-preserving path or a physical canonical path,
- whether `..` will traverse lexical parents or physical parents,
- whether the “current directory” is even a filesystem object versus a provider-style pseudo-drive,
- whether a restored location is still exact current footing or merely a historical breadcrumb,
- whether a remote, provider, or translated path can really support local reveal/open/edit actions,
- and whether a pending relative command will bind against the same ground the prompt chip seems to imply.

Schell can do much better with small luxuries.

### a) Dual-path chip when it matters
Show one compact cwd strip that stays small when logical and physical agree, but blooms into two chips when they diverge.
For example: `~/repo/link/worktree` versus `/srv/repos/physical/worktree`.

### b) Ground-kind badge
Every cwd chip should answer “what kind of place is this?” with a tiny badge such as `fs`, `registry`, `env`, `remote`, or `translated`.
That keeps provider and pseudo-path magic from impersonating ordinary files.

### c) Relative-bind preview
Before a reviewed action spends, Schell can cheaply preview whether `./foo`, `../bar`, or a relative reveal/open will bind against logical path, physical path, or provider-local semantics.

### d) Divergence card
If logical and physical ground differ, or if a provider-style location cannot support an action the operator is reaching for, show a small divergence card rather than hoping the prompt text was enough.

### e) Receipt-level path pins
A reviewed execution receipt should preserve both the display path the operator saw and the stronger location witness the shell actually used.
That keeps history and replay from laundering path ambiguity into fake exactness.

## 4) Great ideas worth stealing now

### Stack, not scalar
Do not compress current location into one flattering prompt segment.
Show the winning display path and the stronger location witnesses behind it.

### Logical and physical can both be right
Preserved user intent and canonical object identity are both useful.
Schell should reveal both when needed instead of making one silently overwrite the other.

### Provider posture should stay visible
If the current location is not a normal filesystem directory, that fact should be cheap to see before relative-path comfort turns into wrong assumptions.

### Relative actions deserve explicit grounding
Open, reveal, create, attach, and rerun actions that depend on cwd should be able to cite which location witness they used.

### Translation stays weaker than identity
Path translation can be wonderful, but a translated path should not impersonate exact same-object truth across provider, remote, or namespace boundaries.

## 5) The strongest lesson from SlopOS and the companion cubes

SlopOS keeps imported carriers and current authority separate rather than ambient.
ViewFS keeps basis, applied state, and changed-object truth explicit rather than reducing everything to a display path.
Steward benefits from exact retry/repair footing instead of one vague “you are here” story.
Helm keeps change cursors, reset cards, and last-seen anchors honest when the basis moves.

That combination points Schell at one small rule:
**the shell should treat current location as a witness family rather than letting one cozy prompt path or breadcrumb impersonate exact current working ground.**

## 6) What Schell should refuse now

Schell should refuse:
- one pretty prompt path counting as full cwd truth,
- one canonical physical path counting as the only user-meaningful path,
- one symlink-preserved display path counting as proof of exact object identity,
- provider-style locations counting as ordinary filesystem directories,
- translated remote or namespace paths counting as same-object truth by default,
- and restored location residue counting as fresh live footing.

## 7) The no-regret move

The best move right now is not to freeze one universal canonical path law.
It is to pin one smaller rule:
**Schell should treat cwd as a family of location witnesses with visible logical-versus-physical posture, provider kind, and relative-bind grounding before ambient prompt breadcrumbs become a second hidden targeting plane.**
