# Clipboard bridges, read/write asymmetry, and export humility

This surface keeps one narrower lesson explicit:
**clipboard writes, clipboard reads, remote-local bridges, and public export are related conveniences, but they are not the same authority move.**

The outside ecosystem is unusually clear here.
xterm still documents OSC 52 selection manipulation, but gates it behind `allowWindowOps` and allows query (`?`) replies as well as writes.
tmux makes `set-clipboard=external` meaningfully weaker than `set-clipboard=on`; the latter allows applications inside tmux to set the system clipboard, and the tmux wiki explicitly warns that any command able to write to a pane can then set the clipboard.
kitty allows fine-grained clipboard control, asks by default on clipboard reads, warns that disabling read confirmation is a security risk, and even exposes a max-size guard.
Ghostty defaults to prompting for clipboard reads while allowing writes, adds paste-protection settings, and treats clipboard policy as a first-class user setting.
WezTerm supports OSC 52 writes and clear operations but ignores clipboard-query requests.
PowerShell 7.4+ adds `Set-Clipboard -AsOSC52` specifically to target the **local** host clipboard over SSH rather than silently writing the remote machine's clipboard.

Taken together, the design-phase lesson for Schell is straightforward:

## 1) Clipboard **read** is stronger than clipboard **write**

A write sends a payload out.
A read pulls ambient user data in.
Those should not share the same default posture.

For Schell, that means a very small but important asymmetry:
- clipboard write may often be allowed under bounded local policy,
- clipboard read should usually be ask-gated, lease-scoped, or denied,
- and the UI should never flatten both into one generic “clipboard access” success story.

## 2) Remote-to-local copy deserves its own verb

PowerShell's `-AsOSC52` is a brilliant clue.
When an operator is over SSH, “copy to clipboard” is ambiguous.
Did we write the remote host clipboard, the local host clipboard, a mux buffer, or nothing at all?

Schell should therefore preserve separate outcomes such as:
- local copy pack created,
- local host clipboard written,
- remote peer clipboard written,
- mux buffer updated,
- terminal bridge write attempted,
- terminal bridge write denied,
- or bridge unavailable.

That is a much better shell+terminal story than letting every successful-looking escape sequence overclaim “copied”.

## 3) Relay posture matters as much as capability posture

Nested tmux, SSH, terminal relays, and compatibility shims all change what clipboard operations can honestly mean.
The shell should not only know whether clipboard support exists.
It should also confess **where the request had to travel** and what policy family decided it.

A small first-cut witness can therefore keep:
- issuer,
- target surface,
- relay path,
- operation family (`write`, `read`, `clear`, `query`, `export`),
- user-approval posture,
- and final observed result.

That would already eliminate a lot of misleading success chrome.

## 4) Export is stronger than clipboard write

A copied string that lands in a local clipboard is not the same as:
- a saved snippet,
- a synced block,
- a share link,
- a published workflow,
- or an exported artifact.

Schell should keep that ladder explicit.
This aligns well with its newer memory-residency and publication-humility surfaces.
Clipboard should feel like a **nearby ephemeral egress lane**, not a synonym for publication.

## 5) Steal the good ideas, not the whole stack

The best ideas to steal from the current ecosystem are:
- **ask on reads, not just writes**,
- **remote-to-local copy as an explicit action**,
- **relay-aware result badges**,
- **size or type budgets for outbound writes**,
- **paste-attack protection staying separate from clipboard-read permission**,
- and **clear/empty clipboard as an explicit operation rather than a side effect**.

Those are high-value ideas that do not force Schell to choose one final clipboard daemon, one final transport protocol, or one final sync/publication backend yet.

## 6) Compact answer

Schell does **not** need a giant clipboard subsystem next.
It needs one bounded rule:
**clipboard reads, clipboard writes, remote-local bridges, mux-local buffers, and stronger export/publication moves should stay separately named, separately badged, and differently permissioned.**

That is enough to make the custom shell+terminal feel much smarter while still staying decision-light.
