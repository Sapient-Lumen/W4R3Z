# Arrival strips, start causes, and summon humility

**Schell should absolutely steal the best modern summon comfort — shortcut summons, notification returns, chooser accepts, protocol launches, duplicate-nearby tabs/splits, and restored rooms — but it must also leave behind one tiny visible answer to the operator's immediate question: _why does this room exist right now?_**

## 1) The next no-regret luxury move is a tiny arrival strip

The archive already has:
- wake tickets,
- launch sheets,
- fresh-intent witnesses,
- activation batons,
- activation receipts,
- and reentry cues.

What is still missing is the smallest durable answer to a different question than _what happened to the baton?_
The missing question is:
**"why did this lane, room, tab, or helper surface appear at all?"**

That question matters constantly in a modern shell+terminal.
A pane may have appeared because:
- the operator typed a fresh local launch,
- a split duplicated nearby footing,
- a shortcut summoned a waiting room,
- a notification click reopened an existing review lane,
- a browser or URI return reentered a flow,
- a restore path replayed remembered state,
- policy or repair restarted something,
- or a tool/helper/assistant proposed a new local surface.

Those are not the same story.
Yet products often leave them implicit.
Schell should not.
It should add one tiny **arrival strip**.

## 2) Current systems already keep start cause narrower than control or readiness

Steward already pushes exactly this direction with an activation-cause posture for concrete runtime cycles.
Desktop stacks keep carrying narrow launch/activation cause clues too:
- notification activations identify themselves as a special activation kind,
- protocol/URI launches identify themselves differently,
- global shortcuts arrive as their own activated events,
- D-Bus activation carries startup/activation platform data,
- and modern terminals keep split/tab/window spawn classes distinct instead of treating all nearby spawns as one clone story.

That is the shape Schell should steal.
Do **not** invent a giant lifecycle graph.
Do **not** decide one universal startup-notification substrate.
Do **not** fuse start cause with foreground result or readiness.
Just keep one tiny visible start-cause object.

## 3) The right object is an arrival strip, not a universal event history

An **arrival strip** is a small explanatory witness attached to a newly visible room/lane/tab/window/helper surface.
It answers:
- why this surface was created or re-surfaced,
- what family of path caused it,
- and what stronger acts are still separate.

A useful v0 can stay tiny:
- `arrival_ref`
- `surface_ref`
- `cause_family` — manual / nearby-fork / shortcut / notification / chooser / protocol-return / restore / repair / helper / unknown
- `cause_detail` — optional compact detail such as `split from room 4`, `shortcut summon`, `notification action=open-review`, `protocol=acme://callback`, `restored workspace`, `repair relaunch`
- `basis_posture` — fresh / inherited-partial / restored / replay-gated / unknown
- `activation_posture` — none / baton-present / baton-spent / receipt-linked / unknown
- `control_posture` — active-now / revealed-only / armed-only / historical-only / unknown
- `next_floor` — inspect / continue / compare / refresh / retry-with-fresh-baton / fresh-start
- `why_note` — optional compact residue such as `cwd followed`, `env partial`, `restore pending refresh`, `foreground denied`, `redirected to existing room`

That is already enough to make new surfaces feel dramatically more understandable.

## 4) Keep these truths visibly separate

### a) Why the surface appeared
This is the core arrival-cause fact.
It should not be guessed from titles, focus, or which pane ended up frontmost.

### b) What footing followed
A room can arrive because of a nearby fork yet only inherit cwd.
Another can arrive because of restore and still need fresh footing.
The arrival strip should confess that.

### c) Whether activation was involved
A shortcut summon, notification return, or browser callback may carry baton/receipt posture.
A local split usually will not.
The cause strip should point to that without turning itself into activation authority.

### d) Whether active control actually arrived
A notification return may reveal the right room yet fail to gain foreground.
That remains an activation-receipt truth, not the same as start cause.

### e) What the strongest honest next move is now
The best next step may be:
- continue,
- inspect,
- compare footing,
- refresh before acting,
- retry with fresh baton,
- or start fresh instead.

## 5) Why this makes the shell+terminal super awesome

Because it makes summons legible.
A great shell+terminal should let the operator reenter quickly **without** asking them to reverse-engineer what kind of arrival just happened.

### a) Duplicate-nearby stops being folklore
Instead of a vague new split, Schell can say:
- `nearby fork • cwd followed • env partial • fresh start available`

### b) Shortcut summons stop pretending to be manual starts
A summoned room can say:
- `shortcut summon • exact room found • armed-only • continue requires focus`

### c) Notification returns stop feeling haunted
A reopened review lane can say:
- `notification return • existing lane revealed • baton receipt linked • foreground denied`

### d) Protocol/browser returns stop feeling like random launches
A callback lane can say:
- `protocol return • restored review lane • active control separate • approval still pending`

### e) Restored rooms gain immediate honesty
A restored workspace can say:
- `restore • footing historical • compare current basis before run`

## 6) Immediate specimen moves worth stealing

### a) First-frame arrival strip
When a room appears, show a short strip for a few seconds and keep it in hover/history:
`notification return • lane revealed • receipt linked`

### b) Persistent “why am I here?” hover
Every room/tab title or chapter header should be able to answer:
- what caused this to appear,
- what inherited footing followed,
- and what stronger act is still separate.

### c) Arrival-aware same-context launch sheets
If a new room came from duplicate-nearby posture, keep the inherited diffs one click away from the arrival strip.

### d) Arrival-linked activation receipts
If a baton-bearing path caused the arrival, the strip should link to the activation receipt instead of flattening both stories into one badge.

### e) Transcript-safe cause residue
Transcripts should be able to say `shortcut summon`, `protocol return`, or `restored room` without serializing private platform token material.

## 7) Companion pressure is strongly aligned

- **SlopOS** keeps exact launch basis and open/reveal authority narrow, so start cause should remain explanatory rather than power-bearing.
- **Steward** already argues for a compact activation-cause vocabulary tied to one concrete runtime cycle.
- **Steward** activation-receipt posture also reinforces that cause, delivered startup material, acknowledgement, and foreground/control are different truths.
- **ViewFS** keeps object identity, carriers, receipts, and current control distinct, which pressures Schell not to flatten arrival cause into current authority.
- **Harbor** keeps stoplines visible, so `restore`, `repair`, or `historical-only` should be first-class admissions.
- **Ward** keeps attenuation and continuous-signal posture visible, which helps arrival strips cool into historical residue cleanly.
- **Helm** keeps settlement narrow, reminding Schell that “why this started” is not the same as “this is complete” or “this landed.”

## 8) What not to decide yet

Do **not** decide yet:
- one universal launch-cause schema shared across every platform,
- one final source-of-truth storage plane for arrival history,
- one final room/tab/window identity treaty,
- one giant lifecycle graph for every appearance and disappearance,
- or one rule that turns a past arrival cause into present authority.

The smaller no-regret move is enough:
**give Schell a tiny arrival-strip family so every newly visible room/lane can say why it exists, what footing followed, whether activation residue is linked, and what the strongest honest next move still is.**
