# Change-digest cards, what-changed-since, and unread humility

**Schell should absolutely steal modern command-aware capture comfort — command guides, sticky headers, prompt jumps, exact command-output selection, hidden-terminal reopening, preserved output, and later live follow — but once a snapshot receipt and an optional since-cut supplement exist, the next operator question is even smaller: _what actually changed since that cut, in one glance, and how much of that answer is still honest?_**

## 1) Snapshot receipts and since-cut supplements still leave one cheap operator question unanswered

A **snapshot receipt** already says what exact cut was captured.
A **since-cut supplement** already says what later output or deltas arrived after that cut, how far they are caught up, and whether refresh or reset is required.

But operators reopening a hidden terminal, returning to a watch deck, attaching a preserved command to help, or glancing at a replay card still want one tiny thing before they read the raw delta stream:

- `did anything change at all?`
- `what kind of change was it?`
- `where is the first unseen thing?`
- `is this just more stdout, or did status/risk/settlement also change?`
- `is the answer counts-only, channel-aware, or gap-limited?`

That is a different object from the base cut and a different object from the raw supplement.

## 2) The missing object is a tiny change-digest card

Schell should add a compact **change-digest card** that hangs off a since-cut supplement (or directly off a snapshot receipt when the only honest answer is `no later change known`).

The card is:
- stronger than a generic unread dot,
- weaker than the raw later-change stream,
- weaker than any claim that the lane is live/current/stable/quiescent,
- and much weaker than any act that spends present authority.

Its whole purpose is to compress the next glance.

## 3) Generic unread counts are too fuzzy, and full summaries are too strong

A generic unread badge is attractive because it is cheap.
But it hides too much:
- unread **what**,
- since **which** cut,
- in **which** channel,
- with **which** reset/gap posture,
- and with **what** claim strength.

At the other extreme, a full prose summary or clever auto-digest often overclaims.
It can quietly flatten:
- exact output into interpretation,
- partial later deltas into confident storyline,
- mixed stdout/stderr/status/settlement movement into one prose blob,
- and a reset-required source into fake continuity.

Schell should therefore keep the first object tiny and explicit.
A change-digest card should be comfortable, but not magical.

## 4) Suggested fields for a v0 change-digest card

A good phase-1 **change-digest card** probably needs fields like:

- `base_snapshot_ref` — exact earlier cut being discussed,
- `supplement_ref` — exact later-change lane or `none`,
- `digest_scope` — same-command / same-chapter / same-watch-row / same-lane / mixed / unknown,
- `digest_basis` — none / counts-only / channel-aware / event-kind-aware / bookmark-aware / human-note / unknown,
- `from_watermark` — exact earlier prompt/cmd/cursor/bookmark/generation,
- `through_watermark` — exact later prompt/cursor/bookmark/generation or `none`,
- `first_unseen_ref` — exact first later boundary when known,
- `last_seen_ref` — exact prior boundary the operator/card was already based on,
- `change_kinds` — stdout / stderr / status / prompt / watch-delta / settlement / risk / annotation / mixed,
- `change_counts` — optional compact counts such as lines/events/rows/status flips,
- `gap_posture` — none-known / partial / compacted / reset-required / unknown,
- `severity_posture` — neutral / attention / degraded / risk-raised / settlement-changed / unknown,
- `why_note` — one compact residue like `+18 stderr lines since prompt 41`, `2 modified rows after bookmark rv=10245`, `later output exists but first unseen boundary lost`,
- `action_floor` — inspect-delta / jump-first-unseen / widen / refresh / reset / start-fresh.

That is already enough to make preserved captures and follow lanes feel much more humane without freezing:
- one universal diff engine,
- one AI summarizer contract,
- one terminal-local unread ontology,
- one cross-runtime event taxonomy,
- or one policy that every lane must support exact first-unseen recovery.

## 5) Tiny card strings worth stealing

Examples of the kind of compact card Schell should support:

- `since cmd 18: no later change known`
- `since prompt 41: +18 stdout lines · first unseen at prompt 42`
- `since cmd 7: stderr grew · exit unchanged · inspect delta`
- `since bookmark rv=10245: 2 added · 1 modified · caught up through rv=10288`
- `since hidden capture: later output exists · first unseen boundary unknown`
- `since cut: status changed to degraded · output delta small`
- `since cut: reset required · source epoch changed`
- `since cut: settlement changed · receipt still historical`

The key is that these are not full summaries.
They are glance-level compression with visible humility.

## 6) Great ideas to steal right now

### Sticky command headers and command guides
Once commands have exact boundaries, keep the relevant command visible while later output scrolls away.
That makes `what changed since this cut?` easier to answer without re-reading a whole transcript.

### Jump to first unseen and show only unseen
A later-change digest should be able to jump directly to the first unseen boundary or filter to later output only.
That is a much better default than dumping the operator at the bottom of a giant transcript and hoping they infer the delta.

### Channel-aware counts
`+18 stdout` is different from `+18 stderr`.
`1 status flip` is different from `43 lines`.
`watch: 2 modified rows` is different again.
Keep those distinctions visible.

### Reset-visible digests
If the first unseen boundary is lost, compacted, or no longer valid, say that directly.
Do not silently degrade into `some new stuff happened`.

### Settlement/risk overlays that remain narrower than output
If later change touched a risk ladder or settlement witness, show that as a narrow kind badge rather than silently burying it inside output text.

## 7) What Schell should refuse here

### Refuse one generic unread badge for every lane
A single dot does not say enough.

### Refuse default prose or LLM summaries as the first truth object
Helpful summaries may exist later, but the first card should stay bounded and inspectable.

### Refuse silent merging of base cut and later delta
The operator should always be able to see the join.

### Refuse auto-heal from reset-required into latest-known digest
If the source changed epochs or lost the first unseen boundary, say so.

### Refuse counts that outrun source truth
If a channel-aware or event-aware count cannot be honestly computed, downgrade the digest basis instead of pretending precision.

## 8) Why the companion datacubes push exactly here

- **SlopOS** keeps bounded observation/export weaker than portable live authority, so a digest card should remain observational and should not become a shadow current-state plane.
- **Steward** already pressures snapshot-plus-change, caught-up posture, and reset-required honesty, which is the right base for `what changed since then?` cards.
- **ViewFS** keeps basis, delta, apply, and reconstructed-result truth distinct; that argues strongly for keeping base cut, later-change lane, and compact digest as separate objects.
- **Ward** keeps continuous signals, attenuation, and residue distinct; that is exactly the pressure toward source-labeled, cooling-aware change digests instead of one generic unread mood.
- **Harbor** keeps risk ladders visible, which suggests later risk movement should become one tiny digest kind rather than buried transcript prose.
- **Helm** keeps settlement narrower than local success, which suggests a digest card may say `settlement changed` without pretending that raw output or local exit already proved durable consequence.
- **Foundry** keeps config/overlay drift explicit, which is a reminder that later change may reflect footing drift rather than just new bytes.

## 9) No-regret first specimen set

A compact first proof could show:
1. one preserved command capture with `no later change`,
2. one hidden-terminal capture with `+stdout since cut` and a jump-to-first-unseen action,
3. one command where only stderr changed after the cut,
4. one watch snapshot with `2 modified rows since bookmark` and caught-up-through posture,
5. one digest that downgrades from channel-aware to partial because the first unseen boundary was lost,
6. one digest showing `risk raised` while raw output change stays small,
7. one reset-required digest after source replacement/epoch change,
8. one transcript-safe notation for base cut + supplement + digest card,
9. and one refusal to let a digest card rerun, act, or silently promote to live truth.

That would make Schell feel substantially more awesome without choosing the final watch schema, transcript store, summary engine, or replay substrate.

## 10) The no-regret move

The best next move is not a giant live-follow constitution.
It is this:

**after an exact cut and an optional later-change lane already exist, give the operator one tiny change-digest card that says what changed since then, how strong that answer really is, where the first unseen thing begins when known, and when refresh/reset is still the more honest next move.**
