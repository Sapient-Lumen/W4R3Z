# Activation receipts, baton spend, and denial residue humility

**Schell should absolutely steal modern comfort around notification clicks, shortcut summons, chooser accepts, browser returns, and exact-open returns — but it must also leave behind one tiny durable object saying what actually happened to the baton, what exact target resolved, whether activation was requested, whether focus/foreground was granted, and what residue remains honest now.**

## 1) The next no-regret luxury move is a tiny after-action truth object

The archive now already has:
- wake tickets,
- fresh-intent witnesses,
- launch sheets,
- activation batons,
- armed-versus-active posture,
- and footing strips.

What is still missing is the tiny durable answer to the operator's very human follow-up question:
**"okay, but what actually happened when I clicked it?"**

Current products often leave that fuzzy.
A notification vanishes.
A shortcut seems to do something.
A browser return appears to bounce back.
A chooser closes.
But afterward the operator may still have to guess:
- did the exact target resolve,
- did the baton get consumed,
- did foregrounding get denied,
- did the app relaunch instead of reveal,
- did activation land on the wrong window,
- or did the UI merely flash the request and stop there?

That is a perfect Schell seam.
Do not add a giant event ledger or trusted-UI constitution.
Just add one tiny **activation receipt**.

## 2) Platforms already hint that spend evidence and control result are different truths

The surrounding platform story is unusually aligned.
The freedesktop notifications spec says clients must not assume the server will even emit `ActionInvoked`, and the optional `ActivationToken` signal may arrive before it.
The XDG Notification portal also says applications cannot learn whether the notification was actually presented, and a click after the app exits may activate it again.
The AppChooser backend says user interaction may mint a **new** activation token for the chosen app.
GlobalShortcuts carries activation tokens on `Activated` and `Deactivated` events.
Windows says a process can still be denied the right to set the foreground window even when several conditions are met, and the system may flash the taskbar instead.
CoAllowSetForegroundWindow exists precisely because foreground privilege can be passed, not assumed.
Systemd's `sd_notify()` posture is another useful analogy: delivery evidence, attribution, and synchronized acknowledgement are distinct enough that `sd_notify_barrier()` exists.

That is the shape Schell should steal.
A baton may exist.
A baton may be passed.
A target may resolve.
A reveal may happen.
A foreground request may still be denied.
And an activation receipt can say so compactly without pretending more happened than really did.

## 3) The right object is an activation receipt, not a giant session log

An **activation receipt** is a tiny shell+terminal-local residue object created after an activation-bearing path finishes trying.
It is not:
- the activation baton itself,
- a durable capability,
- proof of current active control,
- a universal cross-platform focus log,
- or permission to replay the action forever.

A useful v0 receipt can stay small:
- `receipt_ref`
- `source_ref` — exact baton / wake ticket / chooser row / browser return / shortcut event / unknown
- `target_ref` — exact chapter / receipt / room / pane / output span / helper lane / unknown
- `target_resolution` — exact / narrowed / failed / historical-only / unknown
- `activation_request` — none / present / passed-through / regenerated / unknown
- `reveal_result` — revealed / opened / launched-new / already-visible / failed / unknown
- `foreground_result` — not-requested / granted / denied / ignored / expired / policy-blocked / unknown
- `control_result` — active-now / armed-only / no-active-control / wrong-target / unknown
- `residue_floor` — inspect / reveal-again / review / retry-with-fresh-baton / history-only / blocked
- `why_note` — optional compact reason such as `token expired`, `foreground lock`, `chooser closed`, `target historical`, `window missing`

That is already enough to make modern activation comfort feel much more trustworthy.

## 4) Keep these post-activation truths visibly separate

### a) Baton spend
Was the baton actually consumed, passed onward, or never used?
That matters because a spent baton and an expired baton are not the same story.

### b) Target resolution
Did the exact thing resolve?
A good path may still resolve the right chapter or helper lane even when focus is denied.

### c) Reveal/open result
Did Schell reveal an existing surface, open a room, or launch a new one?
That is visible product truth.
It should not hide behind one cozy `activated` badge.

### d) Foreground/control result
Did the UI actually grant foreground or active input?
This is still narrower than reveal/open success.
It should stay a separate field.

### e) Residue floor
What is the strongest honest next move now?
Usually:
- inspect,
- reveal again,
- retry with fresh baton,
- or accept that the residue is historical only.

## 5) Why this makes the shell+terminal super awesome

Because it turns mystery into confidence.
A great shell+terminal should make return paths feel fast **and** explainable.
Tiny activation receipts unlock exactly that.

### a) Notification clicks become explainable
Instead of "I clicked it and something weird happened," Schell can say:
- `exact target resolved • opened existing review lane • foreground denied • retry requires fresh gesture`

### b) Browser returns stop feeling haunted
An auth return can say:
- `target exact • baton arrived • lane revealed • active control not granted • approval still separate`

### c) Shortcuts stop overclaiming control
A shortcut can say:
- `room exact • summon succeeded • baton spent • armed only`

### d) Chooser accepts can confess when they only resolved the target
A chooser accept can say:
- `target exact • new activation token minted • reveal succeeded • focus request ignored`

### e) Operators can debug the system without reading folklore
A tiny receipt attached to the chapter, wake ticket, or lane card makes it much easier to see whether the problem was target resolution, baton freshness, focus policy, or later shell state.

## 6) Immediate specimen moves worth stealing

### a) Receipt strip on reveal cards
After a click/shortcut/return, show one short strip:
`target exact • baton spent • revealed • foreground denied`

### b) Receipt chip on history rows
Recent activation-bearing rows can carry:
`receipt: launched-new` or `receipt: armed-only`

### c) Retry with fresh baton
If the target resolved but the baton died, make `retry with fresh baton` a named action distinct from ordinary reveal.

### d) Receipt-linked why view
A tiny `why?` hover should show the baton source, target, and refusal note.

### e) Transcript-safe residue
The transcript should be able to record a small textual summary without trying to serialize platform-private tokens.

## 7) Companion pressure is strongly aligned

- **SlopOS** already keeps open/reveal routing distinct from portable foreground authority, so activation receipts should stay evidence, not control.
- **Steward** already has activation-cause and activation-receipt pressure, which strongly suggests that one exact run should be able to say what startup/activation material was delivered and whether acknowledgement was observed.
- **ViewFS** keeps gesture evidence, batons, active control, and receipts as different classes, which fits perfectly here.
- **Helm** keeps settlement narrower than source-side success, so an activation receipt should not quietly become durable completion or receiver truth.
- **Harbor** keeps stoplines visible, making `foreground denied` or `retry needs fresh baton` a useful admission rather than a product embarrassment.
- **Ward** keeps continuous status and attenuation posture visible, which pressures Schell to preserve refusal residue without pretending the baton is still live.

## 8) What not to decide yet

Do **not** decide yet:
- one universal receipt schema shared with every OS,
- one final storage plane for activation residue,
- one final token-lifecycle treaty,
- one final replay privilege tied to receipts,
- or one final cross-platform foreground-control protocol.

The smaller no-regret move is enough:
**give Schell a tiny activation-receipt family that records baton spend, target resolution, reveal/open result, foreground/control result, and honest residue floor so notifications, shortcuts, chooser accepts, and browser returns can feel magical without leaving the operator to infer what actually happened.**
