- `80-terminal/source-witnesses-import-cards-and-scope-mutation-humility.md` — load-form cards, scope badges, path/source notes, export-posture chips, reversible overlay receipts, and the rule that helper loading stays weaker than exact reviewed spend.
- `80-terminal/substitution-witnesses-capture-residue-and-helper-sidecar-humility.md` — typed substitution tokens, helper-footing badges, capture-form chips, trim/split residue labels, sidecar route cards, and the rule that capture help stays weaker than exact reviewed spend.
- `80-terminal/redirection-witnesses-heredoc-cards-and-fd-lease-humility.md` — typed redirect tokens, source-lane route chips, here-doc posture cards, fd-lease labels, order reveals, and the rule that routing help stays weaker than exact reviewed side effects.
- `80-terminal/redirection-witnesses-heredoc-cards-and-fd-lease-humility.md` — typed redirect tokens, source-lane route chips, here-doc posture cards, fd-lease labels, order reveals, and the rule that routing help stays weaker than exact reviewed side effects.
- `80-terminal/history-substitution-witnesses-event-designators-and-reedit-humility.md` — typed recall tokens, cited source events, modifier reveals, re-edit posture, and the rule that shell memory stays weaker than exact reviewed command truth.
- `80-terminal/expansion-witnesses-glob-reveals-and-match-residue-humility.md` — typed pattern tokens, expansion-family labels, match-count/sample residue, no-match policy, literal override posture, and the rule that expansion help stays weaker than exact reviewed spend.
- `80-terminal/autocd-cdpath-reveals-and-navigation-truth-humility.md` — implicit-cd posture, CDPATH reveals, ranked-jump labels, exact cwd compare, and the rule that navigation help stays weaker than working-ground truth.
- `80-terminal/abbreviations-alias-reveals-and-expansion-humility.md` — typed abbreviations, alias-reveal posture, imported shorthand packs, exact command-identity compare, and the rule that shorthand stays weaker than exact command truth.
- `80-terminal/transient-prompt-final-rendering-and-history-chip-humility.md` — transient prompts, final historical rendering, frozen history chips, omitted-context notes, and the rule that compact old prompts stay weaker than live shell truth.
- `80-terminal/paste-filters-quote-at-prompt-and-control-code-humility.md` — paste offers, filter proposals, admitted filter results, literal reveal, control-code hygiene, and the rule that helpful paste transforms stay weaker than authored shell truth.
- `80-terminal/preview-settlements-miss-ledgers-and-outcome-gap-humility.md` — preview settlement cards, outcome-gap strips, miss ledgers, outside-claim drawers, and the rule that simulations and helper previews stay weaker than later observed receipts and live truth.
# Docs map

- `00-meta/` — charter, trajectory, policy, move registry, question machine, hygiene, and research synthesis
- `10-command-model/` — the command envelope and execution journey
- `20-language/` — syntax, quoting, expansion, and word formation
- `30-runtime/` — pipelines, processes, effects, and control surfaces
- `40-assurance/` — claims, invariants, and failure classes
- `50-session/` — command lineage, receipts, replay, and postmortems
- `60-platform/` — portability profile, compatibility stance, and Rust implementation posture
- `70-automation/` — agent boundary, consent, and automation posture
- `80-terminal/` — semantic terminal moves, transcript truth, trusted chrome/review-lane separation, review blocks, trusted command-block action gates, authorship/basis surfaces, denial teaching, background shelves, attention/finish-notice posture, ingress/clipboard honesty, operator affordances, and no-regret shell+terminal moves
- `80-terminal/option-witnesses-strictness-scopes-and-startup-mode-humility.md` — inherited baselines, startup imports, strictness/version chips, local-scope badges, restore receipts, and posture-plus-command review rows.
- `80-terminal/redirection-witnesses-heredoc-cards-and-fd-lease-humility.md` — typed redirect families, source lanes, target witnesses, order posture, here-doc expansion posture, fd leases, and redirect-plus-receipt honesty.
- `80-terminal/history-substitution-witnesses-event-designators-and-reedit-humility.md` — typed recall tokens, cited source events, word/modifier reveals, source-locality labels, and re-edit posture for history shorthand.
- `80-terminal/fold-receipts-summary-headers-and-reveal-debt-humility.md` — typed fold receipts, summary headers, hidden-range debt, exact reveal ladders, and the rule that a compact fold stays weaker than the chapter it hides.

- `80-terminal/abbreviations-alias-reveals-and-expansion-humility.md` — typed abbreviations, alias reveals, imported shorthand labels, exact command-identity compare, and the rule that shorthand stays weaker than exact command truth.

- `80-terminal/command-decks-marks-annotations-and-discovery-honesty.md` — exact marks, local annotations, command decks, explicit context stripes, insert-not-run recall, object-vs-action palette rows, and metadata-safe discovery.
- `80-terminal/abandon-receipts-buried-sessions-and-prompt-aware-close-humility.md` — prompt-safe close, unsent-input abandonment, buried live continuity, undo-close grace, destructive close, and continuity-class receipts.

- `90-quarantine/` — attractive but unearned ideas

- `80-terminal/reentry-cues-session-restoration-and-historical-honesty.md` — reentry cues, restored-state badges, hold cards, and history/live honesty.
- `80-terminal/attention-hints-finish-notices-and-interruption-budgets.md` — exact attention events, bounded finish notices, interruption budgets, and residue honesty.

- `80-terminal/ingress-packets-paste-drop-and-clipboard-honesty.md` — ingress packets, bracketed-paste-aware insert paths, dropped-file import cards, and transcript-visible clipboard/drop handling.

- `80-terminal/edit-journals-kill-rings-and-paste-history-humility.md` — edit journals, kill rings, foreign paste provenance, trim-now hygiene, and the rule that local composition memory stays weaker than durable command history or disk-saved residue.

- `80-terminal/output-capsules-stream-braid-witnesses-and-ordering-humility.md` — shell-owned output capsules, braid witnesses, channel/provenance truth, and ordering humility.

- `80-terminal/trusted-chrome-secure-review-lanes-and-anti-spoof-separation.md` — trusted local chrome, secure review lanes, trust grades, and host-effect witnesses that keep approval UI distinct from PTY flow.

- `80-terminal/command-chapters-journal-truth-and-source-labeled-recall.md` — shell-owned command chapters, exact journals, source-labeled recall, and history-pollution guards.

- `80-terminal/launch-kits-quick-summon-and-cockpit-honesty.md` — explicit project launch kits, runtime-fast quick summon, cockpit discovery surfaces, and attach-vs-relaunch honesty.

- `80-terminal/object-cards-exact-reveal-and-safe-open-honesty.md` — typed object cards, exact reveal, ordinary open vs safe-open, and metadata-safe object inspection.

- `80-terminal/slot-linked-edits-synced-cursors-and-parameter-fill-humility.md` — field-local parameter slots, repeated-slot synced edits, provenance badges, and the rule that fill stays weaker than run.

- `80-terminal/argv-witnesses-exact-reveal-and-escape-humility.md` — pretty active-input views, exact argv/text reveal, quote-and-escape witnesses, and the rule that display stays weaker than launch truth.

- `80-terminal/transcript-cards-replay-bundles-and-redaction-honesty.md` — transcript cards, replay bundles, timing witnesses, selective export sheets, and redaction-visible transcript handling.
- `80-terminal/enrichment-packets-freshness-budgets-and-speculation-refusal.md` — smart-terminal enrichment packets, source/freshness/cost badges, explicit refresh/materialize steps, and speculation refusal.

- `80-terminal/chrome-witnesses-status-egress-and-ambient-badge-humility.md` — ambient chrome/status projections, title and badge humility, taskbar/dock progress egress, and the rule that surrounding chrome stays weaker than durable truth.
- `80-terminal/secret-witnesses-reveal-ladders-and-masking-humility.md` — secret-bearing refs, proxy use, reveal ladders, sink badges, and the rule that masking stays weaker than sink avoidance.
- `80-terminal/tty-witnesses-process-group-lanes-and-promotion-humility.md` — foreground tty claims, stopped/background/disowned lanes, promotion rails, and the rule that prompt return stays weaker than durable continuation truth.

- `80-terminal/shell-integration-marks-startup-humility-and-command-block-honesty.md` — shell-owned semantic marks, startup-footing witnesses, trust-graded command chapters, and the rule that command-aware luxury stays weaker than durable shell truth.

- `80-terminal/witness-packets-carried-truth-and-claim-handoff-humility.md` — compact carried witness packets, current supplements, why bundles, and the rule that rich command objects should keep one coherent footing story across views.
- `80-terminal/footing-strips-action-floors-and-strongest-next-verb-humility.md` — tiny footing strips, explicit action floors, strongest-next-verb honesty, and the rule that rich command objects stay weaker than the shell footing they can still prove.

- `80-terminal/activation-batons-armed-rails-and-focus-second-humility.md` — exact target identity, activation batons, armed-versus-active posture, and focus-second humility for notifications, shortcuts, chooser accepts, and browser returns.


- `80-terminal/readiness-strips-prompt-caught-and-integration-truth-humility.md` — tiny readiness strips, prompt-caught posture, integration-quality honesty, cwd freshness, and the rule that a visible lane stays weaker than a prompt-ready lane.

- `80-terminal/since-cut-supplements-snapshot-plus-change-and-refresh-humility.md` — tiny since-cut supplements, later-change caught-up chips, refresh/reset rails, and the rule that preserved captures stay weaker than any live lane they can sometimes be extended from.

- `80-terminal/snapshot-receipts-cut-watermarks-and-partial-capture-humility.md` — tiny snapshot receipts, cut-watermark posture, synced-through markers, partial-capture honesty, and the rule that a bounded terminal slice stays weaker than complete-or-current truth.

- `80-terminal/quiescence-strips-calm-windows-and-silence-is-not-proof-humility.md` — tiny quiescence strips, weaker calm-window posture, marker-finished versus explicit quiesce honesty, and the rule that local silence stays weaker than safe snapshot truth.

- `80-terminal/placement-receipts-requested-lanes-and-realized-landings-humility.md` — tiny placement receipts, requested-versus-realized landing honesty, and redirect/downgrade humility for split/tab/window/editor-area/attach/revive/restore flows.

- `80-terminal/arrival-strips-start-causes-and-summon-humility.md` — tiny arrival strips, start-cause chips, linked footing/activation posture, and summon humility for newly visible rooms, tabs, helper lanes, and restored surfaces.
- `80-terminal/activation-receipts-baton-spend-and-denial-residue-humility.md` — tiny activation receipts, baton spend/regeneration/expiry, reveal/open versus foreground/control results, and honest residue floors for baton-bearing flows.

- `80-terminal/fresh-intent-witnesses-consumed-gestures-and-replay-humility.md` — fresh-intent witnesses, consumed gestures, one-gesture one-spend humility, and graceful downgrade to inspect/stage/review for stronger convenience actions.

- `80-terminal/launch-sheets-inherit-diffs-and-fresh-instead-humility.md` — same-context launch sheets, per-lane inherit diffs, exact fallback toasts, and fresh-instead parity for high-value convenience spawn.

- `80-terminal/capability-witnesses-degradation-receipts-and-hop-lineage-humility.md` — capability witnesses, degradation receipts, hop-lineage cards, and the rule that terminal luxury stays weaker than fresh capability truth.

- `80-terminal/prompt-regions-continuation-cards-and-multiline-input-humility.md` — prompt-region witnesses, continuation cards, multiline-input geometry, sticky chapter header humility, and historical-repaint badges.
- `80-terminal/review-watermarks-first-unseen-and-seen-state-humility.md` — tiny review watermarks, first-unseen anchors, resume strips, and the rule that reviewed-through posture stays weaker than source cursors and action authority.
