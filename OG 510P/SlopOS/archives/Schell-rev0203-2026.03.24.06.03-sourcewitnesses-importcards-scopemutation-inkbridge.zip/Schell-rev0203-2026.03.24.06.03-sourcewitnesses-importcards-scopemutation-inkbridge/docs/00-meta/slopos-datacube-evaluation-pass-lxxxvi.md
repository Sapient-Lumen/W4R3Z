# SlopOS datacube evaluation, pass LXXXVI (2026-03-22)

This pass evaluates the clipboard / paste / selection-ownership seam against the current SlopOS archive.
The main result is crisp:
**SlopOS strongly rewards a shell that treats clipboard and paste as explicit transfer/grant objects rather than as one ambient shared channel.**

That pressure is unusually strong in the companion archive and matches the best modern clipboard/paste designs better than legacy terminal folklore does.

## 1) SlopOS already wants clipboard-like movement to live on explicit workflow seams

The D-PLUMB posture keeps workflow mediation explicit, request-local, and non-ambient.
It refuses ambient helper shortcuts after init and declines a durable generic inbox/outbox story.
That matters here because clipboards and drag/drop are some of the oldest ambient helper fantasies in desktop systems.

For Schell this implies:
- clipboard read/write and paste should look like explicit mediated actions,
- not like invisible ambient helper success,
- and not like a second hidden authority lane that rides on old terminal habit.

## 2) SlopOS is already explicit that host↔guest clipboard convenience should stay weaker than reviewed transfer seams

The current microVM clipboard/drag-drop posture is one of the strongest direct pressures in the whole companion archive.
It says there is no portable ambient shared-clipboard / drag-drop / guest-tools file-transfer plane under `ext.microvm`, that owner-local desktop helper integration stays implementation-local, and that reviewed transfer meaning still rides on explicit D-PLUMB seams.

For Schell this implies:
- remote/local clipboard bridges must stay visibly bridged,
- VM/guest helper clipboard comfort must stay weaker than exact reviewed transfer,
- and “clipboard succeeded” must never masquerade as portable reviewed transfer truth.

## 3) SlopOS likes copy-as-offer and paste-as-targeted grant much more than broadcast clipboard mythology

The companion bibliography and transfer posture work already lean toward portal thinking, not broadcast thinking.
That matches Qubes-like inter-domain clipboard models unusually well: copying into an intermediate lane is not the same thing as granting the paste into one exact target.

For Schell this implies:
- local selection can become a copy offer without immediately mutating broader state,
- cross-boundary paste should name one target,
- and sensitive or privileged paste should often clear or expire after delivery.

## 4) SlopOS trusted-path pressure also matters for paste

The companion archive keeps insisting that strong approvals and stronger authority jumps should not depend only on raw child-controlled render surfaces.
Paste is not exempt.
A multiline newline-bearing payload at a shell prompt, a secret-bearing clipboard readback, or a cross-domain paste into an elevated target can all become “trusted path” questions surprisingly quickly.

For Schell this implies:
- prompt-aware paste grants are better than generic paste,
- elevated/secret-bearing targets may need a stronger local review lane,
- and clipboard readback should be even more tightly gated than ordinary user-triggered paste.

## 5) SlopOS snapshot/evidence posture says residue should stay weaker than live transfer truth

Across observation, evidence, export, and snapshot work, SlopOS keeps derivative residue weaker than exact live basis.
That matters directly for clipboard/paste history.
A saved paste history row is not the same as current clipboard state, not the same as the exact original source object, and not the same as a current approved paste grant.

For Schell this implies:
- local copy rings and durable paste history need explicit weaker badges,
- restored clipboard material should not automatically inherit strong actions,
- and secret/elevated clipboard residue should be especially constrained.

## 6) The current ecosystem gives a companion-compatible answer

Current tools now prove a narrow pattern that matches SlopOS well:
- Wayland proves clipboard and drag/drop are explicit inter-client transfer objects rather than one magical shared substrate,
- Ghostty and WezTerm prove read/write/paste distinctions are real product decisions,
- iTerm2 and VS Code prove target-aware multiline paste warnings are worthwhile,
- kitty proves explicit paste actions, clipboard permissioning, and paste-event handoff can stay typed,
- and Qubes proves cross-domain copy/paste works best when copy and final paste stay distinct grants.

SlopOS sharpens the import:
**Schell should steal luxurious transfer ceremony, not ambient clipboard mythology.**

## 7) What this pass now strongly suggests for Schell

The most companion-compatible moves are:
- **selection-ownership badges**,
- **copy offers before egress**,
- **clipboard-read gates**,
- **bridge strips** for remote/nested/inter-domain crossings,
- **paste grants** with target posture,
- **residue badges** for ring/history/cleared state,
- and **privileged paste lanes** for secret-bearing or elevated targets.

## 8) Decisions this pass still refuses to make too early

This pass still does **not** force:
- one final clipboard manager stack,
- one final typed-payload schema,
- one final remote/VM bridge policy,
- one final paste-history model,
- one final secret auto-clear contract,
- or one final secure-approval UX for privileged paste.

The answer stays smaller and stronger:
**let Schell become excellent at copy offers, paste grants, and clipboard-read gates — but keep selection, clipboard mutation, paste events, bridge crossings, residue, and exact reviewed transfer truth separately named.**
