# SlopOS datacube evaluation — 2026-03-23 — pass CLXXXIX

**Schell should treat preview settlement as exact old claim plus later observed residue rather than one rewritten story, because SlopOS and the companion datacubes keep rewarding bound basis, non-authoritative receipts, miss honesty, label honesty, freshness fences, and neighboring-state separation.**

## 1) SlopOS already keeps reviewed basis narrower than mutable folklore

SlopOS's approval-basis posture is the strongest direct pressure here.
When a human-facing approval depends on mutable local basis, that basis must already be encoded into exact action bytes; old approval does not silently follow the new head.
That maps cleanly onto Schell previews.
A preview should not quietly follow changed cwd, env, peer, subject, auth, or policy footing and still wear the same clothes.
If the basis changed, the settlement card should say so.

## 2) SlopOS outcome receipts stay bounded and non-authoritative

The ACP outcome-receipt schema is equally helpful.
It is a non-authoritative result envelope, and even an `accept` with an effect classification does not by itself prove downstream asynchronous completion or later provider-owned live state.
That is exactly the discipline Schell needs.
A later receipt can settle some of a preview claim without claiming it settled everything forever.

## 3) SlopOS provider-local packaging keeps projections weaker than portable truth

The newer response-packaging boundary is a smaller but valuable warning.
Provider-local response packaging remains packaging; it does not silently become a portable auth-result or approval-basis object.
Schell should copy that humility.
A helper-local preview, a renderer-local diff, or a terminal-local settlement badge should remain a projection surface unless the stronger portable receipt is explicit.

## 4) Helm is the clearest nearby teacher for this exact seam

Helm is already asking the right comparative question:
what did the shell predict, what later happened, what held, what missed, and which omissions were always outside the preview's claim?
That pressure is nearly perfect for Schell.
It suggests:
- calibration witnesses,
- miss ledgers,
- outcome-gap strips,
- and maybe later compact reliability notes.

## 5) Companion cubes keep the seam honest

- **ViewFS** keeps editable, parsed, advisory, compiled, prepared, and receipt/history layers separate, so preview settlement should stay another neighboring layer rather than collapsing preview and outcome into one object.
- **Ward** keeps staleness budgets and revalidation fences explicit, so changed basis and stale data should become typed miss classes rather than vague distrust.
- **Harbor** keeps labels honest, so `preview`, `forecast`, `simulated allow`, `observed outcome`, `outside claim`, and `live state unknown` should remain visibly different labels.
- **Foundry** keeps caveat-hold and foreign-ground honesty explicit, so a preview that depended on unverified outside conditions should keep those conditions visible at settlement time rather than erasing them.
- **Steward** keeps adaptation and lifecycle transitions source-bearing, so a preview can settle differently after adaptation without implying the earlier claim was exact.

Together they point toward one shell+terminal rule:
**preserve the old claim, preserve the later observation, and preserve the typed gap.**

## 6) What this does not require Schell to decide yet

This seam does **not** require Schell to decide:
- one final `WhatIf` engine,
- one universal dry-run protocol,
- one telemetry warehouse,
- one simulator API,
- one confidence score,
- or one outcome reliability algebra.

The archive only needs to prove a compact honesty stack that says:
- what the preview claimed,
- what exact basis it depended on,
- what later receipt was observed,
- what missed,
- and what remained outside claim.

## 7) Compact conclusion

SlopOS keeps mutable-basis approval exact and refuses sticky follow-the-head review.
Its outcome receipts stay bounded and non-authoritative.
Helm sharpens the exact companion question about predictions, misses, and omissions.
ViewFS, Ward, Harbor, Foundry, and Steward keep neighboring-state, freshness, labels, caveats, and adaptation honest.

So the next Schell move should be:

**add preview settlement cards, outcome-gap strips, miss ledgers, and outside-claim drawers so the shell+terminal can become much smarter about previews without letting simulation or explanation quietly become promise, approval, or live-state truth.**
