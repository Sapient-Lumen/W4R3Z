# Research synthesis, pass LVIII (2026-03-21)

This pass keeps one fresh design rule in focus:
**Schell should absolutely steal modern diff/patch review, dirty-tree isolation, disposable worktrees, and rewind tools — but only if edit proposals stay visibly weaker than live tree truth and the shell+terminal never overclaims what “undo” really covers.**

This seam matters because the current coding-tool wave is genuinely good at code-change comfort.
Generated edits are getting easier to inspect, compare, split, undo, and replay.
That is worth stealing.
But the old trap is also back in a new outfit:
when tools blur proposal, applied patch, working tree, staged state, disposable scratch space, and durable rollback, operators stop knowing what is actually safe to accept.

## 1) Git's patch tools still teach the right first lesson: partial review is real power

Git's own patch model is still one of the cleanest lessons for Schell.
`git add -p` lets the user choose hunks interactively before staging them, and `git add --edit` goes further by opening a patch for direct editing before application to the index.
That is both powerful and cautionary.
The power is obvious: partial, hunk-level review is a humane way to accept only the parts you meant to accept.
The caution is equally important: once humans can edit a patch directly, the UI must be explicit that they are no longer only inspecting — they are constructing a new patch proposal.
Schell should absolutely steal hunk-wise review and selective apply.
It should also name the difference between “inspect”, “edit proposal”, and “apply”.
See: https://git-scm.com/docs/git-add
See: https://git-scm.com/book/en/v2/Git-Tools-Interactive-Staging

## 2) Git also teaches undo humility very clearly

Git's docs remain blunt that some recovery operations are dangerous.
`git restore <file>` discards local changes, and `git revert` requires a clean working tree because it records a new commit that inverses an earlier patch.
That is a terrific Schell lesson.
Different undo verbs mean different things:
- discard local uncommitted changes,
- reverse a committed patch with a new patch,
- or restore one tree from another.
A terminal that says only “undo” is usually lying by omission.
Schell should carry undo class explicitly instead of treating every recovery action as one generic rewind story.
See: https://git-scm.com/book/be/v2/Git-Basics-Undoing-Things
See: https://git-scm.com/docs/git-restore
See: https://git-scm.com/docs/git-revert

## 3) Jujutsu shows how diff surgery can feel editor-grade without turning history into a blur

Jujutsu's current docs are a strong clue that diff-first revision surgery can feel surprisingly humane in the terminal.
`jj split` starts a diff editor to split one revision in two; `jj diffedit` edits diffs directly; `jj undo` and `jj redo` walk the operation history rather than pretending all rewinds are the same.
That is exactly the kind of luxury Schell should admire.
The key lesson is not “adopt jj's model wholesale.”
The key lesson is that the system can expose **operation-local rewinds**, **diff editing**, and **split acceptance** as separate verbs.
Those are different from generic shell history and different from generic filesystem rollback.
See: https://jj-vcs.github.io/jj/latest/cli-reference/
See: https://jj-vcs.github.io/jj/latest/git-command-table/
See: https://jj-vcs.github.io/jj/latest/config/

## 4) Aider teaches dirty-tree isolation better than many fancier products

Aider's git integration docs are refreshingly concrete.
It auto-commits its own edits with descriptive commit messages, offers `/undo`, and takes special care with dirty files by first committing preexisting changes so agent edits stay separated from what was already there.
That is an extremely useful Schell lesson.
Before an assistant or workflow edits a tree, the system should make the existing local basis legible and avoid blending old unreviewed dirt with new proposed changes.
That does not force auto-commit as the one answer.
But it strongly suggests that **dirty-isolation posture** should be explicit.
See: https://aider.chat/docs/git.html
See: https://aider.chat/docs/usage/commands.html

## 5) Codex sharpens the review-scope and isolation story

Current Codex docs expose a helpful trio of review scopes:
review against a base branch,
review uncommitted changes,
and review a specific commit.
That is a beautiful Schell clue because it keeps review basis explicit.
Separate docs on worktrees push the lesson further: background automations can run on dedicated Git worktrees so they do not conflict with the ongoing local task.
That is exactly the kind of decision-light luxury Schell should steal.
The system does not need one universal patch substrate yet.
It needs a small set of explicit isolation stances.
See: https://developers.openai.com/codex/cli/features/
See: https://developers.openai.com/codex/workflows/
See: https://developers.openai.com/codex/app/worktrees/
See: https://developers.openai.com/codex/agent-approvals-security/

## 6) Claude Code sharpens the checkpoint boundary

Claude Code's current checkpointing docs say it tracks Claude's file edits and can rewind those code changes.
That is useful.
But its sandboxing and broader security docs reinforce the more important lesson: sandbox boundaries and permissions define where the tool can act, not what history can be perfectly unwound.
This matters because users love hearing “you can always undo it.”
In reality, file edits, shell commands, network calls, service launches, package installs, and remote mutations do not share one rollback story.
Schell should therefore separate:
- patch rewind,
- tree reset,
- disposable worktree drop,
- reversible VCS revert,
- and non-rewindable external side effects.
See: https://code.claude.com/docs/en/checkpointing
See: https://code.claude.com/docs/en/sandboxing

## 7) The dangerous thing to refuse: blended patch folklore

Several modern tools make change generation feel smooth enough that the operator can forget what object is actually under review.
That is the danger.
A generated inline diff is not automatically a live tree.
A dirty working copy is not the same as a clean base plus a proposed patch.
A checkpoint is not a revert commit.
A disposable worktree is not the active tree.
A code review summary is not the same thing as a patch witness.
Schell should keep these distinctions explicit before it invents any especially charming patch UI.

## 8) The stealable move: patch witnesses plus dirty-isolation posture

The best decision-light move now looks like this:
1. introduce a **patch witness** as a first-class review object,
2. make its basis explicit (base tree/revision/worktree/selection),
3. show touched paths and hunk counts before stronger actions,
4. keep **inspect**, **edit proposal**, **apply**, **stage selected hunks**, **commit**, **revert**, and **drop scratch** as separately named verbs,
5. surface a **dirty-isolation posture** such as clean tree, dirty local tree, disposable worktree, or scratch overlay,
6. give every proposed patch an **undo class** instead of one generic undo promise,
7. and let generated edits land in disposable worktrees or scratch zones first whenever basis ambiguity is high.

That would make Schell feel dramatically more capable without freezing one final VCS, patch format, branch/worktree model, or rollback architecture.

## 9) A compact first proving slice

A compact proof could show:
- one assistant-generated patch witness against a clean base,
- one patch witness against a dirty tree that refuses direct apply and offers isolation first,
- one selective hunk-accept path,
- one patch edit path that changes the proposal before apply,
- one disposable-worktree apply path,
- one explicit promote-from-worktree path,
- one review card that says undo class = drop-worktree,
- one review card that says undo class = revert-with-new-commit,
- and one side effect receipt that says no patch rewind is available for the external action.

That would be enough to learn a lot while keeping the big decisions open.
