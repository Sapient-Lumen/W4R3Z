# Research synthesis — 2026-03-23 — pass CXL

This pass sharpens one fresh shell+terminal lesson from current upstream docs:
**the modern terminal no longer has one obvious input surface. Current tools increasingly mix shell-owned prompt editing, terminal-owned editors, embedded handback prompts, and dedicated agent/chat composers — which makes input-host honesty a real design seam rather than a cosmetic preference.**

## 1) Warp now openly supports more than one input-host posture

Warp's current docs are useful because they no longer hide the split.
Classic Input keeps a more traditional shell/PS1-style prompt experience, while Warp also exposes a more terminal/editor-owned input experience and a distinct agent modality with a dedicated conversation view.
That is a strong design signal for Schell.
A future shell+terminal probably does need multiple input-host postures; it just should not pretend they are the same truth class.

## 2) Ghostty's new prompt-click work shows the terminal can edit *inside* a prompt when the marks are good enough

Ghostty 1.3.0 now supports click-to-move within active shell prompts through the OSC 133 semantic prompt extensions, and Ghostty's shell-integration docs make clear that many features depend on shell integration being present or injected.
That is exactly the right kind of stealable idea: make the active prompt feel like a field when the prompt boundaries are authenticated well enough.
It is also the warning label.
This comfort depends on integration quality and should stay weaker when marks are partial, injected, mux-relayed, or absent.

## 3) VS Code keeps proving that shell-integrated prompt truth can be useful and still confidence-scoped

VS Code's terminal appearance docs expose variables such as `${shellCommand}` and `${shellPromptInput}`, but they also say command extraction requires high confidence and may not work in some prompt frameworks.
That is a very Schell-shaped lesson.
Even when a product can show prompt input or the current command beautifully, it is still often working with confidence-scoped shell integration rather than absolute prompt truth.

## 4) Embedded terminals make temporary handback prompts real product terrain

VS Code 1.109 made embedded terminals fully interactive so people can focus them and type directly when a command needs confirmation or input.
That matters because it means a terminal host can now expose input inside a sidecar or embedded surface without pretending the operator is simply “back at the shell prompt.”
This is a good design seam for Schell: some input is live shell prompt input, some is local editor input, and some is an embedded handback interaction that needs its own ownership label.

## 5) The ecosystem is converging on a quieter lesson than “universal input”

The nicest current ideas are not really about one magic input bar.
They are about making nearby input surfaces feel great while quietly narrowing what each one claims:
- shell-owned prompt input,
- terminal-owned staged editing,
- prompt-marked hybrid assistance,
- embedded confirmation/input,
- and conversation/task composition.

That is a better framing than “terminal input versus shell input” because it leaves room for several honest lanes instead of forcing a fake binary.

## 6) The stealable move is host-aware delight

The best move to steal is small and sharp:
**let the shell+terminal feel luxurious by advertising which input host is active, what confidence the prompt marks have, what Enter will do there, and how stronger shell truth is acquired from that host.**

That unlocks:
- prompt-click cursor motion,
- richer command-line editing,
- obvious mode switching,
- humane sidecar prompts,
- better draft/review flow,
- and a cleaner agent/shell split,

without teaching users that every editable surface near the terminal is equally authoritative.

## 7) Compact conclusion

Current docs now show several real input-host classes in the wild.
Warp explicitly supports classic shell input and distinct agent-centric input postures.
Ghostty proves prompt-click editing becomes real once semantic prompt marks are good enough.
VS Code keeps shell-integrated prompt truth confidence-scoped and now supports fully interactive embedded terminals for commands that need input.

Schell should take the hint.
It needs a first-class split between **shell-owned prompt**, **terminal-owned editor**, **prompt-marked hybrid**, **embedded handback prompt**, and **agent/conversation composer** so the future shell+terminal can feel dramatically nicer without letting every nearby input surface impersonate the same kind of shell truth.
