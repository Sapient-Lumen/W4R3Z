# Research synthesis — 2026-03-23 — pass CLXXIII

This pass sharpens one fresh lesson from current desktop, activation, and terminal docs:
**modern systems increasingly preserve narrow start or activation causes, but operators still lack one tiny visible explanation of why a shell/terminal surface appeared right now.**

## 1) Global shortcuts are already typed arrival causes, not generic focus magic

The XDG GlobalShortcuts portal creates explicit shortcut sessions and emits `Activated` / `Deactivated` signals with a `shortcut_id`, timestamp, and optional `activation_token`.
That is a strong clue for Schell.
A shortcut summon is not just “the app somehow focused.”
It is one exact arrival cause with its own identifier and moment.

## 2) Notification activation is also a distinct start cause

Windows App SDK notification registration uses dedicated activation arguments so the app can tell the launch came from an app notification.
Related Windows docs also say the app can inspect activation arguments to determine that the activation was launched by a notification and then decide whether to fully launch or merely handle the activation and exit.

That is precisely the kind of explanatory residue Schell should steal.
The useful question is not only whether the app surfaced.
It is also whether the surface exists because of a notification return.

## 3) URI/protocol activation keeps another distinct arrival family

Windows URI activation docs say apps can inspect activation event args and the `Kind` property to determine how the app was activated, including protocol activation.
That means a browser/deep-link return is already a typed cause in real platforms rather than an implementation detail.

Schell should import that lesson.
A protocol return should not look identical to a fresh manual shell launch or a duplicate-nearby split.

## 4) App lifecycle instancing docs keep activation kind separate from later routing

Windows app lifecycle docs show redirection logic based on activation kind, including redirecting a file activation to an existing instance.
That is very useful pressure.
A single arrival can have:
- one start cause,
- one routing decision,
- and a different later active-control story.

Schell should keep those separate.
The arrival strip should answer why the surface exists.
Activation receipts and footing strips can answer the other two questions.

## 5) freedesktop activation still carries cause-adjacent platform data distinctly

The Desktop Entry D-Bus activation spec says `platform-data` can carry `desktop-startup-id` and `activation-token`, mirroring `DESKTOP_STARTUP_ID` and `XDG_ACTIVATION_TOKEN`.
The older startup-notification protocol was explicitly about tracking application startup to provide user feedback and related features.

That is another clue that launch cause deserves a small visible object.
Even when the implementation substrate differs, the user-facing question “what started this?” persists.

## 6) Current terminals keep nearby spawn classes distinct rather than pretending all arrivals are one clone story

Ghostty 1.3.0 now has separate working-directory inheritance controls for windows, tabs, and splits.
VS Code shell integration keeps command-local status and explanation in hovers/decorations instead of leaving command boundaries to vague scrollback guesswork.
These are not full start-cause systems, but they point in the same product direction: nearby context and explanation matter, and distinct spawn classes should stay visible rather than collapsing into one flattering new-pane myth.

## 7) The no-regret Schell move is a tiny arrival strip

Putting these together suggests a better next move than a giant lifecycle browser.
Schell should add a tiny **arrival strip** for newly visible rooms, lanes, and helper surfaces.
It should say:
- why the surface appeared,
- whether footing was fresh, inherited, or restored,
- whether activation residue is linked,
- and what the strongest honest next move is now.

## 8) Compact conclusion

Global shortcuts already arrive as typed events.
Notifications can identify notification-launched activation.
URI/deep-link flows have their own activation kinds.
App lifecycle docs keep activation kind separate from later routing.
Freedesktop keeps startup/activation platform data explicit.
Modern terminals keep nearby spawn classes distinct and increasingly explain command-local state.

So the next no-regret Schell seam is not a giant lifecycle graph.
It is **arrival strips and tiny start-cause cards** so new rooms, shortcuts, notification returns, protocol callbacks, duplicates, and restored surfaces can immediately say why they exist without pretending that start cause, active control, and current footing are the same truth.
