# Research synthesis, pass XXXV (2026-03-21)

This pass focuses on one specific seam:
**modern terminals can now show inline images and richer previews, but Schell should steal the parts that make object handling feel incredible without letting renderer-local pixels become shell truth, transcript requirements, or durable preview residue.**

## 1) kitty proves that terminals can host serious inline graphics

kitty's graphics protocol is ambitious on purpose.
Its design goals explicitly include arbitrary raster graphics, drawing at individual pixel positions, integration with text, alpha blending, scrolling with text, and same-host optimizations.
That matters because it proves “inline media in a terminal” is no longer a toy idea.
It can support real operator surfaces.

For Schell, the important lesson is not “copy kitty exactly.”
It is: **rich inline media is now a real terminal affordance, so the archive should name an honest boundary before protocol excitement chooses the architecture.**

## 2) iTerm2 shows the power and scope creep of inline-image transports

iTerm2's inline images protocol can display images in the terminal and also facilitate file transfers over arbitrary transports such as ssh or telnet.
The docs also make the split explicit: the same family can either show something inline or download it without visual representation.
That is an excellent reminder that render, transfer, and durable materialization are not one verb.

The protocol docs also expose chunking and tmux-related transport complexity.
That is useful pressure for Schell: terminal luxury features may be worth having, but the **portable core should not depend on one escape-sequence family making it through every mux/SSH/replay path.**

## 3) WezTerm confirms protocol reuse is useful and still not universal

WezTerm implements the iTerm2 inline-images protocol and ships an `imgcat` subcommand.
But its docs also say the image protocol is not fully handled by multiplexer sessions at this time.
That is a very practical lesson.
Even when terminals intentionally interoperate, inline-media behavior still has transport seams and degradation paths.

Schell should learn from that directly:
- the rich renderer can be brilliant,
- but transcript truth and headless truth still need a text-first fallback.

## 4) Ghostty shows the feature race is real

Ghostty's feature docs now list kitty graphics support as one of the protocol-level capabilities it offers terminal application developers.
That means the custom-shell question is no longer hypothetical.
The terminal ecosystem is actively normalizing richer protocols so terminal applications can do more than legacy text surfaces allowed.

The right import for Schell is not “standardize on one graphics protocol today.”
It is: **assume richer local rendering will exist, but keep renderability weaker than shell-owned object truth.**

## 5) Desktop preview systems are a warning label, not just inspiration

Apple's Quick Look offers a fast, full-size preview without opening the file in its associated application.
But the same Quick Look window can also rotate photos, trim audio/video, and use Markup.
That is a powerful reminder that “preview” is not a harmless neutral state.
It quickly accumulates actions, mutation-adjacent affordances, and user expectations.

Windows preview-handler docs make the same point from a different angle.
Preview handlers are a distinct hosted component, run out of process, low integrity is recommended by default, scripts and macros should be blocked, UI should stay minimal, and startup should stay fast.
That is basically a design memo for Schell:
**preview is already its own execution/parsing boundary, with safety and latency requirements of its own.**

## 6) The decision-light import is visible now

A compact Schell import could be:
- one **media witness** object tied to an exact object/output basis,
- one local **viewlet** notion for renderer-local inline presentation,
- one explicit ladder: `inspect metadata` / `render inline` / `open` / `safe-open` / `materialize` / `share`,
- one **text/transcript stub** that survives mux/SSH/logging when pixels do not,
- one **residue posture** for whether rendered previews are transient-local, restored, or unknown,
- and one rule that ambient selection/hover/search should not auto-render risky bytes.

That is enough to learn a lot without choosing:
- the final graphics protocol,
- the final image/video/PDF renderer stack,
- the preview-cache format,
- the mux transport story,
- or the remote rendering architecture.

## 7) Good steals that stay bounded

Some genuinely great ideas worth stealing carefully:
- **inline plot/object viewlets** tied to exact object refs rather than arbitrary terminal escape output,
- **image diff or thumbnail compare cards** for outputs that are naturally visual,
- **click-to-expand inspect panes** that are visibly weaker than open/edit,
- **renderer-local cached derivatives** that can make restored sessions feel fast while staying historical until refreshed,
- and **protocol-gated progressive enhancement** so the custom terminal can be amazing locally without breaking plain SSH or transcript export.

## 8) The lesson we must learn from the past

The old mistake was thinking terminals could only ever be text.
The new mistake would be thinking that because terminals can render pixels, the rendered pixels are automatically the shell's truth.

The better answer is:
- shell truth stays object-first,
- renderer-local viewlets stay explicit,
- render stays distinct from open/materialize/share,
- transcripts keep text-safe stubs,
- and preview residue stays weak, local, and obviously historical when restored.
