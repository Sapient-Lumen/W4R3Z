# SlopOS datacube evaluation, pass CVII (2026-03-22)

This pass evaluates one narrower question against the current SlopOS archive:
**what does the companion already teach Schell about bells, finish notices, notification transports, notification clicks, and the danger of letting transient attention cues outrank durable shell truth?**

The answer is unusually crisp because SlopOS already has excellent attention scar tissue:
**attention authority is real, scarce, origin-branded, budgeted, and action-constrained; transient cues may request attention, but they do not become durable outcome truth or cheap approval surfaces.**

## 1) RFC-0055 is the direct companion lesson

The companion's attention-authority posture is exactly the right pressure here.
Notifications are treated as explicit notification-portal requests.
Payloads stay bounded and non-executable.
Origin branding matters.
Channels and budgets matter.
And actions that would widen authority need fresh volition plus ordinary review/receipt handling.

Applied to Schell, that means:
- a bell is not proof of completion,
- a toast is not a receipt,
- a badge is not durable status,
- and a clicked notification must not become a hidden approval shortcut.

## 2) The durable-status boundary says the same thing in shell terms

The companion already teaches that transient UI chrome should not become the only durable carrier of consequential truth.
That maps directly onto terminal alerts.
A command-finished toast may be useful.
But if the result matters, Schell still needs a chapter-bound result card, receipt, or shelf state that survives after the cue vanishes.

So the companion-compatible move is not “avoid alerts.”
It is:
**keep transient attention cues weaker than durable result surfaces.**

## 3) D-UICAP and trusted UI pressure sharpen the click story

The current SlopOS archive keeps high-risk UI authority, focus steering, and secure attention on explicit mediated seams.
That matters for terminal notifications because modern terminals increasingly let notifications focus windows, bounce icons, request compositor urgency, or trigger follow-up behavior.

The companion therefore pressures Schell to keep notification clicks on a narrow ladder:
- focus or reveal,
- jump to the exact command chapter or task shelf item,
- show durable state,
- and require ordinary review if the next move would spend more power.

That is much better than letting a notification action bypass the shell's review posture.

## 4) The companion also rewards request-state honesty here

One of SlopOS's recurring lessons is that requester-chosen request identity and provider-owned current live state are not the same thing.
That applies perfectly to terminal notifications.
A shell may have requested a finish notice.
That does not prove:
- it is still pending,
- it was displayed,
- the user saw it,
- the user clicked it,
- or the underlying work is still live.

So a SlopOS-compatible Schell should keep request identity, delivery posture, acknowledgement posture, and durable outcome state separately named.

## 5) The companion-compatible answer is smaller than a final notification architecture

Schell does **not** need to choose:
- one final notification protocol,
- one durable notification inbox,
- one cross-device sync story,
- or one callback-action model

to stay aligned with SlopOS.

It only needs a few bounded rules:

### A) Notification witnesses stay explicit
Treat bells, toasts, badges, finish notices, and progress pings as witnessed attention objects with visible routing and visible suppression.

### B) Result truth stays elsewhere
If the command or task matters, the durable outcome must still live on a chapter/result/shelf surface.

### C) Clicks degrade into reveal and review first
Notification actions may focus or reveal.
They should not silently become spend-authority shortcuts.

### D) Origin and transport stay visible
Shell-authenticated chapter alerts, helper-bridged notifications, and raw terminal-app escape sequences should not all wear the same confidence badge.

### E) Focus and policy stay explicit
If a cue was suppressed, coalesced, or downshifted because the source surface was focused or because budget policy applied, say so.

## 6) Compact conclusion

The SlopOS-compatible answer is not “build a huge notification subsystem.”
It is:
**let Schell steal focus-aware finish alerts, blocked-input reminders, progress pings, and humane desktop notifications, but keep transient attention cues, clicked actions, and durable outcomes as separately named seams.**

That is a strong design-phase-safe move because it improves operator delight immediately while keeping the final wire protocol, inbox/history story, and callback model open.
