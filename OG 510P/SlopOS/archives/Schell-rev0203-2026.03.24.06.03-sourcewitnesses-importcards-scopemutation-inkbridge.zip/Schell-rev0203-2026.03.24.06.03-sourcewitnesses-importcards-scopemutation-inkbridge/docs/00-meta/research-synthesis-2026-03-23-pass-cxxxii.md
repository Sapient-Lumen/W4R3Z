# Research synthesis — 2026-03-23 — pass CXXXII

This pass tightens another seam where modern shell and terminal products are attractive but easy to over-trust:
**imported shell text should move through quarantine, explicit review, and exact endorsement before it becomes reusable convenience.**

## 1) Current tools keep separating editability from direct execution — Schell should keep that separation sharper

VS Code's terminal and chat flows still expose a healthy split:
review a command, then either **run** it or **insert** it for editing.
Warp's workflow editor likewise keeps reusable commands as named, editable objects with parameter fields instead of treating found text as silently ready.
That points Schell toward a stronger default posture for imported shell text: stage, inspect, parameterize, and only then consider stronger reuse.

## 2) iTerm2 and kitty remind us that “send text as though typed” is a real authority boundary

iTerm2's triggers and Captured Output features can connect matched output to actions that send configured text as though typed.
kitty's remote-control and send-text surfaces likewise make it easy to inject text, with optional bracketed-paste wrapping.
Those are powerful luxuries, but they prove a larger design lesson:
text-injection surfaces are not merely navigation or preview features.
They cross into authorship and execution posture.
Schell should therefore keep inspect/insert/quote/draft/endorse/run visibly separate wherever output or helper features can generate command text.

## 3) Unsafe-paste UX teaches a subtle but important product rule

Ghostty's recent release notes mention that the text field in unsafe-paste confirmation is no longer editable.
That small change is more important than it looks.
A warning prompt should mirror the risky arrival, not become the place where the text is casually rewritten until it “feels fine.”
For Schell, that suggests exact mirror cards and separate draft editors instead of warning dialogs that quietly launder foreign shell text into apparent reviewed authorship.

## 4) The best shell+terminal version of this is a quarantine-to-endorsement ladder

The no-regret move is not a giant reputation system.
It is a small ladder:

- foreign arrival,
- quarantine ribbon,
- exact mirror card,
- insert / quote / draft / endorse actions,
- endorsement receipt,
- and maybe later a reusable local seed or replay lease.

That keeps open the future format of workflow packs, shared runbooks, snippet catalogs, and sync, while still collecting a very strong operator luxury right now.

## 5) The most important steal is derivative trust, not source laundering

Current tools are good at turning discovered text into something runnable.
Schell should steal the comfort, but improve the trust story:
a risky arrival should be able to produce a **reviewed derivative seed** while the original source stays marked as foreign or quarantined.
That is a much healthier way to keep provenance, review, and reuse all visible at once.

## 6) Compact conclusion

The common pattern across today's products is clear:
**shell text often arrives from somewhere other than direct authorship, and the humane answer is not to ban that convenience but to badge it, stage it, and admit it explicitly before reuse.**

For Schell, that points toward **quarantine ribbons, exact mirror cards, endorsement receipts, and derivative-only promotion** rather than toward one-click trust laundering of imported snippets or captured-output actions.
