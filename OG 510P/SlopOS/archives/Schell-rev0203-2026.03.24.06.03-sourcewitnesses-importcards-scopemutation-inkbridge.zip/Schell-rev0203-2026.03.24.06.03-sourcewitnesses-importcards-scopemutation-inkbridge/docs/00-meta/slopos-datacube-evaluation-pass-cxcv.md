# SlopOS datacube evaluation — 2026-03-24 — pass CXCV

**Schell should treat expansion as a visibly staged local preparation step rather than as hidden reviewed truth, because SlopOS and the companion cubes keep rewarding exact basis, local/provider boundary discipline, visible labels, revalidation, omission honesty, and neighboring-state separation.**

## 1) SlopOS keeps exact basis narrower than helper packaging

SlopOS keeps importing provider-local auth and protocol mechanics without letting them silently widen into portable durable truth.
That pressure maps directly onto shell expansion.
A brace rewrite, tilde rewrite, wildcard match set, or helper-provided glob preview may be very useful, but it should stay weaker than the exact reviewed command basis and weaker still than the later execution receipt.

So the companion-safe import is:
- expansion may help,
- preview may be rich,
- samples may be shown,
- compatibility may matter,
- but exact reviewed spend still needs its own explicit witness lane.

## 2) SlopOS plumb posture again argues for suggest / inspect / admit / compare

Request-local plumb posture is a very nearby lesson.
Expansion surfaces should be excellent at **suggest / inspect / admit / compare**.
They should be much more cautious about silently rewriting the basis of the command before review.

That means a pattern preview can be rich, but it should confess:
- what family of expansion is being discussed,
- how many matches are currently in scope,
- whether the preview is partial,
- what no-match posture stands,
- and whether the final reviewed command still needs revalidation before spend.

## 3) Provider-locality pressure says preview packaging is not command truth

The newest SlopOS work keeps reasserting a boundary between provider-local packaging and portable archive meaning.
Expansion previews deserve the same treatment.
A local glob engine, shell option, helper pack, or terminal-side expansion summary should not quietly become the command's durable reviewed truth.
Otherwise local presentation posture turns into a hidden second authority plane.

## 4) ViewFS again supplies the best neighboring-state discipline

ViewFS keeps editable text, parse understanding, diagnostics, compiled packets, prepared actions, and history distinct.
That same discipline should govern expansion:
- typed token,
- expansion plan,
- current match set,
- no-match policy,
- admitted reviewed command,
- and later execution receipt

should remain neighbors rather than collapsing into one flattering "the shell expanded it" object.

## 5) Harbor, Ward, Steward, and Helm keep the seam honest

- **Harbor** reinforces label honesty, which matters when Schell should say whether a result came from brace rewrite, tilde rewrite, wildcard expansion, parameter/provider matching, or literal no-expand posture.
- **Ward** reinforces revalidation pressure, which matters when the filesystem changes between preview and spend.
- **Steward** reinforces trim/freshness posture, which matters when large match sets are summarized, cached, or intentionally pruned for UI reasons.
- **Helm** reinforces omission and miss posture, which matters when preview surfaces show samples instead of the full set or when unmatched-pattern policy changes what gets passed along.

Together they keep one rule sharp:
**expansion can improve comfort, but it must not erase labels, freshness/revalidation posture, omitted-match honesty, or exact reviewed basis.**

## 6) What this still does not require Schell to decide

This seam does **not** require Schell to decide:
- one final wildcard grammar,
- one final cross-shell compatibility layer,
- one final filesystem search/cache backend,
- one final quote/escape pedagogy,
- one final pattern-preview renderer,
- or one final dual-view history/export format.

The archive only needs to prove the honesty stack that says:
- what exact token was typed,
- what expansion family participated,
- what current match set or sample was observed,
- what no-match rule stands,
- what reviewed command basis was admitted,
- and what later receipt confirms or contradicts that basis.

## 7) Compact conclusion

SlopOS keeps exact basis narrow and explicit.
ViewFS keeps neighboring states separate.
Harbor, Ward, Steward, and Helm keep labels, freshness, omission, and revalidation honest.

So the next Schell move should be:

**add expansion witnesses, glob reveals, no-match receipts, literal-override posture, and revalidation compare so Schell can steal shell-pattern comfort without letting invisible expansion quietly become reviewed truth.**
