# SlopOS datacube evaluation, pass CV (2026-03-22)

This pass evaluates one narrower question against the current SlopOS archive:
**what does the companion already teach Schell about external-editor roundtrips, draft export, return semantics, and the danger of hidden callback/writeback folklore?**

The answer is stronger than “be careful with temp files.”
**SlopOS already pressures Schell to treat exported drafts, editor-mediated return, mutable-basis comparison, and later reviewed execution as different seams instead of one flattering “the editor saved, therefore the shell should continue” story.**

## 1) The callback-reentry boundary is exactly the right warning

The companion's OpenURI callback-reentry boundary is unusually clarifying here.
It freezes a simple rule: mediated launch is one-way request plus request-local completion, not a hidden callback bus or portable “call me back when you are done” contract.

That is direct pressure on Schell.
An external editor bridge should not pretend that launching an editor automatically gives the shell a magical callback/reentry authority story.
If a draft leaves the prompt, the shell still needs its own explicit return path and merge semantics.

For Schell this implies:
- editor launch is not enough,
- editor exit is not enough,
- save/close is not a reviewed action receipt,
- and any return-to-buffer merge needs its own exact shell-owned witness.

## 2) The bearer→docref bridge teaches fresh draft identity

The companion's import-to-docref posture is equally helpful.
It insists on explicit materialize-first semantics, fresh local object identity, and no hidden “reuse existing” collapse merely because bytes happen to match something local.

That is an excellent fit for editor bridges.
An exported draft object should not quietly become “the same thing as the live prompt” just because the text looks similar.
A returned file should not silently inherit the old buffer's identity or review basis without an explicit compare-and-set step.

For Schell this implies:
- exported drafts deserve explicit object identity,
- repeated roundtrips should not quietly alias one another,
- and saved content equality is not enough to skip basis checks or merge confession.

## 3) Trusted-UI approval-basis honesty sharpens the post-return rule

The companion's trusted-UI adjunct family keeps mutable approval basis explicit.
Approvals do not silently follow a newer head or a drifted mutable object.

That is almost a direct template for editor roundtrips.
If a command draft was reviewed before export and returns changed, the shell should not inherit the old review.
Even if the draft only changed slightly, the exact reviewed basis has changed.

So Schell should keep:
- pre-edit reviewed basis,
- exported draft basis,
- returned draft delta,
- and fresh post-return review

separately named.

## 4) Request-state honesty helps with editor/process confusion too

The companion repeatedly separates requester-chosen request identity from provider-owned current live state across jobs, background grants, notifications, and other workflow families.
That discipline is useful here as well.

A launched editor process, a temp path, and a returned draft are not the same state object.
The existence of the draft file or the editor PID does not prove that a save happened, that a merge happened, or that the shell accepted the returned text into the live buffer.

This is exactly the kind of drift SlopOS refuses elsewhere.
Schell should refuse it here too.

## 5) The companion-compatible shape

This pass therefore recommends a bounded import shape.

### A) Editor-bridge witnesses
Treat exported drafts, editor source, basis posture, return posture, and submit posture as an explicit shell-known seam.

### B) Fresh draft identity
Keep externalized draft objects as fresh local identities rather than pretending they are the live buffer itself.

### C) Compare-and-set return
Make return-to-buffer an explicit merge against named mutable basis rather than hidden callback folklore.

### D) No implicit autorun
Neither editor save nor editor exit should become portable execution authority.

### E) Readonly export stays separate from writable return
Inspecting something in a real editor and roundtripping edits back into the shell are different actions and should stay separately named.

## 6) Compact conclusion

The SlopOS-compatible answer is not “never use a real editor.”
It is:
**let Schell steal excellent external-editor comfort, but keep editor launch, draft identity, return merge, mutable-basis comparison, and later reviewed execution as separately named seams.**

That is a very strong design-phase-safe move because it improves humane authoring immediately while keeping the final editor transport, document bridge, and IDE architecture open.
