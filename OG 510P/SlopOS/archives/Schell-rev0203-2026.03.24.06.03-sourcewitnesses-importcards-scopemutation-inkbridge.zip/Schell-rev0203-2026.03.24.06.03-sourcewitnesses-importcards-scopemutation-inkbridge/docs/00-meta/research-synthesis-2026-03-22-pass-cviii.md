# Research synthesis, pass CVIII (2026-03-22)

This pass keeps one historical rule in focus:
**the shell+terminal gets much more honest when interrupt, suspend, hangup, disown, nohup, detach, and durable promotion are treated as different continuity moves instead of one flattering “I stopped it / it kept going” blur.**

The current ecosystem still shows why this matters.
Bash's current manual says job control is supplied jointly by the kernel's terminal driver and the shell, and ties jobs to pipelines and process groups.
Its signal section then makes the ambiguity explicit: with job control enabled, keyboard-generated signals go to the foreground process group; when Bash exits on `SIGHUP`, it resends `SIGHUP` to jobs and even sends `SIGCONT` to stopped jobs so they receive it; `disown` can instead remove a job or suppress the shell's hangup behavior.
fish keeps the same surface more humane, but not less complicated: `fg`, `bg`, `wait`, `disown`, and `suspend` are all distinct, and `disown` even resumes a stopped job before forgetting it.
zsh then shows how much policy shells keep layering on top: `AUTO_CONTINUE`, `AUTO_RESUME`, `CHECK_JOBS`, `CHECK_RUNNING_JOBS`, `HUP`, `NOTIFY`, and `POSIX_JOBS` all exist because the old story is not small enough by itself.

The OS and tooling ecosystem adds one more sharp lesson.
`nohup` ignores `SIGHUP` and rewires output, but it is not supervision.
`setsid` starts a new session and affects controlling-terminal hangup behavior, but it is not a reviewed durability move.
`systemd-run` explicitly distinguishes transient `.service` and `.scope` units, and even warns that the default `Type=simple` may report startup success before `execve()` happens unless `Type=exec` is requested.
kitty's `signal_child` action is also very clarifying: terminals can absolutely offer richer signal actions, but that only makes target truth more important because a terminal gesture can otherwise feel stronger and more universal than it really is.
WezTerm's terminal explainer gives the kernel-side picture cleanly: `Ctrl-C` turns into `SIGINT` for the foreground process and `Ctrl-Z` suspends the foreground process if the shell supports job control.

## 1) Old shell stop semantics are really several different contracts

The first lesson to steal is not an implementation detail.
It is a naming rule.
At minimum, a modern shell+terminal needs to distinguish:
- interrupting foreground work,
- suspending foreground work,
- backgrounding shell-tracked work,
- waiting without foreground reacquisition,
- severing hangup/session coupling,
- ignoring hangup,
- detaching into workspace/mux continuity,
- and promoting into supervised durability.

Bash, fish, zsh, `nohup`, `setsid`, and `systemd-run` all prove that these are real neighboring moves with different outcomes.
The classic shell surface simply makes them too easy to confuse.

## 2) `Ctrl-C` is not a generic cancel plane

WezTerm's explainer is useful because it says the quiet part plainly: `Ctrl-C` is a terminal-driver translation into `SIGINT` for the foreground process group, not an abstract universal cancel plane.
Bash then adds that when job control is not enabled the shell may itself receive keyboard-generated signals because it is in the same process group as the command.

That means Schell should avoid two opposite mistakes:
- do not pretend keyboard interrupts are a universal portable semantic plane,
- but also do not flatten all stop gestures into raw POSIX signal folklore.

The better move is to witness **delivery family** and **target family** separately.

## 3) Hangup, disown, and durability are different stories

fish's `disown` doc is excellent evidence here.
The job continues to exist, but fish loses knowledge of it; on shell termination, jobs still in fish's list are sent hang-up; and a stopped job that gets disowned is continued first.
zsh adds `HUP` and `CHECK_JOBS` policies, while POSIX `nohup` simply ignores `SIGHUP` and redirects output as needed.
Those are not interchangeable.

So the most important no-regret insight is:
**“keep running when I leave” should not be one operator promise.**

There are at least four different promises hiding there:
- shell stops tracking,
- shell will not send hangup,
- session/tty relationship changed,
- work now has a new durable owner.

## 4) Promotion is a different luxury than stop

The ecosystem gives a very stealable pattern here.
Instead of teaching users to stack `&`, `disown`, `nohup`, `setsid`, and terminal lore until the command happens to outlive them, let the shell make **promote to durable owner** an explicit move.

`systemd-run` is especially good evidence because it already separates transient service mode from scope mode, and because `Type=exec` is a reminder that even “started” has to be named carefully.
That suggests a strong Schell luxury:
- foreground stop ladder on one side,
- explicit durable promotion ladder on the other.

That is much safer than letting stop, sever, and promote masquerade as the same axis.

## 5) The best terminal steals are reveal-first and target-explicit

kitty's `signal_child` proves there is value in terminal-local signal actions, but it also proves the terminal should not guess too much.
The best moves to steal are therefore:
- a visible foreground-owner chip,
- a stop/escalate card that shows the next stronger move,
- exit-with-jobs truth that separates tracked, disowned, detached, and promoted work,
- and receipts that say interrupted/suspended/terminated/hangup-severed/promoted instead of hiding behind folklore alone.

## 6) Compact conclusion

One of the smartest no-regret moves available right now is:
**make the stop ladder first-class, but keep interrupt, suspend, hangup, disown, detach, and durable promotion separately named with explicit target and continuity posture.**

That lets Schell steal humane interruption UX, exit warnings, wait/reattach comfort, and durable promotion rails without prematurely deciding the final signal backend, supervisor treaty, remote translation model, or receipt vocabulary.
