# SlopOS datacube evaluation, pass LXXIV (2026-03-22)

This pass evaluates one new companion import:
**Schell should absolutely grow detached-work witnesses, task shelves, and explicit attach/rerun/promote ladders, but SlopOS pressure says local backgrounding, detached request identity, transient status cues, and historical panes must all remain separately named instead of collapsing into one flattering task myth.**

## 1) SlopOS already gives the crucial split: background presence is not deferred jobs

The companion archive is very explicit on D-BGLEASE posture.
Background execution and login autostart must be explicit.
There are no ambient background constructors after init.
And deferrable work should prefer jobs rather than background-presence posture.
That is exactly the discipline Schell needs.
A shell+terminal should stop flattening:
- local background jobs,
- detached queues,
- durable background presence,
- and promoted service posture.
Those are nearby stories.
They are not one story.

## 2) SlopOS also gives the key request-identity rule

The background-request-state posture is one of the strongest lessons in the whole companion archive:
`req_id` is requester-chosen request identity, not portal-issued live grant truth.
Historical request artifacts do not prove that a current live background/autostart grant still exists.
That maps directly onto shell+terminal task UX.
Schell should let operators keep request keys, task ids, rerun keys, and notification identifiers — but it should keep them visibly weaker than current ownership and current live state.

## 3) Durable-status boundary pressure is exactly what task UX needs

The attention durable-status boundary says transient notifications, banners, snackbars, and glows do not become the durable carrier of consequential outcome truth.
That is a decisive lesson for the custom shell+terminal.
Finish notices, dock badges, status glows, and “done” toasts are all wonderful.
They are still weaker than:
- exact result cards,
- explicit route/state surfaces,
- durable receipts,
- and current live task witnesses.
Schell should therefore treat cue state and durable result state as different rails.

## 4) SlopOS already warns against overclaiming observational sidecars

The capshell result sidecar boundary keeps richer telemetry or result description observational and non-authoritative.
That lesson imports cleanly here.
Task logs, progress badges, queue metadata, finish notifications, and restored scrollback are extremely useful — but they should not redefine the exact result identity or present-tense liveness of work.

## 5) The companion archive also keeps hidden persistence on a short leash

D-BGLEASE keeps background work explicit, review-bound, revocable, user-legible, and killable.
That is the right pressure for any Schell helper lane, queue lane, or promoted-work lane.
If some work leaves the current pane or current prompt, the operator should be able to see:
- who owns it now,
- whether it is still killable locally,
- whether it is detached,
- whether it is durable,
- and what exact surface can still speak truth about it.

## 6) The best SlopOS-compatible moves from this seam now look no-regret

The strongest companion-compatible moves are:
- **detached-work witnesses** separating local job / pane command / project deck / detached queue / promoted service / restored history,
- **task shelves** separating request identity, current live state, cue state, and closing witness,
- **orphan posture badges** such as tracked / detached / owner-exited / shell-untracked / historical,
- **cue-vs-result ladders** so notifications and status glows stay weaker than durable outcome truth,
- **attach / inspect-log / rerun / promote ladders** rather than one vague resume action,
- and **restored-state banners** that keep historical panes historical until rerun or live reattach.

## 7) Things this pass still refuses to decide too early

This pass does **not** force:
- one final queue daemon,
- one final task-shelf or status-center storage model,
- one final launcher or attach surface,
- one final notification transport,
- or one final resurrection/reattach substrate.

The answer is smaller and stronger:
**admit detached work on explicit honesty ladders, keep request ids weaker than live state, keep transient cues weaker than durable truth, and keep restored task context historical until live ownership is reacquired.**
