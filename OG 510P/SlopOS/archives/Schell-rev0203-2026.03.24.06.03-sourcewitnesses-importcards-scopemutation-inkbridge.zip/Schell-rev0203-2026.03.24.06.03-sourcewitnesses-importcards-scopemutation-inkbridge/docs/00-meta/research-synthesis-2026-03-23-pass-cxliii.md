# Research synthesis — 2026-03-23 — pass CXLIII

This pass sharpens one fresh shell+terminal lesson from current upstream docs:
**the ecosystem is rapidly standardizing visible autonomy dials — ask, plan, auto-edit, allowlist, bypass, autopilot, yolo — which makes posture-scoping, deny floors, and stop/revoke honesty a real design seam rather than just a settings-page detail.**

## 1) Claude Code is converging on explicit permission postures and ordered rules

Claude Code’s current permissions docs are especially revealing.
It now documents a tiered permission system, ordered rules with deny before ask before allow, and multiple permission modes including `default`, `acceptEdits`, `plan`, `dontAsk`, and `bypassPermissions`.
That is useful because it does not pretend autonomy is one thing.
It is a family of postures with different action envelopes and different failure shapes.

## 2) Claude’s Plan Mode is one of the cleanest current luxury moves

Across the Claude Code docs, Plan Mode keeps coming up as a first-class posture rather than a weak fallback.
In the IDE and desktop docs it is presented as a mode switch for exploring or proposing before change.
In the common workflows docs it is explicitly recommended for safe code analysis and exploratory work.
That is a strong signal.
The best posture systems do not only optimize “run more automatically.”
They also optimize “understand more safely.”

## 3) VS Code makes the session scope and approval gradient unusually explicit

VS Code’s current agent-tools docs are valuable because they show a clear ladder:
`Default Approvals`, `Bypass Approvals`, and `Autopilot`.
The page is explicit that Autopilot auto-approves tools, auto-retries, auto-responds to questions, and keeps iterating until it believes the task is complete.
It is also explicit that the permission level applies to the current chat session and can be changed at any time.
That is an excellent clue for Schell.
Autonomy should usually be **session-shaped or task-shaped**, not mysterious forever-trust.

## 4) Warp is embracing profile-shaped autonomy, but it also shows the warning label

Warp’s agent-permissions docs now expose a family of choices such as `Agent decides`, `Always ask`, `Always allow`, and `Never`, alongside command allowlists, command denylists, MCP allow/deny controls, and a “Run until completion” mode.
The docs are especially instructive because they admit two important things:
- allowlists and denylists are real operator tools,
- and the most aggressive burst mode can outrun the ordinary safety rails.

That means the ecosystem is converging on a posture truth that needs better naming than just “smart agent settings.”

## 5) Gemini CLI shows the same lesson in a CLI-shaped form

Gemini CLI’s current configuration docs expose `--approval-mode` with `default`, `auto_edit`, and `yolo`, along with `--allowed-tools` for bypassing confirmation dialogs on named tool surfaces.
That reinforces the same pattern from another direction:
autonomy is being broken into a small set of shaped speed-ups, not just one invisible preference.
This is good news for Schell because it suggests a small design move rather than a giant framework.

## 6) The ecosystem is converging on posture chips, but not yet on stop/revoke honesty

The current docs are strong on showing autonomy levels.
They are much less consistent about showing exactly:
- what stop means,
- how remembered allowances decay on drift,
- how to revoke a session/project allowance cleanly,
- and which deny floors still remain in force.

That is the gap Schell can exploit.
The next luxury should not be “even more autonomy.”
It should be **clearer autonomy posture with exact scope, exact widening, and obvious stop/revoke handles.**

## 7) The stealable move is visible posture, not hidden appetite

The best move to steal is very small:
**give every active helper/assistant lane an explicit posture chip, scope chip, allow surface, deny floor, stop handle, and revoke path.**

That unlocks:
- true read-only or plan posture,
- auto-edit but still ask-before-shell posture,
- command-family allowlists,
- task-burst autonomy,
- provider/tool-family narrowing,
- safe downgrade on drift or restore,
- and better operator confidence while stepping away.

None of that requires Schell to choose a final agent substrate, policy language, or sync architecture.

## 8) Compact conclusion

Current upstream docs now tell a consistent story.
Claude Code normalizes explicit permission modes and ordered rules.
VS Code normalizes session-scoped autonomy gradients and even question auto-replies in its most aggressive mode.
Warp normalizes profile-shaped allow/deny controls plus full-autonomy bursts.
Gemini CLI normalizes approval modes and per-tool bypasses.

Schell should take the hint.
It needs a first-class split between **autonomy posture**, **scope**, **allow surface**, **deny floor**, **stop handle**, **revoke handle**, **drift downgrade**, and **later receipt truth** so the future shell+terminal can feel dramatically faster without letting one flattering toggle quietly become ambient authority.
