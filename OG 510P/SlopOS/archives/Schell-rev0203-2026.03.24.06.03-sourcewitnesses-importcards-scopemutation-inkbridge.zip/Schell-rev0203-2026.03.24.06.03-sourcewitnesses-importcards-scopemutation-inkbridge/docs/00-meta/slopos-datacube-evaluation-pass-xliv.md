# SlopOS datacube evaluation, pass XLIV

This pass keeps one bounded thesis in focus:
**SlopOS already refuses to let generic launch, preview, or local shell hints quietly become durable recents or hidden residue authority. Schell should import that discipline so rich command history, restored sessions, previews, and semantic recall become much more humane without regrowing a fuzzy second memory plane.**

That is a particularly good ratchet while SlopOS is still design-phase too.
It preserves leverage while refusing to pretend we already know the final store/sync/expiry architecture.

## 1) The OpenURI recent-items boundary is the exact warning Schell needs

SlopOS's current OpenURI recent-items boundary says mediated open should not quietly become a portable recent-items, durable-history, or reopen-enrollment plane.
If local hints exist, they stay shell-owned, non-authoritative, and weaker than explicit persistence or document authority.

That maps directly onto Schell.
Command recents, chapter browsers, and launch decks are useful.
They just should not quietly become a durable reopen grant, a stable authority handle, or a hidden memory plane with fuzzy deletion semantics.

## 2) The safe-open viewer-residue boundary generalizes beyond documents

The open-untrusted viewer-residue boundary is even more useful than its immediate domain.
It says risky preview/open should not auto-enroll the source into durable recent-doc surfaces, and viewer-derived residue like thumbnails, indexes, autosaves, or crash recovery should stay inside the disposable unless something is explicitly exported.

That is the right terminal lesson too.
A preview thumbnail, inline media cache, rich hover, workflow card, or object inspector should not silently become durable reopenable truth merely because it was helpful once.

## 3) Shell-local history is allowed, but it stays weaker than explicit authority

One of SlopOS's strongest design habits is not “no convenience.”
It is “convenience may exist, but it should not overclaim.”
Shell-local history hints are allowed.
Shell-local recents are allowed.
But they stay local policy, not portable truth and not implicit authorization.

For Schell this suggests a clean posture:
- keep humane local memory,
- keep it source-labeled and retention-labeled,
- and make forget scope explicit instead of vague.

## 4) Residue discipline is already cross-cutting in SlopOS

The current datacube keeps pushing the same theme in several boundary families:
- durable status should not be mistaken for live proof,
- recent-item convenience should not become portable authority,
- viewer residue should not escape the compartment,
- speculative loading should stay separate from generic launch,
- and shell-local hints should stay non-authoritative.

That is exactly the pressure Schell now needs around command history and restored terminal luxuries.
If Schell becomes more magical, it also has to become more precise about what gets retained where, for how long, and how deletion really works.

## 5) The no-regret import is small

Schell should add:
- one compact **retention witness** family,
- one **private scratch lane** posture,
- one **forget-this-family** rail that can clear multiple local residues honestly,
- and one refusal to let clear-screen, clear-history, recents clearing, restored-session suppression, preview-cache eviction, and synced-history deletion masquerade as the same action.

That is a strong SlopOS import.
It makes Schell smarter, safer, and still decision-light.
