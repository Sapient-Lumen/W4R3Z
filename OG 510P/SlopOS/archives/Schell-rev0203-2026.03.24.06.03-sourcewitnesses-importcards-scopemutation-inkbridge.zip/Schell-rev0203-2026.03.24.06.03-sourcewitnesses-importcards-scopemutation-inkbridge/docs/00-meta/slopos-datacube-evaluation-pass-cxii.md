# SlopOS datacube evaluation, pass CXII (2026-03-22)

This pass evaluates one narrower question against the current SlopOS archive:
**what does the companion already teach Schell about semantic command frames, terminal luxury metadata, and the line between replay-stable truth versus richer sidecar comfort?**

The answer is unusually crisp:
**SlopOS wants the execution core to stay small and exact, and it wants richer observation, chrome, or telemetry to ride in explicit sidecars and descriptive lanes rather than quietly redefining the execution contract.**

## 1) `capshell.exec` keeps warning against a terminal-shaped second shell

The command-string posture and word-expansion posture are still the loudest companion clues.
SlopOS refuses hidden command-string fallbacks and refuses ambient shell-style expansion at the execution seam.
That means Schell should resist the most tempting mistake:
using terminal cleverness to smuggle parser or launcher folklore back in.

Semantic command frames are fine.
Hidden execution reinterpretation is not.

## 2) The result-sidecar boundary is the direct clue for terminal luxury

The companion's result-sidecar boundary is especially useful here.
It keeps replay-stable identity small and exact, while richer structure stays in a sidecar instead of mutating the canonical result contract.

That is almost a direct design answer for Schell.
Command marks, chapter metadata, sticky headers, capture indexes, scrollbar marks, quick-fix hints, prompt-shape annotations, and other terminal luxuries should be allowed to flourish.
But they should remain explicit sidecars or witness lanes rather than becoming the thing that execution “really meant.”

## 3) Job-control and PTY posture warn against overclaiming terminal power

The companion's job-control posture keeps saying no portable PTY control plane should be smuggled into the general command API.
That matters here because many “smart terminal” dreams quietly assume a deep portable process-control substrate.
SlopOS is warning against that.

So Schell should separate:
- nice local navigation through command frames,
- prompt-local editing when attested,
- durable continuation or promotion,
- and any heavier PTY or process-group machinery.

That keeps humane UX from forcing a false portability story.

## 4) Attention posture says transient chrome is not durable truth

The attention and durable-status boundary is the other crucial clue.
It says transient signals, notifications, and nearby chrome are not the durable record.
That principle generalizes cleanly.
A sticky header, badge, mark, pinned command title, or “recent command” chip may be very useful.
It is still weaker than the accepted command record, exact result, or current live-shell state.

So Schell should make freshness and durability explicit whenever command-aware chrome persists beyond the moment it was learned.

## 5) The companion-compatible answer is small

Schell does **not** need to settle:
- one final semantic shell-integration treaty,
- one final sticky-scroll model,
- one final command-deck storage format,
- one final quick-fix engine,
- or one final predictive-local-echo story

to stay aligned with SlopOS.

It only needs a few rules:

### A) Keep the execution core exact
Structured argv, exact footing, and replay-stable results stay smaller than terminal luxury.

### B) Put richer semantic browsing metadata in sidecars or witness lanes
Marks, frames, capture hints, sticky headers, and diagnostics may help a lot, but they do not redefine execution truth.

### C) Keep freshness posture visible
Historical, restored, inferred, and provisional command chrome should not look equivalent to live shell-authenticated state.

### D) Keep strong actions gated on stronger witnesses
Prompt-local editing, exact compare-after-run, or stronger action cards should depend on shell-authenticated or otherwise stronger evidence, not on decorative chrome alone.

### E) Let transcript truth survive the magic
A plain transcript and exact reviewed command record should still tell the story even when richer UI is available.

## 6) Compact conclusion

The SlopOS-compatible answer is not “build a giant smart-terminal substrate first.”
It is:
**keep execution exact, let semantic command frames and richer terminal comfort ride in explicit sidecars, and make stale or provisional terminal chrome confess itself before it borrows more truth than it deserves.**

That is a design-phase-safe move because it improves the future terminal a lot without forcing big early architecture choices.
