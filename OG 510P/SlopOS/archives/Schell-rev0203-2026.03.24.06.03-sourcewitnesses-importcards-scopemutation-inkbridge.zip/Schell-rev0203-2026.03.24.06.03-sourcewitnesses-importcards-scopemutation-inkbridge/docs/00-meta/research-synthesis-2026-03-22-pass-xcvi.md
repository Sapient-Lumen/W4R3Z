# Research synthesis, pass XCVI (2026-03-22)

This pass asks one narrower question:
**what should Schell learn from modern semantic shell integration without silently adopting hidden startup ownership, heuristic truth, or remote-helper blur?**

The answer is clearer than it first appears.
**The best move is not “pick one protocol and go all in.” The best move is to treat semantic integration itself as a witnessed capability with named source, verification, and downgrade posture.**

## 1) Modern terminals keep proving that shell-known semantic regions are worth stealing

VS Code, Ghostty, kitty, iTerm2, and WezTerm all keep circling the same core idea:
a terminal becomes dramatically better once it knows where prompts, user input, command output, and command completion really are.
That unlocks jump-to-prompt, command selection, command-local search/filter/copy, output-local navigation, better prompt redraw, and prompt-local cursor movement.

This is not a speculative luxury anymore.
It is a demonstrated category of improvement.
Schell should steal it.

## 2) VS Code teaches the strongest small lesson: exact command-line truth deserves its own channel

VS Code's shell integration is especially helpful because it says the quiet part out loud.
Its custom `OSC 633` sequences distinguish prompt start/end, pre-exec, post-exec, and an explicit command-line sequence.
The docs also say that when the explicit command-line sequence is absent, the terminal may fall back to inference from the surrounding marks or disable the feature when it is unreliable.
Even better, the explicit command-line sequence has an optional nonce so the terminal can verify that it came from the shell integration script and relax protections only when verification succeeded.

That suggests one especially valuable Schell distinction:
- prompt/input/output marks are useful,
- exact command-line attestation is stronger,
- and heuristic reconstruction remains weaker than both.

## 3) Ghostty and kitty show how much delight sits above shell-known truth

Ghostty's recent releases are unusually useful design evidence.
Its current docs and 1.3.0 release notes make prompt-local click-to-move depend on semantic prompt support, and they explicitly name richer prompt/output behaviors that ride on shell integration.
Ghostty also added a debug overlay showing the semantic prompt regions, which is a brilliant clue for Schell: shell integration needs an implementer-facing visibility layer, not just an operator-facing delight layer.

kitty points the same way.
Its shell integration can drive prompt marks, output browsing, click-to-move at the prompt, cwd-aware window cloning, and remote comfort features.
It also lets these features be turned off individually.
That is a strong reminder that semantic integration is not one monolith; it is a family of features with explicit posture.

## 4) Remote comfort keeps proving why startup and transport posture cannot stay hidden

The most revealing evidence in this pass is not the semantic marks themselves.
It is how much work terminals now do to preserve them across hops.

Ghostty's 1.2.0 SSH improvements are opt-in because they override `ssh`; the docs call the `ssh-env` path a band-aid and explicitly note that it is not strictly correct even if it is often practical.
Ghostty's terminfo docs are equally honest: `xterm-ghostty` is a compatibility compromise, remote fallback to `xterm-256color` is weaker, and advanced features are lost on fallback.

kitty's `ssh` kitten makes the same lesson vivid from the other direction: it can copy terminfo, set up shell integration remotely, and preserve cwd across new windows.
This is wonderful comfort.
It is also a clear reminder that “the remote session feels native” may depend on helper-installed posture, not on native remote support.

Schell should steal the comfort and the confession together.

## 5) iTerm2 and WezTerm preserve the older lesson: semantic marks are useful even when protocol families differ

iTerm2 still documents the FinalTerm-style semantic shell integration concepts directly: prompt start, command start, command executed, command finished.
It layers useful command selection and semantic-history features on top of that.
WezTerm explicitly supports FinalTerm semantic escapes and iTerm-like cwd reporting.

The design-phase lesson is not “adopt iTerm2” or “adopt FinalTerm” or “adopt VS Code's exact sequences.”
It is simpler:
**multiple protocol families already prove the demand, so Schell should focus first on witness posture and portable truth, not on naming one final sequence family too early.**

## 6) The compact import for Schell

This pass argues for a smaller ratchet than a final protocol manifesto.
Schell should begin with:
- one **integration witness** recording protocol family, source posture, verification posture, hop path, and downgrade reasons,
- one explicit ladder from native shell-authenticated integration down through addon, injection, adapter, remote-wrapper, heuristic, and plain legacy,
- one separate field for exact command-line attestation,
- one visible distinction between terminfo footing and semantic-mark footing,
- and one action-gating rule that depends on verification posture rather than on visual chrome.

## 7) Compact conclusion

The strongest design-phase answer from the current ecosystem is:
**semantic shell integration is now too valuable to ignore, but it should be modeled as a witnessed, negotiable, degradable capability rather than as a hidden second shell.**

That move lets Schell steal:
- command-aware navigation,
- prompt-local editor comfort,
- command-local search/copy/share,
- richer remote continuity,
- and better implementation debugging,

while still deferring:
- the final escape-sequence family,
- the final shell-addon strategy,
- the final mux bridge contract,
- the final remote-helper story,
- and the final startup-injection posture.
