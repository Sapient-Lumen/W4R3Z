# Research synthesis, pass LXVIII (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should absolutely steal explicit filesystem footing — mount roots, cwd roots, bind overlays, portal-granted files, and path-resolution posture — but only if reviewed file authority stays on explicit roots/handles/portals instead of collapsing into one flattering “the command can probably see the normal host tree” story.**

This seam matters because shells still make filesystem footing feel much simpler than it is.
A command often inherits some mix of current cwd, current root view, bind mounts, propagation behavior, and sandbox/file-picker grants without any of that being visible in the review surface.
When a relative path resolves differently, a bind mount shadows expected files, a sandbox sees only loopback/tmpfs roots, or a chooser-granted file persists longer than the operator expected, the debugging session turns into mountinfo, portal, container, and wrapper archaeology.
That is exactly the kind of shell+terminal seam Schell can improve without choosing one final sandbox runtime, mount toolchain, or path API.

## 1) Mount namespaces prove copied trees and propagation are part of the truth

The current `mount_namespaces(7)` docs say mount namespaces isolate the list of mounts a process sees, but a new namespace begins as a copy of another namespace's mount list rather than a blank tree.
The same docs say propagation matters: `MS_SHARED` propagates mount and unmount events, `MS_PRIVATE` does not, and modern systems often begin effectively shared because `systemd` remounts mounts as shared on startup while `unshare` flips them back to recursive private by default in a new namespace.
That is a huge Schell lesson.
“new namespace” is not enough truth.
The shell needs a way to name whether a reviewed action is entering a copied host-like tree, a fresh private tree, a shared-propagation tree, or an unknown/degraded compat view.
See: https://man7.org/linux/man-pages/man7/mount_namespaces.7.html

## 2) chroot and pivot_root prove root changes are not one generic sandbox story

The current `chroot(2)` docs are unusually blunt: `chroot()` changes a pathname-resolution ingredient and is not intended to fully sandbox a process or restrict filesystem calls for security purposes.
The current `pivot_root(2)` docs instead say it changes the root mount in the current mount namespace, can move the old root under the new one so it can later be unmounted, does not necessarily change the caller's cwd, and forbids `MS_SHARED` propagation on relevant parents.
That is exactly the historical lesson Schell must keep learning.
“changed root” is not enough truth.
A reviewed action should be able to say whether it is in a mere chroot-like view, a real mount-root switch, a fresh sandbox root, or a degraded host-root compatibility lane.
See: https://man7.org/linux/man-pages/man2/chroot.2.html and https://man7.org/linux/man-pages/man2/pivot_root.2.html

## 3) Bubblewrap shows the luxury pattern: start empty, then add explicit views

The current `bwrap(1)` docs say bubblewrap creates a new completely empty filesystem namespace whose root is on a tmpfs invisible from the host and automatically cleaned up when the last process exits; command-line options then construct the root filesystem and process environment for the command.
That is a beautiful Schell clue.
The shell does not need to standardize bubblewrap itself, but it should absolutely steal the operator-facing idea that a command can start from an empty or sealed root and then receive explicit view bindings.
See: https://manpages.debian.org/unstable/bubblewrap/bwrap.1.en.html

## 4) Docker bind mounts prove overlays, shadowing, and host coupling need explicit review

The current Docker bind-mount docs say a bind mount maps a host path into the container, bind mounts over existing data obscure the existing files in the container, bind mounts have write access to the host by default, and containers with bind mounts are strongly tied to the host's directory structure.
The docs also note that Docker provides DNS resolution by bind-mounting `/etc/resolv.conf` from the host into each container.
That is an excellent anti-folklore lesson.
A bind is not just “this folder is available.”
It is also “this subtree may shadow something, may be writable back to the host, and may couple the reviewed action to one host-specific layout.”
See: https://docs.docker.com/engine/storage/bind-mounts/

## 5) Flatpak and XDG portals show the handle-first pattern Schell should steal

The current XDG FileChooser portal docs say sandboxed applications can ask for access to files outside the sandbox and the selected files will be made accessible to the application, which may involve adding them to the Documents portal.
The current Documents portal docs say exported files become accessible via a FUSE filesystem mounted at `/run/user/$UID/doc/`, visible both outside and inside the sandbox, with the sandbox view restricted to the files the application is allowed to access.
The current Flatpak sandbox-permission docs also say `--persist=DIR` can map selected home-directory subtrees into the sandbox, explicitly as a narrower alternative to broad home access.
That is a huge Schell lesson.
The classy answer is not “give me the host path and hope.”
It is “grant a chosen object or bounded persisted subtree through an explicit mediation/result surface.”
See: https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.FileChooser.html , https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Documents.html , and https://docs.flatpak.org/en/latest/sandbox-permissions.html

## 6) openat2 proves path resolution posture can be reviewed, even if it is not fully portable

The current `openat2(2)` docs say `RESOLVE_IN_ROOT` and `RESOLVE_BENEATH` detect attempts to escape the starting root during path resolution, `RESOLVE_NO_XDEV` detects mount-point crossings, and callers may get `EAGAIN` when the kernel cannot prove a `..` component did not escape because of a race or potential attack.
That is exactly the kind of narrow modern idea Schell should steal.
Even if Schell does not freeze one Linux-specific path API, it can still name reviewed path-resolution posture: beneath-only, in-root, no-cross-mount, symlink-restricted, provider-unknown, or compat-degraded.
See: https://man7.org/linux/man-pages/man2/openat2.2.html

## 7) Landlock proves ambient filesystem rights can be reduced, but should stay an add-on truth

The current kernel Landlock docs say its goal is to restrict ambient rights such as global filesystem or network access, and because it is stackable it can add a safer security layer on top of existing system-wide access controls.
That is useful Schell pressure, but it is not the full answer.
Landlock is a strengthening layer, not a universal portable filesystem contract.
Schell should therefore surface ambient-rights reduction as an optional witness or addendum, not as the only filesystem truth.
See: https://docs.kernel.org/userspace-api/landlock.html

## 8) The dangerous flattenings to refuse

The current ecosystem keeps inviting at least eight filesystem mistakes:
- treating cwd text as if it were the full root/view truth,
- treating a new mount namespace as if it were an empty tree when it may be a copied tree with propagation semantics,
- treating `chroot` as if it were a security sandbox,
- treating bind mounts as harmless sharing rather than host-coupled writable overlays that can shadow existing content,
- treating chooser-selected files as equivalent to broad path authority,
- treating persisted portal or sandbox directory grants as the same thing as one-shot open authority,
- treating path strings in argv/env as proof of reachability,
- and treating one platform's filesystem control stack as Schell's final universal path model.

Schell should refuse those moves.
A command should be able to say, separately:
- what root/view basis it is entering,
- what cwd-root posture it will start from,
- what explicit mounts or overlays are in play,
- what propagation/shadowing caveats matter,
- what object grants came from chooser/portal mediation,
- what path-resolution guard posture applies,
- and what bounded historical filesystem receipt can honestly be emitted afterward.

## 9) The stealable move: filesystem witnesses, mount roots, and bind humility

The best decision-light move now looks like this:
1. add a **filesystem witness** family for reviewed launch posture,
2. keep **root/view basis** separate from **cwd-root basis**,
3. keep **bind/overlay posture** separate from plain path rendering,
4. keep **chooser/portal/document grants** separate from ambient path reachability,
5. keep **path-resolution guard posture** separate from final execution result,
6. keep **shadowing and host-coupling warnings** explicit,
7. keep **historical file/mount receipts** weaker than current live namespace truth,
8. and refuse to standardize one giant cross-platform path or mount grammar too early.

That would make Schell feel dramatically more capable while preserving the archive's decision throttle.

## 10) A compact first proving slice

A compact proof could show:
- one reviewed launch card with explicit root/view badge,
- one cwd-root badge that says bound / empty / descriptor / unknown,
- one bind/overlay witness with ro/rw plus shadowing warning,
- one propagation badge that says private / shared / slave / unknown,
- one portal-chosen file or persisted-subtree witness that stays weaker than host-path truth,
- one path-resolution badge that says beneath / in-root / no-xdev / compat / unknown,
- one refusal to treat a pretty prompt path as the whole filesystem truth,
- and one historical filesystem receipt with bounded facts.

That is enough to make Schell feel super awesome at filesystem footing without freezing the final sandbox runtime, mount-manipulation stack, path-resolution API, or portal substrate.

## 11) Decisions intentionally kept open

This pass does **not** freeze:
- one universal mount grammar for every host/runtime,
- one portable filesystem API for opening arbitrary paths,
- one final sandbox/container runtime,
- one final document-portal or chooser backend,
- one universal path-guard implementation,
- or one final mount/namespace inspection UI.

The no-regret move is smaller:
**steal reviewed filesystem witnesses, explicit root/view and bind-overlay posture, chooser-mediated file authority, and path-resolution humility — but keep root basis, cwd root, overlays, propagation, portal grants, and historical receipts visibly separate.**
