# Research synthesis — 2026-03-23 — pass CXCIII

This pass sharpens one smaller lesson from current shells:
**shorthand is valuable, but the safest modern shorthand expands where the operator can still see and edit it, not in a hidden parser corner that later impersonates command truth.**

## 1) Current shells already split the good shorthand from the dangerous shorthand

fish is the clearest positive model.
Its `abbr` feature explicitly says abbreviations are replaced with longer phrases **when entered**, only for **typed-in commands**, and **not in scripts**.
The docs also show several bounded luxuries: command-position versus anywhere, command-scoped abbreviations, regex-backed matches, dynamic function-backed expansions, and cursor placement markers.
That is a superb stealable bundle because it improves speed while keeping the expansion in the editable buffer before execution.

Bash, zsh, PowerShell, and Nushell then expose the other half of the lesson.
Bash alias substitution is read-time, not execution-time; it happens while the shell is reading commands, aliases do not take arguments, and the Bash manual calls the rules "somewhat confusing" enough to recommend functions when arguments are needed.
zsh expands aliases immediately before parsing, supports global aliases that expand anywhere on a line, and even warns that global aliases have a lot of potential to cause confusion.
PowerShell explicitly treats aliases as an interactive convenience, notes that alias definitions cannot include parameters, and tells users not to rely on aliases in scripts.
Nushell's alias command is a parser keyword, which is a concise reminder that some shorthand lives inside parse-time structure rather than as a purely local editor aid.

## 2) The lesson Schell must learn from the past

The historical mistake is not merely "aliases exist."
The mistake is **flattening several different shorthand families into one flattering story**:
- text the operator typed,
- text the editor expanded before execution,
- parser-time replacement rules,
- parameterized helpers/functions,
- imported compatibility shims,
- and durable scripts or runbooks.

Once those collapse, two bad things happen:
1. the operator stops knowing what exact command identity will run, and
2. scripts/history/shares start carrying shorthand residue whose meaning depends on hidden local configuration.

That is exactly the kind of ambient magic Schell has been trying to refuse.

## 3) The nifty ideas worth stealing are editor-local and source-labeled

The best current steals are surprisingly small:
- **typed abbreviations** that expand into the visible buffer on space/enter,
- **command-scoped abbreviations** so shorthand can mean one thing for `git` and another for `kubectl`,
- **regex or function-backed expansion** when the shell can still show the result before spend,
- **cursor markers** so an expansion can leave the operator exactly where final editing is needed,
- and **alias inspection** that makes hidden replacement discoverable.

These are super awesome because they speed up command entry without forcing Schell to decide one final shell grammar, one final snippet language, one final history format, or one final compatibility story.

## 4) The moves Schell should refuse for now

Schell should refuse, for now:
- parser-time shorthand that silently changes shared scripts or receipts,
- global shorthand that rewrites tokens far from command position,
- one monolithic "macro" surface that hides whether the source was local editor comfort, parser syntax, imported profile residue, or durable shared workflow,
- and any shorthand surface that obscures the exact command identity witness the shell is about to spend.

In other words:
**steal the comfort of abbreviation, not the ambiguity of folklore aliasing.**

## 5) The no-regret Schell seam

Schell should add one dedicated surface for:
- typed abbreviation offers,
- admitted editor expansions,
- parser alias reveals,
- imported compatibility-pack labels,
- exact command identity compare,
- and history/share rules that distinguish expanded text from shorthand handles.

That lets the shell feel faster and smarter without deciding whether the long-term answer is aliases, snippets, functions, runbooks, workflows, or some later hybrid.

## 6) Compact conclusion

Current docs line up unusually well here.
fish proves the strongest positive pattern: editor-visible, typed-only shorthand.
Bash, zsh, PowerShell, and Nushell keep showing where confusion enters: read-time aliasing, parser-keyword rewrites, global aliases, parameter gaps, and script residue.

So the next low-regret Schell seam is **abbreviation receipts, alias reveals, and command-truth humility** so shorthand stays delightful without becoming a second hidden command resolver.
