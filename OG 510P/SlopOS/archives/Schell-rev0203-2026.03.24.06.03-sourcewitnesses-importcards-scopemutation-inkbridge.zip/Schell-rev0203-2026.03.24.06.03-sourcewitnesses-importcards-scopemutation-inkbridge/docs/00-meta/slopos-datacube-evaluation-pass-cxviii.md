# SlopOS datacube evaluation, pass CXVIII (2026-03-22)

This pass evaluates one narrower question against the current companion archives:
**what do SlopOS, ViewFS, and Steward teach Schell about how long remembered shell objects should remain action-ready once recall becomes richer, more contextual, and more restored?**

The answer is crisp:
**historical presence is weaker than live lease state, so action posture should decay unless fresh footing is re-established.**

## 1) SlopOS already separates stable request identity from live lease truth

The most helpful direct import from SlopOS is its refusal to let descriptive artifacts impersonate current live state.
The outbound-network-lease work is especially instructive: a stable request identifier is not proof that a current live lease still exists.
That is exactly the right lesson for shell memory.

A remembered command chapter, restored block, or saved service card is useful evidence.
It is not proof that:
- the same peer still exists,
- the same namespace or cwd still applies,
- the same authority wallet still holds,
- or the same stronger action should still be the default.

## 2) SlopOS leases and revocation epochs imply recall should age explicitly

The broader SlopOS archive repeatedly prefers:
- lease-bounded grants,
- explicit renewal,
- explicit revocation,
- and visible epoch changes.

That strongly suggests the Schell analogue should be:
- rerun-ready only while footing remains fresh enough,
- downgrade on peer/cwd/repo/authority drift,
- require fresh comparison or reproof after decay,
- and keep restoration/historical material weaker than live.

This is a very good no-regret move because it imports the discipline, not the exact kernel substrate.

## 3) ViewFS reinforces the distinction between live lanes and historical surfaces

ViewFS keeps observe/follow, attach, control, sidebands, and historical surfaces distinct.
That matters here because a remembered command row can easily borrow too much apparent power from its old lane.
A command found in historical search should not automatically inherit the same affordances as one surfaced in a fresh same-peer live lane.

The right Schell import is simple:
**let recall rows say both where they came from and what stronger action lease, if any, remains.**

## 4) Steward reinforces freshness-scoped trusted chrome

Steward's trusted-chrome pressure remains valuable.
Freshness is part of honesty.
That means sticky command headers, restored session cards, and recent-command rows should say whether they are:
- fresh,
- recent,
- aging,
- stale,
- restored,
- or historical.

That is how rich recall avoids becoming a flattering lie.

## 5) Companion-compatible no-regret move

Schell does **not** need one final decay formula yet.
It only needs a few bounded rules:

### A) Keep memory weaker than live footing
Searchable or restored is not the same as currently action-ready.

### B) Make action lease visible
Rows should be able to say rerun-ready, review-first, same-peer-only, insert-only, inspect-only, or historical-only.

### C) Downgrade on drift
Peer drift, cwd drift, repo drift, authority drift, and lane drift should weaken default actions.

### D) Make reproof easy
The humane bridge from old memory to new action is compare-current-basis or re-establish-live-footing, not magical replay.

### E) Keep restoration honest
Restored continuity is valuable while remaining visibly historical until fresh witnesses arrive.

## 6) Compact conclusion

The SlopOS-compatible answer is not “keep every remembered command equally ready forever.”
It is:
**preserve source class, preserve history, but let stronger action posture decay visibly until fresh footing is re-established.**

That is a design-phase-safe move because it makes Schell dramatically smarter at recall without forcing one final history, restore, or ranking architecture.
