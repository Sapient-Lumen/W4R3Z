# Archive policy

- Prefer one stable surface per concept.
- Use RFCs for candidate mechanics and ADRs for hard decisions.
- Keep ledgers small and discriminating.
- When a revision imports pressure from another datacube or from current outside research, record the exact source packets and the bounded take.
- Preserve nearby rejected moves when they were genuinely close; do not let accepted text rewrite its alternatives into inevitability.
- Do not let implementation TODOs replace canonical design surfaces.
- Quarantine anything that sounds exciting but lacks a promotion test.
- Default to **decision deferral** when an interaction can be prototyped before syntax, ABI, or compatibility policy is frozen.
