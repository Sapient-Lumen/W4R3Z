# Research synthesis — 2026-03-23 — pass CLXVI

This pass keeps the archive decision-light while naming the next high-value luxury cluster:
**modern shells and terminals keep proving that command chapters are useful, but the next under-served luxury is cheap then-versus-now footing comparison before a stronger follow-on act.**

That is a strong Schell seam because it adds operator trust and speed without forcing one final shell↔terminal treaty, chapter database, replay engine, or plugin runtime.

## 1) The ecosystem is very good at chapter discovery, and still weaker at chapter drift

Current terminal/docs pressure is now clear about chapter discovery.
Ghostty uses shell integration for prompt-aware features such as prompt jumps, output selection, cwd inheritance, cursor-at-prompt behavior, and prompt-click movement, while still noting that shell integration may need manual sourcing when the user switches shells inside the terminal. WezTerm keeps exposing semantic zones for Prompt/Input/Output and navigation such as `ScrollToPrompt`. Windows Terminal treats marks as stable, supports select-command/select-output, and recent-command suggestions. iTerm2 keeps command selection and a command info panel with duration, exit status, and share/copy/resend affordances. VS Code layers on command navigation, command-context attachment to chat, and hover details like start time, duration, and exit code. citeturn493673view0turn475372view1turn250022view0turn250022view1turn475372view7turn475372view6turn475372view2turn475372view3turn475372view4

The load-bearing lesson is that command chapters are now a mainstream convenience surface.
The missing luxury is not more chapter chrome; it is faster legibility about whether the footing behind a chapter still matches the current world.

## 2) The strongest past lesson is still that startup and argument semantics are real execution boundaries

Bash's startup-file rules still show how many files and variables can silently affect a shell invocation, including `~/.bashrc`, login profiles, `BASH_ENV`, and `ENV` depending on how Bash is invoked. Shellshock remains the blunt reminder that environment handling can become a real command-execution boundary, not just a convenience channel. PowerShell likewise still requires care because native-command arguments are parsed by PowerShell first, and even current behavior is mode-dependent through `$PSNativeCommandArgumentPassing`; meanwhile PowerShell 7.4 had to make byte-preserving native pipes mainstream because shell/native boundaries were still lossy enough to matter. citeturn718063view1turn355655search0turn475372view12turn475372view13turn475372view14

So the next Schell move should not be “make history rows more executable.”
It should be “show the operator what changed in the footing around a historical chapter.”

## 3) Freshness keeps beating remembered pane-wide guesses

A particularly useful current lesson comes from fish.
Recent fish release notes explicitly call out that the working directory is now reported on every fresh prompt via OSC 7, fixing cases where a child process like `ssh` left behind a stale cwd; the same notes also call out explicit prompt-end marking via OSC 133. Ghostty's docs similarly note that automatic shell integration only applies to the initially launched shell and must be manually sourced if the user switches shells, which is another reminder that remembered terminal-local context and current shell footing can drift apart. citeturn475372view16turn493673view0

That suggests a strong Schell rule:
**fresh prompt-side reassertion should stay stronger than remembered pane-wide context.**

## 4) Helpful history is not yet safe replay

xonsh's sqlite history shows the appeal of richer history surfaces: command items can carry keys like input, return code, and timestamps. That is clearly useful, but it also reinforces a limit: helpful history does not itself carry enough footing to justify strong replay. VS Code's command attachment is especially interesting here, because it shares command line, captured output, and exit code — exactly the kind of bounded chapter packet that is useful for troubleshooting — yet even that is still not the same thing as current-basis replay authority. citeturn475372view11turn475372view3

So the best steal is not “fatter history.”
It is **history plus cheap drift comparison plus typed next verbs.**

## 5) Several specific ideas are worth stealing right now

A few current moves look especially stealable without overcommitting architecture:
- WezTerm's zone model and prompt navigation because they prove chapter-local movement/search is worth making first-class. citeturn475372view1turn250022view0turn250022view1
- Windows Terminal's stable marks plus select-command/select-output because chapter-local selection should be a primitive, not a hack. citeturn475372view7
- iTerm2's command info panel because duration/exit/share/resend proves that command-local inspection is a durable UX center of gravity. citeturn475372view6turn475372view8
- VS Code's attach-terminal-command-to-chat and hover details because exact chapter packets are much better than copy/paste folklore. citeturn475372view3turn475372view4
- Nushell's `extern` and custom completion posture because external commands benefit from richer structure and typed hints before execution, not just after. citeturn475372view9turn475372view10
- Ghostty's `-e` safety note because forced shell integration into a command's environment can cause problems, which is precisely why Schell should keep launch exactness and luxury separate. citeturn493673view2

## 6) The next no-regret luxury is a typed then/now compare object

The clearest next cluster now looks like this:
- then/now footing compare cards,
- drift halos in hovers and chapter rows,
- typed changed-row chips such as basis/peer/overlay/authority drift,
- attach-for-help bundles that include both original chapter context and current drift,
- derive-on-current-basis offers,
- and typed refusal cards when exact rerun is no longer honest.

That cluster steals the best of the current ecosystem while deferring:
- one final footing-diff schema,
- one final storage/sync model,
- one final chapter database,
- or one policy that every chapter path preserves enough provenance for strong replay.

## 7) Compact conclusion

The next brilliant step for Schell is not more replay confidence.
It is narrower:
**make drift cheap to see and cheap to explain.**

That lets a custom shell+terminal feel super awesome while staying loyal to the older lesson that startup, cwd, env, and native-command semantics are where hidden shell authority loves to hide.
