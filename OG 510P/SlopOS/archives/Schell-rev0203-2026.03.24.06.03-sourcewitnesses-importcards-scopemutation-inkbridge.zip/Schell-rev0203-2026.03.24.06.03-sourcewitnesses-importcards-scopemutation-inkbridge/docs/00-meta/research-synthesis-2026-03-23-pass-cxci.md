# Research synthesis — 2026-03-23 — pass CXCI

This pass sharpens one smaller lesson from current shells and terminals:
**smart paste transforms are worth stealing, but they should remain explicit filter results instead of silently rewriting what the operator believes they pasted.**

## 1) Bracketed paste solved only the first half of the problem

GNU Readline still gives the cleanest baseline.
Bracketed paste inserts pasted text as one unit instead of replaying key bindings as if every pasted character had been typed.
That matters because it proves pasted bytes are their own ingress family.

But Readline also shows the limit of that win.
Knowing something is a paste does not yet answer:
- whether it should be quoted,
- whether controls should be replaced,
- whether trailing newline should arm or spend,
- or whether the terminal quietly rewrote the payload first.

So Schell should treat bracketed paste as the beginning of a truth ladder, not the end.

## 2) zsh and fish prove target-aware transforms can be helpful before insert

zsh's `bracketed-paste-magic` is a gift here because it explicitly exposes work before final insertion.
`paste-init` runs before insertion, `paste-finish` runs after active processing but before insertion, and helpers like `quote-paste` make clear that smart quoting is a transform layer, not just raw ingress.

fish reaches the same lesson from a more product-shaped direction.
It enables bracketed paste so it can distinguish paste from manual entry, and when pasting inside single quotes it automatically escapes pasted single quotes and backslashes so the result can stay one token.
That is a genuinely brilliant UX move.
It is also a reminder that Schell should preserve literal reveal nearby whenever it adopts such transforms.

## 3) kitty shows the filter family most explicitly

kitty is especially valuable because it refuses to flatten paste into one act.
Its official configuration already names a family of paste actions:
- quote URLs at a shell prompt,
- replace dangerous control codes,
- replace newline,
- confirm,
- confirm if large,
- and run a custom filter.

That is exactly the right kind of pressure for Schell.
The shell+terminal can be very smart here while still staying architecturally modest if it treats those as typed filter proposals and admitted filter outcomes rather than as invisible rewrite magic.

## 4) Current editor-terminals are converging on the same smaller truth

VS Code's terminal documentation keeps reinforcing two bounded lessons:
- multiline paste warnings still matter when good shell footing is absent,
- and selected-text send should use bracketed-paste posture when the shell supports it.

That means the modern UX trend is not “paste is solved now.”
It is “paste is richer, but the richness depends on target footing and should stay distinct from ordinary typing.”

## 5) The trap is residue and hidden rewrite

The more helpful paste gets, the easier it becomes to hide what changed.
A prompt-aware quote, control-code replacement, or large-paste staging rule can make the shell feel wonderful.
But if the system cannot later say what exact text arrived, what exact transform was applied, and what exact candidate reached the live buffer, then the operator loses authorship truth.

That is the old lesson Schell must not relearn:
**helpful transforms become dangerous the moment they become invisible.**

## 6) The no-regret Schell move

Schell should add one compact paste-filter witness family:
- original paste offer,
- filter proposal or admitted automatic hygiene step,
- transformed candidate,
- literal reveal,
- and later reviewed spend.

This imports a genuinely brilliant set of ideas from current tools while still refusing to choose one final clipboard backend, filter DSL, prompt detector, or secret-policy engine too early.

## 7) Compact conclusion

Current shells and terminals already agree on the important part:
paste deserves special handling, and some transforms are worth doing.
The thing they still leave too fuzzy is authorship after transform.

So the next low-regret Schell seam is **paste filters, quote-at-prompt, and control-code humility**.
