# Research synthesis, pass XXXI (2026-03-21)

This pass keeps one construction rule in focus:
**a super-awesome shell+terminal is not the one that does the most hidden work; it is the one that keeps the prompt fast, keeps richer help off the critical path, and makes every upgrade in cost and freshness explicit.**

Modern tools keep converging on this even when they use very different stacks.
The striking pattern is that the most delightful interactions are usually cheap because they ride shell-known boundaries, cached local state, or explicit summon steps.
The dangerous interactions are the ones that quietly cross into helper execution, remote lookup, or stale warm state while still looking instant.

## 1) Shell-known boundaries are the cheapest source of delight

VS Code's shell integration uses shell-reported command boundaries for command navigation and command-scoped selection.
Ghostty's newer OSC 133 support lets the operator click inside the active prompt and move the cursor like a text field.
Those features feel magical, but they are not expensive magic.
They are cheap because the shell already told the terminal where the live boundary is.

That is an important lesson for Schell:
**first ask what delight can be powered by shell-known truth before inventing a background helper.**

## 2) Fast prompt behavior is a product requirement, not a backend afterthought

fish's design notes are unusually clear here: syntax highlighting and autosuggestions must do disk I/O asynchronously, and startup should minimize forks and disk I/O.
That is a brilliant historical lesson.
Prompt-time help is only lovable when operators stop fearing it.
If smartness stalls the prompt, people learn to distrust it or disable it.

Schell should therefore treat prompt-speed as part of the interface contract, not merely as an optimization task for later.

## 3) Suggestion power comes from being inert until accepted

fish's autosuggestions are useful precisely because they do nothing until the operator accepts them.
That continues to be one of the best shell ideas of the last decade.
A suggestion can be strong, contextual, and high-confidence while still remaining proposal-only.

The lesson for Schell is broader than autosuggestions:
**command recall, workflow hits, parameter fills, semantic links, and enriched rows should all be allowed to feel close at hand without crossing into half-executed state.**

## 4) Rich help should usually be summoned, not ambient

PowerShell's dynamic help keeps focused parameter help attached to the current command line.
Warp's workflows open into an editor where the operator can name, edit, and parameterize the command.
These are both excellent patterns because they make richer assistance available at the moment of need without normalizing constant prompt-time work.

Schell should steal that posture aggressively.
The shell+terminal can be much smarter than bash while still saying:
- inline help is cheap when it is local and current,
- deeper help is summoned,
- and edited artifacts stay reviewable before run.

## 5) Rich display should not force richer acquisition

Nushell's `display_override` is another clue.
The display row and the inserted value are separate.
That means the UI can be more descriptive without changing what lands in the buffer.
The same discipline should apply to acquisition cost.
A row can look rich because it reuses known state; it does not need permission to do remote fetches or hidden local exec merely to look polished.

## 6) Protocol upgrades should stay progressive enhancement

kitty's keyboard protocol is a strong construction lesson because it frames richer key reporting as progressive enhancement rather than correctness truth.
That same mindset should apply across Schell's shell+terminal seam.
If richer prompt marks, key events, hover metadata, or local chrome are absent, the terminal should degrade cleanly rather than bluff.

This keeps the project decision-light while still welcoming ambitious local UX.

## 7) Restored state is valuable, but it belongs off the critical path

Zellij's resurrection story is extremely useful and also very honest: it serializes sessions, can restore layouts and scrollback, and keeps resurrected commands behind an explicit “Press ENTER to run...” banner.
That is a wonderful pattern for Schell.
Warm or restored state should accelerate re-entry, not impersonate current live truth.

## 8) A good Schell import now looks like prompt budgets and idle lanes

A compact answer is to define a few operator-facing timing lanes:

1. **keystroke lane** — shell-static, shell-witnessed, or already-cached help only; no forks, no remote reads, no hidden materialization.
2. **prompt-render lane** — enough local work to keep the prompt informative, but still no hidden expensive work in the critical path.
3. **explicit summon lane** — the operator asked for more help, richer inspection, or stronger refresh.
4. **idle repair lane** — background refresh or repair may happen after the prompt is usable, but any upgraded result must stay visibly fresher rather than silently rewriting truth.
5. **historical lane** — restored, replayed, or imported state remains visibly historical until reacquired.

That is enough structure to make Schell feel fast and clever without freezing one scheduler, daemon, cache, or plugin runtime.

## 9) The super-awesome move is cheap delight first, expensive delight second

The custom shell+terminal becomes super awesome when:
- prompt clicks, command guides, and chapter jumps are shell-known and instant,
- inline suggestions are inert until accepted,
- focused help binds to the current slot,
- rich summon rows are editable before run,
- and stronger refresh/materialize actions are clearly second steps.

It becomes dangerous when:
- opening a menu counts as permission to run a completer,
- hover counts as permission to fetch remote metadata,
- restored shelves look current by default,
- or prompt-time beauty depends on hidden startup hooks, helper exec, or network reads.

## 10) Decisions intentionally kept open

This pass still does **not** freeze:
- one async runtime,
- one idle scheduler,
- one cache store,
- one completion/plugin runtime,
- one preview/fetch engine,
- one shell-mark protocol,
- or one resurrection backend.

The no-regret move is smaller:
**name prompt-critical versus idle lanes, keep delight cheap on the critical path, and make stronger acquisition an explicit second step.**
