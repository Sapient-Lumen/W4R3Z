# SlopOS datacube evaluation — 2026-03-24 — pass CC

**Schell should treat file-backed helper loading as an explicit reviewed posture rather than as ambient “the shell already knows this helper” folklore, because SlopOS and the companion cubes keep rewarding exact basis, explicit interpreter binding, startup-hook refusal, neighboring-state separation, label honesty, and later receipt truth.**

## 1) SlopOS keeps reviewed basis narrower than ambient file-loading convenience

SlopOS already refuses to let script bytes, shebangs, ambient PATH lookup, or startup env hooks quietly widen execution meaning.
Its capshell posture says the interpreter itself must be the one explicit exec selector, script bytes are a separate input, shebangs are only observational metadata, and ENOEXEC-style fallback to a shell is forbidden.
Its env-startup posture then forbids hidden startup hooks such as `ENV`, `BASH_ENV`, `PYTHONPATH`, `PYTHONHOME`, `PYTHONSTARTUP`, `LD_*`, and imported shell functions from quietly reintroducing startup code or loader search.
That is the exact companion pressure Schell needs for source/import seams.

So the companion-safe import is:
- helper loading may help,
- it may be fast and delightful,
- but exact reviewed spend still needs its own explicit basis lane,
- and file-loading summaries stay weaker than the exact receipt of what current scope or imported posture actually shaped the later command.

## 2) SlopOS plumb posture again argues for suggest / inspect / admit / compare

File-loading surfaces should be excellent at **suggest / inspect / admit / compare**.
They should be cautious about silently converting startup files, sourced helpers, autoloaded functions, imported modules, or overlays into current command truth.

That means a helper-loading surface can be rich, but it should confess:
- what exact file or module was loaded,
- how it was found,
- what exact scope it changed,
- whether the change is reversible,
- what exact reviewed command basis depends on it,
- and whether later spend happened under the same loaded posture.

## 3) Provider-locality pressure says helper summaries are not portable truth

The newer SlopOS boundary work keeps reasserting that provider-local packaging should not quietly become portable archive truth.
Helper-loading summaries deserve the same treatment.
A nice badge like “loaded from config”, “vendor function active”, or “project overlay on” should not quietly become durable truth if the real posture was only session-local, overlay-hideable, search-path dependent, or current-env only.

## 4) ViewFS again supplies the best neighboring-state discipline

ViewFS keeps editable text, parse understanding, diagnostics, compiled packets, prepared actions, and history distinct.
That same discipline should govern helper loading:
- typed command,
- executed file,
- sourced file,
- autoloaded definition,
- imported definitions,
- imported env,
- overlay-local mutation,
- prepared reviewed basis,
- and later execution receipt

should remain neighbors rather than collapsing into one flattering “helper imported” story.

## 5) Harbor, Ward, Steward, Helm, and Foundry keep the seam honest

- **Harbor** reinforces label honesty, which matters when Schell should say `source`, `dot-source`, `autoload`, `module import`, `source-env`, or `overlay use` instead of one vague import badge.
- **Ward** reinforces revalidation pressure, which matters when later commands are reviewed under one loaded helper set and then rerun under another.
- **Steward** reinforces adaptation posture, which matters when search-path helper loading is a local optimization rather than durable shell truth.
- **Helm** reinforces miss-ledger discipline, which matters when the UI implies full current-scope mutation but the real move imported only exported members or only environment.
- **Foundry** reinforces actor/path caveat discipline, which matters when helper files come from startup config, project packs, vendor paths, or compatibility layers with different trust and lifecycle posture.

Together they keep one rule sharp:
**helper-loading comfort can improve speed, but it must not erase load form, path/source identity, scope, export posture, reversibility, or exact reviewed basis.**

## 6) What this still does not require Schell to decide

This seam does **not** require Schell to decide:
- one final module syntax,
- one final startup-file constitution,
- one final autoload path system,
- one final compatibility importer,
- one final package/distribution story.

It only earns a smaller and more honest witness family.
