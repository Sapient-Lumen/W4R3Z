# Research synthesis, pass XLIV (2026-03-21)

This pass focuses on one bounded seam that Schell did not yet give its own surface:
**the current shell and terminal ecosystem keeps proving that “memory” is not one thing. Session history, on-disk history, scrollback, restored sessions, synced history, recents, and preview snapshots all have different lifetimes, which means Schell should make forgetting just as explicit as remembering.**

## 1) fish shows the value and the limit of private mode

fish's current docs say private mode prevents command history from being written to the history file on disk, and `fish --private` both hides old history and prevents writing new history.
That is a genuinely good operator move, and Schell should steal the spirit of it.

But it is also a useful limit-case.
Private mode is about a particular history surface.
It is not a claim that every other residue surface is gone.
That is exactly the kind of precision Schell should preserve when it eventually offers private scratch lanes or temporary reviewed workspaces. See: https://fishshell.com/docs/current/interactive.html

## 2) PowerShell is a strong warning that “history” often means several different stores at once

The current PSReadLine docs expose three history save styles: `SaveIncrementally`, `SaveAtExit`, and `SaveNothing`.
That alone is already a good design steal for Schell because it makes retention posture explicit.
But the sharper warning comes from the note that if you switch from `SaveNothing` to `SaveIncrementally` later in the same session, PSReadLine writes the commands you already ran earlier in that session.

Microsoft's `Clear-History` docs deepen the warning: `Clear-History` clears the current PowerShell session history, but it does **not** clear the PSReadLine history file.
And the current `about_History` docs say PSReadLine history is a central per-host file across sessions and cannot be managed by the `*-History` cmdlets.

That is probably the single clearest “learn from the past” lesson for Schell on this pass:
**never let one visible delete action imply that all memory layers were erased.** See: https://learn.microsoft.com/en-us/powershell/module/psreadline/set-psreadlineoption?view=powershell-7.5
See: https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/clear-history?view=powershell-7.6
See: https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_history?view=powershell-7.5

## 3) Modern terminals already expose separate forget rails for separate residues

tmux's manual says `clear-history` removes and frees pane history, and `-H` also removes hyperlinks.
WezTerm's current scrollback docs say `ClearScrollback` discards the contents of the scrollback buffer and there is no undo.
VS Code's current terminal docs say persistent sessions can reconnect processes or revive them across restart, can be disabled entirely, and have a separate setting for how much scrollback to restore.

These are excellent clues for Schell.
They imply that scrollback, hyperlinks, revived sessions, and visible pane history are all worth naming independently rather than hiding under one vague “terminal memory” story. See: https://man7.org/linux/man-pages/man1/tmux.1.html
See: https://wezterm.org/scrollback.html
See: https://code.visualstudio.com/docs/terminal/advanced

## 4) History tools increasingly expose pruning and deletion as first-class operations

Atuin's current docs say `atuin history prune` deletes entries that match the configured history filter, specifically to remove older entries that were saved before the new filter existed.
Its search docs also expose `--delete` and `--delete-it-all`.

That is a very good pattern for Schell to steal:
- retention filters should be explicit,
- pruning after the fact should be explicit,
- and “future suppression” should stay distinct from “delete past residue.” See: https://docs.atuin.sh/cli/reference/prune/
See: https://docs.atuin.sh/cli/reference/search/

## 5) The host OS keeps teaching that recents and snapshots are their own residue families

Apple's current support docs say macOS has a `Recent Items` menu for applications, documents, and servers, with a separate menu-clearing action.
Safari's current docs say clearing history removes not only visited-page history but also the back/forward list, frequently visited sites, recent searches, icons, and snapshots saved for open webpages.

That is an important broader lesson.
A humane “forget” action in Schell should be able to explain that there may be a *family* of related residues, not just one line in one history log. See: https://support.apple.com/guide/mac-help/open-recently-used-items-on-mac-mchlp2724/mac
See: https://support.apple.com/guide/safari/clear-your-browsing-history-sfri47acf5d6/mac

## 6) The best ideas worth stealing are small and high-leverage

The current ecosystem suggests a very strong decision-light cluster for Schell:
- **private scratch lanes** rather than only one global private toggle,
- **retention chips** on chapters/cards/previews/services,
- **forget-this-family** actions rather than one-file deletion folklore,
- **separate rails for suppress future retention vs delete past residue**, and
- **expiry posture** for useful short-lived memory instead of forcing every hint into indefinite durable history.

Those ideas can make the shell feel much more humane and much safer without forcing one final history database, sync stack, or preview-cache architecture.

## 7) The lesson from the past that matters most here

The old mistake was treating memory as a hidden implementation detail.
The newer mistake would be to add many new smart memory surfaces — semantic history, restored panes, recents, previews, synced chapters, shared runbooks — and still pretend a single “clear” or “private” gesture fully described what happened.

The better answer is:
- make retention posture visible,
- make forgetting scope visible,
- keep future suppression distinct from past deletion,
- and keep synced/exported residue visibly weaker than local erase guarantees.
