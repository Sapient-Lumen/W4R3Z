# Research synthesis — 2026-03-23 — pass CLXV

This pass keeps the archive decision-light while naming the next high-value luxury cluster:
**modern terminals are no longer just proving that semantic marks are useful; they are proving that command chapters become much more trustworthy once they are inspectable, explainable, attachable, and visibly downgraded under drift.**

That is a strong Schell seam because it adds operator delight without forcing one final shell↔terminal treaty, chapter store, or plugin runtime.

## 1) The ecosystem is moving from “marks exist” to “chapters can be inspected”

Current terminal/docs pressure is now more specific than simple prompt marks.
Ghostty continues to push shell integration and prompt-aware cursor movement, and Ghostty 1.3 added scrollback search.
WezTerm keeps exposing semantic zones via OSC 133 and shell/user-state lanes.
iTerm2 continues to make marks and command/output selection first-class.
Windows Terminal now treats shell-integration marks as stable and exposes select-command/select-output plus recent-command suggestions.
VS Code layers on command decorations, hover details, and attach-terminal-command-to-chat context. citeturn811257view0turn712179view1turn811257view14turn811257view1turn811257view2turn811257view5turn811257view3turn811257view4turn600508view1

The important lesson is not that one of these products has the final UI.
It is that chapter-local inspection is becoming the real luxury tier.

## 2) The right lesson from the past is still “do not hide semantics in convenience”

Shellshock remains the blunt reminder that startup/environment seams are execution authority, not decoration.
PowerShell remains a reminder that shell-side tokenization and interpretation can stay surprising when a user thinks they are just handing a native tool one command line. citeturn725450search0turn811257view8

So Schell should not answer current terminal pressure by putting more magic in startup hooks, command-string rewriting, or hover-triggered helper behavior.
The better answer is:
- keep launch semantics tiny and exact,
- then make post-launch reading, comparison, and explanation excellent.

## 3) A chapter inspector object is more valuable than one prettier block UI

The current tools are all circling some version of the same object:
- command identity,
- output region,
- timing/outcome summary,
- working-directory or shell-state context,
- selection/export affordances,
- and nearby follow-on actions.

That means Schell should likely standardize not on one block style but on one compact **chapter inspector object** that can project into:
- a hover summary,
- a chapter-browser row,
- a compare-current-basis card,
- a watch/exact-attention affordance,
- or an attach-for-help bundle.

That is a much better steal than copying one renderer’s chrome whole.

## 4) The missing great UX is “why this?” and “why not?”

Most current tools are getting good at showing that a chapter exists.
Fewer are equally good at answering:
- why this chapter is trusted,
- why this output belongs here,
- why this command is still rerunnable,
- or why stronger actions are blocked/downgraded.

That is the Schell opportunity.
A great custom shell+terminal should normalize cheap answers to:
- **why this chapter?**
- **why not rerun?**
- **why only inspect/insert/attach?**
- **what drift happened since then?**

That move is unusually consistent with SlopOS exactness.

## 5) Several current details are especially worth stealing

A few current ideas look particularly stealable right now:
- VS Code’s attach-terminal-command-to-chat context packet because it shares command line, captured output, and exit code instead of relying on copy/paste folklore. citeturn811257view4
- VS Code’s command-decoration hover details because start time, duration, and exit code are useful chapter summaries. citeturn600508view1
- Windows Terminal’s select-command/select-output and recent-command suggestions because they prove chapter-local navigation/search is worth first-class treatment. citeturn811257view5
- iTerm2’s marks and command/output selection because they make chapter-local review tangible instead of heuristic. citeturn811257view2turn568261search6
- kitty’s hints and open-actions because typed selection and configurable next-step ladders beat one universal click policy. citeturn811257view12turn811257view13
- Nushell’s extern/custom-completion posture, including `display_override`, because it reinforces the split between display convenience and inserted/reviewed bytes. citeturn811257view9turn712179view2turn712179view3
- fish’s recent OSC 7 / OSC 133 improvements because prompt and cwd freshness continue to matter for semantic terminal affordances. citeturn600508view0

## 6) The no-regret move is explanation-rich luxury on top of exact launch

The clearest no-regret cluster now looks like this:
- shell-authenticated chapter objects,
- cheaper hover summaries,
- full chapter inspectors,
- compare-current-basis cards,
- watch-this-exact-chapter affordances,
- attach-for-help bundles,
- typed object ladders,
- and visible `why` / `why not` rails.

That cluster steals the best of current terminals while deferring:
- one final history/chapter database,
- one final hover protocol,
- one universal smart-click/open policy,
- one plugin ecosystem,
- or one assumption that every terminal path preserves provenance equally well.

## 7) Compact conclusion

The next brilliant step for Schell is not “be more magical.”
It is narrower:
**make every magical chapter affordance inspectable and explainable.**

That lets the custom shell+terminal feel super awesome while staying loyal to the older lesson that hidden launch semantics, hidden reparsing, and hidden replay authority are exactly where shells get into trouble.
