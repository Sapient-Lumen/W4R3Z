# SlopOS datacube evaluation — pass CXLVIII

This pass asks a narrower companion-safe question than “how should Schell do session restore?”
The better question is:
**how should Schell grade continuation verbs so remembered, saved, restored, and runtime-preserved context never borrows the strength of live SlopOS truth?**

## 1) SlopOS keeps refusing the flattering generic verb

Even while still in design phase, SlopOS repeatedly protects exact verb meaning.
Its request-vs-live-state posture refuses to let an accepted request impersonate current provider-owned truth.
Its OpenURI family refuses to let launched, shown, recent, or previously selected posture collapse into completion or current-liveness proof.
Its safe-open and quarantine seams refuse to let inspect, preview, import, and stronger acts flatten into one open story.

That is the direct Schell companion lesson:
**continuity verbs matter.**
Attach, reconnect, restore, rerun, relaunch, insert, and inspect should stay separately named.

## 2) Revivability grades fit SlopOS better than one smart-session object

A Schell surface that says “resume” is too flattering for the SlopOS family.
A Schell surface that says:
- live attachable,
- runtime reconnectable,
- view restorable,
- review rerunnable,
- relaunchable,
- insertable,
- inspect only,

is much more companion-safe.
It preserves delight while protecting claim strength.

## 3) Capshell pressure says old context must not silently spend current footing

SlopOS capshell posture keeps refusing hidden PATH lookup, hidden shell parsing, ambient startup magic, and portable PTY folklore.
That means old or preserved context should rarely get a strong default verb.

Good companion answer:
- remembered commands may insert or compare,
- saved artifacts may relaunch or land in review,
- restored rooms may orient and offer gated rerun,
- runtime-preserved context may reconnect while it is actually live,
- and only fresh reviewed footing should spend current execution truth.

## 4) The companion cubes reinforce the same split

ViewFS keeps handles, refs, receipts, remembered designators, and live state distinct.
That suggests Schell should keep saved kits, restored rooms, runtime lockers, and live attach points as different object classes.

Steward keeps freshness decay and replay gates explicit.
That suggests Schell should make drift demote the strongest honest verb before the object disappears.

Helm keeps basis packets, restore honesty, cockpit truth, and entry-kit posture separate.
That suggests Schell should show which continuation act is truly available rather than saying all old context can just continue.

## 5) What Schell should steal now

Schell should steal several excellent outside moves, but import them as graded continuation verbs:

- runtime reconnect versus relaunch distinction,
- restored-room depth badges with rerun gates,
- launch kits and session files as relaunch artifacts rather than fake liveness,
- remembered command rows that decay from rerun toward insert/inspect,
- and shell-integration marks as reacquisition witnesses rather than authority.

## 6) What Schell should refuse now

Schell should refuse:

- one generic resume button,
- saved config equals live room,
- restored output equals current prompt,
- previous approval equals current approval,
- and hidden drift behind familiar-looking continuity.

## 7) Compact conclusion

The companion-safe answer is not to avoid continuity luxury.
It is to **grade continuity by strongest honest verb**.
If Schell keeps attach, reconnect, restore, rerun, relaunch, insert, and inspect visibly distinct — with claim-strength badges and drift demotion — it can become much more humane than shell folklore while staying aligned with SlopOS exactness during the design phase.
