# Research synthesis, pass CVII (2026-03-22)

This pass keeps one fresh rule in focus:
**a shell+terminal gets much more trustworthy when bells, finish notices, OSC-driven notifications, progress pings, and click actions are treated as different truth families instead of one flattering “the terminal alerted me, so the story is clear” blur.**

The current ecosystem is unusually revealing here.
Ghostty's BEL docs say a bell can now mean sound, flash, focus/raise, icon bounce, or desktop notification, and Ghostty's 1.3.0 release adds command-finished notifications with explicit controls for focus posture, action kind, and minimum duration.
kitty then goes much further with OSC 99 desktop notifications: it supports title/body payloads, optional click-to-focus, and even an optional escape sent back to the application when the notification is activated, while still enforcing plain-text payloads.
WezTerm exposes notification handling for OSC 9 and OSC 777 and lets operators suppress notifications from the focused pane, focused tab, or focused window instead of pretending focus does not matter.
iTerm2 keeps showing the value of command-bound watch objects through Alert on Next Mark, while also cautioning that its proprietary escape codes are non-standard and may have unknown effects in other terminals or through tmux/screen.
foot's current docs are perhaps the bluntest reminder that attention routing is policy: a BEL can ring the system bell, signal urgency, emit a desktop notification, flash visually, or run a command, with focused-window suppression as a separate policy and activation/focus handoff treated as a more complicated path.
Windows Terminal is simpler but still useful evidence: even there, `bellStyle` is already a routing choice among audible, window flash, taskbar flash, all, or none.
Warp's current docs add one more sharp insight: command-finished notifications and password-needed notifications are worth separating, and it explicitly supports OSC 9 and OSC 777 hooks while only notifying when another app is active.

## 1) The ecosystem is converging on focus-aware command-bound interruption, not generic notification spam

The most stealable pattern is not “support notifications.”
It is much narrower:
- bind alerts to a command, shelf item, or exact watch object,
- delay them until a minimum runtime or meaningful state transition,
- and suppress or downshift them when the originating surface is still focused.

Ghostty's finish-notification settings, Warp's away-from-app behavior, WezTerm's focused-pane/tab/window suppression, and iTerm2's alert-on-next-mark all point in the same direction.
That is exactly the kind of humane luxury Schell should steal.

## 2) Bells are now routing inputs, not just sounds

Ghostty, foot, Windows Terminal, and the wider terminal ecosystem all show that `BEL` is no longer just a noise.
It is a request that local policy may route toward sound, flash, urgency, taskbar attention, desktop notification, or nothing.

That means Schell should stop treating bells as durable meaning.
A bell should be modeled as a bounded attention request with visible routing and visible suppression.
It may correlate with a command chapter.
It may not.
It may be the weakest possible cue.

## 3) Notification protocols are fragmented enough that Schell should witness them instead of canonizing them

The current landscape is still split across:
- local `BEL`,
- OSC 9,
- OSC 777,
- OSC 99,
- OSC `9;4` progress bars,
- shell-mark watchers,
- and terminal-specific finish-notification features.

iTerm2's proprietary-escape docs are especially useful because they say the quiet part out loud: these escapes are non-standard, may not work well through tmux/screen, and may have unknown effects on other terminals.
foot's manual also makes the fragmentation obvious by documenting both OSC 777 and OSC 99 support through its desktop-notification layer.

So the right move for Schell is not to freeze one final external notification wire protocol because several current terminals happen to overlap.
The right move is to keep protocol family, origin strength, focus posture, and action posture explicitly witnessed.

## 4) Clickable notifications are valuable exactly because they are dangerous

kitty's OSC 99 docs are superb evidence here.
They allow a notification click to focus the originating window and/or send an escape code back to the application.
That is powerful.
It is also a crisp reminder that a clicked notification can become a hidden callback lane if the shell+terminal is sloppy.

foot's docs make the same problem look even more operational: notification activation may require an action callback and an XDG activation token, and the exact behavior depends on the notification daemon.

So Schell should absolutely steal notification clicks.
But the default ladder should still be:
- focus,
- reveal,
- jump to the exact command chapter or shelf item,
- show durable outcome truth,
- and only then offer stronger reviewed actions.

## 5) Progress and blocked-input cues deserve separate semantics

Warp's docs explicitly distinguish command-completed notifications from password-needed notifications.
That is more important than it sounds.
A shell that only knows “done” and “bell” is too small.

The better split is:
- generic bell,
- progress update,
- blocked-input / needs-you,
- completion cue,
- and durable result state.

That is the right way to make interruption useful without letting attention cues impersonate outcome truth.

## 6) The best no-regret move is a notification witness family

A compact witness could begin with:
- `cue_kind`,
- `transport_family`,
- `origin_strength`,
- `focus_posture`,
- `delivery_posture`,
- `action_posture`,
- `result_binding`,
- and `privacy_posture`.

That is already enough to answer questions current terminals often leave fuzzy:
- why did I get a toast here but only a badge there?
- why did this finish alert not fire while the tab was focused?
- was this raised by the shell, by a helper, or by raw OSC from an app?
- does clicking this toast only focus, or can it feed data back into the session?
- is there a durable result card behind this attention cue or not?

## 7) Compact conclusion

One of the smartest no-regret moves available right now is:
**make notification footing first-class, but keep bells, toasts, progress cues, blocked-input cues, clicked actions, and durable results separately named.**

That lets Schell steal some of the best current terminal comfort without prematurely deciding the whole notification protocol, inbox/history model, click-action model, or progress transport. 
