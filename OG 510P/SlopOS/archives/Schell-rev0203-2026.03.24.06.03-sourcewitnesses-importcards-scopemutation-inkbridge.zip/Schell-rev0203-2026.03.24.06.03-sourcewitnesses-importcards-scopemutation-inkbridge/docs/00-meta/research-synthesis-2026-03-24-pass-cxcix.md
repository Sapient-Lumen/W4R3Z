# Research synthesis — 2026-03-24 — pass CXCIX

This pass sharpens another old shell lesson that still matters for a brand-new shell+terminal:
**ambient shell options are powerful, but they should not silently erase the difference between inherited baseline, startup imports, local overrides, block-local strictness, and the exact reviewed command basis.**

## 1) Current shells already prove that mode is not one thing

Bash still states the problem most plainly.
Its manual says the `set` builtin changes shell options and positional parameters.
But Bash does not stop there.
The same manual documents that `local -` makes shell options local to the current function, restoring later `set` changes when the function returns.
That means even classic Bash already distinguishes between ambient shell posture and scoped temporary posture.

Bash then adds a startup wrinkle that is easy to underestimate.
The `BASHOPTS` and `SHELLOPTS` variables are documented as startup imports: if they are present in the environment when Bash starts, Bash enables those options **before reading any startup files**, and exported values influence child shells.
So option posture can come from inheritance before any visible line in the current shell explains why behavior changed.

zsh is even more explicit about shell-mode hygiene.
Its options docs say `LOCAL_OPTIONS` restores most options to their entry values when a shell function returns.
They also recommend `emulate -L zsh` to give a function a known configuration while activating local option restoration.
That is not just a convenience macro.
It is a direct admission that helper code needs a named baseline and an automatic restore story.
The sibling `LOCAL_TRAPS` option reinforces the same lesson for another rule family.

PowerShell teaches the same lesson from a stricter and more versioned angle.
`Set-StrictMode` applies to the current scope and child scopes, not the parent, and the rules are versioned.
This is an unusually clean precedent for Schell: safety posture can be stronger without pretending that one global strictness flag explains everything.

fish is valuable because it resists the usual giant option soup.
Its current docs surface runtime posture through `status`, including interactive/login state, job-control mode, feature flags, and terminal feature tests.
The fish language docs describe feature flags as staged, script-affecting changes.
The important lesson is not that Schell should copy fish’s exact interface.
The lesson is that a shell can name active feature posture explicitly instead of hiding everything in startup folklore.

Nushell points toward a more structured future.
Its docs describe overlays as activatable/deactivatable layers of definitions and environment, `export-env` as preserving environment changes in the current scope, one-shot environment variables as block-limited, and environment variables as typed values.
That is not a one-to-one shell-option system, but it strongly argues that posture should be layered and scope-shaped rather than ambient and mysterious.

## 2) The lesson Schell must learn from the past

The historical mistake is not just that people forget which shell options are on.
The deeper mistake is **flattening shell posture into hidden ambient truth**:
- the baseline the shell started with,
- the startup imports that altered it,
- the emulation or compatibility personality now in force,
- the helper-local or block-local overrides,
- the restore rules,
- and the exact reviewed command basis that will spend under those rules.

Once these collapse, three bad things happen:
1. command review stops being exact because the operator cannot easily see what rule family is actually active,
2. transcripts and exports preserve text but forget the posture that gave that text meaning,
3. and helper code launders stricter or looser semantics into ambient truth.

## 3) The nifty ideas worth stealing are scope-shaped

The current ecosystem points to several low-regret steals:
- **baseline cards** that say `default`, `startup import`, `project overlay`, `compat emulation`, or `helper-local`,
- **strictness chips** that say exactly which rule family is active and, where relevant, its version,
- **delta strips** that show what changed relative to inherited posture,
- **scope badges** that say `global`, `function-local`, `child scope`, `block-local`, or `overlay-local`,
- **restore receipts** that say whether the previous posture returns automatically or only by explicit rollback,
- **known-profile capsules** in the spirit of zsh `emulate -L` so a helper can say “I run under this named baseline”,
- and **review compare rows** that show the same command basis under current posture versus parent/default posture.

These are super awesome because they improve trust without forcing Schell to decide one final option namespace, startup treaty, or compatibility story.

## 4) The moves Schell should refuse for now

Schell should refuse, for now:
- one generic “safe mode” badge that hides which rules changed,
- startup imports that have no visible witness,
- helper code that toggles shell behavior without a visible restore story,
- export/transcript surfaces that preserve only command text but not posture receipt,
- and any insistence that every future mode must collapse into one flat option list.

In other words:
**steal the speed of local strictness and known baselines, not the ambiguity of ambient option folklore.**

## 5) The no-regret Schell seam

Schell should add one dedicated surface for:
- inherited baseline,
- startup influence,
- compatibility/emulation profile,
- exact rule delta,
- strictness family and version,
- scope of effect,
- restore posture,
- review relation,
- and later posture receipt.

That lets the shell feel much smarter around strictness toggles, project profiles, and helper-local safety bundles without deciding whether the long-term answer is POSIX-like shell options, structured overlays, typed execution policies, or some hybrid.

## 6) Compact conclusion

Current official docs line up well here.
Bash shows that shell posture can arrive from startup imports and can be made function-local.
zsh shows that helpers benefit from named local baselines and automatic restoration.
PowerShell shows that strictness can be versioned and scope-bounded.
fish shows that runtime feature posture can be queried rather than guessed.
Nushell shows that environment and definitions can be layered explicitly.

So the next low-regret Schell seam is **option witnesses, strictness scopes, and startup-mode humility** so shell-mode comfort stays powerful and delightful without becoming hidden command truth.
