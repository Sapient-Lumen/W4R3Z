# SlopOS datacube evaluation, pass LII

**If Schell ever offers a prettier, field-like, token-aware active input, it must still preserve one exact reviewed launch shape. SlopOS keeps teaching the same lesson: structured argv, exact executable identity, and no hidden shell-language fallback matter more than pleasant display.**

This pass focuses on another dangerous seam for Schell:
- prettier active input,
- exact argv reveal,
- quote/escape strategy,
- byte-vs-string handling,
- and token-local editing that still launches one exact reviewed action.

This seam is dangerous because products love to present it as harmless “editor polish.”
In practice it is where shells quietly reintroduce command-string folklore, mutable-name reopening, word expansion, byte/string corruption, and provider-side quoting decisions.
SlopOS already says not to do that.

## 1) SlopOS CH-ARGV posture says reviewed launch shape is already a typed token list

The argv schema is one of the cleanest imports in the companion archive.
It treats argv as a capability-bound token list with literal tokens and descriptor references, explicitly rejects ambient-authority acquisition via literal strings, and requires exact executable selection through one `role="exec"` descriptor.
That is the deepest Schell clue in this pass.
If Schell shows a prettier argument-local surface, that surface should still be understood as **a view over reviewed argv shape**, not a second command-language plane.

## 2) SlopOS command-string posture says there is no hidden adapter back to shell folklore

The capshell command-string posture is even more direct.
The runner must not become a shell parser, tokenizer, or hidden `sh -c` / `system()` adapter.
That means any Schell prettification must stop before it launders visible input back into some private command-string representation that later gets reparsed.
The import is simple:
**pretty does not mean reparsed.**

## 3) SlopOS executable-object posture says exact identity stays stronger than any nice name or label

The executable-object posture closes the next seam.
Once execution has been reviewed against one exact executable object, SlopOS forbids late reopen or name-based retargeting at launch.
That directly pressures any future Schell pretty-token or exact-reveal view.
If the operator edits something that affects executable identity, peer/service target, script interpreter, or secret-bearing descriptor, that must surface as basis drift rather than hiding behind a prettier label.

## 4) SlopOS word-expansion refusal means helper quoting cannot silently widen meaning

The argv and capshell postures together already reject pre-exec shell-like expansion before review/binding.
No hidden tilde expansion, globbing, variable substitution, process substitution, or shell-source reconstruction gets to sneak in under “helpful formatting.”
That should become a Schell law too.
If a helper inserts quotes, escapes, or a prettier token rendering, it must not thereby choose extra shell-language semantics that the operator never reviewed.

## 5) SlopOS exactness also pressures byte/string honesty

The companion archive keeps choosing exact bytes, exact descriptors, exact refs, and exact handler boundaries over flattering convenience.
That pressure maps naturally onto shell I/O too.
If Schell later offers richer pipeline or preview surfaces, it should not let a pretty display lane quietly become the transport lane for exact bytes.
The right import is the same as elsewhere in SlopOS:
**renderer-local or helper-local convenience remains weaker than reviewed transport truth.**

## 6) What SlopOS pressures Schell to steal

The strongest import is a compact posture cluster:
- one pretty active-input view that is explicitly weaker than exact reveal,
- one argv witness family that can show token kind and provenance,
- one exact-reveal ladder for executable-bearing and authority-bearing tokens,
- one visible escape/quote witness when insertion or normalization happened,
- one copy/export split between pleasant shell text and exact argv/value form,
- and one strict refusal to reparse hidden command strings at the launch seam.

## 7) What Schell should deliberately refuse

### Refuse pretty surfaces that become a second parser

A nice token view is allowed.
A helper-owned hidden language plane is not.

### Refuse quote/escape decisions without visible provenance

If the shell inserted quotes, collapsed escapes, or chose a shell-text rendering for presentation, the operator should be able to see that exactness seam.

### Refuse exact-reveal gaps on authority-bearing tokens

Executable selectors, writable paths, peer/service targets, open destinations, and secret-bearing handles deserve stronger exact reveal than ordinary literals.

### Refuse byte/string laundering through pretty previews

Preview or transcript formatting must remain weaker than exact transport when the operator actually cares about raw data.

### Refuse historical prettification as fresh authority

History, chapter cards, and transcripts may import into active input.
They should not themselves silently become the live authoritative edited object.

## 8) Current consequence for Schell

The best next step still looks compact:
1. one **argv witness** surface in active input,
2. one **pretty view / exact reveal** ladder,
3. one **escape witness** or quote-provenance cue,
4. one **basis drift** cue for executable- or authority-bearing tokens,
5. one **copy shell text / copy exact argv** split,
6. and one refusal to let display convenience outrun reviewed launch shape.

That is enough to make Schell feel much more humane while still keeping parser, workflow syntax, pretty-token UI, and transport choices open.
