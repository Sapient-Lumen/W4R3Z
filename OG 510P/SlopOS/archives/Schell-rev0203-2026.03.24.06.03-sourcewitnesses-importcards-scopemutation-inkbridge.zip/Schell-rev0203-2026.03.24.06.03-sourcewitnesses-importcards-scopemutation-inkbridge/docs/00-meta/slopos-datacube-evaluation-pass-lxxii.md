# SlopOS datacube evaluation, pass LXXII (2026-03-22)

This pass evaluates one new companion import:
**Schell should absolutely grow explicit migration ladders, compatibility report cards, shadow packs, one-shot activation rails, retired-prompt breadcrumbs, and interactive-state wallets, but SlopOS pressure says imported profiles, prompt hooks, ranking stores, and legacy shell bridges must remain visibly non-native so migration never reopens ambient authority.**

## 1) SlopOS already says startup compatibility cannot be innocent

The `capshell-startup-profile-posture-v0` surface is blunt.
Integrated startup is explicit-only.
Implicit rc/profile discovery is out.
Prompt redraw and cwd changes are not code-loading events.
That means compatibility with old shell ecosystems cannot land as “just source the old profile and call it good.”
If Schell carries legacy startup material at all, it should do so as a reviewed bridge with explicit claim strength.

## 2) SlopOS also says env mutation must stop pretending to be background decoration

The `capshell-env-startup-posture-v0` surface keeps child environment meaning explicit and rejects hidden startup-hook widening.
That maps directly onto the migration seam.
The old ecosystem is full of prompt hooks and activation tricks.
SlopOS pressure says those should become:
- observed overlays,
- previewable diffs,
- one-shot execution rails,
- or explicit session/project leases,
rather than silent prompt-time mutation.

## 3) The companion datacube keeps pushing Schell toward explicit bridge grades

The `llm-operations-posture-v0` surface says tool/resource/prompt catalogs are explicit and bounded and that hidden cross-run memory does not count.
The same discipline should apply to shell migration.
Imported profiles, imported prompt helpers, imported directory-history stores, imported completion engines, and imported per-project tool selectors should all be explicitly inventoried.
A bridge should say what it touches and what it does **not** become.

## 4) SlopOS also provides the right emotional posture for migration: observational first

The `capshell-learnmode-posture-v0` surface keeps learning observational-only and refuses auto-edit or auto-rerun authority.
That is exactly the right migration mood.
Schell should be willing to:
- observe a legacy setup,
- summarize it,
- run it in shadow compare,
- and suggest a native replacement,
without silently enabling or rewriting it.
Migration help should remain proposal material until the operator chooses a stronger step.

## 5) The biggest import for Schell is a compatibility ladder rather than a single compat mode

The SlopOS companion pressures now suggest a concrete ladder:
1. **inventory only** — report card for imported profiles, hooks, ranking stores, and persistent state,
2. **shadow compare** — native and bridged behavior side by side,
3. **one-shot activation** — exact command with exact overlay,
4. **session lease** — explicit temporary bridge,
5. **project lease** — explicit reviewed per-project posture,
6. **native pack** — bridge retired.

That is much better than one giant “compatibility mode” switch.
It keeps the bridge reversible and makes progress measurable.

## 6) Some particularly strong Schell moves now look no-regret

The best SlopOS-compatible moves from this seam are:
- **compatibility report cards** for imported rc/profile/prompt/env/history state,
- **shadow packs** that compare native versus bridged output without promoting the bridge to truth,
- **retired-prompt breadcrumbs** so transient prompt luxury keeps enough historical witness,
- **directory-memory decks** that stay weaker than exact reviewed navigation,
- **interactive-state wallets** that separate local persistent convenience from script truth,
- and **activation ladders** that prefer one-shot or leased overlays to hidden prompt mutation.

## 7) Things this pass still refuses to decide too early

This pass does **not** force:
- one final importer for Bash/Zsh/Fish/PowerShell ecosystems,
- one final legacy-profile execution substrate,
- one final ranking/history storage format,
- one final prompt retirement schema,
- or one final migration assistant.

The answer is smaller and stronger:
**make migration explicit, comparative, and lease-shaped while keeping native Schell truth separate from imported shell folklore.**
