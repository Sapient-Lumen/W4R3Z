# SlopOS datacube evaluation, pass LVIII (2026-03-21)

This pass evaluates one new companion import:
**Schell should absolutely become better at diff/patch review, dirty-tree isolation, disposable worktrees, and explicit rewind classes — but SlopOS pressure says those luxuries must terminate in exact reviewed action shape rather than turning into a hidden “edit state machine” or a fake universal rollback promise.**

## 1) SlopOS already pressures us away from ambient patch folklore

One load-bearing SlopOS clue is already sitting in the architecture posture set:
`capshell-command-string-posture-v0.md` refuses hidden shell parsing and adapter folklore,
while `approval-basis-posture-v0.md` refuses “follow the current head” approval semantics.
That matters directly for patch review.
A suggested edit cannot be treated as “good enough because the current tree is nearby.”
If the patch depends on an exact basis, that basis has to stay visible.
If the basis drifts, the reviewed object must drift with it.

## 2) Learn-mode posture pressures proposal-only edit help

`capshell-learnmode-posture-v0.md` remains a useful import here.
It keeps observational help weaker than execution.
That same law should govern patch luxuries.
Showing a diff, offering a hunk split, or suggesting a cleanup patch is valuable.
But those affordances should remain proposal-first.
The shell+terminal should not blur a detector, assistant, or inline helper panel into actual live tree mutation.

## 3) Exec-object posture says exact action still wins

SlopOS keeps returning to exact action objects, exact bytes, and exact witnesses.
That is a strong warning against a vague “editor already changed stuff, just continue” story.
Even when Schell adopts richer patch and diff comforts, the stronger action still needs a named reviewed shape:
apply to active tree,
stage selected hunks,
commit exact patch,
revert with new patch,
or discard a disposable worktree.
Those verbs should not collapse into one flattering “accept changes” button.

## 4) Init-snapshot posture is a useful anti-overreach clue

The SlopOS init-snapshot posture explicitly refuses a portable runtime create/apply/patch/list/watch/export plane.
That is an excellent restraint for Schell too.
Schell does not need to invent a grand universal patch substrate for the whole operating model.
It only needs an honest shell+terminal review layer that can carry patch witnesses and dirty-isolation posture.
The review surface can stay smaller than the total system story.

## 5) Plumb posture gives us the right routing instinct

SlopOS plumb posture keeps routing explicit and request-local rather than hidden and ambient.
That is exactly how Schell should treat edit proposals.
A patch witness may be routed to inspect, split, stage selected hunks, apply in disposable worktree, promote, or discard.
Those are explicit routes.
They should not become a hidden callback chain where helper panels quietly rewrite the active tree behind the shell's back.

## 6) Background/request-state posture pressures worktree honesty

The archive already distinguishes request identity from current live grant truth.
That lesson imports cleanly into disposable worktrees and scratch edit zones.
A background helper working in a disposable worktree is not the same thing as the active local checkout.
A queued patch proposal is not the same thing as an applied patch.
A scratch zone being available is not proof that its contents are now the current tree.
Schell should keep worktree identity and promotion state explicit.

## 7) What SlopOS most strongly warns us not to do

Under current SlopOS pressure, Schell should refuse:
- patch proposals that silently follow a newer tree head than the reviewed basis,
- helper-generated edits that bypass shell-owned review objects,
- generic “undo” wording for actions that are really revert, reset, drop-worktree, or non-rewindable side effects,
- dirty-tree blending that makes old local changes indistinguishable from new proposed edits,
- and any patch/apply surface that quietly becomes a hidden admin/workflow plane.

## 8) The clean import: patch witnesses and undo classes

A SlopOS-compatible import now looks like this:
- every proposed edit becomes a **patch witness** with exact basis and provenance,
- every stronger action says where it lands (active tree, staged area, disposable worktree, or elsewhere),
- every dirty situation shows explicit isolation posture,
- every recovery path carries an explicit **undo class**,
- and external side effects stay outside the patch-rewind fantasy.

## 9) Decision-light next move

A strong next move is to define one **patch witness / dirty-isolation / undo-humility** family that proves:
- partial hunk review,
- patch editing,
- disposable worktrees,
- promote-versus-discard,
- and explicit rewind classes
can all coexist without turning Schell into a hidden version-control state machine or a fake rollback oracle.

That keeps Schell ambitious while learning the right lesson from SlopOS:
**modern edit luxury is welcome, but exact basis, exact landing zone, and honest rewind class stay stronger than charm.**
