# SlopOS datacube evaluation — pass CLVIII

This pass asks a narrower companion-safe question than “how should Schell remember login state?”
The better question is:
**how should Schell expose local brokers, presence checks, and refreshable mediator sessions without letting them impersonate portable shell authority?**

## 1) SlopOS keeps imported auth machinery provider-local, which should pressure local brokers too

SlopOS is still in design phase, but its newer auth boundaries are already very sharp.
PKCE handling, redirect mechanics, trust-policy checks, metadata fetches, and exact-match validation stay provider-local rather than becoming portable shell truth.
That same discipline should carry into the local host side.

A local broker session is useful evidence.
It is not itself portable account truth, proof, or approval history.

## 2) SlopOS exactness suggests a smaller split: mediation, adoption, and active binding should stay different

A shell+terminal can honestly say:
- a local broker or desktop app asked for presence,
- the operator satisfied that challenge,
- a local sink now holds something refreshable,
- and the current shell has or has not adopted that into active account/profile state.

That is the same kind of exactness SlopOS keeps elsewhere.
The mistake would be to collapse those moments into one warm badge like `authorized`.

## 3) ViewFS pressure says mediator handles, adopted local objects, and live current use should stay distinct

ViewFS repeatedly refuses to collapse offers, handles, adopted objects, and live current state.
That pressure transfers cleanly here.
A WAM session, a 1Password terminal-local authorization lease, a credential-store row, a disk cache, a selected profile, and a current active account binding are not one object.

So Schell should keep mediator lease, sink posture, and active binding visibly separate.

## 4) Steward pressure says retries and expiries should stay exact, not atmospheric

Steward keeps pushing precise retry posture.
That is exactly what brokered auth and secret mediators need.
Operators need to know:
- did the broker lease expire,
- is this terminal still approved,
- did the sink survive but the binding drift,
- is re-prompt safe here,
- and which part actually needs retry.

That makes typed broker witnesses much better than generic “reauth required” prose.

## 5) Helm pressure says return anchors and reset cards matter after local mediation too

Helm keeps teaching that historical-looking success is dangerous when the basis drifted.
That matters here.
A broker window may be gone, a biometric challenge may have been satisfied on behalf of another terminal, a cached session may still exist even though the active account changed, or a refreshed sink may no longer match the currently intended subject.

So Schell should pair broker witnesses with exact return/reveal anchors and reset cards.

## 6) What Schell should steal now

Schell should steal several high-value moves:
- broker chips that name the mediator (`WAM`, desktop app, keyring helper, remote bootstrap, none),
- presence-proof chips (`Windows Hello`, fingerprint, OS password, hardware key, none),
- subject cards that keep account/tenant/profile selection explicit,
- lease countdown or refresh-on-use posture,
- sink reveal cards that distinguish app-held, keyring, disk cache, and plaintext fallback,
- and historical fade/reset when a terminal-local authorization no longer matches the current footing.

These are great luxuries and do not force Schell to settle one final broker, secret store, or callback architecture.

## 7) What Schell should refuse now

Schell should refuse:
- broker-approved counting as generic shell approval,
- disk-cached or keyring-stored counting as active binding,
- host-global mediator success counting as terminal-local success,
- browser relay success counting as local adoption here,
- and a previous terminal’s authorization lease counting as current exact footing in this one.

## 8) Compact conclusion

The companion-safe move is to keep **local brokers, presence checks, lease refresh, sink posture, and active account binding** separately witnessed.
That lets Schell become dramatically more humane around modern brokered CLI auth and secret mediation while staying aligned with SlopOS’s refusal to turn imported mechanism details into portable truth.
