# Research synthesis, pass XL (2026-03-21)

This pass focuses on one bounded seam that Schell did not yet give its own terminal surface:
**modern terminal and developer-tool accessibility is getting better, but the ecosystem keeps proving that accessibility is both a structure problem and an authority boundary, so Schell should steal the humane review ideas without letting assistive access quietly become ambient automation or stale alternate truth.**

## 1) VS Code shows the strongest no-regret pattern: accessible review should hang off known structure

VS Code’s accessibility docs say screen-reader mode applies to the Integrated Terminal, the terminal has accessibility help, terminal output can be opened in Accessible View, and shell integration makes commands like Run Recent Command, Go to Recent Directory, and Go to Symbol in Accessible View particularly useful in screen-reader workflows.
That is a strong hint for Schell.
A screen reader should not need to infer everything from scrollback if command boundaries and semantic waypoints are already known.

See: https://code.visualstudio.com/docs/configure/accessibility/accessibility

## 2) GitHub CLI shows the old terminal mistake clearly: redraw-heavy prompts and spinners do not narrate well

GitHub’s May 2025 accessibility writeup says terminal accessibility lacks one comprehensive standard, their accessible CLI work focused on screen readers, contrast, and customizable colors, and their legacy rich prompts and redraw-heavy spinners were difficult for speech synthesis screen readers to interpret.
They responded by redesigning prompting and looking at better table formatting for screen-reader interpretation.

That is a direct lesson for Schell:
rich prompt UX should always have a stable, reviewable alternate form.
Animated polish is fine.
It is not enough.

See: https://github.blog/engineering/user-experience/building-a-more-accessible-github-cli/

## 3) PowerShell shows a great “escape the terminal on purpose” move

Microsoft’s guidance for screen-reader-friendly PowerShell output recommends reducing output volume, preferring list formatting for narration, and for some workloads sending data to more accessible tools such as Out-GridView, CSV, or HTML viewed in a browser or spreadsheet.
This is a brilliant steal for Schell.
The most humane review surface for some results is not the raw terminal buffer at all.

The key import is not “launch random viewers.”
It is:
**alternate review surfaces should be explicit, accessible, and weaker than the live shell truth they summarize.**

See: https://learn.microsoft.com/en-us/powershell/scripting/learn/shell/output-for-screen-reader?view=powershell-7.5

## 4) Ghostty exposes the permission boundary nicely

Ghostty’s 1.2.0 notes say macOS now has read-only accessibility API integration so screen readers can read Ghostty’s structure and contents, and that this requires accessibility permissions and is opt-in.
The same release separately mentions App Intents integration for automation with Apple Shortcuts.
That split is exactly the kind of discipline Schell should preserve:
readability and automation are adjacent, but they are not the same grant.

See: https://ghostty.org/docs/install/release-notes/1-2-0

## 5) Apple and Windows both confirm the security lesson: accessibility often carries real control power

Apple’s support docs say that when a third-party app tries to access and control your Mac through accessibility features, the user must specifically grant access in Privacy & Security, and Apple explicitly warns users to grant access only to apps they know and trust.
Windows’ UI Automation docs say UI Automation provides programmatic access to UI elements, enables screen readers to provide information, and also enables interaction with UI by means other than standard input; Microsoft’s security guidance says assistive technologies cross process boundaries, may need special privileges, and should not use these powers outside accessibility scenarios.

That is the biggest historical lesson in this seam:
**accessibility cannot be treated as harmless read-only decoration by default.**
The boundary has to be named.

See: https://support.apple.com/guide/mac-help/allow-accessibility-apps-to-access-your-mac-mh43185/mac
See: https://learn.microsoft.com/en-us/windows/win32/winauto/uiauto-uiautomationoverview
See: https://learn.microsoft.com/en-us/windows/win32/winauto/uiauto-securityoverview

## 6) Warp is a useful warning: accessibility can improve even while the navigation model is still unfinished

Warp’s accessibility page says the feature is currently macOS-only, screen-reader support on Linux and Windows is still being tracked, and Warp auto-announces what is happening even though there is not yet a way to navigate between UI elements using standard VoiceOver key combinations.
This is a valuable reminder for Schell.
Good intentions and partial narration are not the same as a complete accessible interaction model.

See: https://docs.warp.dev/terminal/more-features/accessibility

## 7) GNOME’s Newton work points to a deeper architectural steal

GNOME’s accessibility team describes Newton as a push-based accessibility architecture where applications push serialized accessibility tree updates, the compositor is the authority on focus and what gets sent to assistive technologies, and the design aims to work with sandboxing rather than relying on ambient buses or injection.
The same writeup notes unresolved terminal-widget support and explicitly treats keyboard interception as a sensitive design point.

This is especially relevant to Schell because it suggests a beautiful long-term direction:
- keep shell-known command/output/object structure explicit,
- push structured accessibility updates instead of forcing every assistive tool to scrape the display matrix,
- and separate tree updates from action requests.

See: https://blogs.gnome.org/a11y/

## 8) The best steal is not one accessibility API; it is one assistive-witness lane

The no-regret import is small:
- assistive observation should be explicit,
- accessible review should prefer shell-known chapters/cards/objects,
- redraw-heavy rich UX should have stable narration alternates,
- alternate review surfaces such as grids, CSV, or HTML should be explicit actions,
- and observation should stay weaker than injection or full UI automation.

That keeps Schell free to defer the actual bridge choices while still making the shell+terminal much better for real users.

## 9) The lesson from the past that matters most here

The old mistake was assuming terminal text is automatically accessible because it is text.
The newer mistake would be assuming that once a terminal exposes structure to assistive tooling, the same seam can safely grow into global automation, injection, or stale accessibility caches without a new authority story.

The better answer is:
- accessibility must be designed,
- assistive structure should be shell-known where possible,
- observe and inject should stay separately named,
- and accessible mirrors should stay visibly weaker than current live truth when they are restored, cached, or exported.
