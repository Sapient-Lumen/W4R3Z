# Research synthesis, pass CXXII (2026-03-22)

This pass keeps one narrower lesson explicit:
**Schell should treat terminal self-description as explicit query windows and reply capsules, not as ambient bytes that happened to show up on the TTY.**

The strongest current evidence is surprisingly direct.
kitty's `query_terminal` docs say the helper sends escape codes, waits for a response, and warns other programs not to perform any I/O on the terminal device until the helper exits.
That is almost the whole design lesson in one sentence.
A terminal query is not just a display nicety.
It is a bounded interrogation moment sharing a fragile lane.

The rest of the ecosystem reinforces the same lesson from different angles.
xterm still documents query families such as XTGETTCAP.
Contour documents live feature detection and reply flows for synchronized output, line reflow reconfiguration, theme-mode detection, font settings, and semantic block queries.
tmux reminds us passthrough is an explicit policy choice, so relays can preserve, translate, or suppress query traffic.
And VS Code's nonce warning keeps teaching the same broader humility rule: semantic-looking terminal bytes are not self-authenticating just because they arrived.

Taken together, the design-phase answer for Schell is clear:

## 1) A terminal question deserves an explicit witness

The shell+terminal should know:
- who asked,
- what family of question was asked,
- what reply family was expected,
- whether the question carried a challenge or request id,
- how long the window remained valid,
- and whether overlapping TTY I/O was forbidden, tolerated, or unknown.

That is enough to keep query posture legible without freezing a huge protocol stack.

## 2) Query replies should become reply capsules, not bare bytes

A reply should keep:
- the query window it answers,
- a raw digest,
- a parsed value family,
- relay posture,
- freshness posture,
- timeout/strip/contradiction status,
- and the strongest safe unlock the UI is allowed to derive from it.

This keeps terminal replies useful while refusing to let them become shell truth or approval truth by accident.

## 3) Action strength should stay modest

Live replies can absolutely improve:
- inspectors,
- downgrade explanations,
- rendering posture,
- feature cards,
- and one-shot “why is this weak here?” debugging.

They should **not** automatically unlock stronger shell actions, approval reuse, or authority-bearing continuation.

## 4) Steal challenge-bound introspection rather than ambient interrogation

The best product move here is not “query everything all the time.”
It is:
- reviewed issuer,
- bounded query window,
- explicit timeout,
- reply capsule,
- relay confession,
- and downgrade cards.

That would make Schell feel unusually smart and unusually honest at the same time.

## 5) Compact answer

Schell does **not** need one final introspection bus yet.
It needs a bounded move:
- terminal-query witnesses,
- reply capsules,
- challenge-bound probes,
- timeout and relay posture,
- and a rule that terminal replies refine local comfort but do not impersonate shell truth.

That keeps the architecture open while making live terminal introspection much safer and much more legible.
