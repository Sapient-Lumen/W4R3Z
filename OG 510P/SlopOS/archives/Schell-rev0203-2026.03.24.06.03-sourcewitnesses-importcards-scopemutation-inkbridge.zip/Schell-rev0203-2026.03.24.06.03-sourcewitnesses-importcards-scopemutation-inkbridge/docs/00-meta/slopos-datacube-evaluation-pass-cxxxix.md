# SlopOS datacube evaluation — pass CXXXIX

This pass asks a narrower companion-safe question than “should Schell support project trust, env activation, and repo-aware cold-open comfort?”
The better question is:
**what is the smallest repo-entry and startup-trust model Schell can add without violating SlopOS import-boundary discipline or letting folder-open convenience impersonate reviewed shell authority?**

## 1) SlopOS pressures Schell toward explicit repo-entry posture, not ambient project trust

SlopOS keeps pressing on a few companion laws:
- visible context is weaker than exact authority,
- imported local help should stay weaker than execution truth,
- changed basis should matter,
- and startup/session influence should not hide inside ambient folklore.

That pressure applies directly here.
If Schell opens a repo, the companion-safe version is not “repo open implies smart project shell.”
The safer version is closer to:
- inert workspace,
- clean shell,
- repo help pack,
- trusted activator,
- sandboxed activation lane,
- trusted live footing.

## 2) Repo help and activation should stay separately nameable

The archive already has repo accelerator packs.
This pass says the next boundary is adjacent but not identical:
repo-local help and repo-local activation should not share one trust bit.

A companion-safe split looks like:
- repo help may influence discovery and staging,
- activation may influence env/runtime/startup footing,
- hooks stay separately named if they ever exist,
- and sandboxed activation can be stronger than inspect-only while still weaker than ordinary trusted footing.

That keeps “the repo can help me” from collapsing into “the repo now shapes my shell.”

## 3) ViewFS pressures Schell toward inspect-before-activation objects

ViewFS has been especially consistent about keeping nearby object classes separate:
locators versus live handles, unpublished versus published, launch inheritance versus current live state.
That pressure is helpful here.
An inert workspace should be a rich inspectable object family even before it is activation-capable.
Schell should not require a repo to become trusted just to make it browseable, searchable, annotatable, or draftable.

## 4) Steward sharpens the trusted-chrome and startup-lifecycle edge

Steward keeps source-labeled status, trusted chrome, and non-ambient activation posture separate.
That points to a good Schell move:
if repo-local activation is active, the shell chrome should say so exactly.
If the repo is only being browsed inertly, the chrome should say that too.
The operator should not have to guess whether local startup influence is live.

## 5) Helm keeps quarantine and endorsement narrower than convenience

Helm again supplies the right veto.
A repo, downloaded project, or transferred workspace should not automatically clear itself by being opened.
That means Schell should keep narrow promotion steps such as:
- inspect repo help,
- trust help only,
- promote exact activator basis,
- compare changed basis,
- or sandbox activation first.

That keeps project-aware comfort luxurious without turning folder-open into ambient endorsement.

## 6) Companion-safe no-regret move

Schell does **not** need a giant workspace-trust constitution next.
It only needs a compact split between:

- **inert workspace**
- **clean shell**
- **trusted repo help**
- **trusted activator**
- **sandboxed activation lane**
- **trusted live footing**
- **changed-basis downgrade**

with these rules:
- browse and search are allowed before activation,
- clean shell is easy and prestigious,
- repo help and activation do not share one trust bit,
- changed activator basis revokes prior trust until reviewed,
- and stronger startup influence is always explicitly named in the footing strip.

## 7) Compact conclusion

The companion cubes keep teaching the same law in different accents:
**local project influence is useful without becoming ambient shell truth.**

So the Schell-safe answer is small:
**repo/workspace entry should be an explicit trust-promotion seam.**
That gives the future shell+terminal a real luxury upgrade — safe cold-open, clean-start shelling, and project-aware activation — without forcing early decisions about final workspace-trust architecture, hook systems, env-loader treaties, or sandbox runtimes.
