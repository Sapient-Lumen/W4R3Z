# Research synthesis, pass CXVI (2026-03-22)

This pass keeps one narrower lesson explicit:
**Schell should not only scope recall by peer/cwd/lane, it should also keep visible where remembered shell objects currently live: session-only, durable-local, synced-personal, team-shared, public-link, or exported.**

The outside ecosystem is surprisingly convergent on this once you line the products up.
iTerm2 makes history and recent directories shell-integration-aware and can also persist command, directory, and clipboard history to disk.
fish makes private mode and history-clearing scopes explicit.
Atuin exposes host/session/directory/workspace filters, lets users exclude commands or directories from tracking, and treats multi-machine history sync as an encrypted opt-in.
Warp keeps session history separate, then introduces stronger promotion boundaries such as team workspaces, synced objects, and explicit block sharing.
Together these point to a strong Schell move:
**memory should be scoped by footing and also badged by residence.**

## 1) iTerm2 proves that shell memory already has multiple residences

iTerm2 remains one of the clearest specimens.
Its shell integration keeps command history and recent directories separately for each username+hostname combination.
And its preferences make another important boundary visible: when save-to-disk is enabled, command history, directory history, remote usernames/hostnames, and paste history are persisted; disabling that setting erases the saved information.

That is a useful product truth.
A command-memory object does not merely have content.
It also has a residence story.

## 2) fish proves suppression and deletion are different operations

fish's current docs keep two crucial lessons explicit.
Private mode can hide old history and prevent new command history from being written to disk.
Separately, the `history` builtin distinguishes clearing all history from clearing only the current session's contribution.

That is exactly the discipline Schell needs.
“Do not write future history,” “hide prior history,” “clear this session,” and “erase durable history” are different operations.
The shell+terminal should not borrow one word for all of them.

## 3) Atuin proves rich history needs both context and residence controls

Atuin is valuable not just because it searches history well.
It also makes memory posture more explicit.
Its config supports filter modes like global, host, session, directory, workspace, and session-preload.
It supports `history_filter` and `cwd_filter` so commands or directories can be excluded from tracking.
And its sync docs make multi-machine history an explicit end-to-end encrypted backup/sync workflow.

This is an important Schell clue.
Good command memory is not just better ranking.
It is also better control over where memory is tracked and where it is allowed to travel.

## 4) Warp proves promotion boundaries can be product-grade

Warp now exposes several distinct memory/promotion layers.
Command Entry says session history is isolated per shell session.
Warp Drive introduces a personal workspace and team workspaces whose objects sync immediately.
Warp's docs also say that moving an object into a team workspace shares it with the team and that moving it back is not currently supported.
Offline personal edits can remain local-only until sync is available again.
Separately, block sharing is an explicitly opt-in server action, and shared blocks can be reachable by link.

That stack is instructive.
The clever move is not just “save more things.”
It is making promotion from local/session memory into synced, team-visible, and public surfaces explicit.

## 5) This suggests a compact Schell witness family

Schell should probably add one compact memory-residency witness or equivalent story that can say:
- what the object is,
- where it currently lives,
- whether it is unsynced, synced, team-shared, or published,
- whether promotion was explicit,
- and what revocation or cleanup claims are still possible.

That would let the shell+terminal support much richer:
- saved command frames,
- recent-directory decks,
- notebooks and workflows,
- replay capsules,
- personal cross-machine memory,
- team workspaces,
- and publication/export ladders.

## 6) The crucial honesty rule is residence drift

Earlier passes made authority drift visible.
This pass adds another equally useful idea:
**residence drift**.

A command frame that began as session-only may later become:
- durable local,
- restored local,
- synced personal,
- copied into team memory,
- link-published,
- or exported as an artifact.

Schell should say when that happened.
That alone would make the product feel much more adult.

## 7) Compact design-phase answer

Schell does **not** need to freeze one final history DB, sync backend, collaboration system, or publication engine.
It only needs a bounded move:
- keep session/local/synced/team/public residences distinct,
- make promotions explicit,
- badge revocability honestly,
- keep personal sync different from team share,
- and keep all remembered/shared/exported objects weaker than fresh local review.

That is enough to make shell memory dramatically better without choosing too much too early.
