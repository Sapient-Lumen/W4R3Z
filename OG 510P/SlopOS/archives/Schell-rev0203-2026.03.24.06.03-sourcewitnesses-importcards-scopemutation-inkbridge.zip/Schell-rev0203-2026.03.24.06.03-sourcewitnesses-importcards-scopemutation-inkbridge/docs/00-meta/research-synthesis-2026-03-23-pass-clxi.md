# Research synthesis — 2026-03-23 — pass CLXI

This pass tightens the next seam instead of widening “path handling” or “cwd display” into one giant cross-platform filesystem subsystem:
**location luxury is worth stealing, but the shell should stay excellent at saying what current working ground a relative action will actually bind against right now, because shells still disagree about logical versus physical directories, provider drives, and remembered location residue.**

The strongest current lesson is that modern shells already expose multiple cwd truths, but in fragmented, expert-only ways.
That points to a good next Schell move:
**cwd witnesses, logical/physical path posture, and provider humility** rather than one flattering prompt-path badge.

## 1) Bash shows that current directory is not just one string

Current Bash docs say `cd` defaults to logical behavior and processes `..` before resolving symbolic links, while `cd -P` resolves symbolic links during traversal and before processing `..`.
The same manual says `pwd -P` prints a path without symbolic links, while `pwd -L` may contain symbolic links.
Bash also makes `CDPATH` part of the story, which means the entered token may not even begin life as the final location label the prompt later shows.

That is a crucial shell+terminal lesson.
A cwd chip is not the same thing as exact object identity.
Schell should therefore keep entered path, display path, logical footing, physical footing, and later receipts separate.

## 2) PowerShell proves that location can be provider-shaped and drive-scoped

Current PowerShell docs say the current working location is the default location commands use when no explicit path is supplied, but each runspace has its own current directory and PowerShell also remembers a current location for each drive.
The provider docs say providers expose specialized data stores in a format that resembles a filesystem drive, including `Alias:`, `Env:`, `Function:`, `HKLM:`, and ordinary filesystem drives.

That gives Schell several strong lessons:
location is not always filesystem location, cwd state can be lane-local, and a displayed path-like label can hide a very different action surface underneath.
So provider kind and drive family deserve first-class reveal.

## 3) fish shows the value of explicitly separating logical string paths from physical resolution

Current fish docs say `path normalize` operates on paths as strings, does not make them absolute, and does not resolve symlinks; they say this behaves like `pwd -L` and `cd`.
The same docs say `path resolve` returns normalized, physical, absolute paths, resolves symlinks, and behaves like `pwd -P`.

That is excellent evidence for Schell.
The humane shell move is to keep display-friendly logical footing and stronger physical footing on separate rails instead of forcing one to erase the other.

## 4) Nushell shows that even newer shells had to rethink PWD truth

Nushell’s 0.94.0 notes say Nushell had been aggressively canonicalizing paths instead of using logical paths, which led to unintuitive behavior.
The same notes say `$env.PWD` and `pwd` now support logical paths, while `cd --physical` and `pwd --physical` are the explicit stronger forms.
They also note that some commands had incorrectly used the process cwd instead of `$env.PWD`, which had to be fixed.

That is a valuable Schell lesson.
The boundary between process cwd, shell cwd, logical cwd, and physical cwd is real, and luxury UX gets safer when those layers stay separately witnessed.

## 5) The concrete Schell move

Schell should add a compact **cwd witness** family:
- **entered_path** — the exact location token or route the operator used,
- **display_path** — the humane path label shown in prompt/chrome,
- **logical_pwd** — logical shell footing,
- **physical_pwd** — canonicalized filesystem footing when available,
- **ground_kind** — filesystem / provider / virtual / remote-translated / unknown,
- **provider_or_drive** — exact drive or route family,
- **source_lane** — typed `cd`, `CDPATH`, restored, project launch, import, replay, unknown,
- **divergence_posture** — same / diverged / provider-only / unresolved / translated,
- **basis_ref** — exact witness that established the location,
- **reveal_target** — exact card showing what relative actions will bind against.

That is enough to steal location clarity without freezing one universal path ontology, one remote translation treaty, or one final filesystem-object identity law.
