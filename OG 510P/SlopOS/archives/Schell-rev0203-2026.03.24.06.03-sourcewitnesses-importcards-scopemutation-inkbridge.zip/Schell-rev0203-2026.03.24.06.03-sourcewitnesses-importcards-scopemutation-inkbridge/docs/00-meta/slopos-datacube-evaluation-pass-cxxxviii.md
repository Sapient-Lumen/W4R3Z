# SlopOS datacube evaluation — pass CXXXVIII

This pass asks a narrower companion-safe question than “should Schell support provider channels, deferred tasks, and imported progress UI?”
The better question is:
**what is the smallest sidecar model Schell can add without violating SlopOS import-boundary discipline or letting provider-reported liveness impersonate shell-owned completion truth?**

## 1) SlopOS pressures Schell toward imported-liveness humility, not ambient task folklore

SlopOS keeps pressing on a few critical companion laws:
- imported completion should not quietly become shell truth,
- helper/proxy surfaces should stay weaker than exact execution footing,
- visible progress and explanation are not receipts,
- and foreign capabilities should arrive through named boundaries rather than ambient adoption.

That pressure applies directly here.
If Schell hosts provider tasks, progress, logs, or channels, the companion-safe version is not “task is task.”
The safer version is closer to a **provider-local sidecar** that says:
- provider owns the lifecycle,
- status is mirrored rather than shell-authored,
- result may be available,
- input may be needed,
- and stronger shell adoption requires a separately named step.

## 2) Provider mirror and shell-owned detached work should stay separately nameable

SlopOS already refuses the flattening of request, live state, result, and explanation.
That suggests a healthy ladder for Schell:
- provider sidecar,
- task mirror,
- input-needed checkpoint,
- result locker,
- shell-adopted detached work,
- shell receipt.

This keeps “later thing happening nearby” from smuggling more authority than the operator intended.

## 3) ViewFS gives the right adjacent object posture

ViewFS is again unusually useful.
It wants badges, lockers, publication ladders, and explicit object class boundaries.
That maps cleanly onto provider-adjacent shell surfaces:
- a live sidecar can exist without being the task,
- a task mirror can exist without being shell-owned work,
- a result locker can exist without being a shell receipt,
- and a later promoted derivative can become a stronger shell object only after explicit review.

## 4) Steward sharpens the channel/status boundary where Schell needs it

Steward already likes explicit status channels and visible source posture.
That pressure is helpful here.
A provider-origin progress strip or channel message should stay source-labeled and freshness-badged.
If the shell later adopts work derived from that sidecar, the transition should be explicit rather than ambient.

## 5) Helm keeps endorsement and policy narrower than convenience

Helm again supplies the right veto.
A mirrored provider task should not quietly become:
- a trusted shell workflow,
- a policy-bearing quiet approval surface,
- or a durable proof that the provider's “done” means shell-reviewed completion.

That means Schell should keep explicit promotion paths from:
- provider sidecar,
- to inspected result locker,
- to shell-adopted derivative,
- to shell receipt or later endorsed reusable object.

## 6) Companion-safe no-regret move

Schell does **not** need one giant agent-terminal/task-host architecture next.
It only needs a compact split between:

- **provider sidecar**
- **task mirror**
- **input-needed checkpoint**
- **result locker**
- **shell-adopted detached work**
- **shell receipt**

with these rules:
- imported status is explicitly source-labeled,
- mirrored progress stays weaker than shell-owned progress,
- provider-done stays weaker than shell receipt,
- restored sidecars stay historical until fresh provider contact,
- and stronger shell-owned action requires explicit later adoption.

## 7) Compact conclusion

The companion cubes keep teaching the same law in different accents:
**foreign liveness is useful without becoming shell truth.**

So the Schell-safe answer is small:
**provider sidecars and task mirrors should be separately named objects** rather than one flattering “task is task” story.
That gives the future shell+terminal a real luxury upgrade without forcing early decisions about MCP host topology, background schedulers, channel constitutions, or provider-log persistence policy.
