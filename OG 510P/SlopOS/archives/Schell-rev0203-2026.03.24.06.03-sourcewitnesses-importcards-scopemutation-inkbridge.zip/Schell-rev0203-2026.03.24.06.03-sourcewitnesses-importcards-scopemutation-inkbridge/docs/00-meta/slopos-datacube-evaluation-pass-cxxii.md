# SlopOS datacube evaluation, pass CXXII (2026-03-22)

This pass evaluates one narrower question against the current companion archives:
**what do SlopOS, Steward, and ViewFS teach Schell about querying a live terminal and interpreting its replies?**

The answer is simple:
**terminal replies should behave like imported evidence with freshness and relay posture, not like self-authenticating shell authority.**

## 1) SlopOS keeps rewarding exact imported evidence and explicit local acceptance

Across the companion archive, SlopOS repeatedly prefers exact evidence, explicit local acceptance, and adapters that confess themselves.
That maps very neatly here.
A terminal reply about colors, modes, semantic blocks, theme posture, or feature support is useful evidence.
But it is still imported evidence arriving over a negotiated lane.
It should not silently become shell truth or approval-bearing footing.

This gives Schell a strong rule:
- query replies may explain,
- query replies may improve local comfort,
- query replies may tune local rendering,
- but stronger action rights remain shell-owned and basis-aware.

## 2) Steward keeps freshness and source posture visible

Steward's repeated lesson is that trusted chrome should confess source and freshness.
That maps directly to terminal introspection.
A direct live reply and a cached historical reply are not the same thing.
A direct path and a relayed path are not the same thing.
Schell should therefore keep freshness and relay posture in the reply capsule rather than behind it.

## 3) ViewFS keeps lanes distinct

ViewFS repeatedly pressures the archive not to flatten observe, attach, control, sideband, and historical lanes into one vague connected-state story.
That is useful here too.
A terminal query/reply exchange deserves its own lane posture rather than collapsing into generic stdin folklore.
This is especially important when helpers warn against overlapping TTY I/O or when relays selectively pass escape traffic.

## 4) Companion-safe no-regret move

Schell does **not** need to decide the final sideband or mux architecture for terminal introspection.
It only needs a few bounded rules:

### A) Keep terminal questions explicit
Named issuer, named question family, named expected reply family, named timeout.

### B) Keep replies capsule-shaped
Digest, parsed view, freshness, relay posture, contradiction/timeout state.

### C) Keep replies weaker than shell-owned truth
Useful for explanation and local comfort; not enough for stronger shell claims by themselves.

### D) Keep relay posture visible
A reply that survived tmux passthrough or another bridge should say so.

### E) Keep contradictory and missing replies first-class
Unsupported, timed out, stripped, contradictory, and historical are all different footing classes.

## 5) Compact conclusion

The SlopOS-compatible answer is not “the terminal told us, therefore it is true.”
It is:
**treat terminal replies as explicit imported evidence with issuer, challenge, freshness, relay, and safe-unlock posture.**

That is a very safe companion move because it increases rigor, improves debugging, and keeps the shell+terminal architecture open.
