# Research synthesis — 2026-03-23 — pass CLXXIV

This pass sharpens one fresh lesson from current terminal and platform docs:
**modern systems increasingly expose requested placement classes, but the operator still lacks one tiny durable explanation of where the result actually landed.**

## 1) Current terminals already distinguish spawn classes instead of flattening them into one clone story

Ghostty 1.3.0 now has separate working-directory inheritance controls for windows, tabs, and splits.
That is more than a configuration detail.
It shows that spawn classes are first-class enough to deserve separate policy.

## 2) WezTerm keeps requested landing explicit

WezTerm shell integration says OSC 7/133/1337 support improved experiences such as spawning new panes, tabs, and windows with the same current working directory as the current pane.
Its CLI also makes landing choices explicit: spawn into a new window, spawn into the current window, or target a named/current domain.

That is a strong clue for Schell.
Requested placement should stay explicit, not inferred from a cozy “nearby” myth.

## 3) Windows Terminal says duplicate and new are different promises

Windows Terminal documents that `duplicateTab` copies the current tab's profile and directory but does not include modified or added environment variables.
It separately documents split-pane duplication of the focused pane.

So even in a polished product, “duplicate nearby” is not one giant exact clone claim.
It is already a bounded request with visible omissions.

## 4) VS Code exposes multiple landing surfaces and session movement

VS Code documents terminals in split groups, in the editor area, and in new windows.
It also documents dragging terminal tabs between windows plus explicit `Detach Session` and `Attach to Session` commands.
Persistent sessions further split reconnection from revive.

That means the ecosystem is already teaching users that a terminal session's subject identity and its current landing/container are different truths.

## 5) The web platform keeps requested target and realized browsing context separate too

The HTML Standard says `window.open(url, target, features)` provides a mechanism for navigating an existing browsing context or opening and navigating an auxiliary browsing context.
That is exactly the requested-versus-realized pattern.
The request names a landing intention, but the useful truth is still where the result actually landed.

## 6) The no-regret Schell move is a tiny placement receipt

Putting these together suggests a better next move than a giant layout manager treaty.
Schell should add a tiny **placement receipt** for newly landed or relocated rooms, lanes, helper surfaces, and restored session views.
It should say:
- what landing was requested,
- what landing was realized,
- whether redirect/downgrade/attach/revive happened,
- which arrival or activation witnesses are linked,
- and what the strongest honest next move is now.

## 7) Compact conclusion

Ghostty keeps spawn classes distinct.
WezTerm makes landing knobs explicit and shell integration makes same-cwd spawn possible.
Windows Terminal distinguishes duplicate from new and documents omissions.
VS Code exposes multiple landing surfaces plus detach/attach and revive.
The HTML Standard keeps target/reuse versus actual browsing-context landing separate.

So the next no-regret Schell seam is not a giant pane-graph constitution.
It is **placement receipts and requested-versus-realized landing honesty** so split, tab, editor-area, new-window, attach, revive, and restore flows can feel luxurious without pretending the first requested landing is the same thing as current truth.
