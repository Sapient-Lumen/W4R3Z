# SlopOS datacube evaluation — pass CLIV

This pass asks a narrower companion-safe question than “how should Schell handle paste?”
The better question is:
**how should Schell model pasted ingress that looks submit-shaped — especially ingress ending in a newline — so it stays weaker than a freshly meant spend?**

## 1) SlopOS keeps transfer and volition explicit

Even while still in design phase, SlopOS keeps returning to a crisp pattern:
transfer is mediated, fresh local identity is explicit, quarantine is explicit, and stronger cross-boundary delivery can require fresh volition and a receipt.

That maps almost directly to shell paste.
Clipboard or selected-text ingress may be useful immediately.
But useful ingress is still not the same thing as a freshly meant command spend.
If Schell wants to stay companion-safe, pasted command text should arrive as a packet or witness first and only later cross into a stronger submit posture.

## 2) SlopOS transfer posture argues against ambient paste authority

SlopOS’s transfer and document-portal work keeps saying the same thing in different forms:
- no ambient observation,
- no silent durable grant,
- no hidden import-to-authority shortcut,
- and no “convenience helper” being mistaken for the portable reviewed plane.

That is exactly the right pressure here.
A terminal paste shortcut, selected-text send action, or helper-originated insert should not get to bypass Schell’s review or arming semantics simply because it feels local and convenient.

## 3) ViewFS keeps the candidate weaker than the later apply

ViewFS repeatedly separates visible candidate, exact basis, apply act, and later receipt.
That strongly pressures Schell to treat pasted text the same way.
A visible candidate that happens to end in a newline is still weaker than a later exact spend receipt.

This is especially important for selected-text send, history replay, and assistant insertion.
Those surfaces should feel excellent.
They still should not quietly inherit the same meaning as fresh typed spend.

## 4) Steward reinforces admission-versus-completion discipline

Steward keeps UI-facing acknowledgement, retry posture, countdowns, and durable receipts separately named.
That suggests a direct shell lesson:
Schell should not let “paste landed” flatten into “the command was freshly spent.”

A good shell can keep these states separate:
- ingress arrived,
- ingress inserted,
- candidate armed,
- spend admitted,
- and later outcome received.

That separation is exactly what keeps friendly UX from becoming folklore.

## 5) Helm pressures reclaim-sensitive downgrade

Helm’s change cursors, reset cards, and activity-scope honesty all push toward basis-sensitive action posture.
That means newline-bearing paste should not keep the same strength after footing drift.
If prompt reclaim is pending, target identity drifted, or a reset card is already active, Schell should downgrade pasted ingress automatically.

That is a strong no-regret move:
prompt-looking place plus trailing newline still should not be enough.

## 6) What Schell should steal now

Schell should steal several excellent ideas, but import them under stronger honesty:
- bracketed-paste-aware insertion,
- prompt-aware paste warnings,
- explicit selected-text-send posture,
- quote/normalize/inspect transforms,
- and visible distinction between insert-only, arm-now, and spend-now.

## 7) What Schell should refuse now

Schell should refuse:
- treating pasted newline as automatically fresh intent,
- treating selected-text send as indistinguishable from typing,
- letting helper-originated ingress spend because it happened to land at the prompt,
- and hiding control-character or target-posture downgrades behind silent terminal folklore.

## 8) Compact conclusion

The companion-safe answer is not to make paste cumbersome.
It is to make **paste spend weaker than paste arrival**.
If Schell can show what arrived, how it was delivered, whether a trailing newline crossed a gate, and what later receipt proves an actual spend, it can steal a lot of modern paste comfort while staying aligned with SlopOS exactness during the design phase.
