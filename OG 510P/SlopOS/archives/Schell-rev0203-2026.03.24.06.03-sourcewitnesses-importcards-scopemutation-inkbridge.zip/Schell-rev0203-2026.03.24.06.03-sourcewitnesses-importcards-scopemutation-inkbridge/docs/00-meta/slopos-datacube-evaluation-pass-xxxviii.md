# SlopOS datacube evaluation, pass XXXVIII

This pass keeps one bounded thesis in focus:
**SlopOS keeps insisting that network authority, routing, and launch remain explicit and request-local. Schell should import that directly for terminal service cards, forwarded ports, and browser handoff so a dev-server URL does not quietly become a tunnel, an exposure policy change, or browser/session authority.**

This is another very good import point because SlopOS is still design-phase too.
The lesson is strong without forcing Schell to freeze a tunnel backend, browser-preview stack, or service inventory architecture.

## 1) D-NETLEASE gives Schell the right split immediately

The outbound-network lease RFC says there is no ambient network after init, that dial/listen/resolve authority should be explicit, and that `NetDialer`, `NetListener`, and `DnsResolver` remain separate authority objects with lease bounds.
The capshell network posture says there are no ambient socket constructors and no ambient DNS baseline at `capshell.exec`.

That maps beautifully onto terminal service UX.
A terminal should not quietly infer that because a process emitted `localhost:3000`, it therefore owns a stable browser/open/share/exposure workflow.
The strong import is:
**listening is one fact; forwarding, sharing, and public exposure are stronger facts.**

## 2) D-PLUMB keeps the browser/tunnel temptation under control

The workflow plumbing posture says routing stays explicit invocation only, request-local, provider-owned, and without generic callback registries, durable inboxes, or app-visible handler inventories.
The OpenURI posture inside that stack is still launch-only and manual-only.

That is exactly the discipline Schell needs.
A service card can absolutely help the operator.
But it should not turn a visible service witness into:
- hidden handler probing,
- silent callback registration,
- browser-session/profile control,
- or a durable reopen/session-rejoin contract.

## 3) SlopOS keeps saying “provider-local convenience is weaker than the portable seam”

This comes through all over the datacube:
owner-local helpers may exist, but they do not define the reviewed portable meaning.
That is the right answer for terminal-local service magic too.

Even if one environment can auto-forward ports, open the client browser, label services, and offer preview tabs, Schell should keep the reviewed truth in its own service witnesses rather than in platform folklore.
The custom shell+terminal can then stay super awesome locally without smuggling platform-specific tunnel semantics into the portable center of the archive.

## 4) Exposure posture deserves its own explicit rung

D-NETLEASE already treats destination scope and bounds as first-class.
That strongly suggests Schell should not flatten:
- loopback-only service,
- forwarded-to-local service,
- externally reachable but authenticated service,
- and public share URL.

Those are different authority stories.
SlopOS's general lesson is that adjacent workflows should stay separately named unless the archive has deliberately reviewed their collapse.

## 5) Historical service memory should stay weaker than current service truth

SlopOS repeatedly refuses to let request identity or historical artifacts stand in for current live provider state.
That is a brilliant import for dev-server ergonomics.
A remembered service card, share link, or previously forwarded port can still be useful, but it should remain visibly historical until Schell re-acquires current reachability or freshness evidence.

## 6) The strongest import is small and practical

Schell does not need a giant service manager to learn from SlopOS here.
It needs:
- one **service witness** family,
- one explicit split between **listening**, **forwarded**, **opened locally**, **previewed locally**, **shared privately**, and **shared publicly**,
- one **origin posture** family that keeps detector help weaker than shell-known service truth,
- one **exposure posture** family that keeps loopback/private/public stories apart,
- and one refusal to let browser handoff or tunnel convenience widen silently into generic browser/session/exposure authority.

That is enough to make terminal-hosted service UX much better while keeping architecture choices open.

## 7) This is another path to “super awesome” without choosing too much too early

A shell+terminal becomes super awesome when a running service is easy to inspect, copy, open locally, and route deliberately.
It becomes misleading when every visible localhost URL quietly claims the same local reachability, browser readiness, and public exposure semantics.

SlopOS is already teaching the better pattern:
- authority stays explicit,
- routing stays request-local,
- launch stays weaker than downstream completion or visibility change,
- provider-local convenience stays weaker than reviewed portable meaning,
- and historical handles do not stand in for current live service truth.

That is the Schell import worth ratcheting now.
