# SlopOS datacube evaluation, pass CXI (2026-03-22)

This pass evaluates one narrower question against the current SlopOS archive:
**what does the companion already teach Schell about labels, display names, authority-bearing identifiers, current live-state honesty, and the danger of letting visible names borrow more truth than they deserve?**

The answer is sharp:
**the companion wants display labels to remain descriptive, exact identity to stay on smaller dedicated seams, and current live state to remain weaker than a flattering name that happens to still be visible.**

## 1) D-NAMECERT already rejects flattering-label authority

SlopOS's local naming posture keeps authority-bearing labels on a bounded exact-byte lowercase ASCII profile and treats them as single opaque atoms after validation.
That is the opposite of ambient display-name folklore.
It means Schell already has good companion pressure not to let a pretty tab title, human-friendly host label, or profile/session name masquerade as exact identity.

The lesson for Schell is straightforward:
- exact peer identity stays on exact peer witnesses,
- exact local names stay on exact naming surfaces,
- display labels may summarize those things,
- but display labels do not become them.

## 2) The companion repeatedly separates accepted record from current live state

The current archive keeps repeating another load-bearing lesson:
accepted request state, recorded receipt state, and provider-owned live state are different things.
That shows up in ACP outcome posture, attention posture, and other review/workflow seams.

That is directly relevant to titles.
A tab that still says `deploying`, `prod`, or `running` is not current live-state proof.
It is a label that may or may not still be bound to current truth.
The companion therefore pressures Schell to treat title freshness and title binding posture explicitly rather than assuming that persistence implies currentness.

## 3) Capshell and conflict-key posture also reject display-name identity

The companion already says provider-local display names are diagnostic conveniences rather than portable identity, and it explicitly refuses to derive ordering/identity keys from port paths, serial strings, or display labels.
That is powerful outside proof for Schell.
A window title like `db-prod` or `logs` is the same kind of nearby convenience.
Useful, yes.
Identity, no.

## 4) The companion-compatible answer is smaller than a final naming subsystem

Schell does **not** need to choose:
- one final title escape-sequence treaty,
- one final badge scripting model,
- one final shell-integration naming contract,
- one final restored-title policy,
- or one final tab/window label architecture

to stay aligned with SlopOS.

It only needs a few bounded rules:

### A) Titles, tab names, split/session labels, and badges stay explicitly descriptive
Do not let them masquerade as exact identity or current live-state proof.

### B) Source and override posture stay visible
Shell-driven, operator-fixed, profile-derived, script-provided, restored, and historical labels should not share one flattering label story.

### C) Freshness and binding stay explicit
A visible name may still exist after the peer, cwd, or foreground job changed; the UI should be able to confess that.

### D) Exact identity and exact live state stay elsewhere
Labels may summarize those witnesses, but do not replace them.

### E) Transcript truth survives the fancy UI
A log should still be able to say what label was shown, what sourced it, and whether it was bound to live shell-known state or merely historical/local.

## 5) Compact conclusion

The SlopOS-compatible answer is not “build a giant portable title protocol.”
It is:
**make titles, badges, and session labels explicit title witnesses with visible source, override, and freshness posture while keeping exact identity and current live state on smaller dedicated seams.**

That is a strong design-phase-safe move because it improves a very common terminal failure surface immediately while leaving the final title/badge protocol, scriptability model, and restore policy open.
