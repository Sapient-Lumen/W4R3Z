# Research synthesis, pass LII (2026-03-21)

This pass keeps one fresh design rule in focus:
**Schell may absolutely make active input look prettier than raw shell folklore, but every pretty/token-aware affordance must keep exact argv or exact text reveal one gesture away and must never let helper layers choose quoting, splitting, or byte/string interpretation in secret.**

The outside landscape keeps reinforcing the same lesson.
People want terminals and shells that feel like real editors.
But the moment input prettification hides exact launch shape, quoting law, or byte-vs-string truth, the shell starts lying.
The best ideas are therefore not “replace the command line with magic.”
The best ideas are **pretty input plus exact reveal plus explicit escape valves**.

## 1) Warp keeps proving that the best workflow UX still ends in editable input before run

Warp's workflow docs remain useful for the same reason as the previous pass, but this time the relevant detail is slightly different.
A selected workflow lands in the active input editor, supports `SHIFT-TAB` argument cycling, syncs repeated arguments with multiple cursors, and still expects the operator to adjust the command before running it.
That is the right baseline for Schell too.
Pretty input is strongest when it is still visibly editable input rather than a hidden execution object.
See: https://docs.warp.dev/knowledge-and-collaboration/warp-drive/workflows

## 2) fish shows that better insertion can improve readability without pretending escapes disappeared

fish's latest docs and release notes are especially valuable here.
Autosuggestions remain accept-or-ignore, single-word acceptance exists, and full-token completions now prefer quoting over backslash soup when escaping special characters.
That is a terrific Schell clue.
The steal is not “fish syntax.”
The steal is the idea that **the shell can choose a more humane insertion form while still being explicit about where escaping happened**.
See: https://fishshell.com/docs/current/tutorial.html ; https://fishshell.com/docs/current/relnotes.html ; https://fishshell.com/docs/current/cmds/complete.html

## 3) PowerShell is a reminder that dual parsing and stringification scars never really go away

PowerShell's current docs are still one of the clearest reminders that shell/native interop gets painful fast.
Its parsing docs explain that native-command arguments are first parsed by PowerShell, and it still needs explicit escape hatches like the stop-parsing token.
Its quoting docs also make clear that native commands may expect quote characters that PowerShell interprets before passing arguments onward.
And its pipeline docs note that before PowerShell 7.4, piping or redirecting raw byte output from native programs converted that data to .NET strings, which could corrupt raw output; 7.4+ changed that behavior.
That is exactly the kind of historical scar Schell must learn from.
Do not let a prettier shell surface quietly become a second parser or silently stringify bytes.
See: https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_parsing?view=powershell-7.5 ; https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_quoting_rules?view=powershell-7.6 ; https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_pipelines?view=powershell-7.5 ; https://learn.microsoft.com/en-us/powershell/scripting/learn/shell/running-commands?view=powershell-7.5

## 4) Nushell suggests a bounded way to make external commands feel more structured without overcommitting the whole shell

Nushell remains a useful bounded precedent.
Its extern signatures can provide parse-time type checking, completions, and syntax highlighting for external commands.
Its recent docs and release notes also show list spreading into `run-external` and `exec`, which is a clean way to assemble arguments without pretending one human-facing string is the only truth.
That is a strong Schell hint.
**Expose more argument structure at the active-input seam, but do not require one total structured-data religion for every pipeline and transcript.**
See: https://www.nushell.sh/book/externs.html ; https://www.nushell.sh/book/operators.html ; https://www.nushell.sh/blog/2025-02-04-nushell_0_102_0.html

## 5) Ghostty and kitty still reinforce the right terminal-side discipline

Ghostty's prompt-click work keeps showing that richer pointer behavior is safest when confined to shell-marked active prompts.
kitty's keyboard protocol remains one of the clearest examples of progressive enhancement for richer input events.
Those are perfect Schell imports for pretty-token or exact-reveal affordances.
If a nicer argument-local editing experience wants richer pointer or key signals, it should stay capability-witnessed and degradable.
See: https://ghostty.org/docs/install/release-notes/1-3-0 ; https://sw.kovidgoyal.net/kitty/keyboard-protocol/

## 6) The stealable move: a dual-view active input with exact-reveal humility

The best new steal now looks like this:
1. a command or workflow seed lands in active input,
2. the operator may see a prettier token/slot-oriented view,
3. each token can reveal its exact argv/value/text form,
4. escape/quote decisions become visible and reversible,
5. authority-bearing tokens get stronger basis cues,
6. and run remains a separate explicit action.

That gives Schell a real luxury surface.
The shell can feel like a modern structured editor without pretending the pretty view is the only truth.

## 7) Lessons from the past we should not forget

Past shells repeatedly taught the same painful lessons:
- command strings are not durable intent objects,
- two parsing layers eventually disagree,
- pretty output formats often corrupt bytes when they silently become transport,
- and escape hatches appear whenever the user cannot see what exact argv or exact bytes the shell will really pass along.

The better lesson is narrower and more useful:
**make exact launch shape inspectable at the same moment you make input more humane.**

## 8) A compact Schell v0 cluster is enough

A decision-light first cut probably needs only:
- one **argv witness** family for active input,
- one **pretty view / exact reveal** toggle or ladder,
- one visible **escape/quote provenance** cue,
- one stronger cue for authority-bearing or executable-bearing tokens,
- one explicit **copy exact argv / copy shell text** split,
- and one refusal to prettify history/output into new hidden execution truth.

That is enough to make Schell noticeably better without freezing one final shell grammar, one total token-chip UI, or one universal external-command object model.

## 9) Decisions intentionally kept open

This pass does **not** freeze:
- one final shell-language syntax,
- one final pretty-token rendering style,
- one final quoting strategy for all contexts,
- one final external-command metadata schema,
- one final binary/string pipeline story beyond existing decision-light posture,
- or one final richer keyboard/pointer editing protocol.

The no-regret move is narrower:
**make input prettier only when exact argv/text reveal, escape humility, and explicit run boundaries stay stronger than the prettification.**
