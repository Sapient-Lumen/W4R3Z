# Research synthesis — 2026-03-23 — pass CL

This pass sharpens the next narrower lesson from current shell+terminal tools:
**mixed timelines are much more useful than one flat history list, but they stay safer when the timeline remains a typed evidentiary surface and the live shell “now” stays a distinct stronger object.**

That points to a good next Schell move:
**timeline witnesses and a dedicated now beacon** rather than one generic recent/activity feed.

## 1) VS Code proves a unified filtered timeline is stronger than one monolithic history

VS Code’s user-interface docs describe Timeline as a unified view for visualizing a file’s event history, with filters that switch between source control events and local file events. Timeline entries support different actions depending on source, such as compare, restore, delete, or rename for local history.

That is a strong Schell clue.
A unified surface becomes much more useful once it can mix multiple event sources while preserving row kind and source-specific verbs.
Schell should steal that shape for shell/terminal history — but keep current live footing separate from the mixed timeline itself.

See:
- https://code.visualstudio.com/docs/getstarted/userinterface

## 2) VS Code shell integration proves shell-known rows are valuable, but still not current truth by themselves

VS Code’s shell-integration docs say shell integration helps the terminal understand what is happening inside the shell and enables command detection, decorations, and navigation. The same page lists run-recent-command and go-to-recent-directory affordances.

That is another Schell clue.
Shell-known rows are excellent building blocks for a timeline.
But “this command row was detected” is still not the same thing as “this is the live shell now.”
A typed timeline needs one visibly stronger now-beacon nearby.

See:
- https://code.visualstudio.com/docs/terminal/shell-integration

## 3) Warp proves session-local rich rows are more helpful than plain command strings

Warp’s current command-history docs say history is isolated per shell session while panes are running and then combined on close. The same docs say rows carry rich metadata such as exit code, directory, thread, time to finish, and last run.

That is exactly the kind of row design Schell should steal.
A timeline gets smarter when rows keep scope and metadata attached.
The key discipline is to avoid treating row richness as row authority.
Rich rows are still historical evidence unless the shell freshly says otherwise.

See:
- https://docs.warp.dev/terminal/entry/command-history

## 4) iTerm2 proves cross-linked history surfaces are powerful when verbs stay explicit

iTerm2’s docs show command history and recent directories stored per username+hostname, with row actions like reveal, insert, and `cd`. The same docs say Captured Output is linked to Command History, so selecting a command changes which captured output is shown. Semantic History tracks the working directory for each line to make file opening smarter.

That is one of the best ideas currently available.
A timeline should not just show rows.
It should let rows point into related evidence surfaces:
- command row → captured output,
- line row → cwd-aware file cue,
- directory row → insert-or-cd ladder.

Again, the important pattern is explicit verbs and typed linkage rather than one magic smart click.

See:
- https://iterm2.com/documentation-one-page.html
- https://iterm2.com/documentation-escape-codes.html

## 5) Atuin proves scope toggles are as important as search

Atuin’s docs say it records the command, directory, time and duration, exit code, hostname+user, and shell session. Its TUI can execute immediately or insert into the shell for editing. Its config docs add filter modes such as global, host, session, directory, workspace, and session-preload.

That is an excellent Schell lesson.
A first-class timeline needs scope chips, not just text search.
History becomes dramatically more humane when the operator can say “show me rows from this host / this session / this workspace” instead of searching one giant undifferentiated log.

See:
- https://docs.atuin.sh/cli/guide/basic-usage/
- https://docs.atuin.sh/cli/configuration/config/

## 6) Zellij is a reminder that continuity artifacts should stay inspectable

Zellij’s session-resurrection docs say session data is serialized into human-readable layout files every second, can be examined and altered, and can later be loaded like any other layout.

That is a useful side lesson for Schell.
Saved continuity artifacts should be inspectable and reusable, but they still remain saved artifacts rather than current live shell truth.
That makes them good timeline rows, not automatic now-beacons.

See:
- https://zellij.dev/documentation/session-resurrection.html

## 7) Compact conclusion

Current tools keep converging on a useful answer.
The next no-regret shell+terminal import is not another generic history pane.
It is a **typed timeline layer** that can mix command chapters, prompt marks, captured output, directories, repairs, receipts, and watcher events while preserving:
- row kind,
- source/scope,
- row-specific verbs,
- cross-links to related evidence,
- and one explicit stronger **now beacon** for current live footing.

That bundle would let Schell steal the best ideas in unified timelines, rich history rows, source filters, and linked evidence surfaces without letting “the latest row” impersonate the live shell.
