# SlopOS datacube evaluation, pass XLIII

This pass keeps one bounded thesis in focus:
**SlopOS already treats deferred work, continuous background presence, and current scheduler truth as different seams. Schell should import that discipline so “run later” becomes luxurious without quietly collapsing into cron folklore, replay debt, or daemon persistence.**

That is an especially good ratchet while SlopOS is still design-phase too.
It turns strong existing boundary work into humane shell+terminal leverage without freezing a scheduler or service-manager architecture.

## 1) D-JOBS already says the most important thing Schell needs to hear

The v0 D-JOBS posture is unusually sharp.
It rejects ambient cron, alarm registration, and exact-at constructors.
It says deferred work should arrive through `portal.jobs`, use **best-effort windows rather than exact schedules**, and keep missed periodic windows from accumulating into replay debt.

That is a superb design import for Schell.
The shell+terminal should stop implying that “run this later” naturally means exact wakeup, exact cadence, or replay-everything-after-sleep semantics.

## 2) CH-JOBREQ keeps request identity separate from current scheduler state

The CH-JOBREQ surfaces are also directly relevant.
`job_id` is a requester-chosen stable request key for dedupe/review.
It is not a live queue handle and not proof that a current scheduled job still exists.

That maps perfectly onto shell+terminal truth.
A reviewed future-run card, a receipt, or a transcript marker may be strong evidence of what the operator asked for.
It is still weaker than fresh scheduler-owned truth about whether the job is pending, replaced, cancelled, or already spent.

## 3) D-BGLEASE is a strong warning against “scheduled forever” folklore

D-BGLEASE keeps background presence and autostart as separately reviewed authority.
That means SlopOS is already refusing a common ecosystem cheat where repeated jobs or startup hooks become a stealth daemon surface.

Schell should import that distinction directly.
A scheduled rerun, periodic maintenance intent, and durable “keep running / relaunch later” grant should not share one badge or one mental model.

## 4) D-CAPSHELL already refuses to smuggle deferred/background semantics through ordinary shell launch

The capshell job-control posture explicitly says there is no portable `fg` / `bg` / `jobs` plane and that background or deferred work stays on D-JOBS and D-BGLEASE.
That is extremely useful pressure for Schell.

It suggests a clean split:
- immediate local continuation can stay in shell-local job/tty surfaces,
- deferred work should go through a run-later / job-request lane,
- and durable background presence should stay stronger than either.

## 5) The shell+terminal import can stay very small

The strongest import is not “build the scheduler now.”
It is:
- make deferred work a **named reviewed action**,
- keep best-effort windows explicit,
- show catch-up policy explicitly,
- use stable request keys for replace/dedupe posture,
- and keep request/receipt truth weaker than fresh current scheduler state.

That already makes Schell much better than ad-hoc shell folklore.

## 6) The no-regret move

Schell should add:
- one small **scheduled-work witness** family,
- one **review now / run later** card shape,
- one visible split between **deferred work** and **durable background presence**,
- and one refusal to let missed windows silently become replay debt unless a stronger, separately named policy says so.

That is a clean SlopOS import.
It keeps the archive careful, powerful, and still decision-light.
