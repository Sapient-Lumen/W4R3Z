# SlopOS datacube evaluation, pass XXVIII

**Completion and preflight should become dramatically more helpful without letting suggestion machinery, preview helpers, or parameter prompting quietly become a second execution path. SlopOS keeps teaching the same lesson: a shell can be generous with discovery while still being strict about authority.**

This pass focuses on another tempting seam for Schell:
- argument and option completion,
- parameter-focused help,
- path/object suggestions,
- missing-parameter prompting,
- and “preflight” summaries before a strong run.

That seam is dangerous because legacy shells tend to treat completion as harmless UI sugar.
In practice completion stacks often execute shell code, reopen mutable names, probe the filesystem or network, and quietly import policy from whichever helper happened to answer.
SlopOS keeps showing that discovery can be rich while still remaining weaker than current authority.

## 1) SlopOS capshell posture says completion must not become a second hidden exec path

The capshell work keeps binding the executable object, startup closure, interpreter, `argv[0]`, and environment explicitly.
It repeatedly refuses late reopen by name, shebang fallback, ambient loader search, and hidden startup hooks.
That pressure matters for completion too.

If a completion engine can run arbitrary shell code, reopen helper names, or inherit an ambient shell environment that reviewed execution would later reject, then completion becomes a secret second launcher.
That is exactly what Schell should refuse.

The import is:
**completion should be discovery-grade and insert-grade, not a hidden alternate exec path.**

## 2) SlopOS learn mode keeps suggestions observational only

The capshell learn-mode posture is explicit: learn mode remains observational only, denied effects remain denied, and there is no auto-edit / auto-approve / auto-rerun lane.
That is a beautiful constraint for completion and preflight.

Schell can absolutely show:
- likely flags,
- required-but-missing parameters,
- source-labeled candidate values,
- or a likely next repair.

But the operator still needs to decide whether that proposal lands in input, becomes a stronger preflight card, or runs.
The import is:
**completion and preflight should stay proposal-rich and execution-poor.**

## 3) SlopOS authority diffs and consent receipts point to deterministic preflight cards

The authority-diff and receipt work in SlopOS keeps descriptive summaries deterministic and non-authoritative.
That is exactly the right shape for a preflight card.

A Schell preflight card should be a compact explanation surface such as:
- likely target object(s),
- likely peer / cwd / ground assumptions,
- likely authority wallet drift,
- obvious missing parameters,
- or a bounded effect summary.

But that card should remain descriptive.
It is not approval, not a launch token, and not proof that execution will succeed.
The import is:
**preflight explanation should bind to current input and current basis, while staying weaker than approval.**

## 4) SlopOS typed plumb intents suggest parameter help should be typed, not patchy string magic

The plumb-message work keeps cross-app requests in a typed, canonical, non-authoritative envelope.
Routing is supposed to match typed intent fields rather than ad hoc strings.
That pressure is useful inside Schell too.

A great completion row should not just be text.
It may also carry a kind:
- subcommand,
- flag,
- enum value,
- path-like ref,
- object ref,
- portal-backed selection,
- or service/peer target.

And parameter prompting should fill typed slots rather than doing fuzzy text surgery after the fact.
The import is:
**typed argument cards are more honest than clever post-hoc string rewriting.**

## 5) SlopOS attribute-query posture keeps discovery scoped and metadata-safe

The attribute-query / smart-folder work in SlopOS is view-scoped, snapshot-first, handle-returning, and bounded.
The quarantined result-preview boundaries also insist that discovery stays metadata-safe by default.
That matters a lot for completion.

The easiest way for completion to go bad is to become a global omniscient search plane.
The safer import is:
- completion search should be scoped to the active view / peer / lane when possible,
- path and object suggestions should carry scope truth,
- and richer preview should be explicit rather than hover folklore.

The import is:
**completion should prefer view-scoped, metadata-safe lookup over ambient global probing.**

## 6) What SlopOS pressures Schell to steal

The strongest import is not “AI autocomplete everywhere.”
It is a compact posture cluster:
- one explicit **completion card** family,
- one **origin badge** family,
- one **parameter-help** card family,
- one **preflight card** family,
- one clear split between **insert / review / run**,
- and one rule that live completion search stays **scoped, bounded, and non-authoritative**.

## 7) What Schell should deliberately refuse

### Refuse completion-equals-execution

Generating a candidate should not quietly run helper logic with more power than reviewed execution.

### Refuse hidden dynamic generators as baseline truth

If a completion source executes commands, touches the network, or crawls a view, badge it clearly and keep it weaker than static or shell-known truth.

### Refuse one giant omniscient completion engine first

Static specs, shell-known rows, bridged engines, and explicit dynamic generators should remain separable.

### Refuse parameter prompting that mutates input by surprise

Good prompting should fill typed slots or land edits visibly into the active input field.

### Refuse preflight-equals-approval

A helpful preflight card may explain likely effects or drift.
It does not grant permission.

## 8) Current consequence for Schell

The best next step looks compact:
1. one **completion card** with value, description, type, and origin badge,
2. one **parameter-help** mode for the focused argument or flag,
3. one **preflight card** that can summarize missing parameters, basis drift, and likely authority deltas,
4. one outcome ladder for **insert / keep-open / review / hold / run**,
5. one scoped discovery rule for **peer / lane / view / session** filtering,
6. and one rule that dynamic generators remain explicit, slower-grade, and visibly weaker than static or shell-authenticated rows.

That is enough to make Schell much better at command entry and safer around complex actions while still keeping completion engines, plugin seams, parser integration, and help backends open.
