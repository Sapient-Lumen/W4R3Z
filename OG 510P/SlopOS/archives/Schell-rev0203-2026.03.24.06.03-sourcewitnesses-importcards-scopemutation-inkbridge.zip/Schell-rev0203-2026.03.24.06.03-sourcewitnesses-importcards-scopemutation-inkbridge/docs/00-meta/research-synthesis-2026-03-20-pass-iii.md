# Research synthesis — pass III

This pass compresses the freshest outside pressure into load-bearing imports for Schell.
The goal is not to pick winners.
The goal is to keep stealing good ideas without freezing the wrong layer.

## Outside convergence worth paying attention to

### 1) Shells and terminals get better when command boundaries are explicit

WezTerm, Ghostty, VS Code shell integration, and Warp all benefit from explicit command/prompt/output boundaries.
The common lesson is simple:
**do not scrape prompts if the shell can tell the truth directly.**

Local import for Schell:

- semantic zones are worth carrying early,
- block navigation is worth emulating,
- and transcript truth should preserve those boundaries even when rich UI disappears.

### 2) Permission systems work best when requests are timed to the user’s current action

XDG portals and Android runtime-permission guidance converge on a similar posture:
ask narrowly, ask at the moment of use, explain why now, allow denial, and let grants expire or be revoked.

Local import for Schell:

- review cards should be tied to one concrete action,
- one-shot and expiring grants should feel normal,
- and denial surfaces should teach the smallest likely-successful next request.

### 3) Rich keyboard/input protocols matter once the terminal becomes more than a byte pump

kitty's keyboard protocol is useful pressure because it treats advanced terminal input as a protocol problem rather than a pile of heuristics.
Schell should not copy a terminal whole, but it should remember that review panes, shelves, and prompt-safe editing will punish ambiguous input channels.

### 4) Modern shell ergonomics are real leverage, not sugar

fish and reedline both reinforce a humane lesson: rich completion, hints, multiline editing, and validation are the difference between a strict shell and an annoying one.
Schell should keep the interaction kind even while it keeps authority explicit.

## Moves worth stealing now

- prompt/output/review/receipt semantic marking,
- block-level navigation and copy,
- prompt-aware click and cursor safety,
- exact-artifact review cards,
- denial cards with stage-local rationale,
- transcript surfaces that preserve semantic boundaries,
- structured tracing for review/receipt lineage,
- and action-timed one-shot or expiring grants.

## Moves worth holding back

- full terminal-emulator lock-in,
- AI-product assumptions as shell architecture,
- heavyweight PTY dependence before the first reviewed-action proof,
- and any object model large enough to force the shell's language shape prematurely.

## Rust-side pressure after this pass

The best bounded first slice still looks like:

1. humane text input/editing,
2. structured tracing and receipt lineage,
3. transcript-backed reviewed-action proof,
4. then richer panes or shelves only if the proof clearly needs them.

That is enough to learn something real without overbuilding.
