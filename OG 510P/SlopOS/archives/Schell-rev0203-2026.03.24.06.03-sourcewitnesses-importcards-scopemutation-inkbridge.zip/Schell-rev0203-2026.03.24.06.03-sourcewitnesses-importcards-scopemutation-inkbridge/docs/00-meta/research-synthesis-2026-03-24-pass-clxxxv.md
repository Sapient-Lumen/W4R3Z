# Research synthesis — 2026-03-24 — pass CLXXXV

This pass sharpens one smaller lesson from current shell-integration, prompt-marking, and terminal-capability docs:
**the next trust breakthrough is not another clever terminal trick; it is making capability strength, degradation, and hop lineage explicit.**

## 1) Current terminal docs keep proving that luxury depends on fresh capability, not brand identity

Ghostty, kitty, WezTerm, and iTerm2 all offer genuinely delightful shell-aware features.
But their own docs reveal that these luxuries depend on real runtime conditions: shell integration present or absent, prompt markers emitted or not, OSC 7/133 support actually reaching the terminal, tmux passthrough configuration, SSH compatibility workarounds, and shell-specific startup behavior.

That means Schell should not ask only `what terminal is this?`
It should ask:
- what exact capability is claimed,
- what exact capability was freshly observed,
- what exact capability is only adapted,
- and what exact capability is now guessed or unavailable.

## 2) The ecosystem is paying a tax for silent downgrade

WezTerm is candid that cwd can come either from OSC 7 or from local process heuristics when OSC 7 was never sent.
Ghostty is candid that some shells work without injected integration, some features depend on integration, and some SSH compatibility features are opt-in band-aids.
kitty is candid that integration injection is shell-specific, cleans up after startup, and may not automatically survive later shell hops such as `exec zsh`, `sudo -E zsh`, or `tmux`.

That is a very expensive product lesson:
**users love shell-aware comfort, but they get confused when the downgrade boundary is invisible.**

So the next honest surface is not just `enabled/disabled`.
It is a compact capability witness and a degradation receipt.

## 3) Current products already expose the best “steals” for a capability-honest shell

There is a bounded cluster of proven luxuries worth stealing:
- exact prompt/input/output zones from OSC 133 style integration,
- same-cwd spawn and remote-aware titles from OSC 7 / pane context,
- jump-to-prompt and command-output selection from semantic chapters,
- command-finished notification routing,
- per-pane user vars or host/user context,
- and tiny debug overlays for semantic zones.

The product move for Schell is to import those as **capability-bound luxuries**.
A luxury should appear when a fresh witness exists, degrade visibly when that witness weakens, and never pretend that chrome or terminal label alone proves it still works.

## 4) The most useful new abstraction is small

A giant universal capability treaty would be premature.
A tiny four-rung ladder is enough for now:
- **exact** — the shell or terminal emitted/observed the stronger witness now,
- **adapted** — the feature works through a shell wrapper, mux passthrough, or provider-local bridge,
- **heuristic** — the feature is inferred from local inspection only,
- **unavailable** — no honest support remains.

That single ladder could already explain:
- cwd tracking,
- prompt-click editability,
- sticky chapter reliability,
- current-command output selection,
- finish notifications,
- and remote-aware tab or status chrome.

## 5) The best past lesson to steal is cleanup discipline

kitty's startup behavior is especially useful here.
It uses environment-variable-driven integration and then unsets the variable so it does not pollute the system.
That is a quiet but brilliant design instinct.
It says terminal luxury should be:
- explicit,
- scoped,
- reversible,
- and cleaned up after activation.

That discipline fits Schell perfectly.
Any capability witness or helper-enabled luxury should have clear scope, freshness, and expiry instead of lingering as ambient truth.

## 6) The no-regret Schell move

Schell should add one dedicated surface for:
- capability witnesses,
- degradation receipts,
- hop-lineage cards,
- capability debug overlays,
- and freshness/expiry rules for terminal luxuries.

That would let the shell+terminal feel dramatically more self-explanatory without freezing a final OSC family, a final terminfo treaty, a final mux protocol, or a final remote-control architecture.

## 7) Compact conclusion

The ecosystem already paid for the lesson:
semantic prompt protocols, cwd escapes, prompt marks, pane vars, click-events, and finish notifications are valuable — but only when their current strength is clear.

So the next low-regret Schell seam is **capability witnesses, degradation receipts, and hop lineage humility** so modern shell+terminal luxury can remain brilliant without terminal folklore quietly impersonating fresh truth.
