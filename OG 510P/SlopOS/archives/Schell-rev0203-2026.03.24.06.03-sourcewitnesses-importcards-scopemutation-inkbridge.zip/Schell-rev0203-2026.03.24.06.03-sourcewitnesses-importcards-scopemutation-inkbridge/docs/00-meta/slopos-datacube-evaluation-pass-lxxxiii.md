# SlopOS datacube evaluation, pass LXXXIII (2026-03-22)

This pass evaluates the new session / workspace / layout seam against the current SlopOS archive.
The main result is straightforward:
**SlopOS strongly rewards a shell that treats workspaces, session managers, cached layouts, and restored contexts as explicit view/control objects rather than as ambient durable authority.**

That pressure comes from multiple places in the companion archive and lines up unusually well with the current terminal ecosystem.

## 1) SlopOS already treats sessions as provider-owned control objects, not caller-owned durable handles

`portal-session-posture-v0.md` is especially relevant here.
It says portal request/session objects are provider-owned control objects, one request has one terminal outcome, family-local long-lived sessions do not imply a generic resumable core seam, and Phase 1 exposes no generic resume/list/watch/inventory API.
That is a strong signal for Schell.

For Schell this implies:
- session/workspace surfaces should be provider-owned/local control cards,
- a session handle should not overclaim durable reopen authority,
- and generic “resume everything later from a global inventory” pressure should stay resisted until a narrower seam earns it.

## 2) SlopOS keeps restored runtime truth behind explicit repair barriers

`microvm-restore-repair-barrier-posture-v0.md` says restored execution must pass through repair before externally visible action resumes, and it refuses side-effect oracles as proof that repair happened.
That is a very strong companion lesson for a shell+terminal too.

For Schell this implies:
- resurrected sessions or workspaces should stay visibly weaker than live ones until reacquisition/repair succeeds,
- restored layout or scrollback memory should not be mistaken for current execution truth,
- and “it looked alive when I switched to it” should never substitute for an explicit live witness.

## 3) SlopOS keeps views and namespaces explicit rather than ambient

`view-namespace-posture-v0.md` keeps name resolution explicit, uses view objects rather than a global resolver, and refuses to let a privileged ambient `open(path)` become the authority story.
That matters here because many terminals quietly let “visible workspace” or “current tab set” act like a global work namespace.

For Schell this implies:
- workspaces should be named explicit local wrappers,
- chooser results should preserve family/type identity,
- and the shell should avoid turning the currently visible session tree into ambient target authority.

## 4) SlopOS already warns against overloading generic launch with web/session state

The OpenURI companion boundaries are helpful analogies.
`openuri-session-selection-boundary-v0.md` refuses to make generic URI launch into browser-profile or cookie-jar control.
`openuri-navigation-observation-boundary-v0.md` refuses to make generic launch into a downstream page-state telemetry seam.
That is the exact same kind of discipline Schell needs for workspaces.

For Schell this implies:
- generic workspace/session switching can stay rich without becoming a hidden policy plane,
- visibility change should not imply browsing/session-selection semantics,
- and observation/history of a workspace should remain weaker than a live control or approval seam.

## 5) The outside ecosystem now provides a companion-compatible answer

Current tools now show a narrow, compatible pattern:
- WezTerm proves workspaces are powerful local visibility wrappers and that one launcher can span tabs, workspaces, domains, and commands,
- tmux proves previewful session trees are worth stealing,
- kitty and Zellij prove explicit session/layout files are excellent project-context aids,
- and Zellij’s resurrection/cache model proves cached context is valuable but visibly historical.

SlopOS sharpens the cut:
**Schell should steal context-switch luxury, not session-authority folklore.**

## 6) What this pass now strongly suggests for Schell

The most companion-compatible moves are:
- **workspace cards** and **session cards** with live/detached/restored/historical posture,
- **layout-memory cards** separate from code-bearing start recipes,
- **restoration-depth badges** for layout-only versus viewport/scrollback residue,
- **family-labeled choosers** spanning workspace/session/layout/domain/history,
- **preview-first switching** before attach or batch action,
- **single active-input truth** separate from visible workspace selection,
- and **hold cards** whenever a cached or restored context is asked to do live-authority work.

## 7) Decisions this pass still refuses to make too early

This pass still does **not** force:
- one final workspace persistence story,
- one final session-manager substrate,
- one final resurrection wire format,
- one final workspace-sharing model,
- one final layout grammar,
- or one final global context inventory surface.

The answer stays smaller and stronger:
**let Schell become excellent at context switching, workspace switching, session browsing, and project-start recipes — but keep visible workspace state, cached restoration data, and current live authority separately named.**
