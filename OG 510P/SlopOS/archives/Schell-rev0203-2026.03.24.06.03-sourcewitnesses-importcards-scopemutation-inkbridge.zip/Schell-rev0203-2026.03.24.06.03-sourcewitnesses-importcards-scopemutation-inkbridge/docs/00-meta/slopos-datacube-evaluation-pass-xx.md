# SlopOS datacube evaluation, pass XX

**Remote comfort should not erase exact peer identity, hop boundaries, or borrowed local authority. Schell needs explicit remote domains, peer witnesses, and attach honesty so SSH/mosh/mux convenience stays humane without quietly becoming a second authority plane.**

This pass adds another strong SlopOS import.
Schell already knows how to think about execution grounds, trusted chrome, output capsules, intent packets, and progress scopes.
The next seam is what happens when the operator is **not local anymore**, or is *partly* local and partly remote.

SlopOS is unusually crisp here too:
- D-CAPSHELL keeps refusing ambient local IPC, ambient peer inspection, ambient network, and inherited session folklore,
- D-NETLEASE keeps outbound network explicit, lease-bounded, and separate from current live-state mythology,
- D-ACTIVATE treats restart and continuity as explicit supervisor-owned handoff rather than “same thing because it still looks attached”,
- D-PLUMB keeps routed action request-local instead of letting visibility or convenience become a hidden transport substrate,
- and D-CAPX / sturdyref posture keeps restore/import explicit instead of laundering remote continuity into local ambient presence.

The import for Schell is straightforward:
**remote domains, attaches, resumes, and forwards should become explicit packet families with exact peer witnesses rather than terminal folklore.**

## 1) SlopOS keeps connectivity and authority separate

SlopOS repeatedly draws the same boundary:
- request identity is not live current state,
- historical descriptors are not proof that the grant/session is still active,
- continuity mechanisms are not authority amplification,
- and convenience transports should not create hidden policy.

That is the right shell+terminal lesson too.
A connected SSH tab, a reused mux client, a restored remote pane, or a resumed mobile shell session may all be *useful continuity*.
None of them automatically prove:
- that the peer is the same host as before,
- that the same node behind a cluster alias answered,
- that the same forwarded local capabilities are live,
- or that the same review basis still holds.

## 2) Attach is not connect, and restore is not re-witness

D-ACTIVATE is helpful because it makes continuity a first-class object instead of a ghostly intuition.
Schell should import that posture for remote views.

A good remote ladder should keep at least these states distinct:
- **fresh-connect** — new remote handshake + new peer witness,
- **reattach** — attached to an existing remote session/mux/server,
- **resume** — transport continuity across roaming/interruption,
- **restore** — historical local view re-opened without current remote truth yet,
- **degraded** — still showing history or buffered interaction, but peer/live guarantees are stale or missing.

That compact distinction would save a lot of confusion.

## 3) Forwarded local seams are borrowed authority, not remote magic

SlopOS’s wallet and portal posture says descriptive summaries should remain descriptive, and mediated grants should stay exact.
That strongly suggests Schell should surface borrowed local power explicitly when a remote lane can touch it.

Examples include:
- local auth-agent forwarding,
- local socket / control-channel forwarding,
- local clipboard or host-effect mediation,
- local editor or open/reveal callbacks,
- local terminfo/env/bootstrap helpers,
- and any remote-control bridge back into the local terminal host.

The key import is not “forbid everything remote.”
It is smaller:
**say which local seams are currently borrowable from the remote lane, and say how strong that borrowing really is.**

## 4) Exact peer identity should be a real object, not a tab title vibe

SlopOS loves exactness around subject identity, request identity, and review basis.
That should carry into remote shells.

Schell should prefer one compact **peer witness** packet over a hundred scattered cues.
A first packet could include:
- `domain_kind` — local / ssh / ssh-mux / remote-server / roaming / other,
- `display_name` — operator-friendly alias,
- `peer_basis` — exact host-key / server-key / attestation / none,
- `route_basis` — direct / jump / mux-attach / restored / unknown,
- `hop_count` or a bounded hop-chain witness,
- `feature_posture` — shell integration / terminfo / degraded / provisional echo,
- `borrowed_local_authority` — compact summary only.

That is enough to make remote truth legible without freezing the final transport.

## 5) DelayBasin pushes exactly the right discipline here

DelayBasin keeps teaching that public state should say:
- what is known,
- what is only a continuation guess,
- what was re-entered from history,
- and what is blocked on a fresh witness.

That is a very good teacher for remote shells.
Schell should not pretend that a familiar prompt, remembered cwd, or still-open split proves a live remote peer relationship.
It should say when the view is historical, when the peer witness is stale, and what exact re-witness step would restore strong actions.

## 6) A no-regret remote cluster is visible now

A decision-light Schell answer looks like this:
- one explicit **remote domain kind** family,
- one compact **peer witness** packet,
- one **attach/resume/restore** honesty ladder,
- one **borrowed-local-authority** strip for remote lanes,
- one **hop-chain degradation** rule when nested or partially inferred remote hops outrun exact knowledge,
- one **provisional-local-echo** badge for roaming/predictive modes,
- and one transcript-visible witness for when strong remote actions were downgraded because peer truth was stale or borrowed-local authority was too strong.

## 7) The main decisions to keep open

This pass does **not** force:
- one final remote transport,
- one SSH-specific worldview,
- one host-attestation mechanism,
- one jump-host or bastion algebra,
- one server-install model,
- one remote clipboard or file-edit bridge,
- or one unified story for SSH, mosh, native CapRPC, and future SlopOS-specific remoting.

The no-regret import is smaller:
**remote convenience should stay excellent, but the shell+terminal should always be able to say who the peer is, how the current continuity was obtained, and which local powers the remote lane can currently borrow.**
