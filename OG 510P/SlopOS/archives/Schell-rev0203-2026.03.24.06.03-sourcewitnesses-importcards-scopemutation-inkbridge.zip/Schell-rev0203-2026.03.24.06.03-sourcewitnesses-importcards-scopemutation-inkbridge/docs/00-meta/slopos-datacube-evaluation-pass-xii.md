# SlopOS datacube evaluation — pass XII

This pass keeps one new synthesis in view:
**Schell should treat outside-world ingress as explicit packets, not as “just text.” Clipboard paste, drag/drop, file-transfer payloads, and imported snippets should enter the shell+terminal through bounded ingress objects with provenance, trust hints, and quarantine posture.**

SlopOS keeps teaching the same deeper lesson from new seams:
explicit import, fresh local identity, quarantine-first treatment, and refusal of ambient helper folklore matter more than smooth-looking convenience.
DelayBasin adds the process lesson that ingress should be admitted in bounded form, with public hold packets when the system declines to treat an outside packet as live execution authority.
The next Schell import is to make that visible in the shell+terminal itself.

## Strongest SlopOS lessons right now

### 1) Fresh local identity matters more than byte equality

The import-to-docref family is unusually clear.
When bearer-backed or outside-world material enters routine document workflows, SlopOS first materializes a **fresh local object**.
It does not collapse the event into “same bytes, so just reuse the old thing.”
That protects origin, quarantine state, and workflow meaning from same-bytes laundering.

Local import for Schell:

- a dropped file or imported file-list should not silently become “the same trusted old object” just because a path or hash looks familiar,
- ingress events should preserve that they were **new outside-world arrivals** even when they resolve to familiar-looking content,
- and packet-local provenance should survive long enough for review, safe open, or conversion into a later durable object.

### 2) Outside-world document-like input should stay quarantine-first

SlopOS's import-to-docref boundary also refuses the common shortcut of treating explicit import as implicit trust.
Even explicit restore/import success does **not** clear quarantine or prove that the bytes are safe to run, preview actively, or write through.

Local import for Schell:

- dropped files, pasted path lists, clipboard HTML, and rich packet payloads should default to **inspect / import / open-untrusted** style actions rather than eager execution,
- “the user pasted it” is not proof that it should execute,
- and the terminal should be able to say “this packet is from outside-world ingress and is still untrusted” without feeling punitive.

### 3) Ambient clipboard and drag/drop convenience should not become the authority plane

SlopOS's MicroVM clipboard/drag-drop posture is a sharp warning.
It explicitly refuses to let convenience host↔guest clipboard and drag/drop helpers become the portable reviewed transfer plane.
That same warning generalizes cleanly to Schell.

Local import for Schell:

- clipboard sharing and drag/drop are useful operator conveniences,
- but they should not silently become the strongest reviewed data-import or execution channel,
- and strong actions should continue to route through explicit shell-owned review / import seams rather than ambient desktop-helper behavior.

### 4) Clipboard and file transfer want session-scoped mediation, not folklore

SlopOS keeps mediated transfer surfaces session-scoped and explicit.
That aligns with current portal practice: clipboard access attaches to an existing session, and file transfer is a dedicated inter-app bridge instead of a pile of accidental conventions.

Local import for Schell:

- the terminal should know whether an ingress packet came from direct typing, clipboard paste, drag/drop, or an explicit import action,
- file-bearing clipboard/drop events should be treated more like **import packets** than plain text,
- and the shell should not need to pretend that every incoming thing is one flat UTF-8 string.

### 5) No hidden shell expansion should be smuggled in through ingress

SlopOS's capshell word-expansion posture is also load-bearing here.
It rejects ambient globbing, tilde expansion, variable expansion, and command substitution before the reviewed argv is formed.
That is exactly the caution Schell needs for paste and drop behavior.

Local import for Schell:

- a dropped path list should not silently become an expansion result,
- pasted metacharacters should remain literal unless the user explicitly chooses otherwise,
- and “helpfully turning a packet into executable shell text” is one of the easiest ways to recreate the old shell's hidden authority seams.

### 6) DelayBasin's bounded-assimilation lesson belongs on ingress too

DelayBasin keeps pushing three method lessons that matter here:

- imports should remain explicitly bounded,
- nearby rejected moves should stay visible,
- and abstention/hold packets should explain why a thing was not promoted to a stronger lane.

That maps naturally to Schell ingress handling.
A suspicious multi-line paste, a control-character-bearing drop, or a clipboard packet with file-transfer MIME should not force the archive to decide too much.
It should produce a small, exact ingress object plus the next allowed actions.

## What Schell should deliberately refuse for now

### Refuse “pasted means trusted” folklore

User intent to paste or drop something is real, but it is not enough to prove that the payload should execute, expand, or attach to a strong action lane.

### Refuse raw-path drop as the default document workflow

Dropped files should not mainly arrive as shell text paths.
They should have a real import/document story available from the start.

### Refuse shared-clipboard mythology

A powerful custom terminal will be tempted to treat the clipboard as a global ambient substrate.
Schell should keep it packetized and explicit instead.

### Refuse hidden expansion on ingress

Paths, globs, variables, HTML fragments, and control-character-bearing payloads should not quietly reinterpret themselves during ingress.

## Current consequence for Schell

The best next ratchet is now:

1. **one ingress-packet family for paste/drop/import events,**
2. **one trust and quarantine hint strip for outside-world payloads,**
3. **one multi-line / no-bracketed-paste hold-card path,**
4. **one dropped-file import card that prefers docref/open-untrusted over raw path injection,**
5. **and one transcript-safe ingress witness so logs still explain what entered and how it was handled.**

That is a powerful way to make Schell feel super awesome while still keeping MIME algebra, clipboard backend shape, drag/drop plumbing, and full import architecture open.
