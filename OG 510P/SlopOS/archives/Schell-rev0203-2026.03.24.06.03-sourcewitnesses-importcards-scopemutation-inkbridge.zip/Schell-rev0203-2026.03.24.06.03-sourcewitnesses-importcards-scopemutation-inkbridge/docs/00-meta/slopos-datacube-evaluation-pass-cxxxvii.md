# SlopOS datacube evaluation — pass CXXXVII

This pass asks a narrower companion-safe question than “should Schell have same-directory splits, duplicate tabs, and cloned shells?”
The better question is:
**what is the smallest nearby-spawn model Schell can add without violating SlopOS exact launch footing or letting inherited context impersonate a fresh reviewed launch basis?**

## 1) SlopOS pressures Schell toward explicit forked footing, not magical duplication

SlopOS's D-CAPSHELL work keeps pressing on:
- exact exec selector,
- exact executable object,
- exact startup code closure,
- explicit env posture,
- explicit cwd / view posture,
- and refusal of hidden startup discovery.

That pressure applies directly here.
If Schell offers nearby-spawn luxuries, the companion-safe version is not “duplicate whatever this pane means.”
The safer version is closer to a **forked footing card** that explicitly says:
- cwd followed,
- domain followed or not,
- profile followed or not,
- env reset / inherited-static / shell-serialized,
- activation exact / reported / omitted,
- and whether the resulting spawn still deserves strong review or only compare-and-set review.

## 2) Same-cwd and same-domain should stay separately nameable

SlopOS already refuses the flattening of name lookup, launch target, and resulting authority.
That suggests a healthy nearby-spawn ladder for Schell:
- default fresh local launch,
- cwd-only fork,
- domain-following fork,
- profile-following fork,
- shell-state clone,
- restored/historical nearby-spawn offer.

This keeps “same here” from smuggling more than the operator intended.

## 3) ViewFS gives the right adjacent object shape

ViewFS is unusually helpful here.
It keeps unpublished object, published object, live bind, and receipt/history distinct.
That maps cleanly onto nearby spawn comfort:
- a spawn offer can exist as a derived card,
- a live room can exist after launch,
- a receipt can describe the spent action,
- and a remembered later relaunch offer can remain historical.

That pressure keeps nearby convenience from collapsing into one live-state myth.

## 4) Steward sharpens the inheritance boundary exactly where Schell needs it

Steward already argues that context inheritance should be:
- explicit,
- fieldwise,
- anchored when possible,
- and honest about fallback.

That is almost exactly the pressure Schell needs.
A pane-local convenience action should prefer exact anchored cwd/domain/profile footing when it exists.
If it falls back to remembered or terminal-reported context, the resulting spawn should confess the downgrade instead of silently inheriting strength.

## 5) Helm keeps convenience narrower than endorsement

Helm's endorsement pressure is again useful.
A convenient nearby spawn should not quietly become:
- a reusable exact launch card,
- an endorsed team recipe,
- or a proof that the cloned footing is safe to replay strongly.

That means Schell should keep explicit promotion paths from:
- convenience fork,
- to inspected fork,
- to exact local launch card,
- to stronger shared or endorsed object.

## 6) Companion-safe no-regret move

Schell does **not** need a huge launcher/workspace/session inheritance system next.
It only needs a compact split between:

- **fresh exact launch**
- **cwd fork**
- **domain fork**
- **profile fork**
- **shell-state clone**
- **layout-relative spawn**
- **historical relaunch**

with these rules:
- inherited fields are explicitly named,
- partial clones confess what was *not* inherited,
- shell-state clones stay weaker than fresh exact launch,
- restored nearby-spawn offers stay historical,
- and stronger reusable launch objects require explicit later promotion.

## 7) Compact conclusion

The companion cubes keep teaching the same law in different accents:
**nearby convenience is not the same thing as fresh exact footing.**

So the Schell-safe answer is small:
**spawn forks and forked footing should be separately named objects** rather than one flattering “duplicate this shell” story.
That gives the future shell+terminal a real luxury upgrade without forcing early decisions about clone formats, env-capsule treaties, workspace managers, or remote-domain constitutions.
