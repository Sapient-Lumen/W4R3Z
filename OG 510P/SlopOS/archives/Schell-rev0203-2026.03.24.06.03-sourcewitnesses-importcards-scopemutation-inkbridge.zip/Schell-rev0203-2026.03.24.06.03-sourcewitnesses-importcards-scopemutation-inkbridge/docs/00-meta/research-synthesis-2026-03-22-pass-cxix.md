# Research synthesis, pass CXIX (2026-03-22)

This pass keeps one narrower lesson explicit:
**Schell should maintain one internal semantic transport core and project it into named terminal-profile adapters with visible loss, rather than picking one terminal escape-sequence family as the architecture too early.**

The current ecosystem is giving a pretty clean signal.
VS Code documents a richer `OSC 633` family for prompt boundaries, exact command line, cwd, and optional nonce verification, while also supporting FinalTerm-style `OSC 133` and iTerm2-style `OSC 1337` with a somewhat degraded experience.
kitty documents `OSC 133` semantic markup plus optional command-line extensions and concrete redraw/hook failure modes.
Ghostty now supports prompt click-events and `cl=line` extensions, automatic/manual shell integration, and even a debug overlay for visualizing OSC 133 regions.
fish now reports cwd on every fresh prompt via `OSC 7`, marks prompt end via `OSC 133`, and supports richer prompt-click integrations.
tmux adds both passthrough controls and support for shell-prompt marking based on OSC 133.

Taken together, those tools do **not** say “there is one correct transport now.”
They say something more useful:
- the semantic payload is converging,
- the transport families remain plural,
- mux/remote hops still change what survives,
- and some terminals already distinguish richer verified paths from degraded compatibility paths.

That suggests a compact Schell move:

## 1) Keep a shell-owned semantic core

At minimum, Schell should know internally:
- prompt start/end,
- command start,
- output end / command finish,
- cwd,
- exit status,
- and whether an exact command line is available as shell-owned truth.

That internal truth should stay smaller than any one terminal's favorite wire format.

## 2) Project into explicit transport profiles

Instead of “shell integration yes/no,” Schell should probably name profiles such as:
- `plain-text-only`,
- `osc133-osc7-core`,
- `vscode-633-rich`,
- `iterm-1337-augmented`,
- `kitty-133x-augmented`,
- `tmux-relayed`,
- `historical/replay-only`,
- or `hybrid/unknown`.

That gives the shell+terminal a way to be ambitious without pretending every escape sequence means the same thing.

## 3) Treat richer families as additive, not constitutive

The richest profile available today should not become the definition of truth.
For example, exact command line and nonce verification might be projectable in one terminal family but not another.
Schell should preserve that internal fact even when the active terminal cannot consume it.

## 4) Make projection loss visible

This pass's most important addition is probably the phrase **projection loss**.
The shell+terminal should be able to say:
- the shell knew the fact but the transport could not carry it,
- a mux or remote hop stripped it,
- the terminal can only interpret a weaker compatibility profile,
- the session is restored/historical rather than freshly attested,
- or the marks exist but are not strong enough to unlock some action.

That would keep a lot of delight honest.

## 5) Steal the developer ergonomics too

Ghostty's debug overlay for OSC 133 areas is a genuinely excellent idea.
Schell should steal that spirit aggressively.
A developer/operator inspector that shows active semantic regions, current projection profile, and loss reasons would make the system much easier to trust and much easier to debug.

## 6) Compact design-phase answer

Schell does **not** need to choose one universal terminal treaty or one final shell-integration installer yet.
It only needs a bounded move:
- one internal semantic core,
- one named family of projection profiles,
- one visible loss story,
- and one debug/inspection path for seeing what really survived to the terminal.

That is enough to make the shell+terminal materially better while keeping architecture choices open.
