# Research synthesis, pass XXXIII (2026-03-21)

This pass focuses on one increasingly important seam:
**modern shell, terminal, IDE, and agent tooling keeps normalizing project-local hooks and command packs, which means Schell should import the good parts — searchability, insert-first reuse, contextual ranking, explicit trust, and reauthorization-on-change — without importing ambient project execution.**

## 1) Workspace trust is a strong lesson from the current editor/tooling world

VS Code's Workspace Trust docs say trust lets you decide whether code in a project folder can be executed by VS Code and extensions without explicit approval, and Restricted Mode exists to prevent automatic code execution.
The same docs say Restricted Mode disables or limits features such as AI agents, tasks, debugging, workspace settings, and extensions.
A January 2026 VS Code update adds another sharp signal: when workspace trust is not granted, opening the terminal is blocked by default because the shell may execute code such as by setting variables via an `.env` file.

That is a powerful present-day lesson for Schell.
Project-local context is helpful, but “opened the folder” is not a sufficient basis for ambient trust.

## 2) Hook systems are becoming normal, not exceptional

VS Code's agent-hooks docs say hooks execute custom shell commands at key lifecycle points during agent sessions, and describe them as deterministic automation for security checks, validation, and integration.
VS Code's agent-plugin docs then add a stronger warning: plugins can include hooks and MCP servers that run code on your machine, and plugin hooks fire alongside workspace and user-level hooks.

This is exactly why Schell should be careful.
The ecosystem is moving toward more project-local and tool-local executable customization, not less.
That makes a clean trust story more important, not optional.

## 3) direnv shows the right approval muscle memory

`direnv` is extremely relevant because it sits right on the shell prompt boundary.
Its official docs say it needs a shell hook, and its command docs expose explicit `allow`, `deny`, and `hook` operations.
Its stdlib then sharpens the lesson with `require_allowed`: if watched files change, the user must run `direnv allow` again to re-authorize the environment.

That is a brilliant idea Schell should steal.
Not the ambient prompt hook part.
The **reauthorize-on-change** part.

## 4) The best reuse surfaces stay insert-first and editable

Warp's workflow docs are strong here.
Workflows are saved parameterized commands that are searchable from the command palette, pasted into the active input, and editable before running.
Warp also supports enum arguments and dynamic enum sources, which is a nice example of rich project-aware help — but the key design win is that the operator can still adjust the command and arguments before execution.

That is a Schell-quality pattern:
project-local intelligence should prefer **insert, explain, and edit** before **run**.

## 5) Context-rich recall is worth stealing when it stays non-authoritative

Atuin stores extra command context such as working directory, exit code, and duration.
iTerm2 tracks current working directory per line for semantic history.
VS Code shell integration lets the terminal know more about what is happening inside the shell, enabling working-directory detection, command detection, decorations, and navigation.

Together these point to a great Schell move:
repo-local and personal accelerator packs can rank and resolve better when they know cwd, command outcome, and chapter boundaries.
But those signals should improve proposal quality, not silently widen authority.

## 6) Ranking and display tricks are valuable when they remain explainable

zoxide returns directory matches in descending frecency and documents its aging behavior.
Nushell's recent 0.111.0 work keeps improving list/filter ergonomics, including per-column matching and display control.
These are small but important clues:
Schell should not only care whether project-local help exists; it should care whether the ranking and display logic is legible enough to stay trustworthy.

That suggests a useful split:
- **ranking logic** may be clever,
- **inserted value** should remain exact,
- **display text** may be richer,
- and the operator should be able to see what source family shaped a suggestion.

## 7) A no-regret import is visible now

A compact Schell import could be:
- one **repo accelerator pack** object,
- one **trust lease** for activating it locally,
- one **changed-basis reauthorization** rule,
- one **proposal-only / veto-only** safe floor,
- one **insert-first workflow/runbook posture**,
- and one **source/freshness/provenance badge** for project-local help.

That gives Schell a path to very rich local intelligence without committing yet to:
- a plugin marketplace,
- a workspace-trust clone,
- a signature PKI,
- or a universal hook runtime.

## 8) The lesson we must learn from the past

The old failure mode was not just “shell startup files are messy.”
The deeper failure was that repo-local or machine-local behavior became ambient enough that operators stopped remembering what was personal config, what was project policy, what was imported helper code, and what was actual shell truth.

The current ecosystem gives Schell a better answer:
- trust should be explicit,
- restricted mode should be real,
- changes should trigger re-approval,
- reuse should often land in editable input first,
- and rich contextual ranking should stay weaker than reviewed execution.
