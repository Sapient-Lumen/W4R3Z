# Research synthesis — 2026-03-24 — pass CXCVIII

This pass sharpens another old shell lesson that still matters for a brand-new shell+terminal:
**substitution is powerful, but it should not silently erase the difference between the typed substitution token, the helper footing that produced it, the capture form that came back, the split/trim residue that was lost or kept, and the exact reviewed spend.**

## 1) Current shells already prove that substitution is not one thing

Bash still teaches the central lesson in the clearest possible way.
Its manual says command substitution executes the helper in a **subshell environment** and replaces the substitution with the helper’s standard output, **with any trailing newlines deleted**.
Embedded newlines are not deleted, but they may be removed later during word splitting.
So classic `$(...)` already bundles helper scope, capture loss, and post-capture splitting into one tiny surface.

Bash also keeps a surprisingly modern alternative around.
`${ command; }` executes in the **current execution environment** and captures its output, while `${| command; }` expands to the value of `REPLY` **without removing trailing newlines**.
That means even one shell already distinguishes between “run in a child and capture text” and “run here, keep side effects, and use a different capture lane.”

Bash process substitution sharpens the warning.
Its manual says `<(list)` and `>(list)` run the helper **asynchronously** and pass a filename to the current command.
So some substitution forms are not text capture at all; they are temporary route creation disguised as a word fragment.

zsh makes the route story even more explicit.
Its expansion order performs **process substitution before command substitution**.
Its `<(...)` and `>(...)` forms hand back a `/dev/fd` path or named pipe where available, while `=(...)` returns the name of a **temporary file** containing the helper output for programs that need to seek.
The docs also note that these forms are expanded only when first parsing command or assignment arguments, and even show a workaround using an anonymous shell function so a temporary substitution survives long enough.
That is an unusually vivid reminder that substitution has parsing posture, object kind, and lifetime.

fish keeps the seam smaller but still very explicit.
Its current tutorial says command substitutions use `$(command)` or `(command)`, do **not** use backticks, and split only on **newlines** rather than all whitespace.
Quoted command substitution preserves the result as one argument.
For process-substitution-like behavior, fish uses `psub`, whose docs describe it as a mix between command substitution and piping that returns a filename, either through a regular file or a FIFO, with `--file` better when the reader needs to seek and `--fifo` better when streaming behavior is wanted.
Fish’s own design notes are refreshingly direct that subshells, command substitution, and process substitution are strongly related and that fish only supports command substitution directly, leaving the others to blocks or `psub`.

PowerShell and Nushell point toward the future instead of away from it.
PowerShell’s subexpression operator `$(...)` returns the result of one or more statements, producing a scalar for one result and an array for multiple results, while `@(...)` always forces array shape.
Nushell’s “Thinking in Nu” guide says an expression can return only a **single value**, that if there are multiple subexpressions only the **last value is returned**, and that every command returns a value.
That is a strong design signal: once shells admit richer capture forms, explicit value shape beats textual folklore.

## 2) The lesson Schell must learn from the past

The historical mistake is not simply “people sometimes forget that `$(...)` trims newlines.”
The deeper mistake is **flattening capture into invisible substitution folklore**:
- the exact substitution token the operator typed,
- the helper footing that produced it,
- the capture form that came back,
- the residue posture that trimmed, split, or collapsed it,
- the temporary route or sidecar lifetime when capture is file-backed,
- and the later receipt of what exact text/value/path actually flowed.

Once those collapse, three bad things happen:
1. review becomes less exact because the shell hides whether the helper ran in a child, current scope, async sidecar, or expression lane,
2. transcripts and exports preserve realized text but forget whether it came from a temp file, FIFO, scalar value, or trimmed text capture,
3. and operators start trusting local helper packaging as if it were durable command truth.

## 3) The nifty ideas worth stealing are source-labeled and capture-first

The current ecosystem points to several low-regret steals:
- **substitution chips** that say `capture text`, `capture one arg`, `capture scalar`, `capture array`, `capture temp file`, or `capture fifo`,
- **trim/split badges** that say `trim trailing newlines`, `newline split`, `IFS split`, `quoted collect`, or `last value only`,
- **helper footing chips** that say `subshell`, `current env`, `child scope`, `async sidecar`, or `expression-local`,
- **route cards** for process substitutions that expose `/dev/fd`, FIFO, or temp-file posture and lease length,
- **compare reveals** for inline text capture versus file-backed sidecar versus explicit value-return capture,
- **capture-loss notes** when trailing newlines or intermediate values are discarded,
- and **reveal ladders** that keep exact realized text/value/path one step away from the compact summary.

These are super awesome because they improve comfort and safety without forcing Schell to decide:
- one final substitution/value algebra,
- one final sidecar storage law,
- one final process-substitution protocol,
- one final transcript constitution for helper routes,
- or one final compatibility layer.

## 4) The moves Schell should refuse for now

Schell should refuse, for now:
- substitution syntax that is only explainable after a surprising result,
- hidden trim/split loss,
- export surfaces that preserve only the realized text and forget the capture form,
- helper sidecars that hide whether the caller got a FIFO, `/dev/fd`, or temp file,
- and any insistence that every future capture must collapse into plain argv text.

In other words:
**steal the speed of classic capture, not the ambiguity of classic substitution folklore.**

## 5) The no-regret Schell seam

Schell should add one dedicated surface for:
- typed substitution family,
- helper footing,
- capture form,
- trim/split residue posture,
- side-effect persistence posture,
- sidecar lifetime,
- exact realization reveal,
- and reviewed-spend relation.

That lets the shell feel dramatically smarter around inline capture, file-backed helpers, and value-return expressions without deciding whether the long-term answer is POSIX-ish text substitution, typed value splicing, sidecar objects, or some hybrid.

## 6) Compact conclusion

Current official docs line up unusually well here.
Bash shows that child-scope capture, current-scope capture, and trailing-newline behavior are already meaningfully different.
zsh shows that process substitution is really route-object creation with real lifetime caveats.
fish proves that friendlier shells still need explicit split and sidecar posture.
PowerShell and Nushell show that the future gets better when result shape is named instead of implied.

So the next low-regret Schell seam is **substitution witnesses, capture residue, and helper-sidecar humility** so shell capture stays powerful and delightful without becoming hidden route or residue authority.
