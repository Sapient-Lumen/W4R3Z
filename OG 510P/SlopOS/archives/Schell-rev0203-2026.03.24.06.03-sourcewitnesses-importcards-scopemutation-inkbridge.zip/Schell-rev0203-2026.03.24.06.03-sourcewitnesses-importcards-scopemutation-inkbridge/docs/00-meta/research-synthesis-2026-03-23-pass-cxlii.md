# Research synthesis — 2026-03-23 — pass CXLII

This pass sharpens one fresh shell+terminal lesson from current upstream docs:
**the ecosystem is getting much better at waking you up and taking you back to the relevant command, prompt, or output — which makes return-path honesty and acknowledgement humility a real design seam rather than just a notification detail.**

## 1) Ghostty keeps command-finished alerts small and policy-shaped

Ghostty 1.3.0 now has command-finished notifications with separate controls for when the alert fires, what action kind is used (`bell`, `notify`, or both), and the minimum command duration before a cue is sent.
That is instructive because it keeps attention small.
The product can page you helpfully without pretending that the alert itself is the durable record of what happened.

## 2) Warp shows that “needs input” and “long-running command finished” are different wake-up families

Warp’s current notifications docs say desktop notifications can trigger for long-running commands and password prompts, and Warp also supports custom OSC 9 / OSC 777 notification hooks.
That is an unusually useful reminder.
The best alert UX is not just “done” versus “not done.”
It often needs a separate family for “this session is blocked and wants you back now.”

## 3) VS Code points to exact return rather than vague rediscovery

VS Code’s 1.106 release notes are especially helpful here.
“Show Terminal” reveals and focuses hidden sessions and, with rich shell integration, scrolls directly to the relevant command; “Show Output” can open the terminal’s final output inline.
That is one of the strongest current ideas in the field.
The product should help the operator get back to the exact locus of meaning, not just vaguely restore a tab and hope the user rediscovers the right line in scrollback.

## 4) kitty makes the warning label explicit: alerts can be clicked, activated, closed, updated, and even send something back

kitty’s desktop notification protocol is powerful in a very revealing way.
Clicking a notification can optionally focus the originating window and/or send an escape code back to the application, and the newer notification support adds buttons, closure/activation reporting, updates, and filtering.
That proves two things at once:
- return-to-origin luxury is very real,
- and alert interaction is dangerously close to becoming a control channel if the product stops naming the difference between wake-up, acknowledgement, and approval.

## 5) iTerm2 reminds us that many alerts are weaker than users think

iTerm2’s profile preferences can post Notification Center alerts when a session receives output, becomes idle, rings the bell, closes, or receives a proprietary escape sequence to post a notification.
That is a perfect caution.
Many alerts are best understood as **attention heuristics or policy-chosen cues**, not as durable outcome truth.
An “alert happened” story is too coarse for a serious shell+terminal.

## 6) The ecosystem is converging on a better story than “notification center”

The current tools collectively point to a smaller, more useful lesson:
- alerts should be policy-shaped,
- there should be separate wake-up families such as finished, waiting-input, and generic attention,
- and the best click affordance is usually a return path to exact context rather than a hidden action.

That is much better than the old terminal folklore where a bell either rang or did not and everything else had to be inferred from memory.

## 7) The stealable move is wake tickets, not stronger clicks

The best move to steal is small and sharp:
**give every meaningful cue a wake ticket that can bring the operator back to the exact chapter, prompt witness, sidecar checkpoint, or output that mattered.**

That unlocks:
- command-finish returns,
- waiting-input returns,
- exact room focus,
- output reopeners,
- better restored-history posture,
- and clear operator acknowledgement,

without teaching users that clicking an alert automatically spent approval or proved durable completion.

## 8) Compact conclusion

Current docs show several real return-path ingredients in the wild.
Ghostty keeps command-finished cues small and configurable.
Warp distinguishes long-running finish from password-needed wake-ups and accepts custom notification hooks.
VS Code invests in exact “Show Terminal” / “Show Output” return paths.
kitty makes activated/closed/actionful notifications explicit.
iTerm2 shows how many different weak events can raise alerts in practice.

Schell should take the hint.
It needs a first-class split between **attention cue**, **wake ticket**, **return path**, **delivery residue**, **acknowledgement chip**, and **later durable outcome truth** so the future shell+terminal can feel dramatically better without letting “the terminal brought me back” impersonate “the terminal approved this” or “the alert itself is the record.”
