# Research synthesis, pass LXXI (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should absolutely steal shell ecosystem luxury — prompt presets, meaning-first themes, generated completions, contextual history, optional sync, and capability-bounded extensions — but only if pure data, startup code, per-directory overlays, helper processes, and synced residue stay separately named instead of collapsing into one flattering “install this shell pack” story.**

This seam matters because the past keeps teaching the same lesson in two voices.
One voice says shells become humane when prompt polish, completions, history search, and per-project context are easy to add.
The other says shell ecosystems become fragile and unsafe when every improvement is obtained by sourcing more startup code, evaluating more prompt helpers, trusting more per-directory hooks, and syncing more command residue than anyone intended.
That is exactly the seam Schell can improve without choosing one final add-on marketplace, one final plugin ABI, one final prompt DSL, or one final history-sync service.

## 1) The biggest lesson from shell history: the ecosystem usually arrives as startup code

The current Oh My Zsh site is a loud reminder of how shell ecosystems tend to grow.
It advertises hundreds of plugins and 150 bundled themes, and installation still begins with a fetched shell script.
That is not an argument against delight.
It is a warning that shell delight usually reaches the operator as ambient startup authority.
Schell should learn the positive lesson — ecosystems matter — while refusing the rc-soup default. See: https://ohmyz.sh/

## 2) Starship proves pure-data prompt configuration is a much better default than prompt functions everywhere

Starship's current docs say all configuration lives in `~/.config/starship.toml`, and the config schema is explicit enough to support presets and editor completion.
That is a terrific clue.
A prompt should begin life as data:
- slots,
- meanings,
- visibility rules,
- right-prompt placement,
- icon packs,
- and optional preset imports.
The shell may still need a tiny adapter to render it, but the prompt's *meaning* does not need to be arbitrary rc code.
Schell should steal that pattern aggressively. See: https://starship.rs/config/ and https://starship.rs/presets/

## 3) Atuin proves history becomes far more useful once it carries context, but sync changes the trust story

The current Atuin docs say shell history is stored in SQLite, that extra context is recorded for commands, and that sync across machines is optional and end-to-end encrypted.
That is exactly the kind of design pressure Schell should import.
History is much more valuable when it remembers more than one command string.
But the moment history can sync, become queryable, or carry more context, it also becomes a privacy and residue surface.
Schell should therefore treat contextual history as a named wallet with explicit sync/export posture, not as a hidden improvement to the old `~/.bash_history` idea. See: https://docs.atuin.sh/cli/guide/getting-started/ and https://docs.atuin.sh/cli/reference/sync/

## 4) Meaning-first theming is a brilliant idea worth stealing

Atuin's current theming docs say themes map semantic meanings like `AlertInfo`, `Guidance`, `Important`, and `Title` to colors.
That is a much stronger pattern than “pick some ANSI colors and hope the UI stays legible.”
Schell should steal this.
Prompt themes, review cards, receipts, warnings, and helper-lane badges should all target semantic roles first and rendering values second.
That would let the shell+terminal share one theme vocabulary without freezing one renderer or one color pipeline. See: https://docs.atuin.sh/cli/guide/theming/

## 5) direnv proves per-directory environment help is real, but it also proves that directory entry is authority

The current direnv docs say it hooks into the shell, checks for `.envrc` or `.env` before each prompt, and loads authorized files into a bash sub-shell so it can export only the environment diff back.
The current stdlib docs add file and directory watch lists and re-authorization helpers.
This is genuinely useful.
It is also a precise warning.
Per-directory environment posture is not “just convenience.”
It is code-bearing startup behavior tied to cwd changes.
Schell should steal the env-diff preview, allow/deny posture, and watched-input honesty, but it should refuse the idea that entering a directory should silently become a generic code-loading event. See: https://direnv.net/ ; https://direnv.net/man/direnv-stdlib.1.html ; https://direnv.net/docs/hook.html

## 6) fish proves completion generation can be rich without being a generic plugin language

The current fish docs say `fish_update_completions` parses installed manual pages and attempts to create completion files, without overwriting custom completions.
That is a superb no-regret move.
Completions should begin as data bundles or generated descriptors, not as arbitrary prompt-time shell code.
Schell should steal the idea of generated completion packs and preserve a narrow path for richer dynamic providers only when they are explicitly admitted and capability-bounded. See: https://fishshell.com/docs/current/cmds/fish_update_completions.html

## 7) Nushell proves extension protocols should be versioned and registry-visible

The current Nushell plugin docs say plugins communicate over a versioned `nu-plugin` protocol and must match the shell's plugin version.
That is the right kind of humility.
Add-ons should have:
- explicit install state,
- explicit registration/import state,
- protocol/version visibility,
- and a clean broken-version story.
Schell should steal that shape rather than rely on “source this file and hope everything still works.” See: https://www.nushell.sh/book/plugins.html

## 8) Current runbook tools also prove that environment capture is never free

Atuin Desktop's current shell-environment docs explain interactive versus non-interactive shell differences, then say the app tries to capture environment variables from an interactive shell at startup and reuse them for script blocks.
The same docs also list the limitations: newly installed tools may be missing until restart, complex shell config may fail to transfer, and environment managers may not carry over cleanly.
That is a perfect Schell lesson.
Environment capture can be a helpful compatibility bridge.
It should never pretend to be exact current shell truth. See: https://docs.atuin.sh/desktop/shell-environment/

## 9) The stealable move set now looks very strong and still decision-light

The best no-regret moves now look like this:
1. **add-on manifests** that distinguish pure data from code and name startup footing explicitly,
2. **meaning-first prompt and theme packs** rather than arbitrary prompt functions by default,
3. **generated completion bundles** with provenance badges,
4. **reviewed env-overlay cards** for per-directory posture instead of silent `.envrc` magic,
5. **contextual history wallets** with explicit sync/export/redaction posture,
6. **versioned capability-bounded extension imports** instead of raw rc/plugin sourcing,
7. and **compat bridges with claim-strength badges** when old ecosystems must be carried.

That is enough to make Schell feel dramatically more powerful than legacy shells without prematurely freezing one package manager, one runtime, one sync backend, or one marketplace story.

## 10) Decisions intentionally kept open

This pass does **not** freeze:
- one universal add-on packaging format,
- one final prompt DSL,
- one final extension runtime or ABI,
- one final history-sync service,
- one universal per-directory environment policy,
- or one final marketplace / signing / discovery stack.

The no-regret move is smaller:
**steal pure-data prompt packs, meaning-first themes, generated completions, contextual history, and capability-bounded add-ons — but keep startup code, env overlays, sync residue, and helper posture visibly separate.**
