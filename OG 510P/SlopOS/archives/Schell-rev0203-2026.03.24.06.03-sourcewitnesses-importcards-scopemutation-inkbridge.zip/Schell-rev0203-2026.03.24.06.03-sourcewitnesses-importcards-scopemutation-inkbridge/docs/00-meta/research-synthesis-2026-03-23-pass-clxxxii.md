# Research synthesis — 2026-03-23 — pass CLXXXII

This pass sharpens one fresh lesson from current terminal and cursor docs:
**the ecosystem is good at marks, command guides, sticky command headers, and saved cursors, but the next operator truth is smaller: does the old anchor still survive, or did bounded history, restore limits, or source-side cursor expiry quietly kill it?**

## 1) Current terminal docs keep telling us history is bounded

VS Code's terminal basics docs say the terminal buffer keeps a configurable amount of scrollback via `terminal.integrated.scrollback`, which defaults to `1000` lines.
Its advanced docs say persistent sessions reconnect/revive prior terminals, but the amount of content restored is separately bounded by `terminal.integrated.persistentSessionScrollback`.
That means preserved command cards and resumed rooms are useful, but they are not a promise that every old review or first-unseen anchor still survives exact.

Ghostty's config reference is even more direct: `scrollback-limit` bounds the scrollback buffer, and when the limit is reached, **the oldest lines are removed from scrollback**.
Windows Terminal's advanced profile settings say `historySize` bounds how many lines can be scrolled back through, defaulting to `9001`.
WezTerm's scrollback docs likewise say its searchable scrollback buffer has a configurable maximum size.

the product lesson is simple:
**a shell+terminal that offers resume/review anchors must also be able to confess when bounded retention killed them.**

## 2) Current terminal docs also keep making anchor navigation more worth preserving

The same docs make the tension clearer.
VS Code shell integration supports command detection, command navigation, a command guide, sticky scroll, and clicking the sticky command to jump back to the command in the buffer.
Ghostty shell integration exposes prompt-aware features like `jump_to_prompt` and command/output selection.
WezTerm says OSC 7 plus OSC 133/1337 enable jumping through scrollback to earlier commands and selecting complete command output.

Those are all great steals for Schell.
But once you lean into them, one more truth becomes mandatory:
**the UI has to say whether the anchor still exists.**
Otherwise command navigation comfort turns into silent jump-to-latest repair folklore.

## 3) Cursor docs outside terminals make expiry and reset explicit

Kubernetes' API concepts docs are unusually crisp here.
The API server preserves historical change data for only a limited time; when a client asks for an older `resourceVersion` that is no longer retained, the server may return HTTP `410 Gone`, and clients are expected to clear local cache, perform a new get/list, and restart from a newer `resourceVersion`.
The same docs say continue tokens also expire after a short period and can return `410 Gone`.

Dropbox's detecting-changes guide says folder cursors are long-lived but may expire if unused for an extended time; an expired cursor returns a `409 reset` error and the client should issue a fresh list call to obtain a new cursor.
Watchman's clockspec docs add another useful nuance: named cursors advance convenience state, but they cannot roll back.

That cluster is a very strong Schell design hint.
When an old review/resume anchor dies, say **why**, say **what reset is required**, and do not fake continuity.

## 4) The no-regret Schell move is anchor-survival posture, not a giant replay constitution

Putting these together suggests a much smaller next move than a full replay/watch platform.
Schell should add:
- a tiny **anchor survival strip** for review watermarks and first-unseen anchors,
- an **anchor death card** when the old boundary dies,
- and a **reset-scope chip** that says whether the right fix is `jump nearest`, `refresh`, `relist`, `reopen live`, or `start fresh`.

This keeps exact cuts, later-change supplements, digest cards, and review watermarks useful while preserving one critical truth:
**a helpful old anchor is only helpful while it is still actually representable.**

## 5) Compact conclusion

VS Code, Ghostty, WezTerm, and Windows Terminal all prove that exact command/prompt navigation is worth stealing.
Their bounded-history docs simultaneously prove that old anchors can disappear.
Kubernetes, Dropbox, and Watchman prove that explicit cursor expiry/reset handling is normal, not exceptional.

So the next no-regret Schell seam is **anchor death cards, cursor expiry, and reset-scope humility** so preserved command cards, restored rooms, hidden-terminal returns, and watch lanes can say whether an old first-unseen or reviewed-through anchor still survives, what killed it when it does not, and what reset path is honestly required now.
