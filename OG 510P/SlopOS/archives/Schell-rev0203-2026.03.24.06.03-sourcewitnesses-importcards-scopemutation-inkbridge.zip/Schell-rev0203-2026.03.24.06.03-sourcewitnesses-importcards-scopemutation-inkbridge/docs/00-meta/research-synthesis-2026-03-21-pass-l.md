# Research synthesis, pass L (2026-03-21)

This pass focuses on one bounded seam:
**the next super-awesome thing Schell should steal is not just prettier output, but a better lifecycle for command chapters themselves — capture a chapter exactly, promote it into a reusable workflow only by explicit review, and make every open/reveal gesture travel through a visibly safe route ladder instead of semantic-history folklore.**

## 1) The command chapter is now a proven user-facing unit

Warp's Blocks make a strong product point: one command and its output can be treated as one atomic unit that supports copy-command, copy-output, jump-to-start, re-input, sharing, and bookmarking.
VS Code's shell integration and sticky scroll make the same point from another angle: command boundaries are worth preserving because operators want to navigate by command chapter rather than by raw scrollback.
WezTerm's shell integration also shows that once shells emit `OSC 7`/`OSC 133` information, the terminal can jump through earlier commands and select whole command outputs rather than guessing by heuristics.

The lesson Schell should steal is simple:
**command chapters are not just a history feature; they are the smallest durable unit from which navigation, reuse, and later workflow capture should grow.**

## 2) Save-as-workflow is compelling only when it remains a second step

Warp's workflow model is interesting precisely because workflows can be created from block actions and then edited as commands with arguments.
That is a very good steal, but only if Schell keeps one law intact:
**chapter capture, workflow promotion, parameter extraction, and execution are four different actions.**

A saved chapter should never silently become an executable alias.
A promoted workflow seed should preserve:
- source chapter,
- parameter suggestions,
- current-basis drift posture,
- and provenance.

That keeps “remember this useful command” separate from “run it again right now.”

## 3) Semantic history is brilliant, but it becomes dangerous when open semantics blur

iTerm2's Semantic History is a powerful precedent: it tracks current working directory per line and can use Cmd-Click to open files or even a configured URL target.
That is exactly the kind of convenience people love.
It is also exactly where a custom terminal can start pretending that visible text, cwd guesses, and handler choice are all one harmless convenience story.

xterm.js's link-handling guide points to the right correction: when a link was produced via OSC 8 and the destination may not be visible in the displayed text, the terminal should show the full URL on hover as a safety measure.
That is the right instinct for Schell too.

The steal here is not “copy Semantic History wholesale.”
It is:
- make command chapters and context visible,
- make full destinations inspectable before opening,
- and keep reveal/open/safe-open/copy-insert as distinct action names.

## 4) Prompt marks and click-aware prompts are useful because they strengthen chapters, not because they replace review

Contour's OSC 133 documentation, fish's terminal-compatibility notes, VS Code, and WezTerm all converge on the same idea:
prompt start/end, command start/end, cwd, and optional click-aware prompt hints can teach the terminal where the shell's boundaries are.

That does **not** mean Schell should let click gestures on the prompt become hidden editing or execution policy.
It means Schell should treat shell-emitted marks as the trustworthy anchor for:
- command chapter capture,
- prompt-local cursor movement,
- selection scoped to a chapter,
- and chapter-derived actions.

## 5) The stealable move: chapter capture + workflow harvest + safe-open ladder

The most interesting phase-zero luxury bundle now looks like this:

### Bundle candidate
1. **Exact command chapter capture**
   - copy command,
   - copy output,
   - jump to command start,
   - re-input into active input,
   - bookmark chapter.

2. **Explicit workflow harvest**
   - “save chapter as workflow seed,”
   - suggested parameter slots,
   - visible provenance,
   - review before rerun.

3. **Safe-open ladder**
   - inspect destination,
   - reveal exact object,
   - ordinary open,
   - safe-open,
   - copy destination,
   - insert destination,
   - attach destination to a help lane.

That bundle is exciting because it composes three already-proven ideas:
- shell-aware command chapters,
- workflow capture from real history,
- and safer link/object actions.

It is also decision-light because it still does **not** force:
- one final browser/open API,
- one final workflow marketplace,
- one final shell parser,
- or one final structured-command ontology.

## 6) What Schell should refuse while stealing these ideas

Do not steal these broken parts:
- semantic-history gestures that hide handler choice,
- save-as-workflow flows that bleach away source chapter or basis drift,
- hover that fetches or preconnects in secret,
- click-to-open that pretends displayed text and target URI are the same thing,
- or command chapters that become the only truth instead of one shell-witnessed truth surface.

## 7) The past lesson we must learn here

The past mistake is always the same shape:
what begins as humane convenience slowly turns into a hidden second authority plane.

For shells and terminals, that hidden plane usually appears as:
- heuristically reconstructed command boundaries,
- semantic-history path guessing,
- implicit handler probing,
- remembered recipes that lost provenance,
- or “open” gestures that overclaim what happened.

Schell should learn the opposite lesson early:
**capture exactly, promote explicitly, open humbly, and keep every stronger move separately named.**

## 8) Good near-term proof slice

A strong specimen set would show:
- one command chapter with exact marks and sticky recall,
- one chapter promoted into a workflow seed with suggested parameters,
- one seed landing in active input instead of executing,
- one inferred versus explicit destination hover card that reveals the full target,
- one reveal/open/safe-open split,
- and one launch receipt that says only what Schell can honestly know.

That would already feel materially better than ordinary shell+terminal folklore.

## Source pointers

- Warp Blocks: https://docs.warp.dev/terminal/blocks
- Warp Workflows: https://docs.warp.dev/knowledge-and-collaboration/warp-drive/workflows
- VS Code shell integration: https://code.visualstudio.com/docs/terminal/shell-integration
- WezTerm shell integration: https://wezterm.org/shell-integration.html
- Contour OSC 133 documentation: https://contour-terminal.org/vt-extensions/osc-133-shell-integration/
- fish terminal compatibility / OSC 133 notes: https://fishshell.com/docs/4.1/terminal-compatibility.html
- iTerm2 Semantic History: https://iterm2.com/documentation-preferences-profiles-advanced.html
- xterm.js link handling and hover URL safety: https://xtermjs.org/docs/guides/link-handling/
