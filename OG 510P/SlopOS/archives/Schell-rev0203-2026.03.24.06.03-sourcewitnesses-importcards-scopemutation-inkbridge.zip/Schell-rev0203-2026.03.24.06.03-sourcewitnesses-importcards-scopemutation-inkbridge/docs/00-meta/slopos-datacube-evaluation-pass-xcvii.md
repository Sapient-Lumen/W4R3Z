# SlopOS datacube evaluation, pass XCVII (2026-03-22)

This pass evaluates one narrower question against the current SlopOS archive:
**what does the companion already teach Schell about completion systems, dynamic candidate generation, and insertion honesty?**

The answer is stronger than it first appears.
**SlopOS is already pressuring Schell to treat completion as observational discovery plus explicit insertion, not as an authority-bearing parser shortcut or a hidden auto-repair path.**

## 1) The companion already rewards explicit stage boundaries over convenience folklore

Across the archive, SlopOS keeps preferring explicit stage-local contracts, explicit execution selectors, explicit imported evidence, and explicit local acceptance.
That matters directly here.
A completion candidate may be useful, but the companion's design instinct says not to flatten these nearby truths:
- discovering a possible value,
- inserting a value into the prompt or slot,
- binding exact argv or an exact exec pack,
- and executing the reviewed action.

For Schell this means completion should become a named witness family with source and insertion posture, not just a feeling that tab “knew what you meant.”

## 2) Learn-mode posture already argues against completion becoming auto-repair

The companion's capshell learn-mode posture is explicit: learn mode is observational only, suggestions are non-authoritative, stage-local, binding-aware, and must not auto-edit, auto-approve, or auto-rerun.
That maps cleanly onto completion.

Completion may still offer:
- candidate values,
- narrower slots,
- likely paths,
- or workflow parameter fills.

But the companion pressures Schell not to let those offers become hidden edits to the execution artifact or hidden reruns under a wider guess.

## 3) Command-string and word-expansion posture warn against completion quietly becoming parsing

The companion already refuses free command-string convenience as a normal execution artifact, and it refuses ambient shell-style word expansion in the integrated capshell front end.
That matters because completion is one of the easiest places to sneak parsing folklore back in.

If a completion menu shows a label, performs quoting transforms, bridges from a foreign shell, or inserts a path-like value, Schell still needs to keep distinct:
- the displayed candidate,
- the inserted bytes or slot value,
- the parser/evaluation lane that will later consume it,
- and the reviewed execution artifact.

That is already the companion's preferred shape elsewhere: nearby convenience must not blur exact binding truth.

## 4) Imported evidence and local acceptance map cleanly onto bridged completers

SlopOS repeatedly prefers imported evidence staying distinct from local acceptance.
That philosophy maps directly onto bridged completion.
A shell may import candidates from:
- a foreign shell helper,
- an external command,
- a cached source,
- or a workflow pack.

But Schell should still keep separate:
- what was proposed,
- where it came from,
- how it was translated,
- and what local insertion or later review posture applies.

That is the same discipline the companion uses elsewhere: imported structure is useful, but stronger local meaning still requires a separate local step.

## 5) Explain posture sharpens the display/value split

The companion's explain posture insists that canonical shell-owned summaries remain distinct from nearby prose, decoration, or observational artifacts.
That makes completion menus easier to judge.
Descriptions, annotations, source chips, warnings, and icons are all worth stealing — but they should remain annotations.
The exact inserted value is a separate truth.

For Schell this suggests a very companion-compatible move:
- candidate label,
- candidate annotation,
- inserted value,
- and later reviewed action

should stay separately named.

## 6) The companion also sharpens prompt-path humility

SlopOS already dislikes hidden ambient work and hidden fallback.
That pressure applies here too.
A dynamic completer that runs shell code, calls a command, hits a cache, or bridges to another shell is not inherently bad.
The problem is only when that cost or side-effect posture vanishes into a fake “free” tab key.

So the companion points Schell toward:
- explicit generator family,
- explicit side-effect posture,
- explicit freshness or cache posture,
- and explicit fallback posture.

## 7) Compact conclusion

The strongest companion-compatible move in this pass is:
**treat completion as witnessed discovery plus explicit insertion, and keep it weaker than exact binding and reviewed execution truth.**

That lets Schell steal rich completion comfort while still deferring:
- the final completion ABI,
- the final parser/editor stack,
- the final caching/bridge topology,
- and the final workflow parameter substrate.
