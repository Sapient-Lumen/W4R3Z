# Research synthesis, pass LXXXIX (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should make rendering luxurious — tables, grids, markdown, diffs, hyperlinks, viewers, and even inline graphics — while keeping the rendered view visibly weaker than the underlying value, handle, or command chapter and clearly separate from execution truth.**

This seam matters because current shells and terminals are converging on a very tempting pattern:
- values become pretty tables,
- docs become markdown cards,
- diffs become hyperlink-rich viewers,
- file previews become syntax-colored paged surfaces,
- and terminals can now display explicit links or even inline images.

That is wonderful.
It is also exactly how display starts impersonating truth if the system does not name the layers.

## 1) PowerShell still teaches the clearest lesson: display is not the object

PowerShell’s formatting docs remain unusually helpful here.
Formatting files determine what is displayed and how it is displayed, but they do **not** determine what object members exist in the pipeline.
The pipeline can then send those objects onward to formatting, export, or output cmdlets.

That is a very strong inheritance line for Schell.
A rendered table or list should be thought of as a **view adapter**, not as the thing the shell fundamentally has.

## 2) Nushell sharpens the same lesson from the structured-data direction

Nushell’s docs make the same separation even more explicit.
The `table` command is used to render structured data such as tables, lists, records, and ranges, and the result is a `string` stream.
Then `explore` acts as a table pager, much like `less` does for text.

That is exactly the design pressure Schell should import.
A delightful shell+terminal should be able to give users multiple beautiful renderings of the same value while keeping the subject/value ground intact and inspectable.

## 3) The ecosystem keeps proving that viewers are adapters, not durable basis

Other current tools reinforce the same pattern from different angles.
`bat` automatically pages when interactive, but falls back to plain file contents for non-interactive output and even recommends `--paging=never` when aliasing it to `cat`.
`Glow` renders markdown in the CLI as a reader, not as a new execution substrate.
`delta` adds hyperlinks to file paths, line numbers, and commit hashes when the terminal supports them.

The lesson is not merely “pretty output is nice.”
It is:
**pretty output works best when tools preserve a plainer fallback and do not confuse the render layer with the underlying subject.**

## 4) Terminal link and image support keeps getting better, but capability is still local and fragmented

The terminal side of the ecosystem is equally instructive.
`xterm.js` explicitly distinguishes between links emitted using OSC 8 and links recognized implicitly by pattern matching.
kitty’s graphics protocol is designed for raster graphics integrated with text, while not requiring the terminal to understand image formats.
iTerm2’s inline-images protocol can display images and even facilitate file transfers over transports like SSH or telnet.

These are excellent ideas to steal.
But they also prove why Schell should not flatten “looks rich here” into a portable truth claim.
Hyperlinks, image views, and pixel renderers are still highly adapter- and terminal-dependent.

## 5) SlopOS sharpens the import: keep bytes/handles/types stronger than pretty views

The companion archive keeps rewarding the same posture from the system-design side.
Canonical bytes matter.
Ordering and evidence matter.
Typed transfer descriptors, document handles, and intent messages stay explicit.
Nothing in SlopOS wants a renderer-local flourish to outrank the exact typed subject.

That pushes Schell toward:
- **render-ground cards** for why this view exists,
- **subject cards** for what exact value/handle/output it came from,
- **capability badges** for why it renders here,
- **fallback badges** for what survives elsewhere,
- and **render receipts** for support export and replay.

## 6) What Schell should now do

This pass suggests a compact answer:
- keep **render ground** separate from value ground and handle ground,
- treat tables, grids, markdown views, hyperlink views, and image views as **adapters**,
- keep a **degrade ladder** from rich render → text render → plain text → subject-only stub,
- make stronger actions like open/export/share explicitly stronger than render,
- and preserve one text-safe durable basis for every rich rendering family.

## 7) Super-awesome specimen ideas that still stay decision-light

A first specimen set could stay small but teach a lot:
1. one structured value shown as raw inspect, table, and grid without changing its subject card;
2. one markdown object shown as plain text, rendered markdown, and stronger open actions;
3. one diff chapter with hyperlink-rich rendering that still preserves exact file/line basis;
4. one pretty file preview that visibly downgrades to plain contents when piped or headless;
5. one inline image/media card that carries a capability badge and a text-safe stub fallback;
6. one render-ground why-card that explains which adapter won;
7. and one support/export receipt that preserves subject basis plus render receipt rather than only the pretty view.

## 8) Decisions intentionally kept open

This pass does **not** freeze:
- one final renderer registry,
- one final markdown/diff/image/table viewer stack,
- one final hyperlink or graphics protocol mix,
- one final render-cache/export format,
- or one final remote/mux downgrade policy.

The no-regret move is smaller and stronger:
**give Schell render-ground cards, view adapters, capability badges, fallback ladders, and subject-preserving receipts so rich output becomes dramatically nicer without turning pretty rendering into hidden shell authority.**
