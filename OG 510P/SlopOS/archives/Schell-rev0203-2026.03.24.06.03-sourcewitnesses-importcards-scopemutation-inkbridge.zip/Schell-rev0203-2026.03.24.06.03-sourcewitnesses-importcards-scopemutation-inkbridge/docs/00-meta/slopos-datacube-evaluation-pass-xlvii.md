# SlopOS datacube evaluation, pass XLVII

This pass keeps one bounded thesis in focus:
**SlopOS already teaches the right posture for a fragmented terminal world — open protocols, explicit adapters, exact execution truth, and no hidden widening through compatibility shims. Schell should import that discipline so advanced terminal features ride on explicit capability witnesses instead of quietly becoming part of core shell correctness.**

That is a particularly good ratchet while SlopOS is still design-phase too.
It lets Schell harvest a lot of terminal brilliance without freezing one renderer, one transport, one escape dialect, or one mux story too early.

## 1) D-APIEVO already says adapters beat implicit downgrade folklore

RFC-0071 is one of the strongest direct pressures for this pass.
It prefers open protocols, expects interface evolution, and makes adapters/translators first-class compatibility components rather than accidental hidden behavior.
It also says adapters should be auditable and should not silently widen authority.

That maps perfectly onto shell+terminal capability posture.
SSH wrappers, mux passthrough, platform shims, and terminal-profile fallbacks should behave like named adapters, not like invisible correctness assumptions.

## 2) D-CAPSHELL already refuses hidden terminal/session overreach

RFC-0115 is equally useful here.
It keeps exact execution truth stronger than nearby convenience, and it explicitly declines to treat integrated terminal/session behavior as automatically part of the execution contract.
That means terminal ergonomics can grow, but they should not be allowed to rewrite what the shell claims it actually knows.

This is exactly the right discipline for capability-rich terminal design.
Prompt marking, click-to-move, graphics, richer keyboard input, or smart wrappers may be great, but they stay adjacent to exact reviewed execution rather than redefining it.

## 3) SlopOS’s current datacube keeps reinforcing explicit route and transfer posture

Across recent SlopOS surfaces, one pattern keeps winning:
- explicit transfer instead of ambient carry,
- exact handoff identity instead of “close enough” convenience,
- historical restore material weaker than live truth,
- and second workflows kept separately named.

Capability posture in Schell should import exactly that.
A session should know whether a luxury is:
- native,
- shell-witnessed,
- adapted,
- tunneled through a mux or remote hop,
- historical/restored,
- or unavailable.

## 4) The right import is a capability witness family, not a protocol freeze

Schell does not need to decide now between OSC dialects, side channels, custom PTY brokers, or platform-specific renderer APIs.
The right import from SlopOS is much smaller:
- a **capability witness** for current terminal/session posture,
- explicit **adapter witnesses** when SSH, mux, or platform shims are in the path,
- one distinction between **portable baseline truth** and **luxury enhancement profiles**,
- and one strong rule that transcripts and plain terminals still tell the truth when every luxury disappears.

## 5) The narrow high-value consequence for Schell

The best consequence of this pass is very practical.
Schell should be able to say, in effect:
- this chapter is fully portable text truth,
- this prompt lease currently has click-to-move because prompt marking is live,
- this input profile has richer keyboard events because the terminal negotiated them,
- this media lane is local-only because a mux hop weakens it,
- and this remote shell is running with fallback terminfo, so stronger luxuries are downgraded.

That is exactly the kind of honesty that keeps a super-awesome shell+terminal from regrowing the oldest terminal lie: pretending that whatever happens to work on one machine, in one renderer, through one transport, must therefore be the new baseline truth everywhere.
