# Research synthesis — 2026-03-23 — pass CLXIV

This pass keeps the archive decision-light while isolating a high-value luxury cluster:
**semantic marks, command chapters, searchable recall, inspector overlays, and attach-for-help bundles are worth stealing, but they should stay visibly weaker than exact reviewed action, exact argv/ground witnesses, and shell-owned receipts until provenance is strong.**

The current outside convergence is real.
Modern terminals and shell integrations increasingly agree that prompt, command, and output boundaries deserve first-class treatment.
But they still disagree on provenance, transport, storage, and what stronger actions history rows should unlock.
That makes this a good Schell seam.

## 1) Current terminals are converging on semantic regions, not just plain scrollback

WezTerm documents OSC 133 / FinalTerm-style semantic zones and can select text by semantic zone rather than only raw coordinates.
Ghostty documents shell integration for multiple shells and prompt-aware navigation features like jumping between prompts and opening a terminal in the same working directory.
iTerm2 shell integration exposes marks, command/output selection, return-code views, and recent-directory browsing.
VS Code terminal shell integration adds command decorations, overview-ruler markers, exit-code/status decorations, and command-context attachment into chat/help flows. citeturn815812view3turn815812view0turn152028view1turn815812view5turn815812view7

That means the “command chapter” idea is no longer niche.
It is the clearest place where modern terminal UX is becoming obviously better.

## 2) Provenance is still the hard part

The same ecosystem also shows that visible marks do not solve provenance by themselves.
iTerm2 treats semantic escapes as control sequences that can be emitted by integration helpers.
VS Code goes further and records command-line confidence/trust posture, a shell-integration nonce path, and cases where exit data may be absent or unreliable. citeturn152028view0turn815812view6

That is the load-bearing lesson.
The shell+terminal should enjoy marked chapters without letting any mark automatically count as shell-authenticated truth.

## 3) The best steal is not “blocks”; it is exact chapter objects with honest grades

The convergent luxury is not literally one visual style.
It is the object underneath:
- a command boundary,
- associated output region,
- outcome/decorations,
- current footing,
- and fast recall/navigation.

So Schell should preserve a compact chapter object with explicit provenance grade instead of copying one vendor’s block UI wholesale.
That keeps the door open for transcript-safe text, richer local renderers, degraded relays, and future transport profiles.

## 4) Search, hints, and open-actions prove that typed ladders beat single smart-clicks

kitty shows how much delight operators get from hints for URLs, paths, and line-number paths, plus customizable open actions.
WezTerm and iTerm2 show the complementary value of command/output selection and jump-to-mark behavior. citeturn815812view19turn815812view20turn815812view4turn152028view1

The strongest Schell lesson is not “make clicks smarter.”
It is “route visible objects through typed ladders.”
Reveal, inspect, insert, attach, open, safe-open, and execute should stay separately named.
That gives luxury without hidden policy.

## 5) Attach-for-help is already useful, but it needs better exactness

VS Code now supports attaching terminal command context to chat, including command line, captured output, and exit code.
That is directionally excellent because it turns troubleshooting into an exact context move rather than copy/paste folklore. citeturn815812view7

Schell can steal that move while doing it more carefully:
attach an exact chapter bundle with outcome witness, cwd/env/peer footing, provenance grade, and redaction posture.
That is already valuable even before deciding a final assistant lane or automation story.

## 6) Other shells keep reinforcing adjacent lessons

Nushell keeps pushing parse-time help and richer external-command metadata, which supports the idea that command understanding should start before execution and stay structured where possible.
fish keeps exposing pipeline-status detail and signal-name improvements, reinforcing that chapter outcome should remain richer than one scalar. xonsh’s sqlite history pressure suggests that serious chapter search will likely need a fast structured store eventually, but that is still a later implementation decision. citeturn815812view8turn815812view10turn815812view11turn815812view12

## 7) The concrete no-regret move

Schell should now prefer a bounded five-part luxury cluster:
- shell-authenticated command chapters,
- weaker inferred chapters when transport degrades,
- provenance-graded semantic marks,
- inspector overlays with exact footing/outcome links,
- and attach-for-help bundles plus typed action ladders.

That cluster steals the best current ideas without choosing a final history database, one terminal protocol, one plugin runtime, or one universal smart-click/open policy.
