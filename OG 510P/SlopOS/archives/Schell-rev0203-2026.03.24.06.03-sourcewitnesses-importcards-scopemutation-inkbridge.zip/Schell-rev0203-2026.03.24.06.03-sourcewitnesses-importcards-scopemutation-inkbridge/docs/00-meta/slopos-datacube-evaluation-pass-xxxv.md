# SlopOS datacube evaluation, pass XXXV

This pass keeps one bounded thesis in focus:
**SlopOS keeps warning that preview is a separate workflow, that risky rendering should stay explicit and metadata-safe, and that merely viewing something should not quietly create durable host-side residue. Schell should import that lesson directly before inline media and rich preview make the shell+terminal flattering but dishonest.**

This is another good import point because SlopOS is still design-phase too.
The lesson is strong without forcing a renderer stack decision.

## 1) SlopOS already treats preview as weaker than open and weaker than durable identity

The OpenURI preview-metadata boundary says generic launch must not quietly become title/icon/image unfurl or metadata-card truth.
The OpenURI materialization boundary says generic launch must not silently become durable local bytes or a new object identity.

That maps cleanly into Schell.
A terminal should not act as though:
- visible bytes,
- inline pixels,
- and durable local artifacts

are all the same thing.
They are not.

## 2) Viewer residue is one of the best SlopOS lessons for terminal design

The safe-open viewer-residue boundary is especially valuable here.
It says preview/open of a risky document must not by itself create durable recent-doc, reopen, thumbnail, index, autosave, or crash-recovery residue outside the disposable.
That is a brilliant shell+terminal lesson.

A custom terminal that gains inline media could otherwise drift into exactly this failure mode:
- rendered thumbnails become a second recents plane,
- restored preview caches look live,
- crash recovery keeps bytes the user never explicitly kept,
- or hover/search quietly generate durable derived artifacts.

Schell should import the refusal before that happens.

## 3) Metadata-safe result rendering is directly relevant to terminal discovery surfaces

The quarantined result-preview boundary says that even when the exact quarantined object matched, result lists/cards stay metadata-safe.
Selection, hover, focus, top-match UI, and preview panes must not auto-render content bytes.
If richer preview is desired, the system must cross an explicit exact-handle review/open seam.

That is almost a perfect direct import for Schell.
The terminal is full of result-like surfaces now:
- command decks,
- history palettes,
- chapter search,
- object cards,
- quick-open,
- and workflow/result rows.

For risky or uncertain objects, those surfaces should not auto-turn into image/PDF/media preview just because the terminal can render it.

## 4) Document/transfer posture reinforces object-first thinking

SlopOS keeps documents and transfers explicit through portal/document-handle posture instead of pretending a viewed thing has automatically become a durable host object.
That suggests a clean Schell rule:
**inline render should hang off an exact object ref or bounded output witness, not the other way around.**

In other words:
- the object or output witness is primary,
- the renderer-local preview is secondary,
- export/share/materialize remain separate verbs,
- and restored preview is weaker than fresh object truth.

## 5) The strongest import is small and practical

Schell does not need a giant media subsystem to learn from SlopOS here.
It needs:
- one **media witness** or equivalent object-first render packet,
- one **viewlet** posture for inline/local rendering,
- one **text-safe transcript stub** when graphics are unavailable,
- one **residue posture** that can say transient-local / restored / historical / unknown,
- and one rule that risky preview stays explicit and exact-handle-targeted.

That is enough to become much more powerful without deciding:
- the final graphics protocol,
- the final cache model,
- the final media viewer sandbox,
- or the final remote rendering story.

## 6) This is a direct path to “super awesome” without ambient magic

A shell+terminal becomes super awesome when visual outputs are:
- easier to inspect because they are tied to exact objects,
- faster to revisit because local render caches can exist,
- safer because preview is still weaker than open or export,
- and less misleading because restored pixels are visibly historical rather than silently current.

That is exactly the kind of ambitious but decision-light move Schell should prefer while both datacubes remain in design phase.
