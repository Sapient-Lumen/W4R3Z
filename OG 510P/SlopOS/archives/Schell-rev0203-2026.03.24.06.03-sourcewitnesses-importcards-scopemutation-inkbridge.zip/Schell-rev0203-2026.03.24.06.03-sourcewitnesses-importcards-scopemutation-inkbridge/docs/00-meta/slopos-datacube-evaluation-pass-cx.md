# SlopOS datacube evaluation, pass CX (2026-03-22)

This pass evaluates one narrower question against the current SlopOS archive:
**what does the companion already teach Schell about drag/drop, file-bearing ingress, transfer sessions, object import, host↔guest humility, and the danger of flattening dropped files into prompt-ready text?**

The answer is sharper than it first appears:
**the companion wants file-bearing ingress to remain explicit, sink-granted, object-aware, and weaker than reviewed transfer meaning.**

## 1) D-PLUMB already rejects the “drop equals ambient access” myth

The transfer/document posture in the SlopOS archive keeps repeating the same moral shape:
- copy publishes an offer rather than a cross-component grant,
- paste/drop/share is the sink action that grants delivery,
- transfer is short-lived and auto-cleared by default,
- document access rides on explicit portal/export seams,
- and Phase 1 refuses ambient clipboard readers/history and other helper mythology.

That maps almost perfectly onto drag/drop design for Schell.
A dropped file should not silently become a trusted shell path just because an OS helper made it easy to hand over a pathname-like representation.

## 2) The microVM posture is even stricter in exactly the right way

`microvm-clipboard-dragdrop-posture-v0.md` keeps host↔guest clipboard and drag/drop integration explicitly non-portable and refuses to let desktop-helper convenience become the reviewed transfer plane.
That is a direct pressure source for Schell.
Remote panes, nested terminals, VM helpers, mux bridges, and portal exports all create the same temptation: report “drop worked” without naming the bridge or the transfer contract.

The companion-compatible answer is obvious:
- local drop,
- portal-backed file offer,
- path-translated insert,
- remote upload proposal,
- and host↔guest helper transfer
should stay separately named instead of compressing into one drag/drop success badge.

## 3) SlopOS wants fresh object identity, not path folklore

Across document/transfer/import seams, the companion repeatedly favors fresh imported identity over ambient path mythology.
That matches Schell's earlier ingress work and sharpens it further for dropped files.
For file-bearing drop, the SlopOS-compatible first move is usually:
- import as fresh local object,
- attach to a pending reviewed action,
- safe-open / inspect,
- or explicitly insert a transformed path string when that is the real intent.

That keeps file-like ingress on an import/document seam instead of laundering it into shell text.

## 4) Stronger drop outcomes should be explicit promotions

The companion's transfer posture also gives Schell the right rule for flashy drop features.
A remote upload helper or writable file export should not be treated as an ordinary drop result.
Those are stronger outcomes with stronger leases and stronger review needs.

So the SlopOS-compatible move is to keep:
- local insert,
- local import,
- attach to reviewed action,
- offer remote upload,
- start reviewed transfer,
- writable export
separately named.

That is the same moral structure as D-PLUMB's offer/grant discipline and the companion's refusal to let ambient desktop helper channels become the authority plane.

## 5) The companion-compatible answer stays smaller than a final drag/drop subsystem

Schell does **not** need to choose:
- one final Wayland/X11/macOS/Windows drag/drop backend,
- one final document portal treaty,
- one final remote-upload engine,
- one final file-object model,
- or one final MIME taxonomy

to stay aligned with SlopOS.

It only needs a few bounded rules:

### A) Dropped text, dropped file offers, translated insertion, and stronger transfer proposals stay separately named
Do not let them share one flattering drag/drop story.

### B) File-bearing drop prefers import/attach/open-untrusted over blind path injection
Keep document-like ingress on an explicit object seam.

### C) Translation and quoting stay visible as transforms
A transformed path string is not the same truth as the offered object.

### D) Remote upload and writable export are explicit promotions
Do not let drag convenience silently widen transfer authority.

### E) Transcript truth survives the fancy UI
A log should still be able to say what kind of drop occurred and what stronger action, if any, was granted.

## 6) Compact conclusion

The SlopOS-compatible answer is not “build a giant drag/drop shell.”
It is:
**make dropped text, dropped file offers, path translation/quoting, and stronger transfer promotions explicit witnesses while keeping desktop-helper convenience, remote bridges, and upload shortcuts clearly weaker than reviewed import and transfer authority.**

That is a strong design-phase-safe move because it improves a very common shell failure surface right away while leaving the final drag/drop plumbing, import model, and transfer architecture open.
