# SlopOS datacube evaluation, pass XL

This pass keeps one bounded thesis in focus:
**SlopOS already treats accessibility and automation as leased, audited, scope-separated capabilities. Schell should import that discipline so its shell+terminal can become much more accessible without letting assistive surfaces quietly become ambient UI hooks, hidden injection paths, or a second stale truth plane.**

This is a strong ratchet while SlopOS is still design-phase too.
It preserves optionality.
It also connects directly to a set of modern product pressures that are getting stronger right now.

## 1) D-UIAUT is almost a direct warning label for shell+terminal design

RFC-0099 says modern accessibility and automation APIs are often effectively global hooks.
It insists that observation and injection are different rights, that sessions should be portal-mediated and leased, and that active sessions should imply shell-driven indicators rather than requester-controlled UI.

That maps into Schell almost directly.
A custom shell+terminal will be tempted to grow:
- screen review helpers,
- alternate navigation,
- focused object inspection,
- or even cross-app assistive bridges.

SlopOS’s lesson is that these must not collapse into one generic “accessibility mode.”
Observation is one thing.
Navigation is another.
Injection is stronger.
Cross-app automation is stronger still.

## 2) SlopOS keeps capability shape smaller than provider-local luxury

The datacube repeatedly prefers one small portable seam plus provider-local projection.
That fits accessibility beautifully.
Schell does not need to freeze a universal accessibility API at the center of the archive.
It needs one shell-known assistive witness family and a refusal to let renderer-local accessibility tricks redefine the portable meaning.

That keeps the portable center small:
- exact chapters,
- exact object-card fields,
- exact progress milestones,
- exact review-needed state,
- exact freshness posture.

Local terminals, editors, or OS bridges can then project those into their own assistive ecosystems.

## 3) Historical honesty matters just as much for accessible mirrors

SlopOS repeatedly refuses to let issued descriptors or historical artifacts impersonate current live truth.
Schell should import that into accessibility too.
An accessible mirror, exported summary, cached accessibility tree, or restored chapter browser can help enormously.
It is still weaker than current shell truth unless refreshed.

That is especially important because assistive users may rely on the alternate surface very heavily.
If it goes stale silently, the error is serious.

## 4) Shell-driven indicators matter here too

RFC-0099 says active observation or injection sessions imply shell-driven indicators.
That is a very good fit for Schell.
If stronger assistive rights are active, they should not be signaled only by the requesting helper itself.
The shell+terminal should have its own indicator or receipt posture so the operator can tell:
- observe-only assistive bridge active,
- injection-capable assistive bridge active,
- historical accessible cache only,
- or externalized review surface open.

This is the same anti-spoof instinct already seen elsewhere in the archive.

## 5) D-CAPSHELL adds another useful pressure: learn mode is not ambient authority

The capability-safe shell RFC insists that automation stays explicit, capability-pure, and learnable without falling back to hidden authority.
That matters here because accessibility often arrives wrapped in “helpful automation” promises.
The SlopOS import is:
Schell can absolutely support assistive review, narration, and alternate surfaces, but those should not become backdoor policy exceptions that let scripts or helpers inherit broad UI control simply because they wear an accessibility label.

## 6) A shell+terminal-specific import emerges cleanly

The strongest import is small and practical:
- make accessibility **shell-known** where possible,
- keep **observe / review / navigate / inject** explicitly distinct,
- mark stronger assistive sessions through shell-driven indicators and receipts,
- keep restored or exported accessible surfaces visibly historical until refreshed,
- and let local renderer/OS integrations remain luxuries rather than portable truth.

That is enough to make Schell substantially better without freezing its bridge architecture.

## 7) The no-regret move

Schell does not need to choose one accessibility API, one braille transport, or one automation lease UX right now.
It needs:
- one small **assistive witness** family,
- one explicit split between **accessibility observation** and **automation/injection**,
- one **historical-freshness posture** for accessible mirrors and exports,
- and one refusal to let accessible review surfaces silently widen into ambient cross-app control.

That is a clean SlopOS import, and it is exactly the kind of careful, decision-light move this archive should keep preferring.
