# Research synthesis, pass XLVII (2026-03-21)

This pass focuses on one bounded seam that Schell did not yet give its own surface:
**the current terminal ecosystem keeps proving that rich capability is real, but also fragmented. Shell integration, prompt marks, graphics, keyboard upgrades, terminfo, mux passthrough, SSH fallbacks, and platform quirks are different capability stories, and Schell should stop letting them borrow one fuzzy idea of “the terminal supports it.”**

## 1) The old lesson still wins: luxuries should not become hidden correctness

Modern terminal docs are surprisingly honest about fragmentation.
Ghostty ships its own terminfo, uses `xterm-ghostty`, and explicitly says the `xterm` prefix exists because too many applications string-search `TERM` and break otherwise.
That is a strong reminder that the ecosystem is still compatibility-driven, not purity-driven.

The lesson for Schell is straightforward:
**terminal luxuries are worth stealing, but they must not become hidden prerequisites for shell truth.**

## 2) Shell integration is valuable, but it is not universal truth

VS Code’s terminal shell integration is useful precisely because it gives the terminal more exact facts: working directory detection, command detection, decorations, and navigation.
Ghostty does something similar and lists concrete features that depend on shell integration or native prompt marking, while also saying unsupported shells still work but some features may be unavailable.

That is the right shape for Schell.
Prompt marks, cwd witnesses, and command chapters should unlock better UX, but absence of those features should degrade into weaker local luxury, not broken core behavior.

## 3) Capability upgrades should be explicit and queryable

kitty’s keyboard protocol is one of the clearest current examples of doing this well.
It is backward compatible, applications opt in to more advanced behavior, and support can be queried rather than guessed.
That is much better than folklore or terminal-brand heuristics.

The import for Schell is strong:
**advanced terminal behavior should look like an enhancement profile with detection, not like ambient magic that programs simply hope is there.**

## 4) Remote hops and multiplexers keep proving that degrade paths matter

Ghostty’s SSH features are explicitly opt-in because they override `ssh` and carry risk; they either copy terminfo or fall back to `xterm-256color`.
kitty’s docs keep rediscovering the same issue for SSH and `sudo`.
WezTerm’s docs add another useful warning: some features require local terminfo installation, Windows ConPTY strips some escapes, and tmux passthrough can preserve some sequences while still leaving redraw/history behavior imperfect for images.

That is exactly the historical lesson we must keep learning.
Remote hops, sudo, muxes, and host terminal layers are not transparent pipes.
A shell+terminal that wants to be super awesome must stay honest about where enhancement survives, where it tunnels, and where it degrades.

## 5) The ecosystem is converging on profiles, not one universal protocol win

There is real convergence in places: OSC 133-style prompt semantics, shell integration, richer keyboard reporting, graphics protocols, and shell-known working-directory/context signals.
But the official docs still show a mixed world of terminfo packaging, wrapper features, passthrough shims, platform limitations, and optional injection.

That suggests a very decision-light Schell move:
- keep a **portable baseline** that preserves review/execution/transcript truth with minimal assumptions,
- add **capability witnesses** for richer local features,
- add **profile budgets** for optional luxuries,
- and show **downgrade posture** when a remote, mux, or platform hop weakens the surface.

## 6) The nifty idea worth stealing is not any one protocol, but explicit capability posture

A genuinely brilliant move for Schell would be a compact operator-visible capability story such as:
- baseline text/truth profile,
- shell-integration profile,
- input-upgrade profile,
- media/profile enhancement lane,
- remote/mux downgrade badges,
- and transcript-safe fallbacks for every stronger surface.

That would let Schell feel unusually polished locally while still teaching the operator exactly which luxuries are active, which are borrowed through adapters, and which are unavailable right now.

## 7) The no-regret Schell move is capability witnesses plus degrade honesty

Schell does not need to choose one final terminal protocol now.
It needs something smaller and better:
- **capability witnesses** for what the shell/terminal pair can actually rely on in this session,
- **profile budgets** that separate baseline truth from richer local upgrades,
- **adapter posture** for SSH/mux/platform tunnels,
- and **degrade honesty** so the system never silently confuses “this renderer can do it here” with “the shell can assume it everywhere.”

That would make the custom shell+terminal meaningfully more portable, more honest, and more super awesome at the same time.
