# Research synthesis, pass CIII (2026-03-22)

This pass keeps one fresh rule in focus:
**a shell+terminal gets much more trustworthy when composition/preedit state, committed text, and grapheme/width posture are treated as different truth families instead of one giant “typing happened” blur.**

The current ecosystem keeps pointing in the same direction.
WezTerm explicitly documents IME and dead-key behavior, including platform-specific composition rules and the fact that some IMEs own dead-key processing when enabled.
It also exposes `composition_status()` and a compose-cursor color, which is a useful signal that composition state itself has become a first-class UI fact.
Windows Terminal spent real effort on an IME integration rewrite so composition can inherit TUI colors, richer underline styles, and clause-cursor behavior inside text apps.
Ghostty's recent releases keep sanding this seam too, from IME-widget support to more readable underlined preedit text and Unicode/grapheme correctness fixes.
Windows Terminal then had to add grapheme-cluster support and later a compatibility switch for alternative text measurement modes, which is a clean reminder that display width is still not one universal law.

## 1) Input transport was only part of the story

The previous key-transport pass established that richer key reporting, layout-aware matching, and negotiated input modes should remain witnessed.
This pass adds the next layer:
**after key transport, there is still composition.**

Some keys become dead-key hold state.
Some text appears first as preedit.
Some candidate windows are owned by the OS or IME.
Some commits replace a whole preedit clause at once.
And some user-perceived characters span multiple code points or different width models.

That means Schell still needs to distinguish:
- key/event transport,
- composition/preedit state,
- committed buffer text,
- measured display width,
- and later parse/argv/review truth.

## 2) Official docs now make composition visibility a stealable luxury

WezTerm's `composition_status()` is especially instructive because it exposes the current dead-key or IME composition text as UI-observable state rather than hiding it as mystical platform behavior.
That suggests a good Schell import:
composition deserves a witness instead of disappearing into prompt folklore.

Windows Terminal's 1.21 IME work makes the same point from another angle.
The work was not about “support more languages” in the abstract.
It was about visual honesty inside TUIs: use the app's colors, use richer underline styles, and make clause movement readable.
Ghostty's shift from inverted preedit to underlined preedit points in the same direction.

These are worth stealing directly.
But the important synthesis is not “preedit is now the truth.”
It is:
**composition can be made delightful, visible, and richly rendered while still remaining weaker than committed shell/editor text.**

## 3) Grapheme support proves that visible text and exact committed text are different seams

Windows Terminal's grapheme-cluster work is a particularly useful reminder.
Terminals now have to care about user-perceived characters rather than naïve code-point counting.
But the compatibility setting added later — letting users choose `wcswidth` or Windows Console style measurement instead of grapheme clusters — shows that display measurement is still a compatibility seam, not a solved universal truth.

That is a great lesson for Schell.
The shell+terminal should absolutely handle graphemes well.
But it should also keep the difference visible between:
- what the local renderer measured,
- what the user perceives as one character,
- and what exact text committed into the input buffer.

## 4) Dead keys and AltGr still prove that “a keypress” is not a stable object

WezTerm's keyboard docs remain valuable here because they make platform behavior explicit:
left vs right Option may differ, dead keys may hold state, and when `use_ime=true` the IME may handle dead-key processing implicitly.
That suggests a no-regret rule for Schell:
**dead-key and layout behavior should be confessed as part of composition posture, not flattened into a generic shortcut or text-entry myth.**

## 5) The SlopOS-friendly answer is smaller than inventing a whole IME framework

This pass suggests a bounded answer that fits the companion archive well.
Schell does not need to design a giant universal text-input subsystem yet.
It only needs to name a few important differences clearly.

### Must-learn failure families
- visible preedit silently becoming committed shell text,
- candidate windows silently becoming shell-owned proof,
- grapheme/width policy silently becoming exact parse truth,
- dead-key state silently becoming hidden command editing,
- and assistant/help logic silently triggering from preedit rather than committed text.

### Stealable moves
- readable underlined preedit,
- composition-status badges,
- dead-key and IME posture chips,
- clause/candidate owner confession,
- grapheme/compat-width badges,
- and exact post-commit reveal cards.

### No-regret design move
Add a **composition witness** family so Schell can name:
- `composition_family`,
- `preedit_state`,
- `candidate_owner`,
- `commit_state`,
- `text_commit_basis`,
- and `measurement_posture`.

That is enough structure to make multilingual text entry feel excellent without freezing the final IME API strategy, editor engine, normalization policy, or compatibility-width stack.

## 6) Compact conclusion

One of the smartest moves available right now is:

**make composition/preedit first-class and delightful, but keep visible preedit state, candidate UI, committed buffer text, grapheme measurement posture, and later exact shell meaning separately named.**

That lets Schell steal some of the best modern terminal ideas without letting visual composition comfort impersonate exact execution truth.
