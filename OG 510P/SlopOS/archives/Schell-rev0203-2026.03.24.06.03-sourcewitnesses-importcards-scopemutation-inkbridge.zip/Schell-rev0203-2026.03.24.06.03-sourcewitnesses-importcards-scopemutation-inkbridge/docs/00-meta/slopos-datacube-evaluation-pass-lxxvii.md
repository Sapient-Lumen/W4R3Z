# SlopOS datacube evaluation, pass LXXVII (2026-03-22)

This pass evaluates one new companion import:
**Schell should absolutely grow room cards, participant cards, authorship chips, audience ladders, and writer-token lanes, but SlopOS pressure says room handles, participation cues, and published artifacts must remain weaker than exact approvals, exact live state, and explicit narrowed authority.**

## 1) SlopOS already gives the right room/session lesson: live session objects are provider-owned and not portable authority

`portal-session-posture-v0.md` says request/session objects stay provider-owned, single-outcome, family-local, fail-closed on loss unless a narrower family says otherwise, and do not become a generic resume/list/watch authority surface.
That maps cleanly onto collaborative terminal rooms.
A Schell room handle should be a provider-owned live control object or a weaker historical/imported handle, not a magic bearer of stable authorship or future authority.
If a room is restored or reattached, the archive should say so explicitly instead of pretending it is the same uninterrupted truth.

## 2) Approval-basis posture keeps authorship and strong approvals from drifting with room state

`approval-basis-posture-v0.md` insists that if approval depends on mutable reviewed state, that basis must already be encoded in the exact action bytes.
That means a shared room cannot silently reinterpret who approved or who authored a consequential chapter after participants changed, after a guest reattached, or after a room token was forwarded.
Schell should therefore keep **chapter authorship**, **approver identity**, **current room roster**, and **historical invite lineage** separately named.

## 3) OpenURI history and launch-completion seams warn against social overclaiming too

`openuri-launch-completion-boundary-v0.md` says admission is not completion or “the user definitely saw this.”
`openuri-recent-items-boundary-v0.md` says shell-local history stays non-authoritative.
`openuri-subject-echo-boundary-v0.md` prefers digests or bounded redacted summaries over verbatim sensitive subjects.
Those are exactly the right imports for collaborative terminal rooms.
A participant roster is not proof someone viewed a chapter.
A room history list is not durable truth about who still has access.
And a room/publication receipt should often prefer digests, bounded summaries, and selected parts instead of verbatim secret-bearing subject matter.

## 4) Cross-boundary crypto authority stays a separate lane, not a hidden room privilege

`cryptosvc-forwarding-boundary-v0.md` and `authagent-provider-role-boundary-v0.md` keep cross-boundary key use on explicit narrowed routes and refuse transparent forwarded-agent folklore.
That means collaborative rooms in Schell cannot flatten “participant is in the room” into “participant can spend local or forwarded authority.”
If the room also carries adjacent powers such as file transfer, forwarded crypto use, or service reachability, those need their own strips and receipts.

## 5) Durable-status discipline says presence cues cannot carry the whole truth burden

`attention-durable-status-boundary-v0.md` says transient cues are not durable consequence truth.
That is highly relevant for collaboration UX.
A green dot, “3 viewers”, “guest joined”, or “write access on” pill is not enough durable truth for consequential authorship, audience, or publication semantics.
Schell should land the consequential state on explicit room/artifact receipts and chapter-level witness surfaces instead of presentation happenstance.

## 6) The most SlopOS-compatible moves from this seam now look no-regret

The strongest companion-compatible moves are:
- **room cards** whose handles stay weaker than durable authority,
- **participant cards** with explicit join-proof posture,
- **authorship chips** on chapters rather than room-wide folklore,
- **writer-token lanes** instead of ambient co-typing,
- **adjacent-power strips** separating terminal, files, services, crypto delegation, and publication,
- **audience ladders** separating live roster from anyone-with-link artifacts,
- and **historical/reattached badges** so restored room identity does not impersonate uninterrupted live truth.

## 7) Things this pass still refuses to decide too early

This pass does **not** force:
- one final room relay or coordination backend,
- one final participant-identity or federation model,
- one final author-signing or nonrepudiation scheme,
- one final viewer-read-receipt model,
- one final publication host,
- or one final collaboration protocol.

The answer is smaller and stronger:
**treat shared rooms as provider-owned live objects, keep chapter authorship and approval basis exact, keep audience posture explicit, and refuse to let room presence or share links impersonate durable current truth.**
