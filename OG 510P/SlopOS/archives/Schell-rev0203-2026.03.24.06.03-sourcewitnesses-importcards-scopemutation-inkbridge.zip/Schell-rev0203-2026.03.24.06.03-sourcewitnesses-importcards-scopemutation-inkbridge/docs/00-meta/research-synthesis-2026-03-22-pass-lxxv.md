# Research synthesis, pass LXXV (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should steal lightweight casts, searchable session records, local/LAN live follow, structured timing, and post-hoc chapter search from current tools — but it should keep recorded event streams, searchable transcript hits, PTY/I-O capture, and rerun affordances on an explicit honesty ladder so “we captured this”, “we can search this”, “we can watch this”, and “we can rerun this exactly” never collapse into one flattering replay myth.**

This seam matters because the current shell+terminal ecosystem now offers several tempting recording luxuries at once:
- light text-first terminal casts,
- live browser/LAN streaming,
- centralized searchable I/O logging,
- multi-stream PTY/session capture with timing files,
- and tail-like replay of sessions still in progress.

All of those are genuinely useful.
They are also unusually dangerous.
The operator can stop knowing:
- whether a recording includes only output or also raw input,
- whether search is scanning public artifacts, private artifacts, or current live state,
- whether replay means readonly playback or exact rerun basis,
- whether a “follow” view is a cue or the durable result surface,
- and whether a rich cast is safe to share, safe to index, or safe to treat as operational truth.

The no-regret move is not to avoid recording.
It is to separate capture, searchability, live follow, and rerun truth explicitly.

## 1) `script(1)` still teaches the oldest and sharpest lesson: capture scope matters more than people think

Current `script(1)` docs say it makes a typescript of everything on the terminal session, stores raw terminal data plus structured timing information, supports multiple streams since util-linux 2.35, and warns that `--log-in` / `--log-io` can record security-sensitive input such as passwords even when terminal echo is disabled.
That is a superb reminder that a terminal recorder is not just “history with nicer playback”.
It is a scope choice with residue consequences.
Schell should therefore make capture grade explicit before recording starts and visible long after the run ends.
Useful first distinctions are:
- output-only,
- output + timing,
- output + command chapters,
- input-bearing local capture,
- and imported PTY/I-O capture.
See: https://man7.org/linux/man-pages/man1/script.1.html and https://man7.org/linux/man-pages/man1/scriptreplay.1.html

## 2) `sudo` I/O logging proves that capture can change process posture and still remain incomplete as operational truth

Current `sudoers(5)` docs say I/O logging runs commands in a pseudo-terminal or interposes pipes so terminal input/output and standard streams can be logged locally or to a remote log server.
The same docs warn about pitfalls such as standard-input consumption in shell scripts.
Current `sudo(8)` docs also warn that when users run `sudo su`, `sudo sh`, or commands with shell escapes, subsequent commands may be I/O logged but do not have traditional per-command logs.
That combination is gold for Schell.
It means a capture stack can be both intrusive **and** semantically incomplete.
So Schell should refuse to treat PTY capture as exact chapter identity or exact rerun basis by default.
See: https://man7.org/linux/man-pages/man5/sudoers.5.html and https://man7.org/linux/man-pages/man8/sudo.8.html

## 3) `sudoreplay --follow` proves live watch is a different object from a finished recording

Current `sudoreplay(8)` docs say replay can follow a session still in progress similar to `tail -f`.
That is worth stealing, because live-follow is an excellent operator luxury.
But it is also a crucial honesty lesson.
A follow stream is not the durable completion record, not proof the session is safe to rerun, and not proof the underlying owner still means the same thing.
Schell should keep **live follow** on a different rung from:
- finished cast export,
- durable closing witness,
- and exact rerun packet.
See: https://www.man7.org/linux/man-pages/man8/sudoreplay.8.html

## 4) Tlog proves centralized searchable session records are powerful precisely because they are not just files

Current Tlog docs describe terminal I/O recording/playback for centralized user session recording, with recorded data sent to syslog or journald and encoded as human-readable, searchable JSON so it can be queried and played back from storage systems.
That is an extremely stealable idea.
A shell+terminal should absolutely consider searchable session artifacts and operator-friendly recall.
But it also shows why searchable logs must remain weaker than exact execution basis.
A JSON-search hit is fantastic for discovery and audit.
It is not by itself the canonical command chapter, current live state, or exact rerun authorization.
See: https://github.com/Scribery/tlog

## 5) Asciinema proves text-first casts and live streaming are excellent — and that publication/search radically changes residue

Current asciinema docs describe a CLI for recording and live streaming terminal sessions, a lightweight text-based cast format, and both local and remote live-stream modes.
The asciicast v2 format is newline-delimited JSON with a metadata header and per-event event stream, specifically enabling incremental writing to disk and real-time streaming.
Those are beautiful product clues for Schell.
They show that terminal playback can stay textual, compact, and stream-friendly.
But the more recent asciinema forum announcement about full-text search is an even stronger warning: public/private recordings can become searchable by full terminal session content.
Schell should steal the elegance of text-first casts and local/LAN follow modes while making indexing posture and search visibility impossible to miss.
See: https://docs.asciinema.org/manual/cli/ , https://docs.asciinema.org/manual/asciicast/v2/ , https://docs.asciinema.org/getting-started/ , and https://discourse.asciinema.org/t/full-text-search-on-asciinema-org/1048

## 6) The strongest super-awesome moves are clearer now

The highest-value moves worth stealing from this seam are:
1. **recording ladders** that say output-only / timed-output / shell-chaptered / input-bearing / imported-I-O / live-follow,
2. **search posture badges** that say local-only / team-indexed / published-searchable / unknown,
3. **rerun-basis hold cards** that explain why a cast or log hit is evidence and not exact rerun basis,
4. **follow-versus-finished split cards** so in-progress watch surfaces stay weaker than durable results,
5. **digest-first cast manifests** that bind artifact identity without making the cast itself a power token,
6. **chapter-aware cast spines** that can jump by shell-known command chapter when available and degrade honestly when imported,
7. **secret-risk warnings** for input-bearing or search-indexed captures,
8. **search hit provenance chips** showing public/local/private and shell-authenticated/imported posture,
9. and **promotion ladders** such as inspect / attach excerpt / replay readonly / derive rerun packet / refuse exact rerun.

## 7) What Schell should absolutely refuse

Schell should refuse:
- treating any searchable transcript hit as exact command truth,
- treating live follow as durable completion state,
- treating PTY capture as proof of shell-known chapter boundaries,
- treating a cast file as automatic approval to rerun on the current head,
- and making input-bearing or publicly searchable capture the silent default.

## 8) Decisions intentionally kept open

This pass does **not** freeze:
- one final cast/storage format,
- one final live-stream transport,
- one final search/index backend,
- one final secret-scrubbing pipeline,
- one final replay player,
- or one final rerun-derivation protocol.

The no-regret move is smaller:
**give Schell recording ladders, search posture badges, rerun-basis hold cards, follow-versus-finished splits, digest-first cast manifests, and chapter-aware cast spines while keeping searchable recordings, live streams, and PTY captures visibly weaker than exact rerun truth until attested.**
