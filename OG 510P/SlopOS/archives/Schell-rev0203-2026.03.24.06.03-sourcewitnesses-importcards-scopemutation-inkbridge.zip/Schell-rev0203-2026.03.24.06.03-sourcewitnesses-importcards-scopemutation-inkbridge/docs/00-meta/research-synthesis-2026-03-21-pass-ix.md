# Research synthesis — 2026-03-21 pass IX

This pass keeps one design rule in view:
**collect shell+terminal ideas that are brilliant at the object level while refusing to decide the whole architecture too early.**

The newest outside convergence is not mainly about prettier prompts.
It is about three related truths:

- the shell should emit exact command truth instead of making the terminal guess,
- direct terminal work and agent work should stay visibly distinct,
- and richer execution automation becomes safer only when its lane is explicitly narrower or basis-bound.

## Strongest current outside pressure

### 1) Command truth is strongest when the shell reports it explicitly

VS Code, Windows Terminal, WezTerm, Ghostty, and the older FinalTerm/iTerm2 semantic-prompt lineage all reinforce the same architecture shape:
let the shell emit prompt/command/output boundaries and exact command metadata instead of forcing the terminal to reconstruct them from scrollback.

This now feels like a no-regret import, not just a clever product trick.
It supports prompt navigation, exact block selection, safer rerun, prompt-click editing, and cleaner transcript boundaries.

### 2) Trust and confidence should stay separate

VS Code is especially helpful here.
Its API distinguishes command-line confidence from trust, and a command becomes trusted for strong rerun only when it is explicitly reported and nonce-verified.
That is an excellent lesson for Schell.
A visible block can be highly legible while still not being strong-action-safe.

### 3) Agent work should be a distinct lane, not terminal perfume

Warp's current agent modality makes the product lesson hard to ignore:
a clean terminal for commands and a separate conversation view for multi-turn agent work can still feel integrated while staying honest about provenance and context.
VS Code's agent tooling points the same direction from another angle: stronger autonomy only starts to look acceptable when the execution lane is explicitly narrowed or sandboxed.

### 4) Saved commands are better as explicit searchable artifacts than as folklore

Warp workflows are a useful pressure source because they are parameterized commands that remain named, searchable, and editable artifacts.
That maps well to Schell workflow seeds.
The stealable idea is not “copy Warp.”
It is “preserve reusable command knowledge as explicit objects instead of rc-file sediment.”

### 5) Prompt-safe editing is worth stealing when the shell backs it up

Ghostty's recent click-to-move support inside active shell prompts is one of the clearest examples of a super-awesome move that remains decision-light.
It feels magical to users, but its precondition is humble: the shell must mark the active prompt and the terminal must confine the feature to that live field.
That is exactly the kind of affordance Schell should chase.

### 6) Input realism still matters

kitty's keyboard protocol is still a reminder that richer terminal UI wants a real input story.
Schell does not need to freeze its input protocol now.
But it should remember that inline structure, prompt-safe editing, and future richer widgets cannot be built forever on ambiguous legacy key encodings.

### 7) Request, enabled, active, and completed should stay separate states

XDG OpenURI and InputCapture continue to provide a surprisingly useful shell+terminal lesson.
OpenURI is a user-controlled opening surface, while InputCapture explicitly separates enabled from active.
That is an elegant current precedent for Schell's need to separate proposal, admitted, live, historical, and unknown states rather than flattening them into one nice-looking history.

## Best ideas worth stealing now

### Authorship badges

Every visible actionable object should be able to show a tiny authorship badge such as:

- direct,
- proposed,
- workflow,
- receipt,
- replay,
- or background residue.

This is not decoration.
It is a way to keep provenance visible before action.

### Exact basis packets

A proposal block, saved workflow, or strong rerun target should be able to expose a compact basis packet containing the exact witnesses that matter for “same action, still valid” claims.
This is the shell+terminal analog of SlopOS's approval-basis discipline.

### Compare-and-set review gates

A strong action can then say something much better than “this looks close enough.”
It can say:

- basis still matches → strong action available,
- basis drifted → review again,
- live state unknown → inspect only,
- authorship too weak → no strong rerun.

This is one of the most useful moves Schell can make without deciding its final object model.

### Saved workflow artifacts with provenance

A workflow seed should preserve its source lane, source trust grade, and basis contract.
That gives Schell a cleaner story than aliases while refusing ambient startup magic.

### Active-input field as a real field

The prompt should keep moving toward “one real editable field” instead of dead glass.
Click-to-move, cursor-safe insertions, argument filling, and structured entry affordances are all worth stealing there.

## Moves that make the custom shell+terminal super awesome

### 1) Show who made the thing before asking whether it can run

Authorship and provenance should appear before strong actions, not after mistakes.

### 2) Make stale basis visible before execution, not after the receipt

A custom shell+terminal should be able to refuse flattering reruns and say exactly why.
That is a much stronger product claim than “our terminal has blocks.”

### 3) Keep reusable command knowledge explicit and searchable

A shell becomes much more humane once common work stops hiding in aliases, shell history luck, and undocumented rc-file glue.

### 4) Let narrow lanes earn stronger autonomy

A future agent lane can be much more capable if it is visibly narrower, basis-bound, and possibly sandboxed.
That is the honest route to stronger automation.

## Current prototype reading

The next no-regret slice now looks like this:

1. **one active-input field,**
2. **one authorship badge family,**
3. **one compact basis packet surface,**
4. **one compare-and-set stale-basis refusal specimen,**
5. **one workflow seed carrying provenance and basis,**
6. **and transcript truth for all of it.**

That still leaves renderer, transport, workflow serialization, remote trust, and pipeline ontology open.
That is exactly where Schell should stay.

## Reference pressure

- [VS Code terminal shell integration](https://code.visualstudio.com/docs/terminal/shell-integration)
- [VS Code API: `shellIntegrationNonce` and command-line trust/confidence](https://code.visualstudio.com/api/references/vscode-api)
- [VS Code terminal sandboxing for agents](https://code.visualstudio.com/docs/copilot/agents/agent-tools)
- [Windows Terminal shell integration](https://learn.microsoft.com/en-us/windows/terminal/tutorials/shell-integration)
- [Ghostty shell integration](https://ghostty.org/docs/features/shell-integration)
- [Ghostty click-to-move prompt support](https://ghostty.org/docs/install/release-notes/1-3-0)
- [Ghostty `cursor-click-to-move`](https://ghostty.org/docs/config/reference)
- [WezTerm escape sequences / OSC 133 semantic zones](https://wezterm.org/escape-sequences.html)
- [iTerm2 / FinalTerm semantic prompt escapes](https://iterm2.com/documentation-escape-codes.html)
- [kitty keyboard protocol](https://sw.kovidgoyal.net/kitty/keyboard-protocol/)
- [Warp agent modality](https://docs.warp.dev/agent-platform/local-agents/interacting-with-agents/agent-modality)
- [Warp workflows](https://docs.warp.dev/knowledge-and-collaboration/warp-drive/workflows)
- [XDG OpenURI](https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.OpenURI.html)
- [XDG InputCapture](https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.InputCapture.html)
