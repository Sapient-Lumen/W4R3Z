# Research synthesis, pass LIII (2026-03-21)

This pass keeps one new design rule in focus:
**Schell should steal editor-grade snippet and live-template luxuries — tab order, mirrored placeholders, enum choices, and wrap-the-selection moves — but only as insert-only helpers inside active input, never as hidden execution code, hidden ambient variable capture, or hidden meaning-changing transforms.**

The new outside evidence is unusually clean here.
Editors have spent years making templates humane.
They already know how to:
- jump between fields,
- mirror repeated fields,
- offer constrained choices,
- wrap a selection,
- and keep the operator in an editable surface.

That is exactly the kind of luxury Schell should steal.
The caution is equally clear:
old snippet systems also experimented with embedded shell code, ambient variables, and transformations.
Those are useful in editors because they are mostly text-production tricks.
In a shell+terminal they sit dangerously close to reviewed execution meaning.

## 1) VS Code proves that placeholder, mirror, and choice mechanics are now boringly solid

VS Code's snippet syntax is a terrific baseline because the features are familiar and bounded.
It supports:
- ordered tabstops,
- linked repeated tabstops,
- placeholders,
- explicit choice lists,
- and variables.

That is a good Schell clue.
The steal is not the whole snippet grammar.
The steal is the **interaction model**:
active input can behave like a good editor when the operator is filling reviewed fields.
See: https://code.visualstudio.com/docs/editing/userdefinedsnippets

## 2) TextMate is still the strongest lesson in both what to steal and what to refuse

TextMate remains important because it shows the full shape of the idea.
It has tab stops, placeholders, mirrors, transformations, and choices.
Those are all still compelling.
But it also supports interpolated shell code in snippets.
That is exactly the thing Schell should refuse to inherit.
In a shell+terminal, snippet expansion must not become an execution-capable macro lane.
See: https://macromates.com/textmate/manual/snippets

## 3) JetBrains live templates reinforce the wrap/transform distinction

JetBrains live templates separate a few different powers that are easy to blur:
- plain insertion,
- parameterized insertion,
- and surround templates that wrap existing selections.

That split matters for Schell.
Wrapping a selected token range or active-input region can be wonderful.
But wrap should remain a visible insert/edit action, not a hidden reinterpretation of already-reviewed command meaning.
See: https://www.jetbrains.com/help/idea/using-live-templates.html

## 4) Warp keeps proving the shell-specific version of the same idea

Warp's current workflow docs now line up almost perfectly with the editor-template lesson.
Arguments are explicit, enums can surface suggestions, repeated same-name arguments sync through multiple cursors, and the result lands in editable input before run.
That is the right import for Schell.
The shell version of snippet luxury should still terminate in one live active-input field under operator control.
See: https://docs.warp.dev/knowledge-and-collaboration/warp-drive/workflows

## 5) The dangerous parts are now easier to name

The past lesson is not “templates are dangerous.”
The real lesson is narrower:
**template mechanics become dangerous when they cross from insertion help into hidden execution authority.**

Bad imports for Schell would be:
- interpolated shell code during expansion,
- hidden clipboard/current-selection/current-file capture that changes reviewed meaning without a visible basis badge,
- transforms that silently modify executable names, flags, or destinations,
- provider-defined dynamic enums that require nontrivial side effects just to populate a choice list,
- and template expansion that runs immediately instead of landing in editable input.

## 6) The stealable move: snippet witnesses inside active input

The best bounded move now looks like this:
1. a command chapter or workflow seed enters active input,
2. some spans become visible snippet witnesses,
3. the operator tabs between them,
4. repeated witnesses mirror only when explicitly declared equal,
5. constrained fields may offer enum choices,
6. wrapping a selection stays a visible editing move,
7. and run remains separate.

That is a lot of delight for very little architectural commitment.

## 7) What snippet witnesses should probably expose

A useful first witness shape might include:
- field id,
- span or token family,
- origin (workflow seed / chapter capture / operator-created template / imported snippet),
- default text,
- whether mirroring is explicit,
- whether choices are static or dynamically sourced,
- whether the field is authority-bearing,
- and whether any transform is purely presentational or meaning-affecting.

If Schell cannot say those things, then snippet luxury is probably arriving too early.

## 8) Strong rule for transforms

Transforms are the highest-risk luxury in this cluster.
A transform can be harmless, like uppercasing a display-only label.
Or it can be meaning-bearing, like rewriting an executable name, host, path, extension, or flag shape.

So Schell should start with a hard split:
- **display transforms** may be allowed as visibly derived previews,
- **meaning-affecting transforms** should require explicit reveal and should probably stay out of Phase 0/1 unless proven safe.

## 9) A compact first proving slice

A compact proof could show:
- one active-input template with three tabstops,
- one mirrored placeholder family,
- one enum choice field,
- one wrap-selection move,
- one visible unresolved variable/basis badge,
- and one explicit run step that stays separate from expansion.

That would already make Schell feel dramatically more custom than bash while still keeping parser, PTY, workflow schema, and transport decisions open.

## 10) Decisions intentionally kept open

This pass does **not** freeze:
- one final snippet grammar,
- one final variable catalog,
- one final transform language,
- one final workflow/template serialization format,
- one mandatory editor engine,
- or one final prompt-local key protocol.

The no-regret move is smaller:
**steal tabstops, mirrors, choices, and wrapping — but keep expansion insert-only, provenance-visible, and weaker than exact launch truth.**
