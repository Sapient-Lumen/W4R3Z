# Research synthesis, pass XXXII (2026-03-21)

This pass keeps one lesson in focus:
**shells and terminals get misleading when they compress proposal, launch, observed readiness, completion, and user-saw-it truth into one vague success style.**

The current ecosystem has some excellent ideas here, but the ideas only stay safe when their state claims remain narrow.
A lot of the most attractive tooling can look stronger than it really is.
That is not a reason to avoid rich UX.
It is a reason to make outcome truth more exact.

## 1) Shell integration gets powerful when the shell reports exact boundaries

VS Code's shell integration supports prompt and command markers, tracks working directory, and exposes command-line confidence and trust levels through its API.
That is more than a convenience feature.
It is a design lesson.
The terminal becomes much more capable when it is allowed to say:
- this is the prompt,
- this is the command,
- this cwd was reported by the shell,
- this command line is high/medium/low confidence,
- and this one is trusted because it was nonce-verified.

Schell should steal the deeper idea, not just the escape codes:
**state claims should carry confidence and witness posture instead of being flattened into one decorative “run” label.**

## 2) Prompt-click and prompt-jump features are great precisely because they are narrow

Ghostty's shell integration and OSC 133 support allow prompt jumps and click-to-move within the active prompt.
That feels luxurious, but it works because the claim is modest.
The terminal is not saying “I understand your whole shell session.”
It is saying “the shell marked this region as the active prompt.”

That is exactly the kind of super-awesome move Schell should keep favoring:
small exact truths that unlock a lot of humane control.

## 3) Suggestions stay lovable when they remain proposal-only

fish autosuggestions do nothing until accepted.
That remains one of the best interactive-shell ideas around.
Elvish also keeps editor modes explicit instead of pretending completion, navigation, history, and insert are one undifferentiated state.

The lesson is bigger than suggestion UX.
It is that proposal state should stay visibly weaker than launch state.
A shell+terminal becomes more trustworthy when it lets the operator enjoy proximity without losing the boundary between “suggested”, “inserted”, and “executed”.

## 4) Focused help and rich rows are best when they enrich current review instead of implying execution

PowerShell's dynamic help binds focused parameter help to the current command line.
Nushell's `display_override` separates what a row shows from what gets inserted.
Warp workflows open into an editor where the command and arguments can be edited before running.

These are all stealable for Schell because they preserve the same posture:
- review first,
- insert exactly,
- enrich richly,
- and do not pretend a richer card is the same thing as a stronger execution claim.

## 5) Progressive enhancement works because unsupported terminals fall back to a weaker but honest truth

kitty's keyboard protocol is based on progressive enhancement.
Applications can detect whether support exists instead of assuming it.
That is a beautiful general design rule for Schell.
A richer outcome claim should only appear when the stronger witness really exists.
Otherwise the system should fall back to the weaker honest state, not to fake certainty.

## 6) Cwd-aware semantic links are useful, but they are still weaker than exact object identity

iTerm2's semantic history tracks the working directory for each line to improve file opening from terminal output.
That is a genuinely nifty idea worth stealing.
But it also demonstrates the boundary Schell should keep:
contextual resolution can be very useful while still remaining weaker than a shell-witnessed exact object or reviewed target.

So Schell should keep semantic links, but their badges should stay contextual rather than pretending they are exact object identity.

## 7) Restoration is strongest when the system refuses to lie about rerun state

Zellij's session resurrection is unusually honest here.
It serializes layout/command state, but resurrected commands do not immediately run; they sit behind `Press ENTER to run...`.
That is exactly the right kind of restraint.

It means restored state is not silently promoted from “historical/staged” to “running/complete”.
That is a lesson Schell should copy aggressively.

## 8) Historical text interfaces already knew that handoff is not completion

Plan 9's plumber remains a strong example of explicit message dispatch between programs.
Acme keeps text as an interface instead of hiding everything behind opaque widgets.
Together they suggest a useful design instinct for Schell:
when one tool hands something to another, the handoff itself can be first-class without pretending the downstream program's whole lifecycle is now known.

## 9) A compact Schell import now looks like a handoff ladder

The next good import is not a giant lifecycle engine.
It is a smaller rule:
- `inserted` is not `reviewed`,
- `reviewed` is not `admitted`,
- `admitted` is not `observed-ready`,
- `observed-ready` is not `completed`,
- and `completed` is not automatically `user definitely saw/consumed the result`.

That ladder makes it easier for Schell to support:
- object-card open actions,
- remote attach,
- workflow summon and run,
- restored panes,
- external viewers,
- and smart finish notices,
without silently inflating what the UI claims to know.

## 10) The super-awesome move is exact luxurious wording

A custom shell+terminal becomes super awesome when it can say things like:
- inserted into prompt,
- reviewed on exact basis,
- handoff admitted,
- peer witnessed,
- target ready witness received,
- command exited 0,
- target completion unknown,
- restored and waiting for rerun.

That sounds less flashy than a generic success toast.
In practice it is far more powerful because operators learn which claims to trust.

## 11) Decisions intentionally kept open

This pass still does **not** freeze:
- one lifecycle packet schema,
- one remote observation channel,
- one viewer callback contract,
- one pane-manager API,
- one final badge vocabulary,
- or one callback/notification transport.

The no-regret move is smaller:
**teach Schell to speak in exact handoff and observation states instead of pretending every rich action has the same completion truth.**
