# Research synthesis — pass VIII

This pass asks a narrower question than pass VII:
**what outside ideas help Schell make authority visible and humane without overcommitting the architecture?**

## Lessons we must learn from the past

### 1) Shell truth beats terminal guesswork

Current shell-integration systems keep converging on the same pattern: the shell tells the terminal where prompts, commands, and outputs begin and end, and richer UX follows from that.
VS Code explicitly models shell-integration quality, distinguishes richer versus weaker command detection, and can receive the exact command line with an optional nonce-backed trust path.
Ghostty, iTerm2, and the FinalTerm lineage all reinforce the same lesson.
Schell should keep stealing that pattern rather than making the terminal infer too much from scrollback.

### 2) Admission, activation, and completion must stay separate

XDG portal docs remain unusually useful here.
Request success means the request is carried out, not that downstream work is complete.
InputCapture also distinguishes enabled from active.
That is almost a direct design gift for Schell: draft, admitted, active, completed, historical, and unknown should not be one flattering blob.

### 3) Explicit scope separation is a product feature

Warp's current modality split is genuinely informative.
It keeps a clean terminal for commands and a distinct conversation view for multi-turn agent workflows while still allowing cross-surface search.
That is a strong signal that Schell should keep direct command work, proposal/agent work, receipts, workflows, and background residue visibly distinct.

### 4) Saved command knowledge is better as searchable artifacts than as startup folklore

Warp's workflows and unified command search reinforce a useful product pattern:
repeated work can be named, parameterized, and searched without becoming invisible rc-file magic.
That pairs nicely with Schell's refusal to silently inherit ambient shell startup culture.

### 5) Humane shell UX matters, but it should not choose the ontology too early

fish is still a reminder that interactive friendliness is a real product virtue.
Nushell is still a reminder that structured pipelines can be powerful and attractive.
The lesson Schell should import is not “become fish” or “become Nushell.”
It is “earn the humane wins early, and keep the deeper ontology reversible until proofs exist.”

## Nifty ideas worth stealing now

### Compact authority strip

A current lane or active-input field should be able to show a very small descriptive authority summary such as:

- wallet digest or short id,
- widening state (clean / drifted / widened / unknown),
- active lease hints,
- and maybe the current trust grade.

This is not a permission dashboard.
It is just enough visible truth to stop the operator from flying blind.

### Exact authority diff cards

When a command or workflow needs more power, Schell should show a compact diff card instead of a prose-only warning.
That card should make the widening explicit and bind approval to the exact diff object.

### Lease pills and revocation hints

Temporary authority should show TTL/use-count/scope hints in a tiny way.
Expired, drifted, or no-longer-known state should also be visible.
The point is not to build a big policy console; it is to keep temporary power from looking ambient and permanent.

### Direct-exec versus shell-eval as named modes

Ghostty's explicit `direct:` versus `shell:` command prefixes are a nice reminder that “run this” and “run this through shell parsing/expansion” should be deliberate modes, not always heuristics.
Schell should likely preserve a similarly explicit distinction where it matters.

### Shell-backed prompt editing only where authority is live

Ghostty's prompt-click support and similar semantic-prompt work suggest that click-to-move, multi-line editing, and prompt-safe selection are genuinely worth stealing.
But only where the shell declares live edit authority.
Historical output should stay inspectable, not editable.

### Keyboard/input explicitness

kitty's keyboard protocol is an important reminder that richer terminal interaction needs a real input story.
If Schell ever wants advanced inline UX, it should avoid quietly depending on broken legacy key encodings.

### Unified search across lanes, with scope shown before action

Warp's command search is the best current product hint here.
A single search surface can span command history, workflows, environment state, notebooks/prompts, and conversation history.
For Schell the stealable part is not every object type.
It is the idea that **search may unify discovery while action still respects scope and trust.**

## Moves that make the custom shell+terminal super awesome

### 1) Make authority visible without making it magical

The shell+terminal should answer “what power is live?” almost instantly, but through compact descriptors, not through hidden reusable grants.

### 2) Let the terminal become brilliant exactly where the shell can back it up

Prompt-safe clicks, exact block actions, threshold notifications, sticky headers, and mode tables are great when backed by shell truth.
They become dangerous or annoying when built on guesswork.

### 3) Turn saved work into first-class artifacts, not startup sediment

Searchable workflow seeds and explicit reusable command artifacts feel like the cleanest way to be more powerful than aliases without importing ambient rc-file complexity.

### 4) Keep the command lane, review lane, and receipt lane visibly different

A powerful shell+terminal should feel more unified than current products while still telling the truth about provenance, live state, and what actions are unlocked.

## Current prototype reading

The next no-regret slice now looks like this:

1. **one active-input field,**
2. **one compact authority strip,**
3. **exact authority diff cards for widenings,**
4. **lease and drift hints where they matter,**
5. **scoped work lanes and explicit workflows,**
6. **and transcript-safe fallback when none of the rich rendering exists.**

That still leaves renderer, transport, remote trust, workflow schema, and pipeline ontology open.
That is exactly the kind of ambition Schell should keep.

## Reference pressure

- [VS Code terminal shell integration](https://code.visualstudio.com/docs/terminal/shell-integration)
- [VS Code terminal sandboxing for agents](https://code.visualstudio.com/docs/copilot/agents/agent-tools)
- [VS Code API: `shellIntegrationNonce`](https://code.visualstudio.com/api/references/vscode-api)
- [XDG Request](https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Request.html)
- [XDG OpenURI](https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.OpenURI.html)
- [XDG InputCapture](https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.InputCapture.html)
- [Ghostty shell integration](https://ghostty.org/docs/features/shell-integration)
- [Ghostty configuration reference](https://ghostty.org/docs/config/reference)
- [iTerm2/FinalTerm escape codes](https://iterm2.com/documentation-escape-codes.html)
- [kitty keyboard protocol](https://sw.kovidgoyal.net/kitty/keyboard-protocol/)
- [Warp agent modality](https://docs.warp.dev/agent-platform/local-agents/interacting-with-agents/agent-modality)
- [Warp command search](https://docs.warp.dev/terminal/entry/command-search)
- [Warp workflows](https://docs.warp.dev/knowledge-and-collaboration/warp-drive/workflows)
- [fish tutorial](https://fishshell.com/docs/current/tutorial.html)
- [Nushell introduction](https://www.nushell.sh/book/)
- [Nushell pipelines](https://www.nushell.sh/book/pipelines.html)
