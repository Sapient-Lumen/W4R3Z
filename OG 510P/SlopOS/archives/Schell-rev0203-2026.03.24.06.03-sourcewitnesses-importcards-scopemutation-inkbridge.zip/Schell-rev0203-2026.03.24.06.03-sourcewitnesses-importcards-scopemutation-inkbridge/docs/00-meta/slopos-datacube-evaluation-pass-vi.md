# SlopOS datacube evaluation — pass VI

This pass keeps one narrower rule in view:
**Schell should only inherit shell behavior that it can explain, review, transcript, and replay honestly.**

The freshest SlopOS pressure is not about making the shell smaller for its own sake.
It is about refusing the old places where shells quietly smuggle in power:
startup files,
prompt-time hooks,
per-directory activation,
ambient executable lookup,
and fuzzy “the command text is close enough” execution stories.

That pressure is especially important for Schell because a rich custom terminal can make hidden magic feel delightful long before it becomes legible.

## Strongest SlopOS lessons right now

### 1) Startup and prompt transitions are authority seams, not harmless convenience

The capshell startup-profile posture is one of the most important new imports.
It refuses implicit rc/profile loading and also refuses prompt-time or cwd-triggered code loading.
That is a deep warning for shell history.

Local import for Schell:

- do not treat startup files as morally neutral just because old shells do,
- do not let prompt redraw, `cd`, or project entry become hidden code-execution events,
- and keep built-in prompt/completion/help/rendering separate from future explicit customization artifacts.

This does **not** force Schell to stay austere forever.
It means customization should return later as something explicit, digest-bound, reviewable, and killable.
That is a much stronger foundation than ambient dotfile folklore.

### 2) Exact execution identity matters more than typed command text alone

The capshell exec-selector posture refuses ambient PATH lookup, and the word-expansion posture refuses hidden pre-exec expansion.
Together they say something very useful for Schell:
what the operator typed,
what the shell reviewed,
and what actually got launched are related but distinct truths.

Local import for Schell:

- keep raw prompt input visible as human context,
- keep the reviewed execution artifact separate from that raw text,
- record resolved executable identity separately when it matters,
- and never let rerun or attach semantics depend only on scrollback text.

This is where Schell can outperform classic shells without deciding too much language too early.
The UI can stay humane while the durable receipt remains exact.

### 3) Expansion magic should not silently become the first architecture decision

SlopOS is right to treat pre-exec expansion as a major seam instead of a default convenience.
Schell does not need to copy that answer literally today, but it **must** learn the lesson.
Expansion choices are architecture choices.
They affect review,
receipts,
copy/rerun truth,
and whether a terminal can honestly explain what just happened.

Local import for Schell:

- keep input text, bound argv, and later interpreter-side semantics visibly distinct,
- do not let glob/path/variable substitution hide inside terminal affordances,
- and do not let “the shell probably meant this” become a trusted action path.

### 4) Output should become explicit objects before it becomes terminal folklore

The capshell output normal-form doc is a strong reminder that exportable results should be explicit, digest-addressed objects rather than ambient path folklore or log-only residue.

Local import for Schell:

- receipt-linked outputs should become navigable objects,
- exact preview should stay observational,
- and rich terminal export features should land on explicit artifact references, not guessed file names from scrollback.

This gives Schell a much better story for replay, diffing, postmortems, and background-state inspection.

### 5) Explanation belongs to the shell, not to whatever UI copy happened to render

The SlopOS explain posture remains a powerful anchor.
Canonical summaries and diffs should be shell-owned and action-bound, while receipts stay durable but non-authoritative.

Local import for Schell:

- review cards may look beautiful in the terminal, but their bound meaning must come from shell-owned summaries,
- receipts should never replay as fresh approval,
- and notification/history surfaces must not quietly become permission state.

That keeps Schell from turning a gorgeous terminal UI into a hidden authority plane.

## What Schell should deliberately refuse for now

### Refuse ambient startup imports

Do not build the first real Schell experience on `.bashrc`-style inheritance, prompt hooks, or per-directory activation.

### Refuse trust from raw command text alone

Do not let visible command text stand in for exact execution identity when stronger actions are involved.

### Refuse PATH/glob/session folklore as the first proof of humane control

Those are exactly the moves most likely to smuggle in old shell semantics before the archive proves which ones it actually wants.

### Refuse UI-generated explanations

The terminal can decorate, compress, and guide.
It should not become the author of the canonical review meaning.

## Current consequence for Schell

The best current Schell posture is:

1. **built-in humane shell behavior before ambient customization,**
2. **separate raw input from reviewed execution truth,**
3. **treat stronger block actions as trust-gated,**
4. **make receipts and outputs explicit objects,**
5. **keep canonical explanation shell-owned,**
6. **and only re-admit classic shell conveniences once they earn explicit surfaces.**

That keeps the archive ambitious without quietly inheriting the mistakes it is trying to outgrow.
