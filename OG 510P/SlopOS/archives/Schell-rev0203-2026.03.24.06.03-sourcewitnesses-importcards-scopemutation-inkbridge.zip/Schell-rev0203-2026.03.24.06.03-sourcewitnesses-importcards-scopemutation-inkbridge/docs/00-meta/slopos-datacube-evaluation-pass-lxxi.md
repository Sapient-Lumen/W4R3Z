# SlopOS datacube evaluation, pass LXXI (2026-03-22)

This pass evaluates one new companion import:
**Schell should absolutely gain explicit add-on packs, pure-data themes, contextual history wallets, reviewed env overlays, and capability-bounded extension posture, but SlopOS pressure says startup state, tool catalogs, per-directory hooks, extension imports, learned suggestions, and synced residue must stay separately admitted so shell ecosystem luxury never turns back into ambient authority.**

## 1) SlopOS already has a strong answer for third-party extension shape

`RFC-0052: WebAssembly components as the default untrusted extension runtime` is a major clue.
It says extensions should run in an untrusted sandbox boundary, receive authority only through typed capability imports, and use a closed import allowlist.
That is exactly the lesson Schell should steal for add-ons.
Prompt helpers, completion providers, object routers, query assistants, and optional history analyzers should not begin life as arbitrary startup code inside the main shell process.
They should begin as explicit imported tools with typed capability posture.

## 2) SlopOS also says tool catalogs and memory must be explicit or they do not count

The `llm-operations-posture-v0.md` surface is even sharper.
It says tool, resource, and prompt catalogs are explicit and bounded; there is no portable ambient connector discovery; prompts and metadata do not carry authority; and hidden cross-run memory does not count.
That pressure maps beautifully into shell design.
Schell should not accept “install this pack and it can discover whatever tools/history/state it wants” as an innocent convenience.
Add-on discovery, history reach, prompt modules, and helper lanes should all be explicit.

## 3) SlopOS is deeply hostile to startup/profile folklore

The current capshell startup-profile posture says integrated startup is explicit-only session state and rejects implicit rc/profile loading and per-directory hooks.
The capshell env-startup posture says child environments are complete and explicit only and rejects shell startup hooks, loader-injection variables, and runtime import-path widening.
That is profound design pressure for Schell.
If the shell+terminal ever gains an ecosystem, it should not re-import the very startup/profile ambiguity that SlopOS is working so hard to cut off.

## 4) SlopOS learn-mode posture says suggestions should stay observational

`capshell-learnmode-posture-v0.md` says learning stays observational only, stage-local, and review-bound; no allow-and-remember path, no auto-edit, and no auto-rerun.
That is exactly the right posture for shell ecosystem help.
Schell can absolutely suggest:
- an add-on pack,
- a completion bundle,
- a reviewed env overlay,
- or a history query pack.
It should still refuse to let a helper silently install, enable, widen, or remember those powers on its own.

## 5) SlopOS pressure suggests five separate shell-side objects

Putting the companion archive together suggests a clean Schell family:
- **add-on manifest** — exact identity, version, pure-data versus code posture, startup footing, and touched surfaces,
- **capability wallet** — what the add-on may read, write, route, suggest, or sync,
- **env-overlay card** — reviewed cwd/project-specific environment diff posture,
- **history wallet** — local-only / encrypted-sync / redacted-export / no-export posture,
- **compat bridge badge** — exact claim strength when Schell is carrying old rc/plugin ecosystems rather than a native pack.

That split matters a lot.
If Schell flattens these objects into one generic “plugin installed” badge, it will recreate the same ambient startup and hidden-memory problems SlopOS keeps refusing.

## 6) The companion archive points toward an extension story that is much smaller than a plugin free-for-all

A strong v0 posture would probably say:
- pure-data prompt/themes/completion bundles are preferred,
- code-bearing add-ons are explicit imported tools with typed capability posture,
- per-directory environment changes are reviewed env overlays rather than generic code-on-cwd-entry,
- history/context retention and sync posture are explicit and redaction-aware,
- and learn/suggest flows stay observational until explicit review installs or enables something.

That would give Schell a real ecosystem story without importing arbitrary rc sourcing, hidden memory, or ambient discovery.

## 7) Decision-light next move

A strong next move is to define one **shell add-on pack / pure-data theme / contextual history / extension humility** family that proves:
- delight can arrive through explicit packs,
- code and data can stay visibly separate,
- sync and retention can stay explicit,
- and compatibility bridges can carry old shell ecosystems without becoming native authority.

That keeps Schell ambitious while learning the right lesson from SlopOS:
**ecosystems are welcome, but startup footing, tool catalogs, env overlays, memory/sync reach, and extension imports must stay separately admitted.**
