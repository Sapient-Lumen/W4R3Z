# Research synthesis — 2026-03-23 — pass CLXXIX

This pass sharpens one fresh lesson from current terminal, shell-integration, preserved-output, and watch-stream docs:
**the most honest systems do not stop at “here is the captured slice.” They also make room for a separate _since this cut_ lane that can extend, stream, or reset without pretending the original capture was already live truth.**

## 1) VS Code is converging on preserved command captures plus later live visibility

VS Code keeps making exact command-local capture more valuable.
Shell integration already powers command navigation and output selection, and recent releases add command attachment to chat with command line, captured output, and exit code.
Later release notes then say VS Code preserves captured output even after the backing terminal has exited, and newer chat-terminal output now streams automatically when long-running commands take time.

That is an important design clue.
The product is already separating:
- an exact captured command output,
- a preserved historical view of that output,
- and a later live/streaming continuation when activity is still happening.

Schell should steal that separation, not flatten it.

## 2) WezTerm and Ghostty prove that tiny semantic boundaries are enough to anchor the base cut

WezTerm keeps the semantic substrate tiny: `OSC 7` for cwd, `OSC 133` for prompt/input/output zones, and `OSC 1337` for pane-scoped user vars.
That is enough to support jumping between earlier commands and selecting the complete output from a command.

Ghostty's shell integration exposes the same pressure in a different way: select the output of a command, jump between prompts, keep cwd-aware spawn comfort, and manually re-source integration when shell switching would otherwise make semantics stale.

That matters because a since-cut supplement is only honest if the original cut was anchored to a real command/prompt/output boundary instead of one fuzzy scrollback guess.

## 3) Kubernetes streaming lists are the clearest “snapshot plus changes” pattern to steal

Kubernetes now documents `sendInitialEvents=true` for watch requests: the API server can start the stream with synthetic initial events, emit a `BOOKMARK` carrying the resource version to which the stream is synced, and then continue with the regular watch stream.
The same page also warns that clients must not assume bookmarks arrive on any fixed interval or even at all.

That is almost the exact shape Schell wants.
A shell+terminal capture should be able to say:
- here is the base snapshot,
- here is the watermark it is synced through,
- and here are only the later changes — unless reset is required.

## 4) systemd keeps proving that stronger “caught up through” claims need explicit synchronization

systemd's `sd_notify_barrier()` exists because a process may emit status before the manager has actually processed it.
The call provides a synchronization point so earlier notifications are known to have been received and processed.

That matters here because a since-cut supplement should not quietly claim it is current just because some local UI has shown later lines.
If Schell wants a stronger `caught up through` claim, it should either have an explicit watermark/barrier or confess that the supplement is only later-seen output with weaker sync posture.

## 5) The no-regret Schell move is a tiny since-cut supplement linked to the snapshot receipt

Putting these together suggests a better next move than a giant event-log architecture.
Schell should add:
- a tiny **since-cut supplement** linked to a base snapshot receipt,
- a small **caught-up-through** field for later prompt/cursor/bookmark/generation truth,
- and a visible **refresh/reset rail** when the source can no longer be honestly extended.

They should say:
- what earlier cut they extend,
- what exact source they follow,
- whether the supplement is on-demand refresh, live follow-tail, or change-stream based,
- how far they are caught up,
- whether gaps or resets exist,
- and what the strongest honest next move is now.

## 6) Compact conclusion

VS Code proves that preserved command-local output and later streaming are both valuable.
WezTerm and Ghostty prove that a tiny command/prompt/output substrate is enough to anchor exact cuts.
Kubernetes proves that snapshot-plus-change is best modeled as initial state plus a synced-through marker plus later deltas.
systemd proves that stronger sync claims need explicit barriers instead of hope.

So the next no-regret Schell seam is not a giant watch constitution.
It is **since-cut supplements, snapshot-plus-change posture, and refresh-rails humility** so preserved captures can grow later change lanes without pretending the original slice was already current live truth.
