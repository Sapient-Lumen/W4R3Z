# Research synthesis — 2026-03-23 — pass CLVI

This pass tightens another older shell+terminal seam into a smaller rule:
**ambient status should be a projection lane, not a second truth system.**
The strongest current lesson is not merely “titles and notifications are useful.”
It is that titles, badges, and notification clicks work best when they point back to an exact anchor and stay visibly weaker than the shell-owned thing they summarize.

That points to a good next Schell move:
**return-ticket projections, label/source posture, and click-to-reveal-before-act humility** rather than one more vague “status UI” layer.

## 1) xterm is the historical warning: titles have always been mutable and queryable

xterm’s control-sequence docs trace window-control escape sequences back to SunView in 1986.
Current xterm docs still expose changing icon/title text, querying the current title, and saving/restoring title state on a stack.
That is a powerful reminder that display labels have been easy for terminal applications to emit for decades.

So the old lesson is simple:
visible title text is useful orientation, but never self-authenticating truth.

## 2) Windows Terminal is explicit that visible tab titles and shell titles can diverge

Windows Terminal’s docs tell the operator to set `suppressApplicationTitle: true` to block shell/application title changes and then optionally set a fixed `tabTitle`.
That is valuable because it openly names two nearby truths:
- the shell/application may emit title changes,
- and the visible tab title may still be operator-fixed.

This is exactly the kind of honesty Schell should copy.
A local label can be superb UX while still remaining weaker than exact peer, cwd, or chapter identity.

## 3) kitty shows how much ambient chrome can say — and why click humility matters

kitty’s current config allows window and tab titles to include bell, activity, and progress symbols, and even custom render functions.
Its desktop-notification protocol goes further: clicking a notification can focus the originating window and/or send an escape code back to the application.

That is both inspiring and cautionary.
The inspiring part is that ambient chrome can be rich and still feel terminal-native.
The caution is that once notification clicks can talk back to the app, ambient attention cues are brushing against action authority.

## 4) iTerm2 proves badges and alerts are incredibly expressive and incredibly weak by default

iTerm2 badges are large dynamic labels driven by interpolated variables and proprietary escape sequences.
Separately, iTerm2 can surface tab bell icons and Notification Center alerts for output, idle, bell, close, or a proprietary notification escape.
Its trigger system can also set a title, set a user variable, or show an alert.

That combination proves a crucial Schell lesson:
labels and alerts can summarize state brilliantly, but they should remain projection surfaces unless they cite something stronger.

## 5) WezTerm shows a clean split between ambient status and clicked toasts

WezTerm’s `set_right_status` projects formatted text into the tab bar’s right status area and even gives an example that pulls cwd/hostname from the active pane, including remote hostname when OSC 7 shell integration is present.
Its `toast_notification` API separately creates clickable desktop notifications; clicking opens a URL, and the notification persists until dismissed, clicked, or timed out.

This is a strong design clue for Schell:
status strips and notifications are different projection targets, but both are still weaker than the exact ticket they should point back to.

## 6) Ghostty ties finish notifications to shell-known command boundaries

Ghostty 1.3.0 added `notify-on-command-finish` options like `never`, `unfocused`, and `always`, and requires either shell integration or OSC 133 command markers.
That requirement is instructive.
A finish notification becomes much more trustworthy when it is bound to shell-known command boundaries instead of generic renderer folklore.
Ghostty’s 1.3.0 release notes also note that the notification badge now clears when all active bells are cleared.

That is precisely the kind of freshness/clear-rule humility Schell should steal.

## 7) The concrete Schell move

Schell should add a compact **return-ticket projection** contract:
- **return ticket** — exact shell-owned anchor to a chapter, review card, waiting-input card, progress scope, or reset card,
- **projection target** — title / tab badge / dock-taskbar hint / status strip / desktop notification,
- **source posture** — shell / operator override / renderer-local / helper / restored,
- **freshness posture** — live / live-but-local / historical / reset-required / ticket-gone,
- **click posture** — reveal / focus / jump / show card / copy summary / never direct-approve,
- **clear rule** — on-focus / on-return / on-state-change / manual / ttl.

That is enough to steal beautiful ambient status and return comfort without letting labels or clicks become a second hidden shell.
