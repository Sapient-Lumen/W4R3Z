# Research synthesis, pass LIX (2026-03-21)

This pass keeps one fresh design rule in focus:
**Schell should absolutely steal broadcast input, selected target groups, and multi-host fanout comfort — but only if one keystroke never silently becomes hidden fleet authority and the shell+terminal keeps keyboard mirroring visibly weaker than reviewed multi-target execution.**

This seam matters because the luxury is real.
Operators do sometimes need to touch several panes, hosts, replicas, or scratch environments at once.
The current ecosystem proves that this can feel magical.
But it also shows the old trap in a vivid form:
what starts as “send this to a few panes” quickly becomes “I accidentally typed into production everywhere.”
Schell should learn from the good parts while keeping target shape, divergence, and blast radius explicit.

## 1) tmux proves the oldest local luxury: mirrored typing is useful, but it is only pane-local mirroring

tmux still teaches a very clean first lesson.
`synchronize-panes` duplicates input to the other panes in the same window, and only to panes that are not in copy/mode state.
That is a nice restraint.
It reminds us that broadcast input is fundamentally a **view-local convenience**, not a reviewed fleet action object.
Schell should steal the convenience, but it should keep the same humility:
keyboard mirroring is a local lane with a bounded target set, not proof that every target is equivalent and not proof that one reviewed multi-target action has happened.
See: https://man7.org/linux/man-pages/man1/tmux.1.html

## 2) iTerm2 proves that visible danger indicators and scoped broadcast domains matter

iTerm2's docs are refreshingly blunt.
Its Broadcast Input menu says “Be careful,” supports separate scopes such as all panes in the current tab or all panes in all tabs, lets the operator toggle whether the current session receives broadcast input, and can show a red-stripe background indicator for sessions receiving broadcasted keystrokes.
Its Python API also formalizes broadcast domains as disjoint collections of sessions, and its Targeted Input example shows the next step up: a different string can be sent to each session in a broadcast domain.
That is a terrific Schell clue.
A good shell+terminal should keep **target set**, **broadcast scope**, **armed members**, and **visual danger posture** explicit.
And it should separate “same bytes to all targets” from “per-target parameterization.”
See: https://iterm2.com/documentation-one-page.html
See: https://iterm2.com/python-api/broadcast.html
See: https://iterm2.com/python-api/examples/targeted_input.html

## 3) kitty proves that target selection can be much richer — and that secret posture still needs honesty

kitty's broadcast kitten is one of the best modern clues because it does not stop at “all windows.”
It can broadcast to all kitty windows or a subset chosen by match expressions, and the docs even show restricting the broadcast to the current tab.
It also has an `--end-session` key and a `--hide-input-toggle` for hiding the typed text in the broadcast window itself while entering something like a password.
That is useful, but it is also a warning.
Hiding the typed text in one local broadcast window is not the same thing as proving that secret fanout is safe.
Schell should steal rich target selectors and explicit end-session controls.
It should not let a “hidden local echo” UI imply that bulk secret injection is suddenly low-risk.
See: https://sw.kovidgoyal.net/kitty/kittens/broadcast/

## 4) ClusterSSH proves the divergence warning better than almost anyone else

ClusterSSH is old, but its docs are still unusually honest.
It opens a control console plus one terminal per host, replicates typed text into all windows, allows a host to be unplugged from the cluster control window, and explicitly warns that editing files this way is dangerous because line ordering may differ across servers.
That is exactly the Schell lesson.
Broadcast input should not assume semantic equivalence just because panes look similar.
A line editor at a different cursor position, a pager, a password prompt, a sudo prompt, or a slightly different file can turn mirrored typing into damage.
Schell should therefore carry a **divergence warning** family rather than pretending “all armed panes” means “all safe to type into.”
See: https://github.com/duncs/clusterssh

## 5) parallel-ssh shows the stronger pattern: reviewed fanout should become per-target execution objects with per-target outcomes

The current parallel-ssh docs point in a more mature direction than raw keystroke mirroring.
Commands run concurrently across the host set; each host yields a HostOutput with host identity, stdout, stderr, exit_code, exception, and even a `fully_qualified_command` field for non-interactive command execution.
That is exactly the shape Schell should admire for **reviewed fanout run**.
The stronger action should not be “spray bytes into many PTYs and hope.”
It should be “review one target set, one command family, and then receive per-target outcomes.”
That keeps execution truth much healthier.
See: https://parallel-ssh.readthedocs.io/en/latest/quickstart.html
See: https://parallel-ssh.readthedocs.io/en/latest/output.html

## 6) parallel-ssh also teaches timeout and remote-process humility

parallel-ssh's advanced docs contain one especially valuable warning:
without a PTY, a join timeout leaves the remote process running per SSH protocol behavior.
That is a fantastic Schell lesson.
Once multi-target work is involved, “stop waiting” is not the same thing as “all targets stopped.”
So Schell should keep waiting, cancellation, timeout, and remote-liveness receipts separate for fanout actions.
A fleet card that only says “timed out” is not enough.
It should be able to say something more like:
- controller wait ended,
- target 7 is still potentially running,
- target 9 returned exit 0,
- target 11 had an auth exception,
- and no universal rollback exists.
See: https://parallel-ssh.readthedocs.io/en/latest/advanced.html

## 7) The dangerous thing to refuse: blended broadcast folklore

The ecosystem now shows several different things that are easy to flatten into one story:
- mirrored keystrokes across visible panes,
- selected membership in a local broadcast group,
- per-target parameterized text send,
- concurrent command launch across many hosts,
- per-target outputs and exit codes,
- per-target exceptions,
- and durable background multi-target work.

Those are adjacent.
They are not the same.
Schell should keep them separately named before it invents especially seductive cluster UX.

## 8) The stealable move: target-set witnesses and a split between broadcast input and reviewed fanout run

The best decision-light move now looks like this:
1. introduce a **target-set witness** as a first-class object,
2. make target identity and membership reason visible,
3. split **broadcast input** from **reviewed fanout run**,
4. keep broadcast as a local/interactive lane with explicit arm-disarm controls and divergence warnings,
5. keep reviewed fanout as a stronger object with exact command shape and per-target outcomes,
6. show **blast radius** explicitly before stronger multi-target actions,
7. make secret-bearing fanout a stricter or separately named lane,
8. and keep timeout/cancel wording smaller than remote-stop fantasy.

That would make Schell feel dramatically more capable without freezing one inventory backend, fleet orchestrator, SSH transport, cluster policy engine, or host-group language.

## 9) A compact first proving slice

A compact proof could show:
- one local pane-broadcast card with a selected target set,
- one target temporarily disarmed from the set,
- one divergence warning because a target is in pager/edit state,
- one stronger reviewed fanout card with exact command text/argv and per-target identities,
- one per-target parameter fill variant,
- one blast-radius badge before admitting the action,
- one timeout result that says controller wait ended but one remote target may still be running,
- one mixed outcome table with exit code and exception columns,
- and one refusal path for secret-bearing bulk injection.

That is enough to learn a lot while keeping the big architecture decisions open.
