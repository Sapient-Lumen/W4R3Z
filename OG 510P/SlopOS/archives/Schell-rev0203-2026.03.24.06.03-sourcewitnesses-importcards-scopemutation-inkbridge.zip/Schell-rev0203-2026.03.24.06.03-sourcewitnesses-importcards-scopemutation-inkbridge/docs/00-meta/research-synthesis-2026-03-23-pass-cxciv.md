# Research synthesis — 2026-03-23 — pass CXCIV

This pass sharpens one smaller lesson from current shells and directory-jump tools:
**navigation comfort is valuable, but the safest modern navigation keeps candidate routes, admitted movement, and resulting cwd truth visibly separate instead of laundering them into one flattering "the shell knew where to go" story.**

## 1) Current shells already split the good navigation help from the dangerous kind

Bash and zsh keep exposing where confusion enters.
Bash's `autocd` can treat a bare directory name as though it were the argument to `cd`; `cdable_vars` lets `cd` treat a non-directory argument as a variable naming a directory; `cdspell` can correct small directory typos; and `direxpand` can rewrite the editing buffer to expanded directory names during completion.
zsh's `AUTO_CD` does the same bare-token-to-directory move for interactive use and explicitly recommends using `cd` in scripts to avoid ambiguity; its directory options also bring in `CDABLE_VARS`, `CDPATH`, and multiple physical-vs-logical resolution modes.

fish and `zoxide` show the positive side more cleanly.
fish documents that relative `cd` arguments are tried against `CDPATH` plus `PWD`, performs implicit `cd` when given something that looks like a directory, and keeps a directory history in `dirprev` / `dirnext`.
`zoxide` is explicit that it is a smarter `cd`, remembers frequently used directories, resolves ranked matches, and can switch into interactive selection with `zi`.

## 2) The lesson Schell must learn from the past

The historical mistake is not merely "implicit directory movement exists."
The mistake is **flattening several different movement families into one ambient navigation myth**:
- a literal typed path,
- an implicit-`cd` token,
- a `CDPATH` search hit,
- a variable-backed route,
- a spelling-corrected or completion-expanded path,
- a stack or recency recall,
- and a ranked jump-memory result.

Once those collapse, two bad things happen:
1. the operator stops knowing what exact footing actually changed, and
2. later actions inherit a new cwd whose source, freshness, and exact route are harder to reconstruct.

That is exactly the kind of hidden shell folklore Schell has been trying to refuse.

## 3) The nifty ideas worth stealing are route-aware and source-labeled

The best current steals are surprisingly small:
- **implicit directory offers** for tokens that obviously look like paths,
- **`CDPATH` reveals** so nearby root hits are visible rather than magical,
- **directory-history chips** and previous/next stacks,
- **ranked jump offers** with source and age labels,
- **interactive choice** for ambiguous matches,
- and **dual-view history** that preserves both typed token and resolved route.

These are super awesome because they speed up movement without forcing Schell to decide one final cwd ontology, one final ranker, one final shell helper pack, or one final history-serialization story.

## 4) The moves Schell should refuse for now

Schell should refuse, for now:
- invisible footing changes that later empower strong acts,
- movement heuristics that cannot reveal whether they came from literal path, `CDPATH`, history, or ranking memory,
- one monolithic jump feature that hides whether the route was typed, offered, imported, corrected, or recalled,
- and any history/export surface that forgets the difference between the typed navigation token and the resolved directory.

In other words:
**steal the comfort of fast movement, not the ambiguity of hidden ground changes.**

## 5) The no-regret Schell seam

Schell should add one dedicated surface for:
- typed navigation tokens,
- candidate-route sets,
- admission posture,
- source/ranking labels,
- exact cwd compare,
- and dual-view history/share rules.

That lets the shell feel faster and smarter without deciding whether the long-term answer is pure literal navigation, project roots, jump ranking, variable aliases, assistant help, or some later hybrid.

## 6) Compact conclusion

Current docs line up unusually well here.
Bash and zsh show how easy it is for implicit movement and `CDPATH`/variable tricks to blur authored meaning and actual ground change.
fish and `zoxide` show the best positive pattern: fast movement help with visible route families and optional interactive choice.

So the next low-regret Schell seam is **AUTO_CD, CDPATH reveals, and navigation-truth humility** so movement stays delightful without becoming hidden footing authority.
