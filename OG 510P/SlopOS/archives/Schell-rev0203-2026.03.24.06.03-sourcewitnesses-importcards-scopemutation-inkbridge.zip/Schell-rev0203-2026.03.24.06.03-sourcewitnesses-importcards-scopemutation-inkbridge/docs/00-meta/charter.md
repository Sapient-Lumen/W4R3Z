# Charter

## Purpose

Schell is a shell+terminal design archive for building a SlopOS operator environment that is:

- **interactive enough** for ordinary terminal work,
- **structured enough** to support inspection and automation,
- **strict enough** to make authority and side effects visible,
- **integrated enough** that the shell and terminal reinforce the same reviewed-control model,
- and **portable enough** to grow on conventional Unix-like systems before any exotic runtime ambitions.

## Non-negotiables

1. **Command intent must become a first-class artifact.**
   A command should not leap from raw text straight into process launch without an inspectable intermediate representation.

2. **Shell truth and terminal rendering must be layered, not conflated.**
   Schell is a co-designed shell+terminal, but shell truth, semantic transport, and local luxury UX must stay distinguishable.

3. **Expansion is staged, not magical.**
   Quoting, variable expansion, globbing, command substitution, and redirection binding should have an explicit order and failure story.

4. **Side effects deserve lanes, not footnotes.**
   Environment mutation, filesystem writes, network use, secret reads, terminal control, and job-like background presence should be representable as effects.

5. **History should grow into lineage.**
   The archive aims beyond “what text did I type?” toward “what was intended, approved, executed, and observed?”

6. **Compatibility is a profile, not a religion.**
   Schell should learn from POSIX and existing shells without inheriting every historical ambiguity as destiny.

7. **Automation must not erase the human.**
   Agent help may draft or suggest, but Schell must preserve who requested, who approved, and what actually ran.

8. **Rich terminal affordances must survive into transcript truth.**
   Prompt marks, review cards, receipt blocks, denials, and background state should remain understandable outside the richest renderer.

## Initial north-star object

A **reviewed action envelope** plus **effect lanes** plus **session lineage** plus **terminal-visible receipts** is the current founding compression.
That is still a working object, not a final theorem.
