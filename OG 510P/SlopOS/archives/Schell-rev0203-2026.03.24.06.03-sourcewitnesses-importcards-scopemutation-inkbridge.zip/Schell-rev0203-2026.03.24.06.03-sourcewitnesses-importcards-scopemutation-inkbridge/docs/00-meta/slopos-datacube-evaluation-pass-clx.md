# SlopOS datacube evaluation — pass CLX

This pass asks a narrower companion-safe question than “how should Schell help with commands?”
The better question is:
**how should Schell expose what a command token will actually resolve to without letting aliases, builtins, helper imports, or remembered path hits impersonate exact current execution truth?**

## 1) SlopOS exact routing posture argues against one ambient command-name myth

SlopOS keeps routing and authority explicit instead of ambient.
That pressure transfers directly here.
If Schell says a bare command name will invoke a particular function, builtin, script, or executable, it should be able to say which exact routing layer established that claim.

## 2) SlopOS import boundaries suggest discovery and adoption should stay separately named

SlopOS already keeps imported carriers, adoption, and current live authority separate.
That means Schell should also keep these layers distinct:
- typed command token,
- discovered candidate invokers,
- the actual winning invoker,
- any imported helper or module that made the invoker available,
- and the later prepared action / execution receipt.

The mistake would be to flatten them into one vague “command exists here” story.

## 3) ViewFS pressure says accepted insertion, prepared action, and receipt are not the same object

ViewFS keeps accepted insertions, compiled command packets, prepared actions, and receipts separate.
That pressure fits command resolution almost perfectly.
A typed token, a command card, a path-resolved winner, an imported helper definition, and the receipt of what actually ran are not one object.

So Schell should show command identity as a small witness stack instead of one scalar path answer.

## 4) Steward pressure says remediation should remain exact and subordinate

Steward keeps retry and pushback posture exact.
That matters here too.
Operators need to know whether a failure or surprise means:
- wrong invoker won,
- a function or alias shadowed the expected executable,
- a builtin outranked a path binary,
- a stale path/hash/module basis was reused,
- or the command truly was absent.

That makes command-identity witnesses better than generic “did you mean?” comfort.
Repair can come later and stay weaker.

## 5) Helm pressure says changed basis and reset cards matter for command winners too

Helm keeps teaching that historical-looking continuity is dangerous when basis drifted.
That matters here as well.
A token may still look the same while:
- `PATH` changed,
- a repo-local helper defined a function,
- a module autoload changed the command set,
- a hash entry points at an older path,
- or a recovery card is still showing the last known answer.

So Schell should pair command-name chips with exact basis reveals, shadow-stack cards, and reset/drift cues.

## 6) What Schell should steal now

Schell should steal several high-value moves:
- an **exact-invoker strip** that says what will answer the current token now,
- **shadow-stack cards** that reveal neighboring alias/function/builtin/module/path contenders,
- **bypass ladders** such as explicit path, module-qualified, `command`, and `builtin`,
- **hash/module drift beacons** when the current answer is remembered or imported rather than freshly obvious,
- and **receipt-level invoker pins** so transcripts remember what actually answered the call.

These are great luxuries and do not force Schell to settle one final resolver engine or module system too early.

## 7) What Schell should refuse now

Schell should refuse:
- a path-only answer counting as full command identity truth,
- a pretty badge counting as proof of what will actually run,
- helper/module imports counting as harmless during discovery,
- historical path or hash hits counting as current fresh proof,
- and remediation/install offers counting as if they were the resolver itself.

## 8) Compact conclusion

The companion-safe move is to keep **typed token, winning invoker, shadow neighbors, imported availability, bypass forms, and execution receipt** separately witnessed.
That lets Schell become dramatically more humane around command resolution while staying aligned with SlopOS’s refusal to let ambient naming folklore become portable authority.
