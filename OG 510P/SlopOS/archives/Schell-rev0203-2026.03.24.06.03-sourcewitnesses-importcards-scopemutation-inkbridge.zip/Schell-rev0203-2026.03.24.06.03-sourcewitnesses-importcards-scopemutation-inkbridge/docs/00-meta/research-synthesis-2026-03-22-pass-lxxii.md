# Research synthesis, pass LXXII (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should treat migration as a first-class product surface — stealing smooth upgrade paths, transient prompt retirement, show-on-command context, directory-memory comfort, and one-off tool shims — but it should keep imported profiles, prompt hooks, ranking stores, and compatibility bridges visibly weaker than native shell truth.**

This seam matters because shell quality is not only about what happens once the operator is fully migrated.
It is also about how they arrive.
The past keeps teaching that shell ecosystems are sticky because they accumulate habits:
- startup profiles,
- prompt helpers,
- per-directory tool activation,
- directory-memory shortcuts,
- and persistent history stores.

A new shell+terminal fails if it asks people to give all of that up in one cliff jump.
But it also fails if it imports all of it as ambient authority and calls that compatibility.
That is exactly the seam Schell can improve without choosing one final import format, one final plugin ABI, or one final migration wizard too early.

## 1) The past teaches that startup layers multiply faster than people notice

PowerShell's current profile docs are a precise warning.
They say PowerShell supports several profile files for users and hosts, lists four console profile paths, adds host-specific profiles such as VS Code's, and executes them in order.
That is useful, but it also shows how startup authority fans out into a layered matrix.
Schell should learn the lesson directly:
startup convenience compounds into hidden ordering and host-specific behavior long before operators can keep the whole stack in their head.
See: https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_profiles?view=powershell-7.5

## 2) Oils proves that the upgrade path itself can be the product

The current Oils materials still present the project as an upgrade path from Bash, with OSH running existing shell scripts and YSH offering a smoother path where old and new constructs can live side by side.
That is a major clue for Schell.
The correct migration story is probably not “replace the old shell in one cutover.”
It is more like:
- exact legacy bridge first,
- side-by-side native surfaces second,
- and native truth gradually winning because it is clearer.
Schell should steal that humility aggressively. See: https://oils.pub/ and https://oils.pub/release/latest/doc/ysh-faq.html

## 3) Elvish proves interactive state and script execution should not be the same thing

The current Elvish command docs say interactive Elvish executes an RC file and uses a database file for command and directory history, while running a script does not evaluate the RC file.
Its store API also exposes the persistent command/directory store explicitly.
That is a great boundary.
Schell should steal the idea that:
- interactive convenience state,
- persistent history state,
- and exact script/noninteractive execution
should be separately named instead of collapsing into one vague “the shell session knows stuff” story.
See: https://elv.sh/ref/command.html and https://elv.sh/ref/store.html

## 4) Powerlevel10k proves prompt luxury gets much better when context is timely and retired

Powerlevel10k's current README still shows three especially stealable ideas.
It has Instant Prompt for immediate startup feedback, Show On Command for revealing context segments only when the typed command makes them relevant, and Transient Prompt for trimming older prompts after command acceptance so scrollback is easier to read.
Those are all brilliant.
Schell should steal them, but with one improvement:
retired prompts should leave explicit breadcrumbs for what mattered — cwd basis, failure badge, maybe timestamp or target context — so prompt retirement never turns command history into forensic guesswork.
See: https://github.com/romkatv/powerlevel10k/blob/master/README.md

## 5) Directory memory is a superpower, but ranking should stay visibly weaker than exact navigation

Elvish's location mode remembers directories and lets the operator filter/select them.
zoxide likewise remembers frequently used directories and lets operators jump to them in a few keystrokes, including interactive selection.
That is worth stealing.
But the trick should stay honest.
A ranked path suggestion is not the same as an exact reviewed target.
Schell should therefore keep directory-memory comfort on a visible chooser ladder with ranking provenance, reset controls, and exact-reveal before stronger actions.
See: https://elv.sh/learn/first-commands.html and https://github.com/ajeetdsouza/zoxide

## 6) mise proves one-off execution rails are better than pretending prompt-hook mutation is the only path

The current mise FAQ says `mise activate` installs a shell hook that runs `mise hook-env` every time the prompt is displayed, but it also says non-interactive sessions should use manual `mise hook-env`, shims, or one-off command forms like `mise x -- ...`.
That is a hugely important lesson.
Tool and env activation should have distinct rungs:
- observe only,
- preview the env diff,
- one-shot execution with the overlay,
- session activation,
- and only then longer-lived project posture.
Schell should steal the one-shot rail and refuse the idea that repeated prompt-time mutation is the only humane workflow. See: https://mise.jdx.dev/faq.html

## 7) The best no-regret migration moves now look very strong

The current stealable move set is now clearer:
1. **compatibility report cards** that inventory imported profiles, hooks, history stores, and ranking helpers before anything is enabled,
2. **shadow packs** that let native and bridged behavior run side by side in compare mode,
3. **activation ladders** that separate observe / one-shot / session / project posture,
4. **retired-prompt breadcrumbs** that keep scrollback dense without erasing execution context,
5. **directory-memory decks** with provenance badges and exact-reveal before jump,
6. **interactive state wallets** that say what is stored locally, what syncs, and what never affects script truth,
7. and **claim-strength chrome** that can say native / bridged / degraded / guessed at every migration seam.

That is enough to make Schell feel merciful, modern, and distinctly better than legacy shells without freezing one final compatibility stack.

## 8) What Schell should absolutely refuse

Schell should refuse:
- importing arbitrary rc/profile stacks as the native default,
- turning prompt hooks into invisible env authority,
- replacing exact `cd` / `open` / `run` review with ranked guesses,
- letting imported history or directory stores silently widen shell truth,
- and letting “migration” become a flattering word for ambient startup injection.

## 9) Decisions intentionally kept open

This pass does **not** freeze:
- one universal legacy-profile import format,
- one final migration wizard or onboarding flow,
- one final directory-ranking algorithm,
- one final prompt retirement breadcrumb schema,
- one final compatibility ABI,
- or one final tool/env activation model.

The no-regret move is smaller:
**make migration explicit with report cards, shadow packs, activation ladders, retired-prompt breadcrumbs, directory-memory decks, and interactive-state wallets while keeping every compatibility bridge visibly weaker than native shell truth.**
