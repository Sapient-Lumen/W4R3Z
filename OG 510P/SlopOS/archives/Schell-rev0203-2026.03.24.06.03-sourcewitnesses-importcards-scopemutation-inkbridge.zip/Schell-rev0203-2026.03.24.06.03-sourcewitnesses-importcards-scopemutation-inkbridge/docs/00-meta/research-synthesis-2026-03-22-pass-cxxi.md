# Research synthesis, pass CXXI (2026-03-22)

This pass keeps one narrower lesson explicit:
**Schell should treat semantic prompt/output marks as provenance-graded observations, not self-authenticating truth.**

The strongest current evidence is unusually direct.
VS Code says its `OSC 633` shell-integration sequences can be emitted by any application capable of writing them, and says the optional nonce on the explicit-command sequence is there to verify the sequence came from the shell integration script and prevent command spoofing.
That single detail is a design gift: semantic terminal luxury is real, but provenance still matters.

The rest of the ecosystem reinforces the same lesson from different angles.
Ghostty 1.3 makes semantic prompts more powerful through click-events, better OSC 133 handling, and a debug overlay in its inspector.
fish documents OSC 133 prompt/command markers plus kitty-style click-events and command-line carriage.
Nushell 0.111 adds richer prompt-role semantics and click-events in semantic-prompt-aware terminals.
kitty turns prompt marks and cwd reporting directly into jump-to-prompt, output browsing, and same-cwd comfort.
tmux can preserve or reshape these semantics only through explicit passthrough/relay posture.

taken together, the design-phase answer for Schell is clear:

## 1) Keep semantic provenance separate from semantic presence

A visible mark should not answer all of these questions at once:
- was a mark present,
- who emitted it,
- whether that emitter is reviewed or native,
- whether the current session proved continuity,
- and whether the mark is still live enough for stronger affordances.

Those should become compact independent fields.

## 2) Use provenance grades rather than one boolean trust bit

A useful early ladder is:
- shell-native attested,
- nonce-verified helper,
- reviewed helper without strong verification,
- relay-preserved/unverified,
- heuristic/inferred,
- restored/historical.

That is enough to keep action gating honest without overbuilding the final protocol stack.

## 3) Let action strength depend on provenance grade

Lower grades can still unlock delightful features such as:
- prompt/output navigation,
- output selection,
- sticky command context,
- and semantic inspectors.

Higher grades can unlock:
- active-prompt click editing,
- stronger exact-command display,
- same-cwd spawn borrowing live cwd truth,
- and review-first rerun paths.

The strongest actions should still depend on shell-owned reviewed action objects rather than on renderer chrome alone.

## 4) Steal one especially good idea: semantic canaries

The fixture orchard should not only compare projected versus observed bytes.
It should also keep a compact notion of whether the semantic path was:
- matched,
- downgraded,
- stripped,
- contradictory,
- or merely inferred.

That gives Schell a practical provenance debugger and a better operator explanation surface.

## 5) Compact answer

Schell does **not** need one final authenticated prompt protocol right now.
It needs a bounded move:
- provenance grades,
- optional nonce/session-proof rails,
- cheap downgrade confession,
- provenance-aware action gates,
- and inspector/specimen support for spoof, strip, and mismatch cases.

That keeps the architecture open while making the custom shell+terminal meaningfully safer and more trustworthy.
