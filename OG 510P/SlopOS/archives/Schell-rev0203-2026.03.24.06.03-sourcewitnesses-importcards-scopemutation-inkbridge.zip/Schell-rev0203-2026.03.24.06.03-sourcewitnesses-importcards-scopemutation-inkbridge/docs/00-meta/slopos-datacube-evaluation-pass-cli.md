# SlopOS datacube evaluation — pass CLI

This pass asks a narrower companion-safe question than “should Schell have richer live dashboards?”
The better question is:
**how should Schell steal redraw-heavy terminal luxury without letting mutable screen furniture impersonate stable shell truth or companion-cube state?**

## 1) SlopOS keeps rejecting the shortcut from convenient presentation to current fact

Even while still in design phase, SlopOS repeatedly refuses to let helpful presentation layers become authority.
Its request-vs-provider-live-state posture refuses the move from accepted request to current fact.
Its OpenURI boundaries refuse to let recents, completion, navigation convenience, or provider-local context silently regrow a second truth plane.
Its ordering-token and request-context postures keep context and ordering evidence scope-bearing rather than display-driven.

That is the direct Schell companion lesson:
**a redraw-heavy region can be very helpful, but it should still remain weaker than fresh shell-owned truth unless explicitly frozen or promoted.**

## 2) ViewFS reinforces freeze-before-apply discipline

ViewFS already keeps basis cards, sync watermarks, continuation cursors, gap verdicts, rebuilt snapshots, apply sessions, and receipts as separate objects.
That is strong pressure against treating a mutating watch row or repainting diff summary as “good enough” basis for stronger action.

Schell should therefore treat redraw-heavy regions as weaker witnesses until the operator freezes a stable snapshot or basis card.
That keeps live watch comfort from quietly becoming apply authority.

## 3) Steward reinforces the split between live countdown comfort and durable outcome truth

Steward’s retry advice, pushback, countdown rails, freshness posture, and completion/receipt discipline all point the same way.
A live countdown or changing retry strip is useful, but it is not the same thing as a durable completion, a stable denial, or a reviewable receipt.

That suggests Schell should distinguish:
- live changing status,
- final residue intentionally left behind,
- and durable receipt or denial objects.

## 4) Helm reinforces change-cursor/reset-card honesty for mutable regions too

Helm already pushes current-live truth, last-seen posture, caught-up-through posture, and reset-required posture apart.
That pressure applies directly to redraw-heavy terminal regions.
A spinner row, progress strip, or transient dashboard can have a last frame, a caught-up-through frame, or a reset card, but it should not quietly borrow current-live authority just because it still occupies screen space.

## 5) What Schell should steal now

Schell should steal several excellent ideas, but import them as weaker-than-live redraw witnesses:
- live progress strips,
- bottom toolbars and side status bars,
- transient dashboards,
- print-above lanes for stable textual events,
- freeze cards before strong copy/open/share acts,
- explicit final-residue versus transient-gone policy,
- and accessible static-text downgrade paths when rapid repaint stops being humane.

## 6) What Schell should refuse now

Schell should refuse:
- letting a mutable region be the thing you directly copy/open/share without freezing it first,
- treating the last-painted frame as durable transcript truth by default,
- recording every repaint as if it were meaningful event history,
- turning screen-local progress furniture into approval, receipt, or current-live authority,
- and assuming one animation model will behave consistently across terminals, muxes, remote hops, and assistive technology.

## 7) Compact conclusion

The companion-safe answer is not to avoid live terminal luxury.
It is to make that luxury **visibly weaker, explicitly freezeable, and residue-aware**.
If Schell models live row witnesses, print-above lanes, freeze cards, final residue, transient disappearance, and accessibility downgrade explicitly, it can steal a lot of delight while staying aligned with SlopOS exactness during the design phase.
