# SlopOS datacube evaluation, pass CXX (2026-03-22)

This pass evaluates one narrower question against the current companion archives:
**what do SlopOS and the nearby datacubes teach Schell about proving shell+terminal semantics across terminals, relays, and replay paths without choosing the final transport architecture too early?**

The answer is crisp:
**treat compatibility as a specimen-and-loss discipline, not a prose promise.**

## 1) SlopOS keeps pushing toward toolable proofs

The SlopOS archive repeatedly favors bounded invariants, evidence hooks, golden fixtures, and small proof obligations over hand-wavy descriptive comfort.
That is exactly the right lesson for shell+terminal semantics.
A shell integration story that only lives in README prose or terminal-specific helper snippets is still too weak.
Schell should prefer:
- shell-owned semantic specimens,
- projection fixtures,
- observed-capture fixtures,
- explicit loss records,
- and compact evidence hooks for each stronger affordance.

## 2) SlopOS also keeps internal truth stronger than exported shape

Across the companion archive, exported artifacts remain weaker than live internal authority.
That transfers directly.
A terminal projection should remain weaker than shell-owned semantic truth.
The fixture orchard should therefore compare internal truth against projected and observed surfaces rather than letting any external family define correctness.

## 3) ViewFS reinforces source-class and state-class discipline

ViewFS repeatedly keeps origin class and state class visible.
That is a great fit for terminal specimens.
Schell should preserve whether a specimen is:
- live native projection,
- relayed projection,
- terminal-local inference,
- restored state,
- or historical replay.

Those are different truth classes and should stay visible in fixtures and UI alike.

## 4) Steward reinforces freshness-badged chrome and compact vocabularies

Steward keeps teaching the same healthy instinct:
trustworthy chrome should confess freshness and source, and giant universal matrices are less useful than compact precise vocabularies.
That suggests Schell should maintain a smaller specimen orchard and loss atlas rather than an overambitious protocol encyclopedia.

## 5) Companion-safe no-regret move

Schell does **not** need to freeze one universal shell-integration protocol, one definitive mux relay stack, or one final interop matrix.
It only needs a few bounded rules:

### A) Keep one shell-owned semantic specimen format
This is the internal truth carrier.

### B) Keep explicit projection fixtures
This is how one shell-known fact becomes several terminal family emissions.

### C) Keep observed-capture fixtures
This is how real behavior stays comparable across terminals and relays.

### D) Keep a named loss atlas
Dropped, degraded, relayed, historical, and unverified states should be visible.

### E) Keep UI/debug specimens
Profile chips, loss strips, semantic overlays, and disabled-action reasons should be testable objects, not only product aspirations.

## 6) Compact conclusion

The SlopOS-compatible answer is not “pick the best protocol and standardize on it.”
It is:
**build a shell-owned specimen orchard, compare intended projection to observed capture, preserve source/freshness class, and archive projection losses as named facts.**

That is a very design-phase-safe move because it increases rigor and delight at the same time while keeping the big irreversible transport decisions open.
