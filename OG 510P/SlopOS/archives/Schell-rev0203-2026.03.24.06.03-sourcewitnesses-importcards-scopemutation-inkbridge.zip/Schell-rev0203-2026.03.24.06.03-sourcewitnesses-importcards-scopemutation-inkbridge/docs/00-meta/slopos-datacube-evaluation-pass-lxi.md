# SlopOS datacube evaluation, pass LXI (2026-03-21)

This pass evaluates one new companion import:
**Schell should absolutely gain narrative runbooks and notebook-like chapterbooks, but SlopOS pressure says prose, runnable shell chapters, reactive cells, durable document identity, and published/shareable artifacts must stay separately named so opening a page never silently becomes execution, persistence, or authority transfer.**

## 1) Document-portal posture pressures explicit persistence for chapterbooks

SlopOS's document-portal posture is explicit that persistence is not ambient.
Chooser defaults stay ephemeral, and a durable CH-DOCREF with `persistent=true` is minted only when the user or policy explicitly asks for persistence.
That imports directly into Schell.
A narrative shell page can absolutely start as a scratch artifact.
But promoting it into a durable chapterbook/runbook should be a separately named move, not an invisible side effect of opening, inserting, or sharing.

## 2) CH-DOCREF non-bearer posture pressures safer reopen semantics

SlopOS also pins CH-DOCREF as non-bearer and origin-bound.
Reopen authenticates the caller, re-applies policy, and does not widen rights or target scope.
That is a wonderful lesson for Schell chapterbooks.
A durable runbook handle should not itself mean “this page may now execute or grant the referenced repo/files/services.”
Reopen should recover the document, not silently recover ambient execution authority.

## 3) OpenURI materialization posture says opening a narrative artifact must stay weaker than importing durable local objects

SlopOS's OpenURI materialization boundary is explicit that generic URI launch does not mint local objects, downloads, staged copies, or docrefs.
That should shape Schell too.
Clicking a chapterbook link, opening a help page, or viewing a published runbook should not silently create a durable local runbook object or a new executable project artifact.
If durable local identity matters, that should route through a separate explicit document workflow.

## 4) Resource-grant posture says chapterbooks must not smuggle file/repo/service authority

The OpenURI resource-grant boundary says generic launch is not a portable resource grant, attachment grant, or security-scope handoff.
That matters a lot for shell+terminal runbooks.
A chapterbook can mention files, services, repos, and peers.
It can even point at exact command chapters that refer to them.
But the page itself should not silently grant those objects just because it was opened, shared, or reopened.

## 5) Subject-echo and recents posture pressure smaller durable receipts

Recent-item and subject-echo boundaries also matter here.
A runbook title, chapter summary, or exported digest may be great durable evidence.
A full secret-bearing command line, raw tokenized URL, or highly specific incident subject should not automatically harden into durable recents/history or literal reopen text merely because a chapterbook exists.
That keeps chapterbooks useful without making them accidental history amplifiers.

## 6) The notebook lesson SlopOS most wants Schell to learn

Under current SlopOS pressure, Schell should refuse:
- auto-running shell-bearing blocks on open or reopen,
- silent promotion of scratch notes into durable runbooks,
- durable handles that act like bearer execution tickets,
- runbook pages that silently grant underlying file/service authority,
- and blended receipts that confuse historical output, live runtime state, and durable document identity.

## 7) The clean import: chapterbook witnesses with explicit persistence and runtime posture

A SlopOS-compatible import now looks like this:
- every durable runbook promotion carries an explicit **chapterbook witness**,
- prose blocks, exact command chapters, runtime cells, historical output artifacts, and durable document handles stay separately named,
- default shell-bearing actions prefer **insert into active input** rather than auto-run,
- stronger runtime cells show exact runtime kind and whether their output is live or historical,
- durable reopen recovers the document handle but stays weaker than execution,
- and chapterbooks keep sharing/publication as a second workflow rather than collapsing it into document open.

## 8) Decision-light next move

A strong next move is to define one **chapterbook witness / narrative-cell / state-order humility** family that proves:
- exact chapter reuse,
- parameterized recovery steps,
- reactive/runtime cells,
- durable document promotion,
- and bounded reopen/publish flows
can coexist without turning Schell into either a hidden notebook kernel or an ambient document-authority broker.

That keeps Schell ambitious while learning the right lesson from SlopOS:
**a narrative shell document can be delightful, but persistence, reopen, execution, and object authority must stay separately admitted.**
