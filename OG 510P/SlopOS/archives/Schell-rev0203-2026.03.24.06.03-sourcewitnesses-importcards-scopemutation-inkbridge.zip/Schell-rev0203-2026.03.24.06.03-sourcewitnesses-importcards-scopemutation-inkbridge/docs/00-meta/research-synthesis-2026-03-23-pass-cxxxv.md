# Research synthesis — 2026-03-23 — pass CXXXV

This pass sharpens one fresh shell+terminal lesson from current upstream docs:
**the best modern terminal luxuries increasingly stop one step short of execution.**
Command search, snippets, scratchpads, and AI helpers keep landing on the same humane shape: summon or generate something, place it into an editable input or draft surface, and leave the final spend for later review.

## 1) Warp is explicit that rich search lands in the editor first

Warp's current Command Search docs say the panel searches across Command History, Workflows, Environment Variables, Notebooks, Prompts, and agent conversation history.
The key detail is the action: pressing Enter inputs the selected command into Warp's **Input Editor**.
That is a very important product choice.
Even when the result comes from a broad, powerful search across many command-like objects, the default endpoint is still editable input rather than immediate execution.

## 2) VS Code keeps “recall” and “run” split even inside its recent-command flow

VS Code's shell-integration docs say Run Recent Command draws from the current session's history, previous session history for the shell type, and the common shell history file.
But the stronger lesson is the affordance split:
- a clipboard icon can open command output in an editor,
- the pin action can hold commands near the top,
- and holding Alt writes the selected text to the terminal **without running it**.

That is a near-perfect insert-first design cue for Schell.
A terminal can be fast and confident without pretending that every strong suggestion is already an action.

## 3) Windows Terminal is now openly building non-terminal draft surfaces

Windows Terminal Preview 1.21 says terminal panes were refactored to host non-terminal content and introduces an experimental **Scratchpad** that opens a textbox in a separate terminal pane.
That is a stronger signal than it may seem.
It means even a mainstream terminal is admitting that operators sometimes need a real drafting surface *inside* terminal context that is not identical to the PTY input line.

## 4) Its Snippets Pane strengthens the same lesson

Windows Terminal Preview 1.22 adds a **Snippets Pane** that shows saved commands and lets the user send them to the command line.
The same release says snippets can appear in the Suggestions UI and can be saved directly from the command line with `wt x-save`.
Again, the interesting product choice is not “saved commands exist.”
It is that modern terminal UX keeps distinguishing:
- saved snippet object,
- visible snippet row,
- sent-to-command-line text,
- and later execution.

## 5) Terminal Chat in Windows Terminal doubles down on copy-not-run

Microsoft's GitHub Copilot in Windows Terminal writeup says clicking a Terminal Chat suggestion copies it to the input line and that Terminal Chat will **not run the suggestion automatically**.
That is exactly the sort of humility a custom shell+terminal should steal.
AI help becomes much safer and often more useful when it soft-lands into editable input instead of trying to complete the action for the operator.

## 6) The ecosystem is converging on a real intermediate class

Taken together, these sources keep rediscovering the same missing object:
not just history, not just workflow, not just suggestion, and not yet execution.
The right name for Schell is probably some combination of:
- **parked draft**
- **soft commit**
- **inserted candidate**
- or **draft shelf item**

The exact vocabulary can remain open.
But the product truth is already visible: “placed into editable input” is a distinct state with its own provenance and safety posture.

## 7) The stealable move is not more automation — it is better staging

The most valuable idea to steal here is small:
**treat insertion into input as a first-class, source-labeled, reviewable event.**

That unlocks a lot:
- command-search rows that become drafts instead of actions,
- snippets that can be parked, forked, or promoted later,
- scratch panes that stay weaker than history and workflows,
- assistant answers that become editable candidates,
- and repair/replay flows that can stop at insert or park instead of overclaiming certainty.

## 8) Compact conclusion

The current ecosystem keeps proving that the nicest terminal affordances are often **soft landings**.
Warp inserts into an editor.
VS Code can write without running.
Windows Terminal adds scratchpads and snippet send-to-input flows.
Terminal Chat copies suggestions to the input line but refuses to auto-run them.

Schell should take the hint.
It needs a first-class parked-draft / soft-commit seam so modern convenience can remain luxurious without letting “sent to input” impersonate “reviewed” or “executed.”
