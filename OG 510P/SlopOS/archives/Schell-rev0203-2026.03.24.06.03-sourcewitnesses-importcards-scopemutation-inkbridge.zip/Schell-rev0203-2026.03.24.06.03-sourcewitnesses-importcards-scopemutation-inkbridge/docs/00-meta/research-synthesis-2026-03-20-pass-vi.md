# Research synthesis — pass VI

This pass asks a stricter question than pass V:
**which present-day shell and terminal ideas are good enough to steal now, and which only become safe once Schell has stronger trust gates and basis discipline?**

## Lessons we must learn from the past

### 1) Shell-emitted semantic boundaries have won

Current official docs from VS Code, Windows Terminal, WezTerm, Ghostty, and iTerm2/FinalTerm lineage all point the same way: terminals get materially better when the shell marks prompt, command, and output boundaries explicitly.

Local law for Schell:

> do not build the custom terminal on prompt scraping if the shell can tell the truth directly.

### 2) Confidence and trust are different, and both matter

VS Code is especially useful because it separates low/medium/high command-line confidence and also marks whether a command line is trusted, with nonce-backed verification for the strongest case.
That is one of the best current models for Schell.

Local law for Schell:

- confidence is about how well the terminal reconstructed something,
- trust is about whether the shell actually vouched for it,
- and action gates should care about both.

### 3) Active input should behave like a field, not like dead terminal glass

Ghostty’s prompt click support and shell integration docs show the value of treating the active prompt as editable structure rather than mere pixels.
Recent Ghostty work also leans hard on better OSC 133 accuracy and prompt-aware behaviors.

Local law for Schell:

- let active input feel field-like,
- keep historical output non-editable by default,
- and degrade safely when marks are weak or absent.

### 4) Focus-aware finish notifications are worth stealing

Ghostty’s command-finish notifications are a strong example of a humane feature with low architectural regret.
The good pattern is duration-threshold plus focus awareness, not notification spam.

Local law for Schell:

- notify when the work was long enough and attention moved elsewhere,
- and tie future watch surfaces to reviewed actions or receipt objects rather than raw process folklore.

### 5) Better keyboard/input protocols matter if the terminal becomes richer

kitty’s keyboard protocol is a useful warning that terminal interaction gets shaky when higher-level UX still rides on ambiguous old key encodings.

Local law for Schell:

- keep the shell+terminal input story explicit,
- avoid hidden assumptions about what key sequences mean,
- and treat richer input handling as a protocol surface, not a bag of hacks.

### 6) Humane shell ergonomics are real architecture pressure

fish keeps insisting that user-friendliness and expressiveness do not have to be enemies.
That remains a valuable corrective.
Schell should not confuse explicitness with punishing UX.

### 7) Structured data is compelling, but it is still a whole-project decision

Nushell continues to demonstrate the upside of richer pipelines.
It also continues to remind us that this choice radiates outward into history, introspection, editor affordances, and shell language shape.

Local law for Schell:

- steal typed sidecars,
- delay universal object pipes,
- and do not let pipeline ontology become the first architecture lock-in.

### 8) Generic open and explicit privacy/session control should stay distinct

XDG OpenURI keeps mediated URI launch user-controlled and generic.
Meanwhile current Android and Apple web-auth/browser docs show explicit ephemeral/private session knobs as their own specialized seams.
That difference matters.

Local law for Schell:

- generic open/reveal should stay generic,
- privacy/session control is real and valuable,
- but it should return only as an explicit separate reviewed seam.

## Nifty ideas worth stealing now

### Trusted command-block action gates

Visible blocks should unlock different powers depending on trust grade.
That is a concrete, steal-now improvement.

### Semantic inspector mode

Ghostty’s OSC 133 debug overlay suggests a Schell-native idea: an inspector that shows the truth boundaries of the current view.

What it could reveal:

- prompt start/end,
- active input,
- reviewed action boundary,
- output boundary,
- receipt/denial anchors,
- trust grade,
- and whether the current basis has drifted.

This would be amazing during both product use and product construction.

### Basis-drift alarms

When a command, artifact, or background entry is being acted on through stale assumptions, Schell should say so explicitly.
This is a direct SlopOS-style improvement over “probably still the same.”

### Counterfactual sidecar on denials and stale reruns

DelayBasin’s counterfactual shadow suggests a lovely operator move:
show the nearby rejected action when basis drift or trust weakness blocks the intended one.

### Sticky reviewed-action headers

Keep the currently inspected action or receipt visible while scrolling through long output.
VS Code sticky scroll pressure makes this feel practical rather than speculative.

### Reentry packet / operator landing card

DelayBasin’s reentry discipline suggests a compact shell+terminal landing surface after reopen or restore:

- where you are,
- what is still live,
- what was last reviewed,
- what changed while you were gone,
- and what surfaces are trustworthy first.

### Exact-output export objects

Do not just copy text.
Let operators export or reopen exact receipt-linked outputs when those exist.

## Moves that could make Schell super awesome

### 1) Treat command blocks as first-class objects

Not just selected text.
Objects with trust grade, basis status, receipts, and related outputs.

### 2) Make the terminal self-explanatory in debug mode

Show why a given block is trusted or not, why an action is gated, and what exact shell truth backs the UI.

### 3) Make stale state legible instead of magical

Older receipts, background entries, or launch results should visibly age out of “live confidence.”

### 4) Turn replay into safe navigation, not accidental execution

Readonly replay should feel great and still remain obviously non-live.

### 5) Build humane fallbacks, not fake equivalence

When a powerful action is blocked by weak trust or stale basis, provide the nearest safe alternative without pretending it is the same action.

## Dangerous seductions to refuse for now

### Do not let startup magic become product charm

It will feel great right up until it becomes unreplayable, unreviewable ambient authority.

### Do not let block UI overclaim what it knows

A beautiful block with guessed text is still guessed text.

### Do not turn generic open into browser-profile control

That is a different seam.

### Do not standardize the final input/transport stack yet

We have enough evidence to define gates and boundaries.
We do not yet have enough evidence to freeze the stack.

## Best current research take

Schell should steal:

- shell-emitted semantic boundaries,
- confidence/trust separation,
- active-input field behavior,
- focus-aware finish notifications,
- semantic inspector ideas,
- basis-drift alarms,
- and DelayBasin-style reentry/counterfactual moves.

And it should keep deferring:

- final transport,
- final renderer,
- final plugin model,
- final pipeline ontology,
- and all ambient startup/session magic.
