# SlopOS datacube evaluation, pass LXV (2026-03-22)

This pass evaluates one new companion import:
**Schell should absolutely gain reviewed network-mode witnesses, resolver/proxy posture, and bounded egress receipts, but SlopOS pressure says ambient sockets, ambient DNS, request identity, live lease state, and exact-open URI behavior must stay separately admitted so network truth never collapses into host folklore.**

## 1) D-CAPSHELL already says launch meaning must not inherit ambient sockets or ambient DNS

The companion archive is unusually strong here.
`capshell-network-posture-v0.md` says reviewed `capshell.exec` carries no ambient socket constructors, no ambient resolver baseline, and no “normal machine networking” promise.
Networked behavior routes through explicit D-NETLEASE seams, and if the runtime cannot prevent ambient network widening it must fail closed rather than quietly broaden child authority.
That is exactly the right Schell import.
A reviewed shell surface should say whether the command has no network, private/shared network posture, or explicit leased networking — not leave that hidden in the host/session/runtime.

## 2) D-NETLEASE says network authority is leased, scoped, and redaction-aware

`network-lease-posture-v0.md`, `network-request-schema-v0.md`, and `network-lease-schema-v0.md` add the next important pressure.
They say outbound networking is explicit authority, scope is a reviewed label (`internet | local | loopback | explicit`), resolver binding is explicit, and descriptor exports are redaction-aware rather than casual endpoint dumps.
That is a huge gift to Schell.
It means the shell+terminal does **not** need to guess that every hostname in argv means “internet authority”.
Instead, it can expose one explicit network witness family and stay honest about destination intent, resolver basis, scope, and redaction posture.

## 3) SlopOS separately refuses ambient DNS and ambient proxy-style convenience

The companion archive treats DNS as authority and metadata, not a harmless ambient convenience.
`capshell-network-posture-v0.md` refuses host-global `/etc/resolv.conf` / NSS / service-discovery semantics as portable reviewed meaning.
The D-NETLEASE posture says v0 only admits `resolver.kind="portal"` for lease-bound name resolution.
That pressures Schell toward a stronger design rule:
resolver posture should be a visible first-class witness, and ambient resolver/proxy imports should be marked as degraded or local-compat truth rather than quietly flattened into “the command has network”.

## 4) D-NETLEASE request-state posture says request identity is not live network truth

`network-request-state-posture-v0.md` is another sharp pressure source.
It says `CH-NETREQ.req_id` is a requester-chosen request key for dedupe/review, not a portal-issued live lease handle or current session identifier, and historical request/receipt artifacts do not prove a current active lease.
Schell should import that discipline wholesale.
A network/egress receipt should remain a bounded reviewed-action artifact.
It should not silently become proof of current connectivity, current namespace state, or current destination reachability.

## 5) OpenURI boundaries pressure Schell to keep “open”, “fetch”, and “network authority” separate

The newest SlopOS OpenURI family sharpens another useful lesson.
`openuri-web-permission-boundary-v0.md` says generic `portal.uri.*` launch does not imply a web-permission prompt, browser-tab mediation, or durable web session authority.
`openuri-materialization-boundary-v0.md` separately says generic URI launch does not imply download/materialization/docref minting.
Together they reinforce the same Schell rule:
network and web-adjacent actions need separately named ladders.
A hostname in output, a URL on the command line, an “open” affordance, a fetch/import action, and durable local materialization are not the same object.

## 6) SlopOS's split suggests at least five separate shell-side objects

Putting those companion surfaces together suggests a clean Schell family:
- **network-mode witness** — no network / private loopback-only / joined namespace / shared-host / leased,
- **resolver witness** — none / portal / host-file / explicit override / unknown,
- **proxy witness** — explicit flag / inherited env / workflow default / none,
- **egress receipt** — historical bounded facts about what reviewed action was allowed or attempted,
- **open/fetch/materialize ladder** — separately named web-adjacent stronger actions.

That split matters a lot.
If Schell flattens those objects, it will recreate exactly the ambient-folklore problem SlopOS keeps refusing.

## 7) A compact v0 posture worth stealing

A good early Schell network family should probably say:
- whether launch posture is no-network, private-loopback, joined-namespace, shared/host, leased, or unknown,
- whether resolver posture is none, explicit, ambient-host, portal, or unavailable,
- whether proxy behavior comes from flags, env, workflow defaults, or no proxy,
- whether destination authority is explicit or just text in argv/output,
- whether current status is live or merely historical,
- and whether any egress receipt is exact shell-owned outcome truth or a weaker provider-side/network-side addendum.

That would make network truth much more humane without forcing one final sandbox runtime, portal, or DNS/proxy stack.

## 8) Decision-light next move

A strong next move is to define one **network witness / resolver badge / egress humility** family that proves:
- reviewed network mode,
- explicit resolver/proxy posture,
- separately named open/fetch/materialize ladders,
- and bounded historical egress receipts
can coexist without turning Schell into a host-specific firewall browser, an ambient resolver folklore machine, or a fake portability theater.

That keeps Schell ambitious while learning the right lesson from SlopOS:
**network truth is welcome, but network mode, resolver basis, request identity, open/fetch/materialize semantics, and historical receipts must stay separately admitted.**
