# SlopOS datacube evaluation, pass LXXIX (2026-03-22)

This pass deepens one specific Schell question against current SlopOS pressure:
**how should Schell treat external tools, installer flows, and on-demand command acquisition without letting labels, caches, startup mutations, or third-party source widenings quietly become native authority?**

SlopOS keeps rewarding a smaller answer than the mainstream ecosystem usually offers.
The companion archive repeatedly says: exact authority belongs to explicit selectors, explicit digests, explicit updates, explicit evidence, and explicit admission steps.
That pressure is a very good antidote to package-manager folklore.

## 1) SlopOS keeps rejecting ambient startup and search-path folklore

`capshell-env-startup-posture-v0.md` remains one of the clearest companion pressures in the whole archive.
It explicitly rejects hidden baseline env inheritance and rejects environment-controlled startup or resolution hooks such as `PATH`, `ENV`, `BASH_ENV`, `PYTHONPATH`, `PYTHONHOME`, and `PYTHONSTARTUP`.
That matters directly here.
A modern tool launcher may still helpfully modify `PATH`, shell init files, loader search, or language import paths.
Schell should therefore treat any install flow that wants search-path or startup mutation as a separate reviewed action, never as silent completion of “just run this tool”.

## 2) SlopOS release labels remain observational, which is exactly the right pressure for tool names and versions

`release-identity-boundary-v0.md` says release names, version strings, purls, and handoff slugs are observational distribution identifiers while exact authority stays on digests.
That maps beautifully onto tool acquisition.
The package name `ruff`, the crate name `cargo-nextest`, the tap `alice/homebrew-tap`, or the label `latest` may all be useful operator handles.
But they should stay weaker than exact pinned basis.
Schell should make that visible with source cards and claim-strength badges rather than acting as though package labels are enough.

## 3) SlopOS update posture says install authority must stay digest-bound and narrow

`update-posture-v0.md` keeps CH-UPD small: one exact target cohort, no portable channels/rings/latest-wins semantics, no hidden fetch plan, no package-manager semantics, and no implicit supersession.
That is the right companion pressure for tool-install UX too.
A user may want to:
- run a tool once,
- promote it to the project lock,
- or admit it into a user tool shelf.
Those are different actions.
Schell should keep them as different actions instead of pretending one install button can mean “download whatever the source thinks is current and also make it part of my future shell footing”.

## 4) Supply-chain evidence stays evidence; it does not silently choose what to run

SlopOS keeps SBOM, VEX, provenance, proof bundles, and update evidence on bounded, digest-pinned evidence seams.
That is a powerful import here.
If Schell later shows source provenance, package attestations, or lock evidence for a tool, those artifacts should strengthen understanding of the current proposal; they should not silently replace explicit tool selection or promotion review.
So a future tool-origin card can absolutely show evidence.
It should still keep exact requested source, exact pin posture, and exact promotion target separate from that evidence.

## 5) The strongest Schell move remains a ladder, not a leap

Given the companion pressure, the no-regret acquisition ladder is:
1. **observe need** — command missing or helper requested,
2. **run once** — transient, visibly external, explicitly sourced,
3. **pin exactly** — version/revision/digest or project lock reference,
4. **promote** — explicit write to project environment or user shelf,
5. **mutate startup/search path** — separate reviewed step if still needed,
6. **admit as native pack** — only when that source and promotion are worthy of first-class footing.

That ladder aligns with SlopOS much better than a generic package-manager-shaped install feature.

## 6) What this pass now strongly suggests for Schell

The most companion-compatible moves are:
- **tool-origin cards** with source family, selector strength, cache posture, and promotion target,
- **run-once passes** that remain visibly weaker than project-pinned or native tools,
- **exact-pin rails** for version/tag/rev/lock-backed invocation,
- **promotion ladders** from transient run to project/user/native admission,
- **cache posture badges** so reuse does not impersonate reproducibility,
- **startup-mutation review cards** whenever PATH, shell init, or related footing would change,
- and **refusal badges** for latest-wins, tap-auto-trust, or installer-script folklore.

## 7) Decisions this pass still refuses to make too early

This pass still does **not** force:
- one final Schell package/install subsystem,
- one final provenance or attestation policy for third-party tools,
- one final multi-ecosystem lockfile import layer,
- one final cache eviction or freshness model,
- or one final startup-mutation UX.

The answer stays smaller and stronger:
**let Schell become wonderful at trying, pinning, and promoting tools — but keep source identity, exact basis, cache reuse, and startup mutation separately named so first-run convenience never impersonates durable authority.**
