# Research synthesis — 2026-03-23 — pass CLXXXIX

This pass sharpens one smaller lesson from current shells, terminals, and adjacent simulation systems:
**previews are great, but the shell+terminal gets much more trustworthy when it later records what matched, what missed, and what was never claimed.**

## 1) The shell world already proved preview deserves dignity

PowerShell is still one of the clearest precedents.
`SupportsShouldProcess` turns `WhatIf` and `Confirm` into first-class cmdlet behavior instead of folklore.
That matters because it proves a command surface can dignify `show me what would happen` without pretending preview and execution are the same act.

## 2) Infrastructure tools sharpen the distinction between preview classes

Terraform's CLI and HCP docs are especially instructive.
A speculative plan is explicitly a description of possible changes with no intent to apply it.
Saved plans become a different object because they can later be applied.
That is exactly the kind of split Schell should preserve: descriptive/speculative preview versus stronger apply-capable artifact.

Kubernetes sharpens the point further.
`--dry-run=client` previews the object that would be sent.
`--dry-run=server` runs fuller server-side validation and admission-time checks.
`kubectl diff` then compares the live object with the dry-run result.
This is wonderful pressure for Schell because it demonstrates three distinct local luxuries:
- structural preview,
- stronger simulated validation,
- and compare-versus-live.

## 3) Evaluate-only lanes are worth stealing

GitHub rulesets add another good teaching.
Evaluate mode lets maintainers see what would have passed or failed if the ruleset had been active, and Rule Insights preserves that evidence without immediately enforcing the rule.
That is a powerful idea for Schell:
**a prediction lane can be operationally useful even when it is not yet a spend lane.**

LaunchDarkly's test runs point in the same direction from a different domain.
A targeting change can preview which variation a context would receive and the percentage of contexts expected to receive each variation.
This is a forecast surface, not a durable settlement receipt.
Schell should preserve that distinction when preview becomes coarse or statistical.

## 4) The ecosystem is also warning against simulation overreach

AWS IAM is unusually honest here.
The policy simulator is helpful for testing and troubleshooting policies, but AWS explicitly warns that simulator results can differ from the live environment and recommends checking against live reality after testing.
That is exactly the past lesson Schell should import directly:
**simulation is useful, but the live world still gets a vote.**

OPA offers the missing neighbor: decision logs.
Decision-log events capture policy queried, input, bundle metadata, and related evidence for auditing and offline debugging.
That is not the same thing as simulation.
It is a model for how later observed decision residue should sit beside the earlier preview instead of overwriting it.

## 5) The brilliant idea to steal is not a bigger preview pane

The best move is smaller and more honest:
- preserve the preview claim,
- preserve its exact basis,
- preserve what later happened,
- and preserve the typed gap between them.

That suggests a compact luxury family:
- **preview settlement cards**,
- **outcome-gap strips**,
- **typed miss ledgers**,
- **outside-claim drawers**,
- and maybe later **reliability notes** that summarize repeated miss shape without replacing it.

## 6) The past lesson Schell must not repeat

The historical trap is letting a pretty preview quietly turn into a promise.
That is how shells, policy engines, and admin tools train users to trust the wrong thing.
A `WhatIf`, dry-run, simulated allow, or forecast card should never silently become:
- exact approval basis,
- durable receipt truth,
- current live-state truth,
- or a claim that omitted unknowns never mattered.

## 7) The no-regret Schell move

Schell should add one dedicated surface for:
- preview settlement cards,
- outcome-gap strips,
- miss ledgers,
- outside-claim drawers,
- and compare lanes that preserve old claim versus later receipt.

That imports a genuinely brilliant idea from outside systems while still refusing to choose one final simulator, one preview engine, one policy backend, one telemetry store, or one confidence algebra too early.

## 8) Compact conclusion

The ecosystem is already paying for the lesson:
preview without settlement is charming, but preview plus typed later comparison becomes trustworthy.

So the next low-regret Schell seam is **preview settlements, miss ledgers, and outcome-gap humility**.
