# SlopOS datacube evaluation — 2026-03-23 — pass CLXXVIII

**Schell should introduce tiny snapshot receipts plus explicit cut-watermark posture, because the companion datacubes increasingly separate bounded evidence export, observation sync, current-state truth, and durable replay instead of pretending that a visible terminal slice is already a complete or current record.**

## 1) SlopOS already keeps observation/export narrow in exactly the right way

SlopOS still keeps exact launch, admission, and completion claims narrow.
That remains the hard floor.
But the current companion posture also says:
- observation export is pull-only, bounded, redacted, and policy-killable,
- transcript replication stays immutable digest-addressed evidence only,
- receipt replication stays immutable digest-addressed evidence only,
- imported MCP logging is diagnostic signaling rather than a durable transcript/export substrate,
- and imported MCP progress is liveness signaling rather than a current-state plane.

That is a strong message for Schell.
A visible slice of output is useful evidence, but the architecture is already warning against quietly upgrading such slices into portable current-state truth.

## 2) Steward's snapshot-plus-change and opaque-cursor pressure points to the right shell move

Steward keeps pushing bounded observation subscriptions, snapshot-plus-change views, and opaque caught-up posture instead of teaching clients that silence means everything is current.
Its workspace-snapshot posture also separates remembered arrangement from live process truth.

That is almost a direct specification for the next Schell seam.
When the shell+terminal captures a lane, chapter, or watch deck, it should be able to say what exact cut was taken and what cursor or marker it is synced through, instead of leaving the operator to guess whether the capture is whole, partial, or already stale.

## 3) ViewFS, Ward, and the already-open Schell seams add the rest of the pressure

- **ViewFS** keeps exact basis, explicit apply ladders, and route truth separate, which argues that a captured slice should carry an exact subject/cut witness rather than a flattering “copied from terminal” story.
- **Ward** keeps fresh signals, attenuation, and residue distinct, which argues that old captures and later live updates must stay explicitly separate.
- **Readiness strips** already say whether prompt-aware semantics are live.
- **Stability strips** already say whether the lane is merely ready or warming toward stable current-generation footing.
- **Quiescence strips** already say whether the lane is still flowing, only observationally calm, or explicitly quiescent.

Snapshot receipts should link to those witnesses rather than replacing them.
They answer a different question: **what exact cut did this capture obtain?**

## 4) The companion-safe answer is one tiny snapshot receipt plus cut-watermark posture

The smallest good import is:
- a **snapshot receipt** attached to an attach bundle, replay card, watch snapshot, or export,
- plus an optional **cut watermark** saying what command/chapter/prompt/cursor/bookmark/generation the capture is synced through.

They should say:
- what exact lane/chapter/command/watch row was captured,
- what bounded the cut,
- whether the cut ended in flowing output, at a prompt, at a barrier/bookmark, or only at a local freeze instant,
- whether the capture is exact-command-complete, bounded-partial, visible-only, stream-open, or stale,
- what loss/degradation is known,
- and what the strongest honest next move is now.

That object family is enough to make the shell+terminal meaningfully better while keeping the architecture decision-light.

## 5) What this does not require Schell to decide yet

Snapshot receipts and cut watermarks do **not** require Schell to decide:
- one final transcript/event schema,
- one global replay database,
- one universal watch protocol,
- one full barrier treaty across every runtime,
- one canonical export/publish workflow,
- or any rule that bounded capture automatically equals durable authority.

## 6) Compact conclusion

SlopOS already keeps bounded observation/export narrower than portable current-state truth.
Steward already argues for opaque caught-up posture and honest snapshot-plus-change views.
ViewFS and Ward reinforce exact-subject and freshness/residue discipline.
Readiness, stability, and quiescence seams already cover adjacent truths.

So the next Schell move should be:

**add tiny snapshot receipts and cut-watermark posture so attach bundles, exports, replay cards, and watch snapshots can confess what exact cut of truth they captured, what they are synced through, and what remains partial or stale — without turning bounded capture into fake completion, fake currentness, or fake authority.**
