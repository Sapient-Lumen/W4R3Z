# Research synthesis — 2026-03-23 — pass CXXXVIII

This pass sharpens one fresh shell+terminal lesson from current upstream docs:
**providers, agents, and terminal-adjacent tools increasingly expose live progress, tasks, logs, channels, and deferred results — but those surfaces are useful precisely because they are not automatically shell-owned completion truth.**

## 1) MCP now has distinct utility stories for progress, logging, tasks, and subscribable resources

The current MCP documentation is unusually helpful here because it does not flatten all live activity into one blob.
Its utilities and concepts separate:
- progress updates,
- structured logging,
- tasks as durable state machines with deferred retrieval,
- and resources that can change over time or be subscribed to.

That is a strong signal for Schell.
A host that consumes provider-side liveness should not immediately rename every imported update as shell task truth.

## 2) Claude Code channels make imported liveness feel like a sidecar, not a shell chapter

Claude Code channels are especially clarifying.
The docs describe channels as a research-preview way to send and receive live updates from a CLI session, and they note that channels only stay available while the session remains open unless the user provides a background or persistent terminal arrangement.
They also require explicit sender allowlists and named channel configuration.

That is exactly the kind of thing Schell should notice.
A live provider channel can be very useful, but it is not the same object as a shell-owned command chapter or receipt.
It is provider-local liveness with its own continuity conditions.

## 3) VS Code keeps command context and shell integration separate from helper overlays

Recent VS Code terminal updates continue to expose a healthy split:
- shell integration provides command guide, recent-command context, sticky scroll, and cwd-aware navigation,
- while write-without-run paths and helper affordances still stop short of collapsing every surfaced command into execution.

That reinforces a useful Schell lesson.
The shell can own command truth while nearby helper layers remain assistive, navigational, and reversible.
The right next move is not “make all task/progress UI shell truth,” but “admit assistive sidecars and keep their authority separate.”

## 4) iTerm2 shows how much command-adjacent state can be useful without becoming the command itself

iTerm2's shell integration, captured output, and toolbelt surfaces are another good reminder.
The product can expose recent directories, jobs, snippets, captured-output actions, and search/open affordances without claiming that every surfaced object is a live shell-owned receipt.

That is exactly the kind of stealable move Schell should keep noticing:
more useful nearby objects,
less hidden authority inflation.

## 5) The ecosystem now needs a better distinction than “running” versus “done”

Current tools suggest at least these distinct postures matter:
- provider says running,
- provider says waiting for input,
- provider says done,
- shell launched and still owns,
- shell only mirrored a handle,
- shell restored an old card,
- result available for import,
- and shell emitted a durable receipt.

Those postures are close enough to confuse and different enough to deserve names.

## 6) The stealable move is sidecar honesty, not agent-terminal inflation

The best move to steal is small and sharp:
**let the shell+terminal host provider-local sidecars, task mirrors, result lockers, and input-needed checkpoints — but force them to confess provider ownership, freshness, and weaker-than-shell completion posture.**

That unlocks:
- richer live progress,
- deferred-result retrieval,
- better channel-based collaboration with tools,
- inspectable provider logs,
- and more humane “come back later” operator flows,

without teaching users that every spinner, badge, or later result is already shell truth.

## 7) Compact conclusion

MCP now makes progress, logging, tasks, and changing resources first-class utilities rather than one vague liveness blob.
Claude Code channels prove that live provider communication is useful while still depending on explicit session continuity and allowlists.
VS Code continues to separate shell-owned command context from helper affordances.
iTerm2 continues to show how many command-adjacent objects can be useful without becoming the command itself.

Schell should take the hint.
It needs a first-class split between **provider sidecars**, **mirrored task cards**, **result lockers**, **adopted detached work**, and **shell receipts** so imported liveness can grow dramatically more helpful without impersonating shell-owned completion truth.
