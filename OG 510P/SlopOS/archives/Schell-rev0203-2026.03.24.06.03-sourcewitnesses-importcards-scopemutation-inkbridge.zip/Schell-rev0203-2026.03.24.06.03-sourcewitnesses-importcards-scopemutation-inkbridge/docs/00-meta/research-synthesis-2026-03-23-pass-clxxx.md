# Research synthesis — 2026-03-23 — pass CLXXX

This pass sharpens one fresh lesson from current shell-integration, command-aware terminal, preserved-output, and watch-stream docs:
**the most useful systems increasingly separate exact command boundaries, preserved command-local output, and later live follow — but they still leave room for one smaller glance object above the raw delta stream: a compact answer to _what changed since that cut?_**

## 1) VS Code keeps proving that command-local structure enables small, high-value explanation objects

VS Code's shell integration already turns shell metadata into command detection, decorations, command navigation, output selection, command guides, sticky scroll, and more reliable cwd-aware link handling.
Recent releases then add output streaming for long-running terminal commands and richer terminal/chat attachment flows.

That is an important clue.
The command-local substrate is already good enough to support:
- an exact base command or cut,
- a preserved captured output,
- and a later live continuation.

Once those exist, the next design win is not a giant transcript engine.
It is a smaller object that compresses later change for the operator.

## 2) Ghostty, kitty, Windows Terminal, and fish keep converging on exact boundaries rather than vague scrollback folklore

Ghostty exposes prompt jumps and command-output selection.
kitty lets users jump between prompts and browse the output of the last or last-visited command in a pager.
Windows Terminal now treats marks as stable and documents the same OSC 133 prompt/command/output/finished boundary family.
fish 4.5 reports cwd on every fresh prompt and now also marks prompt end, specifically to keep shell-integration state fresh and less stale.

Taken together, those docs point in the same direction:
exact command/prompt/output boundaries are increasingly real substrate.
That means Schell can safely build a tiny digest object above those boundaries without first deciding a giant protocol.

## 3) Kubernetes still offers the cleanest snapshot-plus-change model to steal

Kubernetes documents `sendInitialEvents=true` for watch requests: build the initial state from synthetic add events, emit a `BOOKMARK` with the synced resource version, then continue with ordinary watch deltas.
It also warns clients not to assume bookmarks appear on any fixed cadence.

That matters because a later-change digest in Schell should not try to replace the raw delta lane.
It should sit above it, saying something like:
- `2 modified rows since bookmark rv=10245`,
- `later output exists through prompt 42`,
- or `reset required; old unseen boundary lost`.

The model is still:
base cut,
then later change,
then a small summary of that later change.
Not one flattened live blob.

## 4) Current terminals prove the luxury, but not yet the final honesty object

The current docs already validate the luxurious half:
- exact command navigation,
- command guides and sticky headers,
- select-output gestures,
- browse-last-command-output affordances,
- and visible output streaming when commands take time.

What they generally do not standardize is the tiny glance object that says, in one bounded sentence, what changed since the operator last trusted a specific cut.
That is precisely why Schell can help without over-deciding.

## 5) The no-regret Schell move is one change-digest card above the since-cut supplement

Putting these together suggests a tighter next move than a watch engine or auto-summary platform.
Schell should add:
- a tiny **change-digest card** linked to a base snapshot receipt and optional since-cut supplement,
- a visible **digest basis** that says whether the answer is counts-only, channel-aware, event-kind-aware, or partial,
- and a compact **first unseen / through watermark / reset posture** story.

The card should say:
- what exact earlier cut it is talking about,
- what exact later-change lane it summarizes,
- what kind of change happened,
- where the first unseen boundary begins when known,
- whether gaps or reset weaken the answer,
- and what the strongest honest next move still is now.

## 6) Compact conclusion

VS Code proves command-local explanation objects are worth building.
Ghostty, kitty, Windows Terminal, and fish prove exact prompt/output boundaries are increasingly real and stable enough to anchor them.
Kubernetes proves that snapshot-plus-change works best when base cut, sync marker, and later deltas stay explicit rather than collapsing into one vague `latest` surface.

So the next no-regret Schell seam is not a giant summary engine.
It is **change-digest cards, what-changed-since posture, and unread humility** so operators can glance at later change without confusing a tiny digest for the raw delta lane, the live lane, or present authority.
