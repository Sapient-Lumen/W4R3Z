# SlopOS datacube evaluation — pass CXL

This pass asks a narrower companion-safe question than “should Schell support prompt clicks, fancy input bars, agent composers, and embedded terminal input?”
The better question is:
**what is the smallest input-host model Schell can add without violating SlopOS exact-footing discipline or letting every editable nearby surface impersonate shell-owned prompt truth?**

## 1) SlopOS pressures Schell toward input-host honesty, not one flattering universal input

SlopOS keeps pressing on a few companion laws:
- exact live footing matters,
- imported or helper-local state should stay weaker than shell-owned truth,
- visible context is not the same as authority,
- and changed basis should stay nameable.

That pressure applies directly here.
If Schell offers several kinds of editable surfaces, the companion-safe answer is not “all input is one thing now.”
The safer answer is closer to:
- shell-owned prompt,
- terminal-owned editor,
- prompt-marked hybrid,
- embedded handback prompt,
- and agent/conversation composer.

## 2) ViewFS again supplies the right object-class instinct

ViewFS has been unusually consistent about refusing to collapse nearby object classes: locator versus live handle, current slot versus copied alias, exec object versus runner, source anchor versus destination anchor.
That pressure is useful here too.
A shell prompt, an editable draft, a sidecar confirmation field, and an agent-composition lane may all look like “some text you can type into,” but they are not the same object class.
Schell should keep them separately nameable before it decides any giant UI architecture.

## 3) Steward sharpens the shell-integration and trusted-chrome edge

Steward already wants shell/terminal integration, trusted chrome, session injection, spawn selectors, and replay gates to confess their footing.
That maps cleanly onto this seam.
If the terminal is only assisting inside a marked live prompt, chrome should say so.
If the terminal owns the editor buffer, chrome should say that too.
If an embedded sidecar has temporarily borrowed focus for input, the handback path should be explicit rather than ambient.

## 4) Helm keeps endorsement narrower than composition convenience

Helm remains the right veto on anything that looks helpful and editable.
Terminal-owned draft text, agent-composed task requests, imported prompt templates, or embedded answers should not quietly become shell-authored reviewed action.
That suggests a healthy promotion ladder here too:
- compose or edit,
- inspect exact bytes / parameters,
- hand off into shell input deliberately,
- and only later run/review strongly enough to mint chapters / launch cards / receipts.

## 5) Companion-safe no-regret move

Schell does **not** need one final universal-input architecture next.
It only needs a compact split between:

- **shell-owned prompt**
- **terminal-owned editor**
- **prompt-marked hybrid**
- **embedded handback prompt**
- **agent/conversation composer**
- **reviewed shell action**

with these rules:
- live prompt editing is the strongest shell-input truth,
- terminal-owned editing can be luxurious while staying weaker until deliberate handoff,
- prompt-click comfort depends on integration quality and should confess that quality,
- embedded prompts advertise who asked and where control returns,
- and agent composition stays separately named even when it later yields shell text.

## 6) Compact conclusion

The companion cubes keep teaching the same law in different accents:
**nearby editable surfaces are useful without becoming the same truth object.**

So the Schell-safe answer is small:
**make input host a first-class witnessed seam.**
That gives the future shell+terminal a real luxury upgrade — better prompt editing, richer drafts, embedded handback prompts, and clearer agent composition — without forcing early decisions about a final UI stack, editor engine, agent terminal constitution, or universal-input doctrine.
