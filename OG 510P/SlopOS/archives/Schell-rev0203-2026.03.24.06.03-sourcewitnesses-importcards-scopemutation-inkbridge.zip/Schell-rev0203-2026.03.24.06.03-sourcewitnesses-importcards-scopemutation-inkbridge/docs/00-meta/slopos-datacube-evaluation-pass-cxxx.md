# SlopOS datacube evaluation, pass CXXX (2026-03-22)

This pass evaluates one narrower question against the current companion archives:
**what do SlopOS, ViewFS, and Steward teach Schell about preserved runtime state, resurrection, and clean-start honesty?**

The answer is crisp:
**continuity should be luxurious, but live authority must still be reacquired explicitly.**

## 1) SlopOS D-CAPSHELL already says exact footing matters more than familiar context

SlopOS RFC-0115 is still the clearest anchor here.
Capability-safe shell execution stays exact about interpreter selection, code-bearing input, wallet footing, and observational-only learn mode.
That means a resurrected pane, a remembered command, or a hidden quick-terminal process cannot borrow fresh authority merely because it feels familiar.
Schell should import that lesson directly.

## 2) SlopOS D-PLUMB says route choices should stay explicit and request-local

RFC-0117 keeps plumb messages canonical but non-authoritative.
That is exactly the right pressure for session comfort too.
A session manager result or cockpit hit should produce a named act:
- attach live,
- restore historical view,
- resurrect behind review,
- relaunch fresh,
- or forget residue.

It should not produce one vague "reopen" action that silently chooses among those.

## 3) ViewFS already warns against restore becoming authority theater

ViewFS keeps repeating that saved state should remain class-aware.
Its non-claims explicitly resist pane/session restore silently rehydrating old authority, and its shell notes keep request objects, live binds, receipts, follow panes, and historical material on visibly separate seams.
That companion pressure is extremely relevant for Schell.
A restored pane should be able to be useful long before it regains any stronger live footing.

## 4) Steward keeps labels, freshness, and session injection honest

Steward's repeated lesson is that shell luxury gets safer once source, freshness, and action family are labeled.
So Schell should keep preserved state visibly tagged as:
- runtime-hidden,
- live-detached,
- resurrectable,
- restored-historical,
- fresh launch,
- or imported transcript.

That will matter more, not less, once the shell+terminal becomes more delightful.

## 5) Companion-compatible no-regret move

Schell does **not** need a final persistence architecture next.
It only needs a few bounded rules:

### A) Keep continuity classes separate
Live attach, runtime-preserved lockers, serialized resurrectables, launch kits, and historical transcripts stay separately named.

### B) Keep clean start and forget/delete explicit
Fresh launch and residue deletion should be first-class verbs, not buried escape hatches.

### C) Keep restored state weaker than fresh review
Resurrected commands, restored outputs, and remembered grounds should ask for reacquisition when they need stronger power.

### D) Keep hint and navigation ladders passive first
Selection, preview, scroll, inspect, and insert can all be fast without becoming hidden run authority.

## 6) Compact conclusion

The companion-safe answer is not "build one giant session brain."
It is:
**build explicit runtime lockers, resurrectable lockers, clean-start rails, and passive navigation ladders so Schell can steal continuity luxury without letting remembered state impersonate fresh authority.**
