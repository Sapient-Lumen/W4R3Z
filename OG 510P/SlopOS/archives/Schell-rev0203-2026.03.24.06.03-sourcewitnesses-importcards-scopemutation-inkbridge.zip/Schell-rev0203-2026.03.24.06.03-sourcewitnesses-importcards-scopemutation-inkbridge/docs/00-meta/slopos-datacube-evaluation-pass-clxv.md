# SlopOS datacube evaluation — pass CLXV

This pass asks a narrower companion question than the last one:
**if SlopOS keeps exact launch tiny and explicit, what is the best next luxury layer for Schell?**

The answer emerging from this pass is:
**chapter inspectors, hover summaries, why/why-not rails, compare-current-basis cards, and watch/attach affordances are the right luxury layer because they reveal exact launch truth instead of trying to replace it.**

## 1) SlopOS already gives Schell the raw material for great inspectors

SlopOS capshell posture keeps making the same disciplined move:
- exact executable selection,
- exact startup closure,
- explicit env and cwd,
- no ambient PATH/session/startup fallback,
- and observational-only learn mode.

That means Schell does not need to invent authority out of hover chrome.
It already has the right eventual sources for an inspector:
- exact exec object,
- exact argv footing,
- explicit cwd/env grounds,
- output/result sidecars,
- and admitted-versus-observed posture.

The inspector is where those truths become humane.

## 2) SlopOS says explanation is better than re-ambientization

Because SlopOS is still in design phase, it is tempting to use the shell+terminal as a place to recover comfort through ambient convenience:
- remembered cwd,
- replay-ready history,
- helper-owned command blocks,
- hover-triggered open/run shortcuts,
- or terminal-local marks that look stronger than they are.

But the companion-safe move is the opposite.
Schell should not re-ambientize execution.
It should **explain exactness better**.

That means a chapter inspector should tell the operator:
- what launch footing was exact,
- what chapter signals are weaker/inferred/imported,
- what changed since the chapter was recorded,
- and why the current action floor is inspect / insert / attach / compare / derive / rerun-after-review.

## 3) ViewFS makes compare-current-basis a first-class shell move

ViewFS pressure keeps saying that visible object, current basis, delta, and adopted result are different objects.
That maps almost perfectly onto chapter replay humility.

A remembered chapter row should not simply say “run again.”
It should support:
- compare then/now basis,
- compare object refs then/now,
- compare activation/env layers then/now,
- and only then a stronger derived or rerun lane.

That makes chapter inspection feel practical rather than ceremonial.

## 4) Helm says chapter endings need settlement cards

Helm’s settlement witness pressure is especially useful here.
A process can:
- start,
- exit,
- drain,
- produce a durable receipt,
- and still fail to reach downstream adoption.

So Schell chapter inspectors should expose compact **settlement cards** rather than one vague success badge.
That makes hovers, history rows, and attach bundles much more honest.

## 5) Harbor says rerun and open must climb visible ladders

Harbor’s risk-ladder posture translates cleanly.
When the inspector shows a file, URL, receipt, or historical command, the next steps should stay separately named:
- inspect,
- reveal,
- insert,
- attach,
- compare current basis,
- derive reviewed action,
- stronger rerun/open only after review.

That is a more companion-safe kind of delight than one universal smart-click story.

## 6) Foundry says overlay and config drift should be legible in the inspector

Foundry keeps warning that activation/config comfort sits on mutable ground.
For Schell, that means chapter inspectors should reveal:
- overlay or activation drift,
- config-layer differences,
- changed tool origin or hook posture,
- and any gates that prevent old footing from being silently restored.

This is exactly where a `why not rerun?` lane becomes valuable.

## 7) Ward and Steward say watch/hover truth must stay source-labeled

Ward’s status-receiver pressure and Steward’s presence/lease pressure both argue that watchfulness is not one thing.
A chapter watch could be:
- shell-owned live status,
- provider-mirrored progress,
- observer-local polling,
- or historical residue.

So watch-this-chapter luxury should stay:
- source-labeled,
- freshness-bearing,
- and lease-shaped.

That makes attention flows feel great without inventing fake liveness.

## 8) The best next Schell steals

The next companion-safe steals are:
- **chapter hover summaries** with provenance, duration, outcome, and action floor,
- **full chapter inspectors** with exact footing links,
- **why-this / why-not rails**,
- **compare-current-basis cards**,
- **watch-this-exact-chapter affordances**,
- **attach exact chapter bundles to help/review lanes**,
- and **settlement cards plus typed object ladders**.

None of these force final closure on protocol, storage, renderer, or automation.
All of them make the future shell+terminal feel much stronger.

## 9) What Schell should still refuse

Schell should still refuse:
- terminal-local chrome pretending to be shell-owned launch truth,
- history rows pretending to be replay-ready authority,
- generic click-to-open or click-to-rerun policy,
- hidden overlay/reactivation of old footing,
- or one final chapter-store / sync / plugin architecture chosen just because the UI got nicer.

## 10) Compact conclusion

The most companion-safe way to make Schell super awesome is now clear:
**keep exact launch tiny, then make command chapters brilliantly inspectable and explainable.**

That is how Schell can enjoy current terminal luxury while SlopOS remains in design phase and while the companion cubes keep warning us not to let comfort residue impersonate exact truth.
