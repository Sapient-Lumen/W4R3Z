# Research synthesis, pass CII (2026-03-22)

This pass keeps one fresh rule in focus:
**a shell+terminal gets much more trustworthy when full-screen life, copy mode, captured output, and durable exact results are treated as different truth families instead of one giant visible-text blur.**

The current ecosystem keeps pointing in the same direction.
xterm still teaches the old alternate-screen lesson.
WezTerm treats copy mode, scrollback, and alternate-buffer wheel behavior as explicit features.
kitty keeps distinguishing scrollback, command-aware output browsing, and screen/scrollback piping.
iTerm2 keeps making captured output, shell integration, and alternate-screen history policy explicit.
Ghostty keeps improving scrollback search and shell-aware prompt behavior while still exposing where terminal-local features begin.

## 1) The old xterm lesson is still load-bearing

xterm's manual and control-sequence docs remain a sharp reminder that the alternate screen buffer is not ordinary saved-lines history.
When the alternate buffer is active, the screen is replaced and ordinary scrolled-off history is not simply the same thing anymore.

That lesson is still foundational for Schell.
A live full-screen program should not automatically collapse into:
- main scrollback,
- durable shell output,
- terminal search index truth,
- or stronger workflow basis.

So the archive should continue separating:
- **live framebuffer truth**,
- **terminal-retained history**,
- **shell-attested command blocks**,
- and **durable result identity**.

## 2) Modern terminals keep proving that copy/search/pager luxury is worth stealing

WezTerm's copy mode, quick select, and scrollback work show that keyboard-first selection and navigation remain valuable.
Ghostty's new scrollback search and native scrollbars make the same point from another direction.
kitty goes further by letting the operator open scrollback or command output in a pager and by treating command-aware output browsing as a real terminal feature.

iTerm2's captured output feature adds another useful idea: large logs and long command output become much easier to work with when interesting lines are indexed and revisitable.

These are all superb ideas for Schell.
But the important synthesis is not “copy mode is the truth now.”
It is:
**observation luxury should be first-class, but it should remain visibly weaker than exact shell-attested command/output truth and much weaker than durable exact result identity.**

## 3) Captured output should remain a derived navigation object

kitty's command-aware paging and iTerm2's captured-output tooling both show that command-local extraction is one of the nicest things a terminal can do.
The operator can return to relevant output without re-running work and without reading giant transcripts top to bottom.

Schell should steal that comfort directly.
But the archive should keep the object model smaller and more honest:
- a **capture row** is a derived index entry,
- a **search hit** is a query result,
- a **pager view** is a reading surface,
- a **chapter/output block** is stronger shell-owned truth,
- and a **durable result capsule** is stronger still.

This is exactly the kind of split that lets the shell+terminal become luxurious without letting the prettiest reading surface choose the execution model.

## 4) Full-screen/TUI life is where ownership must stay explicit

The modern terminal stack now has many overlapping actors:
- the foreground app,
- the shell,
- the terminal itself,
- shell integration helpers,
- copy/search overlays,
- and sometimes local command palettes or pager windows.

That makes ownership the central design question.
When the user scrolls, searches, selects, or presses a key inside a full-screen program, who owns that event and what truth family is being manipulated?

Current docs keep showing that this is a policy seam, not a natural law.
WezTerm documents alternate-buffer wheel translation.
iTerm2 exposes alt-screen scrollback policy as a setting.
kitty distinguishes main-screen scrollback tools from command-aware paging and screen/scrollback piping.
Ghostty's shell-aware prompt behavior only exists when the shell supplies richer structure.

Schell should steal the comfort, but only with visible ownership posture.

## 5) The SlopOS-friendly answer is smaller than “invent a giant terminal object model”

This pass suggests a bounded answer that fits the companion archive well.
Schell does not need to solve every TUI or pager protocol.
It only needs to name a few important differences clearly.

### Must-learn failure families
- visible pixels silently becoming durable shell truth,
- alt-screen residue silently becoming ordinary scrollback,
- copy-mode selections silently becoming app-owned selections,
- captured lines silently becoming exact result identity,
- and search/pager convenience silently becoming a stronger action basis.

### Stealable moves
- searchable scrollback,
- command-aware paging,
- capture decks for interesting lines,
- shell-authenticated jumps back to command chapters,
- source-labeled copy/search overlays,
- and exact-output promotion when stronger shell-owned truth exists.

### No-regret design move
Add a **fullscreen witness** family so Schell can name:
- `view_family`,
- `owner`,
- `source_strength`,
- `overlay_posture`,
- `capture_policy`,
- and `promotion_options`.

That is enough structure to make the terminal feel extraordinary without freezing the final pager stack, scrollback engine, TUI broker, or alt-screen capture policy.

## 6) Compact conclusion

One of the smartest moves available right now is:

**make full-screen life dramatically more luxurious, but keep live framebuffer state, copy/search overlays, captured excerpts, shell-attested output, and durable exact results separately named.**

That lets Schell steal the best modern terminal ideas without letting visibility or navigability impersonate exact execution truth.
