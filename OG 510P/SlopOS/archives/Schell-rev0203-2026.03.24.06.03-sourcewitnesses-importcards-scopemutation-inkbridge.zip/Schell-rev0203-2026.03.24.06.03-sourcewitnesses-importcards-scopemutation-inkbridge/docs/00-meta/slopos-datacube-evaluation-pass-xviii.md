# SlopOS datacube evaluation, pass XVIII

**The shell+terminal should make execution grounds explicit — cwd root, environment capsule, namespace/view posture, and activation state — instead of inheriting them from startup files, prompt hooks, or shell folklore.**

This pass adds another strong SlopOS import.
Schell already knows that approvals bind exact mutable basis and that progress, restoration, ingress, and selection all need explicit truth.
The next seam is the thing a command *stands on* before it runs:
- which cwd root or document/view root it really has,
- which environment variables were deliberately present,
- which activation/profile/toolchain state is live,
- and which pieces are explicit reviewed inputs versus ambient session residue.

SlopOS has unusually crisp pressure here.
Its capshell posture is already telling us that launch grounds should be explicit and fail-closed rather than ambient and flattering.

## 1) SlopOS already rejects ambient execution grounds

The capshell family keeps repeating the same constitutional move:
- no ambient env inheritance,
- no ambient cwd inheritance,
- no implicit startup-profile loading,
- no ambient filesystem reachability,
- and no host-global network / IPC / nondeterminism by accident.

That means Schell should not treat cwd, PATH, HOME-like values, toolchain activation, or view roots as harmless invisible defaults.
They are part of the execution basis.

The direct import for Schell is:
- **execution grounds are basis**,
- not just decoration,
- and not just local terminal convenience.

## 2) CH-ENV and CH-CWD pressure suggests one compact ground packet

SlopOS has CH-ENV and CH-CWD precisely because automation should not inherit shell folklore by omission.
That suggests a very useful Schell object:
**execution ground packet**.

A first packet probably needs only:
- `ground_ref` — exact identity for the current ground,
- `cwd_ref` — exact cwd/view root witness,
- `env_ref` — exact environment-capsule digest or packet,
- `activation_ref` — exact activation/profile/toolchain witness when present,
- `namespace_ref` — optional view / mount / import witness when present,
- `source_family` — default / manual / imported / workflow-bound / restored,
- `drift_flags` — cwd drift / env drift / activation drift / namespace drift,
- `replay_posture` — exact / compare-and-set / inspect-only.

That is enough to make “what ground am I on?” real without freezing a giant workspace model.

## 3) Startup and prompt-time code loading should stay visible if it exists at all

SlopOS is especially clear here.
Its startup-profile posture refuses implicit rc/profile loading and per-directory prompt/cwd code-loading events as portable truth.
Schell should import that caution directly.

This does **not** mean people never want project-local activation.
It means activation should become an explicit object rather than ambient glow.

So if Schell eventually supports project-local activation, a good posture is:
- explicit activation witness,
- exact source files or digests when known,
- visible changed-ground diff,
- replay mode that compares current ground to the reviewed one,
- and no silent rerun on a newer ground just because the prompt happened to refresh.

## 4) View roots and filesystem posture matter to terminal UX too

SlopOS’s filesystem posture says file authority stays on explicit cwd / descriptor / view / portal seams.
That is a very strong hint for Schell’s terminal half.

Rich click-open, path hints, workflow seeds, and reentry affordances get much better when cwd/view truth is explicit.
But that same power becomes slippery if the terminal quietly guesses a host-global root or walks outside the reviewed root because an old shell probably would have.

So Schell should keep the difference between:
- exact cwd/view root,
- nearby guessed path context,
- historical per-block cwd context,
- and generic host browse fallback.

## 5) Activation should be explicit, descriptive, and revocable

SlopOS has activation-handoff and handle-store pressure elsewhere, and that general lesson applies here too:
activation is not the same thing as current live authority.

For Schell, “activation” might mean:
- a toolchain overlay,
- a dev-shell ground,
- a project-local environment packet,
- a loaded workflow profile,
- or a restored historical ground.

Those should be made visible in a compact way:
- what activated,
- who or what activated it,
- what changed,
- how to inspect the exact diff,
- and whether the ground still matches the reviewed basis.

That gives the terminal plenty of room for beautiful UX without making prompt color the only evidence.

## 6) DelayBasin improves the process law

DelayBasin keeps teaching the same hygiene lesson:
if a state matters later, it needs a compact public witness now.

For execution grounds that means:
- keep one exact active-ground witness,
- keep explicit drift triggers,
- keep hold cards when a historical or restored object no longer matches the current ground,
- and keep the receiving surface for “reacquire this ground” or “review the changed ground” explicit.

That is much better than vague messages like “environment changed” or “rerun may behave differently.”

## 7) The terminal should get a lot better once grounds are explicit

This seam unlocks genuinely excellent product moves:
- a tiny **ground strip** for cwd / env / activation posture,
- exact per-command cwd and ground witnesses,
- hover or palette access to “what changed my PATH?”,
- diff cards for activation entry/exit,
- compare-and-set rerun when the ground still matches,
- automatic downgrade to inspect-only when the ground drifted,
- and readonly historical ground views for receipts and replays.

This is “super awesome” in a way that still stays no-regret.

## 8) Transcript truth only needs the important ground transitions

The transcript does not need every shell-local env twitch.
It does need the important truths:
- current ground established,
- ground changed,
- activation entered or exited,
- drift detected relative to reviewed basis,
- rerun downgraded because ground no longer matched,
- and exact closing witness when a command executed under a named ground.

That portable baseline is enough for logs, SSH, replay, and later audit.

## 9) What stays open

This pass still refuses to decide:
- final environment-capsule schema,
- final namespace/view algebra,
- final activation language,
- final dev-shell / toolchain integration set,
- final directory-local policy story,
- and final compatibility bridges for legacy shells.

That is deliberate.
This is a no-regret **ground honesty** pass, not a workspace or package-manager freeze.
