# Question advancement pass (2026-03-20)

This pass exists to prove that the **question machine** changes the archive instead of merely decorating it.

## What advanced this revision

### Q-0001 — Schell / custom-terminal boundary

Advanced from **narrowed** toward a more executable shape by adding a first `minimal-semantic-protocol.md` surface.
This is still reversible.
What changed is that the boundary now has a **candidate split**:

- shell truth,
- semantic transport,
- local luxury UX.

### Q-0002 — smallest portable text-only core

Advanced from **open** to **narrowed**.
The archive now names a first bootstrap answer: portable Schell should preserve text review, text receipts, denial explanations, and exact replay handles even when no rich terminal affordances are available.

### Q-0005 — first end-to-end interaction

Advanced from **narrowed** to **prototyping**.
The archive now carries a more explicit prototype surface in `docs/80-terminal/review-flow-prototype.md`.

### Q-0008 — first Rust stack slice

Advanced from **narrowed** to **prototyping**.
The archive now names a bounded first slice instead of a crate shopping list: `reedline` + `tracing` as the likely first executable pressure, with `ratatui` and `portable-pty` still explicitly deferred.

## What did *not* advance

- Q-0003 (first-class execution artifact)
- Q-0004 (pipeline payload model)
- Q-0006 (background shelf semantics)
- Q-0007 (denial teaching budget)

These remain important, but the archive still gains more by proving a portable reviewed-action path first.

## Why this pass matters

A shell archive tends to accumulate false certainty in one of two ways:

1. it mistakes elegant prose for settled design, or
2. it lets implementation pressure answer unrelated questions by accident.

This pass resists both.
The promoted questions are the ones with the best **bounded proof surfaces** right now.
