# SlopOS datacube evaluation, pass CIV (2026-03-22)

This pass evaluates one narrower question against the current SlopOS archive:
**what does the companion already teach Schell about terminal geometry, resize posture, and the difference between local layout comfort and exact reviewed meaning?**

The answer is stronger than “be careful with resize.”
**SlopOS already pressures Schell to keep geometry comfort, local rendering/layout facts, and reviewed shell meaning as different layers instead of one flattering display story.**

## 1) SlopOS already keeps host↔guest UI/device meaning smaller than nearby pixels suggest

The companion's microVM display/input posture is unusually clarifying here.
Phase 1 exposes no portable ambient guest-visible display/input device contract, no portable `virtio-gpu` scanout/cursor/capset plane, and no portable `virtio-input` device inventory.
UI authority remains on explicit D-UICAP and D-PLUMB seams instead of ambient display/input folklore.

That is direct pressure on Schell.
A local terminal window may know many geometry facts.
But rows, pixels, and layout comfort should still remain weaker than reviewed shell meaning unless a stronger shell-owned witness promotes them.

For Schell this implies:
- realized layout is stronger than config intent, but weaker than exact shell/output truth,
- window/pane geometry is a local UI fact until explicitly attached to a stronger shell-owned witness,
- and geometry comfort should not quietly become authority just because the operator can see it.

## 2) Admission-fixed topology is a useful lesson for resize humility

The companion's microVM memory-topology and CPU-topology postures are equally helpful.
Guest-visible RAM size and guest-visible CPU topology are fixed at admission in Phase 1; changing them means a new reviewed admission rather than mutating a running guest under the same portable identity.

That is a clean lesson for Schell.
Requested or restored geometry may be useful, but the shell+terminal should not quietly pretend a changed live layout is “the same reviewed thing” without explicitly saying:
- what was requested,
- what was realized,
- and what now differs.

In other words, resize should feel humane without laundering drift.

## 3) D-UICAP keeps observation and control on explicit seams

RFC-0080 is also a strong geometry hint even though it is not a terminal-layout doc.
It keeps raw input, display scanout, and secure UI authority on explicit seams and avoids ambient global UI power.
That means geometry, focus, and visible layout are not automatically portable authority facts; they are mediated surfaces.

For Schell this implies:
- prompt/pane/window geometry should remain explicitly witnessed,
- split/zoom/focus/layout actions should remain explicit terminal/editor actions,
- and stronger review or execution meaning should not be inferred just because a layout changed or a viewport now exposes different wrapped lines.

## 4) OpenURI exactness sharpens the reflow lesson

The companion's exact-reveal posture is useful here too.
Show-item exactness refuses to silently degrade into nearby browse.
That is a good model for geometry and reflow.

A copied or inspected excerpt from a resized viewport should not quietly count as exact chapter/output shape just because it is nearby and visible.
Schell should preserve the difference between:
- current viewport rendering,
- locally reflowed display text,
- and stronger exact command/output/result witnesses.

## 5) The companion-compatible shape

This pass therefore recommends a bounded import shape.

### A) Geometry witnesses
Treat requested size, realized window pixels, realized viewport cells, cell metrics, mux/layout policy, and reflow posture as different families.

### B) Request-versus-realized honesty
Let the operator move cleanly from:
- requested geometry,
- to realized local layout,
- to shell-owned command/output witnesses,
- to stronger reviewed action or durable result when that exists.

### C) Reflow humility
Locally wrapped or resized display text remains observation-first unless explicitly promoted through a stronger output/result witness.

### D) Ownership confession
When a mux, window manager, quick-terminal controller, or split system wins the sizing negotiation, Schell should say so instead of pretending the active pane authored the geometry.

## 6) Compact conclusion

SlopOS is still design-phase, but it already gives Schell a practical rule:

**make geometry luxurious as local layout comfort, then promote explicitly into shell-owned witnesses when stronger truth exists.**

That is a careful way to steal modern terminal brilliance without letting rows, pixels, reflow, or resize convenience quietly become shell truth.
