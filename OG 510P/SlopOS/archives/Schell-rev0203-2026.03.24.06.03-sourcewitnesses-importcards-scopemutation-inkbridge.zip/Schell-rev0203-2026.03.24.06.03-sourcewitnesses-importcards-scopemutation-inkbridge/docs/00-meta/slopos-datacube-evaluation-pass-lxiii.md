# SlopOS datacube evaluation, pass LXIII (2026-03-22)

This pass evaluates one new companion import:
**Schell should absolutely gain live watch modes and inspector decks, but SlopOS pressure says subscriptions, observational signals, live request state, metadata-safe rows, and stronger actions must stay separately named so monitoring never becomes ambient background authority, hidden rerun, or implicit exact-target proof.**

## 1) D-ATTRFS already teaches the cleanest saved-view versus live-watch split

SlopOS's D-ATTRFS posture is unusually explicit.
Queries are view-scoped, snapshot-first, and handle-returning.
Live-query mode is optional, revocable, bounded, and must not survive by accident as a hidden background watch.
Saved queries / smart folders remain shell-owned manifests rather than an app-visible inventory or background-watch API.
That maps beautifully onto Schell live inspectors.
A saved deck and a live deck should remain different product shapes, and neither should silently become a hidden worker or ambient watch daemon.

## 2) D-WAITSET pressures observational waiting rather than payload-bearing control planes

RFC-0106 and the pinned waitset posture keep D-WAITSET deliberately observational.
Bindings are explicit, signal bits are observations rather than authority, waits return bounded `{tag, observed_mask}` batches, and the seam explicitly declines packet/control-plane drift.
That is a terrific constraint for Schell.
A live inspector should be able to rely on “something changed” or “this source is readable/terminated/stale” without pretending that the watch lane itself is also the place where stronger commands, payload injection, or hidden workflow logic live.

## 3) D-ATTN request-state posture says visible attention is not the same thing as current live truth

The notification request-state posture gives Schell another vital lesson.
A request artifact is not current portal-owned presentation state, and historical receipts do not prove present visibility, queueing, or acknowledgement.
That same discipline should govern Schell watch surfaces.
A visible panel, past update, or old “live” badge must not stand in for current target truth.
If the subscription is disconnected, paused, overflowed, or reopened from history, the deck should say so rather than borrowing authority from a stale panel.

## 4) Quarantined result-preview posture says inspector rows should stay metadata-safe by default

SlopOS's quarantined result-preview boundary is a direct import here.
Even when the exact result is the right one, metadata-safe rows stay metadata-safe; richer preview is a separate explicit inspect/open step.
That is exactly what Schell needs for live inspectors.
A watch deck full of live updates is one of the easiest places for accidental leakage, because operators get used to hover/peek convenience.
The companion archive says that convenience should remain bounded.

## 5) D-PLUMB and request-local completion posture say watch surfaces should not become hidden workflow buses

The companion archive repeatedly keeps subscriptions and request-local completions smaller than ambient callback buses or hidden workflow daemons.
That is the right lesson for Schell too.
A live inspector may produce explicit row actions, explicit refreshes, or explicit promote-to-target-set flows, but it should not quietly become a second shell or a hidden event-routing substrate just because events are moving through it.

## 6) What this means for Schell

Schell should likely distinguish at least these nearby objects:
- a **watch witness** describing source scope, trigger family, refresh posture, and lag/overflow posture,
- an **inspector deck** for the visible observational surface,
- an **inspector row** that is metadata-safe by default,
- a **rerun policy** for loops that actually rerun commands,
- a **subscription state witness** that is weaker than current target truth,
- and a later **strong action request** that still re-establishes exact target proof.

That split is more or less forced by SlopOS.
If Schell flattens those objects, it will rediscover the same confusion the companion archive keeps refusing elsewhere.

## 7) A compact v0 posture worth stealing

A good early Schell watch family should probably say:
- what is being observed,
- whether refresh comes from polling, fs events, query re-eval, appended logs, or API watch,
- whether the surface is observe-only or reruns/restarts a command,
- what backlog/overflow/disconnect semantics currently apply,
- whether rows are metadata-safe or richer inspect has been explicitly taken,
- and whether a stronger row action still requires singleton proof or reviewed set selection.

That would make live monitoring much more humane without letting it widen into hidden background power.

## 8) Decision-light next move

A strong next move is to define one **watch witness / inspector deck / subscription humility** family that proves:
- repeated-command inspectors,
- file-triggered rerun loops,
- appended-log/live-evidence decks,
- and API-watch-backed resource views
can coexist without turning Schell into an ambient watcher farm, an implicit process supervisor, or a hidden control plane.

That keeps Schell ambitious while learning the right lesson from SlopOS:
**live observation is welcome, but subscription truth, rerun posture, and stronger action authority must stay separately admitted.**
