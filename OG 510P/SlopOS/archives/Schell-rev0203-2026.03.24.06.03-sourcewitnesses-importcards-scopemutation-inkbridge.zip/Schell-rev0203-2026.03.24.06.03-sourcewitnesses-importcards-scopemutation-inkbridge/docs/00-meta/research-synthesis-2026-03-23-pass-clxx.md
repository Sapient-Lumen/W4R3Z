# Research synthesis — 2026-03-23 — pass CLXX

This pass sharpens one fresh lesson from current official platform and terminal docs:
**great shell+terminal comfort should separate present local intent from remembered context, and the strongest actions should often consume that intent instead of stretching one gesture into ambient authority.**

## 1) The web platform already distinguishes user-activation strength

The HTML Standard explicitly separates sticky activation, transient activation, transient-activation-gated APIs, and transient-activation-*consuming* APIs.
That is a very useful lesson for Schell.
A current human gesture is real, but it is not an unlimited budget.
Some actions may allow repeated reveals while stronger ones consume the activation and require another fresh gesture.

## 2) Portals keep shortcut and open actions explicitly user-controlled

The XDG GlobalShortcuts portal makes applications create shortcut sessions and register shortcuts explicitly.
The OpenURI portal says opening URIs happens under the control of the user.
That suggests two strong product lessons for Schell:
- shortcut presence is not itself a permanent authority story,
- and opening or spending stronger actions should stay mediated instead of following remembered rows silently.

## 3) VS Code keeps moving toward exact context attachment and explicit approval

VS Code's terminal surfaces continue to separate context from automatic authority.
Tracked terminal commands can now be attached to chat with exact command line, captured output, and exit code.
At the same time, terminal auto approve is explicit opt-in, carries warnings about security risks, shows which rule applied, and is governed by settings rather than by terminal folklore.
That is exactly the split Schell should steal:
**attach exact context cheaply; spend stronger authority explicitly.**

## 4) Current terminals keep convenience actions fieldwise and partial

Ghostty exposes separate cwd inheritance controls for window, tab, and split.
Windows Terminal documents that duplicate-tab copies profile and directory but not modified or added environment variables, and it separately exposes `--inheritEnvironment`.
WezTerm keeps `SpawnCommand` and optional `cwd` explicit.
These are all reminders that “same context” is partial and host-mediated.
That makes fresh local intent even more important for the stronger end of convenience spawn.

## 5) The no-regret Schell move is a fresh-intent witness, not a giant approval platform

Putting these sources together suggests a better next step than inventing a universal trusted-UI system.
Schell should add a tiny **fresh-intent witness** for strong convenience acts.
That witness should bind one current local gesture to one exact reviewed summary and visibly age through `fresh`, `consumed`, `expired`, `wrong-context`, or `ignored`.
When the witness is missing, the UI should cool to reveal / inspect / stage / review-again rather than guessing harder.

## 6) Compact conclusion

HTML teaches that one gesture need not power unlimited calls.
Portals teach that shortcut and open actions stay user-controlled and session-scoped.
VS Code teaches that exact command context attachment is valuable, while stronger automation still deserves explicit opt-in and visible rules.
Ghostty, Windows Terminal, and WezTerm keep proving that convenience context is fieldwise and partial.

So the next no-regret Schell seam is not another approval cache or shortcut treaty.
It is **fresh-intent witnesses with one-gesture one-spend humility and cheap downgrade to inspect/stage/review** so stronger convenience actions can feel brilliant without letting alert clicks, hotkeys, or remembered command rows quietly become ambient spend authority.
