# SlopOS datacube evaluation, pass LXVIII (2026-03-22)

This pass evaluates one new companion import:
**Schell should absolutely gain reviewed filesystem witnesses, mount-root and cwd-root honesty, bind-overlay warnings, and chooser-mediated file authority, but SlopOS pressure says ambient host filesystem visibility, root-path folklore, and hidden path reopening must stay separate from explicit view/descriptor/portal seams.**

SlopOS is still in design phase too, which makes this a very good time to keep the import small.
The companion archive does not need Schell to invent a universal filesystem browser.
It needs Schell to stop pretending that a prompt path, a root glyph, or an argv string tells the whole story about what files a reviewed action can actually touch.

## 1) SlopOS already says capshell launch must not inherit a normal host filesystem by default

The capshell filesystem-namespace posture says there is **no ambient host filesystem namespace baseline** at `capshell.exec`.
That is a profound shell+terminal lesson.
Schell should not romanticize “the normal host tree” as a silent default just because many existing shells do.
A reviewed action should be able to say:
- explicit view root,
- explicit cwd root,
- explicit descriptor/portal/object grants,
- or degraded compat reachability.

That one distinction prevents a huge amount of filesystem folklore from sneaking back in.

## 2) Cwd-root posture proves cwd is authority, not breadcrumb text

The capshell cwd-root posture says CH-CWD binds a cwd root, not an advisory pathname, and relative path resolution must remain beneath that bound root rather than escaping into ambient parents or host root.
That means Schell should stop treating a pretty cwd breadcrumb as enough truth.
The terminal should have room for:
- visible cwd-root posture,
- visible root/view posture,
- and visible path-resolution guard posture.

Those are related.
They are not identical.

## 3) File authority in SlopOS stays on explicit seams only

The filesystem posture is especially clear about the explicit seams:
- bound cwd roots,
- explicit descriptors / stdio / fdsets,
- explicit view-namespace bindings,
- explicit chooser/portal/document flows.

That maps beautifully into Schell.
The shell can become dramatically nicer if it says *which seam* a file authority came from instead of flattening everything into a guessed pathname.
Examples:
- “descriptor-bound directory authority,”
- “portal-chosen document handle,”
- “view-root subtree,”
- “compat path under bound cwd,”
- “unknown/degraded host path.”

## 4) Powerbox and document-portal posture reinforce handle-first results

SlopOS powerbox posture says chooser mediation stays designation-scoped and chooser-owned, returning concrete capability outcomes rather than ambient names.
The document-portal posture says persistence is explicit, chooser defaults stay ephemeral, reopen is non-bearer, and reopen never widens rights or target scope.
That is exactly the pattern Schell should steal from the outside ecosystem too.
A terminal should be able to say:
- one-shot chosen object,
- persisted reopen handle,
- non-bearer reopen,
- no widening,
- and no generic remembered path grants.

That is much more trustworthy than “Open gave me the file so I guess the app has the folder now.”

## 5) SlopOS also warns against path or root as a hidden second authority plane

Several companion surfaces point in the same direction:
- exec packs do not add a hidden per-step `open(path)` surface,
- filesystem posture rejects host-path baselines as portable promise,
- cwd-root posture rejects ambient parent escape,
- powerbox posture rejects generic remembered-grant libraries,
- document portal posture keeps persistence explicit and non-widening.

Put together, the message for Schell is crisp:
**do not let path strings become a second hidden authority plane beside explicit views, handles, and chooser-mediated grants.**

## 6) Great ideas worth stealing right now

### a) Root/view witness separate from cwd witness
Tiny, powerful, and very honest.

### b) Overlay and shadowing badges
If a subtree is bind-mounted or otherwise shadowing existing content, say so.

### c) Portal/file-choice provenance
Tell the operator when file authority came from explicit chooser designation instead of ambient path reachability.

### d) Persisted-subtree versus one-shot-file distinction
A durable persisted subtree is not the same as a one-time chosen document.

### e) Path-resolution guard posture
Beneath/in-root/no-cross-mount/compat/unknown is a super valuable luxury.

### f) Historical filesystem receipts
Return bounded root/view/cwd/overlay facts without pretending to prove the current live namespace forever.

## 7) Things Schell should refuse

### Refuse host-tree folklore
“The normal host filesystem” should not silently define reviewed meaning.

### Refuse path-string-as-authority
A path literal in argv/env is not enough truth by itself.

### Refuse cwd breadcrumb theater
A visible cwd path should not impersonate root/view authority.

### Refuse bind-mount invisibility
Overlays and shadowing should not surprise the operator after launch.

### Refuse chooser-to-folder widening
One chosen file should not silently become sibling/ancestor discovery.

### Refuse silent persistence
Ephemeral selection and durable reopen should stay different actions.

### Refuse one giant filesystem plane too early
Schell should not yet freeze one universal path API, mount grammar, or sandbox backend.

## 8) The concrete Schell move this supports

The decision-light move is a **filesystem witness** family:
- root/view badge,
- cwd-root badge,
- overlay/bind badge,
- propagation/shadowing posture,
- chooser/portal/document provenance,
- path-resolution guard posture,
- and bounded historical filesystem receipts.

That is enough to make the shell+terminal much more awesome while keeping SlopOS's deeper filesystem, namespace, and portal machinery fully reversible.
