# Research synthesis, pass LXI (2026-03-21)

This pass keeps one fresh design rule in focus:
**Schell should absolutely steal narrative runbooks, notebook-like chapterbooks, and parameterized runnable blocks — but only if prose, runnable command chapters, saved outputs, and durable document identity never collapse into one flattering “this page just is the live shell” story.**

This seam matters because the luxury is real.
Operators do want to explain an incident in prose, pin one reviewed command chapter next to a diagnosis, embed parameterized recovery steps, and publish or reopen that work later.
But the ecosystem also keeps proving that narrative documents, live kernels, reactive runtimes, saved outputs, and trusted execution are not the same thing.
Schell should steal the best bits while keeping opening, inserting, running, persisting, and sharing separately named.

## 1) Warp proves that shell-capable narrative documents are useful when command blocks insert into the terminal instead of silently becoming the terminal

Warp's current notebooks docs are extremely useful here.
They let a command block be selected and inserted into the active terminal session or a new session, rather than forcing execution just because the block exists inside a document.
They also let command blocks accept `{{arguments}}` in the same format as Workflows and support embedding an existing Workflow inside the notebook.
That is a strong Schell clue.
A narrative shell document can be luxurious without pretending the document itself is the shell.
See: https://docs.warp.dev/knowledge-and-collaboration/warp-drive/notebooks
See: https://docs.warp.dev/knowledge-and-collaboration/warp-drive/workflows

## 2) Jupyter proves why narrative + code + output is powerful — and why open is weaker than trust or execution

The current Jupyter docs still show why notebooks became so successful: they combine code, plain-language description, data, rich visualizations, and interactive controls inside one shareable document.
But Jupyter's security docs are the more important lesson for Schell: notebook outputs exist in an execution-capable context, and no code should execute merely because somebody opened a notebook they did not write.
That is a fundamental shell+terminal lesson too.
Opening or focusing a narrative artifact is weaker than trusting it, and trusting it is weaker than admitting exact execution.
See: https://jupyter-notebook.readthedocs.io/en/stable/notebook.html
See: https://jupyter-notebook.readthedocs.io/en/4.x/security.html

## 3) marimo proves that reactive/deterministic notebooks are a serious answer to hidden state

marimo's docs are valuable because they explicitly position reactivity as a fix for traditional hidden-state notebook problems.
marimo says dependent cells rerun or are marked stale, notebooks are stored as pure Python, and the system guarantees consistency between code, outputs, and program state.
Its reactivity docs also say execution order is deterministic and that expensive notebooks can choose a lazier stale-marking posture instead of unconditional rerun.
This is a terrific design clue for Schell.
If Schell ever gains richer non-shell cells, state-order truth must be visible.
See: https://docs.marimo.io/
See: https://docs.marimo.io/guides/reactivity/

## 4) Pluto proves that reactive notebooks can enforce stronger state hygiene than Jupyter-style cell folklore

Pluto's reactivity docs say that dependent cells rerun automatically, deleted definitions are actually removed from global state, and two cells cannot both define the same global variable.
That is a very Schell-compatible lesson.
The point is not “become Pluto.”
The point is that notebook comfort becomes much safer when the system refuses ambiguous lingering state.
See: https://plutojl.org/en/docs/reactivity/

## 5) Observable proves a different but equally useful split: code is live, saved artifacts need not freeze output, and reactivity can power rich narrative documents

Observable's current system guide says notebooks are live, saved notebooks store source code rather than output, and cells rerun reactively when referenced variables change.
That is an important alternative to classic notebook folklore.
A durable narrative artifact does not have to pretend it preserved one eternal live runtime snapshot.
Schell should therefore keep **historical output capture**, **live reactive document**, and **re-runnable chapterbook** separately named.
See: https://observablehq.com/notebook-kit/system-guide

## 6) The dangerous thing to refuse: one generic “runbook page” that hides execution mode, state mode, and persistence mode

The current ecosystem now makes at least five different things easy to flatten into one story:
- prose and annotations,
- exact shell command chapters,
- notebook/runtime cells,
- stored outputs and attachments,
- and durable published/reopened documents.

Those are adjacent.
They are not the same.
Schell should not let one page frame, one publish action, or one “run this doc” button erase those differences.

## 7) The stealable move: chapterbook witnesses and narrative-cell humility

The best decision-light move now looks like this:
1. introduce a **chapterbook witness** family,
2. keep **prose block**, **command chapter block**, **workflow seed block**, **reactive/runtime block**, **historical output artifact**, and **durable document handle** separately named,
3. prefer **insert into active input** as the default action for shell-bearing blocks,
4. let stronger execution paths show exact runtime kind and exact reviewed command shape,
5. distinguish **historical captured output** from **live recomputed output**,
6. keep persistence explicit so a scratch narrative page is weaker than a durable runbook/docref,
7. and keep trust/open/reopen weaker than run.

That would make Schell feel much more capable without freezing one notebook runtime, one cell language mix, one publication stack, one persistence substrate, or one collaboration model.

## 8) A compact first proving slice

A compact proof could show:
- one prose block that cites a failure chapter,
- one exact command chapter block that inserts into input instead of auto-running,
- one parameterized recovery block with visible arguments,
- one embedded workflow seed,
- one historical output artifact explicitly marked non-live,
- one stronger reactive/runtime block with visible runtime kind,
- one durable-promote step that mints a distinct document handle,
- one reopen flow that stays weaker than execution,
- one publish/share lane that still routes through the separate share-witness family,
- and one refusal to auto-run shell-bearing blocks merely because the chapterbook was opened.

That is enough to learn a lot while keeping the big architecture decisions open.
