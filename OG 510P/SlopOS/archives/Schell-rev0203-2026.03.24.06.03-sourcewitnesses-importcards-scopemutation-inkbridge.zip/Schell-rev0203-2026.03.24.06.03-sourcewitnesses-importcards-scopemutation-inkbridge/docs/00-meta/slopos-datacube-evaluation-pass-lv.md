# SlopOS datacube evaluation, pass LV

**If Schell borrows abbreviation or alias luxury, SlopOS says the safe version is still exact reviewed argv plus explicit active-input editing. Shorthand may help compose input, but it must not become hidden command-string parsing, hidden word expansion, hidden startup-profile import, or late executable retargeting.**

This pass focuses on a surprisingly high-leverage seam:
- abbreviations,
- aliases,
- shorthand command names,
- command-scoped expansions,
- and rc/profile-loaded convenience packs.

A custom shell+terminal will obviously want faster typing.
The danger is that shell history trained us to accept shorthand systems that quietly become part of execution semantics.
SlopOS keeps pushing the other way.
It wants reviewed action shape to stay exact, explicit, and authority-aware.
That pressure transfers directly to Schell.

## 1) CH-ARGV still says reviewed launch truth is exact token material, not shorthand folklore

The strongest import remains the same.
Reviewed launch truth is an exact argv object with one explicit executable selector.
That means abbreviation or alias help cannot live as a mysterious side language that "later becomes the real command."
If shorthand exists, it should end in visible editable input or a visibly reviewed argv object before launch.

## 2) Command-string posture refuses the classic alias trap

The capshell command-string posture is especially important here.
It refuses hidden tokenization, hidden shell parsing, and hidden `sh -c` or `system()` adapters.
That means a shorthand feature must not behave like this:
- accept a cute short name,
- expand it into a flattering string,
- and let the runner or helper reparse that string later.

The safe import is much tighter:
**abbreviation expansion must terminate before the execution boundary, not inside it.**

## 3) Word-expansion posture says shorthand cannot hide a second pre-exec expansion phase

SlopOS front-end posture already refuses shell-style word expansion before binding CH-ARGV.
That matters directly for alias and abbreviation design.
A shorthand system cannot become a back door for:
- wildcard expansion,
- tilde/home expansion,
- env lookup,
- command substitution,
- or process substitution
that quietly happens between visible review and actual launch.

So a SlopOS-compatible Schell shorthand feature must stay visibly editorial.
It may replace one typed token with another visible token sequence.
It should not reopen a pre-exec expansion stage.

## 4) Exec-selector posture means shorthand cannot hide executable identity drift

The exact executable selector posture is another direct pressure point.
If a shorthand expands a command name, Schell still needs a visible path from that shorthand to one exact executable selector.
A pleasant label cannot be allowed to conceal:
- PATH lookup,
- mutable name reopen,
- package alias drift,
- or host-specific retargeting.

That suggests a strong rule for Schell:
**abbreviation expansion may help choose an executable, but exact executable identity must become revealable before stronger run/open lanes.**

## 5) Startup-profile posture warns against rc-file shorthand folklore

SlopOS startup posture also matters here.
It explicitly refuses implicit rc/profile files and per-directory activation hooks in Phase 1.
That is a huge clue for Schell.
Traditional alias culture often lives in dotfiles, shared snippets, and per-repo hooks that silently change what commands mean.
SlopOS pushes against exactly that kind of ambient import.

So the safe import is not "load everyone's aliases."
The safe import is closer to:
- explicit shorthand packs,
- visible provenance,
- trust-on-change,
- and interactive-only expansion that never widens into hidden startup behavior by default.

## 6) Plumb posture keeps promotion explicit instead of letting shorthand become a router oracle

The plumb posture is also quietly relevant.
It keeps routing explicit, request-local, and non-oracular.
That means abbreviation or alias systems should not become another hidden dispatch fabric that can:
- inventory handlers,
- pick hidden destinations,
- or widen routing behavior just because a short token was typed.

If shorthand expands into a richer route, that richer route should still show up as its own reviewed object.

## 7) The clean import: abbreviation witnesses, not alias authority

The SlopOS-compatible import now looks like this:
- shorthand lives in active input,
- expansion is previewable and editable,
- command-position and command-scoped rules stay visible,
- executable identity becomes revealable before launch,
- startup/profile import remains explicit rather than ambient,
- and stronger reusable behaviors get promoted into separately named workflow/function artifacts instead of hiding inside alias folklore.

This matches the rest of the archive well.
It preserves typing luxury without giving up exact reviewed action shape.

## 8) What Schell should refuse right now

Under current SlopOS pressure, Schell should refuse:
- runtime alias expansion inside the execution boundary,
- global shorthand that rewrites arbitrary positions on the line,
- rc/profile-loaded shorthand becoming ambient baseline by default,
- expansions that smuggle in shell-style word expansion,
- and shorthand that hides executable retargeting or route selection.

## 9) Decision-light next move

A strong next move is to define one **abbreviation witness** family that proves:
- late expansion,
- command-scoped shorthand,
- cursor landing,
- expansion preview,
- and explicit promote-to-workflow/function moves
can all exist without recreating parse-time alias confusion or hidden execution semantics.

That would keep Schell ambitious while learning the right lesson from SlopOS:
**typing shortcuts are welcome, but exact reviewed launch truth stays stronger than shell folklore.**
