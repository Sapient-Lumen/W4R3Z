# Research synthesis, pass LXX (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should absolutely steal command-aware terminal luxury — semantic marks, command blocks, typed routing, upgraded input, and session recall — but only if startup injection, hidden background helpers, structured-data ambitions, and durable shell truth stay separately named instead of collapsing into one flattering “the terminal understands everything” story.**

This seam matters because the past keeps teaching the same two lessons at once.
First, shells and terminals become much nicer when command boundaries, cwd, object identity, and session continuity are explicit.
Second, they become much less trustworthy when that convenience quietly rides on injected startup code, ambient rc files, hidden helper processes, or terminal-local guesses that overclaim what they know.
That is exactly the seam Schell can improve without choosing one final escape-sequence treaty, one final block wire format, one final PTY replacement, or one final structured-data shell model.

## 1) The most important lesson from the past: startup magic is real authority

The current Bash manual still documents just how many startup paths exist for login shells, interactive non-login shells, non-interactive shells, `sh` mode, and POSIX mode.
VS Code's own docs warn that it may launch an interactive login shell to source the shell environment and that this can cause problems depending on shell setup.
Ghostty's automatic Bash integration is an even sharper clue: it starts Bash in POSIX mode and uses `ENV` to load Ghostty's integration script, making that script responsible for normal startup-file behavior.
That means startup integration is not a cosmetic trick; it is real execution authority.
Schell should treat terminal-supplied shell integration as a named, reviewable footing rather than a harmless default. See: https://www.gnu.org/s/bash/manual/html_node/Bash-Startup-Files.html ; https://code.visualstudio.com/docs/configure/command-line ; https://ghostty.org/docs/features/shell-integration

## 2) Semantic command boundaries are worth stealing

The current crop of terminals has converged on the same thing for a reason.
WezTerm documents `OSC 7` for cwd and `OSC 133` for prompt/input/output zones.
Windows Terminal says shells can write escape sequences that semantically describe “prompt,” “command,” and “output,” which then power marks, command jumps, and whole-command selection.
VS Code says shell integration enables working-directory detection, command detection, decorations, and navigation.
Ghostty lists prompt-aware close behavior, start-new-terminal-in-same-directory behavior, prompt redraw help, and modifier-assisted selection of a command's output.
Schell should steal the semantic boundaries, not the brand-specific UI. See: https://wezterm.org/shell-integration.html ; https://learn.microsoft.com/en-us/windows/terminal/tutorials/shell-integration ; https://code.visualstudio.com/docs/terminal/shell-integration ; https://ghostty.org/docs/features/shell-integration

## 3) Blocks and command chapters are worth stealing, but they are local luxury until proven otherwise

Warp's docs say a Block groups a command and its output into one atomic unit and supports copy, re-input, sharing, bookmarking, and direct scrolling to a command's output.
That is a genuinely good idea.
But Warp's own background-block docs also say background output may be mixed together or misattributed because Warp doesn't always know which process produced it.
The lesson is perfect for Schell: treat command chapters as first-class local navigation objects, but keep claim strength visible whenever provenance is guessed or mixed.
Do not let a beautiful block UI impersonate shell-owned truth. See: https://docs.warp.dev/terminal/blocks ; https://docs.warp.dev/terminal/blocks/background-blocks

## 4) Hidden helper work is powerful, but it should never be invisible policy

Warp's current docs say background commands are used to power features such as completions, syntax highlighting, and command corrections, and that remote sessions may run those commands during idle time in a non-interactive subshell process.
That is a useful product trick and a giant design warning.
Schell should learn the positive lesson — prompt-time delight may need helper work — while refusing the hidden-policy version of it.
If helper work happens, it should be visible as a named lane with budgets, source labels, and a clean way to disable or downgrade it. See: https://docs.warp.dev/terminal/warpify/subshells

## 5) Input upgrades are worth stealing, but only with visible downgrade honesty

The kitty keyboard protocol exists because legacy terminal input collapses too many distinct keystrokes together; the protocol is backward compatible and lets applications opt in to more advanced keyboard handling.
kitty, Ghostty, and WezTerm also all lean on shell integration for prompt navigation and click-to-cursor behavior, while kitty explicitly advertises previous-prompt navigation, last-command paging, and prompt-local cursor placement.
These are exactly the sorts of “super awesome” local luxuries Schell should steal.
But they should live behind explicit capability witnesses so the portable transcript-safe path remains correct when the richer protocol is missing. See: https://sw.kovidgoyal.net/kitty/keyboard-protocol/ ; https://sw.kovidgoyal.net/kitty/shell-integration/ ; https://ghostty.org/docs/features/shell-integration ; https://wezterm.org/shell-integration.html

## 6) Helpful interactive shells teach great UI lessons, but not all of them should define Schell's core semantics

fish's docs still make the strongest case for delight-first interactive help: autosuggestions, syntax highlighting, rich completions, and even completion generation from manual pages.
Nushell's docs make the opposite but equally valuable point: tables, lists, and records can be first-class pipeline data.
PowerShell's docs add one more cautionary clue: objects sent through the pipeline are processed one at a time, and that is meaningfully different from passing a single array parameter.
Put together, these sources suggest a good Schell rule.
Steal fish-style insert-first help aggressively.
Use Nushell/PowerShell-style structure where truth burden is high — receipts, inspectors, object cards, maybe optional query lanes — but do not assume that “everything is structured data now” is the right bootstrap for a shell that still needs transcript truth and PTY compatibility. See: https://fishshell.com/docs/current/ ; https://fishshell.com/docs/current/cmds/fish_update_completions.html ; https://www.nushell.sh/book/navigating_structured_data.html ; https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_pipelines?view=powershell-7.5

## 7) Routing should be typed and explicit, not magical

Plan 9's plumber still feels surprisingly modern: messages are sent to a plumber, examined by rules, and dispatched to ports, which keeps “open this,” “edit that,” and “send here” as explicit routed actions rather than ambient clicks.
That is exactly the kind of thing a shell+terminal should steal.
Visible selections, hyperlinks, paths, receipts, and object cards should turn into typed intent packets with exact subject identity and explicit route posture, not one vague “smart click” action. See: https://9p.io/sys/doc/plumb.html ; https://9fans.github.io/plan9port/man/man4/plumber.html

## 8) Restoration and continuity are worth stealing, but they should stay visibly historical until reacquired

Zellij's docs say sessions are serialized by default and can be resurrected after intentional quit or crash.
That is a great clue for Schell because it proves that session continuity can be product-defining.
But restored state is still not the same thing as current live authority, current peer identity, or current startup footing.
Schell should absolutely steal reentry landing cards, restored panes, and historical command chapters, while keeping restored state visibly weaker than freshly reacquired live truth. See: https://zellij.dev/documentation/session-resurrection.html

## 9) The no-regret move set that now looks strongest

The strongest next moves still look smaller than a full shell-language or terminal-protocol lock-in:
1. **shell-owned semantic marks** for prompt/input/output/receipt zones,
2. **command chapters / blocks with trust grades** instead of one undifferentiated history,
3. **insert-first help and completion luxury** in the fish spirit,
4. **typed object routing** in the Plan 9 plumber spirit,
5. **capability witnesses** for keyboard/input/media luxuries,
6. **reentry cards and restored-state badges** in the Zellij spirit,
7. and **prompt budgets / helper lanes** so background magic cannot hide.

That is enough to make Schell feel dramatically better than legacy shells without prematurely freezing one final startup-injection method, one final structured-data pipeline baseline, or one final “all terminals must speak this” treaty.

## 10) Decisions intentionally kept open

This pass does **not** freeze:
- one universal shell-integration protocol,
- one final escape-sequence catalog,
- one universal command-block wire format,
- one final PTY-vs-native execution story,
- one fully structured-data pipeline ontology,
- one final helper/agent/background-work topology,
- or one final startup customization system.

The no-regret move is smaller:
**steal semantic marks, command chapters, insert-first help, typed routes, and restored continuity — but keep startup footing, helper lanes, capability posture, and durable shell truth visibly separate.**
