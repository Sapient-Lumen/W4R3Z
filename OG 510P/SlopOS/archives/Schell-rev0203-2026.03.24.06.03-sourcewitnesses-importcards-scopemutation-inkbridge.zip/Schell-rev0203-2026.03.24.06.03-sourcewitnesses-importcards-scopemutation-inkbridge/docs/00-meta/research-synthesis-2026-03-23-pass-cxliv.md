# Research synthesis — 2026-03-23 — pass CXLIV

This pass sharpens one fresh shell+terminal lesson from current upstream docs:
**the ecosystem is normalizing more and more ways for prompts to disappear — safe read-only classes, allowlists, sandbox-backed auto-allow, worktree-isolated sessions, org policies, and session replay — but the quietness source is still often under-explained.**

That means the next useful Schell move is not another broad autonomy feature.
It is a smaller honesty move:
**baseline cards and quietness provenance.**

## 1) Claude Code now shows at least three different quietness sources

Claude Code’s current docs make the approval picture more plural than it first appears.
Its permissions docs describe read-only tools as a no-approval class, ordered deny/ask/allow rules, and several permission modes.
Its sandboxing docs then add another quietness source: in auto-allow sandbox mode, bash commands that can run inside the constrained lane are automatically allowed while explicit ask/deny rules still apply.
And its changelog now openly references a bash auto-approval allowlist that has been extended over time for common read-only commands.

That is a powerful clue for Schell.
Silence can come from a class, a rule, a sandbox lane, or a built-in baseline — and the operator should be able to tell which.

## 2) Warp makes allow and deny precedence explicit, but not all quietness feels equally typed yet

Warp’s current agent-permissions/admin docs are also revealing.
They expose explicit autonomy settings, command allowlists and denylists, and the rule that command denylist matches override both allowlists and more permissive autonomy settings.
That is good.
It means the product admits that some command runs are quiet because a rule matched and others are still forced to ask.

The bigger lesson for Schell is that this structure wants a better UI type system than just “ran without asking.”
A deny floor is a different fact from an allow rule, and both are different from a lane-wide auto-allow guarantee.

## 3) VS Code shows that isolation can be the reason approvals disappear

VS Code’s current Copilot CLI docs add another important category.
In worktree isolation, the permission level is automatically set to Bypass Approvals and all tool calls are auto-approved because the agent is operating on an isolated Git worktree.
Its Copilot security docs similarly say that terminal commands can be auto-approved either by configurable per-command rules or by terminal sandboxing, and that the product shows a notification with a link to the setting when an action was automatically approved.

This is one of the best current design clues for Schell.
Quietness from **environment shape** is not the same as quietness from **rule match**.
The UI should say which one happened.

## 4) The ecosystem is converging on multiple baseline families, not one trust switch

Across current tools, quietness now comes from several families:
- read-only or non-effect classes,
- allowlist matches,
- deny floors that still override,
- isolation-backed auto-approval,
- session-scoped or task-scoped autonomy posture,
- and remembered review from exact prior approval.

The trouble is that products often explain those families in separate docs while the operator only sees one shared symptom: the prompt did not appear.
That is a perfect Schell opportunity.
The shell+terminal can make silence typed and inspectable without bringing back the interruption burden that fast lanes were meant to solve.

## 5) The stealable move is visible quietness provenance

The best move to steal from the current ecosystem is therefore not “more auto-approval.”
It is:
- a **baseline chip** on quiet actions,
- a compact **baseline card** that says why the prompt stayed quiet,
- a visible **deny floor** that still applies,
- and **receipt residue** that records the provenance of silent approval.

That would let Schell distinguish at least these cases:
- built-in safe set,
- local reviewed allow rule,
- managed policy baseline,
- sandbox-backed lane,
- isolated worktree lane,
- read-only class,
- replay lease.

## 6) This is a better “super awesome” move than another big architecture bet

This seam is unusually good because it creates luxury and trust at the same time.
Operators get fewer meaningless prompts, but they also stop having to reverse-engineer why the system stayed quiet.
That is more humane than just adding another global autonomy toggle.

It also stays decision-light.
Schell does not need to freeze a final policy engine, sandbox backend, or allowlist catalog format to prove the value of baseline cards.
It only needs a small shell+terminal surface that makes quietness provenance legible.

## 7) Compact conclusion

Current upstream docs are converging on the same truth from several directions:
- Claude Code separates read-only classes, rule-based permissions, sandbox-backed auto-allow, and a growing bash auto-approval baseline.
- Warp separates allow rules from deny floors and from broader autonomy posture.
- VS Code separates per-command auto-approval from isolation-backed auto-approval and already shows notifications when silent approval happens.

Schell should take the hint.
The next no-regret shell+terminal luxury is **typed quietness**:
**baseline cards, visible deny floors, and receipt-level provenance for every action that ran without asking.**
