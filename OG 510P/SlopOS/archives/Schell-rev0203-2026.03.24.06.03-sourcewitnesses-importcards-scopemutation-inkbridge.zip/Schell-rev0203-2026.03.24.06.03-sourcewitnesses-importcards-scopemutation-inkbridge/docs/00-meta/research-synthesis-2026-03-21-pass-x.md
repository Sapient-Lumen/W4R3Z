# Research synthesis — 2026-03-21 pass X

This pass keeps one design rule in view:
**the custom shell+terminal should become dramatically easier to reenter, search, restore, and navigate without ever pretending that restored or discovered objects are automatically current live authority.**

The newest outside convergence is not just “blocks are nice.”
It is about four related truths:

- shell-emitted semantic truth keeps navigation and action honest,
- session restoration is helpful but should be treated as historical reconstruction,
- semantic open/history features are powerful when they preserve per-line or per-block context,
- and unified discovery surfaces work best when they separate finding from acting.

## Strongest current outside pressure

### 1) Shell-reported command truth still buys the most

VS Code and Windows Terminal continue to reinforce the no-regret architecture:
the shell writes escape sequences that mark prompt/command/output boundaries and success state, and the terminal uses those to navigate, select output, and surface history accurately.
That still looks like the base layer Schell should trust most.

### 2) Prompt-safe editing remains a model example of “fancy but bounded”

Ghostty and kitty both show a particularly good product move:
mouse-driven cursor placement works beautifully when it is confined to the active shell prompt that the shell has explicitly marked.
This is exactly the pattern Schell wants for richer interaction in general.

### 3) Semantic history is worth stealing, but not its overreach

iTerm2's semantic history remains one of the best niche ideas in terminal land.
Tracking the current working directory for each line makes file-opening and path resolution materially better.
The part to steal is **context-preserving openability**.
The part to avoid is letting that context silently become a live-authorization story.

### 4) Saved reusable commands work better as explicit artifacts

Warp workflows still provide a strong pressure source: parameterized commands that are named, searchable, and saveable from multiple entry points.
That is directly useful for Schell workflow seeds.
What changed in this pass is the companion lesson from Warp's session restoration docs:
restored blocks are useful continuity aids, but they are still restored history, not proof of current liveness.

### 5) Unified discovery should not flatten context

WezTerm's command palette and Warp's search/workflow entry points show the product value of one strong discovery surface.
The clever move for Schell is not to avoid unified discovery.
It is to keep search results tagged by lane and liveness so that discovery does not silently become targeting.

### 6) Request, enabled, active, historical, and restored should stay distinct

XDG Request, InputCapture, and OpenURI continue to give Schell a better language for state.
A request object lives for the interaction.
InputCapture separates enabled from active.
OpenURI is generic user-controlled opening, not a browser-session-control plane.
Together they argue for a terminal state family that refuses to flatten admitted, restored, live, historical, and unknown into one pretty history.

## Best ideas worth stealing now

### One primary reentry cue

Schell should have one trusted path back to the current live lane and active input.
Everything else — bookmarks, restored panes, receipts, search hits, archived blocks — should remain explicitly secondary.
That is a small but very high-value honesty move.

### Hold cards for non-live objects

When a user lands on a restored block, stale workflow, or historical receipt and asks for a strong action, Schell should not just say no.
It should surface a compact hold card that says what is missing:

- live process not present,
- basis drifted,
- authority widened,
- provenance too weak,
- or exact target must be reacquired.

That is a DelayBasin-quality non-movement move in terminal form.

### Semantic-history style opens with trust grades

Per-line or per-block cwd/path context is worth stealing.
The shell+terminal should be able to open a clicked path more intelligently than legacy terminals.
But the action should stay trust-graded:
inspect/open is generic, while execute/attach/review remains separately basis-bound.

### Restored-state badges

A restored pane or block should say so plainly.
That one tiny badge could save a lot of operator confusion and keep session restoration from becoming fake liveness.

### Lane-aware unified search

A single search or palette can unify current commands, historical receipts, saved workflows, bookmarks, and agent conversations, as long as each result keeps its lane, authorship, and liveness posture attached.
That would be both humane and honest.

## Moves that make the custom shell+terminal super awesome

### 1) Make reentry safe and fast

A user should be able to reopen Schell, hit one reliable cue, and know exactly where the live lane is.
That is a bigger quality-of-life win than adding more prompt chrome.

### 2) Let history be richly useful without pretending it is current

Restored panes, receipts, and bookmarks should feel powerful to browse, search, annotate, and seed into workflows.
They just should not silently become live execution targets.

### 3) Turn refusals into useful next steps

A hold card that explains how to reacquire a target is much better than a dead disabled button or a false-positive rerun.

### 4) Keep path clicks smart but bounded

Contextual file/URI opening can be delightful, especially when paired with per-line cwd or command context.
The shell+terminal should steal that idea aggressively while refusing hidden profile/session semantics.

## Current prototype reading

The next no-regret slice now looks like this:

1. **one primary reentry cue,**
2. **one restored-state badge family,**
3. **one hold-card family for non-live or drifted objects,**
4. **one semantic-history-style open specimen with trust grades,**
5. **and one lane-aware search/palette specimen that separates find from act.**

That still leaves restoration persistence, search indexing, transport, renderer, and final action-resolution policy open.
That is exactly where Schell should stay.

## Reference pressure

- https://code.visualstudio.com/docs/terminal/shell-integration
- https://code.visualstudio.com/updates/v1_104
- https://learn.microsoft.com/en-us/windows/terminal/tutorials/shell-integration
- https://ghostty.org/docs/install/release-notes/1-3-0
- https://ghostty.org/docs/config/reference
- https://sw.kovidgoyal.net/kitty/shell-integration/
- https://sw.kovidgoyal.net/kitty/keyboard-protocol/
- https://iterm2.com/documentation-one-page.html
- https://wezterm.org/config/lua/keyassignment/ActivateCommandPalette.html
- https://docs.warp.dev/knowledge-and-collaboration/warp-drive/workflows
- https://docs.warp.dev/agent-platform/local-agents/interacting-with-agents/agent-modality
- https://docs.warp.dev/terminal/sessions/session-restoration
- https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Request.html
- https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.InputCapture.html
- https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.OpenURI.html
