# Research synthesis, pass XCVIII (2026-03-22)

This pass asks one narrower question:
**what should Schell learn from modern shell line editors and keybinding systems without letting editing comfort become a hidden second shell, hidden prompt-time worker path, or hidden execution lane?**

The answer is now pretty crisp.
**The right move is not “pick the best editor mode.” The right move is to treat keymaps, widgets, menu modes, and prompt-click editing as an explicit editor witness family that stays weaker than command meaning and reviewed execution truth.**

## 1) The ecosystem keeps proving that line editing is one of the biggest quality multipliers in shell UX

fish, zsh, PowerShell, Nushell, Ghostty, and kitty all keep demonstrating the same thing:
people love shells that feel like real editors.
They want:
- modal editing when it helps,
- better help on the current command,
- menu-local bindings,
- prompt-local cursor movement,
- rich search,
- and obvious ways to learn or inspect available actions.

That is exactly the kind of luxury Schell should steal.
But it is also exactly the seam where editing helpers can quietly become execution helpers if the shell stops naming what kind of action actually fired.

## 2) fish proves that keymaps and helper tools are worth stealing directly

fish's current bind docs say key bindings may use modes, that each binding applies to a single mode, and that the mode can be changed after a binding executes.
The docs also keep the action surface concrete: bindings may call fish commands or special input functions, and the shell ships `fish_key_reader` specifically to explain how a key sequence would be bound.
Recent release notes add another useful clue: `fish_trace=all` can now trace execution of key bindings, event handlers, prompt functions, and title functions.

That is a wonderful design hint for Schell.
The shell should not just support rich bindings.
It should be able to explain them and, when necessary, show that a binding is a real code path rather than innocent UI chrome.

See:
- https://fishshell.com/docs/current/cmds/bind.html
- https://fishshell.com/docs/current/cmds/fish_key_reader.html
- https://fishshell.com/docs/current/relnotes.html

## 3) PowerShell sharpens the warning: key handlers can absolutely cross into execution

PSReadLine's current docs say its functions can be bound to keystrokes, and Microsoft explicitly documents `Set-PSReadLineKeyHandler` as letting user-defined key bindings do almost anything possible within a PowerShell script.
The examples are revealing: a single key can clear the line, insert text, and accept the line.
The docs also expose `WhatIsKey`, `AcceptSuggestion`, `AcceptNextSuggestionWord`, and Vi-mode change hooks.

That combination teaches the exact lesson Schell needs.
The same editor surface can host:
- inert explainability,
- ordinary buffer editing,
- suggestion acceptance,
- and immediate submission.

Those are not the same class of move.
Schell should keep them separately witnessed.

See:
- https://learn.microsoft.com/en-us/powershell/module/psreadline/about/about_psreadline_functions?view=powershell-7.5
- https://learn.microsoft.com/en-us/powershell/module/psreadline/set-psreadlinekeyhandler?view=powershell-7.5
- https://learn.microsoft.com/en-us/powershell/module/psreadline/set-psreadlineoption?view=powershell-7.5
- https://learn.microsoft.com/en-us/powershell/scripting/learn/shell/using-keyhandlers?view=powershell-7.5

## 4) zsh proves that widgets are a real programmable editor substrate

The current ZLE docs say `bindkey` manipulates keymaps and key bindings, while `zle` manipulates editing widgets and allows command-line access to ZLE commands from within shell functions.
They also say user-defined widgets can call shell functions, completion widgets can be user-defined, keymaps can be listed, cloned, linked, reset, and switched, and widgets can display status text while running.
The user-contributions docs add a subtle but valuable steal: `ESC h` is normally bound to the `run-help` widget, which acts on the command word under the current input line.

That is exactly the sort of humane editing luxury Schell wants.
But zsh also proves the risk:
editor widgets are not merely cosmetic.
They are programmable shell-facing actions.

See:
- https://zsh.sourceforge.io/Doc/Release/Zsh-Line-Editor.html
- https://zsh.sourceforge.io/Doc/Release/User-Contributions.html

## 5) Nushell shows that menus and help belong inside the editor, not beside it

Nushell's Reedline docs show that when a menu is active, some keybindings change according to menu state.
They also document a built-in help menu on `F1`, where the user can search commands by name or description and paste available examples into the line.
Separately, Nushell exposes `keybindings list` so the user can inspect modifiers, keycodes, modes, events, and edit commands.

That is a great model for Schell because it treats help, menu navigation, and insertion as editor-local luxuries rather than as an ambient sidecar app.
It also reinforces that active-menu mode is a different truth from ordinary prompt editing.

See:
- https://www.nushell.sh/book/line_editor.html
- https://www.nushell.sh/commands/docs/keybindings_list.html

## 6) Ghostty and kitty show the right terminal-side luxury: prompt clicks should work, but only on authenticated editor ground

Ghostty's current docs say cursor-click-to-move works at prompts and requires shell integration, specifically prompt marking via OSC 133.
Its 1.3.0 release notes add that this supports clicking within an active shell prompt to move the cursor.
kitty's current shell-integration docs make the same point from a slightly sharper angle: if the shell can handle prompt click events, kitty sends a click event to the shell; otherwise kitty may synthesize fake key events to move the cursor, which the docs call not fully robust.

That is one of the best current terminal lessons.
Prompt-click editing is worth stealing.
But terminal convenience should stay visibly weaker than shell-authenticated editor truth, and compat fallbacks should be labeled as such.

See:
- https://ghostty.org/docs/config/reference
- https://ghostty.org/docs/install/release-notes/1-3-0
- https://sw.kovidgoyal.net/kitty/shell-integration/

## 7) The compact import for Schell

This pass argues for one smaller ratchet rather than one final editor manifesto.
Schell should start with an explicit **keymap witness** or **editor witness** that can say:
- what editor mode is active,
- where a binding came from,
- whether the binding calls a builtin edit function, a user widget, a shell script, or a terminal bridge,
- whether the action only edits the buffer, opens help, accepts a candidate, or submits a line,
- whether the current action was triggered by a key chord, a menu-local binding, a prompt click, or a terminal fallback,
- and how the operator can discover what the current key would do.

That is enough to make the line editor much more legible without freezing one final keybinding syntax, mode family, or editor engine.

## 8) The no-regret steals are now pretty obvious

The best design-phase steals are:
- a **WhatIsKey** / **DescribeKey** answer for the current context,
- visible **mode badges** for insert / command / menu / search / help / prompt-click / unknown,
- **source-labeled bindings** so user/project/imported/bridge/default actions stay separate,
- a **submit-class badge** when a binding can actually accept/submit the line,
- menu-local bindings that are visibly menu-local,
- built-in help keys such as `F1` / `run-help` that work on the current command without leaving the editor,
- and prompt-click editing only on shell-authenticated live prompt ground.

## 9) What this pass intentionally refuses to freeze

This pass does **not** freeze:
- one final editor engine,
- one final vi/emacs/modal treaty,
- one final binding file format,
- one final widget/plugin API,
- one final terminal click protocol,
- or one final policy for project-local bindings.

The no-regret move is smaller:
**make editor actions legible enough that delightful bindings, menus, widgets, and prompt clicks cannot quietly impersonate parser truth or execution authority.**
