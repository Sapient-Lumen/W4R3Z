# SlopOS datacube evaluation — 2026-03-23 — pass CXC

**Schell should treat input-memory residue as local, typed, and weaker than durable shell truth, because SlopOS and the companion datacubes keep rewarding locality boundaries, packaging humility, neighboring-state separation, label honesty, and aggressive residue trimming.**

## 1) SlopOS already says locality is not authority

The newest memory-locality boundary is a surprisingly good teacher for this seam.
SlopOS freezes richer locality facts as placement hints only rather than letting them quietly become authority boundaries.
That maps well onto Schell edit memory.
A local kill ring or undo journal may be extremely useful because it is near to the current composition act, but that locality does **not** make it durable shell truth.

The shell should therefore preserve one sharp line:
**edit-local memory may help composition, but it does not automatically become command history, replay evidence, or export-worthy artifact truth.**

## 2) SlopOS provider-local packaging is exactly the right warning

The new provider-local response-packaging boundary sharpens the second lesson.
Provider-local packaging remains packaging; it does not silently become a portable auth-result, proof object, or approval basis.
Schell should import that discipline directly.
A terminal-local paste history row or window-local kill-ring entry remains local packaging around typed text.
It should not silently become durable history, safe replay basis, or portable transcript truth just because the operator can still see it.

## 3) ViewFS already keeps neighboring editing layers separate

ViewFS is the clearest nearby shell companion for this exact move.
Its parse-lens ladder keeps editable buffer, parse understanding, diagnostics, packet gutter, prepared action, and receipt/history as separate neighbors.
That means Schell should resist one more collapse:
edit-local text memory should not flatten into the same lane as either the active buffer or durable history.
A yanked snippet, an external paste, and a previously run command should remain different neighboring objects.

## 4) Harbor and Steward keep the hygiene pressure honest

Harbor keeps reminding the family that labels should stay honest even when the UI gets convenient.
That means `kill ring`, `external paste`, `paste history`, `draft shelf`, and `submitted history` should remain visibly different labels.

Steward's current cache-trim posture is the other good pressure.
Local convenience caches are allowed, but they need explicit trim behavior and clear survival posture.
That fits edit memory perfectly.
A super-awesome shell should be better than old terminals at trimming sensitive local residue, not worse.

## 5) What this does not require Schell to decide yet

This seam does **not** require Schell to decide:
- one final line editor,
- one clipboard-bridge backend,
- one sync story,
- one secret detector,
- one terminal paste-history database,
- or one durable note/draft substrate.

The archive only needs to prove a compact honesty stack that says:
- this text is still local edit memory,
- this text came from foreign paste ingress,
- this text is durable history because it was actually submitted,
- and this residue is trimmed, excluded, or persisted by explicit policy.

## 6) Compact conclusion

SlopOS keeps locality weaker than authority and packaging weaker than portable truth.
ViewFS keeps neighboring buffer/parse/packet/history layers separate.
Harbor keeps labels honest.
Steward keeps caches trim-aware.

So the next Schell move should be:

**add edit journals, kill rings, paste-provenance chips, and paste-history humility so the shell+terminal can become much better at composition without letting local edit memory quietly become durable command truth or invisible residue.**
