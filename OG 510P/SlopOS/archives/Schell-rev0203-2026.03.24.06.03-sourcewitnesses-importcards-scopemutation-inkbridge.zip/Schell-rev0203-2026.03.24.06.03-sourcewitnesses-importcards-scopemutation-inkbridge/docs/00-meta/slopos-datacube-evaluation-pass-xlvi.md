# SlopOS datacube evaluation, pass XLVI

This pass keeps one bounded thesis in focus:
**SlopOS already has the right ingredients for honest collaboration semantics — explicit transfers, explicit restore material, bounded leases, authority receipts, and shareable evidence bundles. Schell should import that discipline so “share terminal” becomes a visible ladder of roles rather than a fuzzy jump from observation to ambient co-control.**

That is a particularly good ratchet while SlopOS is still design-phase too.
It gives Schell a stronger help/pair-debugging story without forcing any final relay, browser, or multiplayer backend.

## 1) D-PLUMB / RFC-0094 say transfer is explicit, not ambient

One of the strongest current SlopOS pressures is the transfer-portal posture.
Copy is not grant.
Paste/share is the grant.
There is no ambient clipboard read or background clipboard-history service in v0.

That is exactly the right mindset for shared terminal work too.
A share link, a copied connection string, a browser-open action, and a live writable guest are not one action.
Schell should import the rule that collaboration steps are explicit transfers with distinct bounds and receipts.

## 2) Sturdyrefs and limited-use proxies point toward honest invitations

RFC-0014 and RFC-0066 give another clean lesson.
Offline capability references are explicit restore material, off by default, and not ambient inventory.
Lease wrappers keep TTL, uses, and forwarding bounds explicit, and historical descriptors do not prove current live state.

That maps directly onto collaboration invites.
A guest invitation or join handle should behave more like a bounded restore path or lease than a permanent mystical URL.
And a historical invitation receipt should never masquerade as proof that the share is still live right now.

## 3) Consent receipts and authority diffs are the right shape for co-drive

SlopOS’s authority-diff and receipt posture is especially valuable here.
If a share is moving from observe-only to writable co-drive, that is a meaningful authority change.
It deserves a distinct summary, a distinct approval, and a durable receipt saying what changed.

That gives Schell a much better path than classic tmux folklore.
“Guest may now type into this prompt lease” should be a separately named grant, not a side effect of already watching the session.

## 4) Shareable evidence bundles suggest that live shell access is often too much

RFC-0086 is one of the most useful indirect lessons for Schell on this pass.
Crash capsules and shareable evidence bundles exist precisely because many support workflows do not need ambient live access to the whole machine.

That is a major clue for terminal design.
Very often the right move is to share:
- a chapter bundle,
- a transcript slice,
- a scrubbed replay bundle,
- a service witness,
- or a crash capsule,
not a writable live terminal.

## 5) The import pressure for Schell is narrow and high-value

Schell does not need to decide one collaboration protocol or hosted broker.
The right import from SlopOS is smaller and cleaner:
- keep share roles explicit,
- keep invitations bounded and revocable,
- keep writable co-drive stronger than observation,
- keep guest-side side effects separately approved,
- and make evidence export easy enough that full live sharing is not the default reflex.

That would let Schell become much better than old shells at pair debugging, teaching, and remote help while still honoring one of SlopOS’s best current instincts:
**adjacent convenience should not silently widen authority just because two people are now looking at the same thing.**
