# Research synthesis — 2026-03-23 — pass CLXII

This pass tightens the next seam instead of widening “environment handling” into one giant config/runtime/workspace treaty:
**environment luxury is worth stealing, but the shell should stay excellent at saying which environment layers exist right now, where they came from, when they took effect, and which ones are still too weak to count as fresh reviewed footing.**

The strongest current lesson is that modern shells and terminals already expose multiple environment truths, but in fragmented, source-specific ways.
That points to a good next Schell move:
**environment witnesses, layer stacks, and mutation-timing humility** rather than one flattering “here is the current env” story.

## 1) Bash shows how much ambient startup can shape the environment

Current Bash docs say the shell scans its own environment on invocation, creates parameters for those names, and exported commands inherit that environment.
The same manual says non-interactive shells look for `BASH_ENV`, expand it, and read that file before running a shell script.
That means even “just run this script” can pick up hidden environment behavior from a startup file rather than only from explicit argv.

That is a strong Schell lesson.
Inherited parent env, exported shell state, and startup-file mutation should remain separately witnessed.

## 2) fish proves that scope and export are different dimensions

Current fish docs say variables have independent scope controls such as universal, function, local, and global.
The same docs say export is not itself a scope but an additional bit of state, and PATH-like variables are treated as path variables.
That is a very clean model for Schell:
mutation scope, export posture, and path-search meaning should not be flattened into one boolean “environment variable” badge.

## 3) PowerShell shows that environment has platform scopes and profile-driven startup layers

Current PowerShell docs say environment variables on Windows can exist in Machine, User, and Process scope, with Process built from the parent process and the Machine/User scopes.
They also say a PowerShell profile is a script that runs when PowerShell starts and can customize commands, aliases, variables, modules, drives, and more for every session.
That means a shell session’s effective environment and behavior may come partly from inherited process state and partly from startup script layers that deserve distinct provenance.

## 4) Nushell shows the value of typed env and explicit overlays

Current Nushell docs say environment variables can have types, the environment is created from Nu configuration files plus the environment Nu is started inside of, and overlays can activate and deactivate layers of definitions including environment variables.
That is excellent evidence for Schell.
The shell can keep environment layers explicit and even typed without deciding that the final external process view must mirror the shell’s internal representation exactly.

## 5) direnv shows that repo-local environment luxury works best when authorized and local

Current direnv docs say it augments shells by loading and unloading environment variables depending on the current directory.
They also say that before each prompt direnv checks for `.envrc` (and optionally `.env`) in the current or parent directories, and if authorized it loads the file in a bash sub-shell, captures exported variables, and makes them available to the current shell.
That is a strong Schell lesson:
repo-local activation should be treated as a leased imported layer with explicit authorization and diffable consequences instead of ambient folder magic.

## 6) Current terminals already mutate environment and admit timing matters

Current VS Code docs say extensions can contribute to terminal environments, existing terminals may need relaunch when that environment changes, and the terminal hover can explain the change.
VS Code’s extension docs also say env mutators can be applied at process creation, at shell integration time, or both.
Windows Terminal docs say profiles can carry their own environment object without affecting the whole system.
Together, these tools push a very precise lesson:
terminal-local environment mutation is real product surface, and timing is part of the truth.

## 7) The concrete Schell move

Schell should add a compact **environment-layer witness** family:
- `layer_ref` — exact layer identity,
- `source_lane` — inherited parent / startup / profile / terminal injection / repo activation / overlay / command-local / restored / unknown,
- `timing_lane` — process creation / shell init / shell integration / prompt-time / command-local / historical,
- `scope_posture` — machine / user / process / shell / pane / command / repo / unknown,
- `mutation_kind` — replace / prepend / append / unset / typed overlay / opaque helper,
- `keys_touched` — exact keys,
- `code_posture` — pure data / script / helper-derived / imported / unknown,
- `admission_posture` — native / trusted / leased / terminal-provided / restored / imported,
- `lifetime_posture` — durable / session / pane / command / lease / historical,
- `reveal_ref` — exact diff or card.

Within that family, PATH can have a dedicated row type showing prepend/append order, source lane, and whether command identity drift is likely.
That is enough to steal a lot of environment clarity without freezing one universal env serialization, dev-shell ABI, or overlay runtime.
