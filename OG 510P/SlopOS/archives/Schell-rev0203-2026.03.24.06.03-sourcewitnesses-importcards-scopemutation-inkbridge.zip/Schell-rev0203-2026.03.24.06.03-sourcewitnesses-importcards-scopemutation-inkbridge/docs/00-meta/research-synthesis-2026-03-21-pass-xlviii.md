# Research synthesis, pass XLVIII (2026-03-21)

This pass focuses on one bounded seam that Schell did not yet give its own surface:
**the ecosystem now has two Unicode pressures at once — richer grapheme-correct rendering, and stricter review-time defense against bidi controls, invisible characters, confusables, and width disagreement. Schell should stop letting those borrow one fuzzy idea of “text support.”**

## 1) The old lesson still wins: visible text is not sufficient evidence

The modern source-review ecosystem now treats hidden Unicode controls as a real review risk.
GitHub shows a warning when files contain bidirectional Unicode text because reviewed code can appear differently from how tools interpret or compile it.
Rust responded to the same Trojan Source class by adding deny-by-default lints for text-direction codepoints in comments and literals.

The lesson for Schell is straightforward:
**rendered appearance is useful, but it is not enough to ground reviewed command or identifier truth.**

## 2) Modern terminals are also getting more correct about graphemes and width

The other side of the seam is not fear, but quality.
Ghostty’s recent Unicode work improved shaping, combining-mark placement, grapheme clustering, selection, cursor movement, and width calculation for multi-codepoint characters.
VS Code’s terminal docs likewise admit that Unicode width is a live compatibility problem, with ambiguous-width glyphs, configurable Unicode versions, and renderer-side rescaling to avoid overlap.

That is exactly why Schell should split “display quality” from “authority review.”
The shell should be able to support richer multilingual text without claiming that the current renderer view is automatically the final truth for execution.

## 3) The ecosystem is converging on warnings, reveals, and stricter review surfaces

VS Code highlights invisible and confusable Unicode characters and later refined that behavior to reduce false positives contextually.
GitHub warns at the file boundary.
Rust lints at the compiler boundary.
Unicode UTS #39 supplies confusable-detection and mixed-script machinery for systems that need it.

The design pattern is consistent:
- ordinary reading can stay pleasant,
- but authority-adjacent review gets a stricter representation.

That is a very good import for Schell.

## 4) Width disagreement is a terminal truth seam, not just a font quirk

Ghostty now exposes a grapheme-width method because modern Unicode-correct width and legacy `wcswidth`-style compatibility can diverge.
VS Code likewise warns that backend and frontend may disagree on ambiguous-width characters.

That means a custom shell+terminal cannot treat cell width as an invisible implementation detail anymore.
For Schell, width posture should become explicit whenever cursoring, selection, detector ranges, or command review could be misaligned by renderer-vs-peer disagreement.

## 5) The nifty idea worth stealing is dual-lane text UX

A genuinely brilliant move for Schell would be:
- rich multilingual display by default,
- instant safe-review toggles for suspicious or authority-bearing text,
- confusable or bidi badges only when risk is high,
- grapheme-aware movement/selection for humane interaction,
- and exact-byte reveal before admission/execution when needed.

That is better than the old ecosystem because it does not force the user to choose between hostile ASCII-only austerity and renderer-trusting naivety.

## 6) The no-regret Schell move is Unicode witnesses plus strict-safe review

Schell does not need to choose one permanent Unicode policy stack now.
It needs something smaller and better:
- **Unicode witnesses** for exact vs normalized vs display-shaped text,
- **bidi/confusable posture** for authority-adjacent text,
- **width posture** for renderer/peer/history disagreement,
- and **strict-safe-review** for the moments when the operator needs byte-honest truth.

That would make the custom shell+terminal more humane, more international, and more trustworthy at the same time.
