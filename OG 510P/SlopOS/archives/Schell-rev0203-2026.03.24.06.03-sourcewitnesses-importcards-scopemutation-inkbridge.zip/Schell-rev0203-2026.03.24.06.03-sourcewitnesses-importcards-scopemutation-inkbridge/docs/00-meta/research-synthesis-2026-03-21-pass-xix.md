# Research synthesis, pass XIX (2026-03-21)

This pass focuses on another load-bearing seam:
**current terminal UX gets dramatically better from shell-emitted metadata, but the richest behaviors still ride on escape sequences and host-side handlers, which means Schell should separate trusted chrome from ordinary PTY content instead of pretending every useful overlay is equally trustworthy.**

## 1) Modern terminal shell integration is real metadata, not magic

VS Code’s terminal shell integration makes this explicit. It supports custom `OSC 633` sequences for prompt start/end, pre-execution, execution finish, explicit command lines, and properties such as cwd. The docs also say these sequences can be written by any application capable of sending them, and that the optional nonce on the explicit-command sequence can be used to verify that the sequence came from the shell integration script and prevent command spoofing. That is a very strong design clue for Schell: metadata is valuable, but stronger actions should care about provenance and trust, not just presence. See: https://code.visualstudio.com/docs/terminal/shell-integration

## 2) Rich command chrome is already useful, but it is still renderer-local UX

The same VS Code docs show command decorations, a command guide, sticky scroll, quick fixes, and run-recent-command features built on top of shell integration. Those features are great. They also illustrate Schell’s main caution: a bar beside a command, a sticky header, or a quick action menu is a *host-rendered convenience surface*, not automatically the same thing as the shell’s durable review basis or receipt. See: https://code.visualstudio.com/docs/terminal/shell-integration

## 3) WezTerm and Ghostty show how far shell-known regions can take you

WezTerm’s shell integration docs say it supports `OSC 7` for cwd, `OSC 133` for Input/Output/Prompt zones, and `OSC 1337` user vars, enabling improved UX such as spawning panes/tabs/windows in the same cwd, jumping through scrollback to earlier commands, and selecting the complete output from a command. See: https://wezterm.org/shell-integration.html

Ghostty 1.3 shows the same direction in a more local form. It now supports click-to-move the cursor inside an active shell prompt via OSC 133 prompt semantics, and it also includes a terminal inspector/debug overlay that shows OSC 133 areas. That is exactly the kind of idea Schell should steal — but only for shell-marked active input or shell-attested regions, not as a general trust grant to arbitrary terminal text. See: https://ghostty.org/docs/install/release-notes/1-3-0

## 4) Terminal data is untrusted by default

The xterm.js security guide says terminal data may contain malicious data and should always be treated as untrusted when handled at the DOM level. It specifically warns embedders to apply data securely, for example by opening links in a separate context and avoiding `innerHTML`. That is a direct external confirmation of the design rule Schell needs: terminal content is useful, but it should not automatically become trusted UI chrome. See: https://xtermjs.org/docs/guides/security/

## 5) Even “clickable things” already have a trust ladder in practice

xterm.js documents two kinds of clickable links: explicit `OSC 8` hyperlinks emitted intentionally, and implicit links recognized by pattern matching. That split is helpful because it shows terminals already benefit from distinguishing more-explicit from more-heuristic visible objects. Schell should push that farther with a stronger ladder such as `raw-pty`, `inferred`, `shell-attested`, and `trusted-chrome`. See: https://xtermjs.org/docs/guides/link-handling/

## 6) PTY output can already ask the host terminal to do real side effects

The xterm control-sequence docs say `OSC 52` manipulates selection data and can make the resulting data available for pasting by other applications. The same docs also describe title-changing sequences like `OSC 0`, `OSC 1`, and `OSC 2` for icon name and window-title changes. This matters because it means ordinary terminal output is not just “text on glass”; it can request clipboard and window-chrome changes in terminals that honor those operations. Schell should therefore witness, gate, or visually separate those host-side effects rather than letting them disappear into terminal folklore. See: https://invisible-island.net/xterm/ctlseqs/ctlseqs.html

## 7) Trusted-path precedents still matter

IBM’s AIX docs say the trusted path exists to prevent unauthorized programs from reading data from a user terminal when a secure communication path with the system is required, and that the Secure Attention Key establishes the environment necessary for secure communication between the user and the system. Microsoft’s Winlogon docs say Winlogon registers the Ctrl+Alt+Del secure attention sequence and that registering it first ensures no other application has hooked that key sequence. Those are strong reminders that when the interaction is truly high risk, systems have long separated ordinary application rendering from a more trusted review/entry path. See: https://www.ibm.com/docs/en/aix/7.2.0?topic=security-trusted-path-trusted-shell-secure-attention-key and https://learn.microsoft.com/en-us/windows/win32/secauthn/initializing-winlogon

## 8) A no-regret Schell cluster is visible now

A careful import from these systems is not “become a desktop security stack.”
It is smaller:
- keep shell-emitted metadata because it enables brilliant UX,
- keep provenance and trust grades visible because metadata can also be spoofed,
- keep PTY-driven host effects explicit because terminals already honor clipboard/title/link behaviors,
- and reserve authority-bearing review cards, secure prompts, and final approval/denial surfaces for trusted local chrome that is visibly separate from ordinary terminal flow.

That feels like the right next ratchet for Schell:
**copy the good overlays, but do not let the operator forget which layer is actually allowed to carry authority.**
