# Research synthesis, pass CXI (2026-03-22)

This pass keeps one narrower lesson explicit:
**window titles, tab titles, split/session labels, and badges are superb orientation tools, but they should remain display labels and projections rather than quietly becoming exact peer, cwd, job, or live-state truth.**

The historical baseline is old and surprisingly revealing.
`xterm` still recognizes OSC 0/1/2 for icon and window titles, which is a reminder that title text has long been application-emitted and easy to mutate.
That means title text is useful but inherently weak unless something stronger binds it.

Current terminals then prove how much richer and more divergent this seam has become.
Windows Terminal explicitly supports `tabTitle` and `suppressApplicationTitle`, and its docs note that the shell's title variable may differ from the visible tab title.
That is a valuable truth-model clue: visible label and shell-emitted label are already different stories.
Ghostty 1.3 adds separate window/tab titles apart from split titles and lets operators change them through the menu, command palette, and keybind actions.
kitty's shell integration can set titles from shell state but also lets the operator disable title updates with `no-title`.
iTerm2 goes even further with session-title composition, shell-integration-fed host/PWD/job elements, badges set by proprietary escape sequences, and explicit escaping of control-sequence-set titles so they cannot invoke interpolated functions.

That combination suggests a simple no-regret rule for Schell:
**titles and badges should cite stronger witnesses; they should not become those witnesses.**

## 1) Titles are a display lane, not an identity plane

The Windows Terminal docs are especially clarifying because they say the quiet part out loud: `suppressApplicationTitle` decouples the visible tab title from the shell's title.
Once that is true, Schell should stop pretending there is one canonical title object.
There are instead neighboring label lanes:
- shell-emitted label,
- operator override,
- profile default,
- renderer-derived title,
- restored historical title,
- and badge/status label.

## 2) Shell integration improves labels but does not upgrade them into truth

kitty and iTerm2 both show the right pattern.
Shell integration can make titles more accurate by binding them to cwd, host, remote state, and command history.
Ghostty's new separation of tab/window/split titles reinforces the same point.
But better labels are still labels.
They are projections of stronger state, not replacements for exact peer or cwd witnesses.

## 3) Operator overrides are excellent and should stay obviously local

Ghostty's new prompt/command-palette title-setting actions and Windows Terminal's fixed `tabTitle` posture both point to the same product truth: people love hand-authored tab labels.
That is a feature worth stealing.
But once operator overrides exist, Schell needs visible override posture or the label will overclaim live shell truth.

## 4) Badges and interpolated titles are even more obviously descriptive

iTerm2's badge system is a great specimen because it can interpolate variables and be updated by a proprietary escape sequence.
It is powerful and useful.
It is also exactly the sort of surface that should remain descriptive/orienting unless it cites stronger shell-owned objects.

## 5) Compact conclusion

One of the smartest no-regret moves available right now is:
**make window/tab/split/session labels and badges first-class title witnesses with explicit scope, source, override posture, and freshness before Schell lets visible names masquerade as exact peer identity or current live-state truth.**

That lets Schell steal dynamic titles, badge comfort, profile/session naming, shell-integration-fed host/PWD/job labels, and operator overrides while leaving the final title protocol, badge scripting model, shell-addon treaty, and restored-label policy open.
