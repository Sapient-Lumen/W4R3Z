# Research synthesis — 2026-03-23 — pass CLXVII

This pass keeps the archive decision-light while naming the next small but high-leverage luxury cluster:
**modern terminals keep making command objects richer, so Schell should make their current claim strength and strongest honest next verb explicit before it makes them more powerful.**

That is a strong seam because it increases trust and speed without forcing one final chapter store, protocol, hover framework, or replay engine.

## 1) The current terminal world keeps adding richer command-local detail

VS Code's terminal shell integration continues to expose working-directory detection, command detection, decorations, and navigation. Its January 2026 update added richer command details such as syntax highlighting for inline interpreters, the working directory, and a description of the command's intent. Windows Terminal documents stable shell marks, prompt/command/output regions, select-command/select-output, scroll-to-mark, and recent-command suggestions. WezTerm keeps its model intentionally small and explicit with `OSC 7` for working directory, `OSC 133` for Input/Output/Prompt zones, and `OSC 1337` for additional user vars. iTerm2 continues to center command-local inspection through its Command Info panel, exposing duration, exit status, and share/copy/resend controls. Ghostty's shell integration now supports prompt jumps, output selection, start-new-terminal-in-previous-cwd, and prompt click-to-move, while Ghostty 1.3.0 also added scrollback search. kitty keeps proving the value of typed action ladders: shell integration supports prompt jumps and last-command output views, while hints mode lets operators choose path-like or URL-like text and route it into different actions such as insert, open, or custom handlers. citeturn608973view0turn608973view1turn608973view3turn608973view4turn608973view5turn608973view8turn733963view0turn608973view6turn733963view1turn733963view2

The load-bearing lesson is not just “chapters are nice.”
It is that command-local objects are now the UI center of gravity.
Once that happens, Schell needs a tiny honest summary of what those objects can actually justify.

## 2) The ecosystem already knows stronger actions need stronger provenance

VS Code's API is unusually explicit here: `shellIntegrationNonce` exists to verify shell-integration sequences came from a trusted source, and trusted re-execution only becomes available when the command line is reported explicitly by the shell integration script with high confidence and nonce verification. That is a design gift. A modern shell+terminal can feel luxurious without pretending that visible command details are automatically execution-grade truth. citeturn608973view2

This suggests a no-regret Schell rule:
**every visible command-facing object should advertise claim strength separately from convenience.**

## 3) Fresh prompt reassertion keeps beating remembered pane guesses

fish's current release notes make a very important freshness point: the working directory is now reported on every fresh prompt via `OSC 7`, specifically to fix cases where a child process like `ssh` left behind a stale working directory; fish also now marks the prompt end with `OSC 133`. Ghostty's shell integration docs likewise note that manual sourcing is the safer path when switching shells within Ghostty, and Ghostty's config reference notes that `-e` execution may require manual sourcing or appropriate naming for shell integration to work. These are all reminders that remembered terminal-local context decays faster than fresh shell-side reassertion. citeturn608973view7turn608973view8turn608973view9

So the right luxury is not “trust the last rich row.”
It is “show which rows are fresh, which are restored, and which still need a fresh prompt epoch.”

## 4) A tiny footing strip is the next good steal

The missing luxury is therefore smaller than another inspector panel.
Schell wants a compact strip that can travel with chapter rows, hovers, sticky headers, watch results, and help attachments.
That strip should say:
- where this object's footing came from,
- how fresh it is,
- whether the current compare posture is same/changed/degraded/unknown,
- what the action floor is,
- and what the strongest honest next verb still is.

That move steals the best of today's terminal UX without deciding:
- one final chapter schema,
- one final history database,
- one final terminal wire format,
- or one policy that all drift degrades action floors the same way.

## 5) Specific ideas worth stealing right now

A few current ideas are particularly worth importing into Schell:
- VS Code's richer command details, but always with visible strength chips and stronger-action gates. citeturn608973view1turn608973view2
- Windows Terminal's stable marks and select-command/select-output, but graded by freshness and provenance rather than treated as flat truth. citeturn608973view3
- WezTerm's intentionally small semantic substrate, because working directory + prompt/input/output zones + user vars is enough to drive a lot of luxury without overfreezing the protocol. citeturn608973view4
- iTerm2's command info and per-user@host command memory, because the center of gravity should be command-local inspection rather than undifferentiated scrollback. citeturn608973view5turn733963view3
- Ghostty's prompt-aware movement, output selection, and scrollback search, because navigation and command-local reading are real delight surfaces. citeturn608973view8turn733963view0
- kitty's typed hint/open-action model, because different visible objects deserve different next verbs rather than one generic smart click. citeturn733963view1turn733963view2

## 6) Compact conclusion

The next brilliant step for Schell is not to make historical chapters more executable by default.
It is smaller and safer:
**give every visible command-facing object a tiny footing strip that exposes claim strength, freshness, current action floor, and the strongest honest next verb.**

That is the kind of luxury users feel immediately and the kind of architecture that can still stay open.
