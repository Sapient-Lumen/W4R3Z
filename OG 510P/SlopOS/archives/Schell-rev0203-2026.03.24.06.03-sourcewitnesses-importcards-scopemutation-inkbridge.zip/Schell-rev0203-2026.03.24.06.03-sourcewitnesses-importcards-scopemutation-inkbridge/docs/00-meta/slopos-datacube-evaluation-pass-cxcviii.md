# SlopOS datacube evaluation — 2026-03-24 — pass CXCVIII

**Schell should treat substitution as an explicit reviewed capture plan rather than as tiny helper punctuation, because SlopOS and the companion cubes keep rewarding exact basis, provider-local packaging humility, neighboring-state separation, label honesty, and later receipt truth.**

## 1) SlopOS keeps reviewed basis narrower than local helper packaging

SlopOS repeatedly keeps exact reviewed request basis narrower than provider-local packaging and weaker helper-local views.
Substitutions should follow the same rule.
A local terminal may show a neat one-line summary like “capture current branch”, “attach helper stream”, or “splice temporary file here”.
That summary is useful, but it should still remain weaker than the exact reviewed substitution plan and weaker than the later immutable receipt of what exact text/value/path actually flowed.

So the companion-safe import is:
- substitution comfort may help,
- it may be tiny and fast,
- but exact reviewed spend still needs its own explicit witness lane.

## 2) SlopOS plumb posture again argues for suggest / inspect / admit / compare

Request-local plumb posture is the nearby lesson again.
Substitution surfaces should be excellent at **suggest / inspect / admit / compare**.
They should be much more cautious about silently turning helper outputs, value shapes, or sidecar routes into present command truth.

That means a substitution surface can be rich, but it should confess:
- which exact token the operator typed,
- which helper footing produced the result,
- which exact capture form is claimed,
- whether residue was trimmed or split away,
- whether a sidecar route/path/temp object was created,
- and whether later spend happened as shown.

## 3) Provider-locality pressure says capture packaging is not transcript truth

The newer SlopOS boundary work keeps reasserting that provider-owned/local packaging should not quietly become portable archive truth.
Substitution summaries deserve the same treatment.
A local fold, tooltip, or helper label that says “captured output” should not quietly become the transcript’s durable truth if trailing newlines were deleted, if intermediate values were dropped, if the result was actually a temp-file sidecar, or if a helper child ran in a different scope than the operator assumes.

## 4) ViewFS again supplies the best neighboring-state discipline

ViewFS keeps editable text, parse understanding, diagnostics, compiled packets, prepared actions, and history distinct.
That same discipline should govern substitution-heavy commands:
- typed punctuation,
- parsed helper structure,
- concrete text/value/path result,
- prepared helper sidecar,
- admitted reviewed command basis,
- and later route/value receipts

should remain neighbors rather than collapsing into one flattering “the shell already knows what this means” story.

## 5) Harbor, Ward, Steward, Helm, and Foundry keep the seam honest

- **Harbor** reinforces label honesty, which matters when Schell should say `trim trailing newlines`, `newline split`, `quoted collect`, `scalar`, `array`, `fifo`, `temp file`, or `current-env capture`.
- **Ward** reinforces revalidation pressure, which matters when a sidecar path, FIFO, or temp object can expire or drift before later use.
- **Steward** reinforces adaptation and packaging humility, which matters when a capture summary is a local optimization rather than durable truth.
- **Helm** reinforces omission/miss posture, which matters when trimmed newlines, split behavior, or last-value-only rules silently drop part of helper output.
- **Foundry** reinforces actor/path caveat discipline, which matters when capture crosses from inline text to helper-owned path families or provider-owned sidecar routes.

Together they keep one rule sharp:
**substitution comfort can improve speed, but it must not erase helper footing, capture form, residue posture, lifetime, or exact reviewed basis.**

## 6) What this still does not require Schell to decide

This seam does **not** require Schell to decide:
- one final value-splicing algebra,
- one final sidecar object format,
- one final process-substitution backend,
- one final trim/split constitution,
- one final transcript/export constitution,
- or one final compatibility treaty across Bash/zsh/fish/PowerShell/Nushell.

The archive only needs to prove the honesty stack that says:
- what exact substitution token was typed,
- what exact helper footing produced it,
- what exact capture form was claimed,
- what exact residue posture applied,
- what exact reviewed command basis was admitted,
- and what later receipt confirms or contradicts that capture plan.

## 7) Compact conclusion

SlopOS keeps exact basis narrow and explicit.
ViewFS keeps neighboring states separate.
Harbor, Ward, Steward, Helm, and Foundry keep labels, freshness, omission, packaging, and caveat posture honest.

So the next Schell move should be:

**add substitution witnesses, trim/split residue badges, helper-footing labels, sidecar route cards, and capture-plus-receipt rows so Schell can steal shell capture power without letting tiny substitution syntax quietly become hidden route or residue authority.**
