# SlopOS datacube evaluation — pass VII

This pass keeps one especially important synthesis in view:
**Schell should make scope, live state, and edit authority visible instead of letting the terminal blur them together.**

The latest SlopOS lesson is not only that approvals need exact basis.
It is that several nearby truths must stay separate even when a beautiful terminal UI would rather flatten them:
request versus live state,
enabled versus active,
admission versus completion,
and exact selection versus “something close by.”

That pressure is unusually relevant for a custom shell+terminal because terminals naturally want to turn a single scrollback surface into one flattering story.
Schell should refuse that.

## Strongest SlopOS lessons right now

### 1) Active input should be treated like a bounded authority seam

The InputCapture portal is a useful outside analogy, but SlopOS itself already keeps rediscovering the same structure in multiple places:
there is a big difference between being **eligible** to do something and being **currently active** in a way that changes the world.
The shell+terminal should learn from that.

Local import for Schell:

- there should be one explicit active-input field at a time,
- the terminal may render that field richly,
- pointer editing should only apply where the shell says live input authority exists,
- and old output must not quietly become editable authority just because it looks nearby.

This is a huge opportunity.
It can make the terminal feel much more direct than classic terminals while still being more honest.

### 2) Request identity, acceptance, and live state must not collapse

SlopOS keeps this line sharp across OpenURI, background, approval-basis, and ACP surfaces.
A request object is not the same thing as a live grant.
An accepted action is not the same thing as a finished downstream result.
A previous exact selection is not the same thing as whatever is currently nearest.

Local import for Schell:

- command blocks should record whether they are draft input, admitted action, running action, historical receipt, or background residue,
- richer terminal affordances should disclose which of those statuses they depend on,
- and history search should never imply current liveness.

That means the terminal becomes more informative without becoming a fake live-state oracle.

### 3) Exact selection should beat “nearby object” convenience

The SlopOS selection boundaries are useful pressure against a common terminal temptation:
users clicked near something interesting, so the terminal guesses what object they meant.
Schell should be much stricter.

Local import for Schell:

- clicks should land on explicit shell-emitted objects where possible,
- object cards should carry exact ids or receipts,
- and approximate selection should clearly stay approximate and observational.

This is especially important once the terminal starts offering rerun, reveal, export, attach, or approval actions.

### 4) Scoped surfaces matter more than one giant terminal history

SlopOS does not casually merge unrelated authority surfaces.
That is a useful warning for Schell too.
The shell+terminal should likely keep at least several scopes distinct:

- direct terminal work,
- proposal/agent-assisted work,
- background-state changes,
- receipts and denials,
- and saved workflow artifacts.

Local import for Schell:

- do not let commands run under different authority stories appear identical,
- do not let background output quietly inherit foreground command identity,
- and do not let saved commands masquerade as ambient aliases.

### 5) Saved workflows should be explicit artifacts, not hidden shell folklore

Warp's workflow posture is outside pressure, but SlopOS makes the design judgment clearer.
If a repeated command deserves a name, parameters, and discoverability, that should probably be an explicit artifact rather than another ambient alias or rc-time macro.

Local import for Schell:

- keep workflow-like command reuse explicit,
- let parameters be visible and inspectable,
- bind strong workflow actions to exact reviewed command templates,
- and keep “saved command” separate from “currently approved execution.”

That gives Schell a much better long-run story for reuse without re-importing alias folklore as hidden architecture.

## What Schell should deliberately refuse for now

### Refuse one giant undifferentiated block history

A gorgeous terminal can still lie if direct commands, agent proposals, background residue, and receipts all look like one kind of block.

### Refuse edit authority over historical output

Historical text can be selectable, copyable, pinnable, and inspectable.
It should not quietly inherit the privileges of the one active input field.

### Refuse “accepted means finished” language

The shell+terminal should say when something was admitted, when it started, when it finished, and when later state is simply unknown.

### Refuse ambient aliases as the first workflow story

If Schell wants saved recipes, they should come back as explicit searchable artifacts, not hidden prompt folklore.

## Current consequence for Schell

The best current posture is:

1. **one authoritative active-input field,**
2. **scope-aware blocks and shelves,**
3. **exact object selection before strong action,**
4. **clear request / admission / running / receipt / background distinctions,**
5. **explicit saved workflows instead of ambient aliases,**
6. **and no claim that history equals live state.**

That keeps the shell+terminal ambitious, humane, and much less likely to lie at the exact moment when power matters.
