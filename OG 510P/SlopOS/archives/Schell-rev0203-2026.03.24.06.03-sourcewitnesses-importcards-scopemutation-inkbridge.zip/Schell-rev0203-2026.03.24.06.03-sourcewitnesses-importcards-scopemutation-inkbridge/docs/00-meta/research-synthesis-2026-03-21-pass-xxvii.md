# Research synthesis, pass XXVII (2026-03-21)

This pass keeps another design rule in view:
**transcript export should become much more useful without letting replay, sharing, or sync impersonate current authority.**

The current landscape keeps converging on a helpful split.
The best tools make command boundaries, timing, and exportable command units more explicit.
The safer tools also stay careful about input capture, environment capture, and selective sharing.
That is an excellent clue for Schell.

## 1) Shell-known command boundaries are the foundation for better transcript units

VS Code's terminal shell integration lets the terminal understand more about what's happening inside the shell, enabling working directory detection, command detection, decorations, and navigation.
Its January 2026 terminal enhancements also say terminal commands in chat now show richer details including syntax highlighting and working directory.
That is a strong current clue that transcript cards should be built from shell-known command chapters rather than from scrollback folklore.
See: https://code.visualstudio.com/docs/terminal/shell-integration ; https://code.visualstudio.com/updates/v1_109

## 2) Newline-delimited event streams with markers and exit events are a great fit

asciinema's asciicast v2/v3 formats are both newline-delimited JSON with a header line followed by an event stream.
The formats support output, input, markers, and resize events, and v3 adds an exit event.
Markers may be labeled and used as breakpoints or “chapters.”
That is a very good model for Schell timing/marker sidecars: small appendable event streams with explicit chapter marks beat monolithic opaque blobs.
See: https://docs.asciinema.org/manual/asciicast/v2/ ; https://docs.asciinema.org/manual/asciicast/v3/

## 3) Privacy defaults around input and environment capture are worth stealing

asciinema also gives an unusually good privacy clue.
Its official recorder captures only `SHELL` by default in `env`, and it does not capture keyboard input unless explicitly requested.
That is exactly the sort of discipline Schell should import for transcript export.
Output-first and bounded metadata should be the default; input/env capture should be explicit.
See: https://docs.asciinema.org/manual/asciicast/v3/

## 4) Separate streams and timing files are still a sharp design move

The util-linux `script` tool says that since version 2.35 it supports multiple streams, can log input and output separately or together, and supports a new timing file with additional information.
That is a great clue for Schell.
Replay-critical transcript identity should stay separate from timing and richer viewing aids.
See: https://man7.org/linux/man-pages/man1/script.1.html

## 5) Seekable replay is a real operator affordance

`sudoreplay` can replay logged output in real time or at different playback speeds, and it supports an `@offset` suffix to start replay at a specific time offset.
That is exactly the kind of “super awesome” move Schell can steal without overcommitting the architecture: readonly replay should be bookmarkable, seekable, and clearly non-live.
See: https://www.man7.org/linux/man-pages/man8/sudoreplay.8.html

## 6) JSON-message recording suggests searchable sidecars without forcing one giant storage model

`tlog` inserts itself between terminal and shell and logs everything that passes through as JSON messages.
The lesson is not “record everything by default.”
The lesson is that searchable transcript sidecars can be explicit event objects rather than ad hoc text logs.
See: https://scribery.github.io/tlog/

## 7) Selective share is better than one giant export button

Warp's block sharing is explicitly opt-in and lets the user choose which parts of the block to share, such as command, output, or prompt.
Warp block actions also let command blocks copy the command, output, or both.
That is one of the best current clues for Schell transcript export: attach, copy excerpt, export scrubbed bundle, and publish should be distinct actions with different included fields.
See: https://docs.warp.dev/terminal/blocks/block-sharing ; https://docs.warp.dev/terminal/blocks/block-actions

## 8) Terminal and agent transcript lanes should remain separate

Warp's agent modality docs say terminal blocks appear in the terminal blocklist and can be attached as context, while agent conversation blocks stay scoped to that specific conversation and do not appear in the terminal blocklist.
That is a strong precedent for Schell.
Human-run terminal chapters, help-lane artifacts, and agent-lane artifacts should not collapse into one flattering transcript family.
See: https://docs.warp.dev/agent-platform/local-agents/interacting-with-agents/agent-modality

## 9) A compact Schell v0 cluster is strong

A decision-light first cut probably needs only:
- one **transcript card** family bound to exact shell-known chapters,
- one **replay bundle** action with a visible “what's inside” summary,
- one **output-first default redaction profile**,
- one **timing / marker witness** sidecar,
- one **readonly replay** action that stays visibly non-live,
- and one **lane split** between terminal chapters and help/agent artifacts.

## 10) Decisions intentionally kept open

This pass does **not** freeze:
- one recording backend,
- one storage or sync model,
- one notebook or publishing backend,
- one transcript-search database,
- one collaboration service,
- or one universal cast format.

The no-regret move is narrower:
**make transcript units exact, replay posture explicit, sharing selective, and redaction visible, while keeping export, attach, replay, and publish clearly distinct.**
