# SlopOS datacube evaluation, pass CXIX (2026-03-22)

This pass evaluates one narrower question against the current companion archives:
**what do SlopOS and the nearby datacubes teach Schell about projecting shell-owned semantic truth into multiple terminal/mux escape-sequence families without letting one compatibility story quietly become the architecture?**

The answer is crisp:
**treat semantic transport as an explicit family map with profile badges and loss confession, not as one hidden treaty.**

## 1) SlopOS keeps telling us to prefer named families over folklore

The SlopOS archive is full of small closed families, explicit indexes, schema companions, and fail-closed contracts.
That style matters here.
A shell+terminal that emits several integration dialects should not just spray escape codes from whichever helper knows them.
It should keep an explicit family story:
- what semantic facts exist internally,
- what profile is being projected externally,
- what fields are dropped,
- and what hop/adapter posture caused the loss.

That is the shell equivalent of SlopOS's boundary and adjunct discipline.

## 2) SlopOS also reinforces internal truth before export posture

Across the companion archive, exported bytes and descriptive artifacts stay weaker than live internal authority.
That transfers directly here.
An external terminal profile such as `OSC 133`, `OSC 633`, or `OSC 1337` should be treated as a projection of shell-owned semantic truth, not the origin of truth.

In practical terms, Schell should know more than any one terminal can currently consume.
That lets it preserve exact internal footing while projecting a weaker subset when the terminal, mux, or remote hop cannot carry everything.

## 3) ViewFS reinforces explicit lanes and adapter posture

ViewFS keeps observe, attach, control, exec, and sideband lanes separately named rather than allowing one flattering “live connection” myth.
That same discipline applies here.

Schell should distinguish:
- shell-owned semantic truth,
- projected terminal marks,
- mux-relayed marks,
- replayed historical marks,
- and plain local renderer inference.

Those are different lanes of truth even when the UI wants to feel seamless.

## 4) Steward reinforces freshness-scoped chrome

Steward keeps trusted chrome tied to freshness and provenance.
That is exactly the right pressure for semantic transport too.
A prompt chip, command frame, click-to-edit affordance, or select-output action should be able to say whether it is powered by:
- fresh shell-native projection,
- transported-but-weaker marks,
- mux-relayed marks,
- restored historical state,
- or plain local inference.

That is the companion-compatible version of transport honesty.

## 5) Companion-safe no-regret move

Schell does **not** need to freeze one universal escape-sequence treaty, one mux policy, or one remote-helper installer.
It only needs a few bounded rules:

### A) Keep internal semantic truth smaller and stronger than any one wire format
Prompt/input/output/cwd/exact-command-line truths should remain shell-owned first.

### B) Name external projection profiles explicitly
`portable-core`, `vscode-rich`, `iterm-augmented`, `kitty-augmented`, `tmux-relayed`, and `historical-only` are the right kind of distinction.

### C) Make projection loss visible
A dropped field, stripped mark, downgraded profile, or historical replay should say so.

### D) Keep terminal delight weaker than shell truth
A richer terminal family may unlock nicer UX.
It should not become the source of semantic authority.

### E) Keep a text-truth path alive
The transcript should remain truthful and auditable even when live transport is richer.

## 6) Compact conclusion

The SlopOS-compatible answer is not “pick the best terminal protocol and standardize on it.”
It is:
**define one compact internal semantic core, project it into named external profiles, badge projection loss honestly, and keep projected terminal metadata weaker than shell-owned truth.**

That is a design-phase-safe move because it makes Schell much more portable and much easier to trust without forcing the final renderer, mux, or protocol stack.
