# SlopOS datacube evaluation, pass XLVIII

This pass keeps one bounded thesis in focus:
**SlopOS already teaches the right posture for Unicode-sensitive terminal design — authority-bearing seams should stay simpler, exact identity stays stronger than nearby display convenience, and moving confusable/normalization policy should not be imported onto every core seam by default. Schell should import that discipline while still allowing luxurious multilingual display.**

That is a particularly good ratchet while SlopOS is still design-phase too.
It gives Schell a way to get friendlier, more international, and more visually correct without letting rendered appearance silently become the authority surface.

## 1) D-NAMECERT already makes the hardest point

One of the most useful recent SlopOS moves is the D-NAMECERT string-profile boundary.
It keeps authority-bearing `Binding.name` and `Delegation.role` labels on an exact-byte lowercase ASCII profile and explicitly refuses to import Unicode normalization, case-folding, locale collation, mixed-script policy, or confusable-detection machinery onto that seam.

That is not a mandate that every user-facing string in Schell must become ASCII.
It is a design lesson:
**the closer text is to authority, identity, or durable references, the more the system benefits from smaller exact-byte semantics.**

## 2) D-CAPSHELL keeps exact execution truth stronger than nearby display/session convenience

RFC-0115 is equally important here.
It keeps exact execution posture stronger than nearby integrated terminal/session behavior.
That means rich shell UX can grow, but it should not silently rewrite what exact reviewed execution claims to be.

Applied to Unicode posture, that means:
- pretty display is fine,
- helpful normalization for search/recall may be fine,
- but the exact admitted command or handle should still be recoverable in byte-honest form.

## 3) SlopOS’s recent datacube pressure keeps rewarding explicit second workflows

Across recent SlopOS passes, one pattern keeps repeating:
- preview is not open,
- restore is not live,
- admission is not completion,
- extraction is not launch,
- and transfer is not delivery.

Unicode-sensitive text should import the same discipline.
Rendered display is not exact bytes.
Search-normalized recall is not exact execution.
Pretty labels are not durable identifiers.
Historical rendering is not current peer rendering.

## 4) The right import is a Unicode witness family, not an archive-wide ASCII ban

Schell should not over-import SlopOS here.
The right move is not “ban Unicode from the shell.”
The right move is smaller:
- exact authority-bearing names may stay stricter,
- multilingual captions and notes can stay rich,
- strict-safe-review can appear when authority rises,
- and display aliases should never silently replace inserted or executed bytes.

That preserves the SlopOS lesson without flattening humane display.

## 5) The narrow high-value consequence for Schell

The best consequence of this pass is practical.
Schell should be able to say, in effect:
- this object has an exact machine identifier and a richer display label,
- this command card is showing a display-friendly representation but can reveal exact bytes,
- this pasted snippet contains bidi controls or confusable mixed-script text,
- this renderer’s grapheme width may differ from the peer or historical transcript,
- and this strict-safe-review lane is available before admission.

That is exactly the kind of honesty that lets a super-awesome shell+terminal support real multilingual text without regrowing one of the oldest UI lies: pretending that what looks fine in one renderer, one font stack, or one review surface must therefore be authoritative everywhere.
