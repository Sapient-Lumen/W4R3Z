# SlopOS datacube evaluation, pass LIII

**If Schell borrows snippet or live-template luxuries, SlopOS says the safe version is still a reviewed exact launch shape plus explicit editing witnesses. Snippet expansion may help compose active input, but it must not become hidden shell code, hidden ambient variable acquisition, or hidden reinterpretation of exact argv truth.**

This pass focuses on a deceptively small seam:
- tabstops,
- mirrored placeholders,
- choice lists,
- wrap-selection moves,
- variable fills,
- and template transforms.

The reason this seam matters is simple.
A modern shell+terminal will obviously want editor-grade input comfort.
But template systems are old enough to carry dangerous habits:
- executable expansion hooks,
- ambient state capture,
- dynamic data lookups,
- and invisible rewrites between what the operator saw and what actually launches.

SlopOS gives Schell a strong answer: keep templates as bounded editing help over exact reviewed inputs, not as a second execution language.

## 1) CH-ARGV posture still says launch truth is a reviewed token list

The strongest import remains CH-ARGV.
Reviewed launch shape is already a structured token list with one exact executable selector.
That means snippet witnesses, placeholders, or live-template fields should be understood as **editing handles over visible launch material**, not as an alternate macro language that later compiles into the real command.

## 2) Capshell command-string refusal says template expansion must not hide a second parse

The capshell command-string posture is especially valuable here.
It refuses hidden `sh -c` / `system()` fallback and keeps command-language semantics out of the runner unless the workflow explicitly chooses a shell as the executable.
That means snippet expansion must not behave like:
- build a flattering command string,
- hide transforms inside it,
- and secretly reparse that string later.

The import is direct:
**template expansion should end in visible editable input or visible reviewed argv, not in a private string adapter.**

## 3) Word-expansion refusal says snippet variables are not harmless folklore

Once SlopOS refuses shell-style word expansion and wildcard folklore at launch, the next dangerous temptation is snippet variables.
Editor snippets often expose things like current file, current selection, clipboard contents, or date/time.
In Schell, those are not harmless conveniences unless their source is visible.
A clipboard fill or selection-derived default can absolutely change execution meaning.

So the right import is:
- variables may exist,
- but they need provenance badges,
- unresolved variables should stay unresolved rather than auto-guessed,
- and operator review should stay stronger than expansion convenience.

## 4) Exact executable identity pressures transforms much harder than editors usually do

SlopOS's executable-object posture means executable identity stays stronger than pretty names, aliases, or mutable labels.
That puts pressure on snippet transforms.
A template transform that uppercases a display label is one thing.
A transform that rewrites an executable token, host, secret ref, path root, or authority-bearing flag is much more dangerous.

So Schell should start with a stricter law than editors do:
**meaning-affecting transforms are not ordinary snippet sugar.**

## 5) Env/cwd exactness warns against ambient defaults in template fills

SlopOS also pins env and cwd posture much more tightly than ordinary shell culture.
CH-ENV stays exact and review-visible, with no hidden convenience baseline.
CH-CWD selects a bound cwd root rather than “wherever the launcher happened to be.”
That means template defaults sourced from cwd, env, workspace, or shell session state should remain visibly ground-bound and weaker than reviewed launch truth.

This is another reason to avoid pretending snippet variables are just text decoration.
In Schell they can import ambient state unless the archive keeps them visibly basis-bound.

## 6) Learn-mode posture warns against autofill becoming hidden policy editing

SlopOS learn-mode posture is observational only.
That is an excellent constraint for template luxury too.
A clever system may suggest:
- a missing host,
- a likely namespace,
- a repeated ticket id,
- or a common enum value.

But suggestion/autofill should stay proposal-only.
No auto-edit, auto-approve, or auto-rerun loop should hide behind "smart snippet completion."

## 7) The clean import: snippet witnesses, not snippet authority

The best SlopOS-compatible import now looks like this:
- templates live inside active input,
- expansions are visible and editable,
- mirroring requires explicit same-field identity,
- choices are bounded and source-labeled,
- variables carry provenance,
- transforms are split into display-only versus meaning-affecting,
- and run remains separate.

This fits the rest of the archive very well.
It keeps shell+terminal delight in the operator surface while preserving one exact reviewed action underneath.

## 8) What Schell should refuse right now

Under current SlopOS pressure, Schell should refuse:
- interpolated shell code inside templates,
- hidden clipboard/current-file/current-cwd insertion with no provenance badge,
- dynamic enums populated by effectful background helpers without explicit freshness/cost posture,
- auto-run after expansion,
- and transforms that silently retarget executable identity or authority-bearing destinations.

## 9) Decision-light next move

A strong next move is to define one **snippet witness** family for active input that proves:
- tab order,
- mirrored placeholders,
- choice lists,
- wrap-selection,
- variable provenance,
- and transform humility
can all exist without introducing a second parser or hidden execution plane.

That would keep Schell ambitious while still learning the right lesson from SlopOS:
**pleasant composition is welcome, but exact reviewed launch shape stays stronger than template magic.**
