# SlopOS datacube evaluation, pass XC (2026-03-22)

This pass evaluates capability negotiation, feature admission, adapter confession, and downgrade posture against the current SlopOS archive.
The result is strong:
**SlopOS rewards a shell+terminal that treats feature claims as evidence and local policy input, not as self-executing truth.**

## 1) SlopOS already prefers explicit identity over guessed compatibility

RFC-0071 is the cleanest import here.
It says interface identity should be explicit, unknown interfaces or methods must not trigger guessing, and true compatibility should be delivered by explicit adapters or translators rather than hidden fallback logic.

For Schell this implies:
- a richer capability claim is not permission by itself,
- unknown should remain visible instead of being silently mapped to “something similar,”
- and mux/remote/helper compatibility should be named as adaptation rather than native truth.

## 2) SlopOS keeps acceptance local and explicit

The signature-algorithm acceptance boundary is a particularly useful analog.
It says imported algorithm identifiers are exact evidence of how something was produced, but acceptable algorithms remain explicit verifier-local policy, and Phase 1 refuses a hidden strongest-wins or negotiation plane.

That is an excellent fit for terminal capability posture.
For Schell this implies:
- TERM/terminfo claims, runtime responses, and helper-installed workarounds should be evidence inputs,
- but local acceptance of a stronger behavior should stay explicit,
- and “the environment offered it” should never silently become “the shell relied on it safely.”

## 3) SlopOS makes adapters first-class instead of secret folklore

Across the companion archive, compatibility surfaces become explicit components, import boundaries, or posture pins instead of ambient blur.
That strongly suggests the right Schell answer is not a giant hidden compatibility layer.
It is:
- capability-ground cards,
- bridge/adaptation strips,
- downgrade badges,
- and explicit why-cards for failed or translated features.

For Schell this implies:
- remote TERM fallback should be visibly weaker than a native terminfo-backed footing,
- mux translations should be visibly different from direct terminal support,
- and helper injection should be treated as startup footing, not as invisible native capability.

## 4) SlopOS also keeps current mutable state separate from request or evidence handles

The broader archive repeatedly separates stable request identity from provider-owned current mutable state.
That pattern is helpful here too.
A recorded capability claim or startup-time descriptor should not masquerade as current live feature truth if the transport, mux, remote host, or helper posture has changed.

For Schell this implies:
- static claim and runtime-confirmed capability should stay separately named,
- restored/exported capability info should remain historical,
- and strong feature-dependent actions should be able to demand fresh capability evidence when it matters.

## 5) What this pass now strongly suggests for Schell

The most companion-compatible moves are:
- **capability-ground cards**,
- **negotiation ladders**,
- **adapter confession strips**,
- **downgrade badges**,
- **runtime query versus static claim splits**,
- and **fresh-capability why-cards** before stronger feature-dependent actions.

## 6) Decisions this pass still refuses to make too early

This pass still does **not** force:
- one final capability registry,
- one final TERM/terminfo strategy,
- one final runtime query protocol suite,
- one final mux bridge protocol,
- or one final remote fallback/install story.

The answer stays smaller and stronger:
**let Schell become excellent at explaining native support, translated support, degraded-safe fallback, and unknown posture while keeping capability acceptance explicit and harder than compatibility folklore.**
