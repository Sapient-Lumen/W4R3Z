# SlopOS datacube evaluation, pass CXXVII (2026-03-22)

This pass evaluates one narrower question against the current companion archives:
**what do SlopOS, Steward, and ViewFS teach Schell about secure input, sensitive entry, and local keywatcher suppression?**

The answer is crisp:
**protective input posture should be lease-shaped, source-labeled, and visibly weaker than semantic certainty about what the shell is being asked.**

## 1) SlopOS already has the right nearby seam

SlopOS RFC-0080 keeps high-risk consent and secure attention in a stronger trusted path, and its optional secure-input session is explicitly a lease with TTL, explicit release, visibility, and compatibility tradeoffs.
That is exactly the right companion pressure for Schell.
The import is not "the terminal knows a password prompt when it sees one."
The import is:
- lease-shaped activation,
- explicit scope,
- visibility while active,
- deterministic release and recovery.

## 2) Capability wallets argue for witness chips, not magical prompt detection

SlopOS repeatedly keeps descriptive summaries weaker than live authority.
So a `secure input active` badge should summarize local footing, not silently grant semantic certainty about the current program state.
This is the same rule Schell already learned for identity cards, provenance grades, and capability grounds.

## 3) Steward keeps trusted chrome honest about source and freshness

Steward's strongest adjacent lesson is still trusted chrome humility.
A secure-input indicator should say where it came from and how fresh it is:
- shell-owned witness,
- terminal-local witness,
- OS-level secure-input witness,
- restored historical report,
- inferred only.

## 4) ViewFS keeps lanes separate

ViewFS repeatedly rewards lane separation.
Secure input has the same problem.
There is a difference between:
- ordinary typed input,
- sensitive-entry posture,
- trusted-attention mode,
- hidden-value materialization,
- local replay/history,
- automation or assistive observation.

Those should stay separately named.

## 5) Companion-compatible no-regret move

Schell does **not** need a final cross-platform secure-attention stack yet.
It only needs a few bounded rules:

### A) Keep protection weaker than semantic certainty
`secure input active` does not equal `password prompt proved`.

### B) Keep scope explicit
pane-local, tab-local, app-wide, trusted-path, restored.

### C) Keep side effects visible
blocked hotkeys, focus stealing, reveal/paste/history downgrades.

### D) Keep release explicit
manual release, auto-expiry, prompt-baseline reassertion, or app quit.

## 6) Compact conclusion

The companion-safe answer is not "detect secrets automatically and trust the mode."
It is:
**build secure-input witnesses and sensitive-entry lanes that show local protection, scope, side effects, and release posture while refusing to overclaim shell semantic certainty.**
