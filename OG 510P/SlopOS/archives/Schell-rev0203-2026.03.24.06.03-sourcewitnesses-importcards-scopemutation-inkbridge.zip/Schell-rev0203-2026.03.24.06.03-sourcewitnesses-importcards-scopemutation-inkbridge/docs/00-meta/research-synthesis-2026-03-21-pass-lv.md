# Research synthesis, pass LV (2026-03-21)

This pass keeps one fresh design rule in focus:
**Schell should steal abbreviation luxury — late expansion, command-scoped shorthands, cursor landing, and insert-time preview — but only if abbreviations stay active-input help rather than runtime alias folklore, hidden parser magic, or script-time semantics.**

This seam matters because shell history already contains both the delight and the trap.
People clearly love short forms.
They reduce typing, preserve muscle memory, and make repeated commands feel personal.
But traditional alias systems also teach the wrong lesson:
- expansion can happen at parse time instead of review time,
- aliases can be profile-local folklore,
- global aliases can rewrite more of the line than the operator expects,
- and script readability can degrade badly when shorthand escapes the interactive lane.

## 1) fish proves that interactive shorthand is best when it expands in the command line, not at launch

fish's current `abbr` docs are unusually useful for Schell because they keep abbreviation behavior close to editing.
Abbreviations can expand only in command position or anywhere, can be scoped to particular commands, can use regex matching, and can even place the cursor at a chosen marker after expansion.
That is a terrific Schell clue.
The steal is not “adopt fish syntax wholesale.”
The steal is the shape of the luxury:
**shorthand should expand while the operator is still looking at editable input.**
See: https://fishshell.com/docs/current/cmds/abbr.html

## 2) fish also shows the right split between interactive abbreviation and command/function definition

fish's `alias` docs make the distinction very plain.
`alias` is just a simple wrapper around a function, and the docs explicitly say that if the goal is easier interactive use, operators should consider an abbreviation instead.
That is one of the best current design hints available.
Schell should not force one mechanism to do both jobs.
Interactive shorthand and reusable command artifacts deserve different names and different trust stories.
See: https://fishshell.com/docs/current/cmds/alias.html

## 3) Bash keeps the strongest historical warning sign: parse-time alias rules are confusing

The Bash manual is valuable because it states the foot-gun with unusual honesty.
Aliases expand when a command is read, not when it is executed.
Alias definitions on the same line do not affect later commands on that line, and aliases are generally an interactive feature unless `expand_aliases` is enabled.
That is exactly the sort of historical complexity Schell should refuse to recreate.
The lesson is not merely “aliases are old.”
The lesson is:
**runtime or parse-time shorthand that is weaker than reviewed visible input quickly becomes confusing folklore.**
See: https://www.gnu.org/software/bash/manual/html_node/Aliases.html

## 4) PowerShell reinforces that aliases are an interactive convenience, not a script contract

Current Microsoft guidance is also unusually crisp.
Aliases cannot include parameters, and the documentation explicitly says not to use aliases in scripts because they are a convenience feature for interactive use.
That is a very healthy Schell import.
Abbreviation-style help should be allowed to stay local, ergonomic, and interactive.
Script/runtime meaning should stay explicit and legible.
See: https://learn.microsoft.com/en-us/powershell/scripting/learn/shell/using-aliases

## 5) Nushell shows a parser-keyword alias story that still stops short of "everything is an alias"

Nushell's alias docs are helpful because they keep aliases deliberately limited.
They are simple replacements, can include default arguments, and the docs explicitly redirect anything pipeline-like to a real command definition instead.
That reinforces a Schell design instinct already forming in the archive:
keep simple shorthand simple, and escalate richer behavior into a separately named artifact.
See: https://www.nushell.sh/book/aliases.html

## 6) zsh's global aliases are the cautionary tale Schell should not inherit

zsh remains the cleanest example of how clever shorthand becomes dangerous.
Its introduction documents global aliases that can be substituted anywhere on a line and explicitly warns that they have macro-like confusion potential.
That warning matters more than the feature.
Schell should be very cautious about any shorthand that can rewrite non-command positions or silently change pipes, paths, hosts, or inline operators.
See: https://zsh.sourceforge.io/Intro/intro_8.html

## 7) The stealable move: abbreviation witnesses in active input

The best decision-light move now looks like this:
1. a short form is typed into active input,
2. Schell shows an abbreviation witness,
3. expansion remains previewable and editable before run,
4. command-scoped or position-scoped rules stay visible,
5. cursor landing is explicit when the shorthand expands into a larger form,
6. and stronger reusable behavior gets promoted into a workflow seed, function, or other separately named artifact instead of hiding inside alias folklore.

That is powerful because it makes daily typing faster without forcing a final parser, rc-file story, alias file format, or universal macro language.

## 8) A few lessons from the past are now clear enough to state bluntly

Past shells repeatedly made these mistakes:
- treating parse-time shorthand as harmless,
- letting rc/profile files silently import command meaning,
- letting global or context-insensitive aliases rewrite too much,
- and letting scripts inherit local shorthand habits that wreck portability and review.

The healthier lesson is narrower:
**make shorthand expand before review, keep it interactive-first, and do not let it become hidden execution semantics.**

## 9) A compact first proving slice

A compact proof could show:
- one command-position abbreviation,
- one command-scoped abbreviation,
- one expansion preview card,
- one cursor-landing expansion,
- one explicit promote-to-workflow or promote-to-function move,
- and one refused global/runtime expansion that would otherwise rewrite too much.

That would already make Schell feel delightfully custom without forcing the final shell language, config format, or startup policy.

## 10) Decisions intentionally kept open

This pass does **not** freeze:
- one final abbreviation syntax,
- one startup/profile storage story,
- one function/workflow promotion format,
- one parser-owned shorthand algebra,
- or one script-visible alias mechanism.

The no-regret move is smaller:
**steal late expansion, command-scoped shorthand, and cursor landing — but keep them insert-first, previewable, and weaker than exact reviewed launch truth.**
