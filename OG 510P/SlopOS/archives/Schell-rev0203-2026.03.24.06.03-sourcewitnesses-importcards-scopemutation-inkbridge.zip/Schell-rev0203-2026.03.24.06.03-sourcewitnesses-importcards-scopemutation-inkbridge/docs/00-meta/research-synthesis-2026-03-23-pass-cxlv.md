# Research synthesis — 2026-03-23 — pass CXLV

This pass sharpens one fresh shell+terminal lesson from current upstream docs:
**the ecosystem is getting better at running parallel coding or automation lanes inside isolated repo copies, but the best current tools still work only because they keep the isolated lane reviewable and give the operator an explicit path to bring changes back.**

That means the next useful Schell move is not “let helpers edit my live checkout more aggressively.”
It is a smaller honesty move:
**parallel repo lanes, adoption gates, and live-checkout humility.**

## 1) VS Code now treats worktree isolation as a real working mode, not just a Git trick

Current VS Code docs are unusually clear here.
Copilot CLI sessions now let the operator choose between **worktree isolation** and **workspace isolation**.
In worktree isolation, VS Code creates a Git worktree in a separate folder, keeps agent changes there, auto-approves tool calls in that isolated lane, and then expects the operator to review and apply those changes back into the main workspace when ready.
The January 2026 release notes say background agents can also run in dedicated Git worktrees so multiple agents can work side by side without conflicts, and they highlight an explicit apply-back action.

That is one of the cleanest current clues for Schell.
The luxurious thing is not just “parallel agents.”
It is **parallel lanes with an explicit way home**.

## 2) Codex turns worktrees into a first-class parallel-work luxury

Current Codex app docs push the same lesson from another direction.
They say a thread can run in **Local** or **Worktree** mode.
Worktree mode creates a new Git worktree so changes stay isolated from the regular project, and the docs recommend it when you want to try a new idea without touching current work or when you want parallel tasks side by side in the same project.
The automations docs go further: for Git repositories, automations can run either in the local project or on a dedicated background worktree, and worktrees are explicitly recommended when you want to isolate automation changes from unfinished local work.

This matters because it shows the operator-facing value proposition.
Parallel isolated repo lanes are not just a security story.
They are also a **thrash-reduction** and **unfinished-work protection** story.

## 3) Claude Code shows that “worktree lane” is really a broader isolated-working-copy seam

Claude Code’s hooks docs add a very important twist.
The `WorktreeCreate` hook can replace the default `git worktree` behavior and point Claude Code at an SVN, Perforce, Mercurial, or other working copy instead.
That means the load-bearing concept is not only “Git worktree.”
It is **an isolated working lane whose path is explicitly handed to the agent or helper**.

That is exactly the kind of thing Schell should steal.
It suggests that the portable surface should be named around:
- lane creation,
- lane footing,
- lane ownership,
- review,
- adoption,
- and discard,
not around one VCS implementation detail.

## 4) Git’s own docs warn that worktrees are separate but not totally independent

The official Git docs also give a useful warning label.
`git worktree` manages multiple working trees attached to the same repository, allowing more than one branch to be checked out at a time.
But the repository-layout docs say that when multiple worktrees are used, most files in `$GIT_DIR` are per-worktree **with a few known exceptions**, and files under `common` are shared between all working trees.

That is a perfect humility lesson for Schell.
A parallel repo lane is helpful, but it is not a mythically independent universe.
The product should not overclaim isolation when references, shared metadata, credentials, or repository-wide state still have shared footing.

## 5) The stealable move is explicit lane cards plus adoption gates

The best move to steal from the current ecosystem is therefore not “make parallel runs default.”
It is:
- a **lane card** that says where the helper is actually working,
- a visible **foreground checkout chip** for the operator’s live tree,
- a **shared-metadata badge** when the lane is isolated-but-still-related,
- an explicit **adoption gate** for bringing lane changes back,
- and a cheap **drop lane** path when the work turns out not to matter.

That keeps luxury and truth aligned.
The operator can run side-by-side work without losing sight of which checkout is the one they are currently inhabiting.

## 6) This is a better “super awesome” move than one more giant agent/runtime bet

This seam is unusually good because it stays decision-light.
Schell does not need to freeze:
- a final VCS,
- a final merge UI,
- a final background-agent runtime,
- or a final automation scheduler
just to prove the value of parallel repo lanes.

It only needs a small shell+terminal surface that says:
- this is the live foreground checkout,
- this is a parallel isolated lane,
- this lane borrowed these footing facts,
- these repository facts remain shared,
- and adoption back into the foreground is a separately named stronger act.

## 7) Compact conclusion

Current upstream docs are converging on the same truth from several directions:
- VS Code uses Git worktrees to isolate background or CLI-agent changes and then emphasizes review/apply-back.
- Codex uses worktree mode to isolate changes from regular local work and to let parallel tasks proceed without thrashing the main checkout.
- Claude Code’s hook model shows the seam is really “isolated working lane creation,” not one sacred Git-only product feature.
- Git itself reminds us that worktrees are related working trees with shared repository structure, not total universes.

Schell should take the hint.
The next no-regret shell+terminal luxury is **parallel repo lanes with explicit adoption gates**:
**keep isolated lanes, live foreground checkout truth, adoption-back acts, and drop-lane exits visibly separate so helper comfort never silently impersonates live local truth.**
