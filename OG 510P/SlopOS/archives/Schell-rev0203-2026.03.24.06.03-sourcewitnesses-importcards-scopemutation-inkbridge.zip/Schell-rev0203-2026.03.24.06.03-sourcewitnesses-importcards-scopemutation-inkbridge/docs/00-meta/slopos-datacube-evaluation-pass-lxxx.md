# SlopOS datacube evaluation, pass LXXX (2026-03-22)

This pass deepens one specific Schell question against current SlopOS pressure:
**how should Schell help people discover commands, examples, fixes, and next actions without letting ambient search, guessed intent, or example cards quietly become execution truth?**

The companion archive again rewards a smaller answer than the mainstream ecosystem usually offers.
SlopOS keeps preferring scoped query seams, typed intents, explicit routes, and learn-mode reports over global indexes, ad-hoc handler folklore, or hidden “helpful” mutation.
That pressure is an excellent antidote to over-magical shell guidance.

## 1) SlopOS attribute-query posture says search should know its scope

RFC-0100 remains one of the clearest companion pressures for Schell discovery.
Its attribute-query and smart-folder posture explicitly rejects an ambient global index and instead keeps queries capability-scoped, bounded, deterministic, and view-relative.
That maps directly onto shell help.
Schell should therefore prefer explicit discovery scopes — current command family, current project pack, current capability view, user shelf, imported team pack, system docs — rather than one unbounded “search everything everywhere” gesture.

That one rule already makes help and command search much more compatible with the rest of the archive.

## 2) SlopOS SKB posture says named queries beat one giant help brain

RFC-0018 is about hardware facts, not shell docs, but its design lesson is highly portable.
The System Knowledge Base stays user-space, answers pure named queries, and resists standardizing a whole sprawling logic language too early.
That is exactly the right pressure for Schell help discovery too.

Schell does not need one giant omniscient query language on day one.
A smaller answer is better:
- find command by description,
- find example by tags,
- find flag docs for current command,
- find workflow seed in current project pack,
- explain why this suggestion appeared.

Those named query families are easier to review and easier to keep honest.

## 3) SlopOS plumb-first intent posture says next actions should be typed

RFC-0117 keeps cross-application routing pinned to typed message envelopes and shell-owned “plumb-first” tools.
That pressure is perfect for help surfaces.
When Schell offers a next action after a search or suggestion, it should not flatten everything into a clickable mystery button.
It should say whether the next action is:
- help,
- replace buffer text,
- open manual,
- open safe preview,
- export example,
- install helper,
- or route to another typed workflow.

Typed next actions keep discovery luxurious without turning it into ambient action roulette.

## 4) SlopOS capshell learn mode says denied work should teach without silently widening authority

RFC-0115’s learn-mode posture is especially valuable here.
When a workflow lacks authority, the system should emit a deterministic report of what was required instead of silently widening the contract.
That is a very strong clue for Schell’s quick-fix and command-not-found behavior.
A great shell help surface should be able to say:
- command missing,
- flag unknown,
- capability missing,
- path/view unavailable,
- helper absent,
- or action denied under current footing,

and then show reviewable next steps.
What it should not do is silently install, widen, or reroute just because the suggestion engine feels confident.

## 5) The companion archive keeps pushing examples and discovery below exact basis

Across the companion archive, the stronger facts stay bound to exact bytes, exact digests, exact handles, exact views, and exact approval basis.
That means example pages, command predictions, quick-fix cards, and fuzzy previews should all remain weaker than exact approved action.
They are still valuable.
They just should not get to impersonate the command basis, the approval packet, or the durable receipt.

This is one of the clearest points where SlopOS helps Schell resist product temptation.

## 6) What this pass now strongly suggests for Schell

The most companion-compatible discovery moves are:
- **help-ground cards** with explicit source family and claim strength,
- **query scopes** that remain view/project/user/system/imported instead of ambient,
- **source-labeled prediction chips** for history/plugins/bridges/packs,
- **typed next-action offers** instead of opaque affordances,
- **preview-first choosers** that stay inert,
- **command-not-found cards** that separate search/help/install/replace-buffer actions,
- **example-only cards** that remain distinct from normative help,
- and **learn-mode denial cards** that teach what is missing without silently fixing it.

## 7) Decisions this pass still refuses to make too early

This pass still does **not** force:
- one final Schell help corpus,
- one final query language for discovery surfaces,
- one final ranking engine,
- one final predictor or model-backed suggestion stack,
- one final bridge protocol,
- or one final command-not-found remediation backend.

The answer stays smaller and stronger:
**let Schell become wonderful at finding, explaining, previewing, and suggesting — but keep scope, source, and exact approved action separately named so discovery never impersonates execution truth.**
