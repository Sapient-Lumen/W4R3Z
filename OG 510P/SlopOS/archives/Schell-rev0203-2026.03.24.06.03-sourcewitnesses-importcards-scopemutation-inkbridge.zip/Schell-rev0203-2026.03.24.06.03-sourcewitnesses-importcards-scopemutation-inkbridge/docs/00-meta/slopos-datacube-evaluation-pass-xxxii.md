# SlopOS datacube evaluation, pass XXXII

This pass keeps one bounded thesis in focus:
**SlopOS keeps teaching that admission, observation, readiness, history, and completion are not interchangeable truths. Schell should steal that discipline before its terminal grows too many cheerful but misleading success surfaces.**

This is especially worth importing now because SlopOS is still design-phase too.
The boundary family is still being shaped while the mistakes are still cheap to avoid.
The newest companion revision sharpens the lesson in a way that maps directly to shell+terminal UX.

## 1) The OpenURI family is extremely strict about what launch proves

The newer OpenURI boundaries do not let mediated launch become:
- preview metadata truth,
- speculative-loading truth,
- durable recent-item truth,
- content-extraction truth,
- materialization truth,
- or downstream completion truth.

The launch-completion boundary is especially important.
It says the portable result is admission-scoped: the request was carried out at the seam.
It does not prove the target rendered content, stayed alive, or that the user definitely saw it.

That is a direct Schell lesson.
The terminal should stop flattening:
- inserted,
- reviewed,
- admitted,
- running,
- completed,
- and user-consumed,
into one generic green state.

## 2) Recent-items refusal is really a warning about fake continuity

OpenURI recent-items refusal matters here too.
SlopOS is warning that shell-local recents may be useful, but they must not become stable reopen authority or truth about durable persistence.

For Schell, that means history hits, restored panes, discovery decks, and recent object cards should remain:
- shell-local,
- historical,
- staged,
- or weakly actionable,

until a fresh exact witness upgrades them.

## 3) The import-to-docref boundaries reinforce identity-before-reuse

The fresh-identity and bearer-provenance import boundaries keep saying the same thing from another angle:
reused bytes or remembered provenance are not permission to collapse distinct events into one identity.

That is highly relevant to shell+terminal design.
A restored launch target, a remembered semantic link, or a cached object hint should not be promoted to “same live thing” just because some representation looks similar.
The operator deserves exact identity, not cache-shaped optimism.

## 4) Restore-repair posture gives Schell a ladder for resumed state

The microvm restore-repair barrier is one of the strongest companion lessons in the whole datacube.
Restored state must complete repair before it gets to look externally ready.

Schell should import the UX twin:
restored commands, panes, links, viewers, or remote lanes should re-enter low on the ladder:
- restored,
- suspended,
- awaiting witness,
- or historical,

not as automatically ready or complete.

## 5) capshell keeps warning that surface wording can smuggle false certainty

capshell already refused command-string folklore, startup-profile magic, and hidden expansion.
The same posture applies to outcome wording.
If the shell or terminal says:
- done,
- opened,
- delivered,
- resumed,
- restored successfully,

without an exact witness, then language itself becomes a hidden second workflow.
The operator is being asked to believe more than the system actually knows.

## 6) The practical Schell import is a handoff ladder

The smallest good import now is not a giant lifecycle engine.
It is a narrower rule:
- proposal state,
- review state,
- handoff admission,
- observed target state,
- shell-owned completion,
- and user-consumed/effect-fully-realized state

should remain distinct.

This helps across almost every ambitious terminal move:
- object-card open/reveal,
- workflow seed run,
- restored command rerun,
- pane attach/resume,
- remote continuity,
- finish notices,
- and rich external-app bridges.

## 7) This is how Schell avoids an old terminal lie

A lot of terminal UX quietly relies on one old lie:
if the request left the local prompt, the UI starts speaking as though the world on the other side definitely finished.

SlopOS is valuable because it keeps refusing that lie in many families at once.
That makes it easier for Schell to build something richer than bash without inheriting bash-era ambiguity plus modern glossy overclaiming.

## 8) The no-regret Schell move now

The next safe ratchet is:
- default to admission-scoped wording,
- add visible staged/suspended/historical posture for restored actions,
- allow stronger `observed` or `completed` badges only when exact witnesses exist,
- and keep “user definitely saw/consumed this” as an unusually strong claim that often should remain unknown.

## 9) Decisions intentionally kept open

This pass still does **not** freeze:
- one viewer callback mechanism,
- one external-app observation protocol,
- one restored-state engine,
- one remote-session witness transport,
- or one final badge taxonomy.

The no-regret move is smaller:
**import SlopOS's admission-vs-completion discipline into terminal wording, restored-state posture, and launch/result badges before the shell+terminal teaches itself bad habits.**
