# Research synthesis, pass XXXIV (2026-03-21)

This pass focuses on one very specific seam:
**modern terminals are getting smarter about visible links, but Schell should steal the parts that improve local UX without letting the terminal quietly become a browser, crawler, or raw-URI side channel.**

## 1) xterm.js makes an important explicit-versus-implicit split

The current xterm.js link-handling guide says clickable terminal links can appear in two ways: explicit OSC 8 hyperlinks emitted intentionally, or implicit URLs recognized using pattern matching via the web-links addon.
That distinction is excellent.
Schell should probably make it more visible, not less.

The same guide also recommends requiring a modifier key to activate links so terminals avoid unintentional window opening.
That is a strong reminder that “visible link” and “safe to open right now” are not identical concepts.

## 2) xterm.js also treats hyperlink activation as a security boundary

xterm.js' terminal options API says OSC 8 hyperlinks will fall back to a strongly worded warning if no link handler is set.
Its docs also explicitly say handlers should consider security, recommending at least a tooltip or prompt and warning that links like `javascript:` can be dangerous unless schemes are validated.

That is exactly the kind of lesson Schell should import.
A great shell+terminal should not act as though every visible URI deserves the same one-click authority.

## 3) kitty shows how much power link clicks can accumulate

kitty's config docs say OSC 8 hyperlinks can be ignored, turned into clickable links, or set to `ask`, which prompts before opening.
kitty's open-actions system also shows how easily “click on visible thing” can widen into rich local behavior such as overlays, viewers, and command launches.

That combination is very relevant to Schell.
It suggests two separate design moves:
- ask-before-open is a valuable low-level safety idea,
- and rich click actions should stay explicitly policy-shaped instead of masquerading as generic link truth.

## 4) VS Code proves shell-known context makes links much better

VS Code's shell-integration docs say working-directory detection and command detection let the terminal understand more about what is happening inside the shell.
Those same docs explain that current-working-directory detection improves link resolution: with shell integration, a visible target like `package.json` can open the file in the current folder directly instead of falling back to a broader search flow.

That is an excellent pattern for Schell:
contextual resolution can be brilliant when it stays local and shell-known.
It does not need to become portable truth.

## 5) iTerm2 shows the value and danger of contextual open

iTerm2's semantic-history docs say the terminal tracks the current working directory for each line to help find files, and can then open a file with the default app, open a URL, or run a command using the clicked text and line context.

This is one of the best examples of a move worth stealing carefully.
The good part is line-aware contextual resolution.
The dangerous part is how easily clicked text can escalate into app launch or arbitrary command execution.
Schell should preserve the first and name the second more explicitly.

## 6) Browser docs are a warning label for smart terminal hover behavior

Chrome's speculation-rules documentation says the Speculation Rules API can prefetch or prerender future page navigations, and the docs explicitly tell implementers to consider the costs of speculation.
Chrome's release notes also note that eager speculation can be triggered from link hover behavior.

That matters even though Schell is not a browser.
If a terminal starts warming handlers, preconnecting, prefetching, or prerendering visible links to feel “instant,” it has already crossed into real second-workflow behavior with real network, cache, privacy, and state implications.

## 7) A decision-light import is visible now

A compact Schell import could be:
- one **hyperlink witness** object,
- one visible **source-family ladder** such as explicit / inferred / shell-attested / restored,
- one **ask-first or inspect-first** default for weaker link sources,
- one rule that **hover is descriptive and no-fetch by default**,
- one explicit **fetch preview metadata** or **extract content** lane,
- and one **bounded subject-echo posture** for transcript/history durability.

That is enough to learn a lot without committing to:
- a browser embedding strategy,
- a crawler/unfurl backend,
- a recents schema,
- a browser-profile/session API,
- or a final hyperlink protocol stack.

## 8) The lesson we must learn from the past

The old failure mode is not only that terminals were text-dumb.
The newer failure mode is that terminals become so link-smart that they quietly start doing browser work while still presenting themselves as neutral text surfaces.

The better answer is:
- visible links get source labels,
- open stays distinct from unfurl,
- unfurl stays distinct from extraction,
- hover stays descriptive,
- contextual resolution stays shell-known and local,
- and durable history prefers bounded or redacted evidence over casual raw-URI folklore.
