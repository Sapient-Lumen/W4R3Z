# Research synthesis, pass CI (2026-03-22)

This pass asks one narrower question:
**what should Schell learn from modern pointer/mouse behavior without letting clicks, drags, wheels, and smart routes turn the terminal into a hidden second shell?**

The answer is now crisp enough to keep.
**The right move is not “make clicking magical.” The right move is to treat pointer input as an explicit witness family with event ownership, region strength, route strength, wheel posture, and bypass posture.**

## 1) The ecosystem keeps proving that pointer comfort is a huge UX multiplier

Ghostty, kitty, WezTerm, foot, and iTerm2 all prove the same thing: people love terminals that are not pointer-hostile.
They want:
- live prompt click-to-move,
- command-output selection and paging,
- quick ways to grab URLs/paths/hashes,
- useful wheel behavior in scrollback and alt screen,
- and smart clicks that feel like the terminal understands context.

That is absolutely worth stealing.
But it is also exactly the seam where selection, app input, prompt editing, smart routing, and execution-adjacent actions start blurring together unless the shell+terminal names them separately.

## 2) Ghostty and kitty show the clean prompt-click version of the idea

Ghostty now supports click-to-move in shell prompts, but it explicitly ties that behavior to semantic prompt support and `OSC 133`.
kitty’s mouse click handling likewise distinguishes multiple click outcomes and can move the cursor only when the click happens at the current shell prompt.

That is the right design pressure for Schell.
A click inside a live, shell-authenticated prompt is not the same kind of thing as a click in historical output or a click in app-owned TUI space.
So prompt-click comfort is worth stealing, but only inside an explicit live-edit region with edit-only semantics by default.

## 3) WezTerm reminds us that mouse ownership is real

WezTerm’s docs say the quiet part out loud: by default applications do not respond to the mouse, but applications can emit escape sequences to request mouse tracking; once that happens, terminal mouse assignments stop matching and events are passed to the application unless the operator uses a bypass modifier.

That is a deeply useful lesson.
A click is not one universal event.
It is an event with an **owner**.
The owner may be:
- terminal-local selection,
- the shell prompt,
- a foreground application,
- a terminal-local overlay,
- or a typed route card.

That ownership should be explicit in Schell instead of being hidden inside terminal folklore.

## 4) foot proves wheel behavior is policy, not nature

foot’s alternate-scroll-mode is one of those small docs that teaches a big lesson.
When enabled, mouse wheel events in the alternate screen are translated into up/down key events so pagers can scroll without their own mouse support.

That means the wheel is not “just scroll.”
Depending on posture, it might mean:
- viewport scroll,
- app input,
- translated key events,
- overlay navigation,
- or selection extension.

Schell should preserve that distinction.
It should be able to confess what the wheel means in the current posture rather than leaving the operator to guess why two-finger scroll behaved differently this time.

## 5) iTerm2 proves smart clicks are both delightful and risky

Semantic history is an excellent piece of evidence because it is clearly useful and clearly dangerous in the same breath.
It can use tracked working directory context to open files, open URLs, or run a command.
And iTerm2’s changelog documents that semantic-history filesystem search used to happen on the main thread and had to be moved to a separate process to avoid hangs on slow filesystems.

That is exactly the design-phase lesson Schell should steal from.
Smart clicks should feel helpful, but they should not quietly become:
- ambient cwd assumptions,
- ambient open authority,
- ambient command execution policy,
- or hidden heavy lookup on the pointer path.

## 6) The safe steal is smaller than one final smart-click engine

The no-regret import is not one universal click-to-do-whatever system.
It is one explicit **pointer witness** family that can say:
- what gesture occurred,
- who owned it,
- how strong the region identity is,
- whether the result is selection / prompt edit / app input / route proposal / copy / reveal,
- whether a bypass modifier overrode application capture,
- whether the interaction crossed mux/remote hops,
- and whether any stronger follow-up still needs explicit review.

That is enough to keep the shell+terminal delightful without deciding too early on one final protocol mix, route engine, or UI stack.

## 7) A pointer gesture should be allowed to feel immediate before it is allowed to feel authoritative

The right construction order is:
1. cheap local selection and prompt editing first,
2. typed route proposals second,
3. heavier resolution behind explicit reveal/resolve steps,
4. strong open/run/attach actions only after separately named review.

This is the key historical lesson of the seam.
A helpful click is great.
A click that quietly smuggles in cwd inference, helper lookup, browser launch, or command execution is just terminal folklore wearing nicer clothes.

## 8) Compact conclusion

The strongest companion-compatible move in this pass is:
**let Schell steal pointer delight, but keep selection, prompt editing, app capture, wheel translation, typed route proposals, and stronger reviewed actions separately named.**

That lets Schell become much more humane than legacy terminals without deciding too early:
- one final mouse protocol stack,
- one final smart-click route engine,
- one final quick-select overlay,
- or one final remote/mux pointer treaty.
