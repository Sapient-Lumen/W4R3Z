# SlopOS datacube evaluation — pass CLVII

This pass asks a companion-safe question narrower than “how should Schell do login?”
The better question is:
**how should Schell help the operator complete browser/device/loopback auth handoffs without letting provider-local auth mechanics or browser residue impersonate portable shell truth?**

## 1) SlopOS already keeps auth machinery provider-local and narrower than platform truth

Even while still in design phase, SlopOS has become very explicit about nearby auth boundaries:
- PKCE handling is not portable verifier/proof truth,
- redirect return channels are not portable callback/browser/listen truth,
- auth discovery metadata is not portable issuer/tenant/policy truth,
- and pending-auth continuation is not a generic export seam.

That is exactly the pressure Schell should import.
The terminal should make one exact handoff easier to understand.
It should not quietly become the system’s generic browser-session, callback, or proof substrate.

## 2) SlopOS exactness pushes Schell toward import barriers, not triumphant login blur

A browser step can succeed remotely while the local shell still has not imported or accepted anything usable.
SlopOS keeps that kind of boundary sharp.
So Schell should prefer:
- `browser opened`,
- `waiting for callback`,
- `callback received`,
- `import accepted here`,
- `credential sink chosen`,
- and `current account can act here`

as separately named states.
That keeps the shell from overclaiming success too early.

## 3) ViewFS pressure says designators, offers, and adopted local objects should stay distinct here too

ViewFS repeatedly refuses to collapse designator, offer, adoption, and local object truth.
That transfers cleanly to auth.
A verification URL, user code, redirect URI, callback payload, imported token reference, and active account binding are not the same class of thing.

So Schell should not let a browser-facing auth URL or callback code quietly become local shell authority just because they are adjacent in one flow.

## 4) Steward pressure says compact advice is great, but exact retry rails matter more than generic “login failed” prose

Steward keeps pushing tiny typed status plus exact retry posture.
Auth flows need the same treatment.
Operators need clear answers to:
- is the browser step still pending,
- did the callback arrive,
- did local import fail,
- is the code expired,
- which part is safe to retry,
- and what exact host/account/scope was this flow for?

That is a much better fit for typed auth-handoff witnesses than for one banner that says “sign in again.”

## 5) Helm pressure says return anchors, drift honesty, and reset cards matter here too

Helm keeps teaching that return flows and continuity surfaces need exact anchors and reset posture.
That applies directly to auth handoffs.
A browser tab left open from an earlier attempt, an expired device code, or a callback received for the wrong pending flow should all downgrade visibly instead of pretending they still complete the current shell intent.

So Schell should pair auth handoffs with exact return tickets and reset cards.

## 6) What Schell should steal now

Schell should steal several excellent moves under stronger honesty:
- browser-open return tickets,
- device-code cards with expiry and retry rails,
- callback listener chips for loopback flows,
- exact-host and exact-subject display,
- storage/import posture cards,
- and historical fade for expired or superseded auth attempts.

These are all high-value operator luxuries that do not force Schell to settle the final auth broker, account model, or secret-storage architecture.

## 7) What Schell should refuse now

Schell should refuse:
- embedded-browser overreach,
- callback-received counting as durable login success,
- copied code or opened URL counting as auth completion,
- environment-provided credentials counting as interactive browser-auth success,
- and imported provider-local PKCE/redirect mechanics counting as generic proof or account truth.

## 8) Compact conclusion

The companion-safe answer is not to avoid browser-auth comfort.
It is to keep **browser/device/loopback auth as exact handoff witnesses with explicit return, callback, import, sink, and expiry posture**.
That lets Schell become dramatically better at CLI auth while staying aligned with SlopOS exactness during the design phase.
