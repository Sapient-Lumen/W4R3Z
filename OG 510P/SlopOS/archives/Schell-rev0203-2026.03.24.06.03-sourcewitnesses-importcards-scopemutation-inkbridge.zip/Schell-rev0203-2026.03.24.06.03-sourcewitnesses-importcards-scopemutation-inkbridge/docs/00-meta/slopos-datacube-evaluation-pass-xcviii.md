# SlopOS datacube evaluation, pass XCVIII (2026-03-22)

This pass evaluates one narrower question against the current SlopOS archive:
**what does the companion already teach Schell about keymaps, editor widgets, help bindings, and prompt-click luxuries?**

The answer is tighter than it first appears.
**SlopOS strongly pressures Schell to treat editor power as explicit local editing posture, not as ambient execution or hidden policy import.**

## 1) The companion already prefers explicit stage boundaries over clever invisible glue

Across the archive, SlopOS repeatedly prefers stage-local contracts, explicit selectors, exact launch artifacts, and local acceptance over inferred meaning.
That matters directly for keybinding design.
A key chord may be useful, but the companion does not want nearby truths flattened into one flattering story:
- a key event arriving,
- a keymap/mode resolving,
- a widget or helper firing,
- the input buffer changing,
- and a reviewed execution artifact being approved.

For Schell this means editor actions should become one separately named witness family rather than vanishing into “the shell handled my shortcut somehow.”

## 2) Learn-mode posture says editor help may advise, but should not auto-widen

The companion's capshell learn-mode posture already says observational suggestions must stay stage-local and must not auto-edit, auto-approve, or auto-rerun.
That imports cleanly into editor luxuries.
A help key, repair widget, mode-aware menu, or prompt-local action may still be excellent.
But SlopOS pressures Schell not to let those editing surfaces silently spend the action, mutate the reviewed object behind the user's back, or widen from “editing help” into “execution authority.”

That especially sharpens submit-style bindings.
If a binding can accept the line, that should be a stronger, explicitly visible class than ordinary editing.

## 3) Command-string and word-expansion refusal say editor comfort must terminate before exact review

SlopOS already refuses free command-string convenience and ambient word-expansion folklore at the execution boundary.
That matters here because line editors are one of the easiest places to smuggle folklore back in.
If a widget expands text, pastes an example, inserts a parameter, or reacts to a prompt click, the companion still wants the same sequence of truth:
- visible buffer change first,
- exact review object later,
- explicit execution only after that.

For Schell this means key bindings should stay stronger as editing witnesses than as runtime rules.
They may alter the buffer.
They should not quietly become parser semantics.

## 4) Startup/profile explicitness says repo-local key magic should remain leased, not ambient

The companion's explicit startup and hidden-hook refusal gives Schell a direct warning here.
Keymaps, widgets, run-help adapters, prompt-click helpers, and project-local editor packs are all tempting places to reintroduce rc-file folklore.
SlopOS pressure says not to let that happen silently.
If a repo or imported pack wants to add bindings or editor widgets, that should stay visible, leased, and reauthorizable on change rather than becoming another layer of invisible shell startup behavior.

## 5) Trusted UI pressure says mode badges and prompt-click affordances should be shell-owned when they matter

The companion keeps treating trusted input and shell-owned mediation as real seams.
That maps cleanly onto editor-mode truth.
A terminal can render a cursor style, a badge, a prompt click affordance, or a menu highlight.
But SlopOS pressure says the strongest truth should still come from the shell-owned/editor-owned side of the seam.
If the terminal is guessing, bridging, or synthesizing fallback events, Schell should label that weaker posture instead of letting it impersonate shell-authenticated live prompt ground.

## 6) The clean import is smaller than a final editor architecture

The most companion-compatible move is not to pick a final editor stack now.
It is to define one explicit **keymap/editor witness** family that proves:
- current mode,
- binding source,
- whether the triggered action is edit-only / help / menu-accept / line-submit,
- whether the action came from native shell bindings, imported/project-local bindings, or a terminal bridge,
- and what discoverability answer exists for “what does this key do here?”

That keeps editor luxury compatible with the companion's exactness discipline while leaving implementation details open.

## 7) Compact conclusion

The strongest companion-compatible move in this pass is:
**let Schell steal editor delight, but keep key events, mode resolution, widgets, buffer edits, and reviewed execution separately named.**

That lets Schell become much more humane at the prompt without deciding too early:
- one final editor engine,
- one final keybinding syntax,
- one final widget ABI,
- or one final terminal-click integration contract.
