# SlopOS datacube evaluation, pass CXXIX (2026-03-22)

This pass evaluates one narrower question against the current companion archives:
**what do SlopOS, Steward, and ViewFS teach Schell about workflow seeds, reviewed automation, and shell+terminal luxury?**

The answer is crisp:
**reusable automation should stay explicit, footing-rich, and review-landed rather than becoming hidden command folklore, hidden policy memory, or click-to-run convenience.**

## 1) SlopOS D-CAPSHELL already says automation is a real authority boundary

SlopOS RFC-0115 is extremely clarifying here.
Its capability-safe shell posture says scripts are components with declared authority contracts, capability wallets are reviewable summaries rather than bearer objects, learn mode stays observational only, interpreter selection stays explicit, and exact execution must not silently fall back through shebang/env/path/argv0 folklore.
That is the right import for Schell.
A saved command or workflow seed is not just reusable text.
It is a future reviewed action candidate that should keep exact execution footing visible.

## 2) SlopOS D-PLUMB keeps intent routing explicit and non-authoritative

RFC-0117 keeps plumb messages canonical but non-authoritative and request-local.
That is equally useful for Schell.
Visible output hits, selected object cards, workflow searches, and chapter promotions can all become smarter without turning every discovered thing into a hidden authority channel.
A selected workflow or captured-output row should produce a named route or review landing, not a generic execute-now folklore path.

## 3) Steward keeps shell luxury source-labeled and freshness-scoped

Steward's repeated lesson is that chrome, labels, diagnostics, chooser surfaces, and session injection all stay more honest when source, freshness, and action family are explicit.
For Schell that means a reusable automation artifact should say whether it is:
- operator-authored,
- chapter-harvested,
- proposal-lane,
- imported,
- restored,
- or only locally inferred.

## 4) ViewFS keeps adjacent lanes separate

ViewFS keeps requests, selections, grants, tasks, progress, results, and sideband observation from collapsing into one flattering lane.
Schell needs the same discipline here.
At minimum it should keep separately named:
- command chapter,
- workflow seed,
- reviewed automation pack,
- learn report,
- live run,
- denial,
- and receipt.

## 5) Companion-compatible no-regret move

Schell does **not** need a final automation platform next.
It only needs a few bounded rules:

### A) Keep search and selection weaker than execution
Search, palette picks, clicks, and captured-output hits land in insert/review paths first.

### B) Keep reusable automation footing-rich
Interpreter, wallet baseline, peer/ground, source lane, and drift posture stay visible.

### C) Keep learn mode observational only
Missing authority reports teach without widening, auto-editing, or auto-rerunning.

### D) Keep transcripts honest
Workflow luxury still leaves behind plain text and durable receipts that confess what was suggested, reviewed, denied, and run.

## 6) Compact conclusion

The companion-safe answer is not "build a magical workflow engine."
It is:
**build reviewed workflow seeds, automation witness cards, and observational learn reports so Schell can steal modern command-block and workflow luxury without letting saved convenience impersonate fresh authority.**
