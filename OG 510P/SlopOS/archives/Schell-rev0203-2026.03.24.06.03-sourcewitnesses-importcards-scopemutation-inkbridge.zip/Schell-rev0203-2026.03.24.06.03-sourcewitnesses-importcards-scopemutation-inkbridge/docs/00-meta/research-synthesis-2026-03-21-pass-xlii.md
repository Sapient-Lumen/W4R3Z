# Research synthesis, pass XLII (2026-03-21)

This pass focuses on one bounded seam that Schell did not yet give its own terminal surface:
**classic shell job control still hides too many different stories under foreground/background folklore, while modern tools increasingly separate tty-bound work, detachable workspaces, and supervised continuation. Schell should steal the good parts without freezing one supervisor or one mux architecture too early.**

## 1) POSIX and Bash still teach the deepest historical lesson: foreground TTY control is not the same thing as “the command story is over”

The POSIX terminal interface and Bash job-control docs are still the clearest reminders that interactive shells sit on real process-group and controlling-terminal machinery.
The terminal driver sends signals such as `SIGINT` to the **foreground process group**, and background processes that attempt terminal I/O may be stopped with `SIGTTIN` or `SIGTTOU`.
Bash likewise says that job state changes are tracked in a jobs table, that `%1` can move a job back to foreground, and that when the shell notifies you a job terminated it removes the job from its table.

That is a strong design hint for Schell:
- foreground ownership is a **real coordination fact**,
- prompt return often just means the shell got the TTY back,
- and shell job tables are **local tracking**, not a durable system service inventory.

See: https://www.gnu.org/software/bash/manual/html_node/Job-Control-Basics.html
See: https://pubs.opengroup.org/onlinepubs/009695399/basedefs/xbd_chap11.html
See: https://pubs.opengroup.org/onlinepubs/9699919799/xrat/V4_xbd_chap11.html

## 2) fish makes the local-tracking boundary even more obvious

fish’s docs are unusually direct: `disown` removes a job from the job list, the job continues to exist, but fish loses all knowledge of it, exit hooks stop firing, and it cannot later be resumed with `bg` once disowned.
The fish language docs also make the suspend/foreground/background ladder explicit: `ctrl-z` suspends, `fg` brings work back, and `bg` resumes a stopped job in background.

That is a great thing to steal conceptually.
A shell should not pretend “still running somewhere” and “still tracked here” are the same status.

See: https://fishshell.com/docs/current/cmds/disown.html
See: https://fishshell.com/docs/current/language.html
See: https://fishshell.com/docs/current/cmds/wait.html

## 3) `nohup` is much narrower than shell folklore suggests

The GNU Coreutils docs say `nohup` merely makes the command ignore hangups, redirects terminal stdio as needed, and **does not automatically put the command in the background** — the user must still add `&`.
That is a beautiful example of a command whose cultural meaning drifted wider than its actual semantics.

Schell should learn from that directly:
- ignore-hangup,
- background-under-current-shell,
- detach-from-current-review,
- and durable supervised continuation
are different moves.

See: https://www.gnu.org/software/coreutils/manual/html_node/nohup-invocation.html

## 4) `systemd-run` shows the best “promote this work” shape

The `systemd-run(1)` docs are unusually useful for Schell because they split two nearby forms cleanly.
A transient **service** unit runs in a clean detached execution environment with the service manager as parent and starts asynchronously in the background.
A transient **scope** unit instead inherits the caller’s execution environment and returns only when the command finishes.
The docs also warn that default `Type=simple` success is reported early, before `execve()`, and suggest `Type=exec` when you want stronger startup truth.

That is almost a perfect shell+terminal lesson:
- “promote this command” is a real user-facing action,
- not every promotion yields the same environment semantics,
- and admission/startup success is still weaker than richer target truth.

See: https://man7.org/linux/man-pages/man1/systemd-run.1.html

## 5) tmux and Zellij show the detach/resurrect lane clearly

The tmux manual says tmux sessions may be detached, continue running, and later be reattached.
Zellij’s resurrection docs go one step further: sessions are serialized, can be resurrected after exit or crash, and resurrected commands are placed behind a **“Press ENTER to run...”** banner so they are not silently re-executed.

That is exactly the kind of design humility Schell should steal.
Detached continuity is valuable.
Historical resurrection is valuable.
Neither should quietly claim fresh live foreground truth.

See: https://man7.org/linux/man-pages/man1/tmux.1.html
See: https://zellij.dev/documentation/session-resurrection.html

## 6) The best steal is a continuation ladder, not one more magic command

A custom shell+terminal could become much better than today’s shells with one explicit ladder:
- **foreground-tty claim**,
- **stopped**,
- **background but shell-tracked**,
- **background but shell-untracked / disowned**,
- **detached mux/workspace continuity**,
- **promoted supervised work**,
- **restored historical continuity**.

And each rung can carry different truth about:
- tty ownership,
- interactive signal handling,
- shell tracking,
- durable supervision,
- and restoration freshness.

That is enough to make the terminal feel brilliant without standardizing one init system, one mux daemon, or one universal jobs API.

## 7) The lesson from the past that matters most here

The old mistake was pretending that job control and process continuation were “just shell UX.”
The newer mistake would be letting rich detach, restore, and promote features silently inherit that same ambiguity.

The better answer is:
- keep tty claim explicit,
- keep shell job tracking weaker than durable supervision,
- keep disown weaker than managed continuation,
- keep restored continuity weaker than fresh live witness,
- and give long-running work a visible **promotion** rail instead of asking `&` to mean too much.
