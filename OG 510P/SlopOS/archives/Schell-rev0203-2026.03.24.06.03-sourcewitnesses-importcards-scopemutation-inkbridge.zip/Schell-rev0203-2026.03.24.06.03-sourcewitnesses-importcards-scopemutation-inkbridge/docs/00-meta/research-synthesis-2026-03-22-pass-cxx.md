# Research synthesis, pass CXX (2026-03-22)

This pass keeps one narrower lesson explicit:
**Schell should collect semantic specimens and maintain a loss harness early, so profile families, mux relays, and replay paths are compared against shell-owned truth instead of narrated into compatibility by hope.**

The external ecosystem is giving a useful combined signal.
VS Code documents richer and weaker shell-integration quality paths, with `OSC 633` carrying more than compatibility families such as `OSC 133`/`OSC 1337`.
Ghostty now supports richer `OSC 133` prompt semantics and ships a debug overlay in the terminal inspector.
WezTerm builds command navigation and selection around semantic zones from shell integration.
kitty also turns shell-aware prompt/output zones into concrete navigation and selection features.
tmux keeps reminding us that relays matter because passthrough and prompt marking change what survives.
Meanwhile, `vttest` and `tack` still exist for a reason: terminal claims are not the same thing as terminal behavior.
The xterm control-sequences material even documents cases where real testing corrected published documentation.

Taken together, that suggests a design-phase rule for Schell:

## 1) Keep a shell-owned semantic event tape

Schell should have a compact internal fixture form for what the shell actually knew:
- prompt boundaries,
- command start/finish,
- exact command line availability,
- cwd,
- exit status,
- peer/lane posture,
- freshness class,
- and live/relayed/restored/historical status.

## 2) Project that same specimen into named profile families

The same shell-known specimen should be projectable as:
- plain text only,
- portable `OSC 133`/`OSC 7` core,
- richer VS Code-style projection,
- terminal-specific augmented projections,
- relay/mux-friendly reduced forms,
- and historical/replay-safe projections.

That preserves openness while still making the projection story concrete.

## 3) Normalize observed captures back into comparable evidence

A very important missing piece in many shell/terminal designs is capture normalization.
Schell should compare:
- shell-known semantic truth,
- intended projection,
- observed capture after a terminal/mux/hop path,
- and the final operator-visible badges/overlays/actions.

That comparison is the actual compatibility story.

## 4) Keep a loss atlas, not just a feature matrix

A giant compatibility matrix will rot.
A smaller named atlas of losses is more useful:
- exact command line not projected,
- cwd lost on hop,
- prompt zones degraded,
- replay retains command frames but not liveness,
- helper-injected path works but stays basis-badged,
- malformed marks become unverified.

That is a much healthier design-phase artifact.

## 5) Steal the best ecosystem ideas as proof tools, not only user features

The exciting part of this pass is that some of the best ideas to steal are about proving behavior:
- Ghostty-style semantic inspectors,
- VS Code-style quality posture,
- WezTerm/kitty-style semantic zone navigation,
- `vttest`/`tack` style compatibility probing,
- SlopOS-style toolable golden fixtures,
- and Steward-style freshness-badged chrome.

## 6) Compact answer

Schell does **not** need to choose one universal shell-integration treaty or one final compatibility spreadsheet yet.
It only needs a bounded move:
- one shell-owned semantic specimen format,
- one small orchard of high-value cross-profile fixtures,
- one capture normalizer,
- one named loss atlas,
- and one operator/developer inspector that can show what really survived.

That is enough to keep the architecture open while making the custom shell+terminal much more trustworthy and much more exciting.
