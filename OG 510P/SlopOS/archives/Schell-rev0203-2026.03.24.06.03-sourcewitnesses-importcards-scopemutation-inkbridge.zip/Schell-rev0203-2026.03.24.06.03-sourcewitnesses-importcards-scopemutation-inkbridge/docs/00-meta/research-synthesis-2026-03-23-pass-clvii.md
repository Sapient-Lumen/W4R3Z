# Research synthesis — 2026-03-23 — pass CLVII

This pass tightens another shell+terminal seam into a smaller rule:
**browser-auth comfort is worth stealing, but auth handoff events should stay separately named all the way through return and local import.**

The strongest current lesson is not merely “CLIs can open browsers now.”
It is that modern CLI auth works best when the terminal is honest about which part happened:
- browser opened,
- code shown,
- user finished remote step,
- callback arrived,
- local import completed,
- and local credential storage/account activation changed.

That points to a good next Schell move:
**auth-handoff witnesses, browser return tickets, and callback/import humility** rather than a vague “login UX” layer.

## 1) RFC 8252 is the historical baseline: native apps should use external user-agents, primarily the browser

RFC 8252 remains the best compact lesson for a custom shell+terminal.
Native-app authorization requests should use an external user-agent, primarily the user’s browser.
The document is explicit that embedded user-agents are unsafe because the host app can inspect credentials, cookies, and page content, and that browser-based flows can reuse the user’s authentication state.
It also requires exact redirect-uri matching and recommends state for cross-app request forgery protection.

So Schell should not try to win by being an embedded browser.
It should win by making the handoff and return path exact.

## 2) RFC 8628 proves that browser auth is not always browser-return auth

RFC 8628 exists because some devices or clients lack a suitable browser or are input constrained.
Its lesson is not just “device flow exists.”
It is that the auth experience may legitimately split across devices and time.
The terminal may show a user code, point to a verification URI, and then poll.
That means `browser step happened elsewhere` and `local completion happened here` are different truths.

Schell should model those truths directly instead of squeezing everything into one “login in progress” badge.

## 3) GitHub CLI shows the modern expectation: browser-first, but local sink still matters

The current `gh auth login` docs say the default mode is a web-based browser flow.
They also say the resulting token is stored securely in the system credential store when possible, with plaintext-file fallback if a credential store is unavailable.
That is an important terminal-design lesson.
Even when the remote authorization succeeded, the local result still has a distinct storage posture.

Schell should keep `browser success` separate from `stored in keyring`, `helper fallback`, or `plain-file fallback`.

## 4) gcloud shows the remote-machine lesson: browser handoff can be local, remote, or console-only

gcloud’s docs say `gcloud init` uses a web-based authorization flow, but also support `--console-only` when the command is running over SSH without browser access on that system.
Likewise `gcloud auth login --no-browser` supports a remote-bootstrap path on a machine without a browser.
That means a terminal can be excellent here without claiming that the browser is co-located with the shell.

Schell should steal:
- explicit `open here` versus `continue elsewhere` posture,
- exact copyable URL/code surfaces,
- and return tickets that survive cross-device delay.

## 5) MCP authorization sharpens the auth boundary even more

The current MCP authorization spec is unusually useful for Schell because it is explicit about where auth belongs.
It says HTTP transports use the authorization specification, but STDIO transports should not and instead retrieve credentials from the environment.
It requires discovery through OAuth Protected Resource Metadata, mandates `S256` PKCE when technically capable, and says clients must refuse to proceed if `code_challenge_methods_supported` is absent from the relevant metadata.
It also requires registered redirect URIs, exact redirect validation, and state verification.

That is strong evidence for Schell to keep provider-local discovery, PKCE, redirect, and token handling distinct from the shell’s smaller truth about pending handoff, callback arrival, and local import posture.

## 6) OpenAI’s Apps SDK reinforces the host-mediated external-open lesson

The current Apps SDK exposes `window.openai.openExternal({ href, redirectUrl })` as a host request to open a vetted external link in the user’s browser.
That is a very useful design clue.
The browser handoff is a host-mediated bridge, not proof that the downstream auth step succeeded or that some callback/import has already completed.

Schell should use the same mental model.
Opening the browser is a distinct act that deserves its own witness and return ticket.

## 7) The concrete Schell move

Schell should add a compact **auth-handoff witness** contract:
- **flow family** — browser-open / console-bootstrap / device-code / loopback-return / manual-import / env-provided,
- **subject** — exact server / scope / account target / resource target,
- **browser posture** — opened here / copied elsewhere / declined / unknown,
- **return channel** — loopback / pasted-code / device poll / host callback / none,
- **pending state** — waiting-open / waiting-code-entry / waiting-callback / callback-seen-pending-import / imported / expired / failed,
- **import posture** — none / token-ref-imported / account-binding-updated / provider-local only,
- **credential sink** — keyring / helper / plain-file fallback / memory-only / unknown,
- **reveal target** — exact card or chapter that explains the real current state.

That is enough to steal browser-auth luxury without freezing a giant auth broker.
