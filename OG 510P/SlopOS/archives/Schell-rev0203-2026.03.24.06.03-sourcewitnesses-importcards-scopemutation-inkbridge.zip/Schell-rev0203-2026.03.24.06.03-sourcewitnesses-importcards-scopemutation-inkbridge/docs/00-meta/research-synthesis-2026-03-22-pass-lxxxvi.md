# Research synthesis, pass LXXXVI (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should steal the best current clipboard and paste ideas — prompt-aware paste warnings, bracketed-paste downgrade logic, explicit clipboard-read permissioning, primary-versus-clipboard distinction, cross-domain copy/paste rituals, and typed paste-event handoff — but it should keep selection, copy offers, clipboard reads, paste grants, persisted paste residue, and cross-boundary transfer separately named so “copied” or “pasted” never impersonates one generic ambient authority channel.**

This seam matters because copy/paste is where terminals still look most harmless.
It is also where current systems quietly smuggle real power:
clipboard readback, cross-domain transfer, remote-to-local bridges, prompt-aware quoting, multiline confirmation, selection ownership, and durable paste history.
The current ecosystem now gives Schell both the delight patterns and the cautionary evidence.

## 1) Clipboard is not one thing anymore

Modern terminal-adjacent systems now plainly expose multiple nearby clipboard truths.
Wayland’s `wl_data_device` is explicit that copy-and-paste and drag-and-drop are inter-client transfer mechanisms and that selection is a separate advertised object with MIME offers and focus-bound validity.
WezTerm’s docs say OSC 52 can set or clear the clipboard while clipboard **queries are ignored**.
Ghostty’s config reference separates `clipboard-read`, `clipboard-write`, `copy-on-select`, selection clearing, and the distinction between selection clipboard and system clipboard.
This is no longer folklore: the ecosystem is already telling Schell that **selection ownership, clipboard mutation, paste events, and clipboard readback are distinct powers**.

The stealable lesson is simple:
Schell should stop talking as though there is one clipboard.
The more important historical lesson is stricter:
selection highlight, local copy pack, system clipboard write, primary-selection write, remote bridge, and application clipboard read must not collapse into one flattering “clipboard worked” story.

## 2) Paste safety is now best when the shell/terminal can admit uncertainty

The old xterm bracketed-paste seam is still one of the best imports in the whole ecosystem.
The point was to let pasted text be distinguished from ordinary typing so editors and shells could temporarily change behavior instead of treating pasted bytes as keypresses.
VS Code’s terminal docs now make the modern version explicit: by default there is a warning when pasting multiple lines, but that warning is skipped when the shell supports bracketed paste mode because the shell has said it can handle multiline paste.
Ghostty adds `clipboard-paste-protection` and a separate `clipboard-paste-bracketed-safe` switch.
iTerm2 adds “Warn Before Multi-Line Paste”, “Limit Multi-Line Paste To Shell Prompt”, and even a warning for one line ending in a newline at the shell prompt.

The import for Schell is not merely “show warnings.”
The import is that paste should be judged against a **target posture**:
- prompt or not,
- bracketed-safe or not,
- newline-bearing or not,
- control-code-bearing or not,
- and maybe elevated/remote/secret-bearing or not.

That is exactly the kind of local luxury that feels super awesome while staying reversible.

## 3) Rich paste transforms are worth stealing, but only as explicit proposals

kitty’s `paste_actions` docs are a good north star here.
They include prompt-aware URL quoting, replacement of dangerous control codes, newline replacement, confirmation on dangerous control codes, confirmation on very large pastes, and even a configurable paste filter hook.
iTerm2’s “Advanced Paste” and special paste menu keep making the same case from another angle: edit, transform, slow-paste, base64-encode, and tab-convert before the text reaches the target.

The right import for Schell is not “be smart and rewrite what the user pasted.”
It is: **offer transforms as explicit paste-grant variants**.
That means the shell can be luxurious without quietly becoming a second hidden input-authority plane.
Good early examples:
- paste literal,
- paste quoted for current shell footing,
- paste as here-doc seed,
- paste after stripping dangerous controls,
- paste slowly / chunked,
- or stage into scratch/edit first.

## 4) Clipboard readback is more dangerous than clipboard writing, and current tools are starting to admit that

The current ecosystem is unusually crisp here.
WezTerm ignores OSC 52 clipboard query requests while allowing set/clear writes.
Ghostty’s defaults allow clipboard reading only after prompting the user and allow writing unconditionally.
kitty’s newer clipboard protocol goes further: it supports user permission prompts for read/write, explicit error reporting, one-time passwords for paste events, and typed MIME lists before the application actually requests data.

the lesson Schell should import is not “support every clipboard protocol.”
The lesson is that **clipboard reads, clipboard writes, and user-triggered paste events should be different lanes**.
A program asking “what is on the clipboard?” is stronger than a user explicitly saying “paste this here now.”
A remote pane trying to cause a local readback is stronger again.

## 5) Persistence is residue, not innocent convenience

iTerm2’s current docs say it can save copy/paste and command history to disk, preserving the last 20 copied or pasted values and, with shell integration enabled, also preserving command history, directory history, and remote host/user data.
That is a fantastic convenience feature and also a near-perfect warning.
The moment copy/paste history persists, Schell is no longer only handling transfer; it is handling **residue policy**.

That means Schell should keep at least three different things separate:
- live copy/paste events,
- local transient copy rings or offers,
- and durable paste/copy residue.

It should also keep secret-bearing and elevated paste/copy out of ordinary durable history by default.

## 6) Cross-boundary clipboards work best when copy and paste are visibly separate grants

Qubes OS is the clearest modern proof here.
Its docs separate ordinary copy inside a source qube from copying into the inter-qube clipboard, then from granting the paste into one chosen target qube, and then they clear the inter-qube clipboard.
The result is less magical than a shared clipboard, but much more honest.

This is an unusually good import for Schell.
Remote/local bridges, nested tmux sessions, SSH clipboard bridges, microVM helper transfer, and security-domain jumps should all learn the same lesson:
**copy != grant; paste == grant into one named target under current posture.**

## 7) What Schell should now do

This pass points to a compact answer:
- **selection-ownership badges** that say what has been selected and where that selection currently lives,
- **copy offers** that exist before any external clipboard mutation,
- **clipboard-read gates** with ask/allow/deny/one-shot posture,
- **paste grants** that bind one payload form to one target posture,
- **bridge strips** that confess local, remote, nested, inter-domain, or unknown boundary crossings,
- **paste-residue badges** for local ring vs durable history vs cleared,
- and **privileged paste lanes** when the target is elevated, secret-bearing, or cross-domain.

## 8) Decisions intentionally kept open

This pass does **not** freeze:
- one final clipboard backend,
- one final copy-ring/history implementation,
- one final OSC 52 / OSC 5522 policy,
- one final cross-domain transfer broker,
- one final secret auto-clear posture,
- or one final typed payload ontology.

The no-regret move is smaller and stronger:
**give Schell clipboard-read gates, selection-ownership badges, copy offers, bridge strips, and explicit paste grants so copy/paste becomes much better without turning transfer convenience into ambient authority.**
