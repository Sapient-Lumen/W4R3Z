# Research synthesis, pass XLI (2026-03-21)

This pass focuses on one bounded seam that Schell did not yet give its own terminal surface:
**modern shells and developer tools keep proving that secret handling inside the terminal is not one thing, so Schell should steal the best ideas around references, proxy use, masking, and bounded export without letting plaintext secrets quietly become scrollback, history, clipboard, or transcript folklore.**

## 1) 1Password shows the right first split: secret reference is better than plaintext, but environment injection is still a weaker lane

1Password CLI’s secret-reference model and `op run` flow are a strong signal for Schell.
The tool lets you keep secret references in files or environment configuration, then resolves them only when launching a subprocess.
It also conceals secrets printed to stdout/stderr by default.
But the docs also warn that processes running as the same user may be able to access each other’s environment.

That combination is excellent design pressure.
It says:
- **reference beats plaintext**,
- **runtime materialization beats hardcoding**,
- but **environment variables are still not a magic safe zone**.

See: https://developer.1password.com/docs/cli/reference/commands/run/
See: https://developer.1password.com/docs/cli/secrets-environment-variables/

## 2) systemd credentials show a better materialization shape than ordinary env vars

systemd’s credentials model treats credentials as data objects passed to services at activation time.
The docs say credentials are accessible as regular files via `$CREDENTIALS_DIRECTORY`, are acquired when the service is invoked, and are released when the service deactivates.
That is a beautiful idea to steal.
It is still materialization.
But it is narrower, more structured, and more lifecycle-bound than ambient shell environment inheritance.

For Schell, this is a strong clue that the shell+terminal should distinguish:
- secret reference,
- ephemeral process-scoped materialization,
- file/FD-backed materialization,
- and durable literal reveal.

Those are not one thing.

See: https://systemd.io/CREDENTIALS/
See: https://man7.org/linux/man-pages/man7/systemd.system-credentials.7.html

## 3) GitHub Actions shows the old lesson clearly: masking helps, but it only helps if it happens before output

GitHub’s docs explicitly warn that sensitive information that is not already a GitHub secret should be masked with `::add-mask::VALUE`, and that the mask must be registered **before** the value is output or used in other workflow commands.
That is a very important lesson for Schell.
Masking is useful.
But masking is not retroactive truth repair.
Once a secret has already flowed into output, transcript, or history, the damage may already be done.

That strongly suggests Schell should treat `mask`, `scrub`, `export sanitized`, and `reveal literal` as separate action rails rather than one reassuring “safe now” story.

See: https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-commands
See: https://docs.github.com/actions/security-guides/using-secrets-in-github-actions

## 4) systemd journald is a reminder that log surfaces and process identity can lie in subtle ways

The `systemd.journal-fields(7)` page notes that entries obtained via stdout/stderr of forked processes contain credentials valid for the **parent** process that initiated the connection to `systemd-journald`.
That is exactly the kind of historical lesson a new shell+terminal must take seriously.
Even when output looks like it came from one process, adjacent metadata and export plumbing may reflect a different authority context.

Schell should import the lesson directly:
**logs and transcripts should not be treated as innocent sinks for secrets or credential-adjacent context.**
Output channels, parentage, and export metadata can carry more authority than the visible line suggests.

See: https://man7.org/linux/man-pages/man7/systemd.journal-fields.7.html

## 5) OpenSSH agent forwarding and destination constraints show the best “use without reveal” move

OpenSSH’s agent model is one of the best historical steals here.
The agent can hold keys and allow authentication use without exporting private key material itself.
OpenSSH also added destination constraints for keys in `ssh-agent`, and the OpenSSH notes explain that even with constraints, a forwarded agent can still be abused **on the host where it is forwarded**.

That is a nearly perfect design hint for Schell:
- **proxy use without reveal** is a great pattern,
- **peer/destination constraints** are worth stealing,
- but **forwarded capability use still needs peer-visible posture and risk badges**.

In other words, “not exported” is not the same as “safe everywhere.”

See: https://man.openbsd.org/ssh-agent.1
See: https://man.openbsd.org/ssh-add.1
See: https://www.openssh.org/agent-restrict.html

## 6) Secret Service and Keychain are useful, but they also warn against freezing a huge inventory model too early

The Secret Service spec exposes a full service / collection / item / session / prompt object model.
Apple Keychain likewise treats secrets as keychain items and positions keychain services as the right place for small secrets.
These are good references, but they are also a caution for Schell.
A shell+terminal does not need to standardize a giant portable secret inventory model in order to behave intelligently around secrets.

The no-regret import is smaller:
- secret items exist,
- sessions/prompts exist,
- some reveals need mediated prompts,
- and small secrets deserve better storage than dotfile plaintext.

But Schell should resist freezing a collection-browser ontology into its portable core too early.

See: https://specifications.freedesktop.org/secret-service/latest/ch03.html
See: https://specifications.freedesktop.org/secret-service/latest/sessions.html
See: https://developer.apple.com/documentation/security/keychain-services

## 7) The best steal is a reveal ladder plus sink posture

A custom shell+terminal could become much better here with a small, explicit ladder:
- **reference only**,
- **proxy use**,
- **ephemeral materialize for one child**,
- **insert into current input as secret slot**,
- **reveal literal locally**,
- **copy/export/share literal**.

And every move should carry sink posture such as:
- history allowed / blocked,
- transcript allowed / scrubbed / forbidden,
- clipboard allowed / blocked,
- remote-peer-visible / local-only,
- and historical residue present / absent.

That is enough to make the shell feel brilliant without picking one vault, one keychain, one SSH story, or one remote secret-transport protocol.

## 8) The lesson from the past that matters most here

The old mistake was treating the terminal as a neutral place where secrets could appear briefly and then disappear.
The newer mistake would be treating redaction, masking, or vault integration as proof that all nearby sinks are now safe.

The better answer is:
- plaintext is the expensive move,
- use and reveal should stay different,
- environment materialization should stay weaker than handle/reference use,
- transcript/history/clipboard/export deserve explicit sink posture,
- and remote forwarding should advertise proxy risk instead of pretending “secret never left” is the whole story.
