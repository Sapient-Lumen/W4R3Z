# Research synthesis — 2026-03-23 — pass CXXXVII

This pass sharpens one fresh shell+terminal lesson from current upstream docs:
**spawn inheritance is becoming a first-class terminal luxury, but inherited context is usually partial, platform-specific, or terminal-mediated rather than a fresh exact launch basis.**

## 1) Ghostty now separates working-directory inheritance by window, tab, and split

Ghostty 1.3.0 added separate controls for:
- `window-inherit-working-directory`
- `tab-inherit-working-directory`
- `split-inherit-working-directory`

Its config reference also says `working-directory` can fall back to `inherit`, meaning the launching process directory, and that the inherit settings take precedence when a previously focused surface exists.

That is a strong product clue for Schell.
It means operators care not just about *whether* cwd inheritance exists, but *where* it applies.
A split, a tab, and a window are nearby spawn acts with different expectations.

## 2) Windows Terminal makes duplicate path/profile convenient while openly not cloning everything

Windows Terminal now explicitly documents:
- `duplicateTab` copies the current tab's profile and directory,
- `splitPane` with duplicate mode opens a pane with the same path and profile,
- but `duplicateTab` does **not** include modified/added environment variables.

This is an excellent lesson.
Even in a user-friendly product, “duplicate” is not total state cloning.
It is a partial inheritance contract.
Schell should steal that honesty and make it more explicit.

## 3) VS Code keeps inheritance as separate knobs, not one magic same-context promise

VS Code's terminal docs continue to expose separate launch-context controls such as:
- `terminal.integrated.inheritEnv`
- `terminal.integrated.splitCwd`
- `terminal.integrated.automationProfile.{platform}`

That is useful evidence that spawn convenience naturally decomposes into different fields:
- environment inheritance,
- cwd inheritance,
- and profile choice for automation-related shells.

This is healthier than one vague “new terminal like this one” switch.

## 4) WezTerm keeps launch structure explicit and domain-aware

WezTerm's docs say launcher entries use `SpawnCommand`, which can carry an explicit `cwd`, and its multiplexing docs say new tabs can be spawned in the default local domain, the current tab's domain, or a specific domain.

That is a very important separation for Schell.
Same-cwd and same-domain are related conveniences, but they are not identical truths.
A shell+terminal should be free to follow one without silently claiming the other.

## 5) kitty shows both the appeal and the danger of richer cloning

kitty's `launch` action can open a new window with `--cwd=current`, can pass screen/scrollback into a launched program, and supports `--copy-env`.
But the docs also say `--copy-env` only copies the environment from when the source window was first created because updated environment variables cannot be recovered from arbitrary processes.

kitty then goes further with `clone-in-kitty`:
- it opens a new shell instance,
- copies env vars and cwd,
- works over SSH with the ssh kitten,
- and asks the shell to serialize its internal state so the clone can be restored.

That is exactly the kind of luxury Schell should admire.
It is also exactly why cloned footing should stay visibly weaker than fresh reviewed footing.
Terminal-mediated shell-state restoration is powerful, but it is not the same thing as a brand-new exact launch.

## 6) Zellij keeps nearby-spawn context explicit in commands and layouts

Zellij's `run` and `new-pane` flows accept an explicit `--cwd` and can start commands suspended.
Its layouts also allow pane and tab `cwd` fields, with relative cwd composition.

This reinforces the broader lesson:
spawn inheritance should often be represented as small structured footing rather than invisible shell folklore.

## 7) The ecosystem now suggests a richer ladder than “new pane” versus “duplicate pane”

A better Schell ladder probably includes at least:
- **fresh exact launch**,
- **cwd fork**,
- **domain fork**,
- **profile fork**,
- **shell-state clone**,
- **layout-relative spawn**,
- **historical relaunch**.

The exact names can remain open.
But current tools already show that nearby spawn comfort is composed from separable inherited fields.

## 8) The stealable move is not more cloning — it is better forked-footing honesty

The best move to steal is small and sharp:
**make nearby spawn gestures wonderfully fast, but force them to confess what footing they inherited, what they defaulted, what they merely reconstructed, and whether the result is fresh exact launch or a forked convenience spawn.**

That unlocks:
- same-directory splits,
- current-domain follow-ons,
- profile-aware automation shells,
- safer duplicate tabs,
- explicit shell-state clones,
- and easier project cockpits,

without teaching users that every nearby spawn is the same thing as a reviewed exact launch.

## 9) Compact conclusion

Ghostty proves users want fine-grained cwd inheritance across windows, tabs, and splits.
Windows Terminal proves duplicate tab/pane comfort is valuable while still being partial.
VS Code proves env inheritance, split cwd, and automation profiles belong to separate knobs.
WezTerm proves structured launch objects and domain-following spawns are both real.
kitty proves cloned shell state can be luxurious and also terminal-mediated.
Zellij proves layouts and nearby pane creation benefit from explicit cwd structure.

Schell should take the hint.
It needs a first-class split between **fresh exact launch** and **forked footing**, so same-cwd, same-domain, duplicate-tab, and cloned-shell luxury can grow without letting inherited convenience impersonate current reviewed truth.
