# Research synthesis, pass XXXVI (2026-03-21)

This pass focuses on one specific seam:
**modern terminals increasingly detect meaningful structure in output and offer actions on top of it, but Schell should steal the delight without letting detectors, regexes, or quick-fix helpers become a second execution system.**

## 1) VS Code shows the upside of shell-known quick fixes and exact command-context bundles

VS Code's shell integration now does several relevant things at once:
- it marks command boundaries,
- it offers sticky scroll tied to those commands,
- it scans command output for Quick Fix opportunities,
- and it can attach an exact terminal command to chat, including command line, captured output, and exit code.

That is a very important pattern for Schell.
The value is not only the quick fix itself.
The value is that the quick fix hangs off a known command chapter and can be handed off as an exact bounded context bundle instead of vague terminal folklore.

Another particularly good detail is `Run Recent Command`: Alt writes the selected text to the terminal without running it.
That is a strong “insert-first” lesson.
Even when the system thinks it has the right next step, it still offers a weaker landing than execution.

## 2) kitty hints mode shows how much delight is available from bounded visible-region detection

kitty's hints mode is one of the best “steal this carefully” examples.
It lets the operator select arbitrary visible snippets, URLs, likely paths, and file-plus-line references.
Crucially, one of the best default actions is not “open” but **insert into the command line**.
That is a brilliant shell lesson.

kitty also makes the power and the risk obvious by allowing customized matching and actions.
That flexibility is exciting, but it also demonstrates why Schell should keep detector logic and execution authority separate.
Once the UI can match arbitrary text and run arbitrary handlers, the detector surface can quietly become a hidden automation substrate.

## 3) iTerm2 shows both the power and the danger of regex-triggered action systems

iTerm2 gives two especially useful reminders.
First, triggers can run actions when regexes match received text, either instantly or after the cursor leaves the line.
Second, semantic history can use cwd-aware context to open a clicked file, open a URL, or even run a command with multiple captured values.

This is exactly the kind of feature cluster that makes terminals feel super awesome.
It is also exactly where action semantics can get too strong too early.
A regex hit is not the same thing as shell-known truth.
A clicked file-like token is not always safe to open in the strongest possible way.
A run-command fallback is much stronger than reveal, inspect, or insert.

The right lesson is not “avoid these features.”
It is: **separate detector strength from action strength.**

## 4) Windows Terminal suggests a nice source-explicit suggestion model

Windows Terminal's suggestions menu is useful mostly because it names its sources.
It can be populated from recent commands, tasks, or both, and when shell integration is available the current command line can pre-populate the menu.
That sounds small, but it is actually an important design cue.

Suggestion systems are more honest when they say:
- where entries came from,
- whether they are history or configured tasks,
- and whether the current command line was used as input.

Schell should import that discipline.
Detector-driven action surfaces should name source and confidence instead of pretending all rows are equally authoritative.

## 5) xterm.js is a reminder that terminal output is untrusted and handler code is a real boundary

xterm.js security guidance is very blunt:
anything coming from terminal I/O may contain malicious data, embedders should treat terminal data as untrusted on the DOM side, and linkifier/parser hooks expose a real risk surface.
The docs also say that hyperlink handlers should at minimum use a tooltip or prompt and validate what is being opened.

That is deeply relevant to Schell.
Once a custom shell+terminal starts doing richer detection, hover, quick fixes, or command-context helpers, it is no longer just rendering bytes.
It is operating a local parser and action boundary.
That boundary deserves names and humility.

## 6) The best imports are visible now

A compact Schell import could be:
- one **detector witness** object with source, evidence, confidence, and freshness posture,
- one **action rail** that separates explain/copy/insert/reveal/open/review-run,
- one rule that detector hits remain weaker than shell-known truth unless stronger review occurs,
- one insert-first bias for many convenience actions,
- one bounded summon/visible-region mode for broader heuristic detection,
- and one restored/historical posture for old detector hits.

That is enough to learn a lot without choosing:
- the final detector engine,
- the final regex/custom-script/plugin story,
- the final AI fixer integration,
- or the final storage model for detector residue.

## 7) Good steals that stay bounded

Some genuinely strong ideas worth stealing carefully:
- **command-bound quick-fix cards** that know their exact output slice and exit code,
- **insert-first path/file affordances** instead of default-open behavior,
- **visible-region hints mode** for rich discovery without hidden full-history crawling,
- **exact handoff bundles** for troubleshooting or agent escalation,
- and **source-labeled suggestion menus** where history, tasks, shell-known witnesses, and heuristics remain visibly different.

## 8) The lesson we must learn from the past

The old mistake was thinking terminals should stay dumb text forever.
The new mistake would be letting every useful detector immediately become a stronger action than its evidence deserves.

The better answer is:
- keep detector sources graded,
- keep action ladders explicit,
- keep insert/reveal/open/run separate,
- keep restored detector hits historical until re-proved,
- and keep regexes, hints, or quick fixes from silently becoming a second shell.
