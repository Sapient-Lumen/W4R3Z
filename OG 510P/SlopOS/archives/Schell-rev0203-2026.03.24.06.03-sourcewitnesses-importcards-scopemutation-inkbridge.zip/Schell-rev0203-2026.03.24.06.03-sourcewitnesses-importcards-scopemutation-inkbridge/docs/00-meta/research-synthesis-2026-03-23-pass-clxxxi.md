# Research synthesis — 2026-03-23 — pass CLXXXI

This pass sharpens one fresh lesson from current terminal and watch-sync docs:
**the ecosystem already gives us exact command/prompt boundaries and synced-through source cursors, but it still leaves an obvious operator gap: what have _I_ already reviewed, and where should resume land next?**

## 1) Current terminals now expose exact boundaries that are good enough for resume anchors

VS Code's terminal shell integration explicitly supports command detection, decorations, and navigation.
Its command-navigation docs describe reliable command positions, a command guide beside commands and their output, and sticky scroll that keeps the partially visible command at the top and lets a click jump back to that command.

Ghostty's shell integration docs add prompt-local jump comfort directly: the `jump_to_prompt` keybinding scrolls between prompts.

WezTerm keeps the substrate tiny with OSC 7 plus OSC 133/1337 and says those sequences enable jumping through scrollback to the start of earlier commands and conveniently selecting the complete output from a command.

Windows Terminal's shell integration docs make the same substrate more explicit: marks are stable as of Terminal 1.21, OSC 133 can mark prompt/command/output/finished boundaries, and the UI can scroll between marks or select an entire command or its output.

Even iTerm2's long-lived shell integration keeps proving the same point: when shell integration is enabled, marks appear at prompts and can be navigated with keyboard shortcuts.

Taken together, these docs imply a strong no-regret idea for Schell: **exact first-unseen anchors are already plausible once boundaries exist.**

## 2) Watch APIs already separate source-synced cursors from client-local use

Kubernetes' API concepts docs keep the source-cursor lesson crisp.
Clients can ask for `BOOKMARK` events, but the docs warn that bookmarks are not guaranteed on any specific interval and may not arrive at all.
When `sendInitialEvents=true` is used, the API server can send initial synthetic `ADDED` events, then a `BOOKMARK`, and then continue the regular watch stream from that synced resource version.

That is a powerful design hint for Schell.
A source-synced cursor is not the same thing as a viewer-local read or review boundary.
One tells you what the source has caught up through.
The other would tell you what this viewer has actually reviewed through.

## 3) Fresh prompt boundaries keep resume anchors more trustworthy

fish 4.5.0 tightened two details that matter here: it now reports the working directory on every fresh prompt via OSC 7, and its OSC 133 prompt markers now also mark the prompt end.
Those changes reduce stale prompt footing and strengthen the case that a resume anchor can land on an exact prompt or command boundary rather than an approximate scroll guess.

## 4) The no-regret Schell move is not a read-state platform

Putting these together suggests a smaller move than a giant read-state service.
Schell should add:
- a tiny **review watermark** that says what exact base cut or later-change lane has been reviewed through,
- plus a **first-unseen anchor** that says where resume should land next when known,
- while keeping both weaker than the source cursor, current live lane, and any stronger action rights.

The value is not only cosmetic.
It would let hidden-terminal reopen, preserved command cards, watch snapshots, and attach-for-help surfaces say:
- what later change exists,
- what has already been reviewed through,
- where the first unseen thing begins,
- and when refresh or reset is still the honest next move.

## 5) Compact conclusion

VS Code, Ghostty, WezTerm, Windows Terminal, and iTerm2 all keep proving that exact prompt/command boundaries are cheap enough to navigate and select.
Kubernetes keeps proving that synced-through source cursors deserve a first-class witness.
fish 4.5.0 keeps improving prompt-boundary freshness.

So the next no-regret Schell seam is not a bigger follow/replay constitution.
It is **review watermarks, first-unseen anchors, and seen-state humility** so the shell+terminal can separate source-synced truth from viewer-reviewed-through truth and make resume much more humane without overcommitting the architecture.
