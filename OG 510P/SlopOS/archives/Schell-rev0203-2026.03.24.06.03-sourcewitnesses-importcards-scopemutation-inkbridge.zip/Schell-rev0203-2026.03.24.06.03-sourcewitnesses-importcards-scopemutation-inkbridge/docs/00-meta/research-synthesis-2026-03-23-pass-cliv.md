# Research synthesis — 2026-03-23 — pass CLIV

This pass sharpens the next smaller lesson from current shell+terminal tools:
**paste got safer once terminals and shells learned to distinguish paste from typing, but current tools still leave a narrower seam unresolved — whether newline-bearing ingress should insert, arm, or spend.**

That points to a good next Schell move:
**paste witnesses, trailing-newline gates, and explicit insert-versus-spend posture** rather than one more vague story where pasted text becomes “what the user meant to run” just because it landed at a prompt.

## 1) GNU Readline proves pasted bytes deserve their own path

The current Bash/Readline manual says `enable-bracketed-paste` inserts each paste as a single string of characters rather than treating the characters as if they had been read from the keyboard, and that it prevents editing commands bound to key sequences in the pasted text.

That is a foundational lesson.
Bracketed paste already says pasted content is not just more typing.
Schell should keep building on that separation.

## 2) zsh shows paste transforms are a real editor surface, not a UI trick

Current zsh docs say `bracketed-paste-magic` wraps ordinary `bracketed-paste`, re-enables selected widget processing, and supports `paste-init`, `paste-finish`, and helpers like `quote-paste`.

That matters because it proves target-aware paste transforms are not exotic.
The clever move is not to hide them.
It is to keep them visible and bounded.

## 3) VS Code and WezTerm both keep “send this text” close to paste rather than fake typing

VS Code currently warns on multiline paste when the shell does not support bracketed paste mode, and its terminal-selected-text flow is documented as running text in the terminal rather than pretending the user typed it by hand.
Its release notes also say “Run Selected Text in Active Terminal” uses bracketed paste in supporting shells so multiline selections are treated as a single input.

WezTerm’s `send_paste` docs say that if the terminal attached to the pane is set to bracketed paste mode, the text is sent as a bracketed paste and newlines will not be rewritten.

That is a strong design clue for Schell.
Selected-text send and helper-originated insertion are siblings of paste, not siblings of fresh typing.

## 4) iTerm2 keeps rediscovering that newline-bearing paste deserves separate warning posture

iTerm2’s current docs expose several different paste-specific affordances:
Advanced Paste, Paste Slowly, Warn Before Multi-Line Paste, Limit Multi-Line Paste To Shell Prompt, and Warn Before Pasting One Line Ending in a Newline at Shell Prompt.
That last one is especially revealing: prompt-aware warning only works when shell integration is present.

The ecosystem is telling us something very specific here.
A single line plus a trailing newline is not a trivial detail.
It is submit-shaped ingress.
Schell should name that seam directly instead of burying it under generic paste handling.

## 5) kitty treats paste as a transform-and-confirm surface

kitty’s current configuration docs say `paste_actions` can quote URLs at a shell prompt, replace dangerous control codes, replace newlines, confirm pastes with terminal control codes, confirm very large pastes, or filter pasted text.

This is exactly the kind of brilliant idea worth stealing carefully.
The best move is not to make paste magical.
It is to make smart paste transformations explicit and target-aware.

## 6) PowerShell/PSReadLine proves paste path affects execution behavior

Current PSReadLine docs say its Paste function pastes the entire clipboard into the input buffer and then passes the buffer to the PowerShell parser, while right-click paste copies one character at a time and parses one line at a time when a newline is copied.
The docs explicitly say the difference between paste methods results in different execution behavior.

That is one of the clearest possible warnings for Schell.
Paste path is not an implementation detail.
It changes what becomes true.

## 7) Ghostty’s 2026 fix reminds us that pasted control structure is still a live security seam

Ghostty 1.3.0 fixed a security issue where control characters such as `0x03` in pasted or drag-and-dropped text could be used to execute arbitrary commands in some shell environments.

That is a vivid reminder that “the user pasted it” is not enough reason to let ingress borrow spend authority.
Schell should treat control-bearing paste as structured ingress first, not as ordinary authored input.

## 8) The concrete Schell move

Schell should add a compact paste-spend contract:
- **paste witness** — what exact ingress arrived,
- **delivery posture** — bracketed / literal / replay / unknown,
- **newline posture** — no newline / interior newline / trailing newline / repeated / control-bearing,
- **target posture** — live prompt / reclaimed prompt / editor host / alt-screen app / unknown,
- **submit posture** — insert-only / arm-on-review / arm-now / spend-now / blocked,
- **receipt posture** — no-spend / candidate-only / spent / blocked.

That is enough to steal prompt-aware paste luxury, selected-text send, newline warnings, quoting transforms, and control sanitization while refusing the old lie that pasted text at a prompt is self-authenticating fresh intent.
