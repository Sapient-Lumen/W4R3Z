# Research synthesis — 2026-03-23 — pass CLXXXVII

This pass sharpens one smaller lesson from current shell and terminal docs:
**discovery should be context-rich and insert-first, but still visibly weaker than execution.**

## 1) Current tools are converging on “find, then stage” instead of “find, therefore run”

Atuin is especially clear about this.
It records extra command context such as directory, time, exit code, host/user, and shell session, and its interactive UI can either execute a selected entry immediately or return it to the command line for editing.
That is a powerful product clue.
A modern shell recall surface should preserve rich context and still keep “insert for editing” as a first-class path.

Warp pushes the same instinct from a different angle.
Its command palette searches workflows, notebooks, actions, sessions, and launch configurations, while workflow execution from the palette pastes the workflow into active terminal input so the operator can adjust arguments or the command before running.
That is exactly the kind of delight Schell should steal.

## 2) The best discovery surfaces unify many result families without flattening them

iTerm2 now combines marks, annotations, and a broadened Open Quickly surface that also reaches named marks and menu items.
Windows Terminal and WezTerm both use command palettes for local terminal actions, with WezTerm explicitly fuzzy-matching action names and Windows Terminal supporting nested command groups.

That teaches a useful small rule:
**one palette can host object recall and local actions, but the rows should still confess which family they belong to.**

Schell should therefore avoid both extremes:
- do not build five separate tiny choosers for every object class,
- but do not hide object-vs-action differences behind one flattering universal result row either.

## 3) Context filters are not polish; they are part of truthfulness

Atuin's filter modes — global, host, session, directory, workspace, and session-preload — show that search results feel much more trustworthy when their scope is explicit.
That suggests Schell should expose context stripes or compact scope chips rather than leaving narrowing entirely to ranking folklore.

A result found “in this workspace, from this session, on this peer” is meaningfully different from one found “somewhere in all synced recall.”
The UI should say so.

## 4) Preview and ranking remain the danger zone

The more powerful discovery becomes, the more dangerous hidden preview and hidden ranking become.
Atuin exposes both preview and inspector concepts, which is useful but also a reminder that preview is a separate posture from selection.
Windows Terminal and WezTerm keep palette actions explicit rather than pretending fuzzy matching alone settles what should happen next.

So the next Schell rule should stay small:
- result rows may expose metadata,
- ranking may help order results,
- but preview and strong action should remain separately named steps.

## 5) The nicest ergonomic seam is tiny: keep open, hide, or dismiss

Discovery tools often feel better or worse because of what happens after an action.
The official docs keep hinting at this even when they are not framing it as philosophy: search surfaces are used for one-shot action, repeated staging, and quick inspection.
That is why Schell should likely preserve at least three palette outcomes:
- keep open,
- hide and return,
- dismiss.

This small seam makes a discovery surface feel dramatically better without deciding a giant architecture.

## 6) The no-regret Schell move

Schell should deepen its command-deck and chooser work around:
- exact marks and local annotations,
- explicit context stripes,
- object rows versus action rows,
- metadata-safe previews,
- and insert-not-run defaults for recall-heavy flows.

That would make the shell+terminal feel much more superb at getting back to work without freezing one global search index, one sync model, one preview engine, or one command-palette constitution.

## 7) Compact conclusion

The current ecosystem already paid for the lesson:
rich discovery is great, but the honest magic is contextual recall plus editable landing, not hidden execution.

So the next low-regret Schell seam is **context stripes, insert-not-run recall, and deck honesty** so marks, notes, actions, sessions, seeds, and chapters can share one discovery plane without quietly becoming one authority plane.
