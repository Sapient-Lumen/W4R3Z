# SlopOS datacube evaluation — pass CXLIX

This pass asks a narrower companion-safe question than “how should Schell do history or recents?”
The better question is:
**how should Schell represent “what I last saw” and “what I am caught up through” so historical cursor comfort never borrows the strength of current live SlopOS truth?**

## 1) SlopOS keeps refusing weak historical evidence as strong current truth

Even while still in design phase, SlopOS repeatedly rejects the flattering shortcut from prior observation to present fact.
Its request-vs-live-state posture refuses to let a previously accepted request impersonate provider-owned current truth.
Its OpenURI launch-completion boundary refuses to let admission or showing posture become completion or consumption proof.
Its recent-items/history posture refuses to let generic recents silently become durable current-state or reopen authority.

That is the direct Schell companion lesson:
**historical navigation evidence should stay historical.**
A remembered prompt, old output chapter, last-seen row, or prior directory is useful, but it should not silently inherit live-state strength.

## 2) Cursor witnesses fit SlopOS better than one generic history/recent object

A single “recent” object is too mushy for the SlopOS family.
A Schell object family that distinguishes:
- live prompt witness,
- historical prompt mark,
- command-output anchor,
- line-relative file/designator cue,
- directory cursor,
- stream caught-up-through cursor,
- expired cursor requiring reset,

is much more companion-safe.
It preserves delight while protecting claim strength.

## 3) Helm gives the clearest companion pressure: change cursors are not live truth

Among the companion cubes, Helm names the seam most directly.
Its architecture overview explicitly separates “what I last saw,” “where a stream can resume,” “what exact start semantics apply,” and “has this changed since then?” from current-live truth. It also names reset cards for cursor expiry, history pruning, source replacement, and exact reset scope.

That is probably the best direct import for Schell right now.
The shell+terminal should not merely offer “jump back.”
It should say what the cursor means, how strong it is, and what exact reset is needed if it expired.

## 4) ViewFS and Steward reinforce the same split

ViewFS keeps object class, basis, delta, and apply posture distinct.
That suggests Schell should keep a command row, directory row, prompt mark, line-cwd open target, and stream cursor as different historical object classes rather than one flattened history list.

Steward keeps freshness, countdown, pushback, and completion posture distinct.
That suggests Schell should let “caught up through X” decay honestly and surface explicit reset or revalidation when the underlying stream/history changed.

## 5) What Schell should steal now

Schell should steal several excellent outside moves, but import them as historical cursor witnesses:

- prompt-zone jump keys and command-boundary selection,
- output-of-last-command browse actions,
- per-peer command and directory memory,
- history rows with separate reveal / insert / `cd` verbs,
- semantic-history line-cwd cues for safer file open/reveal,
- explicit caught-up-through chips for streams and room chapters,
- and reset cards when history or source epochs invalidate an old bookmark.

## 6) What Schell should refuse now

Schell should refuse:

- one generic recent/unread/resume dot,
- silent jump-to-latest repair when an old cursor dies,
- historical prompt marks that visually impersonate the live prompt,
- history rows that default to spend stronger authority than insert/reveal,
- and stale bookmarks that survive source replacement or pruning without visible reset scope.

## 7) Compact conclusion

The companion-safe answer is not to avoid rich history and navigation luxury.
It is to turn them into **typed historical cursor objects** with exact verbs and reset honesty.
If Schell keeps `live now`, `last seen`, `caught up through`, `jump`, `reveal`, `insert`, `cd`, `open relative`, and `reset` visibly distinct, it can become much more humane than shell folklore while staying aligned with SlopOS exactness during the design phase.
