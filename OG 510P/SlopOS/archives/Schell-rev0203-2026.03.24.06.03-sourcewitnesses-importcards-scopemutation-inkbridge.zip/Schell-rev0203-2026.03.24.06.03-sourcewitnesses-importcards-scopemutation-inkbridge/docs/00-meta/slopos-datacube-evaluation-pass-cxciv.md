# SlopOS datacube evaluation — 2026-03-23 — pass CXCIV

**Schell should treat navigation help as a local proposal or visibly admitted movement rather than as hidden footing truth, because SlopOS and the companion cubes keep rewarding exact targets, explicit routing, visible labels, freshness posture, and neighboring-state separation.**

## 1) SlopOS keeps footing narrower than movement folklore

SlopOS keeps reviewed targets exact and suspicious of ambient fallback.
That pressure matters directly here.
A bare token like `src`, a `CDPATH` hit, or a ranked jump result can be great operator comfort, but it should stay weaker than the exact working-ground witness and weaker still than the reviewed target of the next stronger act.

So the companion-safe import is:
- navigation may be delightful,
- helper packs and jump indexes may exist,
- migration comfort may matter,
- but exact footing still needs its own explicit witness lane.

## 2) SlopOS plumb posture argues for suggest / inspect / admit / compare

Request-local plumb posture is a useful nearby lesson.
Navigation surfaces should be excellent at **suggest / inspect / admit / compare**.
They should be much more cautious about hidden movement that later pretends to have been obvious shell truth all along.

That means candidate routes should keep their source and freshness visible, and resulting cwd truth should be reacquired explicitly after admission rather than guessed from prompt folklore.

## 3) Borrowed/helper pressure says route families need source labels

Borrowed-mode and provider-locality pressure map cleanly onto helper-driven movement.
If a repo helper, imported profile, `CDPATH`, ranked jump tool, or assistant suggestion participates in navigation, Schell should keep that fact visible.
Otherwise a tiny convenience layer quietly becomes a second authority plane over operator footing.

## 4) ViewFS again supplies the best neighboring-state discipline

ViewFS keeps editable text, parse understanding, compiled packet, prepared action, and history distinct.
That same discipline should govern movement:
- typed navigation token,
- candidate route set,
- admitted jump,
- exact cwd witness,
- prepared action footing,
- and historical residue

should remain neighbors rather than collapsing into one flattering "you are now here" object.

## 5) Harbor, Ward, Steward, and Helm keep the movement seam honest

- **Harbor** reinforces label honesty, which matters when movement should say whether it came from literal path, implicit-`cd`, `CDPATH`, stack recall, or ranked jump memory.
- **Ward** reinforces revalidation pressure, which matters when old jump memories and root searches may no longer describe today's ground.
- **Steward** reinforces trim/freshness posture, which matters when recency/ranking indexes are local and intentionally pruned.
- **Helm** reinforces omission/miss posture, which matters when a navigation receipt should confess what route family was searched, what alternatives existed, and what was never claimed.

Together they keep one rule sharp:
**movement can improve speed, but it must not erase source labels, freshness posture, or exact footing truth.**

## 6) What this still does not require Schell to decide

This seam does **not** require Schell to decide:
- one final cwd ontology,
- one final ranking engine,
- one final project-root system,
- one final prompt path display treaty,
- one final helper-import story,
- or one final history serialization for directory movement.

The archive only needs to prove the honesty stack that says:
- what token was typed,
- what candidate routes were considered,
- what source family participated,
- what movement was admitted,
- what exact cwd truth now stands,
- and what historical residue is safe to replay or share.

## 7) Compact conclusion

SlopOS keeps exact footing narrow and explicit.
ViewFS keeps neighboring states separate.
Harbor, Ward, Steward, and Helm keep labels, freshness, revalidation, and omission honest.

So the next Schell move should be:

**add AUTO_CD receipts, CDPATH reveals, ranked-jump labels, and exact cwd compare so Schell can steal navigation comfort without letting movement folklore quietly become hidden footing authority.**
