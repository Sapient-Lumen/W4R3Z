# Research synthesis, pass LXXXIII (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should steal the best current session-manager, workspace, layout, and context-switch ideas — fuzzy workspace launchers, previewful session trees, folder-plus-layout starters, and project session files — but it should keep visible workspace state, cached layout memory, restored sessions, and current live authority separately named so “I can see or resurrect this context” never impersonates “this is the exact live shell truth right now.”**

This seam matters because shells and terminals become magical the moment they help users return to work without rebuilding context by hand.
They also become misleading in exactly the same place.
The current ecosystem now gives Schell both the delightful patterns and the cautionary evidence.

## 1) Workspaces are an excellent visibility wrapper, not proof of liveness

WezTerm’s workspace model is unusually clear about this split.
Its docs say windows can be spawned into differently named workspaces, that they will not become visible until that workspace is activated, and that switching workspaces swaps the GUI windows to the MuxWindows belonging to the newly focused workspace.
The `SwitchToWorkspace` action can even create a workspace and optionally spawn a command when the workspace does not yet exist.
See: https://wezterm.org/recipes/workspaces.html and https://wezterm.org/config/lua/keyassignment/SwitchToWorkspace.html

The stealable idea is obvious: named workspaces are great.
The caution is equally obvious: visibility and existence are not the same as current shell truth.
A workspace is a local context wrapper.
It should not silently become the source of durable liveness, active-input truth, or approval basis.

## 2) Unified launchers are worth stealing when families stay visibly distinct

WezTerm’s `ShowLauncherArgs` is especially interesting because the launcher can be scoped to tabs, launch-menu items, domains, workspaces, and commands, and can start directly in fuzzy mode.
That is a strong clue for Schell.
One chooser can span many kinds of context-switch targets if the family labels remain explicit.
See: https://wezterm.org/config/lua/keyassignment/ShowLauncherArgs.html

The right lesson is not “make one omnipotent palette.”
It is “make one query surface that still shows whether the candidate is a workspace, live session, layout recipe, launch route, domain, or historical resurrection object.”

## 3) Previewful trees are still one of the best old multiplexer ideas

tmux tree mode remains one of the clearest session-navigation patterns in the ecosystem.
It can browse sessions, windows, and panes, shows previews, allows expanding and collapsing items, and even lets users tag multiple items for batch actions.
See: https://github.com/tmux/tmux/wiki/Getting-Started and https://man7.org/linux/man-pages/man1/tmux.1.html

That is an excellent thing to steal.
A shell+terminal should absolutely help users see the structure around them before they jump.
But tmux also shows the danger: the same chooser can kill objects or apply commands to multiple tagged items.
So Schell should keep preview, attach, inspect, batch-manage, and strong-action lanes distinct instead of flattening them into one tree-mode authority surface.

## 4) Layout files are powerful because they are explicit recipes

Zellij and kitty both show why layout/session files are so attractive.
Zellij layouts are text files defining panes and tabs and can be applied on startup, inside a running session, or even from a remote URL.
kitty sessions are text files where users define tabs, windows, layouts, working directories, and what programs to run, and kitty can start from one directly or via `startup_session`.
See: https://zellij.dev/documentation/layouts.html and https://sw.kovidgoyal.net/kitty/sessions/

The stealable idea is the explicit recipe.
The caution is that these recipes often contain more than layout memory.
Once a “layout” also chooses cwd, launches programs, or comes from a remote URL, it stops being mere view memory and becomes executable footing.
Schell should therefore keep pure layout memory, project start recipes, and code-bearing session files separately named.

## 5) Session managers are magical when they separate start, attach, and resurrect

Zellij’s current session-management tutorial is one of the cleanest examples here.
Its welcome screen can start a new session in a chosen folder and layout, attach to running sessions, and resurrect exited sessions from old context.
Separately, its resurrection docs say sessions are serialized into a layout every second and saved in the cache folder; the files are human readable and can even be shared across machines.
See: https://zellij.dev/tutorials/session-management/ and https://zellij.dev/documentation/session-resurrection.html and https://zellij.dev/documentation/options.html

This is both inspiring and cautionary.
Starting, attaching, and resurrecting are not the same act.
And cache-resident, shareable, human-readable resurrection files are useful precisely because they are historical/contextual artifacts.
They should not impersonate exact live state or current approval basis.

## 6) Serialization depth needs visible posture

Zellij’s options also show how fast resurrection can widen.
`session_serialization` can make sessions resurrectable; `pane_viewport_serialization` can capture the visible pane viewport; and `scrollback_lines_to_serialize` can increase how much text is stored.
See: https://zellij.dev/documentation/options.html

That is a great clue for Schell.
Users benefit from resurrection depth, but they should see whether an object carries only layout memory, command identities, viewport residue, or deeper scrollback/history residue.
A workspace/session card should say how much was remembered, not flatter all restoration into the same trust class.

## 7) What Schell should now do

This pass points to a compact, high-value session/workspace model:
- **workspace cards** that name the local context wrapper and its visible posture,
- **session cards** that distinguish live / detached / cached / resurrectable / historical,
- **layout-memory cards** for pure pane/tab arrangement,
- **start recipe cards** for cwd-plus-command launch bundles,
- **chooser family chips** for workspace / session / layout / domain / history,
- **preview-first navigation** before attach/switch,
- **single active-input truth** separate from whatever workspace is currently visible,
- **restoration-depth badges** for layout-only versus viewport/scrollback residue,
- **workspace launchers** that can create a fresh context without pretending it inherits old approval,
- and **hold cards** whenever a restored or cached context is mistaken for live authority.

## 8) Decisions intentionally kept open

This pass does **not** freeze:
- one final workspace persistence model,
- one final layout-file grammar,
- one final session-manager backend,
- one final session-sync/resurrection format,
- one final local-versus-remote workspace abstraction,
- or one final omnipalette architecture.

The no-regret move is smaller:
**give Schell workspace cards, session cards, layout-memory cards, family-labeled choosers, preview-first switching, and restoration-depth badges so context switching becomes luxurious without letting visible or cached context impersonate current live truth.**
