# Research synthesis — 2026-03-23 — pass CXLI

This pass sharpens one fresh shell+terminal lesson from current upstream docs:
**the ecosystem increasingly knows how to answer interactive prompts, auto-reply to repeated questions, and send text back into running PTYs — which makes prompt identity and reply-scope honesty a real design seam rather than a small convenience detail.**

## 1) VS Code shows the smallest honest auto-reply contract

VS Code's terminal auto replies are instructive precisely because they are narrow.
They only fire when an exact configured output sequence is seen, and the docs explicitly say no auto replies are configured by default because providing shell input should be an explicit action or configuration by the user.
That is a very Schell-shaped lesson.
The honest first luxury is not “understand any prompt.”
It is “for one exact known prompt, optionally send one exact known reply under explicit operator policy.”

## 2) iTerm2 reminds us that prompt-answering is really terminal-stream pattern matching plus input injection

iTerm2's trigger system makes the mechanics unusually plain.
It matches regular expressions against terminal text and can then capture output, inject data into the input stream, or make features such as prompt detection work without installed shell integration.
That is powerful, but it is also the warning label.
The terminal often acts on *stream-shaped evidence*, not semantic ownership truth.
Regex-matched question text, helper banners, and shell/native prompts can all look similar enough to be dangerous if the product flatters itself.

## 3) Warp proves that prompt-answering now lives inside the interactive agent story

Warp's Full Terminal Use docs now say an agent attached to a live PTY can read the terminal buffer, write to the PTY, respond to prompts, and optionally enable auto-approval for similar commands in the current session.
Separately, Warp's agent management docs say agents notify you when they need input such as permission to run a command or approval to apply a code diff.
That is a very useful split.
Sometimes the right luxury is an answer.
Sometimes the better luxury is a clean “needs input” checkpoint plus a fast handback.

## 4) Claude Code shows a second useful split: lifecycle hooks versus judgment

Claude Code's current hooks guide says hooks can run automatically when Claude Code edits files, finishes tasks, or needs input, and it specifically includes notifications for when Claude needs input plus auto-approval for specific permission prompts.
That is another good hint.
Prompt-answering is not one thing.
There is at least a split between deterministic hookable checkpoints and questions that still need live judgment.

## 5) kitty shows how local overlays can collect input and paste or send it back

kitty's custom-kitten docs make another important truth visible: a local overlay can ask the user for input and then paste or send text into the target terminal window afterward.
That is exactly the kind of luxury Schell will eventually want.
But it also means local input collection and later PTY send are distinct events with different truth stories.
The overlay's text is not the same thing as shell-owned prompt truth until an explicit send path materializes it.

## 6) The ecosystem is converging on a quieter lesson than “auto-answer everything”

The nicest current ideas are not really about full semantic understanding of every prompt.
They are about giving operators a ladder of better choices:
- exact auto-reply on known text,
- regex or family recognition with weaker trust,
- session-scoped approval/answer reuse,
- explicit needs-input notifications,
- and local overlays or sidecars that collect an answer before a later send.

That is a better framing than “the terminal can answer prompts now.”
It leaves room for several honest lanes instead of forcing fake certainty.

## 7) The stealable move is answer chips with prompt fingerprints

The best move to steal is small and sharp:
**treat interactive questions as witnessed objects and offer reviewable answer chips bound to exact prompt fingerprints, narrow prompt families, and explicit once/room/session scope.**

That unlocks:
- safer confirmation handling,
- clearer input-needed checkpoints,
- humane REPL/dev-server assistance,
- narrow permission reuse,
- better replay/receipt views,
- and less babysitting during long-running work,

without teaching users that a pretty terminal or active agent semantically understands every repeated question.

## 8) Compact conclusion

Current docs now show several real prompt-answering lanes in the wild.
VS Code keeps the auto-reply contract exact and opt-in.
iTerm2 exposes regex-driven send/inject mechanics directly.
Warp brings prompt response and needs-input checkpoints into live PTY agent work.
Claude Code makes input-needed and specific permission prompt automation explicit hook points.
kitty proves that local overlays can gather input and later send it back.

Schell should take the hint.
It needs a first-class split between **prompt witness**, **prompt fingerprint**, **prompt owner**, **answer chip**, **notify-only checkpoint**, **room/session reuse scope**, and **later reviewed shell consequence** so the future shell+terminal can feel dramatically nicer without letting “looks familiar” impersonate semantic truth or ambient authority.
