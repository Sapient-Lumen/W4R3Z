# Research synthesis — 2026-03-23 — pass CXLIX

This pass sharpens the next narrower lesson from current shell+terminal tools:
**modern terminals are getting wonderfully good at helping people jump back to prompts, command output, old commands, and old directories, but those affordances are much safer when they are treated as explicit cursor witnesses — “what I last saw” or “what I can jump back to” — rather than as proof of current live truth.**

That points to a good next Schell move:
**change cursors and reset cards** rather than one more vague recent/unread/history story.

## 1) VS Code proves command positions are a navigation substrate, not a liveness oracle

VS Code’s shell-integration docs say the commands detected by shell integration feed command navigation so the terminal gets more reliable command positions, and the feature can select a command’s output. The same page describes the command guide as a bar beside a command and its output that helps identify the command boundary and verify shell integration is working.

That is a strong Schell clue.
Command boundaries are a fantastic navigation primitive.
But they are still boundary witnesses inside scrollback, not proof that the old command is the current live footing.

See:
- https://code.visualstudio.com/docs/terminal/shell-integration

## 2) WezTerm, Ghostty, and kitty prove prompt marks are great — and still weaker than live truth

WezTerm’s `ScrollToPrompt` action uses OSC 133 prompt zones so people can skip over large amounts of output and jump to earlier prompt boundaries. Ghostty’s shell integration exposes `jump_to_prompt`, output-of-command selection, and click-to-move inside an active prompt. kitty’s shell integration says prompt marking enables jumping to prompts, browsing the output of the last command, and click-to-move cursor functionality.

That cluster is important.
Prompt marks are already becoming a shared luxury layer across terminals.
But all three examples are really about **jumpability** and **command/output boundary recovery**.
They help you reacquire a place.
They do not make that place current, live, or approval-bearing by themselves.

See:
- https://wezterm.org/config/lua/keyassignment/ScrollToPrompt.html
- https://ghostty.org/docs/features/shell-integration
- https://ghostty.org/docs/config/keybind/reference
- https://ghostty.org/docs/install/release-notes/1-3-0
- https://sw.kovidgoyal.net/kitty/shell-integration/

## 3) iTerm2 proves historical rows become much more humane when verbs stay explicit

iTerm2’s current docs are unusually rich here. With shell integration, command history is stored separately for each username+hostname combination. Clicking a history row scrolls to reveal it; double-clicking enters the command; option-double-click emits a `cd` command to go to the directory where it was last run. Recent directories are also stored per username+hostname, sorted by frecency, and can either type the path or emit `cd`. Semantic History tracks the working directory for each line so Cmd-click can open files more intelligently. iTerm2 also exposes explicit “Set Mark” and “Jump” behavior.

That is a superb Schell lesson.
A single remembered row can support several different verbs:
- reveal old location,
- insert old command,
- change to old directory,
- open a file relative to the line’s cwd,
- jump to a saved mark.

The product win is not one magic smart click.
It is a visible verb ladder over a historical cursor.

See:
- https://iterm2.com/documentation-one-page.html
- https://iterm2.com/documentation-escape-codes.html

## 4) Atuin proves history gets better when scope is carried with it

Atuin’s basic-usage docs say it records the command, directory, time and duration, exit code, hostname+user, and shell session. Its TUI can execute immediately with Enter or insert into the shell for editing with Tab. Its current config docs add filter modes such as global, host, session, directory, workspace, and session-preload.

That is another strong Schell clue.
History is most useful when “where this came from” and “what scope it belongs to” stay nearby.
That means historical cursor objects should keep peer, session, cwd/workspace, and freshness posture visible enough that old context does not borrow current footing by vibes alone.

See:
- https://docs.atuin.sh/cli/guide/basic-usage/
- https://docs.atuin.sh/cli/configuration/config/

## 5) A past lesson worth stealing: shell vs terminal memory must stay separate

Atuin Desktop’s shell-environment docs restate a lesson many systems forget: a shell interprets and executes commands, while a terminal emulator renders and captures input. The same docs explain that Atuin Desktop captures environment variables from an interactive shell at startup for script blocks, and that this has limits: newly installed tools may require restart, complex shell config may not transfer cleanly, and interactive setup does not always carry into non-interactive runs.

That is a valuable past lesson for Schell.
Any “last seen here” or “resume from here” cursor should say whether it points at:
- terminal-local scrollback position,
- shell-owned prompt boundary,
- remembered cwd/workspace,
- captured startup environment,
- or something weaker.

Otherwise remembered terminal position starts impersonating current shell footing.

See:
- https://docs.atuin.sh/desktop/shell-environment/

## 6) Compact conclusion

Current tools keep converging on a useful answer.
The next no-regret shell+terminal import is not another giant history system.
It is a compact family of **cursor witnesses** that separate:
- `live here now`,
- `last seen here`,
- `caught up through`,
- `jump to historical prompt`,
- `reveal old command output`,
- `insert old command`,
- `cd to old directory`,
- `open relative to historical line cwd`,
- and `reset because the bookmark expired or drifted`.

That bundle would let Schell steal the best ideas in shell integration, prompt jumping, semantic history, command history, and recent-directory recall without pretending that remembered navigation targets are live authority.
