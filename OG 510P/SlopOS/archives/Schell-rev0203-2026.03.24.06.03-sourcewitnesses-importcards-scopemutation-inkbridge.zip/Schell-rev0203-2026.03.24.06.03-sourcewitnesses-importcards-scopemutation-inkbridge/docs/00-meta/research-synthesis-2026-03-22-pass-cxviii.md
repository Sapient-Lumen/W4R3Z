# Research synthesis, pass CXVIII (2026-03-22)

This pass makes one narrower lesson explicit:
**Schell should separate memory presence from action lease. A command, directory, block, or restored session may remain searchable and useful while its default action posture decays from rerun-worthy to inspect/insert-only as age and basis drift accumulate.**

The outside ecosystem keeps converging on this without naming it directly.
VS Code's Run Recent Command now shows the last time a command ran and returns the terminal to its previous state after run or cancel.
VS Code also now lets operators ignore commands like `clear` and common agentic CLIs in terminal sticky scroll, and it can suppress some tool-run commands from shell history when shell integration works.
iTerm2 stores command history and recent directories separately for each username+hostname combination, sorts directories by frecency, and can persist command, directory, hostname/username, and paste history to disk.
Atuin supports history search filtered by cwd, session, exit code, and before/after windows, plus deletion of matching history later.
Fish distinguishes private mode, current-session clearing, and session-specific history names.
Warp session navigation is ordered by recency and searches by prompt, current command, last command, and status, while session restoration revives only the last few Blocks and keeps restoration data in a local SQLite database.

Together these suggest a new Schell move:
**remembered shell objects should have action half-lives.**

## 1) Modern terminal recall is already richer than line history

The important product change is no longer “history exists.”
It is that history now carries:
- peer identity,
- cwd,
- exit status,
- time,
- session grouping,
- block/session restoration,
- and richer navigation/search behavior.

Once those exist, the next humane question is not only where memory lives.
It is also:
**when should it stop feeling ready-to-act?**

## 2) VS Code shows that recent-command UX is safer when it stays review-shaped

Showing the last time a command ran and restoring the terminal to its prior state after run/cancel is a strong clue.
It makes the “recent command” object navigational and review-shaped rather than a blunt replay primitive.
The new sticky-scroll ignored-commands setting pushes further in the same direction: some commands should not occupy privileged recent-command chrome at all.
And the history suppression for terminal-tool commands shows that authorship affects history posture.

## 3) iTerm2 and Warp show why recency is helpful but not sufficient

Per-peer history, recent directories, and frecency make recall feel much smarter.
Warp's session search and restoration features make cross-session continuity much better.
But these same features also prove that remembered items are no longer generic shell lines.
They are contextual objects whose stronger actions should decay when the footing is no longer obviously current.

## 4) Atuin and fish show that shells already carry time windows and memory lanes

Atuin's filters and deletion flows make time, cwd, exit code, and scope part of history truth.
Fish's private mode, clear-session behavior, and alternate session names show that history can already be split into distinct visibility and retention lanes.
That means a Schell action-lease model would not be exotic.
It would be a clearer version of pressure the ecosystem already exposes piecemeal.

## 5) Compact design-phase answer

Schell does **not** need one final ranking engine or restore backend yet.
It only needs a compact bounded move:
- keep recall rows source-labeled,
- add age/freshness grades,
- track peer/cwd/repo/authority drift,
- let stronger default actions decay visibly,
- and make “compare current basis” the common bridge from old memory to fresh action.

That is enough to make Schell's memory much smarter without freezing the final storage, restore, sync, or ranking architecture.
