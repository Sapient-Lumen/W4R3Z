# Research synthesis, pass XLV (2026-03-21)

This pass focuses on one bounded seam that Schell did not yet give its own surface:
**the current shell and terminal ecosystem keeps proving that failed-command recovery is not one thing. “Command not found”, “found but not invokable”, “wrong subcommand”, “missing package”, “profile/path mismatch”, “open the docs”, and “repair then rerun” are different operator moves, and Schell should stop letting them borrow one magical recovery glow.**

## 1) The oldest lesson is still the most important: preserve exact failure kind first

POSIX still gives the cleanest baseline here.
The `command` utility documentation preserves the old but vital distinction between exit code `126` (“found but could not be invoked”) and `127` (“could not be found”).
That split matters because “you typed a name that is absent”, “the file exists but is not executable”, “the interpreter is missing”, and “the loader/startup path is broken” are not the same repair story.

That is the first lesson Schell should keep from the past:
**failed-command recovery only gets better if the shell keeps exact failure identity before any advice layer starts guessing.** See: https://manpages.ubuntu.com/manpages/jammy/man1/command.1posix.html

## 2) Helpful command-not-found systems are real, but they are handlers, not truth

fish’s current `fish_command_not_found` docs are unusually honest about this seam.
When fish cannot find a command, it invokes a separate function.
That function can print guidance, often checks for a missing package, ships with OS-specific handlers, and can be replaced.

That is exactly the right mental model for Schell.
A missing-command explainer is a **handler family**, not the meaning of the failed command itself.
It may depend on distro state, package indexes, shell config, or local policy.
So it should be source-labeled and visibly weaker than exact shell lookup truth. See: https://fishshell.com/docs/current/cmds/fish_command_not_found.html

Homebrew’s current `Command Not Found` docs deepen the lesson.
They explicitly describe the feature as reproducing Ubuntu’s behavior for Homebrew users on macOS, install it via a shell hook, and say the handler uses `brew which-formula --explain` to print installation instructions when it finds a match.
Again, the important design steal is not “always suggest installs.”
It is **treat install advice as a separately installed repair provider with a named basis**, not as generic shell truth. See: https://docs.brew.sh/Command-Not-Found
See: https://docs.brew.sh/Manpage

## 3) The humane old correction model is still edit/abort, not silent retargeting

zsh’s spelling-correction docs remain a very good warning and a very good pattern.
When zsh thinks a word should be corrected, it asks.
The user can accept, reject, abort, or bring the line back for editing.
That still feels like the right shape for Schell.

A custom shell+terminal should absolutely steal the **reviewable correction** idea.
But it should refuse the dangerous part of the old folklore: silent retargeting from one executable/subcommand/path to another.
Correction is strongest when it returns the user to review, not when it quietly changes what “run” means. See: https://zsh.sourceforge.io/Intro/intro_16.html

## 4) Modern terminals are proving that repair affordances are great when they stay proposal-first

VS Code’s current shell-integration docs say Quick Fix scans command output and presents actions with a high likelihood of helping next.
Its built-in fixes include similar `git` subcommands, upstream push repair, link opening, and suggestions triggered by PowerShell `General` or `cmd-not-found` feedback providers.
The really valuable small detail is in “Run Recent Command”: holding Alt writes the text to the terminal **without running it**.

That is exactly the kind of move Schell should steal.
The most luxurious repair UX is often **insert-first, run-second**.
Users should be able to accept a correction, install command, or doc lookup as editable input before execution. See: https://code.visualstudio.com/docs/terminal/shell-integration

Microsoft’s current PowerShell feedback-provider docs reinforce the same direction.
PowerShell 7.4 introduced feedback providers as modules that can offer suggestions based on execution success or failure, and Microsoft’s docs explicitly note a command-not-found provider on Linux.
That is exciting, but it is also the warning:
**suggestion planes are becoming programmable subsystems.**
So Schell should keep provider identity, trigger type, and offer provenance visible instead of flattening everything into one “smart shell” voice. See: https://learn.microsoft.com/en-us/powershell/scripting/dev-cross-plat/create-feedback-provider?view=powershell-7.5

## 5) Package/install suggestion quality depends on freshness and platform fit

NixOS’s current stable release notes say the `command-not-found` package is now disabled by default because it works only for nix-channels-based systems and requires setup.
That is a superb humility lesson.
Even very useful missing-command helpers can become stale, backend-specific, or broken when the surrounding package model changes.

Schell should import that lesson directly:
- package/install offers need a visible provider source,
- freshness and platform-fit need to be explicit,
- and fallback behavior should degrade to explanation and search rather than overclaiming certainty. See: https://nixos.org/manual/nixos/stable/release-notes

## 6) The no-regret Schell move is a compact resolver witness family

A good v0 shell+terminal posture here is not a giant package-management brain.
It is a small exact shell truth plus a carefully bounded repair surface.

Schell should likely introduce:
- **resolver witnesses** for exact failure kind (`not_found`, `found_not_invokable`, `startup_bind_failed`, `subcommand_unknown`, `likely_typo`, `provider_stale`, ...),
- **repair providers** with visible source (`shell-static`, `local-index`, `package-manager`, `project-accelerator`, `remote-search`, ...),
- **offer ladders** that separate explain / reveal / copy / insert / stage / review-run / install / open-docs,
- and **freshness posture** so stale package indexes or repo-local accelerators stop pretending to be universal truth.

That would make Schell much better than classic shells at failed-command recovery while still preserving the single biggest historical lesson on this pass:
**recovery should feel brilliant, but the shell must never forget which part is exact failure evidence and which part is just a smart adjacent workflow.**
