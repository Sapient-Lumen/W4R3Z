# SlopOS datacube evaluation, pass CVI (2026-03-22)

This pass evaluates one narrower question against the current SlopOS archive:
**what does the companion already teach Schell about font fallback, glyph rendering, ligature posture, icon packs, and the danger of letting nearby display convenience outrank exact shell truth?**

The answer is consistent with one of the strongest SlopOS patterns in the whole archive:
**authority-bearing seams should stay simpler and more byte-honest than nearby presentation seams, while richer display remains allowed as an explicit weaker lane.**

## 1) D-NAMECERT still teaches the deepest lesson

The companion's string-profile boundary remains the best anchor.
D-NAMECERT keeps authority-bearing names on a narrow exact-byte lowercase-ASCII profile and refuses to import Unicode normalization, locale collation, confusable policy, or richer display semantics onto that seam.

That is not a claim that every Schell prompt or command line must be ASCII.
It is a design lesson:
**the closer a surface is to authority, identity, approval basis, or durable references, the less it should depend on renderer-local typography luck.**

Applied here:
- prompt icons are not durable identifiers,
- a nice ligature is not shell meaning,
- a glyph from a fallback font is not stronger than the exact text underneath,
- and one machine's visual alignment is not portable truth.

## 2) Capshell exactness keeps execution stronger than nearby rendering

The companion's capshell posture repeatedly prefers exact launch identity, exact reviewed basis, no hidden fallback, and smaller exact execution seams over surrounding convenience.
That pressure imports cleanly into terminal typography.

A visible prompt separator, a private-use-area icon, or a shaped glyph can all be useful.
But they should remain **render posture**, not execution identity.

So Schell should preserve:
- exact inserted or reviewed text,
- exact byte/grapheme reveal,
- and exact portable identifiers

as stronger than any renderer-local glyph outcome.

## 3) SlopOS’s preview/render boundaries fit this seam too

The companion keeps repeating a smaller pattern across preview, restore, extraction, and rendering work:
- preview is not open,
- restored is not live,
- nearby rendering is not the authority object,
- and convenient representation is not the exact subject.

Typography should import the same discipline.
A renderer can improve display.
A prompt theme can improve scannability.
A clipboard compatibility map can make pasted text friendlier elsewhere.
But none of those conveniences should silently replace:
- the exact shell text,
- the exact reviewed action basis,
- or the exact durable handle.

## 4) The companion-compatible shape is reassuringly small

Schell does **not** need a grand typography constitution to stay aligned with SlopOS.
It only needs a few bounded rules.

### A) Font/glyph witnesses stay render-local
Treat primary face, fallback source, symbol coverage, ligature posture, and synthetic style as explicit renderer posture.

### B) Exact text remains revealable
Any fancy display should keep exact text or exact bytes one gesture away.

### C) Prompt/theme icon packs stay presentation-only
They may help orientation, but they do not become object identity, authority, or execution proof.

### D) Copy/export substitutions are explicitly weaker
If clipboard/export behavior rewrites characters for compatibility, that should be named as a weaker lane than exact copy.

### E) Portability stays visible
A theme or prompt that depends on host-local font packs, fallback fonts, or private-use-area icons should confess that dependence instead of silently becoming the expected shell baseline.

## 5) Compact conclusion

The SlopOS-compatible answer is not “avoid beautiful text.”
It is:
**let Schell steal excellent typography, iconography, and shaping comfort, but keep exact text, authority-bearing identifiers, glyph fallback, and copy/export substitutions as separately named seams.**

That is a strong design-phase-safe move because it improves operator delight immediately while keeping the final font stack, icon policy, shaping backend, and prompt-theme ecosystem open.
