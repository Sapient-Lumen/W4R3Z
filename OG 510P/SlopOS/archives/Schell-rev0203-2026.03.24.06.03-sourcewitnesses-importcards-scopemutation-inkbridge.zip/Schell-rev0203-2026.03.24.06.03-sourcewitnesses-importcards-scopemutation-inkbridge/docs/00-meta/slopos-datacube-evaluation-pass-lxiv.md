# SlopOS datacube evaluation, pass LXIV (2026-03-22)

This pass evaluates one new companion import:
**Schell should absolutely gain reviewed resource-envelope witnesses, explicit payer/budget posture, and better execution accounting receipts, but SlopOS pressure says default-compartment launch state, explicit payer identity, live metering, and final receipts must stay separately admitted so resource truth never collapses into ambient host folklore.**

## 1) D-CAPSHELL already says launch meaning must not inherit hidden shell/session resource envelopes

The companion archive is unusually strong here.
`capshell-resource-envelope-posture-v0.md` says Phase 1 must not inherit a narrowed resource-controller envelope merely because the parent shell, wrapper, login profile, or service manager already had one.
Instead, launch should normalize to the default resource-controller envelope for the active execution compartment.
That is exactly the right Schell import.
A reviewed launch surface should say whether the operator is getting the default compartment envelope, an explicit transient override, or something unknown/degraded — not leave that hidden in the parent session.

## 2) SlopOS separately refuses inherited `ulimit` and inherited scheduling posture

The companion archive repeats the same lesson in other seams.
`capshell-rlimit-posture-v0.md` refuses inherited shell/session `ulimit` state as reviewed meaning and pins `RLIMIT_CORE = 0` as the portable crash-dump baseline.
`capshell-scheduling-posture-v0.md` likewise refuses inherited `nice` / scheduler-policy state and normalizes launch to a default non-real-time time-sharing posture with neutral nice on POSIX-like hosts.
That pushes Schell toward a stronger design rule:
resource-envelope review should not just mean “CPU and memory.”
It should also surface scheduling/core-dump posture when that affects the meaning of a launch.

## 3) D-BUDGET says payer identity is explicit and must not collapse into container or job membership

`budget-payer-semantics-v0.md` is even more important.
It says the resource principal stays separate from the execution subject, there is no portable ambient current payer, container/cgroup/job/subtree membership is not portable payer identity, and callee sponsorship must be explicit and transcript-visible.
That is a huge gift to Schell.
It means the shell+terminal does **not** need to guess who pays based on the current session, current working directory, current tenant, or current cgroup/job/slice.
Instead, it can expose one explicit payer/budget witness family and stay honest.

## 4) CH-BUDGET already gives Schell the shape of a redaction-safe budget witness

The companion archive also already has a compact budget descriptor shape.
`CH-BUDGET v0` carries `budget_id`, payer linkage via `meter_digest`, a closed `kind`, a bounded `limit`, an optional `scope`, and an optional `expiry`.
That is very close to the shell-side object Schell wants.
The key import is not “surface every meter implementation.”
It is “if a reviewed action burns an explicit budget, the shell should be able to show budget kind, limit, scope, and expiry without materializing secrets or inventing ambient sponsorship.”

## 5) CH-ACPOUT pressures non-authoritative, digest-safe receipts rather than grandiose completion claims

`CH-ACPOUT v0` is another sharp pressure source.
It is a non-authoritative outcome receipt, binds exact action/request digests, and carefully distinguishes outcome classification from effect metadata.
The security notes explicitly say receipts are not authorization evidence and do not by themselves prove downstream completion or current live state.
Schell should import that discipline wholesale.
A resource receipt should remain a bounded reviewed-action outcome and accounting artifact.
It should not silently turn into proof of current quota posture, current service liveness, or present grant state.

## 6) SlopOS's clean split suggests at least four separate shell-side objects

Putting those companion surfaces together suggests a clean Schell family:
- **launch envelope witness** — what default compartment and extra launch posture the command will enter,
- **budget/payer witness** — if a reviewed budget pays, what kind/scope/expiry it has,
- **live usage deck** — optional current accounting or pressure while the command or job still lives,
- **outcome receipt** — exact reviewed action outcome plus bounded accounting afterward.

That split matters a lot.
If Schell flattens those objects, it will recreate exactly the ambient-folklore problem SlopOS keeps refusing.

## 7) A compact v0 posture worth stealing

A good early Schell resource family should probably say:
- whether launch posture is default-compartment, explicitly overridden, or unknown,
- whether CPU/memory/IO/process-count/scheduling/core-dump posture is enforced, merely accounted, or unavailable,
- whether payer identity comes from an explicit budget or no explicit payer exists,
- whether live accounting is unavailable / partial / full,
- whether a limit event is advisory, guaranteed, or absent,
- and whether the final receipt is exact shell-owned outcome truth or a weaker provider-side accounting addendum.

That would make resource truth much more humane without forcing one final scheduler, cgroup, Job Object, or cluster substrate.

## 8) Decision-light next move

A strong next move is to define one **resource witness / budget envelope / receipt humility** family that proves:
- reviewed launch posture,
- explicit payer identity,
- live usage decks,
- and bounded final receipts
can coexist without turning Schell into a host-specific quota browser, an ambient billing plane, or a fake portability theater.

That keeps Schell ambitious while learning the right lesson from SlopOS:
**resource truth is welcome, but launch envelope, payer, live monitoring, and final receipt must stay separately admitted.**
