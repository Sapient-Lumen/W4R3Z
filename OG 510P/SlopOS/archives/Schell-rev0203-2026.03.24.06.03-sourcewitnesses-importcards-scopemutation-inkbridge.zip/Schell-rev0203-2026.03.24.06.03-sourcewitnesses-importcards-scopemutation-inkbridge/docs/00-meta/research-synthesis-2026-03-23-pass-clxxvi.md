# Research synthesis — 2026-03-23 — pass CLXXVI

This pass sharpens one fresh lesson from current terminal, shell-integration, and lifecycle docs:
**the most honest systems do not stop at `ready`; they distinguish first readiness from stable availability and they keep current status attributable to the generation it actually covers.**

## 1) VS Code already teaches that shell-aware readiness is something worth waiting for

VS Code documents that shell integration enables working-directory detection, command detection, decorations, and navigation.
Its recent release notes then say terminal-tool flows may wait for shell integration activation with a configurable timeout.

That is already a practical stability lesson.
A launched terminal and even an interactive shell are not yet the same thing as a settled shell-aware lane.

## 2) Ghostty and fish both show that prompt truth must be reacquired, not assumed once

Ghostty ties prompt jumps, command-output selection, same-cwd new terminals, and prompt click movement to shell integration.
It also explicitly says that if you switch shells inside Ghostty you must manually source the shell-specific integration again.
Its 1.3.0 release notes then call out more accurate OSC 133 handling and better behaviors at the active prompt.

fish 4.5.0 sharpens the same lesson from another angle: it now reports cwd on every fresh prompt and reports prompt end, specifically to fix stale cwd after child processes such as ssh.

That means first prompt truth is not the end of the story.
Fresh prompt semantics must sometimes be reasserted and then allowed to settle.

## 3) Kubernetes keeps `ready now`, `available after dwell`, and `observed generation` distinct

Kubernetes now documents `.spec.minReadySeconds` for StatefulSets as the minimum number of seconds a newly created Pod must be running and ready without container crashes before it is considered available.
Separately, Pod docs now describe `status.observedGeneration` so current status can be tied to the generation it actually reflects, including cases where indirect status still belongs to the previous sync loop.

That is an excellent tiny lesson for Schell.
A lane may be ready now, but the stronger claim the operator wants is often closer to:
- ready and still holding,
- status still belongs to generation N,
- or a newer generation is already in flight.

## 4) systemd keeps reload cycles explicitly attributable

systemd's `sd_notify` family keeps `READY=1` separate from `RELOADING=1`, and `Type=notify-reload` services pair reload notices with `MONOTONIC_USEC=` so reload cycles can be synchronized and later matched to a concrete moment.

That is exactly the kind of small attribution seam Schell should copy.
When a lane is resyncing, reloading, or reacquiring semantics, the shell+terminal should be able to say so explicitly rather than leaving a sticky `ready` myth in place.

## 5) The no-regret Schell move is a tiny stability strip and generation lamp

Putting these together suggests a better next move than wider replay authority, smarter nearby action magic, or a larger lifecycle browser.
Schell should add:
- a tiny **stability strip** for newly ready, restored, resynced, or reloaded rooms and lanes,
- and a compact **generation lamp** for command-facing objects.

They should say:
- whether readiness just arrived or is still warming toward stable,
- whether a dwell-to-stable claim is actually proven,
- whether current status still belongs to the observed generation in view,
- whether reload/resync drift is in flight,
- and what the strongest honest next move is now.

## 6) Compact conclusion

VS Code already waits for shell integration activation in some flows.
Ghostty and fish both show that prompt/cwd semantics must be reacquired and refreshed, not assumed forever.
Kubernetes keeps `ready` separate from `available after dwell` and also attributes status to an observed generation.
systemd keeps reload cycles explicitly attributable with `RELOADING=1` and `MONOTONIC_USEC=`.

So the next no-regret Schell seam is not a bigger lifecycle engine.
It is **stability strips, generation lamps, and warming-truth humility** so a prompt-ready lane can cheaply say whether it is merely ready now, whether it has held long enough to trust stronger convenience, and whether current status still belongs to the generation the operator thinks it does.
