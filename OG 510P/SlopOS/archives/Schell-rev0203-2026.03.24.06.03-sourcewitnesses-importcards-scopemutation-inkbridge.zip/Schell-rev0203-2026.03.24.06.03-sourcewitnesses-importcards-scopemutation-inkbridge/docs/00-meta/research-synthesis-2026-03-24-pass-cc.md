# Research synthesis — 2026-03-24 — pass CC

This pass sharpens another old shell lesson that still matters for a brand-new shell+terminal:
**file-backed helper loading is powerful, but it should not silently erase the difference between executing a file, sourcing it into the current shell, autoloading a function, importing a module, layering an overlay, and the exact reviewed command basis that follows.**

## 1) Current shells already prove that “load this file” is not one thing

Bash still states the problem most plainly.
Its `.` builtin reads and executes commands from a file in the current shell context.
By contrast, when Bash is invoked with a shell script file, it reads commands from that file and then exits.
Bash functions sharpen the same lesson because they execute in the current shell context with no new process created.
So even classic Bash already distinguishes child execution from current-shell mutation.

zsh extends the lesson into discovery.
Its autoload docs say an undefined function marked with `autoload` is resolved by searching `fpath` the first time the function is executed.
The builtin docs then warn that `autoload` does not ensure what shell options are set while the file loads or executes unless you deliberately pair it with `emulate`.
That is an unusually direct admission that file-backed helper loading needs visible baseline, path, and scope posture.

fish keeps the seam clean.
Its `source` docs say a file is evaluated in the current shell as a new block of code rather than in a new process, and that relative paths are resolved from the working directory rather than through `PATH`.
But the same docs say `source` creates a new local scope, so `set --local` inside that block does not affect enclosing scope.
Meanwhile the language docs and tutorial say fish autoloads functions by command name from `$fish_function_path`, with changed definitions reloaded later.
So fish proves that sourced mutation and autoload discovery should not share one lazy import story.

PowerShell gives perhaps the clearest modern split.
The dot-sourcing operator runs a script in the current scope, adding functions, aliases, and variables to that scope.
But `Import-Module` imports exported module members only into the current session, and the scopes docs say modules have their own session state and module-specific hierarchy of scopes.
That makes module import explicitly weaker and differently shaped than dot-sourcing.

Nushell points toward the most structured future.
Its docs distinguish `source`, `source-env`, `use`, and `overlay use`.
`source-env` brings environment from a source file into the current environment.
`use` imports definitions from a module, and the module docs say `use` also runs the module's `export-env` block and merges that environment into the current scope.
`overlay use` activates those definitions and environment in a named layer that can later be hidden.
Nushell's static/parse-time notes also remind us that these commands are not mere runtime sugar; import form and parse-time availability materially change what the shell can prove.

## 2) The lesson Schell must learn from the past

The historical mistake is not only that users confuse `source` and `run`.
The deeper mistake is **flattening helper loading into one ambient import myth**:
- child-shell execution,
- current-shell sourcing,
- autoload-by-name from a search path,
- module import with exported members,
- environment-only import,
- overlay/layer activation,
- and the exact reviewed basis after those changes.

Once those collapse, four bad things happen:
1. a later command looks self-explanatory even though a prior helper-loading step changed its meaning,
2. search-path-based helper discovery becomes a second hidden execution plane,
3. transcripts preserve text but forget whether current scope was mutated,
4. and imported module or overlay state quietly impersonates exact reviewed basis.

## 3) The nifty ideas worth stealing are loader-shaped, not package-shaped

The current ecosystem points to several low-regret steals:
- load-form chips (`execute`, `source`, `autoload`, `module`, `overlay`, `env-only`),
- scope badges (`child shell`, `current shell`, `module state`, `overlay-local`, `current env only`),
- path/source notes (`exact path`, `fpath`, `$fish_function_path`, `$PSModulePath`, `$NU_LIB_DIRS`),
- export posture cards (`definitions only`, `env only`, `definitions + env`, `full current-scope code`),
- reversible layer receipts for overlay hide or session-end rollback,
- and exact source reveals that let an operator inspect the loaded file/definition before later commands claim fresh review.

None of those requires Schell to freeze one module language or one startup-file constitution.
They simply make the helper-loading story smaller and more honest.

## 4) The super-awesome move here is “show the membrane”

The unusually delightful move would be to show, in one tiny revealable card:
- what the operator typed,
- what exact file/definition the shell loaded,
- which scope changed,
- whether the change is reversible,
- and whether later reviewed command text depends on that imported posture.

That is the right kind of luxury because it improves trust while preserving deferral.
It says “here is the helper membrane” instead of “the shell already knows what you meant.”

## 5) Compact conclusion

Current official docs line up well here.
Bash separates execute-file, source-file, and current-shell functions.
zsh separates autoload discovery from named baseline control.
fish separates source, startup files, and autoload-by-name.
PowerShell separates dot-sourcing from module import and module session state.
Nushell separates source, source-env, use, and overlay use.

So the next low-regret Schell seam is **source witnesses, import cards, and scope-mutation humility** so helper-loading comfort stays powerful without becoming hidden shell truth.
