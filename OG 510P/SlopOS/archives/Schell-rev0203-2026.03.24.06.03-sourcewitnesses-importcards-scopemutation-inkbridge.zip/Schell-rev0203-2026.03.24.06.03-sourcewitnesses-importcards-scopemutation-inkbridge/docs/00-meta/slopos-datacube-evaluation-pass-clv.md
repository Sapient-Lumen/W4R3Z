# SlopOS datacube evaluation — pass CLV

This pass asks a narrower companion-safe question than “how should Schell handle drag/drop?”
The better question is:
**how should Schell treat the landing zone of a dropped object so prompt insertion, chrome launch, import/attach, and remote transfer stay visibly different routes?**

## 1) SlopOS keeps launch, open, and materialization on different seams

Even while still in design phase, SlopOS keeps a sharp boundary between mediated launch/open, explicit file or document persistence, and stronger import/materialization flows.
That already tells Schell something useful.
A dropped object that lands on a terminal chrome surface should not silently become prompt text, and a dropped object that lands on a prompt should not silently become a durable imported object.

The route should be chosen and named.

## 2) SlopOS OpenURI and file/document posture warn against route laundering

SlopOS explicitly refuses to let generic URI launch quietly mint durable local-object truth.
That is exactly the right companion pressure here.
A shell+terminal should not let “drop this thing over here” flatten open, launch, import, attach, and transfer into one ambient convenience story.

If Schell wants to stay companion-safe, landing-zone comfort should still preserve route-family truth.

## 3) ViewFS strongly separates offers, imports, and later apply

ViewFS keeps import, export, transfer, open-in-place, promised-file materialization, and later apply/result surfaces distinct.
That is a nearly perfect teacher for Schell here.
A dropped file offered to a prompt, a dropped folder used to seed a new pane, and a dropped object attached for later review should not share one receipt shape.

The route matters as much as the payload.

## 4) Steward keeps chooser returns exact instead of stuffing text back into the world

Steward’s chooser posture argues that visible text, pickers, and context discovery should resolve to exact selectors or anchors rather than just pasting guessed text back into a shell.
That pressure transfers cleanly to Schell.
A landing zone should be able to return an exact route like `new-pane-here`, `attach-candidate`, or `delegated-open` instead of hiding everything behind prompt insertion.

That is how the shell stays luxurious without becoming folklore.

## 5) Helm pressures typed movement and exact routes

Helm’s exchange posture is explicit that paste, drop, share, attach, import, export, and object handoff should compose through typed packets and routes instead of helper magic.
That strongly suggests Schell should record where a drop landed and what exact route family was chosen.

This is especially important when a local drag gesture can widen into a remote upload offer or delegated host open.

## 6) What Schell should steal now

Schell should steal several excellent ideas, but import them under stronger honesty:
- drop a folder onto a new-surface affordance to open a new tab/pane/window rooted there,
- drop a file onto a review harbor to attach or inspect it,
- drop a file onto a live remote line to offer upload rather than silently start it,
- and keep prompt-local insertion as just one possible route rather than the universal route.

## 7) What Schell should refuse now

Schell should refuse:
- treating every dropped object as prompt-ready text,
- treating transformed path text as canonical object identity,
- treating chrome-launch drops as hidden shell input,
- and treating remote-upload-capable drops as ordinary local insertion with extra glitter.

## 8) Compact conclusion

The companion-safe answer is not to make drag/drop ceremonial.
It is to make **landing-zone truth stronger than gesture folklore**.
If Schell can say what arrived, where it landed, what route family that target supports, and what later receipt proves actual launch/import/attach/transfer, it can steal a lot of modern target-sensitive comfort while staying aligned with SlopOS exactness during the design phase.
