# Research synthesis, pass LX (2026-03-21)

This pass keeps one fresh design rule in focus:
**Schell should absolutely steal shareable command chapters, replayable casts, and live session viewing — but only if local scrollback, local capture, durable replay artifacts, published links, and live shared control never collapse into one flattering "share" story.**

This seam matters because the luxury is real.
Operators do need to hand somebody a failure chapter, publish a tiny reproducible demo, keep a redacted replay artifact for later, or let a teammate look in on a live session.
The current ecosystem proves that these moves can feel delightful.
But it also keeps reminding us that review buffers, recordings, live streams, web permalinks, and interactive co-viewing are not interchangeable.
Schell should steal the good parts while keeping capture scope, publication target, and residual authority explicit.

## 1) WezTerm proves that local scrollback is useful review state, not a durable artifact

WezTerm's scrollback docs are a healthy first anchor.
They describe a searchable scrollback buffer with a configurable size limit, and they bluntly note that clearing scrollback discards it with no undo.
That is a terrific Schell clue.
A scrollback buffer is a review convenience.
It is not yet a chapter export, a replay artifact, or proof that somebody else can recover the same thing later.
Schell should keep **review buffer**, **exact export**, and **published artifact** separately named.
See: https://wezterm.org/scrollback.html

## 2) Warp proves that chapter publication can be luxurious when it is explicit, selective, and obviously networked

Warp's current block-sharing docs are unusually helpful here.
They say block sharing is explicitly opt-in, sends command information to Warp's server, and lets the operator customize which parts of a finished block are shared — command, output, prompt, and so on — before creating either a permalink or an embed.
That is a wonderful steal for Schell.
The luxury is not just "copy transcript".
It is **selective publication** with a visible hosting destination and a visible artifact shape.
Schell should steal the selectivity and the explicit publication step while remaining stricter about review basis, redaction posture, and hosting location.
See: https://docs.warp.dev/terminal/blocks/block-sharing

## 3) Warp also proves that live session sharing is a different lane from published chapter artifacts

Warp's current session-sharing docs for agents make another valuable distinction.
A sharer can choose whether the shared session starts from full scrollback, no scrollback, or a specific block; viewers can join from the desktop app or a web viewer; and live viewers may receive view or edit permissions in session-sharing flows and CLI flags.
That is exactly the kind of separation Schell should preserve.
A **live shared session** is not merely a permalink to a finished chapter.
It has ongoing visibility, possible steering authority, and a different residue story.
The artifact lane and the live lane should stay separately named even if both are "sharing."
See: https://docs.warp.dev/agent-platform/local-agents/session-sharing
See: https://docs.warp.dev/reference/cli/cli

## 4) asciinema proves the power of explicit recording, explicit upload, and explicit local-vs-remote streaming

asciinema's current docs are full of exactly the right lessons.
Its 3.0 change made recording and uploading separate steps: `rec` no longer uploads, and publication uses an explicit `upload` command.
The getting-started docs also distinguish remote streaming from purely local streaming, where `asciinema stream -l` runs a local web server and sends no data anywhere.
Those are excellent Schell clues.
Recording, publishing, and relaying are different actions.
The system should say which one happened.
See: https://blog.asciinema.org/post/three-point-o/
See: https://docs.asciinema.org/getting-started/

## 5) asciinema also proves that replay artifacts can stay text-shaped — and that input capture is a stronger act than output capture

The asciinema FAQ says recordings are newline-delimited JSON files and that by default asciinema records only terminal output, not key presses.
It also says capture-input is opt-in because it is effectively keylogging scoped to that shell instance / tab.
This is a powerful Schell lesson.
A replayable cast can still be text-like and editable.
But the moment input capture enters the picture, the privacy and secret posture becomes much stronger.
So Schell should distinguish **output replay artifact**, **input-bearing replay artifact**, and **live mirrored session** instead of treating them as one recording feature.
See: https://docs.asciinema.org/faq/
See: https://docs.asciinema.org/manual/server/api/

## 6) tlog proves that audit recording is a different product shape with different truth and failure modes

Red Hat's tlog docs describe session recording as a detailed, unchangeable record for auditing and investigation, with JSON recordings and playback via `tlog-play`.
They also say input recording is disabled by default for security reasons.
More importantly, the docs list operational limitations: root can bypass recording, journal viewing can create a logging loop, recordings can be lost on reboot if journald is in-memory, and remote sessions must be recorded on the remote host.
That is extremely valuable pressure for Schell.
An **audit recording** is not just a prettier replay artifact.
It has different trust claims, different storage assumptions, and different failure modes.
See: https://docs.redhat.com/en/documentation/red_hat_enterprise_linux/10/html/managing_idm_users_groups_hosts_and_access_control_rules/configuring-session-recording-by-using-cli
See: https://docs.redhat.com/en/documentation/red_hat_enterprise_linux/8/html-single/recording_sessions/index

## 7) util-linux `script` proves that raw terminal capture is even stronger and even riskier

The `script(1)` manual says terminal data are stored in raw form and that timing logs can be used to replay sessions later.
It also warns that logging input via `--log-in` or `--log-io` can capture security-sensitive information such as passwords regardless of terminal echo state.
That is another excellent Schell clue.
A raw capture lane is useful, but it is materially stronger than a visible chapter export or a redacted publication card.
Schell should keep **raw capture** clearly above ordinary share/export moves on the risk ladder.
See: https://man7.org/linux/man-pages/man1/script.1.html

## 8) The dangerous thing to refuse: one generic “share terminal” verb

The ecosystem now shows at least five different things that are easy to flatten into one story:
- local scrollback review,
- exact chapter export,
- replayable cast artifact,
- published web permalink/embed,
- and live shared session with ongoing visibility or steering.

Those are adjacent.
They are not the same.
Schell should not let a single toolbar icon or context menu label smuggle them together.

## 9) The stealable move: share witnesses, replay capsules, and publication ladders

The best decision-light move now looks like this:
1. introduce a **share witness** family,
2. keep **review buffer**, **exact export**, **replay capsule**, **published chapter**, and **live share lane** separately named,
3. let a publication card show hosting destination, visibility, selected included parts, and revocation posture,
4. let a replay capsule show whether it is output-only, input-bearing, raw PTY-ish, or audit-grade,
5. keep local/LAN/no-cloud share distinct from remote relay/publication,
6. prefer redaction-visible and digest-visible publication receipts over silent transcript leakage,
7. keep live share permissions explicit (view / inspect / steer / edit),
8. and keep “somebody could watch this” smaller than “somebody has durable authority over the underlying session or objects.”

That would make Schell feel much more capable without freezing one hosting backend, one sync product, one cast format, one player stack, or one enterprise-sharing architecture.

## 10) A compact first proving slice

A compact proof could show:
- one review-only local chapter clip,
- one exact export card to a local artifact,
- one replay capsule that says output-only,
- one stronger input-bearing capsule with a louder warning,
- one published chapter card with selected parts and a visible host destination,
- one local-only or LAN-only live share offer,
- one remote/public relay offer with a clearer warning,
- one live session share with explicit view versus steer permissions,
- one redaction-first refusal for secret-bearing publication,
- and one revocation / unpublish receipt that is weaker than “all copies everywhere disappeared.”

That is enough to learn a lot while keeping the big architecture decisions open.
