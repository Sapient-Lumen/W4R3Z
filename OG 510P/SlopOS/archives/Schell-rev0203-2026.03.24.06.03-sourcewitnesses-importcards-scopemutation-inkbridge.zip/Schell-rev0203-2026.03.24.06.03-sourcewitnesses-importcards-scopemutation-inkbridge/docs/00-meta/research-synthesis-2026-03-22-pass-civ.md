# Research synthesis, pass CIV (2026-03-22)

This pass keeps one fresh rule in focus:
**a shell+terminal gets much more trustworthy when requested size, realized pixels, viewport cells, cell metrics, mux sizing policy, and reflow posture are treated as different truth families instead of one giant “the terminal is this big” blur.**

The current ecosystem keeps pointing in the same direction.
kitty's graphics protocol docs still tell clients to obtain both pixel size and cell rows/columns, and even call out that some terminals incorrectly return zero pixel dimensions.
WezTerm separates pane geometry from window geometry, exposes pane `cols` / `viewport_rows` / `scrollback_rows`, and separately exposes window pixel width/height and DPI.
WezTerm's newer `window_content_alignment` option is an especially useful tell: modern terminals sometimes have leftover gap because window size is not an exact multiple of cell size.
Ghostty keeps geometry choices explicit too: initial window width/height are in grid cells, split resizing is in pixels, and quick-terminal sizing can mix percentages and pixels.
tmux then adds the classic multiplexer warning by letting window size follow the largest client, smallest client, latest client, or a manual policy.
VS Code's terminal history shows the other side of the seam: local reflow is real and useful, but it is still a display behavior, not proof that arrival shape and current viewport shape are the same thing.

## 1) Geometry has more layers than terminal folklore admits

A lot of shell/terminal lore still acts as though geometry is simple:
- there are rows and columns,
- perhaps a window size,
- perhaps a font size,
- and the rest is implementation detail.

The current docs do not support that simplification anymore.
The system now routinely cares about:
- outer window pixels,
- text-area pixels,
- viewport cells,
- scrollback extent,
- cell width and line height,
- DPI,
- quick-terminal percentages,
- split-resize units,
- and multiplexer-selected size policy.

That means Schell should stop pretending there is one stable “terminal size” object.

## 2) The best current terminals already confess size mismatch

WezTerm's `window_content_alignment` is a particularly useful signal.
If the window is not a multiple of cell size, there can be an extra pixel gap, and the configuration controls where that gap lives.
That is a direct confession that outer-window geometry and inner-cell geometry are different surfaces.

Ghostty's current docs confess the same thing in another way.
Initial window sizing is expressed in grid cells by default, but window managers may clamp or override the request, and there is even a current GTK bug note saying decorations can make the realized grid differ from the configured size.
That is exactly the sort of honesty Schell should steal.

## 3) Pane geometry and window geometry are already separate objects

WezTerm makes this especially explicit by returning different structures:
- pane dimensions identify `cols`, visible `viewport_rows`, and total `scrollback_rows`,
- while window dimensions separately report pixel width, pixel height, and DPI.

That is an excellent design clue.
A pane does not need to pretend it knows the whole window.
A window does not need to pretend it knows the whole reflow story.
And neither of them should automatically claim to be the canonical geometry for exact command/output truth.

## 4) Multiplexers prove that hidden geometry ownership is still a real failure mode

The tmux manual remains a perfect warning.
Window size can follow the largest client, the smallest client, a manual size, or the latest active client.
That means “why is my pane this size?” may have an answer that lives outside the currently visible window.

This is exactly the kind of old failure that luxury terminals often hide.
A shell+terminal feels magical until operators cannot explain why rows vanished, why a split stopped resizing, or why a restored workspace came back cramped.
Schell should not repeat that mistake.

## 5) Reflow is worth stealing, but it should stay visibly local

VS Code's terminal reflow note is still useful because it says the quiet part aloud: the terminal wraps and unwraps lines when it is resized horizontally.
That is a great browsing comfort.
But it also means that what the operator sees after a resize may no longer match the line breaks from the original arrival shape.

So the right import is not “avoid reflow.”
It is:
**make reflow luxurious, but keep it weaker than exact output truth.**

That means copied excerpts, captured rows, and replay bundles should know whether they came from:
- exact chapter/output truth,
- or a locally reflowed viewport.

## 6) The SlopOS-friendly answer is smaller than a full layout engine

This seam does not require Schell to choose one final window manager story, one final split engine, or one final media layout protocol.
It only needs to name the geometry stack clearly.

### Must-learn failure families
- requested size silently overclaiming realized size,
- pane rows/cols silently overclaiming window pixels,
- window pixels silently overclaiming text-area pixels,
- mux-selected size silently overclaiming local intent,
- and reflowed local view silently overclaiming exact output shape.

### Stealable moves
- requested-vs-realized geometry chips,
- explicit gap/confession badges,
- mux-policy badges,
- pixel-aware media placement,
- resize receipts,
- and reflow badges on copied/saved excerpts.

### No-regret design move
Add a **geometry witness** family so Schell can name:
- `requested_geometry`,
- `window_pixel_rect`,
- `text_area_pixels`,
- `viewport_cells`,
- `cell_metric_posture`,
- `resize_owner`,
- `mux_policy`,
- and `reflow_posture`.

That is enough structure to make layout comfort feel excellent without freezing the final pane engine, workspace model, media protocol, or resize/reflow semantics.

## 7) Compact conclusion

One of the smartest moves available right now is:

**make geometry first-class and delightful, but keep requested size, realized pixels, viewport cells, cell metrics, mux ownership, and reflowed local view separately named.**

That lets Schell steal some of the best modern terminal ideas without letting resize comfort or rich layout accidentally impersonate exact shell truth.
