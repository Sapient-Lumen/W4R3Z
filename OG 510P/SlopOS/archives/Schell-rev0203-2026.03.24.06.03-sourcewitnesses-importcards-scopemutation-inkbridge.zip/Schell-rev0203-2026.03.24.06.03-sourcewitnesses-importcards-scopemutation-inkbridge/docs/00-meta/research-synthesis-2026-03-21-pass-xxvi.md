# Research synthesis, pass XXVI (2026-03-21)

This pass keeps another design rule in view:
**visible objects should become much smarter without letting clicks, previews, or helper choice impersonate reviewed authority.**

The current terminal landscape keeps converging on a useful split.
The best tools do not merely make paths clickable.
They distinguish among:
- detecting the object,
- resolving it relative to shell truth,
- opening or revealing it,
- inserting it back into input,
- and sometimes rendering it inside the terminal.

That is an excellent clue for Schell.

## 1) Open, file-open, and directory-reveal are worth keeping separate

The XDG OpenURI portal explicitly separates `OpenURI`, `OpenFile`, and `OpenDirectory`.
It also states that `file://` URIs are not supported by `OpenURI`; local files should use `OpenFile` instead.
`OpenDirectory` is specifically about opening the containing directory, possibly selecting the item.
That is one of the strongest current arguments for Schell to keep reveal distinct from open.
See: https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.OpenURI.html

## 2) Exact working-directory-aware file resolution is still a brilliant idea

iTerm2 semantic history remains a sharp terminal move.
Cmd-click can open a file, and iTerm2 tracks the current working directory for each line to help find files.
That is a wonderful clue for Schell object cards: visible file refs should resolve against exact chapter/ground truth rather than dumb text heuristics alone.
See: https://iterm2.com/documentation-preferences-profiles-advanced.html

## 3) Link detection should prefer typed actions over generic clicks

VS Code's terminal basics show a clean action ladder: URLs open with the standard handler, file links that are verified to exist open in the editor, and folder links open a new window at the folder.
That is exactly the kind of explicit typed-object routing Schell should steal instead of one generic smart-click action.
See: https://code.visualstudio.com/docs/terminal/basics

## 4) Selection that lands back into input is a powerful pattern

kitty's hints mode is especially strong here.
It can select visible paths and filenames and insert them into the terminal for the next command; it can also open file+line targets in an editor, and it can act on hyperlinks explicitly marked by the program.
That shows how a shell+terminal can be much smarter about visible objects without immediately launching them.
See: https://sw.kovidgoyal.net/kitty/kittens/hints/

## 5) Fast local file picking with previews is worth stealing carefully

kitty's choose-files kitten is effectively a keyboard-first file chooser with file-type filtering, icons, and content previews.
The lesson is not “build a giant file manager in the terminal.”
It is that Schell could offer a very fast explicit chooser/reveal layer while still keeping preview and open as separate choices.
See: https://sw.kovidgoyal.net/kitty/kittens/choose-files/

## 6) Rich in-terminal file opening is powerful and needs honesty

Warp's Files & Links support opens files, folders, and URL links found in blocks, and Warp parses relative and absolute file paths plus line/column formats.
Warp also has a Markdown Viewer that can open local markdown files in a split pane and lets shell blocks in markdown be inserted into terminal input.
That is a great clue for Schell: rich local viewers can be excellent, but insert-into-input is safer than hidden execution and remote support gaps matter.
See: https://docs.warp.dev/terminal/more-features/files-and-links ; https://docs.warp.dev/terminal/more-features/markdown-viewer

## 7) A compact Schell v0 cluster is strong

A decision-light first cut probably needs only:
- one **object-card** family,
- one exact **inspect / reveal / open / safe-open / insert / attach** ladder,
- one **working-directory / chapter-ground resolver**,
- one **metadata-safe preview** default,
- one **exact-reveal hold** instead of approximate fallback,
- and one **safe-open downgrade** for suspicious/imported objects.

## 8) Decisions intentionally kept open

This pass does **not** freeze:
- one preview engine,
- one markdown/PDF/image viewer stack,
- one helper-selection policy,
- one quarantine backend,
- one doc-handle model,
- or one omniscient object browser.

The no-regret move is narrower:
**make visible objects typed, exact-ref-bound, and stage-friendly, while keeping reveal, open, safe-open, insert, and attach clearly distinct.**
