# Research synthesis — 2026-03-23 — pass CXCII

This pass sharpens one smaller lesson from current prompt ecosystems:
**transient prompts and compact old-history renders are worth stealing, but they should remain explicit historical renderings rather than quietly recomputing what the shell supposedly knew.**

## 1) fish makes the key split explicit: live prompt render versus final historical render

fish now supports transient prompts by re-running prompt functions with `--final-rendering` before a command line is pushed to scrollback.
Its prompt model is also unusually clear that `fish_prompt`, `fish_right_prompt`, and `fish_mode_prompt` are separate functions.

That means one important design lesson is no longer speculative:
modern shells already accept that **the live prompt and the historical prompt left behind after Enter can be different objects**.

## 2) Powerlevel10k proves the product value of compaction

Powerlevel10k says transient prompt trims down every prompt when accepting a command line and explicitly highlights an operator benefit: easier copy-paste from scrollback.
That is a superb stealable idea for Schell.

The important catch is that copy-friendly old prompts are still history packaging.
A neat compact residue is not the same thing as a fresh status oracle, a fresh account badge, or a fresh cwd/environment truth source.

## 3) Starship keeps prompt families separate enough to avoid one old-prompt myth

Starship's docs are helpful because they keep right prompt and continuation prompt as distinct prompt-wide surfaces.
The continuation prompt is explicitly its own thing and is even restricted to a literal string.

That pushes Schell toward a better split than “prompt got smaller after run.”
Historical prompt compaction should be able to say:
- what stayed from the left prompt,
- what right-prompt context was omitted or salvaged,
- and whether multiline continuation residue still matters in history.

## 4) The hidden trap is recomputation

Once a shell can redraw old prompts, the dangerous shortcut is obvious: just ask the current world again and paint something that looks right.
fish's `--final-rendering` hook is powerful precisely because it invites explicit last-moment shaping.
So Schell needs one stronger local rule:
**final historical rendering should freeze facts already held at accept time, not silently recompute late-changing context into history.**

Otherwise compact prompt history becomes a fresh live-state myth wearing historical clothing.

## 5) The no-regret Schell move

Schell should add one compact witness family for transient prompt receipts:
- live prompt shape,
- final render class,
- frozen fields,
- omitted fields,
- history-copy posture,
- and recompute posture.

That is enough to steal transient prompt delight, copy-friendly scrollback, right-prompt salvage, and multiline continuity chips without choosing one final prompt DSL, theme engine, or history renderer too early.

## 6) Compact conclusion

Current shells and prompt engines already agree on the exciting part: old prompts can be compacted, and that is often a better product.
The smaller discipline they still leave undernamed is what exactly stayed frozen and what got dropped.

So the next low-regret Schell seam is **transient prompts, final rendering, and history-chip humility**.
