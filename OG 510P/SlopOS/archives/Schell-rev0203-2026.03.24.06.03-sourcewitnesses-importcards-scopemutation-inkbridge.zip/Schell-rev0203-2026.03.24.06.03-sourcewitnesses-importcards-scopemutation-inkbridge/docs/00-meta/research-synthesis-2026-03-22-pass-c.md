# Research synthesis, pass C (2026-03-22)

This pass asks one narrower question:
**what should Schell learn from the long mess of terminal keyboard/input handling without freezing one final terminal protocol, line editor, mux bridge, or remote helper stack too early?**

The answer is now crisp enough to archive:
**Schell should treat keyboard/input transport as its own witness family. Text input, non-text key events, negotiated key-encoding mode, mux/remote translation, and recovery-safe fallback should remain separately named.**

## 1) The historical wound is real: terminals still blur too many distinct keys together

The ecosystem has spent decades living with ambiguous byte streams.
Legacy terminal input often forces applications to infer whether a byte sequence meant:
- a plain key,
- an escape-prefixed modified key,
- a function-key sequence,
- or a slow operator pressing Escape and then another key.

That is why current systems still carry things like escape timers, modified-key encodings, compatibility shims, and opt-in richer protocols.
So the lesson for Schell is not “pick the coolest key protocol.”
The lesson is: **never let key transport ambiguity stay invisible once richer editor/prompt/workflow UX depends on it.**

## 2) kitty’s protocol proves the right shape: progressive enhancement, detection, and explicit event classes

The kitty keyboard protocol remains one of the best current examples because it is explicitly opt-in and progressively enhanced.
Applications can request stronger reporting incrementally, detect support, and ask for things like:
- escape-code disambiguation,
- repeat/release events,
- alternate/base-layout key reporting,
- or even “report all keys as escape codes.”

That does not mean Schell should blindly adopt kitty verbatim.
It does mean Schell should copy the construction pattern:
- richer input modes are requested,
- stronger reporting is detected,
- mode changes are queryable,
- and recovery remains possible when a program crashes or forgets to reset modes.

## 3) CSI-u and modifyOtherKeys are useful pressure, but also historical warnings

The current docs are unusually honest here.
WezTerm explicitly says CSI-u style encoding is not recommended as a default because it changes behavior incompatibly and applications cannot detect or request it.
kitty’s own docs go further and say xterm `modifyOtherKeys` should not be used because it still does not solve important problems such as release events, `Esc` ambiguity, and robust state management.
And iTerm2 now says CSI-u mode is no longer recommended and applications should implement the kitty key reporting protocol instead.

That gives Schell a strong negative rule:
**do not let an undetectable or half-detectable keyboard mode become invisible foundation truth.**

## 4) The old protocol problem is not only modifiers — it is also meaning lanes

A modern shell+terminal really wants to distinguish at least:
1. text input that should land in the buffer,
2. non-text navigation/edit keys,
3. shortcut matching against shifted/base-layout keys,
4. repeat and release events,
5. terminal-local keybindings,
6. shell/editor bindings,
7. and fallback synthetic behavior.

Those are different meaning lanes.
Collapsing them into “the terminal got a key” is exactly how prompt-click editing, predictive acceptance, modal bindings, and richer workflows become fragile.

## 5) tmux and remote paths prove the downgrade story matters as much as the native story

Even when the local terminal is rich, the actual path may pass through tmux, SSH, ConPTY, or other adapter layers.
The tmux manual is especially useful because it names `extended-keys`, admits multiple reporting formats (`csi-u` and `xterm`), and still carries `escape-time` because escape-prefix ambiguity never fully disappeared.
That means a great shell+terminal cannot merely say “supports enhanced keys.”
It needs to say:
- who requested them,
- which format is active,
- which hop translated them,
- and what weaker fallback is currently in effect.

## 6) Layout, IME, and platform-local input are part of the same seam

Current terminal docs also remind us that input is not just ASCII plus modifiers.
kitty’s alternate-key reporting explicitly exists to help shortcut matching across shifted keys and non-standard keyboard layouts.
Ghostty’s release notes around Kitty Keyboard regressions and IME fixes show that this seam breaks in practice whenever terminals or editors treat keyboard transport as a solved problem.

So Schell should avoid a naive “one keycode in, one meaning out” story.
The safer rule is:
**keep physical/layout-aware input evidence, emitted bytes, editor binding, and later reviewed action separately named.**

## 7) The safe steal is smaller than a final protocol commitment

The no-regret import is one explicit **key transport witness** family that can say:
- `input_kind` — text / non-text / mixed / unknown
- `transport_family` — legacy / xterm-modifyOtherKeys / csi-u / kitty / win32-input / unknown
- `negotiation_posture` — default / requested / accepted / forced / helper-bridged / unknown
- `event_granularity` — press-only / press+repeat / press+repeat+release / all-keys / unknown
- `layout_posture` — text-only / shifted-aware / base-layout-aware / IME-preedit / unknown
- `hop_posture` — native / mux-translated / remote-forwarded / conpty-adapted / fallback / unknown
- `recovery_posture` — reset-safe / partially-reset-safe / helper-dependent / unknown
- `binding_consumer` — terminal-local / shell-editor / application / mixed / unknown

That is enough to make keyboard/input truth legible before the archive commits to one final protocol or editor stack.

## 8) Super-awesome moves that still stay decision-light

A first specimen set could prove a lot without settling the world:
1. a key-transport badge that answers “why did this chord work here but not there?”
2. a compare card that shows native local mode versus mux/remote downgraded mode,
3. an explicit distinction between text insertion and non-text key events,
4. a shortcut matcher that can explain whether it used visible text, shifted key, or base-layout key,
5. a recovery card that says whether `reset`/mode-clear is natively safe or helper-dependent,
6. and one editor help answer that says the binding is fine locally but degraded through a hop.

## 9) Bounded conclusion

The right construction rule now looks simple:
**Schell should make keyboard/input transport an explicit witness family before it lets richer prompts, menus, widgets, or workflow shortcuts depend on invisible protocol luck.**

That lets Schell steal a lot of modern brilliance while still deferring:
- the final keyboard protocol set,
- the final mux pass-through story,
- the final IME/preedit model,
- the final remote-helper topology,
- and the final editor engine.
