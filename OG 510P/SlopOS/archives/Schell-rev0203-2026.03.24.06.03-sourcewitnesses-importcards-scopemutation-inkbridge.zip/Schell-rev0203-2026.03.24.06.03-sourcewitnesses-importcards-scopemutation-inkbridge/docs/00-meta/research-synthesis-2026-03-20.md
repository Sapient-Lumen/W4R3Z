# Research synthesis — 2026-03-20

This surface records what current outside research pressure plus the SlopOS and DelayBasin datacubes currently seem to support.
It is intentionally **decision-light**.

## 1) What SlopOS is already telling Schell

SlopOS is strongest where it turns shell folklore into explicit launch-boundary law.
The archive currently makes all of the following loud:

- no hidden command-string fallback,
- no runner-side shell parsing,
- no implicit word expansion,
- no portable PTY/job-control plane,
- no ambient env/cwd/fd inheritance,
- no backgrounding as a shell convenience,
- no wallet as an authority container,
- and no receipt mistaken for authorization.

That means Schell should not begin life as “bash with stricter defaults.”
It should begin life as a **reviewable execution surface** whose interactive language and terminal ergonomics are still under study.

## 2) What DelayBasin is teaching the archive itself

DelayBasin’s biggest gift is not domain content but **archive control**.
The most useful imported lessons are:

- preserve a move registry,
- keep revision receipts tiny and machine-readable,
- keep assumptions explicit,
- preserve foreign-pressure lineage narrowly,
- keep followthrough obligations visible,
- preserve one nearby rejected move,
- and explicitly mark which commitments are expensive to reverse.

For Schell this matters because shell projects love to fossilize convenience decisions without preserving the exact pressure that justified them.

## 3) Lessons we must learn from the past

### Hidden expansion is where shells become treacherous

If expansion, splitting, and interpretation happen as ambient folklore, users stop being able to say what will actually run.
Schell should prefer literal tokens plus explicit helpers over hidden rewrite stages.

### Structured composition is useful, but total object-worlds are a commitment

Nu and PowerShell demonstrate the value of inspectable pipeline values.
They also demonstrate that runtime object models can become large commitments that shape everything else.
Schell should start smaller: exact argv, descriptors, receipts, denials, and tiny records where they clearly pay off.

### Interactive polish is a safety feature in a strict shell

fish gets an important thing right: a shell that is safer but much less pleasant will be routed around.
Suggestions, completion, and previews must lower friction without auto-executing or silently widening authority.

### Terminal semantics should be protocol, not guesswork

The modern terminal lesson is straightforward: prompt marks, cwd signaling, blocks, marks, and precise key handling all beat prompt scraping.
Schell should treat shell↔terminal semantics as an explicit channel from the beginning.

### Use-time, narrow permission beats startup-time broad permission

Portal systems and mobile permission systems converge on the same UX truth: ask at moment of use, explain why now, grant narrowly, let grants expire, and degrade gracefully on denial.
That should be Schell’s default authority posture.

### Host-language embedding is a fork, not a garnish

Python-powered shells and higher-order shells are both informative, but they also show how quickly a shell inherits the liabilities of a host runtime.
Schell should delay this choice until its reviewed interactions are proven valuable.

## 4) Nifty ideas worth stealing

### From Oil / rc / es

- explicit expansion instead of accidental expansion,
- smaller quoting rules,
- first-class composition without Bourne-style folklore,
- readable safe defaults.

### From Nushell / PowerShell

- inspectable pipeline stages,
- structured intermediate values when they obviously pay off,
- strong parameter/shape metadata,
- good errors instead of post-hoc folklore.

### From fish

- autosuggestions that never execute themselves,
- calm completion and selection UX,
- interactive forgiveness without semantic ambiguity.

### From WezTerm / Ghostty / iTerm2 / Warp / kitty

- semantic prompt/input/output regions,
- explicit current-directory signaling,
- blocks/marks/jump points,
- prompt-aware selection and cursor movement,
- richer keyboard protocol,
- optional inline graphics for receipts and artifact previews,
- pane/user vars for shell-to-terminal state.

### From portals and mobile permission UX

- request at use-time,
- explain why now,
- narrow leases,
- revocation and expiry as normal,
- graceful degradation when denied.

## 5) Strong candidate moves for the custom terminal

- receipt-native output blocks,
- approval cards before effectful actions,
- denial cards that teach rather than just fail,
- semantic zones for prompt / input / output / review / receipt / denial,
- a background shelf instead of shell job control,
- marks that jump to the last reviewed action, last denial, last receipt, or last exported artifact,
- inline previews for exact artifacts and digests,
- click-safe cursor movement and selection when the terminal knows it is at a prompt or on a review card.

## 6) Questions the archive still owes itself

- Where exactly is the boundary between Schell and the custom terminal?
- What is the minimum portable text-only core?
- What are Schell’s true first-class nouns: intents, descriptors, receipts, leases, stages, or something else?
- What should legacy interop look like: membrane, quarantine lane, or first-class compatibility mode?
- How much review can happen on the hot path before users route around it?
- What should a denial explanation object contain?
- What is the replay model: exact bytes, same intent, or same logical request under refreshed leases?
- How do we test ergonomics before syntax is frozen?

## 7) Current recommendation

Treat Schell as three coupled prototypes:

1. a tiny execution and receipt core,
2. a semantic terminal protocol and operator UI,
3. a datacube that keeps assumptions, foreign pressure, and nearby rejected moves visible.

The next ratchet should come from **interaction proof**, not from syntactic ambition.
