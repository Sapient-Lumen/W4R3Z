# SlopOS datacube evaluation — 2026-03-23 — pass CLXXXI

**Schell should introduce tiny review watermarks and first-unseen anchors, because the companion datacubes increasingly separate source truth, caught-up posture, bounded evidence, and operator-local action posture instead of pretending that one current-looking cursor already answers what the source emitted, what was captured, and what a human has actually reviewed.**

## 1) SlopOS keeps exact source/evidence posture narrow, which is the right floor

SlopOS still keeps exact launch, exact reviewed request shape, and bounded observation/export narrow.
That remains the hard floor.
The important carry-forward here is cultural:
- a source-facing cursor or receipt should stay exact,
- observation export should stay observational,
- and portable authority should not be inferred from UI convenience.

That means Schell should not let one flattering `unread` or `latest` badge collapse:
- current source position,
- captured cut,
- later-change supplement,
- and what a human has actually reviewed.

## 2) Steward already wants snapshot-plus-change and reset honesty, which is almost the whole seam

Steward's current pressure already distinguishes:
- remembered workspace layout from live runtime truth,
- snapshot-plus-change from one flattened latest view,
- caught-up posture from silent optimism,
- and reset-required cases from fake continuity.

That makes a separate **review watermark** feel like the natural next shell/terminal import.
The archive already knows how to say:
- what was captured,
- what changed later,
- what the source is caught up through,
- and when old anchors have died.

The missing operator-facing truth is simply:
**what has this viewer actually reviewed through?**

## 3) ViewFS and Ward reinforce the split between source truth and human read posture

- **ViewFS** keeps exact basis, delta, and result posture distinct, which argues against flattening source cursor, later-change cursor, and viewer-local reviewed-through marker into one number.
- **Ward** keeps continuous signals, attenuation, and residue distinct, which argues that a later-change lane may exist while the human review watermark still trails behind it.
- **Harbor** keeps risk ladders visible and **Helm** keeps settlement narrower than local success, which reinforces that reading/resume comfort should stay weaker than stronger action or consequence claims.

Those pressures all point to one tiny new witness rather than a bigger system.

## 4) The companion-safe import is a viewer-local review watermark plus first-unseen anchor

The smallest good import is:
- a **review watermark** attached to one snapshot receipt / since-cut supplement / change-digest card family,
- plus a **first-unseen anchor** when Schell can still name the next boundary exactly.

They should say:
- what exact base cut or later-change lane they are relative to,
- what exact prompt / command / row / bookmark has been reviewed through,
- what scope the claim belongs to,
- where resume should land next when known,
- and whether reset is required instead of pretending continuity survived.

That is enough to make reopen/resume flows much better while keeping the architecture decision-light.

## 5) What this does not require Schell to decide yet

Review watermarks and first-unseen anchors do **not** require Schell to decide:
- one global read-state or acknowledgement service,
- one team-wide collaborative seen model,
- one final transcript store,
- one universal event bus,
- one watch protocol,
- or any rule that reviewed-through posture implies approval, settlement, or action rights.

## 6) Compact conclusion

SlopOS keeps exact source and evidence posture narrow.
Steward keeps snapshot-plus-change and reset honesty visible.
ViewFS and Ward reinforce the split between source truth and human review posture.
The already-open Schell seams now cover base cuts, later-change supplements, digests, readiness, stability, and quiescence.

So the next Schell move should be:

**add tiny review watermarks and first-unseen anchors so preserved command cards, hidden-terminal returns, watch snapshots, and attach-for-help surfaces can confess what has actually been reviewed already, where resume should land next, and when reset is still the honest answer — without turning local read posture into source truth or spend authority.**
