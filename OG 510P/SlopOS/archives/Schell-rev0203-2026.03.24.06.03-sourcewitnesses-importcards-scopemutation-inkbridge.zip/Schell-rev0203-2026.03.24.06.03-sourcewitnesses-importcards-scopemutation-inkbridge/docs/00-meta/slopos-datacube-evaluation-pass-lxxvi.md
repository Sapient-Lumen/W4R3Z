# SlopOS datacube evaluation, pass LXXVI (2026-03-22)

This pass evaluates one new companion import:
**Schell should absolutely grow borrowed-authority strips, confirmation-gated local-power leases, helper-posture cards, trusted approval lanes, and elevated-writeback edit rungs, but SlopOS pressure says forwarded agents, helper-installed bridges, and remote comfort surfaces must remain explicit narrowed routes rather than ambient session folklore.**

## 1) SlopOS already gives the core rule: cross-boundary authority must narrow, not blur

The companion archive is unusually crisp here.
`cryptosvc-forwarding-boundary-v0.md` says cross-boundary crypto use must not become transparent forwarded-agent folklore and instead stays on an explicit delegated route that preserves or narrows policy.
`authagent-provider-role-boundary-v0.md` says the auth agent remains a provider role rather than a second portable agent API or ambient `SSH_AUTH_SOCK`-style side channel.
That pressure maps directly onto Schell.
A remote or compat lane that can use local key power should never look like ordinary baseline shell truth.
It should look like **borrowed local authority on an explicit route**.

## 2) Capshell privilege posture points away from ambient elevation and toward narrower writeback lanes

`capshell-privgain-posture-v0.md` says Phase 1 launch must not gain privilege at the exec boundary and explicitly declines a generic per-step elevation surface.
That is a strong clue for terminal UX too.
Schell should resist the old instinct to solve “needs privilege” by opening a stronger interactive shell whenever possible.
A narrower elevated-writeback edit rung or reviewed privileged helper lane fits the companion posture much better than ambient run-as mythology.

## 3) Explicit env/startup posture makes remote helper honesty non-negotiable

`capshell-env-startup-posture-v0.md` rejects environment-controlled startup or resolution hooks as reviewed execution meaning.
That means any shell+terminal helper that copies files, injects env, installs integration, or alters startup posture on a remote peer must stay visibly helper-shaped and weaker than shell truth.
If Schell imports that comfort, it should do so with cards and receipts, not by pretending the remote host simply always worked that way.

## 4) Trusted attention and durable-status boundaries sharpen the approval-path lesson

`attention-durable-status-boundary-v0.md` says transient cues are not durable consequence truth.
That matters for permission prompts and helper warnings too.
A tiny glow that says “clipboard granted” or “agent forwarded” is not enough durable truth for consequential authority.
If Schell offers clipboard reads, remote-control bridges, or strong remote approvals, the durable truth needs to land on an explicit receipt or review surface.

## 5) Approval-basis posture prevents remote comfort from becoming approval drift

`approval-basis-posture-v0.md` insists that mutable basis be encoded into exact action bytes rather than silently following the current head.
The shell+terminal equivalent is clear: a prior remote session, prior helper install, prior forwarded-agent setup, or prior privileged-edit approval must not silently bless a later changed basis.
Borrowed-authority cards and helper-posture witnesses need freshness and scope, not timeless “once allowed, always comfortable” mythology.

## 6) The best SlopOS-compatible moves from this seam now look no-regret

The strongest companion-compatible moves are:
- **borrowed-authority strips** separating local-only from remote-spendable power,
- **confirmation-gated leases** for forwarded key use and other local-power bridges,
- **helper-posture cards** for copied files, injected env, shell integration, and remote-control activation,
- **elevated-writeback edit rungs** weaker than a full privileged session,
- **trusted approval lanes** for the strongest local confirmations,
- **clipboard/remote-control ask surfaces** with explicit allow/deny/unknown posture,
- and **freshness/peer-binding badges** so old comfort setup does not impersonate current truth.

## 7) Things this pass still refuses to decide too early

This pass does **not** force:
- one final remote-helper or ssh-wrapper architecture,
- one final auth-agent/provider backend,
- one final secure-attention implementation,
- one final clipboard or host-side side-effect policy stack,
- one final privilege broker,
- or one final remote-control protocol.

The answer is smaller and stronger:
**treat borrowed local power as an explicit narrowed route, keep helper-installed comfort visibly helper-shaped, prefer narrow privileged writeback over broad elevated shells where possible, and reserve the strongest approvals for a trusted local lane rather than ordinary terminal flow.**
