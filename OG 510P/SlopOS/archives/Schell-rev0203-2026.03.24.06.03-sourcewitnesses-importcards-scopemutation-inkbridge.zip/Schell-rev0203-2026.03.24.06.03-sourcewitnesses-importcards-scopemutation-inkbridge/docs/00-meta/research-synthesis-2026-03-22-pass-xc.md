# Research synthesis, pass XC (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should negotiate richer terminal and shell capabilities aggressively, but it should keep static claims, runtime confirmations, helper projections, adapter translations, and downgraded fallbacks separately named so the system never confuses compatibility folklore with exact current truth.**

This seam matters because the current ecosystem keeps rediscovering the same pattern:
- terminfo and TERM still advertise a baseline,
- richer behavior increasingly arrives via runtime requests or progressive enhancement,
- multiplexers and remote paths translate or suppress features,
- and helper tooling quietly papers over missing capability distribution.

That is useful.
It is also exactly how shells and terminals end up overclaiming what is really true.

## 1) Static capability databases still matter, but they are not enough

ncurses still treats `terminfo` as the main terminal capability database, and its current docs continue to support extended entries and user-defined capabilities loaded at runtime.
xterm then sharpens the important caveat: startup resource values may not reflect current state, which is why xterm exposes direct state-query controls in addition to the static termcap/terminfo layer.

That gives Schell a strong design clue:
**do not force “capability truth” into one bucket.**
There is static claim truth and there is current-state truth, and they can differ.

## 2) Runtime capability should be requested and queried, not guessed

Current keyboard/input protocols make the case especially clearly.
kitty’s keyboard protocol is built as progressive enhancement: an application can query support and then request stronger reporting such as repeat/release events or “report all keys as escape codes.” It even intentionally preserves recovery-friendly behavior for a few legacy keys so users can still type `reset` if a program crashes in the middle of mode changes.

WezTerm’s docs reinforce the same design pressure from another angle.
It supports xterm `modifyOtherKeys`, can honor kitty keyboard requests, and explicitly warns that CSI-u style encoding is not recommended as a general default because it changes behavior incompatibly and applications cannot detect or request it.

The design import for Schell is simple and strong:
- richer modes should be requested,
- support should be detectable or explicitly admitted,
- and downgrade posture should be visible when stronger reporting is unavailable or unsafe.

## 3) Multiplexers prove translation should be explicit

tmux is a great current teacher here.
Its manual and wiki say tmux can request extended keys if the terminal supports them, and they expose named feature families through `terminal-features` and `terminal-overrides` because terminfo alone often does not capture what the outer terminal really supports.
The tmux docs also explicitly warn to configure only features the terminal actually supports.

That is not just a tmux tip.
It is a shell+terminal architecture lesson.
A mux or adapter is not merely a neutral pipe; it is a translation layer.
Schell should make that visible.

## 4) Modern terminals openly show the pain of remote capability distribution

Ghostty’s current docs are unusually honest about the ecosystem pressure.
Ghostty uses `xterm-ghostty` because too many applications string-search for `xterm`; it offers an opt-in `ssh-terminfo` feature to copy terminfo to remote hosts; and it also offers an opt-in `ssh-env` fallback that sets `TERM=xterm-256color`, explicitly calling that workaround “not strictly correct” even though it often helps.
Ghostty’s release notes also explain why those SSH integration features are opt-in: they override the `ssh` command in the shell and are not without risk.

WezTerm’s docs show a similar story: `TERM=wezterm` unlocks newer features if the terminfo entry is installed, but older ncurses installations may require manual terminfo installation, nonstandard paths may require `TERMINFO_DIRS`, and Windows ConPTY can strip some escape sequences.

The lesson is not merely “remote terminals are messy.”
It is:
**compatibility often depends on distribution and translation work that should be confessed, not flattened into native capability truth.**

## 5) SlopOS makes the right import much stricter

The companion archive turns this from a convenience issue into a design rule.
RFC-0071 on interface evolution says identity should be explicit, unknown interfaces or methods must fail deterministically rather than guess, and real compatibility should ship as explicit adapters or translators.
The signature-algorithm acceptance boundary says imported identifiers are exact evidence, but acceptance remains explicit local policy and Phase 1 declines hidden strongest-wins or negotiate-until-one-works behavior.

That pressure maps beautifully onto terminal capability posture.
A terminal’s claim about itself, a helper’s workaround, or a mux’s translation should not silently spend richer authority.
Schell should keep claim, query, adapter, and local acceptance separate.

## 6) What Schell should now do

This pass suggests a compact answer:
- keep **capability ground** separate from render/input/session truth,
- split **static claim**, **runtime-confirmed**, **shell-marked**, **adapter-translated**, and **fallback** posture,
- show **bridge strips** for mux/ssh/wsl/conpty/helper involvement,
- expose **why cards** for “why did this feature work or fail here?”,
- and keep a **negotiation ladder** from native -> adapter -> degraded-safe -> legacy -> unknown.

## 7) Super-awesome specimen ideas that still stay decision-light

A first specimen set could stay small but teach a lot:
1. one key-input feature card showing the static terminfo claim, runtime query, accepted enhancement level, and recovery-safe fallback;
2. one remote-host card showing terminfo install versus TERM fallback with a clear downgrade badge;
3. one mux bridge card listing which capabilities were passed through, translated, or suppressed;
4. one “why didn’t this work?” explainer for hyperlinks, undercurl, focus events, clipboard, or graphics;
5. one helper-footing card that names when shell integration or TERMINFO_DIRS made a feature available;
6. and one export witness preserving capability basis, query results, and downgrade posture rather than only the observed symptom.

## 8) Decisions intentionally kept open

This pass does **not** freeze:
- one final capability registry,
- one final runtime query suite,
- one final mux bridge protocol,
- one final TERM/terminfo family strategy,
- or one final remote feature-install/fallback story.

The no-regret move is smaller and stronger:
**give Schell capability-ground cards, negotiation ladders, adapter confession strips, and downgrade badges so richer terminal power becomes much more legible without turning compatibility folklore into hidden shell authority.**
