# SlopOS datacube evaluation — pass XIII

This pass keeps one new synthesis in view:
**Schell should treat visible selection as explicit packets with exact target posture, bounded action ladders, and a separate primary-target truth, rather than letting highlight, hover, or clicked history silently become live authority.**

SlopOS keeps teaching the same deeper lesson from new seams:
exact requester truth, fail-closed handling for approximate fallbacks, and refusal of policy-owned routing leakage matter more than smooth-looking “open whatever seems close enough” convenience.
DelayBasin adds the process lesson that a selection should either stay a small exact object with a bounded next-move ladder or produce a public hold card when the system cannot honestly promote it.
The next Schell import is to make that visible in the shell+terminal itself.

## Strongest SlopOS lessons right now

### 1) Exact reveal/select beats approximate nearby behavior

SlopOS's OpenURI show-item exactness boundary is unusually clear.
A request to reveal/select an exact object stays an **exact target-selection intent**.
If the backend cannot do that exact thing, the request fails closed instead of silently degrading into “open the containing place” or some other nearby affordance.

Local import for Schell:

- selecting a path, URI, command block, or receipt should preserve what exact thing was selected,
- actions on that selection should fail closed when the system only has a nearby approximation,
- and “helpfully did something near it” should not count as the same outcome.

### 2) Handler choice and session choice should stay outside generic selection actions

SlopOS also keeps generic open narrow.
Handler choice stays shell/policy-owned, and OpenURI exports no portable browser-session/profile/private-mode chooser.
That is a strong warning for a custom terminal.

Local import for Schell:

- a click on a selected URI/path can still offer generic open or inspect,
- but that does **not** make the terminal a browser-profile chooser, handler inventory API, or private-session controller,
- and the selected object should not inherit hidden policy state just because a user clicked it.

### 3) Selected is not the same as current live target

A lot of legacy terminal UX quietly collapses “the thing the cursor is over,” “the highlighted text,” and “the object I can safely act on now.”
SlopOS's request/live-state posture keeps warning against that.
Admitted request, chosen route, and live active state stay distinct.

Local import for Schell:

- there should be one visible **primary target** for the current live lane,
- passive selection should remain a separate selection packet,
- and selection should not automatically steal liveness from the active-input field, the current review card, or the current receipt object.

### 4) Exact selectors should stay exact all the way down

SlopOS's capshell selector posture keeps refusing hidden second-pass selector tricks.
Exact executable selection, explicit argv meaning, and refusal of helper folklore all point the same way.

Local import for Schell:

- a selected command block should say whether it is guessed, shell-authenticated, historical, restored, or drifted,
- strong actions should keep compare-and-set style basis checks instead of silently following “latest nearby,”
- and selections should not smuggle in extra expansion or reroute logic when they become actionable.

### 5) DelayBasin's bounded-assimilation lesson belongs on selection too

DelayBasin keeps pushing three method lessons that matter here:

- a visible object should carry a bounded action story,
- nearby rejected promotions should stay public,
- and hold cards should explain what exact witness is missing.

That maps naturally to Schell selection handling.
An ambiguous path, stale command block, cross-lane historical receipt, or selected agent-only object should not force the archive to decide too much.
It should yield a small exact selection packet plus the next allowed actions.

## What Schell should deliberately refuse for now

### Refuse “selected means active” folklore

Highlighting, hovering, or clicking something visible is real operator intent, but it is not enough to prove that the object is the current live target.

### Refuse approximate open fallback as the default

A selected object that cannot be opened, rerun, or revealed exactly should usually produce a compact hold card instead of a flattering nearby substitute.

### Refuse one flat action story for all visible things

Paths, URIs, active prompts, historical output, receipts, workflows, and agent-only blocks may all be selectable, but they should not inherit the same action ladder.

### Refuse hidden policy leakage through click actions

Selection/open behavior should not quietly become handler selection, browser-session choice, or workflow-routing magic.

## Current consequence for Schell

The best next ratchet is now:

1. **one selection-packet family for visible shell+terminal objects,**
2. **one primary-target indicator for the current live lane,**
3. **one trust/liveness/action ladder keyed by selection kind,**
4. **one ambiguous-or-approximate hold-card path instead of quiet fallback,**
5. **and one transcript-safe selected-object witness so logs still explain what was selected and why strong actions were or were not allowed.**

That is a powerful way to make Schell feel super awesome while still keeping renderer choice, pointer model, palette/search plumbing, selection grammar, and final action algebra open.
