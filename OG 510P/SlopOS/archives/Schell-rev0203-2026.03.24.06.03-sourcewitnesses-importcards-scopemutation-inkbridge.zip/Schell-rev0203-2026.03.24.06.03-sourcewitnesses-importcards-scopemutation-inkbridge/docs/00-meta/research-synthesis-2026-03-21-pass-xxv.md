# Research synthesis, pass XXV (2026-03-21)

This pass keeps another design rule in view:
**discovery should become dramatically better without letting command palettes, deck cards, marks, notes, or previews impersonate current authority.**

The outside terminal landscape keeps converging on a useful split.
The best current tools separate:
- exact command units,
- lightweight navigation anchors,
- reusable saved artifacts,
- and palette results that help you stage or inspect work.

That is a very strong clue for Schell.

## 1) Unified discovery is worth stealing

Warp's Command Palette is a global search for workflows, notebooks, keyboard shortcuts, and other actions.
That is worth stealing as a product instinct.
The important lesson is not “one giant palette.”
It is that terminal power becomes much more humane once search, recall, and action entry live in one obvious place.
See: https://docs.warp.dev/terminal/command-palette

## 2) Command search should land in editable input, not rush to run

Warp's Command Search searches across command history, workflows, environment variables, notebooks, prompts, and agent conversation history; pressing Enter inputs the selected command into Warp's Input Editor.
That is one of the best current patterns for Schell.
Selection becomes staging rather than hidden execution.
See: https://docs.warp.dev/terminal/entry/command-search

## 3) Marks and annotations are still brilliant terminal ideas

iTerm2 still has a very strong mark-and-annotation story.
It supports marks, next/previous mark navigation, and annotations as notes attached to a chunk of terminal history.
That remains a terrific clue for Schell: lightweight jump anchors and local notes can make terminals much better without freezing a full notebook model.
See: https://iterm2.com/documentation-one-page.html ; https://iterm2.com/documentation-triggers.html

## 4) Open Quickly style discovery is stronger than fragmented menus

iTerm2's Open Quickly can search by tab title, command name, host name, user name, profile name, directory name, badge label, and more.
That is a strong argument for a Schell discovery surface that spans live sessions, chapters, peers, directories, and pinned objects rather than scattering them across menus.
See: https://iterm2.com/documentation-highlights.html

## 5) Command palettes are now mainstream terminal UX

Ghostty added a command palette that can invoke most keybind actions, and Windows Terminal's command palette can run terminal actions and even a `wt` command in command-line mode.
That reinforces that a palette is no longer an exotic UI flourish.
It is becoming baseline terminal ergonomics.
See: https://ghostty.org/docs/install/release-notes/1-2-0 ; https://learn.microsoft.com/en-us/windows/terminal/command-palette

## 6) Palette post-action behavior deserves explicit design

PowerToys Command Palette documents distinct post-action results like KeepOpen, Hide, GoBack, GoHome, Dismiss, and Confirm.
That is a surprisingly useful import for Schell.
A discovery surface should not always close, and it should not always stay open.
Keep-open / hide / dismiss is a real design seam, not tiny UI trivia.
See: https://learn.microsoft.com/en-us/windows/powertoys/command-palette/command-results

## 7) A compact Schell v0 cluster is strong

A decision-light first cut probably needs only:
- one lightweight **deck card** family,
- one exact **mark** family,
- one local **annotation** family,
- one **discovery palette** row model with strong badges,
- one action ladder favoring inspect and insert over run,
- one explicit keep-open / hide / dismiss rule,
- and one metadata-safe preview posture.

## 8) Decisions intentionally kept open

This pass does **not** freeze:
- one global search index,
- one preview engine,
- one result-ranking model,
- one cross-device deck sync backend,
- one annotation-sharing model,
- or one omniscient palette architecture.

The no-regret move is narrower:
**make discovery unified, exact-ref-bound, and stage-friendly, while keeping marks, notes, recents, and palette hits clearly weaker than live authority and explicit review.**
