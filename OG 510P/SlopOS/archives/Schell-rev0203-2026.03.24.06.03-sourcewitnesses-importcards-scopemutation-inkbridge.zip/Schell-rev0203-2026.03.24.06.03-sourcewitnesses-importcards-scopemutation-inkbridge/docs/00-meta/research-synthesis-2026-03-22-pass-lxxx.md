# Research synthesis, pass LXXX (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should steal the best modern discovery moves — contextual completions, searchable command catalogs, example pages, predictive suggestions, fuzzy preview choosers, and typo help — but it should keep inventory, help, examples, predictions, bridges, and exact approved action separate so “the shell suggested this” never impersonates “this is the exact command basis I reviewed and meant to run.”**

This seam matters because the current ecosystem has genuinely improved the learning curve of command lines:
- fish makes interactive help and completions feel native,
- PowerShell built command discovery into first-class commands and layered predictive help on top,
- zsh’s completion system remains deeply contextual,
- Nushell treats help as queryable structured output,
- fzf and zoxide make previewable recall feel luxurious,
- tldr-pages complements manuals with example-first help,
- Git shows suggestion and autocorrect can stay configurable rather than silently mandatory,
- and carapace shows completion bridges can reuse other ecosystems while also dodging startup-latency costs.

What these tools still blur together, however, is:
1. **what universe is being searched**,
2. **whether the result is normative help or only an example**,
3. **whether the suggestion came from history, a plugin, or a bridge**,
4. **whether the surface is inert preview or pending execution**,
5. **and whether typo repair is suggesting, editing, prompting, or running.**

## 1) Current shells prove that inline help and completions are worth stealing

fish still makes the strongest out-of-the-box case for interactive delight.
Its tutorial says fish provides syntax highlighting, autosuggestions, and tab completions that “just work”.
Its release notes also say pressing `F1` shows the manual page for the current command, and that fish uses OS command-not-found handlers on several major distributions.
The same docs also note continued improvements to the manual-page completion generator.

That is a strong design clue for Schell.
Inline help should be close at hand, command-not-found should be a real discovery surface, and doc-derived completion is worth stealing.
But those suggestions should still remain visibly doc-derived and weaker than exact command approval.
See: https://fishshell.com/docs/current/tutorial.html ; https://fishshell.com/docs/current/relnotes.html ; and https://fishshell.com/docs/current/completions.html

## 2) PowerShell shows the value of explicit discovery commands and source-labeled predictions

PowerShell remains one of the clearest examples of treating discovery as a first-class shell concern.
`Get-Command` inventories installed commands, including cmdlets, aliases, functions, scripts, and applications, and can even auto-import a module when an exact command name is requested.
`Get-Help` is a separate discovery surface: Microsoft’s docs say it can locate commands by wildcarding names first and then doing a full-text search across help articles.
PSReadLine then layers predictive help on top: Microsoft says Predictive IntelliSense offers full-command suggestions from history and plugins, and that the `ListView` shows the source of the prediction.
PSReadLine also advertises dynamic help in the console “without losing your place on the command line.”

The lesson for Schell is excellent and narrow:
keep **inventory**, **help**, and **prediction** as different grounds, and surface prediction source visibly instead of collapsing all guidance into one suggestion stream.
See: https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/get-command?view=powershell-7.5 ; https://learn.microsoft.com/en-us/powershell/scripting/learn/ps101/02-help-system?view=powershell-7.5 ; https://learn.microsoft.com/en-us/powershell/module/psreadline/about/about_psreadline?view=powershell-7.6 ; and https://learn.microsoft.com/en-us/powershell/scripting/learn/shell/using-predictors?view=powershell-7.5

## 3) zsh and Nushell show two useful ends of the discoverability spectrum

zsh’s completion system still matters because it is explicitly contextual and already provided for many commands.
The manual says users can accomplish a great many tasks without learning details beyond initializing the system.
zsh also documents `command_not_found_handler`, but crucially, it runs in a forked subshell, so state changes there do not affect the main shell.
That is a subtle but excellent design clue: command-not-found handling is useful, but it should start as observation and suggestion rather than becoming ambient state mutation.

Nushell pushes the other way by making help queryable and structured.
Its `help commands` surface supports `--find` and returns a table, which is a great clue for Schell’s own help-query posture.
Schell does not need Nushell’s whole model to steal that idea.
It can simply treat help search as a first-class, typed, previewable table rather than opaque prose or ad-hoc plugin output.
See: https://zsh.sourceforge.io/Doc/Release/Completion-System.html ; https://zsh.sourceforge.io/Doc/Release/Command-Execution.html ; and https://www.nushell.sh/commands/docs/help_commands.html

## 4) Example pages and keyword search are different kinds of help and should stay different

Traditional manuals and example pages remain complementary rather than interchangeable.
`apropos` searches manual-page descriptions for keywords, which is exactly the old-school “I know what I want, not what it’s called” move.
`tldr-pages` explicitly describes itself as a simpler, more approachable complement to traditional man pages with practical examples.
The project’s README makes the same point with a useful contrast: manuals can be authoritative but far from the common case, while tldr-style examples optimize for quick practical recall.

Schell should steal both moves while keeping them distinct:
- keyword search over descriptions,
- and example-first cards for common tasks.

Those are great discovery luxuries.
They just should not pose as identical kinds of truth.
See: https://man7.org/linux/man-pages/man1/apropos.1.html ; https://tldr.sh/ ; and https://github.com/tldr-pages/tldr

## 5) Preview-first fuzzy recall is a massive quality-of-life win

fzf’s README still captures one of the most powerful ideas in terminal UX: a general-purpose interactive filter that works over files, command history, processes, hostnames, bookmarks, git commits, and more.
zoxide applies a narrower version of that insight to directory recall: it remembers frequently used directories, supports `zi` for interactive selection using fzf, and even offers interactive completions on supported shells.

That suggests a no-regret Schell move:
use fuzzy search and preview everywhere it helps, but keep previews inert and clearly labeled as previews.
A chooser that looks great is not the same as an exact approved command.
See: https://github.com/junegunn/fzf/blob/master/README.md ; and https://github.com/ajeetdsouza/zoxide

## 6) Git gets typo help mostly right by keeping suggestion and execution configurable

Git’s current docs are especially useful here because they show a mature CLI resisting the temptation to over-automate.
`git --help` prints common commands and can list all available commands.
`git help --config` lists config variables.
Most importantly, `help.autoCorrect` does **not** have to run guessed commands: the default mode is to show the suggested command, while other modes can run immediately, wait, never show, or prompt for confirmation.

That is one of the best current models for Schell’s typo and quick-fix posture.
Suggestion is great.
Prompted execution may sometimes be fine.
Auto-running guessed intent should stay a consciously stronger posture, not the ambient default.
See: https://git-scm.com/docs/git ; and https://git-scm.com/docs/git-config

## 7) Bridges are worth stealing, but only if they confess their provenance

carapace’s bridge docs are a useful reminder that discovery surfaces are increasingly compositional.
The project explicitly says bridging completions from another engine can be beneficial even when the command supports the current shell, partly because it enables embedding and partly because it avoids shell startup delay from sourcing init-time completions.
That is a very strong idea for Schell.
But carapace also makes clear that bridging is limited by how well the command/framework is supported.

So the stealable move is not “everything should be bridged.”
It is: bridged completions and help should be welcome, clearly labeled, and visibly weaker than native command knowledge when confidence differs.
See: https://carapace-sh.github.io/carapace-bin/spec/bridge.html

## 8) What Schell should now do

This pass points to a compact, high-value discovery model:
- **command inventory cards** for what is reachable in the current footing,
- **help-ground cards** for native help vs docs vs examples vs history vs bridges,
- **scoped queries** instead of one ambient global search,
- **source-labeled predictions** instead of one merged suggestion lane,
- **preview-first choosers** with inert rendering,
- **example pages** as complements to normative help,
- **command-not-found cards** that offer search/help/install/replace-in-buffer as separate actions,
- and **quick-fix ladders** where edit and execution remain distinct.

## 9) Decisions intentionally kept open

This pass does **not** freeze:
- one final docs/help storage engine,
- one final ranking or prediction model,
- one final bridge protocol,
- one final query language for local or imported help packs,
- one final example corpus,
- or one final command-not-found remediation backend.

The no-regret move is smaller:
**give Schell help grounds, query scopes, source-labeled suggestions, inert previews, and explicit quick-fix ladders so discovery becomes delightful without letting guesses, examples, or bridges impersonate exact approved action.**
