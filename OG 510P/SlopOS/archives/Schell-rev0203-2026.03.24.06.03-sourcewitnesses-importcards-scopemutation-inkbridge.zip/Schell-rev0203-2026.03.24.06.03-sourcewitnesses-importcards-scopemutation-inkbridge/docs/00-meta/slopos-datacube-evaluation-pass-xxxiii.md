# SlopOS datacube evaluation, pass XXXIII

This pass keeps one bounded thesis in focus:
**SlopOS keeps teaching that imported convenience, local policy, and helper logic should be explicit, non-amplifying, and easy to revoke on change. Schell should steal that lesson before repo-local shell+terminal smartness becomes ambient execution policy.**

This is an especially good moment to import the lesson because SlopOS is still in design phase too.
The expensive mistakes are still cheap to avoid.
The current companion boundaries keep showing that the substrate gets safer and more legible when request shaping, policy, activation, and imported identity stay separately named.

## 1) SlopOS keeps refusing “nice extra logic” as hidden generic meaning

The OpenURI family refuses to let generic launch quietly absorb request shaping, activation control, speculative loading, durable recent-item authority, or downstream completion truth.
The approval-basis posture refuses floating head-following approvals.
The origin/quarantine family refuses imported bytes becoming trusted in place.
The veto-only policy-bundle posture refuses policy from becoming a second authority-granting mechanism.

Put together, those are not isolated OS lessons.
They are a design method:
**extra helper logic may exist, but it must stay explicit about source, scope, revocation, and non-amplification.**

## 2) Repo-local shell intelligence is the terminal twin of those SlopOS boundaries

A brand new shell+terminal will be strongly tempted to let projects provide:
- custom completion rows,
- command examples,
- runbooks,
- workflow seeds,
- environment activation hints,
- repo-local glossary/help,
- guardrail validators,
- path/object heuristics,
- or agent-facing task hooks.

Those are real sources of delight.
They are also one of the fastest routes back to the old ambient-shell trap:
- open repo,
- prompt appears,
- hidden local code runs,
- and the operator is expected to treat the resulting shell state as normal.

SlopOS argues against exactly that shape.
Imported or repo-local intelligence should not silently become baseline shell truth.

## 3) The strongest import is non-amplifying local acceleration

RFC-0028's veto-only policy-bundle posture is a beautiful pattern for Schell.
Project-local smartness should mostly be allowed to:
- annotate,
- rank,
- suggest,
- narrow,
- warn,
- or veto a stronger action.

It should be much harder for repo-local material to:
- auto-run on prompt entry,
- silently widen authority,
- replace current execution-ground truth,
- or install a new hidden execution path.

That means the default Schell import is not “plugins” or “workspace hooks”.
It is closer to **repo-local accelerator packs** whose safe floor is proposal-only or veto-only.

## 4) Origin/quarantine gives Schell the right posture for imported project smartness

SlopOS quarantine discipline keeps imported objects inspectable without laundering trust in place.
That maps directly onto shared runbooks, checked-in helper packs, imported completion bundles, or project-distributed terminal helpers.

A promising Schell rule is:
- a repo accelerator can be visible before it is trusted,
- searchable before it is active,
- previewable before it is leased,
- and still remain clearly quarantined or historical until the operator explicitly accepts it.

That is much better than the old folder-open story where the project instantly starts shaping the shell.

## 5) Approval-basis posture implies reauthorize-on-change

The approval-basis posture says mutable basis must be encoded exactly, not left ambient.
For Schell, that implies a powerful trust rule:
**if a repo-local accelerator pack changes, the old approval should not float forward.**

That does not require one final trust database or signature system yet.
It only requires the archive to keep digest/path/version basis visible and to treat changed bytes as a new approval question.

This is one of the clearest lessons we must learn from the past.
Ambient project-local trust is usually tolerable only until the project changes underneath it.

## 6) SlopOS also warns against smuggling browser- or helper-local policy into generic verbs

The OpenURI request-shaping boundary is very relevant here.
It refuses to let generic “open” turn into a hidden request-customization plane.
Schell should import the twin rule:
**generic terminal help should not quietly become a hidden project-automation plane.**

Examples of what to refuse by default:
- opening a repo should not automatically install or run repo-local hooks,
- opening a command palette should not automatically execute repo-local generators,
- selecting a workflow should not silently enable repo-local validators,
- and shell integration should not mean “workspace logic may now run during prompt paint.”

## 7) The decision-light import is small and strong

A no-regret Schell ratchet now looks like this:
- one **repo accelerator pack** descriptor family,
- one **trust lease** for making a pack active on this machine/account,
- one **changed-bytes revoke / reauthorize** rule,
- one **quarantined preview** posture for imported/shared packs,
- one **proposal-only / veto-only** safe floor,
- and one transcript-visible witness whenever a pack materially influenced a surfaced suggestion, warning, or downgraded action.

That is enough to learn a lot without freezing:
- one plugin API,
- one package format,
- one signature system,
- one policy language,
- or one IDE-style workspace-trust clone.

## 8) This is a direct path to “super awesome” without ambient magic

A shell+terminal becomes super awesome when it gives the operator great local help **without** forcing them to trust the repo as a second shell author.
The best shape is not “every project may now run code on prompt entry.”
The best shape is:
- local project intelligence is easy to inspect,
- delightful to summon,
- easy to trust narrowly,
- easy to revoke,
- and always weaker than fresh shell review when power is on the line.

That is a lesson worth stealing before Schell grows its own folklore.
