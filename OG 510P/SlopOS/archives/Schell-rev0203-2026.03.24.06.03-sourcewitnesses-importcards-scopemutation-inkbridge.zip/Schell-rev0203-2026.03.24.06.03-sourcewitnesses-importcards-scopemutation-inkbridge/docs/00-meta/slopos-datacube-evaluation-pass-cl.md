# SlopOS datacube evaluation — pass CL

This pass asks a narrower companion-safe question than “should Schell have an activity feed?”
The better question is:
**how should Schell build a unified timeline without letting mixed historical rows impersonate current live SlopOS truth?**

## 1) SlopOS keeps rejecting the shortcut from remembered event to current fact

Even while still in design phase, SlopOS repeatedly refuses to let prior events turn into present truth by convenience.
Its request-vs-provider-live-state posture rejects the move from accepted request to current live fact.
Its OpenURI launch-completion boundary keeps launch admission separate from downstream completion or user consumption.
Its OpenURI recent-items boundary keeps recents/history shell-owned and non-authoritative rather than a durable portable reopen plane.

That is the direct Schell companion lesson:
**a mixed timeline can be brilliant, but it should still be historical evidence unless the shell freshly upgrades a row into live now truth.**

## 2) RFC-0119 and RFC-0105 suggest that order and context should travel with rows, not disappear into view chrome

SlopOS’s ordering-token posture keeps ordering evidence scope-bound, owner-minted, and non-authoritative.
Its request-context posture keeps deadline/cancellation/correlation as coordination metadata rather than a second authority system.

That suggests a Schell timeline should preserve:
- exact ordering evidence,
- correlation/context hints,
- and scope-bearing row metadata,

without letting the timeline view itself become the authority plane.
A grouped display is not the same thing as exact shell order.
A correlated row is not the same thing as current live ownership.

## 3) ViewFS reinforces that row class matters

ViewFS keeps continuation cursors, sync watermarks, rebuilt snapshots, gap verdicts, basis cards, apply sessions, and receipts separate.
That is strong pressure against a flattened terminal activity log.

Schell should therefore keep command chapters, prompt marks, directory rows, watcher rows, reset rows, and receipt rows as different timeline classes.
A mixed timeline can still exist — it just should not erase object class.

## 4) Steward reinforces freshness decay and explicit repair posture

Steward keeps freshness, countdowns, retries, pushback, and durable completion posture separate.
That suggests Schell should let timeline rows visibly decay.
The timeline should be a good place to say:
- stale,
- changed since review,
- resume no longer honest,
- live follow lost,
- reset required.

That is much safer than letting the top row silently impersonate “current enough.”

## 5) Helm reinforces the split between now beacons and historical continuity rows

Helm’s change-cursor work already distinguishes current live truth from last-seen, changed-since, resume-from, and reset-required posture.
That is almost exactly the next seam Schell needs.

A mixed timeline can hold those rows, but it still needs one separately named stronger object for live footing.
Otherwise change cursors and current shell truth collapse back into one flattering feed.

## 6) What Schell should steal now

Schell should steal several excellent ideas, but import them as typed timeline witnesses:
- a unified mixed timeline with source filters,
- rich command rows carrying directory/outcome/session metadata,
- cross-linked output rows,
- row-specific verbs like reveal / insert / `cd` / compare / reset,
- explicit historical-versus-live badges,
- and one dedicated now beacon for current shell footing.

## 7) What Schell should refuse now

Schell should refuse:
- one giant undifferentiated activity log,
- treating the most recent row as the live prompt by default,
- display grouping or relative-time chrome as authoritative ordering truth,
- silent merging of assistant/imported/restored rows into ordinary operator truth,
- and silent auto-promotion from stale historical row to current live state.

## 8) Compact conclusion

The companion-safe answer is not to avoid timelines.
It is to make them **typed, filtered, and visibly weaker than live now truth**.
If Schell keeps mixed rows, exact row classes, row-specific verbs, and one explicit now beacon separate, it can become much more humane than shell folklore while staying aligned with SlopOS exactness during the design phase.
