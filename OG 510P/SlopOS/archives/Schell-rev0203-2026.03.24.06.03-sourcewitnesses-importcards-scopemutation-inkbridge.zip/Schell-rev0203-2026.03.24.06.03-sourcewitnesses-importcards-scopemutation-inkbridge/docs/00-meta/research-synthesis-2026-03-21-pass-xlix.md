# Research synthesis, pass XLIX (2026-03-21)

This pass focuses on one bounded seam:
**the best current shell+terminal ideas are now arriving as small command-aware bundles — marks, command boundaries, structured help, rich routing, input upgrades, and safer Unicode review — and Schell should steal those bundles without letting any one bundle silently choose the parser, transport, or renderer architecture.**

## 1) Semantic command boundaries are no longer speculative

The old FinalTerm/iTerm2 lineage is still one of the most important historical clues.
The point of the escape sequences was to mark where the prompt begins, where the user-entered command begins, and where command output begins and ends.
Modern tools have kept pushing that idea forward instead of abandoning it.

VS Code's shell integration uses command detection to power command decorations, command navigation, command guides, sticky scroll, recent-command recall, and quick fixes.
WezTerm added OSC 133 support, semantic-zone-aware selection, and shell integration for cwd plus semantic zones.
kitty's shell integration also shows how far this can go locally: jump between prompts, page command output, and move the cursor inside the current prompt with the mouse.

The lesson is now mature:
**command-aware terminal luxury is real, and it becomes much more trustworthy when the shell marks the boundaries explicitly.**

## 2) fish still teaches the best version of “friendly without magic”

fish's autosuggestions remain a superb product lesson.
They are immediate, humane, and obviously useful, but they are still suggestions based on history, completions, and valid paths.
They do not pretend to be reviewed execution.

That remains a model Schell should steal carefully.
A custom shell+terminal should feel fast and generous while keeping insert, review, and run visibly distinct.

## 3) Nushell proves structured data is great when it is native and bounded

Nushell's strongest lesson is not “replace the Unix shell with tables everywhere.”
It is that structured data becomes powerful when commands and help surfaces know what they are dealing with.
Its custom commands are first-class commands, and its pipeline model can preserve ordinary external stdout/stderr behavior when needed.

Schell should steal the bounded insight:
- structured receipts,
- structured denials,
- structured object cards,
- structured command metadata,
- yes;
- one premature universal structured ontology for everything,
- not yet.

## 4) Plan 9's plumber is still one of the smartest ideas in the room

The plumber remains a gold-standard historical steal.
Programs send explicit messages, rules may rewrite them, and ports or processes handle them.
That is far better than the modern tendency to let visible text silently widen into open, reveal, editor-jump, browser-launch, install, or repair behavior.

Schell should absolutely steal the underlying instinct:
**selection and visible objects should become typed routes with explicit actions, not one flattering smart-click myth.**

## 5) Input deserves an opt-in upgrade path

kitty's keyboard protocol is valuable less because Schell should adopt that exact protocol verbatim, and more because it proves a larger point: higher-level terminal UX eventually wants better keyboard semantics than legacy encodings can reliably provide.

That means Schell should keep one explicit upgraded-input lane available conceptually.
But it should treat the presence, absence, and downgrade of that lane as a visible capability posture rather than a hidden baseline assumption.

## 6) Unicode/rendering quality and review safety are converging, not competing

Ghostty's recent work makes the modern text lesson impossible to ignore.
It now treats full grapheme clusters as single units for selection, cursor movement, and cell-width calculation, while also exposing a grapheme-width compatibility setting because legacy programs may disagree.
VS Code's Unicode highlighting work separately shows that useful warnings need context so false positives do not drown legitimate multilingual text.

That means the best modern answer is not ASCII austerity.
It is dual-lane text posture:
- humane display by default,
- stricter review when ambiguity or authority rises,
- and explicit width/renderer humility when needed.

## 7) The stealable bundles Schell should care about most

The most compelling bundle candidates now look like this:

### Bundle A — command chapters and marks
- semantic prompt/command/output boundaries,
- marks,
- sticky command anchors,
- jump to previous/next command,
- output-in-pager,
- and command-aware recent recall.

### Bundle B — insert-first help
- autosuggestions,
- richer completions,
- focused parameter help,
- output-derived quick fixes,
- and explicit insert-without-run behavior.

### Bundle C — plumber-style object routing
- exact object cards for files, URLs, ports, receipts, and errors,
- explicit reveal/open/insert/fix/share actions,
- and route witnesses instead of smart-click folklore.

### Bundle D — structured receipts, not a structured everything shell
- object metadata,
- effect summaries,
- denials,
- and replay/export bundles,
- while ordinary textual execution remains intact.

### Bundle E — input and text honesty
- upgraded key semantics when available,
- visible downgrade when not,
- grapheme-aware movement,
- and strict-safe-review for suspicious or authority-bearing text.

## 8) The lesson we must learn from the past

Past shell pain keeps repeating the same warning:
- hidden parsing becomes security debt,
- hidden startup state becomes reproducibility debt,
- hidden PTY/session semantics become portability debt,
- and hidden renderer assumptions become review debt.

So the right Schell move is not feature minimalism.
It is **bundle-first ambition with explicit truth boundaries**.
That is how the project gets dramatically better without getting prematurely trapped.

## Source pointers

- VS Code terminal shell integration: https://code.visualstudio.com/docs/terminal/shell-integration
- VS Code Unicode highlighting/contextual narrowing: https://code.visualstudio.com/updates/v1_63 and https://code.visualstudio.com/updates/v1_65
- fish interactive autosuggestions: https://fishshell.com/docs/current/interactive.html
- Nushell pipelines and custom commands: https://www.nushell.sh/book/pipelines.html and https://www.nushell.sh/book/custom_commands.html
- kitty shell integration and keyboard protocol: https://sw.kovidgoyal.net/kitty/shell-integration/ and https://sw.kovidgoyal.net/kitty/keyboard-protocol/
- WezTerm OSC 133 / semantic zones history: https://wezterm.org/changelog.html
- iTerm2 semantic prompt escapes and marks: https://iterm2.com/3.0/documentation-escape-codes.html and https://iterm2.com/3.0/documentation-one-page.html
- Ghostty grapheme-width posture and Unicode 17 rendering work: https://ghostty.org/docs/config/reference and https://ghostty.org/docs/install/release-notes/1-3-0
- Plan 9 plumber: https://www.usenix.org/legacy/event/usenix2000/general/full_papers/pikeplumb/pikeplumb_html/
- Unicode security mechanisms: https://www.unicode.org/reports/tr39/
- Rust deny-by-default direction-codepoint lints: https://doc.rust-lang.org/rustc/lints/listing/deny-by-default.html
