# Research synthesis, pass XXXIX (2026-03-21)

This pass focuses on one bounded seam that Schell did not yet give its own terminal surface:
**modern terminals increasingly project shell state outward into titles, tab chrome, badges, titlebar pills, dock/taskbar progress, and ambient status strips, which means Schell should steal the delight while refusing to let ambient chrome impersonate durable truth, exact peer identity, or completion proof.**

## 1) Windows Terminal shows the value of progress that escapes the pane

Microsoft's Windows Terminal docs say the terminal supports the ConEmu `OSC 9;4` progress-bar sequence and renders it in two places: in the tab header as a progress ring and in the Windows taskbar like a download progress bar.
That is a strong product clue for Schell.
The terminal can help the operator even when the pane is not front-and-center.

But it is also a warning.
A taskbar ring is presentation, not proof.
It is useful because it projects status outward, not because it magically becomes the receipt.

See: https://learn.microsoft.com/en-us/windows/terminal/tutorials/progress-bar-sequences

## 2) iTerm2 shows how much local delight can live in chrome without touching the transcript

iTerm2's badge docs say a badge is a large text label in the top right of a terminal session and that it can be changed by an iTerm2-proprietary escape sequence. Its status-bar docs say the status bar is configurable and scriptable, intended to show up-to-date information about the environment, and includes shell-aware items like current directory, host name, user name, job name, and git state.

This is exactly the kind of idea Schell should steal carefully:
small ambient status can feel fantastic.
But it should remain a renderer-local luxury lane unless the shell can witness what is being shown.

See: https://iterm2.com/documentation-badges.html
See: https://iterm2.com/documentation-status-bar.html

## 3) WezTerm suggests the right posture for programmable chrome

WezTerm's `window:set_right_status` docs say the terminal can render right-aligned status content in the tab bar, clipped to fit available space, and that the example can derive cwd and hostname from pane state, including remote hostname when OSC 7 shell integration is present.
That is an excellent pattern for Schell.
A terminal can become much more informative when it can project exact shell-known facts into chrome.

The key lesson is not “make the tab bar smarter at any cost.”
It is:
**when status escapes the pane, shell-known facts should outrank heuristics and renderer-local guesses.**

See: https://wezterm.org/config/lua/window/set_right_status.html

## 4) Ghostty shows two different ambient-status channels that should stay separate

Ghostty's 1.2.0 release notes say the bell can, by default, put a bell emoji in the title, bounce the dock icon once, and place a badge on the app icon on macOS; GTK marks the window as requesting attention. Ghostty's 1.3.0 notes separately add command-finished notifications with policy knobs for when to notify, which action to use, and how long a command must run before the notification is sent. The same 1.3.0 notes also describe unobtrusive update notifications as a small pill in the titlebar or bottom corner instead of a disruptive popup.

That is a very useful split for Schell:
- title/dock/taskbar chrome,
- transient notifications,
- and exact command/receipt truth
should remain separately named surfaces.

See: https://ghostty.org/docs/install/release-notes/1-2-0
See: https://ghostty.org/docs/install/release-notes/1-3-0

## 5) The old desktop lesson still matters: startup feedback is not outcome proof

The freedesktop startup-notification protocol exists to let desktop environments track application startup and provide user feedback.
That old protocol still teaches the right lesson.
Feedback in window chrome is useful, but it is not the same thing as downstream success, ready-to-use state, or user acknowledgement.

Schell should import that old lesson directly.
Title pills, dock badges, taskbar progress, and tab chrome can all be valuable without pretending they are authoritative outcome state.

See: https://specifications.freedesktop.org/startup-notification/0.1/

## 6) The best steal is one exact shell-owned status packet plus many local projections

The no-regret import is not a giant cross-platform status subsystem.
It is one small shell-owned status packet family that can describe things like:
- current peer/ground identity,
- one running progress scope,
- one warning or problem count,
- one historical/restored caution,
- or one exact hold/review-needed state.

The terminal can then project that into:
- tab title,
- tab badge,
- titlebar pill,
- dock/taskbar badge,
- progress ring,
- status strip,
- or quiet residue.

That keeps the portable meaning small while still letting the local renderer feel luxurious.

## 7) The lesson from the past that matters most here

The old mistake was to treat window titles, bells, or badges as harmless decoration.
The newer mistake would be to let ambient chrome quietly become the only place where operators learn:
- which host they are on,
- whether a command is still running,
- whether the pane is historical,
- whether a service became public,
- or whether a workflow needs review.

The better answer is:
- chrome egress should hang off exact shell-owned status witnesses when possible,
- renderer-local sugar should be visibly weaker than shell-known truth,
- restore should stay historical until refreshed,
- and durable receipts should remain reconstructible without catching a transient badge at the right moment.
