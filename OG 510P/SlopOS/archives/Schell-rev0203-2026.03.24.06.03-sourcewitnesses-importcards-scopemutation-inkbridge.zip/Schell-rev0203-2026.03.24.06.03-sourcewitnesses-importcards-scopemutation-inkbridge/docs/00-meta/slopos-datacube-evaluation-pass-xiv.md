# SlopOS datacube evaluation, pass XIV

**The shell+terminal should treat panes, tabs, splits, and workspaces as local view structure — not as a second portable authority plane.**

This pass adds a new caution and a new opportunity.
The caution is that integrated shell+terminal design can quietly smuggle power through PTY ownership, shell job control, session attachment, signal folklore, pane-local env carry, or cross-pane text injection.
The opportunity is that rich local view trees can make Schell much more humane **if they stay visibly local and descriptively honest**.

## 1) SlopOS keeps refusing ambient terminal/session authority

The capshell terminal/job-control posture is extremely clear:
Phase 1 does **not** want implicit controlling-terminal grants, ambient PTY inheritance, shell-owned foreground/background control planes, or portable `fg` / `bg` / `jobs` semantics hidden inside `capshell.exec`.
Interactive UX may exist locally, but it does not become a new workflow contract.

That is a direct lesson for Schell.
A custom terminal may absolutely offer panes, tabs, splits, zoom, and rearrangement.
But those are not themselves proofs of portable execution semantics.
They are local view affordances unless the shell reifies something stronger.

## 2) SlopOS interrupt posture sharpens the same boundary

SlopOS also refuses to let portable meaning collapse into inherited signal folklore.
Local keybindings such as Ctrl-C may exist, but they remain local wrappers around explicit cancellation semantics rather than a hidden universal signal plane.

For Schell, this means:
- local pane or tab focus should not silently redefine which request is cancelable,
- a visible TUI or foreground process does not by itself become the durable action object,
- and local terminal controls should point back to the shell's exact running/reviewed object rather than pretending pane focus is enough.

## 3) SlopOS explain posture says local presentation is not durable truth

The explain posture says canonical diffs and receipts are shell/provider-owned, deterministic, bounded, and non-authoritative.
Receipts do not become approvals.
Transient banners or presentation surfaces do not become the durable truth.

This is just as important for panes and splits as it was for attention hints.
A scratch split, detached tab, restored workspace, or local compare view may be delightful.
None of that should substitute for the shell's receipt, denial, basis, or live-state truth.

## 4) The multiplexer temptation is real

Once shell and terminal are tightly integrated, it becomes tempting to make the pane tree the real operating model:
- clone a pane and inherit its env,
- fire text into a neighboring pane,
- restore an old workspace and treat it as live,
- let tabs become background jobs by folklore,
- or let the most recently focused pane redefine current authority.

SlopOS says Schell should resist all of that unless there is an explicit named seam.
The integrated terminal can be rich without becoming a hidden PTY/session authority plane.

## 5) Schell should distinguish shell truth from local view truth

A useful separation is:

- **shell truth** — reviewed action objects, receipts, denials, running-state witnesses, basis packets, authorship, and active-input truth,
- **semantic transport** — command boundaries, references, trust grades, and local badges,
- **view tree truth** — windows, tabs, splits, scratch panes, compare panes, inspector panes, and shelves.

The first category is portable and citable.
The third category is mostly local and ergonomic.
The second category bridges them.

## 6) Pane leases look like the right small import

A first useful Schell import is **pane lease** or **view lease**.
A pane lease would not mean “this pane owns authority.”
It would mean something smaller:

- this pane currently hosts one lane or view,
- this pane may be interactive or readonly,
- this pane may be restored or live,
- this pane may or may not accept text insertion,
- and this lease can expire, detach, or downgrade without changing the shell's durable truth.

That gives Schell a way to be excellent locally without letting the pane tree lie about liveness or authority.

## 7) Great local moves are still very available

SlopOS does **not** imply that Schell should be austere.
It suggests a better filter for awesome ideas.

Strong candidate moves:
- scratch splits for temporary work,
- readonly replay panes for receipts and history,
- compare panes for side-by-side outcome inspection,
- inspector panes for semantic/debug state,
- detachable shelves for denials/background residue,
- and drag/reorder/zoom moves that stay explicitly local.

All of these can make the product feel dramatically better while still keeping the shell's reviewed truth separate.

## 8) Layouts and saved workspaces should stay derivative

Saved pane/tab layouts are attractive.
But Schell should initially treat them as **derivative wrappers** or workflow-entry helpers, not as self-certifying execution truth.
A layout may say where panes appear and what kind of pane each one is.
That still should not silently approve launches, resurrect old basis, or restore authority merely because a workspace reopened.

This is a nice place to import DelayBasin's derivative-wrapper lesson.
The layout can be a low-entropy reentry aid without becoming canon-level authority.

## 9) New Schell posture for this pass

A useful new ratchet is:

**rich view trees are worth stealing, but view trees stay local until the shell explicitly names something stronger.**

That implies:
- pane focus is not the same as primary target,
- split/zoom/reorder/detach are local view actions,
- restored panes remain visibly restored,
- cross-pane injection must be explicit and bounded,
- and no pane/workspace/session object becomes portable truth by accident.

## 10) What stays open

This pass still refuses to decide:
- final PTY architecture,
- final multiplexer model,
- whether Schell ships its own mux or layers over an existing substrate,
- final workspace/session persistence,
- final pane-template grammar,
- or a universal cross-pane automation plane.

That is deliberate.
This is a no-regret posture pass, not a multiplexer product freeze.
