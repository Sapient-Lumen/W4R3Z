# Research synthesis — pass IV

This pass asks a stricter question than the earlier ones:
what should Schell steal now that it is explicitly building a **new shell+terminal together**, and what should it still refuse because the proof is not earned yet?

## Lessons we must learn from the past

### 1) Prompt scraping always becomes a tax if the shell can tell the truth directly

The modern terminal landscape keeps rediscovering this.
WezTerm, Ghostty, VS Code shell integration, Contour, iTerm2, and Warp all get better navigation or block semantics when command/prompt/output boundaries are made explicit.
The shared lesson is not “copy one product.”
It is:

> if the shell knows where the prompt, input, reviewed action, and receipt boundaries are, do not make the terminal rediscover them by heuristics.

### 2) Generic open flows become dangerous when they silently widen meaning

XDG portals are a good counterexample to platform folklore.
OpenURI stays an opening seam; Documents handles durable file exposure separately.
That separation is a valuable lesson for Schell too.
Exact artifact review should stay exact instead of silently turning into handler admin, cookie-jar control, or hidden materialization.

### 3) Permission requests work best when tied to the current action

Android's runtime-permission guidance and one-time permission posture keep reinforcing a humane rule:
request narrowly, request when the action makes the reason obvious, let denial stand, and let unused grants cool off.
That is almost a perfect description of the review-card posture Schell wants.

### 4) Rich terminal input must be a protocol problem, not a stack of guesses

kitty's keyboard protocol is useful pressure because it treats advanced terminal input as something to negotiate explicitly.
That matters once Schell wants prompt-safe click-to-cursor movement, review panes, key tables, and other richer input surfaces.

### 5) Nice shell UX matters, but language ambition can sprawl fast

fish demonstrates that humane interaction quality is real engineering, not fluff: async suggestion work and low startup/fork overhead are explicit design goals.
Nushell shows the value of structured data in pipelines, but also reminds us that richer data models are real commitments.
YSH shows the promise and cost of a clean-slate shell language: upgrades are attractive, but language growth can quickly become the project.

Local lesson for Schell:

- steal humane UX aggressively,
- steal structured data carefully,
- and avoid solving language maximalism before the reviewed interaction path is proven.

## Nifty ideas worth stealing now

### Trusted command blocks with confidence grades

VS Code's shell integration is useful because it distinguishes better and worse command truth, and it supports a nonce path for higher-trust shell-originated command reporting.
Schell should probably adopt a similar local law:

- **guessed** block,
- **marked** block,
- **shell-authenticated** block.

Different actions can then require different trust grades.
Copying visible text might work everywhere; rerunning an effectful reviewed action should probably require stronger truth.

### Prompt-safe click editing

Ghostty's newer OSC 133 work and clickable-prompt support are a reminder that prompt editing becomes much nicer once the terminal knows where editable input actually is.
Schell should steal the idea, but bind it to shell truth rather than terminal guesswork.

### Command-finish notifications tied to state

Ghostty's command-finish notifications suggest a very practical move for Schell's future background shelf and long-running reviewed actions:
notify only when the window is unfocused or the duration crosses a threshold.
That keeps the feature humane instead of noisy.

### Key tables and explicit operator modes

Ghostty's key tables are a useful lesson for a shell+terminal that wants multiple interaction modes.
Schell could use lightweight mode tables for:

- review mode,
- receipt navigation,
- background shelf navigation,
- transcript/debug mode,
- and maybe a readonly replay mode.

### Readonly and sandboxed execution lanes

Ghostty's readonly surface idea and VS Code's experimental terminal sandboxing both point in a helpful direction:
not every terminal interaction should have equal write/network authority.
Schell should explore a reviewed lane where agent-proposed execution runs under a narrower substrate posture by default.

### Block-native copy / rerun / attach

Warp, iTerm2, VS Code, and the semantic-prompt family all reinforce that command blocks are useful navigation units.
Schell should steal that, but make the block actions receipt-aware and trust-aware instead of merely buffer-aware.

## Moves to refuse for now

- no mandatory block UI for correctness,
- no freezing the final shell↔terminal protocol around today's OSC details,
- no terminal product lock-in,
- no giant object-pipeline commitment just because Nushell made structured data attractive,
- no browser-profile/session control hidden inside generic open,
- no “AI terminal” architecture imported wholesale from product marketing.

## Current best co-design direction

The winning move still looks small:

1. one exact artifact,
2. one exact reviewed action,
3. one review card with exact mutable basis,
4. one approve/deny choice,
5. one durable receipt or denial block,
6. one truthful transcript,
7. then richer shelves, previews, notifications, and mode tables only if that slice proves they help.
