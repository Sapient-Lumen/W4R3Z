# Research synthesis, pass CXVII (2026-03-22)

This pass makes one narrower lesson explicit:
**Schell should not give every command or remembered object the same memory gravity. Sticky scroll, recent-command recall, searchable history, durable retention, sync, share, and publication should obey explicit source labels and promotion budgets rather than one generic “saved/searchable” posture.**

The outside ecosystem is surprisingly aligned on the need for selective gravity.
VS Code’s terminal shell integration now supports sticky scroll, can ignore specific commands in sticky scroll, and even prevents some tool-run commands from entering shell history when shell integration is available.
iTerm2’s save-to-disk setting makes command, directory, remote host/user, and paste memory residence explicit.
Atuin exposes host/session/directory/workspace filter modes, history and cwd exclusion filters, a default secrets filter, and optional encrypted sync.
Warp groups command+output into blocks, isolates command history per shell session while running, offers unified command search across terminal inputs plus saved objects and agent conversation history, and makes sharing an explicit opt-in action.

Together these suggest a new Schell move:
**memory should be source-labeled and promotion-budgeted before it becomes global recall.**

## 1) VS Code shows that command-local chrome needs selective exclusion

VS Code’s sticky scroll is a very good product clue.
It preserves command context at the top of the viewport, which is genuinely useful.
But its newer ignored-commands setting makes the deeper lesson explicit: some commands should not dominate sticky chrome at all.
The docs even call out examples like `clear` and common agentic CLIs.

That is a surprisingly important signal.
Modern terminal UX is already admitting that “every command is equally chapter-worthy” is false.

## 2) VS Code also shows that authorship should affect memory

The recent terminal-tool change that avoids adding some tool-run commands to shell history is another strong clue.
Even when the bytes are command-like, authorship and execution path matter.
A command issued by a tool or automation lane should not always inherit the same memory privileges as a directly authored command.

Schell should keep that distinction more explicit than a leading-space hack.

## 3) Atuin shows that useful memory is already policy-rich

Atuin’s current docs make this hard to miss.
Filter modes can scope recall to host, session, directory, or workspace.
`history_filter` and `cwd_filter` can keep items out of tracking.
`secrets_filter` exists by default to stop saving known secret patterns.
And the sync path is a separately configured encrypted cross-machine workflow.

That means the good modern question is no longer “should the shell have history?”
It is closer to:
**what deserves tracking, at what scope, with what exclusions, and with what right to leave the machine?**

## 4) Warp shows the upside and the danger of mixed recall

Warp’s current docs show several powerful ideas at once.
Blocks turn command+output into an atomic object.
Command History isolates per-shell-session history while running and then combines it later.
Command Search spans terminal inputs, saved commands/workflows/notebooks/prompts, and agent conversation history.
Block sharing is explicit and opt-in.
Session restoration stores local session data in SQLite and disabling restoration stops new recording but does not itself clear the database.

The upside is huge: search across all the operator’s useful shell-adjacent memory.
The risk is equally clear: once many source classes sit in one search/result surface, Schell must not let them borrow one another’s strength.

## 5) iTerm2 reinforces that memory already has both scope and gravity

iTerm2’s shell integration makes command history and recent directories richer.
Its general preference for saving copy/paste and command history to disk shows another important truth: once persistence is enabled, command, directory, and even paste history move into a stronger residue class.

That supports a nice Schell framing:
residence is one dimension,
**gravity** is another.
Something can be persisted without being sticky.
Something can be searchable without being sync-worthy.
Something can be chapter-worthy without being publish-worthy.

## 6) Compact design-phase answer

Schell does **not** need one final search engine, sync stack, or search-plus-share object model yet.
It only needs a compact bounded move:
- add a memory-gravity hint family,
- keep mixed recall source-labeled,
- add explicit sticky exclusions with reasons,
- separate direct-authored, helper-generated, restored, shared, and assistant-lane memory,
- and make sync/share/publication depend on promotion budgets rather than generic searchability.

That is enough to make Schell’s shell memory much smarter without forcing the final backend architecture.
