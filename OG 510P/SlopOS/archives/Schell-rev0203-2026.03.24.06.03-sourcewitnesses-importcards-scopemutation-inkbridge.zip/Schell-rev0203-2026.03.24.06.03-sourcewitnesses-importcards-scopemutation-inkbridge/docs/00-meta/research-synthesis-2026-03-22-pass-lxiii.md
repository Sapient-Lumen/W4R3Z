# Research synthesis, pass LXIII (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should absolutely steal live watch modes, inspector decks, and subscription-backed monitoring surfaces — but only if observation, rerun, and stronger action never collapse into one flattering “the live panel is already authority” story.**

This seam matters because the luxury is real.
Operators do want to pin a live failing-test view, a file-change loop, a cluster pulse board, or a rolling log inspector next to active shell work.
The current ecosystem proves that repeated command views, file-triggered reruns, directory-backed log inspectors, and API-backed watch streams all feel great.
But it also proves that poll cadence, restart policy, trigger source, backlog/overflow, preview richness, and stronger actions are not the same object.
Schell should steal the best bits while keeping watch posture, rerun posture, and action strength explicit.

## 1) `watch` proves that repeated-command views are useful, but cadence and diff posture matter

The current Linux `watch(1)` page is still a sharp clue.
It runs a command repeatedly, shows the output and errors, defaults to every two seconds, and can highlight differences between successive updates or all changes since the first iteration.
That is a nice baseline for Schell.
A repeated-command inspector can be useful even when it is conceptually small.
But `watch` also teaches the limit: a repeated command view is not the same thing as a durable live subscription, and the cadence/diff mode/exit status are part of the truth.
See: https://man7.org/linux/man-pages/man1/watch.1.html

## 2) `entr` proves that file-triggered rerun is a different product shape than plain watch, and restart policy matters

The current `entr(1)` docs are an even better lesson.
`entr -r` reloads a persistent child process, uses `SIGTERM` before restart, creates a process group so shell scripts cannot mask signals, waits for the utility to exit so resources like sockets can close, and keeps TTY control with `entr` rather than transferring it to the child.
That is fantastic evidence for Schell.
A file-triggered rerun surface should expose restart policy, process-group posture, TTY posture, and shell-evaluation posture instead of pretending “watching files” is one tiny toggle.
The docs also note that shell commands and redirection are not permitted by default for the exit-status script path unless `-x` is doubled, which is exactly the kind of escalation Schell should label bluntly.
See: https://eradman.com/entrproject/entr.1.html

## 3) Watchexec proves that watch surfaces benefit from explicit filters, debounce, and startup/restart rules

Watchexec's current manual adds another valuable layer.
It runs the specified command once at startup, then monitors for changes; events are debounced; and filtering order is explicit across signals, watched paths, ignores, extension filters, and filter programs.
That is a terrific Schell clue.
A watch surface should not merely say “live.”
It should say what events count, how they are filtered/coalesced, whether the first run happens immediately or is postponed, and what happens when an update arrives while the prior run is still busy.
See: https://github.com/watchexec/watchexec/blob/main/doc/watchexec.1.md

## 4) `lnav` proves that a live inspector can be more than a rerun loop

`lnav` is useful because it shows another family entirely.
Its usage docs say that a glob pattern can be used to watch for files with a common name, and if the path is a directory all files in it will be opened while the directory is monitored for files being added or removed from the view.
It also exposes a command prompt, a SQL prompt, tags, comments, and partitions.
That is a lovely Schell lesson.
A live inspector does not have to be “rerun command forever.”
It can also be a collated observational deck over incoming evidence, with richer local inspection affordances that still remain weaker than strong action.
See: https://docs.lnav.org/en/latest/usage.html

## 5) Kubernetes and K9s prove that watch streams and action verbs should stay separately named

Kubernetes' current API concepts docs are particularly load-bearing here.
They say the API is resource-based, include fine-grained subresources for some operations, and treat `watch` as a verb for tracking changes to an object as a stream.
That is exactly the shape Schell should steal.
Live observation is a separate permission and a separate surface from `get`, `edit`, `delete`, or attach-like actions.
K9s reinforces that lesson in the UI: it exposes dedicated pulse and xray views, but also keeps describe/view/edit/logs/delete/kill as explicit commands rather than one vague smart-inspector authority story.
See: https://kubernetes.io/docs/reference/using-api/api-concepts/ and https://k9scli.io/topics/commands/

## 6) The dangerous thing to refuse: watch-as-authority

The ecosystem now makes at least five flattening mistakes temptingly easy:
- treating a live panel as proof that its target is still current and exact,
- treating a watch loop as harmless observation when it is actually rerunning shell commands,
- treating file/event/API subscriptions as interchangeable despite radically different failure and lag behavior,
- treating “the row is visible in the inspector” as enough basis for a stronger act/restart/open/delete verb,
- and treating backlog/overflow/reconnect as implementation trivia instead of operator truth.

Schell should refuse those moves.
A live watch should remain a way to **observe** or **refresh** an explicitly described view on an explicitly described trigger basis.
If a stronger act/open/restart/kill/rerun step is desired, the system should still make the target exact again and name the stronger verb separately.

## 7) The stealable move: watch witnesses, inspector decks, and subscription humility

The best decision-light move now looks like this:
1. introduce a **watch witness** family,
2. let live or semi-live observational panels become **inspector decks** bound to explicit scope and explicit trigger source,
3. keep refresh posture visible: poll / fs-event / query-rerun / API watch / appended-log / unknown,
4. keep rerun posture visible: observe-only / rerun command / restart child / manual refresh only,
5. keep lag and overflow posture visible: bounded / may-drop / reconnecting / stale snapshot / n-a,
6. keep result rows metadata-safe by default,
7. keep stronger actions gated on exact singleton selection or explicit reviewed target sets,
8. and keep live inspectors weaker than background schedulers, service supervisors, or hidden subscription daemons.

That would make Schell feel dramatically more capable without freezing one final watch backend, one event substrate, one dashboard toolkit, or one inventory model.

## 8) A compact first proving slice

A compact proof could show:
- one repeated-command inspector with explicit cadence and diff mode,
- one file-triggered rerun loop with visible debounce/restart posture,
- one appended-log or log-directory inspector deck,
- one API-watch-backed resource list with reconnect/lag posture,
- one metadata-safe row that requires a separate inspect step for richer preview,
- one row action that refuses to inherit authority from the watch surface alone,
- one explicit promote-to-target-set flow for multi-object action,
- and one honest stale/live badge when the subscription is paused, disconnected, or overflowed.

That is enough to make Schell feel super awesome at live observation without hardening the final event/watch stack too early.

## 9) Decisions intentionally kept open

This pass does **not** freeze:
- one universal watch protocol,
- one scheduler/background-job substrate,
- one event-loop or wait API,
- one dashboard/inspector UI toolkit,
- one reconnect/overflow policy across all watch families,
- or one universal permission story shared by file watchers, API watches, and repeated command loops.

The no-regret move is smaller:
**steal live inspector decks, repeated-command watch comfort, file-triggered rerun ergonomics, and explicit watch-action separation — but keep subscriptions and live panels visibly weaker than current authority.**
