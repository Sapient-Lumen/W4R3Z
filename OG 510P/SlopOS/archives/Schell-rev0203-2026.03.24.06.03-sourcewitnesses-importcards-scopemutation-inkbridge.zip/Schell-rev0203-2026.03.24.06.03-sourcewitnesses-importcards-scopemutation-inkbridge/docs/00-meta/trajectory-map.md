# Trajectory map

## Phase 0 — archive bootstrap

- Freeze the charter.
- Define the first shell+terminal-specific canonical objects.
- Establish release-control surfaces.
- Import a compact move-registry discipline from DelayBasin.
- Make open questions first-class archive objects rather than footnotes.

## Phase 1 — integrated shell+terminal truth surfaces

- Name the shell-truth / semantic-transport / local-UX split.
- Freeze the smallest reviewed-action envelope only as far as prototype evidence earns it.
- Preserve transcript truth as a hard portability rule.
- Advance the question kernel through narrow proof surfaces rather than broad syntax claims.

## Phase 2 — reviewed microinteractions and exactness

- Prove at least one reviewed action that feels obviously better than bash.
- Keep exact artifact selection exact; do not silently widen to “nearby enough.”
- Bind approvals to exact mutable basis, not head-following convenience.
- Establish receipt and denial surfaces as native navigation objects.

## Phase 3 — execution and replay

- Define builtin classes.
- Define process-launch semantics.
- Establish session receipts and replay/postmortem surfaces.
- Separate execution IR from terminal rendering protocol without separating them into unrelated products.

## Phase 4 — authority, policy, and background presence

- Make authority requests explicit.
- Separate inherited ambient power from requested power.
- Distinguish request state from live background state.
- Add portal- and receipt-shaped review hooks where shell ergonomics can bear them.

## Phase 5 — richer local terminal UX

- Prototype denial teaching, receipt shelves, background shelves, trusted command blocks, and bounded attention cues.
- Learn which rich affordances are sugar and which are load-bearing for humane review.
- Keep the terminal enhancement layer additive over a portable text baseline.
- Add stronger confidence rules for rerun/copy/attach actions on command blocks.
- Keep transient attention separate from durable outcome truth and approval.
- Add shell-owned progress/cancel/drain surfaces before importing scheduler folklore from terminals or IDEs.
- Add explicit execution-ground / activation witnesses before letting path opens, reruns, or replays depend on ambient prompt-time state.
- Add remote-domain / peer-witness / attach-honesty surfaces before SSH/mux/roaming convenience becomes a hidden authority or identity plane.
- Follow a no-regret feature ladder before choosing a final renderer or final transport.

## Phase 6 — portability and implementation

- Build the Rust workspace only as fast as the questions earn it.
- Choose compatibility profiles.
- Build a reference interpreter.
- Add test corpora, replay traces, and failure probes.
- Ratchet repo hygiene from archive-only linting into archive + Rust workspace linting.

## Live open questions

- How typed should pipelines become?
- Should capabilities be modeled as shell-native handles or only as annotations over POSIX processes?
- What is the minimum semantic protocol between Schell and its custom terminal?
- What evidence should make a command block trustworthy enough for rerun/copy/attach?
- Which shell+terminal moves are no-regret now and which would silently lock the architecture?
- How should attention hints, finish notices, and interruption budgets behave without becoming a second authority plane?
- What is the smallest authority review that users will tolerate on the hot path?
- How should local view trees, pane leases, and mux actions behave without becoming a hidden PTY/session authority plane?
- How should output capsules, channel families, and braid witnesses behave without pretending scrollback is one perfect total log?
- How should intent packets, plumb routes, and exact-open bridges behave without turning visible-object actions into ambient smart-click authority?
- How should progress scopes, cancellation, and drain honesty behave without letting spinners, prompt return, or pane disappearance silently define completion truth?
- How should execution grounds, env capsules, and activation witnesses behave without letting cwd/PATH/project-local state become ambient hidden authority?
- How should remote hops, peer witnesses, and attach honesty behave without turning SSH/mux comfort or forwarded local helpers into hidden authority?
- Which Rust crates deserve adoption, and which should remain research pressure only?
