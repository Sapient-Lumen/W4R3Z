# Research synthesis — 2026-03-23 — pass CXXXIX

This pass sharpens one fresh shell+terminal lesson from current upstream docs:
**opening a repo, workspace, or project is increasingly treated as a trust boundary — because startup code, env loaders, automatic tasks, and local config can all shape what “open a terminal” really means before the operator has reviewed anything.**

## 1) VS Code now treats untrusted workspaces as a real execution boundary

The current Workspace Trust docs are blunt: Restricted Mode exists to prevent automatic code execution, and it disables or limits features such as AI agents, tasks, debugging, workspace settings, and extensions.
That is the right emotional lesson for Schell.
A repo can be inspectable before it is trustworthy.

## 2) VS Code's terminal posture makes the hidden risk unusually concrete

The January 2026 VS Code release notes go further:
- opening the terminal is blocked by default in untrusted workspaces,
- because the shell may execute code such as by setting variables via an `.env` file,
- and automatic tasks are now disabled by default to prevent unintended execution on workspace open.

This is a very strong signal.
A modern shell+terminal should not treat folder-open as harmless chrome when local project bytes may already influence the next shell.

## 3) Current per-directory environment tools show why “current directory” is already an activation seam

direnv remains one of the clearest demonstrations of the issue.
It augments shells so environment variables load and unload depending on the current directory.
That means merely entering a directory can become a meaningful startup/activation act.
More importantly, its `require_allowed` guidance shows the right trust lesson: if relevant files change, re-authorization should be required.

## 4) mise's paranoid mode points in the same direction

mise's paranoid docs make the same distinction in another accent.
Potentially dangerous project config requires trust, and in paranoid mode the config contents are hashed so changes require renewed trust.
That is exactly the kind of changed-basis humility Schell should steal.
Trust should not silently float forward onto changed project activation material.

## 5) Environment inheritance is another quiet part of the same story

VS Code's terminal profile docs are useful here too.
They remind us that inherited environment can itself be surprising enough that there is a dedicated `inheritEnv: false` escape hatch.
That is a strong design hint for Schell:
operators need an easy **clean shell** lane, not only a richly inherited one.

## 6) The stealable move is an inert cold-open ladder

The best move to steal is not one more hidden trust checkbox.
It is a smaller, more operator-honest ladder:
- inert workspace browse,
- clean shell in the repo,
- trusted repo help,
- trusted activator,
- sandboxed activation lane,
- and fully trusted live footing.

That preserves the luxury of fast project entry while keeping “this repo is influencing my shell now” visibly separate from “I am only looking at it.”

## 7) Compact conclusion

Current official docs are converging on the same lesson from different directions.
VS Code treats untrusted workspaces and terminals as a genuine execution boundary, disables automatic tasks by default, and recommends restricted mode for untrusted projects.
direnv demonstrates that directory entry can load authorized project env code.
mise demonstrates that trusted project config should be re-trusted when its contents change.
VS Code's environment inheritance controls show that clean-start lanes are worth naming.

Schell should take the hint.
It needs a first-class split between **inert workspace**, **clean shell**, **trusted repo help**, **trusted activator**, **sandboxed activation**, and **trusted live footing** so project-aware luxury can grow without letting folder-open convenience impersonate reviewed startup authority.
