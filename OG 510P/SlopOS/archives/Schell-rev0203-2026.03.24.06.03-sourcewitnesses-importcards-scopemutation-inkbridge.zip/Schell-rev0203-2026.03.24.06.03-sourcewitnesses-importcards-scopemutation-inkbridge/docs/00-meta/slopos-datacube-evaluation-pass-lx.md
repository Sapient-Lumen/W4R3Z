# SlopOS datacube evaluation, pass LX (2026-03-21)

This pass evaluates one new companion import:
**Schell should absolutely become better at chapter export, replay capsules, publication links, and live share lanes — but SlopOS pressure says scrollback, local export, replay artifacts, published web objects, and live shared sessions must stay separately named so residue, authority, and durable history are never smuggled in by one generic sharing surface.**

## 1) OpenURI recent-items posture pressures a hard split between publication and ambient history

SlopOS already freezes the rule that generic launch does not become a portable recents/history control or receipt surface.
That imports directly here.
If Schell publishes a chapter, uploads a replay capsule, or opens a live viewer, that should not silently imply a durable recent-item or reopen grant for some broader object family.
Publication history and recents, if they exist at all, should stay explicit, local-policy-owned, and weaker than the published artifact itself.

## 2) OpenURI subject-echo posture pressures digest-first / redaction-first publication receipts

SlopOS also freezes the rule that full launched URIs stay request-local and that durable audit should prefer digests or bounded redacted summaries over verbatim subject text.
That matters a lot for shell+terminal sharing.
A chapter often contains hosts, paths, tokens, query strings, prompts, or transient local labels.
So a publication receipt should not casually turn all of that into a durable literal echo plane.
Schell should prefer exact local review plus digest-first/redaction-first publication receipts when the artifact crosses a durable or network boundary.

## 3) OpenURI materialization posture says publication is not equivalent to object transfer or docref minting

SlopOS refuses the move where generic URI launch quietly becomes download, local staging, or docref minting.
That import is valuable here too.
Publishing a terminal chapter or replay capsule should not quietly mint durable access to every underlying local file, pipe, socket, service endpoint, or remote target mentioned inside it.
A published artifact is one explicit exported object.
Any stronger local-object transfer still belongs on a separately named file/document workflow.

## 4) Artifact-reference posture pressures content-addressed publication handles

SlopOS's CH-AREF posture is another clean clue.
Large or external artifacts should be referenced by content identity, while locators remain hints rather than truth.
That maps beautifully onto Schell replay capsules and publication cards.
A shared terminal artifact should ideally have a digest-bearing identity and visible locator/host separation so the archive can say “this exact artifact” without pretending the current host or URL is the only truth.

## 5) Launch-completion and callback posture pressure humility about viewership

SlopOS already says mediated launch outcomes are admission-scoped and do not prove that a handler completed, stayed live, or that the user definitely saw something.
That pressure imports directly into live sharing and publication analytics.
Schell should not say “shared and viewed” when it only knows “publication link minted” or “live share lane opened.”
Audience consumption, attention, and durable downstream copies are different truths.

## 6) Resource-grant posture says published terminal artifacts must stay weaker than underlying host/session authority

SlopOS refuses the move where a generic route silently becomes a resource grant or durable handle transfer.
That is exactly the right discipline for shell sharing.
A published chapter or replay capsule should not silently give the viewer ambient access to the live cwd, the live credentials, the remote service, or the repo tree that originally produced it.
If Schell later supports richer attach or continue flows, those need separately named grants.

## 7) Web-permission and embedded-web-surface posture pressure explicit network/publication boundaries

SlopOS is very strict that generic open does not become a portable web-permission broker or embedded-web control plane.
That means Schell should be strict too whenever a share lane crosses into browsers, embeds, or hosted viewers.
A publication card should say whether the artifact is local-only, LAN-visible, remote-relayed, or publicly hosted, and it should not flatten those hosting choices into the same confidence badge.

## 8) Background/job posture says durable live share is stronger than chapter export

SlopOS already distinguishes foreground requests, job requests, and longer-lived background state.
That same discipline belongs here.
A local exported chapter is not the same as a replay capsule that can be opened later.
A replay capsule is not the same as an actively shared live session that remains viewable or steerable while the shell keeps running.
Schell should keep those lanes separate instead of collapsing them into one “share terminal” verb.

## 9) What SlopOS most strongly warns us not to do

Under current SlopOS pressure, Schell should refuse:
- silently turning scrollback into a durable replay artifact,
- silently turning publication into ambient recent-items/history or reopen authority,
- durable literal subject echo for sensitive chapter contents,
- publication artifacts that quietly mint file/document/resource grants to the underlying local objects,
- and live share receipts that overclaim audience attention, completion, or revocation finality.

## 10) The clean import: share witnesses and publication humility

A SlopOS-compatible import now looks like this:
- every stronger share/export action carries an explicit **share witness**,
- local review buffer, local export, replay capsule, published chapter, and live share lane stay separately named,
- publication receipts prefer digests and bounded redacted summaries over raw subject echo,
- live share permissions stay explicit and weaker than implied host/session authority,
- and unpublish/revoke wording stays smaller than “all copies and memories are gone.”

## 11) Decision-light next move

A strong next move is to define one **share witness / replay capsule / publication humility** family that proves:
- local clipping,
- exact chapter export,
- replayable text-first casts,
- selective published permalinks or embeds,
- and live session sharing with explicit permission lanes
can coexist without turning Schell into an ambient publishing system or a hidden session-authority broker.

That keeps Schell ambitious while learning the right lesson from SlopOS:
**share and replay luxury are welcome, but durable history, literal subject echo, resource transfer, and live authority must stay separately named and separately admitted.**
