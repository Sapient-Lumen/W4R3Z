# Research synthesis — ratchet pass (2026-03-20)

This pass revisits the outside landscape with one bias:
**steal brilliant moves without freezing architecture too early.**

## What the current outside world is converging on

### 1) Terminals are getting semantic, not just prettier

The strongest convergence is around explicit shell integration.
WezTerm, Ghostty, VS Code, and Warp all benefit when the shell tells the terminal where prompts, inputs, outputs, and command boundaries are.
That is a strong external signal that Schell should not rely on prompt scraping if it can help it.

### 2) The best permission systems are action-timed

XDG portals and Android runtime permissions both reinforce the same posture:
ask when the user is doing the thing, ask narrowly, explain why now, and treat expiry / revocation as normal.
That maps directly onto reviewed shell actions better than startup-time grants do.

### 3) Interactive kindness is now table stakes

fish, modern terminals, and newer shell experiments all demonstrate that fast suggestions, completions, navigation, and redraw behavior are not ornamental.
They are the ergonomics budget that keeps a strict shell from feeling punitive.

### 4) Structured composition helps, but giant object universes are expensive

Nushell and PowerShell remain important proof points that pipelines do not need to be only byte strings.
But they are also warnings: runtime object models and large command surfaces become architecture surprisingly quickly.
Schell should import **inspectability** before it imports **mass**.

## Moves worth stealing right now

- semantic prompt/input/output/review/receipt marking;
- block-level navigation and selection;
- exact-artifact review cards;
- rich-but-inert suggestions;
- structured tracing for receipts and replays;
- use-time, scope-limited authority requests;
- smaller quoting / expansion semantics.

## Moves worth refusing right now

- freezing the final terminal protocol;
- copying a giant host object model;
- embedding a full general-purpose language into bootstrap Schell;
- turning TUI polish into a correctness dependency;
- treating crate availability as architecture.

## Rust-side read

The current Rust ecosystem is good enough to let Schell prove interaction before infrastructure:

- `reedline` is likely enough to test humane line editing,
- `tracing` is likely enough to test lineage and receipt instrumentation,
- `cargo-deny` is likely enough to make dependency policy part of hygiene,
- while `ratatui`, `crossterm`, and `portable-pty` should remain candidates until the reviewed interaction proves it needs them.

## Net effect on the archive

This research pass strengthens three local moves:

1. define a **portable text truth surface**,
2. sketch a **minimal semantic transport** for richer terminals,
3. and promote one first reviewed interaction into a real prototype target.
