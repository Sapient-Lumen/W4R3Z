# Research synthesis — 2026-03-23 — pass CXXXVI

This pass sharpens one fresh shell+terminal lesson from current upstream docs:
**reusable command-like objects are multiplying, but they are not all the same class of truth.**
Pinned launch entries, command panes, prompts, snippets, and search results can all feel “command-like” while differing radically in mutability, launch footing, and liveness.

## 1) Zellij turns commands into first-class pane objects, not just history lines

The current Zellij features docs explicitly describe **command panes** as treating commands as first-class pane citizens.
The listed benefits are revealing:
- exit code for completed commands,
- rerun with a single Enter,
- start commands suspended and run on demand,
- keep frequently used commands accessible in the layout.

That is a very strong product clue for Schell.
It means a terminal can treat a runnable command object as part of layout *before* spending the action.
The crucial design lesson is that **layout presence and execution state should be separate fields rather than one blurry “command is here” myth.**

## 2) WezTerm's launcher model keeps launch recipes explicit

WezTerm's `launch_menu` docs say each launcher entry is a `SpawnCommand` object.
The examples show explicit labels and explicit argument arrays.
That matters because it keeps launcher entries closer to an exact launch recipe than to shell folklore.

This is especially valuable for Schell because it suggests a humane but disciplined path:
- save reusable launch cards,
- make their args/cwd/target posture explicit,
- and let the UI stay luxurious without hiding what exactly will launch.

## 3) kitty shows both the power and the danger of terminal-side launch recipes

kitty's `launch` action is very powerful.
Its docs show launching different programs, reusing current working directory, and even sending current screen or scrollback into the started process.
Special placeholders such as `@selection` make the launch recipe even more dynamic.

That is useful, but it also teaches an important Schell warning:
**terminal-side launch convenience can quietly borrow more basis than the operator realizes.**
If a command object depends on current selection, scrollback, or source-window context, that should be visible in the card's basis rather than hidden inside convenience syntax.

## 4) Warp keeps shared prompts/workflows softer than exact launch

Warp's current docs now show a dense ecosystem of command-like objects:
Command Search spans command history, workflows, environment variables, notebooks, prompts, and agent history.
But choosing a result still lands it in the Input Editor instead of auto-running it.
Its Prompt docs say prompts are searchable, can be inserted from Command Search/Palette, and then are pasted into active terminal input where the user can adjust arguments before running.
The same docs also say shared prompts sync immediately for team members and editing conflicts require checking out the latest version.

This is an excellent reminder that some reusable command-like objects are **mutable shared recipes**, not exact reviewed launch basis.
Schell should probably preserve that distinction instead of flattening every reusable thing into one bucket.

## 5) Windows Terminal is also building reusable command objects into the UI

Microsoft's Windows Command Line posts for Terminal Preview 1.21 and 1.22 continue this pattern.
The 1.21 release introduced Scratchpad, which is a non-terminal drafting surface.
The 1.22 release introduced the Snippets Pane.
Even from those high-level release notes, the lesson is obvious:
modern terminal UX is investing in persistent or semi-persistent command-adjacent objects that are **near execution** without already being execution.

## 6) The ecosystem now suggests a richer ladder than “history vs live”

A better Schell ladder probably includes at least:
- **draft text**,
- **exact launch card**,
- **floating shared recipe**,
- **suspended ready-to-run card**,
- **live room/run**,
- **spent action/receipt**,
- **later rerun offer**.

The exact names can remain open.
But the product truth is already visible across current tools.

## 7) The stealable move is not more automation — it is better command-object honesty

The best move to steal is small and sharp:
**make reusable command objects visible and delightful, but force them to confess mutability, launch basis, liveness, and whether they are suspended, live, or already spent.**

That unlocks a lot:
- pinned build/test/dev-server cards,
- layout-resident suspended commands,
- clearer launch menus,
- safer rerun UX,
- easier shared-recipe discovery,
- and nicer command-object reuse without fake certainty.

## 8) Compact conclusion

Zellij proves a command can be a first-class pane object and still start suspended.
WezTerm proves launcher entries can be explicit structured launch recipes.
kitty proves terminal launch power can borrow selection/scrollback/cwd context and therefore needs basis honesty.
Warp proves many reusable command-like objects are mutable shared recipes that still land in editable input before run.
Windows Terminal keeps adding scratchpad/snippet surfaces around the same seam.

Schell should take the hint.
It needs a first-class split between **exact launch card**, **floating shared recipe**, **suspended runnable card**, **live room**, and **spent action**, so recurring-command luxury can grow without letting “saved here”, “pinned in layout”, or “rerunnable later” impersonate live reviewed truth.
