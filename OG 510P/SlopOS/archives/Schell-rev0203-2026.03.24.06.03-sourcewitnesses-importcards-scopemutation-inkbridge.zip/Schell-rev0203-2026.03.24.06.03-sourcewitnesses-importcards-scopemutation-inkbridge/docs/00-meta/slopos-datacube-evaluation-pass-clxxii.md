# SlopOS datacube evaluation — pass CLXXII

This pass asks a narrower and safer question than "should Schell make notification clicks, shortcuts, chooser accepts, and browser returns feel more magical?"
The better question is:
**what is the smallest durable residue object Schell can add so baton-bearing activation flows leave behind honest evidence about what actually happened without turning SlopOS or Schell into a giant foreground-control or callback platform?**

## 1) SlopOS still forbids treating open/reveal as portable focus authority

SlopOS already keeps this boundary sharp.
The OpenURI activation-control boundary explicitly refuses to turn mediated open into portable activation-token authority, foreground-control authority, or a frontmost receipt.
The callback-reentry boundary likewise refuses to smuggle a second rendezvous protocol through generic URI opening.

That means Schell should not treat notification clicks or browser returns as one magical "the right thing is now active" event.
The product surface needs a smaller and more honest residue.

## 2) Steward already provides the adjacent shape

The Steward companion is especially aligned in this pass.
Its activation-cause posture says concrete runtime cycles should have a small start-cause explanation.
Its activation-receipt posture says delivered startup material, acknowledgement, and foreground/focus authority remain separate truths.
Its request-activation posture also keeps attention/focus hints freshness-scoped and separate from lifecycle truth.

That is almost exactly the shape Schell needs after shell+terminal activation flows.
A tiny exact-run residue object should say what target was attempted, what baton was present, and what acknowledgement/control result was actually observed.

## 3) The companion-safe answer is a tiny activation receipt

The smallest useful import is an **activation receipt** for baton-bearing activation paths.
It should say:
- what exact target was meant,
- what baton or activation source was involved,
- whether the baton was consumed, regenerated, ignored, denied, or expired,
- whether the target was merely revealed, newly opened, or newly launched,
- whether active control actually arrived,
- and what downgrade floor remains honest now.

That is enough truth without creating a giant focus-control substrate.

## 4) ViewFS, Harbor, Helm, and Ward improve the shape

- **ViewFS** keeps basis/apply/receipt classes distinct, which strongly pressures Schell not to flatten baton spend, target resolution, and actual control into one cozy `activated` row.
- **Harbor** keeps risk stoplines visible, making `foreground denied` or `retry needs fresh baton` useful, first-class confessions.
- **Helm** keeps settlement narrower than source-side success, which means an activation receipt must not quietly become durable completion, endorsement, or receiver truth.
- **Ward** keeps continuous signals and attenuation posture visible, which pressures Schell to preserve denial residue without pretending the baton remains live forever.

## 5) Companion-safe no-regret moves

Schell does **not** need a larger window-manager treaty, callback platform, or durable activation inbox next.
It only needs:
- a tiny activation receipt family,
- visible baton-spend posture,
- separate reveal/open versus foreground/control result,
- `retry with fresh baton` as a named action,
- and transcript-safe residue that preserves outcome without serializing platform-private token material.

Those moves import SlopOS discipline while staying reversible.

## 6) Compact conclusion

The companion cubes keep saying the same thing in different accents:
**activation-bearing input is real, but the durable thing we should keep is evidence about what happened, not a lingering claim to control.**

So the Schell-safe answer is small:
**add a tiny activation receipt that records baton spend, exact target resolution, reveal/open result, foreground/control result, and honest residue floor.**
That gets the shell+terminal closer to “super awesome” without forcing early closure on cross-platform focus policy, callback design, or one final activation storage plane.
