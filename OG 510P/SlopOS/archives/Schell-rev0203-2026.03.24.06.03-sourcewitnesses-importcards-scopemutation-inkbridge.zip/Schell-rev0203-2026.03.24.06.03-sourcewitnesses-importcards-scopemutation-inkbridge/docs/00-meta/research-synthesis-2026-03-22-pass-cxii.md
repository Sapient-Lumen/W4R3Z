# Research synthesis, pass CXII (2026-03-22)

This pass keeps one narrower lesson explicit:
**the shell+terminal should steal semantic command frames, sticky command context, prompt-local editing, and even some predictive comfort — but it should keep transcript truth small, make richer metadata live in explicit sidecars, and mark stale or provisional chrome before it flatters the operator.**

Current terminals are converging on a real pattern.
WezTerm, Windows Terminal, Ghostty, VS Code, fish, and iTerm2 all get much better once the shell can tell the terminal where prompts, commands, cwd shifts, and command-output regions really are.
That enables jump-to-prompt, same-cwd spawn, command-output selection, sticky command headers, recent-command recall, and prompt-local cursor moves.
Those are not toys.
They are the modern humane baseline.

The trick is not to confuse that semantic comfort with execution truth.
`tmux` control mode is still a useful reminder that text-first parseable side channels can go very far without forcing one giant opaque RPC stack.
Mosh is still a useful reminder that prediction can feel magical if it stays visibly provisional.
And recent terminal security fixes keep reminding us that pasted or injected control text, silent translation, and untrusted escape-driven state are not a harmless detail.

## 1) Command frames are worth stealing as first-class navigation units

The strongest modern idea in terminal land is simple:
**one command should feel like one chapter.**
That chapter may include:
- prompt start/end,
- active editable input,
- exact command line when attested,
- cwd / peer grounding,
- output region,
- exit or finish marker,
- and maybe small local render extras such as quick fixes or capture cards.

That cluster is already proving itself in the wild.
Schell should steal it without apology.

## 2) The transcript core should stay smaller than the luxury around it

The shell+terminal should not answer this by making the terminal transcript itself giant, lossy, or renderer-dependent.
A better pattern is:
- keep the replay-stable transcript and exact reviewed command truth small,
- hang timing, marks, sticky-header hints, output grouping, and richer browsing metadata off explicit sidecars,
- and make it obvious which facts are shell-authenticated, locally inferred, restored, or imported.

That leaves room for command decks, sticky command headers, scrollbar marks, capture cards, and replay aids without making one emulator's UX metadata the deepest truth surface.

## 3) Sticky context is good, but Schell should add stale fences

Sticky scroll, pinned command headers, scrollbar marks, and command-local quick fixes are excellent ideas because they keep long output attached to its originating command.
But they also create a new failure family:
**historical context that looks live.**

So Schell should likely add explicit stale/fresh posture to any sticky command chrome.
A header may be:
- live-shell-authenticated,
- historical-but-exact,
- restored,
- inferred,
- or provisional.

That one bit of honesty will prevent a lot of future confusion.

## 4) Prompt-local power should depend on active-prompt truth

Prompt-local cursor moves and click-to-edit are delightful when the shell can attest where the active prompt really is.
They are much less safe when inferred from old output or relayed weakly through wrappers and hops.

So prompt-local power is worth stealing, but only with an explicit gate:
**historical output is navigable; active prompt state is editable only when the shell can actually say it is the active prompt.**

## 5) Predictive comfort should stay visibly provisional

Mosh points to a class of ideas Schell should not ignore:
roaming continuity, speculative local echo, and “the network is slow but I still feel in control.”
That is brilliant.
It is also dangerous if prediction pretends to be committed remote truth.

So Schell should keep any future local prediction or latency-masking comfort obviously provisional, source-labeled, and easy to compare against later exact receipts.

## 6) Silent translation is one of the old traps

The past keeps teaching the same lesson in different costumes:
- hidden shell reparsing,
- startup-time injection,
- control-sequence surprises,
- path translation folklore,
- pasted-text ambiguity,
- and display labels that overclaim exact state.

The common failure is not “rich UX exists.”
It is **silent translation across a boundary that the operator never got to see.**
So Schell should keep translation basis, freshness, and authorship visible whenever the terminal is being clever.

## 7) Compact design-phase answer

Schell does not need to decide the final shell-integration treaty, final mux protocol, final replay format, or final predictive-echo stack right now.
It only needs a smaller research-safe answer:
- first-class semantic command frames,
- explicit sidecars for richer browsing metadata,
- sticky context with stale fences,
- prompt-local editing gated on active-prompt truth,
- provisional badges for latency-masking or prediction,
- and transcript-first humility when luxury and truth diverge.

That is enough to make the shell+terminal feel dramatically better while keeping the deep architecture open.
