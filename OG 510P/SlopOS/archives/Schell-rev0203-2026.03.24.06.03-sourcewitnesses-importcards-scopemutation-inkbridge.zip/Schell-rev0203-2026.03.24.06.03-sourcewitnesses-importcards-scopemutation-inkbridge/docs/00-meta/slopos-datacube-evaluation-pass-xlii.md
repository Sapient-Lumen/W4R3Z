# SlopOS datacube evaluation, pass XLII

This pass keeps one bounded thesis in focus:
**SlopOS already separates request identity, background authority, activation, and launcher/session liveness much more carefully than traditional shells. Schell should import that discipline so foreground tty control, shell-tracked background jobs, detached continuity, and promoted durable work stop collapsing into one job-control folklore story.**

That is an excellent ratchet while SlopOS is still design-phase too.
It keeps options open.
It also translates directly into humane shell+terminal moves.

## 1) D-CAPSHELL already rejects ambient launcher/session-liveness folklore

RFC-0115 repeatedly normalizes away ambient launch state that other systems often inherit accidentally.
One especially relevant move is the explicit Phase 1 posture that `capshell.exec` adds **no reviewed die-with-parent / detach surface** and must not quietly inherit wrapper-imposed parent-death coupling.
That is a powerful lesson for Schell.

Foreground launch, shell parentage, session death, and durable continuation are not one thing.
The shell+terminal should stop telling one flattering story where “still around after the prompt returned” means the same across all these cases.

## 2) D-JOBS says durable background work should be portal-mediated, attributable, bounded, and cancellable

RFC-0096 is almost the perfect companion to classic shell job control.
It treats background work as an explicit portal workflow with bounded descriptors, constraints, cancellation, and runtime limits.
It explicitly rejects ambient cron/alarm folklore and makes job requests descriptive rather than authority-bearing.

That suggests a clean import for Schell:
- tty-bound job control is good for local interactive continuation,
- but long-lived or policy-bearing work should have a **promotion path** into an explicit job/service lane rather than pretending the shell job table is a general scheduler.

## 3) D-BGLEASE keeps background presence a separate authority seam

RFC-0103 treats running in the background and autostart as leased, audited authority.
That matters for the terminal too.
A local shell background job is not the same as a user-reviewed background-presence grant.
A disowned process is not the same as approved durable background execution.
A resumed session is not proof that a current grant still exists.

Schell should import that distinction directly.
Background presence should stay stronger and more explicit than ordinary `&` job control.

## 4) SlopOS repeatedly distinguishes request identity from live state, and that maps cleanly onto shell jobs

Across the datacube, SlopOS keeps warning that descriptors and receipts are often historical or request-local rather than a current-state oracle.
That is exactly the right warning for shell job control too.
A shell’s job entry, a detached session name, a resurrected pane, or a promoted unit reference may all be useful continuity anchors.
They are not all equally strong evidence that the work is still live, foreground-owning, or user-visible now.

That points straight toward witness posture in Schell rather than one raw “job id” story.

## 5) A shell+terminal-specific import emerges very cleanly

The strongest import is small and practical:
- make **foreground tty claim** an explicit shell-known witness,
- keep **stopped**, **shell-background-tracked**, **shell-background-untracked**, **detached continuity**, **promoted supervision**, and **restored historical continuity** visibly distinct,
- add a visible **promote this work** rail when the operator actually wants durable continuation,
- and keep prompt return weaker than exact completion truth.

That is enough to improve Schell a lot without freezing one service manager, one mux daemon, or one cross-platform process-group API.

## 6) The no-regret move

Schell does not need a final process-object ontology right now.
It needs:
- one small **TTY/process-group witness** family,
- one explicit continuation ladder,
- one visible split between **shell tracking**, **detached continuity**, and **supervised promotion**,
- and one refusal to let `&`, `disown`, `nohup`, detach, and resurrection keep pretending to be the same story.

That is a clean SlopOS import, and it is exactly the sort of careful, decision-light move this archive should keep preferring.
