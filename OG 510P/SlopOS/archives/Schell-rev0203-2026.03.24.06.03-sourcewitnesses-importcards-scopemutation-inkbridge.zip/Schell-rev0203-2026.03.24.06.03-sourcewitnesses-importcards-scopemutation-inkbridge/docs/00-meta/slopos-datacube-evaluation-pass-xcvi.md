# SlopOS datacube evaluation, pass XCVI (2026-03-22)

This pass evaluates one narrower question against the current SlopOS archive:
**what does the companion already teach Schell about semantic shell integration, remote helper posture, and visible downgrade across hops?**

The answer is stronger than it first appears.
**SlopOS is already pressuring Schell to treat semantic shell integration as an explicit interface/adaptor seam with local acceptance and visible downgrade, not as an ambient terminal superstition.**

## 1) The companion already rewards explicit interface identity over flattering fallback

Across the archive, SlopOS keeps preferring exact interface identity, explicit provider/adaptor seams, and deterministic refusal of unknown or unsupported shapes over guess-and-hope compatibility.
That matters directly here.
Semantic prompt/input/output marks are useful, but the companion's design instinct says not to flatten these nearby truths:
- a native shell-known interface,
- a terminal-injected helper,
- a mux-relayed mark stream,
- a remote wrapper that copied terminfo or shell helpers,
- and a heuristic renderer guess.

For Schell this means semantic integration should become a named witness with source and acceptance posture, not just a feeling that the terminal seems command-aware.

## 2) Launch-boundary posture already warns against hidden bootstrap ownership

The companion's capshell launch-boundary family keeps insisting that ambient startup/session state should not quietly cross the execution seam.
Exact exec identity matters.
Command-string folklore is refused.
Inherited environment/session baselines are scrutinized or denied.
Learn mode remains observational and must not become an authority side channel.

That strongly pressures Schell not to treat terminal-injected shell integration, startup hooks, or remote-wrapper comfort as invisible neutral plumbing.
Those things may still be worth doing.
But if they materially affect prompt semantics, cwd reporting, or command boundary truth, the shell+terminal should say so plainly.

## 3) Local acceptance over imported claims maps cleanly onto semantic integration

SlopOS repeatedly prefers imported evidence staying distinct from local acceptance.
That philosophy maps cleanly onto semantic shell integration.
A terminal may import:
- prompt marks,
- exact command lines,
- cwd reports,
- peer/host summaries,
- or copied terminfo / wrapper-projected compatibility.

But Schell should still keep separate:
- what was claimed,
- how it arrived,
- what local acceptance posture applies,
- and which stronger actions remain blocked.

That is the same discipline the companion uses elsewhere: exact imported evidence is valuable, but spending stronger meaning or authority remains a local decision.

## 4) Adapter confession is more companion-compatible than transparent magic

The companion already likes explicit adapters better than hidden fallback.
That makes remote and mux semantic integration much easier to judge.
A mux-relayed mark, copied remote terminfo, injected shell helper, or helper-wrapped `ssh` flow is not inherently bad.
The problem is only when it becomes invisible and starts impersonating native shell truth.

For Schell this suggests a very companion-compatible import:
- one integration witness,
- one hop path,
- one downgrade reason list,
- and one stronger distinction between shell-authenticated command truth and merely transport-preserved comfort.

## 5) The companion also sharpens the action boundary

SlopOS's safe-open and portal posture families keep insisting that adjacent actions remain separately named.
That pressures Schell to keep semantic integration actions separated too.
For example:
- selecting one command chapter,
- copying its output,
- inserting its command into the live prompt,
- deriving a fresh reviewed action,
- and actually executing

should not silently collapse merely because the command block is visually rich and command-aware.
Semantic integration can improve confidence and ergonomics, but it should not erase action boundaries.

## 6) Compact conclusion

SlopOS is still design-phase, but it already supplies a very useful rule for Schell's shell-integration seam:

**semantic integration should be treated as an explicit interface/adaptor witness with local acceptance, visible transport/hop posture, and downgrade honesty — not as ambient terminal magic that automatically counts as native shell truth.**

That is a careful import because it lets Schell steal the delight of modern command-aware terminals while still keeping startup ownership, helper wrapping, remote comfort, and heuristic fallback visibly weaker than exact reviewed shell truth.
