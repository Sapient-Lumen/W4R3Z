# SlopOS datacube evaluation, pass CIX (2026-03-22)

This pass evaluates one narrower question against the current SlopOS archive:
**what does the companion already teach Schell about bracketed paste, multiline send, clipboard readback, sink-grant discipline, and the danger of flattening typed text and pasted data into one input story?**

The answer is stronger than it first appears:
**the companion wants clipboard and transfer behavior to remain explicit, sink-triggered, non-ambient, and weaker than reviewed execution authority.**

## 1) D-PLUMB already gives Schell the right clipboard lesson

`transfer-portal-posture-v0.md` says several things that map almost directly onto shell paste design:
- no ambient clipboard readers, watchers, or history constructors,
- copy publishes an offer rather than a cross-component grant,
- paste/drop/share is the exact sink action that grants delivery,
- cross-boundary transfer is short-lived and auto-clear by default,
- and the whole family remains manual-only in Phase 1.

That is almost a perfect design-phase-safe rule set for Schell.
It means the shell+terminal should absolutely preserve paste comfort, but it should not treat clipboard state as ambient authority and it should not flatten user-triggered paste into generic background data access.

## 2) The companion also rejects ambient host↔guest clipboard mythology

`microvm-clipboard-dragdrop-posture-v0.md` keeps host↔guest clipboard and drag/drop integration explicitly non-portable and refuses to let desktop-helper convenience become reviewed transfer meaning.
That is a great pressure source for Schell because remote panes, nested terminals, VM helpers, and mux buffers all create the same temptation: report “pasted” or “copied” success without naming the bridge.

So the companion-compatible move is obvious:
- keep local paste,
- UI-sent paste,
- remote/mux-local replay,
- host↔guest helper transfer,
- and ambient clipboard query
separately named instead of compressing them into one fuzzy input lane.

## 3) The companion rewards sink-specific grants rather than ambient rights

SlopOS keeps making one design preference clear across portals, transfers, and mediation boundaries:
**delivery should happen when a named sink acts, not because the system quietly decided the data was generally available.**

Applied to Schell, that suggests a very good rule:
- typed keystrokes are one ingress family,
- pasted text is another,
- clipboard query is a stronger access request,
- and multiline delivery into a live target should be modeled as a target-specific grant rather than as blind replay.

That is exactly the same moral structure as D-PLUMB's copy-offer-versus-sink-grant rule.

## 4) Manual-only and transcript-friendly still matter here

The companion's manual-only posture is also useful.
Schell does not need a hidden automation lane for paste transforms or clipboard reads to make this seam better.
It only needs a few bounded witnesses and transcript facts:
- pasted as one edit,
- multiline held for review,
- clipboard query denied,
- quoted insert granted,
- remote bridge only,
- or target refused direct multiline insert.

That keeps the design honest even in plain logs and even when the richer terminal is gone.

## 5) The companion-compatible answer is smaller than a final clipboard subsystem

Schell does **not** need to choose:
- one final clipboard backend,
- one final OSC 52 story,
- one final multiline-paste policy engine,
- one final remote/mux bridge treaty,
- or one final paste-history architecture

to stay aligned with SlopOS.

It only needs a few bounded rules:

### A) Typed text, pasted text, selected-text send, and clipboard query stay separately named
Do not let them share one generic authorship badge.

### B) Copy-offer versus sink-grant logic survives at the shell boundary
A user-triggered paste or send action should be the delivery moment, not proof of ambient read authority.

### C) Multiline delivery becomes an explicit target-aware grant
Literal insert, quote, scratch, hold, and deny should be visibly different moves.

### D) Bridge posture stays visible
Remote, mux-local, host↔guest helper, and local-only input stories should not collapse together.

### E) Transcript truth stays compact and durable
A transcript should be able to say what kind of ingress happened, whether it was bracketed, and whether clipboard query was involved.

## 6) Compact conclusion

The SlopOS-compatible answer is not “build a giant clipboard shell.”
It is:
**make bracketed paste posture, multiline grants, target-aware transforms, and clipboard-query gates explicit witnesses while keeping raw clipboard backends, remote bridges, and helper integrations clearly weaker than reviewed shell meaning.**

That is a strong design-phase-safe move because it improves a very common shell failure surface right away while leaving the final clipboard backend, paste-history engine, remote bridge policy, and approval UI open.
