# SlopOS datacube evaluation

This surface records what the current SlopOS archive seems to be doing **well enough to trust provisionally**, where it still appears intentionally incomplete, and what that implies for Schell.

## 1) What SlopOS already does unusually well

### Negative constitution before positive ergonomics

SlopOS is unusually strong at saying what must **not** be ambient before it says what the final operator experience will be.
The `capshell` surfaces repeatedly close drift seams around:

- command strings,
- shell-style expansion,
- exec selection,
- startup environment,
- cwd/root behavior,
- descriptor inheritance,
- terminal/job control,
- background/autostart policy,
- receipts,
- and wallet semantics.

That is exactly the right order for a design-phase system that cares about trust boundaries.

### Discovery surfaces exist

The `capshell-launch-boundary-index.md` file is especially valuable because it turns many small postures into one re-openable discovery surface.
That reduces a common archive failure mode: the truth becomes scattered across too many tiny docs to hold in working memory.

### Request identity is kept distinct from live state

The background request/state split is excellent.
SlopOS explicitly refuses to let a request key masquerade as current grant truth.
That matters because shells and terminals often blur “I asked for this once” into “this is active now.”

### Receipts are treated as audit objects, not magic permission tokens

The outcome-receipt and sidecar boundaries show strong discipline.
Stable replay identity is kept small and digest-addressed, while richer structure is pushed into explicit sidecars rather than silently inflated into the core result contract.

## 2) What SlopOS still seems intentionally unfinished

### Final operator UX is still open

SlopOS is much more specific about execution invariants than about the interactive operator experience.
That is healthy.
It means Schell should not over-read the archive and pretend syntax or terminal behavior are already settled.

### The proving interactions are not yet front-and-center

The archive is rich in posture docs, but it still needs more obvious “here is the humane operator path” examples.
Schell should help supply those without laundering them into irreversible semantics too early.

### The shell/terminal split is still a design question

SlopOS tells us what launch behavior may not do ambiently.
It does not yet fully determine whether the custom terminal, the shell language, and the review UI are one product or three cooperating layers.

## 3) What Schell should take from this

### Schell should begin as an operator interface for reviewed actions

The safest reading is that Schell should begin life as:

- an intent authoring surface,
- a review surface,
- a replay/receipt browser,
- and only secondarily as a classic shell language.

### Schell should inherit SlopOS's honesty about non-decisions

The archive should stay explicit whenever it does **not yet know**:

- the final surface syntax,
- the runtime object model,
- the terminal protocol,
- the legacy compatibility story,
- or the full scripting model.

### Schell should help SlopOS by providing humane interaction proofs

The big contribution Schell can make back is not more negative law.
It is proof that reviewed actions, denials, receipts, leases, and background state can feel better than shell folklore in day-to-day use.
