# Research synthesis — 2026-03-23 — pass CLXXV

This pass sharpens one fresh lesson from current terminal and shell-integration docs:
**modern terminals already have a practical readiness ladder, but most products still make operators infer it from whether a pane exists instead of saying plainly when prompt-aware truth has actually arrived.**

## 1) VS Code already treats shell integration as a quality level, not just a yes/no flag

VS Code documents that shell integration enables working-directory detection, command detection, decorations, and navigation.
Recent release notes then sharpened this into explicit quality levels: rich, basic, and none.
Its run-in-terminal flow now even waits for shell integration activation with a configurable timeout.

That is a strong clue for Schell.
A launched terminal surface is not yet the same thing as a prompt-ready, command-aware, rich shell-integrated lane.

## 2) Ghostty makes prompt-aware luxury depend on shell integration and calls out shell-switch drift

Ghostty's shell integration docs tie prompt-aware luxury directly to semantic shell help: prompt jumps, command-output selection, same-cwd new terminals, prompt click movement, and prompt-aware resize behavior.
The docs also explicitly recommend manual sourcing when switching shells inside Ghostty.

That means readiness is not a one-time launch fact.
It can degrade or need reacquisition mid-session.

## 3) WezTerm keeps the substrate small, but the readiness dependency is obvious

WezTerm's shell integration page is refreshingly minimal:
OSC 7 for cwd, OSC 133 for Input/Output/Prompt zones, and OSC 1337 for extra user vars.
Those sequences unlock same-cwd spawn, jump-to-earlier-command, and select-complete-output comfort.

This is exactly the kind of pressure Schell should import.
The shell+terminal should be able to say when those semantics are currently present, stale, partial, or missing.

## 4) kitty shows that many delightful prompt-local actions are actually readiness-gated

kitty's shell integration docs and config reference make the dependencies unusually visible.
Turning off cwd or prompt marks disables families of nice actions.
Prompt-local click-to-move also explicitly depends on shell integration.

That is not bad news.
It is the shape of an honest product.
Great terminal luxury is often contingent on prompt-aware semantic footing.

## 5) fish 4.5.0 proves freshness needs to be renewed, not assumed

fish now reports cwd on every fresh prompt via OSC 7 and marks prompt end via OSC 133.
The release notes explicitly say this fixes cases where a child process like ssh left behind stale cwd.

That is one of the clearest possible signals for Schell.
The right threshold is not merely “the pane once had cwd.”
It is “the current prompt has freshly reasserted it.”

## 6) The no-regret Schell move is a tiny readiness strip

Putting these together suggests a better next move than more replay or routing cleverness.
Schell should add a tiny **readiness strip** for newly launched, restored, reattached, or repaired rooms and lanes.
It should say:
- whether the PTY/runtime surface exists,
- whether a prompt is currently caught,
- whether cwd and prompt markers are fresh enough for richer affordances,
- what integration quality is currently available,
- and what the strongest honest next move is now.

## 7) Compact conclusion

VS Code already names shell-integration quality and waits for it.
Ghostty explicitly ties shell-aware luxury to integration and warns about shell-switch scenarios.
WezTerm keeps cwd and prompt zones as the minimal enabling substrate.
kitty shows that prompt-local comfort depends on those semantics.
fish proves freshness must be reasserted at each fresh prompt.

So the next no-regret Schell seam is not a bigger action engine.
It is **readiness strips, prompt-caught posture, and integration-truth humility** so a visible room can cheaply say whether it merely exists, whether the shell is really ready, and which luxuries are honestly live right now.
