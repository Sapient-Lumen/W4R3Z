# Research synthesis, pass XXI (2026-03-21)

This pass focuses on another load-bearing seam:
**the best current shells and terminals keep getting better at suggestions, quick fixes, and exact handoff — but the strongest lesson is not “auto-heal everything.” The strongest lesson is to keep help fast, exact, source-labeled, and inert until the operator explicitly accepts it.**

## 1) VS Code shows how much value shell-known quick fixes unlock

VS Code's terminal shell integration docs say Quick Fixes scan command output and present actions that have a high likelihood of being the next thing the user wants to do. That is a strong product clue for Schell: once the shell/terminal knows command boundaries and outcomes, post-failure help becomes much more useful than raw scrollback grep. See: https://code.visualstudio.com/docs/terminal/shell-integration

## 2) VS Code also shows the right handoff shape

VS Code's October 2025 update says a tracked terminal command can be attached to chat as context, sharing the command line, captured output, and exit code. That is one of the clearest modern hints for Schell: troubleshooting handoff should be an exact packet, not a paste ritual. See: https://code.visualstudio.com/updates/v1_106

## 3) Shell integration is now the foundation, not a side feature

VS Code's August 2025 update says shell integration is the foundation for sticky scroll, quick fixes, and agent mode understanding of what is happening inside the terminal. That matters because it reinforces a Schell theme we should keep stealing: nice post-command UX gets much safer once the shell tells the terminal what actually happened. See: https://code.visualstudio.com/updates/v1_103

## 4) fish keeps the humane part honest: suggestions do not execute themselves

fish's interactive docs say autosuggestions are offered inline but do nothing unless the user explicitly accepts them. That is exactly the kind of historical lesson Schell should preserve: suggestions are powerful *because* they are inert until accepted, not because they are half-executed already. See: https://fishshell.com/docs/current/interactive.html and https://fishshell.com/docs/2.2/index.html

## 5) fish also treats responsiveness as a first-class design constraint

fish's design docs say syntax highlighting and autosuggestions must perform disk I/O asynchronously, and startup should minimize forks and disk I/O. That is a very important construction lesson for Schell: smart help is only delightful if it stays cheap enough to trust at prompt time. See: https://fishshell.com/docs/current/design.html

## 6) PowerShell separates prediction sources explicitly

PSReadLine's docs say Predictive IntelliSense can use history, plugins, or both as prediction sources. That is a useful design hint for Schell: proposal sources should stay source-labeled and swappable instead of becoming one mysterious oracle. See: https://learn.microsoft.com/en-us/powershell/module/psreadline/set-psreadlineoption?view=powershell-7.5 and https://learn.microsoft.com/en-us/powershell/module/psreadline/about/about_psreadline?view=powershell-7.6

## 7) PowerShell's predictor plug-in seam is another strong clue

Microsoft's predictor docs say a predictor is a binary module implementing `ICommandPredictor`. Schell should not copy that interface prematurely, but it should steal the architectural lesson: prediction sources can be explicit modules, and prediction itself does not need to be fused with execution authority. See: https://learn.microsoft.com/en-us/powershell/scripting/dev-cross-plat/create-cmdline-predictor?view=powershell-7.5

## 8) There is a very good Schell move hiding in the overlap

These sources point toward one compact Schell cluster:
- a shell-owned **failure packet** for the last exact command/outcome,
- **proposal-only repair cards** whose source is labeled (history / static recipe / agent / plugin / operator-authored),
- one **exact handoff bundle** for attaching command+output+exit+ground witnesses to a help lane,
- and one hard rule that no suggestion executes or widens authority without a fresh review path.

That would steal the right part of modern terminal UX without importing its slipperier assumptions.

## 9) The construction lesson from the past is sharper than it looks

Older shells often made two opposite mistakes:
- either they gave very little help, leaving users to rediscover the same failure patterns manually,
- or they encouraged ambient magic through rc hooks, aliases, wrappers, and history-driven surprise.

The better path is visible here now:
**keep the help, refuse the ambientness.**

## 10) A strong v0 cluster is small

A decision-light v0 cluster is probably enough:
- one failure-packet family,
- one repair-card ladder,
- one exact handoff-bundle shape,
- one suggestion-source badge,
- one compare-and-set apply rule,
- and one hold-card rule when the system has only heuristic confidence.

## 11) Decisions intentionally kept open

This surface does **not** freeze:
- one plugin API,
- one AI protocol,
- one global failure taxonomy,
- one repair marketplace or extension model,
- one result-sidecar format for every tool,
- or one ranking engine for history vs plugin vs agent suggestions.

The no-regret move is narrower:
**make suggestions and help bundles exact, cheap, and visibly inert until accepted.**
