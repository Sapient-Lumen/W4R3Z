# Research synthesis, pass CXXX (2026-03-22)

This pass keeps one narrower lesson explicit:
**runtime preservation should feel magical without quietly becoming live authority.**

The current shell+terminal ecosystem keeps converging on that lesson from several directions.
Ghostty's quick terminal preserves state between appearances, while its `window-save-state` option treats saved tabs, splits, and working-directory restoration as a separate configurable posture that still depends partly on shell integration.
Zellij's session-resurrection docs make the split even crisper: sessions are serialized to cache, resurrection can be disabled, viewport and scrollback serialization are optional deeper layers, resurrected commands sit behind a deliberate "Press `ENTER` to run..." gate, and the session manager keeps separate verbs for switch, resurrect, start new, kill active, and permanently delete exited sessions.
VS Code's terminal shell-integration docs keep command-local navigation and sticky-scroll memory valuable, but still weaker than the shell's current truth.
fish keeps autosuggestions humane precisely because they do nothing until accepted, and its `forward-char-passive` binding proves that motion and suggestion-acceptance do not have to collapse into one key.
kitty's hints mode shows how powerful visible-text selection can be, while also proving that Schell should separate inspect, insert, open, and run ladders instead of letting every hint act like one generic smart click.
Nushell keeps showing that a shell can preserve structure longer and choose when to render it into tables instead of flattening everything into text immediately.
PowerShell's transcript limitations remain the reminder that even a "transcript" may miss or reorder object output, so durable receipts still need shell-owned exactness instead of trusting renderer timing.

Taken together, the design-phase lesson for Schell is straightforward:

## 1) Hidden runtime state, resurrectable cache, and live sessions are different classes

A hidden quick terminal that reappears with the same running process is useful.
A serialized cache that can be reopened after a restart is useful.
A currently live attachable session is useful.
They are not the same fact and should not wear the same badge.

## 2) Start clean must be a first-class luxury

The ecosystem keeps adding restoration because people love continuity.
Schell should copy that comfort, but it should also make **fresh launch**, **attach live**, **restore view**, **resurrect with review**, and **forget/delete old residue** obviously different actions.
A clean start should be as easy to reach as a resurrected one.

## 3) Restoration depth needs visible posture

There is a real difference between restoring:
- layout only,
- working directory only,
- command identity,
- viewport,
- scrollback,
- and rerunnable command footing.

Schell should make that depth visible instead of calling all of it "restored session."

## 4) The best hinting is passive by default

fish's passive motions, kitty's visible-snippet selection, and VS Code's command-local navigation all suggest the same rule:
**selection and navigation should usually be passive, while stronger actions stay explicit.**
That is one of the cleanest ways to make a shell feel super awesome without creating hidden execution.

## 5) Structured output should stay inspectable before being flattened

Nushell's tables, command-local sticky-scroll ideas, and captured-output tools all point toward a shell+terminal that remembers more shape than plain text.
But Schell should preserve that shape as inspectable object or chapter posture first, then render or export it, rather than pretending every visible row is already a durable authority-bearing object.

## 6) Compact answer

Schell does **not** need a final session manager, persistence backend, or notebook/workflow merger next.
It only needs one bounded move:
- runtime-preserved lockers,
- resurrectable lockers with visible depth,
- explicit clean-start and forget/delete rails,
- passive suggestion/hint ladders,
- and a rule that restored or selected context stays weaker than fresh reviewed footing.
