# Research synthesis, pass XCIII (2026-03-22)

This pass keeps one fresh rule in focus:
**Schell should steal the best current command-boundary, captured-output, semantic-history, workflow, and pane-metadata ideas — but it should pair them with an explicit veto list learned from the last forty years of shell and terminal pain: no hidden reparsing, no spoofable metadata promoted to authority, no heuristic click-to-open escalation, no ambient paste/input injection, and no saved workflow that quietly bypasses fresh review.**

That is the right design-phase answer because SlopOS is also still design-phase.
We do not need a final shell language or one terminal protocol yet.
We do need a sharper memory of what not to repeat.

## 1) The parser lesson is still undefeated

PowerShell remains one of the clearest modern reminders that shells become dangerous when the operator cannot tell which parser is in charge.
Its docs still distinguish expression mode from argument mode, preserve a stop-parsing token for native commands, and note that the call operator does not parse strings for you.
That is all one giant clue for Schell:
**never let convenience text, helper prose, or stringly recall become a hidden second execution language.**

The older shell lesson is harsher.
Shellshock happened because Bash processed crafted environment-variable content across a privilege boundary.
That is not a trivia fact; it is a structural warning that startup, environment, and helper launch surfaces are part of the execution boundary whether shell culture admits it or not.

Stealable answer for Schell:
- show exact argv / external-boundary reveal on demand,
- keep explain-before-run proposal-only,
- refuse hidden interpreter / env / name fallback,
- and treat startup footing as a named ground rather than folklore.

## 2) Shell-emitted metadata is worth stealing, but provenance must stay visible

VS Code, WezTerm, kitty, Ghostty, and iTerm2 all keep proving the same thing: the terminal gets dramatically better when the shell emits prompt, command, cwd, exit, and output boundaries.
That buys navigation, sticky headers, better link resolution, better split inheritance, block actions, and better captured-output tooling.

But VS Code's docs are unusually candid about the trust problem: its custom sequences can be emitted by any application capable of writing to the terminal, and the optional nonce exists specifically to prevent command spoofing.
That means Schell should not merely celebrate shell integration.
It should name a trust ladder for it.

Stealable answer for Schell:
- prefer shell-authenticated command chapters over guessed blocks,
- keep provenance badges for shell-emitted metadata,
- make stronger actions care about trust grade,
- and keep trusted review chrome separate from raw PTY content.

## 3) Clickability is useful, but the old open/run trap is everywhere

Current terminals prove that smart clicks are worth stealing.
iTerm2 semantic history tracks the cwd for each line to help open files intelligently.
kitty can page the last command output and let users act on it.
Captured-output panes that jump directly to warnings and errors are obviously good.
Plan 9's plumber is still the deeper ancestor here: data plus context should shape routing, not just a naked string.

But the modern docs also keep exposing the risk surface.
xterm.js warns that accepting non-HTTP URLs in OSC 8 handlers can create security issues.
kitty explicitly offers an `ask` posture before opening hyperlinks.
That is exactly the posture Schell should import:
**typed open/reveal/insert/inspect routes are good; heuristic click-to-do-whatever is not.**

Stealable answer for Schell:
- object cards and intent packets,
- default-to-inspect or ask for risky opens,
- shell-known cwd/context for better exact reveal,
- and route witnesses so open, reveal, insert, safe-open, and execute never collapse into one click myth.

## 4) Input-path hygiene matters more than shell culture admits

The input path remains one of the oldest sources of accidental damage.
VS Code's bracketed-paste work shows why multi-line paste should be treated as one explicit unit when the shell supports it, and why the terminal warns when that support is absent.
The Linux `su(1)` docs still point out that `--pty` helps avoid TIOCSTI terminal injection and related attacks against terminal file descriptors.

Stealable answer for Schell:
- ingress packets, not ambient paste,
- bracketed-paste-aware multiline handling,
- PTY / process-group witnesses,
- and explicit promotion when historical or external text crosses into active input.

## 5) Workflow reuse is worth stealing only if it stays weaker than fresh review

Warp's saved parameterized workflows are a strong clue that shell reuse wants something better than alias folklore.
Users plainly benefit from named, searchable, argument-bearing workflow objects.
Xonsh's richer per-session history is another clue that shell memory can be smarter than one flat append-only log.

But saved workflows should not become silent execution policy.
The right import for Schell is not “make terminal history executable.”
The right import is:
- searchable parameter cards,
- explicit authorship and basis packets,
- run/insert/review as separate actions,
- and stale-basis confession when a saved workflow no longer stands on the same footing.

## 6) Structured data is a huge gain, but one ontology should not be forced too early

Nushell still shows one of the best possible futures for shell ergonomics: structured pipelines, safer selection/filtering/sorting, explicit extern signatures, and a visible distinction between shell-native data work and external commands.
That is brilliant pressure.
It is not yet a reason to force Schell into one final universal object pipeline.

Stealable answer for Schell:
- output-shape chips,
- structured inspection where available,
- explicit external-boundary posture,
- and render views that confess when they are only views.

## 7) The fish lesson is less flashy and more important

fish's design notes keep pressing three things that are easy to underweight when inventing a “super awesome” shell:
- responsiveness,
- discoverability,
- and hostility to gratuitous configuration.

That is not anti-ambition.
It is an anti-design-debt rule.
Schell should absolutely collect brilliant ideas, but phase-zero brilliance that slows startup, explodes config space, or hides itself from users is usually fake progress.

## 8) The bounded outcome of this pass

The correct move is not one grand unification.
It is a smaller set of explicit bundles:

### Must-learn failure families
- hidden reparsing / string execution,
- privilege-boundary environment surprises,
- spoofable metadata,
- heuristic click-to-open / click-to-run escalation,
- ambient paste/input injection,
- and saved-history/workflow objects that quietly outrank fresh review.

### Stealable luxury bundles
- shell-authenticated command chapters,
- captured-output decks tied to command history,
- semantic-history-aware open/reveal,
- first-class WhatIf / compare-after-run rails,
- searchable parameterized workflow seeds,
- pane/user-var metadata for local luxury,
- rich per-session history objects,
- and structured inspection that stays explicit about conversion boundaries.

### Moves still refused
- one final shell grammar,
- one final shell↔terminal transport,
- one final workflow engine,
- one final universal data ontology,
- or one final click/open protocol.

The right phase-zero answer is simpler:
**make the luxury surfaces better, and make the vetoes unforgettable.**
