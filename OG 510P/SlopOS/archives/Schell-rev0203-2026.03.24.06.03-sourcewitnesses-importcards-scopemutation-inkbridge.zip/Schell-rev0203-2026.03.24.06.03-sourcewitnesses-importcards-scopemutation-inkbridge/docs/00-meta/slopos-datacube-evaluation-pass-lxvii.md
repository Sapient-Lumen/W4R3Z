# SlopOS datacube evaluation, pass LXVII (2026-03-22)

This pass evaluates one new companion import:
**Schell should absolutely gain reviewed credential witnesses, escalation ladders, and file-creation-mask honesty, but SlopOS pressure says ambient caller identity, supplementary groups, privileged-exec gain, namespace-mapped numeric IDs, and hidden `umask` must stay separately admitted so shell truth never collapses into host login folklore.**

## 1) D-CAPSHELL already says launch meaning must not inherit ambient caller identity

The companion archive is extremely sharp here.
`capshell-credential-baseline-posture-v0.md` says `capshell.exec` must not treat the parent runner's current caller identity as reviewed workflow input merely because the runner was launched from a particular login session, service manager, terminal, or helper process.
It explicitly calls out real/effective UID/GID state, supplementary groups, and host access-token / equivalent security-context state as ambient authority that must not silently define reviewed launch meaning.
That is exactly the right Schell import.
A reviewed shell surface should say whether identity posture is fixed executor identity, explicit target identity, compat/degraded basis, or unavailable — not bury it inside session folklore.

## 2) SlopOS separately forbids launch-time privilege gain across exec

`capshell-privgain-posture-v0.md` adds the next important pressure.
It says reviewed workflow launch must not gain authority from setuid/setgid bits, file capabilities, ambient capability carry-over, or similar privileged-exec metadata; where available, runners should use one-way no-new-privileges controls before `exec`.
That is a huge gift to Schell.
It means the shell+terminal does **not** need to pretend privilege transitions are a single yes/no “root mode” bit.
Instead, it can expose privilege-gain posture as one compact witness and keep stronger credential-management ambitions deferred.

## 3) SlopOS also treats file-creation footing as launch posture, not host folklore

`capshell-umask-posture-v0.md` sharpens another useful lesson.
It says reviewed launch must not inherit the parent process, login shell, wrapper, or host session `umask` and instead fixes the launch mask at `0o077` in Phase 1.
That is unusually valuable shell pressure.
It means file-creation footing is not a decorative compatibility detail.
It is part of reviewed launch truth.
Schell should therefore surface whether `umask` is explicit, provider-fixed, compat-inherited, or unavailable rather than leaving it as a post-hoc surprise.

## 4) Exec-pack v2 ties all three seams together into one launch honesty rule

`capshell-exec-pack-schema-v2.md` is especially helpful because it links the three pressures in one place:
- no privilege gain across `exec`,
- no ambient caller-identity baseline,
- and no inherited file-creation mask.
That combination pressures Schell toward one strong rule:
identity, privilege-gain posture, and file-creation footing should be visible together at review time, but they should remain separately named instead of becoming a single “trusted/admin mode” myth.

## 5) SlopOS's split suggests at least six separate shell-side objects

Putting those companion surfaces together suggests a clean Schell family:
- **executor witness** — fixed executor / requested target / compat basis / unknown,
- **caller-target relation witness** — same / switched / service-isolated / unknown,
- **group witness** — explicit clear/keep/init/unknown posture,
- **namespace-mapping witness** — host-basis / mapped / unknown,
- **umask witness** — explicit / provider-fixed / compat-inherited / unknown,
- **privgain witness** — no-new-privs / provider-asserted none / unknown / degraded.

That split matters a lot.
If Schell flattens those objects, it will recreate exactly the ambient-authority problem SlopOS keeps refusing.

## 6) A compact v0 posture worth stealing

A good early Schell identity family should probably say:
- whether launch uses a fixed least-privilege executor or a stronger reviewed target identity,
- whether caller identity and target identity differ,
- whether supplementary groups are cleared, kept, or explicitly reinitialized,
- whether numeric identity is namespace-mapped or host-basis,
- whether file creation starts from explicit `umask`, provider-fixed `umask`, compat inheritance, or unknown,
- and whether launch is guaranteed non-gaining across `exec` or merely degraded/unknown.

That would make identity truth much more humane without forcing one final elevation backend, token broker, or namespace substrate.

## 7) Decision-light next move

A strong next move is to define one **credential witness / escalation ladder / umask humility** family that proves:
- reviewed identity footing,
- explicit elevated-edit versus full privileged-session ladders,
- explicit group and namespace posture,
- and bounded historical identity/creation receipts
can coexist without turning Schell into a universal sudo replacement, a fake token browser, or portability theater around user identity.

That keeps Schell ambitious while learning the right lesson from SlopOS:
**identity truth is welcome, but caller identity, target identity, groups, namespace mapping, `umask`, and privilege-gain posture must stay separately admitted.**
