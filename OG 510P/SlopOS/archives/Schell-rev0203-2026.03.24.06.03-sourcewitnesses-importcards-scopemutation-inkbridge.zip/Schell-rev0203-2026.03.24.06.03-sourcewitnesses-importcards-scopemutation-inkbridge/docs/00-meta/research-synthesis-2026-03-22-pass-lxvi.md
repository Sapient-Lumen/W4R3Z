# Research synthesis, pass LXVI (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should absolutely steal explicit clock kind, timezone/locale basis, and deadline posture — but only if wall clock, monotonic time, sync status, `TZ`, `LC_*`, and historical receipts stay separately named instead of collapsing into one flattering “the shell knows what time it is” story.**

This seam matters because old shells still treat time and locale as oddly ambient.
A command often inherits the host locale, host timezone, host time-sync state, and host/container clock footing without the operator seeing any of it in the review surface.
When output order changes, a glob matches differently, a timestamp renders strangely, or a timeout fires at the wrong moment, the operator ends up diffing `LC_*`, `TZ`, container/runtime settings, and sync status after the fact.
That is exactly the sort of shell+terminal seam Schell can improve without choosing one final locale engine, time-sync stack, or namespace substrate.

## 1) POSIX proves locale is execution meaning, not decoration

The current POSIX environment-variable rules say `LC_ALL` takes precedence over the other locale categories and over `LANG`.
The current POSIX shell language also says `LC_COLLATE` determines the behavior of range expressions, equivalence classes, and multi-character collating elements within pattern matching.
That is a big Schell clue.
Locale is not merely display chrome.
It can materially change shell meaning, comparisons, and pattern behavior.
See: https://pubs.opengroup.org/onlinepubs/9799919799/basedefs/V1_chap08.html and https://pubs.opengroup.org/onlinepubs/9799919799/utilities/V3_chap02.html

## 2) GNU coreutils proves locale and timezone quietly change ordinary shell outcomes

The current GNU `sort` manual says comparisons use the character collating sequence specified by `LC_COLLATE`, and it also notes that `LC_CTYPE` can change what counts as a blank or as a letter/digit for options such as `-b`, `-d`, and `-f`.
The current GNU `date` manual says its default output depends on `LC_TIME` and that it uses timezone rules from `TZ` or the system default when `TZ` is unset.
The current GNU `touch` manual separately warns that UTC timestamps avoid ambiguities during daylight-saving transitions.
That is exactly the kind of hidden execution meaning Schell should surface before run and explain after run.
See: https://www.gnu.org/software/coreutils/manual/html_node/sort-invocation.html , https://www.gnu.org/software/coreutils/manual/html_node/date-invocation.html , and https://www.gnu.org/software/coreutils/manual/html_node/touch-invocation.html

## 3) Time namespaces prove clock footing is real runtime posture, not trivia

The current Linux `time_namespaces(7)` docs say time namespaces virtualize `CLOCK_MONOTONIC` and `CLOCK_BOOTTIME`, while explicitly noting that `CLOCK_REALTIME` is not virtualized.
That is an excellent Schell clue.
Even when the user thinks they are “just running a command”, the runtime may have changed which clock domain matters for elapsed time, timers, and uptime-like reasoning.
So Schell should not flatten “deadline”, “wall clock”, and “elapsed time” into one generic time badge.
See: https://man7.org/linux/man-pages/man7/time_namespaces.7.html

## 4) systemd proves timezone, sync status, and accurate reference time are different stories

The current `timedatectl` docs say the tool queries and changes the system clock and its settings and can enable or disable time synchronization services.
The current `systemd-timesyncd.service(8)` docs sharpen the difference:
- timesyncd is an SNTP service, not full NTP,
- it can make the realtime clock only *roughly* monotonic across reboots,
- and accurate synchronization is a stronger state surfaced separately through `systemd-time-wait-sync.service` and `time-sync.target`.
That is a very good Schell lesson.
Current sync state, timezone configuration, and exact reviewed deadline basis should stay separately named.
See: https://manpages.debian.org/unstable/systemd/timedatectl.1.en.html and https://manpages.debian.org/unstable/systemd-timesyncd/systemd-timesyncd.service.8.en.html

## 5) The dangerous flattenings to refuse

The current ecosystem keeps inviting at least seven mistakes:
- treating locale as presentation-only when it changes shell pattern/range behavior and sort order,
- treating wall clock and elapsed-time clock as interchangeable,
- treating timezone formatting and security/deadline enforcement as the same thing,
- treating sync enabled as equivalent to accurately synchronized,
- treating stale status panes or old receipts as proof of present clock footing,
- treating one runtime's clock namespace behavior as Schell's final portable ontology,
- and treating `TZ=UTC0` / `LC_ALL=C` compatibility tricks as universal semantics rather than explicit posture choices.

Schell should refuse those moves.
A command should be able to say, separately:
- what clock kind it depends on,
- what locale and timezone basis it will use,
- whether deadline intent is monotonic or wall-clock derived,
- whether sync/proof state is live or historical,
- and what bounded historical time receipt can honestly be emitted afterward.

## 6) The stealable move: clock witnesses, locale badges, and deadline humility

The best decision-light move now looks like this:
1. add a **clock witness** family for reviewed launch posture,
2. keep **locale basis** separate from clock basis,
3. keep **timezone basis** separate from both,
4. distinguish **elapsed-time / monotonic deadlines** from **wall-clock rendering**,
5. distinguish **sync enabled** from **accurately synchronized / proof-backed**,
6. distinguish **historical time receipts** from **current live footing**,
7. let richer calendar/timeproof inspectors be optional and capability-witnessed,
8. and refuse to standardize one giant cross-platform locale/time admin grammar too early.

That would make Schell feel dramatically more capable while preserving the archive's current decision throttle.

## 7) A compact first proving slice

A compact proof could show:
- one reviewed launch card with explicit clock-kind badge,
- one locale witness saying exact `LC_*` / `LANG` posture or explicit omission,
- one timezone witness saying explicit `TZ`, default host basis, or reviewed override,
- one deadline chip that confesses whether it is monotonic intent or wall-clock-derived display,
- one reproducibility rail that offers `LC_ALL=C` / `TZ=UTC0` as an explicit insertable posture rather than ambient magic,
- one sync/proof badge that stays weaker than present-time authority,
- one historical receipt with bounded locale/timezone/clock facts,
- and one refusal to treat a stale sync/status panel as current deadline or timestamp truth.

That is enough to make Schell feel super awesome at clock/locale truth without freezing the final timeproof stack, timezone admin model, or locale portability substrate.

## 8) Decisions intentionally kept open

This pass does **not** freeze:
- one universal locale schema for every host/runtime,
- one portable timezone/calendar admin plane,
- one final time-sync or timeproof backend,
- one universal deadline/timer API,
- one final clock-namespace or container/runtime substrate,
- or one universal historical time-receipt schema.

The no-regret move is smaller:
**steal reviewed clock kinds, locale/timezone basis, and deadline humility — but keep wall clock, monotonic time, sync/proof state, locale basis, timezone basis, and historical receipts visibly separate.**
