# SlopOS datacube evaluation — pass CLIII

This pass asks a narrower companion-safe question than “should Schell have history search, restore, or command search?”
The better question is:
**how should Schell model submission freshness so restored, inserted, or imported command text does not impersonate a freshly meant single run?**

## 1) SlopOS already keeps stable request identity weaker than live state

Even while still in design phase, SlopOS keeps returning to a clean rule:
a requester-chosen stable key is useful for dedupe, review, or retry, but it is not the same thing as a currently live grant, handle, or lease.

That lesson maps almost directly to shell submission.
A visible command candidate may deserve a stable local identifier or fingerprint.
But that fingerprint should stay weaker than the later fact that the shell actually spent one exact action and can point to its receipt.

## 2) ViewFS reinforces the split between visible candidate and exact applied basis

ViewFS keeps exact basis, apply session, reconstructed object, and receipt distinct.
That same discipline pressures Schell not to let visible input text overclaim what has become true.

A line in the prompt may be:
- historically recovered,
- assistant-inserted,
- restored from a locker,
- or staged from a history row.

Useful, yes.
But still weaker than an exact newly applied basis.
That is a strong argument for submit witnesses and rearm posture.

## 3) Steward keeps reminding us that user-facing progress is not yet exact completion

Steward repeatedly separates countdowns, retries, acknowledgements, and final receipts.
That suggests a direct shell lesson:
pressing Enter on something current-looking should not automatically erase the difference between:
- first spend,
- repeated spend,
- restored spend,
- and merely staged text.

A shell that wants to be companion-safe should keep those classes named.

## 4) Helm strongly pressures drift-sensitive rearm rather than silent hotness

Helm’s change cursors, reset cards, activity-scope truth, and basis witnesses all push the same way:
what matters is not just “what is visible” but also “what exact footing still holds.”

That is especially relevant here.
A command candidate that was armed a moment ago may deserve cheap invalidation if:
- cwd changed,
- peer changed,
- authority wallet changed,
- prompt reclaim is still pending,
- or a reset card already says the prior footing drifted.

So Schell should prefer rearm after drift over quietly letting an old candidate stay action-hot forever.

## 5) What Schell should steal now

Schell should steal several excellent ideas, but import them under stronger honesty:
- explicit insert-versus-run verbs on history/search rows,
- command restoration that comes back below fresh run,
- prompt-local luxury only when the current prompt is truly live,
- receipt-linked repeat cards rather than ambient repeat folklore,
- and cheap rearm chips whenever the source or footing of the current candidate is weaker than fresh typed intent.

## 6) What Schell should refuse now

Schell should refuse:
- treating every Enter as the same class of action,
- treating restored or imported text as self-arming,
- letting prompt-looking residue count as submit-ready shell truth,
- and flattening first spend, exact repeat, review-repeat, and insert-only into one button or one hot line.

## 7) Compact conclusion

The companion-safe answer is not to slow the shell down.
It is to make **submission freshness explicit**.
If Schell can say where the current candidate came from, whether it is freshly armed, whether it is really a repeat, and what exact receipt later proves the spend, it can steal a lot of modern command-surface luxury while staying aligned with SlopOS exactness during the design phase.
