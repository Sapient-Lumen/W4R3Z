# SlopOS datacube evaluation, pass CII (2026-03-22)

This pass evaluates one narrower question against the current SlopOS archive:
**what does the companion already teach Schell about full-screen/TUI life, captured output, and the difference between visible state and durable exact result truth?**

The answer is stronger than “be careful with pagers.”
**SlopOS already pressures Schell to keep live terminal views, derived captures, shell-attested command/output truth, and durable exact result identity as different layers instead of one flattering visible-text story.**

## 1) SlopOS already keeps durable result identity smaller than terminal comfort

The companion's output-normal-form and result-sidecar boundary docs are unusually clarifying here.
`capshell.exec` replay-stable outputs stay a digest-addressed set.
The archive explicitly refuses to smuggle richer result structure into CH-EXECPACK, CH-EFFCON, or CH-ACPOUT.
And telemetry or richer sidecars remain observational rather than result-defining.

That is direct pressure on Schell.
A visible line in copy mode, a pager screen, or an alt-screen residue block cannot quietly become the canonical result just because it is easy to revisit.

For Schell this implies:
- exact durable results remain stronger than visible terminal views,
- derived capture decks stay derived,
- and stronger export/replay/open actions should route back through exact shell-owned artifacts when those exist.

## 2) The companion's no-portable-PTY posture is a huge clue

The capshell terminal/job-control posture is equally helpful.
Phase 1 explicitly declines a portable PTY / controlling-terminal / shell-job-control plane.
Interactive UX may exist locally, but it does not become a second authority-bearing workflow contract.

That matters for Schell because it means full-screen/TUI life should be treated as a local interaction seam unless and until a stronger explicit shell-owned surface exists.
A live editor, monitor, chooser, or dashboard can absolutely be delightful.
But its live framebuffer state is not automatically a portable workflow artifact.

For Schell this implies:
- full-screen views should default to **observation posture**,
- copy/search overlays should default to **terminal-local helper posture**,
- and stronger reopen/export/rerun actions should promote through shell-owned command/output/result surfaces instead of flattening live PTY state into portable truth.

## 3) The companion's cancellation posture also sharpens the ownership rule

SlopOS keeps cancellation bound to explicit request/workflow seams rather than portable signal folklore.
That means even interrupt-like terminal gestures are local wrappers around stronger existing seams.

This is useful for Schell because full-screen life often tempts designers to let keyboard gestures, copy mode exits, pager actions, or TUI-local controls become hidden authority channels.
The companion argues for the opposite discipline:
- terminal gestures can be rich,
- local wrappers can be humane,
- but stronger meaning still belongs to explicit shell/workflow/result surfaces.

## 4) Learn mode and result sidecars together reinforce a smaller answer

The learn-mode posture keeps observational help weaker than reviewed action.
The result-sidecar boundary keeps richer observability weaker than replay correctness.
Taken together, they give Schell a clean import rule for this seam:

**fullscreen observation, search hits, captured excerpts, and pager surfaces should remain luxurious observational aids until a stronger exact source is explicitly promoted.**

That is exactly the kind of decision-light construction rule the shell+terminal needs while both projects are still in design phase.

## 5) The companion-compatible shape

This pass therefore recommends a bounded import shape.

### A) Fullscreen witnesses
Treat main scrollback, alt-live framebuffer, alt-captured residue, copy/search overlays, shell-attested chapters, and durable exact results as different view families.

### B) Promotion rails
Let the operator move from visible excerpt to stronger truth explicitly:
- copy excerpt,
- reveal chapter,
- reopen exact output,
- export exact result,
- or stay view-local.

### C) Overlay humility
Copy mode, search overlays, and capture decks remain terminal-local helper lanes unless the shell can bind them to stronger command/output objects.

### D) Durable result precedence
When an exact output capsule or digest-addressed result exists, it remains stronger than any view-local framebuffer or capture row.

## 6) Compact conclusion

SlopOS is still design-phase, but it already gives Schell a very practical rule:

**make full-screen life luxurious as observation, then promote explicitly into shell-attested output or durable exact results when stronger truth exists.**

That is a careful way to steal modern terminal brilliance without letting visible state quietly become execution or replay truth.
