# Research synthesis, pass CXIV (2026-03-22)

This pass keeps one narrower lesson explicit:
**a super-awesome shell+terminal should separate observe, attach, control, debug-exec, and sideband lanes rather than flattening them into one flattering idea of a “live session.”**

The outside ecosystem is strikingly consistent once this question is isolated.
Kubernetes keeps `logs`, `attach`, `exec`, `debug`, and `port-forward` separate because they are different powers.
`tmux` keeps read-only clients and control mode separate because observation and control are different relationships to a live pane.
Temporal keeps Queries, Signals, and Updates separate because reading state, fire-and-forget mutation, and synchronous tracked mutation are different verbs.
The XDG InputCapture portal keeps enabled distinct from active because readiness is not the same thing as live ownership.
Meanwhile current terminal integration work keeps moving more UX onto shell-attested semantics rather than renderer guesswork.

Together these point to a very good Schell move:
**make semantic command frames richer, but also name the live lane you are in.**

## 1) The past mistake to avoid is lane collapse

The dangerous modern failure is not only hidden parsing or startup folklore.
It is also **lane collapse**:
- log following treated like attach,
- attach treated like native identity,
- control APIs treated like shell text,
- debug shells treated like the original run,
- sideband tunnels treated like ordinary same-lane reachability,
- and saved transcripts treated like live handles.

A custom shell+terminal can prevent that if it names the lane instead of flattering the operator with one giant “connected” state.

## 2) Kubernetes remains a great specimen

`kubectl logs` prints logs and can follow them, but it is still a logs verb.
`kubectl attach` attaches to a process that is already running and may connect stdin/TTY.
`kubectl exec` injects a command into a container.
`kubectl port-forward` forwards local ports to a selected pod and ends when that pod terminates.
Those are not implementation details; they are product truths worth stealing.

Schell should not collapse follow, attach, injected exec, and forwarded sidebands into one lane just because they can all appear near a terminal pane.

## 3) `tmux` proves live observation and control need different surfaces

`tmux` explicitly supports read-only clients, where only detach/switch-client bindings work, and separately exposes control mode with subscriptions and pane-action control.
That is a very strong clue.
A terminal can expose useful live semantics without turning every client into a full interactive owner.

Schell should therefore be willing to make observe-only and control-enabled lanes both first-class.
That is a feature, not a downgrade.

## 4) Temporal proves reads, async writes, and tracked writes should stay named

Temporal’s split is beautifully transferable:
- Queries are read requests,
- Signals are asynchronous writes,
- Updates are synchronous tracked writes.

That suggests a powerful Schell habit.
When the shell+terminal offers status refresh, pause/continue, “nudge this task,” “recompute this state,” or “wait for result,” it should preserve whether the operator merely queried, sent an async control message, or performed a synchronous tracked update.

That is much better than pretending all these actions are just “commands.”

## 5) Enabled versus active is a crucial honesty trick

The XDG InputCapture portal’s distinction between enabled and active is one of the best transferable ideas in current systems.
It shows that user-facing readiness and actual control do not need to be flattened.

Schell should likely keep states like:
- armed,
- active,
- paused,
- detached,
- historical,
- and maybe focus-owned.

That would make attach/readiness/control UX far more honest without forcing a giant runtime ontology.

## 6) Modern terminal luxuries get better when their lane is explicit

Windows Terminal, kitty, fish, iTerm2, and Ghostty keep proving that shell-attested prompt/command/output/cwd metadata unlock excellent command-local features.
But those features still benefit from knowing whether the surrounding lane is only observed, interactively attached, control-capable, or merely historical.

For example:
- sticky command chrome should not imply interactive control,
- prompt-local click editing should not survive into history-only or follow-only surfaces,
- sideband badges should not masquerade as ordinary reachability,
- and restored transcript context should not overclaim live attachability.

## 7) Compact design-phase answer

Schell does **not** need to freeze one final live-session substrate.
It only needs a bounded move:
- keep shell-known semantic frames,
- add a small live-lane witness vocabulary,
- separate observe/follow, attach, control, debug exec, and sideband,
- distinguish armed from active,
- and preserve live-lane truth in receipts and history.

That is enough to make the shell+terminal dramatically more truthful and more powerful while SlopOS, Steward, ViewFS, and Schell are all still in design.
