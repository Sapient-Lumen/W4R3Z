# SlopOS datacube evaluation, pass LIV

**If Schell borrows chooser luxury — fuzzy recall, ranked candidates, preview panes, and quick-pick style menus — SlopOS says the safe version is chooser-owned, set-valued where ambiguity matters, metadata-safe where previews are risky, and still weaker than exact reviewed `cd`, `open`, or `run`.**

This pass focuses on chooser pressure because the shell+terminal will obviously want it.
Operators love:
- searchable recents,
- fast directory jumps,
- preview lists,
- and compact menus.

But the companion archive keeps warning against the exact ways these luxuries get dangerous:
- hidden winner selection,
- preview leakage,
- ambient recents/history authority,
- and learned ranking quietly becoming execution policy.

## 1) D-NAMECERT selection says set-valued ambiguity is healthier than hidden winner policy

The name-cert selection boundary is one of the cleanest imports for chooser design.
When multiple admissible candidates exist, SlopOS keeps evaluation set-valued instead of silently picking a winner.
That is not just a naming lesson.
It is a chooser lesson.

A Schell chooser can rank or sort for presentation.
But the archive says the ranking should remain non-authoritative until an explicit target action chooses one exact candidate.
That is a very strong antidote to “the top hit must be the truth.”

## 2) D-POWERBOX says candidate sets should stay chooser-owned, not caller-owned inventory leaks

The powerbox posture is also directly relevant.
It keeps candidate sets chooser-owned and refuses to turn mediation into a generic hidden inventory API.
That means Schell should be very careful with chooser sources that expose:
- all possible handlers,
- all possible authorities,
- or all possible hidden destinations
just because the operator typed a few letters.

The import is straightforward:
Schell can show ranked options,
but it should not quietly convert every chooser into a discovery oracle over hidden state.

## 3) CH-CWD exactness says directory recall cannot quietly replace cwd review truth

Capshell's cwd-root posture keeps cwd as a bound root, not an advisory pathname or ambient host fallback.
That puts direct pressure on directory jumpers.
A learned path ranking system may be pleasant,
but it cannot become a hidden replacement for explicit cwd review.

So a Schell directory chooser should probably distinguish at least:
- suggest a target,
- reveal exact target,
- stage `cd` in active input,
- and commit to the cwd-changing action.

The current companion archive argues strongly against letting learned jumps feel like ambient path destiny.

## 4) Learn mode says ranking and suggestion are observational help, not auto-widening policy

Capshell learn mode is observational only.
That is a powerful rule for chooser systems too.
A chooser may remember:
- what succeeded,
- what failed,
- what directory a command ran in,
- or what target was frequently chosen.

But that memory should remain suggestion material.
It should not silently widen authority, change bindings, auto-edit commands, or auto-rerun a top-ranked candidate.

That means scored recall can be wonderful as long as it stays visibly weaker than explicit reviewed action.

## 5) Quarantined result-preview posture says preview panes are not harmless

The quarantined result-preview boundary is perhaps the most important import for chooser design.
It explicitly refuses ambient snippets, thumbnails, preview panes, or hover previews for quarantined content unless a separate review/open step occurs.
That means chooser rows and preview panes are not “just UI.”
They are object-handling behavior.

So if Schell builds chooser previews, it should inherit the same law:
- metadata-only previews are one thing,
- content previews are another,
- and risky content should degrade to metadata rather than quietly render because the cursor moved.

## 6) OpenURI recents posture says local recents should stay shell-owned and non-authoritative

The OpenURI recent-items boundary is another terrific lesson.
It refuses portable recent-items/history control or receipt on generic URI launch and keeps any local recents shell-owned and non-authoritative.
That maps neatly onto chooser design.

A Schell chooser may absolutely surface local recents.
But it should not pretend that:
- a recent hit is a durable reopen grant,
- a launch history row is authority,
- or a recents database is the same thing as an exact explicit object handle.

## 7) The clean import: chooser witnesses, not chooser authority

The SlopOS-compatible import now looks like this:
- chooser sources stay named,
- ambiguous result sets may rank for display without hiding exact candidate choice,
- previews remain metadata-safe by default when risk is nontrivial,
- history and learned ranking remain observational help,
- recents stay shell-owned and non-authoritative,
- and accept actions stay explicitly split between insert, reveal, and act.

That fits the rest of the archive very well.
It preserves one exact reviewed action underneath a much nicer selection surface.

## 8) What Schell should refuse right now

Under current SlopOS pressure, Schell should refuse:
- chooser surfaces that auto-run the top hit,
- hidden single-winner rules where ambiguity matters,
- preview panes that execute helper commands without visible posture,
- ambient rendering of risky content on mere focus,
- and recents/history rows that masquerade as stable reopen or cwd authority.

## 9) Decision-light next move

A strong next move is to define one **chooser witness** family that proves:
- ranked recall,
- directory jumping,
- preview toggles,
- detail rows,
- and explicit accept lanes
can all exist without turning ranking, preview, or history into hidden execution policy.

That would keep Schell ambitious while still learning the right lesson from SlopOS:
**selection can be luxurious, but exact chosen action and exact chosen target stay stronger than chooser magic.**
