# Research synthesis, pass CVI (2026-03-22)

This pass keeps one fresh rule in focus:
**a shell+terminal gets much more trustworthy when exact text, grapheme shaping, glyph source, ligature posture, and font fallback are treated as different truth families instead of one flattering “the terminal showed this” blur.**

The current terminal ecosystem is much clearer about this seam than it used to be.
Ghostty's configuration docs now explicitly let operators repeat `font-family` to define preferred fallbacks, expose `font-synthetic-style`, and even allow codepoint-specific font mapping and clipboard codepoint mapping.
Ghostty's 1.2 release notes also made a judgment call about typography by disabling the discretionary `dlig` feature by default while leaving the more common `calt` feature on.
Then Ghostty 1.3 doubled down on shaping correctness by calling out major improvements for Brahmic scripts, where ligatures, combining marks, and joined forms are essential to correct rendering.
WezTerm's current fonts docs likewise separate fallback from the primary face and now bundle both Nerd Font Symbols and Noto Color Emoji as default fallbacks.
kitty's docs are equally revealing in a different tone: it explicitly says not to rely on patched Nerd Fonts because patching destroys fonts, ships a built-in Nerd font, and lets operators map exact symbol ranges with `symbol_map`.
Windows Terminal exposes font features and axes in profile settings and still ships multiple Cascadia variants so ligature and Powerline choices remain explicit rather than accidental.

## 1) The ecosystem now openly admits that glyph source matters

Older terminal folklore often behaved as if a configured monospaced font settled the matter.
The current docs no longer support that simplification.
The renderer may now mix:
- the primary monospace face,
- one or more preferred fallbacks,
- bundled emoji or symbol fallbacks,
- synthetic bold or italic,
- script shaping,
- variable-font axes,
- and codepoint-specific remapping.

That means a visible prompt or command line can depend on a local typography stack even when the exact text is unchanged.
Schell should name that dependence instead of treating it as harmless background detail.

## 2) The historical lesson is not “avoid fancy fonts”

The healthier lesson is smaller:
**keep typography luxurious, but keep it visibly presentational.**

Ghostty leaving `calt` on but turning `dlig` off by default is a good modern example.
It shows that even one product now distinguishes common shaping from more optional display flourish.
Windows Terminal's Cascadia family makes the same point through packaging: Code vs Mono and PL vs non-PL are distinct choices.
WezTerm and kitty then push the lesson further by proving that terminals can supply bundled symbol coverage without requiring a patched prompt font to become the portable truth.

So the best import for Schell is not one font default.
It is one boundary:
- exact text remains the stronger truth,
- glyph choice remains renderer-local posture,
- and prompt/theme luxury should declare when it depends on font packs or icon ranges.

## 3) Clipboard and copy behavior prove that display and text can diverge

Ghostty's `clipboard-codepoint-map` is especially instructive.
It openly permits mapping characters to different copied output.
That is a useful compatibility tool.
It is also the cleanest current reminder that what the operator sees and what gets copied do not have to be the same thing.

Schell should import the right lesson:
- copy/export posture must be visible,
- exact-text copy must stay available,
- and pretty or compatibility-oriented substitution should stay weaker than exact shell truth.

## 4) The stealable moves are concrete and excellent

### a) Glyph-footing chips
Prompt/theme surfaces can declare whether they are:
- ASCII-safe,
- Powerline-safe,
- Nerd-font-dependent,
- emoji-bearing,
- or font-pack-dependent.

### b) “Why does this look wrong?” cards
When alignment breaks or icons disappear, the terminal should answer:
- missing glyph in primary font,
- fallback font supplied glyph,
- patched-font metrics are unstable,
- remote/local font footing differs,
- or copy/export posture differs from display posture.

### c) Explain-glyph inspector
A compact reveal that shows:
- codepoints,
- grapheme cluster,
- current font source,
- shaping posture,
- width posture,
- and copy posture.

### d) Prompt-theme dependency declarations
Theme packs should say whether their visual quality depends on special symbol coverage or host-local font installation.

### e) Local ligature/style toggles that never claim semantic power
This can feel fantastic while still staying visibly renderer-local.

## 5) This seam is smaller than a final typography stack

None of this requires Schell to freeze:
- one default font family,
- one bundled symbol font,
- one icon-pack policy,
- one shaping backend,
- one ligature default,
- or one cross-platform clipboard substitution policy.

It only requires one explicit witness family.

A good v0 `font witness` could carry:
- `font_stack_ref`,
- `glyph_source_posture`,
- `shaping_posture`,
- `style_posture`,
- `icon_posture`,
- `copy_posture`,
- and `portability_posture`.

That is enough structure to make terminal typography dramatically nicer without letting display convenience impersonate exact shell meaning.

## 6) Compact conclusion

One of the smartest no-regret moves available right now is:
**make font and glyph footing first-class, but keep exact text, grapheme identity, glyph source, ligature posture, and copy/export substitution separately named.**

That lets Schell steal some of the best current terminal comfort without prematurely deciding the whole font stack, theme ecosystem, shaping backend, or icon strategy.
