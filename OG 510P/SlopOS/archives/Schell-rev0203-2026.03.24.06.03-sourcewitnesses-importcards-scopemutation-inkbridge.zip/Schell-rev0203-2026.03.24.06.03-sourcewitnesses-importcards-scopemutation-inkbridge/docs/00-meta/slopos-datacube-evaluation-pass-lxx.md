# SlopOS datacube evaluation, pass LXX (2026-03-22)

This pass evaluates one new companion import:
**Schell should absolutely steal command-aware shell marks, typed object routes, and rich local command-block luxury, but SlopOS pressure says startup files, environment startup hooks, shell-side expansion, peer-handle pipeline folklore, and durable truth receipts must stay separately admitted so the terminal never becomes a hidden shell.**

## 1) SlopOS already says shell startup is not ambient convenience

The companion archive is very sharp here.
`capshell-startup-profile-posture-v0.md` refuses implicit rc/profile startup and per-directory hooks such as `.envrc`, `.env`, and virtualenv activation.
Prompt redraw and cwd changes are not allowed to become hidden code-loading events.
That is a load-bearing Schell lesson.
A custom shell+terminal can absolutely feel magical, but it cannot let terminal convenience quietly inherit the old `~/.bashrc` / project-hook folklore as semantic truth.

## 2) SlopOS also refuses environment-variable startup back doors

`capshell-env-startup-posture-v0.md` deepens the same lesson.
It says the child environment is complete and explicit, and it rejects names whose documented meaning is shell startup, loader injection, or runtime bootstrap such as `PATH`, `ENV`, `BASH_ENV`, `PYTHONPATH`, `PYTHONHOME`, `PYTHONSTARTUP`, `LD_*`, and `BASH_FUNC_*`.
That means Schell should be extremely suspicious of any terminal-side “shell integration” story that works by quietly smuggling startup behavior through the environment.
The shell may offer integration, but startup authority must remain explicit.

## 3) SlopOS says reviewed argv is literal and expansion-free until an explicit interpreter owns it

`capshell-command-string-posture-v0.md` and `capshell-word-expansion-posture-v0.md` keep another old shell trap under control.
The front-end does not get a hidden expansion pass for globs, `$VAR`, `~`, command substitution, or other shell folklore.
Literal tokens stay literal until an explicitly chosen interpreter later gives them other meaning under its own already-declared semantics.
That pressures Schell toward a very specific design rule:
pretty command blocks, active-input luxuries, click-to-edit, completion cards, and object actions should remain weaker than exact launch truth.
If the terminal wants to help, it should insert or propose explicit tokens, not invent a second pre-exec shell.

## 4) SlopOS says pipelines are explicit stage handoff, not hidden peer authority passing

`capshell-pipeline-posture-v0.md` is another huge gift.
It treats pipelines as sequences of stage-local `capshell.exec` actions and refuses direct peer handle/FD passing as ambient shell folklore.
Cross-stage handoff uses explicit artifacts, explicit plumb messages, or explicit portal/service outputs rebound into the next stage.
That is exactly the right pressure for Schell's richer terminal ideas.
Object cards, route hints, quick-fix rails, open/reveal/attach actions, and copied command blocks should all travel through explicit packet surfaces rather than invisible helper IPC.

## 5) SlopOS already has a narrower route vocabulary worth stealing

RFC-0117 (`plumb-messages-and-cli-intents.md`) makes the import even clearer.
It preserves the Plan 9 mental model but keeps Phase 1 request-local and non-authoritative:
messages carry typed intent and references, not raw capabilities; handler inventory is not made ambient; and stronger authority still arrives only through explicit already-held capabilities or portal/session outcomes.
That is the exact shape Schell wants.
The terminal should feel brilliant at turning visible subjects into candidate actions, while refusing to make click-routing or command-block actions a second hidden authority plane.

## 6) The companion archive suggests at least five separate shell+terminal objects

Putting those surfaces together suggests one clean Schell family:
- **shell mark witness** — prompt/input/output/receipt boundaries with claim strength,
- **startup-humility witness** — builtin / explicit package / local compat / unknown, plus any hidden-hook refusal,
- **command-block witness** — guessed / marked / shell-authenticated block identity and provenance,
- **intent-route packet** — exact subject plus reveal/open/insert/attach/propose route posture,
- **historical receipt** — durable outcome truth that stays weaker than current live state or current startup footing.

That split matters a lot.
If Schell flattens these objects, it will recreate exactly the ambient-shell problem SlopOS keeps refusing.

## 7) A compact v0 posture worth stealing

A good early Schell shell-integration family should probably say:
- whether command boundaries are shell-authenticated, merely terminal-marked, or heuristic,
- whether the current shell integration came from shipped builtin support, explicit addon, compat shim, or unknown injection,
- whether prompt-click, output-selection, and jump-to-command luxuries are available, degraded, or absent,
- whether route actions are inspect-only, insert-first, reveal, open, or review-required,
- and whether any restored block is live, historical, or unknown.

That would make command-aware luxury much more humane without forcing one final OSC treaty, terminal brand, PTY replacement, or startup-customization subsystem.

## 8) Decision-light next move

A strong next move is to define one **shell integration marks / startup humility / command-block honesty** family that proves:
- shell-owned command boundaries,
- explicit startup footing,
- trust-graded block luxuries,
- and plumb-first object routing
can coexist without turning Schell into a hidden rc-loader, a terminal-brand monoculture, or an IDE-style confidence trick.

That keeps Schell ambitious while learning the right lesson from SlopOS:
**command-aware luxury is welcome, but startup footing, shell-owned marks, local block UX, typed routes, and durable receipts must stay separately admitted.**
