# Research synthesis, pass XCI (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should make time posture legible — wall time, monotonic elapsed time, suspend-aware elapsed time, logical order, and restore epochs should stay separately named so timestamps and durations never collapse into one flattering clock story.**

This seam matters because the current ecosystem keeps rediscovering the same pattern:
- operating systems expose genuinely different clock families,
- shells preserve different kinds of history time,
- terminals expose line timestamps and replay views,
- recording formats mix absolute session metadata with relative event offsets,
- and restored/virtualized environments can shift clock footing without changing the visible text much.

That is useful.
It is also exactly how shells and terminals end up overclaiming what time really means.

The key imports from the web pass were:
- Linux clock docs showing that `CLOCK_REALTIME`, `CLOCK_MONOTONIC`, `CLOCK_BOOTTIME`, and `CLOCK_TAI` carry different semantics around jumps, suspend, and leap-second posture.
- Linux time namespaces showing that monotonic and boot-time clocks can be virtualized for migration and checkpoint/restore.
- iTerm2’s line timestamp and relative-baseline ergonomics proving that relative timeline UX is genuinely worth stealing.
- Bash and PowerShell history docs proving that shells already preserve different kinds of temporal evidence — order, start/end times, per-session and cross-session history — without one unified truth model.
- asciinema’s cast format proving that header timestamps plus relative event offsets are a powerful and honest replay shape.
- VMClock’s disruption markers, status values, and `vm_generation_counter` proving that restored-state time honesty benefits from explicit epoching rather than vague “restored” chrome.

The resulting Schell posture is now tighter:
- **time kind should be explicit** rather than inferred from formatting;
- **relative timestamp luxury should stay weaker** than exact command or task basis;
- **restore epochs should be first-class badges** rather than a footnote inside replay lore;
- **logical order should stay distinct from clock time** when the thing that matters is scoped sequencing rather than an absolute timestamp;
- and **history / replay / remote imports should keep claim-strength posture** instead of silently becoming present-tense truth.

That leads to a very decision-light but very high-value specimen set:
- time-ground cards,
- relative-baseline line timestamps,
- command chapters with separated wall/duration/suspend-aware pills,
- restore-epoch badges,
- replay cards that split header time from relative offset,
- and order-versus-time explainers.

The bigger architectural choices are still worth deferring:
- final timeproof and authenticated wall-clock stack,
- final replay timestamp/export substrate,
- final deadline engine,
- final remote clock-comparison protocol,
- and final logical-time integration across collaboration, queues, and replay.

The no-regret move is smaller than all of those:
**make time posture visible before time machinery gets large.**
