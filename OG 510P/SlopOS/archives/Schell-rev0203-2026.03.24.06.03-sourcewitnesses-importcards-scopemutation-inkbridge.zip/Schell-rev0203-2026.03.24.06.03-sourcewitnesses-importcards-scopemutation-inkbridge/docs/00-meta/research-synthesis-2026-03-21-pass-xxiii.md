# Research synthesis, pass XXIII (2026-03-21)

This pass keeps another design rule in view:
**reusable commands should become explicit seeds with visible parameters, provenance, and review landings instead of hiding in aliases, prompt lore, or sticky AI memory.**

The outside landscape keeps converging on a surprisingly consistent pattern.
Products want command reuse, search, sharing, and AI context to feel much better than plain shell history.
The good versions make the unit explicit and keep execution reviewable.
The dangerous versions blur saved work into ambient authority.

## 1) Parameterized command reuse works best when it lands back in editable input

Warp's workflow docs say a workflow is a parameterized command you can name and save, and that workflows are searchable from the Command Palette. More importantly, when a workflow is selected, Warp pastes it into the active terminal input so the operator can adjust the arguments or command before running it.
That is an excellent Schell clue.
The important move is not "saved commands" by itself.
The important move is **review-first landing**.
See: https://docs.warp.dev/knowledge-and-collaboration/warp-drive/workflows

## 2) Parameters should stay first-class, not just text substitution folklore

Warp's workflow editor and notebook command blocks both support explicit `{{argument}}` placeholders, and Warp supports enum-style arguments with suggestions when filling them in.
That suggests Schell should treat reusable-command parameters as visible cards or slots rather than as hidden shell-variable lore.
See: https://docs.warp.dev/knowledge-and-collaboration/warp-drive/workflows ; https://docs.warp.dev/knowledge-and-collaboration/warp-drive/notebooks

## 3) Reusable command blocks should still behave like exact chapters

Warp's terminal blocks docs say a block groups commands and outputs into one atomic unit, with actions like copy command, copy output, re-input, share, and bookmark.
That remains a strong pressure source for Schell.
A workflow seed should ideally be born from an exact command chapter, not from a fuzzy text scrape across several prompts and outputs.
See: https://docs.warp.dev/terminal/blocks

## 4) Share/export must be explicit and scoped

Warp's block-sharing docs say sharing a block is explicitly opt-in, sends command information to Warp's server, and lets the user choose which parts of the block to share.
That is a very stealable posture.
Schell should treat help/export/share as a separate explicit lane, not as a default consequence of making reusable command artifacts first-class.
See: https://docs.warp.dev/terminal/blocks/block-sharing

## 5) Search filters matter more than one giant global memory bucket

Atuin's config docs expose filter modes like global, host, session, directory, workspace, and session-preload, and it supports automatic workspace filtering in git repositories.
That is a strong hint for Schell.
A chapter or workflow seed browser becomes much more honest and useful when the operator can constrain the search to the current peer, session, workspace, or lane instead of rummaging through one universal comforting archive.
See: https://docs.atuin.sh/cli/configuration/config/

## 6) Synced history is attractive, but sync is not the first decision

Atuin's sync docs say history can be synced with end-to-end encryption.
That is a good reminder that cross-machine recall has real value.
But it is still a later decision for Schell.
The no-regret import is not "build sync now."
It is **keep the reusable artifact small, exact, partition-aware, and redaction-aware enough that sync remains possible later.**
See: https://docs.atuin.sh/cli/guide/sync/

## 7) Predictor plugins are useful only when their source stays visible

PowerShell's current docs say PSReadLine supports plug-in modules for Predictive IntelliSense.
That is a very useful design hint.
Schell should let workflow seeds, chapter recall, policy-local recipes, and plugin suggestions coexist, but the operator should always be able to tell where a suggestion came from.
See: https://learn.microsoft.com/en-us/powershell/scripting/learn/shell/tab-completion?view=powershell-7.5

## 8) Agent context separation is a real product feature, not just a safety essay

Warp's agent-modality docs separate terminal blocks from agent-conversation blocks, and only terminal blocks live in the terminal blocklist by default.
That directly reinforces Schell's lane discipline.
Saved command reuse should not silently absorb proposal-lane material just because it looks useful.
See: https://docs.warp.dev/agent-platform/local-agents/interacting-with-agents/agent-modality

## 9) Shell integration remains the foundation, not the whole answer

Ghostty's shell-integration docs keep showing the same beneficial pattern: prompt-aware editing, prompt jumping, safe cursor placement, better cwd inheritance, and shell-marked command selection all get better once the shell marks prompt boundaries.
That still matters for reusable command seeds because the cleanest seed probably comes from one shell-authenticated chapter.
But shell integration should not by itself become a workflow authority plane.
See: https://ghostty.org/docs/features/shell-integration

## 10) The past lesson is not just "aliases are old"

Classic shells made command reuse cheap, but they also taught several bad habits:
- aliases and rc files hide when reuse becomes execution policy,
- copied snippets bleach away authorship and basis,
- notes and runbooks drift away from the exact command chapter they came from,
- and shared snippets often skip the question of what is safe to reveal.

The modern product lesson is better:
**make reusable commands explicit artifacts, keep their parameters visible, land them in reviewable input, and keep share/export/reporting as separately named actions.**

## 11) A compact Schell v0 cluster is strong

A decision-light first cut probably needs only:
- one explicit **workflow seed** object derived from an exact chapter,
- one **parameter-card** surface for visible arguments/defaults/enums,
- one rule that selecting a seed **lands in active input or review**, not auto-run,
- one **provenance badge** family preserving lane/source/peer,
- one **share posture** family (local only / attach for help / explicit durable export),
- and one **search filter** ladder for peer / session / workspace / lane.

## 12) Decisions intentionally kept open

This pass does **not** freeze:
- one notebook or runbook product shape,
- one team-sharing backend,
- one sync service or encryption story,
- one seed serialization format,
- one plugin ecosystem for suggestion providers,
- or one collaborative annotation model.

The no-regret move is narrower:
**turn repeatable commands into explicit seeds with visible parameters and provenance, and keep selection, sharing, and execution as separate named steps.**
