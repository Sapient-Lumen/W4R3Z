# SlopOS datacube evaluation — pass X

This pass keeps one new synthesis in view:
**Schell should make reentry and restoration honest: a reopened pane, found block, bookmarked command, or restored session is useful evidence, but it is not the same thing as a current live target.**

SlopOS keeps teaching the same deeper lesson from new angles:
exact selection, exact live-session scope, and explicit restore/import seams matter more than friendly continuity theater.
DelayBasin adds the process lesson that the archive should ship one trusted latest path and one explicit non-live state when continuity is only partial.
The next Schell import is to make that visible in the shell+terminal itself.

## Strongest SlopOS lessons right now

### 1) Live sessions, restored references, and inventories must stay distinct

SlopOS's caprpc session posture is unusually clear.
Live references are session-scoped runtime state.
Disconnect is fail-stop.
Continuity requires an explicit bootstrap or restore/import seam, not generic “the thing is probably still there” optimism.

Local import for Schell:

- a block, pane, or workflow search result should say whether it is **live**, **historical**, **restored**, **receipt-derived**, or **unknown**,
- a session restore should not silently recreate attachability or current-process truth,
- and “open from history” should not masquerade as “resume current authority”.

This is one of the biggest lessons Schell must learn from the past.
Many terminal products look smoother by blurring restored UI continuity with live process continuity.
Schell should refuse that blur.

### 2) Session/profile choice is a separate seam from generic open

The new OpenURI session-selection boundary is also useful.
SlopOS keeps mediated generic open small on purpose and refuses to overload it with browser session, profile, or cookie-jar selection semantics.
That is the same discipline Schell needs around click-to-open, semantic history, and object actions.

Local import for Schell:

- clicking a path or URI in terminal history may request a bounded open,
- but it should not silently inherit hidden browser/profile/session assumptions,
- and generic open should stay distinct from explicit private-session, disposable, or reattach workflows.

That keeps “nice click behavior” from turning into an accidental authority plane.

### 3) Restore is not the same thing as current live state

SlopOS keeps drawing this line across capability restore, document restore, capture sessions, and volition/current-session bindings.
A restored thing may be useful.
It may even be the best operator starting point.
But it does not automatically prove current liveness, current entitlement, or current exact target identity.

Local import for Schell:

- restored panes and blocks should be clearly marked as restored historical state until live truth is reacquired,
- bookmarks and search results should preserve whether they point to a current live object or a durable historical object,
- and “recent” should never become a hidden proof of “current”.

### 4) Exact target selection should remain explicit even when navigation gets richer

SlopOS refuses public session inventories and ambient target discovery on live capability surfaces.
That is a useful warning for terminal palettes and history search.
A rich unified search UI is great, but only if finding something does not silently mean you are now targeting it with strong actions.

Local import for Schell:

- lane-aware search and command palettes may unify discovery,
- but action resolution should still distinguish “select for inspection”, “seed a workflow”, “open historically”, and “strong rerun/attach on an exact live target”.

### 5) DelayBasin's reentry-cue discipline belongs in the terminal too

DelayBasin now pressures archives to maintain one primary landing cue, a durable latest path, and explicit stale/generic-success paths that do **not** count.
That maps naturally to a shell+terminal with session restoration, block bookmarks, and receipts.

Local import for Schell:

- one primary latest path should lead to the current active-input/work-lane truth,
- restored/history/search surfaces should remain clearly secondary,
- and a broken or stale reentry cue should produce a small hold/recover card instead of quiet misdirection.

## What Schell should deliberately refuse for now

### Refuse restored-as-live theater

Restored panes, blocks, or prompts should not look attachable or executable just because the UI rebuilt them convincingly.

### Refuse one giant unified “current object” story

Search, bookmarks, receipts, restored panes, and active sessions can share discovery surfaces without sharing one action contract.

### Refuse hidden session/profile semantics in semantic open actions

Per-line cwd and semantic history are useful, but generic open should stay generic unless an explicit named seam asks for more.

### Refuse ambient latest-path confusion

A newer-looking file, pane, or bookmarked item should not outrank the explicit current live lane just because it opened successfully.

## Current consequence for Schell

The best next ratchet is now:

1. **one primary reentry cue for the current live lane,**
2. **explicit restored/historical/unknown state badges,**
3. **hold cards that explain what must be reacquired for strong action,**
4. **semantic-history style path opening that stays trust-graded and session-honest,**
5. **and lane-aware search that unifies discovery without flattening authority.**

That is a powerful way to make Schell feel super awesome while still keeping transport, renderer, search index shape, and final restoration model open.
