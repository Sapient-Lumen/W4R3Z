# Research synthesis, pass XCIV (2026-03-22)

This pass keeps one fresh rule in focus:
**one of the safest ways to make a shell+terminal feel amazing is to make the shell language less magical before making the terminal more magical.**

The current ecosystem keeps pointing in the same direction.
Oil/YSH pressures toward simpler word evaluation.
Nushell shows that external commands can carry explicit signatures without becoming a universal object runtime.
fish keeps insisting on orthogonality and restraint.
PowerShell keeps reminding us how easily native-command parsing becomes a second problem domain.
Ghostty, kitty, VS Code, Warp, and Zellij keep proving that enormous comfort can live above the language floor — if that floor stays honest.

## 1) The parser lesson is not just “quote better”

PowerShell remains one of the clearest warnings that native-command interop becomes treacherous when the operator cannot tell what parser is in charge.
Its docs still distinguish PowerShell parsing from what native commands receive, preserve stop-parsing for some cases, and document ongoing compatibility pressure around native argument passing.

That is not merely a PowerShell quirk.
It is a general design lesson:
**a shell becomes harder to trust when it carries too many hidden language stories for one line of input.**

Schell should therefore aim for:
- fewer parse stories in the native lane,
- explicit compatibility membranes when another interpreter is in charge,
- and exact reveal surfaces that do not reconstruct meaning from folklore after the fact.

## 2) Oil's simple-word pressure is one of the best steals available

Oil/YSH's “simple word evaluation” work is especially useful because it names a path away from classic shell expansion drama without requiring a whole giant platform commitment.
The key insight is that command words get easier to reason about when they are parsed and evaluated more like an ordinary language instead of a pile of delayed expansion stages.

Schell should steal that pressure before deciding how much of Oil to copy.
The stealable part is:
- single obvious parse flow,
- literal words staying literal by default,
- and explicit evaluation forms rather than ambient expansion folklore.

## 3) Nushell's `extern` story is another unusually high-value steal

Nushell shows something equally important:
external commands can carry enough explicit signature information to power parse-time checks, completions, syntax highlighting, and better help without forcing the shell to pretend that every tool speaks one universal native ontology.

That gives Schell an appealing middle path.
It does not have to choose between:
- “externals are opaque forever,” and
- “every external command becomes part of one giant object shell.”

A better phase-zero move is **known extern packs**:
small, inspectable signature artifacts that improve completion, review, help, and workflow cards while staying weaker than exact reviewed launch.

## 4) fish keeps teaching the discipline rule

fish's old but still valuable design pressure remains one of the best guardrails for a new shell:
small orthogonal features age better than overlapping cleverness.
That matters even more in Schell because the project is already collecting a huge number of terminal luxuries.

The more luxurious the terminal gets, the more Schell needs:
- fewer overlapping command-language rules,
- fewer startup-time meaning mutations,
- and fewer “there are three ways to do this, pick your favorite spell” design habits.

## 5) The terminal ecosystem shows where the luxury should live

Current terminals keep proving that enormous operator comfort is possible above the parser layer:
- Ghostty and kitty show the value of shell-aware prompt and output boundaries,
- VS Code shows the value of exact command-line reporting and provenance-aware shell integration,
- Warp shows that parameterized workflows can be searchable and editable before run,
- and Zellij shows that layouts and session comfort can be explicit text artifacts rather than one hidden runtime blur.

This is important because it suggests a healthier split for Schell:
**put more comfort into review, navigation, capture, workflow, and session surfaces, and less magic into line interpretation itself.**

## 6) The bounded answer Schell should carry forward

The right phase-zero answer is not one final language.
It is a smaller set of explicit moves.

### Must-learn failure families
- multiple hidden parse stories for one line of input,
- string convenience that secretly becomes interpreter indirection,
- startup/integration layers that change meaning without clear authorship,
- workflow objects that outrank fresh review,
- and terminal luxury that compensates for language confusion instead of sitting above exact meaning.

### Stealable moves
- a smaller native parse floor,
- explicit command-lane badges,
- known-extern signature packs,
- exact argv / lane reveals,
- workflow insertion into active input before run,
- and shell-aware terminal chapters and captures that do not claim more meaning than the shell can prove.

### Moves still refused
- one final grammar,
- one final structured pipeline ontology,
- one final extern metadata format,
- one final compatibility layer for importing legacy shells,
- or one final authenticated shell↔terminal protocol.

## 7) Compact conclusion

One of the smartest moves available right now is surprisingly conservative:

**make command meaning more boring, then let the shell+terminal become luxurious on top of that boring truth.**

That is how Schell can steal the best current ideas without letting the prettiest ideas choose the architecture too early.
