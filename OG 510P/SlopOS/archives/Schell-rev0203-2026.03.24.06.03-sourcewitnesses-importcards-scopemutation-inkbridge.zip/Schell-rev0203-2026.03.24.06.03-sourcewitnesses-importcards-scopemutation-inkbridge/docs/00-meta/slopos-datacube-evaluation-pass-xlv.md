# SlopOS datacube evaluation, pass XLV

This pass keeps one bounded thesis in focus:
**SlopOS already refuses late retargeting, hidden interpreter discovery, and observational learn-mode overreach; Schell should import that discipline into failed-command recovery so explain/correct/install/help flows become luxurious without turning “command not found” into a stealth execution or package-authority plane.**

That is a particularly good ratchet while SlopOS is still design-phase too.
It gives Schell a sharper recovery story without forcing any final package-manager, search, or remediation backend.

## 1) D-CAPSHELL keeps exact executable identity stronger than adjacent convenience

SlopOS’s current `D-CAPSHELL` posture is already unusually strong here.
The runner binds one explicit `role="exec"` selector.
It does not silently retry through `env`, `sh`, shebang fallback, file associations, or late reopen-by-name.
And it keeps `capshell.exec` off a hidden command-string plane.

That matters directly for Schell.
A failed command is not permission to quietly choose a different executable, a package alias, a profile hook, or a shell fallback.
If a repair path exists, it should be a separately named adjacent workflow, not silent reinterpretation of the original run request.

## 2) Learn mode stays observational only, which is exactly the repair-provider lesson Schell needs

One of the best recent SlopOS moves is the explicit posture that learn mode is observational only.
Denied effects stay denied.
Reports stay non-authoritative.
There is no auto-edit, auto-approve, or auto-rerun behavior in the v0 posture.

That maps almost perfectly onto command-repair UX.
Schell can absolutely collect explainers, similar-command suggestions, package hints, and workflow seeds.
But those should remain visibly advisory until the user takes a fresh review path.
The danger to avoid is letting a brilliant repair surface quietly become a second execution plane.

## 3) Plumb and portal thinking suggest a clean split for adjacent remediation workflows

Across SlopOS, the strongest pattern is that nearby workflows still get their own seam names.
Open is not preview.
Preview is not materialize.
Transfer is not open.
Deferred work is not durable background presence.
Accessibility observe is not inject.

Schell should steal that exact habit here.
For a failed command, adjacent helpful workflows might include:
- explain why resolution failed,
- reveal current resolution/path basis,
- correct the token,
- suggest a package,
- open docs,
- insert a repair command,
- or stage an install command for review.

Those are all useful.
They just are not one generic “fix it” verb.

## 4) Exact-object discipline is a strong antidote to command-not-found folklore

Classic shells and OS add-ons often smuggle in a lot here:
- typo correction,
- package lookup,
- alias fallback,
- wrapper fallback,
- changed PATH/profile assumptions,
- and sometimes hidden rerun behavior.

SlopOS’s exact-object discipline points the other way.
It keeps the original reviewed target exact.
If a new target is proposed, it is a **new** reviewed choice.
That is exactly the Schell lesson.
“Suggested replacement” should always present itself as a fresh candidate object/command, never as proof that the original command secretly meant something else.

## 5) The import pressure for Schell is narrow and high-value

Schell does not need a package-manager monoculture or one universal remediation engine.
The right import from SlopOS is smaller and cleaner:
- keep exact failure identity first,
- keep repair providers source-labeled and observational,
- keep correction/install/docs/reroute as separately named offers,
- and require fresh review before any new executable, package install, or profile mutation actually runs.

That would let Schell become much more humane than classic shells at “what should I do now?” moments while still honoring one of SlopOS’s best current instincts:
**adjacent convenience should never rewrite the reviewed meaning of the original action.**
