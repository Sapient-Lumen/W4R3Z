# Research synthesis — pass V

This pass asks a tougher question than the earlier ones:
**what should Schell steal immediately because it is clearly high-leverage and low-regret, and what should it hold because the steal would silently lock the architecture?**

## Lessons we must learn from the past

### 1) Shell truth beats prompt scraping

The old FinalTerm / iTerm2 semantic-prompt idea is still the right starting lesson: terminals get dramatically better when the shell marks where prompts, commands, and output begin and end.
VS Code, WezTerm, Ghostty, and kitty all keep rediscovering that same truth in different forms.

Local law for Schell:

> if the shell knows where prompt, active input, reviewed action, receipt, and denial boundaries are, do not make the terminal guess them from pixels or regexes.

### 2) Trust grades matter for block actions

VS Code is especially valuable here because it does not treat every command block as equally trustworthy.
Its shell-integration docs and release notes explicitly preserve stronger and weaker command detection, exact command reporting, and nonce-backed trust.

Local law for Schell:

- visible blocks are not all equal,
- block actions should depend on trust grade,
- and effectful actions should require shell-authenticated truth instead of guessed buffer text.

### 3) Prompt-safe click editing is worth stealing

Ghostty and kitty both show that prompt editing becomes much nicer when the terminal knows the editable region of the active shell prompt.
Click-to-cursor is not fluff when it is safely bounded to current editable input.

Local law for Schell:

- allow pointer editing only inside shell-marked active input,
- never confuse old output with current input,
- and keep the same behavior degradable to plain keyboards and plain transcripts.

### 4) Notifications should be state-aware, not noisy

Ghostty’s command-finish notifications are a good example of a humane feature that does not require huge architecture commitments.
The useful pattern is not “notify on everything.”
It is “notify when the command was long enough and the operator is no longer focused here.”

Local law for Schell:

- tie notifications to duration and focus rules,
- and later connect them to receipts, background state, and watched actions rather than raw process exit alone.

### 5) Humane shell UX is a design principle, not a garnish

fish’s design docs are a strong reminder that user-friendliness and expressiveness do not have to be enemies, and that orthogonality matters.
This is exactly the antidote to both shell folklore and clever demo-ware.

Local law for Schell:

- keep features orthogonal,
- keep interaction humane,
- and treat “pleasant to use” as part of correctness for an interactive shell.

### 6) Structured pipelines are powerful but expensive

Nushell and PowerShell prove that structured data in pipelines can be genuinely useful.
They also prove that this choice is architectural, not cosmetic.
Once the shell makes that jump, many other surfaces inherit the cost.

Local law for Schell:

- steal structured sidecars and typed summaries first,
- hold off on universal object pipelines,
- and do not let pipeline ontology get frozen before the first reviewed interaction is proven.

### 7) Permission timing should stay tied to the current action

Android’s runtime-permission guidance and XDG portal patterns still point in the same direction: ask in context, explain narrowly, allow denial, and degrade gracefully.

Local law for Schell:

- review cards should appear at the moment of need,
- denials should teach without widening,
- and background or durable grants should remain explicit rather than ambient.

## Nifty ideas worth stealing now

### Shell-authenticated command blocks with a trust ladder

Carry a simple early trust ladder:

- guessed,
- marked,
- shell-authenticated.

That is enough to make copy/select broadly available while reserving rerun / attach / replay for stronger truth.

### Sticky reviewed-action headers

VS Code’s command guide and sticky-scroll patterns point to a good Schell move: keep the currently visible reviewed action, receipt, or denial legible while the operator is inspecting its output.

### Prompt-safe click-to-edit

Steal the bounded version only: active input is editable like a normal field; historical output is not.

### Threshold-based finish notifications

A very high-value, low-regret feature for long builds, tests, and backgrounded work.

### Readonly replay mode

A replay or postmortem should feel navigable and live-looking while refusing to send input to the real substrate.

### Session atlas / jump surfaces

Search or jump by receipt, denial, working directory, artifact, or background-state change rather than only by scroll position.

### Exact preview without hidden authority

Inline previews for artifacts, receipts, and digests are great, as long as preview remains observational and does not silently imply reopen authority.

## Dangerous seductions to refuse for now

### Do not freeze the final transport too early

OSC sequences are useful inspiration, but Schell should not decide yet whether its durable transport is escapes, side-channel RPC, or a hybrid.

### Do not let rich block UI become correctness

A block UI should accelerate truth, not contain the only copy of it.

### Do not over-learn from history UIs

iTerm2 and similar tools show that command history UIs are useful, but history is still not receipt truth, and saved command memory is not approval evidence.

### Do not let terminal remote control quietly become shell authority

Powerful terminal control planes are fascinating, but Schell should not confuse “the terminal can do this” with “the shell can truthfully promise this.”

### Do not commit to a universal object pipeline yet

Structured pipelines remain attractive.
They are still a whole-project decision.

## Best current steal pattern

The best current pattern is:

- steal **truth boundaries,**
- steal **trust grading,**
- steal **prompt-safe editing,**
- steal **threshold notifications,**
- steal **sticky navigation objects,**
- and refuse to steal **product lock-in, pipeline maximalism, or browser/session control** before Schell has earned them.
