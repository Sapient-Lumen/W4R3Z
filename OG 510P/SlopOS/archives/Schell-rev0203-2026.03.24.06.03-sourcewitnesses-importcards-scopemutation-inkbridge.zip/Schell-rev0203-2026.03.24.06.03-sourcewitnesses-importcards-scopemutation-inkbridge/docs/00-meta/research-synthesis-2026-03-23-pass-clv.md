# Research synthesis — 2026-03-23 — pass CLV

This pass sharpens the next smaller lesson from current shell+terminal tools:
**modern terminals increasingly route dropped objects by where they land, but they still tend to flatten the aftermath into one vague story.**

That points to a good next Schell move:
**landing-zone witnesses, target-sensitive object routes, and explicit route-family truth** rather than one more fuzzy “drop into terminal” myth.

## 1) Windows Terminal proves a drop target can be a launch surface, not a prompt

Current Windows Terminal docs say you can drag and drop a file or folder over the New Tab button to open your default profile with that file or folder.
By default this opens a new tab, while `Alt` opens a new pane and `Shift` opens a new window.

That is a superb clue for Schell.
A dropped object does not always belong to input insertion.
Sometimes the terminal chrome is the real target and the right truth is a launch-route witness.

## 2) kitty proves object drops can be routed by object kind into explicit actions

kitty’s current open-actions docs say files and URLs dropped onto the dock icon can be opened with kitty, with default actions like opening text files in the editor, images with `icat`, shell scripts in a shell, and `ssh://` URLs with the `ssh` command.

That matters because it proves a target surface can resolve an object route based on object kind without pretending the route is plain text insertion.
The magical part is not the drag gesture.
The magical part is the explicit, customizable route family.

## 3) iTerm2 proves line-relative drops can widen into remote transfer offers

iTerm2’s shell-integration docs say that option-dragging a file into iTerm2 offers to upload the file via `scp` to the remote host into the directory corresponding to the line where the file was dropped.
It also exposes download-with-scp on filenames in output.

That is one of the clearest possible warnings for Schell.
A drop can be target-sensitive, line-sensitive, peer-sensitive, and much stronger than local insertion.
If the shell+terminal does not name that route explicitly, it will flatter one gesture into too much authority.

## 4) WezTerm and Windows Terminal both prove insertion routes are transforms, not object truth

WezTerm’s docs say dropped files from other programs can have their paths pasted into the terminal and `quote_dropped_files` controls how those filenames are quoted, with options like `None`, `SpacesOnly`, `Posix`, and Windows-specific quoting.
Windows Terminal’s `pathTranslationStyle` setting can translate dropped Windows paths into WSL, Cygwin, MSYS2, or Mingw forms during drag-and-drop operations.

That is a strong design clue.
The inserted string is a route-specific transform for one target environment.
It should not impersonate canonical object identity.

## 5) XDG File Transfer proves file-bearing drop is already an offer/retrieve session

The current XDG File Transfer portal docs say the portal acts as a middle-man for drag-and-drop or copy-paste file transfer, uses `application/vnd.portal.filetransfer`, retrieves files by key, exports them through the document portal as needed, and does not keep that access across sessions.

That is important because it shows the richer truth is already structured as a transfer session, not as magically trusted prompt text.
Schell should import that humility even if its final backend mix stays open.

## 6) Ghostty keeps reminding us that object ingress is also a safety seam

Ghostty’s 1.1 release notes say dropped files and selected text were made to work on GTK and that pasted file paths are shell escaped on macOS.
Its 1.3.0 release notes say control characters in pasted or drag-and-dropped text could execute arbitrary commands in some shell environments and that the issue was fixed.

That is the final warning label.
The right move is not to fear drag/drop.
It is to keep route, transform, and later spend/transfer posture visible.

## 7) The concrete Schell move

Schell should add a compact landing-zone contract:
- **drop witness** — what payload arrived,
- **landing zone** — prompt / chrome / shelf / host-launch lane / remote line / unknown,
- **route family** — insert-path / `cd` seed / open-here / new-pane-here / new-tab-here / import / attach / delegate / upload-offer,
- **transform posture** — quoted / translated / escaped / portal-key / raw,
- **peer posture** — local / remote / delegated / mixed,
- **receipt posture** — candidate-only / launched / attached / imported / offered / blocked.

That is enough to steal target-sensitive launch luxury, object-aware open routes, and remote-upload comfort while refusing the old lie that a drag gesture has one universal meaning.
