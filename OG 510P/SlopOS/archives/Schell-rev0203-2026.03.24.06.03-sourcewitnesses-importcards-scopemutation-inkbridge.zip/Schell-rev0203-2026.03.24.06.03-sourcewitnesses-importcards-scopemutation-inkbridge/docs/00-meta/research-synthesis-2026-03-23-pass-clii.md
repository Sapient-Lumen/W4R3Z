# Research synthesis — 2026-03-23 — pass CLII

This pass sharpens the next narrower lesson from current shell+terminal tools:
**full-screen or prompt-adjacent luxury is worth stealing, but a visible prompt or returned normal screen should not by itself mean the shell has cleanly, presently, and strongly reacquired the floor.**

That points to a good next Schell move:
**borrowed screen leases, prompt-reclaim witnesses, and baseline-reassert cards** rather than one more vague story where “the prompt came back” settles everything.

## 1) xterm still teaches the old lesson: alternate screen is a borrowed screen, not ordinary history

The xterm manual says the alternate screen saves the current screen, replaces it with an alternate buffer, and disables saving lines scrolled off the top until the normal screen is restored.
The terminfo notes also remind us that `smcup` clears memory before switching to the alternate screen.

That matters because the shell should not treat full-screen life as “just more scrollback.”
The app has borrowed the floor.
What comes back later may be very useful, but it is not identical to ordinary shell-owned history or prompt truth.

See:
- xterm manpage
- xterm terminfo notes

## 2) tmux and WezTerm both show that borrowed-screen behavior changes local controls

tmux exposes `alternate-screen` as an explicit pane option rather than an invisible universal fact.
Its manual says alternate-screen preserves the visible pane contents for interactive apps and restores them on exit.

WezTerm's `alternate_buffer_wheel_scroll_speed` docs say that when an app is in the alternate screen, that screen has no scrollback, and when mouse reporting is not enabled the mouse wheel is converted into Up/Down key events for the app.

That is a great design clue.
When a screen is borrowed, local wheel/copy/navigation semantics may shift as well.
Schell therefore needs a way to say who currently owns the floor and which local gestures are terminal-local versus app-directed versus shell-known.

See:
- https://man7.org/linux/man-pages/man1/tmux.1.html
- https://wezterm.org/config/lua/config/alternate_buffer_wheel_scroll_speed.html

## 3) Ghostty and kitty both say prompt luxuries only become valid at the current prompt

Ghostty 1.3.0 says click-to-move works within an **active shell prompt** via OSC 133 prompt semantics.
Its config reference says the feature requires shell integration and may work through synthetic arrow motions or direct click events, with possible edge-case surprises.

kitty's default mouse action similarly checks whether the click happened at the **current shell prompt** before moving the cursor, and kitty's shell integration docs say that turning off prompt marks disables jumping to prompt, browsing last-command output, and click-to-move cursor behavior.

That is exactly the lesson Schell should import.
Prompt luxury should key off a **live prompt reclaim witness**, not merely “some prompt-like thing is visible again.”

See:
- https://ghostty.org/docs/install/release-notes/1-3-0
- https://ghostty.org/docs/config/reference
- https://sw.kovidgoyal.net/kitty/conf/
- https://sw.kovidgoyal.net/kitty/shell-integration/

## 4) WezTerm and VS Code show how much can ride on shell-confidence and semantic marks

WezTerm's `ScrollToPrompt` action depends on OSC 133 semantic prompt escapes that distinguish Prompt, Input, and Output zones.
VS Code's terminal appearance docs say `${shellCommand}` only works when shell integration has **high confidence** in the detected command line, and `${shellPromptInput}` is a separate shell-integration value.
The January 2026 VS Code notes also added `terminal.integrated.stickyScroll.ignoredCommands`, acknowledging that some command-looking regions should not be promoted into stronger sticky prompt chrome.

That means a modern terminal can become dramatically nicer without pretending confidence is automatic.
The shell should therefore be able to say: borrowed floor ended, prompt-like region visible, shell reclaim still pending, reclaim complete, or reclaim refused/uncertain.

See:
- https://wezterm.org/config/lua/keyassignment/ScrollToPrompt.html
- https://code.visualstudio.com/docs/terminal/appearance
- https://code.visualstudio.com/updates/v1_109

## 5) The past lesson we must keep learning: prompt return is weaker than clean reentry

Classic terminal life keeps teaching the same failure mode:
- `vim`, `less`, `top`, and friends can borrow the screen,
- mouse/wheel behavior can change while the app owns the floor,
- copied residue may outlive the live app,
- and a visible prompt can return even when the terminal baseline, semantic marks, or trust posture still need reassertion.

So the right import is not “be suspicious of full-screen apps forever.”
It is:
**distinguish borrowed-screen live state, prompt-reclaim detection, baseline reassertion, and fresh shell-owned prompt truth.**

## 6) The concrete Schell move

Schell should add a compact borrowed-screen / shell-reentry contract:
- **screen lease witness** — shell / foreground app / room / mux / unknown owns the floor,
- **reclaim posture** — not-returned / prompt-like-return / shell-marked-return / baseline-reasserted / stranded / unknown,
- **gesture posture** — wheel-to-scrollback / wheel-to-app-keys / app-mouse / prompt-click / blocked,
- **promotion posture** — alt residue only / captured excerpt / command chapter exact / result exact,
- **reentry card** — what exactly became true when the floor came back,
- **reset card** — what exact baseline or mark family still needs reassertion before stronger prompt-local acts.

That would let Schell steal full-screen comfort, prompt clicks, jump-to-prompt, and command-aware paging while refusing the lazy myth that a visible prompt is the same thing as fresh shell footing.
