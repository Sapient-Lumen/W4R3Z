# Research synthesis — 2026-03-23 — pass CLIII

This pass sharpens the next narrower lesson from current shell+terminal tools:
**modern command surfaces keep getting better by separating insert, accept, rearm, and run — so Schell should stop treating every visible prompt line plus Enter as the same kind of fresh spend.**

That points to a good next Schell move:
**submit witnesses, rearm stamps, and explicit repeat ladders** rather than one more vague story where “the text was there and I hit Enter” settles everything.

## 1) fish keeps proving that suggestion comfort works best when acceptance stays explicit

fish’s current interactive docs say autosuggestions do nothing unless the user explicitly accepts them.
The bind docs go further and treat `accept-autosuggestion` as a named editor action that can fail when there is nothing to accept.

That is a strong design clue.
A useful modern shell should absolutely show ghost text and rich recall.
But visible suggestion and accepted buffer text are not the same object.
Schell should import that rule directly into submit posture.

## 2) Atuin and VS Code both make history luxury better when insert and run stay separate

Atuin’s current basic-usage docs say that inside the TUI, Enter executes the selected history item but Tab inserts it into the shell for editing.
Its config docs also keep history scoped by host, session, directory, workspace, or preload, which is another reminder that history rows are contextual recall objects before they are fresh intent.

VS Code’s shell-integration docs echo the same ladder.
Run Recent Command draws from current-session, previous-session, and common shell-history sources, and Alt writes the selected text to the terminal **without running it**.
Go to Recent Directory does the same for `cd` targets.
The appearance docs add that `${shellCommand}` only works when shell integration has **high confidence** in the detected command line.

That combination is exactly the pressure Schell should keep.
History recall can be luxurious, even cross-session luxurious, while still refusing to pretend that every recovered line is equally ready to spend.

## 3) iTerm2 shows that explicit row verbs beat one generic “reopen/rerun” story

iTerm2’s shell-integration docs keep command history actions specific: clicking reveals, double-clicking enters the command, and option-double-click emits a `cd` to the directory where it was last run.
The docs also say command history is stored separately per username+hostname.

That is a beautiful lesson for Schell.
A history row is not just “a command again.”
It may support reveal, insert, `cd`, compare, or later rearm.
The shell should preserve those verbs instead of flattening them into one ambient rerun myth.

## 4) Zellij teaches the right kind of friction for restored execution

Zellij’s current session-resurrection docs say it serializes layout and commands, but resurrected commands do **not** run immediately; instead they sit behind a “Press ENTER to run...” banner to prevent uncomfortable accidents.

That is one of the clearest past lessons still worth learning.
Restoration comfort is valuable precisely because it does **not** silently spend restored authority.
Schell should keep that rearm instinct even if it chooses a different UI shape.

## 5) Prompt-local luxuries also already depend on “current live prompt”, not merely visible text

Ghostty’s 1.3.0 release notes say click-to-move works within an **active shell prompt**.
kitty’s shell-integration docs and config docs similarly tie click-to-move and related prompt luxuries to the **current** shell prompt.

That matters because current prompt editing is already a kind of submit-adjacent confidence check.
The ecosystem is quietly telling us that “text at the bottom of the screen” is not enough.
Schell should carry that exactness into the act of submission itself.

## 6) The past lesson we must keep relearning: one visible line can represent many weaker states

The history of shells keeps trying to flatten these states into one:
- ghost suggestion,
- inserted history line,
- restored command,
- imported snippet,
- assistant-emitted command,
- prompt-like residue after handback,
- or truly fresh typed/rearmed input.

Modern tools are getting better precisely where they resist that flattening.
The nice idea to steal is not “more command search.”
It is:
**give every near-run surface an honest verb ladder and a clear rearm boundary.**

## 7) The concrete Schell move

Schell should add a compact submit/repeat contract:
- **submit witness** — what exact candidate is active now,
- **source posture** — typed / accepted / history / restored / imported / assistant / unknown,
- **arming posture** — fresh / rearm-required / rearmed / repeat-only / blocked,
- **ground posture** — same footing / drifted footing / reclaim pending / unknown,
- **repeat posture** — exact-repeat / review-repeat / reseed-only / none,
- **receipt linkage** — what later receipt or chapter proves the spend happened.

That would let Schell steal history decks, resurrected panes, run pickers, prompt-click editing, and assistant insertion comfort while refusing the old lie that Enter always spends one fresh obvious action.
