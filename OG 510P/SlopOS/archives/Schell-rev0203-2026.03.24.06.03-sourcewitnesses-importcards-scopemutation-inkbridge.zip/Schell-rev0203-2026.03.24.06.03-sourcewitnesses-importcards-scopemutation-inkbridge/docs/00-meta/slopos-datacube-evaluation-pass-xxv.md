# SlopOS datacube evaluation, pass XXV

**Schell should get much better at discovery — marks, pinned cards, command palettes, and local notes — without letting discovery surfaces quietly become preview, reopen, or execution authority. SlopOS keeps teaching the same deep rule: helpful discovery must remain weaker than explicit handles, explicit review, and policy-owned selection.**

This pass focuses on another tempting seam for Schell:
- command palettes,
- recent/pinned objects,
- marks and annotations,
- preview panes and snippets,
- and the dream of “find anything instantly.”

That seam is dangerous because it *feels* like harmless convenience.
But SlopOS keeps showing that history, preview, and selection are exactly where hidden authority grows back.

## 1) SlopOS keeps recents shell-owned and non-authoritative

The current OpenURI recent-items boundary is one of the clearest imports for Schell.
A mediated launch does not become a portable recent-items, durable-history, or reopen-enrollment plane.
Shell-local recents may exist.
They stay shell-owned and non-authoritative.

That is a beautiful rule for a terminal discovery layer.
A recent chapter, deck card, or palette hit may help the operator find something again.
It should not quietly count as:
- standing reopen permission,
- durable object authority,
- or proof that the old target is still the right one.

The import is:
**recents are hints, not grants.**

## 2) SlopOS result-preview discipline warns against ambient snippets and hover panes

The quarantined result-preview boundary says search, launcher, and smart-folder surfaces stay metadata-safe for quarantined objects.
Selection, hover, focus, and preview panes are not implicit open or review.
That warning transfers well to Schell.

A terminal discovery palette should not quietly become:
- a snippet renderer for sensitive content,
- a thumbnail/hover preview tunnel,
- a hidden OCR/summary lane,
- or an “I already previewed this a little” excuse for stronger action.

That does not mean discovery must stay austere.
It means Schell should separate:
- metadata-safe discovery,
- explicit inspect/open,
- attach-for-help,
- and stronger run/review steps.

## 3) SlopOS session-selection posture warns against palette choice becoming hidden target choice

OpenURI session-selection and disposable target-selection boundaries say requesters may ask for posture while concrete session or destination choice stays policy-owned and explicit.
That maps cleanly onto terminal discovery.

A palette result may say:
- chapter on peer X,
- launch kit expecting peer Y,
- recent remote seed,
- or restored cockpit object.

It should not silently choose:
- a remembered profile,
- a stale remote target,
- a concrete disposable domain,
- or some hidden ambient session identity.

The import is:
**finding a thing is not the same thing as selecting an exact live target.**

## 4) SlopOS learn mode says discovery suggestions stay observational

Capshell learn mode remains observational only.
It does not auto-edit, auto-approve, or auto-rerun.
That gives Schell another useful rule.

A deck card, mark, annotation, or palette hit may:
- suggest,
- stage,
- jump,
- or attach context for help,

but it should not auto-run, auto-reopen, or auto-promote itself into current reviewed basis.

## 5) SlopOS keeps descriptive sidecars weaker than live handles

Across summary, sidecar, and evidence posture, SlopOS keeps saying the same thing:
summary is not authority.
That should discipline Schell annotations and deck cards too.

A note may summarize:
- what this chapter was for,
- why it failed,
- what to try next,
- or which project it belongs to.

It should not prove that:
- the chapter is still live,
- the target is still current,
- the peer/ground still matches,
- or the operator has already approved doing it again.

## 6) What SlopOS pressures Schell to steal

The strongest import is not a giant command-center product.
It is a small posture cluster:
- one explicit **deck card** object for pinned working-set items,
- one exact **mark** family,
- one local **annotation** family,
- one **palette row** model with strong badges,
- one **metadata-safe preview** default,
- and one ladder separating **inspect / insert / review / strong action**.

## 7) What Schell should deliberately refuse

### Refuse preview-equals-open

Discovery should not smuggle in content rendering or object admission.

### Refuse recent-equals-reopen

A recent item may help find the object again.
It should not become a hidden durable handle.

### Refuse annotation-equals-truth

Notes are useful local sidecars, not shell-authored facts.

### Refuse palette-hit-equals-target-selection

Finding a result does not pick the exact live destination on the operator's behalf.

### Refuse giant omniscient discovery architecture first

One deck object, one mark family, one annotation family, one palette row model, and one preview refusal rule are enough to learn a lot.

## 8) Current consequence for Schell

The best next step looks compact:
1. one exact **deck card** for a pinned chapter or workflow seed,
2. one exact **mark** on a failure or review boundary,
3. one local **annotation** bound to an exact chapter/range,
4. one **palette row** showing kind/liveness/source/sensitivity badges,
5. one **metadata-safe preview refusal** for a sensitive or quarantined result,
6. and one transcript slice showing inspect vs insert vs strong-action downgrade.

That is enough to make Schell feel much better at discovery and staging while still keeping search-index, preview-engine, sync, result-ranking, and note-sharing treaties open.
