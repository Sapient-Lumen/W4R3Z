# SlopOS datacube evaluation, pass LXXXIX (2026-03-22)

This pass evaluates rendering, formatting, typed view adapters, and pretty-output posture against the current SlopOS archive.
The result is tight:
**SlopOS strongly rewards a shell that treats rendering as a local adapter layer over stronger typed/value/handle truth, not as a new authority plane.**

## 1) SlopOS already prefers typed subjects over pretty projection

The companion archive keeps pulling in the same direction:
- canonical bytes and digestable evidence over ambiguous display,
- typed payload descriptors over ambient clipboard or preview folklore,
- durable document handles over path-shaped convenience,
- and explicit intent envelopes over “the viewer guessed what I meant.”

For Schell this implies:
- the shell should preserve value/handle/subject truth separately from whatever render adapter is currently painting it,
- and rich rendering should remain visibly weaker than exact subject identity.

## 2) SlopOS transfer and document posture both punish display-driven overclaiming

RFC-0094 on typed transfer leases and RFC-0089 on document handles are especially helpful.
They both keep actual transfer/object authority explicit, bounded, and reviewable.
That is exactly the right import for Schell.

For Schell this implies:
- a rendered markdown card is not the document handle,
- a pretty diff is not the file authority,
- an inline image is not the export/share object,
- and hyperlink paint is not the same thing as exact target/open authority.

## 3) SlopOS ordering and evidence posture rewards render receipts, not render mythology

RFC-0119 and the broader evidence family keep saying that scope, order, and receipts matter when meaning is non-commutative or exportable.
That maps cleanly onto rich terminal rendering.
If a support bundle or replay needs to explain what someone saw, Schell should not rely on “whatever the terminal drew.”
It should preserve a subject basis plus a render receipt.

For Schell this implies:
- support export should carry subject refs / value basis plus render-ground metadata,
- replay should keep rich views historical,
- and render adapters should never become the only durable truth.

## 4) SlopOS plumb/intents posture also argues against implicit viewer magic

RFC-0117 keeps plumbing request-local, typed, and non-authoritative.
That is a strong clue for render actions too.
Opening a stronger viewer, exporting a richly rendered object, or asking for markdown/image/diff treatment should stay explicit workflow choices rather than ambient terminal side effects.

For Schell this implies:
- render is one action lane,
- open/export/share are stronger neighboring lanes,
- and “it looked nice here” should never silently widen into stronger object authority.

## 5) The outside ecosystem gives a companion-compatible answer

Current tools now prove a narrow pattern that matches SlopOS well:
- PowerShell proves formatting is display, not the object,
- Nushell proves structured values can render to strings or open viewer-like pagers,
- bat proves pretty paging should degrade cleanly for non-interactive pipes,
- delta proves hyperlink-rich diff output should stay contingent on terminal capability,
- xterm.js proves explicit and implicit links are different families,
- and kitty/iTerm2 prove graphics are useful but adapter-local.

SlopOS sharpens the import:
**Schell should steal render luxury, not render authority.**

## 6) What this pass now strongly suggests for Schell

The most companion-compatible moves are:
- **render-ground cards**,
- **subject cards**,
- **capability badges**,
- **fallback ladders**,
- **render receipts** for replay/export,
- and **stronger open/export/share rails** that stay separate from local rendering.

## 7) Decisions this pass still refuses to make too early

This pass still does **not** force:
- one final renderer registry,
- one final table/markdown/diff/image stack,
- one final hyperlink/image protocol mix,
- one final render cache/export format,
- or one final headless/mux downgrade story.

The answer stays smaller and stronger:
**let Schell become excellent at rendering and re-rendering while keeping values, handles, typed subjects, and stronger actions explicit and harder than the pretty layer.**
