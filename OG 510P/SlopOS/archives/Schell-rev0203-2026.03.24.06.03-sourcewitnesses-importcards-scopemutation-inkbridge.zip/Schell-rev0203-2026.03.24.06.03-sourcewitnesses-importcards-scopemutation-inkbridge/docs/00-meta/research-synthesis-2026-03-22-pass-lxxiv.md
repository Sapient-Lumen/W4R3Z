# Research synthesis, pass LXXIV (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should steal project command decks, detached queues, rerunnable command panes, launcher menus, and threshold notifications from current tools — but it should keep local job control, detached task identity, transient status cues, and restored command intent on an explicit honesty ladder so “still visible”, “still queued”, and “still done” never collapse into one vague background-work story.**

This seam matters because the modern shell+terminal world now offers at least four genuinely useful shapes of work:
- local shell job control,
- project command decks,
- detached queue/daemon style task execution,
- and pane/session resurrection.

They are all valuable.
They are also very easy to flatten together.
A custom shell+terminal becomes much more humane if it can tell the operator:
- what kind of work object this is,
- who currently owns its liveness,
- whether it can still accept input,
- whether a notification is only a cue or a durable result,
- and whether a restored pane is historical, rerunnable, or live again.

The no-regret move is not to reject these luxuries.
It is to separate them explicitly.

## 1) Classic shell backgrounding remains useful — and obviously insufficient

Current fish docs keep the old truth very clear: `bg` resumes a stopped job in the background, and a background job does **not** have access to the keyboard.
That is the oldest shell lesson here and it still matters.
`&`, `bg`, `fg`, and `jobs` are real and useful, but they are local TTY/process-group stories, not durable task management, not detached queue truth, and not completion proof.
Schell should keep that lesson explicit instead of pretending local job control can carry the whole modern task story.
See: https://fishshell.com/docs/current/cmds/bg.html and https://fishshell.com/docs/current/language.html

## 2) Pueue proves detached queues are wonderful because they are *not* bound to one terminal

Current Pueue docs say it is a command-line task management tool for sequential and parallel execution of long-running tasks, that it is not bound to any terminal, and that its queue keeps processing even without active SSH sessions.
The same docs also show why operators like it: groups with separate parallelism, persisted queue state, persisted logs, follow/wait/status commands, JSON status/log output, and callback hooks for desktop notifications.
This is absolutely stealable.
But it also highlights the honesty problem.
A detached queue task id, request key, or callback is not the same thing as a live pane, not the same thing as current success/failure truth, and not the same thing as a shell-owned foreground process.
Schell should steal detached queues as a separate witness family, not smuggle them in under `&` folklore.
See: https://github.com/Nukesor/pueue

## 3) mprocs proves project command decks are a different luxury again

Current mprocs docs say it runs multiple commands in parallel, shows each command’s output separately, and is meant for commands you run repeatedly such as compilers and test runners.
Its own FAQ contrasts this with tmux: tmux is more for longer-lived shells, while mprocs is for finite-lifetime processes that are often restarted together, and when mprocs exits the processes it owns exit too.
That distinction is gold.
Schell should absolutely steal the comfort of a project command deck, but it should keep project deck work visibly distinct from:
- detached queue work,
- durable background presence,
- long-lived shells,
- and promoted services.
See: https://github.com/pvolok/mprocs

## 4) Zellij proves command panes and background commands are great when their posture is explicit

Current Zellij docs are unusually instructive here.
Plugins can open command panes that let users control the command, re-run it, and see its exit status through the UI.
They can also open a hidden background command pane.
And the `run_command` event path includes arbitrary returned dictionary fields such as a `request_id` so result events can be correlated later.
That is a superb clue for Schell:
- keep exact command/pane identity,
- keep rerun as a named action,
- keep hidden/background command posture visible,
- and keep correlation ids weaker than live task ownership.
See: https://zellij.dev/documentation/plugin-api-commands.html

## 5) Zellij session resurrection keeps the most important honesty rule intact

Current Zellij session-resurrection docs say sessions are serialized, can restore layout and commands, and may also restore viewport and scrollback.
But the crucial rule is even better: resurrected commands do **not** run immediately and instead sit behind a “Press `ENTER` to run...” banner.
That is exactly the posture Schell should keep.
Restoration is a historical affordance until live truth is reacquired.
See: https://zellij.dev/documentation/session-resurrection.html

## 6) Notifications and launcher menus are useful — and weaker than durable truth

Current kitty docs show a `notify` command that can send desktop notifications from the shell, including over SSH, optionally wait for activation, and update/replace an existing notification by identifier.
Current WezTerm docs show a launcher menu that explicitly lists multiplexer domains and lets operators connect or spawn tabs/windows in those domains.
These are both worth stealing.
But they are cues and launch affordances, not durable work truth.
A notification id is not completion proof.
A launcher entry is not task identity.
A launcher-opened domain is not a claim that previous work is still valid.
Schell should therefore split:
- task identity,
- current live state,
- transient attention cue,
- and launch/attach affordance.
See: https://sw.kovidgoyal.net/kitty/kittens/notify/ and https://wezterm.org/config/launch.html

## 7) tmux alerts are a useful warning from the past

tmux has long supported bell/activity/silence monitoring and can mark windows with alert flags when output appears, bells ring, or silence intervals elapse.
That is a nice comfort feature.
It is also a cautionary tale.
Alert flags are fundamentally weak cues.
They are not durable results, not task identity, and not proof that current state is still what the operator assumes.
Schell should steal alertability and navigation, but keep it visibly weaker than receipts, live task state, or shell-owned witnesses.
See: https://github.com/tmux/tmux/wiki/Advanced-Use

## 8) The strongest super-awesome moves are clearer now

The highest-value moves worth stealing from this seam are:
1. **detached-work witnesses** that say `local_job` / `project_deck` / `detached_queue` / `pane_command` / `promoted_service` / `restored_history`,
2. **task shelves** that separate `request_key`, `live_state`, `cue_state`, and `closing_witness`,
3. **orphan posture badges** such as tracked / detached / owner-exited / shell-untracked / historical,
4. **threshold finish cues** that can update in place without pretending to be the durable result,
5. **bring-forward / inspect-log / attach / rerun / promote** ladders instead of one vague “resume” button,
6. **project command decks** for repeated finite-lifetime workflows,
7. **detached queue cards** with group/parallelism/log/follow posture,
8. **restoration banners** that stay historical until rerun or live reattach,
9. and **correlation ids that remain weaker than ownership truth**.

## 9) What Schell should absolutely refuse

Schell should refuse:
- calling every non-foreground thing a “job,”
- treating detached queue ids or request ids as live-state proof,
- letting desktop notifications or status glows become the durable completion record,
- flattening project command decks into service supervision,
- and letting restored panes or hidden background commands impersonate current live truth.

## 10) Decisions intentionally kept open

This pass does **not** freeze:
- one final task scheduler,
- one final detached queue/runtime backend,
- one final command-deck file format,
- one final status-center or inbox substrate,
- one final notification integration stack,
- or one final resurrection transport.

The no-regret move is smaller:
**give Schell detached-work witnesses, task shelves, orphan posture badges, threshold finish cues, explicit attach/rerun/promote ladders, and restored-state honesty while keeping queues, decks, notifications, and resurrection visibly weaker than durable shell truth until attested.**
