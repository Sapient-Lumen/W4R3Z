# Research synthesis, pass LXXIII (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should steal semantic history, command/output selection, richer keyboard input, resurrection guards, and accessibility-first interaction ideas from current terminals — but it should keep every upgrade on an explicit honesty ladder so clickable structure, injected input, and restored context never overclaim live shell truth.**

This seam matters because the modern terminal race is no longer only about speed or themes.
The best current products are winning by making terminal interaction more semantic:
- they know where prompts and commands begin,
- they can select command output as a unit,
- they can map filenames or locations to actions,
- they can preserve and restore context,
- and they are starting to take accessibility seriously.

That is wonderful.
But it also means a new shell+terminal can accidentally smuggle in hidden authority through:
- click-to-open guesses,
- richer keyboard/injection channels,
- shell-integrated selection and history,
- preview or semantic-history routing,
- and restored sessions that look current even when they are only historical.

The no-regret move is therefore not to reject these ideas.
It is to admit them on an explicit honesty ladder.

## 1) iTerm2 proves semantic history is magical because it joins text to location

The current iTerm2 docs say shell integration lets iTerm2 track command history, cwd, host, and more; its Semantic History and Command Selection docs say the terminal can use tracked cwd to open files and let the operator select a whole command or its output.
That is a brilliant interaction model because it lets raw terminal text become actionable without forcing a heavyweight IDE frame around it.
Schell should absolutely steal this.
But it should improve the honesty.
The operator should always be able to see whether a clickable object is:
- exact and shell-authenticated,
- derived from semantic history,
- guessed from visible text,
- or historical residue from an older session.
See: https://iterm2.com/documentation-shell-integration.html and https://iterm2.com/documentation-command-selection.html and https://iterm2.com/documentation-one-page.html

## 2) kitty and WezTerm prove command zones and richer input are worth it, but only with visible downgrade posture

Current WezTerm docs say shell integration can use `OSC 7`, `OSC 133`, and `OSC 1337` to mark cwd and prompt/input/output zones.
kitty's shell integration docs show prompt jumps, command-output paging, and prompt-local mouse editing.
kitty's keyboard-protocol docs say terminals and applications can opt in to richer keyboard semantics while staying backward compatible.
That is all highly stealable.
But current fish release notes are a warning too: fish disables the kitty keyboard protocol in some contexts and versions where it does not work correctly, and also adjusted how it emits semantic prompt data.
That means upgraded input is not a binary “supported or unsupported” story.
It is a capability-and-downgrade story.
Schell should therefore keep a visible input-capability witness that can say native / adapted / downgraded / disabled rather than pretending richer keys are always exact.
See: https://wezterm.org/shell-integration.html and https://sw.kovidgoyal.net/kitty/shell-integration/ and https://sw.kovidgoyal.net/kitty/keyboard-protocol/ and https://fishshell.com/docs/current/relnotes.html

## 3) Zellij proves resurrection should keep context without silently re-running work

The current Zellij docs say session resurrection can serialize layout, running commands, viewport, and optionally scrollback.
But they also say resurrected commands are not run immediately and instead sit behind a “Press ENTER to run...” banner to avoid uncomfortable accidents.
That is exactly the right instinct.
Restoration is valuable, but it should remain visibly historical until the operator reacquires live truth.
Schell should steal the banner, the caution, and the posture label — not just the convenience.
See: https://zellij.dev/documentation/session-resurrection.html

## 4) Accessibility can no longer be a late coat of paint

Warp's current accessibility docs say they have been improving VoiceOver support and rethinking terminal workflows for visually impaired users.
GitHub's accessibility write-up for the CLI says they are focusing on screen-reader users, high-contrast needs, and customizable color options.
These are not edge niceties.
They show that terminal interaction quality now includes:
- robust keyboard navigation,
- screen-reader-sensible chunking,
- high-contrast and customizable color posture,
- and a structure that can be narrated honestly.
Schell should steal the ambition, but it should ground it in shell-owned truth.
A narrated command chapter, an object card, or a semantic selection should never claim more certainty than the shell can attest.
See: https://docs.warp.dev/terminal/more-features/accessibility and https://github.blog/engineering/user-experience/building-a-more-accessible-github-cli/

## 5) The stealth risk is interaction channels that quietly cross from observation into injection

Once terminals support semantic selection, point-and-click cursor movement, prompt-local edits, richer key protocols, and assistive navigation, the boundary between observation and injection gets blurry.
That is the dangerous seam.
A great terminal should let the operator:
- hear or inspect the current command chapter,
- jump among commands or prompts,
- select one command's output as a unit,
- and move or edit the prompt precisely,
without letting those luxuries quietly become a hidden automation plane.
The lesson from the past is clear:
input strength must stay explicitly stronger than observation strength.

## 6) The strongest super-awesome moves are now clearer

The highest-value moves worth stealing now are:
1. **semantic-history witnesses** that badge exact / cwd-derived / text-guessed / historical posture,
2. **command-chapter narration rails** for screen readers and dense keyboard use,
3. **input-capability cards** that show native / adapted / downgraded / disabled posture for richer keyboard and prompt-editing features,
4. **safe resurrection banners** that keep restored commands historical until re-run or reattached,
5. **exact-reveal before open** when a click targets a filename, URL-like token, or command output object,
6. **high-contrast and customizable contrast posture** without making color the sole carrier of authority,
7. and **mode strength indicators** that distinguish inspect / navigate / inject / rerun / restore.

## 7) What Schell should absolutely refuse

Schell should refuse:
- click-to-open as unlabelled authority,
- semantic-history guesses masquerading as exact subject identity,
- richer key/input protocols being silently assumed correct in every host path,
- accessibility layers that depend on color or visual grouping alone,
- and restored sessions that look live before live authority is reacquired.

## 8) Decisions intentionally kept open

This pass does **not** freeze:
- one final semantic-history protocol,
- one final command-selection wire format,
- one final keyboard/input upgrade stack,
- one final screen-reader narration model,
- or one final resurrection storage format.

The no-regret move is smaller:
**make upgraded interaction explicit with semantic-history witnesses, command-chapter narration rails, input-capability cards, safe resurrection banners, and exact-reveal ladders while keeping every upgrade visibly weaker than live shell truth until attested.**
