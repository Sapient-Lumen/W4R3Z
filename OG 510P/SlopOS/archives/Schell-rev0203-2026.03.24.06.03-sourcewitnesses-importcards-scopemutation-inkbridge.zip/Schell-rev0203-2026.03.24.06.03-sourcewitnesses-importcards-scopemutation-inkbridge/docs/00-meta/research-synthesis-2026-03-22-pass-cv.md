# Research synthesis, pass CV (2026-03-22)

This pass keeps one fresh rule in focus:
**a shell+terminal gets much more trustworthy when external-editor roundtrips are treated as draft export + return-to-buffer events, not as hidden execution or callback folklore.**

The current ecosystem gives Schell unusually crisp guidance here.
Bash still documents `fc` as editing history entries in an editor and then reading, echoing, and executing the edited commands.
zsh's `edit-command-line` is the healthier pattern: it opens the entered-so-far command line in an external editor and returns to command-line editing without auto-executing.
fish's `edit_command_buffer` similarly opens the visual editor for the current command-line contents.
Nushell's line editor goes further by documenting `Ctrl+O` as opening the current commandline in the editor and updating the commandline with the results when the file is saved and the editor exits.

## 1) The historical lesson is cleaner than many shell lessons

A lot of shell design questions stay muddy for years.
This one is clearer.
The old convenience move — edit then execute — is simply too strong for a shell that claims exact review and explicit authorship.
The better modern move already exists in multiple shells:
**edit externally, then return to the live buffer, then decide whether to review or run.**

Schell should steal that rule directly.

## 2) External editors are nearby, but they are not the live prompt

The ecosystem keeps using environment variables or widget-specific style configuration to choose an editor.
That is convenient, but it should not mislead us about what is happening.
An external editor bridge introduces at least five distinct objects:
- the original live prompt buffer,
- the exported draft object,
- the editor process/session,
- the returned text or merge result,
- and the final accepted live buffer after return.

The docs imply this split even when products do not name it explicitly.
fish says the visual editor is controlled by `VISUAL` or `EDITOR`.
zsh's editor widget can be styled with an explicit editor command and arguments.
Nushell exposes a configurable `buffer_editor` setting and still treats the result as an update to the commandline, not as execution.

That is the right design clue.
Do not flatten all of this into “opened in editor.”

## 3) Bash `fc` is invaluable scar tissue

The best historical lesson in this seam is not that Bash is bad.
It is that Bash preserves a tempting shortcut Schell should not inherit as its safety floor.
`fc` edits and then executes.
That is convenient for experts.
It is also exactly the kind of move that turns editor roundtrip into hidden action spending.

So the right import is:
- keep edit-then-execute, if it ever exists, as a consciously stronger rail,
- but make the default external-edit story return to buffer only.

## 4) Compare-and-set belongs here as much as in review flows

External editing takes time and may cross process boundaries.
That means the original basis can drift while the draft is away.

Schell should therefore treat an editor return as a compact compare-and-set event, not as “whatever came back wins.”
If the basis still matches, great.
If not, the returned draft can become:
- an alternate draft,
- a compare card,
- a snippet mine,
- or a historical draft witness.

This is a much better fit for a shell+terminal that already cares about exact mutable basis.

## 5) The best current steals are concrete and safe

### a) External-editor widgets that return to the line
This is the clearest steal from zsh, fish, and Nushell.

### b) Editor provenance chips
Show whether the bridge used `VISUAL`, `EDITOR`, an explicit buffer-editor setting, or a widget-specific editor command.
This is not authority, but it is useful context.

### c) Return diff cards
A brilliant shell+terminal should not just say “editor closed.”
It should show what changed and whether parse/argv shape changed.

### d) Readonly export versus writable roundtrip
A rich terminal should let the operator open command text, runbooks, or exact output in an editor for inspection without implying that edits will merge back.

### e) Alternate-draft shelving
If the basis drifted or merge was refused, keep the returned draft as a visible, explicit alternate instead of overwriting or discarding it.

## 6) This seam is smaller than a full editor architecture

None of this requires Schell to freeze:
- one final IDE integration story,
- one final document model,
- one final temp-file strategy,
- or one final runbook bridge.

It only requires one small rule:
**treat external-editor roundtrip as a witnessed draft bridge, then keep it weaker than reviewed execution.**

## 7) Compact conclusion

One of the smartest no-regret moves available right now is:
**make editor bridges first-class and delightful, but keep exported draft, editor session, return diff, accepted buffer text, and reviewed execution separately named.**

That lets Schell steal one of the best humane shell ideas in circulation without inheriting Bash-era autorun folklore or prematurely choosing the whole editor/IDE architecture.
