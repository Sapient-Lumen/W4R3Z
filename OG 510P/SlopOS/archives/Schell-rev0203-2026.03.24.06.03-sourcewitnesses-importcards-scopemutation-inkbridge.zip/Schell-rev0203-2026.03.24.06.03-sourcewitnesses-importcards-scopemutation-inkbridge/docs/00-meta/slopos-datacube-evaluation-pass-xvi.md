# SlopOS datacube evaluation, pass XVI

**The shell+terminal should route visible actions through explicit intent packets, not through ambient click-to-open or click-to-run folklore.**

This pass adds a new caution and a new opportunity.
The caution is that once Schell has trusted command blocks, selection packets, output capsules, pane trees, and ingress packets, almost every visible thing starts looking temptingly actionable.
The opportunity is that SlopOS already has a better answer: explicit plumb messages, exact open/reveal boundaries, request-local completion, and wallet-aware review surfaces.

## 1) SlopOS already has the right mental model for shell-visible action routing

RFC-0117 does not treat “open,” “share,” “print,” and similar moves as ambient helper conventions.
It treats them as **plumb-first intents** routed through an explicit message envelope.
That matters for Schell because the terminal will increasingly be full of objects that look like they deserve actions:
- paths,
- URIs,
- receipts,
- output capsules,
- workflows,
- imports,
- and review cards.

The right lesson is that these should not fall straight from visibility into ambient host behavior.
They should become explicit **intent packets**.

## 2) SlopOS also keeps route completion request-local

The D-PLUMB posture is especially important.
It keeps completion on the request-local path and refuses to turn the router into a second durable mailbox, callback registry, or background rendezvous substrate.

For Schell, that is a strong hint that smart terminal actions should preserve:
- one exact action request,
- one exact subject,
- one route/explain witness,
- one local completion or denial path,
- and one durable receipt if the action actually crossed an authority seam.

That is a much better story than “the terminal opened something somewhere and probably it worked.”

## 3) Exact open and exact reveal are different actions and should stay different

SlopOS keeps saying the same important thing in several places:
- generic OpenURI is launch-only and intentionally narrow,
- session/profile choice is a different seam,
- handler selection is a different seam,
- and exact show-item / reveal-select should not silently degrade into parent-directory browse.

That is a major lesson for Schell.
The terminal should absolutely support delightful visible-object actions.
But it should not flatten these into one generic “open” folklore button.

A path-like object may support several different actions:
- inspect,
- insert into active input,
- reveal exact item,
- mediated open,
- derive workflow seed,
- attach to proposal or receipt,
- or compare/export.

Those should remain distinct intent packets, not one flattering nearby behavior.

## 4) Wallet-aware explainability is a better bridge than ambient helper magic

SlopOS CLI plumbing guidance says explain/dry-run is normal and that wallet digests can ride along as descriptive review material.
That maps beautifully to Schell.

A terminal action should be able to say:
- what the shell believes the selected object is,
- what route family would handle it,
- whether mediation is required,
- what authority diff is expected,
- and whether the current wallet/basis makes the action stale, downgraded, or deny-by-default.

That is a path to power without smuggling in hidden helper sockets or desktop-default folklore.

## 5) DelayBasin adds the missing process lesson

DelayBasin is useful here because it keeps asking for explicit witnesses rather than flattering summaries.
For Schell that sharpens the routing discipline:
- the action packet should say what exact object was chosen,
- the route witness should say what exact route class matched,
- the hold card should say what was missing,
- and the denial should keep the nearby rejected action visible instead of silently doing something else.

That keeps smart actions both humane and auditable.

## 6) The promising new Schell pair is intent packet plus route witness

A good first import is a pair:

### Intent packet
A compact shell-owned packet that names:
- the requested action kind,
- the exact subject ref,
- provenance/capture grade,
- active-lane context,
- wallet/basis hints when available,
- and whether the action is inspect-only, direct-local, review-required, or portal-mediated.

### Route witness
A compact witness that names:
- the matched action family,
- whether the route is local, mediated, proposal-only, or denied,
- the exactness class (`exact-open`, `exact-reveal`, `insert-only`, `inspect-only`, `derived-workflow`),
- and what hold/denial rule applied if the action could not proceed strongly.

This is a better answer than one giant click menu and a better answer than pretending the terminal should stay dumb forever.

## 7) Great product moves become possible here too

This is not only a safety pass.
It is also a product pass.
Once intent packets and route witnesses exist, Schell can support genuinely excellent moves without lying:
- click a selected path and choose **insert** instead of **open**,
- open a URI through a mediated launch card rather than a silent browser jump,
- reveal an exact artifact without silently degrading to a nearby directory,
- derive a workflow seed from selected output without treating the output as executable truth,
- attach an exact command region to a debugging conversation or receipt,
- and show a tiny explain card before expensive or widening actions.

That is one of the clearest paths to “super awesome” that still respects SlopOS exactness.

## 8) What stays open

This pass still refuses to decide:
- final intent-packet schema,
- final router implementation shape,
- whether local-only route classes and mediated route classes share one envelope on disk,
- final hyperlink/OSC8 policy,
- final palette or command-search UI,
- and any generic callback or durable inbox substrate.

That is deliberate.
This is a no-regret routing posture pass, not a giant workflow-router freeze.
