# Research synthesis — 2026-03-23 — pass CLXXXVI

This pass sharpens one smaller lesson from current terminal docs:
**close is not one action, and the best shell-aware products already admit that with prompt-safe close, undo-close grace, and buried continuity.**

## 1) Current terminal docs already split “close” into multiple classes

Ghostty and kitty both expose prompt-aware close behavior rather than treating every visible terminal the same.
They already distinguish a terminal resting at a prompt from one that may still hold live work.
That is enough to show that close safety is a classifier problem, not a single UI verb.

## 2) The ecosystem is teaching two extra classes Schell should steal

The most useful additions come from iTerm2:
- **undo-close grace**, where a recently closed session can be revived for a bounded interval;
- **buried continuity**, where a session keeps running while disappearing from the visible window layout.

Those two ideas are powerful because they let the terminal admit that visibility and continuity are not the same thing.

## 3) The hidden tax is accidental loss of draft or continuity

Prompt-aware close alone does not solve everything.
A room can still have:
- unsent draft input,
- multiline continuation state,
- shell-owned background or sideband continuity,
- recently ended but still revivable session state,
- or only historical transcript residue.

That means a helpful close model needs one more question:
**what exact continuity class survives after this act?**

## 4) The best abstraction is small

Schell does not need one giant lifecycle constitution yet.
A tiny ladder is enough:
- **safe prompt close**
- **abandon draft**
- **bury live continuity**
- **destructive close**
- **undo-close revive**
- **historical restore only**

That vocabulary already explains most of the real operator surprises around terminal closing.

## 5) Another quiet lesson: prompt-aware safety should still confess its evidence

Ghostty and kitty tie safety to shell-aware prompt posture.
That is useful, but it also suggests a humility rule:
when close is treated as safe because the lane appears prompt-idle, Schell should be able to inspect and explain that evidence rather than leaving safety as terminal-brand folklore.

## 6) The no-regret Schell move

Schell should add one dedicated surface for:
- abandon receipts,
- buried-session continuity cards,
- undo-close grace with expiry,
- prompt-aware close predicates,
- and visible continuity classes after every close-like act.

That would make the shell+terminal feel safer and more modern without deciding one final persistence backend, mux treaty, shell lifecycle model, or supervisor architecture.

## 7) Compact conclusion

The ecosystem already paid for the lesson:
prompt-safe close, undo-close, and buried sessions all exist because close was never one thing.

So the next low-regret Schell seam is **abandon receipts, buried sessions, and prompt-aware close humility** so the operator always knows whether they closed safely, discarded draft, buried live work, or crossed into destructive loss.
