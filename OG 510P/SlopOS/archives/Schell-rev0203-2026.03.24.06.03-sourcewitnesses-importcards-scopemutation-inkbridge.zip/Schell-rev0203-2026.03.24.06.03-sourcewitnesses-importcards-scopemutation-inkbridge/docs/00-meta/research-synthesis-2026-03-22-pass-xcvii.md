# Research synthesis, pass XCVII (2026-03-22)

This pass asks one narrower question:
**what should Schell learn from the long history of shell completion systems without letting completion logic become a hidden parser, hidden prompt-time code path, or hidden execution lane?**

The answer is clearer than it first appears.
**The best move is not “invent the smartest tab completion.” The best move is to treat completion as a witnessed candidate-generation surface with explicit source, cost, fallback, insertion, and downgrade posture.**

## 1) The ecosystem keeps proving that completion is both delightful and dangerous

fish, bash, zsh, PowerShell, Nushell, kitty, and Warp all demonstrate that completion is one of the highest-leverage luxuries in shell design.
It makes discovery faster, narrows typo repair, fills parameters, reduces manual quoting work, and can make command execution feel dramatically more humane.

But they also keep proving the darker lesson: completion is often not a static lookup table.
It is frequently shell code, command spawning, filesystem probing, bridge logic, caching, and fallback policy hidden behind the tab key.

That combination is exactly why Schell should steal completion luxury carefully instead of casually.

## 2) fish teaches two excellent lessons at once: rich descriptions are worth stealing, and completion conditions are real code

fish's completion docs are unusually revealing.
They show how completions can carry descriptions, sort hints, file/path posture, and option-level conditions.
They also explicitly say the `--condition` script is executed and that command substitution can be used to produce dynamic candidates.

That means fish completion is not “just suggestions.”
It is a rich candidate engine that can run logic to decide what appears.
The good import for Schell is therefore not just “show pretty menus.”
It is: separate value from description, and treat generator posture as part of the truth story.

## 3) Bash preserves the older warning: programmable completion can run both shell functions and external commands

The Bash manual is especially valuable because it describes the programmable-completion pipeline step by step.
Strings used for candidate generation can undergo expansion, completion functions can inspect the command line through `COMP_*` state, shell functions can populate `COMPREPLY`, and external commands can also be invoked to print completions.
Fallback to default bash or Readline completion may then occur depending on the compspec options.

That is more than a convenience feature.
It is a small programmable subsystem living on the prompt path.
Schell should learn the right historical lesson: completion generation, fallback policy, and inserted bytes must be kept separate.

## 4) zsh sharpens the performance lesson: completion can be expensive enough to need cache policy and explicit “do not call the command” defaults

The zsh completion system is rich enough to need its own cache layer, cache policy, and a `call-command` style because running the target command directly may be slow or may even trigger actions such as makefile execution.
The docs explicitly note that `call-command` defaults to false for commands where invoking them to generate matches can be problematic.

That is a brilliant clue for Schell.
The design-phase-safe move is not “make all completions live.”
It is: carry a cost posture and freshness posture so cached, static, dynamic, and dangerous candidate paths do not collapse into one tab key mythology.

## 5) PowerShell and Nushell prove that typed completion is worth stealing

PowerShell's argument completion docs show that completions can be parameter-aware and can return `CompletionResult` objects at runtime.
Nushell goes even further in one respect: its custom completion mechanism binds a completer to an argument shape, and that works for both native custom commands and declared `extern` commands.

That suggests a valuable Schell import: completion can be typed earlier than the final shell language freeze.
Schell can explore value shapes, slot fills, and known-extern candidate sets without needing to lock a universal object pipeline or a final parser.

## 6) Nushell's bridge story is equally important: foreign completers are valuable precisely because they remain explicit bridges

The Nushell cookbook makes the bridge lesson wonderfully concrete.
It shows a fish-based external completer, explains the tab-separated value+description format, and then openly discusses quoting translation problems because fish uses POSIX escapes that Nushell does not parse the same way.
It even describes a multiple-completer fallback that chooses one completer for some commands and another as the default.

That is exactly the kind of design evidence Schell needs.
Borrowed completions are worth stealing, but they should stay visibly bridged and visibly translated.

## 7) kitty and Warp point to luxury above the floor

kitty's shell integration explicitly treats completion as one separable feature among several integration features: it can be disabled independently.
Warp's workflows show a higher-level luxury that is still completion-shaped: parameterized commands with text or enum arguments, including dynamic enums sourced from a shell command, where the result is pasted into an editable input and remains modifiable before run.

This suggests a healthy Schell split:
- the **floor** is completion witness posture,
- the **luxury** is richer descriptions, slot fills, workflow enums, searchable palettes, and bridge imports.

## 8) The compact import for Schell

This pass argues for a smaller ratchet than a final completion subsystem manifesto.
Schell should begin with:
- one **completion witness** that records source family, generator family, side-effect posture, freshness posture, insertion mode, and fallback posture,
- one visible split between candidate label/description and exact inserted bytes or slot value,
- one rule that acceptance inserts but does not execute,
- one visible distinction between native, bridged, cached, and dynamic candidate sets,
- and one specimen set showing file fallback, typed slot fills, and bridged translation honesty.

## 9) Compact conclusion

The strongest design-phase answer from the current ecosystem is:
**completion is too valuable to leave fuzzy, but too programmable to treat as innocent.**

Schell should therefore model completion as a witnessed candidate-generation seam rather than as ambient parser magic.
That move lets it steal:
- rich descriptions,
- typed argument fills,
- slot-aware workflow enums,
- bridged completers,
- caching,
- and better fallback behavior,

while still deferring:
- the final parser,
- the final editor stack,
- the final completion ABI,
- the final workflow substrate,
- and the final bridge/caching topology.
