# Research synthesis, pass XVI (2026-03-21)

This pass focuses on another load-bearing seam:
**terminals keep getting smarter about visible objects and object actions, but Schell still needs a better answer than letting clicks, hints, or workflows collapse into ambient open/run behavior.**

## 1) Current terminal ecosystems increasingly turn visible objects into action sources

xterm.js documents two link paths: explicit OSC 8 hyperlinks and implicit pattern-matched links via its web-links addon.
That is a very useful contrast because it shows the difference between a host-emitted exact link and a regex-derived guess.
See: https://xtermjs.org/docs/guides/link-handling/

kitty pushes visible-object actions further with hints: you can select paths, insert the selected path into the terminal, open the selected path, or even open a selected file at a selected line.
See: https://sw.kovidgoyal.net/kitty/kittens/hints/ and https://sw.kovidgoyal.net/kitty/actions/

iTerm2’s Semantic History and Smart Selection likewise make filenames, URLs, and structured snippets feel richly actionable.
See: https://iterm2.com/documentation-one-page.html

The product lesson is obvious: visible text and visible semantic regions increasingly want action paths.
The design lesson is harder: these action paths should stay explicit about what is exact and what is inferred.

## 2) Shell integration keeps making exact command/object regions more usable

WezTerm’s shell integration uses OSC 7 and OSC 133 so the terminal can track working directory and semantic prompt/input/output zones.
It also exposes `SemanticZone` selection so a whole command/output region can be selected as a semantic unit.
See: https://wezterm.org/shell-integration.html and https://wezterm.org/config/lua/keyassignment/SelectTextAtMouseCursor.html

Windows Terminal’s shell integration similarly supports marks, jumping between commands, selecting a whole command output region, and opening a new tab in the same working directory.
See: https://learn.microsoft.com/en-us/windows/terminal/tutorials/shell-integration

Ghostty’s recent OSC 133 prompt-click support sharpens the same pattern: the nicest click/edit affordances are the ones constrained to shell-marked live input.
See: https://ghostty.org/docs/install/release-notes/1-3-0

This strengthens the case that Schell should route actions from shell-marked regions through explicit packet/witness seams rather than rely on text scraping or accidental cursor context.

## 3) Workflow systems are already converging on “paste into active input first” for reusable commands

Warp’s workflow docs say workflows are searchable and parameterized, and the command palette pastes the chosen workflow into the active terminal input so the operator can review and adjust it before execution.
See: https://docs.warp.dev/knowledge-and-collaboration/warp-drive/workflows and https://docs.warp.dev/terminal/entry/yaml-workflows

That is a very good no-regret clue for Schell.
It suggests that many smart actions should terminate at **active-input insertion**, **review**, or **proposal generation** rather than at silent execution.

## 4) Some current systems already show the value of attaching exact command regions as first-class objects

Recent VS Code updates show this trend clearly.
Commands tracked by shell integration can be attached to chat as context, sharing command line, captured output, and exit code.
More recently, terminal command blocks in agent flows became collapsible summary sections instead of one long undifferentiated transcript.
See: https://code.visualstudio.com/updates/v1_106 and https://code.visualstudio.com/updates/v1_110

This is exactly the kind of bridge Schell should learn from.
A visible terminal object can be richly reusable without becoming ambient execution authority.

## 5) Plan 9 still teaches the cleanest general lesson

Plan 9 plumbing remains one of the best old examples here.
Programs send messages to the plumber and rules decide where they go; users can also plumb selected text interactively.
See: https://9p.io/sys/doc/plumb.html and https://9p.io/wiki/plan9/Using_plumbing/index.html

What matters for Schell is not copying Plan 9 whole.
What matters is the idea that a visible selection can become a typed routed message rather than a pasteboard accident or a hidden helper invocation.

## 6) A no-regret Schell cluster is visible now

A decision-light first cluster looks like this:
- one shell-owned **intent packet** for visible-object actions,
- one compact **route witness** that says what kind of route matched,
- one exactness ladder (`inspect-only`, `insert-only`, `exact-open`, `exact-reveal`, `derived-workflow`, `proposal-only`),
- one provenance ladder that keeps explicit/marked/inferred/restored objects distinct,
- and one action policy that prefers insert/review/proposal over silent execute.

## 7) The best steals are the humane ones

The best ideas to steal now are:
- semantic-region actions over shell-marked command/output zones,
- insert-selected-path and open-selected-path as different actions,
- exact line/file opens when the visible object actually supports it,
- workflow search that lands in active input rather than in auto-run,
- attach-this-command-region as a first-class object,
- and tiny explain cards that say what route/action class the terminal thinks it is about to invoke.

## 8) What to refuse

The moves to refuse are just as important:
- do not let regex-detected or inferred links inherit the same strength as shell-attested objects,
- do not collapse `open`, `reveal`, `insert`, `execute`, and `attach` into one “smart click” folklore behavior,
- do not let terminal-local action handlers become a hidden authority plane,
- do not introduce a generic callback/inbox system before there is real proof pressure,
- and do not let desktop-default helper behavior silently define Schell’s action semantics.
