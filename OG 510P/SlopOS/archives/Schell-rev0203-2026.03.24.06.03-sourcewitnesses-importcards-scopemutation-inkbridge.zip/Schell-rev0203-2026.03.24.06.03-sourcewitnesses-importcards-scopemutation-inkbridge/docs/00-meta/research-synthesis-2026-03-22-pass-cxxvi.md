# Research synthesis, pass CXXVI (2026-03-22)

This pass keeps one narrower lesson explicit:
**terminal identity should be modeled as a ladder of claims and proofs rather than as one flattering brand/version fact.**

The current ecosystem converges on that lesson from several directions.
xterm can answer Primary and Secondary Device Attributes, report name and version with XTVERSION, and answer XTGETTCAP termcap/terminfo queries.
kitty's `query_terminal` uses XTGETTCAP for name, version, and option queries and warns callers not to perform other terminal I/O until the helper exits.
Ghostty deliberately chose `xterm-ghostty` because too many applications string-search for `xterm`, and it ships SSH-termInfo and SSH-env fallbacks because a preferred native terminal identity does not propagate cleanly everywhere.
WezTerm defaults `TERM` to `xterm-256color` and recommends opting into a richer `wezterm` terminfo only when you install it; its FAQ warns that changing `TERM` can change key byte sequences and disable keys.
tmux adds relay-local policy on top of this with `terminal-features`, `terminal-overrides`, and separately gated passthrough.
iTerm2 is also candid that its proprietary escapes may not work properly in tmux or screen and can have unknown effects on other terminals.

Taken together, the design-phase lesson for Schell is straightforward:

## 1) Identity claims are plural

At minimum, Schell should keep these apart:
- declared `TERM` / terminfo family,
- terminal-specific environment hints,
- query replies,
- relay and mux posture,
- observed specimen behavior.

## 2) Names are weaker than capability proofs

`xterm-ghostty`, `xterm-256color`, `wezterm`, `xterm-kitty`, and version replies are useful hints.
But they should not be the whole unlock basis for rich terminal luxury.
A term name may exist for compatibility politics, not for exact capability truth.

## 3) Relay and fallback belong in the model

A remote host without native terminfo, a tmux session with feature overrides, and a direct local session are different footing.
Schell should say which one the operator is standing on.

## 4) Queries are evidence, not identity law

Query replies help, but they are still replies flowing over the terminal path.
They should therefore stay visibly weaker than shell-owned observed specimens when the UI wants to unlock stronger actions.

## 5) Compact answer

Schell does **not** need one canonical brand/version detector next.
It needs one bounded move:
- a terminal identity card,
- a claim ladder,
- visible relay/fallback posture,
- and a rule that observed specimen behavior outranks terminal folklore.
