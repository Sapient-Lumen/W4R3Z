# Research synthesis, pass CIX (2026-03-22)

This pass keeps one increasingly important lesson explicit:
**typed keystrokes, bracketed paste, multiline command-send, and clipboard query are neighboring powers, but they do not mean the same thing and should stop sharing one flattering “input” story.**

Current official docs make this seam surprisingly clear.
GNU Readline says `enable-bracketed-paste` inserts pasted text as a single string of characters instead of treating each character as if it had been read from the keyboard, specifically to avoid executing editing commands bound to key sequences appearing in the pasted text.
fish says it enables bracketed paste so it can tell paste from manually entered text, and goes further by automatically escaping pasted single quotes and backslashes inside single quotes.
zsh's `bracketed-paste-magic` is equally instructive because it exposes `paste-finish` hooks and a built-in `quote-paste` helper, which proves that target-aware paste transforms are a real shell surface rather than mere UI garnish.

The terminal side is just as informative.
xterm's long-running bracketed paste support exists specifically so paste can be distinguished from normal keyboard input, and xterm's own man page still carries `allowPasteControls` and `disallowedPasteControls`, which is a reminder that pasted control characters remain a real safety and UX seam.
VS Code's current terminal docs say multiline paste warnings are shown only when the shell does not support bracketed paste mode, and VS Code's 1.70 notes say multiline commands sent back into the terminal use bracketed paste mode so supporting shells add them to one prompt instead of replaying them as separate commands.
That is one of the cleanest modern proof points that “selected text sent into the prompt” should not be conflated with typed input.

The clipboard side draws an even sharper line.
kitty's config docs say programs may write the clipboard by default but clipboard reads are ask-gated by default, and the docs warn that disabling read confirmation is a security risk because even programs running on a remote server via SSH could read the clipboard.
WezTerm's escape-sequence docs then make a different but equally valuable choice explicit: OSC 52 clipboard queries are ignored, while setting or clearing the clipboard is still supported.
Those two stances differ in implementation, but they agree on the important design truth: **clipboard query is a stronger power than user-triggered paste or clipboard write.**

## 1) Bracketed paste is a meaningful authorship boundary

Readline, fish, zsh, xterm, and VS Code all point to the same first lesson.
Bracketed paste is not just a compatibility detail.
It is a compact authorship witness that says:
- this did not arrive as ordinary keystrokes,
- this was delivered as one bounded paste event,
- and the shell/editor may legitimately apply paste-specific handling.

Schell should therefore keep typed text, pasted text, and UI/tool-originated send-as-paste as separately named ingress families.
That keeps selected-text send, multiline history replay, and literal clipboard paste from quietly borrowing each other's meaning.

## 2) Multiline insert should be granted per target posture

VS Code's warning behavior is a good modern clue here.
When the shell does not support bracketed paste, multiline paste is risky enough that the terminal warns.
When the shell does support bracketed paste, multiline text can be delivered as one edit.
fish and zsh show that target-aware transforms can then be layered on top.

The no-regret design move is to treat multiline delivery as a **grant**, not a gamble.
At minimum, Schell should keep variants like:
- literal one-edit insert,
- quoted insert,
- scratch-stage,
- slow-paste,
- hold-for-review,
- deny.

That is a much better surface than pretending that any multi-line text can safely replay into any live target.

## 3) Clipboard query should have its own gate

kitty and WezTerm are the clearest current evidence here.
A paste event is a user-triggered delivery into one current target.
A clipboard query is ambient data access.
A system that flattens those into one permission or one log message is simply less honest than the current ecosystem already allows.

So Schell should keep a dedicated clipboard-query gate with outcomes like deny, ask once, allow once, allow under lease, or metadata-only.
That is the right place to keep authority small without turning off clipboard comfort.

## 4) The best steals are reveal-first, not magic-first

There are several wonderful steals here that do not force early architecture decisions:
- a visible `pasted as one edit` chip,
- a `multiline held for review` card when bracketed paste is unavailable or the target is sensitive,
- target-aware quote/literal/scratch variants inspired by fish and zsh,
- explicit UI-sent / bracketed authorship for “run recent command” style replay,
- and clipboard-query confession when a terminal or program tried to read ambient clipboard state.

The common pattern is simple:
**keep paste luxury, but make it legible.**

## 5) Compact conclusion

One of the smartest no-regret moves available right now is:
**make bracketed paste posture, multiline grants, target-aware paste transforms, and clipboard-query gates first-class witnesses before Schell lets typed input, pasted input, selected-text send, or ambient clipboard reads masquerade as one generic input story.**

That lets Schell steal excellent modern paste comfort without prematurely deciding the final clipboard backend, paste-history engine, remote bridge story, or privileged-paste approval UI.
