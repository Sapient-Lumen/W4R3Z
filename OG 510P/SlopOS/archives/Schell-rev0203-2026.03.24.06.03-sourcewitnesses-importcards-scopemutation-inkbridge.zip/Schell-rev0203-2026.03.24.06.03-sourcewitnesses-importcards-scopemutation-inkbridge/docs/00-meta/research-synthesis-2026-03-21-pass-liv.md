# Research synthesis, pass LIV (2026-03-21)

This pass keeps one new design rule in focus:
**Schell should steal chooser luxury — fuzzy recall, ranked candidates, inline previews, and quick-pick style filtering — but only if ranking stays inspectable, previews stay weaker than action, and acceptance stays visibly separate from `cd`, `open`, or `run`.**

The outside pressure is especially useful here because it shows both the delight and the foot-guns.
Modern terminal tools are full of chooser surfaces:
- fuzzy finders,
- interactive history browsers,
- frecency-driven directory jumpers,
- and quick-pick menus.

Those are absolutely worth stealing.
But they also create three predictable failure modes:
- hidden ranking becomes hidden policy,
- previews become disguised side effects,
- and “accepting a candidate” quietly becomes execution.

## 1) VS Code quick picks prove that chooser UX can stay compact and structured

VS Code's Quick Pick guidance is a strong generic baseline.
A chooser can:
- filter a list,
- show descriptions and brief detail,
- support multi-step flows,
- and still remain a lightweight selection surface rather than a giant wizard.

That is a very good clue for Schell.
The steal is not “make the terminal into a command palette.”
The steal is the **interaction envelope**:
ranked choices, bounded extra context, and explicit multi-step flows only when they stay short and comprehensible.
See: https://code.visualstudio.com/api/ux-guidelines/quick-picks

## 2) fzf proves how much delight one chooser can unlock — and exactly where danger enters

fzf remains the clearest terminal-native example of chooser luxury.
It can power interactive filtering, reload results on query changes, and show a preview window.
That is very close to what Schell will want.

But the docs also surface the danger plainly.
The preview command is executed through `$SHELL -c COMMAND`.
That means preview is not a harmless rendering trick.
It is a command-execution lane.
The README even warns against blindly putting `--preview` into `FZF_DEFAULT_OPTS` because many candidate lists are not file lists and the preview command can become nonsensical or unsafe.

That is the exact lesson Schell should import:
**preview is not free.**
Preview needs its own witness, own posture, and own downgrade path.
See: https://github.com/junegunn/fzf/blob/master/README.md

## 3) Atuin proves that ranked recall becomes much better when it carries context

Atuin is useful because it is not just a fuzzy list of old commands.
Its search can filter by cwd, exit code, and time bounds, and its interactive UI exposes history as a queryable surface with more context than a plain reverse-history walk.
The project also records exit code, cwd, hostname, session, and duration, and distinguishes between executing the selected command with Enter versus editing it with Tab.

That distinction matters a lot.
The terminal can absolutely remember more than “the last string that matched.”
But it should also keep **edit** and **execute** visibly distinct.
That is one of the cleanest no-regret imports available right now.
See: https://docs.atuin.sh/cli/reference/search/ and https://github.com/atuinsh/atuin

## 4) zoxide proves that ranking can feel magical — and why that magic needs reveal

zoxide is attractive because it turns repetitive path navigation into a short-intent chooser.
It ranks results with a frecency model and supports both immediate jumps and an interactive `zi` surface.
It also exposes query forms that reveal the candidate path, list the matches, and even show scores.

That is the part Schell should steal.
If ranking exists, the operator should be able to ask:
- what candidate would win,
- what else matched,
- and why one match ranked above another.

The part to avoid is letting learned ranking silently replace explicit cwd review.
The current zoxide materials also highlight how easy it is to replace `cd` entirely.
That is precisely the sort of ambient shortcut Schell should hesitate to normalize too early.
See: https://zoxide.org/blog/zoxide-commands/ and https://zoxide.org/blog/mastering-terminal-navigation-zoxide-guide/

## 5) The chooser lesson is narrower than “fuzzy is good”

The real import is not just fuzzy matching.
The deeper lesson is that a great chooser usually has four parts:
1. a candidate source,
2. a ranking story,
3. a context/detail view,
4. and an explicit accept action.

In old terminal culture, those parts are often jammed together.
The list appears, the preview happens, Enter fires, and the operator is expected to know which lane they just crossed.
Schell can do better by naming those parts directly.

## 6) Preview humility should become first-class terminal law

A preview may be:
- metadata-only detail,
- an inert local render,
- a helper-generated summary,
- or a command-executed preview.

Those are not equivalent.
They should not share the same badge, timing, or trust story.
A metadata row in a chooser is cheap and weak.
A preview produced by a subprocess or helper query is stronger.
A preview that dereferences a remote resource or launches a viewer is stronger still.

So the best import is a hard rule:
**chooser previews must surface what kind of work produced them and stay weaker than acceptance.**

## 7) Ranked recall should stay weaker than fresh review

History and recency systems love to feel clairvoyant.
That is useful until they become hidden execution policy.
Schell should absolutely support ranked recent-command recall, likely-successful recall, and directory-local recall.
But those should still arrive as:
- insert into active input,
- reveal exact chapter,
- or explicit rerun-on-current-basis review.

A history match should not quietly inherit “it worked last time, so just do it again” authority.

## 8) A chooser witness is now easy to name

A useful first witness shape might include:
- source family (history / chapters / workflow seeds / directories / services / files / object cards),
- ranking posture (static order / recency / frecency / explicit query score / none),
- candidate count and truncation posture,
- preview kind (none / metadata / inert render / helper summary / subprocess preview / remote fetch),
- accept lanes (insert / reveal / open / cd / rerun / safe-open),
- and whether acceptance is direct or requires another review step.

If Schell cannot say those things, then chooser luxury is arriving too early.

## 9) A compact first proving slice

A small proof could show:
- one history chooser filtered by cwd and success/failure,
- one directory chooser with ranked candidates and visible score reasons,
- one preview toggle that can switch between metadata-only and richer preview,
- one acceptance split between insert, reveal, and do-the-thing,
- and one refused case where a risky preview is downgraded to metadata.

That already feels dramatically more custom than bash without forcing a single ranking engine, preview protocol, sync backend, or palette framework.

## 10) Decisions intentionally kept open

This pass does **not** freeze:
- one universal fuzzy algorithm,
- one mandatory chooser UI toolkit,
- one history sync architecture,
- one preview execution protocol,
- one directory-ranking model,
- or one global command-palette ontology.

The no-regret move is smaller:
**steal chooser luxury, keep ranking revealable, keep previews honest, and keep accept weaker than automatic execution.**
