# Research synthesis, pass XXIX (2026-03-21)

This pass keeps another design rule in view:
**the custom shell+terminal should steal shell-known local luxuries aggressively, but only when the luxury stays visibly weaker than portable shell truth.**

The outside landscape is surprisingly coherent here.
The best current systems do not win by hiding more execution.
They win by making prompt regions, command chapters, history recall, typed suggestions, and session recovery easier to see and manipulate.
That is a strong clue for Schell.

## 1) Shell-known command/prompt boundaries are now baseline terminal leverage

VS Code's terminal shell integration exposes command decorations, run-recent-command history, current working directory reporting, and command execution events.
Ghostty 1.3 says OSC 133 semantic prompts now support click-to-move-cursor in active prompts and more accurate jump-to-prompt / copy-output behavior, and its command-finished notifications also ride those shell-known prompt boundaries.
The clue for Schell is simple:
**great terminal UX increasingly starts from shell-known chapters and prompt leases, not from guessing after the fact.**

## 2) Trust and confidence should be graded explicitly

VS Code's API does something especially worth stealing.
It distinguishes command-line **confidence** from **trust**, and says trusted replay-worthy command lines require explicit shell reporting plus nonce verification.
That is excellent pressure for Schell.
Not every visible command chapter should authorize the same actions.
Some blocks may be visible, navigable, and insertable long before they are trustworthy enough for exact rerun.

## 3) Semantic history is strongest when it stays insert-first and context-aware

VS Code's run-recent-command draws from session history, prior session history for the shell type, and the common shell history file.
iTerm2's semantic history tracks the working directory for each line so clicked paths can be resolved more intelligently.
Warp workflows similarly paste reusable commands into the active terminal input and let the operator edit arguments before running.
The import is:
**history, workflows, and semantic navigation should usually land in editable input or review, not silently execute.**

## 4) Focused help and richer suggestion rows are now obviously worth stealing

fish keeps autosuggestions accept-only and non-executing.
PowerShell/PSReadLine exposes focused parameter help below the command line via `Alt+h`.
Nushell externs describe flags, positional parameters, types, and completers, and Nushell 0.111.0 adds `display_override` so completers can show richer display text than the value inserted into the buffer.
The clue is excellent for Schell:
**value vs display should be separable, focused help should bind to the current slot, and completion should be typed enough to explain itself.**

## 5) Keyboard modernization should be progressive enhancement, not correctness truth

kitty's keyboard protocol explicitly aims to be backward compatible and opt-in while fixing legacy keyboard ambiguities.
Ghostty 1.3's key tables and chained keybinds show the value of modal navigation/review layers for complex workflows.
The import is narrow:
**Schell should absolutely steal richer key handling and mode tables for review/navigation, but those should remain local accelerants rather than the only path to shell correctness.**

## 6) Session resurrection is useful, but it must stay visibly restored

Zellij says sessions are serialized by default so they can be recreated after intentional quit or crash.
That is genuinely useful, but it is also a warning.
A restored layout or scrollback can look dangerously live.
Schell should therefore steal resurrection convenience only with strong restored/imported/history badges and a clear reacquire-live-truth step.

## 7) Transcript folklore is not enough

PowerShell's `Start-Transcript` records typed commands and console output, but Microsoft's own documentation also shows transcript limitations and out-of-order or missing data cases.
That is an important reminder.
A transcript is evidence, not omniscient truth.
Schell should keep transcript cards and replay bundles explicit, redaction-visible, and clearly weaker than fresh live state.

## 8) The shell language itself still teaches the oldest lesson: hidden splitting is poison

Oil's explanation of “quoting everywhere” calls Bourne-style automatic splitting a design flaw, while YSH keeps word, command, and expression languages more explicit and typed.
This is a strong reminder that a new shell should not casually re-import the oldest parsing traps just because they are familiar.
The import is:
**do not let command entry luxury pull Schell back into ambient expansion folklore.**

## 9) A compact Schell v0 cluster now looks strong

A decision-light cut probably needs only:
- one **shell-known packet** family for prompt lease + command chapter + chapter metadata,
- one **trust/confidence badge** family for actions on visible chapters,
- one **semantic history / workflow summon** lane that lands into input or review first,
- one **focused parameter-help** lane with richer display rows,
- one **thresholded finish-notice** lane for long-running work,
- one **restored/imported historical badge** family,
- and one rule that keyboard/protocol upgrades remain progressive enhancement instead of correctness truth.

## 10) Decisions intentionally kept open

This pass does **not** freeze:
- one escape-sequence protocol,
- one mux or pane tree system,
- one session-resurrection backend,
- one workflow/notebook store,
- one completion/plugin API,
- one trusted-chrome renderer,
- or one sync/collaboration architecture.

The no-regret move is narrower:
**make local luxuries shell-known, trust-graded, insert-first, and visibly historical when they are historical.**
