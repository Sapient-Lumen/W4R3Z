# Research synthesis — 2026-03-24 — pass CXCVII

This pass sharpens another older shell lesson that still matters for a brand-new shell+terminal:
**redirection is powerful, but it should not silently erase the difference between the typed redirect tokens, the source lanes they move, the exact targets they touch, the order they are applied, and the exact reviewed spend.**

## 1) Current shells already prove that redirect punctuation is not “just output formatting”

Bash still teaches the central lesson in the clearest possible way.
Its manual says redirections are processed in the order they appear, from left to right, and it uses the familiar contrast between `> file 2>&1` and `2>&1 > file` to show that descriptor order materially changes meaning.
That means redirect punctuation is command meaning, not decoration.

Bash also preserves a surprisingly modern idea in old syntax.
A redirect can be preceded by `{varname}`, in which case Bash allocates a file descriptor `>=10`, stores it in the variable, and lets that descriptor persist beyond the command unless later closed.
That is already a primitive fd-lease model.

Bash here-docs teach the other half of the lesson.
The delimiter word is not expanded; quoting the delimiter suppresses expansion in the here-doc body; leaving it unquoted allows parameter, command, and arithmetic expansion; and `<<-` strips leading tabs.
So “pipe this literal block into stdin” and “expand this helper template into stdin” are different acts that classic shells encode too tersely.

zsh sharpens the warning by keeping more cleverness live.
Its redirection docs say expansion happens before redirection and that if substitution on the target word yields more than one filename, redirection happens to each filename in turn.
With `MULTIOS` enabled, `date >foo >bar` behaves like a tee to two files, redirection words can undergo filename generation, and the docs explicitly warn that `date >output >&1` is unlikely to be what is intended.
That is a strong historical lesson: helpful routing tricks become footguns when order and fanout are hidden.

fish proves that a friendlier shell still cannot escape the semantics.
Its docs preserve `&>`, `&>>`, noclobber `>?`, fd-specific redirects, stderr pipes like `2>|`, combined pipes `&|`, and say that a pipe is set up first and redirections are then evaluated left-to-right.
fish also says block redirects stack, and that redirecting a builtin, function, or block above fd 2 is an error.
So even in a more humane shell, route order, scope, and stream-family limits still matter.

PowerShell and Nushell both point toward the future instead of away from it.
PowerShell documents six redirectable output streams plus an unredirectable Progress stream, says the Success stream is the default, and notes that unlike some Unix shells you can only redirect other streams to the Success stream.
Nushell distinguishes file redirections from pipe redirections, says file redirections are scoped to an expression while pipe redirections affect only the last external command in an expression, and offers `complete` to gather stdout, stderr, and exit code together.
That is a compelling design signal: once shells admit richer lane structure, explicit naming beats clever punctuation folklore.

## 2) The lesson Schell must learn from the past

The historical mistake is not simply “people sometimes typo `>`.”
The deeper mistake is **flattening routing into invisible side effects**:
- the exact redirect operators the operator typed,
- the source lane(s) those operators refer to,
- the exact target object or fd,
- the order in which redirects are applied,
- the expansion posture of the target and any here-doc body,
- the lifetime of any allocated descriptor,
- and the later receipt of what actually opened, truncated, appended, or combined.

Once those collapse, three bad things happen:
1. review becomes less exact because routing meaning is hidden behind tiny punctuation,
2. transcripts and exports preserve output text but forget how it was routed or what it touched,
3. and operators start trusting local helper packaging as if it were durable command truth.

## 3) The nifty ideas worth stealing are source-labeled and route-first

The current ecosystem points to several low-regret steals:
- **fd route chips** that say `stdout → file`, `stderr → stdout`, `stdin ← here-doc`, or `warning → success`,
- **append / truncate / noclobber badges** with visible destructive-risk posture,
- **here-doc cards** that expose delimiter quoting, expansion posture, and tab-strip behavior,
- **fd lease cards** for allocated descriptors that survive one command,
- **fanout warnings** when one line implies multiple open targets or tee-like multios,
- **order-diff reveals** for near-identical redirect sequences with different meaning,
- **expression-scoped lane cards** in the Nushell style,
- and **redirect-plus-receipt rows** that preserve both the route plan and what later actually happened.

These are super awesome because they improve comfort and safety without forcing Schell to decide:
- one final stream ontology,
- one final fd lifetime API,
- one final here-doc editor,
- one final structured-lane law,
- or one final compatibility layer.

## 4) The moves Schell should refuse for now

Schell should refuse, for now:
- redirect punctuation that only becomes explainable after a failure,
- silent truncation/fanout surprises,
- export surfaces that preserve only output and forget route intent,
- here-doc helpers that hide whether expansion happened,
- and any insistence that Unix stdout/stderr/fd folklore is the only future-worthwhile model.

In other words:
**steal the speed of classic routing, not the ambiguity of classic side effects.**

## 5) The no-regret Schell seam

Schell should add one dedicated surface for:
- typed redirect family,
- source lane,
- target witness,
- order posture,
- expansion posture,
- fd lease posture,
- destructive-risk badge,
- and reviewed-spend relation.

That lets the shell feel dramatically smarter around output routing and stdin materialization without deciding whether the long-term answer is POSIX-ish fd folklore, a richer multi-stream lane algebra, object sinks, or some hybrid.

## 6) Compact conclusion

Current official docs line up unusually well here.
Bash and fish show order still matters.
Bash and zsh show descriptor lifetime and fanout are already real shell concerns.
PowerShell and Nushell show the future gets better when stream families are named instead of implied.

So the next low-regret Schell seam is **redirection witnesses, here-doc cards, and fd-lease humility** so shell routing stays powerful and delightful without becoming hidden side-effect authority.
