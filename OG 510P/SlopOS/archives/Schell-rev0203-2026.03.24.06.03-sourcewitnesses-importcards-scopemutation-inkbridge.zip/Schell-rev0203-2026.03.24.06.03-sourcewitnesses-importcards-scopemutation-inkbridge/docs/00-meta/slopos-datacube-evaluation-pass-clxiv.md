# SlopOS datacube evaluation — pass CLXIV

This pass asks a narrower and more companion-safe question than “what terminal should Schell become?”
The better question is:
**how should Schell steal semantic marks, command chapters, inspectors, and attach-for-help luxury while staying loyal to SlopOS's exact-launch posture and the companion cubes' refusal to let descriptive residue impersonate authority?**

## 1) SlopOS says the launch boundary must stay tiny and exact

SlopOS capshell posture is already unusually clear:
- no ambient command string,
- no ambient PATH resolution,
- no ambient environment baseline,
- no ambient network or resolver,
- and observational learn mode rather than hidden execution.

That is a powerful Schell constraint.
The custom shell+terminal should not try to become magical by smuggling old shell folklore back into the launch path.
The right place to be generous is after or around exact launch:
chapters, marks, inspectors, progress, recall, and exact reveal.

## 2) SlopOS also says admission, observation, and completion are different truths

Across the datacube, SlopOS keeps separating admitted request, observed change, durable receipt, and current provider-owned live state.
That pressure applies directly to chapter luxury.
A chapter can contain:
- exact reviewed input,
- exact launch footing,
- live observed output,
- weaker terminal-local marks,
- imported provider progress,
- and a later durable receipt.

Those should not collapse into one flattering “this command block is truth.”

## 3) ViewFS pressure says basis and visible object are not the same thing

ViewFS repeatedly teaches that visible object, current basis, apply target, and receipt are different layers.
That becomes a major shell lesson.
A chapter row, a history hit, a path-like token in output, and a rerun candidate are not the same object.
So Schell should keep typed action ladders and exact basis/delta cards before stronger actions.

## 4) Helm pressure says chapter endings need settlement language

Helm’s settlement-witness pressure is unusually useful here.
For shell work, operators often need to know whether the chapter is merely:
- launched,
- exited,
- drained,
- locally durable,
- mirrored by another provider,
- or actually adopted / consumed by a downstream receiver.

That suggests a good super-awesome move for Schell:
chapter-local **settlement cards** that distinguish process outcome from downstream adoption or durable effect.

## 5) Harbor pressure says strong actions should climb visible risk ladders

Harbor’s timebound-code and risk-ladder instincts transfer cleanly.
A recalled or detected object in a chapter should not jump straight to “run” or “open.”
The shell+terminal can feel better by making the ladder explicit:
inspect → reveal → insert → attach → safe-open / derive → stronger rerun.

That preserves delight while keeping the blast radius visible.

## 6) Foundry pressure says activation and overlay comfort must remain explicit

Foundry’s config-layer and overlay-gate pressure is a useful reminder that chapter recall happens on mutable ground.
If the chapter depended on a different activation layer, foreign runtime, or config overlay, Schell should show that as an explicit gate instead of silently recreating the old posture.

## 7) Ward and Steward pressure say live status should stay source-labeled and lease-shaped

Ward’s attenuation-event / receiver stance pressure and Steward’s presence-advert / lease-chip pressure both argue against one cozy connected-now myth.
For Schell, that means live-updating chapter status, progress chrome, waiting-input hints, and attached-help context should all keep source, freshness, and lease posture visible.
A chapter may still feel live and luxurious.
It just should confess what kind of liveness it is.

## 8) What Schell should steal now

The companion-safe steals are:
- **shell-authenticated command chapters** as the core luxury object,
- **provenance-graded semantic marks** rather than one binary trusted/untrusted folklore,
- **inspector overlays** that reveal exact launch footing and outcome family,
- **attach-for-help bundles** with exact chapter context and redaction posture,
- **settlement cards** that separate exit from downstream adoption,
- and **risk ladders** for stronger recall/open/rerun actions.

These ideas make the future shell+terminal super awesome without forcing final closure on protocol, storage, or automation.

## 9) What Schell should refuse now

Schell should still refuse:
- terminal-local marks counting as shell-owned truth by default,
- history rows counting as replay-ready authority,
- one global smart-click/open policy,
- ambient reactivation of old cwd/env/config posture,
- or one final shell↔terminal transport treaty chosen before specimen proof.

## 10) Compact conclusion

The strongest companion-safe move is to keep **exact launch tiny** and make **post-launch reading luxurious**.
That means chapters, semantic marks, inspectors, attach bundles, settlement cards, and risk ladders should grow fast — while ambient startup magic, hidden replay authority, and premature transport closure stay vetoed.
