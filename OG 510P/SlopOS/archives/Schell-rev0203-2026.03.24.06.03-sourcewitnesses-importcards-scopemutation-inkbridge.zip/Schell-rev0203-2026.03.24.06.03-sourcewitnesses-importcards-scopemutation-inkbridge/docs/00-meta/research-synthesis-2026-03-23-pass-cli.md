# Research synthesis — 2026-03-23 — pass CLI

This pass sharpens the next narrower lesson from current shell+terminal tools:
**redraw-heavy live regions are worth stealing, but mutable screen furniture should stay weaker than stable shell truth until the operator freezes exactly what it was.**

That points to a good next Schell move:
**redraw witnesses, print-above lanes, and freeze-before-act rails** rather than one giant faith-based TUI story.

## 1) xterm reminds us that in-place rewriting is old terminal reality, not a novelty

The classic xterm control-sequence documentation still exposes carriage return (`CR`) and erase-in-line (`EL`) primitives.
Those are the historical ingredients behind progress bars, updating counters, spinner rows, and many “same line, new content” tricks.

That matters because it means Schell should not pretend redraw-heavy regions are exotic.
They are basic terminal reality.
The real design question is how to keep those regions honest once operators want to copy, inspect, click, share, or recover them later.

See:
- xterm control sequences PDF

## 2) Rich shows both the power of live regions and the need for explicit residue policy

Rich’s Live docs describe continuously updating renderables, alternate-screen support, transient mode, and print/log behavior that writes **above** the live display rather than smashing it.
The Progress docs also show transient completion, where the animated/progress surface can disappear once the task finishes.

That is a strong Schell clue.
A live region should not automatically become transcript truth.
Some live regions should leave final residue, some should disappear, and some should first be frozen into an inspectable snapshot.

See:
- https://rich.readthedocs.io/en/stable/live.html
- https://rich.readthedocs.io/en/stable/progress.html

## 3) prompt_toolkit shows a clean split between app redraw and ordinary prints

prompt_toolkit’s progress-bar docs use `patch_stdout()` so ordinary prints appear above the live progress area instead of corrupting it.
The same docs expose explicit cancellation and title/bottom-toolbar ideas without implying that every redraw is durable truth.

That is another Schell clue.
A terminal can keep live app furniture pleasant while routing ordinary textual events through a separate stable lane.
That is much safer than letting every line of incidental output mutate the same region the operator may later treat as evidence.

See:
- https://python-prompt-toolkit.readthedocs.io/en/master/pages/progress_bars.html

## 4) GitHub CLI accessibility work proves constant redraw can actively harm comprehension

GitHub’s engineering writeup on improving accessibility in GitHub CLI says that constantly changing visual streams and spinner redraws were difficult for speech-synthesis screen readers, so the team replaced the spinner with a static text progress indicator and used more form-like interaction where appropriate.

That is a major Schell lesson.
Redraw-heavy luxury is not neutral.
Any live-region design needs an accessibility-grade fallback where the same state changes can be expressed as stable text transitions instead of rapid paint churn.

See:
- https://github.blog/engineering/user-experience/building-a-more-accessible-github-cli/

## 5) GitHub’s Copilot CLI animation post is a warning about fragmentation and flicker

GitHub’s Copilot CLI animation article describes how terminal animation runs into fragmented terminal behavior, weak shared standards, repaint/flicker problems, and screen-reader noise.
It also notes that animation had to become opt-in and that clearing sequences and paint timing mattered.

That reinforces the same direction.
If Schell adopts redraw-rich luxuries, the shell should still own the stable state transitions while the terminal treats animation as an optional projection layer.

See:
- https://github.blog/engineering/user-experience/behind-the-scenes-of-the-copilot-cli-animated-ascii-banner/

## 6) VS Code shell integration and sticky scroll suggest that some changing regions deserve promotion and some should be excluded

VS Code’s shell-integration docs describe command detection, command guides, and sticky scroll for command blocks.
The January 2026 release notes add `terminal.integrated.stickyScroll.ignoredCommands`, explicitly acknowledging that some commands — including clear-like commands or agentic CLIs — should not be promoted into sticky command chrome the same way as ordinary commands.

That is an excellent Schell lesson.
Not every redraw-heavy or command-like region deserves stable promoted UI treatment.
Some regions should remain transient, ignored, or freeze-on-demand rather than silently graduating into stronger history chrome.

See:
- https://code.visualstudio.com/docs/terminal/shell-integration
- https://code.visualstudio.com/updates/v1_109

## 7) Compact conclusion

Current tools keep converging on a useful answer.
Schell should absolutely steal live progress strips, status bars, bottom toolbars, transient dashboards, sticky command chrome, and redraw-heavy luxuries.
But it should import them under a compact honesty contract:
- **live row witness** while the region is mutating,
- **print-above lane** for stable textual events,
- **freeze card** before strong copy/open/share/review acts,
- **final residue** only when the product intentionally leaves one behind,
- **transient gone** when no durable residue remains,
- and **accessibility downgrade** when repaint churn stops being humane.

That would let Schell become dramatically nicer than shell folklore without letting mutable pixels or terminal repaint tricks masquerade as stable shell truth.
