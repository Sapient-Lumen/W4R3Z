# SlopOS datacube evaluation, pass XCIV (2026-03-22)

This pass evaluates one narrower question against the current SlopOS archive:
**what does the companion already teach Schell about how much shell language magic it should tolerate during design phase?**

The answer is stronger than “be careful with parsing.”
**SlopOS is already pointing Schell toward a shell with a smaller native meaning floor, explicit interpreter membranes, and reviewable external-command signatures rather than shell folklore hidden behind terminal luxury.**

## 1) SlopOS already rejects the most dangerous shell-language collapse

The companion archive is explicit that `capshell.exec` should not accept a free-form command string and that the runner must not become a hidden `sh -c` or `system()` adapter.
It also keeps reviewed execution bound to structured argv and exact executable identity.

That matters for Schell because it means one old shell instinct is already off the table:
**there is no companion-compatible story where the shell+terminal can stay vague about meaning and “figure it out later” with another parser hop.**

For Schell this implies:
- exact reviewed action should not depend on hidden string reparsing,
- command text that is merely historical or proposed should stay weaker than exact bound launch meaning,
- and the shell should prefer command lanes whose meaning can be revealed directly.

## 2) The companion's no-expansion posture is a huge clue

SlopOS also declines shell-style front-end word expansion before binding reviewed argv.
No ambient globbing, no tilde rewrite, no variable folklore, no command substitution layer, and no hidden namespace reads are supposed to happen merely because the operator typed shell-looking text.

That is not only a runtime-safety choice.
It is also a user-interface clue.
A terminal can only offer excellent preview, replay, chapter capture, workflow harvesting, and rerun surfaces if the shell can say which text was literal, which substitutions were explicit, and where the external boundary begins.

For Schell this implies:
- the native lane should stay visibly smaller than classic shell folklore,
- expansion should be explicit when it exists,
- and effect-preview surfaces should decorate exactness rather than compensate for hidden rewrite stages.

## 3) SlopOS makes explicit interpreters easier to justify

Because the companion already insists that shell-language semantics live only inside an explicitly chosen interpreter, Schell does not need to fake universality.
It can carry a simpler native lane and still admit other shells or runtimes honestly.

That means compatibility can stay as a **named membrane**:
- explicit interpreter,
- explicit script entry,
- explicit workflow artifact,
- explicit review.

This is companion-compatible in a way that silent legacy emulation is not.
It preserves exactness while still letting users cross into familiar ecosystems when they truly choose to.

## 4) Known externs fit the companion surprisingly well

The archive already separates exact reviewed launch from helper comfort, typed routes, learn-mode observation, and stronger review paths.
That makes a new Schell idea more plausible:
**known extern signature packs.**

A known extern pack could provide:
- signature/help/completion data,
- parameter naming,
- argument-shape hints,
- workflow-seed enrichment,
- and better WhatIf/review cards,

without pretending that the external tool stopped being external.

That is deeply aligned with SlopOS because it keeps comfort weaker than exact reviewed execution.
The signature pack is a lens.
The executable object and reviewed argv are still the stronger truth.

## 5) The companion also sharpens what not to steal

This pass suggests Schell should remain suspicious of:
- universal pre-exec expansion,
- command-string convenience lanes,
- startup/profile hooks that silently alter command meaning,
- workflow or signature metadata that outranks fresh review,
- and terminal luxury features that blur native shell meaning with compatibility membranes.

Those are exactly the kinds of flattening moves the companion keeps refusing elsewhere.

## 6) The companion-compatible shape

This pass therefore recommends a bounded import shape.

### A) A smaller native parse floor
A command language whose meaning can be shown directly and whose literal words remain literal unless stronger forms are explicit.

### B) Explicit interpreter membranes
Compatibility stays available, but only as a visibly chosen lane.

### C) Known-extern signature packs
Steal better docs/completions/highlighting/preflight help without pretending the external boundary disappeared.

### D) Review-first workflow insertion
Saved commands and workflow seeds should land in active input or review lanes before execution.

## 7) Compact conclusion

SlopOS is still design-phase, but it already gives Schell a very practical rule:

**make the native shell lane smaller and more exact, then let luxury accumulate above it through known signatures, review cards, and explicit compatibility membranes.**

That is a decision-light way to get smarter than classic shells without claiming to have solved shell language in one leap.
