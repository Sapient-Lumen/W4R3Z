# SlopOS datacube evaluation, pass CIII (2026-03-22)

This pass evaluates one narrower question against the current SlopOS archive:
**what does the companion already teach Schell about composition/preedit state, committed text, and the difference between visible input comfort and exact shell meaning?**

The answer is stronger than “be careful with IMEs.”
**SlopOS already pressures Schell to keep composition/preedit comfort, exact committed input, and later reviewed execution as different layers instead of one flattering typing story.**

## 1) SlopOS already keeps reviewed launch meaning smaller than nearby input convenience

The companion's capshell posture is unusually clarifying here.
Exact executable selection, exact `argv[0]` derivation, explicit env, and explicit startup-code posture all say the same thing:
reviewed execution meaning should not depend on nearby convenience or hidden ambient state.

That is direct pressure on Schell.
A visible preedit region, candidate window, or dead-key hold cannot quietly become the reviewed shell input just because the operator can already see it on screen.

For Schell this implies:
- committed text is stronger than visible preedit,
- shell parse/argv are stronger than composition widgets,
- and review/execution should only attach meaning after composition has committed into a shell-owned buffer.

## 2) The companion's manual-only automation posture is a huge clue

D-UIAUT is equally helpful.
Observation and injection are explicitly separate, automation remains manual-only in Phase 1, and no ambient accessibility/automation constructor is allowed to become a hidden global input channel.

That matters for Schell because IME candidate windows, accessibility echoes, predictive overlays, and other composition helpers are nearby UI.
They may be valuable, but they should not silently widen into shell authorship or reviewed action.

For Schell this implies:
- composition UI defaults to **editing/composition posture**,
- accessibility echoes remain **observational aids** unless separately widened,
- and stronger shell meaning still belongs to explicit committed text plus later review.

## 3) Exactness around startup and selection sharpens the “commit” rule

The companion's refusal of ambient PATH/search, startup hooks, and name-spoofed launch meaning gives Schell a clean construction rule for text entry too:
**the shell should become exact later, not earlier.**

Composition comfort can be rich.
But exactness begins when committed text reaches the shell-owned buffer and then proceeds through parse, effect preview, and reviewed action.
Preedit should not jump ahead of that ladder.

## 4) Learn mode and review sequencing reinforce a smaller answer

SlopOS already keeps observational help weaker than reviewed action.
That gives Schell a good import rule for this seam:
assistant help, quick fixes, autosuggestions, and command explanations should trigger from committed shell text or stronger shell-owned objects — not from transient preedit state.

This keeps the shell+terminal decision-light while both projects are still in design phase.
It avoids designing a giant IME framework while still naming the boundary that matters.

## 5) The companion-compatible shape

This pass therefore recommends a bounded import shape.

### A) Composition witnesses
Treat preedit/dead-key state, candidate ownership, committed buffer text, and later parse/argv truth as different families.

### B) Commit-first promotion
Let the operator move cleanly from:
- visible composition,
- to exact committed text,
- to shell parse/preview,
- to reviewed action.

### C) Candidate-window humility
Candidate/clauses remain platform- or IME-local helpers unless the shell explicitly turns committed text into stronger meaning.

### D) Exact committed text precedence
When exact committed text exists, it remains stronger than visible preedit, clause highlighting, or display-width hints.

## 6) Compact conclusion

SlopOS is still design-phase, but it already gives Schell a very practical rule:

**make multilingual text entry luxurious as composition, then promote explicitly into committed shell text and later reviewed meaning when stronger truth exists.**

That is a careful way to steal modern terminal brilliance without letting visible composition state quietly become shell truth.
