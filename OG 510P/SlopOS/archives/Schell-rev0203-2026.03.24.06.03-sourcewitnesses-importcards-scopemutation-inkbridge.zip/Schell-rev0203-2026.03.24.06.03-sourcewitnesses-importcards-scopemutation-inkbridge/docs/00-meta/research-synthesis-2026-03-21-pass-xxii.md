# Research synthesis, pass XXII (2026-03-21)

This pass focuses on another load-bearing seam:
**modern shells and terminals keep converging on shell-marked command chapters, exact command-context handoff, and better recent-command UX. The important lesson for Schell is not “history everywhere.” The important lesson is to make command chapters exact, journals source-labeled, and recall clearly weaker than current authority.**

## 1) Shell integration keeps proving that command chapters are the right unit

VS Code’s shell integration docs say shell integration lets the terminal understand more about what is happening inside the shell, enabling working-directory detection, command detection, decorations, and navigation. Windows Terminal’s shell-integration guide then shows the concrete chapter shape: shells mark prompt, command start, command executed, and command finished with OSC 133 sequences, and the terminal uses those marks for jumping between commands and selecting an entire command or its output. WezTerm documents the same direction through OSC 7, OSC 133, and OSC 1337 user vars. The convergence is very strong: command chapters should be shell-known objects, not renderer guesses. See: https://code.visualstudio.com/docs/terminal/shell-integration ; https://learn.microsoft.com/en-us/windows/terminal/tutorials/shell-integration ; https://wezterm.org/shell-integration.html

## 2) Chapter-local actions get much better once those marks exist

Windows Terminal’s current shell-integration docs explicitly list features like showing marks for each command in the scrollbar, automatically jumping between commands, and selecting the entire output of a command. That is a very stealable move for Schell: chapter navigation and chapter-local selection are high-value affordances that do not require freezing the entire shell architecture. See: https://learn.microsoft.com/en-us/windows/terminal/tutorials/shell-integration

## 3) iTerm2 shows the right kind of journal partitioning

iTerm2’s shell integration tracks command history separately for each username+hostname combination, and it also stores recent directories separately for each username+hostname combination. That is a brilliant clue for Schell: command journals should not flatten local work, remote peers, and different operator identities into one comforting pile. Per-peer journal partitions are a real product improvement, not a niche detail. See: https://iterm2.com/documentation-shell-integration.html

## 4) Exact handoff should attach a chapter, not ask for paste rituals

VS Code’s October 2025 update says a tracked terminal command can be attached to chat as context, and that the attachment shares the command line, captured output, and exit code. That is one of the clearest modern hints for Schell: a command chapter should be attachable as an exact bounded object instead of requiring manual copy/paste. See: https://code.visualstudio.com/updates/v1_106

## 5) History pollution is a real design problem, not just a settings nit

VS Code’s December 2025 update says that when shell integration is enabled, commands run by the terminal tool are no longer included in shell history for bash, zsh, pwsh, and fish; it even explains that bash uses `HISTCONTROL=ignorespace` plus a prefixed space. This is a very important Schell lesson. Operator history, tool-issued commands, proposal execution, and workflow replay should not silently merge into one recall surface just because they all happened in a terminal. See: https://code.visualstudio.com/updates/v1_108

## 6) Source-labeled suggestions remain the safer pattern

fish’s interactive docs say autosuggestions do nothing unless the user explicitly accepts them. PSReadLine’s predictor docs say predictive suggestions can come from history or plug-in modules. Put together, that gives Schell a strong rule: recall and suggestion sources should stay source-labeled and inert rather than being fused into a single mysterious recommendation. See: https://fishshell.com/docs/current/interactive.html ; https://learn.microsoft.com/en-us/powershell/scripting/learn/shell/using-predictors?view=powershell-7.5

## 7) Ghostty keeps reminding us that low-friction summon surfaces matter

Ghostty’s quick-terminal docs describe a singleton drop-down terminal that can be shown from a global keybind and preserves its state between appearances. Its 1.3.0 release notes also say the quick terminal sets a `GHOSTTY_QUICK_TERMINAL` environment variable and that newer shell integration work supports more shells and faster hooks. That is a useful product hint for Schell: a chapter browser or observational cockpit summoned instantly is a great fit, as long as its state is still clearly local UX rather than durable shell truth. See: https://ghostty.org/docs/config/keybind/reference ; https://ghostty.org/docs/install/release-notes/1-3-0 ; https://ghostty.org/docs/features/shell-integration

## 8) Structured data remains attractive, but it is still a big commitment

Nushell’s docs keep showing the appeal of structured navigation, like cell paths through records and tables. The lesson for Schell is still the same as earlier passes: steal the ergonomic idea that command chapters and journals can expose useful fields, but do not let that force a universal structured-pipeline commitment before the chapter/journal seam itself is proven. See: https://www.nushell.sh/book/navigating_structured_data.html

## 9) The past lesson is harsher than “history is useful”

Classic shell history made at least four recurring mistakes:
- it flattened human, tool, replay, and imported commands together,
- it treated near-textual similarity as good enough basis for rerun,
- it confused previous success with current authority,
- and it left chapter boundaries fuzzy enough that terminals had to infer what belonged together.

The current product landscape suggests a better answer:
**make command chapters exact, make journals partitioned and source-labeled, and make recall weaker than fresh review.**

## 10) A strong Schell v0 cluster is compact

A decision-light first cut probably needs only:
- one shell-owned **command chapter** object,
- one **exact journal** partitioned by lane / source / peer,
- one **history-pollution guard** so agent/tool commands do not silently colonize the operator journal,
- one **chapter browser** or palette that stays observational by default,
- and one **recall ladder** separating inspect, insert, review-rerun, and attach-for-help.

## 11) Decisions intentionally kept open

This pass does **not** freeze:
- one history database or sync story,
- one workflow/notebook model,
- one structured-pipeline format,
- one final quick-terminal product shape,
- one cross-device restore treaty,
- or one plugin ecosystem for recall providers.

The no-regret move is narrower:
**treat commands as exact chapters, treat journals as source-aware control state, and make recall visibly weaker than live authority.**
