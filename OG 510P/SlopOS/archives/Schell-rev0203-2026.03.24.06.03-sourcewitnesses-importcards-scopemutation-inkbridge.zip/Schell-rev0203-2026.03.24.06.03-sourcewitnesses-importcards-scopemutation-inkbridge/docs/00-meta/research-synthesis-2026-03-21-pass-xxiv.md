# Research synthesis, pass XXIV (2026-03-21)

This pass keeps another design rule in view:
**project entry should become dramatically faster without letting launch kits, restored sessions, or quick-summon surfaces impersonate current authority.**

The outside terminal landscape keeps converging on a useful split.
The best tools separate:
- saved launch shape,
- current live sessions,
- restored history,
- and fast summon.

That is a very strong clue for Schell.

## 1) Saved project launch shape is worth stealing

Warp's Launch Configurations let you save windows, tabs, and panes so the same arrangement can be reopened per project.
That is a very stealable idea.
The important move is not “save layout” by itself.
The important move is making the layout an explicit artifact rather than rc-file folklore.
See: https://docs.warp.dev/terminal/sessions/launch-configurations

## 2) Session navigation should search *sessions*, not just commands

Warp's Session Navigation palette searches active sessions and lets the operator refine results by prompt, currently running command, last run command, and command status.
That is a strong clue that Schell should not force project reentry to start from only command history or only pane trees.
A session navigator is its own thing.
See: https://docs.warp.dev/terminal/sessions/session-navigation

## 3) Restoration is useful, but durable restoration is a distinct choice

Warp's Session Restoration restores windows, tabs, panes, and recent Blocks, and it persists the previous session to a local SQLite database.
That is both an inspiration and a warning.
The inspiration is that resuming context is high-value.
The warning is that session persistence is real storage with sensitivity and truth costs.
Schell should separate restoration from quick summon and from launch kits, not blur them together.
See: https://docs.warp.dev/terminal/sessions/session-restoration

## 4) Quick summon is best when it is runtime-fast and epistemically modest

Ghostty's quick terminal is a global-keybind drop-down terminal whose state is preserved while it is hidden, but Ghostty explicitly says it will not be restored when the application restarts.
That is a brilliant design clue.
Schell should strongly consider a runtime-only quick cockpit or quick summon pad that is fast and always near, but does not pretend to be durable project truth.
See: https://ghostty.org/docs/config/keybind/reference ; https://ghostty.org/docs/features

## 5) Launch menus should make attach and new-launch explicit

WezTerm's launcher menu exposes explicit launcher entries and also lists multiplexer domains for connecting and spawning tabs/windows in those domains.
That is a great import for Schell.
A project cockpit should make choices like:
- open a fresh launch kit,
- attach to a live domain,
- or inspect before doing either,

instead of flattening them into one “open project” action.
See: https://wezterm.org/config/launch.html ; https://wezterm.org/config/lua/config/launch_menu.html

## 6) Session persistence and attach/revive are different actions

VS Code's terminal docs distinguish process reconnection, process revive, and manual detach/attach between windows.
That distinction is deeply useful.
Schell should likely keep at least these separate:
- reattach current live session,
- restore a historical layout,
- relaunch from a kit,
- and move a live session view.
See: https://code.visualstudio.com/docs/terminal/advanced ; https://code.visualstudio.com/updates/v1_58

## 7) Recent directories and recent commands remain high-value cockpit cues

iTerm2 shell integration tracks command history, current working directory, host name, and more—even over SSH—and exposes Open Command History and Open Recent Directories.
That suggests a Schell project cockpit should not be only about panes.
Recent chapter, recent directory, and recent peer cues are excellent project-entry material.
See: https://iterm2.com/documentation-shell-integration.html ; https://iterm2.com/documentation-one-page.html

## 8) Shell-known chapter marks remain the foundation

Windows Terminal's shell integration uses semantic prompt / command / output / finished marks to support scrolling between commands, selecting command output, and recent command suggestions.
That keeps reinforcing the same point: richer session and cockpit UX works best when command chapters are shell-known first.
See: https://learn.microsoft.com/en-us/windows/terminal/tutorials/shell-integration

## 9) A compact Schell v0 cluster is strong

A decision-light first cut probably needs only:
- one explicit **launch-kit** object,
- one **quick-summon** surface that is runtime-fast but not durable-by-default,
- one **session navigator** spanning live / restored / kit / historical objects,
- one explicit **attach vs relaunch vs restore vs fresh launch** ladder,
- one **project cockpit** strip showing recent chapters/directories/peers/seeds,
- and one **hold rule** when target or basis truth is not strong enough.

## 10) Decisions intentionally kept open

This pass does **not** freeze:
- one workspace manager product,
- one pane layout schema,
- one sync or collaboration backend,
- one remote multiplexer treaty,
- one durable session database shape,
- or one cross-device project-cockpit model.

The no-regret move is narrower:
**make project entry explicit, fast, and clearly badged, while keeping launch, attach, restore, and quick-summon as different named actions.**
