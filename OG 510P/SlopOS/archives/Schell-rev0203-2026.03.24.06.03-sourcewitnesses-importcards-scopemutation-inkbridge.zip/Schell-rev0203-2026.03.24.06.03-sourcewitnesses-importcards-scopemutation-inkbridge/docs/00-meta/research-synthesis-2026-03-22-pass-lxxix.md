# Research synthesis, pass LXXIX (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should steal the best parts of modern tool launchers — one-shot execution, isolated installs, pinned project environments, and explicit promotion paths — but it should keep source identity, cache reuse, lock posture, startup mutations, and exact reviewed basis separate so “I can run this tool now” never impersonates “this tool is now trusted, pinned, reproducible, or part of my shell forever.”**

This seam matters because the current ecosystem keeps making tool acquisition easier in ways that are genuinely brilliant and genuinely flattening:
- on-demand tool execution from registries or caches,
- user-local installs that place binaries on `PATH`,
- project-local locks and ephemeral environments,
- third-party taps or registries that widen where commands come from,
- and installer flows that still encourage rc-file or search-path edits.

All of those are useful.
What they usually blur together is:
1. **where the tool came from**,
2. **whether this run is exact or floating**,
3. **whether a cache is being reused**,
4. **whether any project or user configuration is being changed**,
5. **and whether the tool is merely runnable now or actually admitted into a durable environment story**.

## 1) Modern on-demand tool runners are worth stealing — but only if they confess their footing

Current tool UX is clearly converging on fast one-shot execution.
`uv tool run` runs tools without prior installation and installs their dependencies into a temporary isolated virtual environment; `uvx` is just an alias for that path.
`pipx run` similarly creates or reuses a temporary environment and caches it for a few days before fetching fresh again.
`npm exec` goes even further: if the requested package is not already present in the local project dependencies, it installs it into a folder in the npm cache and adds that folder to `PATH` for the executed process.

That is a great design clue for Schell.
A shell+terminal should absolutely have a **run-once lane** for external tools.
But it should also show: origin family, exact selector, cache posture, and whether the current run is project-pinned, user-installed, or just borrowed from a transient lane.
See: https://docs.astral.sh/uv/concepts/tools/ ; https://pipx.pypa.io/stable/explanation/how-pipx-works/ ; and https://docs.npmjs.com/cli/v8/commands/npm-exec/

## 2) Reproducibility still lives in locks and exact refs, not in the friendliness of the launcher

Current docs make the split very plain.
`npm ci` is meant for clean, automated installs; it requires an existing lockfile, exits if `package.json` and the lock disagree, and never writes to `package.json` or the lockfiles.
Cargo is even sharper: by default `cargo install` ignores the packaged `Cargo.lock`, and `--locked` is the flag that forces Cargo to use it for more reproducible builds.
Nix flakes keep telling the same story from another angle: `flake.lock` pins flake inputs, and Nix will happily operate on remote references like `github:NixOS/nixpkgs`.

So the lesson is not “pick one package manager.”
It is: **friendly launch and reproducible footing are different objects.**
Schell should therefore separate:
- floating registry run,
- exact version run,
- lock-backed project run,
- exact git revision run,
- and local reviewed artifact run.
See: https://docs.npmjs.com/cli/v8/commands/npm-ci/ ; https://doc.rust-lang.org/cargo/commands/cargo-install.html ; https://nix.dev/concepts/flakes.html ; and https://nix.dev/manual/nix/2.18/command-ref/new-cli/nix3-flake-lock

## 3) Installers still widen authority through search-path and shell-startup mutations

The ecosystem is still surprisingly comfortable with startup-footing changes.
The official Rust installer flow on Unix is still a fetched shell script (`curl ... | sh`).
`uv tool install` puts executables into a bin directory on `PATH`, and if that directory is not already on `PATH`, `uv tool update-shell` can add it in common shell configuration files.
`pipx ensurepath` similarly updates `PATH`, and its docs even expose `--prepend` when the operator wants pipx-managed binaries to win name resolution ahead of existing system tools.

These are useful behaviors.
They are also exactly the kind of thing Schell should surface as **startup mutation cards** or **path-priority reviews**, not as afterthoughts.
See: https://rustup.rs/ ; https://docs.astral.sh/uv/guides/tools/ ; and https://pipx.pypa.io/stable/installation/

## 4) Source widening is a real feature — which means it needs explicit source cards

Homebrew’s tap docs remain one of the best examples of source widening being treated as ordinary UX.
A tap adds more repositories to the list of formulae Homebrew tracks, updates, and installs from.
Taps are external sources of formulae, casks, and even external commands, and direct installation of `user/repository/formula` will automatically add the tap before installation.
That is fantastically convenient and also a perfect example of why Schell should keep **source family** explicit.
A tool coming from a project lock, the default system source, a third-party tap, a git revision, or a one-shot registry fetch should not share one badge.
See: https://docs.brew.sh/Taps and https://docs.brew.sh/How-to-Create-and-Maintain-a-Tap

## 5) The strongest super-awesome move is a promotion ladder

The best current products already hint at a progression, but they do not unify it well.
Schell can.
A compact promotion ladder would look like this:
1. **Run once** in a transient lane.
2. **Pin exactly** for this command or workflow seed.
3. **Attach to project** by writing the project-owned lock/spec surface.
4. **Promote to user tool** with explicit PATH/startup review.
5. **Admit as native pack** only after source/provenance posture is acceptable.

The shell can feel brilliant if it makes that ladder explicit instead of flattening all five into “install tool”.

## 6) What Schell should absolutely refuse

Schell should refuse:
- one generic “install” button that hides whether the action is run-once, cache reuse, project pin, user install, or startup mutation,
- treating cached tool reuse as proof of exact reproducibility,
- treating a friendly version label or package name as proof of exact basis,
- treating a third-party repository/tap/registry source as equivalent to a project-locked local source,
- and treating search-path or shell-config mutation as a mere cosmetic postscript.

## 7) Decisions intentionally kept open

This pass does **not** freeze:
- one final Schell package-manager abstraction,
- one final trust/provenance policy for external tools,
- one final lockfile import story across npm/Cargo/Nix/Python/Homebrew ecosystems,
- one final cache policy or reuse window,
- or one final startup-mutation/install UX.

The no-regret move is smaller:
**give Schell tool-origin cards, run-once passes, exact-pin rails, promotion ladders, cache posture badges, and startup-mutation review cards so tool convenience gets better without letting first-run comfort impersonate durable trust.**
