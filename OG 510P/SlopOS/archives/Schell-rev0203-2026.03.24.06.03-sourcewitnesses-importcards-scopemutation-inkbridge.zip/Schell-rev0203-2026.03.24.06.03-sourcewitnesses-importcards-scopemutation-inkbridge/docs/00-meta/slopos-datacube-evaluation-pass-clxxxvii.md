# SlopOS datacube evaluation — 2026-03-23 — pass CLXXXVII

**Schell should treat discovery as a metadata-safe, context-badged staging lane rather than a hidden execution plane, because SlopOS and the companion datacubes keep rewarding explicit selection posture, explicit preview weakness, explicit non-authoritative recents, and explicit observational help.**

## 1) SlopOS keeps recents and session choice weaker than authority

SlopOS keeps OpenURI recent-items non-authoritative and refuses to turn generic launch into a durable reopen plane.
It also keeps session selection handler-local instead of portable launch truth.
That pressure transfers directly to Schell.

A recent hit, palette result, or remembered target may still be useful.
But it should remain:
- a shell-owned hint,
- not a reopen grant,
- not current live-session proof,
- and not authority to run.

## 2) SlopOS keeps preview weaker than exact review/open

The quarantined result-preview boundary is especially valuable here.
It keeps result rendering metadata-safe and refuses to let selection, focus, or hover turn into ambient content preview.
That is exactly the right warning for discovery in a shell+terminal.

Schell should therefore treat preview as its own posture:
- metadata-safe by default,
- stronger preview only through explicit inspect/open,
- and no hidden “it was only a hover pane” laundering.

## 3) SlopOS keeps learned help observational only

The capshell learn-mode posture is a strong adjacent lesson.
It keeps suggestions observational, stage-local, and non-authoritative; it refuses auto-edit, auto-approve, and auto-rerun.
That should shape discovery too.

A ranked or remembered suggestion may help the operator.
It should still remain weaker than a fresh reviewed action path.

## 4) Companion cubes reinforce the same split

- **ViewFS** reinforces neighboring-state separation, which matters because deck cards, marks, annotations, palette rows, and current editable input should remain separately named objects.
- **Harbor** reinforces label honesty, which matters because badges such as recent, pinned, workspace, live, and inspect-safe should remain descriptive rather than authority-bearing.
- **Ward** reinforces revalidation and freshness budgets, which matters because palette results and pinned cards should visibly age and weaken instead of quietly remaining “good enough forever.”
- **Foundry** reinforces footing drift, which matters because a remembered command or object may stand on changed env, cwd, peer, or auth footing.

Together they point toward one shell+terminal rule:
**discovery posture is a witness family, not a shortcut around review.**

## 5) What this does not require Schell to decide yet

This seam does **not** require Schell to decide:
- one global search index,
- one cross-device sync story,
- one preview renderer,
- one ranking engine,
- one deck persistence backend,
- or one universal command-palette grammar.

The archive only needs to prove a compact honesty stack that says:
- what family a result belongs to,
- what context/scope produced it,
- what preview posture is allowed,
- what action floor remains honest,
- and when insert/stage is better than run.

## 6) Compact conclusion

SlopOS keeps recents weaker than reopen authority, preview weaker than explicit review, and learned help weaker than authorization.
The companion datacubes keep labels, freshness, drift, and neighboring-state separation honest.

So the next Schell move should be:

**deepen command decks, marks, annotations, and discovery honesty with context stripes, insert-not-run defaults, object-vs-action row separation, and metadata-safe previews so the shell feels much smarter without letting a palette hit quietly become current authority.**
