# SlopOS datacube evaluation, pass XCV (2026-03-22)

This pass evaluates one narrower question against the current SlopOS archive:
**what does the companion already teach Schell about inline suggestions, accepted buffer text, and live prompt editing?**

The answer is clearer than it first appears.
**SlopOS is already pressuring Schell to keep ghost suggestions, inserted buffer text, and reviewed action as different states with different authority stories.**

## 1) Learn mode already refuses the worst possible shortcut

The companion's capshell learn-mode posture is extremely valuable here because it pins suggestion behavior to an observational-only lane.
Denied actions remain denied.
Reports are non-authoritative suggestions.
There is no auto-edit, no auto-approve, and no auto-rerun.

That matters for Schell because prediction and inline help are very tempting places to smuggle those shortcuts back in.
The companion says not to.
A suggestion may be useful, but it is still weaker than the reviewed launch path.

For Schell this implies:
- ghost predictions should stay ghost predictions until explicitly accepted,
- accepted predictions should still be weaker than reviewed action,
- and source-labeled editor comfort should never widen authority by itself.

## 2) The companion already keeps canonical truth shell-owned

SlopOS explain posture is also a strong clue.
Canonical diffs/summaries are shell/provider-owned, and receipts remain non-authoritative evidence.
That is exactly the kind of discipline Schell needs for prompt-time help.

A prediction source, inline hint, or accepted completion fragment can help the operator a lot.
But it should not become the canonical record of what command meaning is.
The stronger truth still lives in the exact reviewed action basis.

That means Schell should avoid a dangerous collapse:
- helper prose,
- accepted ghost text,
- and exact reviewed launch

should not masquerade as one thing merely because they all appeared near the prompt.

## 3) Structured argv pressure makes buffer authorship more important, not less

The companion already refuses free-form command-string execution, hidden front-end word expansion, and late executable reopening by name.
Reviewed execution is supposed to bind exact argv and an exact executable object or explicit interpreter.

That means Schell's editor layer cannot be a vague pre-language haze.
If the project eventually wants exact argv reveal, lane badges, WhatIf cards, and compare-after-run receipts, then it benefits from knowing how the current buffer became what it is.

Not because every keystroke needs a durable log.
Because the shell should stay able to say:
- this part was only a suggestion,
- this was inserted from history or workflow recall,
- this was pasted from outside,
- and this is the exact command the operator finally reviewed.

## 4) Live prompt editing should be a shell truth, not renderer folklore

The companion keeps pressing Schell toward explicit shells, explicit review seams, and explicit live-state humility.
That suggests a clean import for prompt-local click editing too.

If the terminal is allowed to move the cursor inside the active prompt, it should do so because the shell says where the active prompt is, not because the renderer guessed which text looks prompt-shaped.
That matches the broader SlopOS design instinct: exact state should come from an explicit seam, not from a flattering inference.

For Schell this implies:
- one live editable prompt lease,
- prompt-local click/edit luxuries only inside that lease,
- and historical command chapters staying historical even when they are visibly rich.

## 5) The companion-compatible import shape

This pass suggests a very bounded import.

### A) Source-labeled suggestion lanes
Predictions may come from history, known externs, workflows, helpers, or future richer sources, but they stay visibly source-labeled and weaker than exact review.

### B) Accept-only insertion
Prediction acceptance inserts editable buffer text.
It does not auto-run, auto-review, or auto-widen authority.

### C) Buffer authorship posture
Typed, pasted, recalled, workflow-inserted, helper-inserted, and still-ghost text should remain distinguishable enough that stronger surfaces do not overclaim what the operator authored.

### D) Shell-authenticated live prompt editing
Prompt-local cursor movement and richer editing should depend on shell-known active-input truth rather than terminal guesswork.

## 6) Compact conclusion

SlopOS is still design-phase, but it already gives Schell a very practical rule for inline predictions and prompt luxury:

**suggestions may help, accepted text may become editable input, but only exact reviewed action carries the stronger execution story — and the live prompt should be a shell-known region rather than a renderer guess.**

That is a careful, decision-light way to steal some of the best modern shell editing ideas without letting them harden into hidden authority.
