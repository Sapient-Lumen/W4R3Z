# SlopOS datacube evaluation, pass CXVII (2026-03-22)

This pass evaluates one narrower question against the current companion archives:
**what do SlopOS, ViewFS, and Steward teach Schell about giving some shell objects stronger memory gravity than others once recall/search becomes rich, mixed, and highly interactive?**

The answer is crisp:
**mixed recall should stay source-labeled, and promotion into stickier or more durable memory should follow explicit budgets rather than one flattering “history/search” story.**

## 1) SlopOS keeps descriptive objects weaker than present authority

The SlopOS companion keeps repeating a constitutional rule in many domains:
- descriptive wallets are weaker than live grants,
- request identity is weaker than present authority,
- local login/account mediation does not become exportable identity or session-state authority,
- and manual capture remains distinct from durable/published residue.

That transfers directly.
A shell object being visible, restored, searchable, or previously useful is not enough to grant it stronger memory gravity.
If a remembered object is helper-generated, imported, restored, secret-bearing, or publication-crossed, Schell should say so before that object borrows sticky chrome, sync, or rerun gravity.

## 2) SlopOS auth/export boundaries argue against accidental promotion

Several SlopOS auth-mediation boundaries keep “successful local mediation” from silently becoming exportable cookies, identity claims, authorization context, or logout/revoke authority.
That pattern is incredibly useful for Schell.

The shell analogue is:
- searchable is not syncable,
- syncable is not shareable,
- shareable is not publishable,
- and restored is not live.

Those need separately named promotions.

## 3) Capture posture argues for lighter gravity on transient or observer-only lanes

SlopOS capture posture keeps manual session capture explicit and non-persistent by default.
ViewFS similarly refuses to flatten observe/follow, attach, control, and historical surfaces.

For Schell, the implication is simple.
Not every visible or observed shell-adjacent object deserves full memory gravity.
Some things should remain:
- inspectable but not sticky,
- searchable but not syncable,
- stageable but not runnable,
- or historical but not top-hit recent-command material.

That is exactly the kind of selective gravity a shell+terminal needs once it gets more ambitious than bash.

## 4) Steward reinforces that trusted chrome should declare freshness and basis

Steward keeps labels and trusted chrome freshness-scoped.
That is the right nearby lesson for mixed recall.
A sticky command header, search result, or restored block should not only say where it came from.
It should also say whether it is:
- direct or generated,
- fresh or historical,
- live or restored,
- local-only or publication-crossed,
- and ordinary or secret-sensitive.

That is how rich memory stays trustworthy.

## 5) Companion-compatible no-regret move

Schell does **not** need one final universal memory law.
It only needs a few bounded rules:

### A) Keep source class visible
Direct command chapters, helper-generated steps, workflows, notebooks, assistant traces, and restored artifacts should stay separately named.

### B) Keep gravity smaller than residence
An object can exist locally or durably without earning sticky/default-rerun/share gravity.

### C) Promote explicitly
Searchable, sticky, durable, syncable, shareable, and publishable are different steps.

### D) Keep anti-gravity classes explicit
Visual reset commands, watch noise, helper wrappers, secret-bearing inputs, and historical residue should not compete as ordinary top-tier recall objects.

### E) Keep all remembered objects weaker than fresh review
Even the best mixed recall surface should still land on inspect, jump, insert, or stage before it lands on strong action.

## 6) Compact conclusion

The SlopOS-compatible answer is not “make every shell-adjacent object equally searchable and sticky.”
It is:
**preserve source class, assign explicit memory gravity, make stronger promotions explicit, and keep mixed recall objects weaker than fresh local review on current basis.**

That is a design-phase-safe move because it makes Schell dramatically smarter without forcing the final search, sync, or collaboration architecture.
