# SlopOS datacube evaluation, pass XCIX (2026-03-22)

This pass evaluates the SlopOS companion pressure on one narrower seam:
**if Schell steals prompt brilliance, what must SlopOS pressure force it to keep honest about startup, per-directory context, exact review sequencing, and prompt-time helper work?**

The answer is tighter now.
**SlopOS pressures Schell to treat prompt rendering as a weaker status-and-orientation lane, never as a hidden authority lane.**

## 1) D-CAPSHELL still pressures Schell to treat shell glue as a privilege boundary, not a cosmetic layer

RFC-0115 already says shell scripts, cron jobs, CI hooks, and admin runbooks are where least-privilege collapses into ambient authority.
That pressure clearly applies to prompts too.
A prompt is often built from shell functions, startup scripts, helper commands, and project-local environment machinery.
So the companion lesson is straightforward:
Schell should not treat prompt-time code as decorative just because it renders text.

## 2) exact review sequencing stays stronger than prompt convenience

The companion’s learn-mode posture, explicit-exec posture, command-string refusal, and word-expansion posture already insist that nearby convenience must stay weaker than exact reviewed action.
That means a prompt may:
- summarize,
- hint,
- badge,
- and orient.

But it should not silently:
- mutate the execution basis,
- choose a different executable,
- or widen authority just because a redraw occurred.

Prompt-time comfort belongs on the display side of the seam.
Exact review and execution still come later.

## 3) startup/profile explicitness directly constrains prompt customization

PowerShell-style profiles, zsh hook arrays, prompt engines, and repo-local context loaders all exert the same pressure:
startup ownership matters.
The companion already dislikes hidden startup/profile control and ambient repo-local magic.
So Schell should keep at least these postures separate:
- shell-native builtin prompt segments,
- reviewed local prompt config,
- imported theme/segment packs,
- repo-offered prompt/context packs,
- terminal-bridge prompt help,
- and degraded/no-prompt-luxury fallback.

That one split preserves a large amount of truth.

## 4) repo and cwd context should be visible as a witness, not silently loaded as prompt folklore

direnv-like per-directory context is useful enough that many systems normalize it.
The companion says that is exactly where ambient authority returns if we are not careful.
So any cwd/repo-triggered prompt enrichment should stay visibly weaker than reviewed env/exec ground.
A prompt may say:
- pack available,
- pack leased,
- env delta pending review,
- stale repo context,
- imported historical context.

But prompt redraw should not itself be the contract that makes local project bytes authoritative.

## 5) attention and trusted-path pressure argue for prompt facts that are brief, source-labeled, and revocable

SlopOS repeatedly pushes toward trusted UI, exact consent basis, durable receipts, and explicit review paths.
That means the prompt should not try to become a giant omnibar of authority.
Instead it should surface compact orientation facts with source and freshness posture, and route stronger moves into separately named review/help/open flows.

This is especially important for cloud/account/cluster/venv/ssh/repo state.
These are excellent prompt facts.
They are also exactly the kinds of facts that become dangerous when stale or silently sourced from helper code.

## 6) the clean import is one explicit prompt witness family

The companion-compatible import is to define a witness that can say:
- segment kind,
- data source family,
- startup footing,
- cwd/repo trigger posture,
- freshness posture,
- cost lane,
- and whether the segment is status-only or a gateway to a stronger explicit review route.

That is enough to keep the shell+terminal humane without making prompt-time helper topology part of the execution contract.

## 7) Compact conclusion

The strongest SlopOS pressure in this pass is:
**prompts may be luxurious orientation surfaces, but they must remain weaker than reviewed ground, weaker than explicit context activation, and weaker than exact execution authority.**

That is the right construction rule while both datacubes are still in design.
