# SlopOS datacube evaluation — 2026-03-23 — pass CLXXIV

**Schell should introduce one compact placement receipt, because SlopOS and the companion datacubes increasingly separate launch admission, context inheritance, restore class, and activation/focus residue instead of pretending that a requested landing is the same thing as realized present truth.**

## 1) SlopOS already warns against portable placement folklore

SlopOS's OpenURI launch-disposition boundary keeps generic launch from turning into a portable tab/window/task placement or reuse authority.
That is exactly the right pressure.
A requester can ask for useful things locally, but provider-local placement or reuse should not silently become portable substrate truth.

For Schell, that suggests a local explanatory object rather than a giant universal placement API.
A shell+terminal can stay luxurious while still saying: requested here, landed there, redirected for local reasons.

## 2) SlopOS exact launch basis still matters, but it does not answer layout questions

SlopOS keeps exact exec/cwd/env/startup closure small and explicit.
That remains the hard floor.
But exact launch footing is about what process starts with what reviewed basis.
It does not settle whether the result should appear in a split, a tab, a new window, an attached session, or a layout-only restore slot.

That means Schell needs one smaller layout-facing witness rather than broadening launch truth itself.

## 3) Steward already separates nearby context, spawn choice, and restore class

Steward's README and trajectory surfaces now explicitly call for:
- context inheritance for tabs, splits, reruns, and action-launched shells,
- explicit spawn selectors for program/profile/domain/cwd recipes,
- workspace snapshots that keep saved layouts, reconnected processes, revived processes, and content-only restores visibly distinct,
- and request-carried activation that stays separate from lifecycle truth.

That is almost a direct specification for a tiny Schell placement witness.
Requested landing, realized container, and restore/attach/revive class should stay separately named.

## 4) ViewFS and Harbor add the right pressure on identity and redirects

ViewFS keeps subject identity and carrier shape distinct, so Schell should avoid quietly equating “the thing” with “the tab/window/pane currently showing the thing.”
Harbor keeps stoplines and downgrade admissions explicit, which suggests placement mismatches should become visible redirect or downgrade residue rather than flattering magic.

## 5) Ward helps the receipt cool into historical residue

Ward's continuous-signal posture suggests first-frame placement explanation can later cool into a durable historical note without pretending it is still an active route command.
That is useful because restored or attached sessions will otherwise blur “how this landed then” with “where authority lives now.”

## 6) The companion-safe answer is one tiny placement receipt

The smallest good import is a **placement receipt** attached to newly landed or relocated room-like subjects.
It should say:
- what landing was requested,
- what landing was realized,
- whether the result matched, redirected, downgraded, attached, revived, or restored,
- whether arrival/activation/launch-sheet witnesses are linked,
- and what the strongest honest next move is now.

That object is enough to make the shell+terminal feel dramatically nicer while staying decision-light.

## 7) What this does not require Schell to decide yet

A placement receipt does **not** require Schell to decide:
- one universal pane/window/layout ontology,
- one cross-platform placement control plane,
- one global restore database,
- one provider-neutral guarantee that requested placement was honored,
- or one rule that current container identity becomes current subject authority.

## 8) Compact conclusion

SlopOS keeps portable placement/reuse authority narrow.
Exact launch footing still matters but does not answer layout questions.
Steward already separates context inheritance, spawn selection, and restore classes.
ViewFS keeps subject identity distinct from carriers, Harbor keeps redirects explicit, and Ward helps first-frame truth cool into honest residue.

So the next Schell move should be:

**add tiny placement receipts so tabs, splits, editor-area terminals, new windows, attached sessions, revived sessions, and restored layouts can confess requested-versus-realized landing without promoting provider-local placement into portable authority.**
