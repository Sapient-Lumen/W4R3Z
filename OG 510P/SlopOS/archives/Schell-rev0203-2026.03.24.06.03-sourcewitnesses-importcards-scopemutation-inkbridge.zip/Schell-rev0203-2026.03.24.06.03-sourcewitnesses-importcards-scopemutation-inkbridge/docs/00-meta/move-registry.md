# Move registry

This registry records **certified move classes** for Schell.
The point is not to bureaucratize shell design.
The point is to keep the archive honest about **what kind of transition** a revision is actually claiming.

## Certified move classes

- `MV-0001` — `read-reopen`
  - Meaning: re-enter the current archive head before claiming new progress.

- `MV-0002` — `research-cite`
  - Meaning: use current outside sources to pressure, sharpen, or challenge the archive while keeping only compact trace.

- `MV-0003` — `refine-compress`
  - Meaning: reduce entropy, sharpen a distinction, or compress repeated design pressure into one better canonical surface.

- `MV-0004` — `quarantine`
  - Meaning: keep an attractive but weakly supported idea live without laundering it into canon.

- `MV-0005` — `promote`
  - Meaning: elevate a previously loose pattern into canon with explicit wiring.

- `MV-0006` — `interaction-probe`
  - Meaning: define or prototype one concrete end-to-end shell interaction to test the design before freezing more language.

- `MV-0007` — `issue-receipt`
  - Meaning: update the compact revision receipt and aligned ledgers so the revision can be reopened honestly.

- `MV-0008` — `shadow-compare`
  - Meaning: preserve one nearby rejected move so the accepted path does not masquerade as inevitability.

- `MV-0009` — `hold-abstain`
  - Meaning: explicitly preserve a non-decision when current evidence is insufficient for a trustworthy ratchet.

- `MV-0010` — `package-handoff`
  - Meaning: emit a compact release object that future sessions can reopen as current trusted head.

- `MV-0011` — `question-advance`
  - Meaning: move one open question into a narrower, better-scoped state with a next proof surface and discharge rule.

- `MV-0012` — `hygiene-pass`
  - Meaning: add or tighten archive/repo checks so the bundle tells the truth about its own head, ledgers, and release surfaces.
