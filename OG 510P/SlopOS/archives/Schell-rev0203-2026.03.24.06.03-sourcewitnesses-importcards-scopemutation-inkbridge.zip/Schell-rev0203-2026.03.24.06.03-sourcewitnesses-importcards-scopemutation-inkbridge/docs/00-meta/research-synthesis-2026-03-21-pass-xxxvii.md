# Research synthesis, pass XXXVII (2026-03-21)

This pass focuses on one bounded seam that Schell did not yet give its own terminal surface:
**modern shells and terminals increasingly let programs write clipboards, bridge remote copy to the local host, keep internal paste buffers, and even copy richer payloads than plain text, which means Schell should steal the good parts without letting “copied” become one ambient authority story.**

## 1) xterm proves that terminal output can request a real host-side clipboard effect

The xterm control-sequence docs say `Ps = 52` manipulates selection data, may be disabled using `allowWindowOps`, and that the resulting data becomes the new selection available for pasting by other applications.
That is a foundational reminder for Schell:
ordinary terminal output is already capable of requesting a host-side clipboard mutation.

The design lesson is not “forbid all of this.”
It is: **clipboard write is a real egress effect, not just an innocent rendering detail.**

See: https://invisible-island.net/xterm/ctlseqs/ctlseqs.html

## 2) tmux usefully separates internal buffers from terminal clipboard writes

The tmux manual is unusually helpful here.
It documents `set-clipboard` as `on`, `external`, or `off`, and it distinguishes accepting clipboard escape sequences, attempting to set the terminal clipboard, and keeping tmux paste buffers.
It also documents `get-clipboard` modes and even a `pane-set-clipboard` hook.

That is an excellent concrete lesson for Schell:
copy is not one thing.
A mux-local buffer, a clipboard request, and a host clipboard write are nearby workflows, but they should stay separately named.

See: https://man7.org/linux/man-pages/man1/tmux.1.html

## 3) iTerm2 shows the value of explicit enablement, consent, and feature reporting

iTerm2's documentation says applications in the terminal may access the clipboard only if that setting is enabled.
Its OSC 52 docs then say user consent is required for both reading and writing the pasteboard.
Its feature-reporting spec adds another useful idea: terminals should not advertise `CLIPBOARD_WRITABLE` when the user has disabled it, though they may advertise it when support is conditional on consent.

That is a very good design pattern for Schell:
- capability discovery should reflect policy,
- clipboard access should respect user settings,
- and conditional support should remain visible rather than being flattened into “works” or “does not work.”

See: https://iterm2.com/3.4/documentation-one-page.html
See: https://iterm2.com/3.4/documentation-escape-codes.html
See: https://iterm2.com/feature-reporting/

## 4) kitty suggests a richer future without forcing Schell to freeze it now

kitty's clipboard docs say ordinary OSC 52 already exists for plain text, then introduce `OSC 5522` to support arbitrary data, permission-denied responses, MIME-type discovery, and explicit permission prompts before clipboard reads.
That is a brilliant hint for Schell.

The shell+terminal does not need a giant clipboard subsystem right now.
But it should leave room for a copy offer to hold more than one payload form and to distinguish between local copy preparation, permissioned external writes, and denied or unavailable richer egress.

See: https://sw.kovidgoyal.net/kitty/clipboard/

## 5) WezTerm confirms that clipboard capability is often asymmetric

WezTerm's escape-sequence docs say OSC 52 requests to query the clipboard are ignored, while setting or clearing the clipboard is allowed.
That is another useful reality check.
Terminal clipboard support is not always symmetric.
A terminal may allow write without read.

For Schell, that means a copy/export witness should be able to record exact support posture rather than pretending every terminal has one neat clipboard contract.

See: https://wezterm.org/escape-sequences.html

## 6) PowerShell shows a real modern remote-copy use case that Schell should learn from

PowerShell's `Set-Clipboard` docs say the `-AsOSC52` parameter was added in PowerShell 7.4 so that, when connected over SSH, text can be copied to the clipboard of the local machine rather than the remote machine, provided the terminal supports OSC 52.
That is one of the clearest current examples of a remote-to-local clipboard bridge as a first-class operator need.

Schell should steal that exact lesson:
**remote copy to local host is its own verb and should not be collapsed into an ordinary local copy success message.**

See: https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.management/set-clipboard?view=powershell-7.5

## 7) Qubes OS shows the strongest human-facing clipboard lesson: copy does not equal grant

Qubes documents a secure inter-qube clipboard where copying to the inter-qube clipboard and pasting into a chosen target are separate actions, and the inter-qube clipboard is cleared after delivery.
The docs say this gives precise control over which target receives the content and immediately wipes the inter-qube clipboard afterward.
They also warn that copying from a less trusted qube into a more trusted one is potentially insecure.

That is an outstanding lesson for Schell.
A great shell+terminal should not assume that because something was selected or copied, it has already been safely delivered everywhere it might later be pasted.

See: https://doc.qubes-os.org/en/latest/user/how-to-guides/how-to-copy-and-paste-text.html

## 8) A no-regret Schell import is visible now

A compact import could be:
- one **clipboard witness** object for exact copy/export truth,
- one **copy offer** posture that is weaker than external delivery,
- one explicit split between **local copy pack**, **system clipboard write**, **remote-local clipboard bridge**, and **share/export**,
- one **sensitive / auto-clear** posture for narrow egress,
- and one transcript-safe witness line for every stronger clipboard effect.

That is enough to learn a lot without choosing:
- a final clipboard backend stack,
- a final copy-history story,
- a final secret-wiping policy,
- or a final typed-payload protocol.

## 9) The lesson we must learn from the past

The old mistake was to treat the clipboard as harmless glue.
The newer mistake would be to treat every visible “copied” action in a smart terminal as though it had the same target, trust, and persistence semantics.

The better answer is:
- selection stays weaker than copy offer,
- copy offer stays weaker than system clipboard write,
- remote-local bridge stays separately named,
- sensitive copy stays explicit and often narrow,
- and share/export stays stronger than clipboard mutation.
