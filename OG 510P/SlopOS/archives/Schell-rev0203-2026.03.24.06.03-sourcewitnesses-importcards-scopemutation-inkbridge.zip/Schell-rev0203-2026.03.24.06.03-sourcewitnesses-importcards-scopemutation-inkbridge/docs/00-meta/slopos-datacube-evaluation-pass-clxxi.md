# SlopOS datacube evaluation — pass CLXXI

This pass asks a narrower and safer question than “should Schell let clicks, notifications, shortcuts, chooser accepts, and browser returns take focus and active control?”
The better question is:
**what is the smallest shell+terminal-local object that keeps exact target identity, transferred activation/focus hints, armed/prepared lanes, and actual active control visibly separate while SlopOS itself is still keeping activation boundaries narrow?**

## 1) SlopOS already keeps activation control narrower than target identity

The SlopOS OpenURI activation-control boundary keeps foregrounding, activation handoff, and focus steering shell/compositor-owned and explicitly refuses a portable `activation_token` or frontmost receipt story on the generic seam.
That means an open action and the right to raise/focus it are already different classes in the companion architecture.
Schell should preserve that distinction rather than laundering them back together in the terminal UX.

## 2) Steward already supplies the adjacent activation posture

Steward is even more explicit.
Its current posture says request-carried activation may include freshness-scoped attention or activation tokens, but those tokens remain advisory, one-shot, and clearly separate from lifecycle truth.
That is almost exactly the import Schell needs.
A wake ticket or shortcut may point at the right thing and carry a baton for focus/raise.
It still should not claim that the surface is active now or that lifecycle truth changed.

## 3) ViewFS sharpens the missing split

The new ViewFS RFC-0067 presses the separation further:
- gesture evidence,
- activation baton,
- armed/enabled state,
- active control,
- and receipt/history

should remain different classes.
This is the missing shell+terminal-local compression.
Fresh-intent witnesses explain current local volition.
Activation batons explain a transferable foreground request.
Armed rails explain prepared-but-not-active posture.
Those objects together are better than one vague `clicked` or `focused` myth.

## 4) Existing Schell seams improve the shape

- **Wake tickets** already keep alert, return, and acknowledgement separate; activation batons explain whether redeeming the ticket also carried a raise/focus request.
- **Fresh-intent witnesses** already protect stronger acts from history residue; activation batons keep foreground requests narrower than spend authority.
- **Launch sheets** already explain same-context inheritance; armed rails keep prepared helper lanes from overclaiming active control.
- **Witness packets** already carry compact footing; baton posture is another excellent carried field.

## 5) Harbor and Ward keep the failure mode honest

- **Harbor** keeps stoplines and risk ladders visible, which means `focus denied`, `armed only`, or `history only` are useful operator truths, not embarrassing edge cases.
- **Ward** keeps signal and status receivers continuous, which suggests baton residue should stay explainable after the toast, shortcut event, or browser callback has already passed.

## 6) Companion-safe no-regret moves

Schell still does **not** need a universal focus/foreground platform.
It only needs:
- a tiny **activation baton witness**,
- explicit `target exact` / `raise requested` / `active now` / `armed only` / `focus denied` posture,
- durable residue when a baton is refused or expires,
- and target-first / focus-second defaults.

Those moves import the companion pressure while staying reversible.

## 7) Compact conclusion

The companion cubes keep saying the same thing in different accents:
**knowing what exact thing we mean is not the same thing as proving that it now owns active control.**

So the Schell-safe answer is small:
**bind exact target identity, activation baton posture, armed/prepared state, and actual active control into one tiny visible shell+terminal object, and default to reveal/open first, focus second.**
That makes the custom shell+terminal nicer without freezing a giant cross-platform foreground-control treaty too early.
