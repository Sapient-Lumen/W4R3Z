# SlopOS datacube evaluation, pass CXVI (2026-03-22)

This pass evaluates one narrower question against the current companion archives:
**what do SlopOS and the nearby companion datacubes teach Schell about where shell memory is allowed to live once command frames, notebooks, workflows, replay capsules, and shared artifacts become first-class objects?**

The answer is crisp:
**memory should climb explicit residence ladders; it should not silently cross into sync, team share, or publication just because the shell got more helpful.**

## 1) SlopOS keeps descriptive artifacts weaker than live state

The current SlopOS companion keeps repeating one constitutional rule in many domains:
- CH-WALLET is descriptive rather than authoritative.
- Request identity is not current live grant state.
- Capture sessions remain manual, indicator-bound, and non-persistent.
- Local login/account mediation does not quietly become token/profile/session-state export.

That transfers cleanly to Schell.
A remembered command frame, notebook snippet, or workflow seed can be very useful.
It should still stay weaker than:
- current local authorship,
- current peer identity,
- current approval,
- current privacy posture,
- and current publication scope.

## 2) Background-request posture suggests saved object ≠ current permission

One of SlopOS's strongest nearby lessons is that a stable request key is not the same thing as current live portal-owned grant state.
That is an excellent shell lesson too.

A saved command, saved block, saved workflow, or saved notebook is not by itself proof that:
- the operator still wants it synced,
- the operator still wants it shared,
- the original peer is still the right one,
- or the original execution basis is still current.

Schell should therefore refuse any move where “saved once” quietly implies “still okay to replicate or publish.”

## 3) Capture posture suggests live sessions should not become hidden durable memory planes

SlopOS capture posture keeps live capture sessions explicit, manual, indicator-bound, and non-persistent.
That is a very strong neighboring reminder for terminal history.

Schell should be careful not to let:
- live observe lanes,
- attached session state,
- shared live panes,
- or transient replay buffers
quietly become a hidden durable memory substrate without a separately named promotion step.

## 4) Wallet posture suggests shared memory should carry footing hints, not power

Because CH-WALLET is descriptive only, a shared or synced shell object should likewise carry descriptive footing rather than revived authority.
For example, a remembered command might preserve:
- peer hint,
- cwd hint,
- lane hint,
- wallet-drift hint,
- publication hint,
- and imported/restored/synced posture.

That is enough to be useful.
It is much better than pretending the object still carries current power.

## 5) ViewFS and Steward reinforce residence badges and live-vs-historical separation

ViewFS keeps observe, attach, control, and historical surfaces distinct rather than calling all of them “the current session.”
Steward keeps trusted chrome and freshness posture visible.
Those companion pressures combine nicely here.

For Schell, the implication is simple.
A shell object should be able to say not only:
- what peer/lane it came from,
- but also whether it is:
  - local only,
  - restored,
  - synced personal,
  - copied into team memory,
  - link-published,
  - or exported.

That is the shell+terminal equivalent of good trusted chrome.

## 6) Companion-compatible no-regret move

Schell does **not** need to freeze one final sync backend, notebook stack, or collaboration service.
It only needs a few bounded rules:

### A) Distinguish residence from content
The same command frame may exist in different residences with different guarantees.

### B) Separate personal sync from team share from public publication
These are different power and residue stories.

### C) Make promotions explicit
Live/session/local memory should not silently become synced or published memory.

### D) Keep revocation posture visible
Delete local, unshare, invalidate link, and remove from team memory are different actions with different guarantees.

### E) Keep remembered/shared/exported objects weaker than fresh review
The shell can remember aggressively without pretending old or shared footing is still current authority.

## 7) Compact conclusion

The SlopOS-compatible answer is not “save more shell things everywhere.”
It is:
**let shell memory objects move through explicit residence ladders, badge their sync/share/publication posture honestly, and keep every remembered/shared/exported object weaker than fresh local review.**

That is a design-phase-safe move because it makes Schell much more powerful without forcing the final memory, sync, or collaboration architecture.
