# SlopOS datacube evaluation, pass XV

**The shell+terminal should treat command output as explicit braided evidence, not as one fake total log.**

This pass adds a new caution and a new opportunity.
The caution is that once Schell has shell-owned command boundaries, rich selection, pane trees, and reviewable actions, it becomes tempting to flatten everything back into one scrolling transcript and act as if the output had a single obvious total order and one obvious source.
The opportunity is that SlopOS already has the right ingredients for a much better answer: explicit stdio bindings, explicit non-authoritative artifacts, explicit ordering witnesses, and explicit outcome receipts.

## 1) SlopOS already treats stdio as an explicit bound seam

`CH-STDIO v0` does not treat stdin/stdout/stderr as inherited ambient terminal folklore.
It makes them explicit, typed, bound artifacts.
That matters because it means output already has a more exact birth story than "whatever happened to hit the terminal."

For Schell, that is a strong hint that the shell+terminal should not treat command output as undifferentiated scrollback.
At minimum, it should preserve:
- which command region the bytes belong to,
- which channel family they arrived on,
- and whether the bytes were directly witnessed, restored, inferred, or imported.

## 2) SlopOS also keeps stdio from becoming an authority tunnel

The capshell pipeline posture is equally important.
It says stdin/stdout/stderr are **data channels, not authority carriers**, and that cross-stage handoff must use explicit artifacts, explicit route messages, or explicit portal outputs.

That is a major lesson for Schell.
A shell+terminal should let people inspect output, select it, compare it, page it, freeze it, and route it into explicit follow-on actions.
It should not let rich output handling quietly become a hidden capability path or a magical "output implies authority" channel.

## 3) SlopOS ordering tokens suggest the right model for output honesty

RFC-0119 says required ordering should be:
- scoped,
- explicit,
- and receipt-visible.

That was written for non-commutative actions, but it transfers beautifully to terminal truth.
The terminal does not need one universal total-order mythology.
What it needs is a way to say:
- per-channel order is strong here,
- cross-channel order is only known up to a bounded merge witness,
- and this transcript block was rendered with a named braid/merge posture rather than pretending there is one natural truth everywhere.

## 4) Receipts and logs are adjacent but not identical to live output

SlopOS keeps outcome receipts, logs, and request/live-state posture separate.
That separation should survive in Schell too.
A command may have:
- live streaming bytes,
- a shell-owned exit/status witness,
- a review/denial surface,
- a later frozen output capsule,
- and a transcript slice.

Those are related.
They are not interchangeable.
A finish badge is not the output.
A transcript slice is not the same thing as a live region.
A pager view is not the same thing as the exact durable receipt.

## 5) DelayBasin makes the missing process lesson sharper

DelayBasin keeps warning against silent overclaim.
Its execution-witness, basis-witness, followthrough-witness, and reasoning-firebreak surfaces all push the same discipline:
- say what was directly witnessed,
- say what is derivative,
- say what is blocked or withheld,
- and do not let a compressed recap quietly replace the source packet.

For Schell, that means output handling should preserve the difference between:
- exact captured bytes,
- shell-authored status or diagnostic notes,
- terminal-local merge/render decisions,
- and later summaries or extracted snippets.

## 6) The new Schell object should probably be an output capsule plus a braid witness

A promising small import is a pair:

### Output capsule
A compact shell-owned object that can say:
- which command or lane it belongs to,
- which channel families are present,
- what exact byte witnesses or digests back it,
- what truncation or gap posture applies,
- and what summary facts are safe to surface quickly.

### Braid witness
A compact witness that says:
- what ordering is exact,
- what merge posture produced the visible interleaving,
- whether timestamps/arrival order/shell marks were used,
- and what ambiguities remain.

This is a better answer than one perfect transcript mythology and a better answer than giving up on structure entirely.

## 7) Great product moves are available here too

This is not only a safety pass.
It is also a product pass.
Once output capsules and braid witnesses exist, Schell can do delightful things without lying:
- exact "open last command output" and "open stderr only" views,
- compare panes bound to two exact output capsules,
- transcript-visible truncation/gap badges,
- explicit background-residue capsules,
- freeze/export by digest instead of copy-paste folklore,
- and local merge toggles that say what they are doing.

That is a path to "super awesome" that still respects transcript truth.

## 8) What stays open

This pass still refuses to decide:
- final on-disk output-capsule schema,
- whether frozen outputs become CH-AREF-backed sidecars, native shell objects, or both,
- whether timestamps are authoritative, advisory, or absent in v0,
- final pager/export UX,
- and any full-blown binary logging pipeline.

That is deliberate.
This is a no-regret posture pass, not a logging stack freeze.
