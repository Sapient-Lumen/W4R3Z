# SlopOS datacube evaluation, pass CXXVI (2026-03-22)

This pass evaluates one narrower question against the current companion archives:
**what do SlopOS, Steward, and ViewFS teach Schell about terminal identity claims, terminfo drift, and version humility?**

The answer is crisp:
**terminal identity should stay descriptive until current-path behavior is freshly proved.**

## 1) SlopOS keeps descriptive objects weaker than present authority

The SlopOS companion keeps repeating a constitutional rule in many domains:
- wallets are descriptive and non-authoritative,
- request identity is weaker than present capability,
- imported evidence is weaker than current local admission,
- and call-chain metadata can narrow or explain but not grant.

That transfers directly to terminal identity.
A terminal brand string, version reply, env hint, or relay-side rewrite is useful descriptive metadata, but it should not independently grant stronger shell+terminal power.

## 2) SlopOS capability wallets argue for identity cards, not ambient trust

Capability wallets are valuable precisely because they summarize footing without becoming footing.
Schell should borrow that posture for terminal identity:
- summarize the current terminal claim stack,
- show where the claim came from,
- but keep strong feature unlocks tied to observed behavior or explicit shell-owned witnesses.

That is the companion-safe way to steal modern terminal luxury without ambient folklore.

## 3) Privilege bracketing and call-chain posture argue for source-labeled terminal claims

SlopOS's privilege-bracketing and call-chain work pressures systems to say which context produced a claim and which context is allowed to act on it.
For Schell, that implies:
- local terminal claims,
- remote-host fallback claims,
- tmux relay claims,
- shell-integration claims,
- and observed specimen claims
should not flatten into one badge.

They are different sources with different trust and action posture.

## 4) Steward keeps trusted chrome freshness-scoped

Steward's label and trusted-chrome pressure says an attractive badge should confess freshness, source, and downgrade posture.
That is exactly the right nearby lesson for terminal identity.
A shiny `ghostty` or `wezterm` pill should still say whether the claim is:
- env-only,
- query-derived,
- relay-rewritten,
- fallback-only,
- or specimen-proved on this path.

## 5) ViewFS keeps lanes and locality separate

ViewFS repeatedly rewards lane separation instead of one flattering connected-state myth.
Terminal identity has the same problem.
The local GUI terminal, the mux, the SSH hop, the remote pty, and the shell-integration helper are different lanes.
Schell should preserve that.

## 6) Companion-compatible no-regret move

Schell does **not** need a final universal terminal detection stack yet.
It only needs a few bounded rules:

### A) Keep claim families separate
`TERM`, terminfo, env hint, query reply, relay override, observed specimen.

### B) Keep descriptive identity weaker than current proved behavior
Names help; specimens unlock.

### C) Keep locality visible
Local terminal, mux relay, remote host fallback, shell helper.

### D) Keep disagreement explicit
When brand, terminfo, env, and observed behavior disagree, say so instead of flattering the operator.

## 7) Compact conclusion

The companion-safe answer is not “detect the terminal and trust the badge.”
It is:
**build a descriptive identity card with visible source and locality, then let stronger terminal luxury unlock from fresh behavior proofs rather than folklore.**
