# SlopOS datacube evaluation — 2026-03-24 — pass CXCVI

**Schell should treat history shorthand as a local recall-and-edit helper rather than as hidden reviewed truth, because SlopOS and the companion cubes keep rewarding exact basis, locality labels, visible revalidation, omission honesty, and neighboring-state separation.**

## 1) SlopOS keeps exact reviewed basis narrower than helper-local memory

SlopOS repeatedly keeps provider-local state and helper packaging weaker than exact reviewed request basis and weaker still than later immutable receipt truth.
History shorthand should behave the same way.
A cited old command, last-argument reuse, or modifier-based substitution may be very useful, but it should still be weaker than the exact reviewed command basis and weaker than the later spend receipt.

So the companion-safe import is:
- history recall may help,
- it may even be rich and fast,
- but exact reviewed spend still needs its own explicit witness lane.

## 2) SlopOS plumb posture again argues for suggest / inspect / admit / compare

Request-local plumb posture is a very nearby lesson.
History shorthand surfaces should be excellent at **suggest / inspect / admit / compare**.
They should be much more cautious about silently turning historical memory into present command truth.

That means a recall surface can be rich, but it should confess:
- which earlier event is being cited,
- whether the source came from current session or merged/shared history,
- which words/modifiers are in play,
- whether the result is merely inserted for editing,
- and whether later spend happened as shown or only after further edits.

## 3) Provider-locality pressure says shared history is not present command truth

The newer SlopOS boundary work keeps reasserting that provider-owned/local packaging should not quietly become portable archive truth.
History storage and history search deserve the same treatment.
A shared history file, merged-late recall hit, or restored command memory should not quietly become the command's durable reviewed truth.
Otherwise local memory posture becomes a hidden second authority plane.

## 4) ViewFS again supplies the best neighboring-state discipline

ViewFS keeps editable text, parse understanding, diagnostics, compiled packets, prepared actions, and history distinct.
That same discipline should govern history shorthand:
- typed recall token,
- cited source event,
- realized expanded line,
- editing buffer state,
- admitted reviewed command,
- and later spend receipt

should remain neighbors rather than collapsing into one flattering “the shell knew what I meant again” object.

## 5) Harbor, Ward, Steward, and Helm keep the seam honest

- **Harbor** reinforces label honesty, which matters when Schell should say whether a line came from `last-arg`, `slice`, `prefix-hit`, `modifier-chain`, or a shared-history source.
- **Ward** reinforces revalidation pressure, which matters when recalled commands refer to older cwd/env/object footing and may need a fresh compare before stronger review.
- **Steward** reinforces trim/freshness posture, which matters when shared history is merged late, compacted, or only partially available.
- **Helm** reinforces omission and miss posture, which matters when a shorthand fails, a search hit is ambiguous, or a history surface shows only the realized line while omitting its source event.

Together they keep one rule sharp:
**history shorthand can improve comfort, but it must not erase labels, locality, omitted-source honesty, or exact reviewed basis.**

## 6) What this still does not require Schell to decide

This seam does **not** require Schell to decide:
- one final history-substitution grammar,
- one final compatibility layer for bash/zsh bang-history,
- one final shared/local history backend,
- one final event-id scheme,
- one final modifier language,
- or one final history export format.

The archive only needs to prove the honesty stack that says:
- what exact shorthand was typed,
- what exact source event was cited,
- what words/modifiers were selected,
- what line was realized into the editor,
- what exact command basis was later admitted,
- and what later receipt confirms or contradicts that basis.

## 7) Compact conclusion

SlopOS keeps exact basis narrow and explicit.
ViewFS keeps neighboring states separate.
Harbor, Ward, Steward, and Helm keep labels, freshness, omission, and revalidation honest.

So the next Schell move should be:

**add history substitution witnesses, event-designator reveals, source-locality labels, dual-view recall rows, and re-edit posture so Schell can steal historical shell speed without letting old memory quietly become reviewed truth.**
