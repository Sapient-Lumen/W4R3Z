# SlopOS datacube evaluation — pass CLXIX

This pass asks a smaller and safer question than “should Schell have better duplicate-tab, split-here, and helper-here affordances?”
The better question is:
**what is the smallest preflight object Schell can add so convenience spawn stays luxurious without violating SlopOS exact-launch footing or Steward's explicit context-inheritance posture?**

## 1) SlopOS keeps forcing the comparison against fresh exact launch

D-CAPSHELL keeps the launch floor exact:
- exact exec selector,
- exact executable object,
- exact startup code closure,
- exact child env posture,
- exact cwd-root posture,
- and refusal of ambient runtime/session folklore.

That means a same-context convenience spawn should not be allowed to flatter itself into “the same launch again.”
The right comparison point is always:
- what a fresh exact launch would mean,
- versus what this convenience fork is actually inheriting.

## 2) Steward already provides the adjacent shape

The Steward companion is especially aligned here.
Its context-inheritance and spawn-selector posture docs already argue that:
- inheritance is an explicit action choice rather than ambient truth,
- cwd inheritance and domain inheritance should stay separate,
- current, reported, and remembered context should stay distinguishable,
- policy can deny or trim inheritance,
- and fallback should fail honest instead of pretending exact inheritance succeeded.

That is almost exactly the object Schell now needs.

## 3) The companion-safe answer is one tiny launch sheet

The smallest useful import is a **launch sheet** for high-value convenience spawn.
It should say:
- what action was requested,
- what source anchor it used,
- which fields followed,
- which fields were dropped or defaulted,
- which fields are only current-reported or remembered,
- whether the result is forked footing rather than fresh exact launch,
- and what the clean fresh alternative would do instead.

That is enough honesty without a giant launcher treaty.

## 4) ViewFS and Foundry improve the sheet shape

- **ViewFS** keeps compare-current-basis posture explicit, which is exactly the right pressure for an inherit diff.
- **Foundry** keeps overlay/config drift exact, which means the sheet should be able to confess when the source footing changed since review.

A convenience spawn that followed cwd but crossed overlay drift should say so.
That is a real trust win.

## 5) Harbor and Helm keep stronger acts narrower than convenience

- **Harbor** keeps risk ladders visible, so stronger convenience acts should still advertise stoplines.
- **Helm** keeps settlement narrower than launch success, so opening “another one here” should not imply that the source is still healthy, endorsed, or complete.

That means the launch sheet should stay about footing, not flattery.

## 6) Companion-safe no-regret moves

Schell does **not** need a huge workspace/launcher/session constitution next.
It only needs:
- a same-context launch sheet for high-value convenience spawns,
- per-lane inherit diffs,
- first-frame launch-source badges,
- exact fallback toasts,
- and a fresh-instead choice that is as cheap as fork-nearby.

Those moves import SlopOS discipline while staying reversible.

## 7) Compact conclusion

The companion cubes keep saying the same thing in different accents:
**inherited convenience is useful, but it is not self-proving launch truth.**

So the Schell-safe answer is small:
**compare convenience spawn against fresh exact launch in one tiny launch sheet, label current/reported/remembered posture honestly, and keep fresh-instead parity visible.**
That gets the shell+terminal much closer to “super awesome” without forcing early closure on launcher grammars, clone formats, or cross-platform inheritance constitutions.
