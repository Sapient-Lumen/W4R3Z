# SlopOS datacube evaluation — pass CLXX

This pass asks a narrower and safer question than “should Schell let stronger convenience verbs run from clicks, hotkeys, wake tickets, and remembered chapter rows?”
The better question is:
**what is the smallest shell+terminal-local object that proves one current local human gesture still authorizes one exact stronger act without turning Schell into a giant approval-token or trusted-UI platform?**

## 1) SlopOS still forbids ambient spend folklore

D-CAPSHELL keeps the launch floor exact:
- exact exec selector,
- exact executable object,
- exact child env posture,
- exact cwd-root posture,
- and refusal of ambient startup/session folklore.

That means visible chapter rows, callback residue, remembered helper offers, and wake tickets cannot quietly promote themselves into spend authority merely because they are nearby.
A present local act still needs present local footing.

## 2) Steward already provides the adjacent shape

The Steward companion is the clearest pressure source here.
Its fresh-intent posture says:
- fresh intent is evidence, not ambient authority,
- one gesture binds one exact reviewed action summary,
- freshness and consumption stay visible,
- old transcript frames and remembered rows must not recreate it,
- and remote or automation callers stay separate by default.

That is almost exactly the seam Schell needs for the strong end of shell+terminal convenience.

## 3) The companion-safe answer is a tiny fresh-intent witness

The smallest useful import is a **fresh-intent witness** that can accompany stronger convenience verbs.
It should say:
- what exact action summary it binds,
- what local gesture produced it,
- what local context it belongs to,
- whether it is fresh, consumed, expired, wrong-context, or ignored,
- and what downgrade floor remains honest when it is gone.

That is enough honesty without a giant consent stack.

## 4) Existing Schell seams improve the shape

- **Launch sheets** already show what followed and what degraded. A fresh-intent witness is the clean final guard for choosing fork-nearby anyway.
- **Wake tickets** already separate alert, return, and acknowledgement. Fresh-intent keeps a clicked alert from quietly becoming spend.
- **Replay leases** already remember bounded prior review. Fresh-intent keeps remembered permission separate from current local volition.
- **Drift cards** and **footing strips** already explain changed footing. Fresh-intent helps the shell say when the footing may be understood but still not freshly meant.

## 5) Harbor, ViewFS, and Helm keep the strong end narrow

- **Harbor** keeps stoplines and risk ladders visible, which fits exactly with fresh-intent gating the stronger end of convenience.
- **ViewFS** keeps reveal, attach, and apply distinct, which means Schell can keep reveal cheap while reserving fresh-intent for apply/spend acts.
- **Helm** keeps settlement narrower than surface success, which means neither presence nor recentness should impersonate current spend readiness.

## 6) Companion-safe no-regret moves

Schell does **not** need a universal permission platform next.
It only needs:
- a tiny fresh-intent witness family,
- visible `fresh` / `spent` / `expired` / `wrong-context` posture,
- one-gesture one-spend humility for strong acts,
- and cheap downgrade to inspect / stage / review again.

Those moves import SlopOS discipline while staying reversible.

## 7) Compact conclusion

The companion cubes keep saying the same thing in different accents:
**remembered footing and present local intent are different things.**

So the Schell-safe answer is small:
**bind one current local gesture to one exact stronger action summary, make consumption and expiry visible, and cool gracefully to inspect/stage/review when the witness is gone.**
That gets the shell+terminal closer to “super awesome” without forcing early closure on trusted-UI backends, shortcut treaties, or global approval caches.
