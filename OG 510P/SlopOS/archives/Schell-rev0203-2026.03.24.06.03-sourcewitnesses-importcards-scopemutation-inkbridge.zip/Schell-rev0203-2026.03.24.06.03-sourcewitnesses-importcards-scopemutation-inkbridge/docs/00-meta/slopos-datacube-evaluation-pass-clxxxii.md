# SlopOS datacube evaluation — 2026-03-23 — pass CLXXXII

**Schell should introduce tiny anchor-survival strips and anchor-death cards, because the companion datacubes increasingly separate exact reviewed basis, continuation cursors, reset-required posture, and weaker surviving residue instead of pretending that old anchors silently stay current just because some text or layout came back.**

## 1) SlopOS keeps old reviewed basis from silently following newer mutable state

SlopOS still keeps the reviewed basis exact.
That posture matters here because when a review watermark or first-unseen anchor dies, the shell+terminal should **not** quietly remap it to a newer boundary and pretend continuity survived.

The companion-safe carry-forward is:
- exact historical anchors remain useful evidence,
- mutable current state remains its own stronger truth,
- and dead anchors should emit reset/refresh guidance rather than silently inheriting new basis.

## 2) Steward already wants reset-required honesty more than comforting continuity

Steward's current pressure already separates:
- snapshot-plus-change from one flattened latest view,
- caught-up posture from silent optimism,
- restoration from current runtime truth,
- and reset-required cases from fake continuity.

That makes **anchor survival posture** the natural next shell+terminal import.
Review watermarks and first-unseen anchors are useful, but they need a tiny witness saying whether they still survive exact, survive approximately, or died because retention/reset/source-expiry boundaries were crossed.

## 3) ViewFS gives the clearest companion pressure: continuation cursors and gap/reset verdicts stay explicit

ViewFS's current inspiration map is very direct:
continuation cursors, sync watermarks, rebuilt snapshots, and gap/reset verdicts should stay visibly distinct rather than collapsing into one magical live-query token.
That is almost exactly the pressure Schell needs here.

A preserved command card or watch lane should be able to say:
- the old review anchor survives exact,
- the old anchor survives only approximately,
- the old anchor died but historical residue survives,
- or relist/reopen/start-fresh is required.

That is a much more companion-safe story than generic `resume unavailable` text.

## 4) Ward, Harbor, and Helm all reinforce explicit death and fallback scope

- **Ward** keeps continuous signals and attenuation/residue distinct, which argues that `anchor dead` and `no later change` should never collapse into one state.
- **Harbor** keeps risk ladders visible, which argues that dead anchors should lower the action floor to inspect/refresh/reopen instead of quietly permitting stronger nearby actions.
- **Helm** keeps settlement narrower than local success, which argues that surviving text or layout residue must stay weaker than surviving exact footing.

Together they point to one tiny shell+terminal import:
**keep weaker residue useful, but make anchor death and reset scope explicit.**

## 5) What this does not require Schell to decide yet

Anchor-survival strips and death cards do **not** require Schell to decide:
- one universal watch protocol,
- one global transcript store,
- one final replay engine,
- one collaborative read-state service,
- or one shared continuity ontology for every room, card, lane, and provider.

The archive only needs to prove the tiny honesty object that says whether an old anchor is still exact, what killed it when it is not, what residue still survives, and what reset scope now applies.

## 6) Compact conclusion

SlopOS keeps reviewed basis exact and current mutable state separate.
Steward keeps snapshot/change/restore/reset honesty visible.
ViewFS keeps continuation cursors, rebuilt snapshots, and gap/reset verdicts distinct.
Ward, Harbor, and Helm reinforce explicit residue/risk/settlement posture.

So the next Schell move should be:

**add tiny anchor-survival strips and anchor-death cards so review watermarks, first-unseen anchors, hidden-terminal returns, restored rooms, and watch lanes can confess whether the old anchor still survives, what exact retention/reset/expiry event killed it when it does not, what weaker residue still remains, and what reset path is honestly required now — without silently remapping old review posture onto newer basis.**
