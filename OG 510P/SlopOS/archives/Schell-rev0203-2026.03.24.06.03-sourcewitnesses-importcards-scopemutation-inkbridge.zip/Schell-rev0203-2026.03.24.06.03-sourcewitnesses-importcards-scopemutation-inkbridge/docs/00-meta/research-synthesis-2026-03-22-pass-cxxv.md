# Research synthesis, pass CXXV (2026-03-22)

This pass keeps one narrower lesson explicit:
**remote↔local file movement should be treated as a transfer bridge with explicit landing zones and archive posture, not as generic copy or path insertion.**

The current ecosystem converges on that lesson from several directions.
kitty's file-transfer tooling can move files, directory trees, and links over the TTY itself, preserve metadata, optionally use delta transfer, and asks for confirmation before local read/write is allowed.
iTerm2 exposes `it2dl` and `it2ul` over ssh, has a proprietary file-transfer escape family that can transfer files over arbitrary transports, and added multipart chunking specifically to work in tmux integration mode.
VS Code's shell-integration docs are also a useful contrast: automatic shell integration does not simply carry through plain ssh sessions, which is a reminder that not every remote luxury should be modeled as “ordinary shell integration worked.”

Taken together, the design-phase lesson for Schell is straightforward:

## 1) File transfer is a separate bridge family

Path insertion, clipboard mutation, remote upload, remote download, local import, and durable publication are all different moves.
They may look adjacent in a terminal UI, but they should not share one flattering result label.

## 2) Landing zone is part of the truth

Where a file lands matters.
Downloads folder, current directory, chosen directory, review object, temporary copy, or remote destination write are different outcomes.
Schell should preserve that in the transfer receipt instead of burying it in helper behavior.

## 3) Archive posture matters

Single-file, directory-tree, metadata-preserving, wrapped tarball, and delta-capable transfer are different shapes.
That shape should survive into the UI and transcript as explicit posture.

## 4) Confirmation is not UI sugar

kitty's confirmation prompt and bypass warning are especially important here.
If a remote program is about to read or write the local filesystem, then approval posture is part of the authority story.
The shell+terminal should keep that explicit.

## 5) Relay/chunk posture belongs in the model

iTerm2's multipart mode for tmux integration is a particularly good reminder that transfer support does not mean one uniform path.
Different relays reshape the bridge.
Schell should therefore preserve whether transfer was direct, helper-mediated, relayed, multipart, archive-wrapped, or degraded.

## 6) Compact answer

Schell does **not** need to choose one universal file-transfer protocol next.
It needs one bounded move:
- a transfer-bridge witness,
- named landing zones,
- explicit archive posture,
- confirmation and relay confession,
- and stronger promotions staying separate from ordinary transfer completion.
