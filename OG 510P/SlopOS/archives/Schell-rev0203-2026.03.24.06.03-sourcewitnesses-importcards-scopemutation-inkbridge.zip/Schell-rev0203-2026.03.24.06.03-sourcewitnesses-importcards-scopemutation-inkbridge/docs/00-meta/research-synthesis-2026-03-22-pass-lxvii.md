# Research synthesis, pass LXVII (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should absolutely steal explicit credential/identity footing, escalation ladders, and file-creation-mask honesty — but only if caller identity, target identity, groups, user-namespace mappings, `umask`, and post-launch privilege state stay separately named instead of collapsing into one flattering “this command is basically root now” story.**

This seam matters because old shells still treat identity and file-creation footing as strangely ambient.
A command often inherits the current user, effective user, supplementary groups, default `umask`, environment policy, and namespace mapping without any of that appearing in the review surface.
When an edit lands with the wrong ownership, a privileged helper sees the wrong groups, or a file is created more broadly than expected, the operator ends up diffing `sudoers`, `doas.conf`, `umask`, namespace state, and launcher policy after the fact.
That is exactly the sort of shell+terminal seam Schell can improve without choosing one final elevation stack, token broker, or namespace substrate.

## 1) POSIX and Bash prove file-creation footing belongs to the shell execution environment

The current POSIX `umask` utility entry says `umask` affects the current shell execution environment and is therefore generally provided as a shell regular built-in.
The current Bash command-execution-environment docs say the file-creation mode mask is part of the shell execution environment, may be inherited from the shell's parent, and is then part of the separate execution environment for an executed command unless changed.
That is a big Schell clue.
File-creation posture is not a hidden implementation detail.
It is shell meaning.
See: https://pubs.opengroup.org/onlinepubs/9799919799/utilities/umask.html and https://www.gnu.org/software/bash/manual/html_node/Command-Execution-Environment.html

## 2) sudo and doas prove environment and target-identity policy must be explicit

The current `sudoers(5)` docs say `env_reset` is enabled by default, which means commands run with a new minimal environment; `HOME`, `MAIL`, `SHELL`, `LOGNAME`, and `USER` are initialized from the target user, while `SUDO_*` variables are set from the invoking user.
The current OpenBSD `doas.conf(5)` docs separately make `keepenv` and `setenv` explicit policy terms, and they advise using absolute paths when specifying commands.
That is an excellent Schell clue.
Good privilege transitions are policy-shaped and explicit about target identity, environment carry-over, and command identity.
They are not mere “rerun this with more power” folklore.
See: https://man7.org/linux/man-pages/man5/sudoers.5.html and https://man.openbsd.org/doas.conf

## 3) sudoedit proves there should be a safer edit rung than “run the whole editor as root”

The current `sudoedit(8)` docs say the editor is run with the invoking user's environment unmodified, and they document explicit safety checks around symbolic links, writable parent directories, device special files, and temporary-file installation behavior.
That is exactly the kind of narrow luxury Schell should steal.
A custom shell+terminal should have a visible “elevated writeback edit” rung that is weaker than “launch an entire privileged interactive editor/session”.
See: https://man7.org/linux/man-pages/man8/sudoedit.8.html

## 4) setpriv and no_new_privs prove groups and post-exec privilege state must stay named

The current `setpriv(1)` docs say `--no-new-privs` prevents `execve(2)` from granting new privileges, including set-user-ID, set-group-ID, and file-capability-based gain, and also say that if you set a primary GID you must explicitly choose one of `--clear-groups`, `--groups`, `--keep-groups`, or `--init-groups`.
The current Linux kernel `no_new_privs` docs explain the underlying reason: `execve` can grant a newly started program privileges its parent did not have unless this is blocked.
That is a very useful Schell lesson.
Supplementary groups, privilege-gain posture, and one-way no-new-privilege state should not be hidden inside launcher trivia.
See: https://man7.org/linux/man-pages/man1/setpriv.1.html and https://docs.kernel.org/userspace-api/no_new_privs.html

## 5) User namespaces prove numeric identity itself can be remapped and must not be romanticized

The current `user_namespaces(7)` docs say a new user namespace begins without UID/GID mappings, that `uid_map` and `gid_map` define how IDs are mapped, that file-permission checks map process IDs into the initial user namespace, and that `setgroups(2)` may be permanently disabled in a user namespace to permit `gid_map` writes without parent-namespace `CAP_SETGID`.
That is a huge anti-folklore clue.
The number a process sees as its UID/GID is not sufficient shell truth by itself.
Mapped identity, group posture, and namespace ownership matter.
See: https://man7.org/linux/man-pages/man7/user_namespaces.7.html

## 6) run0 proves fresh execution context is a stealable pattern, but not a universal ontology

The current `run0(1)` docs say it serves a similar purpose to `sudo`, but one key difference is that no execution or security-context credentials are inherited from the caller because the invoked command runs from a fresh isolated service forked off by the service manager.
That is a very attractive Schell import.
It suggests a reviewed shell can explicitly name when an escalation or user-switch lane is based on a fresh isolated launch rather than caller inheritance.
But it should still avoid prematurely standardizing one service-manager-specific ontology as the portable answer.
See: https://man7.org/linux/man-pages/man1/run0.1.html

## 7) The dangerous flattenings to refuse

The current ecosystem keeps inviting at least eight mistakes:
- treating “current user” as enough truth when effective user, target user, groups, and namespace mappings can differ,
- treating an elevated edit as equivalent to running the entire editor with elevated privilege,
- treating caller environment carry-over as harmless when policy tools make it explicit for a reason,
- treating `umask` as a host default instead of a reviewed execution footing,
- treating supplementary groups as benign residue rather than authority-bearing state,
- treating a user-namespace UID/GID number as globally meaningful identity,
- treating `no_new_privs` and file-capability posture as host trivia rather than launch truth,
- and treating one platform's elevation tool (`sudo`, `doas`, `run0`, namespace wrappers) as Schell's final universal privilege plane.

Schell should refuse those moves.
A command should be able to say, separately:
- what executor identity basis it is using,
- whether target identity differs from caller identity,
- what supplementary-group posture applies,
- what `umask` / file-creation footing applies,
- whether launch can still gain privilege across `exec`,
- whether identity is namespace-mapped,
- and what bounded historical identity/creation receipt can honestly be emitted afterward.

## 8) The stealable move: credential witnesses, escalation ladders, and umask humility

The best decision-light move now looks like this:
1. add a **credential witness** family for reviewed launch posture,
2. keep **caller identity** separate from **executor identity** and **target identity**,
3. keep **supplementary-group posture** separately named,
4. keep **namespace-mapping posture** separate from plain UID/GID rendering,
5. keep **umask / file-creation footing** visible at review time,
6. keep **elevated writeback edit** separate from **privileged interactive session**,
7. distinguish **no-new-privileges posture** from **historical execution receipts**,
8. and refuse to standardize one giant cross-platform run-as / elevation grammar too early.

That would make Schell feel dramatically more capable while preserving the archive's current decision throttle.

## 9) A compact first proving slice

A compact proof could show:
- one reviewed launch card with explicit executor-identity badge,
- one target-identity witness separating caller, executor, and requested target,
- one group witness that says clear / keep / explicit / unknown,
- one namespace-mapping badge that confesses whether numeric IDs are host-basis or remapped,
- one `umask` witness that says explicit, provider-fixed, inherited compat, or unknown,
- one elevated-edit rung that is clearly weaker than full privileged interactive launch,
- one no-new-privileges badge that stays weaker than a full capability browser,
- one historical identity/creation receipt with bounded facts,
- and one refusal to treat a stale prompt badge as current credential truth.

That is enough to make Schell feel super awesome at identity/creation truth without freezing the final elevation backend, user-switch grammar, token model, or namespace substrate.

## 10) Decisions intentionally kept open

This pass does **not** freeze:
- one universal credential schema for every host/runtime,
- one portable “run as” or privilege-elevation grammar,
- one final user/token broker or policy backend,
- one universal user-namespace ontology,
- one final ownership/ACL/permission inspector stack,
- or one universal historical identity receipt schema.

The no-regret move is smaller:
**steal reviewed credential witnesses, explicit escalation ladders, and file-creation-mask honesty — but keep caller identity, target identity, group posture, namespace mapping, `umask`, privilege-gain posture, and historical receipts visibly separate.**
