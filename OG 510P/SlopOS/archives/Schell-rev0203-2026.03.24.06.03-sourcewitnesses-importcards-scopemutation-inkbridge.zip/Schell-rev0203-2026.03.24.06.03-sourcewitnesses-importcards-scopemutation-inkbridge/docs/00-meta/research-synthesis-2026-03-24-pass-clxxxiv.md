# Research synthesis — 2026-03-24 — pass CLXXXIV

This pass sharpens one smaller lesson from current shells, terminals, and prompt-marking work:
**the next prompt breakthrough is not prettier theming; it is treating prompt/input/output as regions with roles instead of rows with vibes.**

## 1) The historical substrate already pointed at regions

iTerm2's documentation of the old FinalTerm escape family is still one of the clearest reminders that prompt, entered command, and command output were always meant to be semantically distinct spans.
Contour's OSC 133 writeup keeps the same shape explicit: prompt start, prompt end, command output start, command finished, plus optional click-events and command-line metadata.
The important lesson is not protocol nostalgia.
It is that shell+terminal quality begins when the terminal knows which visible areas belong to which phase of the command chapter.

## 2) The current ecosystem is exposing where row-based assumptions break

Ghostty 1.3 and 1.3.1 are especially revealing.
They improve click-to-move in shell prompts, jump-to-prompt, and copy-command-output behavior, but the patch notes also talk about dynamic prompt rebuilds, multiline `PS1` prompts with command substitutions, vi-mode redraws, and forward navigation through multiline prompts.
That is exactly the kind of evidence Schell should learn from early.
The failure mode is not “prompt marks are bad.”
The failure mode is **thinking one row equals one prompt truth**.

kitty's shell-integration notes are similarly helpful because they explicitly distinguish prompt start from secondary-prompt start and even carry prompt-local behavior flags.
Nushell 0.111 then adds a stronger clue by calling out primary prompts, right prompts, and continuation prompts separately while enabling click-events in semantic-prompt-aware terminals.
fish 4.5 reinforces the same trajectory: click-events are useful precisely because the terminal and shell agree on where the current editable command line actually is.

## 3) The best “super awesome” move is geometry honesty, not more magic

Several existing luxuries become much safer once prompt geometry is first-class:
- click-to-move in the active prompt,
- sticky command headers,
- jump-to-prompt,
- copy one command's output,
- and multiline command recall.

VS Code's command guide and sticky scroll are strong product proof here.
They work because command-local boundaries exist.
The missing next layer for Schell is to keep multiline chapter geometry explicit so these luxuries bind to a chapter region instead of to a guessed line.

## 4) The brilliant ideas worth stealing are surprisingly bounded

A compact stack is emerging:
- **prompt-region witnesses** that distinguish primary, right, continuation, editable-input, output, and historical-repaint regions,
- **continuation cards** for multiline or incomplete input,
- **truncated-but-faithful sticky chapter headers** that admit truncation explicitly,
- **region debug overlays** for implementers,
- and **geometry canaries** for multiline prompt rebuild, command substitution, vi-mode redraw, and resize behavior.

These are brilliant because they improve a lot without forcing Schell to freeze a final line editor, final prompt DSL, final remote treaty, or final protocol family.

## 5) The past lesson Schell must not ignore

The old temptation in shells was to flatten everything into prompt folklore:
- the visible prompt line equals the editable input,
- the wrapped line equals continuation,
- the right prompt is decorative and therefore irrelevant,
- the sticky header can summarize from a line scrape,
- and rebuilt prompt residue is close enough to live truth.

Current docs are effectively warning against all of that.
Schell should retain one clean rule:
**layout is useful evidence, but it is weaker than shell-authenticated region roles and much weaker than current prepared action truth.**

## 6) The no-regret Schell move

Schell should add one dedicated surface for:
- prompt-region witnesses,
- continuation cards,
- multiline input geometry,
- sticky chapter header humility,
- and historical-repaint badges.

That lets the shell+terminal feel more natural and more modern while still refusing to confuse beautiful prompt geometry with actual command authority.

## 7) Compact conclusion

The ecosystem has already paid for the lesson:
semantic prompt protocols, click-events, command guides, sticky headers, and multiline prompt fixes all point to the same design truth.

So the next low-regret Schell seam is **prompt regions, continuation cards, and multiline input humility** so the shell can feel radically better without pretending that rows, wraps, or repaints are the same thing as live input truth or reviewed action.
