# SlopOS datacube evaluation — 2026-03-24 — pass CLXXXIV

**Schell should treat prompt geometry as descriptive evidence rather than action authority, because the companion datacubes keep rewarding exact basis, visible reset, visible staleness, and explicit labels instead of flattering layout residue.**

## 1) SlopOS keeps visible comfort weaker than exact footing

SlopOS still pushes the same deep discipline:
visible summary, provider-local routing, and local comfort must stay weaker than exact reviewed footing.
That pressure applies directly here.
Prompt-region chips, multiline sticky headers, continuation cards, and click-to-move comfort can all be excellent — but none of them should quietly become prepared-action truth.

So the companion-safe import is:
- geometry may be rich,
- prompt-local affordances may be rich,
- but exact action still binds to shell-owned current footing.

## 2) ViewFS again provides the clearest neighboring split

ViewFS remains the most direct nearby pressure because it keeps:
- editable material,
- parsed understanding,
- advisory diagnostics,
- compiled packet,
- prepared action,
- and receipt/history

separate.
That means prompt geometry belongs beside those layers, not above them.
A beautifully marked continuation line is still only part of the editable/input-understanding neighborhood.
It is not compiled packet truth.

## 3) Steward, Ward, Harbor, Foundry, and Helm keep the geometry seam honest

- **Steward** reinforces reset/rebuild honesty, which matters when dynamic prompt rebuilds, shell switches, helper injections, or remote hops require Schell to reassert region truth instead of trusting old marks.
- **Ward** reinforces read-cut and revalidation posture, which matters when a restored prompt region is historical geometry rather than current editable truth.
- **Harbor** reinforces label honesty, which matters when `primary`, `right`, `continuation`, `editable`, `output`, and `historical` should remain source-badged roles rather than one visually pleasant prompt state.
- **Foundry** reinforces drift pressure, which matters when unchanged visible multiline text may bind differently on newer cwd/env/helper footing.
- **Helm** reinforces reviewed-basis drift, which matters when rebuilt or restored prompt geometry should not silently inherit the strength of current reviewed input.

Together they point toward one shell+terminal rule:
**separate region roles from prepared action, and make rebuild/restoration posture visible before stronger verbs appear.**

## 4) What this does not require Schell to decide yet

This seam does **not** require Schell to decide:
- one final OSC family,
- one final line editor,
- one final prompt renderer,
- one final sticky-header algorithm,
- one final remote/mux geometry transport,
- or one final right-prompt / continuation-prompt taxonomy.

The archive only needs to prove the tiny honesty stack that says:
- what region is primary prompt,
- what region is continuation,
- what exact span is editable now,
- what is merely rebuilt historical geometry,
- and what exact act is reviewable or launchable on current footing.

## 5) Compact conclusion

SlopOS keeps exact footing narrow.
ViewFS keeps editable, parsed, advisory, compiled, prepared, and historical layers separate.
Steward, Ward, Harbor, Foundry, and Helm all keep reset, staleness, labels, drift, and reviewed basis honest.

So the next Schell move should be:

**add prompt-region witnesses, continuation cards, multiline-input geometry, sticky chapter headers, and historical-repaint badges so the shell feels beautifully modern while still refusing to let layout residue quietly become current reviewed authority.**
