# Research synthesis — 2026-03-23 — pass CLXXVIII

This pass sharpens one fresh lesson from current terminal, shell-integration, streaming, and watch-sync docs:
**the most honest systems do not merely show command-local structure; they also say what exact cut of truth was captured, what it is synced through, and what remains partial or still live.**

## 1) VS Code keeps proving bounded command-local capture is valuable

VS Code's shell integration docs emphasize command navigation and output selection.
Recent release notes then add exact command attachment to chat with command line, captured output, and exit code, plus inline output reveal, output streaming for long-running commands, and collapsible command summaries.

That is important evidence for Schell.
Operators absolutely value bounded command-local capture.
But those features also imply a next honesty question: what exactly did the capture include, and what might still be missing or still arriving?

## 2) WezTerm and Ghostty show why command markers unlock capture, but do not finish the job

WezTerm's shell integration docs keep the substrate tiny: OSC 7 for cwd, OSC 133 for prompt/input/output zones, and OSC 1337 for extra shell state.
That already enables jumping between commands and selecting complete output from a command.

Ghostty's command-finished notifications are the complementary clue.
They make command-local attention much better, but the signal is still a marker-level fact about the tracked command, not a universal guarantee that every later drain, sideband, or relay effect is included in whatever transcript slice the operator is staring at.

## 3) VS Code synchronized output is a good rendering-side lesson

VS Code 1.108 added synchronized-output support so applications can pause rendering and batch updates to prevent tearing while rewriting the buffer.
That is a useful capture lesson too.
A visually coherent buffer update and a semantically complete capture are different things.
The UI may be cleaner, but Schell still needs a small receipt that says what cut was actually taken.

## 4) systemd and Kubernetes show what stronger cut synchronization looks like

systemd's `sd_notify_barrier()` exists because “a status message was emitted” is weaker than “all earlier notifications have been processed.”
Kubernetes watch bookmarks carry the resource version to which a stream is synced, but the docs explicitly warn that clients must not assume bookmarks arrive at any fixed interval or even at all.

That is exactly the design pattern Schell should steal.
If the operator needs a stronger claim than “this looks like the right output,” the shell+terminal should be able to point to a tiny synced-through marker or else admit that it only has a bounded partial cut.

## 5) The no-regret Schell move is a tiny snapshot receipt

Putting these together suggests a better next move than a giant transcript format, global event bus, or universal replay database.
Schell should add:
- a tiny **snapshot receipt** attached to attach/export/replay/watch captures,
- plus an explicit **cut watermark** or synced-through marker when stronger synchronization evidence exists.

They should say:
- what exact thing was captured,
- what bounded the cut,
- what marker or cursor the capture is synced through,
- whether the capture is exact-command-complete, bounded-partial, visible-only, stream-open, or stale,
- what loss or degradation is known,
- and what the strongest honest next move is now.

## 6) Compact conclusion

VS Code proves command-local capture is worth surfacing.
WezTerm proves a tiny semantic substrate is enough to drive exact output-local selection.
Ghostty proves command-finished markers are useful attention signals.
VS Code synchronized output proves visual coherence is not the same thing as semantic completion.
systemd and Kubernetes prove that stronger synchronization deserves explicit barriers or bookmarks.

So the next no-regret Schell seam is not a giant transcript constitution.
It is **snapshot receipts, cut watermarks, and partial-capture humility** so attach bundles, replay cards, watch snapshots, and exports can confess exactly what cut of truth they captured without pretending that bounded capture is complete, current, or authoritative by default.
