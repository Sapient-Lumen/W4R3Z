# Research synthesis, pass XLIII (2026-03-21)

This pass focuses on one bounded seam that Schell did not yet give its own terminal surface:
**run-later UX is one of the best places to make a shell feel super awesome, but current systems keep teaching the same lesson — exact wakeups, best-effort windows, catch-up semantics, replaceable jobs, and durable background presence are different moves and should not be flattened into one generic scheduler story.**

## 1) systemd timers show how much meaning hides inside a “simple timer”

The current `systemd.timer(5)` docs are a strong reminder that even a mature timer model is not just “run at time X.”
Calendar timers that elapse during sleep are processed after resume, but if they elapse multiple times while the system is continuously sleeping they produce only a single service activation.
`AccuracySec=` defaults to one minute to encourage coalescing wakeups, `RandomizedDelaySec=` is for stretching work out to avoid congestion, and `Persistent=` explicitly catches up a missed run when the timer was inactive.

That is a wonderful design warning for Schell.
A future-run card needs to say whether the promise is exact, coalesced, randomized, resumptive, or catch-up capable, because those choices materially change what “later” means.

See: https://man7.org/linux/man-pages/man5/systemd.timer.5.html

## 2) Android keeps insisting that deferrable work should be constraint-based rather than wake-the-world exact

Android’s current WorkManager docs say it schedules one-time or repeated work with **flexible scheduling windows**, constraints, grouping, replacement, and reboot persistence.
The docs also explicitly say WorkManager is for reliable background work that should survive app exit or restart, while `AlarmManager` exact alarms are for precise alarms or notifications rather than recurring background work.
Separately, Android’s current system-restrictions guide says background processes are expensive, restricted apps may lose jobs/alarms/network, and developers should use WorkManager instead of depending on background services and implicit wakeups.

This is one of the clearest “steal this” signals for Schell:
- make deferred work **constraint-first**,
- support replaceable/named work,
- and treat exact wakeup as the special case, not the default story.

See: https://developer.android.com/develop/background-work/background-tasks/persistent
See: https://developer.android.com/develop/background-work/background-tasks/bg-work-restrictions

## 3) Apple’s background-task posture and older launchd docs both reinforce humility about exact time

Apple’s `earliestBeginDate` docs say a background task should not start earlier than that date, but the system does **not** guarantee launching it exactly at that time.
Apple’s older scheduling docs for `launchd` are also still useful as a historical lesson: if a `StartCalendarInterval` job is asleep when the time passes, it runs when the computer wakes; if the machine is off, it waits until the next designated time.

That is a strong reminder that “scheduled for 02:00” and “guaranteed to execute at 02:00” are very different claims.
Schell should preserve that distinction in the UI instead of borrowing calendar language that sounds stronger than the backend can truthfully deliver.

See: https://developer.apple.com/documentation/backgroundtasks/bgtaskrequest/earliestbegindate?language=objc
See: https://developer.apple.com/library/archive/documentation/MacOSX/Conceptual/BPSystemStartup/Chapters/ScheduledJobs.html

## 4) Windows Task Scheduler is another reminder that missed-run policy is a first-class choice

Microsoft’s current guidance says there is a setting to “Run as soon as possible after a scheduled start is missed,” and also notes that this does not apply the same way to one-time tasks in the reboot scenario it describes.
That means even mainstream scheduler UX already contains a quiet policy choice about replaying missed work versus skipping it.

Schell should bring that policy out into the open.
A future-run card should not merely say “daily” or “one time.”
It should expose whether missed windows are skipped, catch up once, or otherwise behave specially.

See: https://learn.microsoft.com/en-us/troubleshoot/windows-server/system-management-components/scheduled-task-not-run-upon-reboot-machine-off

## 5) The best ideas worth stealing are small and operator-facing

A custom shell+terminal could steal a very good subset of these ideas without becoming a scheduler monoculture:
- **review-now / run-later cards** instead of making users retype work into another tool,
- **constraint chips** like charging / unmetered / idle / local-only,
- **replace-by-key posture** so duplicate future work can be replaced intentionally,
- **missed-window badges** so replay vs skip is transcript-visible,
- and one explicit **promote to durable background** rail instead of letting repeated deferred work impersonate a daemon.

Those are the kinds of moves that would make Schell feel special.
They are also exactly the kind of decision-light ratchets this archive should prefer.

## 6) The lesson from the past that matters most here

The old mistake was equating “later” with “therefore exact” or “therefore durable.”
The newer mistake would be giving the terminal a flattering run-later UI that quietly chooses catch-up policy, persistence, replay debt, or background presence on the operator’s behalf.

The better answer is:
- make scheduled intent explicit,
- make missed-window policy explicit,
- keep deferred work distinct from durable background presence,
- and keep request identity weaker than fresh live scheduler truth.
