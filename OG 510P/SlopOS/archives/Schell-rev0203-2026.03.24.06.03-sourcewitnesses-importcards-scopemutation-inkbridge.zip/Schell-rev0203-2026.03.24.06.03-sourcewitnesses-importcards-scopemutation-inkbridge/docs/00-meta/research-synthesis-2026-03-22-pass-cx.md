# Research synthesis, pass CX (2026-03-22)

This pass keeps one narrower lesson explicit:
**dropped text, dropped file offers, path-translated insertion, and remote upload helpers are neighboring conveniences, but they do not mean the same thing and should stop sharing one flattering “drag/drop happened” story.**

Current official docs make this seam unusually clear.
Wayland's data-device model says drag-and-drop begins with data offers, advertised MIME types, and explicit accept/deny behavior; the actual transfer only happens when the receiver requests the offered MIME into a file descriptor.
The XDG File Transfer portal is even more explicit: drag/drop and copy-paste file transfer are middle-manned through a portal session, use `application/vnd.portal.filetransfer`, retrieve files by key, export through the document portal as needed, and close automatically unless configured otherwise.
That is not “paste, but for files.”
It is a typed transfer session with bounded delivery.

The terminal side then shows how much meaning gets flattened away in practice.
WezTerm's `quote_dropped_files` setting exists because dropped file names often need quoting before insertion into a prompt.
Windows Terminal's `pathTranslationStyle` exists because the inserted path string may need to be rewritten differently for WSL, Cygwin, MSYS2, or Mingw targets.
Ghostty's 1.1 release notes say file paths are shell-escaped when files or URLs are pasted, and Ghostty's 1.3 release notes say a security issue was fixed where control characters in pasted or drag-and-dropped text could be used to execute arbitrary commands in some shell environments.
All of that points to the same design truth: a dropped object, an inserted path string, and a later reviewed action are different things.

There is also one very sharp “steal this carefully” example.
iTerm2's shell integration docs say holding Option while dragging and dropping a file offers to upload it via `scp` to the remote host into the directory corresponding to the line where the file was dropped.
That is genuinely clever, but it is also the perfect warning label.
A local drag gesture that becomes a remote upload is not just fancy insertion.
It is a stronger action family with target identity, transfer semantics, and progress/failure posture.

## 1) Drag/drop should be modeled as offers and grants, not as generic input

Wayland and XDG portals point to the same first lesson.
Drag/drop is naturally an **offer + accept + retrieve** seam, not a monolithic “some text arrived” event.
Schell should therefore keep dropped text, dropped file offers, portal-backed file-transfer payloads, and remote-upload proposals as separately named ingress families.
That keeps drag/drop from laundering file identity, transfer posture, or stronger actions into an ordinary input story.

## 2) Quoting and path translation are target-specific transforms

WezTerm and Windows Terminal are particularly useful here.
They show that path insertion is often a transform for one shell or runtime target.
A WSL path translation is not the same truth as the original Windows path.
Quoted insertion is not the same truth as a durable imported object.
Ghostty's shell escaping reinforces the same point.

So Schell should keep file offer, inserted string, quote policy, translation family, and target posture separately named instead of letting the transformed path become the only remembered truth.

## 3) File-bearing drop should usually lead with import/attach, not raw path injection

The File Transfer portal gives the clearest no-regret pattern here because it already routes file exchange through explicit retrieval and document-store export.
That suggests a strong early Schell bias: for file-bearing drops, prefer import, attach, safe-open, or explicit insert-path variants over blind prompt injection.
That is a better way to make dropped files first-class without freezing the final object model.

## 4) Remote upload must stay visibly stronger than local insertion

The iTerm2 `scp` upload example proves that operators love this kind of luxury.
But it also proves that the shell+terminal needs a separate witness for stronger drop actions.
A remote upload proposal has peer identity, transfer direction, destination path, progress, and failure posture that plain insertion does not have.
Schell should steal the comfort and refuse the collapse.

## 5) Compact conclusion

One of the smartest no-regret moves available right now is:
**make dropped text, dropped file offers, path translation/quoting, and remote upload helpers first-class witnesses before Schell lets drag/drop convenience masquerade as plain typing, canonical object identity, or reviewed transfer authority.**

That lets Schell steal genuine modern comfort while keeping the final drop plumbing, import model, portal treaty, and remote-upload engine open.
