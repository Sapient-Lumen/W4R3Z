# SlopOS datacube evaluation, pass LVII

**If Schell borrows MCP-style tool ecosystems, SlopOS says the safe version is explicit catalogs, explicit attachments, request-local routing, exact reviewed actions, and visible session/approval boundaries. Tools, resources, prompts, apps, and pushed events may help a lot, but they must not quietly become ambient shell authority.**

This pass focuses on a pressure seam that is becoming impossible to ignore:
- explicit tool catalogs,
- attached resources,
- reusable prompt templates,
- interactive app/forms,
- mid-task structured elicitation,
- auto-discovered connectors,
- and event channels that push into a live session.

Schell should not respond by rejecting the whole category.
It should respond by importing the right small constraints from SlopOS before convenience turns into architecture.

## 1) D-LLM already says the safe import starts with explicit catalogs

The clearest import is still the LLM-operations posture.
SlopOS already says tool, resource, and prompt catalogs must be explicit and bounded, and it explicitly refuses portable ambient connector discovery or hidden runtime inventory widening in Phase 1.
That maps perfectly onto the current MCP/tool-host world.
A discovered server is not automatically trusted.
A configured server is not automatically started.
A started server is not automatically admitted for every tool.
And prompt/resource metadata is still proposal material, not authority.

## 2) D-PLUMB says route through explicit invocation, not a hidden bus

The plumb posture remains one of the most useful companion warnings.
D-PLUMB stays explicit-invocation, request-local, non-authoritative, and specifically refuses durable inboxes, callback registries, app-visible route inventories, and hidden helper buses.
That matters a lot for modern tool ecosystems.
Interactive apps, prompt templates, resource attachments, and channel pushes will try to regrow a bus if Schell lets them.
The SlopOS import is smaller:
route through explicit request-local objects, not hidden subscriptions or “whoever can handle this” folklore.

## 3) Capshell command-string posture says tools must terminate in reviewed action shape

The capshell command-string posture is the next load-bearing import.
A tool result, app form, or elicitation answer cannot safely stop at “here is some shell text.”
If the result becomes an executable action, it must still land as exact reviewed argv/text in a shell-owned review shape.
No hidden `sh -c`, no model-built command-string adapter, and no app-panel convenience that smuggles parsing across the boundary.
Modern hosts can make invocation beautiful.
They still do not get to make reviewed execution optional.

## 4) Approval-basis posture says structured forms still are not permission

SlopOS approval-basis posture is especially valuable now that elicitation/forms/apps are getting richer.
A filled-out form, a clicked app widget, or a server-provided prompt template does not by itself grant anything.
If a stronger action depends on mutable basis, that exact basis must still be encoded in the reviewed object.
That means Schell should refuse every tempting shortcut in this category:
- “the server asked for it,”
- “the form looked valid,”
- “the app UI already chose the defaults,”
- or “the same server was trusted earlier.”

## 5) Resource attachments should import observation discipline, not hidden memory

SlopOS already has the right instinct for observation/memory surfaces: explicit attachment or it does not count.
So MCP-style resources are a good fit when they behave like explicit attached context objects.
They are a bad fit when they become hidden long-term memory or ambient workspace inventory.
Schell should therefore treat attached resources as visible context cards with source, freshness, and scope posture, not as invisible model background that silently follows later runs.

## 6) App/forms and hidden component state need transcript humility

The current app ecosystems are teaching a subtle but important lesson: not every useful bit of UI state belongs in the transcript, and not every transcript-visible field belongs in the model.
That matches SlopOS very well.
Receipts, prompts, tools, and workflows are already supposed to keep exact reviewed truth separate from helper-local scaffolding.
Schell should import the same discipline:
component-local hydration data can exist,
but it should remain weaker than transcript truth,
and transcript truth should remain weaker than reviewed execution truth.

## 7) Channels and pushed events must stay weaker than durable background truth

Claude-style channels line up closely with a SlopOS background/request-state lesson.
A pushed event arriving in a currently running session is not the same thing as a durable background grant, a portal-owned live job, or a stable notification lease.
The archive already distinguishes request identity from current live grant truth.
That same split should govern channels in Schell.
If a session is closed, the absence of delivery is not a paradox.
If a session is open, the presence of delivery is not a durable-background proof.

## 8) The clean import: tool-catalog witnesses, not tool folklore

A SlopOS-compatible import now looks like this:
- every server/tool/resource/prompt/app/channel object is explicitly cataloged,
- every catalog item carries source, scope, trust, and transport posture,
- local servers can be sandboxed and should say so,
- resource attachment is explicit and request-local,
- prompt templates stay playbooks rather than policy,
- app/forms produce review objects rather than auto-run,
- elicitation yields exact field witnesses rather than ambient questioning authority,
- pushed events stay visibly session-local unless some future background seam earns stronger status,
- and any executable result still terminates in exact shell-owned review truth.

## 9) What Schell should refuse right now

Under current SlopOS pressure, Schell should refuse:
- ambient connector discovery that silently widens active authority,
- helper UIs that can directly run commands without a shell-owned review object,
- prompt/tool metadata acting as permission,
- hidden handler inventories or capability oracles,
- callback registries and invisible event rendezvous,
- channels that overclaim durable background truth,
- and component-local/private app state being treated as transcript or receipt truth by accident.

## 10) Decision-light next move

A strong next move is to define one **tool-catalog witness** family that proves:
- explicit catalog classes,
- explicit scope/trust/sandbox posture,
- resource attachments,
- prompt-template reuse,
- inline app/forms,
- structured elicitation,
- and session-local pushed events
can all coexist without creating a second shell, a hidden bus, or an ambient tool authority plane.

That keeps Schell ambitious while learning the right lesson from SlopOS:
**tool ecosystems are welcome, but discovery, UI, and helper metadata stay weaker than exact reviewed shell truth.**
