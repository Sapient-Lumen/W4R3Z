# Research synthesis — 2026-03-21 pass XIII

This pass keeps one design rule in view:
**visible selection should become explicit, trust-graded selection packets with bounded action ladders and one separate primary-target truth, rather than a blur of highlighted text, hovered links, and guessed “current thing.”**

The strongest outside convergence here is that current shells and terminals become much more useful when they distinguish three different jobs:

- marking semantic command/prompt/output regions,
- selecting visible objects for copy/open/insert/navigation,
- and limiting strong actions to the cases where the system really knows what object is being acted on.

## Strongest current outside pressure

### 1) Shell-emitted semantic regions make selection much more honest

VS Code's shell integration makes command detection, decorations, navigation, sticky scroll, and more reliable working-directory-aware link opening possible because the shell tells the terminal what is happening instead of forcing it to guess from prompt-shaped text.
It also supports FinalTerm / OSC 133 style prompt and command markers plus current-directory markers.

WezTerm then shows what a terminal can do with that: `SelectTextAtMouseCursor 'SemanticZone'` can select the surrounding semantic zone, making complete input/output-region selection a first-class action instead of a regex trick.

This is exactly the direction Schell should steal:
selection should prefer shell-authenticated or shell-marked regions over heuristic guessed regions whenever possible.

### 2) Visible-text action systems are delightful — and dangerous when they overclaim

kitty's hints mode is a great reminder of how delightful visible selection can be.
It can select arbitrary visible snippets, then open URLs, insert selected paths into the terminal, or copy selections to the clipboard.
That is a brilliant class of move.

But those same powers are a warning.
If visible snippets become actionable, the shell+terminal needs an explicit action ladder.
“copy”, “open”, “insert”, and “inspect” are not the same as “rerun”, “execute”, or “replay with current authority”.

### 3) The active prompt deserves a privileged, narrower interaction story

Ghostty's click-to-move-cursor support is especially useful because it stays inside **an active shell prompt**.
That means the terminal is not pretending the whole screen is one giant editable document.
It is taking advantage of a narrower, more truthful zone.

That is a strong clue for Schell:
active-input selection/edit should be privileged and fast, while historical-output selection should stay rich but more bounded.

### 4) Context-rich open is worth stealing — but it still is not strong authority

iTerm2 semantic history tracks the current working directory for each line to help resolve files when you Cmd-click them.
VS Code likewise uses current-working-directory detection to resolve terminal links more accurately and to open the right file directly when it knows the current location.

These are excellent “super awesome” steals.
But they still only justify **context-rich open/inspect**.
They do not justify silently promoting a selected historical path into a live execution target.

### 5) Mode/ownership separation improves selection honesty

Warp now keeps terminal blocks and agent conversation blocks in separate scopes, and saved workflows paste into the active terminal input for review and adjustment before execution.
That separation is a useful product lesson.
A custom shell+terminal can unify discovery while still preserving block origin, visibility, and action boundaries.

### 6) Scoped approval rules are a clue for selection action ladders too

VS Code's December 2025 release added session and workspace rules for future terminal tool commands.
Even in a very different product, that is a good reminder that selected-object actions may need explicit **scope posture**.
A small action may be okay for the current live lane only, while a stronger repeatable rule belongs on a separate seam.

## Best ideas worth stealing now

### Selection packets, not raw highlights

Schell should have a first-class selection object for things like:

- active prompt text,
- command/input/output semantic zones,
- paths,
- URI/hyperlink objects,
- receipt cards,
- review/hold cards,
- workflow artifacts,
- and maybe later agent-only objects.

A good packet should keep at least:

- object kind,
- trust grade,
- liveness/posture badge,
- selection bounds,
- context witness (cwd, block, lane, authorship, basis),
- and the safe action families currently allowed.

### One separate primary-target strip

Schell should distinguish the **primary target** for the current live lane from any passive selection.
That primary target is the object that current strong keyboard actions would route to.
Selections should be able to exist without stealing that role.

### Action ladders keyed by selection kind

A path selection might allow:

- copy,
- insert,
- quote-insert,
- open,
- inspect,
- import.

A shell-authenticated command block might allow:

- copy,
- inspect,
- attach receipt,
- compare basis,
- propose rerun.

A historical receipt might allow:

- inspect,
- cite,
- derive proposal,
- reopen context.

This is better than one giant menu because it keeps power and honesty aligned.

### Fail-closed approximate-open hold cards

When the system only has a nearby approximation — wrong cwd, stale restored block, guessed path, ambiguous region — Schell should show a hold card rather than silently doing “something close.”
That is a very SlopOS move and a very humane one.

### Transcript-safe selected-object witnesses

The transcript should be able to say:

- what kind of object was selected,
- whether it was live, restored, historical, guessed, or shell-authenticated,
- and which action family was taken or refused.

That keeps the fancy terminal from becoming the only place where selection truth exists.

## Moves that make the custom shell+terminal super awesome

### 1) Make selection feel object-aware instead of text-only

Selecting a path, receipt, command output region, or active prompt should feel like selecting a meaningful object, not just a rectangle of bytes.

### 2) Keep active input blazing fast

The current prompt/input field should feel like a real editor field with prompt-safe click/edit and direct workflow insertion, while still staying visibly distinct from history.

### 3) Make click/open behavior exact and explainable

Context-rich opens are wonderful when the system can say what context it used and can refuse approximate fallback honestly.

### 4) Let one palette unify discovery without flattening authority

A unified palette/search system can still preserve block origin, lane, liveness, trust grade, and action families.
That is a great “super awesome” move that stays decision-light.

## Current prototype reading

The next no-regret slice now looks like this:

1. **one selection-packet family,**
2. **one primary-target indicator,**
3. **one active-prompt privileged selection path,**
4. **one semantic-zone selection path,**
5. **one ambiguous-open hold card,**
6. **and one transcript witness for selected-object handling.**

That leaves pointer-model details, final renderer choices, palette engine, complete selection grammar, and the final action algebra open.
That is exactly where Schell should stay.

## Reference pressure

- https://code.visualstudio.com/docs/terminal/shell-integration
- https://code.visualstudio.com/updates/v1_108
- https://wezterm.org/config/lua/keyassignment/SelectTextAtMouseCursor.html
- https://ghostty.org/docs/install/release-notes/1-3-0
- https://ghostty.org/docs/config/keybind/reference
- https://sw.kovidgoyal.net/kitty/kittens/hints/
- https://iterm2.com/documentation-preferences-profiles-advanced.html
- https://docs.warp.dev/agent-platform/local-agents/interacting-with-agents/agent-modality
- https://docs.warp.dev/knowledge-and-collaboration/warp-drive/workflows
