# SlopOS datacube evaluation, pass LXVI (2026-03-22)

This pass evaluates one new companion import:
**Schell should absolutely gain reviewed clock witnesses, locale/timezone basis, and deadline posture, but SlopOS pressure says ambient `LANG`/`LC_*`/`TZ`, ambient clock access, monotonic deadline intent, authenticated-time evidence, and present live status must stay separately admitted so time truth never collapses into host folklore.**

## 1) D-CAPSHELL already says launch meaning must not inherit ambient locale or timezone

The companion archive is unusually sharp here.
`capshell-env-baseline-posture-v0.md` says the child environment is exact, not “declared plus baseline”, and explicitly forbids hidden injection of `LANG`, `LC_*`, and `TZ` from host/session/TTY/request-context state.
That is exactly the right Schell import.
A reviewed shell surface should say whether locale/timezone posture is explicit, omitted, inherited by a compat membrane, or degraded — not leave it hidden in launcher folklore.

## 2) D-NONDET says clock access itself is authority, not an ambient syscall convenience

`rfcs/0063-nondeterminism-capabilities-clock-and-entropy.md`, `clock-descriptor-schema-v0.md`, and `capshell-nondet-posture-v0.md` add the next important pressure.
They say time is capability-shaped; default access is `monotonic_coarse`, finer clocks are stronger authority, `realtime` is optional and observational, and capshell launch must not quietly preserve “normal machine clocks” when D-NONDET is enabled.
That is a huge gift to Schell.
It means the shell+terminal does **not** need to pretend there is one universal “current time” for every reviewed action.
Instead, it can expose clock kind, resolution, and basis as a compact witness family.

## 3) SlopOS separately refuses to make security time equal app-visible wall clock

`security-time-posture-v0.md` and `timeproof-posture-v0.md` sharpen another useful lesson.
They say security time is a policy-local monotonic lower bound, app-visible realtime remains observational, and authenticated timeproof export is evidence-first and lower-bound-only rather than a portable “the clock is now correct” claim.
That pressures Schell toward a stronger design rule:
clock/sync badges should stay weaker than present authority, and historical proofs or receipts should never masquerade as current live footing.

## 4) D-REQCTX says deadline intent is monotonic coordination, not hidden authority

`rfcs/0105-request-contexts-deadlines-and-cancellation.md` and `reqctx-posture-v0.md` are another sharp pressure source.
They say request contexts are not authority, deadline intent is one absolute monotonic deadline intent, and cancellation/deadline semantics are coordination plus resource hygiene rather than a kill switch or security boundary.
Schell should import that discipline wholesale.
A deadline chip should be explicit about whether it is monotonic intent, rendered wall-clock projection, or merely historical receipt metadata.

## 5) SlopOS's split suggests at least six separate shell-side objects

Putting those companion surfaces together suggests a clean Schell family:
- **clock witness** — monotonic coarse / monotonic fine / realtime / unknown,
- **locale witness** — explicit `LC_ALL`/`LC_*`/`LANG` basis, omitted, or degraded compat basis,
- **timezone witness** — explicit `TZ`, host/default basis, or unknown,
- **deadline witness** — monotonic intent versus wall-clock rendering,
- **sync/proof badge** — live, historical, unavailable, or degraded,
- **time receipt** — bounded historical facts about what reviewed action was timed/rendered under which basis.

That split matters a lot.
If Schell flattens those objects, it will recreate exactly the ambient-folklore problem SlopOS keeps refusing.

## 6) A compact v0 posture worth stealing

A good early Schell time family should probably say:
- whether launch depends on monotonic coarse, monotonic fine, realtime, or unknown clock footing,
- whether locale and timezone basis come from explicit reviewed env, compat defaults, or omission,
- whether deadline posture is monotonic intent, wall-clock-derived display, or unavailable,
- whether current sync/proof posture is live or merely historical,
- and whether any time receipt is exact shell-owned outcome truth or a weaker provider-side/timeproof-side addendum.

That would make time truth much more humane without forcing one final time-sync backend, timezone admin stack, or locale portability model.

## 7) Decision-light next move

A strong next move is to define one **clock witness / locale basis / deadline humility** family that proves:
- reviewed clock kind,
- explicit locale/timezone posture,
- separately named deadline and sync/proof badges,
- and bounded historical time receipts
can coexist without turning Schell into a host-specific locale browser, a fake secure-time dashboard, or a portability theater around clocks.

That keeps Schell ambitious while learning the right lesson from SlopOS:
**time truth is welcome, but locale basis, timezone basis, clock kind, request deadline intent, authenticated-time evidence, and historical receipts must stay separately admitted.**
