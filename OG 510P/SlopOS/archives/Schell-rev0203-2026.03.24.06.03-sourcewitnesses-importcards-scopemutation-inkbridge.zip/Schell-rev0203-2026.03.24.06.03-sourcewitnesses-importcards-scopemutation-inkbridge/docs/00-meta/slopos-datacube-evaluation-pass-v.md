# SlopOS datacube evaluation — pass V

This pass keeps one discipline front and center:
**Schell should become a great shell+terminal for SlopOS without inheriting more authority surface than it can honestly prove.**

The most valuable new SlopOS lesson is that several truths that normal terminals collapse together are actually different:

- request intent,
- admission / launch,
- result receipt,
- and current live state.

That distinction should shape Schell from the beginning.

## Strongest SlopOS lessons right now

### 1) Admission, completion, and live state are different truths

SlopOS is unusually crisp here.
The OpenURI launch-completion boundary refuses to turn mediated launch into a portable downstream completion oracle, and the lease-descriptor-state boundary refuses to treat issuance evidence as current live-state truth.

Local import for Schell:

- a reviewed action receipt is not the same thing as downstream completion,
- command exit is not the same thing as durable success,
- old receipts do not prove that a background grant is live now,
- and the terminal should never imply current authority merely because scrollback contains an earlier success.

This is one of the most important shell+terminal lessons in the whole archive.
If Schell gets this right early, postmortems and background UX become much more honest.

### 2) Generic open should stay smaller than browser/session folklore

The OpenURI session-selection and handler-selection boundaries are a direct warning for shell design.
A generic open request should not silently grow browser-profile, cookie-jar, incognito, or chosen-handler selection semantics merely because real launchers happen to have those local behaviors.

Local import for Schell:

- `open` should stay a request for an exact subject and an exact reviewed action,
- review cards should not promise handler identity unless the shell truly owns that seam,
- and the terminal should not imply browser/session control that the shell cannot replay or receipt honestly.

This is especially relevant for a custom terminal because rich preview affordances make it tempting to smuggle policy-local handler state into what looks like portable shell truth.

### 3) Exact mutable basis matters as much as exact subject

The approval-basis posture remains one of the best SlopOS imports for Schell.
It is not enough to know *what* was approved.
We also need to know *which exact mutable basis* was approved.

Local import for Schell:

- review cards should expose revision/digest/selection basis whenever drift would matter,
- command rerun / reopen / attach affordances should fail closed when their basis changed,
- and a terminal should not present “looks close enough” affordances for effectful actions.

This is the design law that keeps humane UX from silently turning into authority reuse.

### 4) Request state and live state should stay visibly separate

The background-request-state and lease-state posture docs in SlopOS are exactly the medicine a new shell needs.
They make it obvious that “I asked for background” and “the grant is live right now” are different facts.

Local import for Schell:

- the background shelf should show requested state, live state, expiry, renewability, and the last state-changing receipt/denial separately,
- receipts should remain issuance-bounded evidence,
- and historic transcript entries should not masquerade as a live-state dashboard.

### 5) Portable requester truth should remain compact

SlopOS keeps teaching the same lesson across OpenURI, materialization, and session boundaries:
portable requester truth should remain smaller than handler-local reality.

Local import for Schell:

- keep shell truth compact and exact,
- let the terminal render richer local UX around that truth,
- but do not widen shell truth until there is a real replay, denial, and receipt story for the widened meaning.

That discipline will matter more and more as Schell grows inline previews, shelves, and richer command blocks.

## What Schell should deliberately refuse for now

### Refuse completion theater

Do not let success at launch or approval-time become an implied promise that the downstream task completed, that the user saw the target, or that the target-owned state is now live.

### Refuse generic browser/session knobs on generic open

Do not turn the first humane open/reveal flow into a browser profile manager, cookie-jar selector, or private-mode API.
Those can return later only if they earn their own explicit shell truth and receipt surfaces.

### Refuse live-state inference from archive residue

Do not let old receipts, command blocks, or exported transcript snippets behave like a portable current-state oracle.

### Refuse giant schema mirroring

SlopOS is a full operating-environment archive.
Schell should import its boundary discipline, not mirror every posture family one-for-one.

## Current no-regret conclusion from SlopOS

The safest and most valuable early shape for Schell is:

1. **exact subject identity,**
2. **exact mutable basis when relevant,**
3. **review card + approve/deny path,**
4. **durable receipt/denial object,**
5. **plain-text transcript truth,**
6. **and explicit refusal to confuse receipt truth with current live state.**

That is enough to build something genuinely better than old shells without pretending the architecture is already settled.
