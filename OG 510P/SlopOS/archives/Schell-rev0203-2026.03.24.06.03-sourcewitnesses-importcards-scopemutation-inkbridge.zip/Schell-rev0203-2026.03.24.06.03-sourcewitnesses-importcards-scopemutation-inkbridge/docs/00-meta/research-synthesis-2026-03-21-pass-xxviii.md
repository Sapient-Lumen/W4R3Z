# Research synthesis, pass XXVIII (2026-03-21)

This pass keeps another design rule in view:
**completion and preflight should become much smarter without letting suggestion engines, helper specs, or parameter prompting impersonate execution authority.**

The current landscape suggests a very good split.
The best tools make suggestions richer, more typed, and more contextual.
The best-behaved tools still keep insertion, review, and execution separate.
That is an excellent clue for Schell.

## 1) Good terminals now treat completion as a first-class terminal surface

VS Code's terminal shell integration says IntelliSense in the terminal can suggest files, folders, commands, command arguments, and options.
It also says the terminal aggressively caches globals for a particular shell to improve performance.
That is a strong clue that completion is now part of terminal UX, not just shell folklore — but it also needs an explicit performance story.
See: https://code.visualstudio.com/docs/terminal/shell-integration

## 2) Descriptions and contextual suggestions are worth stealing

fish says autosuggestions come from command history, completions, and valid file paths.
Its interactive documentation also exposes dedicated colors for completion descriptions in the pager.
Nushell's external fish completer notes that fish returns completion `value` and `description` pairs separated by a tab.
That is a very good Schell clue: completion rows should probably be richer cards with both value and explanation, not plain text stubs.
See: https://fishshell.com/docs/current/interactive.html ; https://www.nushell.sh/cookbook/external_completers.html

## 3) Prediction sources should be explicit and composable

PSReadLine documents that Predictive IntelliSense can use `History` or `HistoryAndPlugin` sources.
That is a strong precedent for Schell origin badges.
A suggestion should be able to say whether it came from shell-known static structure, recent history, a plugin, or some slower dynamic helper.
See: https://learn.microsoft.com/en-us/powershell/scripting/learn/shell/using-predictors?view=powershell-7.5

## 4) Focused parameter help is a wonderful, underused move

PowerShell's dynamic help supports focused parameter help with `Alt+h`, shown below the current command line similarly to MenuComplete.
It also supports selecting arguments on the command line with `Alt+a` for easy replacement.
Those are excellent moves for Schell: help should bind to the exact focused slot, and editing one argument should not require reparsing the whole line in the operator's head.
See: https://learn.microsoft.com/en-us/powershell/scripting/learn/shell/dynamic-help?view=powershell-7.5

## 5) Insert-first menus beat silent execution

PowerShell says tab completion exists to provide hints, discovery, and speed up input entry, and that `MenuComplete` displays a list of matching completions below the command line.
VS Code's run-recent-command picker similarly allows holding Alt to write the text to the terminal without running it.
That pattern is excellent.
For Schell, better completion should usually mean land in active input or open a review card, not run.
See: https://learn.microsoft.com/en-us/powershell/scripting/learn/shell/tab-completion?view=powershell-7.5 ; https://code.visualstudio.com/docs/terminal/shell-integration

## 6) Legacy completion stacks prove how easily “harmless suggestions” become code execution

Bash's programmable completion says Bash executes shell functions or commands specified with `-F` and `-C` when generating completions.
The completion function may use any shell facilities, and a command specified with `-C` runs in an environment equivalent to command substitution.
Fig's generator docs likewise say generators run shell commands on the user's device, and custom generators may execute multiple shell commands on the user's machine.
That is the clearest current warning for Schell: dynamic completion is powerful precisely because it can become a secret second execution path.
See: https://www.gnu.org/software/bash/manual/html_node/Programmable-Completion.html ; https://fig.io/docs/reference/generator ; https://fig.io/docs/reference/generator/custom

## 7) Shared specs and bridges are a better v0 than inventing one giant completion empire

Cobra provides built-in support for generating completion scripts.
`clap_complete` can generate shell completions at compile time or runtime.
Fig defines a standard completion-spec schema.
Carapace presents itself as a multi-shell completion library and binary, and its bridge docs say bridging can be beneficial for embedding cases like `sudo ... <TAB>` while also avoiding shell startup delay from sourcing large completion scripts.
That is a strong clue that Schell should ingest and badge external completion knowledge rather than pretending it needs to author every completion rule itself.
See: https://cobra.dev/docs/how-to-guides/shell-completion/ ; https://docs.rs/clap_complete/latest/clap_complete/ ; https://fig.gitbook.io/fig/autocomplete ; https://carapace.sh/ ; https://carapace-sh.github.io/carapace-bin/spec/bridge.html

## 8) Parameter prompting plus policy checks can be powerful if they stay visibly weaker than approval

Amazon Q Developer in chat applications documents that when a user runs a command, required parameters are checked and missing information is prompted for, then the command is checked against configured IAM roles and channel guardrail policies.
That is a very good clue for Schell preflight cards: missing-slot prompting and policy-aware warnings can be useful, but they should remain explicit preflight, not hidden auto-run logic.
See: https://docs.aws.amazon.com/chatbot/latest/adminguide/qdev-in-chat-applications-ag.pdf

## 9) A compact Schell v0 cluster is strong

A decision-light first cut probably needs only:
- one **completion card** family with value, description, type, and origin badge,
- one **parameter-help** card bound to the focused slot,
- one **preflight card** for missing parameters and likely drift/effect hints,
- one **insert / review / run** outcome ladder,
- one **scoped dynamic-search** rule for slower completions,
- and one **bridge seam** for importing shell/framework completion knowledge without flattening provenance.

## 10) Decisions intentionally kept open

This pass does **not** freeze:
- one completion engine,
- one plugin API,
- one spec schema for all CLIs,
- one global search index,
- one AI suggestion backend,
- or one preflight analysis backend.

The no-regret move is narrower:
**make suggestions typed, source-labeled, insert-first, and preflight-capable, while keeping dynamic generators explicit and weaker than reviewed execution.**
