# SlopOS datacube evaluation, pass CXIV (2026-03-22)

This pass evaluates one narrower question against the current companion archives:
**what do SlopOS and the nearby companion datacubes teach Schell about live-session ergonomics once follow, attach, control, debug, and sideband convenience all begin to accumulate?**

The answer is crisp:
**keep exact execution small, keep routing explicit, and refuse to let live-session lanes collapse into one flattering “connected” story.**

SlopOS supplies most of the constitutional pressure.
ViewFS supplies the clearest nearby shell/product compression.
Steward reinforces the shell+terminal side with explicit semantic epochs, freshness posture, and non-authoritative semantic chrome.

## 1) SlopOS already rejects the hidden-control version of shell comfort

The `capshell` family continues to refuse hidden command-string fallback, ambient startup/session magic, portable PTY mythology, and ambient local-IPC inheritance.
That means Schell should not solve live-session ergonomics by widening the execution substrate until every observation path also becomes a control plane.

A log follower is not an excuse to smuggle in shell stdin.
A convenience attach is not an excuse to smuggle in local IPC or debugger authority.
A forwarded sideband is not an excuse to pretend shell or object authority widened.

## 2) SlopOS plumb posture says visible next actions should stay typed

RFC-0117 keeps routing explicit-invocation, request-local, and non-authoritative.
That is an excellent constraint here.
If Schell wants rich live-session actions, it should preserve whether the operator is:
- observing,
- attaching,
- sending typed control,
- performing a synchronous update,
- spawning debug exec,
- or opening a sideband.

That is much more companion-compatible than one ambient “connected session” abstraction.

## 3) Background and session posture keep history weaker than live authority

The companion archive already keeps request ids weaker than current grant state and live sessions weaker than durable receipts.
That matters directly here.
A transcript or remembered lane can be valuable without becoming a still-live control handle.

So Schell should preserve at least this split:
- live observe/follow,
- live attach,
- live control/update,
- live debug/exec,
- live sideband,
- and historical receipt/transcript.

## 4) ViewFS already offers the best nearby compression

Among the included companion datacubes, ViewFS is especially informative on this pass.
Its current work explicitly separates observe, attach, control, injected exec/debug, sideband tunnels, and durable transcript/history.
That is exactly the right product-level answer for Schell to steal.

It is rich enough to make terminals feel ambitious.
It is still narrow enough to avoid freezing one final runtime or remote substrate too early.

## 5) Steward keeps the shell+terminal chrome honest

Steward’s shell/terminal posture keeps semantic channels observational and freshness-scoped rather than lifecycle authority.
That means even once Schell adopts live-lane witnesses, it should still keep:
- command-frame semantics weaker than exact execution truth,
- freshness explicit,
- and lane claims fenced when resync, hop changes, or restoration make them older than they look.

That is an important throttle.
The lane model should improve shell truth, not impersonate it.

## 6) Companion-compatible no-regret move

Schell does **not** need to freeze one final mux, attach protocol, control channel, debug substrate, or tunnel backend.
It only needs a few rules:

### A) Keep exact execution exact
Structured argv and exact reviewed commands stay stronger than live-session chrome.

### B) Keep live lanes separately named
Observe/follow, attach, control/update, injected exec/debug, and sideband should stay visibly distinct.

### C) Keep armed versus active separate
Requested readiness, active control, paused state, detach, and history should not collapse into one status bit.

### D) Keep history useful but weaker
Receipts, transcripts, and restored views remain valuable without impersonating live handles.

### E) Keep stronger actions route-bound
Mutation, debug exec, tunnel open, and reattach should remain explicit route choices rather than consequences of looking at a pane.

## 7) Compact conclusion

The SlopOS-compatible answer is not “make every live thing a shell.”
It is:
**keep execution exact, keep routing typed, and make live-session lane truth explicit so observation, attach, control, debug, and sideband delight can grow without collapsing into hidden authority.**

That is a design-phase-safe move because it makes the shell+terminal much more powerful and much more honest without forcing the major architecture decisions early.
