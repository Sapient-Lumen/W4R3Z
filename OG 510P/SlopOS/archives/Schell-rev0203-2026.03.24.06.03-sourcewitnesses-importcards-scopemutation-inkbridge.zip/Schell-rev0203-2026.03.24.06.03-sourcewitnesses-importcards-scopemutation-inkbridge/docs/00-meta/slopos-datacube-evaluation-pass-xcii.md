# SlopOS datacube evaluation, pass XCII (2026-03-22)

This pass reopens SlopOS around one narrow seam:
**what Schell should learn from SlopOS’s exact-approval and capability-safe automation posture before it invents a giant shell architecture or a giant preview mythology.**

The strongest imports came from three connected SlopOS areas.

## 1) Approval basis exactness is the real preview lesson

SlopOS’s approval-basis posture is unusually useful here.
It keeps repeating that approval binds one exact action on one exact mutable basis; approvals do not silently follow `latest`, `head now`, or whatever the system has drifted to by execution time.

That means Schell should be very suspicious of warm, fuzzy preview chrome.
A preview that matters should make clear:
- the exact subject,
- the exact mutable basis when relevant,
- what is predicted versus exact,
- and what becomes stale if the basis changes.

The import is not “copy SlopOS approval tokens into a shell UI.”
It is narrower:
**effect preview should be basis-honest or admit that it is only descriptive.**

## 2) D-CAPSHELL says learn mode must stay observational

RFC-0115 keeps pushing the same healthy discipline.
Automation is where least privilege collapses fastest, so capability-safe shelling should make contracts visible, keep ambient authority out, and make learn mode observational rather than authority-bearing.

That is exactly the right warning for Schell.
A shell+terminal can absolutely become luxurious about:
- explain-before-run,
- contract hints,
- missing-authority reports,
- and likely effect summaries.

But those surfaces should stay proposal-only until the operator reviews an exact action on an exact basis.
In other words, the preview can help you think; it should not quietly become permission.

## 3) Exact exec identity and no hidden fallback should shape parse UX

RFC-0115 also keeps refusing hidden shebang discovery, ENOEXEC shell fallback, ambient interpreter selection, and other “probably what you meant” launch folklore.
That is a superb shell-design lesson.

Schell should therefore avoid one of the oldest shell traps: letting convenient rendering or partial parsing stand in for exact launch meaning.
The useful import is:
- separate exact argv / exact external launch shape from pretty inline editing,
- keep raw-text and structured lanes separately named,
- and show when a preview is using approximated parsing or helper knowledge rather than exact execution basis.

## What Schell should steal now

The best decision-light imports are:
- **effect-preview cards** with exact-subject / exact-basis posture when available,
- **WhatIf / explain-before-run rails** that stay weaker than execution approval,
- **contract and wallet diff strips** that summarize likely effects without pretending to authorize them,
- **explicit external-boundary reveal** for native-command parsing, text conversion, and interpreter choice,
- and **stale-basis confession** when a preview or review surface no longer matches current basis.

## What Schell should still defer

This pass does **not** justify freezing:
- one final shell language,
- one final structured pipeline ontology,
- one final preview/explanation protocol,
- one final automation contract language,
- or one final cross-host review story.

## Bottom line

SlopOS keeps rewarding the same discipline:
**bind authority to exact basis, keep learn/explain surfaces observational, refuse hidden launch fallback, and make stale-basis drift visible instead of flattering.**

That makes the next no-regret Schell move clear:
add one explicit effect-preview / WhatIf / parse-honesty surface and keep the bigger shell architecture open.
