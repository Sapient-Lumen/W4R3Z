# Research synthesis — 2026-03-23 — pass CLXXI

This pass sharpens one useful lesson from current official platform docs:
**the exact thing you mean to act on should stay separate from any baton that merely asks the UI to foreground or activate it, and prepared/enabled state should stay separate from active control.**

## 1) HTML keeps fresh interaction and consumed activation distinct

The HTML Standard still separates sticky activation, transient activation, transient-activation-gated APIs, and transient-activation-consuming APIs.
That matters because a recent user gesture is real but bounded.
It can justify one stronger act or one foreground request without becoming ambient standing authority.

## 2) XDG notifications and global shortcuts treat activation as a separate field

The XDG Notification portal says a notification action can carry an **activation token** and an application-defined target.
The XDG GlobalShortcuts portal emits shortcut activation events with an optional activation token that can be used to activate a window in response.
That is a strong product lesson for Schell:
**resolve the exact target first, then carry activation as a second scoped field rather than smuggling focus authority into the target itself.**

## 3) XDG InputCapture keeps enabled and active explicitly separate

The InputCapture portal is even clearer.
It distinguishes `enabled` from `active`, and the compositor decides when capture actually becomes active.
The application can prepare the conditions for capture, but it cannot honestly claim active control until the compositor says so.
That is exactly the kind of honesty a shell+terminal should import for helper lanes, summon flows, and foreground-sensitive returns.

## 4) Current terminal pressure still points toward partial, fieldwise context

Ghostty 1.3.0 keeps adding shell-aware comfort like click-to-move-cursor in prompts and scrollback search, but it also keeps inheritance and shell integration fieldwise rather than magical.
Windows Terminal still documents duplicate tab as copying profile and directory while *not* copying modified/added environment variables.
WezTerm keeps `SpawnCommand`, `cwd`, and domain choice explicit.
These products keep reminding us that nearby comfort is partial and should not overclaim active ownership or complete cloned state.

## 5) The no-regret Schell move is activation batons plus armed rails

Putting these sources together suggests a smaller next step than a full foreground-control platform.
Schell should add a tiny **activation baton witness** that can accompany notification clicks, global shortcuts, chooser accepts, browser returns, and exact reveal/open actions.
That witness should say:
- what exact target was resolved,
- whether a baton exists,
- whether foregrounding was only requested or actually granted,
- whether the lane is only armed/prepared,
- and what downgrade floor remains honest when activation is missing, refused, or expired.

## 6) Compact conclusion

HTML teaches that fresh interaction is real but bounded.
XDG Notification and GlobalShortcuts teach that activation is a separate field from the target.
XDG InputCapture teaches that enabled is not active.
Ghostty, Windows Terminal, and WezTerm keep proving that shell-aware luxury is still fieldwise and partial.

So the next no-regret Schell seam is not a giant foreground-control or trusted-click platform.
It is **activation batons, armed rails, and focus-second humility** so the shell+terminal can reveal the exact thing first, ask for activation second, and confess honestly when active control never actually arrived.
