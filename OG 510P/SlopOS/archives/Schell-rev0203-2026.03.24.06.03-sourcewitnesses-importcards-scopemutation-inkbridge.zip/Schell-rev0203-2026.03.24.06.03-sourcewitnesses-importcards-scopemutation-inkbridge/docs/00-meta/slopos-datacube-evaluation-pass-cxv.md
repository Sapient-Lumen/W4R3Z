# SlopOS datacube evaluation, pass CXV (2026-03-22)

This pass evaluates one narrower question against the current companion archives:
**what do SlopOS and the nearby companion datacubes teach Schell about command recall, recent directories, and semantic-memory comfort once the shell+terminal starts remembering much more than classic shells do?**

The answer is crisp:
**remember more, but remember in partitions and keep footing drift visible.**

SlopOS supplies the constitutional pressure.
Steward supplies freshness and chrome humility.
ViewFS reinforces peer/session separation.
Together they suggest that Schell should not build one giant memory pile just because modern terminals can surface more history beautifully.

## 1) SlopOS keeps descriptive memory weaker than live authority

The current SlopOS companion continues to keep exact execution, typed routing, request-local completion, descriptive wallets, and call-chain context distinct.
That matters directly for shell memory.

A remembered command, directory, or command frame can be extremely useful.
It should still remain weaker than:
- the current live peer,
- the current authority wallet,
- the current route,
- or a fresh reviewed action basis.

That is a very good constitutional rule for Schell memory surfaces.

## 2) Wallet posture suggests recall should carry authority drift, not authority itself

CH-WALLET posture is already descriptive rather than authoritative.
That is exactly the right influence here.

If Schell remembers a command that previously ran with one capability posture, it should not pretend that the same posture is still live.
Instead it should preserve compact descriptive hints such as:
- same-wallet candidate,
- wallet drifted,
- wallet absent,
- imported historical footing,
- or unknown.

That gives recall the right product feel without laundering old authority into current power.

## 3) Call-chain and borrowed-authority posture suggest lane and provenance partitions

RFC-0118’s call-chain and privilege-bracketing pressures suggest another excellent shell lesson.
A command remembered from a helper-mediated or borrowed-authority path should not look identical to one authored directly at a local interactive prompt.

So Schell should likely preserve whether memory came from:
- direct local interactive work,
- remote peer work,
- observe-only lane,
- control/update lane,
- debug exec,
- restored transcript,
- imported/shared history,
- or helper-mediated command launch.

That is not bureaucracy.
It is how the shell avoids flattering the operator with false sameness.

## 4) ViewFS reinforces per-peer and per-session separation

ViewFS already keeps session state, live feeds, observe/attach/control lanes, and durable history separate.
That is the right neighboring compression here too.

For Schell, the implication is simple.
Recent commands and recent directories should likely be partitioned by at least:
- peer,
- lane,
- and whether the source is live, restored, or merely historical.

That is much better than one global “recent” bucket.

## 5) Steward reinforces freshness-scoped memory chrome

Steward’s current emphasis on semantic epochs, label surfaces, and trusted chrome says that visible memory aids should remain freshness-scoped and source-labeled.
That transfers cleanly.

A “recent command” or “recent directory” chip should be allowed to be:
- current,
- restored,
- imported,
- synced,
- historical,
- or drifted.

That keeps recall helpful without letting stale chrome impersonate live footing.

## 6) Companion-compatible no-regret move

Schell does **not** need to freeze one final history database, sync model, or cockpit UI.
It only needs a few bounded rules:

### A) Partition recall by peer

Local and remote memory should not default to one flat stream.

### B) Keep recent directories inside the same footing model

Directory memory should carry peer and cwd truth, not act like a universal jump list.

### C) Preserve lane/provenance posture

Observe-only, attach, control, debug, restored, imported, and local-interactive memory should not collapse into one memory kind.

### D) Show drift before stronger reuse

Peer drift, cwd drift, wallet drift, and route drift should be visible before staging or rerunning a remembered command.

### E) Keep command-frame memory richer than naked line memory

When shell-attested frames exist, they are the better object for copy, reveal, stage, and re-input.

## 7) Compact conclusion

The SlopOS-compatible answer is not “smarter global history.”
It is:
**remember more, but partition memory by peer/cwd/lane/authority posture so command recall, recent directories, and semantic-history comfort stay powerful without pretending old footing is still current power.**

That is a design-phase-safe move because it makes Schell much more humane without forcing the final history backend, sync contract, or cockpit architecture.
