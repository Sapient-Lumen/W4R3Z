# Question machine

Schell should not merely *list* open questions.
It should preserve the machinery for answering them slowly and honestly.

## Why this exists

Shell projects often fail in one of two ways:

1. they answer foundational questions too early and end up trapped by syntax, compatibility, or runtime commitments; or
2. they leave the hard questions diffused across chat transcripts and prose, so the project quietly spends assumption authority without noticing.

This archive uses a **question machine** to avoid both failures.

## The kernel object

Every load-bearing question should have a durable entry in `QUESTION-REGISTRY.json` with:

- a stable id,
- the question text,
- current state,
- why it matters,
- current pressure,
- next proof surface,
- blockers or boundaries,
- accepted nearby non-answers,
- and a discharge rule.

## Question states

- `open` — named, important, and not yet narrowed.
- `narrowed` — the question has a bounded scope and a preferred proof surface.
- `prototyping` — an experiment, mock, corpus, or implementation probe is underway.
- `answered-provisionally` — the archive has a working answer but still treats it as reversible.
- `bound` — an ADR or equivalent canonical surface has intentionally frozen the answer.
- `retired` — the question no longer carries design pressure.

## Moves we allow

- ask a new question,
- narrow a question,
- split one question into smaller ones,
- fuse duplicates,
- promote an answer,
- or retire a question when the project no longer depends on it.

What we do **not** allow is letting a question disappear because a nearby design memo sounds confident.

## Good pressure, bad pressure

A question earns movement when one of these appears:

- a prototype can falsify it,
- outside research sharpens the options,
- a sibling datacube exposes a useful import pressure,
- or repo/implementation work is blocked on it.

A question does **not** earn movement just because the archive feels unfinished.

## Relationship to RFCs and ADRs

- Questions keep uncertainty visible.
- RFCs package candidate answers.
- ADRs bind the answers the project is actually willing to carry.

Questions should therefore point *toward* RFCs and ADRs, not be replaced by them until the decision is earned.
