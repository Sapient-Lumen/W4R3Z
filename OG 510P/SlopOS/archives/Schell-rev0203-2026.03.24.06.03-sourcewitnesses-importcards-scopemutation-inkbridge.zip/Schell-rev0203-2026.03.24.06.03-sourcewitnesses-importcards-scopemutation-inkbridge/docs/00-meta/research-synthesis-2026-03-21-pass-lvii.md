# Research synthesis, pass LVII (2026-03-21)

This pass keeps one fresh design rule in focus:
**Schell should absolutely steal MCP-style tool catalogs, explicit resource attachments, reusable prompt templates, interactive app/forms, and structured elicitation — but only if every one of those surfaces stays visibly cataloged, scope-labeled, and weaker than exact reviewed shell truth.**

This seam matters because the current agent/tool ecosystem has become genuinely impressive.
Modern hosts can discover tools, attach external resources, expose prompt templates, render rich app UIs, and ask structured questions mid-task.
Those are not gimmicks anymore.
They are becoming the normal way powerful AI+terminal systems feel pleasant.
But the old trap is also back in a new outfit:
when tool discovery, helper UIs, and structured forms quietly widen what the system can do, operators stop knowing whether they are still reviewing a proposal or already living inside a second authority plane.

## 1) MCP's split is already a terrific Schell clue: keep tool classes distinct

The current MCP specification keeps a very useful separation of concerns.
Servers may expose **tools**, **resources**, and **prompts**, while client features separately include **sampling**, **elicitation**, and related utilities.
The architecture docs also keep the data layer and transport layer distinct, and emphasize lifecycle management plus capability negotiation.
That is exactly the sort of separation Schell should admire.
Tool invocation, resource attachment, prompt-template reuse, structured user input, and transport choice are nearby concepts, but they are not the same object.
Schell should not flatten them into one vague “integration” blob.
See: https://modelcontextprotocol.io/specification/2025-11-25/basic
See: https://modelcontextprotocol.io/docs/learn/architecture
See: https://modelcontextprotocol.io/specification/2025-06-18/server/tools
See: https://modelcontextprotocol.io/specification/2025-06-18/server/resources
See: https://modelcontextprotocol.io/specification/2025-06-18/server/prompts

## 2) The roadmap gives a nice anti-overcommitment lesson

The MCP roadmap now says the project will not introduce additional official transports this cycle because keeping the set small protects ecosystem compatibility.
That is a terrific Schell lesson.
The right move is not to freeze one giant plugin/runtime/transport story early.
The right move is to prove a compact witness model that can survive multiple transports and multiple host embeddings.
See: https://modelcontextprotocol.io/development/roadmap

## 3) VS Code shows what a disciplined catalog feels like

VS Code's MCP docs are rich with small, stealable ideas.
It supports explicit install in the user profile or the workspace, guided configuration into `mcp.json`, optional dev-container wiring, per-tool toggles, explicit trust prompts before starting a server, sandboxing for local stdio servers, resource attachment flows, prompt templates as slash commands, and inline MCP Apps support.
That is not just a pile of features.
It is a usable lesson in **scope**, **trust**, and **catalog legibility**.
The most important detail may be the obvious one: the product does not pretend all configured servers are equally safe.
It says local servers can run arbitrary code, asks for trust, and now supports sandboxing.
Schell should steal that posture.
See: https://code.visualstudio.com/docs/copilot/customization/mcp-servers
See: https://code.visualstudio.com/api/extension-guides/ai/mcp
See: https://code.visualstudio.com/updates/v1_109
See: https://code.visualstudio.com/updates/v1_112

## 4) The auto-discovery pattern is valuable and dangerous at the same time

VS Code can automatically detect MCP server configurations from other applications such as Claude Desktop.
That is undeniably convenient.
It is also exactly the kind of move that can silently widen a tool surface if the host blurs discovery with approval.
Schell should learn from the convenience while staying stricter:
found is not trusted,
configured is not started,
started is not approved for every tool,
and installed somewhere else is not the same thing as admitted here.
See: https://code.visualstudio.com/docs/copilot/customization/mcp-servers

## 5) Anthropic's current MCP connector sharpens the server/tool boundary nicely

Anthropic's current MCP connector docs are unusually helpful here.
They emphasize direct connection to remote MCP servers from the Messages API, support multiple servers in one request, and allow enabling all tools, allowlisting specific tools, or denylisting tools, with per-tool configuration available too.
Claude Code also now recommends HTTP for remote MCP servers and exposes `/mcp` management inside supported IDE integrations.
That is exactly the kind of bounded flexibility Schell should steal.
Tool catalogs are stronger when they remain explicit enough to scope, subset, and review.
See: https://platform.claude.com/docs/en/agents-and-tools/mcp-connector
See: https://code.claude.com/docs/en/mcp
See: https://code.claude.com/docs/en/ide-integrations

## 6) Elicitation is worth stealing — but only as exact field review, not ambient questioning power

Recent MCP/Claude evolution is especially interesting because it puts structured questions directly into the workflow.
MCP has an **elicitation** client feature in the current spec surface.
Claude Code's March 2026 changelog says MCP servers can now request structured input mid-task via interactive dialogs with form fields or a browser URL.
VS Code's recent chat work similarly shows structured in-chat questions and plan-agent alignment flows.
This is a genuinely great idea for Schell.
But the right import is narrow: structured elicitation should mint a visible field card with provenance, not a magical conversational power that can keep fishing for authority until it gets it.
See: https://modelcontextprotocol.io/specification/2025-11-25/basic
See: https://code.claude.com/docs/en/changelog
See: https://code.visualstudio.com/updates/v1_109

## 7) Apps/UIs are real now, which makes review posture more important, not less

MCP Apps are now an official extension, and both VS Code and ChatGPT have moved to support them.
The official MCP Apps overview describes the pattern clearly: a tool declares a UI resource and the host renders an interactive HTML interface in place.
OpenAI's Apps SDK reinforces the same split: an MCP server is required, a web component is optional, tools are the contract, and tool results can carry transcript-visible `structuredContent`/`content` while `_meta` is delivered only to the component.
That hidden-to-component-only `_meta` split is a huge Schell clue.
Rich UI can be wonderful, but not every bit of app state should automatically become transcript truth or model-visible authority.
See: https://modelcontextprotocol.io/extensions/apps/overview
See: https://developers.openai.com/apps-sdk/quickstart
See: https://developers.openai.com/apps-sdk/reference
See: https://developers.openai.com/apps-sdk/plan/tools
See: https://developers.openai.com/apps-sdk/changelog

## 8) Metadata quality matters more than people admit

OpenAI's current Apps SDK docs are blunt that metadata quality affects whether the host chooses a connector at all.
That is extremely useful and slightly scary.
Names, descriptions, and parameter docs are not authority — but they do shape what gets invoked.
Schell should therefore treat tool metadata as a **routing hint with provenance**, not as policy or permission.
Bad metadata can trigger accidental activations just as surely as a bad alias or bad autosuggestion can.
See: https://developers.openai.com/apps-sdk/guides/optimize-metadata
See: https://developers.openai.com/apps-sdk/app-submission-guidelines/

## 9) Channels and pushed events show the next foot-gun early

Claude Code channels are another strong hint.
They let an MCP server push messages, alerts, and webhooks into a running session, but the docs are careful: this is research preview, requires the session to be open, and for always-on behavior you must run Claude in a persistent terminal/background setup.
That is precisely the kind of honesty Schell should preserve.
Push/event channels can feel magical, but they are not proof of durable background work, not a reason to invent a hidden message bus, and not an excuse to weaken session-liveness truth.
See: https://code.claude.com/docs/en/channels

## 10) The stealable move: tool-catalog witnesses

The best decision-light move now looks like this:
1. keep **server**, **tool**, **resource**, **prompt**, **app**, and **channel** surfaces visibly distinct,
2. make every catalog item wear source, scope, transport, trust, and sandbox posture,
3. make resource attachment explicit instead of hidden memory,
4. keep prompt templates/playbooks reusable but weaker than exact executable artifacts,
5. let app/forms improve review and parameter capture without auto-running stronger actions,
6. keep tool invocation and tool result cards transcript-visible with exact server/tool identity,
7. keep component-only hidden state clearly weaker than transcript truth,
8. keep auto-discovery weaker than explicit trust/admission,
9. and keep pushed-event channels visibly weaker than durable background grant truth.

That would make Schell feel dramatically more modern without freezing one final MCP substrate, plugin marketplace, app runtime, transport stack, or channel model.

## 11) A compact first proving slice

A compact proof could show:
- one tool-catalog strip with server/scope/transport/sandbox badges,
- one explicit resource attachment card,
- one reusable prompt template/playbook with argument fill,
- one tool invocation card with exact server/tool identity,
- one inline app/form panel that lands edits back into reviewable shell input or a review card,
- one structured elicitation dialog with provenance and exact field coverage,
- one auto-discovered server that is found but not yet trusted,
- one sandboxed local server,
- and one pushed event that stays visibly session-local rather than durable background truth.

That is already enough to make Schell feel super awesome without hardening the final backend too early.

## 12) Decisions intentionally kept open

This pass does **not** freeze:
- one final MCP-or-not plugin substrate,
- one server packaging/distribution ecosystem,
- one app runtime/UI engine,
- one transport policy beyond explicit witnessing,
- one auto-discovery policy,
- or one channels/background automation treaty.

The no-regret move is smaller:
**steal explicit tool catalogs, resource attachments, prompt-template reuse, app/form review surfaces, and structured elicitation — but keep all of them visibly cataloged and weaker than exact reviewed shell truth.**
