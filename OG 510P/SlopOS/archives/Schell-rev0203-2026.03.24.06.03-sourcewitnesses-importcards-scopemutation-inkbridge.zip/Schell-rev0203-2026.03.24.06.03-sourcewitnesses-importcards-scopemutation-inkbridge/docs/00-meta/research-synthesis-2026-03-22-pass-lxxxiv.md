# Research synthesis, pass LXXXIV (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should steal the best current file-link, remote-file, semantic-history, and file-watch ideas — verified file links, per-line cwd grounding, explicit file hyperlinks, SSH-aware remote-file actions, and project-root watchers — but it should keep path text, path ground, locality, existence proof, watch freshness, and strongest action separately named so “this looked like a file path” never impersonates “this is the exact file object and state I can safely act on right now.”**

This seam matters because terminals become magical the moment path-like output stops being dead text.
They also become misleading in exactly the same place.
The current ecosystem now gives Schell both the delightful patterns and the cautionary evidence.

## 1) The best current terminals ground file actions with more context than plain text

iTerm2’s semantic-history feature is still one of the sharpest niche ideas in terminal UX.
Its docs say Semantic History is used to open a file when you Cmd-Click on it and that the current working directory for each line in the terminal is tracked to help find files.
Its shell integration docs also say iTerm2 can keep track of command history, current working directory, host name, and more, even over SSH.
See: https://iterm2.com/documentation-preferences-profiles-advanced.html and https://iterm2.com/documentation-shell-integration.html

VS Code’s terminal docs point in the same direction, but with a stronger safety flavor.
They say file links are links to files that have been verified to exist on the system, and folder links likewise open folders rather than only guessing from text.
Its shell integration docs add working-directory detection and command detection to make more of the terminal legible.
See: https://code.visualstudio.com/docs/terminal/basics and https://code.visualstudio.com/docs/terminal/shell-integration

The stealable lesson is simple: path UX gets much better when the terminal admits contextual ground and verification posture.
The caution is equally simple: cwd context, file existence, host locality, and current exact target are not the same fact and should not collapse into one flattering click target.

## 2) Explicit file hyperlinks and typed path actions are worth stealing

kitty’s hints mode is unusually revealing here.
Its docs say users can select anything that looks like a path or filename and insert it into the terminal, open path-plus-line-number targets in an editor, and open explicit hyperlinks marked by the program running in the terminal, for example by `ls --hyperlink=auto`.
Separately, kitty’s remote-file docs say that in an SSH session a user can run `ls --hyperlink=auto` and then click a file name to Edit, Open, or Download the remote file.
GNU Coreutils now documents `ls --hyperlink[=when]` as outputting codes recognized by some terminals to link to files using the `file://` URI format.
See: https://sw.kovidgoyal.net/kitty/kittens/hints/ and https://sw.kovidgoyal.net/kitty/kittens/remote_file/ and https://www.gnu.org/software/coreutils/manual/coreutils.html

This is a rich clue for Schell.
The right object is not “paths are clickable now.”
The right object is a ladder: insert / reveal / open / edit / download / watch, with source and locality chips that say whether the subject is local, remote, hyperlink-exact, cwd-strengthened, or only heuristic.

## 3) Path strings are not stable object identity

The kernel and capability systems keep reinforcing the same lesson.
Linux path-resolution docs say relative paths begin at the current lookup directory and symlink resolution can redirect lookup during traversal.
`openat2(2)` adds stronger controls such as `RESOLVE_NO_MAGICLINKS` and explicitly warns that unknowingly opening magic links can be risky.
Fuchsia’s namespace docs say there is no global root namespace, that object paths may not be meaningful across namespace boundaries, and that access depends on the objects already in hand.
Its “Life of an Open” notes that files and sockets may both look open-able to callers while actually speaking different underlying protocols.
See: https://man7.org/linux/man-pages/man7/path_resolution.7.html and https://man7.org/linux/man-pages/man2/openat2.2.html and https://fuchsia.dev/fuchsia-src/concepts/process/namespaces and https://fuchsia.dev/fuchsia-src/concepts/filesystems/life_of_an_open

That means Schell should stop letting rendered path text masquerade as the file.
A great shell+terminal should be willing to say:
- this is only text that looks path-like,
- this is cwd-grounded text,
- this is a hyperlink-exact target,
- this is a remote file candidate,
- this is a synthetic/generated view object,
- or this is an exact file card already resolved inside the current ground.

## 4) Watch streams are useful precisely because they are weaker than exact file truth

Watchman’s current docs provide some of the clearest evidence here.
They say a query is synchronized by creating a unique cookie so the query sees an up-to-date view, that watches may be restricted to explicit project roots via `root_files` and `enforce_root_files`, and that `illegal_fstypes` is largely meant to prevent use on network-mounted filesystems.
They also say a recrawl happens when Watchman believes it has lost sync with filesystem state, often because the kernel signaled `IN_Q_OVERFLOW`, and that recovery means recursively scanning the tree again; Watchman’s install docs add that overflow recovery can avoid missed legitimate changes at the cost of spurious notifications.
See: https://facebook.github.io/watchman/docs/cookies and https://facebook.github.io/watchman/docs/config and https://facebook.github.io/watchman/docs/troubleshooting and https://facebook.github.io/watchman/docs/install.html

Linux watcher semantics reinforce why Schell should keep watch truth smaller than file truth.
`inotify(7)` says watched files or directories can be deleted or moved, with `IN_DELETE_SELF`, `IN_MOVE_SELF`, and `IN_IGNORED` reshaping what the watch still means.
`fanotify(7)` says notification-group entries refer to files/directories by inode number and mounts by mount ID, surviving some renames within a mount but being deleted on moves to another mount or unmount.
See: https://man7.org/linux/man-pages/man7/inotify.7.html and https://man7.org/linux/man-pages/man7/fanotify.7.html

The lesson for Schell is not “avoid watch UX.”
It is “make watch roots and freshness posture first-class.”
A watch-backed result row should be allowed to say “observed under root X, freshness synced by cookie, later recrawled, existence may have drifted.”
That is much more honest than letting a live-looking file row impersonate a current exact target.

## 5) What Schell should now do

This pass points to a compact, high-value file/path model:
- **file cards** that distinguish exact object, rendered path text, and strongest safe action,
- **path-ground witnesses** for cwd-relative, view-relative, descriptor-relative, hyperlink-exact, and remote-grounded resolution,
- **locality chips** for local / remote / synthetic / historical / imported / unknown,
- **existence posture** such as exact-verified / shell-attested / watch-observed / stale / unknown,
- **watch-root cards** that say what root is watched, how it was identified, and whether overflow/recrawl happened,
- **source chips** for plain text / explicit hyperlink / shell-known chapter / search result / watch row,
- **promotion rails** from path text to exact file card before stronger action,
- **parent-browse refusals** when the target is not exact enough,
- and **derived-view honesty** for generated trees, remote mirrors, or index-backed file lists.

## 6) Decisions intentionally kept open

This pass does **not** freeze:
- one final file-card schema,
- one final watcher backend,
- one final remote-file transport,
- one final namespace/view model for local shells,
- one final file browser or tree UI,
- or one final hyperlink/path grammar.

The no-regret move is smaller:
**give Schell file cards, path-ground witnesses, locality chips, watch-root cards, and overflow/recrawl honesty so file interaction becomes dramatically better without letting path text, watch state, or synthetic views impersonate exact object truth.**
