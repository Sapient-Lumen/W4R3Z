# Question advancement pass III — 2026-03-20

This pass makes progress by tightening proof surfaces, not by declaring final answers.

## Advancements admitted

### Q-0002 — smallest portable text-only core

Status changes from **narrowed** to **prototyping**.
The archive now has enough pressure to stop speaking only in principles and start specifying how semantic boundaries survive into transcripts.
The next proof surface is now a transcript-truth document rather than the first portable-core sketch alone.

### Q-0006 — background presence in operator UX

Status changes from **open** to **narrowed**.
The archive now has enough SlopOS pressure to say what the background shelf must preserve:
request identity, live-grant truth, expiry, autostart posture, and the last receipt or denial that changed state.
It is still too early to freeze exact commands or widget layout.

### Q-0007 — what denials should teach

Status changes from **open** to **narrowed**.
The archive can now say that denial help should be:

- stage-local,
- narrow in scope,
- explicit about what is missing,
- explicit about whether retry is safe,
- and non-widening by default.

It is still too early to freeze a denial schema or auto-repair system.

### Q-0008 — which Rust stack pieces are worth adopting first?

Status remains **prototyping**, but the archive now names a cleaner first stack slice:
text interaction + tracing + transcript proof before TUI/PTY breadth.
That is not a final stack; it is a tighter proving lane.

## What this pass still refuses

- final shell syntax,
- final shell↔terminal transport,
- any mandatory TUI stack,
- PTY-heavy compatibility work as the first proof,
- and denial systems that synthesize hidden privilege widening.

## Local law reaffirmed

A question only advances when at least one of these becomes sharper:

- the next proof surface,
- the accepted nearby non-answer,
- the boundary on what still cannot be decided,
- or the discharge condition.

This keeps the question machine from turning into decorative status churn.
