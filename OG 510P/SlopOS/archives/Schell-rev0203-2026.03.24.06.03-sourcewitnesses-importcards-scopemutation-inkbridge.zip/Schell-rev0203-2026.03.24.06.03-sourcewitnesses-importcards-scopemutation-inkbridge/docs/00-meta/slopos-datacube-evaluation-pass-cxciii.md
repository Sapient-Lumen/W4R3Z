# SlopOS datacube evaluation — 2026-03-23 — pass CXCIII

**Schell should treat shorthand as a local proposal or a visibly named parse rule rather than a second hidden execution selector, because SlopOS and the companion cubes keep rewarding exact execution identity, explicit routing, visible labels, and refreshed footing.**

## 1) SlopOS keeps exact execution identity narrower than command folklore

RFC-0115 in SlopOS keeps pressing the same lesson: command text is not the whole execution truth, script entry should not become a second ambient executable selector, and the reviewed exec selector should end at one exact executable object rather than a late name-based reopen.
That pressure matters directly here.
A shorthand token like `gco`, `ll`, or `kctx` can be great operator comfort, but it should stay weaker than the exact command-identity witness Schell will actually spend.

So the companion-safe import is:
- shorthand may be delightful,
- compatibility packs may exist,
- imported aliases may help migration,
- but exact command identity still needs its own explicit witness lane.

## 2) SlopOS plumb posture argues for inspect/stage, not magical rewrite

RFC-0117 keeps plumb envelopes request-local, explicit-invocation, and non-authoritative.
That suggests a useful Schell boundary:
shorthand expansions should prefer **inspect / insert / stage / review** posture over hidden execute-now magic.
A local alias reveal or abbreviation expansion can be excellent, but it should still confess its source, whether it was editor-local or parser-local, and what exact expanded command identity now sits in the buffer.

## 3) Borrowed-mode pressure says helper-provided shorthand needs source labels

RFC-0118 keeps borrowed-mode default, scoped privilege brackets, and optional deny-only call-chain context.
That pressure maps cleanly onto shorthand packs.
If a repo helper, imported profile, compatibility pack, or assistant-suggested snippet introduces shorthand, Schell should keep that source visible.
Otherwise a tiny convenience layer quietly becomes a second authority plane.

## 4) ViewFS again supplies the best neighboring-state discipline

ViewFS keeps editable text, parse understanding, diagnostics, compiled packet, prepared action, and history distinct.
That same discipline should govern shorthand:
- typed token,
- editor-local expansion,
- parser alias rule,
- exact command identity witness,
- prepared action,
- and historical receipt

should remain neighbors rather than collapsing into one flattering "the shell knew what I meant" object.

## 5) Harbor, Ward, Steward, and Helm keep the shorthand seam honest

- **Harbor** reinforces label honesty, which matters when a token should say whether it came from typed abbreviation, parser alias, imported compatibility pack, or shared runbook.
- **Ward** reinforces revalidation pressure, which matters when old shorthand definitions may have drifted and historical lines should not silently mean today's expansion.
- **Steward** reinforces trim/freshness posture, which matters when migration or compatibility shorthand is intentionally local and maybe short-lived.
- **Helm** reinforces omission/miss posture, which matters when a shorthand receipt should admit what was expanded, what exact identity it resolved to, and what was never claimed.

Together they keep one rule sharp:
**shorthand can improve entry speed, but it must not erase exact execution identity, source labels, or changed-basis humility.**

## 6) What this still does not require Schell to decide

This seam does **not** require Schell to decide:
- one final alias syntax,
- one final abbreviation grammar,
- one final snippet language,
- one final compatibility-import story,
- one final function/workflow/runbook boundary,
- or one final history serialization for shorthand definitions.

The archive only needs to prove the honesty stack that says:
- what token was typed,
- what expansion was shown in the editor,
- what parser rule or compatibility pack participated,
- what exact command identity now stands ready,
- and what historical residue is safe to share or replay.

## 7) Compact conclusion

SlopOS keeps exact execution identity narrow and explicit.
ViewFS keeps neighboring editing and action states separate.
Harbor, Ward, Steward, and Helm keep labels, freshness, revalidation, and omission honest.

So the next Schell move should be:

**add abbreviation receipts, alias reveals, imported-shorthand labels, and exact command-identity compare so Schell can steal shorthand comfort without letting convenience syntax quietly become a hidden second command resolver.**
