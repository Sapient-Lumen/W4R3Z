# Research synthesis, pass XX (2026-03-21)

This pass focuses on another load-bearing seam:
**remote shell comfort keeps getting better, but current tools repeatedly blur fresh connection, reused attach, borrowed-local authority, and provisional local prediction. Schell should steal the comfort while making peer truth and attach posture much more explicit.**

## 1) WezTerm makes remote domains feel first-class

WezTerm’s multiplexing docs describe SSH domains that connect to a remote wezterm multiplexer over SSH, then talk to the remote daemon through a unix-domain-socket-style mechanism. The docs also say SSH domains can auto-populate from `~/.ssh/config`, and that hosts get both plain `SSH:` and multiplexing `SSHMUX:` names. That is a great product clue for Schell: “remote” is not one thing, and domain kind should be explicit instead of collapsing plain SSH, mux-attached SSH, and local sessions into one comforting blur. See: https://wezterm.org/multiplexing.html

## 2) kitty shows both the upside and the danger of rich remote comfort

kitty’s SSH kitten promises automatic shell integration on remote hosts, easy cloning of local shell/editor config, connection reuse, and optional forwarding of the kitty remote-control socket. The same docs warn that forwarding the remote-control socket gives software on the remote host full access to the local computer, and say to do it only for trusted remote hosts. That is a nearly perfect external pressure source for Schell: remote lanes should surface exactly when they can borrow strong local powers instead of hiding that fact behind “comfortable remote login” UX. See: https://sw.kovidgoyal.net/kitty/kittens/ssh/

## 3) Nested remote hops already reveal exactness limits

kitty’s remote-file docs say nested SSH sessions are not supported robustly without the SSH kitten and that otherwise the feature will always try to copy files from the first SSH host because kitty cannot detect and follow nested SSH sessions robustly. This is a strong hint that Schell should say when it only knows the first hop, when the current subject is only approximately remote, and when rich actions need to downgrade because exact hop knowledge is missing. See: https://sw.kovidgoyal.net/kitty/kittens/remote_file/

## 4) Ghostty’s SSH helpers are valuable exactly because they stay opt-in

Ghostty’s docs and release notes describe `ssh-terminfo` and `ssh-env` features that either copy Ghostty’s terminfo to the remote machine or fall back to `xterm-256color`. The release notes explicitly say both features are opt-in because they require overriding the `ssh` command in the shell and that this is not without risk. That is a very Schell-compatible lesson: remote bootstrap helpers can be excellent, but they should remain explicit posture, not ambient startup magic. See: https://ghostty.org/docs/help/terminfo and https://ghostty.org/docs/install/release-notes/1-2-0

## 5) OpenSSH keeps warning that forwarding and reuse are not morally free

The OpenBSD `ssh_config` manual says agent forwarding should be enabled with caution because users who can bypass file permissions on the remote host can access the local agent and perform operations with the loaded identities. The same manual says `ControlMaster` lets sessions share one network connection and notes that X11 and ssh-agent forwarding over multiplexed connections use the forwarding from the master connection. It also documents `HostKeyAlias`, `StrictHostKeyChecking`, and `CheckHostIP`, all of which reinforce the same point: remote identity and borrowed-local authority deserve explicit treatment. See: https://man.openbsd.org/ssh_config

## 6) VS Code Remote-SSH is a good lesson in attach honesty

VS Code’s Remote-SSH docs say the extension installs VS Code Server on the remote host and that terminals opened in that window automatically run on the remote host. The troubleshooting docs add that the server is started with a randomly generated key, that socket mode can lock the server down to a particular user, and that systems that route each SSH connection to a different node can break the experience unless `ControlMaster` is used so both connections hit the same node. The same docs recommend using a separate SSH key for development hosts. Schell should copy the product honesty here: say when the remote lane is really executing on the remote peer, say what continuity helper is in play, and make cluster / attach assumptions visible. See: https://code.visualstudio.com/docs/remote/ssh and https://code.visualstudio.com/docs/remote/troubleshooting

## 7) Mosh points to a valuable but explicitly provisional interaction class

Mosh says it supports roaming, provides intelligent local echo and line editing of user keystrokes, and underlines outstanding predictions so users are not misled. That is a brilliant clue for Schell. A future shell+terminal can absolutely steal local prediction and “stay connected while the network moves” ergonomics, but it should keep those predictions visually provisional and separate from exact remote witness. See: https://mosh.org/

## 8) A no-regret Schell remote cluster is visible now

A careful import from these systems is not “become an IDE” or “become SSH with extra badges.”
It is smaller:
- keep remote **domain kinds** explicit,
- keep **peer witness** and **attach posture** compactly visible,
- keep **borrowed-local authority** explicit when remote lanes can touch local agents, control sockets, or host-side helpers,
- keep **bootstrap helpers** opt-in and transcript-visible,
- keep **nested-hop uncertainty** honest,
- and keep **predictive local echo** visibly provisional.

That feels like the right next ratchet for Schell:
**copy the comfort, but make remote truth and borrowed-local authority impossible to forget.**
