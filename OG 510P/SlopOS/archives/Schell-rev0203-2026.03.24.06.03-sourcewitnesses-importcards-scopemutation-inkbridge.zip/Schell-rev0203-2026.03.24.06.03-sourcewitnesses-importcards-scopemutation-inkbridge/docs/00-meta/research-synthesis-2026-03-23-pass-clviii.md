# Research synthesis — 2026-03-23 — pass CLVIII

This pass tightens the next seam instead of widening “auth” into one giant product:
**local broker comfort is worth stealing, but local presence proof, broker session lease, credential sink, and current account authority should stay separately named.**

The strongest current lesson is not merely that CLIs can “log in with your browser”.
It is that modern CLI auth and secret tools now lean on several different mediators:
- an OS auth broker,
- a desktop app broker,
- a browser on the same machine,
- a browser on another machine,
- a credential store or disk cache,
- and a later active account/profile choice.

That points to a good next Schell move:
**broker witnesses, presence leases, and local-mediator humility** rather than a vague “signed in” or “already authorized” glow.

## 1) Azure CLI shows that a local OS broker is a distinct truth family

Current Azure CLI docs say that starting with version 2.61.0, Azure CLI uses Web Account Manager (WAM) on Windows and browser-based login on Linux and macOS by default.
The same docs describe WAM as an authentication broker that runs on the user’s machine and manages authentication handshakes and token maintenance for connected accounts.
They also say WAM brings support for Windows Hello, conditional access policies, and FIDO keys.

That is a crucial shell+terminal lesson.
A broker-mediated local presence check is not the same thing as “browser auth happened”, and it is not the same thing as “the shell now has exact current authority”.

Schell should therefore keep `broker used`, `presence challenge kind`, `broker session still live`, and `current account/subscription chosen` as different truths.

## 2) 1Password CLI proves the local-app mediator pattern is richer than a one-shot unlock

1Password’s current CLI security docs say each new terminal window or tab requires biometric authorization, establishing a 10-minute session that refreshes on each use.
They also say authorization is per account, expires after 10 minutes of inactivity with a 12-hour hard limit, and is scoped using a session credential tied to the current tty or process start time.
The prompt shows both the account being authorized and the process requesting access.

That is excellent evidence for Schell.
A good shell+terminal can be dramatically better if it treats “local mediator approved this terminal for this account for this long” as a typed lease instead of as invisible residue.

## 3) GitHub CLI and AWS CLI show that local sinks and cached sessions are separate from the auth step

GitHub CLI’s current docs say the default authentication mode is browser-based and that the resulting token is stored securely in the system credential store when possible, with plaintext-file fallback if secure storage is unavailable.
AWS’s current local-development login docs say the CLI can automatically refresh credentials for up to 12 hours, cache authentication data to disk, and also support a `--remote` mode that prints a URL and later asks for an authorization code.
The AWS SSO docs separately expose `--no-browser` and `--use-device-code` options.

So even when “login worked”, at least four different local truths still matter:
- where the account/session actually lives,
- what refresh or expiry rules apply,
- whether the sink is disk/keyring/broker/app scoped,
- and whether the final active profile/account binding changed here.

Schell should keep those visible instead of flattening them into one celebratory success line.

## 4) gcloud reinforces that relay steps and brokered local state should not collapse together

Current Google Cloud CLI docs distinguish ordinary browser login, `--no-browser` remote bootstrap on a second trusted machine with another local gcloud install, and `--no-launch-browser` flows that ask the user to copy a URL to another machine and paste a returned verification code back.
That is a reminder that “remote browser relay completed” and “this machine now has a locally adopted session” are different states.

Schell should steal the comfort of exact relay cards, copyable steps, and clear return anchors, while still keeping the local adopted session or profile switch as a separately named stronger fact.

## 5) Host-mediated external open is still weaker than downstream success

The current OpenAI Apps SDK exposes `window.openai.openExternal({ href, redirectUrl })` as a host-mediated request to open a vetted external link in the user’s browser.
That is a good general lesson beyond OpenAI itself.
Even when a trusted host mediates the browser jump, that act is still only the start of a downstream flow.

For Schell, that means local broker/app/browser mediation should remain bridges and witnesses.
They should not silently count as proof that the user finished the task, that the right account was bound, or that the resulting authority is now active in the current shell footing.

## 6) The concrete Schell move

Schell should add a compact **broker witness** family:
- **broker_family** — none / OS broker / desktop app mediator / credential-store helper / browser helper / unknown,
- **presence_proof** — none / biometric / device-password / OS-account / hardware-key / unknown,
- **subject_scope** — exact account / tenant / profile / vault / subscription / unknown,
- **session_scope** — terminal-local / tab-local / window-local / host-local / profile-local / unknown,
- **session_lease** — one-shot / idle-TTL / hard-cap / refresh-on-use / unknown,
- **sink_posture** — broker-held / keyring / app-held / disk-cache / plain-file fallback / env-only / unknown,
- **adoption_posture** — pending / imported / active-binding-updated / historical / revoked / expired,
- **reveal_target** — exact card showing what was approved, what expires when, and what stronger act remains separate.

That is enough to steal brokered convenience without freezing one final keyring, auth broker, desktop mediator, callback substrate, or account model.
