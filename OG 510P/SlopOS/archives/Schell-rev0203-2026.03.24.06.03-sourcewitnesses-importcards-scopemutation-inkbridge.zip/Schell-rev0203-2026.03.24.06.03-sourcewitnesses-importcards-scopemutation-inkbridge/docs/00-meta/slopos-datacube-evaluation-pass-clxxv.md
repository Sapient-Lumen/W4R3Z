# SlopOS datacube evaluation — 2026-03-23 — pass CLXXV

**Schell should introduce one compact readiness strip, because SlopOS and the companion datacubes increasingly separate launch admission, presence, readiness, readiness generation, settlement, and historical residue instead of pretending that a visible room is automatically prompt-ready truth.**

## 1) SlopOS exact launch is still the hard floor, but it is not the same thing as prompt-ready truth

SlopOS keeps exact exec, cwd, env, and startup closure narrow and explicit.
That remains the hard floor.
But exact launch footing only tells us what was admitted to start.
It does not answer whether:
- the shell finished startup,
- prompt markers are back,
- cwd freshness has been reasserted,
- rich shell integration is live,
- or stronger prompt-local actions are honestly available.

That means Schell needs one smaller readiness-facing witness rather than broadening launch truth itself.

## 2) SlopOS launch-completion narrowness argues against overclaiming readiness

SlopOS keeps launch-completion narrow and resists turning generic launch into proof that downstream work rendered, finished, or was even meaningfully seen.
That is exactly the right pressure here.
A launched terminal room or shell helper surface should not quietly become `ready`, `interactive`, or `safe for richer actions` unless the shell+terminal has fresher evidence.

## 3) Steward already has the adjacent lifecycle split that Schell needs

Steward now explicitly separates:
- activation cause,
- presence advertisement,
- readiness,
- readiness generation,
- and other lifecycle truths such as liveness evidence and stability windows.

That is almost a direct specification for a Schell readiness strip.
A room can exist, be advertised, or have just landed while still lacking fresh prompt/cwd/capability truth.
The strip should say exactly that.

## 4) ViewFS, Helm, and Ward add the right pressure on claim strength and decay

- **ViewFS** keeps subject identity, placement, and current handle rights distinct, which suggests Schell should not flatten current shell readiness into current carrier identity.
- **Helm** keeps settlement narrower than local success, which suggests a readiness strip should remain descriptive and should not quietly become completion or success proof.
- **Ward** keeps continuous signals source-labeled and cooling over time, which is a strong clue that first-frame readiness can later decay into historical residue without pretending it is still live control truth.

## 5) The companion-safe answer is one tiny readiness strip

The smallest good import is a **readiness strip** attached to newly launched, restored, reattached, or repaired room-like subjects.
It should say:
- whether the PTY/runtime surface is live,
- whether a shell is present and a prompt is currently caught,
- whether cwd/prompt freshness are current or stale,
- what shell-integration quality is available,
- and what the strongest honest next move is now.

That object is enough to make the shell+terminal feel dramatically nicer while staying decision-light.

## 6) What this does not require Schell to decide yet

A readiness strip does **not** require Schell to decide:
- one final shell-integration protocol,
- one universal prompt-marker grammar,
- one global timeout policy,
- one giant lifecycle browser,
- or one rule that a visible pane equals prompt-ready truth.

## 7) Compact conclusion

SlopOS keeps exact launch small and keeps completion/activation narrower than folklore wants.
Steward already separates presence, readiness, and readiness generation.
ViewFS keeps carrier identity distinct from current rights, Helm keeps settlement narrow, and Ward helps fresh status cool into residue.

So the next Schell move should be:

**add tiny readiness strips so newly launched, restored, reattached, and repaired rooms can confess whether the shell is merely present or actually prompt-ready, what integration quality is live, whether cwd/prompt freshness are current, and what stronger action is still honestly gated.**
