# Research synthesis — 2026-03-23 — pass CLXVIII

This pass keeps the archive decision-light while naming the next small but high-leverage luxury cluster:
**modern terminal tools keep getting better at attaching exact command-local context to new views, so Schell should introduce one carried witness packet that survives those view changes without recomputing authority from scratch.**

That is a strong seam because it improves honesty across chapter rows, hovers, watch cards, and help attachments without forcing one final protocol, chapter store, or export schema.

## 1) The ecosystem keeps proving that command-local context wants to travel

VS Code's shell integration continues to expose working-directory detection, command detection, decorations, and navigation, and its shell integration API explicitly models command line confidence and trust. Recent VS Code releases also added the ability to attach a terminal command to chat as context, sharing the command line, captured output, and exit code. Windows Terminal documents stable marks and shell-driven metadata, plus command- and output-local selection. WezTerm still keeps the substrate small with `OSC 7`, `OSC 133`, and `OSC 1337`, but uses those to support prompt jumps, same-cwd spawning, and command-output selection. iTerm2 continues to track command history, cwd, host name, and related shell integration facts, exposing command-local history per username/hostname combination. citeturn124944view0turn124944view5turn970631search1turn124944view1turn124944view3turn970631search0turn970631search6

The load-bearing lesson is not just “terminals know more now.”
It is that command-local context is now expected to travel into new places: chat, hovers, histories, output selectors, and helper panels.

## 2) Stronger handoff still needs typed trust and confidence

VS Code's API is especially useful here because it does not flatten everything into one magical trust label. It has a nonce for trusted shell-integration sequences, an `isTrusted` bit for whether a command line is safe to rerun without extra confirmation, and explicit confidence classes that distinguish low, medium, and high confidence based on how the command line was obtained. That is very close to the packet discipline Schell wants: visible richness should carry typed claim strength instead of vague certainty. citeturn124944view5

This suggests a no-regret Schell rule:
**every cross-view command handoff should carry a typed witness packet, not just copied text plus a flattering UI frame.**

## 3) Current terminals show the substrate; Schell can add the carried object

Windows Terminal's shell integration explains the basic mechanism clearly: shells emit escape-sequence metadata that the terminal can use to know more about what is happening. WezTerm likewise keeps the substrate intentionally compact and explicit with cwd plus prompt/input/output zones and optional user vars. Ghostty adds excellent prompt-aware navigation and output selection, but also reminds users that shell integration may need manual sourcing when shells are switched or run in less direct launch paths. kitty keeps showing the value of typed visible-text actions through hints and customizable open actions rather than one generic click. citeturn124944view1turn124944view3turn124944view2turn784620search0turn784620search2

The pattern is consistent:
- the substrate stays relatively small,
- terminals build a lot of delight on top,
- and the missing product move is a compact carried object that keeps those rich views in sync about what they really know.

## 4) Exact attachment is the best bright steal right now

VS Code's terminal-command attachment to chat is especially revealing because it shares exactly the command line, captured output, and exit code instead of asking the user to reconstruct that context manually. That is a direct product proof that attach-for-help becomes much better once command-local context stops being copy/paste ritual. The remaining improvement Schell can add is to carry not just command text and output, but also typed footing, freshness, decay posture, and strongest-next-verb honesty. citeturn970631search1turn124944view5

## 5) Specific ideas worth stealing right now

A few current ideas are particularly worth importing into Schell:
- VS Code's typed command confidence and trusted rerun gates, but generalized into a reusable witness packet. citeturn124944view5
- VS Code's exact command attachment into chat, but widened from `command + output + exit` into `command + packet + why bundle`. citeturn970631search1
- Windows Terminal's stable marks and command/output selection, but with carried packets so one command does not look materially different in each surface. citeturn124944view1turn970631search11
- WezTerm's small semantic substrate, because the packet can ride on a small protocol instead of waiting for a giant treaty. citeturn124944view3
- Ghostty's prompt-aware jumps/output selection and its manual-sourcing humility, because both reinforce that freshness and source posture must stay visible. citeturn124944view2
- kitty's typed hints/open-action model, because witness packets should feed typed next verbs instead of one universal smart click. citeturn784620search0turn784620search2

## 6) Compact conclusion

The next brilliant step for Schell is not to make every rich command view smarter independently.
It is smaller and safer:
**introduce one carried witness packet and one reachable why bundle so chapter truth can survive handoff across rows, hovers, watch cards, and help attachments without silently becoming recomputed magic.**
