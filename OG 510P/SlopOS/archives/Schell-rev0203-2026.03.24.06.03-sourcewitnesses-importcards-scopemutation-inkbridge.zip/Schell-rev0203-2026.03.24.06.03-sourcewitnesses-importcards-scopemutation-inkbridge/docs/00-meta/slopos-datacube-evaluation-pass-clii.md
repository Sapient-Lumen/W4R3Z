# SlopOS datacube evaluation — pass CLII

This pass asks a narrower companion-safe question than “should Schell support rich full-screen/TUI life?”
The better question is:
**how should Schell treat borrowed screen ownership and shell reentry so a returned prompt never overclaims current truth?**

## 1) SlopOS keeps warning against inherited ambient launch or session posture

Even while still in design phase, SlopOS keeps refusing the shortcut from “the surrounding environment already looked normal” to “that must be the exact reviewed baseline now.”
D-CAPSHELL in particular keeps pushing launch and automation away from inherited ambient environment, loader, signal, scheduling, and other hidden session state.

That is directly useful for Schell.
When a fullscreen app, resident room, or helper temporarily borrows the visible floor, the shell should not quietly inherit the post-return state as though it were unquestionably the clean baseline.
It should reassert or re-witness what matters.

## 2) ViewFS reinforces the difference between visible residue and exact current basis

ViewFS already separates exact basis, apply session, reconstructed object, and receipt.
That same discipline maps well to terminal return paths.
The last visible frame from a borrowed screen is useful evidence.
But it is not automatically the same thing as:
- a current live view,
- a shell-authenticated command chapter,
- or a fresh action basis.

So Schell should treat fullscreen residue and returned prompt chrome as witnesses until a stronger reclaim step occurs.

## 3) Steward reinforces the split between “the UI came back” and “the workflow is now cleanly resumed”

Steward keeps pushing countdown-versus-receipt honesty, freshness posture, repair cues, and bounded reset paths.
That suggests a direct shell lesson:
just because a room or full-screen app released the floor does not mean the shell has already regained exact footing.
A return path may still need a reclaim card, a baseline reassertion, or a reset card.

## 4) Helm strongly pressures exact handback and reset semantics

Helm's change cursors, reset cards, activity-scope truth, and action-warrant basis witnesses all make the same point:
a nearby visible thing is not enough.
The system should be able to say what exact scope is in play, what exact witness the current claim depends on, and what exact reset is required when that basis drifted or expired.

That pressure applies directly to prompt return.
A prompt-looking line after a borrowed-screen session may be:
- historical residue,
- visually inferred prompt-like text,
- shell-marked prompt reclaim,
- or fresh baseline-reasserted prompt truth.

## 5) What Schell should steal now

Schell should steal several excellent ideas, but import them under stronger honesty:
- active-prompt click affordances only after live reclaim,
- jump-to-prompt and command-aware paging only when mark confidence is good enough,
- compact borrowed-screen strips saying who owns the floor now,
- prompt-reclaim cards that say what exactly returned,
- baseline-reassert cards after fullscreen or room handback,
- and reset-required posture when mode/mark/basis truth is no longer clean enough for stronger prompt-local actions.

## 6) What Schell should refuse now

Schell should refuse:
- treating any visible prompt return as proof of clean shell reentry,
- silently carrying post-TUI or post-room terminal state forward as unquestioned prompt baseline,
- letting prompt-click/edit luxuries target merely prompt-like historical residue,
- and flattening borrowed-screen exit, shell reclaim, baseline reset, and durable command completion into one event.

## 7) Compact conclusion

The companion-safe answer is not to avoid fullscreen apps or prompt luxuries.
It is to make **borrowed screen ownership, shell reclaim, and baseline reassertion explicit**.
If Schell can say who owns the floor, what returned, how strong that return claim is, and what still needs reset, it can steal a lot of delight while staying aligned with SlopOS exactness during the design phase.
