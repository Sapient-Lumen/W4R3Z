# SlopOS datacube evaluation, pass XXVI

**Visible objects should become dramatically easier to inspect and route without letting clickability, previews, or helper choice quietly widen meaning. SlopOS keeps teaching the same lesson: open, reveal, safe-open, recent, and completion are different seams and should stay different even when the shell+terminal feels magical.**

This pass focuses on another tempting seam for Schell:
- file and directory links in output,
- URLs and object refs,
- exact reveal in a local browser/editor,
- safe-open for suspicious or imported things,
- and the dream of a terminal that can “just show me the thing” without lying.

That seam is dangerous because legacy terminals treat it as mostly harmless click sugar.
SlopOS keeps showing that this is where handler choice, target widening, hidden preview, and active-content surprises sneak back in.

## 1) SlopOS keeps exact reveal distinct from approximate browse

The current OpenURI show-item exactness boundary is one of the sharpest imports for Schell.
A request that means “show this exact item selected” stays that exact intent.
If the backend cannot do that faithfully, the request fails closed instead of silently opening the parent directory and calling that success.

That is a beautiful rule for shell+terminal object actions.
A visible path or deck card may offer:
- reveal exact item,
- open containing place,
- inspect metadata,
- or safe-open.

Those should not collapse into one flattering “open nearby” action.

The import is:
**reveal should mean reveal, not approximate browse.**

## 2) SlopOS OpenURI keeps open, handler choice, and session choice separate

The OpenURI family keeps reminding us that generic launch does not become:
- scheme-support oracle,
- selected-handler receipt,
- browser-profile chooser,
- callback channel,
- or launched-app completion truth.

That matters directly for terminal object affordances.
A clickable URL or file card should not silently decide:
- which app or helper is best,
- whether an existing browser/profile/session gets reused,
- whether focus moves,
- or whether the thing is now “open” in some durable sense.

The import is:
**a visible object action may request posture, but it should stay weaker than hidden handler and session policy.**

## 3) SlopOS safe-open posture is the right warning about suspicious content

The current `open_untrusted` posture is exactly the kind of discipline a custom shell+terminal needs.
Safe-open is object-only, `docref`-only, policy-routed, request-local, and explicitly not a generic URI or restore/import seam.
It is about bounded inspection/open, not hidden trust promotion.

That translates well to Schell.
A suspicious file or imported artifact found in terminal output should not jump straight from:
- visible path,
- to rich preview,
- to active viewer,
- to ambient trust.

The import is:
**safe-open should stay a separately named downgrade path rather than a secret behavior hidden behind ordinary open.**

## 4) SlopOS materialization and active-content boundaries make preview humility non-negotiable

The safe-open materialization boundary insists on request-local stable input rather than a live alias/write-through mount back to the mutable source.
The active-content boundary insists that viewers remain inert by default.
The quarantined result-preview boundary refuses ambient snippets, thumbnails, panes, or hover previews for risky objects.

That is a superb design lesson for Schell.
A terminal that sees:
- a markdown file,
- a PDF,
- a suspicious archive,
- a generated report,
- or an imported object

should not quietly let hover or one-click open become:
- live write-through preview,
- macro/script execution,
- helper launch,
- network fetch,
- or object-driven side effects.

The import is:
**preview is not harmless just because it feels observational.**

## 5) SlopOS recent-items posture warns against accidental reopen authority

The OpenURI recent-items boundary keeps local recents non-authoritative and separate from explicit document persistence.
That should shape terminal object cards too.

A visible object may have:
- recency,
- last-opened hints,
- project affinity,
- and related chapter refs.

But those should not count as:
- durable reopen grants,
- stable doc handles,
- target existence proof,
- or approval to open again without review.

## 6) What SlopOS pressures Schell to steal

The strongest import is not a giant object browser.
It is a small posture cluster:
- one explicit **object card** family,
- one **action ladder** separating inspect / reveal / open / safe-open / insert / attach,
- one **exact-reveal hold rule** when the backend cannot faithfully select the object,
- one **preview classification** that defaults to metadata-safe rows,
- and one **safe-open downgrade** for suspicious or imported objects.

## 7) What Schell should deliberately refuse

### Refuse click-equals-open

Visible object affordances should not collapse into one ambient launch path.

### Refuse reveal-equals-browse-nearby

Exact reveal and approximate browse are different meanings.

### Refuse safe-open as a hidden variant of open

If a dangerous object needs inert handling, say so explicitly.

### Refuse preview-equals-harmless

Hover panes and snippets are still object-handling behavior.

### Refuse recents-equals-reopen grants

Recent use may help discovery, but it should not become durable authority.

## 8) Current consequence for Schell

The best next step looks compact:
1. one **object card** for a path / URL / artifact ref,
2. one action ladder for **inspect / reveal / open / safe-open / insert / attach**, 
3. one **exact reveal** outcome that holds instead of degrading when the platform cannot faithfully select the target,
4. one **metadata-safe preview** default,
5. one **safe-open downgrade** for suspicious objects,
6. and one transcript slice showing reveal-vs-open-vs-safe-open honesty.

That is enough to make Schell feel much smarter around files, folders, URLs, and artifacts while still keeping preview engines, helper inventories, quarantine backends, and document-viewer treaties open.
