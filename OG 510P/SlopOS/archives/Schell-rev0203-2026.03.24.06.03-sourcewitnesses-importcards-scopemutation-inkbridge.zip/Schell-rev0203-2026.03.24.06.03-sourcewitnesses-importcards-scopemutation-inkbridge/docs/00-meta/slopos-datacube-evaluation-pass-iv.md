# SlopOS datacube evaluation — pass IV

This pass takes the new instruction literally:
Schell is now about the **shell and terminal together for SlopOS**.
The question is therefore not “where do we draw a giant wall?” but rather:

> how do we co-design shell and terminal tightly enough to feel native to SlopOS while still keeping the truth surfaces explicit and portable?

## Strongest SlopOS lessons right now

### 1) Exactness beats “helpful enough” fallback

The OpenURI show-item exactness boundary is one of the sharpest lessons in the SlopOS archive.
If the user asked to reveal **this exact thing**, a nearby folder is not the same action.

Local import for Schell:

- exact artifact selection should stay exact,
- reviewed actions should not silently widen to nearby subjects,
- and terminal affordances like rerun, reopen, reveal, or preview should preserve exact identity rather than fuzzy buffer proximity.

### 2) Approval should bind exact mutable basis

The approval-basis posture is deeply relevant to a shell.
If an approval depended on the current artifact head, current digest, current route, or current queue item, the receipt should say exactly which mutable basis was reviewed.

Local import for Schell:

- no sticky head-following approvals,
- no “still basically the same” approval reuse without an explicit basis rule,
- and terminal review cards should surface exact artifact identity or digest whenever the basis matters.

### 3) Portable requester truth should stay smaller than handler-local reality

The OpenURI handler-selection, session-selection, opener-attribution, request-shaping, and materialization boundaries all repeat the same design lesson:
requester truth should stay compact, while downstream routing state remains policy-local unless deliberately promoted.

Local import for Schell:

- a reviewed `open` or `send` action should name the exact subject and requested action,
- but should not pretend Schell owns browser profiles, cookie jars, handler identity, or local cache/materialization details unless a future seam explicitly earns that promotion,
- and the terminal should not suggest more portable control than the shell can honestly guarantee.

### 4) Outcome receipts and denial precedence are product surfaces

SlopOS treats outcome receipts and denial precedence as stable seams, not implementation trivia.
That is exactly right for Schell.

Local import for Schell:

- receipt blocks are not decorative,
- denial reasons should be deterministic enough to teach,
- and terminal navigation should treat receipt / denial objects as first-class units, not just pretty formatting around scrollback.

### 5) Request state and live state must not collapse

Activation posture and durable-status pressure reinforce one of Schell's most important terminal lessons.
What was requested is not always what is live now.

Local import for Schell:

- the background shelf should preserve request vs live state,
- last state-changing receipt/denial should stay visible,
- and expiry / renewal / revocation should be explicit instead of smuggled into old `jobs` folklore.

### 6) Command strings are not authority

The capshell surfaces in SlopOS are very useful pressure here.
They repeatedly refuse ambient authority by omission.
The command string exists, but it is not the whole truth of execution.

Local import for Schell:

- raw shell text should not be the only durable execution artifact,
- review should bind richer truth than “some bytes on a prompt,”
- and terminal actions like rerun, attach, or copy-output should know whether they are acting on shell-authenticated truth or on a guessed buffer reconstruction.

## What Schell should import carefully, not wholesale

### Import the posture discipline, not the schema forest

SlopOS can afford a large number of narrow posture docs because it is defining an entire operating environment.
Schell should copy the discipline of narrow seams, not mirror every singleton family one-for-one.

### Keep the terminal humane, not merely well-indexed

A danger here is obvious:
Schell could become exquisite at naming boundaries while still feeling bad to use.
So every SlopOS import should still answer at least one of these:

- does it improve exactness?
- does it improve review honesty?
- does it improve transcript truth?
- does it improve operator recovery?
- does it improve humane navigation through receipts, denials, and background state?

If not, hold it.

## Current co-design law suggested by this pass

Schell should be designed as **one shell+terminal system for SlopOS** with three explicit layers:

1. **shell truth** — exact reviewed action, mutable basis, effect summary, approval state, receipt / denial lineage;
2. **semantic transport** — the small set of zones, references, and trust markers that let terminals and transcripts carry that truth;
3. **local terminal UX** — cards, shelves, previews, jump navigation, notifications, key tables, and other humane accelerants.

That is the tight integration the project now needs.
It is not a license to collapse every layer into one blob.
