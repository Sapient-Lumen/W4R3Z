# Research synthesis, pass LXII (2026-03-21)

This pass keeps one fresh design rule in focus:
**Schell should absolutely steal queryable history, saved search editors, smart folders, and revset-like selection languages — but only if query views, saved manifests, result rows, and strong actions never collapse into one flattering “the search result is already authority” story.**

This seam matters because the luxury is real.
Operators do want to ask for “failing chapters from this repo in the last two days,” pin that as a reusable working view, reopen it later, and act on one exact result without hand-transcribing context.
The current ecosystem proves that live smart folders, full-sized saved search editors, filtered history search, and set-valued query languages all feel great.
But it also proves that query results, saved criteria, previews, and singleton actions are not the same object.
Schell should steal the best bits while keeping view scope, freshness, cardinality, and action strength explicit.

## 1) Atuin proves that queryable shell history is far richer than plain reverse-search

Atuin's current search docs show a history surface that can be filtered by cwd, exit code, time bounds, and result count, with an interactive TUI available on top.
That is already a terrific Schell clue.
Command recall does not have to be one linear stack.
It can be a filtered, queryable history surface with richer context than a bare reverse-history walk.
Atuin also keeps an important boundary visible: interactive search still returns commands for deliberate replay rather than pretending that history queries are the same thing as current approval.
See: https://docs.atuin.sh/cli/reference/search/

## 2) VS Code proves that search results can become a first-class review surface without becoming hidden execution

VS Code's Search Editor docs are especially useful here.
A search can be lifted into a full-sized editor with syntax highlighting and surrounding context; current results can be copied into a Search Editor; new editors can reuse prior configuration; and the search can be re-triggered while keeping query and result focus behavior explicit.
That is a beautiful model for Schell.
A query result set can become a durable-ish review object or working surface without pretending it is a live handle to every matched thing.
The editor is for inspection, comparison, and navigation first.
Schell should steal that posture for chapter journals, receipts, denials, runbooks, and artifact views.
See: https://code.visualstudio.com/docs/editing/codebasics

## 3) Apple Smart Folders prove the appeal of saved criteria plus auto-updating result sets

Apple's current Smart Folder guidance is another excellent clue.
A Smart Folder is saved by criteria, can be named and stored, and its contents update automatically as files change to match or stop matching those criteria.
That is a powerful idea for Schell too.
Operators will absolutely want living views like “recent failed chapters in this workspace” or “share candidates still needing redaction.”
But Smart Folders also remind us that the saved thing is the **criteria**, not a durable authority grant over every present and future result.
See: https://support.apple.com/guide/mac-help/create-or-change-a-smart-folder-on-mac-mchlp2804/mac

## 4) Jujutsu proves that set-valued query languages become safer when strong actions declare their cardinality expectations

Jujutsu's current revset docs are especially sharp.
They describe a functional language for selecting sets of revisions, and then explicitly say that commands like `jj edit <revset>` require the revset to resolve to exactly one commit, otherwise the command errors.
That is a superb Schell lesson.
A powerful query language does not require vague action semantics.
Set-valued discovery and singleton-required strong actions can coexist if the product is blunt about the distinction.
Schell should steal that principle for chapter queries, receipt queries, and smart decks: many-result discovery is fine, but stronger follow-on actions should demand exact singleton selection or a separately reviewed target set.
See: https://jj-vcs.github.io/jj/latest/revsets/

## 5) Apple Spotlight history also reminds us that asynchronous live query is a stronger product shape than one-shot search

Apple's older Spotlight query programming guide is still useful here because it makes the lifecycle visible: define the search, initiate it, listen for batch notifications, listen for completion, stop the query, then process results.
That is the right mental model for Schell too.
There is a meaningful difference between:
- a one-shot snapshot query,
- a review surface seeded from current results,
- and a live query subscription that may keep adding/removing matches later.
Those should not be flattened into one verb.
See: https://developer.apple.com/library/archive/documentation/Carbon/Conceptual/SpotlightQuery/Concepts/QueryingMetadata.html

## 6) The dangerous thing to refuse: query-as-authority

The ecosystem now makes at least four flattening mistakes temptingly easy:
- treating a saved query as a durable grant,
- treating a result row as proof that the underlying object is still current/live,
- treating live-updating search as an ambient background watcher,
- and treating “this query produced one result last time” as enough basis for a stronger action later.

Schell should refuse those moves.
A query should remain a way to derive a candidate set from an explicit view on an explicit basis.
If a stronger open/attach/replay/rerun/edit/share action is desired, the system should still make the target exact again.

## 7) The stealable move: query witnesses, smart decks, and saved-view manifests

The best decision-light move now looks like this:
1. introduce a **query witness** family,
2. let result sets become **saved views** or **smart decks** bound to explicit criteria and explicit source scope,
3. keep query posture visible: snapshot / copied-results / requeryable / live,
4. keep result rows metadata-safe by default,
5. keep cardinality posture visible: many / zero / singleton-required / target-set-review-required,
6. let query results feed inspection, staging, pinning, and chapterbook composition before stronger actions,
7. keep strong actions gated on exact singleton selection or explicit reviewed set selection,
8. and keep saved query manifests weaker than background schedulers, durable watches, or hidden inventory APIs.

That would make Schell feel dramatically more capable without freezing one final query language, one search backend, one indexing stack, one ranking engine, or one synchronization model.

## 8) A compact first proving slice

A compact proof could show:
- one query over chapter history filtered by cwd, exit status, and recency,
- one full-sized query-review surface with surrounding context,
- one saved smart deck bound to explicit criteria,
- one snapshot result set and one stronger live view with overflow/reconnect posture,
- one singleton-required action that refuses a multi-match result,
- one explicit promote-to-target-set review for bulk actions,
- one metadata-safe result row for a sensitive or quarantined object,
- and one stale/live basis badge when reopening a saved view.

That is enough to make Schell feel super awesome at recall and staging without hardening the final query engine too early.

## 9) Decisions intentionally kept open

This pass does **not** freeze:
- one final query language,
- one ranking/fuzzy engine,
- one indexing backend,
- one live-update/event model,
- one saved-view sync architecture,
- or one universal query surface shared by chapters, artifacts, receipts, and runbooks.

The no-regret move is smaller:
**steal queryable recall, search-editor-like review surfaces, smart-deck manifests, and singleton-aware action posture — but keep saved queries and result sets visibly weaker than current authority.**
