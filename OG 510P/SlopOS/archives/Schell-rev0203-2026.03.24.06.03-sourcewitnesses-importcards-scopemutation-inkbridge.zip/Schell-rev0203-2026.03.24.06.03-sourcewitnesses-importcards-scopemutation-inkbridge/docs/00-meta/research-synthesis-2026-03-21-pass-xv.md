# Research synthesis, pass XV (2026-03-21)

This pass focuses on a quieter but very load-bearing seam:
**command output is one of the main things users will copy, inspect, compare, trust, and act on, so Schell needs a better answer than "whatever happens to be in scrollback."**

## 1) Current terminals keep getting better when the shell names command regions explicitly

VS Code's shell integration lets the terminal understand more about what is happening inside the shell, which enables command detection, decorations, navigation, command guides, and sticky scroll that keeps the partially visible command attached to its output region. See: https://code.visualstudio.com/docs/terminal/shell-integration

WezTerm then shows how valuable semantic zones become once the shell emits those boundaries: `SelectTextAtMouseCursor 'SemanticZone'` can select the surrounding semantic zone, and the example explicitly uses it to select an entire command-output region. See: https://wezterm.org/config/lua/keyassignment/SelectTextAtMouseCursor.html

kitty pushes the same idea further into command-output browsing: shell integration supports opening the output of the last command in a pager, jumping between prompts, clicking within the current command to move the cursor, and right-clicking command output in scrollback to view it in a pager. See: https://sw.kovidgoyal.net/kitty/shell-integration/

The lesson is not "copy these products exactly."
The lesson is that exact command/output regions are increasingly the foundation for humane terminal UX.

## 2) Rich output UX does not require flattening everything into one total transcript truth

VS Code's command guide and sticky scroll are instructive because they bind output to commands without claiming that every byte in the buffer belongs to one perfect universal order.
They provide local command-region structure.
They do not pretend that the renderer has solved history, replay, export, and provenance all at once.

That is exactly the right attitude for Schell.
It suggests that the first step is not a giant logging ontology.
The first step is a compact output-capsule / command-region truth that the shell owns and the terminal renders honestly.

## 3) Separate output channels are still a proven systems pattern

The remote execution ecosystem is a good outside teacher here.
The ActionResult type in the Bazel remote execution API exposes `stdout_raw`, `stdout_digest`, `stderr_raw`, and `stderr_digest` separately, rather than pretending there is only one merged output artifact. See: https://docs.rs/bazel-remote-apis-rs/latest/bazel_remote_apis_rs/build/bazel/remote/execution/v2/struct.ActionResult.html

The lower-level remote execution specification also treats outputs from the execution service as content addressed by digest. See: https://raw.githubusercontent.com/bazelbuild/remote-apis/main/build/bazel/remote/execution/v2/remote_execution.proto

This is a powerful precedent for Schell.
It says we can keep output channels separate, preserve exact digests when useful, and still build humane renderer-level merged views on top.

## 4) Provenance of output is trickier than people think

The systemd journal fields documentation is a useful warning sign: entries obtained via stdout/stderr of forked processes may carry credentials valid for the parent process that initiated the connection to journald. See: https://man7.org/linux/man-pages/man7/systemd.journal-fields.7.html

That means a terminal should be careful about overclaiming who exactly authored every visible byte, especially once wrappers, pipelines, panes, and background runners get involved.
For Schell, this is strong pressure for provenance grades and authorship humility on output capsules rather than a blanket "the foreground child said this" story.

## 5) Current products also show what the fun version of this can look like

Ghostty's shell integration gives prompt navigation and prompt-local click-to-move, while its 1.3.0 release adds click-to-move support within active shell prompts using OSC 133 extensions and command-finished notifications. See: https://ghostty.org/docs/features/shell-integration and https://ghostty.org/docs/install/release-notes/1-3-0

These do not directly solve output-capsule design, but they show the taste level Schell should aim for: exact shell-marked regions plus small, sharp local affordances.

## 6) A no-regret Schell cluster is visible now

A decision-light first cluster looks like this:
- one shell-owned **output capsule** per command region or frozen followthrough object,
- one compact **braid witness** naming the merge/order posture of what the terminal rendered,
- one explicit channel family (`stdout`, `stderr`, `shell-note`, `review-note`, `gap`, `truncation`, `background-residue`),
- one provenance grade (`shell-authenticated`, `terminal-inferred`, `imported`, `restored`),
- and one local action family for pager/compare/export/copy that never silently upgrades into live authority.

## 7) The best steals are the humane ones

The best ideas to steal now are:
- semantic-region selection and paging,
- sticky command-region anchors,
- exact last-command-output browsing,
- stderr-only and region-only views,
- digest-first frozen output sidecars when outputs get large,
- and compare panes bound to exact capsules rather than copied text.

## 8) What to refuse

The moves to refuse are just as important:
- do not pretend one renderer-level merge is the universal truth,
- do not silently blur exact bytes, shell commentary, and later summaries,
- do not let output regions become a hidden authority tunnel,
- do not treat pager views as durable receipts,
- and do not freeze a giant binary logging stack before small specimens prove value.
