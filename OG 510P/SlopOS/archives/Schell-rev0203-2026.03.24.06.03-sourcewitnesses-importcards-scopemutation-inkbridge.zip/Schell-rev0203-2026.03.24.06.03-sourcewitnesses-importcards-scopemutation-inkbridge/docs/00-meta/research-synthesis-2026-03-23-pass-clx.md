# Research synthesis — 2026-03-23 — pass CLX

This pass tightens the next seam instead of widening “helpful completion” or “smart command discovery” into one giant feature:
**command-name luxury is worth stealing, but the shell should stay excellent at saying exactly what a bare command token will resolve to right now, because alias/function/builtin/module/path shadowing is still one of the oldest hidden authority planes in shells.**

The strongest current lesson is that modern shells already expose ordered command identity, but in fragmented, expert-only ways.
That points to a good next Schell move:
**command-identity witnesses, shadow stacks, and exact-invoker humility** rather than a vague “command exists” badge.

## 1) Bash shows that command identity is more than a path lookup

Current Bash docs say command search checks shell functions and builtins before searching `$PATH`, and Bash uses a hash table to remember full pathnames for executables.
The same manual says `type` can report alias, keyword, function, builtin, or file; `type -a` returns all matching places; `type -P` forces a path search; and hashed values may differ from the file that currently appears first in `$PATH`.
The `command` builtin runs a command while ignoring shell functions, and `hash -r` clears remembered locations.

That is a crucial shell+terminal lesson.
A bare token is not the same thing as an executable path.
Schell should therefore keep typed token, winning invoker, shadow stack, and hash freshness separate.

## 2) PowerShell proves both name conflict and discovery side-effect pressure

Current PowerShell docs say that when no path is specified, precedence is alias, then function, then cmdlet, then external executable.
They also say PowerShell does not run an executable from the current directory unless a full or relative path such as `./` or `\.\` is specified.
The docs for `Get-Command` say `-All` reveals hidden commands, while an exact-name `Get-Command` can automatically import the module containing the command.
The module docs add that module autoloading occurs the first time a command is used from an installed module, and that `Import-Module` supports `Prefix` and `NoClobber` to manage conflicts.

That gives Schell several strong lessons:
command discovery is not free if it imports code, current-directory execution posture is a real safety boundary, and name conflicts deserve first-class reveal rather than folklore.

## 3) fish shows the value of a built-in “what would run?” lane

Current fish docs say `type` indicates how a name would be interpreted if used as a command name.
They say `type -a` prints all definitions, `--no-functions` suppresses function lookup, and `--force-path` resolves only the executable in `PATH` even when a function or builtin shadows it.
Fish also routes “command not found” through a dedicated `fish_command_not_found` function.

That is excellent evidence for Schell.
The humane shell move is to keep resolution truth and not-found remediation on separate rails.
A user should be able to ask “what wins?” before the shell starts proposing repairs.

## 4) Nushell shows how signature luxury and command identity can stay separate

Current Nushell docs say `extern` definitions let external commands participate in parse-time type checking, completions, and syntax highlighting.
They also say `extern` has real limitations, including ordering constraints it cannot yet represent and the fact that commands invoked with the caret sigil are not recognized by `extern`.

That is a valuable Schell lesson.
A rich signature for an external command is wonderful, but it still is not the same thing as proof of which concrete invoker will answer a bare token in the current session.
So signature help should stay weaker than exact invoker identity.

## 5) The concrete Schell move

Schell should add a compact **command-identity witness** family:
- **invocation_token** — the exact command word the operator typed,
- **winner_kind** — alias / abbreviation / function / builtin / keyword / module command / script / external file / unknown,
- **winner_label** — exact chosen label or path,
- **source_lane** — interactive definition / rc load / module import / repo accelerator / PATH search / hashed path / explicit path / restored / unknown,
- **shadow_stack** — ordered nearby contenders that also answer this token,
- **bypass_forms** — exact path / `command` / `builtin` / module-qualified / pin-exact-invoker,
- **basis_ref** — file / module / env / receipt / path slot that established the winner,
- **freshness** — current / command-local / hashed / restored / staleable / unknown,
- **reveal_target** — exact card showing why this answer won and what stronger or weaker neighbors remain.

That is enough to steal command-resolution clarity without freezing one universal resolver engine, one module ABI, or one completion treaty.
