# SlopOS datacube evaluation, pass C (2026-03-22)

This pass evaluates the SlopOS companion pressure on one narrower seam:
**if Schell wants richer keyboard/input handling, what must the SlopOS archive force it to keep honest about exact review, adapter posture, and hidden helper power?**

The answer is tighter now:
**SlopOS pressures Schell to treat keyboard/input transport as an explicit compatibility-and-authority seam, not as invisible plumbing.**

## 1) D-CAPSHELL pressure applies before parsing even begins

RFC-0115 keeps insisting that shell glue is where least-privilege quietly collapses.
That warning lands earlier than parsing too.
If a shell+terminal depends on hidden helpers, injected rc tweaks, mux-specific translation, or invisible keyboard-mode forcing just to make editing work, then part of the shell’s authority story has already moved outside the visible command contract.

So the companion pressure is straightforward:
**key transport should be witnessed before Schell lets editor luxury pose as native shell truth.**

## 2) exact reviewed action must stay stronger than nearby keybinding delight

The companion already keeps exact review sequencing stronger than nearby convenience.
That means prompt-click movement, prediction acceptance, menu shortcuts, and modal bindings can all be wonderful — but they remain weaker than the later reviewed action.

A richer key protocol does not itself prove:
- exact command meaning,
- exact argv,
- current authority basis,
- or current live grant truth.

It only proves more about how the operator’s input arrived.
That is valuable, but it is still a weaker lane.

## 3) interface identity and adapter honesty matter here just as much as elsewhere

The companion keeps rewarding explicit interface identity, explicit adapters, and refusal to guess.
That maps cleanly onto keyboard/input handling.
Schell should visibly separate:
- native terminal key reporting,
- terminal-local shortcuts,
- mux translation,
- remote/helper-projected mode changes,
- platform-local input APIs,
- and degraded legacy fallback.

Without that split, “my shortcut worked” becomes a flattering but untrustworthy story.

## 4) helper-forced keyboard luxury should be weaker than native accepted posture

The companion archive consistently distrusts helper-installed comfort when it blurs the execution contract.
That same posture should apply to keyboard transport.
If richer input works only because:
- a wrapper exported extra environment,
- a mux forced a mode,
- a terminal helper injected startup code,
- or a remote host received copied terminfo or rewritten state,

then Schell should say so explicitly.
That does not mean refusing the luxury.
It means refusing to launder helper dependence into native truth.

## 5) recovery matters because broken input modes are not hypothetical

The companion repeatedly prefers failure-visible, deterministic, recoverable behavior.
Keyboard/input transport belongs in that family because stuck modes, ambiguous Escape handling, and helper-reset dependence are all real failure modes.

So a SlopOS-compatible Schell should make recovery posture explicit:
- native reset-safe,
- helper-reset-safe,
- partially reset-safe,
- or unknown.

That one badge would protect a lot of operator trust.

## 6) the clean import is one explicit key transport witness family

The companion-compatible import is to define a witness that can say:
- transport family,
- negotiation/accept posture,
- hop/adapter posture,
- event granularity,
- layout/IME posture,
- terminal-local versus shell/editor consumer,
- and recovery posture.

That keeps Schell humane without deciding too early:
- the final keyboard protocol set,
- the final remote-helper story,
- the final mux pass-through contract,
- or the final editor engine.

## 7) Compact conclusion

The strongest SlopOS pressure in this pass is:
**keyboard brilliance is welcome, but it must remain witnessed compatibility truth rather than hidden shell authority.**

That is the right construction rule while both datacubes are still in design.
