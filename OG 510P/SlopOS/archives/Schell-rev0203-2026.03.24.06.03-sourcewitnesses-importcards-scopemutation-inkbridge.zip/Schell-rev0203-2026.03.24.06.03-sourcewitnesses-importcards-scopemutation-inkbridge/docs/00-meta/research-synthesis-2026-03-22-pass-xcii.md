# Research synthesis, pass XCII (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should make effect posture legible before run — exact basis, predicted mutations, parser boundaries, pipeline shape, and uncertainty should be visible so dry-run stories, pretty output, and optimistic helper prose never impersonate execution truth.**

This seam matters because shells and terminals have already taught the same painful lesson many times:
- quoting and native-command parsing stay full of edge cases,
- rendered output often flatters people into forgetting what is really flowing through a pipeline,
- automation grows hidden authority fastest when “just run it” outruns review,
- and discoverability frequently gets paid for with startup cost, configuration sprawl, or hand-wavy explanations that are too vague to trust.

The web pass sharpened a compact set of imports worth stealing now:
- PowerShell’s `SupportsShouldProcess` posture proves that first-class `WhatIf` and `Confirm` rails are worth building into the command surface rather than bolting them on as folklore.
- fish’s design notes keep repeating three hard-earned truths: responsiveness is a law, discoverability is part of correctness, and configuration explosion is usually design debt in disguise.
- Nushell’s “everything is data” posture proves that structured pipelines can dramatically improve humane inspection, but its external-command boundary also proves view/rendering must stay distinct from exact pipeline semantics.
- PowerShell’s `--%` stop-parsing posture and native-command parsing caveats are a reminder that shell cleverness easily corrupts exact argument intent unless there is an explicit raw/external lane.
- Modern terminal shell-integration work in WezTerm, Ghostty, and VS Code proves that prompt marks, command boundaries, exit-code decorations, and output navigation are genuine luxury features when the shell is the source of truth.

The resulting Schell posture is tighter in a very decision-light way:
- **preview should split exact from descriptive** rather than presenting one flattering “plan”;
- **parser boundaries should be inspectable** rather than hidden inside quoting folklore;
- **rendered views should stay weaker** than exact argument / object / pipeline truth;
- **command boundaries and receipts should be shell-grounded** rather than inferred by the terminal alone;
- and **discoverability should come from humane defaults and explanations** rather than startup-heavy cleverness or infinite configuration.

That points to a compact proving slice:
- effect-preview cards,
- WhatIf / explain-before-run rails,
- exact argv or external-boundary reveal,
- output-shape chips for text vs structured vs rendered views,
- shell-authenticated command boundaries with exit-code and output navigation,
- and one uncertainty strip that names what the preview does **not** know.

The bigger choices are still worth deferring:
- final shell language syntax,
- final universal structured-pipeline model,
- final AI planning/execution contract,
- final shell↔terminal transport mix,
- and final extension / plugin protocols.

The no-regret move is smaller than all of those:
**make reviewable effect posture luxurious before the architecture hardens around hidden parsing, hidden authority, or pretty-but-ambiguous previews.**
