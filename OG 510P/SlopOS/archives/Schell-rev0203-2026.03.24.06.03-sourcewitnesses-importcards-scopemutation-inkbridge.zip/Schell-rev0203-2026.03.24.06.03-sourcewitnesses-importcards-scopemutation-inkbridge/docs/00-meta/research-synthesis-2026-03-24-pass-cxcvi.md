# Research synthesis — 2026-03-24 — pass CXCVI

This pass sharpens one older shell lesson that still matters for a brand-new shell+terminal:
**history shorthand is useful, but it should not silently erase the difference between the typed recall token, the cited source event, the selected words/modifiers, the realized expanded line, and the exact reviewed spend.**

## 1) Current shells already prove that recall and execution are not the same step

Bash still documents history expansion as a distinct pre-parse phase in interactive use.
It happens after a complete line is read but before the shell breaks the line into words.
The expansion model is explicit: an event designator chooses the earlier entry, an optional word designator chooses parts of it, and modifiers then transform the selected text.
That means shorthand like `!!`, `!$`, or `!:2-3` is not just “a command alias.”
It is a local text-recall mechanism that can materially rewrite what the shell will parse next.

Bash also preserves the humane escape hatch.
`histverify` keeps the result of history substitution out of immediate execution and reloads it into the Readline editing buffer.
`histreedit` gives failed substitutions an edit path instead of just dumping the user back at the prompt with folklore-level confusion.

zsh makes the same design lesson even clearer.
Its `HIST_VERIFY` option says that lines containing history expansion should not be executed directly; the shell performs the expansion and reloads the line into the editing buffer.
That is almost exactly the Schell move: reveal history-recall output as editable text before any stronger review or execution path begins.

fish is useful precisely because it mostly avoids that old shorthand lane.
Its current `history` tooling emphasizes searchable, mergeable, deletable, appendable history management rather than terse bang-history syntax.
That is a sign that rich history UX does not require silent substitution.

PowerShell and PSReadLine reinforce the same point from a different angle.
PowerShell splits built-in session history from PSReadLine-managed shared history, while PSReadLine exposes history-search functions that replace the current input or perform incremental search.
The recall machinery is still powerful, but it is editor-shaped rather than parser-magic-shaped.

## 2) The lesson Schell must learn from the past

The historical mistake is not simply “bang history can surprise people.”
The real mistake is **flattening historical recall into command truth**:
- the exact shorthand the operator typed,
- the earlier command it refers to,
- the selected words/arguments,
- the modifiers applied,
- the realized line now in the buffer,
- and the command actually admitted for spend.

Once those collapse, three bad things happen:
1. the operator loses the cited source of the recall,
2. review becomes less exact because historical memory looks like fresh authorship,
3. and history/export surfaces start lying about whether a line was typed, recalled, expanded, edited, or run as-is.

## 3) The nifty ideas worth stealing are source-labeled and edit-first

The current ecosystem points to several low-regret steals:
- **source-event chips** saying exactly which earlier command a shorthand refers to,
- **last-arg / arg-slice / modifier pills** that explain what part of history is being reused,
- **dual-view history rows** that preserve both shorthand and realized line,
- **insert-not-run recall** as the default strong path,
- **failed-substitution repair cards** instead of silent confusion,
- **cross-session locality labels** when recalled history did not come from the current session,
- and **why-this-recall** reveals that explain search, match, or modifier behavior inline.

These are super awesome because they improve comfort and speed without forcing Schell to decide:
- one final event-designator grammar,
- one final compatibility story for bash/zsh muscle memory,
- one final shared history store,
- one final modifier language,
- or one final event-id model.

## 4) The moves Schell should refuse for now

Schell should refuse, for now:
- silent history substitution that goes straight to spend,
- hiding the source event behind only the realized line,
- shared-history recall without locality labels,
- export surfaces that preserve only the expanded text,
- and any insistence that old bang-history syntax is the only acceptable modern recall UX.

In other words:
**steal the speed of historical recall, not the ambiguity of historical authority.**

## 5) The no-regret Schell seam

Schell should add one dedicated surface for:
- typed recall token,
- cited source event,
- word/modifier selection,
- realized expanded line,
- re-edit posture,
- source locality,
- and reviewed-spend relation.

That lets the shell feel dramatically smarter around reuse and repair without deciding whether the long-term answer is bash-style history substitution, zsh-style verified expansion, fish-style searchable history tools, PSReadLine-style input replacement, or some later hybrid.

## 6) Compact conclusion

Current official docs line up unusually well here.
Bash and zsh show that history substitution already wanted a verify/re-edit step.
fish and PSReadLine show that modern shells can make recall powerful while keeping it editor-local.
PowerShell shows that history locality itself is a first-class distinction.

So the next low-regret Schell seam is **history substitution witnesses, event-designator reveals, and re-edit humility** so shell memory stays fast and delightful without becoming hidden reviewed spend.
