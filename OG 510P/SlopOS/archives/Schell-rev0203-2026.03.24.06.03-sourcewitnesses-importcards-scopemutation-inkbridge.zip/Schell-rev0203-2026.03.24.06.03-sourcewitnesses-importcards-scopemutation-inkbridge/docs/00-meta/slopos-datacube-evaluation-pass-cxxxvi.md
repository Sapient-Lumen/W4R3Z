# SlopOS datacube evaluation — pass CXXXVI

This pass asks a narrower companion-safe question than “should Schell have launcher entries, command panes, or saved reusable commands?”
The better question is:
**what is the smallest reusable-launch model Schell can add without violating SlopOS exact launch footing or letting pinned convenience impersonate live authority?**

## 1) SlopOS pressures Schell toward exact launch cards, not flattering saved strings

SlopOS's D-CAPSHELL work keeps pressing on exact interpreter choice, exact exec object posture, startup-code closure, explicit env footing, and non-ambient launch meaning.
That pressure applies directly here.
If Schell introduces reusable launch objects, the companion-safe version is not “one nice saved command string.”
The companion-safe version is closer to an explicit **launch card**:
- command/interpreter basis,
- args/fields,
- cwd posture,
- wallet/env posture,
- target posture,
- and maybe layout placement.

That keeps recurring-command comfort compatible with exact launch footing.

## 2) A pinned card in layout should still be weaker than a live run

Zellij-style command panes are wonderful, but the SlopOS companion pressure says a card shown in layout is still not identical to a live authority edge.
That suggests a healthy ladder:
- card present,
- card suspended,
- card launching,
- live room,
- spent receipt.

Schell should keep those classes separate because SlopOS repeatedly refuses to let visible status or remembered setup impersonate current truth.

## 3) ViewFS gives the best adjacent shape: object existence, publication, liveness, and receipt are different acts

ViewFS is unusually relevant here.
It keeps unnamed object, published name, live bind, and later receipt/history distinct.
That maps beautifully onto reusable command objects:
- a launch card can exist before it is shared,
- a shared recipe can exist before it is exact-forked locally,
- a pinned suspended card can exist before it is launched,
- and a later receipt should describe one spent action rather than reviving liveness.

This is exactly the kind of separation that preserves optionality while the architecture is still moving.

## 4) Steward sharpens the restore-versus-live distinction

Steward's workspace snapshot posture and command-frame posture are strong reminders that remembered or restored UI arrangement is not identical to current process truth.
That pressure carries directly into Schell:
- a restored pinned card is not the same as a reconnected live room,
- a remembered “build here” tile is not proof the old process is still running,
- and a layout slot should be able to say suspended / restored / live / exited / receipt-only instead of one vague restore story.

## 5) Helm keeps convenience weaker than endorsement

Helm's endorsement pressure is also useful.
A convenient reusable command object should not automatically become a strongly trusted shared artifact.
That means Schell should keep an explicit promotion path from:
- draft,
- to exact local launch card,
- to endorsed shared card,
- to later receipt-bearing repeated use.

That is a much smaller and safer promise than one giant shared automation plane.

## 6) Companion-safe no-regret move

Schell does **not** need a huge command-object subsystem next.
It only needs a compact split:

- **draft text**
- **exact local launch card**
- **floating shared recipe**
- **suspended runnable card**
- **live room**
- **spent action / receipt**
- **later rerun offer**

with these rules:
- exact cards advertise exact launch footing,
- floating recipes confess mutability,
- pinned layout does not imply liveness,
- launch remains an explicit spend,
- receipts remain historical,
- and stronger sharing/promotion stays explicit.

## 7) Compact conclusion

The companion cubes keep teaching the same law in different accents:
**reusable convenience near execution is still not execution, and visible readiness is still not live authority.**

So the Schell-safe answer is small:
**launch cards, suspended run cards, live rooms, and spent receipts should be separately named classes** rather than one flattering bucket of “saved command” objects.
That gives the future shell+terminal a very real luxury upgrade without forcing early decisions about schemas, sync, layout engines, or remote-launch treaties.
