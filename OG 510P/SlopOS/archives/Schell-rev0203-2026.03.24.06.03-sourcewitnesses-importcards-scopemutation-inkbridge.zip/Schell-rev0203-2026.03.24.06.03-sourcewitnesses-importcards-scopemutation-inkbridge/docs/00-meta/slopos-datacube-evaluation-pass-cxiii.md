# SlopOS datacube evaluation, pass CXIII (2026-03-22)

This pass evaluates one narrower question against the current companion archives:
**what do SlopOS and the nearby datacubes teach Schell about recovering from stale shell+terminal semantics without widening the execution contract or flattening everything into one giant reset ritual?**

The answer is crisp:
**keep execution exact, keep freshness explicit, and let semantic repair travel on named witnesses instead of inherited confidence.**

SlopOS itself supplies most of the first half of that answer.
Steward, which is already specializing the shell+terminal seam around SlopOS, supplies a very plausible compression for the second half: semantic epochs, prompt-critical baseline reassertion, and precision fences.

## 1) SlopOS keeps exact execution smaller than terminal comfort

The `capshell` posture still refuses hidden command-string fallback, ambient word expansion, and portable PTY mythology in the execution core.
That means Schell should not solve semantic drift by making the execution substrate more terminal-shaped.

A confused terminal is not permission to widen the launcher contract.
The repair belongs on the witness side, not inside `exec` truth.

## 2) Sidecar discipline implies repair should also be sidecar-shaped

The companion archive repeatedly prefers small exact canonical surfaces with richer observational or descriptive detail carried separately.
That is the right shape for semantic repair too.
A fresh prompt/cwd/capability reassertion should not rewrite the historical command transcript or mutate old exact command objects into something newly current.

Instead, Schell should let:
- old command frames remain historical,
- new freshness live on a fresh epoch or witness,
- and downgrade causes stay explicit rather than silently overwritten.

## 3) Attention and live-state posture argue against sticky stale chrome

SlopOS keeps transient attention/status hints weaker than durable exact outcomes.
Generalized to Schell, that means:
- sticky headers,
- remembered cwd chips,
- command-finish badges,
- prompt-local edit affordances,
- and frame-local action chips

must all be willing to say “this belonged to an older semantic world.”
That is much more companion-compatible than preserving one flattering pane-wide fiction.

## 4) Steward already offers a strong shell+terminal compression

Among the included companion datacubes, Steward is especially informative here.
Its current shell/terminal posture already argues for:
- semantic epochs when hops, restarts, or resync shift freshness,
- precision fences explaining why certainty changed,
- a tiny prompt-critical baseline,
- fresh-prompt baseline reassertion,
- and distinct light-resync versus hard-reset repair paths.

That is exactly the kind of smaller answer Schell should steal.
It is rich enough to support super-awesome command-local affordances, but still narrow enough to avoid prematurely freezing one terminal worldview.

## 5) The companion-compatible answer stays small

Schell does **not** need to settle:
- one final OSC family,
- one final remote relay format,
- one final multiplexer treaty,
- one final predictive-local-echo stack,
- or one final session-identity model

to stay aligned with SlopOS.

It only needs a few rules:

### A) Keep exact execution and exact reviewed commands small
Structured argv, exact footing, and replay-stable result truth stay stronger than terminal repair metadata.

### B) Let semantic repair mint fresh witnesses instead of mutating old truth
Epoch bumps, resync cards, and baseline reassertion receipts should establish new freshness without rewriting what was previously observed.

### C) Make downgrade causes explicit
Hop changes, shell restarts, lost markers, capability drift, and TUI residue should show up as precision fences rather than as folklore.

### D) Gate stronger local luxuries on fresh semantics
Prompt-local editing, same-context spawn, live sticky command actions, and similar comforts should require current epoch-scoped evidence, not merely familiar-looking scrollback.

### E) Keep transcript truth viable without the luxury layer
A plain transcript should still preserve what command ran and what happened, even if richer prompt/cwd/frame repair witnesses are unavailable.

## 6) Compact conclusion

The SlopOS-compatible move is not “build a giant smarter terminal core first.”
It is:
**keep execution exact, keep semantic repair explicit, and prefer fresh epochs plus tiny baseline reassertion over stale certainty or giant reset folklore.**

That is a design-phase-safe move because it improves robustness and remote honesty a lot without forcing big early architecture decisions.
