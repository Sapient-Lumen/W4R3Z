# Research synthesis, pass LXXXVII (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should steal the best current startup, config, and overlay ideas — layered config locations, host-versus-user scoping, flat effective-config views, shell-integration injection, prompt-time project overlays, and live reload — but it should keep defaults, user config, host/global config, project overlays, terminal injection, runtime overrides, restored state, and exact current shell footing separately named so “this is my shell config” never flattens into one flattering lie.**

This seam matters because configuration is where shells quietly become policy engines.
Current shells and terminals now expose multiple kinds of startup and config truth at once: login versus non-login behavior, host-scoped profiles, prompt hooks, project-local overlays, terminal-injected integration, command-line overrides, hot reload, restored window-specific changes, and runtime environment capture.
That is fertile ground for delight and also for confusion.
The current ecosystem gives Schell both the lessons and the stealable moves.

## 1) Startup is authority, not decoration

Bash still selects different startup files based on how it is invoked.
The GNU Bash manual says an interactive login shell reads `/etc/profile` and then the first readable file among `~/.bash_profile`, `~/.bash_login`, and `~/.profile`.
The zsh manual is even more layered: `/etc/zshenv` always runs, then login/interactive files are added depending on shell mode, and later files can be skipped or re-enabled through options.
PowerShell keeps several different profiles for users and host programs.

The lesson is not merely “shell startup is complicated.”
It is stronger:
**startup footing is a real execution boundary.**
If a terminal, project tool, or helper product changes startup semantics, it is touching authority.

## 2) Config layering should be shown as a stack, not guessed from one file

The XDG Base Directory Specification already separates user config, search-path config, state, cache, and runtime locations.
Ghostty makes its own file-order precedence explicit and says later files override earlier ones.
tmux keeps a system config, a user config, and explicit later reload via `source-file`.
These systems are already telling Schell that config should be understood as a **layered stack** with a visible winner, not as “whatever the dotfile says”.

A good first Schell model is therefore a compact **config-ground ladder**:
- built-in defaults,
- global/host config,
- user config,
- imported theme/prompt pack,
- project overlay,
- terminal-injected integration,
- session/window/runtime override,
- restored historical residue,
- or unknown.

## 3) Effective config is one of the best ideas worth stealing

Nushell is especially helpful here.
It gives the user separate `env.nu` and `config.nu`, built-in commands to open them, and a `config flatten` command that shows the current flattened configuration.
That is a very strong clue for Schell.

Users should be able to ask questions like:
- why is the prompt styled this way?
- where did this env overlay come from?
- what currently owns completion behavior?
- which layer set this keybinding?

The right answer is not a paragraph.
It is an **effective-config card** showing the winning value, the overridden candidates, their sources, and whether the current result is live, injected, adapted, or historical.

## 4) Shell integration injection is useful, but it is still config authorship

VS Code says shell integration is installed by injecting arguments and/or environment variables when the shell launches.
Ghostty can automatically inject shell integration for several shells, but its docs also recommend sourcing the integration as early as possible in the shell config for broader coverage.
VS Code separately warns that it may launch an interactive login shell just to resolve the shell environment, and that this can cause problems depending on the shell setup.

The right import for Schell is not “terminals should never help.”
It is: **terminal help is one visible author in the config/startup story.**
A startup-footing badge should be able to say things like:
- native shell only,
- terminal-injected,
- manually sourced integration,
- project overlay active,
- resolving-environment helper launch,
- restored session residue,
- or unknown.

## 5) Project-local overlays are powerful, but they should not impersonate permanent shell truth

direnv is one of the clearest modern examples.
It hooks into the shell and, before each prompt, checks for an authorized `.envrc` or optional `.env`, loads it in a subshell, and applies the exported variables back to the current shell.
That is genuinely useful.
It is also exactly the kind of thing that becomes misleading when users can no longer tell whether their current environment came from their base shell, the project, or a terminal helper.

Schell should therefore treat project-local overlays as **named overlay cards** with:
- scope,
- source path,
- authorization posture,
- expiry/lease posture,
- what changed,
- and how to suspend or shadow-compare the overlay.

## 6) Live reload is great only when config evaluation is side-effect humble

WezTerm is unusually crisp here.
It watches the config file, reloads automatically, and explicitly warns that the config may be evaluated multiple times and that side effects in the main flow can spawn repeated background work.
That is an excellent lesson for Schell.

The steal is not simply hot reload.
The steal is **hot reload plus side-effect discipline**.
Schell should prefer pure-data config, derived effective views, and named action hooks rather than “arbitrary code in config main flow.”
If something in config wants to perform a side effect, that should be a separately named hook with explicit review or at least explicit blame.

## 7) Config and state should stop borrowing each other’s drawers

The XDG spec’s distinction between config, state, cache, and runtime is still one of the most practical lessons here.
State includes logs, history, recently used files, view/layout/open files, and undo history.
That separation matters directly for shells and terminals.
Prompt theme choices, command marks, session layouts, recent directories, and restored windows should not all pose as “config”.

Schell should therefore keep at least four drawers visible:
- config intent,
- live state,
- cached accelerators,
- and restored historical residue.

## 8) What Schell should now do

This pass points to a compact answer:
- **startup-footing badges** that say how the shell was started and who altered startup,
- **config-ground cards** that show the layer stack and the winning value,
- **effective-config flatten** for prompt/env/keybinding/completion behavior,
- **overlay cards** for project or terminal-provided changes,
- **pure-data preference for themes/prompts/packs**,
- **side-effect hook fences** for config-time actions,
- and **suspend/shadow/compare rails** so users can test behavior without tearing down their whole shell.

## 9) Decisions intentionally kept open

This pass does **not** freeze:
- one final config language,
- one final pack format,
- one final project-overlay model,
- one final startup-trace protocol,
- one final hot-reload engine,
- or one final terminal-integration contract.

The no-regret move is smaller and stronger:
**give Schell startup-footing badges, config-ground cards, effective-config flatten, overlay cards, and side-effect fences so startup and configuration become more humane without turning rc folklore or terminal injection into hidden authority.**
