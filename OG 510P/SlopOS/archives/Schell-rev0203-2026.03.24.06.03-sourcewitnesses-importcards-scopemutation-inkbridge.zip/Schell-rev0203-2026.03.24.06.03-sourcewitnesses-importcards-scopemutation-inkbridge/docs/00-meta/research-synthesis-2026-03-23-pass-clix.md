# Research synthesis — 2026-03-23 — pass CLIX

This pass tightens the next seam instead of widening “login” or “config” into one giant product:
**current target luxury is worth stealing, but account / profile / project / subscription / cluster / namespace / role choice should stay visibly stacked instead of collapsing into one ambient whoami story.**

The strongest current lesson is that modern CLIs already split targeting across several layers:
- a signed-in or broker-approved identity,
- one active configuration or profile,
- one or more default target properties,
- optional environment overrides,
- optional per-command overrides,
- and sometimes explicit impersonation.

That points to a good next Schell move:
**subject witnesses, target stacks, and override humility** rather than a vague current-account badge.

## 1) Azure CLI shows that sign-in and current subscription are different truths

Current Azure CLI docs say that after sign-in, commands run against the default subscription, and that users with multiple subscriptions should change the default with `az account set --subscription`.
The same docs show `az account get-access-token` operating either against the active subscription or a specific subscription passed explicitly.

That is a crucial shell+terminal lesson.
Signed in is not the same thing as “this exact subscription is current for this command”.
Schell should therefore keep auth/broker state separate from current-subscription witness and command-local override witness.

## 2) kubectl proves that “context” is already a bundle, and even that bundle is not final truth

Kubernetes docs say a kubeconfig context groups cluster, namespace, and user, and that `kubectl` uses parameters from the current context by default.
The docs also show `kubectl config use-context` setting the current context, `KUBECONFIG` merging multiple config files, `--kubeconfig` bypassing merge and using only the specified file, and `--namespace` setting the namespace for a current request.
The command reference further exposes `--as`, `--as-group`, and related impersonation flags.

That means the real targeting story is layered:
current context, merged config basis, file override, namespace override, and optional impersonation.
Schell should show that stack instead of pretending one prompt segment or one remembered context name is enough.

## 3) gcloud shows the value of profile-shaped configurations plus per-invocation override honesty

Current Google Cloud CLI docs say a configuration is a set of gcloud properties that works like a profile.
They say multiple configurations can be created and switched among, and that options override values set in gcloud CLI properties on a per-invocation level.
The initialization docs add that `gcloud init` can authorize an account and set active account, current project, and default region/zone in a configuration.

That is excellent evidence for Schell.
A humane shell should show both the ambient configuration stack and the stronger per-command override path, rather than flattening everything into one “current project” glow.

## 4) AWS CLI makes precedence and source reveal part of the real target truth

Current AWS CLI docs say `--profile` or `AWS_PROFILE` chooses which profile section to use, and that environment-variable credentials take precedence over shared-credentials and config-file credentials.
They also say `aws configure list` shows not just values but where each configuration value came from.
Other AWS config docs show `aws configure set region ... --profile ...` and `aws configure get region --profile ...` as distinct profile operations.

That suggests one especially strong Schell move: every current-subject chip should answer not only “what is current?” but also “where did this come from?”

## 5) GitHub CLI shows host-scoped active-account posture clearly

Current GitHub CLI docs say `gh auth switch` changes the authentication configuration used when targeting the specified GitHub host, and `gh auth status` displays the active account and authentication state on each known host.
That is another reminder that active subject is often host-scoped and tool-scoped rather than one giant machine-global identity.

Schell should steal the clarity: exact host, exact account, exact active-status card, and exact switch action, all weaker than “whatever the prompt badge vaguely implied”.

## 6) The concrete Schell move

Schell should add a compact **subject witness** family:
- **subject_family** — git host / account / tenant / profile / project / subscription / cluster / namespace / role / unknown,
- **subject_value** — exact chosen label or redacted stable handle,
- **source_lane** — broker / active config / config file / env / flag / prompt inference / restored / unknown,
- **scope_lane** — command-only / shell session / pane / window / host / remote peer / unknown,
- **override_strength** — baseline / config-active / env / flag / impersonation / historical / unknown,
- **basis_ref** — exact file / env var / flag / receipt / card that established the subject,
- **freshness** — current / command-local / historical / restored / mismatched / unknown,
- **reveal_target** — exact card showing why this subject is current and what stronger act remains separate.

That is enough to steal current-target comfort without freezing one universal account model, one prompt segment ABI, or one provider ontology.
