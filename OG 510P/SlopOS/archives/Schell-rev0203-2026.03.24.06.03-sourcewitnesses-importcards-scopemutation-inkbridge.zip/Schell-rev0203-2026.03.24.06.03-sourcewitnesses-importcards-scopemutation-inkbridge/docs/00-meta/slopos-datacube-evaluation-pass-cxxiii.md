# SlopOS datacube evaluation, pass CXXIII (2026-03-22)

This pass evaluates one narrower question against the current companion archives:
**what do SlopOS, Steward, and ViewFS teach Schell about terminal modes that are temporary, stateful, and sometimes stranded?**

The answer is straightforward:
**important terminal modes should behave like leased descriptive state with bounded repair, not like hidden ambient authority.**

## 1) SlopOS keeps rewarding lease-shaped temporary state and explicit local acceptance

Across the companion archive, SlopOS repeatedly prefers explicit leased rights, bounded lifetimes, and descriptive exported artifacts that stay weaker than local acceptance.
That maps unusually well onto terminal modes.
Bracketed paste, focus reporting, alternate screen, synchronized output, or title-query posture may all matter a lot.
But they are still temporary live-state facts on a path, not approval-bearing authority.

This gives Schell a strong companion-compatible rule:
- model important terminal modes as leased descriptive state,
- keep issuer and lifetime visible,
- and keep mode state weaker than shell-owned reviewed truth.

## 2) Steward already points toward tiny baselines and bounded repair

Steward's mode-baseline posture is basically a companion proof hint for Schell.
Fresh prompt reassertion, small baselines, explicit repair paths, and downgrade confession all map directly onto terminal-mode life.
That means Schell does not need a giant universal VT ontology.
It only needs a compact way to say which important modes are currently borrowed, freshly reasserted, or stranded.

## 3) ViewFS keeps live lanes distinct

ViewFS keeps observe, attach, control, sideband, and historical lanes separately named.
That matters here too.
A mode lease should not silently become a control grant.
A repair path should not silently become a lifecycle change.
And a relayed mode should not quietly inherit the same footing as a direct live baseline.

## 4) Companion-safe no-regret move

Schell does **not** need to decide the final mode stack, mux treaty, or reset doctrine right now.
It only needs a few bounded rules:

### A) Keep important terminal modes explicit
Named family, named issuer, named owner scope, named exit expectation.

### B) Keep save/restore posture first-class
Fresh baseline, borrowed with restore witness, borrowed without restore witness, restored but not yet reattested, stranded.

### C) Keep repair paths bounded
Baseline reassertion, explicit release, and hard reset are not the same act.

### D) Keep relay posture visible
A mode that survived tmux, SSH, replay, or another adapter should say so.

### E) Keep borrowed mode weaker than shell truth
Useful for local luxury and inspectors; not enough to prove shell authorship, durable completion, or current review basis.

## 5) Compact conclusion

The SlopOS-compatible answer is not “the terminal looks normal, therefore the footing is normal.”
It is:
**treat important terminal modes as compact mode leases with bounded repair and visible relay/freshness posture.**

That is a very safe companion move because it improves polish and recovery without deciding too much too early.
