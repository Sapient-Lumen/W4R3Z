# SlopOS datacube evaluation — pass CLXVII

This pass asks the next narrower companion question:
**if SlopOS keeps exact launch tiny and explicit, what should Schell surface on every visible chapter-like object before that object earns a stronger next act?**

The answer emerging from this pass is:
**Schell should compress SlopOS exactness and companion-cube distinctions into tiny footing strips and explicit action floors, because the shell+terminal now needs more honest summaries more than it needs more replay cleverness.**

## 1) SlopOS already provides the rows that a footing strip needs

SlopOS capshell posture keeps the important launch rows exact:
- executable object,
- argv footing,
- cwd/root footing,
- env/startup closure,
- handle/result posture,
- and bounded output semantics.

That means Schell does not need to fake a strength strip from renderer-local hunches.
It already has real shell-owned ingredients.

## 2) The companion-safe move is compression, not re-ambientization

Because SlopOS is still in design phase, the temptation is to make rich terminal objects feel powerful by default:
- a command row,
- a hover,
- an alert,
- a watch card,
- or an attach bundle.

But that would quietly re-ambientize the exactness that SlopOS is trying to win.
The healthier move is to compress exactness into something operators can see quickly:
- source family,
- freshness,
- changed footing or not,
- action floor,
- strongest honest next verb.

That gives speed without surrendering discipline.

## 3) ViewFS, Foundry, Harbor, Helm, Ward, and Steward all sharpen the same object

The companion cubes line up unusually well here.

- **ViewFS** says basis, delta recipe, apply session, reconstructed object, and fallback lane are different things.
- **Foundry** says overlays/config layers are mutable footing, not invisible comfort.
- **Harbor** says stronger acts should climb visible risk ladders.
- **Helm** says exit is not settlement and settlement is not downstream adoption.
- **Ward** and **Steward** say liveness/freshness claims should stay source-labeled and lease-shaped.

That is almost a direct specification for a shell-facing footing strip.
The strip should be where those distinctions become quick to read rather than hidden in giant inspectors or prose warnings.

## 4) SlopOS exact launch makes “claim strength” unusually honest

Many terminals can only guess a lot of their footing story.
Schell does not need to stay at guess-level if it rides alongside SlopOS.
It can say things like:
- exec exact,
- cwd shell-asserted,
- env closure exact,
- basis changed,
- overlay stale,
- settlement historical only,
- current peer observer-labeled,
- stronger act downgraded to compare.

That is a far more useful kind of delight than one “run again” affordance with hidden doubt.

## 5) The action floor should become the operator-facing expression of Harbor pressure

Harbor's risk ladders suggest a very good surface discipline.
A footing strip should not merely say whether something is “trusted.”
It should say what it is allowed to support *next*:
- inspect,
- insert,
- attach,
- compare,
- derive on current basis,
- or rerun after review.

That keeps stronger action coupled to visible footing rather than to comfort or recency.

## 6) This seam keeps Schell appropriately decision-light

A footing strip does **not** require Schell to decide yet:
- the final shell↔terminal wire format,
- the final chapter storage model,
- the final compare serialization,
- the final help-attachment schema,
- or the final history database.

It only requires one honest summary object and a few specimen views.
That is exactly the right size of decision while SlopOS itself is still evolving.

## 7) Compact conclusion

SlopOS is already doing the hard exactness work.
The next companion move for Schell is not to widen replay.
It is to **surface exactness compactly** through footing strips and explicit action floors.

That gives operators a shell+terminal that feels super awesome for the right reason:
it stays fast, inspectable, and honest about what it really knows now.
