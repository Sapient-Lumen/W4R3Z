# SlopOS datacube evaluation — pass CLXVIII

This pass asks the next narrower companion question:
**if SlopOS keeps exact launch footing explicit, how should Schell keep that footing coherent when a chapter moves into a hover, watch card, help attachment, transcript card, or imported helper lane?**

The answer emerging from this pass is:
**Schell should introduce one compact carried witness packet, because SlopOS exactness and companion-cube distinctions are too valuable to be re-derived differently in every rich view.**

## 1) SlopOS already gives Schell exact rows worth carrying

SlopOS capshell posture keeps the load-bearing launch rows explicit:
- exact executable object,
- exact cwd/root footing,
- explicit environment and startup closure,
- exact handle-table posture,
- exact script-entry posture,
- exact word-expansion refusal,
- and a deliberately separate result-sidecar boundary.

That is already enough to prevent chapter truth from being just whatever the renderer last guessed.
But those rows only pay off if later views can keep carrying them.

## 2) The companion datacubes all punish per-view reinvention

The companions sharpen the same lesson from different angles.

- **ViewFS** keeps witness packs, caveats, freshness tokens, why-records, and receipts distinct.
- **Foundry** keeps overlay/config footing exact enough to compare rather than romanticize.
- **Harbor** keeps stronger acts on visible ladders with readable stoplines.
- **Helm** keeps exit, settlement, downstream adoption, and aftermath on separate seams.
- **Ward** and **Steward** keep liveness and freshness source-labeled and lease-shaped.

If Schell rebuilds its “what this chapter means” summary independently in each surface, it will quietly flatten those distinctions back into terminal folklore.
A carried witness packet is the cleaner answer.

## 3) SlopOS exactness wants compression plus transport, not re-ambientization

Earlier passes established that Schell should compress exactness into footing strips and action floors.
This pass tightens the next move:
those strips and floors should not be reauthored from scratch every time the command appears somewhere new.

The healthy posture is:
- the shell or a shell-owned companion surface creates the base packet,
- later views either carry that packet forward,
- or add explicit current supplements with visible downgrade reasons.

That is companion-safe because the original claim rows stay distinct from current observer additions.

## 4) A carried packet is the shell+terminal translation of ViewFS witness packs

ViewFS is especially useful here.
It already points toward a family split between witness material, caveats, freshness, why-records, and receipts.
Schell does not need to import the whole family right away.
It can take a smaller shell+terminal cut:
- **witness packet** — the compact carried summary,
- **why bundle** — the reachable explanation path,
- **current supplement** — any later source-labeled update,
- **receipt/export posture** — whether the packet is local-only, attach-safe, or export-review-only.

That is enough to keep multiple UI surfaces aligned without deciding the final family schema.

## 5) This seam makes attach-for-help much more honest

One of the nicest “super awesome” moves available now is better help/context attachment.
But attach-for-help should not become a mystery blob that sometimes means original shell truth and sometimes means current observer guesswork.

A carried witness packet lets Schell say, compactly:
- what chapter this is,
- what footing rows were exact then,
- what the current freshness/peer/overlay supplement now says,
- what the action floor is,
- and why stronger moves are blocked.

That is much closer to the shape that SlopOS and the companion cubes are already asking for.

## 6) This is still decision-light

A carried witness packet does **not** require Schell to decide yet:
- the final shell↔terminal wire format,
- the final packet serialization,
- the final chat/export schema,
- the final history database,
- or the final companion-cube field map.

It only requires one narrow discipline:
**the same chapter should not tell materially different footing stories in different rich views unless a visible supplement or downgrade explains why.**

That is exactly the right size of move while SlopOS itself remains in design.

## 7) Compact conclusion

SlopOS is already winning the hard exactness rows.
The next companion move for Schell is to keep those rows coherent across handoff.
So the shell+terminal should add **one compact carried witness packet and one reachable why bundle** before it adds even more view-local cleverness.
