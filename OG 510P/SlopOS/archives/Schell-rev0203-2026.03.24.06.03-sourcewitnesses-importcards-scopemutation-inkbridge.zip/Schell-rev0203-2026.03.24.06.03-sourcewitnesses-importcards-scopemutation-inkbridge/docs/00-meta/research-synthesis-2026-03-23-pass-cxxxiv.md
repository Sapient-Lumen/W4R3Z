# Research synthesis — 2026-03-23 — pass CXXXIV

This pass sharpens one fresh shell+terminal lesson from current upstream docs:
**modern terminal products are increasingly forced to distinguish ordinary command chapters from resident interactive rooms.**
The strongest luxuries now live around active PTY attachment, room-local guidance, collapsible summaries, and explicit handback — but the same docs also show why those features become dangerous when they borrow the trust language of ordinary finished shell commands.

## 1) The ecosystem is admitting that not every terminal occupant is “just a command”

Current VS Code terminal work is unusually revealing here.
The January 2026 release added `terminal.integrated.stickyScroll.ignoredCommands` and says some commands should be ignored by sticky scroll, explicitly naming agentic CLIs such as `copilot`, `claude`, `codex`, and `gemini`.
That is an important admission: some PTY occupants are bad fits for ordinary command-guide chrome because they are more like resident interactive rooms than bounded shell chapters.

## 2) Active dialect changes inside one PTY are now a first-class concern

VS Code's July 2025 terminal-inline-chat update says it now detects the active shell even within subshells like Python or Node launched from another shell.
That matters because the right suggestions and review affordances depend on the currently active inner dialect, not just the parent shell that started the PTY.
A custom shell+terminal therefore needs a cleaner distinction between parent shell truth and current room-local interaction truth.

## 3) Warp makes PTY handoff a product feature

Warp's current Full Terminal Use docs show the strongest pressure.
Its agent can attach to a running PTY, see the live buffer, write to the PTY, respond to prompts, and continue inside interactive tools like `psql`, `vim`, `python`, `gdb`, `top`, or a dev server.
The docs also make handback explicit: the user can take over, then hand control back, and the agent can optionally get auto-approval for similar commands **in this session**.
This is excellent product pressure, but it is also a warning that handoff should be treated as a scoped lease rather than as ambient shell authority.

## 4) Summary chrome is becoming navigational rather than canonical

VS Code's March 2026 release says terminal tool invocations in agent mode are shown as collapsible summary sections to reduce noise.
That is exactly the right direction for resident-room UX: summary headers are useful navigational views over work, but they should not become the canonical record or hide whether the underlying room is still live, historical, or restored.

## 5) Prompt-local affordances still need exact prompt truth

Ghostty's current configuration reference says click-to-move at prompts requires shell integration via `OSC 133` and may rely on synthetic arrow-key movements or direct click events, with some possible edge-case behavior.
That reinforces an old Schell rule that becomes even more important in resident rooms: prompt-local editing and click affordances should only operate where prompt truth is exact enough, not because the terminal guesses that some visible text looks prompt-ish.

## 6) Web terminals keep reminding us that terminal buffers are untrusted data

The xterm.js security guide says terminal I/O should be treated as untrusted when exposed at the DOM level and explicitly warns about APIs like title changes, linkification, buffer access, and parser hooks.
That matters even more once products start summarizing, linking, collapsing, or attaching helpers to live resident rooms.
The shell+terminal must not let room summaries or helper views become an HTML-shaped second truth system.

## 7) Zellij and Atuin teach the right completion humility

Zellij resurrection keeps restored commands behind an explicit “Press ENTER to run...” banner instead of rerunning immediately.
Atuin's executable-block docs say script and terminal blocks have isolated execution context, and terminal blocks must actually exit because completion cannot be inferred automatically; otherwise the operator must click stop or include `exit`.
Together, those tools keep teaching the same lesson: resident interactive work has a weaker and more explicit completion story than a simple one-shot shell command.

## 8) The missing Schell object is a resident room with a handback lease

The best no-regret answer from this pass is not a giant “agent terminal” architecture.
It is smaller:

- **command chapter**
- **resident room**
- **room-local step**
- **handback lease**
- **room summary**
- **restored room view**

That gives Schell enough language to keep PTY-local brilliance honest without committing to one final agent protocol, one final collaboration model, or one final TUI-awareness stack.

## 9) The strongest stealable move

The best move hiding in these sources is:
**treat helper/agent operation inside an active PTY as a room-bound borrow of control, not as generic shell authority.**

That one move unlocks a lot:
- explicit takeover / handback,
- room-local approval quieting,
- better collapsible room summaries,
- dialect-aware suggestions inside REPLs and CLIs,
- and downranked command guides for noisy resident tools,

while still preserving the rule that shell-global truth and reviewed command authority remain narrower and stronger than “something is happening in this PTY.”

## 10) Compact conclusion

Current terminal products are proving that resident PTY rooms are real product objects now.
Schell does not need to rush into one giant architecture to respond.
It only needs a smaller honesty move:
**name resident rooms, keep handback as an exact revocable lease, downrank ordinary command chrome when a room is not an ordinary chapter, and keep room-local dialect/help/approval weaker than shell-global truth.**
