# Research synthesis, pass XIV (2026-03-20)

This pass focuses on a deceptively dangerous seam:
**panes, tabs, splits, sessions, and layouts are excellent local UX, but they can easily become a hidden authority plane if the shell stops being the source of truth.**

## 1) Current tools are very good at pane trees

The public terminal world now offers a lot of strong local multiplexer UX.

- tmux keeps a clean hierarchy: panes belong to windows, windows belong to sessions, sessions attach to clients, and one active pane per current window receives typing.
- WezTerm multiplexes local tabs and windows that persist until they are closed and exposes live pane handles with methods for input, splitting, selection, and screen introspection.
- Ghostty now supports drag-and-drop reordering of splits, carrying the terminal contents, working directory, and running processes with the moved split.
- kitty offers sessions, layouts, remote control, overlays, background launches, and source-window copying.
- Zellij makes panes, tabs, templates, layouts, floating panes, and plugins first-class.

This is a huge source of ideas.
It is also a huge warning.
These systems are strong because they give the operator local power over view trees.
Schell should steal that power without quietly inheriting their most ambient control habits.

## 2) Shell-marked truth still beats view-guessing

The command-boundary lesson remains unchanged.
Windows Terminal and VS Code keep showing that command selection, command-output selection, navigation, and status get much better when the shell emits semantic truth instead of making the terminal guess.
Ghostty's prompt click-to-move again reinforces that active-input magic gets safer when confined to shell-marked prompts.

So even in a pane-heavy interface, the shell still needs to say:
- where input is,
- what command/output blocks are,
- whether a pane is live or restored,
- and what exact running/reviewed object a local view corresponds to.

## 3) Multiplexers also reveal ambient authority leaks

A few current examples are especially instructive.

### tmux environment carry

tmux documents that `SSH_AUTH_SOCK` can live in the session environment and can be updated on attach or session creation.
That is useful.
It is also a reminder that a session tree can become a quiet carrier of ambient authority.

### WezTerm mux auth-sock routing

WezTerm's `mux_enable_ssh_agent` option sets `SSH_AUTH_SOCK` for panes in the local domain and points it at the authentication socket associated with the most recently active multiplexer client.
That is a very powerful convenience seam.
It is exactly the kind of stateful view-driven authority coupling Schell should treat with suspicion.

### kitty remote control and launch/source-window copying

kitty can open windows, send arbitrary text input to windows, and copy data such as title, env vars, cwd, and screen contents from a source window.
It can also substitute `@selection` and use screen/last-command outputs as stdin sources.
Again: powerful, delightful, and clearly worth learning from.
But also a good example of how quickly a pane tree can become a hidden automation and inheritance plane.

### Zellij plugin startup

Zellij lets plugins load on startup and only show a permission request if they need permissions.
This is a nice signal that local panes/plugins/layouts can stay rich while still preserving an explicit permission seam.

## 4) The best ideas to steal are local, visible, and reversible

The best imports from this family look like:

- drag/reorder/zoom/split actions that remain clearly local,
- readonly replay panes,
- compare panes bound to exact receipts or command regions,
- scratch panes that make temporary work fast,
- inspector panes that expose semantic state for debugging,
- layout templates as derivative wrappers,
- and shell-marked command/output selection inside each pane.

These are exciting because they make Schell feel like a new class of tool without forcing a deep architecture bet too early.

## 5) The best ideas to refuse are the ambient ones

The most dangerous habits to import would be:

- hidden session-wide env inheritance,
- arbitrary cross-pane send-text as a default casual action,
- pane focus silently deciding cancellation or strong rerun targets,
- restored workspace implying live authority,
- and pane/session objects becoming the durable truth instead of receipts and running-state witnesses.

That is where SlopOS and DelayBasin become especially useful.
SlopOS keeps saying “do not let local convenience become portable authority,” while DelayBasin keeps saying “publicly distinguish live state, reentry wrappers, and derivative operator surfaces.”

## 6) A small Schell concept cluster now looks no-regret

### View tree

A local arrangement of windows, tabs, panes, shelves, overlays, and inspectors.
This is an ergonomic tree, not a portable execution contract.

### Pane lease

A compact local contract that says:
- what lane or object a pane currently hosts,
- whether it is interactive or readonly,
- whether it is live or restored,
- and what kinds of local actions it permits.

### View action family

Local operations such as split, zoom, reorder, detach, pin, compare, scratch, inspect, or close.
These should be excellent.
They should also stay visibly local unless they route back into an exact shell object.

### Cross-pane packet

Any send/copy/insert/derive move across panes should become an explicit packet or proposal rather than an ambient “just fire text into that other pane” habit.

## 7) This is also a product opportunity

A custom shell+terminal can beat today's terminals here by making view truth and shell truth cooperate instead of blur.

For example:
- a restored pane can be clearly restored,
- a receipt pane can be obviously readonly,
- a scratch split can be visibly unbound from durable state,
- an inspector pane can show exact shell semantics,
- and the one true active input can remain obvious even inside a rich pane tree.

That is the kind of humane clarity current tools only partially achieve.

## 8) The new no-regret rule

The current no-regret rule should be:

**collect aggressive pane/session/layout ideas, but only admit them as local view mechanics until the shell explicitly reifies their durable truth.**

That gives Schell permission to be ambitious on UX while still staying careful about authority, replay, and transcript truth.
