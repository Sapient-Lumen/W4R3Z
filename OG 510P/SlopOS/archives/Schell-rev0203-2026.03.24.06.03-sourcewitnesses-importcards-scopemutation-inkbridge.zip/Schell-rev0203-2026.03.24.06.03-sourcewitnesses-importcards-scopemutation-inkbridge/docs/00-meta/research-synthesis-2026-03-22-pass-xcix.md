# Research synthesis, pass XCIX (2026-03-22)

This pass asks one narrower question:
**what should Schell learn from modern prompt systems without letting prompt-time code, startup hooks, async segments, or repo-local context loaders become a hidden second shell?**

The answer is now pretty crisp.
**The right move is not “pick the prettiest prompt.” The right move is to treat prompt rendering as an explicit witness family with segment provenance, redraw class, freshness posture, and async-cost humility.**

## 1) The ecosystem keeps proving that prompts are both a UX multiplier and a trust hazard

fish, PowerShell, zsh, Nushell, Starship, direnv, Powerlevel10k, and Oh My Posh all keep proving the same thing:
people love prompts that feel alive.
They want:
- left and right prompts,
- vi-mode indicators,
- transient prompts,
- instant startup feel,
- repo/cloud/runtime context,
- and context that changes with cwd or remote posture.

That is exactly the sort of luxury Schell should steal.
But it is also exactly the seam where prompt code can quietly become startup code, directory hook code, shell-out code, or helper recursion if the shell stops naming what kind of prompt fact it is showing.

## 2) fish and Nushell show the clean version of the idea

fish keeps the prompt model concrete:
`fish_prompt`, `fish_right_prompt`, and `fish_mode_prompt` are explicit functions, and transient prompt final rendering is a separate call path.
Nushell does something similarly clarifying:
prompt components are explicit env-bound strings or closures, and transient prompt components are separate variables rather than an invisible renderer trick.

That is the right design pressure for Schell.
Left prompt, right prompt, mode chip, transient redraw, and final historical repaint should remain separately named.

## 3) zsh and PowerShell remind us that prompt hooks are real execution surfaces

zsh gives you `precmd`, `preexec`, `periodic`, `chpwd`, and prompt substitution.
That is powerful and attractive.
It is also a reminder that “the prompt” is not one thing.
It can mean:
- code before every prompt,
- code before command execution,
- code on directory change,
- and prompt strings that themselves allow substitution.

PowerShell is equally candid: the `prompt` function is just code, and profiles are startup scripts that can load modules, aliases, variables, drives, and arbitrary commands.

Schell should absorb the lesson without copying the whole structure.
Prompt luxury is worth stealing.
Unbounded prompt-time programmability is not a safe default.

## 4) current prompt engines prove the luxury bundle and the trap bundle arrive together

Starship proves how much delight you can get from composable segments, right prompts, and cross-shell portability.
It also admits the operational truth:
there are prompt-wide scan and command timeouts,
custom modules can run commands,
and shell-specific prompt escaping matters enough that the docs warn about unescaped output and recommend no-profile style execution when custom commands are involved.

Powerlevel10k proves that instant prompt is compelling enough that people will change startup order for it.
Oh My Posh proves transient prompt and templated segment reuse are desirable.
direnv proves that per-directory context loading is convenient enough that people normalize work on every prompt.

Together these tools say:
**prompt luxury should be admitted only with visible provenance, budget, and downgrade posture.**

## 5) The safe steal is smaller than a final prompt engine

The no-regret import is not one final theme system.
It is one explicit **prompt witness** family that can say:
- which segment is being rendered,
- whether it is left / right / mode / transient / final historical repaint,
- where its data came from,
- whether it is shell-known, cached, imported, bridged, or shell-out derived,
- whether it is current, stale, refreshing, historical, or unknown,
- whether it required prompt-path shell-out or async repair,
- and whether its output is display-only or carries stronger route/review affordances.

That keeps prompts rich while still keeping reviewed action, capability basis, and startup ownership elsewhere.

## 6) A prompt should be allowed to feel instant before it is allowed to feel omniscient

The right construction order is:
1. shell-known cheap facts first,
2. cached facts with freshness badges second,
3. async repair or explicit refresh later,
4. stronger env/context mutations never hidden inside redraw.

This is the key historical lesson.
A prompt that blocks on shell-outs, scans, network reads, or repo hooks is not merely slow.
It has started to make hidden work part of the shell’s emotional contract.

## 7) Compact conclusion

The strongest companion-compatible move in this pass is:
**let Schell steal prompt delight, but keep startup footing, directory hooks, segment provenance, redraw class, and freshness/cost posture separately named.**

That lets Schell become much more humane than legacy shells without deciding too early:
- one final prompt theme engine,
- one final hook taxonomy,
- one final async segment runtime,
- or one final repo-context activation treaty.
