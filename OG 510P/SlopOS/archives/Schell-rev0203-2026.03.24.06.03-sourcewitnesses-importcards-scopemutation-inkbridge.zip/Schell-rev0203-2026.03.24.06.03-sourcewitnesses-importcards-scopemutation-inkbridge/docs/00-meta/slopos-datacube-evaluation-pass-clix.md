# SlopOS datacube evaluation — pass CLIX

This pass asks a narrower companion-safe question than “how should Schell show the current account?”
The better question is:
**how should Schell expose current target identity as a typed stack without letting ambient config, remembered prompt badges, or helper residue impersonate exact current authority?**

## 1) SlopOS exact selector posture argues against one ambient current-target myth

SlopOS keeps execution selection exact and refuses ambient lookup as authority.
That pressure transfers directly here.
An exact current subject should not come from generic atmosphere either.

If Schell says a command will hit a specific subscription, project, cluster, namespace, or role, it should be able to say which exact selector layer established that claim.

## 2) SlopOS profile and provider-local boundaries suggest target layers should stay separately named

SlopOS already keeps provider-local import details smaller than portable truth and keeps profile stacks reviewable rather than ambient.
That means Schell should also keep these layers distinct:
- authenticated identity,
- selected profile or configuration,
- current default target,
- environment override,
- command-local override,
- and optional impersonation or adopted role.

The mistake would be to flatten them into one glowing `current account/context` badge.

## 3) ViewFS pressure says handle, adopted selection, and live current use should stay distinct

ViewFS repeatedly refuses to collapse handles, adopted objects, and live current state.
That pressure fits target identity almost perfectly.
A selected AWS profile, a current Azure subscription, a gcloud configuration, a kube context, a per-command namespace flag, and an impersonated principal are not one object.

So Schell should show target identity as a small stack of witnesses instead of one scalar.

## 4) Steward pressure says wrong-target retries should be exact, not atmospheric

Steward keeps pushing precise retry posture.
That matters a lot once commands are pointed at real tenants, projects, clusters, or roles.
Operators need to know whether a failure means:
- wrong current profile,
- wrong subscription or project,
- wrong namespace,
- stale env override,
- missing impersonation,
- or simply the wrong host/account.

That makes typed subject witnesses better than generic “check your credentials/context” prose.

## 5) Helm pressure says return anchors and drift cards matter for current target too

Helm keeps teaching that historical-looking success is dangerous when basis drifted.
That matters here too.
A prompt chip may still show the old project.
A broker may have refreshed one account while the active profile still points elsewhere.
An environment override may silently outrank the configuration.
A one-off command flag may hit a different target than the visible ambient strip.

So Schell should pair current-subject chips with exact basis reveals, override delta cards, and drift/reset cues.

## 6) What Schell should steal now

Schell should steal several high-value moves:
- a **current-subject strip** that shows a small ordered target stack rather than one scalar badge,
- **source chips** such as `from config`, `from env`, `from flag`, `from broker`, and `historical`,
- a **who will this hit now?** preview for the pending command,
- **override delta cards** when command-local targeting differs from ambient defaults,
- and a lightweight **subject-hop journal** so target drift becomes visible without pretending old state is still current.

These are great luxuries and do not force Schell to settle one universal provider model or one final prompt/status architecture.

## 7) What Schell should refuse now

Schell should refuse:
- `logged in` counting as `current target chosen`,
- prompt memory counting as stronger than command flags or impersonation,
- host-global profile state counting as command-local exact target truth,
- historical target chips counting as live footing,
- and one provider’s context concept becoming the universal model for every tool.

## 8) Compact conclusion

The companion-safe move is to keep **identity, configuration, default target, env override, command override, and impersonation** separately witnessed.
That lets Schell become dramatically more humane around modern multi-account CLI work while staying aligned with SlopOS’s refusal to let ambient selection folklore become portable authority.
