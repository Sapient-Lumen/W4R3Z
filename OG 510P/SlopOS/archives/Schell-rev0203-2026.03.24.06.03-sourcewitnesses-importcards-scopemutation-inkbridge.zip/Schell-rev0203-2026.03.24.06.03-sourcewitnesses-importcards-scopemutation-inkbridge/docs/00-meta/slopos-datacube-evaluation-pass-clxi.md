# SlopOS datacube evaluation — pass CLXI

This pass asks a narrower companion-safe question than “how should Schell show cwd?”
The better question is:
**how should Schell expose current working ground without letting one prompt path, breadcrumb, or restored label impersonate exact current relative-bind truth?**

## 1) SlopOS exact-boundary posture argues against one ambient path myth

SlopOS keeps imports, carriers, and authority explicit instead of ambient.
That pressure transfers directly here.
If Schell says a relative action will bind against a directory, provider drive, translated namespace, or restored ground, it should be able to say which exact location witness established that claim.

## 2) SlopOS import boundaries suggest route family and object identity should stay separately named

SlopOS already keeps imported carriers, adopted state, and current live authority separate.
That means Schell should also keep these layers distinct:
- entered path token,
- display path,
- logical cwd,
- physical cwd,
- provider or namespace family,
- and the later prepared action / execution receipt.

The mistake would be to flatten them into one cozy “you are here” story.

## 3) ViewFS pressure says visible path and exact basis are not the same object

ViewFS keeps basis, applied state, and delta truth explicit.
That pressure fits current-directory truth almost perfectly.
A breadcrumb label, a symlink-preserved path, a canonical filesystem target, a provider route, and the receipt of what a relative command actually touched are not one object.

So Schell should show cwd truth as a witness family instead of one scalar prompt segment.

## 4) Steward pressure says retry and repair need exact footing

Steward keeps retry and pushback posture exact.
That matters here too.
Operators need to know whether a surprise came from:
- logical-versus-physical divergence,
- a provider-backed location that does not support the same actions as a filesystem directory,
- a restored or translated path that is weaker than live footing,
- or a relative action binding against a different ground than the prompt implied.

That makes cwd witnesses better than generic “current folder” comfort.
Repair can come later and stay weaker.

## 5) Helm pressure says changed basis and reset cards matter for location too

Helm keeps teaching that historical-looking continuity is dangerous when basis drifted.
That matters here as well.
A path label may still look familiar while:
- the symlink target changed,
- the provider/drive family changed,
- the shell restored a prior logical label without reacquiring physical certainty,
- or a translated path is no longer an exact same-object claim.

So Schell should pair cwd chips with divergence cards, provider badges, and reset cues.

## 6) What Schell should steal now

Schell should steal several high-value moves:
- a **dual-path cwd strip** that blooms only when logical and physical footing diverge,
- **ground-kind badges** that say filesystem, provider, remote, translated, or unknown,
- **relative-bind previews** for location-sensitive actions,
- **divergence cards** when prompt display and stronger footing disagree,
- and **receipt-level path pins** so transcripts remember both display path and exact working-ground witness.

These are great luxuries and do not force Schell to settle one final filesystem identity model or path ontology too early.

## 7) What Schell should refuse now

Schell should refuse:
- a display breadcrumb counting as full cwd truth,
- a canonical physical path counting as the only meaningful location truth,
- provider routes counting as ordinary filesystem directories,
- translated paths counting as same-object identity by default,
- and restored location residue counting as fresh current footing.

## 8) Compact conclusion

The companion-safe move is to keep **entered path, display path, logical footing, physical footing, provider family, and receipt-level bind ground** separately witnessed.
That lets Schell become dramatically more humane around cwd and relative actions while staying aligned with SlopOS’s refusal to let ambient labels become portable authority.
