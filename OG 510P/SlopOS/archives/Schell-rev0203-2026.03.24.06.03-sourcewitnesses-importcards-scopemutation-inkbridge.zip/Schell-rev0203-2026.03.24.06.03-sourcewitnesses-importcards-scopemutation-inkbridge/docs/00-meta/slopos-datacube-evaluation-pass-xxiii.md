# SlopOS datacube evaluation, pass XXIII

**Reusable command knowledge should stay explicit, non-authoritative, and review-landed. SlopOS keeps teaching the same deep lesson: workflow plumbing, learn mode, and reusable automation are useful only when they do not smuggle durable authority, hidden retries, or callback folklore back into the system.**

This pass focuses on a very tempting seam for Schell:
- repeatable commands,
- named recipes,
- parameterized runbooks,
- chapter-to-workflow promotion,
- and command sharing.

That seam looks innocent because shells have always had aliases, snippets, and notes.
But SlopOS keeps showing why this is not a harmless convenience seam.
It is another place where bounded control state can quietly regrow into hidden power.

## 1) SlopOS workflow routing stays explicit-invocation and request-local

The current SlopOS workflow/plumb posture is very clear.
Cross-app routing is allowed, but the router remains a request-local seam rather than a durable inbox, callback registry, or ambient bus.
That is a powerful import for Schell.

A reusable command artifact should not behave like:
- a hidden subscription,
- a standing callback,
- a silent retry queue,
- or an ambient "run the right thing later" promise.

The import is:
**workflow seeds should stay explicit artifacts that a person invokes again, not background routing magic.**

## 2) SlopOS keeps non-authoritative descriptors separate from real grants

Capshell's CH-WALLET posture treats wallet summaries as non-authoritative descriptors.
Authority diffs and receipts are explanatory surfaces, not grants by themselves.
That should pressure Schell directly.

A saved command seed or shared runbook may preserve:
- authority summary,
- peer summary,
- ground summary,
- and basis expectations,

but it should not itself prove that:
- the same authority is live now,
- the same remote peer is present,
- the same cwd/env ground still exists,
- or the same approval can be replayed without fresh review.

## 3) SlopOS learn mode keeps suggestion observational only

The current capshell learn-mode posture is one of the most important imports here.
Learn mode is observational only.
It does not auto-edit, auto-approve, or auto-rerun.

That is a direct warning for Schell reusable command features.
A generated recipe, proposed workflow seed, or recovered runbook step should be:
- helpful,
- inspectable,
- maybe even richly parameterized,
- but still weaker than a fresh reviewed action.

## 4) SlopOS powerbox discipline says summaries must be canonical, not flattering prose

Consent-mediating surfaces in SlopOS are supposed to summarize canonical bytes/digests rather than whatever the nearest prose says.
That pressure transfers beautifully to Schell.

A workflow seed or runbook step should be derived from:
- one exact chapter,
- one exact command template,
- one exact parameter schema,
- one exact basis contract,

rather than from a model-written summary like "the deploy command from earlier."

## 5) SlopOS keeps export/share distinct from local observation

Across OpenURI, transfer, and workflow-plumbing families, SlopOS keeps mediated export and transfer explicit.
That should discipline Schell sharing features.

Local chapter browsing and command reuse are one thing.
Durably exporting or sharing a command chapter or runbook is another.
Schell should keep at least these distinct:
- local-only seed,
- attach-for-help bundle,
- explicit durable share/export,
- and operator-private note.

## 6) SlopOS keeps request identity separate from later current state

The datacube keeps returning to the same rule:
request objects and receipts are not live-state oracles.
That matters for runbooks too.

A runbook may remember that a command once succeeded under some exact basis.
It should not be allowed to imply that:
- the next run is safe,
- the target service is still in the same state,
- the remote lease is still active,
- or the old approval basis still matches.

That means reusable command artifacts should probably reopen as:
- inspect,
- insert into active input,
- review against current basis,
- or hold because drift is unknown.

## 7) What SlopOS pressures Schell to steal

The strongest import is not a giant workflow system.
It is a compact posture cluster:
- reusable commands are explicit artifacts,
- summaries are canonical enough to diff and review,
- suggestion/learn surfaces are non-authoritative,
- share/export is a separately named mediation lane,
- and old command success is never a silent approval cache.

## 8) What Schell should deliberately refuse

### Refuse aliases as the primary workflow story

Aliases and startup macros are too ambient to carry the new honesty model.
They erase provenance and make execution feel pre-approved.

### Refuse palette-select-means-run

Selecting a saved seed from search or a palette should not itself be execution authority.
It should land in active input or a review surface first.

### Refuse provenance bleach on promotion

Promoting a chapter into a seed or runbook should not erase:
- lane,
- source kind,
- peer partition,
- basis contract,
- or share posture.

### Refuse durable share by accident

Copying, attaching for help, and durable public/team sharing are not the same action.
Schell should keep those separate.

## 9) Current consequence for Schell

The best next step now looks compact:
1. one exact **workflow-seed** artifact derived from a command chapter,
2. one **parameter-card** surface preserving typed/default/enum-like hints,
3. one rule that seed selection lands in **active input or explicit review**,
4. one **share-posture** ladder,
5. and one **drift/hold** rule before strong rerun from a seed.

That is enough to make command reuse feel dramatically better than shell folklore while still keeping notebook shape, sync, collaboration, and final automation treaties open.
