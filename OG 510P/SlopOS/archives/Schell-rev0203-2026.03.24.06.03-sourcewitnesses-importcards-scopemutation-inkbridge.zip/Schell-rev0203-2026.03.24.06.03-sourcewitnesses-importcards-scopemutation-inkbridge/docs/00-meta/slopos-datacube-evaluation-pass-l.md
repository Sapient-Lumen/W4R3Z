# SlopOS datacube evaluation, pass L

This pass keeps one bounded thesis in focus:
**the newest SlopOS OpenURI work is exactly the restraint Schell needs if it wants command chapters, semantic-history gestures, and saved workflow seeds to feel luxurious without silently becoming a second browser or a second shell.**

That matters because the most tempting shell+terminal ideas now all cluster around the same visible gestures:
click, reveal, open, rerun, save, and share.
SlopOS is doing valuable work by refusing to let those gestures overclaim what the system actually knows.

## 1) SlopOS keeps open semantics smaller than terminal folklore wants them to be

The OpenURI family in SlopOS is impressively disciplined.
It refuses to turn generic open into:
- a handler inventory oracle,
- a chooser-control surface,
- a selected-handler receipt,
- a launch-completion proof,
- a web-permission broker,
- or a hidden materialization/download workflow.

That is exactly the lesson Schell should import.
A custom shell+terminal should absolutely expose better visible routes for links, files, ports, and object cards.
It should still keep the underlying open contract humble.

## 2) Handler choice and launch completion should stay weaker than users think they are

Two SlopOS boundaries are especially valuable here:
- handler-selection boundary,
- launch-completion boundary.

Together they say:
- the requester does not get to learn or steer the concrete handler in a portable way,
- and launch success is not proof that the content rendered, was read, or later finished doing something useful.

For Schell, that means every “open” witness should remain narrower than terminal lore usually implies.
A click or key can produce a route witness and an admission-scoped receipt.
It should not quietly become:
- “the right app opened,”
- “the user saw it,”
- or “the task is now complete.”

## 3) Subject-echo and web-permission boundaries matter directly to terminal design

SlopOS also refuses two other attractive forms of overreach:
- durable raw-URI echo as generic history truth,
- and portable browser/web permission mediation on OpenURI.

That is a direct warning for Schell.
If the terminal sees a destination in output or hover chrome, it should not assume that durable transcripting of the exact raw subject is harmless.
And if a launched page later asks for camera, microphone, or location, that downstream permission story is not something the shell+terminal should pretend it mediated just because it initiated the open.

This is the right posture for a design-phase shell+terminal.
It preserves honesty before taste turns into architecture debt.

## 4) Show-item exactness is the right model for reveal versus open

The SlopOS show-item exactness boundary is another excellent import.
It says that “show this exact item” should fail closed rather than silently degrade into opening a parent directory.

Schell should steal that distinction aggressively.
In terminal land, operators constantly get flattened verbs like:
- open,
- reveal,
- inspect,
- browse nearby,
- and go to source.

Those are not the same action.
A super-awesome shell+terminal will feel better precisely because it stops flattening them.

## 5) Capshell exact-exec posture also pressures workflow capture

The newer capshell executable-object posture is equally important for reuse.
Once an executable object has been reviewed, SlopOS refuses to reopen a mutable name at the last moment and quietly retarget execution.

That is the exact rule Schell should import for workflow seeds.
A command chapter promoted into a reusable seed must not silently become:
- “whatever command text happens to look similar now,”
- “whatever handler opens this object today,”
- or “whatever current project context seems nearby.”

Promotion should preserve exact reviewed action shape and then separately show drift.

## 6) What this means for Schell right now

The right near-term import is not a browser subsystem and not a workflow engine.
It is a small set of visible witness objects:
- command chapters,
- workflow seeds,
- route witnesses,
- safe-open ladders,
- and admission-scoped launch receipts.

That gives Schell room to become delightful while still honoring the stronger SlopOS rule:
**helpful gestures may accelerate the operator, but they do not get to widen meaning in secret.**

## 7) Lessons from the past we must actually learn

Past systems repeatedly made three bad bets here:
1. letting clicks flatten distinct actions into one “do the smart thing” myth,
2. letting saved commands lose provenance and drift silently,
3. letting open success overclaim downstream truth.

SlopOS is already trying hard not to repeat those mistakes.
Schell should use that design-phase advantage while it still can.

## 8) Super-awesome moves that remain honest

The nicest Schell moves in this seam now look like:
- one chapter-capture chip that can copy, re-input, bookmark, or promote,
- one workflow-harvest card that suggests parameters but never auto-runs,
- one hover/inspect card that reveals full destinations and source class,
- one reveal/open/safe-open ladder,
- and one receipt lane that says only admission-scoped truth.

That is enough to feel custom and luxurious without pretending the shell has become a universal browser, editor, or launch oracle.
