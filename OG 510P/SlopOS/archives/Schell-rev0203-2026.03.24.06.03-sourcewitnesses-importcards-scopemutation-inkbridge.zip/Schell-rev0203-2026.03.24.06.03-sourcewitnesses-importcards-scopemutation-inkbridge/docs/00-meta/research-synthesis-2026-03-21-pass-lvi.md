# Research synthesis, pass LVI (2026-03-21)

This pass keeps one fresh design rule in focus:
**Schell should steal assistant luxury — natural-language help, plan mode, saved prompts, reusable skills, scoped subagents, checkpoints, and explicit tool permissions — but only if assistant work stays visibly separate from exact shell input and remains weaker than reviewed execution truth.**

This seam matters because the shell+terminal world is now full of agentic products, and many of the best ideas really are worth stealing.
Natural-language requests are often a faster way to start.
Saved AI prompts are a real form of reuse.
Scoped tool permissions, context attachments, and checkpoints make ambitious work less scary.
But the historical trap is equally clear:
when chat, shell input, command generation, permissions, and execution collapse into one flattering surface, operators stop knowing what is still just a proposal.

## 1) Warp is right to separate the clean terminal from multi-turn agent work

Warp's current Agent Modality docs are one of the strongest clues available.
They explicitly separate a clean terminal session from a dedicated Oz agent conversation view, and the point is not only aesthetics.
The point is that commands and multi-turn agent workflows are different kinds of work.
Schell should steal that insight.
A shell+terminal gets safer and clearer when assistant conversation is a named lane rather than a mood that invisibly takes over the same input field.
See: https://docs.warp.dev/agent-platform/local-agents/interacting-with-agents/agent-modality

## 2) VS Code proves that Insert and Run should stay separate verbs

VS Code's terminal inline chat remains a very healthy pattern.
The assistant can propose a command, but the operator still chooses between **Run** and **Insert**.
The inserted path matters a lot.
It keeps active input editable, preserves review opportunity, and makes assistant suggestions visibly weaker than immediate execution.
A useful extra clue appears in the February 2025 release notes: suggested terminal commands are shown inline and can be edited before running.
Schell should absolutely steal that split.
See: https://code.visualstudio.com/docs/copilot/chat/inline-chat
See: https://code.visualstudio.com/updates/v1_98

## 3) Claude Code shows the right safety primitives: plan mode, permissions, and checkpoints

Claude Code's current docs expose a compact safety bundle Schell should learn from carefully.
The product distinguishes default approval, auto-accept-edits, and **plan mode**.
That is a very good hint for Schell: read-only reconnaissance is a different lane than executing commands.
The docs also say checkpoints snapshot file contents before edits and make file edits reversible, while warning that external side effects like databases, APIs, and deployments cannot be checkpointed.
That is exactly the kind of humility a serious shell+terminal needs.
The permission docs are just as valuable because they keep allow/ask/deny rules explicit and ordered, instead of pretending that a smart agent somehow became trustworthy on its own.
See: https://code.claude.com/docs/en/how-claude-code-works
See: https://code.claude.com/docs/en/permissions

## 4) Kiro's approval ladder is blunt in a useful way

Kiro's terminal integration docs are refreshingly concrete.
A natural-language request becomes a suggested command, and the operator can choose **Modify**, **Reject**, **Run**, or **Run and Trust**.
That is not the final Schell wording, but it is a terrific pattern.
Approval verbs should say what they do.
They should not hide inside a magic Enter key or a fuzzy “looks good” button.
Schell should keep any stronger trust move explicit, narrower than ambient shell authority, and easy to inspect later.
See: https://kiro.dev/docs/chat/terminal/
See: https://kiro.dev/changelog/

## 5) Saved prompts and skills are worth stealing, but they are still playbooks, not authority

Warp Prompts and Claude Code skills both show something important: reusable natural-language playbooks are genuinely useful.
Warp lets operators save parameterized prompts and surface them in command-palette/search flows.
Claude Code skills create reusable command-like entries, can load supporting files, and can restrict tool access or require manual invocation.
That is a powerful Schell clue.
Reusable assistant artifacts deserve first-class names.
But they should stay obviously distinct from exact shell functions, explicit workflows, and reviewed executable objects.
A saved prompt is not an executable contract merely because it has a name.
See: https://docs.warp.dev/knowledge-and-collaboration/warp-drive/prompts
See: https://code.claude.com/docs/en/slash-commands

## 6) Subagents and context isolation are more stealable than giant shared chats

Claude Code's docs note that subagents get their own fresh context and return a summary instead of bloating the main conversation.
That matters a lot.
One of the fastest ways to make assistant tooling confusing is to keep stuffing more tools, memories, and side quests into one giant chat transcript.
Schell should lean toward isolated scouting, summarized return, and explicit attachment of outputs rather than one omniscient terminal ghost with unbounded session memory.
See: https://code.claude.com/docs/en/how-claude-code-works

## 7) The foot-gun pattern is already visible too

Current agent tools also show exactly what to fence off.
Warp can auto-detect natural language in terminal input.
VS Code agent mode can run terminal commands and iterate across tool calls.
Claude Code supports hooks that execute automatically at lifecycle points, and its docs warn that `--dangerously-skip-permissions` belongs only in sandboxes without internet access.
These are not reasons to reject assistant help.
They are reasons to keep Schell's agent lane visibly bounded:
chat is not shell input,
a tool allowlist is not ambient shell authority,
a checkpoint is not rollback for remote effects,
and automatic hooks should not quietly become shell meaning.
See: https://docs.warp.dev/terminal/classic-input
See: https://code.visualstudio.com/blogs/2025/04/07/agentMode
See: https://code.claude.com/docs/en/best-practices

## 8) The stealable move: assistant-lane witnesses

The best decision-light move now looks like this:
1. assistant work lives in a visibly distinct lane or mode,
2. any generated command can land as **insert**, **review**, or **run** rather than one blended accept path,
3. plan/read-only scouting stays distinct from side-effectful execution,
4. permission posture and trusted-tool scope stay visible,
5. saved prompts/skills stay reusable playbooks rather than ambient authority,
6. subagents/context shards return summaries instead of widening the main input lane,
7. checkpoints are clearly marked as file-local rather than global rollback truth,
8. and stronger reusable behavior still promotes into separately named shell/workflow artifacts when it deserves execution-grade standing.

That would give Schell a genuinely futuristic feel without freezing one final chat backend, one model/provider treaty, one plugin ecosystem, or one assistant↔shell transport.

## 9) Lessons from the past are already clear enough to state bluntly

The shell world keeps relearning these mistakes:
- blending help with execution until no one can tell which text is live,
- letting prompt-like artifacts quietly become policy,
- overclaiming what undo/rewind covers,
- and treating trusted-once automation as ambient authority forever.

The healthier lesson is narrower:
**make assistant work luxurious, but keep it visibly separate, proposal-first, and weaker than exact reviewed shell truth.**

## 10) A compact first proving slice

A compact proof could show:
- one dedicated assistant lane or clearly marked input mode,
- one natural-language request that yields both Insert and Run paths,
- one read-only plan mode,
- one explicit permission strip for tools/commands,
- one checkpoint/rewind card marked file-local only,
- one saved parameterized prompt or playbook,
- one isolated subagent/scout summary,
- and one refused auto-run or auto-hook pattern that would have widened authority too far.

That would already make Schell feel substantially better than ordinary terminal chat add-ons without freezing the final stack.

## 11) Decisions intentionally kept open

This pass does **not** freeze:
- one final assistant backend,
- one chat transcript/storage model,
- one plugin or MCP substrate,
- one prompt/skill file format,
- one permission grammar,
- or one unified shell+assistant input protocol.

The no-regret move is smaller:
**steal separate assistant lanes, insert/review/run splits, plan mode, scoped permissions, playbook reuse, and checkpoint humility — but keep assistant conversation weaker than exact shell execution truth.**
