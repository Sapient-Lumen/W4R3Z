# SlopOS datacube evaluation, pass LXXXVII (2026-03-22)

This pass evaluates startup/config layering, overlay provenance, and runtime injection against the current SlopOS archive.
The result is clear:
**SlopOS strongly rewards a shell that treats configuration as reviewed compiled basis plus explicit runtime overlays, rather than as ambient startup folklore or invisible helper mutation.**

That pressure is unusually strong in the companion archive and fits the current shell/terminal lessons very well.

## 1) SlopOS already wants privileged configuration to be compiled output, not live-script folklore

ADR-0004 in the companion archive is unusually crisp: CH-CFG is compiled output, generations are tracked outside the privileged core, and the privileged side is limited to decode → validate → apply.
That is an excellent anchor for Schell.

For Schell this implies:
- reviewed durable config should look more like compiled basis than like ad-hoc startup scripting,
- rollback/generation selection should be routine,
- and terminal/session helpers should not quietly widen into config authority.

## 2) SlopOS activation posture prefers descriptive handoff over hidden startup brains

RFC-0081 keeps activation handoff supervisor-owned and inbound-only, treats the activation set as descriptive rather than bearer authority, and keeps optional continuity stores bounded and non-inventory.
That lines up directly with shell startup humility.

For Schell this implies:
- startup footing should be described explicitly rather than inferred from hidden helper state,
- terminal injection or project overlays should show up as named authors in the current footing,
- and “the shell started like this” should stay weaker than exact reviewed config basis unless it was actually promoted there.

## 3) SlopOS keeps rejecting ambient authority, and rc-file culture is ambient authority in disguise

Much of the companion archive exists to prevent hidden widening through ambient names, ambient portals, ambient helper planes, and global mutable state.
Classic shell startup culture often does the opposite: prompt hooks, sourced plugin packs, path surgery, project-local env mutation, and terminal-injected scripts all pile into one lived environment with weak provenance.

For Schell this implies:
- startup, config, and overlays should become explicit packets/cards with source and scope,
- not one giant “dotfiles loaded” myth,
- and project overlays should remain separately suspendable and reviewable.

## 4) SlopOS generation posture says effective live behavior should still admit its basis

The companion archive consistently rewards exact basis, visible diff/receipt behavior, and reversible generation workflows.
That is exactly the right answer for shell config too.

For Schell this implies:
- users should be able to see both the reviewed basis and the currently effective result,
- project/runtime overlays should stay visibly narrower or newer than basis,
- and restored window/session residue should not impersonate durable config intent.

## 5) SlopOS also helps distinguish config, state, and residue

Across snapshots, evidence, export, and view-bound posture, SlopOS keeps derivative state weaker than exact source truth.
That matters here because shells love to mix config with runtime state: recent directories, prompt caches, session layouts, restored tabs, and integration shims all end up masquerading as “my config”.

For Schell this implies:
- config intent,
- live state,
- accelerators/cache,
- and restored historical residue
should stay separately named.

## 6) The current ecosystem gives a companion-compatible answer

Current tools now prove a narrow pattern that matches SlopOS well:
- Bash/zsh/PowerShell prove startup layering is real authority,
- fish and Nushell prove organized per-surface config plus effective-config inspection are worth stealing,
- Ghostty and VS Code prove terminal injection is useful but should be disclosed,
- direnv proves project-local overlays are powerful but deserve source/scope visibility,
- and WezTerm proves reloadable config should avoid side effects in main evaluation flow.

SlopOS sharpens the import:
**Schell should steal effective config visibility and explicit overlays, not rc-file mythology.**

## 7) What this pass now strongly suggests for Schell

The most companion-compatible moves are:
- **startup-footing badges**,
- **config-ground cards**,
- **effective-config flatten**,
- **overlay cards** for project or terminal-provided changes,
- **side-effect hook fences**,
- **generation/rollback rails** for durable config basis,
- and **live-vs-basis compare** before stronger promotion.

## 8) Decisions this pass still refuses to make too early

This pass still does **not** force:
- one final config language,
- one final pack/theme/plugin format,
- one final terminal-integration contract,
- one final project-overlay runtime,
- one final startup-trace protocol,
- or one final config-generation storage engine.

The answer stays smaller and stronger:
**let Schell become excellent at showing startup footing, config ground, and overlay provenance — but keep reviewed basis, live runtime overlays, and restored residue separately named.**
