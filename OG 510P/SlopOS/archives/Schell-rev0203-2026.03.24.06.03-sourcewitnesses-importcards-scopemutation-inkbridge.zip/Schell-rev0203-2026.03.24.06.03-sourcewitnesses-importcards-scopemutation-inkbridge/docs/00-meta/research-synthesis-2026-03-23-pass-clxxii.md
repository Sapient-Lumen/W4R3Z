# Research synthesis — 2026-03-23 — pass CLXXII

This pass sharpens one fresh lesson from current platform and terminal-adjacent docs:
**activation comfort increasingly depends on short-lived tokens and user action, but the useful thing users still need afterward is a tiny honest record of what actually happened to the baton.**

## 1) freedesktop notifications already split invocation from activation token delivery

The Desktop Notifications spec says clients should not assume `ActionInvoked` will even be emitted, because some servers may not support user interaction at all.
It also defines a separate optional `ActivationToken` signal that can be emitted **before** `ActionInvoked` and that carries a token for activating a toplevel.

That is a superb clue for Schell.
The user-facing story after a click is not one scalar "activated" result.
There are at least three nearby facts:
- the notification existed,
- an action may or may not have been invoked,
- and a distinct activation token may or may not have been supplied.

## 2) XDG Notification and OpenURI keep activation as an explicit field, not an implied outcome

The XDG Notification portal says sandboxed applications cannot learn whether the notification was actually presented, and that clicking one after the app exits may activate it again.
The OpenURI portal carries `activation_token` as an optional field for `OpenURI`, `OpenFile`, and `OpenDirectory`.

This is the right pressure.
Open/reveal routing and foreground request are adjacent, but not identical.
A durable Schell residue object should preserve both, rather than flattening them into one flattering success bit.

## 3) AppChooser is unusually explicit about token regeneration

The AppChooser backend docs are especially helpful.
They say the chooser can take an `activation_token`, and the results may return an `activation_token` for the chosen application.
If user interaction was involved, a **new token should be generated**; otherwise it may be the same token.

That is exactly the kind of small but important lifecycle truth that current UIs usually hide.
Schell should not.
A baton may be passed through unchanged.
Or a chooser may mint a new one.
A tiny activation receipt can say which happened.

## 4) GlobalShortcuts proves that activation tokens are event-local

The XDG GlobalShortcuts portal includes `activation_token` on both `Activated` and `Deactivated` events.
That strongly suggests that foregrounding tokens are tied to narrow event moments, not durable app truth.

So Schell should avoid one generic idea of "this shortcut owns focus now".
Instead, it should record event-local baton use and then cool immediately into residue.

## 5) Windows foreground docs keep proving that reveal/open and actual focus are different outcomes

Windows documents strong restrictions on `SetForegroundWindow`.
Even if multiple listed conditions are satisfied, the call can still be denied, and when the user is working with another window the system may flash the taskbar button instead.
`AllowSetForegroundWindow` and `CoAllowSetForegroundWindow` exist because foreground privilege can be passed narrowly, not assumed forever.

That is a perfect precedent for Schell activation receipts.
A click or shortcut path can succeed at target resolution and still fail at foreground acquisition.
The right product move is not to hide that.
It is to record it compactly.

## 6) Windows app-notification docs reinforce that launch/activation and later handling are separable

Windows App SDK notification docs say these apps are always launched in the foreground for app notifications and can inspect activation arguments to decide whether to fully launch or handle the activation and exit.
That is another clue that post-activation handling remains a separate decision layer.

Schell should steal that spirit without importing Windows semantics wholesale.
Activation should not be one magical terminal outcome.
It should leave one small, typed residue object that later views can inspect.

## 7) systemd is a useful analogy for delivery versus acknowledgement

`sd_notify()` may tell the service manager about state changes and startup/reload completion, but the docs also warn about attribution races and explicitly offer `sd_notify_barrier()` as a synchronization point.
This is not a desktop activation API, but it is a valuable pattern lesson.

Delivery, attribution, and synchronized acknowledgement are different truths.
That same separation is exactly what Schell needs after baton-bearing flows.

## 8) The no-regret Schell move is a tiny activation receipt

Putting these together suggests a better next move than inventing a larger focus protocol or inbox.
Schell should add a compact **activation receipt** for baton-bearing flows.
The receipt should say:
- what exact target was intended,
- what baton source existed,
- whether the baton was passed, regenerated, consumed, ignored, or expired,
- whether reveal/open succeeded,
- whether foreground/control was granted, denied, or unknown,
- and what the strongest honest next move is now.

## 9) Compact conclusion

freedesktop keeps activation token delivery separate from invocation.
OpenURI and AppChooser keep activation as an explicit field.
AppChooser even documents token regeneration.
GlobalShortcuts makes tokens event-local.
Windows keeps foreground acquisition separate from revealing the right thing and explicitly allows denial.
Windows app notifications keep activation arguments separate from later handling.
systemd reminds us that delivery and acknowledgement are different truths.

So the next no-regret Schell seam is not "smarter clicks" or a giant focus treaty.
It is **activation receipts for baton spend, reveal/open result, foreground denial, and residue floor** so the shell+terminal becomes dramatically more explainable without freezing one final cross-platform activation architecture.
