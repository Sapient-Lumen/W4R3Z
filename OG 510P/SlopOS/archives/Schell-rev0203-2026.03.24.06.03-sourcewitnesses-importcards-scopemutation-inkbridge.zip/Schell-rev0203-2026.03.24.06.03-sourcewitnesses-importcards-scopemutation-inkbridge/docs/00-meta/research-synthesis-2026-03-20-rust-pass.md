# Research synthesis — Rust pass (2026-03-20)

This note records what the current outside landscape suggests specifically for a Rust implementation of Schell.

## Strong candidate ideas to steal

### 1) Modular interactive editing

`reedline` is explicitly a Rust line editor supporting syntax highlighting, completions, multiline editing, Unicode, and other interactive conveniences.
That makes it a useful pressure source for how a strict shell can still feel humane.

### 2) Rich but optional TUI surfaces

`ratatui` is positioned as a Rust library for fast, lightweight, rich terminal UIs.
That makes it a plausible candidate for local review panes, receipt shelves, and denial cards — but only as an additive layer.

### 3) Cross-platform terminal control without early lock-in

`crossterm` and `portable-pty` show that Rust already has credible building blocks for terminal manipulation and PTY work.
That is encouraging, but not a reason to freeze the stack now.

### 4) Structured diagnostic lineage

`tracing` supports structured events and spans with temporal and causal information.
That is an especially good fit for Schell because receipt, replay, and denial lineage are temporal by nature.

### 5) Dependency-graph discipline

`cargo-deny` is worth adopting when code appears because it makes dependency policy a first-class lint surface rather than post-hoc folklore.

## Rust-specific anti-lessons

- Do not turn the first prototype into a crate zoo.
- Do not pick an async runtime just because many Rust projects do.
- Do not let TUI polish become a correctness dependency.
- Do not let logging stay stringly if the shell is supposed to preserve reviewed lineage.
- Do not confuse library availability with architectural necessity.

## Working posture

Rust is a good implementation language for Schell because it supports strong enums, exact data modeling, memory safety, and structured instrumentation.
But the archive should still treat the implementation stack as a **question-bearing surface**, not as solved infrastructure.
