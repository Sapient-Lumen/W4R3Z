# Research synthesis — 2026-03-23 — pass CLXXXVIII

This pass sharpens one smaller lesson from current shell and terminal docs:
**collapse can be wonderful, but a fold header must stay visibly weaker than the exact output it is hiding.**

## 1) Current tools are openly converging on collapsible command-local sections

The newest VS Code release notes are unusually direct here.
Quick terminal commands can stay collapsed to reduce noise, and later release notes describe terminal tool invocations in agent mode as collapsible sections with summary headers that expand to reveal full output.

That is a real product signal.
Modern terminal-adjacent tools increasingly believe:
- the operator wants less visual noise,
- command-local grouping matters,
- and summary headers can improve scanning dramatically.

## 2) Blocks and command-local objects make folding much more natural

Warp's block model makes the command/output boundary explicit enough that copying the command, copying output, re-inputting a command, bookmarking it, or sharing the pair all become natural object-level moves.
That matters because folding works best when the UI already knows what chapter it is folding.

Schell should steal that object clarity without importing Warp's whole product shape.

## 3) The best docs keep a path back to exact output

kitty's shell integration is a strong reminder that summary and navigation become trustworthy when exact output stays one gesture away.
Its shell-aware output browsing can open the output of a selected or recently visited command in a pager.
That is a powerful clue for Schell:
**compact summaries feel safe when reveal is exact, nearby, and unsurprising.**

## 4) Command-local selection and offscreen context are part of the same family

iTerm2's command selection and offscreen command-line display reinforce the same point from a different angle.
The UI helps you operate on a command chapter even when the command text itself has scrolled away.
That suggests folds should not just hide output; they should preserve command-local identity and a tiny amount of context even when the full chapter is not visible.

## 5) The danger is not folding; it is laundering omission into authority

Once the UI can summarize a command, it becomes tempting to let the summary stand in for:
- the full transcript,
- the exact failure explanation,
- the exact share/export surface,
- or the exact review basis for a stronger next action.

That is the historical trap Schell should avoid.
The right move is not “never summarize.”
The right move is:
- keep summaries typed,
- keep hidden-range debt explicit,
- keep reveal exact,
- and keep the stronger next actions separate.

## 6) The no-regret Schell move

Schell should prototype:
- fold receipts,
- summary headers,
- hidden-range / hidden-byte debt chips,
- manual-reveal override,
- automatic expansion for wait-for-input and stronger failure cases,
- and pager/peek affordances for exact command output.

This would import the best current compactness ideas while still refusing to decide one final transcript database, one agent-summary engine, one pager backend, or one block constitution.

## 7) Compact conclusion

The ecosystem is already paying for the lesson:
collapsible command sections are useful, but only if the operator can still tell the difference between the neat local summary and the exact thing that really happened.

So the next low-regret Schell seam is **fold receipts, summary headers, and reveal debt humility**.
