# Research synthesis — 2026-03-23 — pass CXLVI

This pass sharpens one cross-cutting lesson from current official docs:
**the nicest modern shell+terminal luxuries are no longer the risky part; the risky part is letting those luxuries arrive without explicit provenance, explicit strength, and explicit route class.**

That points to a good next Schell move:
**a provenance-first luxury stack** rather than one more giant architecture decision.

## 1) Shell integration is now the foundation of a lot of terminal delight

Current docs from VS Code, Ghostty, WezTerm, and kitty all converge on the same idea.
Rich terminal behavior increasingly depends on explicit shell integration, semantic prompt/input/output marking, and shell-reported state.
VS Code's shell integration docs expose command decorations and exit-aware navigation, while the VS Code API docs explicitly describe a `shellIntegrationNonce` that can make command-line reporting trusted instead of heuristic.
Ghostty says some of its best features require shell integration and can be auto-injected or manually sourced.
WezTerm documents `OSC 7`, `OSC 133`, and `OSC 1337` as its shell-integration basis.
kitty ties jumping to prompts, browsing last-command output, and click-to-move at the prompt to shell integration.

That is the right Schell clue:
**the shell should emit the truth, and the terminal should become luxurious on top of it.**

See:
- https://code.visualstudio.com/docs/terminal/shell-integration
- https://code.visualstudio.com/api/references/vscode-api
- https://ghostty.org/docs/features/shell-integration
- https://ghostty.org/docs/config/reference
- https://wezterm.org/shell-integration.html
- https://sw.kovidgoyal.net/kitty/shell-integration/
- https://sw.kovidgoyal.net/kitty/conf/

## 2) Great suggestions are rich, source-aware, and slot-bound

fish and PowerShell keep pushing the same humane direction.
fish says autosuggestions come from command history, completions, and valid file paths, and its completion UX carries descriptions instead of raw text fragments.
PowerShell's predictive IntelliSense distinguishes history-backed and plugin-backed prediction sources, and its dynamic help shows focused parameter help with `Alt+h` right below the command line.

That is a superb Schell clue.
Suggestions should be cards with value, description, and origin.
Help should bind to the exact slot in composition rather than tear the operator out of flow.

See:
- https://fishshell.com/docs/current/interactive.html
- https://fishshell.com/docs/current/tutorial.html
- https://learn.microsoft.com/en-us/powershell/scripting/learn/shell/using-predictors?view=powershell-7.6
- https://learn.microsoft.com/en-us/powershell/scripting/learn/shell/dynamic-help?view=powershell-7.5
- https://learn.microsoft.com/en-us/powershell/module/psreadline/about/about_psreadline_functions?view=powershell-7.5

## 3) Old completion stacks prove that "just suggestions" can execute code

Bash's programmable completion is the standing warning here.
Completion can invoke shell functions or commands when generating candidates.
That means completion is not inherently observational.
It can be a live execution surface hiding under a friendly UI.

So the Schell import should be:
- origin badges,
- dynamic-helper confession,
- slower helper lanes that remain weaker than execution,
- and a hard separation between suggestion generation and reviewed action spending.

See:
- https://www.gnu.org/s/bash/manual/html_node/Programmable-Completion.html
- https://www.gnu.org/s/bash/manual/html_node/Commands-For-Completion.html

## 4) Repo-local startup convenience wants explicit allow / re-allow, not ambient trust

direnv remains one of the clearest current signals here.
Its whole value proposition is per-directory environment behavior, but its own allow-list and re-authorization posture keep reminding us that repo-local startup is an authority surface, not harmless atmosphere.
The stdlib docs even describe `require_allowed` so changing certain files forces `direnv allow` again.

That is a very strong Schell clue.
Repo-local accelerators should arrive as visible packs with allow/re-allow posture, not as silent shell authorship that begins the moment a folder opens.

See:
- https://direnv.net/
- https://direnv.net/man/direnv.1.html
- https://direnv.net/man/direnv-stdlib.1.html

## 5) Recording, sharing, and auditing should stay different product shapes

The recording docs are unusually aligned.
asciinema says local recording does not upload by default and separates recording from upload.
Its FAQ also makes clear that input capture is a stronger, opt-in act.
Red Hat's tlog docs say recordings are JSON and that terminal input recording is disabled by default for security reasons.
The `script(1)` manual warns that `--log-in` and `--log-io` can capture sensitive input like passwords regardless of terminal echo state.

That gives Schell a very clean ladder:
- output-only cast,
- input-bearing cast,
- live share,
- audit record.

See:
- https://docs.asciinema.org/faq/
- https://docs.asciinema.org/getting-started/
- https://docs.redhat.com/en/documentation/red_hat_enterprise_linux/10/html/managing_idm_users_groups_hosts_and_access_control_rules/configuring-session-recording-by-using-cli
- https://man7.org/linux/man-pages/man1/script.1.html

## 6) Structure is a real advantage, but it should stay adjunct until earned

PowerShell and Nushell both make a compelling case for structured data.
PowerShell explicitly frames inputs and outputs as .NET objects.
Nushell explicitly centers structured data in pipelines instead of plain text.
That is valuable.
But it does **not** mean Schell should freeze a universal structured pipeline ontology in phase zero.

The better clue is narrower:
structure is great for sidecars, diagnostics, previews, effect summaries, and typed objects; it should not be allowed to silently erase transcript truth or over-decide the shell language before the interaction model is proven.

See:
- https://learn.microsoft.com/en-us/powershell/scripting/overview?view=powershell-7.6
- https://www.nushell.sh/book/
- https://www.nushell.sh/book/pipelines.html
- https://www.nushell.sh/book/navigating_structured_data.html

## 7) Plan 9 still has the cleanest answer to smart-click ambiguity

Plan 9's acme and plumbing docs are still strikingly modern.
acme exposes editable text windows and external-program control through files.
The plumber keeps routes explicit through rule files rather than pretending that every visible string has one obvious action.

That is a powerful Schell clue.
If visible text, paths, URLs, digests, receipts, and ports are going to become actionable, they should become **typed intent packets** with named route classes, not one generic click/open behavior.

See:
- https://9fans.github.io/plan9port/man/man1/acme.html
- https://9fans.github.io/plan9port/man/man7/plumb.html

## 8) Compact conclusion

Current official docs are converging on one very helpful answer.
The next no-regret import for Schell is not one giant shell constitution.
It is a **provenance-first luxury stack**:
- shell-emitted semantic zones,
- trust-graded visible regions,
- source-badged suggestions and slot help,
- repo-local accelerators with explicit allow/re-allow,
- recording ladders that distinguish capture strength,
- typed intent packets for clickable things,
- and structured sidecars that stay weaker than the plain text transcript.

That bundle looks ambitious enough to make the custom shell+terminal feel genuinely modern while still leaving the deepest decisions open.
