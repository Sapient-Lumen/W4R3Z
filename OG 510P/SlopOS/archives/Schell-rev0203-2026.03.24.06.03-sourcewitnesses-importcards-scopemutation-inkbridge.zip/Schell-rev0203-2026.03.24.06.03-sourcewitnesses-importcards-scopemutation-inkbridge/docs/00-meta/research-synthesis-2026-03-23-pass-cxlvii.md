# Research synthesis — 2026-03-23 — pass CXLVII

This pass sharpens a narrower lesson from current shell+terminal tools:
**the best modern comforts often operate on soft state rather than live truth, so the product needs explicit ladders for remembered, saved, restored, and provisional things instead of flattening them into one “smart terminal” feeling.**

That points to a good next Schell move:
**a soft-state ladder** rather than one more deep architecture commitment.

## 1) iTerm2 proves remembered state is valuable when it stays peer-shaped and obviously weaker than live action

Current iTerm2 shell-integration docs keep several useful distinctions visible.
Command history and recent directories are stored separately for each `username+hostname` combination.
The toolbelt can scroll to a past command, type it, or issue a `cd` based on the directory where it was last run.
And command or directory history can also be persisted across runs.

That is a strong Schell clue.
Remembered command state is already:
- scoped by peer,
- ranked by recency/frecency,
- and action-capable,

but it is still not present-tense truth.
It is **remembered soft state**.

See:
- https://iterm2.com/shell_integration.html

## 2) Atuin and zoxide prove ranked memory gets much better when the system can explain what it thinks it knows

Atuin keeps history much richer than a flat reverse-search surface.
Its config supports filter modes such as global, host, session, directory, and workspace.
It supports history and cwd exclusion filters.
And its sync flow keeps multi-machine history as an explicit end-to-end encrypted choice.

zoxide pushes the same lesson on directory memory.
Its frecency algorithm is simple enough to explain, it ages entries over time, and `zoxide query --list --score` can show why a result won.

That gives Schell two strong clues:
- remembered state should stay richly filterable and scoped,
- and ranking should be revealable instead of magical.

See:
- https://docs.atuin.sh/cli/configuration/config/
- https://docs.atuin.sh/cli/guide/sync/
- https://github.com/ajeetdsouza/zoxide/wiki/Algorithm
- https://man.archlinux.org/man/zoxide-query.1.en

## 3) Warp proves saved state should land in editable review surfaces before it becomes execution

Warp's docs now make two nearby ideas explicit.
Workflows are saved parameterized commands with names, descriptions, and arguments, but when you execute one, Warp pastes it into the active terminal input so you can adjust it before running.
Launch Configurations save windows, tabs, and panes so a project shape can be reopened quickly.

That is exactly the distinction Schell should preserve.
A saved workflow or launch configuration is not live truth.
It is **saved soft state**:
useful, structured, and ready to help — but still weaker than a fresh reviewed action.

See:
- https://docs.warp.dev/knowledge-and-collaboration/warp-drive/workflows
- https://docs.warp.dev/terminal/sessions/launch-configurations

## 4) Zellij proves restored state should confess itself and keep a rerun gate

Zellij's session-resurrection docs are especially valuable because they are unusually honest.
Zellij serializes the session layout and running commands, can optionally serialize viewport and scrollback, and then puts resurrected commands behind a visible “Press `ENTER` to run...” banner.
Layouts are also plain text files that can be re-applied or loaded from remote URLs.

That gives Schell a very clean clue.
A restored terminal is not fake or useless.
It is simply **restored soft state**.
It should remain useful for orientation, inspection, and selective replay while clearly refusing to masquerade as current liveness.

See:
- https://zellij.dev/documentation/session-resurrection.html
- https://zellij.dev/documentation/layouts.html

## 5) Mosh proves provisional comfort is a distinct luxury class, not a bug or a lie

Mosh still provides one of the clearest lessons about latency luxury.
It offers roaming, intelligent local echo, and local line editing.
Its docs explain that prediction happens in epochs and that the client only shows predictions once they are confirmed.
Prediction is therefore explicitly weaker than exact remote witness.

That is a brilliant Schell clue.
There is no need to ban latency-masking comfort.
The right move is to name it as **provisional soft state**.

See:
- https://mosh.org/

## 6) Compact conclusion

The current ecosystem keeps converging on one useful design answer.
Schell should distinguish at least four soft-state families:
- **remembered** — history, recent directories, ranked recall,
- **saved** — workflows, launch kits, reusable command artifacts,
- **restored** — resurrected sessions, revived layouts, recovered residue,
- **provisional** — predicted local echo, latency masks, speculative chrome.

Those families can all make the shell+terminal feel super awesome.
But each one is weaker than fresh live truth in a different way.
That means the right next move is not another constitution.
It is a compact **soft-state ladder** with explicit badges, explicit action gates, and explicit downgrade/upgrade rules.
