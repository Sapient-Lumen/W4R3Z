# SlopOS datacube evaluation, pass LXIX (2026-03-22)

This pass evaluates one new companion import:
**Schell should absolutely gain reviewed nondeterminism witnesses, seed-lane posture, and replay humility, but SlopOS pressure says ambient time/RNG access, entropy quality, deterministic/test providers, request keys, and current live handle state must stay separately admitted so randomness truth never collapses into host folklore.**

## 1) SlopOS already says time and entropy should not be ambient shell folklore

The companion archive is very sharp here.
`rfcs/0063-nondeterminism-capabilities-clock-and-entropy.md` and `nondet-posture-v0.md` say that when D-NONDET is enabled, post-init components do **not** get ambient time or RNG APIs.
Clock and entropy arrive through explicit handles, finer time is stronger authority, and deterministic/test providers are separately named.
That is a profound shell+terminal lesson.
Schell should not romanticize “the machine just has randomness” as a silent default any more than it should romanticize one universal current-time source.
A reviewed action should be able to say:
- fresh cryptographic randomness,
- seed-only posture,
- insecure/non-crypto seed posture,
- deterministic replay/test posture,
- or degraded compat reachability.

## 2) SlopOS treats entropy quality as authority, not as an implementation detail

The entropy descriptor and request surfaces sharpen another crucial lesson.
SlopOS distinguishes `seed`, `stream`, and `deterministic` entropy classes and says deterministic/test entropy must never satisfy crypto-randomness preconditions.
That is exactly the rule Schell should import.
A shell witness should not just say “randomness used”.
It should say what *kind* of randomness or seed lane was admitted and what claims the operator may or may not make about replay, secrecy, or crypto quality afterward.

## 3) Request keys and receipts stay weaker than current live entropy truth

`entropy-request-state-posture-v0.md` is especially useful because it refuses a flattering shortcut.
It says the stable request key is for dedupe/retry/review only and is **not** itself a live entropy handle or proof that a current portal-owned handle still exists.
Historical receipts and approval artifacts therefore cannot stand in for present live handle state.
That is perfect pressure for Schell.
The terminal can absolutely show review receipts, request lineage, and bounded historical entropy facts.
It should still refuse to let those surfaces impersonate current random-state authority.

## 4) SlopOS also refuses to let virtualization convenience become portable entropy truth

`microvm-entropy-surface-posture-v0.md` adds a very practical boundary.
It refuses a portable ambient guest-visible entropy-device contract under `ext.microvm` and keeps owner-local boot seeding implementation-local.
That matters for Schell because it means the shell+terminal should not assume one portable `/dev/hwrng` / `virtio-rng` / host-backed-RNG story any more than it should assume one portable mount tree or one portable network namespace.
A reviewed action should therefore have room for explicit nondeterminism posture without turning one runtime's convenience device into Schell canon.

## 5) The companion archive suggests at least five separate shell-side objects

Putting those surfaces together suggests a clean Schell family:
- **nondeterminism witness** — crypto-fresh / seed-only / insecure-seed / deterministic / compat / unknown,
- **seed-lane witness** — one-time seed material, bounded seed budget, or omitted,
- **replay witness** — exact capture required / deterministic replay provider / replay forbidden / unknown,
- **repro rail** — explicit deterministic env or tool-mode insertion that stays weaker than command truth,
- **entropy receipt** — bounded historical facts without raw seed bytes or present-live claims.

That split matters a great deal.
If Schell flattens these objects, it will recreate exactly the ambient nondeterminism problem SlopOS keeps refusing.

## 6) A compact v0 posture worth stealing

A good early Schell nondeterminism family should probably say:
- whether launch depends on fresh crypto randomness, seed-only posture, insecure hash/DoS seed posture, deterministic test/replay posture, or unknown compat reachability,
- whether replay is exact, capture-required, deterministic-by-provider, or unavailable,
- whether any reproducibility rail is explicit reviewed env insertion rather than hidden shell policy,
- and whether the historical receipt is shell-owned exact outcome truth or only a weaker provider-side addendum.

That would make nondeterminism much more humane without forcing one final RNG portal, replay substrate, seed broker, or microVM device contract.

## 7) Decision-light next move

A strong next move is to define one **nondeterminism witness / seed lane / replay humility** family that proves:
- reviewed randomness posture,
- explicit deterministic-versus-fresh separation,
- bounded receipts without raw seed leakage,
- and replay humility
can coexist without turning Schell into a fake universal RNG dashboard or a portability theater around `/dev/urandom`.

That keeps Schell ambitious while learning the right lesson from SlopOS:
**nondeterminism truth is welcome, but fresh randomness, deterministic providers, request keys, current live handles, and historical receipts must stay separately admitted.**
