# SlopOS datacube evaluation, pass CXXVIII (2026-03-22)

This pass evaluates one narrower question against the current companion archives:
**what do SlopOS, Steward, and ViewFS teach Schell about text shape, visual calm, and exact review?**

The answer is crisp:
**descriptive display should stay weaker than exact reviewed basis, and nearby selection/normalization folklore should not quietly widen a narrower contract.**

## 1) SlopOS keeps exact reviewed predicates smaller than nearby selection folklore

The companion archive repeatedly freezes this design move:
exact reviewed names stay smaller than nearby normalization, search-path, service-binding, address-selection, or session-selection behavior.
That is the right import for Schell.
A beautiful local render or a plausible display alias should remain helpful description, not exact command/object identity.

## 2) Steward keeps trusted chrome freshness-scoped and source-labeled

The adjacent lesson from Steward is that trusted chrome should confess source and freshness.
For text shape that means Schell should say whether a visual convenience is:
- current local rendering,
- committed buffer text,
- restored historical display,
- relay-affected projection,
- or exact review basis.

## 3) ViewFS keeps lanes separate

ViewFS keeps observation, control, and sideband flows from collapsing into one flattering lane.
Schell needs the same separation here:
- visible shape,
- composition posture,
- committed text,
- exact reveal,
- and reviewed action
should stay separately named.

## 4) Companion-compatible no-regret move

Schell does **not** need a full international text policy stack next.
It only needs a few bounded rules:

### A) Keep visible shape weaker than committed text
A calm-looking screen does not prove commit happened.

### B) Keep committed text weaker than exact review basis
A buffer update does not end ambiguity for bidi, confusables, or display aliases.

### C) Keep source and freshness visible
local render, relay projection, restored display, committed buffer, exact review.

### D) Keep stronger actions tied to stronger footing
help and hints may observe local shape; execution authority should rise only on stronger basis.

## 5) Compact conclusion

The companion-safe answer is not “trust the screen more.”
It is:
**build text-shape witnesses and strict-review toggles so Schell can feel multilingual and modern while still refusing to let visual calm impersonate exact committed or reviewed shell truth.**
