# Research synthesis, pass XVII (2026-03-21)

This pass focuses on another load-bearing seam:
**terminals and IDE-terminals keep getting better at progress, prompts, and completion cues, but Schell still needs a better answer than letting spinners, silent timeouts, or vanished panes masquerade as exact outcome truth.**

## 1) Current systems separate request lifetime, cancellation, and local notification more than old shell folklore admits

XDG’s Request interface is a good reminder.
A portal method returns a Request handle, the interaction ends with a `Response` signal, and the caller can abort the interaction by calling `Request.Close()`.
Success means the request is carried out, cancellation is a different outcome, and closing the request suppresses the normal response signal.
See: https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Request.html

That is very close to what Schell needs.
A shell+terminal should keep one exact running/request scope, one exact cancel path, and one exact completion/denial/handoff witness instead of burying everything inside “still spinning / done / maybe timed out” UI folklore.

## 2) Current terminal UX is converging on humane completion cues, but those cues are still not receipts

Ghostty 1.2 added GUI progress-bar support using progress sequences and explicitly describes future expansion of progress presentation into more places.
Ghostty 1.3 adds command-finished notifications and prompt-click affordances, both powered by shell integration.
See: https://ghostty.org/docs/install/release-notes/1-2-0 and https://ghostty.org/docs/install/release-notes/1-3-0

iTerm2 has long had “Alert on next mark,” which waits for the next shell-integration mark and then alerts when the command prompt returns.
See: https://iterm2.com/documentation-shell-integration.html

The design lesson is not “copy every badge.”
It is: completion cues are wonderful, but they are **attention surfaces**, not by themselves a proof that the underlying request or workflow reached a clean, exact outcome.

## 3) IDE-terminals are also moving toward explicit progress and current-task awareness

VS Code tasks process output through problem matchers, and task tabs can show task status.
More recent updates add task/terminal output polling, explicit “continue waiting or move on” prompts for long-running commands, and progress UIs that surface prompts and task-specific problems.
See: https://code.visualstudio.com/docs/debugtest/tasks , https://code.visualstudio.com/updates/v1_57 , and https://code.visualstudio.com/updates/v1_103

This is a good hint for Schell.
“Still running,” “waiting for user input,” and “completed with problems” want distinct, exact surfaces.
The best current tools do not just show output; they also bind progress UI to the current task identity.

## 4) Shell integration keeps paying off here too

Ghostty’s shell integration page makes the general rule explicit: several desirable features depend on integrating with the shell.
WezTerm’s shell integration and OSC 133 support likewise make command/prompt/output boundaries explicit, and `SemanticZone` selection builds on those zones.
See: https://ghostty.org/docs/features/shell-integration and https://wezterm.org/changelog.html

This keeps reinforcing the same core posture for Schell:
progress and completion should attach to shell-known work units, not to guessed scrollback regions or renderer-local activity heuristics.

## 5) Plan 9 still teaches a useful routing lesson even here

The plumber receives, rewrites, and dispatches messages between programs through explicit send/rules/output ports.
See: https://9fans.github.io/plan9port/man/man4/plumber.html

For Schell, the relevant lesson is that **cancel**, **handoff**, **attach**, **bring-forward**, and **forget-local-wait** are better as named routed moves than as one generic red stop button glued to whatever looks active.

## 6) A no-regret Schell cluster is visible now

A decision-light first cluster looks like this:
- one shell-owned **progress scope** object,
- one small state family (`running`, `waiting-input`, `draining`, `cancel-requested`, `cancelled`, `deadline-exceeded`, `completed`, `completed-with-problems`, `unknown-after-disconnect`),
- one compact cancel-offer ladder,
- one rule that finish/progress UI lands on exact receipts, denials, hold cards, or problem witnesses,
- and one transcript-visible transition family rather than a giant animation log.

## 7) The best steals are the humane ones

The best ideas to steal now are:
- threshold-based finish notices,
- progress chips that bind to exact work scopes,
- explicit “continue waiting or move on” choices,
- problem-count surfaces tied to exact current work,
- drain cards after cancel so cleanup is not mistaken for completion,
- and readonly outcome landings that preserve the result without claiming the work is still live.

## 8) What to refuse

The moves to refuse are just as important:
- do not let a local spinner or progress bar become the durable truth of job state,
- do not collapse interactive interrupt, cooperative cancel, hard terminate, and “stop watching” into one action,
- do not treat notification delivery as proof the operator saw the event,
- do not let local tab/pane disappearance certify that work ended cleanly,
- and do not freeze a full scheduler, job engine, or diagnostic ontology before a small specimen set exists.
