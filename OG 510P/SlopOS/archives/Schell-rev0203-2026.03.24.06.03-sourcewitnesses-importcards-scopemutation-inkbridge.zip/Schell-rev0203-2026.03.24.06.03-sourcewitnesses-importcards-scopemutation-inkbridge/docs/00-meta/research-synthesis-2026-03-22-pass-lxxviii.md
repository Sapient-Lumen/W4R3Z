# Research synthesis, pass LXXVIII (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should steal repeatable dev-environment metadata, remote thin-client comfort, isolated shells, and explicit environment summaries from the modern toolchain — but it should keep machine identity, tool-stack identity, user overlays, and lifecycle hooks separate so “same dev environment” never impersonates “same host, same user, same startup effects, or same runtime footing.”**

This seam matters because the current ecosystem now offers several adjacent but non-identical promises:
- repeatable dev environments described in project metadata,
- containers or remote hosts that feel almost local,
- project-local shells and package sets,
- dotfile or settings personalization on top of project configs,
- and lifecycle hooks that run on the host, in the container, or at prompt-time.

All of those are useful.
They also create one recurring trust failure:
operators start hearing “same environment” when the system really means “similar tool list plus whatever host, user, overlays, and hooks happened to participate.”
The no-regret move is not to avoid environment tooling.
It is to give those layers a much more explicit truth surface.

## 1) Dev Containers prove the value of metadata-defined environments, but they also prove that lifecycle and locality matter

The Development Container Specification says a development container is defined by metadata that should be easy to use, create, and recreate, and that one environment may include one or more containers plus sidecars.
The `devcontainer.json` reference then makes the hidden complexity plain:
- `initializeCommand` runs on the host and may run more than once,
- `containerEnv` is container-wide and static for the life of the container,
- `remoteEnv` is tool-side or terminal-side rather than whole-container truth,
- features can add more installation-time behavior,
- and host requirements can shape which machine class the environment actually lands on.
That is a powerful import for Schell.
A “project environment” is not one thing.
At minimum it has:
- one **spec layer**,
- one **host layer**,
- one **runtime layer**,
- one **tool-side overlay layer**,
- and one **lifecycle-hook layer**.
See: https://containers.dev/implementors/spec/ and https://containers.dev/implementors/json_reference/

## 2) VS Code Dev Containers show how fast tool comfort widens beyond the project spec

Current VS Code docs say workspace files may be bind-mounted from the local filesystem or copied/cloned into the container, extensions run inside the container with full access there, local user settings are reused, container-specific remote settings can diverge, dotfile repositories can personalize the environment, remote Docker hosts imply trusting the machine the daemon runs on, and ports can be forwarded for the session.
That is not a warning against Dev Containers.
It is a warning against flattening them.
The same `devcontainer.json` can sit above:
- a bind-mounted local workspace,
- a copied remote workspace,
- a remote Docker daemon,
- imported user settings,
- dotfile overlays,
- and forwarded localhost illusions.
Schell should therefore show **machine card truth** next to **environment passport truth**, not assume one replaces the other.
See: https://code.visualstudio.com/docs/devcontainers/containers

## 3) Codespaces and JetBrains Remote show why machine identity and tool-stack identity must stay separate

Current GitHub Codespaces docs say a codespace is a cloud-hosted development environment, each codespace runs in a Docker container on a VM, the environment is Linux regardless of the local OS, machine types vary, and users have limited access to the outer VM host.
Current JetBrains Remote docs say remote development can target a remote machine, development container, WSL, or other providers while the local machine acts as a thin client and the remote host runs the backend.
Those are excellent product moves.
They also prove that “my environment” might mean:
- a local laptop shell,
- a Linux container in the cloud,
- a remote IDE backend on another machine,
- or a project container inside that remote host.
So Schell should keep **host class**, **runtime class**, **project spec**, and **attachment mode** separately named.
See: https://docs.github.com/en/codespaces/about-codespaces/what-are-codespaces and https://www.jetbrains.com/help/idea/remote-development-overview.html

## 4) Nix, Devbox, devenv, and direnv prove that project shells are worth stealing — but not as vague sameness

Current Nix docs say `nix develop` starts a bash shell that provides an interactive build environment nearly identical to what Nix would use to build an installable, and the interface remains experimental.
Current Devbox docs say Devbox creates isolated, reproducible shells from `devbox.json`, recursively searches current and parent directories when starting `devbox shell`, and has a `--pure` mode that still retains a few variables such as `HOME`, `USER`, and `DISPLAY`.
Current devenv docs say `devenv shell` activates the environment, `devenv update` pins inputs into `devenv.lock`, `enterShell` runs bash code on activation, tasks are often preferable for complex setup, and `devenv info` can print an environment summary.
Current direnv docs say it hooks into the shell, checks `.envrc` before each prompt, and loads authorized bash code in a subshell before exporting variables back into the current shell.
That is gold for Schell.
The shell should absolutely steal:
- repeatable project environments,
- lock-aware summaries,
- cheap environment inspection,
- and project-local activation.
But it should refuse to flatten:
- recorded spec,
- discovered config via parent search,
- prompt-time activation,
- activation-time bash hooks,
- residual inherited variables,
- and runtime summaries
into one flattering “same shell everywhere” badge.
See: https://nix.dev/manual/nix/2.26/command-ref/new-cli/nix3-develop ; https://www.jetify.com/docs/devbox ; https://www.jetify.com/docs/devbox/cli-reference/devbox-shell ; https://devenv.sh/getting-started/ ; https://devenv.sh/basics/ ; and https://direnv.net/

## 5) The strongest super-awesome moves are clearer now

The highest-value moves worth stealing from this seam are:
1. **machine cards** with host class, runtime class, attachment mode, trust posture, and resource shape,
2. **environment passports** describing the project environment spec, lock refs, activation family, hook families, and overlay contributors,
3. **host-drift badges** so “same stack, different machine” is visible instead of surprising,
4. **overlay ladders** separating project spec, user dotfiles/settings, session overrides, and discovered parent-directory activators,
5. **hook provenance cards** showing whether code ran on the host, in the runtime, at prompt-time, or once at activation,
6. **compare-ground rungs** that can say same spec / same lock / same runtime kind / same host class / same exact machine / unknown,
7. **one-shot import-to-native cards** for bringing useful environment summaries into Schell without turning external tool behavior into native truth,
8. **thin-client honesty** so remote IDE or browser comfort never hides where code, secrets, extensions, and processes actually run,
9. and **forwarded-localhost badges** whenever remote or containerized work is being made to feel local through forwarding.

## 6) What Schell should absolutely refuse

Schell should refuse:
- one generic “same environment” badge that conflates project metadata, machine class, user overlays, and runtime reality,
- treating host-side lifecycle hooks as if they were the same thing as runtime-local activation,
- treating user dotfiles/settings as if they were project-owned environment truth,
- treating project-local shell sameness as proof of filesystem, privilege, performance, or secret posture sameness,
- and treating forwarded localhost or remote thin-client comfort as proof that the work is local.

## 7) Decisions intentionally kept open

This pass does **not** freeze:
- one final project-environment schema for Schell,
- one final dev-container / codespace / remote-host import protocol,
- one final host fingerprint or machine-identity model,
- one final lockfile / package-manager abstraction across ecosystems,
- one final hook or task execution model,
- or one final comparison lattice for portability claims.

The no-regret move is smaller:
**give Schell machine cards, environment passports, host-drift badges, overlay ladders, and hook provenance so portable comfort can improve without letting environment folklore overclaim sameness.**
