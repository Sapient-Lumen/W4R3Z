# Research synthesis, pass LXV (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should absolutely steal explicit network modes, resolver/proxy posture, and bounded egress receipts — but only if “no network”, private namespace, joined namespace, host/shared network, proxy source, and destination authority stay separately named instead of collapsing into one flattering “the shell knows the internet” story.**

This seam matters because old shells still treat networking as oddly ambient.
A command often inherits the host stack, host DNS, host proxy variables, host loopback reachability, and sometimes a prearranged namespace or container network without the operator seeing any of it in the command review surface.
When something fails, or worse, succeeds too broadly, the operator is left diffing `curl`, container flags, `resolv.conf`, proxy env, and service-manager state after the fact.
That is exactly the kind of shell+terminal seam Schell can improve without choosing one final sandbox, container, portal, or policy engine.

## 1) `systemd.exec` and socket activation prove network mode should be explicit and separately named

The current `systemd.exec(5)` docs make a crucial distinction visible.
`PrivateNetwork=` creates a new network namespace with only the loopback device `lo`, disconnects socket families from the host, and may be replaced by `NetworkNamespacePath=` when the unit should join a specific namespace.
The current `systemd.socket(5)` docs add a powerful second lesson: it is considered good practice to run a service in its own network namespace while receiving only the activation sockets passed in from the host namespace.
That is an excellent Schell clue.
A reviewed launch surface should not flatten “no network”, “private loopback-only network”, “join this existing namespace”, and “receive only these pre-opened sockets” into one tiny badge.
See: https://manpages.debian.org/unstable/systemd/systemd.exec.5.en.html and https://manpages.debian.org/unstable/systemd/systemd.socket.5.en.html

## 2) Bubblewrap and Flatpak prove “network on/off” is real capability posture, not trivia

The current `bwrap(1)` docs say `--unshare-net` creates a new network namespace and `--share-net` retains the network namespace instead of the isolated one.
Flatpak's current sandbox docs say apps have no network access by default, and that portals are used for access to resources outside the sandbox, including opening URIs and getting network status information.
That is an important design hint for Schell.
The shell+terminal should treat network posture as something the operator can review — none, host/shared, private, joined, or portal-mediated — rather than invisible substrate trivia.
See: https://manpages.debian.org/unstable/bubblewrap/bwrap.1.en.html and https://docs.flatpak.org/en/latest/sandbox-permissions.html

## 3) Docker and Podman prove named network modes are worth stealing

Current container docs reinforce the same lesson in a more operator-facing way.
Docker's `none` network driver says `--network none` completely isolates the container's networking stack and creates only the loopback device.
Podman's current `podman run` docs expose a whole mode vocabulary: `none`, `host`, `bridge`, `private`, `container:id`, and `ns:path`, with security notes for `host` and with explicit rootless stack options such as `slirp4netns`.
Schell should absolutely steal the *named-mode review surface* from that world, but not the idea that one container runtime's mode list is the final universal ontology.
See: https://docs.docker.com/engine/network/drivers/none/ and https://docs.podman.io/en/latest/markdown/podman-run.1.html

## 4) `curl` proves proxy and protocol posture often comes from hidden ambient state unless the command reveals it

The current curl docs are especially revealing.
libcurl documents that `NO_PROXY` affects proxy bypass unless an explicit option overrides it.
The curl tool docs say `--proxy` overrides environment variables that set the proxy, `--noproxy` overrides environment variables that disable the proxy, and `--proto` / `--proto-redir` constrain which protocols are allowed — with the docs explicitly warning that enabling all redirect protocols is not good for security.
That is a very strong Schell clue.
A shell+terminal should let the operator see whether proxy posture and protocol posture come from explicit flags, inherited environment, or a reviewed workflow default.
See: https://curl.se/libcurl/c/libcurl-env.html and https://curl.se/docs/manpage.html

## 5) The dangerous flattenings to refuse

The current ecosystem keeps inviting at least seven mistakes:
- treating host/shared networking as an unremarkable baseline,
- treating joined namespace and private namespace as the same thing,
- treating loopback-only isolation as equivalent to “no egress risk” when passed-in sockets may still exist,
- treating proxy env and DNS config as harmless presentation details,
- treating hostname strings in argv as if they already proved destination authority,
- treating current network status or prior egress logs as proof of present authority,
- and treating one runtime's network mode vocabulary as Schell's final portable grammar.

Schell should refuse those moves.
A command should be able to say, separately:
- what network mode it is entering,
- what resolver basis it will use,
- what proxy source is active,
- whether destination authority is explicit or ambient,
- whether pre-opened sockets exist,
- and what exact bounded egress receipt can honestly be emitted afterward.

## 6) The stealable move: network witnesses, resolver badges, and egress humility

The best decision-light move now looks like this:
1. add a **network witness** family for reviewed launch posture,
2. keep **resolver posture** separate from network-mode posture,
3. keep **proxy source** separate from both,
4. distinguish **no network**, **private loopback-only**, **joined namespace**, **shared/host**, and **leased/portal** postures,
5. distinguish **destination request text** from **reviewed destination authority**,
6. distinguish **live network status** from **historical egress receipts**,
7. let richer socket/connection inspectors be optional and capability-witnessed,
8. and refuse to standardize one giant cross-platform network sandbox grammar too early.

That would make Schell feel dramatically more capable while preserving the archive's current decision throttle.

## 7) A compact first proving slice

A compact proof could show:
- one reviewed launch card with explicit network mode badge,
- one resolver witness saying none / portal / host-file / explicit override / unknown,
- one proxy witness saying flag / env / workflow default / none,
- one destination card that distinguishes typed text from reviewed authority,
- one private-namespace command receiving only an explicit passed-in socket or explicit open handle,
- one historical egress receipt with redaction-safe destination/proto/scope facts,
- one refusal to infer safe protocol posture when the command omits `--proto` / equivalent constraints,
- and one refusal to treat a stale status deck as current network authority proof.

That is enough to make Schell feel super awesome at network truth without freezing the final network-control substrate.

## 8) Decisions intentionally kept open

This pass does **not** freeze:
- one universal network-sandbox API,
- one portable resolver schema for every host/runtime,
- one final proxy-configuration contract,
- one final egress-receipt schema for all transports,
- one container/runtime/service-manager substrate,
- or one universal live socket/connection inspector.

The no-regret move is smaller:
**steal reviewed network modes, resolver/proxy posture, and bounded egress receipts — but keep network mode, resolver basis, proxy source, passed-in socket authority, and historical egress evidence visibly separate.**
