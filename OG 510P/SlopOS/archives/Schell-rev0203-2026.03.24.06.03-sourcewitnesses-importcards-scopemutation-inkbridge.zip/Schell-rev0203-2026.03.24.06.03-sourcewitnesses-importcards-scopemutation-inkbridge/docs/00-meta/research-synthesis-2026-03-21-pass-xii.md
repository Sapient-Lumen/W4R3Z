# Research synthesis — 2026-03-21 pass XII

This pass keeps one design rule in view:
**outside-world ingress should enter Schell as typed ingress packets with trust grades and bounded action families, not as ambient text that silently inherits execution authority.**

The strongest outside convergence here is subtle but real.
Current shells and terminals are getting better when they do three things at once:

- treat paste as a special, bounded kind of input rather than ordinary keystrokes,
- preserve richer clipboard and file-transfer structure when it exists,
- and keep “helpful insert/open/import” separate from “go run this now.”

## Strongest current outside pressure

### 1) Bracketed paste is the baseline honesty move

GNU Readline's bracketed-paste mode inserts a paste as a single string in the editing buffer and prevents pasted key sequences from firing editing commands.
VS Code then layers its own operator guidance on top: it warns on multi-line paste when the shell does **not** support bracketed paste, and it uses bracketed paste for Run Selected Text and multi-line recent commands so they land as one input instead of a string of accidental separate commands.

That is exactly the kind of “super awesome but still humble” behavior Schell should steal.
The terminal should know when the active input lane can safely accept a multi-line ingress packet as one edit, and when it should stop and ask for a safer route.

### 2) Clipboard payloads are richer than plain text

kitty's clipboard docs show a more ambitious but still disciplined direction: a TUI can enable paste-events mode and receive a list of available clipboard MIME types when the user pastes, then request only the desired payload using a one-time password.
That is a big clue for Schell.
A powerful terminal does not have to flatten every paste into plain text up front.

This does **not** mean Schell should freeze a full clipboard protocol now.
It does mean Schell should keep the ingress model open enough to represent text, rich text, file-transfer payloads, and other typed clipboard content explicitly.

### 3) Drag/drop and clipboard need security humility

Ghostty 1.3.0 fixed a pasted/drag-and-dropped control-character issue that could lead to arbitrary command execution in some shell environments.
That is a sharp reminder that ingress behavior is not just polish.
It is a real safety boundary.

A great custom shell+terminal should therefore make control characters, hidden structure, and suspicious packet transforms visible instead of burying them inside “just paste it.”

### 4) File transfer is its own seam, not just text with slashes

The XDG File Transfer portal treats drag/drop and copy-paste file exchange as a dedicated inter-app bridge and uses the document portal as the controlled handoff path.
The document portal in turn keeps outside-world files in a controlled store with explicit persistence and permissions.
That matches the SlopOS lesson almost perfectly.

So one of Schell's best steals is simple:
**when a drop or clipboard event is file-bearing, prefer an import/docref/open-untrusted style action family over raw path injection into the shell.**

### 5) Rich clipboard copy is useful, but egress must not become source-of-truth drift

Ghostty now writes both `text/plain` and `text/html` when copying terminal content.
That is a nice reminder that rich clipboard egress can be delightful.
But Schell should still preserve plain-text transcript truth as the canonical public surface.
Rich copy can be an extra, not the truth source.

## Best ideas worth stealing now

### Ingress packets, not ambient bytes

Schell should have a first-class ingress object for:

- clipboard paste,
- drag/drop,
- file-transfer paste,
- explicit import from another lane,
- and maybe later agent-proposed inserts.

A good packet should keep at least:

- source kind,
- MIME summary,
- newline count / size hints,
- control-character or hidden-structure hints,
- authorship/provenance when known,
- and the safe action families currently allowed.

### Multi-line paste hold cards

When the active input lane is not bracketed-paste-safe, Schell should stop pretending that “paste” is harmless.
A hold card can explain the problem and offer bounded next steps:

- insert as one quoted literal,
- stage in scratch,
- inspect hidden characters,
- or open a review card instead of sending it straight through.

### Dropped-file import cards

Dropped files should usually become an import card, not raw text.
The card can offer:

- import as fresh local object,
- open untrusted,
- quote path into the active input lane,
- or seed a workflow with the imported object.

That is a direct steal from document-portal-style thinking, translated into terminal UX.

### A tiny ingress strip

A compact strip for the current packet could be unusually high leverage.
Imagine:

- `clipboard:text 14 lines · bracketed-paste safe`,
- `drop:file-list 2 items · fresh import suggested`,
- `clipboard:html + text/plain · open/inspect before insert`,
- `clipboard:text contains control chars · inspect recommended`.

That tells the truth without forcing a giant MIME dashboard.

### Transcript-safe ingress witnesses

One of Schell's nicest possible moves is to make ingress visible in plain logs too.
Something like “ingress packet: clipboard text, 6 lines, inserted as one bracketed paste” or “drop packet: 2 files, imported as fresh docrefs, quarantine retained” keeps the archive honest even when the fancy terminal is gone.

## Moves that make the custom shell+terminal super awesome

### 1) Make paste feel trustworthy, not merely fast

A shell that visibly understands multi-line paste, suspicious bytes, and quoted-vs-literal insertion will feel much better than terminals that hope for the best.

### 2) Make dropped files first-class citizens

Turning drops into import cards or docrefs instead of dumb path strings is exactly the kind of move that could make Schell feel like a new class of shell+terminal rather than a prettier old one.

### 3) Keep rich clipboard support without making it architecture law

Typed clipboard ingress is worth stealing aggressively, but the first cut can stay tiny: packet summary, one safe insert path, one import path, one inspect path.

### 4) Preserve plain-text truth

The rich local UX should be optional luxury.
The transcript still needs to say what got in, what transformations were applied, and what did **not** become authority.

## Current prototype reading

The next no-regret slice now looks like this:

1. **one ingress-packet family,**
2. **one bracketed-paste-aware insert path,**
3. **one multi-line/no-bracketed-paste hold card,**
4. **one dropped-file import card,**
5. **and one transcript witness for ingress handling.**

That leaves clipboard protocol choice, drag/drop plumbing, file-transfer backend, MIME taxonomy, and cross-process packet routing open.
That is exactly where Schell should stay.

## Reference pressure

- https://code.visualstudio.com/docs/terminal/basics
- https://code.visualstudio.com/updates/v1_75
- https://code.visualstudio.com/updates/v1_70
- https://tiswww.case.edu/php/chet/readline/readline.html
- https://sw.kovidgoyal.net/kitty/clipboard/
- https://ghostty.org/docs/install/release-notes/1-3-0
- https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Clipboard.html
- https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.FileTransfer.html
- https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Documents.html
- https://iterm2.com/documentation-one-page.html
- https://wezterm.org/changelog.html
