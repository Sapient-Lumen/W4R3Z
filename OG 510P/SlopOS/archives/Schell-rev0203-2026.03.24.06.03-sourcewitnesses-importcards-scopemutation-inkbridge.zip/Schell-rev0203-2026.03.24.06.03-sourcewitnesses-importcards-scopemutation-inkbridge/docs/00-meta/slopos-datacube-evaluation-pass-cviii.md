# SlopOS datacube evaluation, pass CVIII (2026-03-22)

This pass evaluates one narrower question against the current SlopOS archive:
**what does the companion already teach Schell about interrupts, suspends, hangups, shell exit, disown/nohup folklore, durable promotion, and the danger of treating raw signal behavior as portable shell truth?**

The answer is strong and surprisingly consistent:
**the companion wants cancellation, teardown, terminal/job control, signal-state baseline, and durable continuation to stay on explicit named seams instead of collapsing into one ambient signal-control myth.**

## 1) Capshell already rejects a portable signal-control plane

`capshell-interrupt-cancel-posture-v0.md` is the clearest direct lesson.
It freezes the Phase 1 answer that `capshell.exec` cancellation should bind to explicit request/workflow seams rather than a portable signal-injection or shell-owned process-control plane.
Local UX may map `Ctrl-C` or similar gestures into that seam, but portable meaning stays at the request/workflow level.

That is excellent pressure on Schell.
It means Schell should absolutely preserve local stop comfort, but it should not force raw host signal names or jobspec folklore to become the durable operator contract.

## 2) The companion keeps PTY/job control and signal-state inheritance explicitly small

`capshell-job-control-posture-v0.md` refuses a portable PTY/controlling-terminal/job-control plane.
`capshell-signalstate-posture-v0.md` then refuses ambient inherited signal-mask and trap state at launch.
Taken together, these say something very useful for Schell:
- the shell+terminal may still have rich local interruption UX,
- but it should not smuggle ambient parent/session signal folklore into reviewed execution truth,
- and it should not let terminal/session ownership quietly become a second authority plane.

That strongly supports a witnessed stop ladder rather than a hidden signal plane.

## 3) The companion already has the right durability split

The archive keeps durable/background continuation on explicit seams like jobs, background leases, quiesce, and attention/portal boundaries.
It also keeps durable interrupt semantics out of plain notification payloads.
That is exactly the companion guidance Schell needs for the old shell tangle around `&`, `disown`, `nohup`, `setsid`, terminal exit, and “keep running somehow”.

Applied to Schell, the companion-compatible move is:
- keep **interrupt**, **suspend**, **terminate**, and **hangup sever** as local stop/control witnesses,
- keep **detach** and **promote durable** as separate continuity moves,
- and keep durable status on explicit result/task/shelf surfaces instead of terminal folklore.

## 4) The companion rewards exact teardown wording

SlopOS repeatedly distinguishes requester intent, provider-owned live state, and exact teardown/continuation export.
That pressure maps beautifully onto shell interruption.
A shell should not overclaim that:
- interrupt means terminated,
- shell exit means hangup reached everything,
- disown means durable supervision,
- or detach means the same live authority still holds.

So the companion-compatible wording for Schell is smaller and better:
- interrupt requested,
- suspend acknowledged,
- foreground claim relinquished,
- hangup severed,
- shell tracking dropped,
- durable owner acquired,
- live state unknown after sever.

## 5) The companion-compatible answer is smaller than a final process model

Schell does **not** need to choose:
- one final signal backend,
- one final process supervisor,
- one final mux/detach story,
- one final remote stop translation model,
- or one final exit-code taxonomy

to stay aligned with SlopOS.

It only needs a few bounded rules:

### A) Stop requests keep target and delivery posture visible
Do not let keyboard-generated terminal signals, shell-owned cancel gestures, supervisor terminate actions, and historical residue all wear the same badge.

### B) Hangup/sever stays weaker than durable promotion
Ignoring hangup or dropping shell tracking is not yet durable ownership.

### C) Durable continuation gets its own move
Detached workspace continuity and promoted supervised continuity should be separately named.

### D) Result truth stays elsewhere
A stop cue or exit warning is not the durable result by itself; exact command/task receipts still matter.

### E) Ambient signal/session state stays out of reviewed execution truth
Do not let parent shell traps, ignored-signal posture, or controlling-terminal folklore silently leak into what Schell claims the operator reviewed.

## 6) Compact conclusion

The SlopOS-compatible answer is not “build a giant signal-control shell.”
It is:
**make interrupt, suspend, hangup sever, terminate, force kill, detach, and durable promotion separately named witnesses, while keeping raw host signal details and portable workflow semantics cleanly separated.**

That is a strong design-phase-safe move because it improves one of the oldest shell failure surfaces right away while leaving the final signal backend, process model, mux/detach story, and supervisor treaty open.
