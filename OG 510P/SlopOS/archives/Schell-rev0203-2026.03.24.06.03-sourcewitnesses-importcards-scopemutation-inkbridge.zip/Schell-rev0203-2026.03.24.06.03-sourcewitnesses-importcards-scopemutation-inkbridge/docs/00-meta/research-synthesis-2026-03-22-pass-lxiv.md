# Research synthesis, pass LXIV (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should absolutely steal resource envelopes, explicit cost/budget posture, and rich execution receipts — but only if launch limits, payer identity, live monitoring, and final accounting stay separately named instead of collapsing into one flattering “the shell knows the cost” story.**

This seam matters because resource truth is where old shells are still oddly primitive.
Operators can easily end up running inside a login shell with inherited `nice`, inherited `ulimit`, inherited cgroup placement, inherited service-manager quotas, or a hidden Windows Job Object and barely notice until the command behaves strangely.
Then, after the fact, resource accounting gets scattered across `time`, `top`, `systemd-cgtop`, job schedulers, logs, and partial postmortems.
That is exactly the kind of shell+terminal seam Schell can make materially better without choosing one final scheduler, one final quota API, or one final execution substrate.

## 1) `systemd-run` proves transient resource envelopes are useful, but service/scope distinction and runtime receipts matter

The current `systemd-run(1)` docs are especially instructive.
They say a transient **service** runs in a clean and detached execution environment with the service manager as parent, while a transient **scope** executes with `systemd-run` as parent and inherits the caller's execution environment.
They also say `--property=` can set unit properties, `--property=Type=exec` ensures success is reported only if the command line actually starts, and `--wait` prints terse runtime information including CPU, memory, IO, and IP accounting data when the corresponding cgroup accounting settings are enabled.
That is a great Schell clue.
A shell+terminal should not flatten “run in a managed envelope,” “inherit current shell context,” and “show me the final accounting receipt” into one tiny toggle.
See: https://manpages.debian.org/unstable/systemd/systemd-run.1.en.html

## 2) cgroup v2 proves envelope inheritance is real, hierarchical, and easy to misunderstand

The Linux cgroup v2 docs remain a load-bearing lesson.
They say every process belongs to one and only one cgroup, controllers are hierarchical, and restrictions set higher in the tree cannot be overridden further down.
They also make the concrete resource knobs visible: `cpu.max` for bandwidth limits, `memory.max` for hard memory limits, `io.max` for per-device BPS/IOPS limits, and `pids.max` for a hard process-count ceiling.
That is exactly the kind of host truth a modern shell should help operators *see* without pretending it has invented a universal portable scheduler language.
The design lesson is not “standardize every controller.”
It is “resource-envelope posture is real enough that hidden inheritance is a bug, and exact current/default envelope truth should be inspectable before the command runs.”
See: https://docs.kernel.org/admin-guide/cgroup-v2.html

## 3) `time` proves measurement and execution meaning are separate lanes

The current Bash manual and GNU `time(1)` docs sharpen a subtle but important point.
Bash's reserved word `time` can time shell builtins, shell functions, and pipelines in ways an external command cannot, while GNU `/usr/bin/time` can report much richer resource data such as max RSS, filesystem I/O, page faults, context switches, socket messages, and exit status.
That means there is no single “timing truth” lane even on one host.
Schell should steal the good part: separate a minimal shell-owned execution receipt from richer optional accounting receipts, and make it obvious which one the operator is currently looking at.
See: https://www.gnu.org/software/bash/manual/bash.html and https://man7.org/linux/man-pages/man1/time.1.html

## 4) Slurm proves live versus historical accounting and allocation versus step are different objects

Current Slurm docs reinforce another high-value split.
`sacct` reports historical accounting data for jobs and job steps, while `sstat` reports status information for running jobs and exposes fields such as `AllocTRES`, `AveCPU`, `AveRSS`, and `MaxRSS`.
The docs are very clear that job records include a primary job entry *and* step entries, and that some fields are generated from `wait3()` / `getrusage()` and may be zero on systems that do not provide them fully.
This is a beautiful Schell lesson.
A “resource receipt” should not pretend to be the same thing as a live deck, and a chapter-level outcome should not quietly flatten process-, step-, and allocation-level accounting into one number.
See: https://slurm.schedmd.com/sacct.html and https://slurm.schedmd.com/sstat.html

## 5) Windows Job Objects prove grouped limits, grouped accounting, and notifications are distinct stories

Microsoft's current Job Objects docs are equally useful.
They say a job object manages a *group* of processes as a unit, can enforce limits such as working set size, process priority, and end-of-job time, can emit notifications via an I/O completion port, and records basic accounting information retrievable with `QueryInformationJobObject`.
The docs also note that some attempts to raise working set size or process priority beyond the job limit succeed but are silently ignored, and that nested jobs influence the effective limits.
That is a sharp warning for Schell: resource posture should not be modelled as “per-process flags” when the real execution subject may be a grouped envelope, and soft-ish/ignored/notification-only outcomes must stay visibly different from hard deny or kill semantics.
See: https://learn.microsoft.com/en-us/windows/win32/procthread/job-objects and https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-jobobject_extended_limit_information

## 6) The dangerous flattenings to refuse

The current ecosystem keeps inviting at least six mistakes:
- treating inherited host/session resource state as invisible background trivia,
- treating “current process tree membership” as the same thing as reviewed payer or budget identity,
- treating live resource monitors as if they were the final receipt,
- treating final receipts as if they proved current liveness or current limits,
- treating one platform's limit vocabulary as Schell's universal portable resource grammar,
- and treating partial accounting availability as a minor rendering detail instead of a claim-strength issue.

Schell should refuse those moves.
A command should be able to say, separately:
- what launch envelope it is entering,
- who pays (if anyone explicit does),
- what limits are definitely in force,
- what limits are provider-local or unknown,
- what live monitoring is available,
- and what final receipt can honestly be emitted afterward.

## 7) The stealable move: resource witnesses, budget envelopes, and receipt humility

The best decision-light move now looks like this:
1. add a **resource witness** family for reviewed launch posture,
2. keep **budget/payer** posture separate from execution subject,
3. distinguish **default compartment envelope** from **extra transient override**,
4. distinguish **limit in force** from **accounting enabled**,
5. distinguish **live usage deck** from **final usage receipt**,
6. distinguish **limit-hit / pressure events** from **terminal outcome**,
7. let richer accounting be optional and capability-witnessed,
8. and refuse to standardize one giant cross-platform scheduler or quota grammar too early.

That would make Schell feel dramatically more capable while preserving the archive's current decision throttle.

## 8) A compact first proving slice

A compact proof could show:
- one reviewed launch card with CPU/memory/IO/process-count/scheduling/core-dump posture,
- one “default compartment versus explicit override” badge,
- one explicit payer/budget witness with limit, scope, and expiry posture,
- one live usage deck that confesses when accounting is partial or unavailable,
- one final receipt with exact runtime and exact exit status plus optional richer accounting fields,
- one limit-hit or pressure event that stays weaker than full outcome truth,
- one refusal to infer payer from container/job/cgroup membership,
- and one refusal to treat a stale live monitor as current envelope proof.

That is enough to make Schell feel super awesome at resource truth without freezing the final resource-control substrate.

## 9) Decisions intentionally kept open

This pass does **not** freeze:
- one universal resource-control API,
- one portable schema for every Linux/Windows/HPC controller,
- one scheduler or service-manager substrate,
- one canonical cost model shared by local shells and cluster jobs,
- one universal live-monitor transport,
- or one universal receipt schema for all host/provider resource metrics.

The no-regret move is smaller:
**steal reviewed resource envelopes, explicit payer/budget posture, live usage decks, and exact-but-bounded usage receipts — but keep launch limits, live monitoring, and final accounting visibly separate.**
