# SlopOS datacube evaluation — pass CLXIII

This pass asks a narrower companion-safe question than “how should Schell show status?”
The better question is:
**how should Schell expose command outcomes as a family of exact witnesses without letting one scalar code, one prompt color, or one imported completion badge impersonate shell-owned completion truth?**

## 1) SlopOS acceptance/completion posture argues against one ambient result myth

SlopOS explicitly keeps accepted request receipts separate from downstream completion and from current provider-owned live state.
That pressure transfers directly here.
If Schell claims a command or pipeline is “done”, it should be able to say whether that means:
- exact shell-owned process completion,
- a weaker wait observation,
- an imported/provider-local completion claim,
- or only historical residue.

The mistake would be to flatten them into one cozy status scalar.

## 2) SlopOS denial and receipt discipline says failure family matters, not just non-zero

SlopOS keeps denial family, winning reason, and bounded evidence explicit instead of turning every negative outcome into one giant generic failure bucket.
That pressure maps neatly onto shell outcomes.
A signal, a stopped job, an interrupted wait, a rightmost-nonzero pipeline member, a native-command non-zero exit, and a shell-native chain failure are not one thing.
So Schell should keep completion kind, aggregate rule, and winning-member evidence visible.

## 3) Waitset posture says observed change and completed work are different truths

SlopOS waitset posture treats wait results as bounded observations over object state, not as a hidden queue or portable current-state oracle.
That is a direct gift for Schell.
A shell wait observation should stay weaker than exact foreground completion, and both should stay stronger than remembered prompt chrome.

## 4) ViewFS pressure says visible badge and exact basis are not the same object

ViewFS keeps applied view, basis, and delta truth explicit.
That pressure maps neatly onto shell outcomes too.
A prompt color, a final pipeline scalar, a per-member outcome vector, a notification summary, and the exact receipt used for rerun/repair are not the same object.
So Schell should keep an outcome stack plus revealable raw member evidence rather than one decorative headline.

## 5) Steward pressure says retries need exact ending posture

Steward keeps retry, pushback, and countdown posture exact.
That matters here too.
Operators need to know whether a prior run:
- truly exited,
- was killed by signal,
- only changed status while still resumable,
- flattened a richer pipeline vector into one headline,
- or only emitted an imported/provider-local completion claim.

That makes outcome witnesses and aggregation chips better than a generic “failed last time” badge.

## 6) Helm pressure says stale basis and overwritten scalars matter for outcomes too

Helm keeps teaching that historical continuity is dangerous when the basis drifted.
That matters here as well.
A remembered `$?`, a colored prompt segment, or an outcome badge may already be stale because:
- another command ran,
- a prompt hook overwrote shell-local scalars,
- the shell only kept the aggregate and lost member detail,
- or the earlier result was imported rather than shell-owned.

So Schell should pair outcome strips with freshness markers, exact reveal cards, and reset cues.

## 7) What Schell should steal now

Schell should steal several high-value moves:
- an **outcome strip** that blooms only when the visible result is more complex than one plain success,
- **aggregate-rule chips** for pipeline outcomes,
- **pipeline-member ladders** showing the exact member vector and winning stage,
- **signal/stop chips** that refuse to flatten interrupted, stopped, and signaled endings into the same badge,
- **wait-observation cards** that confess weaker observation posture,
- and **receipt-level outcome pins** so transcripts remember exact completion kind and winning-member evidence.

These are great luxuries and do not force Schell to settle one final job model, one universal error algebra, or one portable wait/result ABI too early.

## 8) What Schell should refuse now

Schell should refuse:
- one giant flattened success/failure scalar counting as full truth,
- prompt color or notification residue counting as exact current outcome footing,
- pipeline aggregate badges that hide the winning member and rule,
- imported/provider completion claims counting as shell-owned completion by default,
- and historical shell-local scalars counting as fresh result truth after later shell activity.

## 9) Compact conclusion

The companion-safe move is to keep **command outcome** as a family of outcome witnesses with visible completion kind, aggregation rule, pipeline-member vector, signal/stop posture, freshness, and receipt-level relevance.
That lets Schell become dramatically more humane around retry, repair, and outcome reading while staying aligned with SlopOS’s refusal to let admission, observation, and current live state collapse into one flattering result story.
