# SlopOS datacube evaluation, pass XVII

**The shell+terminal should make progress, waiting, cancellation, and completion explicit shell-owned truths instead of leaving them to spinner folklore, PTY superstition, or notification theater.**

This pass adds a new caution and a new opportunity.
The caution is that once Schell has intent packets, output capsules, attention hints, pane trees, and reviewed actions, it becomes very tempting to let “still running”, “done”, “timed out”, “cancelled”, and “safe to stop” be inferred from local UI behavior.
The opportunity is that SlopOS already has the right pressure family: request contexts, explicit cancellation, request-local completion, background/job boundaries, and drain/quiescence posture.

## 1) SlopOS already separates coordination from authority

RFC-0105 is especially important.
It says request contexts carry cancellation, deadline, and correlation posture, but **context is not authority**.
That is an excellent lesson for Schell.
A terminal cancel button, timeout badge, or deadline chip should not magically grant more power, revoke unrelated power, or stand in for approval.
It should point at an exact running scope and request a named coordination move.

For Schell this suggests a first rule:
- cancellation is a **coordination request**,
- deadlines are **expectation posture**,
- and completion still requires a more exact receipt or outcome witness.

## 2) SlopOS keeps request interaction and cancellation request-local

The Request and portal families in SlopOS keep returning the same shape:
- one request,
- one request-owned handle,
- one explicit close/cancel path,
- and one exact completion or denial outcome.

That matters for Schell because shell+terminal UX keeps trying to turn long-running work into general background mythology.
The better answer is smaller:
- one **progress scope** for the running thing,
- one **cancel offer** attached to that scope,
- one **deadline hint** if the request has one,
- and one **receipt/deny/drain** landing when the scope changes state.

That is much better than pretending the terminal itself owns generic “stop whatever is happening somewhere” authority.

## 3) SlopOS job, background, and drain posture warns against fake completion

The job portal, background lease, and quiescence families all sharpen a core distinction:
- requested work,
- admitted work,
- active work,
- draining work,
- completed work,
- and background-presence permission
are not the same state.

Schell should learn from that directly.
A finished spinner, a vanished prompt, a hidden pane, or a dismissed toast must not be treated as proof that work completed cleanly.
The shell+terminal should preserve narrower states like:
- `running`,
- `waiting-input`,
- `draining`,
- `cancel-requested`,
- `cancelled`,
- `deadline-exceeded`,
- `completed`,
- `completed-with-problems`,
- `unknown-after-disconnect`.

That small state family is already more honest than most terminal folklore.

## 4) DelayBasin adds the missing process law

DelayBasin is valuable here because it keeps insisting that blocked remainder work, followthrough, and public state families stay explicit.
For Schell that means:
- when cancellation was requested but cleanup still runs, say `draining` rather than `done`,
- when the shell lost the live basis, say `unknown-after-disconnect` rather than guessing,
- when a run is still waiting on a human answer, say `waiting-input` rather than calling it stalled,
- and when work is handed off to another lane or background owner, emit a compact handoff/hold card instead of letting the progress surface silently evaporate.

That is exactly the sort of honesty a shell+terminal can turn into trust.

## 5) The no-regret object is a progress scope, not a giant task engine

A useful first object is **progress scope**.

A progress scope is a shell-owned, non-authoritative descriptor for one active or recently active unit of work.
It is not a full scheduler.
It is not a final job graph format.
It is not a durable authority token.

A v0 scope likely needs:
- `scope_ref` — exact running or recently-finished work unit,
- `lane_ref` — direct / proposal / workflow / background / replay,
- `basis_ref` — exact command, workflow seed, or receipt basis when present,
- `ctx_ref` — optional request-context or deadline digest,
- `state` — one small closed state family,
- `cancel_posture` — none / local-interrupt / request-cancel / terminate-review-required,
- `drain_posture` — none / flushing / cleanup / handoff-pending,
- `problem_refs` — optional exact problem witnesses,
- `outcome_ref` — exact receipt / denial / hold / unknown witness when available.

That is enough to make progress and cancellation feel first-class without freezing a giant workflow runtime.

## 6) Local affordances should stay visibly local

The terminal should still get to be superb.
It can absolutely provide:
- progress chips,
- status strips,
- inline countdown hints,
- click-to-cancel or click-to-jump affordances,
- finish notices,
- problem-count badges,
- and readonly replay after completion.

But these should remain visibly local renderings over shell-owned progress truth.
The shell should own the exact state transitions and exact outcome witnesses.
The terminal should not make up completion, cancellation, or timeout state because a pane disappeared or a process went quiet.

## 7) “Cancel” should split into smaller named moves

A major lesson from SlopOS is that one generic cancel button is often too vague.
Schell should probably keep at least this small ladder:
- `nudge` — bring the scope forward or request input attention,
- `request-cancel` — polite cooperative cancellation,
- `interrupt-local` — local interactive break for the active live lane,
- `terminate-after-review` — stronger stop that needs review,
- `forget-local-wait` — stop watching without claiming the work is over.

That ladder makes Schell more humane and more exact at the same time.

## 8) Great product moves become possible here too

Once progress scopes exist, Schell can steal some excellent ideas without lying:
- attach exact problem witnesses while the command is still running,
- show a tiny deadline chip without pretending it is enforcement authority,
- keep `draining` visible after cancel so the operator knows cleanup/output flush is still live,
- let finish notices jump to the exact receipt or problem list rather than just focusing a pane,
- and turn “continue waiting or move on” into an explicit operator choice rather than an invisible timeout policy.

This is one of the clearest paths to “super awesome” that still keeps architecture decisions deferred.

## 9) Transcript truth should preserve the minimum that matters

The transcript does not need every animation frame.
It does need the important truths:
- that a progress scope existed,
- what exact scope or request it referred to,
- what state transitions occurred,
- whether cancellation was requested and how,
- whether drain/handoff followed,
- and what exact outcome witness closed the story.

That compact baseline is enough to survive plain terminals, replay, SSH, and later postmortems.

## 10) What stays open

This pass still refuses to decide:
- final progress renderer,
- final scheduler or workflow engine,
- final request-context transport,
- final problem-matcher or diagnostic ontology,
- final background-job graph,
- and final interrupt/terminate signal mechanics.

That is deliberate.
This is a no-regret progress/cancellation/drain posture pass, not a task engine freeze.
