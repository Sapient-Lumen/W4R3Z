# SlopOS datacube evaluation, pass XXIV

**Fast project entry should become superb without turning saved layouts, restored panes, or target selectors into hidden authority. SlopOS keeps pushing the same deep lesson: selection and routing should stay explicit, request-local, and policy-owned even when the UX becomes dramatically better.**

This pass focuses on another tempting seam for Schell:
- project startup,
- saved pane/window arrangements,
- quick summon terminals,
- session selection and attach,
- and the dream of “take me back to where I was working.”

That seam is dangerous because it *feels* like harmless convenience.
But SlopOS keeps showing that convenience around selection is where hidden policy and hidden authority reappear.

## 1) SlopOS keeps target selection policy-owned

The current SlopOS disposable target-selection boundary is one of the clearest imports for Schell.
A requester may ask for a disposable posture.
It does **not** get to select the concrete disposable destination by ambient name.

That is a beautiful rule for shell+terminal launch surfaces.
A project launch kit may ask for:
- local posture,
- exact remembered peer posture,
- fresh disposable posture,
- or review-before-attach posture,

but it should not silently force:
- some ambient running remote session,
- some remembered mux server by hidden id,
- some invisible browser/profile/session state,
- or some implementation-local disposable target.

The import is:
**a launch surface may request posture, but strong destination choice should stay explicit and reviewable.**

## 2) SlopOS OpenURI session-selection discipline warns against convenience widening

The current OpenURI session-selection boundary says generic launch does not become a browser-session, cookie-jar, or profile-selection seam.
That warning transfers well to Schell.

A terminal project launcher should not quietly become:
- a remote profile chooser,
- a browser/account state selector,
- a resurrect-this-exact-auth-session shortcut,
- or a hidden environment/profile mode switch.

That does not mean project entry must stay primitive.
It means the shell+terminal should separate:
- generic open/launch,
- attach to a known live session,
- restore historical layout,
- and stronger explicit session/profile choices.

## 3) SlopOS workflow plumbing keeps completion request-local

The plumb posture stays explicit invocation only and refuses durable inbox, callback, or helper folklore.
That matters here too.

A Schell launch kit should not be a standing subscription that says:
- whenever I come back to this repo, rehydrate these panes,
- reconnect every remembered remote helper,
- reroute outputs into old windows,
- or keep reviving hidden background session furniture.

The import is:
**project entry should remain an explicit invocation, not ambient resurrection policy.**

## 4) SlopOS learn mode says convenience surfaces stay observational

Capshell learn mode remains observational only.
It does not auto-edit, auto-approve, or auto-rerun.

That gives Schell another useful rule.
A quick-summon panel, session navigator, or launch board may:
- suggest likely sessions,
- remember recent directories,
- surface likely workflow seeds,
- or propose reattach vs relaunch,

but it should not auto-open, auto-run, or auto-attach on the operator's behalf just because it has good guesses.

## 5) SlopOS keeps descriptive summaries weaker than live grants

Across wallet, authority-diff, and receipt posture, SlopOS keeps saying the same thing:
summary is not authority.
That should discipline session UX too.

A launch kit may summarize:
- pane arrangement,
- seed references,
- peer expectations,
- ground expectations,
- recent command chapters,
- and outcome memory,

but it should not prove that:
- the old session is still live,
- the old peer is still trusted,
- the old cwd/env basis still matches,
- or the old approval is still reusable.

That means a project cockpit should probably reopen as:
- inspect,
- summon,
- attach,
- relaunch into review,
- or hold because basis drift is unknown.

## 6) SlopOS result-sidecar discipline is a warning about rich cockpit metadata

SlopOS is very careful not to smuggle richer result or telemetry meaning into replay-critical seams.
That is a strong Schell import too.

A future project cockpit can have lots of niceties:
- recency,
- favorite status,
- outcome summaries,
- running indicators,
- launch counts,
- and notes.

But those should remain observational cockpit sidecars.
They should not quietly redefine:
- live session identity,
- review basis,
- attach authority,
- or launch correctness.

## 7) What SlopOS pressures Schell to steal

The strongest import is not a big workspace manager.
It is a small posture cluster:
- one explicit **launch-kit** object,
- one distinct **quick-summon** surface,
- one strong distinction between **attach**, **restore**, **relaunch**, and **fresh launch**,
- one rule that destination posture may be requested while exact target choice remains explicit,
- and one hold-card downgrade when session/peer/ground truth is missing.

## 8) What Schell should deliberately refuse

### Refuse restored-layout-equals-live

A restored project cockpit should be obviously useful.
It should not quietly count as a live reattached session.

### Refuse hidden remote or disposable target selection

A launch kit should not smuggle implementation-local target ids, remote mux handles, or browser/profile state into the operator's back pocket.

### Refuse ambient resurrection policy

Project convenience should not become an invisible always-revive daemon.
Explicit entry beats spooky continuity.

### Refuse collapsing discovery and action

Session navigation, recent work, launch kits, and quick summon are all valuable.
They should still preserve a ladder between finding something and performing a strong action on it.

## 9) Current consequence for Schell

The best next step looks compact:
1. one exact **launch-kit** artifact for project entry,
2. one **quick-summon** runtime surface that is preserved while live but not mistaken for durable restoration,
3. one **session navigator** that spans live / restored / historical / kit objects with clear badges,
4. one explicit **attach vs relaunch vs fresh launch** action ladder,
5. and one **target-selection hold rule** when peer, disposable posture, or basis truth is missing.

That is enough to make Schell feel much faster and more magical at project entry while still keeping workspace-model, pane-layout, sync, remote-mux, and target-selection treaties open.
