# Research synthesis — 2026-03-23 — pass CXXXI

This pass tightens one especially high-leverage luxury seam:
**quiet reuse of previously reviewed intent should become explicit, scoped, and drift-aware rather than a magical “remembered approval” blob.**

## 1) VS Code is making approval scope explicit instead of pretending every allow decision is the same

The December 2025 release added options to allow future terminal-tool commands for the **current session** or for the **workspace**.
That is a small but important design clue.
Modern operators do want fewer repetitive prompts.
But the helpful version of that comfort is scope-shaped, not forever-shaped.

Its terminal shell integration docs point the same way from another angle.
Sticky scroll and command navigation are valuable because they preserve command-locality and let the operator get back to an exact prior frame, not because history becomes self-authorizing.

## 2) Warp keeps proving that reusable command objects should stay editable before run

Warp's workflow docs still show the healthiest version of reusable command luxury:
find the workflow, inspect it, cycle through arguments, paste it into active input, edit if needed, then run.
That is a very strong pattern for Schell.
A remembered reusable command should return as a staged or leased possibility, not as ambient execution authority.

Warp's newer planning surface adds another clue.
Version history and selective execution make repeated automation feel richer **without** erasing boundaries between proposal, edited plan, and execution.
Schell should steal that separation.

## 3) fish keeps showing that history comfort benefits from explicit session classes

fish's current history docs make three useful points at once:
searchable history can be humane,
current-session history can be cleared independently,
and history can be redirected into a named session or suppressed from disk.
Private mode sharpens that lesson further.

That is exactly the kind of residue clarity Schell should import.
A custom shell+terminal gets safer when remembered command comfort, replay eligibility, and durable retention are not collapsed into one memory switch.

## 4) iTerm2 reminds us that history-linked luxuries create residue and can still inject action

iTerm2's shell integration tracks command history, cwd, host name, and more, even over SSH.
Its Captured Output feature is tied to shell integration and command history, and double-click actions can send configured text as though typed.
Its preferences also make persistence very explicit: copy/paste history and command/directory/host data can be saved to disk and erased again.

That is an ideal warning for Schell.
The moment a luxury surface is history-linked and persistent, it has become part of residue policy.
And the moment a discovered output row can inject text, inspect/open/insert/run must stay separately named.

## 5) Zellij and Ghostty reinforce that continuity and deletion must stay explicit verbs

Zellij's resurrection docs keep **resurrect**, **switch**, and **delete** distinct, and make serialization configurable.
Ghostty keeps adding comfort around quick-terminal continuity and prompt-local editing.
Together they reinforce a simple point:
stateful comfort gets safer when the operator can still tell whether they are continuing, restoring, deleting, or freshly editing.

Replay leases should inherit that same explicitness.
They should be inspectable, revocable, and clearly scoped.

## 6) The no-regret answer is a replay lease, not a permission cache

Schell does not need a grand remembered-approval subsystem next.
It only needs a compact shell-owned object with:

- exact basis,
- explicit scope chip,
- explicit retention class,
- explicit drift triggers,
- quiet-authority strip on use,
- and explicit revoke/narrow actions.

That is enough to learn a lot before choosing one persistence backend, one sync model, one policy language, or one UI stack.

## 7) Compact conclusion

The best current tools are converging on the same humane lesson:
**operators like quiet comfort, but they trust it more when it is staged, editable, scope-shaped, revocable, and visibly weaker than fresh exact review.**

For Schell, that points toward **replay leases with scope chips and quiet-authority strips** rather than toward a hidden forever-allow memory. 
