# SlopOS datacube evaluation — pass CXXXIV

This pass asks a narrower companion-safe question than “should Schell support agents or interactive PTY helpers?”
The better question is:
**what is the smallest room-local control model Schell can add without violating SlopOS exact-basis discipline or letting active PTY occupancy impersonate shell-global authority?**

## 1) SlopOS already pushes Schell toward room-local rather than ambient control

SlopOS keeps teaching the same law through different seams: exact basis first, ambient inheritance second, if at all.
That makes resident interactive rooms safer to model as bounded contexts with exact launch basis and narrow control posture instead of as a fuzzy “the whole terminal is now helper-driven” state.

## 2) D-BRACKET pressure says helper control should be task-local and deny-only by default

SlopOS privilege bracketing is explicitly task/request-local and veto-only by design.
That is an excellent companion lesson for resident rooms.
A handback or helper-driving posture inside a PTY should be exact-room-bound, revocable, and narrower than generic shell authority; it should quiet or deny within that room, not widen the whole surrounding session into a new authority plane.

## 3) D-CAPSHELL exact footing still matters after launch

SlopOS keeps Phase 1 launch posture exact around interpreter, exec object, cwd root, startup env, and ambient-session refusal.
That means Schell should preserve a clear distinction between:
- the exact shell chapter that launched a resident room,
- the room's later local interaction loop,
- and any later historical or restored room views.

The inner prompt or tool dialect may change, but it should not erase the exact launch basis that opened the room in the first place.

## 4) Learn mode pressure keeps room helpers observational first

SlopOS learn mode remains observational only.
That is the right companion answer here too.
A helper or agent inside a resident room may watch, summarize, propose, or prepare a room-local step, but it should not silently auto-edit, auto-rerun, or auto-approve just because the room is already live.

## 5) ViewFS keeps live control, command packets, and history separate

ViewFS has been consistent that command packets, live process handles, control rights, deep inspection, detached fragments, and restored views are different seams.
That maps cleanly onto this Schell question: a resident room is not just a saved command row, and a historical room summary is not the same thing as a current control right over the live room.

## 6) Steward is unusually aligned with this seam

Steward's command-guide posture explicitly says noisy commands and agent-like buffer residents may deserve less or no persistent guide chrome.
Its session-injection posture also insists that “load into this session”, “load into a subshell”, and “apply to this reviewed workflow launch” are different meanings.
That is almost exactly the missing shell+terminal law Schell needs: room-local mutation, shell-global launch, and historical summaries should not collapse into one flattering interaction story.

## 7) Helm pressure sharpens the grant window

Helm keeps pushing the idea that session-local or tab-local authority windows are not the same thing as open-ended ambient permission.
For Schell, that means any helper-driving comfort inside a resident room should look like a room-bound handback lease or authority window, not like a generic “the helper is trusted now” mode.

## 8) Companion-safe no-regret move

Schell does **not** need a final agent-terminal architecture next.
It only needs a compact split:

- **launch chapter**
- **resident room**
- **room-local step**
- **handback lease**
- **room summary**
- **restored room view**

with these rules:
- ordinary command guides may downrank or hide inside some rooms,
- handback is exact-room-bound and revocable,
- room-local approvals stay weaker than shell-global review,
- and restored room continuity remains weaker than current live control.

That keeps Schell aligned with SlopOS exactness while still stealing one of the best modern luxuries: humane help *inside* interactive terminal tools.

## 9) Compact conclusion

The companion cubes keep teaching the same law in different accents:
**live PTY occupancy is useful context, but it is not shell-global authority, not a durable receipt, and not permission for hidden ambient control.**

So the Schell-safe answer is small: **resident rooms with handback leases and subsession humility** rather than one giant “smart terminal” mode.
