# Research synthesis, pass LXXXV (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should steal the best current scrollback search, prompt-mark jump, captured-output, and command-output paging ideas — searchable buffers, pager-open on exact command output, scrollbar marks, and explicit alternate-screen toggles — but it should keep live screen state, scrollback text, search hits, marks, pager views, and exact durable command/output truth separately named so “I found it again” never impersonates “this is the exact source I can safely trust or act on now.”**

This seam matters because terminals become magical the moment old output stops being dead text.
They also become misleading in exactly the same place.
The current ecosystem now gives Schell both the delight patterns and the cautionary evidence.

## 1) Searchable scrollback is now table stakes, but it is still text-buffer search

Current terminals now plainly treat search as part of the product.
WezTerm documents a searchable scrollback buffer with a configurable maximum size. Ghostty 1.3 says scrollback search is now available and that native scrollbars can be used to navigate scrollback. Windows Terminal says its search feature lets you search the terminal text buffer for a keyword and can search directionally through that buffer. See WezTerm scrollback docs, Ghostty 1.3 release notes, and Windows Terminal search docs. See: https://wezterm.org/scrollback.html and https://ghostty.org/docs/install/release-notes/1-3-0 and https://learn.microsoft.com/en-us/windows/terminal/search

The stealable lesson is obvious: Schell should have powerful search.
The historical lesson is more important: what these tools are searching is a **buffer**.
A buffer hit is not automatically a live process, an exact command chapter, a durable receipt, or a safe rerun basis.

## 2) Prompt marks and command-output paging are worth stealing, but they are still derivative views

kitty’s current docs are especially clear here. Its actions docs say `search_scrollback` searches scrollback in a pager like `less`, automatically searching for currently selected text when present, and that `show_last_command_output` can open the last command output in a pager. Its shell-integration docs say kitty can jump to previous prompts in scrollback, open the last command output in a pager, and let the user right-click command output in scrollback to view it in a pager. Windows Terminal’s current docs say it can auto-mark prompts, show marks on the scrollbar, add marks, and scroll to marks. iTerm2’s Captured Output docs say matched output lines can be added to a toolbelt view, clicking one scrolls to reveal the line, and double-clicking can run a user-defined coprocess; those docs also require shell integration and enough scrollback history. See: https://sw.kovidgoyal.net/kitty/actions/ and https://sw.kovidgoyal.net/kitty/shell-integration/ and https://learn.microsoft.com/en-us/windows/terminal/customize-settings/profile-advanced and https://learn.microsoft.com/en-us/windows/terminal/customize-settings/actions and https://iterm2.com/documentation-captured-output.html

This convergence is real and very worth stealing.
But it points to a specific Schell answer: **marks, search hits, captured-output rows, and paged views are navigation/review objects. They should remain weaker than exact command chapters or exact output capsules when those exist.**

## 3) Alternate screen still proves that “what I can see” and “what is in scrollback” are not one truth

The alternate-screen story is still fragmented enough that Schell should not flatten it. Windows’ virtual-terminal docs say the alternate screen buffer is exactly the dimensions of the window and has no scrollback region. iTerm2’s profile docs say lines scrolled off the top in alternate-screen mode are saved to scrollback only if an option is enabled. kitty’s overview says its scroll actions only take effect in the main screen, while in alternate screen the key events are passed through to the running program. And kitty’s 2026 changelog says it avoids rewrapping text in the alternate screen buffer during live resize. See: https://learn.microsoft.com/en-us/windows/console/console-virtual-terminal-sequences and https://iterm2.com/documentation-preferences-profiles-terminal.html and https://sw.kovidgoyal.net/kitty/overview/ and https://sw.kovidgoyal.net/kitty/changelog/

That means alternate-screen residue, if present at all, is not the same thing as main-screen scrollback.
The correct import for Schell is not “scrollback everywhere.”
The correct import is an explicit distinction among **main-screen text**, **alt-screen live state**, **optional alt-captured residue**, and **exact output capsules**.

## 4) Pagers are a second workflow and sometimes a security boundary

The pager story is more subtle than “open in less.” The `less(1)` page says it can begin before the full input is read, which is one reason it is such a good review surface for big outputs. But systemd’s docs also say common pagers like `less` can open or write files and run shell commands, and that when commands run with elevated privileges the pager becomes a security boundary. systemd also documents secure mode using `LESSSECURE=1`, and its pager docs explain that the `X` behavior is used by default so output remains visible after the pager exits even though some functionality such as mouse scrolling in paged output no longer works. See: https://man7.org/linux/man-pages/man1/less.1.html and https://man7.org/linux/man-pages/man1/machinectl.1.html and https://man7.org/linux/man-pages/man1/systemctl.1.html

This is an unusually useful lesson for Schell.
A pager should be modeled as a **view surface with posture**, not as a harmless convenience layer.
That means secure pager lanes, degraded pager lanes, live-follow pager lanes, and exact-source pager lanes can all exist without pretending they are the same thing.

## 5) What Schell should now do

This pass points to a compact answer:
- **search-hit cards** that carry source and strength,
- **mark cards** that remain navigation aids rather than authority,
- **pager witnesses** that confess source kind, source strength, and secure/degraded/live posture,
- **alt-screen badges** that say whether the terminal is in alt-live, alt-captured, or not-captured posture,
- **exact-source promotion rails** from search hits or marks into exact command/output objects,
- and **secure pager restrictions** when the source is elevated or secret-bearing.

## 6) Decisions intentionally kept open

This pass does **not** freeze:
- one final pager backend,
- one final scrollback store,
- one final mark/search index,
- one final alt-screen capture policy,
- one final secure-pager contract,
- or one final reentry/search UI.

The no-regret move is smaller and stronger:
**give Schell pager witnesses, alt-screen posture badges, search-hit cards, and exact-source promotion rails so search and paging become luxurious without letting derived views impersonate durable truth.**
