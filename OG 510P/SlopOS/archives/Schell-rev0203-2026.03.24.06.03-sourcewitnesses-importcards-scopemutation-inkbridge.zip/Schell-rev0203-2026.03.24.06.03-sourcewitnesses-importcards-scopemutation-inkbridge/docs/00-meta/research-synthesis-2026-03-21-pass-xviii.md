# Research synthesis, pass XVIII (2026-03-21)

This pass focuses on another load-bearing seam:
**current shells and terminals keep rediscovering that working directory, environment activation, and project-local context are incredibly useful — and incredibly easy to make ambient, surprising, or stale.**

## 1) Current terminal UX gets much better when cwd is explicit

VS Code’s terminal shell integration says it plainly: shell integration tells VS Code what the current working directory is, and that enables more reliable link resolution, directory display in tabs, recent-directory navigation, and inherited split cwd behavior. Without that, the terminal has to guess or poll. See: https://code.visualstudio.com/docs/terminal/shell-integration

WezTerm documents the same kind of gain through OSC 7. When the current working directory is set via OSC 7, a new tab can inherit the current tab’s working directory. See: https://wezterm.org/shell-integration.html

iTerm2’s Semantic History goes even further: it tracks the current working directory for each line in the terminal to help find files when the user Cmd-clicks them. See: https://iterm2.com/documentation-preferences-profiles-advanced.html

The lesson for Schell is straightforward:
**cwd should be an explicit witness, not a prompt-scraping guess.**

## 2) Prompt-time environment mutation is common, but it is exactly the sort of ambient magic Schell should surface explicitly

`direnv` requires a shell hook and explicitly says it needs to be hooked into the shell to work properly. It also has explicit `allow` and `deny` commands for `.envrc` / `.env` authorization. See: https://direnv.net/docs/hook.html and https://direnv.net/man/direnv.1.html

Its stdlib now even includes `require_allowed`, which re-requires authorization if watched files change. See: https://direnv.net/man/direnv-stdlib.1.html

`mise activate` is similar in spirit: it registers a shell hook so `mise hook-env` runs every time the prompt is displayed, updating PATH and related environment variables when the project context changes. See: https://mise.jdx.dev/faq.html

These systems prove that project-local activation is useful.
They also prove how easy it is for live execution grounds to become invisible prompt-time magic.

## 3) Reproducible dev-shells are attractive, but they are not a reason to let grounds stay vague

The Nix manual says `nix develop` starts a bash shell that provides an interactive build environment nearly identical to what Nix would use to build an installable, and it notes the interface is experimental. See: https://nix.dev/manual/nix/2.20/command-ref/new-cli/nix3-develop

This is a powerful pattern for Schell to learn from.
But the right import is not “be Nix.”
The right import is:
- a named, inspectable ground can be very valuable,
- exact environment snapshots can be worth carrying around,
- and historical grounds may be worth replaying or comparing.

## 4) Environment changes can also be explicit and named rather than pure mutation

Nushell’s `overlay use` treats definitions and environment as an overlay that can be loaded and reloaded. See: https://www.nushell.sh/commands/docs/overlay_use.html

That is a useful design pressure for Schell.
A custom shell+terminal does not need to flatten environment change into raw `export` folklore if named overlays, activations, or ground packets turn out to be more legible.

## 5) Past systems also show how startup behavior can quietly scramble execution grounds

VS Code’s terminal basics docs call out a real PATH pitfall: launching a bash login shell on startup and then another login shell for the integrated terminal can reorder PATH in unexpected ways. See: https://code.visualstudio.com/docs/terminal/basics

That is exactly the kind of lesson Schell must learn from the past.
The shell+terminal should not pretend startup state is naturally honest just because existing shells have normalized it.

## 6) A no-regret Schell cluster is visible now

A decision-light first cluster looks like this:
- one shell-owned **execution ground packet**,
- one compact **ground strip** for cwd / env / activation posture,
- one explicit **activation witness** family,
- one compare-and-set rerun rule that downgrades on ground drift,
- one exact distinction between current ground, historical ground, and guessed nearby context,
- and one transcript-visible family for important ground transitions.

## 7) The best steals are the humane ones

The best ideas to steal now are:
- exact cwd-aware link/open behavior,
- per-command or per-line cwd witnesses,
- explicit activation enter/exit cards,
- compact PATH/env diffs on demand,
- compare-and-set rerun under the same ground,
- inspect-only downgrade when the ground drifted,
- and named overlays / activations instead of invisible prompt magic.

## 8) What to refuse

The moves to refuse are just as important:
- do not let prompt color, shell theme, or a toolchain banner become the only evidence of current ground,
- do not silently rerun reviewed actions on a new ground just because the prompt hook refreshed,
- do not flatten cwd, namespace root, PATH drift, and dev-shell activation into one vague “environment changed” warning,
- do not freeze a final workspace / dev-environment / package-manager integration story before small specimens exist,
- and do not import legacy rc/profile behavior as the Schell default just because many current tools depend on it.
