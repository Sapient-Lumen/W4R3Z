# SlopOS datacube evaluation, pass XXXI

This pass keeps one bounded thesis in focus:
**SlopOS keeps teaching that warm state, preview state, and speculative work are optional accelerators rather than baseline truth. Schell should steal that lesson before the custom shell+terminal normalizes prompt-time heroics.**

SlopOS is still in design phase, which makes this exactly the right time to import its discipline instead of reverse-engineering it later.
The newest companion revision is useful because it does not only narrow OpenURI.
It also sharpens how warm restores, local caches, and repaired state should behave before they are allowed to look live.

## 1) The OpenURI family keeps repeating: extra work is a second workflow

The recent OpenURI boundaries refuse to treat generic launch as a synonym for:
- preview metadata,
- speculative loading,
- request shaping,
- materialization,
- durable recent-item truth,
- or downstream completion truth.

That is a direct shell+terminal lesson.
When Schell is tempted to make one row, hover, or palette entry also:
- fetch docs,
- warm a target,
- resolve remote identity,
- materialize a file,
- or prove freshness,

SlopOS says to split those moves before they fossilize.

## 2) capshell keeps warning that hidden prompt-time behavior is where shells go wrong

The capshell posture family already refused hidden command-string parsing, startup/profile magic, and hidden expansion.
That matters here because prompt-time “help” often sneaks in through the same door:
rc hooks, completer helpers, cwd-triggered side effects, environment managers, or launch wrappers that quietly do work just to keep the shell looking helpful.

The lesson is not anti-help.
The lesson is:
**if the terminal needed a second workflow to become clever, say so.**

## 3) The microvm warm-start posture adds a deeper rule: accelerators are optional and owner-local

The newer `microvm-template-availability-posture-v0.md` says warm leaves are owner-local, semantically optional accelerators.
It explicitly refuses a public cache-hit/miss or pending/active/inactive truth plane.
That is a beautiful import for Schell.

Cached suggestions, warmed preview cards, remembered semantic-link resolutions, or resurrected shelves can all be useful.
But they should behave like optional local acceleration, not like new public truth that the operator is expected to rely on blindly.

## 4) The restore-repair barrier gives Schell a rule for restored shell+terminal state

The `microvm-restore-repair-barrier-posture-v0.md` says restored guests complete clone-sensitive repair before any externally visible work or readiness claim.
That same discipline should shape Schell.
If a terminal restores:
- a chapter shelf,
- a completion cache,
- a semantic-link map,
- a preview card,
- or a workflow/history working set,

it should keep that state visibly historical until any needed repair or reacquisition completes.
Restored help may accelerate re-entry; it should not race ahead as if it were fresh shell truth.

## 5) This points to prompt budgets and idle lanes

Putting those SlopOS lessons together suggests a compact Schell posture:

- **critical-path prompt help** should prefer shell-static, shell-witnessed, or already-cached local state,
- **menu-open and hover** should not silently authorize helper exec, remote fetch, or materialization,
- **idle repair/refresh** may improve cached rows after the prompt is already usable,
- **restored or warmed state** stays visibly weaker than fresh truth until repaired,
- and **expensive upgrades** should be explicit actions like refresh, inspect more, or materialize.

## 6) This is how Schell avoids the old failure mode

The old shell failure mode is not only “text commands are scary.”
It is that one flattering surface quietly expands into:
- background hooks,
- invisible parsers,
- remote probes,
- hidden startup code,
- unbounded prefetch,
- and cached state that starts pretending to be live.

SlopOS is strongest where it keeps refusing those expansions early.
Schell should copy that posture while both projects are still young enough to benefit from it.

## 7) The no-regret Schell move now

The next safe ratchet is not to choose one completer daemon, cache backend, background scheduler, or preview engine.
It is to say that Schell will distinguish:
- prompt-critical help,
- explicit richer help,
- idle repair/refresh,
- and historical/restored help.

That keeps the shell+terminal very ambitious without accidentally requiring prompt-time heroics just to feel modern.

## 8) Decisions intentionally kept open

This pass still does **not** freeze:
- one prompt renderer architecture,
- one idle worker topology,
- one cache format,
- one preview backend,
- one workflow store,
- or one restore backend.

The no-regret move is narrower:
**treat speculative work and warm state as optional accelerators, keep prompt-time delight cheap, and require explicit steps before stronger work impersonates current truth.**
