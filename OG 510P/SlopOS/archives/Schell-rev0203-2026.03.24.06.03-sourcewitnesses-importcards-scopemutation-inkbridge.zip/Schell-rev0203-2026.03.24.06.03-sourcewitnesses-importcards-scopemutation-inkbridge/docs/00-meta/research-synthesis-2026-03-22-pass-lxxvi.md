# Research synthesis, pass LXXVI (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should steal confirmation-gated agents, elevated-writeback edits, clipboard permission prompts, trusted-path ideas, and remote comfort helpers from current systems — but it should keep every borrowed local power explicit so “I am on a remote shell”, “this pane can use my local agent”, “this helper changed the remote”, and “this approval is on a trusted path” never collapse into one flattering session myth.**

This seam matters because current shell+terminal tools now expose several kinds of *borrowed authority* at once:
- a remote shell can use a forwarded local SSH agent,
- a terminal app can request clipboard reads or writes,
- a remote-helper wrapper can copy local files and environment into the remote session,
- a terminal can expose a remote-control protocol to scripts,
- and a “quick privileged edit” can either be an elevated shell or a much narrower writeback lane.

All of those are genuinely useful.
They are also exactly where shell comfort becomes a trust accident.
The operator can stop knowing:
- whether the remote peer can merely *request* a local key operation or can browse a whole provider namespace,
- whether a clipboard or terminal-control request will prompt, deny, or silently succeed,
- whether a helper changed the remote host before the first prompt even appeared,
- whether a privileged edit lane actually ran the editor with elevated authority,
- and whether the final approval path is still local trusted chrome or just terminal text that looks reassuring.

The no-regret move is not to reject comfort.
It is to separate local truth, borrowed local power, remote helper posture, and trusted approval path explicitly.

## 1) OpenSSH keeps teaching the same lesson: forwarding is useful, but forwarded power is still local power

Current `ssh_config(5)` docs say agent forwarding should be enabled with caution because users on the remote host who can bypass file permissions for the agent socket may access the local agent and perform operations on the loaded keys.
Current `sshd_config(5)` docs add a sharper warning: disabling agent forwarding on the server does not materially improve security unless users are also denied shell access, because they can install their own forwarders.
That is a crucial design lesson for Schell.
A remote pane that can spend local power should say so plainly.
“Remote” is not the same as “remote-only”.
See: https://man7.org/linux/man-pages/man5/ssh_config.5.html and https://man7.org/linux/man-pages/man5/sshd_config.5.html

## 2) OpenSSH also shows the right mitigation pattern: confirmation, time bounds, and constrained delegation

Current `ssh-add(1)` docs say identities can require confirmation before use.
Current `ssh_config(5)` docs say `AddKeysToAgent` can be set to `confirm`, making each use require confirmation.
Current OpenSSH release notes also describe hardening around destination-constrained keys and specifically mention refusing signing operations when session binding has failed and refusing to fall back to unconstrained adds.
That combination is extremely stealable.
The right luxury is not “forward the whole agent and hope”.
It is “show the borrowed local authority, narrow it, and require explicit confirmation when the user asked for that posture.”
See: https://man7.org/linux/man-pages/man1/ssh-add.1.html , https://man7.org/linux/man-pages/man5/ssh_config.5.html , and https://www.openssh.org/releasenotes.html

## 3) `ssh-agent` itself proves that agent forwarding has hidden feature edges, not just one flat yes/no bit

Current `ssh-agent(1)` docs say forwarded clients may, under explicit options, load PKCS#11 or FIDO provider libraries, and that remote signalling depends on `ssh(1)` so other forwarding tools may circumvent the restriction.
The same page says the default behavior blocks some FIDO signatures in order to prevent forwarded access from also implicitly forwarding website authentication.
That is gold for Schell.
It means borrowed authority is not a single badge.
It has sub-capabilities and policy edges.
Schell should expose those edges rather than pretending “agent available” is enough truth.
See: https://www.man7.org/linux/man-pages/man1/ssh-agent.1.html

## 4) `sudoedit` remains one of the best “steal this, not that” lessons in privileged UX

Current `sudoedit(8)` docs say the editor is run with the invoking user's environment unmodified, editing user-writable temporary copies, and only the writeback crosses the privileged lane.
That is a brilliant design clue for Schell.
A lot of work that people currently perform inside a privileged interactive shell should instead use a narrower **elevated writeback** rung.
This is a much better default than treating every “edit protected file” action as grounds for a whole elevated session.
See: https://man7.org/linux/man-pages/man8/sudoedit.8.html and https://man7.org/linux/man-pages/man8/sudo_plugin.8.html

## 5) kitty is a perfect warning that the best remote comforts are also hidden helper work unless named explicitly

Current kitty ssh-kitten docs say it can automatically set up shell integration on the remote host, copy terminfo, set environment variables, and copy files so the remote shell feels like the local one.
Current kitty remote-control docs say password-based authentication over SSH uses an environment variable (`KITTY_PUBLIC_KEY`) and encrypted communication with time-based nonces to reduce replay risk.
Those are clever features.
They are also exactly why Schell should keep a **helper posture card**.
If the terminal copied files, changed environment, installed helpers, or enabled a local-control bridge, the user should not have to infer that from vibes.
See: https://sw.kovidgoyal.net/kitty/kittens/ssh/ and https://sw.kovidgoyal.net/kitty/remote-control/

## 6) kitty clipboard control shows a better pattern than silent OSC folklore

Current kitty clipboard docs say OSC 5522 allows terminals to ask the user for permission to access the clipboard, return permission denied, and distinguish read/write failures explicitly.
That is a very strong clue for Schell.
Clipboard and similar host-side powers should become ask/allow/deny surfaces with transcript-visible posture, not ambient terminal side effects hidden behind escape-sequence trivia.
See: https://sw.kovidgoyal.net/kitty/clipboard/

## 7) Trusted-path history still matters for the modern terminal

Current IBM AIX docs on the Secure Attention Key say it establishes a trusted communication path and explicitly recommend entering `su`, `passwd`, and similar high-risk commands only after establishing that trusted path.
That is older operating-system wisdom, but it remains highly relevant.
A terminal that wants to be super awesome should have a visibly separate local trusted review lane for the strongest approvals.
That lane does not need to copy AIX exactly.
But it should learn the lesson: some approvals are too important to live only inside ordinary terminal flow.
See: https://www.ibm.com/docs/en/aix/7.1.0?topic=configuration-trusted-computing-base and https://www.ibm.com/docs/ko/aix/7.1.0?topic=options-using-secure-attention-key

## 8) The strongest super-awesome moves are clearer now

The highest-value moves worth stealing from this seam are:
1. **borrowed-authority strips** that enumerate local agent use, clipboard access, host-open/file bridges, terminal remote control, and notification/focus helpers,
2. **confirmation-gated leases** for forwarded key use, with confirm/timebox posture instead of one ambient forwarding bit,
3. **elevated-writeback edits** as a first-class rung weaker than a full privileged shell,
4. **helper posture cards** for copied files, injected environment, remote shell integration, and bridge activation,
5. **trusted approval lanes** for the strongest local approvals,
6. **clipboard/remote-control ask–allow–deny cards** instead of silent host-side side effects,
7. **sub-capability badges** for borrowed authority such as sign-only / provider-load / FIDO-websafe / unknown,
8. **freshness and peer-binding chips** for remote-control bridges,
9. and **downgrade rules** that collapse strong actions back to inspect-only when peer truth or approval-path truth is weak.

## 9) What Schell should absolutely refuse

Schell should refuse:
- treating “remote shell” as proof that no local power is at stake,
- treating forwarded agent availability as a flat yes/no rather than a constrained capability surface,
- treating privileged edits as automatic grounds for a full elevated shell,
- letting clipboard, host-open, or terminal-control requests happen silently,
- and letting the strongest approvals live only in ordinary PTY flow.

## 10) Decisions intentionally kept open

This pass does **not** freeze:
- one final auth-agent backend or key-provider model,
- one final remote-helper transport,
- one final terminal remote-control protocol,
- one final secure-attention implementation,
- one final clipboard policy stack,
- or one final privileged-edit broker.

The no-regret move is smaller:
**give Schell borrowed-authority strips, confirmation-gated leases, elevated-writeback edit rungs, helper posture cards, clipboard/remote-control ask surfaces, and trusted approval lanes while keeping remote comfort visibly weaker than exact local authority unless freshly attested.**
