# SlopOS datacube evaluation, pass XLIX

This pass keeps one bounded thesis in focus:
**the most important SlopOS lesson for Schell is not one flashy feature, but the refusal to let shell convenience silently re-grow hidden parsers, ambient startup/session state, or a portable PTY/job-control authority plane. Because SlopOS is still design-phase too, Schell should import those laws early and treat terminal luxuries as explicit, shell-witnessed bundles rather than irreversible architecture bets.**

That is exactly the right stance for a brand new shell+terminal.
It keeps the archive ambitious while refusing the old trap where comfort features quietly choose the runtime model.

## 1) D-CAPSHELL already tells us what not to repeat from shell history

One of the clearest recent SlopOS moves is the capshell command-string posture.
`capshell.exec` stays a structured argv launch seam and refuses to become a shell parser, command-string tokenizer, or hidden `sh -c` / `system()` adapter.

That is a huge past lesson.
Classic shell history is full of quoting mistakes, accidental expansion, and “it was only one string” ambiguity.
Schell should treat that as settled guidance:
**reviewed action truth should stay stronger than any pretty command line rendering, command palette, or rerun convenience.**

A custom shell+terminal can absolutely render commands beautifully, annotate them richly, and make them easier to edit.
It should still preserve one exact action shape underneath.

## 2) SlopOS also refuses the ambient startup/session folklore that shells historically normalize

The capshell env-baseline posture is just as important.
SlopOS refuses to auto-inject a comforting baseline of `HOME`, `PWD`, `TERM`, `LANG`, `TZ`, and similar session baggage when the reviewed execution pack did not ask for it.
The archive also keeps cwd/env/startup profile seams explicit instead of letting “the way my shell normally starts” masquerade as execution truth.

That is another lesson Schell should import directly.
The terminal may project cwd, project hints, recent peers, repos, or launch kits.
The shell should still be able to say:
- this is exact execution ground,
- this is shell-known context,
- and this is only local convenience.

That split is the only reliable way to become super awesome without quietly becoming haunted by login-ritual state.

## 3) SlopOS draws a hard line around PTY and job-control semantics

The capshell terminal/job-control posture is maybe the most valuable architectural throttle in the whole companion datacube.
SlopOS declines to turn `capshell.exec` into a portable PTY allocator, controlling-terminal broker, or `fg`/`bg`/`jobs` workflow plane.
Interactive UX may exist locally, but it does not become durable reviewed meaning by default.

That is the right lesson for Schell.
Prompt-safe pointer editing, sticky command headers, semantic selection, output paging, and background shelves are all worth pursuing.
But they should stay visibly local or shell-witnessed.
They should not quietly force one universal PTY/session semantics treaty before the archive has earned it.

## 4) CH-EXECPACK v2 teaches the right shape for future shell honesty

The execution pack is a beautiful design clue.
It bundles complete reviewed context so ambient authority-by-omission becomes harder to smuggle in.
Yet it still avoids turning the whole system into one giant pipeline ontology.

That suggests a very healthy Schell move:
- keep exact action basis explicit,
- keep nearby context packets explicit,
- and keep humane terminal layers reversible.

In other words, use packets, witnesses, and receipts where they buy truth — not because every future interaction must become one final structured object model.

## 5) Because SlopOS is still design-phase, the right imports are laws, not stacks

Schell should be especially careful here.
It would be too early to let the companion datacube pressure us into choosing:
- one final parser story,
- one final renderer stack,
- one final shell↔terminal transport,
- one final structured pipeline model,
- or one final plugin ecosystem.

But it is not too early to import stronger laws.
The laws now look pretty clear:
- exact reviewed action beats convenient display,
- explicit context beats ambient session magic,
- local terminal luxury beats hidden portable authority,
- and shell-known truth beats renderer folklore.

## 6) The direct super-awesome move for Schell

The best near-term move is not to copy one existing shell or terminal.
It is to package luxuries as **explicit bundle candidates** that can be proven without freezing deeper architecture.

The most promising bundles now look like:
- command chapters, marks, and sticky navigation that stay shell-known,
- insert-first suggestions and parameter help that stay weaker than run,
- plumber-like object routing that keeps reveal/open/insert/fix distinct,
- structured receipt/denial inspection that does not universalize structured pipelines,
- upgraded input/key tables as capability witnesses rather than assumptions,
- and strict-safe review for authority-adjacent text.

That is a very SlopOS-shaped answer.
It lets Schell become luxurious while still acting like a serious authority-sensitive system.

## 7) Repo/process lesson to steal directly

SlopOS keeps rewarding the same method too:
- make the boundary explicit,
- register the open question,
- name the followthrough specimen debt,
- and avoid pretending the design is more settled than it is.

Schell should keep stealing that process.
A custom shell+terminal is exactly the kind of project that gets worse when its most seductive ideas arrive without a ledger.
