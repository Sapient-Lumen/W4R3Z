# Research synthesis, pass XLVI (2026-03-21)

This pass focuses on one bounded seam that Schell did not yet give its own surface:
**the current collaboration ecosystem keeps proving that “sharing a terminal” is not one thing. Read-only watching, writable co-driving, browser join, service sharing, invitation topology, guest identity, and evidence export are different operator moves, and Schell should stop letting them borrow one magical share button.**

## 1) The oldest lesson is still the most important: read-only should be the cheap default

The modern official collaboration tools are very explicit here.
Live Share says terminals are not shared by default because guests would otherwise gain at least read-only access to your command output, and when a terminal is shared the host chooses read-only or read/write. It also warns that read/write guests can run any command on the computer that the host can.

That is the first lesson Schell should keep from the past:
**shared-terminal collaboration only gets safer when observation stays cheaper than control.**

## 2) Guest identity and approval are real semantics, not social details

Live Share’s security docs are equally clear that guest approval, anonymous-vs-signed posture, and command-control posture are separate controls. Anonymous guests can be allowed only as read-only guests by default and require host approval unless policy changes that posture.

That is exactly the right mental model for Schell.
A collaboration link is not enough.
Identity posture, approval posture, and control posture are different fields of truth.

## 3) Relay/direct topology and writable terminals should remain separately policyable

The Live Share policy docs reinforce the same point from the enterprise side. They expose separate policies to disable read-write terminals, disable shared servers, require direct connection instead of relay-based guests, reject anonymous guests, and require per-guest approval.

That is a strong design clue.
Schell should not assume that collaboration is one scalar “on/off” feature.
Transport topology, service sharing, and write control are independently meaningful decisions.

## 4) Browser join is a real luxury, but it widens the seam

Tools like tty-share make a very compelling case that browser join is delightful because the remote participant needs no extra tools and can often open a secret URL from almost anywhere.
That is a genuinely brilliant idea worth stealing.

But browser join also widens the share surface.
Once the guest is joining through a browser, it becomes even more important to keep read-only watching, keyboard control, service opening, and guest-side side effects separately named.

## 5) Shared sessions need strong humility about side effects on the guest

One of the clearest historical warnings is Microsoft’s 2019 Live Share security advisory: a host-specified shared-server URL could cause a guest browser to navigate without explicit consent, and the fix was to prompt the guest before browsing the host-specified URL.

That lesson should be imported directly.
A collaboration surface should never let the host silently cause guest-browser open, guest clipboard write, or similar local side effects just because there is already a shared session.

## 6) The terminal-sharing ecosystem keeps rediscovering role separation

The smaller sharing tools keep teaching the same lesson in simpler form.
tmate supports separate read-only connection strings.
GoTTY defaults to no keystroke input, warns that permitting writes is dangerous, and suggests using tmux or screen so the host can keep control while clients only watch.

That is exactly the no-regret import for Schell.
Even when live sharing is desired, **co-drive should be a stronger lane than watch-only**.

## 7) Backend permanence is shaky, so collaboration architecture should stay open

The Teleconsole repository is a good warning. Its public service was shut down.
That does not invalidate the product idea at all, but it does strongly suggest that Schell should avoid freezing one relay/service architecture too early.

The right design steal is the role and permission model, not attachment to one hosted broker.

## 8) The no-regret Schell move is a compact guest-witness family and share ladder

A good v0 shell+terminal posture here is not a giant real-time collaboration stack.
It is a compact exact truth plus bounded luxury around it.

Schell should likely introduce:
- **guest witnesses** for role, control scope, identity posture, transport kind, and revocation posture,
- a **share ladder** that separates evidence export, live observation, annotation, request-drive, granted-drive, and service share,
- **guest-side side-effect gates** so browser open / clipboard write / service exposure stay separately named approvals,
- and perhaps a **pass-keyboard** or one-prompt drive lease model so pair-debugging becomes easier without immediately collapsing into ambient co-typing.

That would make Schell much better than classic shells and ad-hoc tmux folklore at teaching, pair debugging, and incident help while still preserving the single biggest historical lesson on this pass:
**collaboration should feel brilliant, but the shell must never forget which part is observation, which part is control, and which side is about to experience the side effect.**
