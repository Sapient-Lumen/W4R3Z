# Research synthesis — 2026-03-23 — pass CLXIII

This pass tightens the next seam instead of widening “status handling” into one giant job-control / structured-error / workflow treaty:
**outcome luxury is worth stealing, but the shell should stay excellent at saying what exact outcome happened, which member of a pipeline supplied the visible result, whether a signal or stop intervened, and which shell-specific aggregation rule is currently being projected outward.**

The strongest current lesson is that modern shells already expose multiple outcome truths, but in fragmented, shell-specific ways.
That points to a good next Schell move:
**outcome witnesses, exit families, and pipefail humility** rather than one flattering “the command failed” story.

## 1) Bash proves that `$?` is too small for pipeline truth

Current Bash docs say the exit status of a pipeline is the status of the last command unless `pipefail` is enabled, in which case it becomes the status of the rightmost non-zero member or zero if all succeeded.
The same manual exposes `PIPESTATUS` as the vector of statuses from the most-recent foreground pipeline, says fatal signals map to `128+N`, and documents `wait -n`, `wait -p`, and `wait -f` distinctions.
That means even the classic shell already has richer outcome truth than the single scalar most prompts project.

That is a strong Schell lesson.
Pipeline-member outcomes, aggregate outcome, signal mapping, and wait observations should remain separately witnessed.

## 2) fish proves that freshness and pipeline vectors matter

Current fish docs say `$status` is the exit status of the last process in the last job, `$pipestatus` is the list of statuses for all processes in a pipe, and signals map to `128+signal`.
The release notes also call out `$status_generation`, which exists precisely because shell-local status gets overwritten easily and consumers need a freshness signal.
That is a very clean model for Schell:
outcome scalar, pipeline vector, and freshness should not be flattened into one boolean prompt color.

## 3) zsh shows that stops are part of outcome truth too

Current zsh docs expose `$pipestatus` as an array of exit statuses for the last pipeline.
The zsh release notes also note that `$?` and `$pipestatus` were updated when a job stops, not only when it exits.
That is a strong warning for Schell.
Stopped is not the same thing as completed-failed, and pipeline truth can change because job state changed rather than because the whole command truly finished.

## 4) PowerShell proves success-bool and native exit code are different surfaces

Current PowerShell docs say `$LASTEXITCODE` stores the exit code of the last native program or script, while the chain operators `&&` and `||` use both `$?` and `$LASTEXITCODE` to decide whether a pipeline failed.
The docs for `pwsh` also say process exit-code propagation can collapse to `0` or `1` unless callers explicitly `exit $LASTEXITCODE`.
Another current preference doc says `$PSNativeCommandUseErrorActionPreference` can make native non-zero exits issue errors according to `$ErrorActionPreference`.
That means chain truth, native exit truth, and process-exit propagation are already distinct layers.

## 5) Nushell proves richer outcomes are useful and still evolving

Current Nushell book docs say `complete` runs an external to completion and gathers stdout, stderr, and exit code together in one record.
The special-variables docs still expose `$env.LAST_EXIT_CODE`, while the 0.98.0 release notes say non-zero exit codes from external commands became errors that can be caught with `try`/`catch`.
The 0.108.0 release notes add an experimental `pipefail` option that changes `$env.LAST_EXIT_CODE` to the rightmost non-zero pipeline member.
That is excellent evidence for Schell.
Rich outcome cards and explicit aggregation rules can be valuable without deciding that the final shell result model must be one universal typed error algebra.

## 6) The concrete Schell move

Schell should add a compact **outcome-witness** family:
- `outcome_ref` — exact outcome identity,
- `subject_ref` — command / pipeline member / pipeline aggregate / job / wait target,
- `scope_lane` — foreground command / pipeline member / aggregate / async launch / wait observation / historical,
- `completion_kind` — exited / signaled / stopped / continued / admission-only / interrupted-wait / unknown,
- `numeric_code` — exact shell/native code when present,
- `signal_ref` — exact signal when present,
- `aggregate_rule` — last-command / rightmost-nonzero / chain-success / explicit-member / provider-local / unknown,
- `member_statuses` — exact per-member vector when the subject is a pipeline,
- `winning_member_ref` — exact stage that supplied the aggregate,
- `freshness_ref` — current generation or stale marker,
- `reveal_ref` — exact card or receipt.

Within that family, pipeline aggregates can carry a dedicated rule chip, and wait observations can stay a weaker subfamily that confesses when the shell merely saw a status change rather than durable completion.
That is enough to steal a lot of outcome clarity without freezing one universal error algebra, one job-object treaty, or one portable wait ABI.
