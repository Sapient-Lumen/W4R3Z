# Research synthesis, pass CXXVII (2026-03-22)

This pass keeps one narrower lesson explicit:
**secure input is protective local posture, not proof of prompt meaning.**

The current ecosystem converges on that lesson from several directions.
Apple Terminal says Secure Keyboard Entry can prevent other apps on your computer or the network from detecting and recording what you type, but it also warns that some other apps may require Terminal keystrokes.
Ghostty exposes `toggle_secure_input` and states that it applies to the entire application, must be manually untoggled or released by quitting, and is only implemented on macOS.
kitty's changelog records a macOS decision to persist Secure Keyboard Entry across restarts to match Terminal.app.
iTerm2 says Secure Keyboard Entry prevents other programs from seeing what you type, may disable global hotkeys, and can block focus stealing while sensitive text is being entered.
Apple's Input Monitoring guidance reminds us that some apps may otherwise monitor keyboard, mouse, or trackpad activity when granted permission.
Apple's 2024 macOS Sonoma 14.4 security notes also record a fix for an issue where an unprivileged app may have been able to log keystrokes in other apps including those using secure input mode.

Taken together, the design-phase lesson for Schell is straightforward:

## 1) Protection and meaning are different

Secure input can narrow who sees keystrokes.
It does **not** prove that the child process is asking for a password or that the shell now has stronger semantic knowledge.

## 2) Scope matters

Protection may be pane-local, app-wide, or OS/trusted-path scoped.
Ghostty's explicit app-wide statement is a very useful design clue.

## 3) Side effects matter

Global hotkeys, focus stealing, clipboard behavior, history behavior, and assistive hooks may change while a secure-input lease is active.
So secure-input witnesses should confess cost as well as protection.

## 4) Freshness and release matter

A secure-input state that persists across restarts or must be manually untoggled should never be treated as invisible ambient fact.
Schell should keep activation source, freshness, and release posture explicit.

## 5) Compact answer

Schell does **not** need to solve secure attention next.
It needs one bounded move:
- a secure-input witness,
- a sensitive-entry lane,
- scope and side-effect chips,
- and a rule that protective local posture stays weaker than shell semantic truth.
