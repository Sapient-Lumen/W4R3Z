# SlopOS datacube evaluation — pass CXXXI

This pass asks a narrower question than “how should Schell remember approvals?”
The companion-safe question is:
**what is the smallest remembered-review seam Schell can add without violating SlopOS's exact-basis discipline or importing a hidden policy plane?**

## 1) SlopOS approval-basis posture rejects follow-the-head approval

`approval-basis-posture-v0.md` keeps one central rule extremely crisp:
approval binds one exact action digest and does **not** quietly follow a mutable nearby target.
If the mutable basis matters, it must already be encoded into exact witness material and the validator fails closed when that basis drifts.

That is the biggest lesson Schell needs here.
A remembered approval may accelerate rerun or review, but it cannot mean “approve whatever now counts as the current version of this command, head, queue item, or workflow.”

## 2) SlopOS capability wallets are descriptive, not authority

`capability-wallet-schema-v0.md` is also exactly the right pressure.
CH-WALLET is a non-authoritative descriptor for prompts, receipts, explainability, and drift gates.
It carries digests and summaries, not bearer power.

Schell should copy that posture directly.
A replay lease can depend on a wallet-core digest or authority summary, but the summary itself should never become the grant.
A quiet-authority strip is descriptive evidence that a remembered basis still matched; it is not ambient power.

## 3) SlopOS learn mode stays observational only

`capshell-learnmode-posture-v0.md` refuses the most dangerous shortcut.
Learn mode may observe, summarize, and suggest, but it does not auto-widen, auto-edit, auto-request, or auto-rerun.

That matters directly for remembered shell comfort.
Palette hits, repair cards, captured-output rows, and assistant suggestions may feed replay-lease proposals, but they should not silently mint stronger remembered authority on their own.

## 4) SlopOS result-sidecar boundary keeps replay core small

`capshell-result-sidecar-boundary-v0.md` keeps richer result structure outside the replay-critical core.
That is a useful import for Schell too.
The replay-safe remembered object should stay compact:
exact basis, scope, drift conditions, and maybe retention class.
It does not need to absorb every UX flourish, support bundle, or result rendering story.

## 5) ViewFS and Steward keep the shell honest around reuse

ViewFS keeps repeating that live handles, reopens, restores, and durable history should not collapse into one flattering row.
That means a replay lease should remain distinct from recent rows, restored panes, imported transcripts, and search results.

Steward keeps insisting that labels, freshness, and trusted chrome matter.
That means quiet reuse should still surface a small strip saying what matched, which scope was used, and what can revoke or narrow it.
A shell that stays quiet with no visible reason quickly becomes harder to trust.

## 6) Companion-safe no-regret move

Schell does **not** need a general permission-memory subsystem next.
It only needs one bounded remembered-review object:

- exact basis packet ref,
- wallet-core or ground digest refs,
- explicit scope chip,
- explicit retention class,
- drift invalidation rules,
- quiet-authority strip on use,
- revoke / narrow / inspect actions,
- and restored-context downgrade by default.

That keeps the archive aligned with SlopOS while still stealing a genuinely delightful shell luxury.

## 7) Compact conclusion

The parent archive keeps teaching the same law:
**remembered review may accelerate an exact repeated act, but it must not become floating permission that follows mutable basis, restored context, or nearby suggestions.**

So the Schell-safe answer is not a generic approval cache.
It is a **replay lease**: shell-owned, descriptive at rest, exact-basis-bound, scope-shaped, drift-aware, and visibly consumed when quiet reuse occurs.
