# Research synthesis — 2026-03-21 pass XI

This pass keeps one design rule in view:
**the custom shell+terminal should become much better at getting the operator's attention without letting attention cues masquerade as completion truth, acknowledgement, or authority.**

The newest outside convergence is not just “notifications are nice.”
It is about four related truths:

- shell-emitted semantics make prompts, outputs, and command finishes safe to reason about,
- current terminals are getting better at bounded local cues such as prompt-safe click editing, readonly replay, and command-finish notification,
- mainstream platform notification systems keep interruption policy under system/user control rather than under payload control,
- and agent tooling keeps proving that convenience autonomy still needs explicit safety posture.

## Strongest current outside pressure

### 1) Shell-reported truth still buys the most

Windows Terminal, VS Code, WezTerm, Ghostty, and the old FinalTerm/iTerm2 lineage all reinforce the same base lesson:
the shell should emit prompt/command/output boundaries and related metadata directly instead of forcing the terminal to guess from scrollback.
That is what makes safer navigation, prompt actions, and trustworthy finish cues possible.

### 2) Command-finish notices are useful when they stay bounded

Ghostty now has explicit command-finish notifications with threshold and focus-aware settings.
WezTerm also supports notification escape routes.
These are great product ideas, but their honest interpretation is modest:
a long-running command appears to have finished and the terminal is surfacing a bounded notice.
That is not the same as “the result is good,” “the operator saw it,” or “the next step is approved.”

### 3) Prompt-safe interaction keeps winning

Ghostty's click-to-move-in-prompt feature again demonstrates the best pattern for rich terminal UX:
make the shell mark the active prompt, then let the terminal do delightful local things only inside that trusted active region.
That same pattern should govern attention cues.
A cue should point back to an exact shell-owned object rather than becoming its own authority source.

### 4) Notification systems keep interruption policy above payload policy

XDG's Notification portal is intentionally small and explicitly does not tell the sender whether the user actually saw the notification.
Android notification channels keep visual/auditory behavior on a per-channel basis and let users control which channels are intrusive or visible.
Apple keeps stronger interruption levels and critical alerts as separately privileged classes rather than making every notification payload equally strong.
The common lesson is excellent for Schell: senders can request attention, but the surface that presents it should stay policy-owned.

### 5) Agent convenience continues to need explicit safety posture

VS Code's current agent docs are a good cautionary signal.
Auto-approved terminal commands are only described as best-effort protection, and the safer path is sandboxing with clear presentation of what is running and why.
The broader lesson for Schell is that convenience shortcuts should ride on visible constraints, not invisible trust.
That applies to attention clicks just as much as to command execution.

### 6) Semantic history is still a good supporting idea

iTerm2 semantic history remains useful pressure in this pass too.
Per-line working-directory context makes contextual open and follow-up navigation smarter.
The move worth stealing is not “everything becomes clickable.”
It is “clicks should carry enough context to land on the right exact object without inventing new authority.”

## Best ideas worth stealing now

### Exact attention events

Schell should let the shell emit compact attention-worthy events bound to exact objects:

- review required,
- denial landed,
- long-running command finished,
- background residue changed,
- hold card now actionable.

### A tiny attention ladder

A very small ladder seems enough to start:

- `quiet` — never interrupt, just badge or shelf,
- `default` — visible in-lane,
- `noteworthy` — may surface outside the lane when policy allows,
- `urgent-hint` — request stronger interruption but still remain policy-gated.

### Threshold-based finish notices

The terminal should be able to surface “that slow command finished” only when the command exceeded a threshold, the lane is unfocused, or the operator explicitly asked to watch it.
That feels super awesome without turning every `echo ok` into alert spam.

### Attention residue instead of silent dropping

Suppressed or expired cues should not simply disappear.
A small residue shelf or ledger can preserve what was asked for, what was shown, and what was downgraded without claiming that the user saw or accepted it.

### Cue actions that route to exact objects

Clicking a cue should generally jump to the exact receipt, review card, hold card, or lane object it refers to.
Anything stronger should still pass through the same authorship/basis review discipline as if the operator had found that object manually.

## Moves that make the custom shell+terminal super awesome

### 1) Make “finished” useful but humble

A good finish cue should help the user get back to the right place quickly while still admitting that completion is not the same as approval, success, or reading.

### 2) Make denial and drift cues teach

A denial notice should take the user to the exact hold card or review surface that explains what is missing.
That is much better than a generic toast with no path forward.

### 3) Keep quiet mode honest

If the system suppressed or downgraded a cue because the operator is focused elsewhere or because the budget was spent, Schell should preserve that truth instead of pretending nothing happened.

### 4) Keep the attention system tiny

The archive should steal the best ideas from terminal products and notification platforms without committing to a whole notification-center product or a cross-device sync story.

## Current prototype reading

The next no-regret slice now looks like this:

1. **one exact attention-event schema tied to shell-owned objects,**
2. **one compact attention ladder,**
3. **one threshold-based finish-notice specimen,**
4. **one denial/drift cue that routes to a hold or review card,**
5. **and one residue shelf showing suppressed or expired cues honestly.**

That still leaves final renderer, notification backend, durable inbox/history, cross-device sync, and full policy algebra open.
That is exactly where Schell should stay.

## Reference pressure

- https://code.visualstudio.com/docs/terminal/shell-integration
- https://code.visualstudio.com/docs/copilot/agents/agent-tools
- https://code.visualstudio.com/updates/v1_109
- https://learn.microsoft.com/en-us/windows/terminal/tutorials/shell-integration
- https://ghostty.org/docs/install/release-notes/1-3-0
- https://ghostty.org/docs/config/reference
- https://wezterm.org/escape-sequences.html
- https://iterm2.com/documentation-one-page.html
- https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Notification.html
- https://developer.android.com/develop/ui/views/notifications/channels
- https://developer.apple.com/documentation/usernotifications/unnotificationinterruptionlevel
