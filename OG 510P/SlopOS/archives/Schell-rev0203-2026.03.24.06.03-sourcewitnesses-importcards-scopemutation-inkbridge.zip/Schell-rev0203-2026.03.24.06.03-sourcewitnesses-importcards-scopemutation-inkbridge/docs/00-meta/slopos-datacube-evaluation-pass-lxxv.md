# SlopOS datacube evaluation, pass LXXV (2026-03-22)

This pass evaluates one new companion import:
**Schell should absolutely grow recording ladders, search-posture badges, follow-versus-finished splits, and rerun-basis hold cards, but SlopOS pressure says casts, searchable transcripts, PTY captures, and live-follow streams must remain evidence-first artifacts rather than exact current basis, durable live state, or replay authority.**

## 1) SlopOS already gives the most important rule: evidence is not execution authority

The companion archive keeps repeating the same pattern in different families:
- approval binds one exact action, not a floating mutable head,
- acceptance receipts prove bounded admission rather than downstream completion,
- transient cues are not durable outcome truth,
- and observational sidecars must not redefine replay-critical identity.

That maps directly onto shell+terminal recording.
A cast, transcript search hit, or PTY log is valuable evidence.
It is not automatically:
- the exact basis for rerun,
- proof that current live state is still present,
- or authority to widen the old execution into a new one.

## 2) Approval-basis posture is the exact antidote to “rerun whatever this recording seems to show”

`approval-basis-posture-v0.md` says mutable basis must already be encoded into exact action bytes rather than left ambient as “latest”, “current”, or “whatever is there now”.
That is the right pressure for recorded terminal work too.
A beautiful transcript card or searchable cast can help derive a proposal.
It must not silently become an approval cache for rerunning against the current workspace, current binary, current host, current queue entry, or current remote endpoint.

## 3) Acceptance/completion posture prevents “follow mode” from becoming durable state fiction

`acp-acceptance-completion-posture-v0.md` says accepted requests and bounded effect metadata do not prove downstream completion or current provider-owned live state.
That maps perfectly onto followable replay.
A live-follow capture, tail-like cast stream, or in-progress session watcher may be extremely helpful.
It still cannot become the durable completion oracle for the shell+terminal.
If Schell wants durable completion or current owner truth, it must admit a separate explicit surface.

## 4) Attention durable-status posture keeps flashy capture chrome honest

`attention-durable-status-boundary-v0.md` freezes the rule that transient cues are not the durable carrier of consequential truth.
Recording UX needs the same law.
A “recording started”, “stream still live”, “search indexed”, or “session published” cue can help the operator notice something.
It should not be the only durable evidence that the capture completed, that redaction happened, or that publication/search visibility remains what the user thinks.

## 5) Capshell result-sidecar posture is a direct warning against letting rich recording metadata redefine canonical replay

`capshell-result-sidecar-boundary-v0.md` is especially relevant here.
It says richer named outputs or telemetry may exist, but they stay observational and separate from the replay-stable core.
For Schell, that means searchable transcripts, cast-side metadata, and fancy recording indexes should remain sidecars.
They may help discovery, debugging, and storytelling.
They must not silently replace the shell-owned canonical chapter basis or exact rerun packet.

## 6) The best SlopOS-compatible moves from this seam now look no-regret

The strongest companion-compatible moves are:
- **recording ladders** separating output-only / timed-output / chaptered / input-bearing / imported-I-O / live-follow,
- **search-posture badges** separating local-only / team-indexed / published-searchable / unknown,
- **rerun-basis hold cards** explaining why evidence is insufficient for exact rerun,
- **follow-versus-finished split cards** so live watch remains weaker than durable result truth,
- **digest-first cast manifests** that identify artifacts without making them authority tokens,
- **chapter-aware cast spines** that degrade honestly when recordings came from imported PTY capture rather than shell-known chapters,
- and **promotion ladders** that derive a fresh proposal instead of silently replaying a stale basis.

## 7) Things this pass still refuses to decide too early

This pass does **not** force:
- one final cast format,
- one final searchable-log backend,
- one final publication/indexing story,
- one final scrub/redaction engine,
- one final player/stream transport,
- or one final rerun-derivation contract.

The answer is smaller and stronger:
**treat recordings as evidence-first artifacts, keep searchable casts weaker than exact reviewed basis, keep live follow weaker than durable result truth, and derive fresh rerun proposals instead of letting old captures impersonate current execution authority.**
