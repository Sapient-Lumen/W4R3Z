# Research synthesis, pass XXXVIII (2026-03-21)

This pass focuses on one bounded seam that Schell did not yet give its own terminal surface:
**modern tools are increasingly able to notice local services, forwarded ports, and browser-worthy localhost URLs, which means Schell should steal the delightful parts without letting a visible dev-server link quietly become browser launch, tunnel management, or public exposure control.**

## 1) VS Code shows the delight ceiling clearly

VS Code's port-forwarding docs say support is built in via Microsoft dev tunnels with no extension required, and the Ports view can forward a port and then offer inline actions to copy the address, open it in the browser, or open an in-editor preview.
That is a great clue for Schell.
A service card can feel dramatically richer than a raw URL while still keeping action rungs separately named.

See: https://code.visualstudio.com/docs/debugtest/port-forwarding

## 2) VS Code's remote API shows the most important split

The remote-extension docs say `vscode.env.openExternal` does automatic localhost port forwarding, while `vscode.env.asExternalUri` exists for cases where you want forwarding **without actually launching a new browser window or application**.
That is an outstanding pattern.
Schell should steal exactly that separation.

The shell+terminal does not need a full browser subsystem to learn the lesson:
**derive/reveal the externally usable address and open it locally are different verbs.**

See: https://code.visualstudio.com/api/advanced-topics/remote-extensions

## 3) GitHub Codespaces shows how much current magic sits on terminal output

GitHub's docs say when an application running inside a codespace prints a localhost URL like `http://localhost:PORT` or `http://127.0.0.1:PORT` to the terminal, the port is automatically forwarded and the URL in the terminal is converted into a clickable link.
The same docs show that ports can be labeled, protocol can be switched, and copied addresses can be taken either as local addresses or externally reachable URLs.

That is powerful.
It is also exactly the seam where terminal text can quietly widen into a service-control plane.
Schell should keep the delight but attach it to explicit service witnesses instead of pretending a visible localhost string already implies a stable reachability story.

See: https://docs.github.com/en/codespaces/developing-in-a-codespace/forwarding-ports-in-your-codespace

## 4) Codespaces also shows that exposure is a separate truth plane

GitHub's security docs say all forwarded ports are private by default, require authentication for access, use auth cookies with a 3-hour expiry, and can become public or organization-visible only through a visibility choice.
They also note that public forwarded ports revert to private when removed/re-added or when the codespace restarts.

This is a terrific lesson for Schell.
A local service card should not tell the same story as a publicly reachable share link.
Exposure posture and browser-open posture are different facts.

See: https://docs.github.com/en/codespaces/reference/security-in-github-codespaces

## 5) OpenSSH preserves the older, still-important lesson: loopback is the safer default

The OpenSSH `ssh_config(5)` man page says `GatewayPorts` controls whether remote hosts may connect to local forwarded ports and that the default behavior is to bind local forwardings to the loopback address, preventing other remote hosts from connecting.

That is the exact old lesson Schell must keep learning from the past:
**a forwarded service is not automatically meant for everyone else.**
The default truth should be loopback-first, with wider exposure separately named and visibly stronger.

See: https://man7.org/linux/man-pages/man5/ssh_config.5.html

## 6) JetBrains remote development confirms the frontend-browser handoff pattern

JetBrains' security-model docs describe CLI commands like `idea openUrlOnClient http://localhost:$port` to forward a port from a remote machine and open the link in a browser on the frontend, and they also keep a separate Ports tab where ports can be added or removed.

Again the lesson is excellent for Schell:
remote service → frontend-local browser handoff is real operator value, but it still deserves its own named action rather than being hidden inside a generic localhost click.

See: https://www.jetbrains.com/help/idea/security-model.html

## 7) The no-regret import is visible now

A compact Schell import could be:
- one **service witness** object for exact local/remote/forwarded service truth,
- one explicit split between **copy local address**, **derive/reveal external address**, **open locally**, **preview locally**, **share privately**, and **share publicly**,
- one **exposure posture** family (`loopback-only`, `private`, `org-visible`, `public`, `unknown`),
- one **origin posture** family (`shell-known`, `workflow-known`, `detector-known`, `restored`, `imported`),
- and one restored/historical badge family for service cards and remembered URLs.

That is enough to learn a lot without choosing:
- a final tunnel backend,
- a final service-discovery protocol,
- a final browser-preview stack,
- or a final remote-service control plane.

## 8) The lesson we must learn from the past

The old mistake was to treat `localhost` as harmless local text.
The newer mistake would be to treat modern forwarded-port tooling as proof that browser open, local reachability, public share, and durable service identity are all the same state.

The better answer is:
- service discovery stays explicit,
- loopback stays weaker than public share,
- revealing an external URI stays weaker than opening it,
- opening it stays weaker than changing visibility,
- and historical service cards stay historical until they are repaired.
