# SlopOS datacube evaluation — pass CXLVII

This pass asks a narrower companion-safe question than “what clever shell features should Schell copy next?”
The better question is:
**how should Schell classify remembered, saved, restored, and provisional shell state so modern luxury never borrows the strength of live SlopOS truth?**

## 1) SlopOS keeps saying that live state is not the same thing as durable residue

Even while still in design phase, SlopOS repeatedly protects this distinction.
Its request-vs-live-state posture refuses to let a durable request or descriptor impersonate current provider-owned truth.
Its OpenURI boundary family refuses to let “launched,” “shown,” “recent,” or “picked before” collapse into completion or current-live-state truth.
Its safe-open and quarantine seams refuse to let preview, inspect, import, and stronger acts flatten into one fuzzy open story.

That is the direct companion lesson for Schell:
remembered, saved, restored, and provisional state can all be useful, but none should be allowed to quietly impersonate **live reviewed footing**.

## 2) The four soft-state families line up well with SlopOS exactness

A good Schell/SlopOS split now looks like this:

- **remembered** state helps find things again,
- **saved** state helps stage repeatable intent,
- **restored** state helps regain orientation,
- **provisional** state helps reduce latency and friction,
- but **live** state remains shell-owned and freshly asserted.

That is much more SlopOS-shaped than one giant “session continuity” myth.
It preserves exactness without throwing away delight.

## 3) Capshell pressure says soft state must stay weaker than exact reviewed launch footing

SlopOS capshell posture keeps refusing ambient PATH lookup, hidden shell parsing, portable PTY/job-control folklore, and inherited env/cwd/session magic.
That means Schell should be extremely careful about what its soft state can do by default.

Good companion answer:
- remembered rows may insert, inspect, or compare,
- saved artifacts may stage editable review,
- restored sessions may orient and offer rerun gates,
- provisional UI may comfort without claiming exact authority,
- and only a fresh reviewed launch should spend current capshell truth.

## 4) ViewFS, Steward, and Helm reinforce the same split

ViewFS keeps object classes separate.
That is exactly the right pressure here: remembered hits, saved artifacts, restored rooms, and provisional overlays should be different object classes rather than one comforting blob.

Steward keeps trusted chrome descriptive.
That means badges like remembered/saved/restored/provisional should be source-visible and claim-strength-visible, not just pretty labels.

Helm keeps launch/preview/endorsement discipline explicit.
That suggests saved workflows and launch kits should land in inspect/review surfaces before they become stronger action candidates.

## 5) What Schell should steal now

Schell should steal several excellent outside moves, but import them as soft-state families rather than as one final shell doctrine:

- per-peer remembered command/directory recall,
- filterable and explainable frecency,
- saved parameterized commands that land in editable input,
- saved launch configurations for project shapes,
- restored layouts and sessions with visible rerun gates,
- and provisional latency luxuries that stay visibly provisional.

## 6) What Schell should refuse now

Schell should refuse:

- remembered means rerun-ready,
- saved means still approved,
- restored means still live,
- provisional means close enough to exact truth,
- and one unified “smart session” object that silently combines all four.

## 7) Compact conclusion

The companion-safe answer is not to avoid luxury.
It is to **grade luxury by state class**.
If Schell keeps remembered, saved, restored, provisional, and live states distinct — with explicit route ladders and trusted chrome — it can become dramatically better than shell folklore while staying aligned with SlopOS discipline even before SlopOS itself finishes designing all of its adjacent surfaces.
