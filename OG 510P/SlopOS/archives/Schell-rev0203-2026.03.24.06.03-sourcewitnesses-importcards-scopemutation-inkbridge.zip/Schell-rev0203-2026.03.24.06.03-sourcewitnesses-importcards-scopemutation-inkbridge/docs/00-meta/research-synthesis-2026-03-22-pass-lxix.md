# Research synthesis, pass LXIX (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should absolutely steal explicit nondeterminism lanes — cryptographic random, insecure per-process seed material, deterministic replay/test providers, and reproducibility rails — but only if fresh randomness, seed hints, replay captures, and historical receipts stay separately named instead of collapsing into one flattering “the shell can just rerun this” story.**

This seam matters because old shells still treat randomness as strangely ambient.
A command reaches for `/dev/urandom`, `getrandom()`, hash-map seeds, UUID helpers, fuzz inputs, or build timestamps without the operator seeing any of that in the review surface.
When a flaky test flips, a generated identifier changes, or a replay stops being exact, the operator ends up reverse-engineering host RNG state, deterministic-mode flags, and timestamp overrides after the fact.
That is exactly the sort of shell+terminal seam Schell can improve without choosing one final RNG provider, replay store, or cross-platform entropy ontology.

## 1) Current WASI already treats random sources as separate authorities

The current WASI Random docs are an unusually clean clue.
They separate:
- `insecure-seed` for one-time hash-map DoS seeding,
- `insecure` random for non-cryptographic pseudo-random bytes,
- and `random` for cryptographically secure fresh randomness.

They also say deterministic environments must **omit** the secure `random` interface rather than quietly implement it with deterministic bytes.
The current WASI CLI world imports terminal handles, filesystem, clocks, networking, and random interfaces separately.
That maps beautifully into Schell.
A shell+terminal can make nondeterminism visible without pretending every command lives in one universal host-RNG story.
See: https://wa.dev/wasi%3Arandom and https://wa.dev/wasi%3Acli

## 2) OpenBSD proves the seed-material split is both real and useful

The current OpenBSD `getentropy(2)` docs say the call is for high-quality entropy, cap the buffer at 256 bytes, and explicitly say ordinary code should use `arc4random(3)` instead.
The current `arc4random(3)` docs say it is reseeded from the kernel `random(4)` subsystem using `getentropy(2)` and that `arc4random_uniform()` should be preferred over modulo arithmetic to avoid bias.
That gives Schell another excellent lesson.
The shell does not need one generic “randomness” badge.
It needs room for:
- seed-material posture,
- local CSPRNG posture,
- and helper APIs whose quality and replay meaning differ.
See: https://man.openbsd.org/getentropy and https://man.openbsd.org/arc4random

## 3) Linux proves initialization, source choice, and scale all matter

The current Linux `getrandom(2)` docs say small reads up to 256 bytes from the default urandom source will, once initialized, return the requested bytes and avoid signal interruption semantics that larger reads may face.
They also say the call can block before initialization unless `GRND_NONBLOCK` is used.
The current `random(7)` docs sharpen the operator lesson:
- most callers should prefer the urandom source or `getrandom()` without `GRND_RANDOM`,
- `GRND_RANDOM` is usually the wrong choice,
- and Monte Carlo / probabilistic sampling should seed a user-space PRNG rather than consume large quantities of kernel CSPRNG output directly.
That is exactly the shape Schell should steal.
The shell review surface should distinguish fresh crypto randomness, seed-only posture, and probabilistic-sampling posture instead of flattening them into one ambient source myth.
See: https://man7.org/linux/man-pages/man2/getrandom.2.html and https://man7.org/linux/man-pages/man7/random.7.html

## 4) Reproducible-builds work proves deterministic time/seed posture should be explicit env truth

The current `SOURCE_DATE_EPOCH` specification says the variable must be exported through the normal environment mechanism, must be reproducible across executions based only on source, and must be used for embedded timestamps instead of “current” time.
It also says formatting should be deferred until runtime if end users should see the value in their own locale/timezone.
That is a perfect Schell lesson.
If a command is entering a reproducibility lane, that should be an explicit reviewed insertion or policy card — not a mysterious shell-side toggle that silently mutates build meaning.
See: https://reproducible-builds.org/specs/source-date-epoch/

## 5) The dangerous flattenings to refuse

The current ecosystem keeps inviting at least seven mistakes:
- treating cryptographic freshness and deterministic replay as if they were the same lane,
- treating one-time seed material and long-lived random streams as identical,
- treating hash-DoS seeds, UUID convenience, and crypto key material as one badge,
- treating ambient `/dev/urandom` or `getrandom()` reachability as the portable Schell baseline,
- treating a replay receipt as proof that current random state still exists,
- treating deterministic-mode helpers like `SOURCE_DATE_EPOCH` as shell magic rather than explicit reviewed env posture,
- and treating historical entropy facts as if they could safely reveal raw seed bytes.

Schell should refuse those moves.
A command should be able to say, separately:
- what nondeterminism lane it depends on,
- whether that lane is fresh, deterministic, insecure, or seed-only,
- whether replay requires captured events or declared seed posture,
- and what bounded historical receipt can honestly be emitted afterward.

## 6) The stealable move: nondeterminism witnesses, seed lanes, and replay humility

The best decision-light move now looks like this:
1. add a **nondeterminism witness** family for reviewed launch posture,
2. distinguish **fresh crypto randomness** from **seed material**,
3. distinguish **insecure or DoS-resistance seed posture** from **crypto posture**,
4. distinguish **deterministic replay/test lanes** from **fresh random lanes**,
5. keep **raw seed bytes** out of transcript/history/receipt surfaces,
6. offer **repro rails** such as reviewed deterministic env insertions when the tool advertises them,
7. and refuse to standardize one giant cross-platform RNG or replay ontology too early.

That would make Schell feel dramatically more capable while preserving the archive's current decision throttle.

## 7) A compact first proving slice

A compact proof could show:
- one reviewed launch card with explicit nondeterminism lane badge,
- one seed witness that says seed-only / crypto-fresh / insecure-seed / deterministic-replay / ambient-compat / unknown,
- one replay chip that confesses whether exact replay is possible, capture-required, or forbidden,
- one explicit reproducibility rail that offers reviewed `SOURCE_DATE_EPOCH` or tool-specific deterministic mode insertion rather than shell magic,
- one refusal to persist raw seed bytes in transcript/history/clipboard surfaces,
- one historical receipt with bounded randomness facts and claim-strength posture,
- and one refusal to treat a stale receipt as current live entropy truth.

That is enough to make Schell feel super awesome at nondeterminism truth without freezing the final portal, RNG backend, replay substrate, or seed-handling policy.

## 8) Decisions intentionally kept open

This pass does **not** freeze:
- one universal entropy schema for every host/runtime,
- one final CSPRNG or randomness provider backend,
- one universal deterministic-mode contract across all tools,
- one final replay/event-capture substrate,
- one universal seed-receipt or provenance schema,
- or one final policy for how helpers discover tool-specific reproducibility knobs.

The no-regret move is smaller:
**steal reviewed nondeterminism lanes, explicit seed posture, and replay humility — but keep fresh randomness, deterministic/test providers, insecure seeds, reproducibility env rails, and historical receipts visibly separate.**
