# Research synthesis, pass XXX (2026-03-21)

This pass keeps one design rule in focus:
**the custom shell+terminal should get much smarter through explicit enrichment lanes, not through hidden speculation, hidden helper execution, or stale local caches pretending to be truth.**

The current ecosystem is surprisingly aligned here.
Modern tools get delight from shell-known prompt and command boundaries, editable recall, focused help, and richer display rows.
But the same tools also show the traps: trusted rerun is narrower than visible history, transcripts are weaker than live truth, and restored or cached material can look dangerously current.

## 1) Shell-known boundaries remain the strongest source of humane terminal UX

VS Code's terminal shell integration uses shell-reported data for command detection, command navigation, run-recent-command, recent directories, and current-working-directory-aware link resolution.
Ghostty 1.3 extends OSC 133 prompt semantics enough to let operators click within an active prompt and move the cursor like a normal text field.
The clue for Schell is simple:
**great shell+terminal UX should start from shell-known chapters and active-input truth, not from regex archaeology or renderer guesswork.**

## 2) Rich display should stay separate from inserted value

Nushell 0.111.0 explicitly separates the inserted value from the display value via `display_override`.
That is a brilliant move worth stealing.
A row can be visually rich, color-coded, or annotated without changing what lands in the buffer.
Schell should generalize that rule across completion rows, history hits, workflow seeds, object references, and semantic-link cards.

## 3) Focused help should bind to the current slot, not to a second help universe

PowerShell's dynamic help keeps help close to the live command line.
`Alt+h` shows focused parameter help below the current command line, and `F1` can show full cmdlet help without discarding the current edit position.
That is exactly the kind of move Schell should copy:
**help should enrich current review, not teleport the operator into a separate wizard.**

## 4) Reusable commands are best when they land as editable artifacts first

Warp workflows are saved from blocks, palette entry points, or agent results, and then open into an editor where the operator can name the workflow, edit the command and arguments, and define parameters.
This is important.
The system is helping the operator remember and reshape a command, not quietly running a remembered action.
Schell should keep stealing that insert/edit-first posture.

## 5) Semantic links get much better when cwd and chapter context are known

VS Code improves link resolution when the shell reports the current working directory instead of forcing regex or polling heuristics.
Likewise, iTerm2's semantic history tracks the working directory for each line to help it find files when the user Cmd-clicks.
The import is strong:
**semantic links should be chapter-aware and cwd-aware, but the richer resolution logic should still remain weaker than explicit object selection or exact reveal.**

## 6) Session resurrection is real value, but it creates fake-liveness risk

Zellij serializes session data into human-readable layouts that can later be examined, altered, shared, and reloaded.
That is useful, but it also shows the danger.
Restored layouts and restored scrollback can look current even when they are not.
Schell should therefore keep restoration visibly historical until fresh shell truth is reacquired.

## 7) Transcript capture is evidence, not omniscient truth

Microsoft's transcript limitations doc shows that PowerShell transcripts can record output out of order or miss output depending on how host-vs-stream output and formatting timing interact.
That is a valuable warning for Schell.
A transcript, replay bundle, or exported chapter can be extremely helpful while still remaining weaker than current live state.

## 8) The oldest text-interface ideas are still worth stealing

Plan 9's plumber is still one of the best historical examples of user-level message dispatch between programs.
Acme still teaches that text can be the user interface instead of merely a transport hidden underneath widgets.
Oil/YSH's critique of Bourne-style quoting and splitting is another historical lesson: hidden expansion rules create decades of confusion.
Taken together, the lesson is:
**make smart actions explicit, textual, and inspectable; do not hide interpretation inside flattering convenience.**

## 9) A good Schell import now looks like “enrichment packets”

A bounded answer is to let the shell+terminal exchange or derive compact **enrichment packets** for things like:
- completion rows,
- focused parameter help,
- semantic-link candidates,
- workflow/history summon rows,
- object metadata hints,
- and safe preview snippets.

Each packet should probably carry at least:
- `source_kind` — shell-static / shell-witnessed / cached-local / live-local / remote / agent,
- `freshness_grade` — static / cached / live / historical,
- `display_value` versus `insert_value`,
- `cost_grade` — free / local-io / local-exec / remote-read,
- and one explicit `refresh` or `materialize` step when stronger acquisition would do more work.

That keeps the terminal brilliant without requiring it to pretend every nice-looking card came from one live authoritative source.

## 10) The super-awesome move is restraint with explicit affordances

The custom shell+terminal gets super awesome when it:
- remembers and summons intelligently,
- resolves links and objects contextually,
- keeps help attached to the current edit,
- lets visible rows be richer than inserted text,
- and gives one explicit refresh/materialize step for stronger enrichment.

The custom shell+terminal gets dangerous when it:
- runs generators just because a menu opened,
- prefetches or previews because the cursor hovered,
- treats restored or cached data as live by default,
- or lets beautiful cards bypass fresh review.

## 11) Decisions intentionally kept open

This pass still does **not** freeze:
- one shell-integration protocol,
- one enrichment storage/cache backend,
- one preview engine,
- one workflow store,
- one sync model,
- one session-resurrection backend,
- or one plugin/completion runtime.

The no-regret move is smaller:
**name enrichment as a first-class but non-authoritative lane, badge it for source/freshness/cost, and keep stronger acquisition as an explicit second step.**
