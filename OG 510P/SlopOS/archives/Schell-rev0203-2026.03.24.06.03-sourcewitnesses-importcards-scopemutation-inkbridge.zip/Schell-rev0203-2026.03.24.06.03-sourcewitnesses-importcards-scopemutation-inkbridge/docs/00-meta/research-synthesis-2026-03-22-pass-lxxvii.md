# Research synthesis, pass LXXVII (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should steal room invites, read-only joins, host-only escalation, participant approval, selected-part publication, and exclusive write turns from current collaboration tools — but it should keep room identity, participant identity, authorship, audience, and adjacent powers separate so “someone joined the terminal” never impersonates “we know who typed this, who saw it, what else they could do, or what became public.”**

This seam matters because the current ecosystem now offers several distinct but adjacent collaboration moves:
- persistent shared terminal rooms,
- read-only versus read-write terminal joins,
- approved signed guests versus weaker anonymous guests,
- browser viewers and terminal viewers,
- file transfer and shared port access next to terminal access,
- and published command/output artifacts that can outlive the live room.

All of those are useful.
They also create one recurring trust failure:
operators can stop knowing whether a participant is merely present, allowed to type, allowed to move files, allowed to reach a forwarded service, or only holding a public link to a finished artifact.
The no-regret move is not to avoid social terminal features.
It is to give them a much more explicit truth surface.

## 1) Live Share proves that good collaboration starts with host control, guest approval, and separate authority knobs

Current Live Share docs say hosts can require guest approval, anonymous guests are weaker than signed-in guests, terminals can be read-only or read/write, only hosts can start shared terminals, and guests cannot choose which host ports get shared.
Live Share also warns that co-debugging lets guests run console/REPL commands and that shared ports behave like localhost on the guest machine, so hosts should be selective about what they share.
That is a strong import for Schell.
A good room model should keep **join approval**, **terminal input**, **shared-port reachability**, and **debugging or console power** as separately named authorities instead of one flattering “collaboration session” badge.
See: https://learn.microsoft.com/en-us/visualstudio/liveshare/reference/security and https://learn.microsoft.com/en-us/visualstudio/liveshare/use/share-server-visual-studio

## 2) Upterm teaches the right adjacent-power lesson: terminal sharing often widens into file-transfer authority unless you name it explicitly

Current `upterm-host(1)` docs say hosts can require authorized keys, accept or deny clients manually, make sessions read-only, and disable SFTP/SCP.
They also say that by default clients can transfer files with the same access as the terminal session, while read-only mode restricts SFTP to download-only.
That is gold for Schell.
“Can view terminal output”, “can type”, “can upload/download files”, and “can reconnect later” are different authorities.
A collaboration room should show them as separate rungs, not as side-effects of one share link.
See: https://man.archlinux.org/man/upterm-host.1.en

## 3) GNU Screen still has one of the best old lessons: shared rooms need ACLs *and* explicit write turns

Current Screen multiuser docs expose ACL commands and a `writelock` mode.
The `writelock` docs say exclusive input can be granted to one participant for a window, automatically or explicitly.
That is a remarkably modern lesson hiding in an older tool.
The best collaborative terminal is not necessarily one where everyone co-types all the time.
Often the right move is a **room with a visible writer token**.
Schell should steal that.
Shared presence, annotation, view, request-to-drive, granted drive, and exclusive writer should stay separate.
See: https://www.gnu.org/software/screen/manual/html_node/Multiuser-Session.html and https://www.gnu.org/software/screen/manual/html_node/Writelock.html

## 4) tmate proves the value and the risk of room identity surviving the current client

Current `tmate(1)` docs describe a persistent shared session that can survive accidental disconnection, be reattached later, allow several teammates, and use a randomly-generated token to join.
That is a useful pattern for Schell, but it carries a truth obligation.
A room token or reattach handle is not participant identity, not proof of continued audience membership, and not proof of who authored later command chapters after reconnect.
So Schell should keep **room handle**, **participant roster**, **join proof strength**, and **chapter authorship** separate.
See: https://manpages.ubuntu.com/manpages/noble/man1/tmate.1.html

## 5) Browser-sharing tools keep proving that transport and audience posture matter more than the pretty terminal frame

Current GoTTY docs say remote input is dangerous, credentials are plain text unless stronger TLS modes are used, traffic is not encrypted by default, and sharing one live terminal with multiple clients usually requires a multiplexer such as tmux.
Current `ttyd` docs add richer browser-terminal features such as TLS and file transfer support.
The design lesson is not “use or reject browser sharing.”
It is: the room surface must say whether the audience is browser-only or terminal-native, whether input is allowed, whether traffic is encrypted, whether the object is one real shared process or per-client process illusion, and whether transfer features widened the room.
See: https://github.com/yudai/gotty and https://github.com/tsl0922/ttyd

## 6) Warp shows the difference between finished-room artifacts and live-room truth

Current Warp block-sharing docs say sharing is explicitly opt-in, lets the user choose which parts of a block to share, and produces links or embeds that are currently accessible to anyone with the link.
That is a great idea.
It is also an important warning.
A shared finished block is not the same thing as a participant in a live room.
Schell should keep **live audience**, **published audience**, **selected included parts**, and **unpublish or revoke posture** separate from room presence.
See: https://docs.warp.dev/terminal/blocks/block-sharing

## 7) The strongest super-awesome moves are clearer now

The highest-value moves worth stealing from this seam are:
1. **room cards** with room handle, live/historical state, join method, audience posture, and adjacent-power summary,
2. **participant cards** that say host / approved signed guest / approved anonymous guest / imported link-holder / historical viewer,
3. **authorship chips** on command chapters so the room never erases who typed, approved, or observed,
4. **writer-token lanes** for exclusive or leased input instead of ambient co-typing,
5. **adjacent-power strips** separating terminal input, file transfer, shared localhost/service reachability, debugging/console power, clipboard/host effect, and publication power,
6. **audience ladders** distinguishing one approved participant, named roster, team room, anyone-with-link artifact, and public embed,
7. **room-versus-artifact receipts** so a published command block does not impersonate a current participant roster,
8. **roster truth weaker than viewed-by truth** unless the system has explicit read receipts,
9. and **historical badges** for reattached or restored rooms so old room identity does not impersonate current live authorship.

## 8) What Schell should absolutely refuse

Schell should refuse:
- one generic “share terminal” action that silently bundles terminal input, file transfer, service access, and publication,
- treating a room token, invite link, or reconnect handle as strong participant identity,
- treating “joined the room” as proof a participant saw a particular chapter,
- letting live-room presence and published artifact visibility collapse into the same audience model,
- and erasing chapter authorship just because several people were present.

## 9) Decisions intentionally kept open

This pass does **not** freeze:
- one final collaboration backend or relay transport,
- one final room-sync or roster protocol,
- one final browser-share stack,
- one final read-receipt or participant-identity model,
- one final author-signing format,
- or one final publication backend.

The no-regret move is smaller:
**give Schell room cards, participant cards, authorship chips, audience ladders, writer tokens, and adjacent-power strips so collaboration can become luxurious without letting room presence, publication, and authorship collapse into one vague myth.**
