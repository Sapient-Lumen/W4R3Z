# Research synthesis, pass CXXIII (2026-03-22)

This pass keeps one narrower lesson explicit:
**important terminal modes should be treated as temporary leases with cleanup and repair posture, not as ambient terminal facts.**

The current ecosystem is converging on that lesson from multiple directions.
`xterm` still documents DEC private modes for things like focus reporting and bracketed paste, and it also documents explicit save/restore of DEC private mode values.
kitty goes a step further by extending save/restore so applications can restore all side-effect-free modes without enumerating them.
Contour's synchronized-output docs make the truth problem especially vivid: the emulator may continue processing incoming text and control sequences while still rendering the previously drawn state until synchronization is disabled.
tmux keeps passthrough, alternate screen, title changes, and cursor styling under explicit pane options rather than treating them as one natural constant.
Ghostty's docs also show that some mode-adjacent queries are risky enough to disable by default, while bracketed paste safety remains an explicit policy choice.

Taken together, the design-phase lesson for Schell is clear:

## 1) Mode state is real but not authoritative

A mode can absolutely matter for:
- prompt-local cursor movement,
- paste handling,
- click behavior,
- smooth full-screen redraw,
- title/query behavior,
- and local rendering posture.

But none of that means the mode should quietly become shell truth, command completion proof, or approval-bearing footing.

## 2) Save/restore posture deserves its own witness

There is a meaningful difference between:
- a shell-fresh baseline,
- a foreground program that set a mode,
- a mode with explicit save/restore evidence,
- a mode that was merely inherited,
- and a mode that looks stranded after a crash, hop change, or relay loss.

A single “shell integration works” badge is too weak for that reality.

## 3) Synchronized rendering is not transcript truth

Contour's synchronized-output behavior is especially valuable as a past lesson.
If the terminal may keep processing text and sequences while still displaying the old rendered state, then Schell should explicitly separate:
- processed state,
- rendered state,
- prompt return,
- and receipt-worthy completion.

That is a very good humility rail for any future polished shell+terminal.

## 4) Steal lease-shaped mode cards, not one giant reset myth

The good product move is not to invent a giant terminal-state bureaucracy.
It is to add:
- compact mode chips,
- save/restore posture,
- relay/loss confession,
- stranded-toggle detection,
- and named repair moves such as baseline reassertion versus hard reset.

That would make Schell feel smarter and safer at the same time.

## 5) Compact answer

Schell does **not** need one universal terminal-mode treaty yet.
It needs one bounded move:
- important mode leases,
- save/restore posture,
- freshness and relay badges,
- stranded-toggle repair cards,
- and a rule that borrowed terminal state stays weaker than shell-owned truth.
