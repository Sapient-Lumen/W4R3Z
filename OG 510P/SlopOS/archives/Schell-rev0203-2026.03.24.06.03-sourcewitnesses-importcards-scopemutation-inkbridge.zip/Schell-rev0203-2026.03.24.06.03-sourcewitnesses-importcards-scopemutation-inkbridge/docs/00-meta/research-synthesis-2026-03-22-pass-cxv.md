# Research synthesis, pass CXV (2026-03-22)

This pass keeps one narrower lesson explicit:
**Schell should make command recall, recent directories, and semantic-history comfort peer-scoped and footing-aware rather than flattening everything into one global history stream.**

The outside ecosystem is more aligned here than it first appears.
iTerm2 stores command history separately for each username+hostname combination and keeps recent directories on the same split.
Atuin records directory, time, duration, exit code, hostname+user, and session.
VS Code uses shell-reported cwd for command-local features like recent-command surfaces and cwd-aware link resolution.
Warp’s block model treats copy/re-input/bookmark/share as command-frame operations instead of one giant scrollback myth.
Together these point to a very good Schell move:
**memory should be partitioned by footing, not just searched more cleverly.**

## 1) The past mistake to avoid is monolithic memory

Classic shells keep command memory too flat.
Once richer shell+terminal comfort arrives, that flatness becomes dangerous.
A remote command can appear locally “familiar.”
A privileged command can appear context-free.
A restored command can look current.
A synced memory row can look firsthand.

Schell should therefore treat at least these as different memory objects:
- local recent line,
- peer-scoped command frame,
- recent directory,
- restored historical command,
- imported or synced command,
- and staged retry proposal.

## 2) iTerm2 remains one of the clearest specimens

The iTerm2 shell-integration docs are especially useful here.
They say command history is stored separately for each username+hostname combination.
They also keep recent directories on that same peer-sensitive footing.

That is a much better default than one universal “up arrow” story.
Schell should steal the rule, not merely the UI.

## 3) Atuin proves richer memory is really about footing metadata

Atuin’s docs explicitly say it records command text plus directory, time, duration, exit code, hostname+user, and session.
That is a strong reminder that good history is not only retrieval.
It is retrieval with context.

Schell should not necessarily copy Atuin’s storage or sync model.
But it should copy the lesson that recall improves when the system knows:
- where the command ran,
- on which peer,
- in which session,
- and with what outcome.

## 4) VS Code and semantic link resolution show why cwd belongs in memory

VS Code’s shell integration uses shell-reported cwd not only for display but also for command-local features like run-recent-command and cwd-aware link resolution.
That is a subtle but important product clue.

The shell+terminal becomes dramatically more useful when paths, recent commands, and command-local actions inherit the cwd that was true when that command frame existed.
That is much better than pretending the current cwd always explains old output.

## 5) Warp’s block model shows how memory can stay command-shaped

Warp’s current docs keep emphasizing that a block groups command and output into one atomic unit and then enables copy command, copy output, re-input, bookmark, and share.
That is a very stealable idea.

Schell should therefore prefer command-frame memory where it has shell-attested boundaries.
A command frame is a better memory object than a bare line because it can carry:
- peer identity,
- cwd witness,
- exit status,
- output handle,
- timestamps,
- and lane posture.

## 6) This suggests a strong no-regret Schell move

Schell should probably add a compact recall-partition witness or equivalent story with fields like:
- peer partition,
- cwd partition,
- lane kind,
- authority-drift posture,
- freshness/import posture,
- and ranking posture.

That would let the shell+terminal support much better:
- per-peer recent command search,
- recent directories by peer,
- cwd-aware output actions,
- stage-before-rerun cards,
- and imported/restored memory badges.

## 7) The crucial honesty rule is authority drift

The most important added discipline is not merely host awareness.
It is **drift awareness**.

A remembered command frame should say when:
- the peer changed,
- the cwd changed,
- the lane changed,
- the authority wallet drifted,
- the command came from restore/import/sync,
- or the original route is no longer current.

This is one of the easiest ways to make Schell feel advanced without silently widening power.

## 8) Compact design-phase answer

Schell does **not** need to freeze one final history DB, sync backend, ranking engine, or launch cockpit.
It only needs a bounded move:
- partition recall by peer and cwd,
- keep recent directories inside that same story,
- prefer shell-attested command-frame memory when available,
- show footing drift before stronger reuse,
- and keep imported/restored memory visibly weaker than fresh local review.

That is enough to make command recall and project re-entry feel much more magical while staying honest about authority and freshness.
