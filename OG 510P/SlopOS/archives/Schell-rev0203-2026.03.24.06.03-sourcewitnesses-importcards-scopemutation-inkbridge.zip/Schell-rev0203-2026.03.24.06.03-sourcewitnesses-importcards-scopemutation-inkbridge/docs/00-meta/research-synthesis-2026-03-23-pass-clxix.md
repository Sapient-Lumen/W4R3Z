# Research synthesis — 2026-03-23 — pass CLXIX

This pass sharpens one fresh lesson from current terminal docs:
**nearby spawn comfort is getting better, but the inherited footing is usually fieldwise, partial, or host-mediated rather than a fresh exact launch.**

## 1) Ghostty now exposes independent cwd inheritance controls for window, tab, and split

Ghostty 1.3.0 added separate `window-inherit-working-directory`, `tab-inherit-working-directory`, and `split-inherit-working-directory` controls.
That is a very good clue for Schell.
Users do not really want one vague “same context” toggle.
They want inheritance behavior that can differ by action class.

## 2) Windows Terminal makes duplicate comfort explicit and partial

Windows Terminal documents that `duplicateTab` copies the current tab's profile and directory, and `splitPane` in duplicate mode does the same for panes.
But the same docs also say `duplicateTab` does **not** include modified or added environment variables.
Its command-line docs also expose `--inheritEnvironment`, which reinforces that env carryover is its own decision.

That is exactly the honesty Schell should steal.
“Duplicate” is not “all footing followed.”

## 3) VS Code keeps cwd, inherited env, and automation profile as separate knobs

VS Code's terminal docs keep launch-context controls separated:
- `terminal.integrated.splitCwd`,
- `terminal.integrated.inheritEnv`,
- and `terminal.integrated.automationProfile.{platform}`.

Its advanced docs also say environment changes contributed by extensions may require a relaunch, with a hover explaining the change and a relaunch button.
That is a gift.
It suggests Schell should make context changes and relaunch consequences inspectable rather than ambient.

## 4) WezTerm keeps launch structure and domain structure explicit

WezTerm's `SpawnCommand` carries explicit launch fields including `cwd`, and its multiplexing docs distinguish spawning in the default local domain, the current tab's domain, or a specific domain.
That means same-directory and same-domain are related but not identical truths.
This again points Schell toward fieldwise inherit diffs instead of one “open nearby” myth.

## 5) kitty is unusually clear about clone strength and clone limits

kitty's `launch --copy-env` docs say the copied env only reflects the environment from when the source window was first created because updated environment variables cannot be recovered from arbitrary processes.
The `clone-in-kitty` docs go further: cloning works by asking the shell to serialize internal state, mainly cwd and env vars, and the docs note that environment variables can cause arbitrary code to be sourced in the cloned window.

That is luxurious and sharp.
It is also a warning.
Shell-state clone is not the same thing as fresh exact launch, and cloned state may need stronger confession before execution.

## 6) fish keeps teaching freshness over remembered pane state

fish 4.5.0 now reports the working directory on every fresh prompt via OSC 7, specifically to avoid stale cwd after child processes such as `ssh`.
That is a very strong clue for Schell:
when convenience spawn depends on current context, fresh prompt-time witness beats remembered pane folklore.

## 7) The no-regret Schell move is a same-context launch sheet

Putting these sources together suggests a much better next step than inventing a giant launcher architecture.
Schell should add a small **same-context launch sheet** for high-value convenience spawns.
The sheet should show:
- requested action,
- source anchor,
- per-lane inheritance for cwd/domain/profile/env/activation,
- exact / reported / remembered / dropped / defaulted / policy-trimmed posture,
- a compact inherit diff,
- and a **fresh instead** alternative that is just as cheap to choose.

## 8) Compact conclusion

Ghostty proves inheritance defaults should differ by action.
Windows Terminal proves duplicate comfort can still be partial.
VS Code proves cwd/env/profile choices belong to separate knobs and that relaunch-worthy env drift should be inspectable.
WezTerm proves launch objects and domain choice should stay explicit.
kitty proves clone luxuries are powerful, host-mediated, and sometimes code-bearing.
fish proves fresh prompt witnesses beat remembered pane state.

So the next no-regret Schell seam is not “more cloning.”
It is **launch sheets with inherit diffs, exact fallback reasons, and fresh-instead parity** so nearby spawn gets much better without pretending inherited convenience is the same thing as fresh exact reviewed footing.
