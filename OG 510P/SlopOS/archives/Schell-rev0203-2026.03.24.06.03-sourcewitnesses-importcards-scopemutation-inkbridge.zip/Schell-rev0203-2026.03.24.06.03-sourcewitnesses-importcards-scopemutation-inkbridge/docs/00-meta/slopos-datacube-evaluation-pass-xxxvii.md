# SlopOS datacube evaluation, pass XXXVII

This pass keeps one bounded thesis in focus:
**SlopOS keeps insisting that transfer is explicit, that copy is not the same thing as delivery, and that desktop-helper clipboard folklore must not become the reviewed authority plane. Schell should import that directly for terminal copy, clipboard export, and remote-local copy behavior.**

This is another very good import point because SlopOS is still design-phase too.
The lesson is strong without forcing Schell to freeze a clipboard backend or a secure-pasteboard architecture.

## 1) D-PLUMB transfer posture gives Schell the right verb split immediately

The transfer-portal posture says there are no ambient clipboard readers, watchers, or history constructors.
It also says **copy publishes an offer; sink action grants delivery**.
Cross-component delivery happens only when a sink performs an explicit paste/drop/share action, and cross-boundary transfer is one-shot/short-lived and auto-clear by default.

That maps beautifully onto Schell.
A terminal copy should not quietly mean:
- the system clipboard definitely changed,
- every future paste target now has ambient access,
- or a hidden clipboard history service has durably absorbed the material.

Schell should steal the exact sentence-level lesson:
**copy offer ≠ delivery grant.**

## 2) SlopOS refuses ambient clipboard mythology in exactly the way Schell needs

The same transfer posture explicitly rejects background clipboard observation and clipboard-history enumeration.
That is unusually important for a custom shell+terminal, because the product temptation will be to treat copy history as harmless operator delight.

SlopOS's pressure is sharper:
clipboard and transfer are a boundary.
They are not a free global recall substrate.

For Schell this suggests:
- local copy packs may exist,
- restored copy offers may exist,
- but ambient clipboard snooping or silent history construction should not become baseline truth.

## 3) MicroVM clipboard posture is a warning against helper folklore becoming policy

The MicroVM clipboard/drag-drop posture says there is no portable ambient host↔guest clipboard/drag/drop integration contract and no portable shared-clipboard / drag-drop / guest-tools file-transfer plane.
Owner-local desktop-helper integration remains implementation-local.
Explicit D-PLUMB transfer seams remain authoritative.

That transfers directly to Schell.
Even if one terminal, one mux, or one host stack can bridge clipboards conveniently, that should not become the archive's portable semantic center.
The reviewed meaning should live in Schell's own copy/export witnesses, not in emulator folklore.

## 4) Capture posture reinforces the “no widening by implication” rule

The capture-portal posture says there is **no clipboard/remote-control widening by implication**.
That is a small sentence with a lot of value.

Schell should import the same discipline:
- selecting output does not imply external clipboard mutation,
- copying locally does not imply remote-local bridge permission,
- and clipboard write does not imply durable share/export authority.

That is exactly the sort of adjacent-workflow separation SlopOS keeps getting right.

## 5) Sensitive transfer and redaction-first posture matter for terminal copy too

The transfer posture keeps sensitive transfer metadata redaction-first and says strict profiles may refuse to export sensitive descriptors entirely.
That is a strong hint for Schell.
Some copy offers should stay narrow.
Some should expire quickly.
Some should avoid durable transcript/share lanes.

A secret-bearing terminal selection is not the same thing as a harmless copied filename.
SlopOS is telling Schell not to flatten those cases away.

## 6) The strongest import is small and practical

Schell does not need a giant clipboard service to learn from SlopOS here.
It needs:
- one **clipboard witness** family,
- one **copy-offer** posture weaker than delivery,
- one explicit split between local copy pack, system clipboard write, remote-local bridge, and share/export,
- one **sensitive / one-shot / clear-on-use** posture,
- and one refusal to let background clipboard history or helper-side sync become ambient shell truth.

That is enough to make copy feel dramatically better while keeping architecture choices open.

## 7) This is another path to “super awesome” without choosing too much too early

A shell+terminal becomes super awesome when copy is exact, structured, source-aware, and easy to route.
It becomes misleading when every selection or “copied” toast quietly claims the same delivery target, trust boundary, and persistence semantics.

SlopOS is already teaching the better pattern:
- offers stay weaker than grants,
- boundary crossing stays explicit,
- history construction stays non-ambient,
- helper folklore stays weaker than reviewed seams,
- and sensitive transfer remains narrow by default.

That is the Schell import worth ratcheting now.
