# Research synthesis, pass CXIII (2026-03-22)

This pass keeps one narrower lesson explicit:
**the shell+terminal should treat semantic drift as a first-class event, recover by reasserting a tiny live baseline, and mint a fresh semantic epoch rather than preserving stale certainty or reaching for a giant terminal reset.**

The latest terminal and shell pressure is unusually consistent.
Windows Terminal explains shell integration as escape-sequence metadata emitted by the shell itself.
kitty, WezTerm, Ghostty, fish, and iTerm2 all get much better once prompt boundaries, cwd reports, and command/output regions are explicit.
Recent fish releases sharpen the same pattern further: prompt markers now include prompt-end support, cwd is refreshed on every fresh prompt, and prompt-local mouse interaction can ride terminal-advertised support.
Ghostty's latest release similarly improves OSC 133 fidelity, prompt-local click behavior, and command-finish UX while also shipping a security fix for pasted or dropped control characters.

That convergence suggests a new no-regret move for Schell:
**the shell should be willing to restate a tiny semantic baseline at fresh prompt boundaries, and the terminal should prefer a fresh epoch over inherited confidence when hops, TUIs, or restarts blur what is still exact.**

## 1) Semantic comfort now depends on shell-known freshness

The most humane current affordances are all freshness-sensitive:
- same-cwd spawn,
- jump-to-prompt,
- select exact command output,
- prompt-local click-to-edit,
- command-finish notifications,
- and sticky command context.

They are wonderful when the shell can freshly attest prompt, cwd, and output boundaries.
They become risky when the terminal is running on remembered or half-broken state.

So Schell should treat fresh shell-known semantics as the enabling condition for its best terminal luxuries.

## 2) A tiny prompt-critical baseline is enough to start

Schell does not need a giant terminal-state ontology first.
A much smaller baseline would already carry a lot of value:
- prompt marker posture,
- prompt-end marker posture,
- cwd freshness posture,
- bracketed paste posture,
- maybe focus-reporting posture,
- and maybe active-prompt click/edit posture.

That gives the terminal enough footing to know whether its best local promises are currently strong, degraded, or stale.

## 3) Fresh-prompt reassertion is the right repair rhythm

One of the clearest lessons from recent fish changes is that fresh prompts are natural resynchronization points.
If a child program, remote hop, or full-screen app disturbed prompt-critical state, the shell can restate cwd and prompt markers when it regains control.
That is a much healthier answer than hoping the terminal guessed correctly or asking the user to perform a giant reset.

Schell should steal that rhythm.

## 4) Semantic epochs keep stale certainty from pretending to be current

Mosh is a helpful specimen here even though it is a different stack.
Its local prediction model works because speculative state is grouped and later confirmed.
The transferable lesson is not “copy Mosh wholesale.”
It is that **freshness boundaries matter.**

So Schell should probably give command-local affordances, sticky context, remembered cwd chips, and prompt-local editing an epoch or freshness fence.
When the semantic world changes, old affordances should degrade honestly instead of acting like current truth.

## 5) Keep repair moves separate

There are at least three different recovery actions:
- a light semantic resync,
- a prompt-critical baseline reassertion,
- and a heavier emergency terminal reset.

Current terminal culture often collapses these into one vague “clear/reset and hope” ritual.
Schell should avoid that.
A custom shell+terminal can afford to name smaller and more truthful repair moves.

## 6) Security pressure makes explicit repair even more important

Bracketed paste exists because pasted text is not the same as typed text.
Shellshock remains the classic warning that environment import and startup-time shell behavior can cross privilege boundaries disastrously.
The util-linux `wall` bug and Ghostty's recent paste/drop control-character fix are more reminders that terminal ingress is still a real attack surface.

Those lessons point the same way:
when the shell+terminal is uncertain, it should prefer a fresh witnessed resync over carrying forward optimistic assumptions.

## 7) Compact design-phase answer

Schell does not need to settle one final shell-integration treaty, one final mux relay protocol, or one final remote-continuity stack right now.
It only needs a bounded research-safe move:
- keep a tiny prompt-critical baseline,
- let fresh prompts reassert that baseline,
- mint semantic epochs when precision shifts,
- attach precision fences explaining the shift,
- and gate stronger command-local affordances on fresh epoch-scoped truth.

That is enough to make the shell+terminal feel far more robust and much less magical-in-a-bad-way while deep architecture remains open.
