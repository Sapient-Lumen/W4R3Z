# SlopOS datacube evaluation, pass LI

**Parameter fill and prompt-local editing should become dramatically more humane without letting slot-fill UI, workflow reuse, or click-aware prompts quietly rewrite reviewed action shape. SlopOS keeps teaching the same lesson: field-like help may accelerate the operator, but it does not get to widen execution meaning in secret.**

This pass focuses on another tempting seam for Schell:
- active-input editing,
- workflow-derived parameter fill,
- repeated-argument edits,
- click-aware prompt movement,
- and “smart” rewriting of command text.

That seam is dangerous because terminals and shells love to call it harmless editing polish.
In practice it can smuggle in parsing, tokenization, mutable-name reopening, and convenience rewrites that are stronger than the reviewed action.
SlopOS already has the right antibodies.

## 1) SlopOS capshell command-string posture says fill must preserve structured action shape

The capshell command-string posture is one of the clearest imports yet.
It refuses free-form command-string execution as baseline truth.
The runner accepts structured argv, does not auto-tokenize free-form strings, does not apply hidden shell quoting/expansion, and does not satisfy execution by secretly routing through `sh -c` or `system()`.
That is a direct Schell lesson for parameter fill.

A parameter-fill surface should therefore behave like **editing a reviewed action shape**, not like constructing some flattering command text blob that will be reinterpreted later.
The import is:
**fill slots, do not smuggle in a second parser.**

## 2) SlopOS exact-exec posture says repeated-slot edits must not retarget execution by name

The capshell executable-object posture is equally important.
Once execution has been reviewed against one exact executable object, SlopOS refuses to reopen a mutable name at the last moment and quietly retarget meaning.
That directly pressures workflow seeds and editable slots.

If a slot represents a path, peer, ref, secret handle, or executable selector, editing that slot must remain visible as basis change.
A synced edit over repeated slots is great.
A hidden name-reopen that changes what command will really run is not.

## 3) SlopOS keeps field-local convenience weaker than execution truth

The archive repeatedly rejects convenience seams that overclaim:
- OpenURI admission is not target completion,
- show-exact-item is not browse-nearby,
- launch does not mediate later browser permission truth,
- and raw subject echo does not become durable receipt truth.

The same method should govern prompt-local editing.
Click-to-move, slot cycling, repeated-slot mirroring, or workflow-fill chrome may all be delightful.
But they remain **editing affordances over active input**, not approval, not execution, and not proof that the final run still matches an earlier basis.

## 4) SlopOS manual-only and second-workflow discipline warns against auto-fill-plus-run

The OpenURI family keeps drawing one healthy line:
launch, reveal, open, chooser behavior, completion, and permission prompts are different workflows.
That matters just as much inside a shell.

Selecting a workflow seed, accepting a suggestion, or filling one missing parameter should not silently imply:
- run now,
- approve now,
- widen authority now,
- or accept the current execution ground as unchanged.

The import is:
**parameter fill is one workflow; execution is another.**

## 5) SlopOS typed-posture discipline says slots should be typed and provenance-bearing

Across plumb, capability, authority-diff, and exactness surfaces, SlopOS keeps preferring typed bounded objects over clever string folklore.
That is the right model here too.
A good Schell slot should know whether it is:
- a literal token,
- a path-like ref,
- an enum-like value,
- an executable selector,
- a peer/service target,
- a secret handle,
- or an operator-fresh override.

And the slot should also keep provenance visible:
- chapter literal,
- workflow default,
- completion suggestion,
- current-ground guess,
- or user-supplied replacement.

## 6) What SlopOS pressures Schell to steal

The strongest import is not a fancy editor.
It is a compact posture cluster:
- one active-input field that is the only writable truth lane,
- one parameter-slot family inside that field,
- one repeated-slot/synced-cursor posture for obviously-equal parameters,
- one provenance badge family,
- one visible basis-change warning when high-authority slots change,
- and one strict split between insert / review / run.

## 7) What Schell should deliberately refuse

### Refuse hidden text surgery

No background regex rewrite over history, transcript cards, or command output should pretend to be the same as field-local editing.

### Refuse slot fill that launders parser decisions

A slot fill must not silently choose quoting, splitting, expansion, or shell-language interpretation that the operator never reviewed.

### Refuse auto-fill-plus-run

Prompt-local luxury gets dangerous the moment selection and execution share one gesture.

### Refuse equal-looking repeated slots without equality posture

Two highlighted placeholders may look similar, but they should only mirror edits when Schell explicitly knows they are the same parameter family.

### Refuse editing that outruns current basis

When a slot touches executable identity, peer, secret handle, or authority-bearing target, drift should become visible before run.

## 8) Current consequence for Schell

The best next step looks compact:
1. one **slot-linked edit** surface in active input,
2. one **synced-slot** rule for repeated parameters,
3. one **slot provenance** badge family,
4. one **basis drift** cue for authority-bearing slots,
5. one explicit **insert / review / run** ladder,
6. and one refusal to let history or output masquerade as editable truth.

That is enough to make Schell much better at real command editing while still keeping parser, workflow syntax, editor stack, and transport choices open.
