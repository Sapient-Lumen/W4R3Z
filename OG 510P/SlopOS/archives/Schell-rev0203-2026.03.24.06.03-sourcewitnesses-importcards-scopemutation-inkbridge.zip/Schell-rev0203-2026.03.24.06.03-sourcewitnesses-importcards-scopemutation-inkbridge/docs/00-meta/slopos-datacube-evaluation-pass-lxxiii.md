# SlopOS datacube evaluation, pass LXXIII (2026-03-22)

This pass evaluates one new companion import:
**Schell should absolutely grow semantic-history witnesses, accessibility-aware command chapters, input-capability cards, and safe resurrection banners, but SlopOS pressure says observation must stay weaker than injection, request-local routes must stay non-authoritative, and restored or compatibility-shaped interaction must never impersonate live shell truth.**

## 1) SlopOS already gives Schell the right safety split: observation versus injection

RFC-0099 is unusually clear.
Accessibility and automation should be leased, attributed, separated by right, and manual-only on the ACP surface in Phase 1.
Observation does not imply injection.
That is an excellent rule for the shell+terminal too.
Semantic history, narrated command chapters, and command-output selection are observation-heavy luxuries.
Prompt editing, synthetic cursor placement, input injection, and rerun/resume are stronger actions.
Schell should keep those strengths visibly separated instead of bundling them into one vague “interactive help” mode.

## 2) SlopOS also says workflow routing should stay typed and request-local

RFC-0117 keeps plumb messages as canonical, request-local, and non-authoritative.
That matters directly for semantic history.
Clicking a filename, URL, stack frame, or output object should not become ambient authority.
The shell should route a typed intent packet with exact subject posture:
- exact bound object,
- semantic-history/cwd derived object,
- plain visible-text guess,
- or historical residue.
That keeps smart interaction luxurious without letting it silently become a second authority path.

## 3) Capshell startup/env posture keeps terminal integration honest

The startup-profile and env-startup postures already refuse implicit rc/profile loading, per-directory hooks, and startup/resolution env tricks.
That means terminal features should not sneak stronger behavior in through “just source our shell integration and everything will work” assumptions.
If a terminal interaction depends on startup injection, compat wrapping, or environment-provided helper code, Schell should say so explicitly in its claim-strength chrome.
The terminal should not get to be more magical than the execution model can honestly support.

## 4) SlopOS's background/autostart posture is a warning against helper-lane creep

RFC-0103 keeps background execution and autostart behind explicit leases.
That matters for accessibility and upgraded interaction too.
It is tempting for a terminal to maintain semantic indexes, precompute previews, or run hidden helper scans in the background.
SlopOS pressure says that kind of activity must not become invisible baseline behavior.
If Schell needs helper lanes for richer navigation, narration, or preview, they should be visibly leased, bounded, and killable.

## 5) SlopOS also keeps historical state weaker than present authority

Across the companion archive, receipts, descriptors, and request IDs stay non-authoritative.
That gives Schell the right posture for restoration.
A resurrected pane, restored command chapter, imported semantic-history record, or narrated prior output may be highly useful — but it is still historical until live truth is reacquired.
This aligns very strongly with safe resurrection banners and restored-state claim-strength badges.

## 6) The best SlopOS-compatible moves from this seam now look no-regret

The strongest companion-compatible moves are:
- **semantic-history witnesses** with claim strength separating exact / cwd-derived / guessed / historical,
- **accessibility-aware command chapters** with shell-owned narration points and structure,
- **input-capability cards** separating native / adapted / downgraded / disabled posture,
- **safe resurrection banners** that keep replay/rerun authority explicitly stronger than restore-view authority,
- **exact-reveal ladders** before strong open/export/share actions,
- and **helper-lane badges** whenever background indexing, narration prep, or preview work exists.

## 7) Things this pass still refuses to decide too early

This pass does **not** force:
- one final accessibility API,
- one final keyboard/input upgrade protocol,
- one final semantic-history transport,
- one final preview/index helper runtime,
- or one final resurrection substrate.

The answer is smaller and stronger:
**admit richer interaction on explicit honesty ladders, keep observation weaker than injection, keep typed routes weaker than exact capability truth, and keep restored context historical until live truth is reacquired.**
