# Research synthesis, pass XCV (2026-03-22)

This pass keeps one fresh rule in focus:
**the shell should be very explicit about when visible command text is only a suggestion, when it has been accepted into the live buffer, and when it has finally become reviewed action.**

That may sound small, but the modern shell+terminal ecosystem keeps proving how easy it is to blur those stages.
fish makes inline autosuggestions feel natural precisely because they remain inert until accepted.
PSReadLine turns prediction into an explicit editor surface with inline and list views, source labels, and next-word acceptance.
Ghostty and kitty show how wonderful prompt-local click editing becomes once the shell tells the terminal where the live prompt really is.
The design-phase lesson is simple:
**steal the delight, but keep ghost text, inserted text, and reviewed action as separately named truths.**

## 1) The most useful modern prediction lesson is not "be smarter"

fish and PSReadLine both point to the same deeper law: predictions are safe because they are edit aids first, not execution decisions.
The suggestion appears, the operator may accept all of it or part of it, and the command line remains editable before execution.
That is exactly the right shape for Schell.

The stealable answer is:
- suggestions should remain inert until accepted,
- whole-line acceptance and partial acceptance should both exist,
- accepted text should land in ordinary editable input,
- and execution still requires a separate explicit run step.

## 2) Prediction source should stay visible

PSReadLine's list view showing the prediction source is one of the best small ideas on the market.
It turns a flattering guess into a more reviewable proposal.
That matters even more for Schell because the project is likely to accumulate many suggestion families over time:
- history,
- known-extern signatures,
- workflow seeds,
- project packs,
- helper/plugin predictors,
- maybe model-backed hints,
- and restored historical residue.

Those should not collapse into one mysterious oracle.
A great shell+terminal can be very helpful while still answering the operator's first question: **why am I seeing this suggestion?**

## 3) Live-prompt editing is wonderful only if the live prompt is real

Ghostty's new click-to-move-cursor support in shell prompts and kitty's prompt-local mouse cursor movement are both strong clues that terminals can feel much more like real editors.
But the common condition is the important one: the terminal is not just guessing.
It is relying on shell integration / semantic prompt boundaries to know where the active prompt is.

That strongly suggests a Schell rule:
**prompt-local click editing belongs inside a shell-authenticated live input lease, not inside guessed scrollback.**

The shell should therefore keep these separately named:
- live editable prompt,
- historical prompt,
- restored prompt-like residue,
- and visible command chapters that are no longer editable input.

## 4) The buffer itself needs authorship posture

Modern shells still mostly behave as if the editing buffer were one flat undifferentiated string.
Schell can do better without freezing a giant editor architecture.

At minimum, the buffer should know whether text is currently:
- typed by the operator,
- accepted from a prediction,
- inserted from a workflow seed,
- inserted from history/chooser recall,
- pasted or dropped from outside,
- or proposed by a helper/assistant and not yet accepted.

That does not need to become a scary provenance log.
It just means stronger operations can remain honest about what the shell actually knows.
For example, “review exact command” should not pretend ghost text was authored input if it was never accepted.

## 5) fish still teaches the budget rule

fish's design notes remain a great restraint on ambition: autosuggestions and syntax highlighting must do disk I/O asynchronously, and startup should minimize forks and disk I/O.
That means prediction delight should stay cheap at the keystroke lane.
If a suggestion needs real work, it belongs in a named stronger lane, not hidden behind typing.

This is especially important if Schell ever wants richer predictors.
Source-labeled, accept-only, cheap-by-default help is a lot safer than one magic prompt-time oracle.

## 6) The right steal is smaller than a full editor manifesto

This pass does **not** argue for one final line-editor stack, one final semantic-prompt protocol, one final predictor plug-in API, or one final AI suggestion system.
It only argues for a smaller phase-zero discipline:

### Distinguish these truths
- visible ghost suggestion,
- accepted buffer text,
- live editable prompt region,
- and reviewed action.

### Steal these luxuries
- inline suggestions,
- partial acceptance,
- source-labeled list views,
- click-to-move inside the one live prompt,
- prompt-local cursor styling and command-boundary comfort,
- and easy “why this?” reveals for suggestions.

### Keep these vetoes
- no suggestion auto-run,
- no hidden acceptance,
- no historical prompt that still acts live,
- no plugin/model suggestion that hides its source,
- and no prompt-click editing based only on guessed renderer state.

## 7) Compact design-phase answer

One of the safest ways to make Schell feel super awesome is to make the command line feel more like an honest editor:
- ghost text stays ghost text,
- accepted text becomes ordinary buffer text,
- the live prompt is a shell-known region,
- and reviewed action stays a later, stronger thing.

That is a delightful import from the modern ecosystem that still keeps architecture, protocols, and predictor stacks open.
