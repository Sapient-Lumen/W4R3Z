# Research synthesis, pass LXXXII (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should steal the best current progress, completion, bell, badge, and notification ideas — command-bound alerts, progress rings, focus-aware suppression, background-only reminders, blocked-input nudges, and plain-text notification hooks — but it should keep transient attention cues, urgency hints, durable outcomes, and exact approval paths separately named so “the terminal got my attention” never impersonates “the terminal proved what happened or what I have already approved.”**

This seam matters because shell+terminal systems often become lovable through tiny attention cues.
They also become annoying, spoofable, or misleading in exactly the same place.
The current ecosystem now gives Schell both the fun ideas and the cautionary evidence.

## 1) Old terminal alerts are still a useful lesson: bells and activity markers are weak, not durable

Classic multiplexers and terminals still frame bells, activity, and silence as background attention, not as durable result truth.
The tmux manual says windows can carry distinct flags for activity (`#`), bell (`!`), and silence (`~`) and render them in the status line.
kitty keeps a similar ladder with window attention on bell, tab bell indicators, dock badges, and custom commands-on-bell.
See: https://man7.org/linux/man-pages/man1/tmux.1.html and https://sw.kovidgoyal.net/kitty/conf/

That is still the right baseline lesson.
A bell or activity marker is useful because it is weak.
It becomes misleading when a shell+terminal starts treating it like durable proof that a task completed, failed, or was reviewed.

## 2) The best current long-command alert is command-bound, not ambient

The most stealable completion-alert pattern in the current ecosystem is still iTerm2’s mark-bound alert.
iTerm2’s shell integration adds marks at command prompts, and “Alert on Next Mark” lets the user request an alert when the next mark appears after a long-running command returns.
That means the alert is attached to a real command boundary rather than to a vague “something happened in this session” heuristic.
See: https://iterm2.com/documentation-shell-integration.html and https://iterm2.com/documentation-menu-items.html

That is a great clue for Schell.
The user should be able to watch a command chapter, pane, or task shelf item directly rather than toggling a fuzzy session-global alert bit.

## 3) Focus-aware delivery is now clearly worth stealing

Current terminals keep converging on focus-aware notification policy.
kitty’s `notify_on_cmd_finish` can be `never`, `unfocused`, `invisible`, or `always`, with optional auto-clear on focus or next notification.
WezTerm’s `notification_handling` can be `AlwaysShow`, `NeverShow`, or suppress notifications from the focused pane/tab/window.
Warp only sends command-finished and password-needed notifications when another app is active.
See: https://sw.kovidgoyal.net/kitty/conf/ ; https://wezterm.org/config/lua/config/notification_handling.html ; and https://docs.warp.dev/terminal/more-features/notifications

This is exactly the kind of reversible luxury Schell should steal.
Focus posture should change how loudly the shell interrupts, not what the shell claims is true.

## 4) Progress deserves its own semantic object, not just a prettier bell

Windows Terminal’s progress tutorial says OSC `9;4` can show progress in both the tab header and the Windows taskbar.
WezTerm’s `pane:get_progress()` captures ConEmu-style progress state and exposes it to Lua so the tab title can style itself differently when progress changes.
See: https://learn.microsoft.com/en-us/windows/terminal/tutorials/progress-bar-sequences and https://wezterm.org/config/lua/pane/get_progress.html

That is a strong convergence signal.
Progress is not only “notify when done.”
It deserves a first-class semantic object with explicit states like none / percentage / error / indeterminate / cleared.
But progress still stays smaller than completion or durable receipts.

## 5) Plain-text notification payloads are safer than rich notification power

kitty’s desktop notification protocol is instructive because it is both powerful and careful.
It uses OSC 99, keeps the payload plain text, explicitly disallows HTML or markup, and can optionally focus the originating window or send an escape code back to the application on click.
See: https://sw.kovidgoyal.net/kitty/desktop-notifications/

The stealable lesson is split in two.
Plain-text, bounded payloads are great.
Click actions that can refocus or message the terminal are powerful enough that Schell should keep them visibly weaker than any durable approval surface.

## 6) The notification/progress protocol landscape is still fragmented

Current terminals do not agree on one notification/progress control surface.
WezTerm documents toast notifications from OSC 9 and OSC 777.
Warp also documents OSC 9 and OSC 777 notification hooks.
iTerm2 documents OSC 9 notifications plus OSC `9;4` progress, while also warning that its proprietary escape codes may have unknown effects on other terminals.
kitty uses OSC 99 for desktop notifications instead.
See: https://wezterm.org/config/lua/config/notification_handling.html ; https://docs.warp.dev/terminal/more-features/notifications ; https://iterm2.com/documentation-escape-codes.html ; and https://sw.kovidgoyal.net/kitty/desktop-notifications/

That means Schell should not freeze its final external notification wire protocol just because some current emulators expose overlapping escape-code tricks.
The safer move is to define a smaller internal attention object family and adapt outward.

## 7) Current tools already hint at the blocked-input cue Schell should make explicit

Warp’s notifications are especially interesting because they trigger not only on long-running command completion but also when a running command needs a password to proceed.
That is a clue that “blocked and waiting for you” is a distinct attention object family rather than just a completion event.
See: https://docs.warp.dev/terminal/more-features/notifications

A custom shell+terminal can do much better here by treating blocked-input cues, review-needed cues, and completion cues as separate postures with different budgets and stronger origin binding.

## 8) What Schell should now do

This pass points to a compact, high-value attention model:
- **attention-budget cards** for pane/task/origin interruption budgets,
- **focus posture chips** for pane/tab/window/visibility state,
- **chapter-bound alert objects** instead of ambient session-global watch bits,
- **progress cues** as first-class semantic objects,
- **blocked-input cues** distinct from completion,
- **auto-clear rules** that are explicit rather than magical,
- **secure-review handoffs** for any actionful follow-up,
- **plain-text origin-branded payloads** by default,
- **adapter-first escape-code bridges** rather than one frozen wire protocol,
- and **durable result cards** that remain after every toast/badge/bell vanishes.

## 9) Decisions intentionally kept open

This pass does **not** freeze:
- one final cross-terminal notification protocol,
- one final progress escape-code dialect,
- one final inbox/history surface for notifications,
- one final action model for alert clicks,
- one final priority/escalation policy,
- or one final background-agent reminder design.

The no-regret move is smaller:
**give Schell attention budgets, progress cues, command-bound alerts, blocked-input reminders, focus-aware suppression, and durable result splits so interruption becomes luxurious without pretending transient cues are truth or approval.**
