# SlopOS datacube evaluation — pass IX

This pass keeps one new synthesis in view:
**Schell should make authorship and reviewed basis visible enough that strong terminal actions can fail closed when the basis drifts instead of silently following “latest”.**

SlopOS keeps tightening three seams that matter directly for a shell+terminal:
exact approval basis, exact request identity, and exact separation between admission and later live state.
DelayBasin adds the process lesson that basis and authorship should be public witnesses, not private vibes.
The next Schell import is to treat those not only as backend law but as operator-surface law.

## Strongest SlopOS lessons right now

### 1) Approval must bind one exact mutable basis

SlopOS's approval-basis posture is one of the cleanest warnings Schell has seen.
Approval evidence binds one exact action, not a floating mutable target.
If the mutable basis matters, it has to be encoded as exact witness material, not left ambient.

Local import for Schell:

- a proposal, workflow, or replayable block should carry an exact **basis packet**,
- that packet should name the bound digests, revisions, epochs, or equivalent exact witnesses,
- and strong actions should refuse to silently follow `head`, `latest`, or “whatever is nearby now”.

This is one of the biggest lessons Schell must learn from the past.
Terminal history and saved commands become dangerously flattering when they quietly inherit newer basis than the operator actually reviewed.

### 2) Acceptance is not completion, and request identity is not live state

SlopOS now repeats this in multiple families: ACP acceptance/completion, OpenURI launch/completion, request-state adjuncts, lease descriptor state, and InputCapture-style enabled-versus-active pressure.
The common lesson is simple:
one exact admitted request does not by itself prove downstream completion or current provider-owned live state.

Local import for Schell:

- strong block actions should disclose whether they are acting on a live running object, a reviewed-but-not-running object, a historical receipt, or something whose current state is unknown,
- and a stale accepted request should not masquerade as a still-current strong action target.

This matters most once Schell grows richer rerun, attach, workflow, and replay affordances.

### 3) Exact target selection should stay policy-owned where exactness matters

SlopOS keeps refusing the temptation to turn bounded postures into target-selection or inventory planes.
Disposable routing, OpenURI handler choice, and session/profile selection all stay narrow on purpose.

Local import for Schell:

- a workflow seed may preserve posture and reviewed shape without preserving ambient target discovery,
- an agent proposal may preserve exact reviewed inputs without acquiring ambient lane-selection power,
- and a terminal affordance should say whether it is choosing an exact known object or merely requesting a bounded posture.

That is a great discipline for a design-phase shell+terminal because it keeps “super awesome” UX from smuggling in ambient power.

### 4) Wallets and summaries should stay descriptive, while basis packets stay exact

The previous pass imported authority strips and diff cards.
This pass sharpens their companion seam.
A wallet summary helps answer **what power is visible now**.
A basis packet helps answer **what exact thing was reviewed and is still compare-and-set valid**.
Those are related, but they are not the same object.

Local import for Schell:

- authority strips stay compact and descriptive,
- basis packets stay exact and action-binding,
- and review cards should make both visible without collapsing them.

### 5) Authorship should become a first-class operator fact

SlopOS is not a shell archive, but its exactness posture combines very naturally with DelayBasin's authorship-witness discipline.
Once Schell has direct commands, agent proposals, workflows, receipts, and replays in one visual field, authorship can no longer remain implied.

Local import for Schell:

- visible actionable objects should say whether they are direct, proposed, saved, replayed, or receipt-derived,
- that status should travel with the object into search, workflow creation, and review,
- and no object should gain stronger power merely because it looks like ordinary terminal text.

## What Schell should deliberately refuse for now

### Refuse latest-following reviews

An old approval should not silently attach to a newer revision, newer env shape, or newer command block just because the summary still looks close.

### Refuse provenance erasure when saving workflows

A saved workflow should not lose who authored it, what lane it came from, or what exact basis contract it expects.

### Refuse self-approval theater

If an assistant proposes, narrows, and executes without a separately legible maker-checker seam, the shell+terminal may feel powerful while actually becoming less trustworthy.

### Refuse giant CAS/basis dashboards before specimens exist

A small basis packet and one good stale-basis refusal specimen are probably enough to start.
A full compare-and-set control plane can wait.

## Current consequence for Schell

The best next ratchet is now:

1. **authorship badges on actionable objects,**
2. **exact basis packets for proposals, workflows, and strong reruns,**
3. **compare-and-set review gates that fail closed on basis drift,**
4. **explicit downgrade from strong actions to inspect-only when current live state is unknown,**
5. **and transcript-safe witnesses for all of the above.**

That is a strong way to make Schell feel much smarter than legacy shells while still keeping renderer, transport, workflow schema, and pipeline ontology open.
