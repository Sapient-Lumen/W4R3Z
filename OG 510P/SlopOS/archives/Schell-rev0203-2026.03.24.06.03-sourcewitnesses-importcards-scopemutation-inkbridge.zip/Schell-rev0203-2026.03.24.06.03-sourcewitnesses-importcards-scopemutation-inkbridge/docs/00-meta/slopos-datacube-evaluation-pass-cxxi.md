# SlopOS datacube evaluation, pass CXXI (2026-03-22)

This pass evaluates one narrower question against the current companion archives:
**what do SlopOS, Steward, and ViewFS teach Schell about semantic-mark authenticity and prompt/output provenance?**

The answer is simple:
**descriptive semantic chrome should stay weaker than live shell authority until provenance is freshly proved.**

## 1) SlopOS keeps rewarding exact basis and bounded trust transfer

Across the companion archive, SlopOS repeatedly prefers exact action basis, bounded proof surfaces, explicit mediation, and summary artifacts that do not widen authority by themselves.
That is a very strong fit for shell-integration semantics.
A terminal mark should be treated more like a review summary than like an authority-bearing action object.
Useful, yes.
Self-authenticating, no.

This gives Schell a strong construction rule:
- prompt/output marks may describe,
- semantic helpers may improve comfort,
- relays may preserve some of that comfort,
- but the strongest action rights remain shell-owned and basis-aware.

## 2) Steward keeps freshness and anti-spoof posture visible

Steward's repeated lesson is that trusted chrome should confess source and freshness.
That maps directly here.
A current prompt mark and a restored prompt mark are not the same thing.
A nonce-verified helper path and an unverified relayed mark are not the same thing.
Schell should therefore make provenance, relay posture, and freshness visible beside semantic luxury rather than behind it.

## 3) ViewFS keeps source class and state class distinct

ViewFS repeatedly pressures the archive not to flatten source and state.
That is useful for semantic integration too.
Schell should preserve whether a command frame is:
- shell-native,
- helper-emitted,
- relayed,
- inferred,
- restored,
- or historical.

Those classes help determine what the UI may confidently imply.

## 4) Companion-safe no-regret move

Schell does **not** need to decide one final end-to-end proof protocol for prompt marks.
It only needs a few bounded rules:

### A) Keep semantic marks descriptive unless provenance is stronger
This matches SlopOS's broader refusal to let summary artifacts silently become authority.

### B) Keep provenance grades explicit
Native, verified-helper, reviewed-helper, relayed, inferred, restored, and historical are different footing classes.

### C) Keep freshness and relay posture in the witness
Freshly proved semantics can unlock more than stale or relayed semantics.

### D) Keep stronger actions shell-owned
Exact rerun, approval reuse, and other strong follow-on moves should still depend on stronger shell-owned objects than terminal marks.

### E) Keep spoof and mismatch specimens first-class
This pairs naturally with the specimen orchard and makes the design much easier to debug without choosing the final transport stack too early.

## 5) Compact conclusion

The SlopOS-compatible answer is not “trust semantic marks when they look convincing.”
It is:
**grade semantic marks by origin, verification, relay path, and freshness; keep stronger actions shell-owned; and archive mismatch/spoof cases as explicit specimens.**

That is a very safe companion move because it raises rigor and keeps terminal delight while still deferring larger irreversible protocol choices.
