# Research synthesis — 2026-03-24 — pass CXCV

This pass sharpens one older shell lesson that still matters for a brand-new shell+terminal:
**expansion is useful, but expansion should not silently erase the difference between the typed token, the expansion plan, the current match set, the no-match policy, and the exact reviewed spend.**

## 1) Current shells already prove that expansion is not one thing

Bash keeps the full expansion stack explicit in its reference manual.
Expansion happens after tokenization, and the order matters: brace expansion first, then tilde / parameter / command / arithmetic, then word splitting, filename expansion, and quote removal.
Bash also says brace expansion is *strictly textual*, happens before any other expansion, and can therefore change word count before the shell has even decided which words will later become filenames or arguments.

zsh preserves the same warning in a different shape.
Its expansion order includes history and alias handling before the main expansion stages, and it still keeps filename generation as the last step.
It then gives explicit policy switches for unmatched patterns such as `NOMATCH` and `NULL_GLOB`.
That is a reminder that "what happens when nothing matches?" is not a minor edge case.
It is part of the shell's real contract.

fish makes the contract sharper for operators.
When fish sees an unquoted `*`, it performs wildcard expansion, and if nothing matches, it prints an error instead of running the command.
The docs explain why: bash-style literal pass-through can look convenient until a matching file later appears and changes what the command means.

Nushell is useful as a contrast.
Its `glob` command returns a list of fully qualified pathnames and offers explicit controls like depth, exclude lists, and type filters.
Its plugin protocol also has a `Glob` value with a `no_expand` boolean, which cleanly separates literal-path posture from wildcard-expansion posture.

PowerShell supplies the other useful contrast.
Its wildcard docs frame wildcards as patterns used with `-like` or with parameters that accept wildcards, which means the shell+command boundary is different from classic textual expansion folklore.

## 2) The lesson Schell must learn from the past

The historical mistake is not simply "globbing can surprise people."
The real mistake is **flattening different expansion families into one flattering command story**:
- the exact token the operator typed,
- a strictly textual brace or tilde rewrite,
- a wildcard pattern,
- a parameter/provider-side wildcard handled by the callee,
- the current match set,
- the no-match rule,
- and the final admitted command/argument list.

Once those collapse, three bad things happen:
1. the operator loses the authored command text,
2. review becomes less exact because changed filesystem state or changed options can silently alter spend,
3. and history/export surfaces start lying about what was literal, what was expanded, and what only looked stable because the directory happened to be empty at that moment.

## 3) The nifty ideas worth stealing are previewable and literal-friendly

The current ecosystem points to several low-regret steals:
- **expansion preview rows** that show how many matches are currently in scope,
- **sample chips plus omitted-count residue** for large match sets,
- **literal/no-expand toggles** that are explicit rather than quote-folklore-only,
- **dual-view history** that can preserve both typed pattern and realized match summary,
- **brace/tilde reveal chips** so textual rewrites do not masquerade as authored text,
- **revalidation before spend** when review time and execution time have drifted apart,
- and **typed no-match receipts** so fail, literal-pass-through, and empty-drop are not quietly interchangeable.

These are super awesome because they improve trust and comfort without forcing Schell to decide:
- one final wildcard grammar,
- one final filesystem search backend,
- one final cache/index strategy,
- one final quoting pedagogy,
- or one final compatibility story for bash, zsh, fish, Nu, and PowerShell habits.

## 4) The moves Schell should refuse for now

Schell should refuse, for now:
- letting a preview sample impersonate the full current match set,
- rewriting typed command text without leaving a reveal path,
- hiding whether a wildcard was shell-expanded or callee/provider-matched,
- exporting only the realized expansion while discarding the typed pattern,
- and treating unmatched-pattern behavior as ambient shell folklore instead of a named policy.

In other words:
**steal the comfort of visible expansion help, not the ambiguity of invisible expansion spend.**

## 5) The no-regret Schell seam

Schell should add one dedicated surface for:
- typed pattern token,
- expansion family,
- candidate/match count,
- no-match posture,
- literal override posture,
- review-time revalidation,
- and history/share dual view.

That lets the shell feel dramatically smarter around patterns and filenames without deciding whether the long-term answer is bash-like expansion, Nu-like typed globs, PowerShell-style parameter matching, or some later hybrid.

## 6) Compact conclusion

Current official docs line up unusually well here.
Bash and zsh show how much hidden contract is packed into expansion order and unmatched-pattern policy.
fish shows the operator-facing trust win of refusing silent literal pass-through.
Nushell and PowerShell show that not all pattern matching needs to live in the same lane.

So the next low-regret Schell seam is **expansion witnesses, glob reveals, and match-residue humility** so pattern convenience stays delightful without becoming hidden reviewed spend.
