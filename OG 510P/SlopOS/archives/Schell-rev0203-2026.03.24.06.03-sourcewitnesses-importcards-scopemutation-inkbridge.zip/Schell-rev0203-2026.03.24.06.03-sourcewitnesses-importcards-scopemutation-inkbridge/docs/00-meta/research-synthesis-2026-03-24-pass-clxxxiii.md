# Research synthesis — 2026-03-24 — pass CLXXXIII

This pass sharpens one smaller lesson from current shells, terminals, editors, and routed-terminal experiments:
**the next leap is not more hidden magic; it is making parse understanding, advisory diagnostics, compiled packets, and prepared actions visibly distinct.**

## 1) Current tooling proves incremental structure is worth having before execution

Tree-sitter is explicit that incremental parsing can update a concrete syntax tree efficiently while the source is edited and still remain useful in the presence of syntax errors.
That is a strong reminder that Schell does not need to settle its final shell grammar before it proves a `parse lens` surface.

Nushell pushes the same lesson from another angle.
Its extern signatures make parse-time type checking, completions, and syntax highlighting available for external commands.
That means there is already market proof that shells can become structurally helpful before anything has been executed.

The product lesson is simple:
**Schell should expose best-current structure early, but keep it explicitly weaker than compiled or reviewed action.**

## 2) Diagnostics are now a mature parallel lane, not a synonym for the command

The LSP ecosystem normalized diagnostics as their own information channel.
ShellCheck is a strong shell-specific reminder that bug-finding and portability help are valuable precisely because they stay advisory.

That suggests a no-regret import for Schell:
- syntax warnings,
- lint,
- history notes,
- policy advice,
- and footing drift

should travel in a **diagnostic rail**, not collapse into syntax color, one red underline, or one magic readiness bit.

## 3) The best interactive shells keep proving that immediacy and honesty can coexist

fish keeps syntax highlighting, autosuggestions, completions, and selection lists near the prompt without pretending they are execution.
PSReadLine's Predictive IntelliSense likewise keeps suggestion acceptance and actual running separate.

That is exactly the past lesson Schell must retain:
**ghost text, predictions, and completion comfort should never impersonate authorship or approval.**

So the shell should name at least four different truths:
- suggested text,
- accepted buffer text,
- current parse understanding,
- and prepared action.

## 4) Current terminals prove command zones are valuable, but they are not enough on their own

VS Code, Windows Terminal, Ghostty, WezTerm, kitty, and iTerm2 all keep making shell-reported prompt/command/output boundaries richer and easier to navigate.
That means Schell should absolutely steal command-local navigation, sticky command context, marks, and captured-output comfort.

But those products also reveal the next missing layer:
terminal shells still often jump from `some structure is visible` directly to `a likely next action is offered`.
That leaves too much ambiguity between what the operator typed, what the parser thinks, what helpers inferred, what the current footing compiled, and what would actually run.

So Schell's next move should not be `copy all the UI chrome`.
It should be:
**keep a packet gutter between structure/diagnostics and reviewed action.**

## 5) The best steals are brilliant precisely because they stay bounded

A compact stack is starting to emerge:
- **parse lenses** from editor-grade incremental parsing,
- **diagnostic rails** from LSP/ShellCheck-style advisory channels,
- **prediction comfort** from fish and PSReadLine,
- **typed command signatures** from Nushell externs,
- **command-local navigation** from current shell integration docs,
- **packet gutters** and **compile diff cards** from the ViewFS companion pressure,
- **runnable docs** from Warp notebooks,
- and **explicit routes** from Plan 9 plumbing.

That is plenty of brilliance already.
What matters is importing these as separate lanes instead of one hidden smart shell myth.

## 6) The no-regret Schell move

Schell should add one dedicated surface for:
- editable buffer,
- parse lens,
- advisory diagnostic rail,
- packet gutter,
- prepared-action shutter,
- and receipt ghost.

It should also reserve a tiny compile-diff witness for the case where the same visible text compiles differently because cwd, bindings, subject, or env footing changed.

## 7) Compact conclusion

The ecosystem has already paid for the lesson:
incremental parsing, rich diagnostics, autosuggestion comfort, typed command signatures, and command-aware terminal zones are all real.

So the next low-regret Schell seam is **parse lenses, diagnostic rails, and packet gutters humility** so the shell can become editor-grade and super awesome without pretending that parser recovery, helper suggestions, or terminal chrome are already reviewed execution truth.
