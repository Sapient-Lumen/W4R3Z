# LLM runbook

When editing Schell:

1. Re-read the charter, trajectory map, move registry, and the directly affected RFC/ADR surfaces.
2. Keep execution IR, review/authority, interactive sugar, and terminal presentation distinct unless a revision is explicitly about merging two of them.
3. Do not smuggle implementation commitments into canon without naming them as such.
4. Update the ledgers if the revision changes scope, assumptions, followthrough, or foreign pressure.
5. Prefer narrow ratchets over large stylistic rewrites.
6. If a design move is attractive but unearned, move it to quarantine instead of deleting it.
7. When in doubt, define a smaller interaction probe instead of freezing more language.
