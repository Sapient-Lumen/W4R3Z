# Research synthesis, pass CXXIV (2026-03-22)

This pass keeps one narrower lesson explicit:
**clipboard access should be modeled as separate egress and ingress lanes, with a strong read/write asymmetry and explicit remote-local bridge posture.**

The current ecosystem converges on that lesson from multiple directions.
xterm still documents OSC 52 selection manipulation and allows both writes and `?` queries, but keeps the control under `allowWindowOps`.
tmux treats clipboard forwarding as an explicit policy setting and warns that `set-clipboard=on` lets any program able to write to a pane set the system clipboard.
kitty's clipboard controls split write from read and warn that disabling read confirmation is a security risk, especially because remote programs can otherwise read the local clipboard.
Ghostty likewise treats clipboard-read and clipboard-write as separate settings, defaults reads to prompting, and keeps paste protection as a separate policy surface.
WezTerm supports OSC 52 writes and clears but ignores clipboard-query requests.
PowerShell's `Set-Clipboard -AsOSC52` is a particularly good product clue because it names the remote-to-local case directly instead of burying it inside generic copy behavior.

Taken together, the design-phase lesson for Schell is clear:

## 1) Clipboard reads are ambient-data requests

A clipboard read is not just a nicer paste.
It is an ambient-data fetch from the host operator environment.
Schell should therefore keep clipboard read permission stronger, more explicit, and more inspectable than clipboard write permission.

## 2) “Copied” is too vague for a serious shell+terminal

The shell should be able to distinguish:
- local copy pack only,
- local host clipboard write,
- mux-local buffer update,
- remote peer clipboard write,
- terminal-bridge write,
- denied read,
- ignored query,
- and stronger export/publication moves.

That one distinction would make a lot of current terminal folklore disappear.

## 3) Relay-aware badges are more important than protocol maximalism

Schell does not need to choose a huge clipboard protocol stack right now.
It needs to preserve which hop or policy family actually answered the request.
That means relay-aware badges and result chips matter more than freezing one universal clipboard backend.

## 4) Powerbox-style approval is the right companion pattern

SlopOS keeps pushing explicit chooser-owned grants, no ambient authority, and temporary delegated rights.
Clipboard reads fit that pattern unusually well.
A read should behave like a small consent-mediated grant.
A write can often remain a weaker, more local egress move.
That asymmetry is a very good design rail.

## 5) Compact answer

Schell does **not** need one universal clipboard treaty yet.
It needs one bounded move:
- explicit clipboard operation families,
- stronger posture for reads than writes,
- remote-local bridge naming,
- relay-aware result badges,
- and a rule that clipboard success must not quietly overclaim publication, locality, or shell authority.
