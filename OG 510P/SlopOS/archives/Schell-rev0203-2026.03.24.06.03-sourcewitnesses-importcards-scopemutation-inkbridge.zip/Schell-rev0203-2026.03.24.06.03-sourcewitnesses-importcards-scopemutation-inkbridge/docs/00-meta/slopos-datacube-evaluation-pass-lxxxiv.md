# SlopOS datacube evaluation, pass LXXXIV (2026-03-22)

This pass evaluates the new file / path / watch seam against the current SlopOS archive.
The main result is straightforward:
**SlopOS strongly rewards a shell that treats files, paths, watched roots, and reopened objects as explicit view-bound or portal-bound objects rather than as ambient host-path truth.**

That pressure comes from multiple places in the companion archive and lines up unusually well with the current terminal ecosystem.

## 1) SlopOS keeps name resolution explicit and rejects a privileged ambient `open(path)` story

`view-namespace-posture-v0.md` is the clearest companion pressure here.
It says namespaces are explicit view objects, name resolution is pure against an explicit view, the binding model stays single-slot in Phase 1, and the privileged core must not provide a syscall or hypercall that parses arbitrary paths against a global namespace.
That is very strong guidance for Schell.

For Schell this implies:
- a clicked path should not by itself count as file authority,
- file/path UX should preserve the current ground or view basis,
- and remote, synthetic, or imported file-like subjects should stay visibly weaker than exact local file cards.

## 2) SlopOS refuses ambient host-filesystem baselines in execution

`capshell-filesystem-posture-v0.md` says a reviewed `capshell.exec` launch does not imply ambient host absolute-path reachability, adds no reviewed per-step `open(path)` surface, and keeps file authority on explicit seams such as cwd roots, descriptors, views, and chooser/portal-mediated selections.
That is a sharp warning against classic shell folklore.

For Schell this implies:
- absolute-path text does not become reviewed filesystem authority merely because the terminal can render it,
- the shell should keep cwd/view/descriptor ground explicit,
- and richer file UX should grow from explicit file cards rather than from inherited host-path optimism.

## 3) SlopOS already has the right posture for mediated files and durable reopen

`document-portal-posture-v0.md` keeps file open/save manual, capability-returning, and explicitly persistent only when the user asks for it, while refusing host-path return values and refusing an app-visible grant inventory.
This maps beautifully to Schell’s file/path seam.

For Schell this implies:
- chooser- or portal-derived file authority should be visibly marked,
- one chosen file should not widen into parent-folder or ambient search authority,
- durable reopen should stay weaker than ambient filesystem reachability,
- and file cards should reveal whether the current target came from explicit mediation or from explicit local resolution.

## 4) SlopOS already treats search/live-query seams as bounded and snapshot-first

`attrfs-posture-v0.md` says queries are view-scoped, handle-returning, snapshot-first, and that live-query mode is optional, bounded, revocable, and kept away from app-visible ambient inventory or scheduler state.
That is almost exactly the discipline Schell needs for file watches.

For Schell this implies:
- watch roots and live file rows should stay capability-scoped and explicit,
- snapshot results and live-updating rows should stay visibly distinct,
- and a watched or indexed file row should remain weaker than an exact reopen basis until the shell promotes it into one.

## 5) SlopOS also warns against smuggling fetch, persistence, and telemetry into generic open/navigation

The OpenURI companion boundaries matter here too.
`openuri-materialization-boundary-v0.md` refuses to make generic URI launch into hidden download/import/local-path semantics.
`openuri-navigation-observation-boundary-v0.md` refuses to make generic launch into downstream page-state telemetry.
That is a helpful analogy for file-path UX.

For Schell this implies:
- opening a clicked file-like subject should not silently download, import, or persist it,
- watching or browsing a file tree should not silently become an ambient inventory or telemetry plane,
- and “show me this file” should stay smaller than “give me broad durable authority over its whole locality.”

## 6) The current ecosystem gives a companion-compatible answer

Current terminals now prove a narrow pattern that matches SlopOS well:
- iTerm2 and VS Code prove cwd-aware and verified file links are worth stealing,
- kitty proves explicit hyperlink and SSH-remote file actions are worth stealing,
- Watchman proves root-scoped watchers, cookie-synchronized queries, and recrawl honesty are worth stealing,
- and Linux/Fuchsia path semantics prove path text is not ambient identity.

SlopOS sharpens the cut:
**Schell should steal file interaction luxury, not host-path folklore.**

## 7) What this pass now strongly suggests for Schell

The most companion-compatible moves are:
- **file cards** with explicit locality and existence posture,
- **path-ground witnesses** for cwd/view/descriptor/hyperlink/remote grounding,
- **watch-root cards** with project-root identity, freshness, overflow, and recrawl posture,
- **promotion rails** from path-like text or watched rows into exact file objects,
- **derived-view honesty** for synthetic or index-backed results,
- **parent-browse refusal** when the target is not exact,
- and **stronger actions** that re-establish exact target truth instead of inheriting it from visible text or watch rows.

## 8) Decisions this pass still refuses to make too early

This pass still does **not** force:
- one final file-card wire format,
- one final watcher/event substrate,
- one final remote-file bridge,
- one final search/index backend,
- one final file browser,
- or one final namespace algebra for Schell.

The answer stays smaller and stronger:
**let Schell become excellent at clicking, revealing, editing, and watching file-like subjects — but keep path text, exact file identity, watch freshness, and locality/ground separately named.**
