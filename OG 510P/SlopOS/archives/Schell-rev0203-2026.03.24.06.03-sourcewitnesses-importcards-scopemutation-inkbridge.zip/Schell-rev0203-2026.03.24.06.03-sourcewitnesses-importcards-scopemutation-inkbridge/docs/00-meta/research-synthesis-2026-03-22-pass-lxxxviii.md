# Research synthesis, pass LXXXVIII (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should make diagnosis feel first-class and luxurious — explainers, narrow traces, key/input decoders, effective-behavior inspectors, and shareable support bundles — but it should keep live debugging views, trace logs, replay residue, and exported diagnostic bundles weaker than exact shell action truth and clearly separate from any surface that can spend authority.**

This seam matters because shells and terminals still answer too many different questions with one blunt instrument.
Users want to know:
- why did that keybinding fire,
- why did the prompt change,
- why did this completion or warning appear,
- what command path actually ran,
- why is startup slow,
- why is shell integration missing,
- or what exact evidence can be shared to debug a failure.

Classic tracing and giant debug logs help, but they often blur together:
- command tracing,
- config provenance,
- effective input decoding,
- helper authorship,
- renderer problems,
- and exportable support artifacts.

The current ecosystem gives Schell a much better answer.

## 1) Old tracing taught a useful warning: trace lanes need their own sink

Bash still exposes `set -x`, and the Bash manual is especially instructive because `BASH_XTRACEFD` can send xtrace output to a separate file descriptor instead of standard error.
fish keeps the same lesson alive: `fish_trace` is useful, but fish also documents `--debug-output` so tracing and debug categories can be redirected away from ordinary stderr.

That is a stronger lesson than “tracing exists.”
It says:
**diagnostic output should be visibly diagnostic.**
A shell that braids trace chatter into ordinary output without clear blame will always make later explanation harder.

## 2) Good diagnosis is narrower than “turn debug mode on”

PowerShell is unusually clear about this.
It separates trace sources from trace execution: `Get-TraceSource` lists traceable components, while `Trace-Command` and `Set-TraceSource` let the user pick the component and the listener destination.
Nushell is similarly encouraging because its debug surface is not one command: `debug env`, `debug info`, `debug profile`, and `explain` all answer narrower questions.

That is exactly the design pressure Schell should import.
A delightful shell+terminal should not ask users to memorize one giant debug mode.
It should give them **small diagnostic grounds** matched to the question they are asking.

## 3) Terminal diagnosis is best when it explains one subsystem at a time

Current terminals already show the pattern.
WezTerm exposes a debug overlay for reviewing recent issues and a Lua REPL, but it also keeps narrower tools such as `show-keys` and `debug_key_events` for input problems.
kitty keeps a dedicated `debug_config` action that shows exactly what configuration kitty is running with and its host environment.
iTerm2 exposes debug logging, performance stats, GPU-frame capture, and instant replay as different tools rather than pretending they are all the same thing.

The lesson is simple:
**excellent observability comes from narrow lenses, not from one flattering giant log.**

## 4) Helper authorship should leave breadcrumbs, not folklore

Ghostty is especially useful here because its shell-integration docs tell the operator exactly what log lines to look for to verify automatic injection.
That is the right posture.
If a terminal, editor, helper, or bridge altered shell behavior, diagnosis should not begin with guesswork.
The helper should leave a visible breadcrumb.

Schell can steal that directly.
If startup, prompt marks, cursor semantics, click behavior, or cwd tracking depend on helper integration, that help should have a visible diagnostic author card.

## 5) Replay and support artifacts are evidence, not authority

iTerm2’s debug logging, performance capture, GPU frame capture, and instant replay are valuable because they preserve evidence that would otherwise be lost.
But none of these artifacts should pose as exact live shell truth.
They are support evidence.

That distinction matters a great deal for Schell.
A replay, transcript slice, support bundle, prompt snapshot, or renderer capture should be easy to assemble and easy to share — but still visibly weaker than a fresh, live, exact shell explanation on current basis.

## 6) SlopOS makes the right import much sharper

The companion archive keeps saying the same thing from a system-design angle:
- tracing should be declared, bounded, and capability-mediated,
- inspect-style snapshots should be structured and export-scoped,
- and triage rules should be deterministic and non-authoritative.

That maps beautifully to Schell.
The shell+terminal should support:
- **why cards** for narrow local explanation,
- **trace scopes** for bounded per-subsystem observation,
- **correlation ids** for linking chapters/traces/snapshots,
- **diagnostic bundles** with explicit export tiers,
- and **support-share cards** that say what is included, redacted, historical, or guessed.

## 7) What Schell should now do

This pass suggests a compact answer:
- **diagnostic-ground cards** for prompt/config/env/keybinding/completion/startup explanation,
- **trace scopes** that are component- or chapter-specific rather than ambient,
- **separate trace sinks** so debug lanes do not impersonate command output,
- **helper-breadcrumb cards** for injected or bridged behavior,
- **chapter correlation ids** that bind live events to later evidence,
- **sanitized support bundles** that are clearly export artifacts,
- and **live-vs-historical posture badges** on replay, overlay, or captured views.

## 8) Super-awesome specimen ideas that still stay decision-light

A first specimen set could stay small but teach a lot:
1. one “why did this key fire?” card showing raw input decode, winning binding, and loser bindings;
2. one “why did this prompt segment appear?” card separating config ground from runtime fact;
3. one “why is shell integration missing?” card showing helper breadcrumb, expected marker, and last seen log lines;
4. one per-command chapter trace scope that captures only startup + env delta + launched argv + completion/progress events;
5. one slow-command profile card that stays chapter-local and does not turn into general always-on profiling;
6. one support bundle card with sanitized/full tiers and an explicit inclusion manifest;
7. one replay or debug snapshot card that is visibly historical and shareable but not rerunnable authority;
8. and one receipt that links a live why-card to the historical bundle exported from it.

## 9) Decisions intentionally kept open

This pass does **not** freeze:
- one final tracing engine,
- one final support-bundle schema,
- one final helper log format,
- one final replay/debug snapshot substrate,
- one final correlation-id wire format,
- or one final always-on observability policy.

The no-regret move is smaller and stronger:
**give Schell diagnostic-ground cards, trace scopes, helper breadcrumbs, chapter correlation ids, and explicit support-bundle tiers so diagnosis becomes much more humane without turning giant debug logs, replay artifacts, or exported bundles into hidden authority.**
