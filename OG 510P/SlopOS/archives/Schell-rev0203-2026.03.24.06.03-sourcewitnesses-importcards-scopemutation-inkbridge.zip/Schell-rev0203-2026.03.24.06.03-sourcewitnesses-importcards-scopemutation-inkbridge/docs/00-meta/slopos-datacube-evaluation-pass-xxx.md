# SlopOS datacube evaluation, pass XXX

This pass keeps one bounded thesis in focus:
**SlopOS keeps teaching that “smart enrichment” must stay a second workflow, not a hidden side effect of ordinary open, recall, preview, or run. Schell should steal that rule before its custom shell+terminal gets too clever.**

SlopOS is still in design phase, which makes this a good time to learn from its boundary discipline instead of reverse-engineering a finished product later.
The current companion revision is especially useful because the OpenURI family keeps pinning one subtle historical lesson again and again:
**do not let one flattering operator verb quietly absorb preview, prefetch, fallback, liveness, recents, session reuse, or subject echo.**

## 1) The OpenURI boundary family is really a lesson about shell+terminal design

The newest companion material sharpens several adjacent refusals:
- preview metadata is not generic launch truth,
- speculative loading is not harmless acceleration,
- install fallback is not part of generic open,
- recent items are not durable reopen authority,
- session selection is not generic launch,
- and launch completion is not “the user definitely saw it” truth.

That is much bigger than OpenURI.
It is a design method.
Whenever Schell is tempted to make one terminal surface mean:
- show,
- inspect,
- preview,
- materialize,
- rerun,
- remember,
- or prefetch,

SlopOS says to split those seams before they fossilize.

## 2) SlopOS is strongest where it refuses hidden second workflows

The companion capshell cluster already refused hidden command-string parsing, hidden startup/profile behavior, hidden expansion, and hidden executable retargeting.
The OpenURI cluster extends the same rule to launch behavior.
Together they say:
**if the system did extra work that matters, name it.**

That is one of the most important historical lessons for Schell.
Shells and terminals usually become dangerous not because they run commands at all, but because they run *extra* commands, *extra* lookups, *extra* hooks, or *extra* previews without naming the second workflow.

## 3) This maps directly onto terminal enrichers

Schell's custom terminal is going to want all kinds of brilliance:
- dynamic completions,
- semantic link resolution,
- hover hints,
- object metadata cards,
- workflow summon,
- chapter summaries,
- agent-produced help,
- and background freshness refresh.

SlopOS suggests a clean discipline for all of them.
Treat them as **enrichers**, not as invisible truth engines.
That means:
- a completion row is not command execution,
- a semantic link hint is not exact object authority,
- a preview snippet is not open/materialize truth,
- a history hit is not rerun approval,
- and a refreshed card is not live shell truth unless the shell says so.

## 4) “Speculative loading” has a shell+terminal twin

OpenURI speculative loading refuses to treat warmup, prefetch, prerender, or preconnect as harmless synonyms for launch.
Schell needs the twin rule:
**no ambient prefetch for terminal intelligence.**

That means the shell+terminal should be very reluctant to:
- run a completer just because a menu opened,
- fetch remote metadata just because a row came into view,
- resolve a link by dereferencing network state during hover,
- warm a session or reattach candidate before the operator asks,
- or materialize historical chapters merely because they were searched.

These may all become useful explicit actions.
They should not become ambient background folklore.

## 5) SlopOS suggests a compact answer: badge enrichers and split refresh

A bounded Schell import probably looks like this:
- **source grade** — where did this enrichment come from?
- **freshness grade** — static / cached / live / historical,
- **cost grade** — free / local-io / local-exec / remote-read,
- **effect posture** — observational / materializing / authority-sensitive,
- and one explicit **refresh/materialize** action when the system would otherwise need to do more work.

That one split keeps the terminal shiny without pretending every shiny surface is equally safe or equally current.

## 6) SlopOS also pressures transcript and restoration honesty here

Once enrichers exist, transcripts and restored sessions become even trickier.
A card shown from cache, an imported preview, or a restored suggestion shelf can look current.
SlopOS already teaches that restore/import/history artifacts must stay visibly weaker than fresh truth.
So Schell should make enrichment history explicit too:
- restored enrichment,
- cached enrichment,
- imported enrichment,
- refreshed enrichment,
- and shell-witnessed truth should not blur together.

## 7) The big lesson from the past: terminals age badly when they smuggle helpers

Classic shells and terminals accumulated danger through:
- prompt hooks,
- rc/profile hooks,
- completion scripts that execute code,
- smart preview helpers,
- history managers that silently rewrite commands,
- opener helpers that recurse into the outside world,
- and restoration machinery that looks live.

SlopOS keeps naming exactly those failure modes in more precise substrate language.
That is why its datacube is such a good companion for Schell even before either system ships.

## 8) Repo/process lesson to steal directly

SlopOS is again strongest in method as much as in product shape.
The boundary family pattern makes it easy to say:
- this is generic launch,
- this is preview,
- this is speculative loading,
- this is install fallback,
- this is session selection,
- and these are not the same thing.

Schell should keep stealing that process.
Rather than one giant “smart terminal” note, it should keep cutting narrow surfaces with exact non-goals and explicit second-workflow boundaries.

## 9) The no-regret Schell move now

The next safe ratchet is not to pick one enrichment backend.
It is to say that Schell will have **enrichment packets** and that:
- they are non-authoritative,
- they are explicitly sourced,
- they are explicitly fresh or historical,
- they may require explicit refresh/materialize,
- and they do not silently widen into execution, preview, or open authority.

That is enough to make the terminal much smarter while SlopOS and Schell are both still design-phase systems.

## 10) Decisions intentionally kept open

This pass still does **not** freeze:
- one background refresh daemon,
- one completion/plugin runtime,
- one preview/fetch engine,
- one cache layout,
- one sync model,
- one workflow store,
- or one policy engine for enrichers.

The no-regret move is narrower:
**treat enrichment as a named, graded, refreshable second workflow rather than hidden terminal folklore.**
