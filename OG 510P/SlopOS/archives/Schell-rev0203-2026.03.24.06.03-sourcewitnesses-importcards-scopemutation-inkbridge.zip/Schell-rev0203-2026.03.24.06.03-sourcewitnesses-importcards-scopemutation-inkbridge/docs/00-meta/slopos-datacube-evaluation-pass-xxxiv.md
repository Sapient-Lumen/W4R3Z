# SlopOS datacube evaluation, pass XXXIV

This pass keeps one bounded thesis in focus:
**SlopOS keeps warning that visible launch subjects should not quietly acquire preview, extraction, speculative loading, durable history, or raw-subject echo semantics. Schell should import that lesson directly into hyperlink UX before the terminal becomes a stealth browser.**

This is another good import point because SlopOS is still design-phase too.
The lesson is sharp while still cheap to apply.
The current OpenURI family is effectively a catalog of what not to smuggle into one flattering “open this link” verb.

## 1) SlopOS keeps saying extra link work is a second workflow

The OpenURI preview-metadata boundary refuses to let generic launch become link preview, unfurl, title/icon/image extraction, or metadata-card truth.
The content-extraction boundary refuses to let launch become reader mode, distillation, or extracted article text.
The speculative-loading boundary refuses to let launch become warmup, preconnect, prefetch, or prerender.
The materialization boundary refuses to let launch become download or durable local-object minting.

That is not just portal hygiene.
It is a beautiful design lesson for Schell.
A terminal should not get to do stealth browser work merely because a URI is visible.

## 2) Subject echo and recents are especially important shell lessons

The OpenURI subject-echo boundary refuses portable full-URI echo as durable truth.
The recent-items boundary refuses generic launch becoming portable reopen or recents authority.

That matters directly for a shell+terminal.
Visible links often contain query parameters, fragments, user IDs, opaque tokens, or path details that operators did not intend to turn into durable shell history.
A future Schell terminal must be careful that:
- inspect hovers,
- copied diagnostics,
- transcript slices,
- quick-fix history,
- and restored rich-link cards

do not accidentally harden raw URI text into a second durable history plane.

## 3) The OpenURI family already implies a link ladder for Schell

Taken together, the OpenURI boundaries imply a very clean terminal rule:
- **seeing** a link is weaker than **inspecting** it,
- **inspecting** it is weaker than **opening** it,
- **opening** it is weaker than **unfurling** it,
- **unfurling** it is weaker than **extracting** content,
- and all of those are weaker than **materializing** bytes or durable object identity.

That ladder is exactly the kind of no-regret structure Schell should name early.
It can make the shell+terminal feel precise and luxurious without freezing one browser stack or one preview backend.

## 4) SlopOS also keeps pointing toward source-labeled honesty

The archive already values exact request identity, request-local meaning, restored-state humility, and digest-first/redaction-aware evidence.
For Schell, that suggests visible hyperlinks should carry more than color.
They should be able to say whether they were:
- explicitly emitted,
- inferred from text,
- strengthened by shell context,
- restored from history,
- or imported from another source.

That would give operators a much better mental model than one generic clickable surface.

## 5) Hover is the easiest place for a hidden second system to appear

Once a terminal can detect links, hover quickly becomes tempting:
- fetch title,
- fetch icon,
- fetch preview image,
- preconnect,
- prefetch,
- or prepare a browser/session.

SlopOS argues against that style strongly.
Hover should stay weak and descriptive by default.
If richer work is wanted, it should be a separately named action with freshness and source posture visible.

## 6) The strongest import is not “build a browser”

The strongest import is smaller:
- one **hyperlink witness** family,
- one source ladder such as explicit/inferred/shell-attested/restored,
- one **no-fetch hover** rule,
- one explicit **unfurl / extract / refresh** action family,
- one **bounded subject-echo** posture,
- and one rule that shell-local recents stay non-authoritative.

That is enough to learn from SlopOS now without choosing:
- browser embedding,
- metadata fetch backend,
- history schema,
- profile/session handoff architecture,
- or durable preview-card storage.

## 7) This is a direct path to “super awesome” without hidden magic

A shell+terminal becomes super awesome when links are:
- easier to trust because their source is visible,
- easier to inspect without committing to open,
- richer when the operator explicitly asks for more,
- and less likely to leak or surprise because hover and history stay humble.

That is exactly the kind of powerful but decision-light move Schell should prefer while both datacubes are still in design phase.
