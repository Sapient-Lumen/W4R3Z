# Research synthesis, pass LI (2026-03-21)

This pass keeps one fresh design rule in focus:
**the active input should become a field-like editing surface with visible parameter slots and reversible synced edits, but those luxuries must stay inside explicit input/review posture instead of turning terminal clicks, workflow fills, or suggestion providers into hidden text surgery or hidden execution policy.**

The outside landscape keeps converging on a powerful but still decision-light pattern.
The best products do not merely remember commands.
They make command reuse *editable*, *slot-aware*, and *separately runnable*.
That is exactly the kind of idea Schell should steal.

## 1) Warp keeps proving that saved command reuse works best when it lands in editable input

Warp's workflow docs now make a particularly useful detail explicit.
When a workflow is selected, it is pasted into the active terminal input, its arguments can be cycled with `SHIFT-TAB`, and arguments with the same name can be edited with multiple synced cursors.
That is an excellent Schell clue.
The important move is not “workflow execution.”
The important move is **field-like parameter editing before execution**.
See: https://docs.warp.dev/knowledge-and-collaboration/warp-drive/workflows

## 2) Insert-without-running remains the humane default in modern terminals

VS Code's shell integration docs are valuable here for a subtler reason than sticky scroll.
Its recent-command surface can write text to the terminal without running it, and its quick-fix posture still presents proposal actions around command-local output rather than silently turning every suggestion into a run.
That is exactly the right default law for Schell too.
Parameter fill should usually mean **insert, focus, and let the operator decide**.
See: https://code.visualstudio.com/docs/terminal/shell-integration

## 3) Ghostty reinforces that richer pointer editing only becomes safe inside shell-marked active prompts

Ghostty's shell-integration docs and 1.3.0 release notes keep sharpening the same lesson.
Jump-to-prompt, prompt-local click-to-move, and shell-prompt-local editing become much safer once the shell marks the live prompt region explicitly, and Ghostty now supports the `click_events` / `cl=line` OSC 133 prompt extensions for cursor movement inside active prompts.
That is a strong Schell steal.
But it also tells us where to stop.
**Prompt-local editing should stay inside the active input field, not spread across historical command chapters or arbitrary output.**
See: https://ghostty.org/docs/features/shell-integration ; https://ghostty.org/docs/install/release-notes/1-3-0 ; https://contour-terminal.org/vt-extensions/osc-133-shell-integration/

## 4) fish still shows the best insert-first help posture

fish remains one of the clearest humane precedents.
Its autosuggestions are based on history, completions, and valid file paths, and they do nothing unless the operator accepts them; fish also allows accepting just the next suggested word.
That is exactly the kind of behavior Schell should steal for slot fills and repeated-argument edits.
Helpful fill should be **accept one thing, or one next piece, or nothing at all**.
See: https://fishshell.com/docs/current/interactive.html ; https://fishshell.com/docs/current/tutorial.html

## 5) kitty's keyboard protocol is a reminder that richer input should be opt-in and degradable

The kitty keyboard protocol docs remain one of the best current reminders that richer keyboard/input semantics should be negotiated and backward compatible.
That matters directly for Schell.
If slot cycling, repeated-slot navigation, or finer-grained editing cues need richer key events, Schell should still treat that as an optional capability witness rather than as the universal baseline.
See: https://sw.kovidgoyal.net/kitty/keyboard-protocol/

## 6) Nushell suggests a bounded way to keep metadata rich without forcing a universal data religion

Nushell's metadata docs make a useful distinction:
values can carry tags that improve the user experience without changing the value itself, and ordinary external-command pipelines still use stdin/stdout flows like other shells.
That is a terrific Schell hint.
Parameter-slot provenance, repeated-slot linkage, and workflow-default badges can remain **sidecar metadata over editable input** without deciding that every pipeline or command language artifact has become one giant structured object algebra.
See: https://www.nushell.sh/book/metadata.html ; https://www.nushell.sh/book/pipelines.html

## 7) The stealable move: slot-linked edits in the one true active input

The best current steal now looks like this:
1. one exact chapter or workflow seed lands in active input,
2. typed parameter slots are visible,
3. each slot shows provenance,
4. repeated slots may opt into synced cursors,
5. pointer/key movement inside the active prompt is field-local and shell-marked,
6. and execution remains a separate explicit action.

That is powerful because it makes the shell feel custom and luxurious *at the last safe moment before run*.
It helps real workflows immediately and still keeps the final parser, workflow storage, transport, and renderer open.

## 8) Lessons from the past we should actually keep learning

Past shells and terminals repeatedly made the same mistakes here:
- letting reusable commands collapse into invisible aliases or rc-file folklore,
- letting text replacement quietly perform semantic surgery,
- letting “smart completion” run code or probe the world with more power than reviewed execution,
- and treating history/output text as equally editable with the live prompt.

The better modern lesson is narrower:
**make the active input field smarter, not the whole transcript magically mutable.**

## 9) A compact Schell v0 cluster is enough

A decision-light first cut probably needs only:
- one visible **parameter-slot** family inside active input,
- one **slot provenance** badge family,
- one **synced-slot** posture for repeated parameters,
- one **insert / review / run** split,
- one capability witness for richer click/key behavior,
- and one refusal to perform hidden edits over history, output, or imported snippets.

That is enough to make Schell feel materially better than shell folklore without freezing one final editor engine, workflow marketplace, command-language parser, or keyboard protocol stack.

## 10) Decisions intentionally kept open

This pass does **not** freeze:
- one final parameter-slot serialization format,
- one final active-input editor implementation,
- one final richer keyboard/input protocol,
- one final workflow template syntax,
- one final parser or quoting discipline for reusable commands,
- or one final shared workflow/notebook product shape.

The no-regret move is narrower:
**make parameter fill explicit, field-local, provenance-aware, and separately runnable.**
