# SlopOS datacube evaluation, pass LXXVIII (2026-03-22)

This pass evaluates one new companion import:
**Schell should absolutely grow machine cards, environment passports, host-drift badges, overlay ladders, and hook provenance — but SlopOS pressure says project-environment convenience must remain weaker than exact attested identity, exact reviewed boot/config basis, and explicit post-boot authority seams.**

## 1) SlopOS already gives the right machine-identity lesson: ambient platform fingerprints are not reviewed identity

`microvm-platform-identity-posture-v0.md` says Phase 1 exposes no portable ambient guest-visible platform identity or fingerprinting contract, no portable CPUID vendor/brand/hypervisor-signature plane, and no portable SMBIOS/DMI identity plane.
That maps cleanly onto development-environment folklore.
A Schell machine card should be allowed to summarize host class, runtime class, or imported environment kind.
But it should stay weaker than exact reviewed identity.
“Running in codespace”, “inside devcontainer”, or “on remote Linux host” can be a useful machine card fact without becoming attestation or durable provenance truth.

## 2) SlopOS bootstrap posture says startup convenience is not a hidden control plane

`microvm-bootstrap-metadata-posture-v0.md` keeps guest bootstrap/config on reviewed boot artifacts or explicit post-boot seams rather than hidden metadata channels.
That is the correct companion pressure for shell environments too.
Project environment activation, shell personalization, dotfile imports, and lifecycle hooks can all be useful, but they should not silently become the authoritative source of consequential configuration truth.
If a reviewed action depends on one project environment or one machine footing, that basis should be named explicitly rather than reconstructed from whatever prompt-time helpers happened to fire.

## 3) SlopOS host↔guest and guest-agent postures reject ambient helper folklore

`host-guest-channel-posture-v0.md` rejects ambient host↔guest transports and hidden host channels.
`microvm-guest-agent-posture-v0.md` rejects a portable ambient guest-agent lifecycle/file/admin/metadata/time plane and keeps such helper behavior implementation-local.
That is exactly the pressure Schell needs here.
The shell should not assume that because one environment manager, remote IDE, or container tool can provide setup hooks, file sharing, terminal opens, remote summaries, or localhost forwarding, those conveniences become native shell truth.
Imported comfort should stay visibly imported.

## 4) Exact basis still beats environment mythology

Across the archive, SlopOS keeps insisting that policy-significant meaning rides on exact reviewed basis rather than ambient surrounding folklore.
Applied here, that means Schell should keep several truths separate:
- **machine card truth** — what kind of place this command is running in,
- **environment passport truth** — which project environment spec/lock/activation family is in play,
- **overlay truth** — which user/session/helper layers modified the experience,
- **approval basis truth** — which exact bytes or exact bounded refs were actually reviewed,
- and **attestation/provenance truth** — what stronger evidence says about the execution substrate when such evidence exists.

## 5) The most SlopOS-compatible moves from this seam now look no-regret

The strongest companion-compatible moves are:
- **machine cards** whose summaries stay weaker than attested or reviewed identity,
- **environment passports** that name project spec, lock, activation family, and overlay contributors,
- **host-drift badges** that downgrade strong sameness claims when runtime kind or host footing changes,
- **hook provenance cards** separating host init, runtime init, prompt-time activation, and post-attach personalization,
- **forwarded-localhost / thin-client badges** so remote comfort does not impersonate local execution truth,
- and **compare-ground ladders** that can say same spec / same lock / same runtime kind / same exact footing / unknown without forcing a fake universal portability claim.

## 6) Things this pass still refuses to decide too early

This pass does **not** force:
- one final Schell-native environment schema,
- one final host identity or fingerprint model,
- one final import story for Dev Containers, Codespaces, Nix, Devbox, devenv, or direnv,
- one final overlay algebra for user settings, dotfiles, and project hooks,
- or one final portability verdict engine.

The answer is smaller and stronger:
**treat machine summaries, project environment specs, overlays, and stronger evidence as separate truth families, so Schell can become wonderful at portable comfort without turning imported environment folklore into authoritative sameness.**
