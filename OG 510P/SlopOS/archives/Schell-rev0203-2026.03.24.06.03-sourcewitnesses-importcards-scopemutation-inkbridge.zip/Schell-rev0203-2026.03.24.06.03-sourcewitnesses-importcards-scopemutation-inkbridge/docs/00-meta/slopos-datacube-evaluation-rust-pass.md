# SlopOS datacube evaluation — Rust pass

This pass re-reads SlopOS with two additional lenses:

1. what it teaches Schell about **how to keep design surfaces honest while the OS is still in design**, and
2. what it suggests about **how a Rust implementation should avoid premature stack or crate commitments**.

## What SlopOS is doing unusually well

### 1) It makes ambient-state removal discoverable

The launch-boundary index is especially strong because it turns many small “no ambient default” choices into one reopenable discovery surface.
For Schell, that argues for one compact place where shell/terminal/runtime non-ambient promises stay enumerable.

### 2) It separates request from live state

The background request/live-grant split is exactly the kind of distinction shell projects usually flatten.
For Schell, this should become terminal law: requests, grants, renewals, and receipts are not one thing.

### 3) It preserves posture docs as narrow knives

SlopOS repeatedly uses small posture docs to pin one seam at a time.
That is worth stealing.
It keeps the archive from pretending one giant manifesto is enough.

## What Schell should import carefully

- launch-boundary indexes;
- posture-by-seam docs;
- explicit request/live-state splits;
- profile and posture matrices;
- RFC-first discipline for new knobs.

## What Schell should *not* copy yet

- SlopOS-level schema multiplication before Schell knows its first-class nouns;
- proof-obligation surface area that exceeds the current shell-design evidence;
- implementation-specific commitments disguised as architecture.

## Rust-specific read

SlopOS suggests that Schell's Rust codebase should begin with **few crates and strong seams**, not many crates named after speculative concepts.
Good early crate boundaries would be earned by operator proof surfaces, not by architectural enthusiasm.

The current safest Rust posture is therefore:

- keep the archive richer than the code for now,
- grow code only where a question has entered prototyping,
- prefer instrumentation and exact receipts over early abstraction towers,
- and avoid committing to line editing, PTY, terminal rendering, or async topology until the smallest reviewed interaction is proven.
