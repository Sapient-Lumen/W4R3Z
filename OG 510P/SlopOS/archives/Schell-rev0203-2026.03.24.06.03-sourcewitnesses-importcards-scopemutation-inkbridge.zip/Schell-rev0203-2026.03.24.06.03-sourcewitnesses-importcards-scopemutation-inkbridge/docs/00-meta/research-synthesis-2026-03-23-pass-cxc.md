# Research synthesis — 2026-03-23 — pass CXC

This pass sharpens one smaller lesson from current shells, shell line editors, and terminal history surfaces:
**the shell+terminal gets much more trustworthy when it treats local editing memory as its own family instead of flattening kills, yanks, undo, clipboard paste, and durable history into one residue story.**

## 1) The classic shell stack already proved local edit memory matters

GNU Readline keeps killing and yanking as first-class editing commands.
`yank` inserts the top of the kill ring, and `yank-pop` rotates the ring only after a yank.
That is valuable design pressure because it makes one thing obvious:
**editing memory is not the same thing as command history.**
It is closer to a local composition aid.

zsh sharpens this by exposing the cut buffer and later kill-ring entries directly through ZLE.
The next yank comes from the last killed item, while later entries live in the `killring` array.
That means even a highly scriptable shell keeps local edit residue distinct from the durable submitted-history lane.

## 2) fish and PSReadLine show the modern version of the same lesson

fish still uses an Emacs-style kill ring, with `ctrl-k` to kill text, `ctrl-y` to yank, and `alt-y` to rotate the previous kill.
Its bindable input functions also include `undo` and `redo`, plus a separate `fish_clipboard_copy` helper for the system clipboard.
That separation is great Schell pressure:
**edit-local memory, edit-local undo, and system clipboard egress should not be one object.**

PSReadLine reaches the same conclusion from another angle.
It documents `Undo`, `Redo`, `UndoAll`, and multiple kill-ring-powered word rubout commands, and it keeps `Maximum History Count` separate from `Maximum Kill Ring Count`.
Microsoft even states that PSReadLine history is separate from PowerShell history.
That is one of the clearest current official signals available: the editing surface deserves its own memory policy.

## 3) Terminals add a second warning: paste history may persist residue

The terminal world then adds a smaller but important danger.
iTerm2 keeps a paste history for copied or pasted text, and its preferences allow saving copy/paste history and command history to disk.
That is a brilliant comfort feature in one sense, but it is also a warning.
Once the terminal adds paste history, local composition residue, durable shell history, and disk persistence can start to blur.

Schell should steal the comfort while refusing the blur.
A local kill ring is not the same thing as a paste-history row.
A paste-history row is not the same thing as submitted command history.
And none of those automatically deserve export, sync, or long-lived disk persistence.

## 4) The stealable idea is older than the flashy terminals

A lot of modern shell excitement focuses on AI, command blocks, and semantic marks.
Those are useful.
But classic line editors are still carrying one underrated brilliant idea:
**let the user build and reshape a command safely before it ever becomes history or side effect.**

That suggests a compact Schell stack:
- **edit journals** for grouped undo/redo,
- **kill rings** for short-lived local text memory,
- **paste provenance chips** for foreign ingress,
- **trim-now actions** for local hygiene,
- and **draft shelves** only when the user intentionally promotes text beyond a transient local ring.

## 5) The past lesson Schell should not repeat

The historical trap is letting anything “remembered” look equivalent.
But these memories differ sharply:
- local text cut while composing,
- text pasted from another authority plane,
- text remembered by the terminal,
- and commands already submitted for execution.

When shells or terminals blur those classes, operators lose exactly the information they need for trust and hygiene:
where the text came from,
what surface still remembers it,
and whether it is going to survive locally, durably, or on disk.

## 6) The no-regret Schell move

Schell should add one dedicated surface for:
- edit journals,
- kill rings,
- paste provenance,
- terminal paste-history humility,
- and explicit trim/persist posture.

That imports a genuinely brilliant idea from the old shell/editor world while still refusing to choose one final line editor, one clipboard bridge, one persistence backend, or one sync story too early.

## 7) Compact conclusion

The ecosystem is already paying for the lesson:
undo and yank are local editing powers,
clipboard ingress is foreign text,
terminal paste history is a separate residue surface,
and submitted command history is stronger again.

So the next low-regret Schell seam is **edit journals, kill rings, and paste-history humility**.
