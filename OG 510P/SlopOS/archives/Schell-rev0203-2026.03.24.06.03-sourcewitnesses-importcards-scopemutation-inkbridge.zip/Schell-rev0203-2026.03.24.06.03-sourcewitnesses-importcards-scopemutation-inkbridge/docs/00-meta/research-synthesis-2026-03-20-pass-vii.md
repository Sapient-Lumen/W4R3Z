# Research synthesis — pass VII

This pass asks a more product-shaped question than pass VI:
**which current shell+terminal ideas help Schell become super awesome without creating a second hidden authority plane?**

## Lessons we must learn from the past

### 1) Great terminal UX often fails exactly where provenance becomes fuzzy

Warp's block model is genuinely useful: a block groups a command and its output into one atomic unit and unlocks copy, re-input, bookmarking, and sharing. But Warp's own background-block docs also admit a hard limitation: it may not know which process a given background output came from, and concurrent background writers may mix together. That is a powerful lesson for Schell. Blocks are excellent, but provenance must stay explicit when the terminal is guessing. ([turn710318view2](https://docs.warp.dev/terminal/blocks), [turn710318view3](https://docs.warp.dev/terminal/blocks/background-blocks))

### 2) The shell should tell the terminal where live edit authority exists

Current shell-integration docs across Windows Terminal, WezTerm, Ghostty, iTerm2, and the FinalTerm lineage keep converging on the same win: shells emit prompt/command/output boundaries, and terminals use that to navigate marks, select output, or support prompt-aware editing. That is strong evidence that Schell should make active input a first-class shell-declared field rather than relying on terminal guesswork. ([turn710318view5](https://learn.microsoft.com/en-us/windows/terminal/tutorials/shell-integration), [turn644651view0](https://wezterm.org/shell-integration.html), [turn644651view1](https://ghostty.org/docs/install/release-notes/1-3-0), [turn710318view4](https://iterm2.com/documentation-shell-integration.html), [turn644651view7](https://iterm2.com/3.2/documentation-escape-codes.html))

### 3) Admission and activation are not the same thing

XDG Portal docs keep this distinction crisp. Request responses report when the user interaction is over and the request is carried out, while other portal families like InputCapture distinguish “enabled” from “active” and keep activation under compositor control. Schell should steal that conceptual split: drafted, admitted, running, and active should not blur together. ([turn710318view6](https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Request.html), [turn644651view4](https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.InputCapture.html))

### 4) Scope separation is a real product feature, not just cleanliness

Warp's current agent modality explicitly separates terminal blocks from agent-conversation blocks and keeps commands run inside a conversation scoped to that conversation unless manually attached elsewhere. That is one of the most directly stealable ideas for Schell because it prevents one terminal history from becoming a mush of unrelated authority stories. ([turn644651view5](https://docs.warp.dev/agent-platform/local-agents/interacting-with-agents/agent-modality))

### 5) Saved workflows are better as explicit parameterized artifacts than as ambient aliases

Warp's workflow docs show a compelling pattern: a saved command can be named, described, parameterized, searched, and executed without becoming invisible shell folklore. Schell should likely prefer explicit workflow artifacts over alias-heavy startup magic. ([turn644651view6](https://docs.warp.dev/knowledge-and-collaboration/warp-drive/workflows))

### 6) Trust and confidence still need separate handling

VS Code remains the best current public reminder that command recovery quality and actual shell-backed trust are different dimensions, while recent VS Code work on terminal sandboxing and auto-approval rules is another signal that a modern integrated shell/terminal needs visible authority posture, not just nice parsing. ([turn710318view0](https://code.visualstudio.com/docs/terminal/shell-integration), [turn710318view1](https://code.visualstudio.com/updates/v1_109), [turn614419search4](https://code.visualstudio.com/updates/v1_104))

## Nifty ideas worth stealing now

### Scoped work lanes

Keep distinct lanes for:

- direct terminal commands,
- agent/proposal commands,
- background-output residue,
- receipts and denials,
- and saved workflow artifacts.

Search and navigation can cross these lanes.
Authority should not.

### Active-input lease

The terminal should visually and interactively privilege exactly one live input field at a time.
Clicks, cursor moves, suggestion insertion, and inline editing should work there.
Historical blocks should remain inspectable but non-authoritative.

### Status tags on blocks

Every visible block should clearly say which truth it carries, such as:

- draft,
- shell-reported,
- reviewed,
- running,
- receipt,
- denial,
- background,
- or workflow.

That single move could make a custom terminal feel much more legible.

### Workflow seeds

Let a direct command block or an agent result become a saved workflow artifact, but only through an explicit conversion step that preserves parameters, origin, and trust grade.
Do not silently turn history into ambient aliases.

### Background residue cards

When provenance is weak, the terminal should say “background residue; provenance partial” rather than pretending it knows the exact command owner.
Warp's current limitation is a useful honesty template here. ([turn710318view3](https://docs.warp.dev/terminal/blocks/background-blocks))

### Lane-aware command palette and search

A command palette should search commands, workflows, receipts, denials, and maybe agent conversations, while still showing scope and trust before action.
Ghostty's command palette and Warp's search/workflow surfaces both point toward this. ([turn587772search17](https://ghostty.org/docs/install/release-notes/1-2-0), [turn587772search8](https://docs.warp.dev/terminal/entry/command-search), [turn644651view6](https://docs.warp.dev/knowledge-and-collaboration/warp-drive/workflows))

## Moves that make the custom shell+terminal super awesome

### 1) Make the truth model visible

A semantic inspector remains a huge win, but now it should also reveal scope and status lane, not only prompt/input/output boundaries.

### 2) Let the terminal feel richer only where the shell can back it up

Make the active input field delightful.
Make history precise.
Make background uncertainty visible.
Do not let the delight outrun provenance.

### 3) Give saved command knowledge a real home

Named, parameterized, searchable workflows are more powerful than a pile of aliases and less dangerous than turning the whole terminal into a macro language too early.

### 4) Keep human, agent, and background stories distinct

The shell+terminal becomes much more trustworthy when it never makes the user guess whether a block came from them, from an assistant, or from later background residue.

## Current prototype reading

The next no-regret proving slice is probably:

1. **one active-input field,**
2. **scoped work lanes,**
3. **trust/status tags on blocks,**
4. **explicit workflow artifacts,**
5. **background-residue honesty,**
6. **and transcript-safe fallback when the fancy renderer is gone.**

That would make Schell feel substantially more advanced than legacy shells while still keeping final renderer, transport, and pipeline ontology open.
