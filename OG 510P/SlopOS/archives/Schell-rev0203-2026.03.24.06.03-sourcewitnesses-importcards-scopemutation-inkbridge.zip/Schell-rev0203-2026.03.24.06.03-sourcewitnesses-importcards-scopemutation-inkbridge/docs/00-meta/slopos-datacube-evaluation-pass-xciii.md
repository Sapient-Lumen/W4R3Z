# SlopOS datacube evaluation, pass XCIII (2026-03-22)

This pass evaluates one broad question against the current SlopOS archive:
**what history lessons and stealable shell+terminal luxuries survive the companion's exact-authority posture?**

The main result is crisp:
**SlopOS strongly rewards stealable luxury bundles only when they stay visibly weaker than exact handles, exact reviewed actions, exact mutable basis, and trusted review paths. It also strongly rewards an explicit veto list for the old shell/terminal failure families.**

That means Schell should absolutely steal current terminal brilliance.
It should just steal it in a companion-compatible way.

## 1) SlopOS turns “do not repeat old shell mistakes” into a first-class architecture rule

The companion archive already refuses a long list of shell-like conveniences when they would silently reopen authority:
- no hidden interpreter fallback,
- no late reopen of an executable by mutable name,
- learn mode stays observational,
- approval binds to one exact action on one exact mutable basis,
- and quarantined discovery/preview must remain weaker than explicit safe-open or explicit clear.

That means the old shell failure families are not merely folklore mistakes.
They are exactly the kinds of collapse SlopOS is trying to prevent.

For Schell this implies:
- parser and startup footing should stay explicit,
- previews and suggestions should remain proposal-only,
- and every “magical” affordance should say whether it is exact, derived, guessed, or historical.

## 2) Shell-emitted metadata fits SlopOS unusually well, but only with trust grades

SlopOS keeps trusted review and trusted-path work separate from ordinary render surfaces.
That maps neatly onto modern shell-integration features.
Command marks, cwd updates, exit annotations, pane metadata, and command chapters are excellent imports — but they should not automatically become trusted approval surfaces.

For Schell this implies:
- shell-authenticated marks are good,
- guessed marks are still useful,
- trusted chrome remains a stronger lane,
- and stronger actions should care about provenance rather than only presence.

## 3) Typed routing and smart clicks are companion-compatible only when routes stay named

The companion's OpenURI, powerbox, view, quarantine, and exact-subject boundaries are all pressing in the same direction:
open, reveal, safe-open, handler selection, preview, and execution are different actions and should not be flattened.
This makes current terminal click luxuries highly compatible **if** they become typed routes instead of click folklore.

For Schell this implies:
- semantic-history and cwd-aware resolution are worth stealing,
- captured-output rows and command-linked file references are worth stealing,
- Plan 9 style plumbing remains a strong inspiration,
- but click surfaces should emit typed intent packets and route witnesses rather than jumping directly from visible text to ambient host behavior.

## 4) SlopOS also sharpens the workflow lesson

The companion archive keeps asking for exact authorship, exact mutable basis, explicit leases, and reviewable reuse artifacts.
That pressure fits searchable workflows and richer shell history very well.
It rejects only one thing:
**letting saved commands or historical material silently outrank current review.**

For Schell this implies:
- named workflow seeds are good,
- parameter cards are good,
- per-session chapter history is good,
- searchable captured output is good,
- but insert, review, and run must remain separate actions,
- and historical objects should confess stale basis or weaker authority rather than pretending to be fresh.

## 5) Input-path hygiene is deeply companion-compatible

The companion archive already keeps ingress, selection, clipboard, tty, and promotion surfaces separate.
That means bracketed paste, explicit ingress packets, PTY isolation, and promotion rails are all strongly aligned with SlopOS.
The old “it's just terminal text” posture is not.

For Schell this implies:
- multiline paste should stay one explicit ingress object,
- historical or external text should not silently become active input,
- and terminal/device/input boundaries should stay visible enough that injection risks do not hide inside interactivity.

## 6) The right companion-compatible import shape

This pass therefore recommends three bounded imports.

### A) A must-never-flatten veto list
- hidden reparsing,
- environment/startup authority surprises,
- spoofable metadata promoted to stronger actions,
- heuristic click-to-open escalation,
- ambient input injection,
- and historical/saved workflow objects bypassing fresh review.

### B) A steal-with-honesty luxury list
- shell-authenticated command chapters,
- captured-output decks tied to exact chapters,
- semantic-history-aware object routes,
- typed intent packets,
- first-class WhatIf / compare-after-run posture,
- searchable workflow seeds,
- richer session/chapter history,
- and pane/user-var metadata for local luxury.

### C) A continued refusal list
- one final shell grammar,
- one final routing/plumbing substrate,
- one final workflow engine,
- one final structured-data ontology,
- and one final shell↔terminal transport.

## 7) The compact conclusion

SlopOS is still design-phase, but it already says something load-bearing for Schell:
**be ambitious about operator luxury, and even more explicit about what that luxury is not.**

The companion-compatible shape is not timid.
It is simply disciplined:
steal the nice things,
name the route,
keep trust visible,
and refuse to let derived convenience impersonate exact authority.
