# SlopOS datacube evaluation, pass CI (2026-03-22)

This pass evaluates the SlopOS companion pressure on one narrower seam:
**if Schell steals pointer brilliance, what must SlopOS pressure force it to keep honest about event ownership, typed routes, prompt editing, and exact review sequencing?**

The answer is tighter now.
**SlopOS pressures Schell to treat pointer input as an explicit interaction lane, never as ambient authority and never as a disguised command membrane.**

## 1) D-CAPSHELL pressure says clicks are not “just UI”

The companion already treats shell glue as a privilege-collapse zone.
That pressure does not stop at typed commands.
Prompt clicks, semantic-history clicks, object clicks, wheel gestures, and copy/selection gestures all sit right next to execution and launch.
So the companion lesson is straightforward:
Schell should not treat pointer behavior as harmless chrome just because it arrives through the renderer.

## 2) exact review sequencing stays stronger than pointer convenience

The companion’s exact-exec posture, command-string refusal, word-expansion humility, and local-acceptance-over-imported-claims pressure all point the same way.
A click may:
- select,
- reveal,
- insert,
- move the live prompt cursor,
- or propose a typed route.

But it should not silently:
- choose an executable,
- open something strong under ambient cwd/path assumptions,
- or widen authority just because the object looked obvious to the terminal.

Pointer comfort belongs on the observation/navigation side of the seam.
Exact review and execution still come later.

## 3) event ownership should stay explicit

WezTerm’s mouse-capture model, Ghostty’s shell-integrated prompt click, kitty’s click ladders, and foot’s wheel translation all reinforce one companion-compatible rule:
**the system must say who owned the gesture.**

At minimum Schell should keep separate:
- terminal-local selection,
- shell-authenticated prompt editing,
- application-captured mouse input,
- typed route proposals,
- and stronger reviewed follow-up actions.

That one split preserves a lot of truth.

## 4) typed routes fit the companion far better than generic smart clicks

The companion repeatedly pushes toward typed interfaces, explicit handles, and bounded action ladders.
That means clicked objects should not go straight from visible text to ambient action.
Instead the companion-compatible import is:
- a route card,
- an explicit reveal/open/insert/copy ladder,
- visible basis posture,
- and stronger review if execution or external open is involved.

This fits SlopOS much better than “semantic click folklore” because it preserves handle truth and keeps the shell from laundering renderer guesses into durable action authority.

## 5) wheel and scroll should remain weaker than input authority

foot’s alternate-scroll policy is a very useful reminder for the companion too.
Wheel gestures can become translated keys, app-local input, overlay navigation, or ordinary viewport scrolling depending on posture.
That is precisely why wheel behavior should remain a witnessed compatibility fact rather than a hidden execution-adjacent channel.

The companion pressure is simple:
scroll comfort is valuable, but accidental gestures must stay weak.
They should not become hidden route acceptance, hidden execution confirmation, or hidden command editing outside the shell-authenticated live prompt.

## 6) the clean import is one explicit pointer witness family

The companion-compatible import is to define a witness that can say:
- gesture kind,
- event owner,
- region strength,
- wheel/drag posture,
- route strength,
- transport/hop posture,
- and whether the outcome is observation-only, proposal-only, or review-required.

That is enough to keep the shell+terminal humane without making clicks or wheels part of ambient shell authority.

## 7) Compact conclusion

The strongest SlopOS pressure in this pass is:
**pointer luxury may improve observation, navigation, and live prompt editing, but it must remain weaker than typed reviewed action, weaker than explicit open/attach review, and weaker than exact execution authority.**

That is the right construction rule while both datacubes are still in design.
