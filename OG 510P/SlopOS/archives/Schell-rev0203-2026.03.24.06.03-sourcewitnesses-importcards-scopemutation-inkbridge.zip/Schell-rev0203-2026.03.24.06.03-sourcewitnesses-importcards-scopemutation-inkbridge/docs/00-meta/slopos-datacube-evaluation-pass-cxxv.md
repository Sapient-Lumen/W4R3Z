# SlopOS datacube evaluation, pass CXXV (2026-03-22)

This pass evaluates one narrower question against the current companion archives:
**what do SlopOS, Steward, and ViewFS teach Schell about remote↔local file transfer, landing zones, and archive posture?**

The answer is crisp:
**file transfer should stay a separately named bridge family with chooser-owned admission, lane-separated locality claims, and stronger promotions above ordinary transfer completion.**

## 1) SlopOS keeps rewarding chooser-owned admission and weaker imported evidence

SlopOS repeatedly prefers explicit grants, visible admission basis, revocation-friendly posture, and the rule that imported descriptions stay weaker than locally accepted state.
That pressure maps very well onto file transfer.
A remote peer offering a file is not the same as a locally admitted object.
A saved local file is not the same as a reviewed import object.
A synced/shared/published artifact is stronger again.

So the SlopOS-compatible rule for Schell is:
- keep transfer offers explicit,
- keep landing zones chosen and named,
- keep imported objects weaker than fresh local review until admitted,
- and keep stronger publication/promotions above ordinary transfer completion.

## 2) Steward keeps shell/terminal luxury permissioned and inspectable

Steward's permissioned-chrome pressure suggests that transfer comfort should not look like hidden terminal magic.
A successful-looking badge should still confess whether the move was only proposed, locally admitted, relayed through a helper, archive-wrapped, or fully materialized.
That is exactly the right companion posture for Schell.

## 3) ViewFS keeps locality and lane posture separate

ViewFS has consistently rewarded distinct observe, attach, control, and sideband lanes.
File transfer fits that same lesson.
Path insertion, local save, import-only materialization, remote upload, and publication are different lanes.
The shell should say which one happened.

## 4) Companion-safe no-regret move

Schell does **not** need to choose the final transfer backend, portal story, mux treaty, or import-object store now.
It only needs a few bounded rules:

### A) Keep the bridge family explicit
Offer, approve, land, import, save, attach, publish.

### B) Keep landing zones first-class
Chosen directory, downloads folder, review object, remote destination, or no landing.

### C) Keep archive posture visible
Single file, file set, directory tree, wrapped archive, metadata-preserving, delta-capable.

### D) Keep stronger promotions separate
Sync, share, publish, and durable workflow attachment should not be flattened into “download complete.”

## 5) Compact conclusion

The companion-safe answer is not “file transfer worked, therefore the result is obvious.”
It is:
**treat remote↔local file movement as an explicit bridge with chooser-owned landing, archive posture, relay confession, and stronger promotions above ordinary transfer completion.**
