# Research synthesis — 2026-03-23 — pass CLXXVII

This pass sharpens one fresh lesson from current terminal, shell-integration, testing, and service-state docs:
**the most honest systems do not treat a short quiet window as semantic completion; they separate command markers, local calm, and explicit synchronization/quiescence.**

## 1) VS Code and modern shell integration prove command boundaries are useful, but bounded

VS Code's shell integration docs keep emphasizing command detection, command decorations, command guides, sticky scroll, command-local output selection, and contextual rerun/copy actions.
Recent release notes then add richer command details, output streaming for long-running commands, exact command attachment to chat, and inline output reveal.

That is important evidence for Schell.
Command-aware terminal luxury is real and valuable.
But the product value is still primarily **command-local structure**, not a giant claim that everything semantically quieted just because output paused.

## 2) Ghostty and WezTerm show why command-finished markers are powerful but still marker-level

Ghostty 1.3.0 now offers command-finished notifications with a minimum-duration threshold and says the feature relies on OSC 133 command-execution tracking.
WezTerm's shell integration docs describe OSC 133 zones for Input, Output, and Prompt, plus shell-aware selection and navigation powered by those semantic regions.

That is a strong clue for Schell.
The shell+terminal should absolutely steal command-finished signals, output zones, and command-local navigation.
But these are still **semantic markers emitted through the shell/terminal boundary**, not necessarily a proof that every side effect, flush, or sideband cleanup has ended.

## 3) Playwright's `networkidle` warning is the right cautionary tale

Playwright's official API docs explicitly mark `networkidle` as **discouraged** and say not to use it as the proof that a page is ready for testing.
That is a beautifully transferable lesson.
A short observational quiet window may be useful,
but it is usually too weak to count as the strongest semantic truth.

For Schell this means:
- a few quiet seconds in the terminal are useful,
- but they should not silently become proof of completion, safe snapshot, or explicit quiescence.

## 4) systemd shows what stronger synchronization looks like

systemd's `sd_notify` docs keep `READY=1`, `RELOADING=1`, and `STOPPING=1` as distinct assignments, and `sd_notify_barrier()` explicitly synchronizes against reception of previously sent notifications.
That is the pattern Schell should steal.
If you need a stronger statement than “things look quiet,” you often need an explicit barrier, explicit state transition, or explicit quiesce/drain acknowledgement.

## 5) The no-regret Schell move is a tiny quiescence strip plus a weaker calm window

Putting these together suggests a better next move than smarter replay, stronger hidden automation, or a giant maintenance browser.
Schell should add:
- a tiny **quiescence strip** for a lane, chapter, snapshot candidate, or attach bundle,
- and a weaker **calm window** notion for short observational quiet.

They should say:
- whether output/bytes are still flowing,
- whether a command-finished marker or prompt-return marker exists,
- whether current calm is only a local no-new-activity window,
- whether stronger explicit barrier/quiesce/drain evidence exists,
- and what the strongest honest next move is now.

## 6) Compact conclusion

VS Code proves command-local terminal structure is worth surfacing.
Ghostty and WezTerm prove OSC-133-backed command markers unlock excellent command-finished and output-local affordances.
Playwright proves that a short quiet window is often too weak to count as semantic readiness.
systemd proves that stronger synchronization needs explicit state transitions or barriers.

So the next no-regret Schell seam is not a global idle detector.
It is **quiescence strips, calm windows, and silence-is-not-proof humility** so a stable-looking lane can cheaply say whether it is still flowing, only observationally quiet, marker-finished but drain-unknown, or explicitly quiescent enough for the stronger move the operator is considering.
