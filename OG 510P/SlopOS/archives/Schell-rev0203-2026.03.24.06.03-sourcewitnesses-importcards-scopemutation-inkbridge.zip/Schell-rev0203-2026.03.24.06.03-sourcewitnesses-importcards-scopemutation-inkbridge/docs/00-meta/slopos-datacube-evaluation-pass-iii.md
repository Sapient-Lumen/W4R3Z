# SlopOS datacube evaluation — pass III

This pass re-opens SlopOS with a stricter question:
what should Schell import from a design-phase sibling **because it reduces future confusion**, and what should it **not** import yet because it would freeze the wrong layer?

## What SlopOS is already teaching well

### 1) Discovery surfaces are architecture

The `capshell-launch-boundary-index.md` surface is one of the strongest ideas in the uploaded SlopOS archive.
It turns many small no-ambient promises into one discovery surface.
For Schell, the lesson is not “copy that exact file.”
The lesson is: when many narrow boundary docs jointly define meaning, add a **closed-set discovery surface** so operators and future maintainers can see the whole seam at once.

### 2) Request state and live state must not collapse

SlopOS is unusually careful about background requests versus live grants.
That is a deep operator-UX lesson for Schell.
If the shell ever surfaces long-running or deferred work, it should preserve at least:

- what was requested,
- what is live now,
- why the live state differs,
- and what receipt or denial last changed that state.

This is a much better ontology than reusing `jobs`, `bg`, and `fg` vocabulary and silently pretending it still means the same thing.

### 3) Small posture docs can beat giant umbrella claims

SlopOS keeps many seams narrow: command strings, word expansion, cwd, env, handle tables, learn mode, wallet posture, portal posture, and output normal form are all pinned separately.
That is healthy archive behavior in a design phase, because it keeps revisions falsifiable.
For Schell, the import is not the exact schema mass.
The import is the habit of making one seam explicit at a time.

### 4) Lint density is part of design honesty

SlopOS's tool surface is a reminder that “still designing” is not a license for drift.
For Schell, this supports continuing to treat lint and release sync as product surfaces, not housekeeping.

## What Schell should import carefully, not wholesale

### Import the discipline, not the full schema mass

SlopOS can afford many architecture singleton docs because it is also defining an operating environment.
Schell is defining a shell plus a humane operator path.
If Schell mirrors every singleton surface too early, the archive may become precise in the wrong places and vague in the operator-critical ones.

### Do not let names travel farther than evidence

`capshell`, `wallet`, `portal`, `lease`, and `ordering token` are useful pressures.
They are not yet reasons to commit Schell to a one-to-one naming mirror.
Schell should preserve local names until the first interaction proofs and transcript forms stabilize.

### Do not let archive completeness outrun humane proof

SlopOS is strongest when it narrows ambient seams.
Schell must do that too.
But Schell also has a unique burden: it has to prove that the strict path can still feel humane.
So each import from SlopOS should answer one of these:

- does this reduce ambient ambiguity?
- does this improve review honesty?
- does this improve transcript truth?
- does this improve operator recovery?

If the answer is no, hold it.

## Current Schell import stance after this pass

### Keep importing

- closed-set discovery/index surfaces,
- request-state versus live-state splits,
- explicit denial and receipt seams,
- portal-shaped exact-artifact mediation pressure,
- narrow posture docs for one seam at a time,
- and lint-gated release truth.

### Keep refusing

- one-to-one schema mirroring,
- premature vocabulary lock-in,
- giant adjunct forests before the first reviewed interaction is proven,
- and any archive move that makes the operator story harder to see.

## New local law suggested by this pass

Every Schell surface that touches terminal UX should state which layer it constrains:

- **shell truth**,
- **semantic transport**,
- or **local luxury UX**.

That keeps SlopOS-style boundary rigor while preventing terminal ambition from quietly becoming correctness law.
