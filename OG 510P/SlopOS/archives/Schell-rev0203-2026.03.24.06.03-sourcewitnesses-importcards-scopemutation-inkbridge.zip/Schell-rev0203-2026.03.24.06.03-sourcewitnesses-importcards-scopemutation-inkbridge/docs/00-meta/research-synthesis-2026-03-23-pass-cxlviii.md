# Research synthesis — 2026-03-23 — pass CXLVIII

This pass sharpens the next narrower lesson from current shell+terminal tools:
**continuity gets much safer and more useful when every remembered, saved, preserved, or restored thing advertises the strongest honest next verb it still supports instead of one flattering generic “resume” claim.**

That points to a good next Schell move:
**revivability grades** rather than one more session mythology.

## 1) VS Code proves continuity is already at least two different products

VS Code's current terminal docs make a crucial distinction inside “persistent sessions”.
They separate **process reconnection** from **process revive**.
Reconnection means reconnecting to the previous process after a window reload.
Revive means restoring content and relaunching the process with its original environment after restarting VS Code.
The same docs also expose session detach/attach commands.

That is an excellent Schell clue.
Even before getting fancy, continuity already has different strength classes:
- reconnect live runtime,
- relaunch equivalent process,
- reattach explicit session.

So the right product move is not a generic resume button.
It is a small ladder of stronger and weaker continuation verbs.

See:
- https://code.visualstudio.com/docs/terminal/advanced

## 2) Zellij proves restored rooms can be truthful when rerun stays gated

Zellij's session resurrection docs are unusually instructive.
By default, sessions are serialized and kept in cache for later recreation.
Zellij can serialize layout and command identity, and optionally viewport and scrollback too.
Most importantly, resurrected commands do **not** run immediately; they sit behind a visible “Press `ENTER` to run...” banner.

That gives Schell two clean clues:
- restoration depth should be explicit,
- and restored command identity should default to review-gated rerun rather than implicit continuation.

See:
- https://zellij.dev/documentation/session-resurrection.html

## 3) tmux-resurrect proves users want total continuity — and its changelog shows where the line gets dangerous

The tmux-resurrect README still aims high: it restores sessions, panes, working directories, layouts, active panes, and even programs running within panes.
That ambition is a real signal — operators deeply want continuity.
But its current changelog is even more revealing: the project removed the deprecated “restoring shell history” feature.

That is a superb Schell lesson from the past.
Restoration can overreach.
The system should preserve useful residue and relaunch posture, but some forms of shell-state resurrection are close enough to execution authority that they stop being harmless continuity.

See:
- https://github.com/tmux-plugins/tmux-resurrect
- https://github.com/tmux-plugins/tmux-resurrect/blob/master/CHANGELOG.md

## 4) kitty and WezTerm prove saved project shape is a different class from live continuity

kitty sessions are simple text files that define windows, tabs, layouts, working directory, and what programs to run.
WezTerm workspaces group windows under a named workspace, let windows exist in inactive workspaces, and expose launcher-based switching among current workspaces.
These are excellent luxuries.
But they are not the same kind of thing.
kitty session files are saved launch artifacts.
WezTerm workspaces are live multiplexer groupings that can be switched and surfaced.

That is exactly the Schell clue.
A continuity surface should separate:
- live attachable rooms,
- switchable workspace groups,
- and relaunchable saved project shapes.

See:
- https://sw.kovidgoyal.net/kitty/sessions/
- https://wezterm.org/recipes/workspaces.html

## 5) Warp proves the safer reusable default is often “insert for editing,” not “execute”

Warp's current docs keep pushing a gentle but important pattern.
Launch Configurations save the arrangement of windows, tabs, and panes for fast project reopen.
Saved prompts paste into the active terminal input, show relevant descriptions and arguments, and can be adjusted before running.
YAML workflows remain parameterized, searchable, and even repo-scoped.

That is a very strong Schell clue.
Reusable artifacts should advertise different strongest verbs:
- some are `relaunchable`,
- some are `insertable`,
- and only a smaller subset should become `review-rerunnable`.

See:
- https://docs.warp.dev/terminal/sessions/launch-configurations
- https://docs.warp.dev/knowledge-and-collaboration/warp-drive/prompts
- https://docs.warp.dev/terminal/entry/yaml-workflows

## 6) Shell integration should help reacquire footing, not overclaim it

Current VS Code shell integration docs say the terminal can understand more of what is happening inside the shell, enabling working-directory detection, command detection, decorations, and navigation.
Ghostty's shell integration and config docs show the same pattern: prompt marks enable jump-to-prompt, cursor-click-to-move, prompt-aware close confirmation, correct prompt redraw, working-directory inheritance, and command-finish notifications.

That is the right continuity clue.
Semantic prompt and command marks are ideal **reacquisition tools**.
They help the operator locate the live prompt and understand current footing after reentry.
They should not, by themselves, turn historical or restored residue into current truth.

See:
- https://code.visualstudio.com/docs/terminal/shell-integration
- https://ghostty.org/docs/features/shell-integration
- https://ghostty.org/docs/config/reference

## 7) Atuin and zoxide prove remembered state should degrade, not disappear or lie

Atuin records command, directory, time, duration, exit code, hostname+user, and shell session, and its TUI can either execute immediately or insert for editing.
It also supports filter modes such as host, current directory, and current session, plus history and cwd filters.
zoxide's docs make the ranking logic explainable with frecency, aging, pruning, and query modes that list results and print scores.

That is a great Schell clue.
Remembered state should keep usefulness as it ages, but the strongest honest verb should decay with drift.
A remembered row may start life as `review-rerunnable` and later fall back to `insertable` or `inspect-only`.

See:
- https://docs.atuin.sh/cli/guide/basic-usage/
- https://docs.atuin.sh/cli/configuration/config/
- https://man.archlinux.org/man/zoxide-query.1.en
- https://github.com/ajeetdsouza/zoxide/wiki/Algorithm

## 8) Compact conclusion

Current tools keep converging on one helpful design answer.
The next no-regret shell+terminal import is not “better sessions.”
It is a compact **revivability ladder** that separates:
- `attach live`,
- `reconnect runtime`,
- `restore view`,
- `review rerun`,
- `relaunch from kit`,
- `insert for editing`,
- `inspect only`,
- and `start clean`.

That bundle would let Schell steal the best current ideas in continuity, session management, workspaces, workflows, and semantic reentry without pretending all old context is equally alive.
