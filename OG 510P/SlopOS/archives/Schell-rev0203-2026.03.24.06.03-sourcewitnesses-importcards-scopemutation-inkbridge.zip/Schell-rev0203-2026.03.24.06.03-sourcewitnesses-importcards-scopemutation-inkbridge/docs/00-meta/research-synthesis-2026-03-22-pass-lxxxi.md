# Research synthesis, pass LXXXI (2026-03-22)

This pass keeps one fresh design rule in focus:
**Schell should steal the best current history, correction, and retry moves — edit-buffer reload, undo/redo, scoped recall, ranked history search, typo help, and correction assistants — but it should keep historical command recall, correction proposals, recents, restored state, and exact approved action separately named so “I saw this before” never impersonates “I freshly reviewed this exact action now.”**

This seam matters because command history is where shell UX often feels most magical and most misleading at the same time.
The current ecosystem proves that users love fast recall, fuzzy search, one-key correction, and retry help.
It also keeps proving that recalled commands are easy to over-trust, that auto-correction can widen effects faster than users realize, and that recents/history often blur together with exact current intent.

## 1) Bash and zsh already contain one of the best old lessons: reload into the edit buffer first

Bash still documents two especially strong safety levers.
If `histverify` is enabled, history substitution is **not** immediately passed to the shell parser; the expanded line is reloaded into the Readline buffer for further editing.
If `histreedit` is enabled, a failed history expansion is also reloaded into the editing buffer for correction.
Bash’s `fc` builtin reinforces the same idea from another angle: it can open prior commands in an editor, then echo and execute the edited result.
See: https://www.gnu.org/software/bash/manual/bash.html

zsh keeps a very similar safety rail.
Its `HIST_VERIFY` option says that after history expansion the shell should reload the line into the editing buffer rather than executing it directly.
The same manual also keeps `CORRECT` and `CORRECT_ALL` separate spelling-correction features instead of pretending the shell already knew the exact intended command.
See: https://zsh.sourceforge.io/Doc/Release/Options.html and https://zsh.sourceforge.io/Doc/Release/Shell-Builtin-Commands.html

That is one of the strongest lessons Schell must learn from the past:
**history and correction are safest when they return editable proposals rather than silently becoming execution authority.**

## 2) Current line editors prove that local undo/redo quality is worth stealing directly

Current shells still undersell how much quality-of-life comes from strong local line editing.
fish exposes `undo` and `redo` editing functions, token-sensitive history search, and command-buffer editing helpers.
Its release notes also say undo history is no longer truncated after every command but kept for the lifetime of the shell process.
zsh’s line editor goes even further by exposing `UNDO_CHANGE_NO`, `UNDO_LIMIT_NO`, incremental undo/redo, and an explicit `split-undo` command.
PSReadLine documents `Undo`, `Redo`, and `UndoAll`, and it also exposes APIs where insert/delete/replace operations are treated as single undoable actions.
See: https://fishshell.com/docs/current/cmds/bind.html ; https://fishshell.com/docs/current/interactive.html ; https://fishshell.com/docs/4.0b1/relnotes.html ; https://zsh.sourceforge.io/Doc/Release/Zsh-Line-Editor.html ; and https://learn.microsoft.com/en-us/powershell/module/psreadline/about/about_psreadline_functions?view=powershell-7.5

The stealable idea here is not just “support undo.”
It is: **make command composition feel like editing a durable local object, with visible undo anchors and grouped changes, before anything graduates to reviewed execution.**

## 3) Scoped history search is now clearly good enough to steal

Modern history tools now prove that recall should be scoped, not ambient.
fish supports token-sensitive history search and multiple search modes.
Atuin’s TUI can filter history by all hosts, only the local machine, the current directory, or the current shell session.
Atuin also records extra command context such as directory, time, duration, exit code, hostname/user, and session.
See: https://fishshell.com/docs/current/interactive.html ; https://fishshell.com/docs/current/cmds/history.html ; https://docs.atuin.sh/cli/guide/basic-usage/ ; and https://docs.atuin.sh/cli/guide/getting-started/

That is a brilliant pattern for Schell.
A recalled command should arrive with scope cards like host / project / directory / session / imported / restored / unknown.
A custom shell+terminal can feel super awesome here without inventing one giant synced-memory architecture.

## 4) Good tools separate “insert for editing” from “run now” — and that distinction is worth preserving

Atuin is unusually clear about this.
Its current docs say that in the TUI, `Enter` can immediately execute a command while `Tab` inserts it into the shell for editing, and users can flip the behavior so `Enter` edits instead of runs.
That is a compact but very powerful design clue.
See: https://docs.atuin.sh/cli/guide/basic-usage/ and https://docs.atuin.sh/cli/faq/

PSReadLine exposes a parallel clue from a different angle.
It has `AcceptSuggestion` and `AcceptNextSuggestionWord`, but it also exposes `AddToHistory(string command)` without executing it.
That suggests Schell should treat history insertion, suggestion acceptance, and execution as three distinct rails.
See: https://learn.microsoft.com/en-us/powershell/module/psreadline/about/about_psreadline_functions?view=powershell-7.5

## 5) Auto-correction remains useful, but blind rerun should stay visibly stronger than ordinary correction

zsh still documents `CORRECT` and `CORRECT_ALL`, which shows that spelling correction remains a real shell desire.
But correction helpers also show the danger of overreach.
The Fuck’s README still recommends startup aliasing through shell rc files, says it creates a new command from a matched rule and executes it, and documents a `--yeah` option for running fixed commands without confirmation.
See: https://zsh.sourceforge.io/Doc/Release/Options.html and https://github.com/nvbn/thefuck

That is a terrific cautionary import for Schell.
Correction is worth stealing.
Blind correction should become an explicitly stronger posture with obvious badges, diff previews, and fresh approval rather than being flattened into ordinary retry comfort.

## 6) History itself is richer than most shells admit, but it should stay weaker than exact rerun basis

fish’s history tools are a useful reminder that history is not only recall.
The current docs say `history append` can add commands without executing them, `history delete` can interactively remove items, `history clear-session` can clear just the current session, and `fish_history` can be changed so a session uses another history name or disables storage altogether.
The docs even note that alternate history names are often used to avoid leaking sensitive history when giving a presentation.
See: https://fishshell.com/docs/current/cmds/history.html

That suggests another no-regret Schell move:
**history should behave more like an explicit wallet with scoped compartments and exact deletion classes, not a monolithic forever-log pretending to be the current basis of truth.**

## 7) What Schell should now do

This pass points to a compact, high-value retry and correction model:
- **history-ground cards** for where a recalled command came from,
- **scope chips** for host / project / directory / session / imported / restored,
- **edit-return by default** for recalled or corrected commands,
- **exact diff previews** from typed text to proposed correction,
- **undo anchors** for grouped input transforms,
- **retry rails** that distinguish copy-to-input, stage-for-review, and rerun-now,
- **history-wallet controls** for local/session/private/redacted storage,
- **safe correction ladders** where correction stays suggestion-first,
- and **rerun-basis hold cards** when historical commands are being reused against changed surroundings.

## 8) Decisions intentionally kept open

This pass does **not** freeze:
- one final history storage backend,
- one final sync model,
- one final correction engine,
- one final command-diff language,
- one final retry receipt format,
- or one final policy for imported/shared history.

The no-regret move is smaller:
**give Schell edit-first recall, scoped history truth, explicit correction ladders, undo anchors, and safe retry rails so memory becomes luxurious without pretending history, recents, or restored state are self-justifying authority.**
