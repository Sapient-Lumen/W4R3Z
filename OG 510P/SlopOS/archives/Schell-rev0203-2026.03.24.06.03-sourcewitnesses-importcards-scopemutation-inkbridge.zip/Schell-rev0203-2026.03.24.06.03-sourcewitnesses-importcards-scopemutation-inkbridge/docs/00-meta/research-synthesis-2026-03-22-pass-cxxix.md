# Research synthesis, pass CXXIX (2026-03-22)

This pass keeps one narrower lesson explicit:
**workflow luxury should land in review, not skip straight to execution.**

The current ecosystem keeps converging on that lesson from several directions.
Warp's workflow docs say selecting a workflow pastes it into the active input editor, shows names, descriptions, and arguments, and lets the operator adjust arguments or the command itself before running.
VS Code's shell-integration and API docs keep command truth graded: command lines have confidence levels, stronger trust only appears when the shell explicitly reports the command and nonce-verifies it, and recent updates also keep tool-run commands out of ordinary shell history when the shell integration path is working.
iTerm2's captured-output docs make rich post-command browsing feel wonderful, but they also admit that activating captured output can send text as though typed, which is a perfect reminder that discovered output and live execution should stay separately named.
Ghostty 1.3.0 keeps investing in shell integration and quick-terminal comfort, while its quick-terminal docs still preserve runtime state between appearances rather than pretending that hidden state is a durable reviewed artifact.
Nushell keeps proving that richer structure can be humane, while fish keeps proving that predictive recall and cross-session convenience can feel magical enough to become ambient if they are not fenced.
PowerShell's transcript docs still remind us that even when a shell claims transcript truth, host/output ordering can get subtle, so transcript luxury and exact execution truth still need explicit seams.

Taken together, the design-phase lesson for Schell is straightforward:

## 1) Reusable command comfort is absolutely worth stealing

A humane shell+terminal should absolutely support:
- searchable workflow seeds,
- visible arguments and defaults,
- chapter-linked captured-output decks,
- command blocks with source/trust badges,
- quick summon / cockpit entry,
- and easy insert-or-review landings.

## 2) But workflow discovery is weaker than reviewed action

Selecting a saved command, clicking a captured row, or accepting a suggested workflow should not itself count as execution authority.
The safe luxury is:
- land in editable input,
- or land in an explicit review card,
- and only then rise into execution.

## 3) Learn mode should teach, not widen

The nicest current products often blur suggestion, recall, and execution.
Schell should steal the comfort while keeping stronger discipline:
- show what authority is missing,
- show what exact basis drifted,
- show why a route was denied,
- but keep the report observational-only until a fresh reviewed action is admitted.

## 4) Saved automation needs exact footing

A reusable shell artifact still needs to say:
- which exact command chapter or source produced it,
- which interpreter or exec object it expects,
- which wallet / authority baseline it assumes,
- whether the current peer/ground still matches,
- and whether it is operator-authored, imported, proposal-lane, or tool-generated.

## 5) Compact answer

Schell does **not** need a final workflow engine, policy synthesizer, or notebook architecture next.
It only needs one bounded move:
- reviewed workflow seeds,
- command chapters with trustworthy source badges,
- wallet-strip and diff-card context for automation,
- observational learn reports,
- and a rule that search/click/recall comfort stays weaker than fresh reviewed execution.
