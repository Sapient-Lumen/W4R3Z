# Research synthesis, pass CXXVIII (2026-03-22)

This pass keeps one narrower lesson explicit:
**visual certainty, commit certainty, and review certainty are different things.**

The current terminal ecosystem keeps converging on that lesson from multiple directions.
Ghostty 1.3.0 changed IME preedit rendering to underlines for readability, updated its grapheme break algorithm to match the Unicode spec exactly, and fixed wide grapheme-cluster rendering cases.
Ghostty's feature docs also say multi-codepoint emoji and some right-to-left grapheme clusters render correctly while the terminal still only supports left-to-right text.
WezTerm's changelog says Wayland `zwp_text_input_v3` enables IME when the compositor supports it, and its FAQ still reminds operators that terminals operate on byte streams and that inspecting emitted bytes with `xxd` is often the right debugging move.
kitty's changelog records fixes where pre-edit text and formatting characters produced surprising local behavior.
Unicode UAX #9 keeps bidi ordering and explicit formatting characters separate from stored text, and UTS #39 keeps confusable detection as an explicit mechanism rather than assuming rendered similarity is safe enough.

Taken together, the design-phase lesson for Schell is straightforward:

## 1) Rich local shaping is worth stealing

A humane shell+terminal should absolutely support:
- readable IME preedit,
- grapheme-aware cursoring,
- good fallback fonts,
- variation-selector correctness,
- better layout-aware input,
- and stricter render honesty when ambiguity rises.

## 2) But local visual calm is still weaker than committed text

A screen can look settled while:
- composition is still active,
- the buffer has not yet received final committed text,
- width/shape rules remain renderer-local,
- or rendered order differs from exact order.

## 3) And committed text is still weaker than reviewed exact basis

Even after commit, Schell still needs the option to reveal:
- exact bytes/scalars,
- bidi controls,
- confusable risk,
- display alias versus inserted text,
- and width/renderer mismatch posture.

## 4) Compact answer

Schell does **not** need to solve full international text truth next.
It only needs one bounded move:
- a text-shape witness,
- a commit-window strip,
- a strict-review toggle,
- and a rule that authority rises from visible shape to committed buffer to exact reviewed basis rather than jumping straight from “looked fine” to “safe enough.”
