# ADR 0001: Schell uses datacube discipline from day one

## Status

Accepted

## Context

A shell project can easily dissolve into snippets, implementation dreams, and compatibility trivia with no durable control surface.

## Decision

Schell will start as a revisioned datacube with:
- canonical docs,
- RFC and ADR surfaces,
- a release manifest,
- a revision receipt,
- a surface-status ledger,
- assumption and followthrough ledgers,
- and an archive index.

## Consequences

- More discipline and overhead immediately.
- Better continuity across human/LLM sessions.
- Clearer frozen public releases.
