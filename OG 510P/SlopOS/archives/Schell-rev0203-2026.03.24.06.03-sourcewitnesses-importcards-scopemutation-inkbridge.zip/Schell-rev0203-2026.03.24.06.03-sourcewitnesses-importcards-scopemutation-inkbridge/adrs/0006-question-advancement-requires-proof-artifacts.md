# ADR 0006: question advancement requires proof artifacts

## Status
Accepted

## Context
Schell now carries a question machine.
That machine only stays honest if question-state changes correspond to sharper proof surfaces rather than narrative optimism.

## Decision
A question should normally advance only when the revision also sharpens at least one concrete proof artifact:

- a new or revised proof surface document,
- a more specific followthrough item,
- a transcript/prototype artifact,
- or a stricter discharge condition.

## Consequences
This keeps question movement slow enough to mean something and prevents the datacube from performing progress through vocabulary alone.
