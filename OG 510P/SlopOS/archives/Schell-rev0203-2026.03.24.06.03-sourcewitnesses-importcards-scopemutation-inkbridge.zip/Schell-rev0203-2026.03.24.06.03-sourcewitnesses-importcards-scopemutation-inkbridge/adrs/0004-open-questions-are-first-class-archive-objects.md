# ADR 0004: Open questions are first-class archive objects

## Status

Accepted.

## Context

Schell is still early enough that the most dangerous failure mode is answering major design questions accidentally through accumulation, mood, or implementation drift.

## Decision

Load-bearing unanswered questions must live in a durable registry with states, next proof surfaces, and discharge rules.
They are not just prose in meeting notes.

## Consequences

- The archive gains more explicit uncertainty management.
- Design movement becomes easier to audit.
- A little more ledger overhead is accepted in exchange for slower, more honest convergence.
