# ADR 0000: title

## Status

Accepted / Superseded / Withdrawn

## Context

## Decision

## Consequences
