# ADR 0002: session lineage is first-class

## Status

Accepted

## Context

Command history alone is too thin for replay, approval tracing, or postmortem analysis.

## Decision

Schell treats session lineage as a first-class design object from the bootstrap phase onward.

## Consequences

- Future implementation work must preserve command and session identifiers.
- Receipts become load-bearing design objects, not optional logging garnish.
- Simpler history-only designs remain possible for compatibility modes, but not as the whole truth of Schell.
