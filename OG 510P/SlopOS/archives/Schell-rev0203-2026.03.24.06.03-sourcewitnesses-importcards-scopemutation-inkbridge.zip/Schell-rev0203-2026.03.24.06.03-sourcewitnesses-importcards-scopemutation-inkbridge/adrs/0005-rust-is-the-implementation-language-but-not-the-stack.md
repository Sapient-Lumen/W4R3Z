# ADR 0005: Rust is the implementation language, but not the stack

## Status

Accepted.

## Context

The project now has an explicit implementation-language preference from the user, but the shell, terminal, and protocol design remain in research mode.

## Decision

Schell will be implemented in Rust.
This decision does not settle the line editor, TUI stack, PTY strategy, async runtime, serialization format, or plugin story.

## Consequences

- Implementation sketches can begin in a language aligned with the project's safety and systems pressure.
- The archive must keep the rest of the implementation stack explicitly reversible until prototype pressure earns narrower commitments.
