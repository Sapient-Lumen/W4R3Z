# ADR 0003: defer language freeze until a reviewed interaction is proven

## Status

Accepted

## Context

Schell is being designed under pressure from SlopOS, which is itself still in design phase.
The archive can already see strong negative constraints around ambient authority, expansion, backgrounding, and receipts.
But it does not yet have enough evidence to freeze a final shell language, compatibility story, or host-language embedding strategy.

## Decision

Schell will not freeze major surface-language commitments until at least one small reviewed interaction is proven humane enough to beat a bash-style alternative.
The current proving target is recorded in `rfcs/0004-smallest-reviewed-action.md`.

## Consequences

- More design restraint in the near term.
- More emphasis on terminal UX, receipt design, and denial teaching.
- Fewer premature commitments around syntax, embedding, and compatibility.
