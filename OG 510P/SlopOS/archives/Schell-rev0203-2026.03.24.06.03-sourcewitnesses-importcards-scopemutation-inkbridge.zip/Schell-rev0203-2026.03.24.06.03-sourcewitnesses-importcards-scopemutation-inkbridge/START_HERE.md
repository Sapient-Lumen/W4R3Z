# Schell: start here (for maintainers, including LLMs)

Schell is a **shell+terminal design datacube for SlopOS**.


Current head focus: source witnesses, import cards, and scope-mutation humility: keep executed script, sourced file, autoloaded function, imported module/overlay, current-scope environment mutation, and exact reviewed basis visibly separate so file-loading comfort never quietly becomes hidden shell truth.

Read first for this seam:

- `docs/80-terminal/source-witnesses-import-cards-and-scope-mutation-humility.md`
- `docs/00-meta/research-synthesis-2026-03-24-pass-cc.md`
- `docs/00-meta/slopos-datacube-evaluation-pass-cc.md`
- `docs/80-terminal/option-witnesses-strictness-scopes-and-startup-mode-humility.md`
- `docs/00-meta/research-synthesis-2026-03-24-pass-cxcix.md`
- `docs/00-meta/slopos-datacube-evaluation-pass-cxcix.md`
- `docs/80-terminal/substitution-witnesses-capture-residue-and-helper-sidecar-humility.md`
- `docs/00-meta/research-synthesis-2026-03-24-pass-cxcviii.md`
- `docs/00-meta/slopos-datacube-evaluation-pass-cxcviii.md`
