# Contributing

## Editing rules

1. Prefer extending existing surfaces over creating new top-level files.
2. Every nontrivial design ratchet should land in one of:
   - an RFC,
   - an ADR,
   - a canonical doc under `docs/`,
   - a durable ledger if the move is about status, assumption, followthrough, foreign pressure, or questions,
   - or a tool check if the move is about archive hygiene.
3. Keep speculative ideas in `docs/90-quarantine/` until they earn promotion.
4. Update `CHANGELOG.md`, `ARCHIVE_INDEX.md`, `RELEASE-MANIFEST.json`, `REVISION-RECEIPT.json`, and `SURFACE-STATUS.json` together.
5. Update `QUESTION-REGISTRY.json` whenever a load-bearing unanswered question is introduced, narrowed, split, or discharged.
6. Run `make lint` before packaging.
7. Do not silently widen scope from “shell” to “OS”, “agent platform”, or “full language runtime” without an explicit RFC and trajectory-map change.
8. Do not treat the Rust decision as permission to settle the implementation stack without a matching question entry, RFC, or prototype need.
