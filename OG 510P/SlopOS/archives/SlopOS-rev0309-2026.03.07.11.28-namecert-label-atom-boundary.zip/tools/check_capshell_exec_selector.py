#!/usr/bin/env python3
"""CI drift gate: capshell exec selector is explicit/unique and non-ambient.

Intent
------
Executable selection is a classic ambient-authority seam (PATH search).
This gate keeps the v0 posture pinned:
- validators require exactly one CH-ARGV `role="exec"` selector for `capshell.exec`
- no ambient PATH resolution
- minimal_context knob does not redundantly restate exec selection

This check is intentionally conservative and string-based.
"""

from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def read(rel: str) -> str:
    p = ROOT / rel
    if not p.exists():
        die(f"missing required file: {rel}")
    return p.read_text(encoding="utf-8")


def die(msg: str) -> None:
    print(f"[execsel] FAIL: {msg}", file=sys.stderr)
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[execsel] OK: {msg}")


def require_contains(rel: str, needle: str) -> None:
    txt = read(rel)
    if needle not in txt:
        die(f"{rel} missing required text: {needle!r}")


def require_not_contains(rel: str, needle: str) -> None:
    txt = read(rel)
    if needle in txt:
        die(f"{rel} must not contain: {needle!r}")


def line_containing(rel: str, token: str) -> str:
    for ln in read(rel).splitlines():
        if token in ln:
            return ln
    die(f"{rel} missing line containing: {token!r}")
    raise AssertionError  # unreachable


def main() -> int:
    # Posture doc exists + is discoverable.
    posture = "docs/30-architecture/capshell-exec-selector-posture-v0.md"
    if not (ROOT / posture).exists():
        die("missing capshell exec selector posture doc")
    require_contains("docs/README.md", "capshell-exec-selector-posture-v0.md")

    # Core schema/control docs: explicit + unique selector and no ambient PATH.
    require_contains(
        "docs/30-architecture/argv-schema-v0.md",
        "Validators MUST require **exactly one** `role=\"exec\"` token",
    )
    require_contains(
        "docs/70-llm-control/acp-validator-semantics.md",
        "validators MUST require **exactly one** `desc` token with `role=\"exec\"`",
    )
    require_contains(
        "docs/70-llm-control/acp-action-kind-registry.md",
        "validators require **exactly one** `desc` token with `role=\"exec\"`",
    )
    require_contains(
        "docs/20-assurance/invariant-registry.md",
        "See `docs/30-architecture/capshell-exec-selector-posture-v0.md`",
    )
    # PO anchor includes uniqueness explicitly.
    require_contains(
        "docs/20-assurance/proof-obligation-registry.md",
        "validators require **exactly one** executable selector",
    )

    # Minimal-context knob should not carry exec selection (avoid duplication + drift).
    require_not_contains("docs/30-architecture/config-toggle-registry.md", "role=\"exec\"")
    require_not_contains("docs/30-architecture/profile-workflow-defaults.md", "role=\"exec\"")

    minctx_i = line_containing("docs/20-assurance/invariant-registry.md", "I-CAPSHELL-MINCTX-1")
    if "role=\"exec\"" in minctx_i:
        die("I-CAPSHELL-MINCTX-1 must not restate exec selector requirements")

    minctx_po = line_containing("docs/20-assurance/proof-obligation-registry.md", "PO-CAPSHELL-MINCTX-ENF")
    if "role=\"exec\"" in minctx_po:
        die("PO-CAPSHELL-MINCTX-ENF must not restate exec selector requirements")

    ok("capshell exec selector posture is pinned (explicit/unique; no ambient PATH)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
