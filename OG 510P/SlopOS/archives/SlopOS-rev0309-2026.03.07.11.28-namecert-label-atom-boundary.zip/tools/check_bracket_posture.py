#!/usr/bin/env python3
"""CI drift gate: pin D-BRACKET v0 posture (borrowed-mode default; task-local scoped privilege; deny-only call-chain)."""
from __future__ import annotations
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOC = ROOT / 'docs/30-architecture/bracket-posture-v0.md'
EVID = 'EVID-2026-294'

DISCOVERY_SURFACES = {
    ROOT / 'README.md': ['bracket-posture-v0.md'],
    ROOT / 'docs/README.md': ['30-architecture/bracket-posture-v0.md'],
    ROOT / 'docs/30-architecture/posture-index.md': ['bracket-posture-v0.md'],
    ROOT / 'docs/00-meta/profile-posture-matrix.md': ['30-architecture/bracket-posture-v0.md'],
    ROOT / 'docs/00-meta/resolved-history.md': ['bracket-posture-v0.md'],
    ROOT / 'docs/00-meta/llm-runbook.md': ['docs/30-architecture/bracket-posture-v0.md'],
    ROOT / 'docs/30-architecture/decision-map.md': ['bracket-posture-v0.md', 'borrowed-mode default'],
    ROOT / 'docs/30-architecture/mechanisms.md': ['bracket-posture-v0.md', 'task/request-local dynamic scope', 'privileged block'],
    ROOT / 'rfcs/0118-privilege-bracketing-and-call-chain-contexts.md': ['bracket-posture-v0.md', 'task/request-local dynamic scope', 'no portable stack inspection'],
    ROOT / 'docs/30-architecture/call-chain-schema-v0.md': ['bracket-posture-v0.md'],
    ROOT / 'docs/30-architecture/request-context-schema-v1.md': ['bracket-posture-v0.md'],
}


def fail(msg: str) -> None:
    print(f'[bracket-posture] FAIL: {msg}')
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f'[bracket-posture] OK: {msg}')


def read(p: Path) -> str:
    return p.read_text(encoding='utf-8')


def main() -> None:
    if not DOC.exists():
        fail('missing docs/30-architecture/bracket-posture-v0.md')

    doc_txt = read(DOC)
    for tok in [
        'D-BRACKET',
        'CH-CALLCHAIN',
        'CH-REQCTX v1',
        'D-REQCTX',
        'D-CAPSHELL',
        'D-PLUMB',
        'D-SEAL',
        'D-FCELL',
        'I-BRACKET-1',
        'I-BRACKET-2',
        'I-BRACKET-3',
        'I-CALLCHAIN-1',
        'I-REQCTX-4',
        'PO-CALLCHAIN-VALIDATE',
        'PO-BRACKET-SCOPE',
        'Phase 1',
    ]:
        if tok not in doc_txt:
            fail(f'posture doc does not mention required anchor token: {tok}')

    for ph in [
        'Optional runtime guardrail, never an authority source',
        'Borrowed mode is the default at inbound trust boundaries',
        'Bracketing state is task/request-local dynamic scope, not an ambient global/thread toggle',
        'Privileged blocks are explicit, minimal, and exception-safe',
        'Bracketing remains veto-only: no self-elevation, no hidden capability minting',
        'CH-CALLCHAIN stays bounded, optional, and non-authoritative',
        'Cross-task and long-lived work must be explicit, not inherited by accident',
        'No portable stack inspection or kernel enforcement in v0',
        'No new workflow / ACP / conflict-key family surface in v0',
        'no new conflict-key family is introduced in v0',
        'Sealed compat remains killable and non-ambient',
    ]:
        if ph not in doc_txt:
            fail(f'posture doc missing required v0 scope phrase: {ph}')

    for ref in [
        'REF-CONFUSED-DEPUTY',
        'REF-JAVA-STACKINSPECT',
        'REF-JAVA-ACCESSCONTROLLER',
        'REF-JAVA-DOPRIVILEGED',
        'REF-OPENJDK-SCOPEDVALUES',
        'REF-PEP-567',
        'REF-PY-CONTEXTVARS',
    ]:
        if ref not in doc_txt:
            fail(f'posture doc must cite {ref}')

    missing = []
    for p, needles in DISCOVERY_SURFACES.items():
        if not p.exists():
            fail(f'missing discovery surface: {p}')
        txt = read(p)
        if not any(n in txt for n in needles):
            missing.append(str(p.relative_to(ROOT)))
    if missing:
        fail('posture doc not referenced from discovery surfaces: ' + ', '.join(missing))

    evid_idx = ROOT / 'docs/00-meta/evidence-index.md'
    if EVID not in read(evid_idx):
        fail(f'evidence-index does not register required evidence hook: {EVID}')

    tools = ROOT / 'tools/README.md'
    if 'check_bracket_posture.py' not in read(tools):
        fail('tools/README.md must mention check_bracket_posture.py')

    ok('D-BRACKET v0 posture is pinned and discoverable (borrowed-mode default, task-local scoped privilege, deny-only call-chain, no workflow/ACP surface)')


if __name__ == '__main__':
    main()
