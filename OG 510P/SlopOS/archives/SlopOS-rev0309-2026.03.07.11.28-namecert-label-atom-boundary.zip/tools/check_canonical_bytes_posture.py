#!/usr/bin/env python3
"""CI drift gate: pin the v0 meaning of the bytes hashed by `digest(CH-XYZ vN)`.

Why this exists
--------------
D-HASH pins the hash algorithm/length, but that alone is insufficient: implementations
also need an unambiguous definition of *which bytes* are hashed.

This gate keeps D-ENC honest by requiring a small, discoverable posture doc that
pins canonical bytes for schema instances, and wiring it into the main seams.

Checks (fail closed):
- The posture doc exists: docs/30-architecture/schema-canonical-bytes-v0.md
- It is discoverable (docs/README.md) and must-read (llm-runbook)
- It is referenced from:
  - docs/30-architecture/encoding-policy.md
  - docs/30-architecture/decision-map.md (D-ENC)
  - docs/30-architecture/profile-hash-suite-v0.md
  - docs/30-architecture/conflict-key-derivation-registry.md
- The posture doc states deterministic CBOR encoding and cites primary refs.

Design constraints: tiny, dependency-free, deterministic.
"""

from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

DOC = ROOT / "docs/30-architecture/schema-canonical-bytes-v0.md"
DOCS_README = ROOT / "docs/README.md"
RUNBOOK = ROOT / "docs/00-meta/llm-runbook.md"
ENC_POLICY = ROOT / "docs/30-architecture/encoding-policy.md"
DECISIONS = ROOT / "docs/30-architecture/decision-map.md"
HASHSUITE = ROOT / "docs/30-architecture/profile-hash-suite-v0.md"
CKDERIVE = ROOT / "docs/30-architecture/conflict-key-derivation-registry.md"


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def fail(msg: str) -> None:
    print(f"[canon-bytes] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[canon-bytes] OK: {msg}")


def must_read_contains(path: str) -> bool:
    rb = read(RUNBOOK)
    return f"`{path}`" in rb


def main() -> None:
    for p, label in [
        (DOC, "schema-canonical-bytes-v0.md"),
        (DOCS_README, "docs/README.md"),
        (RUNBOOK, "llm-runbook.md"),
        (ENC_POLICY, "encoding-policy.md"),
        (DECISIONS, "decision-map.md"),
        (HASHSUITE, "profile-hash-suite-v0.md"),
        (CKDERIVE, "conflict-key-derivation-registry.md"),
    ]:
        if not p.exists():
            fail(f"missing required file: {label}")

    dr = read(DOCS_README)
    if "schema-canonical-bytes-v0.md" not in dr:
        fail("docs/README.md does not reference schema-canonical-bytes-v0.md")

    if not must_read_contains("docs/30-architecture/schema-canonical-bytes-v0.md"):
        fail("llm-runbook must-read set does not include docs/30-architecture/schema-canonical-bytes-v0.md")

    if "schema-canonical-bytes-v0.md" not in read(ENC_POLICY):
        fail("encoding-policy.md does not reference schema-canonical-bytes-v0.md")

    dmap = read(DECISIONS)
    if "D-ENC" not in dmap or "schema-canonical-bytes-v0.md" not in dmap:
        fail("decision-map.md missing D-ENC reference or missing link to schema-canonical-bytes-v0.md")

    if "schema-canonical-bytes-v0.md" not in read(HASHSUITE):
        fail("profile-hash-suite-v0.md does not reference schema-canonical-bytes-v0.md")

    if "schema-canonical-bytes-v0.md" not in read(CKDERIVE):
        fail("conflict-key-derivation-registry.md does not reference schema-canonical-bytes-v0.md")

    txt = read(DOC)

    # Core normative signals.
    required_phrases = [
        "Deterministically Encoded CBOR",
        "digest(CH-",
        "canonical_bytes",
        "REF-CBOR-RFC8949",
        "REF-JCS-RFC8785",
    ]
    for ph in required_phrases:
        if ph not in txt:
            fail(f"schema-canonical-bytes-v0.md missing required phrase/token: {ph}")

    # Ensure the doc mentions fail-closed posture.
    if not re.search(r"fail\s+closed", txt, flags=re.IGNORECASE):
        fail("schema-canonical-bytes-v0.md does not mention fail closed")

    ok("canonical-bytes posture is present and wired (discoverable + referenced from core seams)")


if __name__ == "__main__":
    main()
