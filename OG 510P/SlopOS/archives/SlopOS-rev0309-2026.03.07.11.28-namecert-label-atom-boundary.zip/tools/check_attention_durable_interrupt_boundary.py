#!/usr/bin/env python3
"""Drift gate for the D-ATTN durable-interrupt boundary (OQ-0005 resolution).

Pins the rule that CH-NOTIF remains an ephemeral request seam and that any
future durable interruption semantics must live in a separate RFC-first surface
rather than widening `importance="urgent"` or delivery outcomes in place.
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BOUNDARY = ROOT / "docs/30-architecture/attention-durable-interrupt-boundary-v0.md"
DOCS_README = ROOT / "docs/README.md"
RUNBOOK = ROOT / "docs/00-meta/llm-runbook.md"
POSTURE = ROOT / "docs/30-architecture/attention-lease-posture-v0.md"
NOTIF = ROOT / "docs/30-architecture/notification-request-schema-v0.md"
RFC = ROOT / "rfcs/0055-attention-authority-and-notifications.md"
DECISION = ROOT / "docs/30-architecture/decision-map.md"
TRAJ = ROOT / "docs/00-meta/trajectory-map.md"
EVID = ROOT / "docs/00-meta/evidence-index.md"
TOOLS = ROOT / "tools/README.md"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def die(msg: str) -> None:
    print(f"ERROR: {msg}", file=sys.stderr)
    raise SystemExit(1)


def require(text: str, needle: str, label: str) -> None:
    if needle not in text:
        die(f"{label} missing required text: {needle}")


def main() -> int:
    boundary = read(BOUNDARY)
    for needle in (
        'resolve **OQ-0005**',
        'CH-NOTIF stays ephemeral',
        'No in-place widening of CH-NOTIF into interruption authority',
        'separate RFC-first descriptor/lease surface',
        'non-ambient and policy-killable',
        'REF-XDG-PORTAL-NOTIFICATION',
        'REF-ANDROID-NOTIF-CHANNELS',
        'REF-APPLE-CRITICAL-ALERTS',
    ):
        require(boundary, needle, BOUNDARY.name)

    require(read(DOCS_README), 'attention-durable-interrupt-boundary-v0.md', DOCS_README.name)
    require(read(RUNBOOK), 'attention-durable-interrupt-boundary-v0.md', RUNBOOK.name)
    for path in (POSTURE, NOTIF, RFC, DECISION, TRAJ):
        require(read(path), 'attention-durable-interrupt-boundary-v0.md', path.name)

    traj = read(TRAJ)
    if '## Open questions (tracked as decision surfaces)' not in traj:
        die('trajectory map missing Open questions heading')
    open_section = traj.split('## Open questions (tracked as decision surfaces)', 1)[1]
    if 'OQ-0005' in open_section:
        die('OQ-0005 still appears in the open-questions section')
    require(traj, '**OQ-0005 D-ATTN durable-interrupt boundary**', TRAJ.name)

    evid = read(EVID)
    require(evid, 'EVID-2026-268', EVID.name)
    require(evid, 'tools/check_attention_durable_interrupt_boundary.py', EVID.name)
    require(read(TOOLS), 'check_attention_durable_interrupt_boundary.py', TOOLS.name)

    print('[attention-durable-boundary] OK: CH-NOTIF stays ephemeral; any durable interrupt semantics must live in a separate RFC-first surface')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
