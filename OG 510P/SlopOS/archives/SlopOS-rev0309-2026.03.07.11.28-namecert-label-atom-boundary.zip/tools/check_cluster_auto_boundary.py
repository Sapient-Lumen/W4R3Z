#!/usr/bin/env python3
"""Drift gate for the Phase 1 cluster auto-boundary (narrowing OQ-0001)."""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BOUNDARY = ROOT / "docs/30-architecture/cluster-auto-boundary-v0.md"
CLUSTER = ROOT / "docs/30-architecture/cluster-derivation.md"
MULTICORE = ROOT / "docs/30-architecture/multicore-architecture-options.md"
DECISION = ROOT / "docs/30-architecture/decision-map.md"
DOCS_README = ROOT / "docs/README.md"
RUNBOOK = ROOT / "docs/00-meta/llm-runbook.md"
TRAJ = ROOT / "docs/00-meta/trajectory-map.md"
BIB = ROOT / "docs/00-meta/bibliography.md"
EVID = ROOT / "docs/00-meta/evidence-index.md"
TOOLS = ROOT / "tools/README.md"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def die(msg: str) -> None:
    print(f"ERROR: {msg}", file=sys.stderr)
    raise SystemExit(1)


def require(text: str, needle: str, label: str) -> None:
    if needle not in text:
        die(f"{label} missing required text: {needle}")


def main() -> int:
    boundary = read(BOUNDARY)
    for needle in (
        'narrow **OQ-0001**',
        'When `preferred_boundary = auto`, CH-CLUSTERMAP derivation MUST choose the first fully-known boundary in this order:',
        '1. `numa`',
        '2. `socket`',
        '3. `core_group`',
        '`die` is **not** an auto-selected boundary in Phase 1',
        '`die` remains an **explicit-policy-only** boundary',
        'REF-HWLOC-OBJTYPES',
        'REF-LINUX-NUMA',
        'REF-ACPI-PPTT',
    ):
        require(boundary, needle, BOUNDARY.name)

    cluster = read(CLUSTER)
    require(cluster, 'cluster-auto-boundary-v0.md', CLUSTER.name)
    require(cluster, '`numa` > `socket` > `core_group`', CLUSTER.name)
    require(cluster, '`die` is **not** auto-selected in Phase 1', CLUSTER.name)

    require(read(MULTICORE), 'cluster-auto-boundary-v0.md', MULTICORE.name)
    require(read(DECISION), 'cluster-auto-boundary-v0.md', DECISION.name)
    require(read(DOCS_README), 'cluster-auto-boundary-v0.md', DOCS_README.name)
    require(read(RUNBOOK), 'cluster-auto-boundary-v0.md', RUNBOOK.name)

    traj = read(TRAJ)
    require(traj, '**OQ-0001 Hybrid follow-ups (ADR-0005)**', TRAJ.name)
    require(traj, 'cluster-auto-boundary-v0.md', TRAJ.name)
    require(traj, 'NUMA → socket → core_group', TRAJ.name)

    bib = read(BIB)
    for needle in ('REF-HWLOC-OBJTYPES', 'REF-LINUX-NUMA', 'REF-ACPI-PPTT'):
        require(bib, needle, BIB.name)

    evid = read(EVID)
    require(evid, 'EVID-2026-259', EVID.name)
    require(evid, 'tools/check_cluster_auto_boundary.py', EVID.name)
    require(read(TOOLS), 'check_cluster_auto_boundary.py', TOOLS.name)

    print('[cluster-auto-boundary] OK: Phase 1 auto clustering stays NUMA→socket→core_group; die remains explicit-policy-only')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
