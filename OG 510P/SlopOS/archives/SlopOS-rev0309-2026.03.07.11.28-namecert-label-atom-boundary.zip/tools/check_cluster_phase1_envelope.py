#!/usr/bin/env python3
"""Drift gate for the Phase 1 Hybrid/multicore claim envelope."""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BOUNDARY = ROOT / "docs/30-architecture/cluster-phase1-envelope-v0.md"
MULTICORE = ROOT / "docs/30-architecture/multicore-architecture-options.md"
CLUSTER = ROOT / "docs/30-architecture/cluster-derivation.md"
CLUSTER_AUTO = ROOT / "docs/30-architecture/cluster-auto-boundary-v0.md"
DECISION = ROOT / "docs/30-architecture/decision-map.md"
PROOF = ROOT / "docs/40-verification/minimum-viable-proof-slice.md"
NONCLAIMS = ROOT / "docs/20-assurance/non-claims.md"
DOCS_README = ROOT / "docs/README.md"
RUNBOOK = ROOT / "docs/00-meta/llm-runbook.md"
TRAJ = ROOT / "docs/00-meta/trajectory-map.md"
EVID = ROOT / "docs/00-meta/evidence-index.md"
TOOLS = ROOT / "tools/README.md"
CHANGELOG = ROOT / "CHANGELOG.md"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def die(msg: str) -> None:
    print(f"ERROR: {msg}", file=sys.stderr)
    raise SystemExit(1)


def require(text: str, needle: str, label: str) -> None:
    if needle not in text:
        die(f"{label} missing required text: {needle}")


def main() -> int:
    boundary = read(BOUNDARY)
    for needle in (
        'narrow **OQ-0001**',
        'Phase 1 flagship multicore claim',
        'Total logical CPUs',
        '<= 64',
        'Cluster count',
        '<= 8',
        'Per-cluster size',
        '<= 16',
        'explicit non-claims',
        'REF-MULTIKERNEL-SOSP09',
        'REF-SEL4-BIGLOCK-APSYS15',
        'EVID-2026-267',
    ):
        require(boundary, needle, BOUNDARY.name)

    require(read(MULTICORE), 'cluster-phase1-envelope-v0.md', MULTICORE.name)
    cluster = read(CLUSTER)
    require(cluster, 'cluster-phase1-envelope-v0.md', CLUSTER.name)
    require(cluster, '<=16', CLUSTER.name)
    require(read(CLUSTER_AUTO), 'cluster-phase1-envelope-v0.md', CLUSTER_AUTO.name)
    require(read(DECISION), 'cluster-phase1-envelope-v0.md', DECISION.name)
    require(read(PROOF), 'cluster-phase1-envelope-v0.md', PROOF.name)
    require(read(NONCLAIMS), 'cluster-phase1-envelope-v0.md', NONCLAIMS.name)
    require(read(DOCS_README), 'cluster-phase1-envelope-v0.md', DOCS_README.name)
    require(read(RUNBOOK), 'docs/30-architecture/cluster-phase1-envelope-v0.md', RUNBOOK.name)

    traj = read(TRAJ)
    require(traj, '**OQ-0001 Hybrid follow-ups (ADR-0005)**', TRAJ.name)
    require(traj, 'cluster-phase1-envelope-v0.md', TRAJ.name)
    require(traj, '<=64 logical CPUs', TRAJ.name)
    require(traj, '<=8 clusters', TRAJ.name)
    require(traj, '<=16 logical CPUs per cluster', TRAJ.name)

    evid = read(EVID)
    require(evid, 'EVID-2026-267', EVID.name)
    require(evid, 'tools/check_cluster_phase1_envelope.py', EVID.name)
    require(read(TOOLS), 'check_cluster_phase1_envelope.py', TOOLS.name)

    ch = read(CHANGELOG)
    require(ch, '## Revised258 (2026-03-06)', CHANGELOG.name)
    require(ch, 'cluster-phase1-envelope-v0.md', CHANGELOG.name)

    print('[cluster-phase1-envelope] OK: Phase 1 Hybrid/multicore claims stay within <=64 logical CPUs, <=8 clusters, <=16 logical CPUs per cluster')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
