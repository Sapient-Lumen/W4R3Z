#!/usr/bin/env python3
"""Drift gate for the capshell result-sidecar boundary (OQ-0007 resolution).

Pins the rule that the replay-stable `capshell.exec` result remains the
CH-AREF digest set under CH-EFFCON `contract_id`, while any richer named-output
or telemetry structure must live in a separate digest-referenced sidecar.
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BOUNDARY = ROOT / "docs/30-architecture/capshell-result-sidecar-boundary-v0.md"
DOCS_README = ROOT / "docs/README.md"
RUNBOOK = ROOT / "docs/00-meta/llm-runbook.md"
OUTPUT_NF = ROOT / "docs/30-architecture/capshell-output-normal-form-v0.md"
ACPOUT = ROOT / "docs/30-architecture/acp-outcome-receipt-schema-v0.md"
DECISION = ROOT / "docs/30-architecture/decision-map.md"
TRAJ = ROOT / "docs/00-meta/trajectory-map.md"
EVID = ROOT / "docs/00-meta/evidence-index.md"
TOOLS = ROOT / "tools/README.md"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def die(msg: str) -> None:
    print(f"ERROR: {msg}", file=sys.stderr)
    raise SystemExit(1)


def require(text: str, needle: str, label: str) -> None:
    if needle not in text:
        die(f"{label} missing required text: {needle}")


def main() -> int:
    boundary = read(BOUNDARY)
    for needle in (
        'resolve **OQ-0007**',
        'canonical replay result stays a digest-addressed output set',
        'No richer result structure is smuggled into existing core seams',
        'separate sidecar descriptor',
        'Named outputs stay labels, not ambient reopen selectors',
        'Telemetry sidecars are observational only',
        'REF-REAPI-PROTO',
        'REF-OCI-DESCRIPTOR',
        'REF-OTEL-PROCESS-METRICS',
    ):
        require(boundary, needle, BOUNDARY.name)

    require(read(DOCS_README), 'capshell-result-sidecar-boundary-v0.md', DOCS_README.name)
    require(read(RUNBOOK), 'capshell-result-sidecar-boundary-v0.md', RUNBOOK.name)
    for path in (OUTPUT_NF, ACPOUT, DECISION):
        require(read(path), 'capshell-result-sidecar-boundary-v0.md', path.name)

    traj = read(TRAJ)
    require(traj, '**OQ-0007 capshell result evolution boundary**', TRAJ.name)
    if '## Open questions (tracked as decision surfaces)' not in traj:
        die('trajectory map missing Open questions heading')
    open_section = traj.split('## Open questions (tracked as decision surfaces)', 1)[1]
    if 'OQ-0007' in open_section:
        die('OQ-0007 still appears in the open-questions section')

    evid = read(EVID)
    require(evid, 'EVID-2026-256', EVID.name)
    require(evid, 'tools/check_capshell_result_sidecar_boundary.py', EVID.name)
    require(read(TOOLS), 'check_capshell_result_sidecar_boundary.py', TOOLS.name)

    print('[capshell-result-boundary] OK: capshell replay result stays CH-AREF-digest based; richer result structure must live in a separate sidecar')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
