#!/usr/bin/env python3
"""CI drift gate: keep retry/dedupe outcomes distinguishable on the stable receipt surface.

Why this exists
--------------
D-RETRYSAFE requires duplicate suppression *before* effects for kinds marked
at-least-once-safe. If suppression is only described in prose or only visible
in implementation-specific logs, the system drifts:
- tooling can't reliably tell "applied" vs "suppressed" under retries,
- audits become ambiguous,
- and LLM-driven edits tend to reintroduce ad-hoc outcome strings.

This guardrail enforces a minimal, low-noise contract:
- CH-ACPOUT v0 includes an optional closed `effect` field with value
  `duplicate_suppressed`.
- ACP validator semantics and the ACP kind registry explicitly reference the
  `duplicate_suppressed` marker.
- PO-RETRY-DEDUP mentions the marker to keep proof/evidence surfaces wired.
- evidence-index registers this drift gate.

Design: conservative string anchors only (CI-friendly; fail-closed).
"""

from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def die(msg: str) -> None:
    print(f"[acp-outcome-effect] FAIL: {msg}", file=sys.stderr)
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[acp-outcome-effect] OK: {msg}")


def main() -> int:
    schema = ROOT / "docs/30-architecture/acp-outcome-receipt-schema-v0.md"
    sem = ROOT / "docs/70-llm-control/acp-validator-semantics.md"
    kinds = ROOT / "docs/70-llm-control/acp-action-kind-registry.md"
    po = ROOT / "docs/20-assurance/proof-obligation-registry.md"
    evid = ROOT / "docs/00-meta/evidence-index.md"

    for p in (schema, sem, kinds, po, evid):
        if not p.exists():
            die(f"missing required file: {p.relative_to(ROOT)}")

    s = read(schema)
    need_schema = [
        "effect?:",
        "Effect status values",
        "duplicate_suppressed",
        "Consumers MUST treat a missing `effect` on `accept` as `applied`",
    ]
    missing = [x for x in need_schema if x not in s]
    if missing:
        die("CH-ACPOUT schema missing required anchor(s): " + ", ".join(missing))
    ok("CH-ACPOUT schema includes effect status anchors")

    sem_txt = read(sem)
    if "duplicate_suppressed" not in sem_txt or "CH-ACPOUT" not in sem_txt:
        die("acp-validator-semantics.md must reference CH-ACPOUT effect=duplicate_suppressed for deduped accepts")
    ok("ACP validator semantics references duplicate_suppressed")

    kinds_txt = read(kinds)
    if "duplicate_suppressed" not in kinds_txt or "CH-ACPOUT" not in kinds_txt:
        die("acp-action-kind-registry.md must reference CH-ACPOUT effect=duplicate_suppressed in receipt obligations")
    ok("ACP kind registry references duplicate_suppressed")

    po_txt = read(po)
    if "PO-RETRY-DEDUP" not in po_txt:
        die("proof-obligation-registry.md missing PO-RETRY-DEDUP")
    if "duplicate_suppressed" not in po_txt:
        die("PO-RETRY-DEDUP must mention effect=duplicate_suppressed to keep retry evidence wired")
    ok("PO-RETRY-DEDUP mentions duplicate_suppressed")

    evid_txt = read(evid)
    if "EVID-2026-182" not in evid_txt or "tools/check_acp_outcome_effect_status.py" not in evid_txt:
        die("evidence-index.md missing EVID-2026-182 entry pointing at this tool")
    ok("Evidence index includes EVID-2026-182")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
