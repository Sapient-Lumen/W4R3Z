#!/usr/bin/env python3
from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


@dataclass
class Problem:
    path: Path
    detail: str


def strip_code_fences(txt: str) -> str:
    out: list[str] = []
    in_fence = False
    for line in txt.splitlines():
        if line.strip().startswith("```"):
            in_fence = not in_fence
            continue
        if not in_fence:
            out.append(line)
    return "\n".join(out)


def parse_kind_table() -> tuple[list[dict[str, str]], list[Problem]]:
    reg = ROOT / "docs/70-llm-control/acp-action-kind-registry.md"
    if not reg.exists():
        return [], [Problem(reg, "missing acp-action-kind-registry.md")]

    txt = strip_code_fences(reg.read_text(encoding="utf-8"))
    lines = txt.splitlines()

    header_idx = None
    for i, ln in enumerate(lines):
        if ln.strip().startswith("| Kind |"):
            header_idx = i
            break
    if header_idx is None:
        return [], [Problem(reg, "ACP kind registry table header not found")]

    rows: list[str] = []
    for ln in lines[header_idx + 2 :]:
        if not ln.strip().startswith("|"):
            break
        if ln.strip() == "|":
            break
        rows.append(ln)

    parsed: list[dict[str, str]] = []
    problems: list[Problem] = []
    for ln in rows:
        parts = [p.strip() for p in ln.strip().strip("|").split("|")]
        if len(parts) != 8:
            problems.append(Problem(reg, f"ACP kind table row must have 8 columns; got {len(parts)}: {ln.strip()}"))
            continue
        parsed.append({
            "kind": parts[0],
            "owner": parts[1],
            "conflict": parts[2],
            "commute": parts[3],
            "retry": parts[4],
            "witness": parts[5],
            "serializes": parts[6],
            "profiles": parts[7],
        })
    return parsed, problems


def normalize_cell(s : str) -> str:
    s = s.strip()
    if s.startswith("`") and s.endswith("`") and len(s) >= 2:
        s = s[1:-1].strip()
    return s


def main() -> int:
    kinds, problems = parse_kind_table()
    reg_path = ROOT / "docs/70-llm-control/acp-action-kind-registry.md"

    pat = re.compile(r"^(validator|svc:[A-Za-z0-9._/-]+)$")

    for row in kinds:
        kind = normalize_cell(row["kind"]).strip("`")
        stance = row["commute"].lower()
        ordered = "ordered" in stance

        ser_raw = normalize_cell(row["serializes"])
        ser = ser_raw.lower()

        if ordered:
            if not ser or ser == "none":
                problems.append(Problem(reg_path, f"kind {kind} is ordered but Serialization boundary is none/empty"))
            elif not pat.fullmatch(ser_raw):
                problems.append(Problem(reg_path, f"kind {kind} has non-canonical Serialization boundary: {row['serializes']}"))
        else:
            if ser != "none":
                problems.append(Problem(reg_path, f"kind {kind} is not ordered but Serialization boundary is not none (got {row['serializes']})"))
    if problems:
        print("ACP serialization-boundary check failed:\n")
        for pr in problems:
            rel = pr.path
            try:
                rel = pr.path.relative_to(ROOT)
            except Exception:
                pass
            print(f"- {rel}: {pr.detail}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
