#!/usr/bin/env python3
"""CI drift gate: keep sealed-compat escape-suite spec wired and discoverable.

Rationale
---------
Sealed compatibility (D-FCELL / D-RUMPK) is only as honest as its negative tests.
AC-071 specifically calls out “ambient host effects” escapes; this suite is the
minimum regression surface that prevents the membrane from drifting into prose.

This guardrail is intentionally narrow:
- Requires the escape suite spec to exist and be indexed in docs/README.
- Requires AC-071 and the compat POs to reference the suite's EVID hook.
- Requires the evidence index to register the suite and this drift gate.

Fail-closed: missing wiring fails CI.
"""

from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def fail(msg: str) -> int:
    print(f"[compat-escape-suite] FAIL: {msg}")
    return 1


def ok(msg: str) -> None:
    print(f"[compat-escape-suite] OK: {msg}")


def main() -> int:
    suite = ROOT / "docs/40-verification/foreign-cell-escape-suite-v0.md"
    docs_readme = ROOT / "docs/README.md"
    abuse = ROOT / "docs/10-threat-model/abuse-cases.md"
    poreg = ROOT / "docs/20-assurance/proof-obligation-registry.md"
    evid = ROOT / "docs/00-meta/evidence-index.md"
    tools_readme = ROOT / "tools/README.md"

    for p in (suite, docs_readme, abuse, poreg, evid, tools_readme):
        if not p.exists():
            return fail(f"missing required file: {p.relative_to(ROOT)}")

    # 1) Spec has required anchors.
    s = read(suite)
    must = [
        "AC-071",
        "PO-COMPAT-NOAMBIENT",
        "PO-COMPAT-CLOSESET",
        "posix.open_via_doc_portal",
        "posix.socket_via_net_portal",
        "cfg.params.lane.fcell",
        "cfg.params.lane.portal.net",
        "cfg.params.lane.portal.file",
        "EVID-2026-206",
    ]
    missing = [m for m in must if m not in s]
    if missing:
        return fail(f"escape suite spec missing anchor(s): {', '.join(missing)}")
    ok("escape suite spec contains required anchors")

    # 2) docs index includes it.
    if "40-verification/foreign-cell-escape-suite-v0.md" not in read(docs_readme):
        return fail("docs/README.md missing link to foreign-cell-escape-suite-v0.md")
    ok("docs/README.md links the escape suite spec")

    # 3) AC-071 references the suite (or its EVID hook).
    a = read(abuse)
    if "AC-071" not in a:
        return fail("abuse-cases.md missing AC-071 section")
    if "foreign-cell-escape-suite-v0.md" not in a and "EVID-2026-206" not in a:
        return fail("AC-071 must reference the escape suite spec or EVID-2026-206")
    ok("AC-071 references the escape suite")

    # 4) Compat proof obligations name the EVID seed.
    p = read(poreg)
    for po in ("PO-COMPAT-CLOSESET", "PO-COMPAT-NOAMBIENT"):
        if po not in p:
            return fail(f"proof-obligation-registry.md missing {po}")
    if "PO-COMPAT-CLOSESET" in p and "EVID-2026-206" not in p:
        return fail("compat proof obligations must cite EVID-2026-206")
    ok("compat proof obligations cite EVID-2026-206")

    # 5) Evidence index registers both the suite and this drift gate.
    e = read(evid)
    if "EVID-2026-206" not in e or "foreign-cell-escape-suite-v0.md" not in e:
        return fail("evidence-index.md missing EVID-2026-206 entry pointing at escape suite")
    if "EVID-2026-207" not in e or "tools/check_compat_escape_suite_wiring.py" not in e:
        return fail("evidence-index.md missing EVID-2026-207 entry pointing at this tool")
    ok("evidence index registers EVID-2026-206 and EVID-2026-207")

    # 6) tools/README mentions this drift gate.
    if "check_compat_escape_suite_wiring.py" not in read(tools_readme):
        return fail("tools/README.md missing entry for check_compat_escape_suite_wiring.py")
    ok("tools/README mentions the drift gate")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
