#!/usr/bin/env python3
"""CI drift gate: pin D-APPSECRET v0 posture (minimal app-seed; not a vault).

Why this exists
---------------
Application secrets are a high-entropy seam:
- "per-app secret seed" quietly widens into a named key/value store,
- collection/item/label semantics sneak in from desktop keyrings,
- rotation becomes an ambient background behavior instead of an explicit decision,
- automation paths appear before replay/scope/redaction answers are nailed down,
- and profile defaults drift until the seam stops meaning one coherent thing.

This guardrail keeps Phase 1 small and honest:
- app secrets are a minimal per-app seed seam,
- not a vault or named secret inventory,
- `scope="profile"` is the expected default posture,
- no silent auto-rotation,
- and no ACP automation kind in v0.
"""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOC = ROOT / 'docs/30-architecture/app-secret-posture-v0.md'
EVID = 'EVID-2026-237'

DISCOVERY_SURFACES = {
    ROOT / 'docs/30-architecture/decision-map.md': ['app-secret-posture-v0.md'],
    ROOT / 'docs/README.md': ['30-architecture/app-secret-posture-v0.md'],
    ROOT / 'docs/30-architecture/posture-index.md': ['app-secret-posture-v0.md'],
    ROOT / 'docs/30-architecture/portal-family-registry.md': ['app-secret-posture-v0.md'],
    ROOT / 'docs/30-architecture/app-secret-descriptor-schema-v0.md': ['app-secret-posture-v0.md'],
    ROOT / 'docs/00-meta/profile-posture-matrix.md': ['30-architecture/app-secret-posture-v0.md'],
    ROOT / 'docs/00-meta/resolved-history.md': ['app-secret-posture-v0.md'],
    ROOT / 'rfcs/0104-application-secrets-and-secret-portal.md': ['minimal app-seed seam', 'silent auto-rotation'],
}


def fail(msg: str) -> None:
    print(f'[appsecret-posture] FAIL: {msg}')
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f'[appsecret-posture] OK: {msg}')


def read(p: Path) -> str:
    return p.read_text(encoding='utf-8')


def main() -> None:
    if not DOC.exists():
        fail('missing docs/30-architecture/app-secret-posture-v0.md')

    doc_txt = read(DOC)
    for tok in [
        'D-APPSECRET',
        'D-VAULT',
        'D-CRYPTOSVC',
        '`portal.secret`',
        'CH-APPSECRET',
        '`cfg.params.lane.portal.secret`',
        'Phase 1',
        'manual-only v0',
        'svc:portal.secret',
        'scope="profile"',
    ]:
        if tok not in doc_txt:
            fail(f'posture doc does not mention required anchor token: {tok}')

    for ph in [
        'No ambient secret constructors',
        'Not a vault or named-secret inventory',
        'Profile-scoped by default; wider scopes are explicit',
        'Rotation is explicit and transcript-visible',
        'No ACP automation kind in Phase 1',
    ]:
        if ph not in doc_txt:
            fail(f'posture doc missing required v0 scope phrase: {ph}')

    for ref in [
        'REF-XDG-PORTAL-SECRET',
        'REF-ANDROID-KEYSTORE',
        'REF-SECRET-SERVICE-SPEC',
    ]:
        if ref not in doc_txt:
            fail(f'posture doc must cite {ref}')

    missing = []
    for p, needles in DISCOVERY_SURFACES.items():
        if not p.exists():
            fail(f'missing discovery surface: {p}')
        txt = read(p)
        if not any(n in txt for n in needles):
            missing.append(str(p.relative_to(ROOT)))
    if missing:
        fail('posture doc not referenced from discovery surfaces: ' + ', '.join(missing))

    portal = ROOT / 'docs/30-architecture/portal-family-registry.md'
    ptxt = read(portal)
    if 'no collection/item model' not in ptxt or 'no silent auto-rotation in v0' not in ptxt:
        fail('portal family registry must keep D-APPSECRET minimal and non-vault-like in v0')

    po = ROOT / 'docs/20-assurance/proof-obligation-registry.md'
    potxt = read(po)
    if 'PO-APPSECRET-ENF' not in potxt or 'no named inventory/collection semantics widen the surface in v0' not in potxt or 'silent auto-rotation' not in potxt:
        fail('PO-APPSECRET-ENF must keep non-vault / no silent auto-rotation semantics explicit')

    inv = ROOT / 'docs/20-assurance/invariant-registry.md'
    itxt = read(inv)
    if 'I-APPSECRET-1' not in itxt or '`scope="profile"` remains the expected default posture' not in itxt:
        fail('I-APPSECRET-1 must keep the profile-default scope rule explicit')
    if 'I-APPSECRET-3' not in itxt or 'silent auto-rotation is not a v0 product claim' not in itxt:
        fail('I-APPSECRET-3 must keep the no-silent-auto-rotation rule explicit')

    evid_idx = ROOT / 'docs/00-meta/evidence-index.md'
    if EVID not in read(evid_idx):
        fail(f'evidence-index does not register required evidence hook: {EVID}')

    ok(
        'D-APPSECRET v0 posture is pinned and discoverable (minimal app-seed; not a vault; no silent auto-rotation)'
    )


if __name__ == '__main__':
    main()
