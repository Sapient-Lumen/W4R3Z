#!/usr/bin/env python3
"""CI guardrail: keep ACP kind metadata coherent and mechanically checkable.

This repository treats schemas + validators + receipts as the stable product surface.
The ACP kind registry is a critical authority-substrate seam: it pins the closed set
of externally visible action kinds and their commutativity/ordering metadata.

Failure modes this guardrail prevents:
- LLM-driven drift that removes conflict-key families, introduces unknown families,
  or makes ordering witness requirements inconsistent with the stated stance.
- Profile-gated kinds referencing non-existent lane kill switches.

The check is intentionally conservative and fail-closed.
"""

from __future__ import annotations

import re
import sys
from dataclasses import dataclass
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


@dataclass
class Problem:
    path: Path
    detail: str


def read_text(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def strip_code_fences(txt: str) -> str:
    # keep it simple: remove fenced blocks entirely
    out: list[str] = []
    in_fence = False
    for line in txt.splitlines():
        if line.strip().startswith("```"):
            in_fence = not in_fence
            continue
        if not in_fence:
            out.append(line)
    return "\n".join(out)


def parse_conflictkey_families() -> set[str]:
    ck = ROOT / "docs/30-architecture/conflict-key-schema-v0.md"
    if not ck.exists():
        return set()
    txt = strip_code_fences(read_text(ck))
    fams: set[str] = set()
    # Preferred: numbered list items in the schema.
    for m in re.finditer(r"^\s*\d+\)\s*`([^`]+)`\s*$", txt, flags=re.MULTILINE):
        fams.add(m.group(1).strip())
    # Fallback: families enumerated in the family type comment.
    if not fams:
        for m in re.finditer(r"\bfamily\b[^\n]*;[^\n]*\"([a-z0-9_.-]+)\"", txt):
            fams.add(m.group(1))
    return fams




def parse_portal_tokens() -> set[str]:
    reg = ROOT / 'docs/30-architecture/portal-family-registry.md'
    if not reg.exists():
        return set()
    txt = strip_code_fences(read_text(reg))
    # Portal tokens are backticked in the CH-PLEDGE token column.
    return set(re.findall(r'`(portal\.[a-z0-9]+)`', txt))
def parse_cfg_param_keys() -> set[str]:
    reg = ROOT / "docs/30-architecture/config-toggle-registry.md"
    if not reg.exists():
        return set()
    txt = strip_code_fences(read_text(reg))
    # Capture backticked cfg.params.* tokens.
    keys = set(re.findall(r"`(cfg\.params\.[a-zA-Z0-9_.-]+)`", txt))
    return keys


def parse_kind_table() -> tuple[list[dict[str, str]], list[Problem]]:
    problems: list[Problem] = []
    reg = ROOT / "docs/70-llm-control/acp-action-kind-registry.md"
    if not reg.exists():
        return [], [Problem(reg, "missing acp-action-kind-registry.md")]

    txt = strip_code_fences(read_text(reg))
    lines = txt.splitlines()

    header_idx = None
    for i, ln in enumerate(lines):
        if ln.strip().startswith("| Kind |"):  # table header
            header_idx = i
            break
    if header_idx is None:
        return [], [Problem(reg, "ACP kind registry table header not found")]

    rows: list[str] = []
    for ln in lines[header_idx + 2 :]:  # skip header + separator
        if not ln.strip().startswith("|"):
            break
        if ln.strip() == "|":
            break
        rows.append(ln)

    parsed: list[dict[str, str]] = []
    for ln in rows:
        # split but preserve empty cells
        parts = [p.strip() for p in ln.strip().strip("|").split("|")]
        if len(parts) != 8:
            problems.append(
                Problem(
                    reg,
                    f"ACP kind table row must have 8 columns; got {len(parts)}: {ln.strip()}",
                )
            )
            continue
        parsed.append(
            {
                "kind": parts[0],
                "owner": parts[1],
                "conflict": parts[2],
                "commute": parts[3],
                "retry": parts[4],
                "witness": parts[5],
                "serializes": parts[6],
                "profiles": parts[7],
            }
        )

    return parsed, problems


def main() -> int:
    problems: list[Problem] = []
    kinds, p = parse_kind_table()
    problems.extend(p)

    fams = parse_conflictkey_families()
    cfg_keys = parse_cfg_param_keys()

    portal_tokens = parse_portal_tokens()

    reg_path = ROOT / "docs/70-llm-control/acp-action-kind-registry.md"

    if not fams:
        problems.append(
            Problem(
                ROOT / "docs/30-architecture/conflict-key-schema-v0.md",
                "could not parse CH-CONFLICTKEY family allowlist",
            )
        )

    seen: set[str] = set()

    for row in kinds:
        kind_raw = row["kind"].strip()
        kind = kind_raw.strip("`")

        if kind in seen:
            problems.append(Problem(reg_path, f"duplicate kind entry: {kind}"))
        seen.add(kind)

        if not re.fullmatch(r"[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+", kind):
            problems.append(Problem(reg_path, f"kind name not canonical (lowercase dotted): {kind}"))

        # Portal kinds must correspond to a known portal family token and must be lane-gated.
        if kind.startswith('portal.'):
            parts = kind.split('.')
            if len(parts) < 2:
                problems.append(Problem(reg_path, f'portal kind malformed: {kind}'))
            else:
                tok = '.'.join(parts[:2])
                if portal_tokens and tok not in portal_tokens:
                    problems.append(Problem(reg_path, f'portal kind {kind} references unknown portal token {tok} (not in portal-family-registry.md)'))
                lane_key = f'cfg.params.lane.{tok}'
                # Lane keys use cfg.params.lane.portal.<family> (token has dot).
                if lane_key not in row['profiles']:
                    problems.append(Problem(reg_path, f'portal kind {kind} must be profile-gated with `{lane_key}` (policy-killable; no ambient enablement)'))

        # Conflict key family: must be explicit and must exist.
        m = re.search(r'family="([a-z0-9_.-]+)"', row["conflict"])
        if not m:
            problems.append(Problem(reg_path, f"missing conflict-key family=\"..\" for kind {kind}"))
            family = None
        else:
            family = m.group(1)
            if fams and family not in fams:
                problems.append(
                    Problem(
                        reg_path,
                        f"kind {kind} references unknown conflict-key family '{family}' (not in CH-CONFLICTKEY v0)",
                    )
                )

        # Commutativity stance must be explicit.
        stance = row["commute"].lower()
        if not any(tok in stance for tok in ("commutes", "ordered", "conditional")):
            problems.append(
                Problem(
                    reg_path,
                    f"kind {kind} commutativity stance must include 'commutes', 'ordered', or 'conditional'",
                )
            )

        # Ordering witness consistency.
        witness = row["witness"].lower()
        ordered = "ordered" in stance
        has_required = "required" in witness
        has_none = "none" in witness
        if ordered and not has_required:
            problems.append(
                Problem(
                    reg_path,
                    f"kind {kind} is ordered but Ordering witness column is not 'required'",
                )
            )
        if (not ordered) and not has_none:
            problems.append(
                Problem(
                    reg_path,
                    f"kind {kind} is not ordered but Ordering witness column is not 'none'",
                )
            )
        if has_required and has_none:
            problems.append(
                Problem(
                    reg_path,
                    f"kind {kind} Ordering witness column must not contain both 'required' and 'none'",
                )
            )

        # Retry safety must be present (non-empty).
        if not row["retry"].strip():
            problems.append(Problem(reg_path, f"kind {kind} missing retry safety"))

        # Profiles column must mention only A/B/C/D.
        letters = re.findall(r"\b([A-D])\b", row["profiles"])
        if not letters:
            problems.append(Problem(reg_path, f"kind {kind} Profiles column must mention at least one of A,B,C,D"))
        if any(ch not in "ABCD" for ch in letters):
            problems.append(Problem(reg_path, f"kind {kind} Profiles column contains invalid profile letter"))

        # Lane-gate keys referenced must exist in the cfg toggle registry.
        lanes = re.findall(r"`(cfg\.params\.lane\.[a-zA-Z0-9_.-]+)`", row["profiles"])
        for k in lanes:
            if cfg_keys and k not in cfg_keys:
                problems.append(
                    Problem(
                        ROOT / "docs/30-architecture/config-toggle-registry.md",
                        f"ACP kind {kind} references lane key {k} but it is not in CH-CFG toggle registry",
                    )
                )

        # If kind is ordered, it should also carry a conflict key family (already required above)
        # and it should reference CH-ORDERTOK in witness.
        if ordered and "orderto" not in witness and "ch-ordertok" not in witness:
            problems.append(
                Problem(
                    reg_path,
                    f"kind {kind} is ordered but witness column does not reference CH-ORDERTOK",
                )
            )

    if problems:
        print("ACP kind metadata check failed:\n")
        for pr in problems:
            rel = pr.path
            try:
                rel = pr.path.relative_to(ROOT)
            except Exception:
                pass
            print(f"- {rel}: {pr.detail}")
        return 1

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
