#!/usr/bin/env python3
"""Guardrail: ensure referenced cfg.params.* keys are registry-closed.

Why this exists
--------------
`cfg.params.*` is a high-leverage authority substrate seam:
- lane kill switches (cfg.params.lane.*),
- bounds / policy knobs used by validators.

If docs drift to reference unregistered keys, we reintroduce "ambient toggles":
implementations/LLMs may invent new parameters that are not reviewable and not
subject to closure checks.

This check stays conservative and low-noise:
- It only considers backtick-quoted tokens like `cfg.params.lane.portal.net`.
- It ignores placeholders/wildcards (tokens containing '*', '<', '>').
- It only scans docs/ (not RFCs) to avoid rejecting exploratory proposals.

Exit code:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

import re
from pathlib import Path


RE_CFG_TOKEN = re.compile(r"`(cfg\.params\.[^`\s]+)`")
RE_REGISTRY_KEY = re.compile(r"`(cfg\.params\.[^`\s]+)`")


def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def fail(msg: str) -> None:
    print(f"[cfgref] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[cfgref] OK: {msg}")


def is_placeholder(tok: str) -> bool:
    # Avoid false positives for documentation placeholders:
    # - `cfg.params.lane.portal.*`
    # - `cfg.params.lane.portal.<family>`
    return ("*" in tok) or ("<" in tok) or (">" in tok)


def normalize_token(tok: str) -> str:
    """Return the cfg key portion for inline expressions.

    Docs sometimes use backticks for expressions like `cfg.params.lane.fcell=false`.
    For closure purposes we only care about the key name.
    """
    for sep in ("=", ":"):
        if sep in tok:
            tok = tok.split(sep, 1)[0]
    return tok


def load_registry_keys() -> set[str]:
    root = repo_root()
    reg = root / "docs/30-architecture/config-toggle-registry.md"
    if not reg.exists():
        fail("missing docs/30-architecture/config-toggle-registry.md")

    txt = read(reg)
    keys: set[str] = set()
    for m in RE_REGISTRY_KEY.finditer(txt):
        tok = normalize_token(m.group(1))
        if is_placeholder(tok):
            continue
        keys.add(tok)

    if not keys:
        fail("config-toggle-registry.md contains no cfg.params.* keys")
    return keys


def scan_docs_refs() -> dict[str, list[tuple[str, int]]]:
    """Return {token: [(relpath, lineno), ...]} for cfg.params.* refs in docs/."""
    root = repo_root()
    docs = root / "docs"
    if not docs.exists():
        fail("missing docs/ directory")

    hits: dict[str, list[tuple[str, int]]] = {}
    for p in sorted(docs.rglob("*.md")):
        # Don't treat the registry itself as a reference source.
        if p.name == "config-toggle-registry.md":
            continue
        rel = str(p.relative_to(root))
        for i, line in enumerate(read(p).splitlines(), start=1):
            for m in RE_CFG_TOKEN.finditer(line):
                tok = normalize_token(m.group(1))
                if is_placeholder(tok):
                    continue
                hits.setdefault(tok, []).append((rel, i))
    return hits


def main() -> None:
    reg = load_registry_keys()
    refs = scan_docs_refs()

    missing = sorted([t for t in refs.keys() if t not in reg])
    if missing:
        lines: list[str] = []
        for t in missing[:50]:
            locs = ", ".join([f"{rp}:{ln}" for rp, ln in refs[t][:3]])
            more = "" if len(refs[t]) <= 3 else f" (+{len(refs[t]) - 3} more)"
            lines.append(f"- {t} @ {locs}{more}")
        extra = "" if len(missing) <= 50 else f" (and {len(missing) - 50} more)"
        fail(
            "docs reference cfg.params.* keys not present in config-toggle-registry.md" + extra + "\n" + "\n".join(lines)
        )

    ok(f"all referenced cfg.params.* keys are registry-closed ({len(refs)} unique refs)")


if __name__ == "__main__":
    main()
