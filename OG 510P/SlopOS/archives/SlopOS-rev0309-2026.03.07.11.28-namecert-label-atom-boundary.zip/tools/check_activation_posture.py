#!/usr/bin/env python3
"""CI drift gate: pin D-ACTIVATE v0 posture (supervisor-owned, inbound-only continuity)."""
from __future__ import annotations
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOC = ROOT / 'docs/30-architecture/activation-posture-v0.md'
EVID = 'EVID-2026-251'

DISCOVERY_SURFACES = {
    ROOT / 'docs/30-architecture/decision-map.md': ['activation-posture-v0.md'],
    ROOT / 'docs/README.md': ['30-architecture/activation-posture-v0.md', 'activation-set-schema-v0.md'],
    ROOT / 'docs/30-architecture/posture-index.md': ['activation-posture-v0.md'],
    ROOT / 'docs/30-architecture/activation-set-schema-v0.md': ['activation-posture-v0.md'],
    ROOT / 'docs/30-architecture/component-manifest-schema-v0.md': ['activation-posture-v0.md'],
    ROOT / 'docs/00-meta/profile-posture-matrix.md': ['30-architecture/activation-posture-v0.md'],
    ROOT / 'docs/00-meta/resolved-history.md': ['activation-posture-v0.md'],
    ROOT / 'rfcs/0081-activation-handoff-and-handle-stores.md': ['supervisor-owned, inbound-only continuity'],
}


def fail(msg: str) -> None:
    print(f'[activate-posture] FAIL: {msg}')
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f'[activate-posture] OK: {msg}')


def read(p: Path) -> str:
    return p.read_text(encoding='utf-8')


def main() -> None:
    if not DOC.exists():
        fail('missing docs/30-architecture/activation-posture-v0.md')

    doc_txt = read(DOC)
    for tok in [
        'D-ACTIVATE',
        'CH-ACTSET',
        'Phase 1',
        'supervisor-owned',
        'inbound continuity',
        'manifest-closed',
        'per-`cid`',
        'non-inventory',
        'D-SEAL',
    ]:
        if tok not in doc_txt:
            fail(f'posture doc does not mention required anchor token: {tok}')

    for ph in [
        'Stable handles are supervisor-owned inbound continuity, not service-owned rebinding',
        'CH-ACTSET is descriptive, bounded, and redaction-safe',
        'Handle store is continuity-only, not a generic persistence/export channel',
        'manifest-closed and bounded by CH-COMP',
        'Activation is activation-delivered, not ambiently inherited',
    ]:
        if ph not in doc_txt:
            fail(f'posture doc missing required v0 scope phrase: {ph}')

    for ref in [
        'REF-SYSTEMD-SOCKET-ACTIVATION',
        'REF-SYSTEMD-FDSTORE',
        'REF-LAUNCHD-ACTIVATE-SOCKET',
        'REF-FUCHSIA-RUNNER-STOP',
    ]:
        if ref not in doc_txt:
            fail(f'posture doc must cite {ref}')

    missing = []
    for p, needles in DISCOVERY_SURFACES.items():
        if not p.exists():
            fail(f'missing discovery surface: {p}')
        txt = read(p)
        if not any(n in txt for n in needles):
            missing.append(str(p.relative_to(ROOT)))
    if missing:
        fail('posture doc not referenced from discovery surfaces: ' + ', '.join(missing))

    itxt = read(ROOT / 'docs/20-assurance/invariant-registry.md')
    if 'I-ACTIVATE-3' not in itxt or 'non-inventory and same-component only' not in itxt:
        fail('I-ACTIVATE-3 must keep same-component / non-inventory continuity explicit')

    potxt = read(ROOT / 'docs/20-assurance/proof-obligation-registry.md')
    if 'PO-ACTIVATE-CONTINUITY' not in potxt or 'no list/search/watch API' not in potxt or 'no cross-component export/import semantics' not in potxt:
        fail('PO-ACTIVATE-CONTINUITY must keep non-inventory / no export-import semantics explicit')

    if EVID not in read(ROOT / 'docs/00-meta/evidence-index.md'):
        fail(f'evidence-index does not register required evidence hook: {EVID}')

    ok('D-ACTIVATE v0 posture is pinned and discoverable (supervisor-owned, inbound-only continuity; no generic persistence/export drift)')


if __name__ == '__main__':
    main()
