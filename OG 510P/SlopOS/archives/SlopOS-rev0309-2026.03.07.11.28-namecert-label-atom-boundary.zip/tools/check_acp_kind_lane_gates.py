#!/usr/bin/env python3
"""CI drift gate: ensure lane-gated ACP kinds explicitly name their kill switches.

Why this exists
--------------
This archive relies on explicit, fail-closed lane gates (`cfg.params.lane.*`) to prevent
ambient authority and to keep optional surfaces policy-killable.

Failure modes this prevents:
- A new ACP kind is added behind a lane gate but the registry row forgets to name the
  required `cfg.params.lane.*` key(s), weakening reviewability and making policy-kill
  posture harder to audit.

Contract (conservative)
-----------------------
- For `capshell.exec`, the Profiles cell MUST mention `cfg.params.lane.capshell`.
- For any kind starting with `portal.<family>.`, the Profiles cell MUST mention the
  corresponding `cfg.params.lane.portal.<family>` kill switch.
- For any kind starting with `fcell.`, the Profiles cell MUST mention `cfg.params.lane.fcell`.
- Each required key must exist in `docs/30-architecture/config-toggle-registry.md`.
- Each required key must appear in `docs/30-architecture/profile-lane-defaults.md` so
  the A–D default posture remains a stable diff surface.

Exit code:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def fail(msg: str) -> None:
    print(f"[acplane] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[acplane] OK: {msg}")


def read(p: Path) -> str:
    if not p.exists():
        fail(f"missing required file: {p}")
    return p.read_text(encoding="utf-8")


def parse_kind_table(md: str) -> list[tuple[str, str]]:
    """Return list of (kind, profiles_cell) from the registry table."""
    lines = md.splitlines()
    # Find header line.
    hdr_idx = next((i for i, ln in enumerate(lines) if ln.strip().startswith("| Kind |")), -1)
    if hdr_idx < 0:
        fail("could not find ACP kind registry table header '| Kind |'")

    rows: list[tuple[str, str]] = []
    for ln in lines[hdr_idx + 2 :]:  # skip header + separator
        if not ln.strip().startswith("|"):
            # End of table.
            break
        # Split into columns; strip leading/trailing empty.
        cols = [c.strip() for c in ln.strip().split("|")][1:-1]
        if len(cols) < 8:
            continue
        kind_cell = cols[0]
        # Data rows use backticked kind tokens.
        m = re.match(r"^`(?P<kind>[^`]+)`$", kind_cell)
        if not m:
            continue
        kind = m.group("kind")
        profiles = cols[7]
        rows.append((kind, profiles))

    if not rows:
        fail("no ACP kind rows parsed from registry table")
    return rows


def required_lane_key_for_kind(kind: str) -> str | None:
    if kind == "capshell.exec":
        return "cfg.params.lane.capshell"
    if kind.startswith("portal."):
        parts = kind.split(".")
        if len(parts) < 2:
            return None
        family = parts[1]
        return f"cfg.params.lane.portal.{family}"
    if kind.startswith("fcell."):
        return "cfg.params.lane.fcell"
    return None


def main() -> None:
    reg = ROOT / "docs" / "70-llm-control" / "acp-action-kind-registry.md"
    cfgreg = ROOT / "docs" / "30-architecture" / "config-toggle-registry.md"
    prof = ROOT / "docs" / "30-architecture" / "profile-lane-defaults.md"

    kinds = parse_kind_table(read(reg))
    cfg_txt = read(cfgreg)
    prof_txt = read(prof)

    missing_profiles: list[str] = []
    missing_cfg: list[str] = []
    missing_prof: list[str] = []

    for kind, profiles_cell in kinds:
        req = required_lane_key_for_kind(kind)
        if not req:
            continue

        if req not in profiles_cell:
            missing_profiles.append(f"{kind} -> {req}")

        if f"`{req}`" not in cfg_txt:
            missing_cfg.append(req)

        if req not in prof_txt:
            missing_prof.append(req)

    if missing_profiles:
        fail(
            "ACP kind registry rows missing required lane-gate key mention in Profiles cell: "
            + ", ".join(missing_profiles)
        )
    if missing_cfg:
        fail(
            "required lane-gate keys not present in config-toggle-registry.md: "
            + ", ".join(sorted(set(missing_cfg)))
        )
    if missing_prof:
        fail(
            "required lane-gate keys not present in profile-lane-defaults.md: "
            + ", ".join(sorted(set(missing_prof)))
        )

    ok("lane-gated ACP kinds name required cfg.params.lane.* keys (and keys exist in registries)")


if __name__ == "__main__":
    main()
