#!/usr/bin/env python3
"""CI guardrail: keep capshell explicit-budget (no implicit sponsorship) wiring coherent.

Rationale:
- Least authority in workflows: avoid implicit sponsorship for metered work.
- D-BUDGET/I-BUDGET-1: effectful, metered interfaces require an explicit payer/budget
  unless a profile explicitly exempts them.
- D-CAPSHELL is a high-risk workflow seam: retries, automation, and portals tend to
  reintroduce "just run it" resource sponsorship unless a schema-surface rule pins it.

This guardrail is conservative and fail-closed: it asserts required anchors exist across
cfg toggle registry, profile defaults, ACP semantics/kind registry, deny-code vocabulary,
and assurance/evidence wiring.
"""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def fail(msg: str) -> int:
    print(f"[capshell-budget-reqctx] FAIL: {msg}")
    return 1


def ok(msg: str) -> None:
    print(f"[capshell-budget-reqctx] OK: {msg}")


def main() -> int:
    cfgreg = ROOT / "docs/30-architecture/config-toggle-registry.md"
    prof = ROOT / "docs/30-architecture/profile-workflow-defaults.md"
    acp_sem = ROOT / "docs/70-llm-control/acp-validator-semantics.md"
    kindreg = ROOT / "docs/70-llm-control/acp-action-kind-registry.md"
    denyreg = ROOT / "docs/30-architecture/deny-code-registry.md"
    invreg = ROOT / "docs/20-assurance/invariant-registry.md"
    poreg = ROOT / "docs/20-assurance/proof-obligation-registry.md"
    evid = ROOT / "docs/00-meta/evidence-index.md"

    for p in (cfgreg, prof, acp_sem, kindreg, denyreg, invreg, poreg, evid):
        if not p.exists():
            return fail(f"missing required file: {p.relative_to(ROOT)}")

    # 1) cfg toggle registry includes the key.
    c = read(cfgreg)
    key = "`cfg.params.capshell.require_budget_lease`"
    if key not in c:
        return fail("config-toggle-registry.md missing cfg.params.capshell.require_budget_lease")
    ok("cfg.params.capshell.require_budget_lease is registry-closed")

    # 2) profile defaults matrix pins A–D guidance.
    pr = read(prof)
    if key not in pr:
        return fail("profile-workflow-defaults.md missing cfg.params.capshell.require_budget_lease row")
    if "| A (workstation) |" not in pr or "| B (cloud substrate) |" not in pr or "| C (embedded/separation) |" not in pr or "| D (agent/automation) |" not in pr:
        return fail("profile-workflow-defaults.md missing A–D columns")
    ok("profile-workflow-defaults pins A–D guidance for require_budget_lease")

    # 3) deny-code registry includes budget-missing.
    d = read(denyreg)
    if "`budget-missing`" not in d:
        return fail("deny-code-registry.md missing budget-missing")
    ok("deny-code registry includes budget-missing")

    # 4) ACP semantics mention the knob, metering lane, CH-BUDGET, and budget-missing.
    s = read(acp_sem)
    must = [
        "cfg.params.capshell.require_budget_lease",
        "cfg.params.lane.metering",
        "CH-BUDGET v0",
        "budget_desc_digests",
        "budget-missing",
        "PO-CAPSHELL-BUDGET-REQ",
    ]
    missing = [m for m in must if m not in s]
    if missing:
        return fail(f"acp-validator-semantics.md missing anchor(s): {', '.join(missing)}")
    ok("ACP validator semantics wire explicit budget requirement")

    # 5) ACP kind registry mentions the requirement for capshell.exec.
    k = read(kindreg)
    must = [
        "capshell.exec",
        "cfg.params.capshell.require_budget_lease",
        "cfg.params.lane.metering",
        "CH-BUDGET v0",
        "budget-missing",
    ]
    missing = [m for m in must if m not in k]
    if missing:
        return fail(f"acp-action-kind-registry.md missing capshell budget anchors: {', '.join(missing)}")
    ok("ACP kind registry includes capshell budget requirement")

    # 6) Assurance wiring includes invariant + proof obligation.
    if "I-CAPSHELL-BUDGET-1" not in read(invreg):
        return fail("invariant-registry.md missing I-CAPSHELL-BUDGET-1")
    if "PO-CAPSHELL-BUDGET-REQ" not in read(poreg):
        return fail("proof-obligation-registry.md missing PO-CAPSHELL-BUDGET-REQ")
    ok("Assurance wiring present (I-CAPSHELL-BUDGET-1, PO-CAPSHELL-BUDGET-REQ)")

    # 7) Evidence index includes EVID-2026-185 pointing at this tool.
    ev = read(evid)
    if "EVID-2026-185" not in ev or "tools/check_capshell_budget_reqctx.py" not in ev:
        return fail("evidence-index.md missing EVID-2026-185 entry pointing at this tool")
    ok("Evidence index includes EVID-2026-185")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
