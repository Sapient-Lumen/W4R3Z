#!/usr/bin/env python3
"""CI drift gate: pin D-CAPX v0 posture (gateway-owned, proxy-first import; no portable caveat VM)."""
from __future__ import annotations
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOC = ROOT / 'docs/30-architecture/capx-posture-v0.md'
EVID = 'EVID-2026-302'
DISCOVERY_SURFACES = {
    ROOT / 'README.md': ['capx-posture-v0.md'],
    ROOT / 'docs/README.md': ['30-architecture/capx-posture-v0.md'],
    ROOT / 'docs/30-architecture/posture-index.md': ['capx-posture-v0.md'],
    ROOT / 'docs/00-meta/profile-posture-matrix.md': ['30-architecture/capx-posture-v0.md'],
    ROOT / 'docs/00-meta/resolved-history.md': ['capx-posture-v0.md'],
    ROOT / 'docs/00-meta/llm-runbook.md': ['docs/30-architecture/capx-posture-v0.md'],
    ROOT / 'docs/30-architecture/decision-map.md': ['capx-posture-v0.md', 'gateway-owned, proxy-first import'],
    ROOT / 'docs/30-architecture/mechanisms.md': ['capx-posture-v0.md', 'gateway-owned, proxy-first import seam'],
    ROOT / 'rfcs/0004-networked-capabilities-and-delegation-tokens.md': ['capx-posture-v0.md', 'gateway-owned, proxy-first import'],
    ROOT / 'rfcs/0026-object-capability-rpc-profile.md': ['capx-posture-v0.md'],
    ROOT / 'docs/30-architecture/capability-export-schema-v0.md': ['capx-posture-v0.md', 'proxy" | "service'],
    ROOT / 'docs/30-architecture/schema-registry.md': ['gateway-owned, proxy/service'],
    ROOT / 'docs/00-meta/evidence-index.md': [EVID],
    ROOT / 'tools/README.md': ['check_capx_posture.py'],
    ROOT / 'CHANGELOG.md': ['capx-posture-v0.md'],
}
REQ_TOKENS = ['D-CAPX', 'CH-CAPX', 'D-CAPRPC', 'CH-SREF', 'D-NETLEASE', 'D-COMMUTE', 'I-CAPX-1', 'I-CAPX-2', 'PO-CAPX-BIND', 'PO-CAPX-ATTEN', 'AC-012', 'Phase 1']
REQ_PHRASES = [
    'CH-CAPX is an explicit import envelope, not an ambient naming hint',
    'Gateway-owned, proxy-first binding only',
    'No portable caveat VM or token-policy calculus in the core seam',
    'Explicit route only; no ambient network or service-name fallback',
    'Off-by-default and profile-gated in Phase 1',
    'Routine workflow/observation surfaces carry digests, not raw CH-CAPX bytes',
    'No app-visible token inventory, probing, or generic share bus',
    'External action semantics stay on the imported provider/proxy, not on CH-CAPX itself',
    'No new workflow / ACP / admin surface on D-CAPX tokens',
    'Sealed compat remains killable and non-ambient',
    'digest(CH-CAPX v0)',
    'proxy`** or **`service`** object',
]
REQ_REFS = ['REF-CAPTP', 'REF-OCAPN', 'REF-MACAROONS-NDSS14', 'REF-BISCUIT-SPEC']


def fail(msg: str) -> None:
    print(f'[capx-posture] FAIL: {msg}')
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f'[capx-posture] OK: {msg}')


def read(p: Path) -> str:
    return p.read_text(encoding='utf-8')


def main() -> None:
    if not DOC.exists():
        fail('missing docs/30-architecture/capx-posture-v0.md')
    doc_txt = read(DOC)
    for tok in REQ_TOKENS:
        if tok not in doc_txt:
            fail(f'posture doc does not mention required anchor token: {tok}')
    for ph in REQ_PHRASES:
        if ph not in doc_txt:
            fail(f'posture doc missing required phrase: {ph}')
    for ref in REQ_REFS:
        if ref not in doc_txt:
            fail(f'posture doc missing required reference token: {ref}')
    for path, needles in DISCOVERY_SURFACES.items():
        txt = read(path)
        for needle in needles:
            if needle not in txt:
                fail(f'{path.relative_to(ROOT)} missing required reference: {needle}')
    itxt = read(ROOT / 'docs/20-assurance/invariant-registry.md')
    if 'I-CAPX-1' not in itxt or 'local proxy/service identifier' not in itxt:
        fail('I-CAPX-1 must keep local proxy/service binding explicit')
    potxt = read(ROOT / 'docs/20-assurance/proof-obligation-registry.md')
    if 'PO-CAPX-BIND' not in potxt or 'local proxy/service identifier' not in potxt:
        fail('PO-CAPX-BIND must keep local proxy/service binding explicit')
    bib = read(ROOT / 'docs/00-meta/bibliography.md')
    for ref in REQ_REFS:
        if ref not in bib:
            fail(f'bibliography missing {ref}')
    ok('D-CAPX posture wiring is present and pinned')


if __name__ == '__main__':
    main()
