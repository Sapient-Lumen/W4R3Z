#!/usr/bin/env python3
"""CI drift gate: pin D-LEASE v0 posture (keeps delegation temporary, bounded, and auditable).

Why this exists
--------------
D-LEASE is a deceptively small idea that tends to drift into:
- raw capability sharing (“temporary” by convention only),
- implicit renewal/keepalive (hard to reason about and hard to kill),
- ambient time as an authority source,
- and transcript-free delegation (impossible to audit/test).

This guardrail keeps the Phase 1 meaning of leases small and discoverable:
- lease proxies are the authority (not hints)
- no raw cap export
- no unbounded renewal
- time-based bounds require explicit Clock handles (D-NONDET)
- issuance is attenuation-only (non-amplifying)
- delegation is evidenced via CH-CAPLEASE (descriptor; no secrets)

Exit code:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]

DOC = ROOT / "docs/30-architecture/capability-lease-posture-v0.md"
EVID = "EVID-2026-219"

DISCOVERY_SURFACES = {
    ROOT / "docs/30-architecture/decision-map.md": ["capability-lease-posture-v0.md"],
    ROOT / "docs/README.md": ["30-architecture/capability-lease-posture-v0.md"],
    ROOT / "docs/30-architecture/capability-semantics.md": ["capability-lease-posture-v0.md"],
    ROOT / "docs/30-architecture/capability-lease-schema-v0.md": ["capability-lease-posture-v0.md"],
    ROOT / "docs/00-meta/llm-runbook.md": ["capability-lease-posture-v0.md"],
}


def fail(msg: str) -> None:
    print(f"[caplease-posture] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[caplease-posture] OK: {msg}")


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def main() -> None:
    if not DOC.exists():
        fail("missing docs/30-architecture/capability-lease-posture-v0.md")

    doc_txt = read(DOC)

    # Anchor tokens: keep posture attached to decision + assurance surfaces.
    for tok in [
        "D-LEASE",
        "CH-CAPLEASE",
        "D-MEMBRANE",
        "D-NONDET",
        "I-LEASE-1",
        "I-LEASE-2",
        "I-LEASE-3",
        "PO-LEASE-VALIDATE",
        "PO-LEASE-ENF",
        "PO-LEASE-NOAMP",
    ]:
        if tok not in doc_txt:
            fail(f"posture doc does not mention required anchor token: {tok}")

    # Keep the v0 meaning small and explicit.
    required_phrases = [
        "Phase 1 meaning",
        "No raw capability export",
        "No unbounded renewal",
        "Time is not ambient authority",
        "Delegation is transcript-evidenced",
    ]
    for ph in required_phrases:
        if ph not in doc_txt:
            fail(f"posture doc missing required v0 scope phrase: {ph}")

    # Minimal research wiring.
    for ref in ["REF-CAPMYTHS", "REF-ROBUST-COMPOSITION", "REF-KOPPMANN-ES", "REF-OCAP-MURPHI"]:
        if ref not in doc_txt:
            fail(f"posture doc must cite {ref}")

    # Ensure the posture doc is discoverable from core indices.
    missing = []
    for p, needles in DISCOVERY_SURFACES.items():
        if not p.exists():
            fail(f"missing discovery surface: {p}")
        txt = read(p)
        if not any(n in txt for n in needles):
            missing.append(str(p.relative_to(ROOT)))
    if missing:
        fail("posture doc not referenced from discovery surfaces: " + ", ".join(missing))

    # Evidence hook must be registered.
    evid_idx = ROOT / "docs/00-meta/evidence-index.md"
    if not evid_idx.exists():
        fail("missing docs/00-meta/evidence-index.md")
    if EVID not in read(evid_idx):
        fail(f"evidence-index does not register required evidence hook: {EVID}")

    ok("D-LEASE v0 posture is pinned and discoverable (lease proxies are authority; no raw cap export; no unbounded renewal; no ambient time authority)")


if __name__ == "__main__":
    main()
