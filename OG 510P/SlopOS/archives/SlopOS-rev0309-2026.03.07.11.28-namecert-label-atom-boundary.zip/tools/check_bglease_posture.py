#!/usr/bin/env python3
"""CI drift gate: pin D-BGLEASE v0 posture (explicit, review-bound persistence).

Why this exists
--------------
Background execution + autostart are classic drift seams:
- ambient daemons and login hooks quietly become persistence channels
- generic scheduling gets conflated with continuous presence
- renewals widen into stronger grants without a fresh decision path
- automation inherits a silent "run forever" affordance

This guardrail keeps Phase 1 small and honest:
- no ambient persistence constructors
- prefer D-JOBS for deferrable work
- background and autostart remain separate grant bits
- renewals cannot silently widen into autostart
- the whole seam stays discoverable and policy-killable

Exit code:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOC = ROOT / "docs/30-architecture/background-lease-posture-v0.md"
EVID = "EVID-2026-232"

DISCOVERY_SURFACES = {
    ROOT / "docs/30-architecture/decision-map.md": ["background-lease-posture-v0.md"],
    ROOT / "docs/README.md": ["30-architecture/background-lease-posture-v0.md"],
    ROOT / "docs/30-architecture/portal-family-registry.md": ["background-lease-posture-v0.md"],
    ROOT / "docs/30-architecture/background-request-schema-v0.md": ["background-lease-posture-v0.md"],
    ROOT / "docs/30-architecture/background-lease-schema-v0.md": ["background-lease-posture-v0.md"],
}


def fail(msg: str) -> None:
    print(f"[bglease-posture] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[bglease-posture] OK: {msg}")


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def main() -> None:
    if not DOC.exists():
        fail("missing docs/30-architecture/background-lease-posture-v0.md")

    doc_txt = read(DOC)
    for tok in [
        "D-BGLEASE",
        "D-JOBS",
        "`portal.background`",
        "`portal.background.request`",
        "CH-BGREQ",
        "CH-BGLEASE",
        "`cfg.params.lane.portal.background`",
        "Phase 1",
    ]:
        if tok not in doc_txt:
            fail(f"posture doc does not mention required anchor token: {tok}")

    for ph in [
        "No ambient background/autostart constructors",
        "not generic scheduling",
        "distinct grant bits",
        "silent widening",
        "prefer `portal.jobs` / D-JOBS",
    ]:
        if ph not in doc_txt:
            fail(f"posture doc missing required v0 scope phrase: {ph}")

    for ref in [
        "REF-XDG-PORTAL-BACKGROUND",
        "REF-ANDROID-BG-EXEC-LIMITS",
        "REF-ANDROID-FGS-RESTRICTIONS",
        "REF-APPLE-BG-MODES",
        "REF-APPLE-BGTASKS",
    ]:
        if ref not in doc_txt:
            fail(f"posture doc must cite {ref}")

    missing = []
    for p, needles in DISCOVERY_SURFACES.items():
        if not p.exists():
            fail(f"missing discovery surface: {p}")
        txt = read(p)
        if not any(n in txt for n in needles):
            missing.append(str(p.relative_to(ROOT)))
    if missing:
        fail("posture doc not referenced from discovery surfaces: " + ", ".join(missing))

    kinds = ROOT / "docs/70-llm-control/acp-action-kind-registry.md"
    if not kinds.exists():
        fail("missing docs/70-llm-control/acp-action-kind-registry.md")
    ktxt = read(kinds)
    if "portal.background.request" not in ktxt or "svc:portal.background" not in ktxt:
        fail("ACP kind registry must keep portal.background.request ordered at svc:portal.background")

    evid_idx = ROOT / "docs/00-meta/evidence-index.md"
    if not evid_idx.exists():
        fail("missing docs/00-meta/evidence-index.md")
    if EVID not in read(evid_idx):
        fail(f"evidence-index does not register required evidence hook: {EVID}")

    ok(
        "D-BGLEASE v0 posture is pinned and discoverable (no ambient persistence; prefer jobs; no silent widening)"
    )


if __name__ == "__main__":
    main()
