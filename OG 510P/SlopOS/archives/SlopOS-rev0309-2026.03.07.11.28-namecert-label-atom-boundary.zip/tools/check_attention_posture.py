#!/usr/bin/env python3
"""CI drift gate: pin D-ATTN v0 urgent notification posture.

Why this exists
---------------
Attention/notification seams drift easily:
- old RFC prose can quietly reintroduce a fake `attention.urgent` capability
- "urgent" can become an ambient bypass for volition, budgets, or persistence
- discovery surfaces can disagree about whether v0 uses a lease, a hint, or both

This guardrail keeps Phase 1 honest:
- urgent is a policy-gated CH-NOTIF hint only
- there is no dedicated attention lease descriptor in v0
- there is no standalone `attention.urgent` capability surface in v0
- notification actions remain volition-bound and transcript-visible
- older RFC history stays aligned with the pinned posture instead of fighting it
"""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOC = ROOT / 'docs/30-architecture/attention-lease-posture-v0.md'
EVID = 'EVID-2026-233'

DISCOVERY_SURFACES = {
    ROOT / 'docs/30-architecture/decision-map.md': ['attention-lease-posture-v0.md', 'policy-gated hint'],
    ROOT / 'docs/README.md': ['30-architecture/attention-lease-posture-v0.md'],
    ROOT / 'docs/30-architecture/notification-request-schema-v0.md': ['attention-lease-posture-v0.md', 'no lease/capability in v0'],
    ROOT / 'docs/30-architecture/portal-family-registry.md': ['no lease/capability in v0'],
    ROOT / 'docs/00-meta/trajectory-map.md': ['attention-durable-interrupt-boundary-v0.md', 'tools/check_attention_posture.py'],
    ROOT / 'rfcs/0055-attention-authority-and-notifications.md': ['There is **no `attention.urgent` capability in v0**', 'policy-gated hint only in v0'],
}

FORBIDDEN = {
    ROOT / 'docs/30-architecture/decision-map.md': ['attention leases', 'requiring explicit consent'],
    ROOT / 'rfcs/0055-attention-authority-and-notifications.md': [
        'a component must hold an `attention.urgent` capability',
        'urgent notifications remain origin-branded and are still budgeted, but can bypass some suppression',
        'requires additional capability; see below',
    ],
}


def fail(msg: str) -> None:
    print(f'[attention-posture] FAIL: {msg}')
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f'[attention-posture] OK: {msg}')


def read(p: Path) -> str:
    return p.read_text(encoding='utf-8')


def main() -> None:
    if not DOC.exists():
        fail('missing docs/30-architecture/attention-lease-posture-v0.md')

    doc_txt = read(DOC)
    for tok in [
        'D-ATTN',
        'CH-NOTIF v0',
        '`portal.attn.*`',
        '`portal.attn.request`',
        '`cfg.params.lane.portal.attn`',
        'PO-ATTN-URGENT',
        'I-ATTN-2',
        'I-ATTN-3',
        'Phase 1',
    ]:
        if tok not in doc_txt:
            fail(f'posture doc missing required anchor token: {tok}')

    for phrase in [
        'do not introduce a dedicated attention-lease descriptor',
        'policy-gated hint',
        'no separate `attention.urgent` capability',
        'No standalone urgent capability token',
    ]:
        if phrase not in doc_txt:
            fail(f'posture doc missing required v0 phrase: {phrase}')

    for ref in [
        'REF-APPLE-CRITICAL-ALERTS',
        'REF-ANDROID-NOTIF-CHANNELS',
    ]:
        if ref not in doc_txt:
            fail(f'posture doc must cite {ref}')

    missing = []
    for p, needles in DISCOVERY_SURFACES.items():
        if not p.exists():
            fail(f'missing required discovery/history surface: {p}')
        txt = read(p)
        if not all(n in txt for n in needles):
            missing.append(str(p.relative_to(ROOT)))
    if missing:
        fail('posture/history wiring incomplete: ' + ', '.join(missing))

    for p, needles in FORBIDDEN.items():
        txt = read(p)
        for needle in needles:
            if needle in txt:
                fail(f'forbidden stale urgent-capability prose remains in {p.relative_to(ROOT)}: {needle}')

    evid_idx = ROOT / 'docs/00-meta/evidence-index.md'
    if not evid_idx.exists() or EVID not in read(evid_idx):
        fail('evidence-index does not register EVID-2026-233')

    tools_readme = ROOT / 'tools/README.md'
    if not tools_readme.exists() or 'check_attention_posture.py' not in read(tools_readme):
        fail('tools/README.md must mention check_attention_posture.py')

    ok('D-ATTN v0 posture is pinned and discoverable (urgent is a hint only; no lease/capability drift)')


if __name__ == '__main__':
    main()
