#!/usr/bin/env python3
"""CI guardrail: keep D-COMMUTE predicates explicit for every CH-ACP kind.

Why this exists
--------------
The ACP kind registry pins conflict keys + stance + ordering boundaries, but commutativity
also depends on the exact *predicate* and on what is considered *externally observable*.

Failure modes this prevents:
- A kind is added/renamed but its commutation predicate is not recorded.
- Predicate/normalization anchors drift out of the archive, making D-COMMUTE claims
  untestable and planner-unsafe.

This check is intentionally conservative and fail-closed.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


@dataclass
class Problem:
    path: Path
    detail: str


def read_text(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def strip_code_fences(txt: str) -> str:
    out: list[str] = []
    in_fence = False
    for line in txt.splitlines():
        if line.strip().startswith("```"):
            in_fence = not in_fence
            continue
        if not in_fence:
            out.append(line)
    return "\n".join(out)


def parse_acp_kinds() -> tuple[list[str], list[Problem]]:
    reg = ROOT / "docs/70-llm-control/acp-action-kind-registry.md"
    if not reg.exists():
        return [], [Problem(reg, "missing acp-action-kind-registry.md")]

    txt = strip_code_fences(read_text(reg))
    lines = txt.splitlines()

    header_idx = None
    for i, ln in enumerate(lines):
        if ln.strip().startswith("| Kind |"):
            header_idx = i
            break
    if header_idx is None:
        return [], [Problem(reg, "ACP kind registry table header not found")]

    kinds: list[str] = []
    for ln in lines[header_idx + 2 :]:
        if not ln.strip().startswith("|"):
            break
        parts = [p.strip() for p in ln.strip().strip("|").split("|")]
        if len(parts) < 1:
            continue
        kind_cell = parts[0]
        kind = kind_cell.strip().strip("`")
        if kind:
            kinds.append(kind)

    if not kinds:
        return [], [Problem(reg, "no kinds parsed from ACP kind registry table")]

    # Ensure uniqueness
    dups = sorted({k for k in kinds if kinds.count(k) > 1})
    probs: list[Problem] = []
    if dups:
        probs.append(Problem(reg, f"duplicate kind entries parsed: {', '.join(dups)}"))
    return sorted(set(kinds)), probs


def parse_predicate_registry() -> tuple[dict[str, str], list[Problem]]:
    doc = ROOT / "docs/70-llm-control/acp-commutativity-predicate-registry.md"
    if not doc.exists():
        return {}, [Problem(doc, "missing acp-commutativity-predicate-registry.md")]

    txt = strip_code_fences(read_text(doc))

    # Sections are keyed by headings: ### `kind`
    sec_re = re.compile(r"^###\s+`(?P<kind>[^`]+)`\s*$", flags=re.MULTILINE)

    matches = list(sec_re.finditer(txt))
    if not matches:
        return {}, [Problem(doc, "no per-kind sections found; expected headings like: ### `capshell.exec`")]

    sections: dict[str, str] = {}
    problems: list[Problem] = []

    for idx, m in enumerate(matches):
        kind = m.group("kind").strip()
        start = m.end()
        end = matches[idx + 1].start() if idx + 1 < len(matches) else len(txt)
        body = txt[start:end]
        if kind in sections:
            problems.append(Problem(doc, f"duplicate predicate section for kind {kind}"))
            continue
        sections[kind] = body

    # Basic anchor checks inside each section.
    for kind, body in sections.items():
        if "Predicate:" not in body:
            problems.append(Problem(doc, f"kind {kind} missing 'Predicate:' anchor"))
        if "Normalize:" not in body:
            problems.append(Problem(doc, f"kind {kind} missing 'Normalize:' anchor"))
        if "CH-ACPOUT" not in body:
            problems.append(Problem(doc, f"kind {kind} normalization must mention CH-ACPOUT"))
        if "conflict_key_digest" not in body:
            problems.append(Problem(doc, f"kind {kind} normalization must mention conflict_key_digest"))

    return sections, problems


def main() -> int:
    problems: list[Problem] = []

    kinds, p = parse_acp_kinds()
    problems.extend(p)

    sections, p2 = parse_predicate_registry()
    problems.extend(p2)

    pred_doc = ROOT / "docs/70-llm-control/acp-commutativity-predicate-registry.md"

    if kinds:
        missing = [k for k in kinds if k not in sections]
        extra = [k for k in sections.keys() if k not in kinds]

        if missing:
            problems.append(Problem(pred_doc, "missing predicate entries for kinds: " + ", ".join(missing)))
        if extra:
            problems.append(Problem(pred_doc, "predicate registry contains unknown/extra kinds: " + ", ".join(sorted(extra))))

    if problems:
        print("ACP commutativity predicate registry check failed:\n")
        for pr in problems:
            rel = pr.path
            try:
                rel = pr.path.relative_to(ROOT)
            except Exception:
                pass
            print(f"- {rel}: {pr.detail}")
        return 1

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
