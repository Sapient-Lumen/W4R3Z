#!/usr/bin/env python3
"""CI guardrail: keep capshell explicit intent-envelope (CH-PLUMBMSG) wiring coherent.

Rationale:
- Workflows are a primary ambient-authority drift seam.
- Even when authority is explicit (caps/leases), *intent* can drift into ambient channels
  (free-form notes, logs, UI-only state) that are hard to review/audit.
- CH-PLUMBMSG v0 is a pinned, non-authoritative intent envelope (D-PLUMB).
- CH-EXECPACK v2 optionally binds `plumbmsg_digest = digest(CH-PLUMBMSG v0)`.
- Strict profiles may require intent envelopes via `cfg.params.capshell.require_plumbmsg`
  (veto-only; denies missing/invalid envelopes).

This check is conservative and fail-closed: it asserts required anchors exist across
cfg toggle registry, profile defaults, schemas, validator semantics, deny-code vocabulary,
and assurance/evidence wiring.

Exit code:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def fail(msg: str) -> int:
    print(f"[capshell-plumbmsg] FAIL: {msg}")
    return 1


def ok(msg: str) -> None:
    print(f"[capshell-plumbmsg] OK: {msg}")


def main() -> int:
    cfgreg = ROOT / "docs/30-architecture/config-toggle-registry.md"
    prof = ROOT / "docs/30-architecture/profile-workflow-defaults.md"
    execpack = ROOT / "docs/30-architecture/capshell-exec-pack-schema-v2.md"
    schemareg = ROOT / "docs/30-architecture/schema-registry.md"
    kindreg = ROOT / "docs/70-llm-control/acp-action-kind-registry.md"
    sem = ROOT / "docs/70-llm-control/acp-validator-semantics.md"
    denyreg = ROOT / "docs/30-architecture/deny-code-registry.md"
    invreg = ROOT / "docs/20-assurance/invariant-registry.md"
    poreg = ROOT / "docs/20-assurance/proof-obligation-registry.md"
    evid = ROOT / "docs/00-meta/evidence-index.md"

    for p in (cfgreg, prof, execpack, schemareg, kindreg, sem, denyreg, invreg, poreg, evid):
        if not p.exists():
            return fail(f"missing required file: {p.relative_to(ROOT)}")

    key = "`cfg.params.capshell.require_plumbmsg`"

    # 1) cfg toggle registry includes the knob.
    c = read(cfgreg)
    if key not in c:
        return fail("config-toggle-registry.md missing cfg.params.capshell.require_plumbmsg")
    ok("cfg.params.capshell.require_plumbmsg is registry-closed")

    # 2) profile defaults matrix pins A–D guidance.
    pr = read(prof)
    if key not in pr:
        return fail("profile-workflow-defaults.md missing cfg.params.capshell.require_plumbmsg row")
    ok("profile-workflow-defaults pins A–D guidance for require_plumbmsg")

    # 3) CH-EXECPACK v2 includes plumbmsg_digest binding and references CH-PLUMBMSG.
    e = read(execpack)
    must = ["CH-EXECPACK v2", "v: 2", "plumbmsg_digest", "digest(CH-PLUMBMSG v0)"]
    missing = [m for m in must if m not in e]
    if missing:
        return fail(f"capshell-exec-pack-schema-v2.md missing anchor(s): {', '.join(missing)}")
    ok("CH-EXECPACK v2 binds optional plumbmsg_digest")

    # 4) Schema registry lists CH-EXECPACK v2 and links to the v2 file.
    sr = read(schemareg)
    if "| CH-EXECPACK v2 |" not in sr or "(capshell-exec-pack-schema-v2.md)" not in sr.replace("./", ""):
        return fail("schema-registry.md missing CH-EXECPACK v2 row/link")
    ok("schema registry includes CH-EXECPACK v2")

    # 5) deny-code registry includes plumbmsg-missing.
    d = read(denyreg)
    if "`plumbmsg-missing`" not in d:
        return fail("deny-code-registry.md missing plumbmsg-missing")
    ok("deny-code registry includes plumbmsg-missing")

    # 6) ACP control docs mention the knob, the field, and the deny code.
    k = read(kindreg)
    if "cfg.params.capshell.require_plumbmsg" not in k or "plumbmsg_digest" not in k or "plumbmsg-missing" not in k:
        return fail("acp-action-kind-registry.md missing require_plumbmsg/plumbmsg_digest/plumbmsg-missing anchors")
    ok("ACP kind registry mentions require_plumbmsg")

    s = read(sem)
    must = [
        "cfg.params.capshell.require_plumbmsg",
        "plumbmsg_digest",
        "CH-PLUMBMSG v0",
        "plumbmsg-missing",
        "PO-CAPSHELL-PLUMBMSG-REQ",
        "PO-PLUMBMSG-VALIDATE",
    ]
    missing = [m for m in must if m not in s]
    if missing:
        return fail(f"acp-validator-semantics.md missing anchor(s): {', '.join(missing)}")
    ok("ACP validator semantics wire require_plumbmsg")

    # 7) Assurance wiring includes invariant + proof obligation.
    if "I-CAPSHELL-PLUMBMSG-1" not in read(invreg):
        return fail("invariant-registry.md missing I-CAPSHELL-PLUMBMSG-1")
    if "PO-CAPSHELL-PLUMBMSG-REQ" not in read(poreg):
        return fail("proof-obligation-registry.md missing PO-CAPSHELL-PLUMBMSG-REQ")
    ok("Assurance wiring present (I-CAPSHELL-PLUMBMSG-1, PO-CAPSHELL-PLUMBMSG-REQ)")

    # 8) Evidence index includes EVID-2026-188 pointing at this tool.
    ev = read(evid)
    if "EVID-2026-188" not in ev or "tools/check_capshell_plumbmsg_req.py" not in ev:
        return fail("evidence-index.md missing EVID-2026-188 entry pointing at this tool")
    ok("Evidence index includes EVID-2026-188")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
