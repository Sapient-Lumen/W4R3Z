#!/usr/bin/env python3
"""CI drift gate: pin D-CAPRPC session posture v0 (explicit live sessions; fail-stop disconnect; no transparent resume)."""
from __future__ import annotations
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOC = ROOT / 'docs/30-architecture/caprpc-session-posture-v0.md'
EVID = 'EVID-2026-300'
DISCOVERY_SURFACES = {
    ROOT / 'README.md': ['caprpc-session-posture-v0.md'],
    ROOT / 'docs/README.md': ['30-architecture/caprpc-session-posture-v0.md'],
    ROOT / 'docs/30-architecture/posture-index.md': ['caprpc-session-posture-v0.md'],
    ROOT / 'docs/00-meta/profile-posture-matrix.md': ['30-architecture/caprpc-session-posture-v0.md'],
    ROOT / 'docs/00-meta/resolved-history.md': ['caprpc-session-posture-v0.md'],
    ROOT / 'docs/00-meta/llm-runbook.md': ['docs/30-architecture/caprpc-session-posture-v0.md'],
    ROOT / 'docs/30-architecture/decision-map.md': ['caprpc-session-posture-v0.md', 'explicit, connection-specific, and session-scoped'],
    ROOT / 'docs/30-architecture/mechanisms.md': ['caprpc-session-posture-v0.md', 'fail-stop disconnect'],
    ROOT / 'rfcs/0026-object-capability-rpc-profile.md': ['caprpc-session-posture-v0.md', 'explicit live-session seam'],
    ROOT / 'docs/30-architecture/capability-rpc-frame-schema-v0.md': ['caprpc-session-posture-v0.md'],
    ROOT / 'docs/30-architecture/capability-rpc-frame-schema-v1.md': ['caprpc-session-posture-v0.md'],
}


def fail(msg: str) -> None:
    print(f'[caprpc-session-posture] FAIL: {msg}')
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f'[caprpc-session-posture] OK: {msg}')


def read(p: Path) -> str:
    return p.read_text(encoding='utf-8')


def main() -> None:
    if not DOC.exists():
        fail('missing docs/30-architecture/caprpc-session-posture-v0.md')
    doc_txt = read(DOC)
    for tok in ['D-CAPRPC', 'D-CAPX', 'D-TURNS', 'D-REQCTX', 'D-COMMUTE', 'I-CAPRPC-1', 'PO-CAPRPC-FRAME', 'PO-CAPRPC-NOAMBIENT', 'AC-064', 'Phase 1']:
        if tok not in doc_txt:
            fail(f'posture doc does not mention required anchor token: {tok}')
    for ph in [
        'Live object references stay explicit, connection-specific, and session-scoped',
        'Disconnect is fail-stop; no transparent reconnect, replay, or hidden resume',
        'Bootstrap/reintroduction stays explicit; no ambient resolver or service-name fallback',
        'Persistent/offline capability restore stays outside the live session seam',
        'No public session/object inventory, table introspection, or list/watch surface',
        'Session bookkeeping stays runtime-private and non-replicated',
        'No hidden inbox pumping or scheduler promises on reconnect/recovery',
        'External action semantics stay on existing conflict keys and ordering witnesses',
        'No new workflow / ACP / admin surface on D-CAPRPC sessions',
        'Sealed compat remains killable and non-ambient',
    ]:
        if ph not in doc_txt:
            fail(f'posture doc missing required v0 scope phrase: {ph}')
    for ref in ['REF-CAPNP-RPC', 'REF-CAPNP-CXXRPC', 'REF-CAPTP']:
        if ref not in doc_txt:
            fail(f'posture doc must cite {ref}')
    missing = []
    for p, needles in DISCOVERY_SURFACES.items():
        if not p.exists():
            fail(f'missing discovery surface: {p}')
        txt = read(p)
        if not any(n in txt for n in needles):
            missing.append(str(p.relative_to(ROOT)))
    if missing:
        fail('posture doc not referenced from discovery surfaces: ' + ', '.join(missing))
    if EVID not in read(ROOT / 'docs/00-meta/evidence-index.md'):
        fail(f'evidence-index does not register required evidence hook: {EVID}')
    bib = read(ROOT / 'docs/00-meta/bibliography.md')
    for ref in ['REF-CAPNP-RPC', 'REF-CAPNP-CXXRPC', 'REF-CAPTP']:
        if ref not in bib:
            fail(f'bibliography must register {ref}')
    ok('D-CAPRPC session posture is pinned and discoverable (explicit live sessions, fail-stop disconnect, explicit restore-only continuity, no public session/object inventory or transparent resume surface)')


if __name__ == '__main__':
    main()
