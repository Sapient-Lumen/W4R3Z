#!/usr/bin/env python3
"""CI drift gate: pin D-CAPRPC oneway posture v0 (bounded notifications; no reply, no stealth transport)."""
from __future__ import annotations
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOC = ROOT / 'docs/30-architecture/caprpc-oneway-posture-v0.md'
EVID = 'EVID-2026-301'
DISCOVERY_SURFACES = {
    ROOT / 'README.md': ['caprpc-oneway-posture-v0.md'],
    ROOT / 'docs/README.md': ['30-architecture/caprpc-oneway-posture-v0.md'],
    ROOT / 'docs/30-architecture/posture-index.md': ['caprpc-oneway-posture-v0.md'],
    ROOT / 'docs/00-meta/profile-posture-matrix.md': ['30-architecture/caprpc-oneway-posture-v0.md'],
    ROOT / 'docs/00-meta/resolved-history.md': ['caprpc-oneway-posture-v0.md'],
    ROOT / 'docs/00-meta/llm-runbook.md': ['docs/30-architecture/caprpc-oneway-posture-v0.md'],
    ROOT / 'docs/30-architecture/decision-map.md': ['caprpc-oneway-posture-v0.md', 'enqueue-or-error'],
    ROOT / 'docs/30-architecture/mechanisms.md': ['caprpc-oneway-posture-v0.md', 'zero capability attachments'],
    ROOT / 'rfcs/0026-object-capability-rpc-profile.md': ['caprpc-oneway-posture-v0.md', 'payload <= 256 bytes'],
    ROOT / 'docs/30-architecture/capability-rpc-frame-schema-v0.md': ['caprpc-oneway-posture-v0.md'],
    ROOT / 'docs/30-architecture/capability-rpc-frame-schema-v1.md': ['caprpc-oneway-posture-v0.md'],
    ROOT / 'docs/00-meta/evidence-index.md': [EVID],
    ROOT / 'tools/README.md': ['check_caprpc_oneway_posture.py'],
    ROOT / 'CHANGELOG.md': ['caprpc-oneway-posture-v0.md'],
}

REQ_TOKENS = ['D-CAPRPC', 'D-TURNS', 'D-REQCTX', 'D-COMMUTE', 'D-CAPX', 'I-CAPRPC-1', 'I-CAPRPC-2', 'PO-CAPRPC-FRAME', 'PO-CAPRPC-ONEWAY', 'PO-CAPRPC-NOAMBIENT', 'AC-064', 'Phase 1']
REQ_PHRASES = [
    'Interface-marked adjunct only; no ambient "fire-and-forget" toggle',
    'No third CH-CAPRPC frame kind in Phase 1',
    'Enqueue-or-error only; no reply, receipt, or deferred completion surface',
    'Tightly bounded small payload; no bulk transfer semantics',
    'Zero capability attachments and no export/import material on oneway',
    'No pipelined/promised-answer oneway in v0',
    'Current-session only; no durable backlog, replay, or transparent resume',
    'Delivery becomes a normal later turn, not an interrupt/reentrancy escape hatch',
    'External action semantics stay on existing conflict keys and ordering witnesses',
    'No new workflow / ACP / admin surface on D-CAPRPC oneway',
    'Sealed compat remains killable and non-ambient',
    'payload <= 256 bytes',
    'caps.len == 0',
]
REQ_REFS = ['REF-QNX-PULSES', 'REF-QNX-MSGSENDPULSE', 'REF-GENODE-SIGNALS']


def fail(msg: str) -> None:
    print(f'[caprpc-oneway-posture] FAIL: {msg}')
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f'[caprpc-oneway-posture] OK: {msg}')


def read(p: Path) -> str:
    return p.read_text(encoding='utf-8')


def main() -> None:
    if not DOC.exists():
        fail('missing docs/30-architecture/caprpc-oneway-posture-v0.md')
    doc_txt = read(DOC)
    for tok in REQ_TOKENS:
        if tok not in doc_txt:
            fail(f'posture doc does not mention required anchor token: {tok}')
    for ph in REQ_PHRASES:
        if ph not in doc_txt:
            fail(f'posture doc missing required phrase: {ph}')
    for ref in REQ_REFS:
        if ref not in doc_txt:
            fail(f'posture doc missing required reference token: {ref}')
    for path, needles in DISCOVERY_SURFACES.items():
        txt = read(path)
        for needle in needles:
            if needle not in txt:
                fail(f'{path.relative_to(ROOT)} missing required reference: {needle}')
    bib = read(ROOT / 'docs/00-meta/bibliography.md')
    for ref in REQ_REFS:
        if ref not in bib:
            fail(f'bibliography missing {ref}')
    ok('D-CAPRPC oneway posture wiring is present and pinned')


if __name__ == '__main__':
    main()
