#!/usr/bin/env python3
"""Drift gate: keep CH-AREF resolution posture explicit and non-ambient.

Why this exists
--------------
CH-AREF v0 intentionally allows a free-form `locator` hint so the archive can stay
small. Without an explicit posture, implementations and doc edits tend to drift
back toward ambient authority (implicit `file:` reads, implicit `https:` fetches,
SSRF-by-locator, etc.).

We avoid introducing a new schema surface here. Instead we pin a small posture doc
and wire it into:
- CH-AREF v0 security notes,
- D-AREF decision text,
- the assurance anchors (I-AREF-1, PO-AREF-VERIFY).

Exit code:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def fail(msg: str) -> None:
    print(f"[aref-resolve] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[aref-resolve] OK: {msg}")


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def require_in(path: Path, needle: str) -> None:
    if needle not in read(path):
        fail(f"{path.relative_to(ROOT)} missing required reference: {needle!r}")


def find_table_row(txt: str, row_prefix: str) -> str:
    for line in txt.splitlines():
        if line.startswith(row_prefix):
            return line
    return ""


def main() -> None:
    posture = ROOT / "docs/30-architecture/artifact-resolution-posture-v0.md"
    if not posture.exists():
        fail("missing posture doc: docs/30-architecture/artifact-resolution-posture-v0.md")

    # Discoverability: keep it wired from stable indexes.
    require_in(ROOT / "docs/README.md", "30-architecture/artifact-resolution-posture-v0.md")
    require_in(ROOT / "docs/30-architecture/decision-map.md", "artifact-resolution-posture-v0.md")

    # CH-AREF doc must explicitly point at the posture.
    require_in(
        ROOT / "docs/30-architecture/artifact-reference-schema-v0.md",
        "artifact-resolution-posture-v0.md",
    )

    # Assurance anchors: keep the "no ambient deref" rule mechanically reviewable.
    inv = ROOT / "docs/20-assurance/invariant-registry.md"
    po = ROOT / "docs/20-assurance/proof-obligation-registry.md"
    if not inv.exists() or not po.exists():
        fail("missing assurance registries (invariant-registry.md or proof-obligation-registry.md)")

    require_in(inv, "I-AREF-1")
    require_in(inv, "MUST NOT dereference")

    po_line = find_table_row(read(po), "| PO-AREF-VERIFY |")
    if not po_line:
        fail("PO-AREF-VERIFY row missing from proof-obligation registry")
    if "not dereferenced" not in po_line and "not dereference" not in po_line:
        fail("PO-AREF-VERIFY row must state that locators are not dereferenced by privileged code")
    if "portal" not in po_line:
        fail("PO-AREF-VERIFY row must mention portalized resolution")
    if "PO-LANE-KILL" not in po_line:
        fail("PO-AREF-VERIFY row must mention PO-LANE-KILL (resolution is lane-killable)")

    ok("CH-AREF resolution posture is present and wired (indexes + CH-AREF + assurance anchors)")


if __name__ == "__main__":
    main()
