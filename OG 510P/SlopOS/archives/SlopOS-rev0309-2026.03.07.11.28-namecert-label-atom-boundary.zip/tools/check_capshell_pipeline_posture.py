#!/usr/bin/env python3
"""CI drift gate: keep capshell pipeline posture discoverable + wired.

Rationale
---------
The sharp v0 decision here is *negative*: no peer stage-to-stage raw
handle/FD passing inside capshell pipelines. Without a small guardrail,
that decision can easily drift back into prose-only caveats while CH-STDIO /
CH-FDSET / CH-EXECPACK gain loopholes.
"""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def read(rel: str) -> str:
    p = ROOT / rel
    if not p.exists():
        raise SystemExit(f"[capshell-pipe] FAIL: missing required file: {rel}")
    return p.read_text(encoding="utf-8")

def require(rel: str, needle: str) -> None:
    txt = read(rel)
    if needle not in txt:
        raise SystemExit(f"[capshell-pipe] FAIL: {rel} missing required text: {needle!r}")

def ok(msg: str) -> None:
    print(f"[capshell-pipe] OK: {msg}")

def main() -> int:
    posture = "docs/30-architecture/capshell-pipeline-posture-v0.md"
    require(posture, "no direct peer handle/FD passing")
    require(posture, "digest(CH-AREF v0)")
    require(posture, "digest(CH-PLUMBMSG v0)")
    require(posture, "stage-local")
    ok("posture doc contains required anchors")

    require("docs/README.md", "capshell-pipeline-posture-v0.md")
    require("docs/30-architecture/posture-index.md", "capshell-pipeline-posture-v0.md")
    require("docs/00-meta/profile-posture-matrix.md", "capshell-pipeline-posture-v0.md")
    require("docs/30-architecture/decision-map.md", "capshell-pipeline-posture-v0.md")
    ok("discovery wiring present (docs index + posture index + profile matrix + decision map)")

    require("docs/30-architecture/stdio-schema-v0.md", "capshell-pipeline-posture-v0.md")
    require("docs/30-architecture/fdset-schema-v0.md", "capshell-pipeline-posture-v0.md")
    require("docs/30-architecture/capshell-exec-pack-schema-v2.md", "capshell-pipeline-posture-v0.md")
    require("docs/70-llm-control/acp-validator-semantics.md", "capshell-pipeline-posture-v0.md")
    ok("core capshell schema/control docs reference the posture")

    require("docs/20-assurance/invariant-registry.md", "I-CAPSHELL-PIPE-1")
    require("docs/20-assurance/proof-obligation-registry.md", "PO-CAPSHELL-PIPELINE-EXPLICIT")
    ok("assurance wiring present (I-CAPSHELL-PIPE-1, PO-CAPSHELL-PIPELINE-EXPLICIT)")

    require("docs/00-meta/resolved-history.md", "Capshell pipeline handoff")
    require("rfcs/0115-capability-safe-shell-and-automation.md", "Resolved for v0 posture")
    ok("resolved-history + RFC history record the v0 decision")

    require("docs/00-meta/evidence-index.md", "EVID-2026-231")
    require("docs/00-meta/evidence-index.md", "tools/check_capshell_pipeline_posture.py")
    require("tools/README.md", "check_capshell_pipeline_posture.py")
    ok("evidence index + tools/README mention the drift gate")

    return 0

if __name__ == "__main__":
    raise SystemExit(main())
