#!/usr/bin/env python3
"""CI drift gate: pin D-ATTRFS v0 posture (view-scoped, snapshot-first, handle-returning smart queries)."""
from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOC = ROOT / 'docs/30-architecture/attrfs-posture-v0.md'
EVID = 'EVID-2026-249'
DISCOVERY_SURFACES = {
    ROOT / 'docs/README.md': ['30-architecture/attrfs-posture-v0.md'],
    ROOT / 'docs/30-architecture/posture-index.md': ['attrfs-posture-v0.md'],
    ROOT / 'docs/00-meta/profile-posture-matrix.md': ['30-architecture/attrfs-posture-v0.md'],
    ROOT / 'docs/00-meta/llm-runbook.md': ['docs/30-architecture/attrfs-posture-v0.md'],
    ROOT / 'docs/00-meta/resolved-history.md': ['attrfs-posture-v0.md', 'shell-owned manifests'],
    ROOT / 'docs/30-architecture/decision-map.md': ['attrfs-posture-v0.md', 'snapshot-first', 'saved queries / smart folders stay shell-owned manifests'],
    ROOT / 'docs/30-architecture/schema-registry.md': ['snapshot-first', 'handle-returning'],
    ROOT / 'docs/30-architecture/attribute-schema-v0.md': ['attrfs-posture-v0.md', 'saved-query manifest'],
    ROOT / 'docs/30-architecture/attribute-query-schema-v0.md': ['attrfs-posture-v0.md', 'snapshot-first', 'no app-visible saved-query inventory'],
    ROOT / 'rfcs/0100-attribute-query-predicates-and-smart-folders.md': ['view-scoped, snapshot-first', 'shell-owned manifests', 'PO-ATTRQ-ENF'],
    ROOT / 'docs/10-threat-model/abuse-cases.md': ['AC-085', 'saved-query inventory', 'count-only'],
    ROOT / 'docs/20-assurance/invariant-registry.md': ['I-ATTRQ-2'],
    ROOT / 'docs/20-assurance/proof-obligation-registry.md': ['PO-ATTRQ-ENF'],
}


def fail(msg: str) -> None:
    print(f'[attrfs-posture] FAIL: {msg}')
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f'[attrfs-posture] OK: {msg}')


def read(p: Path) -> str:
    return p.read_text(encoding='utf-8')


def main() -> None:
    if not DOC.exists():
        fail('missing docs/30-architecture/attrfs-posture-v0.md')
    txt = read(DOC)
    for tok in [
        'D-ATTRFS', 'CH-ATTR v0', 'CH-ATTRQ v0', 'I-ATTRQ-1', 'I-ATTRQ-2',
        'PO-ATTRQ-VALIDATE', 'PO-ATTRQ-BOUNDS', 'PO-ATTRQ-ENF', 'AC-085', 'Phase 1'
    ]:
        if tok not in txt:
            fail(f'posture doc missing required anchor token: {tok}')
    for phrase in [
        'No ambient global index or query authority',
        'Queries stay schema-declared, closed, and small',
        'Results are handles, not paths or generic inventory probes',
        'Snapshot-first; live updates are optional and bounded',
        'Saved queries / smart folders are shell-owned manifests',
        'Authority does not widen through query execution',
        'Agent/automation use stays reviewable',
    ]:
        if phrase not in txt:
            fail(f'posture doc missing required v0 scope phrase: {phrase}')
    for phrase in [
        'No ambient global desktop search service.',
        'No raw path-returning query API.',
        'No count-only / existence-probe API for applications.',
        'No app-visible saved-query inventory / rename / delete / background watch API.',
    ]:
        if phrase not in txt:
            fail(f'posture doc missing required non-goal phrase: {phrase}')
    for ref in [
        'REF-BFS-ATTR', 'REF-HAIKU-QUERIES', 'REF-PFSD-BFS',
        'REF-APPLE-NSMETADATAQUERY', 'REF-APPLE-SPOTLIGHT-QUERYGUIDE',
    ]:
        if ref not in txt:
            fail(f'posture doc must cite {ref}')
    missing = []
    for p, needles in DISCOVERY_SURFACES.items():
        ptxt = read(p)
        if not all(n in ptxt for n in needles):
            missing.append(str(p.relative_to(ROOT)))
    if missing:
        fail('posture doc not fully wired from discovery/history/schema surfaces: ' + ', '.join(missing))
    if EVID not in read(ROOT / 'docs/00-meta/evidence-index.md'):
        fail(f'evidence-index does not register required evidence hook: {EVID}')
    ok('D-ATTRFS v0 posture is pinned and discoverable (view-scoped; snapshot-first; handle-returning; saved queries remain shell-owned manifests)')


if __name__ == '__main__':
    main()
