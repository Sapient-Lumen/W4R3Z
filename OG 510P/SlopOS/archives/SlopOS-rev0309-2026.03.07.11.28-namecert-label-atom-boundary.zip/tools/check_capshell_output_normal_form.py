#!/usr/bin/env python3
"""Drift gate: keep capshell output normal form pinned and wired.

Why this exists
--------------
`capshell.exec` can claim **at-least-once-safe** retry semantics (D-RETRYSAFE) only if
duplicates can return a deterministic "already done" outcome. In practice that requires
a minimal, stable output normal form.

We intentionally avoid introducing a new schema surface here. Instead we pin a small
contract doc that reuses CH-AREF v0 and CH-ACPOUT v0.

This guardrail is intentionally low-noise:
- ensures the contract doc exists and is discoverable,
- ensures PO-RETRY-DEDUP and I-RETRY-1 explicitly mention CH-AREF outputs for capshell,
  so the requirement cannot drift back into prose-only suggestions.

Exit code:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def fail(msg: str) -> None:
    print(f"[capshell-outnf] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[capshell-outnf] OK: {msg}")


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def require_in(path: Path, needle: str) -> None:
    if needle not in read(path):
        fail(f"{path.relative_to(ROOT)} missing required reference: {needle!r}")


def find_table_row(txt: str, row_prefix: str) -> str:
    for line in txt.splitlines():
        if line.startswith(row_prefix):
            return line
    return ""


def main() -> None:
    doc = ROOT / "docs/30-architecture/capshell-output-normal-form-v0.md"
    if not doc.exists():
        fail("missing capshell output normal form doc: docs/30-architecture/capshell-output-normal-form-v0.md")

    # Discoverability: keep it wired from stable indexes.
    require_in(ROOT / "docs/README.md", "30-architecture/capshell-output-normal-form-v0.md")
    require_in(ROOT / "docs/30-architecture/decision-map.md", "capshell-output-normal-form-v0.md")

    # Assurance anchors: keep retry safety implementable and testable.
    po = ROOT / "docs/20-assurance/proof-obligation-registry.md"
    inv = ROOT / "docs/20-assurance/invariant-registry.md"
    if not po.exists() or not inv.exists():
        fail("missing assurance registries (proof-obligation-registry.md or invariant-registry.md)")

    po_line = find_table_row(read(po), "| PO-RETRY-DEDUP |")
    if not po_line:
        fail("PO-RETRY-DEDUP row missing from proof-obligation registry")
    if "capshell.exec" not in po_line:
        fail("PO-RETRY-DEDUP row must explicitly mention capshell.exec")
    if "CH-AREF v0" not in po_line:
        fail("PO-RETRY-DEDUP row must explicitly mention CH-AREF v0 output digests")

    require_in(inv, "I-RETRY-1")
    require_in(inv, "capshell.exec")
    require_in(inv, "CH-AREF v0")

    ok("capshell output normal form doc is present, indexed, and wired into retry-safety assurance anchors")


if __name__ == "__main__":
    main()
