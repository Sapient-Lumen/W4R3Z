#!/usr/bin/env python3
"""CI drift gate: pin D-CRYPTOSVC v0 posture (op-only; context-bound; explicit-route only)."""
from __future__ import annotations
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOC = ROOT / 'docs/30-architecture/cryptosvc-posture-v0.md'
EVID = 'EVID-2026-245'
DISCOVERY_SURFACES = {
    ROOT / 'docs/README.md': ['30-architecture/cryptosvc-posture-v0.md'],
    ROOT / 'docs/30-architecture/posture-index.md': ['cryptosvc-posture-v0.md'],
    ROOT / 'docs/00-meta/profile-posture-matrix.md': ['30-architecture/cryptosvc-posture-v0.md'],
    ROOT / 'docs/00-meta/llm-runbook.md': ['docs/30-architecture/cryptosvc-posture-v0.md'],
    ROOT / 'docs/00-meta/resolved-history.md': ['cryptosvc-posture-v0.md'],
    ROOT / 'docs/30-architecture/decision-map.md': ['cryptosvc-posture-v0.md', 'ambient `SSH_AUTH_SOCK`-style discovery'],
    ROOT / 'docs/30-architecture/mechanisms.md': ['cryptosvc-posture-v0.md'],
    ROOT / 'docs/30-architecture/key-policy-schema-v0.md': ['cryptosvc-posture-v0.md'],
    ROOT / 'docs/30-architecture/keyref-schema-v0.md': ['cryptosvc-posture-v0.md'],
    ROOT / 'docs/30-architecture/crypto-audit-schema-v0.md': ['cryptosvc-posture-v0.md'],
    ROOT / 'rfcs/0067-capability-crypto-services-and-key-handles.md': ['Pinned v0 posture follow-up', 'provider-global key inventory'],
    ROOT / 'docs/20-assurance/invariant-registry.md': ['I-CRYPTO-3'],
    ROOT / 'docs/20-assurance/proof-obligation-registry.md': ['PO-CRYPTOSVC-ENF'],
}


def fail(msg: str) -> None:
    print(f'[cryptosvc-posture] FAIL: {msg}')
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f'[cryptosvc-posture] OK: {msg}')


def read(p: Path) -> str:
    return p.read_text(encoding='utf-8')


def main() -> None:
    if not DOC.exists():
        fail('missing docs/30-architecture/cryptosvc-posture-v0.md')
    txt = read(DOC)
    for tok in [
        'D-CRYPTOSVC', 'D-AUTHAGENT', 'CH-KEYPOL v0', 'CH-KEYREF v0', 'CH-CRYPTOAUDIT v0',
        'I-AUTHAGENT-1', 'I-CRYPTO-1', 'I-CRYPTO-2', 'I-CRYPTO-3',
        'PO-AUTHAGENT-NONEXPORT', 'PO-CRYPTOAUDIT-REDACT', 'PO-CRYPTOPOL-ENF', 'PO-CRYPTOSVC-ENF',
    ]:
        if tok not in txt:
            fail(f'posture doc missing required anchor token: {tok}')
    for phrase in [
        'No ambient agent discovery or socket convention',
        'Op-only, closed external surface',
        'Policy is pinned as data, not inferred from call sites',
        'Context-bound use is the expected v0 posture',
        'Handles and explicit refs, not inventory APIs',
        'Confirmation and rate limits are explicit policy, not hidden UI behavior',
        'Audit is digest-first and redaction-safe',
        'Hardware backing is a profile annex, not an API fork',
    ]:
        if phrase not in txt:
            fail(f'posture doc missing required v0 scope phrase: {phrase}')
    for phrase in [
        'No ambient `SSH_AUTH_SOCK` / path / env agent discovery',
        'No provider-global key inventory/search API',
        'No PKCS#11-style slot/session/object model on the core seam',
        'No raw private-key export/import on the app-facing seam',
    ]:
        if phrase not in txt:
            fail(f'posture doc missing required non-goal phrase: {phrase}')
    for ref in ['REF-PLAN9-FACTOTUM', 'REF-OPENSSH-AGENTRESTRICT', 'REF-ANDROID-KEYSTORE']:
        if ref not in txt:
            fail(f'posture doc must cite {ref}')
    missing = []
    for p, needles in DISCOVERY_SURFACES.items():
        ptxt = read(p)
        if not all(n in ptxt for n in needles):
            missing.append(str(p.relative_to(ROOT)))
    if missing:
        fail('posture doc not fully wired from discovery/history/schema surfaces: ' + ', '.join(missing))
    if EVID not in read(ROOT / 'docs/00-meta/evidence-index.md'):
        fail(f'evidence-index does not register required evidence hook: {EVID}')
    ok('D-CRYPTOSVC v0 posture is pinned and discoverable (op-only; context-bound; explicit-route only; no ambient agent socket or provider-global key inventory)')


if __name__ == '__main__':
    main()
