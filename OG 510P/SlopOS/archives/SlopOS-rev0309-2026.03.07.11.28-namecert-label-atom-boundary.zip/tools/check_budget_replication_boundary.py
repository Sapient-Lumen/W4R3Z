#!/usr/bin/env python3
"""Drift gate for the budget replication boundary (narrowing OQ-0001)."""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BOUNDARY = ROOT / "docs/30-architecture/budget-replication-boundary-v0.md"
DOCS_README = ROOT / "docs/README.md"
RUNBOOK = ROOT / "docs/00-meta/llm-runbook.md"
REPL = ROOT / "docs/30-architecture/replication-contracts-v0.md"
REGISTRY = ROOT / "docs/30-architecture/replication-object-family-registry.md"
DEFAULTS = ROOT / "docs/30-architecture/profile-repl-defaults.md"
HOT_SURFACE = ROOT / "docs/30-architecture/hot-action-surface-v0.md"
HOT_BOUND = ROOT / "docs/30-architecture/hot-action-boundaries-v0.md"
BUDGET = ROOT / "docs/30-architecture/budget-lease-schema-v0.md"
RFC = ROOT / "rfcs/0058-operation-scoped-budget-leases.md"
DECISION = ROOT / "docs/30-architecture/decision-map.md"
TRAJ = ROOT / "docs/00-meta/trajectory-map.md"
EVID = ROOT / "docs/00-meta/evidence-index.md"
TOOLS = ROOT / "tools/README.md"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def die(msg: str) -> None:
    print(f"ERROR: {msg}", file=sys.stderr)
    raise SystemExit(1)


def require(text: str, needle: str, label: str) -> None:
    if needle not in text:
        die(f"{label} missing required text: {needle}")


def main() -> int:
    boundary = read(BOUNDARY)
    for needle in (
        'narrow **OQ-0001**',
        '`budget` means owner-routed issuer / lease-lineage metadata only',
        'mint a new local budget lease',
        'widen a lease limit/scope/expiry',
        'new RFC-first transfer/import surface',
        'REF-ESCROW-TODS86',
        'REF-BOUNDED-COUNTER-SRDS15',
        'REF-CRDT-INRIA11',
    ):
        require(boundary, needle, BOUNDARY.name)

    require(read(DOCS_README), 'budget-replication-boundary-v0.md', DOCS_README.name)
    require(read(RUNBOOK), 'budget-replication-boundary-v0.md', RUNBOOK.name)
    for path in (REPL, REGISTRY, DEFAULTS, HOT_SURFACE, HOT_BOUND, BUDGET, RFC, DECISION):
        require(read(path), 'budget-replication-boundary-v0.md', path.name)

    traj = read(TRAJ)
    require(traj, '**OQ-0001 Hybrid follow-ups (ADR-0005)**', TRAJ.name)
    require(traj, 'budget-replication-boundary-v0.md', TRAJ.name)

    evid = read(EVID)
    require(evid, 'EVID-2026-266', EVID.name)
    require(evid, 'tools/check_budget_replication_boundary.py', EVID.name)
    require(read(TOOLS), 'check_budget_replication_boundary.py', TOOLS.name)

    print('[budget-repl-boundary] OK: budget RC1 replication stays owner-routed issuer/lineage metadata only; portable spend authority remains local and explicit')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
