#!/usr/bin/env python3
"""CI guardrail: keep capshell exec-pack v2 reqctx binding coherent.

Rationale:
- No ambient authority in workflows: execution context must be explicit and complete.
- CH-REQCTX is veto-only: it can narrow/deny and correlate receipts, never grant effects.
- Drift seam: action meta reqctx vs runner-side context. If CH-EXECPACK doesn't bind reqctx,
  or if ACP/capshell wiring stops requiring coherence, correlation/cancel semantics can drift
  into ad-hoc fields.

This check is conservative and fail-closed: it asserts required anchors exist across
schemas, validator semantics, registries, and deny-code vocabulary.
"""

from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def fail(msg: str) -> int:
    print(f"[capshell-execpack-reqctx] FAIL: {msg}")
    return 1


def ok(msg: str) -> None:
    print(f"[capshell-execpack-reqctx] OK: {msg}")


def main() -> int:
    execpack = ROOT / "docs/30-architecture/capshell-exec-pack-schema-v2.md"
    acp_schema = ROOT / "docs/70-llm-control/acp-action-schema-v0.md"
    acp_sem = ROOT / "docs/70-llm-control/acp-validator-semantics.md"
    kindreg = ROOT / "docs/70-llm-control/acp-action-kind-registry.md"
    schemareg = ROOT / "docs/30-architecture/schema-registry.md"
    denyreg = ROOT / "docs/30-architecture/deny-code-registry.md"
    invreg = ROOT / "docs/20-assurance/invariant-registry.md"
    poreg = ROOT / "docs/20-assurance/proof-obligation-registry.md"
    evid = ROOT / "docs/00-meta/evidence-index.md"

    for p in (execpack, acp_schema, acp_sem, kindreg, schemareg, denyreg, invreg, poreg, evid):
        if not p.exists():
            return fail(f"missing required file: {p.relative_to(ROOT)}")

    # 1) CH-EXECPACK v2 binds reqctx_digest.
    e = read(execpack)
    must = ["CH-EXECPACK v2", "reqctx_digest", "digest(CH-REQCTX v1)", "v: 2"]
    missing = [m for m in must if m not in e]
    if missing:
        return fail(f"capshell-exec-pack-schema-v2.md missing anchor(s): {', '.join(missing)}")
    ok("CH-EXECPACK v2 binds reqctx_digest")

    # 2) Schema registry lists CH-EXECPACK v2 and links to the v2 file.
    sr = read(schemareg)
    if "| CH-EXECPACK v2 |" not in sr or "(capshell-exec-pack-schema-v2.md)" not in sr.replace("./", ""):
        return fail("schema-registry.md missing CH-EXECPACK v2 row/link")
    ok("schema registry includes CH-EXECPACK v2")

    # 3) ACP schema and kind registry mention exec_pack_digest = digest(CH-EXECPACK v2).
    a = read(acp_schema)
    if "capshell.exec" in a and "CH-EXECPACK v2" not in a:
        return fail("acp-action-schema-v0.md should reference CH-EXECPACK v2 for capshell.exec")
    k = read(kindreg)
    must = ["exec_pack_digest", "CH-EXECPACK v2", "reqctx_digest", "PO-CAPSHELL-REQCTX-BIND"]
    missing = [m for m in must if m not in k]
    if missing:
        return fail(f"acp-action-kind-registry.md missing capshell execpack/reqctx anchor(s): {', '.join(missing)}")
    ok("ACP schema + kind registry reference CH-EXECPACK v2 and reqctx binding")

    # 4) Validator semantics require reqctx coherence and name the deny code.
    s = read(acp_sem)
    must = ["digest(CH-EXECPACK v2)", "reqctx_digest", "meta.reqctx_digest", "PO-CAPSHELL-REQCTX-BIND", "reqctx-mismatch"]
    missing = [m for m in must if m not in s]
    if missing:
        return fail(f"acp-validator-semantics.md missing execpack-v2 reqctx binding anchor(s): {', '.join(missing)}")
    ok("ACP validator semantics require execpack reqctx coherence")

    # 5) Deny-code registry includes reqctx-mismatch.
    d = read(denyreg)
    if "`reqctx-mismatch`" not in d:
        return fail("deny-code-registry.md missing reqctx-mismatch")
    ok("deny-code registry includes reqctx-mismatch")

    # 6) Assurance wiring includes I-EXECPACK-2 and PO-CAPSHELL-REQCTX-BIND.
    if "I-EXECPACK-2" not in read(invreg):
        return fail("invariant-registry.md missing I-EXECPACK-2")
    pr = read(poreg)
    if "PO-CAPSHELL-REQCTX-BIND" not in pr:
        return fail("proof-obligation-registry.md missing PO-CAPSHELL-REQCTX-BIND")
    ok("Assurance wiring present (I-EXECPACK-2, PO-CAPSHELL-REQCTX-BIND)")

    # 7) Evidence index includes EVID-2026-153 referencing this tool.
    ev = read(evid)
    if "EVID-2026-153" not in ev or "tools/check_capshell_execpack_reqctx.py" not in ev:
        return fail("evidence-index.md missing EVID-2026-153 entry pointing at this tool")
    ok("Evidence index includes EVID-2026-153")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
