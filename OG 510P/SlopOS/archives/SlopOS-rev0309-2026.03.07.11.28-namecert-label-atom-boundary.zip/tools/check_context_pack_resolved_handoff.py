#!/usr/bin/env python3
"""Drift gate for the context pack's resolved-history handoff.

Keeps `out/context_pack.md` aligned with the canonical short resolved-OQ window in
`docs/00-meta/trajectory-map.md`, and requires an explicit pointer to
`docs/00-meta/resolved-history.md` so continuation prompts do not lose the full
closure history once the short window rotates.
"""
from __future__ import annotations

import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TRAJ = ROOT / "docs/00-meta/trajectory-map.md"
GEN = ROOT / "tools/gen_context_pack.py"
OUT = ROOT / "out/_ci_context_pack_resolved_handoff.md"
RECENT_HEADING = "## Recently resolved (from trajectory map)"
HISTORY_LINE = "Full closure history / posture overflow: `docs/00-meta/resolved-history.md`."
MAX_BULLETS = 8
RE_OQ = re.compile(r"^\-\s+\*\*(OQ\-\d{4})\s+(.+?)\*\*:\s+(.+)$")


def fail(msg: str) -> None:
    print(f"[ctxpack-resolved-handoff] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[ctxpack-resolved-handoff] OK: {msg}")


def read(path: Path) -> str:
    if not path.exists():
        fail(f"missing file: {path}")
    return path.read_text(encoding="utf-8")


def parse_recently_resolved(md: str) -> list[str]:
    lines = md.splitlines()
    in_section = False
    out: list[str] = []
    for line in lines:
        if line.strip() == "## Recently resolved (keep short)":
            in_section = True
            continue
        if in_section and line.startswith("## "):
            break
        if not in_section:
            continue
        m = RE_OQ.match(line.strip())
        if not m:
            continue
        out.append(f"{m.group(1)} — {m.group(2).strip()}: {m.group(3).strip()}")
    return out


def section_lines(md: str, heading: str) -> list[str]:
    lines = md.splitlines()
    start = None
    for i, line in enumerate(lines):
        if line.strip() == heading:
            start = i + 1
            break
    if start is None:
        fail(f"missing heading {heading!r}")
    out: list[str] = []
    for line in lines[start:]:
        if line.startswith("## "):
            break
        out.append(line.rstrip())
    return out


def generate() -> str:
    OUT.parent.mkdir(parents=True, exist_ok=True)
    try:
        subprocess.run(["python3", str(GEN), "--out", str(OUT.relative_to(ROOT))], cwd=str(ROOT), check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    except subprocess.CalledProcessError as e:
        fail("gen_context_pack.py failed: " + (e.stderr.strip() or e.stdout.strip() or "(no output)"))
    return read(OUT)


def main() -> None:
    expected = parse_recently_resolved(read(TRAJ))[:MAX_BULLETS]
    ctx = generate()
    recent = section_lines(ctx, RECENT_HEADING)
    bullets = [ln.strip()[2:].strip() for ln in recent if ln.strip().startswith("- ")]
    if bullets != expected:
        fail("context pack Recently resolved bullets must mirror the trajectory-map OQ window exactly (same ids, order, and text)")
    if HISTORY_LINE not in recent:
        fail("context pack Recently resolved section must point to docs/00-meta/resolved-history.md for full closure history / overflow")
    ok(f"context pack mirrors the {len(expected)}-item resolved-OQ window and points to resolved-history.md")


if __name__ == "__main__":
    main()
