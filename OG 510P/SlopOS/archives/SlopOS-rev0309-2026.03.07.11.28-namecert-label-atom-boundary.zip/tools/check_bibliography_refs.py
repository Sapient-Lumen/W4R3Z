#!/usr/bin/env python3
"""Bibliography REF-token closure drift gate.

Goal: prevent citation drift where docs/RFCs/ADRs mention `REF-*` tokens that
are not defined in docs/00-meta/bibliography.md.

Why it matters:
- The archive is an authority substrate; references are a discovery surface.
- LLM edits commonly introduce typos or partial REF keys (e.g., missing suffix,
  dots/underscores, wrong hyphenation) that silently break traceability.
- This gate keeps REF tokens mechanically closed over the bibliography.

What it enforces (intentionally simple):
- Every `REF-...` token used anywhere in repo markdown (except the bibliography
  itself) must be defined as an entry in the bibliography.
- Bibliography entries must be unique (no duplicate REF keys).
- Each bibliography entry line includes an explicit http(s) URL.

Token character set:
- REF keys in this repo commonly include '.', '_' and '-' (e.g., REF-CAPNP-1.0-CANCEL,
  REF-WIN-WAIT_ABANDONED). We therefore treat a REF token as:
  REF-[A-Z0-9][A-Z0-9_.-]*

Exit codes:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

import re
from pathlib import Path


# Definition lines in bibliography look like:
# - **REF-FOO-BAR** — ... — https://...
RE_BIB_DEF = re.compile(r"^\s*-\s+\*\*(REF-[A-Z0-9][A-Z0-9_.-]*)\*\*")

# REF tokens as they appear in prose.
# Use custom boundaries because '.' is not a word char, so \b doesn't work.
RE_REF_TOKEN = re.compile(
    r"(?<![A-Za-z0-9_.-])"
    r"(REF-[A-Z0-9](?:[A-Z0-9_.-]*[A-Z0-9])?)"
    r"(?![A-Za-z0-9])"
)


def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="strict")


def fail(msg: str) -> None:
    print(f"[bib-ref] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[bib-ref] OK: {msg}")


def load_bibliography_defs(bib_path: Path) -> set[str]:
    txt = read(bib_path)
    defs: set[str] = set()
    dups: list[str] = []
    missing_url: list[str] = []

    for i, line in enumerate(txt.splitlines(), 1):
        m = RE_BIB_DEF.match(line)
        if not m:
            continue
        key = m.group(1)
        if key in defs:
            dups.append(f"{bib_path.as_posix()}:{i}: {key}")
        defs.add(key)
        if "http://" not in line and "https://" not in line:
            missing_url.append(f"{bib_path.as_posix()}:{i}: {key}")

    if not defs:
        fail("failed to parse any REF entries from bibliography")
    if dups:
        preview = "\n".join(dups[:40])
        more = "" if len(dups) <= 40 else f"\n… (+{len(dups)-40} more)"
        fail(
            "duplicate REF keys in bibliography (must be unique)\n"
            f"{preview}{more}"
        )
    if missing_url:
        preview = "\n".join(missing_url[:40])
        more = "" if len(missing_url) <= 40 else f"\n… (+{len(missing_url)-40} more)"
        fail(
            "bibliography REF entries missing an explicit http(s) URL on the same line\n"
            f"{preview}{more}"
        )

    return defs


def iter_md_files(root: Path) -> list[Path]:
    return sorted([p for p in root.rglob("*.md") if p.is_file()])


def main() -> None:
    root = repo_root()
    bib_path = root / "docs/00-meta/bibliography.md"
    if not bib_path.exists():
        fail("missing docs/00-meta/bibliography.md")

    defs = load_bibliography_defs(bib_path)

    used: set[str] = set()
    offenders: dict[str, set[str]] = {}

    for p in iter_md_files(root):
        if p.resolve() == bib_path.resolve():
            continue
        txt = read(p)
        toks = set(RE_REF_TOKEN.findall(txt))
        if not toks:
            continue
        used.update(toks)
        missing = toks - defs
        if missing:
            offenders[p.relative_to(root).as_posix()] = missing

    if offenders:
        lines: list[str] = []
        for f in sorted(offenders.keys()):
            miss = sorted(offenders[f])
            # Keep output small but useful.
            lines.append(f"{f}: {', '.join(miss[:12])}{' …' if len(miss) > 12 else ''}")
        preview = "\n".join(lines[:60])
        more = "" if len(lines) <= 60 else f"\n… (+{len(lines)-60} more files)"
        fail(
            "undefined REF tokens referenced outside bibliography\n"
            f"{preview}{more}\n"
            "Fix: add the missing REF entry to docs/00-meta/bibliography.md (with an explicit URL), "
            "or correct the REF token in the doc."
        )

    ok(f"all {len(used)} REF tokens referenced in repo markdown resolve to bibliography entries")


if __name__ == "__main__":
    main()
