#!/usr/bin/env python3
"""CI guardrail: keep CH-ACPOUT (ACP outcome receipts) wired and discoverable.

Rationale:
- This repo treats schemas + validators + receipts as the stable product surface.
- Without a stable, registered outcome-receipt shape, accept paths drift back into
  ad-hoc strings or implicit conventions that are hard to audit and easy for LLM
  edits to accidentally widen.

This check is intentionally conservative and fail-closed.
"""

from __future__ import annotations

import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def fail(msg: str) -> int:
    print(f"[acp-outcome] FAIL: {msg}")
    return 1


def ok(msg: str) -> None:
    print(f"[acp-outcome] OK: {msg}")


def main() -> int:
    schema = ROOT / "docs/30-architecture/acp-outcome-receipt-schema-v0.md"
    schemareg = ROOT / "docs/30-architecture/schema-registry.md"
    docs_readme = ROOT / "docs/README.md"
    acp_schema = ROOT / "docs/70-llm-control/acp-action-schema-v0.md"
    acp_sem = ROOT / "docs/70-llm-control/acp-validator-semantics.md"
    po_reg = ROOT / "docs/20-assurance/proof-obligation-registry.md"
    inv_reg = ROOT / "docs/20-assurance/invariant-registry.md"
    evid = ROOT / "docs/00-meta/evidence-index.md"

    for p in (schema, schemareg, docs_readme, acp_schema, acp_sem, po_reg, inv_reg, evid):
        if not p.exists():
            return fail(f"missing required file: {p.relative_to(ROOT)}")

    # 1) Schema doc sanity.
    s_txt = read(schema)
    head = "\n".join(s_txt.splitlines()[:80])
    if "CH-ACPOUT v0" not in head and "CH-ACPOUT v0" not in s_txt:
        return fail("acp-outcome-receipt-schema-v0.md does not mention 'CH-ACPOUT v0'")
    required_snips = [
        "action_digest",
        "outcome",
        "conflict_key_digest",
        "order_digest",
        "deny_digest",
        "Non-authoritative rule",
    ]
    missing = [x for x in required_snips if x not in s_txt]
    if missing:
        return fail(f"CH-ACPOUT schema doc missing expected anchor(s): {', '.join(missing)}")
    ok("CH-ACPOUT schema doc present with required anchors")

    # 2) Registered in schema registry with correct link.
    reg_txt = read(schemareg)
    if "CH-ACPOUT v0" not in reg_txt:
        return fail("schema-registry.md missing CH-ACPOUT v0 entry")
    if "(acp-outcome-receipt-schema-v0.md)" not in reg_txt.replace("./", ""):
        return fail("schema-registry.md CH-ACPOUT row must link to acp-outcome-receipt-schema-v0.md")
    ok("CH-ACPOUT registered in schema registry")

    # 3) Discoverable from docs/README.
    dr = read(docs_readme)
    if "acp-outcome-receipt-schema-v0.md" not in dr and "CH-ACPOUT" not in dr:
        return fail("docs/README.md does not reference CH-ACPOUT outcome receipt schema")
    ok("CH-ACPOUT referenced from docs/README.md")

    # 4) Referenced from ACP control docs.
    if "CH-ACPOUT v0" not in read(acp_schema):
        return fail("acp-action-schema-v0.md does not reference CH-ACPOUT v0")
    if "CH-ACPOUT v0" not in read(acp_sem):
        return fail("acp-validator-semantics.md does not reference CH-ACPOUT v0")
    ok("CH-ACPOUT referenced from ACP control docs")

    # 5) Assurance wiring.
    if "I-ACPOUT-1" not in read(inv_reg):
        return fail("invariant-registry.md missing I-ACPOUT-1")
    if "PO-ACT-ACPOUT" not in read(po_reg):
        return fail("proof-obligation-registry.md missing PO-ACT-ACPOUT")
    ok("Assurance wiring present (I-ACPOUT-1, PO-ACT-ACPOUT)")

    # 6) Evidence register.
    e_txt = read(evid)
    if "EVID-2026-145" not in e_txt or "tools/check_acp_outcome_wiring.py" not in e_txt:
        return fail("evidence-index.md missing EVID-2026-145 entry pointing at this tool")
    ok("Evidence index includes EVID-2026-145")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
