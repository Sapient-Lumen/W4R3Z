#!/usr/bin/env python3
"""Drift gate for the Phase 1 cache-topology authority boundary (narrowing OQ-0001)."""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BOUNDARY = ROOT / "docs/30-architecture/cache-topology-authority-boundary-v0.md"
HWFACT = ROOT / "docs/30-architecture/hardware-facts-schema-v0.md"
CLUSTER = ROOT / "docs/30-architecture/cluster-derivation.md"
CLUSTERMAP = ROOT / "docs/30-architecture/cluster-map-schema-v0.md"
AUTO = ROOT / "docs/30-architecture/cluster-auto-boundary-v0.md"
MULTICORE = ROOT / "docs/30-architecture/multicore-architecture-options.md"
DECISION = ROOT / "docs/30-architecture/decision-map.md"
RFC = ROOT / "rfcs/0018-system-knowledge-base-and-hardware-facts.md"
DOCS_README = ROOT / "docs/README.md"
RUNBOOK = ROOT / "docs/00-meta/llm-runbook.md"
TRAJ = ROOT / "docs/00-meta/trajectory-map.md"
BIB = ROOT / "docs/00-meta/bibliography.md"
EVID = ROOT / "docs/00-meta/evidence-index.md"
TOOLS = ROOT / "tools/README.md"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def die(msg: str) -> None:
    print(f"ERROR: {msg}", file=sys.stderr)
    raise SystemExit(1)


def require(text: str, needle: str, label: str) -> None:
    if needle not in text:
        die(f"{label} missing required text: {needle}")


def main() -> int:
    boundary = read(BOUNDARY)
    for needle in (
        'narrow **OQ-0001**',
        'CH-HWFACT cache-topology facts are **placement hints only**',
        '`cpu_topology[].l3_cache_id`',
        'change the default `preferred_boundary = auto` derivation order',
        'create a new authoritative cluster `kind` such as `cache_group` or `llc`',
        'justify cross-NUMA cluster merges',
        'separate RFC-first policy surface',
        'REF-HWLOC-OBJTYPES',
        'REF-LINUX-CACHEINFO',
        'REF-ACPI-PPTT',
    ):
        require(boundary, needle, BOUNDARY.name)

    require(read(HWFACT), 'cache-topology-authority-boundary-v0.md', HWFACT.name)
    require(read(HWFACT), 'placement hint only', HWFACT.name)
    require(read(CLUSTER), 'cache-topology-authority-boundary-v0.md', CLUSTER.name)
    require(read(CLUSTERMAP), 'cache-topology-authority-boundary-v0.md', CLUSTERMAP.name)
    require(read(AUTO), 'cache-topology-authority-boundary-v0.md', AUTO.name)
    require(read(MULTICORE), 'cache-topology-authority-boundary-v0.md', MULTICORE.name)

    decision = read(DECISION)
    require(decision, 'cache-topology-authority-boundary-v0.md', DECISION.name)
    require(decision, 'placement hints only', DECISION.name)

    require(read(RFC), 'cache-topology-authority-boundary-v0.md', RFC.name)
    require(read(DOCS_README), 'cache-topology-authority-boundary-v0.md', DOCS_README.name)
    require(read(RUNBOOK), 'cache-topology-authority-boundary-v0.md', RUNBOOK.name)

    traj = read(TRAJ)
    require(traj, '**OQ-0001 Hybrid follow-ups (ADR-0005)**', TRAJ.name)
    require(traj, 'cache-topology-authority-boundary-v0.md', TRAJ.name)
    require(traj, 'placement hints only', TRAJ.name)

    bib = read(BIB)
    for needle in ('REF-HWLOC-OBJTYPES', 'REF-LINUX-CACHEINFO', 'REF-ACPI-PPTT'):
        require(bib, needle, BIB.name)

    evid = read(EVID)
    require(evid, 'EVID-2026-269', EVID.name)
    require(evid, 'tools/check_cache_topology_authority_boundary.py', EVID.name)
    require(read(TOOLS), 'check_cache_topology_authority_boundary.py', TOOLS.name)

    print('[cache-topology-boundary] OK: CH-HWFACT cache/LLC facts stay placement hints only; auto clustering/ownership boundaries remain explicit')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
