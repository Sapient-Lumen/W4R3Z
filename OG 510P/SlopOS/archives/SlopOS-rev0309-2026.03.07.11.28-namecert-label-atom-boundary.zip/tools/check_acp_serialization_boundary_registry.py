#!/usr/bin/env python3
"""CI guardrail: keep ACP serialization-boundary tokens registry-closed.

Why
---
The ACP kind registry pins where correctness-required serialization lives for
ordered kinds (validator vs svc:<name>). Under LLM or human edits, it's easy to
introduce typo'd or ad-hoc service boundary names, weakening D-COMMUTE/Hybrid
review surfaces.

Source of truth (stable diff surface):
- docs/30-architecture/serialization-boundary-registry.md

Checks (fail closed):
- The serialization-boundary token table parses and is non-empty.
- All tokens used in the ACP kind registry Serialization boundary column are in
  the allowlist table (except that 'none' is permitted only for non-ordered kinds;
  ordered-kinds must use a non-'none' token).

This guardrail is intentionally tiny and conservative.
"""

from __future__ import annotations

import re
import sys
from dataclasses import dataclass
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


@dataclass
class Problem:
    path: Path
    detail: str


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def strip_code_fences(txt: str) -> str:
    out: list[str] = []
    in_fence = False
    for line in txt.splitlines():
        if line.strip().startswith("```"):
            in_fence = not in_fence
            continue
        if not in_fence:
            out.append(line)
    return "\n".join(out)


def normalize_cell(cell: str) -> str:
    s = cell.strip()
    if s.startswith("`") and s.endswith("`") and len(s) >= 2:
        s = s[1:-1].strip()
    return s


def parse_allowlist() -> tuple[set[str], list[Problem]]:
    problems: list[Problem] = []
    p = ROOT / "docs/30-architecture/serialization-boundary-registry.md"
    if not p.exists():
        return set(), [Problem(p, "missing serialization-boundary-registry.md")]

    txt = strip_code_fences(read(p))
    # Parse the first markdown table in the doc.
    lines = txt.splitlines()
    header_i = None
    for i, ln in enumerate(lines):
        if ln.strip().startswith("| Token |"):
            header_i = i
            break
    if header_i is None:
        return set(), [Problem(p, "serialization-boundary registry table header '| Token |' not found")]

    # Expect separator line at header_i + 1.
    if header_i + 1 >= len(lines) or "---" not in lines[header_i + 1]:
        return set(), [Problem(p, "serialization-boundary registry table missing separator row")]

    toks: list[str] = []
    for ln in lines[header_i + 2 :]:
        s = ln.strip()
        if not s.startswith("|"):
            break
        # Stop if we hit a blank alignment row.
        cols = [c.strip() for c in s.strip("|").split("|")]
        if len(cols) < 1:
            continue
        tok = normalize_cell(cols[0])
        if not tok:
            continue
        toks.append(tok)

    if not toks:
        problems.append(Problem(p, "no tokens parsed from serialization-boundary registry table"))
        return set(), problems

    dup = sorted({t for t in toks if toks.count(t) > 1})
    if dup:
        problems.append(Problem(p, "duplicate token(s) in serialization-boundary registry table: " + ", ".join(dup)))

    return set(toks), problems


def parse_acp_kind_rows() -> tuple[list[dict[str, str]], list[Problem]]:
    problems: list[Problem] = []
    reg = ROOT / "docs/70-llm-control/acp-action-kind-registry.md"
    if not reg.exists():
        return [], [Problem(reg, "missing acp-action-kind-registry.md")]

    txt = strip_code_fences(read(reg))
    lines = txt.splitlines()

    header_idx = None
    for i, ln in enumerate(lines):
        if ln.strip().startswith("| Kind |"):
            header_idx = i
            break
    if header_idx is None:
        return [], [Problem(reg, "ACP kind registry table header not found")]

    rows: list[str] = []
    for ln in lines[header_idx + 2 :]:
        if not ln.strip().startswith("|"):
            break
        if ln.strip() == "|":
            break
        rows.append(ln)

    parsed: list[dict[str, str]] = []
    for ln in rows:
        parts = [p.strip() for p in ln.strip().strip("|").split("|")]
        if len(parts) != 8:
            problems.append(Problem(reg, f"ACP kind table row must have 8 columns; got {len(parts)}: {ln.strip()}"))
            continue
        parsed.append(
            {
                "kind": parts[0],
                "commute": parts[3],
                "serializes": parts[6],
            }
        )
    return parsed, problems


def main() -> int:
    allow, problems = parse_allowlist()
    problems2: list[Problem] = []
    kinds, problems2 = parse_acp_kind_rows()
    problems.extend(problems2)

    reg_path = ROOT / "docs/70-llm-control/acp-action-kind-registry.md"

    if allow:
        # Basic sanity: require the canonical reserved tokens.
        for required in ("validator", "none"):
            if required not in allow:
                problems.append(Problem(ROOT / "docs/30-architecture/serialization-boundary-registry.md", f"allowlist missing required token: {required}"))

    for row in kinds:
        kind = normalize_cell(row["kind"]).strip("`")
        stance = row["commute"].lower()
        ordered = "ordered" in stance
        ser = normalize_cell(row["serializes"])

        if not ser:
            problems.append(Problem(reg_path, f"kind {kind} has empty Serialization boundary"))
            continue

        # Existing check_acp_serialization_boundary enforces ordered vs none,
        # but we keep a redundant fail-closed check here for clarity.
        if ordered and ser == "none":
            problems.append(Problem(reg_path, f"kind {kind} is ordered but Serialization boundary is 'none'"))
        if (not ordered) and ser != "none":
            problems.append(Problem(reg_path, f"kind {kind} is not ordered but Serialization boundary is '{ser}' (expected 'none')"))

        if allow and ser not in allow:
            problems.append(Problem(reg_path, f"kind {kind} uses Serialization boundary token not in allowlist: {ser}"))

    if problems:
        print("ACP serialization-boundary allowlist check failed:\n")
        for pr in problems:
            rel = pr.path
            try:
                rel = pr.path.relative_to(ROOT)
            except Exception:
                pass
            print(f"- {rel}: {pr.detail}")
        return 1

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
