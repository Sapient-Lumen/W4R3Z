#!/usr/bin/env python3
"""Assurance token closure drift gate.

Goal: prevent drift where docs/RFCs/ADRs mention assurance identifiers that are
not defined in the canonical registries.

Why it matters:
- The archive is an authority substrate; assurance surfaces (assumptions,
  claims, invariants, proof obligations) are stable diff surfaces.
- LLM edits commonly introduce typo'd IDs (e.g., PO-FOO-1 vs PO-FOO-I) that
  silently break traceability.
- This gate keeps A-/C-/I-/PO- references mechanically closed.

What it enforces:
- Every A-* token referenced in repo markdown resolves to an entry in
  docs/10-threat-model/assumption-registry.md
- Every C-* token referenced in repo markdown resolves to an entry in
  docs/20-assurance/claim-registry.md
- Every I-* token referenced in repo markdown resolves to an entry in
  docs/20-assurance/invariant-registry.md
- Every PO-* token referenced in repo markdown resolves to an entry in
  docs/20-assurance/proof-obligation-registry.md

Notes:
- The registry headers contain strings like "A-IDs" / "PO-ID"; these are
  explicitly excluded.
- This is intentionally small and conservative; if it becomes complex, justify
  with an RFC/ADR.

Exit codes:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

import re
from pathlib import Path


# Definition patterns (capture *definitions*, not arbitrary references)
# Require tokens to end in an alnum (avoid matching prefix examples like "I-FOO-").
RE_A_DEF = re.compile(r"^\s*-\s+\*\*(A-[A-Z0-9][A-Z0-9-]*[A-Z0-9])\b", re.MULTILINE)
RE_C_DEF = re.compile(r"^\s*-\s+\*\*(C-[A-Z0-9][A-Z0-9-]*[A-Z0-9])\b", re.MULTILINE)
RE_I_DEF = re.compile(r"^\s*-\s+\*\*(I-[A-Z0-9][A-Z0-9-]*[A-Z0-9])\b", re.MULTILINE)
# Proof obligations are mostly in a table, but a few are headings for emphasis.
RE_PO_DEF_ROW = re.compile(r"^\|\s*(PO-[A-Z0-9][A-Z0-9-]*[A-Z0-9])\s*\|", re.MULTILINE)
RE_PO_DEF_HDR = re.compile(r"^#{2,3}\s+(PO-[A-Z0-9][A-Z0-9-]*[A-Z0-9])\b", re.MULTILINE)

# Token patterns in prose/examples.
# Require tokens to end in an alnum (avoid matching prefix families like "PO-ABI-").
RE_A_TOK = re.compile(r"(?<![A-Za-z0-9])(A-[A-Z0-9][A-Z0-9-]*[A-Z0-9])(?![A-Za-z0-9-])")
RE_C_TOK = re.compile(r"(?<![A-Za-z0-9])(C-[A-Z0-9][A-Z0-9-]*[A-Z0-9])(?![A-Za-z0-9-])")
RE_I_TOK = re.compile(r"(?<![A-Za-z0-9])(I-[A-Z0-9][A-Z0-9-]*[A-Z0-9])(?![A-Za-z0-9-])")
RE_PO_TOK = re.compile(r"(?<![A-Za-z0-9])(PO-[A-Z0-9][A-Z0-9-]*[A-Z0-9])(?![A-Za-z0-9-])")

EXCLUDE = {
    "A-ID",
    "A-IDs",
    "C-ID",
    "C-IDs",
    "I-ID",
    "I-IDs",
    "PO-ID",
    "PO-IDs",
}


def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="strict")


def fail(msg: str) -> None:
    print(f"[assure-ref] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[assure-ref] OK: {msg}")


def iter_md_files(root: Path) -> list[Path]:
    return sorted([p for p in root.rglob("*.md") if p.is_file()])


def load_defs(path: Path, name: str, rex: re.Pattern[str]) -> set[str]:
    txt = read(path)
    defs: set[str] = set()
    dups: list[str] = []

    for m in rex.finditer(txt):
        tok = m.group(1)
        if tok in EXCLUDE:
            continue
        if tok in defs:
            # best-effort line number: count newlines before match
            ln = txt.count("\n", 0, m.start()) + 1
            dups.append(f"{path.as_posix()}:{ln}: {tok}")
        defs.add(tok)

    if not defs:
        fail(f"failed to parse any {name} definitions from {path.as_posix()}")
    if dups:
        preview = "\n".join(dups[:40])
        more = "" if len(dups) <= 40 else f"\n… (+{len(dups)-40} more)"
        fail(
            f"duplicate {name} keys in registry (must be unique)\n{preview}{more}"
        )

    return defs

def load_po_defs(path: Path) -> set[str]:
    """Load PO definitions from the proof obligation registry.

    POs are defined both in the main table and (rarely) as explicit headings.
    We treat both as defining entries and enforce uniqueness across both forms.
    """

    txt = read(path)
    defs: set[str] = set()
    dups: list[str] = []

    for i, line in enumerate(txt.splitlines(), 1):
        m = RE_PO_DEF_ROW.match(line.strip())
        key: str | None = None
        if m:
            key = m.group(1)
        else:
            m2 = RE_PO_DEF_HDR.match(line.strip())
            if m2:
                key = m2.group(1)
        if not key:
            continue
        if key in EXCLUDE:
            continue
        if key in defs:
            dups.append(f"{path.as_posix()}:{i}: {key}")
        defs.add(key)

    if not defs:
        fail(f"failed to parse any proof-obligation definitions from {path.as_posix()}")
    if dups:
        preview = "\n".join(dups[:40])
        more = "" if len(dups) <= 40 else f"\n… (+{len(dups)-40} more)"
        fail(
            "duplicate proof-obligation keys in registry (must be unique)\n"
            f"{preview}{more}"
        )
    return defs




def scan_tokens(txt: str) -> tuple[set[str], set[str], set[str], set[str]]:
    a = set(RE_A_TOK.findall(txt)) - EXCLUDE
    c = set(RE_C_TOK.findall(txt)) - EXCLUDE
    i = set(RE_I_TOK.findall(txt)) - EXCLUDE
    po = set(RE_PO_TOK.findall(txt)) - EXCLUDE
    return a, c, i, po


def main() -> None:
    root = repo_root()

    a_reg = root / "docs/10-threat-model/assumption-registry.md"
    c_reg = root / "docs/20-assurance/claim-registry.md"
    i_reg = root / "docs/20-assurance/invariant-registry.md"
    po_reg = root / "docs/20-assurance/proof-obligation-registry.md"

    for p in [a_reg, c_reg, i_reg, po_reg]:
        if not p.exists():
            fail(f"missing required registry: {p.as_posix()}")

    a_defs = load_defs(a_reg, "assumption", RE_A_DEF)
    c_defs = load_defs(c_reg, "claim", RE_C_DEF)
    i_defs = load_defs(i_reg, "invariant", RE_I_DEF)
    po_defs = load_po_defs(po_reg)

    used_a: set[str] = set()
    used_c: set[str] = set()
    used_i: set[str] = set()
    used_po: set[str] = set()

    offenders: dict[str, list[str]] = {}

    for p in iter_md_files(root):
        txt = read(p)
        a_toks, c_toks, i_toks, po_toks = scan_tokens(txt)
        if not (a_toks or c_toks or i_toks or po_toks):
            continue

        used_a |= a_toks
        used_c |= c_toks
        used_i |= i_toks
        used_po |= po_toks

        missing: list[str] = []
        if a_toks - a_defs:
            missing.extend(sorted(a_toks - a_defs))
        if c_toks - c_defs:
            missing.extend(sorted(c_toks - c_defs))
        if i_toks - i_defs:
            missing.extend(sorted(i_toks - i_defs))
        if po_toks - po_defs:
            missing.extend(sorted(po_toks - po_defs))

        if missing:
            offenders[p.relative_to(root).as_posix()] = missing

    if offenders:
        lines: list[str] = []
        for f in sorted(offenders.keys()):
            miss = offenders[f]
            lines.append(
                f"{f}: {', '.join(miss[:12])}{' …' if len(miss) > 12 else ''}"
            )
        preview = "\n".join(lines[:60])
        more = "" if len(lines) <= 60 else f"\n… (+{len(lines)-60} more files)"
        fail(
            "undefined assurance tokens referenced in repo markdown\n"
            f"{preview}{more}\n"
            "Fix: add the missing ID to the appropriate registry (assumptions/claims/invariants/POs), "
            "or correct the token in the doc."
        )

    ok(
        "assurance token closure: "
        f"A-*={len(used_a)} refs, C-*={len(used_c)} refs, I-*={len(used_i)} refs, PO-*={len(used_po)} refs; "
        "all resolve to registries"
    )


if __name__ == "__main__":
    main()
