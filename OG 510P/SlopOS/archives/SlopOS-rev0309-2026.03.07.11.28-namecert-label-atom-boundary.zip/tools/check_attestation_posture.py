#!/usr/bin/env python3
"""CI drift gate: pin D-ATTEST v0 posture (boot-bound, observational; killable export).

Why this exists
--------------
Remote attestation tends to drift in three bad ways:
- becomes an ambient channel ("it just works" export, or implicit network/time dependencies),
- pulls provider-specific parsing into privileged code,
- grows into a protocol spec without an RFC.

This guardrail keeps Phase-1 D-ATTEST small and reviewable:
- CH-ATTEST is a normalized payload-to-sign bound to CH-BOOT,
- export is policy-killable via cfg.params.lane.attest.export,
- freshness is explicit/optional (no ambient time by default),
- provider adaptation stays out of the privileged core.

Exit code:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]

DOC = ROOT / "docs/30-architecture/attestation-posture-v0.md"
EVID = "EVID-2026-228"

DISCOVERY_SURFACES = {
    ROOT / "docs/30-architecture/decision-map.md": ["attestation-posture-v0.md"],
    ROOT / "docs/README.md": ["30-architecture/attestation-posture-v0.md"],
    ROOT / "docs/30-architecture/posture-index.md": ["attestation-posture-v0.md"],
    ROOT / "docs/00-meta/profile-posture-matrix.md": ["attestation-posture-v0.md"],
    ROOT / "docs/30-architecture/config-toggle-registry.md": ["cfg.params.lane.attest.export"],
    ROOT / "docs/30-architecture/profile-lane-defaults.md": ["cfg.params.lane.attest.export"],
    ROOT / "docs/30-architecture/interface-registry.md": ["IF-ATTEST", "cfg.params.lane.attest.export"],
}


def fail(msg: str) -> None:
    print(f"[attest-posture] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[attest-posture] OK: {msg}")


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def main() -> None:
    if not DOC.exists():
        fail("missing docs/30-architecture/attestation-posture-v0.md")

    txt = read(DOC)

    # Attach to existing decision + assurance surfaces.
    required_tokens = [
        "D-ATTEST",
        "CH-ATTEST v0",
        "IF-ATTEST",
        "cfg.params.lane.attest.export",
        "I-ATTEST-1",
        "PO-ATTEST-VERIFY",
    ]
    for tok in required_tokens:
        if tok not in txt:
            fail(f"posture doc missing required anchor token: {tok}")

    # Keep scope honest.
    required_phrases = [
        "Observational",
        "Policy-killable export",
        "Boot binding",
        "Freshness is explicit",
        "provider",
        "MUST NOT",
    ]
    for ph in required_phrases:
        if ph not in txt:
            fail(f"posture doc missing required v0 scope phrase: {ph}")

    # Minimal research wiring.
    for ref in ["REF-RATS-RFC9334", "REF-EAT-RFC9711", "REF-TPM2-PART1"]:
        if ref not in txt:
            fail(f"posture doc must cite {ref}")

    # Discoverability wiring.
    missing = []
    for p, needles in DISCOVERY_SURFACES.items():
        if not p.exists():
            fail(f"missing discovery surface: {p}")
        ptxt = read(p)
        if not any(n in ptxt for n in needles):
            missing.append(str(p.relative_to(ROOT)))
    if missing:
        fail("posture doc not referenced from discovery surfaces: " + ", ".join(missing))

    evid_idx = ROOT / "docs/00-meta/evidence-index.md"
    if not evid_idx.exists():
        fail("missing docs/00-meta/evidence-index.md")
    if EVID not in read(evid_idx):
        fail(f"evidence-index does not register required evidence hook: {EVID}")

    ok(
        "D-ATTEST v0 posture is pinned and discoverable (boot-bound, observational CH-ATTEST; export killable by cfg.params.lane.attest.export; explicit freshness; provider parsing out of core)"
    )


if __name__ == "__main__":
    main()
