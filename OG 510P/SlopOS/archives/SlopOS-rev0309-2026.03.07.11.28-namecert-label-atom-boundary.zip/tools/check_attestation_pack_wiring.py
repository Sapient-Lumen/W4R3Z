#!/usr/bin/env python3
"""CI drift gate: keep the CH-ATTESTPACK bundle schema wired + bounded.

Why this exists
--------------
D-ATTEST v0 intentionally avoids committing to a full remote-attestation protocol.
However, *implementations still need an output artifact* that is:
- discoverable (so it doesn't drift into ad-hoc JSON blobs),
- bounded (so export surfaces don't silently become an exfil channel), and
- compatible with “no privileged provider parsing” (provider evidence stays opaque).

CH-ATTESTPACK v0 is that minimal packaging artifact.

Evidence: EVID-2026-229
"""

from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DOC = ROOT / "docs/30-architecture/attestation-pack-schema-v0.md"
EVID = "EVID-2026-229"

DISCOVERY_SURFACES = {
    ROOT / "docs/30-architecture/schema-registry.md": ["CH-ATTESTPACK v0", "attestation-pack-schema-v0.md"],
    ROOT / "docs/30-architecture/interface-registry.md": ["IF-ATTEST", "CH-ATTESTPACK"],
    ROOT / "docs/30-architecture/attestation-posture-v0.md": ["attestation-pack-schema-v0.md", "CH-ATTESTPACK"],
    ROOT / "docs/30-architecture/attestation-token-schema-v0.md": ["CH-ATTESTPACK"],
    ROOT / "docs/README.md": ["30-architecture/attestation-pack-schema-v0.md"],
}


def fail(msg: str) -> None:
    print(f"[attestpack] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[attestpack] OK: {msg}")


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def main() -> None:
    if not DOC.exists():
        fail("missing docs/30-architecture/attestation-pack-schema-v0.md")

    txt = read(DOC)

    # Anchor tokens: keep the pack tied to the core decision surfaces.
    for tok in [
        "CH-ATTESTPACK",
        "CH-ATTEST",
        "IF-ATTEST",
        "I-ENC-1",
        "Bounds (v0",
        "opaque",
    ]:
        if tok not in txt:
            fail(f"schema doc missing required anchor token/phrase: {tok}")

    # Ensure v0 bounds stay explicit (prevents silent exfil surface growth).
    for bound_phrase in [
        "attest_bytes",
        "≤ **4096**",
        "≤ **4**",
        "≤ **32768**",
        "≤ **8**",
    ]:
        if bound_phrase not in txt:
            fail(f"schema doc missing required v0 bound: {bound_phrase}")

    # Minimal reference anchors (primary sources; keep reviewable).
    for ref in [
        "REF-RATS-RFC9334",
        "REF-EAT-RFC9711",
        "REF-COSE-RFC9052",
        "REF-COSE-RFC9053",
    ]:
        if ref not in txt:
            fail(f"schema doc must cite {ref}")

    # Ensure discoverability.
    missing = []
    for p, needles in DISCOVERY_SURFACES.items():
        if not p.exists():
            fail(f"missing discovery surface: {p}")
        ptxt = read(p)
        if not any(n in ptxt for n in needles):
            missing.append(str(p.relative_to(ROOT)))
    if missing:
        fail("CH-ATTESTPACK doc not wired into discovery surfaces: " + ", ".join(missing))

    # Evidence hook must be registered.
    evid_idx = ROOT / "docs/00-meta/evidence-index.md"
    if not evid_idx.exists():
        fail("missing docs/00-meta/evidence-index.md")
    if EVID not in read(evid_idx):
        fail(f"evidence-index does not register required evidence hook: {EVID}")

    ok("CH-ATTESTPACK v0 is bounded, cited, and wired into schema + interface + docs discovery")


if __name__ == "__main__":
    main()
