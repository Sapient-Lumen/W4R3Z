#!/usr/bin/env python3
"""CI drift gate: pin D-CAPTURE v0 posture (manual-only; indicator-bound; non-persistent).

Why this exists
---------------
Capture is a classic authority-drift seam:
- static audio-server or device access turns into an ambient microphone/camera path,
- screen-share workflows grow restore tokens and remembered sessions before we decide whether we want persistence,
- headless “helper” processes quietly start or keep capture alive after the user-facing session ends,
- remote-desktop capture is mistaken for durable remote-control authority,
- and discovery surfaces stop saying whether the product actually claims any of that.

This guardrail keeps Phase 1 small and honest:
- no ambient capture constructors,
- manual-only portal workflow in v0,
- non-spoofable indicators as part of the contract,
- no restore-token / remembered-session / background-start claim,
- and no drift between the posture doc, schema notes, assurance text, and RFC history.
"""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOC = ROOT / 'docs/30-architecture/capture-portal-posture-v0.md'
EVID = 'EVID-2026-240'

DISCOVERY_SURFACES = {
    ROOT / 'docs/30-architecture/decision-map.md': ['capture-portal-posture-v0.md'],
    ROOT / 'docs/README.md': ['30-architecture/capture-portal-posture-v0.md'],
    ROOT / 'docs/30-architecture/posture-index.md': ['capture-portal-posture-v0.md'],
    ROOT / 'docs/30-architecture/portal-family-registry.md': ['capture-portal-posture-v0.md'],
    ROOT / 'docs/30-architecture/capture-session-schema-v0.md': ['capture-portal-posture-v0.md'],
    ROOT / 'docs/00-meta/profile-posture-matrix.md': ['30-architecture/capture-portal-posture-v0.md'],
    ROOT / 'docs/00-meta/resolved-history.md': ['capture-portal-posture-v0.md'],
    ROOT / 'rfcs/0095-media-capture-portals-and-session-descriptors.md': ['manual-only v0', 'no restore-token / remembered-session semantics'],
}


def fail(msg: str) -> None:
    print(f'[capture-posture] FAIL: {msg}')
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f'[capture-posture] OK: {msg}')


def read(p: Path) -> str:
    return p.read_text(encoding='utf-8')


def main() -> None:
    if not DOC.exists():
        fail('missing docs/30-architecture/capture-portal-posture-v0.md')

    doc_txt = read(DOC)
    for tok in [
        'D-CAPTURE',
        'D-UIAUT',
        'D-BGLEASE',
        'D-JOBS',
        'D-INHIBITLEASE',
        '`portal.capture`',
        'CH-CAPTURE',
        '`cfg.params.lane.portal.capture`',
        'Phase 1',
        'manual-only v0',
        'svc:portal.capture',
    ]:
        if tok not in doc_txt:
            fail(f'posture doc does not mention required anchor token: {tok}')

    for ph in [
        'No ambient capture constructors',
        'Manual-only v0; every start is interactive',
        'Indicator-bound live sessions',
        'Non-persistent in Phase 1',
        'No restore-token / remembered-session semantics',
    ]:
        if ph not in doc_txt:
            fail(f'posture doc missing required v0 scope phrase: {ph}')

    for ref in [
        'REF-XDG-PORTAL-SCREENCAST',
        'REF-XDG-PORTAL-REMOTEDESKTOP',
        'REF-XDG-PORTAL-CAMERA',
        'REF-ANDROID-MEDIAPROJECTION',
        'REF-APPLE-SCREENCAPTUREKIT',
        'REF-APPLE-CONTROL-CENTER-PRIVACY',
    ]:
        if ref not in doc_txt:
            fail(f'posture doc must cite {ref}')

    missing = []
    for p, needles in DISCOVERY_SURFACES.items():
        if not p.exists():
            fail(f'missing discovery surface: {p}')
        txt = read(p)
        if not any(n in txt for n in needles):
            missing.append(str(p.relative_to(ROOT)))
    if missing:
        fail('posture doc not referenced from discovery surfaces: ' + ', '.join(missing))

    portal = ROOT / 'docs/30-architecture/portal-family-registry.md'
    ptxt = read(portal)
    if 'manual-only v0' not in ptxt or 'indicator-bound' not in ptxt or 'no restore-token / remembered-session semantics in Phase 1' not in ptxt:
        fail('portal family registry must keep D-CAPTURE manual-only, indicator-bound, and non-persistent in v0')

    po = ROOT / 'docs/20-assurance/proof-obligation-registry.md'
    potxt = read(po)
    if 'PO-CAPTURE-ENF' not in potxt or 'manual-only v0' not in potxt or 'restore-token / remembered-session semantics' not in potxt:
        fail('PO-CAPTURE-ENF must keep manual-only / non-persistent capture semantics explicit')

    inv = ROOT / 'docs/20-assurance/invariant-registry.md'
    itxt = read(inv)
    if 'I-CAPTURE-1' not in itxt or 'portal-mediated grants' not in itxt:
        fail('I-CAPTURE-1 must keep no-ambient-capture explicit')
    if 'I-CAPTURE-3' not in itxt or 'manual-only v0' not in itxt or 'indicator' not in itxt:
        fail('I-CAPTURE-3 must keep the manual-only / indicator-bound / non-persistent rule explicit')

    evid_idx = ROOT / 'docs/00-meta/evidence-index.md'
    if EVID not in read(evid_idx):
        fail(f'evidence-index does not register required evidence hook: {EVID}')

    ok('D-CAPTURE v0 posture is pinned and discoverable (manual-only; indicator-bound; non-persistent)')


if __name__ == '__main__':
    main()
