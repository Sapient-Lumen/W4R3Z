#!/usr/bin/env python3
"""CI drift gate: pin D-CAPRPC promise posture v0 (session-local one-shot promises; capability-result pipelining only)."""
from __future__ import annotations
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOC = ROOT / 'docs/30-architecture/caprpc-promise-posture-v0.md'
EVID = 'EVID-2026-299'
DISCOVERY_SURFACES = {
    ROOT / 'README.md': ['caprpc-promise-posture-v0.md'],
    ROOT / 'docs/README.md': ['30-architecture/caprpc-promise-posture-v0.md'],
    ROOT / 'docs/30-architecture/posture-index.md': ['caprpc-promise-posture-v0.md'],
    ROOT / 'docs/00-meta/profile-posture-matrix.md': ['30-architecture/caprpc-promise-posture-v0.md'],
    ROOT / 'docs/00-meta/resolved-history.md': ['caprpc-promise-posture-v0.md'],
    ROOT / 'docs/00-meta/llm-runbook.md': ['docs/30-architecture/caprpc-promise-posture-v0.md'],
    ROOT / 'docs/30-architecture/decision-map.md': ['caprpc-promise-posture-v0.md', 'caller-local, session-scoped, and one-shot'],
    ROOT / 'docs/30-architecture/mechanisms.md': ['caprpc-promise-posture-v0.md', 'capability-result-only for pipelining'],
    ROOT / 'rfcs/0026-object-capability-rpc-profile.md': ['caprpc-promise-posture-v0.md', 'caller-local, session-scoped, one-shot promise handles'],
    ROOT / 'docs/30-architecture/capability-rpc-frame-schema-v0.md': ['caprpc-promise-posture-v0.md'],
    ROOT / 'docs/30-architecture/capability-rpc-frame-schema-v1.md': ['caprpc-promise-posture-v0.md'],
}

def fail(msg: str) -> None:
    print(f'[caprpc-promise-posture] FAIL: {msg}')
    raise SystemExit(1)

def ok(msg: str) -> None:
    print(f'[caprpc-promise-posture] OK: {msg}')

def read(p: Path) -> str:
    return p.read_text(encoding='utf-8')

def main() -> None:
    if not DOC.exists():
        fail('missing docs/30-architecture/caprpc-promise-posture-v0.md')
    doc_txt = read(DOC)
    for tok in ['D-CAPRPC', 'D-TURNS', 'D-REQCTX', 'D-COMMUTE', 'D-CAPX', 'I-CAPRPC-1', 'I-CAPRPC-3', 'PO-CAPRPC-FRAME', 'PO-CAPRPC-PIPELINE', 'AC-064', 'Phase 1']:
        if tok not in doc_txt:
            fail(f'posture doc does not mention required anchor token: {tok}')
    for ph in [
        'Promise/result handles stay caller-local, session-scoped, and one-shot',
        'Pipelining is allowed only toward unresolved capability results, not arbitrary data promises',
        'Dependent sends preserve sender identity, `iface_digest` checks, and explicit attachment bounds',
        'Cancellation and disconnect break dependent promises deterministically; no silent completion',
        'No public promise catalog, list/watch, or cross-session restore/export surface',
        'No portable join/race/fork combinator surface on D-CAPRPC',
        'No hidden inbox pumping; D-TURNS remains the default composition story',
        'External action semantics stay on existing conflict keys and ordering witnesses',
        'No new workflow / ACP / admin surface on D-CAPRPC promises',
        'Sealed compat remains killable and non-ambient',
    ]:
        if ph not in doc_txt:
            fail(f'posture doc missing required v0 scope phrase: {ph}')
    for ref in ['REF-CAPNP-RPC', 'REF-CAPNP-CXXRPC', 'REF-E-REFMECH', 'REF-TC39-EVENTUALSEND']:
        if ref not in doc_txt:
            fail(f'posture doc must cite {ref}')
    missing=[]
    for p, needles in DISCOVERY_SURFACES.items():
        if not p.exists():
            fail(f'missing discovery surface: {p}')
        txt = read(p)
        if not any(n in txt for n in needles):
            missing.append(str(p.relative_to(ROOT)))
    if missing:
        fail('posture doc not referenced from discovery surfaces: ' + ', '.join(missing))
    if EVID not in read(ROOT / 'docs/00-meta/evidence-index.md'):
        fail(f'evidence-index does not register required evidence hook: {EVID}')
    bib = read(ROOT / 'docs/00-meta/bibliography.md')
    for ref in ['REF-CAPNP-CXXRPC', 'REF-E-REFMECH']:
        if ref not in bib:
            fail(f'bibliography must register {ref}')
    ok('D-CAPRPC promise posture is pinned and discoverable (caller-local/session-scoped one-shot promise handles, capability-result-only pipelining, deterministic broken-promise/disconnect outcomes, no inventory/combinator/admin surface)')

if __name__ == '__main__':
    main()
