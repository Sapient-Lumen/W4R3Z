#!/usr/bin/env python3
"""Drift gate for the caprpc_proxy replication boundary (narrowing OQ-0001)."""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BOUNDARY = ROOT / "docs/30-architecture/caprpc-proxy-replication-boundary-v0.md"
DOCS_README = ROOT / "docs/README.md"
RUNBOOK = ROOT / "docs/00-meta/llm-runbook.md"
REPL = ROOT / "docs/30-architecture/replication-contracts-v0.md"
REGISTRY = ROOT / "docs/30-architecture/replication-object-family-registry.md"
DEFAULTS = ROOT / "docs/30-architecture/profile-repl-defaults.md"
CAPRPC = ROOT / "docs/30-architecture/capability-rpc-frame-schema-v0.md"
CAPX = ROOT / "docs/30-architecture/capability-export-schema-v0.md"
RFC26 = ROOT / "rfcs/0026-object-capability-rpc-profile.md"
RFC4 = ROOT / "rfcs/0004-networked-capabilities-and-delegation-tokens.md"
DECISION = ROOT / "docs/30-architecture/decision-map.md"
TRAJ = ROOT / "docs/00-meta/trajectory-map.md"
EVID = ROOT / "docs/00-meta/evidence-index.md"
TOOLS = ROOT / "tools/README.md"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def die(msg: str) -> None:
    print(f"ERROR: {msg}", file=sys.stderr)
    raise SystemExit(1)


def require(text: str, needle: str, label: str) -> None:
    if needle not in text:
        die(f"{label} missing required text: {needle}")


def main() -> int:
    boundary = read(BOUNDARY)
    for needle in (
        'narrow **OQ-0001**',
        'owner-routed endpoint/proxy metadata only',
        'create a new callable local handle/proxy',
        'copy connection-scoped capability/object ids, promised-answer paths, or reply routing state',
        'explicit CH-CAPX / CH-SREF restore/import seam',
        'live capability/proxy handoff on an authenticated connection',
        'REF-CAPNP-RPC',
        'REF-CAPTP',
        'REF-ROBUST-COMPOSITION',
    ):
        require(boundary, needle, BOUNDARY.name)

    require(read(DOCS_README), 'caprpc-proxy-replication-boundary-v0.md', DOCS_README.name)
    require(read(RUNBOOK), 'caprpc-proxy-replication-boundary-v0.md', RUNBOOK.name)
    for path in (REPL, REGISTRY, DEFAULTS, CAPRPC, CAPX, RFC26, RFC4, DECISION):
        require(read(path), 'caprpc-proxy-replication-boundary-v0.md', path.name)

    traj = read(TRAJ)
    require(traj, '**OQ-0001 Hybrid follow-ups (ADR-0005)**', TRAJ.name)
    require(traj, 'caprpc-proxy-replication-boundary-v0.md', TRAJ.name)

    evid = read(EVID)
    require(evid, 'EVID-2026-261', EVID.name)
    require(evid, 'tools/check_caprpc_proxy_replication_boundary.py', EVID.name)
    require(read(TOOLS), 'check_caprpc_proxy_replication_boundary.py', TOOLS.name)

    print('[caprpc-proxy-repl-boundary] OK: caprpc_proxy RC1 replication stays owner-routed metadata only; callable authority remains explicit local handle/import/restore state')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
