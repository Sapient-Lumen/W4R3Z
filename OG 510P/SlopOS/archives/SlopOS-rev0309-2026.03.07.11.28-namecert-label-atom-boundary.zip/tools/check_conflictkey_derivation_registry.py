#!/usr/bin/env python3
"""CI guardrail: keep conflict-key derivation + ordering-token family vocabulary drift-resistant.

Source of truth:
- docs/30-architecture/conflict-key-family-registry.md (closed family tokens)
- docs/30-architecture/conflict-key-derivation-registry.md (tuple→digest derivation commitments)

Checks (fail closed):
- conflict-key-derivation-registry.md exists and is linked from docs/README.md.
- conflict-key-schema-v0.md references the derivation registry and includes ck_id commitments
  for the digest-valued `*_key` payload fields used on pinned surfaces.
- hot-action-boundaries-v0.md references the derivation registry where it describes
  CH-ORDERTOK scope/key semantics.
- ordering-token-schema-v0.md treats scope.family as using the closed CH-CONFLICTKEY family vocabulary
  (references conflict-key-family-registry.md).
- Any explicit prose of the form `CH-ORDERTOK v0 (family `X`)` across docs/ uses an X that
  exists in the conflict-key-family allowlist.

Rationale:
- D-COMMUTE + Hybrid depend on stable conflict-key and ordering stream scoping.
- LLM edits often introduce subtle vocabulary drift (shadow families / unstated tuple encodings).

Design constraints: tiny, dependency-free, deterministic.
"""

from __future__ import annotations

import re
import sys
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Problem:
    path: str
    detail: str


ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / "docs"
DOCS_README = DOCS / "README.md"
FAM_REG = DOCS / "30-architecture/conflict-key-family-registry.md"
DERIVE_REG = DOCS / "30-architecture/conflict-key-derivation-registry.md"
CK_SCHEMA = DOCS / "30-architecture/conflict-key-schema-v0.md"
HOT_BOUND = DOCS / "30-architecture/hot-action-boundaries-v0.md"
ORDERTOK = DOCS / "30-architecture/ordering-token-schema-v0.md"

RE_BT = re.compile(r"`([^`]+)`")
RE_ORD_FAM = re.compile(r"CH-ORDERTOK v0 \(family `([^`]+)`\)")


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def parse_registry_families(md: str) -> list[str]:
    """Parse the conflict-key family table (| family | ...)."""
    lines = md.splitlines()
    fams: list[str] = []
    in_table = False
    for ln in lines:
        s = ln.strip()
        if not in_table:
            if s.lower().startswith("| family |"):
                in_table = True
            continue
        if s.startswith("|---"):
            continue
        if not s.startswith("|"):
            break
        cols = [c.strip() for c in s.strip("|").split("|")]
        if not cols:
            continue
        m = RE_BT.search(cols[0])
        if not m:
            continue
        fam = m.group(1).strip()
        if fam:
            fams.append(fam)
    return fams


def parse_derivation_families(md: str) -> set[str]:
    """Parse the derivation table (| CH-CONFLICTKEY family | ...)."""
    lines = md.splitlines()
    fams: set[str] = set()
    in_table = False
    for ln in lines:
        s = ln.strip()
        if not in_table:
            if s.lower().startswith("| ch-conflictkey family |"):
                in_table = True
            continue
        if s.startswith("|---"):
            continue
        if not s.startswith("|"):
            break
        cols = [c.strip() for c in s.strip("|").split("|")]
        if not cols:
            continue
        m = RE_BT.search(cols[0])
        if not m:
            continue
        fam = m.group(1).strip()
        if fam:
            fams.add(fam)
    return fams


def main() -> int:
    req = [DOCS_README, FAM_REG, DERIVE_REG, CK_SCHEMA, HOT_BOUND, ORDERTOK]
    missing = [p for p in req if not p.exists()]
    if missing:
        for p in missing:
            print(f"ERROR: missing required file: {p}")
        return 2

    problems: list[Problem] = []

    fams = parse_registry_families(read(FAM_REG))
    if not fams:
        problems.append(Problem(str(FAM_REG.relative_to(ROOT)), "failed to parse any family tokens from registry table"))
        fam_set: set[str] = set()
    else:
        fam_set = set(fams)

    # Derivation registry wiring + coverage
    if "conflict-key-derivation-registry.md" not in read(DOCS_README):
        problems.append(Problem(str(DOCS_README.relative_to(ROOT)), "docs/README.md must link conflict-key-derivation-registry.md"))

    d_txt = read(DERIVE_REG)
    if "ck_id(" not in d_txt:
        problems.append(Problem(str(DERIVE_REG.relative_to(ROOT)), "derivation registry must define ck_id(..) helper"))

    d_fams = parse_derivation_families(d_txt)
    need = {"mem.range", "ipc.endpoint", "view.slot", "log.eventset", "budget.issuer", "budget.lease", "domain.id", "policy.param"}
    missing_rows = sorted([x for x in need if x not in d_fams])
    if missing_rows:
        problems.append(Problem(str(DERIVE_REG.relative_to(ROOT)), "derivation table missing required family row(s): " + ", ".join(missing_rows)))

    # Schema wiring
    ck_txt = read(CK_SCHEMA)
    if "conflict-key-derivation-registry.md" not in ck_txt:
        problems.append(Problem(str(CK_SCHEMA.relative_to(ROOT)), "CH-CONFLICTKEY schema must reference conflict-key-derivation-registry.md"))

    # Require ck_id commitments for key-digest fields (simple anchor check)
    for fam, needle in [
        ("mem.range", 'ck_id("mem.as"'),
        ("ipc.endpoint", 'ck_id("ipc.endpoint"'),
        ("view.slot", 'ck_id("view.id"'),
        ("log.eventset", 'ck_id("log.eventset"'),
        ("budget.issuer", 'ck_id("budget.issuer"'),
        ("budget.lease", 'ck_id("budget.lease"'),
    ]:
        if needle not in ck_txt:
            problems.append(Problem(str(CK_SCHEMA.relative_to(ROOT)), f"missing ck_id derivation commitment anchor for family {fam} (expected to find {needle})"))

    # Hot-action boundaries should mention derivation registry where it describes ordertok scoping.
    hb_txt = read(HOT_BOUND)
    if "conflict-key-derivation-registry.md" not in hb_txt:
        problems.append(Problem(str(HOT_BOUND.relative_to(ROOT)), "hot-action-boundaries-v0.md must reference conflict-key-derivation-registry.md"))

    # Ordering-token schema must reference the conflict-key family allowlist (no shadow allowlists).
    ot_txt = read(ORDERTOK)
    if "conflict-key-family-registry.md" not in ot_txt:
        problems.append(Problem(str(ORDERTOK.relative_to(ROOT)), "ordering-token-schema-v0.md must reference conflict-key-family-registry.md as canonical family allowlist"))

    # Vocabulary closure across docs: CH-ORDERTOK v0 (family `...`) references
    if fam_set:
        for p in sorted(DOCS.rglob("*.md")):
            body = read(p)
            for m in RE_ORD_FAM.finditer(body):
                fam = m.group(1).strip()
                if fam not in fam_set:
                    problems.append(Problem(str(p.relative_to(ROOT)), f"references unknown CH-ORDERTOK family token: {fam}"))

    if problems:
        print("Conflict-key derivation / ordertok family drift detected:\n")
        for pr in problems:
            print(f"- {pr.path}: {pr.detail}")
        print("\nFix: keep derivation commitments + family vocabularies closed and wired.")
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
