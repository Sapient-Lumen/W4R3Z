#!/usr/bin/env python3
"""CI guardrail: keep CH-CONFLICTKEY family names closed + coherently wired.

Source of truth:
- docs/30-architecture/conflict-key-family-registry.md

Checks (fail closed):
- Registry table parses and defines a non-empty closed set of family tokens.
- conflict-key-schema-v0.md defines the same family set in its numbered payload section.
- conflict-key-schema-v0.md references the registry as the canonical allowlist.
- docs/README.md links the registry (discovery surface).
- Any explicit `family="..."` (or `family=`...``) reference across docs/ must use a family present in the registry.

Rationale:
- D-COMMUTE + Hybrid rely on conflict keys as a stable, reviewable artifact surface.
- LLM edits are prone to introducing typo'd family strings that silently break
  validators/evidence harnesses. This gate keeps the family vocabulary closed.

Design constraints: tiny, dependency-free, deterministic.
"""

from __future__ import annotations

import re
import sys
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Problem:
    path: str
    detail: str


ROOT = Path(__file__).resolve().parents[1]
REG = ROOT / "docs/30-architecture/conflict-key-family-registry.md"
SCHEMA = ROOT / "docs/30-architecture/conflict-key-schema-v0.md"
DOCS_README = ROOT / "docs/README.md"

RE_BT = re.compile(r"`([^`]+)`")
RE_FAMILY_Q = re.compile(r'family="([a-z0-9_.\-]+)"')
RE_FAMILY_BT = re.compile(r"family=`([a-z0-9_.\-]+)`")


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def strip_code_fences(md: str) -> str:
    """Remove fenced code blocks (```...```) to reduce false positives."""
    out: list[str] = []
    in_fence = False
    for ln in md.splitlines():
        s = ln.strip()
        if s.startswith("```"):
            in_fence = not in_fence
            continue
        if not in_fence:
            out.append(ln)
    return "\n".join(out)


def parse_registry_families(md: str) -> list[str]:
    lines = md.splitlines()
    fams: list[str] = []
    in_table = False
    for i, ln in enumerate(lines):
        s = ln.strip()
        if not in_table:
            if s.lower().startswith("| family |"):
                # Expect a separator on next line.
                in_table = True
            continue
        # after header; skip separator row
        if s.startswith("|---"):
            continue
        if not s.startswith("|"):
            break
        cols = [c.strip() for c in s.strip("|").split("|")]
        if not cols:
            continue
        m = RE_BT.search(cols[0])
        if not m:
            continue
        fam = m.group(1).strip()
        if fam:
            fams.append(fam)
    return fams


def parse_schema_families(md: str) -> set[str]:
    body = strip_code_fences(md)
    start = body.find("### Family payloads")
    if start < 0:
        raise ValueError("missing '### Family payloads' section")
    end = body.find("## Validation rules", start)
    if end < 0:
        end = len(body)
    block = body[start:end]
    fams = set(re.findall(r"^\s*\d+\)\s+`([^`]+)`\s*$", block, flags=re.M))
    if not fams:
        raise ValueError("could not extract family list from schema (expected lines like '1) `mem.range`')")
    return fams


def main() -> int:
    missing = [p for p in [REG, SCHEMA, DOCS_README] if not p.exists()]
    if missing:
        for p in missing:
            print(f"ERROR: missing required file: {p}")
        return 2

    problems: list[Problem] = []

    reg_txt = read(REG)
    reg_fams = parse_registry_families(reg_txt)
    if not reg_fams:
        problems.append(Problem(str(REG.relative_to(ROOT)), "failed to parse any families from registry table"))
        reg_set: set[str] = set()
    else:
        reg_set = set(reg_fams)
        if len(reg_set) != len(reg_fams):
            dups = sorted([f for f in reg_set if reg_fams.count(f) > 1])
            problems.append(Problem(str(REG.relative_to(ROOT)), "duplicate family token(s) in registry: " + ", ".join(dups)))

    schema_txt = read(SCHEMA)
    if "conflict-key-family-registry.md" not in schema_txt:
        problems.append(Problem(str(SCHEMA.relative_to(ROOT)), "schema must reference conflict-key-family-registry.md as canonical allowlist"))

    try:
        schema_set = parse_schema_families(schema_txt)
    except ValueError as e:
        problems.append(Problem(str(SCHEMA.relative_to(ROOT)), str(e)))
        schema_set = set()

    # Registry <-> schema closure (both are stable diff surfaces)
    if reg_set and schema_set:
        extra = sorted(schema_set - reg_set)
        missing = sorted(reg_set - schema_set)
        if extra:
            problems.append(Problem(str(SCHEMA.relative_to(ROOT)), "schema defines families not present in registry: " + ", ".join(extra)))
        if missing:
            problems.append(Problem(str(REG.relative_to(ROOT)), "registry lists families missing from schema payload section: " + ", ".join(missing)))

    # Discovery wiring
    if "conflict-key-family-registry.md" not in read(DOCS_README):
        problems.append(Problem(str(DOCS_README.relative_to(ROOT)), "docs/README.md must link conflict-key-family-registry.md"))

    # Reference closure across docs
    if reg_set:
        docs_root = ROOT / "docs"
        for p in sorted(docs_root.rglob("*.md")):
            # skip registry itself; schema checked separately
            if p == REG:
                continue
            body = strip_code_fences(read(p))
            refs = set(RE_FAMILY_Q.findall(body)) | set(RE_FAMILY_BT.findall(body))
            unknown = sorted([r for r in refs if r not in reg_set])
            if unknown:
                problems.append(Problem(str(p.relative_to(ROOT)), "references unknown CH-CONFLICTKEY family token(s): " + ", ".join(unknown)))

    if problems:
        print("Conflict-key family registry drift detected:\n")
        for pr in problems:
            print(f"- {pr.path}: {pr.detail}")
        print("\nFix: keep the family allowlist closed and consistent (registry ↔ schema ↔ references).")
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
