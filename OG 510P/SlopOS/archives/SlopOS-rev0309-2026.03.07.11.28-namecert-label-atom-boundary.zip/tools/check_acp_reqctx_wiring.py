#!/usr/bin/env python3
"""CI guardrail: keep ACP request-context (CH-REQCTX v1) wiring coherent.

Rationale:
- No ambient authority: request contexts must remain non-authoritative (veto-only).
- Schemas/receipts are the product surface: CH-ACP, CH-LOG, and CH-ACPOUT must
  consistently carry a digest-only reqctx hook so audits/replay tooling don't
  drift into ad-hoc correlation fields.

This check is intentionally conservative and fail-closed.
"""

from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def fail(msg: str) -> int:
    print(f"[acp-reqctx] FAIL: {msg}")
    return 1


def ok(msg: str) -> None:
    print(f"[acp-reqctx] OK: {msg}")


def main() -> int:
    acp_schema = ROOT / "docs/70-llm-control/acp-action-schema-v0.md"
    acp_sem = ROOT / "docs/70-llm-control/acp-validator-semantics.md"
    acp_out = ROOT / "docs/30-architecture/acp-outcome-receipt-schema-v0.md"
    log_contract = ROOT / "docs/30-architecture/transcript-contract.md"
    reqctx = ROOT / "docs/30-architecture/request-context-schema-v1.md"
    schemareg = ROOT / "docs/30-architecture/schema-registry.md"
    docs_readme = ROOT / "docs/README.md"
    inv_reg = ROOT / "docs/20-assurance/invariant-registry.md"
    po_reg = ROOT / "docs/20-assurance/proof-obligation-registry.md"
    evid = ROOT / "docs/00-meta/evidence-index.md"

    for p in (acp_schema, acp_sem, acp_out, log_contract, reqctx, schemareg, docs_readme, inv_reg, po_reg, evid):
        if not p.exists():
            return fail(f"missing required file: {p.relative_to(ROOT)}")

    # 1) CH-ACP requires reqctx_digest.
    s = read(acp_schema)
    must = ["reqctx_digest", "CH-REQCTX v1", "meta.reqctx_digest"]
    missing = [m for m in must if m not in s]
    if missing:
        return fail(f"acp-action-schema-v0.md missing required reqctx anchor(s): {', '.join(missing)}")
    ok("CH-ACP schema references meta.reqctx_digest = digest(CH-REQCTX v1)")

    # 2) Validator semantics mention requirement and non-authoritative rule.
    sem = read(acp_sem)
    must = ["reqctx_digest", "CH-REQCTX v1", "veto-only"]
    missing = [m for m in must if m not in sem]
    if missing:
        return fail(f"acp-validator-semantics.md missing reqctx requirement anchor(s): {', '.join(missing)}")
    ok("ACP validator semantics include reqctx validation + veto-only rule")

    # 3) CH-LOG contract carries reqctx_digest.
    lc = read(log_contract)
    must = ["reqctx_digest", "CH-REQCTX v1", "non-authoritative"]
    missing = [m for m in must if m not in lc]
    if missing:
        return fail(f"transcript-contract.md missing reqctx/log anchor(s): {', '.join(missing)}")
    ok("CH-LOG contract includes reqctx_digest and non-authoritative note")

    # 4) CH-ACPOUT echoes reqctx_digest.
    out = read(acp_out)
    must = ["reqctx_digest", "digest(CH-REQCTX v1)"]
    missing = [m for m in must if m not in out]
    if missing:
        return fail(f"acp-outcome receipt schema missing reqctx anchor(s): {', '.join(missing)}")
    ok("CH-ACPOUT includes reqctx_digest")

    # 5) Discoverability/wiring: docs/README and schema registry.
    dr = read(docs_readme)
    if "request-context-schema-v1.md" not in dr and "CH-REQCTX" not in dr:
        return fail("docs/README.md does not reference request-context-schema-v1.md / CH-REQCTX")
    ok("docs/README.md references CH-REQCTX")

    reg = read(schemareg)
    if "| CH-REQCTX v1 |" not in reg:
        return fail("schema-registry.md missing CH-REQCTX v1 row")
    if "(request-context-schema-v1.md)" not in reg.replace("./", ""):
        return fail("schema-registry.md CH-REQCTX v1 row must link to request-context-schema-v1.md")
    if "IF-ACP" not in reg.split("| CH-REQCTX v1 |")[1].splitlines()[0]:
        return fail("schema-registry.md CH-REQCTX v1 'Where used' column should mention IF-ACP")
    ok("schema-registry.md includes CH-REQCTX v1 link and IF-ACP usage")

    # 6) Assurance wiring.
    if "I-ACP-REQCTX-1" not in read(inv_reg):
        return fail("invariant-registry.md missing I-ACP-REQCTX-1")
    po = read(po_reg)
    if "PO-ACT-REQCTX" not in po:
        return fail("proof-obligation-registry.md missing PO-ACT-REQCTX")
    if "PO-REQCTX-VALIDATE" not in po:
        return fail("proof-obligation-registry.md missing PO-REQCTX-VALIDATE reference (required by PO-ACT-REQCTX)")
    ok("Assurance wiring present (I-ACP-REQCTX-1, PO-ACT-REQCTX)")

    # 7) Evidence registry.
    e = read(evid)
    if "EVID-2026-147" not in e or "tools/check_acp_reqctx_wiring.py" not in e:
        return fail("evidence-index.md missing EVID-2026-147 entry pointing at this tool")
    ok("Evidence index includes EVID-2026-147")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
