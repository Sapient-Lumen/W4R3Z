# RFC-0082: Witnessed checkpoints and split-view resistance for transparency logs (D-WITNESS)

Status: Draft  
Updated: 2026-02-25  
Decision node(s): **D-WITNESS**, D-TLOG, D-PCP, D-ATOMICUPD, D-TUF

## Summary
Transparency logs (D-TLOG) improve *auditability* and *tamper evidence*, but a standalone log can still attempt **equivocation** (a “split view” where different victims see different log histories) or collude with a compromised publisher to hide targeted releases.

This RFC introduces **D-WITNESS**: an optional, **out-of-band** ecosystem seam where independently operated **witnesses** cosign (or otherwise attest to) transparency-log checkpoints so that:

- a log cannot convincingly present two different histories without being detected,
- clients/auditors can require **threshold witnessing** for high-assurance channels,
- and “binary transparency” becomes a practical, repeatable release discipline.

D-WITNESS remains entirely in user space and release engineering; the kernel does not parse witness artifacts.

## Motivation
D-TLOG provides append-only anchoring: “this digest was present in the log at this checkpoint.”
However, classic CT-style logs can still:

- attempt **split views** (show different trees/checkpoints to different auditors),
- or delay/pin visibility of a targeted release until after impact.

Witness cosigning and multi-party monitoring raise the cost of these attacks and bring *key-usage transparency* and *binary transparency* closer to “default hygiene” (not a bespoke incident response play).

Modern tlog ecosystems explicitly move toward witnessed checkpoints (e.g., Sigsum witness thresholding; tile-based log + witness stacks).

## Design

### D-WITNESS posture
- **Optional** and profile-gated: dev/test profiles may not require witnesses.
- **Out-of-band evidence**: used by release pipelines, auditors, and fleet monitors.
- **No kernel dependency**: witnessing affects whether a release is considered *audit-complete*, not whether it can boot.

### Threats addressed
D-WITNESS focuses on **equivocation/split view** and **targeted invisibility**.
It does not replace:
- artifact signing (D-UPD-SIGN),
- TUF freshness/consistency (D-TUF),
- or reproducibility/provenance gates (D-PCP).

### Checkpoint witnessing model (minimal)
We define a minimal checkpoint object (conceptual):
- `log_id`
- `tree_size`
- `root_hash`
- `issued_at` (bounded by I-TIME-1 where relevant)

A witness produces a **signature** over the tuple above.
A “witnessed checkpoint” consists of:
- the log’s signed checkpoint (as in RFC-0029), plus
- **M-of-N witness signatures** that match the same `(log_id, tree_size, root_hash, issued_at)`.

Witness policy is a profile/release choice:
- pin a witness set and threshold in tooling configuration,
- optionally bind it into a release manifest/policy digest so it is reviewable and drift-detectable.

### Where witness material lives
We do **not** require a new schema family.
Instead:
- CH-TLOG v0 MAY include an optional `witness_bundle_digest` (CH-AREF to a small witness-sigs bundle) or inline witness signature objects if we keep them bounded.
- Release bundles SHOULD include the witness bundle as a referenced artifact so third parties can verify without contacting witnesses.

### Monitoring / gossip (operator playbook)
A D-WITNESS deployment SHOULD run:
- at least one **monitor** that polls the log, validates consistency, and alerts on regression,
- plus at least one **witness** operated by an independent admin domain,
- and (optionally) a second log (multi-log anchoring) for high-value channels.

We keep this as an operational posture, not a privileged requirement.

## Invariants / proof obligations
- **I-TLOG-2 (Split-view resistance, optional)**: if D-WITNESS is enabled for a release channel, any CH-TLOG anchor claiming “audit-complete” MUST include threshold witness signatures (or a digest-bound witness bundle) matching the log checkpoint.
- **PO-TLOG-WITNESS**: verifiers validate (a) the log checkpoint signature, (b) witness signatures against a pinned witness set and threshold, and (c) that all signatures bind the same checkpoint tuple.

## Evidence plan
- **EVID-2026-080**: build a small verifier + negative tests:
  - mismatched witness signature (wrong root hash) must fail,
  - insufficient witness threshold must fail,
  - replayed/stale witness bundle must be detectable when used as an “audit-complete” predicate.

## Threat-model impact (abuse cases)
- **AC-070 (split-view transparency log attack / targeted invisibility)**: attacker attempts to present different checkpoint histories to different victims or hide a targeted release from auditors.
  - mitigations: D-WITNESS threshold checkpoints, independent monitors, optional multi-log anchoring.

## Alternatives
- **No witnesses**: simplest; still useful, but weaker against equivocation.
- **Rely only on monitors**: monitors detect some attacks, but without witness signatures victims may not share a common checkpoint.
- **Hard-wire witnessing into boot**: rejected; keeps kernel policy-free and avoids availability coupling to external infra.

## References
REF-CT-RFC6962, REF-TLOG-SWTCH, REF-TESSERA, REF-TRANSPARENCY-WITNESS, REF-ARMORED-WITNESS, REF-SIGSUM, REF-GO-SUMDB-DESIGN.
