# RFC-0098: Recovery mode + rescue environment (D-RECOVERY)

Status: Draft

Decision node(s): D-RECOVERY, D-ATOMICUPD (adjunct), D-HEALTH (adjunct), D-SUPV (adjunct), D-BOOT

## Summary
Add an explicit **recovery boot path** that is:
- **independent** of the normal user-space stack,
- **minimal and sealed** by default,
- **mechanically auditable** (same digest/provenance universe as the main system), and
- practical for both users and operators.

We treat recovery as a *deployment/profile feature*, not a kernel subsystem.

## Motivation
Every real OS needs a way to recover when the “main” environment is broken:
- bad updates, misconfigured policy, early-boot crashes,
- driver/domain faults that prevent reaching a usable UI,
- storage corruption, and
- “can’t type the password because the stack that provides input is broken.”

If recovery is bolted on late, it tends to be:
- ad-hoc (scripts, mutable state, hidden heuristics),
- under-tested,
- not provenance-bound,
- or dependent on exactly the parts that fail.

A greenfield, evidence-driven OS should bake in a **small, testable** recovery posture.

## Goals
- A **known-good recovery environment** that can boot even when normal services cannot.
- A **physical-presence** entry path (boot menu / dedicated button / secure attention), avoiding “software can spoof recovery.”
- Recovery environment is **digest-addressed**, signed, and can be measured like normal deployments.
- Recovery does **not** silently widen authority: any high-risk actions remain explicit, portal-mediated, and transcript-visible.

## Non-goals
- A fully general “repair everything automatically” system.
- In-kernel repair logic.
- Making recovery available remotely by default.

## Design
### 1) Recovery is a dedicated deployment root
Recovery is represented as a **deployment root digest** (same digest namespace as D-ATOMICUPD roots).

Conventions:
- CH-UPD and CH-BOOT may include an `artifacts[]` entry with role `recovery_root` whose `digest` is the recovery deployment root digest.
- Installers/updaters should keep a **reserved slot** (partition/volume) for the recovery root so it stays bootable even if the active root is corrupt.

This keeps recovery fully in the “policy/data + verified artifacts” universe.

### 2) Entry paths
Recovery entry is profile-defined, but should include at least one **physical presence** path:
- firmware/bootloader menu entry,
- OEM “recovery button,”
- or a secure attention gesture path into a minimal pre-UI recovery selector.

Software-only entry paths are allowed only if they remain fail-closed and cannot be spoofed by untrusted code.

### 3) What the recovery environment can do
Recovery is intended to provide a bounded set of workflows:

**Core workflows (recommended):**
- **Rollback/select deployment**: view current CH-BOOTSEL state, choose to boot LKG, or select a known installed deployment (if policy allows).
- **Configuration reset (scoped)**: reset selected CH-CFG facets to defaults (or a last-known-good config), using explicit actions logged to CH-LOG.
- **Diagnostics export (scoped)**: collect a sanitized snapshot bundle (CH-SNAPSHOT) under CH-OBSPOL’s sanitized tier.

**Optional workflows (profile extensions):**
- Offline storage checks / repair tooling.
- Network update fetch **only via explicit lease** (D-NETLEASE) and only if the profile accepts that risk.
- “Factory reset” / wipe workflows gated behind strong consent + physical presence.

### 4) Interaction with atomic updates and boot-success
If D-ATOMICUPD and D-HEALTH are enabled:
- recovery is a separate boot target and is **never** considered “boot success” for the main deployment.
- recovery may offer an explicit “attempt trial boot of X” operation that sets CH-BOOTSEL `pending` to X with a bounded `tries_remaining`.

This avoids importing policy into IF-BOOT while still giving an operator a deterministic trial/rollback loop.

### 5) Security posture
- Recovery should boot into a **sealed** state quickly (D-SEAL discipline): no ambient networking, no ambient storage traversal, no ambient device attach.
- Any privileged changes (rollback selection, config reset, wipe) must be expressed as explicit privileged actions (CH-KABI/CH-ACP) and become transcript-visible (CH-LOG).
- Recovery must not become a “hidden admin shell”: high-risk capabilities are not granted implicitly; recovery tools are trusted components in a distinct deployment.

## Assurance hooks
- **Invariant (new): I-RECOVERY-1 (Recovery is provenance-bound, optional)**: if D-RECOVERY is enabled, the recovery environment is identified by a deployment root digest that is signed/verified under the same update policy as other trusted deployments.
- **Proof obligation (new): PO-RECOVERY-ENTRY**: entry path(s) to recovery are fail-closed and require declared physical presence.
- **Proof obligation (new): PO-RECOVERY-NOAMP**: recovery workflows do not widen authority beyond profile rules; actions are portal-mediated and transcript-visible.

## Evidence plan (seed)
- Harness: install update with a recovery_root; verify boot menu selection boots recovery.
- Negative tests: corrupt active root, ensure recovery still boots.
- Trial-boot loop: from recovery, stage a `pending` trial boot of a candidate deployment; verify bounded tries and fallback to LKG.

## References
REF-WINRE, REF-ANDROID-PARTITIONS, REF-SYSTEMD-SPECIAL.
