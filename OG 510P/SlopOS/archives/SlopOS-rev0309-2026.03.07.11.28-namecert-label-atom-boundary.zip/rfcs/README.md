# RFCs

RFCs capture proposals, alternatives, and evidence plans. Accepted RFCs are later distilled into ADRs once implementation/proof alignment exists.

Lifecycle: Draft → Review → (Accepted | Rejected | Superseded) → ADR (if accepted).

## Index
| RFC | Topic | Status | Updated |
|---|---|---|---|
| [0001](0001-encoding-baseline.md) | RFC-0001: Canonical encoding baseline for CH-* (D-ENC / D-UPD-SIGN) | — | — |
| [0002](0002-mile-high-paradigms-and-targets.md) | RFC-0002: Mile-high paradigms + flagship targets (integration map) | — | — |
| [0003](0003-ecosystem-features-to-bake-in.md) | RFC-0003: Ecosystem features to bake in early (candidate list) | Draft | 2026-02-25 |
| [0004](0004-networked-capabilities-and-delegation-tokens.md) | RFC-0004: Networked capabilities + delegation tokens (D-CAPX) | Draft | — |
| [0005](0005-wasm-component-profile.md) | RFC-0005: Wasm component profile (D-WASM) | Draft | 2026-02-24 |
| [0006](0006-contract-based-channels.md) | RFC-0006: Contract-based channels (protocol state machines) (D-CONTRACT) | Draft | — |
| [0007](0007-membranes-sealers-and-auth-agents.md) | RFC-0007: Membranes, sealers, and key-holding auth agents (D-MEMBRANE, D-AUTHAGENT) | Draft | — |
| [0008](0008-event-plumbing-temporal-caps-driver-domains.md) | RFC-0008: Event plumbing, temporal capabilities, and driver domains | Draft | 2026-02-23 |
| [0009](0009-component-manifests-and-capability-routing.md) | RFC-0009: Component manifests and capability routing (D-COMP) | Draft | 2026-02-23 |
| [0010](0010-ambient-authority-and-capability-mode.md) | RFC-0010: Ambient authority elimination + capability mode (D-CAPMODE) | Draft | — |
| [0011](0011-idl-and-codegen-for-privileged-interfaces.md) | RFC-0011: IDL + code generation for privileged interfaces (D-IDL) | Draft | — |
| [0012](0012-resource-meters-space-banks-and-budgets.md) | RFC-0012: Resource meters, space banks, and budgets (D-METER, D-TCAP) | Draft | — |
| [0013](0013-deterministic-record-replay-boundary.md) | RFC-0013: Deterministic record/replay boundary (D-RR) | Draft | — |
| [0014](0014-sturdyrefs-and-capability-uris.md) | RFC-0014: SturdyRefs + capability URIs (offline capabilities) (D-CAPX adjunct) | Draft | — |
| [0015](0015-safe-tracing-and-observability.md) | RFC-0015: Safe tracing and tracepoints (D-TRACE) | Draft | — |
| [0016](0016-voluntary-sandboxing-promises-and-unveil.md) | RFC-0016: Voluntary self-restriction (promises + “unveil”-style narrowing) (D-SEAL) | Draft | — |
| [0017](0017-supervision-trees-and-restart-policy.md) | RFC-0017: Supervision trees, reincarnation, and restart policy (CH-COMP extension) | Draft | — |
| [0018](0018-system-knowledge-base-and-hardware-facts.md) | RFC-0018: System Knowledge Base (SKB) + hardware facts (D-SKB) | Draft | — |
| [0019](0019-revocation-epochs-and-indirection.md) | RFC-0019: Capability revocation via epochs/indirection (D-CAP adjunct) | Draft | — |
| [0020](0020-type-capabilities-and-kernel-internal-authority.md) | RFC-0020: Type-capabilities for kernel-internal authority (Rust posture) | Draft | — |
| [0021](0021-static-partition-policy-profile.md) | RFC-0021: Static partition policy profile (D-PART) | Draft | — |
| [0022](0022-address-decoding-nets-and-page-table-gen.md) | RFC-0022: Address decoding nets + page-table generation (D-ADDRNET) | Draft | — |
| [0023](0023-local-naming-certificates-spki-sdsi.md) | RFC-0023: Local naming certificates (SPKI/SDSI-style) (D-NAMECERT) | Draft | — |
| [0024](0024-initial-state-snapshots-and-cap-distribution-language.md) | RFC-0024: Initial state snapshots and capability distribution language (D-INITSNAP) | draft | — |
| [0025](0025-device-attestation-dice-eat.md) | RFC-0025: device attestation (DICE + EAT) (optional) | draft | — |
| [0026](0026-object-capability-rpc-profile.md) | RFC-0026: object-capability RPC profile (Cap'n Proto–style) (optional) | draft | — |
| [0027](0027-definitional-models-and-differential-testing.md) | RFC-0027: Definitional models and differential randomized testing (DRT) | Draft | 2026-02-23 |
| [0028](0028-veto-only-policy-bundles-for-automation.md) | RFC-0028: Veto-only policy bundles for automation (Cedar profile) | Draft | 2026-02-23 |
| [0029](0029-transparency-log-anchors-for-evidence.md) | RFC-0029: Transparency log anchors for evidence (release/provenance) | Draft | 2026-02-23 |
| [0030](0030-artifact-references-and-content-addressed-evidence.md) | RFC-0030: Artifact references and content-addressed evidence (anti-bloat seam) | Draft | — |
| [0031](0031-powerbox-consent-mediators-and-capability-ux.md) | RFC-0031: Powerbox/consent mediators and capability UX | Draft | — |
| [0032](0032-view-namespace-semantics-v1.md) | RFC-0032: View/namespace semantics v1 (per-process namespaces, union mounts, service trees) | Draft | 2026-02-24 |
| [0033](0033-functional-build-graphs-and-store.md) | RFC-0033: Functional build graphs + content-addressed store (D-FPM) | Draft | 2026-02-24 |
| [0034](0034-kernel-object-quotas-and-cap-budgets.md) | RFC-0034: Kernel object quotas and cap budgets (D-KOBJQ, D-METER) | Draft | 2026-02-24 |
| [0035](0035-capability-graph-export-and-leak-tests.md) | RFC-0035: Capability graph export, introspection, and leak tests (D-CAPAUD) | Draft | 2026-02-24 |
| [0036](0036-rump-kernel-compatibility-domains.md) | RFC-0036: Rump-kernel compatibility domains for legacy drivers/FS (D-RUMPK) | Draft | 2026-02-24 |
| [0037](0037-checkpoint-restore-and-migration-substrate.md) | RFC-0037: Checkpoint/restore and migration substrate (D-CHKPT) | Draft | 2026-02-24 |
| [0038](0038-persistent-object-store-and-snapshots.md) | RFC-0038: Persistent object store + snapshot semantics (D-PERSIST) | Draft | 2026-02-24 |
| [0039](0039-volition-tokens-and-trusted-ui-path.md) | RFC-0039: Volition tokens and a trusted UI path (D-VOLITION) | Draft | 2026-02-24 |
| [0040](0040-multikernel-scaling-monitor-architecture.md) | RFC-0040: Multikernel-inspired scaling and monitor architecture (D-MK) | Draft | 2026-02-24 |
| [0041](0041-crash-only-services-and-microreboots.md) | RFC-0041: Crash-only services + microreboot discipline (D-SUPV adjunct) | Draft | 2026-02-24 |
| [0042](0042-constructors-and-confinement-tests.md) | RFC-0042: Constructor objects and confinement tests (D-CONSTR) | Draft | 2026-02-24 |
| [0043](0043-capsule-isolation-and-unsafe-budgets.md) | RFC-0043: Capsule isolation and unsafe budgets (D-UNSAFE adjunct) | Draft | 2026-02-24 |
| [0044](0044-user-mode-paging-and-external-pagers.md) | RFC-0044: User-mode paging and external pagers (D-PAGER) | Draft | 2026-02-24 |
| [0045](0045-device-leasing-and-io-bypass.md) | RFC-0045: Device leasing and data-plane I/O bypass (D-IOLEASE) | Draft | 2026-02-24 |
| [0046](0046-workflow-plumbing-and-portals.md) | RFC-0046: Workflow plumbing + portals (capability-safe cross-app routing) (D-PLUMB) | Draft | 2026-02-24 |
| [0047](0047-decentralized-information-flow-control.md) | RFC-0047: Decentralized information-flow control substrate (D-IFC) | Draft | 2026-02-24 |
| [0048](0048-failpoints-and-fault-injection-profiles.md) | RFC-0048: Failpoints and fault-injection profiles (D-FAILPOINT) | Draft | 2026-02-24 |
| [0049](0049-temporal-capabilities-and-scheduling-contexts.md) | RFC-0049: Temporal capabilities + scheduling contexts (D-TCAP / D-SCHED / D-UPCALL) | Draft | 2026-02-24 |
| [0050](0050-disposable-domains-and-one-shot-sandboxes.md) | RFC-0050: Disposable domains + one-shot sandboxes (D-EPHEM) | Draft | 2026-02-24 |
| [0051](0051-atomic-system-updates-and-supply-chain-gates.md) | RFC-0051: Atomic system updates + supply-chain gates (D-ATOMICUPD) | Draft | 2026-02-24 |
| [0052](0052-wasm-components-as-extension-runtime.md) | RFC-0052: WebAssembly components as the default untrusted extension runtime (D-WASM) | Draft | 2026-02-24 |
| [0053](0053-origin-quarantine-and-safe-open.md) | RFC-0053: Origin metadata + quarantine + safe-open defaults (D-QUAR) | Draft | 2026-02-24 |
| [0054](0054-authority-diffs-and-consent-receipts.md) | RFC-0054: Authority diffs + consent receipts (D-EXPLAIN) | Superseded (see 0069) | 2026-02-26 |
| [0055](0055-attention-authority-and-notifications.md) | RFC-0055: Attention authority + notifications (D-ATTN) | Draft | 2026-02-24 |
| [0056](0056-outbound-network-leases-and-portals.md) | RFC-0056: Outbound network leases via a portal (D-NETLEASE) | Draft | 2026-02-24 |
| [0057](0057-pressure-signals-and-backpressure.md) | RFC-0057: Resource pressure + backpressure signals (D-PRESSURE) | Draft | 2026-02-24 |
| [0058](0058-operation-scoped-budget-leases.md) | RFC-0058: Operation-scoped budget leases (D-BUDGET) | Draft | 2026-02-24 |
| [0059](0059-sealed-code-spaces-and-dynamic-loading.md) | RFC-0059: Sealed code spaces + dynamic code loading posture (D-DYNCODE) | Draft | 2026-02-24 |
| [0060](0060-cheri-platform-profile.md) | RFC-0060: CHERI-ready compartmentalization profile (D-CHERI) | Draft | 2026-02-24 |
| [0061](0061-bootstrappable-toolchains-and-ddc.md) | RFC-0061: Bootstrappable toolchains + diverse double-compiling (D-BOOTSTRAP / D-DDC) | Draft | 2026-02-24 |
| [0062](0062-hardware-memory-tagging-and-hardening-profiles.md) | RFC-0062: Hardware memory tagging + hardening profiles (D-MEMTAG) | Draft | 2026-02-24 |
| [0063](0063-nondeterminism-capabilities-clock-and-entropy.md) | RFC-0063: Nondeterminism capabilities (Clock + Entropy handles) (D-NONDET) | Draft | 2026-02-24 |
| [0064](0064-confidential-computing-profile.md) | RFC-0064: Confidential-computing profile (D-CC) | Draft | 2026-02-24 |
| [0065](0065-orthogonal-persistence-and-capstore.md) | RFC-0065: Orthogonal persistence + capability store (D-PERSIST) | Draft | 2026-02-24 |
| [0066](0066-capability-leases-and-limited-use-proxies.md) | RFC-0066: Capability leases + limited-use proxies (D-LEASE) | Draft | 2026-02-24 |
| [0067](0067-capability-crypto-services-and-key-handles.md) | RFC-0067: Capability crypto services + non-exportable key handles (D-CRYPTOSVC) | Draft | 2026-02-24 |
| [0068](0068-wasm-trace-processing-pipelines.md) | RFC-0068: Wasm trace-processing pipelines (D-TRACEPROC) | Draft | 2026-02-24 |
| [0069](0069-capability-diffs-for-consent-and-receipts.md) | RFC-0069: Capability diffs for consent + receipts (CH-CAPDIFF, D-EXPLAIN) | Draft | 2026-02-24 |
| [0070](0070-sealed-secrets-and-vault-service.md) | RFC-0070: Sealed secrets + vault service (D-VAULT) | Draft | 2026-02-24 |
| [0071](0071-interface-evolution-open-protocols-and-adapters.md) | RFC-0071: Interface evolution, open protocols, and adapters (D-APIEVO) | Draft | 2026-02-25 |
| [0072](0072-idl-digests-and-ordinals-for-caprpc.md) | RFC-0072: IDL digests + method ordinals for CapRPC (D-IDL/D-APIEVO) | Draft | 2026-02-25 |
| [0073](0073-trace-predicates-and-prefiltering.md) | RFC-0073: Trace predicates + prefiltering (D-TPRED) | Draft | 2026-02-25 |
| [0074](0074-health-predicates-and-boot-success.md) | RFC-0074: Health predicates + boot-success commit (D-HEALTH) | Draft | 2026-02-25 |
| [0075](0075-inspect-trees-and-diagnostic-snapshots.md) | RFC-0075: Inspect trees + diagnostic snapshots (D-INSPECT) | Draft | 2026-02-25 |
| [0076](0076-observation-export-policy.md) | RFC-0076: Observation export policy-as-data (D-OBSPOL) | Draft | 2026-02-25 |
| [0077](0077-tracepoint-descriptors-and-fielded-traces.md) | RFC-0077: Tracepoint descriptors and fielded traces (D-TPROBE) | Draft | 2026-02-25 |
| [0078](0078-turn-based-concurrency-and-reentrancy-guards.md) | RFC-0078: Turn-based concurrency + reentrancy guards for capability services (D-TURNS) | Draft | 2026-02-25 |
| [0079](0079-tuf-style-update-repository-metadata.md) | RFC-0079: TUF-style update repository metadata (D-TUF) | Draft | 2026-02-25 |
| [0080](0080-capability-mediated-ui-compositor-and-secure-attention.md) | RFC-0080: Capability-mediated UI compositor + secure attention (D-UICAP) | Draft | 2026-02-25 |
| [0081](0081-activation-handoff-and-handle-stores.md) | RFC-0081: Activation, handle handoff, and stable service handles (D-ACTIVATE) | Draft | 2026-02-25 |
| [0082](0082-witnessed-checkpoints-and-split-view-resistance.md) | RFC-0082: Witnessed checkpoints and split-view resistance for transparency logs (D-WITNESS) | Draft | 2026-02-25 |
| [0083](0083-driver-hosts-and-compatibility-runtimes.md) | RFC-0083: Driver hosts + legacy driver compatibility runtimes (D-DRVDOM / D-RUMPK) | Draft | 2026-02-25 |
| [0084](0084-copyless-buffer-objects-and-shared-regions.md) | RFC-0084: Copyless buffer objects and shared regions (D-IOBUF) | Draft | 2026-02-25 |
| [0085](0085-device-authorization-and-hotplug-portals.md) | RFC-0085: Device authorization and hotplug portals (D-DEVGUARD) | Draft | 2026-02-25 |
| [0086](0086-crash-capsules-and-shareable-evidence-bundles.md) | RFC-0086: Crash capsules + shareable failure evidence bundles (CH-CRASHCAP) | Draft | 2026-02-26 |
| [0087](0087-triage-rules-and-on-device-diagnosis.md) | RFC-0087: Triage rules and on-device diagnosis predicates (D-TRIAGE) | Draft | 2026-02-26 |
| [0088](0088-measured-boot-event-logs-and-measurement-logs.md) | RFC-0088: Measured boot event logs as pinned artifacts (CH-MEASLOG) (D-BOOT adjunct) | Draft | 2026-02-26 |
| [0089](0089-document-portal-and-durable-file-handles.md) | RFC-0089: Document portal + durable file handles (CH-DOCREF) (D-PLUMB/D-POWERBOX adjunct) | Draft | — |
| [0090](0090-secure-time-sync-and-timeproofs.md) | RFC-0090: authenticated network time + verifiable time proofs (CH-TIMEPROOF) (D-TIMEPROOF) | Draft | 2026-02-26 |
| [0091](0091-sbom-artifacts-and-closure-binding.md) | RFC-0091: SBOM artifacts as pinned, digest-bound evidence (CH-SBOM) (D-SBOM) (optional) | Draft | 2026-02-26 |
| [0092](0092-vex-artifacts-and-exploitability-statements.md) | RFC-0092: VEX artifacts as pinned, digest-bound exploitability statements (CH-VEX) (D-VEX) (optional) | Draft | 2026-02-26 |
| [0093](0093-signature-envelopes-and-keyless-signing.md) | RFC-0093: Signature envelopes for CH-* payloads + optional keyless signing (CH-SIGENV) (D-SIGENV / D-KEYLESS) | Draft | 2026-02-26 |
| [0094](0094-transfer-portal-and-typed-payload-leases.md) | RFC-0094: Transfer portal + typed payload leases (CH-XFER) (D-PLUMB adjunct) | Draft | 2026-02-26 |
| [0095](0095-media-capture-portals-and-session-descriptors.md) | RFC-0095: Media capture portals + session descriptors (CH-CAPTURE) (D-CAPTURE adjunct) | Draft | 2026-02-26 |
| [0096](0096-job-portal-and-constraint-based-background-work.md) | RFC-0096: Job portal + constraint-based background work (CH-JOBREQ) (D-JOBS) | Draft | 2026-02-26 |
| [0097](0097-data-contracts-and-migration-gates.md) | RFC-0097: Data contracts + migration gates for atomic updates (D-ATOMICUPD adjunct) | Draft | 2026-02-26 |
| [0098](0098-recovery-mode-and-rescue-environment.md) | RFC-0098: Recovery mode + rescue environment (D-RECOVERY) | Draft | 2026-02-26 |
| [0099](0099-accessibility-and-automation-leases.md) | RFC-0099: Accessibility + automation as leased, audited capabilities (CH-UIAUT) (D-UIAUT) | Draft | 2026-02-26 |
| [0100](0100-attribute-query-predicates-and-smart-folders.md) | RFC-0100: Attribute query predicates + smart folders (D-ATTRFS adjunct) | Draft | 2026-02-26 |
| [0101](0101-location-leases-and-portals.md) | RFC-0101: Location leases via a portal (CH-LOCLEASE) (D-LOCLEASE) | Draft | 2026-02-26 |
| [0102](0102-inhibit-leases-and-power-inhibition-portal.md) | RFC-0102: Inhibit leases + power/idle inhibition portal (CH-INHIBITLEASE) (D-INHIBITLEASE) | Draft | 2026-02-26 |
| [0103](0103-background-execution-and-autostart-leases.md) | RFC-0103: Background execution + autostart as leased, audited authority (CH-BGLEASE) (D-BGLEASE) | Draft | 2026-02-26 |
| [0104](0104-application-secrets-and-secret-portal.md) | RFC-0104: Application secrets via a secret portal (CH-APPSECRET) (D-APPSECRET) | Draft | 2026-02-26 |
| [0105](0105-request-contexts-deadlines-and-cancellation.md) | RFC-0105: Request contexts (deadlines + cancellation + trace correlation) (D-REQCTX) | Draft | 2026-02-27 |
| [0106](0106-wait-sets-and-object-signals.md) | RFC-0106: Wait sets + object signals for scalable event loops (D-WAITSET) | Draft | 2026-02-27 |
| [0107](0107-io-submission-queues-and-completions.md) | RFC-0107: I/O submission queues + completion events (D-IOQ) | Draft | 2026-02-27 |
| [0108](0108-quiescence-and-drain-protocol.md) | RFC-0108: Quiescence + drain protocol for maintenance operations (D-QUIESCE) | Draft | 2026-02-27 |
| [0109](0109-flight-recorder-buffers-and-incident-capture.md) | RFC-0109: Flight recorder buffers + incident capture triggers (D-FLIGHTREC) | Draft | 2026-02-27 |
| [0110](0110-wait-on-address-and-futex-primitives.md) | RFC-0110: Wait-on-address / futex primitives for userspace synchronization (D-UWAIT) | Draft | 2026-02-27 |
| [0111](0111-robust-locks-and-owner-death.md) | RFC-0111: Robust locks + owner-death semantics for shared synchronization (D-ROBUSTLOCK) | Draft | 2026-02-27 |
| [0112](0112-grace-periods-and-deferred-reclamation.md) | RFC-0112: Grace periods + deferred reclamation for read-mostly shared state (D-RCU) | Draft | 2026-02-27 |
| [0113](0113-restartable-sequences-and-cpu-local-fast-paths.md) | RFC-0113: Restartable sequences + CPU-local fast paths (D-RSEQ) | Draft | 2026-02-27 |
| [0114](0114-verified-blobs-and-merkle-integrity.md) | RFC-0114: Verified blobs + Merkle integrity for immutable content (D-VERITY) | Draft | 2026-02-27 |
| [0115](0115-capability-safe-shell-and-automation.md) | RFC-0115: Capability-safe shell + automation components (D-CAPSHELL) | Draft | 2026-02-27 |
| [0116](0116-capability-wallets.md) | RFC-0116: Capability wallets (CH-WALLET v0) | Draft | 2026-02-27 |

| [0117](0117-plumb-messages-and-cli-intents.md) | RFC-0117: Plumb messages + CLI intents (CH-PLUMBMSG) (D-PLUMB adjunct) | Draft | 2026-02-27 |
| [0118](0118-privilege-bracketing-and-call-chain-contexts.md) | RFC-0118: Privilege bracketing + call-chain contexts (CH-CALLCHAIN) (D-BRACKET) | Draft | 2026-02-27 |
| [0119](0119-ordering-streams-and-tokens.md) | RFC-0119: Ordering streams + ordering tokens for non-commutative actions (CH-ORDERTOK) (D-COMMUTE adjunct) | Draft | 2026-02-27 |
