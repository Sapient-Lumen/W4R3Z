# RFC-0114: Verified blobs + Merkle integrity for immutable content (D-VERITY)

Status: Draft  
Updated: 2026-02-27  
Decision node(s): **D-VERITY**, D-ATOMICUPD (adjunct), D-BOOT (adjunct), D-DYNCODE (adjunct), D-PAGER (adjunct), D-AREF (adjunct), D-OBSPOL (adjunct), D-METER (adjunct)

## Summary
Modern systems routinely ship **large immutable artifacts** (base OS trees, packages, application bundles, model weights, firmware blobs, “known good” config snapshots). If those bytes are silently modified at rest, the consequences range from crashes to supply-chain compromise.

Mature ecosystems converged on **Merkle-tree verified reads**:
- **dm-verity** verifies blocks of a read-only block device using a hash tree and a pinned root hash.
- **fs-verity** does the same at the **file** level: a hidden Merkle tree is associated with a file and reads are transparently verified.

A greenfield capability OS should standardize a small, capability-friendly **D-VERITY seam** now:
- immutable content can be represented as **VerifiedBlob** handles,
- reads are **fail-closed** on verification failure,
- the “what was verified” identity is explicit as a bounded descriptor (**CH-VBLOB v0**),
- verification stays mostly in user space (storage services / pagers), avoiding a large privileged surface.

## Goals
- Provide an **optional** verified-read primitive for immutable content that:
  - detects offline tampering deterministically,
  - composes with content-addressed artifacts (CH-AREF) and provenance (CH-PROV),
  - does not rely on ambient paths.
- Keep the privileged core small: prefer user-space verification in storage/pager domains.
- Make failure behavior explicit and usable:
  - verification failures are explicit errors (and optionally diagnostic signals),
  - corruption does not silently propagate.
- Keep metadata and caches **bounded** and attributable (D-METER when enabled).

## Non-goals
- A general-purpose encrypted filesystem design.
- A full package manager or update repository design (see D-FPM / D-TUF / D-ATOMICUPD).
- A requirement that *all* files be verified.

## Design sketch
### 1) VerifiedBlob as a handle type (concept)
Introduce a standard *conceptual* handle type:
- `VerifiedBlob` (read-only)

A VerifiedBlob has:
- a pinned **content identity** (a digest over the file content; and/or a Merkle root),
- a verification policy (`enforce_on_read` in v0),
- an optional link to an external artifact reference (CH-AREF) for fetch/transport.

The key property is simple:
- **Any read of a VerifiedBlob either returns correct bytes or fails closed.**

### 2) Two implementation styles (both acceptable)
D-VERITY deliberately allows two common implementation strategies:

1) **File-level verity (fs-verity style):**
   - the storage service associates a hidden hash tree with an immutable blob object,
   - reads verify leaf blocks against the tree,
   - the blob has a stable digest/measurement exposed for signing and policy checks.

2) **Device-/volume-level verity (dm-verity style):**
   - the OS boots a read-only volume protected by a hash tree,
   - the root hash is pinned by boot/update policy,
   - file reads inherit integrity from the verified volume.

In both cases, the OS should surface a **VerifiedBlob** interface for consumers.

### 3) Descriptor schema: CH-VBLOB v0
Standardize a bounded, redaction-safe descriptor that can be:
- referenced from CH-BOOT/CH-UPD `artifacts[]`,
- attached to transcripts (CH-LOG) as “what content identity was expected”,
- included in incident bundles (CH-SNAPSHOT) under CH-OBSPOL.

The schema is **not an authorization token**; it is an identity/intent descriptor (I-VERITY-1).

See: `docs/30-architecture/verified-blob-descriptor-schema-v0.md`.

### 4) Composition notes
- **With D-ATOMICUPD / D-FPM:** VerifiedBlob identity should line up with the digest identity used for deployments/store objects. Prefer “digest is identity” so update and verification share vocabulary.
- **With D-DYNCODE:** sealed profiles can require executable pages to be backed by VerifiedBlob handles whose digests are listed in CH-BOOT/CH-UPD (synergy with I-EXEC-SOURCE-1).
- **With D-PAGER:** VerifiedBlob is a natural fit for pager-backed objects: the pager can verify pages/blocks as it services faults, keeping the kernel thin.
- **With observability:** verification failure should be diagnosable without leaking bytes: emit bounded findings (diagnostics) and permit export only under CH-OBSPOL.

## Security and safety notes
- **Fail closed:** corruption must produce explicit I/O errors (or a distinct “integrity failure” error) and never return unverifiable data.
- **DoS controls:** verification is CPU and I/O work; caches must be bounded and attributable (D-METER) to avoid “hash tree thrash” as an attack.
- **Side channels:** accessing hash tree metadata can expose access patterns (like any paging/cache). Treat this under the existing side-channel posture; avoid introducing new ambient oracles.

## Evidence plan (seed)
EVID-2026-117:
- validator tests for CH-VBLOB v0 (canonical encoding, bounds, allowlisted algs),
- a storage/pager prototype that:
  - creates VerifiedBlob objects from content + hash tree,
  - injects corruption and demonstrates fail-closed reads,
  - exercises bounded cache behavior under adversarial access patterns,
  - shows clean integration with D-ATOMICUPD “deployment digests” and (optionally) D-DYNCODE policy checks.

## References (see bibliography)
REF-LINUX-FSVERITY, REF-LINUX-DMVERITY, REF-ANDROID-DMVERITY, REF-ANDROID-AVB2-README.
