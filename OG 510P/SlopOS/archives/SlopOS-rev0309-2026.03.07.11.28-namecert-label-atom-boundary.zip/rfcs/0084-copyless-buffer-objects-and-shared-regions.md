# RFC-0084: Copyless buffer objects and shared regions (D-IOBUF)

Status: Draft  
Updated: 2026-02-25  
Decision node(s): D-IOBUF, D-CAPRPC (adjunct), D-CONTRACT (adjunct), D-DRVDOM (adjunct), D-IOLEASE (adjunct), D-ENC

## Summary
Introduce an **optional** “copyless data movement” seam that does **not** collapse our authority model:

- Standardize **shared-region buffer handles** as an opt-in performance mechanism.
- Require an accompanying, redaction-safe **CH-IOBUF v0** descriptor for audit/lint/UX.
- Make the **safe default** for cross-trust sharing be **immutable payloads** (IO-Lite-style) or **COW snapshots** (Zircon VMO child/clone style), so receivers do not inherit TOCTTOU hazards.
- Keep all policy and routing in user space: the kernel remains a mapping/enforcement mechanism, not a buffering policy engine.

Default posture remains bounded-copy IPC; D-IOBUF is a profile feature.

## Motivation
Microkernels often pay a performance tax when large payloads are moved via copying. Ecosystems that become “real” eventually reinvent shared memory channels.

However, *naive* shared memory between mutually suspicious components is a trap:
- It creates TOCTTOU and integrity hazards (“sender mutates after send”).
- It makes revocation and lifetime ambiguous.
- It becomes a covert channel if treated as ambient.

Greenfield advantage: bake in a disciplined, explicitly-declared copyless seam that is:
- **explicit** (shared objects with enumerated participants),
- **auditable** (descriptor-as-data + transcripts),
- **safe-by-default across trust boundaries** (immutable or snapshot semantics),
- and **optional** (no proof/TCB expansion unless a profile needs it).

Prior art suggests workable primitives:
- **IO-Lite** shows that *immutable buffers* avoid synchronization/consistency/protection problems while enabling single-copy paths. (REF-IOLITE-OSDI99, REF-IOLITE-IMMUTABLE)
- **Zircon VMOs** show a practical “memory object handle + rights + COW children/clones” pattern that scales in production. (REF-FUCHSIA-VMO-CREATE, REF-FUCHSIA-VMO-CHILD)
- **Xen grant tables** demonstrate explicit, mediated page sharing between domains for split drivers. (REF-XEN-GRANTTABLE)

## Integration seam / privileged impact (keep small)
**No new privileged buffering policy.**

D-IOBUF relies only on the already-required privileged primitives:
- memory objects/pages + mapping rights,
- explicit shared-region representation (I-SHARE-1),
- capability transfer.

Everything else is user-space convention:
- buffer allocation/pooling,
- immutability/snapshot semantics (which may be implemented via copy in a low-assurance profile),
- ring protocols and ownership rules.

## Design

### 1) Buffer handles
A “buffer” is represented as a **shared region handle** (or a handle to a memory object that can be mapped into multiple domains). The authoritative rights live in the handle:
- map read
- map write
- (optional) operations such as “snapshot/freeze” if the underlying platform supports it

This RFC does **not** require a new kernel object type; it only requires that buffer sharing remain explicit (I-SHARE-1/I-MAP-1) and capability-mediated.

### 2) Descriptor-as-data: CH-IOBUF v0
Any time a buffer handle crosses a trust boundary (CapRPC, portals, driver-host APIs), the sender SHOULD provide (or the allocator SHOULD publish) a **CH-IOBUF v0** descriptor:
- kind (linear/ring/sg)
- size bounds
- declared immutability posture
- participants/roles (redaction-capable)
- trust classification hint (`same_trust` vs `cross_trust`)

Spec: `docs/30-architecture/io-buffer-schema-v0.md`.

Tooling uses CH-IOBUF to:
- lint “cross-trust + mutable buffer” as a policy violation in hardened profiles,
- explain to humans what was shared (receipts/exports),
- and gate higher-level APIs (“safe open” + quarantine) when shared buffers are involved.

### 3) Safe cross-trust posture: immutable or snapshot payloads
If `sharing.trust == cross_trust`, the recommended safe posture is:
- **immutability="frozen"**: payload is immutable once shared, or
- **immutability="cow_snapshot"**: receiver gets a snapshot view (COW child/clone semantics).

Implementation note:
- If the platform supports COW children/clones (Zircon-style), the allocator can implement snapshot without copying.
- Otherwise, a low-assurance profile may implement “freeze” by copying into a fresh read-only buffer. The semantics remain the same; only performance differs.

### 4) Streaming posture (same-trust): ring buffers + contracts
For high-throughput streaming between mutually cooperative components (e.g., media pipeline stages, driver-host ↔ protocol stack), mutable rings are useful.

For `kind == ring_*`, we require a **contracted protocol** (RFC-0006):
- a pinned ring layout (header offsets, index types, wrap rules)
- ownership rules for slots (producer writes before commit; consumer reads after commit)
- explicit backpressure signaling (pairs naturally with CapRPC oneway/pulses)

This keeps correctness/safety evidence in the *contract layer*, not in ad-hoc folklore.

### 5) DMA and driver domains (adjunct)
For `usage == driver_dma`, D-IOBUF composes with D-IOLEASE:
- buffers intended for DMA must be allocated from a pool bound to a device lease (or otherwise pinned to declared DMA windows),
- CH-IOBUF’s `coherence` fields allow tooling to require explicit flush/invalidate steps under non-coherent DMA models.

D-IOBUF does not change the DMA threat model; it just makes “what memory can the device touch?” and “what buffers were shared?” mechanically visible.

## Profile gating + defaults
- Default posture: **off**. CapRPC payloads are bounded-copy.
- If enabled:
  - cross-trust buffers MUST be immutable/snapshot unless explicitly permitted by policy.
  - buffer descriptors are required on trust-boundary crossings (portal policy may enforce).
  - bounds (size, participant count, ttl) are enforced deterministically.

## Registries impacted
Add:
- Schema: **CH-IOBUF v0**
- Invariants: **I-IOBUF-2** (see below)
- Proof obligation: **PO-IOBUF-VALIDATE**
- Abuse case: **AC-073** (shared-buffer TOCTTOU / mutation-after-send)
- Evidence seed: **EVID-2026-083**

Update:
- I-IOBUF-1 (tighten definition)
- PO-IOBUF-OWNERSHIP (tie to immutability/snapshot posture)
- `docs/90-inspirations/os-lessons.md` (IO-Lite + VMOs + grant tables)
- decision map: D-IOBUF references RFC-0084

## Threat-model impact
Primary risks:
- **TOCTTOU / mutation-after-send** across trust boundaries.
- **Covert channels** via uncontrolled shared regions.
- **Integrity confusion**: receivers treat shared bytes as stable when they are not.

Mitigations:
- “cross-trust implies immutable/snapshot” lint gate (CH-IOBUF + policy).
- explicit participants (I-SHARE-1) and bounded lifetime.
- contracted ring protocols for mutable streaming cases.
- observation/export redaction for participant identities.

## Abuse cases / pressure tests
- AC-073 defines the “mutable-after-send” pressure test and its expected fail-closed gates.

## Assurance/verification impact
- We do not expand privileged proof surface by default; D-IOBUF is a profile.
- For a D-IOBUF enabled profile, we must show:
  - CH-IOBUF validation is total/canonical (PO-IOBUF-VALIDATE).
  - buffer sharing preserves explicit sharing semantics and does not introduce hidden aliasing across trust boundaries (PO-IOBUF-OWNERSHIP; I-IOBUF-1/I-IOBUF-2).

## Observability / operations impact
- Buffer sharing events that cross trust boundaries SHOULD be transcript-visible (CH-LOG by digest) and, when exported, include CH-IOBUF with appropriate redaction.

## Alternatives
- **Always copy**: simplest; often acceptable, but leaves performance on the table for driver domains and media/IO-heavy workloads.
- **Shared memory without descriptors**: fast but becomes unauditable and error-prone; hard to gate cross-trust uses.
- **Kernel-managed unified buffer cache** (IO-Lite-in-kernel): powerful but expands privileged policy surface; we prefer descriptor-as-data + user-space allocators.

## Evidence plan
**EVID-2026-083** prototype plan:
- Implement a user-space buffer allocator/portal that issues buffer handles plus CH-IOBUF v0.
- Add a “freeze/snapshot” operation with two backends:
  - COW snapshot when supported,
  - copy fallback otherwise.
- Negative tests:
  - `cross_trust + immutability=mutable` must be rejected by policy/validator in hardened profile.
  - descriptor decode fuzz corpus must fail closed.
  - ring contracts: violate ordering/ownership rules → deterministic contract failure.
- Microbench:
  - compare copy vs snapshot vs ring in a toy pipeline.

## Open questions
- Do we need a minimal, standard “buffer portal” interface (CapRPC IDL) in Phase 1, or can we leave allocation APIs unconstrained until we pick a primary runtime?
- For non-coherent DMA, do we want the flush/invalidate API pinned as a contract (D-CONTRACT) or treated as device-lease-specific behavior?
