# RFC-0086: Crash capsules + shareable failure evidence bundles (CH-CRASHCAP)

Status: Draft  
Updated: 2026-02-26  
Decision node(s): D-INSPECT, D-RR, D-OBS, D-OBSPOL, D-ENC, D-FPM (adjunct)

## Summary
Define an optional, ecosystem-facing **crash capsule** artifact:

- **CH-CRASHCAP v0**: a bounded manifest for a *single failure event* (crash/panic/abort/watchdog)
  - binds crash metadata (what failed, where, why)
  - references (by digest / CH-AREF) a small set of payloads: log/trace windows, inspect snapshots, and an optional dump (minidump/core) and/or replay slice
  - includes the module/build identity needed for symbolization without shipping the full system image

CH-CRASHCAP is designed to make “attach a bug report that is actually useful” the default workflow, while keeping exports explicit and redaction-scoped.

## Motivation
Every mature ecosystem invents “crash reports” because:
- crashes are common in early systems and in the long tail of drivers/plugins,
- reproducing customer failures is expensive,
- raw logs are rarely enough (need registers, threads, module list, mappings),
- full core dumps are often too large and too sensitive.

Practical prior art converges on a few patterns:
- **minidumps** (Windows; Breakpad/Crashpad) give a compact, tool-friendly capture that still supports symbolized stacks and basic inspection (REF-MS-MINIDUMP-FILES).
- **out-of-process capture** (Crashpad) improves fidelity and avoids doing complex work in a corrupted process (REF-CRASHPAD-OVERVIEW).
- Linux-style **core dump collection** pipelines (systemd-coredump) standardize capture, retention, and operator workflows (REF-SYSTEMD-COREDUMP-MAN).
- **time-travel debugging** (rr, WinDbg TTD) shows the ceiling: for some classes of bugs, replay bundles are the best bug report you can file (REF-RR-PROJECT, REF-TTD-MS).

We already have the pieces (CH-LOG, CH-TRACE, CH-INSPECT, CH-SNAPSHOT, CH-RRBUNDLE). What’s missing is a *tight, failure-shaped* bundle with a consistent identity/symbolization story.

## Design goals
- **High signal per byte**: produce a useful bug report without shipping “the whole machine.”
- **Bounded + automatable**: default capsule size is bounded; collection does not require hand-written app code.
- **Privacy-first exports**: capsule creation/storage may be local; exporting/sharing is explicit authority (I-OBS-1).
- **Stable symbolization**: crash artifacts must be symbolizable using content identity (build IDs / digests), not mutable paths.
- **Compatible with replay**: if D-RR is enabled, the capsule can point to a replay slice or bundle rather than duplicating semantics.

## Non-goals
- Mandating a single dump format for all targets (we keep `dump_kind` an enum and treat payloads as opaque artifacts).
- Building a hosted crash aggregation service into the OS.
- Making crash capture an ambient capability available to arbitrary apps.

## Proposal

### 1) Add CH-CRASHCAP v0 (manifest)
CH-CRASHCAP is a bounded manifest with:
- crash identity + classification (component/domain, fault kind, reason)
- environment binding (boot digest, config generation digest, component graph digest)
- module identity list (build IDs / digests)
- references to payloads (by digest / CH-AREF)

Schema: `docs/30-architecture/crash-capsule-schema-v0.md`.

Relationship to existing artifacts:
- CH-CRASHCAP is to CH-SNAPSHOT what “a crash report” is to “a sysdiagnose/bugreport.”
- A CH-CRASHCAP MAY embed a CH-SNAPSHOT digest if operators choose to attach a larger support bundle.
- A CH-CRASHCAP MAY reference a CH-RRBUNDLE digest if replay is enabled and permitted.

### 2) Dump payload guidance: prefer minidumps (when plausible)
To keep capsules small and tool-friendly:
- Recommend **minidump** as the default native dump payload kind for user-space processes (when platform/tooling supports it) (REF-MS-MINIDUMP-HEADER, REF-MS-MINIDUMP-FILES).
- Allow **core dumps** as an optional local-only/debug build choice.

Rationale:
- minidumps have wide tooling support (WinDbg and open-source processors; Breakpad/Crashpad ecosystem) and are designed for “basic debugging operations” without full memory images (REF-MS-MINIDUMP-FILES).

Note: the manifest does not interpret dump bytes; it only binds them.

### 3) Out-of-process capture posture (recommended)
Crash capture SHOULD be performed by a separate crash-handler component owned/supervised by the system manager:
- reduces reliance on the crashed process being healthy
- allows policy enforcement (redaction, size limits) outside the faulting address space

Crashpad’s design documents the rationale and constraints for this pattern (REF-CRASHPAD-OVERVIEW).

### 4) Symbolization: build IDs + content-addressed debug artifacts
A crash capsule is only as useful as its symbolization story.

Proposal (tight, low-ambience):
- Every shipped binary/module SHOULD embed a **build ID** (or equivalent content identity) (REF-ELF-BUILDID, REF-LD-BUILDID).
- CH-CRASHCAP includes a `modules[]` list with (module_kind, name_hint, build_id/digest, load_addr range if permitted by export policy).
- Debug artifacts (DWARF, Breakpad `.sym`, source bundles) are stored as content-addressed objects in our D-FPM store.

Optional ecosystem feature:
- a **debuginfo fetch service** similar to `debuginfod`, indexed by build-id, but gated by observation/export policy and local trust (REF-DEBUGINFOD, REF-ELFUTILS-DEBUGINFOD).

### 5) Minimization + redaction
Default capsule assembly MUST:
- slice CH-LOG/CH-TRACE windows to bounded ranges around the crash
- apply CH-OBSPOL (or equivalent) to remove/redact sensitive fields
- fail closed if requested sensitive payloads are not authorized

If D-RR is enabled:
- prefer referencing a minimized CH-RRBUNDLE (or slice) instead of embedding additional high-risk payloads.

## Security + abuse cases
- **AC-061 (Support bundle exfiltration)** applies directly: capsules can contain secrets.
  - Mitigation: export is explicit authority; policy-scoped redaction; default to sanitized payload sets.
- **Crash-loop spam / DoS**: adversarial component crashes repeatedly to fill storage.
  - Mitigation: supervisor rate limits + retention policies; capsules are bounded and optionally sampled.

## Assurance wiring
New invariants (seed):
- **I-CRASHCAP-1 (Crash capsule bounded, optional)**: CH-CRASHCAP manifests and referenced payload sets are size-bounded; over-limit behavior is deterministic.
- **I-CRASHCAP-2 (Crash capsule export is explicit authority, optional)**: exporting/sharing CH-CRASHCAP and payloads is capability-gated and redaction-scoped under CH-OBSPOL.

New proof obligations (seed):
- **PO-CRASHCAP-VALIDATE**: total decode/validation of CH-CRASHCAP v0; unknown enums reject deterministically.
- **PO-CRASHCAP-BIND**: the capsule binds to boot/config/component graph digests; mismatches fail closed.
- **PO-CRASHCAP-REDACT**: capsule assembly enforces redaction and forbids secret-bearing identifiers by default.

## Alternatives
- “Just core dumps”: too large + too sensitive; often unusable in customer contexts.
- “Just logs”: insufficient for most native crashes.
- “Just replay”: ideal when enabled, but too heavy as a universal default.

## Next work (evidence plan)
- Prototype crash-handler component + capsule assembler.
- Define a small, deterministic allowlist of dump payload kinds per deployment profile.
- Add fuzzing + bounds tests for CH-CRASHCAP decoder.
- Validate symbolization pipeline: capsule → build-id → debuginfo retrieval → stack.
