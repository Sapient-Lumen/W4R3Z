# RFC-0100: Attribute query predicates + smart folders (D-ATTRFS adjunct)

Status: Draft  
Updated: 2026-02-26  
Decision node(s): **D-ATTRFS**, D-ENC, D-NS (adjunct)

## Summary
Define a small, bounded query contract (**CH-ATTRQ v0**) for attribute-indexed queries so that “Find”, “smart folders”, and tag-based workflows can be **fast, live, and capability-scoped** without embedding a general DB engine or scripting VM in the privileged core.

This RFC does *not* mandate BFS-style “queries are directories” semantics. It standardizes the **query bytes** and the safety rules so multiple UI shells / index services can interoperate.

## Motivation
Indexed attributes + queries are a classic “brilliant but under-adopted” OS feature: they enable:
- **fast search** without recursive scanning,
- **live queries** that update as files change,
- metadata-first workflows (email, media, tags) that feel native rather than bolted-on.

But naïve designs tend to:
- reintroduce ambient authority (“global search daemon knows all paths”),
- leak sensitive metadata via indexes,
- grow a large query language surface.

Greenfield advantage: bake in a *bounded, capability-mediated* query contract and keep policy in user space.

## Design constraints
- **Capability-scoped:** queries run against an explicit view (I-VIEW-1/I-VIEW-2). No ambient global index.
- **Closed + deterministic:** unknown operators/fields/types reject deterministically.
- **Bounded cost:** query AST has strict size limits; evaluation must be fuel-bounded.
- **Typed by schema when available:** if a CH-ATTR schema digest is present, validators type-check strictly.
- **No new authority:** queries can only return handles/caps already reachable via the provided view.

## Proposal
### 1) CH-ATTRQ v0 (Attribute Query)
Add **CH-ATTRQ v0**: a canonical CBOR expression tree with a deliberately small operator set.

High-level features:
- boolean composition: `and/or/not`
- comparisons over declared attributes: `== != < <= > >=`
- bounded set membership: `in`
- `has(key)` for presence checks (useful for “tag exists”)

Out of scope for v0:
- regex, full-text indexing, arbitrary joins
- general scripting or user-defined functions

See `docs/30-architecture/attribute-query-schema-v0.md`.

### 2) Index/query service seam (user space)
If D-ATTRFS is enabled with indexing, provide a user-space service with two capabilities:
- `Index` (admin-ish within a view): create/drop indexes for keys declared in CH-ATTR; bind schema digests.
- `Query` (per-view use): evaluate CH-ATTRQ over the subset visible through a provided view.

Implementation is deliberately unconstrained (B+tree, LSM, embedded KV, etc.). The *contract* is:
- results are a **stream of handles** (e.g., directory-entry caps or DOCREF-like handles), not raw paths
- results are stable only within a declared epoch (align with D-CAP revocation epochs and D-PERSIST durable handles if enabled)

### 3) Live queries (optional but recommended)
Support an optional “live” mode:
- initial result set is produced,
- subsequent attribute mutations emit incremental add/remove events.

Phase-1 pin (see `docs/30-architecture/attrfs-posture-v0.md`): D-ATTRFS is **view-scoped, snapshot-first, and handle-returning**. Live mode is optional, revocable, and bounded; it must not turn into an app-visible saved-query inventory, hidden background watch service, or scheduler surrogate. In Phase 1, saved queries / smart folders stay shell-owned manifests bound to a query digest and explicit view binding.

This should be modeled like any other event stream:
- bounded queue,
- drop/overflow semantics are deterministic and observable,
- live subscriptions are capability-scoped and revocable.

## Threat model impact
New risks:
- **AC-085** (attribute index/query leakage or query-as-DoS)

Controls:
- capability scoping by view
- strict bounds on query size and evaluation fuel
- index visibility controls (CH-ATTR `visibility`) and redaction policy for exported results

## Invariants (add)
- **I-ATTRQ-1 (Attribute queries are view-scoped + bounded, optional):** if D-ATTRFS query mode is enabled, CH-ATTRQ validation is total/closed/bounded; query evaluation reads only declared attributes of objects reachable via the provided view and returns only handles/caps reachable via that view (no existence leaks across views).
- **I-ATTRQ-2 (Snapshot-first, non-inventory query posture, optional):** in Phase 1, D-ATTRFS query execution is snapshot-first and handle-returning by default; applications do not get count-only/path-returning/provider-global inventory APIs, and saved queries / smart folders remain shell-owned manifests bound to an explicit view rather than ambient background watch state.

## Proof obligations (add)
- **PO-ATTRQ-VALIDATE (ENC/FS):** CH-ATTRQ decoding + validation is deterministic; unknown operators/keys/types reject; schema type-checking (when `schema_digest` is present) is fail-closed.
- **PO-ATTRQ-BOUNDS (FS):** query evaluation cost is bounded (AST node count + fuel) and cannot allocate unboundedly; fuel exhaustion behavior is deterministic.
- **PO-ATTRQ-ENF (FS/UI):** query execution stays snapshot-first and handle-returning by default; any live mode is revocable/bounded with deterministic overflow behavior, and saved queries / smart folders remain shell-owned manifests rather than an app-visible inventory or background watch API.

## Evidence plan
Phase 0/1:
- validator/property tests: parse→canonicalize→hash stability; negative tests for unknown ops/keys/types
- fuzz: decoder/validator
- harness: evaluate queries against a toy indexed store under a view; verify non-amplifying results

Seed:
- **EVID-2026-103** — CH-ATTRQ v0 validator + bounded evaluation harness + “no cross-view leak” negatives

## References (bibliography IDs)
- REF-BFS-ATTR
- REF-HAIKU-QUERIES
- REF-PFSD-BFS
