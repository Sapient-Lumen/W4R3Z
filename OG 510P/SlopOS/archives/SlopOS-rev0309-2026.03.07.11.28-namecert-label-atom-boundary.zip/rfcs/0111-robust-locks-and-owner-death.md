# RFC-0111: Robust locks + owner-death semantics for shared synchronization (D-ROBUSTLOCK)

Status: Draft  
Updated: 2026-02-27  
Decision node(s): **D-ROBUSTLOCK**, D-UWAIT (adjunct), D-METER (adjunct), D-RR (adjunct), D-REQCTX (adjunct)

## Summary
A “wait-on-address” primitive (RFC-0110) makes fast locks possible, but does not by itself prevent a common failure mode:

The D-UWAIT posture keeps owner semantics out of the base wait primitive on purpose: `docs/30-architecture/uwait-posture-v0.md` pins D-UWAIT to process-local **wait + wake only**, so owner-death and inconsistent-state recovery remain a separate, explicit surface here rather than a silent widening of the sleep primitive.

Pinned v0 posture: `docs/30-architecture/robustlock-posture-v0.md` freezes Phase 1 to a **runtime-owned per-thread RobustSet**, **mutex-only**, **component-local** seam with explicit **`OWNER_DIED` / `NOT_RECOVERABLE`** recovery states and **no new workflow/ACP surface**. That means SlopOS Phase 1 deliberately stops short of inter-process/shared-region robust recovery until a shared D-UWAIT contract exists.

> A thread terminates while holding a user-space mutex; other participants in the same component can block forever.

Many mature ecosystems address this with **robust locks**:
- **Linux robust futex ABI**: kernel-assisted cleanup sets an **OWNER_DIED** flag and wakes a waiter on task exit.
- **POSIX robust mutexes**: the successor gets **EOWNERDEAD** and must call `pthread_mutex_consistent()` or the mutex becomes **ENOTRECOVERABLE**.
- **FreeBSD umtx**: explicit registration of robust mutex lists plus explicit owner-dead / not-recoverable states.
- **Windows mutexes**: the waiter acquires the mutex but learns it was **abandoned** (WAIT_ABANDONED) and must treat protected state as suspect.

We should design for this now because retrofitting “owner-death recovery” later is painful: it touches exit paths, runtime contracts, and the state machine of the shared lock word itself.

## Goals
- Prevent **permanent deadlock** caused by owner termination while holding a robust user-space mutex.
- Make both “protected state may be inconsistent” and “repair failed / abandoned” **explicit** to later acquirers (`OWNER_DIED` / `NOT_RECOVERABLE`).
- Keep the mechanism **bounded and attributable** (D-METER when enabled).
- Keep the mechanism **non-amplifying** (no new authority is created by opting into robustness).

## Non-goals
- A full kernel lock manager or global priority inheritance policy.
- Making *all* locks robust by default (opt-in only).
- Cross-process/shared-region robust recovery in Phase 1.
- Solving application-specific recovery logic; we only signal owner-death / not-recoverable state.

## Design sketch

### 1) Robust sets as explicit objects (recommended)
Introduce an optional kernel/runtime object type:

- **RobustSet**: a **per-thread** registry of robust mutex words that require owner-death cleanup.
- Rights: `REGISTER`, `UNREGISTER` only in v0.
- Charging: each registered entry consumes a bounded amount of kernel state and is charged to the holder’s budget/meter.

This keeps the surface explicit and auditable without turning it into a queryable inventory or a second lock-manager namespace.

### 2) What is registered?
A robust entry is just:
- `addr`: address of one robust **mutex** word

**Validation:** the runtime/kernel validates that `addr` lies within the caller's writable address space and names one aligned mutex word using the registered robust layout.

Phase 1 posture deliberately declines `scope=shared-region` or `kind=rwlock|condvar`; any future shared-region variant must land alongside an explicit shared wait contract rather than piggybacking on D-ROBUSTLOCK.

### 3) Owner token + `OWNER_DIED` / `NOT_RECOVERABLE` states
Define a small, language-neutral convention for the mutex word:
- a generation-safe **owner token** (e.g., thread handle ID + generation),
- an explicit **OWNER_DIED** state, and
- an explicit **NOT_RECOVERABLE** state.

When a robust owner exits abnormally (or is force-killed) while holding the mutex:
1. The runtime/kernel marks the mutex **OWNER_DIED**.
2. It performs a bounded wake on any local waiters (via D-UWAIT where available).
3. The next acquirer observes `OWNER_DIED` and returns an explicit error/flag (`owner_died` / `EOWNERDEAD` analogue).

### 4) Recovery protocol (hard decision for v0)
After `OWNER_DIED`, the successor MUST either:
- **repair** the protected state and call `make_consistent()` (returns the mutex to normal use), or
- fail closed.

If the successor unlocks or abandons the mutex **without** `make_consistent()`, the mutex becomes **NOT_RECOVERABLE** until reinitialized.

This is a deliberate Phase 1 choice: we prefer the stricter POSIX/FreeBSD-style poison state over the looser Windows-style “successor released it, so it is normal again” posture.

### 5) Interaction with deterministic replay (D-RR)
Owner-death and poison transitions are externally visible events. If D-RR is enabled, `OWNER_DIED` and `NOT_RECOVERABLE` outcomes must be recorded as part of the transcript (or surfaced as replayable decisions), so replay does not silently diverge.

### 6) Interaction with request contexts (D-REQCTX)
Robustness is not a substitute for timeouts; it only prevents indefinite blocking after owner death.
If a wait is cancellable, cancellation must not silently clear `OWNER_DIED`; it only cancels the caller's wait.

## API sketch (not final)
- `robust_create(quota) -> RobustSet`
- `robust_register(rs, addr)`
- `robust_unregister(rs, addr)`
- `robust_on_exit(rs)` (implicit by kernel/runtime on exit; exported only for test harnesses)

User-space lock API surface (library-level):
- `lock() -> ok | owner_died | not_recoverable`
- `make_consistent()` (required after `owner_died` if continuing)

## Security and safety notes
- **Non-amplification:** registering an address must not allow the caller to mutate memory it could not already write. Validation is against the caller's writable address space only.
- **Bounds:** robust sets must be capped; on overflow registration fails deterministically (no silent partial coverage). Exit-time cleanup work must also be bounded.
- **No hidden oracles:** wake/recovery must not become a cross-process signaling channel. Phase 1 stays component-local on purpose.

## Alternatives
- “Don't support this”: pushes recovery into ad-hoc timeouts; runtimes will re-invent partial robust schemes.
- Force “process dies on thread crash”: reduces the need for intra-process robustness but is too blunt for runtimes that supervise worker threads independently.
- Shared-region robust recovery now: tempting, but it widens D-UWAIT and exit-path semantics together before the smaller component-local seam is proven.
- Kernel-managed lock objects: violates minimality and increases TCB.

## Evidence plan (seed)
- EVID-2026-114: build a small harness that:
  - creates shared lock words, registers them, then kills an owner mid-critical section,
  - checks that a waiter gets `owner_died`,
  - checks bounds/charging behavior,
  - validates determinism hooks for D-RR.

## References (see bibliography)
REF-LINUX-ROBUST-FUTEX-ABI, REF-LINUX-GET-ROBUST-LIST, REF-KERNEL-ROBUST-FUTEXES-TXT,  
REF-PTHREAD-MUTEXATTR-SETROBUST, REF-FREEBSD-UMTX-OP, REF-WIN-WAITFORSINGLEOBJECT, REF-WIN-WAIT_ABANDONED
