# RFC-0118: Privilege bracketing + call-chain contexts (veto-only) (D-BRACKET)

Status: Draft  
Updated: 2026-03-07  
Decision node(s): **D-BRACKET** (new), D-REQCTX (adjunct), D-CAPSHELL (adjunct), D-PLUMB (adjunct)

## Summary
We want to eliminate a common real-world failure mode in “capability-ish” systems:

> **Confused deputy inside a process**: a library/helper runs with broad authority, and an untrusted caller induces it to use that authority on the caller’s behalf.

In a pure object-capability style you “just pass the capabilities,” but in practice:
- codebases accrete globals/singletons (network clients, file viewers, credential helpers),
- plugin ecosystems load third-party code into the same address space,
- compatibility layers provide familiar APIs that hide authority.

This RFC adds a *veto-only* ecosystem seam that is cheap to adopt and hard to bypass:

1) **D-BRACKET**: a user-space runtime pattern that makes *privileged capabilities* inaccessible by default when handling inbound requests (“borrowed mode”), unless code explicitly enters a **privileged block**.
2) **CH-CALLCHAIN v0**: a bounded, non-authoritative descriptor of “who called whom” for audit/debug and for *deny-only* routing/policy decisions.
3) **CH-REQCTX v1** (optional): extends request contexts to optionally reference a CH-CALLCHAIN digest.

Pinned v0 posture note: `docs/30-architecture/bracket-posture-v0.md` now freezes Phase 1 to a **borrowed-mode-by-default**, **task/request-local** runtime seam with **explicit exception-safe privileged blocks**, **bounded optional deny-only CH-CALLCHAIN metadata**, **no portable stack inspection/kernel enforcement**, and **no workflow/ACP surface**.

Kernel stance:
- no in-kernel stack inspection;
- no new privileged policy logic;
- everything is implementable as library/runtime conventions + tooling.

## Motivation
The classic **Confused Deputy** problem explains why capabilities were invented: ambient identity-based checks let a deputy be tricked into using its own authority. REF-CONFUSED-DEPUTY.

But even in a capability-based design, the same shape reappears when:
- an *internal* capability is reachable via a global singleton;
- a helper is reused across trust boundaries; or
- a plugin calls into trusted code that “helpfully” performs privileged effects.

Java’s security architecture addressed this with **stack inspection** plus explicit **`doPrivileged`** blocks: access checks intersect permissions along the call stack until a privileged boundary is reached. REF-JAVA-STACKINSPECT, REF-JAVA-ACCESSCONTROLLER, REF-JAVA-DOPRIVILEGED.

We do **not** want Java’s model wholesale (permissions, protection domains, and historical bypass hazards), but the core *engineering lesson* is valuable:
- **make privilege elevation explicit and scoped**, and
- make the default path *least-privilege by construction*, not by code review heroics.

## D-BRACKET: privilege bracketing in user-space runtimes

### Option 0 (default): no standard bracketing
- Pros: no new conventions.
- Cons: plugin/helper ecosystems drift toward ambient authority; hard-to-audit “why did this open the network?” incidents.

### Option 1 (recommended, optional): privileged caps are “dark” by default
A component runtime MAY classify some held capabilities as **privileged** (e.g., `NetAdmin`, `ExportAny`, `OpenOutsideView`, `KeyUse`).

When handling an inbound request in **borrowed mode**:
- privileged capabilities are **inaccessible** via the runtime’s standard introducers/singletons;
- only explicitly *lent* capabilities (passed in the request or explicitly derived from lent caps) are accessible.

To use privileged capability, code must enter an explicit **privileged block**:

```text
with_privileged(reason, scope) {
  ... privileged effects allowed here ...
}
```

Requirements:
- scoped: privilege is always dropped on exit (even on panic/exception) (cf. Java `doPrivileged` guarantees). REF-JAVA-DOPRIVILEGED.
- task/request-local dynamic scope: bracketing state must be bounded by the request/task scope rather than a mutable ambient global or plain unconstrained thread-local toggle; scoped-value / context-local mechanisms are acceptable implementation techniques, not new authority surfaces. REF-OPENJDK-SCOPEDVALUES. REF-PEP-567. REF-PY-CONTEXTVARS.
- veto-only: privilege bracketing can only **deny** access to capabilities or narrow behavior; it never grants new capabilities.
- transcript-visible (optional but recommended): entering privileged blocks in high-risk helpers SHOULD emit a log/receipt entry (often paired with CH-CAPDIFF) so “surprising privilege use” is explainable.
- no portable stack inspection: Phase 1 remains a user-space/runtime convention and deliberately declines kernel-enforced stack-walking or a new workflow/ACP/admin seam.

### “Borrowed authority” as the common case
For cross-component work we already prefer:
- pass handles/caps explicitly,
- keep routing/selection portalized (D-PLUMB),
- seal down after init (D-SEAL).

D-BRACKET makes the *in-process* experience match that philosophy.

## CH-CALLCHAIN v0 (descriptor)
Spec: `docs/30-architecture/call-chain-schema-v0.md`

CH-CALLCHAIN is:
- **non-authoritative** (no caps, no tokens, no secrets),
- **bounded** (small list of frames; closed enums),
- useful for audit/debug and for *deny-only* policy (e.g., “never route intent X if chain contains untrusted plugin Y”).

## CH-REQCTX v1 (optional)
Spec: `docs/30-architecture/request-context-schema-v1.md`

CH-REQCTX v1 adds:
- `call_chain_digest?: bytes32` referencing CH-CALLCHAIN.

Important: this does not turn contexts into authority.
- Call-chain metadata must not be used to **grant** authority.
- It may be used to **narrow/deny** (veto-only) in routing, logging, or local runtime policy.

## Threat model wiring
New abuse case:
- **AC-091: In-process confused deputy (library uses privileged caps on behalf of untrusted caller)**

## Assurance wiring (seed)
New invariants (optional):
- **I-BRACKET-1 (Borrowed-mode default, optional)**: privileged caps are inaccessible by default when servicing inbound requests unless a privileged block is active.
- **I-BRACKET-2 (Scoped privilege, optional)**: privileged blocks are lexically/dynamically scoped and always restore prior state on exit (including panics/exceptions).
- **I-CALLCHAIN-1 (Call chain is non-authoritative + bounded, optional)**: CH-CALLCHAIN contains no cap material; frames are closed+bounded; validation rejects unknown variants.

New proof obligations (seed):
- **PO-CALLCHAIN-VALIDATE**: CH-CALLCHAIN decoding/validation is canonical and total; bounds enforced; unknown variants/keys reject.
- **PO-BRACKET-SCOPE**: bracketing state cannot “leak” across tasks/requests; tests demonstrate privilege is revoked on all exits.

## Evidence plan
- **EVID-2026-118**: CH-CALLCHAIN v0 validator + CH-REQCTX v1 validator, plus a runtime harness demonstrating:
  - privileged caps are inaccessible in borrowed mode,
  - privileged blocks are scoped and exception-safe,
  - deny-only policy examples (router refuses a dangerous intent if call-chain shows untrusted plugin origin).

## Alternatives
- “Just pass capabilities” (pure object-capability discipline): ideal but often defeated by globals + legacy APIs.
- Mandatory kernel stack inspection: too entangled with scheduling/concurrency/proofs; avoid.
- Static analysis only: helpful, but runtime guardrails catch the messy reality.

## References
REF-CONFUSED-DEPUTY, REF-JAVA-EXTSECARCH, REF-JAVA-STACKINSPECT, REF-JAVA-ACCESSCONTROLLER, REF-JAVA-DOPRIVILEGED, REF-JAVA-ACCESSCONTROL-HARDEN2017.
