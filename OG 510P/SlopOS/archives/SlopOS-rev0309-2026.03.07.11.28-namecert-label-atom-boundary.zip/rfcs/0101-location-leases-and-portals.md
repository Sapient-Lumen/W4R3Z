# RFC-0101: Location leases via a portal (D-LOCLEASE)

Status: Draft  
Updated: 2026-02-26  
Decision node(s): **D-LOCLEASE**, D-PLUMB (adjunct), D-LEASE (adjunct), D-VOLITION/D-EXPLAIN (adjunct)

## Summary
Define a small, bounded location-access seam: a **location portal** (`portal.location`) that returns scoped location capabilities and emits a redaction-safe **CH-LOCLEASE v0** descriptor for audit/receipts.

Goal: location becomes *permissionable* and *capability-scoped* (coarse vs precise, foreground vs background, bounded cadence) without ambient global APIs.

## Motivation
Location is one of the highest-value privacy surfaces:
- Ambient, global location APIs become covert tracking channels.
- Long-lived/background location is especially sensitive.
- “Exact GPS” is rarely necessary for many common workflows.

Modern ecosystems have converged on explicit mediation:
- Android requires explicit location permissions and distinguishes foreground vs background access.
- Apple surfaces a **Precise Location** toggle to allow approximate location sharing.
- Desktop sandboxes increasingly use portals, including an explicit Location portal.

Greenfield advantage: make location *a portal workflow* from day one, so “default isolation” does not quietly dissolve.

## Design constraints
- **No ambient location constructors:** after init (D-SEAL), components cannot query location without an explicit location capability.
- **Coarse vs precise is explicit:** clients must request an accuracy class; policy may clamp downward.
- **Bounded + leased:** TTL and cadence are bounded, renewable, and revocable.
- **Phase 1 posture is intentionally narrow:** keep `portal.location` manual-only, coarse-first, and non-persistent; do not casually claim durable background `always` tracking or geofence wakeups.
- **Auditable and redaction-aware:** grants produce a CH-LOCLEASE digest; exports treat it as sensitive metadata.
- **No hidden authority:** location portal must not implicitly grant networking; any network use (Wi‑Fi/cell lookups) is accounted and policy-scoped.

## Proposal
### 1) `portal.location.*` family
Introduce a user-space **location portal** as part of D-PLUMB portal families:
- `RequestOneShot(accuracy, ttl, purpose)` → returns a `LocOneShot` capability
- `RequestUpdates(accuracy, ttl, cadence, purpose, background)` → returns a `LocStream` capability
- `RequestGeofence(spec, ttl, purpose, background)` → returns a `GeoFence` capability

The portal is responsible for:
- enforcing policy (foreground/background posture, user prompts, rate/TTL clamps)
- ensuring user-visible indicators for active continuous tracking (where applicable)
- producing a CH-LOCLEASE descriptor (digest) for receipts/logs

### 2) CH-LOCLEASE v0
Add **CH-LOCLEASE v0** (descriptor only; no raw coordinates):
- `kind`: oneshot | updates | geofence
- `accuracy`: coarse | precise
- provider set (gps/wifi/cell/ip/manual)
- TTL + update cadence bounds
- optional `background` posture
- geofence binding via `region_hash` (digest of canonical geofence spec bytes)

See: `docs/30-architecture/location-lease-schema-v0.md` and `docs/30-architecture/location-lease-posture-v0.md`.

### 3) Consent + indicators (policy-scoped)
### 3a) Phase 1 posture pin
- **manual-only v0**: no ACP kind in Phase 1; location requests remain explicit portal workflows.
- **coarse-first**: one-shot coarse requests are the expected default posture; precise remains purpose-bound and foreground-facing.
- **no persistent tracking claim**: `background="always"` and geofence wake/relaunch semantics remain reserved schema space, but A–D profiles should treat them as policy-denied until future RFC/evidence work justifies them.

Recommended posture:
- One-shot coarse requests MAY be policy-autoapproved for well-known intents (e.g., “weather near me”), but still produce receipts.
- Long-lived updates/geofences SHOULD require explicit consent (D-POWERBOX) and, in strict profiles, **fresh volition** (D-VOLITION).
- Continuous tracking SHOULD produce a non-spoofable UI indicator (shell-driven) and include renew/revoke events in transcript.

### 4) Interaction with D-NETLEASE
Location providers often rely on network lookups (Wi‑Fi databases, cell triangulation). This must not silently reintroduce ambient networking.

If D-NETLEASE is enabled:
- the location portal holds (or obtains) the required **network lease** for its provider operations,
- provider network use is metered and attributed to the portal/service, not the requestor,
- requestors do not obtain network authority as a side effect of location grants.

## Threat model impact
Add **AC-086** (Location service abuse): covert tracking, background surveillance, and metadata leakage via receipts/exports.

## Invariants (add)
- **I-LOCLEASE-1 (No ambient location, optional):** if D-LOCLEASE is enabled, location samples/geofences are obtainable only via explicit capabilities returned by the location portal; no ambient global location constructors exist after init.
- **I-LOCLEASE-2 (Bounds + separation, optional):** if D-LOCLEASE is enabled, location capabilities enforce CH-LOCLEASE bounds (ttl/cadence/accuracy class/background posture) and fail closed; location grants do not implicitly grant network authority.
- **I-LOCLEASE-3 (Grants are auditable, optional):** if D-LOCLEASE is enabled, grant/renew/revoke events are transcript-visible and can bind to CH-AUTHZ/CH-RECEIPT (and CH-VOL when required by policy).

## Proof obligations (add)
- **PO-LOCLEASE-VALIDATE (PLUMB/ENC):** if CH-LOCLEASE is used, decoding/validation is canonical and total; unknown variants/keys reject; bounds are enforced deterministically.
- **PO-LOCLEASE-ENF (PLUMB/UX):** if D-LOCLEASE is enabled, request paths enforce policy clamps, TTL/expiry, and cadence bounds; no bypass path provides location to unleased clients; continuous tracking implies indicators and revocation is deterministic.

## Evidence plan
Phase 0/1:
- validator/negative tests for CH-LOCLEASE (closed enums; bounds; kind-dependent fields)
- portal harness tests:
  - oneshot coarse returns samples only within TTL and returns no more after expiry
  - updates cadence clamps upward; rate cannot exceed declared bounds
  - background posture is enforced (requests reject or clamp based on profile)
  - receipts include CH-LOCLEASE digest; export policy redacts by default

Seed:
- **EVID-2026-104** — CH-LOCLEASE validator + portal harness (TTL/cadence clamps; background posture; export redaction; no implicit net authority)

## References (bibliography IDs)
- REF-XDG-PORTAL-LOCATION
- REF-ANDROID-LOC-PERMS
- REF-ANDROID-LOC-BACKGROUND
- REF-APPLE-LOCATION-PRECISE
- REF-GEOCLUE-DBUS
