# RFC-0077: Tracepoint descriptors and fielded traces (D-TPROBE)

Status: draft
Last updated: 2026-02-25

## Problem
CH-TRACE v0 intentionally keeps trace events minimal: `(probe id, args[])`. This keeps validation and capture cheap, but leaves three sharp edges:

1) **Tooling ambiguity:** without a pinned mapping, consumers can misinterpret `args[i]` (off-by-one, wrong type assumptions, schema drift).
2) **Safe predicates need field names:** CH-TPRED predicates name fields; we need an authoritative table mapping `field -> index/type` to validate them.
3) **Redaction needs semantics:** export policy (CH-OBSPOL) can say “no raw addrs”, but without field semantics it’s easy to accidentally export sensitive values.

Existing systems pair trace event streams with an event schema table:
- Linux trace events expose per-event `format` descriptions and allow fielded filters. (REF-LINUX-TRACE-EVENTS; REF-LINUX-TRACE-EVENT-FORMAT; REF-LINUX-TRACE-FILTER)
- LTTng similarly supports fielded filtering on event payload/context. (REF-LTTNG-FILTER)
- DTrace has named probes with stable arguments/predicates but keeps programmability out of the kernel in constrained modes. (REF-DTRACE; REF-DTRACE-PREDICATES)

We want the ergonomics of fielded tooling **without** building an in-kernel scripting system.

## Decision: D-TPROBE (optional)
If D-TPROBE is enabled, builds/profiles MUST ship a pinned **tracepoint descriptor manifest**:

- **CH-TPROBE v0**: a bounded schema table mapping probe IDs to ordered field lists with types and redaction classes.

D-TPROBE is a dependency for “pleasant” D-TPRED usage. Without it, CH-TPRED can only reference positional fields (which we intentionally avoid).

### Non-goals
- No in-kernel scripting language.
- No dynamic probe creation in production profiles (a dev-only extension may exist later).
- No runtime “best-effort” schema guessing: mismatches must fail closed.

## Design
### CH-TPROBE v0 manifest
A CH-TPROBE manifest lists probe descriptors:
- `probe.id` matches `CH-TRACE.probe`.
- `probe.fields[i]` defines the meaning of `CH-TRACE.args[i]`.
- Each field declares:
  - `ty` (closed enum aligned with CH-TRACE value variants)
  - `redaction` (minimum classification: public/sanitized/sensitive)
  - optional `sem` tag to support policy constraints (e.g., `addr`, `pid`, `irq`).

#### Recommended `sem` tags (correlation + privacy ergonomics)
To make traces/inspect snapshots/support bundles *correlatable* without changing CH-TRACE v0, we standardize a small set of semantics tags that tooling can recognize:

- `corr_id` — a per-request/activity correlation identifier (often `u64`)
  - inspiration: ETW “activity ID / related activity ID” style correlation.
- `trace_id` — distributed trace identifier (recommend `small_bytes` length 16)
- `span_id` — span identifier (recommend `u64` or `small_bytes` length 8)
- `parent_span_id` — parent span identifier (same type guidance as `span_id`)

Notes:
- These map cleanly onto OpenTelemetry’s TraceId/SpanId and W3C Trace Context propagation, but we do **not** require any particular propagation mechanism inside the OS.
- Export/snapshot tooling SHOULD treat correlation identifiers as *not secrets* by default, but still subject to policy (they can be high-cardinality join keys).

Refs: REF-MS-ETW-ACTIVITYID, REF-OTEL-TRACE-API, REF-W3C-TRACECONTEXT.

The manifest is bounded and canonically encoded (I-ENC-1; ADR-0003).

### Binding and distribution
- The active D-TRACE profile pins **exactly one** CH-TPROBE digest for the trace stream(s) it exports.
- If traces are exported out-of-band, the exporter SHOULD include the CH-TPROBE digest alongside any trace artifacts (or include the manifest itself) so offline consumers can interpret traces correctly.
- Tooling MUST treat any schema bytes as untrusted unless the digest matches the pinned reference.

### Enforcement points
1) **Predicate validation** (D-TPRED):
   - CH-TPRED validation consults CH-TPROBE.
   - Unknown probe IDs/field names reject.
   - Operator/type mismatches reject.
2) **Emitter agreement**:
   - Emitters must keep probe IDs and argument order consistent with the pinned manifest.
   - Mismatches are treated as a bug; in safety profiles, drop and surface a bounded diagnostic counter rather than exporting ambiguous data.
3) **Export policy** (D-OBSPOL):
   - Exporters apply CH-OBSPOL constraints using field `redaction`/`sem`.
   - Example: `sem=addr` fields are omitted/zeroed unless policy explicitly permits raw addrs.

## Safety hooks
### Invariants
- Add **I-TPROBE-1 (Trace schema is pinned + non-ambiguous, optional)**: if D-TPROBE is enabled, trace interpretation is bound to a pinned CH-TPROBE digest and field mapping is not guessed.

### Proof obligations
- **PO-TPROBE-VALIDATE**: CH-TPROBE decode/validation is total/canonical and bounded.
- **PO-TPROBE-MATCH**: event emission/export enforces descriptor↔event agreement; schema mismatches fail closed.

### Threat-model note
Schema confusion can become an exfiltration vector (“label this sensitive thing as public and export it”).
Add AC-063 to capture the abuse and document mitigations.

## Interactions
- **D-TRACE**: CH-TRACE stays minimal; D-TPROBE supplies the field mapping.
- **D-TPRED**: predicates become robust and tool-friendly because they name fields rather than positions.
- **D-TRACEPROC**: processors can publish stable fielded outputs and can validate inputs against the pinned schema.
- **D-RR**: trace schemas are observations, not replay inputs; the pinned digest can still be captured for offline decoding.

## Open questions / future work
- Dev-only “user events” (user-space tracepoints) with per-process CH-TPROBE subsets (inspired by Linux user_events), while keeping production profiles closed/declared.
- A `probe_schema_digest` field in future observation/bundle formats (CH-OBS / CH-SNAPSHOT v1) to make trace decoding self-contained without out-of-band agreement.
