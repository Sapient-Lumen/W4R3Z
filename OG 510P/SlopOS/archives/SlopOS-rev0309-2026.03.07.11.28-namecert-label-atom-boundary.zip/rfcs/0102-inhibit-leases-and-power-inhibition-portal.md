# RFC-0102: Inhibit leases + power/idle inhibition portal (D-INHIBITLEASE)

Status: Draft  
Updated: 2026-02-26  
Decision node(s): D-INHIBITLEASE, D-LEASE, D-PLUMB (adjunct), D-VOLITION (optional), D-JOBS (adjunct)

## Summary
Define a standard, capability-safe pattern for **preventing session transitions** (idle, suspend, logout/shutdown) that:
- avoids ambient “keep-awake” APIs,
- keeps policy in user space (portal service), and
- makes long-lived inhibition **bounded, visible, attributable, and revocable**.

This RFC introduces **CH-INHIBITLEASE v0**, a bounded, redaction-safe descriptor for an inhibition grant.
Phase 1 posture is now pinned: inhibit remains a **manual-only, close-to-release** workflow and does not create durable or future-dated keep-awake state.

## Motivation
Keeping a machine awake is a powerful authority:
- it can drain battery and degrade user experience,
- it can be used as a persistence/availability attack (never sleep),
- it becomes a covert-channel surface when “idle state” becomes app-observable.

Production systems converged on “inhibit locks” as explicit objects:
- desktop: systemd/logind inhibitor locks to block or delay sleep/shutdown/idle transitions,
- sandboxed desktop apps: XDG portals’ **Inhibit** workflow,
- mobile: Android wake locks (with strong battery caveats).

Greenfield advantage: bake in the *inhibit-as-leased-workflow* pattern so:
- media players can keep the screen on during playback,
- updaters can prevent reboot mid-transaction,
- apps can’t silently hold the device awake forever.

## Non-goals
- Designing a full power management policy engine.
- Providing per-device DVFS/power profile controls (that is a different seam).
- Making CH-INHIBITLEASE an authorization token.

## Design

### Portal model
A user-space **inhibit portal** (e.g., `/svc/portal/inhibit`) mediates requests and returns an **InhibitLease** handle.

Requests specify:
- `what`: a closed set of transitions to inhibit (idle, suspend, logout, shutdown),
- `mode`: `delay` or `block` (see below),
- `reason`: user-visible string (bounded),
- optional `ttl`: requested duration (portal clamps),
- optional `scope`: session vs system (profile-gated).

Closing the returned handle releases the inhibition.
Phase 1 is **current-session scoped**: holder death, disconnect, portal-enforced expiry, session end, or reboot releases the inhibition fail closed; there are no future-dated or reboot-carried inhibit records.

### Modes: delay vs block
We adopt the systemd distinction:
- `delay`: the transition may proceed after a bounded grace period (default for untrusted apps).
- `block`: the transition is prevented until the lease is released (reserved for privileged/system components under policy).

Policy MUST clamp:
- maximum TTL and renew cadence,
- which `what` values are allowed for a given requester,
- whether `block` is allowed at all.

### Visibility + audit
In strict profiles:
- active `idle`/`suspend` inhibits SHOULD be visible via a non-spoofable indicator in the secure UI shell (D-UICAP).
- portal emits a CH-INHIBITLEASE descriptor; logs/receipts reference it by digest.

### Composition with D-JOBS
If D-JOBS is enabled, the job portal MAY request short inhibition while a job is actively executing (e.g., “finish this upload before suspend”), but:
- inhibits must be bounded to the job’s runtime bound,
- jobs must not create indefinite keep-awake behavior,
- jobs must not pre-arm a future inhibit or recreate one after downtime as replay debt.

### CH-INHIBITLEASE v0
CH-INHIBITLEASE is a bounded descriptor for audit/receipts; it contains **no capability secrets**.

See: `docs/30-architecture/inhibit-lease-schema-v0.md`.

## Registries impacted
- Add **CH-INHIBITLEASE v0** to the schema registry.
- Add invariants:
  - **I-INHIBIT-1 (No ambient inhibit, optional):** inhibiting idle/suspend/logout/shutdown requires an explicit lease handle minted by the portal; no ambient “keep-awake” constructors exist after init.
  - **I-INHIBIT-2 (Bounds + renewal clamps, optional):** leases enforce TTL and mode constraints (delay vs block) and fail closed on violations; renewals are rate-limited and policy-clamped; live inhibits do not survive process death, session end, reboot, or future-dated carryover.
  - **I-INHIBIT-3 (Visibility + transcript, optional):** active inhibits are transcript-visible (grant/renew/release), and long-lived inhibits require user visibility and (in strict profiles) consent/volition binding.
- Add proof obligations:
  - **PO-INHIBIT-VALIDATE:** CH-INHIBITLEASE decoding/validation is canonical, total, and fail-closed.
  - **PO-INHIBIT-ENF:** portal policy clamps (TTL/mode/what) are enforced; no bypass path can hold inhibits without a lease; manual-only v0 is preserved; future-dated/persistent inhibit records are rejected; visibility/receipts follow profile rules.
- Add abuse case:
  - **AC-087:** inhibit misuse (battery drain, “never sleep” persistence, transition DoS).
- Add evidence seed:
  - **EVID-2026-105** (schema validator + portal harness plan).

## Evidence plan
E0 (EVID-2026-105):
- validator golden tests: closed enums; bounds; unknown keys reject; canonical decode.
- portal harness:
  - untrusted app can only request `delay` for `idle`/`suspend` with clamped TTL,
  - privileged updater can request `block` for `shutdown`/`reboot` only under policy,
  - lease expiry forces release deterministically,
  - renewal clamp prevents “infinite keep awake” loops,
  - indicator/receipt behavior matches profile.
- negative tests:
  - no ambient inhibit syscall/API after init,
  - long-lived inhibit requires explicit UI posture (indicator; optional consent),
  - “block” mode denied for non-allowlisted requesters.

## References
Refs: REF-XDG-PORTAL-INHIBIT, REF-SYSTEMD-INHIBITOR-LOCKS, REF-SYSTEMD-INHIBIT-MAN, REF-ANDROID-WAKELOCK, REF-ANDROID-SET-WAKELOCK.
