# RFC-0073: Trace predicates + prefiltering (D-TPRED)

Status: Draft  
Updated: 2026-02-25  
Decision node(s): D-TRACE, D-TRACEPROC, **D-TPRED**, D-ENC

## Summary
Add a **bounded, non-Turing-complete** trace predicate format (**CH-TPRED v0**) and thread it through trace enablement/processing so operators can **filter near the source** without importing an in-kernel scripting system.

This is explicitly the “juicy” part of DTrace/eBPF-style workflows we want *without* the large verifier/VM/tuning surface:
- **DTrace** uses predicates to decide whether a probe clause runs.
- Linux tracing subsystems (trace events / ftrace) and LTTng support **boolean filter expressions** evaluated against event fields.

Our stance:
- keep the privileged core mechanistic (static tracepoints + bounded filtering)
- keep programmability in user space (D-TRACEPROC), but allow **cheap prefilters** when raw event rates would otherwise be impractical.

## Motivation
Without prefiltering, two failure modes appear in practice:
1) turning on a high-rate probe floods buffers and forces “export everything” (bad for performance and for least disclosure),
2) operators fall back to privileged ad hoc tooling because the supported path is too blunt.

Greenfield advantage: define a tiny predicate contract now, so we can prove/validate *boundedness* and avoid the “debug subsystem became an ambient covert channel” trap.

## Design constraints
- **No in-kernel general scripting.** Filtering is boolean predicates over declared event fields.
- **Total, fail-closed validation.** Unknown fields/types/operators reject deterministically.
- **Bounded cost.** A predicate has a max node count; evaluation has a max instruction budget.
- **No new authority.** Filters cannot create capabilities, and must not influence privileged control flow beyond “emit vs drop” (I-TRACE-1).

### Field schema table (recommended companion: D-TPROBE)
CH-TPRED predicates name event fields; validators need an authoritative mapping from `(probe, field)` to `(index, type)`.
In this archive, that mapping is supplied by **CH-TPROBE v0** when **D-TPROBE** is enabled (see RFC-0077).
If D-TPROBE is not enabled, D-TPRED implementations MUST still use a closed, per-build schema map and reject unknown fields/types deterministically; avoid “positional” predicates in production profiles.

## Proposal
### 1) CH-TPRED v0 (Trace Predicate)
Define **CH-TPRED v0** as a canonical CBOR-encoded expression tree:
- boolean composition: `and/or/not`
- comparisons over event fields: `== != < <= > >=`
- bounded “set membership” over small constant lists (`in`)
- optional `exists` over optional fields

No loops, no recursion at runtime, no unbounded memory.

### 2) Where predicates run (profile choice)
D-TPRED is a profile switch that decides **where** predicates are evaluated:
- **none:** no predicates; only coarse enable masks (baseline)
- **portal-only:** trace portal evaluates predicate after buffering (safe, minimal privileged footprint)
- **source-prefilter (optional):** a tiny interpreter runs at the tracepoint site (kernel or trusted trace emitter) to drop events before they hit shared buffers

The source-prefilter mode is the “performance knob,” but it must satisfy the same boundedness obligations.

### 3) Trace processor requests gain an optional filter reference
Add **CH-TRACEPROC v1** (keeping v0 for compatibility) to let callers supply an optional predicate reference for each processor installation/update:
- a `filter` points at a CH-TPRED digest
- the portal may apply it at source or at the portal depending on policy/profile

### 4) Tooling posture
- Trace UX compilers can translate human-friendly filter syntax into CH-TPRED.
- Deterministic validators + round-trip tests must exist for CH-TPRED.
- If D-RR is enabled, predicate digests should be recorded alongside captures so replay tooling can reproduce “what was dropped.”

## Registries impacted
- **Schema:** add **CH-TPRED v0** and **CH-TRACEPROC v1**.
- **Decision map:** add **D-TPRED** under tracing.
- **Invariants:** add **I-TPRED-1**.
- **Proof obligations:** add **PO-TPRED-VALIDATE**, **PO-TPRED-BOUNDS**, **PO-TPRED-NOSTATE**.
- **Abuse cases:** add **AC-066** (predicate abuse / filter-DoS).

## Invariants (add)
- **I-TPRED-1 (Trace predicate safety, optional):** if D-TPRED is enabled, any predicate used for prefiltering is validated as total/closed/bounded; evaluation cannot read memory outside the declared event record, cannot allocate unboundedly, and can only affect whether an event is emitted.

## Proof obligations (add)
- **PO-TPRED-VALIDATE (ENC/OBS):** CH-TPRED decoding + validation is deterministic; unknown operators/fields/types reject.
- **PO-TPRED-BOUNDS (OBS):** predicate evaluation cost is bounded (node count + instruction budget); overflow/fuel exhaustion is deterministic and fail-closed.
- **PO-TPRED-NOSTATE (OBS):** predicate evaluation is observational; it cannot mutate privileged state except bounded trace buffers.

## Threat-model impact
New/changed risks:
- predicates used to create a covert timing channel (still under D-SIDECH; minimize by keeping evaluation simple and predictable)
- predicate validation bugs or complexity bombs used for DoS (AC-066)

Controls:
- strict bounds + closed operators
- optional portal-only evaluation mode
- explicit metering/budgeting for trace processors remains in D-TRACEPROC

## Evidence plan
Phase 0/1:
- property tests: parse→canonicalize→hash stability; equivalence tests against a reference evaluator
- fuzz: predicate decoder/validator
- stress: worst-case predicate under bounds; ensure deterministic failure

Phase 2:
- bounded model-check of evaluation fuel semantics and “no state mutation” property

## References (bibliography IDs)
- REF-DTRACE; REF-DTRACE-PREDICATES; REF-LINUX-TRACE-EVENTS; REF-LINUX-TRACE-EVENT-FORMAT; REF-LINUX-TRACE-FILTER; REF-LTTNG-FILTER
