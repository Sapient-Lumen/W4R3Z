# RFC-0091: SBOM artifacts as pinned, digest-bound evidence (CH-SBOM) (D-SBOM) (optional)

Status: Draft  
Last updated: 2026-02-26

Goal: make Software Bills of Materials (SBOMs) **usable and non-misleading** in a capability-first, artifact-first OS:
- SBOMs are **content-addressed artifacts** (CH-SBOM) that can be signed/logged/attached to releases.
- SBOMs are **bound to what actually ran/installed** (deployment root digest or component digest), so audits do not depend on filenames/paths.
- The privileged core stays agnostic: SBOM generation/verification is user space and/or offline tooling.

This RFC is deliberately *not* “SPDX inside the kernel.” Instead:
1) standardize a **small normalized SBOM** for our ecosystem (CH-SBOM v0), and
2) allow linking to a full external SBOM document (SPDX/CycloneDX) via CH-AREF when needed.

## Problem
SBOM adoption often fails in practice for reasons that are avoidable with a greenfield design:
- SBOMs drift from the deployed bits (different build, different configuration, post-install mutation).
- SBOMs identify components by names/paths rather than stable identities.
- SBOMs become huge and leak sensitive metadata when exported naively.
- Vulnerability triage becomes “noise” without a way to say “not affected” (VEX-style statements).

We already have strong primitives for “what ran” (CH-BOOT, CH-UPD, CH-PROV, CH-DERIV, content-addressed stores). The missing seam is a *standard SBOM artifact* that can be:
- referenced from CH-UPD/CH-BOOT as a non-authoritative **audit attachment**,
- checked for **subject binding** (the SBOM describes *this* deployment/root), and
- safely exported under CH-OBSPOL (bounded fields, optional redaction).

## Prior art (high-signal)
- **NTIA/CISA SBOM minimum elements**: practical framing of “what must be present” for interoperability and risk management. (REF-NTIA-SBOM-MIN2021; REF-CISA-SBOM-MIN2025)
- **SPDX**: widely deployed SBOM exchange format (ISO/IEC 5962:2021 lineage). (REF-SPDX-SPEC; REF-SPDX-SPECS)
- **CycloneDX**: BOM standard with strong supply-chain + risk metadata support (ECMA-424). (REF-CYCLONEDX-OVERVIEW)
- **VEX/OpenVEX**: complementary vulnerability-exploitability statements to reduce false positives. (REF-CISA-VEX-MINREQ; REF-OPENVEX-SPEC)

Lesson we adopt: SBOM usefulness depends on **binding to a specific, immutable subject**, and keeping exports **bounded**.

## Decision
Introduce an optional decision seam:
- **D-SBOM**: the system may publish and consume **CH-SBOM v0** artifacts as digest-bound evidence attached to releases/boots.

This integrates with:
- **D-ATOMICUPD**: include `role = "sbom"` in CH-UPD `artifacts[]`.
- **CH-PROV / D-TLOG**: SBOM digests can be logged/anchored alongside provenance artifacts and transparency anchors.
- **D-OBSPOL**: exporting SBOMs is policy-scoped and may redact sensitive metadata.

## Design summary
### 1) CH-SBOM is small and normalized
CH-SBOM v0 is a bounded inventory that:
- binds to a **subject digest** (deployment root digest or component digest),
- lists components with stable identifiers (prefer digest/build-id; allow optional names/purls),
- optionally links to a full SPDX/CycloneDX document via CH-AREF.

### 2) Binding rules (avoid “SBOM drift”)
If a CH-SBOM digest is referenced from:
- **CH-UPD `artifacts[]`** with role `sbom`: tooling/verifiers MUST check `sbom.subject.digest == upd.target_root_digest` (or a profile-defined mapping).
- **CH-BOOT `artifacts[]`** with role `sbom`: tooling/verifiers MUST check `sbom.subject.digest == boot.root_digest` (or the active deployment root digest).

This does *not* require proving the SBOM lists every byte in the closure (that can be a later, higher-assurance gate). It *does* ensure the SBOM is not about something else.

### 3) Export posture
CH-SBOM may contain metadata that is sensitive in some deployments (supplier names, package versions). Therefore:
- exports are governed by CH-OBSPOL tiers.
- profile defaults SHOULD permit exporting only the normalized SBOM and may drop `meta` or `external_ids`.

### 4) VEX is separate and optional
VEX (exploitability statements) is intentionally a **separate** artifact from inventory so it can evolve independently. If used, see RFC-0092 (D-VEX / CH-VEX). CH-SBOM v0 remains focused on “inventory.”

## CH artifacts
- **CH-SBOM v0** (new): see `docs/30-architecture/sbom-schema-v0.md`.

## Invariants (additions)
- **I-SBOM-1 (SBOM subject binding, optional)**: if a CH-SBOM is referenced from a boot/update/provenance context, its `subject.digest` MUST match the referenced subject digest (deployment root / component) per the chosen profile mapping; mismatches are treated as non-compliant.
- **I-SBOM-2 (Stable component identity, optional)**: CH-SBOM component entries MUST include a stable identifier (digest or build-id) when available; human-readable identifiers (names/versions/purl) are non-authoritative and may be redacted on export.

## Proof obligations (additions)
- **PO-SBOM-VALIDATE**: CH-SBOM v0 decoding/validation is total + canonical; bounds enforced; unknown variants reject deterministically.
- **PO-SBOM-BIND**: when referenced by CH-UPD/CH-BOOT artifacts, SBOM subject binding is checked deterministically (per I-SBOM-1) and mismatches fail closed for SBOM-dependent workflows.

## Abuse case tie-in
- **AC-078**: SBOM injection / mismatch (misleading audits, “SBOM says fixed” while bits are not; or SBOM exfil via oversized metadata).

## Evidence plan (tight)
Phase 0/1:
- schema validator golden tests + negative tests (bounds, enum closure, unknown fields) (PO-SBOM-VALIDATE)
- binder tests:
  - match: `sbom.subject.digest == upd.target_root_digest`
  - mismatch: reject deterministically and record a stable error code (PO-SBOM-BIND)
- CH-OBSPOL export tests: ensure redaction rules are honored and exports remain bounded.

Phase 2:
- optional closure-check experiments (proof that listed component digests are a subset of the deployment tree) for one build profile.

## Notes / open questions
- We should keep CH-SBOM normalized and small. If richer fields are needed (licenses, pedigree), attach a full SPDX/CycloneDX document via CH-AREF.
- VEX (exploitability statements) should be a separate CH-* artifact so it can evolve independently of inventory.

## References
REF-NTIA-SBOM-MIN2021, REF-CISA-SBOM-MIN2025, REF-SPDX-SPEC, REF-SPDX-SPECS, REF-CYCLONEDX-OVERVIEW, REF-CISA-VEX-MINREQ, REF-OPENVEX-SPEC.
