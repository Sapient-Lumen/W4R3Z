# RFC-0109: Flight recorder buffers + incident capture triggers (D-FLIGHTREC)

Status: Draft  
Updated: 2026-02-27  
Decision node(s): **D-FLIGHTREC**, D-INSPECT (adjunct), D-OBS (adjunct), D-OBSPOL (adjunct), D-TRACE (adjunct), D-RR (adjunct), D-QUIESCE (adjunct), D-ENC

## Summary
Many “support bundle” workflows fail at the worst moment: **after** a crash, hang, or reboot.
Teams then discover they needed the *last 30–120 seconds* of:
- structured logs (CH-LOG / CH-OBS),
- selected traces (CH-TRACE), and
- key state snapshots (CH-INSPECT),

…but only had “current state” or only had unbounded logs (too large, too sensitive, too slow).

This RFC proposes an optional, bounded seam:
- **D-FLIGHTREC**: a capability-gated **flight recorder** retention substrate that keeps *recent history* in bounded ring buffers and can assemble an **incident capture** (typically a CH-SNAPSHOT bundle) when triggered.

The intent is to make “capture what just happened” reliable, bounded, and auditable—without turning observability into ambient exfiltration.

## Motivation
Prior art converges on the same idea with different shapes:
- systems keep **circular buffers** in memory (or persistent RAM) so the “dying breath” survives a crash/reboot (Linux pstore/ramoops),
- tracing stacks support **buffering-mode** sessions for “keep last N seconds” (ETW),
- logging subsystems do **rate limiting + rotation** and distinguish volatile vs persistent storage (journald),
- mobile/desktop ecosystems ship a “bugreport/sysdiagnose” style bundle that includes “recent logs” plus state (Android bugreport, Apple sysdiagnose).

We already have:
- D-INSPECT (structured snapshots),
- D-OBSPOL (export policy-as-data),
- D-TRACE + D-TPRED (safe tracing),
- D-RR (optional record/replay bundles),

…but we do not yet standardize the **retention ring + trigger** seam that makes incident capture predictable.

## Goals
- **Bounded retention**: keep “recent history” without unbounded disk/memory growth.
- **Explicit authority**: storing and exporting sensitive captures is capability-gated; “auto-export” is not ambient.
- **Policy-bound contents**: incident captures obey CH-OBSPOL unless an explicit higher-grade workflow grants broader scope.
- **Composable triggers**: crash, watchdog, manual operator request, or test harness triggers all use the same contract.
- **Works with partial failure**: capture should still happen if the crashed component cannot cooperate.

## Non-goals
- A general DLP engine (we rely on CH-OBSPOL bounds and explicit workflows).
- “Perfect secrecy” claims (observability remains an exfiltration surface; we bound + gate it).
- A mandatory always-on system-wide recorder for all profiles.

## Design
### 1) Retained streams are explicit, typed, and bounded
A flight recorder retains *selected* observation streams (not “everything”):
- `log` (structured log/obs records)
- `trace` (selected tracepoint streams)
- `inspect` (lightweight periodic or on-trigger snapshots)
- optionally, `rr` (record/replay event streams at chosen scope)

Retention is configured by a pinned, bounded policy artifact:
- **CH-FLIGHTPOL v0** (`docs/30-architecture/flight-recorder-policy-schema-v0.md`)

CH-FLIGHTPOL specifies per-stream bounds such as:
- max bytes (ring capacity),
- max segment count,
- maximum age (optional; best-effort bound based on the referenced clock kind),
- persistence mode: `volatile` (RAM) or `persistent_local` (bounded store) and an optional `crash_survivor` region (pstore-like).

Design stance:
- default profile keeps only volatile rings (low risk, high utility)
- persistent retention is opt-in and must be explicitly scoped and size-bounded

### 2) The recorder is a user-space collector, not a privileged feature dump
A user-space “archivist/collector” component:
- receives observation events (via IF-OBS / D-TRACE export paths),
- applies CH-TPRED prefilters and CH-OBSPOL redaction rules where applicable,
- writes to the configured rings and maintains bounded indices.

The privileged core:
- MAY provide minimal primitives for bounded shared memory rings (D-IOBUF) and waitable signals (D-WAITSET),
- MUST NOT embed a scripting VM or unbounded policy engine.

### 3) Triggers assemble incident captures (usually CH-SNAPSHOT)
On a trigger (crash, watchdog, operator request), the collector assembles an incident capture:
- baseline output: a **CH-SNAPSHOT** bundle manifest referencing:
  - recent retained segments from each enabled stream,
  - a “now” CH-INSPECT snapshot for key components,
  - crash capsule (CH-CRASHCAP) when applicable,
  - selected pinned config/build identities (digests only).

Trigger kinds (closed set, v0):
- `component_crash` (from supervisor/crash capsule pipeline),
- `watchdog_trip` (from health checks),
- `operator_request` (explicit capability),
- `test_harness` (dev-only).

Important: trigger does **not** imply export off-device. Export/sharing is a separate, capability-gated workflow (D-EXPLAIN + D-OBSPOL).

### 4) Optional crash-survivor buffer (pstore-like) for “last gasp”
For profiles that need post-reboot visibility (early bring-up, embedded), allow a small reserved region:
- used only for a minimal “panic log” and a bounded “last N events” record,
- read out by the next boot and folded into CH-SNAPSHOT.

This is optional and should be treated as sensitive: it can capture secrets if policy is careless.

### 5) Interaction with D-QUIESCE and D-RR
- If D-QUIESCE is enabled and the trigger is `operator_request`, the collector MAY request cooperative quiesce before taking a “now” snapshot, to obtain a cleaner cut.
- If D-RR is enabled, the flight recorder MAY retain the last N seconds of the RR stream (bounded) to make “replay the incident window” possible, but only if the active CH-OBSPOL/profile allows it.

## Security and privacy notes
- D-FLIGHTREC increases data-at-rest exposure; do not enable persistent retention without a clear threat model and CH-OBSPOL scope.
- Redaction is not optional for export; CH-OBSPOL remains the primary gate.
- “Auto-capture on crash” should default to **local-only**, with explicit user/operator authorization required for export.

## Invariants / proof obligations (seed)
- I-FLIGHT-1..3 (bounded retention, explicit capture/export authority, no scope amplification beyond policy).
- PO-FLIGHT-BOUND, PO-FLIGHT-ACCESS (registries).

## Evidence plan (seed)
- **EVID-2026-112**: a prototype collector that:
  - sustains a high-rate log/trace stream while respecting ring bounds,
  - deterministically drops/rotates under overload,
  - produces a CH-SNAPSHOT on crash trigger with verifiable included segments,
  - shows that export is impossible without the correct capabilities/policy.

## References
Refs: REF-LINUX-RAMOOPS, REF-LINUX-PSTORE, REF-MS-ETW, REF-SYSTEMD-JOURNALD, REF-ANDROID-BUGREPORT, REF-APPLE-SYSDIAGNOSE.
