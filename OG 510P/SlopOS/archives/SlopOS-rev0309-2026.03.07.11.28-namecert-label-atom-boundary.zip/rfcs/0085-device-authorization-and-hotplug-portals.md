# RFC-0085: Device authorization and hotplug portals (D-DEVGUARD)

Status: Draft  
Owner: —  
Updated: 2026-02-25  
Decision node(s): D-DEVGUARD, D-DRVDOM, D-IOLEASE, D-DMA, D-VOLITION  
Profiles: optional; **default deny-by-default** for hotplug devices; no auto-attach unless explicitly configured as data

## Summary
Add an **adoptable** device posture for hotplug peripherals (USB / Thunderbolt / PCIe hotplug) that makes *device access* an explicit, transcript-visible, **revocable** capability transfer.
The design couples:
- a **device manager** (user space) that owns enumeration + policy decisions,
- **driver hosts/domains** (D-DRVDOM / RFC-0083) that hold I/O resource authority,
- and a **portal** workflow (D-VOLITION) for user-approved attach/detach.

Optionally, introduce a small, pinned policy schema (**CH-DEVGUARD v0**) for deterministic authorization rules (USBGuard-like) and for automation that is still **veto-only**.

## Motivation
Peripherals are a practical attack surface:
- **malicious USB firmware** can present as arbitrary device classes (BadUSB-like attacks), bypassing “scan the files” defenses (REF-GOODUSB-ACSAC15).
- **PCIe-tunneling links** (Thunderbolt/USB4) can enable DMA-class compromise if IOMMU protection is missing or misconfigured; some mitigations are OS+firmware dependent and do not cover pre-OS boot (REF-THUNDERSPY-REPORT, REF-WIN-KDMA).

A greenfield capability OS should not repeat the “udev grants the world” pattern. The ergonomic target is Qubes-like: **untrusted devices live in a dedicated domain**; attaching a device to a workload domain is explicit and reversible (REF-QUBES-USB).

## Integration seam / privileged impact (keep small)
Minimal privileged mechanisms (most already required by D-DRVDOM/D-IOLEASE):
- a trusted **IOMMU mapping primitive** for DMA containment (D-DMA / I-DMA-1) and the ability to refuse exposure if the platform cannot meet the profile’s DMA assumptions.
- capability objects for **IO resources** (MMIO/PIO/IRQ/DMA mapping) and for **lease grants** (D-IOLEASE, CH-IOLEASE).
- an event source for **hotplug notifications** to the device manager (can reuse oneway/pulse-style oneway notifications (see RFC-0026)); if D-SKB is enabled, the same event is recorded as CH-HWEVENT for audit and SKB epoching (RFC-0018).

Everything else stays in user space:
- device policy evaluation (CH-DEVGUARD),
- attach/detach UX,
- device-class mediation (e.g., “USB storage mount portal”),
- driver host lifecycle and recovery.

## TCB delta / `unsafe` delta (make it explicit)
- New trusted components (if enabled):
  - Device manager (user space; policy + enumeration; not in the kernel TCB but in the “system TCB” for some claims).
  - Driver manager / I/O resource authority holder (already implied by D-DRVDOM).
- TCB size notes:
  - Keep privileged core agnostic: it enforces DMA/IO caps but does not interpret USB descriptors or policy rules.
- New or expanded `unsafe` obligations:
  - none in-kernel beyond existing IOMMU/MMIO/IRQ setup obligations (the existing unsafe obligations for IOMMU/MMIO/IRQ setup in `docs/20-assurance/unsafe-obligation-registry.md`).
  - device manager parsing of device descriptors is hostile-input surface; treat as fuzz target and sandboxable.
- New implicit dependencies to avoid:
  - do not rely on “device names” or global devfs paths as authority; names are views.

## Design

### 1) Authority model
- A physical device *exists* only as an **enumeration fact** plus (optionally) a *quarantined* handle held by the device manager/driver domain.
- A workload domain obtains device authority only via explicit grants:
  - either a **high-level mediated service** (recommended default; e.g., “scan” or “import photos” without raw device),
  - or a **device lease** (D-IOLEASE) that grants bounded queue/MMIO/DMA/IRQ authority.

### 2) Hotplug pipeline (default deny)
1. Hotplug event → device manager receives: `{bus, port_path, vid/pid, class, serial_hint?, topology}`.
   - If D-SKB is enabled: mint a **CH-HWEVENT v0** (`device_added`) record and advance the SKB fact epoch (RFC-0018).

2. Device manager consults CH-DEVGUARD policy:
   - If decision is deny: device stays unassigned; only inventory metadata is visible (policy-controlled).
   - If decision is allow-to-driver-domain: device is bound to a driver host/domain but not attached to any workload.
   - If decision is allow+autoattach: device is attached to a named target **only if** the policy entry explicitly permits auto-attach and the target’s profile allows it.
3. Any attach/detach produces a CH-LOG record referencing:
   - digest(CH-DEVGUARD) + matched rule id (if any),
   - `{epoch, event_seq}` + digest(CH-HWEVENT) (if D-SKB/epoching is enabled),
   - digest(CH-IOLEASE) if a lease was minted,
   - and the target domain id (redaction-safe label).

### 3) Portals for device attach (user-driven)
Device attach is modeled as a portal request:
- prompt includes sanitized device identity (vendor/product/class) and *risk tier* (policy-defined).
- the consent receipt (CH-RECEIPT) links the CH-DEVGUARD decision + IOLEASE digest.

This makes “plugging in a device” insufficient to grant authority; the explicit action is “attach device X to domain Y”.

### 4) CH-DEVGUARD v0 (optional)
A pinned descriptor for authorization rules (USBGuard-like shape) used by:
- device manager policy evaluation,
- transcript logging,
- and tooling (“show me what auto-attaches exist”).

See: `docs/30-architecture/device-guard-policy-schema-v0.md`.

Key properties:
- deterministic rule order and matching,
- closed enums,
- redaction-safe identifiers,
- explicit defaults (deny/allow/quarantine/require-portal).

### 5) DMA-class hotplug posture notes
- If the platform cannot support the profile’s DMA posture (e.g., missing IOMMU), D-DEVGUARD must fail closed for DMA-capable buses.
- Even with OS DMA protection, some threats exist **before the OS loads**; treat those as firmware/boot assumptions and reflect them in A-HW-1 and A-BOOT-1/A-BOOT-2 (REF-WIN-KDMA, REF-THUNDERSPY-REPORT).

### 6) Future automation staging (hard decision; still no v0 ACP kind)
If SlopOS later introduces automated attach/lease actions, we should reduce entropy now instead of rediscovering the serialization scope later:
- **Conflict key family**: use `CH-CONFLICTKEY family="device.id"`.
- **Identity input**: derive `device_key = ck_id("device.id", device_id)` from an explicit typed `device_id` allocated by the device manager / driver authority for one attachable device-presence instance.
- **Do not key ordering on topology hints**: `port_path`, bus addresses, raw serials, and UI labels are useful policy/UX material (CH-DEVGUARD / CH-HWEVENT), but they are not the ordering identity.
- **Phase 1 remains manual-only**: until an ACP kind exists, serialization continues to live inside `portal.device`; this section only pins the future per-device scope so D-COMMUTE does not drift back to ambient names.
- **Resolved boundary**: OQ-0009 is now settled by `device-lease-ordering-boundary-v0.md`: future attach/grant/revoke automation uses `device.id` as the only portal-policy ordering family. Queue-local / endpoint-local sequencing belongs to the live lease / driver host and does not become a second `portal.device.*` conflict-key vocabulary.

Why this shape:
- It matches the portal mediation precedent that device access is a request/permission workflow rather than ambient `/dev` authority (REF-XDG-PORTAL-USB).
- It matches Android’s explicit per-device permission model: apps discover devices, then must obtain user permission before communicating with a chosen device (REF-ANDROID-USB-HOST).
- It keeps deterministic policy matching orthogonal: USBGuard-style policy can still match `via-port`, `serial`, or interface traits, but ordering identity stays separate from those hints (REF-USBGUARD-RULELANG).

## Profile gating + defaults
- Default posture: **deny** new hotplug devices; allow only inventory visibility.
- Optional: allow devices only into an **untrusted peripheral domain** (Qubes-style `sys-usb`), and require an attach portal to reach other domains.
- Auto-attach is opt-in *as data* (CH-DEVGUARD) and should be discouraged outside kiosk/embedded profiles.

## Registries impacted
Add:
- Decision node: **D-DEVGUARD** (decision map entry).
- Schema: **CH-DEVGUARD v0** (schema registry entry).
- Invariants:
  - **I-DEVGUARD-1**: if D-DEVGUARD is enabled, hotplug devices are unauthorized until allowed by policy; any authorization is transcript-visible.
  - **I-DEVGUARD-2**: if D-DEVGUARD is enabled, device authority is revocable; detach removes the authority edge and prevents further I/O.
- Proof obligations:
  - **PO-DEVGUARD-DECIDE**: policy match + decision is deterministic; default is deny; matched rule is logged.
  - **PO-DEVGUARD-ATTACH**: attach/detach results in correct cap-graph edges and respects DMA/IO confinement (I-DMA-1/I-IORES-1/I-IOLEASE-1/I-IOLEASE-2).
- Abuse cases:
  - **AC-074**: malicious peripheral / DMA-capable hotplug device / auto-attach footgun.
- Evidence seed:
  - **EVID-2026-084**: device descriptor fuzzing for the device manager, hotplug/attach negative tests, and IOMMU mapping sanity tests.

## Threat-model impact
Adds explicit coverage for a common physical-adjacent attacker technique: using peripherals to bypass software defenses. Assumptions for DMA-capable hotplug are tied to D-DMA and (optionally) platform support claims like kernel DMA protection (REF-WIN-KDMA).

## Abuse cases / pressure tests
- AC-074 focuses on:
  - device presenting as keyboard/HID to inject input,
  - device presenting as network adapter to bypass network policy,
  - DMA-capable peripheral attempting memory reads/writes,
  - “helpful” auto-attach rules causing silent authority expansion.
Mitigation is default deny + untrusted peripheral domain + portalized attach + transcript visibility + IOMMU confinement.

## References
REF-QUBES-USB, REF-USBGUARD-RHEL7, REF-USBGUARD-RULELANG, REF-XDG-PORTAL-USB, REF-ANDROID-USB-HOST, REF-THUNDERSPY-REPORT, REF-WIN-KDMA, REF-GOODUSB-ACSAC15.
