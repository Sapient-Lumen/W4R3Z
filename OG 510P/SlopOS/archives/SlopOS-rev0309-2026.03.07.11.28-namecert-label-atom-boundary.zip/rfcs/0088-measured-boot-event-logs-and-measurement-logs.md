# RFC-0088: Measured boot event logs as pinned artifacts (CH-MEASLOG) (D-BOOT adjunct)

Status: Draft  
Updated: 2026-02-26  
Decision node(s): **D-BOOT**, D-ENC, D-AREF (optional), D-ATTEST (optional)

## Summary
Tighten the “measured boot” branch of **D-BOOT** by defining **CH-MEASLOG v0**: a portable, replayable **integrity event log** that can be referenced from **CH-BOOT**.

This makes “measured boot” mechanically usable:
- PCR quotes are not interpretable without an event log.
- Operators/verifiers need a **bounded, content-addressed artifact** they can archive, diff, and replay.

Adds:
- CH-MEASLOG v0 schema + registry entry.
- Minimal assurance wiring (I-MEASLOG-1, PO-MEASLOG-VALIDATE) + evidence plan entry.
- Clarifies CH-BOOT `measurements` field to reference CH-MEASLOG.

## Motivation
Measured boot systems commonly provide:
- **PCR values** (what was extended), and
- an **event log** (what was measured, in what order).

A quote over PCRs is only meaningful if a verifier can replay the event log and confirm it yields the quoted PCRs (and optionally confirm key events bind to expected artifact digests).

Greenfield advantage: we can treat the measurement log itself as a **pinned CH-* artifact** that:
- is canonical (hashable/signable),
- is bounded by default (no “send the whole IMA log” by accident),
- and can be referenced via CH-AREF for larger, out-of-band logs.

Refs: REF-TCG-EFI-PLATFORM, REF-TCG-PC-CLIENT-PFP, REF-TCG-IMELP, REF-SYSTEMD-PCR-MEASURE, REF-LINUX-IMA-TEMPLATES.

## Design goals
- **Replayable**: sufficient structure for “replay-to-PCR” verification workflows.
- **Bounded**: a safe default size; explicit escalation path for large logs via CH-AREF.
- **Non-leaky**: no stable hardware IDs, bearer tokens, or user content.
- **Compositional**: can bind selected events to CH-BOOT `artifacts` digests when possible.

## Non-goals
- Standardizing every platform’s full measurement taxonomy (UEFI vs. custom boot stacks vary).
- Requiring runtime integrity measurement for all files (IMA-scale logs are too large by default).
- Putting parsing/verifying of platform-specific binary logs into the privileged core.

## Proposal

### 1) Introduce CH-MEASLOG v0
Spec: `docs/30-architecture/measured-boot-log-schema-v0.md`

CH-MEASLOG v0 is a small, canonical, bounded event log with:
- an explicit `source` (UEFI log, userspace measurements, IMA-style stream, custom),
- a declared hash `bank`,
- ordered `events`, optionally with:
  - `pcr` index (when applicable),
  - `etype` category tags,
  - `ref` bindings to CH-BOOT artifacts (role+digest).

For larger logs:
- either truncate the `events` list and include `aref` pointing to the full log,
- or store the full log out-of-band and carry only CH-AREF (digest-addressed) with policy allowlists.

### 2) Bind CH-MEASLOG into CH-BOOT
CH-BOOT already has a `measurements` field; we tighten it:
- `measurements` SHOULD be `digest(CH-MEASLOG)` when a measured-boot profile is enabled.
- Alternatively/additionally, include the CH-MEASLOG digest in CH-BOOT `artifacts` with role `meas_log`.

Key property:
- measurement events that claim a `ref` MUST match CH-BOOT artifact digests for that boot.

### 3) Keep platform-specific parsing out of the privileged core
IF-BOOT’s obligations stay small:
- treat CH-MEASLOG as *the* portable format.
- platform-specific extraction/parsing (e.g., UEFI binary log decoding) belongs in tooling that produces CH-MEASLOG.

Deployment profiles can still require:
- “CH-MEASLOG must be present for measured boots”,
- “CH-MEASLOG must include an event binding for kernel+init”,
- “full event log must be available via CH-AREF for fleet attestation”.

### 4) Interaction with attestation (D-ATTEST)
No changes are required to CH-ATTEST v0:
- CH-ATTEST binds to `digest(CH-BOOT)`.
- If CH-BOOT binds to `digest(CH-MEASLOG)`, the attestation indirectly commits to the measurement log as well.

(If a profile later needs explicit PCR-quote evidence, it can be carried as an additional evidence artifact referenced by CH-AREF, without changing CH-ATTEST.)

## Assurance wiring
New invariant (seed):
- **I-MEASLOG-1 (Measured log binding, optional)**: if CH-BOOT includes `measurements` and/or lists a `meas_log` artifact, the referenced CH-MEASLOG digest is validated and exportable for audit; any event-level `ref` digests that claim to bind to CH-BOOT artifacts must match.

New proof obligation (seed):
- **PO-MEASLOG-VALIDATE**: if CH-MEASLOG is used/referenced by CH-BOOT, decoding/validation is total and canonical; bounds enforced; event `ref` bindings fail closed on mismatch.

Evidence plan:
- EVID-2026-086

## Alternatives
- **Just store PCR values**: not replayable; unverifiable without additional context.
- **Store platform-native binary logs**: hard to lint; parser complexity creeps into the trusted path.
- **Full IMA by default**: too large; forces premature policy decisions; better as an explicit, opt-in tier with CH-AREF.

## References
REF-TCG-EFI-PLATFORM, REF-TCG-PC-CLIENT-PFP, REF-TCG-IMELP, REF-SYSTEMD-PCR-MEASURE, REF-SYSTEMD-MEASURE-MAN, REF-LINUX-IMA-TEMPLATES.
