# RFC-0104: Application secrets via a secret portal (CH-APPSECRET) (D-APPSECRET)

Status: Draft  
Updated: 2026-02-26  
Decision node(s): D-APPSECRET, D-PLUMB (adjunct), D-CRYPTOSVC (adjunct), D-VAULT (optional)

## Summary
Bake in a capability-safe way for sandboxed applications to obtain a **per-application secret seed** for local confidentiality (at-rest encryption, integrity tags) without creating an ambient “keyring API”.

This RFC introduces:
- a `portal.secret` workflow family that returns an **app-scoped secret seed** (or a handle profile), and
- **CH-APPSECRET v0**, a bounded, redaction-safe descriptor suitable for receipts/audit.

Pinned v0 posture follow-up: treat D-APPSECRET as a **minimal app-seed seam**, not a general vault. Phase 1 declines named secret inventory/collections, keeps `scope="profile"` as the default posture, and forbids silent auto-rotation without a future RFC/evidence pass.

The goal is to prevent the common ecosystem drift where apps either:
- stash secrets in ad hoc files,
- rely on global keyrings/agents with confusing trust boundaries,
- or hardcode credentials (which later becomes a supply-chain incident).

## Motivation
Many sandboxed apps need a small amount of stable secret material to protect local state:
- encrypting a local database/cache,
- generating per-install integrity tags,
- seeding deterministic-but-secret key derivations.

This is not “password storage”; it is a **per-app seed** that lets the app encrypt inside its own sandbox without being handed broad host authority.

A greenfield OS can make this boring:
- no ambient “read a secret by name” syscall,
- no privileged global key-value store as a de facto authority oracle,
- explicit scope (device/user/profile), rotation semantics, and export posture.

## Non-goals
- Replacing a full credential store, password manager, or cross-app secret sharing.
  - Those belong under D-VAULT (CH-SECRETPOL/CH-SECRETREF) when/if enabled.
- Preventing a fully compromised app from reading its own local secrets.
  - Once the app is compromised, its local confidentiality is compromised.
- Defining biometric/interactive unlock policy.
  - If needed, that composes later via D-VOLITION and D-CRYPTOSVC policy pins.

## Design

### Portal model
A user-space **secret portal** mediates requests and returns a per-application secret.

Conceptual request fields:
- `scope`: closed enum, one of:
  - `device` — stable for this device (factory reset breaks it)
  - `user` — stable for this user profile/session identity
  - `profile` — stable for a specific app profile/container (**default v0 posture**)
- `purpose`: closed enum (bounded): `local_encrypt` | `local_integrity` | `kdf_seed`
- `len`: requested bytes (portal clamps to a small allowlist such as 32 or 64)
- `rotate`: optional bool; if true, request an epoch bump (policy-gated)

Portal response profiles (deployment choice):
- **byte-seed profile (baseline):** return raw secret bytes to the requester.
- **handle-only profile (stricter, optional):** return a `SecretSeed` capability that can be used only for derivation operations (via D-CRYPTOSVC) and cannot export raw bytes.

Both profiles MUST emit a redaction-safe descriptor (CH-APPSECRET) for audit/receipts.

### Derivation and rotation (conceptual)
The secret value for `(origin, scope, epoch)` is derived from a high-entropy root secret held by the portal implementation.

Rotation is modeled as a monotonic `rotation_epoch` bump:
- rotating makes the *new* epoch secret available and the *previous* epoch secret unavailable (or only available for a bounded grace window, profile-defined).
- rotation requires explicit policy (and, in strict profiles, may require D-VOLITION).
- Phase 1 does **not** claim silent auto-rotation, rotation-on-read, or background job-driven epoch changes.

### Security posture
- **No ambient access:** apps cannot “look up” secrets by arbitrary names.
- **Not a general inventory:** Phase 1 declines collections, items, labels, attribute search, enumeration, and import/export semantics under D-APPSECRET.
- **No cross-app sharing:** secrets are scoped to the requesting app identity (component id + instance).
- **No secret material in transcripts:** only CH-APPSECRET metadata is logged; never the bytes.
- **No implicit persistence:** the portal decides how the root secret is stored/sealed; persistence choices are profile-defined.

### CH-APPSECRET v0
CH-APPSECRET is a bounded descriptor intended for receipts/audit. It contains:
- scope/purpose/length bounds,
- origin attribution (component id),
- a monotonic rotation epoch,
- redaction hints,
- and no secret bytes.

See: `docs/30-architecture/app-secret-descriptor-schema-v0.md`.

## Registries impacted
- Add **CH-APPSECRET v0** to the schema registry.
- Add portal family `portal.secret.*` to the portal-family registry.
- Extend CH-PLEDGE token set with `portal.secret` (and mapping table).

Add invariants:
- **I-APPSECRET-1 (Per-app secret isolation, optional):** secret portal derivations are scoped to the requesting component identity and cannot be used to obtain another component’s secret material.
- **I-APPSECRET-2 (No secret bytes in logs/exports, optional):** CH-APPSECRET and any transcript/receipt record contains no secret bytes; exports prefer hash-only redaction where applicable.
- **I-APPSECRET-3 (Explicit rotation, optional):** rotating an app secret requires explicit policy authorization; epoch changes are transcript-visible and monotonic.

Add proof obligations:
- **PO-APPSECRET-VALIDATE:** CH-APPSECRET decoding/validation is canonical, total, and fail-closed.
- **PO-APPSECRET-ENF:** the portal enforces scope isolation, bounds, and rotation policy with no bypass paths.

Add abuse case:
- **AC-089:** secret portal misuse (cross-app correlation, secret oracle, stealth rotation).

Add evidence seed:
- **EVID-2026-107** (schema validator + portal harness plan).

## Evidence plan
E0 (EVID-2026-107):
- validator golden tests: closed enums; bounds; unknown keys reject; canonical decode.
- portal harness:
  - per-app isolation checks (requester A cannot obtain requester B’s secret),
  - scope semantics checks (`profile` vs `user` vs `device` are distinct when enabled),
  - rotation monotonicity + policy gating (unauthorized rotate fails closed; epoch bumps are transcript-visible),
  - byte-seed vs handle-only profile behaviors (if both implemented).
- negative tests:
  - no ambient “secret by name” lookup,
  - no secret bytes appear in CH-LOG/CH-RECEIPT exports under CH-OBSPOL.

## References
Refs: REF-XDG-PORTAL-SECRET, REF-ANDROID-KEYSTORE, REF-ANDROID-KEYATTEST, REF-SECRET-SERVICE-SPEC.
