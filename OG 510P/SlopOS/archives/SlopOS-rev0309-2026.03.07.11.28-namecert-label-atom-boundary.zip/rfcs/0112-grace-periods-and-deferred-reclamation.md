# RFC-0112: Grace periods + deferred reclamation for read-mostly shared state (D-RCU)

Status: Draft  
Updated: 2026-02-27  
Decision node(s): **D-RCU**, D-UWAIT (adjunct), D-WAITSET (adjunct), D-METER (adjunct), D-RR (adjunct)
Pinned v0 posture: `docs/30-architecture/rcu-posture-v0.md` (QSBR-first; per-subsystem/user-space GraceDomains; no ambient/global collector; no workflow/ACP surface).

## Summary
Once an ecosystem has **shared memory** (D-IOBUF/shared regions) and scalable **event loops** (D-WAITSET) it will inevitably grow **read-mostly shared state**:

- inspect trees and diagnostic state
- handle tables / routing tables / registries
- connection metadata and caches

At that point, two failure modes show up everywhere:

1) *Snapshot trouble:* readers want to traverse a structure without taking global locks, but writers still need to update it.
2) *Reclamation trouble:* once a node is removed, when is it safe to free/reuse it without a use-after-free?

Mature systems converge on a family of techniques based on **grace periods**:
- **RCU** (Read-Copy-Update): publish new versions, wait a grace period, then reclaim.
- **QSBR/EBR** (quiescent-state / epoch-based reclamation): wait until all participants have passed a known safe point.
- **Hazard pointers**: explicit per-thread “I might touch this pointer” declarations.

We should bake in a small, capability-friendly **D-RCU seam** now: a standard, bounded way for components to obtain grace periods and safely defer reclamation of shared read-mostly structures.

## Goals
- Make read-mostly sharing **fast for readers** (no contended locks on the hot path).
- Provide a **standard** (not bespoke) contract for “wait until all readers are done” and “defer free until safe”.
- Keep the mechanism **bounded and attributable** (D-METER when enabled); no unbounded limbo growth.
- Keep the mechanism **non-amplifying** (no new authority is created by using grace periods).
- Compose with:
  - D-UWAIT/D-WAITSET for efficient waiting,
  - D-RR determinism (explicit, stable outcomes under replay profiles).

## Non-goals
- A general tracing GC, region GC, or language runtime specification.
- A cross-machine distributed reclamation protocol.
- Mandatory adoption for all components (this is an optional seam).

## Design sketch

### 1) The seam: a GraceDomain capability
Introduce an optional user-space service (preferred) or kernel object (only if required by evidence) that exports:

- `read_enter()` / `read_exit()` (a *read-side critical section*)
- `synchronize()` (wait for a **grace period**)
- `defer_free(tag, ptr_or_ref)` (optional convenience: queue a reclamation callback)

Design intent:
- Read-side is extremely cheap (often TLS + atomic loads; no syscalls).
- Writers publish a new pointer/version, then call `synchronize()` to ensure all pre-existing readers have exited before reclaiming old nodes.

### 2) Two profiles: QSBR-first, EBR-when-needed
To keep the seam small and verifiable, D-RCU defines two recommended profiles:

**(A) QSBR (quiescent-state based reclamation) profile**
- Best fit for event-loop/turn-based components (D-TURNS) and driver loops.
- “Quiescent states” are explicit points (turn boundaries, poll loop iterations, or after processing an inbound message).
- `quiescent()` is the only mandatory signal; `read_enter/read_exit` may be elided if all reads happen within turns.

**(B) EBR (epoch-based reclamation) profile**
- Best fit for general threaded runtimes.
- Each thread maintains an `active_epoch` marker while inside `read_enter/read_exit`.
- `synchronize()` advances the global epoch and waits until all threads have either:
  - reported `inactive`, or
  - observed a newer epoch.

### 3) Waiting discipline (no busy-wait fallback)
`synchronize()` must not devolve into polling loops.

- If D-UWAIT is enabled, implementations SHOULD use wait-on-address for blocking waits on epoch/quiescent counters.
- If D-WAITSET is enabled, implementations MAY expose “grace-period completed” as a waitable signal bit.

### 4) Bounding and charging
Grace periods are notorious for “unbounded limbo” when a participant stalls.
D-RCU requires explicit bounds:

- a maximum number of registered participants per domain,
- a maximum backlog of deferred frees / limbo nodes,
- deterministic overflow behavior (reject new deferrals, or force a fail-close path).

When D-METER is enabled, limbo/backlog state must be charged to an explicit payer.

### 5) Stalls and failure posture
D-RCU does **not** magically solve the “crashed/stuck reader prevents reclamation” problem.
Instead, the posture is explicit:

- In production profiles, if a participant does not report quiescence for longer than a declared bound, supervisors treat it as a liveness failure (D-SUPV) and restart/kill it.
- Components that rely on D-RCU MUST treat reclamation pressure as a backpressure signal (D-PRESSURE adjunct) and fail-close rather than silently growing state.

### 6) Deterministic replay (adjunct)
If D-RR is enabled, the outcome of `synchronize()` and any stall/timeout path must be transcript-visible (or treated as a replayed decision), so replay does not silently diverge.

## Security and safety notes
- **Non-amplification:** GraceDomain is not authority; it only coordinates memory safety. It must not be usable as an oracle that leaks cross-component activity beyond the stated side-channel posture.
- **No hidden global:** avoid a system-wide “global RCU domain” that becomes an ambient dependency. Prefer per-component or per-subsystem domains.
- **Avoid pointer reuse hazards:** any “owner token” or handle embedded in reclaimed nodes must be generation-safe (see revocation epoch and robust-lock lessons).

## Alternatives
- “Just use locks”: pushes everyone toward coarse locks; harms inspect snapshot ergonomics and risks lock-order bugs.
- “Just use refcounting”: works but is slow in read-mostly paths and prone to cycles/ABA-style reuse hazards.
- “Hazard pointers only”: robust but higher overhead and harder ergonomics; keep as an optional library technique but not the only ecosystem story.

## Evidence plan (seed)
- **EVID-2026-115**: implement a tiny user-space GraceDomain prototype + harness:
  - RCU-protected pointer swap for a read-mostly map/list,
  - concurrent readers traversing while a writer swaps versions,
  - deferred free backlog bounds + deterministic overflow behavior,
  - stall simulation + supervisor restart path (fail-close),
  - optional D-RR transcript hook for synchronize outcomes.

## References (see bibliography)
REF-LINUX-RCU-WHATIS, REF-LINUX-RCU-CONCEPTS, REF-LINUX-RCU-CHECKLIST,  
REF-MCKENNEY-PERFBOOK, REF-HAZARD-POINTERS-MICHAEL, REF-FRASER-PRACTICAL-LOCK-FREEDOM,  
REF-HART-MEMRECL-IPDPS06, REF-LIBURCU
