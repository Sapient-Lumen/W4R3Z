# RFC-0108: Quiescence + drain protocol for maintenance operations (D-QUIESCE)

Status: Draft  
Updated: 2026-02-27  
Decision node(s): **D-QUIESCE**, D-REQCTX (adjunct), D-SUPV (adjunct), D-ACTIVATE (adjunct), D-CHKPT (adjunct), D-WAITSET (adjunct)

## Summary
“Stop this service” is one of the most overloaded operations in real systems.

In practice, a single coarse signal (SIGTERM) or a single coarse API (Stop) tends to produce:
- dropped in-flight requests,
- orphan background work,
- upgrade and checkpoint pipelines that only work for “nice” services,
- shutdown that is unpredictable under load.

This RFC proposes an optional seam:
- **D-QUIESCE**: a small, capability-mediated **quiescence + drain protocol** that makes “prepare for maintenance” explicit and testable.

The intent is to standardize the minimum cooperative contract that enables:
- **graceful shutdown** (stop accepting new work, drain/abort in-flight),
- **zero/low-downtime restart** (inbound endpoints are manager-owned; workers quiesce and swap),
- **checkpoint/restore** (capture needs a consistent cut),
- **live migration** (where possible),
without adding a heavy in-kernel policy surface.

Refs: REF-SYSTEMD-SERVICE, REF-KUBE-LIFECYCLE-HOOKS, REF-ERLANG-RELEASE-HANDLING, REF-LINUX-CGROUP-FREEZER, REF-FUCHSIA-RUNNER-STOP.

Pinned v0 posture note: `docs/30-architecture/quiesce-posture-v0.md` freezes Phase 1 to a **cooperative, component-local** seam with **one active qid**, **`DRAIN|CANCEL` only**, and **no force-kill/global freeze semantics**.

## Motivation
We already have pieces that *help* (D-REQCTX, D-SUPV, D-ACTIVATE, D-CHKPT), but the ecosystem still needs a standard “stop doing work now” handshake.

Concrete pressures:
- **Shutdown under load**: without a quiesce gate, services often keep accepting work until the last second, then fail mid-flight.
- **Checkpoint/migration**: capturing a consistent state requires either (a) a cooperative cut or (b) intrusive stop-the-world techniques that often break invariants and driver/IPC contracts.
- **Ops semantics drift**: different services invent different “stop” APIs, and tooling must guess what is safe.

We want “stop/drain” to be:
- explicit,
- bounded,
- deterministic,
- and correlated with request contexts and transcripts.

## Non-goals
- A mandatory global service manager API: D-QUIESCE is optional and can be adopted incrementally.
- Transparent “freeze any arbitrary program” checkpointing: that remains out of scope for strict profiles.
- In-kernel stop orchestration policy.

## Proposed seam: D-QUIESCE

### Object model (informal)
D-QUIESCE standardizes a control-plane interface shape for components that want to cooperate.

A minimal control capability (typically held by a supervisor) can request quiescence:
- `BeginQuiesce(reqctx, mode) -> (qid, status)`
- `GetQuiesce(qid) -> CH-QUIESCE (optional descriptor)
- `EndQuiesce(qid) -> status`

Where:
- `reqctx` is the (optional) request context (D-REQCTX), providing deadline/correlation intent.
- `mode` is a closed enum:
  - `DRAIN`: stop accepting *new* externally-triggered work; allow in-flight work to finish until deadline.
  - `CANCEL`: stop accepting new work and actively cancel in-flight work (best-effort but explicit outcomes).

A component that does not implement D-QUIESCE simply cannot be relied on for graceful maintenance; supervisors may fall back to crash-only restart semantics.

### Required semantics (v0)
A component that supports D-QUIESCE must implement a small state machine:
- `RUNNING` → `QUIESCING(qid, mode)` → `QUIESCENT(qid)` → `RUNNING`

Rules:
1) **One active quiesce epoch**: a component instance has at most one active `qid`; a second `BeginQuiesce(...)` while `QUIESCING` or `QUIESCENT` fails deterministically with the active `qid` rather than nesting or silently extending grace.
2) **Gate new work**: once `QUIESCING`, externally-triggered entrypoints that would start new work MUST reject deterministically with a framework error (e.g., `QUIESCING`) or queue behind the quiesce boundary only if the interface explicitly declares that behavior.
3) **Bounded drain**: in-flight work must either (a) complete and become visible, or (b) return an explicit cancel/deadline outcome tied to the request context.
4) **No silent background**: once an operation is reported canceled, the component MUST NOT continue it silently in the background.
5) **Exit is explicit**: `EndQuiesce(qid)` returns to `RUNNING` (or fails deterministically if `qid` is not current).

Pinned v0 posture note: escalation after grace remains outside D-QUIESCE itself; Phase 1 declines a portable force-kill opcode and keeps subtree/process-tree ordering in supervisor/runner policy instead of the core seam.

### Integration hooks (optional)
- **Waitability (D-WAITSET adjunct)**: a component control handle MAY expose a `QUIESCENT` signal bit once it reaches the quiescent state, allowing supervisors to wait efficiently without polling.
- **Activation continuity (D-ACTIVATE adjunct)**: for restartable workers, quiesce can be used as a “pre-stop” step before swap, while inbound endpoints remain manager-owned.
- **Checkpoint capture (D-CHKPT adjunct)**: checkpoint manager requests `BeginQuiesce(DRAIN)` for the capture set, waits for `QUIESCENT`, then requests exports.

### Descriptor as data (optional)
If tooling/transcripts need portable evidence of maintenance semantics, emit a bounded descriptor:
- **CH-QUIESCE v0**: a non-authoritative record describing the active quiesce intent/state for an instance.

See: `docs/30-architecture/quiesce-report-schema-v0.md`.

## Options

### Option 0: No quiesce protocol (ad hoc stop semantics)
Pros: simplest.
Cons: every service invents its own stop/drain semantics; checkpoint/migration becomes service-specific; operators/tooling must guess.

### Option 1 (recommended seam): D-QUIESCE protocol (cooperative drain/cancel)
Pros: small contract; testable; composes with existing seams.
Cons: requires ecosystem uptake; some legacy runtimes will remain crash-only.

### Option 2: Stop-the-world freezer as the primary checkpoint primitive
Pros: can checkpoint uncooperative services in some cases.
Cons: fragile across IPC and device contracts; tends to become an implicit “kernel can do anything” policy surface.

## Assurance wiring (seed)
New invariants (optional; only if D-QUIESCE is enabled):
- **I-QUIESCE-1 (Quiesce gate is non-amplifying, optional)**: requesting or observing quiesce state cannot create new authority or bypass capability checks; quiesce is a control action requiring explicit control authority.
- **I-QUIESCE-2 (No silent work after cancel, optional)**: once an operation is reported canceled due to quiesce or deadline, the component does not continue the operation in the background.
- **I-QUIESCE-3 (Bounded and deterministic maintenance outcomes, optional)**: entering/exiting quiesce is bounded and deterministic: state transitions are explicit, and timeouts/escalation paths are defined and transcript-visible.

New proof obligations (seed):
- **PO-QUIESCE-STATE**: the quiesce state machine is total/closed; invalid `qid` transitions reject deterministically; the control API is bounded.
- **PO-QUIESCE-GATE**: new-work gating is complete: externally-triggered entrypoints do not start new work while QUIESCING unless explicitly declared.

## Evidence plan
- **EVID-2026-111**: harness plan:
  - a toy service that supports quiesce + a supervisor that orchestrates `BeginQuiesce(DRAIN)` and verifies gating of new work,
  - negative tests: ensure canceled work does not complete silently;
  - integration tests: checkpoint manager uses quiesce to capture a consistent cut for a small component set.

## References
REF-SYSTEMD-SERVICE, REF-KUBE-LIFECYCLE-HOOKS, REF-ERLANG-RELEASE-HANDLING, REF-LINUX-CGROUP-FREEZER, REF-FUCHSIA-RUNNER-STOP.
