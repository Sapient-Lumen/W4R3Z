# RFC-0110: Wait-on-address / futex primitives for userspace synchronization (D-UWAIT)

Status: Draft  
Updated: 2026-02-27  
Decision node(s): **D-UWAIT**, D-REQCTX (adjunct), D-METER (adjunct), D-RR (adjunct), D-MEMTAG (adjunct)

## Summary
Modern ecosystems rely on a “missing primitive” that lets user-space build fast mutexes/condvars without burning CPU:

- **Linux futex**: fast path in user space; kernel is used only for contention.
- **Windows WaitOnAddress/WakeByAddress***: wait on a word to change, without allocating an event object.
- **FreeBSD _umtx_op**: kernel assist for pthread primitives.
- **Fuchsia/Zircon futex**: process-local wait/wake keyed by a userspace address.

Without this seam, multi-threaded runtimes either:
- spin/poll (wasteful, harms determinism, triggers watchdogs), or
- allocate heavyweight kernel objects per lock/condvar (explodes object counts and DoS surface).

This RFC proposes an optional, minimal, capability-compatible primitive:
- **D-UWAIT**: a bounded **wait-on-address** facility (futex-like) for *process-local* userspace synchronization.

Pinned v0 posture: `docs/30-architecture/uwait-posture-v0.md` freezes Phase 1 to **one aligned 32-bit wait word**, **wait + wake only**, **process-local only**, and **no workflow/ACP surface**.

## Motivation
We already have:
- D-WAITSET for event loops waiting on many handles,
- D-TURNS for turn-based services,
- D-REQCTX for cancellation/deadlines,
- D-IOQ for batched I/O.

But ecosystem reality is that:
- compatibility runtimes (POSIX pthreads, language runtimes, JVMs, DBs) expect efficient blocking primitives,
- the uncontended case must stay entirely in userspace,
- the contended case must sleep without per-lock kernel allocations.

A small D-UWAIT seam prevents the rest of the system from accreting ad-hoc “sleep queues”, bespoke condvar objects, or polling hacks.

## Goals
- **Uncontended = userspace only**: fast path never enters the kernel.
- **Bounded kernel footprint**: contention queues are bounded and attributable (D-METER when enabled).
- **Process-local by default**: the v0 design does not create new cross-process signaling channels.
- **Deterministic, fail-closed semantics**: no silent success; no implicit “best effort” waits.
- **Composes with cancellation/deadlines**: optional integration with D-REQCTX.
- **Optional, not mandatory**: event-loop style systems can ignore it.

## Non-goals
- A full pthreads specification.
- A global fairness policy (FIFO vs priority queues are profile choices; v0 is minimal).
- A cross-host distributed locking facility.
- Mandatory priority inheritance (PI) in v0.

## Design
### 1) Minimal operations (v0)
The D-UWAIT seam provides two conceptual operations on one aligned 32-bit wait word, exposed as KABI actions (names illustrative):

- `uaddr_wait(uaddr, expected32, ctx?) -> (OK | BAD_STATE | TIMED_OUT | CANCELED | RESOURCE_EXHAUSTED)`
- `uaddr_wake(uaddr, n) -> woken_count`

Notes:
- v0 standardizes **one aligned 32-bit word**; wider or narrower waits are deferred rather than widening the core seam now.
- `ctx?` is an optional request-context handle or digest for cancellation/deadline integration (D-REQCTX adjunct).
- `uaddr_*` operations are **process-local** in v0: `uaddr` is interpreted in the caller’s address space.
- `uaddr_requeue(...)` is explicit future/profile work, not a Phase 1 core claim.

### 2) Atomic check + sleep (no lost-wake within the contract)
`uaddr_wait` performs an atomic read/compare-and-sleep sequence:
1. Atomically read `*uaddr` and compare to `expected`.
2. If not equal, return `BAD_STATE` (do not sleep).
3. If equal, enqueue the current thread in a sleep queue keyed by `uaddr_id` and block.

A correct userspace pattern is:
- change the value with an atomic operation,
- then call `uaddr_wake(uaddr, ...)`.

This is the same “check in userspace, sleep in kernel only when needed” story, but stated in a deterministic, fail-closed way.

### 3) Address identity + pointer tagging
The kernel tracks waiters by a normalized address identity:
- `uaddr_id := normalize(uaddr)` where `normalize` strips architecture-specific tags when applicable.

This avoids creating distinct wait queues for different tags that refer to the same underlying address on tag-enabled platforms.

### 4) Bounds and charging
Sleeping consumes kernel state (a waiter record). D-UWAIT must be **bounded**:
- per-process waiter count is bounded,
- per-address queue length is bounded,
- exceeding bounds returns `RESOURCE_EXHAUSTED` deterministically.

If D-METER is enabled:
- waiter records are chargeable objects (like other kernel reference-like state), and creation requires an explicit payer.

If D-METER is not enabled:
- the system still enforces hard caps by profile to prevent DoS.

### 5) Cancellation and deadlines (adjunct)
If D-REQCTX is enabled, `uaddr_wait` MAY accept a request context:
- deadline expiry returns `TIMED_OUT` deterministically,
- cancellation returns `CANCELED` deterministically.

No ambient time requirement:
- deadlines depend on explicit Clock handles in D-NONDET profiles.

### 6) Interactions
- **With D-WAITSET**: D-UWAIT is for thread blocking on memory words; D-WAITSET is for event loops over handles/signals. They are complementary; avoid forcing one to impersonate the other.
- **With D-RR**: replay profiles should log `uaddr_wait/wake` outcomes (and the chosen timeout/cancel source) to make contention behavior reproducible.
- **With D-MEMTAG**: address normalization must be consistent with the memory-tagging mode to avoid tag-as-identity bugs.

### 7) Priority inheritance (PI) posture (defer)
Many systems support PI variants (Linux PI futexes; Zircon owner concept).
We defer PI to a later profile because:
- Phase 1 scheduling is deliberately constrained/deterministic,
- PI expands scheduler coupling and proof surface,
- and the v0 posture keeps owner-death / inconsistent-state recovery on the separate D-ROBUSTLOCK surface instead of widening D-UWAIT itself.

However, we reserve an interface shape for future PI:
- `uaddr_wait_pi(uaddr, expected, owner_thread_handle, ctx?)` and
- `uaddr_wake_single_owner(uaddr)` style ownership transfer.

## Security notes
- Process-local default avoids creating a cross-process signaling oracle.
- Bounds are mandatory: otherwise untrusted components can consume kernel waiter state.
- Waker/waiter cooperation is required: this is a synchronization primitive, not an authorization mechanism.

## Invariants / proof obligations (seed)
- I-UWAIT-1..3 (non-amplifying, atomic check+sleep contract, bounded/attributable kernel waiter state).
- PO-UWAIT-BOUND, PO-UWAIT-ATOMIC (registries).

## Evidence plan (seed)
- **EVID-2026-113**: a harness that:
  - implements a minimal userspace mutex + condvar on top of D-UWAIT,
  - proves no lost wake in the reference patterns via differential tests,
  - stress-tests waiter bounds/charging and deterministic failure modes,
  - (optional) measures CPU savings vs spin/poll and validates replay determinism when D-RR is enabled.

## References
Refs: REF-MS-WAITONADDRESS, REF-MS-WAKEBYADDRESSSINGLE, REF-MS-WAITFUNCS, REF-LINUX-FUTEX2, REF-LINUX-FUTEX-PAPER, REF-FREEBSD-UMTX-OP, REF-FUCHSIA-FUTEX.
