# RFC-0106: Wait sets + object signals for scalable event loops (D-WAITSET)

Status: Draft  
Updated: 2026-02-27  
Decision node(s): **D-WAITSET**, D-REQCTX (adjunct), D-NONDET (timeout posture), D-TRACE (adjunct), D-IOQ (adjunct)
Pinned v0 posture: `docs/30-architecture/waitset-posture-v0.md` (observational signal bits; explicit bindings; level-triggered by default; `tag + observed_mask` only; no packet queue/user injection; no workflow/ACP surface).

## Summary
Event-driven systems live or die by one primitive: **wait efficiently on many things**.

This RFC proposes an optional, capability-safe seam:
- **D-WAITSET**: a posture to standardize **object signals** (pollable state bits) and an efficient **wait set** (epoll/kqueue/IOCP/Zircon ports–style) for waiting on many signal sources.

Core stance:
- Waiting must never *create* authority.
- Wait registration and delivery must be bounded, deterministic, and fail-closed.
- Cancellation/deadlines should compose cleanly with **D-REQCTX**, without introducing ambient time.

Refs: REF-ZIRCON-SIGNALS, REF-ZIRCON-OBJECT-WAIT-MANY, REF-ZIRCON-OBJECT-WAIT-ASYNC, REF-ZIRCON-PORT-WAIT, REF-LINUX-EPOLL, REF-BSD-KQUEUE, REF-WIN-IOCP, REF-WIN-POSTQUEUEDCOMPLETIONSTATUS.

## Motivation
Three recurring failure modes in young OS stacks:
1) **Poll loops** that devolve into O(n) scans and timer hacks.
2) **Ad hoc notification objects** per subsystem that don’t compose (timers vs channels vs interrupts vs pressure).
3) **Cancellation mismatch**: a shutdown/cancel signal can’t interrupt a blocked wait without bespoke wiring.

Mature ecosystems converge on an aggregating primitive:
- Linux: epoll
- BSD: kqueue
- Windows: I/O completion ports
- Zircon: waitable object signals + wait_many and ports

They differ in details, but the shared “shape” is stable:
- a uniform **signal bitmask** per object type,
- a way to wait on many handles efficiently,
- an event packet that returns a user tag + the observed signal state.

## Non-goals
- An in-kernel programmable filter VM (avoid DTrace/eBPF-class complexity in the privileged core).
- Promise of perfect fairness/ordering across all event sources.
- Ambient timeouts (timeouts require explicit clock authority under D-NONDET).

## Proposed seam: D-WAITSET
### Object signals (v0)
Define a small, closed signal vocabulary per kernel object type.
- Signals are **bits** (uint32) that represent current state, e.g.:
  - endpoint/channel: `READABLE`, `WRITABLE`, `PEER_CLOSED`
  - thread/process: `TERMINATED`
  - timer: `SIGNALED`
  - interrupt: `IRQ_PENDING`

Signal rules:
- Signals are **observations**, not authority.
- Signal bits must be derivable from object state (no hidden payloads).
- v0 is **level-triggered by default**: waiters observe the current bitmask; no user-visible “lost wakeup” semantics are baked into the portable default.
- Edge-triggered / one-shot variants are deferred so the default seam does not inherit re-arm and missed-transition complexity.

### Wait sets (v0)
Introduce an optional **WaitSet** object to aggregate many wait registrations.

Minimal API shape (informal):
- `waitset.bind(handle, mask, tag) -> binding_handle`
- `waitset.unbind(binding_handle)`
- `waitset.wait(max_events, deadline?) -> [ {tag, observed_mask} ]`

v0 posture notes:
- Bindings are over **explicit handles only**; no ambient namespace/path/fd lookup is part of D-WAITSET.
- The portable result is **`tag + observed_mask` only**; payload-bearing packets remain on explicit dequeue/read surfaces owned by the relevant subsystem.
- Phase 1 deliberately declines a user-injected packet queue on D-WAITSET itself so event loops do not become a hidden control plane.

Design constraints:
- **Bounded**: `max_events` is clamped; binding counts are bounded per WaitSet and per domain.
- **Deterministic**: overflow is explicit (stable error/flag), not silent drop.
- **No ambient time**: `deadline` is either absent or derived from an explicit Clock handle (D-NONDET). If D-NONDET is off, waits are either indefinite or use coarse, profile-defined timers.

### Cancellation and request contexts (adjunct)
To avoid bespoke “wake the waiter” hacks:
- A wait SHOULD accept a cancellation source via the request-context path:
  - runtimes translate `ctx.cancelled` into either:
    - a Cancel object signal bound into the WaitSet, or
    - an interruptible wait primitive that returns `CANCELLED` deterministically.

Key point: **D-WAITSET does not require D-REQCTX**, but must not block its adoption.

### Integration notes
- **CapRPC**: server runtimes typically sit on a WaitSet; `ctx.cancelled` should interrupt the event loop so shutdown is prompt and bounded.
- **D-IOQ**: queue objects should become waitable through signal bits such as `CQ_READABLE`; payloads remain on the queue's own completion/dequeue surface rather than being inlined into D-WAITSET packets.
- **Tracing** (optional): if D-TRACE is on, emit a tracepoint when a wait returns (counts only; no tags by default) to support scheduler/latency debugging under redaction policy.

## Options
### Option 0: wait_many only
- Provide a `wait_many(items[], deadline)` primitive that is O(n) in the number of items.
- Pros: minimal kernel surface.
- Cons: poor scalability for high-fd-count servers; invites user-space polling hacks.

### Option 1 (recommended): wait_many + WaitSet
- Keep `wait_many` for small sets and bootstrap tooling.
- Add WaitSet for scalable servers/drivers.
- Pinned v0 posture keeps WaitSet **observational and level-triggered by default** with **no user-injected packet queue** on the same seam.

### Option 2: wait queue + packet/control plane on one object
- Avoid early: combining readiness waiting with arbitrary packet injection or control messages quietly widens D-WAITSET into a second in-process transport.

### Option 3: kqueue-class “filters”
- Avoid early: filter programmability expands TCB and proof surface.

## Assurance wiring (seed)
New invariants (optional; only if D-WAITSET is enabled):
- **I-WAITSET-1 (Wait is non-amplifying)**: registering and waiting on signals cannot create new authority or bypass capability checks.
- **I-WAITSET-2 (Bounded delivery)**: wait registration counts and returned event batches are bounded; overflow/failure is explicit and deterministic.
- **I-WAITSET-3 (Signals are observational)**: signals expose only declared state bits; no hidden payloads or high-resolution oracles beyond the declared side-channel posture.

New proof obligations (seed):
- **PO-WAITSET-BOUND**: bounds are enforced on bind/unbind/wait; error behavior is deterministic; no unbounded queues.
- **PO-WAITSET-NOAMP**: no authority amplification via wait tags/bindings; tags are treated as untrusted data; observed masks are derived solely from authorized object state.

## Evidence plan
- **EVID-2026-109**: harness plan covering:
  - bind/unbind correctness under churn,
  - overflow behavior (explicit, deterministic),
  - cancellation interrupting blocked waits (with and without D-REQCTX),
  - “no ambient time” profile tests (Clock handle required for deadlines),
  - microbench: wait_many vs WaitSet under load.

## References
REF-ZIRCON-SIGNALS, REF-ZIRCON-OBJECT-WAIT-MANY, REF-ZIRCON-OBJECT-WAIT-ASYNC, REF-ZIRCON-PORT-WAIT, REF-LINUX-EPOLL, REF-BSD-KQUEUE, REF-WIN-IOCP, REF-WIN-POSTQUEUEDCOMPLETIONSTATUS.
