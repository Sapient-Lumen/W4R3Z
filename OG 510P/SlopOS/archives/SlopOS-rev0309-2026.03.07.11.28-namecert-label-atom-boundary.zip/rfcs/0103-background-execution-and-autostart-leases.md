# RFC-0103: Background execution + autostart as leased, audited authority (D-BGLEASE)

Status: Draft  
Updated: 2026-02-28  
Decision node(s): D-BGLEASE, D-LEASE, D-PLUMB (adjunct), D-JOBS (adjunct), D-VOLITION (optional)

## Summary
Make **running in the background** and **starting automatically at login** explicit, portal-mediated authority.

This RFC introduces:
- a `portal.background` workflow family that issues **BackgroundLease** handles (attenuation-only; revocable),
- **CH-BGREQ v0**, a bounded request descriptor for background/autostart grants (no capability material),
- **CH-BGLEASE v0**, a bounded, redaction-safe descriptor for grants/receipts,
- and an LLM-first submission seam: ACP kind `portal.background.request` binding `bgreq_digest = digest(CH-BGREQ v0)` (optional; recommended for validator-executed workflows).

The goal is to prevent the classic drift where “harmless” conveniences (tray apps, auto-updaters, helper daemons) silently become ambient persistence and a privacy/power footgun.

## Motivation
Background execution is high-leverage authority:
- it enables **persistence** (spyware, miners, adware),
- it enables **battery drain / availability degradation**,
- it enables **covert exfiltration** when combined with other grants,
- it becomes a UX trust failure if users cannot answer “what’s running in the background, and why?”.

Modern platforms converge on explicit controls:
- sandboxed desktops expose a **Background portal** (request background + autostart, plus user-visible status),
- Android introduced background execution limits and restricts background services,
- Apple requires explicit declaration of background modes/capabilities.

Greenfield advantage: bake a capability-safe, user-visible mechanism from the start, rather than retrofitting policy exceptions forever.

## Non-goals
- Designing a universal power manager.
- Replacing constraint-based deferrable work (use D-JOBS).
- Making CH-BGLEASE an authorization token.

## Design

### Two distinct needs
1) **Deferrable work** (sync, upload, indexing): should use **D-JOBS**.
2) **Continuous background presence** (messaging presence, long-lived audio routing, device bridge): may require a **background lease**, but must be visible and bounded.

D-BGLEASE exists primarily for (2); D-JOBS should cover most legitimate “I need to do work later” requests.

### Portal model
A user-space **background portal** mediates requests and returns a **BackgroundLease** handle.

Requests SHOULD be expressed as **CH-BGREQ v0** (bounded; no capability material). In LLM-first stacks, proposals bind `bgreq_digest = digest(CH-BGREQ v0)` and validators invoke the portal only via explicit portal capabilities (no ambient autostart registries).

Request fields (conceptual; see CH-BGREQ v0):
- `background`: request permission to continue running when not foreground.
- `autostart`: request permission to be started automatically at user login.
- `reason`: bounded, user-visible string.
- optional `ttl`: requested duration (portal clamps); autostart defaults to periodic review.
- optional `status_message`: short, list-friendly indicator message.

The portal MUST return an explicit result:
- `background_granted` (bool)
- `autostart_granted` (bool)

Closing the handle releases background permission; autostart is an explicit, revocable setting tied to the grant record.

### Policy posture
Policy MUST be able to clamp:
- maximum TTL,
- renewal cadence,
- whether `autostart` is allowed (per profile, per publisher, per user policy),
- whether background permission requires **fresh volition** (D-VOLITION) in strict profiles,
- whether a grant requires **indicators** (recommended for long-lived background).

### Visibility
Background activity should be user-legible:
- secure UI shell SHOULD show a non-spoofable “background apps” surface,
- `status_message` is bounded (single line) and owned by the portal (no rich text),
- in strict profiles, any long-lived background grant SHOULD be transcripted as a receipt and exported only under CH-OBSPOL redaction.

### Composition rules
- Background grants **do not imply** network/file/device/location authority.
  - any such authority must be obtained separately (e.g., `portal.net`, `portal.device`, `portal.location`).
- Background grants are **not** a scheduler: use D-JOBS for deferrable work.
- Under D-METER/D-TCAP, background execution SHOULD require an explicit payer/budget where enabled.

### CH-BGLEASE v0
CH-BGLEASE is a bounded descriptor for audit/receipts; it contains **no capability material**.

See: `docs/30-architecture/background-lease-schema-v0.md`.

## Registries impacted
- Add **CH-BGREQ v0** and **CH-BGLEASE v0** to the schema registry.
- Add invariants:
  - **I-BGREQ-1 (Request descriptor is non-authoritative, optional):** CH-BGREQ contains no capability material and is bounded/closed-world; it is data for policy/receipts, not authority.
  - **I-BGLEASE-1 (No ambient background/autostart, optional):** continuing to run while backgrounded or registering autostart requires an explicit lease/grant minted by `portal.background`; no ambient “run forever”/autostart constructors exist after init.
  - **I-BGLEASE-2 (Bounds + revocation, optional):** background leases enforce TTL/renew clamps and fail closed on expiry/revocation; autostart grants are revocable and subject to periodic review in strict profiles.
  - **I-BGLEASE-3 (Visibility + transcript, optional):** grants/renewals/revocations are transcript-visible; long-lived background presence implies indicators and (in strict profiles) consent/volition binding.
- Add proof obligations:
  - **PO-BGREQ-VALIDATE:** CH-BGREQ decoding/validation is canonical, total, and fail-closed.
  - **PO-BGLEASE-VALIDATE:** CH-BGLEASE decoding/validation is canonical, total, and fail-closed.
  - **PO-BGLEASE-ENF:** portal clamps and enforcement are complete (no bypass) and visibility/receipt behavior matches profile policy.
  - **PO-ACP-BGLEASE-REQUEST (optional):** if ACP kind `portal.background.request` is used, validators enforce lane gate `cfg.params.lane.portal.background` fail-closed, validate the referenced `bgreq_digest = digest(CH-BGREQ v0)` canonically, and emit transcript-visible outcomes (CH-ACPOUT/CH-DENY).
- Add abuse case:
  - **AC-088:** background/autostart abuse (stealth persistence + battery drain).
- Add evidence seeds:
  - **EVID-2026-106** (schema validator + portal harness plan).
  - **EVID-2026-175** (ACP kind `portal.background.request` harness plan).


## Evidence plan
E0 (EVID-2026-106):
- validator golden tests: closed enums; bounds; unknown keys reject; canonical decode.
- portal harness:
  - deny-by-default in strict profiles unless explicitly allowed,
  - `autostart` requires stronger policy posture and is revocable,
  - TTL/renew clamps prevent “infinite background” loops,
  - closing lease drops background permission deterministically,
  - status message bounds enforced; indicators appear for active background grants.
- negative tests:
  - no ambient autostart registration path,
  - no background execution without a lease,
  - background does not implicitly grant network authority.


E0 (EVID-2026-175):
- ACP kind harness: lane-disabled deterministic rejects (`portal.background`), CH-BGREQ digest binding + canonical validation, ordered-stream witness enforcement within `domain.id`, and portal clamp/renewal negative tests (TTL clamp, autostart review posture, revoke/expiry).
## References
Refs: REF-XDG-PORTAL-BACKGROUND, REF-ANDROID-BG-EXEC-LIMITS, REF-ANDROID-FGS-RESTRICTIONS, REF-APPLE-BG-MODES.
