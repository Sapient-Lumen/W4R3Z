# RFC-0079: TUF-style update repository metadata (D-TUF)

Status: Draft  
Updated: 2026-02-25  
Decision node(s): **D-TUF**, D-ATOMICUPD, D-UPD-SIGN, D-TLOG, D-PCP, D-BOOT

## Summary
Define an **optional** update-distribution seam based on **The Update Framework (TUF)**: a repository publishes signed metadata that clients use to securely discover and fetch update artifacts (including **CH-UPD** and the deployment root tree referenced by it), while resisting:

- **rollback** (serving older signed content),
- **freeze** / indefinite staleness (withholding fresh metadata),
- **mix-and-match** (serving inconsistent metadata/artifact sets),
- and common **online key compromise** scenarios.

This RFC is about *distribution metadata and key hygiene*.
It does **not** require kernel support: the privileged boot path remains agnostic and continues to validate only the signed digests it is already designed to validate (CH-UPD/CH-BOOT/CH-PROV).

## Motivation
We already have strong “what ran?” artifacts (CH-BOOT) and an atomic update posture (D-ATOMICUPD).
But without a survivable repository metadata strategy, a compromised mirror or compromised online signing key can still cause:

- persistent staleness (clients never learn about security updates),
- confusing partial updates (installing a set the publisher never intended),
- or key-rotation events that become operationally catastrophic.

TUF is attractive because it operationalizes separation of duties via role keys and expiry, while explicitly modeling rollback/freeze classes of attack.

## Design

### D-TUF posture
- **Optional**: D-TUF is a deployment choice (typically P1/P2). P0 can use “direct fetch + CH-UPD signatures” only.
- **User space**: implemented by the updater + repository tooling; the kernel never parses TUF metadata.
- **Digest universe**: TUF `targets` metadata points to artifacts by **digest**; CH-UPD remains the install-time unit of intent (RFC-0051).

### Repository roles (TUF baseline)
We adopt the TUF baseline role split:

- **root**: publishes and rotates the public keys for all other roles; typically offline/threshold.
- **targets**: signs the “what is available” mapping (target name → digest/size/custom metadata).
- **snapshot**: signs a consistent view of which metadata versions are current (prevents mix-and-match).
- **timestamp**: provides a frequently updated freshness signal (prevents freeze / detects staleness).

Operational guidance:
- keep **root** offline with threshold signatures,
- keep **timestamp** online and short-expiry,
- keep **targets** and **snapshot** in a hardened but reachable workflow (offline or semi-online depending on cadence).

### What gets published as “targets”
A D-TUF repository SHOULD publish at least:
- **CH-UPD** objects (CBOR bytes) as targets (e.g., `channel/arch/profile/<upd_digest>.cbor`)
- deployment artifacts referenced by CH-UPD `target_root_digest` (tree/closure objects)
- optional: CH-PROV attestation containers, proof bundles, and transparency anchors (CH-TLOG)

The trusted install logic remains:
1) updater selects a candidate target (often by channel + platform),
2) updater verifies TUF metadata (freshness + consistency),
3) updater fetches CH-UPD + referenced artifacts, verifies digests,
4) updater enforces install-time gates (D-PCP) and stages an atomic deployment (D-ATOMICUPD).

### Trust anchor + bootstrap
Clients need an initial trust anchor. D-TUF requires one of:
- the install medium pins an initial **root metadata** object (by digest and/or embedded signed root),
- or the platform pins a vendor root key bundle in ROM/TPM-sealed storage,
- or an operator pins the initial root out of band (lab/fleet provisioning).

Bootstrap is a *policy event* and SHOULD be recorded as evidence (e.g., an install-time CH-LOG record binding the initial root digest).

### Key rotation + compromise recovery (sketch)
- Non-root key compromise is recovered by issuing a new `root` metadata update that revokes/replaces the compromised key(s).
- Root compromise (threshold breach) is recovered **out of band**: install media or provisioning workflow distributes a new root.

We standardize a “rotation drill” expectation in the engineering playbook (docs/60-engineering/update-repository-metadata-and-key-rotation.md) so D-TUF is not paper security.

### Integrating transparency anchors (D-TLOG)
If D-TLOG is enabled, a release pipeline SHOULD:
- log each published CH-UPD digest and the corresponding `targets` metadata digest,
- include CH-TLOG anchors in the release bundle and/or CH-PROV evidence.

This enables monitors to detect equivocation (two different `targets` views for “the same” channel) even if clients are not actively monitoring.
For higher-assurance channels, require **witnessed** checkpoints (D-WITNESS) so “audit-complete” releases are resistant to split-view log attacks.

### Optional: Uptane-style director split (fleet profiles)
For fleets, Uptane extends TUF with a “director” that can issue per-vehicle/per-cohort target metadata while delegating artifact hosting to an “image repository”.
We treat this as a **profile extension** (D-UPTANE), not a baseline requirement.

## Invariants / proof obligations
- **I-TUF-1 (Freshness + consistency, optional)**: if D-TUF is enabled, the updater MUST reject repository metadata that is expired or inconsistent (timestamp/snapshot mismatch), and MUST fail closed on verification errors.
- **PO-TUF-VERIFY**: implement and test a total verification routine for TUF metadata (signature threshold, expiry checks using I-TIME-1, and snapshot/targets consistency).
- **PO-UPD-VERIFY** remains the install-time digest/signature gate for CH-UPD and the staged deployment tree.

## Threat-model impact (abuse cases)
- **AC-067 (repository freeze / stale-metadata attack)**: attacker with network or mirror control keeps serving old `timestamp`/`snapshot` so clients never learn about security updates.
  - mitigations: short expiry on timestamp/snapshot; monotonic time checks (I-TIME-1); operator alerting on staleness; optional D-TLOG monitoring.

## Alternatives considered
- “Just sign CH-UPD and fetch directly”: acceptable for P0 and for closed networks, but does not address freeze/mix-and-match robustly and makes key compromise recovery more brittle.
- “Use package-manager signatures only”: does not naturally bind “the set” (consistency) or freshness; tends to accumulate ad-hoc rules.

## References
REF-TUF-METADATA, REF-TUF-SPEC, REF-TUF-FAQ, REF-UPTANE-STANDARD2, REF-UPTANE-BESTPRACTICES, REF-PEP-480, REF-SIGSTORE-COSIGN, REF-SIGSTORE-REKOR, REF-SIGSTORE-FULCIO, REF-SIGSTORE-KEYLESS.
