# RFC-0093: Signature envelopes for CH-* payloads + optional keyless signing (CH-SIGENV) (D-SIGENV / D-KEYLESS)

Status: Draft  
Last updated: 2026-02-26

Goal: make “this artifact was signed by the right party” a **mechanically checkable** statement without forcing every profile to carry long-lived signing keys.

This RFC standardizes a small signature envelope for our content-addressed universe:
- **CH-SIGENV v0**: a bounded, canonical *envelope* that signs a **payload digest** (and payload type) using a DSSE-style domain separation.
- Optional: a **keyless** posture (Sigstore-style) where the signer identity is an OIDC-authenticated certificate rather than a provisioned private key.

Non-goals:
- putting signature verification in the kernel unconditionally (keep boot/update verifiers small and profile-driven)
- inventing a new PKI or transparency log protocol (we reuse existing ecosystems)

## Problem
Today our archive has several places where “a signed container exists” is referenced but underspecified (e.g., CH-BOOT `prov_attestation_digest`, CH-UPD signatures under D-UPD-SIGN).

If the ecosystem doesn’t standardize the envelope shape early, the failure mode is predictable:
- every tool invents a slightly different wrapper (hard to audit)
- “signature confusion” bugs creep in (wrong type signed, wrong subject signed)
- key management becomes the adoption blocker (teams avoid signing, or share keys)

A greenfield project can do better by:
1) standardizing a *tiny* envelope for signing payload digests, and
2) making it possible to adopt a keyless workflow where appropriate.

## Prior art (high-signal)
- **DSSE**: signs (payloadType, payload) using a pre-auth encoding to prevent type confusion without canonicalization games. (REF-DSSE; REF-DSSE-BACKGROUND)
- **in-toto Attestation Framework**: a layered model (Statement + Predicate) for supply-chain claims; commonly carried inside DSSE envelopes. (REF-IN-TOTO; REF-IN-TOTO-STATEMENT)
- **Sigstore**:
  - **Fulcio** issues short-lived signing certs tied to OIDC identities; identity claims are embedded into the certificate. (REF-SIGSTORE-FULCIO; REF-SIGSTORE-FULCIO-OIDC)
  - **Rekor** provides a transparency log for signatures/attestations. (REF-SIGSTORE-REKOR)
  - **Bundle format** ties signature material + log inclusion evidence into a portable object. (REF-SIGSTORE-BUNDLE)

Lesson we adopt: envelope standardization + explicit identity policy prevents the “signed bytes, unknown meaning” trap.

## Decisions
Introduce two optional seams:
- **D-SIGENV**: the system may represent signatures over CH-* payloads using **CH-SIGENV v0**.
- **D-KEYLESS** (adjunct): a profile may accept **keyless** signatures (certificate-bound identities) under an explicit allowlist policy.

These integrate with:
- **D-UPD-SIGN**: CH-UPD / CH-CFG / CH-PROV can be signed in a standard way.
- **D-TLOG**: envelopes may carry an optional CH-TLOG anchor digest for “logged” evidence.
- **D-TUF**: repository metadata can remain key-based even if payload artifacts are keyless-signed (hybrid is often operationally best).

## Design summary
### 1) CH-SIGENV signs payload digests (not paths)
A CH-SIGENV v0 envelope binds:
- `payload.schema` (bounded string, e.g., `CH-UPD v0`)
- `payload.digest` (our digest namespace)
- optional `payload.size_bytes` (informational)

Signatures are computed over a DSSE-style pre-auth encoding of `(payload.schema, payload.digest)`.

Rationale:
- avoids ambiguity (“what was signed?”)
- avoids embedding large payload bytes in the envelope
- keeps the verifier narrow: verify signature(s) and check `payload.digest` matches the referenced artifact

### 2) Multiple signature kinds, one normalized record
CH-SIGENV supports two signer kinds:
- `direct_key`: signature verified against a pinned public key (classic)
- `keyless_cert`: signature verified against a pinned CA/root, with **issuer + identity claims** checked against an allowlist policy

Each signature record may optionally include:
- `tlog_anchor_digest`: digest of a CH-TLOG record (D-TLOG) asserting “this payload digest was logged”

### 3) Keyless acceptance is policy, not magic
If D-KEYLESS is enabled, verifiers MUST enforce:
- allowlisted OIDC issuer(s)
- allowlisted identity patterns (repo/workflow/email/etc.)
- certificate validity constraints (time window), using the profile’s secure time posture (D-TIME / D-TIMEPROOF)

Keyless signatures are still “just signatures” — the identity checks are what give them meaning.

### 4) Keep the privileged core out
- The kernel does not parse signatures.
- IF-BOOT verification responsibilities remain profile-defined:
  - early profiles may verify only digests
  - higher profiles may require CH-SIGENV verification for CH-UPD and referenced artifacts

## CH artifacts
- **CH-SIGENV v0** (new): see `docs/30-architecture/signature-envelope-schema-v0.md`.

## Invariants (additions)
- **I-SIGENV-1 (Signature envelope binds meaning, optional)**: for accepted CH-SIGENV envelopes, the signature MUST be verified over a DSSE-style encoding of `(payload.schema, payload.digest)`; mismatches are rejected deterministically.
- **I-KEYLESS-1 (Keyless identity policy, optional)**: if D-KEYLESS is enabled, accepting a `keyless_cert` signature requires an explicit allowlist match on issuer + identity claims (profile-defined); failing to match rejects deterministically.

## Proof obligations (additions)
- **PO-SIGENV-VALIDATE**: CH-SIGENV decoding/validation is total + canonical; bounds enforced; unknown variants/keys reject deterministically.
- **PO-SIGENV-VERIFY**: signature verification over the DSSE-style encoded `(payload.schema, payload.digest)` is deterministic and fail-closed under the profile’s allowed algorithms/keys.
- **PO-KEYLESS-VERIFY**: for `keyless_cert` signatures, verification is deterministic: certificate chain validation + issuer/identity allowlist checks + validity window checks (using the profile time posture); failure rejects.

## Abuse case tie-in
- **AC-080**: keyless identity spoofing / policy confusion ("anyone with an OIDC account can sign") and log-equivocation misuse.

## Evidence plan (tight)
Phase 0/1:
- CH-SIGENV schema validator golden + negative tests (PO-SIGENV-VALIDATE)
- verification golden tests:
  - correct signature verifies for a known payload digest
  - type confusion attempt (`payload.schema` swapped) fails
  - wrong digest fails
- keyless policy tests (if enabled):
  - issuer allowlist mismatch fails
  - identity claim mismatch fails
  - expired cert fails under secure time lower bound rules

Phase 2:
- optional: end-to-end release bundle demo tying together:
  - CH-UPD + CH-PROV + CH-SBOM + CH-VEX
  - CH-SIGENV envelopes for each
  - CH-TLOG anchors for the payload digests

## References
REF-DSSE, REF-DSSE-BACKGROUND, REF-IN-TOTO, REF-IN-TOTO-STATEMENT, REF-SIGSTORE-KEYLESS, REF-SIGSTORE-FULCIO, REF-SIGSTORE-FULCIO-OIDC, REF-SIGSTORE-REKOR, REF-SIGSTORE-BUNDLE.
