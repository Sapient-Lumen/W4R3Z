# RFC-0075: Inspect trees + diagnostic snapshot bundles (D-INSPECT)

Status: Draft  
Updated: 2026-02-25  
Decision node(s): **D-INSPECT**, D-OBS, D-TRACE, D-TRACEPROC, D-TPRED, D-ENC

## Summary
Introduce a small, capability-safe **structured diagnostics** substrate inspired by Fuchsia’s Inspect:

- **CH-INSPECT v0**: a bounded, canonical *snapshot* of a component’s “inspect tree” (structured key/value state).
- **CH-SNAPSHOT v0**: a bounded manifest for a **support/incident snapshot bundle** that references logs, traces, inspect snapshots, crash dumps, and selected config/build metadata.

Companion artifact (optional):
- **CH-CRASHCAP v0**: a smaller, failure-shaped “crash report” manifest for a single crash event (binds env digests + module identity + bounded payload refs). \1
Related seam:
- **D-FLIGHTREC** can retain bounded “last N seconds” rings of selected logs/traces and assemble CH-SNAPSHOT on crash/watchdog/operator triggers. See RFC-0109.

The goal is to make “what is the system doing?” answerable without scraping free-form logs or inventing ad-hoc `/proc`-style formats, while keeping exfiltration risk explicit and bounded.

## Motivation
Every mature OS ecosystem develops a “support bundle” workflow:
- Android bugreports package logs + dumpsys/dumpstate state snapshots.
- Apple sysdiagnose packages unified logs and system state.
- Windows Error Reporting can capture dumps + diagnostics.

These workflows exist because:
1) **logs alone are not enough** (you need current state, counters, topology), and
2) ad-hoc state scraping is brittle and expensive.

Fuchsia’s approach is unusually clean: components expose a structured diagnostics tree (Inspect) and a diagnostics service (“archivist”) aggregates it. That design turns “debuggability” into a first-class contract instead of an accident.

Refs: REF-FUCHSIA-INSPECT, REF-FUCHSIA-INSPECT-FORMAT, REF-FUCHSIA-SNAPSHOT, REF-ANDROID-BUGREPORT, REF-ANDROID-READBUGREPORTS, REF-APPLE-SYSDIAGNOSE, REF-MS-WER-USERMODE-DUMPS.

## Design goals
- **Structured, not stringly**: hierarchical keys + typed values, no free-form JSON.
- **Read-only + capability mediated**: publishing is local; reading/export is explicit authority.
- **Bounded and cheap**: updates must not require syscalls; reads must not induce unbounded work.
- **Redaction/minimization is explicit** (I-OBS-1): snapshot bundles are sensitive objects.
- **Composable with existing observability**: logs/traces remain; inspect adds “current state”.

## Non-goals
- A universal runtime metrics system (Prometheus/OpenTelemetry) baked into the core.
- A kernel-resident monitoring framework.
- A general-purpose remote debugging protocol.

## Proposal

### 1) New decision seam: D-INSPECT
D-INSPECT decides whether we standardize a structured diagnostics tree contract.

Options:
- **none (default)**: rely on logs + ad-hoc endpoints.
- **inspect trees (recommended)**: a small user-space library + snapshot schema (CH-INSPECT).

Evidence criteria:
- developer ergonomics for “what’s happening right now?”
- boundedness (size + CPU) under adversarial components
- redaction posture for exports (I-OBS-1)

### 2) Inspect tree model (implementation guidance)
Each component MAY maintain an in-process “inspect tree”:
- hierarchical node paths (e.g., `net/arp/cache`)
- typed properties: counters, gauges, booleans, small strings, digests

Implementation should prefer **shared-memory publishing**:
- the component allocates a bounded “inspect region” (e.g., a memory object) and writes updates locally.
- a diagnostics collector (“archivist”) holds a read capability for that region and can snapshot it.

This avoids a high-frequency syscall path and keeps the kernel out of observability.

### 3) CH-INSPECT v0 (snapshot export)
Define a canonical, bounded snapshot schema for exporting a component’s inspect tree.

See: `docs/30-architecture/inspect-snapshot-schema-v0.md`

Key constraints:
- closed value types; bounded strings/bytes
- canonical ordering for stable hashing/signing
- optional redaction class per node/property

### 4) Diagnostic snapshot bundles (support bundles)
Define a small manifest schema for “support bundles” that can be:
- created locally by operators,
- attached to bug reports,
- used for incident response,
- optionally used as an input to minimization tooling.

See: `docs/30-architecture/diagnostic-snapshot-bundle-schema-v0.md`

A CH-SNAPSHOT references (by digest / CH-AREF) a bounded set of artifacts such as:
- transcript windows (CH-LOG excerpts)
- trace excerpts (CH-TRACE, or processor outputs)
- inspect snapshots (CH-INSPECT)
- boot + deployment metadata (CH-BOOT / CH-UPD digests)
- component graph snapshot digest (CH-COMP)
- crash reports / dumps (format intentionally out of scope; referenced as artifacts)

### 5) Export posture
Snapshot creation/export is treated as **explicit authority**:
- by default, only sanitized bundles are allowed (policy-driven allowlist)
- full bundles (if allowed at all) require explicit operator/consent workflow

This is aligned with I-OBS-1 and with the general posture that “diagnostics can be an exfiltration channel.”

## Security + abuse cases
- **AC-061 (Support bundle exfiltration)**: attacker coerces export of secret-bearing state via snapshot.
  - mitigation: I-SNAP-1/I-SNAP-2 + PO-SNAP-REDACT + capability-gated export.
- **AC-062 (Inspect DoS / covert channel)**: adversarial component writes high-entropy or high-rate updates.
  - mitigation: I-INSPECT-2 (size + rate bounds), redaction tags, and collector-side sampling.

## Assurance wiring
New invariants (seed):
- **I-INSPECT-1 (Inspect is observational, optional)**: inspect publishing/snapshotting cannot create authority or change privileged state; reads are capability-gated.
- **I-INSPECT-2 (Inspect bounded + redaction-aware, optional)**: inspect regions and exported snapshots are size-bounded; exports are redacted per policy and forbid secret-bearing identifiers by default.
- **I-SNAP-1 (Snapshot export is explicit authority, optional)**: creating/exporting CH-SNAPSHOT bundles requires explicit capabilities/portal approval; no ambient “dump everything” syscall exists.
- **I-SNAP-2 (Snapshot manifest binds scope, optional)**: each CH-SNAPSHOT is bound to a declared redaction/scope policy and lists digests for included artifacts; consumers can verify what is and isn’t present.

New proof obligations (seed):
- **PO-INSPECT-VALIDATE**: CH-INSPECT decode/validation is total; unknown types reject deterministically.
- **PO-INSPECT-BOUNDS**: collectors enforce maximum region size and snapshot size; overflow behavior is explicit and deterministic.
- **PO-SNAP-REDACT**: snapshot assembly must respect the redaction policy; secret-bearing fields are absent unless explicitly authorized.
- **PO-SNAP-BIND**: CH-SNAPSHOT binds to boot/session identifiers + artifact digests; substitution/mismatch fails closed.

## Alternatives
- `/proc`-style text endpoints: easy to add, hard to evolve, and brittle to parse.
- “just use logs”: fails for current state, topology, and counters.
- embed a full metrics stack: increases scope/TCB; still needs redaction and bundle semantics.

## Next work (evidence plan)
- Build a minimal “archivist” component that snapshots a few demo trees.
- Fuzz CH-INSPECT decoder and enforce size bounds under adversarial input.
- Redaction tests: ensure sanitized snapshots exclude secret refs (sturdyrefs, key material, raw addresses).
- Bundle verification tests: mismatched digests, missing required artifacts, unknown artifact kinds.
