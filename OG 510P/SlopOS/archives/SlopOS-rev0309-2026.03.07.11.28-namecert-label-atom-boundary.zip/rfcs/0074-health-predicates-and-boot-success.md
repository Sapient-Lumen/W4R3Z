# RFC-0074: Health predicates + boot-success commit (D-HEALTH)

Status: Draft  
Updated: 2026-02-25  
Decision node(s): **D-HEALTH**, D-ATOMICUPD, D-SUPV, D-ENC

## Summary
Add a small, explicit **health milestone** mechanism to support:
- atomic updates with “trial boot → commit on health” semantics (CH-BOOTSEL), and
- structured recovery (supervision trees) without ambiguous “boot seems fine” heuristics.

We introduce:
- **CH-HEALTH v0**: a signed, canonical *predicate* describing what “healthy” means for a profile.
- **CH-HEALTHREC v0**: a bounded, digest-bindable *record* of one evaluation (audit evidence).

Critically: the ability to commit a boot as “successful” remains a **capability boundary** (a `BootCommit`-like capability), not a writable file or ambient syscall.

## Motivation
Many systems have learned that:
1) switching to a new deployment is necessary but insufficient, and  
2) the “mark successful” step must be explicit and hard to spoof.

Concrete prior art:
- Android A/B updates rely on a bootloader slot state machine and user space marking the current slot **SUCCESSFUL** via the Boot Control HAL (e.g., `markBootSuccessful()`) before certain rollback metadata advances.  
- ChromeOS uses a post-boot “good kernel” marking step after integrity checks.  
- systemd’s “automatic boot assessment” blesses a boot only once `boot-complete.target` is reached (and integrates with boot counting/rollback).

Refs: REF-ANDROID-BOOTCTRL, REF-ANDROID-VERIFIEDBOOT-FLOW, REF-CHROMEOS-UPDATEENGINE, REF-SYSTEMD-BOOT-ASSESS.

In our archive, CH-BOOTSEL already expects a “profile’s health predicate” (I-ATOMICUPD-3), but the predicate was not pinned as an artifact. That gap invites:
- silent drift (“health” means different things in different places),
- confused-deputy commits by compromised early boot services,
- poor auditability (“why did we commit / why did we roll back?”).

## Design goals
- **Small and reviewable**: no embedded scripting VM; bounded clauses.
- **Evidence-friendly**: predicate and outcomes are digest-bindable and transcript-visible.
- **Capability-safe**: only an explicitly authorized agent can commit.
- **Composable**: supervision trees can feed readiness/restart signals into the health evaluation.

## Proposal

### 1) New decision seam: D-HEALTH
D-HEALTH decides whether boot success is:
- implicit (avoid; weak auditability), or
- explicit via a pinned predicate (recommended): CH-HEALTH + a commit capability.

### 2) CH-HEALTH v0 (predicate)
See: `docs/30-architecture/health-predicate-schema-v0.md`

v0 is intentionally modest:
- uptime thresholds,
- “components ready” barrier,
- “no restart storm” in a bounded window.

Extending the check kinds requires an RFC and updates to validators/lints.

### 3) CH-HEALTHREC v0 (record)
See: `docs/30-architecture/health-record-schema-v0.md`

Produced by the health assessor when it decides pass/fail; the commit step SHOULD log the digest.

### 4) Ready barrier: minimal user-space handshake
To make “components_ready” meaningful without importing a heavy framework:

- The component manager/supervisor MAY treat readiness as an explicit, one-shot handshake:
  - if a component is declared as `ready.required=true`, it is launched with a one-shot `ReadyToken` capability.
  - the component calls `ReadyToken.signal_ready()` exactly once.
  - the supervisor logs the transition (CH-LOG) and can expose the ready state to the health assessor.

This is analogous to systemd’s `sd_notify READY=1`, but with capability discipline (no ambient socket, no string protocol).

### 5) Boot commit as a capability boundary
User space commits a boot only by presenting a `BootCommit`-like capability held by the health assessor (or a small broker).
The commit operation MUST:
- bind to the pending deployment (`target_root_digest` and/or `upd_digest`),
- bind to the required predicate digest (if configured in CH-BOOTSEL pending policy),
- be transcript-visible (CH-LOG).

This directly mitigates AC-059 (“boot-success marking bypass”).

## Security + abuse cases
- AC-059 updated: success marking bypass attempts must fail closed under I-HEALTH-1 / I-HEALTH-2 and I-ATOMICUPD-3.
- Predicate-complexity DoS: check kinds are bounded; evaluation cost is capped; unknown kinds reject.

## Assurance wiring
New invariants (seed):
- **I-HEALTH-1 (Commit is capability-gated)**: only explicit authority can mark success; no ambient file/flag.
- **I-HEALTH-2 (Predicate binding)**: commits are bound to a specific CH-HEALTH digest and current pending deployment; mismatches fail closed.

New proof obligations (seed):
- PO-HEALTH-VALIDATE (predicate decode/validation is total)
- PO-HEALTHREC-BIND (record links to boot nonce + root digest + predicate digest)
- PO-BOOT-COMMIT-BIND (commit binds pending deployment + predicate)

## Alternatives
- “Just wait N seconds”: weak signal; does not detect broken critical services.
- “Run arbitrary scripts”: too much policy/attack surface; hard to validate.
- “Let every service self-report”: without a capability boundary, early-boot compromise can trivially spoof success.

## Next work (evidence plan)
- State-machine tests: wrong predicate digest, wrong root digest, replayed health record, multiple commits, tries exhaustion.
- Supervisor tests: readiness handshake is one-shot and cannot be forged without `ReadyToken`.

