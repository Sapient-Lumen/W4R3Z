# RFC-0046: Workflow plumbing + portals (capability-safe cross-app routing)

Status: Draft  
Updated: 2026-02-27  
Decision node(s): D-PLUMB, D-POWERBOX, D-VOLITION

## Summary
Introduce an optional user-space **workflow router** (Plan 9 “plumber” lineage) that mediates cross-application flows (open/save/share/clipboard/drag-drop) via **portal-style requests** that return **capability-bearing handles** (sturdyrefs, view-scoped file caps, or document-store handles (CH-DOCREF)) rather than ambient paths. Plumbing messages use a pinned, canonical envelope (CH-PLUMBMSG v0) so CLI and GUI share the same substrate.

## Motivation
Cross-app “glue” is where ambient authority sneaks back in:
- file chooser returns raw paths (bypasses sandbox semantics)
- clipboard / drag-drop become broadcast channels
- “open with…” becomes implicit delegation without durable audit

A greenfield OS can make workflow routing **explicit data + explicit consent**:
- routing rules are a pinned artifact (CH-ROUTE v0)
- user consent is bound to a rendered action summary (D-VOLITION; CH-VOL)
- grants are capability objects, not filesystem strings (D-POWERBOX; CH-AUTHZ)

## Integration seam / kernel impact (keep small)
Kernel impact: **none required** beyond existing primitives:
- capability endpoints + contracts (RFC-0006)
- stable refs (RFC-0014)
- view objects / namespaces (RFC-0032)
- consent mediators (RFC-0031) and volition tokens (RFC-0039)

The workflow router is a **regular component** published under a service tree (e.g., `/svc/workflow/*`).

## Design

### Concepts
- **Workflow intent:** a structured request (“open file”, “share”, “paste”, “open uri”, “print”) that names the *shape* of the requested capability, not a path.
- **Portal session:** a short-lived mediation flow that ends with either (a) a capability grant, or (b) a fail-closed denial.
- **Route rule:** deterministic “match → action” logic that decides what mediator to invoke and which destination port receives the resulting capability/event.

### Threat model stance
- The router must never create authority from nothing (I-CAP-1).
- Routing can **reduce** authority (filtering/redaction) but may not amplify it.
- The UI-confirmation step is optional, but if used it must be **spoof-resistant** (D-VOLITION).

### Interfaces (sketch)
The router exposes two main contracts:

**`Workflow.Portal`**
- `Begin(intent: Intent, hints: Hints) -> Session`
- `Complete(session: Session, choice: UserChoice, volition?: CH-VOL) -> Grant | Deny`

**`Workflow.Plumb`**
- `Send(msg: CH-PLUMBMSG) -> Request | Ack`

Where:
- `CH-PLUMBMSG` is the pinned message envelope (RFC-0117); it is non-authoritative and carries no raw capabilities (I-PLUMB-3).
- `Intent` is a closed enum (v0) aligned with “portal” families: `OpenFile`, `SaveFile`, `Share`, `Paste`, `OpenUri`, `Print`, `PickDevice`, `ScreenCast`, `RemoteDesktop`, `OpenUntrusted`, `ExportFile`, `ExportText`, …
- `Grant` is a **capability-bearing** object reference (sturdyref or direct cap) plus an optional audit pointer (CH-LOG entry).

Phase 1 posture is pinned in `docs/30-architecture/plumb-posture-v0.md`: the portable router seam stays **explicit-invocation and request-local**. D-PLUMB v0 therefore declines a generic `Subscribe(port)` / durable inbox/outbox API, caller-supplied callback URL/port registries, app-visible route/handler inventory, and durable retry/held-message semantics. Route evaluation + request lifecycle ordering live inside `svc:workflow.router`; any future automated/admin surface must return with explicit conflict keys / commutativity / receipts rather than inheriting message-bus behavior by default.
Phase 1 portal-session posture is pinned in `docs/30-architecture/portal-session-posture-v0.md`: generic portal request/session objects stay **provider-owned**, **single-outcome**, and **family-local**, so the D-PLUMB core does not silently acquire a resumable session broker, generic request/session inventory, or family-agnostic restore-token layer. Family-specific continuity (for example explicit CH-DOCREF reopen) must stay in the corresponding portal family RFC/posture rather than widening the portal core.


### CLI integration (no ambient paths)
A “plumb-first” CLI suite (RFC-0117) should exist from day one so terminal workflows do not re-introduce ambient authority:
- `open <docref|sturdyref|uri>` sends a `CH-PLUMBMSG` with `intent.kind=open` or `open_uri` and relies on portals as needed.
- `share`/`paste` route through the transfer portal (CH-XFER v0; RFC-0094).
- `print` routes through the print portal.

Phase 1 pinned OpenURI posture: `portal.uri.*` stays **manual-only, scheme-gated, and launch-only**. There is no app-visible handler inventory/probing API, no callback/return channel, and `file://` / raw-path opening remains a `portal.file.*` / CH-DOCREF problem rather than a launcher convenience seam (see `docs/30-architecture/openuri-portal-posture-v0.md`).

Phase 1 pinned print posture: `portal.print.*` stays **manual-only, render-first, and shell-spooled**. Printing remains a prepare→submit mediation flow with bounded rendered artifacts; applications get no app-visible printer inventory, no durable queue authority, and no print-to-file/path shortcut around `portal.file.*` (see `docs/30-architecture/print-portal-posture-v0.md`).

Requirement: these tools must work in sealed/capmode contexts (D-SEAL/D-CAPMODE) and may attach a `wallet_core_digest` (CH-WALLET) to enable drift gates and explainability (D-WALLET).
### Rules model (CH-ROUTE v0)
A rule matches on:
- `intent.kind`
- optional `contract_id` (RFC-0006 contract)
- source component identity (from CH-COMP / component manifest)
- mime/type tags or “purpose” tags

Actions:
- `deliver(port)` (no UI; only if the sender already possesses the needed capability; `port` remains router-owned dispatch metadata, not a portable app-visible inbox/listing surface in Phase 1)
- `mediate(powerbox)` (invoke IF-CONSENT; bind to CH-VOL if D-VOLITION enabled)
- `rewrite` (optional redaction/normalization of message metadata)
- `deny` (fail-closed)

Rules are evaluated top-to-bottom with deterministic “first match wins”.
Rules must be canonicalized and hashed (I-ENC-1) so deployments can pin and audit them.

### File access semantics (portal behavior)
The portal must return **handles**, not raw host paths:
- preferred: a view-scoped capability to a file/object
- alternative: a document-store handle (CH-DOCREF) that the portal can re-open into a scoped capability inside the requestor’s namespace (see RFC-0089)
- optional: a “bookmark” style sturdyref for persistent access, but only when user explicitly requests persistence and the consent transcript records it (RFC-0089 explains why non-bearer doc handles are preferred)

### Clipboard / drag-drop (optional)
Model clipboard/drag-drop as portal-mediated **transfers**:
- a **paste/drop intent** yields a leased `payload_cap` (D-LEASE), never a broadcast channel
- the portal emits a **CH-XFER v0** descriptor (digest logged/receipted) that attributes source→sink and pins bounds (formats, size, TTL, auto-clear)
- cross-trust transfers SHOULD require fresh volition (D-VOLITION) and SHOULD be receipt-bound (D-EXPLAIN)
See: RFC-0094.


### High-risk portals are leases (recommended)
Some portal families should *always* return a **revocable lease** (short TTL, explicit renew) rather than a long-lived capability:

- **ScreenCast / RemoteDesktop / Camera / Microphone**: return a lease handle to a stream endpoint; the router can require fresh user volition for (a) start, (b) renew, and (c) escalating scope (e.g., whole screen vs window).
  - portals SHOULD emit a **CH-CAPTURE v0** descriptor (digest logged/receipted) to attribute scope + TTL + renewal/escalation behavior (no media bytes).
  - see: RFC-0095.
- **PickDevice** (and similar): return a device lease (D-IOLEASE) with strict bounds and explicit revoke.

Lease semantics:
- default TTL (minutes) with explicit renew
- revoke on domain exit, logout, or on user “stop sharing”
- all grants/renews/revokes are transcript-logged (CH-LOG)

### “Open untrusted” as a first-class workflow (optional, D-EPHEM)
Add an intent family:
- `OpenUntrusted` (open in disposable)

Flow:
1. router spawns a disposable domain (RFC-0050) from a pinned template
2. router delivers the selected object as a scoped capability (not a path)
3. any exports from the disposable use explicit `Export*` intents

This turns the common “open risky thing” action into an explicit, auditable flow rather than an ambient policy hack.

## Registries impacted
- Add D-PLUMB to decision map.
- Add CH-PLUMBMSG v0 and CH-ROUTE v0 to schema registry and add their specs.
- Optional: add new invariants and proof obligations:
  - I-PLUMB-1: router is non-amplifying (no authority creation)
  - I-PLUMB-2: portal grants are bound to a consent transcript (if D-POWERBOX enabled)
  - PO-PLUMB-NOAMP: capgraph diff tests show no unexpected edges after portal completion
  - PO-PLUMB-UI: if CH-VOL provided, the grant must match the rendered digest (fail-closed)

## Threat-model impact
New trusted components (if enabled):
- workflow router service (user space)
- optional portal UI backend(s)
Mitigations:
- keep router in user space; ensure it is restartable (D-SUPV)
- record all grants/denials in CH-LOG with deterministic digests
- add leak-tests using CH-CAPG snapshots before/after a portal session

## Evidence plan
E1: prototype router that mediates OpenFile via a minimal file chooser UI and returns view-scoped file caps.  
E2: fuzz + differential tests on rule evaluation; capgraph diff gate on portal completion.

## References
Refs: REF-PLAN9-PLUMB, REF-XDG-PORTAL, REF-XDG-PORTAL-OPENURI, REF-XDG-PORTAL-FILECHOOSER, REF-XDG-PORTAL-DOCUMENTS, REF-QUBES-CLIPBOARD, REF-APPLE-SECBOOKMARK, REF-SSB-CVE-2025 (cautionary), REF-PLAN9-PAPER.
