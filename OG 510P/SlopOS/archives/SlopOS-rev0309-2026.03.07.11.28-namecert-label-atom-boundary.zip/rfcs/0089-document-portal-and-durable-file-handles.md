# RFC-0089: Document portal + durable file handles (CH-DOCREF) (D-PLUMB/D-POWERBOX adjunct)

Status: Draft  
Updated: 2026-02-26  
Decision node(s): **D-PLUMB**, **D-POWERBOX**, D-VOLITION (optional), D-PERSIST (optional), D-EXPLAIN (optional), D-ENC

## Summary
Desktop/workflow sandboxes fail in practice if applications cannot:
- open a user-chosen file **without** receiving ambient host paths, and
- re-open that file later (recent documents, project files) **without** asking the user every time.

This RFC introduces **CH-DOCREF v0**: a **non-bearer**, redaction-aware “document handle” that lets a document portal re-issue a scoped file capability (or view node) to the original requester across restarts.

Key posture:
- Portals return **handles/caps**, not paths (RFC-0046).
- Persistence is **explicit** and transcripted (D-POWERBOX + CH-RECEIPT).
- Durability does **not** imply bearer access: a stolen CH-DOCREF must not grant authority.
- Phase 1 keeps `portal.file.*` **manual-only**, chooser defaults **ephemeral**, and any remembered-file management UI shell-owned rather than app-enumerable.

Adds:
- CH-DOCREF v0 schema + registry entry.
- Minimal assurance wiring (I-DOCREF-1/I-DOCREF-2; PO-DOCREF-VALIDATE/PO-DOCREF-REOPEN) + abuse case + evidence seed.
- Tightens RFC-0046 “document-store ID” note into a concrete artifact and safety posture.

## Motivation
A greenfield capability OS can avoid ambient paths, but a usable desktop ecosystem still needs:
- “Open…” and “Save…” workflows that return a capability-shaped handle.
- “Recent files” / “re-open last project” UX that survives restarts.

Existing ecosystems converge on mediated document access:
- **XDG document portal** exports selected files into a restricted view for sandboxed apps.  
- **macOS security-scoped bookmarks** provide persistence, but their threat surface has produced real sandbox escapes when key material or validation is mishandled.

We want the good part (durable UX) with strict, testable safety constraints:
- no implicit persistence,
- no path leakage,
- no bearer token “oops”,
- and monotonic revocation behavior compatible with D-PERSIST restore semantics.

Refs: REF-XDG-PORTAL-DOCUMENTS, REF-XDG-PORTAL-FILECHOOSER, REF-APPLE-SECBOOKMARK, REF-ANDROID-SAF-DOCUMENTS, REF-SSB-CVE-2025.

## Design goals
- **Adoptable**: enable “recent documents” and “project reopen” patterns without ambient path access.
- **Non-bearer**: CH-DOCREF alone is insufficient to regain authority (I-DOCREF-1).
- **Path-free**: portals may reveal UI strings, but they must not hand apps host paths (I-DOCREF-2).
- **Revocable**: user and policy can revoke persistent grants; revocation survives restarts/restore.
- **Bounded + canonical**: schema is small, validator is total and fail-closed.

## Non-goals
- Designing the full file system / storage model (views already cover name→cap mapping).
- Making “every open” persistent by default (we treat that as a footgun).
- Exporting document grants as shareable bearer tokens (use explicit sharing workflows if needed).

## Proposal

### 1) Introduce CH-DOCREF v0
Spec: `docs/30-architecture/document-handle-schema-v0.md`

CH-DOCREF is a small, canonical descriptor that identifies a portal-managed “document grant”:
- random `doc_id` for local indexing
- declared `rights` and `target_kind`
- optional expiry + revocation epoch metadata
- canonical origin binding (`origin.comp_id`) for non-bearer enforcement

CH-DOCREF contains **no host paths** and is **not** the authority itself.

### 2) Portal APIs (conceptual shape)
A document portal (often co-resident with the workflow router) supports:
- `export(ephemeral|persistent, file_cap_or_host_ref, rights) -> (docref, handle)`
- `open(docref) -> handle`  (or `open(doc_id)` with origin auth)
- `revoke(docref)` / `revoke(doc_id)`
- optional shell-owned `list()` for a user-facing “manage grants” UI (**not** an app-visible ambient inventory API in v0)

Where `handle` is:
- preferred: a **view-scoped capability** to a file/object (path-free), or
- an explicit binding inserted into the caller’s root view under a portal-owned prefix (e.g., `doc:/<id>`), still path-free relative to the host.

### 3) Persistence is explicit (no silent “always persistent”)
Persistence is only enabled when the user (or policy) explicitly chooses it:
- The open/save flow can present an explicit toggle (“remember this file”) or a clear UX affordance.
- Chooser defaults remain ephemeral; Phase 1 rejects silent “always persistent” defaults.
- If D-POWERBOX/D-EXPLAIN are enabled, the consent transcript and receipt must record persistence intent.

Rationale: ecosystems that silently persist document grants create unexpected long-lived access.

### 4) Stable target binding and rename/move semantics
A durable grant should survive rename/move of the file, but must not silently retarget:
- The portal stores and re-checks a stable object identity (inode/file-id equivalent) when reopening.
- If the underlying object identity changes (replace/swap), the portal must fail closed or require fresh consent (profile-defined).

### 5) Interaction with D-PERSIST / restore
If persistent grants are stored in CapStore or a portal-managed database:
- restoration must not resurrect revoked grants (align with D-PERSIST revocation epoch posture).
- policy can require re-validation or user re-consent after a restore event.

### 6) Integrate into D-PLUMB (RFC-0046)
Tighten RFC-0046 “document-store ID” into this concrete artifact:
- file chooser returns (a) a scoped handle, and optionally (b) a CH-DOCREF if persistence was explicitly requested.

## Assurance wiring
New invariants (seed):
- **I-DOCREF-1 (Document refs are non-bearer, optional)**: if CH-DOCREF is used, a docref alone is insufficient to regain authority; the portal must authenticate the requestor and enforce `origin.comp_id` binding (and policy) before issuing any handle.
- **I-DOCREF-2 (No path leakage + stable binding, optional)**: if CH-DOCREF is used, the portal never returns host paths to sandboxed apps, and reopening re-checks stable target identity; replaced targets fail closed or require fresh consent; rights are clamped to the stored grant.
- **I-DOCREF-3 (Explicit persistence + no inventory amplification, optional)**: if CH-DOCREF / `portal.file.*` is enabled, Phase 1 keeps chooser results ephemeral by default; `persistent=true` is minted only by explicit user/policy choice; applications have no ambient inventory/list API for prior grants; and reopened handles may not widen rights or target scope beyond the stored grant.

New proof obligations (seed):
- **PO-DOCREF-VALIDATE**: CH-DOCREF decoding/validation is canonical, total, and bounded.
- **PO-DOCREF-REOPEN**: portal reopen logic enforces origin binding, revocation/expiry, and stable-target checks; returned handles are path-free and non-amplifying.
- **PO-DOCREF-ENF**: chooser/export policy keeps `portal.file.*` manual-only in v0, makes persistence explicit, keeps grant-management UI shell-owned, and clamps reopen rights/target scope to the stored grant.

New abuse case (seed): AC-076  
Evidence plan: EVID-2026-087

## Alternatives
- **Paths + sandbox filters**: leaks ambient authority, encourages confused-deputy flows, and is brittle under symlinks/rename.
- **Pure sturdyrefs as persistence**: powerful but easy to accidentally make bearer; CH-DOCREF explicitly bakes in non-bearer posture.
- **Always persistent grants**: convenient but a security footgun; requires strong, explicit UX and manageable revoke lists.

## References
REF-XDG-PORTAL-DOCUMENTS, REF-XDG-PORTAL-FILECHOOSER, REF-APPLE-SECBOOKMARK, REF-ANDROID-SAF-DOCUMENTS, REF-SSB-CVE-2025.

## History
- Phase 1 pinned posture is now captured in `docs/30-architecture/document-portal-posture-v0.md`: `portal.file.*` stays manual-only, persistence is explicit, reopen is non-bearer and non-widening, and any remembered-file inventory remains shell-owned.
