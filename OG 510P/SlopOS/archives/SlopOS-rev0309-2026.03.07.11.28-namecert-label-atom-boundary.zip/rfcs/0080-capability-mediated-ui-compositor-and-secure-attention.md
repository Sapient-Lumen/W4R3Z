# RFC-0080: Capability-mediated UI compositor + secure attention (D-UICAP)

Status: Draft  
Updated: 2026-02-25  
Decision node(s): D-UICAP, D-UIAUT, D-VOLITION, D-PLUMB, D-LEASE

## Summary
Define an optional **UI isolation contract** that makes the desktop/UI ecosystem compatible with least privilege by default:

- A **user-space compositor/UI root** is the only component that touches raw input devices and display scanout.
- Applications interact with the desktop through **object capabilities** (surface handles, view tokens, input endpoints), not global window IDs.
- High-risk UI capabilities (screen capture, global input injection, remote control) are only available via **portal workflows** (D-PLUMB) and SHOULD be **leased** (D-LEASE).
- Add an optional **secure attention sequence** (SAS) to enter a “secure UI mode” for login/consent surfaces, mitigating fake-login and clickjacking-style UX attacks.

This RFC does **not** pick a rendering stack, window decorations, toolkit API, or remote-display protocol. It pins only the minimal security/authority seams so the rest can evolve.

## Motivation
Greenfield OSes routinely lose security posture at the UI boundary:

- X11-style ambient window global state makes screen scraping, global keylogging, and focus confusion easy.
- “Convenience” APIs for screenshots, global hotkeys, accessibility, and automation become implicit ambient authority.
- Consent dialogs can be spoofed by fake windows unless there is a trusted UI path.

Wayland’s operational lesson is that **routing + isolation belong in the compositor**: clients do not access other clients’ surfaces and do not know global surface position; input is delivered to the focused surface. That improves confidentiality/integrity, but pushes legitimate “global” features into a mediation layer.

We already have D-POWERBOX/D-VOLITION/D-PLUMB for *workflow* consent; D-UICAP is the missing glue that makes the everyday desktop ecosystem compatible with those constraints.

## Integration seam / kernel impact (stay small)
Keep UI logic out of the kernel. Kernel assumptions:

1) Device capability assignment exists (D-DRVDOM): raw input devices and scanout/graphics device access are assigned to the UI root component by CH-COMP/CH-INIT (or equivalent).
2) IPC and capability handles are unforgeable (I-CAP-1).
3) Optional: a small “secure attention” event can be delivered to the UI root in a way normal apps cannot intercept.

Everything else is user space:
- compositor protocol
- focus policy
- portal UIs (screen capture, remote desktop)
- accessibility tooling

## Design

### A) Object-capability UI model
The UI root exposes a small set of capability-shaped interfaces (names illustrative):

- `UiCompositor`: create and manage surfaces/views; request focus; enumerate attached displays under explicit rights.
- `UiSurface`: a capability representing one renderable surface; can attach buffers; commit frames.
- `UiInputEndpoint`: a capability representing delivery of input events to the holder (keyboard/pointer/touch), scoped to a focus chain and rights.
- `UiToken` / `ViewRef`: an opaque token representing identity/lifecycle of a view/surface (for focus chain membership and routing), safe to hand around without granting control.

Properties:
- **No global window IDs.** If you don’t hold the surface capability, you cannot affect or observe it.
- **No ambient screen readback.** Frame contents are private to the surface owner and the compositor.
- **Focus is explicit state** held by the compositor, and input delivery is a deterministic function of focus chain + rights.

### B) Focus-gated input delivery
Default rule:
- input events are delivered only to the currently focused surface(s) according to a compositor-defined focus chain.

Non-default behaviors are explicit capabilities:
- global hotkeys: `UiHotkey` capability minted only for trusted/system components
- accessibility/assistive tech: capabilities minted via portal-mediated **sessions** (D-UIAUT) that default to observation-only (no injection) and are leased/auditable (CH-UIAUT)
- automation/testing: dedicated `UiAutomation` sessions (ideally dev/test only) with explicit injection rights, TTL, and shell indicators (see RFC-0099)

### C) Screen capture and remote control are portal workflows
Screen capture, screencast, and remote desktop are treated as **high-risk authority** and MUST be mediated:

- `portal.screenshot` / `portal.screencast` sessions present an origin-branded UI and return a *leased* capture capability (D-LEASE) with explicit scope (window/screen/region), TTL, and renewal rules.
- `portal.remotedesktop` returns a leased remote-control capability that includes input injection rights.

The portal SHOULD emit a bounded **CH-CAPTURE v0** descriptor (digest logged/receipted) for each capture session, to make scope/TTL/attribution auditable without embedding pixels/bytes.
See: RFC-0095.

The UI root is not required to implement the portals itself; it only must expose enough capability hooks for portal services to request captures under policy.

### D) Secure attention sequence (optional)
Add an optional SAS concept: a reserved key chord or hardware event that is delivered only to the secure UI component and cannot be intercepted or simulated by normal applications.

Operational pattern (recommended):
- SAS switches into a **secure UI mode** (“secure desktop” / trusted shell) that is visually distinct and can host login/unlock and other high-risk consent flows.
- In secure UI mode, normal surfaces are frozen/occluded; only the secure UI component receives input; screen capture and input injection are disabled unless explicitly granted by policy.
- The secure UI component can present consent UI that is spoof-resistant by construction (no other app can draw over it or receive its input).

Threats addressed: fake-login overlays, consent spoofing/clickjacking, and “global hook” input snooping.

### F) Secure input sessions (optional)
Some sensitive entry happens *outside* login/lock flows (password fields, PIN prompts, terminal “secure keyboard entry”). Borrow a pragmatic pattern from macOS: a short-lived **secure input session** that suppresses non-authorized keyboard interception (and optionally injection) while a sensitive field is focused.

Model this as a lease:
- the UI root (or secure UI mode) acquires a `SecureInputLease` capability with a strict TTL and explicit release;
- while active, only the focused target(s) receive keyboard events; non-authorized global key taps do not receive keystrokes;
- if the lease expires or is revoked, the system returns to normal focus-gated delivery.

Safety posture:
- TTL + rate limits to avoid “stuck secure input” DoS
- visibility: the UI root SHOULD expose an indicator when secure input is active (inspect + optional UI chrome)
- compatibility: only enabled in profiles that accept the reduced “global hotkey”/automation surface during sensitive entry

### E) Relationship to D-VOLITION
D-VOLITION binds a gesture to an action digest via CH-VOL. D-UICAP ensures the UI root’s gesture capture path is **exclusive** and focus-correct.

Recommended composition:
- Sensitive portal flows require both (a) SAS entry OR an equivalent “secure mode” and (b) approvals bound via CH-VOL.

## Registries impacted

### Decision map
- Add **D-UICAP** (this RFC).

### Invariants
- **I-UICAP-1 (Surface isolation, optional):** if D-UICAP is enabled, a component can present, modify, or obtain pixels for a surface only if it holds the corresponding `UiSurface` capability (or a leased derivative). No other API reveals other clients’ pixels.
- **I-UICAP-2 (Focus-gated input, optional):** if D-UICAP is enabled, input events are delivered only to recipients determined by the compositor focus chain and explicit rights; global interception/injection requires an explicit high-trust capability.
- **I-SAS-1 (Secure attention delivery, optional):** if SAS is enabled, the secure attention event cannot be intercepted by normal applications and is delivered only to the configured secure UI component(s).

### Proof obligations
- **PO-UICAP-FOCUS:** focus chain and input routing are total/deterministic; unfocused clients cannot receive input; injection paths are capability-gated.
- **PO-SAS-DELIVER:** SAS delivery is exclusive to the secure UI component(s) and cannot be simulated by normal applications.

### Threat model
- Add **AC-068** (UI spoofing / input snooping / screen scrape).

### Evidence plan
- Add evidence seed **EVID-2026-078** for a compositor harness:
  - negative tests: unfocused client receives no input; client cannot request pixels of another surface; capture requires portal lease
  - property tests: focus-chain transitions are deterministic; SAS event cannot be delivered to non-UI-root targets
  - negative tests: secure-input session suppresses non-authorized global key taps; TTL/expiry returns to normal focus-gated delivery
- Add evidence seed **EVID-2026-095** for SAS + secure-input integration:
  - SAS enters secure UI mode (secure desktop) and is visually distinct; secure UI mode occludes normal surfaces
  - secure input cannot be held indefinitely (TTL + explicit release); stuck-on detection has a deterministic recovery path

## Alternatives
- “Just run Wayland”: useful precedent, but this RFC is about *capability discipline and consent integration*, not picking a Linux desktop stack.
- Put UI into the kernel: rejected (TCB explosion).
- Allow ambient screen capture for compatibility: rejected for default profiles; keep it as an explicit dev/test capability if required.

## References
REF-WAYLAND-CH04, REF-XDG-PORTAL-SCREENSHOT, REF-XDG-PORTAL-SCREENCAST, REF-XDG-PORTAL-REMOTEDESKTOP, REF-FUCHSIA-VIEWREF, REF-FUCHSIA-FOCUSCHAIN, REF-MS-WINLOGON-SAS, REF-IBM-AIX-TRUSTEDPATH, REF-APPLE-TN2150-SECEVENTINPUT.
