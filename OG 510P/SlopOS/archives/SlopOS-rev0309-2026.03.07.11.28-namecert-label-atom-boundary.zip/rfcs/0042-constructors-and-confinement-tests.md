# RFC-0042: Constructor objects and confinement tests (D-CONSTR)

Status: Draft  
Last updated: 2026-02-25

Goal: make “build a confined subsystem” a **repeatable, auditable pattern** by standardizing **constructor components** (user-space factories) and a **confinement test** that detects authority leaks using our existing cap-graph / transcript seams.

Motivation sources: KeyKOS/EROS “constructors” and confinement reasoning (incl. mechanized arguments for the confinement mechanism), plus the broader capability-systems lesson that *construction is where ambient authority sneaks in*. Refs: REF-KEYKOS-NANOKERNEL, REF-KEYKOS-ARCH85, REF-KEYKOS-OSR92, REF-EROS-CONFINEMENT, REF-CAPMYTHS.

Non-goals:
- A kernel-resident “constructor framework” (keep TCB small).
- Magical global guarantees (“all constructed subsystems are safe”) without explicit scopes and evidence.
- Making constructors mandatory for all software.

## Problem
Even if the kernel/hypervisor is capability-pure, **composition is where mistakes happen**:
- a template accidentally leaves a powerful capability reachable,
- a helper service holds “just-in-case” authority forever,
- post-init wiring silently widens authority.

We already have seams that can make these failures visible:
- CH-COMP (D-COMP) for declared wiring,
- CH-LOG transcripts for effect provenance,
- D-CAPAUD cap-graph export + leak tests (RFC-0035).

What’s missing is a **first-class pattern** for “stamp out this subsystem repeatedly without re-auditing a new pile of init code every time.”

## Proposal

### 1) Define “constructor components” as normal components
A **constructor** is a standard user-space component that:
- receives a **template reference** (digest of a pinned artifact set; typically CH-COMP and/or CH-INIT fragments),
- receives a small **parameter object** (names, sizes, policy knobs) that is *data, not authority*,
- returns a **sealed handle** to the constructed subsystem plus an explicit set of exported capabilities (the public surface).

Key rule: the constructor may only *use* authority it already holds. Construction never justifies adding privileged mechanisms.

### 2) Treat the constructor boundary as an explicit authority boundary
For each constructor, we define a boundary contract:

- **Inputs (authority in):** the capabilities passed to the constructor (including any template fetch capability, space bank, etc.).
- **Outputs (authority out):** the exported surface capabilities returned to the caller.

Confinement means: **no other authority crosses the boundary**, and the constructed internal graph cannot retain backchannels that let the caller gain more than the outputs.

### 3) Standard “confinement test” based on cap-graph diffs
Leverage D-CAPAUD (RFC-0035) to define a standard test:

1. Export a **capability graph snapshot** of:
   - the caller before construction (baseline),
   - the constructor + subsystem after construction (post-state),
2. Compute a bounded **authority delta** at the boundary:
   - the only new “caller-reachable” authorities are the declared constructor outputs,
   - no “leaked” references to internal capabilities exist outside the declared exports,
3. Optionally, run “negative tests” by revoking/attenuating the exported surface and verifying the caller cannot still reach the internal objects (interacts with D-MEMBRANE / RFC-0019).

This is not a proof by itself, but it is a **high-signal regression test** that catches the common failure modes early.

### 4) Integration points (minimal)
- **D-COMP / CH-COMP:** templates are pinned and linted; constructors can emit CH-LOG entries tying instantiation to template digests.
- **D-SEAL:** constructors should run an init→seal transition for constructed services when applicable.
- **D-METER / D-KOBJQ:** constructors are natural sites to “charge” creation costs to a budget/space bank so subsystems can be garbage-collected and accounted.
- **D-CHKPT (optional):** constructor outputs can be checkpointed as a unit for “factory reset” or migration.

## Candidate invariants / proof obligations
- **I-CONSTR-1 (Constructor confinement, optional):** if D-CONSTR is enabled for a constructor template, the only new caller-reachable authority introduced by instantiation is the declared exported surface; no other authority leaks across the boundary.
- **I-CONSTR-2 (Deterministic construction, optional):** given the same template digests and the same parameter object, the constructor produces the same exported surface structure (up to declared nondeterminism like fresh object IDs).
- **PO-CONSTR-CONFINE:** confinement tests (cap-graph export + delta checks) are sound w.r.t. the declared boundary predicate and fail closed when bounds are exceeded.
- **PO-CONSTR-REPLAY (optional):** constructor events are transcript-logged with enough detail (digests + parameter hashes) to reproduce the construction in replay/testing modes.

## Evidence plan (stageable)
E1 (prototype-to-evidence):
- implement a minimal constructor (e.g., “sandboxed worker pool” or “translator-backed mount service”)
- implement the confinement test harness using the cap-graph exporter

E2 (model-check fast):
- model a small constructor + graph and search for leak counterexamples (align with RFC-0035 methodology)

E3 (mechanize boundary):
- represent the boundary predicate in the abstract machine and show refinement for a bounded constructor interface

## Alternatives
1) **No constructors**: copy/paste init logic per subsystem.  
   - Con: repeated audits; high leak risk.

2) **Templating without confinement tests**.  
   - Con: “policy-as-data” without regression evidence tends to drift.

3) **Kernel-level constructors**.  
   - Con: TCB expansion and proof surface increase; likely unacceptable early.

## Open questions
- What is the minimal parameter language that stays “data, not authority” (avoid stringly capability lookup)?
- How to represent “freshness” and identity in deterministic-construction claims without overspecifying?
- How tightly should constructors integrate with D-MEMBRANE and revocation (RFC-0019) for teardown?

