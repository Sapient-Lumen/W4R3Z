# RFC-0097: Data contracts + migration gates for atomic updates (adjunct)

Status: Draft  
Updated: 2026-02-26  
Decision node(s): D-ATOMICUPD (adjunct), D-PERSIST (adjunct), D-FPM (optional), D-HEALTH (optional)

## Summary
Atomic deployments (D-ATOMICUPD) make **code** rollback routine, but they do not automatically make **mutable data** rollback-safe.
This RFC adds a *tight, low-TCB* seam:

- represent per-dataset compatibility as **data contracts** declared in CH-CFG,
- require update tooling to validate *read compatibility* before activation,
- introduce an explicit **migration gate**: if an upgrade performs a breaking data write, it must either (a) take a snapshot (D-PERSIST) and record a rollback barrier or (b) declare that rollback requires restoring a compatible dataset snapshot.

The privileged core stays unchanged: this is a user-space update discipline with schema-pinned declarations that can be audited.

## Motivation
Without an explicit data compatibility model, “rollback” becomes a trap:
- the new deployment may upgrade a database/object-store format,
- a rollback boots an older deployment that cannot read the upgraded data,
- operators get a *false sense of safety* and failures become harder to diagnose.

We already call out the classic NixOS footgun (“rolling back code ≠ rolling back mutable state”) in the configuration pipeline doc.
This RFC turns that warning into a concrete, testable seam.

## Design

### 1) Data contracts in CH-CFG
Extend CH-CFG v0 with an optional, bounded list of dataset contracts:

`data_contracts: [ { dataset, writer_rev, reader_min, rollback_floor?, notes_tag? } ]`

Semantics:
- `dataset`: stable identifier (reverse-DNS or similar), e.g., `org.example.maildb`.
- `writer_rev`: the **current** format revision the deployment will write.
- `reader_min`: the **minimum** format revision the deployment can read.
- `rollback_floor` (optional): minimum `writer_rev` the updater/boot selector may roll back *to* without also restoring a dataset snapshot.
  - If absent, rollback safety is determined by `reader_min` checks at activation time.
- `notes_tag` (optional): a small, bounded string tag for operator display (non-authoritative).

Constraints:
- list size is bounded (profile-defined cap)
- numeric values are bounded (u64)
- unknown/malformed entries fail validation when D-ATOMICUPD profiles require data contracts

### 2) Dataset metadata: what the system records
Each dataset stores a small metadata record in-band or adjacent:
- `dataset`
- `current_rev` (writer revision that last wrote)
- `last_migration_id` (optional, for audit)

This record is **not** trusted input for authorization; it is used by the updater to decide safe activation and by diagnostics tooling to explain failures.

### 3) Activation checks (pre-boot gate)
Before staging/activating a deployment, the updater must check:

For each declared `dataset`:
- if dataset exists, require: `current_rev >= reader_min` for the new deployment
- if not, allow initialization (first writer chooses `writer_rev`)

If the check fails, activation is refused unless an explicit migration step is executed.

### 4) Migration gates + rollback barriers
A migration step is user-space logic that updates dataset bytes and then updates `current_rev`.

We support two safe patterns:

**A) Expand/contract (preferred)**
- upgrade writes in a new format while remaining readable by older code (within a window)
- `reader_min` stays low until the fleet passes a safety point

**B) Breaking migration with snapshot barrier (explicit)**
- if a migration increases `writer_rev` beyond what old deployments can read, the updater must:
  1) create a dataset snapshot (D-PERSIST; CH-CKPT or FS snapshot),
  2) record a rollback barrier: `dataset`, `from_rev`, `to_rev`, and the snapshot digest/reference,
  3) only then advance `current_rev`.

Rollback across a barrier is only allowed if the rollback operation also selects/restores the recorded snapshot (or another compatible snapshot).

### 5) Interaction with D-ATOMICUPD health-commit
If CH-BOOTSEL + health-commit (D-HEALTH) is used:
- a deployment should not be marked successful until required migrations complete and dataset contracts are satisfied.
- migration failures should be surfaced as a structured health predicate failure (CH-HEALTH), not as silent crash loops.

## Invariants and obligations
Additions (optional, when D-ATOMICUPD profiles enable data contracts):

- **I-ATOMICUPD-4 (Data rollback is explicit, optional)**: a rollback operation must not transition the system into a state where the active deployment’s declared `reader_min` is violated by the current dataset revision, unless the rollback explicitly restores a compatible dataset snapshot.

Proof obligation:
- **PO-ATOMICUPD-DATA**: activation/rollback tooling enforces the above rule deterministically and records decisions (dataset id, revs, snapshot refs) in transcript logs.

## Threat-model impact
This seam primarily reduces operational failure modes and narrows ambiguity for incident response.
It does not claim to prevent malicious corruption of data by an authorized writer.

## Evidence plan
- **EVID-2026-096**: harness that simulates:
  - upgrade with expand/contract compatibility window,
  - upgrade with breaking migration + snapshot barrier,
  - attempted rollback without restoring snapshot (must fail closed),
  - rollback with snapshot restore (must succeed),
  - crash-loop case where health-commit must not mark deployment successful.

## References
Refs: REF-NIXOS-MANUAL, REF-NIX-MANUAL-ROLLBACK, REF-RPM-OSTREE, REF-FEDORA-ROLLBACKS, REF-SOLARIS-BOOTENV, REF-FREEBSD-BECTL.
