# RFC-0053: Origin metadata + quarantine + safe-open defaults (D-QUAR)

Status: Draft  
Updated: 2026-02-24  
Decision node(s): D-QUAR, D-EPHEM, D-PLUMB, D-POWERBOX

## Summary
Add a first-class concept of **origin** and **quarantine** to reduce real-world “download → execute/open → persist” failures.

Core idea:
- objects created from risky sources carry **origin + quarantine attributes**,
- quarantine is **monotonic** until an explicit, logged clear,
- opening/executing quarantined objects routes through a **safe-open** path:
  - disposable domain by default (D-EPHEM),
  - explicit export only (D-PLUMB),
  - optional sanitize-export pipeline (future RFC).

Refs: REF-MOTW-ZONEID, REF-MACOS-GATEKEEPER, REF-GATEKEEPER-BYPASS, REF-MS-PREVIEW-MOTW.

## Problem
Most compromises start with a user interaction with an object of unclear provenance:
- a downloaded document,
- an email attachment,
- a file extracted from an archive,
- a “helpful” script pasted from the internet.

Existing OSes have partial defenses (Mark-of-the-Web, Gatekeeper quarantine), but bypasses are common when:
- metadata is not propagated through containers/extraction,
- clearing happens implicitly or invisibly,
- applications ignore the tag and open/execute anyway.

We already have strong building blocks (disposables + portals/powerbox). We need an ecosystem default that connects them.

## Goals
- Preserve and propagate “this came from outside” signals.
- Make safe behavior the default without banning user choice.
- Provide a **small, testable contract**: quarantine is monotonic; clearing is explicit and logged.
- Ensure “safe-open” composes with disposables and portals.

## Non-goals
- Perfect malware detection.
- A universal file reputation service.
- Solving all covert channels; we focus on the dominant user-facing path.

## Proposed design

### A) Attribute set (D-ATTRFS friendly)
When D-ATTRFS is enabled, the following attribute keys are declared (CH-ATTR v0):
- `origin.source` (enum): {network, email, removable, ipc, unknown}
- `origin.locator_hint` (string, optional): human-facing hint (not authoritative)
- `origin.time` (u64): unix seconds
- `origin.chain_digest` (digest, optional): digest of a provenance chain object if CH-PROV is enabled

- `quarantine.state` (enum): {none, quarantined, cleared}
- `quarantine.reason` (enum): {download, attachment, extracted, unknown}
- `quarantine.cleared_by` (string, optional): stable identifier for the clearing workflow / policy

See: docs/30-architecture/origin-quarantine-attrset.md

### B) Monotonic propagation rules
- Any object created from a quarantined object is quarantined unless:
  - it is an explicit, policy-allowed “safe export” action that produces a new artifact with a logged justification, or
  - a user explicitly clears quarantine via the consent mediator (see below).
- Archive extraction propagates quarantine to extracted entries.
- Copies across domains preserve quarantine unless explicitly cleared.

### C) Safe-open default routes
If `quarantine.state == quarantined`, the default open/execute path is:
1) Open in disposable domain (D-EPHEM) with a restricted view namespace, and
2) Require explicit export (D-PLUMB) to persist results in trusted locations.

This applies to:
- execution of binaries/scripts,
- “open” of documents by risky parsers,
- importing into interpreters / REPLs.

### D) Clearing quarantine is explicit + logged
Clearing requires:
- a user-visible action in IF-CONSENT/powerbox,
- transcript logging (CH-LOG) with the object digest and a “clear reason” token,
- optional policy constraints (e.g., only clear after signature verification).

Clearing is a capability-mediated effect; it is not an app-private bit.

## Pinned v0 posture follow-up (2026-03-06)

Phase 1 narrows D-QUAR further in `docs/30-architecture/quarantine-posture-v0.md`:
- clearing is **manual-only, object-local, and non-recursive**,
- safe-open / preview does **not** mutate the source object’s trust state,
- and any dequarantined/sanitized materialization is a **new artifact** with its own digest + transcript-visible reason rather than an in-place laundering step.

This keeps D-QUAR small enough to implement honestly: “trust this one object” is explicit, “trust this whole tree/archive forever” is not, and verification/notarization/scanning may inform the decision but do not silently auto-clear quarantine.

## Security considerations
- Avoid “implicit clearing” behaviors (opening in a viewer must not auto-clear).
- Container bypasses (disk images, nested archives) are the first attack to test.
- Treat `origin.locator_hint` as non-authoritative to prevent spoofing.

## Alternatives considered
- Rely on app-specific download tagging (too inconsistent).
- Block execution/open outright (bad UX; encourages disabling protections).
- Central reputation servers (privacy + complexity).

## Required invariants / proof obligations / evidence plan
Invariants:
- I-QUAR-1, I-QUAR-2, I-QUAR-3, I-QUAR-4, I-QUAR-5.

Proof obligations:
- PO-QUAR-PROP (propagation),
- PO-QUAR-GATE (safe-open routing),
- PO-QUAR-CLEAR (explicit + logged clearing),
- PO-QUAR-LOCAL (object-local clear; new-artifact safe export).

Evidence targets:
- EVID-2026-043 (E1): extraction + copy propagation test suite
- EVID-2026-044 (E2): corpus of “laundering” attempts (nested archive, disk image, rename) + regression harness
