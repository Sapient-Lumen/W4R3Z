# RFC-0087: Triage rules and on-device diagnosis predicates (D-TRIAGE)

Status: Draft  
Updated: 2026-02-26  
Decision node(s): **D-TRIAGE**, D-INSPECT, D-OBS, D-OBSPOL, D-ENC, D-TRACEPROC (optional)

## Summary
Introduce **CH-TRIAGE v0**: a pinned, bounded **rule set** for on-device diagnosis that can:

- evaluate **local state** (CH-INSPECT snapshots) and/or a failure artifact (CH-CRASHCAP),
- emit **deterministic findings** (tags/codes + short bounded explanations), and
- request a **bounded next step** (e.g., “assemble sanitized snapshot with these entry kinds”, or “ask operator for full tier”).

Core stance: triage rules are **non-authoritative** and **veto-only** with respect to export. They can *recommend* collection/export within policy, but cannot widen authority beyond **CH-OBSPOL** and any required portal/consent workflows.

## Motivation
Operational reality:
- when something breaks, teams reach for “dump everything,”
- the resulting artifacts are often too large, too sensitive, and too hard to interpret,
- and many incidents are diagnosable from **a small set of structured facts**.

A greenfield OS can make “small, shareable, policy-scoped diagnostics” a default by:
- standardizing **bounded, deterministic rule evaluation** over pinned artifacts,
- making rule sets themselves reviewable and testable,
- and wiring triage into existing **export policy** and **snapshot** seams.

Prior art:
- **Fuchsia `fx triage`**: selectors + eval expressions + actions + tests over Inspect/snapshot data.  
- **Prometheus alerting rules**: declarative predicates over a bounded data model, driving operator actions.  
- **osquery packs**: curated, scheduled queries to collect only the data needed for a purpose.
- **Solaris FMA**: typed error reports (ereports) feeding diagnosis engines and response agents; a precedent for “structured faults → deterministic findings → bounded responses.”

Refs: REF-FUCHSIA-TRIAGE, REF-PROMETHEUS-ALERT-RULES, REF-OSQUERY-CONFIG, REF-SOLARIS-FMA-OVERVIEW.

## Design goals
- **Deterministic + bounded**: no embedded scripting VM; closed operator set; bounded evaluation cost.
- **Artifact-first**: inputs are CH-* objects (typically CH-INSPECT / CH-CRASHCAP) with canonical bytes.
- **Non-authoritative**: outputs can only request actions already gated by policy/capabilities.
- **Testable**: rule sets can include small golden inputs and expected outputs.

## Non-goals
- Replacing full observability stacks (metrics pipelines, APM).
- Proving “no sensitive data ever leaves the device.”
- Arbitrary programmable logic or user-supplied plugins in the privileged core.

## Proposal

### 1) New decision seam: D-TRIAGE
D-TRIAGE decides whether we standardize a **portable triage rules format**.

When enabled:
- CH-TRIAGE v0 is used by diagnostic tooling (local monitors, crash handlers, snapshot assemblers),
- evaluation is deterministic and bounded, and
- any requested export/collection remains constrained by CH-OBSPOL + portal workflows.

### 2) CH-TRIAGE v0 (rule set)
Spec: `docs/30-architecture/triage-rules-schema-v0.md`

High-level shape:
- `selectors`: named extractors over allowed input artifacts (Inspect-path selectors, crash metadata selectors)
- `derived`: bounded expressions over selector values
- `rules`: ordered list of `if predicate then actions`
- `tests`: optional small embedded test vectors

We intentionally choose **ordered rules** with first-match or “accumulate tags” semantics to keep evaluation simple.

### 3) Actions are advisory and bounded
Allowed actions (closed set):
- `emit_tag(tag)` — bounded diagnostic labels (e.g., `"storage.full"`, `"net.dns"`)
- `emit_finding(code, severity, hint)` — code + severity + short bounded hint string
- `request_snapshot(entry_kinds, tier)` — request that a snapshot assembler attempt to include only these entry kinds under the requested tier (`sanitized` default)
- `request_escalation(reason_code)` — request an operator/portal flow for `full` export tier or a sensitive payload kind

Hard rule: **actions cannot directly trigger export**. Export is still capability-gated and policy-scoped.

### 4) Binding to export policy (no authority amplification)
A snapshot assembler that consumes CH-TRIAGE MUST:
- treat requested `tier` and `entry_kinds` as **inputs to the CH-OBSPOL allowlist**,
- fail closed if the request exceeds the active CH-OBSPOL bounds/allowlist,
- and make the applied policy digest audit-visible (I-OBSPOL-1).

Optional: for escalations, require a portal workflow that binds the escalation request to a receipt (D-EXPLAIN), keeping “why was full export allowed?” mechanically answerable.

### 5) Where triage runs
- **Crash path**: the crash handler assembles a CH-CRASHCAP, then runs triage rules over it to decide whether a sanitized snapshot should also be assembled (or whether escalation is needed).
- **Local monitoring**: a monitor periodically evaluates rules over local inspect snapshots and emits bounded findings/alerts.

No kernel involvement is required.

## Threats and abuse cases
- **AC-075 (Triage-triggered sensitive export / DoS)**: attacker manipulates observable state (logs/inspect) to trigger “collect more” or “ask for full export” repeatedly.

Mitigations:
- triage is advisory; actual export remains policy- and capability-gated (I-OBSPOL-1, I-SNAP-1)
- bounded rule evaluation and bounded actions (I-TRIAGE-1)
- rate limits and budgets belong in export tooling/portals (D-BUDGET / D-METER adjunct), not in rule logic

## Assurance wiring
New invariants (seed):
- **I-TRIAGE-1 (Triage rules are bounded + deterministic, optional)**: if CH-TRIAGE is used, rule decoding and evaluation are total, closed-set, and bounded; unknown operators reject deterministically.
- **I-TRIAGE-2 (Triage is non-authoritative, optional)**: triage outputs cannot widen export authority; snapshot/export tooling enforces CH-OBSPOL and capability checks regardless of triage requests.

New proof obligations (seed):
- **PO-TRIAGE-VALIDATE**: CH-TRIAGE decoding/validation is canonical, total, and enforces bounds.
- **PO-TRIAGE-EVAL**: evaluation is deterministic and reads only declared selector inputs; action emission is bounded.

## Evidence plan
- validator tests: unknown keys/opcodes reject; bounds enforced; canonical encoding
- golden evaluation tests: fixed CH-INSPECT / CH-CRASHCAP inputs yield stable findings and requested snapshot shapes
- negative tests: triage requests that exceed CH-OBSPOL are rejected (no partial export) and are audit-visible

## Alternatives
- **Hardcoded heuristics**: simplest, but drift-prone and not auditable.
- **Full metrics/alert DSL (PromQL)**: powerful, but too large for our pinned-schema posture.
- **Ad-hoc JSON rules**: common, but tends to become an unbounded scripting surface.

## References
REF-FUCHSIA-TRIAGE, REF-PROMETHEUS-ALERT-RULES, REF-OSQUERY-CONFIG.
