# RFC-0076: Observation export policy-as-data (CH-OBSPOL) (D-OBSPOL)

Status: Draft

Decision node(s): D-OBS, D-OBSPOL, D-ENC

## Summary
Introduce **CH-OBSPOL v0**: a pinned, bounded “export policy” artifact that makes the allowed **diagnostics/telemetry export surface** explicit and machine-checkable.

CH-OBSPOL is used by:
- **IF-OBS** exporters assembling CH-OBS payloads,
- **snapshot tooling** assembling CH-SNAPSHOT bundles (D-INSPECT), and
- offline verifiers/auditors checking that an export/bundle obeyed the declared allowlists and bounds.

## Motivation
The archive’s posture has been consistent: observability is valuable, but it is also a *data exfiltration surface*.

Without an explicit policy artifact, teams drift toward:
- ad-hoc “dump endpoints,”
- string scrubbing (regex-based redaction),
- unreviewable per-tool heuristics, and
- “just attach a full bugreport” incident workflows.

A greenfield OS can do better: **pin what we export**, keep it **bounded**, and make the decision **auditable**.

## Goals
- Make “what leaves the device” explicit and reviewable.
- Keep enforcement deterministic and fail-closed.
- Avoid scripting/regex engines or other unbounded mechanisms.
- Allow multiple tiers (sanitized default, operator-authorized full) without changing core schemas.

## Non-goals
- Rich data-loss-prevention (DLP) engines.
- Proving perfect secrecy of all exported data.
- Replacing human incident review workflows.

## Design
### 1) Policy artifact: CH-OBSPOL v0
CH-OBSPOL defines:
- an export **tier** (`sanitized` vs `full`),
- allowlists for **payload classes** (logs/trace/cap graphs/labels/etc),
- optional enablement + allowlist for **snapshot entry kinds**,
- an allowlist of **redaction classes** (`public|sanitized|sensitive`),
- hard **bounds** (total bytes, per-entry bytes, entry counts), and
- explicit **forbid flags** (no sturdyrefs, no raw addrs, no secret caps).

Spec: `docs/30-architecture/observation-export-policy-schema-v0.md`.

### 2) Enforcement points
- **IF-OBS exporter** MUST consult the active CH-OBSPOL (if enabled) before emitting any CH-OBS payload.
- **CH-SNAPSHOT assemblers** MUST consult the policy designated by the snapshot workflow (or the snapshot’s `redaction_profile` tag/digest).
- Violations MUST fail closed and emit bounded error diagnostics (not partial exports).

### 3) Binding and audit visibility
A profile may choose how to make the applied policy digest audit-visible:
- include the policy digest in export transcript metadata (CH-LOG),
- include it as the `redaction_profile` digest in CH-SNAPSHOT,
- include it in any outer “envelope” (e.g., signed email/support upload metadata).

The key property: **recipients can see which policy was claimed and compare against what was received**.

### 4) Interaction with D-INSPECT
D-INSPECT adds bounded structured state (CH-INSPECT) and support/incident bundles (CH-SNAPSHOT). CH-OBSPOL provides a single “choke point” for export rules:
- sanitized policies can allow `inspect` entries while denying `trace_window` or `crash_dump` by default
- full policies can permit those kinds behind explicit authority

### 5) Triage rules as a separate artifact (CH-TRIAGE)
Fuchsia's "triage" tooling suggests a useful next layer: **on-device rules that decide what to collect or request**, using bounded rule sets rather than ad-hoc heuristics.

We keep CH-OBSPOL v0 *non-programmable*: it stays a static allowlist+bounds artifact.
If D-TRIAGE is enabled, a separate pinned rule artifact (CH-TRIAGE) may produce **advisory** snapshot requests (tier + entry kinds) and bounded findings, but exporters MUST still enforce CH-OBSPOL and capability gates.

See: RFC-0087.

## Alternatives considered
- **Hardcoded policy**: simplest, but not reviewable/auditable and tends to drift per tool.
- **Regex scrubbing**: brittle, expensive, and easy to bypass; also not deterministic under adversarial inputs.
- **In-kernel enforcement**: expands privileged TCB; avoid unless evidence forces it.

## Security considerations
- CH-OBSPOL does not *grant* authority; it only restricts exports.
- Sanitized policy MUST forbid sturdyrefs, raw addresses, and secret-bearing capability material.
- Exporters must treat all content as attacker-controlled and enforce bounds deterministically.

## Assurance hooks
- Invariant: I-OBSPOL-1 (policy pinned + deterministic application).
- Proof obligations: PO-OBSPOL-VALIDATE, PO-OBSPOL-APPLY, PO-SNAP-REDACT.

## Evidence plan (seed)
- Property tests: malformed/unknown fields reject; bounds enforcement; canonical encoding reject non-canonical.
- Negative tests: inject bearer tokens/addresses/sturdyrefs into candidate exports and ensure fail/strip behavior.
- Differential tests: apply policy in two independent implementations and compare decisions.

## References
REF-FUCHSIA-DIAGNOSTICS, REF-FUCHSIA-TRIAGE, REF-ANDROID-BUGREPORT.
