# RFC-0090: authenticated network time + verifiable time proofs (D-TIMEPROOF) (optional)

Status: Draft  
Last updated: 2026-02-26

Goal: make **wall-clock time** usable for security-adjacent workflows (update metadata expiry, cert validity, audit timelines) on devices that:
- have no trustworthy RTC, and/or
- operate in hostile networks where unauthenticated time sync is an attack surface.

We keep the privileged core agnostic: time sync is a **user-space portal**. The privileged stance is:
- security policies consult a **monotonic** source (I-TIME-1),
- any wall-clock used for security decisions is **monotonic/non-decreasing**, and
- when we claim “authenticated time,” we export a **bounded proof artifact** (CH-TIMEPROOF) that can be verified independently.

## Problem
Many practical security mechanisms assume time:
- TUF-style update distribution depends on expiry/freshness (D-TUF).
- Certificates and revocation windows depend on validity periods.
- Audit trails and incident workflows become dramatically easier with credible timestamps.

But “NTP by default” is fragile:
- unauthenticated NTP enables **rollback** (move time backward to accept expired metadata) and **freeze** (stall time to keep old views) style attacks.
- many embedded devices boot at an epoch (e.g., 1970) without a secure RTC.

We want a design that:
1) works without an RTC (bootstrap time),
2) scales to frequent sync (steady-state),
3) does not expand the privileged core, and
4) produces **portable, bounded evidence** when needed.

## Prior art (high-signal)
- **Roughtime**: authenticated time samples signed by the server; designed so clients can produce cryptographic evidence of server misbehavior. (REF-ROUGHTIME-PROTOCOL; REF-ROUGHTIME-IETF)
- **NTS for NTP (RFC 8915)**: scalable cryptographic security for NTP using TLS for key establishment and AEAD for packets. (REF-RFC-8915; REF-CHRONY-NTS)

Key lesson: Roughtime is great for **bootstrap + portable proof**; NTS is great for **continuous sync** but is not “publicly verifiable proof” unless we additionally bind it into a device-signed receipt.

## Decision
Introduce an optional decision:
- **D-TIMEPROOF**: the system may obtain authenticated time from allowlisted network authorities and may export **CH-TIMEPROOF v0** artifacts as bounded evidence.

This complements:
- **D-NONDET** (explicit Clock handles): time access is explicit.
- **D-TIME** (security time source): the time used for expiry/anti-rollback is monotonic and fail-closed.

## Design summary
### 1) A user-space time portal (not a privileged interface)
A time portal is a normal supervised component that:
- holds outbound network authority (via D-NETLEASE/D-PLUMB portals),
- maintains one or more `realtime` clock providers for UX/logging,
- optionally performs authenticated sync:
  - **Bootstrap**: Roughtime queries to an allowlisted server set.
  - **Steady-state**: NTS-secured NTP (or equivalent) for frequent discipline.

### 2) A monotonic “secure wall time” for security checks
Security checks MUST NOT depend on a wall-clock that can move backward.
Profiles that use time for security decisions (C-TIME-1) maintain:
- `secure_time_lb` (a lower bound on current UNIX time) and
- `mono_anchor` (monotonic counter at last update)

and compute:
- `secure_time_now = max(secure_time_lb, secure_time_lb + (mono_now - mono_anchor))`

Updates to `secure_time_lb` are:
- **non-decreasing** (I-TIMEPROOF-2), and
- allowed only when justified by verified time evidence (or an explicit, transcript-visible admin override).

This keeps rollback attacks from time sync from turning into policy bypass. Phase 1 makes this stricter: authenticated time may advance the security lower bound, but does not become a generic ambient “set the wall clock / drive scheduler” surface.

### 3) CH-TIMEPROOF as bounded, portable evidence
When D-TIMEPROOF is enabled, the time portal MAY emit:
- **CH-TIMEPROOF v0**: a normalized, bounded record that summarizes a single authenticated time sample and binds to a raw proof blob via CH-AREF (optional).
  - **Phase-1 export stance:** portable/exported CH-TIMEPROOF is **Roughtime-shaped only** (`kind=roughtime`); NTS may discipline portal-local state, but does not become a second CH-TIMEPROOF kind in v0.
- **CH-TIMEREQ v0** (new): request descriptor for authenticated time sampling (bound by digest into ACP proposals).
  - ACP kind seed: `portal.clock.timeproof.sample` binds `timereq_digest = digest(CH-TIMEREQ v0)` and yields `CH-TIMEPROOF v0` evidence under lane gates.

The artifact is intended for:
- audit trails (“why did the device believe it was time T?”),
- bootstrap time confidence (first trustworthy time after epoch boot),
- incident workflows (bind time samples into crash capsules/snapshots as optional attachments).

The artifact is **observational**: exporting it must not change privileged state.

### 4) Interaction with update freshness and certificates
- D-TUF profiles that rely on expiry MUST either:
  - have a secure RTC/monotonic time base (D-TIME option), or
  - use D-TIMEPROOF to bootstrap `secure_time_lb` before enabling expiry-based acceptance.

If time is unknown/untrusted, fail closed on expiry-sensitive paths (do not “guess”).

## CH artifacts
- **CH-TIMEPROOF v0** (new): see `docs/30-architecture/time-proof-schema-v0.md`.

## Invariants (additions)
- **I-TIMEPROOF-1 (Timeproof verification, optional)**: if D-TIMEPROOF is enabled and a CH-TIMEPROOF is presented as evidence, validators verify the proof per an explicit allowlist/policy (server key identity + nonce binding + bounds). Invalid proofs are rejected deterministically.
- **I-TIMEPROOF-2 (Secure wall time is non-decreasing, optional)**: if D-TIMEPROOF is enabled for security policies, the “secure wall time” used for expiry/anti-rollback never decreases; backward adjustments require an explicit, transcript-visible override and must not silently weaken rollback/expiry enforcement.

## Proof obligations (additions)
- **PO-TIMEPROOF-VALIDATE**: CH-TIMEPROOF v0 decoding/validation is total + canonical; bounds enforced; unknown variants reject deterministically.
- **PO-TIMEPROOF-VERIFY**: for supported proof kinds (v0: Roughtime), verification is deterministic (signature/key allowlist + nonce binding + bounds) and yields a stable `(midpoint, radius)`.
- **PO-TIMEPROOF-APPLY**: advancing `secure_time_lb` from verified samples is monotonic and enforces profile step/jump rules; failures are fail-closed and audit-visible.

## Abuse case tie-in
- **AC-077**: time rollback / time authority injection (authenticated time is bypassed or misapplied, weakening expiry/anti-rollback).

## Evidence plan (tight)
Phase 0/1:
- validator fuzz/negative tests for CH-TIMEPROOF decode/bounds (PO-TIMEPROOF-VALIDATE)
- golden verification tests using known Roughtime vectors (PO-TIMEPROOF-VERIFY)
- monotonic-apply tests:
  - accept forward steps within policy
  - reject backward steps
  - reject unreasonable jumps unless explicit override token is presented (PO-TIMEPROOF-APPLY)

Phase 2:
- network-adversary simulation: inject unauthenticated NTP responses and show no effect on `secure_time_lb` under D-TIMEPROOF.

## Notes / open questions
- Proof formats: v0 standardizes a Roughtime-shaped proof summary and Phase 1 rejects other CH-TIMEPROOF kinds; future profiles may add COSE-wrapped statements or device-signed “time state receipts” (bound to CH-BOOT) when NTS is the primary sync mechanism, but only via a new RFC.
- Privacy: CH-TIMEPROOF may reveal network metadata (server IDs, coarse RTT). Treat export as policy-scoped via CH-OBSPOL and allow redaction.

## References
REF-ROUGHTIME-PROTOCOL, REF-ROUGHTIME-IETF, REF-RFC-8915, REF-CHRONY-NTS, REF-CLOUDFLARE-ROUGHTIME.
