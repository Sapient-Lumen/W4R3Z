# RFC-0083: Driver hosts + legacy driver compatibility runtimes (D-DRVDOM / D-RUMPK)

Status: Draft  
Owner: archive  
Last updated: 2026-02-25

Decision node(s): **D-DRVDOM**, **D-RUMPK**, D-IOLEASE, D-ACTIVATE, D-SUPV, D-SEAL

## Summary
Driver ecosystems are where greenfield OS projects die.

This RFC tightens our *driver-domain* story by importing two pragmatic, underused patterns into the archive as **explicit seams** (not kernel features):

1) **Driver hosts**: a user-space driver manager runs drivers inside restartable **driver-host processes** with clear lifecycles and isolation boundaries (Fuchsia DF, Windows UMDF).
2) **Compatibility runtimes** for legacy driver stacks: run large donor subsystems (Linux/NetBSD-style) as *contained* components that receive only explicit IO/resource capabilities and expose services via existing seams (translators, CapRPC).

3) **Declarative binding inputs (adjunct)**: driver binding and routing decisions should be based on explicit hardware facts (CH-HWFACT / CH-HWEVENT) and (optionally) a user-space SKB query service (D-SKB), rather than ad-hoc probes or magic paths.

The goal is to make “reuse” and “isolation” *default-shaped* so that hardware bring-up is fast **without** importing donor code into the privileged core.

Refs: REF-FUCHSIA-DRIVER-FRAMEWORK, REF-FUCHSIA-DRIVER-DEVEL, REF-WINDOWS-UMDF-OVERVIEW, REF-LKL-GITHUB, REF-L4RE-DOC, REF-L4RE-DEVICE-DRIVER, REF-RUMPKERNEL-WIKI.

## Motivation
We already commit to driver domains (D-DRVDOM) and have a rump-kernel bridge (D-RUMPK, RFC-0036), but two things remain under-specified:

- **Lifecycle/containment mechanics**: how do we restart drivers without destabilizing the system, and how do we make “driver crashes are normal” operationally boring?
- **A common membrane** for “foreign code in a box”: rump kernels are one choice, but the real requirement is that *any* donor stack (rump, LKL, DDE-style environments, even a microVM guest) cannot silently acquire ambient authority or expand privileged surfaces.

This RFC makes these mechanics explicit and connects them to existing seams:
- D-DRVDOM (driver domains)
- D-IOLEASE (device leasing / dataplane bypass)
- D-ACTIVATE (stable handles + restart continuity)
- D-SUPV (structured restart policy)
- D-SEAL (init→seal to shrink steady-state authority)

## Prior art (what we steal)
### A) Fuchsia driver hosts
Fuchsia runs drivers in **driver host processes** managed by a driver manager; a driver host is a component/process that loads one or more drivers, providing isolation between driver stacks and enabling controlled lifecycles. Refs: REF-FUCHSIA-DRIVER-FRAMEWORK, REF-FUCHSIA-DRIVER-DEVEL.

What we steal:
- the *process boundary* is the security/reliability unit
- the manager owns lifecycle and policy; drivers are just libraries inside hosts
- driver protocols are explicit interfaces, not magical ioctl soup

### B) Windows UMDF
UMDF demonstrates that “user-mode drivers” can be a mainstream stability strategy for classes of devices, with restart semantics and a system-supplied framework layer. Ref: REF-WINDOWS-UMDF-OVERVIEW.

What we steal:
- treat crash/restart as expected; keep kernel insulated
- constrain which device classes fit user-mode, and document the boundaries

### C) LKL and L4Re (DDE-style) legacy reuse
- **LKL** runs Linux kernel code as a library to reuse Linux subsystems in user space. Ref: REF-LKL-GITHUB.
- **L4Re** documents practical user-space driver construction and pass-through patterns in a microkernel context (and historically, DDE-style approaches exist to port Linux drivers). Refs: REF-L4RE-DOC, REF-L4RE-DEVICE-DRIVER.

What we steal:
- donor stacks can be contained if the host boundary is explicit and effects are capability-mediated
- portability shims become the *real* TCB inside the compat domain; treat them as hostile inputs too

## Design goals
- **No new privileged interfaces**: the kernel/hypervisor does not learn about “drivers” or “compat stacks”.
- **Capability membrane is explicit**: compatibility runtimes cannot perform host effects via ambient channels (I-COMPAT-1).
- **Fail-closed ABI**: emulated syscalls/ioctls/protocol ops are a closed set; unknown ops fail deterministically (I-COMPAT-2).
- **Restart is boring**: driver crashes are contained and handled by D-SUPV, ideally with D-ACTIVATE for continuity.
- **Expose services via existing seams**: translators (D-TRANS) and views (D-NS) for filesystem-like services; CapRPC for protocol services.

## Proposal

### 1) Driver-host pattern (recommended even for native drivers)
Define an implementation posture (not a new schema):
- a **driver manager** component owns device discovery and policy (and may consult D-SKB queries over CH-HWFACT/CH-HWEVENT for deterministic binding decisions)
- drivers run inside one or more **driver host** components/processes
- each driver host is supervised (D-SUPV) and may be restartable independently

Authority discipline:
- driver hosts receive only the IO resource capabilities required for their bound devices (I-IORES-1)
- optional device leases (D-IOLEASE) move dataplane queues/buffers into the driver host under explicit authority

Continuity:
- stable service endpoints (e.g., “net0”, “nvme0”) should be owned by a supervisor and handed into the current instance (D-ACTIVATE)
- state that must survive restarts should be explicit (either handle store, or higher-level durability via D-PERSIST), never implicit “kernel driver state”

### 2) Compatibility runtime capsules (Rump, LKL, etc.)
Treat compatibility runtimes as a **component runtime choice** under D-RUMPK:

- **Rump capsule**: RFC-0036 (recommended first bridge, especially for untrusted FS images)
- **LKL capsule**: reuse selected Linux subsystems in a contained component, *but* require the same membrane and authorization rules
- **Future capsules**: DDE-style porting layers or a microVM guest as a last resort for specific hardware

Common rules (the membrane):
- the compat capsule receives *no* ambient naming authority; all IO and host effects are explicit capabilities
- any “hostcall” surface provided to the donor stack is treated as a **closed interface** with deterministic failure and transcript visibility
- the capsule must be launchable with post-init sealing (D-SEAL) so “bring-up authority” is not retained

### 3) Exposing compat-backed functionality
- **Filesystems**: export a translator that presents a subtree; mount into a view (D-TRANS + D-NS)
- **Networking**: export a protocol service (CapRPC) or a service-tree endpoint; avoid ambient sockets
- **Device services**: prefer a small, pinned interface boundary (CH-IFACE) rather than passing ioctls across domains

## Security / abuse cases
Add:
- **AC-071 (Compat capsule escape / ambient host effects)**: a donor stack uses an unintended hostcall, name service, or debug channel to reach privileged effects.

Mitigations:
- I-COMPAT-1/I-COMPAT-2 enforced by validators + negative tests
- D-SEAL applied to compat domains (seal-after-init)
- D-IOLEASE used for device access (no raw DMA/MMIO without explicit caps)
- allow/deny results for any effect attempts are visible in CH-LOG (auditability)

## Assurance wiring
No new invariants are required beyond the existing compat membrane invariants:
- **I-COMPAT-1**, **I-COMPAT-2**

But this RFC strengthens their evidence targets.

Evidence seed:
- **EVID-2026-081**: “compat capsule harness” plan: demonstrate a contained legacy FS stack and/or driver stack:
  - attempt ambient host effects (should fail)
  - fuzz hostile inputs (core survives; restarts are deterministic)
  - prove exported service is reachable only via declared seams (views/translators/CapRPC)

## Alternatives
- “Just write all drivers natively”: ideal long-term, but incompatible with fast bring-up.
- “Put donors in the kernel”: fastest short-term, but destroys our TCB and proof surface.
- “Always use microVM guests”: strong isolation but higher overhead and operational complexity; reserve for hard cases.

## Archive impact
- Adds this RFC.
- Updates the D-RUMPK decision map entry to include this RFC as the “common membrane” guidance.
- Expands the bibliography with LKL, L4Re driver tutorials, and Fuchsia/UMDF driver-host prior art.
- Adds AC-071 and evidence seed EVID-2026-081.
