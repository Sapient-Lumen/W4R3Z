# Verification strategy (multi-phase)

Goal: convert invariants into machine-checked evidence for a core slice, then expand scope deliberately.

## Layered artifacts (target)
1) Abstract spec (state machine)  
2) Executable model / reference semantics (optional but helpful)  
3) Rust implementation with `unsafe` confined  
4) Refinement: implementation refines spec under A-IDs  

## Phase alignment
- Phase 0/1: invariant design + bounded checks for rapid feedback (e.g., Kani).
- Phase 2: mechanized proof for core slice (A2).
- Phase 3: stronger properties (A3) where scope/model is explicit (info-flow, concurrency).

## Toolchain trust notes
For SMT-based tools, document solver trust assumptions and mitigations (proof replay/certificates where possible).

## “Model-check fast” targets (tight, bounded)
Use bounded model checks early to turn hypotheses into counterexamples/POs quickly:
- **Protocol contracts** (D-CONTRACT): small FSMs for selected channels (PO-CONTRACT-MCHECK).
- **OCap patterns** (D-MEMBRANE): revocation/membrane wrapper automata under staged concurrency assumptions (PO-MEMBRANE-REVOKE).
- **Encodings** (D-ENC): canonical decode/encode roundtrips and rejection cases (PO-ENC-DECODE).
