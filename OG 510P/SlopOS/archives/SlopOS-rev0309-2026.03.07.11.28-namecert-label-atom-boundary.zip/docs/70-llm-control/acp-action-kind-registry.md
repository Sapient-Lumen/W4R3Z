# ACP action kind registry (stable semantics + commutativity metadata)

Purpose: pin the **closed** set of CH-ACP action kinds and the *normative* per-kind metadata needed to keep:
- least-authority workflows honest (no ambient authority),
- Hybrid + D-COMMUTE honest (explicit conflict keys + explicit ordering boundaries),
- and “LLMs propose; validators execute” operational (schemas + validators + receipts are the product surface).

Rule: adding a new kind requires an RFC + updates to:
- this registry,
- `docs/70-llm-control/acp-action-schema-v0.md` (CH-ACP),
- `docs/70-llm-control/acp-commutativity-predicate-registry.md` (per-kind commutation predicates + normalized observation boundary),
- relevant invariants/POs, and
- at least one evidence hook (tests/fuzz/model-check) that exercises the new kind.

## Per-kind metadata (what must be explicit)

For each kind we record:
0) **Request context**: every proposal MUST carry `meta.reqctx_digest = digest(CH-REQCTX v1)` (non-authoritative; veto-only context; required for replay/audit stability).
1) **Conflict key derivation** (the resource identity whose concurrent mutation can conflict), represented as `digest(CH-CONFLICTKEY v0)` when crossing trust boundaries.
2) **Commutativity stance**: keyed / conditional / ordered.
3) **Retry safety** (idempotent / at-least-once-safe / exactly-once-required).
4) **Ordering witness requirement**: if the kind is *ordered*, proposals MUST carry `meta.order_digest = digest(CH-ORDERTOK v0)` and `meta.conflict_key_digest = digest(CH-CONFLICTKEY v0)`.
5) **Profile gates**: which of the four product shapes (A–D) must support the kind (or whether it is profile-optional). If the kind is lane-gated, the Profiles cell MUST explicitly name the required lane kill switch key(s) from `config-toggle-registry.md` (e.g., `cfg.params.lane.portal.net`, `cfg.params.lane.capshell`, `cfg.params.lane.fcell`) so the gate remains discoverable/reviewable (CI-enforced; PO-LANE-KILL; I-LANEGATE-1).
6) **Serialization boundary**: if the kind is ordered (or ordered within a key), where serialization *actually* lives (validator vs a specific service). If the kind is not ordered, this must be `none`.

## Registry (v0 seed; keep small)

| Kind | Owner surface | Conflict key derivation (CH-CONFLICTKEY family) | Commutativity stance | Retry safety | Ordering witness | Serialization boundary | Profiles |
|---|---|---|---|---|---|---|---|
| `cfg.set_policy` | IF-CFG | family="policy.param", payload={param=<cfg.params.* key>} | **ordered** per `policy.param` (high-risk config writes) | exactly-once recommended (idempotent only if an explicit dedupe key is bound and enforced, e.g., CH-EFFCON `contract_id`) | **required** (CH-ORDERTOK v0) | `svc:IF-CFG` | A,B,C,D |
| `cap.grant` | IF-KABI | family="domain.id", payload={domain_key=ck_domain(dst_domain_id)} | **commutes (keyed)** across disjoint `domain.id` keys; within a domain it is set-insertion (order-independent) | idempotent (by canonical cap digest) | none | `none` | A,B,C,D |
| `domain.quarantine` | IF-KABI | family="domain.id", payload={domain_key=ck_domain(domain_id)} | **ordered** within a domain (quarantine/revoke is a correctness boundary vs concurrent grants) | idempotent (monotonic; re-quarantine is a no-op) | **required** (CH-ORDERTOK v0) | `svc:IF-KABI` | A,B,C,D |
| `view.attach` | view/namespace svc | family="view.slot", payload={view_key=digest(view_id), slot_id} | **commutes (keyed)** across disjoint `view.slot` keys; **ordered** within the same slot | exactly-once recommended (name-binding surfaces are sensitive to duplicates) | **required** (CH-ORDERTOK v0) | `svc:view` | A,B,C,D |
| `view.detach` | view/namespace svc | family="view.slot", payload={view_key=digest(view_id), slot_id} | **commutes (keyed)** across disjoint `view.slot` keys; **ordered** within the same slot | idempotent (detach absent binding is a no-op or explicit `NOT_ATTACHED`) | **required** (CH-ORDERTOK v0) | `svc:view` | A,B,C,D |
| `capshell.exec` | IF-CAPSHELL | family="domain.id", payload={domain_key=ck_domain(domain_id)} | **commutes (keyed)** across disjoint `domain.id` keys; **ordered** within the same domain (side-effects are domain-scoped) | at-least-once-safe when outputs are content-addressed + the bound CH-EFFCON `contract_id` is used as the idempotency key for duplicate suppression; otherwise exactly-once recommended | **required** (CH-ORDERTOK v0) | `svc:IF-CAPSHELL` | A,B,C,D (profile-gated; requires `cfg.params.lane.capshell`) |
| `portal.attn.request` | portal/attn svc | family="domain.id", payload={domain_key=ck_domain(domain_id)} | **commutes (keyed)** across disjoint `domain.id` keys; **ordered** within the same domain (portal upsert semantics keyed by CH-NOTIF.id) | at-least-once-safe when CH-NOTIF `kind="post"` and CH-NOTIF.id is stable (id-based upsert); idempotent for `kind="withdraw"` | **required** (CH-ORDERTOK v0) | `svc:portal.attn` | A,B,C,D (profile-gated; requires `cfg.params.lane.portal.attn`) |
| `portal.clock.timeproof.sample` | portal/clock svc | family="domain.id", payload={domain_key=ck_domain(domain_id)} | **ordered** within a domain (updates timeproof state / emits evidence) | at-least-once-safe when CH-TIMEREQ.req_id is stable and the portal dedupes by req_id; otherwise exactly-once recommended | **required** (CH-ORDERTOK v0) | `svc:portal.clock` | A,B,C,D (optional; requires `cfg.params.lane.portal.clock` and `cfg.params.lane.timeproof`) |
| `portal.net.request` | portal/net svc | family="domain.id", payload={domain_key=ck_domain(domain_id)} | **ordered** within a domain (lease issuance state; upsert keyed by CH-NETREQ.req_id) | at-least-once-safe when CH-NETREQ.req_id is stable and the portal dedupes by req_id; otherwise exactly-once recommended | **required** (CH-ORDERTOK v0) | `svc:portal.net` | A,B,C,D (optional; requires `cfg.params.lane.portal.net`) |
| `portal.entropy.request` | portal/entropy svc | family="domain.id", payload={domain_key=ck_domain(domain_id)} | **ordered** within a domain (entropy handle issuance state; upsert keyed by CH-ENTREQ.req_id) | at-least-once-safe when CH-ENTREQ.req_id is stable and the portal dedupes by req_id; otherwise exactly-once recommended | **required** (CH-ORDERTOK v0) | `svc:portal.entropy` | A,B,C,D (optional; requires `cfg.params.lane.portal.entropy`) |
| `portal.jobs.submit` | portal/jobs svc | family="domain.id", payload={domain_key=ck_domain(domain_id)} | **ordered** within a domain (job queue state; coalescing/cancel semantics live here; periodic backlog semantics are portal-owned) | at-least-once-safe when CH-JOBREQ.job_id is stable and the portal dedupes by job_id; otherwise exactly-once recommended | **required** (CH-ORDERTOK v0) | `svc:portal.jobs` | A,B,C,D (optional; requires `cfg.params.lane.portal.jobs`) |
| `portal.background.request` | portal/background svc | family="domain.id", payload={domain_key=ck_domain(domain_id)} | **ordered** within a domain (grant/renew/revoke state; autostart widening/review lives here) | at-least-once-safe when CH-BGREQ `req_id` is stable and the portal dedupes by req_id; otherwise exactly-once recommended | **required** (CH-ORDERTOK v0) | `svc:portal.background` | A,B,C,D (optional; requires `cfg.params.lane.portal.background`) |
| `budget.mint` | metering/budget svc | family="budget.issuer", payload={issuer_key=digest(payer_meter_id)} | **ordered** within `budget.issuer` (mint/split is the serialization boundary) | exactly-once recommended (prevents duplicate issuance) | **required** (CH-ORDERTOK v0) | `svc:budget` | A,B,C,D (profile-gated; requires `cfg.params.lane.metering`) |
| `fcell.launch` | compat supervisor | family="cell.id", payload={cell_id} | **ordered** within `cell.id` (launch/kill state machine; policy-killable lane) | at-least-once-safe if `cell_id` is unique per instance (replays yield `ALREADY_RUNNING`) | **required** (CH-ORDERTOK v0) | `svc:fcell` | A,B,D (optional; requires `cfg.params.lane.fcell`); C (bootstrap-only) |
| `fcell.kill` | compat supervisor | family="cell.id", payload={cell_id} | **ordered** within `cell.id` | idempotent (`NOT_RUNNING` is explicit) | **required** (CH-ORDERTOK v0) | `svc:fcell` | A,B,D (optional; requires `cfg.params.lane.fcell`); C (bootstrap-only) |


Notes:
- View/namespace posture: Phase 1 pins D-NS v0 semantics (explicit view namespaces; single-slot binding; no privileged `open(path)`) in `docs/30-architecture/view-namespace-posture-v0.md`; v1 union/clones remain in RFC-0032.
- Recommended per-profile defaults for workflow posture knobs (e.g., `cfg.params.capshell.minimal_context`, `cfg.params.capshell.require_plumbmsg`, `cfg.params.capshell.require_budget_lease`) are pinned in `docs/30-architecture/profile-workflow-defaults.md` (non-authoritative; no forks).
- “A,B,C,D” refer to the four profile stacks: workstation, cloud substrate, embedded/separation, agent/automation.
- Profile gating is **never a fork**: kinds remain defined; profiles can disable a kind by policy so it deterministically rejects and emits a transcript-visible receipt.
- `ck_domain(..)` is defined normatively in `docs/30-architecture/conflict-key-schema-v0.md` (Derivation commitments) to avoid double-hashing and keep domain-scoped commutativity evidence stable.
- Where a kind has an explicit lane gate in `docs/30-architecture/config-toggle-registry.md`, the validator MUST enforce it (fail closed) before attempting the effect (PO-LANE-KILL).
- For workflow automation kinds (e.g., `capshell.exec`), proposals MUST carry:
  - `exec_pack_digest = digest(CH-EXECPACK v2)` (capshell execution pack; completeness seal), which binds the full workflow execution context **and** a request-context digest:
    - `reqctx_digest = digest(CH-REQCTX v1)` (non-authoritative; veto-only), which MUST match the action `meta.reqctx_digest` (PO-CAPSHELL-REQCTX-BIND),
    - If `cfg.params.capshell.require_plumbmsg=true`, validators MUST require the referenced CH-EXECPACK v2 to include `plumbmsg_digest = digest(CH-PLUMBMSG v0)` and MUST validate the referenced CH-PLUMBMSG descriptor (non-authoritative intent envelope) before any effect (PO-PLUMBMSG-VALIDATE; PO-CAPSHELL-PLUMBMSG-REQ). Missing/invalid intent envelopes SHOULD emit CH-DENY `plumbmsg-missing` bound to `reason.ref_schema = "CH-PLUMBMSG v0"`.
    - If `cfg.params.capshell.require_budget_lease=true` **and** `cfg.params.lane.metering=true`, validators MUST require the bound CH-REQCTX v1 to include at least one `budget_desc_digests` entry that resolves/validates as **CH-BUDGET v0** (no implicit sponsorship; PO-CAPSHELL-BUDGET-REQ). Missing/invalid budgets SHOULD emit CH-DENY `budget-missing` bound to the CH-REQCTX digest.

    - `effcon_digest = digest(CH-EFFCON v0)` (veto-only effect contract), and
    - `argv_digest = digest(CH-ARGV v0)` (typed argv tokens that bind to already-held descriptor digests), and
      - within the referenced CH-ARGV, executable selection is **explicit and unique** (no ambient PATH): validators require **exactly one** `desc` token with `role="exec"` and MUST NOT resolve an executable from `lit` tokens or any ambient PATH (see `docs/30-architecture/capshell-exec-selector-posture-v0.md`).
    - `env_digest = digest(CH-ENV v0)` (typed environment tokens; no ambient env inheritance). If `cfg.params.capshell.minimal_context=true`, validators require an empty CH-ENV (no explicit env vars).
    - For any descriptor references in CH-ARGV/CH-ENV (`desc_schema` + `desc_digest`), validators/runners MUST enforce the **workflow-bound descriptor allowlist** pinned in CH-EFFCON v0 (effect-kind → allowed descriptor schemas). Any mismatch MUST fail closed and SHOULD emit CH-DENY `deny_code = effcon-violation` bound to the active `effcon_digest`.
    - `cwd_digest = digest(CH-CWD v0)` (typed working-directory selector; no ambient cwd inheritance). If `cfg.params.capshell.minimal_context=true`, validators require `kind="empty"`.
    - `stdio_digest = digest(CH-STDIO v0)` (typed stdio bindings; no ambient stdio/TTY inheritance). If `cfg.params.capshell.minimal_context=true`, validators require `(stdin.kind="null", stdout.kind="drop", stderr.kind="drop")`.
    - `fdset_digest = digest(CH-FDSET v0)` (typed extra child-handle bindings; no ambient handle/FD table inheritance). If `cfg.params.capshell.minimal_context=true`, validators require an empty CH-FDSET.
    - Multi-stage workflows are modeled as **multiple** `capshell.exec` actions, not as hidden runner-internal handle passing. Phase 1 forbids peer stage-to-stage raw handle/FD transfer; cross-stage handoff uses explicit next-stage CH-EXECPACK bindings plus existing CH-AREF/CH-PLUMBMSG/portal receipt surfaces (see `docs/30-architecture/capshell-pipeline-posture-v0.md`).
  These digests are non-authoritative correlation hooks, but are required for fail-closed validation and drift-resistant auditing.

For portal workflow kinds (e.g., `portal.attn.request`):
- proposals bind a descriptor digest (e.g., `notif_digest = digest(CH-NOTIF v0)`) and validators MUST validate the referenced schema before any UI-visible side effect (PO-ACP-ATTN-REQUEST; PO-NOTIF-VALIDATE).

For timeproof sampling kinds (e.g., `portal.clock.timeproof.sample`):
- proposals bind `timereq_digest = digest(CH-TIMEREQ v0)` and validators MUST validate CH-TIMEREQ before any network/portal effect (PO-TIMEREQ-VALIDATE).
- lane gates `cfg.params.lane.portal.clock` and `cfg.params.lane.timeproof` are enforced fail-closed before invoking the portal (PO-LANE-KILL; PO-ACP-TIMEPROOF-SAMPLE).
- when a CH-TIMEPROOF artifact is produced, validators SHOULD schema-validate it and (if applied to security time) enforce monotonic-apply rules (PO-TIMEPROOF-VALIDATE; PO-TIMEPROOF-VERIFY; PO-TIMEPROOF-APPLY; PO-TIMEPROOF-ENF).
- v0 posture: accepted/exported CH-TIMEPROOF remains **Roughtime-only**, evidence-first, and lower-bound-only; NTS may live inside the portal for steady-state discipline but does not become a second CH-TIMEPROOF proof kind in Phase 1 (see `docs/30-architecture/timeproof-posture-v0.md`).
- lane gates (the per-portal lane kill switches pinned in `config-toggle-registry.md`) are enforced fail-closed before invoking the portal service (PO-LANE-KILL).

For network lease request kinds (e.g., `portal.net.request`):
- proposals bind `netreq_digest = digest(CH-NETREQ v0)` and validators MUST validate CH-NETREQ before any portal effect (PO-NETREQ-VALIDATE).
- lane gate `cfg.params.lane.portal.net` is enforced fail-closed before invoking the portal (PO-LANE-KILL; PO-ACP-NET-REQUEST).
- when a CH-NETLEASE artifact is produced, validators SHOULD schema-validate it (PO-NETLEASE-VALIDATE) and SHOULD include a digest-only `receipt_refs` pointer in CH-ACPOUT (when safe) so tooling can correlate issuance without logs.
- no ambient socket constructors exist on the accept path; the portal returns an opaque leased network authority handle whose bounds are described by CH-NETLEASE (I-NETLEASE-1..2; D-NETLEASE).
- v0 posture: no ambient DNS/resolver surfaces; name resolution is bound to the lease (`resolver.kind="portal"`) (see `docs/30-architecture/network-lease-posture-v0.md`).

For entropy request kinds (e.g., `portal.entropy.request`):
- proposals bind `entreq_digest = digest(CH-ENTREQ v0)` and validators MUST validate CH-ENTREQ before any portal effect (PO-ENTREQ-VALIDATE).
- lane gate `cfg.params.lane.portal.entropy` is enforced fail-closed before invoking the portal (PO-LANE-KILL; PO-ACP-ENTROPY-REQUEST).
- when a CH-ENTROPY artifact is produced, validators SHOULD schema-validate it (PO-ENTROPY-VALIDATE) and SHOULD include a digest-only `receipt_refs` pointer in CH-ACPOUT (when safe) so tooling can correlate issuance without logs.
- deterministic entropy requests MUST remain mechanically distinguishable from crypto-quality entropy (I-NONDET-3); policies MUST forbid satisfying crypto-randomness preconditions with deterministic handles.


CI guardrail:
- `tools/check_acp_kindmeta.py` treats the table above as machine-checkable metadata and fails `make lint` if a kind row is missing a conflict-key family, uses a non-existent CH-CONFLICTKEY family, has an ordering witness mismatch vs its stance, or references a non-existent cfg.params lane kill switch (e.g., `cfg.params.lane.capshell`).
- `tools/check_acp_serialization_boundary.py` fails `make lint` if any kind marked **ordered** does not specify a serialization boundary (or if a non-ordered kind uses something other than `none`).
- `tools/check_acp_serialization_boundary_registry.py` fails `make lint` if any Serialization boundary token used by an ACP kind is not present in the closed allowlist pinned in `docs/30-architecture/serialization-boundary-registry.md` (prevents svc-name drift / typo’d boundaries).
## Receipt + transcript obligations (cross-cutting)

For any accepted action:
- For kinds marked **at-least-once-safe** in this registry, validators/owner services MUST implement dedupe keyed by the schema-pinned id field (e.g., CH-EFFCON `contract_id`, CH-JOBREQ `job_id`, CH-TIMEREQ `req_id`, CH-NOTIF.id) so duplicates do not repeat effects; duplicate suppression outcomes MUST be transcript-visible (CH-LOG/CH-ACPOUT), and when CH-ACPOUT is emitted producers SHOULD set `effect="duplicate_suppressed"` (CH-ACPOUT v0) (I-RETRY-1; PO-RETRY-DEDUP; D-RETRYSAFE).
- The validator computes the **derived** `conflict_key_digest` (when applicable) and records it in CH-LOG outputs (and, when D-EXPLAIN is enabled, SHOULD also record it in CH-RECEIPT).
- For CH-ACP kinds that are commutativity-tested (D-COMMUTE), producers SHOULD include a `receipt_refs` entry with `schema="CH-SPROJ v0"` and `digest = digest(CH-SPROJ v0)` that projects the final key-scoped post-state for the action's derived `conflict_key_digest` (see `docs/30-architecture/state-projection-schema-v0.md`). This keeps swap-order tests operational without introducing ambient inspection channels.
- If the kind is **ordered**, the receipt MUST include `order_digest` and the validator MUST check `meta.conflict_key_digest` matches the derived key and `meta.order_digest` scope matches the key (I-ORDERTOK-2).
- Kind selection is closed-world: unknown kinds reject deterministically.

## Evidence hooks (seed)

- Use swap-order tests for **commutes (keyed/conditional)** pairs (PO-COMMUTE-TEST).
- Use ordered-stream/serialization-point checks for **ordered** kinds (e.g., linearizability-style harnesses; REF-KNOSSOS-JEPSEN).
