# Roadmap (Phase 0–3)

See Charter for the canonical mission and behaviors.

## Phase 0 — Claims & discipline
Exit criteria:
- Threat model + assumptions registry stabilized (v1)
- Claim registry + invariant registry (v1)
- Decision map exists; first architecture RFCs drafted
- Archive policy + REF/EVID registries in place

## Phase 1 — Spec-first minimal core
Exit criteria:
- Abstract machine spec for objects/capabilities/mappings/IPC/scheduling
- End-to-end prototype demonstrating at least one isolation story
- Select primary verification path + fallback (ADR)

## Phase 2 — Verified core slice
Exit criteria:
- Machine-checked proof for a meaningful slice (capability integrity + mapping discipline + privileged ABI subset)
- TCB inventory precise for those claims
- Reproducible builds for trusted artifacts (at least one release profile)

## Phase 3 — Broaden & harden
Exit criteria:
- Concurrency/multicore story: **verified for the baseline multicore profile**; any constraints/exclusions are explicit non-claims
- Stronger properties (e.g., scoped information-flow) where justified
- Device/DMA story integrated with assumptions and enforcement (IOMMU or explicit weakening)


## Flagship targets (differentiators worth aiming at)
These are *targets*, not commitments; each requires an explicit D-* decision, scoped claims, and evidence.
- **Proof-carrying provenance (D-PCP)**: make a running image attestably linked to source + build recipe + selected proof artifacts, without expanding TCB beyond an explicit verifier.
- **Toolchain trust as a seam (D-BOOTSTRAP / D-DDC)**: keep a path toward bootstrappable toolchains and use diverse double-compiling gates in the release pipeline to mitigate “trusting trust”, without expanding runtime TCB (see RFC-0061).
- **Interface-as-data (CH-* + transcripts)**: privileged effects expressed as closed action sets with canonical bytes + logged decisions, enabling replay/diff testing against the abstract machine.
- **Interface evolution without silent fallback (D-APIEVO)**: make interface identity explicit (CH-IFACE + CH-CAPRPC `iface_digest`) and define deterministic unknown-op behavior so upgrades either fail closed or degrade safely; use adapter components for non-monotonic changes (RFC-0071).
- **Per-component namespaces that scale (D-NS)**: make view objects cheap to clone and overlay (union mounts) so least-authority naming is ergonomic, not a tax.
- **Rollback-friendly composition (D-FPM + D-ATOMICUPD)**: treat deployments as digest-addressed closures so “what ran?” is always answerable.
- **Durable authority by design (D-PERSIST)**: optional capability store + named roots so crash-only restart and upgrades can preserve state without reintroducing ambient authority; rollback/resurrection becomes an explicit, testable policy seam (RFC-0065).
- **Zero-downtime restarts by default (D-ACTIVATE)**: supervisor-owned stable service handles (socket activation style) + bounded per-component handle stores so crash-only restarts don’t drop inbound traffic and small continuity needs don’t require full checkpoint/restore (RFC-0081).
- **Temporary authority by design (D-LEASE)**: standardize time-limited / use-limited capability proxies for portals/gateways so “share for 10 minutes / 1 use” is ergonomic and leak-resistant without pushing token lifecycles into the kernel (RFC-0066).
- **Keys as capabilities (D-CRYPTOSVC)**: standardize non-exportable key handles + pinned key policies (CH-KEYPOL/CH-KEYREF) and redaction-safe crypto audit (CH-CRYPTOAUDIT) so delegation and persistence don’t require passing raw secrets (RFC-0067).
- **Sealed secrets + credential vault (D-VAULT)**: extend “keys as capabilities” to credentials/tokens so secrets become policy-pinned objects (CH-SECRETPOL/CH-SECRETREF) and high-risk releases can be consent/receipt- or attestation-gated without scattering raw secrets across apps (RFC-0070).
- **MicroVM/high-assurance profile (D-MICROVM)**: a small, bounded exit/device surface that is a realistic A2/A3 verification slice (v0 `ext.microvm` posture: `docs/30-architecture/microvm-profile-posture-v0.md`).
- **Compatibility domains without kernel bloat (D-RUMPK)**: optional contained compatibility runtimes (rump kernels first; LKL-style donor subsystems and other libOS/userspace-kernel facades later) so driver/legacy enablement does not inflate the privileged core; enforce an explicit compat membrane (I-COMPAT-1/I-COMPAT-2) with fail-closed dispatch and no ambient host channels (see RFC-0036, RFC-0083).
- **Sealed appliance profile (D-SEAL + D-FPM)**: support build-time specialized, sealed service images (unikernel-style) as a *profile* over our provenance + update mechanisms, not a new privileged subsystem; keeps ops surface tiny while preserving explicit capability wiring.
- **Confidential-computing profile (D-CC)**: optional TEE-backed isolation/attestation as a *declared* deployment extension, primarily to enable attestation-gated secret release and remote provenance checks, without importing CC protocol/policy into the privileged core (see RFC-0064).
- **Parametric platform instantiation**: keep the abstract machine stable while varying ISA/virtualization assumptions via explicit annexes and A-IDs.
- **Init→seal authority narrowing (D-SEAL)**: treat “setup then seal down” as a first-class hardening pattern for long-running services to shrink steady-state authority.
- **Confinement by construction (D-CONSTR)**: standardize user-space constructor/factory patterns + cap-graph-based confinement tests so “stamp out this sandboxed subsystem” is repeatable and regression-testable (see RFC-0042).
- **Hardware memory tagging profiles (D-MEMTAG)**: where hardware supports it (e.g., Arm MTE), enable production-like bug-catching / exploit-hardening modes for risky compartments, pinned as data (CH-HARDEN) and enforced at launch without expanding the privileged core (see RFC-0062).
- **Sealed code spaces (D-DYNCODE)**: make W^X the default and treat “make bytes executable” (execmod/JIT/dynamic modules) as explicit, reviewable authority, improving provenance and shrinking exploit surface.
- **Nondeterminism authority (D-NONDET)**: treat time/entropy as explicit Clock/Entropy handles (coarse-by-default, labeled quality) so replay, sandboxing, and “timer hygiene” are implementable without ad-hoc hooks.
- **Deterministic replay profiles (D-RR)**: leverage CH-KABI + CH-LOG + explicit nondeterminism (D-NONDET) to make incidents and proof-driven tests reproducible within a declared boundary; treat time-travel debugging as a user-space tooling target.
- **Turn-based service runtimes (D-TURNS)**: optional vat/turn-style concurrency for selected long-lived services (especially CapRPC-exposed ones) to avoid implicit reentrancy, simplify reasoning, and tighten the record/replay story without changing the kernel scheduler (RFC-0078).
- **Programmable observability without privileged TCB (D-TRACEPROC)**: run untrusted Wasm trace processors in user space to filter/aggregate CH-TRACE streams into bounded, redaction-safe diagnostics so “ask one question” doesn’t require exporting raw traces (see RFC-0068).
- **Trace prefilter predicates (D-TPRED)**: add a tiny, pinned boolean predicate format (CH-TPRED) so trace portals can safely drop irrelevant events early (portal-only by default; optional source-prefilter later) (see RFC-0073).
- **Capability-mediated event plumbing (D-EVENTBUS)**: a “plumber”-style routing substrate for ops/control events without ambient broadcast channels; pairs naturally with CH-LOG and ACP workflows.
- **Capability-mediated resource meters (D-METER)**: if availability/DoS becomes in-scope, enable explicit quota/charge delegation without bloating the core.
- **Temporal capabilities (D-TCAP)**: treat CPU time/scheduling rights as explicit authority (optionally unified with meters) to keep policy out of the core and enable auditable delegation.
- **Copyless buffer objects (D-IOBUF)**: optional performance mechanism that preserves explicit sharing and reduces IPC/I/O copies when needed.
- **Driver domains (D-DRVDOM)**: push device logic to user space and treat MMIO/IRQ/DMA as capability-controlled resources (IOMMU-first where available), shrinking privileged proof surface.


## Profile stacks (avoid forking the OS)

We aim to support four profile stacks over one shared authority substrate:
- Workstation/developer OS
- Cloud substrate / microVM host
- Embedded / separation-style deployments
- Agent/automation OS (LLM-first workflows)

The rule is: core primitives must serve ≥2 profiles or be explicitly profile-scoped; compatibility runtimes remain sealed foreign cells.

## Cross-cutting
- LLM control plane is treated as non-TCB; design rule is “propose → validate → authorize → execute → log.”
- OS inspirations are recorded only when they map to a decision node or invariant.
- Add ACP validator semantics slice and bounded model check plan (links to EVID-2026-004).


## Parallel research tracks (optional)
- **Capability hardware evaluation (D-CHERI)**: keep an ISA+toolchain path open for CHERI/Morello/CHERI-RISC-V compartments to reduce unsafe-code blast radius, without making it a Phase‑1 dependency (see RFC-0060).
