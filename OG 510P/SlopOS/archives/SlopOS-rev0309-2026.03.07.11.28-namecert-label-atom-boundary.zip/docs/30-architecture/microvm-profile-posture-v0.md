# D-MICROVM posture v0 (`ext.microvm`: virtio-first, no legacy, no hidden host channels)

Purpose: pin a **small, implementable** v0 meaning for the `ext.microvm` profile extension.

This is an exit-surface posture (D-XS): it constrains what the system will emulate/expose so the virtualization/device-model TCB stays reviewable.

## Posture (v0)

When `cfg.feature_flags` includes `ext.microvm`, the microVM profile is:

1) **Virtio-first and declared**
   - The guest-visible device model is a **declared, closed set** (no “implicit hardware”).
   - Unknown/unlisted devices MUST fail closed (ties to PO-XS-CLOSESET).
   - Transport choice is allowed to be platform-dependent (virtio-mmio vs virtio-pci), but **the device *types* remain virtio**.

2) **No legacy emulation**
   - v0 explicitly does **not** include legacy chipset/device emulation (ACPI tables, random historical PCI devices, BIOS-era glue).
   - If the platform uses PCI for virtio transport, v0 still treats “PCI support” as *virtio transport only* (no general PCI(e) ecosystem).

3) **No hidden host channels**
   - The microVM profile MUST NOT create ambient channels “because virtualization”: no implicit host filesystem, no implicit host network, no implicit host time.
   - Any host-mediated effects flow through existing portal/receipt seams under lane gates (e.g., `portal.net`, `portal.file`, `portal.clock`).

4) **Not a compatibility escape hatch (sealed-compat remains sealed)**
   - Running foreign OSes/runtimes in a microVM is still “foreign code in a box”.
   - Phase 1’s **no second compat runtime family** posture (D-RUMPK) applies: we do **not** adopt “just run Linux guests” as a hidden POSIX/legacy path in Phase 1.
   - If we later want “foreign guests as a product”, we must do it explicitly as sealed compatibility (D-FCELL + new negative tests), not as an ambient microVM side effect.

## Phase 1 non-goals (explicitly deferred)

- No standardized exhaustive device list in v0 (only posture direction + exclusion set).
- No vsock / fs sharing / PCI hotplug / passthrough without an RFC + D-XS budget update.
- No “foreign guest as the default compatibility story” (requires explicit sealed-compat design).

## Wiring

- Decision surface: `decision-map.md` (D-MICROVM, D-XS).
- Feature flag surface: `docs/30-architecture/config-toggle-registry.md` (`cfg.feature_flags` includes `ext.microvm`).
- Related postures:
  - `rumpk-selection-posture-v0.md` (D-RUMPK; “no second runtime family” in Phase 1)
  - `host-guest-channel-posture-v0.md` (host↔guest channels; v0 forbids virtio-vsock/virtio-fs/9p as ambient interop)
  - `dma-posture-v0.md` (D-DMA; physical DMA containment remains host-enforced)
- Mechanism note: `virtio-iommu-mechanism-note.md` (guest-visible seam; optional; declared/killable).
- CI drift gate: `tools/check_microvm_profile_posture.py` (EVID-2026-215).

## References

- REF-FIRECRACKER-NSDI20
- REF-FIRECRACKER-KERNEL-POLICY
- REF-VIRTIO-1.3
- REF-QEMU-MICROVM
- REF-KVM-API
- REF-CHYP-DEVICE-MODEL
- REF-CHYP-IOMMU
