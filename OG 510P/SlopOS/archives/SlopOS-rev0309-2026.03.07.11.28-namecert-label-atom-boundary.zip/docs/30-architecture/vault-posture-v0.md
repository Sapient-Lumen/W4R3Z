# D-VAULT posture v0 (ref-bound; provider-owned; non-inventory)

Purpose: pin an **implementable Phase 1** meaning for D-VAULT so “secret vault” stays a small,
reviewable authority seam instead of quietly expanding into a general keychain / search / sync subsystem.
It deliberately narrows the RFC into something worth coding: a user-space provider that holds secret objects,
uses **CH-SECRETPOL v0** and **CH-SECRETREF v0** as the portable contract, and keeps inventory/recovery semantics
explicit rather than ambient.

This doc says what a Phase 1 vault *is* and what it is *not*:
a **policy-bound provider-owned object store with explicit references and a closed op set** — **not** a Secret Service-style
collection/item/session/search broker, not a named-secret lookup API, and not an implicit cloud-sync / recovery surface.

## Posture (v0)

1) **User-space provider; no privileged-core policy fork**
   - If D-VAULT is enabled, the vault remains a **user-space provider**.
   - The privileged core does not gain new secret-release policy logic; it only routes/enforces existing capability boundaries.
   - Hardware sealing / attestation may strengthen deployments, but they remain profile annexes rather than a second cross-component API.

2) **Portable authority is ref-bound, not lookup-bound**
   - The portable cross-component contract is **CH-SECRETPOL v0** + **CH-SECRETREF v0** plus the closed op set (`read`, `wrap`, `rotate`, `delete`).
   - Secret persistence / handoff / receipts use **CH-SECRETREF**, not raw secret bytes and not provider-specific object-path conventions.
   - Possessing one CH-SECRETREF grants authority only to that referenced secret under its pinned policy; it does **not** imply enumerate-all-secrets authority.

3) **Policy is pinned as data, not inferred from names or labels**
   - Secret use constraints live in **CH-SECRETPOL v0**: allowed ops, contexts, evidence requirements, confirm/rate hints.
   - Providers MUST fail closed when required context/evidence is missing or when the effective policy pin does not match.
   - Labels, notes, or provider-local tags may exist for UX, but they are not a portable authorization surface in v0.

4) **No collection/item/session/search model on the core seam**
   - Phase 1 does **not** standardize a Secret Service-style collection/item/session/search object model on the core seam.
   - The portable surface is intentionally smaller: explicit references + bounded operations.
   - Providers may implement richer internal organization, but it remains internal/provider-specific until a future RFC justifies the entropy cost.

5) **No provider-global inventory or attribute search API**
   - Phase 1 does **not** claim app-visible “list my secrets”, label search, attribute search, or provider-global enumeration.
   - Discovery happens by explicit handoff / persistence / routing of CH-SECRETREF, not by ambient lookup.
   - This keeps D-VAULT from becoming a metadata oracle or a hidden authority-discovery surface for agents/apps.

6) **Recovery / federation is an explicit profile annex, not default behavior**
   - Optional recovery-vault behavior (e.g., secstore-style remote retrieval of encrypted bundles) is a **profile-explicit annex**.
   - Phase 1 does **not** assume always-on cloud backup, cross-provider federation, implicit sync, or automatic restore into a new provider.
   - If recovery exists, it must stay explicit, policy-bound, and reviewable as a separate deployment decision.

7) **Audit and persistence stay redaction-safe and reference-first**
   - Exported logs/receipts carry **digests, policy pins, and CH-SECRETREF references**, not secret bytes.
   - CapStore stores **CH-SECRETREF**, not plaintext secret blobs.
   - High-risk reveal remains policy-bound and evidence-bound rather than “because the caller found the right label”.

## Phase 1 non-goals (explicitly deferred)

- **No Secret Service-style collection/item/session/search object model on the core seam**.
- **No app-visible `list/search secrets by label/attribute` portable API**.
- **No implicit provider-to-provider federation, sync, or cloud-backup semantics**.
- **No assumption that remote recovery exists or is always-on**.
- **No raw secret-byte persistence as the portable CapStore format**.

## Wiring

- Decision surface: `decision-map.md` (D-VAULT).
- Schema surfaces:
  - `secret-policy-schema-v0.md` (CH-SECRETPOL v0)
  - `secretref-schema-v0.md` (CH-SECRETREF v0)
- Related mechanism notes:
  - `mechanisms.md` (vault provider posture)
  - `app-secret-posture-v0.md` (minimal app seed; distinct from a vault)
  - `cryptosvc-posture-v0.md` (keys-as-capabilities adjunct)
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-VAULT-1, I-VAULT-2, I-VAULT-3)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-SECRETPOL-ENF, PO-SECRETREF-PIN, PO-VAULT-REFONLY)

CI drift gate:
- `tools/check_vault_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 “ref-bound / provider-owned / non-inventory / no implicit recovery” constraints, or drops its primary REF wiring.

## References

- REF-PLAN9-SECSTORE.
- REF-SECRET-SERVICE-SPEC.
- REF-ANDROID-KEYSTORE.
- REF-APPLE-KEYCHAIN.
