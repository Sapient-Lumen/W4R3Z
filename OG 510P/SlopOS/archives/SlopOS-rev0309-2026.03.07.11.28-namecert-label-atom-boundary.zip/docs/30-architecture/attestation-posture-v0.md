# Attestation posture v0 (CH-ATTEST is boot-bound; export is killable)

Purpose: pin the Phase‑1 meaning of **D-ATTEST** so “remote attestation” does not drift into an ambient channel,
protocol sprawl, or privileged parsing complexity.

This posture is about the **export surface** and **binding semantics**, not about a specific hardware RoT provider.

## Posture (v0)

1) **Observational only.** Producing an attestation token (CH-ATTEST v0) MUST be **non‑mutating** with respect to privileged state (no “attest-and-configure”).
2) **Policy-killable export.** IF-ATTEST MUST be gated by `cfg.params.lane.attest.export`. If the lane is disabled, IF-ATTEST MUST deterministically deny and emit a receipt/deny record (no silent fallbacks). (Sealed‑compat rule: interop must be killable.)
3) **Boot binding is mandatory.** Any exported token MUST bind to the active `digest(CH-BOOT)` as `boot_digest` (I-ATTEST-1) and MUST be rejected by verifiers if that binding fails.
4) **No secrets in-band.** CH-ATTEST payloads MUST NOT contain secrets. Exporters MUST treat `eat_payload` (and any provider-native evidence blobs carried in CH-ATTESTPACK) as opaque bytes; no privileged code parses them.
5) **Freshness is explicit.** Freshness is OPTIONAL. If freshness is claimed, the token MUST bind a verifier‑provided nonce/challenge (`freshness.kind != none`) and the verifier MUST enforce the associated freshness assumptions (A-ATTEST-2). No ambient “current time” dependency is introduced by default.
6) **Claims are profile-bounded.** v0 treats CH-ATTEST as a *binding token* (boot digest + device identity context). Any additional claims (e.g., EAT) are profile policy, not privileged core behavior.
7) **Provider diversity stays out of the core.** The privileged core MUST NOT embed vendor/provider‑specific attestation parsing logic (TPM quotes, SEV-SNP reports, TDX reports, CCA reports). Provider adaptation lives in user space tooling/services that produce a normalized CH-ATTEST payload-to-sign.
8) **Interop does not create ambient network.** Exporting a token MUST NOT require ambient networking. If a deployment chooses an online freshness protocol, it must flow through D-NETLEASE (portal-issued network authority) and remain policy-killable.

## Phase 1 non-goals (explicitly deferred)

- A full remote-attestation protocol spec (endorsement retrieval, transport, verifier policy language).
- Standardizing a single RoT provider or mandating a particular confidential-computing attestation format.
- “Attestation-driven configuration” (mutating state as a side effect of attestation).
- Global attestation registries / ambient discovery services.

## Wiring

- Decision surface: `decision-map.md` → **D-ATTEST**.
- Schema surface: `attestation-token-schema-v0.md` → **CH-ATTEST v0** (normalized summary payload).
- Packaging surface: `attestation-pack-schema-v0.md` → **CH-ATTESTPACK v0** (export bundle: CH-ATTEST bytes + optional provider-native evidence + endorsement pointers).
- Interface surface: `interface-registry.md` → **IF-ATTEST** (exporter).
- Assurance hooks:
  - Claim: **C-ATTEST-1** (optional) in `docs/20-assurance/claim-registry.md`.
  - Invariant: **I-ATTEST-1** (binds “this boot” to CH-BOOT digest).
  - Proof obligations: **PO-ATTEST-VERIFY**, **PO-ATTEST-FRESH**.
- Policy kill switch:
  - `cfg.params.lane.attest.export` in `config-toggle-registry.md` and profiled defaults in `profile-lane-defaults.md`.
- Related postures:
  - Observation export posture: `observation-export-posture-v0.md` (attestation is an export surface; keep it pull-only and bounded).
  - No ambient networking: `network-lease-posture-v0.md`.
  - No ambient time: `nondet-posture-v0.md` (freshness remains explicit; avoid ambient time dependence).
- CI drift gate: `tools/check_attestation_posture.py` (EVID-2026-228).

## References

- REF-RATS-RFC9334
- REF-EAT-RFC9711
- REF-TPM2-PART1
- REF-DICE-TCG
- REF-AMD-SEV
- REF-INTEL-TDX
- REF-ARM-CCA
