# D-LEASE posture v0 (capability leases are proxy authority, not a hint)

Purpose: pin the **Phase 1 meaning** of D-LEASE so “temporary authority” does not drift into:
- raw-cap sharing with no revocation/expiry,
- implicit renewal (“it just stays valid”),
- ambient time as an authority source,
- or transcript-free delegation (impossible to audit/test).

This posture is intentionally small. Leases are an **attenuation pattern** implemented in user space (D-MEMBRANE),
evidenced by a bounded descriptor (CH-CAPLEASE v0), and (when time-bounded) depend on explicit Clock handles (D-NONDET).

## Posture (v0)

If D-LEASE is enabled, then any “temporary share” boundary MUST be implemented as:

1) **A lease proxy is the authority**
   - The delegate receives a capability to a proxy object (LeaseGate), not the raw underlying capability.
   - The proxy enforces bounds before forwarding and fails closed (I-LEASE-1).

2) **No raw capability export**
   - A lease proxy MUST NOT expose an API that returns the wrapped capability (directly or via re-serialization).
   - Any “unwrap” operation, if ever added, requires a distinct explicit authority object and an ADR; v0 forbids it.

3) **No unbounded renewal**
   - Renewal requires explicit renewal authority (I-LEASE-2). The delegate cannot extend TTL/uses by default.
   - “Keepalive” signals are not renewal authority.

4) **Time is not ambient authority**
   - Time-based leases require an explicit Clock handle (D-NONDET).
   - If a Clock handle is missing, invalid, or fails, forwarding MUST fail closed (I-LEASE-1).

5) **Issuance is non-amplifying**
   - A lease proxy may only attenuate the wrapped capability (I-LEASE-3). It MUST NOT add rights.
   - Method allowlists/rights labels in CH-CAPLEASE are UX/audit hints; enforcement is by the proxy.

6) **Delegation is transcript-evidenced**
   - Whenever a lease proxy crosses a trust boundary, the issuer MUST emit a redaction-safe CH-CAPLEASE v0 descriptor (no secrets) and bind it into the transcript/receipt surface when feasible.
   - CH-CAPLEASE is evidence, not authority. Validators/observers MUST treat it as non-authoritative.

## Phase 1 non-goals (explicitly deferred)

- No global “lease registry” schema. Domain-specific lease descriptors (e.g., CH-NETLEASE) may exist; v0 does not force them to embed CH-CAPLEASE.
- No ambient “lease by name” lookup. Leases remain capabilities.
- No “unwrap” or “re-export raw cap” escape hatch.

## Wiring

- Decision surface: `decision-map.md` (D-LEASE).
- Schema surface: `capability-lease-schema-v0.md` (CH-CAPLEASE v0).
- Related posture: `nondet-posture-v0.md` (D-NONDET; time authority is explicit).
- Required validation/enforcement:
  - PO-LEASE-VALIDATE (descriptor validation when present)
  - PO-LEASE-ENF (complete fail-closed enforcement)
  - PO-LEASE-NOAMP (non-amplifying issuance)
- CI drift gate: `tools/check_caplease_posture.py` (EVID-2026-219).

## References

- REF-CAPMYTHS
- REF-ROBUST-COMPOSITION
- REF-KOPPMANN-ES
- REF-OCAP-MURPHI
- REF-KEYKOS-ARCH85
- REF-EROS-FASTCAP
