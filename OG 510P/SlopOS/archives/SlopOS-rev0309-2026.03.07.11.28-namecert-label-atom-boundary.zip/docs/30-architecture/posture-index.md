# Posture index (v0)

Purpose: keep all **v0 posture** decisions discoverable and reviewable.

A posture doc is a small, Phase-1 scoped “meaning pin” for a decision surface.
It is intentionally **not** an API spec: it names what we do *and do not* claim,
what must fail-closed, and where future expansion requires an RFC.

This index is an amnesia resistor:
- helps humans/LLMs find the *current* pinned meanings,
- Conventions/template: `posture-doc-conventions.md` (section shape enforced by CI)
- reduces drift by making “what we’ve pinned” a closed, enumerable set,
- supports lint/CI checks that prevent orphan posture docs.

## v0 posture docs (closed by convention)

Rule: any new `*-posture-v0.md` doc MUST be added here and wired from `docs/README.md`.

| Doc | Pins (surface) | v0 meaning (one line) | CI hook |
|---|---|---|---|
| [`artifact-resolution-posture-v0.md`](artifact-resolution-posture-v0.md) | D-AREF | CH-AREF `locator` is a hint; no privileged deref; bytes only via explicit portals + verification | `tools/check_aref_resolution_posture.py` (EVID-2026-199) |
| [`activation-posture-v0.md`](activation-posture-v0.md) | D-ACTIVATE | Stable handles stay supervisor-owned and inbound-only; optional handle store is continuity-only, manifest-closed, and non-inventory | `tools/check_activation_posture.py` (EVID-2026-251) |
| [`attrfs-posture-v0.md`](attrfs-posture-v0.md) | D-ATTRFS | Indexed attributes and smart queries stay view-scoped, snapshot-first, and handle-returning; saved queries remain shell-owned manifests | `tools/check_attrfs_posture.py` (EVID-2026-249) |
| [`attention-lease-posture-v0.md`](attention-lease-posture-v0.md) | D-ATTN | No new attention lease schema; urgency is a policy-gated CH-NOTIF hint | `tools/check_attention_posture.py` (EVID-2026-233) |
| [`app-secret-posture-v0.md`](app-secret-posture-v0.md) | D-APPSECRET | Application secrets stay a minimal app-scoped seed seam: not a vault, no named inventory, no silent auto-rotation | `tools/check_appsecret_posture.py` (EVID-2026-237) |
| [`vault-posture-v0.md`](vault-posture-v0.md) | D-VAULT | Vault stays ref-bound, provider-owned, and non-inventory; no collection/search core seam or implicit recovery/federation | `tools/check_vault_posture.py` (EVID-2026-247) |
| [`cryptosvc-posture-v0.md`](cryptosvc-posture-v0.md) | D-CRYPTOSVC | Crypto services stay op-only, context-bound, and explicit-route only; no ambient agent socket or provider-global key inventory | `tools/check_cryptosvc_posture.py` (EVID-2026-245) |
| [`namecert-posture-v0.md`](namecert-posture-v0.md) | D-NAMECERT / CH-NAMECERT | Local naming stays issuer-local and evaluator-local; no privileged chain evaluator, ambient resolver/fetch, or auto-install into views | `tools/check_namecert_posture.py` (EVID-2026-303) |
| [`wallet-posture-v0.md`](wallet-posture-v0.md) | D-WALLET | Wallets stay summary-only and `wallet_core_digest`-bound; no import/merge semantics and no wallet-driven authority lookup or transfer | `tools/check_wallet_posture.py` (EVID-2026-246) |
| [`attestation-posture-v0.md`](attestation-posture-v0.md) | D-ATTEST / CH-ATTEST | CH-ATTEST is boot-bound and observational; export is policy-killable; no privileged provider-specific parsing | `tools/check_attestation_posture.py` (EVID-2026-228) |
| [`background-lease-posture-v0.md`](background-lease-posture-v0.md) | D-BGLEASE | Background/autostart is explicit, review-bound persistence; no silent widening; prefer D-JOBS for deferrable work | `tools/check_bglease_posture.py` (EVID-2026-232) |
| [`inhibit-lease-posture-v0.md`](inhibit-lease-posture-v0.md) | D-INHIBITLEASE | Inhibits are live, close-to-release, and non-durable; no future-dated keep-awake records; manual-only v0 | `tools/check_inhibitlease_posture.py` (EVID-2026-235) |
| [`capability-lease-posture-v0.md`](capability-lease-posture-v0.md) | D-LEASE | Leases are proxy authority: no raw export; no unbounded renewal; no ambient time | `tools/check_caplease_posture.py` (EVID-2026-219) |
| [`capshell-exec-selector-posture-v0.md`](capshell-exec-selector-posture-v0.md) | D-CAPSHELL | Exactly one `role="exec"`; no ambient PATH resolution | `tools/check_capshell_exec_selector.py` (EVID-2026-202) |
| [`capshell-pipeline-posture-v0.md`](capshell-pipeline-posture-v0.md) | D-CAPSHELL | Pipelines are stage-local exec packs; no peer handle/FD passing; handoff uses explicit artifacts or re-binding | `tools/check_capshell_pipeline_posture.py` (EVID-2026-231) |
| [`dma-posture-v0.md`](dma-posture-v0.md) | D-DMA / C-ISO-2 | C-ISO-2 implies IOMMU/SMMU required; otherwise DMA-class attach/lease denies-by-default | `tools/check_dma_posture.py` (EVID-2026-221) |
| [`io-lease-posture-v0.md`](io-lease-posture-v0.md) | D-IOLEASE / D-DEVGUARD | Phase 1 device access is manual-only via `portal.device.*`; no ambient `/dev`; consent receipts required | `tools/check_iolease_posture.py` (EVID-2026-220) |
| [`location-lease-posture-v0.md`](location-lease-posture-v0.md) | D-LOCLEASE | Phase 1 location is manual-only, coarse-first, and non-persistent; no background `always` or geofence wakeups claimed | `tools/check_loclease_posture.py` (EVID-2026-236) |
| [`job-portal-posture-v0.md`](job-portal-posture-v0.md) | D-JOBS | deferred work stays portalized and best-effort; no ambient cron/exact alarms; missed periodic windows are not replay debt | `tools/check_job_portal_posture.py` (EVID-2026-234) |
| [`transfer-portal-posture-v0.md`](transfer-portal-posture-v0.md) | D-PLUMB / CH-XFER | Transfer stays manual-only, sink-pull, one-shot/auto-clear across boundaries, and non-history | `tools/check_transfer_portal_posture.py` (EVID-2026-239) |
| [`plumb-posture-v0.md`](plumb-posture-v0.md) | D-PLUMB | Workflow routing stays explicit-invocation and request-local; no durable inbox/outbox, callback registry, or app-visible handler/route inventory | `tools/check_plumb_posture.py` (EVID-2026-295) |
| [`portal-session-posture-v0.md`](portal-session-posture-v0.md) | D-PLUMB | Portal request/session objects stay provider-owned and single-outcome; long-lived sessions are family-local only; no generic resume/list/watch/callback surface | `tools/check_portal_session_posture.py` (EVID-2026-296) |
| [`powerbox-posture-v0.md`](powerbox-posture-v0.md) | D-POWERBOX | Consent mediation stays designation-scoped and chooser-owned; results are concrete capability outcomes only; no generic remembered-grant library or inventory oracle | `tools/check_powerbox_posture.py` (EVID-2026-297) |
| [`capture-portal-posture-v0.md`](capture-portal-posture-v0.md) | D-CAPTURE / CH-CAPTURE | Capture stays manual-only, indicator-bound, and non-persistent in Phase 1; no restore-token / remembered-session semantics or background/headless start | `tools/check_capture_portal_posture.py` (EVID-2026-240) |
| [`document-portal-posture-v0.md`](document-portal-posture-v0.md) | D-PLUMB / D-POWERBOX / CH-DOCREF | `portal.file.*` stays manual-only; persistence is explicit; reopen is non-bearer and non-widening; no app-visible grant inventory in v0 | `tools/check_document_portal_posture.py` (EVID-2026-241) |
| [`openuri-portal-posture-v0.md`](openuri-portal-posture-v0.md) | D-PLUMB / `portal.uri.*` | OpenURI stays manual-only, scheme-gated, and launch-only; no app-visible handler inventory/probing or callback channel | `tools/check_openuri_portal_posture.py` (EVID-2026-242) |
| [`print-portal-posture-v0.md`](print-portal-posture-v0.md) | D-PLUMB / `portal.print.*` | Print stays manual-only, render-first, and shell-spooled; no app-visible printer inventory, queue authority, or print-to-file/path loophole | `tools/check_print_portal_posture.py` (EVID-2026-243) |
| [`quarantine-posture-v0.md`](quarantine-posture-v0.md) | D-QUAR | Quarantine stays monotonic; clear is manual-only and object-local; safe export creates a new artifact instead of laundering trust in place | `tools/check_quarantine_posture.py` (EVID-2026-248) |
| [`microvm-profile-posture-v0.md`](microvm-profile-posture-v0.md) | D-MICROVM / D-XS | `ext.microvm` is virtio-first, declared, no legacy emulation, no hidden host channels | `tools/check_microvm_profile_posture.py` (EVID-2026-215) |
| [`host-guest-channel-posture-v0.md`](host-guest-channel-posture-v0.md) | D-MICROVM | No virtio-vsock / virtio-fs \/ 9p host-sharing in Phase 1; any future host↔guest interop must be explicit + killable | `tools/check_host_guest_channel_posture.py` (EVID-2026-230) |
| [`network-lease-posture-v0.md`](network-lease-posture-v0.md) | D-NETLEASE | No ambient sockets/DNS; networking exists only as portal-issued leased authority | `tools/check_netlease_posture.py` (EVID-2026-217) |
| [`nondet-posture-v0.md`](nondet-posture-v0.md) | D-NONDET | No ambient time/RNG when enabled; time/entropy enter via explicit handles | `tools/check_nondet_posture.py` (EVID-2026-218) |
| [`timeproof-posture-v0.md`](timeproof-posture-v0.md) | D-TIMEPROOF | Authenticated time is evidence-first and lower-bound-only; portable CH-TIMEPROOF export is Roughtime-only in Phase 1 | `tools/check_timeproof_posture.py` (EVID-2026-244) |
| [`observation-export-posture-v0.md`](observation-export-posture-v0.md) | D-OBS | Observation export is pull-only, bounded, redaction-first, and killable by policy (no ambient indexing/exfil) | `tools/check_obs_export_posture.py` (EVID-2026-225) |
| [`reqctx-posture-v0.md`](reqctx-posture-v0.md) | D-REQCTX | Request contexts stay sticky and tree-shaped; one absolute monotonic deadline intent; no portable baggage, detach, or shield semantics | `tools/check_reqctx_posture.py` (EVID-2026-292) |
| [`turns-posture-v0.md`](turns-posture-v0.md) | D-TURNS | Turn-based services stay per-component and one-turn-at-a-time; far calls stay async; no hidden inbox pumping or portable reentrancy knob | `tools/check_turns_posture.py` (EVID-2026-298) |
| [`caprpc-session-posture-v0.md`](caprpc-session-posture-v0.md) | D-CAPRPC | Live refs stay explicit, connection-specific, and session-scoped; disconnect is fail-stop; continuity requires explicit restore; no session/object inventory or transparent resume seam | `tools/check_caprpc_session_posture.py` (EVID-2026-300) |
| [`caprpc-promise-posture-v0.md`](caprpc-promise-posture-v0.md) | D-CAPRPC | Promise handles stay caller-local and one-shot; pipelining only targets unresolved capability results; no promise inventory/combinator/admin seam | `tools/check_caprpc_promise_posture.py` (EVID-2026-299) |
| [`caprpc-oneway-posture-v0.md`](caprpc-oneway-posture-v0.md) | D-CAPRPC | Oneway stays interface-marked, enqueue-or-error, and small; no third frame kind, no capability attachments, and no durable mailbox/admin seam | `tools/check_caprpc_oneway_posture.py` (EVID-2026-301) |
| [`bracket-posture-v0.md`](bracket-posture-v0.md) | D-BRACKET / CH-CALLCHAIN | Privilege bracketing stays borrowed-mode-by-default and task-local; call-chain stays bounded and deny-only; no portable stack inspection or workflow surface | `tools/check_bracket_posture.py` (EVID-2026-294) |
| [`ordering-token-posture-v0.md`](ordering-token-posture-v0.md) | CH-ORDERTOK / D-COMMUTE | Ordering witnesses stay scope-bound and owner-minted; one conflict-key stream; no portable sequencer, range-allocation, or global-stream surface | `tools/check_ordering_token_posture.py` (EVID-2026-293) |
| [`reqctx-budget-ref-posture-v0.md`](reqctx-budget-ref-posture-v0.md) | D-REQCTX / D-BUDGET | CH-REQCTX `budget_desc_digests` are consumer-typed and non-ambient; only CH-BUDGET counts when required | `tools/check_reqctx_budget_ref_posture.py` (EVID-2026-205) |
| [`reqctx-tcap-ref-posture-v0.md`](reqctx-tcap-ref-posture-v0.md) | D-REQCTX / D-TCAP | CH-REQCTX `tcap_desc_digests` are consumer-typed and non-ambient; only CH-TCAP counts when required | `tools/check_reqctx_tcap_ref_posture.py` (EVID-2026-208) |
| [`waitset-posture-v0.md`](waitset-posture-v0.md) | D-WAITSET | Wait sets stay observational and explicit-binding; level-triggered by default; no packet queue/user injection or workflow surface | `tools/check_waitset_posture.py` (EVID-2026-289) |
| [`ioq-posture-v0.md`](ioq-posture-v0.md) | D-IOQ | IoQueues stay provider-owned and explicit-handle-only; one SQE → one op; no path constructors, chain/message-ring drift, or workflow surface | `tools/check_ioq_posture.py` (EVID-2026-291) |
| [`quiesce-posture-v0.md`](quiesce-posture-v0.md) | D-QUIESCE | Quiesce stays cooperative and component-local: one active qid, `DRAIN|CANCEL` only, no force-kill/global freeze semantics | `tools/check_quiesce_posture.py` (EVID-2026-290) |
| [`rcu-posture-v0.md`](rcu-posture-v0.md) | D-RCU | Grace periods stay per-subsystem and user-space by default; QSBR-first; no ambient/global GraceDomain or workflow surface | `tools/check_rcu_posture.py` (EVID-2026-285) |
| [`uwait-posture-v0.md`](uwait-posture-v0.md) | D-UWAIT | Wait-on-address stays process-local and 32-bit; core seam is wait+wake only with no PI/requeue or workflow surface | `tools/check_uwait_posture.py` (EVID-2026-287) |
| [`robustlock-posture-v0.md`](robustlock-posture-v0.md) | D-ROBUSTLOCK | Owner-death recovery stays per-thread, mutex-only, and component-local; successors must make consistent or poison to `NOT_RECOVERABLE` | `tools/check_robustlock_posture.py` (EVID-2026-288) |
| [`rseq-posture-v0.md`](rseq-posture-v0.md) | D-RSEQ | CPU-local fast paths stay runtime-owned and single-slot; no ambient `getcpu`/topology oracle or workflow surface | `tools/check_rseq_posture.py` (EVID-2026-286) |
| [`rumpk-selection-posture-v0.md`](rumpk-selection-posture-v0.md) | D-RUMPK | Phase 1 posture: rump kernels for filesystem-image handling only; no second runtime family | `tools/check_rumpk_selection_posture.py` (EVID-2026-210) |
| [`seal-posture-v0.md`](seal-posture-v0.md) | D-SEAL | Init→seal is one-way attenuation: post-seal authority can only shrink unless an explicit reconfiguration action is authorized | `tools/check_seal_posture.py` (EVID-2026-227) |
| [`capx-posture-v0.md`](capx-posture-v0.md) | D-CAPX / CH-CAPX | Delegated remote authority stays a gateway-owned, proxy-first import seam; no raw-cap binding, ambient resolver/inventory, or portable caveat VM | `tools/check_capx_posture.py` (EVID-2026-302) |
| [`sturdyref-posture-v0.md`](sturdyref-posture-v0.md) | D-CAPX / CH-SREF | Sturdyrefs stay explicit restore-only bearer refs; off by default; no ambient resolver/inventory; routine surfaces carry digests, not raw bytes | `tools/check_sturdyref_posture.py` (EVID-2026-252) |
| [`uicap-scope-posture-v0.md`](uicap-scope-posture-v0.md) | D-UICAP | UI authority scope posture (SAS + portal-only high-risk UI authority; profile-shaped) | `tools/check_uicap_scope_posture.py` (EVID-2026-213) |
| [`volition-posture-v0.md`](volition-posture-v0.md) | D-VOLITION | Trusted UI gesture evidence stays fresh, local-only, and one-shot; no batch/cached approvals or export/import semantics | `tools/check_volition_posture.py` (EVID-2026-250) |
| [`ui-automation-posture-v0.md`](ui-automation-posture-v0.md) | D-UIAUT | Accessibility/automation stays manual-only and observation-first in Phase 1; no ACP automation kind or hidden persistence | `tools/check_uiaut_posture.py` (EVID-2026-238) |
| [`view-namespace-posture-v0.md`](view-namespace-posture-v0.md) | D-NS | Namespaces are explicit view objects; single-slot binding; no privileged `open(path)` | `tools/check_view_namespace_posture.py` (EVID-2026-216) |

## Adding a new v0 posture doc

Keep the entropy cost explicit:
1) Attach the new posture to an existing decision surface (D-/CH-/I-/PO-) and state what it pins.
2) Wire it into discovery:
   - add it to this index,
   - link it from `docs/README.md` (or a relevant registry section),
   - link it from the relevant decision page (usually `decision-map.md`).
3) Prefer a tiny CI drift gate if the posture prevents a known failure mode (ambient channels, “compat escape hatch”, silent claim inflation).
