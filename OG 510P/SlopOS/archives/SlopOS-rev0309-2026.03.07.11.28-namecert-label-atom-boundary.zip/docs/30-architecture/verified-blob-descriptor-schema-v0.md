# CH-VBLOB v0: Verified blob descriptor (Merkle integrity)

Status: Draft  
Updated: 2026-02-27  

Purpose: represent the identity and verification posture of an immutable, verified-read blob.

This schema is **non-authoritative**: it never grants access to bytes. It is a descriptor for audit, binding, and debugging (I-VERITY-1).

## Shape (canonical fields)
A CH-VBLOB v0 object has this high-level shape:

- `schema`: string, must be `"CH-VBLOB"`
- `version`: integer, must be `0`
- `kind`: enum, one of:
  - `file_verity` (fs-verity style)
  - `volume_verity` (dm-verity style)
- `digest_alg`: enum, allowlisted (v0): `sha256`
- `digest`: bytes (or lowercase hex string in JSON authoring), the **content identity** digest
- `size_bytes`: u64, total content size
- `block_size`: u32, leaf block size used for the hash tree (must be a power of two; min 4096)
- `merkle_root`: bytes (or lowercase hex string in JSON authoring), root hash of the Merkle tree
- `enforce_on_read`: bool (v0 default = true when present)
- `aref`: optional artifact reference (CH-AREF digest) if this blob is fetched/transported out of band
- `sig_ref`: optional signature envelope reference (CH-SIGENV digest) when policy requires “signed blob identities”
- `notes`: optional bounded string (short, redaction-safe)

### Validation rules (v0)
Validators MUST:
- enforce `{schema,version}` exact match,
- enforce `digest_alg` allowlist (v0: `sha256` only),
- bound `size_bytes` and `block_size` to profile limits,
- enforce `block_size` is power-of-two and ≥ 4096,
- require `digest` and `merkle_root` lengths match the algorithm,
- reject unknown keys (closed schema),
- treat `aref`/`sig_ref` as **references only** (no embedded payload bytes).

### Notes
- `digest` SHOULD be the canonical identity used for update/provenance binding (CH-BOOT/CH-UPD `artifacts[]`).
- `merkle_root` allows streaming proofs and on-demand verification without hashing the entire blob up front.
- `enforce_on_read=false` exists only for explicit test/diagnostic profiles; production profiles should reject or warn.

## References
See RFC-0114 (D-VERITY) for design intent and evidence plan.
