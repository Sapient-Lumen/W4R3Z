# D-ATTRFS posture v0 (view-scoped, snapshot-first, handle-returning smart queries)

Purpose: pin an **implementable Phase 1** meaning for **D-ATTRFS** so indexed attributes, search,
and “smart folder” workflows stay capability-scoped and reviewable instead of drifting into a
global search daemon, a path/count-probing API, or an ambient background watch surface.

This posture deliberately narrows the seam: **CH-ATTR** declares what may be indexed, **CH-ATTRQ**
expresses bounded predicates, and any persistence/live behavior stays shell-owned and explicitly
bound to a view rather than becoming application-visible inventory or scheduler state.

## Posture (v0)

1) **No ambient global index or query authority**
   - If **D-ATTRFS** query mode is enabled, every query executes against an explicit **view** already authorized to see the underlying objects.
   - Phase 1 does **not** expose a system-wide “search everything I can infer from the host” service, raw path crawl, or cross-view metadata oracle.
   - Sealed compat does not gain an ambient host search/index channel; any interop remains explicit and policy-killable.

2) **Queries stay schema-declared, closed, and small**
   - Indexed keys come only from **CH-ATTR v0** declarations with explicit `indexed=true` and visibility rules.
   - Query bytes are **CH-ATTRQ v0** only: closed operators, bounded AST, deterministic validation, and strict type checking when `schema_digest` is present.
   - Phase 1 does **not** widen CH-ATTRQ into regex, full-text ranking, arbitrary scripting, joins, or app-defined operator plugins.

3) **Results are handles, not paths or generic inventory probes**
   - Query results are handles/caps already reachable through the provided view; they are not raw host paths, inode numbers, or ambient reopen tokens.
   - Applications do **not** get a generic “count-only”, “exists somewhere”, or provider-global inventory surface in v0.
   - Any shell UI summary counts remain shell-owned presentation, not a new authority surface.

4) **Snapshot-first; live updates are optional and bounded**
   - Phase 1 treats a query as a **snapshot-first** operation returning the currently matching handle set.
   - Live-query mode is optional, capability-scoped, revocable, and bounded: update streams must have deterministic overflow/drop semantics and must not survive by accident as a hidden background watch.
   - A live query may narrow the freshness/latency story, but it does **not** widen authority or bypass the view boundary.

5) **Saved queries / smart folders are shell-owned manifests**
   - In Phase 1, persistent “smart folder” / saved-query objects are **shell-owned manifests** bound to a query digest and an explicit view binding.
   - Applications may submit ephemeral CH-ATTRQ bytes for evaluation, but v0 exposes **no app-visible saved-query inventory / CRUD API** and no generic “list every saved query” surface.
   - Saved-query persistence must not silently widen into autostart, background resubscription, or an app-owned indexing daemon.

6) **Authority does not widen through query execution**
   - Querying may filter and project already-visible objects only; it must not mint new authority, leak hidden objects by timing/count/path side channels, or attach ambient network/observation authority.
   - Returned handles remain subject to the same downstream portal / view / quarantine / document rules they had before the query.

7) **Agent/automation use stays reviewable**
   - Phase 1 does **not** claim a generic ACP action kind for persistent query creation or background live-query management.
   - Agent workflows may reason over CH-ATTRQ bytes and query digests, but any durable saved-query UX remains shell-owned and transcript-visible rather than silently app/agent-managed.

## Phase 1 non-goals (explicitly deferred)

- No ambient global desktop search service.
- No raw path-returning query API.
- No count-only / existence-probe API for applications.
- No regex/full-text/ranking/query-plugin expansion of CH-ATTRQ.
- No app-visible saved-query inventory / rename / delete / background watch API.
- No hidden persistence or scheduler semantics via “live query” subscriptions.

## Wiring

- Decision surface: `decision-map.md` → **D-ATTRFS**.
- Schema surfaces:
  - `attribute-schema-v0.md` → **CH-ATTR v0**.
  - `attribute-query-schema-v0.md` → **CH-ATTRQ v0**.
  - `schema-registry.md` → CH-ATTR / CH-ATTRQ registry notes.
- Related RFC / threat model:
  - `rfcs/0100-attribute-query-predicates-and-smart-folders.md`.
  - `docs/10-threat-model/abuse-cases.md` → **AC-085**.
- Assurance hooks:
  - Invariants: **I-ATTRQ-1**, **I-ATTRQ-2**.
  - Proof obligations: **PO-ATTRQ-VALIDATE**, **PO-ATTRQ-BOUNDS**, **PO-ATTRQ-ENF**.
- Discovery / amnesia-resistor surfaces:
  - `docs/README.md`.
  - `posture-index.md`.
  - `docs/00-meta/profile-posture-matrix.md`.
  - `docs/00-meta/llm-runbook.md`.
  - `docs/00-meta/trajectory-map.md`.
- CI drift gate: `tools/check_attrfs_posture.py` (**EVID-2026-249**).

## References

- REF-BFS-ATTR
- REF-HAIKU-QUERIES
- REF-PFSD-BFS
- REF-APPLE-NSMETADATAQUERY
- REF-APPLE-SPOTLIGHT-QUERYGUIDE
