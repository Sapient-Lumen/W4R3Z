# CH-EXECPACK v2: capshell execution pack (schema)

Purpose: eliminate “ambient authority by omission” in workflow execution by bundling the **complete** capshell execution context into a single, hashable descriptor.

CH-EXECPACK is designed for D-CAPSHELL:
- **LLMs propose** a `capshell.exec` action carrying `exec_pack_digest = digest(CH-EXECPACK v2)`.
- deterministic validators/runners **execute** only after validating the pack and then validating/binding each referenced descriptor under already-held authority.

CH-EXECPACK is **non-authoritative**:
- it contains only digests (no bearer secrets, no raw capability material),
- it never grants authority,
- it exists to make required workflow context explicit and reviewable across profiles (A–D) without forks.

Additions vs v1:
- Optional `plumbmsg_digest?: digest(CH-PLUMBMSG v0)` so automation can carry an explicit, non-authoritative **workflow intent envelope** (D-PLUMB) for audit/routing.
  - Profiles may require this via `cfg.params.capshell.require_plumbmsg` (veto-only; denies missing/invalid intent envelopes).

References: REF-SHILL-OSDI14, REF-PLASH.

## Encoding
Candidate baseline: canonical CBOR (D-ENC).
Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Design constraints (v2)
- total decoding + fail-closed validation
- bounded sizes and closed fields (no scripting language)
- digests only: **no bearer secrets** and **no raw capability identifiers**
- makes “no ambient workflow context” enforceable:
  - profiles MAY further *narrow* workflow context via `cfg.params.capshell.minimal_context` (veto-only): when true, the referenced CH-ENV/CH-CWD/CH-STDIO/CH-FDSET/CH-ARGV must satisfy the minimal-context constraints (PO-CAPSHELL-MINCTX-ENF).
  - profiles MAY require explicit **workflow intent envelopes** via `cfg.params.capshell.require_plumbmsg` (veto-only): when true, the pack MUST include `plumbmsg_digest = digest(CH-PLUMBMSG v0)` and validators MUST validate the referenced CH-PLUMBMSG descriptor (PO-CAPSHELL-PLUMBMSG-REQ).
  - no ambient PATH resolution (exec chosen via CH-ARGV role="exec" only)
  - no ambient env/cwd inheritance
  - no ambient stdio/TTY inheritance
  - no ambient inherited handle/FD tables
  - no ambient request correlation/deadline/cancel context (bound via CH-REQCTX)

## Data model (conceptual)

CH-EXECPACK v2 := {
  v: 2,

  ; Non-authoritative request context correlation hook.
  ; This is veto-only information: it MUST NOT be used to grant privileged effects.
  reqctx_digest: bstr,      ; digest(CH-REQCTX v1)

  ; Optional non-authoritative workflow intent envelope.
  ; This is routing/audit metadata only; it MUST NOT be treated as authorization evidence.
  plumbmsg_digest?: bstr,   ; digest(CH-PLUMBMSG v0)

  ; The complete execution context is required.
  ; Each field is a digest of canonical bytes of the referenced descriptor.
  effcon_digest: bstr,      ; digest(CH-EFFCON v0)
  argv_digest: bstr,        ; digest(CH-ARGV v0)
  env_digest: bstr,         ; digest(CH-ENV v0)
  cwd_digest: bstr,         ; digest(CH-CWD v0)
  stdio_digest: bstr,       ; digest(CH-STDIO v0)
  fdset_digest: bstr,       ; digest(CH-FDSET v0)

  ; Optional non-authoritative hints.
  note?: tstr
}

## Validation rules (minimum)

An exec-pack validator MUST be total and fail closed (PO-EXECPACK-VALIDATE):
1) `v == 2`.
2) All required digests are present and each digest length matches the profile hash.
3) Unknown keys reject (or are rejected by canonical CBOR decode).
4) `note` (if present) is bounded.

If `plumbmsg_digest` is present:
- it must be 32 bytes,
- and if the profile requires intent envelopes (`cfg.params.capshell.require_plumbmsg=true`), the validator MUST resolve and canonically validate the referenced CH-PLUMBMSG v0 descriptor (PO-PLUMBMSG-VALIDATE).

## Semantics notes (binding to execution)

CH-EXECPACK is a **veto-only completeness seal**:
- It never grants authority (I-EXECPACK-1).
- It exists so `capshell.exec` can be specified as “requires `exec_pack_digest`” rather than
  as a drifting set of optional per-field digests.

Binding points:
- `capshell.exec` proposals MUST carry `exec_pack_digest = digest(CH-EXECPACK v2)`.
- Validators MUST reject `capshell.exec` proposals that omit `exec_pack_digest` (PO-CAPSHELL-EXECPACK-REQUIRE).
- Validators MUST also require **request-context coherence** (PO-CAPSHELL-REQCTX-BIND):
  - let `a.meta.reqctx_digest` be the CH-ACP action request context digest,
  - let `p.reqctx_digest` be the CH-EXECPACK v2 request context digest,
  - acceptance requires `a.meta.reqctx_digest == p.reqctx_digest`.
  Mismatches MUST fail closed.

Intent-envelope posture (optional):
- If `cfg.params.capshell.require_plumbmsg=true`, validators MUST require `plumbmsg_digest` be present in CH-EXECPACK v2 and MUST validate the referenced CH-PLUMBMSG v0 descriptor before any effect (PO-CAPSHELL-PLUMBMSG-REQ).
- CH-PLUMBMSG is **non-authoritative**: it is a routing/UX envelope only and MUST NOT be treated as authorization evidence.

Runners MUST validate and bind each referenced descriptor:
- enforce CH-EFFCON veto-only effect families at every privileged-effect boundary (I-EFFCON-2),
- bind CH-ARGV/CH-ENV/CH-CWD/CH-STDIO/CH-FDSET descriptor references only to already-held handles/leases/portal outputs,
- select the executable only via CH-ARGV `desc` token with `role="exec"` (no ambient PATH),
- avoid inheriting any ambient process context (env/cwd/stdio/extra handles).

Request-context note:
- `reqctx_digest` is informational only (I-REQCTX-3): it MUST NOT be used to grant privileged effects.
- It MAY be used to deny/narrow behavior (deadline/cancel intent; profile veto hooks) and to correlate receipts/transcripts.

Denial guidance:
- Missing `exec_pack_digest` SHOULD emit CH-DENY with deny_code `execpack-missing` and `reason.ref_schema = "CH-EXECPACK v2"`.
- Mismatched request contexts SHOULD emit CH-DENY with deny_code `reqctx-mismatch`, binding the relevant `reqctx_digest`.
- If `cfg.params.capshell.require_plumbmsg=true` and `plumbmsg_digest` is missing, validators SHOULD emit CH-DENY with deny_code `plumbmsg-missing` and `reason.ref_schema = "CH-PLUMBMSG v0"`.
- Invalid/unavailable packs SHOULD emit CH-DENY with deny_code `invalid-schema`, binding `reason.ref_schema = "CH-EXECPACK v2"`.

Notes:
- Profiles that disable capshell (`cfg.params.lane.capshell=false`) deterministically deny `capshell.exec` (PO-LANE-KILL).
- This schema is deliberately minimal: it binds *what* context is used, not *how* handles are passed.
- v0 pipeline posture: a CH-EXECPACK is **single-stage only**. Phase 1 forbids peer stage-to-stage raw handle/FD passing; cross-stage handoff uses CH-AREF/CH-PLUMBMSG digests or explicit portal outputs rebound into the next stage's own pack (see `capshell-pipeline-posture-v0.md`).
