# CH-CAPDIFF v0: Capability-diff summary (schema)

Purpose: a **bounded, redacted** description of how a capability graph / authority set changes across an operation, suitable for:
- *authority diffs* shown to a user during consent (D-EXPLAIN),
- deterministic binding in CH-VOL + CH-RECEIPT, and
- export via IF-OBS subject to the same redaction policy as other observations (I-OBS-1).

Design constraints (v0)
- deterministic decode + canonical encoding (I-ENC-1; PO-ENC-DECODE)
- bounded size (fail closed if the diff would exceed bounds)
- no raw capability secrets, pointers, or stable kernel object IDs
- derived only from canonical inputs (action bytes + policy + internal authority state); requester-provided prose must not influence the bound diff (I-EXPLAIN-1)

References: REF-UDAC-SP12, REF-YEE-UIDSS-2002, REF-XDG-PORTAL-FILECHOOSER, REF-SANDSTORM-POWERBOX, REF-PLASH-POWERBOX.

## Encoding
Candidate baseline: canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-CAPDIFF v0 := {
  v: 0,

  ; scope / subject (for UI routing + policy); opaque + optional
  scope?: tstr,               ; e.g. "component:netstack" (policy may omit/redact)

  ; optional correlation anchors (do not carry secrets)
  action_schema?: tstr,       ; e.g. "CH-ACP v0" | "CH-KABI v0"
  action_digest?: bstr,       ; digest of canonical action bytes (if applicable)
  epoch_before?: uint,        ; optional monotonic snapshot counters (profile-defined)
  epoch_after?: uint,

  ; the interesting part: added/removed authority items
  adds: [ CAPDIFF_ITEM ],     ; bounded list
  removes?: [ CAPDIFF_ITEM ], ; optional bounded list (often omitted in UI)

  ; deterministic policy decisions that affect interpretation
  clamps?: [ tstr ],          ; closed enum values like "truncated", "grouped", "redacted" (optional; informational)

  meta?: { * tstr => any }    ; ignored unless allowlisted
}

CAPDIFF_ITEM := {
  kind: tstr,                 ; closed enum: "cap_grant" | "lease_grant" | "label_add" | "net_allow" | "fs_allow" | "dev_allow" | "other"

  ; human legibility (policy-controlled; may be redacted)
  subject?: tstr,             ; e.g. "app:photos" (derived from canonical component identity)
  object?: tstr,              ; e.g. "camera" | "file" | "socket" | "service:clipboard"

  rights?: tstr,              ; reduced rights summary (closed vocab per kind; e.g. "read", "write", "connect:tcp", "capture")
  bounds?: {
    lease_schema?: tstr,      ; e.g. "CH-CAPLEASE v0" | "CH-IOLEASE v0"
    lease_digest?: bstr,      ; digest of the lease descriptor (if used)
    ttl_s?: uint,             ; optional display hint (derived from lease; informational)
    uses?: uint,              ; optional display hint (derived from lease; informational)
  },

  ; references for machine/audit linking (no secrets)
  cap_class?: tstr,           ; optional capability class tag (closed set per profile; e.g. "fs.read", "dev.camera.capture")
  derivation_hint?: tstr,     ; optional opaque hint for debugging (NOT authoritative)

  ; optional: user-facing resource designation (highly sensitive; profile-gated)
  resource_hint?: tstr,       ; e.g. a filename chosen by user; MUST be omitted or redacted by default exports

  meta?: { * tstr => any }
}

## Validation rules (minimum)
A CH-CAPDIFF validator MUST be total and fail closed:
1) `v == 0` and required fields present (`adds`).
2) `adds/removes` length are bounded; unknown `kind` rejects.
3) `rights` and `cap_class` are from closed allowlists for the configured profile; unknown values reject.
4) `resource_hint` is only permitted when the active profile explicitly allows it (dev/desktop); otherwise it must be absent.
5) If `bounds.lease_schema` is present, it must be allowlisted and `lease_digest` length must match the configured hash.
6) Unknown `meta` keys are ignored unless allowlisted.

## Intended uses
- Consent previews that show “what authority is being added” (grant creep defense).
- Receipts that can be audited after the fact without re-running the original UI.
- Regression tests: compare diffs across versions to detect accidental authority widening.

## Proof obligations (hooks)
- PO-CAPDIFF-REDACT: diff generation/export never emits forbidden fields and obeys profile gating for `resource_hint`.
- PO-EXPLAIN-SUMMARY: diff generation is deterministic and derived only from canonical inputs (action bytes + policy + relevant state); requester text cannot affect the bound structure.

