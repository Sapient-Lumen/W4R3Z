# Origin + quarantine attribute set (for CH-ATTR v0)

Purpose: provide a small, reviewable attribute key space used by D-QUAR so that:
- quarantined objects can be detected consistently,
- propagation rules are testable,
- UI can present provenance without guessing.

This is an **instance** of CH-ATTR v0 (not a new CH-* schema).

## Declared keys

### origin.*
- `origin.source` : enum {`network`, `email`, `removable`, `ipc`, `unknown`}
- `origin.locator_hint` : string (optional; non-authoritative)
- `origin.time` : u64 (unix seconds)
- `origin.chain_digest` : digest (optional; if CH-PROV is enabled, digest of the provenance chain object)

### quarantine.*
- `quarantine.state` : enum {`none`, `quarantined`, `cleared`}
- `quarantine.reason` : enum {`download`, `attachment`, `extracted`, `unknown`}
- `quarantine.cleared_by` : string (optional; identifier for the clearing workflow/policy)

## Semantics (summary)
- Any create/copy/extract from a quarantined object yields a quarantined object (I-QUAR-1), unless a declared “safe export” workflow produces a new object with an explicit log record.
- Clearing is **object-local**: clearing one object does not recursively clear enclosing archives, extracted children, siblings, or future derivations (I-QUAR-5).
- Safe-open / preview does not silently rewrite the source object’s quarantine state; sanitized/dequarantined materialization happens by producing a **new artifact** with its own digest and transcript-visible reason rather than laundering trust in place (`quarantine-posture-v0.md`).
- `origin.locator_hint` is informational and must not be used for authorization decisions.
