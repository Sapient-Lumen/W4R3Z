# CH-DOCREF v0: Document portal reference (durable file handle descriptor)

Purpose: a redaction-aware, audit-friendly descriptor for a **portal-managed durable document grant**.
This schema is **not** the authority itself; it describes a grant that a document portal can later re-open into a scoped, path-free handle (a file cap or view node).

References: REF-XDG-PORTAL-DOCUMENTS, REF-APPLE-SECBOOKMARK, REF-ANDROID-SAF-DOCUMENTS.

Phase 1 posture is pinned in `document-portal-posture-v0.md`: `portal.file.*` remains manual-only, persistence is explicit, reopen is non-bearer + non-widening, and applications do not gain an ambient grant inventory.

## Encoding
Candidate baseline: canonical CBOR (D-ENC). Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-DOCREF v0 := {
  v: 0,

  doc_id: bstr,              ; random 128-bit (or more) identifier

  target_kind: tstr,         ; closed enum: "file" | "dir"

  rights: tstr,              ; closed enum: "read" | "read_write" | "append" | "metadata"

  persistent: bool,          ; true iff the user/policy explicitly requested durability across restarts

  issued_at_s: uint,         ; monotonic or policy-defined epoch seconds
  exp_s?: uint,              ; optional expiry; if present, portal MUST deny after expiry

  rev_epoch?: uint,          ; optional revocation epoch at issuance (if revocation epochs are enabled)

  origin: {
    comp_id: tstr,           ; canonical component identity this grant is bound to (non-bearer posture)
    instance?: tstr,         ; optional instance label (bounded; informational only)
  },

  provider: {
    comp_id: tstr,           ; identity of the portal/docstore service that minted the ref
  },

  label?: tstr,              ; optional, bounded display label for “recent docs”; may be redacted on export

  meta?: { * tstr => any }   ; optional; MUST be ignored unless whitelisted
}

Notes:
- `doc_id` is a lookup key, not an authorization token. Portals MUST authenticate the caller and enforce `origin.comp_id` binding (I-DOCREF-1).
- `label` exists for local UX (recent-doc lists). It is optional and may be dropped/redacted in exports.

## Validation rules (minimum)
A CH-DOCREF validator MUST be total and fail closed:
1) `v == 0`.
2) `doc_id` is present and length-bounded (>= 16 bytes; profile may require more).
3) `target_kind` and `rights` are allowlisted closed enums.
4) `issued_at_s` is present and bounded; if `exp_s` is present, `exp_s >= issued_at_s` and is bounded.
5) `origin.comp_id` and `provider.comp_id` are present and bounded.
6) Unknown fields reject (or are rejected by canonical CBOR decode); `meta` MUST be ignored unless explicitly allowlisted.

## Security notes
- **Non-bearer posture**: systems MUST NOT treat CH-DOCREF as sufficient proof of access. Re-open must check caller identity and policy (I-DOCREF-1; PO-DOCREF-REOPEN).
- **No host paths**: docrefs must not embed paths; portals should return capability-shaped handles or view insertions (I-DOCREF-2).
- **Explicit persistence**: `persistent=true` is reserved for explicit user/policy choices; Phase 1 must not auto-mint durable docrefs for every chooser result (I-DOCREF-3; PO-DOCREF-ENF).
- **No widening on reopen**: reopening must clamp to the stored `rights` and `target_kind`; a file grant does not become a directory/root inventory surface (I-DOCREF-3; PO-DOCREF-ENF).
- **Stale/retarget protection**: portals should bind grants to stable file identity internally and fail closed if the underlying object changes (I-DOCREF-2).
- **Export hygiene**: CH-DOCREFs may be sensitive metadata. Sanitized snapshot/export tiers SHOULD redact `label` and may forbid exporting docrefs entirely via CH-OBSPOL.
