# CH-ENV v0: capability-bound environment token list (schema)

Purpose: eliminate ambient authority in workflow automation by representing process environment
variables as a **typed token list** that can bind to already-held capabilities/leases/portal outputs.

CH-ENV is designed for D-CAPSHELL:
- **LLMs propose** a `capshell.exec` action carrying `exec_pack_digest = digest(CH-EXECPACK v2)`; the referenced pack binds `env_digest = digest(CH-ENV v0)`.
- deterministic validators/runners **execute** only after validating the token list and binding
  referenced descriptors to already-held handles.

CH-ENV is **non-authoritative**:
- it MUST NOT contain bearer secrets or raw capability material,
- it MUST NOT be interpreted as a “permission grant,”
- and any binding from the token list to real handles MUST be checked against already-held
  authority (e.g., a bound CH-WALLET core digest).

References: REF-SHILL-OSDI14, REF-PLASH, REF-CAPSICUM.

## Encoding
Candidate baseline: canonical CBOR (D-ENC).
Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Design constraints (v0)
- total decoding + fail-closed validation
- bounded sizes and closed enums
- **no bearer secrets** and **no raw capabilities**
- no ambient-authority surrogates (host paths, implicit network names) as “permission grants”
- hashable and stable for binding into CH-ACP / transcripts / receipts

## Data model (conceptual)

CH-ENV v0 := {
  v: 0,

  ; Environment variables for a child process. In the strictest profile, this is the *entire*
  ; child environment (default empty). Profiles MAY support a learn-mode that auto-emits a
  ; normalized CH-ENV describing any inherited baseline env.
  env: [ EnvVar ],

  ; Optional non-authoritative hints.
  note?: tstr,
  meta?: { * tstr => any }
}

EnvVar := {
  name: tstr,    ; bounded; recommended: uppercase letters/digits/underscore, length 1–64
  val: EnvVal
}

EnvVal :=
  ; literal value (data only). Literal values MUST NOT be used by the runner to acquire
  ; authority from ambient namespaces.
  { kind: "lit", s: tstr }

| ; typed descriptor reference (digest only). The runner binds the referenced descriptor to
  ; an already-held handle and passes the resulting handle to the child by a profile-defined
  ; mechanism (e.g., handle table slot + opaque reference string). The env var value itself
  ; is not a bearer secret and is not a permission grant.
  { kind: "desc",
    desc_schema: tstr,   ; allowlisted descriptor schema (closed-world; must be permitted by the bound CH-EFFCON v0 effects; e.g., "CH-DOCREF v0")
    desc_digest: bstr    ; digest of canonical bytes of the descriptor
  }

## Validation rules (minimum)

An env validator MUST be total and fail closed (PO-ENV-VALIDATE):
1) `v == 0`.
2) `env` is present (may be empty) and bounded.
3) Each `EnvVar.name` is bounded and matches a conservative allowlist (profile-defined; recommended: uppercase letters/digits/underscore, length 1–64).
4) Each `EnvVal.kind` is in the closed enum.
5) For `lit` values: `s` is bounded.
6) For `desc` values:
   - `desc_schema` is allowlisted (closed-world) and is permitted by the bound CH-EFFCON v0 effect list (see CH-EFFCON “Workflow-bound descriptor allowlist”); profiles may further restrict (subset),
   - `desc_digest` length matches profile hash.
7) Duplicate `name` keys reject deterministically (prevents ambiguous shadowing).
8) Unknown keys reject (or are rejected by canonical CBOR decode).

## Binding semantics (capshell runner)

CH-ENV is a **veto-only** structure:
- It never grants authority (I-ENV-1).
- Runners MUST NOT interpret `lit` values as authority acquisition instructions.

When `capshell.exec` (via CH-EXECPACK) binds `env_digest`:
- The runner MUST check that every `desc` reference corresponds to already-held authority in
  the bound wallet/handle inventory for the execution context.
- The runner MUST also check that each `desc_schema` is permitted by the bound CH-EFFCON `effects[*].kind` list (see CH-EFFCON “Workflow-bound descriptor allowlist”). Any mismatch MUST fail closed and SHOULD emit CH-DENY `deny_code = effcon-violation` bound to `reason.ref_digest = effcon_digest`.
- If any `desc` reference is unknown/unavailable/unbindable, execution MUST fail closed and be
  transcript-visible (I-ENV-2; PO-CAPSHELL-ENV-BIND).
- Rejects SHOULD emit CH-DENY with deny_code `env-bind-failed`, binding `reason.kind="schema"`,
  `reason.ref_schema="CH-ENV v0"`, and `reason.ref_digest=env_digest`.

Notes:
- Secrets should not be carried as literal env strings. Prefer portal-mediated secret descriptors
  (e.g., CH-APPSECRET) and bind them as `desc` values, so secret bytes never appear in CH-ENV.
- The runner’s baseline environment policy is profile-defined. If `cfg.params.capshell.minimal_context=true`, validators MUST require an empty child environment (use an empty CH-ENV); inheritance of any host baseline env remains forbidden in all profiles.
- The child working directory is modeled separately by **CH-CWD v0** (`cwd-schema-v0.md`), so the runner never inherits ambient host cwd and can bind a directory handle explicitly.
