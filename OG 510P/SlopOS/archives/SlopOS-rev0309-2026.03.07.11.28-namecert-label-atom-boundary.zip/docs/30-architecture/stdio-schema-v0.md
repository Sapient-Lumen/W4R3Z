# CH-STDIO v0: capability-bound stdio bindings (schema)

Purpose: eliminate ambient authority in workflow automation by making **process stdio** (stdin/stdout/stderr) an explicit, typed, bindable artifact rather than an inherited ambient channel.

CH-STDIO is designed for D-CAPSHELL:
- **LLMs propose** a `capshell.exec` action carrying `exec_pack_digest = digest(CH-EXECPACK v2)`; the referenced pack binds `stdio_digest = digest(CH-STDIO v0)`.
- deterministic validators/runners **execute** only after validating the bindings and binding any referenced descriptors to already-held handles.

CH-STDIO is **non-authoritative**:
- it MUST NOT contain bearer secrets or raw capability material,
- it MUST NOT be interpreted as a “permission grant,”
- and any binding to real handles MUST be checked against already-held authority (e.g., a bound CH-WALLET core digest).

Rationale: inherited file descriptors and inherited TTYs are a classic “workflow glue” ambient-authority seam (see REF-CAPSICUM, REF-PLASH).

## Encoding
Candidate baseline: canonical CBOR (D-ENC).
Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Design constraints (v0)
- total decoding + fail-closed validation
- bounded sizes and closed enums
- **no bearer secrets** and **no raw capabilities**
- no ambient-authority surrogates (host paths, implicit TTY devices, inherited FD tables)
- stable for binding into CH-ACP / transcripts / receipts

## Data model (conceptual)

CH-STDIO v0 := {
  v: 0,

  stdin:  In,
  stdout: Out,
  stderr: Out,

  note?: tstr,
  meta?: { * tstr => any }
}

In :=
  ; explicit empty/EOF stdin
  { kind: "null" }

| ; typed descriptor reference (digest only). The runner binds the referenced
  ; descriptor to an already-held handle and uses it as stdin.
  { kind: "docref",
    docref_digest: bstr   ; digest of canonical bytes of CH-DOCREF v0
  }

Out :=
  ; explicit discard (no inherited terminal)
  { kind: "drop" }

| ; typed descriptor reference (digest only). The runner binds the referenced
  ; descriptor to an already-held writable handle and uses it as stdout/stderr.
  { kind: "docref",
    docref_digest: bstr   ; digest of canonical bytes of CH-DOCREF v0
  }

### Notes (v0)
- CH-STDIO uses `CH-DOCREF v0` as the only descriptor reference in v0.
  - `stdin.kind="docref"` requires `target_kind="file"` and readable rights.
  - `stdout/stderr.kind="docref"` require `target_kind="file"` and writable/append rights.
- CH-STDIO does **not** model stdio redirection via host paths, inherited FDs, or ambient TTY devices.
- CH-ARGV v0 no longer binds stdio via per-argument roles; stdio is exclusively modeled via CH-STDIO.
- Extra child handles beyond stdio are modeled separately by **CH-FDSET v0** (`fdset-schema-v0.md`).

## Validation rules (minimum)

A stdio validator MUST be total and fail closed (PO-STDIO-VALIDATE):
1) `v == 0`.
2) `stdin/stdout/stderr` are present.
3) Each binding has `kind` in the closed enum:
   - `stdin.kind` in {`null`, `docref`}
   - `stdout.kind` in {`drop`, `docref`}
   - `stderr.kind` in {`drop`, `docref`}
4) For `docref` bindings: `docref_digest` length matches profile hash.
5) Unknown keys reject (or are rejected by canonical CBOR decode).

## Binding semantics (capshell runner)

CH-STDIO is a **veto-only** structure:
- It never grants authority (I-STDIO-1).
- Runners MUST NOT inherit ambient host stdio/TTY state.

When `capshell.exec` (via CH-EXECPACK) binds `stdio_digest`:
- The runner MUST check that every `docref_digest` reference corresponds to already-held authority in the execution context (wallet/handle inventory).
- If any reference is unknown/unavailable/unbindable, execution MUST fail closed and be transcript-visible (I-STDIO-2; PO-CAPSHELL-STDIO-BIND).
- Rejects SHOULD emit CH-DENY with deny_code `stdio-bind-failed`, binding:
  - `reason.kind="schema"`
  - `reason.ref_schema="CH-STDIO v0"`
  - `reason.ref_digest=stdio_digest`

Notes:
- The mechanism for passing bound handles to children is profile-defined (FD passing, handle tables, view binding, etc.), but the **no ambient inheritance** rule is invariant.
- `stdin`/`stdout`/`stderr` are **data channels only** in Phase 1: runners MUST NOT use stdio transport as a hidden capability/handle-passing channel between sibling `capshell.exec` stages; cross-stage authority handoff uses the next stage's explicit CH-EXECPACK bindings (see `capshell-pipeline-posture-v0.md`).
- CH-STDIO composes with CH-ARGV/CH-ENV/CH-CWD: argv/env/cwd/stdio/fdset are independent, explicit seams, each validated and bound fail-closed.
- Extra child handles beyond stdio are bound via CH-FDSET v0; runners must not inherit an ambient handle table.
- If `cfg.params.capshell.minimal_context=true`, validators MUST require `stdin.kind="null"`, `stdout.kind="drop"`, and `stderr.kind="drop"` for `capshell.exec` contexts (PO-CAPSHELL-MINCTX-ENF).
