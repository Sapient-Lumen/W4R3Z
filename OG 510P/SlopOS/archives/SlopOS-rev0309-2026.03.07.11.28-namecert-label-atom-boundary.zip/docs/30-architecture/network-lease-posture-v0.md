# D-NETLEASE posture v0 (no ambient sockets/DNS; portal-issued leased network authority)

Purpose: pin an **implementable Phase 1** meaning for D-NETLEASE that keeps networking non-ambient (I-NETLEASE-1), keeps sealed-compat honest (policy-killable; no ambient channels), and keeps Hybrid/commutativity evidence coherent on the automation surface (D-COMMUTE).

This doc is intentionally narrow: it does **not** design a full firewall UI, per-packet filtering, or “compat sockets” shims.

## Posture (v0)

1) **No ambient socket constructors (networking is explicit authority)**
   - If D-NETLEASE is enabled, the platform MUST NOT expose ambient `socket()/connect()/bind()/listen()` constructors to post-init components.
   - Outbound networking authority is obtained only via `portal.net` (manual workflow) or ACP kind `portal.net.request` (automation), which returns an opaque network authority handle plus a redaction-aware bounds descriptor (CH-NETLEASE v0).
   - Any interop/compat layer that would recreate ambient sockets is out of scope in Phase 1.

2) **No ambient DNS / resolver configuration**
   - If D-NETLEASE is enabled, there is no ambient resolver surface (`/etc/resolv.conf`, `getaddrinfo`-style global resolver APIs, implicit proxy autodiscovery).
   - Domain-name resolution occurs only inside the leased authority:
     - Requests describe destination intent via CH-NETREQ `dest.kind in {dns_name,dns_suffix,service}`.
     - Leases record the granted resolver binding via CH-NETLEASE `resolver.kind="portal"` (v0).
   - Rationale: DNS is both authority and metadata. Treating it as ambient breaks “killable by policy” and creates covert channels.

3) **Scope is a policy label; enforcement is in the leased authority**
   - CH-NETREQ/CH-NETLEASE carry a closed `scope` enum (`internet | local | loopback | explicit`).
   - The portal clamps/denies by policy; the granted `scope` value is part of the receipt surface.
   - Enforcement lives in the leased authority object (PO-NETLEASE-ENFORCE); there is no “bypass” path (I-NETLEASE-2).

4) **Resolver binding is explicit (DNS bind obligation is satisfiable)**
   - For any lease that can resolve names (`kind=="dns"` or `dest.kind in {dns_name,dns_suffix,service}`), CH-NETLEASE MUST include `resolver`.
   - v0 only admits `resolver.kind="portal"`.
   - This keeps PO-NETLEASE-DNSBIND evidenceable without introducing a second, ambient resolver channel.

5) **Externally visible requests are transcripted and commutativity-scoped**
   - `portal.net.request` is an externally visible action:
     - Conflict key family: `domain.id` (so requests in disjoint domains commute).
     - Ordering: **ordered within a domain** (grants are stateful) and requires CH-ORDERTOK v0.
     - Serialization boundary is explicit (`svc:portal.net`) in `serialization-boundary-registry.md`.
   - Dedupe: when the ACP kind claims at-least-once-safe, portals SHOULD dedupe by CH-NETREQ `req_id` and make duplicate suppression transcript-visible (D-RETRYSAFE).

6) **Sealed compat constraints (keep “interop” killable and non-ambient)**
   - Any bridge from leased networking to a legacy interface (e.g., “compat sockets”) MUST be:
     - policy-killable by `cfg.params.lane.portal.net` (fail closed), and
     - incapable of creating ambient channels (no implicit proxy env, no implicit DNS, no implicit “system network”).
   - v0 stance: do **not** standardize such bridges in Phase 1; keep them behind an RFC/ADR.

## Phase 1 non-goals (explicitly deferred)

- **Inbound-by-default networking**: inbound listeners are possible only via explicit leases; “ambient listening” is out of scope.
- **Per-packet filtering / firewall rule language**: any rule UI is a portal policy implementation detail.
- **Legacy transparency**: no “drop-in POSIX sockets” promise.
- **Cross-host capability networking (CeNet-style)**: useful inspiration for future distributed authority models, but not required for v0. (REF-CENET)

## Wiring

- Schemas:
  - `network-request-schema-v0.md` (CH-NETREQ v0)
  - `network-lease-schema-v0.md` (CH-NETLEASE v0)
- Decision surface: `decision-map.md` (D-NETLEASE)
- Portal family: `portal-family-registry.md` (`portal.net`)
- ACP surfaces:
  - `docs/70-llm-control/acp-action-kind-registry.md` (`portal.net.request`)
  - `docs/70-llm-control/acp-validator-semantics.md` (PO-ACP-NET-REQUEST)

CI drift gate:
- `tools/check_netlease_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 “no ambient sockets/DNS” constraints, or drops minimal REF wiring.

## References

- Capability-based sandboxing precedents: REF-CAPSICUM, REF-CLOUDABI.
- Desktop precedents for per-app connection mediation/visibility: REF-LITTLESNITCH, REF-MACOS-NETWORKEXT.
- Least-privilege networking research: REF-CENET.
