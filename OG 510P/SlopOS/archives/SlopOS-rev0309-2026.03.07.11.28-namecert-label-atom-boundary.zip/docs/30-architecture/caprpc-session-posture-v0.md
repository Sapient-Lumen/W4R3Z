# D-CAPRPC session posture v0 (explicit live sessions; fail-stop disconnect; no transparent resume)

Purpose: pin an implementable **Phase 1** meaning for the **live-session boundary** on **D-CAPRPC** so capability-RPC runtime state stays a small explicit seam instead of widening into transparent reconnect/resume, endpoint discovery, or a public object/session inventory.
It narrows RFC-0026 into one compact posture adjacent to **D-CAPX**, **D-TURNS**, **D-REQCTX**, and **D-COMMUTE** so runtimes, validators, and replay/logging tools can reason about one default shape.

## Posture (v0)

1) **Live object references stay explicit, connection-specific, and session-scoped**
   - A live D-CAPRPC handle names callable authority only inside the current transport/runtime session.
   - Live reference ids are connection-specific runtime state, not ambient names, not stable object URIs, and not portable authority outside the current session.
   - Phase 1 therefore treats bootstrap handles, reply routing, and live-reference bookkeeping as explicit bounded session machinery rather than as a shared platform namespace.

2) **Disconnect is fail-stop; no transparent reconnect, replay, or hidden resume**
   - If the live session disconnects, outstanding calls and dependent promise work fail with deterministic framework outcomes.
   - The runtime MUST NOT silently reconnect, silently replay effectful calls, or pretend a broken live reference is still valid.
   - Recovery requires an explicit new session plus explicit application-level retry logic where that is semantically safe.

3) **Bootstrap/reintroduction stays explicit; no ambient resolver or service-name fallback**
   - Entering a live D-CAPRPC session requires an explicit bootstrap capability, explicit introducer/resolver capability, or an explicit **CH-CAPX / CH-SREF** import/restore event under local policy.
   - The portable seam does **not** include ambient service names, path/env discovery, or automatic endpoint selection by convention.
   - This is the concrete session-level reading of **I-CAPRPC-1** and **PO-CAPRPC-NOAMBIENT**.

4) **Persistent/offline capability restore stays outside the live session seam**
   - Persistent continuity belongs to **D-CAPX** / **CH-SREF**, not to live session ids.
   - Phase 1 therefore declines any portable claim that a disconnected live reference can itself be serialized, resumed later, or revalidated across sessions without an explicit restore/import surface.
   - Live references and persistent references stay distinct so logs, validators, and operators can tell whether authority came from a current session or an explicit restore event.

5) **No public session/object inventory, table introspection, or list/watch surface**
   - Phase 1 declines any portable API to enumerate open sessions, list live imported/exported references, inspect bootstrap tables, or subscribe to per-session object churn.
   - Debugging and observation stay on explicit bounded **IF-OBS / CH-LOG** surfaces rather than on a live D-CAPRPC management API.
   - This keeps the session seam out of workflow routing, control-plane inventories, and ambient authority discovery.

6) **Session bookkeeping stays runtime-private and non-replicated**
   - `call_id`, live handle ids, and other per-session routing/bookkeeping stay runtime-private state.
   - Hybrid replication of `object_family = caprpc_proxy` remains **owner-routed metadata only** and MUST NOT recreate callable live references, replay connection-local ids, or infer portable authority from replicated route hints.
   - Phase 1 therefore keeps session machinery bounded, owner-routed, and clearly separate from replicated evidence or restore tokens.

7) **No hidden inbox pumping or scheduler promises on reconnect/recovery**
   - D-CAPRPC session recovery must not reintroduce hidden inbox pumping, reentrancy, or “wait while servicing unrelated inbound work” behavior.
   - Any reconnect or retry helper remains subordinate to **D-TURNS** and **D-REQCTX**: it schedules explicit continuation work or returns a deterministic disconnect/cancel result.
   - The live-session seam is therefore transport state, not a scheduler contract.

8) **External action semantics stay on existing conflict keys and ordering witnesses**
   - Whether a call is attempted on the first session or after an explicit reconnect/retry path, externally visible actions keep the same provider conflict keys, commutativity stance, serialization boundary, and **CH-ORDERTOK** evidence story they already had.
   - D-CAPRPC sessions do **not** mint a session-order authority, a reconnect-local sequencing token, or a new workflow action family.
   - Session state affects liveness only; it does not create new externally visible action semantics.

9) **No new workflow / ACP / admin surface on D-CAPRPC sessions**
   - Phase 1 introduces no portal family, no **CH-ACP** kind, and no generic admin protocol for listing, migrating, forcing, checkpointing, or resuming D-CAPRPC sessions across components.
   - Any future live-session administration surface must pay its own schema, commutativity, and evidence cost explicitly.
   - This keeps D-CAPRPC from quietly becoming a hidden connection manager or durable broker control plane.

10) **Sealed compat remains killable and non-ambient**
   - Foreign Cells may adapt guest RPC/runtime sessions only through explicit, policy-killable membrane surfaces.
   - They must not recreate ambient endpoint discovery, hidden reconnect daemons, or path/env based fallback channels that bypass declared D-CAPRPC handles.
   - Any compat enablement remains subordinate to sealed-compat policy and must fail closed when disabled.

## Phase 1 non-goals (explicitly deferred)

- Transparent reconnect/resume for live references.
- Portable APIs for enumerating sessions, imported/exported live objects, or per-session routing tables.
- Serializing/distributing current-session ids as if they were durable capability references.
- Generic connection-manager / broker-control workflows on D-CAPRPC itself.
- Any new workflow / ACP / admin surface for live-session lifecycle management.

## Wiring

- Decision surface:
  - `decision-map.md` (D-CAPRPC)
- Adjacent runtime surfaces:
  - `mechanisms.md`
  - `rfcs/0026-object-capability-rpc-profile.md`
  - `capability-rpc-frame-schema-v0.md`
  - `capability-rpc-frame-schema-v1.md`
  - `caprpc-promise-posture-v0.md`
  - `caprpc-proxy-replication-boundary-v0.md`
  - `sturdyref-posture-v0.md`
  - `turns-posture-v0.md`
  - `reqctx-posture-v0.md`
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (**I-CAPRPC-1**)
  - `docs/20-assurance/proof-obligation-registry.md` (**PO-CAPRPC-FRAME**, **PO-CAPRPC-NOAMBIENT**)
  - `docs/10-threat-model/abuse-cases.md` (**AC-064**)
- Related posture/history surfaces:
  - `docs/00-meta/profile-posture-matrix.md`
  - `docs/00-meta/resolved-history.md`
  - `docs/00-meta/llm-runbook.md`
- No portal family / ACP kind / conflict-key family addition in v0; any future external session-management surface must pay that entropy cost explicitly.

CI drift gate:
- `tools/check_caprpc_session_posture.py` fails `make lint` if this posture stops being discoverable, loses the **connection-specific / fail-stop disconnect / explicit restore only / no session inventory** posture, or drops its primary REF wiring.

## References

- REF-CAPNP-RPC.
- REF-CAPNP-CXXRPC.
- REF-CAPTP.
