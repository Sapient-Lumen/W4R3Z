# D-PLUMB document portal posture v0 (explicit persistence; non-bearer reopen; no app-visible grant inventory)

Purpose: pin an **implementable Phase 1** meaning for `portal.file.*` and CH-DOCREF so open/save/reopen workflows stay capability-shaped and path-free.
It narrows an already-present RFC/schema seam into something validators, UX, and harnesses can test without turning SlopOS into an ambient recent-doc database, a host-path API, or a silent persistence footgun.

## Posture (v0)

1) **`portal.file.*` remains manual-only in v0**
   - File open/save/export/share authority is obtained only through an interactive chooser/powerbox workflow.
   - There is no CH-ACP automation kind for `portal.file.*` in Phase 1.

2) **Persistence is explicit; chooser defaults stay ephemeral**
   - The default chooser result is a live scoped handle/cap for the current workflow.
   - A durable CH-DOCREF with `persistent=true` is minted only when the user or policy explicitly requests persistence.
   - Phase 1 rejects silent “always persistent” chooser defaults.

3) **CH-DOCREF remains non-bearer and origin-bound**
   - A docref alone is not authority.
   - Reopen authenticates the caller, enforces `origin.comp_id`, and re-applies active policy before any handle is issued.

4) **Reopen clamps; it never widens rights or target scope**
   - Reopened handles may not exceed the stored `rights` or `target_kind`.
   - A file grant does not become a directory grant, `read` does not become `read_write`, and reopening does not imply ambient sibling/ancestor discovery.
   - Directory grants remain scoped to the explicitly granted root; recursive breadth beyond that root requires a fresh mediated choice.

5) **Handles stay path-free and bounded**
   - `portal.file.*` returns capability-shaped handles or portal-owned view bindings, not host paths.
   - CH-DOCREF labels remain optional, bounded, and redaction-friendly.

6) **No app-visible grant inventory/list API in v0**
   - Phase 1 does not expose an ambient `list()` or “enumerate all prior grants” API to applications.
   - Any “manage remembered files” UI is shell/portal-owned and review-bound.

7) **Revocation and restore stay honest**
   - Revoked, expired, or replaced targets fail closed on reopen.
   - Restore must not resurrect revoked grants, and strict profiles MAY require fresh consent after restore.

8) **Sealed compat remains killable and non-ambient**
   - Any Foreign Cell open/save adapter must flow through `portal.file` / CH-DOCREF or an equivalent portal-issued handle.
   - Compat runtimes do not gain an ambient host-path escape hatch; the seam remains fail-closed behind `cfg.params.lane.portal.file`.

## Phase 1 non-goals (explicitly deferred)

- **ACP / background automation** for `portal.file.*`.
- **Ambient recent-document inventory APIs** visible to applications.
- **Host-path round-tripping** as an interop convenience.
- **Cross-app bearer sharing** by copying CH-DOCREF values around.
- **Implicit scope widening** from file→directory, read→write, or remembered directory grants becoming a general recursive host browser.

## Wiring

- Decision surfaces:
  - `decision-map.md` (D-PLUMB, D-POWERBOX)
- Schemas:
  - `document-handle-schema-v0.md` (CH-DOCREF v0)
  - `effect-contract-schema-v0.md` (`portal.file` effect family)
- Portal/control surfaces:
  - `portal-family-registry.md` (`portal.file.*`)
  - `config-toggle-registry.md` (`cfg.params.lane.portal.file`)
  - `pledge-token-mapping.md` (`portal.file`)
- Assurance surfaces:
  - `docs/20-assurance/invariant-registry.md` (I-PLUMB-1, I-DOCREF-1, I-DOCREF-2, I-DOCREF-3)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-DOCREF-VALIDATE, PO-DOCREF-REOPEN, PO-DOCREF-ENF)
  - `docs/10-threat-model/abuse-cases.md` (AC-076)

CI drift gate:
- `tools/check_document_portal_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 **manual-only / explicit persistence / no app-visible grant inventory** constraints, or drops its primary REF wiring.

## References

- REF-XDG-PORTAL-FILECHOOSER.
- REF-XDG-PORTAL-DOCUMENTS.
- REF-APPLE-SECBOOKMARK.
- REF-ANDROID-SAF-DOCUMENTS.
