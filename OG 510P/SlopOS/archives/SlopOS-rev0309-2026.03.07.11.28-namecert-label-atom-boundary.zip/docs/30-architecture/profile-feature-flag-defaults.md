# Profile feature-flag defaults matrix (A–D; no forks)

Purpose: pin **non-authoritative** default guidance for `cfg.feature_flags` profile extensions across the four product shapes:

- (A) secure workstation,
- (B) cloud micro-VM / hosted compute substrate,
- (C) embedded / separation-kernel-ish appliance,
- (D) agent/automation OS.

This matrix is a **composition aid**, not a fork mechanism:
- For the artifact boundary between these recommendations and generated CH-CFG / CH-POLICY outputs, see `profile-default-artifact-boundary-v0.md`.
- Profiles may override these defaults in signed CH-CFG / policy bundles.
- Unknown `feature_flags` values MUST be rejected by IF-CFG per `config-toggle-registry.md` (PO-CFGTOGGLE-VERIFY).
- Enabling a flag **never grants authority**; it only selects an optional semantic profile slice.

Stability rule: treat this file as a **stable diff surface**. Any changes must:
- keep A–D viable (no forks),
- preserve sealed-compat posture (foreign cell stays portal/intent/receipt only; killable), and
- preserve “no ambient authority” (flags do not create implicit channels).

## Defaults (v0 seed; conservative)

Values:
- `on`: recommended to be enabled in the profile’s default policy bundle.
- `off`: recommended to be disabled in the profile’s default policy bundle.

| Flag value | A (workstation) | B (cloud substrate) | C (embedded/separation) | D (agent/automation) | Notes |
|---|---|---|---|---|---|
| `ext.static_partitioning` | off | off | on | off | reduces proof/analysis entropy for strict appliances (fixed cores + fixed memory partitions); avoid enabling where overcommit/elasticity is required |
| `ext.microvm` | off | on | off | off | microVM device-model profile (D-MICROVM); pairs with D-MK placement constraints and tight exit-surface budgets |
| `ext.confidential_computing.attest_only` | off | off | off | off | enable only with explicit assumption/claim scoping; does not imply side-channel safety |
| `ext.confidential_computing.enforced` | off | off | off | off | enable only with explicit platform constraints + claim scoping; high verification/evidence burden |
| `ext.cheri` | off | off | off | off | research lane; enable only when the CHERI-enforced subset is explicitly scoped |
| `ext.capx_remote_delegation` | off | off | off | off | remote delegation is a sharp edge; default off even with the new sturdyref posture: Phase 1 keeps CH-SREF explicit restore-only, no ambient resolver/inventory, and digest-only on routine workflow/observation surfaces (D-CAPX) |
| `ext.wasm_plugins` | on | on | off | on | extension profile via Wasm plugins; keep host boundary capability-only; avoid for minimal embedded appliances |
| `ext.ifc_lite` | off | off | off | off | enable only when the label budget + downgrade rules are explicitly pinned (avoid “label everything” drift) |
| `ext.user_mode_pager` | off | on | on | off | user-mode pager profile; aligns with isolation-heavy B/C deployments; ensure DoS posture via D-METER when enabled |

## Guardrail

CI enforces:
- every `cfg.feature_flags` value in `config-toggle-registry.md` appears in the table above,
- no extra values are introduced here,
- values are from the closed set `{on, off}`.

Tool: `tools/check_profile_feature_flag_defaults.py`.
