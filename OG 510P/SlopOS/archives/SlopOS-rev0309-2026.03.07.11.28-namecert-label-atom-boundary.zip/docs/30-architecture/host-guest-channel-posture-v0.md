# Host↔guest channel posture v0 (no ambient host channels in `ext.microvm`)

Purpose: pin the Phase‑1 meaning of **host↔guest communication channels** under `ext.microvm` so “helpful virtualization devices” do not become an ambient authority surface.

This is a *meaning pin* attached to D-MICROVM’s “no hidden host channels” rule: it makes the exclusions explicit and keeps sealed‑compat killable.

## Posture (v0)

When `cfg.feature_flags` includes `ext.microvm`:

1) **No ambient host↔guest transports**
   - v0 MUST NOT expose a general host↔guest transport as an ambient API surface.
   - In particular, **virtio‑vsock** (AF_VSOCK) MUST be **disabled** as an in‑guest syscall surface in Phase 1.

2) **No host filesystem sharing devices**
   - v0 MUST NOT expose host directory trees in‑guest.
   - In particular, **virtio‑fs** and **9p/virtfs** style “shared folder” devices are **disallowed** in Phase 1.

3) **No implicit host control plane**
   - The microVM profile MUST NOT rely on an implicit “host agent” channel for policy or capability changes.
   - Any mutation of policy/authority MUST route through explicit IF surfaces and produce transcript-visible receipts.

4) **Allowed v0 device classes do not add ambient channels**
   - v0 may use virtio devices for **block** and **network** transport, but these MUST NOT create ambient authority inside the guest:
     - Network effects remain portal-issued leased authority (D-NETLEASE); there is no ambient socket/DNS surface.
     - Block devices are treated as sealed images; they do not imply host path access.

5) **Interop must be explicit + killable (future admission rule)**
   - If we later admit host↔guest transports (vsock-like) or host FS sharing, the interface MUST:
     - be **lane-gated** (killable by policy),
     - be expressed as an explicit portal/lease seam (no ambient constructors), and
     - carry D-COMMUTE metadata (conflict keys + ordering) for any externally visible mutating action.

## Phase 1 non-goals (explicitly deferred)

- No “host agent” protocol design in v0 (vsock control planes, guest management daemons).
- No virtio‑fs / 9p / shared-folder semantics (requires an explicit portal/lease design and sealed-compat review).
- No in‑guest vsock APIs for “fast local calls” (requires a capability/lease model and covert-channel review).

## Wiring

- Decision surface: D-MICROVM in `decision-map.md` (this doc pins part of “no hidden host channels”).
- Primary posture: `microvm-profile-posture-v0.md` (calls out the exclusion set; Phase 1 scope discipline).
- Related postures:
  - `network-lease-posture-v0.md` (D-NETLEASE; “virtio-net exists” does not imply ambient sockets/DNS)
  - `observation-export-posture-v0.md` (D-OBS; export is pull-only and killable; avoid “console as ambient exfil”)
  - `seal-posture-v0.md` (D-SEAL; post-seal authority widening requires an explicit reconfiguration action)
- Sealed compat honesty: any future host↔guest interop must remain killable and must not introduce ambient `path/env/net` channels.
- CI drift gate: `tools/check_host_guest_channel_posture.py` (EVID-2026-230).

## References

- REF-FIRECRACKER-VSOCK
- REF-CHYP-VSOCK
- REF-LINUX-VSOCK-MAN7
- REF-VIRTIOFS-DESIGN
- REF-LINUX-VIRTIOFS
