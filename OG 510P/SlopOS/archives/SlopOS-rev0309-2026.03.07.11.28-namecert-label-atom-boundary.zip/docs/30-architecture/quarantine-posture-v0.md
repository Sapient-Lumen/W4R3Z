# D-QUAR posture v0 (monotonic; object-local clear; safe-open does not mutate trust in place)

Purpose: pin an **implementable Phase 1** meaning for D-QUAR so origin/quarantine metadata becomes a small,
reviewable workflow boundary rather than a vague “warning bit” that different tools clear differently.
It narrows the existing RFC into something worth coding: quarantine is **monotonic by default**, clearing is
**manual-only and object-local**, safe-open stays a **disposable/view-first** workflow, and any “this is now safe”
materialization happens by creating a **new artifact** with a fresh digest and transcript record rather than mutating trust in place.

This doc says what Phase 1 quarantine *is* and what it is *not*:
an **explicit provenance + gating posture** bound to object digests and safe-open workflows — **not** an app-private flag,
not a recursive “trust this folder/archive tree” toggle, and not a hidden notarization/AV verdict channel that silently dequarantines content.

## Posture (v0)

1) **Origin/quarantine stay explicit data, not app-private heuristics**
   - If D-QUAR is enabled, origin and quarantine state live in the declared `origin.*` / `quarantine.*` attribute set.
   - Applications and compat runtimes do not get to invent parallel private trust bits that bypass the shared contract.
   - `origin.locator_hint` remains informational only and must not become an authorization input.

2) **Propagation is monotonic and container-aware**
   - Copy, extract, derive, and equivalent container decode flows preserve quarantine by default.
   - Rename, repack, archive nesting, or “open then save elsewhere” must not silently drop quarantine.
   - Container handling is part of the contract, not an implementation detail left to individual apps.

3) **Clearing is manual-only, object-local, and never recursive**
   - Phase 1 quarantine clear remains an IF-CONSENT mediated action with transcript logging.
   - Clearing object `X` does **not** recursively clear siblings, descendants, extracted children, enclosing archives, or future derivations.
   - There is **no ACP automation kind** for quarantine clear / safe-open override in v0.

4) **Safe-open is a view/execute workflow, not a trust mutation**
   - Opening or previewing quarantined content routes through the safe-open workflow (typically disposable domain + explicit export) unless an explicit override is authorized.
   - Safe-open must not silently rewrite `quarantine.state` on the source object.
   - Preview/open success does not mean “trusted forever”; it means a bounded workflow was allowed to inspect the object.

5) **Safe export creates a new artifact; it does not launder the source in place**
   - Any dequarantined materialization across the trust boundary is a **new artifact** with its own digest, provenance, and transcript-visible justification.
   - The source object remains quarantined unless it is separately and explicitly cleared.
   - “Sanitize then trust” is modeled as *derive a new object*, not *mutate the old object’s trust bit*.

6) **Verification may gate consent, but it does not silently clear**
   - Signature checks, notarization, scanning, or parser validation may inform policy/UI for the clear decision.
   - Those results do **not** auto-clear quarantine in Phase 1.
   - Any future policy-assisted fast path still needs an explicit transcript-visible authorization edge.

7) **Sealed compat and importers remain killable and non-ambient**
   - Foreign Cell import/open flows must respect D-QUAR and route quarantined content through safe-open or explicit clear.
   - Interop must not create a hidden “legacy app saved this without tags” laundering path.
   - If a profile disables D-QUAR, it does so explicitly rather than via compat exceptions.

## Phase 1 non-goals (explicitly deferred)

- **No recursive “trust this archive/folder tree” clear**.
- **No “opened once == permanently trusted” behavior**.
- **No policy-hidden auto-clear after signature, notarization, or AV verdict**.
- **No app-private quarantine bits** that bypass the shared attribute + consent contract.
- **No rename/repack/container loophole** that treats equivalent bytes as newly trusted without a logged workflow.

## Wiring

- Decision surface:
  - `decision-map.md` (D-QUAR, D-EPHEM, D-PLUMB)
- Schema / attribute surfaces:
  - `origin-quarantine-attrset.md`
- Related workflow notes:
  - `document-portal-posture-v0.md`
  - `transfer-portal-posture-v0.md`
- Assurance hooks:
  - `docs/20-assurance/invariant-registry.md` (I-QUAR-1, I-QUAR-2, I-QUAR-3, I-QUAR-4, I-QUAR-5)
  - `docs/20-assurance/proof-obligation-registry.md` (PO-QUAR-PROP, PO-QUAR-GATE, PO-QUAR-CLEAR, PO-QUAR-LOCAL)
  - `docs/10-threat-model/abuse-cases.md` (AC-040)
- RFC history:
  - `rfcs/0053-origin-quarantine-and-safe-open.md`

CI drift gate:
- `tools/check_quarantine_posture.py` fails `make lint` if this posture stops being discoverable, loses its Phase 1 **manual-only / object-local clear / safe-export-creates-new-artifact / no silent auto-clear** constraints, or drops its primary REF wiring.

## References

- REF-MOTW-ZONEID.
- REF-MACOS-GATEKEEPER.
- REF-GATEKEEPER-BYPASS.
- REF-MS-PREVIEW-MOTW.
