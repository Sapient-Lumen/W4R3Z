# CH-FAULT v0 (fault request message schema, informal)

Purpose: a **bounded**, minimally-informative kernel→user message for reporting faults (page faults and similar) to a designated handler in D-PAGER.

This schema is meant to be *boring*:
- closed enums, fixed field names
- no raw kernel object identifiers
- minimize address-space leakage when a shared pager is used

## Design constraints (v0)
- Canonical decode/encode (I-ENC-1) for hashing/logging.
- Explicit routing only (I-PAGER-1; PO-PAGER-ROUTE).
- No ambient authority: the fault message does not, by itself, grant mapping power.

## Message shape (v0)
A fault request `f` contains:
- `schema`: fixed `CH-FAULT v0`
- `kind`: enum: `page | access_violation | other` (closed)
- `access`: enum: `read | write | exec` (closed)
- `object`: a **fault reference** (one of):
  - `vmo`: `{ id_hint, offset, len }`  (preferred; avoids virtual-address leakage)
  - `as`: `{ vaddr, len }`  (per-address-space pager mode only)
- `flags`: small bitset (bounded) e.g. `user`, `present`, `cow`, `is_instruction`
- `nonce`: bounded integer/bytes used only for correlation (not a secret)

### Attached capability (out-of-band)
The kernel delivers the fault message along with a *single attached capability*:
- `reply`: a one-shot “fault reply token/endpoint” that authorizes completing **this** fault (e.g., by mapping a page or rejecting).

This avoids making the message body itself capability-bearing.

## Validation / bounds
- `len` is bounded (e.g., ≤ 64 KiB) and page-aligned when `kind=page`.
- unknown enum values or extra keys are rejected deterministically.

## Notes
- In production systems, pager requests are often delivered to a port/queue (REF-FUCHSIA-PAGER) or via IPC to a designated pager thread (REF-L4RE-DS-RM). This schema abstracts over the transport.
- If D-RR is enabled, `nonce` can help correlate CH-FAULT events with replay traces without exposing raw kernel IDs.
