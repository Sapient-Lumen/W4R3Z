# D-OBS posture v0 (bounded, pull-only exports; no ambient indexing or auto-exfil)

Purpose: pin an **implementable Phase 1** meaning for D-OBS that keeps observation export:
- **explicit and policy-killable** (no “always-on” export channel),
- **bounded + redaction-first** (I-OBS-1; PO-OBS-REDACT),
- and **non-authoritative** (observations explain/replay; they never grant effects).

This doc constrains the **spec surface** (IF-OBS + artifacts + policy hooks). It does **not** design a full logging stack, tracing system, metrics engine, or on-device query language.

## Posture (v0)

1) **Export is pull-only and explicit (no ambient exfiltration path)**
   - IF-OBS exports occur only on an explicit operator/tool request.
   - Phase 1 forbids “auto-send diagnostics to a remote endpoint” behaviors (syslog-forwarding, OTLP exporters, “phone home” crash upload) as an *ambient* default.
   - Any remote forwarding (if later allowed) must be:
     - invoked as an explicit workflow/tool step (e.g., capshell exec),
     - **killable** (see `cfg.params.lane.obs.export`), and
     - constrained by the same redaction/bounds policy (CH-OBSPOL when enabled).

2) **A lane kill switch exists for export (policy must be able to turn exports off)**
   - `cfg.params.lane.obs.export` is a kill switch for IF-OBS export and snapshot tooling that *uses* IF-OBS.
   - When `cfg.params.lane.obs.export=false`, IF-OBS export MUST deterministically reject (fail closed) and emit a transcript-visible denial/error (PO-LANE-KILL; I-LOG-1).
   - Rationale: a “privileged export” that cannot be disabled is an ambient channel.

3) **Default is sanitized; “full” exports require explicit authority and must remain bounded**
   - The default export tier is **sanitized** (no raw addresses, no secret-bearing caps, no sturdy refs) as constrained by policy.
   - If a deployment allows a “full” tier, it MUST require explicit operator authority and remain bounded by policy (CH-OBSPOL `tier='full'` still clamps size/classes).
   - Export tooling MUST fail closed on policy mismatches (I-OBSPOL-1; PO-OBSPOL-APPLY).

4) **No ambient global indexing / query service in Phase 1**
   - Phase 1 forbids introducing a global, ambient “search all logs/objects” interface.
   - If indexing exists at all, it must be capability-mediated and scope-limited (e.g., view-scoped) and must not create new implicit joins across domains.
   - Rationale: global indexing is a covert-channel amplifier and a drift magnet.

5) **Exports are non-mutating and commutative at the spec surface**
   - IF-OBS export is a read-only observation surface: it MUST NOT mutate privileged state.
   - Any stateful export behavior (cursors, “mark read”, retention toggles) is out of scope for v0 unless introduced via RFC with explicit conflict keys + serialization boundary.
   - This keeps D-COMMUTE evidence coherent: export operations commute by construction because they do not claim stateful effects.

6) **Artifacts are digest-pinned and explainable**
   - Exported observation payloads are represented as **CH-OBS v0** (and optional companion artifacts like CH-SNAPSHOT/CH-CRASHCAP when D-INSPECT/D-FLIGHTREC are enabled).
   - When CH-OBSPOL is enabled, tooling MUST record the applied policy digest alongside outputs (I-OBSPOL-1), so “what rules were applied?” is non-ambient.

## Phase 1 non-goals (explicitly deferred)

- **Always-on remote telemetry exporters** (OTLP/syslog forwarders) as a built-in, ambient behavior.
- **A general query language** (SQL/regex scripting) in the privileged export path.
- **Cross-domain global search** of logs/inspect trees by default.
- **Stateful export cursors** ("give me everything since last time") without an explicit conflict-key/serialization design and evidence plan.

## Wiring

- Decision surface: `decision-map.md` (D-OBS; D-OBSPOL)
- Privileged interface: `interface-registry.md` (IF-OBS)
- Policy + artifacts:
  - `observation-schema-v0.md` (CH-OBS v0)
  - `observation-export-policy-schema-v0.md` (CH-OBSPOL v0; optional)
  - `diagnostic-snapshot-bundle-schema-v0.md` (CH-SNAPSHOT v0; optional; D-INSPECT)
- Config kill switch:
  - `config-toggle-registry.md` (`cfg.params.lane.obs.export`)
  - `profile-lane-defaults.md` (A–D defaults)

CI drift gate:
- `tools/check_obs_export_posture.py` fails `make lint` if the v0 meaning (pull-only, killable, bounded, no ambient indexing) stops being discoverable or loses minimal REF wiring.

## References

- Fuchsia diagnostics stack precedent (user-space aggregation + structured artifacts + tooling): REF-FUCHSIA-DIAGNOSTICS.
- Fuchsia “Archivist”/Inspect hosting model (on-demand aggregation; capability discovery): REF-FUCHSIA-INSPECT-TREE.
- Bounded logging behavior under overload as a platform contract: REF-SYSTEMD-JOURNALD.