# CH-RECEIPT v0: Consent receipt (schema)

Purpose: record a **non-authoritative** receipt for an allow/deny decision that binds:
Posture note: CH-VOL evidence used by a receipt remains governed by `volition-posture-v0.md`: receipts may reference `vol_digest`, but neither receipts nor CH-VOL provide batch/cached approval semantics.

(1) the requested action, (2) what was shown to the user (summary/diff), (3) the approval evidence, and (4) the outcome.

Receipts are designed to be:
- human-legible (via a stable summary structure),
- machine-checkable (digest-bound), and
- privacy-minimized (no raw capability secrets).

References: REF-KANTARA-CONSENT-RECEIPT, REF-UDAC-SP12.

## Encoding
Candidate baseline: canonical CBOR (D-ENC), optionally wrapped with COSE for signatures.
Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-RECEIPT v0 := {
  v: 0,

  receipt_id: bstr,           ; random 128-bit (or more) identifier, for local indexing
  issued_at: uint,            ; monotonic or wall-clock (profile-defined). if monotonic, interpret as “relative time”.

  ; who requested / who is subject
  subject: {
    subject_kind: tstr,        ; closed enum: "domain" | "user" | "session"
    subject_id: bstr,          ; local stable id (opaque; not a username)
  },
  requester?: {
    component_id: tstr,        ; CH-COMP identity string or other profile-defined id
    instance_id?: bstr,        ; optional runtime instance identifier
  },

  ; what was asked to do
  action_schema: tstr,        ; e.g. "CH-ACP v0" | "CH-KABI v0" | "CH-ROUTE v0"
  action_digest: bstr,        ; digest of canonical bytes of the action/request

  ; commutativity/ordering observability (optional; non-authoritative)
  conflict_key_digest?: bstr, ; optional digest(CH-CONFLICTKEY v0) when the action kind has a declared conflict key (D-COMMUTE)
  order_digest?: bstr,        ; optional digest(CH-ORDERTOK v0) when the action is ordered and carries an ordering witness (D-COMMUTE)

  ; what was shown (canonical summary structure; then rendered to text)
  summary_kind: tstr,         ; closed enum: "grant" | "route" | "lease" | "mixed"
  summary_digest: bstr,       ; digest of canonical bytes of the summary structure
  diff_digest?: bstr,         ; optional digest of CH-CAPDIFF v0 (preferred) or a profile-defined typed diff structure
  locale_hint?: tstr,         ; optional; informational only; MUST NOT affect digest meaning

  ; approval evidence (non-authoritative in receipt context)
  authz_schema?: tstr,        ; typically "CH-AUTHZ v0"
  authz_digest?: bstr,        ; digest of approval token (if an approval existed)
  vol_schema?: tstr,          ; typically "CH-VOL v0"
  vol_digest?: bstr,          ; digest of volition token (if used)

  ; result
  decision: tstr,             ; "allow" | "deny"
  result_schema?: tstr,       ; optional: schema of a result payload (if any)
  result_digest?: bstr,       ; digest of canonical result bytes (or empty for none)

  ; lifetime / revocation metadata (if applicable)
  exp?: uint,                 ; optional expiry timestamp (profile-defined)
  rev_epoch?: uint,           ; optional revocation epoch at issuance (if revocation is enabled per D-CAP)
  lease_id?: bstr,            ; optional: identifier of a lease object (D-IOLEASE/D-TCAP)

  ; optional, constrained “rationale” from requester (untrusted)
  rationale?: {
    purpose: tstr,            ; closed enum in profile, e.g. "open-file", "share", "screencast"
    hint?: tstr,              ; bounded length; displayed as decoration only
  },

  meta?: { * tstr => any }  ; optional; MUST be ignored unless whitelisted
}

## Validation rules (minimum)
Validators MUST be total and fail closed:
1) `v == 0` and required fields present.
2) `action_schema` is in a closed allowlist; `action_digest` length matches profile hash.
2a) If `conflict_key_digest` is present, it MUST match the profile digest length.
2b) If `order_digest` is present, it MUST match the profile digest length.
3) If `authz_schema`/`authz_digest` present, `authz_schema` is allowlisted (typically CH-AUTHZ v0).
4) `summary_kind` is allowlisted; `summary_digest` length matches profile hash.
5) `decision` is in the closed enum.
6) **Non-authoritative rule**: no validator may treat a receipt as approval evidence; it is only an audit artifact.

Producer rules (normative, when D-COMMUTE is in scope):
- If `action_schema == "CH-ACP v0"` and the action kind has a declared conflict key (per `docs/70-llm-control/acp-action-kind-registry.md`), producers MUST include `conflict_key_digest` as the **derived** key (not a copy of untrusted input).
- If the action is an **ordered** kind, producers MUST include `order_digest` and SHOULD also include `conflict_key_digest`.

## Security notes
- Receipts may reveal sensitive metadata; exports must be redacted/minimized (align with C-OBS-1).
- Receipts MUST NOT contain raw capability material. If a UI needs to “re-open” a granted resource, it must do so via fresh portal consent, not by replaying receipts.
- Hybrid note: if CH-RECEIPT artifacts are replicated under `object_family = receipt`, they remain immutable evidence only; replicated receipts cannot satisfy consent locally, skip fresh portal approval, or resurrect an old lease/handle (`receipt-replication-boundary-v0.md`).
- `conflict_key_digest` and `order_digest` are **non-authoritative** observability fields. They must not be used to grant effects or bypass capability checks (I-CONFLICTKEY-1; I-ORDERTOK-1).
