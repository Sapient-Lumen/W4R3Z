# System generation pipeline (CH-COMP → CH-INIT) (Microkit/capDL-inspired)

Goal: keep early system bring-up **simple, static, and auditable** by supporting an optional build-time pipeline that compiles a declared composition (CH-COMP) into a concrete time‑0 snapshot (CH-INIT), minimizing runtime “init logic” and making it easier to test/verify that “boot matches intent”.

This is an *engineering posture* layered on D-COMP + D-INITSNAP:
- CH-COMP remains the **authoring** and review artifact (“what should run + how routing is allowed”).
- CH-INIT is the **realized** time‑0 object/capability graph (“what actually exists at boot”).

Inspiration: seL4’s capDL + Microkit toolchain, which treats architecture as a static description compiled into an initializer/runtime that sets up the system state.

Refs: REF-MICROKIT-MANUAL, REF-MICROKIT-GITHUB, REF-CAPDL-KUZ10, REF-MICROKIT-VERIFY24.


## Inputs
- **CH-COMP v0** (authoring): components, routes, restart/criticality metadata, and optional readiness/health annotations.
- Optional adjuncts (authoring):
  - CH-PART / CH-ADDRNET / CH-HWFACT (if the profile uses them)
  - Profile policy: bounds (max objects/caps), scheduling stance, device exposure posture


## Outputs
- **CH-INIT v0** (snapshot): bounded list of objects + capability edges + optional initial maps (profile-scoped).
- Optional accelerator (ecosystem): a digest-identified **template image** derived from CH-INIT (or a cooperative CH-CKPT) to enable low-latency spawning of disposable domains (zygote-style) without adding privileged-kernel logic.
- Optional build products (non-authoritative, for tooling/debug):
  - `init.diff` (CH-COMP intent vs realized CH-INIT summary)
  - `cap-graph.svg` or `cap-graph.json` (for visualization)

### Recovery deployment (D-RECOVERY)
If the profile enables D-RECOVERY (RFC-0098), the build pipeline SHOULD also emit a **recovery deployment root**:
- built from a minimal CH-COMP/CH-INIT composition (diagnostics + rollback/config tooling),
- sealed/minimal by default (no ambient network/device attach),
- installed into a reserved slot, and
- referenced from release intent and boot records as an `artifacts[]` entry with role `recovery_root` (CH-UPD/CH-BOOT convention).

This keeps recovery in the same digest/provenance universe as normal deployments without adding privileged logic.


## Pipeline stages
### Stage A: Authoring + lint (CI)
- Validate CH-COMP (closed-world validation; reject unknown variants).
- Lint for authority hazards:
  - no undeclared routes (I-COMP-1 profile),
  - no ambient acquisition edges (D-CAPMODE discipline),
  - seal_after_init coverage on critical components (D-SEAL profiles),
  - restart storm risk heuristics (RFC-0017).

### Stage B: Sysgen (build-time compilation)
- Allocate the initial object graph deterministically (IDs are stable under a chosen ordering).
- Expand declared routes into concrete capability edges:
  - enforce attenuation rules (rights reduction only unless an explicit authority object is present).
- Optional: materialize profile-specific objects (meters, sched contexts, device windows) using CH-PART/CH-ADDRNET.

Output: CH-INIT snapshot + a small “init plan” artifact for humans.

### Stage C: Boot-time installation
Two modes (both are acceptable; chosen by profile):
- **Interpretation mode**: user-space init reads CH-COMP and creates objects/caps at runtime.
- **Snapshot mode**: a tiny initializer installs exactly the CH-INIT snapshot (and can still hand off to a user-space supervisor).

Snapshot mode is preferred for high-assurance profiles because it reduces runtime degrees of freedom.


## Assurance hooks
- **PO-INIT-VALIDATE**: CH-INIT decoding/validation is deterministic and bounded.
- **PO-INIT-MATCH**: installed initial state matches CH-INIT within the declared equivalence.
- **PO-COMP-BIND**: if CH-COMP is used, its digest is bound in CH-BOOT (and ideally tied to the CH-INIT digest if snapshot mode is used).

Evidence targets (early):
1. Golden tests: a tiny CH-COMP produces an expected CH-INIT (stable IDs, stable edges).
2. Negative tests: invalid routes/rights amplification fail closed.
3. Boot check: attempt to boot with tampered CH-INIT must fail closed and be transcript-visible.


## TCB posture
- Sysgen tooling is **not** in the privileged core.
- The trusted part (if snapshot mode is used) is a small initializer + validator that:
  - validates CH-INIT,
  - instantiates objects/caps,
  - records/binds digests into CH-BOOT/CH-LOG for audit.

Rule: keep the initializer’s behavior a straight-line “install snapshot” procedure with total validation. Complex policy stays in authoring tools and validators.
