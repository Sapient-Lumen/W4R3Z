# Authority bracketing + promise learning workflow (D-SEAL / CH-PLEDGE)

Goal: make “init → sealed steady state” a boring, repeatable engineering habit that scales to large codebases and compatibility shims.

This doc assumes the core discipline:
- no ambient acquisition (or at least: acquisition is explicit via views/portals), and
- sealing is **one-way** (I-SEAL-1, I-PLEDGE-1..3).

## 1) The bracket: three phases

### Phase A — Init (wide, but explicit)
- Acquire the minimum set of *bootstrap* capabilities needed to configure steady state (views, ports, caches, routing).
- Prefer to acquire capabilities via **portals** (D-PLUMB) or explicit view objects (D-NS), not ad-hoc “open by name” APIs.

### Phase B — Narrow
Apply any subset of these *stackable* narrowing steps:
1) **Drop capabilities**: delete unused handles; revoke introducers if present.
2) **Seal views** ("unveil on views"): remove subtrees and/or forbid further mounts/binds in the active view object(s).
3) **Install CH-PLEDGE**: apply a one-way promise mask for the steady-state effect families.
4) **Enter capmode** (optional, D-CAPMODE): forbid ambient acquisition after init.

### Phase C — Steady state (small, testable surface)
- Operate only using the reduced set of capabilities.
- Treat any “needs more authority” as a bug or an explicit reconfiguration event.

## 2) Pledge learning mode (how to pick the tokens)

The biggest adoption trap for sandboxing APIs is policy authoring cost.
We want *token-level* policy (CH-PLEDGE) that is:
- small and closed-vocab,
- easy to learn,
- and easy to mechanically validate.

### Recommended practice
- Start with `violation = "deny"` in CH-PLEDGE (complain-style behavior).
- Ensure each denied effect emits a **stable violation record** to CH-LOG/CH-OBS with:
  - the denied action kind (e.g., CH-KABI `kind`),
  - the active CH-PLEDGE digest,
  - and the component identity.
- Run the service under representative workloads.
- Derive the *minimal* promise token set from the logged violations.
- Switch to `violation = "kill"` for hardened profiles.

This is conceptually similar to “learning/debug modes” explored in modern sandboxing work (e.g., Threadbox) and aligns with why pledge-style coarse promises are more usable than syscall allowlists.

## 3) CI guardrails (cheap, high leverage)

### A) Post-seal steady-state invariant checks
- If a component declares `seal_after_init = true` in CH-COMP:
  - require a transcript-visible “seal point” (e.g., log entry referencing CH-PLEDGE digest and view-lock event),
  - and require no forbidden effect kinds after that point.

### B) Negative tests
- For each promise token set used in production profiles:
  - attempt a representative forbidden effect,
  - assert deny/kill behavior is deterministic,
  - and assert a violation record is emitted in `deny` profiles.

### C) Mapping drift check
- Any change to the pledge token→effect mapping table must:
  - update tests that cover the mapping,
  - and add/update an evidence index entry.

## 4) Common failure modes
- **Seal too late**: “init” silently grows. Fix by making “ready” depend on sealing when `seal_after_init` is set.
- **Hidden bypass**: a fast path skips pledge checks. Fix by enforcing at the *single* privileged dispatch point (I-PLEDGE-2).
- **Overbroad tokens**: the service stays “working” but carries excess authority. Fix by iterating in deny/learn mode.
- **Narrowing loophole**: view wasn’t locked; the process can unveil/mount new subtrees later. Fix by sealing views.

## 5) What this is *not*
- Not a replacement for correct capability distribution.
- Not a claim of confinement if the service retains powerful capabilities and promises include using them.
- Not an excuse to reintroduce ambient file/network acquisition.


## 6) In-process privilege bracketing (plugins/helpers) (D-BRACKET)

Even with good component boundaries, ecosystems drift into **in-process deputies**: shared helpers, plugins, and compatibility code that can accidentally use the host’s internal authority.

Recommended pattern (optional):
- Mark some held capabilities as **privileged** (e.g., export-any, net-admin, open-outside-view).
- When servicing inbound requests, run in **borrowed mode**: privileged capabilities are *inaccessible by default*.
- Allow privileged effects only inside an explicit, exception-safe `with_privileged { ... }` block.

This is inspired by the *engineering* lesson of Java stack inspection + `doPrivileged` (explicit, scoped privilege boundaries), but we keep it **veto-only** and entirely in user space (no kernel stack inspection, no permission domains).

Tight guardrail: treat any “shortcut” path that bypasses the bracketing check as a bug class—historical experience shows access-control shortcuts are where the model collapses.

Pointer: RFC-0118 (D-BRACKET + CH-CALLCHAIN + CH-REQCTX v1).

## Pointers
- RFC-0016 (D-SEAL, CH-PLEDGE): `rfcs/0016-voluntary-sandboxing-promises-and-unveil.md`
- CH-PLEDGE schema: `docs/30-architecture/pledge-contract-schema-v0.md`
- Token mapping table: `docs/30-architecture/pledge-token-mapping.md`

- RFC-0118 (D-BRACKET): `rfcs/0118-privilege-bracketing-and-call-chain-contexts.md`
- CH-CALLCHAIN schema: `docs/30-architecture/call-chain-schema-v0.md`

