# Inspirations mapped to ViewFS

## Lessons we must learn from the past

### L1. Ambient namespaces always try to come back
- REF-CAPSICUM-SEC10, REF-FUCHSIA-NAMESPACE, and REF-WASMTIME-PREOPEN all show that bounded access works best when roots are explicit.
- Therefore: do not let “temporary” host-path fallback become a permanent escape hatch.

### L2. Capability persistence is harder than blob persistence
- REF-EROS and REF-KEYKOS both warn that durable authority edges create difficult stabilization and recovery semantics.
- Therefore: store immutable data first; postpone rich persistent capability graphs.

### L3. Private namespaces are a feature, not a hack
- REF-PLAN9 and REF-FUCHSIA-NAMESPACE show private, assembled views can be the primary user model.
- Therefore: make per-process `/` normal.

### L4. Rights attenuation should be visible and cheap
- REF-FUCHSIA-RIGHTS and REF-FUCHSIA-DIR-CAPS show attenuation as normal practice.
- Therefore: rights-reduced duplicates should be common, not exotic.

### L5. Mediated imports beat broad static permissions
- REF-FLATPAK-BASICS, REF-XDG-FILECHOOSER, REF-XDG-DOCUMENTS show the practical value of portals.
- Therefore: prioritize portal/open/save flows early.

### L6. Immutable object stores are powerful, but they are not the whole filesystem story
- REF-VENTI, REF-GIT-OBJECTS, REF-NIX-CA are excellent for storage and closure identity.
- Therefore: use them for the backing store, but do not pretend content addressing alone defines mutable namespace truth.

## Nifty ideas worth stealing
- **Preopens / synthetic mounts for compat** from REF-WASMTIME-PREOPEN.
- **Per-component composite namespaces** from REF-FUCHSIA-NAMESPACE.
- **Routed directory capabilities** from REF-FUCHSIA-DIR-CAPS.
- **Write-once archival backing** from REF-VENTI.
- **Tiny core object vocabulary** from REF-GIT-OBJECTS.
- **Immutable application/runtime closures** from REF-NIX-CA.
- **Structured pipelines** from REF-NUSHELL.
- **Great interactive ergonomics** from REF-FISH.
- **Terminal blocks** from REF-WARP-BLOCKS.
- **Semantic hyperlinks and visible domains** from REF-WEZTERM-HYPERLINKS and REF-WEZTERM-DOMAINS.

## Ideas to reject or treat carefully
- making host-global paths foundational again
- turning every service into a path string just because Plan 9 could
- overcommitting to persistence or revocation before the minimal object/view core is proven
- assuming portal persistence, revocation, or UX semantics are “obvious” without receipts and inspection tools
