# Annotated bibliography (REF index)

Rule: each REF entry is <=3 bullets: **key idea** / **why it matters** / **implication for us**.
No pasted papers; just pointers.

## Capability systems / namespace control
- **REF-CAPSICUM-SEC10** — Watson et al., *Capsicum: practical capabilities for UNIX* — https://www.usenix.org/event/sec10/tech/full_papers/Watson.pdf
  - key: capability mode removes access to global namespaces while preserving a migration path from UNIX APIs
  - why: strongest precedent for “compatibility membrane, not ambient authority”
  - us: keep path shims subordinate to handles and explicit entry into bounded execution
- **REF-EROS** — Shapiro et al., *EROS: a fast capability system* — https://flint.cs.yale.edu/cs428/doc/eros.pdf
  - key: persistent capabilities create hard ordering/cycle problems between data and authority
  - why: warns against casual mutable capability persistence
  - us: prefer immutable objects + snapshot roots before richer mutable transactions
- **REF-KEYKOS** — Bomberger et al., *The KeyKOS Nanokernel Architecture* — https://css.csail.mit.edu/6.566/2018/readings/keykos.pdf
  - key: small capability kernels benefited from tuned primitives, checkpoints, and compatibility layers
  - why: demonstrates that capability systems can host legacy interfaces without making them foundational
  - us: keep compat as a layer and make checkpoint/snapshot strategy explicit
- **REF-SEL4-CSPACE** — seL4 capability tutorial / manual — https://docs.sel4.systems/Tutorials/capabilities.html
  - key: capabilities live in explicit slots and spaces, not in a hidden ambient namespace
  - why: good language for handle tables and view bindings
  - us: consider stable slot semantics for ViewFS handle inventories

## Namespaces / routing
- **REF-FUCHSIA-NAMESPACE** — Fuchsia namespaces — https://fuchsia.dev/fuchsia-src/concepts/process/namespaces
  - key: no global root; each component receives its own composite namespace
  - why: directly matches ViewFS per-process root ambitions
  - us: make `/` synthetic and local to a view
- **REF-FUCHSIA-DIR-CAPS** — Fuchsia directory capabilities — https://fuchsia.dev/fuchsia-src/concepts/components/v2/capabilities/directory
  - key: directories are capabilities routed with explicit rights
  - why: useful precedent for view slot bindings and rights attenuation
  - us: bind directories as capabilities, not as discovered paths
- **REF-FUCHSIA-RIGHTS** — Fuchsia handle rights — https://fuchsia.dev/fuchsia-src/concepts/kernel/rights
  - key: rights are attached to handles and can be reduced
  - why: capability attenuation should be first-class in ViewFS
  - us: design handle duplication / attenuation before fancy search features
- **REF-WASI-CAPS** — WASI capabilities note — https://github.com/WebAssembly/WASI/blob/main/docs/Capabilities.md
  - key: use runtime handles when multiple distinct live resources must coexist
  - why: exactly the ViewFS file/object handle case
  - us: prefer runtime handles over string re-resolution
- **REF-WASMTIME-PREOPEN** — Wasmtime WASI tutorial — https://github.com/bytecodealliance/wasmtime/blob/main/docs/WASI-tutorial.md
  - key: preopened directories let libc translate legacy path calls into bounded capability access
  - why: strongest compat pattern for ViewFS Phase 1
  - us: emulate preopens for legacy path APIs instead of making paths authoritative
- **REF-OPENAT2** — Linux `openat2(2)` manual — https://man7.org/linux/man-pages/man2/openat2.2.html
  - key: `RESOLVE_BENEATH` / `RESOLVE_IN_ROOT` exist because naive path rooting escapes easily
  - why: path compatibility is security-sensitive, even when “just starting from cwd”
  - us: no best-effort path membrane; fail closed on escape ambiguity

## Portals / mediated authority
- **REF-FLATPAK-BASICS** — Flatpak basic concepts — https://docs.flatpak.org/en/latest/basic-concepts.html
  - key: sandboxes default-deny and use portals for host interaction
  - why: clean desktop precedent for mediated file access
  - us: treat chooser/import/save as first-class authority events
- **REF-XDG-FILECHOOSER** — XDG FileChooser portal — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.FileChooser.html
  - key: chooser grants can make selected files accessible to sandboxed apps
  - why: matches ViewFS import flow expectations
  - us: portal-open must yield explicit handles and durable receipts
- **REF-XDG-DOCUMENTS** — XDG Documents portal — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Documents.html
  - key: exported files become visible through a restricted filesystem view
  - why: useful precedent for “synthetic tree backed by explicit grants”
  - us: import/export should be visible as a restricted view, not a host path leak

## Object stores / archival storage
- **REF-VENTI** — Quinlan and Dorward, *Venti* — https://9p.io/sys/doc/venti/venti.pdf
  - key: content hashes naturally enable write-once archival storage and deduplication
  - why: excellent model for immutable blob storage and snapshots
  - us: keep the backing store simple and immutable-first
- **REF-GIT-OBJECTS** — Git internals: objects — https://git-scm.com/book/en/v2/Git-Internals-Git-Objects
  - key: a simple content-addressed key-value store scales far with minimal object kinds
  - why: suggests a small core object vocabulary
  - us: start with blob/tree-ish/manifest primitives before adding richer object types
- **REF-NIX-CA** — Nix content-addressed store objects — https://nix.dev/manual/nix/2.26/store/store-object/content-address
  - key: content-addressed objects and closures can be separated from mutable working state
  - why: strong precedent for immutable application closures and reproducible roots
  - us: `/app` or equivalent closures should be immutable and content-addressed
- **REF-PLAN9** — Pike et al., *Plan 9 from Bell Labs* — https://www.usenix.org/publications/compsystems/1995/sum_pike.pdf
  - key: private namespaces and uniform naming are powerful composition tools
  - why: ViewFS can learn from private namespaces without inheriting every “everything is a path” decision
  - us: steal personal namespace assembly, not ambient string centrality

## Shell / terminal inspiration
- **REF-NUSHELL** — Nushell pipelines — https://www.nushell.sh/book/pipelines.html
  - key: pipelines can carry structured data rather than only bytes
  - why: a capability-native shell should traffic in typed objects and receipts
  - us: let shell commands emit structured handle metadata by default
- **REF-FISH** — fish tutorial — https://fishshell.com/docs/current/tutorial.html
  - key: syntax highlighting, autosuggestions, and completion ergonomics matter a lot
  - why: safer authority UX needs excellent interaction design
  - us: capability-aware completions and preview panes should feel effortless
- **REF-WARP-BLOCKS** — Warp terminal blocks — https://docs.warp.dev/terminal/blocks
  - key: command + output as an atomic block is a better unit than a raw scroll stream
  - why: ViewFS shell receipts and grants should be grouped and shareable
  - us: represent imports/exports/transfers as blocks with attached metadata
- **REF-WEZTERM-HYPERLINKS** — WezTerm hyperlinks — https://wezterm.org/hyperlinks.html
  - key: terminals can expose clickable semantic links without cluttering output
  - why: good fit for handle IDs, receipts, manifests, and docs
  - us: make ViewFS object receipts clickable from terminal output
- **REF-WEZTERM-DOMAINS** — WezTerm multiplexing domains — https://wezterm.org/multiplexing.html
  - key: distinct UI domains can remain user-comprehensible
  - why: ViewFS views may benefit from similarly visible domains
  - us: terminal tabs should expose active view identity clearly
