# External source review queue

Purpose: keep mutable docs re-review visible.

## Snapshot
- moving-head refs tracked: **14**
- exact byte locks: **0**
- earliest review date: **2026-04-15**

| review_by | ref_id | area | note |
|---|---|---|---|
| `2026-04-15` | `REF-FLATPAK-BASICS` | portal posture | re-check portal narrative before making UX guarantees |
| `2026-04-15` | `REF-XDG-FILECHOOSER` | chooser/import | re-check persistence / access wording before protocol pinning |
| `2026-04-15` | `REF-XDG-DOCUMENTS` | document export/import | re-check restricted-view behavior before stronger analogy |
| `2026-04-15` | `REF-WARP-BLOCKS` | terminal UX | re-check block model before UI-specific commitments |
| `2026-04-20` | `REF-WASI-CAPS` | capability model | re-check runtime-handle guidance |
| `2026-04-20` | `REF-WASMTIME-PREOPEN` | compat membrane | re-check libc preopen discussion |
| `2026-05-01` | `REF-FUCHSIA-NAMESPACE` | per-view root | re-check namespace wording and non-global root claims |
| `2026-05-01` | `REF-FUCHSIA-DIR-CAPS` | routed directories | re-check rights and route wording |
| `2026-05-01` | `REF-FUCHSIA-RIGHTS` | handle attenuation | re-check rights reduction semantics |
| `2026-05-15` | `REF-NIX-CA` | object addressing | re-check manual section |
| `2026-05-15` | `REF-NUSHELL` | shell UX | re-check structured pipeline docs |
| `2026-05-15` | `REF-FISH` | shell UX | re-check interaction claims |
| `2026-05-15` | `REF-WEZTERM-HYPERLINKS` | terminal UX | re-check hyperlink support language |
| `2026-05-15` | `REF-WEZTERM-DOMAINS` | terminal UX | re-check domain terminology |
