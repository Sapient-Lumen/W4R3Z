# Evidence index

| EVID-ID | Class | Summary | Artifact | Notes |
|---|---|---|---|---|
| EVID-2026-001 | E0 | First ViewFS datacube archive revision with foundation docs, architecture postures, inspiration map, and RFC seed. | `ViewFS-rev0001-2026.03.21.18.23-foundation-hygiene-openquestions-seedling.zip` | Archive seed |
| EVID-2026-002 | E0 | Generated context pack for Revision 001. | `out/context_pack.md` | Regenerate with `make context-pack` |
