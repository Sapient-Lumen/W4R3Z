# Trajectory map

## North-star sentence
ViewFS is a **capability-native namespace and object layer** for SlopOS, not a traditional host-global filesystem.

## What should be stable early
- immutable-first backing store
- explicit handles with attenuable rights
- per-process synthetic root views
- portal-mediated import/export
- compatibility as a membrane

## What should stay open longer
- exact on-disk pack format
- hash algorithm choice
- mutable transaction model
- live revocation mechanics
- distributed sync / replication
- query engine and indexing strategy
- shell language syntax
