# Roadmap

## Phase A0 — archive seed
- repo hygiene
- charter / claims / non-claims
- bibliography and research map
- first RFC

## Phase A1 — minimal substrate design
- immutable blob + manifest object model
- directory/object handle vocabulary
- per-process view root posture
- portal import/export posture

## Phase A2 — bounded compatibility
- synthetic path membrane
- cwd / root semantics
- failure-on-escape rules
- transcript-visible import/export receipts

## Phase A3 — shell and terminal differentiation
- structured pipelines over handles/receipts
- clickable blocks and receipts
- capability-aware completion and previews
- explicit view/domain switching UX

## Phase A4 — deferred hard decisions
- revocation semantics
- mutable directory transactions
- query/index model
- replication / sync model
- symlink/hardlink policy
