# External source head register

Purpose: keep moving-head or presentation-layer external sources visible so we do not accidentally treat a mutable docs page as frozen law.

Status for Revision 001: **reviewed, not byte-locked**. We used current primary sources, but this repo has not yet downloaded and hashed exact artifacts for lock rows. That work should happen when a source becomes load-bearing enough to support a hard decision.

| ref_id | source type | volatility | retrieved_on | next_review_by | note |
|---|---|---|---|---|---|
| `REF-FUCHSIA-NAMESPACE` | web docs | moving-head | `2026-03-21` | `2026-05-01` | design inspiration only; do not overfit exact current routing syntax |
| `REF-FUCHSIA-DIR-CAPS` | web docs | moving-head | `2026-03-21` | `2026-05-01` | rights-routing semantics are relevant; exact schema syntax is not load-bearing yet |
| `REF-FUCHSIA-RIGHTS` | web docs | moving-head | `2026-03-21` | `2026-05-01` | good for handle-rights vocabulary |
| `REF-FLATPAK-BASICS` | web docs | moving-head | `2026-03-21` | `2026-04-15` | portal posture reference |
| `REF-XDG-FILECHOOSER` | web docs | moving-head | `2026-03-21` | `2026-04-15` | chooser semantics may evolve; re-check before binding protocol details |
| `REF-XDG-DOCUMENTS` | web docs | moving-head | `2026-03-21` | `2026-04-15` | document portal behavior is inspirational, not directly adopted |
| `REF-WASI-CAPS` | GitHub markdown | moving-head | `2026-03-21` | `2026-04-20` | capability taxonomy is useful; exact text may drift |
| `REF-WASMTIME-PREOPEN` | GitHub markdown | moving-head | `2026-03-21` | `2026-04-20` | compat-preopen pattern is highly relevant |
| `REF-NIX-CA` | web manual | moving-head | `2026-03-21` | `2026-05-15` | object-addressing precedent |
| `REF-NUSHELL` | web docs | moving-head | `2026-03-21` | `2026-05-15` | shell UX inspiration only |
| `REF-FISH` | web docs | moving-head | `2026-03-21` | `2026-05-15` | shell UX inspiration only |
| `REF-WARP-BLOCKS` | web docs | moving-head | `2026-03-21` | `2026-04-15` | terminal-block UX inspiration only |
| `REF-WEZTERM-HYPERLINKS` | web docs | moving-head | `2026-03-21` | `2026-05-15` | terminal hyperlink inspiration |
| `REF-WEZTERM-DOMAINS` | web docs | moving-head | `2026-03-21` | `2026-05-15` | terminal domain UI inspiration |
