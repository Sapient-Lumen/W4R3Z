# Shell and terminal ideas for ViewFS

This file captures ideas worth stealing without prematurely freezing shell syntax.

## Big opportunities

### 1. Structured pipelines by default
Steal from REF-NUSHELL:
- commands can emit typed records, tables, handles, receipts, and manifests
- text remains available, but not mandatory as the lingua franca
- inspection commands should show both friendly and exact forms

### 2. Capability-aware completion and previews
Steal from REF-FISH:
- completions should understand the active view
- previews should say *what authority this object implies*, not just its name
- dangerous expansions should be visually marked before execution

### 3. Command/output blocks as first-class transcript units
Steal from REF-WARP-BLOCKS:
- every command and its result should form a block
- imports, exports, grant receipts, and errors should attach metadata to the block
- blocks should be bookmarkable and shareable inside the archive

### 4. Clickable semantic receipts in terminal output
Steal from REF-WEZTERM-HYPERLINKS:
- handle IDs, manifest IDs, docs, and receipts should be clickable
- terminal output can link to a local inspector instead of dumping raw identifiers only

### 5. Explicit view domains in tabs/panes
Steal from REF-WEZTERM-DOMAINS:
- every tab/pane should visibly show which view/domain it belongs to
- switching views should feel like changing domains, not like mutating a hidden cwd

## ViewFS-native shell moves
- `grant open` -> chooser flow returning handles + receipt
- `grant save` -> export flow returning receipt + destination binding
- `view ls` -> list explicit roots and bindings
- `obj inspect` -> metadata / rights / provenance for a handle
- `manifest show` -> exact immutable closure view
- `path explain` -> explain how a compat path maps onto explicit roots

## Anti-goals
- no fake “normal Unix” prompt if the system is using a synthetic view root
- no silent coercion from handles back to ambient host paths
- no AI-generated shell magic without a visible explanation of resulting authority
