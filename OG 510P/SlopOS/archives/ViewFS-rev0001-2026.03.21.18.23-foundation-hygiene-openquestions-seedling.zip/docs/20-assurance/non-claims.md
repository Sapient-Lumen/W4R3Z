# Non-claims

Revision 001 deliberately does **not** claim:
- full POSIX fidelity,
- global path stability across views,
- general live revocation,
- distributed transparency,
- a final on-disk format,
- a final hash algorithm,
- that content addressing alone solves mutable namespace integrity,
- that all shell pipelines should become typed by force,
- that portal persistence semantics are already final.
