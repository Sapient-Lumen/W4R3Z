# Invariant registry

| ID | Invariant |
|---|---|
| I-VIEWFS-1 | A process view root is explicit; it is never silently replaced by ambient host `/`. |
| I-VIEWFS-2 | Handle rights can only stay the same or attenuate across duplication/binding unless a separate reviewed grant path exists. |
| I-VIEWFS-3 | Path-compat resolution cannot escape the bound view root; ambiguous implementations fail closed. |
| I-VIEWFS-4 | Portal imports/exports produce receipts or logs sufficient to reconstruct the authority step. |
| I-VIEWFS-5 | Immutable object IDs name content, not mutable current state. |
