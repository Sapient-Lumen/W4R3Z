# Claim registry

| ID | Claim |
|---|---|
| C-VIEWFS-1 | ViewFS core semantics do not require an ambient machine-global filesystem namespace. |
| C-VIEWFS-2 | Path compatibility can be constrained to authority already present in explicit handles/views. |
| C-VIEWFS-3 | Portal-mediated imports/exports can provide explicit, inspectable authority transitions. |
| C-VIEWFS-4 | A simple immutable-first object store is sufficient for the first useful ViewFS slice. |
