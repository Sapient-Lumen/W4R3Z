# Assumption registry

| ID | Assumption | Why it exists |
|---|---|---|
| A-VIEWFS-1 | Phase 1 can require explicit launch-time view construction rather than ambient host namespace inheritance. | Core authority model depends on it. |
| A-VIEWFS-2 | Early ViewFS may rely on immutable objects and snapshot roots before it has a fully general mutable transaction system. | Reduces consistency complexity. |
| A-VIEWFS-3 | Legacy software support can be layered through a killable compatibility membrane. | Prevents compatibility from becoming the truth model. |
| A-VIEWFS-4 | Portal-mediated imports/exports can be made transcript-visible and user-comprehensible. | Necessary for explicit authority UX. |
| A-VIEWFS-5 | The first shell/terminal can exploit structured data and metadata, not only raw byte streams. | Needed to differentiate the user experience. |
