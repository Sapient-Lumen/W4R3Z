# Object-store posture v0 (immutable first, boring on purpose)

Purpose: keep the backing store small, comprehensible, and decoupled from premature namespace cleverness.

## Posture
1. Phase 1 should prefer **immutable blobs and manifests** over a fully general mutable inode model.
2. Object IDs should name **content** or stable manifest structure, not mutable current state.
3. The store should begin with a **small object vocabulary** and a simple pack/index story.
4. Snapshot roots are welcome; a grand mutable transaction model is not required for Phase 1.
5. Capability persistence should be treated as a higher-risk topic than blob persistence.

## Why this cut is worth making
- REF-VENTI and REF-GIT-OBJECTS show how far a small immutable object core can go.
- REF-NIX-CA suggests immutable closures are especially valuable for application/runtime roots.
- REF-EROS and REF-KEYKOS warn that persistent authority edges complicate stabilization quickly.

## Open questions
- hash algorithm choice
- pack/index layout
- metadata normalization format
- garbage collection / retention policy
- manifest granularity
