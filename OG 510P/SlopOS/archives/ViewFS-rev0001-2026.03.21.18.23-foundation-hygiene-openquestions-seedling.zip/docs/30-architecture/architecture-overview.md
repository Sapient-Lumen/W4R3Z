# Architecture overview

## Core split
ViewFS should be decomposed into four layers:
1. **Object store** — immutable blobs, manifests, and compact metadata.
2. **Handle layer** — object references plus rights and attenuation rules.
3. **View layer** — explicit per-process synthetic roots assembled from bindings.
4. **Portal / compat layer** — user-mediated imports/exports and optional path shims.

## Design pressure
The danger zone is letting layer 4 quietly redefine layers 1–3. History suggests that once ambient paths or hidden inheritance sneak back in, capability systems lose their main benefit.

## Working build order
1. immutable blob + manifest storage
2. directory/object handle API
3. per-process view root construction
4. portal import/export receipt flow
5. path compatibility membrane
6. shell/terminal ergonomics

## Early object vocabulary (tentative)
- `Blob`
- `Directory`
- `Manifest`
- `View`
- `GrantReceipt`

Everything richer should justify itself.
