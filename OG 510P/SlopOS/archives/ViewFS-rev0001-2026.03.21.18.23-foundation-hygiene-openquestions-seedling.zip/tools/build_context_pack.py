from pathlib import Path

root = Path(__file__).resolve().parents[1]
out = root / "out" / "context_pack.md"
parts = [
    "# ViewFS context pack",
    "",
    "## Must-read",
]
for rel in [
    "README.md",
    "docs/00-meta/charter.md",
    "docs/00-meta/trajectory-map.md",
    "docs/20-assurance/non-claims.md",
    "docs/30-architecture/architecture-overview.md",
    "rfcs/0001-viewfs-foundation-rfc.md",
]:
    text = (root / rel).read_text()
    parts.append(f"### {rel}")
    parts.append("")
    parts.append(text.strip())
    parts.append("")
out.write_text("\n".join(parts) + "\n")
print(f"wrote {out}")
