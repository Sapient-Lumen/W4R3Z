from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
required = [
    'README.md',
    'CHANGELOG.md',
    'docs/00-meta/charter.md',
    'docs/00-meta/bibliography.md',
    'docs/10-threat-model/assumption-registry.md',
    'docs/20-assurance/claim-registry.md',
    'docs/20-assurance/invariant-registry.md',
    'docs/30-architecture/architecture-overview.md',
    'rfcs/0001-viewfs-foundation-rfc.md',
]
missing = [p for p in required if not (root / p).exists()]
if missing:
    print('Missing required files:')
    for p in missing:
        print(' -', p)
    sys.exit(1)
print('lint: ok')
