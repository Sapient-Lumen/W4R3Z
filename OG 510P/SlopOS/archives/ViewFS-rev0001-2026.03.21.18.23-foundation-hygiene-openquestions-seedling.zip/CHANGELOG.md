# Changelog

## Revised001 (2026-03-21)
- Seeded the first ViewFS datacube archive with repo hygiene, charter, trajectory map, claim/invariant skeletons, and a first RFC.
- Added architecture notes for:
  - immutable-first object store posture,
  - explicit per-process namespace posture,
  - portal-mediated import posture,
  - path compatibility membrane posture.
- Added a curated inspiration map covering capability systems, namespaces, portals, content-addressed stores, and terminal UX patterns.
- Added a shell/terminal idea file focused on structured pipelines, capability-aware completions, block transcripts, clickable receipts, and multiplexed view domains.
- Added external-source head tracking surfaces for moving-head docs used during design review.
