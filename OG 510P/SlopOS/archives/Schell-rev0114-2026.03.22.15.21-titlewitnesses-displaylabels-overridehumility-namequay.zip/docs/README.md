# Docs map

- `00-meta/` — charter, trajectory, policy, move registry, question machine, hygiene, and research synthesis
- `10-command-model/` — the command envelope and execution journey
- `20-language/` — syntax, quoting, expansion, and word formation
- `30-runtime/` — pipelines, processes, effects, and control surfaces
- `40-assurance/` — claims, invariants, and failure classes
- `50-session/` — command lineage, receipts, replay, and postmortems
- `60-platform/` — portability profile, compatibility stance, and Rust implementation posture
- `70-automation/` — agent boundary, consent, and automation posture
- `80-terminal/` — semantic terminal moves, transcript truth, trusted chrome/review-lane separation, review blocks, trusted command-block action gates, authorship/basis surfaces, denial teaching, background shelves, attention/finish-notice posture, ingress/clipboard honesty, operator affordances, and no-regret shell+terminal moves
- `90-quarantine/` — attractive but unearned ideas

- `80-terminal/reentry-cues-session-restoration-and-historical-honesty.md` — reentry cues, restored-state badges, hold cards, and history/live honesty.
- `80-terminal/attention-hints-finish-notices-and-interruption-budgets.md` — exact attention events, bounded finish notices, interruption budgets, and residue honesty.

- `80-terminal/ingress-packets-paste-drop-and-clipboard-honesty.md` — ingress packets, bracketed-paste-aware insert paths, dropped-file import cards, and transcript-visible clipboard/drop handling.

- `80-terminal/output-capsules-stream-braid-witnesses-and-ordering-humility.md` — shell-owned output capsules, braid witnesses, channel/provenance truth, and ordering humility.

- `80-terminal/trusted-chrome-secure-review-lanes-and-anti-spoof-separation.md` — trusted local chrome, secure review lanes, trust grades, and host-effect witnesses that keep approval UI distinct from PTY flow.

- `80-terminal/command-chapters-journal-truth-and-source-labeled-recall.md` — shell-owned command chapters, exact journals, source-labeled recall, and history-pollution guards.

- `80-terminal/launch-kits-quick-summon-and-cockpit-honesty.md` — explicit project launch kits, runtime-fast quick summon, cockpit discovery surfaces, and attach-vs-relaunch honesty.

- `80-terminal/object-cards-exact-reveal-and-safe-open-honesty.md` — typed object cards, exact reveal, ordinary open vs safe-open, and metadata-safe object inspection.

- `80-terminal/slot-linked-edits-synced-cursors-and-parameter-fill-humility.md` — field-local parameter slots, repeated-slot synced edits, provenance badges, and the rule that fill stays weaker than run.

- `80-terminal/argv-witnesses-exact-reveal-and-escape-humility.md` — pretty active-input views, exact argv/text reveal, quote-and-escape witnesses, and the rule that display stays weaker than launch truth.

- `80-terminal/transcript-cards-replay-bundles-and-redaction-honesty.md` — transcript cards, replay bundles, timing witnesses, selective export sheets, and redaction-visible transcript handling.
- `80-terminal/enrichment-packets-freshness-budgets-and-speculation-refusal.md` — smart-terminal enrichment packets, source/freshness/cost badges, explicit refresh/materialize steps, and speculation refusal.

- `80-terminal/chrome-witnesses-status-egress-and-ambient-badge-humility.md` — ambient chrome/status projections, title and badge humility, taskbar/dock progress egress, and the rule that surrounding chrome stays weaker than durable truth.
- `80-terminal/secret-witnesses-reveal-ladders-and-masking-humility.md` — secret-bearing refs, proxy use, reveal ladders, sink badges, and the rule that masking stays weaker than sink avoidance.
- `80-terminal/tty-witnesses-process-group-lanes-and-promotion-humility.md` — foreground tty claims, stopped/background/disowned lanes, promotion rails, and the rule that prompt return stays weaker than durable continuation truth.


- `80-terminal/shell-integration-marks-startup-humility-and-command-block-honesty.md` — shell-owned semantic marks, startup-footing witnesses, trust-graded command chapters, and the rule that command-aware luxury stays weaker than durable shell truth.
