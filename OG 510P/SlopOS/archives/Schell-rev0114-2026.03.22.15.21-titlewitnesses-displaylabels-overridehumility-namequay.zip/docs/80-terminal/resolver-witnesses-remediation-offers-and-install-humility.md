# Resolver witnesses, remediation offers, and install humility

This surface names a shell+terminal seam that gets more important as the product grows friendlier:
**Schell should become dramatically better than classic shells at helping after a failed command, but it should do that by separating exact failure truth from adjacent remediation workflows, because typo correction, similar-subcommand help, package-install advice, PATH/profile repair, doc lookup, and rerun are different actions and should stop borrowing one magical recovery badge.**

SlopOS already teaches the key discipline.
Exact exec selection stays stronger than late reopen-by-name.
Learn mode stays observational only.
Adjacent workflows keep their own seam names.
That is exactly the right import pressure for Schell while both datacubes are still design-phase.

## 1) Failed-command recovery deserves first-class shell truth

Classic shell UX usually gives a blur of folklore:
- maybe `command not found`,
- maybe a package-install hint,
- maybe typo correction,
- maybe a profile/PATH problem disguised as absence,
- maybe a non-executable file in `PATH`,
- maybe a missing interpreter,
- maybe a wrong subcommand,
- maybe a wrapper that rewrites what runs,
- and maybe a terminal/editor quick fix that proposes a next step.

Those are not the same state.
A custom shell+terminal can do much better by naming exact failure kind before it offers any adjacent repair luxuries.

## 2) Preserve resolver truth before rendering repair ideas

A Schell resolver witness should probably record the strongest facts first.
For example:
- `resolver_kind` — `not_found` / `found_not_invokable` / `missing_interpreter` / `subcommand_unknown` / `startup_bind_failed` / `provider_stale` / `weak_signature_only`
- `token_subject` — which token or subcommand failed
- `lookup_basis` — exact shell lookup / project accelerator / package index / external provider / stderr signature
- `platform_scope` — host / distro / package-manager / project-local / remote peer
- `freshness_posture` — exact-now / exact-local-but-staleable / heuristic / imported-historical
- `next_safe_actions` — explain / reveal / copy / insert / stage / review-run / open-docs / install-offer

That is enough to make a repair surface much more honest without freezing one resolver stack.

## 3) One compact remediation ladder would already feel luxurious

Schell does not need auto-repair magic first.
A simple ladder would already beat the old world:

1. **Explain** what kind of failure this was.
2. **Reveal** the resolution basis (PATH, alias/function shadowing, provider source, stale package DB, missing interpreter, wrong subcommand, etc.).
3. **Offer** nearby candidates with visible source labels.
4. **Insert** the best candidate into active input without running it.
5. **Stage** stronger actions like install/enable/profile-edit behind a separate review card.
6. **Review-run** any new command as a fresh action with new authorship and basis badges.

That is the key “super awesome” move here.
The shell can feel brilliant without becoming magical in the bad way.

## 4) Correction, install, and docs should stay separately named

A particularly dangerous old habit is flattening all recovery into one glowing suggestion.
Schell should resist that.

At minimum, different offer families should stay separate:
- **correction offer** — “did you mean `git switch`?”
- **subcommand offer** — “closest known subcommands are …”
- **path/profile offer** — “binary exists outside current PATH / profile not loaded / shell hook missing”
- **package offer** — “local package provider thinks package X contains executable Y”
- **doc offer** — “open help / manual / recipe”
- **project offer** — “repo accelerator suggests `cargo xtask foo`”
- **install offer** — “insert or stage install command”

Those may all appear together, but the user should never have to guess which kind of move they are approving.

## 5) Install advice needs visible humility

Package/install advice is useful precisely because it is often wrong in subtle ways.
The package may be stale.
The package may be available only on one distro.
The user may not want a global install.
The command may really be a profile issue or a missing module rather than a missing package.
The best fix may be to use an existing project tool, dev shell, or scoped environment rather than install anything.

So install offers should carry visible posture such as:
- provider source,
- platform scope,
- freshness age or “index freshness unknown”,
- install scope guess (`global`, `user`, `project`, `ephemeral env`, `package alias only`),
- and whether the offer is exact, heuristic, or imported from a repo accelerator.

## 6) Review-first is the no-regret power move

The nicest version of this surface is not “auto-run the fix.”
It is review-first ergonomics.

Schell should prefer moves like:
- `Alt-accept` to insert a repaired command without running it,
- side-by-side diff cards between original and suggested command,
- explicit offer chips for “docs”, “install”, “path fix”, or “use project tool”,
- and new authorship/basis badges whenever a different command becomes the reviewed action.

That gives us a custom shell+terminal that feels unusually capable exactly where classic shells are clumsy, while still refusing one of the oldest mistakes in the category:
**a failed command does not authorize the shell to silently choose a new command.**

## 7) A narrow v0 is enough

Schell can start very small here:
- one resolver-witness family,
- one remediation card shape,
- one insert-vs-review-run split,
- one install-offer humility badge set,
- and one explicit rule that no provider may auto-rerun, auto-install, or auto-edit profile state as if it were merely finishing the original command.

That is already enough to make the shell+terminal meaningfully more humane than the past without forcing a final package-manager integration, doc-search backend, or remediation plugin model.
