# Shell-terminal co-design for SlopOS

Schell is now explicitly designing the **shell and terminal together** for SlopOS.
That does **not** mean blurring every layer.
It means designing one coherent operator system with named boundaries.

## Why this co-design is necessary

A strict shell without terminal help becomes annoying.
A rich terminal without shell truth becomes a confidence trick.
SlopOS pressure says both failures matter:

- exact approval basis matters,
- exact subject selection matters,
- durable receipts and denials matter,
- request state and live state differ,
- and generic launch semantics should not secretly widen into policy state.

So Schell should treat shell and terminal as one project with three explicit layers.

## Layer 1 — shell truth

The shell owns the durable meaning.
At minimum that includes:

- exact reviewed action identity,
- exact subject identity,
- exact mutable approval basis when relevant,
- effect summary,
- approval / denial decision,
- receipt / denial lineage,
- request state versus live background state,
- and the references needed for replay, diff, or reopen.

The terminal must not invent or guess these semantics into existence.

## Layer 2 — semantic transport

This layer should stay as small as possible while still making the terminal and transcript honest.
Candidate truths to carry:

- prompt start / end,
- active editable input start / end,
- reviewed action block start / end,
- command output block start / end,
- receipt block start / end,
- denial block start / end,
- background-state-change block start / end,
- current working context,
- command-block trust grade,
- and stable references / ids when available.

This is where Schell should carry trust markers like:

- `guessed`,
- `marked`,
- `shell-authenticated`.

That one move unlocks a lot of safe terminal behavior.

## Layer 3 — local terminal UX

This is where the terminal gets super awesome.
Examples:

- review cards,
- receipt shelf,
- denial shelf,
- background shelf,
- prompt-safe click-to-cursor,
- exact artifact preview,
- jump to previous/next reviewed action,
- jump to previous/next receipt or denial,
- command-finish notifications,
- readonly replay mode,
- and explicit key-table modes for review, navigation, or debug work.

These are great.
They still should not be the only place where the truth exists.

## Design laws for the integrated system

### 1) Exact subject over approximate convenience

If the action is about one artifact, one receipt, or one reviewed request, the terminal should preserve exact identity.
No silent fallback to “something nearby” just because it feels convenient.

### 2) One approval, one exact mutable basis

If an approval depended on a digest, revision, selection, or route, that exact basis should be visible on the review card and carried into the receipt.
No sticky head-following approvals by default.

### 3) Terminal actions must respect trust grade

Not every command block deserves the same powers.
A useful early law is:

- guessed blocks may be copied,
- marked blocks may be navigated and summarized,
- shell-authenticated blocks may unlock safer rerun / attach / replay affordances.

The exact permissions are still open.
The need for trust grades is not.

### 4) Denials should narrow, not merely reject

A denial should say what was attempted, what exact prerequisite was missing, whether retry is safe, and what narrower next move is likely to succeed.
It must not secretly widen authority while trying to be helpful.

### 5) Background presence is request/live-state UX, not old job control

The background shelf should preserve:

- original request,
- current live state,
- expiry / renewal posture,
- autostart posture if any,
- and the last state-changing receipt or denial.

### 6) Transcript truth is part of correctness

Every review card, receipt, denial, and background-state change should still tell the truth in a plain transcript.
Rich local rendering is acceleration, not the only source of meaning.

### 7) Admission, completion, and live state should not collapse

A review receipt, a command exit, and a still-live grant are different truths.
The terminal should help the operator see those differences, not hide them.

## Decision throttle

The right way to be ambitious here is not to decide everything up front.
It is to separate:

- **truth surfaces we can justify now,**
- **humane local UX we can prototype reversibly,**
- and **architecture-binding choices we should still defer.**

That is the role of `no-regret-shell-terminal-moves.md`.
Schell should aggressively pursue the no-regret moves and stay stubbornly noncommittal about final transport, renderer, pipeline ontology, and product shape until those choices are actually earned.

## First proving slice

The right first integrated proof still looks like:

- select one exact artifact,
- request one exact action,
- show one review card with exact mutable basis,
- approve or deny,
- emit one durable receipt or denial block,
- and preserve the same truth in a plain transcript.

If Schell nails that, the richer terminal can grow around something real.
If it cannot, more terminal cleverness will only hide the weakness.

## Super awesome moves that still look safe

- trusted command blocks with confidence grades,
- prompt-safe click editing only inside marked active input,
- command-finish notifications with threshold + focus rules,
- readonly receipt/replay mode,
- exact artifact preview that never implies hidden reopen authority,
- mode tables for review / shelf / debug work,
- a session atlas that jumps by artifact, receipt, denial, or background change,
- and a narrower sandboxed lane for agent-proposed execution.

## What to keep open

- final protocol encoding,
- exact escape-sequence vs side-channel transport,
- final line editor or renderer stack,
- full PTY compatibility story,
- whether structured data becomes foundational for pipelines,
- and whether the terminal ships embedded, standalone, or both.
