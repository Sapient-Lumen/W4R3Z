# TTY witnesses, process-group lanes, and promotion humility

This surface names one of the oldest shell footguns and one of the clearest places Schell can become genuinely better than bash without choosing too much too early:
**foreground job control, background jobs, suspend/resume, disown, detach, and supervised continuation are nearby moves, but they are not the same move and should stop sharing one vague folklore story.**

The historical shell stack flattened too much here.
A prompt returns and users often read that as “done.”
A job is backgrounded and users often read that as “durable.”
A process is disowned and users often read that as “supervised.”
A session is detached or resurrected and users often read that as “the same live thing.”
Schell can do much better by naming the lanes.

## 1) Foreground TTY claim is real shell truth

Classic job control is not just shell decoration.
The terminal driver, the shell, and process groups jointly decide who currently owns interactive read/write and which group receives interactive signals.
That means the shell+terminal should stop pretending that every running command has the same relation to the TTY.

A first v0 rule:
- there is at most one **foreground TTY claim** per interactive lane,
- the shell should witness when that claim is issued, suspended, resumed, or relinquished,
- and prompt reappearance should mean only that **the shell has the TTY again**, not that every target process truly completed.

That one distinction alone fixes a lot of old shell lies.

## 2) Schell should name more than one continuation lane

A useful first lane ladder could be:
- **foreground-tty** — the current process group owns interactive TTY control,
- **stopped-tty** — work is suspended and can be resumed into foreground or background,
- **shell-background-tracked** — background under the current shell with explicit job-table knowledge,
- **shell-background-untracked** — disowned or otherwise no longer tracked by the shell,
- **detached-mux** — continued behind a multiplexer or detachable workspace,
- **promoted-supervised** — continued under an explicit service/job manager,
- **restored-historical** — a resurrected or reopened view that has continuity value but not fresh live claim,
- **unknown-residue** — output or references that smell like continued work but lack exact continuity posture.

Those are already much better than one undifferentiated “background” story.

## 3) One small TTY/process-group witness family is enough to start

Schell does not need to freeze a giant process supervisor architecture first.
It can start with one compact **TTY witness** or **job witness** family.

A v0 packet could keep:
- `lane_ref` — which visible lane/block owns the witness,
- `continuation_kind` — foreground-tty / stopped-tty / shell-background-tracked / shell-background-untracked / detached-mux / promoted-supervised / restored-historical / unknown,
- `pgrp_ref` — process-group id or opaque group witness when available,
- `tty_claim_posture` — owns-readwrite / no-tty / read-blocked / write-blocked / unknown,
- `signal_posture` — interactive-break-capable / suspend-capable / supervised-stop-only / none / unknown,
- `ownership_freshness` — current / resumed / attached / restored / historical / unknown,
- `continuity_basis` — shell-job-table / mux-session / service-manager unit / historical cache / unknown,
- `promotion_posture` — local-job-only / can-promote / already-promoted / cannot-promote / unknown.

That gives the terminal enough truth to feel brilliant without locking in one POSIX-only contract, one service manager, or one multiplexer.

## 4) Background, disown, detach, nohup, and promote should stop blurring together

The old shell surface compresses a lot of distinct operator intent into a few tiny commands.
Schell should explicitly keep them separate:
- **background** — let the current shell continue while the shell still tracks the job,
- **wait** — stay attached to the outcome while not pretending foreground ownership is required,
- **disown** — stop shell tracking; continuity may continue but shell knowledge becomes weaker,
- **nohup-style continue** — ignore hangup and redirect stdio, but do not pretend this equals supervision,
- **detach** — continue inside a mux/workspace continuity system,
- **promote** — move the work under an explicit supervisor or job manager,
- **restore** — reopen historical continuity without claiming fresh live control.

These are different gifts to the operator.
They should show up as different cards and different transcript facts.

## 5) “Prompt returned” is not the completion witness

This archive already learned that launch admitted is not target completed.
Job control adds another neighboring lesson:
**prompt returned is usually a TTY-ownership fact, not a target-completion fact.**

The shell got the TTY back.
That might mean:
- the job finished,
- the job stopped,
- the job moved to background,
- the foreground pipeline handed off,
- or the current lane was detached/promoted and local waiting ended.

Schell should make that explicit, because modern terminals still repeatedly blur these states.

## 6) The best steals are humane and still decision-light

### a) Suspended-job shelf
A compact shelf for stopped work with clear rails: foreground, background, inspect output, signal, promote, or discard local tracking.

### b) One-click `wait` and `foreground` truth
A reviewed card should show whether an action will reattach the live TTY, merely await outcome, or only open historical context.

### c) Promotion rail
The nicest modern move here is not more `&` folklore.
It is a visible **promote this work** rail that hands long-running work to a proper service/job manager or detachable workspace.

### d) Continuity badges
Detached-mux, promoted-supervised, restored-historical, and shell-background-tracked should all feel different at a glance.

### e) TTY-claim transcript markers
Transcript truth should retain only the important transitions: foreground claim, stop, resume, background, disown, promotion, detach, restore, and exact closing witness when known.

## 7) A better shell story emerges cleanly

The humane answer is not to abolish job control.
It is to stop asking old job control to carry all continuation meanings by itself.

Local interactive work can stay under the shell.
Long-lived or durable work can be promoted.
Detached continuity can be explicit.
Historical resurrection can stay visibly historical.
And prompt return can stay just a TTY fact until stronger outcome truth appears.

## 8) The no-regret move

The best move right now is small:
**give Schell one shell-known TTY/process-group witness family, one named continuation ladder, and one explicit promotion rail so background, disown, detach, and durable supervised continuation stop pretending to be the same story.**

That keeps open:
- one final process/job object model,
- one final supervisor backend,
- one final mux/resurrection architecture,
- one final remote attach contract,
- and one final cross-platform TTY control API.
