# Tabstop witnesses, mirrored fields, and transform humility

This surface exists to keep one especially stealable luxury bundle honest:
**Schell should absolutely steal editor-grade tabstops, mirrored fields, enum choices, and wrap-selection moves, but it must not let template expansion become hidden shell code, hidden ambient capture, or hidden meaning-changing transforms.**

This is where old editor wisdom and shell danger meet.
The good news is that snippet systems already know how to make repetitive editing feel great.
The bad news is that many snippet systems also experimented with variables, interpolation, and transformations that are too magical when the text being edited is also a reviewed command.

## 1) Snippet luxury belongs only in active input

Tabstops and mirrored fields belong in the one shell-owned active input field.
That is where operators should be able to:
- jump between fields,
- change repeated values once,
- choose from bounded alternatives,
- wrap an existing selection,
- and then still review before run.

Historical chapters, saved workflow seeds, copied snippets, and detected repair offers may all seed that field.
They should not themselves become equally writable truth.

## 2) A tabstop witness is an editing witness, not a macro system

A tabstop witness should describe:
- where a field lives,
- what family it belongs to,
- what seeded it,
- whether it mirrors elsewhere,
- whether its choices are static or dynamic,
- and whether changing it might affect authority or reviewed basis.

A tabstop witness is **not**:
- permission to execute code while expanding,
- a hidden mini-language that rewrites neighboring tokens,
- or a promise that the final launched action will be derived later from some private template state.

## 3) Mirroring should be explicit, not visual guesswork

Mirrored fields are one of the highest-value things to steal.
If the same ticket, host, service, or environment name appears multiple times, editing it once should sometimes update every declared-equal occurrence.

But only **declared-equal** fields should mirror.
Two pieces of text that merely look the same should not silently move together.
Mirroring needs an explicit witness.

## 4) Choice lists are great when bounded and source-labeled

Enum-style choices are wonderful for:
- deployment targets,
- known branches,
- action modes,
- profile names,
- or reviewed workflow variants.

But a choice list should say where it came from.
Useful source labels include:
- static workflow enum,
- shell-known local set,
- repo accelerator suggestion,
- restored historical set,
- or explicit fresh query.

If a list is dynamic, freshness and cost posture should be visible too.

## 5) Variables should feel weaker than literal review truth

Template variables can help a lot.
Selection, clipboard, current chapter metadata, and current peer/cwd hints may all be valuable.
But those fills should remain visibly weaker than literal operator-entered review truth.

That suggests a simple rule:
- literal operator text is strongest,
- reviewed chapter literals are next,
- workflow defaults and static choices come after,
- ambient or helper-derived fills need badges,
- and unresolved variables should stay unresolved rather than silently guessed.

## 6) Wrap-selection moves are worth stealing

Editors are right that wrap-selection is delightful.
In Schell, that could mean:
- wrap a path selection in a quote form,
- wrap a selection in a safe-open command seed,
- wrap visible output in a follow-up grep or jq seed,
- or wrap a selected value into a workflow parameter field.

The key is that wrap stays a visible editing move.
It should not retroactively reinterpret command history or silently relabel already-reviewed execution truth.

## 7) Transform humility is the hard rule

Transforms are where this gets dangerous.
A transform may be:
- harmless display polish,
- convenience insertion,
- or a real semantic rewrite.

Schell should treat those very differently.

### Good early transforms
- display-only casing or decoration,
- mirrored presentation where the exact value is still revealable,
- non-authority-bearing derived labels.

### Suspicious transforms
- changing executable names,
- changing hostnames or service targets,
- rewriting path roots or extensions,
- injecting flags,
- converting selection text into a command fragment with hidden quoting.

Those stronger transforms should either be refused or pushed into an explicit reveal-and-review lane.

## 8) Expansion should always end before run begins

A healthy ladder looks like this:
- expand seed/template,
- move between fields,
- pick choices,
- accept or reject mirrored edits,
- inspect variable provenance,
- reveal exact text/argv for suspicious fields,
- then run.

Expansion should normally leave the cursor in active input.
The operator should still be able to back out, copy, or change the command.

## 9) A compact first proving slice

A compact first specimen should show:
1. one command seed expanding into three fields,
2. one mirrored field family,
3. one enum choice list,
4. one wrap-selection gesture,
5. one helper-derived variable wearing a provenance badge,
6. one suspicious transform being refused or downgraded to preview,
7. and one explicit run step that stays separate from expansion.

That is enough to make Schell feel modern and luxurious without freezing parser, renderer, workflow serialization, or provider model.

## 10) Things to refuse for now

Refuse for now:
- interpolated shell code in templates,
- auto-run after expansion,
- hidden ambient variable catalogs,
- transforms that silently change authority-bearing meaning,
- and one mandatory global snippet grammar for every lane.

The right law is:
**steal the editor comfort, keep expansion insert-only, keep provenance visible, and make exact launch truth stronger than template magic.**
