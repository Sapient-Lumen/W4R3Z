# Hyperlink witnesses, unfurl gates, and hover humility

This surface keeps one boundary explicit:
**a great shell+terminal should treat visible links as explicit objects with source and context, but it should not quietly become a stealth browser that unfurls, extracts, preconnects, or records raw subjects just because a URI became visible.**

Modern terminal UX is getting very good at links:
- explicit OSC 8 hyperlinks,
- heuristic URL detection,
- cwd-aware file and path resolution,
- shell-known command boundaries,
- modifier-key open gestures,
- rich open actions,
- and even command-aware quick fixes that can open a URL.

Those are all genuinely useful.
They also create one of the next easy ways for a terminal to overreach:
- hover becomes fetch,
- visible text becomes normalized link authority,
- open becomes unfurl,
- unfurl becomes content extraction,
- link memory becomes durable recents,
- and transcript truth quietly turns into a raw-URI side channel.

SlopOS is already drawing those lines on the OpenURI seam.
Schell should import the lesson before the custom shell+terminal accidentally becomes a very flattering hidden browser.

## Why this surface exists

There are at least five distinct things a shell+terminal can do with a visible link:
1. notice it,
2. describe it,
3. let the operator open it,
4. fetch extra metadata about it,
5. or extract content from it.

History says systems love to flatten those into one friendly verb.
That is exactly the mistake to avoid here.

A hyperlink in terminal output may come from very different sources:
- explicitly emitted by the program,
- inferred by pattern matching,
- reconstructed from cwd or semantic context,
- inserted from history or a runbook,
- restored from an older session,
- or imported from somewhere outside the shell entirely.

Those origins matter.
They should stay visible.

## The compact answer: hyperlink witnesses

A useful small object here is **hyperlink witness**.

A hyperlink witness is not the whole browsing stack.
It is a compact Schell object that says:
“there is a visible candidate link here, here is how we know about it, and here is which actions stay weak versus strong.”

A v0 hyperlink witness probably needs:
- `subject_ref` — exact visible subject or bounded redacted form,
- `display_text` — what the operator actually saw,
- `source_family` — explicit-osc8 / inferred / shell-attested / inserted / restored / imported,
- `context_ref` — optional command chapter, cwd, object card, or selection packet basis,
- `normalization_state` — verbatim / normalized / redacted / unknown,
- `open_posture` — ask / proposal-only / shell-open / policy-routed,
- `fetch_posture` — no-fetch / explicit-fetch / historical-metadata / repaired,
- `history_posture` — none / shell-local hint / historical / unknown,
- `freshness_posture` — current / historical / restored / imported / unknown,
- `notes_ref` — optional inspect card or explanation.

That is enough to power humane link UX without standardizing a crawler, browser profile API, or recents database.

## 1) Explicit and inferred links should not be conflated

The outside ecosystem already exposes a useful split.
Some links are deliberate, like OSC 8 hyperlinks.
Some are inferred from text patterns.
That split matters.

Schell should probably make at least this ladder visible:
- **explicit** — a program intentionally emitted the link,
- **inferred** — the terminal guessed from visible text,
- **shell-attested** — the shell added bounded contextual knowledge such as cwd or command chapter identity,
- **historical/restored** — useful but not freshly witnessed now.

That gives the operator a better mental model than one generic clickable color.

## 2) Hover should stay descriptive by default

One of the best no-regret rules here is:
**hover should not fetch.**

Hover can still be good.
It can show:
- the exact visible URI or redacted form,
- whether the link is explicit or inferred,
- whether contextual resolution depended on cwd or shell-known boundaries,
- which open action would be taken,
- and whether richer metadata is current, historical, or unavailable.

But hover should not silently:
- preconnect,
- prefetch,
- prerender,
- crawl Open Graph/oEmbed metadata,
- fetch a preview image,
- or distill content.

That keeps pointer delight from turning into stealth work.

## 3) Open, unfurl, and extract should stay separate verbs

A visible link may support several action rungs:
- **copy / insert**,
- **inspect**,
- **open**,
- **fetch preview metadata**,
- **extract content**,
- **materialize local bytes**.

The custom shell+terminal should not pretend those are all the same action.

A good v0 ladder is:
- inspect-only is cheapest,
- open is a one-way handoff,
- unfurl is explicit second work,
- extraction is an even stronger explicit workflow,
- and materialization is separate again.

That maps very cleanly to the current SlopOS OpenURI boundaries.

## 4) Ask-before-open is especially valuable for weak link sources

The ecosystem has a few strong clues here.
Modifier keys, ask-before-open, and strong warnings all exist because link activation is easy to trigger accidentally and the target can be dangerous.

Schell should steal that lesson selectively:
- explicit shell-known links may graduate to a cleaner one-gesture open,
- inferred links should default lower on the ladder,
- non-http schemes should stay visibly special,
- and anything ambiguous or normalized should be inspect-first or ask-first.

That is a great way to keep the terminal delightful without treating every visible URI as equally trustworthy.

## 5) Rich previews should be explicit, freshness-badged, and source-labeled

Link cards are tempting because they look “super awesome” fast.
The problem is that a title, icon, image, or summary is already extra work.
It may be stale.
It may have come from another machine.
It may not match what the eventual handler would show.

A better Schell move is:
- no fetch on sight,
- no fetch on hover,
- explicit **Fetch card** or **Refresh card** action when richer metadata is wanted,
- clear badges like `historical`, `fetched-now`, `imported`, or `unknown`,
- and explicit disclosure when a preview was based on cached or shared metadata instead of fresh fetch.

That makes rich links possible without normalizing the terminal as a hidden crawler.

## 6) Subject echo should stay bounded

URIs are not harmless text.
They often carry query parameters, fragments, opaque IDs, or sensitive path material.

Schell should therefore be conservative about:
- transcript export,
- shell-local history,
- recents lists,
- and copied diagnostic logs.

A hyperlink witness should be allowed to keep:
- exact visible text for immediate local interaction,
- redacted or digested durable evidence,
- and a visible distinction between `verbatim now` and `durable description later`.

That imports a very strong SlopOS lesson into the terminal world.

## 7) Contextual resolution is brilliant when it stays local and humble

Some of the nicest current terminal behavior comes from context:
- cwd-aware path resolution,
- command-aware selection,
- semantic history,
- line-aware open targets,
- and shell integration that knows what command produced the text.

Schell should absolutely steal that.
But it should describe it honestly.

When a link or path became stronger because the shell knew:
- the command chapter,
- the cwd,
- the remote peer,
- the active repo,
- or the active execution ground,

that contextual strengthening should remain a **local witness**, not portable link truth.

## 8) Good “super awesome” ideas that stay decision-light

### a) Link inspect chip
A tiny inspect chip or hover card that shows:
- explicit/inferred source,
- target scheme,
- normalization posture,
- open route,
- and whether richer metadata exists.

### b) No-fetch hover
Hover only reveals local truth and route posture.
A separate click or key summons metadata fetch.

### c) Fetch card / refresh card
A dedicated richer action that says “fetch title/icon/summary now” and returns a freshness-badged card instead of pretending the preview was always just there.

### d) Link source badges in transcript and history
When a visible action came from an inferred link versus an explicit shell-known link, keep that difference visible in the action record.

### e) Scheme-sensitive ladders
`https` and `file-like` contextual targets do not need the same default treatment as custom app schemes.
Keep the action ladder visibly different.

### f) Historical preview honesty
Allow rich link cards to survive restoration, but keep them visibly historical until explicitly refreshed.

## 9) The no-regret move

The best move right now is not to invent a full browser-subsystem abstraction.
It is to pin one rule:
**hyperlinks in Schell should become explicit witnesses before they become actions, and richer link work should remain separately named from generic open.**

That keeps the path open for excellent link UX while leaving big decisions unfrozen:
- no final hyperlink protocol commitment,
- no final metadata-fetch backend,
- no recents/history schema freeze,
- no browser-profile/session-selection design,
- and no crawler/extractor architecture commitment.

## 10) Sources worth stealing from

- xterm.js link handling: explicit OSC 8 links and implicit pattern links
- xterm.js link-handler security guidance and warning posture
- kitty hyperlink processing and ask-before-open mode
- VS Code shell integration for cwd-aware link resolution and command boundaries
- iTerm2 semantic history for line-aware contextual opening
- Chrome speculation rules docs as a reminder that prefetch and prerender are real work with real costs
