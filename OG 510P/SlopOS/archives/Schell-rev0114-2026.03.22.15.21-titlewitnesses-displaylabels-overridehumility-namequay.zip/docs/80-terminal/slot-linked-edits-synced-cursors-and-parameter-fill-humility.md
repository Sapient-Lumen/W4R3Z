# Slot-linked edits, synced cursors, and parameter-fill humility

This surface exists to keep one very tempting cluster of ideas honest:
**Schell should absolutely make workflow fills, repeated parameters, and prompt-local editing feel amazing, but it must not let slot fills, synced cursors, or prompt clicks quietly become hidden text surgery, hidden parser policy, or hidden execution authority.**

This is where several attractive stories meet:
- workflow seeds landing in editable input,
- repeated parameters that should edit together,
- prompt-local click-to-cursor and slot cycling,
- and typed parameter help that wants to fill things in for the operator.

All four are worth stealing.
All four become dangerous if they collapse into one flattering “Schell just fixed the command for me” story.

## 1) The one true editing surface is still active input

Slot-linked edits belong in the one shell-owned active input field.
That is the right place for:
- cursor movement,
- selection,
- repeated-slot mirroring,
- parameter cycling,
- partial suggestion acceptance,
- and visible preflight cues.

Historical command chapters, output capsules, transcript cards, imported snippets, and helper notes may still seed active input.
They should not themselves become equally writable truth.

## 2) A slot is an editing witness, not a second command language

A parameter slot is best understood as an editing witness over already-visible input.
It may describe:
- the token span it currently occupies,
- its kind,
- its source,
- whether it is repeated elsewhere,
- whether changing it may alter authority or basis,
- and which safer fills are available.

A slot is **not**:
- a hidden macro,
- a parser-owned AST node that silently rewrites nearby text,
- or permission to reinterpret command language outside visible input.

## 3) Every slot should say where it came from

Good slot fill depends on visible provenance.
Useful origins include:
- **chapter literal** — copied exactly from the source chapter,
- **workflow default** — supplied by a saved seed,
- **completion suggestion** — proposed by a provider,
- **ground guess** — inferred from current cwd/peer/view,
- **operator value** — typed fresh right now.

That provenance matters because two equal-looking fills may deserve very different trust.

## 4) Synced cursors should only exist for declared-equal slots

Repeated-parameter mirroring is one of the highest-value luxuries Schell can steal.
If the same host, branch, ticket, service, or path token appears multiple times, editing it once should sometimes update every declared-equal occurrence.

But the equality relation must be explicit.
Two highlighted words that merely *look similar* should not mirror by default.
Synced edits should be reserved for slots with a visible “same parameter family” witness.

## 5) Prompt-local pointer and key luxuries stay field-local

Prompt-local click-to-cursor, slot focus, `SHIFT-TAB` slot cycling, and richer key events can all be wonderful.
But they should remain:
- inside live active input,
- contingent on shell-known prompt posture,
- and degradable when capability witnesses are absent.

That keeps the luxury real without turning one renderer or one input protocol into Schell truth.

## 6) Fill, review, and run are still different actions

A healthy ladder looks like this:
- **insert value**,
- **accept one next word/piece**,
- **cycle slot candidate**,
- **focus next slot**,
- **open parameter help**,
- **review basis/effect drift**,
- **run**.

The last step should stay separate.
Parameter fill should usually end with the cursor still in active input.

## 7) Authority-bearing slots deserve extra cues

Not all slots are equally harmless.
Changing these usually deserves stronger review cues:
- executable selectors,
- peer/service targets,
- secret handles,
- writable paths,
- authority-bearing flags,
- launch/open destinations.

For these slots, Schell should prefer:
- stronger provenance badges,
- exact-value reveal,
- diff cues,
- and visible basis drift before run.

## 8) Slot fill should not mutate history or output

Schell should refuse the seductive idea that because a command chapter is exact, it is also the right place to perform live refactoring.
Command chapters are excellent parents for capture, compare, and promote.
They are not the same thing as the active prompt.

Likewise, output-derived quick fixes may seed slots.
They should not silently rewrite the historical chapter they came from.

## 9) Good first proving slice

A compact proof could show:
1. one workflow seed landing in active input,
2. one parameter row with three typed slots,
3. one repeated slot family using synced cursors,
4. one prompt-local click-to-focus interaction,
5. one authority-bearing slot surfacing a basis-drift warning,
6. and one explicit run button/key that stays separate from every fill gesture.

That is already enough to make Schell feel custom, fast, and obviously more humane than ordinary shell folklore.

## 10) Things to refuse for now

Refuse for now:
- hidden regex surgery across transcript/history,
- auto-run after workflow fill,
- provider-side quoting/splitting magic that is not reflected in visible input,
- synced edits for merely similar-looking text,
- prompt-local edits outside shell-marked active input,
- and one giant mandatory editor/input protocol.

The right law is:
**edit in the field, show the slot, keep provenance visible, and run separately.**
