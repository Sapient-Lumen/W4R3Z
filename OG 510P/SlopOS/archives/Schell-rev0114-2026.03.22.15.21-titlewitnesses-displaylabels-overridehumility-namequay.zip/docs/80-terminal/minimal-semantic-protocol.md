# Minimal semantic protocol

This is **not** the final shell↔terminal protocol.
It is the smallest sketch that seems worth carrying while the archive is still proving its first interaction.

## Why sketch anything yet?

Because multiple current terminals already benefit from explicit prompt and command-boundary signaling.
Schell should learn from that without pretending the protocol is settled.

## Candidate layer split

### Layer A — shell truth

The shell owns:

- exact reviewed action identity,
- exact artifact identity,
- exact mutable review basis when relevant,
- requested authority scope,
- receipt / denial ids,
- replay handles,
- session lineage,
- request-state versus live-state truth,
- and command-block trust grade when the shell can attest to it.

### Layer B — semantic transport

A tiny transport should be able to mark at least:

- prompt start / end,
- user input start / end,
- review card start / end,
- output start / end,
- denial block start / end,
- receipt block start / end,
- background-change block start / end,
- current working context,
- and trust grade for the currently emitted block.

### Layer C — local luxury UX

A richer terminal may then add:

- click-to-jump,
- block selection,
- inline previews,
- denial shelves,
- background shelves,
- finish notifications,
- readonly replay mode,
- and receipt cards.

## Candidate bootstrap rule

The bootstrap protocol should carry *references*, *boundaries*, and *trust hints*, not giant payloads.
That keeps the shell truth portable and the terminal free to render locally.

## Things to keep open

- escape-sequence vs side-channel transport,
- which zones are mandatory vs optional,
- whether background state needs its own live stream,
- how remote hops should preserve or degrade semantic marks,
- how transcripts should store semantic boundaries,
- and whether trust grades remain local or later require stronger attestation.

## Immediate use

This sketch is good enough to guide the first prototype:
mark a reviewed action, carry its trust grade, emit a denial or receipt, and prove that plain text still tells the truth.
