# Intent packets, plumb routes, and exact-open bridges

This surface records a new no-regret candidate cluster for Schell:
**let visible things become richly actionable, but route those actions through explicit intent packets and route witnesses instead of ambient open/run folklore.**

The design pressure comes from three directions:

- SlopOS already treats CLI and cross-application actions as plumb-first, explicit-invocation, request-local intent routing rather than helper magic.
- DelayBasin keeps distinguishing exact witnessed moves from flattering nearby fallback and asks for explicit hold/denial witnesses when a stronger action has not been earned.
- Current terminals and IDE-terminals keep turning visible links, paths, command blocks, and workflows into action sources.

## 1) Visible objects want actions, but not all actions are the same

A modern shell+terminal can expose many visible objects:
- active input text,
- selected semantic zones,
- paths,
- URIs,
- command regions,
- receipts,
- output capsules,
- workflows,
- and imported artifacts.

The wrong answer is to give them all one generic click behavior.
The better answer is to route them through named action classes.

## 2) Intent packet

A good first object is **intent packet**.

An intent packet is a compact shell-owned descriptor for a requested terminal-visible action.
It is not the final effect itself.
It is not a generic callback envelope.
It is a named request.

A v0 packet probably needs:
- `intent_kind` — closed family name,
- `subject_ref` — exact selected object or region,
- `subject_grade` — explicit / shell-authenticated / terminal-inferred / restored / imported,
- `lane_ref` — where the request originated,
- `basis_ref` — exact reviewed basis when relevant,
- `wallet_hint` — compact descriptive authority hint when present,
- `action_strength` — inspect / insert / reveal / open / derive / attach / propose,
- `delivery_posture` — local-only / review-required / portal-mediated / proposal-only.

That is enough to make visible-object actions explicit without freezing a giant router.

## 3) Route witness

A second useful object is **route witness**.

The route witness answers a narrower question:
**what action family matched this intent packet, and how strong was the resulting action allowed to be?**

A v0 witness might keep:
- `intent_ref`,
- `matched_family`,
- `exactness_class`,
- `mediation_needed`,
- `expected_receipt_kind`,
- `hold_reason` or `deny_reason` when blocked,
- `counterfactual_nearby_action` when a tempting but stronger action was refused.

That gives Schell a way to be smart without becoming slippery.

## 4) Exactness classes should stay small and legible

A decision-light first ladder could be:
- `inspect-only`
- `insert-only`
- `exact-open`
- `exact-reveal`
- `derived-workflow`
- `attach-context`
- `proposal-only`

This is intentionally smaller than a full action algebra.
The point is not to model everything.
The point is to stop pretending that every visible click means the same thing.

## 5) Open and reveal should remain different

One of the strongest imports from SlopOS is that:
- generic open is not exact reveal,
- exact reveal is not approximate nearby browse,
- session/profile selection is not generic open,
- and attach/insert/propose are not execution.

Schell should keep those seams visible.
A path-like subject might therefore support:
- insert into active input,
- reveal exact item,
- mediated open,
- inspect metadata,
- or derive a workflow seed.

Those should stay different packets and different witnesses.

## 6) Prefer reviewable landings over silent action

The right default for many smart actions is not “execute now.”
It is one of these:
- insert into active input,
- open a review card,
- create a proposal object,
- attach exact context to an ongoing debugging lane,
- or open a hold card explaining why a stronger route was refused.

This is one of the clearest ways to make Schell powerful without ambient authority creep.

## 7) Hyperlinks and hints should be routed by strength, not by glamour

Explicit OSC 8 links, shell-marked command regions, semantic-zone selections, and terminal-inferred path guesses are all useful.
They are not equally strong.

Schell should therefore keep at least a small strength rule:
- shell-owned exact objects can unlock stronger routes,
- explicit external links can unlock mediated open routes,
- inferred or restored text usually starts at inspect/insert/propose,
- and exact execution should remain rare and separately named.

This parallels trusted-command-block posture without flattening all action routing into trust/no-trust binary.

## 8) Great product moves become possible here too

Once intent packets and route witnesses exist, Schell can do delightful things without lying:
- `insert selected path` versus `open selected path`,
- `reveal exact artifact` versus `browse nearby`,
- `attach last command region` to a troubleshooting lane,
- `derive workflow seed` from selected output,
- `explain this click` for widening or portal-mediated routes,
- `proposal-only open` when the current lane is agent-authored or historical.

## 9) Transcript truth should preserve the right minimum

The transcript does not need every local hover state.
It does need the important truths:
- that an intent packet existed,
- what exact subject it named,
- what strength class it requested,
- what route witness posture matched,
- and whether the action landed in inspect, insert, review, proposal, mediated open, or denial.

That is the compact portable baseline.

## 10) No-regret first cut

A first specimen set could stay small:

1. one exact path selection that offers `insert` and `reveal` separately,
2. one URI selection that lands in a mediated open card,
3. one inferred historical path that downgrades to inspect/propose only,
4. one workflow pick that pastes into active input,
5. one selected output slice that becomes a workflow seed proposal,
6. one exact show-item request that refuses parent-browse fallback,
7. and one transcript slice showing intent packet plus route witness.

That is enough to learn a lot without freezing the final routing engine, hyperlink policy, or callback architecture.
