# Tool-catalog witnesses, resource attachments, and elicitation humility

This surface exists to keep one especially tempting luxury bundle honest:
**Schell should absolutely steal explicit tool catalogs, attached resources, reusable prompt templates, inline app/forms, and structured elicitation — but it must not let helper ecosystems become ambient shell authority.**

The point is not to avoid integrations.
The point is to keep them legible.
A shell+terminal can feel dramatically better when external tools and attached context are nearby.
It becomes confusing when discovery, attachment, form-filling, and execution all blur into one flattering surface.

## 1) Keep catalog classes visibly distinct

Schell should not flatten everything into “plugins.”
At minimum, the operator should be able to tell whether a visible item is:
- a **server**,
- a **tool**,
- a **resource**,
- a **prompt/playbook**,
- an **app/form panel**,
- or a **channel/event source**.

Those objects are adjacent.
They are not interchangeable.
A prompt template is not a tool call.
A resource attachment is not hidden memory.
An app panel is not permission.
A pushed event is not durable background truth.

## 2) A tool-catalog witness should describe the actual footing

A healthy tool-catalog witness should carry things like:
- server identity,
- where it came from,
- scope (`profile`, `workspace`, `session`, or equivalent),
- transport posture,
- local-vs-remote posture,
- sandbox posture,
- current trust/admission state,
- the tool/resource/prompt/app counts or entry points it exposes,
- whether catalog changes are expected live,
- and what stronger approvals remain required before side effects.

It should also make clear what it is **not**:
- not proof that every listed tool is safe,
- not proof that the current server basis matches some earlier trust decision,
- and not proof that a visible helper may silently run shell actions.

## 3) Resource attachments should be explicit context cards

Attached resources are worth stealing because they make context visible and reusable.
But Schell should keep them as explicit attached objects:
- attach,
- inspect,
- detach,
- refresh,
- compare,
- and cite where they came from.

A resource should not silently become ambient session memory.
If a later command or assistant step depends on a resource, that dependency should stay visible.

## 4) Prompt templates should stay reusable playbooks, not policy

Reusable prompts/playbooks are clearly useful.
Operators should be able to browse them, search them, parameterize them, and insert them deliberately.
But Schell should keep a sharp split between:
- a prompt template/playbook,
- a reviewed workflow seed,
- an exact shell artifact,
- and a current live approval.

Prompt metadata may help routing.
It should never become permission.

## 5) Inline app/forms should improve review, not bypass it

Interactive app panels are worth stealing because they can:
- display structured results,
- collect parameters cleanly,
- compare alternatives,
- and make multi-step tasks feel much less brittle.

But an app/form panel should stay weaker than the shell-owned review object.
A healthy app surface may:
- fill fields,
- generate candidate actions,
- stage attachments,
- or propose edits.

It should not quietly count as “already approved.”
The operator should still be able to see what exact stronger action would happen next.

## 6) Structured elicitation deserves its own review object

Mid-task questions are a real luxury when they are done well.
Schell should absolutely steal structured elicitation.
But the result should be a visible field witness:
- what asked the question,
- which fields were collected,
- which were optional,
- what defaults or recommendations were present,
- and what exact follow-on action those fields would feed.

That is much healthier than one giant conversational blur where the system keeps asking until it accumulates enough authority.

## 7) Component-local hidden state needs humility

Some helper UIs need local hydration state, temporary view data, or private widget/session metadata.
That is fine.
But Schell should keep the layers explicit:
- **component-local helper state**,
- **transcript-visible content**,
- **reviewed execution truth**.

Those are three different authority stories.
The first may help render.
The second may help explain.
The third is the only one that should authorize shell-side effect.

## 8) Tool invocation cards should be first-class

A strong system should make actual tool use legible.
Each invocation card should be able to show:
- exact server and tool identity,
- argument shape,
- whether the call was read-only or side-effectful,
- relevant scope/trust/sandbox posture,
- result kind,
- and what outputs became transcript-visible, component-only, or review-only.

That makes integrated tooling feel more trustworthy than one generic “assistant did something” bubble.

## 9) Auto-discovery should stay weaker than admission

Auto-discovery is attractive because it reduces setup friction.
But Schell should keep the verbs separate:
- **found**,
- **configured**,
- **trusted**,
- **started**,
- **enabled**,
- **approved for this action**.

One of the easiest ways to accidentally build ambient authority is to collapse those into a single “available” badge.

## 10) Channels and pushed events need session honesty

Channels and event push can be delightful.
They can bring CI, monitoring, or chat events into a live terminal/assistant session.
But a channel event should stay visibly weaker than durable background truth.
It should say things like:
- source,
- when it arrived,
- whether this session was open to receive it,
- and whether it created only a message, a proposed action, or a review card.

A pushed event is not proof of durable service ownership, always-on presence, or background grant truth.

## 11) A compact first proving slice

A compact first specimen should show:
1. one tool-catalog strip with source/scope/transport/sandbox/trust badges,
2. one explicit resource attachment card,
3. one prompt template/playbook with argument fill,
4. one tool invocation card with exact server/tool identity,
5. one inline app/form panel feeding a review object,
6. one structured elicitation card with exact field coverage,
7. one auto-discovered server that is found but not yet trusted,
8. one sandboxed local server,
9. and one pushed event that stays session-local rather than durable-background truth.

That is enough to make Schell feel unusually capable without freezing the final plugin ecosystem, app runtime, or transport stack.

## 12) Things to refuse for now

Refuse for now:
- one undifferentiated “integration/plugin” bucket,
- hidden ambient tool discovery,
- app/forms that directly bypass shell-owned review,
- prompt/template metadata acting as permission,
- invisible callback registries or hidden event buses,
- and pushed channels that overclaim durable background or notification truth.

The right law is:
**steal explicit tool catalogs, resource attachments, prompt-template reuse, inline app/forms, and structured elicitation — but keep all of them visibly weaker than exact reviewed shell truth.**
