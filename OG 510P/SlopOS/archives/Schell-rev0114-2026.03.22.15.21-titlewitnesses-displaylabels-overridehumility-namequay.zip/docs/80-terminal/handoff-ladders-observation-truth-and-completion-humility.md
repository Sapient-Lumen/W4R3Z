# Handoff ladders, observation truth, and completion humility

This surface keeps one boundary explicit:
**the shell+terminal should distinguish proposal, review, handoff admission, observed target state, completion, and user-saw-it claims instead of flattening them into one flattering "done" surface.**

Schell already has strong pressure around finish notices, command chapters, workflow seeds, object cards, transcript cards, prompt budgets, and restored-state honesty.
What is still easy to blur is the meaning of a successful launch or run.
A terminal can easily say “opened”, “ran”, “done”, or “restored” when it only knows something weaker:
- text was inserted,
- a review card was accepted,
- a handoff was admitted,
- a target was started,
- a pane resumed,
- or a prompt returned.

SlopOS keeps warning against exactly this blur.
So should Schell.

## Why this surface exists

The custom shell+terminal will want many powerful actions:
- open a file,
- open a URL,
- reveal an object,
- launch a workflow,
- run a saved seed in a pane,
- attach to a remote lane,
- resume a restored command,
- or hand an object to an external viewer/editor.

Those moves are worth building.
The trap is that the UI starts presenting one generic success style even though the underlying truths are very different.
That is how systems accidentally teach operators the wrong mental model.

## The compact answer: a handoff ladder

Schell should probably keep a small ladder of outcome states rather than one generic success bit.
The names can change later.
The separation should not.

### 1) Proposed / inserted

The terminal or shell suggested something or inserted text into the active prompt.
Nothing has run.
Nothing has been handed off.
This is still proposal-only.

Examples:
- a completion row inserted a flag,
- a workflow seed landed in the prompt,
- a command chapter was copied into input,
- a repaired command was staged for review,
- or a resurrected command is visible but suspended.

### 2) Reviewed / armed

The operator approved the action class and exact basis.
This is stronger than insertion.
It is still not handoff truth.

Examples:
- a review card was accepted,
- a strong action cleared a compare-and-set gate,
- an open or send action was armed against an exact object,
- or a rerun was approved on exact basis.

### 3) Handoff admitted

Schell knows the request crossed the shell-owned seam.
This is often the strongest portable truth available.
It should be treated with respect, but also with humility.

Examples:
- the shell launched the command,
- the terminal routed an intent packet to the correct seam,
- the portal/open bridge admitted the request,
- the pane manager accepted a command pane launch,
- or a remote attach request was accepted.

This state does **not** automatically prove:
- the target rendered content,
- the handler stayed alive,
- the user saw the result,
- the external app finished,
- or the side effect fully completed.

### 4) Observed start / observed ready

A stronger target-local or shell-witnessed observation exists.
This is better than admission, but it is still narrower than “done”.

Examples:
- the shell witnessed child start and bound an exact chapter,
- a target sent a ready witness,
- a remote peer witness was reacquired,
- a viewer reported a loaded object identity,
- or a pane moved from suspended to actively running.

The key discipline:
**only claim observed readiness when an exact witness exists.**
Do not infer it from window focus, pane visibility, or generic optimism.

### 5) Completed / drained

A run finished and the shell has exact completion truth for that run.
This may include exit code, completion packet, drain completion, or another shell-owned end witness.

This still does **not** prove:
- the user understood the result,
- the user saw an opened document,
- a downstream external app finished every internal task,
- or a future observer can safely replay the same thing without new review.

### 6) User-saw-it / effect-fully-consumed

This category should be used very sparingly.
In many cases it is not knowable in a trustworthy portable way.
That is fine.
The point is not to fake omniscience.
The point is to keep weaker truths from wearing stronger words.

## Rule 1: default wording should be admission-scoped unless stronger evidence exists

When Schell launches something external, the safe default is wording like:
- handed off,
- admitted,
- launched,
- sent to viewer,
- opened request accepted,
- resume request accepted,
- or waiting for observed readiness.

Avoid wording like:
- opened successfully,
- finished,
- delivered,
- viewed,
- consumed,
- synced,
- or restored and ready,

unless the system really has the right witness.

## Rule 2: prompt return is not completion proof for everything that matters

The shell may know that a local command finished.
That is useful.
But prompt return does not automatically prove:
- an external open completed,
- a remote action converged,
- a viewer loaded the exact object,
- or a spawned helper finished all downstream work.

Schell should be especially careful here because prompt return is one of the oldest accidental lies in terminal UX.

## Rule 3: visible suspension is a feature, not an embarrassment

Resurrected or imported actions should often reappear as staged or suspended.
That is good.
A visible `press ENTER to run` or `review before resume` posture is much more honest than silently treating restored text as resumed work.

This is a place where “super awesome” and “careful” align.
The luxurious move is not silent resumption.
It is rich restoration with exact re-entry posture.

## Rule 4: shell-owned completion truth and target-owned observation truth should stay distinct

Some facts belong to the shell:
- command launched,
- exit code,
- command chapter ended,
- drain complete,
- cancellation acknowledged.

Some facts belong to a target or peer witness:
- document identity loaded,
- remote peer reacquired,
- exact object revealed,
- live session attached,
- or a workflow engine reached a named checkpoint.

Do not flatten these into one field just because the UI wants one badge.

## Rule 5: historical and restored states should re-enter low on the ladder

A restored chapter, pane, workflow seed, open target, or remote lane should usually re-enter as:
- historical,
- staged,
- suspended,
- or awaiting witness.

It should not re-enter as:
- running,
- ready,
- current,
- or completed,

unless fresh evidence upgrades it.

## Rule 6: exact badges beat optimistic summaries

A compact badge ladder might look like:
- `inserted`
- `reviewed`
- `admitted`
- `observed`
- `completed`
- `historical`
- `stale`
- `unknown`

These names can evolve.
What matters is that Schell avoids the old generic badge collapse where every strong-looking surface just says `done`.

## Stealable “super awesome” moves under this model

### Rich open cards with exact posture
An object card can say:
- `insert path`,
- `safe-open request`,
- `viewer admitted`,
- `viewer observed object #…`,
- `historical viewer state`,
without pretending these are the same event.

### Workflow launches that stay editable until review
A runbook or workflow can land as inserted text first, become reviewed next, and only then become admitted run truth.
That makes reuse powerful without hiding execution.

### Resurrected commands that resume honestly
A restored pane can show the last known command, scrollback, cwd witness, and basis badge while still pausing before rerun.
That is better than a fake “session restored successfully” blanket claim.

### Remote attach with witness upgrades
A remote card can move through:
- attach requested,
- peer admitted,
- peer witnessed,
- session current,
while keeping stale/unknown posture visible when continuity is weak.

### Finish notices that point to the right thing
A finish notice can say:
- `command exited 0`,
- `handoff admitted; target completion unknown`,
- `remote peer ready witness received`,
- `waiting for explicit reopen`,
which is far more useful than one cheerful but ambiguous success toast.

## Decisions intentionally kept open

This surface does **not** freeze:
- one external-app callback protocol,
- one viewer/session observation channel,
- one remote attach transport,
- one pane-manager lifecycle API,
- one terminal badge taxonomy,
- or one final packet schema.

The no-regret move is smaller:
**keep a handoff ladder, default to admission-scoped wording, and only promote a state when an exact stronger witness exists.**
