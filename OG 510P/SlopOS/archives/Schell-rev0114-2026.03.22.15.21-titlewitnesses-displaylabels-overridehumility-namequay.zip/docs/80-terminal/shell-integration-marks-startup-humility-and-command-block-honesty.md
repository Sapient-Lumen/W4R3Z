# Shell integration marks, startup humility, and command-block honesty

Schell should aggressively steal the best command-aware terminal ideas.
It should also be extremely suspicious of the way many current systems obtain them.
The point of this surface is to keep those two truths together.

## Working rule

**Semantic marks are worth stealing.
Startup injection is real authority.
Command blocks are local luxury until the shell attests to them.
Object actions should route through explicit intent packets, not smart-click folklore.**

## 1) What Schell should absolutely steal

### Shell-known command boundaries

A modern terminal is much better when it knows:
- where the prompt starts and ends,
- where the active editable input starts and ends,
- where a command's output begins and ends,
- what cwd or peer context the command belonged to,
- and whether the shell itself attested to those boundaries.

Schell should therefore treat prompt/input/output/receipt marks as a first-class shell-owned truth family.

### Command chapters / blocks

Operators clearly want command+output grouped into useful navigation units.
Schell should steal:
- jump to previous/next command,
- select one exact command output region,
- re-input a previous command without rerunning it,
- bookmark or annotate a chapter,
- and browse recent chapters by source/lane/peer/ground/outcome badges.

### Prompt-local click/edit luxury

Prompt-aware cursor movement, output selection, and block-level actions are real delight.
Schell should steal them, but only inside explicit trust/capability posture.
Prompt-local cursor movement is not permission to treat scrollback as editable shell state.

### Rich reentry

Restored sessions, panes, and chapters are worth stealing too.
But the restored thing should say plainly whether it is:
- live,
- historical,
- restored-and-not-yet-reacquired,
- or unknown.

## 2) What Schell must refuse

### Refuse terminal-owned startup magic

If a terminal feature depends on injecting startup code, altering `ENV` / `BASH_ENV`, bypassing the usual startup path, or silently taking responsibility for rc-file loading, that should be visible as an explicit startup footing.
The terminal may *offer* integration.
It must not become the hidden owner of shell bootstrap semantics.

### Refuse terminal-local blocks as the only truth

A command block is useful.
It is not automatically durable shell truth.
The transcript still needs a plain-text path for:
- command boundary truth,
- receipt/denial truth,
- route truth,
- and historical-vs-live honesty.

### Refuse hidden helper work as correctness

Helper processes, prompt-time completion fetches, remote idle-time enrichments, and cached previews may all be valuable.
They should still be visible as named helper lanes with source, freshness, and budget posture.
A fast prompt should not depend on unbounded invisible work.

### Refuse smart-click flattening

Open, reveal, insert, attach, derive, copy, export, and execute are not one action.
A visible path/URL/object should first become an explicit intent packet that says:
- exact subject,
- route posture,
- trust grade,
- and why any stronger nearby move is blocked.

## 3) Trust grades for command blocks

Every visible command chapter should carry one explicit trust grade:

- **guessed** — inferred from terminal text or heuristics,
- **marked** — boundary-marked by a cooperating shell/adapter, but not yet strong shell-owned action truth,
- **shell-authenticated** — emitted by the shell's own semantic transport,
- **historical** — durable but not current live authority,
- **restored** — historical state revived into local UX but not yet reacquired as live.

These grades should gate actions.
For example:
- guessed blocks may be copied, filtered, annotated, or inserted,
- marked blocks may support better navigation and object extraction,
- shell-authenticated blocks may unlock safer rerun/review/replay affordances,
- historical/restored blocks should visibly downgrade strong actions until fresh truth is reacquired.

## 4) Startup footing should be a first-class witness

Schell should name startup footing explicitly, for example:
- `builtin` — shell-native marking, no terminal bootstrap trick required,
- `explicit-addon` — user-installed integration package or reviewed hook,
- `compat-injected` — terminal or wrapper injected integration,
- `degraded` — command-aware luxuries unavailable,
- `unknown` — feature posture cannot be trusted.

That one witness keeps shell integration honest.
It also lets Schell remain ambitious without pretending all command-aware terminals are equally trustworthy.

## 5) Capability posture should stay separate from shell truth

Prompt-local luxuries may depend on:
- keyboard protocol upgrades,
- prompt mark support,
- semantic output zones,
- hyperlink support,
- image/media lanes,
- clipboard bridges,
- mux/SSH passthrough,
- and richer local rendering.

Schell should surface those as capability witnesses.
The shell's durable truth should still survive the fallback path.

## 6) The best first proof slice

A strong first proof does not require a final terminal architecture.
It only needs these things together:

1. one shell-authenticated prompt/input/output mark family,
2. one startup-footing witness,
3. one command chapter with trust grade,
4. one insert-first object action,
5. one review card for the stronger action,
6. one transcript-visible receipt or denial,
7. and one restored historical chapter that visibly stays weaker than live truth.

If that feels materially better than bash + terminal folklore, Schell has earned the next layer.

## 7) Decisions intentionally deferred

This surface does **not** freeze:
- one universal OSC/escape treaty,
- one final shell integration installer,
- one final block wire format,
- one final PTY replacement story,
- one final mux/SSH protocol,
- one final structured-data shell model,
- or one final startup-customization ecosystem.

The no-regret move is smaller:
**steal shell-known marks, command chapters, prompt-local luxury, typed intent routing, and rich reentry — while keeping startup footing, helper lanes, capability posture, and durable truth explicitly separate.**
