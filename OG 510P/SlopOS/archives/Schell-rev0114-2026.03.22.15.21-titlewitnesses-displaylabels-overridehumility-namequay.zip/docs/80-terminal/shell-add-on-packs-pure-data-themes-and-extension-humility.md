# Shell add-on packs, pure-data themes, and extension humility

This surface keeps one boundary explicit:
**a great shell+terminal should make prompts, themes, completions, contextual history, and helper extensions easy to add — but it should not let arbitrary startup code, per-directory hooks, version drift, or synced residue impersonate ordinary shell truth.**

Modern shell ecosystems already prove that add-ons matter.
They provide the prompt polish people love, the completions they depend on, the history search they do not want to lose, and the project-local environment behavior they keep reinstalling.
The problem is not that these ecosystems exist.
The problem is that they usually arrive through:
- sourced rc files,
- prompt-time code execution,
- cwd-triggered hook evaluation,
- loose plugin versioning,
- and history/sync behavior that becomes more powerful than it looks.

Schell can do better without choosing one final package manager, runtime, or marketplace.

## 1) Schell needs one exact add-on manifest

The first object should be an **add-on manifest**.

An add-on manifest is the shell-owned record that says what a pack is, how native it is, and what posture it needs.
A v0 manifest probably needs:
- `addon_id` — stable identity,
- `kind` — prompt / theme / completion / env_overlay / history_helper / router / query_pack / compat_bridge,
- `payload_posture` — pure_data / generated_data / code / mixed / compat_unknown,
- `startup_posture` — none / explicit_enable / cwd_review / compat_injected / unknown,
- `capability_posture` — local_ui / history_read / history_write / cwd_watch / env_overlay / network / file_read / clipboard / unknown,
- `version_posture` — schema version or protocol version,
- `sync_posture` — local_only / encrypted_sync / exportable / redacted_export / unknown,
- `claim_strength` — native_exact / compat_bridge / degraded / guessed,
- `disable_path` — exact off switch.

That is enough to make add-ons visible without locking Schell into a big package story.

## 2) Prompts and themes should begin as pure data

A native Schell prompt should be a pack of:
- semantic slots,
- layout rules,
- icon/style sets,
- show/hide conditions,
- truncation rules,
- and meaning-first theme values.

That is much better than defaulting to prompt functions that can do anything.

It is still fine to support richer computed modules later.
The key boundary is that **pure-data prompt/theme packs should be the baseline**, while code-bearing prompt helpers should be explicit add-ons with visible capability posture.

## 3) Completions should prefer generated bundles over prompt-time code

Completion ecosystems are full of value.
They are also full of hidden execution.

Schell should therefore prefer three increasing rungs:
1. **declared completions** shipped by tools,
2. **generated bundles** derived from help/man pages or prior reviewed schemas,
3. **explicit dynamic providers** only when the operator admits them.

That means the shell can be extremely helpful without making every tab press into a miniature plugin host.

## 4) Per-directory behavior should become reviewed env overlays, not generic magic

A strong Schell move is to replace the old `.envrc` feeling with an explicit **env-overlay card**.

An env-overlay card should show:
- what files or inputs are being consulted,
- what environment diff would be applied,
- what watcher set will trigger re-review,
- whether the overlay is pure data or code-bearing,
- whether it is one-shot, persistent-for-project, or denied,
- and what stronger powers it still does *not* receive.

That preserves the utility of project-local environment posture while refusing the folklore that “changing directories loads code now.”

## 5) History should become a wallet, not a pile

Schell should stop thinking of history as just a text log.
A better object is a **history wallet**.

A history wallet can say:
- what extra context is stored,
- whether command bodies are fully retained, redacted, or partially retained,
- whether sync is off, local-only, encrypted, or exportable,
- whether object cards and query decks may inspect it,
- and whether clipboard/share/export is weaker than local search.

That would make history much more powerful and much more honest.

## 6) Native code-bearing extensions should look like tools, not dotfile incantations

If Schell needs code-bearing add-ons, they should be admitted the same way good tools are admitted:
- exact identity,
- typed capability imports,
- explicit registration,
- versioned protocol posture,
- explicit disable/remove path,
- and clear separation between install, register, and enable.

That keeps the ecosystem real without reimporting rc-file mysticism.

## 7) Compatibility bridges are allowed, but they should confess what they are

Schell will almost certainly need compatibility bridges for legacy ecosystems.
That is fine.
A bridge can carry:
- a Starship prompt,
- a direnv-style env helper,
- an imported completion pack,
- a history adapter,
- or even a plugin framework bridge.

It just needs to say so.

A good compatibility badge might say:
- native exact,
- bridged from shell X,
- startup code injected,
- claim strength degraded,
- synced residue unknown,
- or version drift unverified.

That would let Schell be hospitable without lying.

## 8) Super-awesome moves worth stealing right now

### a) Pack cards
Every add-on gets a compact card:
- what it is,
- what it touches,
- what it watches,
- what it stores,
- and how to turn it off.

### b) Theme meanings instead of color guessing
Prompt/review/output chrome should target meanings first, colors second.

### c) Completion provenance pills
Show whether a completion came from:
- tool-declared schema,
- generated help/man-page bundle,
- reviewed local pack,
- dynamic provider,
- or compatibility bridge.

### d) Env-overlay diffs
Before admitting a project-local overlay, show the exact env diff and watcher set.

### e) History wallet controls
One place to set:
- retention,
- sync,
- export,
- redaction,
- and search scope.

### f) Shadow-mode add-ons
Run a native pack and a bridged legacy pack side by side in compare mode before switching defaults.
That is a brilliant way to migrate without blind trust.

### g) Claim-strength chrome
Any addon-sourced UI element should be able to say native / bridged / degraded / guessed.

## 9) Things Schell should refuse

### Refuse arbitrary rc-sourcing as the native ecosystem
Compatibility only, not the proud default.

### Refuse prompt-time invisible execution by default
A beautiful prompt is not worth invisible authority.

### Refuse code-on-cwd-entry folklore
Per-directory behavior must be reviewed as env-overlay posture, not treated as innocent path traversal.

### Refuse versionless plugin drift
Protocol and registration state must be visible.

### Refuse hidden history widening
Sync, export, and context retention must be explicit.

### Refuse assistant-suggested auto-install
Suggestions may help; installation and enablement still need explicit review.

## 10) Decision-light first proving slice

A compact proof could show:
- one pure-data prompt/theme pack,
- one completion bundle with provenance badge,
- one reviewed env-overlay card with watched inputs,
- one contextual history wallet with local-only versus encrypted-sync posture,
- one versioned code-bearing extension import with explicit capability wallet,
- one compatibility bridge card for a legacy prompt or env helper,
- and one refusal case where a pack asks for more startup or history reach than its class allows.

That is enough to make Schell feel seriously modern without freezing one final extension runtime, prompt language, sync backend, or package registry.
