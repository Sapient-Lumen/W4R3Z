# Repo accelerators, trust leases, and hook quarantine

This surface keeps one boundary explicit:
**let projects contribute brilliant local shell+terminal help, but do not let repo-local hooks, command packs, or plugin-like helpers become ambient execution policy.**

Schell is going to want project-aware luxury:
- repo-local workflow seeds,
- command examples,
- completion enrichers,
- glossary/help packs,
- validator hints,
- environment/ground suggestions,
- semantic object rules,
- and maybe even local guardrail or review helpers.

Those can make the custom shell+terminal feel dramatically better.
They are also one of the oldest ways shells stop feeling trustworthy.

## Why this surface exists

A modern operator surface increasingly lives near executable customization:
- shell hooks,
- workspace settings,
- checked-in tasks,
- plugin hooks,
- agent hooks,
- environment activators,
- and searchable runbooks.

The trap is obvious once named:
- open a repo,
- see a helpful prompt,
- and forget that local project bytes are now shaping execution behavior.

Schell should resist that pattern early.

## The compact answer: repo accelerator packs

A useful small object here is **repo accelerator pack**.

A repo accelerator pack is a source-labeled bundle of local shell+terminal smartness.
It is **not** automatically a plugin system.
It is **not** automatically a code execution grant.
It is a compact object the shell+terminal can point at when it says:
“this project is offering help, and here is exactly how trusted that help currently is.”

A v0 pack probably needs:
- `pack_ref` — exact digest / identity,
- `source_family` — repo-local / imported / shared / plugin / restored,
- `basis_ref` — path + digest or another exact approval basis,
- `offered_lanes[]` — workflow seeds / completions / glossary / validators / env hints / object rules / ranking data,
- `effect_floor` — inspect-only / proposal-only / veto-only / stronger lane if ever admitted,
- `trust_state` — quarantined / inspectable / leased / changed / revoked / expired,
- `lease_ref` — optional local trust lease,
- `reauthorize_on_change` — whether changed basis revokes the lease,
- `provenance_ref` — optional signer / sharer / importer witness,
- `freshness_posture` — current / historical / restored / imported / unknown,
- `notes_ref` — optional explanation card.

That is enough to make repo-local smartness real without freezing a final marketplace, package manager, or signature model.

## 1) Default posture should be visible before active

A repo accelerator pack should be allowed to be:
- discovered,
- browsed,
- searched,
- and previewed

before it is active.

That means Schell can do something delightful on repo entry:
show a compact project-help card with:
- available workflow seeds,
- available completions/help packs,
- current trust posture,
- changed-since-last-lease hints,
- and the next safe actions.

The crucial rule is that visibility is not activation.

## 2) Trust should be a lease, not a vibe

If the operator wants a pack to shape local behavior, Schell should prefer a **trust lease**.

A trust lease says, roughly:
- which exact pack basis is being trusted,
- on whose machine/account,
- for which offered lanes,
- with what expiry or revocation posture,
- and whether changed bytes automatically revoke it.

That is much better than the old story where a folder quietly becomes trusted because it was opened once.

## 3) Reauthorize on change is one of the best ideas to steal

A very strong no-regret rule is:
**if the repo accelerator basis changes, the prior trust lease should not float forward silently.**

At minimum, changed bytes should downgrade the pack to:
- changed,
- held,
- inspectable,
- or proposal-only until reauthorized.

This is one of the clearest ways Schell can avoid the historical shell mistake where yesterday's trust silently applies to today's different project state.

## 4) “Trust for delight, not for power” is a good v0 policy

A leased repo pack can still stay weaker than execution authority.
That is probably the right first move.

Examples of what a leased pack may do in v0:
- add searchable workflow seeds,
- contribute completion or help rows,
- improve ranking or labels,
- surface validator warnings,
- attach glossary/help cards,
- or narrow choices in a picker.

Examples of what it should *not* silently do by default:
- run on prompt entry,
- mutate the execution ground invisibly,
- install hidden wrappers around commands,
- widen strong action families,
- or cause folder-open to become code-execution time.

That is why proposal-only and veto-only are such useful safe floors.

## 5) Insert-first and edit-before-run should be the main luxury path

The best place for repo-local intelligence is often the current input editor.
A great Schell move is:
- search a repo-local runbook or workflow seed,
- insert it into the active prompt,
- mark the inserted parameter regions,
- show short provenance/trust badges,
- and let the operator edit before review or execution.

That preserves delight while keeping execution explicit.

## 6) Hook quarantine should stay a separate lane

Some local project helpers really will want executable hooks.
Schell does not have to ban that possibility forever.
It should refuse to normalize it too early.

A useful early split is:
- **repo accelerator pack** — local smartness for suggestions, ranking, display, workflow summon, and veto-only checks,
- **hook lane** — separately named, separately reviewed, and clearly stronger if executable lifecycle hooks are ever admitted.

That keeps “help from the repo” from collapsing into “the repo now runs code whenever the shell blinks.”

## 7) Historical, imported, and shared packs should stay visibly weaker

A pack can arrive from many places:
- checked into the current repo,
- imported from another machine,
- shared by a teammate,
- restored from a previous session,
- or bundled by a plugin.

Those origins matter.
Schell should keep them visible because they shape how much the operator should trust the pack and what action families it may unlock.

In particular:
- imported/shared/restored packs should be easy to inspect,
- easy to diff against the current repo state,
- and low on the action ladder until freshly leased.

## 8) Transcript truth should mention pack influence when it matters

The transcript does not need every ranking tweak.
It does need to say when a strong visible result materially depended on a repo accelerator pack.

Useful witness lines could be:
- workflow seed inserted from leased pack `X`,
- validator veto came from local pack `Y`,
- suggestion ranking influenced by pack `Z`,
- or changed pack basis downgraded leased help to inspect-only.

That keeps repo-local intelligence from disappearing into folklore.

## 9) Brilliant ideas worth stealing without freezing too much

A few particularly good moves look decision-light right now:

### a) Repo entry card
A small card when entering a project that says:
- what packs were detected,
- which are quarantined,
- which are leased,
- what changed since last lease,
- and what safe help lanes are available.

### b) Shadow mode for untrusted packs
Let an untrusted pack show what it *would* have suggested without activating it.
That lets operators evaluate usefulness before granting a lease.

### c) Trust strip beside the prompt
A tiny badge or strip for the active repo pack posture:
- no pack,
- pack available,
- leased,
- changed,
- revoked,
- or historical.

### d) Influence badges on results
When a picker row or help card was shaped by a repo pack, say so.
Not with giant prose.
Just enough that the operator can tell shell-native truth from project-local help.

### e) Lease-scope controls
Allow narrow trust such as:
- workflow seeds only,
- completions/help only,
- ranking only,
- veto-only validators,
- but not executable hooks.

That is a very Schell-like way to be powerful without overcommitting.

## 10) No-regret first specimen set

A first specimen set could stay small:

1. one repo entry card with a detected but quarantined pack,
2. one explicit inspect-and-lease flow for workflow seeds only,
3. one changed-basis downgrade that revokes the old lease,
4. one inserted workflow seed with provenance/trust badges,
5. one leased validator that can veto or warn but not run side effects,
6. one imported/shared pack that remains historical until freshly leased,
7. and one transcript slice showing pack influence plus one reauthorization-on-change witness.

That is enough to learn a lot without freezing:
- a final plugin system,
- a final package/signature format,
- a marketplace,
- or a universal lifecycle-hook architecture.
