# Guest witnesses, share ladders, and co-drive humility

This surface names a terminal seam that current tools still flatten too often:
**Schell should become excellent at getting help, pairing, teaching, and debugging through shared terminal context, but it should do that by separating live observation, writable co-drive, browser join, service sharing, transcript export, and evidence bundles, because those are different operator moves and should stop borrowing one flattering “share terminal” button.**

SlopOS already teaches the right discipline here.
Transfer is explicit.
Receipts bind approvals to exact routes.
Capability references are explicit restore material, not ambient presence.
Observation export stays weaker than current live-state truth.
That is exactly the right import pressure for Schell while both datacubes are still design-phase.

## 1) Shared terminal presence deserves first-class shell truth

Classic shells and terminal multiplexers usually treat collaboration as folklore:
- give someone SSH,
- share a tmux session,
- paste a relay URL,
- maybe make it read-only,
- maybe expose a browser view,
- maybe forward a local service too,
- and maybe later send a transcript or support bundle.

Those are not the same thing.
A custom shell+terminal can do much better by naming share posture directly.

## 2) Preserve share role before rendering convenience

A Schell guest witness should probably keep a compact set of exact facts first.
For example:
- `guest_role` — `observer` / `annotator` / `request-driver` / `granted-driver` / `evidence-recipient`
- `share_subject` — current prompt lease / current pane / command chapter / transcript slice / service witness / crash bundle
- `transport_kind` — local pair / direct peer / relay / browser bridge / imported replay
- `identity_posture` — local-trusted / approved-signed / approved-anonymous / imported-link / historical-share
- `control_scope` — none / current prompt only / current pane only / current shell session / explicit service card only
- `secret_posture` — unreviewed-visible / review-gated / redacted-export / unknown
- `revocation_posture` — host-can-stop / lease-expiring / one-shot / historical-only

That is enough to make collaboration much more honest without freezing a final sync backend.

## 3) One compact share ladder would already feel luxurious

Schell does not need full multiplayer architecture first.
A compact ladder would already beat the old world:

1. **Share evidence** — send a transcript slice, chapter bundle, or crash/evidence bundle.
2. **Share live read-only** — let someone watch the current prompt or pane.
3. **Share annotation** — let them place notes, marks, or suggestion cards without typing in the TTY.
4. **Request keyboard** — let a guest ask for one explicit driving lease.
5. **Grant co-drive** — grant write access for one prompt, one pane, or one bounded session.
6. **Share service/object separately** — share a local service card, object card, or crash capsule without assuming the guest needs shell control.

That is the key no-regret move here.
The shell can become unusually good at help and pairing without turning collaboration into ambient host authority.

## 4) Read-only, co-drive, and browser join should stay separately named

A particularly dangerous old habit is flattening collaboration into one invitation string.
Schell should resist that.

At minimum, different share families should stay separate:
- **readonly live share** — guest watches output only
- **annotation share** — guest can mark or suggest without terminal input
- **prompt-drive lease** — guest may edit/type only into the current prompt lease
- **pane-drive lease** — guest may type into one bounded pane
- **service share** — guest opens a forwarded/local service in a browser
- **evidence export** — guest receives transcript/replay/crash bundle only
- **historical replay share** — guest sees restored/historical material, not current live truth

Those may all appear near the same surface, but the operator should never have to guess which power is being granted.

## 5) “Pass keyboard” is a better default than ambient co-typing

One genuinely brilliant move worth stealing is not full multiplayer typing.
It is **keyboard passing**.

Instead of treating all writable shared terminals as one big co-typing plane, Schell can make the common help/debugging path feel better by default:
- host keeps the live prompt lease,
- guest can request control,
- host grants a bounded drive lease,
- authorship on the resulting chapter stays explicit,
- and the lease expires or can be revoked without tearing down the whole share.

That is much closer to the real operator need during debugging and teaching.
It is also much easier to keep honest than “anyone in the session can type whenever.”

## 6) Guest-side side effects should not be smuggled in

Shared sessions often grow adjacent powers by accident:
- open this URL on the guest,
- auto-open this forwarded service in a browser,
- copy this credential or connection string,
- follow me into this pane,
- or join via a relay the host picked.

Schell should keep those as separate reviewed actions.
A collaboration invite should not silently carry guest-browser launch, guest clipboard writes, or implicit service exposure just because those are convenient.

## 7) Evidence sharing should often beat live sharing

One of the best lessons from the wider tool ecosystem is that many help/debugging workflows do **not** need full live shell access.
Often the right move is:
- a transcript chapter,
- a scrubbed replay bundle,
- a crash capsule,
- a command chapter with env/peer witnesses,
- or a service witness card.

Schell should make those easy enough that “share the whole terminal” stops being the first instinct.

## 8) A narrow v0 is enough

Schell can start very small here:
- one guest-witness family,
- one share ladder,
- one explicit split between observe / annotate / request-drive / granted-drive / export-evidence,
- one rule that browser open, service share, and guest-side side effects are separate approvals,
- and one requirement that restored or imported shares stay visibly historical until live truth is reacquired.

That is already enough to make the shell+terminal materially better for help, teaching, pair debugging, and incident response without forcing a final collaboration backend, relay design, cursor/presence model, or multiplayer editing architecture.
