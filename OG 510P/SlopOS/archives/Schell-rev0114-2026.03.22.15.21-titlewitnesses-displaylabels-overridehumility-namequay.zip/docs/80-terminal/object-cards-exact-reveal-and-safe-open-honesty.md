# Object cards, exact reveal, and safe-open honesty

This surface records another low-regret move for Schell:
**make visible objects dramatically easier to inspect and route while refusing to let clicks, previews, or helper guesses impersonate current authority.**

The point is not to build a file manager inside the terminal first.
The point is to give the shell+terminal a much better answer to:
- “what is this path or URL, exactly,”
- “show me the exact thing without widening,”
- “open this safely because I do not trust it yet,”
- and “use this object in the next command without launching anything.”

## Core idea

Schell should probably distinguish at least six nearby things:

- **object ref** — one exact visible path / URL / artifact ref / line-target ref,
- **object card** — a compact typed card bound to that exact ref,
- **inspect** — metadata-safe detail on the object and route options,
- **reveal** — exact show/select in a local containing context,
- **open** — ordinary handler/editor/viewer launch,
- **safe-open** — inert or quarantined bounded handling for suspicious/imported objects.

Those are related.
They are not the same action.

## 1) Object cards should preserve exact resolution context

A visible object card should not be just a pretty hover.
It should bind the detected object to the exact context that made it meaningful.

A compact v0 object card could preserve:
- `object_card_id`,
- `subject_kind` — path / dir / url / artifact_ref / line_target / markdown / suspicious_import,
- `exact_ref`,
- `resolver_basis` — chapter / cwd / peer / ground / output-range witness,
- `sensitivity_posture`,
- `openability_posture`,
- `safe_open_hint?`,
- `allowed_actions[]`,
- `liveness_hint?`,
- and `recent_hint?`.

Important posture:
- an object card is **routing and staging help**,
- not proof the object still exists,
- not proof a helper is available,
- and not permission to open it again without review.

## 2) Inspect should be metadata-safe by default

A good first inspect surface should prefer:
- exact ref text,
- object kind,
- cwd/peer/ground witness,
- local-vs-remote posture,
- sensitivity/quarantine hints,
- and the available action ladder.

It should not assume ambiently safe access to:
- file snippets,
- rendered thumbnails,
- markdown bodies,
- remote fetches,
- or active-content parsing.

That default keeps inspection useful without turning hover into hidden preview.

## 3) Reveal should mean exact reveal

Exact reveal is a wonderful operator affordance.
But Schell should say what it means.

`reveal` should mean something like:
- show the containing local context,
- select or spotlight the exact target if the platform can do so,
- and otherwise hold or deny rather than silently opening “something nearby” and pretending success.

That matters because these are different meanings:
- reveal exact item,
- open containing folder,
- open the object,
- or search for something like it.

Schell should keep them separate.

## 4) Open should stay an explicit helper-routed action

Ordinary open is still valuable.
A custom shell+terminal should be great at it.

But `open` should remain explicit about at least:
- local vs remote target posture,
- file vs folder vs URL,
- ordinary handler vs editor vs in-terminal viewer,
- and whether the action is request-local or likely to reuse an existing session/profile.

The main rule is simple:
**clickability should not hide helper choice or browsing-state reuse.**

## 5) Safe-open should be a separately named downgrade path

One of the nicest improvements Schell could make is to stop forcing operators to choose between:
- “open it normally and hope,”
- and “drop to the OS and figure out a sandbox myself.”

A visible suspicious object card should be able to offer:
- **safe-open**,
- with a clearly different badge,
- clearly different outcome posture,
- and clearly different residue expectations.

The key rule is:
**safe-open should not be a hidden variant of open.**
If it matters, say it.

## 6) Insert is often better than open

Legacy terminals push too hard toward launch.
Often the operator really wants:
- insert quoted path into active input,
- attach exact object ref for help,
- copy normalized ref,
- or derive the next command.

That is where kitty-style selection and insert flows are such a good clue.
For many objects, the best default action is staging, not opening.

## 7) Recent and pinned object cues should stay weaker than handles

A smart shell+terminal should absolutely remember useful objects.
But recent use should stay:
- clearable,
- descriptive,
- and weaker than an explicit current handle.

A recent object card may help you find the thing again.
It should not count as:
- durable reopen authority,
- proof the helper still exists,
- or proof the old context still matches.

## 8) Good first action ladder

A good v0 ladder might be:
- **inspect**,
- **reveal exact item**,
- **open containing place**,
- **insert into active input**,
- **attach for help**,
- **open normally**,
- **safe-open instead**,
- **request stronger action**.

Different object kinds can expose different subsets.
The important part is that the ladder remains explicit.

## 9) Things Schell should steal now

### Working-directory-aware resolution

Object detection should bind against exact chapter/ground truth, not only regex folklore.

### Exact reveal/select when possible

Showing the exact item in context is a better affordance than generic “open nearby.”

### Insert-path and insert-object actions

Often the safest and fastest move is to land the object back into input.

### Safe-open as a named action

This gives Schell a much more humane answer for suspicious or imported things.

### Local viewer posture with explicit boundaries

Markdown/image/report viewers can be great so long as they do not pretend to be harmless or universal.

## 10) Things Schell should refuse

### Refuse click-equals-open

Detection is not consent.

### Refuse reveal-equals-browse-nearby

Exact reveal and approximate browse are different actions.

### Refuse ambient hover preview for risky objects

Especially for suspicious/imported things, hover should not become secret object handling.

### Refuse safe-open as branding only

If the posture is different, the object card and transcript should say so.

### Refuse one giant object browser first

One object-card family, one resolver witness, one reveal ladder, and one safe-open downgrade are enough to learn a lot.

## 11) No-regret first specimen set

A compact first cut could show:
1. one path in command output resolved into an exact object card,
2. one URL object card with open-vs-copy-vs-attach actions,
3. one local file with an exact reveal action that holds when the backend cannot faithfully select it,
4. one suspicious/imported object that defaults toward safe-open,
5. one action that inserts a quoted path into active input instead of opening,
6. one metadata-safe inspect pane,
7. and one transcript slice showing inspect vs reveal vs open vs safe-open honesty.

That is enough to make Schell feel substantially more awesome around visible objects without freezing preview engines, helper inventories, sandbox backends, or a full document browser architecture.
