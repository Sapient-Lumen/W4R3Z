# Room roles, authorship chips, and audience-truth humility

This surface exists to keep one especially tempting collaboration myth honest:
**Schell should become excellent at paired terminal work, teaching, debugging, and selective publication — but it should do that by separating room identity, participant identity, chapter authorship, live audience, and published audience, because “someone joined the terminal” is not one fact.**

The point is not to avoid social terminal features.
The point is to keep them legible enough that the shell still knows what happened.
A custom shell+terminal can be genuinely better than current tools here if it refuses to let room presence blur into authorship, blur into approval, or blur into publication.

## 1) Keep the room smaller than the people and the people smaller than the chapters

At minimum Schell should separate:
- **room** — a live or historical collaboration container,
- **participant** — one host/guest/viewer/controller identity with a join-proof posture,
- **writer token** — current right to inject input into one prompt, pane, or room,
- **chapter authorship** — who actually typed or approved a command chapter,
- **live audience** — who could currently observe,
- **published audience** — who can access a shared artifact,
- **adjacent powers** — file transfer, forwarded service reachability, crypto delegation, clipboard/host effects,
- **artifact lineage** — clips, exports, embeds, or historical replays derived from the room.

These objects are adjacent.
They are not interchangeable.

## 2) A room card should describe real footing

A healthy room card should carry compact truth such as:
- `room_posture` — live / restored / imported / historical-only,
- `join_method` — approved roster / link token / browser bridge / terminal attach / imported artifact,
- `identity_posture` — host-local / approved-signed / approved-anonymous / unknown-link-holder / historical,
- `writer_mode` — none / request-drive / leased-writer / exclusive-writer / ambient-cotype,
- `audience_scope` — current roster only / team-scoped / link-scoped / public artifact,
- `adjacent_powers` — tty-view / tty-input / file-xfer / service-open / crypto-bridge / publish,
- `publication_posture` — none / local-only / link-shared / embeddable / unknown,
- `revocation_posture` — host-can-stop / lease-expiring / artifact-unpublish / downstream-copies-unknown.

That already gives Schell much more honest collaboration footing without freezing a final backend.

## 3) Participant cards should be first-class, not implied by transport

A participant card should probably say at least:
- host,
- approved signed guest,
- approved anonymous guest,
- imported link holder,
- historical viewer,
- or delegated helper.

It should also show the powers actually granted:
- observe output,
- request control,
- hold writer token,
- receive selected artifact,
- transfer files,
- or open a forwarded service.

That keeps “connected somehow” from becoming the whole story.

## 4) Authorship chips should live on chapters, not on room folklore

The room is not the author.
The chapter is where authorship matters.

A Schell chapter should be able to say things like:
- typed by host,
- typed by guest while holding writer token,
- approved by host after guest proposal,
- imported from historical artifact,
- or unknown byte provenance.

That is the right place to keep social truth.
A room with five participants does not prove that all five authored or even saw a given command chapter.

## 5) Writer tokens beat ambient co-typing most of the time

One of the most stealable ideas from older and newer tooling is to separate presence from write turns.
Schell does not need to default to everyone typing at once.
A better default is:
- everyone can observe,
- someone can request drive,
- the host grants a writer token,
- the resulting chapter records token holder and approval posture,
- and the token can expire or be revoked without destroying the room.

That is more humane for teaching, pair debugging, incident response, and review than permanent ambient co-typing.

## 6) Adjacent powers should sit beside the room, not disappear inside it

Current tools repeatedly widen collaboration in adjacent ways:
- file transfer rides alongside terminal access,
- a shared local service appears on the guest as localhost,
- publication produces persistent links or embeds,
- helper lanes can open browsers or move artifacts,
- and remote/key bridges may accompany the room.

Schell should make those powers explicit on the room card.
The participant should not have to guess whether “joined room” also means “can upload files”, “can hit the local database”, or “can republish this chapter.”

## 7) Live audience and published audience should never collapse into one badge

A live room roster and a published artifact audience are different things.
So Schell should separate:
- **live audience** — who can currently observe the room,
- **artifact audience** — who can access an exported chapter/block/replay,
- **selected included parts** — command/output/prompt/annotations/metadata,
- **unpublish posture** — closed lane / revoked link / downstream copies unknown.

That prevents “we shared a block” from pretending to say who is currently in the room.

## 8) Presence is weaker than view receipts unless explicitly proven

One of the biggest collaboration lies in software is pretending that presence means consumption.
Schell should refuse that.
A room card may show that someone joined or remained present.
That should remain weaker than:
- explicit read receipt,
- explicit ack,
- explicit approval,
- or explicit authorship.

Otherwise the room will start overclaiming social truth.

## 9) Restoration and reattach need visible historical posture

Room comfort often depends on persistence.
That is useful.
It also means old room identity can linger.
So restored or reattached rooms should stay visibly badged as:
- restored,
- reattached,
- audience rederived,
- authorship continuous only where witnessed,
- or room handle reused but participant roster refreshed.

Historical continuity is valuable.
It is not free truth.

## 10) A strong first proving slice

A compact first specimen should show:
1. one host-only room card,
2. one approved signed guest card,
3. one approved anonymous guest card,
4. one writer-token request and grant,
5. one chapter authored by host,
6. one chapter authored by guest under explicit writer token,
7. one room with file-transfer lane present but terminal input denied,
8. one shared-service lane present while terminal access stays read-only,
9. one published chapter artifact accessible to anyone with the link,
10. one reattached room badge that keeps historical posture visible,
11. and one refusal to treat roster presence as proof that a participant saw or approved a consequential chapter.

That is already enough to make Schell feel unusually capable without freezing the final relay, roster, publication, or identity stack.

## 11) Things to refuse for now

Refuse for now:
- one generic “share terminal” verb that hides room, participant, authorship, and publication differences,
- room tokens or links acting as strong participant identity by default,
- room presence acting as proof of view or approval,
- chapter authorship being inferred from room membership alone,
- and adjacent powers being silently smuggled in with a room invite.

The right law is:
**steal social-terminal luxury, but keep room truth, participant truth, chapter truth, and audience truth separately named.**
