# Remote hops, peer witnesses, and attach honesty

This surface records a new no-regret candidate cluster for Schell:
**the integrated shell+terminal should treat remote lanes as explicit domains with peer witnesses, attach/resume posture, and borrowed-local-authority summaries, so remote work can feel fantastic without hiding who the peer is or what local power the remote lane can currently borrow.**

The design pressure comes from three directions:

- SlopOS keeps request identity, live state, continuity, and authority transfer on separate seams instead of letting session folklore do hidden work.
- DelayBasin keeps demanding public witnesses for what is really known now, what is only a continuation, and what has not yet been re-witnessed.
- Current terminal and remote-dev tools keep adding brilliant SSH/mux/roaming comfort, but they repeatedly blur fresh connect, reused attach, server install, forwarding, and provisional local prediction.

## 1) Schell should name remote domain kind explicitly

A first remote ladder could include:
- **local** — ordinary local shell truth,
- **ssh-direct** — one direct SSH peer,
- **ssh-mux-attach** — attached via a reused SSH or remote multiplexer path,
- **remote-server** — a local UI attached to a remote helper/server process,
- **roaming-provisional** — a remote lane with prediction or continuity beyond exact round-trip truth,
- **restored-remote** — a historical remote lane reopened without fresh peer witness yet,
- **unknown-remote** — visible remote-ish material without enough exact hop truth for strong actions.

This is a better answer than one “remote” icon.

## 2) Peer identity should become one compact witness packet

A good first **peer witness** packet could include:
- `domain_kind`,
- `display_name`,
- `route_basis` — direct / jump / mux-attach / restored / resumed / unknown,
- `peer_basis_kind` — host-key / server-key / attestation / alias-only / none,
- `peer_basis_digest_or_ref` — optional exact witness,
- `hop_chain_ref` — optional bounded hop witness,
- `feature_posture` — shell integration / terminfo fallback / bootstrap helper / degraded,
- `borrowed_local_authority_ref` — optional summary strip,
- `freshness_posture` — fresh / stale / restored / provisional.

That is enough to support excellent UI without freezing the transport.

## 3) Connect, attach, resume, and restore should not blur together

Schell should keep four distinct stories visible:
- **connect** — a fresh peer witness was obtained,
- **attach** — a local UI attached to an already-running remote session or server,
- **resume** — continuity survived interruption or roaming,
- **restore** — a historical local view reopened before current peer truth returned.

These are all valuable.
They are just not the same truth.

A reattached lane may inherit useful continuity.
It should not automatically inherit all strong remote actions unless the current peer witness and execution ground still match.

## 4) Borrowed local authority needs its own strip

Remote lanes often borrow local power.
A compact **borrowed-local-authority** strip could summarize whether the remote lane can currently reach:
- local auth-agent operations,
- local forwarded sockets,
- local editor/open/reveal bridges,
- local clipboard or host-effect mediation,
- local terminal remote-control bridge,
- local file-transfer bridge,
- local notification or focus-steering helpers.

This strip should stay descriptive.
But it should be hard to miss.

## 5) Bootstrap helpers should stay explicit posture

Remote comfort helpers are worth stealing:
- remote terminfo/bootstrap install,
- remote shell-integration setup,
- remote helper/server install,
- connection reuse,
- cwd-carry and feature negotiation.

The SlopOS-compatible answer is not “never do that.”
It is:
- **say when it happened**,
- **say what exact helper class is active**,
- and **do not let bootstrap posture silently become trusted identity or authority proof**.

## 6) Nested hops should degrade exactness instead of bluffing

One hop is often knowable.
Nested hops are frequently only partly knowable.
Schell should keep that honest.

A good rule is:
- if the terminal only knows the first hop, say so,
- if the active subject may be behind another shell hop, keep strong file/open/reveal/attach actions downgraded,
- and if exact downstream peer witness becomes available later, upgrade explicitly rather than silently.

This is a better operator experience than magical confidence followed by wrong-host action.

## 7) Predictive local echo is worth stealing, but it should stay visibly provisional

Roaming/predictive transport ideas are genuinely excellent.
They can make remote interaction feel fast and humane on poor links.

Schell should feel free to adopt a small **provisional local echo** family later.
But the rule should be simple:
- locally predicted text is not exact remote witness yet,
- outstanding prediction should be visible,
- and final command/output truth still comes from the shell-owned remote witness path.

## 8) Trusted chrome still matters more on remote lanes

The trusted-chrome ratchet becomes even more important once the peer is remote.
If a remote lane can borrow local authority or ask for a strong local action, the final approval surface should land in trusted local chrome, not inside the remote PTY stream.

That gives Schell a very clean story:
- the remote shell tells the terminal what it knows,
- the local host renders that beautifully,
- and final local authority-bearing review stays in a visibly separate trusted lane.

## 9) Transcript witnesses should preserve remote honesty

A transcript slice should be able to say at least:
- what remote domain kind was active,
- whether the lane was fresh / attached / resumed / restored,
- what peer-basis strength was present,
- whether borrowed-local authority was active,
- and whether a strong action downgraded because peer truth or hop truth was insufficient.

That keeps remote sessions useful later without mythologizing them.

## 10) A strong v0 cluster is small

A decision-light v0 cluster is probably enough:
- one remote-domain-kind ladder,
- one peer-witness packet,
- one attach/resume/restore honesty ladder,
- one borrowed-local-authority strip,
- one hop-uncertainty downgrade rule,
- one provisional-local-echo badge,
- and one transcript-visible remote witness summary.

## 11) Decisions intentionally kept open

This surface does **not** freeze:
- one final remote transport,
- one SSH-specific identity model,
- one jump-host or bastion graph,
- one attestation scheme,
- one server-install model,
- one clipboard/file bridge policy,
- or one exact merger of SSH, mosh, mux daemons, and future SlopOS-native remoting.

The no-regret move is narrower:
**make remote truth, continuity posture, and borrowed-local authority explicit before Schell teaches operators to trust remote convenience blindly.**
