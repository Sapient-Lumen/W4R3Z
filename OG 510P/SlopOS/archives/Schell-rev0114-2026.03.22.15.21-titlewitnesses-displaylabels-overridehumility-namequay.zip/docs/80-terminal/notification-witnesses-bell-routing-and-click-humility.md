# Notification witnesses, bell routing, and click humility

This surface names another place where a custom shell+terminal can become much more humane **without** freezing too much too early:
**bells, finish notices, desktop notifications, urgency badges, and progress pings can be delightful, but they should stay weaker than durable results, fresh review, and explicit authority.**

The current terminal ecosystem is better than old terminal folklore at this seam.
It also makes the fragmentation impossible to ignore.
Some products treat `BEL` as a configurable attention request.
Some support command-finished notifications tied to focus and duration.
Some support OSC-driven desktop notifications or progress bars.
Some let notification clicks re-focus the terminal or send an escape back to the program.
That is all useful.
It is also exactly where nearby convenience can quietly impersonate approval, durable completion truth, or portable protocol consensus.

## 1) Attention cues, command truth, and click actions are different lanes

A shell+terminal should keep at least five different stories apart:
- **attention cue** — bell, badge, toast, bounce, flash, urgency hint,
- **command-bound watch** — "alert when this command chapter ends" or "tell me when this shelf item needs input",
- **durable outcome** — exact exit/result/receipt state that survives after the cue vanishes,
- **notification transport** — `BEL`, OSC 9, OSC 777, OSC 99, shell integration marks, or local helper bridging,
- **notification action** — focus, jump, reveal, copy, re-open review, or a stronger action that still needs fresh review.

Old shells often flatten all of this into one vague feeling: "the terminal let me know something happened."
Schell should refuse that blur.
A notification can request attention.
It should not by itself prove completion, widen authority, or silently spend power.

## 2) `BEL` is not one thing anymore

The terminal bell used to mean "ring a noise."
Current terminals openly show that it is now a small routing surface.
Depending on local policy, a bell may:
- make a sound,
- flash or mark a window,
- request compositor/taskbar attention,
- show a desktop notification,
- or do nothing.

That means Schell should treat a bell as an **attention request**, not as a durable result object.
A bell witness can still be useful.
It can say:
- who emitted it,
- which command chapter or pane it came from,
- whether it was routed to sound / badge / desktop notification / nothing,
- whether focus suppression changed delivery,
- and whether the originating command already has a stronger durable result card.

## 3) Command-finished alerts are great when they stay chapter-bound

One of the nicest steals in the current ecosystem is the command-bound finish alert.
This is much better than a session-global “notify me about everything” toggle.

A good shell+terminal should support things like:
- alert on the **next command chapter**,
- alert when this **background shelf item** reaches a terminal state,
- alert when this **live task** needs input,
- alert when this **remote watch** changes posture,
- and suppress or downshift those cues when the originating surface is still focused.

That stays beautifully compatible with Schell’s existing chapter / shelf / review story.
It also keeps the architecture small.
The shell does not need a giant durable notification center to learn from this.
It only needs an explicit witness for how transient attention relates to stronger truth.

## 4) Notification protocols are useful, but visibly fragmented

Current terminals do **not** agree on one universal notification protocol.
Nearby products expose different wire surfaces:
- `BEL` attention behavior,
- OSC 9 body-only notifications,
- OSC 777 title/body notifications,
- OSC 99 desktop notifications,
- OSC `9;4` progress bars,
- shell-integration marks that local UI can watch,
- and product-local finish-notice settings.

Schell should import the right lesson:
**steal the behaviors, not the premature standardization claim.**

That means the shell+terminal can happily model:
- `cue_kind` — bell / badge / toast / progress / finish-watch / blocked-input / unknown,
- `transport_family` — local-bell / osc9 / osc777 / osc99 / mark-watch / helper-local / unknown,
- `origin_strength` — shell-authenticated-command / shell-authenticated-pane / helper-proxy / terminal-local / unknown,
- `focus_posture` — focused / same-tab / same-window / unfocused / detached / unknown,
- `delivery_posture` — delivered / suppressed / coalesced / downgraded / denied / unknown,
- `action_posture` — none / focus-only / reveal-only / jump-only / review-required / helper-callback / unknown,
- `result_binding` — no-result / weakly-bound / chapter-bound / task-bound / receipt-bound / unknown.

That is enough witness structure to keep the seam honest without picking one final wire protocol today.

## 5) Clicks and actions must degrade into reveal and review first

This is the safety line that matters most.
A notification click can be delightful.
It can also become a hidden approval bypass.

The safest default ladder is:
1. focus or reveal the originating pane/tab/window,
2. jump to the command chapter or task shelf item,
3. show exact exit/result/receipt posture,
4. offer stronger next actions only through the same review gates Schell would use in-band.

That keeps a clicked toast weaker than fresh review.
It also matches SlopOS’s larger lesson that attention authority and action authority should stay distinct.

## 6) Progress and blocked-input cues deserve separate meaning

A terminal that only has "bell" and "done" is too small for modern work.
Current systems already hint at a better split:
- command finished,
- command still running but needs a password,
- progress available,
- bell with no stronger meaning,
- update available,
- or generic urgency.

Schell should therefore keep:
- **completion cue**,
- **blocked-input cue**,
- **progress cue**,
- **generic attention cue**,
- and **durable result state**

separately named instead of laundering them into one generic notification family.

## 7) The nicest steals are concrete and low-commitment

### a) Alert-on-next-command watch objects
Bind the watch to one exact command chapter or task shelf item.

### b) Focus-aware suppression with visible reason
Say whether the cue was shown, suppressed, or downshifted because the origin was focused.

### c) Notification source badges
Say whether the cue came from a shell-authenticated chapter, a terminal-local bell, a helper bridge, or a best-effort OSC import.

### d) Progress pills and blocked-input chips
Separate "still running with progress" from "waiting on you" from "finished."

### e) Click ladders that prefer reveal over execute
Focus, jump, reveal, and review before stronger action.

### f) Exact durable result cards that outlive the cue
The toast can vanish.
The result should remain.

## 8) This seam is smaller than a final notification architecture

None of this requires Schell to choose:
- one final cross-terminal notification protocol,
- one durable inbox/history product,
- one sync story,
- one action callback model,
- one progress bar transport,
- or one platform-specific notification daemon treaty.

It only requires a bounded rule:
**treat bells, toasts, progress pings, and finish notices as explicit notification witnesses so attention luxury can land without transient cues or clicked actions impersonating durable shell truth or fresh approval.**

## 9) Compact conclusion

One of the smartest design-phase-safe moves available right now is:
**give Schell a notification-witness family so command-finish alerts, blocked-input reminders, progress pings, and desktop notifications can feel first-class while staying weaker than exact results, receipts, and reviewed actions.**
