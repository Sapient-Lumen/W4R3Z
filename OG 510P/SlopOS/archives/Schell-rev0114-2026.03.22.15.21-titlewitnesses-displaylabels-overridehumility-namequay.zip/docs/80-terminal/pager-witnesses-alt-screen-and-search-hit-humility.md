# Pager witnesses, alt-screen, and search-hit humility

**Schell should absolutely steal searchable scrollback, prompt/mark jumps, command-output paging, scrollbar marks, and great pager ergonomics — but it must not let live screen state, alt-screen residue, scrollback hits, pager views, and durable command truth collapse into one flattering “I can find it again, therefore I know exactly what it is” story.**

## 1) Why this seam matters

A super-awesome shell+terminal wins a lot of love the moment users can:
- search old output quickly,
- jump between prompts and command outputs,
- open large results in a pager,
- keep a few important marks on a scrollbar,
- and revisit interesting lines without re-running work.

But the same seam goes wrong fast.
Search hits start pretending to be exact objects.
Paged output starts pretending to be the durable source of truth.
Alternate-screen content starts pretending to be ordinary scrollback.
And “I can reopen it in a pager” quietly becomes “this is the authoritative basis for a stronger action.”

Schell should learn the opposite lesson.
It should make review dramatically better while keeping **live screen**, **scrollback buffer**, **pager view**, **search hit**, **mark**, **command chapter**, and **durable receipt/capsule** as separately named things.

## 2) The current ecosystem proves that search and scrollback are worth stealing

The outside world is now converging on this comfort layer.

- **WezTerm** documents a searchable scrollback buffer with a configurable maximum size.
- **Ghostty 1.3** now ships terminal scrollback search and native scrollbars for navigating it.
- **Windows Terminal** documents search over the terminal text buffer and directional search through that buffer.

That is enough evidence that Schell should not remain “just raw scrolling plus copy.”
It should have first-class search and reentry.

But notice what these tools are actually searching: a **text buffer** or **scrollback buffer**.
That is a strong clue for Schell.
A search hit is a hit in a source buffer, not automatically a durable command object, a live process, or a safe rerun basis.

## 3) Prompt marks and command-output paging are worth stealing too

Modern terminals are also converging on command-aware reentry:

- **kitty** can jump to previous/next prompts, open the last command output in a pager, and search scrollback in a pager.
- **Windows Terminal** now supports adding scroll marks, scrolling to marks, auto-marking prompts, and showing marks on the scrollbar.
- **iTerm2** uses shell integration plus captured-output tooling to find important lines and scroll to reveal them again.

These are terrific ideas for Schell.
But the right import is not “everything is a block now.”
The right import is:
- **mark cards**,
- **search-hit cards**,
- **chapter/output references**,
- and **reveal-before-strong-action** discipline.

A mark is a navigation aid.
A search hit is a query result.
A captured-output row is a derived index entry.
A pager view is a derivative reading surface.
None of those should silently outrank an exact command chapter or exact output capsule if Schell has one.

## 4) Alternate screen is not just more scrollback

This is where the historical lesson gets especially sharp.

- **Windows Console VT docs** say the alternate screen buffer is exactly the dimensions of the window and has **no scrollback region**.
- **iTerm2** makes saving lines to scrollback in alternate-screen mode an **option**.
- **kitty** says its scroll actions only take effect in the main screen; in the alternate screen, those keys are passed to the running program instead.
- kitty’s 2026 changelog even notes it now avoids rewrapping text in the alternate screen buffer during live resize.

That combination is a warning sign.
The alternate screen is not one universal truth surface.
It is an interactive display mode whose relation to scrollback is terminal-specific and sometimes configurable.

So Schell should treat:
- **main-screen scrollback**,
- **alt-screen live state**,
- **alt-screen captured residue**,
- and **paged historical output**

as distinct view families.

If a full-screen program exits and Schell still has something to show, that should carry posture like:
- `alt-live`,
- `alt-captured`,
- `scrollback-derived`,
- `pager-derived`,
- or `exact-output-capsule`.

## 5) A pager is a second workflow, not harmless decoration

Terminals keep teaching the same lesson about pagers.
`less` is brilliant because it can start reading before the whole input is available and works across many terminals.
But systemd’s docs also warn that common pagers like `less` can open or create files and run subprocesses, so when privileged commands are involved the pager itself becomes a **security boundary**.
Those docs describe secure mode via `LESSSECURE=1`, and they also explain why systemd often sets the `X` behavior so output remains visible after the pager exits even though some functionality is lost.

That matters a lot for Schell.
A pager is not merely “another way to scroll.”
It is a second interactive workflow with its own affordances, exits, and sometimes its own risk posture.

So Schell should name **pager witnesses** explicitly:
- what source was opened,
- whether it was exact or derived,
- whether it is secure/degraded/untrusted,
- whether it still tracks live output,
- and whether actions inside it are read-only or can launch stronger flows.

## 6) What Schell should now do

This pass points to a compact, high-value answer.

### A. Add **pager witnesses**
Every paged view should know:
- `source_kind` — scrollback / exact command output / stderr-only capsule / transcript / alt-captured / imported text,
- `source_strength` — exact / shell-attested / mark-derived / search-derived / historical / unknown,
- `view_posture` — read-only / secure / degraded / live-follow / frozen,
- `exit_posture` — close returns to prior view / leaves output visible / restored historical pager.

### B. Add **search-hit cards**
Each hit should keep:
- query text,
- source buffer or object,
- whether the hit is in main scrollback, alt-captured residue, transcript, or exact chapter/output,
- and the strongest safe next action.

Likely actions:
- jump to source,
- reveal enclosing chapter,
- open exact output in pager,
- copy excerpt,
- export exact source,
- or refuse stronger action until exact promotion happens.

### C. Add **alt-screen posture badges**
Schell should clearly distinguish:
- `main-screen`,
- `alt-live`,
- `alt-captured`,
- `alt-not-captured`,
- `alt-resize-derived`,
- and `alt-historical`.

### D. Keep **marks weaker than exact chapters**
Prompt marks, scrollbar marks, and captured-output rows are excellent navigation surfaces.
They should remain weaker than exact command chapters and exact output capsules.

### E. Add a **secure pager lane** for elevated or sensitive output
When the source is privileged, secret-bearing, or trusted-review-adjacent, Schell should be willing to say:
- read-only pager only,
- secure pager features restricted,
- export disabled by default,
- or “open exact capsule in secure review lane instead.”

## 7) Super-awesome moves worth stealing

The nicest current ideas to steal without overcommitting are:
- searchable scrollback,
- prompt/command mark jumps,
- command-output-in-pager actions,
- scrollbar marks,
- captured-output side decks,
- pager-open on exact stderr or exact output capsule,
- and query results that can reopen an exact source when one exists.

The especially good Schell twist would be:
- **search-hit cards** that confess their source,
- **pager cards** that confess whether they are exact or derived,
- **alt-screen badges** that confess whether capture happened at all,
- and **exact-source promotion rails** before stronger reuse/export/open actions.

## 8) Decisions intentionally kept open

This pass does **not** freeze:
- one final pager implementation,
- one final alt-screen capture policy,
- one final scrollback storage model,
- one final mark/search index backend,
- one final pager security policy,
- or one final reentry/search UI.

The no-regret move is smaller:
**let Schell become excellent at searching, marking, paging, and reentering terminal history — but keep search hits, marks, pager views, alternate-screen residue, and exact durable command/output truth separately named.**
