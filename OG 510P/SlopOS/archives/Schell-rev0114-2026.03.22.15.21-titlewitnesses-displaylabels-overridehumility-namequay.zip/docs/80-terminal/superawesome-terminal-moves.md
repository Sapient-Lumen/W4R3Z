# Superawesome terminal moves

This surface records ambitious terminal ideas that still look compatible with Schell's explicit-review posture.
These are candidates, not commitments.

## 1) Review cards, not just prompts

Effectful actions should render as cards with:

- exact artifact or descriptor identity,
- exact mutable basis when relevant,
- intended action,
- narrow authority request,
- expiry / one-shot / durable grant posture,
- expected receipt shape,
- and one obvious approve / deny / narrow-further path.

## 2) Receipt shelf and denial shelf

The terminal should make recent receipts and denials navigable objects, not dead scrollback.
A user should be able to jump to:

- last reviewed action,
- last denial,
- last receipt,
- last exported artifact,
- and last background-state change.

## 3) Background shelf instead of `jobs`

Background state should look like a shelf of live grants with:

- request id,
- requested state,
- live-grant truth,
- TTL,
- renew / revoke,
- autostart posture,
- and what changed since the last review.

## 4) Prompt-aware cursor and selection affordances

When the terminal knows where the prompt and editable input are, it can:

- move the cursor by click only where safe,
- select exact command blocks,
- keep complex prompts visually stable,
- and avoid confusing previous output for current input.

## 5) Trusted command blocks

Not every visible block should authorize the same actions.
Candidate trust grades:

- guessed,
- marked,
- shell-authenticated.

That lets Schell separate safe copy/select actions from stronger rerun/attach/replay actions.

## 6) Exact artifact previews

Artifact refs, receipts, digests, and small structured outputs should support inline preview without confusing the preview for authority.
Preview is observational, not a hidden reopen.

## 7) Split transport from luxury UX

The semantic protocol should stay small enough to survive plain terminals and logs.
Richer local affordances like cards, panes, images, mode tables, and graph views should layer on top without becoming correctness dependencies.

## 8) Make non-effectful work feel fast

The review ceremony must be concentrated where effects or authority matter.
Observational commands, search, history, navigation, and preview should feel very fast.

## 9) Operator memory aids

A strong custom terminal can make continuity much better by keeping visible:

- current focus artifact,
- current lease set,
- current replay target,
- current open review,
- current question or experiment being pressured,
- and the currently active trust grade for the visible block.

That would make the terminal feel like an operator cockpit rather than just a byte pump.

## 10) Design/debug mode for the shell itself

Because Schell is still being invented, the custom terminal should probably support a design/debug lane that can show:

- which question entry the current prototype is meant to pressure,
- what proof surface is being exercised,
- what receipts/denials were just generated,
- whether the current block is guessed or shell-authenticated,
- and whether the prototype is still operating inside the intended reversible scope.

## 11) Readonly replay mode

A replay or postmortem view should be able to stay visibly live-looking while refusing to send input to the running substrate.
That makes receipts and past reviewed actions safer to inspect.

## 12) Threshold-based command-finish notifications

For long-running work, the terminal should be able to notify only when:

- the command crossed a duration threshold,
- the window is unfocused,
- or the operator explicitly asked to watch that reviewed action.

## 13) Mode tables for review and navigation

Key-table or mode-table behavior looks promising for:

- review mode,
- receipt/denial navigation,
- background shelf navigation,
- and transcript/debug inspection.

## 14) Semantic inspector mode

A custom shell+terminal can become much more trustworthy if it has an optional inspector overlay that shows:

- prompt/input/output boundaries,
- trust grade,
- confidence grade,
- linked receipt or denial ids,
- linked artifact refs,
- and any detected basis drift.

That would make the terminal teach its own honesty model.

## 15) Basis-drift alarms

If a visible affordance used to point at one exact basis but the basis has since changed, the terminal should say so plainly and offer the nearest safe alternative rather than silently following the new state.

## 16) Counterfactual sidecar for blocked actions

DelayBasin suggests a particularly nice operator move: when Schell refuses a rerun/reopen/attach action because trust is weak or basis drifted, show the nearby rejected action and why it was not admitted.

## 17) Reentry landing card

After reopen, restore, or long absence, Schell should be able to show a compact landing card with:

- where you are,
- what is still live,
- what is only historical,
- what changed while you were away,
- and what surfaces are trustworthy first.

## 18) Scoped work lanes

A truly great custom shell+terminal should help the operator see whether something belongs to:

- direct terminal work,
- agent/proposal work,
- receipt/denial history,
- workflow artifacts,
- or background residue.

That would make search and navigation much more powerful without erasing authorship or live-state honesty.

## 19) Workflow seeds instead of alias folklore

Repeated commands should be able to become named, parameterized, searchable workflow seeds.
That gives Schell a better reuse story than startup aliases while keeping provenance and trust visible.

## 20) Authority strip and wallet digest

A super awesome shell+terminal should make current authority visible in a tiny descriptive strip with:

- wallet digest or short id,
- widening/drift state,
- active lease hints,
- and one obvious path to inspect the exact diff when power is changing.

## 21) Exact authority diff cards

When power is widening, the terminal should show the exact diff object, not only a prose warning.

## 22) Direct-exec versus shell-eval as named modes

The shell+terminal should make it obvious whether something is being executed directly or through shell parsing/expansion.
Heuristics can help, but they should not be the only story.


## 23) Intent packets and explain-this-click cards

A super awesome shell+terminal should be able to turn visible selections, hyperlinks, command regions, and receipts into explicit intent packets that say:

- what exact subject was selected,
- what action class is being requested,
- whether the route is local, mediated, review-only, or proposal-only,
- and why a stronger nearby action was refused.

That would make “smart clicks” much more trustworthy than legacy open/run folklore.


## 24) Command chapters and source-labeled journals

A super awesome shell+terminal should let operators browse exact recent command chapters with source, lane, peer, ground, and outcome badges instead of one flat history list.

## 25) Quick summon chapter browser

A drop-down or quick-terminal style observational browser for recent chapters looks worth stealing because it can make search, attach-for-help, and insert-only recall extremely fast without claiming durable shell truth.


## 26) Object cards and safe-open ladders

A super awesome shell+terminal should make visible paths, URLs, directories, and artifact refs feel typed and exact, with:

- working-directory-aware resolution,
- exact reveal when the platform can faithfully select the object,
- insert-into-input as a first-class alternative to launch,
- one clearly badged safe-open path for suspicious objects,
- and metadata-safe inspect panes that do not silently turn hover into object handling.
