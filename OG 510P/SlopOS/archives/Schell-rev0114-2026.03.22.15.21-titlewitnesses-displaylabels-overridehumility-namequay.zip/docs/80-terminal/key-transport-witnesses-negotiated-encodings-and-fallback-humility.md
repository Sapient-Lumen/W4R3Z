# Key transport witnesses, negotiated encodings, and fallback humility

This surface exists to keep one increasingly important shell myth honest:
**Schell should absolutely steal richer keyboard handling, layout-aware shortcut matching, release/repeat events, and terminal/editor comfort — but it should do so by keeping text input, key-event transport, negotiated mode, hop translation, and later reviewed action separately named.**

That is the smaller discipline that lets a shell+terminal feel dramatically better than legacy shells without quietly depending on invisible protocol luck.

## 1) Why this surface exists

The archive already has:
- keymap witnesses,
- input-authorship and prediction witnesses,
- completion witnesses,
- capability-ground cards,
- integration witnesses,
- and active-input leases.

But one seam was still undernamed:
**what exact keyboard/input transport footing is in effect when the operator presses a key?**

That matters because current shell+terminal comfort increasingly depends on:
- enhanced modified-key reporting,
- layout-aware shortcut matching,
- repeat/release events,
- shell-authenticated prompt clicks,
- terminal-local key tables,
- mux translation,
- remote hops,
- and platform-local input paths.

Without an explicit witness split, “the shortcut worked” becomes a flattering but mushy story.

## 2) Keep these truths distinct

At minimum Schell should treat these as different objects:

1. **input intent** — text entry, non-text navigation key, modifier-only change, click gesture, or unknown
2. **transport encoding** — legacy bytes, modified-key escape, progressive keyboard protocol event, platform-local event, or unknown
3. **negotiated mode** — default, requested, accepted, forced, helper-bridged, or unknown
4. **hop posture** — native, mux-translated, remote-forwarded, compatibility-adapted, or fallback
5. **binding consumer** — terminal-local action, shell editor, application, or mixed
6. **buffer/editor effect** — text insertion, cursor motion, menu action, suggestion acceptance, or none
7. **reviewed action** — the later stronger object the operator explicitly reviews or runs

These truths are adjacent.
They are not interchangeable.

## 3) A key-transport witness should name encoding family, granularity, and hop posture

A key-transport witness should probably be able to say at least:
- `input_kind` — text / non-text / mixed / modifier-only / click / unknown
- `transport_family` — legacy / xterm-modifyOtherKeys / csi-u / kitty / win32-input / native-gui / unknown
- `negotiation_posture` — default / requested / accepted / forced / helper-bridged / unknown
- `event_granularity` — press-only / press+repeat / press+repeat+release / all-keys / unknown
- `layout_posture` — text-only / shifted-aware / base-layout-aware / ime-preedit / unknown
- `hop_posture` — native / mux-translated / remote-forwarded / conpty-adapted / compatibility-fallback / unknown
- `binding_consumer` — terminal-local / shell-editor / application / mixed / unknown
- `recovery_posture` — reset-safe / partially-reset-safe / helper-dependent / unknown
- `trust_posture` — native / adapted / imported / fallback / unknown

This does not require one final protocol.
It only requires Schell to stop pretending every working shortcut has the same truth story.

## 4) Text insertion and non-text key events should stay separately named

One of the easiest ways to make a shell/editor lie is to collapse text and key events together.
Schell should keep at least these distinctions visible:
- text that should land in the buffer,
- non-text navigation/edit keys,
- modifiers used for shortcut matching,
- and layout-aware alternate/base-key evidence used only for interpretation.

That protects prompt editing, menu navigation, and workflow shortcuts from turning into hidden parser or input folklore.

## 5) Negotiation should be a ladder, not a hidden leap

The current ecosystem strongly suggests the right construction order:
1. default legacy behavior first,
2. explicit request for richer reporting second,
3. explicit acceptance or downgrade third,
4. visible hop/adapter confession fourth,
5. recovery-safe fallback always available.

This is not just protocol tidiness.
It is how Schell avoids waking up with invisible keyboard mode dependence spread across prompt, completion, help, editor widgets, and workflow launchers.

## 6) Recovery posture matters because broken input state is not theoretical

Key-transport luxury should never make recovery mysterious.
A humane shell+terminal should be able to answer:
- can the operator still recover with plain legacy keys,
- does `reset` or a similar clear-mode path work natively,
- is recovery helper-dependent,
- and did a remote hop or mux force a weaker footing?

A key-transport witness should therefore make recovery posture visible rather than leaving it as terminal folklore.

## 7) Mux and remote hops deserve explicit downgrade honesty

Even when the local terminal is rich, the actual path may include:
- tmux or another multiplexer,
- ssh or a helper-wrapped remote path,
- conpty or platform-local translation,
- or compatibility fallback chosen by the host or terminal.

So Schell should be able to say:
- native enhanced mode,
- mux accepted and translated,
- remote forwarded and partially degraded,
- helper projected,
- or plain legacy fallback.

That one strip would explain a lot of otherwise spooky UX.

## 8) Terminal-local shortcuts should stay weaker than shell/editor meaning

A terminal may legitimately intercept keys for:
- split management,
- quick terminal summon,
- copy/search UI,
- secure-input toggles,
- or command palette actions.

Those are useful.
But they are terminal-local actions, not shell meaning.
Schell should keep terminal-local actions visibly distinct from shell/editor bindings and from later reviewed execution.

## 9) Layout-aware shortcut matching is worth stealing, but it should stay explicit

Modern systems increasingly need to cope with:
- shifted-versus-base key identity,
- non-US layouts,
- IME/preedit paths,
- platform-specific modifier sets,
- and application shortcut matching that should not depend only on visible text.

Schell should absolutely steal better shortcut matching.
But it should do so by naming which evidence it used:
- visible text,
- unshifted/base key,
- shifted key,
- layout-normalized key,
- or terminal-local special key.

## 10) First specimen set this surface wants

A good first proof set would show:
1. one card explaining why a modified shortcut works locally,
2. one compare card showing native local mode versus mux/remote downgraded mode,
3. one visible split between text insertion and non-text key-event handling,
4. one shortcut explanation that names visible-text versus base-layout matching,
5. one terminal-local shortcut badge that clearly does not claim shell meaning,
6. one recovery card showing whether reset/mode-clear is native or helper-dependent,
7. one support bundle export that preserves the key-transport witness instead of only the visible symptom,
8. one refusal to let hidden helper forcing pose as native keyboard truth,
9. and one refusal to let a terminal-local action pose as shell-reviewed execution.

## 11) What to refuse for now

Refuse for now:
- one undifferentiated “keyboard support” claim,
- invisible forcing of an enhanced key mode with no visible acceptance or downgrade,
- helper-installed keyboard luxury posing as native shell footing,
- terminal-local key actions posing as shell/editor meaning,
- text input and non-text key events collapsed into one event story,
- and layout-aware shortcut matching that leaves no explanation trail.

## 12) Bounded conclusion

One of the safest ways to make Schell feel much more capable than legacy shells is also one of the clearest:

**treat keyboard/input transport as a witnessed compatibility layer.**
The shortcuts can be richer.
The editor can be smarter.
The prompt can be more interactive.
But the transport footing still needs a name.

That is enough to steal a lot of brilliance without freezing the architecture too early.
