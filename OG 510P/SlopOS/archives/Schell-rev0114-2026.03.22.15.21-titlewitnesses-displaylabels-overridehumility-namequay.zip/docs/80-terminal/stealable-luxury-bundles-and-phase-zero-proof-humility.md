# Stealable luxury bundles and phase-zero proof humility

This surface exists for one reason:
Schell already has a lot of interesting terminal ideas, but a new shell+terminal can still fail by collecting clever features one by one until the feature pile quietly chooses the architecture.

The safer move is to group the best steals into **small luxury bundles**.
A bundle is strong enough to feel magical to an operator, but still bounded enough that we can prove it without freezing the final parser, transport, renderer, or plugin story.

## 1) Bundle-first design law

A feature is worth pursuing early only if it improves one of these directly:
- exact review truth,
- insert-versus-run honesty,
- denial clarity,
- recovery speed,
- transcript usefulness,
- or humane command-local navigation.

A feature should be held if it silently chooses any of these too early:
- one final shell language shape,
- one final shell↔terminal protocol,
- one final PTY/session semantics story,
- one final structured pipeline ontology,
- or one final extension ecosystem.

## 2) Bundle A — command chapters, marks, and sticky navigation

This is probably the highest-value first bundle.
The shell emits exact command boundaries.
The terminal turns them into:
- marks,
- jump previous/next command,
- sticky command headers,
- command guide rails,
- output-in-pager,
- and recent-command recall tied to command chapters.

Why this bundle is good:
- it makes long sessions dramatically easier to navigate,
- it preserves transcript truth,
- it does not require a final parser rewrite,
- and it teaches the shell/terminal boundary in a way users can feel immediately.

What to refuse here:
- command boundaries inferred only from heuristics,
- sticky headers becoming the only retained truth,
- or marks silently implying replay authority.

## 3) Bundle B — insert-first help and review-first correction

This bundle gathers the best humane ideas from fish, completion systems, and command-aware quick fixes.

Candidate moves:
- autosuggestions,
- rich completion rows with descriptions and origins,
- focused parameter help,
- output-derived quick-fix cards,
- “write into input” without running,
- and explicit review before any strong follow-on action.

Why this bundle is good:
- it makes the shell feel generous and fast,
- it improves novice and expert flow,
- and it does not require the terminal to become a secret second shell.

What to refuse here:
- hidden execution from suggestion acceptance,
- ambient install/correction logic,
- or output scanning that silently upgrades into mutation authority.

## 4) Bundle C — object cards and plumber-style routes

This bundle is where Schell can feel wildly better than a plain terminal without pretending selection is execution.

The move:
- visible files, URLs, ports, errors, receipts, and handles become typed object cards,
- cards expose explicit actions such as inspect, reveal, insert, open, safe-open, repair, or share,
- and routes stay explicit enough that reveal/open/fix/share do not collapse into one flattering click.

Why this bundle is good:
- it makes terminals feel like they understand what the operator is looking at,
- it scales across files, services, links, and receipts,
- and it gives Schell one obvious place to hang exact witnesses and route rationale.

What to refuse here:
- one giant router architecture too early,
- hover that fetches or mutates behind the scenes,
- or browser/file-manager/editor side effects hidden inside selection.

## 5) Bundle D — structured receipts and denial inspectors

Schell should not decide yet that the shell itself is “structured data all the way down.”
But it should absolutely make receipts, denials, and nearby effect summaries richer.

This bundle means:
- receipts with exact action, basis, and outcome,
- denials with narrow repair posture,
- object metadata for export or replay-readonly,
- and structured effect summaries that can be inspected without collapsing ordinary textual output.

Why this bundle is good:
- it improves trust,
- it supports automation and collaboration later,
- and it keeps high-value structure where the truth burden is highest.

What to refuse here:
- turning every pipeline into tables before earning it,
- or assuming structured output is the same thing as humane terminal UX.

## 6) Bundle E — upgraded input and explicit capability posture

A super-awesome shell+terminal eventually wants better input semantics.
It may want key tables, upgraded keyboard protocols, better selection semantics, and grapheme-aware movement.

The no-regret move is:
- treat those as capability witnesses,
- make downgrade visible,
- and keep a transcript-safe baseline path.

That allows Schell to support dramatic local improvements without letting one renderer or terminal brand become the hidden baseline truth.

## 7) Bundle F — strict-safe review for ambiguous text

Authority-bearing text, suspicious Unicode, mixed-script confusables, and width disagreement deserve a stricter review lane.
This bundle gathers:
- exact-byte reveal,
- display-label versus exact-identifier split,
- confusable/bidi badges,
- grapheme-aware selection,
- and explicit width/renderer humility.

This is not a global anti-Unicode posture.
It is a trust-preserving lane for the moments that matter.

## 8) The best phase-zero proving slice

The strongest near-term proving slice is not “build all bundles.”
It is probably these three together:

### Phase-zero slice
1. **Command chapters + marks**
2. **Insert-first help**
3. **Structured receipts/denials**

That slice proves:
- the shell can emit durable truth,
- the terminal can make that truth delightful,
- and help can stay helpful without becoming hidden authority.

Then Schell can add:
- object routing,
- upgraded input,
- and stricter Unicode review,
- once the first proof feels genuinely better than bash/zsh/fish on real operator work.

## 9) What not to decide yet

Do not decide yet:
- one final shell language compatibility story,
- one final rich graphics/media protocol,
- one final remote attach/resume treaty,
- one final extension/plugin sandbox,
- one final browser/open ecosystem,
- or one final fully structured data shell model.

Those may all matter later.
They do not need to be decided to make the first Schell experience obviously excellent.

## 10) Specimen debt

A future specimen set should show:
- one long session with sticky command chapters and exact jumps,
- one suggestion row that inserts but does not run,
- one quick-fix card that remains proposal-only,
- one object card with separate inspect/reveal/open actions,
- one receipt inspector with exact basis,
- one capability downgrade badge for absent input upgrades,
- and one strict-safe-review toggle for ambiguous text.

If Schell can make those feel coherent, the project will already feel like a custom shell+terminal rather than a pile of terminal tricks.
