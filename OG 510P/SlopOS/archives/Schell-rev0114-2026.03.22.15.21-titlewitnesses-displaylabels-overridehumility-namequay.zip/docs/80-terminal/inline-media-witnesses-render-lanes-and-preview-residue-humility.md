# Inline media witnesses, render lanes, and preview-residue humility

This surface keeps one boundary explicit:
**a great shell+terminal should be able to show images, plots, PDFs, visual diffs, and other rich media inline, but it should not let renderer-local pixels become shell truth, transcript requirements, or a hidden durable preview/history system.**

Modern terminals increasingly support richer local rendering:
- inline images,
- graphics protocols,
- protocol-specific plot and image viewers,
- scrollback-integrated media,
- and shell-aware context that can make visual objects easier to find and reopen.

Those are genuinely exciting.
They are also an easy way to overreach:
- terminal escape output starts masquerading as durable artifact truth,
- preview becomes a stealth parser/runtime,
- mux or SSH breakage turns luxury rendering into correctness bugs,
- and restored thumbnails or cached derivatives start looking like live current objects.

SlopOS is already drawing a very helpful line around preview, materialization, and viewer residue.
Schell should import that lesson before “super awesome inline media” chooses too much architecture too early.

## Why this surface exists

There are at least six distinct things the shell+terminal can do with a visual object:
1. notice that one exists,
2. describe it,
3. render it locally,
4. open it in a stronger viewer,
5. materialize or export bytes,
6. or keep enough residue to make later rendering fast.

History says systems love to flatten those into one friendly preview story.
That is exactly the mistake to avoid.

An inline image or plot in terminal output may come from very different bases:
- a shell-known object ref,
- a bounded output range tied to one command chapter,
- a local file/path contextualized by cwd,
- a remote object whose bytes are not local,
- a restored preview cache,
- or an imported/historical derivative.

Those origins matter.
They should stay visible.

## The compact answer: media witnesses and viewlets

A useful small object here is **media witness**.

A media witness is not the whole graphics stack.
It is a compact Schell object that says:
“there is a visual thing here, here is the exact object/output basis for it, and here is which actions stay weak versus strong.”

A local rendered presentation of that witness can be called a **viewlet**.
A viewlet is deliberately weaker than open, materialize, export, or share.
It is a renderer-local convenience surface.

A v0 media witness probably needs:
- `subject_ref` — exact object ref, chapter output ref, or bounded path/object basis,
- `media_kind` — image / plot / pdf-page / svg / waveform / video-thumb / diff-thumb / unknown,
- `source_family` — shell-object / chapter-output / contextual-path / restored-cache / imported / unknown,
- `render_posture` — text-stub / inline-viewlet / inspect-pane / open-viewer / safe-open,
- `residue_posture` — transient-local / restored / historical / imported / unknown,
- `portability_posture` — text-safe / protocol-gated / local-only / unknown,
- `freshness_posture` — current / restored / historical / repaired / unknown,
- `safety_posture` — ordinary / uncertain / quarantined / safe-open-only,
- `notes_ref` — optional object card / inspect card / explanation.

That is enough to power humane visual UX without freezing one graphics protocol, cache format, or media runtime.

## 1) Shell truth should stay object-first and transcript-safe

The shell does not need to “own pixels.”
What it should own is the exact thing the pixels came from:
- an object ref,
- a bounded output witness,
- a chapter-local artifact,
- or another explicit subject.

The terminal can then render a local viewlet when possible.
But the durable truth should remain:
- what object/output was referenced,
- what command chapter produced it,
- what exact basis still matches,
- and what stronger actions remain available.

That keeps the rich renderer exciting without making it the authority surface.

## 2) Render should stay distinct from open, safe-open, materialize, and share

A common failure mode is flattening all visual interaction into one preview/open gesture.
Schell should refuse that.

A strong v0 ladder is:
- **inspect metadata**,
- **render inline viewlet**,
- **expand inspect pane**,
- **open viewer**,
- **safe-open viewer**,
- **materialize/export/share**.

That ladder matters because the same “show me something visual” desire may imply very different safety, residue, and portability consequences.

## 3) Transcripts, SSH, mux, and headless use need text-safe stubs

The terminal ecosystem is already telling us that graphics are real but fragmented.
Some terminals support kitty graphics, some support the iTerm2 image protocol, some support both, and mux/replay/SSH paths still have seams.

That means Schell should preserve one text-safe fallback.
A transcript-safe stub might carry:
- subject kind,
- dimensions or page count when known,
- digest or object ref,
- render posture,
- and whether the inline viewlet was current or restored.

The operator then still has truthful evidence when pixels are unavailable.

## 4) Preview residue should stay weak, local, and obviously historical when restored

One of the best imports from SlopOS is that merely viewing something should not quietly create a stronger persistence lane.

For Schell, that means viewlet residue should default to:
- transient local cache,
- renderer-local and revocable,
- weaker than durable recents or reopen authority,
- and visibly historical when restored after relaunch.

Restored pixels may still be useful.
They just should not pretend to be fresh object truth.

## 5) Risky or uncertain objects should not auto-render on hover, selection, or top-hit UI

The custom terminal will increasingly have discovery surfaces:
- object cards,
- command decks,
- quick-open rows,
- chapter search,
- and maybe later richer shelves.

Those surfaces should not become ambient preview channels for risky bytes.
For uncertain or quarantined objects, richer rendering should remain:
- exact-handle targeted,
- explicitly requested,
- and clearly weaker than export/keep/open.

That rule prevents a lot of accidental parser exposure and fake familiarity.

## 6) Protocol support should be progressive enhancement, not the core contract

Schell can absolutely steal from kitty graphics, iTerm2 inline images, and compatible renderers.
But it should steal them as **local render lanes**.

The durable contract should stay smaller:
- object/output witness,
- render hint,
- transcript stub,
- residue posture,
- and explicit stronger actions.

That leaves the archive free to defer:
- the first graphics protocol,
- the fallback chain,
- the mux story,
- the remote streaming story,
- and the renderer sandbox story.

## 7) Good “super awesome” ideas that still stay decision-light

### a) Object-bound viewlets
Commands that produce image-like or plot-like artifacts can emit exact object refs plus a render hint.
The terminal may show a small inline viewlet without pretending the viewlet is the artifact.

### b) Compare viewlets
Visual diffs are one of the best reasons to have richer rendering at all.
A compare card can show two exact object refs with a tiny local diff/thumbnail view while keeping open/export separate.

### c) Chapter-local media shelves
A command chapter can remember that it had a visual artifact and let the operator jump back to the object or rerender the viewlet later.
The shelf stays a convenience layer, not reopen authority.

### d) Expand-in-place inspect panes
Small inline media can expand into a richer inspect pane while staying obviously local and weaker than viewer-open.

### e) Restored-but-historical viewlets
After relaunch, restored visual caches can still help orientation, but they should wear `restored` / `historical` posture until rerendered from current basis.

### f) Text-first durability
Every inline media affordance should have one obvious text-safe representation so logs, replay, SSH, and plain terminals do not lose the plot.

## 8) The no-regret move

The best move right now is not to freeze a media protocol stack.
It is to pin one rule:
**inline media in Schell should become explicit media witnesses before it becomes renderer-local luxury, and renderer-local luxury should stay weaker than open/materialize/share truth.**

That keeps the path open for excellent visual UX while leaving big decisions unfrozen:
- no final graphics protocol commitment,
- no final preview-cache model,
- no final mux/SSH transport strategy,
- no final viewer sandbox architecture,
- and no final remote rendering story.

## 9) Sources worth stealing from

- kitty graphics protocol for serious inline raster rendering integrated with text
- iTerm2 inline images and file-transfer-over-terminal ideas
- WezTerm's protocol reuse plus explicit mux caveats
- Ghostty's support for graphics as progressive capability for terminal applications
- desktop preview systems like Quick Look and Windows preview handlers as reminders that preview is a real boundary, not harmless decoration
