# Selection packets, primary targets, and action ladders

This surface records a new no-regret candidate cluster for Schell:
**treat visible selection as explicit packets with bounded action ladders, while keeping one separate primary-target truth for the current live lane.**

The design pressure comes from three directions:

- SlopOS keeps warning that exact target selection, exact action meaning, and fail-closed refusal of approximate fallback matter more than smooth-looking nearby behavior.
- DelayBasin keeps urging bounded object promotion, public hold cards, and explicit non-movement when a visible thing has not earned a stronger action.
- Current terminals show that semantic zones, hints, prompt-local click/edit, and context-aware open are magical when they do not blur into hidden authority.

## 1) Selection should become an object, not just a highlight

Schell should have one small family of **selection packets** for visible things.
Examples:

- active prompt text,
- semantic input/output regions,
- path-like snippets,
- URI/hyperlink objects,
- receipt cards,
- review or hold cards,
- workflow artifacts,
- and later maybe agent-only blocks.

A packet does not need a giant schema at first.
A small first cut could keep:

- selection kind,
- selection bounds,
- trust grade,
- liveness/posture,
- lane / origin,
- context witness (cwd, authorship, basis, block id when known),
- and allowed action families.

This is a no-regret move because it makes visible interaction richer without freezing pointer semantics, menu design, or renderer architecture.

## 2) One primary target should stay separate from passive selection

Schell should distinguish two truths:

- **primary target** — the current live object that strong keyboard actions route to,
- **selection packet** — the thing the user is currently highlighting, hovering, or browsing.

Important posture:

- selecting a historical object should not automatically steal the primary-target role,
- selecting inside the active prompt may coincide with the primary target, but that should stay visible,
- and “the thing under the pointer” should not silently become “the thing rerun applies to.”

This is one of the simplest ways to avoid recreating old terminal ambiguity in a shinier shell.

## 3) Selection kind should shape the action ladder

Not every visible object deserves the same verbs.
The first cut should stay small and explicit.

Candidate ladder families:

### Active-prompt selection

- copy,
- cut,
- edit,
- quote-insert,
- workflow insert,
- inspect hidden structure.

### Path/URI selection

- copy,
- insert,
- quote-insert,
- open,
- inspect,
- import.

### Shell-authenticated command-block selection

- copy,
- inspect,
- attach receipt,
- compare basis,
- propose rerun.

### Historical/restored object selection

- inspect,
- cite,
- reopen context,
- derive proposal,
- hold if strong action is requested.

The key idea is not the exact verbs.
It is that verbs should be keyed by **what the object is** and **how much the system really knows**.

## 4) Active prompt gets the fastest, narrowest path

The active prompt/input field should feel like a real editable field.
That means prompt-safe click-to-move, direct selection edits, and quick insertion of workflows or selected paths.

But that privilege should stay narrow.
Historical output, receipts, and restored objects can still be richly selectable without pretending they are part of the same editable surface.

This is exactly the kind of humane asymmetry that makes a custom shell+terminal better than legacy terminals without widening authority.

## 5) Semantic-zone selection is worth stealing aggressively

Complete command/input/output region selection is a very good idea.
It lets users quickly:

- copy one command with or without output,
- attach a precise region as context,
- inspect one exact outcome,
- or derive a workflow/proposal from a bounded region.

Schell should prefer shell-authenticated semantic zones when available.
Guessed regions can still exist, but they should be marked as guessed and should usually get a smaller action ladder.

## 6) Approximate open or rerun should fail closed into a hold card

One of the easiest places to lie is selection-based action.
The system sees something path-like or command-like and does “whatever seems nearby.”
Schell should resist that.

Good hold-card cases:

- path selected, but cwd witness is missing or stale,
- command block selected, but only heuristic boundaries are known,
- restored object selected, but no live basis exists,
- URI selected, but the requested open mode exceeds the generic open seam,
- workflow-like text selected, but no authorship or basis packet exists.

A compact hold card can say:

- what was selected,
- what the system actually knows,
- why the stronger action is blocked,
- and what exact next move would upgrade the posture.

## 7) Unified discovery should preserve origin and scope

A single palette/search system can still be honest.
Search results should preserve:

- lane,
- selection kind,
- trust/liveness badges,
- authorship badge when relevant,
- and allowed actions.

That way a palette can span active commands, receipts, workflows, restored panes, and agent-only objects without flattening them into one action story.

## 8) Transcript truth still matters here too

The text transcript should be able to preserve the important part of a selection event:

- what kind of object was selected,
- whether it was live, restored, historical, guessed, or shell-authenticated,
- what action family was invoked,
- and whether a hold card or exact action followed.

The transcript should not pretend more than that.
It should not imply that selection alone conferred authority.

## 9) No-regret first cut

A first specimen set could stay small:

1. one active-prompt selection/edit specimen,
2. one semantic-zone selection specimen,
3. one path-selection open/import specimen,
4. one historical-block selection that downgrades to inspect-only,
5. one ambiguous-open hold card,
6. and one transcript witness for all of the above.

That is enough to learn a lot without freezing palette architecture, pointer semantics, or a full selection algebra.
