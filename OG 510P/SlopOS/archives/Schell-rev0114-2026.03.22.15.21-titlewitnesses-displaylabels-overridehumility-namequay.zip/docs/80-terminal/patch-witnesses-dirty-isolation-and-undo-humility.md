# Patch witnesses, dirty isolation, and undo humility

This surface exists to keep one especially tempting luxury bundle honest:
**Schell should absolutely steal diff/patch review, selective hunk acceptance, disposable worktrees, and convenient rewinds — but it must not let edit comfort blur proposal, application, current tree truth, or what “undo” actually means.**

The point is not to avoid patch luxury.
The point is to keep it legible.
A shell+terminal can feel dramatically better when edits are easy to inspect, split, stage, isolate, and discard.
It becomes dangerous when the operator cannot tell whether they are looking at a proposed patch, a dirty working tree, a staged subset, or a disposable scratch space.

## 1) Keep proposal, tree, and commit truth visibly distinct

At minimum, Schell should keep these objects separate:
- the **current active tree**,
- a **dirty local delta**,
- a **proposed patch witness**,
- a **staged subset**,
- a **disposable worktree or scratch zone**,
- a **committed patch**,
- and a **revert patch**.

Those objects are adjacent.
They are not interchangeable.
A proposed diff is not automatically current tree truth.
A disposable worktree is not the active checkout.
A revert is not the same action as dropping uncommitted edits.

## 2) A patch witness should describe actual footing

A healthy patch witness should carry things like:
- patch provenance,
- exact basis tree/revision/worktree,
- whether the basis is still current,
- touched paths,
- hunk count or chunk count,
- whether the patch is generated, hand-edited, or mixed,
- landing options,
- dirty-isolation posture,
- and undo class.

It should also make clear what it is **not**:
- not proof that the patch has already been applied,
- not proof that the active tree is clean,
- and not proof that later basis drift is harmless.

## 3) Dirty isolation should be first-class posture

Before stronger apply actions, the system should say whether it is standing on:
- a **clean active tree**,
- a **dirty active tree**,
- a **disposable worktree**,
- a **scratch overlay**,
- or some other isolated landing zone.

That posture matters because the safest next move depends on it.
A patch against a clean tree might be ready for direct selective apply.
A patch against a dirty tree may need isolation first.
A patch in a disposable worktree may be safe to explore aggressively because discard is cheap there.

## 4) Keep edit verbs separate

Schell should not collapse all patch-related actions into one “accept” button.
At minimum, the verbs should stay separately named:
- inspect,
- reveal basis,
- edit proposal,
- apply to scratch,
- apply to active tree,
- stage selected hunks,
- commit exact patch,
- revert with new patch,
- promote from disposable worktree,
- discard scratch,
- and drop worktree.

Those verbs imply different costs and different truths.
The shell+terminal should say so.

## 5) Selective hunk acceptance is worth stealing

Partial acceptance is a real luxury.
Operators often want one hunk and not another.
Schell should absolutely support selective hunk acceptance.
But the resulting state should remain explicit:
- partially staged,
- partially applied,
- or partially promoted.

Partial acceptance should never masquerade as one clean, obvious state if it is actually a mixed state.

## 6) Editing a patch should stay proposal-colored

Direct patch editing is powerful.
It is also one of the easiest ways to confuse “review” with “authoring.”
If the operator or assistant edits the diff itself, the system should make that explicit.
The patch witness should say that the current proposal is hand-edited or mixed-origin.
That keeps provenance honest without forbidding useful diff surgery.

## 7) Undo needs classes, not vibes

A healthy patch/review surface should say which kind of recovery is available.
Useful undo classes might include:
- **rewind file edits**,
- **drop disposable worktree**,
- **restore working tree from basis**,
- **revert committed patch with new patch**,
- **operation-log rewind**,
- or **no patch undo for external side effects**.

A generic “undo” label is only acceptable if the exact class is still visible nearby.
Otherwise the terminal is flattering the operator instead of informing them.

## 8) External side effects must stay outside the patch fantasy

Running tests, starting services, making network calls, installing packages, or mutating a remote system are not patch rewinds.
A patch witness may coexist with those effects.
It should not claim to cover them.
A strong system should be able to say:
- patch rewind available,
- worktree drop available,
- but external side effects remain only receipt-visible.

## 9) Disposable worktrees are a beautiful compromise

Disposable worktrees are worth stealing because they let the system explore edits without contaminating the active tree.
That is a terrific middle ground between:
- fully mutating the live checkout,
- and forcing every idea to stay hypothetical forever.

But Schell should keep promotion explicit.
A disposable worktree becoming valuable is not the same thing as it silently becoming primary.

## 10) A compact first proving slice

A compact first specimen should show:
1. one clean-tree patch witness,
2. one dirty-tree patch witness that refuses direct apply,
3. one selective hunk-accept path,
4. one hand-edited diff proposal,
5. one disposable-worktree apply path,
6. one promote-from-worktree path,
7. one drop-worktree undo class,
8. one revert-with-new-patch undo class,
9. and one external-side-effect receipt that stays outside patch rewind.

That is enough to make Schell feel unusually capable without freezing the final VCS, patch format, branch model, or rollback stack.

## 11) Things to refuse for now

Refuse for now:
- one generic “accept changes” action that hides landing zone,
- one generic “undo” promise that hides recovery class,
- helper edits that silently blend with preexisting dirty state,
- patch proposals that silently follow a newer basis,
- and disposable worktrees that quietly become the active truth without promotion.

The right law is:
**steal diff/patch review, selective hunk acceptance, disposable worktrees, and rewind comforts — but keep exact basis, landing zone, dirty-isolation posture, and undo class visibly stronger than charm.**
