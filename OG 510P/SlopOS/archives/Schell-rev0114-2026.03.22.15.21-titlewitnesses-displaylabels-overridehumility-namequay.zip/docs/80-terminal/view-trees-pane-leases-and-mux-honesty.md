# View trees, pane leases, and mux honesty

This surface records a new no-regret candidate cluster for Schell:
**build a rich local view tree, but keep panes, tabs, splits, and workspaces visibly local until the shell explicitly reifies something stronger.**

The design pressure comes from three directions:

- SlopOS keeps refusing to treat PTY ownership, job control, signal folklore, or local session state as portable reviewed authority.
- DelayBasin keeps distinguishing canon from derivative wrappers, live state from reentry aids, and active scope from ambient nearby structure.
- Current terminals show that pane trees, sessions, layouts, and scriptable control are wonderful — and also exactly where ambient authority starts to creep in.

## 1) The view tree is not the shell's truth

Schell should treat the **view tree** as a local ergonomic structure:
- windows,
- tabs,
- splits,
- floating panes,
- shelves,
- overlays,
- compare panes,
- inspector panes,
- and other view nodes.

The shell's durable truth still lives elsewhere:
- reviewed action objects,
- command/output boundaries,
- live-state witnesses,
- receipts and denials,
- basis packets,
- authorship,
- and active-input truth.

The view tree can render those things beautifully.
It should not replace them.

## 2) Pane leases are the right small object

A good first object here is **pane lease**.
Not because panes should own power.
Because panes need a compact local truth.

A pane lease could keep:
- pane kind,
- hosted lane or object id,
- posture (`interactive`, `readonly`, `restored`, `scratch`, `inspector`),
- active-input eligibility,
- liveness badge,
- and permitted local action families.

This is enough to make panes more legible without freezing a final mux architecture.

## 3) Useful pane kinds Schell should probably have

A decision-light first family could include:

### Live interactive pane
Hosts the current shell lane and may own the active-input field.

### Readonly replay pane
Shows a receipt, historical command region, or restored state without taking live authority.

### Compare pane
Pins one exact receipt, output region, or basis packet next to another.

### Inspector pane
Shows semantic/debug truth the terminal knows about the current pane or block.

### Scratch pane
Fast temporary workspace that is explicitly non-canonical and easy to close.

### Shelf pane
Hosts background residue, denials, or followthrough items in a compact local view.

## 4) Great local view actions should stay local

Strong candidate view actions:
- split,
- reorder,
- zoom,
- pin,
- detach,
- reattach,
- move to compare,
- open as scratch,
- convert to readonly replay,
- and close/undo-close.

These can be excellent product features.
The key posture is that they do **not** by themselves mutate the shell's durable truth.

## 5) Cross-pane send/inject should not be casual

Many current systems can send text or clone state across panes.
Schell should be much more careful.

Good first posture:
- copy across panes is fine,
- quote-insert into the one true active input is fine when explicit,
- derive-proposal from another pane is fine,
- but raw cross-pane send-text should usually require an explicit packet or stay disabled.

This is one of the simplest ways to avoid rebuilding terminal folklore where “neighboring pane” quietly means “authorized target.”

## 6) Layouts and workspaces should be derivative wrappers

Saved layouts, workspaces, and pane templates are attractive.
Schell should likely treat them as **derivative wrappers** at first.

They may remember:
- pane arrangement,
- pane kinds,
- preferred bindings,
- compare/shelf/inspector placement,
- maybe launch intents or workflow seeds.

But they should not silently:
- approve launches,
- resurrect old basis,
- claim current liveness,
- or turn restored panes into durable execution truth.

## 7) Restored and detached panes need visible badges

This surface inherits a lot from the restoration and selection work.
A pane should be able to say whether it is:
- live,
- restored,
- detached,
- scratch,
- readonly,
- guessed,
- or awaiting reacquisition.

That one small badge family would do a lot to keep a rich pane tree honest.

## 8) One active input still matters inside the view tree

No matter how rich the layout gets, Schell should still keep one separate truth for the current active-input field.
That field may live inside one pane lease.
Other panes may be visible, selected, or focused for browsing.
They should not silently become the place where strong keyboard actions route.

## 9) Transcript truth here should stay compact

The transcript does not need to serialize every splitter drag or floating-pane resize.
It does need to preserve the important truths:
- which pane kind hosted a shell object,
- whether a pane was live or restored,
- when a local action routed back into an exact shell object,
- and when a cross-pane action downgraded to hold/inspect/copy rather than execution.

## 10) No-regret first cut

A first specimen set could stay small:

1. one live interactive pane,
2. one readonly replay pane,
3. one scratch split,
4. one compare pane bound to exact receipts,
5. one restored pane that stays visibly restored,
6. one cross-pane send that downgrades to a packet/proposal,
7. and one transcript witness for the important local-vs-durable distinctions.

That is enough to learn a lot without freezing the final multiplexer, PTY architecture, or workspace persistence story.
