# Unicode witnesses, bidi gates, and confusable humility

This surface names a terminal seam that modern shells, editors, code forges, and renderers keep proving is real:
**Schell should support rich multilingual text and better grapheme rendering, but it should not let Unicode rendering tricks, invisible controls, confusable labels, or width mismatches outrun reviewed byte truth.**

SlopOS already gives the right pressure here.
Authority-bearing seams get simpler profiles first.
Exact identity stays stronger than nearby convenience.
Expensive policy datasets do not belong on every boundary by default.
That is exactly the posture Schell should import while both datacubes are still in design.

## 1) The shell should know the difference between bytes, graphemes, and display text

Old terminal culture often treats visible text as if it were the only truth that matters.
That is no longer good enough.
Modern Unicode makes at least four nearby views operationally different:
- exact bytes,
- scalar/codepoint sequence,
- grapheme clusters,
- and current rendered order/shape.

Schell should never force every interaction to use the same view.
A great shell+terminal should know when the operator needs exact bytes, when cluster-aware movement matters, and when display-only shaping is just a luxury.

## 2) Review surfaces should become stricter exactly where authority increases

A no-regret rule for Schell is:
- rich rendering is fine for ordinary reading,
- richer shaping is good for humane multilingual use,
- but reviewed commands, executable paths, pasted snippets, secret handles, and policy-bearing names should get a stricter reveal posture.

That stricter reveal posture could include:
- explicit display of bidi controls and invisible codepoints,
- confusable-risk hints,
- exact-byte or escape-sequence reveal,
- normalization posture badges,
- and a one-step switch from pretty view to safe review view.

This does **not** require banning non-ASCII text.
It only requires refusing to confuse beautiful display with exact review truth.

## 3) A compact Unicode witness family would already be enough

Schell likely does not need a giant internationalization policy engine first.
A compact witness family could already make the shell much more honest:
- `text_basis` — exact bytes / scalar sequence / grapheme sequence / rendered projection
- `normalization_posture` — exact / normalized-for-search / display-only folded / unknown
- `bidi_posture` — none / present-visible / present-hidden / historical-only
- `confusable_posture` — low / mixed-script / skeleton-collision-risk / known-alias / unknown
- `width_posture` — baseline-width / renderer-local-width / remote-mismatch-risk / historical
- `display_alias` — pretty label distinct from inserted/executed bytes
- `review_mode` — pretty / escaped / hex / skeleton-compare / strict-safe-review

That is already enough to make many old shell dangers legible without freezing a huge policy stack.

## 4) Authority-bearing identifiers should stay simpler than nearby prose

This is the strongest SlopOS import on this pass.
SlopOS already keeps some authority-bearing labels on exact-byte ASCII profiles rather than importing Unicode preparation and confusable-management into the core seam.
Schell should import the **principle**, not necessarily the exact same restriction everywhere.

A good v0 rule is:
- commands, executable paths, durable receipts, handle ids, and policy-bound object names should prefer exact-byte identity and strict review,
- while user-facing captions, notes, runbook titles, and explanatory cards can remain richly multilingual and display-friendly.

That split would make the shell safer without making it culturally narrow.

## 5) The super-awesome move is not “more Unicode”, but better Unicode lanes

There are genuinely brilliant ideas worth stealing here:
- **grapheme-aware cursoring and selection** so combined emoji and complex-script clusters behave like one thing when that is what the renderer shows,
- **safe review toggles** that instantly reveal hidden bidi controls, zero-width characters, and escapes,
- **confusable compare cards** that show the skeleton or nearest-confusable peer before running a suspicious command,
- **display label vs inserted bytes** as a first-class distinction for completions, workflow cards, and detector offers,
- **width-mismatch badges** when the local renderer and remote peer may disagree about cell width,
- **script-aware but non-paternal warnings** that warn harder only when authority or ambiguity is high.

That is how Schell can become unusually humane and unusually careful at the same time.

## 6) Search, recall, and history should stay weaker than exact execution truth

This pass also suggests a subtle but important rule:
search-friendly normalization and pretty display names are useful, but they should stay weaker than exact execution truth.
History lookup may fold or normalize for recall.
Rendered cards may use a safer display alias.
But the final reviewed action should still be able to show the exact inserted or executed bytes before admission.

## 7) Protocol and policy choices should remain deferred

Schell should **not** answer this seam by prematurely freezing:
- one normalization strategy for every surface,
- one confusable dataset version as permanent product truth,
- one bidi-control policy for every script context,
- one terminal width table everywhere,
- or one renderer behavior as authoritative.

The smaller commitment is enough:
**every authority-adjacent text surface should declare whether it is exact, normalized, display-shaped, width-sensitive, or potentially ambiguous.**

## 8) A narrow v0 is enough

Schell can start very small here:
- one Unicode-witness family,
- one strict-safe-review mode for authority-adjacent text,
- one rule that display aliases never silently replace exact inserted/executed bytes,
- one distinction between multilingual display luxury and authority-bearing identifier truth,
- and one degrade note when width, shaping, or bidi visibility may differ across renderer/peer/history contexts.

That is already enough to make the shell+terminal materially better than current folklore without freezing the final Unicode, shaping, or identifier-policy stack too early.
