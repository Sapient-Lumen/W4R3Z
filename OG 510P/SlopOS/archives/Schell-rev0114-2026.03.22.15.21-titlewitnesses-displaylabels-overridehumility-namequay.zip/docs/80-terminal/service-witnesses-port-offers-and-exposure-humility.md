# Service witnesses, port offers, and exposure humility

This surface keeps another easy-to-overflatten terminal seam explicit:
**a great shell+terminal should make local services, forwarded ports, and browser handoff feel much smoother than legacy terminals, but it should not let a visible `localhost` string quietly become a browser launch, a tunnel, a public share URL, or an exposure policy change.**

Modern development tools already make this seam feel magical.
That magic is worth stealing.
But the shell+terminal should stay honest about what kind of thing it knows:
- a process may be **listening**,
- a service may be **reachable only on loopback**,
- a port may be **forwarded**,
- a URL may be **safe to open locally but not shared publicly**,
- and a browser tab may have been **requested** without proving that anyone else can reach the target.

If Schell does not name this seam, a custom shell+terminal will quietly become a stealth browser launcher, tunnel manager, and port-exposure control plane.

## 1) A visible service is not one action

When a tool prints `http://localhost:3000`, several adjacent workflows suddenly sit near each other:
- inspect the local address,
- copy the local address,
- open it in a browser,
- open it in an in-terminal preview,
- forward it from a remote environment to the local machine,
- share it with collaborators,
- change visibility or protocol,
- or stop exposing it.

Those workflows are related, but they are not the same thing.
Schell should therefore refuse the old terminal habit of treating every visible localhost URL as one giant implicit “open” affordance.

## 2) Schell should mint a small service witness before it mints stronger actions

A useful first move is to treat a discovered service as a **service witness**.

A service witness is smaller than a whole service dashboard.
It is just a bounded object saying what the shell or terminal currently knows about one candidate service endpoint.

A v0 service witness could keep:
- `subject_ref` — exact command chapter / output capsule / workflow seed / detector hit / imported handoff,
- `origin_posture` — shell-known / workflow-known / detector-known / imported / restored / historical,
- `locality_posture` — loopback-local / local-network / remote-loopback / forwarded-local / public-url / unknown,
- `transport` — http / https / tcp / udp / unknown,
- `endpoint_forms[]` — literal localhost URL, local forwarded address, remote origin address, browser-facing external URI, curl-safe local address, or unknown,
- `reachability_posture` — listening-witnessed / forwarded / opened / copied / shared / expired / unknown,
- `exposure_posture` — loopback-only / private / org-visible / public / unknown,
- `browser_posture` — not-opened / open-requested / opened-locally / unknown,
- `freshness_posture` — current / restored / historical / imported / unknown,
- `transcript_summary` — a text-safe witness line.

That is enough to keep service UX honest without freezing:
- one port-forwarding protocol,
- one browser-preview engine,
- one public-sharing system,
- or one service-discovery stack.

## 3) Listening, forwarding, opening, and sharing should stay separately named

This may be the most important design lesson here.
A custom shell+terminal should not tell the same story for all of these cases:
- “process is listening on 127.0.0.1:3000”,
- “remote port 3000 is forwarded to a local address”,
- “opened browser at a local forwarded address”,
- “created an externally reachable share URL”,
- or “changed visibility from private to public”.

Those are stronger and stronger claims.
Schell should therefore keep a compact action ladder such as:
- `inspect service witness`,
- `copy local address`,
- `copy external address`,
- `open local in browser`,
- `open local in preview`,
- `forward to local address`,
- `share privately`,
- `share publicly`,
- `stop forwarding / stop sharing`.

That lets the terminal feel dramatically more capable without turning one click on visible text into a hidden exposure decision.

## 4) “Open locally” and “make externally reachable” should be different verbs

Some of the best current tooling already hints at this split.
A remote tool may know how to produce an external URI without forcing a browser open.
That is a brilliant pattern for Schell.

The wrong move is to collapse these into a single flattering affordance.
The better move is:
- one action that **derives or reveals the address**,
- one action that **opens locally**,
- and a stronger separately named action that **widens reachability**.

That pattern preserves operator control over whether the terminal is helping with mere inspection, browser launch, or actual exposure.

## 5) Detector help should stay weaker than shell-known service truth

Many service witnesses will begin life as detector help.
The terminal may notice:
- a `localhost` URL in output,
- a `Listening on` line,
- a tunnel announcement,
- or a dev server banner.

That is useful.
It is not the same as shell-known truth.

So service witnesses should grade origin clearly:
- **shell-known** — a workflow seed or launch kit intentionally created a service lane,
- **workflow-known** — a reviewed helper already knew which service it was starting,
- **detector-known** — regex/banner/URL detection from output only,
- **restored/historical** — a prior service card survives as history but needs reproof.

That one badge family will prevent a lot of accidental overclaiming.

## 6) Remote and local service stories should not be flattened

A remote dev shell, codespace, container, or SSH session often needs the same humane affordances as a local service, but the truth story changes.
A remote service may become reachable through:
- loopback on the remote side,
- a forwarded local address,
- a provider-issued external URL,
- or a browser-open-on-client helper.

Schell should not pretend those are interchangeable.
A remote service card can still be luxurious, but it should say whether the current address is:
- remote-origin only,
- forwarded to local loopback,
- externally reachable with auth,
- externally reachable without auth,
- or historical/stale.

That keeps service UX humane without forcing a full remote platform architecture now.

## 7) Historical service cards should stay historical until repaired

This is another place where terminals can lie accidentally.
A remembered dev-server card from yesterday is useful.
It is not current truth.

So restored service witnesses should keep visible posture like:
- `historical service`,
- `previously forwarded`,
- `share link stale`,
- `reacquire local address`,
- or `re-open after reachability check`.

That keeps the terminal from teaching users that browser tabs, copied URLs, and remembered port cards are still alive just because they look familiar.

## 8) Great steals that still stay decision-light

### a) URL/port detection that lands in a service card
A visible localhost URL or listening banner can produce a service witness rather than a one-click hidden action.

### b) Explicit local-versus-external address rows
One card can show `local address`, `external address`, and `remote origin` as different rows instead of pretending one canonical URL exists.

### c) Insert/copy before open
For scripts, curl, and sharing flows, `copy local address` or `copy curl address` should often be easier than forced browser launch.

### d) Visibility/exposure badges
A service card can show `loopback-only`, `private`, `org-visible`, `public`, or `unknown` clearly before the operator shares anything.

### e) Reversible reachability changes
If a stronger platform-specific stack exists, `share publicly` should sit beside `make private again` or `stop sharing`, not hide behind a browser button.

## 9) The no-regret move

The best move right now is not to invent a full service manager, tunnel platform, or browser-session abstraction.
It is to pin one rule:
**Schell should model detected services and forwarded ports as explicit service witnesses with distinct local/open/share/exposure actions before it lets visible localhost text or dev-server banners masquerade as one giant “open in browser” truth.**

That keeps the archive free to defer:
- the final port-forwarding backend,
- the final browser-preview story,
- the final public-sharing controls,
- the final reachability-check protocol,
- and the final remote-service inventory model.
