# Forget rails, retention lanes, and history-residue humility

This surface names a shell+terminal seam that gets more important with every “smart” feature we add:
**Schell should get much better at remembering the right things, but it should get equally good at forgetting the right things, because clearing the screen, clearing scrollback, deleting a session history entry, hiding recents, pruning synced history, and suppressing future retention are different actions and should stop borrowing one another's language.**

SlopOS already teaches the key discipline.
Generic open does not quietly become durable recents authority.
Safe-open residue should not escape the disposable.
Shell-local history may exist, but it stays shell-owned and non-authoritative.
That is exactly the right import pressure for Schell while both datacubes are still design-phase.

## 1) Forgetting deserves first-class shell truth

Classic shells are surprisingly sloppy here.
They often offer some mix of:
- a visible prompt history,
- an on-disk history file,
- a terminal scrollback buffer,
- restored tabs or sessions,
- maybe synced history from another tool,
- and stray recents or preview caches from host integrations.

But they rarely say clearly:
- which layer a command or object currently lives in,
- which of those layers will survive window close or reboot,
- what “private mode” actually suppresses,
- or what a user means when they say “forget that.”

A custom shell+terminal can do much better by making **retention lanes** and **forget rails** explicit.

## 2) SlopOS already has the right residue instincts

The most useful import from SlopOS is not one storage backend.
It is one boundary story.

The current OpenURI recent-items boundary says generic mediated launch should **not** quietly become a portable recent-items, durable-history, or reopen-enrollment surface.
The safe-open viewer-residue boundary says thumbnails, search sidecars, autosave drafts, and crash-recovery blobs should not escape the disposable merely because risky preview happened.
And the surrounding cache/residue posture work keeps reminding us that local hints are acceptable only when they stay visibly weaker than explicit authority.

That is an excellent terminal lesson.
Schell should not let:
- one helpful chapter browser,
- one semantic-history index,
- one restored pane,
- one image preview cache,
- one command deck,
- or one synced history tool
quietly grow into a second ambient memory plane with fuzzy deletion semantics.

## 3) One compact retention witness family would already help a lot

Schell does not need a grand personal-data architecture first.
A small witness family could already make memory posture much more honest.

A v0 retention witness could carry:
- `subject_kind` — input-line / command-chapter / transcript-slice / preview-residue / service-hint / secret-bearing-object / unknown,
- `retention_lane` — prompt-only / scrollback / session-history / durable-local-history / restored-session / synced-history / shell-local-recent / exported-artifact / unknown,
- `persistence_posture` — volatile / survives-window / survives-restart / durable-local / synced / historical / unknown,
- `clear_scope` — this-view / this-session / this-machine / all-known-local / synced-remote-too / unknown,
- `forget_posture` — suppress-future / delete-past / clear-visible / prune-matching / expire-later / unknown,
- `recoverability_posture` — none / undo-window / recoverable-local / recoverable-remote / unknown,
- `freshness_posture` — live / restored / imported / historical / unknown.

That is enough to drive rich UI without freezing one database, sync model, or global retention policy engine.

## 4) The most stealable ideas are practical and humane

### a) Private scratch lanes
Steal the best part of shell private modes, but make it broader than “do not write readline history.”
A Schell **private scratch lane** could suppress durable chapter history, recents enrollment, synced history, preview residue, and restored-session persistence for that lane unless the operator explicitly promotes something out of it.

### b) Retention chips on chapters and cards
Every command chapter, workflow card, preview card, and service card should be able to say something compact like:
- visible only,
- session only,
- durable local,
- synced,
- exported,
- restored historical.

That is a much better operator experience than guessing which invisible subsystem kept a copy.

### c) Forget-this-family rails
One of the best “super awesome” moves here would be a **forget this family** action.
Not merely “delete this line from one history file,” but:
- clear visible scrollback references,
- drop chapter metadata,
- prune durable local history matches,
- remove restored-session echoes,
- clear shell-local recent hints,
- and show what could not be erased because it already crossed an export or sync boundary.

### d) Suppress future retention separately from delete past retention
Private mode, ignore-space rules, and history filters are mostly about **future** retention.
Pruning, clear-history, and delete-it-all are about **past** residue.
Schell should keep those verbs separate.
The UI should never imply that “don't save new history” also erased earlier copies.

### e) Expiring lanes instead of one giant forever history
A lot of humane shell memory is useful for hours or days, not forever.
Schell could allow session-local or project-local retention classes with visible expiry posture rather than assuming every smart hint deserves indefinite storage.

## 5) The old mistakes to avoid

### a) Clearing the screen is not clearing memory
A blank viewport proves very little.
Scrollback, pane history, persistent sessions, chapter journals, and synced history may all still exist.

### b) Clearing one history plane is not clearing the others
Shells and terminal tools often keep separate session, file-backed, restored, and synced histories.
One delete action rarely covers them all.
Schell should surface that truth instead of hiding it.

### c) Private mode is not retroactive absolution
If a command already landed in durable history or sync, turning on private mode later does not erase the earlier residue.
That is exactly the kind of overclaim we should refuse.

### d) Helpful recents and previews can become secret residue
Recent-item lists, thumbnails, snapshots, preview caches, and restored-session buffers can retain exactly the kinds of commands, filenames, URLs, and sensitive hints users most need to forget.

### e) Sync makes deletion harder, not simpler
Once history or receipts leave the local machine, “forget” becomes an explicit cross-boundary workflow with weaker guarantees.
Schell should stay honest about that.

## 6) The no-regret move

The best move right now is compact:
**give Schell one retention-witness family, one private-scratch-lane posture, one forget-this-family action ladder, and one refusal to let clear-screen, clear-history, private mode, scrollback deletion, restored-session suppression, recents clearing, and synced-history pruning masquerade as the same action.**

That keeps open:
- one final history store,
- one final sync backend,
- one final preview-cache design,
- one final restored-session model,
- and one final deletion/expiry engine.
