# Render-ground cards, view adapters, and rich-output humility

This surface keeps one boundary explicit:
**a great shell+terminal should be able to show beautiful tables, grids, markdown, diffs, hyperlinks, and inline media, but it should not let rendered views impersonate exact values, exact handles, or exact command/output truth.**

Schell already has pager witnesses, hyperlink witnesses, inline-media witnesses, help grounds, file cards, and command/output honesty.
This pass narrows the seam those surfaces still left open:
**how the shell+terminal should treat formatting and rendering as explicit adapter layers rather than as the thing itself.**

The design pressure comes from three directions:
- SlopOS keeps pushing typed payloads, durable handles, explicit transfer lanes, and canonical evidence rather than ambient display folklore.
- Current shells keep proving that structured values and rendered views are different objects.
- Current terminals keep proving that beautiful local rendering is possible while protocol support, fallback behavior, and click actions stay fragmented.

## 1) The first rule: render is a view, not the basis

PowerShell still teaches the cleanest old lesson here: formatting files define what is displayed, not what object members exist in the pipeline.
Nushell sharpens the same idea from another direction: `table` renders structured data to a string stream.

Schell should steal that separation aggressively.
A shell+terminal should keep at least these things separately named:
- **value ground** — the structured value or exact plain-text output,
- **handle ground** — the exact object/document/file/output ref when one exists,
- **render ground** — the adapter/view chosen for display,
- **capability posture** — what this renderer depends on locally,
- **fallback posture** — what remains true when the renderer disappears,
- and **action posture** — which stronger actions are inspect/open/export/share rather than mere display.

## 2) Render-ground cards should explain why something looks this way

A humane shell+terminal should let an operator ask:
- why did this become a table,
- why is this a wrapped list instead of a grid,
- why is this markdown being prettified,
- why did this diff become clickable,
- why are images visible here but not over SSH,
- or why did the pager/viewer downgrade to plain text.

Schell should therefore keep compact **render-ground cards** that can say things like:
- raw value,
- formatted text,
- table adapter,
- grid adapter,
- markdown adapter,
- hyperlink adapter,
- image/media adapter,
- preview-only adapter,
- degraded plain-text fallback,
- or restored historical rendering.

This does not require a universal rich-output stack.
It only requires refusing to overclaim what the pretty layer proves.

## 3) View adapters should stay weaker than inspect/open/export

One of the easiest shell mistakes is letting a beautiful view become a hidden stronger action.
Schell should refuse that.

A useful v0 ladder is:
- **inspect subject/value**,
- **render locally**,
- **expand viewer/pager**,
- **copy rendered text**,
- **copy exact subject ref**,
- **open stronger viewer**,
- **export/materialize/share**.

That matters because a rendered table, markdown card, or image preview may come from:
- a structured value,
- a bounded command-output chapter,
- a file/doc handle,
- a remote peer,
- a historical cache,
- or an imported artifact.

Those origins should stay visible.

## 4) Rich rendering should degrade honestly

Current tools already prove a useful pattern:
- PowerShell objects can be formatted in multiple views,
- Nushell can render a table or open `explore`,
- diff tools can add hyperlinks when the terminal supports them,
- markdown viewers can render beautifully in-place,
- and graphics-capable terminals can show inline images.

But those same tools also prove fragmentation:
- paging may need to turn off in pipelines,
- non-interactive outputs often fall back to plain text,
- hyperlinks may exist explicitly or only by pattern matching,
- and image/graphics support depends heavily on terminal-local protocols.

So Schell should keep one explicit **degrade ladder**:
- native structured render,
- text render with shell-known annotations,
- plain text with inspect chips,
- and subject-only stub.

## 5) Rendered text should never be the only durable truth

Rendered views are useful because they help humans.
They are dangerous when they become the only surviving thing.

Schell should therefore prefer one text-safe durable basis for every richer rendering family:
- exact subject/value digest or handle when available,
- plain-text fallback when a renderer is unavailable,
- source-labeled link/path targets,
- and render receipts that say which adapter produced the visible form.

That makes transcripts, replay, support export, SSH, and downgraded terminals much safer.

## 6) Markdown, diffs, tables, and images should all fit the same humility rule

The shell does not need a different metaphysics for every pretty thing.
A compact family is enough:
- **render-ground card** answers “what adapter am I looking at?”
- **subject card** answers “what exact thing did this come from?”
- **capability badge** answers “why does this work here?”
- **fallback badge** answers “what survives elsewhere?”
- **historical badge** answers “is this live, restored, or exported?”

That gives Schell one consistent answer across:
- tables,
- grids,
- markdown,
- syntax-highlighted text,
- diffs,
- hyperlinks,
- and inline media.

## 7) Super-awesome specimen ideas that still stay decision-light

A first specimen set could stay small but teach a lot:
1. one structured value shown as raw inspect, table, and grid while keeping the same subject card;
2. one markdown document shown as plain text, rendered markdown, and stronger open-viewer actions;
3. one diff chapter with clickable file/line links that remain weaker than exact editor-open review;
4. one bat-like pretty file view that falls back to plain contents in a non-interactive or piped lane;
5. one image/media result that shows native inline view when supported and a text-safe stub otherwise;
6. one render-ground why-card showing which adapter won and which fallbacks were available;
7. one transcript/support export witness that keeps the subject basis plus render receipt instead of only the pretty pixels.

## 8) The no-regret move

The best move right now is not to freeze one universal rich-output protocol, one renderer runtime, one markdown/diff/image stack, or one viewer registry.
It is to pin one stronger rule:
**Schell should model rendering as render-ground cards, view adapters, capability badges, fallback ladders, and subject-preserving receipts before it lets pretty tables, markdown, hyperlinks, or pixels masquerade as exact shell truth.**

That keeps the archive free to defer:
- the final renderer registry,
- the final markdown/diff/table/image adapter stack,
- the final hyperlink/image protocol mix,
- the final export/screenshot/story for rich views,
- and the final remote/mux downgrade strategy.
