# Query witnesses, smart decks, and saved-view humility

This surface keeps one boundary explicit:
**a great shell+terminal should let operators query prior chapters, receipts, denials, runbooks, and artifacts as first-class working views, but it should not let saved searches, live query updates, or result rows impersonate current authority.**

Modern tools keep rediscovering the same delight:
- command history becomes filterable by repo, host, exit status, and time,
- search results become a full-sized review surface instead of a tiny dropdown,
- saved criteria become living folders or smart collections,
- and set-valued query languages become expressive enough to feel like real navigation.

That is all worth stealing.
The failure mode is equally consistent:
- saved criteria quietly become hidden inventory authority,
- result rows quietly become “do the thing” buttons,
- live queries quietly become a background watcher or scheduler,
- and yesterday's singleton result quietly becomes today's unstated execution target.

Schell should steal the luxury while refusing the flattening.

## Core idea

Schell should probably distinguish at least six nearby objects:

- **query witness** — one explicit query request bound to explicit scope and explicit posture,
- **result row** — one metadata-safe candidate derived from a query witness,
- **query editor** — a full-sized review surface for one result set,
- **smart deck** — a reusable saved-view manifest bound to criteria and scope,
- **live view** — an opt-in bounded subscription that may add/remove rows over time,
- **strong action request** — a later explicit step that selects one exact row or one reviewed target set.

Those objects are related.
They are not the same thing.

## 1) Query witnesses should make scope and posture visible

A useful v0 **query witness** probably needs fields like:
- `query_witness_id`,
- `domain` — chapter / receipt / denial / artifact / runbook / mixed,
- `source_scope` — workspace / peer / host / chapterbook / deck / local-only,
- `criteria_kind` — typed predicate / filtered search / fuzzy query / imported query string / unknown,
- `freshness_posture` — snapshot / reopened / rechecked / live,
- `cardinality_posture` — zero-ok / many-ok / singleton-required-for-strong-actions / reviewed-target-set,
- `preview_posture` — metadata-safe / richer-inspect-required,
- `history_posture` — ephemeral / saved-manifest / exported-never / shared-never,
- `overflow_posture` — bounded / may-drop / reconnect-required / n-a,
- `basis_ref` — optional explicit epoch or journal basis,
- `result_handle_family` — exact chapter refs / review cards / doc handles / mixed refs,
- `notes_ref?` — explanation or saved rationale.

That is enough to support rich search UX without freezing:
- one final query language,
- one final search index,
- one final live-query event model,
- or one final sync architecture for saved views.

## 2) A smart deck should be criteria plus scope, not a durable grant

A **smart deck** is the reusable saved-view object here.
It is not a magic bookmark to whatever happens to match forever, and it is not a permission grant over the underlying results.

A compact v0 smart deck could preserve:
- `deck_id`,
- `title`,
- `query_ref`,
- `source_scope`,
- `default_mode` — snapshot / requery / live,
- `result_kind_badges[]`,
- `history_policy`,
- `sharing_policy`,
- `sensitivity_posture`,
- `allowed_default_actions[]`,
- `reopen_behavior` — reopen previous snapshot / rerun criteria / ask,
- `live_overflow_policy?`.

Important posture:
- a smart deck is **query reuse and staging help**,
- not proof the current results are still present,
- not permission to run against all matches,
- and not a hidden background watch by default.

## 3) Query editors should feel rich, but remain review-first

A full-sized **query editor** is one of the nicest stealable ideas.
It lets the operator compare multiple result rows, see surrounding context, annotate the view, and keep the query open while navigating to exact rows.

In Schell, a query editor should probably:
- show the criteria and source scope prominently,
- show surrounding context for chapter or receipt matches,
- let the operator pin rows into a working set,
- let the operator reopen as snapshot or rerun now,
- and keep strong actions visibly separated from navigation.

That would make command history and operational residue much more humane without pretending the editor itself is a live control plane.

## 4) Result rows should be metadata-safe by default

Discovery surfaces are where accidental leakage and fake certainty creep back in.
So Schell should keep result rows conservative by default.

A good default posture is:
- exact refs,
- source badges,
- liveness/freshness badges,
- kind badges,
- bounded summaries,
- and explicit inspect/open steps for anything richer.

Rows should not ambiently reveal:
- secret-bearing command bodies,
- quarantined/snippet-rich content,
- remote previews with hidden fetching,
- or aggressive derived summaries that outrun the original evidence.

## 5) Singleton-required strong actions should be blunt

Set-valued discovery is fine.
Strong actions should still be precise.

So Schell should likely support at least three action postures:
- **inspect or stage** — safe for many matches,
- **promote to reviewed target set** — for intentionally many-target actions,
- **singleton required** — for open / rerun / attach / edit / publish style actions.

If a query currently resolves to multiple rows, a singleton-required action should refuse politely and push the operator toward exact row selection or an explicit target-set review.
That is much better than quietly choosing “the top hit.”

## 6) Live views should be opt-in and visibly stronger than snapshots

A query that refreshes itself over time is a different product shape than a one-shot search.
Schell should say so.

A good v0 split is:
- **snapshot query** — one exact result set on one exact basis,
- **copied result editor** — a review artifact derived from a snapshot,
- **requery now** — explicit refresh on demand,
- **live deck** — opt-in updates with overflow and reconnect posture.

Live decks can be wonderful for things like:
- current failing chapters in this repo,
- new denials from this peer,
- or recent share artifacts awaiting redaction.

But they should stay visibly bounded, revocable, and weaker than schedulers or hidden background workers.

## 7) Great ideas worth stealing right now

### a) Filtered chapter recall with rich facets
History queries should be able to filter by cwd/workspace, exit posture, time bounds, peer, and maybe artifact family.

### b) Full-sized query editors
Let search results become a richer review surface with context, pinning, and compare-friendly navigation.

### c) Smart decks as reusable saved criteria
A saved deck for “recent failures in this workspace” or “share candidates with secret risk” is much more valuable than a raw history list.

### d) Singleton-aware action posture
Make it obvious which commands tolerate many rows and which demand one exact row.

### e) Metadata-safe result rows with stronger inspect steps
This one rule prevents a lot of leakage and overclaiming.

### f) Optional live decks with visible overflow posture
When live queries are useful, make the subscription truth visible instead of ambient.

## 8) Things Schell should refuse

### Refuse ambient global inventory
Saved views should stay bound to explicit scope, not “everything reachable from the host somehow.”

### Refuse top-hit-equals-target
Ranking may help navigation.
It should not silently choose execution targets.

### Refuse saved-query-equals-grant
A manifest is criteria plus scope, not durable authority over future matches.

### Refuse live-query-equals-background-worker
A live deck is not a scheduler, watcher daemon, or hidden recall service by default.

### Refuse rich previews by ambient hover
Especially for sensitive or quarantined rows, hover should not become a secret preview channel.

## 9) No-regret first specimen set

A compact first cut could show:
1. one filtered history query over chapters with cwd/exit/time facets,
2. one query editor with surrounding chapter context,
3. one saved smart deck bound to explicit criteria and scope,
4. one reopened deck that clearly says snapshot versus rerun-now,
5. one live deck with bounded overflow posture,
6. one singleton-required action refusing a multi-match result,
7. one explicit promote-to-target-set review path,
8. and one metadata-safe preview refusal for a sensitive or quarantined row.

That is enough to make Schell substantially more awesome at recall, staging, and operational navigation without freezing a full search/index stack.

## 10) The no-regret move

The best move right now is not to freeze one universal query language or one giant search backend.
It is to pin one rule:
**query luxury in Schell should become explicit query witnesses, saved smart-deck manifests, metadata-safe result rows, and singleton-aware action posture before it becomes ambient inventory or hidden authority.**
