# Nondeterminism witnesses, seed lanes, and replay humility

This surface keeps one boundary explicit:
**a great shell+terminal should let operators review randomness quality, seed posture, and replay footing — but it should not let ambient `/dev/urandom`, hidden `getrandom()` calls, deterministic test knobs, or historical receipts impersonate one another.**

Modern systems already have real nondeterminism machinery:
- some APIs provide cryptographically fresh randomness,
- some provide only insecure or one-time seed material,
- some deterministic environments intentionally omit fresh-random interfaces,
- builds and tests often accept explicit reproducibility variables,
- and replay systems need captured events or declared deterministic providers.

That is all worth stealing.
The failure mode is equally consistent:
- randomness stays invisible until a flaky test or changed identifier surprises someone,
- fresh crypto and deterministic replay get flattened together,
- seed material gets logged as if it were ordinary metadata,
- and stale badges or receipts start pretending to prove present authority.

Schell can do better without picking one final RNG provider, replay substrate, or cross-platform nondeterminism ontology.

## 1) The shell needs one exact nondeterminism witness

A good first object is **nondeterminism witness**.

A nondeterminism witness is a compact shell-owned descriptor for the randomness or determinism footing a reviewed action will enter.
It is not a full RNG API.
It is not a final replay engine.
It is the thing the terminal can point at when it says “this command depends on *this exact kind* of nondeterminism posture.”

A v0 witness probably needs:
- `nondet_lane` — `crypto_fresh` / `seed_only` / `insecure_seed` / `deterministic_replay` / `tool_declared_seed` / `ambient_compat` / `unknown`,
- `quality_posture` — crypto / bounded_seed / insecure / deterministic / unknown,
- `source_posture` — explicit provider / explicit env rail / compat inherit / omitted / unknown,
- `replay_posture` — exact / capture_required / deterministic_provider / forbidden / unknown,
- `receipt_posture` — shell_owned / provider_addendum / unavailable,
- `raw_material_policy` — never_persist / sealed_ref_only / compat_unknown,
- `notes_ref` — optional explanation or refusal card.

That is enough to make randomness truth real without freezing a giant portability model.

## 2) Seed lanes should be named, not implied

Current shells still hide one of the most common sources of confusion:
not every random-looking value has the same security or replay meaning.
Useful distinctions include:
- one-time seed material for local PRNG startup,
- insecure per-process seeds such as hash-map DoS resistance,
- long-lived probabilistic sampling lanes,
- and fresh cryptographic random required for security-sensitive work.

Schell should therefore show named **seed-lane posture** up front.
The operator should not have to reconstruct it from:
- host-runtime folklore,
- a language helper hidden behind `uuid` or `rand` convenience,
- or a replay failure discovered later.

## 3) Deterministic and fresh lanes deserve different chrome

This is a crucial shell lesson.
A command can be:
- intentionally deterministic for replay or tests,
- deterministic only because a tool-specific env knob was inserted,
- or explicitly fresh-random and therefore unreplayable without capture.

Those are all valuable.
They are not the same.

Schell should let the terminal render them richly:
- “fresh crypto randomness; exact replay unavailable without capture”,
- “seed-only lane; downstream process-local PRNG expected”,
- “deterministic replay lane; tool-specific seed/env inserted by review”,
- “ambient compat randomness; claim strength degraded”.

That is a genuine super-awesome move that still stays decision-light.

## 4) Repro rails are a luxury worth stealing

One especially good idea worth stealing is an explicit **repro rail**.
For many build or test commands, the operator may want a reviewed insertion offer that says:
- add `SOURCE_DATE_EPOCH=...` or another tool-declared deterministic flag,
- keep the original command visible beside the adjusted one,
- confess whether the determinism is shell-known, tool-declared, or guessed,
- and never pretend that reproducible timestamps equal fully deterministic execution.

That gives Schell a luxurious practical move without prematurely standardizing one universal deterministic-mode contract.

## 5) Historical entropy receipts should stay bounded

A good nondeterminism receipt might include:
- exact command/action basis,
- nondeterminism lane and quality posture at review time,
- replay posture,
- optional deterministic env insertions,
- exact exit status / signal posture,
- optional provider/source badge,
- optional byte-budget or seed-budget facts,
- and a claim-strength badge when the runtime could not prove more.

It should avoid pretending to prove:
- current live entropy-handle state,
- current provider freshness,
- current replayability,
- or raw seed bytes that would widen residue.

## 6) Great ideas worth stealing right now

### a) Named nondeterminism badges
Tiny but very high value:
- crypto fresh,
- seed only,
- insecure seed,
- deterministic replay,
- ambient compat,
- unknown.

### b) Seed-slot cards
A command should be able to say “tool-declared seed slot”, “one-time seed only”, or “fresh crypto only”.
That is excellent operator hygiene.

### c) Replay chips with honesty
A replay pill should say whether exact replay is possible, capture-required, or intentionally unavailable.

### d) Repro rails
Wonderful and practical:
- insert deterministic env posture,
- compare before/after,
- run only after fresh review.

### e) Fresh-vs-deterministic compare decks
For flaky builds/tests, Schell could eventually show a side-by-side compare lane:
- same reviewed command,
- one deterministic rail,
- one fresh lane,
- bounded diff of outputs or receipts.

That is super-awesome and still smaller than freezing one global replay engine.

### f) Historical entropy receipts with claim-strength posture
Keep post-run evidence useful without turning old randomness facts into live authority.

## 7) Things Schell should refuse

### Refuse ambient-randomness-as-baseline
Randomness posture should be explicit, not invisible.

### Refuse fresh-equals-replayable folklore
Fresh crypto randomness and deterministic replay are different lanes.

### Refuse seed-collapse
One-time seed material, insecure seeds, and crypto random should not share one badge.

### Refuse raw-seed residue
Receipts, transcript cards, clipboard exports, and shared sessions should never persist raw seed bytes by default.

### Refuse stale-receipt-equals-live-entropy
Historical receipts should never impersonate current provider state.
