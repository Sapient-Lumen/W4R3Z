# Title witnesses, display labels, and override humility

This surface narrows one deceptively ordinary seam:
**window titles, tab titles, split/session labels, badges, and profile-derived names are fantastically useful orientation aids, but they should remain display labels and projections rather than quietly becoming exact host, cwd, peer, job, or live-state truth.**

The historical seam is old.
Xterm still recognizes OSC 0/1/2 for icon and window titles.
That is useful, but it is also proof that title text has always been easy for applications to emit.
Modern terminals then layer richer shell integration, title overrides, badges, and scriptable session names on top.
That makes the seam more useful and also easier to overclaim.

Schell should steal the comfort while keeping the truth smaller.

## 1) Titles are display labels, not exact identity

A title can summarize:
- current peer,
- cwd,
- foreground job,
- profile name,
- split role,
- danger posture,
- or restored historical context.

That is real value.
But a title is not the same thing as:
- exact peer witness,
- exact cwd witness,
- current live job truth,
- current provider-owned live state,
- or durable receipt.

The companion archive already pushes in this direction.
SlopOS keeps authority-bearing identifiers on smaller exact profiles and repeatedly refuses to let current live state collapse into historical receipts or descriptive labels.
Schell should treat title text the same way: **helpful label, weaker claim**.

## 2) Modern terminals already prove that visible title and shell title can diverge

Windows Terminal is unusually explicit here.
It lets the operator set `tabTitle` and suppress application title changes with `suppressApplicationTitle`, and its docs explicitly note that the shell's title variable may differ from the visible tab title.
That is not an edge case.
That is the truth model.

Ghostty 1.3 goes further by letting window and tab titles be set separately from split titles, and by exposing prompt-based or command-palette-based title overrides.
kitty similarly treats title management as a configurable shell-integration feature and allows turning shell-driven title updates off.
iTerm2's title system is even richer, with session names, profile names, job/user/host/PWD elements, badges, and script-provided titles.

So Schell should stop pretending there is one “the title”.
There are several nearby label lanes.

## 3) A compact title witness is enough

Schell does not need a huge naming subsystem to get this right.
A compact **title witness** could keep fields such as:
- `title_scope` — window / tab / split / session / badge / titlebar strip,
- `label_family` — profile-default / shell-emitted / terminal-derived / operator-override / restored / script-provided / imported,
- `source_strength` — exact-bound-summary / shell-known / renderer-local / historical / unknown,
- `binding_subject` — peer witness / cwd witness / job witness / profile / room / none,
- `override_posture` — none / operator-fixed / shell-active / renderer-derived / restored / inherited,
- `freshness_posture` — live / live-but-local / restored / historical / stale / unknown,
- `clear_rule` — on-focus / on-peer-change / on-command-change / manual / unknown,
- `transcript_summary` — plain text explanation suitable for logs.

That is enough to keep title comfort brilliant without freezing one final title protocol or scripting model.

## 4) Shell integration should strengthen labels, not turn them into identity

kitty's shell integration shows the right pressure.
It can set titles based on shell state and report cwd, but it also lets the operator disable title updates separately.
iTerm2 similarly uses shell integration to keep host/PWD/current job richer, including over SSH.
Ghostty's newer shell integration and prompt semantics make titles more accurate and more interactive.

That does **not** mean titles become identity.
It means titles can cite better witnesses.
The exact peer, cwd, or prompt state should still live in separately named objects.
The title should be a projection lane that can point back to them.

## 5) Overrides are a luxury worth stealing, but they need confession

One of the niftiest steals in this seam is title override.
An operator may want to label a tab `prod deploy`, `benchmark A`, `pairing`, or `watching logs`.
That is excellent local UX.
But an operator override should not quietly masquerade as shell-owned truth.

So Schell should make override posture visible:
- `operator title override`,
- `shell title`,
- `profile title`,
- `restored old title`,
- `script-provided title`,
- `remote helper title`.

That one confession solves a lot of hidden folklore.

## 6) Badges and interpolated labels are even weaker than titles

iTerm2 badges are a great warning and a great inspiration at the same time.
They can interpolate variables and be updated by proprietary escape sequences.
That is powerful.
It is also the perfect reason to keep badge text weaker than exact identity.

Interpolated labels, script-provided titles, and proprietary badge escape sequences should therefore stay explicitly decorative or orienting unless they cite stronger witnesses.
They are excellent ways to point at state.
They should not become the state.

## 7) Restore and attach need visible downgrade posture

This seam gets especially dangerous when titles persist.
A restored tab title may still say `prod` after the remote peer is gone.
A badge may still show an old git branch.
A split title may survive the job that originally authored it.

So restored/replayed labels should be able to say things like:
- `restored title`,
- `historical session name`,
- `stale badge`,
- `operator override still pinned`,
- `title no longer bound to live peer`.

That one downgrade family would make a custom shell+terminal much more trustworthy.

## 8) Great specimen moves that still stay decision-light

### a) Source chip on every strong title
A small chip such as `shell`, `override`, `restored`, or `profile` next to a title in manage/switch surfaces.

### b) Reveal-title card
Click a title to see what it is bound to: exact peer, cwd, job, or nothing.

### c) Clear override rail
If an operator set a local title, offer a quick `clear override` move and visibly restore shell-driven behavior.

### d) Copy label with witness
Copying a title should optionally include a compact witness note such as `title: operator override, bound to none`.

### e) Historical fade
Restored or detached sessions can keep their labels but wear a distinct `historical` posture.

## 9) The no-regret move

The best move right now is not to freeze one title protocol, one badge scripting language, one shell-integration title treaty, or one tab/window naming policy.
It is to pin one rule:
**Schell should model titles, badges, and session labels as title witnesses with explicit source, scope, override posture, and freshness, before display labels quietly become a second identity or live-state system.**

That keeps the archive free to defer:
- the final escape/control sequence family,
- the final title/badge scripting model,
- the final cross-terminal shell-integration treaty,
- the final restored-title policy,
- and the final layout of ambient label chrome.
