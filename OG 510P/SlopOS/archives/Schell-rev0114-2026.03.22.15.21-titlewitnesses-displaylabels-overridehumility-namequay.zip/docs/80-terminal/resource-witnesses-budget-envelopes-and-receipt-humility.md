# Resource witnesses, budget envelopes, and receipt humility

This surface keeps one boundary explicit:
**a great shell+terminal should let operators review launch envelopes, explicit budgets, and rich execution receipts — but it should not let hidden host limits, ambient payer folklore, live monitors, or post-run accounting impersonate one another.**

Modern systems already have real resource-control machinery:
- service managers can start transient resource-bounded units,
- cgroups and Job Objects can constrain or account for whole groups,
- shells can time pipelines and functions,
- external tools can emit richer accounting,
- cluster schedulers can show live and historical usage,
- and providers can attach budgets, quotas, or billing roots.

That is all worth stealing.
The failure mode is equally consistent:
- launch state stays hidden,
- payer identity gets guessed from context,
- limits and accounting get confused,
- live meters pretend to be final receipts,
- and host-specific limit vocabularies masquerade as portable shell truth.

Schell should steal the luxury while refusing the flattening.

## Core idea

Schell should probably distinguish at least eight nearby objects:

- **resource witness** — one reviewed launch-envelope summary for a command chapter or workflow step,
- **compartment baseline** — the default resource envelope for the active execution compartment,
- **override witness** — any explicit extra launch posture requested for this run,
- **budget witness** — explicit payer/kind/limit/scope/expiry posture when metered work is in play,
- **live usage deck** — optional current accounting/pressure view while work still lives,
- **limit event witness** — one bounded signal that a threshold, pressure, or hard ceiling was encountered,
- **usage receipt** — the post-run accounting artifact attached to the reviewed action outcome,
- **residue posture** — whether the runtime/accounting object persists, auto-collects, or becomes history-only.

Those objects are related.
They are not the same thing.

## 1) Resource witnesses should make the launch basis visible before run

A useful v0 **resource witness** probably needs fields like:
- `resource_witness_id`,
- `subject_ref` — exact chapter / reviewed command / workflow step,
- `compartment_posture` — default-compartment / transient-managed / host-unknown / degraded,
- `cpu_posture` — none / accounted / weighted / capped / unknown,
- `memory_posture` — none / accounted / soft-ceiling / hard-ceiling / unknown,
- `io_posture` — none / accounted / throttled / unknown,
- `process_posture` — none / counted / hard-ceiling / unknown,
- `scheduling_posture` — normalized / explicitly-raised / explicitly-lowered / unknown,
- `core_dump_posture` — disabled / profile-default / unknown,
- `payer_posture` — no-explicit-payer / explicit-budget / explicit-server-budget / unknown,
- `receipt_posture` — exact-outcome-only / outcome-plus-usage / provider-accounting-optional,
- `residue_posture` — auto-collect / keep-until-reset / history-only / unknown,
- `basis_ref?` — optional launch-basis digest or provider handle,
- `notes_ref?` — rationale, review note, or source explanation.

That is enough to support rich review UX without freezing:
- one final resource-control substrate,
- one cross-platform scheduler grammar,
- or one universal accounting schema.

## 2) Default compartment and explicit override should stay visibly distinct

A giant source of confusion is whether the command is simply entering the runtime's default envelope or a stronger transient envelope.
Schell should keep those separate.

### Default compartment posture
This is the ordinary launch baseline for the active execution compartment.
It may already carry provider-defined CPU/memory/IO/process ceilings.
That is fine.
But it should be sayable as **default compartment**, not disappear into host folklore.

### Explicit override posture
This is a stronger move:
- one transient managed unit,
- one stronger cap,
- one heavier accounting request,
- one deliberate change in scheduling or process-count posture,
- or one explicit resource-management lane.

This should feel like an extra reviewable fact, not an invisible side effect of “where I happened to launch from.”

## 3) Payer identity should stay separate from the execution subject

A command can run in one subject/context while charging a distinct payer root.
Schell should therefore avoid:
- deriving payer from session,
- deriving payer from cgroup/job/container membership,
- deriving payer from current directory, project, or tenant by default,
- or silently assuming the callee/server pays.

If a budget exists, the shell should show something like:
- budget kind,
- limit,
- scope,
- expiry,
- and maybe payer label/digest posture.

If no explicit budget exists, Schell should say that too.
“Unknown” or “no explicit payer witness” is vastly better than a flattering lie.

## 4) Live usage decks should stay weaker than final receipts

A live meter deck is extremely worth stealing.
Operators want:
- CPU/memory/IO/process graphs or rows,
- current pressure / limit-hit hints,
- cluster or unit usage while a job still lives,
- and progress-like visibility into resource burn.

But a live deck should remain visibly weaker than the final receipt.
A live deck does not prove:
- that the action finished,
- that current values will remain true a moment later,
- that a limit was or was not hit later,
- or that the present envelope is still exactly what the action was reviewed against.

So Schell should likely distinguish:
- **observe current usage**,
- **pin this live deck**,
- **export this usage receipt**,
- **inspect the reviewed launch witness again**,
- and **take a stronger action**.

## 5) Limit events should not overclaim outcome truth

Some systems have hard ceilings.
Some have advisory pressure.
Some have notifications that may be best-effort.
Some silently ignore over-limit attempts.
Those are not the same.

So a good **limit event witness** should probably say:
- what limit family it came from,
- whether it is advisory / threshold / hard-fail / kill / ignore-without-effect / unknown,
- what object emitted it,
- whether delivery is guaranteed or best-effort,
- and whether final outcome still needs a later usage receipt or exact exit receipt.

This is one of the nicest places Schell can beat old shell folklore.
Instead of one mysterious failure or one vague warning, the operator can get one properly scoped event and one separate final receipt.

## 6) Usage receipts should remain exact but bounded

A good **usage receipt** should be attached to one reviewed action and remain bounded.
It might include:
- exact exit status / signal posture,
- elapsed time,
- user/system CPU,
- optional peak memory,
- optional filesystem/socket I/O,
- optional allocation/step facts,
- optional limit-hit refs,
- optional provider-side accounting refs,
- and a claim-strength badge when accounting is partial or unavailable.

It should avoid pretending to prove:
- current live state,
- current quota availability,
- current service-manager unit existence,
- or current budget residue after later work happened.

## 7) Great ideas worth stealing right now

### a) Reviewed launch-envelope badges
Tiny but high-value:
- default-compartment,
- explicit transient override,
- explicit budget attached,
- richer accounting requested,
- auto-collect versus persistent residue.

### b) Exact “accounted versus limited” distinctions
This is wonderful operator hygiene.
Something can be:
- merely observed,
- hard-limited,
- soft-limited,
- counted only,
- or unknown.

That should be first-class copy, not buried in docs.

### c) Live usage decks with honesty badges
Show when accounting is:
- unavailable,
- partial,
- delayed,
- stale,
- provider-side,
- or exact-for-this-runtime.

### d) Budget countdowns and scope badges
Useful without locking in one billing stack.
The budget witness can stay small while still giving the operator valuable review truth.

### e) Separate chapter-level receipt and provider-side accounting addendum
This preserves exact reviewed-action truth while still allowing richer host/provider metrics.

### f) Residue posture badges
Did the transient managed object auto-collect?
Does the unit/job/accounting record persist?
Is the deck now historical only?
That is excellent shell+terminal honesty.

## 8) Things Schell should refuse

### Refuse ambient payer folklore
Session, cgroup, tenant, or project membership should not silently answer “who pays?”

### Refuse limit/accounting collapse
Being monitored is not the same as being constrained.

### Refuse live-deck-equals-receipt
Current usage is not the same thing as final outcome truth.

### Refuse post-run receipt-equals-current-state
A receipt is historical evidence, not current liveness or current resource headroom.

### Refuse one giant portable quota grammar too early
Linux cgroups, Windows Job Objects, cluster schedulers, and provider budgets are all real.
Schell does not need to flatten them into one premature universal ontology.

## 9) No-regret first specimen set

A compact first cut could show:
1. one reviewed launch card with explicit CPU/memory/IO/process/scheduling/core-dump posture,
2. one default-compartment versus explicit-override badge,
3. one explicit budget witness with kind/limit/scope/expiry posture,
4. one live usage deck that confesses when accounting is partial or unavailable,
5. one limit event witness that stays weaker than the final outcome receipt,
6. one final usage receipt with exact runtime/exit plus optional richer accounting fields,
7. one refusal to infer payer from job/cgroup/container membership,
8. and one refusal to treat a stale live deck as current envelope proof.

That is enough to make Schell feel substantially more awesome at resource truth without freezing one final scheduler, meter, or accounting substrate.

## 10) The no-regret move

The best move right now is not to freeze one universal quota or scheduling framework.
It is to pin one rule:
**resource comfort in Schell should become explicit launch-envelope witnesses, explicit payer/budget posture, live usage decks, limit-event witnesses, and bounded usage receipts before it becomes hidden host folklore or fake portability theater.**
