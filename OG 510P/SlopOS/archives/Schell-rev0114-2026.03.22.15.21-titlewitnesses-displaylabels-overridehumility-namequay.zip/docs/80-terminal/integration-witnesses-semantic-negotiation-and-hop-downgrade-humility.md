# Integration witnesses, semantic negotiation, and hop-downgrade humility

This surface keeps one especially useful seam explicit:
**semantic shell integration is worth stealing aggressively, but it should remain a visibly negotiated capability with named authorship, verification, and hop posture rather than a hidden second shell.**

Schell already has shell-known packets, shell-integration marks, capability-ground cards, remote-hop witnesses, prompt/input authorship posture, and startup-footing humility.
This pass narrows the seam those surfaces still leave open:
**how should the shell+terminal talk about semantic prompt/input/output integration itself once remote hops, wrappers, muxes, injected helpers, terminfo workarounds, and heuristic fallback all enter the picture?**

## 1) The best modern shell-integration ideas are real and worth stealing

The current ecosystem keeps proving that a terminal becomes much better once the shell tells it:
- where prompts start and end,
- where the live editable input really is,
- where command output begins and ends,
- what the exact command line was when the shell can attest it,
- and what working directory / peer context belonged to that command.

That unlocks genuinely excellent luxuries:
- jump-to-prompt,
- select/copy one command's output,
- restrict search/filter to one command chapter,
- prompt-local click-to-move,
- more accurate resize/redraw behavior at the active prompt,
- better command recall,
- and richer command-local cards.

Schell should absolutely steal that cluster.

## 2) The old failure is not “semantic integration exists”

The old failure is letting the operator forget **how** the terminal learned those semantics.
Current systems get there through different means:
- shell-native prompt marking,
- user-installed shell integration,
- terminal-injected startup hooks,
- helper-wrapped `ssh` / `sudo` flows,
- copied remote terminfo,
- mux passthrough or translation,
- terminal-local heuristics,
- or partial compatibility with a nearby escape-sequence family.

Those are not the same kind of truth.
If Schell flattens them, then click-to-move, command selection, and chapter navigation become another ambient authority story.

## 3) One integration witness is worth more than vague shell-integration folklore

A compact **integration witness** could keep at least:
- `integration_family` — native-shell / FinalTerm-OSC133 / VSCode-OSC633 / iTerm-style / local-proprietary / none / unknown,
- `source_posture` — shell-built-in / explicit-addon / terminal-injected / wrapper-installed / mux-relayed / remote-installed / heuristic / unknown,
- `verification_posture` — shell-authenticated / nonce-verified / transport-marked / unverified-marked / heuristic / restored / unknown,
- `transport_posture` — direct-pty / mux-pass / mux-translate / ssh-wrapper / remote-shell / replay / imported,
- `hop_path[]` — local shell, mux, ssh wrapper, remote shell, nested shell, etc.,
- `active_features[]` — prompt marks / exact command line / cwd reports / output regions / click-to-move / selection / jump-to-prompt / finish hints,
- `blocked_features[]` — strong actions currently suppressed because verification or transport posture is weaker,
- `terminfo_posture` — native / copied / fallback-brand / helper-projected / unknown,
- `downgrade_reason[]` — exact short confessions such as “exact command line unavailable”, “shell marks relayed through mux only”, “remote TERM fallback active”, or “markers present but unverified”,
- `transcript_summary` — one portable one-line explanation.

This is smaller than a final protocol.
It is just enough to keep semantic integration from becoming hidden startup folklore.

## 4) The shell-integration ladder should be explicit

Schell should probably name a ladder like this:

1. **native shell-authenticated** — the shell itself emits and owns the live prompt / command / output truth.
2. **explicit reviewed addon** — a user-installed shell package adds marks and metadata under visible startup footing.
3. **terminal-injected integration** — the terminal injects reviewed helper code, but this remains weaker than native shell truth.
4. **adapter-relayed** — a mux or bridge preserves/relays semantic marks, possibly with some loss.
5. **remote-wrapper assisted** — helper-wrapped `ssh` / remote install / copied terminfo make the session more comfortable, but the comfort depends on explicit helper posture.
6. **heuristic fallback** — the terminal grouped things locally, but exact command/input truth is not attested.
7. **plain legacy** — no semantic integration beyond plain terminal behavior.

The key design lesson is simple:
**every step down the ladder should reduce what the terminal claims, not just how pretty it looks.**

## 5) Exact command line is stronger than prompt marks alone

Prompt/input/output marks are valuable.
A separately attested exact command line is stronger.
Current tools keep proving why:
- a shell may mark command boundaries without providing the exact interpreted command line,
- the terminal may infer the command from prompt boundaries alone,
- markup may cross remote/mux boundaries imperfectly,
- and visible buffer text may not be the same thing as what the shell finally interpreted.

So Schell should treat at least three nearby truths separately:
- marked command region,
- exact reviewed/accepted command line when attested,
- and renderer-local inference when the stronger truth is absent.

That keeps pretty command blocks from outranking parser truth.

## 6) Remote and mux comfort should stay honest about borrowed help

Modern terminals increasingly help across hops by:
- wrapping `ssh`,
- copying terminfo remotely,
- setting remote environment fallbacks,
- relaying shell integration,
- or translating features across muxes.

That is useful.
It is also a real change to session footing.
Schell should therefore make those helps visible rather than treating them as native continuity.

Important distinctions to keep named:
- native remote support vs remote helper install,
- copied terminfo vs fallback `TERM` brand,
- direct shell marks vs mux-relayed marks,
- shell-authenticated active prompt vs guessed active prompt,
- and local terminal comfort vs portable transcript truth.

## 7) Strong actions should gate on verification posture, not on chrome alone

Integration witnesses should gate what becomes available.
A good compact rule is:
- **heuristic / unverified** integration may support navigation, copy, search restriction, or insert-first recall,
- **marked / transport-known** integration may support better chapter selection, prompt jumps, and command-local browsing,
- **shell-authenticated or nonce-verified** integration may unlock stronger exact-command review, safer compare-after-run, and higher-confidence command-local actions,
- **restored / imported** integration stays visibly historical until live truth is reacquired.

No case should allow semantic chrome alone to widen execution authority.

## 8) The right “super awesome” move is not more protocol — it is better confession

A great shell+terminal could feel dramatically better with a few small additions:
- an always-available `why does this command block work here?` reveal,
- a hop strip that shows local -> mux -> ssh-wrapper -> remote shell posture,
- a downgrade badge that explains why click-to-move or exact command review is disabled,
- a terminfo footing chip that admits native / copied / fallback posture,
- and one debug overlay or inspector that makes semantic zones visible to shell developers.

That is a no-regret move because it improves operator trust and implementer debugging without freezing the final transport or protocol family.

## 9) The compact design-phase answer

Schell should steal semantic prompt/input/output luxury hard.
But it should keep a tighter accounting of how that luxury became available.

The smallest strong import is:
- one integration witness,
- one explicit semantic-integration ladder,
- one per-hop downgrade confession,
- one separate field for exact command-line attestation,
- and action gates that depend on verification posture rather than on renderer confidence.

That keeps the shell+terminal exciting while the architecture is still in motion.
