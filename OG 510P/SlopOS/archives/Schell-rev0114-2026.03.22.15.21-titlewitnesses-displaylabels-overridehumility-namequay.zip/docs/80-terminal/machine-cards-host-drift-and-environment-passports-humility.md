# Machine cards, host drift, and environment passports humility

This surface exists to keep one especially tempting portability myth honest:
**Schell should become excellent at carrying work across laptops, remotes, containers, codespaces, and project-local shells — but it should do that by separating machine truth, runtime truth, environment-spec truth, overlay truth, and approval-basis truth, because “same dev environment” is not one fact.**

The point is not to avoid portable developer comfort.
The point is to make it legible enough that the shell still knows what actually happened.
A custom shell+terminal can be genuinely better than current tools here if it refuses to let environment metadata blur into host identity, blur into user overlays, or blur into exact reviewed footing.

## 1) Keep the machine smaller than the environment and the environment smaller than the chapter basis

At minimum Schell should separate:
- **machine card** — summary of where work is running,
- **runtime card** — local process / container / VM / remote host / hosted workspace / browser-backed attach,
- **environment passport** — project-owned environment spec, lock refs, and activation family,
- **overlay ladder** — user dotfiles, editor settings, session overrides, forwarded env, helper-injected extras,
- **hook provenance** — what executed on host/init/prompt/attach/runtime activation,
- **approval basis** — exact bytes or bounded refs that were actually reviewed,
- **attestation/provenance** — stronger evidence about the substrate when available,
- **drift posture** — whether current footing still matches the footing a prior command assumed.

These objects are adjacent.
They are not interchangeable.

## 2) A machine card should describe real footing

A healthy machine card should carry compact truth such as:
- `machine_posture` — local / remote / hosted / containerized / layered / historical,
- `runtime_kind` — native-process / container / vm / remote-backend / browser-attach / unknown,
- `host_class` — local-laptop / ssh-host / remote-vm / codespace-vm / devcontainer-on-local / devcontainer-on-remote / unknown,
- `trust_posture` — user-owned / org-owned / imported / low-detail / unknown,
- `path_posture` — local-tree / bind-mounted / copied-clone / remote-volume / forwarded-view / unknown,
- `locality_posture` — executes-here / executes-remote / thin-client / mixed / forwarded-localhost / unknown,
- `resource_shape` — optional summary of CPU/memory/storage tier or unknown,
- `identity_strength` — descriptive-summary / exact-machine-ref / attested-ref / historical / unknown.

That already gives Schell much more honest portability footing without freezing a final host-identity stack.

## 3) An environment passport should be first-class, not implied by a prompt

An environment passport should probably say at least:
- project spec family (`devcontainer`, `nix develop`, `devenv`, `devbox`, `direnv`, native Schell pack, imported snapshot, unknown),
- source refs (config file path, lockfile ref, digest when known),
- activation family (one-shot build shell / prompt-time hook / attach-time personalization / background helper / none),
- overlay contributors (user dotfiles, editor settings sync, session overrides, forwarded env, helper-installed features),
- runtime user posture (container user, remote user, host user, unknown),
- and freshness/drift posture (same lock / same spec but unlocked / discovered parent config / historical / unknown).

That keeps “shell looks right” from becoming the whole story.

## 4) Overlay ladders should stay visible and ordered

Current tools repeatedly widen environments in layered ways:
- project metadata defines the nominal environment,
- runtime tooling adds features or installs extensions,
- host lifecycle hooks may run before attach,
- user dotfiles or settings personalize the result,
- forwarded env values bridge local context into the runtime,
- and session-local overrides can sit on top.

Schell should make those overlays explicit in order:
1. project spec,
2. project lock or resolved package set,
3. runtime creation choices,
4. host-side init hooks,
5. runtime-local init hooks,
6. user overlays,
7. session overrides,
8. helper-added transient context.

That is much better than pretending the final prompt is all one smooth native truth.

## 5) Hook provenance beats “it just happened somehow”

One of the best upgrades Schell can make is to name hook families instead of burying them.
A hook provenance card should be able to say:
- host initialize hook ran,
- runtime setup hook ran,
- prompt-time activation currently active,
- attach-time personalization applied,
- background helper updated environment summary,
- or unknown imported startup behavior.

That gives the operator one honest answer to “why is PATH / PS1 / user / cwd / forwarded port / env different here?”

## 6) Host drift should degrade claims rather than surprise later

A previous command or saved workflow may have been reviewed under:
- the same project spec,
- a different machine class,
- the same runtime kind but different host,
- the same codespace/devcontainer definition but different resources,
- or a local path layout rather than a remote copy.

So Schell should prefer compare-ground language such as:
- same spec,
- same spec and lock,
- same runtime kind,
- same host class,
- same exact footing,
- historical match only,
- or unknown.

That prevents portable comfort from silently becoming fake sameness.

## 7) Thin-client honesty needs its own badge family

Remote IDEs, browser-backed workspaces, and hosted dev environments can feel wonderfully local.
That is a feature.
It should still stay explicit.
Schell should be able to say:
- editor local, execution remote,
- filesystem remote,
- extensions remote,
- localhost forwarded,
- machine tier imported from provider,
- host access limited,
- or runtime local but orchestrator remote.

That makes remote comfort more trustworthy, not less magical.

## 8) Environment passports should compose with earlier surfaces

This seam should not replace earlier work.
It should compose with it:
- execution ground packets can include machine/runtime/passport refs,
- remote-hop surfaces can point to machine cards instead of vague peer labels,
- filesystem witnesses can say whether a tree is bind-mounted, copied, or remote-volume backed,
- approval or rerun surfaces can compare current footing against historical footing,
- publication or collaboration surfaces can show whether an artifact came from local, hosted, or imported work,
- and borrowed-authority surfaces can explain when thin-client comfort is spending local power from a remote lane.

That is how the shell+terminal keeps getting smarter without becoming blurrier.

## 9) A strong first proving slice

A compact first specimen should show:
1. one local native machine card and environment passport,
2. one devcontainer-backed card with containerEnv vs remoteEnv differences,
3. one codespace or hosted remote machine card with limited-host-access posture,
4. one thin-client remote-backend card,
5. one direnv-style prompt-time activation badge,
6. one Nix/Devbox/devenv-style explicit environment passport with lock or profile refs,
7. one user-dotfiles/settings overlay badge,
8. one host-drift downgrade from “same spec” to “different machine class”,
9. one forwarded-localhost badge,
10. one rerun refusal or downgrade because footing no longer matches,
11. and one machine/passport summary that stays visibly weaker than stronger attested or reviewed basis truth.

That is already enough to make Schell feel unusually capable without freezing the final environment schema, import protocol, or portability engine.

## 10) Things to refuse for now

Refuse for now:
- one generic “same environment” badge,
- project metadata acting as proof of host or privilege sameness,
- prompt appearance acting as proof of activation provenance,
- user dotfiles/settings quietly becoming project truth,
- and remote thin-client comfort or forwarded localhost acting as proof that the work is actually local.

The right law is:
**steal portable developer luxury, but keep machine truth, environment truth, overlay truth, and stronger evidence separately named.**
