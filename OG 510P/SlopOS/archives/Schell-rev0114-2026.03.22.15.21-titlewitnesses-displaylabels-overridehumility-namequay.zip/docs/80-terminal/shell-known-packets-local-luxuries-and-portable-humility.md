# Shell-known packets, local luxuries, and portable humility

This surface records one especially promising move for Schell:
**make the shell attest a compact packet family, then let the terminal become wonderfully rich on top without pretending the chrome is the truth.**

These are candidates, not commitments.

## 1) The past mistakes we should refuse again

A new shell+terminal should not repeat these old failures:

- hidden parsing paths that turn one reviewed command into a different executed command,
- rc/profile/directory-hook startup that silently widens authority,
- history/search/palette rows that behave like approved reruns,
- previews and clicks that silently become open/run authority,
- restored sessions that impersonate live truth,
- transcripts that impersonate omniscient recording,
- and terminal-local protocol cleverness that becomes a hidden correctness dependency.

If Schell gets those wrong, “super awesome” will quickly become “flattering but unsafe.”

## 2) The key design split

The terminal should be allowed to be luxurious.
The shell should remain the authority-bearing truth source.

That suggests a compact split:
- **shell-known packets** carry exact, portable-enough truth,
- **local luxuries** consume those packets for humane UX,
- **portable transcript truth** remains understandable without the luxury layer,
- and **restored/imported/replayed** material stays visibly weaker than fresh live state.

## 3) Candidate shell-known packet family

Do not freeze this as final protocol yet, but the current cluster looks promising:

### a) Prompt lease packet

Names:
- there is exactly one active editable input lease,
- where the editable span begins and ends,
- whether click-to-move is valid right now,
- and whether the visible prompt is live, restored, or historical.

This packet could unlock active-prompt click, safer cursor placement, and exact insert targets.

### b) Command chapter packet

Names:
- accepted input,
- command start,
- command end,
- outcome grade,
- and maybe coarse timing markers.

This packet could unlock jump-to-command, output folding, command palettes, command-finish notices, and trustworthy copy/output actions.

### c) Chapter metadata witness

Carries compact chapter-local evidence such as:
- cwd witness,
- peer/domain witness,
- execution-ground witness,
- authorship/source badge,
- trust/confidence grade,
- and restored/imported/replayed status.

This is the layer that can keep semantic history useful without pretending it is live authority.

### d) Object anchor packet

Lets visible paths, URLs, digests, refs, and chapter outputs become typed anchors with inspect / insert / reveal / safe-open ladders.
This should stay weaker than approval and weaker than helper/session choice.

### e) Finish-notice eligibility packet

Lets the shell say whether a finished action crossed a threshold or asked to be watched.
That is better than terminal-local folklore around bells and window state.

## 4) Local luxuries worth stealing now

Once those packets exist, a lot of great UX becomes possible without extra ambient magic:

### Active-prompt click

Ghostty-style click-to-move in the active prompt looks worth stealing, but only inside the live prompt lease.
Historical prompts should stay historical.

### Semantic history with cwd truth

iTerm2-style working-directory-aware navigation is worth stealing.
But chapter recall should usually land into input or review, not run.

### Insert-first command summon

VS Code run-recent-command and Warp workflows both suggest the right shape:
searchable summon surfaces that paste into editable input and keep argument editing obvious.

### Focused parameter help and richer display rows

Completion should be able to show a value, a description, a display override, a source badge, and a trust grade without forcing execution.
Repeated parameters should support synced cursors or slot-wise editing where that helps.

### Thresholded finish notices

Long-running work should be able to notify when it actually matters, especially when unfocused.
That is a wonderful luxury as long as it is not mistaken for a durable receipt.

### Restored-session landing cards

Session resurrection and reopen are genuinely useful.
But the landing card should say exactly what is restored, what is historical, what needs reacquisition, and what surfaces are safe first.

### Review/inspect key tables

Mode tables for review, transcript inspection, and chapter navigation look worth stealing.
But mode tables should remain local productivity layers, not the only path to correctness.

## 5) What makes this “super awesome” without overcommitting

A shell+terminal becomes dramatically better when it can:
- jump exactly to the last real command chapter,
- move the cursor inside the one live prompt as if it were a real editor,
- search prior commands and workflows with rich badges,
- recover a crashed or paused workspace with explicit restored-state honesty,
- notify about meaningful completion without lying about receipts,
- and turn visible output into typed object anchors without collapsing into click-to-run folklore.

None of that requires freezing one renderer, one mux, one escape dialect, one sync engine, or one agent architecture.
It only requires a compact shell-known fact plane plus disciplined local luxuries.

## 6) Refusals that keep the luxury honest

Even if the terminal becomes extraordinary, keep these refusals:
- no rerun because a block merely looks command-like,
- no session-resurrection badge that counts as live peer truth,
- no preview/open helper that silently chooses stronger handling,
- no raw transcript that counts as replay permission,
- no protocol feature that must exist for the shell to stay legible,
- and no ambient startup or dynamic-generator behavior hidden behind convenience.

## 7) Current consequence for Schell

The best next move is not a giant terminal-protocol manifesto.
It is a smaller ratchet:
1. name the shell-known packet family,
2. keep the local luxuries explicit and optional,
3. grade trust/confidence/historical posture everywhere,
4. land summon/history/workflow results into input or review first,
5. and treat restored/replayed/imported material as visibly weaker than fresh live truth.

That is enough to make Schell feel far better than legacy terminals while still learning in public and keeping major architectural choices open.
