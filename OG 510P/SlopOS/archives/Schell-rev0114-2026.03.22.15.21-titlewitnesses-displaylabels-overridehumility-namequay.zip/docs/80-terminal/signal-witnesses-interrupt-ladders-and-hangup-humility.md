# Signal witnesses, interrupt ladders, and hangup humility

This surface names another old shell lie that still hurts modern terminals:
**`Ctrl-C`, `Ctrl-Z`, `kill`, `disown`, `nohup`, detach, and durable promotion are nearby actions, but they do not mean the same thing and should stop sharing one vague “stop this thing / keep this thing” folklore story.**

The ecosystem still shows the scar tissue.
Bash job control depends on terminal process groups and signal delivery.
fish keeps `fg`, `bg`, `wait`, `disown`, and `suspend` separate.
zsh adds options like `CHECK_JOBS`, `CHECK_RUNNING_JOBS`, `HUP`, and `AUTO_CONTINUE`, which is useful proof that even mature shells still need extra knobs because the old surface collapses too much.
`nohup` is not supervision.
`setsid` is not review.
`systemd-run --scope` and `systemd-run` service mode are not the same continuation story.

Schell can do much better by keeping the ladder small and explicit.

## 1) Interrupt is not terminate, and terminate is not durable promotion

A humane shell+terminal should begin with one visible ladder:
- **interrupt-request** — ask the current foreground claimant or bound work item to stop cooperatively if that is what the local stack maps `Ctrl-C` to,
- **suspend-request** — stop and return tty ownership without pretending the work is finished,
- **wait-only** — keep watching without reasserting foreground ownership,
- **hangup-sever** — sever shell/session continuity without pretending the work is now durable,
- **terminate-request** — ask for stronger stop than interrupt,
- **force-kill** — make an intentionally brutal move,
- **promote-durable** — move the work under an explicit detached/supervised owner,
- **restore-historical** — reopen a view on what happened without claiming live control.

The point is not to force one host signal vocabulary.
The point is to stop one tiny set of shell gestures from carrying all meanings at once.

## 2) The target of a stop request should be witnessed, not guessed

A shell+terminal often knows several nearby candidates:
- the **foreground tty claimant**,
- a **shell-tracked background job**,
- a **detached task shelf item**,
- a **promoted supervisor unit**,
- a **remote peer lane**,
- or only **historical residue**.

Those should not all accept the same stop affordance with the same strength.
A `Ctrl-C` in a live foreground lane is different from clicking “stop” on a promoted durable task.
A kill action inside a mux pane is different from killing the pane.
A hangup on shell exit is different from a reviewed terminate request.

So Schell should keep a compact target witness:
- `target_family`,
- `target_strength`,
- `delivery_posture`,
- `origin_posture`,
- `continuity_owner`,
- `durability_posture`,
- `expected_outcome_family`.

That already answers the questions the classic shell leaves fuzzy:
- who is about to receive this stop request?
- is this a keyboard-generated terminal signal, a shell-owned cancel request, a supervisor terminate, or only a local helper action?
- will this break continuity, preserve continuity, or promote continuity?

## 3) Hangup is a continuity fact, not a durability guarantee

Old shell folklore still overclaims here.
`disown` weakens shell knowledge.
`nohup` ignores `SIGHUP` and redirects output, but it does not create supervision.
`setsid` creates a new session, but it does not by itself create reviewed policy or durable ownership.
A detached mux pane remains a mux continuity story.
A transient service or scope under a service manager is a different kind of story again.

So Schell should stop letting “keep running when I leave” collapse into one vague promise.
A smaller set of explicit operator verbs is better:
- **disown shell tracking**,
- **ignore hangup**,
- **detach into workspace/mux continuity**,
- **promote into supervised durability**.

That is already much more honest than shipping a clever `&` story and hoping users infer the rest.

## 4) The terminal can become super awesome by making the stop ladder visible

Some stealable luxury moves:

### a) A stop card instead of one blind interrupt key
A compact card can show:
- current foreground owner,
- last signal/cancel request,
- what the next stronger move would be,
- and what continuity will look like afterward.

### b) One-click escalate ladder
If interrupt did nothing, Schell can offer:
- interrupt again,
- terminate,
- force kill,
- or promote/detach instead.

That is much better than teaching operators to reach for `kill -9` folklore early.

### c) Exit with jobs truth
Instead of one vague shell-exit warning, show:
- shell-tracked background jobs,
- disowned work,
- detached mux continuations,
- promoted supervisor units,
- and historical-only residue.

### d) Wait versus reattach
A command chapter should let the operator choose:
- wait for completion,
- foreground/reacquire tty,
- inspect output only,
- sever continuity,
- or promote durability.

### e) Outcome family instead of magic exit codes
Receipts should say things like:
- completed,
- interrupted,
- suspended,
- terminated,
- hangup-severed,
- force-killed,
- promoted,
- detached,
- unknown-after-sever.

That is more honest than leaving users to decode signal conventions from `130` or `143` alone.

## 5) The SlopOS pressure is excellent here

The companion already says:
- portable capshell cancellation should stay on explicit request/workflow seams instead of a portable signal-control plane,
- job control should not become a hidden PTY/controlling-terminal authority story,
- launch should not inherit ambient signal-state folklore,
- and durable interruption belongs on separately named attention/lease/portal seams rather than transient notification hints.

That pressure suggests a good Schell answer:
**local signal details may exist, but the operator-facing shell+terminal story should still be framed as explicit cancel/stop/terminate/promote witnesses rather than raw signal folklore.**

## 6) The no-regret move

The best move right now is small:
**add a signal-witness family that keeps interrupt, suspend, hangup, terminate, force-kill, detach, and promote separately named, with explicit target and continuity posture, while leaving the final POSIX/non-POSIX delivery mechanisms open.**

That keeps open:
- the final local signal mapping,
- the final remote/mux translation story,
- the final supervisor backend,
- the final command receipt vocabulary,
- and the final cross-platform stop semantics.
