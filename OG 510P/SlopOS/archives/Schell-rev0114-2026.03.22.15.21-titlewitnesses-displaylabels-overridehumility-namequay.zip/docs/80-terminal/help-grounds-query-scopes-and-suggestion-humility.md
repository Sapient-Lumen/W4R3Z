# Help grounds, query scopes, and suggestion humility

This surface exists to keep one increasingly tempting shell myth honest:
**Schell should become dramatically better than classic shells at helping people discover commands, flags, examples, fixes, and adjacent actions — but it should do that by separating command inventory, normative help, examples, predictions, previews, and action offers, because “the shell showed me this” is not the same fact as “this is the exact command basis I reviewed and meant to run.”**

The point is not to avoid guidance.
The point is to keep guidance truthful enough that the shell still knows what kind of help it is providing.
A custom shell+terminal can be super awesome here if it treats discovery as a family of grounds rather than one flattering suggestion stream.

## 1) Keep help smaller than execution truth

At minimum Schell should separate:
- **command inventory** — what commands or actions appear reachable in the current footing,
- **help ground** — where the explanation came from,
- **example card** — practical usage snippets that may be useful without being normative,
- **prediction stream** — history/plugin/model-derived guesses about what the user may want,
- **preview card** — inert rendering of what a command/help/example/result appears to be,
- **quick-fix offer** — a narrower proposed edit, subcommand correction, missing flag hint, or install/remediation suggestion,
- **action offer** — a typed next step such as open/help/export/share/install/search,
- **review basis** — the exact command/action bytes actually approved.

Those objects are adjacent.
They are not interchangeable.

## 2) A help ground should name its source family and strength

A healthy help ground should probably carry compact truth such as:
- `source_family` — native-spec / builtin-help / manual-page / example-page / history / plugin / bridge / project-pack / team-pack / imported / unknown,
- `scope` — current-command / current-shell / current-project / current-view / user-shelf / system-wide / remote-provider / unknown,
- `claim_strength` — exact-native / doc-derived / example-only / history-derived / heuristic / imported / historical / unknown,
- `freshness_posture` — current-local / provider-current / cached / historical / unknown,
- `execution_posture` — inert-preview / copy-to-input / suggestion-only / prompt-required / exact-reviewed / unknown,
- `routing_posture` — local-help / local-query / remote-doc / imported-pack / unknown.

That already gives Schell a much more honest discovery story without freezing one final docs engine, example corpus, or prediction stack.

## 3) Queries should be scoped, not ambient

The most important discovery law may simply be this:
**search must know what universe it is searching.**

Schell should therefore prefer explicit query scopes such as:
1. current command family,
2. current shell builtins,
3. current project/workflow pack,
4. current capability view / current workspace,
5. user shelf,
6. imported team/runbook packs,
7. system manuals/examples,
8. explicitly remote sources.

That is much safer than one ambient “search everything the machine knows” gesture.
It also fits the rest of the archive better, because scope is where authority and metadata leakage usually start.

## 4) Predictions should carry source chips and stay weaker than approval

Modern predictive help is clearly worth stealing.
But Schell should make prediction sources visible:
- history,
- native command signatures,
- plugin predictor,
- project workflow pack,
- imported runbook,
- external example corpus,
- unknown bridge.

A prediction chip should answer two questions at a glance:
- **why am I seeing this?**
- **what kind of truth is this?**

Predictions should usually support:
- accept next word,
- accept whole suggestion,
- preview before accept,
- pin to workflow seed,
- hide this source,
- or downgrade to plain input.

What predictions should *not* quietly do by default is cross the line from “suggested” to “executed”.

## 5) Command-not-found and typo repair should begin as observation-only

Classic shells and CLIs keep showing that typo help is useful and auto-execution is risky.
Schell should therefore prefer a default ladder like:
1. **show near matches**,
2. **show help/example grounds**,
3. **show exact diff from what was typed**,
4. **offer copy-to-input or replace-in-buffer**,
5. **offer typed next actions** such as install/search/open-manual,
6. **require a fresh approval** before any mutation or execution.

That posture keeps discovery pleasant without laundering guessed intent into shell truth.

## 6) Preview-first choosers are a huge luxury if they stay inert

Previewable search is one of the best things current command-line ecosystems have invented.
Schell should absolutely steal:
- fuzzy recall,
- ranked search results,
- inline previews,
- inert example rendering,
- and browse-first choosers for commands, flags, docs, history, directories, and runbooks.

But previews should stay visibly weaker than live execution.
A preview card should say whether it is:
- static text,
- derived example,
- command synopsis,
- local manual excerpt,
- historical command,
- remote page summary,
- or unknown imported rendering.

That keeps “looked right in the chooser” from becoming the whole authority story.

## 7) Example pages should complement normative help, not replace it

One of the nicest discovery moves available is to treat examples as a separate object family.
Schell should therefore keep:
- **normative help** for signatures, flags, argument meaning, and exact command identity,
- **example pages** for common tasks,
- **workflow seeds** for reusable project/team recipes,
- and **historical examples** from the user’s own prior work.

That lets the shell be friendly without pretending that a handy example page is always the normative definition of a command.

## 8) Bridged discovery surfaces need provenance too

Completion and help bridges are extremely attractive because they let one ecosystem borrow another.
Schell should support that — but it should tag bridged help and bridged completion as exactly that.

A bridged discovery card should say:
- native / bridged / imported,
- bridge family,
- startup or latency consequences,
- parsing confidence,
- and downgrade behavior.

That makes cross-ecosystem reuse possible without pretending every borrowed completion or help surface is first-class native knowledge.

## 9) “Why this suggestion?” should be a first-class answer

One of the most delightful things Schell can do is explain a suggestion without making the user leave the input line.
For any offered help/prediction/quick-fix, Schell should be able to say:
- matched command description,
- matched example tags,
- came from recent history,
- came from project pack,
- came from imported team pack,
- came from bridge,
- matched typo edit distance,
- or unknown.

That one reveal already turns a magical guess into a reviewable suggestion.

## 10) A compact first proving slice

A strong first specimen set would show:
1. one command inventory card for the current shell footing,
2. one help search result with explicit query scope,
3. one exact-native help card beside one example-only card,
4. one history-based prediction chip beside one plugin/project-pack chip,
5. one typo-repair offer that edits the buffer but does not auto-run,
6. one command-not-found card with install/search/help offers kept separate,
7. one preview-first fuzzy chooser with inert previews,
8. one bridged completion/help card that stays visibly weaker than native,
9. one workflow-seed card beside ordinary examples,
10. one refusal to let a prediction, example, or preview pose as exact approval basis,
11. and one capability-scoped query example that stays smaller than an ambient global index.

That is already enough to make Schell feel unusually capable without freezing the final docs engine, learning model, bridge layer, ranking engine, or query substrate.

## 11) Things to refuse for now

Refuse for now:
- one undifferentiated suggestion lane,
- ambient global search with unclear scope,
- history or plugin predictions posing as reviewed commands,
- example pages posing as normative command identity,
- bridged completions/help posing as native truth,
- and typo repair or command-not-found help auto-running by default.

The right law is:
**steal search, examples, predictions, and preview luxury — but keep help ground, query scope, suggestion source, and exact approved action separately named.**
