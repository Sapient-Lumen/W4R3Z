# Secret witnesses, reveal ladders, and masking humility

This surface names another place where a shell+terminal can become genuinely great or quietly reckless:
**secret-bearing work should feel much better than today’s shells, but secret reference, secret use, secret materialization, literal reveal, masking, and export are different moves and should stay different.**

Schell can become super awesome here.
It can make credentials, tokens, passwords, signing keys, and app seeds much easier to route safely.
But it should not import the old habit where a secret briefly appears as plain text in a prompt, flows through scrollback, lands in history, leaks into support logs, or rides an SSH hop under the comforting story that it was “only in the terminal for a second.”

## 1) Secret handling is not one thing

At least six nearby lanes exist:
- **reference** — a durable ref, item handle, vault path, or secret slot placeholder,
- **proxy use** — the secret stays behind an agent, provider, or handle while an operation happens,
- **ephemeral materialization** — the secret becomes bytes for one child process, one file descriptor, one short-lived file, or one execution ground,
- **local review insertion** — the current command line or review card holds a secret-bearing parameter slot without necessarily exposing the literal value,
- **literal reveal** — the bytes are shown directly to the operator,
- **copy/export/share** — the bytes leave the current review context toward clipboard, transcript, remote peer, file, or share surface.

Those lanes overlap.
They should not collapse.
A secret reference is not a secret reveal.
A proxy-sign request is not permission to copy a key.
A masked log line is not proof that a transcript sink is now safe.
A one-child environment injection is not the same as a durable secret slot in history.

## 2) Schell should mint a small secret witness family

A good first move is not a giant terminal vault.
It is one shell-owned **secret witness** family that lets the shell and terminal name what kind of secret-bearing surface is in play.

A v0 secret witness could keep:
- `subject_ref` — active input / parameter slot / execution ground / object card / output capsule / transcript card / clipboard offer / remote hop,
- `secret_kind` — password / token / key / app-seed / opaque-bytes / ref-only / unknown,
- `origin_posture` — literal-input / pasted / imported / vault-ref / handle / derived / remote-proxy / unknown,
- `materialization_posture` — none / child-env / fd-or-pipe / temp-file / service-credential-dir / provider-handle / local-rendered / clipboard / unknown,
- `sink_posture` — history-forbidden / transcript-scrubbed / transcript-forbidden / clipboard-blocked / remote-peer-visible / export-forbidden / unknown,
- `freshness_posture` — current / restored / imported / historical / scrubbed / unknown,
- `reveal_posture` — hidden / masked / one-shot-peek / local-literal / exported-literal / unknown,
- `authority_posture` — review-only / proxy-use-allowed / explicit-reveal-needed / explicit-export-needed / unknown.

That is enough to ground secret handling without freezing one secret manager, one SSH agent protocol, one clipboard architecture, or one final classification taxonomy.

## 3) The strongest design lesson: use and reveal must stay different

The past keeps teaching this.
The best secret UX is often not “show the secret more safely.”
It is **avoid literal reveal in the first place**.

Schell should therefore keep a hard split:
- **reference a secret**,
- **use it behind a provider or agent**,
- **materialize it narrowly for one execution ground**,
- **reveal it locally**,
- **copy/export/share it**.

The shell+terminal only needs the early parts of that ladder for a long time.
It does not need to pretend every secret workflow becomes humane only when the bytes are shown.

## 4) Environment materialization should stay visibly weaker than ref or handle use

Environment-variable injection is often useful.
It is also one of the oldest shell secret leaks.
The shell should therefore treat env materialization as a named downgrade, not the invisible default success path.

Good posture here would look like:
- secret reference first,
- child-only env materialization as one explicit rail,
- visible execution-ground badge that the launch carried secret env,
- no history echo of literal values,
- no transcript capture of resolved values by default,
- and easy promotion toward FD/file/handle-backed delivery where possible.

That keeps convenience.
It also keeps honesty.

## 5) Secret sinks should be named, not implied

One of the niftiest ideas worth stealing is not a new vault.
It is a **sink ledger** for secret-bearing work.

Every secret-adjacent surface should be able to answer:
- can this land in history?
- can this land in transcript?
- can this be copied to clipboard?
- can a remote peer observe it?
- can this appear in support/export bundles?
- is the current view literal, masked, scrubbed, or ref-only?

That would make the shell dramatically more legible than bash without forcing any single backend.

## 6) Masking helps, but masking is weaker than sink avoidance

A modern shell+terminal should absolutely steal good masking ideas.
It should support redaction cards, scrub profiles, and visible “masked here” posture.
But it should stay honest about the hierarchy:
- best: secret never entered the sink,
- next best: sink carried only ref/handle metadata,
- weaker: sink carried literal bytes but scrubbed or masked them,
- weakest: sink already carried the literal and we are hoping downstream cleanup is enough.

That is the right humility.
It prevents masking from becoming a fake absolution ritual.

## 7) Remote and forwarded secret use should advertise proxy risk

Agent forwarding and remote proxy use are powerful because they can avoid exporting raw secret material.
They are still risky because a remote peer may be able to exercise the forwarded capability while it is present.
Schell should therefore make remote secret posture very explicit:
- local-only handle,
- forwarded handle,
- destination-constrained proxy,
- peer-visible but non-exported use,
- or literal export.

That is much better than the vague story that “the key never left.”
The shell should tell the truth about where use can happen, not only where bytes reside.

## 8) Great steals that still stay decision-light

### a) Secret slots in parameter cards
Secret-bearing parameters should render as typed slots with ref/mask/reveal/use posture instead of plain echoed strings.

### b) One-shot peek
Allow a short-lived local literal reveal with obvious residue rules, then return to masked or ref-only display.

### c) Provider-backed use rails
`sign`, `auth`, `login`, `fetch token`, `mount`, or `decrypt for child` should be explicit actions that can avoid durable literal reveal.

### d) Sink badges
Show history/transcript/clipboard/remote-peer posture right next to the secret-bearing slot or execution-ground review.

### e) Sanitized handoff bundles
Support failure/help handoff that proves which secret sinks were avoided, scrubbed, or blocked instead of assuming redaction folklore.

## 9) The no-regret move

The best move right now is not to choose one secret manager or freeze one vault protocol.
It is to pin one rule:
**Schell should model secrets as shell-known witnesses with explicit reference/use/materialize/reveal/export posture, visible sink posture, and masking humility before credential handling quietly collapses into plaintext terminal folklore.**

That keeps the archive free to defer:
- one final vault/keychain adapter,
- one final secret-ref syntax,
- one final remote proxy protocol,
- one final clipboard/export policy stack,
- and one final secret classification ontology.
