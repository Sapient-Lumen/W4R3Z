# Recording ladders, searchable casts, and rerun-basis humility

This surface keeps one boundary explicit:
**a great shell+terminal should make casts, searchable session records, live follow, and post-hoc chapter search feel exceptional — but it should not let transcript hits, PTY/I-O logs, or published casts impersonate exact rerun basis or durable current truth.**

The shell+terminal world keeps rediscovering the same family of recording comforts:
- export a lightweight cast,
- watch a session live,
- search prior terminal material,
- replay timing and output,
- and derive new work from what happened before.

These are all excellent.
They also sit right on a dangerous seam.
The operator can very quickly stop knowing:
- whether the recording contains only output or also sensitive input,
- whether the shell authenticated chapter boundaries or a PTY recorder merely captured bytes,
- whether a search result is local-only, team-indexed, or publicly searchable,
- whether a follow view is still in progress or durably finished,
- and whether “rerun” means exact approved basis or only a derived suggestion.

Schell should steal the delight.
It should not inherit the flattening.

## 1) Recording should arrive on an explicit ladder

Schell should have a **recording ladder** for any capture/export/live-watch object.

A first useful ladder could be:
- `output_only` — durable output without raw input,
- `timed_output` — output with replay timing,
- `chaptered_cast` — shell-known chapter boundaries + timing,
- `input_bearing_local` — input-bearing local capture with strong warning,
- `imported_io_capture` — PTY/I-O import where chapter truth may be degraded,
- `live_follow` — in-progress observation,
- `unknown`.

That gives the shell a compact way to say what kind of thing this is before a user copies, searches, publishes, or reruns anything.

## 2) Search posture needs names

Search is one of the niftiest terminal luxuries in the world.
It is also one of the easiest ways to widen residue silently.
Schell should therefore carry **search posture** on any recording/search artifact.

Useful first values:
- `not_indexed`,
- `local_only`,
- `workspace_indexed`,
- `team_indexed`,
- `published_searchable`,
- `unknown`.

This makes “why did this show up in search?” answerable without folklore.

## 3) Chapter truth and byte capture should not be the same badge

A shell-known chapter is stronger than a PTY byte stream.
A PTY byte stream may still be very useful.
They are not the same.

So Schell should keep distinct posture like:
- `chapter_truth = shell_authenticated / shell_marked / terminal_inferred / imported_bytes / restored / unknown`
- `capture_truth = output_only / input_output / live_follow / imported`

That lets a cast spine jump richly when the shell truly knows chapter boundaries, while degrading honestly when all we have is imported byte capture.

## 4) Follow and finished should be different cards

A live-follow view is great.
It should still remain visibly weaker than a finished artifact.

So Schell should keep separate cards for:
- **follow state** — watching an in-progress source,
- **capture state** — still recording / sealed / abandoned / unknown,
- **closing witness** — exact finished artifact digest, sealed receipt, or none,
- **durable result state** — absent / present / historical / unknown.

This prevents “the thing I was watching” from becoming the only durable truth surface.

## 5) Rerun should usually derive a proposal, not silently reuse a recording

This is the most important law in the whole seam.
A recording is almost never the exact rerun basis by itself.
The shell+terminal should therefore prefer:
- **inspect** the old recording,
- **extract** the exact authenticated chapter when available,
- **derive** a new rerun proposal with explicit basis fields,
- **show hold card** when the old capture is insufficient,
- and only then **review and run**.

The good default is:
**old capture → fresh proposal**
not
**old capture → silent execution.**

## 6) Digest-first cast manifests are worth stealing now

A cast/export object should preserve a compact manifest such as:
- cast digest or ref,
- recording ladder grade,
- chapter-truth grade,
- search posture,
- publication posture,
- redaction posture,
- input-bearing flag,
- timing posture,
- closing witness,
- rerun posture.

This keeps identity small and durable while letting richer sidecars remain sidecars.

## 7) Secret risk should be louder for input-bearing and searchable capture

Schell should raise stronger warnings when any of these combine:
- raw input capture,
- search indexing,
- publication,
- imported I/O logging,
- or uncertain redaction posture.

A simple first posture may be:
- `secret_risk = low / elevated / high / unknown`
with stronger defaults and more friction for `high` or `unknown`.

## 8) Super-awesome moves worth stealing now

### a) Recording ladder chips
Output-only, timed, chaptered, input-bearing, imported, live-follow.

### b) Search posture badges
Local-only versus team-indexed versus published-searchable is product-defining clarity.

### c) Chapter-aware cast spine
Jump by exact shell chapter when possible; degrade honestly when imported.

### d) Follow-versus-finished split cards
A perfect fix for the “I was watching it, therefore it must be done” illusion.

### e) Rerun-basis hold cards
Turn stale capture into guidance instead of silent overreach.

### f) Digest-first cast manifest
Great for hygiene, export, and history without granting power.

### g) Derive-rerun ladder
Inspect → extract → derive proposal → review → run.

### h) Search-hit provenance chips
Show whether a hit came from public cast search, local index, imported log, or shell-owned chapter history.

## 9) What Schell should refuse

### Refuse capture-as-authority
A cast or PTY log is evidence, not automatic rerun authorization.

### Refuse search-hit truth collapse
A search hit is not exact chapter identity by default.

### Refuse follow-as-finished
Watching an in-progress stream is not the durable completion record.

### Refuse silent input-bearing defaults
Input capture needs louder posture and better defaults.

### Refuse chapter/baseline confusion
Imported bytes and shell-authenticated chapters should never share one trust badge.

## 10) Decision-light proving slice

A compact proof could show:
- one output-only cast manifest,
- one input-bearing warning card,
- one chapter-aware cast spine with shell-authenticated and imported segments,
- one search-hit provenance chip for local versus published-searchable capture,
- one live-follow card that never claims finished truth,
- one sealed-finished card with a separate closing witness,
- one rerun-basis hold card,
- and one derive-rerun ladder that mints a fresh proposal instead of silently replaying old bytes.

That is enough to make Schell feel dramatically more capable without freezing one final recording format, search backend, stream protocol, or rerun derivation stack.
