# Pointer witnesses, mouse reporting, and prompt-click humility

**Schell should absolutely steal live-prompt cursor clicks, command-output click affordances, quick-select comfort, terminal-local selection polish, and good wheel/trackpad browsing — but it must not let local selection, app-captured mouse reporting, semantic-history smart clicks, wheel-to-key translation, and stronger open/run routes collapse into one flattering “the click did something useful, therefore it was shell truth” story.**

## 1) Why this seam matters

A custom shell+terminal gets much more humane the moment the pointer starts helping: 
- click inside the live prompt to move the cursor,
- drag to select without fighting the app,
- quick-select likely tokens,
- open command output in a pager,
- and route obvious objects to inspect/open/reveal actions.

But this is also where terminal folklore gets slippery.
The pointer may mean:
- terminal-local selection,
- shell-authenticated prompt editing,
- application-owned mouse tracking,
- semantic click routing,
- wheel-to-scroll,
- wheel-to-arrow translation in alt screen,
- or a terminal-local quick-select overlay.

Those are not one thing.
Schell should keep **selection**, **hover**, **click**, **drag**, **wheel**, **prompt-edit**, **typed route**, **application-captured mouse event**, and **later reviewed action** separately named.

## 2) The current ecosystem proves the luxury bundle and the trap bundle arrive together

Modern terminals are getting delightful here for good reason.
Ghostty now supports click-to-move inside active shell prompts, but it explicitly requires shell integration and prompt marking via `OSC 133`.
kitty lets mouse clicks route through an ordered action ladder (`selection`, `link`, `prompt`) and also supports selecting or showing clicked command output when shell integration is present.
WezTerm makes mouse bindings configurable and is very explicit that when an application enables mouse tracking, events stop matching terminal mouse assignments and are passed through to the application instead, unless the operator uses a bypass modifier.
foot keeps alternate-scroll-mode visible as a policy choice: mouse wheel events in the alternate screen can be translated into up/down key events for apps like pagers.
And iTerm2’s semantic history shows both the brilliance and the danger of “smart clicks”: cmd-click can use per-line tracked cwd to open files, open URLs, or even run a command.

That combination is the lesson.
The pointer can be a luxurious editor/navigation surface, but only if Schell never forgets who currently owns the event and how strong the resulting claim really is.

## 3) Prompt clicks are worth stealing, but only inside a shell-authenticated live-edit region

Ghostty and kitty both point in the same direction: clicking in the current prompt can feel like clicking in a normal text field.
That is a great idea for Schell.
But it should remain narrower than generic “cursor anywhere” folklore.

The safe import is:
- live-prompt click only,
- shell-authenticated prompt region only,
- edit-only effect by default,
- no silent submit,
- and no promotion from clicked text to executable meaning.

So Schell should distinguish:
- `prompt-live-shell-auth`,
- `prompt-live-terminal-inferred`,
- `screen-historical`,
- `output-derived`,
- and `app-captured`.

Only the first of those deserves rich click-to-move comfort.

## 4) Mouse reporting capture is a real ownership seam, not an implementation detail

WezTerm’s docs are unusually helpful here: by default applications do not respond to the mouse, but applications can emit escape sequences to request mouse tracking; when they do, terminal mouse assignments stop applying until the operator uses a bypass modifier.
That means Schell should not pretend a click is always “for the terminal” or always “for the app.”

The event should carry a witness like:
- `owner = terminal-local`,
- `owner = shell-prompt`,
- `owner = app-captured`,
- `owner = quick-select-overlay`,
- `owner = route-card`,
- `bypass = none|modifier`,
- `transport = local|mux|remote`,
- `confidence = exact|shell-attested|terminal-derived|heuristic`.

That one split would make a huge amount of luxury safer.

## 5) Wheel and scroll are not harmless either

foot’s alternate-scroll-mode is a perfect reminder that the wheel can mean different things depending on the view and app posture.
In main scrollback it may simply move the viewport.
In alternate screen it may be translated into arrow keys.
Inside an app with mouse tracking it may be app-owned input.
Inside a quick-select or copy-mode overlay it may mean local navigation.

So Schell should keep:
- `viewport-scroll`,
- `app-wheel`,
- `wheel-translated-to-keys`,
- `selection-extend`,
- and `overlay-nav`

as separate pointer event families.

That matters because wheel gestures are often easy to trigger accidentally, and accidental input should never quietly become stronger route or execution authority.

## 6) Smart clicks should become typed routes, not click-to-do-whatever folklore

The ecosystem keeps proving that click affordances are useful: kitty can show clicked command output in a pager; iTerm2 semantic history can use working-directory context to open files or invoke commands; WezTerm quick-select can find likely paths/URLs/hashes and copy them quickly.

Schell should absolutely steal the comfort, but not the ambiguity.
The safe import is:
- a **selection packet** when the operator is only selecting,
- a **route card** when the terminal thinks it found an object,
- a **prompt-edit packet** for live command-line clicks,
- an **app-captured badge** when the foreground app owns the mouse,
- and a **review rail** before any strong open/run/attach action.

Clicked text should never silently become:
- a path with ambient cwd assumptions,
- a URL with ambient browser launch authority,
- a command with ambient shell interpretation,
- or an app-local coordinate with shell-level meaning.

## 7) Performance and correctness belong in the design, not in post-hoc excuses

The iTerm2 changelog is instructive here: semantic-history filesystem search used to happen on the main thread and could hang on slow network filesystems, so it was moved to a separate process.
That is exactly the kind of historical scar Schell should learn from early.
Pointer comfort that blocks the UI or does hidden heavy lookup on click is not just annoying; it blurs observation, indexing, and stronger route resolution into one mysterious gesture.

So Schell should prefer:
- cheap local selection immediately,
- shell-authenticated prompt editing immediately,
- typed route cards with visible freshness/cost posture,
- heavier lookup behind explicit reveal/resolve steps,
- and strong open/run/attach actions only after explicit review.

## 8) What Schell should now do

### A. Add **pointer witnesses**
Every pointer interaction should be able to say:
- `event_kind` — hover / click / drag / wheel / press / release,
- `owner` — terminal / shell-prompt / app / overlay / route-card,
- `region_strength` — shell-authenticated / terminal-derived / heuristic / historical,
- `effect_class` — select / move-cursor / reveal / copy / route-proposal / app-input,
- `bypass_posture` — none / modifier-held / forced-local,
- `transport_posture` — local / muxed / remote / restored,
- `review_strength` — observation-only / proposal-only / review-required.

### B. Add **prompt-click rails**
Prompt clicks should be admitted only when the shell has authenticated the live prompt region.
Otherwise Schell should degrade honestly to selection or reveal-only behavior.

### C. Add **app-capture badges**
When the foreground app owns the mouse, Schell should say so.
That is not an error; it is a different ownership story.

### D. Add **typed route cards**
Object-like clicks should yield typed next steps such as:
- reveal exact source,
- insert into prompt,
- open safe,
- open exact,
- copy,
- attach,
- hand to pager,
- or ask for stronger review.

### E. Add **wheel posture badges**
Especially for alt screen and overlays, Schell should be able to say whether the wheel is scrolling viewport, extending selection, driving app input, or being translated into keys.

## 9) Super-awesome moves worth stealing

The nicest moves to steal without overcommitting the architecture are:
- shell-authenticated prompt clicks,
- typed object route cards,
- command-output click-to-pager or click-to-select,
- quick-select overlays for likely objects,
- good bypass modifiers when apps capture the mouse,
- and honest wheel posture in main screen, alt screen, and overlays.

The especially good Schell twist would be:
- **pointer witnesses** that confess who owned the event,
- **prompt-click rails** that only light up in authenticated live prompts,
- **route cards** that keep clicked objects weaker than reviewed actions,
- and **wheel badges** that confess whether a gesture scrolled, selected, translated, or fed the foreground app.

## 10) Decisions intentionally kept open

This pass does **not** freeze:
- one final mouse protocol mix,
- one final prompt-click extension,
- one final smart-click/object-detection engine,
- one final quick-select UI,
- one final wheel/trackpad gesture policy,
- or one final mux/remote forwarding story.

The no-regret move is smaller:
**let Schell become excellent at pointer comfort, but keep local selection, prompt editing, app capture, typed route proposals, and stronger reviewed actions separately named.**
