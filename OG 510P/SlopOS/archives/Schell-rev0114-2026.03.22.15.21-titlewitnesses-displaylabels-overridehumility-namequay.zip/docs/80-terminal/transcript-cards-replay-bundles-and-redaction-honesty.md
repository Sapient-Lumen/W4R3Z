# Transcript cards, replay bundles, and redaction honesty

This surface records another low-regret move for Schell:
**make exact command chapters much easier to export, replay, and hand off while refusing to let transcript artifacts impersonate live authority.**

The point is not to build a giant notebook or surveillance recorder first.
The point is to give the shell+terminal a much better answer to:
- “show me the exact chapter that happened,”
- “attach just enough of it for help,”
- “export a scrubbed replay bundle,”
- “replay this readonly with markers and timing,”
- and “make clear what this capture includes and what it does not.”

## Core idea

Schell should probably distinguish at least six nearby things:

- **chapter** — one exact shell-known command region,
- **transcript card** — a compact card bound to one chapter or chosen chapter set,
- **attach bundle** — a bounded help/context packet that is weaker than durable export,
- **replay bundle** — a packaged export for readonly replay or audit,
- **timing witness** — marker/timing/seek metadata bound to the transcript card,
- **publish/share action** — a stronger outward move than local attach or local replay.

Those are related.
They are not the same action.

## 1) Transcript cards should bind exact chapter truth, not raw scrollback

A transcript card should not be just “the text that happened to be on screen.”
It should bind to exact shell-known chapter identity.

A compact v0 transcript card could preserve:
- `transcript_card_id`,
- `chapter_refs[]`,
- `capture_grade` — `shell-authenticated`, `terminal-inferred`, `restored`, or `imported`,
- `lane_kind` — terminal / help / agent / imported,
- `cwd_or_ground_ref?`,
- `peer_ref?`,
- `output_refs[]`,
- `exit_or_outcome_ref?`,
- `redaction_profile_default`,
- `timing_witness_ref?`,
- `share_posture`,
- and `replay_grade`.

Important posture:
- a transcript card is **evidence and routing help**,
- not proof the chapter is still live,
- not approval to rerun it,
- and not a portable authority token.

## 2) Redaction profiles should be named before export

One of the easiest ways to lie is to say “share transcript” without saying what is inside.
Schell should make the inclusion set explicit.

A useful first ladder could be:
- **output-only**,
- **output + command**,
- **output + command + prompt/cwd hints**,
- **full local help bundle**,
- **full replay bundle**.

And the card should say, clearly:
- whether typed input is included,
- whether environment snapshots are included,
- whether peer identity is included,
- whether only excerpts or full outputs are included,
- and whether secrets were redacted, withheld, or never captured.

## 3) Attach-for-help should stay weaker than durable export

A custom shell+terminal becomes dramatically better once asking for help stops being paste ritual.
But attach-for-help is still not the same as publishing or archiving.

An **attach bundle** could stay compact:
- exact command/chapter ref,
- selected output slices,
- exit or denial witness,
- ground and peer hints when useful,
- one visible redaction profile,
- and one provenance badge.

That bundle should be easy to attach to:
- another local lane,
- a help lane,
- or a teammate-facing draft later.

The key rule is:
**attach is request-local context transfer, not durable publication by accident.**

## 4) Replay bundles should declare “what's inside” up front

A **replay bundle** should feel like a careful export, not a mystery blob.
A good v0 export sheet could say:
- command chapters included,
- byte counts and output refs,
- timing/marker sidecars present or absent,
- input included or not,
- env/peer/ground details included or not,
- replay grade,
- redaction profile,
- and sensitivity badge.

That makes replay much more trustworthy.
It also makes refusal much easier when the requested export would include more than the operator meant.

## 5) Timing and markers should live in an explicit witness sidecar

Replay becomes much nicer when it supports:
- chapter boundaries,
- named markers,
- speed control,
- jump-to-offset,
- and bookmarkable failure or review points.

But those are not the same thing as transcript identity.
So timing and markers should probably live in an explicit **timing witness** sidecar rather than being smuggled into the transcript card core.

A compact witness might keep:
- `subject_ref`,
- `time_basis` — none / local-monotonic / imported / unknown,
- `marker_refs[]`,
- `offset_index?`,
- `speed_hints?`,
- and `gap_flags`.

That keeps replay-stable identity small while leaving rich playback open.

## 6) Replay should stay visibly readonly and non-live

Readonly replay is a wonderful operator affordance.
But Schell should say what it is.

Replay should stay clearly distinct from:
- reopening a live session,
- reattaching to a PTY,
- rerunning a command,
- or importing a workflow seed.

The transcript card should therefore badge at least:
- **live chapter**,
- **restored transcript**,
- **imported cast**,
- **scrubbed export**,
- **readonly replay**.

That matters because a replay may be exact about evidence while still being non-live and non-authoritative.

## 7) Lane separation matters here too

A transcript surface gets confusing fast if everything is one giant history pool.
Schell should keep at least a small family split:
- operator terminal chapters,
- attached help bundles,
- agent-lane artifacts,
- imported recordings,
- and published/shared exports.

Those may be linked.
They should not be flattened into one “same truth” story.

## 8) Selective copy and excerpt actions are underrated

Sometimes the right action is not replay or share.
It is simply:
- copy command only,
- copy output excerpt,
- copy command + selected output,
- or copy a normalized chapter ref.

That is a very strong place for Schell to feel super awesome.
Operators constantly need smaller-than-full transcript moves.
Making those explicit will beat legacy terminals immediately.

## 9) Things Schell should steal now

### Output-first redaction posture

Default toward output and bounded metadata; make input/env capture explicit.

### Marker and chapter sidecars

Small appendable timing/marker witnesses can make replay much better without freezing one giant recording format.

### Seekable readonly replay

Jump-to-offset, bookmark, and speed control are all worthwhile.

### Selective export sheets

“What is inside” should be visible before export.

### Lane-split transcript families

Operator terminal chapters and help/agent artifacts should remain distinct families even if they can reference each other.

## 10) Things Schell should refuse

### Refuse transcript-equals-rerun

A replay artifact should not quietly become a command proposal or a live execution handle.

### Refuse hidden input capture

If keys or raw input are present, say so explicitly.

### Refuse one generic share action

Attach, export scrubbed, export full, and publish are different meanings.

### Refuse replay-equals-live

Playback can be excellent evidence without being a live shell session.

### Refuse giant capture architecture first

One transcript-card family, one redaction ladder, one timing witness, and one readonly replay surface are enough to learn a lot.

## 11) No-regret first specimen set

A compact first cut could show:
1. one exact chapter promoted into a transcript card,
2. one attach-for-help export with output-only redaction,
3. one fuller replay bundle sheet showing included fields,
4. one timing witness with markers for failure and review,
5. one readonly replay pane with jump-to-offset,
6. one imported cast that stays visibly imported,
7. and one transcript slice showing attach vs export vs replay honesty.

That is enough to make Schell substantially more awesome around incident evidence, teaching, collaboration, and debugging without freezing a recording backend, sync story, storage model, or publishing stack.
