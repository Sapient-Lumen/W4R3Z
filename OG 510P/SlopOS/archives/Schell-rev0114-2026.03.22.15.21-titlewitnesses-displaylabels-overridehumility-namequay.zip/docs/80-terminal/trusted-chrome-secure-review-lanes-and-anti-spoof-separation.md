# Trusted chrome, secure review lanes, and anti-spoof separation

This surface records a new no-regret candidate cluster for Schell:
**the integrated shell+terminal should have one small trusted-chrome family outside ordinary PTY flow, so authority-bearing review cards, secure follow-up prompts, and final approval/denial surfaces stay visibly distinct from raw or inferred terminal content.**

The design pressure comes from three directions:

- SlopOS keeps trusted UI, volition, approval basis, chooser mediation, and high-risk capture/automation on explicit seams rather than ambient pixels.
- DelayBasin keeps demanding that public state, witnesses, and actuator-adjacent decisions not be laundered through hidden carry or self-certifying narrative.
- Current terminals show that shell-emitted metadata can make UX brilliant, but that metadata still rides through channels any application can often write unless the host distinguishes provenance and trust.

## 1) Schell needs one explicit trust ladder for visible surfaces

A good first ladder is:
- **raw-pty** — ordinary terminal content with no stronger claim,
- **inferred** — host-detected structure or pattern match,
- **shell-attested** — shell-emitted or otherwise verified semantic structure,
- **trusted-chrome** — host-local review chrome that PTY flow cannot impersonate.

This does not have to freeze a final protocol.
It just gives Schell a compact answer to a crucial question:
*what layer am I looking at right now?*

## 2) High-risk review should land in a separate review lane

Schell already wants review cards, denial cards, hold cards, basis packets, authority strips, and progress/residue surfaces.
The new ratchet is that the most authority-bearing of those should not be normal scrollback.

A first **review lane** could host:
- exact review cards,
- exact mutable-basis witnesses,
- approval and denial outcomes,
- secure follow-up prompts,
- and transcript-visible “trusted chrome hosted this decision” witnesses.

PTY output can request or motivate those cards.
It should not be able to render the final trustworthy version of them.

## 3) The shell should remain the truth source for semantic regions

Schell should keep copying the best current terminal pattern:
- shell-known prompt/input/output boundaries,
- shell-known command lines when possible,
- shell-known cwd/ground data,
- and shell-known active-input windows.

But it should add one more rule:
- shell-known regions are still not automatically trusted chrome.

That keeps the model simple:
- the shell tells the truth about command structure,
- the terminal renders that truth beautifully,
- and the trusted chrome layer is reserved for authority-bearing review and local host policy surfaces.

## 4) Host-side effects from terminal content need witnesses

Terminal content can already request surprising host-side effects in many emulators: title changes, clipboard writes, hyperlinks, and other escape-sequence-mediated behaviors.
Schell should therefore grow a tiny **host-effect witness** family.

A witness may only need:
- `effect_kind` — title / clipboard / link-open / other local effect,
- `origin_grade` — raw-pty / inferred / shell-attested / trusted-chrome,
- `policy_result` — allowed / downgraded / held / denied,
- `subject_ref` — optional path/URI/object witness,
- `notes_ref` — optional explanation or hold card.

This lets Schell say what happened without pretending that PTY output itself earned trusted authority.

## 5) Anti-spoof discipline should be visible, not mystical

A good Schell posture is:
- trusted chrome has a stable placement,
- trusted chrome has a small but unmistakable visual language,
- PTY output cannot place itself in that lane,
- suspiciously similar PTY output may be visually downgraded or annotated,
- and local policy can collapse strong actions back to inspect-only when provenance is weak.

This does **not** require one final UI kit.
It only requires that Schell not let its most important surfaces be easy to imitate accidentally.

## 6) Secure entry is optional by platform, but the concept is worth keeping

Some platforms can support a stronger local secure-entry path.
Some cannot.
Schell should keep that implementation question open.

But the conceptual split is still valuable even before platform SAS exists:
- ordinary terminal flow,
- trusted local review lane,
- and optionally a stronger secure-entry mode for especially sensitive approvals.

That is enough to keep the architecture honest.

## 7) DelayBasin’s process lessons sharpen the same answer

DelayBasin is helpful here because it warns against letting one surface be both:
- the main descriptive story,
- and the thing that certifies its own rightness.

So Schell should keep:
- PTY content as evidence / request / suggestion,
- trusted chrome as the compact public decision surface,
- and receipts / transcripts as the durable witness of what actually happened.

That is a healthier observer/actuator split than “the prettiest text in the terminal won.”

## 8) A strong v0 cluster is small

A decision-light v0 cluster is probably enough:
- one trust ladder,
- one trusted-chrome strip,
- one review lane,
- one host-effect witness family,
- one transcript-visible witness for trusted-chrome decisions,
- and one rule that strong approval/denial surfaces never live only in PTY scrollback.

## 9) Decisions intentionally kept open

This surface does **not** freeze:
- a compositor or toolkit,
- one secure-attention implementation,
- one cross-platform escape policy,
- one remote-display story,
- one hyperlink/open policy for every platform,
- or one final theming language.

The no-regret move is narrower:
**make the most trustworthy surfaces visibly separate before Schell teaches users to rely on them.**
