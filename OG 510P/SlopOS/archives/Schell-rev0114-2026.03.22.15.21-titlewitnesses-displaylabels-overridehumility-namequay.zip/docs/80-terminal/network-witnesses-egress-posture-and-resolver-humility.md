# Network witnesses, egress posture, and resolver humility

This surface keeps one boundary explicit:
**a great shell+terminal should let operators review network mode, resolver/proxy posture, and bounded egress receipts — but it should not let host networking, ambient DNS, proxy env, passed-in sockets, or URI text impersonate one another.**

Modern systems already have real network-control machinery:
- service managers can place workloads in private or joined network namespaces,
- socket activation can pass in specific listening sockets,
- sandboxes can default to no network,
- container tools can name multiple network modes,
- command-line tools can inherit or override proxy and protocol posture,
- and platform portals can mediate URI opens and status info.

That is all worth stealing.
The failure mode is equally consistent:
- host/shared networking stays invisible,
- resolver basis gets guessed from success/failure,
- proxy env silently changes routing,
- passed-in sockets and loopback-only namespaces look the same,
- and old receipts or status panes start pretending to prove present authority.

Schell can do better without picking one final sandbox, container, or portal stack.

## 1) The shell needs one exact network witness

A good first object is **network witness**.

A network witness is a compact shell-owned descriptor for the network posture a reviewed action will enter.
It is not a firewall DSL.
It is not a final egress policy engine.
It is the thing the terminal can point at when it says “this command has *this exact kind* of network footing.”

A v0 witness probably needs:
- `mode` — `none` / `private_loopback` / `joined_namespace` / `shared_host` / `leased` / `unknown`,
- `resolver_mode` — `none` / `portal` / `host_file` / `explicit_override` / `unknown`,
- `proxy_mode` — `none` / `flag` / `env` / `workflow_default` / `unknown`,
- `proto_posture` — unconstrained / allowlisted / redirect-limited / unknown,
- `socket_basis` — none / passed_in / ambient_host / unknown,
- `destination_basis` — explicit reviewed target / ambient text only / mixed,
- `status_posture` — live / historical / unavailable,
- `redaction_mode` — full / hash / metadata-only,
- `notes_ref` — optional explanation or refusal card.

That is enough to make network truth real without freezing a giant portability model.

## 2) Network mode should be named, not implied

Current tools already prove this.
There is a huge practical difference between:
- **no network**,
- **private loopback-only namespace**,
- **join this existing namespace**,
- **share host networking**,
- and **receive only these explicit sockets**.

Schell should therefore show named network modes up front.
The operator should not have to reconstruct them from:
- container flags,
- service-manager properties,
- namespace paths,
- or a command “just working”.

## 3) Resolver posture needs its own witness family

A command can have “network” and still differ radically in name-resolution meaning.
Useful distinctions include:
- no name resolution,
- explicit portal/broker resolution,
- host-file or host-stack resolution,
- explicit per-command override,
- unknown compat resolution.

This matters because DNS is not just convenience.
It often leaks intent, changes routing, and changes what the command can even reach.

A **resolver witness** should therefore say:
- where names are resolved,
- whether service discovery is in play,
- whether the basis is reviewed or ambient,
- and whether the current runtime is degraded from the archive's preferred posture.

## 4) Proxy posture also deserves exact review truth

Operators routinely get surprised by proxy state.
That surprise comes from several places:
- inherited `http_proxy` / `https_proxy` / `NO_PROXY` style env,
- workflow defaults,
- config files,
- command-line flags,
- and redirect/protocol behavior.

Schell should treat proxy source as explicit review truth.
A **proxy witness** can be tiny and still helpful:
- none,
- explicit flag,
- inherited env,
- workflow default,
- or unknown compat behavior.

That tiny distinction can explain an enormous amount of shell confusion.

## 5) URI text, destination text, and destination authority are different things

This is a crucial shell lesson.
A hostname or URI appearing in:
- argv,
- output,
- selection text,
- or a runbook cell
is not automatically destination authority.

Schell should therefore keep at least three truths separate:
- **typed/requested text**,
- **reviewed destination authority**,
- **historical egress receipt**.

That improves:
- safe open,
- fetch/import review,
- replay and re-run fidelity,
- proxy/protocol explanation,
- and support/postmortem analysis.

## 6) Socket-passing is a luxury worth stealing

One especially good idea worth stealing is **socket-basis honesty**.
A command or service may have:
- no socket authority at launch,
- private networking but one or more passed-in sockets,
- shared networking with ordinary socket constructors,
- or a leased/brokered network handle.

Those are all valuable.
They are not the same.

Schell should let the terminal render them richly:
- “private network, 1 passed-in listener”,
- “shared host network, no explicit proxy”,
- “leased outbound connect scope, portal resolver”,
- “host resolver, proxy inherited from env”,
- and so on.

That is a genuine super-awesome move that still stays decision-light.

## 7) Historical egress receipts should stay humble

A good egress receipt might include:
- exact command/action basis,
- mode / resolver / proxy posture at review time,
- optional reviewed destination predicate,
- optional protocol family,
- optional scope label,
- exact exit status / signal posture,
- optional redacted endpoint facts,
- optional explicit-open / fetch / materialize follow-on refs,
- and a claim-strength badge when the runtime could not prove more.

It should avoid pretending to prove:
- current connectivity,
- current namespace membership,
- current proxy state,
- current DNS answers,
- or that the same authority still exists now.

## 8) Great ideas worth stealing right now

### a) Named network-mode badges
Tiny but very high value:
- none,
- private loopback,
- joined namespace,
- shared host,
- leased.

### b) Resolver and proxy provenance badges
A command should be able to say “portal resolver, no proxy” or “host resolver, proxy from env”.
That is excellent operator hygiene.

### c) Socket-basis badges
Show whether communication relies on:
- ordinary constructors,
- passed-in listeners,
- passed-in connected sockets,
- brokered/leased handles,
- or unknown compat behavior.

### d) Protocol posture badges
A small but useful card can say:
- unconstrained,
- allowlisted,
- redirect-limited,
- or unknown.

### e) Open / fetch / materialize ladders
Wonderful and necessary:
- reveal URI,
- open,
- safe-open,
- fetch/import,
- materialize into durable artifact.

These must stay separately named.

### f) Historical egress receipts with redaction posture
Keep post-run evidence useful without turning endpoint details into ambient residue.

## 9) Things Schell should refuse

### Refuse ambient-network-as-baseline
Shared host networking should be explicit, not invisible.

### Refuse resolver-collapse
“Has network” is not enough to describe DNS/service-discovery meaning.

### Refuse proxy-env invisibility
Inherited proxy state should never be a silent routing trick.

### Refuse URI-text-equals-authority
A URL in output or argv is not the same as reviewed destination authority.

### Refuse live-status-equals-current-authority
A prior status pane or old receipt is not present network proof.

### Refuse one giant portable network grammar too early
systemd, bubblewrap, Flatpak, containers, portals, and host tools are all real.
Schell does not need to flatten them into one premature universal ontology.

## 10) No-regret first specimen set

A compact first cut could show:
1. one reviewed launch card with explicit network mode badge,
2. one resolver witness with none / portal / host-file / explicit-override posture,
3. one proxy witness with flag / env / workflow-default / none posture,
4. one destination card separating typed URI text from reviewed authority,
5. one private-network command with an explicit passed-in socket witness,
6. one historical egress receipt with redaction-safe endpoint facts,
7. one refusal to infer safe protocol posture when the command omits constraints,
8. and one refusal to treat a stale status deck as current egress authority.

That is enough to make Schell feel substantially more awesome at network truth without freezing one final sandbox runtime, resolver stack, or egress policy substrate.

## 11) The no-regret move

Steal reviewed network modes, resolver/proxy provenance, socket-basis badges, and bounded egress receipts.
Keep shared host networking, private namespaces, joined namespaces, leased handles, passed-in sockets, open/fetch/materialize ladders, and historical receipts visibly separate.
That is the move that makes the shell+terminal feel smarter without making it blurrier.
