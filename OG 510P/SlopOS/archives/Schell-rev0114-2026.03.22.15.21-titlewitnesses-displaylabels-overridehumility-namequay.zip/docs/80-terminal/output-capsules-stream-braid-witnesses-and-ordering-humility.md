# Output capsules, stream-braid witnesses, and ordering humility

This surface records a new no-regret candidate cluster for Schell:
**keep output richly explorable and beautifully rendered, but preserve exact channel/basis/provenance truth instead of pretending that scrollback is one perfect total log.**

The design pressure comes from three directions:

- SlopOS already treats stdio as an explicit bindable seam, keeps pipelines from turning stdio into an authority tunnel, and says ordering should be scoped, explicit, and receipt-visible.
- DelayBasin keeps distinguishing source packets from summaries, direct witnesses from derived extracts, and blocked outputs from falsely completed stories.
- Current terminals keep proving that shell-marked command regions unlock better navigation, selection, paging, and compare flows than raw scrollback guessing.

## 1) The terminal should render a braid, not invent a myth

A live command often has several adjacent truths:
- stdout bytes,
- stderr bytes,
- shell-authored status edges,
- local terminal hints,
- background residue,
- truncation/gap notices,
- and later frozen/exported artifacts.

Schell should not collapse that into one mythical single-source transcript.
It should preserve what ordering is exact and what ordering is only a renderer-level merge.

## 2) Output capsule

A good first object is **output capsule**.

An output capsule is not a second shell.
It is a compact shell-owned descriptor for one command region or one frozen residue object.

A v0 capsule probably needs:
- `subject_ref` — exact command / lane / receipt / residue object,
- `capture_grade` — `shell-authenticated`, `terminal-inferred`, `restored`, or `imported`,
- `channels_present` — closed family names,
- `channel_refs` — exact byte witnesses or digest-backed sidecars,
- `gap_flags` — truncation, dropped-by-policy, reordered-locally, restored-without-live-basis,
- `summary_facts` — bounded cheap facts like exit code witness present, stderr present, bytes available, pager-ready, compare-ready.

That is enough to make output an explicit thing without freezing a giant logging substrate.

## 3) Braid witness

A second useful object is **braid witness**.

The braid witness answers a narrower question:
**what merge/ordering posture produced the visible region the operator is looking at?**

A v0 braid witness might keep:
- `subject_ref`,
- `exact_orders` — for example `stdout` order exact, `stderr` order exact,
- `merge_posture` — `arrival-order`, `shell-mark-order`, `render-local-only`, `restored-unknown`,
- `time_basis` — absent / monotonic-local / imported / unknown,
- `ambiguity_flags` — cross-channel order unknown, background splice, renderer replay, truncation, etc.

That gives Schell a way to be honest without becoming austere.

## 4) Channel families should stay small and explicit

A decision-light first family could be:
- `stdout`
- `stderr`
- `shell-note`
- `review-note`
- `gap`
- `truncation`
- `background-residue`
- `import-note`

This is deliberately smaller than a full observability ontology.
The point is not to model everything.
The point is to stop pretending that all visible bytes are equivalent.

## 5) Provenance grade matters

A command region can be wonderfully useful without being equally trustworthy.
Schell should preserve at least a small provenance grade:

### shell-authenticated
The shell marked the region and the capsule binds to exact shell-known state.

### terminal-inferred
The terminal segmented or merged it from local evidence but does not have full shell proof.

### restored
The region was reconstructed from history / replay / frozen state and is not live by default.

### imported
The bytes came from outside the primary shell-run lane and should not quietly inherit direct-exec semantics.

This parallels trusted-command-block discipline without flattening the whole terminal into trust/no-trust binary.

## 6) The fun actions should stay bounded

A strong first action family is:
- open pager on exact capsule,
- open stderr-only pager,
- compare two capsules,
- copy exact region,
- export digest-backed capsule,
- attach capsule to receipt/followthrough,
- and derive explicit proposal/workflow seed from selected output.

What should usually *not* happen by default:
- silent rerun,
- silent authority widening,
- hidden cross-pane injection,
- or silent promotion from inferred/restored/imported output into live shell truth.

## 7) Sticky anchors and region guides are worth stealing

Schell should absolutely steal from the best current region UX:
- sticky command anchors,
- region guides,
- semantic-zone selection,
- exact last-command-output browsing,
- and prompt-to-output navigation.

The important filter is that these are renderer affordances over an explicit capsule, not replacements for shell truth.

## 8) Pager and compare panes become much better with capsules

Once capsules exist, several already-admitted surfaces get stronger:
- readonly replay panes can host an exact capsule rather than loose text,
- compare panes can bind two exact capsule refs rather than ad hoc copies,
- selection packets can carry capsule refs instead of naked highlighted text,
- reentry cues can land on one exact capsule,
- and attention residue can point to the exact object that finished, failed, or got truncated.

## 9) Transcript truth should preserve the right minimum

The transcript does not need every renderer twitch.
It does need the important truths:
- that a capsule existed,
- what channels were present,
- what capture/provenance grade applied,
- what braid witness posture the rendered view used,
- and when later summaries or extracts were derivative rather than primary witnesses.

That is the compact portable baseline.

## 10) No-regret first cut

A first specimen set could stay small:

1. one command with stdout+stderr and a visible braid witness,
2. one stderr-only pager action,
3. one sticky region guide tied to an exact capsule,
4. one large-output command that freezes to digest-backed sidecar,
5. one restored capsule that stays visibly restored,
6. one background-residue capsule,
7. and one transcript slice showing local-merge humility.

That is enough to learn a lot without freezing a final logging, export, or binary sidecar architecture.
