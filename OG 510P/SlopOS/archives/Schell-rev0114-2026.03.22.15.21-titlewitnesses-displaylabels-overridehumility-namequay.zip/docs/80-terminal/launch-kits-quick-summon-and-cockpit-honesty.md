# Launch kits, quick summon, and cockpit honesty

This surface records another low-regret move for Schell:
**make project entry dramatically faster while refusing to let launch kits, restored layouts, or quick terminals impersonate current live authority.**

The point is not to build a giant workspace manager first.
The point is to give the shell+terminal a much better answer to:
- “take me back to the thing I was working on,”
- “open my usual project setup,”
- and “give me a terminal *right now*.”

## Core idea

Schell should probably distinguish at least five nearby things:

- **live session** — a current shell-owned lane with current truth,
- **restored session** — recovered UI/session continuity with no default claim of current liveness,
- **launch kit** — an explicit artifact for reopening a project shape,
- **quick summon** — a runtime-fast terminal or cockpit surface for instant access,
- **project cockpit** — a discovery surface spanning recent/live/launch materials.

Those are related.
They are not the same object.

## 1) Launch kits should be explicit artifacts, not rc-file folklore

A launch kit is not just “open these tabs.”
It should preserve enough truth to stay honest later.

A compact v0 launch kit could preserve:
- `launch_kit_id`,
- `title`,
- `workspace_hint` or repo/root witness,
- `pane_plan` or view skeleton,
- `seed_refs[]`,
- `initial_directory_refs[]`,
- `peer_expectations[]`,
- `launch_posture` — local / exact-peer-review / disposable-request / ask,
- `restore_posture` — fresh-only / may-offer-attach / may-offer-restore,
- `share_posture` — local-only / attach-for-help / explicit-exportable.

Important posture:
- a launch kit is **entry guidance**,
- not current authority,
- not proof a live session still exists,
- and not permission to silently choose a concrete remote or disposable target.

## 2) Quick summon should be fast and modest

One of the best current terminal ideas is the quick drop-down terminal.
Schell should probably steal that class of move aggressively.

But it should do so with epistemic modesty.

A good quick-summon surface should:
- appear from a global shortcut,
- preserve state while hidden during the current runtime,
- make it easy to inspect current live work,
- maybe host one compact project cockpit,
- and avoid pretending it is durable restoration just because it is convenient.

This gives Schell a magical-feeling “always there” terminal without confusing runtime convenience with archive truth.

## 3) Project cockpits should unify discovery without flattening action

A good project cockpit could surface:
- current live sessions,
- recently focused sessions,
- restored-but-not-live sessions,
- launch kits,
- recent chapters,
- recent directories,
- recent peers,
- and recent workflow seeds.

That sounds like a lot.
But the critical rule is simple:
**finding something is not the same thing as acting strongly on it.**

A project cockpit result should probably carry badges for:
- object kind,
- liveness/restoration state,
- peer partition,
- source/lane,
- last outcome,
- and allowed action families.

## 4) Attach, restore, relaunch, and fresh launch are not the same action

This may be the most important distinction in the whole surface.

Schell should preserve at least these separate actions:
- **attach** — bind the current view to a still-live session,
- **restore** — reopen historical UI/session continuity,
- **relaunch from kit** — create fresh session structure using an explicit launch artifact,
- **fresh launch** — open a new plain session with no historical continuity claim.

The shell+terminal can make all four delightful.
It should not collapse them.

## 5) Destination posture can be requested; exact target choice stays explicit

A launch kit may legitimately say things like:
- prefer local,
- prefer last exact peer if still witnessable,
- request disposable posture,
- or ask before reusing anything historical.

But it should not silently hard-bind to:
- an invisible remote server id,
- a stale mux session handle,
- a browser/profile/session state,
- or an implementation-local disposable target.

If strong target truth is missing, Schell should prefer:
- **hold card**,
- **review destination**,
- or **fresh local launch**,

rather than hidden retargeting.

## 6) Restoration storage should be explicit and redactable

The moment a terminal stores restored state, it has created a real archive.
That is useful and sensitive.

So Schell should probably keep separate knobs for:
- runtime-only quick summon,
- local restoration storage,
- redaction of sensitive chapters/paths/peer data,
- and durable exported project artifacts.

A good rule is:
**storage is a named posture, not a side effect that hides behind convenience.**

## 7) Recent directories and recent peers belong in the cockpit

Project entry is not only a pane-layout problem.
Often the real question is:
- where was I,
- on which peer,
- in which repo,
- and what was the last successful or still-running chapter.

So the cockpit should likely include compact cues for:
- recent directories,
- recent peers,
- current running scopes,
- recent successful chapters,
- and recent denied/held work.

That is a better operator memory surface than layout alone.

## 8) Things Schell should steal now

### Explicit launch kits

Saving a project setup as one named artifact is a real usability win.

### Runtime-only quick summon

A fast global summon surface is one of the most obviously delightful terminal moves available today.

### Session navigator with real badges

A search surface spanning live, restored, and launch objects would be much better than separate hidden menus.

### Attach-vs-relaunch honesty

The UI should say which one is happening.
That sounds small.
It is huge.

### Recent-directory and recent-peer cues

These are high-signal project-entry hints and should sit near session and chapter cues.

## 9) Things Schell should refuse

### Refuse restored equals live

A restored project shell should be useful but not silently count as current truth.

### Refuse launch kit equals execute

Opening a kit is not the same as admitting reviewed work inside it.

### Refuse hidden target selection

A launch surface should not quietly choose a remote/disposable/profile target that the operator cannot inspect.

### Refuse giant workspace bureaucracy first

One launch-kit object, one quick-summon surface, one cockpit result model, and one hold-card downgrade rule are enough to learn a lot.

### Refuse durable storage by accident

Quick summon, restored history, attach-for-help, and export should stay visibly separate postures.

## 10) No-regret first specimen set

A compact first cut could show:
1. one explicit launch kit for a project with panes, recent dirs, and seed refs,
2. one quick-summon cockpit that preserves runtime state only,
3. one session navigator spanning live / restored / launch-kit objects with badges,
4. one attach action that binds to a live session and one relaunch action that clearly does not,
5. one launch hold card caused by missing peer or ambiguous disposable posture,
6. and one transcript slice showing summon → inspect → attach-or-relaunch outcome.

That is enough to make Schell feel substantially more awesome at project entry without freezing a workspace manager, a pane-layout engine, a remote mux treaty, or a final persistence model.
