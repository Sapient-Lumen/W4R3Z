# Workflow seeds, parameter cards, and runbook honesty

This surface records another low-regret move for Schell:
**make repeatable commands explicit reusable seeds with visible parameters and provenance instead of hiding reuse inside aliases, snippets, and sticky terminal memory.**

The point is not to invent a giant notebook platform first.
The point is to give the shell+terminal a better reuse story than shell folklore while keeping execution reviewable and authority honest.

## Core idea

Schell should probably distinguish at least four nearby things:

- **command chapter** — one exact shell-known command plus its outcome and context,
- **workflow seed** — a reusable command artifact derived from one or more trusted chapters,
- **parameter card** — the visible argument/default/enum/help surface used when filling a seed,
- **runbook** — a curated collection of seeds, notes, and attachments for humans to inspect and reuse.

Those are related.
They are not the same object.

## 1) Workflow seeds should be explicit artifacts, not alias folklore

A workflow seed is not merely a saved string.
It should preserve enough truth to stay honest later.

A compact v0 seed could preserve:
- `seed_id`,
- `source_chapter_ref`,
- `lane_kind` — direct / proposal / workflow / replay,
- `source_kind` — operator / workflow / agent / plugin / imported,
- `peer_partition` — local / exact remote peer / unknown,
- `template` — the reviewed command template,
- `parameter_slots[]`,
- `basis_contract` — what must still match before strong execution,
- `share_posture` — local-only / attach-for-help / explicit-exportable,
- `visibility_class` — operator-private / workspace-local / team-shared / public-export.

Important posture:
- a seed is **reusable control state**,
- not current authority,
- not a standing approval,
- and not proof that the old basis still matches.

## 2) Parameter cards should stay visible and inspectable

Legacy shell reuse often hides parameters in positional habits, copied comments, or environment variables.
Schell can do better.

A good parameter card should make visible:
- argument name,
- expected shape,
- default if any,
- enum or constrained suggestions if any,
- whether the default came from the old chapter, current ground, or an imported policy/plugin,
- whether filling the slot changes authority or target identity,
- and whether the slot is secret-bearing and therefore should avoid transcripts or ordinary share lanes.

Candidate slot kinds:
- plain text,
- path/path-like,
- exact peer selector,
- enum choice,
- artifact reference,
- chapter reference,
- secret handle placeholder,
- authority profile selector.

The terminal may render these beautifully.
The transcript should still be able to say where each value came from.

## 3) Seed selection should land in active input or explicit review

The cleanest rule in this whole surface may be the most important one:
**selecting a workflow seed should not, by itself, run it.**

A good action ladder is:
- **inspect seed** — show provenance, old basis, parameter card, and recent outcomes,
- **insert into active input** — land the expanded or partially expanded command in the one editable shell-owned field,
- **review-run** — compare against current basis, show diffs, then admit or hold,
- **attach for help** — send the seed plus basis packet into a help lane,
- **export/share** — separately mediated.

This keeps reusable-command UX fast without letting palette selection become hidden execution authority.

## 4) Runbooks should stay historical and curated, not magical

A runbook can be superb without pretending to be a live automation engine.

A runbook might contain:
- a title and description,
- one or more seeds,
- human notes,
- exact chapter attachments,
- receipt attachments,
- peer or environment warnings,
- suggested order,
- and redaction/share policy hints.

But a runbook should still be treated as:
- curated history,
- reusable guidance,
- maybe attachable support material,
- not current live truth,
- and not an approval cache.

## 5) Search should be partition-aware

A seed or runbook browser becomes much more trustworthy when the operator can constrain the search.

Useful filters likely include:
- peer / host,
- current session,
- workspace / repo,
- lane,
- source kind,
- visibility class,
- and outcome class.

That lets Schell avoid the trap of one giant global command attic.

## 6) Promotion from chapter to seed should preserve provenance

Promoting a useful chapter into a seed should not bleach away where it came from.

The promotion surface should preserve at least:
- the source chapter id,
- lane/source/peer badges,
- old exit/outcome summary,
- relevant ground witness,
- and whether the new seed is merely reusable text or a stronger reviewed shape with a basis contract.

If the source chapter was proposal-lane or low-trust, the seed should say so.
That is not bureaucracy.
That is how saved reuse stays honest.

## 7) Drift should downgrade to hold, not hidden retargeting

A seed is especially dangerous when it looks familiar.

If the current ground, peer, authority wallet, or target identity drifted, Schell should prefer:
- **hold card**,
- **review-again**,
- or **inspect-only**,

rather than silently following the nearest current target.

This is where compare-and-set review posture meets reusable command UX.

## 8) Sharing must be explicit and redactable

Not every useful reusable command artifact should leave the machine.

Schell should probably distinguish:
- **local-only seed**,
- **attach-for-help bundle**,
- **team-shared runbook**,
- **public export**.

Each stronger outward move should make visible:
- what exact parts are leaving,
- whether command text, output, prompt metadata, peer identity, or paths are included,
- what redactions were applied,
- and whether the resulting artifact is durable or one-shot.

## 9) Things Schell should steal now

### Review-first workflow landing

Searching for a reusable command and landing it back in editable input is one of the best current product ideas in terminal land.

### Typed or constrained parameter hints

Visible parameters with enum-like choices are a big usability win, especially when the operator still gets the final reviewable command.

### Chapter-derived seeds

The safest reusable artifacts come from exact chapters, not fuzzy snippets.

### Opt-in share customization

When sharing is desired, the operator should be able to choose which parts of the command chapter or runbook leave the machine.

### Partition-aware recall

Host/session/workspace filters are a simple but high-value way to keep reuse grounded.

## 10) Things Schell should refuse

### Refuse aliases as the primary future

Aliases are too ambient and too lossy to carry Schell's honesty model.

### Refuse palette select equals execute

Fast selection is good.
Silent execution is not.

### Refuse provenance bleach on save or share

A seed or runbook should not lose its lane, source, or basis posture just because it became convenient.

### Refuse conversation-local proposal artifacts entering operator reuse by default

Agent/proposal work can inspire seeds.
It should not silently colonize the operator's reusable command library.

### Refuse giant workflow bureaucracy first

One seed object, one parameter card, one runbook posture, and one share ladder are enough to learn a lot.

## 11) No-regret first specimen set

A compact first cut could show:
1. one shell-authenticated chapter promoted into a workflow seed,
2. one parameter card with text, enum, and path-like slots,
3. one seed selected from search and landed into active input for review,
4. one seed that downgrades to hold because peer or ground drifted,
5. one attach-for-help export that includes only selected seed/chapter fields,
6. and one transcript slice showing chapter → seed promotion → parameter fill → review outcome.

That is enough to make Schell feel significantly more powerful than shell folklore without freezing notebooks, sync, team sharing, or final automation architecture.
