# Input authorship, prediction witnesses, and live-prompt humility

This surface exists to keep one very specific shell+terminal temptation honest:
**Schell should absolutely steal the best modern inline prediction and prompt-editing ideas, but it should do so by keeping ghost suggestions, accepted buffer text, live prompt truth, and reviewed action separately named.**

That is the small discipline that lets the shell feel amazing without turning “the terminal showed me this” into hidden authorship or hidden execution policy.

## 1) Why this surface exists

The archive already has:
- help grounds and suggestion humility,
- selection packets,
- active-input leases,
- shell-known packets,
- prompt budgets,
- workflow seeds,
- history correction,
- clipboard read/paste gates,
- and assistant-lane separation.

But there is still one missing seam between them:
**who currently owns the visible command line, and what exactly changed when a suggestion was accepted?**

That matters because modern shell UX increasingly mixes:
- inline ghost text,
- list-view predictions,
- click-to-move inside prompts,
- history recall,
- workflow insertion,
- paste/drop ingress,
- and helper/assistant proposal surfaces.

Without an explicit authorship split, those features become flattering but mushy.

## 2) Keep these four truths distinct

At minimum Schell should treat these as different states:

1. **ghost suggestion** — visible but not yet part of authored input
2. **accepted buffer text** — now part of the live editable line
3. **live prompt lease** — the one region where prompt-local editing is actually valid
4. **reviewed action** — the later stronger object that the operator explicitly runs/reviews

Those are adjacent truths.
They are not interchangeable truths.

## 3) Prediction witnesses should name source and acceptance posture

A prediction witness should probably be able to say at least:
- `source_family` — history / known-extern / workflow-seed / project-pack / helper / assistant / imported / unknown
- `presentation_mode` — inline / list / palette / card / unknown
- `acceptance_mode` — next-token / next-word / whole-line / parameter-slot / unknown
- `live_cost` — in-memory / cheap-local / explicit-local / explicit-remote / historical
- `confidence_posture` — exact-history / signature-shaped / heuristic / model-backed / imported / unknown
- `execution_posture` — suggestion-only / inserts-into-buffer / requires-review / unknown

This does not require one final predictor API.
It only requires the shell and terminal to stop pretending that every suggestion has the same truth story.

## 4) Acceptance should change authorship, not execution

One of the best rules available is simple:
**accepting a suggestion should change the buffer, not spend the action.**

That means Schell should prefer a clear ladder:
1. show ghost text or a suggestion row,
2. optionally explain why it appeared,
3. accept part or all into the buffer,
4. let the operator keep editing,
5. and only later enter the review/run path.

That is how fish, PSReadLine, and the best modern shells keep delight from becoming stealth execution.

## 5) Partial acceptance is worth stealing

Whole-line acceptance is useful.
Partial acceptance is a much more interesting luxury.

Schell should explore at least:
- accept next word,
- accept next path component,
- accept one parameter slot,
- accept one expansion-ready fragment,
- and accept into a structured fill target when a workflow seed or parameter card owns the slots.

The common law should stay the same:
**partial accept grows authored buffer text incrementally; it does not silently authorize or auto-complete the whole action.**

## 6) The live prompt should be a shell-known editable region

Click-to-move and mouse-local prompt editing are worth stealing.
But they should only operate inside the one live prompt lease the shell says is real.

That means Schell should keep these separately named:
- active live prompt,
- inactive but visible past prompts,
- restored prompt-like residue,
- readonly replay prompt views,
- and prompt-like text that happens to appear in command output.

If the terminal cannot tell which is which, it should degrade gracefully instead of guessing.

## 7) Buffer authorship families

The live editing buffer should not remain one anonymous pile of bytes.
It should at least be able to distinguish how text entered the buffer:
- typed directly,
- accepted from history prediction,
- accepted from helper/plugin predictor,
- inserted from workflow seed,
- inserted from history chooser,
- pasted/dropped from outside,
- inserted from a visible object action,
- or proposed by an assistant but not yet accepted.

This does **not** mean every character needs a forensic trail.
It only means stronger surfaces should not overclaim operator authorship where the shell still knows the insertion came from somewhere else.

## 8) "Why this?" should be first-class

A luxurious shell should be able to explain a suggestion without forcing the operator to leave the line.
Possible compact reasons include:
- matched recent command history,
- matched known-extern signature and current token slot,
- came from this workflow seed,
- came from project pack,
- came from imported runbook,
- came from helper predictor,
- or unknown imported source.

That one reveal already turns suggestion magic into suggestion discipline.

## 9) Input ingress still matters here

This surface must stay connected to ingress hygiene.
Text that was pasted, dropped, or imported into the buffer should not silently inherit the same posture as typed or accepted-inline text.

That does not mean pasted text is suspicious by default.
It means Schell should still know the difference between:
- direct typing,
- inline acceptance,
- and outside-world ingress.

That keeps later review, repair, and exact-handoff surfaces more honest.

## 10) Prompt-time budgets still apply

Prediction luxury belongs on the cheap path only when it is actually cheap.
Source-labeled suggestions are good.
Hidden prompt-time heroics are not.

So this surface inherits the prompt-budget ladder:
- in-memory predictions may live on the keystroke lane,
- richer local help may require explicit summon,
- remote/model-backed refresh should stay visibly explicit,
- and restored historical predictors should stay historical until refreshed.

## 11) First specimen set this surface wants

A good early proof set would show:
1. one inline ghost suggestion that is visibly not yet authored input,
2. one accept-next-word action that updates the buffer but does not run,
3. one list view that shows suggestion source and lets the user ask why,
4. one prompt-click move that works only inside the live prompt lease,
5. one visible refusal to edit a historical prompt because it is not live,
6. one workflow seed insertion that becomes ordinary editable input with provenance chips,
7. one paste/drop insertion that stays distinct from inline prediction acceptance,
8. one review card that only reflects actually accepted buffer text,
9. and one transcript slice proving that ghost suggestions are not durable command truth unless they were accepted and later reviewed.

## 12) What to refuse for now

Refuse for now:
- suggestion auto-run,
- hidden acceptance on cursor movement alone,
- prompt-click editing based on guessed scrollback,
- one undifferentiated predictor oracle,
- history recall that silently overwrites active input without an edit-visible step,
- and assistant/plugin proposals that enter the buffer without a separately named accept action.

## 13) Bounded conclusion

One of the easiest ways to make Schell feel modern and super awesome is also one of the safest:

**treat the prompt like an honest editor.**
Ghost text stays ghost text.
Accepted text becomes buffer text.
The live prompt is shell-known.
Reviewed action comes later.

That is enough to steal a lot of brilliance without locking the architecture too early.
