# Reentry cues, session restoration, and historical honesty

This surface records a new no-regret candidate cluster for Schell:
**make reentry and restoration radically nicer while refusing to confuse restored or discovered objects with current live authority.**

The design pressure comes from three directions:

- SlopOS keeps drawing sharp lines between live session scope, explicit restore/import, and policy-owned target selection.
- DelayBasin keeps arguing for one primary reentry cue, one durable latest path, and explicit stale paths that do not count.
- Current terminals show that restored sessions, semantic history, palettes, and shell-marked prompts can be magical when their boundaries stay honest.

## 1) One primary reentry cue

Schell should have one obvious trusted path back to the **current live lane**.
That cue should lead to the active-input field and the current live work context, not merely to “something that opened successfully”.

Candidate cues:

- one explicit “current live lane” jump target,
- one stable status strip entry,
- one keyboard route that never lands on a merely historical object first,
- and one transcript-safe textual indicator saying what the current live lane actually is.

This is a small feature with unusually high leverage.
Many restoration systems feel helpful until the user cannot tell whether they are looking at living state or a photograph of prior state.

## 2) Restored state is useful, but not live by default

Restored panes, blocks, and bookmarks should be first-class objects.
They are excellent for browsing, comparing, annotating, copying, and seeding into workflows.
But the default state should be honest.

Candidate state badges:

- `live` — backed by a current active object with reacquired shell truth,
- `restored` — reconstructed continuity object with no claim of current liveness,
- `historical` — durable past execution or archive object,
- `receipt` — durable result/witness object,
- `unknown` — object exists, current truth is not established.

Important posture:

- `restored` is not a weak synonym for `live`,
- `historical` is not a shame state,
- and a richly restored UI should still fail closed on strong actions until live truth is re-earned.

## 3) Hold cards instead of fake continuity

When a user lands on a non-live object and reaches for a strong action, Schell should produce a compact **hold card**.
This is the terminal analog of DelayBasin's epistemic brake.

A good hold card could say:

- what object the user is acting on,
- its current posture (`restored`, `historical`, `unknown`, or `drifted`),
- what exact witness is missing,
- and what explicit next move would reacquire a strong-action-safe target.

Examples:

- “Historical receipt only — inspect or derive a new proposal.”
- “Restored pane is not attached to a live process — reopen or reattach explicitly.”
- “Basis drifted — review the new exact target before rerun.”
- “Generic open is available; profile/session-specific open is not part of this seam.”

This is one of the best “super awesome” moves Schell can make because it turns refusal into guidance without lying.

## 4) Semantic-history style opening is worth stealing

One of the best old terminal ideas is iTerm2 semantic history: file-opening gets better when the terminal preserves current-directory context for each line.
Schell should steal that class of move aggressively.

A first-cut posture could be:

- each command block may preserve per-block cwd / subject context,
- clicks on paths/URIs may use that context for bounded open/inspect actions,
- transcript-safe text should preserve enough cues to explain why the open target resolved as it did,
- but strong actions still require a separate provenance/basis story.

That gives Schell smarter path and URI behavior without overloading semantic context into execution authority.

## 5) Unified search and palettes should separate finding from acting

Search and command palettes are clearly worth stealing.
The mistake would be to let one result list collapse all action stories.

A good Schell search result should keep at least:

- lane,
- authorship badge,
- liveness/restoration badge,
- basis posture,
- and the action families currently allowed.

That means a single palette could still span:

- current live commands,
- restored panes,
- historical receipts,
- saved workflows,
- bookmarks,
- and proposal/agent objects,

without implying that all of them can be rerun, attached to, or widened the same way.

## 6) Generic open is still not browser/session control

This surface inherits one valuable SlopOS lesson from OpenURI.
A contextual click/open feature can be rich and useful without silently becoming a browser-profile, cookie-jar, private-session, or disposable-target control plane.

So Schell should keep this split:

- **generic semantic open** — contextual open/inspect using the best available object-local clues,
- **explicit session/profile/disposable seams** — future named actions if the product ever really needs them.

That protects the shell+terminal from accidentally growing a hidden web/session policy plane through convenience clicks.

## 7) No-regret first cut

A first specimen set could stay small:

1. one current-live reentry cue,
2. one restored pane badge,
3. one historical receipt badge,
4. one hold card that explains how to reacquire a live target,
5. one semantic path-open specimen using per-block cwd context,
6. and one palette/search mock that keeps discovery unified but action stories separate.

That is enough to learn a lot without freezing restoration persistence, renderer, palette engine, or search schema.
