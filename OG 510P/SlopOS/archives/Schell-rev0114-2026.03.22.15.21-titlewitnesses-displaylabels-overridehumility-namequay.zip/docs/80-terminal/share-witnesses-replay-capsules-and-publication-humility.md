# Share witnesses, replay capsules, and publication humility

This surface exists to keep one especially tempting luxury bundle honest:
**Schell should absolutely steal chapter sharing, replayable casts, and live session viewing — but it must not let local review, durable artifacts, web publication, and live shared control collapse into one flattering “share terminal” button.**

The point is not to avoid sharing.
The point is to keep it legible.
A shell+terminal becomes dramatically more useful when an operator can hand off one exact command chapter, keep a replayable capsule, publish a tiny demo, or open a live view for a teammate.
It becomes dangerous when those surfaces no longer say whether they are local-only, durable, networked, public, input-bearing, or live.

## 1) Keep review buffers weaker than exported artifacts

At minimum, Schell should separate:
- **local review buffer**,
- **exact chapter export**,
- **replay capsule**,
- **published chapter artifact**,
- and **live share lane**.

Those actions are adjacent.
They are not interchangeable.
A searchable buffer is a convenience.
An exact export is a new local object.
A replay capsule is a durable artifact with fidelity choices.
A published chapter is a hosted object.
A live share lane has ongoing visibility and possibly ongoing steering.

## 2) A share witness should describe actual footing

A healthy share witness should carry things like:
- source chapter identity,
- export or publication strength,
- local/LAN/remote/public hosting posture,
- selected included parts (command, output, prompt, annotations, metadata),
- replay fidelity class,
- input-capture posture,
- secret/redaction posture,
- visibility or audience posture,
- revocation/unpublish posture,
- and residue posture.

It should also make clear what it is **not**:
- not proof that recipients viewed the artifact,
- not proof that all downstream copies are gone after revocation,
- not proof that underlying local files or sessions were granted,
- and not proof that a live session lane is the same thing as a published artifact.

## 3) Exact chapter export should stay smaller than publication

A strong export lane should say:
- what exact chapter or block was exported,
- whether the export is local-only,
- whether redaction was applied,
- whether the object is text-first or richer,
- and what digest identifies it.

The operator should be able to create an exact local artifact without silently publishing it anywhere.

## 4) Replay capsules need visible fidelity classes

Replay artifacts are not all the same.
At minimum Schell should distinguish:
- output-only replay,
- input-bearing replay,
- raw capture,
- and audit-grade session record.

That difference should stay visible.
An output-only capsule can often be shared more freely.
An input-bearing or raw capture lane deserves much louder warnings and probably stricter defaults.

## 5) Publication should expose destination and visibility before admission

For stronger publication moves, the shell+terminal should show things like:
- selected host or storage destination,
- local-only versus LAN versus remote relay versus public web posture,
- whether the artifact is link-only or embeddable,
- selected included parts,
- and whether later unpublish is possible.

One exported text file in a local workspace is not the same thing as a public permalink.
The system should say so.

## 6) Live share lanes should keep permissions explicit

A live shared session should say:
- whether viewers can only watch or can also steer,
- whether they receive full scrollback, no scrollback, or one bounded chapter,
- whether the lane is local-only, team-scoped, or link-scoped,
- and whether agent/tool activity is visible.

A live share lane is stronger than a finished artifact.
The terminal should say so.

## 7) Secret-bearing publication deserves stricter posture

A terminal chapter may contain hosts, tokens, prompts, raw paths, or echoed secrets.
So Schell should support stronger rails like:
- explicit secret-bearing badge,
- redaction preview before export,
- output-only default for ordinary replay capsules,
- refusal for unsafe public publication,
- or a local-only share offer instead of remote/public relay.

The rule should be:
local convenience is not equivalent to safe publication.

## 8) Revocation and unpublish need humility

An unshared block, deleted link, or closed live session is still useful.
But the wording should stay honest.
Good states might include:
- local export remains,
- remote link revoked,
- live share lane closed,
- future viewers blocked,
- downstream copies unknown,
- and audience consumption not proven.

That is much more honest than one generic “unshared everywhere” badge.

## 9) Keep share verbs separate

Schell should not collapse all share/export moves into one verb.
At minimum, the verbs should stay separately named:
- inspect chapter,
- copy local excerpt,
- export exact chapter,
- mint replay capsule,
- publish chapter link,
- publish embed,
- start local live share,
- start remote live share,
- grant view,
- grant steer,
- and revoke publication.

Those verbs imply different residue and different authority.
The shell+terminal should say so.

## 10) Publication receipts should prefer digest-first and redaction-visible truth

A healthy publication receipt should prefer:
- digest-bearing artifact identity,
- bounded redacted summaries,
- selected included-part manifest,
- visibility class,
- destination class,
- and revocation handle or policy.

It should avoid pretending that a raw literal chapter, full URI set, or full live shell state must become the durable receipt text.

## 11) A compact first proving slice

A compact first specimen should show:
1. one local chapter clip,
2. one exact local export card with digest,
3. one output-only replay capsule,
4. one input-bearing capsule with a louder warning,
5. one selective published chapter card with chosen included parts,
6. one local/LAN-only live share offer,
7. one remote/public publication offer with a stronger warning,
8. one live share lane with explicit view versus steer permissions,
9. one redaction-first refusal for secret-bearing publication,
10. and one revoke/unpublish receipt that stays smaller than “all copies disappeared.”

That is enough to make Schell feel unusually capable without freezing the final cast format, player, hosting backend, sync stack, or team-sharing architecture.

## 12) Things to refuse for now

Refuse for now:
- one generic “share terminal” action that hides whether the move is local copy, export, replay capsule, publication, or live share,
- literal full-subject durable receipts for sensitive chapter contents,
- publication artifacts that silently mint access to underlying local files or services,
- input-bearing replay as the silent default,
- and revocation wording that overclaims what happened to downstream copies or viewers.

The right law is:
**steal chapter sharing, replay, and live-view luxury — but keep capture scope, publication target, replay fidelity, redaction posture, and live authority visibly stronger than charm.**
