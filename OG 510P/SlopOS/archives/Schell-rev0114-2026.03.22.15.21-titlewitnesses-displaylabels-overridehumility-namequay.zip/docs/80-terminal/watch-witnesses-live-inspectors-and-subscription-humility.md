# Watch witnesses, live inspectors, and subscription humility

This surface keeps one boundary explicit:
**a great shell+terminal should let operators pin live inspector decks, watch repeated command output, and subscribe to changing evidence — but it should not let “live” panels impersonate current authority, hidden reruns, or stronger action rights.**

Modern tools keep rediscovering the same delight:
- polling views make changing output legible,
- file-triggered reruns shrink the edit-test loop,
- log inspectors collate incoming evidence into one place,
- and API watch streams make fast-changing systems navigable without constant manual refresh.

That is all worth stealing.
The failure mode is equally consistent:
- observation quietly becomes rerun,
- rerun quietly becomes restart/kill/act,
- subscription lag quietly becomes invisible,
- and stale panels quietly become authority theater.

Schell should steal the luxury while refusing the flattening.

## Core idea

Schell should probably distinguish at least seven nearby objects:

- **watch witness** — one explicit observational or rerun-backed live view request,
- **trigger source** — poll / fs-event / query refresh / appended-log / API watch / unknown,
- **inspector deck** — the visible panel or live working view,
- **inspector row** — one metadata-safe candidate or observation item,
- **rerun policy** — observe-only / rerun command / restart child / manual refresh only,
- **subscription state witness** — freshness, lag, overflow, reconnect, paused, stale-snapshot posture,
- **strong action request** — a later explicit step that still makes the target exact again.

Those objects are related.
They are not the same thing.

## 1) Watch witnesses should make refresh source and strength visible

A useful v0 **watch witness** probably needs fields like:
- `watch_witness_id`,
- `domain` — chapter / process / artifact / service / resource / mixed,
- `source_scope` — workspace / peer / host / cluster / chapterbook / deck / local-only,
- `refresh_kind` — poll / fs-event / query-rerun / appended-log / api-watch / unknown,
- `rerun_policy` — observe-only / rerun-command / restart-child / manual-refresh,
- `startup_behavior` — run-now / postpone / seed-from-snapshot,
- `busy_update_policy` — queue-one / drop / restart / prompt / unknown,
- `lag_posture` — current / stale / reconnecting / may-drop / overflowed / paused,
- `preview_posture` — metadata-safe / inspect-required,
- `history_posture` — ephemeral / saved-deck / exported-never / shared-never,
- `basis_ref` — optional source epoch or explicit command chapter basis,
- `action_posture` — observe-only / singleton-required / reviewed-target-set,
- `notes_ref?` — rationale or operator annotations.

That is enough to support rich live-inspector UX without freezing:
- one final watch/event protocol,
- one final dashboard toolkit,
- one final scheduler substrate,
- or one universal lag/overflow contract across all watch families.

## 2) Inspector decks should be visibly weaker than the shell

A live **inspector deck** is one of the nicest stealable surfaces.
It can hold:
- changing command output,
- collated logs,
- watched resources,
- health rows,
- service/process summaries,
- or evolving failure candidates.

But the deck should remain visibly weaker than the shell.
A row shown there is not yet proof that:
- the object still exists unchanged,
- the target remains current,
- the last change has been observed losslessly,
- or a stronger restart/open/kill/act request should inherit authority automatically.

## 3) Observe-only and rerun-backed decks should stay distinct

A repeated-command panel and a pure subscription panel are not the same shape.

### Observe-only decks
These are fed by already-existing streams or append-only evidence sources.
Examples:
- tail-like log decks,
- API watch results,
- directory-backed evidence decks,
- query-refresh decks that do not run arbitrary shell code.

### Rerun-backed decks
These actually run or rerun a command.
Examples:
- poll a command every N seconds,
- rerun tests when files change,
- restart a development server on edits.

Schell should not flatten these.
Observe-only decks are already stronger than static history.
Rerun-backed decks are stronger still because they consume execution budget, touch current state, and may produce new side effects.

## 4) Rerun policy needs names, not folklore

A good watch lane should make policy choices explicit:
- **run-now** versus **postpone**,
- **poll** versus **event-triggered**,
- **rerun** versus **restart**,
- **clear between runs** versus **retain history**,
- **queue one update** versus **drop while busy** versus **restart immediately**,
- **prompt on stronger action** versus **never act from here**.

This is where a lot of terminal folklore hides.
Schell should drag that truth into named posture badges and review-time copy.

## 5) Inspector rows should remain metadata-safe by default

Live decks are one of the easiest places for overexposed previews.
So a good default posture is:
- source badge,
- freshness/lag badge,
- scope badge,
- bounded summary,
- exact ref/handle,
- and explicit inspect/open steps for anything richer.

Rows should not ambiently reveal:
- secret-bearing payloads,
- quarantined snippets,
- full remote previews,
- or aggressive summaries that outrun the underlying evidence.

## 6) Row actions should still re-establish exact target truth

A visible row is useful.
It is not the same thing as target proof.

So Schell should likely support at least three action postures:
- **inspect or pin** — safe for many rows,
- **promote to reviewed target set** — for intentionally many-target actions,
- **singleton required** — for stronger open/restart/kill/rerun/edit/share style actions.

If a deck is lagged, reconnecting, or multi-match ambiguous, stronger actions should refuse politely and ask for an exact row or a reviewed set.
That is much better than turning “whatever is currently highlighted” into authority.

## 7) Great ideas worth stealing right now

### a) Polling inspectors with explicit cadence and difference posture
Great for unstable output, but cadence and diff mode must stay visible.

### b) File-triggered rerun decks with explicit debounce and restart policy
Wonderful for development loops, but they should say what events count and what happens when the child is busy.

### c) API-watch-backed resource decks
Especially good for fast-moving systems, but auth/scope and reconnect posture should stay visible.

### d) Log/evidence inspectors with richer local analysis
Filtering, tagging, comments, partitions, and contextual jump-back are excellent steals.

### e) Lag, overflow, and reconnect badges
A “live” deck that cannot confess staleness is a liar.

### f) Explicit promote-to-target-set paths
This is how multi-object action can stay honest when the deck itself is not authority.

## 8) Things Schell should refuse

### Refuse live-panel-equals-target
Visibility is not exactness.

### Refuse observe-rerun-act collapse
A deck that observes should not silently become a shell loop or a control plane.

### Refuse hidden overflow or reconnect stories
Dropped updates and stale snapshots must be legible.

### Refuse hover/peek leakage on sensitive rows
Richer preview should remain an explicit stronger step.

### Refuse ambient long-lived watcher daemons by default
Live decks are not schedulers, supervisors, or background leases unless separately promoted.

## 9) No-regret first specimen set

A compact first cut could show:
1. one repeated-command inspector with cadence + diff badges,
2. one file-triggered rerun deck with debounce/restart posture,
3. one appended-log deck with metadata-safe rows,
4. one API-watch-backed resource deck with reconnect/lag posture,
5. one row action refusing to inherit authority from a stale or multi-row deck,
6. one explicit promote-to-target-set review path,
7. one paused/degraded badge that is weaker than live truth,
8. and one refusal to let a watch deck silently become a background scheduler or service supervisor.

That is enough to make Schell feel substantially more awesome at live observation without freezing a large watch stack.

## 10) The no-regret move

The best move right now is not to freeze one universal watcher framework.
It is to pin one rule:
**live comfort in Schell should become explicit watch witnesses, inspector decks, lag/overflow posture, metadata-safe rows, and singleton-aware stronger actions before it becomes ambient watcher folklore or hidden authority.**
