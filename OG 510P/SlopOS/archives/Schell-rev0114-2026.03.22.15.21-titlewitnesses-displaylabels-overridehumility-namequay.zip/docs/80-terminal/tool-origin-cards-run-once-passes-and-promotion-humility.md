# Tool-origin cards, run-once passes, and promotion humility

This surface exists to keep one increasingly tempting shell myth honest:
**Schell should become dramatically better than classic shells at helping you obtain and run tools — but it should do that by separating run-once execution, exact pinning, project promotion, user installation, cache reuse, and startup mutation, because “this command can run now” is not the same fact as “this tool is trusted, reproducible, or part of my shell forever.”**

The point is not to avoid package managers or installer comfort.
The point is to keep acquisition truthful enough that the shell still knows what actually happened.
A custom shell+terminal can be super awesome here if it treats tool arrival as a ladder rather than one magical install gesture.

## 1) Keep acquisition posture smaller than execution truth

At minimum Schell should separate:
- **tool-origin card** — where this commandable thing came from,
- **execution basis** — what exact source/ref/version/revision/digest is being requested for this run,
- **cache posture** — whether the bytes are fresh, reused, floating, historical, or unknown,
- **promotion target** — transient run / workflow seed / project environment / user shelf / native pack,
- **startup mutation** — whether PATH, shell init, or other search/startup footing will change,
- **review basis** — what exact command and source were actually reviewed,
- **evidence sidecars** — lockfiles, attestations, SBOMs, provenance, or proof bundles when present.

Those objects are adjacent.
They are not interchangeable.

## 2) A tool-origin card should describe real footing

A healthy tool-origin card should probably carry compact truth such as:
- `origin_family` — local-project / project-lock / user-installed / registry-ephemeral / registry-cached / git-ref / third-party-tap / installer-script / imported-unknown,
- `selector_strength` — digest / exact-version / exact-rev / tag / branch / floating-name / latest-like / unknown,
- `cache_posture` — fresh-fetch / cache-reuse / lock-resolved / historical / unknown,
- `install_scope` — none / transient / project / user / system / startup-mutation-needed / unknown,
- `source_owner_posture` — project-owned / first-party / third-party / personal-repo / imported / unknown,
- `startup_mutation_posture` — none / path-append / path-prepend / shell-config-edit / helper-script / unknown,
- `claim_strength` — runnable-now / exact-pinned / lock-backed / locally-reviewed / attested / historical / unknown.

That already gives Schell a much more honest tool story without freezing one final package or provenance stack.

## 3) Run-once passes should be first-class

Modern tools keep proving that one-shot execution is worth stealing.
Schell should embrace that with a dedicated **run-once pass** object.
A run-once pass is the shell saying:
- this command can be executed now,
- through this external source family,
- at this selector strength,
- under this cache posture,
- without pretending that the tool has joined your durable environment.

That is a much stronger story than either of the old extremes:
- “please install a bunch of stuff first”, or
- “sure, we fetched something and now it is just part of your life somehow”.

## 4) Exact-pin rails should stay separate from run-once comfort

A big source of confusion in today’s tooling is that run-once and exact-pin often look almost the same to the operator.
Schell should keep them explicitly separate.
Possible rails:
1. **run floating once** — great for discovery, weakest claim strength,
2. **run exact version once** — stronger, still not durable installation,
3. **run exact revision once** — stronger still, especially for git-backed tools,
4. **run from project lock/spec** — project-owned footing,
5. **run local reviewed artifact** — strongest local footing.

That makes “what exactly am I running?” answerable at a glance.

## 5) Promotion ladders are the super-awesome move

Schell should make the next step after a successful transient run explicit.
A good promotion ladder would look like:
- **keep transient**
- **pin into this command/workflow**
- **promote into project environment**
- **promote into user tool shelf**
- **promote into native Schell pack**

Each step should show what changes:
- source/ref,
- lock surface,
- path/startup consequences,
- cache reuse assumptions,
- and review obligations.

The shell becomes delightful not by hiding those changes, but by making them easy to compare.

## 6) Startup mutation deserves its own review family

Today’s tool installers still routinely ask to append or prepend to `PATH`, edit shell startup files, or route future command resolution through new directories.
Schell should treat those as **startup mutation cards**, not post-install trivia.

A startup mutation card should say:
- what file or startup surface would change,
- whether the change appends or prepends,
- what command names may now resolve differently,
- whether the change is reversible,
- and whether the new path contains one tool, many tools, or an external package shelf.

That is exactly the kind of move that will make the shell feel safer and more modern than today’s installer culture.

## 7) Cache posture must stay visible

Cache reuse is often wonderful.
It is not the same thing as exact reproducibility.
So Schell should badge cache posture explicitly:
- fetched now,
- reused cached environment,
- lock-resolved local cache,
- staleable floating cache,
- historical artifact,
- unknown.

That single distinction will prevent a lot of accidental overclaim.

## 8) Source widening should remain visible

Registries, third-party taps, git repositories, installer scripts, and project locks should not collapse into one “external tool” blob.
Schell should keep source widening explicit because that is where a lot of trust confusion starts.
A direct tool name from a project lock is not the same as:
- a package fetched by floating name from a registry,
- a binary from a user-local shelf,
- a tool from a third-party tap,
- a crate installed from a branch or tag,
- or a tool introduced by an installer script.

## 9) A compact first proving slice

A strong first specimen set would show:
1. one missing-command card that offers a run-once pass,
2. one run-once pass from an external registry with cache posture visible,
3. one exact-version rail beside the floating one,
4. one exact-revision rail for a git-backed tool,
5. one project-lock-backed promotion target,
6. one user shelf promotion target,
7. one startup-mutation card showing PATH append vs prepend,
8. one third-party source card (tap/repo) beside a project-owned source card,
9. one cache-reuse badge that remains weaker than lock-backed footing,
10. one refusal to treat a label like `latest` as exact review basis,
11. and one evidence sidecar that strengthens understanding without replacing explicit source selection.

That is already enough to make Schell feel unusually capable without freezing the final install stack, package-manager abstraction, or provenance engine.

## 10) Things to refuse for now

Refuse for now:
- one generic install button,
- cache reuse posing as exact reproducibility,
- package labels posing as exact basis,
- third-party source widening posing as ordinary project truth,
- and startup/path mutation posing as postscript instead of a first-class approval step.

The right law is:
**steal tool convenience, but keep origin truth, exact basis, cache posture, promotion target, and startup mutation separately named.**
