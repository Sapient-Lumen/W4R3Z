# Prompt budgets, idle lanes, and cheap delight

This surface keeps one design rule in view:
**make the custom shell+terminal feel instant and brilliant without letting prompt-time helper work, background warm state, or restored caches quietly become correctness dependencies.**

The goal is not to freeze one scheduler, daemon, cache, or async stack.
The goal is to keep the prompt trustworthy while still leaving room for a lot of delightful behavior.

## Why this surface exists

Schell already has:
- completion cards,
- parameter help,
- shell-known packets,
- command chapters,
- object cards,
- workflow seeds,
- transcript cards,
- restored-session honesty,
- and enrichment packets.

That is enough to make the project ambitious.
It is also enough to create a classic trap:
smart features begin competing to run during the most sensitive moment in the whole interface — while the operator is typing and waiting for the prompt to feel live.

If that critical path becomes crowded with helper exec, remote reads, disk walks, metadata crawls, or resurrection repair, the shell may still be powerful but it stops feeling trustworthy.

## The compact answer: timing lanes

Schell should probably name a few timing lanes explicitly.
Not because timing itself is the product.
Because timing determines which kinds of “smartness” are safe to normalize.

### 1) Keystroke lane

This is the strictest lane.
It covers typing, cursor movement, immediate inline suggestion display, and other interactions that must feel effectively instant.

Good occupants:
- shell-static grammar/help,
- shell-witnessed prompt/chapter facts,
- in-memory history hits,
- in-memory cached rows already admitted for local reuse,
- and cheap formatting of already-known values.

Bad occupants:
- forks,
- shell-outs,
- remote reads,
- materialization,
- on-demand metadata crawls,
- or any hidden “generator” that can stall the operator.

## 2) Prompt-render lane

This lane covers prompt paint, chapter chrome, command guides, local badges, and other information that can appear alongside the prompt without blocking on expensive work.

The rule should still be strict:
**the prompt can be informative, but it should not need heroics to become visible.**

A good prompt-render move is:
- show cwd/peer/ground witnesses the shell already knows,
- show cached badges with freshness posture,
- or reserve space for richer info that may arrive later.

A bad prompt-render move is:
- run a slow helper merely to make the prompt complete,
- perform remote probes for prettier status,
- or make prompt correctness depend on rc-hook folklore.

## 3) Explicit summon lane

This lane exists because richer help is often worth real work.
The operator may explicitly ask for:
- focused parameter help,
- stronger completion search,
- semantic-link refresh,
- object inspect-more,
- workflow editing,
- or a richer diagnostic explanation.

That is fine.
The critical distinction is that the operator asked.
This is where local helper exec, bounded disk inspection, doc lookup, and even remote reads can live, as long as source/freshness/cost posture stays visible.

## 4) Idle repair lane

Some work is useful only after the prompt is already usable.
Examples:
- refreshing a stale semantic-link row,
- rebuilding a local completion cache,
- rechecking metadata for a pinned object hint,
- reacquiring richer badges for a restored chapter shelf,
- or precomputing cheap local indexes while the operator is idle.

This lane should improve local UX without silently changing what current truth means.
If a row becomes fresher, badge it.
If a repair fails, keep the old row visibly stale or historical.

## 5) Historical lane

Restored, replayed, and imported help belongs here.
Examples:
- resurrected history shelves,
- replay-derived preview cards,
- imported workflow rows,
- cached object hints from a previous session,
- or restored semantic-link maps.

This lane is valuable because it makes re-entry fast.
But it must stay visibly historical until fresh shell truth or fresh inspection upgrades it.

## Rule 1: opening a menu is not permission to do work

This should be one of Schell's hardest rules.
Opening a completion menu, hovering a token, focusing a card, or revealing a palette does **not** by itself authorize lane escalation.

No hidden move from keystroke lane to summon lane.
No hidden move from prompt-render lane to remote fetch.
No hidden move from restored lane to live truth.

If stronger work would help, offer:
- refresh,
- inspect more,
- materialize,
- or another named second step.

## Rule 2: shell-known truth gets first claim on the fast path

If a delightful feature can be powered by:
- active prompt leases,
- chapter boundaries,
- cwd witnesses,
- peer witnesses,
- or exact selection packets,

then Schell should prefer that over helper inference.

This is how the terminal gets smarter while still staying portable and honest.

## Rule 3: caches and warm state are optional accelerators, not truth planes

A cached row may be excellent.
A restored working set may be genuinely useful.
A warmed preview may save time.

But none of these should create a new expectation that:
- the cache must exist,
- the warm state must be current,
- or the renderer-local store is now the authority plane.

The shell+terminal should still function correctly with those accelerators missing, stale, or disabled.

## Rule 4: repair before promotion

When restored or warmed help is upgraded, the upgrade should be explicit enough that the operator can tell the difference between:
- historical,
- cached,
- freshly reacquired,
- and shell-witnessed.

Do not let a restored row silently become current truth without a visible repair or refresh step.

## Rule 5: richer display should not rewrite insert or execution behavior

This extends earlier Schell surfaces.
A row may get:
- better icons,
- richer annotations,
- new freshness badges,
- more context,
- or a repaired preview.

That should not silently change:
- the inserted value,
- the selected object,
- or the approved action class.

## A small budget ladder

A useful default ladder might be:

1. **instant** — in-memory only; safe for typing,
2. **cheap local** — already-known shell facts or already-held local cache,
3. **explicit local** — bounded local helper, doc lookup, or inspection on request,
4. **explicit remote** — remote read or network-backed refresh on request,
5. **materializing / authority-sensitive** — separate stronger step.

The names can change later.
The important thing is the ladder itself.

## Stealable “super awesome” moves under this model

This still allows a lot of brilliance:

### Instant active-prompt editing
Click-to-move inside the one live prompt because the shell marked the editable region.

### Instant command guides and chapter jumps
Command boundaries, guides, and copy-output affordances powered by shell-known chapters.

### Inline summon that stays inert
Autosuggestions and history hits that land into input only when accepted.

### Focused help on demand
`show me this parameter` or `expand this flag` without changing the run path.

### Idle freshness repair
A cached row can quietly become fresher later, but the result is visibly upgraded rather than silently substituted.

### Restored shelves with honest posture
A working set from the last session can be present immediately while remaining clearly historical until repaired.

These are exactly the kinds of moves that make a shell+terminal feel luxurious without becoming haunted.

## Decisions intentionally kept open

This surface does **not** freeze:
- one async runtime,
- one worker topology,
- one cache backend,
- one resurrected-state store,
- one shell integration protocol,
- one preview engine,
- or one completer/plugin API.

The commitment is smaller:
**keep the prompt-critical path cheap, keep richer work in named lanes, and treat warm state as optional acceleration rather than truth.**

## Followthrough still owed

The archive now owes a specimen set showing at least:
1. one keystroke-lane suggestion that uses only shell-static or shell-witnessed state,
2. one prompt-render badge that reserves space and upgrades later without blocking prompt paint,
3. one explicit summon action that runs a local helper only after operator request,
4. one idle-lane refresh that upgrades a stale row with visible freshness change,
5. one restored row that stays historical until repaired,
6. one strong action refused because it would exceed the current lane/budget,
7. and one transcript slice showing cheap delight versus explicit expensive help honesty.

That is enough to learn a lot before freezing any big smart-terminal runtime.
