# Geometry witnesses, grid pixels, and reflow humility

**Schell should absolutely steal excellent resize comfort — live rows×cols chips, pixel-aware image/media placement, pane equalization, split zoom, layout memory, and gentle reflow — but it must not let requested size, realized window pixels, viewport cells, cell metrics, mux policies, or reflowed local views flatten into one flattering “the terminal is this size” story.**

## 1) Why this seam matters

A super-awesome shell+terminal gets noticeably better the moment geometry feels explicit instead of magical:
- split and zoom operations feel predictable,
- inline media and plots know what space they really have,
- remote and muxed panes explain why a shortcut or layout feels cramped,
- quick terminals and drop-down shells stop surprising operators across monitors,
- and copy/search/fullscreen tools stop pretending every visible line is durably shaped the same way.

But this is also a classic place where terminals and shells lie by accident.
A requested 132×40 grid is not always the realized viewport.
A window rectangle in pixels is not the text area.
A pane viewport is not the whole window.
A cell size is not the same as font size.
A line reflowed after resize is not the exact byte/line structure that first arrived.
A tmux pane can be constrained by another client that the operator cannot currently see.

Schell should therefore keep at least these families separately named:
- **requested geometry**,
- **realized window pixels**,
- **realized viewport cells**,
- **cell metrics and display gaps**,
- **mux/pane sizing policy**,
- **reflow posture for local view state**,
- and **later exact shell/output/result truth**.

## 2) The historical lesson: geometry has more owners than people admit

Current terminal systems keep proving the same thing.
Geometry is negotiated, not bestowed.
The window manager may clamp or decorate a window.
The terminal may align cells inside a larger pixel rectangle.
A pane may see only a subset of the window.
A multiplexer may pick the smallest or most-recent client as the controlling size.
A quick terminal may size itself in percentages on one axis and pixels on another.
A fullscreen or alternate-screen app may react to rows/cols while media helpers care about pixel size.

The design lesson is not “force one universal size model.”
It is:
**never let requested size, realized grid, realized pixel area, cell metrics, mux policy, and reflowed display collapse into one hidden truth object.**

So Schell should carry compact geometry posture badges such as:
- `request-132x40-cells`,
- `realized-1278x782-px`,
- `viewport-130x38-cells`,
- `cell-gap-centered`,
- `tmux-smallest-client`,
- `split-resize-pixel-policy`,
- `reflowed-local-view`.

## 3) Requested size is an intent, not a guarantee

Some terminals still think in grid cells for initial windows.
Some quick-terminal surfaces can size in percentages or pixels.
Some window managers or compositor rules clamp or override those requests.
Some decorations consume pixels that the text grid never gets.
That means the operator-visible request should stay weaker than the realized geometry.

Schell should import the right lesson:
**requested geometry is an opening proposal, not a durable fact.**

A geometry card may honestly say:
- `requested 132×40 cells`,
- `window manager clamped width`,
- `decorations consumed outer pixels`,
- `viewport now 126×38 cells`,
- `pane inherited reduced rows from mux policy`.

That kind of honesty is better than pretending the config file, the new-window recipe, or the restored workspace still tells the whole truth.

## 4) Pixels, cells, and text area are different seams

Inline media, image protocols, and richer layout features keep proving that rows/cols are not enough.
Applications may care about window pixels, text-area pixels, character-cell pixels, or visible rows/cols.
Those are related, but they are not interchangeable.
Sometimes the window rectangle exceeds the text area because of borders, title bars, or scrollbars.
Sometimes the terminal grid leaves a small gap because the outer window is not an even multiple of cell size.
Sometimes line height and cell width are deliberately scaled relative to font metrics.

Schell should steal the comfort while refusing the lie.
The shell+terminal may:
- render images with pixel-aware placement,
- reveal cell metrics for layout debugging,
- or align spare gap space intentionally,

but exact shell/output truth still needs stronger objects than “it looked like this many rows on my screen.”

## 5) Reflow is a local luxury, not a canonical output rewrite

Modern terminals and editors increasingly rewrap lines when width changes.
That is often delightful.
It keeps browsing humane.
It makes narrow or wide layouts much easier to live with.

But Schell should keep one strict rule:
**a line that reflowed in a local viewport is not automatically the canonical shape of the output that first arrived.**

So geometry witnesses should keep:
- **arrival shape / exact output chapter**,
- **current viewport width**,
- **reflow posture**,
- and **stronger promotion paths back to exact output**

separately named.

This is especially important for:
- copied excerpts,
- saved snippets,
- screenshot-like evidence,
- and command-aware paging/captured-output decks.

## 6) Multiplexers and split systems need explicit ownership confession

Muxers and split systems are especially good at flattening geometry truth.
One client may resize another.
One split system may resize by cells while another does so by pixels.
One pane may zoom to occupy the whole tab while another remains geometrically present but hidden.
One remote hop may preserve rows/cols but lose pixel information.

Schell can become unusually honest here by making the distinction obvious:
- **window owner** versus **pane owner**,
- **terminal-local split policy** versus **mux-wide size policy**,
- **requested split delta** versus **realized viewport delta**,
- **local reflow** versus **exact command/output recall**.

That creates room for excellent layout comfort without pretending every resize is a shell-authored truth event.

## 7) What Schell should do now

### A. Add **geometry witnesses**
Each geometry-aware surface should be able to carry:
- `requested_geometry`,
- `window_pixel_rect`,
- `text_area_pixels`,
- `viewport_cells`,
- `cell_metric_posture`,
- `resize_owner`,
- `mux_policy`,
- `reflow_posture`,
- and `strongest_safe_next_action`.

### B. Add **resize receipts**
When a meaningful resize happens, Schell should be able to show a tiny exact object such as:
- request source,
- realized rows/cols,
- realized pixel rect,
- whether the change was local, mux-imposed, or manager-imposed,
- and whether visible lines were reflowed locally.

### C. Add **geometry chips**
Do not hide the geometry stack.
A compact chip row should be able to admit:
- `132×40 requested`,
- `1280×784 px window`,
- `126×38 viewport`,
- `line-height 1.15`,
- `gap centered`,
- `tmux latest-client`.

### D. Keep **reflow weaker than output truth**
Viewport reflow, wrapped copy, and resize-local text selection all remain observation or convenience facts unless explicitly promoted back through command/output witnesses.

### E. Keep **media/layout helpers away from authority inflation**
Image placement, plot layout, and pane equalization should be geometry-aware, but they should not silently rewrite shell truth, transcript truth, or result identity.

## 8) Super-awesome ideas worth stealing now

- one always-available geometry chip that reveals requested vs realized size,
- one resize compare card that admits whether a mux, remote peer, or window manager won the negotiation,
- one reflow badge on copied or saved excerpts when visible lines were rewrapped locally,
- one pixel-aware media/layout strip for images, tables, and plots,
- one split-zoom receipt that explains what is hidden versus destroyed,
- and one restore-workspace card that says whether size is exact, clamped, or merely proposed.

The especially good Schell twist would be:
**make resize and layout comfort first-class, then keep requested geometry, realized pixels, viewport cells, cell metrics, mux policy, and reflowed local view separately named.**

## 9) Decisions intentionally kept open

This pass does **not** freeze:
- one final window-manager treaty,
- one final pixel-versus-cell API,
- one final mux sizing policy,
- one final reflow model,
- one final media-layout protocol,
- or one final pane/workspace engine.

The no-regret move is smaller:
**make terminal geometry first-class and luxurious, but keep requests, realized layout, local reflow, and later exact shell/output truth separately named.**
