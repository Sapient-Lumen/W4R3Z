# No-regret shell+terminal moves

This surface exists to protect Schell from a very normal failure mode:
falling in love with terminal cleverness early and accidentally freezing the shell architecture around it.

The point is not to become timid.
The point is to separate **high-value humane affordances** from **architecture-binding commitments**.

## Category A — no-regret now

These look worth pursuing immediately because they improve humane reviewed control without forcing major early decisions.

### 1) Explicit truth boundaries

Carry shell-emitted boundaries for at least:

- prompt,
- active input,
- reviewed action,
- command output,
- receipt,
- denial,
- and background-state change.

### 1.5) Command chapters and exact journals

Treat shell-known command chapters as first-class navigation units, and keep journals partitioned by source, lane, and peer so recall stays useful without becoming hidden rerun authority.

### 2) Command-block trust ladder

Use a small trust ladder:

- guessed,
- marked,
- shell-authenticated.

Every richer block action should declare its minimum trust grade.

### 3) Review cards with exact basis

Whenever the action is effectful or authority-bearing, show:

- exact subject,
- exact mutable basis when relevant,
- intended action,
- requested authority,
- and approve / deny paths.

### 4) Receipt / denial objects as navigation units

Treat receipts and denials as objects you can jump to, search, pin, and replay-readonly.

### 4.5) Scoped work lanes

Keep direct commands, proposal/agent work, receipts/denials, background residue, and workflow artifacts visibly distinct even if they share one search surface.

### 5) Prompt-safe pointer editing

Allow cursor movement and selection inside active shell-marked input.
Refuse pointer editing authority over historical output.

### 6) Threshold-based finish notifications

Notify on long-running work only when duration and focus rules say it is helpful.

### 6.25) Compact authority strips

Show a tiny descriptive authority summary on the active lane or review card: wallet digest, drift state, and lease hints.

### 6.5) Basis-drift warnings

When a block, receipt, or background entry no longer matches the exact mutable basis it was reviewed against, say so explicitly instead of pretending the old affordance still means the same thing.

### 7) Readonly replay mode

Make past actions easy to inspect without granting live input to the current substrate.

### 8) Exact preview

Previews should help observation while making zero claims about reopen, resume, or hidden write authority.

### 9) Transcript truth

Every rich surface above must still leave behind honest plain text.

## Category B — bounded prototypes only

These look promising, but each should stay explicitly reversible until it proves itself.

### 1) Sticky reviewed-action headers

Very likely useful.
Still a local rendering choice, not shell truth.

### 2) Session atlas / operator cockpit

Likely high-value, but the exact set of panels and jump objects should remain flexible.

### 2.5) Semantic inspector overlay

Very promising for both operator trust and design-phase debugging, but still a rendering choice until the minimal truth surfaces are more proven.

### 3) Mode tables for review / replay / shelf navigation

Promising and probably right.
Still should remain local UX until a minimal set proves itself.

### 4) Structured output sidecars

Worth exploring for receipts and effect summaries.
Do not let them quietly turn into a universal object pipeline yet.

### 4.5) Workflow seeds

Promising as explicit reusable command artifacts, but still should remain separate from ambient aliases or reusable approvals.

### 4.75) Authority diff cards

Promising and probably worth proving early, but still should remain a compact review object instead of quietly expanding into a general permission dashboard.

### 4.875) Object cards and exact reveal ladders

Promising because typed visible-object actions can make terminals feel dramatically smarter, but still should remain bounded to exact reveal/open/insert/safe-open posture rather than expanding into a giant preview engine or document browser.

### 5) Inline media / richer previews

Potentially delightful and useful.
Still clearly luxury until transcript-safe proving slices exist.


## Category C — do not decide yet

These decisions are too architecture-binding to settle before stronger proof.

### 1) Final shell↔terminal transport

Do not freeze escape-sequence only, side-channel only, or hybrid until remote hops, replay, and transcript persistence are better understood.

### 2) Final renderer / line editor / TUI stack

Do not mistake currently attractive crates or products for the architecture.

### 3) Universal structured pipeline model

Do not turn pipeline ontology into the first design victory.

### 4) General plugin or extension protocol

Hold this until the core shell truth surfaces are stable enough to deserve an ecosystem.

### 5) Cross-host trust or attestation story

A local trust ladder is worth prototyping now.
A cross-host or cryptographic attestation story is much heavier and should wait.

### 6) Embedded versus standalone terminal product shape

Keep both live as options until the proving slices reveal where the real friction is.

## Test every candidate move against these gates

A move is probably admissible only if it improves at least one of:

- exactness,
- review honesty,
- denial clarity,
- transcript truth,
- operator recovery,
- or background-state legibility.

And it should be held or narrowed if it silently chooses any of:

- final transport,
- final renderer stack,
- final pipeline ontology,
- final browser/session semantics,
- or final remote-trust posture.

## Current best reading

Schell can become super awesome by being **better at truth and better at operator comfort at the same time**.
The safest route is not to refuse ambition.
It is to pursue the ambitious moves that still leave the deep architecture open.
