# Keymap witnesses, chord discoverability, and editor humility

This surface exists to keep one especially tempting shell myth honest:
**Schell should absolutely steal brilliant command-line editing, discoverable shortcuts, help keys, menus, mode badges, and prompt-click cursor movement — but it should do so by keeping key events, bound editor actions, resulting buffer edits, and later reviewed execution separately named.**

That is the smaller discipline that lets a shell+terminal feel far better than bash without letting line-editor magic become a hidden second shell.

## 1) Why this surface exists

The archive already has:
- active-input leases,
- input-authorship and prediction witnesses,
- completion witnesses,
- help grounds,
- history/correction/undo rails,
- slot-linked edits and tabstop witnesses,
- and semantic prompt integration.

But one seam was still undernamed:
**what exactly fired when a key was pressed, a prompt was clicked, a help menu opened, or a widget ran?**

That matters because current shells and terminals increasingly mix:
- builtin edit functions,
- menu-local keymaps,
- shell-script widgets,
- history/prediction acceptance,
- help bindings,
- terminal-side prompt click events,
- and fallback event synthesis.

Without an explicit witness split, “the shell handled the key” becomes a flattering but mushy story.

## 2) Keep these truths distinct

At minimum Schell should treat these as different objects:

1. **input trigger** — key chord, mouse click, menu gesture, or fallback synthetic event
2. **binding resolution** — which keymap/mode/binding matched
3. **editor action** — builtin edit function, widget, help action, menu action, or submit action
4. **buffer effect** — what exact text/selection/cursor/mode changed
5. **reviewed action** — the later stronger object the operator explicitly reviews or runs

These truths are adjacent.
They are not interchangeable.

## 3) A keymap witness should name mode, source, and submission posture

A keymap witness should probably be able to say at least:
- `mode_kind` — insert / command / menu / search / help / history / prompt-click / unknown
- `trigger_kind` — key-chord / click-event / synthetic-fallback / imported / unknown
- `binding_source` — builtin-default / user-local / project-pack / imported-pack / bridge / terminal-helper / unknown
- `action_kind` — edit-function / widget / help-open / candidate-accept / menu-nav / line-submit / unknown
- `implementation_kind` — builtin / shell-function / scriptblock / bridge / terminal-fallback / unknown
- `effect_posture` — cursor-only / buffer-edit / mode-change / help-only / submit / unknown
- `discoverability_posture` — visible-hint / describe-key / key-reader / hidden / unknown
- `trust_posture` — shell-owned / imported / bridged / fallback-synthesized / unknown

This does not require one final editor engine.
It only requires Schell to stop pretending every shortcut has the same truth story.

## 4) Mode badges are worth stealing, but they should stay descriptive

Modern line editors keep proving that visible mode is good.
Modal editing can be delightful.
Menu-local modes are helpful.
Prompt-click posture matters.
A help menu is different from plain insert mode.

Schell should therefore support visible badges such as:
- **insert**,
- **command**,
- **menu**,
- **history search**,
- **help**,
- **prompt click**,
- **compat fallback**.

But those badges should remain descriptive.
A mode badge is not command meaning, not execution approval, and not proof that a terminal-side helper is acting natively.

## 5) “What does this key do here?” should be a first-class answer

One of the easiest brilliance steals in the current ecosystem is key discoverability.
Schell should be able to answer, in-context:
- what key was seen,
- which keymap matched it,
- which action it triggers in the current mode,
- whether that action only edits the buffer or can actually submit,
- where the binding came from,
- and what stronger action would still require fresh review.

A compact `DescribeKey` / `WhatIsKey` answer would already make Schell feel unusually humane.

## 6) Help keys belong inside the editor, not outside it

The ecosystem keeps showing that command help works better when it operates on the current buffer.
Schell should steal things like:
- help on the current command word,
- command-search menus from the active input line,
- doc/example insertion back into the buffer,
- and menu-local navigation that keeps the user inside the editing context.

But help should stay help.
A discovered example or inserted snippet should remain weaker than reviewed action.

## 7) Widgets and custom key handlers are real code paths

A particularly important historical lesson is that editor actions are often programmable.
User-defined widgets, scriptbound key handlers, project-local editor packs, and bridged bindings are all worth supporting.
But they should stay visibly weaker than native shell meaning.

At minimum Schell should distinguish:
- native builtin edit functions,
- user-local widgets,
- project-local/imported widgets,
- terminal-bridge actions,
- and fallback synthetic actions.

That one distinction already makes the prompt much more honest.

## 8) Prompt-click cursor movement is a great luxury only on live authenticated prompt ground

Prompt-click editing is a real upgrade.
Schell should absolutely support it.
But it should keep at least these postures separate:
- shell-authenticated live prompt click,
- terminal-assisted click on a marked prompt,
- compat fallback using synthesized navigation events,
- and no click-edit support.

That prevents “I clicked there and the cursor moved” from quietly becoming a claim that the shell actually authenticated the whole interaction.

## 9) Submit-class bindings should look stronger than ordinary editing

The prompt gets much less honest when submit-like actions look identical to edit-like actions.
A binding that only:
- moves the cursor,
- opens help,
- accepts a suggestion,
- or inserts text

is not the same class as a binding that:
- accepts the current line,
- accepts a menu choice and submits,
- or dispatches a stronger review/run flow.

So Schell should give submit-capable bindings a clearly stronger label such as:
- **edit only**,
- **insert only**,
- **accept candidate**,
- **help only**,
- **submit line**,
- **submit review flow**.

That one split protects a surprising amount of meaning.

## 10) Project-local keypacks deserve the same humility as other local accelerators

Shared repo bindings, imported editor packs, and workflow-local widgets can be wonderful.
But they should be visibly installed, locally leased, and reauthorized on change.
They should not quietly become ambient startup truth.

This is the editor-side analogue of refusing hidden hooks and hidden repo accelerators.
If a repo wants to add a leader key, a repair widget, or a smart submit action, Schell should make that visible before active.

## 11) First specimen set this surface wants

A good first proof set would show:
1. one `DescribeKey` answer for the current chord,
2. one visible mode badge transition,
3. one help key that acts on the current command word,
4. one menu-local keymap that is clearly menu-local,
5. one submit-capable binding that is visibly stronger than edit-only bindings,
6. one project-local widget with a trust/source badge,
7. one prompt-click edit path with native/bridged/fallback posture,
8. one compare view between triggered action and resulting exact buffer delta,
9. one refusal to let a binding-defined action pose as parser meaning,
10. and one refusal to silently enable repo-local bindings without a visible lease.

## 12) What to refuse for now

Refuse for now:
- one undifferentiated “shortcuts” story,
- hidden shell-script widgets on the cheapest prompt path with no visible source,
- project-local keypacks that quietly load through repo discovery,
- prompt-click compatibility fallbacks posing as shell-authenticated prompt truth,
- mode badges posing as parser or execution truth,
- and submit-class bindings that look identical to harmless edit commands.

## 13) Bounded conclusion

One of the safest ways to make Schell feel dramatically better than legacy shells is also one of the clearest:

**treat editor actions as witnessed local editing power.**
The keys can be rich.
The menus can be luxurious.
The help can be near at hand.
The prompt can feel clickable.
But the reviewed action still comes later.

That is enough to steal a lot of brilliance without freezing the architecture too early.
