# Progress scopes, cancellation, and drain honesty

This surface records a new no-regret candidate cluster for Schell:
**make progress, waiting, cancellation, and completion explicit shell-owned truths, while letting the terminal render them richly without turning badges, bars, or toasts into fake receipts.**

The design pressure comes from three directions:

- SlopOS already separates request coordination from authority and keeps request completion/cancellation request-local.
- DelayBasin keeps demanding explicit blocked-output, followthrough, and handoff honesty when a story is not actually over.
- Current terminals and IDE-terminals keep getting better at progress bars, finish notices, marks, and problem surfaces.

## 1) The shell needs one exact progress object

A good first object is **progress scope**.

A progress scope is a compact shell-owned descriptor for one running or recently-finished unit of work.
It is not the final scheduler.
It is not a giant workflow engine object.
It is not authority.
It is the thing the terminal can point at when it says “this is what is happening.”

A v0 scope probably needs:
- `scope_ref` — exact work unit,
- `lane_ref` — direct / proposal / workflow / background / replay,
- `basis_ref` — exact command, workflow seed, or receipt basis when present,
- `ctx_ref` — optional request-context or deadline digest,
- `state` — one closed state family,
- `progress_hint` — none / indeterminate / fraction / bounded-step-count,
- `cancel_posture` — none / request-cancel / interrupt-local / terminate-review-required / forget-local-wait,
- `drain_posture` — none / flushing / cleanup / handoff-pending,
- `problem_refs` — exact attached problem witnesses when present,
- `outcome_ref` — exact receipt / denial / hold / unknown witness when available.

That is enough to make progress and cancellation real without freezing a task engine.

## 2) One closed state family is better than terminal folklore

A useful first state family could be:
- `running`
- `waiting-input`
- `draining`
- `cancel-requested`
- `cancelled`
- `deadline-exceeded`
- `completed`
- `completed-with-problems`
- `unknown-after-disconnect`

That is already much more honest than the usual blur of spinner / no spinner / prompt returned.

## 3) “Cancel” should split into named moves

A generic stop button is too vague.
Schell should probably keep at least this small ladder:

- **bring-forward** — jump to the scope or show what it is waiting on,
- **request-cancel** — ask the exact scope to cooperate and stop,
- **interrupt-local** — send a local interactive break for the live foreground lane,
- **terminate-after-review** — stronger stop that should show review material first,
- **forget-local-wait** — stop local waiting/attention without claiming the work ended.

This is one of the cleanest ways to be humane without being slippery.

## 4) Drain honesty matters a lot

One of the oldest terminal lies is that “the operator asked to stop, so the story is over.”
Often it is not.
Cleanup may still run.
Buffered output may still flush.
A handoff may still be pending.
A background owner may still have accepted the work.

That is why Schell should have **drain cards**.

A drain card is a compact landing that says:
- what scope is draining,
- why it is still draining,
- what output or cleanup is still expected,
- what stronger stop remains available,
- and what exact witness will close the story.

This alone would make the shell+terminal feel markedly more trustworthy.

## 5) Deadline hints should be hints unless another seam enforces more

Deadlines are useful.
Operators like countdowns, overdue state, and “expected to finish around…” hints.
But Schell should keep the SlopOS posture:
- deadline metadata is coordination posture,
- not standalone authority,
- and not by itself proof that the runtime will definitely stop at that instant.

So a terminal may show a deadline chip, overdue state, or soft timeout warning,
but the shell should still emit the exact resulting transition:
- still running,
- cancel-requested,
- deadline-exceeded,
- draining,
- or completed.

## 6) Problems should stay attached to exact work

Current IDE-terminals keep rediscovering the same thing:
problem summaries become far more useful once they stay attached to one current task instead of floating free in output history.

Schell should steal that idea carefully.
A progress scope may attach:
- exact problem witnesses,
- exact output capsules,
- exact receipt refs,
- and exact hold/deny refs.

That lets the terminal show “2 problems” or “needs input” without inventing new truth.

## 7) Great product moves become possible here too

Once progress scopes exist, Schell can do genuinely excellent things:
- a tiny status strip for the current live scope,
- threshold-based finish notices,
- jump-to-problem from a running command,
- explicit “continue waiting or move on” cards,
- drain cards after cancel,
- readonly outcome panes for finished work,
- and handoff cards when work leaves the local lane.

This is the kind of “super awesome” that still respects decision deferral.

## 8) Transcript truth needs only the important parts

The transcript does not need every progress repaint.
It does need:
- scope creation,
- meaningful state transitions,
- cancellation requests,
- deadline-expired transitions,
- drain/handoff transitions,
- problem witness attachment,
- and the exact closing witness.

That is the portable minimum.

## 9) No-regret first cut

A first specimen set could stay small:

1. one direct command with indeterminate progress and a final exact receipt,
2. one command that waits for user input and surfaces a `waiting-input` state,
3. one command that gets `request-cancel` and then shows a visible drain card,
4. one long-running task with exact attached problem witnesses,
5. one soft deadline chip that becomes `deadline-exceeded` without pretending the work vanished,
6. one “continue waiting or move on” card,
7. and one transcript slice showing progress-scope transitions plus exact closing witness.

That is enough to learn a lot without freezing the final task engine, progress renderer, or scheduler.
