# Filesystem witnesses, mount roots, and bind humility

This surface keeps one boundary explicit:
**a great shell+terminal should let operators review filesystem footing — root view, cwd root, bind overlays, chooser-granted objects, and path-resolution posture — but it should not let prompt paths, host-tree folklore, or hidden mounts impersonate one another.**

Modern systems already have real filesystem machinery:
- mount namespaces can copy or isolate whole mount trees,
- root changes can happen by `chroot`, `pivot_root`, or sandbox construction,
- sandboxes can start from empty tmpfs-backed roots and then receive explicit bindings,
- bind mounts can shadow preexisting content and often write back to the host,
- chooser/document portals can hand out concrete files or persisted subtrees,
- and path-resolution APIs can constrain escapes and mount crossings.

That is all worth stealing.
The failure mode is equally consistent:
- a pretty cwd breadcrumb pretends to be the whole filesystem truth,
- root changes are described as generic “sandboxing” even when they are not,
- bind overlays stay invisible until expected files disappear or the host gets modified,
- portal-granted files get mistaken for broad path authority,
- and path strings in argv/env are treated as proof that the child can actually reach those locations.

Schell can do better without picking one final mount toolchain, container runtime, or path API.

## 1) The shell needs one exact filesystem witness family

A good first object is **filesystem witness**.

A filesystem witness is a compact shell-owned descriptor for the filesystem footing a reviewed action will enter.
It is not a universal file-manager API.
It is not a final mount browser.
It is the thing the terminal can point at when it says “this command will run inside *this exact filesystem posture*.”

A v0 family probably needs:
- `root_view_posture` — host_like / empty_root / switched_root / explicit_view / compat / unknown,
- `cwd_root_posture` — bound / descriptor / empty / inherited_compat / unknown,
- `overlay_posture` — none / bind_ro / bind_rw / layered / unknown,
- `shadowing_posture` — none / may_shadow / known_shadow / unknown,
- `propagation_posture` — private / shared / slave / unbindable / unknown,
- `object_grant_posture` — none / portal_chosen / docref_reopen / persisted_subtree / descriptor_only / unknown,
- `path_guard_posture` — beneath / in_root / no_xdev / symlink_restricted / compat / unknown,
- `receipt_posture` — exact_shell_outcome / provider_addendum / unavailable,
- `notes_ref` — optional explanation or refusal card.

That is enough to make filesystem truth real without freezing a giant path ontology.

## 2) Root view, cwd root, and visible path text should never collapse into one badge

A prompt path is often lying by omission.
Useful distinctions include:
- the root/view the process actually sees,
- the bound cwd root used for relative lookup,
- the rendered breadcrumb text shown to the user,
- and whether any of those are only compat or degraded approximations.

Schell should therefore separate:
- **root/view basis**,
- **cwd-root basis**,
- **rendered path text**,
- and **path-resolution posture**.

That lets the terminal say:
- “fresh empty root with one bound project subtree,”
- “cwd bound to descriptor-backed directory root,”
- “path text is presentational only,”
- “relative lookup guarded beneath bound root,”
- “filesystem footing degraded under legacy wrapper.”

That is dramatically more honest than one generic cwd chip.

## 3) Overlay and bind posture deserve first-class review

Bind mounts and overlays decide a surprising amount of behavior.
So Schell should be able to say:
- subtree bound read-only,
- subtree bound read-write,
- host-coupled overlay,
- may shadow existing content at destination,
- no overlay facts available,
- or overlay posture unknown/degraded.

That is a super practical luxury.
It prevents the classic debugging spiral where the operator only discovers after launch that:
- expected files are obscured beneath a bind mount,
- writes are really landing on the host,
- or a supposedly portable workflow depends on one host-specific directory layout.

## 4) Propagation posture should stay separately named

A namespace may still participate in mount propagation.
So a reviewed action should be able to confess:
- private,
- shared,
- slave,
- unbindable,
- or unknown.

This is not a universal namespace inspector.
It is simply enough honesty to prevent “new namespace” from masquerading as guaranteed isolation.

## 5) Chooser and portal grants should stay weaker than host-path truth

A file chosen through a portal or powerbox is not the same thing as ambient filesystem reachability.
The terminal should be able to say:
- one-shot chosen file,
- persisted reopen handle,
- persisted subtree mapping,
- descriptor-only file authority,
- or no chooser/portal grant involved.

That is crucial because it keeps:
- one selected file separate from broad folder access,
- explicit persistence separate from one-shot selection,
- and durable reopen handles separate from ambient path discovery.

## 6) Path-resolution guards should be a ladder, not a boolean

One especially good idea worth stealing is an explicit **path-guard ladder**.
At minimum the shell should distinguish:
- plain compat lookup,
- beneath-only lookup,
- in-root lookup,
- no-cross-mount lookup,
- symlink-restricted lookup,
- and provider-unknown posture.

Those are all useful.
They are not the same.

A very nice practical rung is **beneath/in-root review**:
show that a relative or rooted path will be resolved only beneath a reviewed root.
That is much weaker than promising a universal safe path API, but much stronger than hoping `..` and mounts behave the way the operator imagined.

## 7) Historical filesystem receipts should stay humble and exact

A shell can gain a lot by returning:
- exact reviewed root/view posture,
- cwd-root posture,
- overlay/shadowing posture,
- chooser/portal provenance,
- path-guard posture,
- exit/signal truth,
- optional created/read/written object summaries,
- and a claim-strength badge when the runtime could not prove more.

But it should avoid pretending to prove:
- the current live mount tree,
- the entire current host filesystem layout,
- that a prompt breadcrumb is still accurate now,
- that a document handle still implies current reachability,
- or that one historical receipt proves the present namespace forever.

## 8) Great ideas worth stealing right now

### a) Root-view / cwd-root split
Tiny but high value.
Do not flatten root view and cwd root.

### b) Overlay and shadowing badges
Make hidden binds visible before they surprise the operator.

### c) Portal/file provenance
Tell the operator when file authority came from chooser mediation rather than ambient path reachability.

### d) Persisted-subtree versus one-shot-file distinction
A durable mapped subtree is not the same thing as one selected file.

### e) Path-guard badges
Beneath / in-root / no-xdev / symlink-restricted / compat / unknown.
Wonderful operator hygiene.

### f) Empty-root luxury
Steal the “start empty, then add explicit views” pattern without freezing one sandbox runtime.

### g) Historical filesystem receipts
Make root/view and overlay footing explainable after run without overclaiming current truth.

## 9) Things Schell should refuse

### Refuse prompt-path theater
A rendered breadcrumb is not enough truth by itself.

### Refuse chroot-as-sandbox folklore
Changed root does not automatically mean good isolation.

### Refuse bind invisibility
Overlays and shadowing should not remain hidden until after launch.

### Refuse chooser-to-folder widening
One chosen object should not silently become ambient path authority.

### Refuse path-literal romanticism
A path string in argv/env is not proof of reachability.

### Refuse one giant filesystem plane too early
Schell should not yet freeze one universal path API, mount grammar, or sandbox backend.

### Refuse stale filesystem chrome as live authority
A restored root badge or old receipt should never impersonate present mount truth.
