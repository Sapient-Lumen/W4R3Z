# Trusted command blocks and action gates

This surface exists to turn one vague idea into a sharper prototype rule:
**visible command blocks should not all unlock the same actions.**

Schell can become much more humane than old terminals without pretending that every block on screen is equally trustworthy.
The goal is not heavyweight cryptography on day one.
The goal is a clean early ladder that keeps copy/select fast and keeps stronger actions honest.

## The problem

A modern terminal can usually show something block-shaped:

- a prompt region,
- a command line,
- its output,
- maybe an exit badge,
- maybe a working directory,
- maybe a sticky header,
- maybe a rerun button.

But those surfaces do not all come from the same truth source.
Some are pure buffer guesses.
Some are reconstructed from marks.
Some are explicitly reported by the shell.
Some may later be bound to exact reviewed action or receipt objects.

If Schell blurs those levels together, it will overclaim what it knows.

## Early trust ladder

### 0) Visible text only

The terminal has bytes on screen but no reliable structural marks.
It may know there is text.
It does not know where the real command or output boundaries are.

### 1) Marked block

The terminal has prompt/command/output boundaries from shell integration or equivalent marks.
That is enough for navigation and selection improvements.
It is still not the same as exact shell-vouched command truth.

### 2) Shell-reported command

The shell explicitly reported the interpreted command line or equivalent command object.
This is much stronger than buffer reconstruction.
The terminal now has a shell-side statement about what ran.

### 3) Shell-authenticated action object

The block is tied not only to shell-reported command truth but also to an exact reviewed action / receipt / basis object that the shell can name durably.
This is the strongest local trust Schell should aim for early.

This ladder is intentionally simple.
It can later grow finer distinctions if prototypes demand them.

## Confidence and trust

Do not confuse these.

- **confidence** = how well the terminal thinks it reconstructed the block,
- **trust** = whether the shell explicitly vouched for the block or action.

A block may have medium or high reconstruction confidence and still not be trusted enough for effectful actions.
That distinction is worth preserving in the UI.

## Action gates

### Allowed from visible text only

- ordinary text selection,
- plain copy,
- search,
- manual note-taking,
- open a readonly transcript view that makes no structural claims.

### Allowed from marked blocks

- jump between blocks,
- select exact command output,
- sticky command headers,
- prompt-aware resize behavior,
- copy command/output with block boundaries preserved,
- readonly navigation by prompt or output region.

### Allowed from shell-reported commands

- show exact interpreted command text,
- show working directory and exit status when reported,
- offer “edit before rerun” as a **new review path**,
- compare typed prompt input to interpreted command truth,
- show basis-drift warnings when the shell can detect them.

### Reserved for shell-authenticated action objects

- rerun as the same reviewed action,
- attach to related receipt/output objects,
- reopen exact artifact/result references,
- replay with semantic guarantees,
- agent follow-on actions that assume the block identity is exact,
- any action that would otherwise smuggle in prior approval or basis reuse.

## Downgrade rules

When trust is weaker than the requested action:

- say **why**,
- preserve the nearby safe action,
- and never relabel the weaker action as though it were the stronger one.

Examples:

- from a marked block, allow **copy command text** but not **rerun exact reviewed action**;
- from shell-reported truth without a durable action object, allow **edit and review again** but not **reuse prior receipt authority**;
- from stale shell-authenticated objects, show **basis drift** and require a fresh review.

## Basis drift and stale truth

A strong block can still go stale.
That is part of the design.

Schell should surface at least:

- last-known trust grade,
- whether the exact basis still matches,
- whether the receipt is historical only,
- and whether the related background/live-state truth must be reacquired.

This is where SlopOS exact mutable basis pressure and DelayBasin same-answer-is-not-same-state pressure meet very cleanly.

## Semantic inspector mode

A great prototype move is an optional inspector that reveals:

- the block grade,
- confidence,
- trust source,
- prompt/input/output boundaries,
- linked receipt or denial ids,
- linked output refs,
- and any basis-drift reason.

That makes the terminal teach its own honesty model.

## Transcript truth requirement

Every gated action must still leave behind honest text.
A plain transcript should still be able to show, in degraded form:

- that a block was guessed, marked, or shell-authenticated,
- what action was or was not allowed,
- and why a stronger action required re-review.

If the truth ladder only exists in one rich renderer, the design has failed.

## Current prototype reading

The early Schell goal should be:

1. **marked blocks for humane navigation,**
2. **shell-reported commands for exact display,**
3. **shell-authenticated action objects for strong actions,**
4. **clear downgrade paths when trust is insufficient,**
5. **basis-drift warnings when identity aged out,**
6. **and a semantic inspector to keep the whole thing honest.**

That is enough to make the custom shell+terminal feel dramatically better without pretending the final trust architecture is already settled.
