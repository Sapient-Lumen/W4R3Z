# Workspace cards, layout memory, and session humility

This surface exists to keep one very tempting shell+terminal move honest:
**Schell should be unusually good at letting users return to work — through workspaces, session cards, previewful choosers, startup recipes, and resurrection aids — but it should keep visible context, cached context, start recipes, and current live authority separately named, because “this context is easy to reach again” is not the same fact as “this context is live, current, and safe for strong action.”**

The point is not to avoid session management.
The point is to keep it smaller than authority.
A custom shell+terminal can feel super awesome here if it treats session/workspace comfort as a bounded object family rather than one flattering blur of tabs, panes, layouts, and restored residue.

## 1) Separate the context object family

At minimum Schell should keep these objects distinct:
- **workspace card** — a named local visibility wrapper for one cluster of panes/windows/tabs,
- **session card** — a live or detached runtime context with explicit liveness posture,
- **layout-memory card** — pane/tab arrangement without executable launch claims,
- **start recipe card** — cwd/commands/layout bundle intended to create fresh context,
- **resurrection card** — a cached historical context derived from prior live state,
- **restoration-depth badge** — layout-only / command-identity / viewport / scrollback / unknown,
- **chooser family chip** — workspace / session / layout / recipe / domain / history,
- **active-input truth** — the exact lane currently accepting strong keyboard input,
- **attach lane** — the path that rebinds to live context,
- **inspect lane** — the path that only previews/browses historical or detached context.

Those facts are adjacent.
They are not interchangeable.

## 2) Visible workspace state is local comfort, not durable shell truth

A visible workspace should answer questions like:
- which window cluster is on screen,
- which tabs/panes belong together for a task,
- and what the operator likely wants to see next.

It should **not** by itself answer:
- whether the underlying processes are still live,
- whether the current lane still owns strong input,
- whether restored outputs are current,
- or whether prior approval basis still matches the new moment.

A shell that gets this right can be very luxurious without overclaiming liveness.

## 3) Session cards need posture, not just names

A good session manager should be able to distinguish:
- **live-attached**,
- **live-detached**,
- **restored-awaiting-repair**,
- **cached-resurrectable**,
- **historical-only**,
- **unknown**,
- and **failed-reacquisition**.

That one badge family would prevent a huge amount of confusion.
A resurrectable card is useful even when it is not live.
A historical card is still valuable even when it cannot accept attach.
The mistake is flattening all of them into “session.”

## 4) Pure layout memory should stay separate from executable start recipes

There are at least two different user desires here:
1. “I want this pane/tab arrangement again.”
2. “I want this whole project context recreated.”

Those should not collapse into one object.
A **layout-memory card** may remember only structure.
A **start recipe card** may also remember cwd, commands, helper programs, inspector panes, monitors, or queue watchers.

This split matters because structure is usually safe to preview and reuse widely.
Executable start recipes carry more authority and should admit stronger provenance, trust, and review posture.

## 5) The best chooser is preview-first and family-labeled

Schell should absolutely steal previewful trees and fuzzy launchers.
But every candidate should still reveal:
- family,
- posture,
- restoration depth,
- source/provenance,
- and strongest currently allowed action.

That means one chooser can gracefully span:
- live sessions,
- workspaces,
- layouts,
- recipes,
- detached tasks,
- remote domains,
- and historical context cards,

without implying that every item can be attached to, resumed, or batch-managed the same way.

## 6) The shell still needs one separate active-input truth

No matter how elegant the workspace manager becomes, the shell still needs one exact answer to:
**where will strong keyboard input go right now?**

Visible selection is not enough.
Highlighted result is not enough.
Current workspace is not enough.
A shell+terminal that remembers this will avoid a lot of accidental cross-context action.

## 7) Restoration should reacquire, not impersonate

A restored/resurrected object can be fantastic for:
- browsing,
- comparing,
- copying,
- reopening a project recipe,
- or seeding a new reviewed run.

But a restored object should only become live after explicit reacquisition/repair.
Until then it stays historical, cached, or awaiting-repair.
That means Schell can be generous with restoration and still conservative about truth.

## 8) Batch action lanes need a stronger split than tree browsers usually give

Previewful tree browsers often tempt direct batch actions:
kill, close, retitle, apply command, tag-and-act.
Schell should keep a firmer lane split:
- **browse/preview**,
- **attach/switch**,
- **inspect metadata**,
- **derive fresh proposal**,
- **strong batch act**.

This is especially important once workspaces may hold mixed families like live sessions, detached queues, restored historical contexts, or remote domains.

## 9) A compact first proving slice

A strong first specimen set would show:
1. one workspace card with visible-only posture,
2. one live session card and one detached session card,
3. one layout-memory card that carries no launch authority,
4. one start-recipe card that clearly carries cwd/command launch power,
5. one resurrection card with layout-only depth,
6. one resurrection card with viewport/scrollback residue badges,
7. one chooser that spans workspace/session/layout/recipe families with source chips,
8. one preview-first switch that does not attach until confirmed,
9. one hold card when a restored card is asked to accept live strong action,
10. one explicit reacquire step that upgrades restored to live,
11. and one transcript witness for active-input truth separate from visible workspace.

That is already enough to make Schell feel much more polished than a classic terminal without freezing the final session manager, workspace sync model, or resurrection format.

## 10) Things to refuse for now

Refuse for now:
- one undifferentiated “session” object that mixes live, restored, cached, and historical states,
- layout files that silently become executable without stronger provenance,
- visible workspace focus masquerading as active-input truth,
- restored context masquerading as current live authority,
- one global inventory/resume API just because current tools make local lists pleasant,
- and one final omnipalette that hides family/type distinctions.

The right law is:
**steal workspace launchers, previewful trees, folder-plus-layout starters, and project session files — but keep visible context, cached context, executable recipes, and current live authority separately named.**
