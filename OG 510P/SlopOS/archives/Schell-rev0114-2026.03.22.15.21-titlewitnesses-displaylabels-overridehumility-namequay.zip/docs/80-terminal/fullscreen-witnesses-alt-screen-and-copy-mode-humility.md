# Fullscreen witnesses, alt-screen ownership, and copy-mode humility

**Schell should absolutely steal full-screen/TUI comfort — searchable scrollback, copy mode, quick-select, command-aware paging, capture decks, and durable reentry — but it must not let visible pixels, alt-screen live state, terminal overlays, or captured output flatten into one flattering “I can still see it, therefore I know exactly what it is” story.**

## 1) Why this seam matters

A super-awesome shell+terminal gets dramatically better the moment users can:
- search history while a long session is still open,
- enter a keyboard-first copy/select mode without touching the mouse,
- reopen the last command output in a pager,
- keep a command-aware capture deck for interesting lines,
- and move smoothly between ordinary shell prompts and full-screen tools like editors, pagers, selectors, dashboards, and monitors.

But this is also one of the oldest places where terminals lie by accident.
What is on screen right now is not always scrollback.
What is searchable is not always durable.
What is in a copy-mode overlay is not always the app's own state.
What got captured for convenience is not always the exact basis for a stronger action.

Schell should therefore keep at least these families separately named:
- **main scrollback**,
- **alt-screen live framebuffer**,
- **terminal-owned copy/search overlay**,
- **captured command-output excerpt**,
- **pager-derived reading surface**,
- **shell-attested command chapter/output**,
- and **durable exact result capsule**.

## 2) The historical lesson: alternate screen is a mode, not a promise

xterm's old alternate-screen behavior still teaches the right lesson: the alternate buffer is a different buffer, and ordinary saved-lines history does not simply follow it by default.
Modern terminals still prove the same thing in their own ways.
Some expose explicit policies for saving alt-screen lines to history.
Some translate wheel motion into app-facing keys while a full-screen program is active.
Some fix bugs where alt-screen state leaked into ordinary scrollback assumptions.

The design lesson is not “avoid full-screen apps.”
It is:
**never let alt-screen presence, exit residue, or post-hoc capture silently become the same truth object as ordinary shell scrollback or exact command output.**

So Schell should carry explicit fullscreen posture badges such as:
- `main-scrollback`,
- `alt-live`,
- `alt-captured`,
- `alt-not-captured`,
- `overlay-copy-mode`,
- `overlay-search`,
- `pager-derived`,
- `chapter-exact`,
- `result-capsule-exact`.

## 3) Copy mode is a second workflow, not invisible terminal magic

Modern terminals keep showing that copy mode is worth stealing.
WezTerm's copy mode and quick-select mode are separate features.
Ghostty keeps adding native scrollback search and command-palette-driven affordances.
kitty can send scrollback or command output into pagers or overlays.
These are all great ideas.

But a copy-mode or search overlay is still a terminal-owned workflow.
It is not automatically the foreground app's own selection state.
It is not proof that the foreground app agrees with the selection.
And it is not proof that the selection is a durable object rather than a view-local excerpt.

So Schell should treat copy/search overlays as explicit witnesses:
- **overlay owner** — terminal / shell / foreground app,
- **source family** — main scrollback / alt-live capture / exact chapter / imported transcript,
- **selection strength** — visible excerpt / command-local excerpt / shell-attested block / durable exact artifact,
- **strongest safe next action** — copy / reveal source / open exact output / export excerpt / refuse stronger reuse until promotion.

## 4) Captured output is a derived index, not the result itself

iTerm2's captured output and kitty's command-aware paging both show that command-local capture is a huge ergonomic win.
Schell should absolutely steal that.
The operator should be able to say “show me the command output around this hit” or “reopen the last output in a pager” or “jump between command-local matches.”

But the right import is not “captured output becomes the canonical result.”
The right import is:
- **capture rows** as derived navigation objects,
- **command-local reentry cards** as shell-aware convenience,
- and **promotion rails** when a stronger exact source exists.

That means a capture row might honestly say:
- `derived from scrollback`,
- `shell-attested command boundary present`,
- `exact output capsule available`,
- `alt-live residue only`,
- or `historical excerpt; not a rerun basis`.

## 5) Full-screen/TUI life deserves shell-authenticated promotion, not flattening

This is where Schell can become unusually good.
Instead of pretending a live full-screen tool is just “more terminal text,” it can offer promotion ladders:
- **observe live framebuffer**,
- **capture bounded excerpt**,
- **reveal owning command chapter**,
- **open exact command output capsule if one exists**,
- **export exact durable result if one exists**,
- or **stay terminal-local because no stronger source exists**.

That keeps luxury high while preserving honesty.
A full-screen fuzzy finder, log viewer, dashboard, or editor can still feel deeply integrated.
But the integration stays strongest when Schell knows whether the thing on screen is:
- app-private live state,
- terminal-derived capture,
- shell-attested output,
- or durable exported result.

## 6) What Schell should do now

### A. Add **fullscreen witnesses**
Each full-screen-related view should carry:
- `view_family`,
- `owner`,
- `source_strength`,
- `capture_policy`,
- `overlay_posture`,
- `promotion_options`,
- and `exit_posture`.

### B. Add **copy/search overlay cards**
Each overlay should confess:
- whether it is terminal-owned or app-owned,
- whether it ranges over main scrollback or alt-derived capture,
- whether the chosen lines are durable, historical, or merely visible,
- and which stronger source can be opened next.

### C. Add **full-screen promotion rails**
The best super-awesome move here is not more selection magic.
It is a better ladder from visible surface to stronger truth:
- `copy excerpt`,
- `jump to chapter`,
- `reopen exact output`,
- `export exact result`,
- `stay view-local`.

### D. Keep **copy mode, quick select, and app selection separately named**
Even when the UX feels seamless, Schell should never blur:
- foreground-app selection,
- terminal overlay selection,
- shell-authenticated output block selection,
- and exact durable artifact selection.

### E. Keep **full-screen actions weaker than reviewed action**
Scrolling, searching, selecting, and paging are still observation lanes.
They should only become stronger routes through explicit promotion or explicit review.

## 7) Super-awesome ideas worth stealing now

- command-aware “open this output in pager” rails,
- command-local search decks,
- overlay copy mode with source confession,
- searchable scrollback with source-family badges,
- shell-authenticated chapter reentry from full-screen history,
- exact-output promotion from captured lines,
- and alt-screen posture badges that say whether capture happened at all.

The especially good Schell twist would be:
**treat visible full-screen state as luxurious observation, then make exact chapter/output/result promotion feel effortless when stronger truth exists.**

## 8) Decisions intentionally kept open

This pass does **not** freeze:
- one final pager implementation,
- one final copy-mode UX,
- one final scrollback storage model,
- one final alt-screen capture policy,
- one final TUI integration protocol,
- or one final terminal-side search/index backend.

The no-regret move is smaller:
**make full-screen/TUI life first-class and delightful, but keep live framebuffer state, terminal overlays, captured excerpts, shell-attested output, and durable exact results separately named.**
