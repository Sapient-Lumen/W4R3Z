# Prompt witnesses, segment provenance, and async humility

This surface keeps one especially tempting shell myth honest:
**Schell should absolutely steal brilliant prompts — right prompts, transient prompts, mode chips, async status, cloud/repo context, and instant-feeling startup — but it should do so by keeping prompt segments, startup footing, redraw class, and freshness/cost posture separately named.**

That is the smaller discipline that lets a shell+terminal feel dramatically better than bash without letting prompt-time code become a hidden second shell.

## 1) Why this surface exists

The archive already has:
- config-ground cards,
- prompt budgets and idle lanes,
- active-input leases,
- input-authorship witnesses,
- integration witnesses,
- repo accelerator leases,
- and keymap/editor witnesses.

But one seam was still undernamed:
**what exactly authored the current prompt fact, and what class of redraw or helper work made it visible?**

That matters because current prompts increasingly mix:
- shell-native prompt functions,
- right prompts,
- mode indicators,
- transient post-exec redraws,
- async segment repair,
- startup profile code,
- repo/cwd hook code,
- custom prompt engines,
- and shell-out derived status.

Without an explicit witness split, “the prompt says X” becomes a flattering but mushy story.

## 2) Keep these truths distinct

At minimum Schell should treat these as different objects:

1. **startup footing** — builtin shell segment / reviewed local config / imported theme pack / repo-offered pack / terminal bridge / degraded fallback
2. **redraw class** — live prompt / right prompt / mode chip / transient prompt / final historical repaint / async refresh / unknown
3. **segment provenance** — shell-known / cached / shell-out derived / imported / bridged / repo-triggered / unknown
4. **freshness posture** — current / stale / refreshing / historical / restored / unknown
5. **cost lane** — instant / cheap local / explicit local / async repair / unknown
6. **interaction posture** — display-only / copyable / opens review / opens help / route-offer / unknown

These truths are adjacent.
They are not interchangeable.

## 3) A prompt witness should name source, redraw class, and shell-out posture

A prompt witness should probably be able to say at least:
- `segment_kind` — left / right / mode / transient / final / inline-status / unknown
- `startup_footing` — builtin / reviewed-local / imported-pack / repo-pack / bridge / degraded / unknown
- `source_family` — shell-known / cached / shellout / hook / repo-context / imported / terminal-bridge / unknown
- `freshness_posture` — current / stale / refreshing / historical / restored / unknown
- `cost_lane` — instant / cheap-local / explicit-local / async-repair / blocked / unknown
- `trigger_kind` — prompt-show / cwd-change / mode-change / post-exec / timer / explicit-refresh / unknown
- `display_safety` — escaped / shell-specific / unescaped-risk / unknown
- `interaction_posture` — display-only / hint / review-offer / route-offer / unknown
- `trust_posture` — shell-owned / helper-derived / imported / bridged / fallback / unknown

This does not require one final theme engine.
It only requires Schell to stop pretending every prompt fact has the same truth story.

## 4) Left, right, mode, and transient prompts are worth stealing — but they should stay descriptive

Modern prompt systems keep proving that prompt variety is good.
Schell should support luxuries such as:
- a left prompt for primary orientation,
- a right prompt for low-commitment context,
- a mode chip for editor state,
- and a transient prompt for post-exec condensation.

But those should remain descriptive.
A right prompt is not execution approval.
A transient prompt is not the same object as the live editable prompt.
A mode chip is not command meaning.
A final historical repaint is not proof that the original live prompt was shell-authenticated.

## 5) Instant-feeling startup is excellent only when cheap truth renders first

Instant prompt is a real quality multiplier.
Schell should steal the feeling.
But it should do so under a stricter rule:
**the first prompt may render only shell-known or already-held cheap facts, and any later enriched segment must arrive as a visibly repaired upgrade rather than silently rewriting the truth story.**

That means:
- no hidden dependency on prompt-path shell-outs,
- no hidden dependency on repo hooks merely to feel live,
- and no startup helper recursion disguised as prompt polish.

## 6) Async segments should be allowed to refresh, not to overclaim

Async prompt repair can be wonderful.
Git state, cluster context, background task count, and repo metadata are all fair game for later refresh.

But a repaired segment should keep its posture visible:
- stale,
- refreshing,
- refreshed from cache,
- or newly reacquired.

Do not let an old segment silently turn into current truth with no visible provenance shift.

## 7) Per-directory context is a stronger seam than “show a badge”

Schell should be very careful here.
Per-directory context loaders and repo-aware prompt enrichers are delightful.
They are also one of the oldest ways shell environments become ambiently programmable.

So Schell should keep at least these postures separate:
- repo context available,
- repo context leased,
- repo context changed since lease,
- repo context proposal-only,
- repo context blocked,
- and no repo context.

Prompt redraw alone should never count as fresh approval of repo-local startup or env changes.

## 8) Prompt output needs explicit display-safety posture

Prompt engines increasingly run commands and print the output.
That makes escaping rules and shell-specific rendering relevant.
So Schell should make it cheap to answer:
- was this segment shell-escaped,
- shell-specific,
- generic safe text,
- or potentially unsafe/unescaped?

This is a subtle but very important honesty rule.
Pretty prompt text should not quietly become a code or control-sequence channel.

## 9) “Why is this in my prompt?” should be a first-class answer

One of the easiest brilliance steals in the current ecosystem is prompt explainability.
Schell should be able to answer, in-context:
- what segment is shown,
- what source produced it,
- what redraw path triggered it,
- whether it is cached or fresh,
- whether it needed shell-out or async repair,
- what startup/profile/repo footing made it possible,
- and which stronger nearby action would still require explicit review.

A compact `ExplainPrompt` answer would already make Schell feel unusually humane.

## 10) Segments that imply authority should look stronger than decorative status

Some prompt facts are just orientation.
Others are dangerously close to authority context.
These include:
- cloud account/profile,
- kubernetes context/namespace,
- remote peer or jump posture,
- repo trust lease state,
- environment activation state,
- and borrowed credentials.

Schell should keep these visually stronger than decoration and attach source/freshness posture to them.
A stale cloud profile badge is worse than no badge.

## 11) First specimen set this surface wants

A good first proof set would show:
1. one `ExplainPrompt` answer for a left segment,
2. one right prompt segment with visible freshness posture,
3. one mode chip with shell-owned/editor-owned posture,
4. one transient prompt repaint that is visibly distinct from the live prompt,
5. one instant-first render with later async repair badge,
6. one repo-context segment that stays proposal-only until explicitly leased,
7. one segment with escaped versus shell-specific display-safety posture,
8. one compare view between stale and refreshed segment provenance,
9. one refusal to let prompt redraw mutate execution ground silently,
10. and one refusal to let imported/repo prompt packs quietly become startup truth.

## 12) What to refuse for now

Refuse for now:
- one undifferentiated “prompt customization” story,
- prompt-path shell-outs that are required for baseline usability,
- repo-local prompt/context loaders that silently activate on directory entry,
- transient or final redraws posing as the same truth object as the live prompt,
- unescaped helper output masquerading as harmless status text,
- and prompt segments that imply cloud/cluster/credential truth without source and freshness posture.

## 13) Bounded conclusion

One of the safest ways to make Schell feel dramatically better than legacy shells is also one of the clearest:

**treat prompt facts as witnessed status, not as ambient authority.**
The prompt can be gorgeous.
The right side can be useful.
The transient repaint can be elegant.
Async segments can be delightful.
But the reviewed action still comes later.

That is enough to steal a lot of brilliance without freezing the architecture too early.
