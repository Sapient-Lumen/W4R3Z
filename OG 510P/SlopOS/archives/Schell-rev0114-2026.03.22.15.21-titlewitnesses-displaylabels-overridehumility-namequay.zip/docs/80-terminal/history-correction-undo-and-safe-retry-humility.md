# History, correction, undo, and safe-retry humility

This surface exists to keep one very old shell temptation honest:
**Schell should be dramatically better than classic shells at recalling previous commands, repairing likely mistakes, and safely retrying work — but it should do that by separating history grounds, correction proposals, undoable edits, restored residue, and exact approved action, because “this is what I ran before” is not the same fact as “this is the exact action I freshly reviewed and now mean to run.”**

The point is not to avoid memory.
The point is to make memory reviewable.
A custom shell+terminal can be super awesome here if it treats history and correction as explicit object families rather than one flattering auto-rerun stream.

## 1) Keep history smaller than approval truth

At minimum Schell should separate:
- **history ground** — where a recalled command came from,
- **recall scope** — which universe of prior work is being searched,
- **correction proposal** — a suggested replacement or augmentation of current input,
- **edit state** — the local, undoable command buffer before approval,
- **retry rail** — whether a recalled command is being inserted, staged, or rerun,
- **restored residue** — commands surfaced because a session/view was restored,
- **recent hint** — a non-authoritative “used/opened recently” memory,
- **review basis** — the exact command/action bytes actually approved now.

Those objects are adjacent.
They are not interchangeable.

## 2) A history ground should name source family, scope, and claim strength

A healthy history ground should probably carry compact truth such as:
- `source_family` — local-session / local-history / project-history / imported-history / restored-session / workflow-seed / correction-engine / unknown,
- `scope` — current session / current directory / current project / local host / all hosts / imported pack / unknown,
- `claim_strength` — exact-local-history / contextual-history / correction-only / restored-historical / inferred / unknown,
- `freshness_posture` — current-session / recent-local / historical / restored / imported / unknown,
- `execution_posture` — insert-only / stage-for-review / suggestion-only / prompt-required / exact-reviewed / unknown,
- `basis_drift_posture` — unchanged / cwd-drift / tool-drift / target-drift / authority-drift / unknown.

That already gives Schell a much more honest retry story without freezing one final history backend, sync substrate, or correction engine.

## 3) Recalled commands should usually return to the edit buffer first

One of the strongest old shell lessons is still the right default.
Recalled or expanded history should usually reappear in the active input buffer where the user can inspect, edit, diff, and undo.
That is a much healthier default than executing immediately.

Schell should therefore strongly prefer:
1. recall into buffer,
2. show exact diff from current input when relevant,
3. show scope/source chips,
4. show basis-drift hints,
5. require fresh approval before execution.

Immediate rerun can still exist.
It should simply be a stronger rail with a stronger badge.

## 4) Correction should begin as proposal, not as substitution

Spelling correction, “did you mean?”, missing-flag help, missing-subcommand help, and failed-command repair are all worth stealing.
But they should start life as proposal objects.

A correction proposal should say:
- what text changed,
- why the engine thinks it is relevant,
- whether it came from syntax, history, examples, a pack, a bridge, or a rule engine,
- whether it would widen authority, install something, or rerun a prior side effect,
- and whether the current footing has drifted since the original failure.

That keeps correction friendly without laundering guessed intent into shell truth.

## 5) Undo anchors should be first-class

A luxury shell should make command composition feel safe because edits stay local and reversible.
Schell should therefore treat grouped transformations as explicit undo anchors:
- recall a history entry,
- expand a snippet,
- accept the next suggestion word,
- apply a correction diff,
- swap one tool origin for another,
- or inject a retry template.

Each should be its own grouped local edit action, not a pile of tiny opaque mutations.
That is one of the easiest ways to make the shell feel unusually good without widening authority at all.

## 6) Retry should have lanes, not one button

Safe retry gets much better when it is split into named rails:
1. **insert** — put the old command in the buffer,
2. **stage** — create an exact retry card with drift checks and diff,
3. **replay-input** — reuse text only, not surrounding authority or targets,
4. **rerun-now** — a stronger fresh approval path,
5. **derive-new-proposal** — build a modern proposal from historical evidence when the footing changed too much.

This keeps “run it again” from smuggling together text reuse, target reuse, env reuse, cwd reuse, capability reuse, and approval reuse.

## 7) Recents and restored state should stay historically badged

Recents are helpful.
Restored command cards are helpful.
Neither should overclaim.

Schell should therefore mark such things explicitly as:
- recent hint,
- restored from prior session,
- historical command,
- imported/shared history,
- or fresh current-session input.

That one honesty ladder already prevents a lot of accidental authority laundering.

## 8) History should behave more like a wallet than a monolith

A modern shell should support:
- session-only history,
- project-local history,
- private or non-persistent sessions,
- redacted or filtered history,
- explicit delete classes,
- and imported/shared history that stays visibly imported.

That makes memory much more humane and much less likely to impersonate one universal source of truth.

## 9) “Why this correction?” should be answerable inline

For any correction or retry proposal, Schell should be able to say:
- typo distance,
- matched prior command,
- matched current cwd/project,
- matched tool signature,
- matched exit/failure pattern,
- came from imported history,
- came from restored state,
- or unknown.

That one reveal turns a magical fix into a reviewable suggestion.

## 10) A compact first proving slice

A strong first specimen set would show:
1. one recalled history command returning to the buffer instead of auto-running,
2. one correction card with exact old→new diff,
3. one scope chip set for host / directory / session,
4. one basis-drift badge when cwd/tool/authority changed,
5. one grouped undo anchor around an applied correction,
6. one insert-vs-stage-vs-rerun retry ladder,
7. one restored historical command card that stays weaker than live approval,
8. one history-wallet switch for private/session-only mode,
9. one imported-history card that stays visibly imported,
10. one refusal to let a recalled or corrected command pose as exact current approval basis,
11. and one failure-help card that proposes edits before any stronger rerun.

That is already enough to make Schell feel unusually capable without freezing the final history store, sync layer, correction engine, retry receipts, or imported-memory model.

## 11) Things to refuse for now

Refuse for now:
- one undifferentiated “run it again” button,
- recalled commands auto-executing by default,
- correction engines silently widening authority or installing helpers,
- restored/recent state posing as current basis truth,
- imported/shared history posing as local exact memory,
- and history pretending to preserve approval after footing drift.

The right law is:
**steal history luxury, edit comfort, undo quality, and correction speed — but keep historical memory, restored residue, correction proposals, and exact approved action separately named.**
