# Scheduled-work witnesses, window offers, and replay-debt humility

This surface names a shell+terminal seam that becomes much more important once the system grows richer than plain `&` folklore:
**reviewing something now and asking the system to run it later is valuable, but exact alarms, best-effort windows, catch-up runs, durable background presence, and hidden self-resubmitting daemons are not the same story and should stop borrowing each other's language.**

SlopOS already points in a better direction.
Deferred work is portalized.
Windows are best-effort.
Missed periodic work is not replay debt.
Continuous presence is a separate authority seam.
Schell can import that discipline without freezing one scheduler backend, one job portal UI, or one calendar syntax too early.

## 1) “Run later” should become a named shell truth

Traditional shells are oddly weak here.
They are good at run now, background now, and maybe detach now.
They are much worse at saying:
- rerun this reviewed thing later,
- make it replaceable by key,
- delay until useful conditions hold,
- explain what happens if the window is missed,
- or show whether the future run is historical intent or still live scheduler truth.

So users fall back to ambient cron, ad-hoc wrapper scripts, hidden service-manager units, or one-off automation folklore.
A custom shell+terminal can do better by making **scheduled work witnesses** first-class.

## 2) SlopOS already teaches the crucial split

The strongest SlopOS lesson is small and clear:
- **D-JOBS** is for deferred work,
- **D-BGLEASE** is for continuous background presence or autostart posture,
- and **D-CAPSHELL** explicitly refuses to smuggle deferred/background semantics back in through ordinary shell launch or job-control lore.

That means Schell should stop flattening nearby user intents like:
- run this reviewed chapter after a maintenance window,
- retry this sync when unmetered network returns,
- keep this thing running forever,
- catch up missed work after resume,
- and relaunch this at every login.

Those are related.
They are not identical.
A terminal that shows them as one generic “scheduled” glow will become dishonest very quickly.

## 3) One compact scheduled-work witness family is enough to start

Schell does not need a full calendar DSL or a universal service-manager adapter first.
A small witness family could already carry most of the truth users need.

A v0 packet could keep:
- `request_key` — a stable reviewed identity for replace/compare/cancel posture,
- `target_posture` — rerun-reviewed-chapter / activate-workflow-seed / promoted-service / unknown,
- `schedule_kind` — one-shot-window / periodic-window / expedited / historical,
- `earliest_not_before` — the first eligible time,
- `window_posture` — open-ended / advisory-latest / maintenance-window / unknown,
- `constraint_posture` — charging / unmetered / idle / storage-ok / local-only / none,
- `catchup_posture` — skip-missed / one-catchup / catchup-enabled / unknown,
- `runtime_posture` — bounded / unbounded / unknown,
- `state_freshness` — reviewed-intent / admitted / currently-pending / historical / replaced / cancelled / unknown.

That is enough to power rich shell+terminal UX without freezing one final scheduler, one final calendar parser, or one final persistence substrate.

## 4) The best steals here are humane, not grandiose

### a) Review-now / run-later cards
A reviewed command chapter or workflow seed should be promotable into a **run-later card** rather than forcing the operator to leave the shell and rewrite the action in some other scheduler UI.

### b) Constraint chips instead of timer mysticism
The card should make it easy to ask for:
- when charging,
- when unmetered network returns,
- when the machine is idle enough,
- when the next maintenance window opens,
- or “soon, but not now.”

Those are often more honest and more useful than pretending exact minute-level wakeup is the real need.

### c) Replace-by-key posture
Steal the idea that deferred work can be **named and replaceable**.
A reviewed background sync or index refresh should usually replace the earlier equivalent request rather than quietly piling up duplicate future work.

### d) Missed-window honesty
If the machine slept through the window, the shell+terminal should show which policy applied:
- skipped,
- one catch-up run,
- or catch-up still pending.

This should be transcript-visible and card-visible.
It should not be folklore hidden in some scheduler backend.

### e) One explicit “promote to durable background” rail
A scheduled run later is not automatically durable presence.
If the operator actually wants “keep doing this forever” or “come back at login forever,” that should move through a stronger, separately named background/autostart rail.

## 5) The old mistakes to avoid

### a) Ambient cron by another name
A rich terminal can accidentally reinvent cron while pretending it did something friendlier.
The danger is not the syntax.
The danger is ambient durable wakeups and hidden persistence.

### b) Replay debt as a surprise
If a periodic task missed ten windows during sleep or power-off, silently replaying ten runs later is often the wrong story.
It can amplify load, confuse operators, and turn harmless maintenance into a storm.

### c) Self-resubmitting “little jobs” that are really daemons
A shell+terminal should not encourage people to smuggle durable presence through tiny repeated jobs just because the UI makes it easy.
That is background authority in disguise.

### d) Request identity pretending to be live scheduler state
A reviewed future-run card or old receipt is useful evidence.
It is not proof that a current scheduled job still exists unless the current scheduler state is reacquired.

## 6) A better shell story appears if we keep the seam honest

The shell can stay wonderful at reviewed action.
The terminal can stay wonderful at seeing, editing, comparing, and rescheduling future work.
But “run later” should feel different from:
- “background this now,”
- “keep this daemon-like thing alive,”
- “repeat forever,”
- “wake exactly at this second,”
- and “replay everything we missed.”

That difference is exactly where a custom shell+terminal can feel super awesome without becoming sloppy.

## 7) The no-regret move

The best move right now is small:
**give Schell one scheduled-work witness family, one review-now/run-later card shape, one explicit missed-window policy surface, and one refusal to let deferred work quietly collapse into cron folklore, durable daemon posture, or replay debt.**

That keeps open:
- one final scheduler backend,
- one final calendar or recurrence syntax,
- one final persistence store,
- one final notification/reminder integration,
- and one final background/autostart policy model.
