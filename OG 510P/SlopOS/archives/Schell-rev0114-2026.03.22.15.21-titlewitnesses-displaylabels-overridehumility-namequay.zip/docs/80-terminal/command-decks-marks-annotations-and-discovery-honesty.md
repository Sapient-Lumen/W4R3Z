# Command decks, marks, annotations, and discovery honesty

This surface records another low-regret move for Schell:
**make it dramatically easier to find, pin, and stage exact prior work while refusing to let palette hits, marks, notes, or previews impersonate current authority.**

The point is not to build an omniscient command palette first.
The point is to give the shell+terminal a much better answer to:
- “where was that exact command or failure I care about,”
- “pin this for the next half hour,”
- “leave me a note on this chapter,”
- and “show me enough to choose without smuggling preview, reopen, or run authority.”

## Core idea

Schell should probably distinguish at least five nearby things:

- **chapter** — one exact shell-known command unit with outcome and refs,
- **mark** — a lightweight jump anchor bound to an exact chapter or exact range,
- **annotation** — a local note bound to an exact object or range,
- **deck card** — a compact pinned working-set object for quick return,
- **palette result** — a temporary discovery row used to inspect, stage, or route.

Those are related.
They are not the same object.

## 1) A command deck should be a lightweight working set, not a new authority plane

A command deck is not a new workflow engine.
It is a compact operator working set.

A compact v0 deck card could preserve:
- `deck_card_id`,
- `ref_kind` — chapter / seed / launch-kit / note / review-card / receipt,
- `exact_ref`,
- `title`,
- `kind_badges[]`,
- `liveness_badge`,
- `peer_partition`,
- `sensitivity_posture`,
- `suggested_actions[]`,
- `pin_posture` — runtime / local-durable / exportable-never,
- `note_ref?`,
- `last_basis_hint?`.

Important posture:
- a deck card is **navigation and staging help**,
- not proof of current liveness,
- not permission to re-run,
- and not a durable reopen grant by itself.

## 2) Marks should bind to exact things

Classic terminal marks are worth stealing.
But Schell should make them more exact.

A mark should attach to:
- one exact chapter,
- one exact output range,
- one exact review or denial card,
- or one exact restored historical object.

Useful mark families could include:
- **return marks** — “bring me back here,”
- **failure marks** — exact failure boundaries,
- **review marks** — review/receipt/denial boundaries,
- **operator marks** — explicit named bookmarks,
- **generated marks** — shell- or terminal-produced but clearly badged.

The main rule is simple:
**a mark is a jump anchor, not a live-handle proof.**

## 3) Annotations should be local notes, not transcript laundering

Annotations are another great old idea.
They let the operator leave breadcrumbs without editing shell truth.

A Schell annotation should probably:
- bind to an exact chapter or exact range,
- preserve author and timestamp,
- stay visibly separate from shell output,
- be local by default,
- and remain weaker than reviewed receipts or workflow seeds.

That keeps notes useful without turning them into fake shell truth.

## 4) Palette results should say what they are before they let you act

A good discovery palette should be able to search across:
- chapters,
- marks,
- annotations,
- workflow seeds,
- launch kits,
- receipts,
- recent directories,
- and maybe active sessions.

But each result should probably carry at least:
- object kind,
- liveness/restored status,
- source lane,
- peer partition,
- sensitivity posture,
- and allowed action family.

The best result row is not the prettiest one.
It is the one that keeps the operator from confusing:
- exact chapter,
- saved recipe,
- current live session,
- historical note,
- or sensitive object preview.

## 5) Default palette actions should stage or inspect, not run

One of the nicest modern command-search ideas is landing a result back into editable input instead of firing it immediately.
Schell should steal that instinct aggressively.

A good v0 action ladder might be:
- **inspect**,
- **jump**,
- **insert into active input**,
- **open review card**,
- **attach exact chapter for help**,
- **request stronger action**.

Direct strong action should stay rare and heavily badged.

## 6) Palette lifecycle matters: keep open, hide, or dismiss

A palette should not always behave the same after an action.
That sounds small.
It is actually a powerful ergonomics seam.

Schell should probably preserve at least three outcomes:
- **keep open** — good for multi-step staging work,
- **hide and return** — good when the operator wants to briefly inspect something and come back,
- **dismiss** — good for one-shot actions.

This keeps the palette from feeling like one giant ambiguous mode.

## 7) Preview should be metadata-safe by default

Discovery surfaces are where hidden authority and hidden leakage creep back in.
So Schell should likely keep result rows and hover panes conservative by default.

A good default posture is:
- labels, kind badges, status, peer, recency, and exact-ref cues are fine,
- content snippets, rich previews, thumbnails, and derived summaries are not ambiently assumed safe,
- and stronger preview should route through an explicit inspect/open step on the exact object.

That rule matters most for:
- sensitive local objects,
- remote objects with weak current witness,
- quarantined imports,
- and historical results whose exact basis is no longer current.

## 8) Recents are useful, but they are not reopen grants

A custom shell+terminal should absolutely keep smart local recents.
That is one of the easiest ways to feel great.

But “recent” should stay:
- shell-owned,
- clearable,
- non-authoritative,
- and weaker than an explicit exact object handle.

A recent deck card or palette hit is a hint.
It is not standing permission.

## 9) Things Schell should steal now

### Exact marks and jump anchors

Old-school mark navigation is still wonderful.

### Local annotations on exact chapters

This makes troubleshooting, handoff, and project resumption much more humane.

### One deck strip or shelf for pinned working-set objects

A tiny pinned working-set surface is more useful than a giant history browser.

### One discovery palette with strong badges

Unified discovery is worth it if result truth stays visible.

### Palette outcomes with keep-open / hide / dismiss

This is a small design seam with real ergonomic upside.

### Metadata-safe result rows

That one rule prevents a lot of accidental preview and fake certainty.

## 10) Things Schell should refuse

### Refuse palette-hit-equals-run

Finding something should not count as approving it.

### Refuse note-equals-truth

Annotations are local notes, not shell-authored facts.

### Refuse mark-equals-liveness

A jump anchor is not proof the thing is still live.

### Refuse rich preview by ambient hover

Especially for sensitive or quarantined objects, hover should not become secret preview.

### Refuse one giant omniscient deck system first

One deck card type, one mark family, one annotation family, one palette row model, and one preview rule are enough to learn a lot.

## 11) No-regret first specimen set

A compact first cut could show:
1. one exact chapter promoted into a pinned deck card,
2. one named mark on a failure or review boundary,
3. one local annotation attached to an exact chapter/range,
4. one palette result row with kind/liveness/source/sensitivity badges,
5. one palette action that lands a command or seed into active input while keeping the palette open,
6. one metadata-safe preview refusal for a sensitive or quarantined result,
7. and one transcript slice showing inspect vs insert vs strong-action downgrade behavior.

That is enough to make Schell feel substantially more awesome at discovery and staging without freezing a search index, preview engine, cross-device sync model, or giant workspace deck product.
