# Font witnesses, glyph fallback, and ligature humility

This surface names another place where a custom shell+terminal can become much more humane **without** freezing too much too early:
**rendered glyphs, icon packs, fallback fonts, and ligature settings can be delightful, but they should stay weaker than exact bytes, exact grapheme identity, and reviewed shell meaning.**

Modern terminals keep getting better at text rendering.
That is wonderful.
It is also one of the easiest places for nearby display convenience to impersonate truth.
A prompt can look aligned because a patched font happens to work on one machine.
A symbol can appear because a bundled icon fallback rescued a missing glyph.
A glyph can look like one “character” because shaping or ligatures changed the visible form.
None of those facts should silently become shell authority.

## 1) Text truth and glyph truth are nearby, not identical

The shell ultimately cares about exact inserted text, exact reviewed bytes/argv, and exact handles or identifiers.
The terminal renderer cares about:
- which font face answered the codepoint,
- whether fallback was used,
- whether a symbol font or icon font supplied the glyph,
- whether ligatures or stylistic sets changed the visible form,
- whether synthetic bold/italic was applied,
- and whether clipboard/export substituted friendlier characters.

That means one visible line can carry at least three different stories:
- the exact text story,
- the shaping/grapheme story,
- and the font/glyph story.

Schell should keep them separately named.

## 2) Patched-font convenience is real, but it is not a clean truth basis

The current terminal ecosystem is unusually instructive here.
Some terminals now bundle symbol fonts or let operators map codepoint ranges to a specific symbol font.
That is a huge quality-of-life improvement because it avoids forcing one patched prompt font on every setup.

But it also reveals the right safety lesson:
**a prompt icon appearing on screen may say more about local font fallback than about portable shell meaning.**

So the shell+terminal should stop asking glyph luck to carry shell truth.
Prompt packs, icon badges, and fancy separators should stay visibly presentational.

## 3) Ligatures are lovely, but they should remain render-local

Programming ligatures, contextual substitutions, stylistic sets, and variable-font axes can make terminal text more readable or more beautiful.
They can also make the visible line diverge from the exact inserted bytes.

That does not mean Schell should avoid them.
It means Schell should:
- let operators choose them,
- reveal when they are active,
- and keep exact-byte or exact-grapheme reveal one gesture away.

The safest posture is simple:
**ligature state should be a renderer setting, not an execution meaning.**

## 4) Fallback fonts and codepoint maps deserve explicit witness posture

A compact **font witness** family could begin with:
- `text_subject_ref` — the exact text/field/chapter being rendered,
- `font_stack_ref` — the primary family plus any preferred fallback stack,
- `glyph_source_posture` — primary / preferred-fallback / bundled-symbol-fallback / system-fallback / patched-font / unknown,
- `shaping_posture` — plain / shaped / ligatured / script-joined / unknown,
- `style_posture` — native-style / synthetic-style / variable-axis / unknown,
- `icon_posture` — none / prompt-theme-icons / bundled-symbols / patched-icons / unknown,
- `copy_posture` — exact-text / normalized-copy / codepoint-mapped-copy / unknown,
- `portability_posture` — stable-text / glyph-sensitive / font-pack-dependent / host-local-only.

That is already enough to answer questions that ordinary terminals leave fuzzy:
- why does this prompt align here but not there?
- why did that icon disappear remotely?
- why does copy/paste produce different characters than the screen seemed to show?
- why did a symbol suddenly widen after a font change?

## 5) The nicest steals are specific and low-commitment

### a) Glyph-footing chips
A prompt/theme pack can say:
- text-safe,
- needs powerline symbols,
- needs Nerd Font/private-use icons,
- uses shaped script features,
- or depends on local-only font packs.

### b) “Explain this glyph”
A great terminal move is a tiny inspector that answers:
- exact codepoints,
- grapheme cluster,
- current font source,
- fallback reason,
- width posture,
- and copy/export behavior.

### c) Prompt-theme dependency cards
Prompt themes should declare whether they depend on:
- patched fonts,
- bundled symbol fallbacks,
- specific variable-font features,
- or text-safe ASCII-only rendering.

### d) One exact-text reveal rail
Whenever the renderer is doing something fancy, Schell should make exact text easy to reveal and easy to copy.

### e) Font-health doctor cards
When alignment or missing-glyph problems happen, the terminal should be able to confess:
- missing glyph in primary font,
- fallback metric mismatch,
- patched-font dependence,
- synthetic style in use,
- or remote host/local renderer mismatch.

## 6) The SlopOS-friendly answer is smaller than a font architecture

This seam does **not** require Schell to choose:
- one bundled font family,
- one icon story,
- one prompt-theme format,
- one ligature default,
- or one cross-platform shaping backend.

It only requires one durable rule:
**rendered glyph choice, ligature state, icon fallback, and synthetic styling should stay explicit render posture rather than quietly becoming shell meaning or durable object identity.**

## 7) Compact conclusion

One of the smartest design-phase-safe moves available right now is:
**give Schell a font/glyph witness family so prompt icons, shaped scripts, ligatures, fallback fonts, and copy/export substitutions can feel first-class without letting display luck outrank exact text truth.**

That would make the shell+terminal noticeably more luxurious while still keeping the final font stack, shaping backend, bundled symbol policy, and theme ecosystem open.
