# History lessons, stealable bundles, and luxury vetoes

This surface exists because Schell is in danger of two equal and opposite mistakes:
- becoming timid and missing the best ideas in modern shell+terminal work, or
- becoming enchanted by terminal cleverness and quietly repeating the worst old failures.

The right move is neither.
It is to carry an explicit split between:
- **failure families we must remember**,
- **luxury bundles worth stealing**,
- and **vetoes that keep the luxury from silently choosing the architecture.**

## 1) Failure family: hidden reparsing

Past shells keep teaching the same expensive lesson:
string-shaped convenience grows into a second execution language.
That can happen through:
- string eval,
- command-text recall that re-enters a parser,
- hidden `sh -c` style fallback,
- shebang/env discovery magic,
- or launch wrappers that reopen by mutable name.

### Schell import
- keep exact argv / external-boundary reveal close at hand,
- keep explain-before-run proposal-only,
- refuse hidden interpreter/name fallback,
- and treat shell text, launch object, and eventual receipt as separately named things.

## 2) Failure family: privilege-boundary startup and environment surprises

Shellshock is the memorable mascot, but the deeper lesson is bigger than one bug:
startup files, inherited environment, helper injection, and launch-time hooks are part of the authority boundary.
They are not harmless atmosphere.

### Schell import
- startup footing badges,
- config-ground cards,
- explicit environment capsules,
- and visible shell-integration injection provenance.

## 3) Failure family: spoofable metadata

Prompt marks, command blocks, cwd updates, and exit-code decorations are wonderful.
They are also only as trustworthy as their provenance.
Any sequence the PTY can display is not automatically shell truth.

### Schell import
- trust grades like guessed / marked / shell-authenticated / trusted-chrome,
- stronger actions keyed to minimum trust grade,
- provenance badges on shell-emitted metadata,
- and explicit secure-review lanes for stronger approvals.

## 4) Failure family: click-to-do-whatever

Terminals and editors keep drifting toward “smart clicks.”
That is often good.
It becomes bad the moment:
- hover implies open,
- click implies execute,
- link implies browser launch,
- or visible text implies exact object identity.

### Schell import
- typed object cards,
- intent packets with route witnesses,
- distinct rails for inspect / reveal / insert / open / safe-open / execute,
- default ask or inspect for riskier routes,
- and metadata-safe previews that confess when they are only previews.

## 5) Failure family: ambient input injection

The active input field is not just another line in scrollback.
Multiline paste, PTY injection, clipboard drops, and historical text promotion all prove that input-path hygiene is a real control-plane concern.

### Schell import
- ingress packets,
- bracketed-paste-aware multiline posture,
- PTY/process-group witnesses,
- and explicit promote-to-input rails from historical or external text.

## 6) Failure family: history and workflow objects that quietly become authority

Current tools now offer richer history, blocks, captured output, workflow saves, and recent-command recall.
Those are excellent.
They become dangerous when old text or saved commands quietly outrank fresh review on current basis.

### Schell import
- command chapters rather than flat history only,
- searchable parameterized workflow seeds,
- run / review / insert / compare as separate actions,
- stale-basis confession,
- authorship badges,
- and compare-after-run receipts.

## 7) Luxury bundle worth stealing now: shell-authenticated command chapters

Steal the best part of current shell integration:
- prompt boundaries,
- exact command line when available,
- cwd grounding,
- exit/outcome markers,
- and command-output grouping.

But make the chapter itself a named Schell object.
Do not let escape sequences be the deepest truth surface.

## 8) Luxury bundle worth stealing now: captured-output decks tied to chapters

iTerm2's captured output and kitty's command-output paging prove that warnings, errors, and interesting rows should not be dead scrollback.
The right import is:
- chapter-linked captured-output decks,
- row actions that stay weaker than exact object routes,
- and one visible ladder from regex hit to exact reveal or review.

## 9) Luxury bundle worth stealing now: semantic-history-aware exact reveal

A modern terminal should know more than “the line had text that looked like a path.”
It should be able to carry cwd, host, lane, and chapter context so reveal/open actions become better grounded.

The route should still confess what kind of grounding it has:
- raw text guess,
- cwd-relative guess,
- shell-known exact object,
- or trusted review object.

## 10) Luxury bundle worth stealing now: WhatIf and compare-after-run

PowerShell is right that pre-run effect posture should be first-class.
Schell should make it easy to ask:
- what will this touch,
- how will this parse,
- what authority will it likely request,
- what shape of output should I expect,
- and how did the receipt differ from the preview?

## 11) Luxury bundle worth stealing now: workflow seeds instead of alias folklore

Warp is right that reusable commands want names, arguments, descriptions, search, and palette discoverability.
Schell should steal that — but keep workflow seeds descriptive and reviewable rather than silently executable policy.

## 12) Luxury bundle worth stealing now: richer session history objects

Xonsh and modern terminal history UIs prove history can be more than one flat file.
Schell should treat recent work as command chapters with:
- lane,
- source,
- footing,
- trust grade,
- outcome,
- and maybe compact attached objects like captured rows or receipts.

## 13) Luxury bundle worth stealing now: pane metadata for local luxury

WezTerm user vars and related shell-integration metadata are a strong clue that panes can carry useful local state without becoming process truth.
That is exactly the right shape for:
- tab titles,
- status strips,
- split inheritance,
- quick summon,
- and local cockpit UX.

The rule is simple:
**pane metadata is for local luxury until promoted into an explicitly named Schell object.**

## 14) Luxury vetoes for phase zero

These are the moves Schell should actively refuse until much later proof exists:

- a universal click/open/execute protocol that erases route distinctions,
- a giant hidden workflow engine beneath “saved commands,”
- any preview or detector surface that silently reruns or auto-edits,
- a final shell grammar chosen mostly to support terminal chrome,
- a final structured-pipeline ontology chosen mostly to support pretty inspectors,
- a final shell↔terminal transport chosen mostly because one current emulator made a feature easy,
- and any AI/help lane that can quietly cross from advice into execution.

## 15) A compact working heuristic

When a new idea appears, ask three questions:

1. **What old failure family could this quietly regrow?**
2. **What exact object or route would make it honest?**
3. **Can we steal the luxury while keeping the deep architecture open?**

If the answer to (3) is yes, the move is probably admissible now.
If not, park it.

## 16) The bounded conclusion

Schell does not need to choose between plain honesty and ambitious delight.
It can have both.
But it will only get both if the archive remembers this rule:

**luxury is good; hidden authority is not.**
