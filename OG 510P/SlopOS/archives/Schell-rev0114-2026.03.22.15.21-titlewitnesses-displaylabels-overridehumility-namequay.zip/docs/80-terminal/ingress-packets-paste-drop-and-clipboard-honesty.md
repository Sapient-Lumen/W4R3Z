# Ingress packets, paste/drop discipline, and clipboard honesty

This surface records a new no-regret candidate cluster for Schell:
**treat outside-world ingress as explicit packets with bounded actions instead of letting paste, drop, or clipboard/file-transfer payloads silently inherit shell authority.**

The design pressure comes from three directions:

- SlopOS keeps forcing import, fresh identity, quarantine, and non-ambient helper discipline.
- DelayBasin keeps urging bounded assimilation, hold packets, and explicit non-promotion when the system declines to move something into a stronger lane.
- Current terminals and shells keep showing that paste is much safer and more humane when it is handled as a special kind of input rather than raw simulated typing.

## 1) One ingress-packet family

Schell should have one small family of ingress objects for things that come **from outside the current live input lane**.
Examples:

- clipboard text paste,
- clipboard rich payload paste,
- drag/drop text,
- drag/drop file list,
- file-transfer clipboard payloads,
- and later perhaps explicit lane-to-lane inserts or agent-proposed inserts.

A packet does not need a giant schema at first.
A small first cut could keep:

- source kind,
- MIME summary,
- size / newline count,
- path-count hint if file-like,
- hidden-structure or control-character hint,
- provenance / authorship hint when known,
- and the currently allowed actions.

This is one of the best no-regret moves available because it keeps the ingress model open without freezing clipboard backends, drag/drop plumbing, or MIME taxonomy.

## 2) Inert by default is a feature, not a punishment

Outside-world ingress should default to **insertion, inspection, import, or staging**.
It should not default to execution.

Good defaults:

- paste into active input as one literal edit when bracketed-paste-safe,
- quote before insert when the user asks for a shell-literal path/value,
- stage suspicious or large packets into a scratch/review lane,
- import dropped files as fresh local objects,
- and open unknown document-like things through an open-untrusted path.

Bad defaults:

- replaying pasted control characters as live key behavior,
- silently expanding pasted globs or variables,
- converting a dropped file into a strong action target just because a path was available,
- or treating “user pasted it” as proof that it should run now.

## 3) Bracketed-paste awareness should shape the insert path

The active-input lane should know whether the shell has declared a bracketed-paste-safe path.
That one bit changes the right behavior a lot.

Possible first-cut behavior:

- if bracketed paste is supported, multi-line text can insert as one edit;
- if not, a multi-line packet should produce a hold card rather than pretending that repeated simulated Return presses are fine;
- single-line safe text may still insert directly;
- suspicious content can always branch into inspect / quote / scratch.

This is exactly the sort of local delight that makes the shell+terminal feel meaningfully better than legacy terminals without deciding the final transport.

## 4) Dropped files should prefer import cards over raw path injection

One of the best “steal this” ideas is to stop treating file drop as a glorified path paste.
Schell should usually prefer a **dropped-file import card**.

Good first actions:

- import as fresh local object,
- open untrusted,
- quote path into active input,
- seed a workflow with the imported object,
- or inspect packet provenance.

That keeps document-like ingress on a document/import seam instead of laundering it into shell text.

## 5) Rich clipboard payloads should remain visible, not flattened away too early

If the clipboard contains `text/plain` plus something richer — HTML, file-transfer MIME, maybe images later — Schell should not have to pretend it only saw text.
The first cut can stay tiny:

- summarize the MIME options,
- prefer plain text for transcript truth,
- and expose one explicit transform/import choice when richer structure matters.

This makes it possible to stay honest without committing to a huge clipboard subsystem.

## 6) Control-character and hidden-structure warnings should be first-class

Ghostty's pasted/dragged control-character fix is a useful warning shot.
Schell should surface hidden control characters, suspicious escapes, or surprising packet structure as packet-local facts.

Good behavior:

- an ingress strip that says control chars were detected,
- an inspect action that reveals the structure safely,
- and refusal to silently replay dangerous control bytes as though they were normal typing.

That is one of the easiest ways to make Schell feel safer and smarter at once.

## 7) Transcript truth still matters here

Ingress handling should survive plain text logs.
A transcript should be able to say things like:

- “ingress packet: clipboard text, 12 lines, inserted as one bracketed paste,”
- “ingress packet: drop file-list, 2 items, imported as fresh local objects, quarantine retained,”
- or “ingress packet: clipboard text contains control chars, direct insert refused, inspect card opened.”

That keeps the fancy terminal from becoming the only place where ingress behavior is understandable.

## 8) No-regret first cut

A first specimen set could stay small:

1. one multi-line clipboard packet on a bracketed-paste-safe input lane,
2. one multi-line packet on a non-bracketed-paste lane that produces a hold card,
3. one dropped-file import card,
4. one control-character warning path,
5. and one transcript witness for all of the above.

That is enough to learn a lot without freezing clipboard protocols, document-store semantics, or the final renderer.
