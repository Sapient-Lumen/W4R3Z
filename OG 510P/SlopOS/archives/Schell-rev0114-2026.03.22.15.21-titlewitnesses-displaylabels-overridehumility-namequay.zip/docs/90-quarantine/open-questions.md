# Open questions

These are live questions that should remain visible until a revision earns the right to narrow them.

- What is Schell’s minimal execution artifact and how small can it stay?
- Should pipelines have distinct data lanes and effect lanes, or is that an explanatory tool rather than runtime law?
- How much typed structure is enough before the shell becomes an object bureaucracy?
- Which builtins deserve authority-aware treatment in the first prototype?
- Is the custom terminal optional sugar, a power-user path, or part of Schell’s core humane proof?
- How much POSIX compatibility is worth preserving once reviewability becomes the priority?
- What is the clean membrane for legacy command strings and shell scripts?
- How should receipt/replay semantics relate to caching, idempotence, and background execution?
- What is the best first denial-teaching interaction?
- How should semantic zones and receipt/denial boundaries survive into transcripts?
- What is the smallest interaction proof that ordinary users actually prefer?
- Which shell+terminal moves are safe to pursue now without silently choosing the final renderer, transport, or pipeline ontology?
- How should active-input leases, scoped work lanes, and workflow seeds relate without turning the terminal into a second authority plane?

- How should authority wallets, diff cards, and revocation hints appear without becoming a second hidden authority plane?

- How should authorship badges, basis packets, and compare-and-set review gates behave without turning the terminal into a bureaucracy?

- How should restored panes, bookmarks, search hits, and historical receipts stay richly useful without masquerading as current live targets?
- How should attention hints, finish notices, and interruption budgets behave without turning the terminal into a second hidden authority plane or fake completion oracle?
- How should selection packets, primary targets, and action ladders behave without letting highlight, hover, or clicked history masquerade as current live authority?
- How should intent packets, plumb routes, and exact-open bridges behave without turning rich visible-object actions into ambient smart-click authority?
- How should remote hops, peer witnesses, and attach honesty behave without turning SSH/mux comfort or forwarded local helpers into hidden authority?

- How should admitted launches, observed target state, shell-owned completion, and user-consumed truth stay distinct without freezing a giant lifecycle engine?

- How should visible hyperlinks, inferred links, rich previews, and extracted content behave without turning the terminal into a stealth browser or raw-URI leak?
