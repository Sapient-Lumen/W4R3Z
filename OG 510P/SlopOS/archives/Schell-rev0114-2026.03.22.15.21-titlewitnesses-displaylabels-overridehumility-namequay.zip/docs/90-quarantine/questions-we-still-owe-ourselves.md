# Questions we still owe ourselves

These questions are load-bearing because answering them too early would harden the wrong layer.

## Core boundary questions

1. Is Schell the shell language, the review environment, the custom terminal, or the whole operator stack?
2. What is the smallest portable text-only subset that must remain usable over SSH and in transcripts?
3. Which parts of the rich terminal experience are optional sugar, and which are core to humane reviewed execution?
4. How should semantic zones survive remote hops, transcripts, and replay?

## Command-model questions

5. What are Schell's true first-class nouns?
6. Is the minimal command artifact an intent, an envelope, a request, or a stage graph?
7. Do pipelines primarily move bytes, descriptors, tiny records, or multiple lanes at once?
8. Which builtins deserve first-class status, and which should remain external tools?

## Authority questions

9. Which grants should be one-shot by default?
10. What should expiry look like in practice?
11. How much rationale is helpful before it becomes review fatigue?
12. How should denials teach without synthesizing broader authority?

## Compatibility questions

13. Is legacy interop a quarantine lane, a first-class compatibility profile, or a membrane that compiles into reviewed actions?
14. Which legacy shell habits are worth preserving, and which should stay outside the trust core entirely?

## Replay questions

15. What does it mean to replay an action honestly?
16. Can a replay refresh leases while staying semantically “the same” action?
17. Which parts of a receipt are stable identity and which are merely observation?

## Authority-surface questions

18. How should a compact authority strip relate to review cards, receipts, and workflow artifacts?
19. When is a wallet or lease summary current, drifted, historical, or simply unknown?
20. How much authority-diff detail is enough before review turns into dashboard fatigue?

## Authorship and basis questions

21. How should visible actionable objects disclose who authored them without turning the terminal into provenance confetti?
22. What is the smallest exact basis packet that can honestly support strong rerun, replay, or workflow execution claims?
23. When should a stale-basis object downgrade from strong action to inspect-only instead of asking for silent forgiveness?

## Reentry and restoration questions

24. What should count as the one primary reentry cue back to the current live lane?
25. When is a restored object honest enough to stay merely restored, and when can it regain a live badge?
26. How should hold cards explain missing liveness, stale basis, or missing exact target identity without review fatigue?

## Attention questions

27. What should count as `quiet`, `default`, `noteworthy`, and `urgent-hint` in a shell+terminal without becoming a fake permission system?
28. When should a finish notice point to a receipt, a review card, a hold card, or merely a lane anchor?
29. How much attention residue is enough to stay honest about suppressed and expired cues without building a giant inbox?

## Evaluation questions

30. What are the first three operator tasks Schell must beat bash on?
31. How do we measure review burden, mis-execution rate, denial clarity, transcript truth, recovery quality, restored-vs-live confusion rate, and alert-fatigue rate?
32. What is the first prototype that can falsify the design quickly?

## Ingress and selection questions

33. When should a visible thing become a selection packet instead of remaining just text?
34. What should count as the one primary target for strong keyboard actions when multiple objects are visible and selected?
35. Which action ladders belong to active-prompt text, semantic zones, paths, receipts, workflows, and restored history?

## Remote continuity questions

36. What should count as a fresh remote peer witness, and when is an attached or restored remote lane honest enough to regain strong actions?
37. Which borrowed local powers should remain available to a remote lane, and how should those powers be surfaced before the operator forgets they are local?

## Outcome-truth questions

38. When should Schell say `admitted`, `observed`, `completed`, `historical`, or `unknown` for an open, run, attach, or restored action?
39. Which target-side witnesses are worth standardizing later, and which should stay optional local luxuries rather than portable truth?


## Link-surface questions

40. When should a visible link stay just text, become a hyperlink witness, or graduate to a richer object card?
41. How should hover, preview, unfurl, content extraction, and recents/history behave so terminal links stay delightful without hidden fetches or raw-URI leakage?
