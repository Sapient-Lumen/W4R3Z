# Schell: start here (for maintainers, including LLMs)

Schell is a **shell+terminal design datacube for SlopOS**.

Non-negotiables:

- **Do not collapse syntax into execution.** Parsing, expansion, authority requests, planning, and process launch are distinct stages.
- **Do not separate shell and terminal so hard that humane reviewed control becomes accidental.** They are co-designed, but their layers still need names.
- **Do not let convenience outrun auditability.** History is not enough; preserve command lineage, effect summaries, and revision receipts.
- **Do not treat side effects as text.** Filesystem mutation, environment mutation, network use, terminal control, background presence, and secret access deserve first-class representation.
- **Do not confuse interactivity with ambient authority.** The shell is a control plane, not a blank cheque.
- **Do not freeze the language before proving the interaction.** A custom shell+terminal can still fail if its smallest reviewed action feels worse than bash.
- **Do not let archive mass explode.** Ratchet the charter, RFCs, ADRs, ledgers, and question states; quarantine the rest.
- **Do not overpromise typed payloads.** Typed lanes are a live option, not a bootstrap dogma.
- **Do not sever the agent boundary.** Automation may propose, but Schell must preserve who asked, what was approved, and what actually ran.
- **Do not let open questions float as prose.** Every load-bearing uncertainty should have a registry entry, next proof surface, and discharge rule.
- **Do not confuse “Rust chosen” with “stack settled.”** Language choice is fixed; line editor, PTY, terminal rendering, async runtime, and serialization remain open until earned.
- **Do not let rich terminal UX become hidden correctness.** Transcript truth must survive logs, SSH, replay, and plain terminals.
- **Do not let full-screen visibility impersonate durable truth.** Alt-screen live state, terminal copy/search overlays, captured output rows, shell-attested output, and durable exact results are different objects even when they feel seamlessly connected.
- **Do not let terminal capability folklore become hidden correctness.** Shell integration, terminfo, keyboard upgrades, graphics, mux passthrough, and platform shims are different capability stories and should stay explicitly witnessed.
- **Do not let terminal luxury paper over ambiguous command meaning.** A smaller native parse floor, exact argv/lane reveal, known externs, and explicit interpreter membranes are safer than compensating for shell folklore with prettier UI.
- **Do not let time/entropy or deterministic-mode toggles stay ambient.** Reviewed commands should say whether they depend on fresh randomness, seed-only posture, deterministic rails, or historical receipts rather than letting host RNG folklore answer for them.
- **Do not let failed-command recovery become hidden authorship.** Not found, found-but-not-invokable, typo correction, package/install advice, path/profile repair, and docs lookup are different actions.
- **Do not let handoff wording overclaim target truth.** Inserted, reviewed, admitted, observed, completed, and user-consumed are different states.
- **Do not silently import ambient shell magic.** Startup files, prompt hooks, per-directory activation, and guessed reruns are design decisions, not harmless defaults.
- **Do not let visible links turn the terminal into a stealth browser.** Showing, inspecting, opening, unfurling, extracting, warming, and durably recording a URI are different actions.
- **Do not let inline media or richer preview turn renderer-local pixels into shell truth or durable residue.** Rendering, opening, safe-opening, exporting, and restoring preview caches are different actions and different truth claims.
- **Do not collapse scope lanes into one flattering history.** Direct commands, agent/proposal work, background residue, receipts, and workflows may all be visible, but they should not inherit the same authority story.
- **Do not let “super awesome” terminal ideas silently choose the architecture.** Follow the no-regret ladder first.
- **Do not let authority summaries become authority.** Wallet strips, diff cards, and receipts must stay descriptive unless a separately named seam grants power.
- **Do not let authorship or reviewed basis disappear before execution.** Strong actions should say who produced the object and what exact basis still matches.
- **Do not let restoration theater masquerade as current live truth.** Restored panes, history hits, and bookmarks are useful, but they are not live targets until the shell says so again.
- **Do not let attention cues masquerade as outcome truth or approval.** Finish notices, banners, bells, and badges may help the operator notice something, but they are not receipts and they do not widen authority by themselves.
- **Do not let assistive access quietly widen into automation authority.** Screen-reader-friendly review, accessible mirrors, braille summaries, and alternate navigation are valuable, but observation, narration, navigation, and injection should stay separately named rights.
- **Do not let ambient chrome become a second truth system.** Titles, badges, titlebar pills, status strips, and taskbar/dock progress may help operators notice state, but they are not durable receipts and they do not prove live identity by themselves.
- **Do not let visible labels borrow exact identity.** Window titles, tab names, split/session labels, and badges may summarize current state, but they should confess source, override, and freshness rather than impersonating exact peer, cwd, or live-state truth.
- **Do not let outside-world ingress arrive as ambient text.** Paste, drag/drop, clipboard MIME payloads, and file-bearing handoffs should stay explicit ingress packets with bounded actions, quarantine hints, and transcript-visible handling.
- **Do not let copy/export become one generic clipboard myth.** Local copy packs, system clipboard writes, remote-local clipboard bridges, and durable share/export are different actions with different trust and persistence stories.
- **Do not let visible selection silently become live authority.** Highlight, hover, click, and semantic-zone selection should produce explicit selection packets with bounded action ladders and a separate primary-target truth.
- **Do not let visible-object actions silently become smart-click folklore.** Open, reveal, insert, attach, derive, and execute should stay separately named even when the terminal feels magical.
- **Do not let spinners, finish notices, or prompt return masquerade as receipts.** Progress, cancellation, draining cleanup, and completion should stay shell-owned exact state with explicit closing witnesses.
- **Do not let cwd, env/profile, activation, or namespace/view posture remain ambient folklore.** Strong open/rerun/replay actions should know the execution ground they stand on.
- **Do not let pane trees or workspaces become a hidden authority plane.** Splits, tabs, restored views, and layout wrappers may be rich local UX, but they are not durable shell truth unless the shell explicitly says so.
- **Do not let remote convenience blur peer identity or borrowed local power.** Fresh connect, attach, resume, restore, SSH/mux reuse, forwarded agents/sockets, and predictive local echo should stay visibly distinct instead of becoming one flattering “still remote” story.
- **Do not let repair suggestions or help handoffs widen authority by themselves.** Quick fixes, autosuggestions, exact command-context bundles, and troubleshooting lanes should stay source-labeled, proposal-only, and compare-and-set aware until a new explicit review path is taken.
- **Do not let command recall or recent-chapter UX masquerade as current authority.** Exact chapters, journals, and chapter browsers should stay source-labeled, peer-aware, and weaker than fresh review on current basis.
- **Do not let saved seeds, shared runbooks, or palette picks bypass fresh review.** Reusable command artifacts should preserve provenance, visible parameters, and share posture instead of turning convenience into hidden execution policy.
- **Do not let clicks, links, or workflow picks collapse into ambient open/run behavior.** Visible-object actions should route through explicit intent packets and route witnesses so exact open, exact reveal, insert, attach, derive, and execute stay visibly distinct.
- **Do not let object cards or previews become hidden helper policy.** Exact reveal, ordinary open, safe-open, and insert should stay separately named even when visible objects feel magical.
- **Do not let transcript export or replay bundles quietly become current authority.** Attach, export scrubbed, export full, replay readonly, and publish should stay separately named, redaction-visible, and weaker than fresh review on current basis.
- **Do not let review buffer, replay capsules, published links, and live shared sessions collapse into one flattering share story.** Capture scope, publication destination, replay fidelity, and live permissions should stay separately named.
- **Do not let smart enrichment quietly become hidden helper execution or background prefetch truth.** Rich suggestions, previews, semantic links, and metadata hints may help a lot, but stronger refresh/materialize work should remain explicit and source/freshness/cost badges should stay visible.
- **Do not let prompt-time delight become a hidden worker topology.** Keystroke-time help, prompt render, explicit summon, idle refresh, and restored historical help should stay named lanes so fast typing never depends on unseen helper heroics.
- **Do not let repo-local smartness become ambient shell authorship.** Checked-in helpers, hooks, workflow packs, validators, and shared runbooks may be useful, but they should be visible before active, locally leased, reauthorized on change, and weaker than fresh shell review by default.
- **Do not let assistant conversation, playbooks, and shell input collapse into one flattering field.** Chat, insert, review, run, plan, and trusted-auto lanes should stay visibly distinct, source-labeled, and weaker than exact reviewed shell truth unless a separately named seam widens power.
- **Do not let ghost suggestions, accepted inserts, and reviewed action collapse into one flattering command line.** Visible prediction, accepted buffer text, live editable prompt, and reviewed action should stay separately named so inline delight never impersonates authored input or execution truth.
- **Do not let editor roundtrips turn temp files, save/close events, or returned draft text into reviewed execution truth.** External editor bridges should keep exported draft, editor session, return merge, accepted live buffer, and later review separately named.
- **Do not let detectors, triggers, or quick fixes become a second shell.** Source-labeled detection can be wonderful, but regex hits, restored matches, and helper suggestions should stay weaker than shell-known truth and must not auto-edit, auto-rerun, or silently upgrade into stronger actions.
- **Do not let local services or forwarded ports quietly become browser or exposure folklore.** Loopback detection, forwarded reachability, local open, preview, copied addresses, and private/public sharing are different actions with different truth claims.
- **Do not let prompt return or `&` folklore masquerade as durable continuation truth.** Foreground tty claim, stopped jobs, shell-tracked background work, disown, detach, and promoted supervised continuation are different states with different evidence.
- **Do not let run-later UX collapse into cron folklore or daemon persistence.** One-shot windows, periodic maintenance intents, exact alarms, missed-run catch-up, and durable background presence are different moves with different truth and power stories.
- **Do not let one keystroke silently fan out into hidden fleet authority.** Broadcast input, selected target sets, reviewed multi-target execution, and durable background orchestration are different actions with different blast-radius and outcome-truth stories.
- **Do not let “share terminal” collapse watching, annotating, co-driving, browser join, service share, and evidence export into one flattering invite.** Observation, writable control, guest identity, guest-side side effects, and exported evidence are different collaboration seams.
- **Do not let “clear”, “private”, and “forget” overclaim memory erasure.** Clearing the viewport, clearing scrollback, suppressing future history, deleting session history, pruning durable history, clearing recents, and evicting restored or preview residue are different actions with different guarantees.

- **Do not let visible text composition state masquerade as committed shell text or reviewed argv.** IME preedit, dead-key holds, candidate windows, grapheme width, and committed buffer text are different truth families.
- **Do not let requested size, realized viewport, and local reflow collapse into one flattering geometry myth.** Window pixels, text-area pixels, rows/cols, cell metrics, mux size policy, and wrapped local view are different truth families.

## Read first

1. `START_HERE.md`
2. `docs/00-meta/question-machine.md`
3. `QUESTION-REGISTRY.json`
4. `docs/80-terminal/drop-witnesses-file-offers-and-path-translation-humility.md`
5. `docs/00-meta/research-synthesis-2026-03-22-pass-cx.md`
6. `docs/00-meta/slopos-datacube-evaluation-pass-cx.md`
7. `docs/80-terminal/bracketed-paste-witnesses-multiline-grants-and-clipboard-query-humility.md`
8. `docs/80-terminal/signal-witnesses-interrupt-ladders-and-hangup-humility.md`
9. `docs/80-terminal/notification-witnesses-bell-routing-and-click-humility.md`
10. `docs/80-terminal/keymap-witnesses-chord-discoverability-and-editor-humility.md`
10. `docs/80-terminal/completion-witnesses-candidate-sources-and-insertion-humility.md`
11. `docs/80-terminal/integration-witnesses-semantic-negotiation-and-hop-downgrade-humility.md`
12. `docs/20-language/parse-floors-known-externs-and-evaluation-humility.md`
13. `docs/80-terminal/argv-witnesses-exact-reveal-and-escape-humility.md`
14. `docs/80-terminal/workflow-seeds-parameter-cards-and-runbook-honesty.md`
15. `docs/80-terminal/shell-terminal-co-design-for-slopos.md`
16. `docs/80-terminal/no-regret-shell-terminal-moves.md`
17. `docs/20-language/expansion-and-quoting.md`
18. `docs/00-meta/delaybasin-lessons-for-schell.md`
19. `README.md`

## One command

```bash
make lint
```

## What a good revision looks like

A good Schell revision does at least one of these:

- clarifies the integrated shell+terminal control model,
- or makes rich completion menus, typed candidate fills, and fallback posture more honest without letting tab-time helper logic become hidden parser or execution power.
- or makes prompt segments, right prompts, transient redraws, and async status more honest without letting startup hooks, shell-outs, or repo-local context loaders become a hidden second shell.
- or makes dropped text, dropped file offers, path translation, quoting, and stronger transfer promotions more honest without letting drag/drop convenience collapse into plain typing, canonical object identity, or hidden remote upload authority.
- or makes bracketed paste, multiline send, target-aware paste transforms, and clipboard-query authority more honest without letting typed text, pasted text, selected-text replay, or ambient clipboard reads collapse into one flattering input story.
- or makes key transport, negotiated encodings, layout-aware shortcut matching, and mux/remote downgrade posture more honest without letting invisible protocol luck become hidden shell truth.
- or makes full-screen/TUI life, alt-screen posture, copy/search overlays, and promotion from visible framebuffer state to stronger exact command/output/result truth more honest without flattening terminal observation into durable shell authority.
- or makes composition/preedit state, committed text, candidate ownership, and grapheme-width posture more honest without letting visible preedit or display heuristics impersonate exact shell meaning.
- or makes requested geometry, realized window/pane size, cell metrics, mux size policy, and local reflow more honest without letting resize comfort or visible wrapped text impersonate exact shell/output truth.
- or makes discoverable keymaps, help bindings, prompt-click editing, and submit-class shortcuts more honest without letting widgets or shortcut handlers become a hidden second shell.
- hardens an authority boundary,
- makes an effect surface more legible,
- converts shell folklore into an explicit contract,
- improves replay and failure diagnosis,
- records a live assumption or deferred obligation honestly,
- advances one question from `open` to `narrowed` or from `narrowed` to `prototyping` with a concrete proof surface,
- preserves a nearby rejected move so syntax does not fossilize too early,
- improves release hygiene or lints so the archive tells the truth about its current head,
- makes one candidate interaction obviously more humane than bash without widening ambient authority,
- keeps restoration, history, and search honest about what is and is not live,
- makes attention and interruption cues more helpful without letting them become fake completion proof,
- or sharpens transcript truth so semantic terminal features remain portable and auditable.
- or turns paste, drag/drop, and clipboard/file-transfer ingress into a more explicit and reviewable packet family without freezing a giant clipboard subsystem.
- or makes panes, tabs, splits, and restored workspaces much richer locally without letting the view tree masquerade as durable shell truth.
- or makes visible selection, primary-target truth, and action ladders more honest without flattening the terminal into one giant live surface.
- or turns command output into richer exact capsules with explicit channel/provenance/merge truth without freezing a giant logging stack.
- or makes visible-object actions much smarter by routing them through explicit intent packets and route witnesses without collapsing open, reveal, insert, attach, and execute into one smart-click authority story.
- or makes transcript cards, replay bundles, and selective export dramatically more useful without letting replay, sharing, or scrubbed transcripts impersonate live authority or fresh review.

- or makes progress, waiting-input, cancellation, and draining cleanup more honest without letting local progress UI become receipt folklore.
- or makes cwd/env/activation truth much more explicit and inspectable without freezing a workspace model or dev-shell treaty.
- or makes remote lanes much more honest about peer identity, attach/resume posture, borrowed-local authority, and hop uncertainty without freezing a final remote transport.
- or makes post-failure help much more exact and humane through failure packets, repair cards, and handoff bundles without letting suggestions or troubleshooting handoff become ambient repair authority.
- or makes command chapters, journals, and recall dramatically more useful without letting history, search, or chapter browsers impersonate current authority or approval.
- or makes reusable command seeds and runbooks dramatically more helpful through visible parameters, provenance badges, and review-first landings without turning palette picks or shared artifacts into hidden execution policy.
