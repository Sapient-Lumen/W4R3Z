#!/usr/bin/env python3
"""Check Harbor user-visible explanation bundle v0."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

from harbor_bundle_common import check_digest_string, digest, expect, fail, file_digest, unguarded_confidence_phrases  # noqa: E402
import harbor_user_visible_explanation_harness as harness  # noqa: E402


def check_case(case: dict[str, Any]) -> None:
    case_id = case["id"]
    candidate = case["candidate"]
    plan = next(plan for plan in harness.CASE_PLAN if plan["id"] == case_id)
    expected = plan["expected"]

    source = case["overlay.input"]
    audience = case["audience.context"]
    copy = case["explanation.copy"]
    reason = case["reason.code"]
    action = case["action.affordance"]
    access = case["access.localization"]
    history = case["history.trace"]
    verdict = case["verdict.summary"]

    expect(case["row_digest"] == digest({label: case[label] for label in harness.MEMBER_LABELS}), f"{case_id}: row digest drift")
    check_digest_string(source["parent_bundle_digest"], f"{case_id}: parent bundle digest malformed")
    if source["overlay_digest_present"]:
        check_digest_string(source["overlay_digest"], f"{case_id}: overlay digest malformed")
    if source["scope_map_present"]:
        check_digest_string(source["scope_map_digest"], f"{case_id}: scope map digest malformed")
    check_digest_string(copy["copy_digest"], f"{case_id}: copy digest malformed")
    check_digest_string(reason["reason_digest"], f"{case_id}: reason digest malformed")
    check_digest_string(action["action_digest"], f"{case_id}: action digest malformed")
    check_digest_string(access["render_digest"], f"{case_id}: render digest malformed")
    check_digest_string(history["history_digest"], f"{case_id}: history digest malformed")
    check_digest_string(history["parent_overlay_bundle_digest"], f"{case_id}: history parent digest malformed")
    expect(source["parent_bundle_digest"] == history["parent_overlay_bundle_digest"], f"{case_id}: parent digest mismatch")
    expect("not Harbor authority by itself" in source["source_non_promises"], f"{case_id}: source non-promise missing")
    expect(audience["reading_level_goal"] == "plain operational language", f"{case_id}: reading-level posture drift")
    expect(verdict["badge_allowed"] is False, f"{case_id}: badge cannot be allowed")
    expect(verdict["compliance_claim_allowed"] is False, f"{case_id}: compliance cannot be allowed")
    expect(verdict["legal_finding_allowed"] is False, f"{case_id}: legal finding cannot be allowed")
    expect(verdict["global_repair_claim_allowed"] is False, f"{case_id}: global repair cannot be allowed")
    expect(verdict["read_or_application_claim_allowed"] is False, f"{case_id}: read/application cannot be allowed")
    expect(verdict["history_erasure_allowed"] is False, f"{case_id}: history erasure cannot be allowed")
    for non_promise in harness.NON_PROMOTION:
        expect(non_promise in verdict["non_promises"], f"{case_id}: missing non-promise {non_promise}")

    if expected == "accepted":
        expect(verdict["expected"] == "accepted", f"{case_id}: accepted expectation drift")
        expect(verdict["verdict_class"] == "accepted_scoped_user_explanation", f"{case_id}: accepted verdict class drift")
        expect(verdict["failure_reasons"] == [], f"{case_id}: accepted case has failure reasons")
        expect(source["overlay_digest_present"] is True, f"{case_id}: accepted case missing overlay digest")
        expect(source["scope_map_present"] is True, f"{case_id}: accepted case missing scope map")
        expect(copy["plain_language_present"] is True, f"{case_id}: accepted case lacks user copy")
        expect(copy["caveats"], f"{case_id}: accepted case lacks caveats")
        expect(copy["badge_shape_used"] is False and copy["red_failure_shape_used"] is False, f"{case_id}: accepted case uses badge shape")
        expect(copy["closure_language_used"] is False and copy["prior_fault_language_used"] is False, f"{case_id}: accepted case uses closure/fault language")
        expect(action["repair_claimed"] is False and action["global_downstream_action_claimed"] is False, f"{case_id}: accepted case claims repair")
        expect(action["read_claimed_from_delivery"] is False and action["applied_claimed_from_delivery"] is False, f"{case_id}: accepted case upgrades delivery")
        expect(access["programmatic_label_present"] is True and access["text_not_color_only"] is True, f"{case_id}: accepted case lacks accessible text posture")
        expect(access["localized_scope_widened"] is False, f"{case_id}: accepted case widens localization scope")
        expect(access["accessibility_conformance_claimed"] is False and access["localization_equivalence_claimed"] is False, f"{case_id}: accepted case overclaims access/localization")
        expect(history["prior_history_visible"] is True and history["mixed_overlay_state_preserved"] is True, f"{case_id}: accepted case hides history or mixed state")
    else:
        expect(verdict["expected"] == "rejected", f"{case_id}: rejected expectation drift")
        expect(verdict["verdict_class"] == "refused_explanation_status_collapse", f"{case_id}: rejected verdict class drift")
        expect(verdict["failure_reasons"] == [harness.FAILURE_REASONS[candidate]], f"{case_id}: failure reason drift")

    flags = verdict["flags"]
    if candidate == "mirror_stale_recheck_explanation":
        expect("Recheck" in copy["body"] or "recheck" in copy["body"], f"{case_id}: stale mirror lacks recheck wording")
    elif candidate == "generated_summary_carries_overlay_basis":
        expect(source["overlay_digest_present"] is True and "not source equivalent" in copy["caveats"], f"{case_id}: generated summary basis drift")
    elif candidate == "consumer_notice_delivery_vs_read_split":
        expect("Delivery is recorded separately" in copy["body"], f"{case_id}: consumer notice split wording missing")
    elif candidate == "warning_card_split_state_plain_language":
        expect("split by scope" in copy["body"], f"{case_id}: warning card split wording missing")
    elif candidate == "sealed_overlay_public_safe_summary":
        expect(audience["sealed_context"] is True and copy["sealed_detail_leaked"] is False, f"{case_id}: sealed summary not safe")
    elif candidate == "mixed_cube_incomparable_explanations":
        expect(audience["multi_cube_context"] is True and history["mixed_overlay_state_preserved"] is True, f"{case_id}: mixed overlay collapsed")
    elif candidate == "localized_variant_bound_to_source_digest":
        expect(access["translation_provenance_present"] is True and access["localized_variant_digest"], f"{case_id}: localization lacks provenance")
    elif candidate == "accessible_status_message_non_color_only":
        expect(audience["needs_programmatic_status"] is True and access["programmatic_label_present"] is True and access["text_not_color_only"] is True, f"{case_id}: status message access posture drift")
    elif candidate == "machine_reason_paired_with_user_copy":
        expect(reason["problem_detail_shape"] is True and reason["human_text_present"] is True, f"{case_id}: machine reason lacks user copy")
    elif candidate == "appeal_recheck_affordance_without_repair":
        expect("request recheck" in action["allowed_actions"] and action["repair_claimed"] is False, f"{case_id}: action affordance overclaims")
    elif candidate == "missing_source_overlay_digest":
        expect(flags["missing_source_overlay_digest"] is True, f"{case_id}: missing digest flag absent")
    elif candidate == "status_message_without_programmatic_label":
        expect(flags["missing_programmatic_label"] is True, f"{case_id}: missing label flag absent")
    elif candidate == "translation_without_provenance":
        expect(flags["translation_without_provenance"] is True, f"{case_id}: translation provenance flag absent")


def check_bundle(bundle: dict[str, Any]) -> None:
    expect(bundle.get("schema") == harness.SCHEMA, "Schema drift")
    expect(bundle.get("version") == harness.VERSION, "Version drift")
    expect(bundle.get("source_revision") == harness.REVISION, "Source revision drift")
    expect(bundle.get("member_labels") == harness.MEMBER_LABELS, "Member label drift")
    expect(bundle.get("prior_revocation_overlay_bundle_digest") == harness.prior_f104_digest(), "Prior F104 digest drift")
    expect(bundle.get("bundle_common_helper_digest") == file_digest(ROOT / "tools" / "harbor_bundle_common.py"), "Bundle helper digest drift")
    if (ROOT / "tools" / "check_harbor_briefing_focus.py").exists():
        expect(bundle.get("briefing_focus_audit_checker_digest") == file_digest(ROOT / "tools" / "check_harbor_briefing_focus.py"), "Briefing focus checker digest drift")
    expected_digest = digest({key: bundle[key] for key in ["schema", "version", "source_revision", "member_labels", "prior_revocation_overlay_bundle_digest", "bundle_common_helper_digest", "briefing_focus_audit_checker_digest", "cases", "audit_refactor_note", "global"]})
    expect(bundle.get("bundle_digest") == expected_digest, "Bundle digest drift")
    check_digest_string(bundle["bundle_digest"], "Bundle digest malformed")
    expect(not unguarded_confidence_phrases(bundle), "Bundle contains unguarded confidence/status phrase")

    cases = bundle.get("cases", [])
    expect(len(cases) == len(harness.CASE_PLAN), "Case count drift")
    expect([case["index"] for case in cases] == list(range(1, len(cases) + 1)), "Case indexes not gapless")
    expect([case["id"] for case in cases] == [plan["id"] for plan in harness.CASE_PLAN], "Case id order drift")
    expect([case["candidate"] for case in cases] == [plan["candidate"] for plan in harness.CASE_PLAN], "Candidate order drift")
    for case in cases:
        check_case(case)

    accepted = sum(1 for case in cases if case["verdict.summary"]["expected"] == "accepted")
    rejected = len(cases) - accepted
    global_ = bundle.get("global", {})
    expect(global_.get("case_count") == len(cases), "Global case count drift")
    expect(global_.get("accepted_count") == accepted, "Global accepted count drift")
    expect(global_.get("rejected_count") == rejected, "Global rejected count drift")
    expect(global_.get("source_revision") == harness.REVISION, "Global source revision drift")
    for refusal in harness.NON_PROMOTION:
        expect(refusal in global_.get("non_promotion", []), f"Global non-promotion missing {refusal}")
    audit = bundle.get("audit_refactor_note", {})
    expect("check_harbor_briefing_focus.py" in audit.get("refactor", "") or "briefing" in audit.get("audit_guard", ""), "Audit/refactor note missing briefing focus audit")
    expect("not schema" in audit.get("non_promise", ""), "Audit/refactor non-promise missing")


def main() -> None:
    parser = argparse.ArgumentParser(description="Check Harbor user-visible explanation bundle")
    parser.add_argument("--fixture", type=Path, default=ROOT / "fixtures" / "harbor-user-visible-explanation-bundle-v0.json")
    args = parser.parse_args()
    expected = harness.build_bundle()
    check_bundle(expected)
    if args.fixture.exists():
        actual = json.loads(args.fixture.read_text(encoding="utf-8"))
        expect(actual == expected, "Checked fixture does not match deterministic harness output")
    else:
        fail(f"Fixture missing: {args.fixture}")
    print("Harbor user-visible explanation bundle check passed")


if __name__ == "__main__":
    main()
