#!/usr/bin/env python3
"""Emit deterministic Harbor cross-cube lineage import evidence.

F102 starts after Harbor can model overlapping correction epochs inside its own
cube. The next pressure is foreign evidence: SlopOS may carry ordered portal-net
append history, Foundry may carry classification pins, Steward may carry retry
attempts, Schell may carry retention/forgetting context, ViewFS may carry
volition cards, Ward may carry delegation warrants, and Helm may carry repair
traces. Each fragment can help Harbor, but none may arrive as inherited Harbor
status, currentness, repair, warning, consent, delegation authority, or
compliance. This harness keeps import material, scope mapping, authority
quarantine, local lineage, and verdicts separate.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]

SCHEMA = "harbor-cross-cube-lineage-import-bundle"
VERSION = "0"
REVISION = "rev0111"

MEMBER_LABELS = [
    "import.matrix",
    "foreign.material",
    "local.observation",
    "scope.translation",
    "authority.quarantine",
    "lineage.bridge",
    "recheck.plan",
    "verdict.summary",
]

NON_PROMOTION = [
    "no cross-cube status inheritance",
    "no companion trust root",
    "no foreign compliance workflow",
    "no multi-cube conflict-resolution engine",
    "no global public badge workflow",
    "no consent/delegation authority transfer",
    "no repair ledger import API",
    "no final SlopOS datacube shape",
]

FOREIGN_CATALOG: dict[str, dict[str, str]] = {
    "SlopOS": {
        "revision": "rev0720",
        "archive_name": "SlopOS-rev0720-2026.05.20.18.26-portal-net-recheckpoint-resume-truncation-append-corpus(14).zip",
        "archive_sha256": "sha256:4336783c9b91df78e946efcdb078a1b6e723da3664496e0d122998510989b6e6",
        "fragment_family": "portal.net.accepted_append_history",
        "native_status": "accepted_append_replayable",
        "safe_harbor_use": "ordering_witness_only",
    },
    "Foundry": {
        "revision": "rev0082",
        "archive_name": "Foundry-rev0082-2026.05.15.15.24-classificationpins-crosswalkwitnesses-codedriftfences-ochreswitch(13).zip",
        "archive_sha256": "sha256:ad1ef986410a92085582bcc32540158e2129f13a7bfa617cde3b6672f1dbeb08",
        "fragment_family": "classification.pin_crosswalk_witness",
        "native_status": "classification_pin_present",
        "safe_harbor_use": "label_provenance_only",
    },
    "Steward": {
        "revision": "rev0181",
        "archive_name": "Steward-rev0181-2026.05.15.23.16-retryattempts-replayguards-pushbackbudgets-amberwake(13).zip",
        "archive_sha256": "sha256:c695eaa8ba2aa281564c9983a1a010d10b9855c731a30c6828fa0d89b8463e0f",
        "fragment_family": "retry.attempt_replay_guard_pushback_budget",
        "native_status": "retry_budget_observed",
        "safe_harbor_use": "attempt_history_only",
    },
    "Schell": {
        "revision": "rev0248",
        "archive_name": "Schell-rev0248-2026.05.18.19.01-retentionbudgets-forgettingledgers-minimizationfences-pearlforge(14).zip",
        "archive_sha256": "sha256:1fd0a1b0d497da7b6e0db34e93d2141a281f0db1edda878fd12b4d434e9924b5",
        "fragment_family": "retention.budget_forgetting_ledger_minimization_fence",
        "native_status": "retention_budget_recorded",
        "safe_harbor_use": "retention_context_only",
    },
    "ViewFS": {
        "revision": "rev0154",
        "archive_name": "ViewFS-rev0154-2026.05.18.20.28-volitioncards-trustedpaths-consentfences-jadegate(14).zip",
        "archive_sha256": "sha256:8bb9865e832412bb77184895f201fcbd645f58aa1e63a5280ad2853f729b3b6b",
        "fragment_family": "volition.card_trusted_path_consent_fence",
        "native_status": "volition_card_recorded",
        "safe_harbor_use": "consent_evidence_only",
    },
    "Ward": {
        "revision": "rev0077",
        "archive_name": "Ward-rev0077-2026.05.16.04.06-stewardshipcharters-delegationwarrants-escalationhandoffs-ivoryrelay(14).zip",
        "archive_sha256": "sha256:22371bafd203bb1145528b4254096e218077360fdb74204e55ed360d99021928",
        "fragment_family": "delegation.warrant_stewardship_charter_escalation_handoff",
        "native_status": "delegation_warrant_present",
        "safe_harbor_use": "route_or_escalation_evidence_only",
    },
    "Helm": {
        "revision": "rev0203",
        "archive_name": "Helm-rev0203-2026.05.18.19.52-repairattempts-interventiontraces-remainderbridges-cobaltorchid(14).zip",
        "archive_sha256": "sha256:571d805d2f69471362b991b6ec632e651e653d0d1e2947dcef16a6315cc85e3a",
        "fragment_family": "repair.attempt_intervention_trace_remainder_bridge",
        "native_status": "repair_trace_observed",
        "safe_harbor_use": "repair_attempt_evidence_only",
    },
}

CASE_PLAN: list[dict[str, Any]] = [
    {"id": "XC001", "candidate": "slopos_portal_append_imported_as_ordering_witness", "cubes": ["SlopOS"], "expected": "accepted"},
    {"id": "XC002", "candidate": "foundry_classification_pin_imported_as_label_provenance", "cubes": ["Foundry"], "expected": "accepted"},
    {"id": "XC003", "candidate": "steward_retry_history_imported_as_attempt_history", "cubes": ["Steward"], "expected": "accepted"},
    {"id": "XC004", "candidate": "schell_retention_context_imported_without_deletion_claim", "cubes": ["Schell"], "expected": "accepted"},
    {"id": "XC005", "candidate": "viewfs_volition_card_imported_as_consent_evidence_only", "cubes": ["ViewFS"], "expected": "accepted"},
    {"id": "XC006", "candidate": "ward_delegation_warrant_imported_as_route_evidence_only", "cubes": ["Ward"], "expected": "accepted"},
    {"id": "XC007", "candidate": "helm_repair_trace_imported_with_harbor_scope_recheck", "cubes": ["Helm"], "expected": "accepted"},
    {"id": "XC008", "candidate": "multi_cube_conflicting_fragments_admitted_as_incomparable_split", "cubes": ["SlopOS", "Foundry", "Helm"], "expected": "accepted"},
    {"id": "XC009", "candidate": "sealed_foreign_packet_imported_by_digest_with_public_summary_limit", "cubes": ["Ward", "Schell"], "expected": "accepted"},
    {"id": "XC010", "candidate": "stale_companion_revision_imported_as_historical_residue", "cubes": ["ViewFS", "Steward"], "expected": "accepted"},
    {"id": "XC011", "candidate": "foreign_green_status_inherited_as_harbor_status", "cubes": ["Helm"], "expected": "rejected"},
    {"id": "XC012", "candidate": "replay_availability_imported_as_currentness", "cubes": ["SlopOS"], "expected": "rejected"},
    {"id": "XC013", "candidate": "retention_window_imported_as_repair", "cubes": ["Schell"], "expected": "rejected"},
    {"id": "XC014", "candidate": "foreign_warning_state_imported_as_public_badge", "cubes": ["Ward", "Helm"], "expected": "rejected"},
    {"id": "XC015", "candidate": "companion_revision_imported_as_freshness", "cubes": ["Foundry"], "expected": "rejected"},
    {"id": "XC016", "candidate": "foreign_scope_widened_on_import", "cubes": ["Foundry", "ViewFS"], "expected": "rejected"},
    {"id": "XC017", "candidate": "foreign_archive_digest_mismatch_accepted", "cubes": ["SlopOS"], "expected": "rejected"},
    {"id": "XC018", "candidate": "copied_fragment_without_parent_manifest", "cubes": ["Steward"], "expected": "rejected"},
    {"id": "XC019", "candidate": "cross_cube_total_order_without_clock_map", "cubes": ["SlopOS", "Steward", "Helm"], "expected": "rejected"},
    {"id": "XC020", "candidate": "mixed_cube_policy_majority_wins", "cubes": ["Foundry", "Ward", "Helm"], "expected": "rejected"},
    {"id": "XC021", "candidate": "sealed_foreign_evidence_imported_as_public_truth", "cubes": ["Ward"], "expected": "rejected"},
    {"id": "XC022", "candidate": "foreign_acknowledgement_imported_as_consumer_repair", "cubes": ["ViewFS"], "expected": "rejected"},
    {"id": "XC023", "candidate": "callback_success_imported_as_authority", "cubes": ["SlopOS", "Ward"], "expected": "rejected"},
    {"id": "XC024", "candidate": "slopos_append_order_imported_as_semantic_supersession", "cubes": ["SlopOS"], "expected": "rejected"},
    {"id": "XC025", "candidate": "foundry_classification_pin_imported_as_status_truth", "cubes": ["Foundry"], "expected": "rejected"},
    {"id": "XC026", "candidate": "steward_retry_exhaustion_imported_as_compliance_failure", "cubes": ["Steward"], "expected": "rejected"},
    {"id": "XC027", "candidate": "schell_forgetting_ledger_imported_as_erasure_proof", "cubes": ["Schell"], "expected": "rejected"},
    {"id": "XC028", "candidate": "viewfs_volition_card_imported_as_consent_outcome", "cubes": ["ViewFS"], "expected": "rejected"},
    {"id": "XC029", "candidate": "ward_delegation_warrant_imported_as_authority_transfer", "cubes": ["Ward"], "expected": "rejected"},
    {"id": "XC030", "candidate": "helm_repair_trace_imported_as_completed_repair", "cubes": ["Helm"], "expected": "rejected"},
]

FAILURE_REASONS = {
    "foreign_green_status_inherited_as_harbor_status": "foreign_green_status_inherited",
    "replay_availability_imported_as_currentness": "replay_availability_as_currentness",
    "retention_window_imported_as_repair": "retention_window_as_repair",
    "foreign_warning_state_imported_as_public_badge": "warning_state_as_public_badge",
    "companion_revision_imported_as_freshness": "companion_revision_as_freshness",
    "foreign_scope_widened_on_import": "scope_widening_on_import",
    "foreign_archive_digest_mismatch_accepted": "foreign_archive_digest_mismatch",
    "copied_fragment_without_parent_manifest": "copied_fragment_without_parent_manifest",
    "cross_cube_total_order_without_clock_map": "cross_cube_total_order_without_clock_map",
    "mixed_cube_policy_majority_wins": "majority_vote_foreign_policy",
    "sealed_foreign_evidence_imported_as_public_truth": "sealed_foreign_evidence_as_public_truth",
    "foreign_acknowledgement_imported_as_consumer_repair": "foreign_ack_as_consumer_repair",
    "callback_success_imported_as_authority": "callback_success_as_authority",
    "slopos_append_order_imported_as_semantic_supersession": "slopos_append_order_as_semantic_supersession",
    "foundry_classification_pin_imported_as_status_truth": "foundry_classification_pin_as_status_truth",
    "steward_retry_exhaustion_imported_as_compliance_failure": "steward_retry_exhaustion_as_compliance_failure",
    "schell_forgetting_ledger_imported_as_erasure_proof": "schell_forgetting_ledger_as_erasure_proof",
    "viewfs_volition_card_imported_as_consent_outcome": "viewfs_volition_card_as_consent_outcome",
    "ward_delegation_warrant_imported_as_authority_transfer": "ward_delegation_warrant_as_authority_transfer",
    "helm_repair_trace_imported_as_completed_repair": "helm_repair_trace_as_completed_repair",
}


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def digest(value: Any) -> str:
    return "sha256:" + hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def file_digest(rel: str) -> str:
    return "sha256:" + hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()


def read_json(rel: str) -> dict[str, Any]:
    return json.loads((ROOT / rel).read_text(encoding="utf-8"))


def f101_lineage_digest() -> str:
    bundle = read_json("fixtures/harbor-overlapping-correction-lineage-bundle-v0.json")
    return bundle.get("bundle_digest", file_digest("fixtures/harbor-overlapping-correction-lineage-bundle-v0.json"))


def release_root_digest() -> str:
    manifest = read_json("RELEASE-MANIFEST.json")
    return digest({
        "kind": "f102_release_root",
        "archive": manifest.get("archive"),
        "revision": manifest.get("revision"),
        "basis": f101_lineage_digest(),
    })


def fragment_digest(cube: str, candidate: str) -> str:
    meta = FOREIGN_CATALOG[cube]
    return digest({
        "kind": "f102_foreign_fragment",
        "cube": cube,
        "revision": meta["revision"],
        "archive_sha256": meta["archive_sha256"],
        "fragment_family": meta["fragment_family"],
        "candidate": candidate,
    })


def imported_cubes(plan: dict[str, Any]) -> list[str]:
    return list(plan["cubes"])


def parent_manifest_present(candidate: str) -> bool:
    return candidate != "copied_fragment_without_parent_manifest"


def archive_digest_ok(candidate: str) -> bool:
    return candidate != "foreign_archive_digest_mismatch_accepted"


def scope_relation(candidate: str) -> str:
    if "multi_cube_conflicting" in candidate:
        return "incomparable_split"
    if "stale_companion" in candidate:
        return "historical_only"
    if "sealed_foreign" in candidate:
        return "sealed_public_summary_only"
    if "foreign_scope_widened" in candidate:
        return "widened_without_authority"
    if "total_order" in candidate:
        return "ordered_without_clock_map"
    if "majority" in candidate:
        return "policy_epoch_incomparable"
    return "mapped_narrower_or_equal"


def authority_flags(candidate: str, expected: str) -> dict[str, Any]:
    inherited = {
        "harbor_status_inherited": candidate == "foreign_green_status_inherited_as_harbor_status",
        "currentness_inherited": candidate in {"replay_availability_imported_as_currentness", "companion_revision_imported_as_freshness"},
        "repair_inherited": candidate in {"retention_window_imported_as_repair", "foreign_acknowledgement_imported_as_consumer_repair", "helm_repair_trace_imported_as_completed_repair"},
        "public_badge_inherited": candidate == "foreign_warning_state_imported_as_public_badge",
        "public_truth_inherited": candidate == "sealed_foreign_evidence_imported_as_public_truth",
        "authority_transfer_inherited": candidate in {"callback_success_imported_as_authority", "ward_delegation_warrant_imported_as_authority_transfer"},
        "consent_outcome_inherited": candidate == "viewfs_volition_card_imported_as_consent_outcome",
        "semantic_supersession_inherited": candidate == "slopos_append_order_imported_as_semantic_supersession",
        "classification_status_truth_inherited": candidate == "foundry_classification_pin_imported_as_status_truth",
        "compliance_failure_inherited": candidate == "steward_retry_exhaustion_imported_as_compliance_failure",
        "erasure_proof_inherited": candidate == "schell_forgetting_ledger_imported_as_erasure_proof",
        "majority_policy_inherited": candidate == "mixed_cube_policy_majority_wins",
    }
    inherited["any_inherited_status"] = any(inherited.values())
    inherited["quarantine_state"] = "passed" if expected == "accepted" else "failed"
    return inherited


def foreign_material(plan: dict[str, Any]) -> dict[str, Any]:
    candidate = plan["candidate"]
    rows = []
    for cube in imported_cubes(plan):
        meta = FOREIGN_CATALOG[cube]
        rows.append({
            "cube": cube,
            "foreign_revision": meta["revision"],
            "archive_name": meta["archive_name"],
            "archive_sha256_observed": meta["archive_sha256"] if archive_digest_ok(candidate) else "sha256:0000000000000000000000000000000000000000000000000000000000000000",
            "archive_sha256_expected": meta["archive_sha256"],
            "archive_digest_ok": archive_digest_ok(candidate),
            "fragment_family": meta["fragment_family"],
            "native_status": meta["native_status"],
            "safe_harbor_use": meta["safe_harbor_use"],
            "fragment_digest": fragment_digest(cube, candidate),
            "parent_manifest_present": parent_manifest_present(candidate),
            "material_non_promises": [
                "foreign fragment is not Harbor status",
                "foreign archive digest is not currentness",
                "foreign native status is not local authority",
            ],
        })
    return {
        "foreign_inputs": rows,
        "foreign_input_count": len(rows),
        "all_archive_digests_ok": all(row["archive_digest_ok"] for row in rows),
        "all_parent_manifests_present": all(row["parent_manifest_present"] for row in rows),
        "material_catalog_digest": digest({cube: FOREIGN_CATALOG[cube] for cube in imported_cubes(plan)}),
    }


def local_observation(plan: dict[str, Any]) -> dict[str, Any]:
    candidate = plan["candidate"]
    return {
        "import_id": f"harbor-f102-{plan['id'].lower()}",
        "observed_at": "2026-05-25T02:20:00-04:00",
        "observed_by": "Harbor import quarantine harness",
        "transport_surface": "uploaded archive / extracted tree / copied fragment / portal-callback reference",
        "material_rechecked_after_transport": candidate not in {"foreign_archive_digest_mismatch_accepted", "copied_fragment_without_parent_manifest"},
        "pasted_digest_only": False,
        "file_library_timestamp_used_as_freshness": False,
        "local_root_digest": release_root_digest(),
        "foreign_fragment_digests": [fragment_digest(cube, candidate) for cube in imported_cubes(plan)],
        "observation_non_promises": [
            "transport success is not import authority",
            "upload timestamp is not freshness",
            "callback return is not local adoption",
        ],
    }


def scope_translation(plan: dict[str, Any]) -> dict[str, Any]:
    candidate = plan["candidate"]
    relation = scope_relation(candidate)
    return {
        "relation": relation,
        "scope_map_present": candidate not in {"foreign_scope_widened_on_import", "cross_cube_total_order_without_clock_map"},
        "native_scope": "foreign cube fragment scope, not Harbor public-copy or correction-epoch scope",
        "harbor_scope": "F102 import quarantine packet + F101 lineage basis",
        "scope_map_digest": digest({"candidate": candidate, "relation": relation, "cubes": imported_cubes(plan)}),
        "widened_without_authority": candidate == "foreign_scope_widened_on_import",
        "single_public_badge_requested": candidate in {"foreign_warning_state_imported_as_public_badge", "mixed_cube_policy_majority_wins"},
        "semantic_supersession_requested": candidate == "slopos_append_order_imported_as_semantic_supersession",
        "scope_non_promises": [
            "foreign native scope is not Harbor scope",
            "cross-cube relation is not total order",
            "scope map is not compliance",
        ],
    }


def authority_quarantine(plan: dict[str, Any]) -> dict[str, Any]:
    candidate = plan["candidate"]
    expected = plan["expected"]
    flags = authority_flags(candidate, expected)
    return {
        "quarantine_required": True,
        "quarantine_state": flags["quarantine_state"],
        "status_import_rule": "foreign status may enter only as evidence subject to Harbor scope comparison",
        "flags": flags,
        "foreign_native_statuses": [FOREIGN_CATALOG[cube]["native_status"] for cube in imported_cubes(plan)],
        "allowed_harbor_uses": [FOREIGN_CATALOG[cube]["safe_harbor_use"] for cube in imported_cubes(plan)],
        "authority_non_promises": [
            "not inherited Harbor status",
            "not inherited currentness",
            "not inherited repair",
            "not inherited consent outcome",
            "not inherited delegation authority",
            "not inherited compliance",
        ],
    }


def lineage_bridge(plan: dict[str, Any]) -> dict[str, Any]:
    candidate = plan["candidate"]
    return {
        "prior_harbor_lineage_bundle_digest": f101_lineage_digest(),
        "bridge_digest": digest({
            "candidate": candidate,
            "foreign_fragments": [fragment_digest(cube, candidate) for cube in imported_cubes(plan)],
            "prior": f101_lineage_digest(),
        }),
        "cross_cube_clock_map_present": candidate != "cross_cube_total_order_without_clock_map",
        "cross_cube_total_order_attempt": candidate == "cross_cube_total_order_without_clock_map",
        "foreign_policy_majority_attempt": candidate == "mixed_cube_policy_majority_wins",
        "sealed_evidence_public_summary_limit": "sealed_foreign_packet_imported_by_digest" in candidate,
        "sealed_evidence_claims_public_truth": candidate == "sealed_foreign_evidence_imported_as_public_truth",
        "lineage_bridge_non_promises": [
            "bridge is not merged lineage",
            "bridge is not conflict-resolution engine",
            "bridge is not policy majority vote",
            "bridge is not source-owner closure",
        ],
    }


def recheck_plan(plan: dict[str, Any]) -> dict[str, Any]:
    candidate = plan["candidate"]
    stale = candidate == "stale_companion_revision_imported_as_historical_residue"
    repairish = candidate in {
        "helm_repair_trace_imported_with_harbor_scope_recheck",
        "helm_repair_trace_imported_as_completed_repair",
        "retention_window_imported_as_repair",
        "foreign_acknowledgement_imported_as_consumer_repair",
    }
    return {
        "recheck_required_before_status": True,
        "recheck_window": "required-before-any-public-status-admission",
        "historical_residue_only": stale,
        "stale_companion_revision": stale or candidate == "companion_revision_imported_as_freshness",
        "repair_evidence_requires_local_scope_check": repairish,
        "warning_or_badge_requires_harbor_recheck": candidate in {"foreign_warning_state_imported_as_public_badge", "mixed_cube_policy_majority_wins"},
        "retention_or_forgetting_requires_subject_digest_check": any(cube == "Schell" for cube in imported_cubes(plan)),
        "recheck_non_promises": [
            "recheck plan is not recheck pass",
            "historical residue is not currentness",
            "retention window is not repair",
        ],
    }


def verdict_summary(plan: dict[str, Any]) -> dict[str, Any]:
    candidate = plan["candidate"]
    expected = plan["expected"]
    reasons = [] if expected == "accepted" else [FAILURE_REASONS[candidate]]
    return {
        "expected": expected,
        "verdict_class": "admitted_foreign_lineage_material_with_status_quarantine" if expected == "accepted" else "refused_foreign_lineage_status_inheritance",
        "failure_reasons": reasons,
        "admitted_scope": "F102 import quarantine only" if expected == "accepted" else "none",
        "recheck_required_before_status": True,
        "inherited_status_admitted": False if expected == "accepted" else authority_flags(candidate, expected)["any_inherited_status"],
        "public_badge_allowed": False,
        "compliance_claim_allowed": False,
        "non_promises": NON_PROMOTION,
    }


def build_case(index: int, plan: dict[str, Any]) -> dict[str, Any]:
    case = {
        "index": index,
        "id": plan["id"],
        "candidate": plan["candidate"],
        "import.matrix": {
            "case_id": plan["id"],
            "candidate": plan["candidate"],
            "cubes": imported_cubes(plan),
            "expected": plan["expected"],
        },
        "foreign.material": foreign_material(plan),
        "local.observation": local_observation(plan),
        "scope.translation": scope_translation(plan),
        "authority.quarantine": authority_quarantine(plan),
        "lineage.bridge": lineage_bridge(plan),
        "recheck.plan": recheck_plan(plan),
        "verdict.summary": verdict_summary(plan),
    }
    case["row_digest"] = digest({key: case[key] for key in MEMBER_LABELS})
    return case


def build_bundle() -> dict[str, Any]:
    cases = [build_case(index, plan) for index, plan in enumerate(CASE_PLAN, start=1)]
    accepted_count = sum(1 for case in cases if case["verdict.summary"]["expected"] == "accepted")
    rejected_count = len(cases) - accepted_count
    bundle: dict[str, Any] = {
        "schema": SCHEMA,
        "version": VERSION,
        "source_revision": REVISION,
        "member_labels": MEMBER_LABELS,
        "foreign_catalog": FOREIGN_CATALOG,
        "cases": cases,
        "global": {
            "case_count": len(cases),
            "accepted_count": accepted_count,
            "rejected_count": rejected_count,
            "source_revision": REVISION,
            "prior_harbor_lineage_bundle_digest": f101_lineage_digest(),
            "release_root_digest": release_root_digest(),
            "coverage_claim": "deterministic F102 cross-cube import quarantine slice, not a companion trust root or cross-cube status API",
            "non_promotion": NON_PROMOTION,
        },
    }
    bundle["bundle_digest"] = digest({key: bundle[key] for key in ["schema", "version", "source_revision", "member_labels", "foreign_catalog", "cases", "global"]})
    return bundle


def main() -> None:
    parser = argparse.ArgumentParser(description="Emit Harbor cross-cube lineage import bundle")
    parser.add_argument("--out", type=Path, default=ROOT / "fixtures" / "harbor-cross-cube-lineage-import-bundle-v0.json")
    args = parser.parse_args()
    bundle = build_bundle()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(bundle, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(args.out)


if __name__ == "__main__":
    main()
