#!/usr/bin/env python3
"""Emit deterministic Harbor checker-provenance evidence.

F095 is about evidence concerning the checker observation itself.  It records
which checker source, harness source, fixture digest, invocation, guard set, and
self-test receipt produced the current observation, and it keeps reviewer
overrides smaller than the machine result.  The bundle is intentionally not a
checker registry, trust-root schema, CI status API, or durable conformance
claim.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]

SCHEMA = "harbor-checker-provenance-bundle"
VERSION = "0"
REVISION = "rev0100"

MEMBER_LABELS = [
    "checker.matrix",
    "checker.provenance",
    "fixture.pairing",
    "guard.state",
    "selftest.receipt",
    "reviewer.override",
    "verdict.summary",
]

NON_PROMOTION = [
    "no checker registry",
    "no CI status API",
    "no trust-root schema",
    "no automated reliance workflow",
    "no checker certification badge",
    "no self-recursive checker attestation",
    "no final SlopOS datacube shape",
]

CHECKERS: dict[str, dict[str, Any]] = {
    "crossing": {
        "checker_path": "tools/check_harbor_crossing_record_bundle.py",
        "harness_path": "tools/harbor_crossing_record_harness.py",
        "fixture_path": "fixtures/harbor-crossing-record-evidence-bundle-v0.json",
        "fixture_schema": "harbor-crossing-record-evidence-bundle",
        "fixture_revision": "rev0095",
        "role": "CrossingRecord v0 evidence checker",
        "guard_families": [
            "bundle_digest_binding",
            "member_label_order",
            "case_alignment",
            "subject_digest_binding",
            "rejected_no_record_id",
            "scope_widening_refusal",
            "route_family_non_promises",
            "forbidden_authority_phrase_scan",
        ],
    },
    "receipt": {
        "checker_path": "tools/check_harbor_transparency_receipt_bundle.py",
        "harness_path": "tools/harbor_transparency_receipt_harness.py",
        "fixture_path": "fixtures/harbor-transparency-provenance-receipt-bundle-v0.json",
        "fixture_schema": "harbor-transparency-provenance-receipt-bundle",
        "fixture_revision": "rev0096",
        "role": "transparency/provenance receipt import checker",
        "guard_families": [
            "bundle_digest_binding",
            "member_label_order",
            "case_alignment",
            "receipt_subject_binding",
            "currentness_upgrade_refusal",
            "redaction_scope_refusal",
            "issuer_compromise_refusal",
            "forbidden_authority_phrase_scan",
        ],
    },
    "disagreement": {
        "checker_path": "tools/check_harbor_verifier_disagreement_bundle.py",
        "harness_path": "tools/harbor_verifier_disagreement_harness.py",
        "fixture_path": "fixtures/harbor-verifier-disagreement-policy-epoch-bundle-v0.json",
        "fixture_schema": "harbor-verifier-disagreement-policy-epoch-bundle",
        "fixture_revision": "rev0097",
        "role": "verifier disagreement / policy epoch checker",
        "guard_families": [
            "bundle_digest_binding",
            "member_label_order",
            "case_alignment",
            "policy_digest_presence",
            "green_badge_refusal",
            "majority_vote_refusal",
            "unknown_currentness_refusal",
            "forbidden_authority_phrase_scan",
        ],
    },
    "property": {
        "checker_path": "tools/check_harbor_property_mutation_bundle.py",
        "harness_path": "tools/harbor_property_mutation_harness.py",
        "fixture_path": "fixtures/harbor-property-mutation-coverage-bundle-v0.json",
        "fixture_schema": "harbor-property-mutation-coverage-bundle",
        "fixture_revision": "rev0098",
        "role": "property/mutation coverage checker",
        "guard_families": [
            "bundle_digest_binding",
            "member_label_order",
            "case_alignment",
            "all_mutants_killed",
            "baseline_digest_binding",
            "operator_explainability",
            "non_promotion_guard",
        ],
    },
    "triage": {
        "checker_path": "tools/check_harbor_mutation_triage_bundle.py",
        "harness_path": "tools/harbor_mutation_triage_harness.py",
        "fixture_path": "fixtures/harbor-mutation-triage-bundle-v0.json",
        "fixture_schema": "harbor-mutation-triage-bundle",
        "fixture_revision": "rev0099",
        "role": "survived/equivalent/overstrict mutation triage checker",
        "guard_families": [
            "bundle_digest_binding",
            "member_label_order",
            "case_alignment",
            "unsafe_survivor_guarded",
            "equivalent_survivor_not_promoted",
            "overstrict_guard_not_relaxed",
            "metric_dashboard_refusal",
        ],
    },
}

CASE_PLAN: list[dict[str, Any]] = [
    {"id": "CP001", "checker": "crossing", "candidate": "current_checker_observation", "expected": "accepted"},
    {"id": "CP002", "checker": "receipt", "candidate": "current_checker_observation", "expected": "accepted"},
    {"id": "CP003", "checker": "disagreement", "candidate": "current_checker_observation", "expected": "accepted"},
    {"id": "CP004", "checker": "property", "candidate": "current_checker_observation", "expected": "accepted"},
    {"id": "CP005", "checker": "triage", "candidate": "current_checker_observation", "expected": "accepted"},
    {"id": "CP006", "checker": "crossing", "candidate": "disabled_guard_evidence", "expected": "rejected"},
    {"id": "CP007", "checker": "receipt", "candidate": "stale_fixture_checker_pairing", "expected": "rejected"},
    {"id": "CP008", "checker": "disagreement", "candidate": "missing_selftest_receipt", "expected": "rejected"},
    {"id": "CP009", "checker": "property", "candidate": "scoped_reviewer_override_packet", "expected": "accepted"},
    {"id": "CP010", "checker": "triage", "candidate": "unscoped_reviewer_override_attempt", "expected": "rejected"},
]


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def digest(value: Any) -> str:
    return "sha256:" + hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def file_digest(rel: str) -> str:
    data = (ROOT / rel).read_bytes()
    return "sha256:" + hashlib.sha256(data).hexdigest()


def load_fixture(rel: str) -> dict[str, Any]:
    return json.loads((ROOT / rel).read_text(encoding="utf-8"))


def run_checker(rel: str) -> dict[str, Any]:
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    proc = subprocess.run(
        [sys.executable, rel],
        cwd=ROOT,
        text=True,
        capture_output=True,
        env=env,
        check=False,
    )
    stdout = proc.stdout.strip()
    stderr = proc.stderr.strip()
    return {
        "command": ["python3", rel],
        "exit_code": proc.returncode,
        "stdout_digest": digest(stdout),
        "stderr_digest": digest(stderr),
        "stdout_last_line": stdout.splitlines()[-1] if stdout else "",
        "stderr_empty": stderr == "",
        "saw_passed_string": "passed" in stdout.lower(),
    }


def current_provenance(checker_id: str) -> dict[str, Any]:
    spec = CHECKERS[checker_id]
    fixture = load_fixture(spec["fixture_path"])
    return {
        "checker_id": checker_id,
        "role": spec["role"],
        "checker_path": spec["checker_path"],
        "checker_source_digest": file_digest(spec["checker_path"]),
        "harness_path": spec["harness_path"],
        "harness_source_digest": file_digest(spec["harness_path"]),
        "fixture_path": spec["fixture_path"],
        "fixture_file_digest": file_digest(spec["fixture_path"]),
        "fixture_bundle_digest": fixture.get("bundle_digest"),
        "fixture_schema": fixture.get("schema"),
        "fixture_version": fixture.get("version"),
        "fixture_revision": fixture.get("revision"),
        "expected_fixture_schema": spec["fixture_schema"],
        "expected_fixture_revision": spec["fixture_revision"],
        "checker_revision_basis": spec["fixture_revision"],
        "source_digest_algorithm": "sha256 over exact file bytes",
        "observation_is_about_checker_execution": True,
        "observation_is_not_semantic_truth": True,
    }


def make_guard_state(checker_id: str, candidate: str) -> dict[str, Any]:
    guards = {name: True for name in CHECKERS[checker_id]["guard_families"]}
    disabled: list[str] = []
    if candidate == "disabled_guard_evidence":
        disabled = [CHECKERS[checker_id]["guard_families"][-1]]
        for guard in disabled:
            guards[guard] = False
    return {
        "checker_id": checker_id,
        "required_guards": list(CHECKERS[checker_id]["guard_families"]),
        "guard_enabled": guards,
        "disabled_guards": disabled,
        "all_required_guards_enabled": not disabled,
        "guard_state_digest": digest(guards),
        "guard_state_is_observed_not_assumed": True,
    }


def make_pairing(prov: dict[str, Any], candidate: str) -> dict[str, Any]:
    paired = True
    stale_reason = "none"
    observed_fixture_revision = prov["fixture_revision"]
    observed_fixture_digest = prov["fixture_file_digest"]
    if candidate == "stale_fixture_checker_pairing":
        paired = False
        stale_reason = "fixture digest/revision was copied from a prior epoch and is not the fixture checked by this source digest"
        observed_fixture_revision = "rev0094"
        observed_fixture_digest = "sha256:" + "0" * 64
    return {
        "checker_id": prov["checker_id"],
        "checker_source_digest": prov["checker_source_digest"],
        "fixture_file_digest": observed_fixture_digest,
        "fixture_bundle_digest": prov["fixture_bundle_digest"],
        "fixture_revision_observed": observed_fixture_revision,
        "fixture_revision_expected": prov["expected_fixture_revision"],
        "schema_matches_checker_expectation": prov["fixture_schema"] == prov["expected_fixture_schema"],
        "revision_matches_checker_expectation": observed_fixture_revision == prov["expected_fixture_revision"],
        "paired": paired,
        "stale_pairing_refused": not paired,
        "stale_reason": stale_reason,
    }


def make_selftest(checker_id: str, candidate: str) -> dict[str, Any]:
    receipt = run_checker(CHECKERS[checker_id]["checker_path"])
    if candidate == "missing_selftest_receipt":
        return {
            "checker_id": checker_id,
            "selftest_status": "missing",
            "exit_code": None,
            "stdout_digest": None,
            "stderr_digest": None,
            "saw_passed_string": False,
            "missing_receipt_refused": True,
            "receipt_does_not_certify_checker_correctness": True,
        }
    return {
        "checker_id": checker_id,
        "selftest_status": "passed" if receipt["exit_code"] == 0 and receipt["saw_passed_string"] else "failed",
        "exit_code": receipt["exit_code"],
        "command": receipt["command"],
        "stdout_digest": receipt["stdout_digest"],
        "stderr_digest": receipt["stderr_digest"],
        "stdout_last_line": receipt["stdout_last_line"],
        "stderr_empty": receipt["stderr_empty"],
        "saw_passed_string": receipt["saw_passed_string"],
        "missing_receipt_refused": False,
        "receipt_does_not_certify_checker_correctness": True,
    }


def make_override(case_id: str, checker_id: str, candidate: str) -> dict[str, Any]:
    if candidate == "scoped_reviewer_override_packet":
        return {
            "override_present": True,
            "override_id": f"OVR-{case_id}",
            "reviewer_basis": "human reviewer may keep an overstrict canonicality guard for reproducible fixtures",
            "scope": "review note for this deterministic fixture only",
            "expires_after_revision": "rev0101",
            "does_not_change_checker_result": True,
            "does_not_mark_failure_as_success": True,
            "human_review_required": True,
            "requires_followthrough_if_repeated": True,
            "non_promises": [
                "not a trust root",
                "not a checker bypass",
                "not a CI pass",
                "not a global waiver",
            ],
        }
    if candidate == "unscoped_reviewer_override_attempt":
        return {
            "override_present": True,
            "override_id": f"OVR-{case_id}",
            "reviewer_basis": "operator says to count this as passed",
            "scope": "global",
            "expires_after_revision": None,
            "does_not_change_checker_result": False,
            "does_not_mark_failure_as_success": False,
            "human_review_required": True,
            "requires_followthrough_if_repeated": False,
            "non_promises": [],
        }
    return {
        "override_present": False,
        "override_id": None,
        "does_not_change_checker_result": True,
        "does_not_mark_failure_as_success": True,
        "human_review_required": False,
        "requires_followthrough_if_repeated": False,
        "non_promises": ["no override packet present"],
    }


def classify(candidate: str, guard: dict[str, Any], pairing: dict[str, Any], selftest: dict[str, Any], override: dict[str, Any]) -> tuple[bool, str]:
    if not guard["all_required_guards_enabled"]:
        return False, "disabled required guard evidence must be refused"
    if not pairing["paired"]:
        return False, "stale fixture/checker pairing must be refused"
    if selftest["selftest_status"] != "passed":
        return False, "checker observation without a passing self-test receipt must be refused"
    if override["override_present"]:
        if not override["does_not_change_checker_result"] or not override["does_not_mark_failure_as_success"]:
            return False, "reviewer override cannot change the machine result or mark failure as success"
        if not override.get("expires_after_revision") or override.get("scope") in {None, "global"}:
            return False, "reviewer override needs narrow scope and expiry"
    return True, "accepted as checker-observation evidence only"


def build_bundle() -> dict[str, Any]:
    members: dict[str, dict[str, Any]] = {label: {} for label in MEMBER_LABELS}

    for index, plan in enumerate(CASE_PLAN, start=1):
        case_id = plan["id"]
        checker_id = plan["checker"]
        candidate = plan["candidate"]
        prov = current_provenance(checker_id)
        guard = make_guard_state(checker_id, candidate)
        pairing = make_pairing(prov, candidate)
        selftest = make_selftest(checker_id, candidate)
        override = make_override(case_id, checker_id, candidate)
        admitted, reason = classify(candidate, guard, pairing, selftest, override)

        members["checker.matrix"][case_id] = {
            "index": index,
            "checker": checker_id,
            "candidate": candidate,
            "expected": plan["expected"],
            "role": CHECKERS[checker_id]["role"],
            "pressure": {
                "current_checker_observation": "current checker/source/fixture/self-test observation",
                "disabled_guard_evidence": "guard-state receipt tries to hide a disabled refusal guard",
                "stale_fixture_checker_pairing": "fixture digest/revision belongs to another checker epoch",
                "missing_selftest_receipt": "checker observation arrives without a self-test receipt",
                "scoped_reviewer_override_packet": "reviewer note is narrow, expiring, and cannot change the checker result",
                "unscoped_reviewer_override_attempt": "reviewer note tries to turn a failure into success",
            }[candidate],
        }
        members["checker.provenance"][case_id] = prov
        members["fixture.pairing"][case_id] = pairing
        members["guard.state"][case_id] = guard
        members["selftest.receipt"][case_id] = selftest
        members["reviewer.override"][case_id] = override
        members["verdict.summary"][case_id] = {
            "admitted": admitted,
            "expected_matched": ("accepted" if admitted else "rejected") == plan["expected"],
            "verdict_class": "checker_observation_packet" if admitted else "refused_counterfeit_checker_confidence",
            "reason": reason,
            "non_promotion_checked": True,
            "does_not_certify_subject_bundle_truth": True,
            "does_not_establish_ci_status": True,
        }

    accepted_count = sum(1 for row in members["verdict.summary"].values() if row["admitted"])
    rejected_count = len(CASE_PLAN) - accepted_count
    bundle: dict[str, Any] = {
        "schema": SCHEMA,
        "version": VERSION,
        "revision": REVISION,
        "purpose": "F095 checker provenance, guard-state, self-test, stale-pairing, and reviewer-override evidence; not a durable schema",
        "emitted_by": "tools/harbor_checker_provenance_harness.py",
        "members": members,
        "global": {
            "case_count": len(CASE_PLAN),
            "accepted_count": accepted_count,
            "rejected_count": rejected_count,
            "checker_count": len(CHECKERS),
            "subject_checkers": sorted(CHECKERS.keys()),
            "self_recursive_checker_attestation": "excluded; this bundle records prior checker stack evidence and is verified by its own checker separately",
            "non_promotion": NON_PROMOTION,
            "coverage_claim": "checker-provenance evidence only; not CI status, not a trust root, not a certification badge, not a checker registry",
        },
    }
    bundle["bundle_digest"] = digest({k: v for k, v in bundle.items() if k != "bundle_digest"})
    return bundle


def main() -> None:
    parser = argparse.ArgumentParser(description="Emit Harbor checker-provenance bundle")
    parser.add_argument("--emit-bundle", action="store_true", help="print the deterministic bundle as JSON")
    parser.add_argument("--write", type=Path, help="write the deterministic bundle to a fixture path")
    args = parser.parse_args()

    bundle = build_bundle()
    if args.write:
        args.write.write_text(json.dumps(bundle, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        return
    if args.emit_bundle or not args.write:
        print(json.dumps(bundle, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
