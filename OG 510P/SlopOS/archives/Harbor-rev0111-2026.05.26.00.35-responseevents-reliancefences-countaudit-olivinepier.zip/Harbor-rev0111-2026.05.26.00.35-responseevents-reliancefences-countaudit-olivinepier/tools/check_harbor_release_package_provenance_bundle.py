#!/usr/bin/env python3
"""Check the deterministic Harbor release-package provenance bundle."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

import harbor_release_package_provenance_harness as harness  # noqa: E402


def fail(message: str) -> None:
    print(message)
    raise SystemExit(1)


def expect(condition: bool, message: str) -> None:
    if not condition:
        fail(message)


def check_bundle(bundle: dict[str, Any]) -> None:
    expect(bundle.get("schema") == harness.SCHEMA, "Unexpected bundle schema")
    expect(bundle.get("version") == harness.VERSION, "Unexpected bundle version")
    expect(bundle.get("revision") == harness.REVISION, "Unexpected bundle revision")
    expect("durable schemas" in bundle.get("purpose", ""), "Purpose must refuse durable-schema promotion")
    expected_digest = harness.digest({k: v for k, v in bundle.items() if k != "bundle_digest"})
    expect(bundle.get("bundle_digest") == expected_digest, "Bundle digest drift")

    members = bundle.get("members")
    expect(isinstance(members, dict), "Bundle members must be an object")
    expect(list(members.keys()) == harness.MEMBER_LABELS, "Member labels/order drift")
    matrix = members["release.matrix"]
    expect(len(matrix) == len(harness.CASE_PLAN), "Release-package case count drift")
    for label in harness.MEMBER_LABELS[1:]:
        expect(list(members[label].keys()) == list(matrix.keys()), f"Case id/order drift in {label}")

    accepted = rejected = 0
    seen_indexes = []
    seen_candidates: set[str] = set()
    for case_id, row in matrix.items():
        seen_indexes.append(row.get("index"))
        candidate = row.get("candidate")
        expected = row.get("expected")
        seen_candidates.add(candidate)
        expect(expected in {"accepted", "rejected"}, f"{case_id}: invalid expected outcome")
        expect(candidate, f"{case_id}: missing candidate")
        expect(row.get("case_digest", "").startswith("sha256:"), f"{case_id}: case digest missing")

        root = members["root.identity"][case_id]
        inventory = members["file.inventory"][case_id]
        index = members["archive.index.check"][case_id]
        plan = members["package.plan"][case_id]
        env = members["build.environment"][case_id]
        boot = members["bootstrap.verification"][case_id]
        verdict = members["verdict.summary"][case_id]

        expect(root.get("current_revision") == harness.REVISION, f"{case_id}: root current revision drift")
        expect(root.get("root_name_is_release_scope_not_trust_root") is True, f"{case_id}: root trust-root refusal missing")
        expect(set(root.get("revision_fields", {}).values()) == {harness.REVISION}, f"{case_id}: revision fields drift")

        expect(inventory.get("actual_file_count") == inventory.get("manifest_file_count"), f"{case_id}: manifest file_count drift")
        expect(inventory.get("actual_file_list_digest", "").startswith("sha256:"), f"{case_id}: file list digest missing")
        expect(inventory.get("inventory_is_not_archive_signature") is True, f"{case_id}: inventory signature refusal missing")

        expect(index.get("actual_count") == inventory.get("actual_file_count"), f"{case_id}: index actual count drift")
        expect(index.get("index_file_digest", "").startswith("sha256:"), f"{case_id}: index digest missing")
        expect(index.get("archive_index_is_inventory_not_attestation") is True, f"{case_id}: index attestation refusal missing")

        for digest_field in ["package_script_digest", "release_zip_checker_digest"]:
            expect(plan.get(digest_field, "").startswith("sha256:"), f"{case_id}: {digest_field} missing")
        expect(plan.get("deterministic_plan_is_not_reproducible_build_claim") is True, f"{case_id}: reproducible-build refusal missing")

        expect(env.get("environment_capture", {}).get("python_implementation"), f"{case_id}: environment capture missing")
        expect(env.get("environment_capture_is_debugging_evidence") is True, f"{case_id}: env debug-evidence bit missing")
        expect(env.get("environment_capture_is_not_portability_proof") is True, f"{case_id}: env portability refusal missing")

        expect(boot.get("final_zip_digest_is_computed_after_packaging") is True, f"{case_id}: final zip digest boundary missing")
        expect(boot.get("final_zip_digest_recorded_inside_fixture") is False, f"{case_id}: fixture should not embed final zip digest")
        expect(boot.get("fixture_does_not_sign_or_certify_archive") is True, f"{case_id}: fixture signature refusal missing")

        expect(verdict.get("expected") == expected, f"{case_id}: expected echo drift")
        expect(verdict.get("expected_matched") is True, f"{case_id}: verdict did not match expected outcome")
        expect(verdict.get("non_promotion_checked") is True, f"{case_id}: non-promotion bit missing")
        expect(verdict.get("does_not_establish_archive_signature") is True, f"{case_id}: archive signature refusal missing")
        expect(verdict.get("does_not_establish_reproducible_build") is True, f"{case_id}: reproducible-build refusal missing")
        expect(verdict.get("does_not_establish_artifact_security") is True, f"{case_id}: security refusal missing")
        expect(verdict.get("does_not_establish_ci_status") is True, f"{case_id}: CI-status refusal missing")

        if verdict.get("admitted"):
            accepted += 1
            expect(expected == "accepted", f"{case_id}: admitted rejected candidate")
            expect(root.get("manifest_archive_matches_root") is True, f"{case_id}: admitted stale root")
            expect(inventory.get("embedded_release_zips") == [], f"{case_id}: admitted embedded zip")
            expect(inventory.get("generated_surface_missing") == [], f"{case_id}: admitted missing generated surface")
            expect(index.get("index_matches_actual") is True, f"{case_id}: admitted archive index drift")
            for key in ["stable_zip_timestamp", "uses_zip_deflated", "sorted_file_order", "filters_ds_store", "embedded_release_zip_guard_present", "archive_verifier_present"]:
                expect(plan.get(key) is True, f"{case_id}: admitted missing package-plan guard {key}")
            expect(boot.get("relies_on_internal_fixture_only") is False, f"{case_id}: admitted bootstrap self-trust")
            expect(boot.get("attestation_as_security_refused") is False, f"{case_id}: admitted security overclaim")
        else:
            rejected += 1
            expect(expected == "rejected", f"{case_id}: rejected accepted candidate")
            expect(verdict.get("verdict_class") == "refused_counterfeit_release_package_confidence", f"{case_id}: rejected class drift")
            expect(verdict.get("failure_reasons"), f"{case_id}: rejected case without failure reasons")

        if candidate == "archive_index_drift":
            expect(index.get("index_matches_actual") is False, f"{case_id}: archive-index drift candidate not drifting")
            expect("archive_index_drift" in verdict.get("failure_reasons", []), f"{case_id}: archive drift failure reason missing")
        elif candidate == "embedded_release_zip":
            expect(inventory.get("embedded_release_zips"), f"{case_id}: embedded zip candidate missing zip")
            expect("embedded_release_zip" in verdict.get("failure_reasons", []), f"{case_id}: embedded zip failure reason missing")
        elif candidate == "nondeterministic_zip_metadata":
            expect(plan.get("stable_zip_timestamp") is False, f"{case_id}: nondeterministic timestamp not represented")
            expect("package_plan_missing_stable_zip_timestamp" in verdict.get("failure_reasons", []), f"{case_id}: timestamp failure reason missing")
        elif candidate == "stale_release_root_name":
            expect(root.get("manifest_archive_matches_root") is False, f"{case_id}: stale root candidate still matches")
            expect("root_identity_drift" in verdict.get("failure_reasons", []), f"{case_id}: stale root failure reason missing")
        elif candidate == "generated_artifact_unlisted":
            expect(index.get("index_matches_actual") is False, f"{case_id}: generated artifact unlisted candidate still indexed")
            expect("archive_index_drift" in verdict.get("failure_reasons", []), f"{case_id}: generated unlisted failure reason missing")
        elif candidate == "bootstrap_self_trust_attempt":
            expect(boot.get("bootstrap_self_trust_refused") is True, f"{case_id}: bootstrap self-trust refusal missing")
            expect("bootstrap_self_trust_attempt" in verdict.get("failure_reasons", []), f"{case_id}: bootstrap failure reason missing")
        elif candidate == "attestation_as_security_claim":
            expect(boot.get("attestation_as_security_refused") is True, f"{case_id}: security overclaim refusal missing")
            expect("attestation_as_security_claim" in verdict.get("failure_reasons", []), f"{case_id}: attestation security failure reason missing")

    expect(seen_indexes == list(range(1, len(matrix) + 1)), "Release-package indexes must be gapless")
    expect(seen_candidates == {row["candidate"] for row in harness.CASE_PLAN}, "Not all F096 candidate classes are represented")

    global_ = bundle.get("global", {})
    expect(global_.get("case_count") == len(matrix), "Global case_count drift")
    expect(global_.get("accepted_count") == accepted, "Global accepted_count drift")
    expect(global_.get("rejected_count") == rejected, "Global rejected_count drift")
    expect(global_.get("source_file_count") == harness.read_json("RELEASE-MANIFEST.json").get("file_count"), "Global source file_count drift")
    expect(global_.get("package_script_digest") == harness.file_digest("tools/package_release.py"), "Package script digest drift")
    expect(global_.get("release_zip_checker_digest") == harness.file_digest("tools/check_harbor_release_zip.py"), "Zip checker digest drift")
    expect("not CI status" in global_.get("coverage_claim", ""), "Coverage claim must refuse CI status")
    expect("not embedded" in global_.get("final_zip_digest_boundary", "") or "not embedded" in json.dumps(global_), "Final zip digest boundary must be explicit")
    for refusal in harness.NON_PROMOTION:
        expect(refusal in global_.get("non_promotion", []), f"Global non-promotion list missing {refusal}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Check Harbor release-package provenance bundle")
    parser.add_argument("--fixture", type=Path, default=ROOT / "fixtures" / "harbor-release-package-provenance-bundle-v0.json")
    args = parser.parse_args()

    expected = harness.build_bundle()
    check_bundle(expected)
    if args.fixture.exists():
        actual = json.loads(args.fixture.read_text(encoding="utf-8"))
        expect(actual == expected, "Checked fixture does not match deterministic harness output")
    else:
        fail(f"Fixture missing: {args.fixture}")
    print("Harbor release-package provenance bundle check passed")


if __name__ == "__main__":
    main()
