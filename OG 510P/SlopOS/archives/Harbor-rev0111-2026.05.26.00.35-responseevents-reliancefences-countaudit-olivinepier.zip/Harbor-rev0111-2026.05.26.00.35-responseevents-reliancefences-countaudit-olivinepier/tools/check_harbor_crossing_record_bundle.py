#!/usr/bin/env python3
"""Check the deterministic Harbor CrossingRecord evidence bundle."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

import harbor_crossing_record_harness as harness  # noqa: E402


def fail(message: str) -> None:
    print(message)
    raise SystemExit(1)


def expect(condition: bool, message: str) -> None:
    if not condition:
        fail(message)


FORBIDDEN_AUTHORITY_PHRASES = {
    "global truth",
    "semantic truth",
    "compliance truth",
    "authority truth",
    "trusted content",
    "fresh now",
    "global authority",
}


def nested_contains_key(value: Any, forbidden: set[str]) -> bool:
    if isinstance(value, dict):
        for key, child in value.items():
            if key in forbidden:
                return True
            if nested_contains_key(child, forbidden):
                return True
    elif isinstance(value, list):
        return any(nested_contains_key(child, forbidden) for child in value)
    return False


def nested_contains_forbidden_authority_phrase(value: Any) -> bool:
    if isinstance(value, dict):
        return any(nested_contains_forbidden_authority_phrase(child) for child in value.values())
    if isinstance(value, list):
        return any(nested_contains_forbidden_authority_phrase(child) for child in value)
    if isinstance(value, str):
        lower = value.lower().replace("_", " ")
        if lower.startswith("not ") or lower.startswith("no ") or " not " in lower:
            return False
        return any(phrase in lower for phrase in FORBIDDEN_AUTHORITY_PHRASES)
    return False


def check_bundle(bundle: dict[str, Any]) -> None:
    expect(bundle.get("schema") == harness.SCHEMA, "Unexpected bundle schema")
    expect(bundle.get("version") == harness.VERSION, "Unexpected bundle version")
    expect(bundle.get("revision") == harness.REVISION, "Unexpected bundle revision")
    expect(bundle.get("purpose", "").endswith("not a durable schema"), "Purpose must refuse durable schema promotion")
    expected_digest = harness.digest({k: v for k, v in bundle.items() if k != "bundle_digest"})
    expect(bundle.get("bundle_digest") == expected_digest, "Bundle digest drift")

    members = bundle.get("members")
    expect(isinstance(members, dict), "Bundle members must be an object")
    expect(list(members.keys()) == harness.MEMBER_LABELS, "Member labels/order drift")

    case_ids = list(members["case.matrix"].keys())
    expect(len(case_ids) == 10, "F090 bundle must keep ten stable cases")
    for label in harness.MEMBER_LABELS[1:]:
        expect(list(members[label].keys()) == case_ids, f"Case ids drift in {label}")

    accepted = 0
    rejected = 0
    for cid in case_ids:
        matrix = members["case.matrix"][cid]
        expected = matrix["expected"]
        external = members["input.external_evidence"][cid]
        candidate = members["input.crossing_record"][cid]
        comparison = members["scope.comparison"][cid]
        admission = members["output.admission"][cid]
        aftermath = members["output.aftermath"][cid]
        verdict = members["verdict.summary"][cid]

        expect(comparison.get("verdict") in harness.ALLOWED_SCOPE_VERDICTS, f"{cid}: invalid scope verdict")
        expect(comparison.get("refused_widening") is True, f"{cid}: scope comparison must refuse widening")
        expect(verdict.get("record_digest") == harness.digest(candidate), f"{cid}: record digest mismatch")
        expect(verdict.get("non_promotion_checked") is True, f"{cid}: non-promotion bit missing")

        if expected == "accepted":
            accepted += 1
            record = candidate
            expect(admission.get("decision") == "accepted", f"{cid}: accepted case not admitted")
            expect(set(record.keys()) == set(harness.RECORD_TOP_KEYS), f"{cid}: CrossingRecord v0 top-level key drift")
            expect(record["subject"]["digest"] == external["subject_digest"], f"{cid}: subject digest not bound to external evidence")
            route_family = record["route"]["route_family"]
            expect(route_family == external["route_family"], f"{cid}: route family mismatch")
            expect(route_family in harness.ROUTE_GUARDS, f"{cid}: unknown route family")
            expect(record["outcome"]["class"] not in harness.FORBIDDEN_OUTCOME_CLASSES, f"{cid}: forbidden outcome class")
            non_promises = set(record["outcome"].get("non_promises", []))
            expect(harness.ROUTE_GUARDS[route_family].issubset(non_promises), f"{cid}: missing route-specific non-promises")
            expect(isinstance(record["admission"].get("visible_to_user"), bool), f"{cid}: visible_to_user must be boolean")
            expect(aftermath.get("durable_effect") == "bounded_crossing_residue_only", f"{cid}: accepted aftermath overclaims")
            expect(verdict.get("admitted") is True, f"{cid}: verdict admitted bit drift")
            expect(not nested_contains_key(record, {"ambient_truth", "global_truth", "compliance_truth"}), f"{cid}: ambient/global truth key leaked")
            expect(not nested_contains_forbidden_authority_phrase(record), f"{cid}: forbidden authority/truth phrase leaked")
        elif expected == "rejected":
            rejected += 1
            expect(admission.get("decision") == "rejected", f"{cid}: rejected case admitted")
            expect(verdict.get("admitted") is False, f"{cid}: verdict admitted bit drift")
            expect(verdict.get("reject_reason") == admission.get("reason"), f"{cid}: reject reason drift")
            expect(aftermath.get("record_id") is None, f"{cid}: rejected case emitted a record id")
            expect("no_crossing_record_emitted" in aftermath.get("non_promises", []), f"{cid}: rejection lacks no-record non-promise")
            rec = candidate.get("candidate")
            expect(isinstance(rec, dict), f"{cid}: rejected case must carry candidate only")
            if cid == "reject-malformed-envelope-ambient-field":
                expect("ambient_truth" in rec, f"{cid}: ambient-field fixture lost its mutation")
            if cid == "reject-subject-digest-mismatch":
                expect(rec["subject"]["digest"] != external["subject_digest"], f"{cid}: digest mismatch fixture no longer mismatches")
            if cid == "reject-global-resolution-overclaim":
                expect(rec["outcome"]["class"] in harness.FORBIDDEN_OUTCOME_CLASSES, f"{cid}: global-resolution fixture lost forbidden class")
            if cid == "reject-latest-wins-scope-substitution":
                expect(comparison.get("verdict") == "rejected_scope_substitution", f"{cid}: latest-wins fixture must reject scope substitution")
        else:
            fail(f"{cid}: invalid expected outcome {expected!r}")

    global_ = bundle.get("global", {})
    expect(global_.get("case_count") == len(case_ids), "Global case_count drift")
    expect(global_.get("accepted_count") == accepted, "Global accepted_count drift")
    expect(global_.get("rejected_count") == rejected, "Global rejected_count drift")
    expect("no durable CrossingRecord schema" in global_.get("non_promotion", []), "Global non-promotion list missing schema refusal")


def main() -> None:
    parser = argparse.ArgumentParser(description="Check Harbor CrossingRecord evidence bundle")
    parser.add_argument("--fixture", type=Path, default=ROOT / "fixtures" / "harbor-crossing-record-evidence-bundle-v0.json")
    args = parser.parse_args()

    expected = harness.build_bundle()
    check_bundle(expected)

    if args.fixture.exists():
        actual = json.loads(args.fixture.read_text(encoding="utf-8"))
        expect(actual == expected, "Checked fixture does not match deterministic harness output")
    else:
        fail(f"Fixture missing: {args.fixture}")

    print("Harbor CrossingRecord bundle check passed")


if __name__ == "__main__":
    main()
