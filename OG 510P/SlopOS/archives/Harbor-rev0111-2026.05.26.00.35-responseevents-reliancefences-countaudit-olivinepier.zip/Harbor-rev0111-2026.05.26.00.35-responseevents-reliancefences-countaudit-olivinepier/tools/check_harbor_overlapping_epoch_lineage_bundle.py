#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import harbor_overlapping_epoch_lineage_harness as harness  # noqa: E402


def fail(message: str) -> None:
    print(message)
    raise SystemExit(1)


def expect(condition: bool, message: str) -> None:
    if not condition:
        fail(message)


def check_bundle(bundle: dict[str, Any]) -> None:
    expect(bundle.get("schema") == harness.SCHEMA, "Unexpected bundle schema")
    expect(bundle.get("version") == harness.VERSION, "Unexpected bundle version")
    expect(bundle.get("revision") == harness.REVISION, "Unexpected bundle revision")
    expect(bundle.get("purpose", "").endswith("not a durable schema"), "Purpose must refuse durable schema promotion")
    expected_digest = harness.digest({k: v for k, v in bundle.items() if k != "bundle_digest"})
    expect(bundle.get("bundle_digest") == expected_digest, "Bundle digest drift")

    members = bundle.get("members")
    expect(isinstance(members, dict), "Bundle members must be an object")
    expect(list(members.keys()) == harness.MEMBER_LABELS, "Member labels/order drift")
    matrix = members["lineage.matrix"]
    expect(len(matrix) == len(harness.CASE_PLAN), "F101 bundle case count drift")
    for label in harness.MEMBER_LABELS[1:]:
        expect(list(members[label].keys()) == list(matrix.keys()), f"Case id/order drift in {label}")

    accepted = 0
    rejected = 0
    seen_indexes: list[int] = []
    seen_candidates: set[str] = set()
    for case_id, row in matrix.items():
        seen_indexes.append(row.get("index"))
        candidate = row.get("candidate")
        expected = row.get("expected")
        seen_candidates.add(candidate)
        expect(expected in {"accepted", "rejected"}, f"{case_id}: invalid expected outcome")
        expect(row.get("digest") == harness.digest({"index": row.get("index"), "candidate": candidate, "expected": expected}), f"{case_id}: row digest drift")

        epoch = members["source.epoch"][case_id]
        lineage = members["derivative.lineage"][case_id]
        action = members["repair.action"][case_id]
        scope = members["scope.reconciliation"][case_id]
        window = members["currentness.window"][case_id]
        state = members["consumer.state"][case_id]
        verdict = members["verdict.summary"][case_id]

        expect(epoch.get("subject_source_digest") == harness.source_material_digest(), f"{case_id}: source material digest drift")
        expect(epoch.get("retention_bundle_digest") == harness.retention_bundle_digest(), f"{case_id}: retention bundle digest drift")
        expect(epoch.get("epoch_order_is_not_global_truth") is True, f"{case_id}: epoch/global-truth refusal missing")
        expect(epoch.get("epoch_order_is_not_source_owner_closure") is True, f"{case_id}: epoch/source-owner refusal missing")
        expect(isinstance(epoch.get("epochs"), list) and len(epoch["epochs"]) >= 2, f"{case_id}: epoch list too small")
        for e in epoch["epochs"]:
            expect(isinstance(e.get("digest"), str) and e["digest"].startswith("sha256:"), f"{case_id}: epoch digest missing")
            expect(e.get("epoch_id"), f"{case_id}: epoch id missing")
            expect(e.get("scope"), f"{case_id}: epoch scope missing")

        expect(lineage.get("lineage_graph_has_subject_digest") is True, f"{case_id}: lineage subject digest missing")
        expect(lineage.get("lineage_is_not_original_source") is True, f"{case_id}: lineage/original refusal missing")
        expect(lineage.get("lineage_is_not_global_downstream_state") is True, f"{case_id}: lineage/global-state refusal missing")
        expect(isinstance(lineage.get("lineage_edges"), list) and lineage["lineage_edges"], f"{case_id}: lineage edges missing")
        expect(isinstance(lineage.get("current_candidate_digest"), str) and lineage["current_candidate_digest"].startswith("sha256:"), f"{case_id}: current candidate digest missing")

        expect(action.get("lineage_action_is_not_repair_attestation") is True, f"{case_id}: repair-attestation refusal missing")
        expect(scope.get("scope_comparison_is_not_authority") is True, f"{case_id}: scope-authority refusal missing")
        expect(window.get("currentness_is_scoped_to_epoch_and_fields") is True, f"{case_id}: scoped currentness bit missing")
        expect(window.get("old_receipt_is_not_current_repair") is True, f"{case_id}: old-receipt currentness refusal missing")
        expect(state.get("consumer_state_is_not_compliance") is True, f"{case_id}: consumer/compliance refusal missing")
        expect(state.get("consumer_state_is_not_all_derivatives_current") is True, f"{case_id}: consumer/all-current refusal missing")

        expect(verdict.get("candidate") == candidate, f"{case_id}: verdict candidate drift")
        expect(verdict.get("expected_matched") is True, f"{case_id}: verdict did not match expected outcome")
        expect(verdict.get("must_preserve_intermediate_history") is True, f"{case_id}: history preservation bit missing")
        for phrase in ["not latest-wins", "not oldest-receipt-wins", "not global repair", "not all derivatives current", "not source-owner closure", "not compliance", "not public green badge"]:
            expect(phrase in verdict.get("non_promises", []), f"{case_id}: missing non-promise {phrase}")

        if verdict.get("admitted"):
            accepted += 1
            expect(expected == "accepted", f"{case_id}: admitted rejected candidate")
            expect(not verdict.get("failure_reasons"), f"{case_id}: accepted case carries failure reasons")
            expect(state.get("public_badge_posture") == "scoped", f"{case_id}: accepted case carries green/global badge")
            expect(lineage.get("digest_reused_across_epochs") is False, f"{case_id}: accepted case reused derivative digest")
            expect(lineage.get("cycle_detected") is False, f"{case_id}: accepted case has cycle")
            if candidate == "linear_epoch_chain_repair_to_latest_scoped":
                expect(verdict.get("may_claim_current_for_scope") is True, f"{case_id}: linear currentness not scoped-current")
                expect(verdict.get("current_scope") == "epoch-b named fields only", f"{case_id}: linear current scope drift")
            elif candidate == "epoch_a_repair_retained_history_after_epoch_b":
                expect(window.get("epoch_a_window") == "history_only", f"{case_id}: epoch-a not history-only")
                expect(verdict.get("may_claim_current_for_scope") is False, f"{case_id}: history-only case claimed current")
            elif candidate == "disjoint_corrections_coexist_without_latest_wins":
                expect(scope.get("relation") == "disjoint", f"{case_id}: disjoint relation drift")
                expect(scope.get("latest_wins_attempt") is False, f"{case_id}: latest-wins admitted")
            elif candidate == "overlapping_corrections_split_derivative_state_by_scope":
                expect(scope.get("relation") == "partial_overlap", f"{case_id}: split relation drift")
                expect(state.get("mixed_epochs_visible") is True, f"{case_id}: mixed epochs hidden")
            elif candidate == "rollback_epoch_reopens_prior_repair_with_history":
                expect(action.get("rollback_recheck_required") is True and action.get("rollback_recheck_performed") is True, f"{case_id}: rollback recheck posture drift")
                expect(state.get("warning_history_preserved") is True, f"{case_id}: rollback history missing")
            elif candidate == "partial_subset_repaired_epoch_b_others_epoch_a_history":
                expect(state.get("mixed_epochs_visible") is True, f"{case_id}: partial subset mixed state hidden")
                expect(verdict.get("current_scope") == "split by scope and derivative subset", f"{case_id}: partial current scope drift")
            elif candidate == "consumer_patch_rebased_onto_epoch_b_with_delta_map":
                expect(action.get("rebase_map_present") is True, f"{case_id}: rebase map missing")
                expect(action.get("base_epoch") == "epoch-b", f"{case_id}: rebase base epoch drift")
            elif candidate == "stale_epoch_a_ack_preserved_as_residue":
                expect(state.get("acknowledgement_epoch") == "epoch-a", f"{case_id}: ack epoch drift")
                expect(verdict.get("may_claim_current_for_scope") is False, f"{case_id}: stale ack claimed current")
            elif candidate == "conflicting_external_epoch_requires_dispute_state":
                expect(epoch.get("dispute_epoch_present") is True, f"{case_id}: dispute epoch absent")
                expect(state.get("state_class") == "disputed_not_repaired", f"{case_id}: dispute state drift")
                expect(verdict.get("must_recheck_before_current_status") is True, f"{case_id}: dispute lacks recheck guard")
            elif candidate == "epoch_b_supersedes_named_fields_only":
                expect(scope.get("named_fields_only") is True, f"{case_id}: named-field scope absent")
                expect(scope.get("whole_artifact_current_claim") is False, f"{case_id}: named fields widened to whole artifact")
        else:
            rejected += 1
            expect(expected == "rejected", f"{case_id}: rejected accepted candidate")
            expect(verdict.get("verdict_class") == "refused_counterfeit_epoch_lineage_confidence", f"{case_id}: rejected verdict class drift")
            expect(verdict.get("failure_reasons"), f"{case_id}: rejected case lacks failure reason")

        if candidate == "latest_epoch_wins_without_scope_overlap_map":
            expect("latest_epoch_wins_without_scope_overlap_map" in verdict["failure_reasons"], f"{case_id}: latest-wins reason absent")
            expect(scope.get("overlap_map_present") is False, f"{case_id}: missing overlap-map not represented")
        elif candidate == "epoch_a_repair_claims_current_after_epoch_b_overlap":
            expect("stale_epoch_a_currentness_overclaim" in verdict["failure_reasons"], f"{case_id}: epoch-a stale reason absent")
            expect(window.get("epoch_a_window") == "history_only", f"{case_id}: epoch-a not history-only")
        elif candidate == "rollback_erases_intermediate_warning_history":
            expect("rollback_erases_intermediate_history" in verdict["failure_reasons"], f"{case_id}: rollback history reason absent")
            expect(state.get("warning_history_preserved") is False, f"{case_id}: rollback history loss not represented")
        elif candidate == "disjoint_correction_marked_conflict":
            expect("disjoint_scope_false_conflict" in verdict["failure_reasons"], f"{case_id}: false conflict reason absent")
            expect(scope.get("relation") == "disjoint" and scope.get("disjoint_marked_conflict") is True, f"{case_id}: false conflict not represented")
        elif candidate == "overlapping_correction_merged_without_delta_map":
            expect("overlap_merge_missing_delta_map" in verdict["failure_reasons"], f"{case_id}: missing delta reason absent")
            expect(action.get("delta_map_present") is False, f"{case_id}: missing delta map not represented")
        elif candidate == "consumer_patch_applied_to_wrong_epoch_base":
            expect("consumer_patch_wrong_epoch_base" in verdict["failure_reasons"], f"{case_id}: wrong base reason absent")
            expect(action.get("base_epoch") == "epoch-a", f"{case_id}: wrong base not represented")
        elif candidate == "ack_for_epoch_a_counts_for_epoch_b":
            expect("acknowledgement_epoch_mismatch" in verdict["failure_reasons"], f"{case_id}: ack mismatch reason absent")
            expect(action.get("ack_counts_for_target_epoch_only") is False, f"{case_id}: ack overclaim not represented")
        elif candidate == "derivative_digest_reused_across_epochs":
            expect("derivative_digest_reused_across_epochs" in verdict["failure_reasons"], f"{case_id}: digest reuse reason absent")
            expect(lineage.get("digest_reused_across_epochs") is True, f"{case_id}: digest reuse not represented")
        elif candidate == "missing_epoch_order_or_clock_basis":
            expect("missing_epoch_order_or_clock_basis" in verdict["failure_reasons"], f"{case_id}: missing clock reason absent")
            expect(epoch.get("clock_basis_present") is False and window.get("clock_basis_present") is False, f"{case_id}: missing clock not represented")
        elif candidate == "parallel_epochs_total_ordered_without_authority":
            expect("parallel_epochs_total_order_without_authority" in verdict["failure_reasons"], f"{case_id}: parallel order reason absent")
            expect(epoch.get("parallel_epochs_total_order_attempt") is True, f"{case_id}: parallel order attempt not represented")
        elif candidate == "field_scope_widened_to_whole_artifact":
            expect("field_scope_widened_to_whole_artifact" in verdict["failure_reasons"], f"{case_id}: scope widening reason absent")
            expect(scope.get("field_scope_widened_to_artifact") is True, f"{case_id}: field-scope widening not represented")
        elif candidate == "stale_subset_marked_global_current":
            expect("stale_subset_marked_global_current" in verdict["failure_reasons"], f"{case_id}: stale subset reason absent")
            expect(scope.get("whole_artifact_current_claim") is True, f"{case_id}: global-current claim not represented")
        elif candidate == "dispute_epoch_treated_as_repair":
            expect("dispute_epoch_treated_as_repair" in verdict["failure_reasons"], f"{case_id}: dispute-as-repair reason absent")
            expect(scope.get("relation") == "conflict_unresolved", f"{case_id}: conflict relation absent")
        elif candidate == "source_owner_closure_overrides_lineage":
            expect("source_owner_closure_overrides_lineage" in verdict["failure_reasons"], f"{case_id}: source-owner reason absent")
            expect(state.get("source_owner_closure_attempt") is True, f"{case_id}: source-owner attempt not represented")
        elif candidate == "retention_expiry_ignored_in_lineage_currentness":
            expect("retention_expiry_ignored" in verdict["failure_reasons"], f"{case_id}: expiry ignored reason absent")
            expect(action.get("retention_expiry_considered") is False, f"{case_id}: ignored expiry not represented")
        elif candidate == "public_badge_green_across_mixed_epochs":
            expect("green_badge_across_mixed_epochs" in verdict["failure_reasons"], f"{case_id}: badge reason absent")
            expect(state.get("public_badge_posture") == "green_global", f"{case_id}: green badge not represented")
        elif candidate == "material_rollback_without_recheck":
            expect("material_rollback_without_recheck" in verdict["failure_reasons"], f"{case_id}: rollback no-recheck reason absent")
            expect(action.get("rollback_recheck_required") is True and action.get("rollback_recheck_performed") is False, f"{case_id}: rollback no-recheck not represented")
        elif candidate == "cycle_in_lineage_graph":
            expect("cycle_in_lineage_graph" in verdict["failure_reasons"], f"{case_id}: cycle reason absent")
            expect(epoch.get("contains_cycle") is True and lineage.get("cycle_detected") is True, f"{case_id}: cycle not represented")

    expect(seen_indexes == list(range(1, len(matrix) + 1)), "F101 indexes must be gapless")
    expect(seen_candidates == {plan["candidate"] for plan in harness.CASE_PLAN}, "Not all F101 candidate classes are represented")

    global_ = bundle.get("global", {})
    expect(global_.get("case_count") == len(matrix), "Global case_count drift")
    expect(global_.get("accepted_count") == accepted, "Global accepted_count drift")
    expect(global_.get("rejected_count") == rejected, "Global rejected_count drift")
    expect(global_.get("source_revision") == harness.REVISION, "Global source revision drift")
    expect(global_.get("retention_bundle_digest") == harness.retention_bundle_digest(), "Global retention bundle digest drift")
    expect("not a correction registry" in global_.get("coverage_claim", ""), "Coverage claim must refuse registry promotion")
    for refusal in harness.NON_PROMOTION:
        expect(refusal in global_.get("non_promotion", []), f"Global non-promotion list missing {refusal}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Check Harbor overlapping correction-epoch lineage bundle")
    parser.add_argument("--fixture", type=Path, default=ROOT / "fixtures" / "harbor-overlapping-correction-lineage-bundle-v0.json")
    args = parser.parse_args()

    expected = harness.build_bundle()
    check_bundle(expected)
    if args.fixture.exists():
        actual = json.loads(args.fixture.read_text(encoding="utf-8"))
        expect(actual == expected, "Checked fixture does not match deterministic harness output")
    else:
        fail(f"Fixture missing: {args.fixture}")
    print("Harbor overlapping correction-epoch lineage bundle check passed")


if __name__ == "__main__":
    main()
