#!/usr/bin/env python3
from __future__ import annotations

import importlib
import runpy
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / "tools"))

from harbor_executable_surface_registry import CHECKER_MODULES  # noqa: E402


def main() -> None:
    original_argv = sys.argv[:]
    try:
        for module_name in CHECKER_MODULES:
            module = importlib.import_module(module_name)
            sys.argv = [str(ROOT / "tools" / f"{module_name}.py")]
            module.main()
        sys.argv = [str(ROOT / "tools" / "check_repo_hygiene.py")]
        runpy.run_path(str(ROOT / "tools" / "check_repo_hygiene.py"), run_name="__main__")
    finally:
        sys.argv = original_argv


if __name__ == "__main__":
    main()
