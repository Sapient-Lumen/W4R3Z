#!/usr/bin/env python3
"""Emit deterministic Harbor user-visible explanation bundle evidence.

F105 starts after Harbor can propagate revocation overlays to public and local
surfaces.  The next pressure is the human-facing explanation layer: wording,
labels, reason codes, history links, localization/accessibility variants, and
action affordances must help a person understand the scoped overlay without
turning that explanation into a green/red badge, compliance result, legal
finding, proof of read/application, or global downstream repair.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

from harbor_bundle_common import digest, file_digest  # noqa: E402
import harbor_revocation_overlay_propagation_harness as f104  # noqa: E402

SCHEMA = "harbor-user-visible-explanation-bundle"
VERSION = "0"
REVISION = "rev0111"

MEMBER_LABELS = [
    "overlay.input",
    "audience.context",
    "explanation.copy",
    "reason.code",
    "action.affordance",
    "access.localization",
    "history.trace",
    "verdict.summary",
]

NON_PROMOTION = [
    "no public badge workflow",
    "no compliance workflow",
    "no legal finding",
    "no global downstream repair",
    "no notification read guarantee",
    "no accessibility conformance claim",
    "no localization equivalence guarantee",
    "no explanation API",
    "no final SlopOS datacube shape",
]

CASE_PLAN: list[dict[str, Any]] = [
    {"id": "UX001", "candidate": "public_copy_scope_digest_plain_card", "surface": "public_copy", "expected": "accepted"},
    {"id": "UX002", "candidate": "mirror_stale_recheck_explanation", "surface": "mirror", "expected": "accepted"},
    {"id": "UX003", "candidate": "generated_summary_carries_overlay_basis", "surface": "generated_summary", "expected": "accepted"},
    {"id": "UX004", "candidate": "consumer_notice_delivery_vs_read_split", "surface": "consumer_notice", "expected": "accepted"},
    {"id": "UX005", "candidate": "local_index_result_warning_snippet", "surface": "local_index", "expected": "accepted"},
    {"id": "UX006", "candidate": "warning_card_split_state_plain_language", "surface": "warning_card", "expected": "accepted"},
    {"id": "UX007", "candidate": "sealed_overlay_public_safe_summary", "surface": "sealed_notice_summary", "expected": "accepted"},
    {"id": "UX008", "candidate": "mixed_cube_incomparable_explanations", "surface": "multi_cube_public_card", "expected": "accepted"},
    {"id": "UX009", "candidate": "localized_variant_bound_to_source_digest", "surface": "localized_card", "expected": "accepted"},
    {"id": "UX010", "candidate": "accessible_status_message_non_color_only", "surface": "status_message", "expected": "accepted"},
    {"id": "UX011", "candidate": "machine_reason_paired_with_user_copy", "surface": "problem_detail", "expected": "accepted"},
    {"id": "UX012", "candidate": "appeal_recheck_affordance_without_repair", "surface": "action_panel", "expected": "accepted"},
    {"id": "UX013", "candidate": "green_badge_only_display", "surface": "public_copy", "expected": "rejected"},
    {"id": "UX014", "candidate": "red_global_failure_banner", "surface": "warning_card", "expected": "rejected"},
    {"id": "UX015", "candidate": "closure_language_without_scope", "surface": "public_copy", "expected": "rejected"},
    {"id": "UX016", "candidate": "prior_falsehood_or_negligence_claim", "surface": "public_copy", "expected": "rejected"},
    {"id": "UX017", "candidate": "color_only_indicator", "surface": "status_message", "expected": "rejected"},
    {"id": "UX018", "candidate": "missing_scope_map", "surface": "public_copy", "expected": "rejected"},
    {"id": "UX019", "candidate": "missing_source_overlay_digest", "surface": "generated_summary", "expected": "rejected"},
    {"id": "UX020", "candidate": "localized_variant_widens_scope", "surface": "localized_card", "expected": "rejected"},
    {"id": "UX021", "candidate": "generated_summary_as_source_equivalent", "surface": "generated_summary", "expected": "rejected"},
    {"id": "UX022", "candidate": "notice_delivery_as_read_applied", "surface": "consumer_notice", "expected": "rejected"},
    {"id": "UX023", "candidate": "repair_all_downstream_action", "surface": "action_panel", "expected": "rejected"},
    {"id": "UX024", "candidate": "hide_prior_history", "surface": "public_copy", "expected": "rejected"},
    {"id": "UX025", "candidate": "sealed_detail_disclosure", "surface": "sealed_notice_summary", "expected": "rejected"},
    {"id": "UX026", "candidate": "timestamp_as_currentness", "surface": "local_index", "expected": "rejected"},
    {"id": "UX027", "candidate": "machine_code_only_user_message", "surface": "problem_detail", "expected": "rejected"},
    {"id": "UX028", "candidate": "status_message_without_programmatic_label", "surface": "status_message", "expected": "rejected"},
    {"id": "UX029", "candidate": "translation_without_provenance", "surface": "localized_card", "expected": "rejected"},
    {"id": "UX030", "candidate": "single_sentence_mixed_overlay_collapse", "surface": "multi_cube_public_card", "expected": "rejected"},
    {"id": "UX031", "candidate": "confidence_percentage_as_truth", "surface": "warning_card", "expected": "rejected"},
    {"id": "UX032", "candidate": "legal_advice_language", "surface": "action_panel", "expected": "rejected"},
]

FAILURE_REASONS = {
    "green_badge_only_display": "badge_only_display",
    "red_global_failure_banner": "global_failure_banner",
    "closure_language_without_scope": "closure_language_without_scope",
    "prior_falsehood_or_negligence_claim": "prior_falsehood_or_negligence_claim",
    "color_only_indicator": "color_only_indicator",
    "missing_scope_map": "missing_scope_map",
    "missing_source_overlay_digest": "missing_source_overlay_digest",
    "localized_variant_widens_scope": "localized_scope_widening",
    "generated_summary_as_source_equivalent": "summary_as_source_equivalent",
    "notice_delivery_as_read_applied": "delivery_as_read_applied",
    "repair_all_downstream_action": "action_as_global_repair",
    "hide_prior_history": "history_hidden",
    "sealed_detail_disclosure": "sealed_detail_disclosure",
    "timestamp_as_currentness": "timestamp_as_currentness",
    "machine_code_only_user_message": "machine_code_without_user_copy",
    "status_message_without_programmatic_label": "missing_programmatic_label",
    "translation_without_provenance": "translation_without_provenance",
    "single_sentence_mixed_overlay_collapse": "mixed_overlay_collapse",
    "confidence_percentage_as_truth": "confidence_percentage_truth",
    "legal_advice_language": "legal_advice_language",
}

SURFACE_COPY = {
    "public_copy": "This public copy has a scoped overlay. See the source digest, affected scope, and preserved history before relying on it.",
    "mirror": "This mirror may lag the source. Recheck the named source digest before treating this mirror as current.",
    "generated_summary": "This generated summary reflects an overlay notice for a named source digest; it is not the source itself.",
    "consumer_notice": "A notice was delivered to this consumer surface. Delivery is recorded separately from read, application, or repair.",
    "local_index": "This search result is marked with a scoped overlay. The index helps find material but does not prove currentness.",
    "warning_card": "The warning is split by scope. Some surfaces are updated, some are unknown, and history remains visible.",
    "sealed_notice_summary": "A sealed overlay exists. The public summary preserves scope and caveats without disclosing sealed details.",
    "multi_cube_public_card": "Multiple companion overlays are present and remain incomparable unless Harbor records a local scope map.",
    "localized_card": "This localized explanation is bound to the source-language digest and does not widen the overlay scope.",
    "status_message": "Status message: scoped overlay present. It is also exposed with a programmatic label and text, not color alone.",
    "problem_detail": "Reason code and user-facing text travel together so machines can route the issue without replacing explanation.",
    "action_panel": "You can inspect evidence, request recheck, or export the scope note. These actions do not prove repair.",
}

SURFACE_NON_PROMISES = {
    "public_copy": ["not a green badge", "not closure", "not compliance"],
    "mirror": ["not all mirrors clean", "not current without recheck", "not global closure"],
    "generated_summary": ["not source equivalent", "not compliance proof", "not all copies repaired"],
    "consumer_notice": ["not read proof", "not applied proof", "not repair proof"],
    "local_index": ["not search truth", "not currentness", "not source repair"],
    "warning_card": ["not single badge", "not legal finding", "not compliance workflow"],
    "sealed_notice_summary": ["not sealed disclosure", "not public truth", "not full proof"],
    "multi_cube_public_card": ["not majority verdict", "not conflict resolution", "not single summary"],
    "localized_card": ["not translation equivalence", "not scope widening", "not new authority"],
    "status_message": ["not color-only", "not accessibility conformance", "not user comprehension proof"],
    "problem_detail": ["not workflow closure", "not machine-code truth", "not user-message replacement"],
    "action_panel": ["not automatic repair", "not legal advice", "not global downstream action"],
}

def prior_f104_digest() -> str:
    path = ROOT / "fixtures" / "harbor-revocation-overlay-propagation-bundle-v0.json"
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))["bundle_digest"]
    return f104.build_bundle()["bundle_digest"]


def overlay_input(case: dict[str, Any]) -> dict[str, Any]:
    candidate = case["candidate"]
    missing_digest = candidate == "missing_source_overlay_digest"
    surface = case["surface"]
    overlay_digest = None if missing_digest else digest({"overlay_explanation": case["id"], "parent": prior_f104_digest(), "surface": surface})
    return {
        "parent_bundle": "harbor-revocation-overlay-propagation-bundle-v0",
        "parent_bundle_digest": prior_f104_digest(),
        "parent_case_ref": f"RO{((int(case['id'][2:]) - 1) % 30) + 1:03d}",
        "surface_kind": surface,
        "overlay_digest_present": not missing_digest,
        "overlay_digest": overlay_digest,
        "scope_map_present": candidate != "missing_scope_map",
        "scope_map_digest": None if candidate == "missing_scope_map" else digest({"scope": surface, "case": case["id"], "overlay": overlay_digest}),
        "overlay_clock": "2026-05-25T23:42:00Z",
        "source_non_promises": ["not Harbor authority by itself", "not badge", "not compliance", "not global repair"],
    }


def audience_context(case: dict[str, Any]) -> dict[str, Any]:
    surface = case["surface"]
    localized = surface == "localized_card"
    status = surface == "status_message"
    return {
        "audience": "public_reader" if surface in {"public_copy", "mirror", "warning_card", "localized_card", "status_message"} else "consumer_or_operator",
        "locale": "es-US" if localized else "en-US",
        "reading_level_goal": "plain operational language",
        "needs_programmatic_status": status,
        "needs_non_color_cue": status or case["candidate"] == "color_only_indicator",
        "sealed_context": surface == "sealed_notice_summary",
        "multi_cube_context": surface == "multi_cube_public_card",
        "non_promises": ["not user comprehension proof", "not legal advice", "not accessibility conformance claim"],
    }


def explanation_copy(case: dict[str, Any], source: dict[str, Any]) -> dict[str, Any]:
    candidate = case["candidate"]
    surface = case["surface"]
    text = SURFACE_COPY[surface]
    if candidate == "green_badge_only_display":
        text = "unsafe green-badge-only display; missing scope, history, and caveats"
    elif candidate == "red_global_failure_banner":
        text = "unsafe red global-failure banner; companion overlay is treated as universal failure"
    elif candidate == "closure_language_without_scope":
        text = "unsafe closure label: resolved without scope or recheck basis"
    elif candidate == "prior_falsehood_or_negligence_claim":
        text = "unsafe prior-falsehood and negligence language attached to the old copy"
    elif candidate == "color_only_indicator":
        text = "unsafe color-only dot with no text label or reason"
    elif candidate == "generated_summary_as_source_equivalent":
        text = "unsafe generated summary says it replaces the source and carries the same status"
    elif candidate == "hide_prior_history":
        text = "unsafe explanation hides the prior import and old overlay history"
    elif candidate == "sealed_detail_disclosure":
        text = "unsafe sealed detail disclosure appears in public explanation"
    elif candidate == "timestamp_as_currentness":
        text = "unsafe timestamp freshness claim used as currentness"
    elif candidate == "machine_code_only_user_message":
        text = "UX-OVERLAY-SCOPE-RECHECK"
    elif candidate == "single_sentence_mixed_overlay_collapse":
        text = "unsafe single sentence says all companion overlays agree"
    elif candidate == "confidence_percentage_as_truth":
        text = "unsafe 99 percent confidence shown as truth instead of scoped evidence"
    elif candidate == "legal_advice_language":
        text = "unsafe legal advice language instructs the user that compliance has failed"
    caveats = SURFACE_NON_PROMISES[surface]
    if candidate in {"green_badge_only_display", "red_global_failure_banner", "closure_language_without_scope", "color_only_indicator", "machine_code_only_user_message"}:
        caveats = []
    return {
        "headline": "Scoped overlay notice" if case["expected"] == "accepted" else "Unsafe explanation candidate",
        "body": text,
        "caveats": caveats,
        "scope_words_present": source["scope_map_present"] and "scope" in text.lower(),
        "digest_words_present": source["overlay_digest_present"] and ("digest" in text.lower() or surface in {"consumer_notice", "status_message", "action_panel"}),
        "history_words_present": "history" in text.lower() or surface in {"consumer_notice", "localized_card", "status_message", "problem_detail", "action_panel"},
        "machine_only": candidate == "machine_code_only_user_message",
        "plain_language_present": candidate != "machine_code_only_user_message",
        "badge_shape_used": candidate == "green_badge_only_display",
        "red_failure_shape_used": candidate == "red_global_failure_banner",
        "closure_language_used": candidate == "closure_language_without_scope",
        "prior_fault_language_used": candidate == "prior_falsehood_or_negligence_claim",
        "sealed_detail_leaked": candidate == "sealed_detail_disclosure",
        "confidence_as_truth_used": candidate == "confidence_percentage_as_truth",
        "legal_advice_used": candidate == "legal_advice_language",
        "copy_digest": digest({"body": text, "caveats": caveats, "case": case["id"]}),
    }


def reason_code(case: dict[str, Any], copy: dict[str, Any]) -> dict[str, Any]:
    candidate = case["candidate"]
    code_present = candidate != "machine_code_only_user_message" or True
    code = "harbor.overlay.scope.recheck" if case["expected"] == "accepted" else f"harbor.overlay.refusal.{FAILURE_REASONS[candidate]}"
    return {
        "code_present": code_present,
        "code": code,
        "human_text_present": not copy["machine_only"],
        "problem_detail_shape": case["surface"] == "problem_detail",
        "machine_reason_not_user_truth": candidate != "machine_code_only_user_message",
        "reason_digest": digest({"code": code, "human": not copy["machine_only"], "case": case["id"]}),
    }


def action_affordance(case: dict[str, Any]) -> dict[str, Any]:
    candidate = case["candidate"]
    global_repair = candidate == "repair_all_downstream_action"
    read_applied = candidate == "notice_delivery_as_read_applied"
    return {
        "allowed_actions": ["inspect evidence", "request recheck", "export scope note"] if not global_repair else ["repair all downstream now"],
        "repair_claimed": global_repair,
        "global_downstream_action_claimed": global_repair,
        "read_claimed_from_delivery": read_applied,
        "applied_claimed_from_delivery": read_applied,
        "legal_advice_claimed": candidate == "legal_advice_language",
        "action_digest": digest({"candidate": candidate, "actions": "global" if global_repair else "scoped"}),
        "non_promises": ["not repair proof", "not read proof", "not compliance workflow"],
    }


def access_localization(case: dict[str, Any], audience: dict[str, Any], source: dict[str, Any]) -> dict[str, Any]:
    candidate = case["candidate"]
    localized = case["surface"] == "localized_card"
    color_only = candidate == "color_only_indicator"
    no_label = candidate == "status_message_without_programmatic_label"
    translation_missing = candidate == "translation_without_provenance"
    widens = candidate == "localized_variant_widens_scope"
    return {
        "programmatic_label_present": not no_label and not color_only,
        "text_not_color_only": not color_only,
        "status_message_declared": case["surface"] == "status_message",
        "source_language_digest": source["overlay_digest"] if localized and not translation_missing else None,
        "localized_variant_digest": digest({"locale": audience["locale"], "case": case["id"], "source": source["overlay_digest"]}) if localized and not translation_missing else None,
        "translation_provenance_present": (localized and not translation_missing) or not localized,
        "localized_scope_widened": widens,
        "accessibility_conformance_claimed": False,
        "localization_equivalence_claimed": False,
        "render_digest": digest({"case": case["id"], "label": not no_label, "color_only": color_only, "locale": audience["locale"]}),
    }


def history_trace(case: dict[str, Any], source: dict[str, Any]) -> dict[str, Any]:
    hidden = case["candidate"] == "hide_prior_history"
    mixed_collapse = case["candidate"] == "single_sentence_mixed_overlay_collapse"
    return {
        "parent_overlay_bundle_digest": prior_f104_digest(),
        "parent_case_ref": source["parent_case_ref"],
        "prior_history_visible": not hidden,
        "prior_import_digest": digest({"prior_import": case["id"], "surface": case["surface"]}),
        "mixed_overlay_state_preserved": case["surface"] != "multi_cube_public_card" or not mixed_collapse,
        "timestamp_currentness_claimed": case["candidate"] == "timestamp_as_currentness",
        "history_digest": digest({"case": case["id"], "hidden": hidden, "mixed": not mixed_collapse}),
        "non_promises": ["not history erasure", "not currentness", "not all surfaces repaired"],
    }


def verdict_summary(case: dict[str, Any], source: dict[str, Any], copy: dict[str, Any], reason: dict[str, Any], action: dict[str, Any], access: dict[str, Any], history: dict[str, Any]) -> dict[str, Any]:
    expected = case["expected"]
    failure_reasons: list[str] = []
    candidate = case["candidate"]
    if expected == "rejected":
        failure_reasons.append(FAILURE_REASONS[candidate])
    flags = {
        "badge_shape_used": copy["badge_shape_used"],
        "red_failure_shape_used": copy["red_failure_shape_used"],
        "closure_language_used": copy["closure_language_used"],
        "prior_fault_language_used": copy["prior_fault_language_used"],
        "color_only_indicator": not access["text_not_color_only"],
        "missing_scope_map": not source["scope_map_present"],
        "missing_source_overlay_digest": not source["overlay_digest_present"],
        "localized_scope_widened": access["localized_scope_widened"],
        "summary_as_source_equivalent": candidate == "generated_summary_as_source_equivalent",
        "delivery_as_read_applied": action["read_claimed_from_delivery"] or action["applied_claimed_from_delivery"],
        "global_repair_action": action["global_downstream_action_claimed"],
        "history_hidden": not history["prior_history_visible"],
        "sealed_detail_leaked": copy["sealed_detail_leaked"],
        "timestamp_currentness_claimed": history["timestamp_currentness_claimed"],
        "machine_only_message": copy["machine_only"],
        "missing_programmatic_label": not access["programmatic_label_present"],
        "translation_without_provenance": not access["translation_provenance_present"],
        "mixed_overlay_collapse": not history["mixed_overlay_state_preserved"],
        "confidence_as_truth_used": copy["confidence_as_truth_used"],
        "legal_advice_used": copy["legal_advice_used"] or action["legal_advice_claimed"],
    }
    return {
        "expected": expected,
        "admitted": expected == "accepted",
        "verdict_class": "accepted_scoped_user_explanation" if expected == "accepted" else "refused_explanation_status_collapse",
        "failure_reasons": failure_reasons,
        "flags": flags,
        "badge_allowed": False,
        "compliance_claim_allowed": False,
        "legal_finding_allowed": False,
        "global_repair_claim_allowed": False,
        "read_or_application_claim_allowed": False,
        "history_erasure_allowed": False,
        "non_promises": NON_PROMOTION,
    }


def build_case(index: int, case: dict[str, Any]) -> dict[str, Any]:
    source = overlay_input(case)
    audience = audience_context(case)
    copy = explanation_copy(case, source)
    reason = reason_code(case, copy)
    action = action_affordance(case)
    access = access_localization(case, audience, source)
    history = history_trace(case, source)
    verdict = verdict_summary(case, source, copy, reason, action, access, history)
    members = {
        "overlay.input": source,
        "audience.context": audience,
        "explanation.copy": copy,
        "reason.code": reason,
        "action.affordance": action,
        "access.localization": access,
        "history.trace": history,
        "verdict.summary": verdict,
    }
    row = {"index": index, "id": case["id"], "candidate": case["candidate"], "surface": case["surface"], **members}
    row["row_digest"] = digest({label: row[label] for label in MEMBER_LABELS})
    return row


def build_bundle() -> dict[str, Any]:
    cases = [build_case(index, plan) for index, plan in enumerate(CASE_PLAN, start=1)]
    accepted = sum(1 for case in cases if case["verdict.summary"]["expected"] == "accepted")
    rejected = len(cases) - accepted
    bundle = {
        "schema": SCHEMA,
        "version": VERSION,
        "source_revision": REVISION,
        "member_labels": MEMBER_LABELS,
        "prior_revocation_overlay_bundle_digest": prior_f104_digest(),
        "bundle_common_helper_digest": file_digest(ROOT / "tools" / "harbor_bundle_common.py"),
        "briefing_focus_audit_checker_digest": file_digest(ROOT / "tools" / "check_harbor_briefing_focus.py") if (ROOT / "tools" / "check_harbor_briefing_focus.py").exists() else None,
        "cases": cases,
        "audit_refactor_note": {
            "refactor": "rev0110 trims landing pages to one current briefing and adds check_harbor_briefing_focus.py so stale appended briefing sections fail",
            "audit_guard": "briefing focus audit checks README.md, START_HERE.md, and docs/README.md for current revision/focus and stale revision fragments",
            "non_promise": "landing-page cleanup is documentation hygiene, not schema, badge, compliance, accessibility conformance, or trust authority",
        },
        "global": {
            "case_count": len(cases),
            "accepted_count": accepted,
            "rejected_count": rejected,
            "source_revision": REVISION,
            "member_labels": MEMBER_LABELS,
            "coverage_claim": "Covers representative user-visible explanation cases for revocation overlays; not an explanation API, badge workflow, accessibility conformance claim, localization guarantee, or compliance workflow.",
            "non_promotion": NON_PROMOTION,
        },
    }
    bundle["bundle_digest"] = digest({key: bundle[key] for key in ["schema", "version", "source_revision", "member_labels", "prior_revocation_overlay_bundle_digest", "bundle_common_helper_digest", "briefing_focus_audit_checker_digest", "cases", "audit_refactor_note", "global"]})
    return bundle


def main() -> None:
    parser = argparse.ArgumentParser(description="Emit Harbor user-visible explanation bundle")
    parser.add_argument("--output", type=Path, default=ROOT / "fixtures" / "harbor-user-visible-explanation-bundle-v0.json")
    args = parser.parse_args()
    bundle = build_bundle()
    args.output.write_text(json.dumps(bundle, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(args.output)


if __name__ == "__main__":
    main()
