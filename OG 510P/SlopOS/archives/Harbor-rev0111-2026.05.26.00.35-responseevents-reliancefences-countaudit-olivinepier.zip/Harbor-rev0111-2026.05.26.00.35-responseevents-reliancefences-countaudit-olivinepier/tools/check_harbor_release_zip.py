#!/usr/bin/env python3
"""Inspect a Harbor release zip after packaging.

This is an out-of-band package check used by `make package-release`.  It does
not sign the archive, certify security, or prove reproducibility across unknown
builders; it verifies that the emitted zip matches this working tree's package
plan.
"""
from __future__ import annotations

import argparse
import hashlib
import os
import stat
import sys
import zipfile
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
GENERATED_SOURCE_PARTS = {"__pycache__"}

def is_packaged_source(path: Path) -> bool:
    return (
        path.is_file()
        and ".git" not in path.parts
        and not any(part in GENERATED_SOURCE_PARTS for part in path.parts)
        and path.name != ".DS_Store"
        and path.suffix != ".pyc"
    )


def fail(message: str) -> None:
    print(message)
    raise SystemExit(1)


def expect(condition: bool, message: str) -> None:
    if not condition:
        fail(message)


def list_files() -> list[Path]:
    return sorted(
        p for p in ROOT.rglob("*")
        if is_packaged_source(p)
    )


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return "sha256:" + h.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description="Check a Harbor release zip against the current tree")
    parser.add_argument("zip_path", type=Path)
    args = parser.parse_args()
    zip_path = args.zip_path
    expect(zip_path.exists(), f"Release zip not found: {zip_path}")
    expect(zip_path.name == f"{ROOT.name}.zip", f"Release zip name does not match root: {zip_path.name} vs {ROOT.name}.zip")

    expected_files = list_files()
    expected_names = [f"{ROOT.name}/{p.relative_to(ROOT).as_posix()}" for p in expected_files]

    with zipfile.ZipFile(zip_path, "r") as zf:
        infos = zf.infolist()
        names = [info.filename for info in infos]
        expect(names == expected_names, "Release zip entry list/order does not match sorted repository file list")
        for info, source_path in zip(infos, expected_files):
            expect(not info.is_dir(), f"Directory entry unexpectedly present: {info.filename}")
            expect(info.filename.startswith(f"{ROOT.name}/"), f"Entry lacks release-root prefix: {info.filename}")
            expect(".." not in Path(info.filename).parts, f"Entry contains parent traversal: {info.filename}")
            expect(info.date_time == (1980, 1, 1, 0, 0, 0), f"Non-deterministic timestamp on {info.filename}: {info.date_time}")
            expect(info.compress_type == zipfile.ZIP_DEFLATED, f"Unexpected compression type on {info.filename}: {info.compress_type}")
            mode = (info.external_attr >> 16) & 0xFFFF
            expected_mode = stat.S_IMODE(source_path.stat().st_mode) or 0o644
            expect(mode == expected_mode, f"Mode drift on {info.filename}: {oct(mode)} vs {oct(expected_mode)}")
            if Path(info.filename).name.startswith("Harbor-rev") and info.filename.endswith(".zip"):
                fail(f"Embedded release zip detected in archive: {info.filename}")
        bad = zf.testzip()
        expect(bad is None, f"Zip CRC/integrity test failed at {bad}")

    print(f"Harbor release zip check passed: {sha256_file(zip_path)}")


if __name__ == "__main__":
    main()
