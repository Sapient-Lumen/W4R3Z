#!/usr/bin/env python3
"""Check the deterministic Harbor checker-provenance bundle."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

import harbor_checker_provenance_harness as harness  # noqa: E402


def fail(message: str) -> None:
    print(message)
    raise SystemExit(1)


def expect(condition: bool, message: str) -> None:
    if not condition:
        fail(message)


def check_bundle(bundle: dict[str, Any]) -> None:
    expect(bundle.get("schema") == harness.SCHEMA, "Unexpected bundle schema")
    expect(bundle.get("version") == harness.VERSION, "Unexpected bundle version")
    expect(bundle.get("revision") == harness.REVISION, "Unexpected bundle revision")
    expect(bundle.get("purpose", "").endswith("not a durable schema"), "Purpose must refuse durable schema promotion")
    expected_digest = harness.digest({k: v for k, v in bundle.items() if k != "bundle_digest"})
    expect(bundle.get("bundle_digest") == expected_digest, "Bundle digest drift")

    members = bundle.get("members")
    expect(isinstance(members, dict), "Bundle members must be an object")
    expect(list(members.keys()) == harness.MEMBER_LABELS, "Member labels/order drift")

    matrix = members["checker.matrix"]
    expect(len(matrix) == 10, "F095 bundle must keep ten checker-provenance cases")
    for label in harness.MEMBER_LABELS[1:]:
        expect(list(members[label].keys()) == list(matrix.keys()), f"Case id/order drift in {label}")

    accepted = 0
    rejected = 0
    seen_indexes = []
    seen_candidates = set()
    for case_id, row in matrix.items():
        seen_indexes.append(row.get("index"))
        checker_id = row.get("checker")
        candidate = row.get("candidate")
        seen_candidates.add(candidate)
        expected = row.get("expected")
        expect(checker_id in harness.CHECKERS, f"{case_id}: unknown checker")
        expect(expected in {"accepted", "rejected"}, f"{case_id}: invalid expected outcome")
        expect(candidate, f"{case_id}: missing candidate")

        prov = members["checker.provenance"][case_id]
        pairing = members["fixture.pairing"][case_id]
        guard = members["guard.state"][case_id]
        selftest = members["selftest.receipt"][case_id]
        override = members["reviewer.override"][case_id]
        verdict = members["verdict.summary"][case_id]

        spec = harness.CHECKERS[checker_id]
        expect(prov.get("checker_id") == checker_id, f"{case_id}: provenance checker id drift")
        expect(prov.get("checker_path") == spec["checker_path"], f"{case_id}: checker path drift")
        expect(prov.get("harness_path") == spec["harness_path"], f"{case_id}: harness path drift")
        expect(prov.get("fixture_path") == spec["fixture_path"], f"{case_id}: fixture path drift")
        for field in ["checker_source_digest", "harness_source_digest", "fixture_file_digest", "fixture_bundle_digest"]:
            expect(isinstance(prov.get(field), str) and prov[field].startswith("sha256:"), f"{case_id}: {field} missing digest")
        expect(prov.get("fixture_schema") == spec["fixture_schema"], f"{case_id}: fixture schema drift")
        expect(prov.get("expected_fixture_revision") == spec["fixture_revision"], f"{case_id}: expected fixture revision drift")
        expect(prov.get("observation_is_about_checker_execution") is True, f"{case_id}: checker-execution bit missing")
        expect(prov.get("observation_is_not_semantic_truth") is True, f"{case_id}: semantic-truth refusal missing")

        expect(guard.get("checker_id") == checker_id, f"{case_id}: guard checker id drift")
        expect(guard.get("required_guards") == spec["guard_families"], f"{case_id}: guard family drift")
        expect(guard.get("guard_state_digest", "").startswith("sha256:"), f"{case_id}: guard digest missing")
        expect(set(guard.get("guard_enabled", {}).keys()) == set(spec["guard_families"]), f"{case_id}: guard enable map drift")
        expect(guard.get("guard_state_is_observed_not_assumed") is True, f"{case_id}: guard-state observation bit missing")

        expect(pairing.get("checker_id") == checker_id, f"{case_id}: pairing checker id drift")
        expect(pairing.get("checker_source_digest") == prov.get("checker_source_digest"), f"{case_id}: pairing source digest mismatch")
        expect(pairing.get("fixture_revision_expected") == spec["fixture_revision"], f"{case_id}: pairing expected revision drift")
        expect(pairing.get("schema_matches_checker_expectation") is True, f"{case_id}: schema expectation mismatch")

        expect(selftest.get("checker_id") == checker_id, f"{case_id}: selftest checker id drift")
        expect(selftest.get("receipt_does_not_certify_checker_correctness") is True, f"{case_id}: selftest overclaim guard missing")

        expect(verdict.get("expected_matched") is True, f"{case_id}: verdict did not match expected outcome")
        expect(verdict.get("non_promotion_checked") is True, f"{case_id}: non-promotion bit missing")
        expect(verdict.get("does_not_certify_subject_bundle_truth") is True, f"{case_id}: subject-truth refusal missing")
        expect(verdict.get("does_not_establish_ci_status") is True, f"{case_id}: CI-status refusal missing")
        if verdict.get("admitted"):
            accepted += 1
            expect(expected == "accepted", f"{case_id}: admitted rejected candidate")
            expect(guard.get("all_required_guards_enabled") is True, f"{case_id}: admitted with disabled guard")
            expect(pairing.get("paired") is True, f"{case_id}: admitted stale pairing")
            expect(selftest.get("selftest_status") == "passed", f"{case_id}: admitted without passing selftest")
            if override.get("override_present"):
                expect(override.get("scope") != "global", f"{case_id}: admitted global override")
                expect(override.get("expires_after_revision"), f"{case_id}: admitted override without expiry")
                expect(override.get("does_not_change_checker_result") is True, f"{case_id}: override changes checker result")
                expect(override.get("does_not_mark_failure_as_success") is True, f"{case_id}: override marks failure as success")
                expect("not a checker bypass" in override.get("non_promises", []), f"{case_id}: override bypass refusal missing")
        else:
            rejected += 1
            expect(expected == "rejected", f"{case_id}: rejected accepted candidate")
            expect(verdict.get("verdict_class") == "refused_counterfeit_checker_confidence", f"{case_id}: rejected verdict class drift")

        if candidate == "disabled_guard_evidence":
            expect(guard.get("all_required_guards_enabled") is False, f"{case_id}: disabled guard candidate still all-enabled")
            expect(guard.get("disabled_guards"), f"{case_id}: disabled guard list missing")
            expect(verdict.get("admitted") is False, f"{case_id}: disabled guard admitted")
        elif candidate == "stale_fixture_checker_pairing":
            expect(pairing.get("paired") is False, f"{case_id}: stale pairing marked paired")
            expect(pairing.get("stale_pairing_refused") is True, f"{case_id}: stale pairing not refused")
            expect(pairing.get("fixture_revision_observed") != pairing.get("fixture_revision_expected"), f"{case_id}: stale pairing revision not stale")
        elif candidate == "missing_selftest_receipt":
            expect(selftest.get("selftest_status") == "missing", f"{case_id}: missing selftest candidate not missing")
            expect(selftest.get("missing_receipt_refused") is True, f"{case_id}: missing receipt refusal missing")
        elif candidate == "scoped_reviewer_override_packet":
            expect(verdict.get("admitted") is True, f"{case_id}: scoped override should be admitted as review packet")
            expect(override.get("override_present") is True, f"{case_id}: override packet missing")
            expect(override.get("requires_followthrough_if_repeated") is True, f"{case_id}: repeated override followthrough guard missing")
        elif candidate == "unscoped_reviewer_override_attempt":
            expect(verdict.get("admitted") is False, f"{case_id}: unscoped override admitted")
            expect(override.get("does_not_change_checker_result") is False, f"{case_id}: unscoped override did not attempt result change")

    expect(seen_indexes == list(range(1, len(matrix) + 1)), "Checker-provenance indexes must be gapless")
    required_candidates = {plan["candidate"] for plan in harness.CASE_PLAN}
    expect(seen_candidates == required_candidates, "Not all F095 candidate classes are represented")

    global_ = bundle.get("global", {})
    expect(global_.get("case_count") == len(matrix), "Global case_count drift")
    expect(global_.get("accepted_count") == accepted, "Global accepted_count drift")
    expect(global_.get("rejected_count") == rejected, "Global rejected_count drift")
    expect(global_.get("checker_count") == len(harness.CHECKERS), "Global checker_count drift")
    expect(global_.get("subject_checkers") == sorted(harness.CHECKERS.keys()), "Global subject checker list drift")
    expect("excluded" in global_.get("self_recursive_checker_attestation", ""), "Self-recursive attestation exclusion missing")
    expect("not CI status" in global_.get("coverage_claim", ""), "Coverage claim must refuse CI-status promotion")
    for refusal in harness.NON_PROMOTION:
        expect(refusal in global_.get("non_promotion", []), f"Global non-promotion list missing {refusal}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Check Harbor checker-provenance bundle")
    parser.add_argument("--fixture", type=Path, default=ROOT / "fixtures" / "harbor-checker-provenance-bundle-v0.json")
    args = parser.parse_args()

    expected = harness.build_bundle()
    check_bundle(expected)

    if args.fixture.exists():
        actual = json.loads(args.fixture.read_text(encoding="utf-8"))
        expect(actual == expected, "Checked fixture does not match deterministic harness output")
    else:
        fail(f"Fixture missing: {args.fixture}")

    print("Harbor checker-provenance bundle check passed")


if __name__ == "__main__":
    main()
