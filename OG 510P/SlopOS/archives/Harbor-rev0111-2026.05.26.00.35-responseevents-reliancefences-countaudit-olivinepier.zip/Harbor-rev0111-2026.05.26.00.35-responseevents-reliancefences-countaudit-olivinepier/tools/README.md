# Tools

This embryo ships tiny repo/process helpers and deterministic verification proof slices.

- `make check` — runs `tools/check_all.py`, which follows the executable-surface registry plus audit checks and repo hygiene.
- `make package-release` — refreshes release surfaces, reruns checks, emits a deterministic release zip, then verifies the emitted archive.

- `tools/harbor_crossing_record_harness.py` / `tools/check_harbor_crossing_record_bundle.py` — emit and check F090 CrossingRecord evidence evidence.
- `tools/harbor_transparency_receipt_harness.py` / `tools/check_harbor_transparency_receipt_bundle.py` — emit and check F091 transparency/provenance receipt import evidence.
- `tools/harbor_verifier_disagreement_harness.py` / `tools/check_harbor_verifier_disagreement_bundle.py` — emit and check F092 verifier disagreement / policy epoch drift evidence.
- `tools/harbor_property_mutation_harness.py` / `tools/check_harbor_property_mutation_bundle.py` — emit and check F093 property/mutation coverage evidence.
- `tools/harbor_mutation_triage_harness.py` / `tools/check_harbor_mutation_triage_bundle.py` — emit and check F094 mutation triage evidence.
- `tools/harbor_checker_provenance_harness.py` / `tools/check_harbor_checker_provenance_bundle.py` — emit and check F095 checker provenance evidence.
- `tools/harbor_release_package_provenance_harness.py` / `tools/check_harbor_release_package_provenance_bundle.py` — emit and check F096 release-package provenance evidence.
- `tools/harbor_artifact_handoff_harness.py` / `tools/check_harbor_artifact_handoff_bundle.py` — emit and check F097 artifact handoff / consumer import evidence.
- `tools/harbor_local_derivation_harness.py` / `tools/check_harbor_local_derivation_bundle.py` — emit and check F098 post-import local derivation drift evidence.
- `tools/harbor_derivative_repair_harness.py` / `tools/check_harbor_derivative_repair_bundle.py` — emit and check F099 derivative correction propagation evidence.
- `tools/harbor_retention_expiry_harness.py` / `tools/check_harbor_retention_expiry_bundle.py` — emit and check F100 derivative repair retention/expiry evidence.
- `tools/harbor_overlapping_epoch_lineage_harness.py` / `tools/check_harbor_overlapping_epoch_lineage_bundle.py` — emit and check F101 overlapping correction-epoch lineage evidence.
- `tools/harbor_cross_cube_lineage_import_harness.py` / `tools/check_harbor_cross_cube_lineage_import_bundle.py` — emit and check F102 cross-cube lineage import evidence.
- `tools/harbor_foreign_import_revocation_harness.py` / `tools/check_harbor_foreign_import_revocation_bundle.py` — emit and check F103 foreign-import revocation/correction evidence.
- `tools/harbor_revocation_overlay_propagation_harness.py` / `tools/check_harbor_revocation_overlay_propagation_bundle.py` — emit and check F104 revocation-overlay propagation evidence.
- `tools/harbor_user_visible_explanation_harness.py` / `tools/check_harbor_user_visible_explanation_bundle.py` — emit and check F105 user-visible explanation bundles evidence.
- `tools/harbor_user_response_event_harness.py` / `tools/check_harbor_user_response_event_bundle.py` — emit and check F106 user-response event capture evidence.

- `tools/harbor_executable_surface_registry.py` centralizes proof-slice wiring; it is maintenance inventory, not conformance status.
- `tools/check_harbor_briefing_focus.py` keeps landing pages current-focused; it is not a release-status API.
