#!/usr/bin/env python3
"""Emit deterministic Harbor transparency/provenance receipt import evidence."""
from __future__ import annotations

import argparse
import hashlib
import json
from copy import deepcopy
from typing import Any

SCHEMA = "harbor-transparency-provenance-receipt-bundle"
VERSION = "0"
REVISION = "rev0096"

MEMBER_LABELS = [
    "case.matrix",
    "input.receipt_evidence",
    "input.import_record",
    "binding.analysis",
    "currentness.analysis",
    "output.admission",
    "output.aftermath",
    "verdict.summary",
]

IMPORT_TOP_KEYS = [
    "import_id",
    "subject",
    "receipt",
    "binding",
    "scope",
    "verifier",
    "currentness",
    "outcome",
    "aftermath",
]

RECEIPT_GUARDS = {
    "scitt_inclusion": {
        "not_statement_truth",
        "not_currentness",
        "not_policy_satisfaction",
        "not_issuer_authority_beyond_scope",
    },
    "c2pa_manifest": {
        "not_real_world_authenticity",
        "not_editorial_approval",
        "not_preserved_after_transform",
        "not_trust_signal_truth",
    },
    "intoto_slsa_provenance": {
        "not_build_trust_by_default",
        "not_dependency_cleanliness",
        "not_deployed_artifact_truth",
        "not_vulnerability_status",
    },
    "rekor_ct_inclusion": {
        "not_currentness",
        "not_semantic_approval",
        "not_revocation_absence",
        "not_consistency_checked_unless_recorded",
    },
    "timestamp_anchor": {
        "not_event_time",
        "not_source_truth",
        "not_currentness",
        "not_clock_authority_beyond_source",
    },
    "redacted_derived_proof": {
        "not_full_evidence",
        "not_no_hidden_contradiction",
        "not_privacy_safety",
        "not_recursive_disclosure_entitlement",
    },
    "issuer_compromise_advisory": {
        "not_auto_false",
        "not_auto_true",
        "not_clean_since_compromise",
        "not_global_revocation",
    },
    "verifier_policy_decision": {
        "not_content_truth",
        "not_future_policy_pass",
        "not_compliance",
        "not_global_authority",
    },
}

FORBIDDEN_OUTCOME_CLASSES = {
    "trusted",
    "true",
    "fresh",
    "compliant",
    "globally_verified",
    "authentic_real_world",
}

ALLOWED_BINDING_VERDICTS = {
    "subject_digest_matches",
    "subject_digest_mismatch",
    "subject_binding_indeterminate",
    "redacted_binding_sufficient_for_claims",
    "scope_substitution_rejected",
}

ALLOWED_CURRENTNESS_VERDICTS = {
    "currentness_not_established",
    "fresh_for_checkpoint_only",
    "timestamp_only",
    "revocation_or_compromise_recheck_required",
    "policy_epoch_bound",
}


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def digest(value: Any) -> str:
    return "sha256:" + hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def scope(artifact: str, audience: str, surface: str, *, jurisdiction: str = "local", window: str = "2026-05-21T10:00:00Z/2026-05-28T10:00:00Z") -> dict[str, Any]:
    return {
        "artifact": artifact,
        "audience": audience,
        "jurisdiction": jurisdiction,
        "surface": surface,
        "time_window": window,
    }


def receipt_evidence(
    case_id: str,
    *,
    family: str,
    subject_digest: str,
    issuer: str,
    receipt_claims: list[str],
    blocked_claims: list[str],
    scope_value: dict[str, Any],
    observed_at: str = "2026-05-21T10:00:00Z",
) -> dict[str, Any]:
    body = {
        "evidence_id": "rx-" + case_id,
        "family": family,
        "issuer": issuer,
        "observed_at": observed_at,
        "subject_digest": subject_digest,
        "receipt_claims": receipt_claims,
        "blocked_claims": blocked_claims,
        "scope": scope_value,
    }
    body["receipt_digest"] = digest({k: v for k, v in body.items() if k != "receipt_digest"})
    return body


def import_record(
    case_id: str,
    *,
    subject_kind: str,
    subject_ref: str,
    subject_digest: str,
    family: str,
    issuer: str,
    scope_value: dict[str, Any],
    verifier_decision: str,
    binding_verdict: str,
    currentness_verdict: str,
    outcome_class: str,
    receipts: list[str],
    non_promises: list[str],
    receipt_digest: str,
    policy_id: str = "harbor-receipt-import-policy/v0",
    policy_digest: str = "sha256:policy-placeholder-rev0096",
) -> dict[str, Any]:
    return {
        "import_id": "ri-091-" + case_id,
        "subject": {
            "kind": subject_kind,
            "ref": subject_ref,
            "digest": subject_digest,
        },
        "receipt": {
            "family": family,
            "issuer": issuer,
            "receipt_digest": receipt_digest,
            "observed_at": "2026-05-21T10:00:00Z",
        },
        "binding": {
            "subject_digest_verdict": binding_verdict,
            "materials_or_manifest_checked": binding_verdict not in {"subject_digest_mismatch", "subject_binding_indeterminate"},
        },
        "scope": scope_value,
        "verifier": {
            "decision": verifier_decision,
            "policy_id": policy_id,
            "policy_digest": policy_digest,
            "policy_epoch": "2026-05-21T10:00:00Z",
            "decision_is_semantic_truth": False,
        },
        "currentness": {
            "verdict": currentness_verdict,
            "revocation_or_compromise_checked": currentness_verdict == "fresh_for_checkpoint_only",
            "freshness_claim": "none" if currentness_verdict != "fresh_for_checkpoint_only" else "fresh for named checkpoint only",
        },
        "outcome": {
            "class": outcome_class,
            "non_promises": non_promises,
        },
        "aftermath": {
            "receipts": receipts,
            "recheck_window": "2026-05-21T10:00:00Z/2026-05-28T10:00:00Z",
            "rollback_or_reopen_triggers": [
                "subject_digest_mismatch",
                "scope_substitution",
                "issuer_compromise",
                "log_consistency_failure",
                "manifest_binding_loss",
                "policy_epoch_change",
            ],
        },
    }


def accepted_case(
    case_id: str,
    *,
    family: str,
    subject_kind: str,
    subject_ref: str,
    subject_digest: str,
    issuer: str,
    scope_value: dict[str, Any],
    receipt_claims: list[str],
    blocked_claims: list[str],
    binding_verdict: str,
    currentness_verdict: str,
    verifier_decision: str,
    outcome_class: str,
    binding_note: str,
    currentness_note: str,
) -> dict[str, Any]:
    evidence = receipt_evidence(
        case_id,
        family=family,
        subject_digest=subject_digest,
        issuer=issuer,
        receipt_claims=receipt_claims,
        blocked_claims=blocked_claims,
        scope_value=scope_value,
    )
    guards = sorted(RECEIPT_GUARDS[family])
    record = import_record(
        case_id,
        subject_kind=subject_kind,
        subject_ref=subject_ref,
        subject_digest=subject_digest,
        family=family,
        issuer=issuer,
        scope_value=scope_value,
        verifier_decision=verifier_decision,
        binding_verdict=binding_verdict,
        currentness_verdict=currentness_verdict,
        outcome_class=outcome_class,
        receipts=[evidence["evidence_id"]],
        non_promises=guards,
        receipt_digest=evidence["receipt_digest"],
    )
    return {
        "id": case_id,
        "expected": "accepted",
        "exercise": family,
        "receipt_evidence": evidence,
        "import_record": record,
        "binding_analysis": {
            "verdict": binding_verdict,
            "note": binding_note,
            "refused_widening": True,
        },
        "currentness_analysis": {
            "verdict": currentness_verdict,
            "note": currentness_note,
            "refused_freshness_upgrade": True,
        },
        "admission": {
            "decision": "accepted",
            "reason": "receipt imported as scoped evidence only",
        },
        "aftermath": {
            "record_id": record["import_id"],
            "non_promises": guards,
            "durable_effect": "bounded_receipt_residue_only",
        },
    }


def rejected_case(
    case_id: str,
    *,
    family: str,
    subject_kind: str,
    subject_ref: str,
    evidence_digest: str,
    record_digest: str,
    issuer: str,
    scope_value: dict[str, Any],
    reject_reason: str,
    mutation: str,
) -> dict[str, Any]:
    evidence = receipt_evidence(
        case_id,
        family=family,
        subject_digest=evidence_digest,
        issuer=issuer,
        receipt_claims=["candidate_received"],
        blocked_claims=["must_not_emit_import_record"],
        scope_value=scope_value,
    )
    record = import_record(
        case_id,
        subject_kind=subject_kind,
        subject_ref=subject_ref,
        subject_digest=record_digest,
        family=family,
        issuer=issuer,
        scope_value=scope_value,
        verifier_decision="candidate",
        binding_verdict="subject_digest_matches",
        currentness_verdict="currentness_not_established",
        outcome_class="receipt_observed",
        receipts=[evidence["evidence_id"]],
        non_promises=sorted(RECEIPT_GUARDS[family]),
        receipt_digest=evidence["receipt_digest"],
    )
    binding_verdict = "subject_digest_matches"
    currentness_verdict = "currentness_not_established"
    if mutation == "subject_digest_mismatch":
        binding_verdict = "subject_digest_mismatch"
        record["binding"]["subject_digest_verdict"] = binding_verdict
    elif mutation == "trusted_outcome":
        record["outcome"] = {"class": "trusted", "non_promises": []}
    elif mutation == "fresh_overclaim":
        record["currentness"] = {
            "verdict": "fresh_for_checkpoint_only",
            "revocation_or_compromise_checked": False,
            "freshness_claim": "fresh now because log inclusion exists",
        }
    elif mutation == "issuer_compromise_hidden":
        record["receipt"]["issuer_compromise_status"] = "suppressed"
        record["outcome"]["non_promises"] = [p for p in record["outcome"]["non_promises"] if p not in {"not_auto_true", "not_auto_false", "not_clean_since_compromise"}]
        currentness_verdict = "revocation_or_compromise_recheck_required"
        record["currentness"]["verdict"] = currentness_verdict
    elif mutation == "redaction_full_evidence":
        record["outcome"] = {"class": "full_evidence", "non_promises": []}
        record["binding"]["subject_digest_verdict"] = "redacted_binding_sufficient_for_claims"
        binding_verdict = "redacted_binding_sufficient_for_claims"
    elif mutation == "scope_substitution":
        widened = deepcopy(scope_value)
        widened["audience"] = "global-public"
        widened["surface"] = "all-mirrors-and-agents"
        record["scope"] = widened
        binding_verdict = "scope_substitution_rejected"
    else:
        raise ValueError(f"unknown mutation {mutation}")

    return {
        "id": case_id,
        "expected": "rejected",
        "exercise": family,
        "receipt_evidence": evidence,
        "import_record": {"candidate": record, "mutation": mutation},
        "binding_analysis": {
            "verdict": binding_verdict,
            "note": reject_reason,
            "refused_widening": True,
        },
        "currentness_analysis": {
            "verdict": currentness_verdict,
            "note": reject_reason,
            "refused_freshness_upgrade": True,
        },
        "admission": {
            "decision": "rejected",
            "reason": reject_reason,
        },
        "aftermath": {
            "record_id": None,
            "non_promises": ["no_import_record_emitted", "candidate_retained_as_rejection_residue_only"],
            "durable_effect": "none",
        },
    }


def build_cases() -> list[dict[str, Any]]:
    return [
        accepted_case(
            "accept-scitt-inclusion-scoped",
            family="scitt_inclusion",
            subject_kind="signed_statement",
            subject_ref="scitt://registry.example/entry/alpha",
            subject_digest="sha256:scitt-statement-alpha",
            issuer="issuer:source-owner-alpha",
            scope_value=scope("public-aggregate-a", "public-us", "transparency-registry"),
            receipt_claims=["registered_statement_observed", "subject_digest_bound", "registry_checkpoint_named"],
            blocked_claims=["statement_truth", "policy_satisfaction", "issuer_global_authority"],
            binding_verdict="subject_digest_matches",
            currentness_verdict="currentness_not_established",
            verifier_decision="admit_receipt_only",
            outcome_class="receipt_observed",
            binding_note="SCITT-style inclusion binds a signed statement digest, not the truth of the statement.",
            currentness_note="Inclusion is an observation at a checkpoint; currentness and policy satisfaction remain separate.",
        ),
        accepted_case(
            "accept-c2pa-manifest-binding",
            family="c2pa_manifest",
            subject_kind="media_asset",
            subject_ref="urn:harbor:asset:rendered-chart-a.png",
            subject_digest="sha256:c2pa-chart-render-a",
            issuer="issuer:camera-or-editorial-toolchain",
            scope_value=scope("chart-render-a", "public-web", "content-credential-manifest"),
            receipt_claims=["manifest_present", "active_manifest_selected", "content_binding_checked"],
            blocked_claims=["real_world_authenticity", "editorial_approval", "transform_survival"],
            binding_verdict="subject_digest_matches",
            currentness_verdict="currentness_not_established",
            verifier_decision="admit_manifest_receipt_only",
            outcome_class="manifest_observed",
            binding_note="Manifest binding can identify the asset being described but not whether external reality matches the asset.",
            currentness_note="Credential presence does not show whether later uploads, screenshots, or transcodes preserved it.",
        ),
        accepted_case(
            "accept-intoto-slsa-subject-materials",
            family="intoto_slsa_provenance",
            subject_kind="software_artifact",
            subject_ref="pkg:harbor/example@1.0.0",
            subject_digest="sha256:slsa-artifact-alpha",
            issuer="issuer:build-platform-alpha",
            scope_value=scope("software-artifact-alpha", "consumer-review", "attestation-envelope"),
            receipt_claims=["predicate_type_named", "subject_digest_bound", "builder_identity_present", "materials_list_present"],
            blocked_claims=["dependency_cleanliness", "vulnerability_status", "deployment_truth"],
            binding_verdict="subject_digest_matches",
            currentness_verdict="policy_epoch_bound",
            verifier_decision="admit_provenance_receipt_only",
            outcome_class="provenance_observed",
            binding_note="Subject/materials provenance can describe where and how an artifact was produced without proving all dependency meaning.",
            currentness_note="The verifier decision is bound to one policy epoch and should be recomputed after policy changes.",
        ),
        accepted_case(
            "accept-rekor-ct-inclusion-currentness-split",
            family="rekor_ct_inclusion",
            subject_kind="artifact_signature",
            subject_ref="rekor://uuid/alpha",
            subject_digest="sha256:rekor-entry-alpha",
            issuer="issuer:signer-alpha",
            scope_value=scope("signed-release-alpha", "consumer-review", "transparency-log"),
            receipt_claims=["inclusion_proof_observed", "tree_head_named", "entry_retrievable"],
            blocked_claims=["semantic_approval", "revocation_absence", "future_consistency"],
            binding_verdict="subject_digest_matches",
            currentness_verdict="fresh_for_checkpoint_only",
            verifier_decision="admit_inclusion_receipt_only",
            outcome_class="log_inclusion_observed",
            binding_note="The log entry binds to the searched digest/signature but does not approve the artifact.",
            currentness_note="Freshness is limited to the named checkpoint and recorded checks; later log/issuer state can change the answer.",
        ),
        accepted_case(
            "accept-timestamp-anchor-only",
            family="timestamp_anchor",
            subject_kind="receipt_digest",
            subject_ref="ts://tsa.example/token/alpha",
            subject_digest="sha256:timestamped-receipt-alpha",
            issuer="issuer:tsa-alpha",
            scope_value=scope("receipt-bundle-alpha", "auditor", "timestamp-token"),
            receipt_claims=["timestamp_token_valid", "message_imprint_matches"],
            blocked_claims=["event_time", "source_truth", "currentness"],
            binding_verdict="subject_digest_matches",
            currentness_verdict="timestamp_only",
            verifier_decision="admit_timestamp_anchor_only",
            outcome_class="timestamp_observed",
            binding_note="The anchor binds a message imprint to a timestamping authority response, not to the event described by the message.",
            currentness_note="A timestamp is an ordering/not-before style fact, not a current-state witness.",
        ),
        accepted_case(
            "accept-redacted-derived-proof-claims",
            family="redacted_derived_proof",
            subject_kind="derived_proof_bundle",
            subject_ref="urn:harbor:redacted-proof:alpha",
            subject_digest="sha256:redacted-derived-proof-alpha",
            issuer="issuer:verifier-alpha",
            scope_value=scope("sealed-evidence-alpha", "auditor-redacted", "derived-proof-bundle"),
            receipt_claims=["selected_claims_verified", "base_proof_linked", "redaction_scope_named"],
            blocked_claims=["full_evidence", "no_hidden_contradiction", "recursive_disclosure"],
            binding_verdict="redacted_binding_sufficient_for_claims",
            currentness_verdict="policy_epoch_bound",
            verifier_decision="admit_selected_claims_only",
            outcome_class="selected_claims_observed",
            binding_note="Derived proof supports selected claims only; the unshown base material remains outside the public claim.",
            currentness_note="Verifier policy and disclosure scope control the claim; they do not create timeless evidence access.",
        ),
        accepted_case(
            "accept-issuer-compromise-advisory-recheck",
            family="issuer_compromise_advisory",
            subject_kind="issuer_status",
            subject_ref="issuer:source-owner-alpha#compromise-window",
            subject_digest="sha256:issuer-compromise-advisory-alpha",
            issuer="issuer:incident-response-alpha",
            scope_value=scope("issuer-source-owner-alpha", "harbor-review", "issuer-status-feed"),
            receipt_claims=["compromise_window_reported", "affected_key_set_named", "recheck_required"],
            blocked_claims=["auto_false", "auto_true", "global_revocation"],
            binding_verdict="subject_digest_matches",
            currentness_verdict="revocation_or_compromise_recheck_required",
            verifier_decision="admit_recheck_requirement_only",
            outcome_class="recheck_required",
            binding_note="An issuer-compromise notice is an input to revalidation, not automatic deletion or automatic trust.",
            currentness_note="Currentness is suspended until affected receipts are rechecked against the compromise window and key status.",
        ),
        accepted_case(
            "accept-verifier-policy-decision-epoch",
            family="verifier_policy_decision",
            subject_kind="verifier_result",
            subject_ref="verifier://harbor/policy-run/alpha",
            subject_digest="sha256:verifier-run-alpha",
            issuer="issuer:harbor-local-verifier",
            scope_value=scope("receipt-bundle-alpha", "harbor-review", "local-verifier"),
            receipt_claims=["policy_epoch_named", "decision_trace_digest_bound", "checked_receipt_families_listed"],
            blocked_claims=["content_truth", "future_policy_pass", "compliance"],
            binding_verdict="subject_digest_matches",
            currentness_verdict="policy_epoch_bound",
            verifier_decision="policy_pass_for_scope",
            outcome_class="verifier_decision_observed",
            binding_note="The verifier result is bound to a policy and input digest, not to the world.",
            currentness_note="Policy pass is only for the named epoch, subject, audience, and surface.",
        ),
        rejected_case(
            "reject-subject-digest-mismatch",
            family="intoto_slsa_provenance",
            subject_kind="software_artifact",
            subject_ref="pkg:harbor/example@1.0.0",
            evidence_digest="sha256:slsa-artifact-alpha",
            record_digest="sha256:slsa-artifact-beta",
            issuer="issuer:build-platform-alpha",
            scope_value=scope("software-artifact-alpha", "consumer-review", "attestation-envelope"),
            reject_reason="receipt evidence and import candidate bind different subject digests",
            mutation="subject_digest_mismatch",
        ),
        rejected_case(
            "reject-inclusion-means-trusted",
            family="scitt_inclusion",
            subject_kind="signed_statement",
            subject_ref="scitt://registry.example/entry/beta",
            evidence_digest="sha256:scitt-statement-beta",
            record_digest="sha256:scitt-statement-beta",
            issuer="issuer:source-owner-beta",
            scope_value=scope("public-aggregate-beta", "public-us", "transparency-registry"),
            reject_reason="inclusion evidence was mutated into trusted/true outcome",
            mutation="trusted_outcome",
        ),
        rejected_case(
            "reject-log-inclusion-currentness-overclaim",
            family="rekor_ct_inclusion",
            subject_kind="artifact_signature",
            subject_ref="rekor://uuid/beta",
            evidence_digest="sha256:rekor-entry-beta",
            record_digest="sha256:rekor-entry-beta",
            issuer="issuer:signer-beta",
            scope_value=scope("signed-release-beta", "consumer-review", "transparency-log"),
            reject_reason="log inclusion cannot be upgraded to fresh-now without recorded currentness checks",
            mutation="fresh_overclaim",
        ),
        rejected_case(
            "reject-issuer-compromise-hidden",
            family="issuer_compromise_advisory",
            subject_kind="issuer_status",
            subject_ref="issuer:source-owner-beta#compromise-window",
            evidence_digest="sha256:issuer-compromise-advisory-beta",
            record_digest="sha256:issuer-compromise-advisory-beta",
            issuer="issuer:incident-response-beta",
            scope_value=scope("issuer-source-owner-beta", "harbor-review", "issuer-status-feed"),
            reject_reason="issuer compromise state was hidden while recheck non-promises were stripped",
            mutation="issuer_compromise_hidden",
        ),
        rejected_case(
            "reject-redaction-full-evidence-overclaim",
            family="redacted_derived_proof",
            subject_kind="derived_proof_bundle",
            subject_ref="urn:harbor:redacted-proof:beta",
            evidence_digest="sha256:redacted-derived-proof-beta",
            record_digest="sha256:redacted-derived-proof-beta",
            issuer="issuer:verifier-beta",
            scope_value=scope("sealed-evidence-beta", "auditor-redacted", "derived-proof-bundle"),
            reject_reason="selected/redacted proof was mutated into full-evidence access",
            mutation="redaction_full_evidence",
        ),
        rejected_case(
            "reject-latest-log-wins-scope-substitution",
            family="c2pa_manifest",
            subject_kind="media_asset",
            subject_ref="urn:harbor:asset:rendered-chart-b.png",
            evidence_digest="sha256:c2pa-chart-render-beta",
            record_digest="sha256:c2pa-chart-render-beta",
            issuer="issuer:camera-or-editorial-toolchain",
            scope_value=scope("chart-render-b", "public-web", "content-credential-manifest"),
            reject_reason="newer receipt cannot widen audience/surface scope by being latest",
            mutation="scope_substitution",
        ),
    ]


def build_bundle() -> dict[str, Any]:
    cases = build_cases()
    members = {label: {} for label in MEMBER_LABELS}
    for case in cases:
        cid = case["id"]
        members["case.matrix"][cid] = {
            "expected": case["expected"],
            "exercise": case["exercise"],
        }
        members["input.receipt_evidence"][cid] = case["receipt_evidence"]
        members["input.import_record"][cid] = case["import_record"]
        members["binding.analysis"][cid] = case["binding_analysis"]
        members["currentness.analysis"][cid] = case["currentness_analysis"]
        members["output.admission"][cid] = case["admission"]
        members["output.aftermath"][cid] = case["aftermath"]
        candidate = case["import_record"].get("candidate", case["import_record"])
        members["verdict.summary"][cid] = {
            "admitted": case["expected"] == "accepted",
            "record_digest": digest(candidate),
            "non_promotion_checked": True,
            "reject_reason": None if case["expected"] == "accepted" else case["admission"]["reason"],
        }
    bundle = {
        "schema": SCHEMA,
        "version": VERSION,
        "revision": REVISION,
        "purpose": "deterministic transparency/provenance receipt import pressure; not a durable schema",
        "members": members,
        "global": {
            "case_count": len(cases),
            "accepted_count": sum(1 for c in cases if c["expected"] == "accepted"),
            "rejected_count": sum(1 for c in cases if c["expected"] == "rejected"),
            "non_promotion": [
                "no durable receipt-import schema",
                "no transparency-log reliance policy",
                "no C2PA verifier profile",
                "no SLSA/in-toto predicate profile",
                "no compliance workflow",
                "no global truth or freshness semantics",
            ],
        },
    }
    bundle["bundle_digest"] = digest(bundle)
    return bundle


def main() -> None:
    parser = argparse.ArgumentParser(description="Emit deterministic Harbor transparency/provenance receipt bundle")
    parser.add_argument("--emit-bundle", action="store_true", help="print the deterministic bundle JSON")
    args = parser.parse_args()
    bundle = build_bundle()
    if args.emit_bundle:
        print(json.dumps(bundle, indent=2, ensure_ascii=False))
    else:
        print(bundle["bundle_digest"])


if __name__ == "__main__":
    main()
