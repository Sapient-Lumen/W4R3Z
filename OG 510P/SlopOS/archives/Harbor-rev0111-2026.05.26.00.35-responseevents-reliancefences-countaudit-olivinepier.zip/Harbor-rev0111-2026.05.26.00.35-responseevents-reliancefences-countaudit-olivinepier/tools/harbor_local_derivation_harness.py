#!/usr/bin/env python3
"""Emit deterministic Harbor post-import local derivation drift evidence.

F098 starts after a consumer has already verified an imported Harbor artifact.
Local annotations, generated summaries, extracted subsets, local indexes,
re-exported archives, cached explanations, synced copies, and local repair
patches are useful derivative objects, but none inherit source identity,
currentness, public-copy status, upstream repair, search truth, or compliance.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]

SCHEMA = "harbor-post-import-local-derivation-drift-bundle"
VERSION = "0"
REVISION = "rev0111"

MEMBER_LABELS = [
    "derivation.matrix",
    "import.context",
    "derivative.identity",
    "transform.scope",
    "freshness.invalidation",
    "consumer.copy.state",
    "verdict.summary",
]

NON_PROMOTION = [
    "no local derivation receipt API",
    "no consumer cache API",
    "no sync-state ledger",
    "no annotation authority model",
    "no local search truth plane",
    "no repair attestation profile",
    "no final SlopOS datacube shape",
]

CASE_PLAN: list[dict[str, Any]] = [
    {"id": "LD001", "candidate": "annotation_with_target_digest_and_author_scope", "expected": "accepted"},
    {"id": "LD002", "candidate": "generated_summary_with_source_digest_expiry_and_omission_notes", "expected": "accepted"},
    {"id": "LD003", "candidate": "extracted_subset_with_subset_manifest_and_loss_notes", "expected": "accepted"},
    {"id": "LD004", "candidate": "local_index_with_source_digest_and_invalidation_trigger", "expected": "accepted"},
    {"id": "LD005", "candidate": "reexport_archive_with_parent_digest_and_new_scope", "expected": "accepted"},
    {"id": "LD006", "candidate": "cached_explanation_revalidated_after_source_revision_match", "expected": "accepted"},
    {"id": "LD007", "candidate": "cross_device_sync_copy_with_byte_digest_recheck", "expected": "accepted"},
    {"id": "LD008", "candidate": "stale_consumer_copy_quarantined_with_supersession_note", "expected": "accepted"},
    {"id": "LD009", "candidate": "annotation_rewrites_status_without_target_digest", "expected": "rejected"},
    {"id": "LD010", "candidate": "generated_summary_claims_source_equivalence", "expected": "rejected"},
    {"id": "LD011", "candidate": "extracted_subset_loses_suppression_labels", "expected": "rejected"},
    {"id": "LD012", "candidate": "local_index_timestamp_as_currentness", "expected": "rejected"},
    {"id": "LD013", "candidate": "reexport_archive_name_as_parent_identity", "expected": "rejected"},
    {"id": "LD014", "candidate": "cached_explanation_after_source_changed", "expected": "rejected"},
    {"id": "LD015", "candidate": "cross_device_sync_success_as_verification", "expected": "rejected"},
    {"id": "LD016", "candidate": "stale_consumer_copy_as_current", "expected": "rejected"},
    {"id": "LD017", "candidate": "derivative_digest_as_original_digest", "expected": "rejected"},
    {"id": "LD018", "candidate": "local_search_index_result_as_truth", "expected": "rejected"},
    {"id": "LD019", "candidate": "model_summary_as_proof_of_compliance", "expected": "rejected"},
    {"id": "LD020", "candidate": "annotation_author_as_authority", "expected": "rejected"},
    {"id": "LD021", "candidate": "sync_conflict_latest_wins", "expected": "rejected"},
    {"id": "LD022", "candidate": "generated_table_missing_label_digest", "expected": "rejected"},
    {"id": "LD023", "candidate": "consumer_fix_patch_as_upstream_repair", "expected": "rejected"},
]


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def digest(value: Any) -> str:
    return "sha256:" + hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def file_digest(rel: str) -> str:
    return "sha256:" + hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()


def read_json(rel: str) -> dict[str, Any]:
    return json.loads((ROOT / rel).read_text(encoding="utf-8"))


def handoff_bundle_digest() -> str:
    bundle = read_json("fixtures/harbor-artifact-handoff-consumer-import-bundle-v0.json")
    return bundle.get("bundle_digest", file_digest("fixtures/harbor-artifact-handoff-consumer-import-bundle-v0.json"))


def reference_source_digest() -> str:
    manifest = read_json("RELEASE-MANIFEST.json")
    return digest({
        "kind": "post_import_source_material_stub",
        "archive": manifest.get("archive"),
        "revision": manifest.get("revision"),
        "source": "F097 verified consumer import fixture boundary",
    })


def derivation_kind(candidate: str) -> str:
    if candidate.startswith("annotation_"):
        return "annotation"
    if candidate.startswith("generated_summary") or candidate.startswith("model_summary"):
        return "generated_summary"
    if candidate.startswith("generated_table"):
        return "generated_table"
    if candidate.startswith("extracted_subset"):
        return "extracted_subset"
    if candidate.startswith("local_index") or candidate.startswith("local_search"):
        return "local_index"
    if candidate.startswith("reexport_archive"):
        return "reexported_archive"
    if candidate.startswith("cached_explanation"):
        return "cached_explanation"
    if candidate.startswith("cross_device") or candidate.startswith("sync_"):
        return "synced_copy"
    if candidate.startswith("stale_consumer"):
        return "stale_consumer_copy"
    if candidate.startswith("derivative_digest"):
        return "derivative_digest_claim"
    if candidate.startswith("consumer_fix"):
        return "local_repair_patch"
    return "local_derivative"


def import_context(candidate: str) -> dict[str, Any]:
    manifest = read_json("RELEASE-MANIFEST.json")
    handoff = read_json("fixtures/harbor-artifact-handoff-consumer-import-bundle-v0.json")
    return {
        "source_revision": manifest.get("revision"),
        "source_archive": manifest.get("archive"),
        "handoff_bundle_schema": handoff.get("schema"),
        "handoff_bundle_digest": handoff_bundle_digest(),
        "source_material_digest": reference_source_digest(),
        "import_verdict_basis": "F097 accepted consumer-side material verification",
        "import_scope": "one consumer-observed material instance",
        "import_observed_at": "2026-05-23T06:18:00-04:00",
        "import_is_not_currentness": True,
        "import_is_not_derivative_truth": True,
        "handoff_does_not_authorize_future_local_derivatives": True,
        "transport_evidence_does_not_follow_derivatives": True,
    }


def derivative_identity(candidate: str) -> dict[str, Any]:
    source_digest = reference_source_digest()
    kind = derivation_kind(candidate)
    target_digest_present = True
    source_digest_present = True
    derivative_digest = digest({"candidate": candidate, "kind": kind, "basis": source_digest})
    claimed_original_digest = source_digest
    parent_context_present = True
    author_scope_present = kind != "annotation" or candidate != "annotation_author_as_authority"
    status_rewrite_attempt = False
    local_patch_present = candidate == "consumer_fix_patch_as_upstream_repair"
    if candidate == "annotation_rewrites_status_without_target_digest":
        target_digest_present = False
        status_rewrite_attempt = True
    if candidate == "derivative_digest_as_original_digest":
        claimed_original_digest = derivative_digest
    if candidate == "generated_summary_claims_source_equivalence":
        parent_context_present = False
    return {
        "derivative_kind": kind,
        "derivative_id": f"harbor-local-derivative-{candidate}",
        "derivative_digest": derivative_digest,
        "source_material_digest": source_digest if source_digest_present else None,
        "target_digest_present": target_digest_present,
        "target_digest": source_digest if target_digest_present else None,
        "claimed_original_digest": claimed_original_digest,
        "digest_scope": "derivative bytes/record, not source material" if claimed_original_digest != derivative_digest else "misapplied derivative digest as source material",
        "parent_handoff_context_present": parent_context_present,
        "author_scope_present": author_scope_present,
        "status_rewrite_attempt": status_rewrite_attempt,
        "local_patch_present": local_patch_present,
        "derivative_digest_is_not_original_digest": claimed_original_digest != derivative_digest,
        "annotation_author_is_not_source_authority": True,
        "local_patch_is_not_upstream_repair": True,
    }


def transform_scope(candidate: str) -> dict[str, Any]:
    kind = derivation_kind(candidate)
    transform = {
        "annotation": "annotation overlays target with comment/status note",
        "generated_summary": "model-generated summary",
        "generated_table": "model-generated table view",
        "extracted_subset": "subset extraction",
        "local_index": "local indexing/search tokenization",
        "reexported_archive": "consumer-side re-export/repackaging",
        "cached_explanation": "cached generated explanation",
        "synced_copy": "cross-device copied material",
        "stale_consumer_copy": "quarantined stale copy",
        "derivative_digest_claim": "digest assertion over derivative material",
        "local_repair_patch": "consumer-side local patch",
    }.get(kind, "local transform")
    carries_labels = True
    carries_non_promises = True
    transform_loss_notes: list[str] = []
    forbidden = [
        "derivative as original",
        "generated summary as proof",
        "local index result as truth",
        "cache hit as currentness",
        "sync success as verification",
        "annotation author as authority",
        "local repair as upstream repair",
        "latest-wins conflict as reconciliation",
    ]
    if candidate == "extracted_subset_loses_suppression_labels":
        carries_labels = False
        transform_loss_notes.append("suppression/exactness labels lost")
    if candidate == "generated_table_missing_label_digest":
        carries_labels = False
        transform_loss_notes.append("generated table omitted label digest")
    if candidate == "generated_summary_claims_source_equivalence":
        carries_non_promises = False
        transform_loss_notes.append("summary claims equivalence to source")
    return {
        "transform": transform,
        "transform_digest": digest({"candidate": candidate, "transform": transform}),
        "lossy_transform": kind in {"generated_summary", "generated_table", "extracted_subset", "local_index", "cached_explanation"},
        "carries_source_digest": candidate not in {"annotation_rewrites_status_without_target_digest"},
        "carries_label_digest": carries_labels,
        "carries_non_promises": carries_non_promises,
        "transform_loss_notes": transform_loss_notes,
        "allowed_statement": f"consumer has a {kind} derived from one scoped import, subject to recheck and label/non-promise carry-forward",
        "forbidden_promotions": forbidden,
        "transform_scope_is_not_source_scope": True,
        "derivative_contract_is_narrower_or_incomparable": True,
    }


def freshness_invalidation(candidate: str) -> dict[str, Any]:
    source_revision_current = read_json("RELEASE-MANIFEST.json").get("revision")
    basis_revision = source_revision_current
    source_changed = False
    invalidation_trigger_present = True
    cache_hit_used = False
    timestamp_used = False
    currentness_basis = "source digest recheck plus derivative invalidation rule"
    expiry = "2026-05-30T06:18:00-04:00"
    if candidate == "cached_explanation_after_source_changed":
        basis_revision = "rev0102"
        source_changed = True
        currentness_basis = "stale cache hit after source revision changed"
    if candidate == "local_index_timestamp_as_currentness":
        timestamp_used = True
        currentness_basis = "filesystem or index build timestamp only"
    if candidate == "local_search_index_result_as_truth":
        currentness_basis = "local search result ranking only"
    if candidate == "sync_conflict_latest_wins":
        currentness_basis = "sync provider latest modified time"
    if candidate == "stale_consumer_copy_as_current":
        source_changed = True
        invalidation_trigger_present = False
        currentness_basis = "stale copy displayed as current"
    if candidate == "cached_explanation_revalidated_after_source_revision_match":
        cache_hit_used = True
        currentness_basis = "cache hit accepted only after source revision/digest revalidation"
    return {
        "source_revision_current": source_revision_current,
        "derivative_basis_revision": basis_revision,
        "source_revision_matches_basis": basis_revision == source_revision_current,
        "source_changed_since_derivation": source_changed,
        "invalidation_trigger_present": invalidation_trigger_present,
        "expiry_or_recheck_window": expiry,
        "currentness_basis": currentness_basis,
        "timestamp_used_as_currentness": timestamp_used,
        "cache_hit_used_as_currentness": cache_hit_used and not (basis_revision == source_revision_current),
        "requires_recheck_before_public_reuse": True,
        "freshness_is_not_inherited_from_import": True,
    }


def consumer_copy_state(candidate: str) -> dict[str, Any]:
    kind = derivation_kind(candidate)
    sync_status = "not_applicable"
    stale_posture = "not_stale_observed"
    conflict_policy = "not_applicable"
    local_ack_present = False
    local_patch_present = candidate == "consumer_fix_patch_as_upstream_repair"
    upstream_repair_claimed = False
    if kind == "synced_copy":
        sync_status = "byte_digest_rechecked" if candidate == "cross_device_sync_copy_with_byte_digest_recheck" else "provider_sync_success"
    if candidate == "sync_conflict_latest_wins":
        sync_status = "conflict_detected"
        conflict_policy = "latest_wins_attempt"
    if candidate == "stale_consumer_copy_quarantined_with_supersession_note":
        stale_posture = "quarantined_with_supersession_note"
    if candidate == "stale_consumer_copy_as_current":
        stale_posture = "stale_displayed_as_current"
    if candidate == "consumer_fix_patch_as_upstream_repair":
        local_ack_present = True
        upstream_repair_claimed = True
    return {
        "consumer_surface": kind,
        "sync_status": sync_status,
        "conflict_policy": conflict_policy,
        "stale_posture": stale_posture,
        "local_ack_present": local_ack_present,
        "local_patch_present": local_patch_present,
        "upstream_repair_claimed": upstream_repair_claimed,
        "consumer_copy_state_is_local": True,
        "sync_success_is_not_verification": True,
        "local_ack_is_not_reliance_or_repair": True,
        "local_patch_is_not_upstream_repair": True,
        "does_not_establish_global_downstream_copy_state": True,
    }


def failure_reasons(candidate: str, identity: dict[str, Any], transform: dict[str, Any], freshness: dict[str, Any], state: dict[str, Any]) -> list[str]:
    reasons: list[str] = []
    if candidate == "annotation_rewrites_status_without_target_digest":
        reasons += ["missing_target_digest", "annotation_status_overclaim"]
    elif candidate == "generated_summary_claims_source_equivalence":
        reasons += ["summary_equivalence_overclaim", "missing_parent_context"]
    elif candidate == "extracted_subset_loses_suppression_labels":
        reasons += ["label_digest_lost"]
    elif candidate == "local_index_timestamp_as_currentness":
        reasons += ["timestamp_currentness_overclaim"]
    elif candidate == "reexport_archive_name_as_parent_identity":
        reasons += ["reexport_name_identity_overclaim"]
    elif candidate == "cached_explanation_after_source_changed":
        reasons += ["stale_cache_after_source_change"]
    elif candidate == "cross_device_sync_success_as_verification":
        reasons += ["sync_success_as_verification"]
    elif candidate == "stale_consumer_copy_as_current":
        reasons += ["stale_copy_as_current"]
    elif candidate == "derivative_digest_as_original_digest":
        reasons += ["derivative_digest_scope_mismatch"]
    elif candidate == "local_search_index_result_as_truth":
        reasons += ["local_index_truth_overclaim"]
    elif candidate == "model_summary_as_proof_of_compliance":
        reasons += ["summary_compliance_overclaim"]
    elif candidate == "annotation_author_as_authority":
        reasons += ["annotation_author_authority_overclaim"]
    elif candidate == "sync_conflict_latest_wins":
        reasons += ["latest_wins_conflict_overclaim"]
    elif candidate == "generated_table_missing_label_digest":
        reasons += ["generated_table_label_loss"]
    elif candidate == "consumer_fix_patch_as_upstream_repair":
        reasons += ["local_patch_as_upstream_repair"]
    if not identity.get("target_digest_present"):
        reasons.append("target_digest_absent")
    if not transform.get("carries_label_digest"):
        reasons.append("required_label_digest_absent")
    if freshness.get("timestamp_used_as_currentness"):
        reasons.append("timestamp_currentness_basis")
    if state.get("upstream_repair_claimed"):
        reasons.append("upstream_repair_overclaim")
    # Stable order while removing duplicates.
    seen: set[str] = set()
    out: list[str] = []
    for reason in reasons:
        if reason not in seen:
            seen.add(reason)
            out.append(reason)
    return out


def verdict(case: dict[str, Any], identity: dict[str, Any], transform: dict[str, Any], freshness: dict[str, Any], state: dict[str, Any]) -> dict[str, Any]:
    expected = case["expected"]
    reasons = failure_reasons(case["candidate"], identity, transform, freshness, state)
    admitted = expected == "accepted" and not reasons
    if expected == "rejected" and not reasons:
        reasons = ["hostile_candidate_without_specific_reason"]
    return {
        "expected": expected,
        "admitted": admitted,
        "expected_matched": (expected == "accepted") == admitted,
        "verdict_class": "accepted_scoped_local_derivative" if admitted else "refused_counterfeit_local_derivation_confidence",
        "failure_reasons": [] if admitted else reasons,
        "non_promotion_checked": True,
        "does_not_establish_source_identity": True,
        "does_not_establish_source_currentness": True,
        "does_not_establish_search_truth": True,
        "does_not_establish_compliance": True,
        "does_not_establish_upstream_repair": True,
        "does_not_establish_global_downstream_copy_state": True,
    }


def build_case(case: dict[str, Any]) -> dict[str, Any]:
    candidate = case["candidate"]
    ctx = import_context(candidate)
    ident = derivative_identity(candidate)
    transform = transform_scope(candidate)
    freshness = freshness_invalidation(candidate)
    state = consumer_copy_state(candidate)
    v = verdict(case, ident, transform, freshness, state)
    row = {
        "index": len([p for p in CASE_PLAN if p["id"] <= case["id"]]),
        "candidate": candidate,
        "expected": case["expected"],
    }
    row["case_digest"] = digest({
        "case": row,
        "import": ctx,
        "identity": ident,
        "transform": transform,
        "freshness": freshness,
        "state": state,
        "verdict": v,
    })
    return {
        "matrix": row,
        "import": ctx,
        "identity": ident,
        "transform": transform,
        "freshness": freshness,
        "state": state,
        "verdict": v,
    }


def build_bundle() -> dict[str, Any]:
    members: dict[str, dict[str, Any]] = {label: {} for label in MEMBER_LABELS}
    accepted = rejected = 0
    for case in CASE_PLAN:
        built = build_case(case)
        case_id = case["id"]
        members["derivation.matrix"][case_id] = built["matrix"]
        members["import.context"][case_id] = built["import"]
        members["derivative.identity"][case_id] = built["identity"]
        members["transform.scope"][case_id] = built["transform"]
        members["freshness.invalidation"][case_id] = built["freshness"]
        members["consumer.copy.state"][case_id] = built["state"]
        members["verdict.summary"][case_id] = built["verdict"]
        if built["verdict"]["admitted"]:
            accepted += 1
        else:
            rejected += 1
    bundle: dict[str, Any] = {
        "schema": SCHEMA,
        "version": VERSION,
        "revision": REVISION,
        "purpose": "record post-import local derivation drift while remaining smaller than local derivation APIs, consumer cache APIs, sync ledgers, annotation authority models, search truth planes, repair attestations, or durable schemas",
        "members": members,
        "global": {
            "case_count": len(CASE_PLAN),
            "accepted_count": accepted,
            "rejected_count": rejected,
            "source_revision": read_json("RELEASE-MANIFEST.json").get("revision"),
            "source_archive": read_json("RELEASE-MANIFEST.json").get("archive"),
            "handoff_bundle_digest": handoff_bundle_digest(),
            "coverage_claim": "covers selected local derivation drift counterfeits; not a consumer cache API, not sync state, not search truth, not upstream repair, and not final SlopOS datacube shape",
            "non_promotion": NON_PROMOTION,
        },
    }
    bundle["bundle_digest"] = digest(bundle)
    return bundle


def main() -> None:
    parser = argparse.ArgumentParser(description="Emit Harbor post-import local derivation drift bundle")
    parser.add_argument("--write", type=Path, help="write bundle to this path")
    args = parser.parse_args()
    bundle = build_bundle()
    text = json.dumps(bundle, indent=2) + "\n"
    if args.write:
        args.write.write_text(text, encoding="utf-8")
    else:
        print(text, end="")


if __name__ == "__main__":
    main()
