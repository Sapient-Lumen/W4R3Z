#!/usr/bin/env python3
"""Check the deterministic Harbor derivative correction propagation bundle."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

import harbor_derivative_repair_harness as harness  # noqa: E402


def fail(message: str) -> None:
    print(message)
    raise SystemExit(1)


def expect(condition: bool, message: str) -> None:
    if not condition:
        fail(message)


def check_bundle(bundle: dict[str, Any]) -> None:
    expect(bundle.get("schema") == harness.SCHEMA, "Unexpected bundle schema")
    expect(bundle.get("version") == harness.VERSION, "Unexpected bundle version")
    expect(bundle.get("revision") == harness.REVISION, "Unexpected bundle revision")
    expect(bundle.get("purpose", "").endswith("not a durable schema"), "Purpose must refuse durable schema promotion")
    expected_digest = harness.digest({k: v for k, v in bundle.items() if k != "bundle_digest"})
    expect(bundle.get("bundle_digest") == expected_digest, "Bundle digest drift")

    members = bundle.get("members")
    expect(isinstance(members, dict), "Bundle members must be an object")
    expect(list(members.keys()) == harness.MEMBER_LABELS, "Member labels/order drift")

    matrix = members["repair.matrix"]
    expect(len(matrix) == len(harness.CASE_PLAN), "F099 bundle case-count drift")
    for label in harness.MEMBER_LABELS[1:]:
        expect(list(members[label].keys()) == list(matrix.keys()), f"Case id/order drift in {label}")

    accepted = rejected = 0
    seen_indexes: list[int] = []
    seen_candidates: set[str] = set()
    for case_id, row in matrix.items():
        seen_indexes.append(row.get("index"))
        candidate = row.get("candidate")
        expected = row.get("expected")
        seen_candidates.add(candidate)
        expect(expected in {"accepted", "rejected"}, f"{case_id}: invalid expected outcome")
        expect(candidate, f"{case_id}: missing candidate")
        expect(row.get("digest") == harness.row_digest(case_id, candidate, expected), f"{case_id}: row digest drift")

        source = members["source.correction"][case_id]
        inventory = members["derivative.inventory"][case_id]
        notice = members["propagation.notice"][case_id]
        invalidation = members["invalidation.action"][case_id]
        ack = members["consumer.acknowledgement"][case_id]
        state = members["derivative.state"][case_id]
        verdict = members["verdict.summary"][case_id]

        for field in ["prior_source_digest", "corrected_source_digest", "delta_digest"]:
            expect(isinstance(source.get(field), str) and source[field].startswith("sha256:"), f"{case_id}: source {field} missing digest")
        expect(source.get("correction_is_not_global_repair") is True, f"{case_id}: global-repair refusal missing")
        expect(source.get("correction_is_not_consumer_compliance") is True, f"{case_id}: compliance refusal missing")
        expect(source.get("latest_correction_is_not_default_winner") is True, f"{case_id}: latest-wins refusal missing")

        for field in ["prior_derivative_digest", "basis_source_digest", "basis_local_derivation_bundle_digest"]:
            expect(isinstance(inventory.get(field), str) and inventory[field].startswith("sha256:"), f"{case_id}: inventory {field} missing digest")
        expect(inventory.get("inventory_is_observation_not_reachability") is True, f"{case_id}: inventory reachability refusal missing")
        expect(inventory.get("inventory_does_not_prove_current_derivative_state") is True, f"{case_id}: inventory state refusal missing")

        expect(notice.get("target_derivative_digest") == inventory.get("prior_derivative_digest"), f"{case_id}: notice target digest mismatch")
        expect(notice.get("correction_delta_digest") == source.get("delta_digest"), f"{case_id}: correction delta mismatch")
        expect(notice.get("notice_delivery_is_not_repair") is True, f"{case_id}: notice-as-repair refusal missing")
        expect(notice.get("notice_delivery_is_not_user_read") is True, f"{case_id}: read receipt refusal missing")
        expect(notice.get("broadcast_is_not_complete_reachability") is True, f"{case_id}: broadcast reachability refusal missing")

        expect(invalidation.get("repair_requires_material_state_evidence") is True, f"{case_id}: material-state guard missing")
        expect(invalidation.get("invalidation_is_not_repair_without_output_check") is True, f"{case_id}: invalidation-as-repair refusal missing")
        if invalidation.get("corrected_source_digest") is not None:
            expect(invalidation.get("corrected_source_digest") == source.get("corrected_source_digest"), f"{case_id}: corrected source digest mismatch")

        expect(ack.get("expected_derivative_digest") == inventory.get("prior_derivative_digest"), f"{case_id}: ack expected digest mismatch")
        expect(ack.get("ack_is_not_source_authority") is True, f"{case_id}: ack source-authority refusal missing")
        expect(ack.get("ack_is_not_compliance") is True, f"{case_id}: ack compliance refusal missing")
        if ack.get("ack_type") == "notice_received":
            expect(ack.get("ack_is_not_repair") is True, f"{case_id}: notice ack must remain non-repair")

        expect(state.get("state_is_not_downstream_global_truth") is True, f"{case_id}: state global-truth refusal missing")
        expect(state.get("state_is_not_compliance") is True, f"{case_id}: state compliance refusal missing")
        expect(state.get("state_is_not_notification_read_receipt") is True, f"{case_id}: state read-receipt refusal missing")

        expect(verdict.get("candidate") == candidate, f"{case_id}: verdict candidate drift")
        expect(verdict.get("expected") == expected, f"{case_id}: verdict expected drift")
        expect(verdict.get("expected_matched") is True, f"{case_id}: verdict did not match expected")
        expect(verdict.get("does_not_turn_notice_into_repair") is True, f"{case_id}: notice non-promotion missing")
        expect(verdict.get("does_not_turn_ack_into_repair") is True, f"{case_id}: ack non-promotion missing")
        expect(verdict.get("does_not_turn_sync_green_into_verification") is True, f"{case_id}: sync non-promotion missing")
        expect(verdict.get("does_not_turn_quarantine_into_repair") is True, f"{case_id}: quarantine non-promotion missing")
        for phrase in ["not global downstream repair", "not all derivatives reached", "not user-read evidence", "not compliance"]:
            expect(phrase in verdict.get("non_promises", []), f"{case_id}: missing non-promise {phrase}")

        if verdict.get("admitted"):
            accepted += 1
            expect(expected == "accepted", f"{case_id}: admitted rejected candidate")
            expect(not verdict.get("failure_reasons"), f"{case_id}: admitted with failure reasons")
            if candidate in {"notice_received_acknowledged_not_repaired", "partial_propagation_unknown_surfaces_preserved", "stale_consumer_copy_quarantined_unreached"}:
                expect(state.get("verified_after_action") is False, f"{case_id}: partial/quarantine/notice-only case must not become repair")
            else:
                expect(state.get("verified_after_action") is True, f"{case_id}: accepted repair case lacks material verification")
        else:
            rejected += 1
            expect(expected == "rejected", f"{case_id}: rejected accepted candidate")
            expect(verdict.get("verdict_class") == "refused_counterfeit_derivative_repair", f"{case_id}: rejected verdict class drift")
            expect(verdict.get("failure_reasons"), f"{case_id}: rejected case lacks failure reasons")

        if candidate == "notice_acknowledgement_claims_repair":
            expect("acknowledgement_as_repair" in verdict["failure_reasons"], f"{case_id}: ack-as-repair reason absent")
            expect(ack.get("ack_claims_repair_without_material_evidence") is True, f"{case_id}: ack repair overclaim not represented")
        elif candidate == "broadcast_delivery_claims_all_derivatives_reached":
            expect("broadcast_reachability_overclaim" in verdict["failure_reasons"], f"{case_id}: broadcast reason absent")
            expect(notice.get("attempted_all_reached_claim") is True, f"{case_id}: all-reached claim not represented")
        elif candidate == "index_invalidated_but_search_current_claimed":
            expect("index_currentness_overclaim" in verdict["failure_reasons"], f"{case_id}: index reason absent")
            expect(invalidation.get("search_surface_current_claimed") is True, f"{case_id}: search current claim not represented")
        elif candidate == "rebuilt_summary_missing_corrected_source_digest":
            expect("missing_corrected_source_digest" in verdict["failure_reasons"], f"{case_id}: missing digest reason absent")
            expect(invalidation.get("corrected_source_digest_present") is False, f"{case_id}: missing digest not represented")
        elif candidate == "cache_refresh_without_source_revalidation":
            expect("cache_refresh_without_revalidation" in verdict["failure_reasons"], f"{case_id}: cache reason absent")
            expect(invalidation.get("source_revalidation_performed") is False, f"{case_id}: source revalidation not represented")
        elif candidate == "sync_provider_green_as_digest_verification":
            expect("sync_green_as_digest_verification" in verdict["failure_reasons"], f"{case_id}: sync reason absent")
            expect(state.get("sync_provider_status") == "green", f"{case_id}: sync green not represented")
        elif candidate == "local_patch_deletes_warning_labels":
            expect("warning_label_loss" in verdict["failure_reasons"], f"{case_id}: warning label reason absent")
            expect(inventory.get("label_digest_preserved_after_repair") is False, f"{case_id}: label loss not represented")
        elif candidate == "stale_copy_silent_superseded_as_current":
            expect("silent_supersession_currentness" in verdict["failure_reasons"], f"{case_id}: silent supersession reason absent")
            expect(invalidation.get("supersession_visible") is False, f"{case_id}: supersession invisibility not represented")
        elif candidate == "consumer_repair_ack_claims_compliance":
            expect("consumer_compliance_overclaim" in verdict["failure_reasons"], f"{case_id}: compliance reason absent")
            expect(ack.get("ack_claims_compliance") is True, f"{case_id}: compliance overclaim not represented")
        elif candidate == "repair_ack_wrong_derivative_digest":
            expect("ack_derivative_digest_mismatch" in verdict["failure_reasons"], f"{case_id}: digest mismatch reason absent")
            expect(ack.get("ack_digest_matches_target") is False, f"{case_id}: wrong ack digest not represented")
        elif candidate == "reexport_overwrites_parent_identity":
            expect("reexport_parent_identity_overwrite" in verdict["failure_reasons"], f"{case_id}: parent identity reason absent")
            expect(inventory.get("parent_identity_overwrite_attempt") is True, f"{case_id}: overwrite not represented")
        elif candidate == "notification_delivery_as_read_and_applied":
            expect("notification_delivery_as_read_applied" in verdict["failure_reasons"], f"{case_id}: notification reason absent")
            expect(notice.get("delivery_as_read_or_applied_claim") is True, f"{case_id}: delivery-as-applied not represented")
        elif candidate == "latest_correction_wins_without_scope_map":
            expect("missing_correction_scope_map" in verdict["failure_reasons"], f"{case_id}: missing scope-map reason absent")
            expect(source.get("scope_map_present") is False, f"{case_id}: missing scope map not represented")
        elif candidate == "summary_repaired_index_stale_global_closure":
            expect("global_closure_with_stale_derivative" in verdict["failure_reasons"], f"{case_id}: stale neighbor reason absent")
            expect(state.get("global_closure_claimed") is True, f"{case_id}: global closure not represented")
        elif candidate == "unreachable_device_assumed_repaired_after_expiry":
            expect("unreachable_device_assumed_repaired" in verdict["failure_reasons"], f"{case_id}: unreachable reason absent")
            expect(state.get("unreached_surfaces_preserved") is True, f"{case_id}: unreached surfaces not represented")
        elif candidate == "ack_signer_as_source_authority":
            expect("ack_signer_authority_overclaim" in verdict["failure_reasons"], f"{case_id}: signer authority reason absent")
            expect(ack.get("ack_signer_has_source_authority") is True, f"{case_id}: signer authority not represented")

    expect(seen_indexes == list(range(1, len(matrix) + 1)), "F099 indexes must be gapless")
    expect(seen_candidates == {plan["candidate"] for plan in harness.CASE_PLAN}, "Not all F099 candidate classes are represented")

    global_ = bundle.get("global", {})
    expect(global_.get("case_count") == len(matrix), "Global case_count drift")
    expect(global_.get("accepted_count") == accepted, "Global accepted_count drift")
    expect(global_.get("rejected_count") == rejected, "Global rejected_count drift")
    expect(global_.get("source_revision") == harness.REVISION, "Global source revision drift")
    expect(global_.get("local_derivation_bundle_digest") == harness.local_derivation_bundle_digest(), "Global local-derivation bundle digest drift")
    expect("not a derivative invalidation ledger" in global_.get("coverage_claim", ""), "Coverage claim must refuse invalidation-ledger promotion")
    for refusal in harness.NON_PROMOTION:
        expect(refusal in global_.get("non_promotion", []), f"Global non-promotion list missing {refusal}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Check Harbor derivative correction propagation bundle")
    parser.add_argument("--fixture", type=Path, default=ROOT / "fixtures" / "harbor-derivative-correction-propagation-bundle-v0.json")
    args = parser.parse_args()

    expected = harness.build_bundle()
    check_bundle(expected)
    if args.fixture.exists():
        actual = json.loads(args.fixture.read_text(encoding="utf-8"))
        expect(actual == expected, "Checked fixture does not match deterministic harness output")
    else:
        fail(f"Fixture missing: {args.fixture}")
    print("Harbor derivative correction propagation bundle check passed")


if __name__ == "__main__":
    main()
