#!/usr/bin/env python3
"""Emit deterministic Harbor overlapping-correction lineage evidence.

F101 starts after repair receipts can be retained and expire. The new pressure
is that a source may be corrected more than once while derivatives are repaired,
quarantined, rebased, rolled back, disputed, or split across scopes. This
harness keeps correction epoch, derivative lineage, scope overlap, rebase maps,
currentness windows, consumer state, and public badge posture separate. No
latest correction, oldest receipt, source-owner closure, or rollback event can
collapse the lineage into a global currentness claim.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]

SCHEMA = "harbor-overlapping-correction-lineage-bundle"
VERSION = "0"
REVISION = "rev0111"

MEMBER_LABELS = [
    "lineage.matrix",
    "source.epoch",
    "derivative.lineage",
    "repair.action",
    "scope.reconciliation",
    "currentness.window",
    "consumer.state",
    "verdict.summary",
]

NON_PROMOTION = [
    "no correction-epoch registry",
    "no derivative repair ledger",
    "no conflict-resolution engine",
    "no source-owner closure authority",
    "no public badge workflow",
    "no consumer cache API",
    "no compliance workflow",
    "no final SlopOS datacube shape",
]

CASE_PLAN: list[dict[str, Any]] = [
    {"id": "OL001", "candidate": "linear_epoch_chain_repair_to_latest_scoped", "expected": "accepted"},
    {"id": "OL002", "candidate": "epoch_a_repair_retained_history_after_epoch_b", "expected": "accepted"},
    {"id": "OL003", "candidate": "disjoint_corrections_coexist_without_latest_wins", "expected": "accepted"},
    {"id": "OL004", "candidate": "overlapping_corrections_split_derivative_state_by_scope", "expected": "accepted"},
    {"id": "OL005", "candidate": "rollback_epoch_reopens_prior_repair_with_history", "expected": "accepted"},
    {"id": "OL006", "candidate": "partial_subset_repaired_epoch_b_others_epoch_a_history", "expected": "accepted"},
    {"id": "OL007", "candidate": "consumer_patch_rebased_onto_epoch_b_with_delta_map", "expected": "accepted"},
    {"id": "OL008", "candidate": "stale_epoch_a_ack_preserved_as_residue", "expected": "accepted"},
    {"id": "OL009", "candidate": "conflicting_external_epoch_requires_dispute_state", "expected": "accepted"},
    {"id": "OL010", "candidate": "epoch_b_supersedes_named_fields_only", "expected": "accepted"},
    {"id": "OL011", "candidate": "latest_epoch_wins_without_scope_overlap_map", "expected": "rejected"},
    {"id": "OL012", "candidate": "epoch_a_repair_claims_current_after_epoch_b_overlap", "expected": "rejected"},
    {"id": "OL013", "candidate": "rollback_erases_intermediate_warning_history", "expected": "rejected"},
    {"id": "OL014", "candidate": "disjoint_correction_marked_conflict", "expected": "rejected"},
    {"id": "OL015", "candidate": "overlapping_correction_merged_without_delta_map", "expected": "rejected"},
    {"id": "OL016", "candidate": "consumer_patch_applied_to_wrong_epoch_base", "expected": "rejected"},
    {"id": "OL017", "candidate": "ack_for_epoch_a_counts_for_epoch_b", "expected": "rejected"},
    {"id": "OL018", "candidate": "derivative_digest_reused_across_epochs", "expected": "rejected"},
    {"id": "OL019", "candidate": "missing_epoch_order_or_clock_basis", "expected": "rejected"},
    {"id": "OL020", "candidate": "parallel_epochs_total_ordered_without_authority", "expected": "rejected"},
    {"id": "OL021", "candidate": "field_scope_widened_to_whole_artifact", "expected": "rejected"},
    {"id": "OL022", "candidate": "stale_subset_marked_global_current", "expected": "rejected"},
    {"id": "OL023", "candidate": "dispute_epoch_treated_as_repair", "expected": "rejected"},
    {"id": "OL024", "candidate": "source_owner_closure_overrides_lineage", "expected": "rejected"},
    {"id": "OL025", "candidate": "retention_expiry_ignored_in_lineage_currentness", "expected": "rejected"},
    {"id": "OL026", "candidate": "public_badge_green_across_mixed_epochs", "expected": "rejected"},
    {"id": "OL027", "candidate": "material_rollback_without_recheck", "expected": "rejected"},
    {"id": "OL028", "candidate": "cycle_in_lineage_graph", "expected": "rejected"},
]


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def digest(value: Any) -> str:
    return "sha256:" + hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def file_digest(rel: str) -> str:
    return "sha256:" + hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()


def read_json(rel: str) -> dict[str, Any]:
    return json.loads((ROOT / rel).read_text(encoding="utf-8"))


def retention_bundle_digest() -> str:
    bundle = read_json("fixtures/harbor-derivative-repair-retention-expiry-bundle-v0.json")
    return bundle.get("bundle_digest", file_digest("fixtures/harbor-derivative-repair-retention-expiry-bundle-v0.json"))


def source_material_digest() -> str:
    manifest = read_json("RELEASE-MANIFEST.json")
    return digest({
        "kind": "f101_source_material_stub",
        "archive": manifest.get("archive"),
        "revision": manifest.get("revision"),
        "basis": retention_bundle_digest(),
    })


def epoch_digest(epoch_id: str) -> str:
    return digest({"kind": "f101_correction_epoch", "epoch_id": epoch_id, "prior": source_material_digest()})


def derivative_digest(candidate: str, epoch_id: str, phase: str = "post_repair") -> str:
    return digest({
        "kind": "f101_derivative",
        "candidate": candidate,
        "epoch": epoch_id,
        "phase": phase,
        "basis": source_material_digest(),
    })


def primary_epoch(candidate: str) -> str:
    if "epoch_a" in candidate or "wrong_epoch_base" in candidate:
        return "epoch-a"
    if "rollback" in candidate:
        return "epoch-rollback"
    if "dispute" in candidate or "conflicting_external" in candidate:
        return "epoch-dispute"
    if "parallel" in candidate:
        return "epoch-parallel-2"
    return "epoch-b"


def scope_relation(candidate: str) -> str:
    if "disjoint" in candidate:
        return "disjoint"
    if "split" in candidate or "partial_subset" in candidate or "mixed" in candidate or "stale_subset" in candidate:
        return "partial_overlap"
    if "dispute" in candidate or "conflicting_external" in candidate:
        return "conflict_unresolved"
    if "parallel" in candidate:
        return "parallel_incomparable"
    if "missing_epoch_order" in candidate:
        return "unknown"
    return "overlap"


def source_epoch(candidate: str) -> dict[str, Any]:
    missing_clock = candidate == "missing_epoch_order_or_clock_basis"
    parallel = candidate == "parallel_epochs_total_ordered_without_authority"
    rollback = "rollback" in candidate
    dispute = "dispute" in candidate or "conflicting_external" in candidate
    cycle = candidate == "cycle_in_lineage_graph"
    epochs = [
        {
            "epoch_id": "epoch-a",
            "correction_id": "harbor-correction-F101-src-A",
            "digest": epoch_digest("epoch-a"),
            "observed_at": None if missing_clock else "2026-05-24T00:40:00-04:00",
            "scope": "field:public-warning-label + generated-summary-text",
            "authority_basis": "local correction receipt",
        },
        {
            "epoch_id": "epoch-b",
            "correction_id": "harbor-correction-F101-src-B",
            "digest": epoch_digest("epoch-b"),
            "observed_at": None if missing_clock else "2026-05-25T00:23:00-04:00",
            "scope": "field:generated-summary-text + local-index-entry",
            "authority_basis": "local correction receipt plus F100 retained-history cut",
        },
    ]
    if rollback:
        epochs.append({
            "epoch_id": "epoch-rollback",
            "correction_id": "harbor-correction-F101-rollback-R",
            "digest": epoch_digest("epoch-rollback"),
            "observed_at": "2026-05-25T00:24:00-04:00",
            "scope": "rollback of one summary rendering, not warning-label removal",
            "authority_basis": "rollback notice requiring recheck",
        })
    if dispute:
        epochs.append({
            "epoch_id": "epoch-dispute",
            "correction_id": "external-conflicting-correction-F101-X",
            "digest": epoch_digest("epoch-dispute"),
            "observed_at": "2026-05-25T00:25:00-04:00",
            "scope": "external claim overlapping summary text only",
            "authority_basis": "unresolved external verifier claim",
        })
    if parallel:
        epochs.append({
            "epoch_id": "epoch-parallel-1",
            "correction_id": "parallel-correction-left",
            "digest": epoch_digest("epoch-parallel-1"),
            "observed_at": "2026-05-25T00:26:00-04:00",
            "scope": "mirror-a only",
            "authority_basis": "independent branch no total-order authority",
        })
        epochs.append({
            "epoch_id": "epoch-parallel-2",
            "correction_id": "parallel-correction-right",
            "digest": epoch_digest("epoch-parallel-2"),
            "observed_at": "2026-05-25T00:26:00-04:00",
            "scope": "mirror-b only",
            "authority_basis": "independent branch no total-order authority",
        })
    edges = [("epoch-a", "epoch-b")]
    if rollback:
        edges.append(("epoch-b", "epoch-rollback"))
    if dispute:
        edges.append(("epoch-b", "epoch-dispute"))
    if parallel:
        edges = [("epoch-a", "epoch-parallel-1"), ("epoch-a", "epoch-parallel-2")]
    if cycle:
        edges.append(("epoch-b", "epoch-a"))
    return {
        "subject_source_digest": source_material_digest(),
        "retention_bundle_digest": retention_bundle_digest(),
        "epochs": epochs,
        "epoch_edges": [{"from": a, "to": b} for a, b in edges],
        "clock_basis_present": not missing_clock,
        "order_basis": None if missing_clock else ("partial_order_only" if parallel else "observed correction receipt order plus scope comparison"),
        "contains_cycle": cycle,
        "parallel_epochs_total_order_attempt": parallel,
        "rollback_epoch_present": rollback,
        "dispute_epoch_present": dispute,
        "epoch_order_is_not_global_truth": True,
        "epoch_order_is_not_source_owner_closure": True,
    }


def derivative_lineage(candidate: str) -> dict[str, Any]:
    epoch = primary_epoch(candidate)
    reuse = candidate == "derivative_digest_reused_across_epochs"
    cycle = candidate == "cycle_in_lineage_graph"
    prior = derivative_digest(candidate, "epoch-a", "pre_repair")
    after_a = derivative_digest(candidate, "epoch-a")
    after_b = after_a if reuse else derivative_digest(candidate, "epoch-b")
    current = after_b if epoch in {"epoch-b", "epoch-dispute", "epoch-parallel-2"} else derivative_digest(candidate, epoch)
    edges = [
        {"from_digest": prior, "to_digest": after_a, "via_epoch": "epoch-a", "edge_kind": "repair"},
        {"from_digest": after_a, "to_digest": after_b, "via_epoch": "epoch-b", "edge_kind": "supersession_or_rebase"},
    ]
    if "rollback" in candidate:
        rb = derivative_digest(candidate, "epoch-rollback")
        edges.append({"from_digest": after_b, "to_digest": rb, "via_epoch": "epoch-rollback", "edge_kind": "rollback_requires_recheck"})
        current = rb
    if "consumer_patch" in candidate or "wrong_epoch_base" in candidate:
        base = "epoch-a" if candidate == "consumer_patch_applied_to_wrong_epoch_base" else "epoch-b"
        patched = derivative_digest(candidate, base, "consumer_patch_rebased")
        edges.append({"from_digest": after_b if base == "epoch-b" else after_a, "to_digest": patched, "via_epoch": base, "edge_kind": "consumer_patch_rebase"})
        current = patched
    if cycle:
        edges.append({"from_digest": after_b, "to_digest": after_a, "via_epoch": "epoch-a", "edge_kind": "cycle_attempt"})
    return {
        "derivative_id": f"harbor-overlap-derivative-{candidate}",
        "lineage_edges": edges,
        "current_candidate_digest": current,
        "pre_epoch_digest": prior,
        "epoch_a_digest": after_a,
        "epoch_b_digest": after_b,
        "digest_reused_across_epochs": reuse,
        "cycle_detected": cycle,
        "lineage_graph_has_subject_digest": True,
        "lineage_is_not_original_source": True,
        "lineage_is_not_global_downstream_state": True,
    }


def repair_action(candidate: str) -> dict[str, Any]:
    wrong_base = candidate == "consumer_patch_applied_to_wrong_epoch_base"
    missing_delta = candidate == "overlapping_correction_merged_without_delta_map"
    rollback_no_recheck = candidate == "material_rollback_without_recheck"
    action = "repair_to_epoch_b"
    if "retained_history" in candidate or "stale_epoch_a" in candidate:
        action = "retain_epoch_a_as_history"
    elif "disjoint" in candidate:
        action = "coexist_by_disjoint_scope"
    elif "split" in candidate or "partial_subset" in candidate:
        action = "split_derivative_state_by_scope"
    elif "rollback" in candidate:
        action = "rollback_with_recheck_and_history"
    elif "patch" in candidate:
        action = "consumer_patch_rebase"
    elif "dispute" in candidate or "conflicting_external" in candidate:
        action = "mark_disputed_recheck_required"
    elif "supersedes_named_fields" in candidate:
        action = "supersede_named_fields_only"
    return {
        "action": action,
        "base_epoch": "epoch-a" if wrong_base else "epoch-b",
        "target_epoch": primary_epoch(candidate),
        "scope_map_present": candidate not in {"latest_epoch_wins_without_scope_overlap_map", "field_scope_widened_to_whole_artifact"},
        "delta_map_present": not missing_delta,
        "rebase_map_present": ("patch" not in candidate) or not wrong_base,
        "rollback_recheck_required": "rollback" in candidate,
        "rollback_recheck_performed": "rollback" in candidate and not rollback_no_recheck and candidate != "rollback_erases_intermediate_warning_history",
        "retention_expiry_considered": candidate != "retention_expiry_ignored_in_lineage_currentness",
        "ack_target_epoch": "epoch-a" if "ack" in candidate else primary_epoch(candidate),
        "ack_counts_for_target_epoch_only": candidate != "ack_for_epoch_a_counts_for_epoch_b",
        "lineage_action_is_not_repair_attestation": True,
    }


def scope_reconciliation(candidate: str) -> dict[str, Any]:
    relation = scope_relation(candidate)
    return {
        "relation": relation,
        "scope_map_digest": digest({"candidate": candidate, "relation": relation}),
        "overlap_map_present": candidate != "latest_epoch_wins_without_scope_overlap_map",
        "latest_wins_attempt": candidate == "latest_epoch_wins_without_scope_overlap_map",
        "disjoint_marked_conflict": candidate == "disjoint_correction_marked_conflict",
        "field_scope_widened_to_artifact": candidate == "field_scope_widened_to_whole_artifact",
        "named_fields_only": candidate in {"epoch_b_supersedes_named_fields_only", "field_scope_widened_to_whole_artifact"},
        "whole_artifact_current_claim": candidate in {"field_scope_widened_to_whole_artifact", "stale_subset_marked_global_current", "public_badge_green_across_mixed_epochs"},
        "scope_comparison_is_not_authority": True,
        "incomparable_scopes_block_single_badge": relation in {"partial_overlap", "parallel_incomparable", "conflict_unresolved", "unknown"},
    }


def currentness_window(candidate: str) -> dict[str, Any]:
    missing_clock = candidate == "missing_epoch_order_or_clock_basis"
    stale_a = candidate in {
        "epoch_a_repair_retained_history_after_epoch_b",
        "stale_epoch_a_ack_preserved_as_residue",
        "epoch_a_repair_claims_current_after_epoch_b_overlap",
        "ack_for_epoch_a_counts_for_epoch_b",
        "retention_expiry_ignored_in_lineage_currentness",
    }
    return {
        "evaluated_at": None if missing_clock else "2026-05-25T00:23:00-04:00",
        "clock_basis_present": not missing_clock,
        "epoch_a_window": "history_only" if stale_a else "prior_epoch_context",
        "epoch_b_window": "current_for_named_scope" if not missing_clock else "unknown",
        "retention_cut_considered": candidate != "retention_expiry_ignored_in_lineage_currentness",
        "must_recheck_before_current_status": candidate in {
            "epoch_a_repair_retained_history_after_epoch_b",
            "stale_epoch_a_ack_preserved_as_residue",
            "conflicting_external_epoch_requires_dispute_state",
            "epoch_a_repair_claims_current_after_epoch_b_overlap",
            "retention_expiry_ignored_in_lineage_currentness",
            "material_rollback_without_recheck",
        },
        "currentness_is_scoped_to_epoch_and_fields": True,
        "old_receipt_is_not_current_repair": True,
    }


def consumer_state(candidate: str) -> dict[str, Any]:
    state = "scoped_current_epoch_b"
    if "retained_history" in candidate or "stale_epoch_a" in candidate:
        state = "history_only_with_recheck_required"
    elif "disjoint" in candidate:
        state = "coexisting_disjoint_epoch_states"
    elif "split" in candidate or "partial_subset" in candidate:
        state = "mixed_epoch_state_visible"
    elif "rollback" in candidate:
        state = "rollback_pending_recheck"
    elif "patch" in candidate:
        state = "local_patch_rebased" if candidate != "consumer_patch_applied_to_wrong_epoch_base" else "wrong_base_refused"
    elif "dispute" in candidate or "conflicting_external" in candidate:
        state = "disputed_not_repaired"
    badge = "scoped" if candidate not in {"public_badge_green_across_mixed_epochs", "source_owner_closure_overrides_lineage"} else "green_global"
    return {
        "state_class": state,
        "public_badge_posture": badge,
        "mixed_epochs_visible": state in {"mixed_epoch_state_visible", "coexisting_disjoint_epoch_states", "disputed_not_repaired"},
        "warning_history_preserved": candidate != "rollback_erases_intermediate_warning_history",
        "source_owner_closure_attempt": candidate == "source_owner_closure_overrides_lineage",
        "acknowledgement_epoch": "epoch-a" if "ack" in candidate else primary_epoch(candidate),
        "acknowledgement_is_not_repair_for_other_epochs": candidate != "ack_for_epoch_a_counts_for_epoch_b",
        "consumer_state_is_not_compliance": True,
        "consumer_state_is_not_all_derivatives_current": True,
    }


def failure_reasons(candidate: str) -> list[str]:
    reasons: list[str] = []
    if candidate == "latest_epoch_wins_without_scope_overlap_map":
        reasons.append("latest_epoch_wins_without_scope_overlap_map")
    if candidate == "epoch_a_repair_claims_current_after_epoch_b_overlap":
        reasons.append("stale_epoch_a_currentness_overclaim")
    if candidate == "rollback_erases_intermediate_warning_history":
        reasons.append("rollback_erases_intermediate_history")
    if candidate == "disjoint_correction_marked_conflict":
        reasons.append("disjoint_scope_false_conflict")
    if candidate == "overlapping_correction_merged_without_delta_map":
        reasons.append("overlap_merge_missing_delta_map")
    if candidate == "consumer_patch_applied_to_wrong_epoch_base":
        reasons.append("consumer_patch_wrong_epoch_base")
    if candidate == "ack_for_epoch_a_counts_for_epoch_b":
        reasons.append("acknowledgement_epoch_mismatch")
    if candidate == "derivative_digest_reused_across_epochs":
        reasons.append("derivative_digest_reused_across_epochs")
    if candidate == "missing_epoch_order_or_clock_basis":
        reasons.append("missing_epoch_order_or_clock_basis")
    if candidate == "parallel_epochs_total_ordered_without_authority":
        reasons.append("parallel_epochs_total_order_without_authority")
    if candidate == "field_scope_widened_to_whole_artifact":
        reasons.append("field_scope_widened_to_whole_artifact")
    if candidate == "stale_subset_marked_global_current":
        reasons.append("stale_subset_marked_global_current")
    if candidate == "dispute_epoch_treated_as_repair":
        reasons.append("dispute_epoch_treated_as_repair")
    if candidate == "source_owner_closure_overrides_lineage":
        reasons.append("source_owner_closure_overrides_lineage")
    if candidate == "retention_expiry_ignored_in_lineage_currentness":
        reasons.append("retention_expiry_ignored")
    if candidate == "public_badge_green_across_mixed_epochs":
        reasons.append("green_badge_across_mixed_epochs")
    if candidate == "material_rollback_without_recheck":
        reasons.append("material_rollback_without_recheck")
    if candidate == "cycle_in_lineage_graph":
        reasons.append("cycle_in_lineage_graph")
    return reasons


def verdict_summary(candidate: str, expected: str) -> dict[str, Any]:
    reasons = failure_reasons(candidate)
    admitted = expected == "accepted" and not reasons
    current_scope = "none"
    if admitted and candidate == "linear_epoch_chain_repair_to_latest_scoped":
        current_scope = "epoch-b named fields only"
    elif admitted and candidate == "epoch_b_supersedes_named_fields_only":
        current_scope = "epoch-b named fields, not whole artifact"
    elif admitted and candidate in {"disjoint_corrections_coexist_without_latest_wins", "overlapping_corrections_split_derivative_state_by_scope", "partial_subset_repaired_epoch_b_others_epoch_a_history"}:
        current_scope = "split by scope and derivative subset"
    return {
        "candidate": candidate,
        "admitted": admitted,
        "expected_matched": admitted == (expected == "accepted"),
        "verdict_class": "admitted_scoped_epoch_lineage" if admitted else "refused_counterfeit_epoch_lineage_confidence",
        "failure_reasons": reasons,
        "may_claim_current_for_scope": admitted and current_scope != "none",
        "current_scope": current_scope,
        "must_recheck_before_current_status": candidate in {
            "epoch_a_repair_retained_history_after_epoch_b",
            "stale_epoch_a_ack_preserved_as_residue",
            "conflicting_external_epoch_requires_dispute_state",
            "rollback_epoch_reopens_prior_repair_with_history",
        } or bool(reasons),
        "must_preserve_intermediate_history": True,
        "non_promises": [
            "not latest-wins",
            "not oldest-receipt-wins",
            "not global repair",
            "not all derivatives current",
            "not source-owner closure",
            "not compliance",
            "not public green badge",
        ],
    }


def build_bundle() -> dict[str, Any]:
    members: dict[str, dict[str, Any]] = {label: {} for label in MEMBER_LABELS}
    accepted = 0
    rejected = 0
    for idx, plan in enumerate(CASE_PLAN, start=1):
        case_id = plan["id"]
        candidate = plan["candidate"]
        expected = plan["expected"]
        if expected == "accepted":
            accepted += 1
        else:
            rejected += 1
        row_basis = {"index": idx, "candidate": candidate, "expected": expected}
        members["lineage.matrix"][case_id] = {**row_basis, "digest": digest(row_basis)}
        members["source.epoch"][case_id] = source_epoch(candidate)
        members["derivative.lineage"][case_id] = derivative_lineage(candidate)
        members["repair.action"][case_id] = repair_action(candidate)
        members["scope.reconciliation"][case_id] = scope_reconciliation(candidate)
        members["currentness.window"][case_id] = currentness_window(candidate)
        members["consumer.state"][case_id] = consumer_state(candidate)
        members["verdict.summary"][case_id] = verdict_summary(candidate, expected)
    bundle = {
        "schema": SCHEMA,
        "version": VERSION,
        "revision": REVISION,
        "purpose": "deterministic F101 overlapping correction-epoch lineage pressure slice; not a durable schema",
        "members": members,
        "global": {
            "case_count": len(CASE_PLAN),
            "accepted_count": accepted,
            "rejected_count": rejected,
            "source_revision": REVISION,
            "retention_bundle_digest": retention_bundle_digest(),
            "coverage_claim": "covers overlapping correction epochs, lineage/rebase/rollback/dispute counterfeits; not a correction registry, repair ledger, badge workflow, conflict-resolution engine, or compliance system",
            "non_promotion": NON_PROMOTION,
        },
    }
    bundle["bundle_digest"] = digest(bundle)
    return bundle


def main() -> None:
    parser = argparse.ArgumentParser(description="Emit Harbor overlapping correction-epoch lineage bundle")
    parser.add_argument("--emit-bundle", action="store_true", help="print the deterministic bundle as JSON")
    parser.add_argument("--write", type=Path, help="write the deterministic bundle to a fixture path")
    args = parser.parse_args()
    bundle = build_bundle()
    if args.write:
        args.write.parent.mkdir(parents=True, exist_ok=True)
        args.write.write_text(json.dumps(bundle, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if args.emit_bundle or not args.write:
        print(json.dumps(bundle, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
