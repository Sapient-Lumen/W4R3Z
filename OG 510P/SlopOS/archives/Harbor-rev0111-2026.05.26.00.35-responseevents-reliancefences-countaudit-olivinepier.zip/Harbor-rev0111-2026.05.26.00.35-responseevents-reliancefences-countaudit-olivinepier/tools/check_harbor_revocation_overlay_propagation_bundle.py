#!/usr/bin/env python3
"""Check Harbor revocation-overlay propagation bundle v0."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

from harbor_bundle_common import check_digest_string, expect, fail, unguarded_confidence_phrases, digest, file_digest  # noqa: E402
import harbor_revocation_overlay_propagation_harness as harness  # noqa: E402

def check_case(case: dict[str, Any]) -> None:
    case_id = case["id"]
    candidate = case["candidate"]
    expected = next(plan["expected"] for plan in harness.CASE_PLAN if plan["id"] == case_id)
    source = case["overlay.source"]
    target = case["target.surface"]
    action = case["propagation.action"]
    render = case["visibility.render"]
    notice = case["consumer.notice"]
    index_state = case["index.warning.state"]
    history = case["history.linkage"]
    verdict = case["verdict.summary"]

    expect(case["row_digest"] == digest({label: case[label] for label in harness.MEMBER_LABELS}), f"{case_id}: row digest drift")
    check_digest_string(source["parent_bundle_digest"], f"{case_id}: parent digest malformed")
    if source["overlay_digest_present"]:
        check_digest_string(source["overlay_digest"], f"{case_id}: overlay digest malformed")
    check_digest_string(target["target_digest"], f"{case_id}: target digest malformed")
    check_digest_string(action["propagation_digest"], f"{case_id}: propagation digest malformed")
    check_digest_string(render["render_digest"], f"{case_id}: render digest malformed")
    check_digest_string(index_state["state_digest"], f"{case_id}: state digest malformed")
    check_digest_string(history["lineage_digest"], f"{case_id}: lineage digest malformed")
    expect("not Harbor authority by itself" in source["source_non_promises"], f"{case_id}: source non-promise missing")
    expect(target["prior_history_visible"] is True, f"{case_id}: prior history must remain visible")
    expect(verdict["public_badge_allowed"] is False, f"{case_id}: public badge cannot be allowed")
    expect(verdict["compliance_claim_allowed"] is False, f"{case_id}: compliance cannot be allowed")
    expect(verdict["global_repair_claim_allowed"] is False, f"{case_id}: global repair cannot be allowed")
    expect(verdict["prior_falsehood_claim_allowed"] is False, f"{case_id}: prior falsehood cannot be allowed")
    for non_promise in harness.NON_PROMOTION:
        expect(non_promise in verdict["non_promises"], f"{case_id}: missing verdict non-promise {non_promise}")

    if expected == "accepted":
        expect(verdict["expected"] == "accepted", f"{case_id}: accepted expectation drift")
        expect(verdict["verdict_class"] == "propagated_scoped_revocation_overlay", f"{case_id}: accepted verdict class drift")
        expect(verdict["failure_reasons"] == [], f"{case_id}: accepted case has failure reasons")
        expect(source["overlay_digest_present"] is True, f"{case_id}: accepted case missing overlay digest")
        expect(action["scope_map_present"] is True, f"{case_id}: accepted case missing scope map")
        expect(action["source_digest_carried"] is True, f"{case_id}: accepted case dropped source digest")
        expect(action["history_link_carried"] is True, f"{case_id}: accepted case dropped history link")
        expect(action["automatic_repair_claimed"] is False, f"{case_id}: accepted case claims automatic repair")
        expect(action["global_closure_claimed"] is False, f"{case_id}: accepted case claims global closure")
        expect(render["green_badge_claimed"] is False and render["red_badge_claimed"] is False, f"{case_id}: accepted case claims badge")
        expect(render["compliance_remediation_claimed"] is False and render["compliance_failure_claimed"] is False, f"{case_id}: accepted case claims compliance")
        expect(render["prior_falsehood_claimed"] is False, f"{case_id}: accepted case claims prior falsehood")
        expect(notice["read_claimed"] is False and notice["applied_claimed"] is False, f"{case_id}: accepted case upgrades delivery")
        expect(history["history_erasure_claimed"] is False, f"{case_id}: accepted case erases history")
    else:
        expect(verdict["expected"] == "rejected", f"{case_id}: rejected expectation drift")
        expect(verdict["verdict_class"] == "refused_revocation_overlay_status_collapse", f"{case_id}: rejected verdict class drift")
        expect(verdict["failure_reasons"] == [harness.FAILURE_REASONS[candidate]], f"{case_id}: expected failure reason absent")

    flags = verdict["flags"]
    if candidate == "mirror_overlay_with_no_global_closure":
        expect(target["mirror_or_search_scope_limited"] is True and action["global_closure_claimed"] is False, f"{case_id}: mirror scope widened")
    elif candidate == "generated_summary_overlay_with_source_digest":
        expect(action["source_digest_carried"] is True and target["surface_kind"] == "generated_summary", f"{case_id}: summary lacks digest posture")
    elif candidate == "consumer_notice_delivery_without_read_claim":
        expect(notice["delivery_observed"] is True and notice["read_claimed"] is False and notice["applied_claimed"] is False, f"{case_id}: notice delivery overclaim")
    elif candidate == "local_index_overlay_quarantine":
        expect(index_state["index_refresh_observed"] is True and index_state["index_truth_claimed"] is False, f"{case_id}: index truth overclaim")
    elif candidate == "warning_card_split_state":
        expect(index_state["warning_card_state"] == "split_scoped", f"{case_id}: warning card not split-scoped")
    elif candidate == "partial_propagation_unknown_surfaces_preserved":
        expect(action["unreached_surfaces_state"] == "unknown_preserved", f"{case_id}: unknown surfaces not preserved")
    elif candidate == "sealed_revocation_overlay_public_summary_limit":
        expect(source["sealed_source"] is True and target["sealed_summary_limit"] is True and render["sealed_public_truth_claimed"] is False, f"{case_id}: sealed summary widened")
    elif candidate == "stale_mirror_overlay_requires_recheck":
        expect(source["stale_source_overlay"] is True and index_state["recheck_required"] is True and flags["stale_currentness_claimed"] is False, f"{case_id}: stale mirror not recheck-bound")
    elif candidate == "multi_cube_conflict_overlays_keep_incomparable":
        expect(target["mixed_overlay_state"] is True and index_state["mixed_state_preserved"] is True and action["majority_vote_used"] is False, f"{case_id}: multi-cube split collapsed")
    elif candidate == "missing_source_revocation_digest":
        expect(flags["missing_source_revocation_digest"] is True, f"{case_id}: missing source digest flag absent")

def check_bundle(bundle: dict[str, Any]) -> None:
    expect(bundle.get("schema") == harness.SCHEMA, "Schema drift")
    expect(bundle.get("version") == harness.VERSION, "Version drift")
    expect(bundle.get("source_revision") == harness.REVISION, "Source revision drift")
    expect(bundle.get("member_labels") == harness.MEMBER_LABELS, "Member label drift")
    expect(bundle.get("prior_foreign_revocation_bundle_digest") == harness.prior_f103_digest(), "Prior F103 digest drift")
    expect(bundle.get("bundle_common_helper_digest") == file_digest(ROOT / "tools" / "harbor_bundle_common.py"), "Bundle helper digest drift")
    expected_digest = digest({key: bundle[key] for key in ["schema", "version", "source_revision", "member_labels", "prior_foreign_revocation_bundle_digest", "bundle_common_helper_digest", "cases", "audit_refactor_note", "global"]})
    expect(bundle.get("bundle_digest") == expected_digest, "Bundle digest drift")
    check_digest_string(bundle["bundle_digest"], "Bundle digest malformed")
    expect(not unguarded_confidence_phrases(bundle), "Bundle contains unguarded confidence/status phrase")

    cases = bundle.get("cases", [])
    expect(len(cases) == len(harness.CASE_PLAN), "Case count drift")
    expect([case["index"] for case in cases] == list(range(1, len(cases) + 1)), "Case indexes not gapless")
    expect([case["id"] for case in cases] == [plan["id"] for plan in harness.CASE_PLAN], "Case id order drift")
    expect([case["candidate"] for case in cases] == [plan["candidate"] for plan in harness.CASE_PLAN], "Candidate order drift")
    for case in cases:
        check_case(case)

    accepted = sum(1 for case in cases if case["verdict.summary"]["expected"] == "accepted")
    rejected = len(cases) - accepted
    global_ = bundle.get("global", {})
    expect(global_.get("case_count") == len(cases), "Global case count drift")
    expect(global_.get("accepted_count") == accepted, "Global accepted count drift")
    expect(global_.get("rejected_count") == rejected, "Global rejected count drift")
    expect(global_.get("source_revision") == harness.REVISION, "Global source revision drift")
    for refusal in harness.NON_PROMOTION:
        expect(refusal in global_.get("non_promotion", []), f"Global non-promotion missing {refusal}")
    audit = bundle.get("audit_refactor_note", {})
    expect("harbor_bundle_common.py" in audit.get("refactor", ""), "Audit/refactor note missing bundle common refactor")
    expect("not schema" in audit.get("non_promise", ""), "Audit/refactor non-promise missing")

def main() -> None:
    parser = argparse.ArgumentParser(description="Check Harbor revocation-overlay propagation bundle")
    parser.add_argument("--fixture", type=Path, default=ROOT / "fixtures" / "harbor-revocation-overlay-propagation-bundle-v0.json")
    args = parser.parse_args()
    expected = harness.build_bundle()
    check_bundle(expected)
    if args.fixture.exists():
        actual = json.loads(args.fixture.read_text(encoding="utf-8"))
        expect(actual == expected, "Checked fixture does not match deterministic harness output")
    else:
        fail(f"Fixture missing: {args.fixture}")
    print("Harbor revocation-overlay propagation bundle check passed")

if __name__ == "__main__":
    main()
