#!/usr/bin/env python3
"""Audit Harbor's executable-surface registry and check_all wiring."""
from __future__ import annotations

import importlib
import json
import re
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

import harbor_executable_surface_registry as registry  # noqa: E402


def fail(message: str) -> None:
    print(message)
    raise SystemExit(1)


def expect(condition: bool, message: str) -> None:
    if not condition:
        fail(message)


def collect_followthrough() -> dict[str, str]:
    data = json.loads((ROOT / "FOLLOWTHROUGH-QUEUE.json").read_text(encoding="utf-8"))
    return {item["id"]: item.get("status", "") for item in data.get("items", [])}


def main() -> None:
    surfaces = registry.EXECUTABLE_SURFACES
    expect(len(surfaces) >= 17, "Executable surface registry unexpectedly small")
    ids = [surface["id"] for surface in surfaces]
    expect(ids == [f"F{i:03d}" for i in range(90, 107)], "Executable surface ids must be contiguous F090-F106")
    checker_modules = [surface["checker_module"] for surface in surfaces]
    expect(checker_modules == registry.SURFACE_CHECKER_MODULES, "Surface checker module order drift")
    expect(registry.CHECKER_MODULES == checker_modules + [registry.BUNDLE_COMMON_AUDIT_CHECKER, registry.BRIEFING_FOCUS_AUDIT_CHECKER, registry.REGISTRY_AUDIT_CHECKER], "Global checker module order drift")

    check_all = importlib.import_module("check_all")
    expect(check_all.CHECKER_MODULES == registry.CHECKER_MODULES, "check_all.py is not using registry checker order")

    followthrough = collect_followthrough()
    for surface in surfaces:
        for key in ["meta_doc", "specimen", "verification_doc", "fixture", "harness", "checker"]:
            rel = surface[key]
            expect((ROOT / rel).exists(), f"Registry path missing for {surface['id']}:{key}: {rel}")
        expect(followthrough.get(surface["id"]) == "done", f"{surface['id']} must be done if registered as executable proof slice")
        expect(re.search(rf"specimen-flow-{int(surface['id'][1:]):02d}-", surface["specimen"]), f"{surface['id']} specimen path number drift")
        expect(surface["revision"].startswith("rev"), f"{surface['id']} revision field drift")
        expect(surface["checker"].endswith(".py") and surface["harness"].endswith(".py"), f"{surface['id']} Python path drift")
        expect(surface["fixture"].endswith(".json"), f"{surface['id']} fixture path drift")

    latest = surfaces[-1]
    surface_status = json.loads((ROOT / "SURFACE-STATUS.json").read_text(encoding="utf-8"))
    manifest = json.loads((ROOT / "RELEASE-MANIFEST.json").read_text(encoding="utf-8"))
    expect(surface_status.get("latest_executable_surface") == latest["verification_doc"], "Latest executable surface drift")
    expect(surface_status.get("latest_specimen") == latest["specimen"], "Latest specimen drift")
    for rel in [latest["meta_doc"], latest["verification_doc"], latest["fixture"], latest["harness"], latest["checker"], latest["specimen"]]:
        expect(rel in manifest.get("core_docs", []), f"Latest registry surface missing from release manifest core_docs: {rel}")

    readme = (ROOT / "README.md").read_text(encoding="utf-8", errors="ignore")
    expect(registry.EXECUTABLE_SURFACE_COUNT_PHRASE in readme, "README executable count not updated")
    for non_promise in registry.NON_PROMOTION:
        expect(non_promise.startswith("not "), "Registry non-promotion phrasing drift")
    print("Harbor executable surface registry audit passed")


if __name__ == "__main__":
    main()
