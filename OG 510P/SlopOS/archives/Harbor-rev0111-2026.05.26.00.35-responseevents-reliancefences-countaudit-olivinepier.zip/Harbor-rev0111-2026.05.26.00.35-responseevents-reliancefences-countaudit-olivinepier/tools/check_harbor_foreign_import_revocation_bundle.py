#!/usr/bin/env python3
"""Check the deterministic Harbor foreign-import revocation bundle."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

import harbor_foreign_import_revocation_harness as harness  # noqa: E402


def fail(message: str) -> None:
    print(message)
    raise SystemExit(1)


def expect(condition: bool, message: str) -> None:
    if not condition:
        fail(message)


def check_case(case: dict[str, Any]) -> None:
    case_id = case["id"]
    candidate = case["candidate"]
    matrix = case["revocation.matrix"]
    prior = case["prior.import"]
    notice = case["foreign.change.notice"]
    impact = case["local.impact.analysis"]
    down = case["downstream.quarantine"]
    hist = case["history.residue"]
    recheck = case["recheck.plan"]
    verdict = case["verdict.summary"]
    flags = impact["flags"]

    expect(matrix["id"] == case_id, f"{case_id}: matrix id drift")
    expect(matrix["candidate"] == candidate, f"{case_id}: matrix candidate drift")
    expect(prior["parent_bundle_digest"] == harness.f102_bundle_digest(), f"{case_id}: parent bundle digest drift")
    expect(prior["prior_import_was_quarantined"] is True, f"{case_id}: prior import must remain quarantined")
    expect(prior["prior_import_was_not_reliance_authority"] is True, f"{case_id}: prior import reliance overclaim")
    expect(notice["notice_set_digest"].startswith("sha256:"), f"{case_id}: notice set digest missing")
    expect(impact["impact_digest"].startswith("sha256:"), f"{case_id}: impact digest missing")
    expect(down["downstream_digest"].startswith("sha256:"), f"{case_id}: downstream digest missing")
    expect(hist["history_digest"].startswith("sha256:"), f"{case_id}: history digest missing")
    expect(recheck["recheck_plan_digest"].startswith("sha256:"), f"{case_id}: recheck plan digest missing")
    expect(verdict["expected_matched"] is True, f"{case_id}: expected outcome did not match")
    expect(verdict["non_promotion_checked"] is True, f"{case_id}: non-promotion bit missing")

    for n in notice["notices"]:
        expect("not Harbor authority" in n["notice_non_promises"], f"{case_id}: notice authority refusal missing")
        expect("not downstream repair" in n["notice_non_promises"], f"{case_id}: notice repair refusal missing")
        if n["sealed_notice"]:
            expect("sealed is not public truth" in hist["history_non_promises"], f"{case_id}: sealed public-truth refusal missing")

    if verdict["admitted"]:
        expect(matrix["expected"] == "accepted", f"{case_id}: admitted rejected plan")
        expect(not any(flags.values()), f"{case_id}: admitted with forbidden flag")
        expect(notice["all_archive_digests_ok"] is True, f"{case_id}: admitted archive mismatch")
        expect(notice["all_parent_import_ids_present"] is True, f"{case_id}: admitted missing parent import")
        expect(notice["all_change_digests_present"] is True, f"{case_id}: admitted missing change digest")
        expect(impact["local_analysis_present"] is True, f"{case_id}: admitted without local impact analysis")
        expect(hist["retain_prior_import_history"] is True, f"{case_id}: admitted without history residue")
        expect(recheck["recheck_required"] is True, f"{case_id}: admitted without recheck requirement")
        expect(down["automatic_repair_claimed"] is False, f"{case_id}: admitted automatic repair")
        expect(down["global_derivative_closure_claimed"] is False, f"{case_id}: admitted global closure")
        expect(verdict["does_not_mark_prior_import_false"] is True, f"{case_id}: admitted prior falsehood")
        expect(verdict["does_not_establish_downstream_repair"] is True, f"{case_id}: admitted downstream repair")
        expect(verdict["does_not_import_companion_authority"] is True, f"{case_id}: admitted companion authority")
    else:
        expect(matrix["expected"] == "rejected", f"{case_id}: rejected accepted plan")
        expect(verdict["verdict_class"] == "refused_counterfeit_revocation_import", f"{case_id}: rejected verdict class drift")
        expect(verdict["failure_reason"], f"{case_id}: rejected without failure reason")

    if candidate == "revocation_means_prior_harbor_import_false":
        expect(flags["prior_falsity_claimed"] is True and impact["prior_import_marked_false"] is True, f"{case_id}: prior falsity overclaim not represented")
    elif candidate == "withdrawal_means_automatic_downstream_repair":
        expect(flags["automatic_repair_claimed"] is True and down["automatic_repair_claimed"] is True, f"{case_id}: automatic repair overclaim not represented")
    elif candidate == "supersession_lifts_quarantine_and_trusts_new_fragment":
        expect(flags["new_fragment_trusted_without_quarantine"] is True, f"{case_id}: trust-promotion overclaim not represented")
    elif candidate == "foreign_dispute_means_fragment_false":
        expect(flags["dispute_claimed_falsehood"] is True and hist["dispute_marks_uncertainty_not_falsehood"] is False, f"{case_id}: dispute falsehood overclaim not represented")
    elif candidate == "expiry_means_material_erased_or_repaired":
        expect(flags["expiry_claimed_erasure_or_repair"] is True and hist["expiry_marks_recheck_not_erasure"] is False, f"{case_id}: expiry repair/erasure overclaim not represented")
    elif candidate == "foreign_rescope_widens_harbor_scope":
        expect(flags["scope_widened_by_foreign_rescope"] is True and impact["impact_scope_relation"] == "widened_by_foreign_notice", f"{case_id}: scope widening not represented")
    elif candidate == "revocation_imported_as_compliance_failure":
        expect(flags["compliance_failure_claimed"] is True, f"{case_id}: compliance failure overclaim not represented")
    elif candidate == "newer_companion_revision_as_freshness":
        expect(flags["freshness_from_new_revision"] is True and recheck["new_revision_is_not_freshness"] is False, f"{case_id}: revision freshness overclaim not represented")
    elif candidate == "notice_timestamp_as_harbor_currentness":
        expect(flags["currentness_from_notice_timestamp"] is True and recheck["notice_timestamp_is_not_currentness"] is False, f"{case_id}: timestamp currentness overclaim not represented")
    elif candidate == "missing_foreign_change_digest_accepted":
        expect(notice["all_change_digests_present"] is False and recheck["missing_digest_blocks_recheck"] is True, f"{case_id}: missing digest not represented")
    elif candidate == "changed_archive_digest_mismatch_accepted":
        expect(notice["all_archive_digests_ok"] is False and recheck["archive_mismatch_blocks_recheck"] is True, f"{case_id}: archive mismatch not represented")
    elif candidate == "revocation_without_parent_import_id":
        expect(notice["all_parent_import_ids_present"] is False and recheck["missing_parent_blocks_recheck"] is True, f"{case_id}: missing parent import not represented")
    elif candidate == "badge_changed_without_local_impact_analysis":
        expect(flags["badge_changed_without_impact_analysis"] is True and impact["local_analysis_present"] is False, f"{case_id}: badge/impact overclaim not represented")
    elif candidate == "revocation_produces_public_green_badge":
        expect(flags["public_green_badge_claimed"] is True, f"{case_id}: green badge overclaim not represented")
    elif candidate == "companion_revocation_becomes_harbor_authority":
        expect(flags["companion_authority_imported"] is True and impact["companion_notice_used_as_authority"] is True, f"{case_id}: companion authority overclaim not represented")
    elif candidate == "multiple_revocation_notices_majority_wins":
        expect(flags["majority_vote_used"] is True and recheck["majority_vote_not_allowed"] is False, f"{case_id}: majority vote overclaim not represented")
    elif candidate == "sealed_withdrawal_notice_as_public_truth":
        expect(flags["sealed_notice_claimed_public_truth"] is True and hist["sealed_notice_public_truth"] is True, f"{case_id}: sealed public truth overclaim not represented")
    elif candidate == "rollback_after_foreign_withdrawal_without_recheck":
        expect(flags["rollback_without_recheck"] is True and recheck["rollback_requires_recheck"] is False, f"{case_id}: rollback without recheck not represented")
    elif candidate == "supersession_closes_all_derivatives_globally":
        expect(flags["global_derivative_closure_claimed"] is True and down["global_derivative_closure_claimed"] is True, f"{case_id}: global closure overclaim not represented")
    elif candidate == "consumer_ack_of_revocation_as_repair":
        expect(flags["consumer_ack_claimed_repair"] is True and down["consumer_ack_claimed_repair"] is True, f"{case_id}: ack repair overclaim not represented")


def check_bundle(bundle: dict[str, Any]) -> None:
    expect(bundle.get("schema") == harness.SCHEMA, "Schema drift")
    expect(bundle.get("version") == harness.VERSION, "Version drift")
    expect(bundle.get("source_revision") == harness.REVISION, "Source revision drift")
    expect(bundle.get("member_labels") == harness.MEMBER_LABELS, "Member label drift")
    expect(bundle.get("prior_cross_cube_import_bundle_digest") == harness.f102_bundle_digest(), "Prior F102 digest drift")
    expect(bundle.get("foreign_catalog") == harness.f102.FOREIGN_CATALOG, "Foreign catalog drift")
    expected_digest = harness.digest({key: bundle[key] for key in ["schema", "version", "source_revision", "member_labels", "prior_cross_cube_import_bundle_digest", "foreign_catalog", "cases", "audit_refactor_note", "global"]})
    expect(bundle.get("bundle_digest") == expected_digest, "Bundle digest drift")

    cases = bundle.get("cases", [])
    expect(len(cases) == len(harness.CASE_PLAN), "Case count drift")
    expect([case["index"] for case in cases] == list(range(1, len(cases) + 1)), "Case indexes not gapless")
    expect([case["id"] for case in cases] == [plan["id"] for plan in harness.CASE_PLAN], "Case id order drift")
    expect([case["candidate"] for case in cases] == [plan["candidate"] for plan in harness.CASE_PLAN], "Candidate order drift")

    for case, plan in zip(cases, harness.CASE_PLAN):
        expect(case["revocation.matrix"]["expected"] == plan["expected"], f"{case['id']}: expected outcome drift")
        check_case(case)

    accepted = sum(1 for case in cases if case["verdict.summary"]["expected"] == "accepted")
    rejected = len(cases) - accepted
    global_ = bundle.get("global", {})
    expect(global_.get("case_count") == len(cases), "Global case count drift")
    expect(global_.get("accepted_count") == accepted, "Global accepted count drift")
    expect(global_.get("rejected_count") == rejected, "Global rejected count drift")
    expect(global_.get("source_revision") == harness.REVISION, "Global source revision drift")
    expect("not a revocation API" in global_.get("coverage_claim", ""), "Coverage claim must refuse revocation API promotion")
    for refusal in harness.NON_PROMOTION:
        expect(refusal in global_.get("non_promotion", []), f"Global non-promotion list missing {refusal}")
    audit = bundle.get("audit_refactor_note", {})
    expect("harbor_executable_surface_registry.py" in audit.get("refactor", ""), "Audit/refactor note missing registry refactor")
    expect("not conformance status" in audit.get("non_promise", ""), "Audit/refactor non-promise missing")


def main() -> None:
    parser = argparse.ArgumentParser(description="Check Harbor foreign-import revocation bundle")
    parser.add_argument("--fixture", type=Path, default=ROOT / "fixtures" / "harbor-foreign-import-revocation-bundle-v0.json")
    args = parser.parse_args()

    expected = harness.build_bundle()
    check_bundle(expected)
    if args.fixture.exists():
        actual = json.loads(args.fixture.read_text(encoding="utf-8"))
        expect(actual == expected, "Checked fixture does not match deterministic harness output")
    else:
        fail(f"Fixture missing: {args.fixture}")
    print("Harbor foreign-import revocation bundle check passed")


if __name__ == "__main__":
    main()
