#!/usr/bin/env python3
"""Check the deterministic Harbor mutation-triage bundle."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

import harbor_mutation_triage_harness as harness  # noqa: E402


def fail(message: str) -> None:
    print(message)
    raise SystemExit(1)


def expect(condition: bool, message: str) -> None:
    if not condition:
        fail(message)


def check_bundle(bundle: dict[str, Any]) -> None:
    expect(bundle.get("schema") == harness.SCHEMA, "Unexpected bundle schema")
    expect(bundle.get("version") == harness.VERSION, "Unexpected bundle version")
    expect(bundle.get("revision") == harness.REVISION, "Unexpected bundle revision")
    expect(bundle.get("purpose", "").endswith("not a durable schema"), "Purpose must refuse durable schema promotion")
    expected_digest = harness.digest({k: v for k, v in bundle.items() if k != "bundle_digest"})
    expect(bundle.get("bundle_digest") == expected_digest, "Bundle digest drift")

    members = bundle.get("members")
    expect(isinstance(members, dict), "Bundle members must be an object")
    expect(list(members.keys()) == harness.MEMBER_LABELS, "Member labels/order drift")

    matrix = members["triage.matrix"]
    expect(len(matrix) == 7, "F094 bundle must keep seven deterministic triage cases")
    for label in harness.MEMBER_LABELS[1:]:
        expect(list(members[label].keys()) == list(matrix.keys()), f"Triage ids drift in {label}")

    indexes = []
    killed = 0
    survived = 0
    unsafe_open = 0
    seen_classes = set()
    for case_id, row in matrix.items():
        indexes.append(row.get("index"))
        triage_class = row.get("triage_class")
        seen_classes.add(triage_class)
        expect(triage_class in harness.TRIAGE_CLASSES, f"{case_id}: unknown triage class")
        expect(row.get("bundle") in harness.BUNDLES, f"{case_id}: unknown bundle")
        expect(row.get("operator"), f"{case_id}: missing operator")
        expect(row.get("target_path"), f"{case_id}: missing target path")

        baseline = members["baseline.digest"][case_id]
        mutation = members["candidate.mutation"][case_id]
        observation = members["checker.observation"][case_id]
        classification = members["classification.packet"][case_id]
        promotion = members["promotion.packet"][case_id]
        pruning = members["corpus.pruning"][case_id]
        verdict = members["verdict.summary"][case_id]

        expect(baseline.get("bundle") == row["bundle"], f"{case_id}: baseline bundle drift")
        expect(baseline.get("baseline_digest", "").startswith("sha256:"), f"{case_id}: baseline digest missing")
        expect(mutation.get("operator") == row["operator"], f"{case_id}: mutation operator drift")
        expect(mutation.get("minimal_target") == row["target_path"], f"{case_id}: mutation target drift")
        expect(mutation.get("mutant_digest", "").startswith("sha256:"), f"{case_id}: mutant digest missing")
        expect(mutation.get("human_readable_counterfeit"), f"{case_id}: missing human-readable counterfeit")
        expect(observation.get("current_checker_is_source_of_truth") is True, f"{case_id}: current checker not marked as source")
        expect(observation.get("checker_reason"), f"{case_id}: missing checker reason")
        expect(classification.get("triage_class") == triage_class, f"{case_id}: classification drift")
        expect(classification.get("human_review_required") is True, f"{case_id}: human-review bit missing")
        expect(promotion.get("promoted_to_triage_fixture") is True, f"{case_id}: not promoted to triage fixture")
        expect(harness.NON_PROMOTION == promotion.get("non_promotions"), f"{case_id}: non-promotion list drift")
        expect(pruning.get("pruning_decision"), f"{case_id}: pruning decision missing")
        expect(pruning.get("would_inflate_metric_if_counted") is True, f"{case_id}: metric-inflation guard missing")
        expect(verdict.get("admitted") is True, f"{case_id}: verdict admitted bit drift")
        expect(verdict.get("non_promotion_checked") is True, f"{case_id}: non-promotion bit drift")
        expect(verdict.get("current_result_matches_expectation") is True, f"{case_id}: checker result did not match expectation")

        result = observation.get("current_checker_result")
        if result == "killed":
            killed += 1
        elif result == "survived":
            survived += 1
        else:
            fail(f"{case_id}: invalid current checker result {result!r}")

        if triage_class == "unsafe_survivor_guarded":
            expect(result == "killed", f"{case_id}: unsafe survivor is still open")
            expect(observation.get("legacy_or_prior_observation", "").startswith("survived_under_rev0098"), f"{case_id}: legacy survivor basis missing")
            expect(classification.get("unsafe_survivor_pattern") is True, f"{case_id}: unsafe pattern not marked")
            expect(classification.get("equivalent") is False, f"{case_id}: unsafe case marked equivalent")
            expect(promotion.get("decision") == "checker_guard_added", f"{case_id}: unsafe survivor not routed to checker guard")
            expect(promotion.get("checker_guard_added") is True, f"{case_id}: checker guard bit missing")
            expect(promotion.get("open_gap") is False, f"{case_id}: unsafe gap still open")
            expect(verdict.get("unsafe_gap_open") is False, f"{case_id}: unsafe verdict gap open")
        elif triage_class == "equivalent_survivor_do_not_promote":
            expect(result == "survived", f"{case_id}: equivalent survivor unexpectedly killed")
            expect(classification.get("equivalent") is True, f"{case_id}: equivalent bit missing")
            expect(classification.get("semantic_delta") == "none for this fixture", f"{case_id}: equivalence proof missing")
            expect(classification.get("do_not_auto_promote") is True, f"{case_id}: equivalent case auto-promotes")
            expect(promotion.get("decision") == "classify_equivalent_do_not_promote", f"{case_id}: equivalent case decision drift")
            expect(promotion.get("open_gap") is False, f"{case_id}: equivalent case opens unsafe gap")
            expect(pruning.get("requires_new_followthrough_if_repeated") is True, f"{case_id}: repeated survivor followthrough guard missing")
        elif triage_class == "overstrict_false_positive_candidate":
            expect(result == "killed", f"{case_id}: overstrict candidate should be killed by canonicality guard")
            expect(classification.get("checker_overstrict_candidate") is True, f"{case_id}: overstrict bit missing")
            expect(promotion.get("decision") == "keep_canonicality_guard", f"{case_id}: overstrict decision drift")
            expect(promotion.get("do_not_relax_without_repeat") is True, f"{case_id}: relax guard missing")
        else:
            fail(f"{case_id}: unhandled triage class")

    expect(indexes == list(range(1, len(matrix) + 1)), "Triage indexes must be gapless")
    expect(seen_classes == set(harness.TRIAGE_CLASSES), "Not all triage classes are represented")

    global_ = bundle.get("global", {})
    expect(global_.get("case_count") == len(matrix), "Global case_count drift")
    expect(global_.get("killed_count") == killed, "Global killed_count drift")
    expect(global_.get("survived_count") == survived, "Global survived_count drift")
    expect(global_.get("unsafe_survivor_open_count") == unsafe_open == 0, "Unsafe survivors must not remain open")
    expect(global_.get("triage_classes") == sorted(harness.TRIAGE_CLASSES), "Global triage classes drift")
    expect(global_.get("pruning_decisions") == harness.PRUNING_DECISIONS, "Pruning decision map drift")
    expect("not mutation score" in global_.get("coverage_claim", ""), "Coverage claim must refuse mutation-score promotion")
    for refusal in harness.NON_PROMOTION:
        expect(refusal in global_.get("non_promotion", []), f"Global non-promotion list missing {refusal}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Check Harbor mutation triage bundle")
    parser.add_argument("--fixture", type=Path, default=ROOT / "fixtures" / "harbor-mutation-triage-bundle-v0.json")
    args = parser.parse_args()

    expected = harness.build_bundle()
    check_bundle(expected)

    if args.fixture.exists():
        actual = json.loads(args.fixture.read_text(encoding="utf-8"))
        expect(actual == expected, "Checked fixture does not match deterministic harness output")
    else:
        fail(f"Fixture missing: {args.fixture}")

    print("Harbor mutation-triage bundle check passed")


if __name__ == "__main__":
    main()
