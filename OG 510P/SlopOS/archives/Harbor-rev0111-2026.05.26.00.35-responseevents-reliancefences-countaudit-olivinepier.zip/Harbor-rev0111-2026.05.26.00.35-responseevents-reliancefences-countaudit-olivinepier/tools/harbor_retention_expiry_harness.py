#!/usr/bin/env python3
"""Emit deterministic Harbor derivative repair retention/expiry evidence.

F100 starts after derivative repair evidence exists. The pressure is temporal:
repair receipts, acknowledgement packets, quarantines, tombstones, compaction
summaries, legal-hold-like exceptions, and privacy-minimized records are useful
only inside their stated retention/recheck scope. This harness keeps retention,
expiry, recheck, hold, pruning, and later-source-correction facts separate; no
retention policy extends truth merely by keeping a record alive.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]

SCHEMA = "harbor-derivative-repair-retention-expiry-bundle"
VERSION = "0"
REVISION = "rev0111"

MEMBER_LABELS = [
    "retention.matrix",
    "evidence.subject",
    "retention.policy",
    "expiry.clock",
    "retention.action",
    "recheck.receipt",
    "exception.hold",
    "verdict.summary",
]

NON_PROMOTION = [
    "no records-management system",
    "no legal-hold workflow",
    "no privacy-erasure API",
    "no retention schedule registry",
    "no evidence-vault format",
    "no consumer cache API",
    "no compliance workflow",
    "no final SlopOS datacube shape",
]

CASE_PLAN: list[dict[str, Any]] = [
    {"id": "RE001", "candidate": "active_repair_receipt_within_window", "expected": "accepted"},
    {"id": "RE002", "candidate": "expired_repair_receipt_recheck_required", "expected": "accepted"},
    {"id": "RE003", "candidate": "compacted_tombstone_with_digest_pointers", "expected": "accepted"},
    {"id": "RE004", "candidate": "legal_hold_preserves_evidence_not_freshness", "expected": "accepted"},
    {"id": "RE005", "candidate": "source_corrected_again_prior_repair_stale", "expected": "accepted"},
    {"id": "RE006", "candidate": "quarantine_evidence_retained_after_material_prune", "expected": "accepted"},
    {"id": "RE007", "candidate": "raw_evidence_pruned_digest_pointer_only", "expected": "accepted"},
    {"id": "RE008", "candidate": "recurrence_after_expiry_reopens_warning", "expected": "accepted"},
    {"id": "RE009", "candidate": "privacy_minimized_tombstone_retained", "expected": "accepted"},
    {"id": "RE010", "candidate": "reviewer_waiver_note_with_expiry", "expected": "accepted"},
    {"id": "RE011", "candidate": "expired_receipt_claims_current_repair", "expected": "rejected"},
    {"id": "RE012", "candidate": "retention_policy_extends_repair_without_recheck", "expected": "rejected"},
    {"id": "RE013", "candidate": "legal_hold_as_freshness", "expected": "rejected"},
    {"id": "RE014", "candidate": "compaction_digest_as_full_evidence", "expected": "rejected"},
    {"id": "RE015", "candidate": "deletion_as_repair_or_clean_slate", "expected": "rejected"},
    {"id": "RE016", "candidate": "second_source_correction_ignored", "expected": "rejected"},
    {"id": "RE017", "candidate": "scheduled_recheck_as_passed_recheck", "expected": "rejected"},
    {"id": "RE018", "candidate": "pruned_raw_evidence_as_verified_success", "expected": "rejected"},
    {"id": "RE019", "candidate": "quarantine_expiry_as_repaired", "expected": "rejected"},
    {"id": "RE020", "candidate": "consumer_acknowledgement_valid_after_expiry", "expected": "rejected"},
    {"id": "RE021", "candidate": "hold_release_drops_stale_warning", "expected": "rejected"},
    {"id": "RE022", "candidate": "clockless_expiry_window", "expected": "rejected"},
    {"id": "RE023", "candidate": "borrowed_retention_window_wrong_scope", "expected": "rejected"},
    {"id": "RE024", "candidate": "tombstone_missing_subject_digest", "expected": "rejected"},
    {"id": "RE025", "candidate": "privacy_minimization_as_no_stale_copies_proof", "expected": "rejected"},
    {"id": "RE026", "candidate": "migrated_evidence_digest_without_map", "expected": "rejected"},
]


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def digest(value: Any) -> str:
    return "sha256:" + hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def file_digest(rel: str) -> str:
    return "sha256:" + hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()


def read_json(rel: str) -> dict[str, Any]:
    return json.loads((ROOT / rel).read_text(encoding="utf-8"))


def derivative_repair_bundle_digest() -> str:
    bundle = read_json("fixtures/harbor-derivative-correction-propagation-bundle-v0.json")
    return bundle.get("bundle_digest", file_digest("fixtures/harbor-derivative-correction-propagation-bundle-v0.json"))


def source_material_digest() -> str:
    manifest = read_json("RELEASE-MANIFEST.json")
    return digest({
        "kind": "f100_retention_subject_source",
        "archive": manifest.get("archive"),
        "revision": manifest.get("revision"),
        "basis": derivative_repair_bundle_digest(),
    })


def repaired_derivative_digest(candidate: str) -> str:
    return digest({
        "kind": "f100_repaired_derivative_subject",
        "candidate": candidate,
        "basis": derivative_repair_bundle_digest(),
        "source": source_material_digest(),
    })


def later_source_correction_digest() -> str:
    return digest({
        "kind": "f100_second_source_correction",
        "supersedes": source_material_digest(),
        "correction_id": "harbor-correction-F100-src-002",
    })


def is_expired_case(candidate: str) -> bool:
    return candidate in {
        "expired_repair_receipt_recheck_required",
        "source_corrected_again_prior_repair_stale",
        "recurrence_after_expiry_reopens_warning",
        "expired_receipt_claims_current_repair",
        "retention_policy_extends_repair_without_recheck",
        "consumer_acknowledgement_valid_after_expiry",
        "quarantine_expiry_as_repaired",
    }


def evidence_subject(candidate: str) -> dict[str, Any]:
    derivative_digest = repaired_derivative_digest(candidate)
    wrong_or_missing = candidate == "tombstone_missing_subject_digest"
    return {
        "subject_id": f"harbor-retention-subject-{candidate}",
        "source_revision": read_json("RELEASE-MANIFEST.json").get("revision"),
        "source_archive": read_json("RELEASE-MANIFEST.json").get("archive"),
        "derivative_repair_bundle_digest": derivative_repair_bundle_digest(),
        "source_material_digest": source_material_digest(),
        "derivative_digest": None if wrong_or_missing else derivative_digest,
        "repair_receipt_digest": digest({"repair": derivative_digest, "candidate": candidate}),
        "acknowledgement_digest": digest({"ack": derivative_digest, "candidate": candidate}),
        "subject_digest_present": not wrong_or_missing,
        "subject_digest_scope": "repaired derivative, not original source or global downstream state",
        "subject_is_not_global_repair": True,
        "subject_is_not_retention_policy": True,
    }


def retention_policy(candidate: str) -> dict[str, Any]:
    legal_hold = candidate in {"legal_hold_preserves_evidence_not_freshness", "legal_hold_as_freshness", "hold_release_drops_stale_warning"}
    privacy_min = candidate in {"privacy_minimized_tombstone_retained", "privacy_minimization_as_no_stale_copies_proof"}
    wrong_scope = candidate == "borrowed_retention_window_wrong_scope"
    extends = candidate == "retention_policy_extends_repair_without_recheck"
    return {
        "policy_id": f"harbor-retention-policy-{candidate}",
        "basis": "legal_hold" if legal_hold else "privacy_minimization" if privacy_min else "local_derivative_repair_evidence_retention",
        "retention_window_days": 30 if not legal_hold else 365,
        "recheck_required_after_expiry": True,
        "compaction_allowed_after_days": 30,
        "raw_material_may_be_pruned": candidate in {
            "compacted_tombstone_with_digest_pointers",
            "quarantine_evidence_retained_after_material_prune",
            "raw_evidence_pruned_digest_pointer_only",
            "privacy_minimized_tombstone_retained",
            "pruned_raw_evidence_as_verified_success",
        },
        "policy_scope": "one repaired derivative receipt" if not wrong_scope else "source-wide retention schedule borrowed from another consumer",
        "policy_scope_matches_subject": not wrong_scope,
        "retention_extends_evidence_availability_not_truth": not extends,
        "policy_extends_repair_status_without_recheck": extends,
        "policy_is_not_freshness": True,
        "policy_is_not_compliance": True,
    }


def expiry_clock(candidate: str) -> dict[str, Any]:
    clockless = candidate == "clockless_expiry_window"
    expired = is_expired_case(candidate)
    return {
        "receipt_observed_at": None if clockless else "2026-05-24T00:40:00-04:00",
        "expires_at": None if clockless else "2026-06-23T00:40:00-04:00",
        "evaluated_at": None if clockless else ("2026-06-24T00:40:00-04:00" if expired else "2026-06-01T00:40:00-04:00"),
        "clock_basis_present": not clockless,
        "clock_basis": None if clockless else "America/New_York wall-clock rendering plus ISO8601 instants recorded in receipt",
        "expired_at_evaluation": expired if not clockless else None,
        "expiry_is_not_fault": True,
        "unknown_or_missing_clock_blocks_current_status": clockless,
    }


def retention_action(candidate: str) -> dict[str, Any]:
    action = "retain_raw_and_digest"
    if "expired" in candidate or "second_source" in candidate or "source_corrected_again" in candidate:
        action = "require_recheck_before_current_status"
    if "compacted" in candidate or "tombstone" in candidate:
        action = "compact_to_tombstone"
    if "legal_hold" in candidate or "hold" in candidate:
        action = "hold_record"
    if "quarantine" in candidate:
        action = "retain_quarantine_tombstone"
    if "privacy" in candidate:
        action = "privacy_minimize_with_tombstone"
    if "deletion_as" in candidate:
        action = "delete_material"
    if "migrated" in candidate:
        action = "migrate_evidence_store"
    return {
        "action": action,
        "raw_evidence_retained": candidate not in {
            "compacted_tombstone_with_digest_pointers",
            "quarantine_evidence_retained_after_material_prune",
            "raw_evidence_pruned_digest_pointer_only",
            "privacy_minimized_tombstone_retained",
            "deletion_as_repair_or_clean_slate",
            "pruned_raw_evidence_as_verified_success",
        },
        "tombstone_retained": candidate in {
            "compacted_tombstone_with_digest_pointers",
            "quarantine_evidence_retained_after_material_prune",
            "raw_evidence_pruned_digest_pointer_only",
            "privacy_minimized_tombstone_retained",
            "recurrence_after_expiry_reopens_warning",
            "tombstone_missing_subject_digest",
        },
        "tombstone_has_subject_digest": candidate != "tombstone_missing_subject_digest",
        "compaction_is_full_evidence_claim": candidate == "compaction_digest_as_full_evidence",
        "deletion_claims_repair_or_clean_slate": candidate == "deletion_as_repair_or_clean_slate",
        "pruning_is_not_repair": candidate != "deletion_as_repair_or_clean_slate",
        "privacy_minimization_claims_no_stale_copies": candidate == "privacy_minimization_as_no_stale_copies_proof",
        "migration_map_present": candidate != "migrated_evidence_digest_without_map",
        "warning_residue_preserved": candidate != "hold_release_drops_stale_warning",
    }


def recheck_receipt(candidate: str) -> dict[str, Any]:
    performed = candidate in {
        "active_repair_receipt_within_window",
        "source_corrected_again_prior_repair_stale",
        "recurrence_after_expiry_reopens_warning",
    }
    if candidate == "scheduled_recheck_as_passed_recheck":
        performed = False
    result = "not_due"
    if candidate == "active_repair_receipt_within_window":
        result = "passed_within_window"
    elif candidate == "source_corrected_again_prior_repair_stale":
        result = "stale_due_to_new_source_correction"
    elif candidate == "recurrence_after_expiry_reopens_warning":
        result = "stale_recurrence_observed"
    elif candidate == "expired_repair_receipt_recheck_required":
        result = "required_not_yet_performed"
    elif candidate == "scheduled_recheck_as_passed_recheck":
        result = "scheduled_not_performed"
    elif candidate == "second_source_correction_ignored":
        result = "not_performed_despite_new_source_correction"
    return {
        "recheck_id": f"harbor-recheck-F100-{candidate}",
        "performed": performed,
        "scheduled": candidate in {"expired_repair_receipt_recheck_required", "scheduled_recheck_as_passed_recheck"},
        "result": result,
        "result_digest": digest({"candidate": candidate, "performed": performed, "result": result}),
        "new_source_correction_digest": later_source_correction_digest() if candidate in {"source_corrected_again_prior_repair_stale", "second_source_correction_ignored"} else None,
        "new_source_correction_considered": candidate != "second_source_correction_ignored",
        "scheduled_is_not_performed": candidate != "scheduled_recheck_as_passed_recheck",
        "recheck_is_not_compliance": True,
    }


def exception_hold(candidate: str) -> dict[str, Any]:
    legal_hold = candidate in {"legal_hold_preserves_evidence_not_freshness", "legal_hold_as_freshness", "hold_release_drops_stale_warning"}
    waiver = candidate == "reviewer_waiver_note_with_expiry"
    return {
        "hold_or_waiver_present": legal_hold or waiver,
        "hold_type": "legal_hold_like_review_hold" if legal_hold else "reviewer_waiver" if waiver else "none",
        "scope": "preserve evidence for review" if legal_hold else "review note only" if waiver else "none",
        "expires_after_revision": "rev0106" if waiver else None,
        "released": candidate == "hold_release_drops_stale_warning",
        "hold_claims_freshness": candidate == "legal_hold_as_freshness",
        "hold_release_drops_warning": candidate == "hold_release_drops_stale_warning",
        "exception_preserves_evidence_not_status": candidate not in {"legal_hold_as_freshness", "hold_release_drops_stale_warning"},
        "waiver_does_not_change_machine_result": waiver,
    }


def verdict_summary(candidate: str, expected: str) -> dict[str, Any]:
    subject = evidence_subject(candidate)
    policy = retention_policy(candidate)
    clock = expiry_clock(candidate)
    action = retention_action(candidate)
    recheck = recheck_receipt(candidate)
    hold = exception_hold(candidate)
    failure_reasons: list[str] = []

    if candidate == "expired_receipt_claims_current_repair":
        failure_reasons.append("expired_receipt_currentness_overclaim")
    if policy["policy_extends_repair_status_without_recheck"]:
        failure_reasons.append("retention_policy_extends_truth")
    if hold["hold_claims_freshness"]:
        failure_reasons.append("hold_as_freshness")
    if action["compaction_is_full_evidence_claim"]:
        failure_reasons.append("compaction_digest_as_full_evidence")
    if action["deletion_claims_repair_or_clean_slate"]:
        failure_reasons.append("deletion_as_repair")
    if candidate == "second_source_correction_ignored":
        failure_reasons.append("new_source_correction_ignored")
    if candidate == "scheduled_recheck_as_passed_recheck":
        failure_reasons.append("scheduled_recheck_as_passed")
    if candidate == "pruned_raw_evidence_as_verified_success":
        failure_reasons.append("pruned_raw_evidence_as_success")
    if candidate == "quarantine_expiry_as_repaired":
        failure_reasons.append("quarantine_expiry_as_repair")
    if candidate == "consumer_acknowledgement_valid_after_expiry":
        failure_reasons.append("expired_acknowledgement_currentness_overclaim")
    if hold["hold_release_drops_warning"]:
        failure_reasons.append("hold_release_warning_loss")
    if not clock["clock_basis_present"]:
        failure_reasons.append("missing_clock_basis")
    if not policy["policy_scope_matches_subject"]:
        failure_reasons.append("retention_scope_mismatch")
    if not subject["subject_digest_present"] or not action["tombstone_has_subject_digest"]:
        failure_reasons.append("missing_subject_digest")
    if action["privacy_minimization_claims_no_stale_copies"]:
        failure_reasons.append("privacy_minimization_no_stale_copies_overclaim")
    if not action["migration_map_present"]:
        failure_reasons.append("evidence_migration_without_map")

    admitted = expected == "accepted"
    if admitted and candidate == "active_repair_receipt_within_window":
        verdict_class = "active_within_retention_window"
    elif admitted and candidate == "expired_repair_receipt_recheck_required":
        verdict_class = "expired_recheck_required_not_current"
    elif admitted and candidate == "compacted_tombstone_with_digest_pointers":
        verdict_class = "compacted_tombstone_retained"
    elif admitted and candidate == "legal_hold_preserves_evidence_not_freshness":
        verdict_class = "hold_preserves_evidence_not_freshness"
    elif admitted and candidate == "source_corrected_again_prior_repair_stale":
        verdict_class = "superseded_by_new_source_correction"
    elif admitted and candidate == "quarantine_evidence_retained_after_material_prune":
        verdict_class = "quarantine_residue_retained_not_repair"
    elif admitted and candidate == "raw_evidence_pruned_digest_pointer_only":
        verdict_class = "digest_pointer_only_not_full_evidence"
    elif admitted and candidate == "recurrence_after_expiry_reopens_warning":
        verdict_class = "stale_recurrence_reopened"
    elif admitted and candidate == "privacy_minimized_tombstone_retained":
        verdict_class = "privacy_minimized_tombstone"
    elif admitted and candidate == "reviewer_waiver_note_with_expiry":
        verdict_class = "scoped_reviewer_note_only"
    else:
        verdict_class = "refused_counterfeit_retention_confidence"

    return {
        "candidate": candidate,
        "admitted": admitted,
        "expected_matched": admitted == (expected == "accepted"),
        "verdict_class": verdict_class,
        "failure_reasons": failure_reasons,
        "may_claim_current_repair": candidate == "active_repair_receipt_within_window",
        "must_recheck_before_current_status": candidate in {
            "expired_repair_receipt_recheck_required",
            "source_corrected_again_prior_repair_stale",
            "recurrence_after_expiry_reopens_warning",
        },
        "must_preserve_warning_residue": candidate in {
            "recurrence_after_expiry_reopens_warning",
            "quarantine_evidence_retained_after_material_prune",
            "privacy_minimized_tombstone_retained",
        },
        "non_promises": [
            "not global repair",
            "not all derivatives current",
            "not compliance",
            "not legal advice",
            "not privacy erasure proof",
            "not cache freshness",
            "not final SlopOS datacube shape",
        ],
    }


def build_bundle() -> dict[str, Any]:
    members: dict[str, dict[str, Any]] = {label: {} for label in MEMBER_LABELS}
    accepted = 0
    rejected = 0
    for idx, plan in enumerate(CASE_PLAN, start=1):
        case_id = plan["id"]
        candidate = plan["candidate"]
        expected = plan["expected"]
        if expected == "accepted":
            accepted += 1
        else:
            rejected += 1
        row_basis = {"index": idx, "candidate": candidate, "expected": expected}
        members["retention.matrix"][case_id] = {**row_basis, "digest": digest(row_basis)}
        members["evidence.subject"][case_id] = evidence_subject(candidate)
        members["retention.policy"][case_id] = retention_policy(candidate)
        members["expiry.clock"][case_id] = expiry_clock(candidate)
        members["retention.action"][case_id] = retention_action(candidate)
        members["recheck.receipt"][case_id] = recheck_receipt(candidate)
        members["exception.hold"][case_id] = exception_hold(candidate)
        members["verdict.summary"][case_id] = verdict_summary(candidate, expected)

    bundle = {
        "schema": SCHEMA,
        "version": VERSION,
        "revision": REVISION,
        "purpose": "deterministic F100 retention/expiry pressure slice; not a durable schema",
        "members": members,
        "global": {
            "case_count": len(CASE_PLAN),
            "accepted_count": accepted,
            "rejected_count": rejected,
            "source_revision": REVISION,
            "derivative_repair_bundle_digest": derivative_repair_bundle_digest(),
            "coverage_claim": "covers retention/expiry/pruning/hold/recheck counterfeits; not records management, legal hold, compliance, privacy erasure, or cache authority",
            "non_promotion": NON_PROMOTION,
        },
    }
    bundle["bundle_digest"] = digest(bundle)
    return bundle


def main() -> None:
    parser = argparse.ArgumentParser(description="Emit Harbor derivative repair retention/expiry bundle")
    parser.add_argument("--emit-bundle", action="store_true", help="print the deterministic bundle as JSON")
    parser.add_argument("--write", type=Path, help="write the deterministic bundle to a fixture path")
    args = parser.parse_args()
    bundle = build_bundle()
    if args.write:
        args.write.parent.mkdir(parents=True, exist_ok=True)
        args.write.write_text(json.dumps(bundle, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if args.emit_bundle or not args.write:
        print(json.dumps(bundle, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
