#!/usr/bin/env python3
"""Emit deterministic Harbor property/mutation coverage evidence.

This harness is intentionally a meta-fixture, not a generator contract.  It
imports the three executable Harbor bundles and applies a small, named mutation
matrix to prove that the existing checkers kill the mutations Harbor currently
cares about: digest drift, member alignment drift, admission/status collapse,
non-promotion loss, and surface-specific authority overclaims.
"""
from __future__ import annotations

import argparse
import copy
import contextlib
import hashlib
import io
import json
import sys
from collections import Counter
from typing import Any, Callable

sys.dont_write_bytecode = True

import harbor_crossing_record_harness as crossing_harness
import harbor_transparency_receipt_harness as receipt_harness
import harbor_verifier_disagreement_harness as disagreement_harness
import check_harbor_crossing_record_bundle as crossing_checker
import check_harbor_transparency_receipt_bundle as receipt_checker
import check_harbor_verifier_disagreement_bundle as disagreement_checker

SCHEMA = "harbor-property-mutation-coverage-bundle"
VERSION = "0"
REVISION = "rev0098"

MEMBER_LABELS = [
    "suite.matrix",
    "baseline.digest",
    "property.claims",
    "mutation.plan",
    "mutation.results",
    "shrink.notes",
    "coverage.summary",
    "verdict.summary",
]

BUNDLES: dict[str, tuple[Callable[[], dict[str, Any]], Callable[[dict[str, Any]], None]]] = {
    "crossing": (crossing_harness.build_bundle, crossing_checker.check_bundle),
    "receipt": (receipt_harness.build_bundle, receipt_checker.check_bundle),
    "disagreement": (disagreement_harness.build_bundle, disagreement_checker.check_bundle),
}

# Invariant names are intentionally shared vocabulary, not a schema.  Each
# checker still owns its local fixture shape.
INVARIANT_CLAIMS = {
    "digest_binding": "top-level bundle digest and per-record digests must bind the exact emitted candidate",
    "member_alignment": "every member table must preserve identical case ids and label order",
    "expected_admission_consistency": "case.matrix expected status must agree with output admission and aftermath residue",
    "non_promotion_guard": "the fixture must keep explicit non-promotion posture and refuse durable schema promotion",
    "accepted_subject_binding": "accepted records must bind subject digest to the imported evidence/receipt set",
    "rejected_no_record_emission": "rejected candidates may carry explanatory residue but must not emit a durable record id",
    "scope_or_binding_refusal": "scope/binding/currentness comparison notes must refuse widening or freshness upgrades",
    "family_specific_non_promises": "route, receipt, or verifier family guards must survive on accepted records",
    "badge_and_currentness_refusal": "disagreement cases must not collapse into one green badge, freshness, or majority/latest truth",
    "hostile_fixture_explainability": "a killed mutation must retain a named operator, target path, minimal reproduction, and refusal reason",
}

NON_PROMOTION = [
    "no property-test framework dependency",
    "no shared bundle schema",
    "no generated conformance suite",
    "no numeric coverage gate",
    "no fuzzer corpus promotion",
    "no final SlopOS datacube shape",
]


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def digest(value: Any) -> str:
    return "sha256:" + hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def deep_get(value: Any, path: list[Any]) -> Any:
    cur = value
    for part in path:
        cur = cur[part]
    return cur


def deep_set(value: Any, path: list[Any], new_value: Any) -> None:
    cur = value
    for part in path[:-1]:
        cur = cur[part]
    cur[path[-1]] = new_value


def deep_del(value: Any, path: list[Any]) -> None:
    cur = value
    for part in path[:-1]:
        cur = cur[part]
    del cur[path[-1]]


def case_ids(bundle: dict[str, Any]) -> list[str]:
    return list(bundle["members"]["case.matrix"].keys())


def first_case(bundle: dict[str, Any], expected: str | None = None) -> str:
    for cid, matrix in bundle["members"]["case.matrix"].items():
        if expected is None or matrix["expected"] == expected:
            return cid
    raise KeyError(f"no case with expected={expected!r}")


def first_rejected(bundle: dict[str, Any]) -> str:
    return first_case(bundle, "rejected")


def first_accepted(bundle: dict[str, Any]) -> str:
    return first_case(bundle, "accepted")


def mutate_bundle_digest(bundle: dict[str, Any], bundle_name: str) -> dict[str, Any]:
    mutant = copy.deepcopy(bundle)
    mutant["bundle_digest"] = "sha256:" + "0" * 64
    return mutant


def mutate_purpose_promotes_schema(bundle: dict[str, Any], bundle_name: str) -> dict[str, Any]:
    mutant = copy.deepcopy(bundle)
    mutant["purpose"] = "F093 generated conformance suite; promoted durable schema"
    mutant["bundle_digest"] = digest({k: v for k, v in mutant.items() if k != "bundle_digest"})
    return mutant


def mutate_member_label_order(bundle: dict[str, Any], bundle_name: str) -> dict[str, Any]:
    mutant = copy.deepcopy(bundle)
    members = mutant["members"]
    first_label = next(iter(members))
    members["schema.promoted.extra"] = copy.deepcopy(members[first_label])
    mutant["bundle_digest"] = digest({k: v for k, v in mutant.items() if k != "bundle_digest"})
    return mutant


def mutate_case_alignment(bundle: dict[str, Any], bundle_name: str) -> dict[str, Any]:
    mutant = copy.deepcopy(bundle)
    cid = first_case(mutant)
    second_label = list(mutant["members"].keys())[1]
    deep_del(mutant, ["members", second_label, cid])
    mutant["bundle_digest"] = digest({k: v for k, v in mutant.items() if k != "bundle_digest"})
    return mutant


def mutate_expected_flip(bundle: dict[str, Any], bundle_name: str) -> dict[str, Any]:
    mutant = copy.deepcopy(bundle)
    cid = first_rejected(mutant)
    mutant["members"]["case.matrix"][cid]["expected"] = "accepted"
    mutant["bundle_digest"] = digest({k: v for k, v in mutant.items() if k != "bundle_digest"})
    return mutant


def mutate_non_promotion_flag(bundle: dict[str, Any], bundle_name: str) -> dict[str, Any]:
    mutant = copy.deepcopy(bundle)
    cid = first_case(mutant)
    mutant["members"]["verdict.summary"][cid]["non_promotion_checked"] = False
    mutant["bundle_digest"] = digest({k: v for k, v in mutant.items() if k != "bundle_digest"})
    return mutant


def mutate_global_count(bundle: dict[str, Any], bundle_name: str) -> dict[str, Any]:
    mutant = copy.deepcopy(bundle)
    mutant["global"]["accepted_count"] = -1
    mutant["bundle_digest"] = digest({k: v for k, v in mutant.items() if k != "bundle_digest"})
    return mutant


def mutate_crossing_subject_digest(bundle: dict[str, Any], bundle_name: str) -> dict[str, Any]:
    mutant = copy.deepcopy(bundle)
    cid = first_accepted(mutant)
    mutant["members"]["input.crossing_record"][cid]["subject"]["digest"] = "sha256:mutated-subject-digest"
    mutant["members"]["verdict.summary"][cid]["record_digest"] = crossing_harness.digest(mutant["members"]["input.crossing_record"][cid])
    mutant["bundle_digest"] = crossing_harness.digest({k: v for k, v in mutant.items() if k != "bundle_digest"})
    return mutant


def mutate_crossing_strip_route_guard(bundle: dict[str, Any], bundle_name: str) -> dict[str, Any]:
    mutant = copy.deepcopy(bundle)
    cid = first_accepted(mutant)
    record = mutant["members"]["input.crossing_record"][cid]
    record["outcome"]["non_promises"] = []
    mutant["members"]["verdict.summary"][cid]["record_digest"] = crossing_harness.digest(record)
    mutant["bundle_digest"] = crossing_harness.digest({k: v for k, v in mutant.items() if k != "bundle_digest"})
    return mutant


def mutate_crossing_scope_widening(bundle: dict[str, Any], bundle_name: str) -> dict[str, Any]:
    mutant = copy.deepcopy(bundle)
    cid = first_case(mutant)
    mutant["members"]["scope.comparison"][cid]["refused_widening"] = False
    mutant["bundle_digest"] = crossing_harness.digest({k: v for k, v in mutant.items() if k != "bundle_digest"})
    return mutant


def mutate_crossing_aftermath_overclaim(bundle: dict[str, Any], bundle_name: str) -> dict[str, Any]:
    mutant = copy.deepcopy(bundle)
    cid = first_accepted(mutant)
    mutant["members"]["output.aftermath"][cid]["durable_effect"] = "trusted_content_and_global_repair"
    mutant["bundle_digest"] = crossing_harness.digest({k: v for k, v in mutant.items() if k != "bundle_digest"})
    return mutant


def mutate_receipt_subject_digest(bundle: dict[str, Any], bundle_name: str) -> dict[str, Any]:
    mutant = copy.deepcopy(bundle)
    cid = first_accepted(mutant)
    record = mutant["members"]["input.import_record"][cid]
    record["subject"]["digest"] = "sha256:mutated-receipt-subject"
    mutant["members"]["verdict.summary"][cid]["record_digest"] = receipt_harness.digest(record)
    mutant["bundle_digest"] = receipt_harness.digest({k: v for k, v in mutant.items() if k != "bundle_digest"})
    return mutant


def mutate_receipt_currentness_upgrade(bundle: dict[str, Any], bundle_name: str) -> dict[str, Any]:
    mutant = copy.deepcopy(bundle)
    cid = first_case(mutant)
    mutant["members"]["currentness.analysis"][cid]["refused_freshness_upgrade"] = False
    mutant["bundle_digest"] = receipt_harness.digest({k: v for k, v in mutant.items() if k != "bundle_digest"})
    return mutant


def mutate_receipt_verifier_truth(bundle: dict[str, Any], bundle_name: str) -> dict[str, Any]:
    mutant = copy.deepcopy(bundle)
    cid = first_accepted(mutant)
    record = mutant["members"]["input.import_record"][cid]
    record["verifier"]["decision_is_semantic_truth"] = True
    mutant["members"]["verdict.summary"][cid]["record_digest"] = receipt_harness.digest(record)
    mutant["bundle_digest"] = receipt_harness.digest({k: v for k, v in mutant.items() if k != "bundle_digest"})
    return mutant


def mutate_receipt_outcome_forbidden(bundle: dict[str, Any], bundle_name: str) -> dict[str, Any]:
    mutant = copy.deepcopy(bundle)
    cid = first_accepted(mutant)
    record = mutant["members"]["input.import_record"][cid]
    record["outcome"]["class"] = "trusted"
    mutant["members"]["verdict.summary"][cid]["record_digest"] = receipt_harness.digest(record)
    mutant["bundle_digest"] = receipt_harness.digest({k: v for k, v in mutant.items() if k != "bundle_digest"})
    return mutant


def mutate_receipt_aftermath_overclaim(bundle: dict[str, Any], bundle_name: str) -> dict[str, Any]:
    mutant = copy.deepcopy(bundle)
    cid = first_accepted(mutant)
    mutant["members"]["output.aftermath"][cid]["durable_effect"] = "trusted_receipt_reliance_api"
    mutant["bundle_digest"] = receipt_harness.digest({k: v for k, v in mutant.items() if k != "bundle_digest"})
    return mutant


def mutate_disagreement_green_badge(bundle: dict[str, Any], bundle_name: str) -> dict[str, Any]:
    mutant = copy.deepcopy(bundle)
    cid = first_accepted(mutant)
    record = mutant["members"]["input.disagreement_record"][cid]
    record["public_status"]["badge"] = "green"
    record["public_status"]["one_badge_truth"] = True
    mutant["members"]["verdict.summary"][cid]["record_digest"] = disagreement_harness.digest(record)
    mutant["bundle_digest"] = disagreement_harness.digest({k: v for k, v in mutant.items() if k != "bundle_digest"})
    return mutant


def mutate_disagreement_majority_wins(bundle: dict[str, Any], bundle_name: str) -> dict[str, Any]:
    mutant = copy.deepcopy(bundle)
    cid = first_accepted(mutant)
    record = mutant["members"]["input.disagreement_record"][cid]
    record["comparison"]["majority_or_latest_wins"] = True
    record["comparison"]["result"] = "collapsed_to_majority"
    mutant["members"]["verdict.summary"][cid]["record_digest"] = disagreement_harness.digest(record)
    mutant["bundle_digest"] = disagreement_harness.digest({k: v for k, v in mutant.items() if k != "bundle_digest"})
    return mutant


def mutate_disagreement_unknown_fresh(bundle: dict[str, Any], bundle_name: str) -> dict[str, Any]:
    mutant = copy.deepcopy(bundle)
    cid = first_accepted(mutant)
    record = mutant["members"]["input.disagreement_record"][cid]
    record["currentness"]["unknown_is_fresh"] = True
    mutant["members"]["verdict.summary"][cid]["record_digest"] = disagreement_harness.digest(record)
    mutant["bundle_digest"] = disagreement_harness.digest({k: v for k, v in mutant.items() if k != "bundle_digest"})
    return mutant


def mutate_disagreement_policy_digest_missing(bundle: dict[str, Any], bundle_name: str) -> dict[str, Any]:
    mutant = copy.deepcopy(bundle)
    cid = first_accepted(mutant)
    run = mutant["members"]["input.verifier_runs"][cid][0]
    # This mirrors the F092 hostile omission, but applies it to an otherwise
    # accepted case so the checker must reject the generated mutant.
    del run["policy_digest"]
    mutant["bundle_digest"] = disagreement_harness.digest({k: v for k, v in mutant.items() if k != "bundle_digest"})
    return mutant


def mutate_disagreement_hide_disagreement(bundle: dict[str, Any], bundle_name: str) -> dict[str, Any]:
    mutant = copy.deepcopy(bundle)
    cid = first_accepted(mutant)
    record = mutant["members"]["input.disagreement_record"][cid]
    record["public_status"]["visible_disagreement"] = False
    mutant["members"]["verdict.summary"][cid]["record_digest"] = disagreement_harness.digest(record)
    mutant["bundle_digest"] = disagreement_harness.digest({k: v for k, v in mutant.items() if k != "bundle_digest"})
    return mutant


def mutate_rejected_record_emission(bundle: dict[str, Any], bundle_name: str) -> dict[str, Any]:
    mutant = copy.deepcopy(bundle)
    cid = first_rejected(mutant)
    member_labels = list(mutant["members"].keys())
    aftermath_label = next(label for label in member_labels if label == "output.aftermath")
    mutant["members"][aftermath_label][cid]["record_id"] = f"mutated-record-{bundle_name}-{cid}"
    if "non_promises" in mutant["members"][aftermath_label][cid]:
        mutant["members"][aftermath_label][cid]["non_promises"] = []
    harness = {"crossing": crossing_harness, "receipt": receipt_harness, "disagreement": disagreement_harness}[bundle_name]
    mutant["bundle_digest"] = harness.digest({k: v for k, v in mutant.items() if k != "bundle_digest"})
    return mutant


COMMON_OPERATORS: list[dict[str, Any]] = [
    {"operator": "common.bundle_digest_corrupted", "invariants": ["digest_binding"], "mutator": mutate_bundle_digest, "scope": ["crossing", "receipt", "disagreement"], "shrink": "one top-level string"},
    {"operator": "common.purpose_promotes_schema", "invariants": ["non_promotion_guard"], "mutator": mutate_purpose_promotes_schema, "scope": ["crossing", "receipt", "disagreement"], "shrink": "one purpose field"},
    {"operator": "common.member_label_inserted", "invariants": ["member_alignment"], "mutator": mutate_member_label_order, "scope": ["crossing", "receipt", "disagreement"], "shrink": "one extra member label"},
    {"operator": "common.case_id_removed_from_member", "invariants": ["member_alignment"], "mutator": mutate_case_alignment, "scope": ["crossing", "receipt", "disagreement"], "shrink": "one missing case id in one table"},
    {"operator": "common.expected_rejected_flipped_to_accepted", "invariants": ["expected_admission_consistency", "rejected_no_record_emission"], "mutator": mutate_expected_flip, "scope": ["crossing", "receipt", "disagreement"], "shrink": "one expected bit on one hostile case"},
    {"operator": "common.non_promotion_flag_false", "invariants": ["non_promotion_guard"], "mutator": mutate_non_promotion_flag, "scope": ["crossing", "receipt", "disagreement"], "shrink": "one verdict bit"},
    {"operator": "common.global_count_mutated", "invariants": ["member_alignment", "expected_admission_consistency"], "mutator": mutate_global_count, "scope": ["crossing", "receipt", "disagreement"], "shrink": "one global counter"},
    {"operator": "common.rejected_case_emits_record_id", "invariants": ["rejected_no_record_emission"], "mutator": mutate_rejected_record_emission, "scope": ["crossing", "receipt", "disagreement"], "shrink": "one rejected aftermath record_id"},
]

BUNDLE_OPERATORS: list[dict[str, Any]] = [
    {"operator": "crossing.accepted_subject_digest_mutated", "invariants": ["accepted_subject_binding", "digest_binding"], "mutator": mutate_crossing_subject_digest, "scope": ["crossing"], "shrink": "one accepted CrossingRecord subject.digest"},
    {"operator": "crossing.route_non_promises_stripped", "invariants": ["family_specific_non_promises", "non_promotion_guard"], "mutator": mutate_crossing_strip_route_guard, "scope": ["crossing"], "shrink": "one accepted outcome.non_promises list"},
    {"operator": "crossing.scope_refused_widening_false", "invariants": ["scope_or_binding_refusal"], "mutator": mutate_crossing_scope_widening, "scope": ["crossing"], "shrink": "one scope.comparison refused_widening bit"},
    {"operator": "crossing.aftermath_durable_effect_overclaims", "invariants": ["expected_admission_consistency", "non_promotion_guard"], "mutator": mutate_crossing_aftermath_overclaim, "scope": ["crossing"], "shrink": "one accepted aftermath.durable_effect value"},
    {"operator": "receipt.accepted_subject_digest_mutated", "invariants": ["accepted_subject_binding", "digest_binding"], "mutator": mutate_receipt_subject_digest, "scope": ["receipt"], "shrink": "one accepted import subject.digest"},
    {"operator": "receipt.currentness_upgrade_allowed", "invariants": ["scope_or_binding_refusal"], "mutator": mutate_receipt_currentness_upgrade, "scope": ["receipt"], "shrink": "one currentness.analysis refused_freshness_upgrade bit"},
    {"operator": "receipt.verifier_decision_becomes_truth", "invariants": ["non_promotion_guard"], "mutator": mutate_receipt_verifier_truth, "scope": ["receipt"], "shrink": "one verifier decision_is_semantic_truth bit"},
    {"operator": "receipt.outcome_trusted_content", "invariants": ["non_promotion_guard"], "mutator": mutate_receipt_outcome_forbidden, "scope": ["receipt"], "shrink": "one accepted outcome.class value"},
    {"operator": "receipt.aftermath_durable_effect_overclaims", "invariants": ["expected_admission_consistency", "non_promotion_guard"], "mutator": mutate_receipt_aftermath_overclaim, "scope": ["receipt"], "shrink": "one accepted aftermath.durable_effect value"},
    {"operator": "disagreement.public_badge_goes_green", "invariants": ["badge_and_currentness_refusal", "non_promotion_guard"], "mutator": mutate_disagreement_green_badge, "scope": ["disagreement"], "shrink": "one public_status badge plus one truth bit"},
    {"operator": "disagreement.majority_latest_wins", "invariants": ["badge_and_currentness_refusal"], "mutator": mutate_disagreement_majority_wins, "scope": ["disagreement"], "shrink": "one comparison result plus majority flag"},
    {"operator": "disagreement.unknown_currentness_is_fresh", "invariants": ["badge_and_currentness_refusal", "scope_or_binding_refusal"], "mutator": mutate_disagreement_unknown_fresh, "scope": ["disagreement"], "shrink": "one currentness.unknown_is_fresh bit"},
    {"operator": "disagreement.policy_digest_list_emptied", "invariants": ["digest_binding", "badge_and_currentness_refusal"], "mutator": mutate_disagreement_policy_digest_missing, "scope": ["disagreement"], "shrink": "one policy_epochs.policy_digests list"},
    {"operator": "disagreement.visible_disagreement_hidden", "invariants": ["badge_and_currentness_refusal"], "mutator": mutate_disagreement_hide_disagreement, "scope": ["disagreement"], "shrink": "one public_status visible_disagreement bit"},
]


def classify_failure(error: BaseException, captured: str) -> str:
    text = (captured.strip().splitlines()[-1] if captured.strip() else "").strip()
    if text:
        return text[:220]
    return type(error).__name__[:220]


def run_checker(checker: Callable[[dict[str, Any]], None], bundle: dict[str, Any]) -> tuple[bool, str]:
    buffer = io.StringIO()
    try:
        with contextlib.redirect_stdout(buffer), contextlib.redirect_stderr(buffer):
            checker(bundle)
    except BaseException as exc:  # SystemExit, AssertionError, KeyError, etc. all kill a mutant here.
        return False, classify_failure(exc, buffer.getvalue())
    return True, "survived: checker accepted mutated bundle"


def build_mutation_results() -> tuple[dict[str, Any], dict[str, Any], dict[str, Any], dict[str, Any]]:
    baselines = {name: builder() for name, (builder, _checker) in BUNDLES.items()}
    baseline_digest = {
        name: {
            "bundle_digest": bundle["bundle_digest"],
            "case_count": len(case_ids(bundle)),
            "accepted_count": bundle["global"].get("accepted_count"),
            "rejected_count": bundle["global"].get("rejected_count"),
        }
        for name, bundle in baselines.items()
    }

    suite_matrix: dict[str, Any] = {}
    mutation_plan: dict[str, Any] = {}
    mutation_results: dict[str, Any] = {}
    shrink_notes: dict[str, Any] = {}
    coverage_rows: list[dict[str, Any]] = []
    index = 0

    for operator_def in COMMON_OPERATORS + BUNDLE_OPERATORS:
        for bundle_name in operator_def["scope"]:
            index += 1
            mutation_id = f"mut-{index:03d}-{bundle_name}-{operator_def['operator'].replace('.', '-')}"
            baseline = baselines[bundle_name]
            checker = BUNDLES[bundle_name][1]
            mutant = operator_def["mutator"](baseline, bundle_name)
            survived, reason = run_checker(checker, mutant)
            killed = not survived
            matrix = {
                "index": index,
                "bundle": bundle_name,
                "operator": operator_def["operator"],
                "expected": "killed",
                "invariants": operator_def["invariants"],
            }
            suite_matrix[mutation_id] = matrix
            mutation_plan[mutation_id] = {
                "baseline_digest": baseline["bundle_digest"],
                "mutant_digest": mutant.get("bundle_digest"),
                "operator": operator_def["operator"],
                "minimal_target": operator_def["shrink"],
                "case_count_preserved": len(case_ids(mutant)) if "members" in mutant and "case.matrix" in mutant.get("members", {}) else None,
            }
            mutation_results[mutation_id] = {
                "killed": killed,
                "survived": survived,
                "checker_reason": reason,
                "result_class": "killed_by_checker" if killed else "survived_and_requires_new_fixture",
            }
            shrink_notes[mutation_id] = {
                "shrink_target": operator_def["shrink"],
                "human_explanation_required": True,
                "generated_case_retains_operator_name": True,
                "do_not_auto_promote_to_fixture": True,
            }
            coverage_rows.append({
                "bundle": bundle_name,
                "operator": operator_def["operator"],
                "invariants": operator_def["invariants"],
                "killed": killed,
            })

    bundle_counts = Counter(row["bundle"] for row in coverage_rows)
    invariant_counts = Counter(inv for row in coverage_rows for inv in row["invariants"])
    killed_count = sum(1 for row in coverage_rows if row["killed"])
    survived = [mid for mid, result in mutation_results.items() if result["survived"]]
    coverage_summary = {
        "mutation_count": len(coverage_rows),
        "killed_count": killed_count,
        "survived_count": len(survived),
        "survived_mutations": survived,
        "bundle_counts": dict(sorted(bundle_counts.items())),
        "invariant_counts": dict(sorted(invariant_counts.items())),
        "coverage_claim": "deterministic targeted mutation coverage only; not stochastic fuzz coverage or conformance completeness",
        "all_current_mutations_killed": len(survived) == 0,
        "non_promotion": NON_PROMOTION,
    }
    return baseline_digest, suite_matrix, mutation_plan, {"results": mutation_results, "shrink": shrink_notes, "coverage": coverage_summary}


def build_bundle() -> dict[str, Any]:
    baseline_digest, suite_matrix, mutation_plan, result_pack = build_mutation_results()
    members = {
        "suite.matrix": suite_matrix,
        "baseline.digest": baseline_digest,
        "property.claims": INVARIANT_CLAIMS,
        "mutation.plan": mutation_plan,
        "mutation.results": result_pack["results"],
        "shrink.notes": result_pack["shrink"],
        "coverage.summary": result_pack["coverage"],
        "verdict.summary": {
            "admitted": True,
            "non_promotion_checked": True,
            "all_current_mutations_killed": result_pack["coverage"]["all_current_mutations_killed"],
            "coverage_claim": result_pack["coverage"]["coverage_claim"],
            "refused_promotions": NON_PROMOTION,
        },
    }
    bundle = {
        "schema": SCHEMA,
        "version": VERSION,
        "revision": REVISION,
        "emitted_by": "tools/harbor_property_mutation_harness.py",
        "purpose": "F093 property-style mutation pressure test for existing executable bundles; not a durable schema",
        "members": members,
        "global": {
            "input_bundles": sorted(BUNDLES.keys()),
            "baseline_revisions": {
                "crossing": crossing_harness.REVISION,
                "receipt": receipt_harness.REVISION,
                "disagreement": disagreement_harness.REVISION,
            },
            "mutation_count": result_pack["coverage"]["mutation_count"],
            "killed_count": result_pack["coverage"]["killed_count"],
            "survived_count": result_pack["coverage"]["survived_count"],
            "invariant_count": len(INVARIANT_CLAIMS),
            "non_promotion": NON_PROMOTION,
        },
    }
    bundle["bundle_digest"] = digest({k: v for k, v in bundle.items() if k != "bundle_digest"})
    return bundle


def main() -> None:
    parser = argparse.ArgumentParser(description="Emit Harbor property/mutation coverage bundle")
    parser.add_argument("--emit-bundle", action="store_true", help="print the deterministic mutation coverage bundle JSON")
    args = parser.parse_args()
    if not args.emit_bundle:
        parser.error("expected --emit-bundle")
    print(json.dumps(build_bundle(), indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
