#!/usr/bin/env python3
"""Emit deterministic Harbor derivative correction/repair evidence.

F099 starts after local derivatives already exist. A later source correction
arrives and must propagate through summaries, annotations, indexes, re-exports,
cached explanations, synced copies, stale copies, and local repair patches.
The harness keeps notice delivery, consumer acknowledgement, invalidation, and
verified derivative repair separate; no acknowledgement becomes repair merely
because it crossed a boundary.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]

SCHEMA = "harbor-derivative-correction-propagation-bundle"
VERSION = "0"
REVISION = "rev0111"

MEMBER_LABELS = [
    "repair.matrix",
    "source.correction",
    "derivative.inventory",
    "propagation.notice",
    "invalidation.action",
    "consumer.acknowledgement",
    "derivative.state",
    "verdict.summary",
]

NON_PROMOTION = [
    "no derivative invalidation ledger",
    "no consumer cache API",
    "no repair attestation profile",
    "no sync-state authority",
    "no notification delivery guarantee",
    "no compliance workflow",
    "no final SlopOS datacube shape",
]

CASE_PLAN: list[dict[str, Any]] = [
    {"id": "DR001", "candidate": "annotation_repair_note_target_digest_bound", "expected": "accepted"},
    {"id": "DR002", "candidate": "generated_summary_rebuilt_from_corrected_source", "expected": "accepted"},
    {"id": "DR003", "candidate": "local_index_invalidated_and_rebuilt", "expected": "accepted"},
    {"id": "DR004", "candidate": "reexport_archive_superseded_with_parent_child_map", "expected": "accepted"},
    {"id": "DR005", "candidate": "cached_explanation_expired_and_revalidated", "expected": "accepted"},
    {"id": "DR006", "candidate": "cross_device_sync_repair_byte_verified", "expected": "accepted"},
    {"id": "DR007", "candidate": "stale_consumer_copy_quarantined_unreached", "expected": "accepted"},
    {"id": "DR008", "candidate": "local_patch_reconciled_but_kept_local_delta", "expected": "accepted"},
    {"id": "DR009", "candidate": "partial_propagation_unknown_surfaces_preserved", "expected": "accepted"},
    {"id": "DR010", "candidate": "notice_received_acknowledged_not_repaired", "expected": "accepted"},
    {"id": "DR011", "candidate": "notice_acknowledgement_claims_repair", "expected": "rejected"},
    {"id": "DR012", "candidate": "broadcast_delivery_claims_all_derivatives_reached", "expected": "rejected"},
    {"id": "DR013", "candidate": "index_invalidated_but_search_current_claimed", "expected": "rejected"},
    {"id": "DR014", "candidate": "rebuilt_summary_missing_corrected_source_digest", "expected": "rejected"},
    {"id": "DR015", "candidate": "cache_refresh_without_source_revalidation", "expected": "rejected"},
    {"id": "DR016", "candidate": "sync_provider_green_as_digest_verification", "expected": "rejected"},
    {"id": "DR017", "candidate": "local_patch_deletes_warning_labels", "expected": "rejected"},
    {"id": "DR018", "candidate": "stale_copy_silent_superseded_as_current", "expected": "rejected"},
    {"id": "DR019", "candidate": "consumer_repair_ack_claims_compliance", "expected": "rejected"},
    {"id": "DR020", "candidate": "repair_ack_wrong_derivative_digest", "expected": "rejected"},
    {"id": "DR021", "candidate": "reexport_overwrites_parent_identity", "expected": "rejected"},
    {"id": "DR022", "candidate": "notification_delivery_as_read_and_applied", "expected": "rejected"},
    {"id": "DR023", "candidate": "latest_correction_wins_without_scope_map", "expected": "rejected"},
    {"id": "DR024", "candidate": "summary_repaired_index_stale_global_closure", "expected": "rejected"},
    {"id": "DR025", "candidate": "unreachable_device_assumed_repaired_after_expiry", "expected": "rejected"},
    {"id": "DR026", "candidate": "ack_signer_as_source_authority", "expected": "rejected"},
]


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def digest(value: Any) -> str:
    return "sha256:" + hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def file_digest(rel: str) -> str:
    return "sha256:" + hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()


def read_json(rel: str) -> dict[str, Any]:
    return json.loads((ROOT / rel).read_text(encoding="utf-8"))


def local_derivation_bundle_digest() -> str:
    bundle = read_json("fixtures/harbor-post-import-local-derivation-drift-bundle-v0.json")
    return bundle.get("bundle_digest", file_digest("fixtures/harbor-post-import-local-derivation-drift-bundle-v0.json"))


def source_material_digest() -> str:
    manifest = read_json("RELEASE-MANIFEST.json")
    return digest({
        "kind": "f099_source_material_stub",
        "archive": manifest.get("archive"),
        "revision": manifest.get("revision"),
        "basis": "F098 local derivative inventory boundary",
    })


def corrected_source_digest() -> str:
    return digest({
        "kind": "f099_corrected_source_material_stub",
        "supersedes": source_material_digest(),
        "correction_id": "harbor-correction-F099-src-001",
    })


def derivative_kind(candidate: str) -> str:
    if candidate.startswith("annotation_"):
        return "annotation"
    if "summary" in candidate:
        return "generated_summary"
    if "index" in candidate or "search" in candidate:
        return "local_index"
    if "reexport" in candidate:
        return "reexported_archive"
    if "cache" in candidate or "explanation" in candidate:
        return "cached_explanation"
    if "sync" in candidate or "device" in candidate:
        return "synced_copy"
    if "stale_copy" in candidate:
        return "stale_consumer_copy"
    if "patch" in candidate:
        return "local_repair_patch"
    if "notification" in candidate or "broadcast" in candidate or "notice" in candidate:
        return "propagation_notice"
    return "local_derivative"


def base_derivative_digest(candidate: str) -> str:
    return digest({
        "kind": derivative_kind(candidate),
        "candidate": candidate,
        "basis": source_material_digest(),
        "phase": "pre_correction_derivative",
    })


def repaired_derivative_digest(candidate: str) -> str:
    return digest({
        "kind": derivative_kind(candidate),
        "candidate": candidate,
        "basis": corrected_source_digest(),
        "phase": "post_correction_derivative",
    })


def source_correction(candidate: str) -> dict[str, Any]:
    disputed = candidate == "latest_correction_wins_without_scope_map"
    return {
        "correction_id": "harbor-correction-F099-src-001" if not disputed else "harbor-correction-F099-src-002-conflicting",
        "source_revision": read_json("RELEASE-MANIFEST.json").get("revision"),
        "source_archive": read_json("RELEASE-MANIFEST.json").get("archive"),
        "prior_source_digest": source_material_digest(),
        "corrected_source_digest": corrected_source_digest(),
        "delta_digest": digest({"from": source_material_digest(), "to": corrected_source_digest(), "candidate": candidate}),
        "correction_notice_time": "2026-05-23T07:04:00-04:00",
        "target_scope": "consumer-local derivatives descended from one verified F098 import",
        "scope_map_present": not disputed,
        "disputed_or_rollback_branch_present": disputed,
        "latest_correction_is_not_default_winner": True,
        "correction_is_not_global_repair": True,
        "correction_is_not_consumer_compliance": True,
    }


def derivative_inventory(candidate: str) -> dict[str, Any]:
    kind = derivative_kind(candidate)
    prior = base_derivative_digest(candidate)
    return {
        "derivative_id": f"harbor-derivative-{candidate}",
        "derivative_kind": kind,
        "prior_derivative_digest": prior,
        "basis_source_digest": source_material_digest(),
        "basis_local_derivation_bundle_digest": local_derivation_bundle_digest(),
        "basis_transform_scope": kind,
        "label_digest_present_before_repair": True,
        "label_digest_preserved_after_repair": candidate != "local_patch_deletes_warning_labels",
        "parent_child_map_present": kind != "reexported_archive" or candidate != "reexport_overwrites_parent_identity",
        "parent_identity_overwrite_attempt": candidate == "reexport_overwrites_parent_identity",
        "inventory_is_observation_not_reachability": True,
        "inventory_does_not_prove_current_derivative_state": True,
    }


def propagation_notice(candidate: str) -> dict[str, Any]:
    route = "local_notification"
    if "sync" in candidate or "device" in candidate:
        route = "sync_provider_notice"
    elif "broadcast" in candidate:
        route = "broadcast_channel"
    elif "notification" in candidate:
        route = "notification_endpoint"
    elif "reexport" in candidate:
        route = "archive_referrer_notice"
    elif "index" in candidate:
        route = "local_index_invalidation_notice"
    delivered = candidate not in {"stale_consumer_copy_quarantined_unreached", "unreachable_device_assumed_repaired_after_expiry"}
    return {
        "notice_id": f"harbor-propagation-notice-{candidate}",
        "route_family": route,
        "target_derivative_digest": base_derivative_digest(candidate),
        "correction_delta_digest": source_correction(candidate)["delta_digest"],
        "delivered": delivered,
        "delivery_receipt_digest": digest({"route": route, "candidate": candidate, "delivered": delivered}),
        "delivery_observed_at": "2026-05-23T07:05:00-04:00" if delivered else None,
        "read_observed": candidate != "notification_delivery_as_read_and_applied" and delivered,
        "application_observed": candidate not in {"notice_received_acknowledged_not_repaired", "notice_acknowledgement_claims_repair", "notification_delivery_as_read_and_applied", "broadcast_delivery_claims_all_derivatives_reached"},
        "attempted_all_reached_claim": candidate == "broadcast_delivery_claims_all_derivatives_reached",
        "delivery_as_read_or_applied_claim": candidate == "notification_delivery_as_read_and_applied",
        "unreached_surfaces": ["offline-laptop-cache"] if candidate in {"partial_propagation_unknown_surfaces_preserved", "stale_consumer_copy_quarantined_unreached", "unreachable_device_assumed_repaired_after_expiry"} else [],
        "notice_delivery_is_not_repair": True,
        "notice_delivery_is_not_user_read": True,
        "broadcast_is_not_complete_reachability": True,
    }


def invalidation_action(candidate: str) -> dict[str, Any]:
    kind = derivative_kind(candidate)
    action = "mark_stale_and_recheck"
    if "rebuilt" in candidate or candidate in {"generated_summary_rebuilt_from_corrected_source", "local_index_invalidated_and_rebuilt"}:
        action = "invalidate_and_rebuild"
    if "superseded" in candidate:
        action = "supersede_with_parent_child_map"
    if "expired" in candidate or "cache" in candidate:
        action = "expire_cache_and_revalidate"
    if "quarantined" in candidate:
        action = "quarantine_unreached_copy"
    if "acknowledged_not_repaired" in candidate:
        action = "notice_only_no_repair"
    if "patch" in candidate:
        action = "reconcile_local_delta"
    if candidate in {"index_invalidated_but_search_current_claimed", "local_patch_deletes_warning_labels", "reexport_overwrites_parent_identity"}:
        action = "unsafe_mutation_attempt"
    if candidate == "cache_refresh_without_source_revalidation":
        action = "refresh_without_revalidation"
    return {
        "action": action,
        "derivative_kind": kind,
        "requires_source_digest_recheck": True,
        "corrected_source_digest_present": candidate != "rebuilt_summary_missing_corrected_source_digest",
        "corrected_source_digest": None if candidate == "rebuilt_summary_missing_corrected_source_digest" else corrected_source_digest(),
        "rebuild_output_digest": repaired_derivative_digest(candidate) if action in {"invalidate_and_rebuild", "expire_cache_and_revalidate", "reconcile_local_delta"} else None,
        "search_surface_current_claimed": candidate == "index_invalidated_but_search_current_claimed",
        "source_revalidation_performed": candidate != "cache_refresh_without_source_revalidation",
        "warning_labels_preserved": candidate != "local_patch_deletes_warning_labels",
        "supersession_visible": candidate != "stale_copy_silent_superseded_as_current",
        "expiry_or_recheck_window": "PT24H",
        "invalidation_is_not_repair_without_output_check": True,
        "repair_requires_material_state_evidence": True,
    }


def consumer_acknowledgement(candidate: str) -> dict[str, Any]:
    ack_type = "none"
    if "ack" in candidate or "notice" in candidate or "notification" in candidate:
        ack_type = "notice_received"
    if candidate in {
        "generated_summary_rebuilt_from_corrected_source",
        "local_index_invalidated_and_rebuilt",
        "cached_explanation_expired_and_revalidated",
        "cross_device_sync_repair_byte_verified",
        "local_patch_reconciled_but_kept_local_delta",
    }:
        ack_type = "repair_applied_and_verified"
    if candidate == "stale_consumer_copy_quarantined_unreached":
        ack_type = "unreached_copy_quarantined"
    signer_scope = "consumer-local-operator"
    if candidate == "ack_signer_as_source_authority":
        signer_scope = "consumer-local-operator-miscast-as-source-authority"
    correct_digest = base_derivative_digest(candidate)
    observed_digest = correct_digest
    if candidate == "repair_ack_wrong_derivative_digest":
        observed_digest = digest({"wrong": candidate, "not": correct_digest})
    return {
        "ack_id": f"harbor-consumer-ack-{candidate}",
        "ack_type": ack_type,
        "acknowledged_derivative_digest": observed_digest,
        "expected_derivative_digest": correct_digest,
        "ack_digest_matches_target": observed_digest == correct_digest,
        "ack_signer_scope": signer_scope,
        "ack_signer_has_source_authority": False if candidate != "ack_signer_as_source_authority" else True,
        "ack_claims_repair_without_material_evidence": candidate == "notice_acknowledgement_claims_repair",
        "ack_claims_compliance": candidate == "consumer_repair_ack_claims_compliance",
        "ack_observed_at": "2026-05-23T07:06:00-04:00" if ack_type != "none" else None,
        "ack_is_not_repair": ack_type == "notice_received",
        "ack_is_not_source_authority": True,
        "ack_is_not_compliance": True,
    }


def derivative_state(candidate: str) -> dict[str, Any]:
    inv = invalidation_action(candidate)
    ack = consumer_acknowledgement(candidate)
    notice = propagation_notice(candidate)
    kind = derivative_kind(candidate)
    state = "pending_recheck"
    material_digest = base_derivative_digest(candidate)
    verified_after = False
    unreached_unknown = bool(notice["unreached_surfaces"])
    if candidate in {
        "generated_summary_rebuilt_from_corrected_source",
        "local_index_invalidated_and_rebuilt",
        "cached_explanation_expired_and_revalidated",
        "cross_device_sync_repair_byte_verified",
        "local_patch_reconciled_but_kept_local_delta",
        "annotation_repair_note_target_digest_bound",
        "reexport_archive_superseded_with_parent_child_map",
    }:
        state = "repaired_or_superseded_for_scope"
        material_digest = repaired_derivative_digest(candidate)
        verified_after = True
    if candidate == "stale_consumer_copy_quarantined_unreached":
        state = "quarantined_unreached"
        verified_after = False
    if candidate == "partial_propagation_unknown_surfaces_preserved":
        state = "partially_propagated_unknown_surfaces_preserved"
        verified_after = False
    if candidate == "notice_received_acknowledged_not_repaired":
        state = "notice_acknowledged_not_repaired"
        verified_after = False
    if candidate.startswith("notice_acknowledgement_claims_repair"):
        state = "unsafe_repair_claim_without_material_evidence"
    if candidate == "broadcast_delivery_claims_all_derivatives_reached":
        state = "unsafe_all_reached_claim"
    if candidate == "index_invalidated_but_search_current_claimed":
        state = "unsafe_index_currentness_claim"
    if candidate == "rebuilt_summary_missing_corrected_source_digest":
        state = "unsafe_rebuild_without_source_digest"
    if candidate == "cache_refresh_without_source_revalidation":
        state = "unsafe_cache_refresh_without_revalidation"
    if candidate == "sync_provider_green_as_digest_verification":
        state = "unsafe_sync_green_as_verification"
    if candidate == "local_patch_deletes_warning_labels":
        state = "unsafe_warning_label_loss"
    if candidate == "stale_copy_silent_superseded_as_current":
        state = "unsafe_stale_copy_current_claim"
    if candidate == "consumer_repair_ack_claims_compliance":
        state = "unsafe_compliance_claim"
    if candidate == "repair_ack_wrong_derivative_digest":
        state = "unsafe_wrong_derivative_digest"
    if candidate == "reexport_overwrites_parent_identity":
        state = "unsafe_parent_identity_overwrite"
    if candidate == "notification_delivery_as_read_and_applied":
        state = "unsafe_delivery_as_read_applied"
    if candidate == "latest_correction_wins_without_scope_map":
        state = "unsafe_latest_correction_without_scope_map"
    if candidate == "summary_repaired_index_stale_global_closure":
        state = "unsafe_global_closure_with_stale_neighbor"
    if candidate == "unreachable_device_assumed_repaired_after_expiry":
        state = "unsafe_unreachable_assumed_repaired"
    if candidate == "ack_signer_as_source_authority":
        state = "unsafe_ack_signer_authority_claim"
    return {
        "derivative_kind": kind,
        "state": state,
        "material_digest_after_action": material_digest,
        "verified_after_action": verified_after,
        "verified_after_action_basis": "byte digest + corrected source digest" if verified_after else "none or pending",
        "unreached_surfaces_preserved": unreached_unknown,
        "stale_neighbor_surfaces": ["local_index"] if candidate == "summary_repaired_index_stale_global_closure" else [],
        "global_closure_claimed": candidate == "summary_repaired_index_stale_global_closure",
        "all_devices_repaired_claimed": candidate == "unreachable_device_assumed_repaired_after_expiry",
        "sync_provider_status": "green" if candidate == "sync_provider_green_as_digest_verification" else "not_authoritative",
        "repair_state_is_scoped": True,
        "state_is_not_downstream_global_truth": True,
        "state_is_not_compliance": True,
        "state_is_not_notification_read_receipt": True,
    }


def verdict_summary(candidate: str, expected: str) -> dict[str, Any]:
    correction = source_correction(candidate)
    inventory = derivative_inventory(candidate)
    notice = propagation_notice(candidate)
    inv = invalidation_action(candidate)
    ack = consumer_acknowledgement(candidate)
    state = derivative_state(candidate)
    failure_reasons: list[str] = []

    if not correction["scope_map_present"]:
        failure_reasons.append("missing_correction_scope_map")
    if notice["attempted_all_reached_claim"]:
        failure_reasons.append("broadcast_reachability_overclaim")
    if notice["delivery_as_read_or_applied_claim"]:
        failure_reasons.append("notification_delivery_as_read_applied")
    if inv["search_surface_current_claimed"] and not state["verified_after_action"]:
        failure_reasons.append("index_currentness_overclaim")
    if not inv["corrected_source_digest_present"]:
        failure_reasons.append("missing_corrected_source_digest")
    if not inv["source_revalidation_performed"]:
        failure_reasons.append("cache_refresh_without_revalidation")
    if state["sync_provider_status"] == "green" and not state["verified_after_action"]:
        failure_reasons.append("sync_green_as_digest_verification")
    if not inventory["label_digest_preserved_after_repair"] or not inv["warning_labels_preserved"]:
        failure_reasons.append("warning_label_loss")
    if not inv["supersession_visible"]:
        failure_reasons.append("silent_supersession_currentness")
    if ack["ack_claims_repair_without_material_evidence"]:
        failure_reasons.append("acknowledgement_as_repair")
    if ack["ack_claims_compliance"]:
        failure_reasons.append("consumer_compliance_overclaim")
    if not ack["ack_digest_matches_target"]:
        failure_reasons.append("ack_derivative_digest_mismatch")
    if inventory["parent_identity_overwrite_attempt"] or not inventory["parent_child_map_present"]:
        failure_reasons.append("reexport_parent_identity_overwrite")
    if state["global_closure_claimed"] and state["stale_neighbor_surfaces"]:
        failure_reasons.append("global_closure_with_stale_derivative")
    if state["all_devices_repaired_claimed"] and state["unreached_surfaces_preserved"]:
        failure_reasons.append("unreachable_device_assumed_repaired")
    if ack["ack_signer_has_source_authority"]:
        failure_reasons.append("ack_signer_authority_overclaim")

    admitted = expected == "accepted" and not failure_reasons
    if expected == "rejected" and not failure_reasons:
        failure_reasons.append("rejected_fixture_missing_explicit_failure_reason")
        admitted = False
    return {
        "candidate": candidate,
        "expected": expected,
        "admitted": admitted,
        "verdict_class": "accepted_scoped_derivative_repair_evidence" if admitted else "refused_counterfeit_derivative_repair",
        "failure_reasons": failure_reasons,
        "expected_matched": (admitted and expected == "accepted") or ((not admitted) and expected == "rejected"),
        "non_promises": [
            "not global downstream repair",
            "not all derivatives reached",
            "not user-read evidence",
            "not compliance",
            "not source-authority transfer",
            "not sync-state authority",
        ],
        "does_not_turn_notice_into_repair": True,
        "does_not_turn_ack_into_repair": True,
        "does_not_turn_sync_green_into_verification": True,
        "does_not_turn_quarantine_into_repair": True,
    }


def row_digest(case_id: str, candidate: str, expected: str) -> str:
    row = {
        "case_id": case_id,
        "candidate": candidate,
        "expected": expected,
        "source": source_correction(candidate),
        "inventory": derivative_inventory(candidate),
        "notice": propagation_notice(candidate),
        "invalidation": invalidation_action(candidate),
        "ack": consumer_acknowledgement(candidate),
        "state": derivative_state(candidate),
        "verdict": verdict_summary(candidate, expected),
    }
    return digest(row)


def build_bundle() -> dict[str, Any]:
    members: dict[str, Any] = {label: {} for label in MEMBER_LABELS}
    accepted = rejected = 0
    for index, plan in enumerate(CASE_PLAN, start=1):
        case_id = plan["id"]
        candidate = plan["candidate"]
        expected = plan["expected"]
        verdict = verdict_summary(candidate, expected)
        if verdict["admitted"]:
            accepted += 1
        else:
            rejected += 1
        members["repair.matrix"][case_id] = {
            "index": index,
            "candidate": candidate,
            "expected": expected,
            "digest": row_digest(case_id, candidate, expected),
        }
        members["source.correction"][case_id] = source_correction(candidate)
        members["derivative.inventory"][case_id] = derivative_inventory(candidate)
        members["propagation.notice"][case_id] = propagation_notice(candidate)
        members["invalidation.action"][case_id] = invalidation_action(candidate)
        members["consumer.acknowledgement"][case_id] = consumer_acknowledgement(candidate)
        members["derivative.state"][case_id] = derivative_state(candidate)
        members["verdict.summary"][case_id] = verdict

    bundle: dict[str, Any] = {
        "schema": SCHEMA,
        "version": VERSION,
        "revision": REVISION,
        "purpose": "deterministic derivative correction propagation and consumer repair acknowledgement evidence; not a durable schema",
        "members": members,
        "global": {
            "case_count": len(CASE_PLAN),
            "accepted_count": accepted,
            "rejected_count": rejected,
            "source_revision": REVISION,
            "source_archive": read_json("RELEASE-MANIFEST.json").get("archive"),
            "local_derivation_bundle_digest": local_derivation_bundle_digest(),
            "coverage_claim": "small F099 proof slice; not a derivative invalidation ledger, consumer cache API, or repair attestation profile",
            "non_promotion": NON_PROMOTION,
        },
    }
    bundle["bundle_digest"] = digest({k: v for k, v in bundle.items() if k != "bundle_digest"})
    return bundle


def main() -> None:
    parser = argparse.ArgumentParser(description="Emit Harbor derivative correction propagation bundle")
    parser.add_argument("--output", type=Path, default=ROOT / "fixtures" / "harbor-derivative-correction-propagation-bundle-v0.json")
    args = parser.parse_args()
    bundle = build_bundle()
    args.output.write_text(json.dumps(bundle, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(args.output)


if __name__ == "__main__":
    main()
