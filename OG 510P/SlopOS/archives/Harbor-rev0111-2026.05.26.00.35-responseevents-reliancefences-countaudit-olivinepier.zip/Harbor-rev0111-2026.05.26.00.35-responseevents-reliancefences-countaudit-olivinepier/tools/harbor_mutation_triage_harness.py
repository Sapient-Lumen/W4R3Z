#!/usr/bin/env python3
"""Emit deterministic Harbor mutation-triage evidence.

F094 is deliberately smaller than a mutation dashboard.  It records how Harbor
classifies checker outcomes that are not simple "all mutants killed" facts:
unsafe survivors discovered by the F093 discipline, equivalent/cosmetic
survivors, checker-overstrict false-positive candidates, and mutation-corpus
pruning decisions.  The harness executes the current checkers; legacy survivor
notes are recorded only as named prior behavior, not as a second truth source.
"""
from __future__ import annotations

import argparse
import copy
import contextlib
import hashlib
import io
import json
import sys
from typing import Any, Callable

sys.dont_write_bytecode = True

import harbor_crossing_record_harness as crossing_harness
import harbor_transparency_receipt_harness as receipt_harness
import harbor_verifier_disagreement_harness as disagreement_harness
import check_harbor_crossing_record_bundle as crossing_checker
import check_harbor_transparency_receipt_bundle as receipt_checker
import check_harbor_verifier_disagreement_bundle as disagreement_checker

SCHEMA = "harbor-mutation-triage-bundle"
VERSION = "0"
REVISION = "rev0099"

MEMBER_LABELS = [
    "triage.matrix",
    "baseline.digest",
    "candidate.mutation",
    "checker.observation",
    "classification.packet",
    "promotion.packet",
    "corpus.pruning",
    "verdict.summary",
]

NON_PROMOTION = [
    "no mutation dashboard",
    "no coverage gate",
    "no property-test framework dependency",
    "no generated conformance suite",
    "no automatic fixture promotion",
    "no final SlopOS datacube shape",
]

BUNDLES: dict[str, tuple[Callable[[], dict[str, Any]], Callable[[dict[str, Any]], None], Callable[[Any], str]]] = {
    "crossing": (crossing_harness.build_bundle, crossing_checker.check_bundle, crossing_harness.digest),
    "receipt": (receipt_harness.build_bundle, receipt_checker.check_bundle, receipt_harness.digest),
    "disagreement": (disagreement_harness.build_bundle, disagreement_checker.check_bundle, disagreement_harness.digest),
}

TRIAGE_CLASSES = {
    "unsafe_survivor_guarded": "legacy key-only or exact-token checks would miss an unsafe string-value overclaim; current checker must kill it",
    "equivalent_survivor_do_not_promote": "current checker may accept the mutant because the triage packet proves no semantic delta for this fixture",
    "overstrict_false_positive_candidate": "current checker kills a semantically harmless edit because deterministic fixture canonicality is intentionally stricter than JSON semantics",
}

PRUNING_DECISIONS = {
    "retain_shared_value_guard_not_more_F093_rows": "value-overclaim checking now lives in current bundle checkers and F094 triage; do not inflate F093's killed count with duplicate rows",
    "do_not_promote_cosmetic_survivors": "cosmetic survivors with explicit equivalence proof are triage evidence, not hostile fixtures",
    "keep_canonical_member_order_guard": "member ordering is semantically harmless for JSON but load-bearing for deterministic archive reproduction",
    "park_threshold_metrics": "mutation score and coverage percentage remain non-promoted; the next seam should inspect checker trust roots, not dashboards",
}


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def digest(value: Any) -> str:
    return "sha256:" + hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def first_case(bundle: dict[str, Any], expected: str = "accepted") -> str:
    for cid, matrix in bundle["members"]["case.matrix"].items():
        if matrix["expected"] == expected:
            return cid
    raise KeyError(expected)


def recompute_record_and_bundle(bundle: dict[str, Any], bundle_name: str, record_label: str, cid: str) -> dict[str, Any]:
    digest_fn = BUNDLES[bundle_name][2]
    record = bundle["members"][record_label][cid]
    bundle["members"]["verdict.summary"][cid]["record_digest"] = digest_fn(record)
    bundle["bundle_digest"] = digest_fn({k: v for k, v in bundle.items() if k != "bundle_digest"})
    return bundle


def run_checker(bundle_name: str, candidate: dict[str, Any]) -> tuple[str, str]:
    checker = BUNDLES[bundle_name][1]
    stdout = io.StringIO()
    try:
        with contextlib.redirect_stdout(stdout):
            checker(candidate)
        return "survived", "checker accepted mutant"
    except SystemExit as exc:
        reason = stdout.getvalue().strip().splitlines()
        if reason:
            return "killed", reason[-1]
        return "killed", f"checker exited {exc.code}"


def mutate_crossing_authority_phrase() -> tuple[dict[str, Any], str, str]:
    bundle = crossing_harness.build_bundle()
    cid = "accept-portal-net-request-route-admission"
    record = bundle["members"]["input.crossing_record"][cid]
    record["admission"]["authority_basis"] = "global truth confirmed by portal result"
    return recompute_record_and_bundle(bundle, "crossing", "input.crossing_record", cid), cid, "admission.authority_basis"


def mutate_receipt_policy_truth_phrase() -> tuple[dict[str, Any], str, str]:
    bundle = receipt_harness.build_bundle()
    cid = "accept-verifier-policy-decision-epoch"
    record = bundle["members"]["input.import_record"][cid]
    record["verifier"]["policy_id"] = "global truth verifier policy"
    return recompute_record_and_bundle(bundle, "receipt", "input.import_record", cid), cid, "verifier.policy_id"


def mutate_disagreement_badge_phrase() -> tuple[dict[str, Any], str, str]:
    bundle = disagreement_harness.build_bundle()
    cid = "accept-split-accept-refuse-preserved"
    record = bundle["members"]["input.disagreement_record"][cid]
    record["public_status"]["explanation"] = "One badge truth for all audiences"
    return recompute_record_and_bundle(bundle, "disagreement", "input.disagreement_record", cid), cid, "public_status.explanation"


def mutate_crossing_non_promise_order() -> tuple[dict[str, Any], str, str]:
    bundle = crossing_harness.build_bundle()
    cid = "accept-portal-net-request-route-admission"
    record = bundle["members"]["input.crossing_record"][cid]
    record["outcome"]["non_promises"] = list(reversed(record["outcome"]["non_promises"]))
    return recompute_record_and_bundle(bundle, "crossing", "input.crossing_record", cid), cid, "outcome.non_promises order"


def mutate_receipt_none_wording() -> tuple[dict[str, Any], str, str]:
    bundle = receipt_harness.build_bundle()
    cid = "accept-scitt-inclusion-scoped"
    record = bundle["members"]["input.import_record"][cid]
    record["currentness"]["freshness_claim"] = "not applicable"
    return recompute_record_and_bundle(bundle, "receipt", "input.import_record", cid), cid, "currentness.freshness_claim wording"


def mutate_disagreement_explanation_expanded() -> tuple[dict[str, Any], str, str]:
    bundle = disagreement_harness.build_bundle()
    cid = "accept-currentness-unknown-withheld"
    record = bundle["members"]["input.disagreement_record"][cid]
    record["public_status"]["explanation"] += " Recheck remains required."
    return recompute_record_and_bundle(bundle, "disagreement", "input.disagreement_record", cid), cid, "public_status.explanation appended safe sentence"


def mutate_crossing_member_order_sorted() -> tuple[dict[str, Any], str, str]:
    bundle = crossing_harness.build_bundle()
    members = bundle["members"]
    bundle["members"] = {label: members[label] for label in sorted(members.keys())}
    bundle["bundle_digest"] = crossing_harness.digest({k: v for k, v in bundle.items() if k != "bundle_digest"})
    return bundle, "<all>", "members label order"


CASE_BUILDERS = [
    (
        "triage-001-crossing-authority-phrase-guarded",
        "crossing",
        "crossing.authority_basis_global_truth_phrase",
        "unsafe_survivor_guarded",
        mutate_crossing_authority_phrase,
        "survived_under_rev0098_key_only_truth_scan",
        "checker_guard_added",
    ),
    (
        "triage-002-receipt-policy-id-truth-phrase-guarded",
        "receipt",
        "receipt.policy_id_global_truth_phrase",
        "unsafe_survivor_guarded",
        mutate_receipt_policy_truth_phrase,
        "survived_under_rev0098_key_only_truth_scan",
        "checker_guard_added",
    ),
    (
        "triage-003-disagreement-one-badge-phrase-guarded",
        "disagreement",
        "disagreement.public_status_one_badge_truth_phrase",
        "unsafe_survivor_guarded",
        mutate_disagreement_badge_phrase,
        "survived_under_rev0098_exact_value_only_scan",
        "checker_guard_added",
    ),
    (
        "triage-004-crossing-non-promise-order-equivalent",
        "crossing",
        "crossing.non_promise_order_reversed",
        "equivalent_survivor_do_not_promote",
        mutate_crossing_non_promise_order,
        "survived_under_current_checker",
        "classify_equivalent_do_not_promote",
    ),
    (
        "triage-005-receipt-none-wording-equivalent",
        "receipt",
        "receipt.currentness_none_wording_not_applicable",
        "equivalent_survivor_do_not_promote",
        mutate_receipt_none_wording,
        "survived_under_current_checker",
        "classify_equivalent_do_not_promote",
    ),
    (
        "triage-006-disagreement-safe-explanation-equivalent",
        "disagreement",
        "disagreement.safe_explanation_append",
        "equivalent_survivor_do_not_promote",
        mutate_disagreement_explanation_expanded,
        "survived_under_current_checker",
        "classify_equivalent_do_not_promote",
    ),
    (
        "triage-007-crossing-member-order-overstrict",
        "crossing",
        "crossing.member_label_order_sorted",
        "overstrict_false_positive_candidate",
        mutate_crossing_member_order_sorted,
        "would_survive_semantic_json_object_equivalence",
        "keep_canonicality_guard",
    ),
]


def baseline_summary() -> dict[str, Any]:
    out: dict[str, Any] = {}
    for name, (builder, _checker, digest_fn) in BUNDLES.items():
        bundle = builder()
        matrix = bundle["members"]["case.matrix"]
        out[name] = {
            "bundle_digest": bundle["bundle_digest"],
            "case_count": len(matrix),
            "accepted_count": sum(1 for row in matrix.values() if row["expected"] == "accepted"),
            "rejected_count": sum(1 for row in matrix.values() if row["expected"] == "rejected"),
            "harness_digest": digest_fn({"harness": name, "revision": bundle["revision"], "schema": bundle["schema"]}),
        }
    return out


def build_bundle() -> dict[str, Any]:
    baselines = baseline_summary()
    members: dict[str, Any] = {label: {} for label in MEMBER_LABELS}
    killed = 0
    survived = 0
    unsafe_open = 0

    for index, (case_id, bundle_name, operator, triage_class, builder, legacy_result, action) in enumerate(CASE_BUILDERS, start=1):
        candidate, source_case, target_path = builder()
        current_result, checker_reason = run_checker(bundle_name, candidate)
        if current_result == "killed":
            killed += 1
        else:
            survived += 1

        unsafe = triage_class == "unsafe_survivor_guarded"
        equivalent = triage_class == "equivalent_survivor_do_not_promote"
        overstrict = triage_class == "overstrict_false_positive_candidate"
        if unsafe and current_result != "killed":
            unsafe_open += 1

        members["triage.matrix"][case_id] = {
            "index": index,
            "bundle": bundle_name,
            "source_case": source_case,
            "operator": operator,
            "target_path": target_path,
            "triage_class": triage_class,
            "expected_current_result": "killed" if (unsafe or overstrict) else "survived",
        }
        members["baseline.digest"][case_id] = {
            "bundle": bundle_name,
            "baseline_digest": baselines[bundle_name]["bundle_digest"],
            "baseline_case_count": baselines[bundle_name]["case_count"],
        }
        members["candidate.mutation"][case_id] = {
            "operator": operator,
            "minimal_target": target_path,
            "mutant_digest": candidate["bundle_digest"],
            "human_readable_counterfeit": (
                "string-value authority/status overclaim" if unsafe else
                "cosmetic representation survivor" if equivalent else
                "semantically equivalent object-order edit killed by canonical fixture contract"
            ),
            "candidate_excerpt_digest": digest({
                "bundle": bundle_name,
                "operator": operator,
                "target_path": target_path,
                "source_case": source_case,
            }),
        }
        members["checker.observation"][case_id] = {
            "legacy_or_prior_observation": legacy_result,
            "current_checker_result": current_result,
            "checker_reason": checker_reason,
            "current_checker_is_source_of_truth": True,
        }
        members["classification.packet"][case_id] = {
            "triage_class": triage_class,
            "class_definition": TRIAGE_CLASSES[triage_class],
            "unsafe_survivor_pattern": unsafe,
            "equivalent": equivalent,
            "checker_overstrict_candidate": overstrict,
            "semantic_delta": "unsafe authority/status widening" if unsafe else "none for this fixture" if equivalent else "none for JSON semantics; present for canonical archive semantics",
            "why_checker_survived_or_killed": checker_reason,
            "human_review_required": True,
            "do_not_auto_promote": not unsafe,
        }
        members["promotion.packet"][case_id] = {
            "decision": action,
            "promoted_to_triage_fixture": True,
            "base_fixture_change": False,
            "checker_guard_added": action == "checker_guard_added",
            "open_gap": unsafe and current_result != "killed",
            "do_not_relax_without_repeat": overstrict,
            "non_promotions": NON_PROMOTION,
        }
        members["corpus.pruning"][case_id] = {
            "pruning_decision": (
                "retain_as_guarded_triage_case_not_F093_count_inflation" if unsafe else
                "do_not_promote_cosmetic_survivor" if equivalent else
                "keep_canonicality_guard_do_not_relax"
            ),
            "reason": (
                "shared forbidden-phrase guard now covers the class across checkers" if unsafe else
                "survived cosmetic mutation does not add hostile semantic pressure" if equivalent else
                "canonical member order makes deterministic bundle comparison and archive diffing sharper"
            ),
            "would_inflate_metric_if_counted": True,
            "requires_new_followthrough_if_repeated": equivalent,
        }
        members["verdict.summary"][case_id] = {
            "admitted": True,
            "non_promotion_checked": True,
            "result_class": triage_class,
            "current_result_matches_expectation": current_result == members["triage.matrix"][case_id]["expected_current_result"],
            "unsafe_gap_open": unsafe and current_result != "killed",
        }

    bundle = {
        "schema": SCHEMA,
        "version": VERSION,
        "revision": REVISION,
        "purpose": "survived-mutant triage, equivalence packets, overstrictness notes, and corpus pruning; not a durable schema",
        "members": members,
        "global": {
            "case_count": len(CASE_BUILDERS),
            "killed_count": killed,
            "survived_count": survived,
            "unsafe_survivor_open_count": unsafe_open,
            "triage_classes": sorted(TRIAGE_CLASSES),
            "pruning_decisions": PRUNING_DECISIONS,
            "non_promotion": NON_PROMOTION,
            "coverage_claim": "triage evidence only; not mutation score, not branch coverage, not fuzz completeness, not conformance",
        },
    }
    bundle["bundle_digest"] = digest(bundle)
    return bundle


def main() -> None:
    parser = argparse.ArgumentParser(description="Emit Harbor mutation triage bundle")
    parser.add_argument("--write", help="write fixture to path")
    args = parser.parse_args()
    bundle = build_bundle()
    text = json.dumps(bundle, indent=2, sort_keys=False) + "\n"
    if args.write:
        with open(args.write, "w", encoding="utf-8") as handle:
            handle.write(text)
    else:
        print(text, end="")


if __name__ == "__main__":
    main()
