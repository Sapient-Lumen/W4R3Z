#!/usr/bin/env python3
"""Check the deterministic Harbor property/mutation coverage bundle."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

import harbor_property_mutation_harness as harness  # noqa: E402


def fail(message: str) -> None:
    print(message)
    raise SystemExit(1)


def expect(condition: bool, message: str) -> None:
    if not condition:
        fail(message)


def check_bundle(bundle: dict[str, Any]) -> None:
    expect(bundle.get("schema") == harness.SCHEMA, "Unexpected bundle schema")
    expect(bundle.get("version") == harness.VERSION, "Unexpected bundle version")
    expect(bundle.get("revision") == harness.REVISION, "Unexpected bundle revision")
    expect(bundle.get("purpose", "").endswith("not a durable schema"), "Purpose must refuse durable schema promotion")
    expected_digest = harness.digest({k: v for k, v in bundle.items() if k != "bundle_digest"})
    expect(bundle.get("bundle_digest") == expected_digest, "Bundle digest drift")

    members = bundle.get("members")
    expect(isinstance(members, dict), "Bundle members must be an object")
    expect(list(members.keys()) == harness.MEMBER_LABELS, "Member labels/order drift")

    matrix = members["suite.matrix"]
    baselines = members["baseline.digest"]
    claims = members["property.claims"]
    plan = members["mutation.plan"]
    results = members["mutation.results"]
    shrink = members["shrink.notes"]
    coverage = members["coverage.summary"]
    verdict = members["verdict.summary"]

    expect(set(baselines.keys()) == set(harness.BUNDLES.keys()), "Baseline bundle set drift")
    for bundle_name, summary in baselines.items():
        expect(summary.get("bundle_digest", "").startswith("sha256:"), f"{bundle_name}: missing baseline digest")
        expect(summary.get("case_count", 0) > 0, f"{bundle_name}: missing baseline case count")
        expect(summary.get("accepted_count", -1) >= 0, f"{bundle_name}: invalid accepted count")
        expect(summary.get("rejected_count", -1) >= 0, f"{bundle_name}: invalid rejected count")

    expect(claims == harness.INVARIANT_CLAIMS, "Property claim text drift")
    expect(set(matrix.keys()) == set(plan.keys()) == set(results.keys()) == set(shrink.keys()), "Mutation id alignment drift")
    expect(len(matrix) == 38, "F093 bundle must keep thirty-eight deterministic mutations")
    expect(coverage.get("mutation_count") == len(matrix), "Coverage mutation_count drift")
    expect(coverage.get("killed_count") == len(matrix), "Coverage killed_count drift")
    expect(coverage.get("survived_count") == 0, "Coverage survived_count must stay zero")
    expect(coverage.get("survived_mutations") == [], "No survived mutations may be hidden")
    expect(coverage.get("all_current_mutations_killed") is True, "All-current-mutations-killed bit drift")
    expect("not stochastic fuzz coverage" in coverage.get("coverage_claim", ""), "Coverage claim must refuse fuzz/conformance completeness")

    seen_indexes = []
    seen_operators = set()
    for mutation_id, row in matrix.items():
        seen_indexes.append(row.get("index"))
        expect(row.get("bundle") in harness.BUNDLES, f"{mutation_id}: unknown bundle")
        expect(row.get("expected") == "killed", f"{mutation_id}: expected verdict drift")
        operator = row.get("operator")
        expect(isinstance(operator, str) and operator, f"{mutation_id}: missing operator")
        seen_operators.add(operator)
        invariants = row.get("invariants")
        expect(isinstance(invariants, list) and invariants, f"{mutation_id}: missing invariants")
        for invariant in invariants:
            expect(invariant in claims, f"{mutation_id}: unknown invariant {invariant!r}")

        plan_row = plan[mutation_id]
        result_row = results[mutation_id]
        shrink_row = shrink[mutation_id]
        expect(plan_row.get("baseline_digest") == baselines[row["bundle"]]["bundle_digest"], f"{mutation_id}: baseline digest not linked")
        expect(plan_row.get("mutant_digest", "").startswith("sha256:"), f"{mutation_id}: missing mutant digest")
        expect(plan_row.get("operator") == operator, f"{mutation_id}: operator drift between matrix and plan")
        expect(isinstance(plan_row.get("minimal_target"), str) and plan_row["minimal_target"], f"{mutation_id}: missing minimal target")
        expect(result_row.get("killed") is True, f"{mutation_id}: mutant not killed")
        expect(result_row.get("survived") is False, f"{mutation_id}: survived bit drift")
        expect(result_row.get("result_class") == "killed_by_checker", f"{mutation_id}: result class drift")
        expect(isinstance(result_row.get("checker_reason"), str) and result_row["checker_reason"], f"{mutation_id}: missing checker reason")
        expect(shrink_row.get("human_explanation_required") is True, f"{mutation_id}: generated mutation lacks human-readable obligation")
        expect(shrink_row.get("generated_case_retains_operator_name") is True, f"{mutation_id}: operator name not retained")
        expect(shrink_row.get("do_not_auto_promote_to_fixture") is True, f"{mutation_id}: generated mutation auto-promotes")

    expect(seen_indexes == list(range(1, len(matrix) + 1)), "Mutation indexes must be gapless")
    required_operator_prefixes = ["common.", "crossing.", "receipt.", "disagreement."]
    for prefix in required_operator_prefixes:
        expect(any(op.startswith(prefix) for op in seen_operators), f"Missing operator family {prefix}")

    global_ = bundle.get("global", {})
    expect(global_.get("input_bundles") == sorted(harness.BUNDLES.keys()), "Global input bundle list drift")
    expect(global_.get("mutation_count") == len(matrix), "Global mutation_count drift")
    expect(global_.get("killed_count") == len(matrix), "Global killed_count drift")
    expect(global_.get("survived_count") == 0, "Global survived_count must stay zero")
    expect(global_.get("invariant_count") == len(claims), "Global invariant_count drift")
    for refusal in harness.NON_PROMOTION:
        expect(refusal in global_.get("non_promotion", []), f"Global non-promotion list missing {refusal}")
        expect(refusal in verdict.get("refused_promotions", []), f"Verdict non-promotion list missing {refusal}")
    expect(verdict.get("admitted") is True, "Meta-bundle admitted bit drift")
    expect(verdict.get("non_promotion_checked") is True, "Meta-bundle non-promotion bit drift")
    expect(verdict.get("all_current_mutations_killed") is True, "Verdict all-killed bit drift")


def main() -> None:
    parser = argparse.ArgumentParser(description="Check Harbor property/mutation coverage bundle")
    parser.add_argument("--fixture", type=Path, default=ROOT / "fixtures" / "harbor-property-mutation-coverage-bundle-v0.json")
    args = parser.parse_args()

    expected = harness.build_bundle()
    check_bundle(expected)

    if args.fixture.exists():
        actual = json.loads(args.fixture.read_text(encoding="utf-8"))
        expect(actual == expected, "Checked fixture does not match deterministic harness output")
    else:
        fail(f"Fixture missing: {args.fixture}")

    print("Harbor property/mutation coverage bundle check passed")


if __name__ == "__main__":
    main()
