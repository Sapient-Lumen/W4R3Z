#!/usr/bin/env python3
"""Audit Harbor briefing/landing pages for stale appended revision blocks.

This is documentation hygiene only.  It keeps README.md, START_HERE.md, and
/docs/README.md as current entrypoints instead of long accreted revision logs.
It is not a schema, promotion gate, public badge, trust root, or release status
API.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

from harbor_bundle_common import expect  # noqa: E402
import harbor_executable_surface_registry as registry  # noqa: E402

LANDING_SURFACES = ["README.md", "START_HERE.md", "docs/README.md"]
STALE_MARKERS = [
    "Harbor living archive",
    "## Harbor living archive",
    "# Docs\nCurrent focus:",
    "Revision `rev0103`",
    "Revision `rev0107`",
    "Latest rev0103 pass",
    "Latest rev0107 pass",
]


def main() -> None:
    manifest = json.loads((ROOT / "RELEASE-MANIFEST.json").read_text(encoding="utf-8"))
    receipt = json.loads((ROOT / "REVISION-RECEIPT.json").read_text(encoding="utf-8"))
    surface = json.loads((ROOT / "SURFACE-STATUS.json").read_text(encoding="utf-8"))
    current_revision = manifest["revision"]
    summary = receipt["summary"]
    latest_surface = registry.EXECUTABLE_SURFACES[-1]
    # Only the newest research/evaluation briefing pages belong on landing
    # surfaces. Historical entries remain in the manifest and archive index, but
    # should not be re-required by this audit or the root pages would accrete a
    # hidden changelog again.
    core_docs = manifest.get("core_docs", [])
    research_docs = [rel for rel in core_docs if rel.startswith("docs/00-meta/research-synthesis-")]
    evaluation_docs = [rel for rel in core_docs if rel.startswith("docs/00-meta/slopos-companions-evaluation-")]
    latest_docs = []
    if research_docs:
        latest_docs.append(research_docs[-1])
    if evaluation_docs:
        latest_docs.append(evaluation_docs[-1])
    latest_docs.extend([
        latest_surface["meta_doc"],
        "docs/00-meta/datacube-executable-count-audit.md",
        latest_surface["verification_doc"],
        latest_surface["fixture"],
        latest_surface["harness"],
        latest_surface["checker"],
        latest_surface["specimen"],
    ])
    for rel in LANDING_SURFACES:
        text = (ROOT / rel).read_text(encoding="utf-8", errors="ignore")
        expect(current_revision in text, f"{rel}: current revision missing")
        expect(summary in text, f"{rel}: current focus summary missing")
        expect(text.count("Current focus:") == 1, f"{rel}: multiple current-focus sections detected")
        expect(text.count(f"Latest {current_revision} pass") == 1, f"{rel}: current latest-pass section missing or duplicated")
        old_revs = sorted(set(re.findall(r"rev\d{4}", text)) - {current_revision})
        expect(not old_revs, f"{rel}: stale revision fragments present: {', '.join(old_revs)}")
        for marker in STALE_MARKERS:
            expect(marker not in text, f"{rel}: stale marker present: {marker!r}")
        for doc in latest_docs:
            expect(doc in text, f"{rel}: latest core path missing: {doc}")
        expect(surface["latest_executable_surface"] in text, f"{rel}: latest executable surface missing")
        expect(surface["latest_specimen"] in text, f"{rel}: latest specimen missing")
        expect(registry.EXECUTABLE_SURFACE_COUNT_PHRASE in text, f"{rel}: executable slice count not current")
        expect("docs/00-meta/embryo-promotion-contract.md" in text or "embryo-promotion contract" in text.lower(), f"{rel}: promotion contract missing")
        expect("docs/00-meta/datacube-design-principles.md" in text or "datacube design principles" in text.lower(), f"{rel}: design principles missing")
    print("Harbor briefing focus audit passed")


if __name__ == "__main__":
    main()
