#!/usr/bin/env python3
from pathlib import Path
from collections import Counter
import re
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
required = [
    'README.md',
    'START_HERE.md',
    'ARCHIVE_INDEX.md',
    'RELEASE-MANIFEST.json',
    'REVISION-RECEIPT.json',
    'SURFACE-STATUS.json',
    'QUESTION-REGISTRY.json',
    'ASSUMPTION-LEDGER.json',
    'FOREIGN-PRESSURE-LEDGER.json',
    'FOLLOWTHROUGH-QUEUE.json',
    'IRREVERSIBLE-DECISION-LEDGER.json',
    'docs/00-meta/charter.md',
    'docs/00-meta/roadmap.md',
    'docs/00-meta/embryo-promotion-contract.md',
    'docs/00-meta/datacube-design-principles.md',
    'docs/00-meta/datacube-artifact-boundary.md',
    'docs/00-meta/datacube-review-loop.md',
    'docs/00-meta/datacube-stability-rings.md',
    'docs/00-meta/datacube-contract-tiers.md',
    'docs/00-meta/datacube-change-classes.md',
    'docs/00-meta/datacube-assertion-posture.md',
    'docs/00-meta/datacube-presence-semantics.md',
    'docs/00-meta/datacube-evidence-grades.md',
    'docs/00-meta/datacube-time-axes.md',
    'docs/00-meta/datacube-aggregation-semantics.md',
    'docs/00-meta/datacube-conformance-lanes.md',
    'docs/00-meta/datacube-exactness-semantics.md',
    'docs/00-meta/datacube-change-history-lanes.md',
    'docs/00-meta/datacube-measurement-semantics.md',
    'docs/00-meta/load-bearing-source-register.md',
    'docs/00-meta/datacube-executable-crossing-evidence.md',
    'docs/30-architecture/architecture-overview.md',
    'docs/30-architecture/specimen-flow-90-portal-net-crossing-record-fixture-harness.md',
    'docs/30-architecture/specimen-flow-91-transparency-provenance-receipt-import.md',
    'docs/30-architecture/specimen-flow-92-verifier-disagreement-policy-epoch-drift.md',
    'docs/40-verification/README.md',
    'docs/40-verification/harbor-crossing-record-evidence-bundle-v0.md',
    'fixtures/README.md',
    'fixtures/harbor-crossing-record-evidence-bundle-v0.json',
    'tools/harbor_crossing_record_harness.py',
    'tools/check_harbor_crossing_record_bundle.py',
    'docs/00-meta/datacube-transparency-provenance-receipt-import.md',
    'docs/40-verification/harbor-transparency-provenance-receipt-bundle-v0.md',
    'fixtures/harbor-transparency-provenance-receipt-bundle-v0.json',
    'tools/harbor_transparency_receipt_harness.py',
    'tools/check_harbor_transparency_receipt_bundle.py',
    'docs/00-meta/datacube-verifier-disagreement-policy-epoch-drift.md',
    'docs/40-verification/harbor-verifier-disagreement-policy-epoch-bundle-v0.md',
    'fixtures/harbor-verifier-disagreement-policy-epoch-bundle-v0.json',
    'tools/harbor_verifier_disagreement_harness.py',
    'tools/check_harbor_verifier_disagreement_bundle.py',
    'docs/00-meta/datacube-property-mutation-coverage.md',
    'docs/30-architecture/specimen-flow-93-property-mutation-coverage-without-schema-promotion.md',
    'docs/40-verification/harbor-property-mutation-coverage-bundle-v0.md',
    'fixtures/harbor-property-mutation-coverage-bundle-v0.json',
    'tools/harbor_property_mutation_harness.py',
    'tools/check_harbor_property_mutation_bundle.py',
    'docs/00-meta/datacube-mutation-triage-and-corpus-pruning.md',
    'docs/30-architecture/specimen-flow-94-survived-mutant-triage-and-corpus-pruning.md',
    'docs/40-verification/harbor-mutation-triage-bundle-v0.md',
    'fixtures/harbor-mutation-triage-bundle-v0.json',
    'tools/harbor_mutation_triage_harness.py',
    'tools/check_harbor_mutation_triage_bundle.py',
    'docs/00-meta/datacube-checker-provenance-and-drift.md',
    'docs/30-architecture/specimen-flow-95-checker-provenance-and-guard-drift.md',
    'docs/40-verification/harbor-checker-provenance-bundle-v0.md',
    'fixtures/harbor-checker-provenance-bundle-v0.json',
    'tools/harbor_checker_provenance_harness.py',
    'tools/check_harbor_checker_provenance_bundle.py',
    'docs/00-meta/datacube-release-package-provenance.md',
    'docs/30-architecture/specimen-flow-96-release-package-provenance-and-bootstrap-guards.md',
    'docs/40-verification/harbor-release-package-provenance-bundle-v0.md',
    'fixtures/harbor-release-package-provenance-bundle-v0.json',
    'tools/harbor_release_package_provenance_harness.py',
    'tools/check_harbor_release_package_provenance_bundle.py',
    'tools/check_harbor_release_zip.py',
    'docs/00-meta/datacube-artifact-handoff-consumer-import.md',
    'docs/30-architecture/specimen-flow-97-artifact-handoff-consumer-import.md',
    'docs/40-verification/harbor-artifact-handoff-consumer-import-bundle-v0.md',
    'fixtures/harbor-artifact-handoff-consumer-import-bundle-v0.json',
    'tools/harbor_artifact_handoff_harness.py',
    'tools/check_harbor_artifact_handoff_bundle.py',
    'docs/00-meta/datacube-post-import-local-derivation-drift.md',
    'docs/30-architecture/specimen-flow-98-post-import-local-derivation-drift.md',
    'docs/40-verification/harbor-post-import-local-derivation-drift-bundle-v0.md',
    'fixtures/harbor-post-import-local-derivation-drift-bundle-v0.json',
    'tools/harbor_local_derivation_harness.py',
    'tools/check_harbor_local_derivation_bundle.py',
    'docs/00-meta/datacube-derivative-correction-propagation.md',
    'docs/30-architecture/specimen-flow-99-derivative-correction-propagation-and-repair-ack.md',
    'docs/40-verification/harbor-derivative-correction-propagation-bundle-v0.md',
    'fixtures/harbor-derivative-correction-propagation-bundle-v0.json',
    'tools/harbor_derivative_repair_harness.py',
    'tools/check_harbor_derivative_repair_bundle.py',
    'docs/00-meta/datacube-derivative-repair-retention-expiry.md',
    'docs/30-architecture/specimen-flow-100-derivative-repair-retention-expiry.md',
    'docs/40-verification/harbor-derivative-repair-retention-expiry-bundle-v0.md',
    'fixtures/harbor-derivative-repair-retention-expiry-bundle-v0.json',
    'tools/harbor_retention_expiry_harness.py',
    'tools/check_harbor_retention_expiry_bundle.py',
    'docs/00-meta/datacube-overlapping-correction-epochs.md',
    'docs/30-architecture/specimen-flow-101-overlapping-correction-epochs-and-derivative-lineage.md',
    'docs/40-verification/harbor-overlapping-correction-lineage-bundle-v0.md',
    'fixtures/harbor-overlapping-correction-lineage-bundle-v0.json',
    'tools/harbor_overlapping_epoch_lineage_harness.py',
    'tools/check_harbor_overlapping_epoch_lineage_bundle.py',
    'docs/00-meta/datacube-cross-cube-lineage-import.md',
    'docs/30-architecture/specimen-flow-102-cross-cube-lineage-import-without-inherited-status.md',
    'docs/40-verification/harbor-cross-cube-lineage-import-bundle-v0.md',
    'fixtures/harbor-cross-cube-lineage-import-bundle-v0.json',
    'tools/harbor_cross_cube_lineage_import_harness.py',
    'tools/check_harbor_cross_cube_lineage_import_bundle.py',
    'tools/check_all.py',
    'tools/harbor_executable_surface_registry.py',
    'tools/check_harbor_executable_surface_registry.py',
    'docs/00-meta/datacube-executable-surface-registry-audit.md',
    'docs/00-meta/datacube-foreign-import-revocation.md',
    'docs/30-architecture/specimen-flow-103-foreign-import-revocation-and-correction.md',
    'docs/40-verification/harbor-foreign-import-revocation-bundle-v0.md',
    'fixtures/harbor-foreign-import-revocation-bundle-v0.json',
    'tools/harbor_foreign_import_revocation_harness.py',
    'tools/check_harbor_foreign_import_revocation_bundle.py',
    'docs/00-meta/datacube-revocation-overlay-propagation.md',
    'docs/30-architecture/specimen-flow-104-revocation-overlay-propagation-public-surfaces.md',
    'docs/40-verification/harbor-revocation-overlay-propagation-bundle-v0.md',
    'fixtures/harbor-revocation-overlay-propagation-bundle-v0.json',
    'tools/harbor_revocation_overlay_propagation_harness.py',
    'tools/check_harbor_revocation_overlay_propagation_bundle.py',
    'tools/harbor_bundle_common.py',
    'tools/check_harbor_bundle_common_audit.py',
    'docs/00-meta/datacube-bundle-common-audit.md',
    'docs/00-meta/research-synthesis-2026-05-25-pass-cix.md',
    'docs/00-meta/slopos-companions-evaluation-2026-05-25-pass-cix.md',
    'docs/00-meta/research-synthesis-2026-05-25-pass-cviii.md',
    'docs/00-meta/slopos-companions-evaluation-2026-05-25-pass-cviii.md',
    'docs/90-inspirations/steal-these-ideas.md',
]


# Registry-backed executable surfaces are appended dynamically so future proof
# slices do not require duplicating every path in this legacy required list.
sys.path.insert(0, str(ROOT / 'tools'))
from harbor_executable_surface_registry import EXECUTABLE_SURFACES  # noqa: E402
for surface in EXECUTABLE_SURFACES:
    for key in ['meta_doc', 'specimen', 'verification_doc', 'fixture', 'harness', 'checker']:
        rel = surface[key]
        if rel not in required:
            required.append(rel)
for rel in ['tools/check_harbor_briefing_focus.py', 'docs/00-meta/datacube-briefing-focus-audit.md']:
    if rel not in required:
        required.append(rel)

missing = [p for p in required if not (ROOT / p).exists()]
if missing:
    print('Missing required surfaces:')
    for m in missing:
        print(' -', m)
    sys.exit(1)

actual = sorted(
    str(p.relative_to(ROOT))
    for p in ROOT.rglob('*')
    if p.is_file() and '.git' not in p.parts and p.name != '.DS_Store'
)

generated_python_bytecode = [p for p in actual if p.endswith('.pyc') or '/__pycache__/' in p]
if generated_python_bytecode:
    print('Generated Python bytecode detected in source tree:')
    for p in generated_python_bytecode:
        print(' -', p)
    sys.exit(1)

embedded_release_zips = [p for p in actual if p.endswith('.zip') and Path(p).name.startswith('Harbor-rev')]
if embedded_release_zips:
    print('Embedded release zip detected inside repo tree.')
    for p in embedded_release_zips:
        print(' -', p)
    sys.exit(1)

index = (ROOT / 'ARCHIVE_INDEX.md').read_text(errors='ignore').splitlines()
listed = sorted(line.split('`')[1] for line in index if line.strip().startswith('- `') and '`' in line)
if actual != listed:
    print('Archive index drift detected.')
    only_actual = [p for p in actual if p not in listed]
    only_listed = [p for p in listed if p not in actual]
    if only_actual:
        print('Unlisted files:')
        for p in only_actual:
            print(' -', p)
    if only_listed:
        print('Missing on disk:')
        for p in only_listed:
            print(' -', p)
    sys.exit(1)

manifest = json.loads((ROOT / 'RELEASE-MANIFEST.json').read_text())
receipt = json.loads((ROOT / 'REVISION-RECEIPT.json').read_text())
surface = json.loads((ROOT / 'SURFACE-STATUS.json').read_text())
context = json.loads((ROOT / 'context-pack.json').read_text())

if manifest.get('archive') != ROOT.name:
    print('Release manifest archive/name mismatch.')
    print(' manifest:', manifest.get('archive'))
    print(' root    :', ROOT.name)
    sys.exit(1)

if manifest.get('file_count') != len(actual):
    print('Release manifest file_count drift detected.')
    print(' manifest:', manifest.get('file_count'))
    print(' actual  :', len(actual))
    sys.exit(1)

revision_files = [
    'RELEASE-MANIFEST.json',
    'REVISION-RECEIPT.json',
    'SURFACE-STATUS.json',
    'QUESTION-REGISTRY.json',
    'ASSUMPTION-LEDGER.json',
    'FOREIGN-PRESSURE-LEDGER.json',
    'FOLLOWTHROUGH-QUEUE.json',
    'IRREVERSIBLE-DECISION-LEDGER.json',
    'context-pack.json',
]
revisions = {}
for rel in revision_files:
    data = json.loads((ROOT / rel).read_text())
    rev = data.get('revision')
    revisions.setdefault(rev, []).append(rel)
if len(revisions) != 1:
    print('Revision drift detected across core json surfaces:')
    for rev, files in revisions.items():
        print(f' - {rev}:')
        for rel in files:
            print('   -', rel)
    sys.exit(1)

focus_values = {
    ('REVISION-RECEIPT.json', 'summary'): receipt.get('summary'),
    ('RELEASE-MANIFEST.json', 'highlights'): manifest.get('highlights'),
    ('SURFACE-STATUS.json', 'latest_focus'): surface.get('latest_focus'),
    ('context-pack.json', 'latest_revision_focus'): context.get('latest_revision_focus'),
}
if len(set(focus_values.values())) != 1:
    print('Focus-summary drift detected across core json surfaces:')
    for (rel, field), value in focus_values.items():
        print(f' - {rel}:{field} = {value!r}')
    sys.exit(1)

codename_values = {
    ('REVISION-RECEIPT.json', 'codename'): receipt.get('codename'),
    ('RELEASE-MANIFEST.json', 'codename'): manifest.get('codename'),
}
if len(set(codename_values.values())) != 1:
    print('Codename drift detected across release surfaces:')
    for (rel, field), value in codename_values.items():
        print(f' - {rel}:{field} = {value!r}')
    sys.exit(1)



def collect_ids(value):
    ids = []
    if isinstance(value, dict):
        if 'id' in value and isinstance(value['id'], str):
            ids.append(value['id'])
        for child in value.values():
            ids.extend(collect_ids(child))
    elif isinstance(value, list):
        for child in value:
            ids.extend(collect_ids(child))
    return ids

for rel in ['QUESTION-REGISTRY.json', 'ASSUMPTION-LEDGER.json', 'FOREIGN-PRESSURE-LEDGER.json', 'FOLLOWTHROUGH-QUEUE.json']:
    data = json.loads((ROOT / rel).read_text())
    ids = collect_ids(data)
    dupes = [k for k, v in Counter(ids).items() if v > 1]
    if dupes:
        print('Duplicate id values detected in', rel)
        for d in dupes:
            print(' -', d)
        sys.exit(1)

question_data = json.loads((ROOT / 'QUESTION-REGISTRY.json').read_text())
question_nums = sorted(int(item['id'][1:]) for item in question_data.get('questions', []) if isinstance(item.get('id'), str) and re.fullmatch(r'Q\d{3}', item['id']))
expected = list(range(1, len(question_nums) + 1))
if question_nums != expected:
    print('QUESTION-REGISTRY.json ids are not gapless/sequential from Q001.')
    print(' found   :', [f'Q{n:03d}' for n in question_nums])
    print(' expected:', [f'Q{n:03d}' for n in expected])
    sys.exit(1)

followthrough = json.loads((ROOT / 'FOLLOWTHROUGH-QUEUE.json').read_text())
next_items = [item.get('id') for item in followthrough.get('items', []) if item.get('status') == 'next']
if len(next_items) > 1:
    print('Multiple followthrough items marked as next:')
    for item_id in next_items:
        print(' -', item_id)
    sys.exit(1)


allowed_followthrough_statuses = {'queued', 'next', 'done', 'parked', 'superseded', 'reopened'}
missing_followthrough_status = [item.get('id', '<unknown>') for item in followthrough.get('items', []) if 'status' not in item]
if missing_followthrough_status:
    print('FOLLOWTHROUGH-QUEUE.json items missing status:')
    for item_id in missing_followthrough_status:
        print(' -', item_id)
    sys.exit(1)
invalid_followthrough_status = [(item.get('id', '<unknown>'), item.get('status')) for item in followthrough.get('items', []) if item.get('status') not in allowed_followthrough_statuses]
if invalid_followthrough_status:
    print('FOLLOWTHROUGH-QUEUE.json items have invalid status:')
    for item_id, status in invalid_followthrough_status:
        print(f' - {item_id}: {status!r}')
    sys.exit(1)
if len(next_items) != 1:
    print('Exactly one followthrough item must be marked next.')
    print(' next items:', next_items)
    sys.exit(1)

assumption_data = json.loads((ROOT / 'ASSUMPTION-LEDGER.json').read_text())
allowed_assumption_statuses = {'active', 'parked', 'superseded', 'retired'}
missing_assumption_status = [item.get('id', '<unknown>') for item in assumption_data.get('assumptions', []) if 'status' not in item]
if missing_assumption_status:
    print('ASSUMPTION-LEDGER.json assumptions missing status:')
    for item_id in missing_assumption_status:
        print(' -', item_id)
    sys.exit(1)
invalid_assumption_status = [(item.get('id', '<unknown>'), item.get('status')) for item in assumption_data.get('assumptions', []) if item.get('status') not in allowed_assumption_statuses]
if invalid_assumption_status:
    print('ASSUMPTION-LEDGER.json assumptions have invalid status:')
    for item_id, status in invalid_assumption_status:
        print(f' - {item_id}: {status!r}')
    sys.exit(1)

question_data = json.loads((ROOT / 'QUESTION-REGISTRY.json').read_text())
allowed_question_statuses = set(question_data.get('allowed_statuses', [])) or {'open'}
invalid_question_status = [(item.get('id', '<unknown>'), item.get('status')) for item in question_data.get('questions', []) if item.get('status') not in allowed_question_statuses]
if invalid_question_status:
    print('QUESTION-REGISTRY.json questions have invalid status:')
    for item_id, status in invalid_question_status:
        print(f' - {item_id}: {status!r}')
    sys.exit(1)
open_count = sum(1 for item in question_data.get('questions', []) if item.get('status') == 'open')
if question_data.get('questions') and open_count == len(question_data.get('questions', [])):
    print('QUESTION-REGISTRY.json is all-open; use question statuses to distinguish answered, promoted, parked, superseded, or blocked questions.')
    sys.exit(1)

followthrough_nums = [int(item['id'][1:]) for item in followthrough.get('items', []) if isinstance(item.get('id'), str) and re.fullmatch(r'F\d{3}', item['id'])]
if followthrough_nums:
    latest_f = max(followthrough_nums)
    latest_item = next(item for item in followthrough.get('items', []) if item.get('id') == f'F{latest_f:03d}')
    if latest_item.get('status') != 'next':
        print('Latest followthrough item must be the single next item.')
        print(' latest:', latest_item.get('id'), latest_item.get('status'))
        sys.exit(1)
    prior = next((item for item in followthrough.get('items', []) if item.get('id') == f'F{latest_f - 1:03d}'), None)
    if prior is not None and prior.get('status') != 'done':
        print('Previous followthrough item must be done before a new next item is introduced.')
        print(' previous:', prior.get('id'), prior.get('status'))
        sys.exit(1)

changelog_lines = (ROOT / 'CHANGELOG.md').read_text(encoding='utf-8', errors='ignore').splitlines()
rev_heads = [line.strip() for line in changelog_lines if line.startswith('## rev')]
rev_dupes = [k for k, v in Counter(rev_heads).items() if v > 1]
if rev_dupes:
    print('Duplicate revision headings detected in CHANGELOG.md')
    for d in rev_dupes:
        print(' -', d)
    sys.exit(1)



biblio_lines = (ROOT / 'docs/00-meta/bibliography.md').read_text(encoding='utf-8', errors='ignore').splitlines()
for line in biblio_lines:
    if line.count('- **EXT-') > 1:
        print('Bibliography entry collision detected.')
        print(' -', line)
        sys.exit(1)

specimen_numbers = []
for path in (ROOT / 'docs' / '30-architecture').glob('specimen-flow-*.md'):
    m = re.match(r'specimen-flow-(\d+)-', path.name)
    if m:
        specimen_numbers.append(m.group(1))
dupe_specimen_numbers = [k for k, v in Counter(specimen_numbers).items() if v > 1]
if dupe_specimen_numbers:
    print('Duplicate specimen-flow numbers detected on disk:')
    for d in dupe_specimen_numbers:
        print(' -', d)
    sys.exit(1)

for rel in ['CHANGELOG.md', 'README.md', 'START_HERE.md', 'docs/README.md']:
    lines = (ROOT / rel).read_text(encoding='utf-8', errors='ignore').splitlines()
    top = [line.strip() for line in lines if line.startswith('# ')]
    dupes = [k for k, v in Counter(top).items() if v > 1]
    if dupes:
        print('Duplicate top-level headings detected in', rel)
        for d in dupes:
            print(' -', d)
        sys.exit(1)

current_revision = next(iter(revisions.keys()))
if rev_heads and not rev_heads[0].startswith(f'## {current_revision} '):
    print('CHANGELOG.md does not lead with the current revision heading.')
    print(' first heading:', rev_heads[0])
    print(' current rev  :', current_revision)
    sys.exit(1)


if current_revision != 'rev0001' and receipt.get('supersedes') == current_revision:
    print('Revision receipt supersedes itself, which is not allowed outside the founding revision.')
    print(' revision  :', current_revision)
    print(' supersedes:', receipt.get('supersedes'))
    sys.exit(1)

for rel in manifest.get('core_docs', []):
    if not (ROOT / rel).exists():
        print('Release manifest core_docs entry missing on disk:')
        print(' -', rel)
        sys.exit(1)


research_docs = [rel for rel in manifest.get('core_docs', []) if rel.startswith('docs/00-meta/research-synthesis-')]
evaluation_docs = [rel for rel in manifest.get('core_docs', []) if rel.startswith('docs/00-meta/slopos-companions-evaluation-')]
specimen_docs = [rel for rel in manifest.get('core_docs', []) if rel.startswith('docs/30-architecture/specimen-flow-')]
latest_wiring_docs = []
if research_docs:
    latest_wiring_docs.append(research_docs[-1])
if evaluation_docs:
    latest_wiring_docs.append(evaluation_docs[-1])
if specimen_docs:
    latest_wiring_docs.append(specimen_docs[-1])
for rel in latest_wiring_docs:
    for briefing in ['README.md', 'START_HERE.md', 'docs/README.md']:
        text = (ROOT / briefing).read_text(encoding='utf-8', errors='ignore')
        if rel not in text:
            print('Latest pass/specimen wiring missing from briefing surface:')
            print(' - briefing:', briefing)
            print(' - missing :', rel)
            sys.exit(1)

core_doc_passes = {}
for rel in manifest.get('core_docs', []):
    m = re.search(r'pass-([a-z0-9-]+)\.md$', rel)
    if not m:
        continue
    if 'research-synthesis-' in rel:
        core_doc_passes['research'] = m.group(1)
    elif 'slopos-companions-evaluation-' in rel:
        core_doc_passes['evaluation'] = m.group(1)
if set(core_doc_passes) == {'research', 'evaluation'} and len(set(core_doc_passes.values())) != 1:
    print('Latest research/evaluation pass mismatch detected in release manifest core_docs:')
    for kind, suffix in core_doc_passes.items():
        print(f' - {kind}: {suffix}')
    sys.exit(1)
if 'research' in core_doc_passes:
    pass_heading = f"## Pass {core_doc_passes['research'].upper()} additions"
    for rel in ['docs/00-meta/lessons-we-must-learn.md', 'docs/90-inspirations/steal-these-ideas.md']:
        text = (ROOT / rel).read_text(encoding='utf-8', errors='ignore')
        if pass_heading not in text:
            print('Latest pass heading missing from supporting surface:')
            print(' - surface:', rel)
            print(' - heading:', pass_heading)
            sys.exit(1)

for rel in ['README.md', 'START_HERE.md', 'docs/README.md', 'CHANGELOG.md', 'docs/00-meta/roadmap.md']:
    text = (ROOT / rel).read_text(encoding='utf-8', errors='ignore')
    if current_revision not in text:
        print('Current revision missing from briefing surface:')
        print(' -', rel)
        sys.exit(1)

roadmap_text = (ROOT / 'docs/00-meta/roadmap.md').read_text(encoding='utf-8', errors='ignore')
expected_focus_line = f"Current revision focus (`{current_revision}`): {receipt.get('summary')}."
if expected_focus_line not in roadmap_text:
    print('Roadmap current-revision focus line drift detected.')
    print(' expected:', expected_focus_line)
    sys.exit(1)


for rel in ['README.md', 'START_HERE.md', 'docs/README.md']:
    text_surface = (ROOT / rel).read_text(encoding='utf-8', errors='ignore')
    if receipt.get('summary') not in text_surface:
        print('Current revision focus summary missing from briefing surface:')
        print(' -', rel)
        print(' expected summary:', receipt.get('summary'))
        sys.exit(1)

specimen_nums = []
for path in (ROOT / 'docs' / '30-architecture').glob('specimen-flow-*.md'):
    m = re.match(r'specimen-flow-(\d+)-', path.name)
    if m:
        specimen_nums.append(int(m.group(1)))
if specimen_nums:
    latest_specimen = max(specimen_nums)
    expected_done = f'F{latest_specimen:03d}'
    done_ids = {item.get('id') for item in followthrough.get('items', []) if item.get('status') == 'done'}
    if expected_done not in done_ids:
        print('Latest specimen does not have matching done followthrough item.')
        print(' latest specimen:', latest_specimen)
        print(' expected done:', expected_done)
        sys.exit(1)

latest_specimen_docs = [rel for rel in manifest.get('core_docs', []) if rel.startswith('docs/30-architecture/specimen-flow-')]
if latest_specimen_docs:
    latest_manifest_specimen = latest_specimen_docs[-1]
    if not re.search(rf'specimen-flow-{latest_specimen:02d}-', latest_manifest_specimen):
        print('Release manifest latest specimen drift detected.')
        print(' manifest latest:', latest_manifest_specimen)
        print(' disk latest    :', latest_specimen)
        sys.exit(1)
contract_path = 'docs/00-meta/embryo-promotion-contract.md'
for rel in ['README.md', 'START_HERE.md', 'docs/README.md', 'CONTRIBUTING.md']:
    text = (ROOT / rel).read_text(encoding='utf-8', errors='ignore')
    if contract_path not in text and 'embryo-promotion contract' not in text.lower():
        print('Embryo-promotion contract missing from briefing/process surface:')
        print(' -', rel)
        sys.exit(1)

design_principles_path = 'docs/00-meta/datacube-design-principles.md'
for rel in ['README.md', 'START_HERE.md', 'docs/README.md', 'CONTRIBUTING.md']:
    text = (ROOT / rel).read_text(encoding='utf-8', errors='ignore')
    if design_principles_path not in text and 'datacube design principles' not in text.lower():
        print('Datacube design principles surface missing from briefing/process surface:')
        print(' -', rel)
        sys.exit(1)


stability_rings_path = 'docs/00-meta/datacube-stability-rings.md'
for rel in ['README.md', 'START_HERE.md', 'docs/README.md', 'CONTRIBUTING.md']:
    text = (ROOT / rel).read_text(encoding='utf-8', errors='ignore')
    if stability_rings_path not in text and 'datacube stability rings' not in text.lower():
        print('Datacube stability-rings surface missing from briefing/process surface:')
        print(' -', rel)
        sys.exit(1)

change_classes_path = 'docs/00-meta/datacube-change-classes.md'
for rel in ['README.md', 'START_HERE.md', 'docs/README.md', 'CONTRIBUTING.md']:
    text = (ROOT / rel).read_text(encoding='utf-8', errors='ignore')
    if change_classes_path not in text and 'datacube change classes' not in text.lower():
        print('Datacube change-classes surface missing from briefing/process surface:')
        print(' -', rel)
        sys.exit(1)

assertion_posture_path = 'docs/00-meta/datacube-assertion-posture.md'
for rel in ['README.md', 'START_HERE.md', 'docs/README.md', 'CONTRIBUTING.md']:
    text = (ROOT / rel).read_text(encoding='utf-8', errors='ignore')
    if assertion_posture_path not in text and 'datacube assertion posture' not in text.lower():
        print('Datacube assertion-posture surface missing from briefing/process surface:')
        print(' -', rel)
        sys.exit(1)

presence_semantics_path = 'docs/00-meta/datacube-presence-semantics.md'
for rel in ['README.md', 'START_HERE.md', 'docs/README.md', 'CONTRIBUTING.md']:
    text = (ROOT / rel).read_text(encoding='utf-8', errors='ignore')
    if presence_semantics_path not in text and 'datacube presence semantics' not in text.lower():
        print('Datacube presence-semantics surface missing from briefing/process surface:')
        print(' -', rel)
        sys.exit(1)

evidence_grades_path = 'docs/00-meta/datacube-evidence-grades.md'
for rel in ['README.md', 'START_HERE.md', 'docs/README.md', 'CONTRIBUTING.md']:
    text = (ROOT / rel).read_text(encoding='utf-8', errors='ignore')
    if evidence_grades_path not in text and 'datacube evidence grades' not in text.lower():
        print('Datacube evidence-grades surface missing from briefing/process surface:')
        print(' -', rel)
        sys.exit(1)

aggregation_semantics_path = 'docs/00-meta/datacube-aggregation-semantics.md'
for rel in ['README.md', 'START_HERE.md', 'docs/README.md', 'CONTRIBUTING.md']:
    text = (ROOT / rel).read_text(encoding='utf-8', errors='ignore')
    if aggregation_semantics_path not in text and 'datacube aggregation semantics' not in text.lower():
        print('Datacube aggregation-semantics surface missing from briefing/process surface:')
        print(' -', rel)
        sys.exit(1)


conformance_lanes_path = 'docs/00-meta/datacube-conformance-lanes.md'
for rel in ['README.md', 'START_HERE.md', 'docs/README.md', 'CONTRIBUTING.md']:
    text = (ROOT / rel).read_text(encoding='utf-8', errors='ignore')
    if conformance_lanes_path not in text and 'datacube conformance lanes' not in text.lower():
        print('Datacube conformance-lanes surface missing from briefing/process surface:')
        print(' -', rel)
        sys.exit(1)

exactness_semantics_path = 'docs/00-meta/datacube-exactness-semantics.md'
for rel in ['README.md', 'START_HERE.md', 'docs/README.md', 'CONTRIBUTING.md']:
    text = (ROOT / rel).read_text(encoding='utf-8', errors='ignore')
    if exactness_semantics_path not in text and 'datacube exactness semantics' not in text.lower():
        print('Datacube exactness-semantics surface missing from briefing/process surface:')
        print(' -', rel)
        sys.exit(1)


# Semantic overclaim scan for latest revision documents. This is deliberately small:
# guarded/refusal lines may mention forbidden phrases, but unguarded public-status closure must fail.
latest_docs_for_overclaim = [
    'docs/00-meta/research-synthesis-2026-05-26-pass-cxi.md',
    'docs/00-meta/slopos-companions-evaluation-2026-05-26-pass-cxi.md',
    'docs/00-meta/datacube-user-response-event-capture.md',
    'docs/00-meta/datacube-executable-count-audit.md',
    'docs/40-verification/harbor-user-response-event-bundle-v0.md',
    'docs/30-architecture/specimen-flow-106-user-response-reliance-event-capture.md',
]
for rel in latest_docs_for_overclaim:
    lines = (ROOT / rel).read_text(encoding='utf-8', errors='ignore').splitlines()
    for lineno, line in enumerate(lines, start=1):
        lower = line.lower()
        if not any(term in lower for term in ['corrected everywhere', 'global truth', 'compliant', 'resolved']):
            continue
        guard_words = ['not ', 'no ', 'without', 'unsupported', 'refuse', 'refused', 'refusal', 'reject', 'rejected', 'rejection', 'must not', 'non-promise', 'non_promises', 'counterfeit', 'guard', 'smaller than', 'unsafe', 'unless', 'blocked']
        if any(g in lower for g in guard_words):
            continue
        print('Possible unguarded public-status overclaim detected:')
        print(f' - {rel}:{lineno}: {line.strip()}')
        sys.exit(1)

print('Repo hygiene check passed for', ROOT.name)
