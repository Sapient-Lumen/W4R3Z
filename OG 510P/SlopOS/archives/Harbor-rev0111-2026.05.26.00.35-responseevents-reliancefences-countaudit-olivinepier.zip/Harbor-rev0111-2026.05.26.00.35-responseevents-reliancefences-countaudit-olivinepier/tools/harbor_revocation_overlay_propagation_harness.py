#!/usr/bin/env python3
"""Emit deterministic Harbor revocation-overlay propagation evidence.

F104 starts after Harbor can import companion changes as scoped revocation
overlays over prior foreign lineage.  The next pressure is public and local
propagation: public copies, mirrors, generated summaries, consumer notices,
local indexes, and warning cards need overlay evidence without turning that
evidence into green/red badges, compliance workflows, prior-falsity findings,
or global downstream repair.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

from harbor_bundle_common import digest, file_digest  # noqa: E402
import harbor_foreign_import_revocation_harness as f103  # noqa: E402

SCHEMA = "harbor-revocation-overlay-propagation-bundle"
VERSION = "0"
REVISION = "rev0111"

MEMBER_LABELS = [
    "overlay.source",
    "target.surface",
    "propagation.action",
    "visibility.render",
    "consumer.notice",
    "index.warning.state",
    "history.linkage",
    "verdict.summary",
]

NON_PROMOTION = [
    "no revocation propagation API",
    "no public badge workflow",
    "no compliance workflow",
    "no prior-falsity judgment",
    "no global downstream repair",
    "no notification guarantee",
    "no mirror/search truth plane",
    "no warning-card status engine",
    "no final SlopOS datacube shape",
]

CASE_PLAN: list[dict[str, Any]] = [
    {"id": "RO001", "candidate": "public_copy_overlay_scoped_note", "surface": "public_copy", "expected": "accepted"},
    {"id": "RO002", "candidate": "mirror_overlay_with_no_global_closure", "surface": "mirror", "expected": "accepted"},
    {"id": "RO003", "candidate": "generated_summary_overlay_with_source_digest", "surface": "generated_summary", "expected": "accepted"},
    {"id": "RO004", "candidate": "consumer_notice_delivery_without_read_claim", "surface": "consumer_notice", "expected": "accepted"},
    {"id": "RO005", "candidate": "local_index_overlay_quarantine", "surface": "local_index", "expected": "accepted"},
    {"id": "RO006", "candidate": "warning_card_split_state", "surface": "warning_card", "expected": "accepted"},
    {"id": "RO007", "candidate": "partial_propagation_unknown_surfaces_preserved", "surface": "mixed_public_surfaces", "expected": "accepted"},
    {"id": "RO008", "candidate": "sealed_revocation_overlay_public_summary_limit", "surface": "sealed_notice_summary", "expected": "accepted"},
    {"id": "RO009", "candidate": "stale_mirror_overlay_requires_recheck", "surface": "mirror", "expected": "accepted"},
    {"id": "RO010", "candidate": "multi_cube_conflict_overlays_keep_incomparable", "surface": "multi_cube_public_card", "expected": "accepted"},
    {"id": "RO011", "candidate": "green_badge_after_overlay_delivery", "surface": "public_copy", "expected": "rejected"},
    {"id": "RO012", "candidate": "red_badge_global_failure_after_overlay", "surface": "warning_card", "expected": "rejected"},
    {"id": "RO013", "candidate": "compliance_remediation_claim_from_overlay", "surface": "public_copy", "expected": "rejected"},
    {"id": "RO014", "candidate": "prior_falsehood_banner_from_overlay", "surface": "public_copy", "expected": "rejected"},
    {"id": "RO015", "candidate": "mirror_clean_as_all_copies_clean", "surface": "mirror", "expected": "rejected"},
    {"id": "RO016", "candidate": "summary_rewrite_without_source_digest", "surface": "generated_summary", "expected": "rejected"},
    {"id": "RO017", "candidate": "notice_delivered_as_read_and_applied", "surface": "consumer_notice", "expected": "rejected"},
    {"id": "RO018", "candidate": "index_refresh_as_truth", "surface": "local_index", "expected": "rejected"},
    {"id": "RO019", "candidate": "warning_card_sunset_without_scope", "surface": "warning_card", "expected": "rejected"},
    {"id": "RO020", "candidate": "sealed_overlay_as_public_truth", "surface": "sealed_notice_summary", "expected": "rejected"},
    {"id": "RO021", "candidate": "stale_overlay_as_current", "surface": "mirror", "expected": "rejected"},
    {"id": "RO022", "candidate": "auto_repair_after_overlay", "surface": "consumer_notice", "expected": "rejected"},
    {"id": "RO023", "candidate": "majority_overlays_choose_verdict", "surface": "multi_cube_public_card", "expected": "rejected"},
    {"id": "RO024", "candidate": "single_badge_over_mixed_overlays", "surface": "multi_cube_public_card", "expected": "rejected"},
    {"id": "RO025", "candidate": "compliance_failure_from_companion_notice", "surface": "public_copy", "expected": "rejected"},
    {"id": "RO026", "candidate": "global_downstream_repair_from_public_overlay", "surface": "mixed_public_surfaces", "expected": "rejected"},
    {"id": "RO027", "candidate": "retraction_erases_history", "surface": "public_copy", "expected": "rejected"},
    {"id": "RO028", "candidate": "callback_overlay_status", "surface": "consumer_notice", "expected": "rejected"},
    {"id": "RO029", "candidate": "timestamp_freshness_after_overlay", "surface": "local_index", "expected": "rejected"},
    {"id": "RO030", "candidate": "missing_source_revocation_digest", "surface": "public_copy", "expected": "rejected"},
]

FAILURE_REASONS = {
    "green_badge_after_overlay_delivery": "overlay_as_green_badge",
    "red_badge_global_failure_after_overlay": "overlay_as_red_global_failure",
    "compliance_remediation_claim_from_overlay": "overlay_as_compliance_remediation",
    "prior_falsehood_banner_from_overlay": "overlay_as_prior_falsehood",
    "mirror_clean_as_all_copies_clean": "mirror_clean_as_global_closure",
    "summary_rewrite_without_source_digest": "summary_missing_source_digest",
    "notice_delivered_as_read_and_applied": "delivery_as_read_applied",
    "index_refresh_as_truth": "index_refresh_as_truth",
    "warning_card_sunset_without_scope": "warning_sunset_missing_scope",
    "sealed_overlay_as_public_truth": "sealed_overlay_public_truth",
    "stale_overlay_as_current": "stale_overlay_as_current",
    "auto_repair_after_overlay": "overlay_as_automatic_repair",
    "majority_overlays_choose_verdict": "majority_overlay_verdict",
    "single_badge_over_mixed_overlays": "single_badge_mixed_overlays",
    "compliance_failure_from_companion_notice": "companion_notice_as_compliance_failure",
    "global_downstream_repair_from_public_overlay": "public_overlay_as_global_repair",
    "retraction_erases_history": "retraction_erases_history",
    "callback_overlay_status": "callback_as_overlay_status",
    "timestamp_freshness_after_overlay": "overlay_timestamp_as_freshness",
    "missing_source_revocation_digest": "missing_source_revocation_digest",
}

SURFACE_NON_PROMISES = {
    "public_copy": ["not global truth", "not prior falsehood", "not compliance status"],
    "mirror": ["not all mirrors clean", "not current without recheck", "not global closure"],
    "generated_summary": ["not source equivalent", "not compliance proof", "not repaired everywhere"],
    "consumer_notice": ["not read proof", "not applied proof", "not repair proof"],
    "local_index": ["not search truth", "not freshness", "not source repair"],
    "warning_card": ["not green badge", "not red badge", "not compliance finding"],
    "mixed_public_surfaces": ["not all surfaces reached", "not global downstream repair", "not badge collapse"],
    "sealed_notice_summary": ["not sealed evidence disclosure", "not public truth", "not full proof"],
    "multi_cube_public_card": ["not majority verdict", "not single badge", "not conflict resolution"],
}

def prior_f103_digest() -> str:
    path = ROOT / "fixtures" / "harbor-foreign-import-revocation-bundle-v0.json"
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))["bundle_digest"]
    return f103.build_bundle()["bundle_digest"]

def overlay_source(case: dict[str, Any]) -> dict[str, Any]:
    candidate = case["candidate"]
    missing_digest = candidate == "missing_source_revocation_digest"
    sealed = case["surface"] == "sealed_notice_summary"
    stale = candidate in {"stale_mirror_overlay_requires_recheck", "stale_overlay_as_current"}
    source = {
        "parent_bundle": "harbor-foreign-import-revocation-bundle-v0",
        "parent_bundle_digest": prior_f103_digest(),
        "parent_case_ref": f"FR{((int(case['id'][2:]) - 1) % 30) + 1:03d}",
        "overlay_id": f"overlay-{case['id'].lower()}",
        "overlay_class": "foreign_revocation_public_overlay",
        "overlay_digest_present": not missing_digest,
        "overlay_digest": None if missing_digest else digest({"overlay": case["id"], "candidate": candidate, "parent": prior_f103_digest()}),
        "overlay_clock": "2026-05-25T22:17:00Z",
        "sealed_source": sealed,
        "stale_source_overlay": stale,
        "source_non_promises": [
            "not Harbor authority by itself",
            "not prior falsehood",
            "not automatic repair",
            "not public truth",
            "not compliance finding",
        ],
    }
    return source

def target_surface(case: dict[str, Any], source: dict[str, Any]) -> dict[str, Any]:
    surface = case["surface"]
    target_digest = digest({"surface": surface, "case": case["id"], "source": source.get("overlay_digest")})
    return {
        "surface_kind": surface,
        "target_id": f"target-{surface}-{case['id'].lower()}",
        "target_digest": target_digest,
        "target_scope": "named surface only; neighbor surfaces remain unobserved",
        "prior_history_visible": True,
        "surface_non_promises": SURFACE_NON_PROMISES[surface],
        "mirror_or_search_scope_limited": surface in {"mirror", "local_index", "mixed_public_surfaces"},
        "sealed_summary_limit": surface == "sealed_notice_summary",
        "mixed_overlay_state": surface == "multi_cube_public_card",
    }

def propagation_action(case: dict[str, Any]) -> dict[str, Any]:
    candidate = case["candidate"]
    accepted = case["expected"] == "accepted"
    reached = ["canonical_public_copy"]
    if case["surface"] in {"mirror", "mixed_public_surfaces"}:
        reached.append("mirror-a")
    if case["surface"] in {"generated_summary", "mixed_public_surfaces"}:
        reached.append("generated-summary-a")
    if case["surface"] in {"consumer_notice", "mixed_public_surfaces"}:
        reached.append("consumer-inbox-a")
    if case["surface"] in {"local_index", "mixed_public_surfaces"}:
        reached.append("local-index-a")
    if case["surface"] in {"warning_card", "multi_cube_public_card"}:
        reached.append("warning-card-a")
    return {
        "action_id": f"propagate-{case['id'].lower()}",
        "reached_surfaces": reached,
        "unreached_surfaces_state": "unknown_preserved" if accepted or "global" in candidate else "overclaimed",
        "scope_map_present": candidate != "warning_card_sunset_without_scope",
        "label_carry_forward": candidate not in {"summary_rewrite_without_source_digest", "retraction_erases_history"},
        "source_digest_carried": candidate != "summary_rewrite_without_source_digest",
        "history_link_carried": candidate != "retraction_erases_history",
        "automatic_repair_claimed": candidate in {"auto_repair_after_overlay", "global_downstream_repair_from_public_overlay"},
        "global_closure_claimed": candidate in {"mirror_clean_as_all_copies_clean", "global_downstream_repair_from_public_overlay"},
        "majority_vote_used": candidate == "majority_overlays_choose_verdict",
        "callback_status_used": candidate == "callback_overlay_status",
        "propagation_digest": digest({"case": case["id"], "candidate": candidate, "reached": reached}),
    }

def visibility_render(case: dict[str, Any], action: dict[str, Any]) -> dict[str, Any]:
    candidate = case["candidate"]
    return {
        "display_mode": "scoped_overlay_note" if case["expected"] == "accepted" else "unsafe_collapsed_status",
        "green_badge_claimed": candidate == "green_badge_after_overlay_delivery",
        "red_badge_claimed": candidate == "red_badge_global_failure_after_overlay",
        "single_badge_over_mixed": candidate == "single_badge_over_mixed_overlays",
        "prior_falsehood_claimed": candidate == "prior_falsehood_banner_from_overlay",
        "compliance_remediation_claimed": candidate == "compliance_remediation_claim_from_overlay",
        "compliance_failure_claimed": candidate == "compliance_failure_from_companion_notice",
        "sealed_public_truth_claimed": candidate == "sealed_overlay_as_public_truth",
        "timestamp_freshness_claimed": candidate == "timestamp_freshness_after_overlay",
        "warning_sunset_without_scope": candidate == "warning_card_sunset_without_scope",
        "user_visible_non_promises": [
            "not global truth",
            "not all copies repaired",
            "not compliance status",
            "not proof notice was read",
            "not prior falsehood",
        ],
        "render_digest": digest({"case": case["id"], "display": candidate, "action": action["propagation_digest"]}),
    }

def consumer_notice(case: dict[str, Any]) -> dict[str, Any]:
    candidate = case["candidate"]
    return {
        "notice_id": f"notice-{case['id'].lower()}",
        "delivery_observed": case["surface"] in {"consumer_notice", "mixed_public_surfaces"} or candidate == "notice_delivered_as_read_and_applied",
        "read_claimed": candidate == "notice_delivered_as_read_and_applied",
        "applied_claimed": candidate == "notice_delivered_as_read_and_applied",
        "consumer_ack_claimed_repair": candidate == "auto_repair_after_overlay",
        "notification_guarantee_claimed": False,
        "problem_detail_reason": FAILURE_REASONS.get(candidate),
        "notice_non_promises": ["delivery is not read", "read is not applied", "acknowledgement is not repair"],
    }

def index_warning_state(case: dict[str, Any]) -> dict[str, Any]:
    candidate = case["candidate"]
    return {
        "index_refresh_observed": case["surface"] == "local_index" or candidate == "index_refresh_as_truth",
        "index_truth_claimed": candidate == "index_refresh_as_truth",
        "warning_card_state": "split_scoped" if case["surface"] in {"warning_card", "multi_cube_public_card"} and case["expected"] == "accepted" else "not_applicable_or_unsafe",
        "mixed_state_preserved": case["surface"] == "multi_cube_public_card" and candidate != "single_badge_over_mixed_overlays",
        "stale_overlay_as_current": candidate == "stale_overlay_as_current",
        "recheck_required": candidate in {"stale_mirror_overlay_requires_recheck", "stale_overlay_as_current"} or case["surface"] in {"mirror", "local_index"},
        "recheck_clock_basis": None if candidate == "timestamp_freshness_after_overlay" else "observation_clock_plus_source_digest",
        "state_digest": digest({"case": case["id"], "candidate": candidate, "surface": case["surface"]}),
    }

def history_linkage(case: dict[str, Any], source: dict[str, Any], action: dict[str, Any]) -> dict[str, Any]:
    candidate = case["candidate"]
    return {
        "parent_history_retained": candidate != "retraction_erases_history",
        "overlay_changes_current_display_not_past_observation": candidate != "retraction_erases_history",
        "history_erasure_claimed": candidate == "retraction_erases_history",
        "parent_import_falsehood_claimed": candidate == "prior_falsehood_banner_from_overlay",
        "lineage_digest": digest({"parent": source.get("parent_bundle_digest"), "overlay": source.get("overlay_digest"), "action": action["propagation_digest"]}),
        "history_non_promises": [
            "history is not currentness",
            "overlay is not erasure",
            "retraction is not repair",
            "display change is not source truth",
        ],
    }

def verdict_summary(case: dict[str, Any], source: dict[str, Any], action: dict[str, Any], render: dict[str, Any], notice: dict[str, Any], index_state: dict[str, Any], history: dict[str, Any]) -> dict[str, Any]:
    expected = case["expected"]
    candidate = case["candidate"]
    flags = {
        "missing_source_revocation_digest": not source["overlay_digest_present"],
        "green_badge_claimed": render["green_badge_claimed"],
        "red_badge_claimed": render["red_badge_claimed"],
        "compliance_claimed": render["compliance_remediation_claimed"] or render["compliance_failure_claimed"],
        "prior_falsehood_claimed": render["prior_falsehood_claimed"] or history["parent_import_falsehood_claimed"],
        "global_closure_claimed": action["global_closure_claimed"],
        "source_digest_missing": not action["source_digest_carried"],
        "delivery_as_read_applied": notice["read_claimed"] or notice["applied_claimed"],
        "index_truth_claimed": index_state["index_truth_claimed"],
        "warning_scope_missing": render["warning_sunset_without_scope"],
        "sealed_public_truth_claimed": render["sealed_public_truth_claimed"],
        "stale_currentness_claimed": index_state["stale_overlay_as_current"],
        "automatic_repair_claimed": action["automatic_repair_claimed"] or notice["consumer_ack_claimed_repair"],
        "majority_vote_used": action["majority_vote_used"],
        "single_badge_over_mixed": render["single_badge_over_mixed"],
        "history_erasure_claimed": history["history_erasure_claimed"],
        "callback_status_used": action["callback_status_used"],
        "timestamp_freshness_claimed": render["timestamp_freshness_claimed"],
    }
    failure_reasons = [] if expected == "accepted" else [FAILURE_REASONS[candidate]]
    return {
        "expected": expected,
        "verdict_class": "propagated_scoped_revocation_overlay" if expected == "accepted" else "refused_revocation_overlay_status_collapse",
        "failure_reasons": failure_reasons,
        "flags": flags,
        "public_badge_allowed": False,
        "compliance_claim_allowed": False,
        "global_repair_claim_allowed": False,
        "prior_falsehood_claim_allowed": False,
        "non_promises": NON_PROMOTION,
    }

def build_case(index: int, plan: dict[str, Any]) -> dict[str, Any]:
    case = {"index": index, **plan}
    source = overlay_source(case)
    target = target_surface(case, source)
    action = propagation_action(case)
    render = visibility_render(case, action)
    notice = consumer_notice(case)
    index_state = index_warning_state(case)
    history = history_linkage(case, source, action)
    verdict = verdict_summary(case, source, action, render, notice, index_state, history)
    members = {
        "overlay.source": source,
        "target.surface": target,
        "propagation.action": action,
        "visibility.render": render,
        "consumer.notice": notice,
        "index.warning.state": index_state,
        "history.linkage": history,
        "verdict.summary": verdict,
    }
    row = {"index": index, "id": case["id"], "candidate": case["candidate"], "surface": case["surface"], **members}
    row["row_digest"] = digest({label: row[label] for label in MEMBER_LABELS})
    return row

def build_bundle() -> dict[str, Any]:
    cases = [build_case(index, plan) for index, plan in enumerate(CASE_PLAN, start=1)]
    accepted = sum(1 for case in cases if case["verdict.summary"]["expected"] == "accepted")
    rejected = len(cases) - accepted
    bundle = {
        "schema": SCHEMA,
        "version": VERSION,
        "source_revision": REVISION,
        "member_labels": MEMBER_LABELS,
        "prior_foreign_revocation_bundle_digest": prior_f103_digest(),
        "bundle_common_helper_digest": file_digest(ROOT / "tools" / "harbor_bundle_common.py"),
        "cases": cases,
        "audit_refactor_note": {
            "refactor": "rev0109 introduces harbor_bundle_common.py and a bundle-common audit so checker helper idioms do not fork silently",
            "audit_guard": "check_harbor_bundle_common_audit checks bundle keys, digests, non-promotion lists, and generated bytecode absence",
            "non_promise": "bundle helpers are maintenance scaffolding, not schema, conformance status, or trust authority",
        },
        "global": {
            "case_count": len(cases),
            "accepted_count": accepted,
            "rejected_count": rejected,
            "source_revision": REVISION,
            "member_labels": MEMBER_LABELS,
            "coverage_claim": "Covers representative revocation-overlay propagation cases; not a revocation propagation API, badge workflow, compliance workflow, or notification guarantee.",
            "non_promotion": NON_PROMOTION,
        },
    }
    bundle["bundle_digest"] = digest({
        key: bundle[key]
        for key in ["schema", "version", "source_revision", "member_labels", "prior_foreign_revocation_bundle_digest", "bundle_common_helper_digest", "cases", "audit_refactor_note", "global"]
    })
    return bundle

def main() -> None:
    parser = argparse.ArgumentParser(description="Emit Harbor revocation-overlay propagation bundle")
    parser.add_argument("--output", type=Path, default=ROOT / "fixtures" / "harbor-revocation-overlay-propagation-bundle-v0.json")
    args = parser.parse_args()
    bundle = build_bundle()
    args.output.write_text(json.dumps(bundle, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(args.output)

if __name__ == "__main__":
    main()
