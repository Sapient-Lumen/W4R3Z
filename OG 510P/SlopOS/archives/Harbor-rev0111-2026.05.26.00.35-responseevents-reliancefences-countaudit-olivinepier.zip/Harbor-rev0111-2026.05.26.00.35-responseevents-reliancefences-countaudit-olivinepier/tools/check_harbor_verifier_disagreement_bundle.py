#!/usr/bin/env python3
"""Check the deterministic Harbor verifier-disagreement / policy-epoch drift bundle."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

import harbor_verifier_disagreement_harness as harness  # noqa: E402


def fail(message: str) -> None:
    print(message)
    raise SystemExit(1)


def expect(condition: bool, message: str) -> None:
    if not condition:
        fail(message)


FORBIDDEN_AUTHORITY_PHRASES = {
    "global truth",
    "semantic truth",
    "compliance truth",
    "authority truth",
    "trusted content",
    "fresh now",
    "global authority",
    "one badge truth",
}


def nested_contains_forbidden_authority_phrase(value: Any) -> bool:
    if isinstance(value, dict):
        return any(nested_contains_forbidden_authority_phrase(child) for child in value.values())
    if isinstance(value, list):
        return any(nested_contains_forbidden_authority_phrase(child) for child in value)
    if isinstance(value, str):
        lower = value.lower().replace("_", " ")
        if lower.startswith("not ") or lower.startswith("no ") or " not " in lower:
            return False
        return any(phrase in lower for phrase in FORBIDDEN_AUTHORITY_PHRASES)
    return False


def nested_contains_key_or_value(value: Any, forbidden: set[str]) -> bool:
    if isinstance(value, dict):
        for key, child in value.items():
            if key in forbidden:
                return True
            if isinstance(child, str) and child in forbidden:
                return True
            if nested_contains_key_or_value(child, forbidden):
                return True
    elif isinstance(value, list):
        for child in value:
            if isinstance(child, str) and child in forbidden:
                return True
            if nested_contains_key_or_value(child, forbidden):
                return True
    return False


def check_verifier_run(cid: str, run: dict[str, Any], *, allow_missing_policy_digest: bool = False) -> None:
    required = {
        "verifier_run_id",
        "verifier",
        "decision",
        "policy_id",
        "policy_digest",
        "policy_epoch",
        "input_digest",
        "currentness",
        "scope",
        "reason",
        "decision_is_semantic_truth",
        "run_digest",
    }
    if allow_missing_policy_digest:
        # The hostile omission case intentionally includes one malformed run; the
        # case-specific assertion below checks that at least one digest is absent.
        return
    expect(set(run.keys()) == required, f"{cid}: verifier run key drift for {run.get('verifier')}")
    expect(run["decision"] in harness.ALLOWED_VERIFIER_DECISIONS, f"{cid}: invalid verifier decision")
    expect(run["decision_is_semantic_truth"] is False, f"{cid}: verifier decision became semantic truth")
    expected_digest = harness.digest({k: v for k, v in run.items() if k != "run_digest"})
    expect(run["run_digest"] == expected_digest, f"{cid}: verifier run digest drift")


def check_bundle(bundle: dict[str, Any]) -> None:
    expect(bundle.get("schema") == harness.SCHEMA, "Unexpected bundle schema")
    expect(bundle.get("version") == harness.VERSION, "Unexpected bundle version")
    expect(bundle.get("revision") == harness.REVISION, "Unexpected bundle revision")
    expect(bundle.get("purpose", "").endswith("not a durable schema"), "Purpose must refuse durable schema promotion")
    expected_digest = harness.digest({k: v for k, v in bundle.items() if k != "bundle_digest"})
    expect(bundle.get("bundle_digest") == expected_digest, "Bundle digest drift")

    members = bundle.get("members")
    expect(isinstance(members, dict), "Bundle members must be an object")
    expect(list(members.keys()) == harness.MEMBER_LABELS, "Member labels/order drift")

    case_ids = list(members["case.matrix"].keys())
    expect(len(case_ids) == 14, "F092 bundle must keep fourteen stable cases")
    for label in harness.MEMBER_LABELS[1:]:
        expect(list(members[label].keys()) == case_ids, f"Case ids drift in {label}")

    accepted = 0
    rejected = 0
    for cid in case_ids:
        matrix = members["case.matrix"][cid]
        expected = matrix["expected"]
        receipts = members["input.receipt_set"][cid]
        runs = members["input.verifier_runs"][cid]
        record_or_candidate = members["input.disagreement_record"][cid]
        policy_epoch = members["policy_epoch.analysis"][cid]
        disagreement = members["disagreement.analysis"][cid]
        badge = members["badge.analysis"][cid]
        admission = members["output.admission"][cid]
        aftermath = members["output.aftermath"][cid]
        verdict = members["verdict.summary"][cid]

        expect(isinstance(receipts, list) and receipts, f"{cid}: receipt set missing")
        expect(isinstance(runs, list) and len(runs) >= 2, f"{cid}: at least two verifier runs required")
        for rx in receipts:
            expect(rx.get("subject_digest"), f"{cid}: receipt missing subject digest")
            expect(rx.get("receipt_digest") == harness.digest({k: v for k, v in rx.items() if k != "receipt_digest"}), f"{cid}: receipt digest drift")
        for run in runs:
            check_verifier_run(cid, run, allow_missing_policy_digest=(cid == "reject-policy-digest-omitted"))

        expect(policy_epoch.get("relation") in harness.ALLOWED_EPOCH_RELATIONS, f"{cid}: invalid policy epoch relation")
        expect(disagreement.get("preserved_verifier_runs") == len(runs), f"{cid}: disagreement analysis lost verifier run count")
        expect(verdict.get("non_promotion_checked") is True, f"{cid}: non-promotion bit missing")

        if expected == "accepted":
            accepted += 1
            record = record_or_candidate
            expect(admission.get("decision") == "accepted", f"{cid}: accepted case not admitted")
            expect(set(record.keys()) == set(harness.RECORD_TOP_KEYS), f"{cid}: disagreement record top-level key drift")
            expect(verdict.get("record_digest") == harness.digest(record), f"{cid}: record digest mismatch")
            expect(record["subject"]["digest"] == receipts[0]["subject_digest"], f"{cid}: subject digest not bound to receipts")
            expect(set(record["receipt_set"]) == {r["receipt_digest"] for r in receipts}, f"{cid}: receipt digests not preserved")
            expect(set(record["verifiers"]) == {v["run_digest"] for v in runs}, f"{cid}: verifier run digests not preserved")
            expect(record["policy_epochs"]["relation"] in harness.ALLOWED_EPOCH_RELATIONS, f"{cid}: invalid record epoch relation")
            expect(record["policy_epochs"].get("refused_retroactive_rewrite") is True, f"{cid}: retroactive rewrite not refused")
            expect(record["comparison"].get("preserved_verifier_count") == len(runs), f"{cid}: record lost verifier count")
            expect(record["comparison"].get("result") == "preserved_disagreement", f"{cid}: disagreement collapsed")
            expect(record["comparison"].get("majority_or_latest_wins") is False, f"{cid}: majority/latest wins leaked")
            expect(record["public_status"].get("badge") in harness.ALLOWED_BADGE_POSTURES, f"{cid}: invalid accepted badge posture")
            expect(record["public_status"].get("badge") not in harness.FORBIDDEN_BADGE_POSTURES, f"{cid}: forbidden badge posture")
            expect(record["public_status"].get("one_badge_truth") is False, f"{cid}: badge became truth")
            expect(record["public_status"].get("visible_disagreement") is True, f"{cid}: disagreement hidden")
            expect(record["currentness"].get("unknown_is_fresh") is False, f"{cid}: unknown currentness became fresh")
            expect(record["outcome"].get("class") not in harness.FORBIDDEN_OUTCOME_CLASSES, f"{cid}: forbidden accepted outcome")
            expect(harness.BASE_NON_PROMISES.issubset(set(record["outcome"].get("non_promises", []))), f"{cid}: missing base non-promises")
            expect(aftermath.get("durable_effect") == "bounded_disagreement_residue_only", f"{cid}: accepted aftermath overclaims")
            expect(verdict.get("admitted") is True, f"{cid}: admitted bit drift")
            expect(not nested_contains_key_or_value(record, {"global_truth", "compliance_truth", "future_policy_pass", "one_badge_truth_true"}), f"{cid}: ambient authority leaked")
            expect(not nested_contains_forbidden_authority_phrase(record), f"{cid}: forbidden authority/truth phrase leaked")
        elif expected == "rejected":
            rejected += 1
            expect(admission.get("decision") == "rejected", f"{cid}: rejected case admitted")
            expect(verdict.get("admitted") is False, f"{cid}: admitted bit drift")
            expect(verdict.get("reject_reason") == admission.get("reason"), f"{cid}: reject reason drift")
            expect(aftermath.get("record_id") is None, f"{cid}: rejected case emitted a record id")
            expect("no_disagreement_record_emitted" in aftermath.get("non_promises", []), f"{cid}: rejection lacks no-record non-promise")
            rec = record_or_candidate.get("candidate")
            expect(isinstance(rec, dict), f"{cid}: rejected case must carry candidate")
            expect(verdict.get("record_digest") == harness.digest(rec), f"{cid}: rejected candidate digest mismatch")
            if cid == "reject-single-green-badge-from-split":
                expect(rec["public_status"]["badge"] in harness.FORBIDDEN_BADGE_POSTURES, f"{cid}: green badge fixture lost")
                expect(rec["public_status"].get("one_badge_truth") is True, f"{cid}: one-badge truth fixture lost")
            if cid == "reject-latest-policy-retroactive-erasure":
                expect(rec["outcome"]["class"] == "retroactive_erasure", f"{cid}: retroactive erasure fixture lost")
                expect(rec["policy_epochs"].get("refused_retroactive_rewrite") is False, f"{cid}: retroactive rewrite mutation lost")
            if cid == "reject-stale-policy-claimed-current":
                expect(rec["policy_epochs"]["relation"] == "older_policy_superseded", f"{cid}: stale-policy relation lost")
                expect(rec["currentness"].get("claim") == "fresh_now", f"{cid}: fresh-now claim fixture lost")
            if cid == "reject-refusal-becomes-global-failure":
                expect(rec["outcome"]["class"] == "global_failure", f"{cid}: global failure fixture lost")
                expect(rec["comparison"].get("result") == "collapsed_to_refusal", f"{cid}: refusal collapse fixture lost")
            if cid == "reject-unknown-currentness-treated-fresh":
                expect(rec["currentness"].get("unknown_is_fresh") is True, f"{cid}: unknown-is-fresh fixture lost")
                expect(rec["public_status"]["badge"] == "fresh_now", f"{cid}: fresh-now badge fixture lost")
            if cid == "reject-issuer-compromise-auto-false":
                expect(rec["outcome"]["class"] == "auto_false_due_to_compromise", f"{cid}: compromise auto-false fixture lost")
                expect(not rec["outcome"].get("non_promises"), f"{cid}: stripped non-promises fixture lost")
            if cid == "reject-majority-vote-without-authority":
                expect(rec["comparison"].get("majority_or_latest_wins") is True, f"{cid}: majority-wins fixture lost")
                expect(rec["outcome"]["class"] == "majority_truth", f"{cid}: majority truth fixture lost")
            if cid == "reject-policy-digest-omitted":
                expect(not rec["policy_epochs"].get("policy_digests"), f"{cid}: missing-policy-digest fixture lost")
                expect(any("policy_digest" not in run for run in runs), f"{cid}: verifier input missing policy digest fixture lost")
        else:
            fail(f"{cid}: invalid expected outcome {expected!r}")

    global_ = bundle.get("global", {})
    expect(global_.get("case_count") == len(case_ids), "Global case_count drift")
    expect(global_.get("accepted_count") == accepted, "Global accepted_count drift")
    expect(global_.get("rejected_count") == rejected, "Global rejected_count drift")
    for refusal in ["no verifier arbitration schema", "no policy-drift ledger", "no public badge semantics", "no reliance API"]:
        expect(refusal in global_.get("non_promotion", []), f"Global non-promotion list missing {refusal}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Check Harbor verifier-disagreement bundle")
    parser.add_argument("--fixture", type=Path, default=ROOT / "fixtures" / "harbor-verifier-disagreement-policy-epoch-bundle-v0.json")
    args = parser.parse_args()

    expected = harness.build_bundle()
    check_bundle(expected)

    if args.fixture.exists():
        actual = json.loads(args.fixture.read_text(encoding="utf-8"))
        expect(actual == expected, "Checked fixture does not match deterministic harness output")
    else:
        fail(f"Fixture missing: {args.fixture}")

    print("Harbor verifier-disagreement policy-epoch bundle check passed")


if __name__ == "__main__":
    main()
