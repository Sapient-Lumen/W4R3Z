#!/usr/bin/env python3
"""Emit deterministic Harbor release-package provenance evidence.

F096 is about the packaged archive boundary: root identity, file inventory,
archive-index coherence, deterministic ZIP plan, build-environment capture, and
bootstrap verification receipts.  The bundle is intentionally smaller than a
release attestation profile, package trust root, reproducible-build claim, CI
status API, archive signature guarantee, or final SlopOS datacube shape.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import stat
import sys
import zipfile
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import harbor_executable_surface_registry as surface_registry  # noqa: E402
GENERATED_SOURCE_PARTS = {"__pycache__"}

def is_source_file(path: Path) -> bool:
    return (
        path.is_file()
        and ".git" not in path.parts
        and not any(part in GENERATED_SOURCE_PARTS for part in path.parts)
        and path.name != ".DS_Store"
        and path.suffix != ".pyc"
    )

SCHEMA = "harbor-release-package-provenance-bundle"
VERSION = "0"
REVISION = "rev0111"

MEMBER_LABELS = [
    "release.matrix",
    "root.identity",
    "file.inventory",
    "archive.index.check",
    "package.plan",
    "build.environment",
    "bootstrap.verification",
    "verdict.summary",
]

NON_PROMOTION = [
    "no release attestation profile",
    "no package trust root",
    "no reproducible-build claim",
    "no CI status API",
    "no archive signature guarantee",
    "no bootstrap self-trust",
    "no final SlopOS datacube shape",
]

CASE_PLAN: list[dict[str, Any]] = [
    {"id": "RP001", "candidate": "current_release_surfaces", "expected": "accepted"},
    {"id": "RP002", "candidate": "deterministic_zip_plan", "expected": "accepted"},
    {"id": "RP003", "candidate": "build_environment_capture", "expected": "accepted"},
    {"id": "RP004", "candidate": "out_of_band_verification_receipt", "expected": "accepted"},
    {"id": "RP005", "candidate": "archive_index_drift", "expected": "rejected"},
    {"id": "RP006", "candidate": "embedded_release_zip", "expected": "rejected"},
    {"id": "RP007", "candidate": "nondeterministic_zip_metadata", "expected": "rejected"},
    {"id": "RP008", "candidate": "stale_release_root_name", "expected": "rejected"},
    {"id": "RP009", "candidate": "generated_artifact_unlisted", "expected": "rejected"},
    {"id": "RP010", "candidate": "bootstrap_self_trust_attempt", "expected": "rejected"},
    {"id": "RP011", "candidate": "attestation_as_security_claim", "expected": "rejected"},
]

GENERATED_RELEASE_SURFACES = [
    "ARCHIVE_INDEX.md",
    "RELEASE-MANIFEST.json",
    "fixtures/harbor-release-package-provenance-bundle-v0.json",
    "fixtures/harbor-artifact-handoff-consumer-import-bundle-v0.json",
    "docs/40-verification/harbor-artifact-handoff-consumer-import-bundle-v0.md",
    "tools/check_harbor_artifact_handoff_bundle.py",
    "fixtures/harbor-post-import-local-derivation-drift-bundle-v0.json",
    "docs/40-verification/harbor-post-import-local-derivation-drift-bundle-v0.md",
    "tools/check_harbor_local_derivation_bundle.py",
    "fixtures/harbor-derivative-repair-retention-expiry-bundle-v0.json",
    "docs/40-verification/harbor-derivative-repair-retention-expiry-bundle-v0.md",
    "tools/check_harbor_retention_expiry_bundle.py",
    "fixtures/harbor-cross-cube-lineage-import-bundle-v0.json",
    "docs/40-verification/harbor-cross-cube-lineage-import-bundle-v0.md",
    "tools/check_harbor_cross_cube_lineage_import_bundle.py",
    "fixtures/harbor-foreign-import-revocation-bundle-v0.json",
    "docs/40-verification/harbor-foreign-import-revocation-bundle-v0.md",
    "tools/check_harbor_foreign_import_revocation_bundle.py",
    "tools/harbor_executable_surface_registry.py",
    "tools/check_harbor_executable_surface_registry.py",
    "tools/check_all.py",
    "fixtures/harbor-revocation-overlay-propagation-bundle-v0.json",
    "fixtures/harbor-user-visible-explanation-bundle-v0.json",
    "docs/40-verification/harbor-user-visible-explanation-bundle-v0.md",
    "tools/check_harbor_user_visible_explanation_bundle.py",
    "fixtures/harbor-user-response-event-bundle-v0.json",
    "docs/40-verification/harbor-user-response-event-bundle-v0.md",
    "tools/check_harbor_user_response_event_bundle.py",
    "tools/harbor_user_response_event_harness.py",
    "docs/00-meta/datacube-executable-count-audit.md",
]

RELEASE_CHECKERS = [
    *[surface["checker"] for surface in surface_registry.EXECUTABLE_SURFACES],
    "tools/check_repo_hygiene.py",
    "tools/harbor_executable_surface_registry.py",
    "tools/check_harbor_executable_surface_registry.py",
    "tools/check_harbor_bundle_common_audit.py",
    "tools/check_harbor_briefing_focus.py",
    "tools/check_all.py",
]


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def digest(value: Any) -> str:
    return "sha256:" + hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def file_digest(rel: str) -> str:
    return "sha256:" + hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()


def read_json(rel: str) -> dict[str, Any]:
    return json.loads((ROOT / rel).read_text(encoding="utf-8"))


def list_files() -> list[str]:
    return sorted(
        str(p.relative_to(ROOT)).replace(os.sep, "/")
        for p in ROOT.rglob("*")
        if is_source_file(p)
    )


def read_archive_index() -> list[str]:
    lines = (ROOT / "ARCHIVE_INDEX.md").read_text(encoding="utf-8", errors="ignore").splitlines()
    return sorted(line.split("`")[1] for line in lines if line.strip().startswith("- `") and "`" in line)


def root_identity(candidate: str) -> dict[str, Any]:
    manifest = read_json("RELEASE-MANIFEST.json")
    receipt = read_json("REVISION-RECEIPT.json")
    surface = read_json("SURFACE-STATUS.json")
    context = read_json("context-pack.json")
    root_name = ROOT.name
    manifest_archive = manifest.get("archive")
    if candidate == "stale_release_root_name":
        root_name = root_name.replace(REVISION, "rev0106")
        manifest_archive = str(manifest_archive).replace(REVISION, "rev0106")
    revisions = {
        "manifest": manifest.get("revision"),
        "receipt": receipt.get("revision"),
        "surface": surface.get("revision"),
        "context": context.get("revision"),
    }
    return {
        "root_name": root_name,
        "expected_root_name": ROOT.name,
        "manifest_archive": manifest_archive,
        "manifest_archive_matches_root": manifest_archive == ROOT.name,
        "revision_fields": revisions,
        "all_revision_fields_match": len(set(revisions.values())) == 1,
        "current_revision": manifest.get("revision"),
        "supersedes": receipt.get("supersedes"),
        "codename": manifest.get("codename"),
        "summary": manifest.get("highlights"),
        "root_name_is_release_scope_not_trust_root": True,
        "stale_release_root_refused": candidate == "stale_release_root_name",
    }


def file_inventory(candidate: str) -> dict[str, Any]:
    files = list_files()
    embedded_zips = [p for p in files if p.endswith(".zip") and Path(p).name.startswith("Harbor-rev")]
    generated_present = [p for p in GENERATED_RELEASE_SURFACES if p in files]
    generated_missing = [p for p in GENERATED_RELEASE_SURFACES if p not in files]
    if candidate == "embedded_release_zip":
        embedded_zips = embedded_zips + ["dist/Harbor-rev0100-stale.zip"]
    if candidate == "generated_artifact_unlisted":
        generated_missing = generated_missing + ["fixtures/harbor-release-package-provenance-bundle-v0.json"]
    return {
        "actual_file_count": len(files),
        "manifest_file_count": read_json("RELEASE-MANIFEST.json").get("file_count"),
        "file_count_matches_manifest": read_json("RELEASE-MANIFEST.json").get("file_count") == len(files),
        "actual_file_list_digest": digest(files),
        "embedded_release_zips": embedded_zips,
        "embedded_release_zip_refused": bool(embedded_zips),
        "generated_release_surfaces": generated_present,
        "generated_surface_missing": generated_missing,
        "generated_surface_listing_required": True,
        "inventory_is_not_archive_signature": True,
    }


def archive_index_check(candidate: str) -> dict[str, Any]:
    actual = list_files()
    listed = read_archive_index()
    if candidate == "archive_index_drift":
        listed = listed[:-1]
    if candidate == "generated_artifact_unlisted":
        listed = [p for p in listed if p != "fixtures/harbor-release-package-provenance-bundle-v0.json"]
    only_actual = [p for p in actual if p not in listed]
    only_listed = [p for p in listed if p not in actual]
    return {
        "actual_count": len(actual),
        "listed_count": len(listed),
        "actual_list_digest": digest(actual),
        "listed_list_digest": digest(listed),
        "index_file_digest": file_digest("ARCHIVE_INDEX.md"),
        "index_matches_actual": actual == listed,
        "only_actual": only_actual,
        "only_listed": only_listed,
        "archive_index_is_inventory_not_attestation": True,
    }


def package_plan(candidate: str) -> dict[str, Any]:
    script_text = (ROOT / "tools" / "package_release.py").read_text(encoding="utf-8", errors="ignore")
    zip_checker_text = (ROOT / "tools" / "check_harbor_release_zip.py").read_text(encoding="utf-8", errors="ignore")
    stable_timestamp = "info.date_time = (1980, 1, 1, 0, 0, 0)" in script_text
    deflated = "ZIP_DEFLATED" in script_text
    sorted_order = "return sorted(" in script_text and "ROOT.rglob('*')" in script_text
    no_ds_store = ".DS_Store" in script_text
    embedded_guard = "Embedded release zip detected" in (ROOT / "tools" / "check_repo_hygiene.py").read_text(encoding="utf-8", errors="ignore")
    archive_verifier_present = "date_time == (1980, 1, 1, 0, 0, 0)" in zip_checker_text
    if candidate == "nondeterministic_zip_metadata":
        stable_timestamp = False
        sorted_order = False
    return {
        "package_script": "tools/package_release.py",
        "package_script_digest": file_digest("tools/package_release.py"),
        "release_zip_checker": "tools/check_harbor_release_zip.py",
        "release_zip_checker_digest": file_digest("tools/check_harbor_release_zip.py"),
        "stable_zip_timestamp": stable_timestamp,
        "zip_timestamp_value": "1980-01-01T00:00:00Z" if stable_timestamp else "filesystem mtime or build clock",
        "uses_zip_deflated": deflated,
        "sorted_file_order": sorted_order,
        "filters_ds_store": no_ds_store,
        "embedded_release_zip_guard_present": embedded_guard,
        "archive_verifier_present": archive_verifier_present,
        "path_prefix_policy": f"{ROOT.name}/<relative-path>",
        "mode_policy": "stat.S_IMODE(path.stat().st_mode) or 0o644",
        "deterministic_plan_is_not_reproducible_build_claim": True,
    }


def build_environment(candidate: str) -> dict[str, Any]:
    env = {
        "python_implementation": platform.python_implementation(),
        "python_version": platform.python_version(),
        "platform_system": platform.system(),
        "platform_machine": platform.machine(),
        "zipfile_module": "python-stdlib-zipfile",
        "zip_deflated_constant": zipfile.ZIP_DEFLATED,
        "source_date_epoch": os.environ.get("SOURCE_DATE_EPOCH", "unset"),
        "pythondontwritebytecode": f"sys:{sys.dont_write_bytecode}",
    }
    if candidate == "build_environment_capture":
        capture_complete = True
    else:
        capture_complete = True
    return {
        "environment_capture": env,
        "capture_complete_for_this_fixture": capture_complete,
        "environment_capture_is_debugging_evidence": True,
        "environment_capture_is_not_portability_proof": True,
        "unknown_rebuilder_environment_refused_as_same_build": True,
    }


def bootstrap_verification(candidate: str) -> dict[str, Any]:
    scoped_out_of_band = candidate == "out_of_band_verification_receipt"
    self_trust_attempt = candidate == "bootstrap_self_trust_attempt"
    security_claim = candidate == "attestation_as_security_claim"
    return {
        "bootstrap_receipt_kind": "out-of-band package check" if scoped_out_of_band else "release package fixture observation",
        "make_check_command": ["make", "check"],
        "package_command": ["make", "package-release"],
        "zip_integrity_command": ["unzip", "-t", f"../{ROOT.name}.zip"],
        "harbor_zip_checker_command": ["python3", "tools/check_harbor_release_zip.py", f"../{ROOT.name}.zip"],
        "final_zip_digest_is_computed_after_packaging": True,
        "final_zip_digest_recorded_inside_fixture": False,
        "fixture_does_not_sign_or_certify_archive": True,
        "relies_on_internal_fixture_only": self_trust_attempt,
        "bootstrap_self_trust_refused": self_trust_attempt,
        "attestation_claim": "attestation proves secure and reproducible" if security_claim else "release receipt only binds observed package process facts",
        "attestation_as_security_refused": security_claim,
        "requires_external_reviewer_or_tool_to_check_zip_digest": True,
    }


def verdict_for(candidate: str, expected: str, root: dict[str, Any], inv: dict[str, Any], index: dict[str, Any], plan: dict[str, Any], env: dict[str, Any], boot: dict[str, Any]) -> dict[str, Any]:
    failure_reasons: list[str] = []
    if not root.get("manifest_archive_matches_root") or not root.get("all_revision_fields_match"):
        failure_reasons.append("root_identity_drift")
    if inv.get("embedded_release_zips"):
        failure_reasons.append("embedded_release_zip")
    if inv.get("generated_surface_missing"):
        failure_reasons.append("generated_release_surface_missing")
    if not inv.get("file_count_matches_manifest"):
        failure_reasons.append("manifest_file_count_drift")
    if not index.get("index_matches_actual"):
        failure_reasons.append("archive_index_drift")
    for key in ["stable_zip_timestamp", "uses_zip_deflated", "sorted_file_order", "filters_ds_store", "embedded_release_zip_guard_present", "archive_verifier_present"]:
        if not plan.get(key):
            failure_reasons.append(f"package_plan_missing_{key}")
    if not env.get("capture_complete_for_this_fixture"):
        failure_reasons.append("build_environment_not_captured")
    if boot.get("relies_on_internal_fixture_only"):
        failure_reasons.append("bootstrap_self_trust_attempt")
    if boot.get("attestation_as_security_refused"):
        failure_reasons.append("attestation_as_security_claim")
    admitted = not failure_reasons
    return {
        "expected": expected,
        "admitted": admitted,
        "expected_matched": (admitted and expected == "accepted") or ((not admitted) and expected == "rejected"),
        "verdict_class": "accepted_release_package_process_evidence" if admitted else "refused_counterfeit_release_package_confidence",
        "failure_reasons": failure_reasons,
        "does_not_establish_archive_signature": True,
        "does_not_establish_reproducible_build": True,
        "does_not_establish_artifact_security": True,
        "does_not_establish_ci_status": True,
        "non_promotion_checked": True,
    }


def build_bundle() -> dict[str, Any]:
    members: dict[str, Any] = {label: {} for label in MEMBER_LABELS}
    accepted = rejected = 0
    for idx, plan_row in enumerate(CASE_PLAN, start=1):
        case_id = plan_row["id"]
        candidate = plan_row["candidate"]
        expected = plan_row["expected"]
        root = root_identity(candidate)
        inv = file_inventory(candidate)
        index = archive_index_check(candidate)
        pplan = package_plan(candidate)
        env = build_environment(candidate)
        boot = bootstrap_verification(candidate)
        verdict = verdict_for(candidate, expected, root, inv, index, pplan, env, boot)
        if verdict["admitted"]:
            accepted += 1
        else:
            rejected += 1
        members["release.matrix"][case_id] = {
            "index": idx,
            "candidate": candidate,
            "expected": expected,
            "case_digest": digest({"candidate": candidate, "expected": expected}),
        }
        members["root.identity"][case_id] = root
        members["file.inventory"][case_id] = inv
        members["archive.index.check"][case_id] = index
        members["package.plan"][case_id] = pplan
        members["build.environment"][case_id] = env
        members["bootstrap.verification"][case_id] = boot
        members["verdict.summary"][case_id] = verdict

    bundle = {
        "schema": SCHEMA,
        "version": VERSION,
        "revision": REVISION,
        "purpose": "record release-package process evidence while remaining smaller than release attestations, package trust roots, reproducible-build claims, CI APIs, archive signatures, or durable schemas",
        "members": members,
        "global": {
            "case_count": len(CASE_PLAN),
            "accepted_count": accepted,
            "rejected_count": rejected,
            "source_file_count": len(list_files()),
            "source_file_list_digest": digest(list_files()),
            "archive_index_digest": file_digest("ARCHIVE_INDEX.md"),
            "package_script_digest": file_digest("tools/package_release.py"),
            "release_zip_checker_digest": file_digest("tools/check_harbor_release_zip.py"),
            "release_checkers": RELEASE_CHECKERS,
            "coverage_claim": "covers this release-package evidence fixture only; not CI status, not a trust root, not a reproducible-build claim",
            "final_zip_digest_boundary": "computed after package-release by out-of-band zip check; intentionally not embedded in this fixture",
            "non_promotion": NON_PROMOTION,
        },
    }
    bundle["bundle_digest"] = digest(bundle)
    return bundle


def main() -> None:
    parser = argparse.ArgumentParser(description="Emit Harbor release-package provenance bundle")
    parser.add_argument("--emit-bundle", action="store_true", help="write the bundle to stdout")
    parser.add_argument("--write", type=Path, help="write the bundle to a path")
    args = parser.parse_args()
    bundle = build_bundle()
    text = json.dumps(bundle, indent=2, sort_keys=False) + "\n"
    if args.write:
        args.write.parent.mkdir(parents=True, exist_ok=True)
        args.write.write_text(text, encoding="utf-8")
    if args.emit_bundle or not args.write:
        print(text, end="")


if __name__ == "__main__":
    main()
