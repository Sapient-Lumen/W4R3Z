#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import argparse
import json
import stat
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[1]
GENERATED_SOURCE_PARTS = {"__pycache__"}

def is_packaged_source(path: Path) -> bool:
    return (
        path.is_file()
        and ".git" not in path.parts
        and not any(part in GENERATED_SOURCE_PARTS for part in path.parts)
        and path.name != ".DS_Store"
        and path.suffix != ".pyc"
    )

def list_files() -> list[str]:
    return sorted(
        str(p.relative_to(ROOT))
        for p in ROOT.rglob('*')
        if is_packaged_source(p)
    )

def write_archive_index(files: list[str]) -> None:
    lines = ['# Archive index', '']
    lines.extend(f'- `{rel}`' for rel in files)
    (ROOT / 'ARCHIVE_INDEX.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')

def refresh_manifest(file_count: int) -> dict:
    manifest_path = ROOT / 'RELEASE-MANIFEST.json'
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    manifest['archive'] = ROOT.name
    manifest['file_count'] = file_count
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
    return manifest

def iter_files() -> list[Path]:
    return sorted(
        p for p in ROOT.rglob('*')
        if is_packaged_source(p)
    )

def stable_info(arcname: str, mode: int) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(arcname)
    info.date_time = (1980, 1, 1, 0, 0, 0)
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = (mode & 0xFFFF) << 16
    return info

def run_hygiene() -> None:
    subprocess.run(["python3", str(ROOT / "tools" / "check_all.py")], check=True)

def package(zip_path: Path) -> None:
    with zipfile.ZipFile(zip_path, 'w') as zf:
        for path in iter_files():
            rel = path.relative_to(ROOT)
            arcname = f"{ROOT.name}/{rel.as_posix()}"
            mode = path.stat().st_mode
            info = stable_info(arcname, stat.S_IMODE(mode) or 0o644)
            zf.writestr(info, path.read_bytes())

def main() -> None:
    parser = argparse.ArgumentParser(description='Refresh release surfaces and emit a deterministic zip bundle.')
    parser.add_argument('--skip-zip', action='store_true', help='only refresh ARCHIVE_INDEX.md and RELEASE-MANIFEST.json')
    parser.add_argument('--output-dir', default=str(ROOT.parent), help='directory that receives the zip bundle')
    args = parser.parse_args()

    files = list_files()
    write_archive_index(files)
    files = list_files()
    manifest = refresh_manifest(len(files))
    files = list_files()
    write_archive_index(files)

    run_hygiene()

    if args.skip_zip:
        print(f"Refreshed release surfaces for {manifest['archive']}")
        return

    outdir = Path(args.output_dir)
    outdir.mkdir(parents=True, exist_ok=True)
    zip_path = outdir / f"{ROOT.name}.zip"
    if zip_path.exists():
        zip_path.unlink()
    package(zip_path)
    subprocess.run(["python3", str(ROOT / "tools" / "check_harbor_release_zip.py"), str(zip_path)], check=True)
    print(zip_path)

if __name__ == '__main__':
    main()
