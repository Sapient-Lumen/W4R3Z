#!/usr/bin/env python3
"""Check the deterministic Harbor artifact handoff / consumer import bundle."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

import harbor_artifact_handoff_harness as harness  # noqa: E402


def fail(message: str) -> None:
    print(message)
    raise SystemExit(1)


def expect(condition: bool, message: str) -> None:
    if not condition:
        fail(message)


def check_bundle(bundle: dict[str, Any]) -> None:
    expect(bundle.get("schema") == harness.SCHEMA, "Unexpected bundle schema")
    expect(bundle.get("version") == harness.VERSION, "Unexpected bundle version")
    expect(bundle.get("revision") == harness.REVISION, "Unexpected bundle revision")
    expect("durable schemas" in bundle.get("purpose", ""), "Purpose must refuse durable-schema promotion")
    expected_digest = harness.digest({k: v for k, v in bundle.items() if k != "bundle_digest"})
    expect(bundle.get("bundle_digest") == expected_digest, "Bundle digest drift")

    members = bundle.get("members")
    expect(isinstance(members, dict), "Bundle members must be an object")
    expect(list(members.keys()) == harness.MEMBER_LABELS, "Member labels/order drift")
    matrix = members["handoff.matrix"]
    expect(len(matrix) == len(harness.CASE_PLAN), "F097 case count drift")
    for label in harness.MEMBER_LABELS[1:]:
        expect(list(members[label].keys()) == list(matrix.keys()), f"Case id/order drift in {label}")

    accepted = rejected = 0
    seen_indexes: list[int] = []
    seen_candidates: set[str] = set()
    for case_id, row in matrix.items():
        seen_indexes.append(row.get("index"))
        candidate = row.get("candidate")
        expected = row.get("expected")
        seen_candidates.add(candidate)
        expect(expected in {"accepted", "rejected"}, f"{case_id}: invalid expected outcome")
        expect(candidate, f"{case_id}: missing candidate")
        expect(row.get("case_digest", "").startswith("sha256:"), f"{case_id}: case digest missing")

        claim = members["release.claim"][case_id]
        transport = members["transport.observation"][case_id]
        material = members["material.identity"][case_id]
        verification = members["consumer.verification"][case_id]
        scope = members["scope.comparison"][case_id]
        verdict = members["verdict.summary"][case_id]

        expect(claim.get("claimed_revision") == harness.REVISION, f"{case_id}: release claim revision drift")
        expect(claim.get("filename_is_not_identity") is True, f"{case_id}: filename non-authority bit missing")
        expect(claim.get("release_claim_is_not_package_trust_root") is True, f"{case_id}: package trust-root refusal missing")
        expect(claim.get("final_zip_digest_not_predicted_by_source_fixture") is True, f"{case_id}: final zip boundary missing")

        expect(transport.get("transport_is_not_authority") is True, f"{case_id}: transport authority refusal missing")
        expect(transport.get("path_or_filename_is_not_identity") is True, f"{case_id}: path/name authority refusal missing")
        expect(transport.get("upload_timestamp_is_not_currentness") is True, f"{case_id}: upload timestamp refusal missing")
        expect(transport.get("callback_success_is_not_verification") is True, f"{case_id}: callback verification refusal missing")

        expect(material.get("digest_is_not_semantic_truth") is True, f"{case_id}: digest semantic-truth refusal missing")
        expect(material.get("digest_scope"), f"{case_id}: digest scope missing")
        if material.get("computed_digest_present"):
            expect(str(material.get("computed_digest", "")).startswith("sha256:"), f"{case_id}: computed digest malformed")
        expect(str(material.get("reference_digest", "")).startswith("sha256:"), f"{case_id}: reference digest malformed")

        expect(verification.get("requires_consumer_side_computation") is True, f"{case_id}: consumer computation requirement missing")
        for key in ["does_not_establish_package_trust_root", "does_not_establish_artifact_security", "does_not_establish_ci_status", "does_not_establish_compliance"]:
            expect(verification.get(key) is True, f"{case_id}: verification non-promise missing {key}")

        expect(isinstance(scope.get("forbidden_promotions"), list) and scope["forbidden_promotions"], f"{case_id}: forbidden promotions missing")
        expect("transport success as authority" in scope.get("forbidden_promotions", []), f"{case_id}: transport overclaim guard missing")
        expect(scope.get("allowed_statement"), f"{case_id}: allowed statement missing")

        expect(verdict.get("expected") == expected, f"{case_id}: expected echo drift")
        expect(verdict.get("expected_matched") is True, f"{case_id}: verdict did not match expected outcome")
        expect(verdict.get("non_promotion_checked") is True, f"{case_id}: non-promotion bit missing")
        for key in ["does_not_establish_package_trust_root", "does_not_establish_artifact_security", "does_not_establish_ci_status", "does_not_establish_global_downstream_copy_state"]:
            expect(verdict.get(key) is True, f"{case_id}: verdict non-promise missing {key}")

        if verdict.get("admitted"):
            accepted += 1
            expect(expected == "accepted", f"{case_id}: admitted rejected candidate")
            expect(material.get("material_identity_established") is True, f"{case_id}: admitted without material identity")
            expect(verdict.get("failure_reasons") == [], f"{case_id}: admitted with failure reasons")
            expect(scope.get("incomparable_or_insufficient") is False, f"{case_id}: admitted incomparable scope")
        else:
            rejected += 1
            expect(expected == "rejected", f"{case_id}: rejected accepted candidate")
            expect(verdict.get("verdict_class") == "refused_counterfeit_handoff_confidence", f"{case_id}: rejected verdict class drift")
            expect(verdict.get("failure_reasons"), f"{case_id}: rejected case without failure reasons")

        if candidate == "filename_only_match":
            expect("filename_only_claim" in verdict.get("failure_reasons", []), f"{case_id}: filename failure reason missing")
            expect(material.get("computed_digest_present") is False, f"{case_id}: filename-only candidate unexpectedly has digest")
        elif candidate == "pasted_digest_without_material":
            expect(material.get("pasted_digest_only") is True, f"{case_id}: pasted digest bit missing")
            expect("pasted_digest_without_material" in verdict.get("failure_reasons", []), f"{case_id}: pasted digest failure reason missing")
        elif candidate == "renamed_archive_name_as_identity":
            expect("renamed_archive_name_as_identity" in verdict.get("failure_reasons", []), f"{case_id}: renamed identity failure reason missing")
        elif candidate == "extracted_tree_missing_archive_index":
            expect(material.get("archive_index_present") is False, f"{case_id}: missing archive index not represented")
            expect("extracted_tree_missing_archive_index" in verdict.get("failure_reasons", []), f"{case_id}: missing index failure reason missing")
        elif candidate == "copied_fixture_without_parent_bundle":
            expect(material.get("fixture_parent_bundle_present") is False, f"{case_id}: fixture parent context unexpectedly present")
            expect("copied_fixture_without_parent_bundle" in verdict.get("failure_reasons", []), f"{case_id}: fixture context failure reason missing")
        elif candidate == "file_library_upload_timestamp_as_freshness":
            expect(transport.get("upload_timestamp_used_as_freshness") is True, f"{case_id}: upload freshness misuse not represented")
            expect("upload_timestamp_as_freshness" in verdict.get("failure_reasons", []), f"{case_id}: upload timestamp failure reason missing")
        elif candidate == "portal_callback_success_as_verification":
            expect(transport.get("callback_status") == "success", f"{case_id}: callback success not represented")
            expect("callback_success_as_verification" in verdict.get("failure_reasons", []), f"{case_id}: callback failure reason missing")
        elif candidate == "zip_digest_applied_to_extracted_tree":
            expect(material.get("zip_digest_misapplied_to_tree") is True, f"{case_id}: zip/tree scope misuse missing")
            expect("zip_digest_applied_to_extracted_tree" in verdict.get("failure_reasons", []), f"{case_id}: zip digest scope failure reason missing")
        elif candidate == "downstream_repack_digest_mismatch":
            expect("material_digest_mismatch" in verdict.get("failure_reasons", []), f"{case_id}: repack digest mismatch failure reason missing")
        elif candidate == "hidden_generated_artifact_added":
            expect(material.get("hidden_extra_artifacts"), f"{case_id}: hidden extra artifact not represented")
            expect("hidden_generated_artifact_added" in verdict.get("failure_reasons", []), f"{case_id}: hidden artifact failure reason missing")
        elif candidate == "consumer_ack_as_reliance_claim":
            expect(verification.get("consumer_ack_present") is True, f"{case_id}: consumer ack overclaim not represented")
            expect("consumer_ack_as_reliance_claim" in verdict.get("failure_reasons", []), f"{case_id}: consumer ack failure reason missing")

    expect(seen_indexes == list(range(1, len(matrix) + 1)), "Handoff indexes must be gapless")
    expect(seen_candidates == {row["candidate"] for row in harness.CASE_PLAN}, "Not all F097 candidate classes are represented")

    global_ = bundle.get("global", {})
    expect(global_.get("case_count") == len(matrix), "Global case_count drift")
    expect(global_.get("accepted_count") == accepted, "Global accepted_count drift")
    expect(global_.get("rejected_count") == rejected, "Global rejected_count drift")
    expect(global_.get("release_manifest_revision") == harness.REVISION, "Global manifest revision drift")
    expect("not the actual packaged archive digest" in global_.get("reference_release_digest_scope", ""), "Final zip digest boundary missing from global scope")
    expect("not a consumer verification API" in global_.get("coverage_claim", ""), "Coverage claim must refuse consumer API promotion")
    for refusal in harness.NON_PROMOTION:
        expect(refusal in global_.get("non_promotion", []), f"Global non-promotion list missing {refusal}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Check Harbor artifact handoff / consumer import bundle")
    parser.add_argument("--fixture", type=Path, default=ROOT / "fixtures" / "harbor-artifact-handoff-consumer-import-bundle-v0.json")
    args = parser.parse_args()

    expected = harness.build_bundle()
    check_bundle(expected)
    if args.fixture.exists():
        actual = json.loads(args.fixture.read_text(encoding="utf-8"))
        expect(actual == expected, "Checked fixture does not match deterministic harness output")
    else:
        fail(f"Fixture missing: {args.fixture}")
    print("Harbor artifact handoff / consumer import bundle check passed")


if __name__ == "__main__":
    main()
