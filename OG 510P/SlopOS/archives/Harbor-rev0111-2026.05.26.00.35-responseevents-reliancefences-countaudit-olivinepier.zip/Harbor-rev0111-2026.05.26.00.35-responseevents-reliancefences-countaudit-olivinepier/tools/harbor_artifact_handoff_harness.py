#!/usr/bin/env python3
"""Emit deterministic Harbor artifact handoff / consumer import evidence.

F097 is about the moment after a release package leaves the source tree.  A
consumer can receive a zip, extract a tree, copy a fixture, paste a digest,
rename an archive, upload it to a file library, or route it through a portal
callback.  Harbor records those as handoff/import observations without turning
transport, filename, upload timestamp, callback success, or a pasted checksum
into package authority.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]

SCHEMA = "harbor-artifact-handoff-consumer-import-bundle"
VERSION = "0"
REVISION = "rev0111"

MEMBER_LABELS = [
    "handoff.matrix",
    "release.claim",
    "transport.observation",
    "material.identity",
    "consumer.verification",
    "scope.comparison",
    "verdict.summary",
]

NON_PROMOTION = [
    "no consumer verification API",
    "no handoff attestation profile",
    "no package trust root",
    "no CI status API",
    "no artifact security guarantee",
    "no file-library authority",
    "no callback authority",
    "no final SlopOS datacube shape",
]

CASE_PLAN: list[dict[str, Any]] = [
    {"id": "HI001", "candidate": "received_release_zip_verified_digest", "expected": "accepted"},
    {"id": "HI002", "candidate": "extracted_tree_verified_manifest_index", "expected": "accepted"},
    {"id": "HI003", "candidate": "copied_fixture_with_parent_bundle_context", "expected": "accepted"},
    {"id": "HI004", "candidate": "renamed_archive_with_computed_digest", "expected": "accepted"},
    {"id": "HI005", "candidate": "portal_callback_handoff_with_post_material_verification", "expected": "accepted"},
    {"id": "HI006", "candidate": "file_library_upload_with_digest_recheck", "expected": "accepted"},
    {"id": "HI007", "candidate": "filename_only_match", "expected": "rejected"},
    {"id": "HI008", "candidate": "pasted_digest_without_material", "expected": "rejected"},
    {"id": "HI009", "candidate": "renamed_archive_name_as_identity", "expected": "rejected"},
    {"id": "HI010", "candidate": "extracted_tree_missing_archive_index", "expected": "rejected"},
    {"id": "HI011", "candidate": "copied_fixture_without_parent_bundle", "expected": "rejected"},
    {"id": "HI012", "candidate": "file_library_upload_timestamp_as_freshness", "expected": "rejected"},
    {"id": "HI013", "candidate": "portal_callback_success_as_verification", "expected": "rejected"},
    {"id": "HI014", "candidate": "zip_digest_applied_to_extracted_tree", "expected": "rejected"},
    {"id": "HI015", "candidate": "downstream_repack_digest_mismatch", "expected": "rejected"},
    {"id": "HI016", "candidate": "hidden_generated_artifact_added", "expected": "rejected"},
    {"id": "HI017", "candidate": "consumer_ack_as_reliance_claim", "expected": "rejected"},
]


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def digest(value: Any) -> str:
    return "sha256:" + hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def file_digest(rel: str) -> str:
    return "sha256:" + hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()


def read_json(rel: str) -> dict[str, Any]:
    return json.loads((ROOT / rel).read_text(encoding="utf-8"))


def reference_release_digest() -> str:
    """Fixture-local stand-in for a consumer-observed final zip digest.

    The real final zip digest is computed after packaging by
    check_harbor_release_zip.py.  This deterministic digest is only used to
    exercise handoff logic; the bundle explicitly refuses to embed or predict
    the actual archive digest.
    """
    manifest = read_json("RELEASE-MANIFEST.json")
    return digest(
        {
            "kind": "consumer_observed_release_zip_bytes_digest_fixture_stub",
            "archive": manifest.get("archive"),
            "revision": manifest.get("revision"),
            "scope": "F097 handoff fixture only; not final package digest",
        }
    )


def reference_tree_digest() -> str:
    manifest = read_json("RELEASE-MANIFEST.json")
    return digest(
        {
            "kind": "consumer_observed_extracted_tree_digest_fixture_stub",
            "archive_index": "present and matched",
            "archive": manifest.get("archive"),
            "revision": manifest.get("revision"),
            "scope": "F097 extracted tree fixture only",
        }
    )


def reference_fixture_digest() -> str:
    return file_digest("fixtures/harbor-crossing-record-evidence-bundle-v0.json")


def release_claim(candidate: str) -> dict[str, Any]:
    manifest = read_json("RELEASE-MANIFEST.json")
    archive = manifest.get("archive")
    claim_name = archive
    claim_source = "release manifest plus consumer observation"
    if candidate == "renamed_archive_with_computed_digest":
        claim_name = "Harbor-current.zip"
    elif candidate == "renamed_archive_name_as_identity":
        claim_name = archive
        claim_source = "renamed filename only"
    elif candidate == "filename_only_match":
        claim_source = "filename only"
    elif candidate == "pasted_digest_without_material":
        claim_source = "chat pasted digest"
    elif candidate == "downstream_repack_digest_mismatch":
        claim_name = f"repacked-{archive}.zip"
    return {
        "claimed_revision": manifest.get("revision"),
        "manifest_revision": manifest.get("revision"),
        "claimed_archive_name": claim_name,
        "manifest_archive_name": archive,
        "claim_source": claim_source,
        "claim_name_matches_manifest": claim_name == archive,
        "rename_observed": claim_name != archive,
        "filename_is_not_identity": True,
        "release_claim_is_not_package_trust_root": True,
        "final_zip_digest_not_predicted_by_source_fixture": True,
    }


def transport_observation(candidate: str) -> dict[str, Any]:
    channel = "downloaded_zip"
    transform = "none"
    locator = "consumer/downloads/Harbor-release.zip"
    callback_status = "not_applicable"
    upload_timestamp_used_as_freshness = False
    if candidate in {"extracted_tree_verified_manifest_index", "extracted_tree_missing_archive_index", "zip_digest_applied_to_extracted_tree", "hidden_generated_artifact_added"}:
        channel = "extracted_directory"
        transform = "zip_extraction"
        locator = "consumer/work/Harbor-extracted/"
    elif candidate in {"copied_fixture_with_parent_bundle_context", "copied_fixture_without_parent_bundle"}:
        channel = "copied_fixture_file"
        transform = "file_copy"
        locator = "consumer/work/fixtures/harbor-crossing-record-evidence-bundle-v0.json"
    elif candidate == "pasted_digest_without_material":
        channel = "chat_or_issue_comment"
        transform = "digest_paste"
        locator = "conversation digest text"
    elif candidate in {"renamed_archive_with_computed_digest", "renamed_archive_name_as_identity"}:
        channel = "renamed_archive"
        transform = "filename_rename"
        locator = "consumer/downloads/Harbor-current.zip"
    elif candidate in {"file_library_upload_with_digest_recheck", "file_library_upload_timestamp_as_freshness"}:
        channel = "file_library_upload"
        transform = "upload_copy"
        locator = "file_library://upload/harbor"
        upload_timestamp_used_as_freshness = candidate == "file_library_upload_timestamp_as_freshness"
    elif candidate in {"portal_callback_handoff_with_post_material_verification", "portal_callback_success_as_verification"}:
        channel = "portal_callback"
        transform = "portal_mediated_transfer"
        locator = "portal://callback/return-token"
        callback_status = "success"
    elif candidate == "downstream_repack_digest_mismatch":
        channel = "downstream_repack"
        transform = "repack"
        locator = "consumer/dist/repacked-harbor.zip"
    return {
        "channel": channel,
        "transform": transform,
        "observed_locator": locator,
        "callback_status": callback_status,
        "upload_timestamp": "2026-05-23T05:10:00-04:00" if channel == "file_library_upload" else None,
        "upload_timestamp_used_as_freshness": upload_timestamp_used_as_freshness,
        "transport_is_not_authority": True,
        "path_or_filename_is_not_identity": True,
        "upload_timestamp_is_not_currentness": True,
        "callback_success_is_not_verification": True,
        "portal_receipt_requires_post_material_check": channel == "portal_callback",
    }


def material_identity(candidate: str) -> dict[str, Any]:
    release_digest = reference_release_digest()
    tree_digest = reference_tree_digest()
    fixture_digest = reference_fixture_digest()
    material_kind = "release_zip_bytes"
    bytes_available = True
    computed_digest_present = True
    computed_digest = release_digest
    reference_digest = release_digest
    digest_scope = "release_zip_bytes"
    archive_index_present = True
    archive_index_matches_manifest = True
    fixture_parent_bundle_present = False
    hidden_extra_artifacts: list[str] = []
    pasted_digest_only = False
    zip_digest_misapplied_to_tree = False

    if candidate in {"extracted_tree_verified_manifest_index", "extracted_tree_missing_archive_index", "zip_digest_applied_to_extracted_tree", "hidden_generated_artifact_added"}:
        material_kind = "extracted_tree"
        computed_digest = tree_digest
        reference_digest = tree_digest
        digest_scope = "extracted_tree_manifest"
    if candidate in {"copied_fixture_with_parent_bundle_context", "copied_fixture_without_parent_bundle"}:
        material_kind = "fixture_file"
        computed_digest = fixture_digest
        reference_digest = fixture_digest
        digest_scope = "fixture_file_bytes"
        fixture_parent_bundle_present = candidate == "copied_fixture_with_parent_bundle_context"
    if candidate in {"filename_only_match", "renamed_archive_name_as_identity", "portal_callback_success_as_verification"}:
        computed_digest_present = False
        computed_digest = None
    if candidate == "pasted_digest_without_material":
        material_kind = "pasted_digest"
        bytes_available = False
        computed_digest_present = False
        computed_digest = None
        reference_digest = release_digest
        digest_scope = "digest_text_only"
        pasted_digest_only = True
    if candidate == "extracted_tree_missing_archive_index":
        archive_index_present = False
        archive_index_matches_manifest = False
    if candidate == "file_library_upload_timestamp_as_freshness":
        computed_digest_present = False
        computed_digest = None
    if candidate == "zip_digest_applied_to_extracted_tree":
        computed_digest = release_digest
        reference_digest = tree_digest
        digest_scope = "release_zip_bytes_misapplied_to_tree"
        zip_digest_misapplied_to_tree = True
    if candidate == "downstream_repack_digest_mismatch":
        computed_digest = digest({"kind": "downstream_repack_bytes", "archive": ROOT.name, "extra": "local comment"})
        reference_digest = release_digest
        digest_scope = "downstream_repack_bytes"
    if candidate == "hidden_generated_artifact_added":
        hidden_extra_artifacts = ["consumer/generated/report-cache.json"]
        computed_digest = digest({"kind": "tree_with_hidden_extra", "extra": hidden_extra_artifacts, "base": tree_digest})
        reference_digest = tree_digest
    digest_matches_reference = computed_digest_present and computed_digest == reference_digest
    material_identity_established = (
        bytes_available
        and computed_digest_present
        and digest_matches_reference
        and not pasted_digest_only
        and not zip_digest_misapplied_to_tree
        and archive_index_present
        and archive_index_matches_manifest
        and not hidden_extra_artifacts
        and (material_kind != "fixture_file" or fixture_parent_bundle_present)
    )
    return {
        "material_kind": material_kind,
        "bytes_available_for_consumer_check": bytes_available,
        "computed_digest_present": computed_digest_present,
        "computed_digest": computed_digest,
        "reference_digest": reference_digest,
        "digest_scope": digest_scope,
        "digest_matches_reference": digest_matches_reference,
        "archive_index_present": archive_index_present,
        "archive_index_matches_manifest": archive_index_matches_manifest,
        "fixture_parent_bundle_present": fixture_parent_bundle_present,
        "hidden_extra_artifacts": hidden_extra_artifacts,
        "pasted_digest_only": pasted_digest_only,
        "zip_digest_misapplied_to_tree": zip_digest_misapplied_to_tree,
        "material_identity_established": material_identity_established,
        "identity_basis": "computed bytes under declared scope" if material_identity_established else "insufficient or scope-mismatched material evidence",
        "digest_is_not_semantic_truth": True,
    }


def consumer_verification(candidate: str, material: dict[str, Any]) -> dict[str, Any]:
    action = "compute release zip digest and compare out-of-band"
    if material["material_kind"] == "extracted_tree":
        action = "compare extracted tree inventory to archive index and manifest revision"
    elif material["material_kind"] == "fixture_file":
        action = "check fixture digest plus parent bundle/checker context"
    elif candidate == "pasted_digest_without_material":
        action = "no verifier input available; digest text cannot be checked"
    elif candidate in {"portal_callback_handoff_with_post_material_verification", "portal_callback_success_as_verification"}:
        action = "portal callback observed; post-material digest check required"
    consumer_ack_overclaim = candidate == "consumer_ack_as_reliance_claim"
    return {
        "verification_action": action,
        "verifier_input_available": material["bytes_available_for_consumer_check"] and material["computed_digest_present"],
        "verifier_scope": material["digest_scope"],
        "consumer_ack_present": consumer_ack_overclaim,
        "consumer_ack_claim": "consumer acknowledged import, therefore relied, secured, and compliant" if consumer_ack_overclaim else "none",
        "consumer_ack_is_not_reliance_or_security": not consumer_ack_overclaim,
        "requires_consumer_side_computation": True,
        "does_not_establish_package_trust_root": True,
        "does_not_establish_artifact_security": True,
        "does_not_establish_ci_status": True,
        "does_not_establish_compliance": True,
    }


def scope_comparison(candidate: str, claim: dict[str, Any], transport: dict[str, Any], material: dict[str, Any]) -> dict[str, Any]:
    source_scope = "release archive boundary"
    consumer_scope = material["material_kind"]
    transform = transport["transform"]
    if material["material_kind"] == "release_zip_bytes" and material["digest_matches_reference"]:
        comparison = "same bytes within fixture reference digest" if not claim["rename_observed"] else "same bytes despite renamed locator"
    elif material["material_kind"] == "extracted_tree" and material["material_identity_established"]:
        comparison = "derived extraction with manifest/index match, not same object as zip"
    elif material["material_kind"] == "fixture_file" and material["material_identity_established"]:
        comparison = "narrow fixture-file match with parent-bundle context"
    else:
        comparison = "incomparable or insufficient"
    return {
        "source_scope": source_scope,
        "consumer_scope": consumer_scope,
        "transform_kind": transform,
        "scope_comparison": comparison,
        "same_scope": comparison.startswith("same bytes"),
        "derived_but_comparable": comparison.startswith("derived extraction") or comparison.startswith("narrow fixture"),
        "incomparable_or_insufficient": comparison == "incomparable or insufficient",
        "allowed_statement": "consumer material matches the observed handoff scope" if not comparison.startswith("incomparable") else "no import identity statement allowed",
        "forbidden_promotions": [
            "transport success as authority",
            "filename as identity",
            "upload timestamp as currentness",
            "callback success as verification",
            "pasted digest as material possession",
            "consumer acknowledgement as reliance or security",
        ],
    }


def verdict_for(
    candidate: str,
    expected: str,
    claim: dict[str, Any],
    transport: dict[str, Any],
    material: dict[str, Any],
    verification: dict[str, Any],
    scope: dict[str, Any],
) -> dict[str, Any]:
    failure_reasons: list[str] = []
    if claim["claim_source"] == "filename only":
        failure_reasons.append("filename_only_claim")
    if material["pasted_digest_only"]:
        failure_reasons.append("pasted_digest_without_material")
    if candidate == "renamed_archive_name_as_identity" and not material["computed_digest_present"]:
        failure_reasons.append("renamed_archive_name_as_identity")
    if transport["upload_timestamp_used_as_freshness"]:
        failure_reasons.append("upload_timestamp_as_freshness")
    if candidate == "portal_callback_success_as_verification" and not material["computed_digest_present"]:
        failure_reasons.append("callback_success_as_verification")
    if material["material_kind"] == "extracted_tree" and not material["archive_index_present"]:
        failure_reasons.append("extracted_tree_missing_archive_index")
    if material["material_kind"] == "fixture_file" and not material["fixture_parent_bundle_present"]:
        failure_reasons.append("copied_fixture_without_parent_bundle")
    if material["zip_digest_misapplied_to_tree"]:
        failure_reasons.append("zip_digest_applied_to_extracted_tree")
    if material["computed_digest_present"] and not material["digest_matches_reference"]:
        failure_reasons.append("material_digest_mismatch")
    if material["hidden_extra_artifacts"]:
        failure_reasons.append("hidden_generated_artifact_added")
    if verification["consumer_ack_present"] and not verification["consumer_ack_is_not_reliance_or_security"]:
        failure_reasons.append("consumer_ack_as_reliance_claim")
    if not material["material_identity_established"] and not failure_reasons:
        failure_reasons.append("material_identity_not_established")

    admitted = not failure_reasons
    return {
        "expected": expected,
        "admitted": admitted,
        "expected_matched": (admitted and expected == "accepted") or ((not admitted) and expected == "rejected"),
        "verdict_class": "accepted_scoped_consumer_import_evidence" if admitted else "refused_counterfeit_handoff_confidence",
        "failure_reasons": failure_reasons,
        "allowed_statement": scope["allowed_statement"] if admitted else "no consumer import identity statement allowed",
        "does_not_establish_package_trust_root": True,
        "does_not_establish_artifact_security": True,
        "does_not_establish_ci_status": True,
        "does_not_establish_global_downstream_copy_state": True,
        "non_promotion_checked": True,
    }


def build_bundle() -> dict[str, Any]:
    members: dict[str, Any] = {label: {} for label in MEMBER_LABELS}
    accepted = rejected = 0
    for idx, plan in enumerate(CASE_PLAN, start=1):
        case_id = plan["id"]
        candidate = plan["candidate"]
        expected = plan["expected"]
        claim = release_claim(candidate)
        transport = transport_observation(candidate)
        material = material_identity(candidate)
        verification = consumer_verification(candidate, material)
        scope = scope_comparison(candidate, claim, transport, material)
        verdict = verdict_for(candidate, expected, claim, transport, material, verification, scope)
        if verdict["admitted"]:
            accepted += 1
        else:
            rejected += 1
        members["handoff.matrix"][case_id] = {
            "index": idx,
            "candidate": candidate,
            "expected": expected,
            "case_digest": digest({"candidate": candidate, "expected": expected}),
        }
        members["release.claim"][case_id] = claim
        members["transport.observation"][case_id] = transport
        members["material.identity"][case_id] = material
        members["consumer.verification"][case_id] = verification
        members["scope.comparison"][case_id] = scope
        members["verdict.summary"][case_id] = verdict

    bundle = {
        "schema": SCHEMA,
        "version": VERSION,
        "revision": REVISION,
        "purpose": "record artifact handoff and consumer-import evidence while remaining smaller than consumer verification APIs, handoff attestations, package trust roots, CI status, artifact-security claims, or durable schemas",
        "members": members,
        "global": {
            "case_count": len(CASE_PLAN),
            "accepted_count": accepted,
            "rejected_count": rejected,
            "reference_release_digest_scope": "fixture-local stand-in for consumer-observed final zip bytes; not the actual packaged archive digest",
            "release_manifest_revision": read_json("RELEASE-MANIFEST.json").get("revision"),
            "release_manifest_archive": read_json("RELEASE-MANIFEST.json").get("archive"),
            "coverage_claim": "covers this F097 handoff/import fixture only; not a consumer verification API, not CI status, not a trust root",
            "handoff_boundary": "transport observation + material identity + consumer-side verification + scope comparison must all stay separate",
            "non_promotion": NON_PROMOTION,
        },
    }
    bundle["bundle_digest"] = digest(bundle)
    return bundle


def main() -> None:
    parser = argparse.ArgumentParser(description="Emit Harbor artifact handoff / consumer import bundle")
    parser.add_argument("--emit-bundle", action="store_true", help="write the bundle to stdout")
    parser.add_argument("--write", type=Path, help="write the bundle to a path")
    args = parser.parse_args()
    bundle = build_bundle()
    text = json.dumps(bundle, indent=2, sort_keys=False) + "\n"
    if args.write:
        args.write.parent.mkdir(parents=True, exist_ok=True)
        args.write.write_text(text, encoding="utf-8")
    if args.emit_bundle or not args.write:
        print(text, end="")


if __name__ == "__main__":
    main()
