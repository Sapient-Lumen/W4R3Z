#!/usr/bin/env python3
"""Check Harbor cross-cube lineage import bundle v0."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import harbor_cross_cube_lineage_import_harness as harness  # noqa: E402


def fail(message: str) -> None:
    print(message, file=sys.stderr)
    raise SystemExit(1)


def expect(condition: bool, message: str) -> None:
    if not condition:
        fail(message)


def check_digest_string(value: str, message: str) -> None:
    expect(isinstance(value, str) and value.startswith("sha256:") and len(value) == 71, message)


def check_case(case: dict[str, Any]) -> None:
    case_id = case["id"]
    candidate = case["candidate"]
    expected = case["import.matrix"]["expected"]
    cubes = case["import.matrix"]["cubes"]
    material = case["foreign.material"]
    observation = case["local.observation"]
    scope = case["scope.translation"]
    quarantine = case["authority.quarantine"]
    bridge = case["lineage.bridge"]
    recheck = case["recheck.plan"]
    verdict = case["verdict.summary"]

    expect(case["row_digest"] == harness.digest({key: case[key] for key in harness.MEMBER_LABELS}), f"{case_id}: row digest drift")
    expect(cubes == harness.imported_cubes({"cubes": cubes}), f"{case_id}: cube list not stable")
    expect(set(cubes).issubset(harness.FOREIGN_CATALOG), f"{case_id}: unknown cube imported")
    expect(material["foreign_input_count"] == len(cubes), f"{case_id}: input count drift")
    expect(observation["foreign_fragment_digests"] == [harness.fragment_digest(cube, candidate) for cube in cubes], f"{case_id}: fragment digest list drift")
    check_digest_string(observation["local_root_digest"], f"{case_id}: local root digest malformed")
    check_digest_string(bridge["prior_harbor_lineage_bundle_digest"], f"{case_id}: prior lineage digest malformed")
    check_digest_string(bridge["bridge_digest"], f"{case_id}: bridge digest malformed")
    expect(recheck["recheck_required_before_status"] is True, f"{case_id}: status admission must require recheck")
    expect(verdict["public_badge_allowed"] is False, f"{case_id}: public badge cannot be allowed")
    expect(verdict["compliance_claim_allowed"] is False, f"{case_id}: compliance claim cannot be allowed")
    expect("not inherited Harbor status" in quarantine["authority_non_promises"], f"{case_id}: missing status non-promise")

    for row in material["foreign_inputs"]:
        cube = row["cube"]
        meta = harness.FOREIGN_CATALOG[cube]
        expect(row["foreign_revision"] == meta["revision"], f"{case_id}: {cube} revision drift")
        expect(row["archive_sha256_expected"] == meta["archive_sha256"], f"{case_id}: {cube} expected digest drift")
        expect(row["fragment_family"] == meta["fragment_family"], f"{case_id}: {cube} fragment family drift")
        expect(row["safe_harbor_use"] == meta["safe_harbor_use"], f"{case_id}: {cube} safe use drift")
        expect(row["fragment_digest"] == harness.fragment_digest(cube, candidate), f"{case_id}: {cube} fragment digest drift")
        check_digest_string(row["fragment_digest"], f"{case_id}: {cube} fragment digest malformed")

    flags = quarantine["flags"]
    if expected == "accepted":
        expect(verdict["verdict_class"] == "admitted_foreign_lineage_material_with_status_quarantine", f"{case_id}: accepted verdict class drift")
        expect(verdict["failure_reasons"] == [], f"{case_id}: accepted case has failure reasons")
        expect(verdict["inherited_status_admitted"] is False, f"{case_id}: accepted case admitted inherited status")
        expect(flags["any_inherited_status"] is False, f"{case_id}: accepted case has inherited status flag")
        expect(quarantine["quarantine_state"] == "passed", f"{case_id}: accepted quarantine state drift")
        expect(material["all_archive_digests_ok"] is True, f"{case_id}: accepted case archive digest mismatch")
        expect(material["all_parent_manifests_present"] is True, f"{case_id}: accepted case missing parent manifest")
    else:
        expect(verdict["verdict_class"] == "refused_foreign_lineage_status_inheritance", f"{case_id}: rejected verdict class drift")
        expect(verdict["failure_reasons"], f"{case_id}: rejected case lacks failure reason")
        expect(quarantine["quarantine_state"] == "failed", f"{case_id}: rejected quarantine state drift")
        expect(harness.FAILURE_REASONS[candidate] in verdict["failure_reasons"], f"{case_id}: expected failure reason absent")

    # Candidate-specific evidence checks. These are the actual pressure seams.
    if candidate == "slopos_portal_append_imported_as_ordering_witness":
        expect(quarantine["allowed_harbor_uses"] == ["ordering_witness_only"], f"{case_id}: SlopOS use widened")
        expect(scope["semantic_supersession_requested"] is False, f"{case_id}: ordering witness became supersession")
    elif candidate == "foundry_classification_pin_imported_as_label_provenance":
        expect(quarantine["allowed_harbor_uses"] == ["label_provenance_only"], f"{case_id}: Foundry use widened")
    elif candidate == "steward_retry_history_imported_as_attempt_history":
        expect(quarantine["allowed_harbor_uses"] == ["attempt_history_only"], f"{case_id}: Steward use widened")
    elif candidate == "schell_retention_context_imported_without_deletion_claim":
        expect(recheck["retention_or_forgetting_requires_subject_digest_check"] is True, f"{case_id}: Schell subject-digest guard absent")
        expect(flags["erasure_proof_inherited"] is False, f"{case_id}: Schell erasure proof inherited")
    elif candidate == "viewfs_volition_card_imported_as_consent_evidence_only":
        expect(flags["consent_outcome_inherited"] is False, f"{case_id}: ViewFS consent outcome inherited")
    elif candidate == "ward_delegation_warrant_imported_as_route_evidence_only":
        expect(flags["authority_transfer_inherited"] is False, f"{case_id}: Ward authority transfer inherited")
    elif candidate == "helm_repair_trace_imported_with_harbor_scope_recheck":
        expect(recheck["repair_evidence_requires_local_scope_check"] is True, f"{case_id}: Helm repair trace lacks recheck")
        expect(flags["repair_inherited"] is False, f"{case_id}: Helm repair inherited")
    elif candidate == "multi_cube_conflicting_fragments_admitted_as_incomparable_split":
        expect(scope["relation"] == "incomparable_split", f"{case_id}: conflict not kept as split")
        expect(flags["majority_policy_inherited"] is False, f"{case_id}: majority imported")
    elif candidate == "sealed_foreign_packet_imported_by_digest_with_public_summary_limit":
        expect(bridge["sealed_evidence_public_summary_limit"] is True, f"{case_id}: sealed summary limit absent")
        expect(flags["public_truth_inherited"] is False, f"{case_id}: sealed public truth inherited")
    elif candidate == "stale_companion_revision_imported_as_historical_residue":
        expect(recheck["historical_residue_only"] is True, f"{case_id}: stale revision not historical")
        expect(flags["currentness_inherited"] is False, f"{case_id}: stale revision inherited currentness")
    elif candidate == "foreign_green_status_inherited_as_harbor_status":
        expect(flags["harbor_status_inherited"] is True, f"{case_id}: green status overclaim not represented")
    elif candidate == "replay_availability_imported_as_currentness":
        expect(flags["currentness_inherited"] is True, f"{case_id}: replay/currentness overclaim not represented")
    elif candidate == "retention_window_imported_as_repair":
        expect(flags["repair_inherited"] is True, f"{case_id}: retention/repair overclaim not represented")
    elif candidate == "foreign_warning_state_imported_as_public_badge":
        expect(flags["public_badge_inherited"] is True and scope["single_public_badge_requested"] is True, f"{case_id}: warning badge overclaim not represented")
    elif candidate == "companion_revision_imported_as_freshness":
        expect(flags["currentness_inherited"] is True and recheck["stale_companion_revision"] is True, f"{case_id}: revision freshness overclaim not represented")
    elif candidate == "foreign_scope_widened_on_import":
        expect(scope["widened_without_authority"] is True and scope["scope_map_present"] is False, f"{case_id}: scope widening not represented")
    elif candidate == "foreign_archive_digest_mismatch_accepted":
        expect(material["all_archive_digests_ok"] is False, f"{case_id}: digest mismatch not represented")
    elif candidate == "copied_fragment_without_parent_manifest":
        expect(material["all_parent_manifests_present"] is False, f"{case_id}: missing parent manifest not represented")
    elif candidate == "cross_cube_total_order_without_clock_map":
        expect(bridge["cross_cube_total_order_attempt"] is True and bridge["cross_cube_clock_map_present"] is False, f"{case_id}: total-order overclaim not represented")
    elif candidate == "mixed_cube_policy_majority_wins":
        expect(bridge["foreign_policy_majority_attempt"] is True and flags["majority_policy_inherited"] is True, f"{case_id}: majority policy overclaim not represented")
    elif candidate == "sealed_foreign_evidence_imported_as_public_truth":
        expect(bridge["sealed_evidence_claims_public_truth"] is True and flags["public_truth_inherited"] is True, f"{case_id}: sealed public-truth overclaim not represented")
    elif candidate == "foreign_acknowledgement_imported_as_consumer_repair":
        expect(flags["repair_inherited"] is True, f"{case_id}: ack repair overclaim not represented")
    elif candidate == "callback_success_imported_as_authority":
        expect(flags["authority_transfer_inherited"] is True, f"{case_id}: callback authority overclaim not represented")
    elif candidate == "slopos_append_order_imported_as_semantic_supersession":
        expect(flags["semantic_supersession_inherited"] is True and scope["semantic_supersession_requested"] is True, f"{case_id}: append supersession overclaim not represented")
    elif candidate == "foundry_classification_pin_imported_as_status_truth":
        expect(flags["classification_status_truth_inherited"] is True, f"{case_id}: classification status truth overclaim not represented")
    elif candidate == "steward_retry_exhaustion_imported_as_compliance_failure":
        expect(flags["compliance_failure_inherited"] is True, f"{case_id}: retry compliance overclaim not represented")
    elif candidate == "schell_forgetting_ledger_imported_as_erasure_proof":
        expect(flags["erasure_proof_inherited"] is True, f"{case_id}: erasure proof overclaim not represented")
    elif candidate == "viewfs_volition_card_imported_as_consent_outcome":
        expect(flags["consent_outcome_inherited"] is True, f"{case_id}: consent outcome overclaim not represented")
    elif candidate == "ward_delegation_warrant_imported_as_authority_transfer":
        expect(flags["authority_transfer_inherited"] is True, f"{case_id}: delegation authority overclaim not represented")
    elif candidate == "helm_repair_trace_imported_as_completed_repair":
        expect(flags["repair_inherited"] is True, f"{case_id}: repair trace completion overclaim not represented")


def check_bundle(bundle: dict[str, Any]) -> None:
    expect(bundle.get("schema") == harness.SCHEMA, "Schema drift")
    expect(bundle.get("version") == harness.VERSION, "Version drift")
    expect(bundle.get("source_revision") == harness.REVISION, "Source revision drift")
    expect(bundle.get("member_labels") == harness.MEMBER_LABELS, "Member label drift")
    expect(bundle.get("foreign_catalog") == harness.FOREIGN_CATALOG, "Foreign catalog drift")
    expected_digest = harness.digest({key: bundle[key] for key in ["schema", "version", "source_revision", "member_labels", "foreign_catalog", "cases", "global"]})
    expect(bundle.get("bundle_digest") == expected_digest, "Bundle digest drift")

    cases = bundle.get("cases", [])
    expect(len(cases) == len(harness.CASE_PLAN), "Case count drift")
    expect([case["index"] for case in cases] == list(range(1, len(cases) + 1)), "Case indexes not gapless")
    expect([case["id"] for case in cases] == [plan["id"] for plan in harness.CASE_PLAN], "Case id order drift")
    expect([case["candidate"] for case in cases] == [plan["candidate"] for plan in harness.CASE_PLAN], "Candidate order drift")

    for case, plan in zip(cases, harness.CASE_PLAN):
        expect(case["import.matrix"]["expected"] == plan["expected"], f"{case['id']}: expected outcome drift")
        check_case(case)

    accepted = sum(1 for case in cases if case["verdict.summary"]["expected"] == "accepted")
    rejected = len(cases) - accepted
    global_ = bundle.get("global", {})
    expect(global_.get("case_count") == len(cases), "Global case count drift")
    expect(global_.get("accepted_count") == accepted, "Global accepted count drift")
    expect(global_.get("rejected_count") == rejected, "Global rejected count drift")
    expect(global_.get("source_revision") == harness.REVISION, "Global source revision drift")
    expect(global_.get("prior_harbor_lineage_bundle_digest") == harness.f101_lineage_digest(), "Global prior lineage digest drift")
    expect("not a companion trust root" in global_.get("coverage_claim", ""), "Coverage claim must refuse companion trust root promotion")
    for refusal in harness.NON_PROMOTION:
        expect(refusal in global_.get("non_promotion", []), f"Global non-promotion list missing {refusal}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Check Harbor cross-cube lineage import bundle")
    parser.add_argument("--fixture", type=Path, default=ROOT / "fixtures" / "harbor-cross-cube-lineage-import-bundle-v0.json")
    args = parser.parse_args()

    expected = harness.build_bundle()
    check_bundle(expected)
    if args.fixture.exists():
        actual = json.loads(args.fixture.read_text(encoding="utf-8"))
        expect(actual == expected, "Checked fixture does not match deterministic harness output")
    else:
        fail(f"Fixture missing: {args.fixture}")
    print("Harbor cross-cube lineage import bundle check passed")


if __name__ == "__main__":
    main()
