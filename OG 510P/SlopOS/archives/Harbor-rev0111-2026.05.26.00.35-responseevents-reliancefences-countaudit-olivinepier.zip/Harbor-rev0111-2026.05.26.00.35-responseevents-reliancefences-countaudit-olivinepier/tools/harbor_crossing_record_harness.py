#!/usr/bin/env python3
"""Emit the tiny Harbor CrossingRecord v0 evidence bundle.

This is deliberately a deterministic specimen harness, not a production schema.
It gives `make check` something sharper than prose: accepted crossings must carry
route/scope/non-promise guards, and nearby malformed or overclaiming candidates
must reject without creating durable truth.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from copy import deepcopy
from typing import Any

SCHEMA = "harbor-crossing-record-evidence-bundle"
VERSION = "0"
REVISION = "rev0095"

MEMBER_LABELS = [
    "case.matrix",
    "input.external_evidence",
    "input.crossing_record",
    "scope.comparison",
    "output.admission",
    "output.aftermath",
    "verdict.summary",
]

RECORD_TOP_KEYS = [
    "crossing_id",
    "subject",
    "route",
    "admission",
    "scope",
    "outcome",
    "aftermath",
]

ROUTE_GUARDS = {
    "portal.net.request": {
        "not_transport_trust",
        "not_content_truth",
        "not_current_lease",
        "not_user_comprehension",
    },
    "portal.net.durability": {
        "not_transport_trust",
        "not_discarded_suffix_preserved",
        "not_denied_duplicate_durable",
        "not_outside_truth_continuity",
    },
    "callback": {
        "not_same_authority",
        "not_user_comprehension",
        "not_local_adoption",
    },
    "mcp_tool_metadata": {
        "not_tool_annotation_truth",
        "not_user_consent_proof",
        "not_content_truth",
    },
    "browser_credential": {
        "not_identity_truth",
        "not_holder_authority",
        "not_user_comprehension",
        "not_global_authorization",
    },
    "public_copy_aftermath": {
        "not_global_repair",
        "not_compliance",
        "not_all_copies_clean",
        "not_all_agents_corrected",
    },
}

FORBIDDEN_OUTCOME_CLASSES = {"resolved", "compliant", "trusted", "global_truth"}
ALLOWED_SCOPE_VERDICTS = {
    "same_scope",
    "narrower_than",
    "overlaps_but_not_same_scope",
    "incomparable",
    "supersedes_within_scope",
    "stale_after",
    "rejected_scope_substitution",
}


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def digest(value: Any) -> str:
    return "sha256:" + hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def evidence(case_id: str, *, route_family: str, subject_digest: str, scope: dict[str, Any], stable_claims: list[str], blocked_claims: list[str]) -> dict[str, Any]:
    return {
        "evidence_id": "ev-" + case_id,
        "source": "SlopOS portal.net.request harness" if route_family.startswith("portal.net") else "Harbor hostile crossing fixture",
        "route_family": route_family,
        "subject_digest": subject_digest,
        "scope": scope,
        "stable_claims": stable_claims,
        "blocked_claims": blocked_claims,
    }


def record(
    case_id: str,
    *,
    subject_kind: str,
    subject_ref: str,
    subject_digest: str,
    route_family: str,
    authority_basis: str,
    scope: dict[str, Any],
    outcome_class: str,
    receipts: list[str],
    non_promises: list[str],
    basis_time: str = "2026-05-21T07:32:00Z",
) -> dict[str, Any]:
    return {
        "crossing_id": "cr-090-" + case_id,
        "subject": {
            "kind": subject_kind,
            "ref": subject_ref,
            "digest": subject_digest,
            "basis_time": basis_time,
        },
        "route": {
            "from_membrane": "foreign-evidence-surface",
            "to_membrane": "harbor-core",
            "route_family": route_family,
        },
        "admission": {
            "decision": "accepted",
            "authority_basis": authority_basis,
            "visible_to_user": True,
        },
        "scope": scope,
        "outcome": {
            "class": outcome_class,
            "non_promises": non_promises,
        },
        "aftermath": {
            "receipts": receipts,
            "recheck_window": "2026-05-21T07:32:00Z/2026-05-28T07:32:00Z",
            "rollback_or_reopen_triggers": [
                "scope_substitution",
                "contradictory_digest",
                "stale_recurrence",
                "authority_overclaim",
            ],
        },
    }


def scope(artifact: str, audience: str, surface: str, *, jurisdiction: str = "local", window: str = "2026-05-21T00:00:00Z/2026-05-28T00:00:00Z") -> dict[str, Any]:
    return {
        "artifact": artifact,
        "audience": audience,
        "jurisdiction": jurisdiction,
        "surface": surface,
        "time_window": window,
    }


def accepted_case(
    case_id: str,
    *,
    route_family: str,
    subject_kind: str,
    subject_ref: str,
    subject_digest: str,
    scope_value: dict[str, Any],
    outcome_class: str,
    authority_basis: str,
    stable_claims: list[str],
    blocked_claims: list[str],
    scope_verdict: str,
    comparison_note: str,
) -> dict[str, Any]:
    guards = sorted(ROUTE_GUARDS[route_family])
    ev = evidence(case_id, route_family=route_family, subject_digest=subject_digest, scope=scope_value, stable_claims=stable_claims, blocked_claims=blocked_claims)
    rec = record(
        case_id,
        subject_kind=subject_kind,
        subject_ref=subject_ref,
        subject_digest=subject_digest,
        route_family=route_family,
        authority_basis=authority_basis,
        scope=scope_value,
        outcome_class=outcome_class,
        receipts=[ev["evidence_id"]],
        non_promises=guards,
    )
    return {
        "id": case_id,
        "expected": "accepted",
        "exercise": route_family,
        "external_evidence": ev,
        "crossing_record": rec,
        "scope_comparison": {
            "verdict": scope_verdict,
            "note": comparison_note,
            "refused_widening": True,
        },
        "admission": {
            "decision": "accepted",
            "reason": "scope-bound crossing residue admitted",
        },
        "aftermath": {
            "record_id": rec["crossing_id"],
            "non_promises": guards,
            "durable_effect": "bounded_crossing_residue_only",
        },
    }


def rejected_case(
    case_id: str,
    *,
    route_family: str,
    subject_kind: str,
    subject_ref: str,
    evidence_digest: str,
    record_digest: str,
    scope_value: dict[str, Any],
    reject_reason: str,
    mutation: str,
) -> dict[str, Any]:
    ev = evidence(
        case_id,
        route_family=route_family,
        subject_digest=evidence_digest,
        scope=scope_value,
        stable_claims=["candidate_received"],
        blocked_claims=["must_not_create_crossing_record"],
    )
    rec = record(
        case_id,
        subject_kind=subject_kind,
        subject_ref=subject_ref,
        subject_digest=record_digest,
        route_family=route_family,
        authority_basis="hostile-fixture",
        scope=scope_value,
        outcome_class="materialized",
        receipts=[ev["evidence_id"]],
        non_promises=sorted(ROUTE_GUARDS.get(route_family, {"not_content_truth"})),
    )
    if mutation == "ambient_field":
        rec["ambient_truth"] = "trusted because portal accepted it"
    elif mutation == "global_resolution":
        rec["outcome"] = {
            "class": "resolved",
            "non_promises": [],
        }
        rec["admission"]["authority_basis"] = "status-banner-only"
    elif mutation == "latest_wins_scope_substitution":
        rec["scope"] = scope("pub-may-b", "public-global", "generated explainer", jurisdiction="global")
        rec["admission"]["authority_basis"] = "latest-owner-ticket-only"
    return {
        "id": case_id,
        "expected": "rejected",
        "exercise": mutation,
        "external_evidence": ev,
        "crossing_record": {"candidate": rec},
        "scope_comparison": {
            "verdict": "rejected_scope_substitution" if mutation == "latest_wins_scope_substitution" else "incomparable",
            "note": reject_reason,
            "refused_widening": True,
        },
        "admission": {
            "decision": "rejected",
            "reason": reject_reason,
        },
        "aftermath": {
            "record_id": None,
            "non_promises": ["no_crossing_record_emitted", "no_durable_truth_created"],
            "durable_effect": "rejection_receipt_only",
        },
    }


def build_cases() -> list[dict[str, Any]]:
    portal_scope = scope("slopos.portal.net.request", "harbor-core", "network request evidence bundle")
    public_scope = scope("pub-may-b", "public-us", "canonical bundle + generated explainer", jurisdiction="us")
    return [
        accepted_case(
            "accept-portal-net-request-route-admission",
            route_family="portal.net.request",
            subject_kind="tool_result",
            subject_ref="portal-net-request-evidence-bundle:EVID-2026-736",
            subject_digest="sha256:slopos-netreq-route-admission-a",
            scope_value=portal_scope,
            outcome_class="materialized",
            authority_basis="SlopOS EVID-2026-736 route/admission only",
            stable_claims=["accepted_path_observed", "order_token_digest_bound", "ambient_absence_ok"],
            blocked_claims=["trusted_response_content", "current_network_lease", "user_understood_request"],
            scope_verdict="same_scope",
            comparison_note="Route/admission evidence matches the Harbor crossing subject but carries no response truth.",
        ),
        accepted_case(
            "accept-portal-net-resume-truncation-append",
            route_family="portal.net.durability",
            subject_kind="artifact",
            subject_ref="portal-net-request-linearization-chain-checkpoint-resume-truncation-append-corpus",
            subject_digest="sha256:slopos-accepted-only-history-b",
            scope_value=scope("slopos.portal.net.request", "harbor-core", "accepted-only replay history"),
            outcome_class="materialized",
            authority_basis="SlopOS checkpoint/resume/truncation/append corpus accepted-prefix proof",
            stable_claims=["accepted_only_history", "discarded_suffix_rejected", "append_indexes_continue"],
            blocked_claims=["denied_duplicate_durable", "discarded_suffix_revival", "outside_truth_continuity"],
            scope_verdict="supersedes_within_scope",
            comparison_note="Durability evidence can update the local replay cursor only within the same accepted-prefix scope.",
        ),
        rejected_case(
            "reject-malformed-envelope-ambient-field",
            route_family="portal.net.request",
            subject_kind="tool_result",
            subject_ref="portal-net-request-evidence-bundle:ambient-field",
            evidence_digest="sha256:slopos-netreq-malformed-c",
            record_digest="sha256:slopos-netreq-malformed-c",
            scope_value=portal_scope,
            reject_reason="candidate crossing contains ambient authority/truth field outside CrossingRecord v0",
            mutation="ambient_field",
        ),
        rejected_case(
            "reject-subject-digest-mismatch",
            route_family="portal.net.request",
            subject_kind="tool_result",
            subject_ref="portal-net-request-evidence-bundle:digest-mismatch",
            evidence_digest="sha256:slopos-netreq-expected-d",
            record_digest="sha256:slopos-netreq-other-d",
            scope_value=portal_scope,
            reject_reason="subject digest does not match external evidence digest",
            mutation="digest_mismatch",
        ),
        accepted_case(
            "accept-callback-continuation-boundary",
            route_family="callback",
            subject_kind="callback",
            subject_ref="browser-detour-return:cb-090-a",
            subject_digest="sha256:callback-return-e",
            scope_value=scope("callback-return", "same-user-session", "return path continuation"),
            outcome_class="opened",
            authority_basis="return-state hash and local continuation leash",
            stable_claims=["return_path_observed", "state_hash_matches", "local_continuation_allowed"],
            blocked_claims=["same_authority", "user_comprehension", "remote_verdict"],
            scope_verdict="narrower_than",
            comparison_note="Callback can resume a local continuation, not import remote authority.",
        ),
        accepted_case(
            "accept-mcp-tool-metadata-untrusted",
            route_family="mcp_tool_metadata",
            subject_kind="tool_result",
            subject_ref="mcp:resource-card:pricing-catalog",
            subject_digest="sha256:mcp-resource-card-f",
            scope_value=scope("mcp-resource-card", "operator-review", "tool/resource annotation"),
            outcome_class="materialized",
            authority_basis="trusted-server-list absent; local review only",
            stable_claims=["metadata_presented", "server_label_observed"],
            blocked_claims=["annotation_truth", "safe_tool_execution", "user_consent_proof"],
            scope_verdict="incomparable",
            comparison_note="Tool annotations can be displayed for review but cannot certify content or action safety.",
        ),
        accepted_case(
            "accept-browser-credential-presentation",
            route_family="browser_credential",
            subject_kind="credential",
            subject_ref="digital-credential-presentation:age-over-18",
            subject_digest="sha256:credential-presentation-g",
            scope_value=scope("credential-presentation", "relying-party-demo", "browser mediated presentation"),
            outcome_class="materialized",
            authority_basis="user-agent mediated credential presentation; relying-party scope only",
            stable_claims=["credential_response_presented", "holder_mediation_observed"],
            blocked_claims=["global_identity", "issuer_endorsement_for_all_uses", "durable_authorization"],
            scope_verdict="overlaps_but_not_same_scope",
            comparison_note="Presentation overlaps identity claims but is not a universal identity or authorization result.",
        ),
        accepted_case(
            "accept-public-copy-aftermath-warning",
            route_family="public_copy_aftermath",
            subject_kind="public_copy",
            subject_ref="pub-may-b/generated-explainer",
            subject_digest="sha256:pub-may-b-generated-explainer-h",
            scope_value=public_scope,
            outcome_class="stale_observed",
            authority_basis="F089 warning lifecycle receipt and failed recheck",
            stable_claims=["stale_surface_observed", "warning_stays_active", "recheck_window_bound"],
            blocked_claims=["global_repair", "compliance", "all_agent_memory_repaired"],
            scope_verdict="stale_after",
            comparison_note="A stale generated explainer after a clean window keeps the warning active for named surfaces only.",
        ),
        rejected_case(
            "reject-global-resolution-overclaim",
            route_family="public_copy_aftermath",
            subject_kind="public_copy",
            subject_ref="pub-may-b/status-banner",
            evidence_digest="sha256:pub-may-b-status-i",
            record_digest="sha256:pub-may-b-status-i",
            scope_value=public_scope,
            reject_reason="status banner claims resolved without scoped warning lifecycle receipts or non-promises",
            mutation="global_resolution",
        ),
        rejected_case(
            "reject-latest-wins-scope-substitution",
            route_family="public_copy_aftermath",
            subject_kind="public_copy",
            subject_ref="pub-may-b/source-owner-ticket-latest",
            evidence_digest="sha256:pub-may-b-public-us-j",
            record_digest="sha256:pub-may-b-public-us-j",
            scope_value=public_scope,
            reject_reason="latest ticket swaps public-us canonical scope for public-global generated-explainer scope",
            mutation="latest_wins_scope_substitution",
        ),
    ]


def build_bundle() -> dict[str, Any]:
    cases = build_cases()
    members: dict[str, dict[str, Any]] = {label: {} for label in MEMBER_LABELS}
    for index, case in enumerate(cases, start=1):
        cid = case["id"]
        members["case.matrix"][cid] = {
            "index": index,
            "expected": case["expected"],
            "exercise": case["exercise"],
        }
        members["input.external_evidence"][cid] = case["external_evidence"]
        members["input.crossing_record"][cid] = case["crossing_record"]
        members["scope.comparison"][cid] = case["scope_comparison"]
        members["output.admission"][cid] = case["admission"]
        members["output.aftermath"][cid] = case["aftermath"]
        members["verdict.summary"][cid] = {
            "admitted": case["expected"] == "accepted",
            "guards_checked": True,
            "subject_digest_checked": True,
            "scope_checked": True,
            "ambient_fields_rejected": cid == "reject-malformed-envelope-ambient-field" or case["expected"] == "accepted",
            "non_promotion_checked": True,
            "reject_reason": None if case["expected"] == "accepted" else case["admission"]["reason"],
            "record_digest": digest(case["crossing_record"]),
        }
    admitted = sum(1 for c in cases if c["expected"] == "accepted")
    bundle = {
        "schema": SCHEMA,
        "version": VERSION,
        "revision": REVISION,
        "emitted_by": "tools/harbor_crossing_record_harness.py",
        "purpose": "F090 executable crossing-record pressure test; not a durable schema",
        "members": members,
        "global": {
            "case_count": len(cases),
            "accepted_count": admitted,
            "rejected_count": len(cases) - admitted,
            "member_labels": MEMBER_LABELS,
            "route_families": sorted({c["external_evidence"]["route_family"] for c in cases}),
            "non_promotion": [
                "no durable CrossingRecord schema",
                "no SlopOS import contract",
                "no MCP trust profile",
                "no browser credential trust profile",
                "no compliance/status API",
            ],
        },
    }
    bundle["bundle_digest"] = digest({k: v for k, v in bundle.items() if k != "bundle_digest"})
    return bundle


def main() -> None:
    parser = argparse.ArgumentParser(description="Emit Harbor CrossingRecord v0 evidence bundle")
    parser.add_argument("--emit-bundle", action="store_true", help="print the deterministic evidence bundle JSON")
    args = parser.parse_args()
    if not args.emit_bundle:
        parser.error("expected --emit-bundle")
    print(json.dumps(build_bundle(), indent=2, sort_keys=True) + "\n")


if __name__ == "__main__":
    main()
