#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import harbor_retention_expiry_harness as harness  # noqa: E402


def fail(message: str) -> None:
    print(message)
    raise SystemExit(1)


def expect(condition: bool, message: str) -> None:
    if not condition:
        fail(message)


def check_bundle(bundle: dict) -> None:
    expect(bundle.get("schema") == harness.SCHEMA, "Unexpected bundle schema")
    expect(bundle.get("version") == harness.VERSION, "Unexpected bundle version")
    expect(bundle.get("revision") == harness.REVISION, "Unexpected bundle revision")
    expect(bundle.get("purpose", "").endswith("not a durable schema"), "Purpose must refuse durable schema promotion")
    expected_digest = harness.digest({k: v for k, v in bundle.items() if k != "bundle_digest"})
    expect(bundle.get("bundle_digest") == expected_digest, "Bundle digest drift")

    members = bundle.get("members")
    expect(isinstance(members, dict), "Bundle members must be an object")
    expect(list(members.keys()) == harness.MEMBER_LABELS, "Member labels/order drift")

    matrix = members["retention.matrix"]
    expect(len(matrix) == len(harness.CASE_PLAN), "F100 bundle case count drift")
    for label in harness.MEMBER_LABELS[1:]:
        expect(list(members[label].keys()) == list(matrix.keys()), f"Case id/order drift in {label}")

    accepted = 0
    rejected = 0
    seen_indexes: list[int] = []
    seen_candidates: set[str] = set()
    for case_id, row in matrix.items():
        seen_indexes.append(row.get("index"))
        candidate = row.get("candidate")
        expected = row.get("expected")
        seen_candidates.add(candidate)
        expect(expected in {"accepted", "rejected"}, f"{case_id}: invalid expected outcome")
        expect(row.get("digest") == harness.digest({"index": row.get("index"), "candidate": candidate, "expected": expected}), f"{case_id}: row digest drift")

        subject = members["evidence.subject"][case_id]
        policy = members["retention.policy"][case_id]
        clock = members["expiry.clock"][case_id]
        action = members["retention.action"][case_id]
        recheck = members["recheck.receipt"][case_id]
        hold = members["exception.hold"][case_id]
        verdict = members["verdict.summary"][case_id]

        expect(subject.get("derivative_repair_bundle_digest") == harness.derivative_repair_bundle_digest(), f"{case_id}: repair-bundle digest drift")
        expect(subject.get("source_material_digest") == harness.source_material_digest(), f"{case_id}: source material digest drift")
        expect(subject.get("subject_is_not_global_repair") is True, f"{case_id}: global-repair subject refusal missing")
        expect(subject.get("subject_is_not_retention_policy") is True, f"{case_id}: subject/policy split missing")
        if subject.get("subject_digest_present"):
            expect(isinstance(subject.get("derivative_digest"), str) and subject["derivative_digest"].startswith("sha256:"), f"{case_id}: derivative digest missing")

        expect(policy.get("recheck_required_after_expiry") is True, f"{case_id}: recheck-after-expiry bit missing")
        expect(policy.get("policy_is_not_freshness") is True, f"{case_id}: policy/freshness refusal missing")
        expect(policy.get("policy_is_not_compliance") is True, f"{case_id}: policy/compliance refusal missing")
        expect(clock.get("expiry_is_not_fault") is True, f"{case_id}: expiry fault-refusal missing")
        expect(action.get("pruning_is_not_repair") is not None, f"{case_id}: pruning/repair posture missing")
        expect(recheck.get("recheck_is_not_compliance") is True, f"{case_id}: recheck/compliance refusal missing")
        expect(hold.get("exception_preserves_evidence_not_status") is not None, f"{case_id}: hold/status posture missing")

        expect(verdict.get("expected_matched") is True, f"{case_id}: verdict did not match expected outcome")
        expect(verdict.get("candidate") == candidate, f"{case_id}: verdict candidate drift")
        for phrase in ["not global repair", "not all derivatives current", "not compliance", "not privacy erasure proof", "not cache freshness"]:
            expect(phrase in verdict.get("non_promises", []), f"{case_id}: missing non-promise {phrase}")

        if verdict.get("admitted"):
            accepted += 1
            expect(expected == "accepted", f"{case_id}: admitted rejected candidate")
            expect(not verdict.get("failure_reasons"), f"{case_id}: accepted case carries failure reasons")
            if candidate == "active_repair_receipt_within_window":
                expect(verdict.get("may_claim_current_repair") is True, f"{case_id}: active case cannot claim current repair")
                expect(clock.get("expired_at_evaluation") is False, f"{case_id}: active case marked expired")
                expect(recheck.get("result") == "passed_within_window", f"{case_id}: active recheck result drift")
            else:
                expect(verdict.get("may_claim_current_repair") is False, f"{case_id}: non-active accepted case claimed current repair")
            if candidate == "expired_repair_receipt_recheck_required":
                expect(clock.get("expired_at_evaluation") is True, f"{case_id}: expired case not expired")
                expect(verdict.get("must_recheck_before_current_status") is True, f"{case_id}: expired case lacks recheck guard")
                expect(recheck.get("result") == "required_not_yet_performed", f"{case_id}: expired recheck result drift")
            elif candidate == "compacted_tombstone_with_digest_pointers":
                expect(action.get("tombstone_retained") is True, f"{case_id}: tombstone missing")
                expect(action.get("compaction_is_full_evidence_claim") is False, f"{case_id}: compaction overclaim admitted")
            elif candidate == "legal_hold_preserves_evidence_not_freshness":
                expect(hold.get("hold_or_waiver_present") is True, f"{case_id}: hold missing")
                expect(hold.get("hold_claims_freshness") is False, f"{case_id}: hold freshness overclaim admitted")
            elif candidate == "source_corrected_again_prior_repair_stale":
                expect(recheck.get("new_source_correction_digest", "").startswith("sha256:"), f"{case_id}: later correction digest missing")
                expect(recheck.get("new_source_correction_considered") is True, f"{case_id}: later correction ignored")
                expect(verdict.get("must_recheck_before_current_status") is True, f"{case_id}: stale repair lacks recheck guard")
            elif candidate == "quarantine_evidence_retained_after_material_prune":
                expect(action.get("raw_evidence_retained") is False, f"{case_id}: quarantine material not pruned")
                expect(action.get("tombstone_retained") is True, f"{case_id}: quarantine tombstone missing")
                expect(verdict.get("must_preserve_warning_residue") is True, f"{case_id}: quarantine warning residue not preserved")
            elif candidate == "raw_evidence_pruned_digest_pointer_only":
                expect(action.get("raw_evidence_retained") is False, f"{case_id}: raw evidence retained unexpectedly")
                expect(verdict.get("verdict_class") == "digest_pointer_only_not_full_evidence", f"{case_id}: digest-pointer class drift")
            elif candidate == "recurrence_after_expiry_reopens_warning":
                expect(clock.get("expired_at_evaluation") is True, f"{case_id}: recurrence not expired")
                expect(recheck.get("result") == "stale_recurrence_observed", f"{case_id}: recurrence recheck result drift")
                expect(verdict.get("must_preserve_warning_residue") is True, f"{case_id}: recurrence warning residue missing")
            elif candidate == "privacy_minimized_tombstone_retained":
                expect(policy.get("basis") == "privacy_minimization", f"{case_id}: privacy-min basis drift")
                expect(action.get("privacy_minimization_claims_no_stale_copies") is False, f"{case_id}: privacy no-stale overclaim admitted")
            elif candidate == "reviewer_waiver_note_with_expiry":
                expect(hold.get("expires_after_revision") == "rev0106", f"{case_id}: waiver expiry drift")
                expect(hold.get("waiver_does_not_change_machine_result") is True, f"{case_id}: waiver changes result")
        else:
            rejected += 1
            expect(expected == "rejected", f"{case_id}: rejected accepted candidate")
            expect(verdict.get("verdict_class") == "refused_counterfeit_retention_confidence", f"{case_id}: rejected verdict class drift")
            expect(verdict.get("failure_reasons"), f"{case_id}: rejected case lacks failure reason")

        if candidate == "expired_receipt_claims_current_repair":
            expect("expired_receipt_currentness_overclaim" in verdict["failure_reasons"], f"{case_id}: expired-current reason absent")
            expect(clock.get("expired_at_evaluation") is True, f"{case_id}: expired-current not expired")
        elif candidate == "retention_policy_extends_repair_without_recheck":
            expect("retention_policy_extends_truth" in verdict["failure_reasons"], f"{case_id}: retention-truth reason absent")
            expect(policy.get("policy_extends_repair_status_without_recheck") is True, f"{case_id}: retention extension not represented")
        elif candidate == "legal_hold_as_freshness":
            expect("hold_as_freshness" in verdict["failure_reasons"], f"{case_id}: hold-freshness reason absent")
            expect(hold.get("hold_claims_freshness") is True, f"{case_id}: hold freshness not represented")
        elif candidate == "compaction_digest_as_full_evidence":
            expect("compaction_digest_as_full_evidence" in verdict["failure_reasons"], f"{case_id}: compaction reason absent")
            expect(action.get("compaction_is_full_evidence_claim") is True, f"{case_id}: compaction overclaim not represented")
        elif candidate == "deletion_as_repair_or_clean_slate":
            expect("deletion_as_repair" in verdict["failure_reasons"], f"{case_id}: deletion reason absent")
            expect(action.get("deletion_claims_repair_or_clean_slate") is True, f"{case_id}: deletion overclaim not represented")
        elif candidate == "second_source_correction_ignored":
            expect("new_source_correction_ignored" in verdict["failure_reasons"], f"{case_id}: ignored correction reason absent")
            expect(recheck.get("new_source_correction_considered") is False, f"{case_id}: ignored correction not represented")
        elif candidate == "scheduled_recheck_as_passed_recheck":
            expect("scheduled_recheck_as_passed" in verdict["failure_reasons"], f"{case_id}: scheduled reason absent")
            expect(recheck.get("performed") is False and recheck.get("scheduled") is True, f"{case_id}: scheduled/performed posture not represented")
        elif candidate == "pruned_raw_evidence_as_verified_success":
            expect("pruned_raw_evidence_as_success" in verdict["failure_reasons"], f"{case_id}: pruned success reason absent")
            expect(action.get("raw_evidence_retained") is False, f"{case_id}: raw evidence not pruned")
        elif candidate == "quarantine_expiry_as_repaired":
            expect("quarantine_expiry_as_repair" in verdict["failure_reasons"], f"{case_id}: quarantine expiry reason absent")
            expect(clock.get("expired_at_evaluation") is True, f"{case_id}: quarantine expiry not expired")
        elif candidate == "consumer_acknowledgement_valid_after_expiry":
            expect("expired_acknowledgement_currentness_overclaim" in verdict["failure_reasons"], f"{case_id}: expired ack reason absent")
            expect(clock.get("expired_at_evaluation") is True, f"{case_id}: expired ack not expired")
        elif candidate == "hold_release_drops_stale_warning":
            expect("hold_release_warning_loss" in verdict["failure_reasons"], f"{case_id}: hold release reason absent")
            expect(action.get("warning_residue_preserved") is False, f"{case_id}: warning loss not represented")
        elif candidate == "clockless_expiry_window":
            expect("missing_clock_basis" in verdict["failure_reasons"], f"{case_id}: missing clock reason absent")
            expect(clock.get("clock_basis_present") is False, f"{case_id}: missing clock not represented")
        elif candidate == "borrowed_retention_window_wrong_scope":
            expect("retention_scope_mismatch" in verdict["failure_reasons"], f"{case_id}: scope mismatch reason absent")
            expect(policy.get("policy_scope_matches_subject") is False, f"{case_id}: scope mismatch not represented")
        elif candidate == "tombstone_missing_subject_digest":
            expect("missing_subject_digest" in verdict["failure_reasons"], f"{case_id}: missing subject reason absent")
            expect(subject.get("subject_digest_present") is False, f"{case_id}: missing subject not represented")
        elif candidate == "privacy_minimization_as_no_stale_copies_proof":
            expect("privacy_minimization_no_stale_copies_overclaim" in verdict["failure_reasons"], f"{case_id}: privacy stale-copies reason absent")
            expect(action.get("privacy_minimization_claims_no_stale_copies") is True, f"{case_id}: privacy overclaim not represented")
        elif candidate == "migrated_evidence_digest_without_map":
            expect("evidence_migration_without_map" in verdict["failure_reasons"], f"{case_id}: migration reason absent")
            expect(action.get("migration_map_present") is False, f"{case_id}: migration map absence not represented")

    expect(seen_indexes == list(range(1, len(matrix) + 1)), "F100 indexes must be gapless")
    expect(seen_candidates == {plan["candidate"] for plan in harness.CASE_PLAN}, "Not all F100 candidate classes are represented")

    global_ = bundle.get("global", {})
    expect(global_.get("case_count") == len(matrix), "Global case_count drift")
    expect(global_.get("accepted_count") == accepted, "Global accepted_count drift")
    expect(global_.get("rejected_count") == rejected, "Global rejected_count drift")
    expect(global_.get("source_revision") == harness.REVISION, "Global source revision drift")
    expect(global_.get("derivative_repair_bundle_digest") == harness.derivative_repair_bundle_digest(), "Global derivative-repair bundle digest drift")
    expect("not records management" in global_.get("coverage_claim", ""), "Coverage claim must refuse records-management promotion")
    for refusal in harness.NON_PROMOTION:
        expect(refusal in global_.get("non_promotion", []), f"Global non-promotion list missing {refusal}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Check Harbor derivative repair retention/expiry bundle")
    parser.add_argument("--fixture", type=Path, default=ROOT / "fixtures" / "harbor-derivative-repair-retention-expiry-bundle-v0.json")
    args = parser.parse_args()

    expected = harness.build_bundle()
    check_bundle(expected)
    if args.fixture.exists():
        actual = json.loads(args.fixture.read_text(encoding="utf-8"))
        expect(actual == expected, "Checked fixture does not match deterministic harness output")
    else:
        fail(f"Fixture missing: {args.fixture}")
    print("Harbor derivative repair retention/expiry bundle check passed")


if __name__ == "__main__":
    main()
