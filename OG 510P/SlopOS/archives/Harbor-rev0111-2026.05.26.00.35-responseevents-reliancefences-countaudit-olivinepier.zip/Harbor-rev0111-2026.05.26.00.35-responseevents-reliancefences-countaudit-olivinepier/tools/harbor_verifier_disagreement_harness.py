#!/usr/bin/env python3
"""Emit deterministic Harbor verifier-disagreement / policy-epoch drift evidence."""
from __future__ import annotations

import argparse
import hashlib
import json
from copy import deepcopy
from typing import Any

SCHEMA = "harbor-verifier-disagreement-policy-epoch-bundle"
VERSION = "0"
REVISION = "rev0097"

MEMBER_LABELS = [
    "case.matrix",
    "input.receipt_set",
    "input.verifier_runs",
    "input.disagreement_record",
    "policy_epoch.analysis",
    "disagreement.analysis",
    "badge.analysis",
    "output.admission",
    "output.aftermath",
    "verdict.summary",
]

RECORD_TOP_KEYS = [
    "disagreement_id",
    "subject",
    "receipt_set",
    "verifiers",
    "policy_epochs",
    "comparison",
    "currentness",
    "public_status",
    "outcome",
    "aftermath",
]

ALLOWED_VERIFIER_DECISIONS = {
    "accepted",
    "refused",
    "inconclusive",
    "currentness_unknown",
    "recheck_required",
    "selected_claims_only",
    "not_applicable",
}

ALLOWED_EPOCH_RELATIONS = {
    "same_epoch",
    "mixed_epochs",
    "newer_policy_after_public_copy",
    "older_policy_superseded",
    "issuer_status_after_timestamp",
    "incomparable_policy_family",
    "epoch_unknown",
}

ALLOWED_BADGE_POSTURES = {
    "badge_withheld",
    "split_status",
    "scoped_pass_with_disclosure",
    "recheck_required",
    "prior_epoch_retained_with_notice",
    "incomparable_review",
    "no_public_badge",
}

FORBIDDEN_BADGE_POSTURES = {
    "green",
    "trusted",
    "resolved",
    "compliant",
    "globally_approved",
    "all_clear",
    "fresh_now",
}

FORBIDDEN_OUTCOME_CLASSES = {
    "global_pass",
    "global_failure",
    "retroactive_erasure",
    "auto_false_due_to_compromise",
    "majority_truth",
    "fresh_now",
    "compliant",
    "resolved",
}

BASE_NON_PROMISES = {
    "not_one_badge_truth",
    "not_majority_truth",
    "not_future_policy_pass",
    "not_retroactive_erasure",
    "not_global_currentness",
    "not_compliance",
    "not_issuer_status_collapse",
}


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def digest(value: Any) -> str:
    return "sha256:" + hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def scope(artifact: str, audience: str, surface: str, *, jurisdiction: str = "local", window: str = "2026-05-22T16:45:00Z/2026-05-29T16:45:00Z") -> dict[str, Any]:
    return {
        "artifact": artifact,
        "audience": audience,
        "jurisdiction": jurisdiction,
        "surface": surface,
        "time_window": window,
    }


def subject(kind: str, ref: str, digest_value: str, scope_value: dict[str, Any]) -> dict[str, Any]:
    return {
        "kind": kind,
        "ref": ref,
        "digest": digest_value,
        "scope": scope_value,
    }


def receipt(receipt_id: str, family: str, subject_digest: str, issuer: str, *, observed_at: str = "2026-05-22T16:45:00Z") -> dict[str, Any]:
    body = {
        "receipt_id": "rx-092-" + receipt_id,
        "family": family,
        "subject_digest": subject_digest,
        "issuer": issuer,
        "observed_at": observed_at,
        "claims": ["subject_digest_named", "policy_or_checkpoint_basis_named"],
    }
    body["receipt_digest"] = digest({k: v for k, v in body.items() if k != "receipt_digest"})
    return body


def verifier_run(
    case_id: str,
    name: str,
    *,
    decision: str,
    policy_id: str,
    policy_digest: str,
    policy_epoch: str,
    input_digest: str,
    currentness: str,
    scope_value: dict[str, Any],
    reason: str,
) -> dict[str, Any]:
    run = {
        "verifier_run_id": f"vr-092-{case_id}-{name}",
        "verifier": name,
        "decision": decision,
        "policy_id": policy_id,
        "policy_digest": policy_digest,
        "policy_epoch": policy_epoch,
        "input_digest": input_digest,
        "currentness": currentness,
        "scope": scope_value,
        "reason": reason,
        "decision_is_semantic_truth": False,
    }
    run["run_digest"] = digest({k: v for k, v in run.items() if k != "run_digest"})
    return run


def disagreement_record(
    case_id: str,
    *,
    subject_value: dict[str, Any],
    receipt_set: list[dict[str, Any]],
    verifier_runs: list[dict[str, Any]],
    epoch_relation: str,
    disagreement_class: str,
    currentness_verdict: str,
    badge_posture: str,
    outcome_class: str,
    explanation: str,
) -> dict[str, Any]:
    return {
        "disagreement_id": "vd-092-" + case_id,
        "subject": subject_value,
        "receipt_set": [r["receipt_digest"] for r in receipt_set],
        "verifiers": [v["run_digest"] for v in verifier_runs],
        "policy_epochs": {
            "relation": epoch_relation,
            "epochs": sorted({v["policy_epoch"] for v in verifier_runs}),
            "policy_digests": sorted({v["policy_digest"] for v in verifier_runs if v.get("policy_digest")}),
            "public_copy_time": "2026-05-22T15:30:00Z",
            "refused_retroactive_rewrite": True,
        },
        "comparison": {
            "class": disagreement_class,
            "decisions": sorted({v["decision"] for v in verifier_runs}),
            "preserved_verifier_count": len(verifier_runs),
            "result": "preserved_disagreement",
            "majority_or_latest_wins": False,
        },
        "currentness": {
            "verdict": currentness_verdict,
            "claim": "bounded_by_named_verifier_inputs",
            "unknown_is_fresh": False,
        },
        "public_status": {
            "badge": badge_posture,
            "explanation": explanation,
            "one_badge_truth": False,
            "visible_disagreement": True,
        },
        "outcome": {
            "class": outcome_class,
            "non_promises": sorted(BASE_NON_PROMISES),
        },
        "aftermath": {
            "receipts": [r["receipt_id"] for r in receipt_set],
            "verifier_runs": [v["verifier_run_id"] for v in verifier_runs],
            "recheck_window": "2026-05-22T16:45:00Z/2026-05-29T16:45:00Z",
            "rollback_or_reopen_triggers": [
                "policy_epoch_change",
                "currentness_check_failure",
                "issuer_status_change",
                "scope_substitution",
                "verifier_input_digest_change",
                "badge_collapse_attempt",
            ],
        },
    }


def base_materials(case_id: str, artifact: str, audience: str, surface: str, digest_value: str, receipt_families: list[str]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    sc = scope(artifact, audience, surface)
    subj = subject("public_copy_or_receipt_bundle", f"urn:harbor:subject:{case_id}", digest_value, sc)
    receipts = [receipt(f"{case_id}-{i}", fam, digest_value, f"issuer:{fam}") for i, fam in enumerate(receipt_families, start=1)]
    return subj, receipts


def accepted_case(
    case_id: str,
    *,
    exercise: str,
    artifact: str,
    audience: str,
    surface: str,
    digest_value: str,
    receipt_families: list[str],
    verifier_specs: list[dict[str, str]],
    epoch_relation: str,
    disagreement_class: str,
    currentness_verdict: str,
    badge_posture: str,
    outcome_class: str,
    explanation: str,
) -> dict[str, Any]:
    subj, receipts = base_materials(case_id, artifact, audience, surface, digest_value, receipt_families)
    runs = []
    for spec in verifier_specs:
        runs.append(verifier_run(
            case_id,
            spec["name"],
            decision=spec["decision"],
            policy_id=spec["policy_id"],
            policy_digest=spec["policy_digest"],
            policy_epoch=spec["policy_epoch"],
            input_digest=digest({"case": case_id, "receipt_digests": [r["receipt_digest"] for r in receipts], "verifier": spec["name"]}),
            currentness=spec["currentness"],
            scope_value=subj["scope"],
            reason=spec["reason"],
        ))
    record = disagreement_record(
        case_id,
        subject_value=subj,
        receipt_set=receipts,
        verifier_runs=runs,
        epoch_relation=epoch_relation,
        disagreement_class=disagreement_class,
        currentness_verdict=currentness_verdict,
        badge_posture=badge_posture,
        outcome_class=outcome_class,
        explanation=explanation,
    )
    return {
        "id": case_id,
        "expected": "accepted",
        "exercise": exercise,
        "subject": subj,
        "receipt_set": receipts,
        "verifier_runs": runs,
        "record": record,
        "policy_epoch_analysis": {
            "relation": epoch_relation,
            "refused_retroactive_rewrite": True,
            "requires_recheck": epoch_relation != "same_epoch",
        },
        "disagreement_analysis": {
            "class": disagreement_class,
            "preserved_verifier_runs": len(runs),
            "collapse_refused": True,
            "majority_or_latest_wins_refused": True,
        },
        "badge_analysis": {
            "posture": badge_posture,
            "public_badge_allowed": badge_posture in {"split_status", "scoped_pass_with_disclosure", "prior_epoch_retained_with_notice"},
            "one_badge_truth_refused": True,
        },
        "admission": {
            "decision": "accepted",
            "reason": "verifier disagreement retained as bounded evidence only",
        },
        "aftermath": {
            "record_id": record["disagreement_id"],
            "durable_effect": "bounded_disagreement_residue_only",
            "non_promises": sorted(BASE_NON_PROMISES),
        },
    }


def rejected_case(
    case_id: str,
    *,
    exercise: str,
    artifact: str,
    audience: str,
    surface: str,
    digest_value: str,
    receipt_families: list[str],
    verifier_specs: list[dict[str, str]],
    epoch_relation: str,
    disagreement_class: str,
    currentness_verdict: str,
    badge_posture: str,
    outcome_class: str,
    explanation: str,
    reject_reason: str,
    mutation: str,
) -> dict[str, Any]:
    accepted = accepted_case(
        case_id,
        exercise=exercise,
        artifact=artifact,
        audience=audience,
        surface=surface,
        digest_value=digest_value,
        receipt_families=receipt_families,
        verifier_specs=verifier_specs,
        epoch_relation=epoch_relation,
        disagreement_class=disagreement_class,
        currentness_verdict=currentness_verdict,
        badge_posture=badge_posture,
        outcome_class=outcome_class,
        explanation=explanation,
    )
    record = deepcopy(accepted["record"])
    runs = deepcopy(accepted["verifier_runs"])
    policy_epoch_analysis = deepcopy(accepted["policy_epoch_analysis"])
    disagreement_analysis = deepcopy(accepted["disagreement_analysis"])
    badge_analysis = deepcopy(accepted["badge_analysis"])

    if mutation == "single_green_badge":
        record["public_status"]["badge"] = "green"
        record["public_status"]["one_badge_truth"] = True
        record["public_status"]["visible_disagreement"] = False
        badge_analysis["posture"] = "green"
        badge_analysis["one_badge_truth_refused"] = False
    elif mutation == "retroactive_erasure":
        record["outcome"]["class"] = "retroactive_erasure"
        record["policy_epochs"]["refused_retroactive_rewrite"] = False
        policy_epoch_analysis["refused_retroactive_rewrite"] = False
    elif mutation == "stale_policy_current":
        record["currentness"]["claim"] = "fresh_now"
        record["currentness"]["unknown_is_fresh"] = True
        record["policy_epochs"]["relation"] = "older_policy_superseded"
    elif mutation == "refusal_global_failure":
        record["outcome"]["class"] = "global_failure"
        record["comparison"]["result"] = "collapsed_to_refusal"
        disagreement_analysis["collapse_refused"] = False
    elif mutation == "unknown_currentness_fresh":
        record["currentness"]["verdict"] = "currentness_unknown"
        record["currentness"]["claim"] = "fresh_now"
        record["currentness"]["unknown_is_fresh"] = True
        record["public_status"]["badge"] = "fresh_now"
    elif mutation == "issuer_compromise_auto_false":
        record["outcome"] = {"class": "auto_false_due_to_compromise", "non_promises": []}
        record["public_status"]["badge"] = "all_clear"  # deliberately contradictory hostile fixture
    elif mutation == "majority_vote_without_authority":
        record["comparison"]["result"] = "majority_wins"
        record["comparison"]["majority_or_latest_wins"] = True
        record["outcome"]["class"] = "majority_truth"
        disagreement_analysis["majority_or_latest_wins_refused"] = False
    elif mutation == "policy_digest_omitted":
        if runs:
            runs[0].pop("policy_digest", None)
            runs[0].pop("run_digest", None)
        record["policy_epochs"]["policy_digests"] = []
    else:
        raise ValueError(f"unknown mutation {mutation}")

    return {
        "id": case_id,
        "expected": "rejected",
        "exercise": exercise,
        "subject": accepted["subject"],
        "receipt_set": accepted["receipt_set"],
        "verifier_runs": runs,
        "record": {"candidate": record, "mutation": mutation},
        "policy_epoch_analysis": policy_epoch_analysis,
        "disagreement_analysis": disagreement_analysis,
        "badge_analysis": badge_analysis,
        "admission": {
            "decision": "rejected",
            "reason": reject_reason,
        },
        "aftermath": {
            "record_id": None,
            "durable_effect": "none",
            "non_promises": ["no_disagreement_record_emitted", "candidate_retained_as_rejection_residue_only"],
        },
    }


def build_cases() -> list[dict[str, Any]]:
    common_policy = "harbor-reliance-policy/v0"
    return [
        accepted_case(
            "accept-split-accept-refuse-preserved",
            exercise="accept_refuse_split",
            artifact="receipt-bundle-alpha",
            audience="public-us",
            surface="public-status-panel",
            digest_value="sha256:vd-alpha",
            receipt_families=["scitt_inclusion", "c2pa_manifest"],
            verifier_specs=[
                {"name": "verifier-a", "decision": "accepted", "policy_id": common_policy, "policy_digest": "sha256:policy-a1", "policy_epoch": "2026-05-22T14:00:00Z", "currentness": "checkpoint_named", "reason": "subject and manifest binding passed"},
                {"name": "verifier-b", "decision": "refused", "policy_id": common_policy, "policy_digest": "sha256:policy-a1", "policy_epoch": "2026-05-22T14:00:00Z", "currentness": "checkpoint_named", "reason": "issuer authority not accepted for target audience"},
            ],
            epoch_relation="same_epoch",
            disagreement_class="accept_refuse_split",
            currentness_verdict="current_for_named_checkpoint_only",
            badge_posture="split_status",
            outcome_class="disagreement_observed",
            explanation="Show split verifier result; do not collapse into a single green or red badge.",
        ),
        accepted_case(
            "accept-currentness-unknown-withheld",
            exercise="currentness_unknown",
            artifact="receipt-bundle-beta",
            audience="public-web",
            surface="dashboard-badge",
            digest_value="sha256:vd-beta",
            receipt_families=["rekor_ct_inclusion", "timestamp_anchor"],
            verifier_specs=[
                {"name": "verifier-log", "decision": "accepted", "policy_id": common_policy, "policy_digest": "sha256:policy-b1", "policy_epoch": "2026-05-22T15:00:00Z", "currentness": "tree_head_named", "reason": "inclusion proof valid for one checkpoint"},
                {"name": "verifier-currentness", "decision": "currentness_unknown", "policy_id": common_policy, "policy_digest": "sha256:policy-b1", "policy_epoch": "2026-05-22T15:00:00Z", "currentness": "revocation_not_checked", "reason": "issuer and log currentness not established"},
            ],
            epoch_relation="same_epoch",
            disagreement_class="accepted_plus_currentness_unknown",
            currentness_verdict="currentness_unknown",
            badge_posture="badge_withheld",
            outcome_class="recheck_required",
            explanation="Withhold public badge until currentness is checked; inclusion remains useful evidence.",
        ),
        accepted_case(
            "accept-policy-updated-after-public-copy",
            exercise="policy_epoch_drift",
            artifact="public-copy-gamma",
            audience="public-us",
            surface="correction-status-page",
            digest_value="sha256:vd-gamma",
            receipt_families=["verifier_policy_decision", "intoto_slsa_provenance"],
            verifier_specs=[
                {"name": "verifier-old-policy", "decision": "accepted", "policy_id": common_policy, "policy_digest": "sha256:policy-c-old", "policy_epoch": "2026-05-22T13:00:00Z", "currentness": "policy_epoch_bound", "reason": "public copy was published under prior policy"},
                {"name": "verifier-new-policy", "decision": "refused", "policy_id": common_policy, "policy_digest": "sha256:policy-c-new", "policy_epoch": "2026-05-22T16:00:00Z", "currentness": "policy_epoch_bound", "reason": "new policy requires issuer recheck"},
            ],
            epoch_relation="newer_policy_after_public_copy",
            disagreement_class="policy_drift_after_public_copy",
            currentness_verdict="policy_epoch_bound",
            badge_posture="prior_epoch_retained_with_notice",
            outcome_class="policy_drift_observed",
            explanation="Keep the prior public-copy basis visible and require recheck under the new policy; do not erase history.",
        ),
        accepted_case(
            "accept-issuer-status-after-timestamp-recheck",
            exercise="issuer_status_after_timestamp",
            artifact="receipt-bundle-delta",
            audience="auditor",
            surface="issuer-status-feed",
            digest_value="sha256:vd-delta",
            receipt_families=["timestamp_anchor", "issuer_compromise_advisory"],
            verifier_specs=[
                {"name": "verifier-timestamp", "decision": "accepted", "policy_id": common_policy, "policy_digest": "sha256:policy-d1", "policy_epoch": "2026-05-22T12:00:00Z", "currentness": "timestamp_only", "reason": "message imprint existed before the compromise notice"},
                {"name": "verifier-issuer-status", "decision": "recheck_required", "policy_id": common_policy, "policy_digest": "sha256:policy-d2", "policy_epoch": "2026-05-22T16:30:00Z", "currentness": "issuer_status_changed", "reason": "affected key set may overlap historical receipt"},
            ],
            epoch_relation="issuer_status_after_timestamp",
            disagreement_class="timestamp_then_issuer_status_change",
            currentness_verdict="revocation_or_compromise_recheck_required",
            badge_posture="recheck_required",
            outcome_class="recheck_required",
            explanation="Timestamp evidence remains timestamp evidence; issuer compromise creates a recheck, not automatic truth or falsity.",
        ),
        accepted_case(
            "accept-redacted-incomparable-review",
            exercise="incomparable_verifier_bases",
            artifact="sealed-evidence-epsilon",
            audience="auditor-redacted",
            surface="derived-proof-bundle",
            digest_value="sha256:vd-epsilon",
            receipt_families=["redacted_derived_proof", "verifier_policy_decision"],
            verifier_specs=[
                {"name": "verifier-sealed", "decision": "selected_claims_only", "policy_id": "sealed-review-policy/v0", "policy_digest": "sha256:policy-e-sealed", "policy_epoch": "2026-05-22T14:30:00Z", "currentness": "selected_claims_bound", "reason": "sealed basis supports only selected public claim"},
                {"name": "verifier-public", "decision": "inconclusive", "policy_id": "public-review-policy/v0", "policy_digest": "sha256:policy-e-public", "policy_epoch": "2026-05-22T14:30:00Z", "currentness": "basis_withheld", "reason": "public verifier cannot inspect sealed base evidence"},
            ],
            epoch_relation="incomparable_policy_family",
            disagreement_class="incomparable_bases",
            currentness_verdict="selected_claims_only",
            badge_posture="incomparable_review",
            outcome_class="incomparable_review_observed",
            explanation="Show selected-claim/sealed-basis boundary; do not force public and sealed verifiers into one verdict.",
        ),
        accepted_case(
            "accept-scope-narrow-pass-global-refusal",
            exercise="scope_split",
            artifact="public-copy-zeta",
            audience="public-us",
            surface="localized-status-panel",
            digest_value="sha256:vd-zeta",
            receipt_families=["c2pa_manifest", "verifier_policy_decision"],
            verifier_specs=[
                {"name": "verifier-local-scope", "decision": "accepted", "policy_id": "local-public-policy/v0", "policy_digest": "sha256:policy-f-local", "policy_epoch": "2026-05-22T15:10:00Z", "currentness": "scope_bound", "reason": "localized public copy meets local badge preconditions"},
                {"name": "verifier-global-scope", "decision": "refused", "policy_id": "global-public-policy/v0", "policy_digest": "sha256:policy-f-global", "policy_epoch": "2026-05-22T15:10:00Z", "currentness": "scope_bound", "reason": "global mirrors and generated explanations are unobserved"},
            ],
            epoch_relation="incomparable_policy_family",
            disagreement_class="scope_split",
            currentness_verdict="scope_bound_currentness",
            badge_posture="scoped_pass_with_disclosure",
            outcome_class="scoped_pass_observed",
            explanation="Allow a visibly scoped local pass while refusing global copy or all-mirror claims.",
        ),
        rejected_case(
            "reject-single-green-badge-from-split",
            exercise="badge_collapse",
            artifact="receipt-bundle-eta",
            audience="public-us",
            surface="public-status-panel",
            digest_value="sha256:vd-eta",
            receipt_families=["scitt_inclusion", "c2pa_manifest"],
            verifier_specs=[
                {"name": "verifier-a", "decision": "accepted", "policy_id": common_policy, "policy_digest": "sha256:policy-g1", "policy_epoch": "2026-05-22T14:00:00Z", "currentness": "checkpoint_named", "reason": "one verifier passed"},
                {"name": "verifier-b", "decision": "refused", "policy_id": common_policy, "policy_digest": "sha256:policy-g1", "policy_epoch": "2026-05-22T14:00:00Z", "currentness": "checkpoint_named", "reason": "one verifier refused"},
            ],
            epoch_relation="same_epoch",
            disagreement_class="accept_refuse_split",
            currentness_verdict="current_for_named_checkpoint_only",
            badge_posture="split_status",
            outcome_class="disagreement_observed",
            explanation="hostile candidate collapses split into green badge",
            reject_reason="multi-verifier split was collapsed into a single green badge",
            mutation="single_green_badge",
        ),
        rejected_case(
            "reject-latest-policy-retroactive-erasure",
            exercise="policy_epoch_retroactive_overwrite",
            artifact="public-copy-theta",
            audience="public-us",
            surface="correction-status-page",
            digest_value="sha256:vd-theta",
            receipt_families=["verifier_policy_decision", "intoto_slsa_provenance"],
            verifier_specs=[
                {"name": "verifier-old-policy", "decision": "accepted", "policy_id": common_policy, "policy_digest": "sha256:policy-h-old", "policy_epoch": "2026-05-22T13:00:00Z", "currentness": "policy_epoch_bound", "reason": "prior copy basis"},
                {"name": "verifier-new-policy", "decision": "refused", "policy_id": common_policy, "policy_digest": "sha256:policy-h-new", "policy_epoch": "2026-05-22T16:00:00Z", "currentness": "policy_epoch_bound", "reason": "new policy rejects"},
            ],
            epoch_relation="newer_policy_after_public_copy",
            disagreement_class="policy_drift_after_public_copy",
            currentness_verdict="policy_epoch_bound",
            badge_posture="prior_epoch_retained_with_notice",
            outcome_class="policy_drift_observed",
            explanation="hostile candidate deletes prior public basis",
            reject_reason="newer policy attempted to erase historical public-copy basis",
            mutation="retroactive_erasure",
        ),
        rejected_case(
            "reject-stale-policy-claimed-current",
            exercise="stale_policy_currentness_overclaim",
            artifact="receipt-bundle-iota",
            audience="public-web",
            surface="dashboard-badge",
            digest_value="sha256:vd-iota",
            receipt_families=["verifier_policy_decision"],
            verifier_specs=[
                {"name": "verifier-old-policy", "decision": "accepted", "policy_id": common_policy, "policy_digest": "sha256:policy-i-old", "policy_epoch": "2026-05-22T11:00:00Z", "currentness": "policy_epoch_bound", "reason": "old policy pass"},
                {"name": "verifier-current-policy", "decision": "inconclusive", "policy_id": common_policy, "policy_digest": "sha256:policy-i-new", "policy_epoch": "2026-05-22T16:00:00Z", "currentness": "not_checked", "reason": "current policy not fully run"},
            ],
            epoch_relation="older_policy_superseded",
            disagreement_class="stale_policy_vs_current_unknown",
            currentness_verdict="currentness_unknown",
            badge_posture="badge_withheld",
            outcome_class="recheck_required",
            explanation="hostile candidate treats stale policy as current",
            reject_reason="superseded policy was claimed fresh-now",
            mutation="stale_policy_current",
        ),
        rejected_case(
            "reject-refusal-becomes-global-failure",
            exercise="refusal_overgeneralization",
            artifact="receipt-bundle-kappa",
            audience="public-us",
            surface="public-status-panel",
            digest_value="sha256:vd-kappa",
            receipt_families=["c2pa_manifest"],
            verifier_specs=[
                {"name": "verifier-a", "decision": "refused", "policy_id": common_policy, "policy_digest": "sha256:policy-j1", "policy_epoch": "2026-05-22T15:00:00Z", "currentness": "scope_bound", "reason": "missing transform-survival evidence"},
                {"name": "verifier-b", "decision": "inconclusive", "policy_id": common_policy, "policy_digest": "sha256:policy-j1", "policy_epoch": "2026-05-22T15:00:00Z", "currentness": "scope_bound", "reason": "cannot inspect derived copy"},
            ],
            epoch_relation="same_epoch",
            disagreement_class="refusal_plus_inconclusive",
            currentness_verdict="currentness_unknown",
            badge_posture="badge_withheld",
            outcome_class="recheck_required",
            explanation="hostile candidate turns refusal into global failure",
            reject_reason="one verifier refusal cannot become global failure",
            mutation="refusal_global_failure",
        ),
        rejected_case(
            "reject-unknown-currentness-treated-fresh",
            exercise="currentness_unknown_overclaim",
            artifact="receipt-bundle-lambda",
            audience="public-web",
            surface="dashboard-badge",
            digest_value="sha256:vd-lambda",
            receipt_families=["rekor_ct_inclusion"],
            verifier_specs=[
                {"name": "verifier-log", "decision": "accepted", "policy_id": common_policy, "policy_digest": "sha256:policy-k1", "policy_epoch": "2026-05-22T15:00:00Z", "currentness": "tree_head_named", "reason": "log proof checked"},
                {"name": "verifier-currentness", "decision": "currentness_unknown", "policy_id": common_policy, "policy_digest": "sha256:policy-k1", "policy_epoch": "2026-05-22T15:00:00Z", "currentness": "revocation_not_checked", "reason": "current issuer status unknown"},
            ],
            epoch_relation="same_epoch",
            disagreement_class="accepted_plus_currentness_unknown",
            currentness_verdict="currentness_unknown",
            badge_posture="badge_withheld",
            outcome_class="recheck_required",
            explanation="hostile candidate calls unknown currentness fresh",
            reject_reason="unknown currentness was upgraded to fresh-now",
            mutation="unknown_currentness_fresh",
        ),
        rejected_case(
            "reject-issuer-compromise-auto-false",
            exercise="issuer_status_collapse",
            artifact="receipt-bundle-mu",
            audience="auditor",
            surface="issuer-status-feed",
            digest_value="sha256:vd-mu",
            receipt_families=["timestamp_anchor", "issuer_compromise_advisory"],
            verifier_specs=[
                {"name": "verifier-timestamp", "decision": "accepted", "policy_id": common_policy, "policy_digest": "sha256:policy-l1", "policy_epoch": "2026-05-22T12:00:00Z", "currentness": "timestamp_only", "reason": "message imprint timestamped"},
                {"name": "verifier-issuer-status", "decision": "recheck_required", "policy_id": common_policy, "policy_digest": "sha256:policy-l2", "policy_epoch": "2026-05-22T16:30:00Z", "currentness": "issuer_status_changed", "reason": "compromise window may overlap"},
            ],
            epoch_relation="issuer_status_after_timestamp",
            disagreement_class="timestamp_then_issuer_status_change",
            currentness_verdict="revocation_or_compromise_recheck_required",
            badge_posture="recheck_required",
            outcome_class="recheck_required",
            explanation="hostile candidate treats compromise as automatic falsehood",
            reject_reason="issuer compromise was collapsed into automatic falsehood",
            mutation="issuer_compromise_auto_false",
        ),
        rejected_case(
            "reject-majority-vote-without-authority",
            exercise="majority_vote_collapse",
            artifact="receipt-bundle-nu",
            audience="public-us",
            surface="public-status-panel",
            digest_value="sha256:vd-nu",
            receipt_families=["scitt_inclusion", "c2pa_manifest", "verifier_policy_decision"],
            verifier_specs=[
                {"name": "verifier-a", "decision": "accepted", "policy_id": common_policy, "policy_digest": "sha256:policy-m1", "policy_epoch": "2026-05-22T15:00:00Z", "currentness": "checkpoint_named", "reason": "passed one policy"},
                {"name": "verifier-b", "decision": "accepted", "policy_id": common_policy, "policy_digest": "sha256:policy-m1", "policy_epoch": "2026-05-22T15:00:00Z", "currentness": "checkpoint_named", "reason": "passed second policy"},
                {"name": "verifier-c", "decision": "refused", "policy_id": "jurisdiction-policy/v0", "policy_digest": "sha256:policy-m2", "policy_epoch": "2026-05-22T15:00:00Z", "currentness": "scope_bound", "reason": "jurisdiction-specific refusal"},
            ],
            epoch_relation="incomparable_policy_family",
            disagreement_class="majority_without_authority",
            currentness_verdict="scope_bound_currentness",
            badge_posture="split_status",
            outcome_class="disagreement_observed",
            explanation="hostile candidate lets majority vote override authority/scope split",
            reject_reason="majority vote was used as truth without authority basis",
            mutation="majority_vote_without_authority",
        ),
        rejected_case(
            "reject-policy-digest-omitted",
            exercise="policy_digest_missing",
            artifact="receipt-bundle-xi",
            audience="public-us",
            surface="public-status-panel",
            digest_value="sha256:vd-xi",
            receipt_families=["verifier_policy_decision"],
            verifier_specs=[
                {"name": "verifier-a", "decision": "accepted", "policy_id": common_policy, "policy_digest": "sha256:policy-n1", "policy_epoch": "2026-05-22T15:00:00Z", "currentness": "policy_epoch_bound", "reason": "policy pass"},
                {"name": "verifier-b", "decision": "refused", "policy_id": common_policy, "policy_digest": "sha256:policy-n1", "policy_epoch": "2026-05-22T15:00:00Z", "currentness": "policy_epoch_bound", "reason": "policy refusal"},
            ],
            epoch_relation="same_epoch",
            disagreement_class="accept_refuse_split",
            currentness_verdict="policy_epoch_bound",
            badge_posture="split_status",
            outcome_class="disagreement_observed",
            explanation="hostile candidate omits policy digest from a verifier run",
            reject_reason="verifier run omitted policy digest and cannot support epoch comparison",
            mutation="policy_digest_omitted",
        ),
    ]


def build_bundle() -> dict[str, Any]:
    cases = build_cases()
    members = {label: {} for label in MEMBER_LABELS}
    for case in cases:
        cid = case["id"]
        members["case.matrix"][cid] = {"expected": case["expected"], "exercise": case["exercise"]}
        members["input.receipt_set"][cid] = case["receipt_set"]
        members["input.verifier_runs"][cid] = case["verifier_runs"]
        members["input.disagreement_record"][cid] = case["record"]
        members["policy_epoch.analysis"][cid] = case["policy_epoch_analysis"]
        members["disagreement.analysis"][cid] = case["disagreement_analysis"]
        members["badge.analysis"][cid] = case["badge_analysis"]
        members["output.admission"][cid] = case["admission"]
        members["output.aftermath"][cid] = case["aftermath"]
        candidate = case["record"].get("candidate", case["record"])
        members["verdict.summary"][cid] = {
            "admitted": case["expected"] == "accepted",
            "record_digest": digest(candidate),
            "non_promotion_checked": True,
            "reject_reason": None if case["expected"] == "accepted" else case["admission"]["reason"],
        }
    bundle = {
        "schema": SCHEMA,
        "version": VERSION,
        "revision": REVISION,
        "purpose": "deterministic multi-verifier disagreement and policy-epoch drift pressure; not a durable schema",
        "members": members,
        "global": {
            "case_count": len(cases),
            "accepted_count": sum(1 for c in cases if c["expected"] == "accepted"),
            "rejected_count": sum(1 for c in cases if c["expected"] == "rejected"),
            "non_promotion": [
                "no verifier arbitration schema",
                "no policy-drift ledger",
                "no public badge semantics",
                "no reliance API",
                "no compliance workflow",
                "no final SlopOS datacube shape",
            ],
        },
    }
    bundle["bundle_digest"] = digest(bundle)
    return bundle


def main() -> None:
    parser = argparse.ArgumentParser(description="Emit deterministic Harbor verifier-disagreement bundle")
    parser.add_argument("--emit-bundle", action="store_true", help="print the deterministic bundle JSON")
    args = parser.parse_args()
    bundle = build_bundle()
    if args.emit_bundle:
        print(json.dumps(bundle, indent=2, ensure_ascii=False))
    else:
        print(bundle["bundle_digest"])


if __name__ == "__main__":
    main()
