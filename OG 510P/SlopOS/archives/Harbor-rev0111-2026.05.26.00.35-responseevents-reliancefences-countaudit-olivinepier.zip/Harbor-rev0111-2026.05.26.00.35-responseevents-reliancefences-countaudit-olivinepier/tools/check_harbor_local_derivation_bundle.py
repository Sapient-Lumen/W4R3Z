#!/usr/bin/env python3
"""Check the deterministic Harbor post-import local derivation drift bundle."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

import harbor_local_derivation_harness as harness  # noqa: E402


def fail(message: str) -> None:
    print(message)
    raise SystemExit(1)


def expect(condition: bool, message: str) -> None:
    if not condition:
        fail(message)


def strings(value: Any) -> list[str]:
    out: list[str] = []
    if isinstance(value, str):
        out.append(value)
    elif isinstance(value, dict):
        for child in value.values():
            out.extend(strings(child))
    elif isinstance(value, list):
        for child in value:
            out.extend(strings(child))
    return out


FORBIDDEN_ACCEPTED_PHRASES = [
    "global truth",
    "source equivalent",
    "current everywhere",
    "all copies clean",
    "upstream repaired",
    "compliant",
    "resolved",
]


def check_bundle(bundle: dict[str, Any]) -> None:
    expect(bundle.get("schema") == harness.SCHEMA, "Unexpected bundle schema")
    expect(bundle.get("version") == harness.VERSION, "Unexpected bundle version")
    expect(bundle.get("revision") == harness.REVISION, "Unexpected bundle revision")
    expect("durable schemas" in bundle.get("purpose", ""), "Purpose must refuse durable-schema promotion")
    expected_digest = harness.digest({k: v for k, v in bundle.items() if k != "bundle_digest"})
    expect(bundle.get("bundle_digest") == expected_digest, "Bundle digest drift")

    members = bundle.get("members")
    expect(isinstance(members, dict), "Bundle members must be an object")
    expect(list(members.keys()) == harness.MEMBER_LABELS, "Member labels/order drift")
    matrix = members["derivation.matrix"]
    expect(len(matrix) == len(harness.CASE_PLAN), "F098 case count drift")
    for label in harness.MEMBER_LABELS[1:]:
        expect(list(members[label].keys()) == list(matrix.keys()), f"Case id/order drift in {label}")

    accepted = rejected = 0
    seen_indexes: list[int] = []
    seen_candidates: set[str] = set()
    for case_id, row in matrix.items():
        seen_indexes.append(row.get("index"))
        candidate = row.get("candidate")
        expected = row.get("expected")
        seen_candidates.add(candidate)
        expect(expected in {"accepted", "rejected"}, f"{case_id}: invalid expected outcome")
        expect(candidate, f"{case_id}: missing candidate")
        expect(row.get("case_digest", "").startswith("sha256:"), f"{case_id}: case digest missing")

        ctx = members["import.context"][case_id]
        identity = members["derivative.identity"][case_id]
        transform = members["transform.scope"][case_id]
        fresh = members["freshness.invalidation"][case_id]
        state = members["consumer.copy.state"][case_id]
        verdict = members["verdict.summary"][case_id]

        expect(ctx.get("source_revision") == harness.REVISION, f"{case_id}: source revision drift")
        expect(str(ctx.get("handoff_bundle_digest", "")).startswith("sha256:"), f"{case_id}: handoff bundle digest missing")
        expect(ctx.get("import_is_not_currentness") is True, f"{case_id}: import currentness refusal missing")
        expect(ctx.get("import_is_not_derivative_truth") is True, f"{case_id}: import derivative-truth refusal missing")
        expect(ctx.get("handoff_does_not_authorize_future_local_derivatives") is True, f"{case_id}: handoff non-authority missing")

        for field in ["derivative_digest", "source_material_digest"]:
            expect(isinstance(identity.get(field), str) and identity[field].startswith("sha256:"), f"{case_id}: {field} missing digest")
        expect(identity.get("annotation_author_is_not_source_authority") is True, f"{case_id}: annotation authority refusal missing")
        expect(identity.get("local_patch_is_not_upstream_repair") is True, f"{case_id}: local repair refusal missing")
        expect(identity.get("digest_scope"), f"{case_id}: digest scope missing")

        expect(transform.get("transform_digest", "").startswith("sha256:"), f"{case_id}: transform digest missing")
        expect(transform.get("allowed_statement"), f"{case_id}: allowed statement missing")
        expect("derivative as original" in transform.get("forbidden_promotions", []), f"{case_id}: derivative/original guard missing")
        expect("local index result as truth" in transform.get("forbidden_promotions", []), f"{case_id}: index truth guard missing")
        expect(transform.get("transform_scope_is_not_source_scope") is True, f"{case_id}: transform/source scope refusal missing")
        expect(transform.get("derivative_contract_is_narrower_or_incomparable") is True, f"{case_id}: scope comparison bit missing")

        expect(fresh.get("source_revision_current") == harness.REVISION, f"{case_id}: freshness current revision drift")
        expect(fresh.get("requires_recheck_before_public_reuse") is True, f"{case_id}: recheck requirement missing")
        expect(fresh.get("freshness_is_not_inherited_from_import") is True, f"{case_id}: inherited freshness refusal missing")

        expect(state.get("consumer_copy_state_is_local") is True, f"{case_id}: local consumer-state bit missing")
        expect(state.get("sync_success_is_not_verification") is True, f"{case_id}: sync verification refusal missing")
        expect(state.get("local_ack_is_not_reliance_or_repair") is True, f"{case_id}: local ack refusal missing")
        expect(state.get("does_not_establish_global_downstream_copy_state") is True, f"{case_id}: global downstream refusal missing")

        expect(verdict.get("expected") == expected, f"{case_id}: expected echo drift")
        expect(verdict.get("expected_matched") is True, f"{case_id}: verdict did not match expected outcome")
        expect(verdict.get("non_promotion_checked") is True, f"{case_id}: non-promotion bit missing")
        for key in [
            "does_not_establish_source_identity",
            "does_not_establish_source_currentness",
            "does_not_establish_search_truth",
            "does_not_establish_compliance",
            "does_not_establish_upstream_repair",
            "does_not_establish_global_downstream_copy_state",
        ]:
            expect(verdict.get(key) is True, f"{case_id}: verdict non-promise missing {key}")

        if verdict.get("admitted"):
            accepted += 1
            expect(expected == "accepted", f"{case_id}: admitted rejected candidate")
            expect(verdict.get("failure_reasons") == [], f"{case_id}: admitted with failure reasons")
            expect(identity.get("target_digest_present") is True, f"{case_id}: admitted without target digest")
            expect(identity.get("derivative_digest_is_not_original_digest") is True, f"{case_id}: admitted digest-scope collapse")
            expect(transform.get("carries_label_digest") is True, f"{case_id}: admitted missing label digest")
            expect(transform.get("carries_non_promises") is True, f"{case_id}: admitted missing non-promises")
            accepted_text = "\n".join(strings({"identity": identity, "transform": transform, "fresh": fresh, "state": state, "verdict": verdict})).lower()
            for phrase in FORBIDDEN_ACCEPTED_PHRASES:
                expect(phrase not in accepted_text, f"{case_id}: accepted case contains forbidden authority phrase {phrase!r}")
        else:
            rejected += 1
            expect(expected == "rejected", f"{case_id}: rejected accepted candidate")
            expect(verdict.get("verdict_class") == "refused_counterfeit_local_derivation_confidence", f"{case_id}: rejected verdict class drift")
            expect(verdict.get("failure_reasons"), f"{case_id}: rejected case without failure reasons")

        if candidate == "annotation_rewrites_status_without_target_digest":
            expect(identity.get("target_digest_present") is False, f"{case_id}: missing target digest not represented")
            expect("missing_target_digest" in verdict.get("failure_reasons", []), f"{case_id}: missing target failure reason absent")
        elif candidate == "generated_summary_claims_source_equivalence":
            expect(transform.get("carries_non_promises") is False, f"{case_id}: summary equivalence did not drop non-promises")
            expect("summary_equivalence_overclaim" in verdict.get("failure_reasons", []), f"{case_id}: summary equivalence reason absent")
        elif candidate == "extracted_subset_loses_suppression_labels":
            expect(transform.get("carries_label_digest") is False, f"{case_id}: label loss not represented")
            expect("label_digest_lost" in verdict.get("failure_reasons", []), f"{case_id}: label loss reason absent")
        elif candidate == "local_index_timestamp_as_currentness":
            expect(fresh.get("timestamp_used_as_currentness") is True, f"{case_id}: timestamp misuse not represented")
            expect("timestamp_currentness_overclaim" in verdict.get("failure_reasons", []), f"{case_id}: timestamp reason absent")
        elif candidate == "reexport_archive_name_as_parent_identity":
            expect("reexport_name_identity_overclaim" in verdict.get("failure_reasons", []), f"{case_id}: re-export name reason absent")
        elif candidate == "cached_explanation_after_source_changed":
            expect(fresh.get("source_changed_since_derivation") is True, f"{case_id}: source change not represented")
            expect("stale_cache_after_source_change" in verdict.get("failure_reasons", []), f"{case_id}: stale cache reason absent")
        elif candidate == "cross_device_sync_success_as_verification":
            expect(state.get("sync_status") == "provider_sync_success", f"{case_id}: sync success not represented")
            expect("sync_success_as_verification" in verdict.get("failure_reasons", []), f"{case_id}: sync reason absent")
        elif candidate == "stale_consumer_copy_as_current":
            expect(state.get("stale_posture") == "stale_displayed_as_current", f"{case_id}: stale-as-current not represented")
            expect("stale_copy_as_current" in verdict.get("failure_reasons", []), f"{case_id}: stale current reason absent")
        elif candidate == "derivative_digest_as_original_digest":
            expect(identity.get("derivative_digest_is_not_original_digest") is False, f"{case_id}: digest-scope collapse not represented")
            expect("derivative_digest_scope_mismatch" in verdict.get("failure_reasons", []), f"{case_id}: digest scope reason absent")
        elif candidate == "local_search_index_result_as_truth":
            expect("local_index_truth_overclaim" in verdict.get("failure_reasons", []), f"{case_id}: local index truth reason absent")
        elif candidate == "model_summary_as_proof_of_compliance":
            expect("summary_compliance_overclaim" in verdict.get("failure_reasons", []), f"{case_id}: compliance reason absent")
        elif candidate == "annotation_author_as_authority":
            expect(identity.get("author_scope_present") is False, f"{case_id}: missing author scope not represented")
            expect("annotation_author_authority_overclaim" in verdict.get("failure_reasons", []), f"{case_id}: annotation authority reason absent")
        elif candidate == "sync_conflict_latest_wins":
            expect(state.get("conflict_policy") == "latest_wins_attempt", f"{case_id}: latest-wins not represented")
            expect("latest_wins_conflict_overclaim" in verdict.get("failure_reasons", []), f"{case_id}: latest-wins reason absent")
        elif candidate == "generated_table_missing_label_digest":
            expect(transform.get("carries_label_digest") is False, f"{case_id}: generated table label loss not represented")
            expect("generated_table_label_loss" in verdict.get("failure_reasons", []), f"{case_id}: generated table reason absent")
        elif candidate == "consumer_fix_patch_as_upstream_repair":
            expect(state.get("upstream_repair_claimed") is True, f"{case_id}: upstream repair overclaim not represented")
            expect("local_patch_as_upstream_repair" in verdict.get("failure_reasons", []), f"{case_id}: local patch reason absent")

    expect(seen_indexes == list(range(1, len(matrix) + 1)), "Local-derivation indexes must be gapless")
    expect(seen_candidates == {row["candidate"] for row in harness.CASE_PLAN}, "Not all F098 candidate classes are represented")

    global_ = bundle.get("global", {})
    expect(global_.get("case_count") == len(matrix), "Global case_count drift")
    expect(global_.get("accepted_count") == accepted, "Global accepted_count drift")
    expect(global_.get("rejected_count") == rejected, "Global rejected_count drift")
    expect(global_.get("source_revision") == harness.REVISION, "Global source revision drift")
    expect(global_.get("handoff_bundle_digest") == harness.handoff_bundle_digest(), "Global handoff bundle digest drift")
    expect("not a consumer cache API" in global_.get("coverage_claim", ""), "Coverage claim must refuse cache API promotion")
    for refusal in harness.NON_PROMOTION:
        expect(refusal in global_.get("non_promotion", []), f"Global non-promotion list missing {refusal}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Check Harbor post-import local derivation drift bundle")
    parser.add_argument("--fixture", type=Path, default=ROOT / "fixtures" / "harbor-post-import-local-derivation-drift-bundle-v0.json")
    args = parser.parse_args()

    expected = harness.build_bundle()
    check_bundle(expected)
    if args.fixture.exists():
        actual = json.loads(args.fixture.read_text(encoding="utf-8"))
        expect(actual == expected, "Checked fixture does not match deterministic harness output")
    else:
        fail(f"Fixture missing: {args.fixture}")
    print("Harbor post-import local derivation drift bundle check passed")


if __name__ == "__main__":
    main()
