#!/usr/bin/env python3
"""Audit shared Harbor proof-bundle conventions and generated-bytecode hygiene."""
from __future__ import annotations

import importlib
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

from harbor_bundle_common import check_digest_string, expect, file_digest, load_json  # noqa: E402
import harbor_executable_surface_registry as registry  # noqa: E402

def main() -> None:
    expect(file_digest(ROOT / "tools" / "harbor_bundle_common.py").startswith("sha256:"), "bundle common helper digest missing")
    pycache_files = [str(p.relative_to(ROOT)) for p in ROOT.rglob("*.pyc")]
    expect(not pycache_files, "Generated Python bytecode must not be part of the source tree: " + ", ".join(pycache_files))

    for surface in registry.EXECUTABLE_SURFACES:
        fixture_path = ROOT / surface["fixture"]
        data = load_json(fixture_path)
        expect("schema" in data, f"{surface['id']}: fixture missing schema")
        expect("version" in data, f"{surface['id']}: fixture missing version")
        expect("bundle_digest" in data, f"{surface['id']}: fixture missing bundle digest")
        check_digest_string(data["bundle_digest"], f"{surface['id']}: malformed bundle digest")
        revision = data.get("source_revision", data.get("revision"))
        expect(isinstance(revision, str) and revision.startswith("rev"), f"{surface['id']}: fixture revision missing")
        members = data.get("member_labels") or data.get("members")
        expect(members, f"{surface['id']}: fixture lacks member labels/members")
        global_ = data.get("global", {})
        expect(isinstance(global_.get("non_promotion"), list) and global_["non_promotion"], f"{surface['id']}: fixture missing global non_promotion list")

    # Make the new common helper a used dependency, not an orphan.
    current_checker = importlib.import_module(registry.EXECUTABLE_SURFACES[-1]["checker_module"])
    expect("harbor_bundle_common" in (ROOT / current_checker.__file__).read_text(encoding="utf-8"), "Latest checker does not use bundle common helper")
    print("Harbor bundle-common audit passed")

if __name__ == "__main__":
    main()
