#!/usr/bin/env python3
"""Emit deterministic Harbor foreign-import revocation evidence.

F103 starts after Harbor can import companion-cube fragments only through local
scope translation and authority quarantine.  The next pressure is change after
import: a sibling cube may withdraw, supersede, dispute, expire, or re-scope a
fragment Harbor previously imported.  Those notices matter, but they do not make
Harbor's earlier import false, repair every derivative, or install the companion
as a Harbor trust root.  This harness records prior import, foreign change
notice, local impact analysis, downstream quarantine, history residue, and
recheck posture as separate evidence.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

import harbor_cross_cube_lineage_import_harness as f102  # noqa: E402

SCHEMA = "harbor-foreign-import-revocation-bundle"
VERSION = "0"
REVISION = "rev0111"

MEMBER_LABELS = [
    "revocation.matrix",
    "prior.import",
    "foreign.change.notice",
    "local.impact.analysis",
    "downstream.quarantine",
    "history.residue",
    "recheck.plan",
    "verdict.summary",
]

NON_PROMOTION = [
    "no foreign revocation API",
    "no companion trust root",
    "no automatic downstream repair",
    "no prior-falsity judgment",
    "no negligence judgment",
    "no foreign compliance workflow",
    "no global public badge workflow",
    "no cross-cube status inheritance",
    "no final SlopOS datacube shape",
]

CASE_PLAN: list[dict[str, Any]] = [
    {"id": "FR001", "candidate": "slopos_import_withdrawn_to_historical_residue", "cube": "SlopOS", "change": "withdrawn", "expected": "accepted"},
    {"id": "FR002", "candidate": "foundry_pin_superseded_to_label_quarantine", "cube": "Foundry", "change": "superseded", "expected": "accepted"},
    {"id": "FR003", "candidate": "steward_retry_history_corrected_without_fault", "cube": "Steward", "change": "corrected", "expected": "accepted"},
    {"id": "FR004", "candidate": "schell_retention_context_expired_to_recheck", "cube": "Schell", "change": "expired", "expected": "accepted"},
    {"id": "FR005", "candidate": "viewfs_volition_card_rescoped_to_narrow_consent_evidence", "cube": "ViewFS", "change": "rescoped", "expected": "accepted"},
    {"id": "FR006", "candidate": "ward_delegation_warrant_withdrawn_route_recheck", "cube": "Ward", "change": "withdrawn", "expected": "accepted"},
    {"id": "FR007", "candidate": "helm_repair_trace_disputed_to_derivative_quarantine", "cube": "Helm", "change": "disputed", "expected": "accepted"},
    {"id": "FR008", "candidate": "multi_cube_conflicting_revocations_kept_incomparable", "cube": ["SlopOS", "Helm", "Foundry"], "change": "mixed", "expected": "accepted"},
    {"id": "FR009", "candidate": "sealed_foreign_withdrawal_notice_digest_only", "cube": ["Ward", "Schell"], "change": "withdrawn", "sealed": True, "expected": "accepted"},
    {"id": "FR010", "candidate": "stale_companion_supersession_notice_imported_as_history", "cube": ["ViewFS", "Steward"], "change": "superseded", "stale_notice": True, "expected": "accepted"},
    {"id": "FR011", "candidate": "revocation_means_prior_harbor_import_false", "cube": "SlopOS", "change": "withdrawn", "expected": "rejected"},
    {"id": "FR012", "candidate": "withdrawal_means_automatic_downstream_repair", "cube": "Helm", "change": "withdrawn", "expected": "rejected"},
    {"id": "FR013", "candidate": "supersession_lifts_quarantine_and_trusts_new_fragment", "cube": "Foundry", "change": "superseded", "expected": "rejected"},
    {"id": "FR014", "candidate": "foreign_dispute_means_fragment_false", "cube": "Ward", "change": "disputed", "expected": "rejected"},
    {"id": "FR015", "candidate": "expiry_means_material_erased_or_repaired", "cube": "Schell", "change": "expired", "expected": "rejected"},
    {"id": "FR016", "candidate": "foreign_rescope_widens_harbor_scope", "cube": "ViewFS", "change": "rescoped", "expected": "rejected"},
    {"id": "FR017", "candidate": "revocation_imported_as_compliance_failure", "cube": "Steward", "change": "withdrawn", "expected": "rejected"},
    {"id": "FR018", "candidate": "newer_companion_revision_as_freshness", "cube": "Foundry", "change": "superseded", "expected": "rejected"},
    {"id": "FR019", "candidate": "notice_timestamp_as_harbor_currentness", "cube": "SlopOS", "change": "corrected", "expected": "rejected"},
    {"id": "FR020", "candidate": "missing_foreign_change_digest_accepted", "cube": "Helm", "change": "disputed", "expected": "rejected"},
    {"id": "FR021", "candidate": "changed_archive_digest_mismatch_accepted", "cube": "Ward", "change": "superseded", "expected": "rejected"},
    {"id": "FR022", "candidate": "revocation_without_parent_import_id", "cube": "Schell", "change": "withdrawn", "expected": "rejected"},
    {"id": "FR023", "candidate": "badge_changed_without_local_impact_analysis", "cube": "ViewFS", "change": "rescoped", "expected": "rejected"},
    {"id": "FR024", "candidate": "revocation_produces_public_green_badge", "cube": "Foundry", "change": "corrected", "expected": "rejected"},
    {"id": "FR025", "candidate": "companion_revocation_becomes_harbor_authority", "cube": "Ward", "change": "withdrawn", "expected": "rejected"},
    {"id": "FR026", "candidate": "multiple_revocation_notices_majority_wins", "cube": ["Foundry", "Ward", "Helm"], "change": "mixed", "expected": "rejected"},
    {"id": "FR027", "candidate": "sealed_withdrawal_notice_as_public_truth", "cube": "Ward", "change": "withdrawn", "sealed": True, "expected": "rejected"},
    {"id": "FR028", "candidate": "rollback_after_foreign_withdrawal_without_recheck", "cube": "Helm", "change": "withdrawn", "expected": "rejected"},
    {"id": "FR029", "candidate": "supersession_closes_all_derivatives_globally", "cube": "SlopOS", "change": "superseded", "expected": "rejected"},
    {"id": "FR030", "candidate": "consumer_ack_of_revocation_as_repair", "cube": "ViewFS", "change": "withdrawn", "expected": "rejected"},
]

FAILURE_REASONS = {
    "revocation_means_prior_harbor_import_false": "revocation_as_prior_falsity",
    "withdrawal_means_automatic_downstream_repair": "withdrawal_as_automatic_repair",
    "supersession_lifts_quarantine_and_trusts_new_fragment": "supersession_trusts_new_fragment",
    "foreign_dispute_means_fragment_false": "dispute_as_falsehood",
    "expiry_means_material_erased_or_repaired": "expiry_as_erasure_or_repair",
    "foreign_rescope_widens_harbor_scope": "foreign_rescope_widens_harbor_scope",
    "revocation_imported_as_compliance_failure": "revocation_as_compliance_failure",
    "newer_companion_revision_as_freshness": "newer_revision_as_freshness",
    "notice_timestamp_as_harbor_currentness": "notice_timestamp_as_currentness",
    "missing_foreign_change_digest_accepted": "missing_change_digest",
    "changed_archive_digest_mismatch_accepted": "changed_archive_digest_mismatch",
    "revocation_without_parent_import_id": "missing_parent_import_id",
    "badge_changed_without_local_impact_analysis": "badge_change_without_impact_analysis",
    "revocation_produces_public_green_badge": "revocation_as_green_badge",
    "companion_revocation_becomes_harbor_authority": "companion_revocation_as_authority",
    "multiple_revocation_notices_majority_wins": "revocation_majority_vote",
    "sealed_withdrawal_notice_as_public_truth": "sealed_notice_as_public_truth",
    "rollback_after_foreign_withdrawal_without_recheck": "rollback_without_recheck",
    "supersession_closes_all_derivatives_globally": "supersession_global_derivative_closure",
    "consumer_ack_of_revocation_as_repair": "consumer_ack_as_repair",
}


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def digest(value: Any) -> str:
    return "sha256:" + hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def load_f102_bundle() -> dict[str, Any]:
    return json.loads((ROOT / "fixtures" / "harbor-cross-cube-lineage-import-bundle-v0.json").read_text(encoding="utf-8"))


def f102_bundle_digest() -> str:
    return load_f102_bundle()["bundle_digest"]


def cubes_for(plan: dict[str, Any]) -> list[str]:
    cube = plan["cube"]
    return cube if isinstance(cube, list) else [cube]


def prior_import(plan: dict[str, Any], index: int) -> dict[str, Any]:
    cubes = cubes_for(plan)
    fragments = []
    for cube in cubes:
        spec = f102.FOREIGN_CATALOG[cube]
        fragments.append(
            {
                "cube": cube,
                "foreign_revision": spec["revision"],
                "archive_name": spec["archive_name"],
                "archive_sha256": spec["archive_sha256"],
                "fragment_family": spec["fragment_family"],
                "prior_native_status": spec["native_status"],
                "prior_safe_harbor_use": spec["safe_harbor_use"],
                "prior_fragment_digest": digest({"cube": cube, "revision": spec["revision"], "family": spec["fragment_family"], "import": "F102"}),
                "prior_import_status": "quarantined_evidence_only",
                "prior_non_promises": [
                    "not Harbor status",
                    "not currentness",
                    "not repair",
                    "not compliance",
                    "not consent/delegation authority",
                ],
            }
        )
    return {
        "parent_import_id": f"harbor-xc-{index:03d}",
        "parent_bundle_digest": f102_bundle_digest(),
        "parent_manifest_present": True,
        "parent_import_scope": "harbor_local_scope_after_F102_translation",
        "foreign_fragment_count": len(fragments),
        "foreign_fragments": fragments,
        "prior_import_was_quarantined": True,
        "prior_import_was_not_reliance_authority": True,
        "prior_import_digest": digest(fragments),
    }


def change_notice(plan: dict[str, Any], index: int) -> dict[str, Any]:
    candidate = plan["candidate"]
    cubes = cubes_for(plan)
    notices = []
    for cube in cubes:
        spec = f102.FOREIGN_CATALOG[cube]
        revision_number = int(spec["revision"].removeprefix("rev")) if spec["revision"].startswith("rev") else index
        new_revision = f"rev{revision_number + 1:04d}"
        change = plan["change"]
        if change == "mixed":
            change = {"SlopOS": "withdrawn", "Helm": "disputed", "Foundry": "superseded", "Ward": "withdrawn"}.get(cube, "rescoped")
        notice_payload = {
            "cube": cube,
            "prior_revision": spec["revision"],
            "notice_revision": new_revision,
            "change_class": change,
            "foreign_scope_before": f"{spec['fragment_family']}:native_scope",
            "foreign_scope_after": f"{spec['fragment_family']}:native_scope:{change}",
            "issuer": f"{cube}.companion-maintainer",
            "notice_clock": f"2026-05-25T21:{index % 60:02d}:00Z",
        }
        notices.append(
            {
                **notice_payload,
                "notice_digest": digest(notice_payload),
                "archive_digest_expected": spec["archive_sha256"],
                "archive_digest_observed": ("sha256:bad-change-digest" if candidate == "changed_archive_digest_mismatch_accepted" else spec["archive_sha256"]),
                "archive_digest_ok": candidate != "changed_archive_digest_mismatch_accepted",
                "parent_import_id_present": candidate != "revocation_without_parent_import_id",
                "change_digest_present": candidate != "missing_foreign_change_digest_accepted",
                "sealed_notice": bool(plan.get("sealed")),
                "stale_notice": bool(plan.get("stale_notice")) or candidate == "newer_companion_revision_as_freshness",
                "notice_non_promises": [
                    "not Harbor authority",
                    "not prior falsity",
                    "not downstream repair",
                    "not public truth",
                    "not compliance finding",
                ],
            }
        )
    return {
        "change_notice_count": len(notices),
        "notices": notices,
        "all_archive_digests_ok": all(n["archive_digest_ok"] for n in notices),
        "all_parent_import_ids_present": all(n["parent_import_id_present"] for n in notices),
        "all_change_digests_present": all(n["change_digest_present"] for n in notices),
        "all_notices_sealed": all(n["sealed_notice"] for n in notices),
        "any_notice_stale": any(n["stale_notice"] for n in notices),
        "notice_set_digest": digest(notices),
    }


def flags_for(candidate: str) -> dict[str, bool]:
    return {
        "prior_falsity_claimed": candidate == "revocation_means_prior_harbor_import_false",
        "negligence_claimed": candidate == "revocation_means_prior_harbor_import_false",
        "automatic_repair_claimed": candidate in {"withdrawal_means_automatic_downstream_repair", "consumer_ack_of_revocation_as_repair"},
        "new_fragment_trusted_without_quarantine": candidate == "supersession_lifts_quarantine_and_trusts_new_fragment",
        "dispute_claimed_falsehood": candidate == "foreign_dispute_means_fragment_false",
        "expiry_claimed_erasure_or_repair": candidate == "expiry_means_material_erased_or_repaired",
        "scope_widened_by_foreign_rescope": candidate == "foreign_rescope_widens_harbor_scope",
        "compliance_failure_claimed": candidate == "revocation_imported_as_compliance_failure",
        "freshness_from_new_revision": candidate == "newer_companion_revision_as_freshness",
        "currentness_from_notice_timestamp": candidate == "notice_timestamp_as_harbor_currentness",
        "badge_changed_without_impact_analysis": candidate == "badge_changed_without_local_impact_analysis",
        "public_green_badge_claimed": candidate == "revocation_produces_public_green_badge",
        "companion_authority_imported": candidate == "companion_revocation_becomes_harbor_authority",
        "majority_vote_used": candidate == "multiple_revocation_notices_majority_wins",
        "sealed_notice_claimed_public_truth": candidate == "sealed_withdrawal_notice_as_public_truth",
        "rollback_without_recheck": candidate == "rollback_after_foreign_withdrawal_without_recheck",
        "global_derivative_closure_claimed": candidate == "supersession_closes_all_derivatives_globally",
        "consumer_ack_claimed_repair": candidate == "consumer_ack_of_revocation_as_repair",
    }


def impact_analysis(plan: dict[str, Any], notice: dict[str, Any]) -> dict[str, Any]:
    candidate = plan["candidate"]
    flags = flags_for(candidate)
    local_analysis_present = not flags["badge_changed_without_impact_analysis"]
    return {
        "analysis_id": f"impact-{plan['id'].lower()}",
        "local_analysis_present": local_analysis_present,
        "foreign_change_is_input_not_verdict": not flags["companion_authority_imported"],
        "prior_import_marked_false": flags["prior_falsity_claimed"],
        "prior_import_marked_negligent": flags["negligence_claimed"],
        "change_requires_local_recheck": not flags["automatic_repair_claimed"],
        "status_recomputed_only_after_local_evidence": not (flags["currentness_from_notice_timestamp"] or flags["freshness_from_new_revision"] or flags["companion_authority_imported"]),
        "notice_timestamp_used_as_currentness": flags["currentness_from_notice_timestamp"],
        "newer_companion_revision_used_as_freshness": flags["freshness_from_new_revision"],
        "companion_notice_used_as_authority": flags["companion_authority_imported"],
        "compliance_failure_claimed": flags["compliance_failure_claimed"],
        "public_green_badge_claimed": flags["public_green_badge_claimed"],
        "majority_vote_used": flags["majority_vote_used"],
        "impact_scope_relation": ("widened_by_foreign_notice" if flags["scope_widened_by_foreign_rescope"] else "same_or_narrower_or_incomparable"),
        "impact_digest": digest({"candidate": candidate, "notice_digest": notice["notice_set_digest"], "flags": flags}),
        "impact_non_promises": [
            "change notice is not local verdict",
            "revocation is not prior falsity",
            "supersession is not trust promotion",
            "dispute is not falsehood",
            "expiry is not erasure proof",
        ],
        "flags": flags,
    }


def downstream_quarantine(plan: dict[str, Any], impact: dict[str, Any]) -> dict[str, Any]:
    flags = impact["flags"]
    affected = [
        {"derivative_id": f"derivative-{plan['id'].lower()}-summary", "state": "needs_recheck_or_quarantine"},
        {"derivative_id": f"derivative-{plan['id'].lower()}-index", "state": "history_retained_not_current"},
    ]
    return {
        "affected_derivatives": affected,
        "derivative_count": len(affected),
        "quarantine_required": not flags["automatic_repair_claimed"],
        "automatic_repair_claimed": flags["automatic_repair_claimed"],
        "global_derivative_closure_claimed": flags["global_derivative_closure_claimed"],
        "consumer_ack_claimed_repair": flags["consumer_ack_claimed_repair"],
        "sync_or_notice_is_not_repair": not (flags["consumer_ack_claimed_repair"] or flags["automatic_repair_claimed"]),
        "downstream_scope": "known derivatives only; unreached surfaces remain unknown",
        "downstream_digest": digest({"affected": affected, "flags": flags}),
        "non_promises": [
            "not all derivatives reached",
            "not automatic repair",
            "not consumer acknowledgement as repair",
            "not global closure",
        ],
    }


def history_residue(plan: dict[str, Any], prior: dict[str, Any], impact: dict[str, Any]) -> dict[str, Any]:
    flags = impact["flags"]
    return {
        "prior_import_digest": prior["prior_import_digest"],
        "retain_prior_import_history": not flags["prior_falsity_claimed"],
        "residue_class": "historical_import_residue_with_revocation_overlay",
        "revocation_changes_current_use_not_past_observation": not flags["prior_falsity_claimed"],
        "dispute_marks_uncertainty_not_falsehood": not flags["dispute_claimed_falsehood"],
        "expiry_marks_recheck_not_erasure": not flags["expiry_claimed_erasure_or_repair"],
        "supersession_keeps_old_context": not flags["new_fragment_trusted_without_quarantine"],
        "sealed_notice_public_truth": flags["sealed_notice_claimed_public_truth"],
        "history_digest": digest({"prior": prior["prior_import_digest"], "candidate": plan["candidate"], "flags": flags}),
        "history_non_promises": [
            "history is not currentness",
            "revoked is not false",
            "superseded is not erased",
            "disputed is not adjudicated",
            "sealed is not public truth",
        ],
    }


def recheck_plan(plan: dict[str, Any], notice: dict[str, Any], impact: dict[str, Any]) -> dict[str, Any]:
    flags = impact["flags"]
    required = not flags["rollback_without_recheck"]
    return {
        "recheck_required": required,
        "rollback_requires_recheck": not flags["rollback_without_recheck"],
        "recheck_trigger": plan["change"],
        "clock_basis": "notice_observed_time_plus_local_evaluation_clock",
        "notice_timestamp_is_not_currentness": not flags["currentness_from_notice_timestamp"],
        "new_revision_is_not_freshness": not flags["freshness_from_new_revision"],
        "required_surfaces": ["parent import", "affected derivatives", "public warning", "consumer cache", "cross-cube bridge"],
        "missing_digest_blocks_recheck": not notice["all_change_digests_present"],
        "archive_mismatch_blocks_recheck": not notice["all_archive_digests_ok"],
        "missing_parent_blocks_recheck": not notice["all_parent_import_ids_present"],
        "majority_vote_not_allowed": not flags["majority_vote_used"],
        "recheck_plan_digest": digest({"candidate": plan["candidate"], "notice": notice["notice_set_digest"], "required": required}),
    }


def admitted(plan: dict[str, Any], prior: dict[str, Any], notice: dict[str, Any], impact: dict[str, Any], down: dict[str, Any], hist: dict[str, Any], recheck: dict[str, Any]) -> bool:
    flags = impact["flags"]
    forbidden_flags = any(flags.values())
    blockers = not (notice["all_archive_digests_ok"] and notice["all_parent_import_ids_present"] and notice["all_change_digests_present"])
    structural = prior["prior_import_was_quarantined"] and impact["local_analysis_present"] and hist["retain_prior_import_history"] and recheck["recheck_required"]
    return plan["expected"] == "accepted" and not forbidden_flags and not blockers and structural and not hist["sealed_notice_public_truth"] and not down["global_derivative_closure_claimed"]


def case_record(plan: dict[str, Any], index: int) -> dict[str, Any]:
    prior = prior_import(plan, index)
    notice = change_notice(plan, index)
    impact = impact_analysis(plan, notice)
    down = downstream_quarantine(plan, impact)
    hist = history_residue(plan, prior, impact)
    recheck = recheck_plan(plan, notice, impact)
    is_admitted = admitted(plan, prior, notice, impact, down, hist, recheck)
    failure_reason = None if is_admitted else FAILURE_REASONS.get(plan["candidate"], "structural_revocation_import_failure")
    verdict = {
        "admitted": is_admitted,
        "verdict_class": "accepted_revocation_overlay" if is_admitted else "refused_counterfeit_revocation_import",
        "expected": plan["expected"],
        "expected_matched": (is_admitted and plan["expected"] == "accepted") or ((not is_admitted) and plan["expected"] == "rejected"),
        "failure_reason": failure_reason,
        "non_promotion_checked": True,
        "does_not_mark_prior_import_false": not impact["prior_import_marked_false"],
        "does_not_establish_downstream_repair": not down["automatic_repair_claimed"],
        "does_not_import_companion_authority": not impact["companion_notice_used_as_authority"],
    }
    return {
        "index": index,
        "id": plan["id"],
        "candidate": plan["candidate"],
        "revocation.matrix": {
            "id": plan["id"],
            "candidate": plan["candidate"],
            "cube": plan["cube"],
            "change": plan["change"],
            "expected": plan["expected"],
        },
        "prior.import": prior,
        "foreign.change.notice": notice,
        "local.impact.analysis": impact,
        "downstream.quarantine": down,
        "history.residue": hist,
        "recheck.plan": recheck,
        "verdict.summary": verdict,
    }


def build_bundle() -> dict[str, Any]:
    cases = [case_record(plan, idx) for idx, plan in enumerate(CASE_PLAN, start=1)]
    accepted = sum(1 for case in cases if case["verdict.summary"]["admitted"])
    rejected = len(cases) - accepted
    bundle = {
        "schema": SCHEMA,
        "version": VERSION,
        "source_revision": REVISION,
        "member_labels": MEMBER_LABELS,
        "prior_cross_cube_import_bundle_digest": f102_bundle_digest(),
        "foreign_catalog": f102.FOREIGN_CATALOG,
        "cases": cases,
        "audit_refactor_note": {
            "refactor": "rev0108 also centralizes executable proof-slice listing in harbor_executable_surface_registry.py",
            "audit_guard": "check_harbor_executable_surface_registry verifies surface paths and checker ordering",
            "non_promise": "registry is maintenance inventory, not conformance status or trust root",
        },
        "global": {
            "case_count": len(cases),
            "accepted_count": accepted,
            "rejected_count": rejected,
            "source_revision": REVISION,
            "coverage_claim": "foreign revocation/correction notices become scoped overlays requiring local recheck; not a revocation API or companion trust root",
            "non_promotion": NON_PROMOTION,
            "member_labels": MEMBER_LABELS,
        },
    }
    bundle["bundle_digest"] = digest({key: bundle[key] for key in ["schema", "version", "source_revision", "member_labels", "prior_cross_cube_import_bundle_digest", "foreign_catalog", "cases", "audit_refactor_note", "global"]})
    return bundle


def main() -> None:
    parser = argparse.ArgumentParser(description="Emit Harbor foreign-import revocation bundle")
    parser.add_argument("--out", type=Path, default=None)
    args = parser.parse_args()
    text = json.dumps(build_bundle(), indent=2, sort_keys=True) + "\n"
    if args.out:
        args.out.write_text(text, encoding="utf-8")
    else:
        print(text, end="")


if __name__ == "__main__":
    main()
