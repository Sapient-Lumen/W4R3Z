# Harbor post-import local derivation drift bundle v0

`harbor-post-import-local-derivation-drift-bundle-v0.json` is a deterministic proof slice for F098. It is not a schema, conformance suite, cache API, sync-state ledger, search index contract, annotation authority model, repair attestation profile, or SlopOS datacube shape.

## Members

1. `derivation.matrix` — candidate id, class, expected outcome, and digest.
2. `import.context` — source revision/archive, handoff bundle digest, import scope, and import non-authority bits.
3. `derivative.identity` — derivative kind/id/digest, source/target digest posture, author scope, and local patch posture.
4. `transform.scope` — transform digest, lossy posture, label/non-promise carry-forward, allowed statement, and forbidden promotions.
5. `freshness.invalidation` — source revision basis, source-change posture, invalidation trigger, currentness basis, expiry/recheck window.
6. `consumer.copy.state` — sync, stale, conflict, acknowledgement, and local patch state.
7. `verdict.summary` — admitted/refused class, failure reasons, and non-promises.

## Accepted cases

- annotation with target digest and author scope;
- generated summary with source digest, expiry, and omission notes;
- extracted subset with subset manifest and loss notes;
- local index with source digest and invalidation trigger;
- re-exported archive with parent digest and new scope;
- cached explanation revalidated after source revision match;
- cross-device synced copy with byte digest recheck;
- stale consumer copy quarantined with a supersession note.

## Hostile cases

The checker rejects annotation status rewrites without target digest, generated-summary equivalence, label loss, timestamp-as-currentness, re-export name-as-identity, stale cache after source change, sync success-as-verification, stale copy-as-current, derivative digest-as-original, local search truth, summary compliance proof, annotation author-as-authority, latest-wins sync conflict, generated table label loss, and local patch-as-upstream repair.

## Non-promotions

The bundle explicitly keeps local derivation evidence smaller than a local derivation receipt API, consumer cache API, sync-state ledger, annotation authority model, local search truth plane, repair attestation profile, or final SlopOS datacube shape.
