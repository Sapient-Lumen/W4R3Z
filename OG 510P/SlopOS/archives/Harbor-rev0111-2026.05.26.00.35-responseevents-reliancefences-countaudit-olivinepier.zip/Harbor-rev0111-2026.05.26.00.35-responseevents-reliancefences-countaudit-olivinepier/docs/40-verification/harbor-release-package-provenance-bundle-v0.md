# Harbor release-package provenance bundle v0

This verification surface belongs to F096. It is a deterministic proof slice for source-tree-to-zip release packaging.

## Producer and checker

- Harness: `tools/harbor_release_package_provenance_harness.py`
- Fixture: `fixtures/harbor-release-package-provenance-bundle-v0.json`
- Bundle checker: `tools/check_harbor_release_package_provenance_bundle.py`
- Emitted-zip checker: `tools/check_harbor_release_zip.py`

The fixture is generated with:

```bash
python3 tools/harbor_release_package_provenance_harness.py --write fixtures/harbor-release-package-provenance-bundle-v0.json
```

The bundle checker is run by `make check`. The emitted-zip checker is run by `make package-release` after the zip has been written.

## Member labels

The bundle contains the following ordered members:

1. `release.matrix`
2. `root.identity`
3. `file.inventory`
4. `archive.index.check`
5. `package.plan`
6. `build.environment`
7. `bootstrap.verification`
8. `verdict.summary`

The order is intentional. It keeps the release package observation readable without turning the bundle into a general schema.

## Accepted cases

- current release surfaces;
- deterministic ZIP plan;
- build-environment capture;
- out-of-band verification receipt.

## Rejected cases

- archive-index drift;
- embedded release zip;
- nondeterministic ZIP metadata;
- stale release root name;
- generated artifact unlisted from the archive index;
- bootstrap self-trust attempt;
- attestation-as-security claim.

## Required non-promises

Every admitted case must retain these refusals:

- does not establish archive signature;
- does not establish reproducible build;
- does not establish artifact security;
- does not establish CI status;
- does not establish package trust root;
- does not establish final SlopOS datacube shape.

## Post-package boundary

The source fixture cannot contain the final zip digest because the zip is emitted after the fixture is checked and packed. The final digest is an out-of-band observation produced by `tools/check_harbor_release_zip.py`, `unzip -t`, or an external reviewer.
