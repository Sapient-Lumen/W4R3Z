# Harbor property/mutation coverage bundle v0

**Introduced:** `rev0098` / F093.  
**Fixture:** `fixtures/harbor-property-mutation-coverage-bundle-v0.json`  
**Harness:** `tools/harbor_property_mutation_harness.py`  
**Checker:** `tools/check_harbor_property_mutation_bundle.py`

## Contract

The bundle is a deterministic meta-fixture over existing executable Harbor bundles. It imports the F090, F091, and F092 harness/checker pairs, mutates their emitted bundles, and records whether the existing checkers reject the mutants.

The bundle is not a shared schema. Its member labels are part of the rev0098 proof slice only.

## Member labels

```text
suite.matrix
baseline.digest
property.claims
mutation.plan
mutation.results
shrink.notes
coverage.summary
verdict.summary
```

## Required guarantees

The checker requires:

- exact schema/version/revision identity;
- top-level digest binding;
- exact member-label ordering;
- baseline digests for `crossing`, `receipt`, and `disagreement` bundles;
- exactly 38 deterministic mutations in rev0098;
- gapless mutation indexes;
- mutation ids aligned across matrix, plan, results, and shrink notes;
- each mutation has a named operator, bundle target, invariant list, baseline digest, mutant digest, checker reason, and shrink note;
- all current mutations are killed;
- no survived mutation may be hidden;
- common, crossing, receipt, and disagreement operator families are all represented;
- non-promotion refusals include no property-test framework dependency, no shared bundle schema, no generated conformance suite, no numeric coverage gate, no fuzzer corpus promotion, and no final SlopOS datacube shape.

## Why it exists

The three prior executable bundles can pass while failing to pressure the checkers themselves. F093 adds a meta-check that proves current checkers reject deliberate counterfeits such as:

```text
bundle digest drift
member-table case drift
non-promotion bit removal
rejected-case record emission
subject digest mismatch
scope/currentness upgrade
stripped route/receipt/verifier guards
green badge collapse
majority/latest-wins collapse
unknown currentness as fresh
missing verifier policy digest
hidden disagreement
```

## Refusal rules

The checker must reject the meta-bundle if:

- any mutation survives;
- mutation ids drift between tables;
- the coverage claim stops refusing completeness;
- the bundle promotes a generated conformance suite;
- a generated mutation lacks a human-readable shrink target;
- the global counters hide survived cases;
- the fixture differs from deterministic harness output.

## Non-promotion note

The bundle is a pressure map, not a law. A killed mutation proves checker sensitivity to that operator. It does not prove that the checker is complete, that the schema is correct, or that future generated mutations are automatically meaningful.
