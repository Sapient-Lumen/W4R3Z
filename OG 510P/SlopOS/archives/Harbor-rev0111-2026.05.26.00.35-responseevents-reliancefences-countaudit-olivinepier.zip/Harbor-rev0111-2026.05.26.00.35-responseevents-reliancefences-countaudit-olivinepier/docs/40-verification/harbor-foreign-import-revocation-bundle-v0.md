# Harbor foreign-import revocation bundle v0

The `harbor-foreign-import-revocation-bundle-v0.json` fixture is the executable pressure slice for F103.  It records thirty deterministic cases where a foreign fragment imported under F102 is later withdrawn, superseded, corrected, disputed, expired, or re-scoped.

The bundle members are:

- `revocation.matrix`
- `prior.import`
- `foreign.change.notice`
- `local.impact.analysis`
- `downstream.quarantine`
- `history.residue`
- `recheck.plan`
- `verdict.summary`

The harness is `tools/harbor_foreign_import_revocation_harness.py`.
The checker is `tools/check_harbor_foreign_import_revocation_bundle.py`.

## Acceptance posture

A case can be admitted only when:

- the parent F102 bundle digest is preserved;
- the prior import remains quarantined evidence rather than reliance authority;
- the foreign change notice has a digest, parent import id, and archive-digest match;
- local impact analysis is present;
- prior history is retained as history, not overwritten by revocation;
- downstream derivatives are quarantined or recheck-required rather than auto-repaired;
- rollback or current-status change requires local recheck;
- no companion authority, freshness, compliance, public truth, green badge, or global derivative closure is inherited.

## Rejection posture

The hostile cases intentionally reject:

- revocation as prior falsity;
- withdrawal as automatic downstream repair;
- supersession as trust promotion;
- dispute as falsehood;
- expiry as erasure or repair;
- foreign re-scope as Harbor scope widening;
- revocation as compliance failure;
- newer revision or notice timestamp as freshness/currentness;
- missing change digest, changed archive digest mismatch, or missing parent import id;
- badge changes without local impact analysis;
- companion revocation as Harbor authority;
- majority-vote revocation decisions;
- sealed notice as public truth;
- rollback without recheck;
- consumer acknowledgement as repair.

## Non-promotion

This bundle is not a foreign revocation API, companion trust root, automatic downstream repair workflow, prior-falsity judgment, negligence judgment, compliance workflow, global public badge workflow, cross-cube status inheritance system, or final SlopOS datacube shape.
