# Harbor CrossingRecord evidence bundle v0

**Revision:** `rev0095`  
**Status:** deterministic F090 proof slice; not a production schema, API, conformance suite, SlopOS import contract, browser credential profile, MCP trust profile, public status API, compliance workflow, transparency profile, or final SlopOS datacube shape.

## Purpose

`rev0094` named `CrossingRecord v0`. `rev0095` gives that name a small executable pressure surface. The bundle proves that Harbor can accept route/admission/aftermath evidence from SlopOS-like and browser/tool/public-copy crossings while rejecting nearby malformed or overclaiming candidates.

The executable object is the deterministic `harbor-crossing-record-evidence-bundle` JSON emitted by:

```bash
python3 tools/harbor_crossing_record_harness.py --emit-bundle
```

It is checked against the committed fixture by:

```bash
python3 tools/check_harbor_crossing_record_bundle.py --fixture fixtures/harbor-crossing-record-evidence-bundle-v0.json
```

`make check` now runs this checker before the broader repo hygiene pass.

## Canonical member labels

The v0 bundle has exactly these member labels:

1. `case.matrix` — stable case ids, expected admission result, and exercised boundary.
2. `input.external_evidence` — the bounded outside evidence Harbor is being asked to ingest.
3. `input.crossing_record` — an accepted `CrossingRecord v0` or a rejected candidate wrapper.
4. `scope.comparison` — the same/narrower/overlap/incomparable/supersession/staleness verdict.
5. `output.admission` — the Harbor admission or rejection result.
6. `output.aftermath` — the record id or rejection residue plus non-promises.
7. `verdict.summary` — digest-bound machine-checkable bits for guards, scope, subject digest, ambient-field rejection, and non-promotion.

No alias labels are allowed in v0.

## Case coverage

The fixture keeps ten stable cases:

| Case | Expected | Pressure |
|---|---:|---|
| `accept-portal-net-request-route-admission` | accepted | SlopOS `portal.net.request` route/admission evidence is admitted as crossing residue only. |
| `accept-portal-net-resume-truncation-append` | accepted | Checkpoint/resume/truncation/append evidence updates a local accepted-prefix cursor only. |
| `reject-malformed-envelope-ambient-field` | rejected | A candidate with `ambient_truth` is not a crossing record. |
| `reject-subject-digest-mismatch` | rejected | Subject digest mismatch blocks import before aftermath. |
| `accept-callback-continuation-boundary` | accepted | Callback return evidence resumes local continuation without importing remote authority. |
| `accept-mcp-tool-metadata-untrusted` | accepted | MCP/tool resource metadata can be displayed for review but stays untrusted. |
| `accept-browser-credential-presentation` | accepted | Browser-mediated credential presentation remains audience-bound, not global identity. |
| `accept-public-copy-aftermath-warning` | accepted | Public-copy stale recurrence keeps warning scope narrow and active. |
| `reject-global-resolution-overclaim` | rejected | Refuses a status banner saying `resolved` without scoped warning receipts. |
| `reject-latest-wins-scope-substitution` | rejected | A later ticket cannot swap public-US canonical scope for public-global generated-explainer scope. |

## Required non-promises

Accepted records must include route-family non-promises:

- `portal.net.request`: `not_transport_trust`, `not_content_truth`, `not_current_lease`, `not_user_comprehension`.
- `portal.net.durability`: `not_transport_trust`, `not_discarded_suffix_preserved`, `not_denied_duplicate_durable`, `not_outside_truth_continuity`.
- `callback`: `not_same_authority`, `not_user_comprehension`, `not_local_adoption`.
- `mcp_tool_metadata`: `not_tool_annotation_truth`, `not_user_consent_proof`, `not_content_truth`.
- `browser_credential`: `not_identity_truth`, `not_holder_authority`, `not_user_comprehension`, `not_global_authorization`.
- `public_copy_aftermath`: `not_global_repair`, `not_compliance`, `not_all_copies_clean`, `not_all_agents_corrected`.

## Checker invariants

The checker enforces:

- bundle schema/version/revision/digest stability;
- exact member-label set and stable ten-case coverage;
- identical case ids across every member table;
- accepted record top-level keys limited to `crossing_id`, `subject`, `route`, `admission`, `scope`, `outcome`, and `aftermath`;
- accepted subject digest equals external evidence digest;
- route family matches external evidence;
- route-specific non-promises are present;
- `visible_to_user` remains boolean rather than cognition proof;
- forbidden outcome classes such as `resolved`, `compliant`, `trusted`, and `global_truth` are not accepted;
- rejected candidates emit no crossing id and carry `no_crossing_record_emitted`;
- ambient truth, digest mismatch, global-resolution, and latest-wins scope-substitution fixtures still reject;
- global counts and non-promotion refusals remain intact.

## Non-promotion result

This proof slice closes F090 only as executable pressure. It does not freeze `CrossingRecord v0`, define a public JSON schema, import SlopOS internals, certify MCP annotations, establish browser credential identity truth, or create a public-copy status API. It proves that Harbor can require a small evidence bundle before promotion discussions continue.
