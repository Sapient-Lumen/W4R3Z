# Harbor revocation-overlay propagation bundle v0

The deterministic fixture `fixtures/harbor-revocation-overlay-propagation-bundle-v0.json`
is emitted by `tools/harbor_revocation_overlay_propagation_harness.py` and
checked by `tools/check_harbor_revocation_overlay_propagation_bundle.py`.

The bundle has thirty cases.  Ten accepted cases demonstrate scoped overlay
propagation for public copies, mirrors, generated summaries, consumer notices,
local indexes, warning cards, partial propagation, sealed summaries, stale
mirrors, and multi-cube incomparable overlays.  Twenty hostile cases are
refused when propagation evidence tries to become badges, compliance,
prior-falsity findings, mirror/global closure, source-digest-free summaries,
read/applied notice proof, search truth, sunset without scope, public truth
from sealed material, stale currentness, automatic repair, majority verdict,
single badge, global repair, history erasure, callback status, timestamp
freshness, or source-digest-free overlays.

## Member labels

- `overlay.source`
- `target.surface`
- `propagation.action`
- `visibility.render`
- `consumer.notice`
- `index.warning.state`
- `history.linkage`
- `verdict.summary`

## Non-promotions

This fixture is not a revocation propagation API, public badge workflow,
compliance workflow, prior-falsity judgment, global downstream repair proof,
notification guarantee, mirror/search truth plane, warning-card status engine,
or final SlopOS datacube shape.

## Audit/refactor

Rev0109 adds `tools/harbor_bundle_common.py` and
`tools/check_harbor_bundle_common_audit.py`.  The helper exists to reduce
checker drift.  It does not make old bundles conformant and does not make new
bundles authoritative.
