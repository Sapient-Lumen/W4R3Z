# Harbor transparency/provenance receipt bundle v0

**Revision:** `rev0096`  
**Status:** deterministic F091 fixture contract; not a schema, conformance suite, transparency-log reliance policy, C2PA verifier profile, in-toto/SLSA predicate profile, SCITT profile, timestamp authority policy, redaction proof format, issuer-reputation model, legal status workflow, or final SlopOS datacube shape.

## Location

Fixture:

```text
fixtures/harbor-transparency-provenance-receipt-bundle-v0.json
```

Emitter:

```text
tools/harbor_transparency_receipt_harness.py --emit-bundle
```

Checker:

```text
tools/check_harbor_transparency_receipt_bundle.py
```

## Bundle members

The bundle has stable member labels:

```text
case.matrix
input.receipt_evidence
input.import_record
binding.analysis
currentness.analysis
output.admission
output.aftermath
verdict.summary
```

The order is checked. The case ids are checked. The whole bundle digest is checked.

## Accepted cases

The eight accepted cases are deliberately narrow:

- `accept-scitt-inclusion-scoped` — admits signed-statement inclusion only with statement-truth/currentness/policy/issuer non-promises.
- `accept-c2pa-manifest-binding` — admits content-credential manifest binding only with real-world/editorial/transform/trust-signal non-promises.
- `accept-intoto-slsa-subject-materials` — admits subject/materials provenance only with build/dependency/deployment/vulnerability non-promises.
- `accept-rekor-ct-inclusion-currentness-split` — admits inclusion/currentness only for a named checkpoint, not semantic approval.
- `accept-timestamp-anchor-only` — admits timestamp anchor only as message-imprint time evidence, not event time.
- `accept-redacted-derived-proof-claims` — admits selected claims only, not full evidence.
- `accept-issuer-compromise-advisory-recheck` — admits compromise notice as recheck requirement, not automatic deletion or automatic trust.
- `accept-verifier-policy-decision-epoch` — admits verifier result only for named inputs and policy epoch.

## Rejected cases

The six rejected cases block:

- subject digest mismatch;
- inclusion becoming a `trusted` outcome;
- log inclusion becoming fresh-now currentness;
- hidden issuer-compromise posture;
- redacted proof becoming full evidence;
- newer receipt widening scope by being latest.

Rejected candidates emit no import record id. They remain rejection residue only.

## Checker guarantees

The checker enforces:

- schema, version, revision, purpose, member labels, case count, and bundle digest;
- import-record top-level key stability for accepted cases;
- subject digest binding to receipt evidence;
- receipt-family non-promises;
- verifier decisions marked as not semantic truth;
- allowed binding/currentness verdicts;
- rejection residue for hostile candidates;
- no durable receipt-import schema, log reliance policy, verifier profile, or global truth/freshness semantics.

## Non-promotion rule

A receipt-rich system can make a bad Harbor artifact look mature too early. Therefore this bundle is allowed to harden as a test artifact while the vocabulary remains embryo-stage. A future promotion must still show repeated specimens, companion pressure, and real handoff needs.
