# Harbor derivative repair retention/expiry bundle v0

`harbor-derivative-repair-retention-expiry-bundle-v0.json` is a deterministic proof slice for F100. It is not a schema, conformance suite, records-management system, legal-hold workflow, privacy-erasure API, retention schedule registry, evidence-vault format, consumer cache API, compliance workflow, or final SlopOS datacube shape.

## Members

1. `retention.matrix` — candidate id, class, expected outcome, and row digest.
2. `evidence.subject` — source revision/archive, derivative repair bundle digest, repaired derivative digest, receipt digest, acknowledgement digest, and subject-scope non-promises.
3. `retention.policy` — policy basis, window, compaction permission, subject-scope match, and retention/truth separation.
4. `expiry.clock` — observed, expiry, evaluated, clock-basis, and expired-at-evaluation posture.
5. `retention.action` — raw-retention, tombstone, compaction, pruning, deletion, privacy minimization, migration, and warning-residue posture.
6. `recheck.receipt` — whether a recheck was performed or merely scheduled, later source-correction digest, result, and compliance non-promise.
7. `exception.hold` — legal-hold-like and reviewer-waiver exceptions, expiry, release, and status non-promotion posture.
8. `verdict.summary` — accepted/refused class, failure reasons, current-repair permission, recheck requirement, warning residue, and non-promises.

## Accepted cases

- active repair receipt inside retention window;
- expired repair receipt retained with recheck required;
- compacted tombstone with digest pointers;
- legal-hold-like preservation that does not claim freshness;
- prior repair superseded by a later source correction;
- quarantine evidence retained after material pruning;
- raw evidence pruned to digest-pointer-only residue;
- recurrence after expiry reopening warning residue;
- privacy-minimized tombstone retained;
- reviewer waiver note with explicit expiry.

## Hostile cases

The checker rejects expired receipts as current repair, retention policy as repair extension, hold as freshness, compaction digest as full evidence, deletion as repair, ignored later source corrections, scheduled rechecks as passed rechecks, pruned evidence as verified success, quarantine expiry as repair, expired acknowledgements as current, hold-release warning loss, missing clock basis, wrong-scope retention windows, tombstones without subject digest, privacy minimization as proof of no stale copies, and evidence migration without a map.

## Non-promotions

The bundle explicitly keeps retention/expiry evidence smaller than records management, legal holds, privacy erasure, retention schedule registries, evidence vaults, consumer cache APIs, compliance workflows, and the final SlopOS datacube shape.
