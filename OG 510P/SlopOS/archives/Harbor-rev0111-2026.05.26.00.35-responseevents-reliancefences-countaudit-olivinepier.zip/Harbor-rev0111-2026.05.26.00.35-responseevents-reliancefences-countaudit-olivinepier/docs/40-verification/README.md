# Verification surfaces

This directory holds small executable or semi-executable proof slices for Harbor. A verification surface may introduce deterministic fixtures, harnesses, or checkers, but it must not promote a durable schema merely by being machine-checkable.

Current surfaces:

- [`harbor-crossing-record-evidence-bundle-v0.md`](harbor-crossing-record-evidence-bundle-v0.md) — F090 CrossingRecord evidence bundle contract.
- [`harbor-transparency-provenance-receipt-bundle-v0.md`](harbor-transparency-provenance-receipt-bundle-v0.md) — F091 transparency/provenance receipt import bundle contract.
- [`harbor-verifier-disagreement-policy-epoch-bundle-v0.md`](harbor-verifier-disagreement-policy-epoch-bundle-v0.md) — F092 verifier disagreement / policy epoch drift bundle contract.
- [`harbor-property-mutation-coverage-bundle-v0.md`](harbor-property-mutation-coverage-bundle-v0.md) — F093 property/mutation coverage bundle contract.
- [`harbor-mutation-triage-bundle-v0.md`](harbor-mutation-triage-bundle-v0.md) — F094 mutation triage bundle contract.
- [`harbor-checker-provenance-bundle-v0.md`](harbor-checker-provenance-bundle-v0.md) — F095 checker provenance bundle contract.
- [`harbor-release-package-provenance-bundle-v0.md`](harbor-release-package-provenance-bundle-v0.md) — F096 release-package provenance bundle contract.
- [`harbor-artifact-handoff-consumer-import-bundle-v0.md`](harbor-artifact-handoff-consumer-import-bundle-v0.md) — F097 artifact handoff / consumer import bundle contract.
- [`harbor-post-import-local-derivation-drift-bundle-v0.md`](harbor-post-import-local-derivation-drift-bundle-v0.md) — F098 post-import local derivation drift bundle contract.
- [`harbor-derivative-correction-propagation-bundle-v0.md`](harbor-derivative-correction-propagation-bundle-v0.md) — F099 derivative correction propagation bundle contract.
- [`harbor-derivative-repair-retention-expiry-bundle-v0.md`](harbor-derivative-repair-retention-expiry-bundle-v0.md) — F100 derivative repair retention/expiry bundle contract.
- [`harbor-overlapping-correction-lineage-bundle-v0.md`](harbor-overlapping-correction-lineage-bundle-v0.md) — F101 overlapping correction-epoch lineage bundle contract.
- [`harbor-cross-cube-lineage-import-bundle-v0.md`](harbor-cross-cube-lineage-import-bundle-v0.md) — F102 cross-cube lineage import bundle contract.
- [`harbor-foreign-import-revocation-bundle-v0.md`](harbor-foreign-import-revocation-bundle-v0.md) — F103 foreign-import revocation/correction bundle contract.
- [`harbor-revocation-overlay-propagation-bundle-v0.md`](harbor-revocation-overlay-propagation-bundle-v0.md) — F104 revocation-overlay propagation bundle contract.
- [`harbor-user-visible-explanation-bundle-v0.md`](harbor-user-visible-explanation-bundle-v0.md) — F105 user-visible explanation bundles bundle contract.
- [`harbor-user-response-event-bundle-v0.md`](harbor-user-response-event-bundle-v0.md) — F106 user-response event capture bundle contract.

Audit surfaces:

- `check_harbor_bundle_common_audit.py` and `check_harbor_briefing_focus.py` are maintenance guards, not conformance status.
