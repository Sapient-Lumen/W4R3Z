# Harbor checker-provenance bundle v0

This verification surface belongs to F095.  It records evidence about the checker stack that produced the previous Harbor executable observations.

The bundle is deterministic and small.  It is not a durable schema, registry, CI status API, certification badge, or reliance workflow.

## Fixture

```text
fixtures/harbor-checker-provenance-bundle-v0.json
```

## Harness

```text
tools/harbor_checker_provenance_harness.py --write fixtures/harbor-checker-provenance-bundle-v0.json
```

The harness records:

- checker source digest;
- owning harness source digest;
- fixture file digest;
- fixture bundle digest;
- fixture schema/version/revision;
- checker invocation command;
- self-test stdout/stderr digest;
- guard-state receipt;
- reviewer override packet, if present.

## Checker

```text
tools/check_harbor_checker_provenance_bundle.py
```

The checker requires:

- exact schema/version/revision;
- exact member label order;
- stable case ids and gapless indexes;
- fixture equality with deterministic harness output;
- digest binding;
- all accepted cases to have passing self-tests, enabled guards, and current fixture/checker pairing;
- disabled-guard, stale-pairing, missing-selftest, and unscoped-override candidates to be rejected;
- non-promotion language for checker registries, CI status APIs, trust-root schemas, automated reliance workflows, certification badges, recursive self-attestation, and final SlopOS shape.

## Member labels

```text
checker.matrix
checker.provenance
fixture.pairing
guard.state
selftest.receipt
reviewer.override
verdict.summary
```

## Case classes

```text
current_checker_observation
disabled_guard_evidence
stale_fixture_checker_pairing
missing_selftest_receipt
scoped_reviewer_override_packet
unscoped_reviewer_override_attempt
```

## Non-promises

A passing checker-provenance bundle does not prove the checked subject bundle is true.  It only proves that this Harbor archive has retained enough local evidence about which checker, fixture, guard set, and invocation produced the current observation.
