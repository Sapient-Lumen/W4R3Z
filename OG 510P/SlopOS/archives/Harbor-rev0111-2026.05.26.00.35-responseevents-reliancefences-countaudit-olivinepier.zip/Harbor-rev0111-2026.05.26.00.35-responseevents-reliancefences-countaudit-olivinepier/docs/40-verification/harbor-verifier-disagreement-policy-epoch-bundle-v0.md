# Harbor verifier-disagreement policy-epoch bundle v0

**Revision:** `rev0097`  
**Status:** deterministic F092 fixture contract; not a schema, conformance suite, verifier arbitration policy, policy-drift ledger, public badge model, reliance API, compliance workflow, or final SlopOS datacube shape.

## Location

Fixture:

```text
fixtures/harbor-verifier-disagreement-policy-epoch-bundle-v0.json
```

Emitter:

```text
tools/harbor_verifier_disagreement_harness.py --emit-bundle
```

Checker:

```text
tools/check_harbor_verifier_disagreement_bundle.py
```

## Bundle members

The bundle has stable member labels:

```text
case.matrix
input.receipt_set
input.verifier_runs
input.disagreement_record
policy_epoch.analysis
disagreement.analysis
badge.analysis
output.admission
output.aftermath
verdict.summary
```

The order is checked. The case ids are checked. The whole bundle digest is checked.

## Accepted cases

The six accepted cases are deliberately narrow:

- `accept-split-accept-refuse-preserved` — preserves an accept/refuse split instead of choosing a green or red badge.
- `accept-currentness-unknown-withheld` — withholds a public badge when log/timestamp evidence exists but currentness is unknown.
- `accept-policy-updated-after-public-copy` — retains the prior public-copy basis while requiring recheck under a newer policy.
- `accept-issuer-status-after-timestamp-recheck` — treats issuer/key compromise after a timestamp as recheck pressure, not automatic truth/falsity.
- `accept-redacted-incomparable-review` — keeps sealed selected-claim review incomparable with public full-evidence review.
- `accept-scope-narrow-pass-global-refusal` — allows a visibly scoped local pass while refusing global/all-mirror/all-agent status.

## Rejected cases

The eight rejected cases block:

- one green badge from split verifier results;
- latest-policy retroactive erasure;
- stale/superseded policy claimed as current;
- one refusal becoming global failure;
- unknown currentness becoming fresh-now;
- issuer compromise becoming automatic falsehood;
- majority vote becoming authority;
- verifier run without policy digest supporting epoch comparison.

Rejected candidates emit no disagreement record id. They remain rejection residue only.

## Checker guarantees

The checker enforces:

- schema, version, revision, purpose, member labels, case count, and bundle digest;
- receipt digest stability and subject digest presence;
- verifier run policy id, policy digest, policy epoch, input digest, decision, currentness, no-semantic-truth bit, and run digest;
- accepted record top-level key stability;
- receipt/verifier digest preservation inside accepted records;
- allowed policy-epoch relations and badge postures;
- visible disagreement and majority/latest-wins refusal;
- unknown currentness cannot become freshness;
- public badge cannot become truth;
- non-promises for one-badge, majority, future-policy, retroactive-erasure, currentness, compliance, and issuer-status collapse;
- hostile mutation survival for the rejected cases.

## Non-promotion rule

Machine-checkable disagreement evidence is useful precisely because it prevents premature product semantics. A future promotion must still show repeated specimens, generated negative cases, companion pressure, and real handoff needs before Harbor may expose public badge semantics, arbitration APIs, reliance interfaces, or policy-drift ledgers.
