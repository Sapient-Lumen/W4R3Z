# Harbor artifact handoff / consumer import bundle v0

## Scope

This bundle supports F097. It is a deterministic fixture for handoff/import pressure only. It is not a consumer verification API, handoff attestation profile, package trust root, CI status API, artifact-security guarantee, file-library authority model, callback authority model, or durable schema.

## Members

The bundle has these ordered member maps:

1. `handoff.matrix`
2. `release.claim`
3. `transport.observation`
4. `material.identity`
5. `consumer.verification`
6. `scope.comparison`
7. `verdict.summary`

The checker requires all members to share the same case ids and order.

## Accepted pressure cases

- received release zip with computed digest under release-zip scope;
- extracted tree with archive index and manifest/revision match;
- copied fixture with parent bundle/checker context;
- renamed archive with matching bytes;
- portal/callback handoff followed by post-material verification;
- file-library upload followed by digest recheck.

## Rejected hostile cases

- filename-only match;
- pasted digest without material;
- renamed archive name used as identity;
- extracted tree missing archive index;
- copied fixture without parent bundle context;
- file-library upload timestamp used as freshness;
- portal callback success used as verification;
- release-zip digest applied to an extracted tree;
- downstream repack digest mismatch;
- hidden generated artifact added after extraction;
- consumer acknowledgement treated as reliance, security, compliance, or downstream state.

## Required non-promises

Every admitted case still says:

- no package trust root;
- no artifact security guarantee;
- no CI status;
- no global downstream copy state;
- no file-library authority;
- no callback authority.

The bundle uses a fixture-local reference digest to pressure the logic. The actual final release zip digest is still computed after packaging by the release-zip checker and is not predicted by this source fixture.
