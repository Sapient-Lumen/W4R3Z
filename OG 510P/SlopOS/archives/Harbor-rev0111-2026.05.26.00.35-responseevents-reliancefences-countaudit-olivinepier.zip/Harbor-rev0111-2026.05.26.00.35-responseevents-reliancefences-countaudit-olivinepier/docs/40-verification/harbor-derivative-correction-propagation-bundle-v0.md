# Harbor derivative correction propagation bundle v0

`harbor-derivative-correction-propagation-bundle-v0.json` is a deterministic proof slice for F099. It is not a schema, conformance suite, derivative invalidation ledger, consumer cache API, repair attestation profile, sync-state authority, notification protocol, compliance workflow, or SlopOS datacube shape.

## Members

1. `repair.matrix` — candidate id, class, expected outcome, and row digest.
2. `source.correction` — source correction id, prior/corrected source digests, delta digest, scope map, disputed branch, and correction non-promises.
3. `derivative.inventory` — derivative id/kind, prior digest, basis source digest, F098 bundle digest, label posture, and parent/child posture.
4. `propagation.notice` — route family, delivery observation, read/application separation, unreached surfaces, and delivery non-promises.
5. `invalidation.action` — quarantine, rebuild, revalidate, supersede, or notice-only action with corrected-source digest posture and output-check requirements.
6. `consumer.acknowledgement` — acknowledgement type, target digest, signer scope, repair/compliance overclaim bits, and acknowledgement non-promises.
7. `derivative.state` — repaired, superseded, quarantined, notice-only, partial/unknown, or refused-counterfeit local state.
8. `verdict.summary` — admitted/refused class, failure reasons, and non-promises.

## Accepted cases

- annotation repair note bound to the target digest;
- generated summary rebuilt from corrected source;
- local index invalidated and rebuilt;
- re-exported archive superseded with parent/child map;
- cached explanation expired and revalidated;
- cross-device sync repair verified by byte digest;
- stale consumer copy quarantined as unreached;
- local patch reconciled while kept as a local delta;
- partial propagation that preserves unknown surfaces;
- notice received and acknowledged, explicitly not repaired.

## Hostile cases

The checker rejects notice acknowledgement as repair, broadcast delivery as all derivatives reached, index invalidation as search-currentness, rebuilt summary without corrected-source digest, cache refresh without source revalidation, sync-provider green as digest verification, local patch warning-label loss, silent stale-copy supersession as current, consumer repair acknowledgement as compliance, repair acknowledgement with the wrong derivative digest, re-export parent identity overwrite, notification delivery as read/applied, latest correction as winner without scope map, global closure when a neighbor derivative remains stale, unreachable device assumed repaired after expiry, and acknowledgement signer as source authority.

## Non-promotions

The bundle explicitly keeps derivative repair evidence smaller than a derivative invalidation ledger, consumer cache API, repair attestation profile, sync-state authority, notification delivery guarantee, compliance workflow, or final SlopOS datacube shape.
