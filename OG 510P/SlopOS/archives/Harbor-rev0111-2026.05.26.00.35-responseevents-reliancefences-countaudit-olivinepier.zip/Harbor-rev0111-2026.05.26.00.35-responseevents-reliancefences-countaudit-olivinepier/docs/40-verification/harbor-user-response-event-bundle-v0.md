# Harbor user-response event bundle v0

This bundle verifies F106 user response-event capture after F105 explanation cards.  It is a deterministic proof slice, not a schema, event API, consent system, reliance ledger, analytics product, identity registry, compliance workflow, or final SlopOS datacube shape.

## Members

Each row contains these labeled members:

1. `explanation.input` — parent explanation bundle/case/digest, surface, clock, stale flag, and source non-promises.
2. `response.event` — event kind, event text, event clock, pseudonymous actor posture, agent/delivery flags, and event digest.
3. `capture.context` — surface/affordance, instrumentation posture, scope-map carry-forward, localization widening flag, undo/escape posture, and capture digest.
4. `interpretation.guard` — flags for comprehension, consent, reliance, repair, compliance, all-recipient read, permission, recheck-passed, and currentness overclaims.
5. `followup.action` — allowed next actions and whether a result, appeal outcome, reliance, undo, or repair has actually been observed.
6. `privacy.retention` — minimization, actor reference kind, raw identifier posture, retention expiry, consent-record attempts, analytics risk, and privacy digest.
7. `history.trace` — parent explanation bundle digest, parent case, prior overlay reference, stale-response posture, and history digest.
8. `verdict.summary` — accepted/refused class, failure reasons, claim allowances, flags, and non-promises.

The row digest is the canonical digest of those member labels only.  The bundle digest covers schema, version, revision, member labels, prior F105 digest, helper/registry digests, cases, audit/refactor note, and global posture.

## Accepted examples

Accepted rows include inspection, pending recheck request, scope-note export, dismissal without acceptance, appeal start without outcome, share-link copy with unknown recipients, acknowledgement without understanding, focus without read, localized acknowledgement with bound scope, denied sealed-detail request, agent follow-up with caveats, notice opt-out without repair, partial batch acknowledgement, and automated retry without human reliance.

## Rejected examples

Rejected rows include click-as-comprehension, checkbox-as-consent, export-as-reliance, dismiss-as-acceptance, appeal-as-repair, share-as-all-read, acknowledgement-as-compliance, scroll/focus-as-understanding, localized scope widening, sealed request as permission, recheck request as passed, delivery as user action, missing parent explanation digest, re-identifying analytics, stale response as currentness, agent acknowledgement as user consent, irreversible action without undo, unbounded retention, and retry-as-repair.

## Checker obligations

`tools/check_harbor_user_response_event_bundle.py` verifies:

- schema, version, revision, member labels, parent F105 digest, helper digest, registry digest, and bundle digest;
- row digest integrity;
- parent explanation digest presence for accepted cases;
- digest string shape for event, capture, guard, follow-up, privacy, and history members;
- accepted/rejected case counts and order;
- all claim allowances remain false;
- accepted cases preserve minimization, expiry, scope maps, undo/escape, parent explanation, and non-promotion;
- rejected cases expose exactly one named failure reason.

The checker is intentionally small.  It is not a production telemetry validator, user-consent profile, or UX conformance suite.
