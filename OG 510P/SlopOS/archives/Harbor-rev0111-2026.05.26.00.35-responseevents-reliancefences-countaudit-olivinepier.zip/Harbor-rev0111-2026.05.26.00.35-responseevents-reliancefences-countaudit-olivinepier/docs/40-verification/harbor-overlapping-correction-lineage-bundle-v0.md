# Harbor overlapping correction-epoch lineage bundle v0

`harbor-overlapping-correction-lineage-bundle-v0.json` is a deterministic proof slice for F101. It is not a schema, conformance suite, correction-epoch registry, derivative repair ledger, conflict-resolution engine, source-owner closure authority, public badge workflow, consumer cache API, compliance workflow, or SlopOS datacube shape.

## Members

1. `lineage.matrix` — candidate id, class, expected outcome, and row digest.
2. `source.epoch` — source material digest, retained-history bundle digest, correction epochs, epoch edges, clock basis, rollback/dispute/parallel/cycle posture, and epoch non-promises.
3. `derivative.lineage` — derivative id, lineage edges, epoch-specific digests, current candidate digest, digest-reuse and cycle posture, and lineage non-promises.
4. `repair.action` — action class, base/target epoch, scope map, delta map, rebase map, rollback recheck, retention cut, acknowledgement epoch, and repair-attestation refusal.
5. `scope.reconciliation` — overlap/disjoint/partial/conflict/parallel/unknown relation, scope-map digest, latest-wins, field-widening, whole-artifact, and single-badge guards.
6. `currentness.window` — evaluation clock, epoch-A and epoch-B status, retention cut, recheck requirement, and old-receipt refusal.
7. `consumer.state` — scoped or mixed consumer state, public badge posture, warning-history preservation, acknowledgement epoch, source-owner closure attempt, and compliance/all-current refusals.
8. `verdict.summary` — admitted/refused class, failure reasons, current scope, recheck requirement, history preservation, and non-promises.

## Accepted cases

- linear epoch chain repaired to latest named scope;
- epoch-A repair retained as history after epoch B;
- disjoint corrections coexisting without latest-wins;
- overlapping corrections split by derivative scope;
- rollback reopening prior repair while preserving intermediate history;
- partial derivative subset repaired under epoch B while others remain epoch-A history;
- consumer patch rebased onto epoch B with a delta map;
- stale epoch-A acknowledgement preserved as residue;
- conflicting external epoch marked as dispute/recheck-required;
- epoch B superseding only named fields.

## Hostile cases

The checker rejects latest-epoch-wins without overlap maps, stale epoch-A currentness, rollback history erasure, false conflict for disjoint scopes, overlap merge without delta map, wrong-epoch patch base, acknowledgement epoch mismatch, derivative digest reuse, clockless epoch order, total-ordering of parallel epochs, field-to-artifact widening, stale subset global-current claims, dispute-as-repair, source-owner closure override, retention-expiry ignored, global green badge across mixed epochs, rollback without recheck, and lineage cycles.

## Non-promotions

The bundle keeps correction epochs smaller than registries, repair ledgers, badge workflows, conflict-resolution engines, source-owner closure authority, consumer cache APIs, compliance workflows, and the final SlopOS datacube shape.
