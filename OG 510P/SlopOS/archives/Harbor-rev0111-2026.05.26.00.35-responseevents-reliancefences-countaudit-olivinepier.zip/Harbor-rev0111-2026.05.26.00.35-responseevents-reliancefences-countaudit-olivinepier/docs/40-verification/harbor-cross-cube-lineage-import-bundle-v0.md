# Harbor cross-cube lineage import bundle v0

`harbor-cross-cube-lineage-import-bundle-v0.json` is a deterministic proof slice for F102. It is not a schema, conformance suite, companion trust root, cross-cube status API, conflict-resolution engine, compliance workflow, public badge workflow, repair-ledger import API, or SlopOS datacube shape.

## Members

1. `import.matrix` — case id, candidate class, imported cubes, expected outcome, and row digest.
2. `foreign.material` — cube name, revision, archive digest, fragment family, native status, safe Harbor use, material digest, parent-manifest posture, and material non-promises.
3. `local.observation` — import id, observation clock, transport surface, material recheck, local root digest, foreign fragment digests, and transport/callback/upload non-promises.
4. `scope.translation` — native scope, Harbor scope, relation, scope-map digest, scope-widening posture, semantic-supersession pressure, and badge pressure.
5. `authority.quarantine` — quarantine state, native status strings, allowed Harbor uses, inherited-status flags, and authority non-promises.
6. `lineage.bridge` — prior Harbor lineage bundle digest, foreign fragment digests, bridge digest, clock-map posture, sealed-evidence posture, and no-merge/no-majority posture.
7. `recheck.plan` — recheck requirement, stale/historical posture, repair/retention/warning subject-digest checks, and recheck non-promises.
8. `verdict.summary` — admitted/refused class, failure reasons, admitted scope, badge/compliance refusal, and non-promotions.

## Accepted cases

- SlopOS portal append history imported as ordering witness only;
- Foundry classification pin imported as label provenance only;
- Steward retry history imported as attempt history only;
- Schell retention context imported without deletion or repair claim;
- ViewFS volition card imported as consent evidence only;
- Ward delegation warrant imported as route or escalation evidence only;
- Helm repair trace imported with Harbor scope recheck;
- multi-cube conflicting fragments admitted as incomparable split;
- sealed foreign packet imported by digest with public-summary limit;
- stale companion revision imported as historical residue.

## Hostile cases

The checker rejects foreign green status inherited as Harbor status, replay availability as currentness, retention windows as repair, foreign warning states as public badges, companion revision as freshness, foreign scope widening, archive digest mismatch, copied fragments without parent manifests, cross-cube total order without clock maps, foreign policy majority vote, sealed evidence as public truth, foreign acknowledgement as consumer repair, callback success as authority, SlopOS append order as semantic supersession, Foundry classification pin as status truth, Steward retry exhaustion as compliance failure, Schell forgetting ledger as erasure proof, ViewFS volition card as consent outcome, Ward delegation warrant as authority transfer, and Helm repair trace as completed repair.

## Non-promotions

The bundle keeps cross-cube imports smaller than status inheritance, companion trust roots, compliance workflows, conflict-resolution engines, public badge workflows, consent/delegation authority transfer, repair-ledger import APIs, and the final SlopOS datacube shape.
