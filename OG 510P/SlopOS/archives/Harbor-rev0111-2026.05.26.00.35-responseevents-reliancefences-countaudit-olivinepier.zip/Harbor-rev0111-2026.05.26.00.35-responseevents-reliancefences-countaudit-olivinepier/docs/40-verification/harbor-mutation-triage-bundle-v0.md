# Harbor mutation triage bundle v0

**Introduced:** `rev0099` / F094.  
**Fixture:** `fixtures/harbor-mutation-triage-bundle-v0.json`  
**Harness:** `tools/harbor_mutation_triage_harness.py`  
**Checker:** `tools/check_harbor_mutation_triage_bundle.py`

## Contract

The bundle is a deterministic triage fixture over current Harbor executable checkers. It records what happens when mutation pressure produces unsafe survivor patterns, equivalent/cosmetic survivors, or checker-overstrict false-positive candidates.

The bundle is not a schema, not a mutation dashboard, not a coverage gate, and not a conformance suite.

## Member labels

```text
triage.matrix
baseline.digest
candidate.mutation
checker.observation
classification.packet
promotion.packet
corpus.pruning
verdict.summary
```

## Required guarantees

The checker requires:

- exact schema/version/revision identity;
- top-level digest binding;
- exact member-label ordering;
- seven deterministic triage cases;
- gapless case indexes;
- case ids aligned across all member tables;
- baseline digest linkage to the crossing, receipt, or disagreement bundle under test;
- current checker result recorded as killed or survived;
- unsafe survivor patterns killed by current checkers with no open unsafe gap;
- equivalent survivors explicitly marked equivalent, human-reviewed, and not auto-promoted;
- overstrict false-positive candidates killed only under an explicit canonicality decision;
- pruning decisions for every case;
- global refusal of mutation-score, dashboard, property-framework, conformance-suite, automatic-fixture-promotion, and final SlopOS-shape claims.

## Current cases

```text
triage-001-crossing-authority-phrase-guarded
triage-002-receipt-policy-id-truth-phrase-guarded
triage-003-disagreement-one-badge-phrase-guarded
triage-004-crossing-non-promise-order-equivalent
triage-005-receipt-none-wording-equivalent
triage-006-disagreement-safe-explanation-equivalent
triage-007-crossing-member-order-overstrict
```

## Refusal rules

The checker must reject the triage bundle if:

- an unsafe survivor remains open;
- a survivor is counted as harmless without an equivalence packet;
- a killed overstrict candidate lacks a canonicality decision;
- a generated hostile case is auto-promoted without human-review flags;
- global counters hide survived cases;
- the coverage claim stops refusing mutation-score or conformance meaning;
- the committed fixture differs from deterministic harness output.

## Why it exists

F093 answers whether current targeted mutants are killed. F094 answers what Harbor does with ambiguous mutation outcomes. It keeps mutation work reviewable and prevents three counterfeits:

```text
survived means emergency
killed means semantic truth
higher mutation count means better Harbor
```

The bundle is pressure evidence, not a quality badge.
