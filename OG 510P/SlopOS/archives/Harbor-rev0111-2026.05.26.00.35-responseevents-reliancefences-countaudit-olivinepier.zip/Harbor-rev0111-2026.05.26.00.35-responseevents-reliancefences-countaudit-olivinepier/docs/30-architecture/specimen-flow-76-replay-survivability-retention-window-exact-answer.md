# Specimen flow 76 — replay survivability, retention windows, frozen cuts, and exact-answer humility

Purpose: pressure-test `F076` without choosing a storage engine, replay service, archival policy, or final SlopOS datacube schema.

## Scenario
A consumer asks Harbor to reproduce the exact public callback cube slice that was published on `2026-05-13T21:40Z` for provider-family counts, callback outcome class, hour bucket, freshness label, and optional row-lineage drilldown.

Since publication:

- base rows were compacted into a newer optimized layout;
- old table snapshots crossed their normal time-travel retention window;
- a frozen answer packet for the originally published aggregate survived;
- a late correction withdrew one callback attempt key, but the tombstone evidence later expired from the compacted correction feed;
- the row-lineage sidecar expired earlier than the base aggregate retention window;
- the semantic export view definition survived, but the target assertion engine and policy epoch moved;
- the consumer asks for an **exact historical answer**, not a best-effort current rerun.

A naive system would rerun the current query, call the old view definition enough, fill lineage with blanks, or treat expired tombstones as no deletion. Harbor refuses that counterfeit.

## Candidate survivability rows

### RS-76-01 — replay after compaction
- class: `replay_after_compaction`
- original cut: `cut-callback-2026-05-13T21:40Z`
- maintenance event: file/layout compaction plus old-snapshot expiration
- retained artifacts: current optimized table, semantic view definition, publication receipt
- missing artifacts: old base snapshot for exact recompute
- verdict: `explainable_not_replayable` for recomputation from base rows
- anti-counterfeit warning: compaction may preserve current semantics while destroying the old recomputation path

Healthy behavior: Harbor refuses to call a current rerun the old answer. It can explain the maintenance history and point to the frozen answer packet if available.

### RS-76-02 — frozen cut / frozen answer survives
- class: `exact_frozen_answer_ready`
- frozen packet: `answerpack-callback-public-2026-05-13T21:40Z`
- retained packet contents:
  - answer digest and rendered aggregate;
  - source cut ids and policy/contract epoch;
  - query/view digest;
  - evidence-grade and exactness posture at publication time;
  - non-promises for lineage drilldown and future corrections;
- missing packet contents: raw rows and full row-lineage sidecar
- verdict: exact old published answer can be returned if current policy allows this consumer
- anti-counterfeit warning: frozen answer is not recomputation, not current truth, and not raw-row authority

Healthy behavior: Harbor can return “the exact answer Harbor published then,” clearly labeled as a frozen answer packet, while refusing fresh/current labels.

### RS-76-03 — late correction with expired tombstone evidence
- class: `expired_negative_evidence`
- correction event: one callback attempt key was withdrawn after the original publication
- tombstone retention: expired before this consumer request
- retained artifacts: restatement receipt says a withdrawal occurred; the underlying tombstone payload is gone
- replay consequence: old current-state lookup can no longer independently prove the withdrawn key from retained tombstone evidence
- verdict: `restated_successor_only` for corrected answer; `explainable_not_replayable` for tombstone-level proof
- anti-counterfeit warning: tombstone expiry is evidence loss, not proof that the event never existed

Healthy behavior: Harbor shows the restatement receipt and corrected successor answer if authorized, but refuses to fabricate tombstone-level replay proof.

### RS-76-04 — sidecar retention mismatch
- class: `sidecar_retention_mismatch`
- base aggregate evidence: frozen answer packet survives
- row-lineage sidecar: expired before the aggregate answer packet
- requested feature: lineage drilldown for rows behind the old aggregate
- verdict: `partial_replay_ready` for aggregate-only old answer; `unsafe_to_answer` for lineage drilldown
- anti-counterfeit warning: base aggregate survivability does not imply lineage survivability

Healthy behavior: Harbor returns the old aggregate only with a no-lineage-drilldown label, not blank lineage rows.

### RS-76-05 — view/query survives but runtime semantics moved
- class: `definition_survived_runtime_moved`
- retained artifacts: view SQL/digest and source-register entry
- moved artifacts: target engine version, assertion compiler target, and policy epoch
- exactness consequence: current engine may handle null, time zone, grouping, or rounding differently
- verdict: exact recompute unavailable unless the old runtime/dialect basis or certified equivalence proof is present
- anti-counterfeit warning: preserved query text is not preserved execution semantics

Healthy behavior: Harbor either uses the frozen answer packet, finds a certified old-runtime replay path, or downgrades to explainable-only.

### RS-76-06 — consumer asks for exact historical answer
- class: `exact_answer_request`
- consumer asks: “Give me the exact public cube answer from 2026-05-13T21:40Z, including lineage drilldown and freshness basis.”
- available answer modes:
  - exact frozen aggregate answer: yes, if current policy allows;
  - exact recompute from base rows: no;
  - lineage drilldown: no;
  - freshness basis at publication: yes as frozen evidence, not current freshness;
  - corrected successor answer: yes as restated successor if authorized;
- verdict: return frozen aggregate with labels, refuse lineage drilldown, offer corrected successor, and explain missing survivor set
- anti-counterfeit warning: exact old aggregate, current corrected answer, and explanation of lost replay proof must not collapse

Healthy behavior: Harbor gives the strongest honest answer mode and refuses the rest.

## Proof obligations exercised

| obligation | status in this specimen |
| --- | --- |
| PO-DC-002 time-axis proof | satisfied by separating original publication cut, current query time, correction time, and retention windows |
| PO-DC-008 history/restatement proof | satisfied for restatement successor and tombstone evidence loss |
| PO-DC-010 derived-artifact proof | satisfied by keeping view/query definition smaller than data and runtime semantics |
| PO-DC-011 sidecar optionality proof | satisfied by aggregate-vs-lineage survivor split |
| PO-NE-001 negative-class proof | satisfied for expired negative evidence and missing lineage sidecar |
| PO-NE-002 refusal-lifecycle proof | satisfied for bounded exact-answer refusal and safe alternative |
| PO-RS-001 survivor-set proof | satisfied by listing required/present/missing artifacts for each requested answer mode |
| PO-RS-002 answer-mode proof | satisfied by distinguishing exact recompute, exact frozen answer, partial replay, explanation-only, refusal, and restated successor |
| PO-RS-003 retention-mutation proof | satisfied by naming compaction, snapshot expiration, tombstone expiry, sidecar expiry, and policy/runtime drift |

## Adversarial checks

| counterfeit | expected Harbor response |
| --- | --- |
| rerun latest data and label it as old answer | reject; current state is not the old cut |
| preserved view SQL treated as exact replay | reject unless runtime/dialect/source cuts survive or equivalence is proven |
| expired tombstone treated as no delete | reject; evidence loss must be named |
| frozen old answer treated as current answer | reject; label as frozen historical publication |
| base aggregate packet used to enable row lineage | reject; sidecar survivor set is separate |
| emergency/fail-safe recoverability treated as queryable time travel | reject; recovery/access mode must be named |
| restated successor hidden behind old answer | reject; show restatement relation if authorized |
| exact-answer refusal shown as data absence | reject; refusal is about missing/inaccessible survivor set |

## Review copy examples

Consumer-visible bounded answer:

> Harbor can return the exact aggregate answer that was published for the requested cut, but cannot recompute it from base rows or provide the old row-lineage drilldown. The old base replay cut and lineage sidecar are no longer retained. A later correction exists; a corrected successor answer is available as a separate restated answer if your current policy allows it.

Operator-visible survivability packet:

```yaml
request_id: req-callback-historical-answer-2026-05-13-01
historical_question: callback_public_cube_slice
original_publication_cut: cut-callback-2026-05-13T21:40Z
requested_mode: exact_historical_answer_with_lineage
survivor_set_required:
  - base_table_snapshot_at_cut
  - query_view_digest
  - policy_contract_epoch
  - row_lineage_sidecar_at_cut
  - tombstone_delete_evidence_for_late_corrections
  - frozen_answer_packet
  - runtime_dialect_basis
survivor_set_present:
  - query_view_digest
  - policy_contract_epoch_summary
  - frozen_answer_packet
  - restatement_receipt_summary
survivor_set_missing_or_inaccessible:
  - base_table_snapshot_at_cut
  - row_lineage_sidecar_at_cut
  - tombstone_delete_payload_after_retention
  - certified_old_runtime_recompute_path
answer_modes:
  exact_recompute_ready: false
  exact_frozen_answer_ready: true
  partial_replay_ready: aggregate_only
  explainable_not_replayable: true
  restated_successor_only: true
  unsafe_to_answer: lineage_drilldown_and_tombstone_level_replay
consumer_message_class: bounded_historical_answer_with_refusals
non_promises:
  - frozen_answer_is_not_current_truth
  - explanation_is_not_exact_recompute
  - tombstone_expiry_is_not_no_history
  - missing_lineage_sidecar_is_not_missing_rows
followthrough:
  - define replay-evidence redaction and access-control pressure before exposing answer packs broadly
```

## Verdict
Replay-survivability vocabulary is useful as **answerability process residue**. It lets Harbor distinguish exact recompute, exact frozen answer, partial replay, explanation-only, refusal, and restated successor without choosing SlopOS's final datacube storage substrate.

This pass does **not** promote:

- a Harbor-wide replay service;
- a warehouse/lakehouse/event-log choice;
- a universal retention policy;
- a public historical-answer API;
- a frozen-answer packet schema;
- a backup/restore product;
- a sidecar registry;
- or durable Harbor datacube cards for replay survivability.

Followthrough `F076` is complete. The next pressure should focus on access and redaction for replay evidence: if exact answer packs, replay bundles, and survivor sets can contain sensitive data, Harbor needs to know which evidence can be shown to consumers, operators, auditors, or no one.
