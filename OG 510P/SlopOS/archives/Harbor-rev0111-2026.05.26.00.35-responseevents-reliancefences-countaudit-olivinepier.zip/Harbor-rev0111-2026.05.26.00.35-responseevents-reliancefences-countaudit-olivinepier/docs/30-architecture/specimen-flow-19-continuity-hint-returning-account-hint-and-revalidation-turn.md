# Specimen flow 19 — continuity hint, returning-account hint, and revalidation turn

Goal: let same-device or same-browser return paths feel smoother without pretending they exported a portable session, account binding, or durable local success.

## Scenario
A user previously signed in through a browser-mediated federation or OAuth detour on their laptop.
They return later on the same browser instance, and the browser or provider has some continuity material: perhaps a connected-account memory, perhaps a device-bound session key, perhaps both.
The system offers a one-tap or auto-reauth path, but it still re-checks issuer identity, exact redirect/return shape, and whether the provider currently considers the user signed in.
If that revalidation fails — because the user signed out, the account was disconnected, the browser instance changed, or the continuity material no longer matches — the truthful result is chooser, login, or refusal rather than counterfeit continuity.

## Proposed Harbor objects
1. **continuity hint**
   - bounded evidence that this crossing may be returning through the same local browser/device posture;
   - stronger than route folklore and weaker than portable session truth.

2. **returning-account hint**
   - modest indication that one provider/account relation may already be recognized in this browser/device context;
   - stronger than a generic login prompt and weaker than durable account binding.

3. **revalidation turn**
   - explicit local or provider check that continuity material still deserves use before adoption proceeds;
   - important because same-device comfort must remain smaller than exact origin, exact redirect, and current login truth.

4. **mismatch honesty**
   - typed aftermath for the case where continuity was expected but current reality says chooser, login, re-consent, or stop;
   - stronger than a silent restart and weaker than adopted success.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- same-device or same-browser return paths feel smoother than first-time crossings,
- continuity hardening reduces theft without exporting a portable session blob,
- provider/browser-local account memory exists but may be stale or disconnected,
- and the safest truthful result is revalidation or fallback instead of magical resumed success.

## Promotion rule
Do not promote `continuity hint`, `returning-account hint`, `revalidation turn`, or `mismatch honesty` unless they improve:
- one same-browser returning-federation specimen,
- one device-bound continuity specimen that stays smaller than session export,
- and one mismatch specimen where expected continuity degrades honestly to chooser, login, or refusal.
