# Specimen flow 96 — release-package provenance and bootstrap guards

## Pressure

Harbor now has several executable proof slices. That creates a new risk: the release archive could be treated as trustworthy merely because the source tree says it is trustworthy. F096 tests the package boundary itself.

## Scenario

A Harbor maintainer prepares `rev0101`. The source tree has a manifest, an archive index, deterministic package script, release fixture, and multiple checkers. A consumer receives a zip and asks whether the archive is the release.

Harbor must answer with bounded evidence:

- the source tree's manifest and archive index agree with the root and file inventory;
- the package script intends stable timestamps and sorted entry order;
- no prior release zip is embedded inside the repo tree;
- generated release surfaces are listed;
- the build environment is recorded as evidence, not portability proof;
- the final zip digest is checked after packaging, not embedded in the source fixture;
- the package record does not certify security, reproducibility, CI status, or trust-root status.

## Fixture cases

Accepted:

1. current release surfaces;
2. deterministic zip plan;
3. build-environment capture;
4. out-of-band verification receipt.

Rejected:

1. archive-index drift;
2. embedded release zip;
3. nondeterministic zip metadata;
4. stale release root name;
5. generated artifact unlisted;
6. bootstrap self-trust attempt;
7. attestation-as-security claim.

## Proof obligations exercised

- `PO-RP-001` release root and manifest identity proof;
- `PO-RP-002` archive index and file inventory proof;
- `PO-RP-003` deterministic zip plan proof;
- `PO-RP-004` build-environment capture proof;
- `PO-RP-005` bootstrap/out-of-band verification proof;
- `PO-RP-006` release-attestation and trust-root refusal proof.

## Non-promotions

This flow does not promote a release attestation profile, package trust root, reproducible-build claim, CI status API, archive signature guarantee, binary transparency log, build farm, notarization workflow, or final SlopOS datacube shape.

## Result

The source fixture and checker can say: this tree's package process has coherent, inspectable evidence. The emitted archive still needs an out-of-band zip check and digest observation after packaging.
