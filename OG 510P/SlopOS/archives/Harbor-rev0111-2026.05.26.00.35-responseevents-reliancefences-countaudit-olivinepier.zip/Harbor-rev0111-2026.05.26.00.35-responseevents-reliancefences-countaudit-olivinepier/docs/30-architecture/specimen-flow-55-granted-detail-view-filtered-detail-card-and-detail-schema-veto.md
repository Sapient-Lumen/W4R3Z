# Specimen flow 55 — granted-detail view, filtered-detail card, and detail-schema veto

Goal: let Harbor describe a crossing where a client submits structured `authorization_details`, receives a token response whose granted details are a filtered or enriched subset of what was requested, later encounters a receiver-scoped JWT or introspection view of those details, and still needs a typed bottom when a later detail object is malformed enough to trigger `invalid_authorization_details`.

## Scenario
A Harbor-hosted client first follows the previous specimen’s actionable authorization-detail offer and asks an authorization server for approval to initiate and confirm a specific payment.
The client submits an `authorization_details` array for a `payment_initiation`-style type plus a risk-acknowledgement object.

The authorization server approves only part of what was requested and returns a token response containing:
- an access token;
- `authorization_details` that represent the **granted-detail view** actually attached to that token; and
- an enriched field identifying the specific payer account or payment identifier chosen during consent.

Later, the payments resource server validates the token through a JWT audience-specific view or introspection response that includes:
- a **filtered-detail card** containing only the authorization details relevant to that receiver; and
- optional receiver-specific extension fields needed for request processing.

A later refresh or follow-on token request then sends a malformed authorization details object that:
- uses a known detail type,
- but includes an unknown field and a wrong-typed value for a required field.

The authorization server rejects that turn with `invalid_authorization_details`.

At this point Harbor must preserve five truths at once:
- the token response carried a **granted-detail view**, not durable entitlement truth;
- the RS later saw a **filtered-detail card**, not a universal authorization ledger;
- the enrichment step did not magically upgrade request JSON into one permanent schema family owned by Harbor;
- the refusal was a **detail-schema veto**, not evidence of wrong target, wrong account, or session teardown; and
- any metadata `schema` / `schema_uri` consulted to build or validate the object remained implementation guidance rather than Harbor’s permanent authorization language.

## Why Harbor needs a new specimen
Without this specimen, Harbor risks either:
1. treating the token response’s granted `authorization_details` as the one true durable entitlement object; or
2. flattening malformed-detail failures into generic invalid-token or invalid-target endings.

This specimen keeps the middle path: Harbor can tell the truth about what was granted, what this receiver got to see, and why the next malformed detail object bottomed out.

## Suggested Harbor handling
- Preserve a **granted-detail view** when the token response returns `authorization_details` actually assigned to the access token.
- Preserve a **filtered-detail card** when JWT or introspection-visible details are receiver-scoped, filtered, or extended.
- Preserve a **detail-schema veto** when the authorization server rejects malformed or unknown detail shapes.
- Keep requested detail objects, granted detail objects, receiver-visible detail objects, and schema-validation failures visibly separate even when one user journey touches all four.
- Treat metadata schemas and examples as construction or validation aids, not as Harbor-owned global type law.

## Anti-regrowth notes
- Do **not** let a token-response granted-detail view masquerade as durable entitlement or policy truth.
- Do **not** let a receiver-scoped filtered-detail card masquerade as a universal authorization ledger.
- Do **not** let `invalid_authorization_details` silently collapse into generic invalid-token, wrong-target, or session-failure language.
- Do **not** let schema metadata, human-readable descriptions, or examples silently become Harbor’s permanent authorization ontology.
