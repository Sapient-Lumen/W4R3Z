# Specimen flow 87 — external decision return, conflicting findings, sealed expiry, and local adoption

**Revision:** `rev0092`  
**Followthrough:** `F087`  
**Purpose:** pressure-test outside decision return after handoff: a source-owner response that partially accepts a challenge, an auditor finding that conflicts with a source-owner claim, a regulator-facing determination with sealed-only basis, an appeal outcome that changes public copy but not historical correction evidence, and an expired sealed finding before promoting external decision ingestion, finding-adoption notes, authority-precedence rules, sealed-finding expiry semantics, public-copy update rules, or compliance/status reconciliation.

## Scenario

Harbor has just completed specimen flow 86.

1. `catalog-alpha/export/claims-q1.csv` was escalated for repeated stale-copy regression.
2. `sc-generated-explainer-non-use-003` is still open because non-use could not be verified from public evidence.
3. A regulator-facing reviewer received sealed evidence for a rejected suppressed-cell-leak claim.
4. `mirror-beta/claims-q1-accessible-table.html` has a disputed sunset appeal.
5. The public log says `escalation_sent`; the status surface says `standing_challenge_open` for one target and `cooldown_active` for another.

`F087` adds five return complications:

1. The source owner partially accepts the challenge: it accepts that labels were stripped from one export, rejects that generated-explainer non-use is unverified, and proposes a recommended copy update.
2. The auditor finds the non-use claim unsupported for the stated window, conflicting with the source-owner reply.
3. The regulator-facing reviewer returns a sealed-only determination: no public evidence supports suppressed-cell leakage, but public copy must avoid implying that leakage was impossible.
4. The appeal outcome keeps `mirror-beta` in cooldown for one more export cycle, changes public wording, and preserves historical correction evidence.
5. The sealed finding has an expiry date; after expiry it can no longer support current public wording unless renewed.

## Actors

- Harbor maintainer reviewing outside responses.
- Catalog-alpha source owner.
- Auditor with access to sealed verifier packet.
- Regulator-facing reviewer with limited scope.
- External reporter who appealed the sunset.
- Public reader who sees only safe copy.
- Consumer who needs current-use guidance.

## Evidence packet

```text
source_artifact: pub-claims-2026q1-r5
public_successor_candidate: pub-claims-2026q1-r6-reviewwording
regressed_target: catalog-alpha/export/claims-q1.csv
standing_challenge: sc-generated-explainer-non-use-003
source_owner_response: so-catalog-alpha-response-2026-05-16
source_owner_claims:
  - accepts label_strip on CSV export
  - claims generated_explainer_non_use was true
  - recommends public wording update but does not accept audit finding
auditor_finding: aud-nonuse-unsupported-2026-05-16
regulator_facing_determination: reg-suppression-leak-sealed-review-2026-05-16
sealed_manifest_id: sem-suppression-check-2026q1-r5
sealed_finding_expiry: 2026-06-15T00:00:00Z
appeal_outcome: appeal-mirror-beta-sunset-001 partial_sustain
```

## Required checks

### 1. External finding return receipt

Harbor records the source-owner response as a scoped imported claim, not a repair.

```text
finding_id: so-catalog-alpha-response-2026-05-16
issuer_role: source_owner
subject: catalog-alpha/export/claims-q1.csv
authority_basis: owner of downstream public export, not source of Harbor proof
response_class: partial_finding
accepted: label_strip on CSV export
rejected: generated_explainer_non_use_unverified
proposed: recommended public wording update
open_basis: owner export logs summary
sealed_basis: none
expiry: 2026-06-16T00:00:00Z for current owner-log support
non_promises: not remediation, not non-use proof, not compliance, not bad-faith refutation
```

### 2. Scope normalization before conflict

Harbor compares the source-owner and auditor findings only after matching subject, time window, method, and evidence lane.

```text
normalization_note: norm-nonuse-003-auditor-vs-owner
claim_family: generated_explainer_non_use
subject: catalog-alpha generated explainer cache for claims-q1
window: 2026-05-01T00:00:00Z/2026-05-15T20:00:00Z
source_owner_method: owner log assertion summary
auditor_method: sealed access-log digest list + retrieval-index comparison
comparable_fields: non-use support for stated cache/index window
not_comparable_fields: owner intent, fault, harm, legal notice, unrelated exports
result: comparable for support/no-support only
```

### 3. Authority conflict map

The auditor finding conflicts with the source-owner claim on one scoped field only.

```text
conflict_map_id: acm-nonuse-003
conflicting_findings:
  - so-catalog-alpha-response-2026-05-16 says non_use_supported
  - aud-nonuse-unsupported-2026-05-16 says non_use_not_supported
local_status: finding_conflicts; Harbor adoption paused for non-use claim
safe_public_effect: keep standing challenge visible; do not say source owner lied or auditor proved use
next_action: request owner verifier packet or renewed auditor check
```

### 4. Regulator-facing sealed-only determination

The reviewer returns a scoped result that changes public wording without opening raw evidence.

```text
determination_id: reg-suppression-leak-sealed-review-2026-05-16
issuer_role: regulator_facing_reviewer
subject: reporter claim suppressed_cell_leaked for pub-claims-2026q1-r5
basis: sealed-only suppression-policy check and version/cut comparison
result: public claim unsupported; public copy must avoid implying impossible leakage
instruction_type: mandated within reviewer scope for Harbor public summary
allowed_public_result: unsupported public leak claim; sealed basis retained; do not disclose raw cells
not_meaning: legal compliance, universal no-leak proof, reporter bad faith, or public raw evidence release
expiry: 2026-06-15T00:00:00Z
```

### 5. Finding adoption note

Harbor adopts only the public-wording effect and refuses broader effects.

```text
adoption_note: adopt-reg-suppression-wording-2026-05-16
finding: reg-suppression-leak-sealed-review-2026-05-16
local_effect: update public summary wording and maintain sealed-evidence boundary
adopted_as: public wording correction with sealed-only basis
refused_effects:
  - no legal/compliance conclusion
  - no public disclosure of suppressed cells
  - no universal no-leak claim
  - no erasure of reporter dispute packet
recheck: renewal required before 2026-06-15T00:00:00Z for current reliance
```

### 6. Appeal outcome and public copy update

The sunset appeal is partially sustained.

```text
appeal_outcome_id: appeal-mirror-beta-sunset-001-outcome
outcome: partial_sustain
remedy: keep cooldown banner until next export cycle; narrow stale warning to accessible-table variant
public_copy_update: pub-claims-2026q1-r6-reviewwording
unchanged_history:
  - corr-2026q1-claims-label-restatement
  - old stale-use evidence for mirror-beta
  - escalation and appeal receipts
not_meaning: old warning deleted, mirror currently stale, or appeal fully validated
```

### 7. Sealed finding expiry

Harbor records that expiry changes current reliance, not history.

```text
sealed_finding_expiry_note: sfe-reg-suppression-leak-2026-06-15
sealed_finding: reg-suppression-leak-sealed-review-2026-05-16
current_support_until: 2026-06-15T00:00:00Z
on_expiry: public wording must say sealed review expired or must renew review
historical_effect: old finding remains historical evidence of what was reviewed then
not_meaning: finding false, reviewer wrong, leak proven, or evidence deleted
```

## Consumer-facing copy

```text
Use pub-claims-2026q1-r6-reviewwording for new analysis. Catalog-alpha acknowledged that a CSV export stripped release labels; Harbor has not adopted the source-owner non-use claim for the generated explainer because an auditor found the claim unsupported for the stated window. A regulator-facing sealed review found no public support for the suppressed-cell-leak claim, but Harbor has updated the public wording so it does not imply leakage was impossible. Mirror-beta remains in cooldown for one more export cycle after a partial sunset appeal. Sealed-review support for the suppression wording expires on 2026-06-15 unless renewed.
```

## Refusals

Harbor refuses to say:

- `source owner partially accepted the challenge, so the target is repaired`;
- `auditor found non-use unsupported, so the source owner lied or caused harm`;
- `regulator-facing sealed review proves universal compliance`;
- `sealed evidence should be public because it affected public copy`;
- `recommended and mandated corrections are the same`;
- `appeal sustained means old evidence was wrong or deleted`;
- `appeal denied means reporter bad faith`;
- `expired finding means false finding`;
- `historical finding means current support`;
- `transparency/log publication decides which outside finding wins`.

## Proof obligations exercised

- `PO-SE-001` through `PO-SE-007` from external escalation handoff hygiene.
- `PO-SR-001` through `PO-SR-006` from status reconciliation hygiene.
- `PO-DR-001` through `PO-DR-007` from external decision return hygiene.

## Outcome

`F087` is closed as a reversible pressure test.

No external decision ingestion schema, finding-adoption API, authority precedence hierarchy, source-owner/auditor/regulator trust ranking, legal/compliance workflow, appeal court, correction-implementation tracker, sealed finding protocol, transparency-log dependency, public status-page product, VEX/CSAF profile, in-toto predicate, SCITT receipt requirement, source-owner ticketing workflow, reputation model, enforcement ladder, or final SlopOS datacube shape is promoted.
