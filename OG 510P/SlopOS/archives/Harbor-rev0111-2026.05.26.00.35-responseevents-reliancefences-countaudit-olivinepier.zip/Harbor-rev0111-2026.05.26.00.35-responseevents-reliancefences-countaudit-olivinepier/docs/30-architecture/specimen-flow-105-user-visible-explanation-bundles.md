# Specimen flow 105 — user-visible explanation bundles

## Pressure

After a foreign revocation overlay reaches a public surface, Harbor still has to decide what a human sees. A status card, generated summary, localized variant, status message, search snippet, or consumer notice can be more dangerous than the overlay itself if it compresses uncertainty into a badge, closure phrase, compliance claim, legal finding, or repair button.

## Specimen

The specimen emits `harbor-user-visible-explanation-bundle-v0`, a deterministic bundle with accepted and rejected candidates across public copies, mirrors, generated summaries, consumer notices, local indexes, warning cards, sealed summaries, multi-cube cards, localized cards, status messages, problem-detail-like reason payloads, and action panels.

## Required member slices

- `overlay.input`
- `audience.context`
- `explanation.copy`
- `reason.code`
- `action.affordance`
- `access.localization`
- `history.trace`
- `verdict.summary`

## Accepted examples

- scoped public-copy explanation with source digest, scope, caveats, and visible history;
- stale mirror explanation with recheck path;
- generated summary that carries overlay basis without source equivalence;
- consumer notice that separates delivery from read/application/repair;
- local-index warning snippet that refuses search truth;
- warning card that preserves split state;
- sealed overlay public summary that does not disclose sealed details;
- mixed-cube explanation that keeps incomparable overlays separate;
- localized variant bound to source-language digest;
- accessible status message with text and programmatic label rather than color alone;
- machine reason code paired with user-facing text;
- inspect/recheck/export affordance without repair claim.

## Rejected examples

- badge-only display;
- red global-failure banner;
- closure language without scope;
- prior-falsehood or negligence claim;
- color-only indicator;
- missing scope map;
- missing source overlay digest;
- localized variant that widens scope;
- generated summary as source equivalent;
- delivery as read/application;
- global downstream repair action;
- hidden prior history;
- sealed detail disclosure;
- timestamp as currentness;
- machine-code-only user message;
- status message without programmatic label;
- translation without provenance;
- single sentence that collapses mixed overlays;
- confidence percentage as truth;
- legal advice language.

## Proof obligations exercised

This specimen exercises `PO-UX-001` through `PO-UX-006`.

## Non-promotions

No explanation API, public badge workflow, compliance workflow, legal-finding vocabulary, global repair workflow, notification-read guarantee, accessibility conformance claim, localization equivalence guarantee, or final SlopOS datacube shape is promoted.
