# Specimen flow 86 — external escalation handoff, appeal windows, and sealed evidence

**Revision:** `rev0091`  
**Followthrough:** `F086`  
**Purpose:** pressure-test standing challenges that need source-owner or auditor packets, external escalation with an appeal window, regulator-facing packets with sealed evidence, public-log/status-page divergence after escalation, and disputed sunset appeal before promoting external escalation handoffs, appeal windows, auditor/regulator packets, sealed-evidence transfer receipts, or public-log/status-page reconciliation rules.

## Scenario

Harbor has an active standing challenge from specimen flow 85:

1. `catalog-alpha/export/claims-q1.csv` regressed after prior repair.
2. The downstream owner acknowledged the new notice but did not provide verifier evidence.
3. The generated-explainer non-use claim remains unverifiable.
4. A stale warning for an older repaired mirror is a sunset candidate.
5. A public log still contains older signed `fixed` evidence, while the status surface says `standing challenge open`.

`F086` adds five complications:

1. The standing challenge needs a source-owner packet and an auditor packet because Harbor cannot verify the non-use claim with public evidence.
2. Harbor escalates the recurring stale-copy warning and opens a bounded appeal window for `catalog-alpha`.
3. A regulator-facing reviewer asks for sealed evidence proving that no suppressed cell was leaked in the reporter's claim.
4. A transparency-style public log records `escalation_sent`, while a public status page still says `cooldown_active` for one mirror and `standing_challenge_open` for another.
5. The external reporter appeals the warning sunset for the older mirror, claiming the target may regress again.

## Actors

- Harbor source owner.
- Downstream catalog owner / source owner for the mirror.
- External reporter.
- Auditor who can inspect sealed verifier evidence.
- Regulator-facing reviewer with limited scope.
- Public reader who sees only safe summary copy.
- Consumer who needs current-use guidance.

## Evidence packet

```text
standing_challenge: sc-generated-explainer-non-use-003
source_artifact: pub-claims-2026q1-r5
correction_anchor: corr-2026q1-claims-label-restatement
regressed_target: catalog-alpha/export/claims-q1.csv
older_sunset_candidate: mirror-beta/claims-q1-accessible-table.html
public_log_entry: log-entry-52a escalation_sent for catalog-alpha/export
status_surface_current: standing_challenge_open for catalog-alpha; cooldown_active for mirror-beta
sealed_packet: sealed-agg-disclosure-check-2026q1-r5
sealed_packet_digest: sha256:sealed-packet-digest
redaction_map_digest: sha256:redaction-map-digest
appeal_window: 2026-05-15T20:00:00Z/2026-05-22T20:00:00Z
```

## Required checks

### 1. Standing challenge handoff packet

Harbor builds two packets from the same challenge, not one universal truth bundle.

```text
packet_id: handoff-sc-nonuse-003-source-owner
recipient_class: source_owner
subject: generated_explainer_non_use for catalog-alpha
open_section: challenge id, artifact ids, missing evidence list, requested verifier packet
sealed_section: none
public_safe_section: non-use claim remains unverified
requested_action: provide retrieval-index version, cache invalidation receipt, access-log window, dependency lock, and authority statement
non_promises: no assumption of use, no assumption of non-use, no source-owner fault
```

```text
packet_id: handoff-sc-nonuse-003-auditor
recipient_class: auditor
subject: generated_explainer_non_use for catalog-alpha
open_section: challenge id, target scope, requested verifier operations
sealed_section: access-log digest list and retrieval-index comparison under handling label
requested_action: verify whether the non-use claim is supported for the stated window
non_promises: auditor review is scoped to this claim family and window only
```

### 2. External escalation receipt with appeal window

Harbor escalates the recurring stale-copy warning but does not pretend escalation is enforcement.

```text
escalation_id: esc-catalog-alpha-regression-001
subject: catalog-alpha/export/claims-q1.csv
reason: repeated stale-copy regression after prior repair
recipient: catalog-alpha source owner
status: handoff_sent
appeal_window: open
appeal_deadline: 2026-05-22T20:00:00Z
stay_posture: no automatic stay; public warning remains active for new-use guidance
requested_remedy_if_appealed: identify scope mismatch, provide clean revalidation, or provide verifier packet
unsupported: accepted review, agreement, repair, bad faith, legal notice, compliance finding
```

### 3. Sealed evidence transfer manifest

The regulator-facing reviewer receives sealed evidence to assess the rejected suppressed-cell-leak report.

```text
sealed_manifest_id: sem-suppression-check-2026q1-r5
recipient_class: regulator_facing_reviewer
subject: reporter claim suppressed_cell_leaked
open_fields: artifact ids, release labels, public claim under review, public refusal copy
sealed_fields: suppressed-cell contributor checks, raw differencing worksheet, reviewer notes
handling_label: restricted reviewer packet; no redistribution without source permission
allowed_operations: digest match, suppression-policy check, version/cut comparison, public-summary approval
expiry: 2026-06-15T00:00:00Z
public_result_allowed: confirmed, rejected, cannot assess, or unsafe to disclose basis
non_promises: no public raw cells, no universal compliance decision, no unrelated artifact review
```

### 4. Source-owner and auditor response receipts

Responses remain scoped.

```text
source_owner_response: acknowledged + asks for extension
meaning: cooperation and requested extension only
not_meaning: repair, non-use, accepted fault, or successful appeal
```

```text
auditor_response: accepted_for_review
meaning: auditor can inspect sealed/open packet under handling label
not_meaning: non-use verified or claim resolved
```

### 5. Public-log/status-page divergence after escalation

Harbor records that different surfaces are now true for different scopes.

```text
public_log: escalation_sent for catalog-alpha/export at 2026-05-15T20:05:00Z
status_page: standing_challenge_open for catalog-alpha/export; cooldown_active for mirror-beta
current_proof_packet: escalation sent; no external finding yet
safe_statement: Escalation has been sent for catalog-alpha. Review is not complete. Mirror-beta remains in cooldown; its warning is not yet sunset.
```

### 6. Disputed sunset appeal

The reporter appeals the sunset candidate for `mirror-beta`.

```text
appeal_id: appeal-mirror-beta-sunset-001
challenged_decision: move old mirror-beta warning to historical-only after clean windows
challenger: external reporter
standing_basis: reporter supplied prior stale-copy evidence for this mirror family
grounds: possible recurrence after old cache rebuild
remedy_sought: keep active warning until next export cycle
window_status: received within window
stay_posture: partial stay; keep cooldown banner visible until next export-cycle recheck
required_evidence: current stale observation, cache/export rebuild proof, or digest mismatch
non_promises: warning is not deleted; appeal does not prove current staleness
```

## Consumer-facing copy

```text
Use Harbor public copy pub-claims-2026q1-r5 for new analysis.
Harbor has escalated the catalog-alpha stale-copy regression to the source owner and opened a bounded appeal window. The generated-explainer non-use claim remains under standing challenge pending verifier evidence. A sealed reviewer packet exists for the suppressed-cell-leak claim; public evidence still does not support that leak. Mirror-beta is in cooldown, but its sunset has been appealed, so its warning remains visible until the next recheck.
```

## Refusals

Harbor refuses to say:

- `escalation means the source owner accepted fault`;
- `appeal means the warning is invalid`;
- `no appeal means the warning was proven correct`;
- `sealed evidence proves the public claim` before a verifier result exists;
- `regulator-facing packet means legal compliance or noncompliance`;
- `auditor accepted review means auditor verified the claim`;
- `public log inclusion is current truth`;
- `status-page cooldown overrides logged escalation`;
- `sunset appeal deletes or restores history`;
- `source-owner acknowledgement is remediation`.

## Proof obligations exercised

- `PO-RE-001` through `PO-RE-006` from recurrence/escalation hygiene.
- `PO-SR-001` through `PO-SR-006` from status reconciliation.
- `PO-SE-001` through `PO-SE-007` from external escalation handoff hygiene.

## Outcome

`F086` is closed as a reversible pressure test.

No external escalation handoff schema, appeal-window API, source-owner ticketing workflow, regulator/auditor packet format, sealed-evidence transfer protocol, public status-page product, transparency-log policy, legal/compliance workflow, incident-response program, CVD/PSIRT/CSIRT operating model, VEX/CSAF profile, in-toto predicate, SCITT receipt dependency, reporter/source-owner reputation model, enforcement ladder, or final SlopOS datacube shape is promoted.
