# Specimen flow 80 — public-copy localization, accessible render variants, and summary tether honesty

**Status:** specimen for `F080`; design-phase rehearsal only.

## Setup

Source release, inherited from the public-copy hygiene pass:

- `public_artifact_id`: `pub-callback-route-week-2026-05-13-r2`
- `source_cut`: `cut-callback-2026-05-13T22:00Z`
- `payload_digest`: `sha256:payload-callback-route-week-r2-example`
- `label_digest`: `sha256:labels-callback-route-week-r2-example`
- carried labels: `disclosure_treated`, `not_exact_public_copy`, `coarsened_for_disclosure`, `suppressed_cells_present`, `perturbed_release`, `not_a_dp_claim`, `additivity_weakened`, `structural_zero_labels_present`, `do_not_recompose_with=provider-excluded-sibling`

The specimen asks whether human-friendly variants can remain useful without becoming a second truth source.

## Candidate cases

| Case | Candidate variant | Review question | Verdict |
| --- | --- | --- | --- |
| RV-80-01 | `fr-CA` translated label set preserves all machine label IDs and translates explanatory strings | Did non-promises survive translation? | valid translated label set; still not source truth |
| RV-80-02 | Spanish copy translates `not_exact_public_copy` as “not current data” | Did translation change the caveat? | invalid until repaired; caveat meaning drifted |
| RV-80-03 | `ratio_unity=0.125` displays as `12.5%` in `en-US` and `12,5 %` in `fr-FR` | Are canonical value and display basis both visible? | valid display-only locale receipt |
| RV-80-04 | Duration `1250 ms` displays as `1.25 s` with source unit, canonical unit, rounding, and display-only flag | Did unit formatting become conversion authority? | valid locale/unit receipt; not a measurement rewrite |
| RV-80-05 | SVG chart includes title, short description, long description, source-data table, labels, and source link | Can a non-visual reviewer recover the same release posture? | valid accessible render variant |
| RV-80-06 | Chart-only image has alt text “route volume chart” and no table or long description | Are the data and caveats reachable? | not proof-grade; explanatory thumbnail only |
| RV-80-07 | Mobile renderer folds low-frequency rows into “Other” and sorts by localized label | Did grouping/sort change inferable meaning? | valid only with render-transform note and recomposition review |
| RV-80-08 | Plain-language summary says “callback detours were lower this week” but omits suppression/noise/exactness labels | Is the summary proof-grade? | explanatory-only with summary tether; not a public data copy |
| RV-80-09 | Arabic render preserves machine IDs but lacks text direction isolation around LTR label IDs | Did visual order corrupt labels? | repair needed; IDs preserved but not safely readable |
| RV-80-10 | Downstream dashboard reorders rows by client locale and hides suppressed rows by default | Did renderer drift strip public-copy warnings? | invalid until transform and hidden-row posture are disclosed |

## Counterfeit matrix

| Counterfeit | Why it is tempting | Required Harbor response |
| --- | --- | --- |
| “Translated means equivalent.” | The numbers match. | Require machine IDs, non-promises, and glossary review. |
| “Localized percent is a new value.” | Display looks numeric. | Preserve unity-ratio basis and display-only flag. |
| “Accessible table is just UX.” | It lives in the render layer. | Treat it as evidence-bearing because it can omit labels or data. |
| “Plain summary is safer than labels.” | It is easier to understand. | Mark explanatory-only unless proof labels survive. |
| “Renderer sorting is harmless.” | It changes order, not cells. | Declare sort/collation because rank/top/bottom meaning can change. |
| “Screen-reader-only table proves equivalence.” | It contains numbers. | Check headers, captions, source link, labels, and transform posture. |
| “Stale localized copy is fine.” | It is only text. | Link to restatement or refuse current-proof status. |

## Example receipt sketch

```yaml
render_variant: pub-callback-route-week-2026-05-13-r2.fr-CA.accessible-table.v1
source_public_artifact: pub-callback-route-week-2026-05-13-r2
source_cut: cut-callback-2026-05-13T22:00Z
payload_digest: sha256:payload-callback-route-week-r2-example
label_digest: sha256:labels-callback-route-week-r2-example
release_labels_preserved:
  - disclosure_treated
  - not_exact_public_copy
  - coarsened_for_disclosure
  - suppressed_cells_present
  - perturbed_release
  - not_a_dp_claim
  - additivity_weakened
  - structural_zero_labels_present
  - do_not_recompose_with=provider-excluded-sibling
locale_receipt:
  locale: fr-CA
  numbering_system: latn
  unit_display: long
  percent_display: localized_percent_from_unity_ratio
  canonical_values_unchanged: true
  fallback_used: false
translation_receipt:
  label_ids_preserved: true
  translated_strings_reviewed: true
  machine_translation_used: false
  unresolved_terms: []
accessibility_receipt:
  table_caption_present: true
  table_headers_bound: true
  chart_short_description: present
  chart_long_description: present
  screen_reader_table: present
  source_data_link: present
  color_only_meaning: false
render_transform:
  sort: localized_label_ascending
  collation: fr-CA-default
  grouping: none
  filters: none
  top_n: none
  values_changed: false
  hidden_rows: none
human_summary:
  present: true
  tethered_to_label_digest: true
  omitted_machine_labels: false
  proof_grade: false
verdict: valid_render_variant_not_source_truth
non_promises:
  - not_a_new_public_artifact
  - not_a_translation_framework
  - not_a_wcag_conformance_claim
  - not_a_renderer_api
```

## Consumer-facing refusal copy

> This rendering is a human-readable variant of a labeled public copy, not the proof-grade bundle. It currently omits or changes release labels that are required to interpret suppression, perturbation, exactness, or recomposition posture. Use the labeled bundle, or repair the variant before treating it as a public data copy.

## What the specimen proves

This specimen is enough to close `F080` because it shows localized labels, locale number/unit display, accessible chart/table alternatives, human-readable summaries, and renderer sorting/grouping can all be reviewed without promoting them into canonical datacube schema.

## What remains open

`F081` should test public correction and feedback paths after a localized or accessible copy escapes: public annotations, errata, stale citations, machine-generated explanations over variants, and consumer disputes about suppression can create new residue without proving that Harbor needs an annotation platform or correction workflow yet.
