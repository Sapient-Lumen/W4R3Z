# Specimen flow 49 — default-target cue, coverage note, and confirmation-gap receipt

Goal: let Harbor describe a crossing where protected-resource discovery can legitimately cover a broader same-origin path family, a JWT access token may carry a default resource cue when no explicit `resource` was requested, and local validation must still distinguish “likely covered” from “client-facing confirmation actually landed”.

## Scenario
A Harbor-hosted product wants an access token for `https://api.example.com/transactions/123`.
The first unauthenticated request receives a `WWW-Authenticate` challenge pointing at protected-resource metadata.
That metadata names `https://api.example.com/transactions/` or `https://api.example.com/` as the protected resource, so the challenge-derived route covers the requested URL by same-origin path-prefix rules.
The client then performs authorization and token exchange.
Sometimes it sends an explicit `resource` value.
Sometimes it relies on scope and local configuration, so the authorization server chooses a default resource and encodes that choice into the JWT access token `aud` claim.
Sometimes the token response includes a client-facing `resource` value.
Sometimes it omits `resource`.
Sometimes it returns duplicated resource values after normalization, which means local validation must fail.

During execution:
- challenge-derived discovery may cover a broader path family than the exact request URL;
- direct well-known discovery would still have stronger exact-match posture than that challenge-derived coverage;
- the token format may carry a default-resource hint even when no explicit `resource` was requested;
- the token response may confirm one exact resource, several resources, or none at all;
- the response may be malformed for confirmation purposes even if the route and token format both looked plausible;
- and the local product must avoid turning “probably covered” or “JWT `aud` looked right” into counterfeit exact issuance-time confirmation.

Harbor must therefore preserve the difference between:
- “challenge-derived discovery says this request falls under a broader covered path family,”
- “the client explicitly asked for these resource anchors now, or omitted them,”
- “the token format hints at a default target through `aud`, ”
- “the client-facing token response actually confirms the effective target set cleanly,”
- “this turn ended with a confirmation gap because response confirmation was absent, duplicated, or weaker than discovery/cue posture suggested,”
- and “none of those facts by themselves settle durable entitlement, account, session, or adopted consequence truth.”

## Candidate Harbor objects
1. **default-target cue**
   - compact note that the token format or local policy supplied a likely default protected-resource target for this turn;
   - useful because the cue can help explain why a token was usable at a resource server without pretending the client received exact issuance-time confirmation.

2. **coverage note**
   - inspectable note that challenge-derived protected-resource metadata covered the requested URL by same-origin path-prefix rules;
   - useful because broader coverage is real discovery value without becoming grant truth or exact effective-target confirmation.

3. **confirmation-gap receipt**
   - local residue that the route and/or cue looked plausible but the client-facing confirmation surface stayed absent, malformed, duplicated, or otherwise weaker than needed;
   - useful because typed weakness is more honest than silent acceptance or fake precision.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- challenge-derived coverage is broader than direct exact-match discovery;
- JWT-format audience defaults exist even when explicit requested-resource anchors do not;
- client-facing confirmation and resource-server-facing audience are not the same fact;
- and duplicate or missing returned `resource` values should bottom out in a visible confirmation gap instead of quiet reuse.

## Promotion rule
Do not promote `default-target cue`, `coverage note`, or `confirmation-gap receipt` unless they improve:
- one RFC 9068 default-resource-indicator specimen where the JWT `aud` hints at the likely target without itself settling client confirmation;
- one RFC9728bis challenge-derived broader-coverage specimen where same-origin path-prefix coverage is useful but still smaller than exact issuance-time confirmation;
- and one duplicate-resource-response validation-failure specimen where the client-facing confirmation surface fails even though discovery and token-format cues looked plausible.
