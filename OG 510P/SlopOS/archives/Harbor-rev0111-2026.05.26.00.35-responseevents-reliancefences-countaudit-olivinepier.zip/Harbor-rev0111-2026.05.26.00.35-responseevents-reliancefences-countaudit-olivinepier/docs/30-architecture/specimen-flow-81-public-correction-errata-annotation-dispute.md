# Specimen flow 81 — public correction, errata, annotation, stale citation, and dispute hygiene

**Status:** specimen for `F081`; design-phase rehearsal only.

## Setup

Source release and variants, inherited from the public-copy and localized-render passes:

- `public_artifact_id`: `pub-callback-route-week-2026-05-13-r2`
- `source_cut`: `cut-callback-2026-05-13T22:00Z`
- `payload_digest`: `sha256:payload-callback-route-week-r2-example`
- `label_digest`: `sha256:labels-callback-route-week-r2-example`
- localized variant: `pub-callback-route-week-2026-05-13-r2.fr-CA.accessible-table.v1`
- generated summary: `pub-callback-route-week-2026-05-13-r2.summary.en.v1`
- carried labels: `disclosure_treated`, `not_exact_public_copy`, `coarsened_for_disclosure`, `suppressed_cells_present`, `perturbed_release`, `not_a_dp_claim`, `additivity_weakened`, `structural_zero_labels_present`, `do_not_recompose_with=provider-excluded-sibling`

A later review discovers that one accessible table variant preserved data and labels, but the English human summary and a downstream dashboard explanation both lost the `suppressed_cells_present` and `not_a_dp_claim` warnings. A consumer also disputes the suppression label and asks for the hidden values.

## Candidate cases

| Case | Candidate residue | Review question | Verdict |
| --- | --- | --- | --- |
| CE-81-01 | Correction anchor supersedes `r2.summary.en.v1` with `r2.summary.en.v2` and points back to the same labeled bundle | Does the correction target the escaped summary without rewriting source artifact truth? | valid correction anchor; summary corrected, bundle unchanged |
| CE-81-02 | `fr-CA` translated erratum preserves machine label IDs and translates the reason for the summary correction | Did non-promises survive translation? | valid erratum receipt; still smaller than source truth |
| CE-81-03 | External blog post cites the old English summary URL after `v2` exists | Is the citation current? | stale-citation witness; cite remains historical pointer, not current status |
| CE-81-04 | Public annotation says the accessible chart is misleading but targets only the PNG thumbnail, not the data table | Is the target precise enough? | triaged annotation; insufficient to change artifact status |
| CE-81-05 | Reviewer annotation targets the exact table row/label and attaches evidence that label text was stripped in one mirror | Can it support a correction? | accepted annotation feeds correction anchor for the mirror copy |
| CE-81-06 | Machine-generated explanation says “this release has no privacy mechanism” because the prompt omitted `not_a_dp_claim` and `perturbed_release` | Can the explanation travel? | invalid explanation; refuse proof-grade use and regenerate from labeled bundle |
| CE-81-07 | Generated explanation includes source artifact, label digest, omitted-label list empty, and reviewer approval | Is it proof-grade? | explanatory-only but valid to publish with tether |
| CE-81-08 | Consumer disputes `suppressed_cells_present` and asks Harbor to reveal the suppressed count | Can Harbor answer publicly? | dispute packet opened; public response stays class-level; sealed/auditor evidence lane only |
| CE-81-09 | Correction notice changes the public status to `unsafe_for_new_use` but does not provide successor digest | Is it enough? | warning-only; not a full correction anchor until successor/status relation is named |
| CE-81-10 | Annotation flood repeats unsupported claims against every localized variant | Does volume become evidence? | quarantine unsafe annotations; no artifact-status change |
| CE-81-11 | Cached chart image lacks the correction banner while accessible table has it | Are variant statuses aligned? | render-variant drift; stale cache warning and mirror repair required |
| CE-81-12 | DOI-like citation resolves but metadata still says current after Harbor has superseded the copy | Does resolver status outrank Harbor status? | citation metadata-stale; Harbor status wins for Harbor artifacts |

## Counterfeit matrix

| Counterfeit | Why it is tempting | Required Harbor response |
| --- | --- | --- |
| “Correction means the old copy vanished.” | The UI shows the new copy. | Preserve old artifact status and successor relation; no remote-recall promise. |
| “Erratum in another language is equivalent.” | It says the same thing in human terms. | Require machine label IDs, language/locale, translator/reviewer posture, and unresolved terms. |
| “Annotation equals proof.” | It is attached to the artifact. | Require target precision, provenance, evidence class, review status, and safety lane. |
| “Fresh citation equals correct claim.” | The URL resolves. | Record freshness and relation; do not make resolver status semantic truth. |
| “Generated explanation is friendlier than labels.” | It is easier to read. | Tether to label digest, list omitted labels, and mark explanatory-only unless proof labels survive. |
| “Dispute means label is wrong.” | A consumer objected. | Open a dispute packet; correction only follows reviewed evidence. |
| “Refusal proves hidden value.” | The response says it cannot reveal details. | Use class-level refusal copy that does not disclose cell size, denominator, or contributor identity. |
| “Annotation flood is consensus.” | Many notes say the same thing. | Quarantine or rate-limit; volume is not evidence without provenance and review. |

## Example receipt sketch

```yaml
correction_anchor: corr-pub-callback-route-week-2026-05-13-r2-summary-labels-v1
source_public_artifact: pub-callback-route-week-2026-05-13-r2
source_cut: cut-callback-2026-05-13T22:00Z
payload_digest: sha256:payload-callback-route-week-r2-example
label_digest: sha256:labels-callback-route-week-r2-example
affected_variants:
  - pub-callback-route-week-2026-05-13-r2.summary.en.v1
  - dashboard-copy-42.summary-card
correction_class: label_omission_in_human_summary
old_public_status: explanatory_only_missing_required_labels
new_public_status: corrected_explanatory_summary_available
successor_variant: pub-callback-route-week-2026-05-13-r2.summary.en.v2
successor_digest: sha256:summary-en-v2-example
labels_restored:
  - suppressed_cells_present
  - not_a_dp_claim
  - perturbed_release
sealed_evidence: none_required
annotation_receipts:
  - id: anno-reviewer-81-05
    target: dashboard-copy-42.summary-card#label-region
    body_type: reviewer_note
    provenance: internal_review_queue
    review_status: accepted
stale_citation_witnesses:
  - citation: external-blog-example
    target: pub-callback-route-week-2026-05-13-r2.summary.en.v1
    status: points_to_old_variant
    successor_known: pub-callback-route-week-2026-05-13-r2.summary.en.v2
generated_explanation_receipt:
  explanation: pub-callback-route-week-2026-05-13-r2.explainer.en.v2
  source_label_digest: sha256:labels-callback-route-week-r2-example
  omitted_labels: []
  review_status: reviewer_approved
  proof_grade: false
consumer_dispute_packet:
  id: disp-81-suppression-label
  disputed_label: suppressed_cells_present
  public_response: class_level_only
  sealed_review: available_to_authorized_auditor
  resolution: no_public_raw_value_disclosure
non_promises:
  - not_remote_recall
  - not_annotation_platform
  - not_moderation_system
  - not_generated_truth
  - not_disclosure_of_suppressed_cells
verdict: correction_anchor_valid_summary_repaired_source_bundle_unchanged
```

## Consumer-facing refusal copy

> This public copy has a correction or dispute status. The label or summary issue can be reviewed through the linked correction anchor, but Harbor cannot disclose suppressed cell values or sealed replay evidence in a public response. Use the current labeled bundle or a corrected explanatory summary; do not treat the older generated explanation as proof-grade.

## What the specimen proves

This specimen is enough to close `F081` because it shows public corrections, translated errata, annotation provenance, stale citations, generated explanations, mirror/cache drift, and consumer disputes can be handled as bounded process residue without promoting a public-feedback ledger, annotation platform, citation resolver, generated-explanation service, ticketing system, or final datacube schema.

## What remains open

`F082` should test propagation and invalidation after corrections: catalog mirrors, search snippets, generated explainers, agent caches, and downstream training/evaluation copies can keep stale status alive even after Harbor's own correction anchor is correct.
