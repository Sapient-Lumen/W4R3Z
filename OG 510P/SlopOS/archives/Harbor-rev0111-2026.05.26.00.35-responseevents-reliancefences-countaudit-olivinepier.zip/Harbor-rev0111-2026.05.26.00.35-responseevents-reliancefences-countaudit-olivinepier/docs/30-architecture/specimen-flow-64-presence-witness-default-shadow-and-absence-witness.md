# Specimen flow 64 — presence witness, default shadow, and absence witness

Goal: let Harbor pressure-test one realistic datacube slice where the rendered values alone are not enough to tell the truth.

## Scenario
A Harbor maintainer has one candidate curated lane that mixes:
- a boolean `requires_review` field;
- an enum `route_status` field;
- an optional nested `review_summary` object; and
- a numeric `duplicate_count` measure.

Three awkward cases show up in the same delivery window:
1. one upstream producer uses an implicit/default discipline for the boolean, so `false` might mean “explicitly false” or “never set”;
2. one serving tier omits `review_summary` for performance when the summary was never materialized, even though the raw tier could still build it later;
3. one consumer-facing slice suppresses `duplicate_count` for policy reasons, while another slice shows `0` because the warehouse materialization filled a default.

At the same time:
- one analyst wants a single table and would happily coerce blanks to defaults;
- one operational consumer needs to know whether `false` was explicit; and
- the team expects some missing summaries to arrive later during restatement.

## What this proves
Harbor needs to keep these facts separate:
- the rendered value in the slot;
- whether the slot had explicit presence tracking;
- whether a blank is due to policy, query omission, incomplete materialization, or true producer-side absence; and
- whether a default-looking value is trustworthy or default-shadowed.

## Suggested Harbor handling
1. **Presence witness**
   - `requires_review=false` carries a presence witness of **default-shadowed / implicit presence** until the substrate can prove explicit setting.
   - `route_status=UNSPECIFIED` carries a witness that the value is present but semantically weak, not proof that the route truly belongs to that status.

2. **Absence witness**
   - missing `review_summary` in the fast lane carries an absence witness of **serving-tier omission / not materialized here yet**, not generic null.
   - suppressed `duplicate_count` in the consumer slice carries an absence witness of **withheld / policy-suppressed**, not zero.

3. **Default shadow**
   - any field family where unset and default collapse gets a compact default-shadow note so downstream users do not overclaim explicit producer intent.

4. **Restatement consequence**
   - when later materialization fills `review_summary`, Harbor treats that as late-arriving completion or restatement pressure, not proof that the earlier blank meant “not applicable”.

5. **Consumer-obligation slice check**
   - the analyst slice may choose a convenience default for display, but Harbor records that this is display residue rather than canonical meaning.
   - the operational consumer stays pinned to the stronger presence witness and default-shadow warning.

## Why this specimen matters
Without this specimen, Harbor risks two bad patterns:
1. a blank-looking or default-looking slot quietly becomes a semantic fact it never earned; or
2. Harbor panics and tries to solve every future null/absence case with one giant universal ontology before the datacube’s nouns have even stabilized.

This specimen keeps the middle path: **show the value, show how presence was known, show why absence happened, and admit default-shadow where explicit intent is gone.**

## Anti-regrowth notes
- Do **not** let `0` masquerade as unknown, withheld, or not applicable.
- Do **not** let omitted nested children masquerade as producer-side absence without a witness.
- Do **not** let policy suppression masquerade as an empty fact.
- Do **not** let default enum members or booleans counterfeit explicit producer intent.
- Do **not** force one giant cube-wide null ontology before repeated specimens prove it deserves promotion.
