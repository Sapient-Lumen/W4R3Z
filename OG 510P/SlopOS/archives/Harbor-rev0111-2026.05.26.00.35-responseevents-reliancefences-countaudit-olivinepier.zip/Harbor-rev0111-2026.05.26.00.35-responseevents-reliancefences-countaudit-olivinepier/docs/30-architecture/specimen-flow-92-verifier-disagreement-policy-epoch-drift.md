# Specimen flow 92 — verifier disagreement and policy-epoch drift

**Revision:** `rev0097`  
**Followthrough:** `F092`  
**Status:** executable pressure-test specimen; not a verifier arbitration schema, policy-drift ledger, public badge model, reliance API, compliance workflow, legal status resolver, trust-root policy, issuer-reputation model, or final SlopOS datacube shape.

## Scenario

Harbor receives a receipt-import bundle after F091. Multiple verifiers inspect the same or related evidence, but they do not agree:

1. one verifier accepts while another refuses;
2. one verifier accepts inclusion while another cannot establish currentness;
3. a policy changes after a public copy was published;
4. issuer/key status changes after a timestamp anchor;
5. sealed selected-claim verification and public full-evidence verification are incomparable;
6. a local/audience-specific pass conflicts with a global/all-mirror refusal;
7. a candidate collapses disagreement into one green badge;
8. a candidate lets latest policy erase historical public-copy basis;
9. a candidate treats a superseded policy as current;
10. a candidate upgrades one refusal to global failure;
11. a candidate upgrades unknown currentness to fresh-now;
12. a candidate treats issuer compromise as automatic falsity;
13. a candidate uses majority vote as authority;
14. a candidate omits policy digest while asking for epoch comparison.

## Executable packet

The specimen is the fixture at:

```text
fixtures/harbor-verifier-disagreement-policy-epoch-bundle-v0.json
```

It is emitted by:

```text
tools/harbor_verifier_disagreement_harness.py --emit-bundle
```

and checked by:

```text
tools/check_harbor_verifier_disagreement_bundle.py
```

## Expected Harbor behavior

- Harbor accepts `accept-split-accept-refuse-preserved` only as preserved disagreement evidence.
- Harbor accepts `accept-currentness-unknown-withheld` only with public badge withheld.
- Harbor accepts `accept-policy-updated-after-public-copy` only with prior epoch retained and new recheck required.
- Harbor accepts `accept-issuer-status-after-timestamp-recheck` only as timestamp evidence plus issuer-status recheck.
- Harbor accepts `accept-redacted-incomparable-review` only as incomparable selected-claim/public-review residue.
- Harbor accepts `accept-scope-narrow-pass-global-refusal` only as visibly scoped pass plus broader refusal.
- Harbor rejects one-badge green collapse, latest-policy retroactive erasure, stale-policy currentness, refusal-to-global-failure, unknown-currentness-as-fresh, issuer-compromise auto-false, majority-vote authority, and missing-policy-digest epoch comparison.

## Proof obligation pressure

This specimen exercises:

- `PO-VD-001` verifier run identity and policy digest proof;
- `PO-VD-002` disagreement preservation proof;
- `PO-VD-003` policy-epoch drift proof;
- `PO-VD-004` currentness uncertainty proof;
- `PO-VD-005` badge refusal/scope proof;
- `PO-VD-006` issuer status and timestamp recheck proof;
- `PO-VD-007` incomparable-basis proof;
- `PO-XE-001` deterministic bundle proof;
- `PO-XR-002` hostile receipt rejection proof.

## Non-promotion result

`F092` is complete because Harbor now has a deterministic multi-verifier disagreement and policy-epoch drift bundle plus checker. The result is deliberately insufficient to promote a verifier arbitration schema, policy-drift ledger, public badge model, reliance API, compliance workflow, trust-root policy, issuer-reputation model, legal resolver, or final SlopOS datacube shape.
