# Specimen flow 78 — aggregate disclosure small-cell, differencing, and budget humility

This specimen pressure-tests `F078`.

Scenario: a public callback datacube slice has an exact frozen answer and hidden replay evidence. A consumer may see aggregates, but not raw callback rows. The consumer asks for callback success counts and rates by route family, provider family, and weekly cut.

The exact answer exists. Some public copies are unsafe.

## Inputs
- frozen answer: `answerpack-callback-public-2026-05-13T22:20Z`
- source cut: `cut-callback-2026-05-13T22:00Z`
- base grain: one callback attempt after deduplication by local attempt id
- requested views:
  - callback success count by route family;
  - callback success rate by route family and provider family;
  - weekly comparison for the last four cuts;
  - provider-excluded variant for one partner's public report.
- sensitive risk facts:
  - one provider-family cell has two contributors;
  - one displayed success rate has denominator three;
  - one magnitude cell is dominated by one provider;
  - a provider-excluded table and all-provider table differ by the suppressed provider;
  - the same requester has asked six near-neighbor filters over a moving head;
  - a noisy candidate would make subtotals no longer add to the displayed total;
  - one zero is structural, while another zero is disclosure-suppressed.

A naive system would say "aggregate-only" and publish every table. Harbor refuses.

## Candidate release rows

### AD-78-01 — exact aggregate with small cell refused
- class: `small_cell_guard`
- audience: `public_consumer`
- requested answer: exact callback success count for `provider_family=cedar`, `route_family=browser_return`
- contributor evidence: hidden; contributor-count class below release threshold
- release mode: `unsafe_to_release`
- safe alternative: collapse provider family into `other_provider_family` or show route-family-only total
- verdict: `refuse_fine_cell_release`
- anti-counterfeit warning: aggregate-only is not safe when the cell has too few contributors

Healthy behavior: Harbor does not reveal the count, does not reveal the exact threshold, and offers a coarser grouping.

### AD-78-02 — denominator-small rate collapsed
- class: `small_denominator_rate`
- audience: `public_consumer`
- requested answer: success rate for `route_family=native_associated`, `provider_family=maple`
- exactness before treatment: exact numerator and denominator
- risk: denominator is too small even though the percentage looks ordinary
- release mode: `collapsed_release`
- public label: `coarsened_for_disclosure`
- verdict: `publish_collapsed_rate_from_components`
- anti-counterfeit warning: a percentage is not safer than its denominator

Healthy behavior: Harbor recomputes the rate after coarsening; it does not average or sum subgroup percentages.

### AD-78-03 — differencing across two allowed cuts blocked
- class: `sibling_cut_differencing`
- candidate releases:
  - all providers by route family;
  - all providers except `provider_family=cedar` by route family.
- individually: each looks above threshold
- together: subtraction reveals the suppressed cedar cell
- release mode: `complementary_suppression_required`
- verdict: `block_or_suppress_sibling_cut`
- anti-counterfeit warning: individually allowed tables can become unsafe together

Healthy behavior: Harbor checks sibling-cut sets before release and refuses the second table or suppresses enough companions to prevent reconstruction.

### AD-78-04 — repeated-query leakage pattern
- class: `repeated_query_ledger`
- requester pattern: six near-neighbor queries varying one time window and one provider exclusion
- risk: accumulated answers isolate one contributor path over time
- release mode: `budget_exhausted_refusal`
- safe alternative: delayed coarser weekly summary or auditor-only review
- verdict: `refuse_more_fine_queries_for_window`
- anti-counterfeit warning: many safe-looking questions can become one unsafe reconstruction

Healthy behavior: Harbor records the refusal as scoped release-process residue, not as a data absence or durable user blacklist.

### AD-78-05 — noisy candidate with exactness downgrade
- class: `noisy_release_candidate`
- proposed treatment: perturb low counts and small denominators
- missing evidence: contribution bounds and composition/accounting note absent
- consequence: subtotals may not add to displayed totals; equality checks against internal frozen answer will fail
- release mode: `perturbed_release` only; not `dp_candidate`
- verdict: `publish_only_if_noise_receipt_and_copy_labels_exist`
- anti-counterfeit warning: noise is not differential privacy, and noisy output is not exact output

Healthy behavior: Harbor labels the public copy as disclosure-treated, names exactness/additivity consequences, and refuses any DP claim without accounting evidence.

### AD-78-06 — magnitude dominance blocked
- class: `dominance_guard`
- metric: support-bundle bytes exported by provider family
- risk: one contributor dominates the total for the cell
- release mode: `collapsed_release` or `unsafe_to_release`
- verdict: `refuse_dominated_magnitude_cell`
- anti-counterfeit warning: non-small contributor counts can still disclose a dominant contributor

Healthy behavior: Harbor treats dominance as a separate guard from small-cell count.

### AD-78-07 — structural zero versus suppressed zero
- class: `zero_meaning_split`
- cell A: no native-app route exists for a provider family under the contract (`structural_zero`)
- cell B: count withheld for disclosure (`suppressed_zero_like_display`)
- release mode: structural zero may be shown; suppressed zero cannot be rendered as `0`
- verdict: `keep_zero_classes_distinct`
- anti-counterfeit warning: zero is not one thing

Healthy behavior: Harbor labels structural impossibility and suppression differently so downstream systems cannot infer hidden values.

### AD-78-08 — consumer-facing refusal copy without leakage
- class: `safe_refusal_copy`
- unsafe value: hidden
- visible copy: "This fine-grained aggregate is not released because the requested grouping is too sparse or too closely overlaps prior public releases. A coarser grouping is available."
- disallowed copy: "Only two users matched this provider" or "cedar has one failed callback"
- verdict: `refusal_copy_safe`
- anti-counterfeit warning: refusal language can leak the thing it refuses to show

Healthy behavior: Harbor returns class-level copy and a safe alternative, not sensitive explanation detail.

## Counterfeit matrix

| counterfeit | Harbor response |
| --- | --- |
| aggregate-only means safe | reject; check contributor, denominator, dominance, sibling cuts, and repeated-query ledger |
| exact frozen answer means public exact answer | reject; releaseability is separate from answerability |
| one suppressed cell protects the table | reject; require sibling/margin/complementary-suppression review |
| noisy value is DP | reject unless mechanism, bounds, parameters, and accounting evidence are present |
| perturbed totals should reconcile exactly | reject; carry utility/additivity consequences |
| zero is always zero | reject; keep structural, true, rounded, perturbed, suppressed, missing, and refused zero-like states apart |
| repeated refusals prove absent data | reject; refusal is release-process residue, not data absence |
| auditor can see it, therefore public can | reject; evidence audience remains separate |
| BI export may drop suppression labels | reject; label stripping is a downstream release hazard |

## Review copy example

Consumer-visible bounded refusal:

> Harbor can answer this question internally for the frozen cut, but the fine-grained public aggregate is not released. The requested grouping is too sparse or too closely overlaps prior public releases. A coarser route-family summary is available. The public summary may carry disclosure-treatment labels and may not reconcile exactly to internal frozen totals.

Noisy-release receipt sketch:

```yaml
release_cell: callback_success_count_by_route_family_provider_week
answer_cut: cut-callback-2026-05-13T22:00Z
internal_answer_mode: exact_frozen_answer
public_release_mode: perturbed_release
not_a_dp_claim: true
contributor_evidence:
  contributor_count_class: hidden_below_or_near_threshold
  denominator_class: small_for_some_rates
risk_checks:
  small_cell_guard: triggered
  dominance_guard: not_triggered_for_this_metric
  sibling_cut_differencing: triggered_for_provider_excluded_variant
  repeated_query_ledger: near_neighbor_window_warn
noise_receipt:
  mechanism_family: perturbation_unspecified
  stable_across_sibling_cells: unknown
  privacy_loss_accounting: absent
  additivity_consequence: public_subtotals_may_not_sum_to_total
release_labels_required:
  - disclosure_treated
  - not_exact_public_copy
  - coarsened_or_suppressed_cells_present
safe_alternative:
  grain: route_family_only_weekly
verdict: release_coarser_or_refuse_fine
non_promises:
  - aggregate_visibility_is_not_raw_evidence_access
  - noise_is_not_dp_without_accounting
  - suppression_is_not_zero
  - refusal_is_not_data_absence
```

## Verdict
Aggregate-disclosure vocabulary is useful as **bounded review residue**. It lets Harbor distinguish exact internal answers, safe public copies, suppressed/collapsed/noisy releases, differencing hazards, repeated-query leakage, and safe refusal copy without choosing a statistical disclosure-control method.

This pass does **not** promote:

- a small-cell threshold;
- a dominance rule;
- a statistical disclosure-control method;
- a differential-privacy mechanism or accountant;
- a disclosure-budget service;
- a query broker;
- a public aggregate-release API;
- a BI/export governance product;
- a de-identification standard;
- or durable Harbor datacube cards for aggregate disclosure.

Followthrough `F078` is complete. The next pressure should focus on downstream public-copy hygiene: labels, mirrors, BI exports, restated disclosure-treated answers, and how a coarser/noisy public copy survives recomposition attempts outside Harbor.
