# Specimen flow 37 — review card, origin cue, and truncation honesty

Goal: let Harbor describe a bounded reviewed surface, keep the requester/RP cue explicit on that surface, and admit when displayed text is shortened instead of pretending the shortened card was the whole reviewed truth.

## Scenario
A crossing reaches a human review turn on a surface owned by the browser, chooser, authenticator, or other host-controlled UI:
- an OAuth/OIDC authorization request whose merged requirements are rendered for consent;
- a browser credential chooser that must identify the requesting origin;
- a FedCM sign-in prompt owned by the browser;
- or a WebAuthn authorization-gesture prompt that displays RP and user fields.

During the crossing, several pressure points appear:
- the underlying ask may be structured and integrity-protected enough to support a trustworthy summary;
- the displayed surface may have less room than the full ask, forcing shortening, cropping, or field elision;
- the user still needs an explicit requester/RP cue even when the rest of the card is brief;
- and the honest bottom-out may be that the visible card was bounded or truncated rather than fully expansive.

Harbor should therefore preserve the difference between:
- “this was the bounded host-owned review card,”
- “this was the explicit origin/RP cue on that card,”
- “these displayed fields were contained rather than allowed to bleed into surrounding chrome,”
- and “the displayed card was shortened, so the visible summary was only partial.”

## Proposed Harbor objects
1. **review card**
   - host/UA/authenticator-owned bounded display surface summarizing the reviewed crossing;
   - useful because it keeps review visible without turning every nearby string into approval truth.

2. **origin cue**
   - explicit requester/RP/origin indication carried on the review card;
   - useful because it helps preserve provenance and anti-spoofing posture.

3. **bounded field**
   - display-contained field whose content cannot visually bleed into adjacent UI or chrome;
   - useful because it keeps names, labels, or summaries from becoming spoofable boundaryless text.

4. **truncation honesty**
   - inspectable residue that the visible card or field was shortened, cropped, collapsed, or otherwise partial;
   - useful because a partial display is still real history, but it is not the same as full reviewed basis.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- rich or merged asks must be shown on bounded surfaces;
- browser/chooser/authenticator UI needs a visible requester/RP cue;
- displayed identity fields must stay visually contained;
- and the truthful ending may be “the user saw a bounded or shortened card” rather than “the full underlying basis was plainly visible in unbounded prose.”

## Promotion rule
Do not promote `review card`, `origin cue`, `bounded field`, or `truncation honesty` unless they improve:
- one RAR/JAR specimen where a long merged ask becomes a bounded review card without free-floating copy becoming canonical;
- one Credential-Management/FedCM specimen where chooser/user-agent UI keeps an explicit origin cue;
- and one WebAuthn-like bounded-display specimen where RP/user fields stay contained and shortened text admits that it is shortened.
