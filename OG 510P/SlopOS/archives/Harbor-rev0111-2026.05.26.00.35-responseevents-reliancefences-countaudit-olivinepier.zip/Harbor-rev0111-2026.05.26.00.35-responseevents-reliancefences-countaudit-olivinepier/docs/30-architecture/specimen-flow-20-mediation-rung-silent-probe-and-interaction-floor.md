# Specimen flow 20 — mediation rung, silent probe, and interaction floor

Goal: let Harbor describe browser-mediated identity crossings without pretending that UI posture, remembered account relation, or chooser-light continuity already equals success.

## Scenario
A user returns to a relying surface that can attempt browser-mediated sign-in.
The caller may request a silent probe, a chooser-light/discoverable flow, or an explicit reauthentication turn.
The browser or provider may remember that this RP/IdP/account relation existed before, but the current moment still decides whether silent progress is allowed.
If the crossing cannot stay silent, the truthful result is not “auth failed” in the abstract; it is a typed interaction floor such as chooser, login, consent, account selection, or reauthentication required.
Only after the mediated turn completes and local checks pass does any stronger adoption happen.

## Proposed Harbor objects
1. **mediation rung**
   - bounded statement of the requested UI posture for this crossing;
   - stronger than route folklore and weaker than success or account truth.

2. **silent probe**
   - no-UI attempt to recover a valid mediated crossing;
   - can produce a small success precursor or an honest typed floor rather than counterfeit continuity.

3. **conditional chooser**
   - chooser-light, discoverable, or browser-curated mediation branch;
   - stronger than a raw silent probe and weaker than explicit account truth or durable adoption.

4. **interaction floor**
   - typed bottom-out such as `interaction required`, `login required`, `account selection required`, `consent required`, or `reauth required`;
   - stronger than a generic failure and weaker than adopted success.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- auto-reauth or remembered-account UX exists but may not be allowed right now,
- passkey/discoverable flows feel almost ambient,
- silent OAuth/OIDC attempts degrade into typed provider/browser UI demands,
- and a system is tempted to call every bottom-out simply “failure” or every smooth path simply “session truth”.

## Promotion rule
Do not promote `mediation rung`, `silent probe`, `conditional chooser`, or `interaction floor` unless they improve:
- one FedCM-style same-browser auto-reauth specimen,
- one WebAuthn/passkey conditional-mediation specimen,
- and one OIDC `prompt=none` specimen whose honest result is a typed interaction floor rather than counterfeit continuity.
