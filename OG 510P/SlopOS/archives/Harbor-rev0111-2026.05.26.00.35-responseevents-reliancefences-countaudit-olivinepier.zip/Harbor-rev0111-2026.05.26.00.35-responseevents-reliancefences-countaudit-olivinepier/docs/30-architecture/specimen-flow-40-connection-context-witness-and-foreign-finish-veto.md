# Specimen flow 40 — connection-context witness, finish-hash witness, and foreign-finish veto

Goal: let Harbor describe a crossing where one host can initiate multiple OAuth or GNAP-style identity flows across different provider/toolkit/tenant contexts, and a later finish arrives that looks plausible but belongs to the wrong local context.

## Scenario
A Harbor-hosted product lets one user connect tools from multiple toolkits.
Two connections are live in the same broad product shell:
- **Toolkit A / tenant A / provider config A** starts an authorization flow for one tool;
- **Toolkit B / tenant B / provider config B** starts another flow, or an attacker manages to trigger a sibling flow that looks nearby enough to be confused.

During the crossing:
- both flows may show the same provider brand, the same user-facing email address, or very similar account chrome;
- one or both flows may return through a shared broker or a single callback-catching surface;
- a finish callback or structured return parcel arrives that is well-formed and may even carry a real issuer or account indicator;
- but the local side only has adoption rights if that finish belongs to the **exact connection context** and **exact lane/basis** that started here.

Harbor must therefore preserve the difference between:
- “this product remembers which provider/toolkit/tenant/lane initiated this crossing,”
- “this callback or finish package proved it belongs to that exact crossing,”
- “this result may be valid for some nearby context but foreign to the one that started here,”
- and “none of those facts by themselves settle durable account truth, durable session truth, or adopted consequence.”

## Candidate Harbor objects
1. **connection-context witness**
   - exact locally stored tuple for which provider/toolkit/tenant/integration slot and lane initiated the crossing;
   - useful because provider sameness or issuer sameness can still be too coarse.

2. **finish-hash witness**
   - exact callback-binding residue showing the later finish belongs to the initiating context;
   - useful because a callback that only looks plausible is still weaker than a callback that proves it belongs.

3. **foreign-finish veto**
   - explicit local quarantine or abort when a later finish validates structurally but belongs to a different context or lane;
   - useful because “ignore silently” and “accept anyway” are both too dishonest.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- the same host coordinates multiple OAuth/toolkit/tenant contexts;
- visible provider or account cues tempt operators to overread brand sameness as context sameness;
- exact issuer checks are necessary but still not always the whole story;
- and a late finish must prove relation to one exact locally remembered start before adoption.

## Promotion rule
Do not promote `connection-context witness`, `finish-hash witness`, or `foreign-finish veto` unless they improve:
- one cross-toolkit or cross-tenant specimen where provider sameness is insufficient;
- one finish-callback specimen where exact hash/basis/lane binding cleanly vetoes a nearby but foreign result;
- and one specimen where the losing result is kept as visible residue or quarantine rather than erased or over-adopted.
