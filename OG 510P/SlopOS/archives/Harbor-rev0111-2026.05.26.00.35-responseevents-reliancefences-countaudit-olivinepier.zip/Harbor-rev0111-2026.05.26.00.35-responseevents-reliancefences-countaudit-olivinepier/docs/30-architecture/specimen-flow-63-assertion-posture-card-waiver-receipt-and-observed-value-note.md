# Specimen flow 63 — assertion-posture card, waiver receipt, and observed-value note

Goal: let Harbor pressure-test one realistic datacube verification event without pretending that a failed or missing check automatically rewrites the lane's meaning.

## Scenario
A Harbor maintainer has one curated lane in `published` ring and one `candidate` successor lane.

The lane's shape and row meaning are unchanged this week, but three checks fire:
1. the published lane misses its 6-hour freshness target because an upstream arrival is late and the latest observed lag is 8 hours;
2. a duplicate-rate check is slightly elevated but still below the team's true stop-ship threshold;
3. one volume check produces no trustworthy observed value because the evaluation batch was incomplete.

At the same time:
- one operational consumer depends on the freshness promise for alerting;
- one analyst only needs historically interpretable rows and can tolerate temporary staleness; and
- the team expects the upstream lag to clear within one day.

## What this proves
Harbor needs to keep these facts separate:
- whether row meaning or lane shape changed (**they did not**);
- whether an assertion result is `observe-only`, `warn`, `blocking`, or `unknown/not-observed`;
- whether one temporary exception is being accepted deliberately rather than silently ignored; and
- what raw evidence was actually observed versus what headline status was assigned.

## Suggested Harbor handling
1. **Assertion-posture card**
   - Freshness is marked **blocking** for consumers pinned to the stronger service/assertion posture.
   - Duplicate-rate is marked **warn**.
   - The incomplete volume evaluation is marked **unknown / not observed**, not green.

2. **Observed-value notes**
   - Freshness note records "8 hours observed lag against 6-hour target" plus the evaluation timestamp.
   - Duplicate note records the measured duplicate rate and the threshold band that distinguishes warn from blocking.
   - Volume note explicitly says that no trustworthy observed value was produced for the intended window.

3. **Consumer-obligation slice check**
   - Harbor records that the operational consumer is affected by the freshness block.
   - Harbor records that the analyst-facing slice is still usable for historically interpretable work even while the service/assertion posture is degraded.

4. **Waiver receipt**
   - If Harbor chooses to keep the published lane live for the operational consumer during the upstream incident, it leaves a waiver receipt.
   - The receipt names affected assertions, covered consumers, reason, owner, expiry, and the evidence reviewed.
   - The waiver does **not** convert the blocking result into a pass.

5. **Promotion consequence**
   - The candidate successor lane is not blocked merely because the published lane has a temporary freshness incident.
   - But neither lane may claim a stronger freshness posture than the evidence supports.

## Why this specimen matters
Without this specimen, Harbor risks two bad patterns:
1. a temporary quality/service incident quietly mutates the meaning or compatibility story of the lane; or
2. Harbor overreacts and treats every warning, missing observation, or transient incident as a reason to version or redesign the lane itself.

This specimen keeps the middle path: **keep row meaning stable, make assertion posture explicit, show the observed evidence, and leave temporary exceptions as receipts.**

## Anti-regrowth notes
- Do **not** let a waiver receipt masquerade as a green pass.
- Do **not** let a red badge masquerade as a semantic rewrite.
- Do **not** let a missing observed value masquerade as success.
- Do **not** let an analyst-tolerable warning counterfeit safety for a service-critical consumer slice.
- Do **not** let assertion posture silently decide change class, compatibility verdict, or historical meaning.
