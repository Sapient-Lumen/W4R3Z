# Specimen flow 48 — assigned-only lane, requested-anchor minimum, and resource-confirmation floor

Goal: let Harbor describe a crossing where the client may have preconfigured or dynamically discovered resource knowledge, a token response may omit `resource` or return only assigned resources, and local validation must distinguish “usable but not resource-confirmed” from “discard because the requested anchor never survived”.

## Scenario
A Harbor-hosted product wants an access token for a protected resource.
Sometimes the protected resource and authorization server are configured locally ahead of time.
Sometimes the product discovers the resource dynamically from user input and protected-resource metadata.
Sometimes the token request includes one or more explicit `resource` values.
Sometimes it includes no `resource` and lets server policy or requested scopes drive the returned target set.

During execution:
- the route may be preconfigured or dynamically discovered;
- the token request may include one or more explicit requested resources, or none at all;
- the response may return a `resource` parameter matching at least one requested anchor;
- the response may return only authorization-server-assigned resources because no resource was explicitly requested;
- the response may omit `resource`, leaving a preconfigured client with weaker confirmation or a dynamically discovered client with a discard condition;
- and the response may include only non-requested values, which means local validation must fail even if the returned identifiers look plausible.

Harbor must therefore preserve the difference between:
- “the route/discovery layer told us which authorization server and protected resource might be in play,”
- “the client explicitly asked for these resource anchors now,”
- “the token response actually confirmed at least one requested anchor,”
- “this was an assigned-only or unbounded outcome rather than exact requested-target confirmation,”
- “this turn remained usable only below a resource-confirmation floor, or failed that floor entirely,”
- and “none of those facts by themselves settle durable entitlement, account, session, or adopted consequence truth.”

## Candidate Harbor objects
1. **assigned-only lane**
   - inspectable note that the client did not request a resource anchor for this turn, and the authorization server returned one or more assigned resources or an unbounded omission instead;
   - useful because “assigned” is different from “requested and confirmed” without becoming durable entitlement truth.

2. **requested-anchor minimum**
   - local validation floor that when the client did request resources, at least one returned resource must match a requested anchor;
   - useful because assigned additions should not counterfeit exact requested-target success.

3. **resource-confirmation floor**
   - compact local status explaining whether issuance-time resource confirmation happened strongly, weakly, or not at all;
   - useful because preconfigured omission grace and strict-discovery discard are both real outcomes smaller than durable adoption truth.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- preconfigured and dynamically discovered clients deserve different omission posture;
- discovery-time routing remains useful while still being smaller than issuance-time confirmation;
- assigned-only or unbounded outcomes should not counterfeit exact requested-target confirmation;
- and a plausible-looking returned resource set should still fail when none of the requested anchors survived.

## Promotion rule
Do not promote `assigned-only lane`, `requested-anchor minimum`, or `resource-confirmation floor` unless they improve:
- one pre-configured no-resource omission specimen where local prior knowledge permits weaker-but-explicit continuation;
- one dynamically discovered missing-resource-parameter specimen where local policy discards the token rather than guessing the resource confirmation;
- and one client-side requested-anchor validation mismatch specimen where returned resources omit every requested anchor and the turn stays visibly smaller than durable grant or entitlement truth.
