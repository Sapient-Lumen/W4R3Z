# Specimen flow 57 — trusted-schema-audience note, schema-rotation repair receipt, and detail-retry cache epoch

## Scenario
A client calls a protected resource and receives `403 insufficient_authorization_details` plus a `resource_metadata` pointer and an optional JSON body.
That body contains an actionable `authorization_details` object for the failing request and includes ephemeral, interaction-specific fields such as:
- `interactionId`;
- `riskProfile`; or
- another short-lived risk or consent hint.

The protected-resource metadata advertises a set of trusted authorization servers and supported authorization-details types.
At the time the body is emitted, **all** trusted authorization servers accept the detail type used, so the body is valid retry guidance for that trust set.

Later, one of three things changes:
1. the client picks an authorization server outside the original trusted set;
2. one trusted authorization server drops or changes support for the detail type, or rotates the `schema_uri` backing that type; or
3. the actionable body is reused after its interaction-specific fields have become stale, or after an intermediary/client cache replays it despite the original response being marked `Cache-Control: no-store`.

A later retry bottoms out until the client re-fetches resource metadata and schema guidance, reconstructs a fresh authorization-details object, and obtains a newly granted result.

At this point Harbor must preserve six truths at once:
- the error-body object was a retry aid carrying **ephemeral interaction-specific claims**, not durable entitlement or approval truth;
- the object had a **trusted-schema-audience note** because it was only safe for the resource's trusted authorization-server set;
- the client's stale copy belonged to an older **detail-retry cache epoch**;
- trusted-set drift is different from wrong target, wrong account, or session collapse;
- successful re-fetch/rebuild deserves a **schema-rotation repair receipt** rather than counterfeit permanence; and
- actionable bodies, metadata cache, schema fetch, and later granted details all stayed smaller than Harbor-owned policy or entitlement truth.

## Why Harbor needs a new specimen
Without this specimen, Harbor risks either:
1. promoting one helpful actionable body into a portable authorization-policy artifact; or
2. flattening stale-body replay, trust-set drift, and schema rotation into one generic invalid-token or invalid-target failure.

This specimen keeps the middle path: Harbor can tell the truth about who the body was for, when it went stale, and how repair happened.

## Suggested Harbor handling
- Preserve a **trusted-schema-audience note** when an actionable body is only safe for the resource's trusted authorization-server set.
- Preserve a **detail-retry cache epoch** when the client reuses a body or nearby schema guidance from an older retry turn.
- Preserve a **schema-rotation repair receipt** when a later retry succeeds only after re-fetching metadata/schema and rebuilding the detail object.
- Keep actionable body, trusted-AS set, metadata/schema source, built retry object, later granted details, and repaired aftermath visibly separate.
- Treat ephemeral risk or interaction fields as retry-scoped guidance, not durable account, approval, grant, or session truth.

## Anti-regrowth notes
- Do **not** let one actionable `authorization_details` body silently become portable policy or entitlement truth.
- Do **not** let a trusted authorization-server set silently bloom into a Harbor-owned trust-matrix family.
- Do **not** let stale-body replay silently collapse into wrong-target, wrong-account, or session-failure language.
- Do **not** let repair-after-rotation silently become a durable approval or entitlement story.
- Do **not** let `no-store` response bodies and normally cached metadata/schema collapse into one undifferentiated cache object.
