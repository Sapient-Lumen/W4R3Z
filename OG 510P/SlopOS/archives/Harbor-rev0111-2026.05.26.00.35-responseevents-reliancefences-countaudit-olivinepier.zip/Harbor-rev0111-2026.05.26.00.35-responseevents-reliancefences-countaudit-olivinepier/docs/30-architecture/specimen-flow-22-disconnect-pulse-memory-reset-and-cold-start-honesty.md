# Specimen flow 22 — disconnect pulse, memory reset, and cold-start honesty

Goal: let Harbor describe logout/disconnect/reset crossings without pretending they prove universal forgetfulness across RP, provider, browser, and authenticator layers.

## Scenario
A relying surface previously completed a browser-mediated sign-in and now wants to sign the user out or disconnect a remembered relation.
It may redirect the browser to an OIDC RP-initiated logout endpoint.
It may call `navigator.credentials.preventSilentAccess()` so the next visit cannot silently reuse stored credentials.
An identity provider may mark its FedCM login status as `logged-out` and use the FedCM disconnect endpoint so the browser removes a connected-account entry.
A passkey-using relying party may signal `signalUnknownCredential()` or refresh accepted credential/user details so authenticator-side candidate memory gets updated.
Those moves all matter, but they do not prove that every remembering layer is already empty or synchronized.
Harbor should preserve the reset truth without minting a universal logged-out-everywhere object.

## Proposed Harbor objects
1. **disconnect pulse**
   - typed request that a specific layer should sever, disassociate, or demote a remembered relation;
   - examples include RP-initiated logout, browser disconnect, or credential-manager sign-out signal;
   - stronger than folklore and weaker than universal logout truth.

2. **memory reset**
   - layer-local truth that silent reuse, connected-account memory, or remembered credential candidates were suppressed, removed, or refreshed;
   - may succeed partially or only for one layer;
   - stronger than “nothing changed” and weaker than “all memory is gone”.

3. **cold-start floor**
   - next return should begin from fresh mediation, chooser, or login posture instead of piggybacking on old continuity residue;
   - useful because products often need to say “start over through the front door again” without claiming account deletion or full revocation.

4. **residual-memory honesty**
   - standing rule that one layer’s reset does not prove every browser/provider/authenticator/RP memory surface forgot simultaneously;
   - important because ecosystems differ wildly in what they can forget immediately, lazily, or only on next attachment.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- a user explicitly signs out or disconnects;
- one layer suppresses silent reuse while another layer may still remember candidates;
- post-logout cleanup signals update remembered state without proving fresh authentication truth;
- and the right result is not “all state is gone” but “these layers were asked to reset, these layers changed, and the next turn starts colder”.

## Promotion rule
Do not promote `disconnect pulse`, `memory reset`, `cold-start floor`, or `residual-memory honesty` unless they improve:
- one OIDC RP-initiated logout specimen where confirmation and bounded post-logout redirection remain visible;
- one FedCM / Credential Management specimen where disconnect or silent-suppression makes the next visit begin colder without proving universal logout;
- and one WebAuthn Level 3 cleanup specimen where stale credential memory is updated without becoming selected-account truth.
