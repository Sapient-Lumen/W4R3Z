# Specimen flow 59 — publish lane card, branch rehearsal, and promotion merge receipt

## Scenario
Harbor now has one candidate base crossing grain and a handful of tempting downstream datacube shapes.

Three consumers ask for slightly different curated surfaces:
1. one report wants a stable **crossing-turn** lane for trend counts;
2. one design-review tool wants a **restatement-aware** lane that can expose correction history; and
3. one future semantic-layer experiment wants a thinner **entities/dimensions/measures** projection.

A team wants to rehearse one candidate lane change without freezing the whole stack:
- add a new optional facet note on the base grain;
- test a backfill that recomputes older rows under a clearer history policy; and
- emit a generated catalog or semantic-model artifact so downstream tools can trial the shape.

At that point Harbor needs six truths to stay separate:
- the current published consumer-facing surface needs a visible **publish lane card**;
- the experimental variant needs a visibly non-canonical **branch rehearsal**;
- any generated SQL/schema/catalog/semantic artifact needs to stay a **derived artifact** of that rehearsal, not the repo’s new truth;
- if the rehearsal is adopted, Harbor needs a **promotion merge receipt** instead of folklore;
- if a historical snapshot is worth keeping, Harbor may need a **historical tag** that stays smaller than the evolving lane head; and
- lane/reference identity must stay visible even if a future catalog makes the query shape look the same.

## Why Harbor needs a new specimen
Without this specimen, Harbor risks either:
1. treating one experimental export or branch head as the new ontology; or
2. refusing to experiment at all because every rehearsal feels like a permanent architectural commitment.

This specimen keeps the middle path: Harbor can rehearse datacube contracts safely while still keeping reviewed meaning stronger than generated artifacts.

## Suggested Harbor handling
- Preserve a **publish lane card** for every consumer-facing curated datacube surface.
- Preserve a **branch rehearsal** when testing a new contract, backfill, or export.
- Preserve a **promotion merge receipt** when a rehearsal lane becomes the new published lane.
- Allow an optional **historical tag** when a frozen audit/replay reference is worth keeping.
- Keep generated schemas/catalog exports/semantic-model configs explicitly **derived** from the reviewed lane, not equal to it.
- Keep lane/reference identity visible in any future export surface.
- Keep rehearsal-lane retention/expiry explicit so temporary lanes do not quietly become production by inertia.

## Anti-regrowth notes
- Do **not** let a branch name, export path, or catalog schema name masquerade as Harbor’s ontology.
- Do **not** let the latest rehearsal head silently rewrite what an older published revision meant.
- Do **not** let “same SQL, different reference” hide which lane or historical tag the user is actually querying.
- Do **not** let one successful generated artifact outrank the archive’s canonical review surfaces.
- Do **not** let temporary staging lanes become immortal just because deleting them feels inconvenient.
