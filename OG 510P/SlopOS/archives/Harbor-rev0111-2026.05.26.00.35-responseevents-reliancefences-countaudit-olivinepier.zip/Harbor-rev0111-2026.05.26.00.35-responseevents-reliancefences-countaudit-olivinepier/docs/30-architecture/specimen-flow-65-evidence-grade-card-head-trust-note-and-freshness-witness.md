# Specimen flow 65 — evidence-grade card, head-trust note, and freshness witness

Goal: let Harbor pressure-test one realistic datacube slice where a lane can be trustworthy in more than one way, but not in the same way for every consumer.

## Scenario
A Harbor maintainer is reviewing three candidate curated lanes that all look superficially healthy:
- `crossing_summary_live` — a live operational lane with current dashboard consumers;
- `crossing_summary_audit_tag` — a frozen historical tag used for replay and explanation; and
- `crossing_summary_partner` — a partner-facing lane whose contract status is reported by an external quality system.

Three awkward facts show up in the same review window:
1. `crossing_summary_live` has a passing schema/quality status and a computed freshness age of 2 hours against a 6-hour warning threshold, but the reading came from a moving live head and no exact snapshot identifier was captured in the review note;
2. `crossing_summary_audit_tag` is tied to one exact snapshot/tag and is perfectly replayable, but it is 30 hours old and should not quietly pass as the answer to a present-tense operational freshness question;
3. `crossing_summary_partner` has a green summary badge from an external validation run, but the returned evidence payload does not include the detailed `observed_value` or row-level diagnostics needed to explain what was actually checked.

## Pressure
If Harbor only records one generic “published / passing” state, all three lanes can look equivalent even though:
- one is current but not exact/replayable;
- one is exact/replayable but not current; and
- one has only partial summary evidence.

## Minimal Harbor move
Harbor keeps the row meaning and contract tier unchanged and adds three smaller review surfaces:

### 1) Evidence-grade card
- `crossing_summary_live` → **head-fresh**
- `crossing_summary_audit_tag` → **snapshot-pinned**
- `crossing_summary_partner` → **partial / summary-only**

### 2) Head-trust note
- `crossing_summary_live` — moving live head, exact snapshot not preserved
- `crossing_summary_audit_tag` — exact frozen tag preserved
- `crossing_summary_partner` — external result ingestion, detailed evidence handle incomplete

### 3) Freshness witness
- `crossing_summary_live` — observed at `T0`, age `2h`, warning threshold `6h`, basis = warehouse metadata / row timestamp policy
- `crossing_summary_audit_tag` — observed at `T0`, age `30h`, currentness not suitable for live operational consumers, but exact replay okay
- `crossing_summary_partner` — freshness basis unknown because the external summary did not include enough detail to compute or explain it

## Why this is better than one giant status
- it keeps **currentness** visible without pretending the live head was an exact reviewed artifact;
- it keeps **exact replayability** visible without counterfeiting present-tense freshness;
- it keeps **summary-only evidence** visibly weaker than a full measured observation; and
- it lets different consumers fit different lanes without forcing a giant observability stack, snapshot registry, or universal trust score.

## What stays deliberately open
- whether Harbor later stores exact snapshot IDs in a registry or only in lightweight receipts;
- whether evidence grades ever become machine-readable fields on published lanes;
- whether consumer-fit notes are needed beside evidence-grade cards or remain a later follow-on.

The specimen earns one small rule only: **a passing lane still needs an honest evidence posture saying whether it is fresh, exact, partial, or unknown.**
