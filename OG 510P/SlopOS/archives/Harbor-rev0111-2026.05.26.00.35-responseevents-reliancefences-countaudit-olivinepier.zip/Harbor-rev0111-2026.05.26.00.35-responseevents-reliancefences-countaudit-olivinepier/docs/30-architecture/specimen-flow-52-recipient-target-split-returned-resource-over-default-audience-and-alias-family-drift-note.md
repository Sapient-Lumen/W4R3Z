# Specimen flow 52 — recipient-target split, returned-resource-over-default-audience, and alias-family drift note

Goal: let Harbor describe a crossing where a protected resource asks for a JWT-secured introspection response, the signed recipient of that response is one exact receiver, the token itself still carries broader/default audience-like identifiers, the token response provides stronger explicit `resource` confirmation, and a neighboring receiver family can still refuse because local accepted identifiers drifted.

## Scenario
A Harbor-hosted product first wants to call `https://api.example.com/entries/42`.
The client does **not** send a `resource` parameter in the authorization request because it only knows the `entries:read` scope.
The authorization server issues:
- a JWT access token whose `aud` is the default audience `https://api.example.com/`; and
- a token response whose explicit `resource` value is `https://api.example.com/entries`, assigned from policy and scope.

Later, the entries protected resource receives the token and asks the authorization server for JWT-secured introspection by sending:
- `Accept: application/token-introspection+jwt`;
- resource-server authentication to the introspection endpoint;
- and the token value the client presented.

The authorization server returns a signed JWT introspection response whose:
- top-level `aud` is `https://api.example.com/entries`;
- `token_introspection.active` is `true`;
- and nested token metadata includes `aud = ["https://api.example.com/", "entries-api"]` and `scope = entries:read`.

At this point Harbor must preserve three different target-like facts:
- the **signed recipient** of the introspection JWT is the entries receiver;
- the **nested token audiences** are broader/default or alias-shaped target hints;
- the **explicit returned `resource`** from token issuance is `https://api.example.com/entries` and is stronger for the client than the broader/default `aud`.

A second receiver on the same origin, `https://api.example.com/reports`, exposes RFC9728bis-style challenge-derived metadata whose resource identifier covers `/reports/` by same-origin path-prefix rules. That receiver's local expectation rules drifted recently: it now accepts only `reports-api` or `https://api.example.com/reports`, not the old family alias `https://api.example.com/`.

During execution:
- the entries receiver can accept because the signed recipient, explicit returned `resource`, and local expectation line up closely enough;
- the reports receiver can still refuse even though the token's default or mapped `aud` looked same-origin and same-family enough to tempt overreading;
- and Harbor must not flatten those endings into one generic protected-resource truth object.

## Candidate Harbor objects
1. **recipient-target split**
   - compact note that the JWT-secured introspection response was signed to one exact receiver while the nested token metadata named a different or broader target set;
   - useful because it prevents signed recipient provenance from silently becoming token-wide exact-resource truth.

2. **returned-resource-over-default-audience conflict**
   - compact note that explicit returned `resource` confirmation and broader/default token `aud` cues pointed at different strengths of target fact, with client-facing interpretation favoring the returned `resource`;
   - useful because it keeps client-facing confirmation and token-format/default routing cues from collapsing into one counterfeit truth.

3. **alias-family drift note**
   - typed local ending showing that a neighboring receiver or alias family changed, narrowed, or no longer accepts the broad/default audience cue;
   - useful because it keeps receiver-local refusal legible instead of hiding it behind generic invalid-token folklore.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- RFC 9701 signs the introspection response to one exact recipient and separates the nested token metadata to prevent claim confusion;
- RFC 7662 keeps introspection receiver-scoped and allows responses to differ by protected resource;
- RFC 8707 and RFC 9068 allow exact resources to be mapped to broader or default audience identifiers;
- the March 2026 resource-token-response draft says explicit returned `resource` is more useful than audience for client-side exactness;
- and RFC 9728bis plus RFC 9068 still leave final accepted-identifier fit to the current receiver.

## Promotion rule
Do not promote **recipient-target split**, **returned-resource-over-default-audience conflict**, or **alias-family drift note** unless they improve:
- one RFC 9701 specimen where signed recipient provenance and nested token target metadata are clearly different facts;
- one explicit returned-resource-versus-default-audience specimen where client-side exactness should follow the returned `resource`;
- and one protected-resource drift specimen where same-origin or same-family coverage still bottoms out in a visible local refusal.
