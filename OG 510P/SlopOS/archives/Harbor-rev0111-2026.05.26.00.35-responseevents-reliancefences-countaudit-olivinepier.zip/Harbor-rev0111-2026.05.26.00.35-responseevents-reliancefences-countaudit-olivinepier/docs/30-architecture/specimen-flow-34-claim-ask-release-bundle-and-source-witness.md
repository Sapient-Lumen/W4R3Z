# Specimen flow 34 — claim ask, release bundle, and source witness

Goal: let Harbor describe requested identity/profile facts and the facts that actually came back without turning them into a portable adopted-profile, adopted-account, or subject-truth plane.

## Scenario
A crossing begins with a request for some facts about the outside subject or account.
Examples include:
- an OIDC client asking for `email`, `email_verified`, groups, or selected profile claims via scope values and/or the `claims` parameter;
- an RP receiving a UserInfo payload where some requested claims are omitted, some arrive directly, and some arrive through aggregated/distributed claims sources;
- a FedCM chooser receiving account-display facts such as `name`, `email`, `picture`, and matching hints;
- or a WebAuthn ceremony carrying human-display account names that help users recognize which credential they are managing.

During this period, several truths can emerge:
- a caller or browser asks for a set of facts;
- the outside side releases some bundle of facts, possibly partial;
- the released facts may come from one source or from multiple named/provenanced sources;
- and the correct local outcome may still be display-only, chooser-only, or “not enough to adopt here”.

Harbor should therefore preserve the difference between:
- “we asked for these facts,”
- “these are the facts that actually came back,”
- “this is where those facts came from,”
- and “local subject/account adoption still remains elsewhere.”

## Proposed Harbor objects
1. **claim ask**
   - typed request for specific identity/profile facts;
   - useful because it keeps demanded information visible without pretending it arrived.

2. **release bundle**
   - inspectable outside-provided set of facts that actually came back here;
   - stronger than the ask because it reflects release reality, weaker than local adoption because policy, matching, and trust still remain local.

3. **source witness**
   - compact provenance about which issuer/provider/claims source asserted which facts;
   - useful because it prevents flattened “profile blob” folklore when claims come from multiple places or through references.

4. **not-adopted-here honesty**
   - explicit local bottom-out when a release bundle is display-only, chooser-only, partial, or otherwise insufficient for local account/profile adoption;
   - standing anti-regrowth rule: do not let returned or displayed facts masquerade as adopted subject/account truth.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- requested facts may be optional, omitted, or heuristically returned;
- one released bundle may combine direct, aggregated, and referenced facts;
- display-facing account strings need clear UI boundaries;
- and the truthful ending may be “useful to show/review/narrow” rather than “locally adopted account/profile truth”.

## Promotion rule
Do not promote `claim ask`, `release bundle`, or `source witness` unless they improve:
- one OIDC specimen where requested claims are partially omitted without fake error or fake success;
- one OIDC aggregated/distributed-claims specimen where provenance stays visible;
- and one FedCM or WebAuthn specimen where account/profile display facts remain visibly smaller than local subject/account adoption.
