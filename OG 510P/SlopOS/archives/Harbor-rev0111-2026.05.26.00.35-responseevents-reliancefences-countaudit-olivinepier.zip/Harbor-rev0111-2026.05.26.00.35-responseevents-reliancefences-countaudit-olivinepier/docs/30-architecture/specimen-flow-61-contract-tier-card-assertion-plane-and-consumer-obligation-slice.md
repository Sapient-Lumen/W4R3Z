# Specimen flow 61 — contract-tier card, assertion plane, and consumer-obligation slice

Goal: let Harbor pressure-test one curated datacube lane that is genuinely useful downstream without pretending every nearby promise has matured equally.

## Scenario
A Harbor maintainer has one curated lane that several downstream consumers want to use.
The returned columns and types are now fairly stable, but the deeper meaning of two value families is still being refined and the team is still experimenting with freshness/volume checks.

At the same time:
1. one dashboard consumer only needs five fields and a stable shape;
2. one operational consumer also needs a 12-hour freshness assertion; and
3. one analyst wants a frozen historical reference for reproducible backfill work.

## What this proves
Harbor needs to keep these facts separate:
- whether the lane’s **shape tier** is mature enough for publication;
- whether the lane’s **meaning tier** is still candidate or rehearsal posture;
- which checks live in the neighboring **assertion plane**;
- which consumer relies on which subset of fields/assertions/history behavior; and
- which generated test or monitoring artifacts were derived from the review surface.

## Suggested Harbor handling
1. **Contract-tier card**
   - Harbor marks the lane as **published for shape**, **candidate for meaning**, and **rehearsal for service/freshness**.
   - The card names owner, review trigger, and which tiers are intentionally absent.

2. **Assertion plane**
   - Freshness, schema, and volume checks live as explicit neighboring assertions.
   - Failing an assertion is meaningful, but it must not silently reinterpret the row contract.

3. **Consumer-obligation slice**
   - The dashboard consumer pins to the published shape tier plus five named fields.
   - The operational consumer pins to the same shape slice plus one freshness assertion.
   - The analyst pins to a frozen historical reference and does not depend on the live head assertion posture.

4. **Generated artifact humility**
   - dbt tests, monitoring rules, warehouse-native checks, or catalog descriptions may be generated from the lane and assertion plane.
   - Each derived artifact must identify the exact Harbor revision and lane/reference it reflects and remain smaller than the canonical review surface.

5. **Change discipline**
   - A new optional column may fit inside the published shape tier if the compatibility window allows it.
   - A meaning rewrite or enum reinterpretation requires a meaning-tier review, not a disguised assertion update.
   - A tighter freshness target changes service/assertion posture and should not masquerade as a schema change.

## Why this specimen matters
Without this specimen, Harbor risks one of two bad patterns:
1. one useful lane gets over-contracted immediately because a few consumers rely on it; or
2. Harbor avoids explicit downstream usage because it has no honest way to say “shape is stable, deeper meaning and checks are still maturing.”

This specimen keeps the middle path: real consumers are allowed, but each promise family stays explicit and reviewable.

## Anti-regrowth notes
- Do **not** let “contracted” flatten shape, meaning, assertions, and service posture into one badge.
- Do **not** let assertion failures silently redefine row meaning.
- Do **not** let one consumer’s narrow dependency imply a universal promise for every field.
- Do **not** let generated test/monitor artifacts outrank the review surface that declared the tier.
- Do **not** let a frozen historical consumer pin pretend to be the same thing as a live-head consumer.
