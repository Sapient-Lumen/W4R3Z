# Specimen flow 21 — selector hint, chooser priming, and selection honesty

Goal: let Harbor describe preference and narrowing inputs without pretending they already answer who or what was actually selected.

## Scenario
A relying surface has some useful context before a mediated crossing starts.
It may know the user’s typed e-mail address and send an OIDC `login_hint`.
It may prefer enterprise-domain accounts and send a FedCM `domainHint`.
It may prefer a passkey path that is likely `client-device`, `security-key`, or `hybrid` and provide WebAuthn hints.
Those inputs can shape the candidate set or the order in which candidates are shown.
But the browser, provider, or chooser still owns whether a candidate actually exists, whether more login is needed, whether the hint mismatches the present state, and what the user explicitly selects.
Harbor should preserve that crossing truth without minting a portable selected-account, selected-credential, or selected-handler object.

## Proposed Harbor objects
1. **selector hint**
   - bounded preference or narrowing signal about a likely account, domain, or authenticator path;
   - may come from the caller or from provider-maintained labeling;
   - stronger than route folklore and weaker than any reviewed selection.

2. **chooser priming**
   - visible effect of a hint on filtering, sorting, staging, or highlighting candidates;
   - stronger than “nothing happened” and weaker than selected-outcome truth.

3. **mismatch prompt**
   - typed truth that the supplied hint did not land on a currently usable candidate and more interaction is required;
   - examples include login prompt, account-selection prompt, or chooser reset;
   - stronger than generic failure and weaker than adopted consequence.

4. **selection honesty**
   - standing rule that the actual selected account, credential, or handler remains outside Harbor until a reviewed mediated turn and local adoption say otherwise;
   - important because products often overread hinting as implicit choice.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- a caller supplies useful narrowing context,
- chooser surfaces may become heavily filtered or pre-shaped,
- a mismatch may still require fresh login or selection,
- and the right result is not “the account was chosen” but “the chooser was primed in this particular way”.

## Promotion rule
Do not promote `selector hint`, `chooser priming`, `mismatch prompt`, or `selection honesty` unless they improve:
- one OIDC `login_hint` specimen that still bottoms out at explicit account selection or login;
- one FedCM `loginHint` / `domainHint` or provider-label specimen whose hint filters the chooser without becoming selected-account truth;
- and one WebAuthn Level 3 `hints` specimen where the user agent is guided but not bound.
