# Specimen flow 51 — JWT introspection response card, response-over-token precedence, and alias-family mismatch note

Goal: let Harbor describe a crossing where a protected resource asks for a JWT-secured introspection response, the authorization server signs the reply to that exact receiver, the client also has an explicit returned `resource` value from token issuance, and the current receiver can still veto the turn because its accepted identifier family is narrower than audience-like token evidence suggested.

## Scenario
A Harbor-hosted product wants to call `https://ledger.example.com/entries/42`.
The access token is opaque to the client, so the ledger resource server introspects it.
The resource server sends:
- `Accept: application/token-introspection+jwt`;
- resource-server authentication to the introspection endpoint;
- and the token value the client presented.

The authorization server returns a signed JWT introspection response whose:
- top-level `iss` names the authorization server;
- top-level `aud` names the ledger resource server receiving the JWT response;
- `token_introspection.active` is `true`;
- nested token metadata includes `scope = ledger:read` and `aud = ["ledger-api", "https://ledger.example.com/"]`.

Earlier, when the client obtained the token, the token response also returned:
- `resource = "https://ledger.example.com/entries"`.

The ledger deployment has local expectation rules saying that:
- exact `https://ledger.example.com/entries` is accepted for the entries family;
- `ledger-api` is a broad family alias accepted only for non-admin ledger routes;
- `https://ledger.example.com/` is a receiver-level identifier, not blanket approval for every sub-surface;
- and `https://ledger.example.com/admin` is not in-family for this token even though the token/introspection audiences look ledger-shaped.

During execution:
- the signed JWT introspection response proves what the authorization server said to this receiver;
- the nested token audiences remain audience-like hints rather than client-facing exact protected-resource confirmation;
- the explicit returned `resource` from the token response is stronger for the client than token or introspection audience folklore;
- and the current receiver can still refuse the call if its exact accepted identifier family for this route does not match what was confirmed.

Harbor must therefore preserve the difference between:
- “the authorization server signed an introspection response to this exact receiver,”
- “the nested token metadata named these audience-like identifiers,”
- “the client did or did not receive stronger explicit returned-resource confirmation,”
- “the current receiver still bottomed out in alias-family mismatch or local-expectation veto,”
- and “none of those facts by themselves settle durable entitlement, account, session, or adopted consequence truth.”

## Candidate Harbor objects
1. **JWT introspection response card**
   - compact note that the authorization server returned a signed introspection JWT to one exact protected resource;
   - useful because it records stronger receiver-facing provenance without pretending that it is portable client-facing exact-resource truth.

2. **response-over-token precedence**
   - standing interpretation rule that explicit returned `resource` confirmation outranks ambiguous audience hints from token self-inspection or introspection when the client needs exact protected-resource applicability;
   - useful because it keeps client-facing confirmation and receiver-facing audience evidence from collapsing into one counterfeit truth.

3. **alias-family mismatch note**
   - typed local ending showing that current receiver acceptance failed even though the signed introspection response or token audiences looked plausible;
   - useful because it keeps receiver-local refusal legible instead of hiding it behind generic invalid-token folklore.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- RFC 9701 adds a signed JWT wrapper around token introspection, with a top-level recipient audience and a nested `token_introspection` object;
- the March 2026 resource-token-response draft still says clients cannot rely on audience information from introspection or self-inspection for exact protected-resource applicability;
- explicit returned `resource` values can contain at least one requested resource, possibly plus server-assigned additions;
- and RFC 9068 / OAuth 2.1 still make the current protected resource’s own exact expectation and refusal posture decisive.

## Promotion rule
Do not promote **JWT introspection response card**, **response-over-token precedence**, or **alias-family mismatch note** unless they improve:
- one RFC 9701 specimen where the signed introspection response is clearly receiver-facing and deliberately distinct from the nested token metadata;
- one explicit returned-resource-over-audience specimen where the client-facing `resource` value is stronger than introspection/JWT audience hints;
- and one local receiver-alias mismatch specimen where signed or token-format evidence looked plausible yet the correct ending is still a visible refusal here.
