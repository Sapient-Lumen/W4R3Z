# Specimen flow 31 — discovery card, cache epoch, and admission truth

Goal: let Harbor describe fetched and refreshed discovery/configuration surfaces without turning them into portable trust, route ownership, or automatic local adoption.

## Scenario
A local product needs to cross a boundary toward a remote provider, resource, or routed app path.
Examples include:
- an OAuth/OIDC client fetching authorization-server metadata or protected-resource metadata from a well-known location;
- a FedCM-capable browser consulting the IdP well-known file, config file, endpoint set, and login-status hints;
- or an Android app relying on manifest-declared App Links while newer server-side `assetlinks.json` rules periodically refresh and refine handling.

During this period, several truths can emerge:
- a fetched discovery document says what the outside party claims about itself;
- a cached earlier fetch may still be present with some age and provenance;
- an overlay or policy-resolution step may refine what the raw discovery means locally;
- and the local side still has to decide whether the result is usable here now, needs refresh, falls back to a static floor, or must be rejected.

Harbor should therefore preserve the difference between:
- raw fetched description of an outside route/provider/resource/config surface,
- the age/provenance of that fetched description,
- any bounded overlay or resolution process that changed how the description is interpreted,
- and the stronger local truth that a route/admission path was actually allowed here.

## Proposed Harbor objects
1. **discovery card**
   - compact fetched description of an outside route/provider/resource/config surface;
   - examples include authorization-server metadata, protected-resource metadata, a FedCM config endpoint result, or refreshed app-link rules;
   - useful because it keeps “this is what the outside side currently advertises” smaller than local route/admission truth.

2. **cache epoch**
   - inspectable marker for age, provenance, or refresh generation of fetched discovery/config residue;
   - useful because it keeps stale-versus-fresh uncertainty visible instead of laundering yesterday's fetch into timeless certainty.

3. **overlay witness**
   - visible note that raw discovery was refined by a policy layer, trust-chain resolution, manifest ceiling, or other bounded overlay process;
   - stronger than raw fetch logging because it explains *why* current interpretation differs from source bytes, weaker than local adoption because it still does not decide consequence by itself.

4. **admission truth**
   - explicit local verdict that says whether the fetched/resolved discovery is usable here now, needs refresh, falls back to a static floor, or must be rejected;
   - standing anti-regrowth rule: do not overread fetched config, support lists, or resolved overlays into portable trust or admitted route ownership.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- fetched metadata is exact enough to matter but still not enough to settle local consequence;
- stale cached discovery should lead to refresh, fallback, or rejection instead of counterfeit confidence;
- layered resolution/refinement is useful but should not erase raw origin;
- and platform/browser/provider config surfaces keep changing without becoming one giant portable config authority plane.

## Promotion rule
Do not promote `discovery card`, `cache epoch`, or `overlay witness` unless they improve:
- one RFC 8414 / RFC 9728 specimen where fetched metadata and exact-identifier checks remain visibly smaller than actual admitted route/resource truth;
- one FedCM specimen where well-known/config-endpoint information shapes chooser behavior without becoming portable account/login truth;
- and one Dynamic App Links specimen where refreshed server-side rules remain visibly smaller than manifest ceilings and final admitted path handling.
