# Specimen flow 85 — recurrence, escalation, cooldown, and warning sunset

**Revision:** `rev0090`  
**Followthrough:** `F085`  
**Purpose:** pressure-test recurring stale-copy regressions, serial acknowledgement expiry, repeated unverifiable attestations, mixed-accuracy external reports, stale/disputed public warnings, and public-log/status divergence before promoting recurrence ledgers, reliability notes, escalation triggers, reporter-confidence labels, or status-sunset rules.

## Scenario

Harbor has already corrected public aggregate artifact `pub-claims-2026q1-r4` with a correction anchor and successor public copy `pub-claims-2026q1-r5`.

Five cycles later:

1. A catalog mirror that previously repaired its copy exports a stale CSV again after a BI job reruns from an old cache.
2. The same downstream owner acknowledges the new notice, but prior acknowledgements have expired twice and no verifier packet proves repair.
3. The owner repeats a non-use claim for a generated explainer cache, but cannot name retrieval-index versions, dependency locks, or access logs for the relevant window.
4. An external reporter correctly finds the stale CSV, incorrectly claims a suppressed cell leaked, and ambiguously reports an outdated status-page banner.
5. A public log still contains a signed `fixed` claim from the prior cycle while the current status surface says `standing challenge open`.
6. The warning for one stale copy class may need to escalate, while an older warning for another repaired target may be safe to sunset to historical-only.

## Actors

- Harbor source owner.
- Downstream catalog owner.
- External reporter.
- Consumer who sees stale CSV.
- Auditor/reviewer who can inspect sealed evidence.
- Public reader who sees only safe warning copy.

## Evidence packet

```text
source_artifact: pub-claims-2026q1-r5
correction_anchor: corr-2026q1-claims-label-restatement
stale_target: catalog-alpha/export/claims-q1.csv
regressed_target: catalog-alpha/export/claims-q1.csv
prior_remediation: rem-cat-alpha-002
prior_verified_at: 2026-05-10T14:12:00Z
regression_observed_at: 2026-05-15T15:41:00Z
payload_digest_current: sha256:current-r5
payload_digest_observed: sha256:stale-r4
label_digest_current: sha256:labels-r5
label_digest_observed: sha256:labels-r4-stripped
public_log_claim: log-entry-44f... says fixed for rem-cat-alpha-002
current_status_surface: standing_challenge_open
```

## Required checks

### 1. Recurrence pattern receipt

Harbor records a recurrence pattern for `catalog-alpha/export`:

```text
pattern_type: stale_copy_regression
same_target: yes
same_label_family: disclosure/exactness/restatement labels
first_observed: 2026-05-08
latest_observed: 2026-05-15
clean_windows: one observed repair window
regression_basis: payload digest + label digest mismatch
allowed_consequence: re-notify + challenge remediation + active warning
unsupported: bad faith, all catalog-alpha exports stale, consumer harm proven
```

### 2. Regression guard receipt

The old remediation is not simply overwritten.

```text
prior_remediation_status: repaired_when_observed
current_result: regression_confirmed
cause_known: no
suspected_path: old BI cache rerendered CSV
safe_statement: This target served a superseded copy again after an earlier repair. Use the current Harbor release artifact and treat this mirror as unsafe for new analysis until revalidated.
```

### 3. Serial acknowledgement note

The downstream owner acknowledges the latest notice, but three acknowledgement cycles have now expired without durable repair proof.

```text
ack_history: acknowledged -> expired -> acknowledged -> expired -> acknowledged
current_ack_status: receipt_only
allowed_consequence: require verifier packet before public status can say repaired
unsupported: refusal, negligence, non-use, repair, deletion, notification of all consumers
```

### 4. Claim reliability limiter

The downstream owner repeats a non-use claim for an agent explainer cache.

```text
claim_family: generated_explainer_non_use
claim: not used after correction notice
missing_repeated: retrieval index version, cache invalidation receipt, access-log window, dependency lock, model/eval path
result: claim_family_unverifiable
limiter: future non-use claims in this family require verifier packet or are displayed as unverified cooperation only
anti_score: does not rank catalog-alpha generally
```

### 5. Reporter claim outcome map

The external reporter gets one thing right, one thing wrong, and one thing unresolved.

```text
reporter_claims:
  - stale_csv_visible: confirmed
  - suppressed_cell_leaked: rejected; reporter differenced against wrong version and ignored suppression label
  - status_banner_misleading: unresolved; screenshot lacks timestamp and banner digest
public_reply: confirmed stale CSV; no evidence of suppressed-cell leak; status-banner claim under review
anti_score: no reporter-confidence label beyond these claim outcomes
```

### 6. Escalation/cooldown/sunset note

Harbor separates three decisions.

```text
stale_csv_warning: escalate visibility for catalog-alpha/export until one clean revalidation window plus verifier packet
non_use_claim_family: standing challenge remains open
old_mirror_warning: cooldown complete after two clean windows; move to historical-only warning, keep correction chain
public_log_status: divergence note required because prior logged fixed claim is still true for old observation but not current status
```

## Consumer-facing copy

```text
Use Harbor public copy pub-claims-2026q1-r5 for new analysis.
A previously repaired catalog-alpha CSV served superseded labels again on 2026-05-15. Harbor has confirmed the stale CSV, has not confirmed the reported suppressed-cell leak, and is keeping the generated-explainer non-use claim under standing challenge until verifier evidence is available. Older repaired mirror warnings remain in the historical record; one is no longer active for new-use warnings after clean revalidation.
```

## Refusals

Harbor refuses to say:

- `catalog-alpha is unreliable`;
- `the reporter is reliable` or `the reporter is unreliable`;
- `all downstream copies are stale`;
- `consumers were harmed`;
- `the non-use claim is false`;
- `the old public log entry is wrong`;
- `the warning was deleted`;
- `sunset means the old copy was never risky`.

## Proof obligations exercised

- `PO-SR-001` through `PO-SR-006` from status reconciliation.
- `PO-SI-001` through `PO-SI-006` from stale downstream impact.
- `PO-CP-001` through `PO-CP-006` from correction propagation.
- `PO-RE-001` through `PO-RE-006` from recurrence/escalation hygiene.

## Outcome

`F085` is closed as a reversible pressure test.

No recurrence ledger, reliability note, reporter-confidence label, escalation trigger, status-sunset rule, standing-challenge registry, public warning API, external escalation workflow, regulator/auditor packet, reputation model, transparency-log policy, enforcement ladder, or final SlopOS datacube shape is promoted.
