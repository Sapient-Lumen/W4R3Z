# Specimen flow 99 — derivative correction propagation and repair acknowledgement

## Scenario

A source correction arrives after a consumer has already produced local derivatives: annotations, generated summaries, extracted subsets, local indexes, re-exported archives, cached explanations, cross-device synced copies, stale working copies, and local repair patches.

The pressure is that repair signals are attractive status shortcuts. A notification may be delivered, a user may acknowledge receipt, a sync provider may go green, an index may rebuild, a summary may be regenerated, or a stale copy may be quarantined. Those facts alone do not prove that every derivative was reached, read, repaired, revalidated, compliance-safe, or safe to treat as current.

## Required packets

- source correction packet;
- derivative inventory packet;
- propagation notice packet;
- invalidation action packet;
- consumer acknowledgement packet;
- derivative state packet;
- unreached surface packet;
- parent/child supersession packet;
- warning-label preservation packet;
- repair non-promotion packet.

## Expected accepted outcomes

Harbor may admit scoped derivative repair evidence when the record binds the source correction to the derivative inventory, carries target/prior/corrected digests, records delivery separately from read/application, preserves labels and non-promises, records invalidation or rebuild action, and reports the resulting derivative state as repaired, superseded, quarantined, partial/unknown, or notice-only.

Notice-only acknowledgement can be accepted as an acknowledgement record, not as repair. Quarantine can be accepted as stale-copy containment, not as repair. Partial propagation can be accepted when unreached surfaces remain explicit unknowns.

## Expected refusals

Harbor must reject:

- notice acknowledgement as repair;
- broadcast delivery as all derivatives reached;
- index invalidation as search-currentness;
- rebuilt summary without corrected-source digest;
- cache refresh without source revalidation;
- sync-provider green as digest verification;
- local patch that deletes warning labels;
- silent stale-copy supersession as current;
- consumer repair acknowledgement as compliance;
- repair acknowledgement with the wrong derivative digest;
- re-export parent identity overwrite;
- notification delivery as read/applied;
- latest correction as winner without scope map;
- global closure while a neighbor derivative remains stale;
- unreachable device assumed repaired after expiry;
- acknowledgement signer as source authority.

## Why this matters to SlopOS

SlopOS can show that a portal/callback/file movement completed and that bytes crossed a route. Harbor must decide what local derivatives can say after a later correction arrives. Portal completion, notification delivery, sync success, file-library upload, or consumer acknowledgement must not become repair unless the derivative material and scope are rechecked.

## Non-promotions

No derivative invalidation ledger, consumer cache API, repair attestation profile, sync-state authority, notification delivery guarantee, compliance workflow, or final SlopOS datacube shape is promoted by this specimen.
