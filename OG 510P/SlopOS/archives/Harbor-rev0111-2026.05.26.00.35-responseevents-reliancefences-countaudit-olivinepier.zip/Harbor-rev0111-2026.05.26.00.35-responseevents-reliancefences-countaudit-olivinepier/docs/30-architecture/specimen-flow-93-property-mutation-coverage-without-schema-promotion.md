# Specimen flow 93 — property/mutation coverage without schema promotion

**Followthrough:** `F093`  
**Revision:** `rev0098`  
**Focus:** generated negative coverage, invariant reuse, shrink notes, and checker sensitivity across existing executable Harbor bundles.

## Scenario

Harbor now has deterministic executable bundles for CrossingRecord evidence, transparency/provenance receipt import, and verifier disagreement. The next danger is quiet checker weakness: a bundle can pass while a checker forgets to kill a predictable counterfeit.

A reviewer asks Harbor to "make property tests". Harbor refuses to import a property-testing framework or promote a generated conformance suite. Instead it emits a deterministic meta-bundle that applies named mutations to the existing emitted bundles and requires the existing checkers to reject them.

## Baselines

The specimen imports only emitted bundles from current harnesses:

```text
crossing      -> tools/harbor_crossing_record_harness.py
receipt       -> tools/harbor_transparency_receipt_harness.py
disagreement  -> tools/harbor_verifier_disagreement_harness.py
```

Each baseline remains owned by its original specimen and checker. F093 does not rewrite their schemas or member labels.

## Property claims

The specimen names shared invariant claims:

```text
digest_binding
member_alignment
expected_admission_consistency
non_promotion_guard
accepted_subject_binding
rejected_no_record_emission
scope_or_binding_refusal
family_specific_non_promises
badge_and_currentness_refusal
hostile_fixture_explainability
```

These are labels for pressure. They are not a public schema vocabulary.

## Mutations

The meta-harness applies 38 deterministic mutations:

```text
common.bundle_digest_corrupted
common.purpose_promotes_schema
common.member_label_inserted
common.case_id_removed_from_member
common.expected_rejected_flipped_to_accepted
common.non_promotion_flag_false
common.global_count_mutated
common.rejected_case_emits_record_id
crossing.accepted_subject_digest_mutated
crossing.route_non_promises_stripped
crossing.scope_refused_widening_false
crossing.aftermath_durable_effect_overclaims
receipt.accepted_subject_digest_mutated
receipt.currentness_upgrade_allowed
receipt.verifier_decision_becomes_truth
receipt.outcome_trusted_content
receipt.aftermath_durable_effect_overclaims
disagreement.public_badge_goes_green
disagreement.majority_latest_wins
disagreement.unknown_currentness_is_fresh
disagreement.policy_digest_list_emptied
disagreement.visible_disagreement_hidden
```

Common operators run against all three bundles. Bundle-specific operators run only against the matching bundle.

## Expected result

Every current mutation must be killed by the relevant existing checker.

```text
mutation_count: 38
killed_count:   38
survived_count: 0
```

A survived mutation would be a valid F094/F095 pressure item, not an automatic failure of Harbor's conceptual model.

## Counterfeits blocked

- A generated fixture pretending to be a schema.
- A coverage number pretending to be semantic completeness.
- A passed fixture hiding checker blindness.
- A hostile mutation without a human-readable explanation.
- A killed mutation being silently promoted to a durable fixture.
- A rejected candidate being allowed to emit a durable record id.
- A green badge, latest-wins, or freshness collapse sneaking through disagreement logic.

## Non-promotions

F093 does not promote:

- property-test framework dependency;
- fuzzing harness;
- coverage threshold;
- shared bundle schema;
- generated conformance suite;
- production validator;
- public certification label;
- final SlopOS datacube shape.

## Followthrough result

`F093` is complete when the meta-bundle fixture matches deterministic harness output, all 38 mutations are killed, and `make check` runs the F090, F091, F092, F093, and repo-hygiene checks in sequence.
