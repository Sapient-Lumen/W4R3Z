# Specimen flow 45 — request-target receipt, effective-target echo, and unbounded-target warning

Goal: let Harbor describe a crossing where a client asks for one protected resource, discovers or is told which authorization server route to use, proves possession to one exact endpoint, and still needs issuance-time confirmation about what target actually survived.

## Scenario
A Harbor-hosted product wants an access token for one API surface such as `https://api.example.com/orders`.
It first learns the authorization route either from protected-resource metadata / `WWW-Authenticate` guidance or from GNAP RS-first discovery.
It then requests authorization for that resource, authenticates to the token or grant endpoint with an exact-target proof such as DPoP, and receives a successful token response.

During execution:
- the client explicitly asks for one or more `resource` values;
- the authorization route may have been discovered dynamically from the resource side;
- the proof or assertion targets one exact endpoint URI;
- the token response may return a `resource` value that matches, narrows, augments, or otherwise clarifies the effective target;
- or the token response may omit a specific returned target entirely.

Harbor must therefore preserve the difference between:
- “this is what the client asked to reach,”
- “this is the AS or token endpoint the crossing actually targeted,”
- “this is what the issuer says the result is for now,”
- “this result came back without specific returned target bounds,”
- and “none of those facts by themselves settle durable issuer, grant, account, session, or adopted consequence truth.”

## Candidate Harbor objects
1. **request-target receipt**
   - compact residue of the exact resource identifier(s) the client asked for here;
   - useful because request intent can be specific even when later discovery or issuance reshapes the answer.

2. **effective-target echo**
   - inspectable note of the `resource` value(s) the issuer returned at issuance time;
   - useful because issuance-time confirmation is stronger than discovery-time guesses without becoming durable grant truth.

3. **unbounded-target warning**
   - explicit local caution that the result did not come back with specific returned target bounds;
   - useful because omission should not be silently reinterpreted as “the originally requested target definitely survived.”

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- the same crossing carries requested resource identity, discovered AS route, exact endpoint proof target, and returned target confirmation at different stages;
- resource metadata and RS-first discovery help route the request but do not prove issuance-time target selection;
- an issuer narrows, substitutes, or omits target bounds without the product noticing;
- and an apparently successful token response still leaves ambiguity that should survive as inspectable aftermath instead of counterfeit exactness.

## Promotion rule
Do not promote `request-target receipt`, `effective-target echo`, or `unbounded-target warning` unless they improve:
- one DPoP token-endpoint `htu` specimen where proof target remains visibly separate from requested resource identity;
- one resource-response specimen where issuance-time `resource` echo beats discovery-time assumptions;
- and one GNAP RS-first or protected-resource-metadata specimen where dynamic routing remains visibly smaller than issued target truth.
