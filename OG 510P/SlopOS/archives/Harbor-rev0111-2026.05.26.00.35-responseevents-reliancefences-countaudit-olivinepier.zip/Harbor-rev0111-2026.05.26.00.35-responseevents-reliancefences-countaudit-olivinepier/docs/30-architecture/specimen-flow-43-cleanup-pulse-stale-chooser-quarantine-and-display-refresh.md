# Specimen flow 43 — cleanup pulse, stale-chooser quarantine, and display-refresh residue

Goal: let Harbor describe a crossing where remembered chooser or authenticator state is refreshed or suppressed after account changes, but the local side still refuses to treat cleanup or label refresh as durable account, session, or adoption truth.

## Scenario
A Harbor-hosted product supports browser- or authenticator-mediated sign-in.
Later, one or more of these things happens:
- the relying party deletes a passkey server-side after a failed assertion for an unknown credential;
- the relying party signs the user out locally and requests that future credential return require fresh mediation;
- or the user renames their account and the relying party asks the authenticator to refresh the displayed label for future chooser UI.

During the crossing aftermath:
- a cleanup signal may ask the authenticator or browser to hide a no-longer-accepted credential from future ceremonies;
- a full accepted-credential list may be sent, with the risk that an omitted valid credential could be hidden too aggressively;
- a display refresh may update chooser-facing name fields without proving durable account adoption;
- and some clients may not support the signal methods immediately, or the authenticator may not be attached at the time the signal is sent.

Harbor must therefore preserve the difference between:
- “the local side emitted a cleanup or mediation-reset signal,”
- “a remembered chooser/authenticator entry is now stale enough to require quarantine or revalidation here,”
- “future chooser UI may display fresher labels or require mediation again,”
- and “none of those facts by themselves settle durable issuer, account, session, or adopted consequence truth.”

## Candidate Harbor objects
1. **cleanup pulse**
   - compact advisory residue that stale chooser or authenticator state should be hidden, refreshed, or re-mediated;
   - useful because sign-out and stale-credential cleanup are meaningful aftermath without becoming universal logout or durable account deletion.

2. **stale-chooser quarantine**
   - explicit local posture for a credential or account candidate that still appears plausible in UI but is no longer safely accepted here;
   - useful because “remembered by chooser” is weaker than “accepted by local server/policy now.”

3. **display-refresh residue**
   - small note that chooser-facing `name`, `displayName`, or nearby label material was refreshed for later UI;
   - useful because a better label is still weaker than adopted identity, adopted account, or durable session truth.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- chooser or authenticator state persists beyond one completed crossing;
- cleanup and display refresh are best-effort and may be delayed, partial, or capability-gated;
- one local sign-out changes the next mediation posture without proving universal logout;
- and stale or renamed remembered entries remain weaker than durable local adoption.

## Promotion rule
Do not promote `cleanup pulse`, `stale-chooser quarantine`, or `display-refresh residue` unless they improve:
- one unknown-credential specimen where stale chooser state is hidden or quarantined rather than silently retried forever;
- one full accepted-credential-list specimen where omission risk stays visible and recoverable;
- and one display-refresh or local-sign-out specimen where fresher labels or stricter mediation posture remain visibly smaller than durable account/session truth.
