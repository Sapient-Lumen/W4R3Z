# Specimen flow 103 — foreign-import revocation and correction

## Scenario

Harbor imported companion evidence under F102.  Later, one or more companion cubes publish change notices: SlopOS withdraws an append fragment, Foundry supersedes a classification pin, Steward corrects retry history, Schell lets retention context expire, ViewFS narrows a volition card, Ward withdraws a delegation warrant, Helm disputes a repair trace, or several cubes disagree.

Harbor must record those notices without letting them rewrite history, repair downstream derivatives, or become Harbor authority.

## Required packet shape

The specimen emits a deterministic `ForeignImportRevocation` bundle with:

- parent F102 import digest and prior imported fragment identities;
- foreign notice digest, change class, issuer, clock, sealed/stale posture, and archive-digest posture;
- local impact analysis and scope comparison;
- downstream derivative quarantine posture;
- historical residue posture for the prior import;
- recheck plan with clock basis and rollback preconditions;
- explicit refusal of foreign authority, public truth, compliance, global repair, and badge shortcuts.

## Accepted specimens

The accepted cases preserve prior import history while marking current use as recheck-required, quarantined, narrowed, or historical.  A sealed notice can be retained by digest and summary limit.  Stale or conflicting companion notices can be recorded without deciding global truth.

## Rejected specimens

The rejected cases attempt to treat revocation as prior falsehood, withdrawal as downstream repair, supersession as trust promotion, dispute as falsehood, expiry as erasure or repair, re-scope as widening, revision number or notice timestamp as freshness, missing digest as acceptable, companion notice as authority, majority vote as decision, sealed notice as public truth, rollback without recheck, or consumer acknowledgement as repair.

## Audit/refactor performed in this pass

F103 also refactors checker wiring through `tools/harbor_executable_surface_registry.py`.  `tools/check_all.py` now reads the shared registry instead of carrying a separate checker list, and `tools/check_harbor_executable_surface_registry.py` audits the F090-F103 file paths, checker order, followthrough states, latest executable surface, and README executable-count wording.

The registry is deliberately smaller than a conformance registry, trust root, CI status API, or promotion gate.

## Proof posture

This closes F103 but does not promote a foreign-revocation API, foreign trust-root model, companion correction protocol, downstream repair workflow, badge semantics, compliance workflow, negligence adjudicator, or final SlopOS datacube shape.
