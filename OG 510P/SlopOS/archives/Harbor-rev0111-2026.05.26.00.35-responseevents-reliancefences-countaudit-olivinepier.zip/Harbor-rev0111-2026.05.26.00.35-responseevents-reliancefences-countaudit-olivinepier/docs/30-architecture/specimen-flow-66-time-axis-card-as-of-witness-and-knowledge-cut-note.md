# Specimen flow 66 — time-axis card, as-of witness, and knowledge-cut note

Goal: let Harbor pressure-test one realistic datacube slice where a single visible number can change depending on whether the consumer is asking about occurrence time, validity time, knowledge time, or one published cut.

## Scenario
A Harbor maintainer is reviewing a curated lane called `crossing_target_membership` that combines:
- crossing events emitted by a live service;
- target-membership rules that can become effective in the future;
- occasional late-arriving imports from an upstream partner; and
- a nightly published cut used for replay and partner export.

Three consumers ask three superficially similar but actually different questions:
1. **Operations dashboard:** “How many crossings happened on March 1?”
2. **Policy review:** “Which targets were in force for those crossings on March 1?”
3. **Historical replay:** “What answer would Harbor have published in last night’s export cut?”

An awkward fourth fact appears during review:
4. a partner sends a late backfill on March 3 for crossings that actually occurred on March 1, and one target-membership assignment was already known on February 28 but did not become valid until March 2.

## Pressure
If Harbor records only one generic timestamp, the lane can quietly confuse all of these:
- the crossing **occurred** on March 1;
- Harbor **learned/recorded** the late backfill on March 3;
- the target-membership change became **valid/in-force** on March 2 even though Harbor knew it earlier; and
- the partner export used the **published cut** from the night of March 1.

That turns one cube into a counterfeit answer machine:
- a late backfill can look like it happened on March 3 instead of March 1;
- a future-effective target rule can look valid too early;
- a replay question can silently answer from the latest head instead of the published cut; and
- different consumers can disagree without Harbor being able to explain why.

## Minimal Harbor move
Harbor keeps row meaning, contract tier, and evidence-grade posture unchanged and adds three smaller review surfaces.

### 1) Time-axis card
`crossing_target_membership` declares:
- **occurrence time** = crossing event timestamp;
- **validity time** = target-membership effective window;
- **knowledge time** = Harbor ingest/record timestamp for late imports or corrections;
- **publish cut time** = nightly export tag / snapshot;
- canonical grouping axis for operational counts = occurrence time;
- canonical policy-review axis for membership truth = validity time.

### 2) As-of witness
Each consumer answer carries an explicit witness:
- operations dashboard → **as of occurrence time** March 1 with current knowledge note;
- policy review → **as of validity time** March 1;
- historical replay → **as of published cut** `nightly-export-2026-03-01`.

If Harbor later answers “what did Harbor know on March 1?”, that would be a fourth witness: **as of knowledge time** March 1.

### 3) Knowledge-cut note
The nightly export cut records:
- cut = `nightly-export-2026-03-01`;
- included all rows known by Harbor through `2026-03-01T23:59:59Z`;
- late backfill arriving on March 3 may restate March 1 occurrence totals for later cuts;
- replay of the March 1 export remains exact for that cut even after restatement.

## Why this is better than one timestamp
- it keeps **what happened when** separate from **when Harbor learned it**;
- it keeps **valid/in-force windows** separate from both occurrence and ingest time;
- it keeps **published replayability** separate from moving-head latest answers; and
- it gives different consumers honest ways to disagree without turning the datacube into a contradiction.

## What stays deliberately open
- whether Harbor later materializes validity/knowledge windows in one engine-native temporal-table feature or keeps them as lighter review/process residue;
- whether overlap-free validity windows become enforced everywhere or only on selected published lanes;
- whether publish cuts later compile into a stronger snapshot registry.

The specimen earns one small rule only: **Harbor should not answer temporal questions until it names which time axis the answer is using.**
