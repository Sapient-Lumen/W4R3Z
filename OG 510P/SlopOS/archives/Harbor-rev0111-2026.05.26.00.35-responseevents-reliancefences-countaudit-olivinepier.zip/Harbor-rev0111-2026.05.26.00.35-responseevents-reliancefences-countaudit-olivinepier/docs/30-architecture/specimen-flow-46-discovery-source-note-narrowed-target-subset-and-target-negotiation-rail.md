# Specimen flow 46 — discovery-source note, narrowed-target subset, and target-negotiation rail

Goal: let Harbor describe a crossing where route guidance comes from different discovery sources with different validation rules, candidate token-exchange targets are scoped to a client and subject token, and issuance may accept the whole ask, return only a narrower subset, or refuse with `invalid_target`.

## Scenario
A Harbor-hosted product wants to exchange a subject token for access to one or more downstream services.
Sometimes it learns the route from protected-resource metadata discovered directly from a resource identifier.
Sometimes it learns the route from `WWW-Authenticate` guidance where RFC9728bis-style relaxed same-origin path-prefix validation may apply.
Sometimes it first asks the authorization server’s token-exchange target-service-discovery endpoint which targets are even available for this subject token and authenticated client.

During execution:
- the route may come from exact direct metadata, relaxed challenge-derived metadata, target-service discovery, or local configuration;
- the client may ask for multiple `resource` or `audience` values at once;
- the discovery endpoint may return a scoped candidate slate or nothing at all;
- issuance may accept the full target set, return only a narrower subset, add server-assigned identifiers, or refuse with `invalid_target`;
- and later refresh or follow-on requests may narrow again without expanding what the grant allowed.

Harbor must therefore preserve the difference between:
- “this is how we learned which route or targets were even in play,”
- “these are the candidates offered for this client and this subject token,”
- “this is what the client actually asked for now,”
- “this narrower subset is what survived issuance,”
- “this turn bottomed out in typed target refusal,”
- and “none of those facts by themselves settle durable issuer, entitlement, grant, account, session, or adopted consequence truth.”

## Candidate Harbor objects
1. **discovery-source note**
   - compact residue of whether discovery came from exact direct metadata, relaxed challenge-derived metadata, token-exchange target discovery, or local configuration;
   - useful because the validation rule and trust posture change with the source.

2. **narrowed-target subset**
   - inspectable note that only part of the originally requested target set survived issuance;
   - useful because subset survival is better than counterfeit exactness and smaller than durable entitlement truth.

3. **target-negotiation rail**
   - typed explanation path for intact acceptance, narrowed acceptance, or `invalid_target` refusal;
   - useful because negotiation outcomes should stay legible without becoming a giant portable target-service ladder.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- challenge-derived metadata follows different validation rules from exact direct metadata;
- discovered candidates are scoped to a particular subject token and authenticated client;
- multi-resource asks broaden rapidly and may need subset survival or refusal;
- and a returned subset or refusal should survive as inspectable aftermath instead of counterfeit durable entitlement.

## Promotion rule
Do not promote `discovery-source note`, `narrowed-target subset`, or `target-negotiation rail` unless they improve:
- one RFC9728bis-style challenge-versus-direct discovery specimen where the discovery source changes the validation rule;
- one token-exchange target-service-discovery specimen where available targets are scoped to a subject token and authenticated client;
- and one multi-resource issuance specimen where subset survival or `invalid_target` refusal remains visibly smaller than durable grant truth.
