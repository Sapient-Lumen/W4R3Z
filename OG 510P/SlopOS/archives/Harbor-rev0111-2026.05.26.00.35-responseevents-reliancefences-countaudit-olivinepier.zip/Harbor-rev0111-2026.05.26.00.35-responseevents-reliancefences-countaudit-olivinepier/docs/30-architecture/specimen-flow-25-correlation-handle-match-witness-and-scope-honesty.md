# Specimen flow 25 — correlation handle, match witness, and scope honesty

Goal: let Harbor describe how later signals and return flows find the right local lane without pretending that a scoped identifier is universal subject, account, or session truth.

## Scenario
A user completed a crossing earlier and the local product retains bounded continuity residue.
Later the product receives one of several scoped identifiers:
- an OIDC logout or Native SSO `sid`,
- an SSF / SET `sub_id`,
- a FedCM `account_hint` / `account_id`,
- or a WebAuthn `userHandle` / credential ID.

The local receiver validates the incoming structure, checks issuer/provider/RP context, and tries to match the handle against its own remembered local lane.
Sometimes the match is strong enough to narrow exactly one continuity lane.
Sometimes it is ambiguous, stale, cross-scope, or absent.
Harbor should therefore preserve the difference between:
- the incoming scoped handle,
- the local basis that justified a match,
- and the honest mismatch/quarantine path when silent overreach would be counterfeit.

## Proposed Harbor objects
1. **correlation handle**
   - scoped opaque or typed identifier used to attempt a local match;
   - examples include `iss` + `sid`, `sub_id`, `account_id`, `account_hint`, RP-scoped `userHandle`, or credential ID;
   - weaker than durable subject/account/session truth because it is only a handle inside its declared scope.

2. **match witness**
   - compact residue saying how the local product concluded that an incoming handle applied here;
   - useful because issuer-bound, provider-bound, RP-bound, and credential-bound matches are different strengths;
   - weaker than durable adoption or identity truth because it only records the basis for one local consequence.

3. **mismatch quarantine**
   - explicit posture when the handle parses but does not justify a silent local consequence;
   - useful because products need a truthful alternative to counterfeit “best effort” matching;
   - likely next steps are revalidation, chooser, inspection, or ignore-with-receipt.

4. **scope honesty**
   - standing rule that scoped handles remain visibly scoped;
   - issuer-scoped/session-scoped/provider-scoped/RP-scoped/credential-scoped identifiers must not be overread as portable global truth.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- later attenuation, logout, disconnect, or reauthentication flows need to find a local lane;
- the incoming identifier is valid and useful but only inside one issuer/provider/RP scope;
- multiple identifiers could be combined in privacy-expensive ways;
- and the right next step is quarantine or revalidation rather than silent universal logout, universal account choice, or universal session collapse.

## Promotion rule
Do not promote `correlation handle`, `match witness`, `mismatch quarantine`, or `scope honesty` unless they improve:
- one OIDC logout / Native SSO specimen where `sid` is scoped and opaque;
- one SSF / SET specimen where `sub_id` parses cleanly but still requires local resolution;
- and one FedCM or WebAuthn specimen where local matching aids remain smaller than selected-account, user identity, or durable session truth.
