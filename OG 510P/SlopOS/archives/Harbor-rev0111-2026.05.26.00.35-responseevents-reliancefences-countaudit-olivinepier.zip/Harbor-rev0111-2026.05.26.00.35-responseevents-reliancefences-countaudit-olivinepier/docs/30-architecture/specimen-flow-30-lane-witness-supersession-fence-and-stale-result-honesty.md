# Specimen flow 30 — lane witness, supersession fence, and stale-result honesty

Goal: let Harbor describe late arrivals from older auth or challenge lanes without turning them into fresh authority, portable current-session truth, or magical resume.

## Scenario
A crossing lane has already started and is meaningfully in motion.
Examples include:
- a browser-mediated OAuth/OIDC flow carrying `state`, `nonce`, and PKCE material;
- a passkey / WebAuthn authentication ceremony carrying a fresh RP-generated challenge;
- or a browser-owned chooser flow that gets restarted locally because the app changed route, mediation posture, or selected provider.

During this period, several truths can emerge:
- lane A started with one exact binder set;
- the local side later abandons, cancels, or supersedes lane A and starts lane B with fresh binders;
- lane A still returns later with a callback, ID token, authorization code, or assertion that looks valid in isolation;
- but that return no longer belongs to the live lane the local side is willing to adopt.

Harbor should therefore preserve the difference between:
- the exact witness that binds a result to one initiating lane,
- the local fact that a newer lane displaced the old one,
- the historical fact that an older lane still produced a later arrival,
- and the much stronger question of which lane, if any, may still mint local consequence.

## Proposed Harbor objects
1. **lane witness**
   - compact attempt-specific binder connecting a later callback/assertion/result to one exact initiating lane;
   - examples include `state`, `nonce`, PKCE-related lane identity, or a fresh WebAuthn challenge family;
   - useful because it keeps “belongs to this attempt” smaller than durable subject/session/account truth.

2. **supersession fence**
   - explicit local marker that a newer lane displaced an older lane for adoption purposes;
   - examples include “user restarted sign-in”, “fresh challenge issued”, or “old browser lane no longer owns local adoption rights”;
   - useful because it records local lane ownership without claiming the provider/browser/authenticator forgot the older lane.

3. **stale-result quarantine**
   - typed aftermath for a later arrival that may validate structurally yet no longer matches the live lane the local side is willing to adopt;
   - stronger than vague timeout logging because it names why the arrival cannot spend consequence, weaker than universal invalidity because the old lane may still be historically real.

4. **live-lane adoption**
   - standing rule that only the currently owned lane may mint local consequence;
   - a late old-lane completion can remain inspectable history while still being barred from adoption;
   - standing anti-regrowth rule: do not overread lane match, callback proof, or stale completion into a portable resume/current-session plane.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- local restart or supersession is the most truthful explanation of why a valid-looking later result must not be adopted;
- a challenge/callback can remain historically real without winning local consequence;
- abort or dismissal no longer implies “nothing will arrive later”;
- and exact lane ownership matters more than same-user/provider comfort.

## Promotion rule
Do not promote `lane witness`, `supersession fence`, or `stale-result quarantine` unless they improve:
- one OAuth/OIDC specimen where a fresh `state`/`nonce` lane supersedes an older browser lane;
- one WebAuthn specimen where a later response from an earlier challenge is visibly stale rather than silently adopted;
- and one abort/restart specimen where Harbor records a late old-lane arrival historically without inventing a portable current-session or resume plane.
