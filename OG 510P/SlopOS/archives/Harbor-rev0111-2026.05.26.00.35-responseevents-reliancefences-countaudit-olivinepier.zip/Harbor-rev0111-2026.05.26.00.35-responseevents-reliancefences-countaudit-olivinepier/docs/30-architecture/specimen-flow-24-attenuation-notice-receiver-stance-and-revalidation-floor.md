# Specimen flow 24 — attenuation notice, receiver stance, and revalidation floor

Goal: let Harbor describe later auth/session drift without pretending that an outside signal is a command, a universal logout, or a portable live-session truth plane.

## Scenario
A user completed a crossing earlier and the local product still has bounded continuity residue.
Later, an identity or security system sends a Security Event Token / Shared Signals event such as `session-revoked`, `risk-level-change`, or `credential-change`.
The local receiver validates the event, matches it against its own remembered continuity/session context as best it can, and then decides what local consequence to apply.
That consequence might be to keep the current posture, narrow it, require revalidation, or force a colder restart through chooser/login.
Harbor should therefore preserve the difference between:
- the outside event statement,
- the local receiver’s chosen stance after interpretation,
- and the next user-visible floor once silent continuity is no longer honest.

## Proposed Harbor objects
1. **attenuation notice**
   - typed outside statement that session, credential, token-claims, device-compliance, assurance, or risk posture changed;
   - useful because it names later drift without rewriting the earlier crossing;
   - weaker than a local command or universal verdict because the receiver still decides what to do.

2. **receiver stance**
   - explicit local reaction after validating and interpreting the notice;
   - likely values look like keep, narrow, revalidate, or cold-start;
   - weaker than durable account/session truth because it is still a current local stance, not a universal statement about every layer.

3. **revalidation floor**
   - next required posture once smooth continuity is no longer honest;
   - useful because many products need to say “prove it again” without claiming total logout, deletion, or compromise everywhere.

4. **signal drift honesty**
   - standing rule that later signals may narrow a once-acceptable crossing;
   - important because the past crossing can remain historically true while the present continuation becomes weaker or invalid.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- a previously successful crossing is later narrowed by a session, credential, or risk event;
- delivery and acknowledgement of the event tempt designers to overread transport success as local consequence;
- the right next step is explicit revalidation or cold-start rather than counterfeit seamless continuity;
- and neighboring cubes still own stronger truths such as durable trust verdicts, generic live watch surfaces, or durable session/account state.

## Promotion rule
Do not promote `attenuation notice`, `receiver stance`, `revalidation floor`, or `signal drift honesty` unless they improve:
- one CAEP specimen where `session-revoked` or `risk-level-change` demotes a previously smooth return path;
- one SET/SSF specimen where event delivery succeeds but the receiver still chooses its own consequence;
- and one shell/product specimen where the next visible posture becomes revalidation or cold-start instead of a vague “session error” blob.
