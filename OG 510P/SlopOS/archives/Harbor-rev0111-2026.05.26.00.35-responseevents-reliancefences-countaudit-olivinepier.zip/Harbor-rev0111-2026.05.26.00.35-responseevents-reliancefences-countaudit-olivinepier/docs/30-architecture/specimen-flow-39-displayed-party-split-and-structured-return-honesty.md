# Specimen flow 39 — displayed-party split and structured return honesty

Goal: let Harbor describe a host-owned crossing surface that may need to show both the embedding site and the embedded requester, while a structured return package comes back later, without letting any of that UI or packaging masquerade as durable issuer, account, approval, or session truth.

## Scenario
A user is on `top-frame.example`, which embeds `widget.example` in a cross-origin iframe.
The embedded service initiates a browser-mediated identity crossing:
- the browser-owned surface may show the top-level site plus the embedded requester because one displayed party is no longer enough for honest orientation;
- the identity provider may still supply high-level branding, labels, or account pictures;
- the eventual return may arrive as a structured JSON object rather than a simple string blob;
- and exact issuer / redirect / lane binding must still decide whether the local side may adopt consequence.

During the crossing, several pressure points appear:
- the human needs to understand who is embedding whom without confusing either displayed party with durable issuer truth;
- the returned package may become richer and easier to inspect without becoming durable account/session truth;
- client-supplied display metadata can still be useful while remaining advisory;
- and exact basis checks must still veto a pretty but mismatched result.

Harbor should therefore preserve the difference between:
- “this was the top-level site shown on the host-owned surface,”
- “this was the embedded requester or iframe-origin cue shown on the host-owned surface,”
- “this was the structured return parcel that came back from the crossing,”
- and “none of those facts by themselves settled adopted account, durable session, issuer identity, or approved consequence.”

## Candidate Harbor objects
1. **displayed-party split**
   - residue that the host-owned surface needed to show more than one relevant party;
   - useful because one provenance cue may be too weak in embedded third-party crossings.

2. **embedded-party cue**
   - specific cue for the embedded requester or iframe-origin party shown beside the top-level site;
   - useful because it names the service actually asking without flattening it into durable issuer/account truth.

3. **return parcel**
   - structured result package returned from the crossing;
   - useful because packaging can be richer than a string while still staying smaller than durable consequence.

4. **exact-basis veto**
   - reminder that issuer, redirect, request-basis, and lane checks still own local adoption rights;
   - useful because it stops attractive UI or tidy JSON from becoming counterfeit truth.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- more than one displayed party matters on the same surface;
- result packaging gets richer;
- old display-metadata pressure remains active;
- and exact binding still needs to outrank appearance.

## Promotion rule
Do not promote `displayed-party split`, `embedded-party cue`, `return parcel`, or `exact-basis veto` unless they improve:
- one embedded third-party FedCM specimen where top-level and embedded requester cues both matter for honest orientation;
- one structured-return specimen where richer packaging still remains smaller than durable account/session/adoption truth;
- and one exact-binding specimen where stored issuer/request/lane truth cleanly vetoes a visually convincing but mismatched result.
