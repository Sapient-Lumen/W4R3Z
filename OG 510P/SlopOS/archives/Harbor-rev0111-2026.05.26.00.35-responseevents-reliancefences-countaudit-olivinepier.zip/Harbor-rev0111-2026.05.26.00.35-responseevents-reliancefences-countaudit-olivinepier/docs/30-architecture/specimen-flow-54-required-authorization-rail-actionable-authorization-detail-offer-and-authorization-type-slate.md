# Specimen flow 54 — required-authorization rail, actionable authorization-detail offer, and authorization-type slate

Goal: let Harbor describe a crossing where a protected resource accepts that the token targets the right resource family, decides the current operation is missing structured authorization details, advertises acceptable type combinations in protected-resource metadata, optionally returns an actionable `authorization_details` object in the error body, and later receives a token whose granted details remain smaller than durable entitlement truth.

## Scenario
A Harbor-hosted client wants to call `https://api.example.com/payments/123/approve`.
The token is already acceptable for the payments resource family and the user already passed a recent-enough authentication step for this endpoint family. The current problem is not “wrong audience” and not “step up required here”; it is that the resource server requires a structured authorization-details combination describing payment approval.

The resource server's protected-resource metadata advertises:
- `authorization_servers` containing the two ASs that may issue tokens for this API; and
- `authorization_details_types_supported` with a required-types expression equivalent to “`payment_approval` and one of `beneficiary_designation` or `payment_risk_acknowledgement`”.

The client presents a token that lacks the needed structured authorization details.
The resource server responds with:
- `403 Forbidden`;
- `WWW-Authenticate: Bearer error="insufficient_authorization_details"`;
- `resource_metadata=` pointing to the protected-resource metadata document; and
- an optional JSON body containing an `authorization_details` array with a concrete approval object the client MAY reuse in the next OAuth + RAR request.

At this point Harbor must preserve five truths at once:
- the token is **target-valid here** enough for the resource server to explain the finer problem;
- the failure is a **required-authorization rail**, not an audience mismatch and not a generic invalid-token ending;
- the error-body object is an **actionable authorization-detail offer**, not approved entitlement truth;
- the metadata expression is an **authorization-type slate**, not Harbor’s permanent global type lattice; and
- any later token/introspection-visible `authorization_details` may still be filtered, enriched, or narrowed for the receiving RS.

## Why Harbor needs a new specimen
Without this specimen, Harbor risks either:
1. flattening structured authorization-detail demands into coarse scope or generic auth failure; or
2. overreacting by inventing a portable authorization policy / entitlement registry too early.

This specimen keeps the middle path: the resource server can teach the client what is missing for **this** request, while Harbor still refuses to claim global policy truth.

## Suggested Harbor handling
- Preserve a **required-authorization rail** when a resource server says richer structured authorization is required.
- Preserve an **authorization-type slate** when metadata or challenge context names acceptable type combinations.
- Preserve an **actionable authorization-detail offer** only as request-scoped guidance for the next OAuth turn.
- Keep stronger-here authentication demands (`acr_values`, `max_age`), missing scopes, missing `authorization_details`, and final granted-detail views visibly separate even when one recovery turn satisfies all of them.
- If the next token or introspection response carries granted `authorization_details`, treat that as smaller than durable entitlement truth and potentially receiver-scoped.

## Anti-regrowth notes
- Do **not** let the actionable body masquerade as approved authorization.
- Do **not** let a required-types expression masquerade as Harbor’s portable type ontology.
- Do **not** let “required here” silently collapse scope, authentication strength, and authorization-details into one hierarchy.
- Do **not** let later granted or RS-filtered `authorization_details` silently become durable entitlement or account/session truth.
