# Specimen flow 90 — portal-net crossing record fixture harness

**Revision:** `rev0095`  
**Followthrough:** `F090`  
**Status:** executable pressure-test specimen; not a schema, SlopOS import contract, public JSON profile, credential trust profile, MCP integration, status API, compliance workflow, or final SlopOS datacube shape.

## Scenario

Harbor receives mixed crossing evidence after `rev0094`:

1. SlopOS emits portal-network request route/admission evidence.
2. SlopOS emits checkpoint/resume/truncation/append evidence for accepted-only durable history.
3. A malformed crossing candidate includes an ambient truth field.
4. A candidate binds the wrong subject digest.
5. A browser detour returns through a callback continuation.
6. An MCP/tool resource card claims helpful metadata.
7. A browser-mediated credential presentation returns a scoped credential result.
8. A public-copy generated explainer becomes stale after a prior warning/recheck window.
9. A public status banner says `resolved` without the Harbor warning lifecycle basis.
10. A source-owner ticket attempts to make a later public-global explainer claim override public-US canonical scope.

## Executable packet

The specimen is the fixture at:

```text
fixtures/harbor-crossing-record-evidence-bundle-v0.json
```

It is emitted by:

```text
tools/harbor_crossing_record_harness.py --emit-bundle
```

and checked by:

```text
tools/check_harbor_crossing_record_bundle.py
```

## Expected Harbor behavior

- Harbor accepts `accept-portal-net-request-route-admission` only as route/admission residue with `not_transport_trust`, `not_content_truth`, `not_current_lease`, and `not_user_comprehension`.
- Harbor accepts `accept-portal-net-resume-truncation-append` only as same-scope accepted-prefix evidence with discarded suffix and denied/duplicate durable-state refusals.
- Harbor rejects `reject-malformed-envelope-ambient-field` because no crossing candidate may smuggle `ambient_truth`.
- Harbor rejects `reject-subject-digest-mismatch` before aftermath because subject digest binding failed.
- Harbor accepts `accept-callback-continuation-boundary` as a local continuation, not remote authority or local adoption.
- Harbor accepts `accept-mcp-tool-metadata-untrusted` as displayed metadata only, not tool annotation truth or consent proof.
- Harbor accepts `accept-browser-credential-presentation` as scoped presentation only, not global identity or global authorization.
- Harbor accepts `accept-public-copy-aftermath-warning` as stale observation within named public-copy aftermath scope, not compliance or all-agent correction.
- Harbor refuses `reject-global-resolution-overclaim` because `resolved` is not supported by warning lifecycle receipts and non-promises.
- Harbor rejects `reject-latest-wins-scope-substitution` because latest evidence cannot replace scope comparison.

## Proof obligation pressure

This specimen exercises:

- `PO-XE-001` executable bundle proof;
- `PO-XE-002` route-family non-promise proof;
- `PO-XE-003` subject digest and hostile-envelope proof;
- `PO-XE-004` callback/tool/credential humility proof;
- `PO-XE-005` accepted-prefix aftermath proof;
- `PO-XR-001` crossing-record scope proof;
- `PO-XR-002` hostile receipt rejection proof;
- `PO-IX-006` warning lifecycle proof.

## Non-promotion result

`F090` is complete because Harbor now has a deterministic crossing evidence bundle and checker. The result is deliberately insufficient to promote a durable schema. It only proves that future crossing-record promotions must survive executable bundle checks, negative fixtures, route-family non-promises, digest binding, and scope comparison.
