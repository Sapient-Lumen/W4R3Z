# Specimen flow 56 — schema-source note, receiver-enriched detail card, and cache-staleness detail warning

## Scenario
A client calls a protected resource and receives `403 insufficient_authorization_details` plus a `resource_metadata` pointer.
The protected-resource metadata advertises:
- accepted authorization servers;
- an `authorization_details_types_supported` expression; and
- enough routing information for the client to find the authorization server metadata.

The client then fetches the authorization server metadata and finds an `authorization_details_types_metadata_endpoint`.
That endpoint describes the needed authorization-details type using either:
- inline `schema`; or
- external `schema_uri`.

The client builds an `authorization_details` object from that shape guidance and makes a fresh OAuth request.
The authorization server grants access.
Later, the resource server sees a JWT or introspection view whose `authorization_details` are:
- filtered to that receiver; and
- extended with receiver-specific or policy-derived fields needed for request processing.

Still later, the authorization-details metadata changes, but the client reuses a cached metadata/schema response that is still within or mistakenly treated as within its local cache window.
The next constructed request bottoms out because the built detail shape no longer matches current server expectations.

At this point Harbor must preserve five truths at once:
- the client had a **schema-source note** about where shape guidance came from;
- the built request shape was a client-side construction, not permanent type law;
- the RS later saw a **receiver-enriched detail card**, not universal grant truth;
- the new failure can be a **cache-staleness detail warning** rather than wrong target, wrong account, or session collapse; and
- fetched metadata/schema remained provider-local guidance rather than Harbor-owned policy or entitlement truth.

## Why Harbor needs a new specimen
Without this specimen, Harbor risks either:
1. promoting inline or fetched schema guidance into a portable authorization ontology; or
2. flattening stale metadata/schema fallout into generic invalid-token or invalid-target endings.

This specimen keeps the middle path: Harbor can tell the truth about where shape guidance came from, what one receiver later saw, and why a stale cache changed the next turn.

## Suggested Harbor handling
- Preserve a **schema-source note** when the client learned the detail shape from inline schema, fetched `schema_uri`, or trusted local preconfiguration.
- Preserve a **receiver-enriched detail card** when a JWT or introspection view is filtered or extended for one receiver.
- Preserve a **cache-staleness detail warning** when cached metadata or schema guidance plausibly explains the mismatch on a later turn.
- Keep discovery metadata, schema source, built detail object, receiver-visible enriched detail object, and stale-cache explanation visibly separate.
- Treat metadata descriptions, examples, and fetched schemas as build-or-validate aids, not as Harbor-owned global authorization law.

## Anti-regrowth notes
- Do **not** let schema source silently become portable authorization ontology.
- Do **not** let a receiver-enriched detail card masquerade as universal grant or entitlement truth.
- Do **not** let stale-cache schema fallout silently collapse into generic invalid-token, wrong-target, or session-failure language.
- Do **not** let schema fetch/cache handling silently bloom into Harbor-owned policy, registry, or cache-coherence families.
