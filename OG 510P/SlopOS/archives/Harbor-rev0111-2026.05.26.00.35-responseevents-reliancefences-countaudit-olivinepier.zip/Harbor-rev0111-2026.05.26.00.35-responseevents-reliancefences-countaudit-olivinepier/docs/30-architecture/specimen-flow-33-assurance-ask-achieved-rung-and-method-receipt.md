# Specimen flow 33 — assurance ask, achieved rung, and method receipt

Goal: let Harbor describe requested assurance pressure and returned verification/method evidence without turning them into a portable assurance registry, recent-login oracle, or durable account/session truth.

## Scenario
A crossing begins with a request for stronger authentication than the ambient or earlier path would normally require.
Examples include:
- an OIDC client or protected resource requesting specific `acr` values or stronger/fresher authentication before a privileged action;
- a browser or RP starting a WebAuthn ceremony with `userVerification` set to `required` for a sensitive step;
- or a deployment that allows synced passkeys for ordinary sign-in but requires device-bound passkeys or stronger verification posture for high-privilege access.

During this period, several truths can emerge:
- some caller, RP, or resource asks for a stronger assurance rung;
- the actual finished crossing may achieve one particular rung or fail to reach the requested rung;
- returned evidence may explain *how* the crossing happened, such as `amr` values, a UV flag, or device-bound-versus-synced passkey posture;
- and the correct local outcome may still be refusal, retry, or step-up because the requested rung could not be met here now.

Harbor should therefore preserve the difference between:
- “a stronger rung was requested,”
- “this is the rung the crossing actually achieved,”
- “these are the methods or verification properties that explain the crossing,”
- and “the requested rung could not be met here now.”

## Proposed Harbor objects
1. **assurance ask**
   - typed request for a stronger or more specific authentication/verification rung;
   - useful because it keeps demanded assurance visible without pretending the demand was satisfied.

2. **achieved rung**
   - inspectable residue naming the actual assurance class or verification rung this crossing achieved;
   - stronger than the ask because it reflects what really happened, weaker than durable local approval because policy may still reject or further narrow it.

3. **method receipt**
   - compact evidence about the methods or verification properties actually used, such as `amr`, UV, or device-bound posture;
   - useful because it explains the achieved rung while staying smaller than a universal assurance taxonomy.

4. **unable-here honesty**
   - explicit local bottom-out when the requested rung cannot be met here now or cannot be proven here now;
   - standing anti-regrowth rule: do not let method labels or verification bits masquerade as portable assurance truth.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- assurance pressure can be advisory or essential;
- method evidence explains a crossing without universally ranking it;
- higher-privilege paths need stronger local policy than ordinary sign-in;
- and the truthful ending may be “try a stronger route” or “not sufficient here” rather than counterfeit success.

## Promotion rule
Do not promote `assurance ask`, `achieved rung`, or `method receipt` unless they improve:
- one OIDC specimen where `acr_values` or essential `acr` requests stay visibly separate from the returned `acr`/`amr` result;
- one WebAuthn specimen where `userVerification` pressure and UV-bit evidence stay visibly separate from adoption truth;
- and one mixed-passkey specimen where synced versus device-bound posture matters to local policy without becoming a portable assurance registry.
