# Specimen flow 71 — measurement-kind card, canonical-unit note, display-unit note, and currency-rate witness

Goal: let Harbor pressure-test one realistic datacube slice where several scalar-looking outputs all seem “simple” even though they carry different measurement promises.

## Scenario
A Harbor maintainer is reviewing three curated lanes for queue and payout reporting:
- `queue_service_duration` — producer-native request latency rows arriving from two sources, one in milliseconds and one in seconds;
- `queue_success_ratio` — a fraction computed from numerator/denominator components and rendered as a dashboard percent; and
- `partner_payout_amount` — monetary rows reported in original local currency, with one downstream board view asking for converted USD totals.

A reviewer proposes a convenience export with four columns:
- `duration = 250`
- `success_rate = 97.5`
- `amount = 1234.56`
- `unit = "mixed"`

The board deck also wants a human-friendly version:
- duration shown in `ms` for short requests and `s` for long requests;
- success ratio shown as a `%`;
- payout amounts converted to `USD` at a month-end reference rate.

## Pressure
If Harbor publishes all of this as one generic scalar surface, several wrong things can happen:
- milliseconds and seconds can silently mix inside one duration lane;
- a ratio in unity form can be mistaken for a pre-scaled percent;
- original currency amounts can be mistaken for already-converted comparable money;
- late FX restatements can silently rewrite old “USD totals” without any basis witness;
- human display suffixes can counterfeit machine-comparable coded units.

That turns one cube into a counterfeit-measurement machine:
- display-friendly units start masquerading as canonical units;
- percent render starts masquerading as stored ratio semantics;
- converted money starts masquerading as original-denomination truth; and
- one scalar-looking lane starts pretending it has one shared conversion discipline.

## Minimal Harbor move
Harbor keeps grain, time-axis posture, exactness posture, and change-history posture unchanged and adds four smaller review surfaces.

### 1) Measurement-kind card
Each lane declares its quantity kind:
- `queue_service_duration` = **duration**;
- `queue_success_ratio` = **ratio/utilization**;
- `partner_payout_amount` = **money**.

That alone blocks one dangerous collapse: scalar shape no longer implies semantic sameness.

### 2) Canonical-unit note
Each lane says what coded unit Harbor treats as machine-comparable:
- duration lane may normalize to `s` or may remain source-native with explicit per-row code;
- ratio/utilization lane uses unity `1`, not percent;
- money lane uses original ISO 4217 currency code for source truth.

### 3) Display-unit note
Human rendering stays explicit and weaker than coded machine basis:
- dashboards may render duration in `ms` or `s` depending on scale;
- ratios may render as `97.5%` while the stored semantic is still `0.975` in unity form;
- money may render with locale-aware symbol/formatting without erasing the underlying currency code.

### 4) Currency-rate witness
Any converted-money lane records:
- source currency and target currency;
- rate source / authority;
- as-of basis and time axis;
- rounding/minor-unit posture;
- whether the converted value is original publication, derived view, or later restatement.

## Why this is better than one generic scalar lane
- it keeps **quantity kind** separate from **scalar shape**;
- it keeps **coded machine unit** separate from **display render unit**;
- it keeps **ratio semantics** separate from **percent formatting**; and
- it keeps **original money** separate from **converted money with a rate basis**.

## What stays deliberately open
- whether Harbor later standardizes one cross-lane unit registry;
- whether canonical-unit notes later become machine-readable sidecars;
- whether display-unit notes are per-lane, per-consumer, or per-render target;
- whether rate witnesses later point to explicit FX-rate lanes or only to reviewed external references.

The specimen earns one small rule only: **Harbor should not publish a measured scalar without saying what kind of quantity it is, what coded unit it rests on, and whether any displayed or converted form is weaker than that basis.**
