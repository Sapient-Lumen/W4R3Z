# Specimen flow 97 — artifact handoff and consumer import

## Scenario

A Harbor release package has been produced. Downstream consumers encounter it through several different paths:

1. a downloaded release zip;
2. an extracted directory;
3. a copied fixture file;
4. a pasted digest in chat;
5. a renamed archive;
6. a file-library upload;
7. a portal/callback-mediated transfer;
8. a downstream repack.

The specimen asks which facts can travel and which must be refused.

## Required packets

- `release_claim_packet`
- `transport_observation_packet`
- `material_identity_packet`
- `consumer_verification_packet`
- `scope_comparison_packet`
- `handoff_verdict_packet`

## Expected behavior

Harbor admits a handoff/import statement only when consumer-side material exists, the digest scope matches the material, archive/tree/fixture context is present, and the allowed statement stays scoped to the observed material.

Harbor refuses transport-only confidence. Filename, upload path, upload time, callback success, pasted digest text, and consumer acknowledgement are route or communication evidence, not import identity.

## Hostile cases

- `filename_only_match`
- `pasted_digest_without_material`
- `renamed_archive_name_as_identity`
- `extracted_tree_missing_archive_index`
- `copied_fixture_without_parent_bundle`
- `file_library_upload_timestamp_as_freshness`
- `portal_callback_success_as_verification`
- `zip_digest_applied_to_extracted_tree`
- `downstream_repack_digest_mismatch`
- `hidden_generated_artifact_added`
- `consumer_ack_as_reliance_claim`

## Proof obligations exercised

- `PO-HI-001` — release-claim versus material proof
- `PO-HI-002` — transport non-authority proof
- `PO-HI-003` — digest-scope proof
- `PO-HI-004` — derived tree / copied fixture context proof
- `PO-HI-005` — consumer acknowledgement non-promotion proof
- `PO-HI-006` — handoff non-promotion proof

## Non-promotions

The specimen does not promote a consumer verification API, handoff attestation, package trust root, CI status API, artifact-security guarantee, file-library authority model, callback authority model, or final SlopOS datacube shape.
