# Specimen flow 18 — route ceiling, refinement rail, and fallback honesty

Goal: allow late route updates to narrow or exclude within a predeclared ceiling without pretending they widened authority or erased graceful fallback.

## Scenario
A local app declares a broad verified/native route for its own domain.
Later, server-side rules narrow eligible paths and explicitly exclude a short-lived campaign URL plus one risky query-parameter pattern.
Newer platforms merge the refinement layer and stop opening those URLs natively; older platforms ignore the refinement and keep the static route ceiling only.
When the user opens one of the excluded links, the truthful outcome is a web landing, chooser turn, or refusal card rather than counterfeit native certainty.

## Proposed Harbor objects
1. **route ceiling**
   - predeclared maximum eligible native scope;
   - stronger than affiliation and weaker than actual admission.

2. **refinement rail**
   - late-arriving narrowing logic applied within that ceiling;
   - stronger than marketing/config folklore and weaker than durable trust.

3. **exclusion rail**
   - explicit negative rule that removes paths, fragments, or query patterns from otherwise eligible native handling;
   - stronger than vague fallback advice and weaker than route ownership.

4. **fallback honesty**
   - typed aftermath telling the truth that the route degraded to web, chooser, or no-action;
   - stronger than a silent no-op and weaker than adopted success.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- affiliation is verified but late routing policy changes,
- some platforms understand the refinement layer and others do not,
- exclusions are intentional and useful rather than accidental breakage,
- and the most truthful outcome is graceful fallback instead of “native won” or “everything failed”.

## Promotion rule
Do not promote `route ceiling`, `refinement rail`, `exclusion rail`, or `fallback honesty` unless they improve:
- one verified-native route that later narrows,
- one explicit exclusion specimen that truthfully falls back,
- and one mixed-version compatibility specimen where the static ceiling remains honest even without the refinement layer.
