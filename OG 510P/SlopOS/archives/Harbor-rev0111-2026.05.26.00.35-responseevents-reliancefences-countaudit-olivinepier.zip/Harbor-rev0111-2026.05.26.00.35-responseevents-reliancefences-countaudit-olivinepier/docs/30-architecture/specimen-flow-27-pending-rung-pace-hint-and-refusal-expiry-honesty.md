# Specimen flow 27 — pending rung, pace hint, and refusal/expiry honesty

Goal: let Harbor describe in-flight mediated crossings that can wait, back off, be explicitly refused, go quietly cold, or expire — without pretending any of those are durable account/session truth.

## Scenario
A crossing has been launched but is not yet complete.
Examples include:
- a device authorization flow that returns a user code and asks the client to poll;
- a browser/provider turn that can only proceed after explicit user interaction;
- a chooser-light credential flow that the user may quietly dismiss;
- or a passkey/federation ceremony that can be aborted, refused, or simply left unfinished until it expires.

During this period, the requester may learn one of several very different truths:
- the crossing is still pending;
- the provider asks the requester to slow down or wait longer;
- the user/provider/local policy explicitly refuses the turn;
- the user simply dismisses or abandons the UI without a crisp denial verdict;
- or the bounded crossing expires and must be restarted fresh.

Harbor should therefore preserve the difference between:
- in-flight pending posture,
- optional pacing guidance,
- explicit refusal,
- and honest cold/expired endings.

## Proposed Harbor objects
1. **pending rung**
   - explicit statement that the crossing is still in flight and has not yet bottomed out into success, refusal, or expiry;
   - examples include RFC 8628 `authorization_pending` or a browser-mediated turn waiting on user action;
   - weaker than durable success and weaker than durable denial because the crossing is still unresolved.

2. **pace hint**
   - optional guidance about when or how aggressively to retry or refresh;
   - examples include RFC 8628 `slow_down`, poll interval hints, or UI posture that says “wait for user action” rather than spinning blindly;
   - useful because it shapes safe follow-up behavior without becoming approval truth.

3. **refusal rail**
   - typed bottom-out for explicit non-completion;
   - examples include OAuth `access_denied`, OIDC `login_required` / `consent_required` / `account_selection_required`, user-declined WebAuthn, or a local policy refusal after inspection;
   - stronger than pending and still smaller than durable account/session truth because it only says this crossing did not complete in the requested way.

4. **expiry honesty**
   - standing rule that expiration, concluded pending windows, and quiet abandonment remain visibly different from approval and from one universal denial story;
   - includes cold endings such as dialog dismissal, chooser abandonment, or expired device-code sessions that require a fresh start;
   - useful because products need a truthful alternative to counterfeit “still pending forever” or counterfeit “the user denied it.”

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- a crossing remains truly unresolved for a while;
- an issuer/provider gives a real backoff signal;
- some non-success endings are explicit refusals while others are quiet abandonment or expiry;
- and local UX needs inspectable residue rather than a single vague failure state.

## Promotion rule
Do not promote `pending rung`, `pace hint`, `refusal rail`, or `expiry honesty` unless they improve:
- one RFC 8628 specimen where `authorization_pending`, `slow_down`, and `expired_token` remain visibly distinct;
- one OIDC/OAuth specimen where typed refusal/UI-required bottoms remain more precise than generic failure;
- and one browser-mediated chooser specimen where dismissal/abandonment does not counterfeit explicit denial.
