# Specimen flow 62 — change-class card, shadow diff, and retirement reservation note

Goal: let Harbor pressure-test one realistic published-lane change without pretending that rename, recalculation, assertion tightening, and historical restatement are all the same thing.

## Scenario
A Harbor maintainer has one published curated lane used by three downstream consumers.
They want to:
1. rename `receiver_label` to `displayed_party_label`;
2. split one overloaded status family into two clearer values;
3. tighten the freshness expectation from 24 hours to 6 hours; and
4. backfill 90 days of history after discovering a late-arriving enrichment source.

At the same time:
- one dashboard consumer still selects the old field name;
- one operational consumer depends on the freshness assertion; and
- one analyst needs reproducible pre-restatement history.

## What this proves
Harbor needs to keep these facts separate:
- whether the field rename is **shape-bridged** rather than magically “no change”;
- whether the status split is a **meaning reinterpretation** even if the column names and types look close;
- whether the freshness tightening is **assertion/service-only** rather than a semantic rewrite;
- whether the 90-day backfill is a **historical/restatement** event; and
- which consumer slices are actually affected by each of those changes.

## Suggested Harbor handling
1. **Change-class card**
   - Harbor records one change-class card covering the proposed edit set.
   - The rename is marked **shape-bridged**.
   - The status split is marked **meaning-reinterpreting** unless Harbor can truly prove it is only clarifying.
   - The freshness tightening is marked **assertion-only / service-only**.
   - The 90-day backfill is marked **historical/restatement**.

2. **Compatibility verdicts**
   - The rename earns **safe with bridge window** only if Harbor keeps an overlap form explicit.
   - The status reinterpretation earns **successor required** unless it is proven to be only clarifying.
   - The freshness change may be **safe in place** for shape consumers but still requires explicit notice for consumers pinned to service/assertion posture.
   - The backfill earns **historical restatement** and must leave a restatement receipt plus a frozen historical reference.

3. **Bridge window**
   - Harbor keeps `receiver_label` available alongside `displayed_party_label` for a bounded overlap period or equivalent alias/projection bridge.
   - The bridge window names affected consumers, warning posture, and bridge expiry.
   - The old identifier is not silently recycled for a new meaning once the bridge ends.

4. **Shadow diff**
   - Harbor runs a shadow diff across the current published lane and the candidate lane.
   - Shape differences, value differences, and assertion/service differences are reported separately.
   - Evidence rows/aggregates can be attached as derived artifacts, but the compatibility verdict stays on the review surface.

5. **Retirement reservation note**
   - When `receiver_label` finally retires, Harbor leaves a reservation note so the identifier is not casually reused for an unrelated meaning in the same family.
   - The note is process residue, not a giant registry.

## Why this specimen matters
Without this specimen, Harbor risks two bad patterns:
1. a rename-plus-recalculation sneaks through under the banner of “compatible enough”; or
2. Harbor overreacts and versions every tiny additive or assertion-only change forever.

This specimen keeps the middle path: **classify first, verdict second, bridge only when necessary, and keep historical corrections explicit.**

## Anti-regrowth notes
- Do **not** let alias/dual-field bridges masquerade as semantic sameness.
- Do **not** let a green shadow diff on one consumer slice counterfeit universal compatibility.
- Do **not** let assertion tightening sneak in under a shape-only review.
- Do **not** let a published identifier disappear and later reappear with a new meaning absent a retirement reservation note.
- Do **not** let a historical backfill rewrite reproducible history without a restatement receipt or frozen historical reference.
