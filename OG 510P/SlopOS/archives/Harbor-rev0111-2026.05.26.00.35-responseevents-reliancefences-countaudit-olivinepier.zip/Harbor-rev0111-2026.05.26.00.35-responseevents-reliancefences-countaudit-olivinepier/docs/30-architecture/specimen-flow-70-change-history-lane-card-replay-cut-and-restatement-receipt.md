# Specimen flow 70 — change-history lane card, replay cut note, and restatement receipt

Goal: let Harbor pressure-test one realistic datacube slice where several exports all look like “history” even though they carry different replay promises.

## Scenario
A Harbor maintainer is reviewing three curated lanes for a receiver-target alignment surface:
- `target_alignment_current`, a current-state lane with one latest row per receiver/target pair;
- `target_alignment_changed_rows_since_cut`, an incremental lane that emits the latest values for rows changed after a commit cut so downstream materializations can refresh efficiently; and
- `target_alignment_changes`, a change-history lane intended for audit/replay and downstream append-only sync.

A correction arrives a week later because one upstream import replayed late receiver mappings and Harbor recomputes the historical alignment story for three prior days.

A dashboard author now asks for three seemingly simple outputs:
1. **Current alignment** for today.
2. **What changed this week** in order.
3. **Reconcile last week’s published counts** after the late replay.

A dangerous fourth convenience appears during review:
4. One downstream export flattens `target_alignment_changes` to after-only payloads because its sink only likes append-only rows and cannot handle deletes.

## Pressure
If Harbor publishes all four surfaces as generic “history” tables, several wrong things can happen:
- a current-state lane can be mistaken for an audit trail;
- a changed-rows export can be mistaken for every intermediate change that happened in the period;
- a net or after-only export can erase deletes and update-before images that matter for replay;
- copy-on-write carry-over rows can look like business changes; and
- a late historical correction can silently change previously published numbers without leaving any visible residue.

That turns one cube into a counterfeit-history machine:
- current state starts masquerading as history;
- changed rows start masquerading as ordered change events;
- append-only transport format starts masquerading as faithful CDC semantics; and
- corrected historical cuts start masquerading as if they had always been true.

## Minimal Harbor move
Harbor keeps grain, time-axis posture, change-class posture, and evidence posture unchanged and adds four smaller review surfaces.

### 1) Change-history lane card
Each lane declares:
- `target_alignment_current` = **current-state lane**;
- `target_alignment_changed_rows_since_cut` = **changed-rows lane** and not a guarantee of every intermediate change;
- `target_alignment_changes` = **change-history lane** with typed operations;
- any collapsed “diff since X” export = **net-change lane** and not a replay log.

### 2) Replay cut note
Every history-shaped lane records:
- whether the slice is defined by commit range, snapshot range, or timestamp range;
- whether the cut is commit/knowledge time or event/occurrence time;
- whether the head is moving or frozen;
- whether late-arriving rows can still restate the slice.

### 3) Carry-over veto
If the substrate emits copy-on-write preservation rows or other rewrite artifacts, Harbor marks them as physical carry-over rather than logical business change.
The lane may still preserve them for debugging, but it should not advertise them as first-class business history.

### 4) Restatement receipt
When the late replay recomputes the prior three days, Harbor records:
- which published cuts changed;
- why the restatement happened;
- whether old and new numbers are directly comparable;
- whether downstream consumers need replay or re-baselining.

## Why this is better than one generic history label
- it keeps **current state** separate from **ordered change history**;
- it keeps **incremental changed rows** separate from **all intermediate changes**;
- it keeps **append-only transport** separate from **faithful CDC semantics**; and
- it keeps **restated history** separate from **unchanged prior publication**.

## What stays deliberately open
- whether Harbor later standardizes one cross-engine operation-code family;
- whether update-before/update-after images are required or only optional;
- whether restatement receipts later become machine-readable and promotion-gated;
- whether net-change lanes later get their own first-class publishing path.

The specimen earns one small rule only: **Harbor should not publish “history” without saying what kind of history it is, what cut it covers, and whether that history was later corrected.**
