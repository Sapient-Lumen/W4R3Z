# Specimen flow 79 — public-copy labels, mirror hygiene, and restatement receipts

This specimen pressure-tests `F079`.

Scenario: specimen flow 78 produced a disclosure-treated public aggregate for callback success by route family and week. The internal frozen answer remains exact, but the public copy carries coarsening, suppression, perturbation, non-DP, structural-zero, and additivity labels. The answer now leaves Harbor through BI export, CSV download, a public mirror, a PDF/chart, and a consumer proof request.

The release was reviewed. The copies can still be wrong.

## Inputs
- internal answer: `answerpack-callback-public-2026-05-13T22:20Z`
- source cut: `cut-callback-2026-05-13T22:00Z`
- public release artifact: `pub-callback-route-week-2026-05-13-r1`
- disclosure treatment:
  - provider-family cells collapsed;
  - one fine cell suppressed;
  - one weekly count perturbed;
  - public subtotals may not sum exactly to public totals;
  - no differential-privacy claim;
  - structural zeros and suppressed zero-like displays are separately labeled.
- required labels:
  - `disclosure_treated`;
  - `not_exact_public_copy`;
  - `coarsened_for_disclosure`;
  - `suppressed_cells_present`;
  - `perturbed_release`;
  - `not_a_dp_claim`;
  - `additivity_weakened`;
  - `structural_zero_labels_present`;
  - `source_cut=cut-callback-2026-05-13T22:00Z`;
  - `public_artifact=pub-callback-route-week-2026-05-13-r1`.

A naive system would export the displayed table and forget the labels. Harbor refuses.

## Candidate copy rows

### PC-79-01 — BI export preserves labels
- class: `valid_labeled_public_copy`
- copy: BI dashboard tile plus export bundle
- preserved labels: all required labels plus visible footnote and machine-readable sidecar
- digest posture: payload digest and label-sidecar digest bound by release artifact receipt
- mirror posture: fresh as of release time
- verdict: `copy_valid_for_public_use`
- anti-counterfeit warning: dashboard display is not enough; labels must survive export and proof

Healthy behavior: Harbor allows the copy because both payload and labels are bound. The BI display may be pretty, but its validity comes from the receipt, not the pixels.

### PC-79-02 — CSV mirror strips suppression and noise labels
- class: `label_stripped_copy`
- copy: downstream CSV mirror containing only route/week/count columns
- stripped labels: `suppressed_cells_present`, `perturbed_release`, `not_exact_public_copy`, `not_a_dp_claim`
- digest posture: payload rows may match one projection, but the required label digest is absent
- verdict: `mirror_invalid_until_repaired`
- anti-counterfeit warning: data bytes without labels can counterfeit exact public truth

Healthy behavior: Harbor does not say the data is absent or malicious. It says this mirror is not a valid public copy of the release until labels are restored or a safe coarser projection is emitted.

### PC-79-03 — restated suppressed/noisy public answer
- class: `aggregate_restatement_receipt`
- old artifact: `pub-callback-route-week-2026-05-13-r1`
- new artifact: `pub-callback-route-week-2026-05-13-r2`
- reason: late source correction changed internal components; disclosure treatment was recomputed, changing one perturbed public cell and one collapse note
- relation: `is_new_version_of` old copy; old copy marked `superseded_public_copy`
- verdict: `publish_restatement_without_rewriting_old_copy`
- anti-counterfeit warning: restatement is not proof the old public copy was exact, absent, or recalled

Healthy behavior: Harbor links old and new copies, explains use posture, and keeps both receipts inspectable.

### PC-79-04 — recomposition attempt across public copies
- class: `invalid_recomposition_copy`
- copies combined:
  - all-provider route/week table;
  - provider-excluded route/week table;
  - partner PDF chart with totals but no machine-readable labels.
- risk: subtraction reconstructs a suppressed provider-family cell
- verdict: `block_or_warn_recomposition`
- anti-counterfeit warning: valid copies can become unsafe together

Healthy behavior: Harbor marks sibling-copy recomposition as unsafe and refuses proof language that would bless the combined derived table.

### PC-79-05 — consumer proof request for a public copy
- class: `proof_of_public_copy_ticket`
- requester: public consumer asking whether a mirrored file is genuine
- allowed proof: public artifact id, payload digest, required label digest, release receipt digest, source/public cut ids, restatement status, and safe copy text
- disallowed proof: raw replay bundle, contributor counts, suppressed cell values, noise seed, or private disclosure-threshold evidence
- verdict: `provide_copy_proof_not_raw_evidence`
- anti-counterfeit warning: proof of emitted bytes is not raw evidence access and not privacy approval

Healthy behavior: Harbor proves the public-copy relation without opening the sealed replay evidence from earlier passes.

### PC-79-06 — stale cache serves pre-restatement copy
- class: `stale_public_copy`
- mirror: public cache serving `r1` after `r2` exists
- cache note: was fresh before restatement; now stale pending revalidation
- consumer copy: “This mirror serves a superseded public copy. Use r2 for current public reporting; r1 remains citable only as historical release evidence.”
- verdict: `mark_stale_and_revalidate`
- anti-counterfeit warning: staleness is not deletion, and a stale copy can still be real historical evidence

Healthy behavior: Harbor avoids pretending old bytes vanished while also refusing to call them current.

### PC-79-07 — notice/license propagation and non-recall
- class: `notice_license_propagation`
- public copy: downloadable aggregate under open reuse terms plus disclosure-treatment notices
- later action: artifact withdrawn for safety; successor is safer and coarser
- honest posture: deprecate, supersede, and warn; do not claim every downstream copy has been recalled
- verdict: `withdrawal_without_fake_recall`
- anti-counterfeit warning: reuse permission is not disclosure safety, and withdrawal is not remote erasure

Healthy behavior: Harbor distinguishes legal/notice posture from privacy/release safety and keeps downstream warnings explicit.

### PC-79-08 — PDF/chart copy hides cell-level labels
- class: `format_label_loss`
- copy: PDF chart screenshot showing route/week bars
- hidden issue: footnote says “disclosure treated” but does not bind which cells were suppressed, perturbed, or structural zero
- verdict: `chart_not_sufficient_as_machine_public_copy`
- safe alternative: include a companion release receipt or publish only a coarse chart with no cell-level claims
- anti-counterfeit warning: a chart can be communicative without being proof-grade

Healthy behavior: Harbor may allow the chart as explanatory copy while refusing to treat it as a proof-grade public data artifact.

## Counterfeit matrix

| counterfeit | Harbor response |
| --- | --- |
| release success means every export is valid | reject; each copy needs label-preservation proof |
| matching payload digest is enough | reject when required metadata/label digest is absent |
| BI footnote equals machine-readable disclosure treatment | reject; bind labels to payload or mark copy weak |
| restatement rewrites the old public copy | reject; link old/new and name use posture |
| withdrawal means recall | reject; say deprecated, superseded, withdrawn, or unsafe for new use |
| stale mirror is fake data | reject; stale can be real historical evidence but not current recommendation |
| license permission means privacy safety | reject; rights/reuse and disclosure safety are separate |
| proof of copy grants raw replay evidence | reject; provide digest/manifest/label proof only |
| valid copies compose safely | reject; sibling-copy recomposition can defeat suppression |
| screenshot/PDF proves public table semantics | reject unless labels and cell semantics are bound elsewhere |

## Review copy example

Consumer-visible copy proof:

> Harbor released a public aggregate artifact with identifier `pub-callback-route-week-2026-05-13-r1`. The mirrored payload matches the released payload digest, but the mirror is missing the required disclosure-treatment labels. Treat this mirror as incomplete. Use the labeled release bundle or the superseding artifact `pub-callback-route-week-2026-05-13-r2` for current public reporting. No raw replay evidence is included in this proof.

Release artifact receipt sketch:

```yaml
public_artifact: pub-callback-route-week-2026-05-13-r2
supersedes: pub-callback-route-week-2026-05-13-r1
source_cut: cut-callback-2026-05-13T22:00Z
public_cut: public-cut-callback-2026-05-13T22:45Z
release_mode: perturbed_release_with_suppression
payload_digest: sha256:payload-r2-example
label_digest: sha256:labels-r2-example
release_receipt_digest: sha256:receipt-r2-example
required_labels:
  - disclosure_treated
  - not_exact_public_copy
  - coarsened_for_disclosure
  - suppressed_cells_present
  - perturbed_release
  - not_a_dp_claim
  - additivity_weakened
  - structural_zero_labels_present
mirror_status:
  canonical_download: fresh
  partner_csv_mirror: label_stripped_copy
  dashboard_tile: valid_labeled_public_copy
  old_cache_r1: stale_public_copy
recomposition_guard:
  sibling_provider_excluded_tables: do_not_recompose_without_review
notice_posture:
  attribution_required: true
  disclosure_treatment_notice_required: true
  withdrawal_is_not_recall: true
proof_non_promises:
  - proof_of_copy_is_not_raw_replay_access
  - public_copy_is_not_exact_internal_answer
  - license_permission_is_not_privacy_safety
  - valid_single_copy_is_not_safe_recomposition
verdict: publish_labeled_bundle_and_repair_or_mark_bad_mirrors
```

## Verdict
Public-copy vocabulary is useful as **bounded review residue**. It lets Harbor distinguish release artifacts, valid labeled copies, stripped mirrors, stale caches, restatements, withdrawals, recomposition hazards, and proof-of-copy tickets without choosing a catalog, package format, BI governance product, license engine, mirror protocol, or final SlopOS datacube shape.

This pass does **not** promote:

- a public data package format;
- a catalog/distribution vocabulary;
- a BI/export governance product;
- a mirror-validation service;
- a cache-control profile;
- a license or rights-management engine;
- a provenance ontology;
- a public aggregate-release API;
- a signature/verifier stack;
- a transparency log;
- or durable Harbor datacube cards for public-copy hygiene.

Followthrough `F079` is complete. The next pressure should focus on release artifact localization and accessibility: translations, alternate renderings, unit/locale formatting, alt text/table accessibility, and how label meaning survives human-friendly forms without becoming a second truth source.

