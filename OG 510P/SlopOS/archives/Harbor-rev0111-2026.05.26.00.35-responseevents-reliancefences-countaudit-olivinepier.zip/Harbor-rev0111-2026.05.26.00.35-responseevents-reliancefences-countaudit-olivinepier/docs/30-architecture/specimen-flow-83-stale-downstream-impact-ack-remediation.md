# Specimen flow 83 — stale downstream impact, acknowledgement, remediation, and use-attestation humility

**Status:** specimen for `F083`; design-phase rehearsal only.

## Setup

Source release inherited from flows 79–82:

- `public_artifact_id`: `pub-callback-route-week-2026-05-13-r2`
- `source_cut`: `cut-callback-2026-05-13T22:00Z`
- `payload_digest`: `sha256:payload-callback-route-week-r2-example`
- `label_digest`: `sha256:labels-callback-route-week-r2-example`
- correction anchor: `corr-pub-callback-route-week-2026-05-13-r2-summary-labels-v1`
- corrected successor: `pub-callback-route-week-2026-05-13-r2.summary.en.v2`
- stale copy: `pub-callback-route-week-2026-05-13-r2.summary.en.v1`
- restored labels: `suppressed_cells_present`, `not_a_dp_claim`, `perturbed_release`, `coarsened_for_disclosure`, `do_not_recompose_with=provider-excluded-sibling`

Flow 82 proved Harbor could notice stale catalogs, snippets, caches, agents, dataset/eval cards, and mirrors. Flow 83 asks what to do when stale material was used.

## Candidate cases

| Case | Candidate residue | Review question | Verdict |
| --- | --- | --- | --- |
| SI-83-01 | External weekly report cites stale `summary.en.v1` and repeats "DP-protected" wording | Is this known harm? | use confirmed; impact assessment needed; public wording safe-only |
| SI-83-02 | Consumer acknowledges correction notice but has not reissued report | Is acknowledgement enough? | acknowledgement receipt only; no remediation claim |
| SI-83-03 | Catalog owner says metadata fixed but human summary still stale | Is it remediated? | remediation claimed, verification failed; residual risk note |
| SI-83-04 | Dataset owner updates card warning but cannot rebuild eval set this month | Is stale eval repaired? | unrepairable-now; historical-only/unsafe-for-new-use notice |
| SI-83-05 | Downstream owner says their model did not train on stale copy, based on manifest review | Is non-use proven? | scoped use attestation; not global non-use proof |
| SI-83-06 | Agent regenerates explanation from corrected source but omits `not_a_dp_claim` label | Is repair successful? | repaired explanation refused; label preservation failed |
| SI-83-07 | Dashboard numbers unchanged after correction, but label/non-promise changed | Is impact zero? | numeric impact none observed; interpretation impact material |
| SI-83-08 | Public statement says "all downstream copies fixed" | Is it safe? | counterfeit; target set missing |
| SI-83-09 | Consumer disputes that it relied on stale copy despite citation | Can Harbor resolve? | disputed; publish source-current statement and sealed/auditor lane |
| SI-83-10 | Old report remains archived with warning and successor link | Is it acceptable? | historical-only if label and successor link visible |

## Example receipt sketches

```yaml
stale_use_impact_packet: impact-83-01
source:
  artifact: pub-callback-route-week-2026-05-13-r2
  correction_anchor: corr-pub-callback-route-week-2026-05-13-r2-summary-labels-v1
  source_cut: cut-callback-2026-05-13T22:00Z
  payload_digest: sha256:payload-callback-route-week-r2-example
  label_digest: sha256:labels-callback-route-week-r2-example
stale_copy:
  variant: pub-callback-route-week-2026-05-13-r2.summary.en.v1
  missing_labels:
    - suppressed_cells_present
    - not_a_dp_claim
    - perturbed_release
use:
  subject: external-weekly-report-2026-05-14
  class: downstream_report
  status: use_confirmed
  reliance: reliance_unknown
impact:
  numeric_result_drift: none_observed
  interpretation_drift: material
  sensitive_boundary: public_safe_only
verdict: impact_assessed_not_closed
required_action:
  - notify_report_owner
  - publish_safe_current-source_statement
  - request_report_correction_or_warning
non_promises:
  - no_universal_recall
  - no_raw_suppressed_values
  - no_claim_that_prior_decisions_were_repaired
```

```yaml
consumer_acknowledgement_receipt: ack-83-02
notice: notice-corr-pub-callback-route-week-r2-summary-labels-v1
correction_anchor: corr-pub-callback-route-week-2026-05-13-r2-summary-labels-v1
consumer:
  class: report_owner
  id: external-weekly-report-team
acknowledgement:
  method: email_reply
  actor_authority: report_editor
  timestamp: 2026-05-15T18:30:00Z
  posture: review_started
scope:
  acknowledged_subjects:
    - external-weekly-report-2026-05-14
  not_acknowledged:
    - downstream_syndications
    - reader_decisions
    - archived_pdf_copies
non_promises:
  - acknowledgement_is_not_remediation
  - acknowledgement_is_not_user_notification
```

```yaml
remediation_attestation: remed-83-04
subject:
  class: public_eval_dataset
  id: callback-route-eval-mini-2026-05
source_correction_anchor: corr-pub-callback-route-week-2026-05-13-r2-summary-labels-v1
claimed_action:
  action: card_updated_warning_added
  timestamp: 2026-05-15T19:05:00Z
  actor: dataset_owner
basis:
  evidence_lane: public_url_and_card_diff
  card_status: observed_warning_added
  eval_rebuild_status: not_rebuilt
result_status: partially_verified
residual_risk:
  - stale_eval_rows_remain
  - old_leaderboard_scores_may_reference_stale_labels
  - no_model_unlearning_claim
public_status: historical_only_for_old_eval; use_successor_when_available
recheck: 2026-06-01
```

```yaml
use_attestation_note: use-attest-83-05
attester:
  class: downstream_model_owner
  authority: dataset_manifest_owner
subject_artifact: pub-callback-route-week-2026-05-13-r2.summary.en.v1
statement_type: claimed_non_use
use_window: 2026-05-13/2026-05-15
method:
  - reviewed_training_manifest
  - reviewed_retrieval_index_build_log
limitations:
  - no_access_to_user_prompt_logs
  - no_claim_about_other_models
  - expires_if_manifest_reprocessed
verdict: scoped_non_use_claim_received
```

## Safe public impact copy

> Harbor corrected the public callback-route weekly artifact and restored labels indicating suppression, perturbation, and non-DP status. Some downstream copies or reports may still quote the older summary. For new analysis, use `pub-callback-route-week-2026-05-13-r2.summary.en.v2` and its current labels. Harbor has received some acknowledgements and remediation claims, but this notice does not claim universal recall, deletion from caches or training data, model behavior change, repair of prior decisions, or disclosure of suppressed values.

## Proof obligations exercised

- Source correction anchor, stale copy, downstream subject, and evidence lane named.
- Exposure, use, reliance, impact, acknowledgement, remediation claim, verification, and residual risk separated.
- Acknowledgement does not counterfeit remediation.
- Remediation claim remains partial until subject/action/evidence and residual risk are verified.
- Use attestation remains scoped and expiring.
- Stale model/eval material can be historical-only or unsafe-for-new-use without pretending it was repaired.
- Public statement preserves non-promises and avoids raw suppressed evidence.

## Result

`F083` can close with stale-impact receipts as process residue. Harbor still should not promote an impact ledger, customer notification workflow, remediation registry, VEX/CSAF profile, in-toto predicate, AI incident taxonomy, model unlearning process, eval governance program, public status API, or final SlopOS datacube shape.
