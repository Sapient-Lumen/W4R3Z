
# Specimen flow 72 — measurement proof cut, rate restatement, and display honesty

Purpose: complete followthrough `F072` without inventing a universal conversion service, FX governance stack, metric engine, semantic layer, or warehouse substrate.

This specimen tests whether Harbor can keep four measurement truths separate:
1. source-native unit/currency as observed;
2. canonical machine basis for comparison, if any;
3. display/render basis for humans; and
4. conversion/rate/restatement basis for derived comparisons.

## Actors and surfaces
- **Producer:** an unsettled SlopOS design-phase telemetry/export lane.
- **Harbor:** archive/process reviewer, not a metric engine.
- **Consumer:** a dashboard-like review view that wants duration, utilization, and money side by side.
- **Sibling pressure:** Helm display honesty, ViewFS materialization boundary, Steward restatement aftermath, Ward tier/conformance humility.

## Starting rows

### A. Duration lane — source-native mixed inputs

| row | source value | source unit | quantity family | event cut | producer note |
| --- | ---: | --- | --- | --- | --- |
| `dur-001` | `250` | `ms` | duration | `obs-cut-17` | browser callback completed quickly |
| `dur-002` | `0.40` | `s` | duration | `obs-cut-17` | provider took a slower path |
| `dur-003` | `1100` | `ms` | duration | `obs-cut-17` | timeout-near result |

Allowed derived comparison:

| row | source value | source unit | canonical value | canonical unit | conversion class |
| --- | ---: | --- | ---: | --- | --- |
| `dur-001` | `250` | `ms` | `0.250` | `s` | scale conversion |
| `dur-002` | `0.40` | `s` | `0.400` | `s` | identity scale |
| `dur-003` | `1100` | `ms` | `1.100` | `s` | scale conversion |

Hard veto: a lane whose canonical basis says `unit="mixed"` is not canonical. Source-native mixed units are allowed only when each row preserves its source unit and any comparison view names the conversion basis.

### B. Utilization lane — unity storage, percent display

| row | stored value | stored unit | quantity family | display value | display note |
| --- | ---: | --- | --- | ---: | --- |
| `util-001` | `0.975` | `1` | ratio/utilization | `97.5%` | render only |
| `util-002` | `0.420` | `1` | ratio/utilization | `42.0%` | render only |

Hard veto: storing `97.5` and displaying `97.5%` under a unity contract is double-scaled counterfeit unless the lane explicitly states that the stored quantity is percent points. Harbor should prefer unity storage for ratios and explicit display-unit notes for percent rendering.

### C. Money lane — original currency plus converted comparison view

Original truth:

| row | amount | currency | quantity family | knowledge cut | source posture |
| --- | ---: | --- | --- | --- | --- |
| `money-001` | `100.00` | `EUR` | money | `k-2026-05-13T14:00Z` | original-denomination truth |
| `money-002` | `12000` | `JPY` | money | `k-2026-05-13T14:00Z` | original-denomination truth |
| `money-003` | `97.25` | `USD` | money | `k-2026-05-13T14:00Z` | original-denomination truth |

Derived comparison view:

| row | source amount | source currency | target amount | target currency | rate table | rate as-of | applied at | rounding posture |
| --- | ---: | --- | ---: | --- | --- | --- | --- | --- |
| `money-001` | `100.00` | `EUR` | `108.20` | `USD` | `fx-demo-v4` | `2026-05-13T12:00Z` | `2026-05-13T14:05Z` | cents, half-even |
| `money-002` | `12000` | `JPY` | `77.40` | `USD` | `fx-demo-v4` | `2026-05-13T12:00Z` | `2026-05-13T14:05Z` | cents, half-even |
| `money-003` | `97.25` | `USD` | `97.25` | `USD` | `fx-demo-v4` | `2026-05-13T12:00Z` | `2026-05-13T14:05Z` | identity, cents |

Hard veto: the converted target amount is a derived view, not source truth. It must not overwrite original amount/currency and must not be compared as if the rate were timeless.

## Late rate restatement
At `2026-05-13T15:30Z`, the rate table provider republishes the `2026-05-13T12:00Z` EUR->USD rate from `1.0820` to `1.0811`.

Harbor emits a restatement receipt for the derived view:

```text
restatement_id: fx-restatement-2026-05-13-001
invalidates: converted-view/fx-demo-v4/applied-2026-05-13T14:05Z
reissues: converted-view/fx-demo-v5/applied-2026-05-13T15:35Z
source_rows_changed: false
rate_basis_changed: true
knowledge_cut: k-2026-05-13T15:35Z
consumer_effect: comparison view may change; original-denomination truth remains stable
```

The corrected derived view changes `money-001` from `108.20 USD` to `108.11 USD`. The original row remains `100.00 EUR`.

## Proof cuts applied

### PC-MEAS-001 — source-unit cut
Every measured source row carries quantity family and source unit/currency. Mixed source units are allowed only because each row's source basis is explicit.

### PC-MEAS-002 — canonical-machine-unit cut
Only comparison views choose a canonical machine unit. That choice is per lane/view and does not rewrite source rows.

### PC-MEAS-003 — display-render cut
Display strings and percent signs are human presentation. They cannot change storage semantics, and they need a note when display scale differs from stored scale.

### PC-MEAS-004 — conversion/rate cut
Scale conversions, semantic unit conversions, variable-rate conversions, and presentation-only conversions are different classes. Money conversion always names source currency, target currency, rate source/version, rate as-of, applied-at, rounding/minor-unit posture, and restatement handling.

### PC-MEAS-005 — knowledge/restatement cut
A derived comparison view has a knowledge cut and invalidation rule. Late rate changes update the derived view through a restatement receipt rather than mutating original rows silently.

## Adversarial checks

| counterfeit | expected Harbor response |
| --- | --- |
| `unit="mixed"` used as canonical basis | reject canonical claim; keep source-native rows and require explicit conversion view |
| `0.975` stored but dashboard multiplies twice to `9750%` | reject display proof; percent is render-only unless stored unit is percent-points |
| `97.5` stored under unity contract and displayed as `97.5%` | reject storage proof or require changed quantity/display contract |
| converted USD amount replaces original EUR/JPY values | reject as source-truth overwrite |
| late FX rate silently changes old dashboard output | require restatement receipt and new knowledge cut |
| pivot output fills non-applicable cells with `NULL` and consumer treats them as missing source facts | require presence proof; query placeholders are not original absence witnesses |
| row-lineage sidecar says `money-001` survived and consumer treats that as currency authority | lineage may trace row survival, but measurement proof still owns currency/rate truth |
| statistics/facet sidecar includes `unit=s` and consumer treats it as base contract | sidecar metadata is optional evidence unless the lane contract/proof packet promotes it |

## Verdict
The measurement seam is useful and should remain in the repo as process vocabulary. It is now better supported by a proof obligation surface and a harder specimen, but this pass still does **not** promote:
- a universal conversion service;
- a global FX-rate registry;
- a mandatory canonical unit for every quantity family;
- a semantic front door; or
- a datacube storage/query engine.

Followthrough `F072` is complete. The next pressure should move to semantic-front-door exports, contract subsets, freshness basis, join/fanout fences, and optional row-lineage sidecars under the new proof-obligation gate.
