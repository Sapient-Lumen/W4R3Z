# Specimen flow 50 — token-format target witness, resource-server coverage card, and client-confidence ladder

Goal: let Harbor describe a crossing where a token or introspection response names audience-like target identifiers, a protected resource has its own exact expected identifiers or alias family, and local acceptance must still distinguish “token-format evidence exists” from “this receiver definitely accepts the token for this call”.

## Scenario
A Harbor-hosted product wants to call `https://ledger.example.com/entries/42`.
In one deployment the access token is opaque, so the protected resource introspects it.
The introspection response says the token is active and returns metadata such as:
- `client_id = cli-123`;
- `scope = ledger:read`;
- `aud = ["ledger-api", "https://ledger.example.com/"]`.

In another deployment the token is a JWT access token whose `aud` names either one resource identifier or a small list of resource-server identifiers.
The resource server has local expectation rules saying that:
- exact `https://ledger.example.com/` is accepted;
- `ledger-api` is accepted only for the ledger family;
- `billing-api` is not an alias for ledger;
- and `/entries/` and `/admin/` are not interchangeable just because they share a host.

Sometimes the token response also carried an explicit `resource` value confirming the intended protected resource.
Sometimes it did not, leaving only token-format or introspection evidence.
Sometimes the token-format witness looks plausible but the protected resource’s local expectation still fails, so the request must be refused.

During execution:
- introspection exposes audience-like token metadata for the protected resource’s benefit;
- JWT validation separately checks that `aud` contains an identifier the current resource server expects for itself;
- an audience list can be real without meaning every nearby endpoint or alias family is acceptable here;
- explicit client-facing `resource` confirmation, when present, is stronger for the client than token-format audience folklore;
- and the resource server’s own exact expectation can still veto the turn despite a structurally valid token.

Harbor must therefore preserve the difference between:
- “the token or introspection surface named these target-like identifiers,”
- “this protected resource currently treats these identifiers or aliases as in-family,”
- “the client did or did not receive stronger explicit `resource` confirmation,”
- “the turn ended with a local-expectation mismatch veto even though token-format evidence looked plausible,”
- and “none of those facts by themselves settle durable entitlement, account, session, or adopted consequence truth.”

## Candidate Harbor objects
1. **token-format target witness**
   - compact note that the token string or introspection response named certain audience or target-like identifiers;
   - useful because it captures what the token machinery actually said without pretending that it proves concrete protected-resource applicability for every consumer.

2. **resource-server coverage card**
   - inspectable note about which exact audience identifiers or aliases the current protected resource will locally accept for this family of calls;
   - useful because local receiver expectation is stronger than generic token-format plausibility while still remaining smaller than durable grant truth.

3. **client-confidence ladder**
   - local note about whether current target confidence is response-confirmed, receiver-locally-accepted, or token-format-only;
   - useful because it keeps stronger and weaker target facts legible instead of flattening them into one success bit.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- RFC 7662 introspection returns useful audience-like metadata that is still receiver-facing rather than client-facing proof;
- RFC 9068-style JWT validation says the current receiver must see an expected audience identifier in `aud`;
- OAuth 2.1 still wants audience restriction, preferably to a single resource server, and obliges each resource server to refuse tokens not meant for it;
- and explicit returned `resource` confirmation can be absent even though token-format evidence looked plausible.

## Promotion rule
Do not promote `token-format target witness`, `resource-server coverage card`, or `client-confidence ladder` unless they improve:
- one RFC 7662 introspection specimen where `aud` is informative for the current receiver but still not a concrete protected-resource oracle for clients;
- one RFC 9068 / OAuth 2.1 specimen where audience restriction and current-receiver validation matter even when the token is otherwise structurally valid;
- and one protected-resource local-expectation mismatch specimen where token-format evidence looked plausible yet the correct result is still a visible local veto.
