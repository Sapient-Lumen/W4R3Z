# Specimen flow 47 — grant-bounded narrowing floor, server-assigned addition, and target-refusal rail

Goal: let Harbor describe a crossing where the original grant authorized a wider resource set, a later authorization-code or refresh-token request narrows that set further, the authorization server may attach one or more scope- or policy-derived resources in addition to an accepted requested resource, and a typed `invalid_target` bottom-out remains visibly smaller than generic auth failure or durable entitlement truth.

## Scenario
A Harbor-hosted product already holds an authorization code or refresh token for a broader original grant.
At token time it wants one access token for a narrower subset of resources.
Sometimes it also asks for scopes such as `openid` that cause the authorization server to derive an extra resource like a UserInfo endpoint.
Sometimes it omits `resource` entirely and lets server policy decide whether the access token is resource-specific or not.
Sometimes it asks for a resource that is outside the grant or outside local policy, and the authorization server rejects the turn with `invalid_target`.

During execution:
- the token request may include one or more `resource` values that are only a further restriction on the underlying grant;
- a refresh-token request may narrow but must not silently expand the resource set previously bound to that grant;
- the response may return only a strict subset of the requested resources;
- the response may also return one or more **server-assigned** resources derived from policy, client configuration, or requested scopes;
- if the client requested no resource at all, the response may either omit `resource` (token not resource-specific in the sense of the specification) or return an assigned resource set;
- and if none of the requested resources are acceptable, the authorization server may or must bottom out with `invalid_target` instead of quietly widening, guessing, or succeeding vaguely.

Harbor must therefore preserve the difference between:
- “the underlying grant authorized this broader region,”
- “this token request asked for a smaller slice now,”
- “this returned resource set still includes at least one accepted requested anchor,”
- “this extra returned identifier was server-assigned rather than explicitly asked for,”
- “this turn bottomed out in typed target refusal,”
- and “none of those facts by themselves settle durable entitlement, account, session, or adopted consequence truth.”

## Candidate Harbor objects
1. **grant-bounded narrowing floor**
   - compact residue that the current token request only narrows within the underlying grant and must not silently widen what that grant already allowed;
   - useful because refresh-time and code-time restriction are real, inspectable facts smaller than durable entitlement truth.

2. **server-assigned addition**
   - inspectable note that the authorization server returned an extra resource identifier derived from policy, client configuration, or requested scope rather than from exact client request text;
   - useful because assigned resources can be valid and important without counterfeiting an exact requested-target mirror.

3. **target-refusal rail**
   - typed explanation path for `invalid_target` outcomes when none of the requested resources are acceptable or a required resource value is missing;
   - useful because refusal should stay legible without dissolving into generic auth failure or a giant entitlement-negotiation ladder.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- grant-time breadth and token-time breadth differ;
- refresh-token requests can restrict but must not expand;
- the authorization server may add one or more scope-defined or policy-defined resources alongside an accepted requested anchor;
- omission of `resource` can mean either assigned specificity or non-resource-specific issuance;
- and typed `invalid_target` refusal should survive as inspectable aftermath rather than counterfeit durable entitlement truth.

## Promotion rule
Do not promote `grant-bounded narrowing floor`, `server-assigned addition`, or `target-refusal rail` unless they improve:
- one refresh-token further-restriction specimen where token-time resource asks are a proper subset of the grant;
- one scope-defined extra-resource specimen where an accepted requested resource comes back with an additional server-assigned identifier;
- and one no-request or unacceptable-request specimen where the result is either an assigned-only resource set, a resource-omitted unbounded result, or a typed `invalid_target` refusal that remains visibly smaller than durable grant truth.
