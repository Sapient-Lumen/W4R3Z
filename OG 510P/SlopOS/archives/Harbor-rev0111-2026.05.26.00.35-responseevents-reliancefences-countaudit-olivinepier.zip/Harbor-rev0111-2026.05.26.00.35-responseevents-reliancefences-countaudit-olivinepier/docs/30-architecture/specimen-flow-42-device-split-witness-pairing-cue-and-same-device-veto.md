# Specimen flow 42 — device-split witness, pairing cue, and same-device veto

Goal: let Harbor describe a crossing where approval happens on a second device, the user is given a human-visible cue to interlock the devices, and the local side may need to refuse or downgrade the flow if the supposed cross-device split collapses into same-device use.

## Scenario
A Harbor-hosted product starts a sign-in or grant flow from a limited-input or headless client.
Instead of finishing on the initiating surface, the crossing hands the user to another device:
- a TV, CLI, kiosk, or background agent shows a short code, QR code, or short instruction card;
- the user scans or types into a phone or laptop;
- or a CIBA-style request triggers a push/poll path on the user’s authentication device.

During the crossing:
- the current surface may display a `verification_uri`, `verification_uri_complete`, `user_code`, or other handoff artifact;
- the second device may show a matching code or `binding_message` that lets the user visually interlock the two sides;
- the local product may discover that the supposed cross-device flow is actually running on the same device, or in a context where the split is implausible enough to require a veto or downgrade;
- and any eventual approval may still arrive through polling or a small callback stub rather than a fully trusted durable result.

Harbor must therefore preserve the difference between:
- “this crossing genuinely depended on a separate consumption device and authorization device,”
- “the user saw a short cue intended to match the two devices for this transaction,”
- “the local side refused or narrowed the crossing because same-device use or copied-context use made the cross-device story untrustworthy,”
- and “none of those facts by themselves settle durable issuer, account, session, or adopted consequence truth.”

## Candidate Harbor objects
1. **device-split witness**
   - compact local residue that the crossing was meant to span separate consumption and authorization devices;
   - useful because a cross-device protocol used on the same device is not the same thing as a real split crossing.

2. **pairing cue**
   - short human-visible interlock such as a matching `user_code` check or CIBA `binding_message` displayed across both devices;
   - useful because users need something small and inspectable that says “this approval belongs to that other screen.”

3. **same-device veto**
   - explicit local bottom-out or downgrade when a supposed cross-device route collapses into same-device or other implausible context;
   - useful because “silently continue” and “pretend the split never mattered” are both too dishonest.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- a real crossing leaves the initiating surface and completes somewhere else;
- the only authenticated thing on the inter-device gap may be a short visual cue inspected by a human;
- same-device use of a cross-device protocol is materially different from true cross-device use;
- and callback or poll completion remains smaller than durable local adoption.

## Promotion rule
Do not promote `device-split witness`, `pairing cue`, or `same-device veto` unless they improve:
- one device-authorization specimen where `verification_uri_complete` still requires a user-code match check;
- one CIBA-style specimen where `binding_message` or user-code interlock is visible but remains smaller than durable adoption;
- and one specimen where same-device or copied-context use produces an inspectable veto/downgrade rather than silent success.
