# Specimen flow 69 — exactness-class card, sketch witness, and error-band note

Goal: let Harbor pressure-test one realistic datacube slice where several numbers look equally trustworthy on screen even though they come from different exactness classes.

## Scenario
A Harbor maintainer is reviewing three curated daily lanes:
- `crossing_events_daily`, an exact count of boundary crossings by day and workspace;
- `distinct_actor_presence_daily`, a daily distinct-actor lane derived from a mergeable distinct-count sketch retained per day/workspace; and
- `top_target_families_daily`, a compact “top targets” lane derived from an approximate heavy-hitters summary.

A dashboard author asks for three seemingly simple outputs:
1. **Adoption rate** = completed crossings / distinct actors.
2. **Top target families this month** by activity share.
3. **Historical trend** that compares last month to this month after a backfill changed the distinct-count computation from exact raw-row recomputation to retained sketches for large partitions.

A dangerous fourth convenience appears during review:
4. One downstream export already labels `distinct_actor_presence_daily.value` as `exact_distinct_actors`, because the rendered field is just an integer.

## Pressure
If Harbor publishes all three surfaces as generic numbers, several wrong things can happen:
- an exact count and a sketch estimate can be mistaken for the same kind of scalar truth;
- the adoption rate can look exact even though its denominator is estimated;
- the heavy-hitters list can be read as exact ranking when it is only approximate with bounded error posture;
- a later switch from exact recomputation to sketches can silently break comparability across time; and
- consumers can lose the retained sketch artifact and still assume re-aggregation remains legal.

That turns one cube into a counterfeit-certainty machine:
- exact integers start masquerading as exact semantics even when they are extracted estimates;
- mergeability starts masquerading as proof of exactness;
- trend lines start blending exact and estimated eras without a witness; and
- approximate summaries start outranking the smaller raw or component truth that generated them.

## Minimal Harbor move
Harbor keeps grain, time-axis posture, aggregation posture, and conformance posture unchanged and adds three smaller review surfaces.

### 1) Exactness-class card
Each lane declares:
- `crossing_events_daily.count` = **exact**;
- `distinct_actor_presence_daily.value` = **sketch-estimate**;
- `adoption_rate` = **mixed exactness derived metric** and should visibly note that the numerator is exact while the denominator is estimated;
- `top_target_families_daily.rank` and `share` are **estimate-backed** and should not be labeled “exact top targets.”

### 2) Sketch witness
`distinct_actor_presence_daily` records:
- retained artifact = mergeable distinct-count sketch plus extracted estimate;
- merge posture = partial daily sketches may be merged to larger windows, but extracted integers alone should not be re-merged;
- precision posture = configured/tunable upstream, not implied by the rendered integer;
- historical note = older periods may still be exact-from-rows or exact-from-components rather than sketch-backed.

`top_target_families_daily` records:
- retained artifact = approximate heavy-hitters summary;
- returned list is bounded by the sketch’s estimate posture;
- downstream consumers may display ranks and counts with explicit estimate posture, but should not treat the lane as an exact exhaustively ordered list.

### 3) Error-band note
Estimate-backed lanes carry a compact note:
- whether the lane currently preserves relative/absolute/rank-based error posture;
- whether the confidence basis is known;
- whether only a point estimate survives in the published lane;
- whether mixed exactness appears in derived rates or shares.

## Why this is better than one generic metric label
- it keeps **exact counts** separate from **estimate-backed integers**;
- it keeps **mergeable sketch retention** separate from **point-estimate-only exports**;
- it keeps **mixed-exactness ratios** separate from uniformly exact metrics; and
- it leaves room for later stronger machine checks without pretending Harbor already chose one sketch engine or universal statistics registry.

## What stays deliberately open
- whether Harbor later compiles exactness-class cards into semantic-model metadata, catalog facets, or warehouse-native types;
- whether error-band notes later become machine-readable enough to block misleading dashboard labels;
- whether estimate-lineage changes later need successor lanes or only compatibility notes.

The specimen earns one small rule only: **Harbor should not publish a number without saying whether it is exact, what estimate artifact produced it, and what uncertainty survived the trip.**
