# Specimen flow 73 — semantic export, contract subset, fanout fence, and sidecar honesty

Purpose: complete followthrough `F073` without inventing a semantic layer, metric engine, BI product, warehouse, lakehouse, universal row identity, assertion DSL, sidecar registry, or public datacube API.

This specimen tests whether Harbor can publish a small consumer-facing semantic export while keeping five facts separate:

1. base lane truth;
2. derived semantic lens;
3. public contract subset;
4. freshness and join/fanout proof; and
5. optional row-lineage sidecar evidence.

## Actors and surfaces
- **Producer:** unsettled SlopOS callback/export lanes.
- **Harbor:** archive/process reviewer, not a semantic layer.
- **Consumer:** a public status report that wants daily provider-funnel metrics.
- **Sibling pressure:** Foundry serving-lane basis, ViewFS materialization boundary, Ward conformance tiers, Helm display/refusal honesty, Steward aftermath receipts, Schell supersession discipline.

## Base lanes

### A. Callback-attempt fact lane

Grain: one browser-mediated callback attempt observed by SlopOS.

| attempt_id | provider_id | route_class | event_day | success | duration_s | published_cut | evidence_grade |
| --- | --- | --- | --- | --- | ---: | --- | --- |
| `att-001` | `prov-a` | `browser` | `2026-05-13` | `true` | `0.250` | `pub-17` | exact frozen cut |
| `att-002` | `prov-a` | `browser` | `2026-05-13` | `false` | `1.100` | `pub-17` | exact frozen cut |
| `att-003` | `prov-b` | `native-detour` | `2026-05-13` | `true` | `0.400` | `pub-17` | exact frozen cut |

Allowed base metrics:
- `callback_attempts = count(attempt_id)` — exact count at fact grain;
- `callback_successes = sum(success as 0/1)` — exact count at fact grain;
- `callback_success_rate = callback_successes / callback_attempts` — ratio recomputed from components;
- `callback_duration_p95_s` — non-additive percentile, safe only at explicitly computed grouping sets.

### B. Provider dimension lane

Grain: one provider record per provider id for the published cut.

| provider_id | provider_family | display_label | effective_from | effective_to | uniqueness_evidence |
| --- | --- | --- | --- | --- | --- |
| `prov-a` | `oidc` | `Example IdP A` | `2026-01-01` | `null` | one row per provider at `pub-17` |
| `prov-b` | `fedcm` | `Example IdP B` | `2026-01-01` | `null` | one row per provider at `pub-17` |

Allowed join note:

```text
left: callback_attempt fact lane
right: provider dimension lane
key: provider_id
relationship: many callback attempts to one provider record at pub-17
allowed_for: callback_attempts, callback_successes, callback_success_rate, callback_duration_p95_s
proof: right-side uniqueness holds at pub-17; effective-date overlap not observed for event_day
```

### C. Claim-release child lane

Grain: one released claim per callback attempt.

| attempt_id | claim_name | claim_source | published_cut |
| --- | --- | --- | --- |
| `att-001` | `email` | `userinfo` | `pub-17` |
| `att-001` | `profile` | `userinfo` | `pub-17` |
| `att-003` | `email` | `id_token` | `pub-17` |

Refused join note:

```text
left: callback_attempt fact lane
right: claim-release child lane
key: attempt_id
relationship: one callback attempt to zero/many released claims
risk: fanout for attempt-level counts and success sums
verdict: refuse direct aggregate export; require a child-grain metric or pre-aggregated claim-count lane
```

If a consumer naively joins callback attempts to claims and sums `success`, the joined rows make `att-001` appear twice. The true `callback_successes` is `2`; the naive joined sum is `3`. Harbor refuses the export rather than trying to hide the fanout in a pretty dashboard.

## Derived semantic export receipt

```text
semantic_export_id: sem-daily-provider-funnel-2026-05-13-pub17
kind: derived semantic export receipt
owns_data: false
source_cuts:
  - callback_attempt@pub-17
  - provider_dimension@pub-17
contract_subset: public-daily-provider-funnel-v0
exposed_dimensions:
  - event_day
  - provider_family
  - route_class
exposed_metrics:
  - callback_attempts
  - callback_successes
  - callback_success_rate
  - callback_duration_p95_s
allowed_join_notes:
  - callback_attempt.provider_id -> provider_dimension.provider_id at pub-17, many_to_one
refused_join_notes:
  - callback_attempt.attempt_id -> claim_release.attempt_id for attempt-level aggregate metrics, one_to_many fanout
freshness_basis: fbw-pub17-2026-05-13T16:20Z
row_lineage_sidecar: optional, partial, source-scoped
invalidates_when:
  - source cut restated
  - provider dimension uniqueness proof fails
  - freshness threshold missed
  - metric definition changes
  - fanout-refused join is requested as if safe
refused_questions:
  - per-person or durable account questions
  - arbitrary claim-scope drilldown over attempt-level metrics
  - latest-live-head answers beyond pub-17
  - row identity outside the source-scoped lineage sidecar
```

This is a receipt for a lens, not a claim that Harbor has chosen a semantic layer.

## Public contract subset

The consumer-facing contract exposes only the following promises:

| area | public promise | explicit non-promise |
| --- | --- | --- |
| shape | four dimensions/metrics listed in the export receipt | no arbitrary field explorer |
| meaning | attempt grain, provider-family grouping, route-class grouping | no durable account/session truth |
| assertions | provider dimension uniqueness at `pub-17`; non-null `event_day`; non-null `provider_id`; duration in seconds | no publication of every internal assertion or validator result |
| freshness | published cut no older than 4 hours at report build time | no live-head currentness guarantee |
| exactness | counts are exact at `pub-17`; success rate recomputed from exact components | percentile is grouping-specific and not additive |
| joins | provider dimension join allowed for listed metrics | claim-release child join refused for attempt-level aggregates |
| sidecars | row-lineage sidecar may support debugging when present | sidecar absence does not mean row absence; sidecar presence does not create identity |

## Freshness basis witness

```text
freshness_basis_id: fbw-pub17-2026-05-13T16:20Z
source_cut: pub-17
source_cut_closed_at: 2026-05-13T15:45:00Z
export_built_at: 2026-05-13T16:20:00Z
threshold: 4h
time_axis: published-cut time
observed_age: 35m
verdict: pass
non_promise: not live head; late-arriving facts may require restatement
```

If `pub-17` is later restated, Harbor invalidates the semantic export receipt and issues a new one rather than letting the old freshness witness imply timeless truth.

## Optional row-lineage sidecar

The source system can attach a sidecar like this:

| attempt_id | source_scope | row_id | last_updated_sequence | sidecar_posture |
| --- | --- | ---: | ---: | --- |
| `att-001` | `callback_attempt@pub-17` | `501001` | `44` | present |
| `att-002` | `callback_attempt@pub-17` | `501002` | `44` | present |
| `att-003` | `callback_attempt@pub-17` | `null` | `null` | legacy/imported source; no row lineage |

Allowed uses:
- trace whether a restated export reused, rewrote, split, or dropped source rows within the same source scope;
- debug whether a later `pub-18` value came from row movement or semantic recomputation;
- cite lineage as evidence grade context.

Forbidden uses:
- joining to provider or claim dimensions;
- treating `row_id` as durable account, person, device, subject, or universal row identity;
- treating `null` row lineage as missing data;
- upgrading the public contract tier because a sidecar is present.

## Proof cuts applied

### PC-SEMA-001 — derived-lens cut
The export receipt says it owns no data and names its source cuts. It can be regenerated, invalidated, or refused without mutating base lane truth.

### PC-SEMA-002 — contract-subset cut
Only a selected set of shape, assertion, freshness, exactness, and join promises is public. Private checks and non-promises stay explicit.

### PC-SEMA-003 — freshness-basis cut
Freshness names the source cut, built-at time, threshold, observed age, time axis, and non-promise about live-head truth.

### PC-SEMA-004 — fanout-fence cut
The provider dimension join is allowed because right-side uniqueness is proven for the cut. The claim-release child join is refused for attempt-level aggregates because it fans out the base grain.

### PC-SEMA-005 — sidecar-optionality cut
Row lineage is partial, source-scoped, and optional. It supports debugging but does not define identity, conformance, authorization, or contract tier.

## Proof obligations exercised

| obligation | status in this specimen |
| --- | --- |
| PO-DC-001 grain proof | satisfied for callback attempts, provider dimension, and claim-release child lane |
| PO-DC-002 time-axis proof | satisfied for `event_day`, `published_cut`, and freshness basis |
| PO-DC-005 aggregation/fanout proof | satisfied by allowed provider join and refused claim-release fanout |
| PO-DC-006 conformance proof | partially satisfied for provider id at `pub-17`; not promoted to global provider identity |
| PO-DC-007 exactness proof | satisfied for counts/rate components; percentile remains grouping-specific |
| PO-DC-008 history/restatement proof | partially satisfied by invalidation rule; no full history lane promoted |
| PO-DC-009 contract/evidence proof | satisfied for the public subset only |
| PO-DC-010 derived-artifact proof | satisfied: export owns no data and names source cuts/refusals |
| PO-DC-011 sidecar optionality proof | satisfied: lineage is optional, partial, and scoped |
| PO-DC-012 noun-promotion proof | not satisfied for durable schema promotion; keep as process vocabulary |

## Adversarial checks

| counterfeit | expected Harbor response |
| --- | --- |
| generated semantic YAML is treated as canonical row meaning | reject; receipt is a derived lens over named source cuts |
| public contract badge implies every internal assertion passed | reject; only named public assertion subset is promised |
| freshness badge has no threshold or source cut | reject; require freshness basis witness |
| provider join lacks right-side uniqueness proof | refuse metrics through that join |
| one-to-many claim join is used to sum attempt successes | reject; fanout fence blocks aggregate export |
| success rate is averaged across groups | reject; recompute from numerator/denominator components |
| percentile is rolled up from child percentiles | reject unless retained distribution/sketch proof exists |
| row-lineage sidecar used as subject/account identity | reject; sidecar is source-scoped trace evidence only |
| null row lineage treated as absent source row | reject; lineage absence is sidecar absence, not data absence |
| consumer asks for latest live status from frozen `pub-17` export | refuse; export is a frozen published cut |

## Verdict
Semantic export receipts, contract subsets, freshness basis witnesses, join-relationship notes, fanout fences, and optional row-lineage sidecars are useful process vocabulary. They should remain in Harbor as review/specimen language.

This pass does **not** promote:
- a semantic layer;
- a metric engine;
- a public datacube API;
- a warehouse/lakehouse/catalog choice;
- a universal row identity;
- a row-lineage implementation;
- a sidecar registry; or
- a durable Harbor schema for semantic exports.

Followthrough `F073` is complete. The next pressure should move to option-reservation cards, derived-view receipts, statistics sidecars, watermark/frontier witnesses, and assertion-compiler/schema-transform targets under the same proof-obligation gate.
