# Specimen flow 104 — revocation-overlay propagation across public and local surfaces

## Scenario

Harbor has imported a companion change notice as a foreign-revocation overlay
over a prior F102/F103 lineage import.  Now the overlay must be propagated to
a public copy, mirror, generated summary, consumer notice, local index, and
warning card.  Some surfaces are reached, some remain unknown, one notice is
sealed, one mirror is stale, and one multi-cube public card has conflicting
overlays.

## Required packets

- overlay source packet with parent F103 bundle digest and source overlay
  digest;
- target-surface packet naming the exact public/local surface;
- propagation-action packet with reached and unreached surfaces;
- visibility-render packet with scoped public wording and no badge collapse;
- consumer-notice packet that separates delivery, read, applied, and repair;
- index/warning-state packet with local recheck basis;
- history-linkage packet preserving prior import history;
- verdict packet that records accepted scoped propagation or refusal.

## Expected refusals

- Do not use a green badge after overlay delivery.
- Do not use a red badge as a global failure finding.
- Do not infer compliance remediation or compliance failure.
- Do not say the prior import was false merely because a later overlay exists.
- Do not treat one clean mirror as all copies clean.
- Do not rewrite generated summaries without source digest carry-forward.
- Do not treat notice delivery as read, applied, or repaired.
- Do not treat index refresh as truth.
- Do not sunset a warning without scope and clock basis.
- Do not disclose sealed evidence as public truth.
- Do not treat stale overlays or timestamps as currentness.
- Do not use majority vote or single badge collapse for mixed overlays.
- Do not erase history on retraction.
- Do not treat callback success as overlay status.

## Promotion boundary

This specimen promotes no revocation propagation API, public badge workflow,
compliance workflow, notification guarantee, mirror/search truth plane,
warning-card status engine, or final SlopOS datacube shape.
