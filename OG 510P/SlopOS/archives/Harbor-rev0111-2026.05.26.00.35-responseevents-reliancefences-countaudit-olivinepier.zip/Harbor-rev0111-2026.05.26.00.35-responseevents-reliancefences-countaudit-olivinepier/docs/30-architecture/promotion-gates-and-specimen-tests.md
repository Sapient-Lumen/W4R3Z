# Promotion gates and specimen tests

Harbor should not promote a new durable noun unless it survives at least one specimen flow.

## Promotion gates
1. A proposed object must clearly name which stronger truths it refuses to claim.
2. It must survive one browser-based flow and one non-browser portal flow without changing meaning.
3. It must name which sibling cube owns the next stronger consequence.
4. It must not require Harbor to infer durable trust, object identity, runtime continuity, or browser/provider-local account truth on its own.
5. If the object speaks about UI posture, it must preserve the difference between silent attempt, chooser-light mediation, explicit interaction, and final adoption.
6. If the object speaks about hints or chooser shaping, it must preserve the difference between preference input, chooser priming, explicit reviewed selection, and final adoption.
7. If the object speaks about logout/reset/disconnect, it must preserve the difference between reset request, layer-local memory change, cold-start floor, and universal forgetfulness.
8. If the object speaks about freshness, it must preserve the difference between recency demand, returned auth-event time, current freshness verdict, and durable session/account truth.
9. If the object speaks about later security signals, it must preserve the difference between outside event statement, local receiver stance, next required revalidation floor, and durable session/account truth.
10. If the object speaks about matching handles or identifiers, it must preserve the difference between identifier format/scope, local match basis, mismatch/quarantine posture, and durable subject/session/account truth.
11. If the object speaks about status or presence adverts, it must preserve the difference between browser/provider-local advert, verification turn, mismatch/user-visible floor, and durable login/account/session truth.
12. If the object speaks about cancellation or deadlines, it must preserve the difference between caller/runtime abort, chooser dismissal, deadline bottom-out, provider refusal, and late completion.
13. If the object speaks about restarted or superseded lanes, it must preserve the difference between attempt-specific lane witness, fresher-lane supersession, stale-result quarantine, and current-lane adoption.
14. If the object speaks about fetched discovery or config surfaces, it must preserve the difference between raw fetched description, cache age/provenance, bounded overlay/resolution, and actual local admission truth.
15. If the object speaks about browser-messaging finishes, it must preserve the difference between expected lane, expected receiver origin, observed sender origin, message-shape validity, and durable adoption.
16. If the object speaks about cross-device interlocks, it must preserve the difference between real device split, human pairing cue, same-device veto/downgrade, and durable adoption.
17. If the object speaks about audience or exact target identity, it must preserve the difference between named server identity, exact endpoint URI target, returned target/resource cue, alias mismatch/veto, and durable adoption.
18. If the object speaks about requested-versus-issued resource targeting, it must preserve the difference between requested resource identity, discovery-time AS routing, exact proof target, issued target/resource echo, target-unbounded omission, and durable adoption.
19. If the object speaks about discovered target candidates or narrowed target outcomes, it must preserve the difference between discovery source/validation rule, candidate target services, explicit requested targets, accepted subset or typed `invalid_target` refusal, and durable adoption.
20. If the object speaks about token-time narrowing or assigned resources, it must preserve the difference between original grant breadth, current token-time restriction, returned requested anchors, returned server-assigned additions, typed target refusal, and durable entitlement/adoption truth.
21. If the object speaks about missing or weaker resource confirmation, it must preserve the difference between discovery-time routing, explicit requested anchors, assigned-only or unbounded omission, preconfigured-knowledge grace, strict-client discard posture, and durable adoption truth.
22. If the object speaks about default targets or broader coverage, it must preserve the difference between challenge-derived discovery scope, token-format audience/default cue, exact client-facing response confirmation, malformed or duplicated response confirmation, and durable adoption truth.
23. If the object speaks about token-format target evidence or receiver-local coverage, it must preserve the difference between token/introspection target witness, receiver-local accepted audience or alias family, explicit returned-resource confirmation, local mismatch veto, and durable adoption truth.
24. If the object speaks about JWT-secured introspection or returned-resource precedence, it must preserve the difference between signed recipient-facing introspection provenance, nested token target metadata, explicit returned-resource confirmation, receiver-local alias-family refusal, and durable adoption truth.
25. If the object speaks about recipient-target split, default or mapped audiences, or alias-family drift, it must preserve the difference between signed introspection recipient, token-format audience/default cues, explicit returned-resource confirmation, challenge-derived or local receiver coverage, and durable adoption truth.
26. If the object speaks about required authorization details or actionable RAR guidance, it must preserve the difference between target-valid fit, stronger-here authentication demands, missing scope, missing authorization details, request-scoped actionable offers, later granted or RS-filtered details, and durable entitlement/adoption truth.
27. If the object speaks about granted or filtered authorization details or schema-shaped refusals, it must preserve the difference between requested detail objects, token-response granted details, JWT/introspection receiver-visible filtered details, shape-validation/schema mismatch refusal, and durable entitlement/adoption truth.
28. If the object speaks about schema-sourced or receiver-enriched authorization details, it must preserve the difference between resource-metadata discovery, inline schema versus fetched `schema_uri`, client-built detail shape, receiver-visible filtered/enriched detail shape, stale-cache explanation, and durable entitlement/adoption truth.

## First specimen tests
- external-browser OAuth or MCP-style auth with exact callback proof classes;
- open-versus-import-versus-materialize comparison with explicit ViewFS handoff;
- verified association plus chooser flow where affiliation, eligibility, selection, and trust remain separate;
- provider-local session hint that improves UX without becoming durable native truth;
- predeclared native route whose late refinement narrows or excludes paths while honest fallback remains visible;
- browser-mediated sign-in or passkey retrieval where silent probe, conditional mediation, required reauth, and typed interaction-required aftermath stay visibly separate;
- account/domain/authenticator hinting where chooser priming remains visibly smaller than selected-account or selected-credential truth;
- logout/disconnect/reset behavior where layer-local memory cleanup remains visibly smaller than universal logged-out-everywhere truth.
- resource- or RP-originated recent-authentication demand where `max_age`, returned `auth_time`, and current freshness verdict stay visibly separate from token issuance.
- later security-event behavior where delivered attenuation notices remain visibly smaller than local receiver stance and portable live-session truth.
- scoped-match behavior where `sid`, `sub_id`, `account_id`, `userHandle`, or credential IDs remain visibly smaller than durable subject/session/account truth.
- browser/provider status-advert behavior where remembered `logged-in` or `changed` states shape the next turn while remaining visibly smaller than settled login/account/session truth.
- browser/runtime abort-and-deadline behavior where local stop signals and chooser dismissals remain visibly smaller than provider refusal or durable account/session truth.
- restarted-or-superseded crossing behavior where late old-lane completions remain visibly smaller than live-lane adoption or durable account/session truth.
- discovery/config behavior where fetched metadata, policy overlays, and stale-cache refresh remain visibly smaller than admitted route/resource truth.

- popup- or iframe-based browser-messaging behavior where opener/parent lane choice and sender/receiver origin checks remain visibly smaller than durable account/session/adoption truth.
- cross-device device-authorization or CIBA behavior where device split, user-visible pairing cues, and same-device veto posture remain visibly smaller than durable account/session/adoption truth.
- exact-target behavior where client-assertion audiences, JAR-or-PAR basis, and wrong-endpoint aliases remain visibly smaller than durable issuer/resource/grant truth.

- requested-versus-issued target behavior where request-target receipt, effective-target echo, and target-unbounded warning remain visibly smaller than discovered auth routes, exact endpoint proofs, and durable grant truth.
- discovery-versus-narrowing behavior where challenge-derived metadata, token-exchange target-service discovery, narrowed-target subset, and typed `invalid_target` refusal remain visibly smaller than durable entitlement or grant truth.
- grant-bounded-narrowing behavior where refresh-time restriction, scope-defined extra resources, assigned-only responses, and typed `invalid_target` refusal remain visibly smaller than durable entitlement or grant truth.
- confirmation-floor behavior where preconfigured omission grace, dynamically discovered missing confirmation, and requested-anchor mismatch remain visibly smaller than durable entitlement, grant, or adoption truth.
- default-target-and-coverage behavior where JWT default audiences, challenge-derived broader metadata coverage, and duplicate response confirmation failure remain visibly smaller than durable entitlement, grant, or adoption truth.
- token-introspection-or-JWT audience behavior where token-format target witnesses, resource-server coverage cards, and local-expectation mismatch remain visibly smaller than explicit returned-resource confirmation and durable entitlement/adoption truth.
- JWT-secured introspection behavior where signed recipient-facing introspection provenance, explicit returned-resource precedence, and alias-family mismatch remain visibly smaller than durable entitlement/adoption truth.
- recipient-target-split behavior where signed introspection recipient, broader/default token audience, explicit returned `resource`, and alias-family drift remain visibly smaller than durable entitlement/adoption truth.

26. If the object speaks about receiver-scoped disclosure, stronger-here challenges, or coverage drift, it must preserve the difference between target-valid token fit, receiver-scoped introspection disclosure, per-operation authentication insufficiency, broader challenge-derived discovery coverage, and durable adoption truth.

- receiver-scoped-introspection-plus-step-up behavior where narrowed scope disclosure, RFC 9470 stronger-here challenges, and broader challenge-derived coverage remain visibly smaller than durable entitlement, assurance, or adoption truth.

- required-authorization behavior where protected-resource metadata advertises accepted authorization-details combinations, `insufficient_authorization_details` optionally returns an actionable body, and step-up-plus-RAR recovery remains visibly smaller than durable entitlement or policy truth.

- granted-detail behavior where token-response granted details, receiver-filtered JWT or introspection details, and typed `invalid_authorization_details` bottoms remain visibly smaller than portable entitlement, schema, or policy truth.

- schema-source behavior where metadata discovery, inline schema versus fetched `schema_uri`, receiver-enriched detail views, and stale-cache mismatches remain visibly smaller than portable entitlement, schema, or policy truth.


- option-reservation export/view/sidecar/frontier/compiler behavior where observation-shaped exports, no-data derived views, optional sidecars, progress witnesses, compiled assertion targets, and schema transforms remain visibly smaller than source rows, public contracts, freshness, exactness, and semantic equivalence.

## Pass LXXX specimen expectation
Any future promotion packet that uses negative outcomes must include at least one specimen where a consumer asks for a cube-shaped answer and Harbor refuses, narrows, or labels it because sidecar evidence is missing, export policy blocks a component, an assertion target is unsupported, a frontier is stale, or tombstone evidence changes replay posture.


## Pass LXXXIII specimen expectation
Any future promotion packet that uses aggregate-disclosure vocabulary must include at least one specimen where a consumer asks for a public aggregate and Harbor suppresses, collapses, perturbs, or refuses it because of small-cell risk, denominator risk, dominance, sibling-cut differencing, repeated-query leakage, or missing privacy-accounting evidence.
