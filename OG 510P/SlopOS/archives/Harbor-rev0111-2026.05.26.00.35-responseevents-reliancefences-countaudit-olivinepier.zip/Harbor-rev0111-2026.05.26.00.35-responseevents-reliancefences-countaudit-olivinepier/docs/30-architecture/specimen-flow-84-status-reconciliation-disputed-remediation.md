# Specimen flow 84 — status reconciliation, disputed remediation, and public-status drift

**Revision:** `rev0089`  
**Status:** pressure-test specimen for `F084`; not a schema, status page, dispute tribunal, notification workflow, VEX/CSAF profile, in-toto predicate, transparency-log policy, moderation workflow, or final SlopOS datacube behavior.

## Purpose

Exercise one corrected public artifact after stale downstream impact has already been identified. The specimen verifies that Harbor can handle:

- a disputed remediation receipt;
- an expired acknowledgement;
- a contradictory external impact report;
- an unverifiable use/non-use attestation;
- a public status surface that drifted out of sync with the proof packet.

## Setup

Harbor previously released public aggregate copy `pub.copy.harbor.2026-q1-suppressed-v2`.

Known basis:

- source artifact: `harbor.cube.release.public-q1`;
- source cut: `cut:2026-05-13T20:58Z`;
- correction anchor: `corr:2026-05-15.small-denominator-label`;
- old payload digest: `sha256:old-payload-redacted`;
- old label digest: `sha256:old-labels-missing-small-denominator`;
- successor artifact: `pub.copy.harbor.2026-q1-suppressed-v3`;
- successor label digest: `sha256:new-labels-with-small-denominator-warning`;
- public status before this specimen: `resolved` on a catalog banner;
- proof packet status before this specimen: `remediation_claimed`, `residual_risk_unknown`.

## Flow

### 1. Downstream remediation is claimed

A catalog owner sends `remediation_attestation cat-rem-19`:

- subject: catalog card `catalog.example/harbor-q1`;
- action: `warning_added` and `download_replaced`;
- basis: public URL and human assertion;
- unsupported claims: old cache purged, users notified, derived dashboards repaired, old BI export removed;
- residual risk: not stated;
- recheck horizon: 48 hours.

Harbor records the claim as `claim_received`, not `remediation_verified`.

### 2. Consumer disputes the remediation

A consumer reports that a dashboard linked from the catalog still downloads the old CSV without the small-denominator label.

Harbor creates `remediation_challenge_receipt challenge-cat-rem-19`:

- challenged claim: `cat-rem-19`;
- challenged field: `download_replaced` for dashboard-linked CSV;
- evidence: observed old label digest in dashboard export;
- challenge type: `stale copy still visible` plus `missing label`;
- interim public status: `disputed remediation; use successor artifact`;
- sealed evidence: none needed.

Expected result: the catalog claim is not rejected wholesale. The catalog page may be repaired while a dashboard-linked export remains stale. Harbor marks `partially_reconciled` only for the page and `challenge_open` for the export.

### 3. Acknowledgement expires

The original acknowledgement `ack-consumer-07` is older than its recheck horizon and did not name the dashboard export.

Harbor creates `acknowledgement_expiry_note ack-exp-07`:

- expired acknowledgement: `ack-consumer-07`;
- reason: recheck horizon exceeded and subject set narrower than challenged export;
- safe consequence: re-notify, do not use as current repair evidence;
- non-promise: expiry does not prove use, refusal, non-use, or harm.

Expected result: status moves from `acknowledged_notice` to `acknowledgement_expired` for current posture. Historical acknowledgement remains in the record.

### 4. External impact report contradicts Harbor's severity copy

An external blog claims: "Harbor published unsafe exact values for the Q1 table and all derived dashboards are wrong."

Harbor creates `external_impact_claim_map ext-impact-04`:

- exact quoted value: not present in Harbor public copy;
- cited artifact: stale screenshot of a dashboard export, not source bundle;
- contradiction class: label omission true for one dashboard export; exact-value claim unsupported; all-dashboards claim unscoped;
- relation to Harbor status: narrows and partly contradicts public severity statement;
- safe reply: "One dashboard-linked export remained stale; the source bundle and catalog page now point to v3; all-dashboards and exact-value claims are not supported by the provided evidence."

Expected result: Harbor updates public wording to admit the confirmed stale export and rejects only the unsupported overbroad claims.

### 5. Non-use attestation cannot be verified

A downstream owner sends `use_attestation downstream-nonuse-11` claiming: "We did not use v2 in any model or evaluation."

Limitations:

- log retention expired before the relevant date;
- retrieval-index version not named;
- eval suite dependency lock not attached;
- model card updated but does not mention the correction anchor;
- manual review covered only one repository.

Harbor creates `use_attestation_challenge_note use-challenge-11`:

- result: `attestation_unverifiable`;
- safe status: `claimed non-use; evidence insufficient for proof`;
- recheck: request dependency lock, retrieval index version, and eval-card update.

Expected result: Harbor may record cooperation but must not render `not_used` or `model/eval repaired`.

### 6. Public status drift is detected

The public catalog banner still says `resolved` while the proof packet now says `disputed remediation`, `acknowledgement_expired`, and `attestation_unverifiable`.

Harbor creates `public_status_sync_receipt status-sync-22`:

- expected status: `disputed remediation; corrected source available; one dashboard export under challenge`;
- observed status: `resolved`;
- mismatch type: `resolved-versus-disputed` and `missing non-promises`;
- repair action: replace banner with safe disputed-status statement;
- observed repair: catalog page updated; search snippet/mirror status unknown;
- next recheck: 24 hours.

Expected result: status page repair does not claim every mirror/cache/snippet is current.

## Expected public copy

Safe public text:

> Harbor corrected the Q1 public copy to add the missing small-denominator label. The current artifact is `pub.copy.harbor.2026-q1-suppressed-v3`. A catalog page has been updated, but one dashboard-linked export is under remediation challenge. A prior acknowledgement has expired, and one downstream non-use claim is not verifiable from the evidence provided. Use v3 for new analysis. Harbor is not claiming universal recall, deletion from downstream models/evals, repair of prior decisions, or that every mirror/cache/search snippet is current.

This text is intentionally less satisfying than `resolved`. That is the point.

## Checks this specimen must pass

- The disputed remediation claim remains scoped by subject and action.
- The expired acknowledgement is preserved historically but removed from current proof.
- The external report is split into confirmed, unsupported, stale-citation, and overbroad pieces.
- The non-use attestation is recorded as a claim, not proof.
- The public status banner is repaired to match proof packet state.
- Suppressed/raw values, sealed logs, and private replay evidence are not exposed.
- The status packet has an unresolved-for-now outcome without pretending closure.

## Deliberate non-promotions

This specimen does not promote `status_reconciliation_packet`, `remediation_challenge_receipt`, `acknowledgement_expiry_note`, `external_impact_claim_map`, `use_attestation_challenge_note`, `public_status_sync_receipt`, `safe_disputed_status_statement`, or `unresolved_for_now_note` into canonical datacube schema.

It also does not choose a status page product, dispute tribunal, ticketing workflow, notification system, VEX/CSAF profile, in-toto predicate, SCITT/CT/Rekor transparency policy, public-reporting taxonomy, reputation score, or final SlopOS datacube shape.
