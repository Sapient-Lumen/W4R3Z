# Specimen flow 101 — overlapping correction epochs and derivative lineage

## Scenario

A source artifact is corrected under epoch A. Several consumer derivatives are repaired, some only acknowledged, some quarantined, and some retained as history. A second source correction arrives under epoch B, overlapping some epoch-A fields but not others. A rollback notice, an external conflicting correction, a local consumer patch, and mixed downstream subsets arrive before all derivatives converge.

The pressure is attractive shortcutting. Operators want the newest correction to win, the oldest repair receipt to remain current, a source-owner closure note to end the story, or a public green badge to summarize all mixed derivatives. Harbor must instead preserve lineage: which epoch, which derivative, which field scope, which clock, which recheck, and which history remains visible.

## Required packets

- source correction epoch packet;
- correction partial-order / clock-basis packet;
- derivative lineage edge packet;
- scope overlap / disjointness packet;
- rebase and delta-map packet;
- rollback-with-recheck packet;
- dispute / external-epoch packet;
- acknowledgement epoch packet;
- currentness-window packet;
- public badge refusal packet;
- non-promotion packet.

## Expected accepted outcomes

Harbor may admit scoped currentness for the latest named fields, historical retention for an earlier repair, coexistence for disjoint correction scopes, split derivative state for partial overlaps, rollback only with warning-history preservation and recheck, subset repair while unknown/stale subsets remain visible, consumer-patch rebasing with a delta map, stale acknowledgement as residue, external conflict as dispute/recheck-required, and named-field-only supersession.

## Expected refusals

Harbor must reject:

- latest epoch wins without scope-overlap map;
- epoch-A repair as current after overlapping epoch-B correction;
- rollback that erases intermediate warning history;
- disjoint corrections marked as conflict;
- overlapping corrections merged without delta map;
- consumer patch applied to the wrong epoch base;
- epoch-A acknowledgement counted for epoch B;
- derivative digest reuse across epochs;
- missing epoch order or clock basis;
- parallel epochs totally ordered without authority;
- field scope widened to the whole artifact;
- stale subset marked globally current;
- dispute epoch treated as repair;
- source-owner closure overriding lineage;
- retention expiry ignored for currentness;
- public green badge across mixed epochs;
- material rollback without recheck;
- cycle in the lineage graph.

## Why this matters to SlopOS

SlopOS can record accepted portal-net histories, append sequences, checkpoint/resume events, callback returns, and materialization receipts. Harbor must decide whether a later correction supersedes a derivative that was repaired under an earlier epoch. The SlopOS sequence can help bind evidence order, but it cannot decide currentness, scope overlap, or public badge posture by itself.

## Non-promotions

No correction-epoch registry, derivative repair ledger, conflict-resolution engine, source-owner closure authority, public badge workflow, consumer cache API, compliance workflow, or final SlopOS datacube shape is promoted by this specimen.
