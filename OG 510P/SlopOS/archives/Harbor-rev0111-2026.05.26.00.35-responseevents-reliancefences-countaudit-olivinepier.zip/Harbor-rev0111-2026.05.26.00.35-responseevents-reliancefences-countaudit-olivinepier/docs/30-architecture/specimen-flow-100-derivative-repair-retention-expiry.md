# Specimen flow 100 — derivative repair evidence retention and expiry

## Scenario

A source correction was propagated to local derivatives in F099. Some derivatives were repaired or superseded, some were quarantined, some received notice-only acknowledgements, and some remained unknown. Weeks later, Harbor must decide which records still support current derivative status and which are now only historical residue.

The pressure is that retention and expiry invite attractive shortcuts. A repair receipt may be retained past its recheck window, a legal-hold-like exception may keep evidence available, a tombstone may survive compaction, raw material may be pruned for minimization, a reviewer may waive a repeated warning for one revision, a source may be corrected again, or an old acknowledgement may be redisplayed from cache. None of those facts alone proves current repair.

## Required packets

- derivative repair subject packet;
- retained evidence packet;
- retention policy packet;
- expiry clock packet;
- compaction/tombstone packet;
- pruning/minimization packet;
- legal-hold or reviewer-waiver exception packet;
- recheck receipt packet;
- later source-correction packet;
- warning-residue preservation packet;
- retention non-promotion packet.

## Expected accepted outcomes

Harbor may admit active repair evidence inside its clocked retention window. It may also admit expired evidence as history with recheck required, compacted tombstones with subject/receipt digests, legal-hold-like records that preserve evidence but not freshness, prior repair evidence superseded by a later source correction, quarantined stale material after raw material pruning, digest-pointer-only residue, reopened stale recurrence warnings, privacy-minimized tombstones, and expiring reviewer waiver notes.

Accepted non-current outcomes must say exactly what they are: expired, compacted, held, quarantined, privacy-minimized, superseded, pointer-only, or reviewer-note-only.

## Expected refusals

Harbor must reject:

- expired repair receipt as current repair;
- retention policy as a truth extender;
- legal hold as freshness;
- compaction digest as full evidence;
- deletion as repair or clean slate;
- second source correction ignored;
- scheduled recheck as passed recheck;
- pruned raw evidence as verified success;
- quarantine expiry as repair;
- consumer acknowledgement valid after expiry;
- hold release that drops warning residue;
- clockless expiry windows;
- borrowed retention windows from another subject scope;
- tombstones without source/derivative subject digest;
- privacy minimization as proof of no stale copies;
- migrated evidence digests without a migration map.

## Why this matters to SlopOS

SlopOS can preserve portal, checkpoint, resume, truncation, append, and callback records. Harbor must decide when those records still support the current derivative status of a consumer artifact. A retained SlopOS/Harbor receipt is evidence history; it is not automatically current repair, freshness, or user-visible warning state after its expiry window.

## Non-promotions

No records-management system, legal-hold workflow, privacy-erasure API, retention schedule registry, evidence-vault format, consumer cache API, compliance workflow, or final SlopOS datacube shape is promoted by this specimen.
