# Specimen flow 44 — audience-basis witness, endpoint-target card, and alias veto

Goal: let Harbor describe a crossing where several exact identifiers coexist — issuer, authorization endpoint, PAR endpoint, token endpoint, DPoP target URI, and optional resource echo — without pretending that one polished provider label or one accepted alias settles all of them.

## Scenario
A Harbor-hosted product integrates with a provider that publishes one issuer and several operational endpoints.
It uses a signed JAR Request Object for the browser-facing authorization request, pushes that request through PAR, authenticates to PAR or the token endpoint with a JWT client assertion, and may also sender-constrain the token request with DPoP.

During implementation or later rollout:
- the signed Request Object uses the authorization-server issuer as its `aud` basis;
- the client assertion is supposed to use the exact endpoint URI that receives it as its sole `aud` value;
- the DPoP proof is supposed to bind to the exact HTTP target URI of the current request;
- one deployment alias, reverse-proxy hostname, or endpoint-class mix-up makes a structurally valid proof land at the wrong endpoint;
- and a token response may optionally echo which resource or target actually survived issuance-time policy.

Harbor must therefore preserve the difference between:
- “this envelope named the authorization server issuer,”
- “this proof or assertion targeted this exact endpoint URI,”
- “this target/resource is what the server says survived issuance-time selection,”
- “a same-provider or same-issuer alias still failed exact-target validation here,”
- and “none of those facts by themselves settle durable issuer, grant, account, session, or adopted consequence truth.”

## Candidate Harbor objects
1. **audience-basis witness**
   - compact residue showing why a particular identifier counted as the audience basis here (`issuer`, exact PAR endpoint, exact token endpoint, etc.);
   - useful because signed envelopes and client assertions can follow different exactness rules without either one becoming universal truth.

2. **endpoint-target card**
   - inspectable note of the exact endpoint URI a proof or assertion targeted;
   - useful because exact request-target residue helps explain wrong-endpoint failures without pretending to be durable resource/grant truth.

3. **alias veto**
   - explicit local or provider refusal when same-brand / same-issuer / same-host-family polish still points at the wrong endpoint alias or endpoint class;
   - useful because “close enough” target identity is precisely the confusion Harbor should keep visible.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- one crossing mixes issuer-scoped and endpoint-scoped audience/target rules;
- the same provider brand or issuer still spans multiple exact endpoints with different security roles;
- normalization, aliasing, or reverse-proxy shapes make a wrong endpoint look deceptively nearby;
- and a returned resource/target echo can improve explanation without becoming durable grant truth.

## Promotion rule
Do not promote `audience-basis witness`, `endpoint-target card`, or `alias veto` unless they improve:
- one client-assertion specimen where exact endpoint audience beats issuer-sameness folklore;
- one JAR-or-PAR specimen where authorization-server identity and endpoint-target identity remain visibly separate;
- and one endpoint-alias or wrong-endpoint-class specimen where visible veto beats counterfeit success.
