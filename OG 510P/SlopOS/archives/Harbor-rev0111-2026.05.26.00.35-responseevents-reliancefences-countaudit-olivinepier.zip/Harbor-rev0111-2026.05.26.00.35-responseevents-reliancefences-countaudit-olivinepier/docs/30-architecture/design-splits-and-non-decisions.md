# Design splits and non-decisions

## Splits Harbor is freezing early
- route eligibility versus admission decision;
- predeclared route ceiling versus late refinement/exclusion;
- browser detour versus durable trust meaning;
- continuity residue versus portable session/account truth;
- disconnect pulse versus universal logout / universal forgetfulness;
- attenuation notice versus receiver stance;
- correlation handle versus durable subject/session/account truth;
- presence advert versus current login/account/session truth;
- event delivery posture versus live session/account truth;
- import/open/materialize/grant outcome classes;
- callback arrival versus completed consequence;
- displayed-party cue versus durable issuer/account truth;
- structured return parcel versus durable adoption;
- connection-context witness versus durable issuer/account/toolkit/tenant truth;
- foreign-finish veto versus durable consequence;
- receiver-origin witness versus durable route/adoption truth;
- secondary-window lane versus durable session/account truth;
- message-origin fence versus durable consequence;
- device-split witness versus durable account/session/adoption truth;
- pairing cue versus durable approval/adoption truth;
- same-device veto versus generic route convenience or durable denial;
- cleanup pulse versus universal logout or durable account deletion;
- stale-chooser quarantine versus durable mismatch or adopted-account truth;
- display-refresh residue versus durable subject/account truth;
- request-target receipt versus durable resource/grant truth;
- effective-target echo versus durable grant/adoption truth;
- unbounded-target warning versus counterfeit exactness;
- grant-bounded narrowing floor versus durable entitlement/grant truth;
- server-assigned addition versus exact request mirroring;
- target-refusal rail versus generic auth failure;
- assigned-only lane versus exact request mirroring;
- resource-confirmation floor versus counterfeit exactness;
- default-target cue versus exact client-facing confirmation;
- coverage note versus durable resource/grant truth;
- confirmation-gap receipt versus silent acceptance;
- schema-source note versus Harbor-owned type law;
- receiver-enriched detail card versus universal grant truth;
- cache-staleness detail warning versus generic auth/session failure;
- aftermath receipt versus neighboring-cube completion.

## Non-decisions still open
- whether Harbor needs a single generic request envelope or a family of narrowly typed ones;
- how much route explanation belongs in the receipt versus a separate trace object;
- whether chooser, callback, and provider wait states should share one lifecycle vocabulary;
- how far Harbor should go in representing speculative routes that were never offered to the user;
- whether materialization lineage is a Harbor export or merely a handoff hint to ViewFS;
- whether route ceiling belongs inside the route set or beside it as a separate first-class card;
- whether continuity hint belongs in Harbor at all, or should remain only an inspiration/hint borrowed from neighboring surfaces;
- whether returning-account hint is a Harbor noun or merely provider/browser-local context that should stay outside the cube;
- whether memory reset belongs in Harbor at all, or should remain only a neighboring-layer signal with one smaller cold-start vocabulary;
- whether attenuation notice belongs in Harbor at all, or should remain only neighboring-layer status with one smaller revalidation vocabulary;
- whether correlation handle belongs in Harbor at all, or should remain only a neighboring-layer matching aid with one smaller mismatch vocabulary;
- whether presence advert belongs in Harbor at all, or should remain only a neighboring/browser signal with one smaller verification vocabulary;
- whether match witness deserves its own family or merely rides inside aftermath receipts;
- whether receiver stance is a Harbor noun or merely local product behavior that should stay outside the cube.
- whether Harbor needs one coarse origin cue or a richer displayed-party split when an embedded requester and a top-level site both matter;
- whether a structured return parcel belongs in Harbor at all, or should remain only an annotation on existing outcome/aftermath surfaces;
- whether Harbor needs a first-class connection-context witness, or whether exact context should remain only lane/basis residue;
- whether finish-hash witness belongs in Harbor at all, or should remain an implementation-local verifier detail that only leaks out through a smaller veto/receipt vocabulary;
- whether Harbor needs a first-class receiver-origin witness, or whether exact browser-message targeting should remain only lane/basis residue;
- whether secondary-window lane belongs in Harbor at all, or should remain only a browser-detour detail that leaks out through a smaller veto/receipt vocabulary;
- whether Harbor needs a first-class device-split witness, or whether cross-device posture should remain only detour/aftermath residue;
- whether pairing cue belongs in Harbor at all, or should remain only a review/interlock annotation on existing detour surfaces;
- whether same-device veto belongs in Harbor, or should stay a smaller route/admission consequence with receipt-only visibility;
- whether Harbor needs a first-class cleanup pulse, or whether chooser/authenticator cleanup should remain only smaller aftermath residue;
- whether stale-chooser quarantine belongs in Harbor at all, or should remain only a local revalidation/veto consequence;
- whether display-refresh residue belongs in Harbor, or should stay a compact review/selection note with receipt-only visibility;
- whether request-target receipt belongs in Harbor at all, or should remain only a request-envelope annotation with smaller aftermath visibility;
- whether effective-target echo deserves a first-class Harbor noun, or should remain only a smaller aftermath note on specific auth specimens;
- whether unbounded-target warning belongs in Harbor, or should stay a typed local caution that never blooms into a target-negotiation family;
- whether discovery-source note belongs in Harbor at all, or should remain only a request/discovery annotation with smaller aftermath visibility;
- whether narrowed-target subset deserves a first-class Harbor noun, or should remain only a smaller aftermath note on specific auth specimens;
- whether target-negotiation rail belongs in Harbor, or should stay a typed local explanation that never blooms into a portable target-service or entitlement registry;
- whether grant-bounded narrowing floor deserves a first-class Harbor noun, or should remain only a request/aftermath annotation with smaller visibility;
- whether server-assigned addition belongs in Harbor at all, or should remain only a note attached to specific token-response specimens;
- whether target-refusal rail belongs in Harbor, or should stay a typed local explanation that never blooms into a portable entitlement or target-policy registry;
- whether assigned-only lane deserves a first-class Harbor noun, or should remain only a request/aftermath annotation with smaller visibility;
- whether requested-anchor minimum belongs in Harbor at all, or should remain only a client-validation note on specific token-response specimens;
- whether resource-confirmation floor belongs in Harbor, or should stay a typed local explanation that never blooms into a portable entitlement or target-confirmation registry;
- whether default-target cue belongs in Harbor at all, or should remain only a token-format annotation with smaller aftermath visibility;
- whether coverage note deserves a first-class Harbor noun, or should remain only a discovery annotation on specific protected-resource metadata specimens;
- whether confirmation-gap receipt belongs in Harbor, or should stay a typed local explanation that never blooms into a portable target-inference, coverage, or confidence registry;
- whether token-format target witness belongs in Harbor at all, or should remain only a token/introspection annotation with smaller aftermath visibility;
- whether resource-server coverage card deserves a first-class Harbor noun, or should remain only a local receiver-policy annotation on specific protected-resource specimens;
- whether client-confidence ladder belongs in Harbor, or should stay a typed local explanation that never blooms into a portable target-confidence or entitlement registry;
- whether JWT introspection response card belongs in Harbor at all, or should remain only a signed receiver-facing annotation on specific introspection aftermath surfaces;
- whether response-over-token precedence deserves a first-class Harbor noun, or should remain only a standing interpretation rule on specific token/aftermath specimens;
- whether alias-family mismatch note belongs in Harbor, or should stay a typed local explanation that never blooms into a portable alias, coverage, or target-confidence registry;
- whether recipient-target split belongs in Harbor at all, or should remain only a signed-recipient annotation on specific introspection aftermath surfaces;
- whether returned-resource-over-default-audience conflict deserves a first-class Harbor noun, or should remain only a standing interpretation rule on specific token-response specimens;
- whether alias-family drift note belongs in Harbor beyond specific receivers, or should remain a typed local explanation that never blooms into a portable alias or target-confidence registry;
- whether granted-detail view deserves a first-class Harbor noun, or should remain only an annotation on specific token-response aftermath surfaces;
- whether filtered-detail card belongs in Harbor at all, or should remain only a receiver-scoped note on specific JWT or introspection aftermath surfaces;
- whether detail-schema veto belongs in Harbor, or should stay a typed local explanation that never blooms into a portable validation, schema, or policy registry;

## Process non-decisions
- do not create a boundary-family map until at least three recurring seams have earned it;
- do not create a giant registry or schema family until at least two specimen tests need it;
- do not let a convenience integration define the cube’s permanent object model;
- do not create a portable route-memory, session-continuity, or connected-account family before same-browser, mismatch, and cross-browser specimens agree on its smallest truthful shape;
- do not let one sign-out gesture define a universal logout object before OIDC, FedCM, Credential Management, and WebAuthn cleanup specimens agree on the smallest truthful shape;
- do not let one event-stream integration define a generic live-session or stream-management object before SET/SSF/CAEP specimens and sibling cubes agree on the smallest truthful shape;
- do not let one scoped identifier (`sid`, `sub_id`, `account_id`, `userHandle`, or credential ID) define a portable subject/session/account object before logout, disconnect, and local-match specimens agree on the smallest truthful shape.
- do not let two closely related specimen noun clusters accumulate across revisions without either compressing them or paying for explicit structure in the same revision;
- do not let preconfiguration, discovery, or JWT audience defaults silently stand in for issuance-time resource confirmation before omission and mismatch specimens agree on the smallest truthful shape;
- do not let challenge-derived broader coverage, token-format default audiences, or malformed returned `resource` arrays silently collapse into one generic target-confidence object before exact-confirmation specimens agree on the smallest truthful shape;
- do not let introspection audiences, JWT `aud` lists, or one protected resource's local alias family silently collapse into a portable target-confidence or coverage registry before response-confirmed and mismatch-veto specimens agree on the smallest truthful shape;
- do not let a JWT-secured introspection wrapper, a returned `resource` value, and a receiver's alias-family acceptance rules silently collapse into one generic protected-resource truth object before precedence and refusal specimens agree on the smallest truthful shape;
- do not let signed recipient audiences, default or mapped token audiences, and explicit returned `resource` confirmations silently collapse into one portable target-confidence object before split/conflict/drift specimens agree on the smallest truthful shape;
- do not let token-response granted `authorization_details`, receiver-filtered JWT/introspection detail views, and schema metadata or examples silently collapse into a portable entitlement, schema, or policy registry before granted/filter/veto specimens agree on the smallest truthful shape;

## rev0022 pressure note
- same-device continuity versus portable session export;
- returning-account hint versus durable account binding;
- revalidation turn versus counterfeit smooth resume;
- mismatch honesty versus silent restart or overclaim.

- do not let one login-status hint, changed-session signal, or empty-account fetch define a portable login-state plane before FedCM, OIDC Session Management, and privacy-preserving discovery specimens agree on the smallest truthful shape.

- receiver-scoped disclosure note versus portable token meaning;
- stronger-here challenge rail versus generic invalid-target or invalid-token failure;
- coverage-drift note versus portable receiver-policy registry.

- whether receiver-scoped disclosure note deserves a first-class Harbor noun, or should remain only an annotation on introspection aftermath;
- whether stronger-here challenge rail belongs in Harbor at all, or should remain only a typed ending on specific step-up specimens;
- whether coverage-drift note belongs in Harbor, or should remain a local explanation that never blooms into a portable receiver-policy or auth-strength registry.


- whether required-authorization rail deserves a first-class Harbor noun, or should remain only an annotation on specific protected-resource challenge specimens;
- whether actionable authorization-detail offer belongs in Harbor at all, or should remain only a request-scoped note attached to one aftermath surface;
- whether authorization-type slate belongs in Harbor, or should stay a compact local discovery/challenge explanation that never blooms into a portable entitlement or policy registry;
- do not let required-types expressions, actionable authorization-detail bodies, and later granted or RS-filtered authorization_details silently collapse into one portable authorization-policy or entitlement object before challenge/grant/filter specimens agree on the smallest truthful shape.

- whether schema-source note belongs in Harbor at all, or should remain only a discovery/request annotation attached to specific authorization-detail specimens;
- whether receiver-enriched detail card belongs in Harbor at all, or should remain only a verifier-scoped note on JWT or introspection surfaces;
- whether cache-staleness detail warning belongs in Harbor at all, or should stay a typed local explanation that never blooms into a portable schema/cache registry.

- whether trusted-schema-audience note belongs in Harbor at all, or should remain only a challenge/retry annotation attached to specific insufficient-authorization-details aftermath surfaces;
- whether schema-rotation repair receipt belongs in Harbor at all, or should remain only a local aftermath note on specific retry specimens;
- whether detail-retry cache epoch belongs in Harbor at all, or should stay a typed local explanation that never blooms into a portable trusted-AS, schema, or retry registry.
- do not let actionable authorization-detail bodies, trusted authorization-server sets, stale-body replay posture, and repair-after-rotation silently collapse into a portable policy/schema/retry registry before replay/trust-set/repair specimens agree on the smallest truthful shape.
