# Architecture overview

Harbor is strongest when it tells the truth about **crossing** rather than pretending crossing is itself success, logout, or universal forgetting.

The founding Harbor chain is:

1. **request envelope** — what the caller is asking for;
2. **route set** — what routes are even eligible right now;
3. **admission decision** — which route was actually allowed;
4. **detour state** — chooser, browser, callback, provider-local wait, pending, refusal, duplicate/replay handling, caller abort, deadline bottom-out, user review, or review-surface provenance;
5. **outcome class** — launch, reveal, open-in-place, materialize, grant, handback, or refusal;
6. **aftermath receipt** — what Harbor can honestly say happened and what stronger work remains elsewhere.

Harbor does **not** own:
- durable object identity (that pressure belongs with ViewFS),
- durable trust verdicts (that pressure belongs with Ward),
- runtime realization or continuity on foreign ground (that pressure belongs with Foundry),
- shell/compositor policy as a whole (that pressure belongs with Helm),
- or lifecycle/accounting truth for long-running work (that pressure belongs with Steward).

Harbor’s job is to make exchange events **legible** to those neighboring cubes without flattening them.

## rev0003 posture additions
- keep snapshot, callback, and provider success signals visibly weaker than durable local consequence;
- prefer one or two specimen artifacts before inventing family-wide registries;
- track downgrade and freshness as first-class modifiers instead of folding them into a success bit;
- keep recency asks, returned auth-event times, and current freshness verdicts visibly separate from token issuance or generic session truth;
- keep occurrence time, validity time, knowledge time, and published-cut time visibly separate from one another and from one ambient “latest” answer;
- keep later attenuation notices, receiver stances, and revalidation floors visibly separate from delivery mechanics or portable live-session truth;
- keep status adverts, verification turns, and mismatch floors visibly separate from durable login/account/session truth.

- keep replay witnesses, duplicate suppression, and spent crossing chances visibly separate from portable resume or exactly-once folklore;
- keep local abort pulses, deadline floors, and raced completions visibly separate from provider refusal or durable account/session truth;
- keep requested assurance, achieved rungs, and method receipts visibly separate from portable assurance registries or durable account/session truth;
- keep claim asks, release bundles, and source witnesses visibly separate from locally adopted subject/account truth or portable profile registries;
- keep prompt provenance, reviewed summaries, and review witnesses visibly separate from requester-owned copy and durable grant/account/session truth;
- keep display-bound review cards, origin cues, bounded fields, and truncation honesty visibly separate from durable approval, grant, account, and session truth;
- keep coarse origin cues, preview assets, chooser labels, and asset honesty visibly separate from durable issuer, approval, grant, account, and session truth;
- keep connection-context witnesses, finish-hash witnesses, and foreign-finish vetoes visibly separate from durable issuer, account, toolkit, tenant, and adopted-consequence truth;
- keep device-split witnesses, pairing cues, and same-device vetoes visibly separate from durable issuer, account, session, and adopted-consequence truth.
- keep cleanup pulses, stale-chooser quarantine, and display-refresh residue visibly separate from durable issuer, account, session, and adopted-consequence truth.
- keep audience-basis witnesses, endpoint-target cards, and alias vetoes visibly separate from durable issuer, resource, grant, account, session, and adopted-consequence truth.
- keep request-target receipts, effective-target echoes, and unbounded-target warnings visibly separate from discovered AS routes, exact proof targets, durable issuer/resource/grant/account/session truth, and adopted-consequence meaning.
- keep discovery-source notes, narrowed-target subsets, and target-negotiation rails visibly separate from portable target-service catalogs, durable entitlement/grant truth, and adopted-consequence meaning.
- keep grant-bounded narrowing floors, server-assigned additions, and target-refusal rails visibly separate from durable entitlement, grant, and adopted-consequence meaning.
- keep assigned-only lanes, requested-anchor minimums, and resource-confirmation floors visibly separate from discovery-time routing, durable entitlement/grant truth, and adopted-consequence meaning.
- keep token-format target witnesses, resource-server coverage cards, and client-confidence ladders visibly separate from explicit returned-resource confirmation, durable entitlement/grant truth, and adopted-consequence meaning.
- keep JWT introspection response cards, response-over-token precedence, and alias-family mismatch notes visibly separate from signed receiver-facing provenance, nested token audience hints, durable entitlement/grant truth, and adopted-consequence meaning.
- keep recipient-target splits, returned-resource-over-default-audience conflicts, and alias-family drift notes visibly separate from signed recipient provenance, default or mapped token audiences, exact returned-resource confirmation, challenge-derived coverage, durable entitlement/grant truth, and adopted-consequence meaning.

- keep receiver-scoped disclosure notes, stronger-here challenge rails, and coverage-drift notes visibly separate from exact target validity, broader token folklore, durable entitlement/assurance/grant truth, and adopted-consequence meaning.
- keep granted-detail views, filtered-detail cards, and detail-schema vetoes visibly separate from requested detail objects, receiver-scoped visibility, portable entitlement/policy/schema truth, and adopted-consequence meaning.
- keep schema-source notes, receiver-enriched detail cards, and cache-staleness detail warnings visibly separate from human-readable docs/examples, built-request shapes, portable entitlement/policy/schema truth, and adopted-consequence meaning.
- keep trusted-schema-audience notes, schema-rotation repair receipts, and detail-retry cache epochs visibly separate from actionable-body payloads, trusted-AS drift, durable entitlement/policy/schema truth, and adopted-consequence meaning.
- keep publish lane cards, branch rehearsals, historical tags, and promotion merge receipts visibly separate from engine choice, generated artifacts, and durable identity/trust/runtime truth.
- keep checker source digests, fixture pairings, guard-state receipts, self-test receipts, and reviewer overrides visibly separate from subject-bundle truth, CI status, checker certification, and trust-root authority.


## Datacube conformance seam
Harbor now keeps a small datacube conformance seam: conformance-lane cards, bridge witnesses, and identity-shadow notes are allowed as review residue smaller than row meaning, smaller than time-axis posture, and smaller than any premature canonical-entity or MDM stack.
