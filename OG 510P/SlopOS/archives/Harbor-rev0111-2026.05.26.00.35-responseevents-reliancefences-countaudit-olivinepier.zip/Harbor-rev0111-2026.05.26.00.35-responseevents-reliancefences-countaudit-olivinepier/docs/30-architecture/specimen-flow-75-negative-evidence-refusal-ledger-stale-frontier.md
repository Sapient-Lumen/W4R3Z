# Specimen flow 75 — negative evidence, refusal ledger, and stale-frontier honesty

Goal: pressure-test `F075` without promoting a global incident manager, refusal ledger schema, sidecar registry, assertion compiler, frontier service, tombstone model, or public negative-evidence API.

## Scenario
A consumer asks Harbor for a public datacube slice derived from `callback-observation-exchange-v0`:

- group callback attempts by provider family and hour;
- include one optional row-lineage sidecar so a reviewer can trace a suspicious count;
- export the observation slice under a sanitized tier;
- compile the public freshness / uniqueness / non-null assertion subset to a target warehouse check;
- label the output as fresh through the latest event-time watermark;
- and provide a reason if the answer cannot be emitted.

The request arrives after a source repair window:

- the base source rows exist at cut `cut-callback-2026-05-13T21:40Z`;
- the statistics sidecar is present but the row-lineage sidecar was not produced for this cut;
- the sanitized export policy now forbids `provider_account_hint` and any raw callback URL evidence;
- the chosen assertion target cannot express Harbor's `withheld != null` presence rule;
- the latest event-time watermark is older than the consumer's requested freshness threshold;
- a compacted correction feed contains a deletion marker for one old callback attempt key, but the purge/reuse fence has not elapsed.

A naive system would still emit a polished cube-looking table, perhaps with empty lineage, silent redaction, a green target check, and a stale-but-unlabeled freshness badge.

Harbor refuses that counterfeit.

## Candidate negative evidence rows

### NE-75-01 — missing row-lineage sidecar
- class: `missing_optional_evidence`
- basis: `cut-callback-2026-05-13T21:40Z`
- linked artifact: `callback-observation-exchange-v0`
- expected sidecar: `row-lineage/debug-v0`
- absence cause: `not_produced_for_cut`
- consumer consequence: grouped counts may still be reviewed, but row trace drilldown must be hidden and labeled unavailable
- anti-counterfeit warning: missing lineage is not proof that source rows lack lineage or that rows are absent

Healthy behavior: Harbor can emit the base aggregate only if every other proof obligation passes; the lineage drilldown card stays unavailable with a bounded note.

### NE-75-02 — blocked sanitized observation export
- class: `blocked_by_policy`
- basis: active sanitized export policy digest `obspol-sanitized-2026-05-13`
- requested artifact: observation-shaped public export with provider hints and callback URL evidence
- blocked components: `provider_account_hint`, `raw_callback_url`, `raw_error_fragment`
- smaller export: allowed only if the component list is narrowed to provider family, hour bucket, counts, evidence grade, and withheld-field notes
- anti-counterfeit warning: blocked export is not proof that the hinted provider account or URL evidence is absent

Healthy behavior: Harbor refuses the original request and offers a smaller export shape with explicit withheld-field notes. It does not leak whether any specific sensitive value was present.

### NE-75-03 — unsupported assertion compilation
- class: `unsupported_target`
- source assertion: `callback_public_contract_presence_v0`
- unsupported semantics: target warehouse check cannot distinguish explicit null, withheld, default-shadowed, and not-observed states
- generated artifact: none for this assertion; other independent assertions may compile separately
- result posture: `no-result` for the unsupported assertion, not green, not warning by default
- anti-counterfeit warning: unsupported target does not mean the source assertion passed or was unnecessary

Healthy behavior: Harbor records an unsupported-target note, refuses to widen the public contract, and requires either a target with presence semantics or an observe-only manual review lane.

### NE-75-04 — stale event-time frontier
- class: `stale_progress`
- frontier domain: event-time watermark
- observed frontier: `2026-05-13T20:58Z`
- observation time: `2026-05-13T21:45Z`
- requested claim: fresh through `2026-05-13T21:30Z`
- stale reason: `age_threshold` plus `late_data_aperture_open`
- acceptable answer: preview-only as-of old frontier, or refuse fresh label
- anti-counterfeit warning: stale event-time frontier is not the same as stale published-cut time and is not permanent incompleteness

Healthy behavior: Harbor may show an as-of preview with an old-frontier label, but it refuses the requested fresh-through badge.

### NE-75-05 — tombstone / withdrawal humility
- class: `withdrawn_currently`
- key family: source-scoped callback attempt key
- marker: compacted correction-feed tombstone for one old key
- current lookup behavior: ordinary public lookup treats the attempt as withdrawn from the current slice
- retention posture: tombstone may be compacted after retention; replay cut may need a frozen snapshot to keep the negative evidence visible
- resurrection hazard: do not reuse the same key or treat compaction as proof that the event never existed
- anti-counterfeit warning: tombstone is not null, not safe purge, and not no-history

Healthy behavior: Harbor excludes the withdrawn attempt from the current aggregate only when the replay/restatement basis says so, and it records that future exact replay requires the relevant cut or tombstone evidence to survive.

### NE-75-06 — consumer-facing refusal ledger row
- class: `missing_required_evidence`
- refused action: publish the requested fresh, lineage-drillable, sanitized public cube slice
- missing obligations:
  - required export component policy proof for original shape;
  - required presence-semantics compiler proof for one assertion;
  - required freshness frontier for requested fresh-through label;
- safe alternative:
  - emit a narrowed preview-only aggregate with withheld-field notes and no lineage drilldown; or
  - queue a rebuild / target-engine change / policy review before publication
- visibility: consumer-visible summary plus operator-visible details
- expiry: recheck after next lineage build, policy review, or frontier advance
- anti-counterfeit warning: refusal of this publish action is not proof that the underlying counts are false

Healthy behavior: Harbor returns a bounded refusal message and an operator ledger row. It does not return a polished table that hides missing proof.

## Proof obligations exercised

| obligation | status in this specimen |
| --- | --- |
| PO-DC-003 presence proof | satisfied for withheld vs null distinctions in the refusal, not in the target compiler |
| PO-DC-004 evidence proof | satisfied for missing sidecar / no-result / stale frontier distinctions |
| PO-DC-009 contract/evidence proof | refused for public contract widening because one assertion cannot compile faithfully |
| PO-DC-010 derived-artifact proof | satisfied only for a narrowed preview export, not the original requested export |
| PO-DC-011 sidecar optionality proof | satisfied by keeping missing row lineage smaller than row truth |
| PO-DC-012 noun-promotion proof | not satisfied for durable negative-evidence schema promotion |
| PO-NE-001 negative-class proof | satisfied for five bounded negative classes |
| PO-NE-002 refusal-lifecycle proof | satisfied by created / visible / actionable / recheck / retired posture |

## Adversarial checks

| counterfeit | expected Harbor response |
| --- | --- |
| missing sidecar shown as zero rows | reject; sidecar absence is helper-evidence absence only |
| blocked export shown as complete export with blanks | reject; redaction/withholding is not null or blank |
| unsupported compiler target shown as green assertion | reject; no-result is neither pass nor warn unless policy says so |
| stale watermark shown as fresh-through badge | reject; preview-only or refuse fresh label |
| tombstone treated as safe purge or no-history | reject; retention and resurrection fence must be named |
| refusal ledger treated as public blacklist | reject; refusal is scoped to action, basis, audience, and expiry |
| consumer refusal leaks sensitive component names | reject; consumer copy must stay within export policy |
| exact replay demanded after compaction | reject unless frozen cut or retained tombstone evidence survives |

## Review copy examples

Consumer-visible bounded refusal:

> Harbor cannot publish the requested fresh public cube slice. The request needs evidence that is missing or unsupported for this cut. A narrowed preview as of the older frontier is available without row-lineage drilldown and with withheld-field notes.

Operator-visible refusal row:

```yaml
request_id: req-public-callback-cube-2026-05-13-01
basis_cut: cut-callback-2026-05-13T21:40Z
refused_action: publish_requested_fresh_lineage_drillable_slice
negative_classes:
  - missing_optional_evidence
  - blocked_by_policy
  - unsupported_target
  - stale_progress
  - withdrawn_currently
missing_proof_obligations:
  - export_policy_allows_original_components
  - assertion_target_preserves_presence_semantics
  - frontier_fresh_through_requested_threshold
consumer_message_class: bounded_refusal_with_preview_offer
safe_alternative: narrowed_preview_as_of_old_frontier_without_lineage_drilldown
recheck_triggers:
  - row_lineage_sidecar_rebuilt_for_cut
  - export_policy_review_completed
  - target_engine_presence_semantics_available
  - event_time_frontier_advances_or_rebuild_completes
non_promises:
  - refusal_does_not_mean_counts_false
  - missing_sidecar_does_not_mean_missing_rows
  - blocked_export_does_not_mean_sensitive_values_absent_or_present
  - tombstone_does_not_mean_safe_purge_or_no_history
```

## Verdict
Negative evidence and refusal-ledger vocabulary is useful as **process residue**. It lets Harbor tell consumers and operators why a cube-shaped answer is withheld, narrowed, stale-labeled, or preview-only.

This pass does **not** promote:

- a Harbor-wide refusal ledger schema;
- a public negative-evidence API;
- a global incident manager;
- a sidecar registry;
- an assertion compiler stack;
- a tombstone/delete implementation;
- a frontier/freshness service;
- or durable Harbor datacube cards for the negative classes.

Followthrough `F075` is complete. The next pressure should focus on replay-after-compaction and exact historical answer survivability: when frozen cuts, tombstones, sidecars, and late corrections have different retention windows, Harbor needs to know which old answers remain exactly reproducible and which only remain explainable.
