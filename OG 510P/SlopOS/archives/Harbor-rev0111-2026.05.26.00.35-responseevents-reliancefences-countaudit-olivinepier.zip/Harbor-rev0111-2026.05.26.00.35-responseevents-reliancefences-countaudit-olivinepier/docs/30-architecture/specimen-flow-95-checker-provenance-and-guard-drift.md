# Specimen flow 95 — checker provenance and guard drift

## Intent

Pressure-test Harbor after F094 by asking whether the executable checker stack can produce evidence about itself without becoming a registry, CI API, or trust-root system.

## Setup

Harbor has five executable proof slices:

1. CrossingRecord v0 evidence.
2. Transparency/provenance receipt import.
3. Verifier disagreement and policy-epoch drift.
4. Property/mutation coverage.
5. Mutation triage.

A reviewer now wants to rely on the latest pass.  Harbor must preserve what was checked, which checker source observed it, which fixture it was paired with, which guards were enabled, and whether a self-test receipt exists.

## Packets exercised

```text
checker_source_digest_packet
harness_source_digest_packet
fixture_pairing_packet
guard_state_receipt
selftest_receipt
stale_pairing_refusal
missing_selftest_refusal
reviewer_override_packet
bootstrap_non_promotion_note
```

## Accepted cases

- current CrossingRecord checker observation;
- current transparency/provenance receipt checker observation;
- current verifier-disagreement checker observation;
- current property/mutation checker observation;
- current mutation-triage checker observation;
- a scoped reviewer override packet that preserves the machine result, expires after the next revision, and requires followthrough if repeated.

## Rejected cases

- disabled guard evidence where one required guard is reported off;
- stale fixture/checker pairing where a prior fixture revision/digest is paired with the current checker source;
- checker observation with no self-test receipt;
- reviewer override attempt that marks failure as success, claims global scope, or has no expiry.

## Expected refusals

Harbor must not say:

```text
checker passed, therefore subject truth is established
self-test passed, therefore checker is certified
source digest present, therefore trust root exists
reviewer approved, therefore failure became success
fixture digest present, therefore fixture/checker pair is current
Do not claim CI green, compliant, resolved, or globally safe
```

## Executable surfaces

- Fixture: `fixtures/harbor-checker-provenance-bundle-v0.json`.
- Harness: `tools/harbor_checker_provenance_harness.py`.
- Checker: `tools/check_harbor_checker_provenance_bundle.py`.
- Verification contract: `docs/40-verification/harbor-checker-provenance-bundle-v0.md`.

## Promotion result

F095 closes as an executable pressure test.  It promotes no checker registry, CI status API, trust-root schema, automated reliance workflow, checker certification badge, recursive self-attestation scheme, or final SlopOS datacube shape.
