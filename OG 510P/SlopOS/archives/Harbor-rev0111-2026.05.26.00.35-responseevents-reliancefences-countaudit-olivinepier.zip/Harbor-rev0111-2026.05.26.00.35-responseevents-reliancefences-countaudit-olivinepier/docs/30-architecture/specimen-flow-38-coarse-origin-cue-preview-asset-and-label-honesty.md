# Specimen flow 38 — coarse origin cue, preview asset, and label honesty

Goal: let Harbor describe host-owned chooser/review surfaces that show coarse requester provenance plus optional visual previews and labels, without letting any of that UI chrome masquerade as issuer, account, approval, or adopted-truth state.

## Scenario
A crossing reaches a host-owned chooser or review surface:
- an authorization server displays `client_name` and `logo_uri` to help a user recognize the requesting client;
- a browser-mediated FedCM chooser displays account pictures and only a filtered subset of labeled accounts;
- or a credential chooser displays a site icon or account label while still needing to protect chooser privacy.

During the crossing, several pressure points appear:
- the human needs to know *which origin* is asking, but the cue may remain origin-scoped and pathless;
- images, logos, and pictures can help recognition, but they may be stale, transformed, cached, or omitted;
- labels can narrow which candidates appear without proving anything about selected-account or issuer truth;
- and the platform may deliberately suppress or prefetch assets to avoid leaking chooser use.

Harbor should therefore preserve the difference between:
- “this was the coarse origin cue on the host-owned review surface,”
- “this visual preview asset was shown (or intentionally not shown) as a recognition aid,”
- “this chooser label filtered or annotated the visible candidates,”
- and “none of those facts by themselves settled issuer truth, selected-account truth, or approved consequence.”

## Proposed Harbor objects
1. **coarse origin cue**
   - explicit origin-scoped provenance cue carried on a host-owned chooser or review card;
   - useful because it gives enough provenance for anti-spoofing without pretending the entire request path or callback basis was shown.

2. **preview asset**
   - logo, icon, picture, or other bounded visual aid shown on a chooser/review surface;
   - useful because recognition can matter even when the asset remains smaller than issuer/account truth.

3. **chooser label**
   - small label/badge/category used to narrow or distinguish visible candidates;
   - useful because filtering and categorization can shape the chooser without becoming selected-account truth.

4. **asset honesty**
   - inspectable residue that a preview asset or label may have been cached, transformed, omitted, filtered, or otherwise only partially representative;
   - useful because visual aids are still real crossing history, but not canonical truth.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- caller-supplied names or logos are shown to help recognition;
- account pictures and labels shape a chooser;
- origin provenance needs to stay explicit but coarse;
- and privacy rules limit when visual assets are fetched or revealed.

## Promotion rule
Do not promote `coarse origin cue`, `preview asset`, `chooser label`, or `asset honesty` unless they improve:
- one OIDC client-name / `logo_uri` specimen where displayed metadata remains smaller than redirect, issuer, and approval truth;
- one FedCM specimen where account pictures and custom labels filter or annotate visible accounts without becoming selected-account truth;
- and one credential-chooser specimen where image handling avoids chooser-use leakage while preserving honest history about what the human actually saw.
