# Specimen flow 28 — replay witness, duplicate suppression, and consumption honesty

Goal: let Harbor describe duplicate, refreshed, retried, or late-arriving mediated crossings that must not spend consequence twice and must not pretend a spent handle is magically resumable.

## Scenario
A crossing has already been initiated and is partially or fully in motion.
Examples include:
- a browser authorization turn backed by PAR + PKCE where the user refreshes the browser or repeats a deep-link return;
- a proof-bound token exchange where the same proof or same bound handle arrives again inside the validity window;
- a cross-device handoff where a timebound code or callback arrives late after the first result was already consumed;
- or a local retry after network uncertainty where the caller genuinely does not know whether the first crossing already landed.

During this period, the system may learn one of several very different truths:
- the later arrival is an exact replay of the same canonical crossing and should have no new effect;
- the later arrival carries the same handle but changed bytes, claimant, route, or context and should reject before effect;
- the handle/code/proof has already been consumed and can no longer act as a fresh crossing;
- or the duplicate is late but still useful as historical residue explaining what happened.

Harbor should therefore preserve the difference between:
- exact replay of the same crossing,
- duplicate suppression with no new effect,
- changed-meaning reuse that must be rejected or quarantined,
- and honest spent/consumed aftermath.

## Proposed Harbor objects
1. **replay witness**
   - inspectable residue about whether a later arrival matched an already-known canonical crossing;
   - examples include refreshed PAR `request_uri` use, repeated callback delivery, repeated proof presentation, or retry after transport uncertainty;
   - useful because it explains why the system treated the arrival as same-as-before, suspiciously-different, or too-late-to-spend.

2. **duplicate suppression**
   - explicit no-new-effect outcome for a replay that is equivalent enough to return the prior aftermath honestly;
   - stronger than mere logging because it names what happened, weaker than a portable exactly-once plane because it is still a local verdict about this crossing context.

3. **consumption honesty**
   - visible statement that a code, handle, proof, or narrow crossing chance has already been spent, used, or otherwise cannot act as fresh authority now;
   - includes one-shot or limited-use material whose safe meaning is now historical residue rather than resumable capability.

4. **exact replay only**
   - standing anti-regrowth rule: the same handle may safely replay only the same canonical crossing;
   - if claimant, route, bound proof, or other canonical meaning changed, the honest result is reject-before-effect or quarantine, not mutable resume.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- browser refresh or callback duplication happens for boring operational reasons;
- proof-bound or single-use material arrives again and must not spend consequence twice;
- the safest truthful outcome is “duplicate-suppressed” or “already consumed” instead of generic success or failure;
- and exact replay discipline matters without Harbor becoming a giant job queue, session-resume plane, or exactly-once registry.

## Promotion rule
Do not promote `replay witness`, `duplicate suppression`, or `consumption honesty` unless they improve:
- one PAR/PKCE-style specimen where refresh-triggered duplicate arrivals stay visibly smaller than a fresh crossing;
- one proof-bound/challenge-bound specimen where replay narrows or rejects instead of creating fresh success;
- and one local retry specimen where same-handle changed-context reuse rejects before effect instead of acting like mutable upsert or magical resume.
