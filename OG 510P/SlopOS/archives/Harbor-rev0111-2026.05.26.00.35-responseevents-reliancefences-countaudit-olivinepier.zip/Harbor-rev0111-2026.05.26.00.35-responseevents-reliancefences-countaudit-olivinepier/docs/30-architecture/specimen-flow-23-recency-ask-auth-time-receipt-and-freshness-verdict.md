# Specimen flow 23 — recency ask, auth_time receipt, and freshness verdict

Goal: let Harbor describe recent-authentication pressure without pretending that a fresh token, a returned timestamp, and a currently satisfied recency policy are the same thing.

## Scenario
A protected resource receives an access token and decides the associated user-authentication event is too old for this action.
It returns `insufficient_user_authentication` with a `max_age` challenge.
The client constructs a new authorization request carrying that recentness requirement.
The authorization server may have to actively reauthenticate the user. If the request uses `max_age`, the resulting identity material includes `auth_time`.
Later, the client may still hold a currently issued token or even obtain a renewed token whose authentication context still points back to the same original authentication event.
Harbor should therefore preserve the difference between:
- the ask for a bounded recent authentication event,
- the receipt that says when the active authentication event occurred,
- and the current verdict about whether that event is still recent enough for this crossing.

## Proposed Harbor objects
1. **recency ask**
   - typed demand that the active authentication event be no older than a stated bound;
   - may come from the caller, a relying party, or a protected resource;
   - stronger than generic “please log in again” folklore and weaker than a proved fresh authentication event.

2. **auth_time receipt**
   - returned fact about when the active authentication event occurred;
   - useful because it is exact and can survive transport across the crossing;
   - weaker than “fresh right now” because the clock keeps moving and token renewal may preserve the same event time.

3. **freshness verdict**
   - current judgment that the present crossing meets or misses the recency ask;
   - may be true now and false later even if no other fields change;
   - should stay visibly separate from token issuance, session continuity, and durable account truth.

4. **decay honesty**
   - standing rule that once-fresh auth may age into stale/unknown/miss and should be allowed to say so;
   - important because the right next step is often typed reauth/login interaction rather than counterfeit freshness.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- a resource asks for more recent authentication than the caller currently has;
- `auth_time` is returned and looks stronger than it really is;
- a newly issued or renewed token tempts designers to mistake fresh issuance for fresh human interaction;
- and the right result is not “fresh forever” but “fresh enough for now, until it isn’t”.

## Promotion rule
Do not promote `recency ask`, `auth_time receipt`, `freshness verdict`, or `decay honesty` unless they improve:
- one OIDC specimen where `max_age` or `prompt=login` forces an actively recent authentication event;
- one RFC 9470 specimen where a protected resource challenges for more recent authentication and the client builds a new request instead of guessing;
- and one shell/product specimen where auth-recency chrome can decay to stale/unknown/miss without being mistaken for generic failure.
