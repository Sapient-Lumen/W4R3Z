# Specimen flow 35 — prompt provenance, reviewed summary, and approval honesty

Goal: let Harbor describe where a user-facing review/approval surface lived and what it actually showed without turning browser/authenticator prompts, rendered copy, or simple gesture evidence into portable grant, session, or account truth.

## Scenario
A crossing begins with an exact or semi-exact ask that may need human review.
Examples include:
- an OAuth/OIDC authorization request with structured `authorization_details` or other exact request material;
- a native-app detour that must leave the app and use an external browser or other external user-agent;
- a FedCM turn where the browser mediates the sign-in dialog and permission posture;
- or a WebAuthn ceremony where the prompt is owned by the authenticator or user agent and shows RP/user display fields before the gesture completes.

During this period, several truths can emerge:
- the ask may be structured enough to support a meaningful review summary;
- the human-facing prompt may live in a safer host/browser/authenticator surface rather than in requester-owned chrome;
- an authorization gesture or review turn may really happen;
- and the correct local bottom-out may still be that the available copy was untrusted, incomplete, or otherwise too weak to count as a trustworthy review surface.

Harbor should therefore preserve the difference between:
- “the requester wanted a certain thing,”
- “the review happened on this provenance-bearing surface,”
- “this is what the user was actually shown or bounded by,”
- and “local grant/account/session truth still belongs elsewhere.”

## Proposed Harbor objects
1. **prompt provenance**
   - compact fact about where the human-facing prompt lived: external browser, user-agent mediator, authenticator-owned prompt, or weaker requester-owned/widget-owned chrome;
   - useful because prompt location is a real safety and trust boundary.

2. **reviewed summary**
   - bounded summary of what the user was actually shown for this crossing;
   - stronger than requester prose because it is tied to exact ask/basis, weaker than grant truth because it does not itself spend authority.

3. **review witness**
   - inspectable residue that a host/browser/authenticator-owned review turn really occurred here;
   - useful because it keeps human review visible without pretending that the review itself already settled local adoption.

4. **no-fake-approval honesty**
   - explicit local bottom-out when only requester text, widget chrome, provider marketing copy, or other untrusted/insufficient display material was available;
   - standing anti-regrowth rule: do not let arbitrary displayed text masquerade as trusted approval, durable grant, or adopted account/session truth.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- structured request data and protected request objects make better review possible;
- browser/authenticator-owned prompts are safer than requester-owned surfaces;
- consent, user presence, and user verification are neighboring but non-identical facts;
- and the truthful ending may be “review happened here on this bounded surface” rather than “grant/account/session truth is now portable.”

## Promotion rule
Do not promote `prompt provenance`, `reviewed summary`, or `review witness` unless they improve:
- one RAR/JAR specimen where exact ask/basis survives into review without summary becoming grant truth;
- one RFC 8252 / FedCM specimen where host-owned prompt provenance stays visibly distinct from requester-owned chrome;
- and one WebAuthn specimen where authorization gesture, user presence, and user verification remain visibly smaller than durable local approval or account/session truth.
