# Specimen flow 89 — implementation exceptions and warning lifecycle guards

**Revision:** `rev0094`  
**Followthrough:** `F089`  
**Status:** pressure-test specimen; not a schema, crossing-record runtime, compliance workflow, public status-page product, deadline service, recheck service, rollback protocol, source-owner ticketing system, agent-memory subsystem, or final SlopOS datacube shape.

## Scenario

Specimen 88 produced a locally adopted correction for public aggregate copy `pub-may-a`, a mandated public-US correction deadline, implementation evidence for successor copy `pub-may-b`, a monitoring window, and stale-surface notes. The next week produces six exception pressures:

1. the mandated public correction deadline is missed for one scoped surface because publication evidence arrived late;
2. a recheck fails after an apparently clean monitoring window;
3. a source owner submits contradictory implementation evidence for the same public copy;
4. a rollback or reopen trigger appears because the corrected wording is bad for one audience;
5. a stale generated explanation recurs after a clean window;
6. an active warning must be re-escalated, narrowed, or sunset without claiming compliance or global repair.

## Packet sketch

```text
crossing_record_v0:
  id: cr-089-pub-warning-a
  subject:
    kind: public_copy
    ref: pub-may-b
    digest: sha256:pub-may-b-corrected
    basis_time: 2026-06-02T00:30:00Z
  route:
    from_membrane: external-review-return
    to_membrane: harbor-public-copy
    route_family: public_copy
  admission:
    decision: accepted
    authority_basis: fan-087-public-wording-only + acwi-088-a
    visible_to_user: true
  scope:
    artifact: pub-may-b
    audience: public-us
    jurisdiction: us
    surface: canonical bundle + catalog card + generated explainer
    time_window: 2026-06-01T00:00:00Z/2026-06-08T00:00:00Z
  outcome:
    class: stale_observed
    non_promises:
      - not_global_truth
      - not_compliance
      - not_all_copies_clean
  aftermath:
    receipts:
      - mdr-089-a
      - frr-089-a
      - ssrr-089-a
    recheck_window: 2026-06-08T00:00:00Z/2026-06-15T00:00:00Z
    rollback_or_reopen_triggers:
      - ciep-089-a
      - rort-089-a
```

```text
clock_basis_note:
  id: cbn-089-a
  deadline_source: external_order
  deadline_time: 2026-06-01T00:00:00Z
  rendered_local_time: 2026-05-31T20:00:00-04:00
  publication_time: 2026-06-01T02:15:00Z
  observation_time: 2026-06-01T03:00:00Z
  clock_source: harbor-release-review clock + receipt timestamps
  known_skew_or_uncertainty: none beyond receipt precision
  stay_or_extension: none
```

```text
missed_deadline_receipt:
  id: mdr-089-a
  instruction: mrdn-088-a
  subject: pub-may-b@sha256:pub-may-b-corrected
  missed_scope:
    audience: public-us
    surface: canonical bundle publication
  deadline: 2026-06-01T00:00:00Z
  first_valid_publication_evidence: 2026-06-01T02:15:00Z
  allowed_statement: deadline missed for this publication surface
  refused_statements:
    - noncompliant (refused)
    - bad faith
    - correction invalid everywhere
```

```text
failed_recheck_receipt:
  id: frr-089-a
  prior_clean_window: rmwr-088-a
  recheck_window: 2026-06-08T00:00:00Z/2026-06-15T00:00:00Z
  observed_clean:
    - canonical bundle
    - catalog card
  observed_stale:
    - generated_explainer
  inconclusive:
    - mirror_csv
  failure_class: stale_recurs_after_clean_window
  non_promise: not a global regression finding
```

```text
contradictory_implementation_evidence_packet:
  id: ciep-089-a
  claim_a:
    receipt: ier-088-a
    says: successor pub-may-b preserved label digest lbl-2026-05-a
  claim_b:
    receipt: source-owner-ticket-477
    says: localized summary used lbl-2026-04-old for public-global
  scope_comparison: overlaps-but-not-same-scope
  immediate_effect:
    - keep public-us mandated correction active
    - reopen public-global recommended clarification review
    - do not choose latest evidence by timestamp alone
```

```text
rollback_or_reopen_trigger_note:
  id: rort-089-a
  trigger: contradictory evidence plus audience-specific wording harm
  challenged_effect: recommended global clarification
  stay_posture: public-global recommendation stayed; public-us mandate not stayed
  affected_copies:
    - pub-may-b public-global summary
    - generated_explainer public-global cache
  historical_retention: predecessor and successor copies remain in evidence chain
  memory_hole_refusal: do not delete old correction packets
```

```text
stale_surface_recurrence_receipt:
  id: ssrr-089-a
  prior_clean_observation: generated_explainer clean on 2026-06-06T12:00:00Z
  recurrence_observation: generated_explainer stale on 2026-06-10T09:40:00Z
  stale_text_digest: sha256:stale-summary-old-label
  current_expected_label_digest: lbl-2026-05-a
  suspected_path: cached retrieval chunk regenerated explainer
  agent_memory_invalidation:
    status: requested
    surfaces:
      - retrieval chunk
      - generated explanation cache
      - prompt template snippet
    non_promises:
      - not_training_unlearned
      - not_all_agents_corrected
      - not_global_retrieval_current
```

```text
warning_lifecycle_receipt:
  id: wlr-089-a
  warning: public-warning-085-stale-copy
  decision: reescalate-for-public-global; keep-public-us-narrow-warning; no-global-sunset
  basis:
    - missed_deadline_receipt mdr-089-a
    - failed_recheck_receipt frr-089-a
    - contradictory_implementation_evidence_packet ciep-089-a
  sunset_refused_because:
    - generated_explainer stale recurrence
    - mirror_csv inconclusive
    - public-global recommendation stayed
  allowed_public_copy: corrected canonical copy available; some generated and mirror surfaces may still be stale
  refused_public_copy:
    - resolved (refused)
    - corrected everywhere (refused)
    - compliant (refused)
```

```text
scope_comparison_note:
  id: scn-089-a
  compared:
    - public-us canonical bundle deadline
    - public-global localized summary evidence
    - generated_explainer cache recurrence
  verdicts:
    public-us-vs-public-global: overlaps-but-not-same-scope
    canonical-vs-generated-explainer: incomparable-for-publication-compliance
    stale-recurrence-vs-bad-faith: unsupported
  safe_status: warning remains active only for named stale and inconclusive surfaces
```

```text
hostile_receipt_fixture_set:
  id: hrfs-089-a
  rejected:
    - receipt with pub-may-a digest but pub-may-b subject
    - backdated deadline receipt lacking clock_basis_note
    - clean recheck that omitted generated_explainer from target surfaces
    - status banner saying resolved without warning_lifecycle_receipt
    - tool annotation saying trusted correction without authority_basis
```

## Expected Harbor behavior

- Harbor marks `F089` complete only because the specimen proves that implementation exceptions can be recorded without promoting compliance, universal repair, or public status-page semantics.
- Harbor says `deadline missed for this publication surface`, not `noncompliant`.
- Harbor says `recheck failed for generated explainer recurrence`, not `all stale copies returned`.
- Harbor says `contradictory evidence overlaps but is not same scope`, not `latest evidence wins`.
- Harbor says `recommendation stayed/reopened`, not `mandated correction undone`.
- Harbor says `warning re-escalated or narrowed for named scopes`, not `resolved`.
- Harbor keeps old correction and implementation receipts in the evidence chain; no rollback can memory-hole history.

## Proof obligation pressure

This specimen exercises:

- `PO-IX-001` clock/deadline proof;
- `PO-IX-002` failed-recheck proof;
- `PO-IX-003` contradictory-evidence proof;
- `PO-IX-004` rollback/reopen proof;
- `PO-IX-005` stale recurrence after clean-window proof;
- `PO-IX-006` warning lifecycle proof;
- `PO-XR-001` crossing-record scope proof;
- `PO-XR-002` hostile receipt rejection proof.

## Non-promotion result

No deadline tracker, recheck service, compliance automation, source-owner ticketing system, rollback protocol, warning API, public status-page product, scope algebra engine, agent-memory subsystem, VEX/CSAF profile, in-toto predicate, SCITT dependency, reputation model, enforcement ladder, or final SlopOS datacube shape is promoted.
