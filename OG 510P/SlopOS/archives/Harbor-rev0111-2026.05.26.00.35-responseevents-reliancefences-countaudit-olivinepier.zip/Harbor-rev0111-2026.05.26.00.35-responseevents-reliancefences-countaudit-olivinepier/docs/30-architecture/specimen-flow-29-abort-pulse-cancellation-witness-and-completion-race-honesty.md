# Specimen flow 29 — abort pulse, cancellation witness, and completion-race honesty

Goal: let Harbor describe caller-side aborts, chooser dismissals, and deadline-driven bottoms without turning them into provider refusal, durable account truth, or portable pending/session state.

## Scenario
A crossing has already started and is meaningfully in motion.
Examples include:
- a browser- or chooser-mediated credential retrieval where the caller aborts via `AbortController` because the surrounding UI disappeared;
- a FedCM or chooser flow where the user explicitly closes or dismisses the browser-owned dialog;
- a passkey or WebAuthn ceremony where the local client cancels one in-progress authenticator operation while switching to another path;
- or a request-context/deadline governed crossing where the caller disconnects or a deadline passes before the remote/provider side definitively settles.

During this period, several different truths can emerge:
- the caller or runtime issued a real stop request;
- the user dismissed chooser UI without granting or selecting;
- a deadline expired, making continued waiting dishonest;
- the provider or remote side refused for its own reasons;
- or the stop request raced with completion, so the local side must ignore, quarantine, or historically record a result that arrived after abort.

Harbor should therefore preserve the difference between:
- caller/runtime abort,
- user dismissal,
- deadline bottom-out,
- provider refusal,
- and completion that raced with cancel.

## Proposed Harbor objects
1. **abort pulse**
   - explicit local/browser/runtime signal that an in-flight crossing should stop;
   - examples include `AbortController`, caller disconnect, user-backed cancel affordances, or local lane teardown;
   - useful because it records that the stop originated locally and is not the same thing as remote refusal.

2. **cancellation witness**
   - inspectable residue about which layer pulled the stop signal and what family of stop it was;
   - examples include caller abort, chooser dismissal, transport disconnect, or runtime-issued cancellation;
   - useful because it explains why a crossing bottomed out without silently overreading the stop as remote truth.

3. **deadline floor**
   - typed point where continued waiting is no longer honest for this crossing lane;
   - examples include request timeout, browser/runtime deadline, or an explicit local wait budget expiring;
   - stronger than vague timeout logging because it names an honest end to the current lane, weaker than portable authority because it remains local coordination truth.

4. **completion-race honesty**
   - visible statement that cancel and completion may cross in flight;
   - if a later result arrives after abort, Harbor should preserve that historical fact while still making clear that the original lane already bottomed out;
   - standing anti-regrowth rule: abort is a coordination signal, not universal proof that no later completion exists anywhere.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- the most truthful result is “we stopped locally” rather than “the provider denied”;
- a chooser dismissal should leave real residue without becoming durable identity/session truth;
- deadlines and caller disconnects matter operationally but do not grant authority;
- and completion can race with cancellation, making simplistic “abort means nothing happened” stories unsafe.

## Promotion rule
Do not promote `abort pulse`, `cancellation witness`, or `deadline floor` unless they improve:
- one browser-mediated `AbortSignal` specimen where caller abort remains visibly different from user refusal or provider refusal;
- one chooser/dialog dismissal specimen where browser-owned UI closure leaves honest local residue and, if present, cooldown/backoff posture;
- and one request-context/deadline specimen where timeout or caller disconnect bottoms out honestly without inventing a portable cancel/session plane.
