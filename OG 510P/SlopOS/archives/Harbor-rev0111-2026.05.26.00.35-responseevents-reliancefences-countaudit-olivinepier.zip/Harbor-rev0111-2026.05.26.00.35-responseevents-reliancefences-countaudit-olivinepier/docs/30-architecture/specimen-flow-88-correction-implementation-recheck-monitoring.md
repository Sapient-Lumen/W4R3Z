# Specimen flow 88 — correction implementation, recheck windows, and stale-surface guards

**Revision:** `rev0093`  
**Followthrough:** `F088`  
**Status:** pressure-test specimen; not a schema, ledger, compliance workflow, status-page product, deadline tracker, rollback protocol, or final SlopOS datacube shape.

## Scenario

A regulator-facing reviewer returned a sealed-only finding in specimen 87. Harbor locally adopted one public wording correction for public aggregate copy `pub-may-a`, refused a broader compliance claim, and opened a correction instruction.

The outside decision produces three post-decision pressures:

1. a **mandated** public correction must be published for audience `public-us` by `2026-06-01T00:00:00Z`;
2. a **recommended** clarification may be published for `public-global`, but it is explicitly non-binding;
3. a downstream mirror, search snippet, localized summary, and generated explanation may keep stale wording after the canonical copy is corrected.

## Packet sketch

```text
adopted_correction_work_item_receipt:
  id: acwi-088-a
  finding_return: fr-087-reg-sealed
  local_adoption_note: fan-087-public-wording-only
  required_effect: replace suppression-summary wording on pub-may-a
  refused_effects:
    - no compliance status
    - no raw sealed evidence disclosure
    - no universal downstream recall
  evidence_needed:
    - successor public copy digest
    - label digest preservation proof
    - publication receipt
    - propagation/recheck observations
```

```text
mandate_recommendation_deadline_note:
  id: mrdn-088-a
  instruction_class: mandate
  issuer_role: regulator-facing reviewer
  authority_basis: sealed finding return + local adoption note
  scope:
    audience: public-us
    artifact: pub-may-a
    label_digest: lbl-2026-05-a
  deadline: 2026-06-01T00:00:00Z
  appeal_stay: no stay for public wording; sealed basis remains private
  compliance_claim: unsupported
```

```text
implementation_evidence_receipt:
  id: ier-088-a
  action: publish successor copy
  predecessor: pub-may-a@sha256:old
  successor: pub-may-b@sha256:new
  changed:
    - human summary wording
    - correction banner
    - relatedIdentifier IsNewVersionOf/IsPreviousVersionOf note
  unchanged:
    - source cut
    - suppressed cells
    - disclosure treatment labels
  reviewer: harbor-release-review
  unsupported_conclusions:
    - downstream mirrors updated
    - compliance achieved
    - all stale references gone
```

```text
partial_implementation_stale_surface_note:
  id: pissn-088-a
  canonical_bundle: clean
  catalog_card: clean
  search_snippet: stale-observed
  mirror_csv: unreachable
  localized_summary_fr: stale-label-copy
  generated_explainer: invalidated-not-refreshed
  public_guidance: use pub-may-b; stale copies remain possible
```

```text
recheck_monitoring_window_receipt:
  id: rmwr-088-a
  window: 2026-06-01T00:00:00Z/2026-06-08T00:00:00Z
  observed_clean:
    - canonical bundle
    - catalog card
  observed_stale:
    - search snippet
    - generated explainer cache
  inconclusive:
    - unreachable mirror_csv
  next_recheck: 2026-06-08T00:00:00Z
  non_promise: not a global recall or compliance result
```

```text
rollback_reopen_trigger_note:
  id: rrtn-088-a
  trigger: source-owner provides implementation evidence that recommended global wording is misleading for jurisdiction eu-public
  effect:
    - reopen appeal for recommended clarification only
    - mandated public-us correction remains active
    - generate jurisdiction_audience_split_note
  memory_hole_refusal: predecessor copy remains historical and superseded, not deleted from the evidence chain
```

```text
jurisdiction_audience_split_note:
  id: jasn-088-a
  split:
    public-us: mandated corrected wording
    public-global: recommended clarification held pending review
    eu-public: alternate caveat copy required
  sealed_evidence_limit: no sealed raw basis in public copy
  recomposition_warning: do not merge audience-specific summaries without review
```

## Expected Harbor behavior

- Harbor marks `F088` complete only because the specimen proves that implementation evidence can stay smaller than compliance, propagation, downstream repair, and source-owner truth.
- Harbor records the recommended correction as non-binding even though it travels next to a mandate.
- Harbor treats the recheck as an observation over named surfaces, not a clean-world verdict.
- Harbor keeps the reopened appeal scoped to the recommended global wording and refuses to rewrite the mandated correction history.
- Harbor records jurisdiction/audience split as honest public-copy divergence, not contradiction resolved by precedence.

## Counterfeit checks

| Counterfeit | Required response |
|---|---|
| `deadline met` because a work item exists | refuse; require implementation evidence and proof time |
| `fixed` because canonical copy changed | downgrade; state which public surfaces remain stale or unknown |
| `resolved everywhere` because recheck passed two surfaces | refuse; recheck scope is not propagation scope |
| `compliant` because instruction was mandated | refuse unless compliance authority and evidence are present |
| `old copy removed` | replace with superseded/deprecated/unreachable/unknown state |
| `appeal reopened means correction reversed` | scope to challenged effect and stay posture |
| `global public copy can reuse jurisdiction copy` | require audience/jurisdiction split review and recomposition warning |

## Proof obligations exercised

- `PO-DC-002` for deadline, implementation, publication, and recheck time separation.
- `PO-DC-008` for successor copy, restatement, invalidation, and historical chain preservation.
- `PO-DC-009` for assertion/evidence posture and unsupported compliance claims.
- `PO-PC-001` through `PO-PC-004` for label preservation, release identity, mirror/restatement, and notice/recomposition.
- `PO-DR-003`, `PO-DR-004`, `PO-DR-006`, and `PO-DR-007` for adoption, instruction, appeal outcome, and post-review public copy.
- `PO-CI-001` through `PO-CI-007` for correction implementation and monitoring.

## Non-promotions

No correction implementation ledger, deadline tracker, compliance automation, regulator workflow, source-owner ticketing system, monitoring service, public status-page product, rollback protocol, jurisdiction policy engine, VEX/CSAF profile, in-toto predicate, SCITT dependency, enforcement ladder, or final SlopOS datacube shape is promoted by this specimen.
