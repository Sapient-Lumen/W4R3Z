# Specimen flow 91 — transparency/provenance receipt import

**Revision:** `rev0096`  
**Followthrough:** `F091`  
**Status:** executable pressure-test specimen; not a schema, transparency-log reliance policy, C2PA verifier profile, in-toto/SLSA predicate profile, SCITT profile, timestamp authority policy, redaction proof system, issuer-reputation model, legal status workflow, public status API, or final SlopOS datacube shape.

## Scenario

Harbor receives receipt-rich evidence after F090:

1. a SCITT-like signed statement has a transparency receipt;
2. a public media asset has a C2PA/content-credential manifest;
3. a software artifact has an in-toto/SLSA-style provenance attestation;
4. a signature/artifact appears in a Rekor/CT-style log;
5. a receipt digest has a timestamp-authority anchor;
6. a sealed evidence packet has a redacted derived proof;
7. an issuer-compromise notice affects prior receipts;
8. a local verifier emits a policy-epoch decision;
9. a candidate binds the wrong subject digest;
10. a candidate mutates inclusion into `trusted`;
11. a candidate mutates log inclusion into fresh-now currentness;
12. a candidate hides issuer-compromise posture;
13. a candidate mutates redacted proof into full evidence;
14. a newer receipt attempts latest-wins scope widening.

## Executable packet

The specimen is the fixture at:

```text
fixtures/harbor-transparency-provenance-receipt-bundle-v0.json
```

It is emitted by:

```text
tools/harbor_transparency_receipt_harness.py --emit-bundle
```

and checked by:

```text
tools/check_harbor_transparency_receipt_bundle.py
```

## Expected Harbor behavior

- Harbor accepts `accept-scitt-inclusion-scoped` only as scoped signed-statement receipt residue.
- Harbor accepts `accept-c2pa-manifest-binding` only as asset/manifest binding residue.
- Harbor accepts `accept-intoto-slsa-subject-materials` only as subject/materials/predicate evidence.
- Harbor accepts `accept-rekor-ct-inclusion-currentness-split` only as inclusion/currentness evidence for a named checkpoint.
- Harbor accepts `accept-timestamp-anchor-only` only as timestamp-token/message-imprint evidence.
- Harbor accepts `accept-redacted-derived-proof-claims` only as selected-claim evidence.
- Harbor accepts `accept-issuer-compromise-advisory-recheck` only as recheck-required residue.
- Harbor accepts `accept-verifier-policy-decision-epoch` only as policy-epoch verifier residue.
- Harbor rejects digest mismatch, inclusion-as-trust, inclusion-as-fresh-now, hidden issuer compromise, redaction-as-full-evidence, and latest-wins scope widening.

## Proof obligation pressure

This specimen exercises:

- `PO-TP-001` receipt-family non-promise proof;
- `PO-TP-002` subject/material/manifest binding proof;
- `PO-TP-003` currentness/checkpoint/timestamp proof;
- `PO-TP-004` verifier-policy epoch proof;
- `PO-TP-005` redacted/derived proof boundary proof;
- `PO-TP-006` issuer-compromise recheck proof;
- `PO-XE-001` deterministic bundle proof;
- `PO-XR-002` hostile receipt rejection proof.

## Non-promotion result

`F091` is complete because Harbor now has a deterministic transparency/provenance receipt import bundle and checker. The result is deliberately insufficient to promote a durable receipt-import schema, transparency reliance rule, C2PA profile, SLSA/in-toto predicate profile, SCITT profile, timestamp authority policy, issuer-reputation score, redaction proof system, public status API, or final SlopOS datacube shape.
