# Specimen flow 58 — grain contract card, late-bound evolution lane, and facet-version note

## Scenario
Harbor wants a small datacube for crossing analysis while the archive is still embryonic.

Three nearby consumers ask for “one Harbor table”:
1. a product report wants counts by **crossing turn**;
2. a security review wants counts by **target/resource or verifier**; and
3. a design-history review wants counts by **aftermath repair/restatement**.

A prototype row starts to mix all three:
- one request/admission/detour/outcome tuple;
- one later receiver- or resource-oriented interpretation; and
- one eventual repair, correction, or restatement outcome.

Then the cube evolves:
- a new field such as `receiver_origin`, `trusted_schema_audience`, or `same_device_veto_reason` appears;
- an earlier row needs correction or historical restatement after late context arrives; and
- a downstream consumer asks for a stable contract they can query without learning Harbor’s latest internal storage tricks.

At that point Harbor must preserve six truths at once:
- the base row needs a visible **grain contract card** saying what one row actually represents;
- rollups by target/resource/verifier or by aftermath repair are derived views, not proof that the base row already had those grains;
- a late-arriving correction or retroactive recomputation deserves a **restatement receipt**, not silent mutation folklore;
- a new optional annotation can begin life as a **facet-version note** instead of forcing a core-schema rewrite;
- adding a new field should prefer a **late-bound evolution lane** over destructive reinterpretation of old rows; and
- physical layout, partitioning, or performance tuning must stay smaller than the curated semantic contract.

## Why Harbor needs a new specimen
Without this specimen, Harbor risks either:
1. flattening mixed request/detour/aftermath grains into one counterfeit universal row; or
2. overreacting by freezing a giant metric, dimension, or table-format architecture before Harbor’s own nouns settle.

This specimen keeps the middle path: Harbor can state the row contract, evolve additively, and preserve change history without pretending the warehouse stack is already chosen.

## Suggested Harbor handling
- Preserve a **grain contract card** on every durable curated surface.
- Preserve a **late-bound evolution lane** when new fields or sidecars are added after the initial row contract exists.
- Preserve a **facet-version note** when an optional or experimental annotation should remain smaller than the core contract.
- Preserve a **restatement receipt** when history is recomputed, corrected, or completed after late context arrives.
- Keep base grain, derived semantic views, and physical storage/layout visibly separate.
- Keep curated downstream contracts smaller and stricter than raw ingest/intermediate shapes.

## Anti-regrowth notes
- Do **not** let one convenience report silently decide Harbor’s universal grain.
- Do **not** let partition columns, clustering tricks, or file layout leak into semantic truth.
- Do **not** let a useful optional annotation force immediate promotion into the core row contract.
- Do **not** let historical restatement masquerade as if the old row had always meant the new thing.
- Do **not** let a future semantic layer backfill certainty that Harbor has not yet earned.
