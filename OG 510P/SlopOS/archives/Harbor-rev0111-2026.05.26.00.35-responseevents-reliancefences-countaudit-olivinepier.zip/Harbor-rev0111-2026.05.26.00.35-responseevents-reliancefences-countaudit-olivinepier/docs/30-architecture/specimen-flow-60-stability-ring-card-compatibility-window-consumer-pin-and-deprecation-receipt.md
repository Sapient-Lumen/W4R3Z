# Specimen flow 60 — stability ring card, compatibility window, consumer pin, and deprecation receipt

Goal: let Harbor pressure-test one curated datacube lane that attracts real downstream interest while still refusing to pretend the whole semantic stack is settled.

## Scenario
A Harbor maintainer has one promising curated lane for downstream analysis of crossing residue. The lane is good enough that two consumers want to try it, but the team still expects rapid iteration and has not frozen the warehouse engine, semantic layer, or catalog product.

At the same time:
1. one additive field looks harmless and probably should be allowed;
2. one rename/drop proposal would break at least one consumer; and
3. one historical audit query needs the older published shape to stay interpretable.

## What this proves
Harbor needs to keep these facts separate:
- what maturity ring the lane currently occupies;
- what sort of compatibility promise, if any, the lane currently makes;
- which consumers have pinned themselves to that lane or to a historical reference;
- which generated schema/catalog/semantic artifacts were derived from it;
- and how a published lane is warned, overlapped, and retired.

## Suggested Harbor handling
1. **Stability ring card**
   - Harbor marks the lane as **candidate** rather than quietly calling it stable.
   - The card names the owner, review trigger, and expiry/re-promotion expectation.

2. **Compatibility window**
   - The candidate lane declares a narrow compatibility window such as **latest-only** or **additive/backward during the candidate window**.
   - An additive field or facet can fit inside that promise if the card says so.

3. **Consumer pin note**
   - One consumer is allowed to pin to the candidate lane head for active evaluation.
   - Another consumer is allowed to pin to a frozen historical tag when reproducibility matters more than freshness.

4. **Derived artifact note**
   - A semantic-model file, schema descriptor, or catalog export may be generated from the lane.
   - That artifact must identify the exact Harbor revision and lane/reference it reflects and remain smaller than the canonical review surface.

5. **Deprecation receipt**
   - If Harbor wants a breaking rename/drop, it should either keep the old published lane alive during overlap or create a successor lane/version.
   - The retirement of the older published lane leaves a **deprecation receipt** stating overlap, warnings, successor, and end state.

## Why this specimen matters
Without this specimen, Harbor risks one of two bad patterns:
1. every promising lane looks accidentally permanent; or
2. nothing gets real consumers because the archive has no honest way to say “use this, but know exactly what kind of promise it makes.”

This specimen keeps the middle path: real downstream usage is allowed, but the strength of the promise stays explicit.

## Anti-regrowth notes
- Do **not** let “published” mean everything from first trial to long-term compatibility.
- Do **not** let a candidate lane silently inherit GA-like permanence.
- Do **not** let a generated schema or semantic-model file outrank the review surface that defined the lane.
- Do **not** let a breaking rename/drop ride through under an “evolved” label if the compatibility window did not allow it.
- Do **not** let a historical tag pretend to be the live head.
