# Specimen flow 26 — presence advert, verification turn, and status honesty

Goal: let Harbor describe how browser/provider-local sign-in or account-availability hints can shape a crossing without pretending that a status advert is settled login, account, or session truth.

## Scenario
A user has interacted with an identity provider before.
The browser now carries a small remembered status advert such as:
- FedCM login status `unknown`, `logged-in`, or `logged-out`,
- an OIDC Session Management `changed` / `unchanged` signal,
- or a privacy-preserving “no credentials discovered yet” branch that refuses to cheaply reveal absence.

A new crossing begins.
The local product may attempt a silent or chooser-light turn, the browser may fetch accounts, or an RP may run a `prompt=none` re-check.
Sometimes remembered status and fetched reality agree.
Sometimes they disagree: the browser expected a signed-in account but fetched none, or a status signal says `changed` without yet proving logout.
Harbor should therefore preserve the difference between:
- the status advert,
- the explicit verification turn,
- and the honest mismatch/user-visible floor when remembered status and fetched reality diverge.

## Proposed Harbor objects
1. **presence advert**
   - compact browser/provider-local hint about sign-in or account-availability posture;
   - examples include FedCM `unknown` / `logged-in` / `logged-out` and OIDC-style `changed` / `unchanged` status signals;
   - weaker than durable login/account/session truth because it is only a local advert that still may require checking.

2. **verification turn**
   - explicit re-check lane triggered by status drift, mismatch, or privacy-preserving uncertainty;
   - examples include `prompt=none` reauthentication, account fetch, confirm-login dialog, or fresh chooser/login mediation;
   - stronger than a raw advert and weaker than adopted success.

3. **mismatch prompt**
   - honest user-visible floor when remembered status and fetched reality disagree;
   - useful because a product needs a truthful alternative to counterfeit “still signed in” smoothness or counterfeit “definitely signed out everywhere” collapse;
   - likely next steps are confirm dialog, login dialog, chooser, or stop-with-receipt.

4. **status honesty**
   - standing rule that `unknown`, `changed`, `logged-out`, empty-account fetches, and privacy-preserving no-candidate outcomes stay visibly smaller than durable truth;
   - also means negative discovery should not be leaked more cheaply than the platform allows.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- browser-owned or provider-owned status adverts materially shape the next route;
- a crossing wants smooth continuation but the best truthful answer is still “verify now”;
- mismatch should be shown and handled rather than silently flattened into logout or success;
- and privacy requires the platform to avoid cheaply revealing that no applicable accounts or credentials exist.

## Promotion rule
Do not promote `presence advert`, `verification turn`, `mismatch prompt`, or `status honesty` unless they improve:
- one FedCM login-status specimen where `logged-in` / `logged-out` adverts shape the next turn without becoming portable login truth;
- one OIDC Session Management specimen where `changed` triggers a `prompt=none` verification turn rather than immediate logout folklore;
- and one privacy-preserving discovery specimen where lack of candidates does not become an instant requester-visible negative truth.
