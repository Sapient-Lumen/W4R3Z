# Specimen flow 74 — option-reservation export, derived view, sidecar, frontier, and compiler humility

Purpose: complete followthrough `F074` without inventing a warehouse, RDF stack, stream processor, semantic layer, assertion product, schema registry, sidecar registry, universal row identity, or public datacube API.

This specimen tests whether Harbor can rehearse six candidate datacube artifacts together while keeping each one smaller than source row truth:

1. observation exchange receipt;
2. derived-view receipt;
3. sidecar interpretation note;
4. frontier / watermark witness;
5. assertion compiler receipt;
6. schema transform receipt.

## Scenario
Harbor needs to expose a reviewable `callback-observation-exchange-v0` for a narrow consumer that compares callback attempts by provider family and route class. The base facts already have the grain and semantic-export pressure from earlier specimens, but this pass asks a different question: can the artifacts around the export stay honest?

The candidate export is useful, but every artifact in the chain can counterfeit something stronger than it is:

- observation shape can counterfeit a complete public API;
- derived views can counterfeit source tables;
- sidecars can counterfeit contract strength;
- watermarks/frontiers can counterfeit freshness or completeness;
- compiled assertions can counterfeit the source assertion language;
- schema transforms can counterfeit semantic equivalence.

## Source lane
Base grain: one callback attempt.

| attempt_id | event_time | published_cut | provider_id | route_class | success | duration_ms | observation_policy |
| --- | --- | --- | --- | --- | ---: | ---: | --- |
| `att-101` | `2026-05-13T15:00:05Z` | `pub-18` | `prov-a` | `browser_detour` | 1 | 420 | `public-summary` |
| `att-102` | `2026-05-13T15:02:10Z` | `pub-18` | `prov-a` | `fedcm` | 0 | 880 | `public-summary` |
| `att-103` | `2026-05-13T15:04:11Z` | `pub-18` | `prov-b` | `browser_detour` | 1 | 510 | `public-summary` |
| `att-104` | `2026-05-13T14:58:41Z` | `pub-18` | `prov-b` | `fedcm` | 1 | 630 | `withheld-detail` |

The lane does not export requester account, subject, claims, raw URLs, tokens, device details, or provider-owned identifiers.

## Artifact A — observation exchange receipt

```text
observation_exchange_id: obs-callback-exchange-v0-pub18
source_lane: callback_attempt
source_cut: pub-18
export_tier: public-summary
observation_grain: one callback attempt after redaction policy
component_roles:
  dimensions:
    - event_day
    - provider_family
    - route_class
  measures:
    - callback_attempts
    - callback_successes
    - duration_ms_component
  attributes:
    - published_cut
    - evidence_grade
    - freshness_basis_id
  withheld:
    - account identifiers
    - raw callback URLs
    - subject claims
    - token material
non_promises:
  - not a full diagnostics dump
  - not an RDF/SDMX commitment
  - not a stable public datacube API
  - not row-level authorization or subject truth
```

Counterfeit caught: a consumer asks for per-account callback failures from the observation exchange. Harbor refuses because the export receipt explicitly withheld account identifiers and promised only a public summary tier.

## Artifact B — derived-view receipt

The consumer wants an aggregated convenience view:

```sql
SELECT
  DATE(event_time) AS event_day,
  provider_family,
  route_class,
  COUNT(*) AS callback_attempts,
  SUM(success) AS callback_successes,
  SUM(success) * 1.0 / COUNT(*) AS callback_success_rate,
  APPROX_PERCENTILE(duration_ms, 0.95) AS callback_duration_p95_ms
FROM obs_callback_exchange_pub18
GROUP BY 1, 2, 3
```

Receipt:

```text
derived_view_id: view-callback-provider-route-v2
view_version: 2
owns_data: false
source_artifacts:
  - obs-callback-exchange-v0-pub18
query_digest: sha256:example-view-digest-v2
sql_dialect: review-sql-not-engine-law
semantic_basis:
  - callback_attempts exact at source cut
  - callback_successes exact at source cut
  - callback_success_rate recomputed from components
  - callback_duration_p95_ms approximate and grouping-specific
compatibility_with_v1:
  - additive field: route_class added as grouping dimension
  - breaking-for-consumers-without-route_class: true
invalidates_when:
  - source cut pub-18 restated
  - observation exchange policy changes
  - provider_family mapping changes
  - approximation algorithm changes
  - source cut no longer retained
non_promise:
  - view definition does not preserve source rows
  - SQL text does not prove identical behavior across engines
```

Counterfeit caught: someone treats `view_version: 2` as a durable historical snapshot. Harbor rejects the claim: the view is replayable only if `pub-18`, policy, provider mapping, and approximation semantics are retained.

## Artifact C — statistics and lineage sidecar notes

Statistics sidecar:

| sidecar_id | linked_artifact | schema_version | contents | allowed_use | forbidden_use |
| --- | --- | --- | --- | --- | --- |
| `stats-pub18-a` | `obs-callback-exchange-v0-pub18` | `harbor.stats.note/0` | row count, null counts, NDV estimate for provider_family, min/max duration | planning, review, anomaly triage | public metric promise, exactness upgrade, contract-tier upgrade |

Lineage sidecar:

| sidecar_id | linked_artifact | scope | contents | allowed_use | forbidden_use |
| --- | --- | --- | --- | --- | --- |
| `lineage-pub18-a` | `callback_attempt@pub-18` | source-scoped | source row family and last-updated sequence for three rows; one legacy row absent | restatement debugging | subject identity, join key, proof of data absence |

Counterfeit caught: a dashboard wants to publish the NDV estimate from `stats-pub18-a` as the exact number of provider families. Harbor refuses. The sidecar was informational and approximate; the base public contract did not promise exact NDV.

## Artifact D — frontier / watermark witness

```text
frontier_witness_id: fw-callback-pub18
source_lane: callback_attempt
basis:
  event_time_watermark: 2026-05-13T15:05:00Z
  published_cut_frontier: pub-18 closed at 2026-05-13T15:20:00Z
  export_built_at: 2026-05-13T15:24:00Z
lateness_policy: late facts before watermark may still arrive and require restatement if admitted by source policy
compaction_posture: no row-detail compaction for pub-18 during this specimen
safe_questions:
  - published-cut summary questions over pub-18
unsafe_questions:
  - latest live callback status
  - claim that event_time <= watermark is impossible to restate
  - historical row-debug after compaction unless sidecars/source cuts survive
```

Counterfeit caught: a consumer sees the event-time watermark and asks Harbor to label the answer “complete forever through 15:05Z.” Harbor refuses. The witness says progress, not metaphysical impossibility of late corrections.

## Artifact E — assertion compiler receipt

Source public assertion subset:

```text
assertion_set_id: public-callback-exchange-assertions-v0
assertions:
  - event_day_not_null
  - provider_family_not_null
  - provider_dimension_unique_at_pub18
  - published_cut_age_under_4h_at_export_build
postures:
  event_day_not_null: blocking
  provider_family_not_null: blocking
  provider_dimension_unique_at_pub18: blocking
  published_cut_age_under_4h_at_export_build: warn
```

Compiler receipt:

```text
assertion_compiler_receipt_id: acr-public-callback-v0-to-target-a
source_assertion_set: public-callback-exchange-assertions-v0
compiler_version: harbor-review-compiler/0
execution_target: target-a-quality-checks
compiled_artifact_digest: sha256:example-assertion-target-digest
preserved_semantics:
  - not-null checks on exported columns
  - provider-dimension uniqueness check at pub-18
unsupported_or_downgraded:
  - freshness warning cannot block publication in target-a
  - evidence-grade details return as summary status only
result_return_path: assertion-run-summary + optional observed-value note
recompile_when:
  - assertion_set_id changes
  - source schema changes
  - execution target changes
  - blocking/warn posture changes
```

Counterfeit caught: a target-a green status is proposed as proof that every internal assertion passed. Harbor rejects it: only the public subset compiled, freshness was warning-only, and observed evidence returned as a summary.

## Artifact F — schema transform receipt

A prior export used `provider_kind`; the new export uses `provider_family`.

```text
schema_transform_receipt_id: str-provider-kind-to-family-v1
source_schema: callback-observation-exchange-v0.1
target_schema: callback-observation-exchange-v0.2
mechanical_mapping:
  provider_kind -> provider_family
semantic_delta:
  provider_family groups provider labels into a smaller public taxonomy
  old provider_kind values may be more granular than new family values
compatibility_window:
  aliases accepted for one rehearsal lane only
retired_identifier_posture:
  provider_kind reserved; do not reuse for another meaning
consumer_replay:
  v1 consumer report replayed with mapping shadow diff; one filter changed cardinality
non_equivalence_warning:
  rename plus coarsening is not same meaning
```

Counterfeit caught: a consumer asks Harbor to mark v0.1 and v0.2 as semantically identical because the transform succeeds mechanically. Harbor refuses; the transform coarsened the provider taxonomy and changed one filter's cardinality.

## Proof cuts applied

### PC-ORC-001 — observation export cut
The exchange receipt names source cut, grain, component roles, withheld fields, export tier, and non-promises. It is a bounded export, not a full datacube API.

### PC-ORC-002 — derived view cut
The view receipt says `owns_data: false`, names query digest/dialect/source artifacts, and records invalidation rules. It is metadata over source cuts, not source truth.

### PC-ORC-003 — sidecar optionality cut
Statistics and lineage sidecars have allowed/forbidden uses. They can aid planning/debugging but cannot upgrade exactness, contract tier, identity, or data presence claims.

### PC-ORC-004 — frontier domain cut
The frontier witness distinguishes event-time watermark, published-cut close, export build time, lateness policy, and compaction posture. It does not flatten progress, freshness, and historical exactness into one timestamp.

### PC-ORC-005 — compiler target cut
The compiler receipt names preserved and unsupported semantics. The compiled target artifact is evidence of one execution posture, not the source assertion itself.

### PC-ORC-006 — schema transform cut
The transform receipt records both mechanical mapping and semantic delta. The successful transform does not imply equivalence.

## Proof obligations exercised

| obligation | status in this specimen |
| --- | --- |
| PO-DC-001 grain proof | satisfied for callback attempt observation grain and grouped derived view |
| PO-DC-002 time-axis proof | satisfied for event time, published-cut close, and export build time |
| PO-DC-005 aggregation/fanout proof | partially satisfied for grouped counts/rate; percentile remains approximate and grouping-specific |
| PO-DC-007 exactness proof | satisfied for exact counts; rejected for sidecar NDV and percentile overclaim |
| PO-DC-009 contract/evidence proof | satisfied for the public assertion subset only |
| PO-DC-010 derived-artifact proof | satisfied for the view receipt and observation export receipt |
| PO-DC-011 sidecar optionality proof | satisfied for statistics and lineage notes |
| PO-DC-012 noun-promotion proof | not satisfied for durable schema promotion; keep as option-reservation process vocabulary |

## Adversarial checks

| counterfeit | expected Harbor response |
| --- | --- |
| observation export treated as full public API | reject; receipt exposes only a bounded public-summary tier |
| component role names treated as universal semantic identities | reject; roles are scoped to the exchange receipt |
| derived view treated as base table | reject; `owns_data: false` and source cuts are mandatory |
| SQL view version treated as replayable after source cut deletion | reject; replay requires retained source cuts and compatible semantics |
| stats sidecar value published as exact metric | reject; sidecar is planning/review evidence only |
| row-lineage sidecar used as subject/account join key | reject; source-scoped debug evidence only |
| watermark treated as forever completeness | reject; domain and lateness policy must be named |
| published cut treated as live-head freshness | reject; cut freshness and live status are different axes |
| compiler green status treated as all assertions passed | reject; source assertion subset and target limitations must be shown |
| schema rename treated as same meaning | reject unless semantic delta proof says equivalence, which this specimen does not |

## Verdict
Observation exchange receipts, derived-view receipts, sidecar interpretation notes, frontier/watermark witnesses, assertion compiler receipts, and schema transform receipts are useful **option-reservation cuts**. They help Harbor collect brilliant outside ideas without letting a fashionable artifact become a constitution.

This pass does **not** promote:

- an observation API;
- an RDF/SDMX/JSON/Parquet exchange schema;
- a warehouse, stream processor, lakehouse, query engine, or semantic layer;
- a sidecar registry or row-lineage implementation;
- an assertion DSL or compiler stack;
- a schema registry or transform language;
- durable Harbor datacube cards for any of the six cuts.

Followthrough `F074` is complete. The next pressure should focus on negative evidence and refusal ledgers: how Harbor records absence, blocked export, unsupported compilation, missing sidecar, stale frontier, and consumer-facing refusal without turning refusal residue into another authority plane.
