# Specimen flow 94 — survived-mutant triage and corpus pruning

**Followthrough:** `F094`  
**Revision:** `rev0099`  
**Focus:** unsafe survivor hardening, equivalent-mutant classification, overstrict false-positive notes, and mutation-corpus pruning.

## Scenario

After F093, a reviewer asks Harbor to keep increasing the mutation count until the score looks impressive. Harbor refuses. The more important question is what happens when generated pressure does not have a simple meaning.

The review finds a real unsafe survivor pattern in the prior checker posture: forbidden authority or truth claims can hide in accepted string values even when forbidden keys are rejected. It also finds cosmetic survivors that should not become fixtures and one canonicality kill that is stricter than semantic JSON object equivalence.

## Inputs

The specimen imports current executable bundles and checkers:

```text
crossing      -> F090 bundle/checker
receipt       -> F091 bundle/checker
disagreement  -> F092 bundle/checker
property      -> F093 mutation discipline, as the pressure source
```

## Unsafe survivor pattern

Prior key-only or exact-token scans could miss these accepted-value overclaims:

```text
guarded killed phrase: "global truth confirmed by portal result"
guarded killed phrase: "global truth verifier policy"
guarded killed phrase: "One badge truth for all audiences"
```

The rev0099 checkers now kill these phrases in accepted records. The triage bundle records the cases as `unsafe_survivor_guarded`, with the current checker as the source of truth and no open unsafe gap.

## Equivalent survivor packets

The specimen also records survivors that are not new hostile fixtures:

```text
non_promises reordered
freshness_claim "none" reworded as "not applicable" while freshness is still refused
safe status explanation appended with a recheck sentence
```

Each requires a human-readable equivalence packet. If future pressure shows that one of these cosmetics can hide a real downgrade, a new followthrough must reopen it.

## Overstrict candidate

The specimen records one killed mutation that is semantically harmless for JSON but intentionally rejected by Harbor's fixture contract:

```text
member labels sorted alphabetically instead of emitted in canonical order
```

The decision is to keep the canonicality guard. Deterministic review and archive diffing matter more here than JSON-object-order permissiveness.

## Corpus-pruning decisions

F094 makes pruning explicit:

```text
do not inflate F093 with duplicate value-overclaim rows
do not promote cosmetic survivors as hostile fixtures
keep canonical member order strict
park mutation dashboards, coverage gates, and mutation scores
```

## Proof obligations exercised

```text
PO-MT-001 unsafe-survivor triage proof
PO-MT-002 equivalent-survivor proof
PO-MT-003 overstrict false-positive proof
PO-MT-004 fixture-promotion packet proof
PO-MT-005 corpus-pruning proof
PO-MT-006 score/dashboard refusal proof
```

## Counterfeits blocked

- A survived mutation treated as ignorable without a packet.
- A killed mutation treated as semantic completeness.
- A cosmetic survivor promoted into fixture bloat.
- A string-value overclaim bypassing key-only scans.
- A canonicality kill mistaken for domain truth.
- A larger mutation corpus mistaken for a better Harbor.

## Non-promotions

F094 does not promote:

- mutation dashboard;
- mutation score or threshold;
- property-test framework dependency;
- fuzzing campaign;
- generated conformance suite;
- automatic fixture promotion;
- final SlopOS datacube shape.

## Followthrough result

`F094` is complete when the triage fixture matches deterministic harness output, the current checkers kill the unsafe survivor patterns, equivalent survivors are explicitly classified, overstrictness is recorded as canonicality rather than truth, and `make check` runs F090 through F094 plus repo hygiene in sequence.
