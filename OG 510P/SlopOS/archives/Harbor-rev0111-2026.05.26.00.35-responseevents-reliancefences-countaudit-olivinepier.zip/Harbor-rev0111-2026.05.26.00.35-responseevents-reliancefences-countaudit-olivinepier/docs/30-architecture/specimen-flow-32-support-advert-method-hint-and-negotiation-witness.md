# Specimen flow 32 — support advert, method hint, and negotiation witness

Goal: let Harbor describe advertised support and chooser/transport hints without turning them into current negotiated-path truth or portable capability authority.

## Scenario
A crossing begins with some external or fetched statement about what methods, transports, or UI options might be available.
Examples include:
- an OAuth/OIDC client consulting authorization-server metadata or OpenID Provider discovery metadata that list supported grants, scopes, or request features;
- a browser or RP supplying WebAuthn hints or seeing remembered credential transport hints;
- or a FedCM-capable browser interpreting IdP config flags such as `supports_use_other_account`, shared account/login endpoints, or account-label filtering.

During this period, several truths can emerge:
- an outside party advertises support for some methods or features;
- a local caller, browser, provider, or remembered credential may carry a preference or hint about which method should be tried first;
- the actual live crossing may negotiate or admit only one narrower path;
- and a listed or hinted feature may still bottom out locally as unsupported, unavailable, hidden, degraded, or browser-escalated.

Harbor should therefore preserve the difference between:
- “the outside side says these methods/features exist,”
- “someone here prefers or suggests one of them,”
- “this is the exact path that was actually negotiated and admitted here,”
- and “the advertised/hinted path did not land here now.”

## Proposed Harbor objects
1. **support advert**
   - compact description of an outside party’s claimed supported methods, features, transports, or flags;
   - useful because it keeps “the provider/browser/platform says this is available” smaller than actual usable-now truth.

2. **method hint**
   - chooser-shaping or transport-shaping preference from caller, browser, provider, or remembered credential state;
   - useful because it keeps request-side or environment-side preference visible without pretending it bound the result.

3. **negotiation witness**
   - inspectable residue naming the exact method/path that actually survived negotiation and was admitted here;
   - stronger than adverts or hints because it explains what really happened, weaker than durable consequence because it still does not settle account/session/grant truth by itself.

4. **unsupported-here honesty**
   - explicit local bottom-out when an advertised or hinted feature does not land on a usable path here now;
   - standing anti-regrowth rule: do not overread support adverts, defaults, or hints into guaranteed usable-now capability.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- support lists are partial or defaulted instead of complete catalogs;
- chooser/transport hints improve UX but do not bind the final path;
- the actually negotiated method deserves explanation residue of its own;
- and a crossing must degrade honestly when a listed or hinted option is unsupported here, hidden here, or rejected here now.

## Promotion rule
Do not promote `support advert`, `method hint`, or `negotiation witness` unless they improve:
- one RFC 8414 / OIDC Discovery specimen where support declarations and defaults remain visibly smaller than actual admitted path truth;
- one WebAuthn specimen where hints/transports guide the crossing without binding final method choice;
- and one FedCM specimen where config flags or account labels shape candidate space without becoming portable account/session or reviewed selection truth.
