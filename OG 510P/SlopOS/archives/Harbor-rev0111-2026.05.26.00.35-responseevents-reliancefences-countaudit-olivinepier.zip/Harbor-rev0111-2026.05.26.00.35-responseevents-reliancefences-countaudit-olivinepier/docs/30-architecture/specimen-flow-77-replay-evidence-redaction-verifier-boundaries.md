# Specimen flow 77 — replay evidence redaction and verifier boundaries

This specimen pressure-tests `F077`.

Scenario: a public callback datacube slice has an old frozen aggregate answer. The exact base replay path is partially gone after compaction, but a frozen answer packet and some sealed replay evidence survived. The consumer asks for the answer and proof. The answer is harmless enough to display; the proof payloads are not.

## Inputs
- frozen answer: `answerpack-callback-public-2026-05-13T21:40Z`
- aggregate: callback success count by route family
- sensitive survivor evidence:
  - raw callback attempts with user/session identifiers;
  - policy-suppressed provider detail fields;
  - optional row-lineage sidecar with source row ids;
  - source lock and old policy bundle digest;
  - sealed replay chunk containing old rejected callbacks;
  - restatement receipt for one withdrawn callback key.
- current drift:
  - policy bundle has rotated;
  - source schema has a compatible-looking but unproven field rename;
  - verifier runtime version changed;
  - one auditor ticket expires before review finishes.

A naive system would zip the full proof, redact a few names and call it safe, or let the current policy engine prove the old answer. Harbor refuses.

## Candidate evidence rows

### RA-77-01 — consumer-visible frozen answer, raw evidence hidden
- class: `aggregate_visible_payload_hidden`
- audience: `public_consumer`
- visible: aggregate value, published-cut time, exactness label, frozen-answer label, restatement availability flag
- hidden: raw replay stream, row-lineage sidecar, suppressed provider detail, source-policy internals
- verdict: `exact_frozen_answer_visible`; `raw_replay_payload_refused`
- anti-counterfeit warning: aggregate visibility is not replay-payload visibility

Healthy behavior: Harbor returns the frozen aggregate with labels and says proof payloads are not available to this audience.

### RA-77-02 — redacted verifier packet for auditor
- class: `redacted_verifier_packet`
- audience: `auditor_verifier`
- redaction cut: `derived_proof + digest_only + sealed_payload_reference`
- allowed proof: selected statements about answer digest, source cut, contract epoch, exactness posture, and restatement relation
- disallowed proof: row-level payloads, suppressed fields, raw callback identifiers
- verdict: `redacted_verification_ready`
- anti-counterfeit warning: derived proof validates selected statements, not the entire hidden bundle

Healthy behavior: Harbor gives the auditor a bounded verifier packet and a transcript of what was disclosed.

### RA-77-03 — sealed replay bundle for operator incident review
- class: `sealed_payload_operator_only`
- audience: `operator_incident`
- evidence view: encrypted/local sealed replay payload reference plus manifest digest and incident workflow id
- consumer visibility: none beyond proof summary
- verdict: `sealed_payload_available_not_exportable`
- anti-counterfeit warning: sealed evidence existence is not a public proof and not a consumer entitlement

Healthy behavior: Harbor records that a stronger proof path exists only under operator incident authority.

### RA-77-04 — ticket expiry and revocation
- class: `verifier_ticket_expired`
- ticket: `ticket-audit-callback-2026-05-13-01`
- allowed claim: frozen aggregate answer digest and restatement relation
- expires: before auditor finishes review
- verdict: `reissue_required`; no automatic replay or disclosure extension
- anti-counterfeit warning: a verifier ticket is not durable grant memory

Healthy behavior: Harbor refuses the stale ticket and requires an explicit recheck under current access policy.

### RA-77-05 — source-lock drift
- class: `source_lock_drift`
- old locks: source cut, schema epoch, policy bundle digest, query/runtime digest, assertion compiler target
- current locks: policy bundle rotated; source schema renamed one field; verifier runtime changed
- equivalence proof: absent
- verdict: `old_lock_required_or_refuse_verification`
- anti-counterfeit warning: current source/policy/runtime state cannot silently verify an old answer

Healthy behavior: Harbor either verifies using the old locks or refuses exact verifier language; it may still show the old frozen answer with weaker labels.

### RA-77-06 — de-identification not proven
- class: `masked_but_not_deidentified`
- proposed export: raw row sample with identifiers blanked
- missing proof: quasi-identifier risk review, repeated-query/differencing analysis, disclosure review, suppression thresholds
- verdict: `refuse_public_redacted_rows`
- anti-counterfeit warning: masking is not de-identification and not privacy proof

Healthy behavior: Harbor keeps raw/redacted rows out of consumer proof and opens followthrough for aggregate privacy thresholds.

## Proof obligations exercised

| obligation | status in this specimen |
| --- | --- |
| PO-DC-009 contract/evidence proof | satisfied by separating public contract subset from internal proof payloads |
| PO-DC-010 derived-artifact proof | satisfied by keeping frozen answer, redacted verifier packet, and sealed replay bundle smaller than source truth |
| PO-DC-011 sidecar optionality proof | satisfied by hiding/refusing lineage sidecar payloads for non-authorized audiences |
| PO-RS-001 survivor-set proof | satisfied by listing visible, sealed, redacted, missing, and inaccessible evidence |
| PO-RS-002 answer-mode proof | satisfied by distinguishing exact frozen answer, redacted verification, sealed operator replay, and refusal |
| PO-RS-003 retention-mutation proof | satisfied where source/policy/runtime drift affects verifier language |
| PO-RA-001 audience-bound evidence proof | satisfied by consumer/auditor/operator/source-owner splits |
| PO-RA-002 redaction-cut proof | satisfied by naming summary, digest, derived-proof, sealed-reference, and refusal cuts |
| PO-RA-003 verifier-ticket proof | satisfied by scope, expiry, revocation, nonce/session, and non-recursive fetch notes |
| PO-RA-004 source-lock drift proof | satisfied by old/current lock comparison and refusal without equivalence |

## Adversarial checks

| counterfeit | expected Harbor response |
| --- | --- |
| ship full replay bundle to prove an aggregate | reject; aggregate visibility is not evidence export authority |
| hash hidden payload and call it a consumer explanation | reject; digest-only proves byte identity, not semantic details |
| redaction label treated as de-identification | reject; require risk/governance proof or refuse |
| current policy bundle used to prove old answer | reject unless equivalence to old lock is proven |
| auditor ticket reused after expiry | reject and require reissue/recheck |
| proof-bundle presence treated as verifier policy | reject; verifier policy must be explicit |
| transparency-log inclusion treated as semantic approval | reject; inclusion witnesses bytes/events only |
| sealed operator payload treated as public proof | reject; say stronger proof exists but is not discloseable |
| missing disclosure treated as missing data | reject; refusal is access/policy, not absence |

## Review copy examples

Consumer-visible bounded answer:

> Harbor can return the exact aggregate answer that was published for this historical cut. The raw replay payloads and row-lineage sidecar are not available to your audience. A redacted proof summary is available; an auditor may request a scoped verifier packet if current policy allows.

Auditor-visible verifier packet sketch:

```yaml
verifier_ticket: ticket-audit-callback-2026-05-13-02
requested_claim: callback_public_cube_slice_frozen_answer_digest
audience: auditor_verifier
answer_cut: cut-callback-2026-05-13T21:40Z
answer_packet_digest: sha256:answerpack...
allowed_evidence_view:
  - frozen_answer_digest
  - query_view_digest
  - policy_contract_epoch_digest
  - exactness_and_evidence_grade_labels
  - restatement_receipt_digest
  - selected derived-proof statements
disallowed_payload_classes:
  - raw_callback_rows
  - suppressed_provider_details
  - row_lineage_sidecar_payload
  - sealed_replay_chunks
redaction_cut:
  mode: derived_proof_plus_digest_only
  preserves:
    - answer_digest_integrity
    - source_cut_identity
    - contract_epoch_identity
    - restatement_relation
  breaks:
    - row_level_replay
    - lineage_drilldown
source_locks:
  source_cut_digest: sha256:sourcecut-old...
  policy_bundle_digest: sha256:policy-old...
  runtime_digest: sha256:runtime-old...
  verifier_bundle_digest: sha256:verifier-old...
current_lock_drift:
  policy_bundle: rotated
  runtime: changed
  source_schema: renamed_field_unproven
equivalence_proof: absent
verdict: verify_under_old_locks_or_refuse_exact_verification
expiry: 2026-05-14T01:00:00Z
revocation_check: required
non_recursive_fetch: true
disclosure_transcript_digest: sha256:disclosure...
non_promises:
  - verifier_ticket_is_not_export_authority
  - derived_proof_is_not_full_replay
  - hidden_payload_digest_is_not_public_explanation
  - current_policy_is_not_old_policy_equivalence
```

## Verdict
Replay-evidence access vocabulary is useful as **bounded review residue**. It lets Harbor distinguish answer visibility, evidence disclosure, proof verification, sealed replay, and source-lock drift without choosing SlopOS's proof/replay substrate.

This pass does **not** promote:

- a public answer-pack API;
- a proof-bundle schema;
- a verifier service;
- a selective-disclosure cryptosystem;
- a de-identification standard;
- a transparency log;
- a policy engine;
- a disclosure language;
- an enclave or auditor workflow;
- a replay service;
- or durable Harbor datacube cards for replay-evidence access.

Followthrough `F077` is complete. The next pressure should focus on aggregate disclosure risk: small-cell suppression, differencing attacks, noisy estimates, disclosure budgets, and repeated-query leakage when consumers may see aggregates but not replay payloads.
