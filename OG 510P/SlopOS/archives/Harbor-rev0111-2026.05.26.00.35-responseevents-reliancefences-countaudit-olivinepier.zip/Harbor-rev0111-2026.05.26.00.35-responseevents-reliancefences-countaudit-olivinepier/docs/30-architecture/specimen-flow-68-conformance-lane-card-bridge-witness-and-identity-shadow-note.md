# Specimen flow 68 — conformance-lane card, bridge witness, and identity shadow note

Goal: let Harbor pressure-test one realistic datacube slice where several useful IDs and dimensions look equally “shared” on screen even though they do not yet carry the same conformance strength.

## Scenario
A Harbor maintainer is reviewing two curated lanes:
- `crossing_event_daily`, which counts crossings and groups them by `workspace_id`, `resource_owner_id`, and a local `team_label`;
- `crossing_cost_daily`, which summarizes spend and budgets by `payer_id` plus a Foundry-derived `allocation_group`.

A third lane exists only as a design-phase helper:
- `workspace_payer_bridge`, which maps Harbor `workspace_id` values to Foundry `payer_id` values, but some mappings are many-to-many during migration and some historical mappings changed at a known effective date.

Three consumers ask for one apparently simple slice:
1. **Ops dashboard:** “Show crossings and spend by team.”
2. **Leadership view:** “Show one canonical account dimension across Harbor and Foundry.”
3. **Historical replay:** “Re-run last month’s report using the mapping that was valid then.”

An awkward fourth fact appears during review:
4. The current `canonical_account_id` field is only a convenient derived alias from today’s bridge output. Some historical workspaces later split across two payer groups, and one downstream export has already started treating the alias as if it were permanent truth.

## Pressure
If Harbor publishes one undifferentiated “account dimension” surface, several wrong things can happen:
- two lanes that only share a small conformed subset can be mistaken for one exact shared dimension;
- a many-to-many bridge can be mistaken for proof of one settled canonical account;
- historical replays can drift because the bridge changed and no time-basis was recorded;
- higher-grain executive views can inherit lower-grain attributes that do not truly conform at that rollup level; and
- the convenient `canonical_account_id` can harden into fake ontology.

That turns one cube into a counterfeit-identity machine:
- local keys start masquerading as enterprise keys;
- bridge outputs start masquerading as settled entity truth;
- higher-grain views silently overclaim what attributes really survive rollup; and
- downstream consumers cannot tell whether a join is exact, bridged, or merely convenient.

## Minimal Harbor move
Harbor keeps grain, time-axis posture, and aggregation posture unchanged and adds three smaller review surfaces.

### 1) Conformance-lane card
`crossing_event_daily` and `crossing_cost_daily` each declare:
- `team_label` is **local-only** for now and should not drive cross-lane drill-across;
- `account_tier` plus a smaller shared `region` attribute form a **conformed subset** across the two lanes;
- any executive rollup keyed by month and region may use a **shrunken conformance slice** instead of the richer base dimensions; and
- `canonical_account_id` is not itself proof of full-row conformance.

### 2) Bridge witness
`workspace_payer_bridge` records:
- Harbor `workspace_id` ↔ Foundry `payer_id` mapping posture = **many-to-many during migration**;
- lookup basis = **validity time** with explicit effective/expiration windows;
- unresolved rows and split/merge cases remain possible;
- leadership views may use the bridge for declared report cuts, but historical replay must pin the bridge to the requested time basis;
- the bridge is useful, but weaker than one exact shared dimension.

### 3) Identity shadow note
`canonical_account_id` carries an explicit note:
- derived from the current bridge output;
- safe for selected navigation and top-level grouping cuts;
- unsafe as proof of permanent deduplication or final entity identity;
- historical rows may later map differently if the bridge restates;
- consumers that need exact replay or contractual identity should pin the bridge/cut, not the shadow alone.

## Why this is better than one generic canonical account field
- it keeps **shared subset conformance** separate from **full-row sameness**;
- it keeps **bridge-based alignment** separate from **authoritative identity truth**;
- it keeps **higher-grain shrunken slices** separate from richer base-dimension claims; and
- it leaves room for later stronger conformance without pretending Harbor already solved enterprise identity.

## What stays deliberately open
- whether Harbor later expresses conformance-lane cards through semantic-model metadata, catalog surfaces, or review-only residue;
- whether bridge witnesses later compile into machine checks for multiplicity and time-basis completeness;
- whether `canonical_account_id` ever graduates from identity shadow to stronger shared-dimension status.

The specimen earns one small rule only: **Harbor should not publish a shared dimension claim until it names exactly what conforms, what is bridged, and what is only a convenient shadow.**
