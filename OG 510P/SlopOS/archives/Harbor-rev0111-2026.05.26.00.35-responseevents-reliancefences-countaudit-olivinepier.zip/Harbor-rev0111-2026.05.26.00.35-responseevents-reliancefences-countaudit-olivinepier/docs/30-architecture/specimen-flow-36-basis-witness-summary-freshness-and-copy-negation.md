# Specimen flow 36 — basis witness, summary freshness, and copy negation

Goal: let Harbor describe what exact ask/revision a reviewed surface was based on, whether that summary stayed fresh until approval/adoption time, and when requester-owned copy had to be explicitly ignored.

## Scenario
A crossing begins with an exact or semi-exact ask that is rich enough to summarize:
- an OAuth/OIDC authorization request that carries structured `authorization_details` and is protected in a Request Object;
- a browser- or chooser-mediated sign-in turn where the host/UA owns the prompt;
- a WebAuthn ceremony where the authenticator or user agent displays RP/user fields;
- or a local action proposal whose validity depends on the exact currently reviewed revision/descriptor.

During the crossing, several pressure points appear:
- the original ask may be structured and integrity-protected enough to support a trustworthy reviewed summary;
- the requester may also render its own chrome, marketing copy, or stale cached summary;
- the mutable basis may drift after review but before the user gesture lands or before local adoption happens;
- and the honest bottom-out may be that the only visible copy was requester-owned or stale.

Harbor should therefore preserve the difference between:
- “this was the exact basis the review referred to,”
- “the summary was still fresh when the crossing tried to spend consequence,”
- “the basis drifted and this review no longer counts,”
- and “the requester’s copy never became canonical review truth.”

## Proposed Harbor objects
1. **basis witness**
   - compact tie from the reviewed surface to the exact ask / request object / revision / descriptor / lane it summarized;
   - useful because it prevents free-floating prose from masquerading as canonical basis.

2. **summary freshness**
   - typed truth about whether the rendered summary still matches the live basis at approval or adoption time;
   - useful because a once-good summary can become stale without becoming false history.

3. **stale-basis denial**
   - explicit local bottom-out when a reviewed surface depends on older mutable state and can no longer honestly authorize/adopt the live crossing;
   - standing anti-regrowth rule: no sticky “latest approved thing” semantics.

4. **requester-copy negation**
   - inspectable reminder that requester-owned prose, widget chrome, cached screenshots, or copied summaries did not count as trusted review here;
   - useful because it keeps host/browser/authenticator-owned review visibly distinct from arbitrary rendered copy.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- structured and integrity-protected asks make exact review possible;
- UA/authenticator-owned prompts are stronger than requester-rendered surfaces;
- mutable basis can drift between review and effect;
- and the truthful ending may be “review happened, but on a stale or non-canonical basis” rather than counterfeit approval.

## Promotion rule
Do not promote `basis witness`, `summary freshness`, `stale-basis denial`, or `requester-copy negation` unless they improve:
- one JAR/RAR specimen where exact request basis survives into review without free-floating copy becoming canonical;
- one Credential-Management/FedCM specimen where chooser/user-agent UI stays visibly distinguishable from requester-owned chrome;
- and one stale-mutable-basis specimen (SlopOS-like exact witness gate) where review/approval fails closed once the reviewed basis drifts.
