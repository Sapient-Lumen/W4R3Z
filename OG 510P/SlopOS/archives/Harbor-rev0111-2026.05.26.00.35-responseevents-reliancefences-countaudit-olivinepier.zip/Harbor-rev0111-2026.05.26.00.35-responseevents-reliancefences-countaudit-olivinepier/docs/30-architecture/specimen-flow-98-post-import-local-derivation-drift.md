# Specimen flow 98 — post-import local derivation drift

## Scenario

A consumer has verified and imported a Harbor release artifact. After import, local tools produce annotations, generated summaries, extracted subsets, local indexes, re-exported archives, cached explanations, cross-device synced copies, stale working copies, and local repair patches.

The pressure is that these derivatives look close to the source. They carry familiar filenames, snippets, summaries, search hits, synced paths, or human notes. Harbor must preserve their usefulness while refusing to let them become source identity, source currentness, public-copy state, upstream repair, search truth, compliance, or global downstream-copy knowledge.

## Required packets

- import context packet;
- derivative identity packet;
- transform scope packet;
- label/non-promise carry-forward packet;
- freshness and invalidation packet;
- consumer copy-state packet;
- sync conflict packet;
- stale copy quarantine packet;
- local repair non-promotion packet.

## Expected accepted outcomes

Harbor may admit a local derivative record when it carries target/source digest posture, transform scope, label and non-promise carry-forward, freshness/recheck posture, and local-only consumer state. The admitted statement remains narrow: a consumer has a derivative of one scoped import.

## Expected refusals

Harbor must reject:

- annotation as status rewrite without target digest;
- generated summary as source-equivalent proof;
- subset extraction that loses suppression/exactness labels;
- index timestamp as currentness;
- re-exported name as parent identity;
- stale cache after source revision drift;
- sync success as verification;
- stale consumer copy as current;
- derivative digest as original digest;
- local search hit as truth;
- generated summary as compliance proof;
- annotation author as source authority;
- latest-wins sync conflict as reconciliation;
- generated table without label digest;
- consumer patch as upstream repair.

## Why this matters to SlopOS

SlopOS can show that a portal/callback/import route completed and that bytes were materialized or resumed under a bounded request. Harbor must still record what happens after those bytes enter a consumer's local derivative world. Portal success, callback success, file-library upload, local index build, or cross-device sync must not become derivative currentness or authority.

## Non-promotions

No local derivation receipt API, consumer cache API, sync-state ledger, annotation authority model, local search truth plane, repair attestation profile, or final SlopOS datacube shape is promoted by this specimen.
