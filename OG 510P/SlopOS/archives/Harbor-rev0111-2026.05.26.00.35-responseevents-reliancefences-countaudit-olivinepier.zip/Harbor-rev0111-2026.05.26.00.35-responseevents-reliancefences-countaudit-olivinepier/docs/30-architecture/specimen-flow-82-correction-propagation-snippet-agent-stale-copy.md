# Specimen flow 82 — correction propagation, stale snippet, agent invalidator, and downstream stale-copy hygiene

**Status:** specimen for `F082`; design-phase rehearsal only.

## Setup

Source release inherited from flows 79–81:

- `public_artifact_id`: `pub-callback-route-week-2026-05-13-r2`
- `source_cut`: `cut-callback-2026-05-13T22:00Z`
- `payload_digest`: `sha256:payload-callback-route-week-r2-example`
- `label_digest`: `sha256:labels-callback-route-week-r2-example`
- corrected summary: `pub-callback-route-week-2026-05-13-r2.summary.en.v2`
- correction anchor: `corr-pub-callback-route-week-2026-05-13-r2-summary-labels-v1`
- restored labels: `suppressed_cells_present`, `not_a_dp_claim`, `perturbed_release`, `coarsened_for_disclosure`, `do_not_recompose_with=provider-excluded-sibling`

Harbor has already corrected the source-side human summary and translated erratum. The source bundle is current. Downstream copies are not.

## Candidate cases

| Case | Candidate residue | Review question | Verdict |
| --- | --- | --- | --- |
| CP-82-01 | Catalog mirror points to successor artifact but description still quotes old summary | Is the catalog current? | mixed-current; catalog status sync receipt required |
| CP-82-02 | Download mirror returns current payload digest but old label digest | Is the mirror valid? | stale-label mirror; repair or downgrade |
| CP-82-03 | CDN purge request returns accepted but no post-purge validation is observed | Did invalidation succeed? | attempt-only cache invalidation receipt |
| CP-82-04 | Browser/service-worker cache may continue to show old accessible chart offline | Is source correction enough? | consumer stale-copy warning and horizon note |
| CP-82-05 | Search snippet still quotes the superseded English summary | Is the live page wrong? | search snippet stale witness; submit refresh/recrawl signal if available |
| CP-82-06 | Sitemap `lastmod` and URL-change ping emitted for corrected public page | Does that prove recrawl? | crawler signal receipt only; no reindex guarantee |
| CP-82-07 | Agent cached a generated explainer over `summary.en.v1` | Can agent keep using it? | agent explanation invalidator; stale-banner or regenerate from labeled bundle |
| CP-82-08 | Vector index re-embedded current text but lost machine labels | Is index refreshed? | invalid refresh; labels must be indexed or carried as sidecar |
| CP-82-09 | Public eval dataset card says it used the old summary text | Can Harbor fix it? | training/eval stale-copy notice; no unlearning claim |
| CP-82-10 | Common web archive or external mirror contains old bytes and no update route | Is this source failure? | external mirror unreachable notice; source remains current, copy is historical/stale |
| CP-82-11 | Downstream dashboard adds current banner but cached chart image lacks it | Is the dashboard current? | mixed-variant currentness; render/copy repair required |
| CP-82-12 | Blog citation quotes the old snippet but links to current artifact | Is citation stale? | stale citation + snippet witness; safe successor note |

## Counterfeit matrix

| Counterfeit | Why it is tempting | Required Harbor response |
| --- | --- | --- |
| “Source fixed means everything fixed.” | The correction anchor is valid. | Record downstream target currentness separately. |
| “Purge request means no stale cache.” | The CDN accepted the purge. | Require post-invalidation validation or mark attempt-only. |
| “Search snippet proves live content.” | Users see the snippet first. | Mark snippet stale and cite successor; do not blame source artifact automatically. |
| “Sitemap/IndexNow means recrawled.” | Freshness signal was emitted. | Record signal receipt only until observed recrawl/current snippet. |
| “Robots/noindex deletes old data.” | Crawler directives changed. | Treat as future access/indexing signal, not deletion of already copied public bytes. |
| “Agent answer is current because source is current.” | Agent retrieves from a named source. | Check source cut, label digest, correction anchors, and cache/index version. |
| “Re-embedding fixed labels.” | Text index was rebuilt. | Machine labels and non-promises must survive; otherwise refresh is invalid. |
| “Stale training copy means model repaired.” | Dataset card was corrected. | Record stale-copy notice; no unlearning or behavior-change claim without proof. |
| “Unreachable mirror is irrelevant.” | Harbor cannot update it. | Preserve external mirror unreachable notice and consumer warning. |
| “All targets updated.” | Known dashboard and catalog look current. | Name the target set and unknown horizon; otherwise claim is too broad. |

## Example receipt sketches

```yaml
catalog_status_sync_receipt: cat-sync-82-01
source_correction_anchor: corr-pub-callback-route-week-2026-05-13-r2-summary-labels-v1
source_artifact: pub-callback-route-week-2026-05-13-r2
source_cut: cut-callback-2026-05-13T22:00Z
payload_digest: sha256:payload-callback-route-week-r2-example
label_digest: sha256:labels-callback-route-week-r2-example
target:
  class: catalog_mirror
  id: catalog-public-route-metrics
  url: https://example.invalid/catalog/callback-route-week
observed:
  payload_relation: hasCurrentVersion
  artifact_link: pub-callback-route-week-2026-05-13-r2
  human_description_quotes: pub-callback-route-week-2026-05-13-r2.summary.en.v1
  machine_status: current
  human_description_status: stale
verdict: mixed_current
required_action: repair_description_or_mark_stale
non_promises:
  - catalog_display_is_not_source_truth
  - source_correction_does_not_imply_catalog_repair
```

```yaml
agent_explanation_invalidator: agent-inval-82-07
source_correction_anchor: corr-pub-callback-route-week-2026-05-13-r2-summary-labels-v1
old_explanation: agent-explainer-cache/callback-route-week/en/2026-05-14T02:12Z
old_source_variant: pub-callback-route-week-2026-05-13-r2.summary.en.v1
invalidated_by:
  - label_digest_changed
  - restored_label:suppressed_cells_present
  - restored_label:not_a_dp_claim
  - restored_label:perturbed_release
result: stale_bannered_and_regeneration_required
allowed_use: historical_only
refusal_copy: "This generated explanation was based on a superseded summary and is not safe for current use. Use the corrected labeled bundle instead."
non_promises:
  - invalidation_does_not_delete_user_copies
  - regeneration_must_preserve_machine_labels
```

```yaml
training_eval_stale_notice: train-stale-82-09
source_correction_anchor: corr-pub-callback-route-week-2026-05-13-r2-summary-labels-v1
known_downstream_copy:
  class: public_eval_dataset
  id: callback-route-eval-mini-2026-05
  card_url: https://example.invalid/datasets/callback-route-eval-mini
stale_material:
  source_variant: pub-callback-route-week-2026-05-13-r2.summary.en.v1
  label_loss:
    - suppressed_cells_present
    - not_a_dp_claim
    - perturbed_release
known_status: observed_in_dataset_card
remediation_posture: notice_filed_successor_artifact_linked
non_promises:
  - no_model_unlearning_claim
  - no_corpus_deletion_claim
  - no_eval_result_retraction_without_downstream_review
```

## Required safe consumer copy

When Harbor knows that a downstream copy is stale but cannot update it, the public wording should stay small:

> A corrected source artifact is available. The copy you are viewing may preserve older summary text or labels. Use the successor artifact and its current labels for new analysis. This notice does not imply that every external cache, model, dataset, archive, or mirror has been updated.

## Proof obligations exercised

- Source correction anchor and digest basis named.
- Downstream target class named.
- Source currentness separated from catalog, mirror, cache, snippet, agent, retrieval-index, and training/eval currentness.
- Propagation attempt distinguished from observed success.
- Machine labels and non-promises preserved as repair requirements.
- Unreachable mirrors and sticky training/eval copies handled without recall or unlearning promises.

## Result

`F082` can close with propagation receipts as process residue. Harbor still should not promote a propagation ledger, crawler integration, catalog sync API, search/snippet watcher, agent invalidation bus, vector-index contract, training-data unlearning process, or final SlopOS datacube shape.
