# Specimen flow 67 — aggregation-class card, fanout fence, and rollup note

Goal: let Harbor pressure-test one realistic datacube slice where several useful numbers look equally simple on screen even though they do not share the same rollup rights.

## Scenario
A Harbor maintainer is reviewing a curated lane called `crossing_target_daily` that combines:
- one row per crossing at the base event grain;
- repeated target annotations because one crossing can touch multiple target facets;
- a daily published summary used by dashboards; and
- a high-cardinality question about distinct affected targets.

Three consumers ask three superficially similar but actually different questions:
1. **Operations dashboard:** “How many crossings completed each day?”
2. **Executive dashboard:** “What completion rate did we have each day?”
3. **Coverage review:** “How many distinct targets were affected each day and across the full week?”

An awkward fourth fact appears during review:
4. a convenience join adds repeated target tags and repeated review reasons, multiplying some crossing rows three or four times unless Harbor fences the measure at crossing grain first.

## Pressure
If Harbor publishes one undifferentiated “daily metric” surface, several wrong things can happen:
- an additive crossing count can be multiplied by repeated child rows after a one-to-many join;
- a displayed daily completion rate can get summed across days as if rates were additive;
- a distinct-target count can get rolled up from already-aggregated day totals even though distinct counts do not add up that way; and
- a future pre-aggregation/export may imply stronger exactness than Harbor actually retained.

That turns one cube into a counterfeit number machine:
- simple counts become inflated;
- rates become mathematically meaningless when re-summed;
- unique counts become either too large or deceptively exact; and
- later consumers cannot tell whether a number came from base grain, additive components, or an approximate sidecar.

## Minimal Harbor move
Harbor keeps row meaning, time-axis posture, and evidence-grade posture unchanged and adds three smaller review surfaces.

### 1) Aggregation-class card
`crossing_target_daily` declares:
- `completed_crossings` = **additive** at crossing grain;
- `completion_rate` = **ratio/composite**, computed from `completed_crossings / attempted_crossings`;
- `distinct_targets` = **set/sketch-backed** or exact-distinct depending on lane posture;
- any snapshot-like “targets currently in force” number would be **semi-additive** and must name the forbidden axis explicitly.

### 2) Fanout fence
The lane records:
- base measure grain = one crossing;
- repeated target tags and repeated review reasons can multiply rows after join;
- additive crossing counts must aggregate or deduplicate at crossing grain before joining repeated child collections;
- the fence is anchored by one unique crossing key;
- if the fence is absent, Harbor must not publish the inflated aggregate as if it were the same question.

### 3) Rollup note
Each published number carries an explicit note:
- `completed_crossings` may roll up across declared grouping dimensions;
- `completion_rate` must be recomputed from numerator and denominator at the target grouping, not summed from displayed subgroup rates;
- `distinct_targets` requires either exact base-grain distinct logic or an explicit mergeable sketch sidecar, with exactness posture visible;
- weekly totals may therefore mix exact additive counts with ratio recomputation and set/sketch merge rules rather than one generic `SUM` story.

## Why this is better than one generic metric label
- it keeps **additive counts** separate from **ratios/composites**;
- it keeps **join safety** separate from display convenience;
- it keeps **distinct/set questions** separate from ordinary rollup math; and
- it leaves room for **optional approximate sidecars** without pretending Harbor has already chosen a universal metric engine.

## What stays deliberately open
- whether Harbor later expresses fanout fences through semantic-model metadata, SQL generation, or review-only residue;
- whether distinct/set questions later use exact-only paths, optional sketches, or both;
- whether semi-additive snapshot-like lanes need stronger enforcement once real consumers appear.

The specimen earns one small rule only: **Harbor should not publish a number until it names what kind of aggregation that number can survive.**
