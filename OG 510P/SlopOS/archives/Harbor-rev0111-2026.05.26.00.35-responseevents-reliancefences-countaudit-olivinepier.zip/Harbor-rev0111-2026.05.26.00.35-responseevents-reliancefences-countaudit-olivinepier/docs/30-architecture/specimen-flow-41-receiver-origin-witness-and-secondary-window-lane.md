# Specimen flow 41 — receiver-origin witness, secondary-window lane, and message-origin fence

Goal: let Harbor describe a crossing where a browser-based authorization flow returns through `postMessage` from a popup or iframe, and the local side must decide whether the message belongs to the exact lane and origin it intended.

## Scenario
A Harbor-hosted product starts an OAuth-style authorization flow from a browser surface.
Instead of navigating the primary window to a callback endpoint, the flow uses a secondary window:
- a popup opened from the primary surface, or
- an embedded iframe used for a bounded reauthentication or chooser turn.

During the crossing:
- the authorization request names a response mode that expects browser messaging rather than an HTTP redirect;
- the client expects the finish on one exact lane, such as `window.opener` or `window.parent`;
- the authorization server sends a `postMessage` result back toward the primary window;
- the message may look structurally valid and may even carry a plausible `code`, `state`, or `iss`;
- but the local side only has adoption rights if the message arrived on the **expected browser lane**, targeted the **expected receiver origin**, and came from the **expected sender origin** for the crossing that started here.

Harbor must therefore preserve the difference between:
- “this crossing was supposed to finish on the opener lane / parent lane,”
- “this origin was the allowed receiver for the browser-messaging finish,”
- “this sender origin and message shape matched what the local side expected,”
- and “none of those facts by themselves settle durable issuer, account, session, or adopted consequence truth.”

## Candidate Harbor objects
1. **receiver-origin witness**
   - exact locally expected origin that a browser-messaging finish was allowed to target;
   - useful because same-product chrome or same-tab context can still be too coarse.

2. **secondary-window lane**
   - compact residue for whether the finish was supposed to travel via popup opener, iframe parent, or another strictly named browser lane;
   - useful because a real message on the wrong lane is still foreign here.

3. **message-origin fence**
   - explicit local check that sender origin, receiver origin, lane, and expected format matched before any adoption;
   - useful because a plausible payload is still weaker than a payload that belongs to this exact crossing.

## Why this specimen matters
It pressure-tests whether Harbor can stay honest when:
- browser-based auth finishes via `postMessage` instead of a path-bearing redirect;
- popup and iframe flows share nearby product chrome but differ in allowed lane and leak surface;
- origin checks, issuer checks, and ordinary `state` handling are all necessary but still play different roles;
- and the local side needs a visible quarantine/abort path for foreign, mis-laned, or mis-targeted finishes.

## Promotion rule
Do not promote `receiver-origin witness`, `secondary-window lane`, or `message-origin fence` unless they improve:
- one popup-based specimen where opener-lane return is distinct from any nearby iframe or sibling-window return;
- one iframe-based specimen where parent-lane return is distinct from any popup or top-level route;
- and one specimen where a structurally valid but wrong-origin or wrong-lane result is preserved as inspectable residue rather than silently adopted or erased.
