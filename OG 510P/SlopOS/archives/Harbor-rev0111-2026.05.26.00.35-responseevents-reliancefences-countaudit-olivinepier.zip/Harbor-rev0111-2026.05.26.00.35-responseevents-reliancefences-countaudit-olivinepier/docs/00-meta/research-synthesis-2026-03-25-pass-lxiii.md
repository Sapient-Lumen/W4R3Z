# Research synthesis — pass LXIII

This pass learns the next restraint for a design-phase datacube: **not every consumer-facing surface should carry the same promise. Harbor should steal explicit maturity rings, explicit compatibility windows, immutable version pointers, and explicit deprecation receipts — but only for curated lanes that have actually earned consumers.**

## Outside lessons
1. **Vague “stable enough” folklore is weaker than named stages.**
   Kubernetes feature gates make maturity explicit: alpha can break and disappear, beta is safer but still changeable, and GA carries the strongest permanence expectations. Harbor should steal the behavior, not the product vocabulary: rehearsal, candidate, published, and historical are stronger than one vague “current” lane.

2. **Compatibility should be declared, not implied.**
   Confluent Schema Registry treats compatibility as an explicit policy and distinguishes latest-only checks from transitive checks across all previous versions. Harbor should borrow the idea of a **compatibility window** rather than promising generic stability for every published lane.

3. **Contracts belong on returned shape, not on every raw seam.**
   dbt model contracts define the returned dataset shape, and dbt model versions exist specifically to track changes over time. Harbor should therefore keep contracts and versions on curated published lanes, not on every specimen or raw sidecar.

4. **Version pointers should be immutable once published.**
   OpenTelemetry schemas require a versioned schema URL, put the version in the URL path, and treat published schema files as immutable. Harbor should steal the discipline of an immutable version pointer for any future published lane contract or facet/schema family.

5. **Small modular contracts refactor better than giant universal schemas.**
   Protobuf’s 1-1-1 best practice argues for one top-level entity per file/build target when possible, and Protobuf’s compatibility guidance warns against type changes and other destructive edits. Harbor should therefore keep datacube contracts narrow and modular, and prefer successor lanes or explicit deprecation over silent rewrites.

6. **Deprecation is part of the contract, not an afterthought.**
   Kubernetes deprecation policy sets minimum support windows and requires warnings for deprecated feature gates. Harbor should steal the idea of a **deprecation receipt** and avoid deprecating a stronger published lane in favor of a weaker, less stable successor.

## Harbor consequence
Harbor should add one modest datacube/process seam now:
- **stability ring card** — declares whether a lane is rehearsal, candidate, published, or historical;
- **compatibility window** — declares whether the lane currently promises no compatibility, latest-only compatibility, additive/backward compatibility, or frozen exact history;
- **consumer-pin note** — records whether a downstream consumer depends on one named lane or historical tag;
- **deprecation receipt** — records how an older published lane is warned, overlapped, and retired; and
- **immutable version pointer** — future published contracts or facets should resolve to one immutable family/version reference instead of a moving branch head.

## What Harbor still should not decide yet
- exact version-number syntax;
- exact enforcement mechanism for compatibility checks;
- exact warehouse, catalog, semantic-layer, or registry product;
- whether published-lane versions live as views, marts, semantic models, tags, or some hybrid.

Those are later implementation choices. The lesson to keep now is the **process discipline**: name the maturity ring, say what kind of change is safe, keep published version pointers immutable, and leave a receipt when something is retired.
