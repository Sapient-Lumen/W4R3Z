# Research synthesis — pass LXII

This pass learns a second layer of datacube restraint: **when the cube is still moving, experimental publish lanes should be cheap, explicit, and disposable; generated schemas/catalog exports should remain derived artifacts rather than canonical truth; promotion from experiment to published lane should leave an explicit receipt; and frozen historical references should stay distinguishable from the evolving head contract.**

## Outside lessons
1. **Named references can preserve optionality without creating ontology debt.**
   Iceberg’s branches and tags are named references to snapshots with their own lifecycles. The important Harbor lesson is not “adopt Iceberg”; it is “keep experimental and historical references explicit, named, and lifecycle-aware.” Harbor should steal the idea of a **publish lane card** and **historical tag** without picking a table format yet.

2. **Testing lanes should be isolated and cheap enough to use per change.**
   lakeFS argues for isolated dev/test environments created from branches rather than copied long-lived staging datasets. The Harbor translation is a **branch rehearsal**: one explicit experimental lane for one candidate semantic contract, backfill, or export surface, not one immortal pseudo-production shadow.

3. **Promotion should be explicit and versioned.**
   lakeFS’s branch workflow and Iceberg’s audit-branch / fast-forward pattern both reinforce the same habit: validate elsewhere first, then promote deliberately. Harbor should therefore keep a **promotion merge receipt** whenever a rehearsal lane becomes a published datacube lane.

4. **Historical references and live heads are different contracts.**
   Iceberg’s docs explicitly distinguish branch-head schema use from snapshot/tag schema use. Harbor should learn the semantic lesson: a live lane can evolve, while a frozen historical reference should keep the contract readers expected at the time it was frozen.

5. **Same query shape can hide a reference switch, so reference identity must stay visible.**
   lakeFS catalog exports show that SQL can stay the same while branch or tag identity changes underneath. That is powerful and dangerous. Harbor should borrow the ergonomic ambition while insisting that the active **lane/reference identity** remain visible in any future export or catalog surface.

6. **Generated artifacts should be derived, not canonical.**
   SlopOS’s compiled-artifact posture is the clean repo/process lesson here: reviewable markdown/JSON surfaces stay canonical while generated machine artifacts remain derived outputs. Harbor should apply this to future SQL DDL, semantic-model YAML, and catalog-export files.

7. **Curated contracts still belong later, not everywhere.**
   dbt’s contracts and semantic-model spine remain valuable, but this pass sharpens where they belong: on a published lane after the lane has survived rehearsal, not on every raw seam or speculative export.

## Harbor consequence
Harbor should add one new datacube/process seam now:
- **publish lane card** — the current consumer-facing contract for one curated lane;
- **branch rehearsal** — an isolated test lane for one contract or backfill experiment;
- **promotion merge receipt** — a compact record that a rehearsal lane was adopted;
- **historical tag** — an optional frozen reference for audit/replay; and
- **derived artifact rule** — generated schemas/catalog exports remain smaller than canonical review surfaces.

## What Harbor still should not decide yet
- exact branch/reference implementation;
- exact catalog or semantic-layer product;
- whether historical tags live inside the warehouse stack or inside Harbor’s own release discipline;
- whether published lanes eventually map to views, schemas, marts, semantic models, or some hybrid.

Those are future implementation choices. The lesson to keep now is the **behavioral discipline**: isolate, validate, promote explicitly, and never let generated artifacts outrank reviewed meaning.
