# Research synthesis — 2026-03-25 pass LXXIV

Question: while SlopOS and Harbor are both still in design phase, what is the smallest honest way to let Harbor carry **physical quantities, ratios, counts, and money** without counterfeiting unit sameness, safe conversion, or display equivalence?

## What current sources say
1. **Unit codes should be computational, not merely pretty.**
   UCUM’s current specification says its purpose is unambiguous electronic communication of quantities together with their units, that valid expressions have precisely defined semantics, and that full-conformance programs must compare unit expressions by semantics rather than by literal spelling. Harbor should steal that: a display label like “seconds” or “MB” is weaker than a coded unit with comparison semantics.

2. **Quantity kind and allowed units are contextual facts.**
   FHIR’s Quantity docs say a quantity is “a measured amount,” but the context of use may define what kind of measured quantity it is and therefore what kind of unit can be used, and may require a code from a particular system. Harbor should steal that: a lane should say whether it carries duration, bytes, ratio/utilization, count, money, or another quantity kind instead of assuming the unit string explains everything.

3. **Human-readable unit and computable unit should stay visibly different.**
   FHIR’s MoneyQuantity structure keeps a computable `code`/`system` separate from the human-readable `unit`, and its core Quantity rules require `system` when `code` is present. Harbor should steal that split: canonical coded unit and display/render unit are different surfaces.

4. **Money is not just another physical unit family.**
   The current HL7 MonetaryAmount definition says currencies are the units in which monetary amounts are denominated, but exchange rates between currencies are variable and that is why currency units are not physical units. MoneyQuantity also says that if `system` is present it must be ISO 4217. Harbor should steal that: currency conversion needs its own witness rather than pretending USD→EUR behaves like ms→s.

5. **One measure should name one quantity and one unit.**
   Prometheus’s naming guidance says a metric must refer to a single unit and to a single quantity, should use base units, and should expose ratios rather than percentages. OpenTelemetry’s current metric guidance says units should follow UCUM, utilization metrics should use the unity unit `1`, counts may use curly-brace annotations like `{request}`, and durations should use `s`. Harbor should steal that blunt discipline: single-quantity/single-unit lanes are easier to trust than mixed-unit convenience surfaces.

6. **Currency code maintenance and history are real moving parts.**
   SIX says it is the official ISO 4217 maintenance agency and the authoritative source on currency code designations. Harbor should steal the implication: money lanes need explicit currency-code posture and should leave room for historic-denomination or redenomination history instead of hard-coding timeless assumptions.

## Harbor consequence
Harbor should add one modest datacube/process seam now:
- **measurement-kind card** — compact declaration of whether a lane carries duration, bytes, count, ratio/utilization, money, or another quantity kind;
- **canonical-unit note** — compact note that says which coded unit Harbor is treating as the machine-comparable basis, and whether the lane is already normalized or still source-native;
- **display-unit note** — compact note that says what human-facing rendering unit or symbol is preferred, while staying visibly weaker than the coded machine basis; and
- **currency-rate witness** — compact note for any cross-currency or re-denominated money output, carrying source currency, target currency, rate source, as-of basis, and whether the rendered value is original, converted, or restated.

## What Harbor still should not decide yet
- one universal unit registry product or conversion service;
- one mandatory canonical/base unit for every physical measure regardless of source precision or local meaning;
- one global FX-rate policy, treasury source, rounding regime, or minor-unit enforcement stack;
- one semantic front door that claims all quantities can already be queried through a single mature metric API.

The design-phase lesson is enough for now: **quantity kind, coded unit, display unit, and currency-rate basis are different truths, and Harbor should not flatten them into one scalar with a pretty suffix.**
