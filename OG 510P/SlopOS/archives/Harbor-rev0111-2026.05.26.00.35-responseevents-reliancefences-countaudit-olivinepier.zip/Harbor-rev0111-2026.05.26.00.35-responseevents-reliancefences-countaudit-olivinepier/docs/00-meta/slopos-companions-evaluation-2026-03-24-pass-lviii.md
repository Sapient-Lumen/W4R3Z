# SlopOS / companions evaluation — pass LVIII

This pass re-checks Harbor against SlopOS and the sibling cubes after adding a granted-detail-view / filtered-detail-card / detail-schema-veto specimen, and again chooses one narrow crossing seam over any early family bloom.

## What the current cubes still teach
- **SlopOS** remains the strongest restraint mechanism. Its MCP/RAR import boundary keeps imported `authorization_details`, metadata endpoints, granted-detail responses, and inadequate-details signaling provider-local or request-local rather than portable approval or entitlement truth. That lines up directly with Harbor treating granted or filtered detail views as crossing residue only.
- **SlopOS** also reinforces that shape validation and provider-local grant semantics should not silently become platform law. A schema mismatch or malformed detail object is therefore best read as a typed local veto, not as evidence about durable account, policy, or session truth.
- **Ward** still reinforces visible-veto posture: the token can be in-family and the receiver can still bottom out because the detail object is malformed or incompatible with the expected schema.
- **Helm** still contributes UI humility: a helpful surface may summarize granted details or explain a schema-shaped failure, but the displayed summary is still smaller than durable entitlement or policy truth.
- **Foundry** still teaches aftermath honesty: token-response detail views and RS-filtered detail cards are useful residue without becoming runtime authority.
- **ViewFS** still reminds us that materialized JSON or copied policy-looking objects do not become fresh native truth just because they were imported, cached, or re-rendered.

## Harbor consequence
Harbor should keep this move modest:
- add one specimen around **granted-detail view**, **filtered-detail card**, and **detail-schema veto**;
- keep requested details, granted details, RS-visible filtered details, and malformed-detail refusal visibly separate; and
- leave any future authorization schema registry, entitlement lattice, or portable filtered-detail family outside Harbor for now.

## Still-not-yet decisions
- Whether **granted-detail view** deserves its own Harbor family, or should remain only an annotation on specific token-response aftermath surfaces.
- Whether **filtered-detail card** belongs in Harbor at all, or should remain only a receiver-scoped note attached to specific JWT or introspection specimens.
- Whether **detail-schema veto** belongs in Harbor, or should stay a typed local refusal explanation that never blooms into a portable validation or policy registry.
