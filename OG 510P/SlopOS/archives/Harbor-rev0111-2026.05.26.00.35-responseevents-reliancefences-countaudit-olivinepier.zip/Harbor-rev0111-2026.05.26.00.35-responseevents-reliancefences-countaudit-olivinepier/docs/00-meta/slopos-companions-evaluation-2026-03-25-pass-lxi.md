# SlopOS / companions evaluation — pass LXI

This pass re-checks Harbor against SlopOS and the sibling cubes after stepping back to study datacube construction itself. The answer is not “choose a warehouse style now.” The answer is “steal process discipline first, then grow one narrow semantic seam.”

## What the current cubes still teach
- **SlopOS** remains the strongest process teacher. Its archive lint gates, release-bundle manifest contract, trajectory map, RFC-to-ADR promotion discipline, and external-source lock/review surfaces show how to keep a still-moving design repo rigorous without pretending the architecture is finished.
- **SlopOS** also reinforces a deeper design lesson: the repo treats exact contracts, evidence hooks, and proof surfaces as first-class long before it chases broad convenience abstractions. Harbor should copy that order of operations for datacube work.
- **Schell** still teaches quarantine discipline: speculative ideas should stay visibly smaller than committed product truth, and question/followthrough surfaces should carry the burden of uncertainty instead of prose drift.
- **Foundry** continues to sharpen a data-shaped warning Harbor should not ignore: ranking, arbitration, sampling, and allocation all become dishonest when a system forgets what a visible row/value really stands for. That strongly supports Harbor making grain explicit before it grows a metric or rollup story.
- **Ward** keeps teaching optionality hygiene: new residue classes should remain datacube-side guidance until enough specimens accumulate to prove they are real and distinct.
- **ViewFS** still reminds Harbor that durable identity/binding truth lives elsewhere. A Harbor datacube may describe crossings, retries, repairs, and aftermath, but it should not quietly become the identity ledger for every object it touches.

## Harbor consequence
Harbor should keep this move modest:
- add one specimen around **grain contract card**, **late-bound evolution lane**, and **facet-version note**;
- add one durable process surface for datacube design principles;
- strengthen hygiene so that process guidance stays wired into the briefing surfaces; and
- leave any future warehouse-engine choice, semantic-layer product choice, or universal change-history subsystem outside Harbor for now.

## Still-not-yet decisions
- Whether Harbor will ever need a first-class semantic front door of entities/dimensions/metrics, or whether neighbor-facing receipts are enough.
- Whether restatement/change-history lanes belong inside Harbor at all, or should mostly stay with Foundry/ViewFS-style aftermath and binding surfaces.
- Whether facet-version notes should remain process-level annotations for a long time, or later graduate into a Harbor-owned schema family.
