# SlopOS / companions evaluation — pass XXIV

This pass re-checks Harbor against the uploaded cube ecology and keeps the architecture embryonic.

## What the current cubes still teach
- **SlopOS** keeps selected-handler identity, selected-account identity, login-state export, and account-binding export on the provider/shell side. That means Harbor can safely record hinting and chooser-shaping truth, but not a portable “the selected account is X” artifact.
- **ViewFS** is especially relevant here: indexes, recents, selector rows, request objects, candidate sets, selected outcomes, and minted grants stay visibly separate. Harbor should borrow that exact discipline for chooser hints versus actual reviewed choices.
- **Steward** reinforces that explicit chooser surfaces can return reviewed targets or selectors without turning ambient context into truth. Harbor can steal that humility for auth/account/device choosers.
- **Helm** keeps shell-owned front-door review surfaces honest. That is a good reminder that even a heavily primed chooser is still a chooser.
- **Ward** still teaches the hard rule: strong outside signals remain weaker than durable local appraisal.

## Harbor consequence
Harbor should keep selector nouns provisional.
The right near-term move is small:
- add one specimen around selector hints, chooser priming, mismatch prompts, and selection honesty;
- keep selected account / selected credential / selected handler truth outside Harbor-owned durable vocabulary;
- and keep provider labels or hinting rails visibly smaller than actual reviewed outcomes.

## Still-not-yet decisions
- Whether `provider label rail` is a first-class Harbor noun or merely one case of selector hint.
- Whether `chooser priming` deserves its own card or remains typed annotation on a route/mediation surface.
- Whether mismatch should be one family shared with interaction floors, or stay distinct so hint failure does not blur back into generic login failure.
