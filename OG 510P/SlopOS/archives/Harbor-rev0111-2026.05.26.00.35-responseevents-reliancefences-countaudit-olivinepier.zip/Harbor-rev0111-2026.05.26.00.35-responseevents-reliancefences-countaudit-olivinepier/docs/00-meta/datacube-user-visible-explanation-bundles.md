# Datacube user-visible explanation bundles

Rev0110 should be read as the next membrane after revocation-overlay propagation. F104 established that an overlay can reach public copies, mirrors, summaries, consumer notices, local indexes, warning cards, sealed summaries, stale mirrors, and multi-cube cards without becoming a badge. F105 asks what happens when a person sees that overlay.

A user-visible explanation bundle is not a UI framework. It is a scoped evidence record for the words, labels, reason codes, history links, access/localization posture, and action affordances used to explain a revocation overlay.

## Minimum members

Each explanation record names:

- `overlay.input`: parent F104 bundle digest, parent case reference, surface kind, overlay digest, scope-map digest, and source non-promises.
- `audience.context`: audience, locale, reading posture, sealed/multi-cube context, and whether programmatic status/non-color cues are needed.
- `explanation.copy`: headline, body, caveats, plain-language posture, badge/closure/fault flags, and copy digest.
- `reason.code`: machine-readable code, human-text pairing, problem-detail posture, and reason digest.
- `action.affordance`: inspect/recheck/export affordances and explicit refusal of repair/read/compliance claims.
- `access.localization`: programmatic-label posture, text-not-color-only posture, translation provenance, scope-widening flag, and render digest.
- `history.trace`: parent overlay digest, prior import digest, prior-history visibility, mixed-overlay preservation, and timestamp-currentness refusal.
- `verdict.summary`: accepted/refused class, failure reasons, flags, and non-promises.

## Safe explanation posture

A safe card says enough for a user to understand the scope, source basis, caveats, and next action. It does not pretend to prove that the user understood it, that every downstream copy repaired, that a mirror is fresh, or that a compliance/legal finding exists.

Useful language is operational:

> This public copy has a scoped overlay. See the source digest, affected scope, and preserved history before relying on it.

Unsafe language is badge-shaped or closure-shaped:

> unsafe closure label: resolved without scope or recheck basis

The unsafe example is deliberately marked as unsafe so the proof-bundle phrase scanner does not mistake it for Harbor vocabulary.

## Rejected collapses

F105 rejects explanation candidates that use green/red badges, universal failure banners, closure language without scope, prior-falsehood/negligence claims, color-only indicators, missing scope maps, missing source overlay digests, localization scope widening, summary-as-source equivalence, delivery-as-read/application, global repair buttons, hidden history, sealed detail leakage, timestamp currentness, machine-code-only messages, missing programmatic labels, translation without provenance, mixed-overlay collapse, truth percentages, or legal advice.

## Non-promotions

This pass promotes no public badge workflow, compliance workflow, legal finding, global downstream repair, notification read guarantee, accessibility conformance claim, localization equivalence guarantee, explanation API, or final SlopOS datacube shape.
