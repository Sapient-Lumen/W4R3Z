# Research synthesis — pass LXXXVII, correction propagation and stale downstream copies

**Revision:** `rev0087`  
**Date:** 2026-05-15  
**Question:** After Harbor has a valid source-side correction anchor, how should correction status propagate across catalogs, mirrors, caches, search snippets, generated explainers, agent indexes, and stale training/evaluation copies without pretending Harbor can recall every downstream copy?

## Result

Harbor should treat propagation as **bounded currentness evidence**, not as source truth and not as universal recall.

The next useful seam is a small family of receipts:

- `catalog_status_sync_receipt` for catalog/mirror metadata and version relations;
- `mirror_revalidation_receipt` for observed payload/label/status digest checks;
- `cache_invalidation_receipt` for purge/revalidate attempts and residual TTL/offline/stale-if-error risk;
- `search_snippet_stale_witness` for snippets or answer summaries that quote superseded text;
- `crawler_signal_receipt` for sitemap, recrawl, robots/meta, IndexNow-like, or search-console signals;
- `agent_explanation_invalidator` for cached generated explanations and retrieval answers after label/status changes;
- `retrieval_index_refresh_receipt` for vector/search index rebuilds that remain smaller than semantic proof;
- `training_eval_stale_notice` for downstream datasets, benchmarks, model cards, eval suites, and crawl corpora that absorbed stale labels;
- `external_mirror_unreachable_notice` for copies Harbor can observe but not update.

None of those handles should be promoted yet. They give Harbor a review vocabulary for source-fixed/world-stale gaps.

## External lessons folded in

- DCAT gives Harbor a catalog/distribution vocabulary and a reminder that catalog metadata and dataset resources have life cycles; useful for catalog status sync, but too broad to become Harbor's datacube constitution.
- DataCite relation types and Crossmark status checks reinforce old→new, current→superseded, and current-status-near-the-copy patterns. Harbor should steal relation clarity, not scholarly publishing governance.
- RFC 9111 makes caches a separate semantics layer with cache-control and validation behavior. Harbor should therefore record cache purge/revalidation evidence rather than infer freshness from the source artifact alone.
- Sitemaps and Bing's 2025 AI-search sitemap guidance make `lastmod` a useful crawl-prioritization signal, especially when timestamps reflect actual page changes. Harbor should treat it as a signal, not a reindex guarantee.
- IndexNow offers a simple URL-change notification for added, updated, or deleted URLs. Harbor can steal the shape of an emitted URL-change receipt without choosing the protocol.
- RFC 9309 robots caching says crawlers may cache `robots.txt`, should not use the cached version beyond 24 hours unless unreachable, and that robots is not an access-control mechanism. Harbor should avoid treating crawl directives as deletion or secrecy.
- Google Search's robots meta guidance and outdated-content/removals tools show the difference between indexing/snippet display, cache clearing, and web removal. Harbor should model snippet stale witnesses and refresh requests separately from source truth.
- OpenAI crawler documentation distinguishes search crawlers and training crawlers with independent robots signals. Harbor should therefore keep search-answer freshness and training-use exclusion separate.
- Common Crawl demonstrates why stale downstream copies are sticky: it maintains a large open web archive, adds billions of pages, and publishes errata for issues spanning many releases. Harbor should treat web/archive/training copies as potentially persistent historical artifacts.
- Hugging Face dataset cards show a practical documentation lane for context, responsible use, and metadata around datasets. Harbor can borrow the "card updated with stale-copy notice" habit without assuming downstream repair.
- PROV's generation/revision/invalidation language is useful for identifying invalidated derived entities, but Harbor should not pretend that invalidation of one entity invalidates all copies unless their target set is named.

## SlopOS-specific interpretation

SlopOS is still design-phase, and that matters. It would be a mistake to promote a propagation bus, crawler contract, agent-memory invalidator, or training-data governance layer now. The safer pattern is to reuse SlopOS boundaries already present in the archives:

- cache-topology and imported provenance remain hints/evidence, not authority;
- imported docrefs and digest-only provenance do not grant hidden refresh or reopen authority;
- LLM/tool elicitation and generated text cannot define trusted UI or approval truth;
- provenance attestations are digest-bound evidence, not recursive fetch/query power;
- public/cached copies, annotations, labels, and stale badges remain smaller than canonical metadata.

Harbor should keep a source correction anchor and downstream propagation receipts separate in the same spirit.

## New watchlist handles

- `propagation_target_register`
- `catalog_status_sync_receipt`
- `mirror_revalidation_receipt`
- `cache_invalidation_receipt`
- `search_snippet_stale_witness`
- `crawler_signal_receipt`
- `agent_explanation_invalidator`
- `retrieval_index_refresh_receipt`
- `training_eval_stale_notice`
- `external_mirror_unreachable_notice`
- `propagation_horizon_note`
- `consumer_stale_copy_warning`

These handles are intentionally smaller than durable schema.

## What stayed open

- CDN/cache integration;
- sitemap/IndexNow/search-console workflow;
- public catalog or catalog vocabulary;
- mirror validation service;
- agent memory architecture;
- vector/retrieval index invalidation mechanism;
- crawler/robots policy;
- training-data unlearning or eval governance;
- public status API;
- final SlopOS datacube shape.
