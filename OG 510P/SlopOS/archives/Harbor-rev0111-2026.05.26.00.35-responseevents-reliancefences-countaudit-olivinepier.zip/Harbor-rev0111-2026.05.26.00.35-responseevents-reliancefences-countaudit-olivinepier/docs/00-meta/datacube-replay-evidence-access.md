# Datacube replay-evidence access and verifier boundaries

This surface is a **review aid**, not a schema, product API, cryptographic protocol, disclosure policy, or verifier implementation.

It exists because replay-survivability created a new danger: once Harbor can say an old answer has a survivor set, a consumer may assume they are entitled to the survivor set. That is false. Survivor evidence can contain raw rows, suppressed fields, policy-only facts, secrets, operator notes, lineage sidecars, or old source/runtime locks.

## Stance
- Verification, disclosure, and authority are separate lanes.
- A visible aggregate does not imply visible raw replay payloads.
- A digest of hidden evidence can support integrity checks, but it is not a consumer explanation by itself.
- A redacted proof packet is not exact recompute unless the redaction cut preserves the requested proof obligation.
- A verifier ticket is scoped, expiring, revocable review residue, not a durable grant, approval verdict, or fetch authority.
- Current policy/source/runtime state cannot silently prove an old answer; source-lock drift must be named.

## Review handles

### Evidence audience
A compact label for who may see or use a particular evidence view.

Candidate audience values for specimens:

| audience | may see | must not infer |
| --- | --- | --- |
| `public_consumer` | published aggregate, labels, safe refusals, proof summary | raw rows, suppressed fields, policy internals, replay entitlement |
| `contract_consumer` | aggregate plus contract/freshness/exactness subset promised to that consumer | every internal assertion or sidecar |
| `auditor_verifier` | time-limited verifier packet, derived proofs, selected policy/source locks | general export or operational authority |
| `operator_incident` | sealed replay payloads under incident workflow | consumer disclosure approval |
| `source_owner` | source-native evidence permitted by source policy | downstream consumer promise |
| `no_one_exportable` | only local sealed reference / refusal | public proof or portable replay |

### Redaction cut
A declaration of what was removed, transformed, or disclosed from an evidence packet and which proof obligations remain valid.

Candidate cut modes:

| mode | meaning | counterfeits blocked |
| --- | --- | --- |
| `summary_only` | text verdict and labels only | summary as replay proof |
| `digest_only` | exact hidden artifact digest and size/class | hash as safe explanation |
| `derived_proof` | selected statements proven without full payload | derived proof as all-row access |
| `deidentified_packet` | identifiers/quasi-identifiers transformed under reviewed model | masking as risk-free release |
| `sealed_payload_reference` | evidence exists but is encrypted or local-only | sealed reference as public evidence |
| `refused_by_policy` | proof cannot be disclosed under current policy | refusal as data absence |

### Verifier ticket
A scoped review note saying which party may verify which claim against which evidence basis.

A verifier ticket should name:

- requested claim and answer cut;
- requesting party and audience;
- allowed evidence view and disallowed payload classes;
- verifier material, policy bundle/source/runtime locks, and their digests;
- challenge/nonce or session binding if used;
- expiry, revocation, and recheck behavior;
- whether the ticket allows local verification, mediated verification, or only an operator-produced proof summary;
- non-recursive fetch rule;
- disclosure transcript digest if anything is shown.

### Source/policy lock
A pinned basis for proof. At minimum the review note should say which source cut, schema/contract epoch, policy bundle, assertion/compiler target, runtime/dialect, and sidecar versions were used.

If current locks differ from old locks, Harbor should choose one of these verdicts:

- `old_lock_available`: verify under the old basis;
- `equivalence_proven`: current basis has a reviewed equivalence proof for this claim;
- `summary_only`: old answer can be shown, but not reverified under current basis;
- `refuse_verification`: no safe proof path remains.

### Disclosure transcript
A compact audit trail of what evidence view was presented to whom, under which ticket, with which redaction cut, and which proof obligations were claimed or refused.

Disclosure transcript is process residue. It does not become a public data contract or durable authority by itself.

## Minimum proof obligations before promoting any replay-evidence access noun
- State audience and non-audience.
- State redaction cut and what it preserves or breaks.
- State verifier ticket scope, expiry, and revocation behavior.
- State old/current source-lock posture.
- State non-recursive-fetch and no-approval non-promises.
- State which answer mode remains: exact recompute, exact frozen answer, redacted verification, explanation-only, refused, or restated successor.

## Anti-counterfeit checklist
- A visible aggregate is not raw replay authorization.
- A sealed bundle reference is not public evidence.
- A redacted packet is not automatically de-identified.
- A de-identified packet is not automatically safe against differencing, linkage, or repeated-query attacks.
- A verifier ticket is not a durable access token.
- A proof bundle does not choose verifier policy.
- Transparency inclusion is not semantic approval.
- Current source/policy/runtime locks do not prove an old answer unless equivalence is established.
- Missing disclosure is not missing data.
- Auditor-visible evidence is not consumer-visible evidence.

## Promotion triggers
This vocabulary should remain process residue until repeated specimens show that Harbor needs a durable artifact. Possible triggers:

- two or more consumers require independent verification of old answers without raw-row disclosure;
- SlopOS promotes durable observation/replay proof-bundle formats;
- a real source-lock drift incident causes an old answer to be unverifiable under current policy;
- redacted proof packets become common enough that hand-written review notes are error-prone;
- aggregate-only disclosure leaks enough through small cells or differencing that a separate privacy-budget/suppression seam is needed.

## Explicit non-decisions
This pass does not promote:

- a public answer-pack API;
- a proof-bundle schema;
- a verifier service;
- a selective-disclosure cryptosystem;
- a de-identification standard;
- a policy engine;
- a disclosure language;
- a transparency log;
- an enclave or auditor workflow;
- a replay service;
- or final SlopOS datacube shape.
