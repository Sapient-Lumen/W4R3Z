# Research synthesis — pass XXVI

This pass keeps Harbor narrow and learns one more thing from recent-authentication systems: **a freshness demand, a returned authentication timestamp, and a current decision that the crossing is still fresh enough are three different truths.**

## Outside lessons
1. **OIDC `max_age` is a request for bounded recentness, not proof that the user is fresh right now.**  
   OpenID Connect defines `max_age` as the allowable elapsed time since the last time the end-user was actively authenticated. If that elapsed time is too large, the OP must attempt to actively re-authenticate the user. When `max_age` is used, the returned ID Token must include `auth_time`, and `max_age=0` is equivalent to `prompt=login`.

2. **`auth_time` is a receipt about when authentication happened.**  
   OIDC defines `auth_time` as the time when end-user authentication occurred. It is required when `max_age` is used or specifically requested as an essential claim. Crucially, OIDC also says that if a later ID Token contains `auth_time`, it must represent the time of the original authentication, not merely the time the new token was issued.

3. **RFC 9470 makes recentness challengeable at the resource boundary.**  
   A protected resource can return `insufficient_user_authentication` and include `max_age` and/or `acr_values` in the challenge. The client is supposed to parse those parameters and use them when constructing a new authorization request. That is a beautiful Harbor precedent: recentness pressure can arrive late and still remain typed instead of dissolving into one vague “session expired” blob.

4. **Returned authentication context is stable across token renewals unless a new authentication event happened.**  
   RFC 9470 says `auth_time` and `acr` carried in JWT access tokens or token introspection are established at user-authentication time and will not change on access-token renewals. Harbor should steal that warning directly: a freshly minted token can still be carrying an old authentication event.

5. **Freshness misses should bottom out honestly.**  
   OIDC says `prompt=none` forbids user interaction and must return an error if the user cannot be silently authenticated. Its typed errors (`interaction_required`, `login_required`, `account_selection_required`, `consent_required`) are excellent Harbor precedent for what should happen when a recency demand cannot be met silently.

6. **Steward has the right shell-side instinct: freshness decays unless renewed.**  
   The uploaded Steward cube treats observational truth as something that ages unless the seam says otherwise, and it prefers explicit renewal/ownership over sticky booleans. Harbor should borrow that idea for recency chips, auth clocks, and post-return explanation surfaces.

## Resulting Harbor move
Do not decide yet whether the durable nouns are exactly `recency ask`, `auth_time receipt`, `freshness verdict`, and `decay honesty`, or whether later pressure will compress them into a smaller freshness family.
For now, keep them alive as specimen nouns and demand that they improve:
- one OIDC specimen where `max_age` or `prompt=login` forces an actively recent authentication event;
- one RFC 9470 specimen where the protected resource challenges for more recent authentication and the client constructs a new request;
- and one UI/specimen where a once-fresh authentication clock visibly decays instead of masquerading as timeless “recent login” truth.

## Fresh ideas worth stealing
- **recency ask** — typed demand that active authentication be newer than a bound.
- **auth_time receipt** — exact returned time of the active authentication event.
- **freshness verdict** — current judgment that the present crossing meets or misses the ask.
- **decay honesty** — rule that freshness ages and may become stale/unknown/miss without implying broader failure.
- **fresh token smaller than fresh auth** — a standing anti-regrowth rule.
