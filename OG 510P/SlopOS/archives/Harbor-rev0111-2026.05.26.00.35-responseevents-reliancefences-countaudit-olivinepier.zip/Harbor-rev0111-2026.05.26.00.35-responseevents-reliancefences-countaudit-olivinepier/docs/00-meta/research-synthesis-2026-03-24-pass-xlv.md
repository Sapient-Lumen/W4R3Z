# Research synthesis — pass XLV

This pass keeps Harbor narrow and learns five compatible things at once: **cross-device flows still rely on an unauthenticated gap between the consumption device and the authorization device, human-visible pairing cues matter but remain weaker than durable adoption, same-device use of cross-device protocols is a real hazard rather than a convenience path, CIBA-style delivery modes are safest when the notification stays smaller than the token result, and transaction-bound keys are interesting enough to collect without freezing a new Harbor family today.**

## Outside lessons
1. **The unauthenticated gap is the central wound.**  
   The current cross-device security BCP says the consumption device and authorization device are not directly connected, there is no technical mechanism for them to mutually authenticate each other, and the user is left to judge whether a QR code, user code, or pushed approval belongs to a legitimate context. Harbor should keep cross-device handoff facts visibly smaller than durable account, session, or adoption truth.

2. **Pairing cues are worth preserving, but only as cues.**  
   RFC 8628 says that when `verification_uri_complete` is used, the server should still display the `user_code` and ask the user to verify that it matches the code shown on the device. CIBA goes further and defines `binding_message` as a human-readable interlock shown on both devices. Harbor should preserve this as a **pairing cue**, not as durable proof that the right thing was approved.

3. **Same-device is not “close enough.”**  
   The cross-device security BCP now says cross-device protocols should not be used for same-device scenarios and that servers may block them if they detect the same device is being used. Harbor should keep room for a small **same-device veto** rather than treating same-device fallback as an invisible implementation optimization.

4. **Notification should stay smaller than result.**  
   CIBA says a client registers a single token delivery mode, the OP must only deliver the result through that mode, and the client notification endpoint is for callback stubs such as `auth_req_id` rather than a generic place to spray tokens. The FAPI CIBA profile goes further and forbids push mode, preferring ping or poll so tokens are still retrieved through the token endpoint. Harbor should preserve a small **notification stub** instinct without turning client callbacks into portable token/result truth.

5. **Transaction-bound keys are a brilliant future move.**  
   The DPoP-for-device-flow draft binds the DPoP key from the initial device authorization request to the `device_code`, so only the holder of that key can later redeem the flow. That is a powerful idea to steal later as a continuity/binding aid, but it still looks smaller than durable local adoption truth and should remain inspiration for now.

## Resulting Harbor move
Do not decide yet whether Harbor needs durable nouns such as **device-split witness**, **pairing cue**, or **same-device veto**.
For this revision:
- add one specimen around device authorization and CIBA-style cross-device interlocks;
- preserve the difference between “this crossing depended on a real device split,” “the user saw a shared pairing cue,” “the local side refused or downgraded because the split collapsed into same-device,” and “none of those facts settle durable issuer, account, session, or adopted consequence truth”;
- and collect **continuation-bound key** plus **notification stub** as inspiration only, without promoting a new family today.

## Fresh ideas worth stealing
- **device-split witness** — compact local residue that this crossing genuinely depended on separate consumption and authorization devices.
- **pairing cue** — short human-visible interlock such as a matching code or binding message displayed on both devices.
- **same-device veto** — explicit bottom-out or downgrade when a cross-device route collapses into same-device usage.
- **notification stub** — reminder that a backchannel callback can carry only enough to resume the right retrieval path, not the whole durable result.
- **continuation-bound key** — future-facing idea from DPoP device flow: bind the whole continuation to one key from start to finish.
