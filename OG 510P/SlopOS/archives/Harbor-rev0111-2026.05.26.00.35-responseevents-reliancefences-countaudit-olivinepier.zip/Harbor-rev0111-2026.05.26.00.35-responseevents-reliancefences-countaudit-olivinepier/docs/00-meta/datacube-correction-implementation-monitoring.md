# Datacube correction implementation and monitoring hygiene

**Status:** design-phase review surface for `rev0093`; not an ADR, schema, implementation ledger, deadline tracker, compliance automation, regulator workflow, public status-page product, source-owner ticketing model, rollback protocol, jurisdiction policy engine, VEX/CSAF profile, in-toto predicate, SCITT dependency, or final SlopOS datacube constitution.

## Why this exists

`rev0092` let Harbor receive outside findings and locally adopt only the public-copy effects that passed review. The next pressure is what happens after adoption: someone must implement a correction, meet or miss deadlines, publish successor copies, monitor stale surfaces, reopen appeals when new evidence arrives, and handle jurisdiction/audience splits.

The counterfeit is easy: an adopted finding becomes a correction task; a correction task becomes proof of implementation; one implementation receipt becomes proof of propagation; one clean recheck becomes proof of universal repair; and public `resolved` copy becomes compliance.

Harbor should instead keep correction implementation as bounded process residue.

## Core distinction

| Thing | What it can prove | What it must not prove |
|---|---|---|
| adopted finding | Harbor accepted a scoped effect from outside review | implementation, repair, compliance, source-owner fault |
| correction instruction | a mandate/recommendation/advisory exists for a scoped subject | universal legal duty or automatic fix |
| implementation evidence | a named action happened for named artifacts/cuts | propagation, downstream repair, non-use, root-cause elimination |
| publication receipt | a successor public copy was emitted | old copies vanished or search/mirrors updated |
| partial implementation note | some required surfaces remain stale or unverified | bad faith, harm, non-compliance, or total failure |
| recheck receipt | selected surfaces were observed at a time/window | future cleanliness or unreachable-copy state |
| reopened appeal/rollback note | new evidence changed the review path | memory-hole correction or automatic reversal |
| jurisdiction/audience split | public copy differs by named audience/scope | contradiction resolution or global policy truth |

## Minimal packet family

### 1. Adopted correction work item receipt

Records adoption id, external finding id, local adoption note, affected public artifacts, affected labels/summaries/citations, required safe public change, refused effects, owner class, and evidence needed.

### 2. Mandate/recommendation/deadline scope note

Classifies the instruction as mandate, recommendation, advisory, source-owner proposal, or clarification request. Names issuer, authority basis, deadline or review window, jurisdiction/audience, appeal/stay posture, and compliance-claim limits.

### 3. Implementation evidence receipt

Records exact action, actor role, subject artifacts, old/new digests, source cut, public cut, label digest, tests/assertions, reviewer, timestamp, materials, byproducts, and unsupported conclusions.

### 4. Public-copy publication receipt

Records successor copy, predecessor copy, relation, changed rows/labels/summaries/citations/status banners, unchanged evidence, accessibility/localization variants, and propagation obligations.

### 5. Partial implementation and stale-surface note

Records which surfaces changed, which stayed stale, which were unreachable, which failed label preservation, which remain ambiguous, and what user-facing warnings/refusals apply.

### 6. Recheck/monitoring window receipt

Records monitoring window, target surfaces, observation method, sample/coverage, clean findings, failed findings, inconclusive findings, recheck horizon, and non-promises.

### 7. Reopened appeal or rollback trigger note

Records new evidence, trigger type, challenged implementation, stay/rollback posture, affected copies, historical evidence retention, public copy impact, and next review boundary.

### 8. Jurisdiction/audience split note

Records audience or jurisdiction, allowed copy, required labels, local restriction, alternate wording, sealed-evidence limits, translation/accessibility impacts, and cross-copy recomposition risks.

## Required refusals

Harbor should refuse or downgrade any implementation claim that says:

- `implemented` without artifact/cut/digest/action evidence;
- `deadline met` without deadline scope and proof time;
- `corrected everywhere` without propagation observations;
- `resolved` when recheck scope was partial;
- `compliant` without explicit compliance authority and evidence;
- `old copy removed` when the honest statement is superseded, deprecated, unreachable, or unknown;
- `appeal closed` when new evidence reopened a scoped part;
- `same correction applies globally` when jurisdiction/audience copies differ.

## Specimen pressure summary

Specimen flow 88 exercises five cases:

1. an adopted outside finding requires a mandated correction by a deadline;
2. a related recommended correction remains non-binding;
3. implementation updates the canonical bundle but leaves mirrors, snippets, and generated summaries stale;
4. a recheck observes some clean surfaces and some unresolved stale surfaces;
5. new implementation evidence reopens an appeal and produces jurisdiction-specific public wording.

## Non-goals

No correction implementation ledger, deadline tracker, compliance status automation, status-page product, notification workflow, regulator workflow, source-owner ticketing system, rollback protocol, monitoring service, jurisdiction policy engine, VEX/CSAF profile, in-toto predicate, SCITT dependency, remediation registry, enforcement ladder, or final SlopOS datacube shape is promoted here.


## rev0094 successor pressure

`rev0094` does not replace this surface. It adds the exception layer above it: missed deadlines require a clock-basis note, failed rechecks require a target-surface comparison, contradictory implementation evidence requires scope algebra before winner selection, rollback/reopen triggers must preserve historical receipts, stale recurrence after a clean window must name the agent/cache/mirror path if known, and warning sunset/re-escalation must stay scoped.
