# Datacube foreign-import revocation

Harbor can now import foreign evidence from companion cubes only as locally scoped, authority-quarantined material.  Foreign-import revocation is the next membrane: after Harbor imports a fragment, the companion may withdraw it, supersede it, dispute it, let it expire, or re-scope it.  That later change is real evidence, but it is not a verdict over Harbor's earlier act and it does not automatically repair downstream derivatives.

The revocation packet is an overlay, not a replacement.  It says: this foreign fragment had this prior import context; this companion notice now exists; Harbor observed it at this clock; these local uses are now recheck-required, quarantined, retained as history, or split by scope.  It does not say: the prior import was false, Harbor was negligent, every derivative is repaired, the companion became a trust root, or a public badge can turn green.

## Required separation

A foreign-import revocation/correction packet keeps at least six things apart:

1. **Prior import.** The F102 parent import id, bridge digest, foreign cube id, foreign revision, archive digest, fragment family, native status, parent-manifest posture, and the fact that the old import was already quarantined evidence.
2. **Foreign change notice.** Withdrawal, supersession, dispute, expiry, correction, or re-scope notice, including notice digest, issuer, clock, archive digest posture, parent import id, sealed/public posture, and stale-notice posture.
3. **Local impact analysis.** Which Harbor claims become unsafe, which remain historical residue, and which must be rechecked before any status is changed.
4. **Downstream quarantine.** Which local derivatives, summaries, indexes, cache entries, re-exported archives, warnings, or consumer copies are affected, and which remain unknown.
5. **History residue.** Prior observation remains prior observation unless separately falsified.  A withdrawn, disputed, expired, or superseded foreign fragment changes current usability; it does not erase the fact that Harbor imported a scoped fragment at an earlier time.
6. **Recheck plan.** A notice may trigger recheck.  It cannot itself be the recheck result.

## Allowed outcomes

- `revocation_overlay_admitted`: Harbor records the companion notice as a scoped overlay and requires local recheck before current status changes.
- `historical_residue_only`: the prior import remains usable only as past evidence and is not current evidence for derivative repair or public status.
- `quarantine_downstream_derivatives`: affected derivatives are marked recheck-required or stale-risk until independently verified.
- `scope_split_required`: the foreign notice applies to part of the imported scope, or to a foreign scope not comparable to Harbor's local scope.
- `sealed_notice_limited`: Harbor can retain a sealed notice by digest and public summary limits, but cannot publish it as truth.
- `refused_counterfeit_revocation_import`: Harbor rejects an attempted shortcut from foreign notice to local truth, repair, authority, or public badge.

## Counterfeits to reject

- Revocation means the prior Harbor import was false.
- Withdrawal means all downstream derivatives are repaired.
- Supersession lifts quarantine and makes the new foreign fragment trusted.
- A foreign dispute means the older fragment was false.
- Expiry means material was erased, repaired, or no longer consequential.
- Re-scope widens Harbor's scope.
- Companion revision number or notice timestamp proves freshness.
- Missing change digest or missing parent import id can be accepted.
- Companion notice becomes Harbor authority or compliance failure.
- Multiple notices are decided by majority vote.
- Sealed withdrawal notice is public truth.
- Rollback happens without local recheck.
- Consumer acknowledgement of revocation is repair.

## Audit/refactor note

Rev0108 also adds an executable-surface registry audit.  That refactor is maintenance scaffolding: it reduces duplicated checker lists and verifies the F090-F103 files are wired.  It is not a conformance registry, trust root, CI status API, promotion gate, or certification badge.
