# Research synthesis — 2026-03-25 pass LXXII

Question: while SlopOS and Harbor are both still in design phase, what is the smallest honest way to let Harbor publish approximate or sketch-backed datacube values **without** counterfeiting exactness or forcing an early metric/sketch stack choice?

## What current sources say
1. **Approximate aggregate functions are explicitly weaker than exact aggregation.**
   BigQuery’s current docs say approximate aggregate functions are scalable in memory usage and time, but produce approximate rather than exact results and introduce statistical uncertainty. The same page also says the built-in approximate functions operate directly on input data and do not let users specify precision through sketches. Harbor should steal the bluntness: approximate is a first-class exactness class, not an implementation detail.

2. **Materialized sketches are a different promise from one-shot approximate functions.**
   BigQuery’s HLL++ docs say HLL sketches are compact summaries of an aggregation, and that sketch functions support partial aggregations, re-aggregations, and custom precision in ways that `APPROX_COUNT_DISTINCT` does not. Harbor should steal that distinction: an estimate backed by a preserved mergeable sketch is different from a system-defined one-shot estimate with no retained sketch artifact.

3. **Mergeable summaries make some hard questions additive-like, but not exact.**
   The DataSketches research overview says mergeable summaries let independent streams be summarized separately and then combined, and explicitly notes that this lets non-additive questions such as unique-count queries be treated *as though* they are additive through sketch merge. Harbor should steal the humility in the phrase “as though”: sketch merge gives re-aggregation power without erasing the difference between estimate and exact count.

4. **Useful sketches trade size for accuracy and carry explicit error posture.**
   The DataSketches PDF says sketches are streamable, approximate with predictable error, sublinear in size, and mergeable. It also says sketch size can be configured as a tradeoff with accuracy. Harbor should steal that as process pressure: if a published lane depends on a sketch, the lane should say whether precision is system-defined, tunable, or unknown instead of hiding the tradeoff.

5. **Error bounds and confidence belong beside the estimate.**
   DataSketches’ HLL docs show concrete relative-standard-error and confidence-band language, while the frequent-items docs show estimate ranges with lower and upper bounds plus pre- and post-error. Harbor should steal that habit even if it does not yet choose one sketch family: point estimates and error-band posture should travel together whenever possible.

6. **Approximate aggregates are already common enough that Harbor should plan for them, not ban them.**
   DuckDB currently exposes `approx_count_distinct` with HyperLogLog, `approx_quantile` with T-Digest, `approx_top_k` with Filtered Space-Saving, and `reservoir_quantile` with sampling. Harbor should read that as ecosystem pressure, not product endorsement: approximate answers are a normal part of modern analytics, so the cube needs honest exactness semantics even before it chooses an engine.

## Harbor consequence
Harbor should add one modest datacube/process seam now:
- **exactness-class card** — compact declaration of whether a published value is exact, exact-from-components, sketch-estimate, or sample/proxy estimate;
- **sketch witness** — compact note that says whether the lane keeps a mergeable sketch, only a derived estimate, and what precision/merge posture is known; and
- **error-band note** — compact note that says whether the estimate has relative/absolute/rank-based bounds, what confidence basis is known, and whether only a point estimate survives.

## What Harbor still should not decide yet
- exact sketch library or warehouse-native sketch type;
- exact canonical error language or universal statistical DSL;
- exact policy for when every estimate-backed lane is publishable or promotable;
- exact choice between retaining raw rows, retained sketches, or both for every estimate-backed lane.

The design-phase lesson is enough for now: **keep estimate class visible, keep sketch lineage explicit, and never let an approximate scalar impersonate exact durable truth.**
