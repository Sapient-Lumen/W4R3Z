# Research synthesis — pass LXVIII

This pass asks a smaller question than “what is Harbor’s final observability stack?”

It asks: **while the datacube is still embryonic, how do we stop “published”, “fresh”, and “exactly reviewed” from collapsing into one fake trust state?**

## What the outside material teaches
1. **A data contract can bundle several promise families without making them the same thing.**
   OpenMetadata’s contract guide explicitly separates schema, semantics, security, quality/assertions, SLA, terms of use, and status. Harbor should steal the split: a lane’s returned shape or semantic promise is not the same thing as today’s live evidence posture.

2. **A contract’s public promise can be only a selected subset of checks.**
   DataHub describes a data contract as a bundle of verifiable assertions on a physical asset and notes that a contract may promote only the subset of assertions you want publicly promised. Harbor should steal the discipline: “published” and “currently verified by these exact observations” are related, but they are not the same sentence.

3. **Freshness is a named calculation, not an ambient vibe.**
   dbt’s freshness docs make `warn_after` and `error_after` explicit, and also state that if neither threshold is provided then dbt will not calculate freshness. Harbor should steal that humility: no calculation basis should remain visibly different from a passing freshness check.

4. **Observed evidence can be thinner than the headline result.**
   Great Expectations’ result-format docs show that validation payloads may include fields such as `observed_value`, `missing_count`, `unexpected_percent_nonmissing`, and others, but the returned detail depends on the selected result format. Harbor should steal the lesson that a summary badge and a richly evidenced reading are different strengths of trust.

5. **Moving heads and exact reviewed artifacts are different roles.**
   SlopOS’s external-source head register keeps a reviewer-facing discovery head separate from the exact reviewed artifact identity. Harbor should borrow the same behavior for datacube lanes: a moving live head and an exact snapshot/tag are different evidence postures even when both are useful.

## Harbor consequence
Harbor should add one modest datacube/process seam now:
- **evidence-grade card** — compact declaration of whether the current trust reading is snapshot-pinned, head-fresh, head-stale, partial/summary-only, or unknown/unobserved;
- **head-trust note** — compact note saying whether the reading came from a moving head or an explicit snapshot/tag and whether the exact evidence handle was preserved; and
- **freshness witness** — compact note carrying observation time, measured age, threshold window, and the basis used to compute freshness.

## What Harbor still should not decide yet
- exact monitoring/observability product;
- exact snapshot registry or immutable evidence-store design;
- exact machine schema shared across every sibling cube;
- exact universal ordering of evidence grades across every consumer and every lane.

The design-phase lesson is enough for now: **currentness, exactness, and evidence detail are different truths, and Harbor should say which one it has instead of letting one green state impersonate all three.**
