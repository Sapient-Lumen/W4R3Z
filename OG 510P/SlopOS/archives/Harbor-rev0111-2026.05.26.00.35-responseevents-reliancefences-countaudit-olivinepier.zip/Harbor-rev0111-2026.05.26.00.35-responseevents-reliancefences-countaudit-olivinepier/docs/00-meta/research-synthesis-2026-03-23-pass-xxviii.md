# Research synthesis — pass XXVIII

This pass keeps Harbor narrow and learns one more thing from modern auth and event systems: **correlation handles should help local matching without turning into portable subject, session, or account truth.**

## Outside lessons
1. **OIDC `sid` is deliberately scoped and opaque.**  
   Front-channel and back-channel logout define `sid` as an optional session identifier whose contents are opaque to the RP and only need to be unique within a particular issuer. That is a very strong Harbor pattern: a handle can be useful for matching without becoming universal session truth.

2. **Native SSO keeps `sid` as a validity check, not a portable session object.**  
   The current OpenID Connect Native SSO draft requires the authorization server to verify that the `sid` in the `id_token` is still valid and to return `invalid_grant` if it is not. Harbor should steal the humility: a same-AS correlation handle can gate one exchange without becoming a general session export plane.

3. **RFC 9493 formalizes identifier formats but refuses to define the whole subject for you.**  
   Subject Identifiers are structured JSON objects with named formats, but the RFC is explicit that identifier formats do not define the type or nature of the subject itself. They remove ambiguity around parsing and identifier shape, not around final subject resolution.

4. **RFC 9493 also warns that pairing identifiers increases correlation power.**  
   Presenting multiple identifiers together may reveal more than intended, and transmitters are told to do that only when the receiver already knows the relationship or correlation is essential. Harbor should keep correlation thrift visible.

5. **SSF keeps subject structure typed while still talking about exactly one principal.**  
   SSF 1.0 says each Subject Member refers to exactly one Subject Principal, and a Complex Subject as a whole must refer to exactly one Subject Principal. That means Harbor can preserve matching aids while still resisting a giant subject-braid object.

6. **FedCM and WebAuthn both distinguish useful match keys from display identity.**  
   FedCM’s disconnect flow carries an `account_hint` and returns an `account_id`, while WebAuthn says a user handle is an opaque RP-chosen identifier that must not contain PII and that the credential ID is authenticator-chosen and unique per credential. Those are excellent Harbor precedents for “matchable, scoped, non-display, smaller than identity truth.”

## Resulting Harbor move
Do not decide yet whether the durable nouns are exactly `correlation handle`, `match witness`, `mismatch quarantine`, and `scope honesty`, or whether later pressure compresses some of them behind a smaller match-family.
For now, keep them alive as specimen nouns and demand that they improve:
- one OIDC logout / native-SSO specimen where `sid` matches a local continuity lane only within issuer scope;
- one SSF / SET specimen where `sub_id` is parsed cleanly but still requires local resolution and may remain partially unmatched;
- one FedCM or WebAuthn specimen where `account_id`, `account_hint`, `userHandle`, or `credential ID` is useful for local matching without becoming display identity or portable account/session truth.

## Fresh ideas worth stealing
- **correlation handle** — scoped opaque or typed identifier used only to attempt a local match.
- **match witness** — residue about which basis produced a local match and at what scope.
- **mismatch quarantine** — explicit path when a handle parses but does not justify silent overreach.
- **scope honesty** — standing rule that issuer-, provider-, RP-, credential-, or session-scoped handles stay visibly scoped.
- **match smaller than subject** — a standing anti-regrowth rule.
