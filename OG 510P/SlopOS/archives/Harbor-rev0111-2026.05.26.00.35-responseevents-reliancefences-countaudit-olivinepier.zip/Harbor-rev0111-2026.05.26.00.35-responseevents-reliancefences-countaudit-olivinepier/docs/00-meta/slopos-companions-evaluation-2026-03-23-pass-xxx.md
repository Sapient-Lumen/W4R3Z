# SlopOS / companions evaluation — pass XXX

This pass re-checks Harbor against the uploaded cube ecology and keeps the architecture embryonic.

## What the current cubes still teach
- **SlopOS** is the clearest guardrail again. Its auth-mediation boundaries refuse to export portable pending-auth handles, verification URLs, polling schedulers, login-state truth, or generic continuation/session substrates. That strongly supports a Harbor move that records waiting, pacing, refusal, abandonment, and expiry as small crossing residue without inventing a portable pending-auth plane.
- **SlopOS** also keeps request/session objects provider-owned and family-local. Harbor should borrow the humility, not the object model: keep a compact pending rung at the crossing boundary, not a universal watched session object.
- **Steward** is a particularly useful sibling here. Its lessons around explicit pending request objects, cancellation, deadlines, and honest resolve/cancel/expire outcomes are exactly the temperament Harbor needs, even though Harbor should stay smaller than a supervisor or transcript manager.
- **Schell** already rewards “wait without fake completion.” That reinforces Harbor’s need for an inspectable in-flight posture that does not silently drift into success or durable consequence.
- **Helm** keeps pending and accepted states visibly different in front-door cards. Harbor can steal that same restraint for mediated crossings: pending review, explicit refusal, abandonment, and expiry should not flatten into the same bucket.

## Harbor consequence
Harbor should keep pending-state nouns provisional.
The right near-term move is small:
- add one specimen around `pending rung`, `pace hint`, `refusal rail`, and `expiry honesty`;
- keep portable pending-auth/session/account truth outside Harbor;
- and keep in-flight posture, final refusal, quiet abandonment, and durable consequence visibly separate.

## Still-not-yet decisions
- Whether `pending rung` deserves its own first-class card or remains a typed annotation on detour state.
- Whether `pace hint` should stand alone or stay nested under continuation/admission posture.
- Whether `refusal rail` and `expiry honesty` compress behind a smaller stop-reason family, or whether Harbor needs both because quiet abandonment is materially different from explicit denial.
