# Research synthesis — pass XCV, executable crossing evidence and portal-net bridge

**Revision:** `rev0095`  
**Date:** 2026-05-21  
**Question:** What should Harbor do after naming `CrossingRecord v0` so the term does not become another prose-only promise?

## Result

Harbor should make `CrossingRecord v0` executable enough to fail. The smallest safe step is a deterministic bundle with accepted and rejected cases, not a schema registry. That is what `rev0095` adds.

The new F090 bundle turns six recurring lessons into checkable facts:

1. accepted transport is not trusted content;
2. checkpoint/resume/truncation/append evidence is local durability evidence, not outside truth continuity;
3. callback return is not same authority;
4. MCP/tool metadata is not annotation truth or consent proof;
5. browser credential presentation is not global identity;
6. public-copy warning aftermath is not compliance, repair, or all-agent memory correction.

## External lessons folded in

- MCP tool/resource descriptions are useful as capability metadata, but tool annotations must be treated as untrusted unless they come from a trusted server; the harness therefore admits MCP metadata only with `not_tool_annotation_truth` and `not_user_consent_proof`.
- OAuth security guidance remains relevant because an authorization completion is still a scoped security event, not broad content truth or durable user comprehension.
- FedCM and Digital Credentials keep moving identity/credential presentation into browser-mediated APIs; Harbor should record the presentation event and audience, not promote global identity or issuer authority.
- XDG portal patterns remain useful because mediated openings and notifications demonstrate the difference between a request being handled and a user actually seeing, understanding, or adopting an outcome.
- SCITT, C2PA, Rekor/CT, and in-toto remain next-pass pressure: receipt, inclusion, provenance, subject/materials, and timestamp evidence should be imported only as scoped artifacts with non-promises.

## SlopOS-specific interpretation

SlopOS's rev720 `portal.net.request` corpus gives Harbor a concrete upstream shape to honor without copying. The F090 bundle imports only these stable ideas:

- route/admission evidence;
- exact subject digest binding;
- closed envelope rejection;
- accepted-only durable history;
- checkpoint/resume/truncation/append cursor discipline;
- denied/duplicate non-commit exclusion;
- discarded suffix rejection.

It refuses to import:

- SlopOS's internal schema as Harbor schema;
- current network lease truth;
- response content truth;
- outside state continuity;
- user comprehension;
- a final SlopOS datacube shape.

## New watchlist handles

- `harbor_crossing_record_evidence_bundle`
- `case.matrix`
- `input.external_evidence`
- `input.crossing_record`
- `scope.comparison`
- `output.admission`
- `output.aftermath`
- `verdict.summary`
- `route_family_non_promises`
- `ambient_truth_rejection`
- `latest_wins_scope_substitution_rejection`

## Practical design rule

A crossing noun earns the next round only when it has:

```text
positive fixture + negative fixture + digest binding + scope comparison + non-promises + checker
```

A crossing noun that has only prose remains a review note.

## Followthrough result

`F090` is now complete. `F091` should pressure-test transparency and provenance receipt import: SCITT-like inclusion, C2PA/content credentials, in-toto/SLSA attestations, Rekor/CT inclusion/currentness, timestamp anchors, redacted proof bundles, and compromised issuer stories must not become truth, compliance, freshness, or all-copy repair.
