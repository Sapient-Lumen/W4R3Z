# Research synthesis — pass XL

This pass keeps Harbor narrow and learns one more thing from browser-, chooser-, and authenticator-owned review surfaces: **what was shown should stay bounded, the requester/RP cue should stay explicit, and shortening should admit itself instead of pretending a partial card was the whole reviewed truth.**

## Outside lessons
1. **Consent/review can be structured yet still needs a bounded surface.**  
   RFC 9396 says the authorization server MUST present the merged set of requirements represented by the authorization request when gathering user consent, and it explicitly leaves deployments to determine how authorization details are shown to the user. Harbor should steal the lesson that a review surface can be richer than `scope`, but still has to be a bounded **review card** rather than uncontained prose.

2. **The review card should stay tied to exact protected basis.**  
   RFC 9101 says the authorization server MUST only use the parameters in the Request Object even if the same parameter also appears in the query. Harbor should therefore treat any display card as a projection from protected basis, not as a new independent source of truth.

3. **Chooser UI needs an explicit requester-origin cue.**  
   Credential Management says chooser UI should be distinguishable from UI a website could produce and MUST include an indication of the origin requesting credentials. FedCM migration guidance says the browser controls the prompts and only contacts the IdP after explicit user consent. Harbor should therefore preserve an explicit **origin cue** when the review surface belongs to the user agent rather than the requester.

4. **Displayed identity/review fields need hard boundaries.**  
   WebAuthn Level 3 says the authorization-gesture prompt should display `rp.id`, `rp.name`, `user.name`, and `user.displayName`, if possible. The same spec says displayed `name` and `displayName` values should always have a clear boundary and not overflow into surrounding UI. Harbor should steal that as a general display rule: keep the card bounded and keep individual fields contained.

5. **Truncation should stay honest.**  
   WebAuthn Level 3 allows stored `name` and `displayName` values to be truncated under a minimum size rule. That teaches a broader Harbor lesson: if the displayed card is shortened, cropped, or partially hidden, the crossing should preserve **truncation honesty** instead of letting the partial display masquerade as the full reviewed basis.

## Resulting Harbor move
Do not decide yet whether the durable nouns are exactly `review card`, `origin cue`, `bounded field`, and `truncation honesty`, or whether later pressure compresses some of them behind a smaller review-surface family.
For now, keep them alive as specimen nouns and require that they improve:
- one RAR/JAR specimen where a long merged ask becomes one bounded review card instead of sprawling or silently losing basis;
- one chooser/browser-mediated specimen where the origin cue remains explicit and visibly host-owned;
- and one WebAuthn-like bounded-display specimen where RP/user fields stay contained and shortened text admits that it is shortened.

## Fresh ideas worth stealing
- **review card** — host/UA/authenticator-owned bounded surface that summarizes the exact reviewed crossing without becoming the grant or durable account/session truth.
- **origin cue** — explicit requester/RP/origin indication carried on the review card.
- **bounded field** — display-bound field that cannot bleed into surrounding UI or adjacent chrome.
- **truncation honesty** — explicit reminder that shown text is shortened, cropped, or otherwise partial.
- **display smaller than reviewed basis** — standing anti-regrowth rule.
