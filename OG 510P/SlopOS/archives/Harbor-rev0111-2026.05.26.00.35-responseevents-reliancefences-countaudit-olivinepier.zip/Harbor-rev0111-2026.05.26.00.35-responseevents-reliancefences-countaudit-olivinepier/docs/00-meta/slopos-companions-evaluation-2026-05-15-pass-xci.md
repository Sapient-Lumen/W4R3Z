# SlopOS and companions evaluation — pass XCI

**Revision:** `rev0091`  
**Date:** 2026-05-15  
**Focus:** external escalation handoff, appeal windows, auditor/regulator/source-owner packets, sealed evidence boundaries, public-log/status divergence after handoff, and disputed sunset appeals.

## SlopOS pressure

SlopOS remains design-phase; that argues for scoped handoff receipts instead of a native authority, legal, or incident-management model.

The strongest SlopOS lessons for this pass:

- **Export is killable and non-mutating.** SlopOS attestation posture makes export policy-gated and non-mutating. Harbor should let escalation packet creation fail or remain unsafe-to-send without silently changing public status.
- **No secrets in public lanes.** SlopOS attestation posture refuses secrets in-band and treats provider-native evidence as opaque. Harbor should use sealed manifests and safe summaries instead of copying raw logs, suppressed cells, or private reporter/source details into public text.
- **Verifier-local currentness stays local.** SlopOS attestation collateral and result boundaries keep status, CRLs/OCSP, TCB info, verifier results, and cache freshness under explicit verifier policy. Harbor should treat auditor/regulator/source-owner responses as scoped observations, not current truth.
- **Imported advisory semantics are evidence.** SlopOS VEX/SBOM boundaries keep producer identity, status, justification, and distribution markings smaller than local policy and proof. Harbor should likewise keep appeal and handoff responses smaller than remediation, non-use, or compliance.
- **Transparency is not authority.** SlopOS signature/transparency boundaries warn against turning logged statements into native trust. Harbor should keep public-log escalation evidence separate from status-page currentness.

## Companion pressure

- **ViewFS:** visible copy state and source object state can diverge after handoff; packet subjects need exact copy/version/cut names.
- **Helm:** expiry and route windows support appeal deadlines, extension notes, and explicit no-automatic-stay posture.
- **Schell:** generated explanations are tempting public summaries, but sealed evidence and verifier packets must stay separate from explanatory text.
- **Ward:** status/frontier discipline supports post-handoff divergence notes when some surfaces update before others.
- **Foundry:** exactness and correction-horizon discipline supports safe public copy that refuses to summarize sealed proof beyond the approved result.
- **Steward:** remediation and cause/condition surfaces warn that Harbor should not import a workflow engine or enforcement ladder when a handoff packet would do.
- **SlopOS:** attestation/VEX/SBOM/transparency boundaries reinforce exact evidence, handling limits, and local appraisal.

## Harbor delta

`rev0091` adds:

- `docs/00-meta/datacube-external-escalation-handoff.md`;
- specimen flow 86 for standing challenge handoff, external escalation, appeal windows, sealed evidence transfer manifests, auditor/regulator/source-owner responses, public-log/status-page divergence, and disputed sunset appeals;
- external-escalation proof obligations in `docs/00-meta/datacube-proof-obligations.md`;
- refreshed lessons, inspiration harvest, source register, bibliography, ledgers, roadmap, briefing surfaces, manifest, and archive index.

## Deliberate non-promotion

This pass does not promote an external escalation handoff schema, appeal-window API, source-owner ticketing workflow, regulator/auditor packet format, sealed-evidence transfer protocol, public status-page product, transparency-log policy, legal/compliance workflow, incident-response program, CVD/PSIRT/CSIRT operating model, VEX/CSAF profile, in-toto predicate, SCITT receipt dependency, reporter/source-owner reputation model, enforcement ladder, or final SlopOS datacube shape.
