# Research synthesis — 2026-05-23 pass CIII

This pass pressure-tests the aftermath of consumer import. Prior F097 work proved that received material, extracted trees, copied fixtures, renamed archives, file-library uploads, and portal/callback transfers must be verified as material, not trusted as transport. F098 asks what happens next when local derivatives multiply.

## External pressure borrowed

- W3C PROV-DM keeps derivation subtle: a generated entity can be affected by a used entity, but mere use does not automatically prove derivation or equivalence. Harbor uses this to require derivative identity and transform scope before a local summary, subset, index, or re-export can claim source relationship.
- W3C Web Annotation keeps body, target, and annotation provenance separate. Harbor uses this to reject annotation-author authority and annotation status rewrites that lack target digest and source-scope evidence.
- RO-Crate 1.2 keeps root data entities, contextual entities, and provenance legible in one package-shaped description. Harbor borrows the idea that local derivative metadata may travel with material without becoming truth, compliance, or repair proof.
- BagIt and OCI-style layouts keep fixity/content identity distinct from location/reference/transport. Harbor uses that split again for re-exported archives, copied subsets, synced copies, and local indexes.
- Data Package descriptor/resource discipline keeps dataset-resource listings useful while reminding Harbor that a descriptor is not a verification result.

## Harbor conclusion

A verified handoff only establishes a scoped import. A local derivative needs its own record: source digest, target digest, derivative digest, transform scope, label and non-promise carry-forward, currentness/recheck basis, and consumer-copy state. Anything less should be a refusal or quarantine posture.

## Speculative seam

The next seam is correction propagation into derivatives. Once a source correction lands, Harbor needs to know which summaries, local indexes, re-exports, cached explanations, and synced copies are repaired, quarantined, expired, contradicted, unreachable, or merely acknowledged. That is not a cache API yet; it is a pressure field for F099.
