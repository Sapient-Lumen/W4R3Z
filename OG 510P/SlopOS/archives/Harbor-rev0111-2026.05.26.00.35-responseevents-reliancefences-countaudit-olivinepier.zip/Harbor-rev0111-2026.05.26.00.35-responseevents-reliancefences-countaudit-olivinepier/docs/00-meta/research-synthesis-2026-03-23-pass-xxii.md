# Research synthesis — pass XXII

This pass keeps Harbor narrow and learns one more thing from current federation and session-hardening work: **returning smoothly is useful, but continuity must stay smaller than portable session truth and smaller than durable adoption**.

## Outside lessons
1. **RFC 8252 and RFC 9700 still set the floor: external browser, exact redirect matching, and issuer defenses matter even when the same device returns.**  
   The old lesson survives because convenience keeps trying to outrun it. A familiar browser or a remembered account is helpful, but it does not outrank exact redirect validation, issuer identity, or local adoption.

2. **FedCM shows a productive split between browser-mediated continuity and portable truth.**  
   The user agent can keep a connected-account memory, offer a browser-mediated chooser, and even support streamlined auto-reauth in the same browser instance, while still deciding whether to show UI, request permission, or surface a mismatch. Harbor should steal the shape, not the whole browser-owned state model.

3. **DBSC shows how to harden continuity without turning it into a stable device identifier.**  
   Device-bound session work is attractive precisely because it tries to prevent off-device session theft while avoiding stable cross-session device identity. Harbor should learn the anti-regrowth rule: continuity can be stronger than folklore and still smaller than exported login truth.

4. **DBSC also reminds us what not to overclaim.**  
   It does not solve an attacker already resident on the same device, and it is not meant to prove the overall state of the device. Harbor should therefore treat any same-device continuity residue as bounded and defeasible.

5. **The uploaded cube ecology keeps browser/profile/account truth provider-local on purpose.**  
   SlopOS explicitly refuses portable browser-session selection, login-state export, auth-result export, and account-binding export. Harbor should inherit that restraint instead of minting a giant remembered-session or connected-account family.

## Resulting Harbor move
Do not decide yet whether the durable nouns are `continuity hint`, `returning-account hint`, `revalidation turn`, and `mismatch honesty`, or whether later pressure will compress some of them behind a smaller continuity-residue family.
For now, keep them alive as specimen nouns and demand that they improve:
- one same-browser returning federation specimen,
- one device-bound continuity specimen that remains smaller than session portability,
- and one mismatch specimen where expected continuity truthfully degrades to chooser, login, or stop.

## Fresh ideas worth stealing
- **continuity hint** — bounded evidence that the crossing may be returning through the same local browser/device posture.
- **returning-account hint** — modest clue that a previously used provider/account relation may still be available in this local context.
- **revalidation turn** — explicit step that checks whether continuity still deserves use before adoption.
- **mismatch honesty** — typed aftermath for stale, disconnected, or cross-instance continuity that does not silently carry forward.
- **per-session continuity without device identity** — a standing anti-regrowth rule worth preserving even if Harbor never owns the underlying session state.
