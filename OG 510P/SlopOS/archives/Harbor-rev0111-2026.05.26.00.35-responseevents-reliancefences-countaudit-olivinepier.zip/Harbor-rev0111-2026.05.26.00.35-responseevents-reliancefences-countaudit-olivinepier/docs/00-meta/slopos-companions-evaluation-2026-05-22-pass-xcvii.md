# SlopOS and companions evaluation — pass XCVII

**Revision:** `rev0097`  
**Date:** 2026-05-22  
**Focus:** multi-verifier disagreement, policy-epoch drift, badge refusal, currentness uncertainty, and issuer-status recheck pressure.

## SlopOS pressure

SlopOS keeps durable events smaller than the interpretations built on top of them. F092 extends that discipline to verifier outputs. A policy run, admission decision, or currentness check may cross into Harbor, but it must keep its own policy digest, input digest, epoch, scope, and non-promises.

The Harbor-side verifier-disagreement bundle keeps SlopOS-compatible discipline by requiring:

- deterministic fixture output;
- accepted and rejected cases;
- no emitted id for rejected candidates;
- digest-bound receipts and verifier runs;
- explicit policy id, policy digest, policy epoch, input digest, and no-semantic-truth bits;
- visible disagreement and majority/latest-wins refusal;
- bounded badge posture rather than single green status;
- recheck triggers for policy epoch, currentness, issuer status, scope substitution, verifier input drift, and badge collapse.

Harbor still does not import SlopOS internals, SlopOS policy state, or final SlopOS datacube shape.

## Companion pressure

- **Helm:** repair/intervention traces push badge surfaces to show recheck and split status rather than closure.
- **Schell:** retention and forgetting ledgers push policy epochs to preserve historical basis without memory-hole rewrites.
- **ViewFS:** volition and trusted-path cards push public badge posture to distinguish user-visible from user-understood.
- **Ward:** delegation warrants push verifier authority to stay scoped and revocable.
- **Foundry:** classification pins and witness crosswalks push disagreement classes to keep incomparable bases rather than forced verdicts.
- **Steward:** replay guards and pushback budgets push currentness unknowns to remain unknown until rechecked.

## Harbor delta

`rev0097` adds:

- a verifier disagreement / policy-epoch drift design surface;
- a deterministic fourteen-case verifier-disagreement bundle;
- a harness and checker wired into `make check` and `package-release`;
- proof obligations `PO-VD-001` through `PO-VD-007`;
- specimen flow 92;
- pass XCVII research and companion evaluation surfaces;
- source/register, lessons, inspiration, manifest, roadmap, context, and briefing updates.

## Deliberate non-promotion

This pass does not promote verifier arbitration, policy-drift ledgers, public badge semantics, reliance APIs, compliance workflows, legal status handling, trust-root policy, issuer reputation, or final SlopOS datacube shape. It only promotes the expectation that verifier-rich proposals must preserve disagreement and survive positive and negative executable fixtures.
