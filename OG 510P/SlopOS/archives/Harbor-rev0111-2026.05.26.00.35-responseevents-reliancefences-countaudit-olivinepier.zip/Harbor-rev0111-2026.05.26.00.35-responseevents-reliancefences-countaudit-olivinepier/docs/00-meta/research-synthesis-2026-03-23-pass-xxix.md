# Research synthesis — pass XXIX

This pass keeps Harbor narrow and learns one more thing from browser-mediated identity systems: **presence/status adverts should help discovery and verification without turning into portable login, session, or account truth.**

## Outside lessons
1. **FedCM keeps a browser-owned login-status map, not a universal login oracle.**  
   The FedCM spec gives the user agent a persistent Login Status map keyed by IdP origin, with values `unknown`, `logged-in`, and `logged-out`. That is an excellent Harbor pattern: a compact local advert can exist and matter without becoming durable cross-layer truth.

2. **FedCM also keeps status adverts resettable and attributable.**  
   The same spec lets IdPs set login status through an HTTP header or `navigator.login.setStatus()`, and it requires the browser to clear this state when cookies/site data are cleared. That is the right shape for Harbor: status adverts are real and useful, but they age, reset, and remain browser-local.

3. **A logged-out advert may stop or challenge a crossing, but it is still not final truth.**  
   If the stored FedCM login status is `logged-out`, the user agent must either fail or prompt the user whether to continue, potentially into an explicit IdP login dialog. Harbor should steal this restraint: a negative advert can narrow the next route without pretending the whole world now knows the user is logged out.

4. **FedCM mismatch handling is a brilliant anti-folklore move.**  
   When the browser expects `logged-in` but account fetch returns no accounts, the spec calls for a mismatch dialog and offers a fresh login turn. That is a powerful Harbor lesson: when adverts and fetched reality disagree, the right answer is an honest verification turn, not counterfeit continuity or silent state collapse.

5. **OIDC Session Management treats status change as a re-check trigger.**  
   Session Management gives the RP an opaque `session_state` and a `changed`/`unchanged` signal from the OP iframe. On `changed`, the RP must do a `prompt=none` reauthentication to learn the current truth. That is almost perfect Harbor material: `changed` means “verify now,” not “the session is definitely gone everywhere.”

6. **Credential Management refuses to let absence leak too cheaply.**  
   Credential Management says `get()` with mediation should not immediately resolve with `null` when no credentials are discovered, specifically to avoid revealing the lack of applicable credentials. That is a valuable Harbor reminder that absence and availability deserve privacy-aware handling rather than blunt negative truth.

## Resulting Harbor move
Do not decide yet whether the durable nouns are exactly `presence advert`, `verification turn`, `mismatch prompt`, and `status honesty`, or whether later pressure compresses some of them behind a smaller mediation/status family.
For now, keep them alive as specimen nouns and demand that they improve:
- one FedCM login-status specimen where stored `logged-in` / `logged-out` adverts shape the next turn without becoming portable login truth;
- one OIDC Session Management specimen where `changed` triggers verification instead of silent logout folklore;
- and one no-cheap-absence specimen where missing credentials/accounts do not instantly reveal a negative truth to the requester.

## Fresh ideas worth stealing
- **presence advert** — compact browser/provider-local hint such as `unknown`, `logged-in`, `logged-out`, `changed`, or `unchanged`.
- **verification turn** — explicit re-check lane triggered by advert drift or mismatch.
- **mismatch prompt** — honest user-visible floor when remembered status and fetched reality diverge.
- **status honesty** — standing rule that adverts stay visibly smaller than durable login, account, or session truth.
- **unknown is honest** — a first-class anti-regrowth rule.
