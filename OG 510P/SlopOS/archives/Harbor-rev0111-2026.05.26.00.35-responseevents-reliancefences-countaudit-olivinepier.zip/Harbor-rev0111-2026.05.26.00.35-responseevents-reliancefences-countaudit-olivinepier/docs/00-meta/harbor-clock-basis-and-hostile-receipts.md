# Harbor clock-basis and hostile receipt fixtures

**Status:** design-phase note for `rev0094`; not a clock service, deadline tracker, evidence format, transparency-log policy, or compliance workflow.

## Clock basis

Deadline and recheck language requires a source clock, a deadline, an observation time, a publication time where applicable, and stay/extension posture. Without those fields, Harbor may only say the deadline status is unknown.

## Hostile receipts

Negative fixtures should include wrong digest, wrong audience, copied receipt, backdated receipt, authorityless receipt, label-stripped export, clean recheck with hidden exclusions, publication without implementation, implementation without propagation, and log inclusion without semantic validation.

## Review rule

A receipt that proves `something was emitted` cannot by itself prove `the right thing was emitted`, `the right audience saw it`, `it was on time`, `it remained current`, or `it was true`.
