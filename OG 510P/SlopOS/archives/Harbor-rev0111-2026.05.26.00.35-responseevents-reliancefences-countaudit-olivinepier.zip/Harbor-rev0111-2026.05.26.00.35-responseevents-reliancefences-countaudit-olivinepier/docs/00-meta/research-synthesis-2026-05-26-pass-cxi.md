# Research synthesis — 2026-05-26 pass CXI

## Focus

User response-event capture after explanation cards: inspect, recheck request,
export, dismiss, appeal, share, acknowledge, focus, sealed-detail request,
agent follow-up, notice opt-out, batch acknowledgement, and automated retry.

## External pressure

- W3C Privacy Principles pressure Harbor to treat meaningful user agency and
  data minimization as design constraints, not as evidence that a user response
  proves comprehension, consent, or reliance.
- Kantara Consent Receipt pressure shows why a consent record needs a specific
  transaction and terms.  Harbor therefore refuses acknowledgement-as-consent
  and agent-acknowledgement-as-user-consent.
- WCAG labels/instructions and status-message guidance continues to pressure
  clear controls and programmatic status, but a clear control or focused status
  message still does not prove the user understood it.
- RFC 9457 Problem Details continues to pressure machine-readable reason codes,
  but an automated retry from a problem detail is not repair or human reliance.

## Harbor consequence

F106 records interaction traces only when they remain bound to the parent F105
explanation digest, scope, event kind, follow-up state, privacy/retention
posture, and history.  Missing parent explanation digest, direct-person
analytics, unbounded retention, notification-delivery-as-user-action,
click-as-comprehension, checkbox-as-consent, export-as-reliance, share-as-all
read, appeal-as-repair, retry-as-repair, and stale response-as-currentness are
all rejected.

## Audit/refactor consequence

The executable proof-slice count is now registry-derived.  Landing-page audits
look for `EXECUTABLE_SURFACE_COUNT_PHRASE` instead of a hand-written word count,
so adding F106 does not require another fragile spelling update in the checker.
