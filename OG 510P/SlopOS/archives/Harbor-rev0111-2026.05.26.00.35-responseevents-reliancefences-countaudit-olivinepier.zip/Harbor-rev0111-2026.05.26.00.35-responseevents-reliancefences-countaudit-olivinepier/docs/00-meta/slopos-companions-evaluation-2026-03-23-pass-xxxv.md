# SlopOS / companions evaluation — pass XXXV

This pass re-checks Harbor against the uploaded cube ecology and keeps the archive embryonic.

## What the current cubes still teach
- **SlopOS** is already excellent at keeping helpful descriptors smaller than live authority. In `capability-export-schema-v0.md`, `rights_hint` is explicitly optional and non-authoritative, and replicated proxy metadata is never enough to recreate a live callable handle on its own.
- **SlopOS** says the same thing again in `attention-lease-posture-v0.md`: urgency is a hint, never a bypass and never a capability. That is exactly Harbor’s cultural lane too.
- **SlopOS** also keeps other metadata surfaces honest — for example, script-entry posture treats shebangs as non-authoritative metadata and fails closed when exact reviewed selectors are missing.
- **Foundry** remains a good sibling pressure source because config layers, overlay gates, and realization checks all keep “what the config says” visibly smaller than “what is actually admitted and instantiated.”
- **Steward** keeps teaching that activation tokens, mode baselines, and other advisory surfaces should remain freshness-scoped hints rather than silent control or authority.

## Harbor consequence
Harbor should keep support/negotiation nouns provisional.
The right near-term move is small:
- add one specimen around `support advert`, `method hint`, `negotiation witness`, and `unsupported-here honesty`;
- keep advertised support, config flags, and transport hints visibly smaller than the actual chosen/admitted path;
- and let stronger siblings own durable capability registries, launch/runtime authority, or provider-local method catalogs.

## Still-not-yet decisions
- Whether `support advert` deserves its own first-class card or belongs as one exact field on discovery/admission residue.
- Whether `method hint` should stay generic across route/transport/method families or later split into narrower cards.
- Whether `negotiation witness` belongs in Harbor at all, or whether it is only an explanation chip attached to stronger local admission/outcome objects.
