# SlopOS / companions evaluation — pass XXXI

This pass re-checks Harbor against the uploaded cube ecology and keeps the architecture embryonic.

## What the current cubes still teach
- **SlopOS** is the clearest anchor again. Its request-state and idempotency posture repeatedly says that the same scoped request key may replay only the same canonical request, while changed bytes under that key reject before effect. That is exactly the rule Harbor needs for crossing retries: exact replay only, never mutable reuse.
- **SlopOS** also keeps request/session/result handles provider-local. Harbor should borrow the humility, not the substrate: preserve small replay residue at the crossing membrane instead of inventing a portable resume/session plane.
- **Steward** is an unusually close sibling for this pressure. Its replay gates, effect keys, consumable grants, and duplicate-suppressed truth all argue that retries deserve typed honest aftermath rather than hidden reruns or fake exactly-once folklore.
- **Ward** already teaches that later events and receipts are historical fact smaller than current authority. That same humility transfers well to replay handling: a late duplicate can be historically real without earning fresh effect.
- **ViewFS** keeps basis, reuse, revalidation, and renewed authority visibly separate. Harbor can steal that temperament: same crossing basis may justify duplicate suppression without pretending a consumed handle is now fresh again.

## Harbor consequence
Harbor should keep replay-state nouns provisional.
The right near-term move is small:
- add one specimen around `replay witness`, `duplicate suppression`, and `consumption honesty`;
- keep exact-replay discipline visible as a rule rather than a giant resume model;
- and keep spent/duplicate/mismatch aftermath outside portable session, account, or current-authority truth.

## Still-not-yet decisions
- Whether Harbor needs a first-class attempt handle, or whether replay witness can stay attached to request envelope / detour lease / callback proof surfaces.
- Whether duplicate suppression is its own outcome class or a modifier on aftermath receipts.
- Whether consumption honesty and expiry honesty compress together later, or whether spent-versus-expired turns out to be a load-bearing distinction.
