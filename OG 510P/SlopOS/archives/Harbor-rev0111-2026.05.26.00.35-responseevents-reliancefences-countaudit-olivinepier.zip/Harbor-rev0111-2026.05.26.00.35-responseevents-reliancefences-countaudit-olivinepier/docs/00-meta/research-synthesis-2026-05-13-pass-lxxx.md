# Research synthesis — 2026-05-13 pass LXXX

Question: how should Harbor pressure-test `F075` — missing sidecars, blocked observation exports, unsupported assertion compilation, stale frontiers, tombstone/withdrawal residue, and consumer-facing refusal ledgers — without promoting a global negative-evidence schema, incident manager, data-quality product, sidecar registry, assertion compiler, freshness service, or delete model?

## Result of this pass
The strongest next move is to treat negative outcomes as **bounded process residue with lifecycle**, not as a second truth plane.

The pass therefore adds:

- `docs/00-meta/datacube-negative-evidence-refusal-ledgers.md` — a compact review surface for negative evidence, refusal classes, lifecycle, and anti-counterfeit tests; and
- `docs/30-architecture/specimen-flow-75-negative-evidence-refusal-ledger-stale-frontier.md` — a concrete specimen covering a missing optional lineage sidecar, blocked export, unsupported assertion target, stale frontier, tombstone/withdrawal note, and consumer-facing refusal row.

This closes `F075` while preserving the design-phase stance: Harbor can be honest about absence, refusal, unsupported semantics, and stale progress without deciding SlopOS's final datacube representation.

## External lessons folded into this pass
1. **Quality tools are strongest when failures preserve inspected evidence.** Great Expectations can retrieve unexpected rows from a validation definition, while dbt can separately configure warning/error thresholds and optionally store test failures. Harbor should steal the principle: a failed or refused check should preserve enough bounded evidence for review, but the failure table is not the source data and not the semantic meaning of the lane.

2. **Assertion systems separate rules, incidents, and contracts.** DataHub describes assertions as data-quality rules and contract building blocks, and its open assertion work treats tool-specific outputs as compilation targets. Harbor should keep unsupported compilation as an explicit no-result/downgrade posture, not as pass, fail, or silent omission.

3. **Lineage failure is runtime evidence, not ontology.** OpenLineage has terminal run states such as fail/abort/complete and facets for error payloads. Harbor should borrow a scoped run/result/error receipt shape, but keep the receipt smaller than row truth, consumer contract, and global lineage meaning.

4. **Tombstones and deletes are not ordinary nulls.** Kafka log compaction and Debezium tombstone behavior show why delete markers need retention windows and why late consumers can miss negative evidence after compaction. Iceberg's position/equality deletes likewise keep delete evidence separate from base data files. Harbor should record withdrawal humility: tombstone is not null, not safe purge, not no-history, and not proof that identity reuse is safe.

5. **Frontiers and watermarks are domain-scoped progress claims.** Flink watermarks, late-data handling, and Materialize frontier explanations reinforce that a stale or insufficient frontier should narrow a claim rather than become a universal stale badge. Harbor should refuse fresh-through labels when the domain-specific frontier is insufficient, while allowing old-cut previews when honestly labeled.

6. **Schema transforms can declare impossibility.** OpenTelemetry schema files explicitly support transformations only when conversion is possible; impossible conversions are breaking changes. Harbor should use the same humility for assertion compilers and export transforms: unsupported semantics must be carried forward as unsupported, not erased.

7. **SlopOS makes refusals policy-shaped.** SlopOS CH-OBSPOL's allowlist/bounds/fail-closed posture and RFC-0097's migration-gate posture imply that negative datacube outcomes need policy/gate basis, bounded messages, and recheck triggers. Refusal is a controlled membrane outcome, not a vague exception string.

## New process shape
`docs/00-meta/datacube-negative-evidence-refusal-ledgers.md` names six process handles:

- missing sidecar note;
- blocked export receipt;
- unsupported assertion target note;
- stale frontier notice;
- consumer-facing refusal ledger row;
- tombstone / withdrawal humility note.

These are not canonical schema objects. They are review vocabulary for specimens, promotion packets, and future source refreshes.

## Specimen selected
Specimen flow 75 models a public callback cube slice request that cannot be safely emitted as requested:

- base rows exist, but row-lineage sidecar evidence is missing for the cut;
- sanitized export policy blocks sensitive components;
- a target assertion engine cannot preserve Harbor's withheld/null/default-shadow/not-observed distinction;
- event-time frontier is too old for the requested fresh-through label;
- one old key is withdrawn by tombstone-like correction evidence, with purge/reuse hazard still open;
- Harbor records a bounded consumer-visible refusal and an operator-visible row with recheck triggers.

## Still not decided
- one negative-evidence schema or public API;
- one incident / data-quality / assertion product;
- one tombstone, delete-file, or compaction implementation;
- one sidecar registry;
- one frontier/freshness service;
- whether SlopOS's final datacube exposes refusals, incidents, assertions, or sidecars at all;
- whether any of the six negative-evidence handles become first-class Harbor cards.

The deeper lesson is: **a refusal that names its basis, scope, lifecycle, and non-promises is useful; a refusal that looks like fact is dangerous.**
