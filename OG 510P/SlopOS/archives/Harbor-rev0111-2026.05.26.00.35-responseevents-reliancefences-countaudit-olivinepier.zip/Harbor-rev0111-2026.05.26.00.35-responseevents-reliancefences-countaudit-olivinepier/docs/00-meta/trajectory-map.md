## Pass XCII trajectory note

Harbor now has an inbound outside-finding seam after outbound handoff: source owners, auditors, regulators, reporters, appeal outcomes, and logs can return scoped claims that are useful but not automatically authoritative. The next trajectory pressure is implementation after adoption: how to track mandated and recommended corrections without inventing compliance automation or universal repair.

## Pass LXXXIX trajectory note

Harbor now has a dispute/status-reconciliation seam after stale downstream impact: a public correction can be source-valid, propagated to some targets, used downstream, acknowledged, partly remediated, challenged, contradicted externally, unverifiable for model/eval paths, and still public-status-stale. The next trajectory pressure is recurrence: repeated stale-copy regressions and serially weak claims without inventing a reputation system.

# Trajectory map

## Current thesis

Harbor should begin as a **small, high-signal companion cube** whose main job is to metabolize a missing class of cross-pressure before it can leak confusion into the rest of the ecology.

## Non-negotiables
1. Harbor owns a distinct pressure class and should not merely duplicate a sibling cube.
2. The cube may converse with sibling companions, but its public text stays clean of the sealed primary.
3. Early documents should freeze separations and non-decisions, not pretend a giant implementation stack already exists.
4. Outside examples are teachers, not templates.

## Immediate direction
- tighten the object model,
- keep the strongest distinctions visible,
- export compact artifacts that neighboring cubes could plausibly consume later,
- and grow only the subfamilies that survive repeated pressure, including pressure from recency/freshness claims, browser/provider status adverts, fetched discovery/config surfaces, and released identity/profile bundles that feel stronger than they really are.
