# Research synthesis — 2026-05-25 pass CX

## Focus

User-visible explanation bundles for revocation overlays: wording, labels,
reason codes, scope/digest basis, history linkage, accessibility/localization
posture, and safe action affordances.

## External pressure

- WCAG 2.2 status-message guidance pressures Harbor to treat visible status
  text and programmatic status exposure as display posture, not proof of user
  comprehension or accessibility conformance.
- WCAG labels/instructions guidance pressures Harbor to require clear labels
  and instructions for controls without treating clear wording as consent,
  reliance, or repair.
- Web Annotation's body/target/provenance split pressures Harbor to keep an
  explanation card smaller than the target artifact or overlay authority.
- RFC 9457 Problem Details pressures Harbor to pair machine-readable reason
  codes with human explanation while refusing machine-code-only user messages
  or workflow closure.
- Prior Linked Data Notifications and ResourceSync pressure still applies:
  delivery, availability, and change announcement remain weaker than read,
  application, synchronization, or repair.

## Harbor consequence

A public explanation needs parent overlay digest, scope map, plain-language
copy, caveats, reason code, history visibility, action affordance, and
access/localization posture.  It must refuse badge-only display, red global
failure banners, closure language, prior-fault claims, color-only indicators,
source-digest-free summaries, localization scope widening, read/application
upgrades, global repair buttons, hidden history, sealed detail leakage,
timestamp currentness, machine-code-only messages, confidence-as-truth, and
legal advice.

## Audit/refactor consequence

The three entrypoint documents are now current-focused surfaces rather than
revision-log dumps.  `check_harbor_briefing_focus.py` blocks stale appended
revision fragments in `README.md`, `START_HERE.md`, and `docs/README.md`.
