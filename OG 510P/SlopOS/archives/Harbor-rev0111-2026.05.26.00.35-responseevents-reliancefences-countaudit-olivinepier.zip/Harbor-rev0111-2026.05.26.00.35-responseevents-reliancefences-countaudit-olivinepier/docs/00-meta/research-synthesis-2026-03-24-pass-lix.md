# Research synthesis — pass LIX

This pass keeps Harbor narrow and learns five compatible things at once: **RAR metadata can tell a client where shape guidance came from without turning that source into permanent type law; `schema` versus `schema_uri` is a real construction split rather than a cosmetic transport choice; normal HTTP caching applies to fetched metadata, so stale schema guidance deserves its own warning surface; receiver-visible authorization details can be filtered and extended for one receiver without becoming universal grant truth; and cross-domain Resource Authorization Servers can legitimately enrich or filter details again, which means Harbor should preserve the mismatch between client-built detail objects and later receiver-enriched views instead of flattening them.**

## Outside lessons
1. **Schema source is a real fact, not just implementation trivia.**  
   The February 2026 RAR metadata draft defines an authorization-server metadata endpoint named `authorization_details_types_metadata_endpoint`, says each type definition can carry either inline `schema` or external `schema_uri`, and makes those two fields mutually exclusive. Harbor should therefore preserve a **schema-source note** instead of pretending all detail shapes were learned the same way.

2. **Human-readable text is smaller than validation truth.**  
   The same draft says the `description` field is informational and clients **MUST NOT** rely on it for authorization or validation decisions. Harbor should keep examples and descriptions visibly smaller than actual validation or local admission truth.

3. **Schema fetch has a cache story, so staleness has to stay visible.**  
   RFC 9728 says protected-resource metadata is fetched with HTTP GET and that normal HTTP caching behavior applies, with implementations expected to use directives such as `Cache-Control: max-age`. A client that followed `schema_uri` or metadata endpoints through cached responses can therefore be honestly out of date without that implying wrong target, wrong account, or wrong session. Harbor needs a **cache-staleness detail warning** instead of flattening stale-shape fallout into generic auth failure.

4. **Receiver-visible details can still be enriched after the client built them.**  
   RFC 9396 says JWT access tokens may carry `authorization_details` filtered to the specific audience, and introspection responses may carry `authorization_details` filtered and extended for the requesting resource server. Harbor therefore needs a **receiver-enriched detail card** rather than a universal grant or schema truth object.

5. **Cross-domain/resource-authorization servers sharpen the mismatch.**  
   The March 2026 Identity Assertion JWT Authorization Grant draft says both the IdP and the Resource Authorization Server may modify, filter, or omit `authorization_details` based on policy, and must reflect granted values when they differ from the request. That means a client can correctly construct details from schema metadata and still later see a narrower or enriched receiver-facing form. Harbor should preserve the split instead of promoting a portable authorization-details registry.

## Resulting Harbor move
Do not decide yet whether Harbor needs durable nouns such as **schema-source note**, **receiver-enriched detail card**, or **cache-staleness detail warning**.
For this revision:
- add one specimen where a client follows protected-resource metadata to an authorization-details metadata endpoint, builds a detail object from inline schema or `schema_uri`, later encounters a receiver-enriched detail view, and then discovers its cached schema guidance was stale;
- keep source-of-shape, built-request shape, receiver-visible enriched shape, and stale-cache explanation visibly separate; and
- treat schema fetch/caching as implementation residue rather than Harbor’s permanent type or policy language.

## Fresh ideas worth stealing
- **schema-source note** — compact residue saying whether shape guidance came from inline schema, fetched `schema_uri`, or trusted local configuration.
- **receiver-enriched detail card** — receiver-facing view that is filtered or extended for one verifier and stays smaller than durable entitlement truth.
- **cache-staleness detail warning** — typed bottom or warning that the client may have validated against stale metadata/schema guidance.
- **trusted-schema audience note** — reminder that actionable error-body detail objects are aimed at the resource server’s trusted authorization servers, not the world.
- **shape newer than cache** — standing anti-regrowth rule: a stale cache mismatch is not target drift, account drift, or session collapse.
