# Research synthesis — 2026-05-22 pass CI

## Release packaging as a new membrane

F096 treats the release zip as a boundary crossing. The source tree is not the archive; the archive is not automatically the source tree; and a receipt inside the source tree cannot be the final word about the artifact created after that receipt is packed.

## Borrowed pressures

- Reproducible-build practice makes timestamp discipline explicit. `SOURCE_DATE_EPOCH` is useful precedent because it shows that build time must be an input, not hidden ambient state. Harbor uses a fixed ZIP timestamp for deterministic packaging, but refuses to call that general reproducibility.
- SLSA provenance emphasizes where, when, and how an artifact was produced, and separates build definition, run details, builder identity, parameters, and dependencies. Harbor borrows that separation as a checklist, not as a SLSA predicate.
- in-toto's attestation layers separate subject, statement, predicate, envelope, and bundle. Harbor borrows the idea that a statement binds evidence to a subject, but refuses to treat an internal fixture as a signed envelope.
- Artifact-attestation systems are useful exactly because consumers must verify and apply policy. Harbor records that an attestation or package receipt is not a security guarantee.

## Harbor-specific seam

The package boundary has two digest domains:

1. source-tree evidence digests, which the fixture can include;
2. final zip digest, which must be computed after packaging.

Combining them too early creates a bootstrap lie. The fixture cannot contain the final archive digest without either predicting the future or causing a circular rebuild. The safe posture is to record the packaging plan and then produce an out-of-band archive check after the zip exists.

## Speculative next seam

F097 should pressure artifact handoff and consumer import. A downstream user may receive a zip, an extracted tree, a copied fixture, a checksum in chat, a file-library upload, or a renamed archive. Harbor needs handoff records that distinguish transport, copy identity, extraction root, manifest match, and consumer-side verification without turning a pasted digest into authority.
