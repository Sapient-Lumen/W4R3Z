# Datacube design principles

Harbor is still in design phase. That means the archive should optimize for **truthful separations and reversible growth**, not for early completeness or stack selection.

## What we should decide now
1. **Declare grain before families.** Every durable surface should say what one row, card, or receipt represents before Harbor adds new dimensions, measures, or registries.
2. **Prefer atomic history first.** Start from the smallest truthful crossing/event grain that can survive later questions; let rollups, summaries, and semantic conveniences come later.
3. **Separate logical meaning from physical layout.** Partitioning, clustering, storage format, cache strategy, and pre-aggregation are implementation details until they materially change user-visible truth.
4. **Make time policy explicit.** Corrections, history-preserving changes, late-arriving context, and restatements are different moves and should never be flattened into one generic “update.”
5. **Grow by addition more often than mutation.** New fields, facets, or sidecars are healthier than redefining old rows in place.
6. **Put contracts on curated surfaces, not raw seams.** Stable downstream promises belong on deliberately published Harbor views/cards/receipts, not on every raw ingest or intermediate structure.
7. **Not every promise family must mature together.** Returned shape, row meaning, assertion posture, and service posture can stabilize at different times.
8. **Keep optional annotations smaller than core truth.** Extra provenance, experimental fields, or neighbor-facing hints should start as explicit sidecars/facets before they can become core Harbor nouns.
9. **Treat change history as first-class evidence.** A later consumer should be able to tell what changed, when, and why without guessing from the newest shape alone.
10. **Keep review surfaces stronger than generated artifacts.** SQL DDL, semantic-model configs, catalog exports, and engine-specific lanes can help, but they should stay derived until Harbor explicitly chooses otherwise.

## What we should not decide yet
- exact table format;
- exact OLAP/warehouse engine;
- exact semantic-layer product;
- exact partition strategy;
- exact branch/reference/versioning product for future publish lanes;
- whether Harbor eventually looks more dimensional, vault-like, anchor-like, or hybrid.

Those are all legitimate future choices. They are just **too expensive to freeze before Harbor’s own pressure classes settle**.

## Repo/process rules for the design phase
- Every new durable noun should attach to a same-revision specimen, research pass, or explicit open question.
- If a new field or annotation can begin life as a smaller facet/sidecar, do that before widening the core schema.
- If a revision introduces a new “must stay true” design rule, wire it into a briefing surface and, when cheap, into a hygiene check.
- Refresh living load-bearing sources before promoting datacube nouns that depend on them.
- Follow `docs/00-meta/datacube-review-loop.md` whenever a revision changes datacube-side semantics, repo process, or semantic-export posture.
- Keep exactly one `next` followthrough item.
- Keep speculative implementation ideas visibly smaller than durable semantic commitments.

## Current Harbor bias
For now Harbor should bias toward:
- **grain contract card** over early cube-wide dimension catalogs;
- **contract-tier card** over one early all-or-nothing data contract;
- **late-bound evolution lane** over destructive schema rewrites;
- **facet-version note** over premature core inflation;
- **restatement receipt** over silent historical mutation; and
- **curated semantic front door later** rather than now;
- **contract subset + freshness witness** over one early all-in-one trust badge;
- **row-lineage sidecar** over one premature universal row identity; and
- **publish lane card + promotion merge receipt** over one early universal export tree.
