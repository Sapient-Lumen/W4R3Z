# SlopOS / companions evaluation — pass XLVII

This pass re-checks Harbor against SlopOS and the sibling cubes after adding an exact-target specimen, and again chooses one narrow crossing seam over any early family bloom.

## What the current cubes still teach
- **SlopOS** remains the strongest restraint mechanism. Its MCP auth exact-match and metadata-import boundaries already keep issuer identity, metadata fetch, redirect handling, and authorization context provider-local instead of silently becoming portable trust or route truth. That lines up cleanly with Harbor treating audience basis and endpoint target as small crossing residue rather than as a new portable endpoint-authority plane.
- **SlopOS** also contributes a more general operational lesson: exact endpoint identity can matter without deserving a first-class user-facing registry. Harbor can borrow that restraint directly.
- **Ward** keeps reinforcing the exact-basis instinct: a strong-looking success path is still weaker than the exact local basis that proves this was the right place to land.
- **ViewFS** keeps contributing the anti-alias lesson from another angle: resolve-once stable inputs beat live alias folklore. Harbor can borrow that habit for endpoint-target comparisons without inheriting ViewFS’s object-identity mission.
- **Helm** keeps the review-surface lesson alive: the right chrome can explain which route or provider was in play, but polished UI still loses to exact local target checks.
- **Steward** keeps the accountability lesson alive: an alias veto or target mismatch should survive as inspectable aftermath instead of disappearing into a generic failure bucket.

## Harbor consequence
Harbor should keep this move modest:
- add one specimen around **audience-basis witness**, **endpoint-target card**, and **alias veto**;
- keep signed-envelope basis, exact endpoint target, and returned target/resource cues visibly smaller than durable issuer/resource/grant/adoption truth;
- collect **normalized-target note** and **effective-target echo** as inspiration only;
- and leave any future registry of endpoint classes, alias families, or portable target receipts outside Harbor for now.

## Still-not-yet decisions
- Whether **audience-basis witness** deserves its own Harbor family, or should remain an annotation on detour/basis surfaces.
- Whether **endpoint-target card** belongs in Harbor at all, or should remain only a smaller exact-target note attached to specific specimens.
- Whether **alias veto** belongs in Harbor, or should stay a typed local refusal outcome that never blooms into a target-trust registry.
