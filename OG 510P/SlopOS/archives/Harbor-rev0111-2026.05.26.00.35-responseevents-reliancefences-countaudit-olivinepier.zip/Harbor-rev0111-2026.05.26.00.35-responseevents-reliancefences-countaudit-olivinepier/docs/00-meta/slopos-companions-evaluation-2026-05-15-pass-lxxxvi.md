# SlopOS and companions evaluation — pass LXXXVI

**Revision:** `rev0086`  
**Date:** 2026-05-15  
**Focus:** public corrections, errata, annotations, stale citations, generated explanations, and consumer disputes after friendly public copies escape.

## SlopOS pressure

SlopOS remains in design phase. This pass should therefore keep Harbor's public-correction posture small and reversible.

The strongest SlopOS lessons for this pass:

- **Imported annotations are not authority.** SlopOS's MCP resource and tool-annotation boundaries keep imported annotations and hints advisory. Harbor should apply the same rule to public datacube annotations: useful targets and bodies, but no automatic truth upgrade.
- **Citation heads are not stable truth by default.** SlopOS external-source hygiene distinguishes operational/discovery heads from citation-ready reviewed heads. Harbor should carry stale-citation witnesses instead of assuming a copied link still points at the current artifact.
- **Generated explanations are derived.** SlopOS LLM/posture boundaries keep model output smaller than authority, approval, or replay proof. Harbor should require generated-explanation receipts and invalidation triggers before a model summary travels beside public data.
- **Display and accessibility lanes do not grant disclosure.** SlopOS display/accessibility boundaries keep observation, review, input, and automation rights separate. A dispute about suppression/noise labels should not reveal sealed cells merely because the copy was public.
- **Observation-export policy still gates the evidence.** A correction or dispute can cite sealed evidence, but Harbor should return a class-level or auditor-only response when raw suppressed values cannot be disclosed.

## Companion pressure

- **Ward:** correction lineage, dedupe posture, and delete/tombstone history reinforce that current winner, raw history, and corrective replacement are distinct truths.
- **Foundry:** exactness class and correction horizon map directly to Harbor's public-status banners: current, superseded, corrected, explanation-only, and unsafe-for-new-use must not flatten into one badge.
- **Schell:** history correction and safe retry humility provide a UI/process lesson: suggestions, repairs, and reruns need old→new diff, basis drift, and approval boundaries.
- **ViewFS:** annotations, badges, trusted labels, and projection discipline warn that pretty path/advisory metadata cannot become object truth.
- **Helm:** review queues, stale fences, and briefing overlays suggest correction anchors need triage and stale indicators without becoming a support platform.
- **Steward:** remediation lanes are useful for accepted corrections, repaired translations, inaccessible variants, stripped labels, and stale generated explanations.

## Harbor delta

`rev0086` adds:

- `docs/00-meta/datacube-public-correction-dispute-hygiene.md`;
- specimen flow 81 for corrected public artifacts, translated errata, public annotations, stale citations, generated explanations, cache/variant mismatch, and consumer disputes;
- proof obligations for correction anchors, annotation provenance, citation freshness, generated explanations, and dispute responses;
- refreshed source-register, bibliography, lessons, inspiration, roadmap, and ledgers.

## Deliberate non-promotion

This pass does not promote a public-feedback ledger schema, correction API, annotation store, comment/moderation workflow, ticketing product, citation resolver, generated-explanation service, public status vocabulary, DOI policy, legal removal process, or final SlopOS datacube shape.
