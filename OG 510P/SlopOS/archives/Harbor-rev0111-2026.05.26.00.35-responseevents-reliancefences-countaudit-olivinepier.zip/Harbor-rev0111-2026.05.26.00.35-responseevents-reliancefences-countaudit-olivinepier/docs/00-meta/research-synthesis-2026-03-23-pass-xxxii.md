# Research synthesis — pass XXXII

This pass keeps Harbor narrow and learns one more thing from browser-mediated identity stacks and request-context systems: **cancellation is coordination, not verdict, and abort can race completion.**

## Outside lessons
1. **Credential Management treats abort as real but not omnipotent.**  
   `navigator.credentials.get()` and `create()` both accept an `AbortSignal`, and an aborted operation may either complete normally or reject with the abort reason. That is exactly the shape Harbor should steal: a stop request is real crossing residue, but it is not proof that the remote side, chooser, or provider never finished.

2. **WebAuthn cleanly separates caller abort from generic refusal.**  
   WebAuthn Level 3 says `AbortError` means the ceremony was canceled by an `AbortController`, while `NotAllowedError` remains the catch-all bucket that includes common cases like user cancellation. It also defines `authenticatorCancel` so the client can terminate in-progress operations and ignore later responses from the canceled operation. Harbor should preserve that difference instead of flattening every non-completion path into one vague refusal.

3. **FedCM keeps dismissal and cooldown honest.**  
   The FedCM flow explicitly bottoms out in failure when the user closes a mismatch or account dialog, and the WebDriver hooks include a resettable cooldown for cases where the user dismissed the dialog. That is a beautiful small idea to steal: dismissal leaves real local residue that shapes the next attempt without becoming durable account/session truth.

4. **Go’s `context` package keeps cancellation and deadlines request-scoped.**  
   Go’s standard `context` package carries deadlines and cancellation signals across API boundaries, propagates parent cancellation to children, distinguishes `Canceled` from `DeadlineExceeded`, and reminds callers that `CancelFunc` tells work to stop but does not wait for it to stop. Harbor should borrow that exact humility for crossing aborts and deadline bottoms.

5. **SlopOS already says the quiet part plainly.**  
   RFC-0105 in SlopOS treats cancellation and deadlines as coordination and resource hygiene, not a security boundary or authority grant. That is the cleanest local guardrail for Harbor: preserve cancel/deadline residue at the membrane without inventing a portable cancel/session plane.

## Resulting Harbor move
Do not decide yet whether the durable nouns are exactly `abort pulse`, `cancellation witness`, `deadline floor`, and `completion-race honesty`, or whether later pressure compresses some of them behind a smaller detour/aftermath family.
For now, keep them alive as specimen nouns and demand that they improve:
- one browser-mediated `AbortSignal` specimen where caller abort and user refusal remain visibly different;
- one chooser/dialog-dismissal specimen where dismissal leaves honest local residue and maybe cooldown/backoff posture;
- and one request-context/deadline specimen where timeout or caller disconnect bottoms out honestly without becoming a portable session/account verdict.

## Fresh ideas worth stealing
- **abort pulse** — explicit local/browser/runtime stop request for an in-flight crossing.
- **cancellation witness** — inspectable residue about who pulled the stop signal and at what layer.
- **deadline floor** — typed point where continued waiting is no longer honest.
- **completion-race honesty** — standing reminder that cancel may race completion, so local aftermath may need to record both facts.
- **dismissal cooldown** — compact local residue saying a user-dismissed chooser should quiet or slow the very next attempt without rewriting identity truth.
