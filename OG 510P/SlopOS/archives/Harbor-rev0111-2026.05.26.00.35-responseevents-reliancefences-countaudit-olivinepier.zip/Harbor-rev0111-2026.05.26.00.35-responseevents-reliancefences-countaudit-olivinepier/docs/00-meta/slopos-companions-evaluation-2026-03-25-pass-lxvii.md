# SlopOS / companions evaluation — pass LXVII

This pass asks a datacube-discipline question rather than a warehouse question: if Harbor starts publishing lanes with booleans, enums, rollups, or optional facets while SlopOS is still in design phase, how does Harbor stop “blank”, `0`, default enum members, and omitted children from pretending to mean the same thing?

## What the companions teach this pass
- **SlopOS** remains the strongest process teacher because it keeps claim, posture, and evidence on visibly different surfaces. Its claim/posture matrices are a useful reminder that “a value is absent”, “a value is inapplicable”, and “we never promised to claim this here” are not interchangeable truths. Harbor should steal that discipline for datacube presence semantics.
- **SlopOS** also keeps boundary meaning explicit and singleton-sized. That makes it a good nearby model for keeping presence semantics small: one compact witness is healthier than prematurely inventing a cube-wide null ontology.
- **Ward** keeps teaching temporality and tier honesty. That same habit transfers well here: missing because the retained tier did not materialize the slot is not the same as producer-side absence.
- **Foundry** keeps teaching residue-class discipline. For Harbor, that is a reminder that one blank-looking or default-looking result often still needs an explicit residue class.
- **Steward** keeps proving that small receipts beat oral history. Harbor should therefore prefer a small presence witness or absence witness over a vague future promise that consumers will “just know what blank means.”

## Harbor consequence
Harbor should make exactly one modest repo/process expansion now:
- add a datacube presence-semantics surface;
- add one specimen around presence witnesses, default shadows, and absence witnesses;
- refresh the load-bearing source register with living sources that keep default-versus-absence discipline visible; and
- keep restatement receipts, semantic front doors, and change-history lanes as the next bigger pressure rather than pretending presence semantics finishes the datacube.

## Still-not-yet decisions
- whether Harbor ever needs one machine-readable shared presence enum;
- whether late-arriving values should later compile into explicit unknown, explicit absence, or restatement families;
- whether neighboring cubes should share one default-shadow vocabulary.

For now, the companion lesson is enough: **separate value from presence, separate absence from inapplicability, and treat default-shadow as a first-class humility note rather than a hidden assumption.**
