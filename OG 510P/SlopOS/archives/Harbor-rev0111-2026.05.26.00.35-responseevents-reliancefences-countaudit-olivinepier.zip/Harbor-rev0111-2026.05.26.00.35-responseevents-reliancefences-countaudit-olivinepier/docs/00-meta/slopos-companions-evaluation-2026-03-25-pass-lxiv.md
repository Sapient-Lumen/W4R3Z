# SlopOS / companions evaluation — pass LXIV

This pass asks a design-phase datacube governance question: if Harbor starts earning real downstream consumers before SlopOS freezes its own broader architecture, how does Harbor avoid over-contracting too early? The answer is to copy the companions’ **explicit small surfaces** and combine them with tiered promises.

## What the companions teach this pass
- **SlopOS** remains the strongest teacher because its boundary-index contract and boundary-singleton contract both force unstable semantic surfaces to stay explicit, enumerated, and same-revision maintained. Harbor should copy that habit into datacube promises: a lane should not imply shape, semantics, assertions, and service guarantees all at once unless those tiers are explicitly named.
- **SlopOS** also keeps leaning on `v0` posture docs instead of fake permanence. That is a good fit for a tiered contract card: Harbor can say a lane is published for shape while still candidate for richer meaning or assertion posture.
- **Foundry** already teaches promotion-candidate and stability-lane discipline. That makes it a good nearby model for **tiered stability**: some exported facts can be visible and useful while still clearly labeled candidate.
- **Ward** is the best reminder that repeated numeric surfaces need explicit temporal and derivative posture. Harbor should therefore keep assertion/freshness/rate-style promises in a neighboring assertion plane instead of flattening them into row meaning.
- **Steward** keeps proving that receipts and reviewed anchors matter more than implementation glamor. Harbor should borrow that for consumer-obligation slices: a consumer pin should say exactly what it depends on instead of gesturing at one giant public lane.

## Harbor consequence
Harbor should make exactly one modest repo/process expansion now:
- add a datacube contract-tiers surface;
- add one specimen around contract-tier cards, assertion planes, and consumer-obligation slices;
- refresh the source register with living sources that shape contract/assertion/consumer-slice hygiene; and
- keep restatement, semantic-front-door, and change-history pressure queued rather than pretending the contract story is now complete.

## Still-not-yet decisions
- whether assertion-plane definitions should ever be first-class Harbor cards instead of repo/process annotations;
- whether consumer-obligation slices should remain prose/JSON notes or later gain a generated machine-readable form;
- whether service/freshness tiers deserve separate lifecycle treatment from semantic tiers once Harbor has real operational consumers.

For now, the repo/process lesson is enough: **name which tier is actually promised, keep verification smaller than meaning, and let consumers pin only the slice they truly use.**
