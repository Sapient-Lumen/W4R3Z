# Datacube option reservations

This file is a **watchlist**, not a schema, ADR, registry, or commitment. It exists because the datacube is still in design phase and the outside world contains many good ideas that Harbor should remember without freezing too early.

## Rules for this surface
- A reservation is not a decision.
- A reservation must stay smaller than row meaning, lane truth, and published contract truth.
- A reservation must not smuggle a chosen warehouse, semantic layer, stream processor, table format, assertion engine, or sidecar registry.
- A reservation can be promoted only after at least one specimen demonstrates the pressure and the relevant source/register/ledger surfaces are refreshed in the same revision.
- A reservation can be deleted if it stops pulling its weight.

## Reservation cards

### OR-001 — observation component frame
- **Borrowed idea:** observations composed from dimensions, measures, and attributes.
- **Why interesting:** gives Harbor a compact way to discuss base grain and component roles without inventing a giant ontology.
- **Why not decided:** Harbor does not yet know whether its exchange exports need RDF-shaped, relational, JSON, or table-format expression.
- **Promotion trigger:** two specimens need cross-engine exchange where component roles prevent ambiguity that existing grain/measurement/conformance docs cannot handle.
- **Anti-counterfeit rule:** component vocabulary never proves conformance, additivity, exactness, or currentness by itself.

### OR-002 — semantic-model export receipt
- **Borrowed idea:** entities, dimensions, measures, metrics, and join relationships compiled into a semantic-layer or BI-facing model.
- **Why interesting:** consumers will eventually want named exports that can be queried safely.
- **Why not decided:** a semantic layer can easily become a false constitution for still-moving row meaning.
- **Promotion trigger:** one repeated consumer export needs a stable receipt naming inputs, joins, additive rights, freshness basis, and refusal cases.
- **Anti-counterfeit rule:** the export is derived; canonical Harbor meaning remains in the review surfaces and specimens.

### OR-003 — derived-view receipt
- **Borrowed idea:** a versioned view definition that stores metadata and dialect representation but owns no data.
- **Why interesting:** Harbor will likely need reusable lenses over published lanes.
- **Why not decided:** view metadata can impersonate a lane if base cut, invalidation, and dialect limits are hidden.
- **Promotion trigger:** two derived views need stable publication across revisions without copying source rows.
- **Anti-counterfeit rule:** every view receipt names base cuts, dialect/runtime, lineage inputs, freshness basis, and invalidation rules.

### OR-004 — statistics/blob sidecar
- **Borrowed idea:** separate blobs for sketches, indexes, cardinality estimates, histograms, and other metadata.
- **Why interesting:** sidecars can support planning, quality review, and approximate answers without mutating rows.
- **Why not decided:** a universal sidecar registry would be premature and could overpromise exactness.
- **Promotion trigger:** at least one specimen needs a retained sketch or statistic that is reused across rollups and cannot be represented as an ordinary lane value.
- **Anti-counterfeit rule:** sidecars are optional evidence; absence is allowed, and presence never upgrades the base contract silently.

### OR-005 — namespaced metadata facet
- **Borrowed idea:** atomic, schema-url-backed facets attached to jobs, datasets, runs, or lanes.
- **Why interesting:** facets offer a way to add metadata without growing a monolith.
- **Why not decided:** facet sprawl can hide incompatible meanings behind namespace gloss.
- **Promotion trigger:** three unrelated metadata additions need extension without changing core Harbor cards.
- **Anti-counterfeit rule:** facet namespaces must declare owner, version, stability ring, and what they cannot prove.

### OR-006 — row-lineage receipt
- **Borrowed idea:** source sequence / row identifier metadata that helps trace rows through changes.
- **Why interesting:** debugging restatements, deletes, and cross-cut evolution may need scoped row traces.
- **Why not decided:** row IDs are especially prone to counterfeit universal identity.
- **Promotion trigger:** one restatement or change-history specimen cannot explain row survival/split/delete behavior without a scoped lineage receipt.
- **Anti-counterfeit rule:** row-lineage receipts are scoped to a source/cut/evolution family and do not claim cross-system identity.

### OR-007 — watermark / frontier witness
- **Borrowed idea:** event-time progress markers and frontiers that say how far a source believes it has processed.
- **Why interesting:** freshness and late-data posture need more than one ambient timestamp.
- **Why not decided:** watermarks can be misread as proof that old facts are final.
- **Promotion trigger:** a streaming or late-arrival specimen needs explicit progress, lateness, and restatement behavior.
- **Anti-counterfeit rule:** a frontier is a source-scoped progress claim, never a timeless closure guarantee.

### OR-008 — assertion compiler target
- **Borrowed idea:** declarative data-quality assertions compiled to tests, monitors, or checks.
- **Why interesting:** Harbor wants portable checks without choosing one data-quality engine.
- **Why not decided:** assertion DSLs can collapse promise, evidence, consequence, and waiver posture.
- **Promotion trigger:** two assertion surfaces need the same reviewed intent compiled to different runtimes.
- **Anti-counterfeit rule:** compiler targets verify observed evidence; they do not define row meaning.

### OR-009 — schema-transform receipt
- **Borrowed idea:** explicit transforms between schema versions with a stable schema URL or version identity.
- **Why interesting:** consumers need to know when a field or metric was renamed, split, dropped, or reinterpreted.
- **Why not decided:** transforms can hide lossy meaning changes behind mechanical compatibility.
- **Promotion trigger:** one consumer-pinned export survives a version change only with an explicit transform and loss note.
- **Anti-counterfeit rule:** transform success is not semantic equivalence unless the receipt says what was preserved and what was lost.

### OR-010 — cube / pivot query affordance
- **Borrowed idea:** `CUBE`, `ROLLUP`, `GROUPING SETS`, and `PIVOT` answer shapes.
- **Why interesting:** these operations can pressure-test grain, additivity, conformance, and exactness claims.
- **Why not decided:** a cube-shaped output is not proof that the base datacube has settled.
- **Promotion trigger:** Harbor uses pivot/cube outputs as recurring review artifacts and needs a standard basis receipt.
- **Anti-counterfeit rule:** query shape never proves safe rollup; the rollup note, fanout fence, exactness class, and conformance lane must do that work.

### OR-011 — sibling-cube borrow card
- **Borrowed idea:** Foundry population/coverage witnesses, Schell supersession receipts, ViewFS materialization boundaries, Helm display-basis cues, Ward tier witnesses, and Steward followthrough receipts.
- **Why interesting:** the sibling cubes already carry disciplines Harbor should not re-invent badly.
- **Why not decided:** copying sibling nouns too early would flatten their ownership and blur Harbor's exchange-membrane role.
- **Promotion trigger:** one repeated Harbor specimen needs a borrowed discipline and can state the boundary to the owning cube.
- **Anti-counterfeit rule:** borrow the discipline, not the authority; cite the sibling and keep Harbor's local meaning narrower.


### OR-012 — promotion proof packet
- **Borrowed idea:** proof obligations, migration gates, bounded export policies, and non-authoritative receipts from SlopOS and sibling-cube process discipline.
- **Why interesting:** Harbor needs a way to collect many good datacube ideas without letting any one of them graduate because it is fashionable, implemented elsewhere, or visually convincing.
- **Why not decided:** proof packets may remain markdown/process surfaces forever; making them machine-readable now would be premature.
- **Promotion trigger:** two or more future noun promotions need the same proof packet fields and can be validated by repo hygiene without choosing a warehouse or semantic layer.
- **Anti-counterfeit rule:** a proof packet is a gate, not authority; it can reject or reserve a noun, but it cannot make weak evidence strong.

## Proof-obligation overlay
Every reservation above now points through `docs/00-meta/datacube-proof-obligations.md` before promotion. The overlay is intentionally stricter than the watchlist: a reservation can remain interesting with little evidence, but promotion needs a specimen, proof packet, source/register refresh, ledger update, and explicit non-decision statement in the same revision.

## Explicit non-decisions
- no chosen warehouse, lakehouse, catalog, semantic-layer, stream processor, BI product, assertion engine, schema registry, or query engine;
- no universal row identity, watermark model, optimizer-stat registry, facet namespace system, or view dialect;
- no claim that SlopOS's datacube is settled; and
- no promotion of any reservation without a specimen, refreshed sources, ledger entries, and release hygiene in the same revision.


## Pass LXXVIII semantic-export exercise
Specimen flow 73 exercised the semantic-model export reservation with a public contract subset, freshness basis witness, join/fanout proof, and optional row-lineage sidecar. The result stays a proof/residue checklist, not a promoted semantic layer, contract schema, BI model, or row-identity constitution.


## Pass LXXIX option-reservation cuts
Specimen flow 74 exercises observation exchange receipts, derived-view receipts, sidecar interpretation notes, frontier/watermark witnesses, assertion compiler receipts, and schema transform receipts together. The result is captured in `docs/00-meta/datacube-option-reservation-cuts.md`: each artifact remains useful only while it carries a source basis, owner/non-owner statement, invalidation posture, optionality/refusal rule, and anti-counterfeit tests.

The watchlist remains unpromoted. Harbor gained sharper counterfeit detectors, not a new canonical datacube schema.
