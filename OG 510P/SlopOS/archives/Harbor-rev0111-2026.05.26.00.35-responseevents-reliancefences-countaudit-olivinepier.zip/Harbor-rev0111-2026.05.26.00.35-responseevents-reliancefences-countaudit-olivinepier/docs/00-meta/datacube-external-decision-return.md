# Datacube external decision return and adoption hygiene

**Status:** design-phase review surface for `rev0092`; not an ADR, schema, authority hierarchy, compliance system, appeal court, regulator workflow, source-owner ticketing model, public status-page product, transparency-log policy, sealed-finding protocol, remediation tracker, or final SlopOS datacube constitution.

## Why this exists

`rev0091` let Harbor prepare and send bounded handoff packets to source owners, auditors, regulators, coordinators, and reviewers. `F087` applies the return pressure: outside parties may answer.

That sounds like closure, but it is usually not closure. A source owner may partially accept a challenge. An auditor may find that a non-use claim is unsupported. A regulator-facing reviewer may issue a sealed-only determination. An appeal outcome may change public copy without deleting historical correction evidence. A finding may expire, be withdrawn, be superseded, or conflict with another finding.

The safe stance is:

> External findings are imported claim packets. Harbor may adopt, refuse, narrow, or quarantine them only through a separate local adoption note.

## Design rule

Do not let an outside answer skip the membrane.

- `source owner says fixed` is not `Harbor verified fixed`.
- `auditor says unsupported` is not `actor acted in bad faith`.
- `regulator-facing reviewer confirmed sealed basis` is not `public may see sealed evidence`.
- `recommended correction` is not `mandated correction`.
- `mandated correction` is not `implemented correction`.
- `appeal sustained` is not `old evidence deleted`.
- `finding expired` is not `finding false`.
- `finding logged` is not `finding current`.

## States under observation

These are composable labels, not a final state machine.

| State | Meaning | Counterfeit to avoid |
| --- | --- | --- |
| `finding_received` | outside response arrived for a named subject | adopted truth |
| `finding_partial` | some claims accepted, some rejected, some unanswered | clean closure |
| `finding_conflicts` | comparable findings disagree after scope normalization | one source automatically wins |
| `finding_not_comparable` | subject/window/audience/method differ enough that conflict is not established | contradiction theater |
| `finding_sealed_only` | basis exists only in restricted evidence lanes | public proof |
| `finding_recommended_correction` | outside party recommends public/source change | mandate or implementation |
| `finding_mandated_correction` | outside authority says a correction is required for its scope | universal legal/compliance truth |
| `finding_expiring` | finding has a recheck/expiry window | false after deadline |
| `finding_expired` | finding no longer supports current posture without renewal | disproven or erased |
| `finding_adopted_with_limits` | Harbor uses part of finding for named local effect | global adoption |
| `finding_refused_locally` | Harbor declines local effect and records why | outside party irrelevant or wrong |
| `appeal_outcome_received` | appeal result returned with scope and remedy | historical evidence rewritten |
| `public_copy_updated_after_review` | public text/artifact changed because of outside review | source data changed or old copy recalled |
| `unsafe_to_adopt` | adoption would overclaim authority, leak sealed evidence, or confuse scope | hiding or denial |

## Candidate process handles

These handles are watchlist vocabulary, not promoted schema.

### `external_finding_return_receipt`

A receipt for an outside source-owner, auditor, regulator-facing reviewer, coordinator, or appeal-body response.

Candidate fields:

- finding id, source handoff/escalation id, issuer/role, authority basis, received time, subject artifact, source cut, affected public copies, payload digest, label digest, decision/status challenged, and response class;
- open basis, sealed basis, withheld basis, handling labels, expiry/recheck posture, public-safe summary, and allowed local uses;
- response classes: receipt-only, partial finding, accepted, rejected, cannot assess, unsupported, contradicted, out-of-scope, recommended correction, mandated correction, appeal sustained, appeal denied, superseded, withdrawn, expired, or unsafe-to-disclose.

### `finding_scope_normalization_note`

A note that normalizes subject, window, audience, method, and evidence lane before treating two outside answers as comparable.

Candidate fields:

- compared findings, subject ids, source/public cuts, artifact digests, label digests, actor/audience scope, time window, method, evidence lane, authority basis, and comparable fields;
- result: comparable, partially comparable, not comparable, missing scope, missing method, missing digest, or unsafe-to-compare;
- non-promise: normalization does not select a winner.

### `authority_conflict_map`

A small map for source-owner/auditor/regulator/reporter findings that disagree after normalization.

Candidate fields:

- disputed claim family, conflicting findings, exact fields in conflict, common evidence, sealed evidence boundaries, current public effect, interim safe wording, pending action, and local adoption state;
- conflict outcomes: unresolved, local adoption paused, local narrow adoption, sealed review requested, public copy warning narrowed, public copy warning widened, or refused.

### `finding_adoption_note`

A separate Harbor-local note saying what, if anything, Harbor does with the outside finding.

Candidate fields:

- finding id, local adopter, adoption reason, proof obligations satisfied, proof obligations failed, local effect, public-copy effect, consumer-guidance effect, historical-evidence effect, expiry, recheck, and reversal triggers;
- adoption states: no local effect, adopted as evidence, adopted for public wording, adopted for correction task, adopted for warning/cooldown, adopted with sealed-only basis, refused, quarantined, or pending.

### `external_correction_instruction_receipt`

A receipt for mandated or recommended correction instructions returned by an outside party.

Candidate fields:

- instruction id, issuer, authority basis, scope, subject artifact, public copy, labels/cells/summaries/citations affected, instruction type, deadline, grace window, evidence required, implementation status, appeal posture, and public-safe wording;
- distinction: mandate, recommendation, request for clarification, advisory note, non-binding preference, or source-owner proposal.

### `sealed_finding_expiry_note`

A note that sealed, auditor-only, or regulator-facing findings can expire as current support.

Candidate fields:

- sealed finding id, sealed manifest id, allowed operations, original verifier/result, public-safe conclusion, expiry time, renewal basis, revoked/withdrawn status, stale-currentness effect, retained historical effect, and unsafe-to-rely copy;
- anti-counterfeit rule: expiry removes current support; it does not erase the historical fact that the finding existed.

### `appeal_outcome_receipt`

A small receipt for appeals that change warning scope, public copy, cooldown, sunset, or adoption posture.

Candidate fields:

- appeal id, challenged decision, outcome, remedy, public-copy changes, unchanged historical evidence, sealed evidence references, stay posture, onward appeal window if any, and local adoption note;
- non-promises: sustained appeal is not memory hole; denied appeal is not proof of bad faith; partial appeal is not universal resolution.

### `public_copy_update_after_review_note`

A note for post-review public copy changes.

Candidate fields:

- public copy id, old copy id, successor id, relation, source cut, review/finding basis, changed labels/summaries/citations, unchanged evidence, stale-copy warnings, cache/catalog propagation needs, and consumer-safe copy;
- relation options: revised, corrected, superseded, narrowed warning, widened warning, restored, historical-only, unsafe-for-new-use, or explanatory-only.

## Anti-counterfeit checks

- If a finding lacks subject, issuer, authority basis, scope, evidence lane, and expiry/recheck posture, it is not ready for local effect.
- If a source-owner partial acceptance is displayed as full repair, owner speech has replaced proof.
- If an auditor's unsupported finding is displayed as harm, fault, or misuse, a verification result has become accusation.
- If a regulator-facing determination is displayed as universal compliance, the scope boundary has been erased.
- If sealed-only basis is summarized as public proof, the redaction lane has failed.
- If recommended correction and mandated correction use the same public wording, Harbor has imported authority without a receipt.
- If an appeal outcome changes the public copy but deletes prior correction anchors, it creates a memory hole.
- If an expired finding is treated as false, expiry has counterfeited refutation.
- If an expired finding is treated as current, retained history has counterfeited freshness.
- If conflicting findings are ranked by actor prestige before scope normalization, Harbor has promoted an authority hierarchy.
- If a public copy updates after review without a successor relation and label digest, users cannot tell whether data, labels, interpretation, or status changed.

## Minimum proof obligations before any promotion

A candidate external-decision-return noun must show at least these before it graduates from process residue:

1. It can name the finding issuer, authority basis, subject, cut, window, audience, evidence lane, public-safe summary, and expiry/recheck posture.
2. It can separate outside response, Harbor-local adoption, public-copy change, consumer guidance, historical evidence, and correction implementation.
3. It can normalize scope before declaring conflict, and it can say `not comparable` without pretending contradiction.
4. It can distinguish mandated, recommended, advisory, proposed, and refused corrections.
5. It can carry sealed-only basis without public leakage and without treating hidden evidence as public proof.
6. It can represent appeal outcomes without memory holes and without automatic trust reversal.
7. It can expire or withdraw current reliance while preserving historical receipts and non-promises.

## Deliberate non-promotions

This pass does **not** promote:

- external decision ingestion schema;
- finding-adoption API;
- authority precedence hierarchy;
- source-owner/auditor/regulator trust ranking;
- legal or compliance workflow;
- appeal court or tribunal;
- correction-implementation tracker;
- sealed finding protocol;
- transparency-log dependency;
- public status-page product;
- VEX/CSAF profile;
- in-toto predicate;
- SCITT receipt requirement;
- source-owner ticketing workflow;
- reputation model;
- enforcement ladder;
- final SlopOS datacube shape.

## New pressure queued

After `F087`, the next seam is external correction implementation and post-decision monitoring: mandated/recommended corrections, deadlines, partial implementation, recheck receipts, reopened appeals, jurisdiction or audience splits, stale public surfaces after an adopted finding, and implementation evidence that must remain smaller than compliance or universal repair.
