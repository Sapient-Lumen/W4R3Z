# Research synthesis — 2026-05-13 pass LXXXII

Question: how should Harbor pressure-test `F077` — redacted replay bundles, access-controlled frozen-answer packets, auditor verification requests, consumers who may see aggregates but not replay payloads, and source-lock drift — without promoting a public answer-pack API, universal proof-bundle format, disclosure engine, verifier service, privacy stack, or final SlopOS datacube constitution?

## Result of this pass
The strongest next move is to split **verification**, **disclosure**, and **authority**.

A historical answer may be:

- visible to a consumer as an aggregate;
- verifiable by an auditor through a redacted or derived proof packet;
- replayable only by an operator holding sealed payload authority;
- explainable through digests, policy/source locks, and run receipts;
- or refused because the proof would reveal suppressed data or because the verifier basis drifted.

This pass therefore adds:

- `docs/00-meta/datacube-replay-evidence-access.md` — a compact review surface for redaction cuts, verifier tickets, audience-bound evidence views, source-lock drift, sealed replay bundles, and proof-without-disclosure posture; and
- `docs/30-architecture/specimen-flow-77-replay-evidence-redaction-verifier-boundaries.md` — a concrete specimen covering a redacted replay bundle, an access-controlled frozen answer, an auditor verification request, aggregate-visible/raw-hidden consumer posture, ticket expiry/revocation, and source-lock drift.

This closes `F077` while preserving the design-phase stance: Harbor can say which evidence a party may see, which evidence can be verified without disclosure, and which request must be refused without choosing a proof system or replay service.

## External lessons folded into this pass
1. **Selective disclosure is a shape, not a Harbor commitment.** W3C Verifiable Credentials and BBS derived proofs show that a holder can present machine-verifiable claims while revealing only selected statements. Harbor should steal the separation between base proof, derived proof, and verifier presentation, but not adopt VC/BBS as the datacube substrate.

2. **Redaction starts before capture.** OpenTelemetry's sensitive-data guidance says the best prevention is not collecting sensitive data in the first place, then using processors to remove, hash, filter, or redact what still appears. Harbor should not treat redaction as a cosmetic output filter over unlimited replay payload capture.

3. **PII/confidentiality risk is contextual.** NIST SP 800-122 frames PII protection around inappropriate access, use, and disclosure, with context-based impact levels. Harbor should let the same frozen answer have different evidence views for consumer, operator, source owner, auditor, or nobody.

4. **De-identification is governance, not masking.** NIST SP 800-188 distinguishes de-identification as disclosure-risk reduction with governance, review models, and re-identification risk, not simple masking. Harbor should never call a redacted replay bundle "safe" merely because raw identifiers were blanked.

5. **Attestations bind claims to subjects and materials.** in-toto attestations are useful because they make verifiable claims about production steps and materials/products. Harbor should steal subject/material/predicate discipline for proof packets, while remembering that a signed packet is still not a local approval verdict.

6. **Transparency logs witness bytes and events, not policy truth.** Sigstore Rekor provides immutable/tamper-resistant metadata logs and inclusion/integrity verification. Harbor should steal the idea of anchoring exact proof artifacts or digests without treating log inclusion as semantic approval.

7. **Policy engines know drift.** OPA decision logs include policy, input, bundle metadata, and masking hooks; OPA signed bundles verify policy integrity before activation; Cedar validates policies against application schemas; Biscuit supports offline attenuation and decentralized verification. Harbor should require source-lock and policy-lock evidence for verifier packets instead of letting the current evaluator silently prove an old answer.

8. **SlopOS already separates proof bundles, observation export, and replay sensitivity.** The included SlopOS archive treats replay bundles as sensitive, routes export through explicit observation policy, keeps proof-bundle role labels non-authoritative, and uses digest-first/redaction-safe audit payloads. Harbor mirrors that split rather than inventing a datacube-wide proof-bundle constitution.

## New process shape
`docs/00-meta/datacube-replay-evidence-access.md` names seven review handles:

- evidence audience;
- redaction cut;
- sealed replay payload;
- verifier ticket;
- derived proof packet;
- source/policy lock;
- disclosure transcript.

These are not canonical schema objects. They are review vocabulary for specimens, promotion packets, and future SlopOS datacube work.

## Specimen selected
Specimen flow 77 models a public callback datacube slice whose exact historical answer survived as a frozen packet but whose replay evidence contains sensitive raw callbacks, suppressed fields, optional lineage sidecars, and old policy/source locks:

- the consumer may see the aggregate and a minimal frozen-answer label;
- the auditor may verify a redacted proof packet under a time-limited verifier ticket;
- the operator may use sealed replay payloads only under explicit incident authority;
- the source owner may inspect suppressed payload classes, but the ordinary consumer may not;
- the old policy bundle and source lock differ from the current verifier basis;
- and one verifier ticket expires before the review completes.

A naive system would ship the whole replay bundle, call a hash of hidden bytes sufficient public proof, let the current policy engine prove an old answer, treat aggregate visibility as raw-payload visibility, or use a redaction label as proof of de-identification. Harbor refuses those counterfeits.

## Still not decided
- one proof-bundle format, answer-pack format, verifier service, disclosure language, privacy framework, or public API;
- one cryptographic selective-disclosure scheme;
- whether proof packets belong in Harbor, SlopOS, Foundry, Steward, or a shared substrate;
- whether redaction profiles are policy objects, datacube cards, review notes, or downstream export settings;
- whether auditors receive proof packets, sealed enclaves, challenge/response tickets, or only operator-mediated review;
- whether source-lock drift is solved by archived policy bundles, signed source snapshots, equivalence proofs, or refusal.

The deeper lesson is: **proof visibility is a lane, not a property of the answer itself.**
