# Datacube conformance lanes

Purpose: keep Harbor honest that a design-phase datacube can support **cross-lane alignment** without pretending it already owns one universal canonical dimension model.

Design-phase cubes repeatedly get into trouble when they jump too early from “these lanes can sometimes line up” to “there is now one perfect enterprise entity table.”
That leap hides several different realities:
- two lanes may share only a small subset of attributes that truly conform;
- one lane may need a many-to-many or time-bounded bridge before it can line up with another;
- a rollup lane may only need a shrunken subset of a richer base dimension;
- a convenient surrogate or “canonical” identifier may still be only a provisional alias; and
- one consumer may need shared slicing while another still only needs a local dimension.

Harbor should not freeze one universal entity registry now.
It does need one small review surface that stops local keys, bridge mappings, and provisional canonical IDs from counterfeiting fully settled conformance.

## Core rule
A Harbor dimension only counts as shared once Harbor names **what exactly conforms and how**.

Same-looking column names are not enough.
One shared label may align while richer attributes do not.
A bridge can make cross-lane analysis possible while still being weaker than one exact shared dimension.
A convenience surrogate can help downstream joins while still being smaller than settled identity truth.

Harbor therefore needs a compact way to say **whether a lane is local-only, partially conformed, bridged, or only provisionally shadowed by a convenient identifier**.

## Minimal conformance classes (Phase 1)
Harbor should keep the first set small and descriptive rather than pretending every entity needs a universal master-data regime.

1. **local-only**
   - useful inside one lane or producer family only.
   - not yet safe for drill-across or cross-lane joins.
   - strongest when Harbor says it is intentionally local.

2. **conformed subset**
   - a named subset of attributes or rows that genuinely line up across lanes.
   - strongest when Harbor says exactly which attributes/levels conform.
   - may be a shrunken or rollup slice rather than the full base dimension.

3. **bridged conformance**
   - cross-lane alignment depends on an explicit bridge artifact or mapping policy.
   - strongest when Harbor names multiplicity, time basis, exclusivity, and unresolved cases.
   - should stay visibly weaker than an exact shared dimension.

4. **identity shadow**
   - a convenient surrogate, provisional canonical ID, or downstream alias that helps grouping or navigation.
   - may be analytically useful while still being smaller than authoritative entity truth.
   - should not silently become the archive’s final ontology.

These are review classes, not a commitment to one MDM stack, semantic layer, or universal entity catalog.

## Conformance-lane card
Harbor should allow a compact **conformance-lane card** beside a curated lane or shared dimension slice.

The card can say:
- which local key or dimension family the lane starts from;
- whether the lane is local-only, a conformed subset, a bridged conformance, or an identity-shadow convenience surface;
- which attributes/levels are guaranteed to line up across lanes;
- whether the conformance is full-row, attribute-subset, row-subset, or rollup/shrunken only; and
- which downstream drill-across or reuse questions are actually safe.

The point is not to demand one enterprise bus matrix on day one.
The point is to stop weakly aligned labels or provisional IDs from masquerading as settled shared dimensions.

## Bridge witness
Harbor should allow a compact **bridge witness** whenever cross-lane conformance depends on a mapping artifact.

A bridge witness can say:
- which two key families it connects;
- whether the mapping is one-to-one, one-to-many, or many-to-many;
- whether weights or allocation rules are needed;
- which time axis controls the lookup and whether effective/expiration windows matter;
- whether unresolved, split, or merged identities remain; and
- whether the bridge is exact, heuristic, or policy-maintained.

This matters because a bridged lane can still be useful for analysis, but it is weaker than pretending every producer already writes the same shared dimension key.

## Identity shadow note
Harbor should allow a compact **identity shadow note** beside any convenient surrogate or canonical-looking identifier.

An identity shadow note can say:
- whether the identifier is authoritative, derived, imported, heuristic, or review-only;
- whether it is safe for grouping, drill-across, deduplication, or only navigation/debugging;
- whether multiple local identities may currently collapse into one shadow identifier;
- whether one local identity may later split into multiple authoritative entities; and
- which consumers must not treat the shadow as final truth.

This matters because a “canonical_account_id” can be very helpful and still be smaller than the world’s actual identity structure.

## Shrunken conformance slices
Harbor should stay open to **shrunken conformance slices** for aggregate or higher-grain lanes.

A shrunken slice can remain smaller than the base dimension and still say:
- which subset of attributes is preserved;
- which higher grain it serves;
- which rows or members are intentionally excluded; and
- whether it is still safe for drill-across only at that declared level.

Harbor does not need to choose a universal rollup-dimension architecture now.
It should simply leave room for the idea that some aggregate or summary lanes only need a smaller conformed slice rather than the full base dimension.

## What this forbids in Phase 1
- no silently treating same-name columns as fully conformed dimensions;
- no silently treating a bridge table as if it proved one exact settled canonical entity model;
- no silently treating a provisional surrogate or imported canonical-looking ID as final identity truth;
- no silently using a higher-grain/shrunken slice as if it preserved every lower-grain attribute; and
- no forcing Harbor into a premature master-data, semantic-layer, or enterprise-bus implementation stack.

## What this still leaves open
- exact machine schema for conformance-lane cards, bridge witnesses, or identity-shadow notes;
- exact mapping onto dbt semantic models, SQL views, catalog entries, or sibling-cube registries;
- exact governance policy for when a local-only lane graduates into a conformed subset;
- whether Harbor later needs stronger machine checks for bridge multiplicity, unresolved mappings, or shrunken-slice drift.

Harbor only needs the review behavior now: **name what truly conforms, witness every bridge, and keep convenient identities smaller than final truth.**
