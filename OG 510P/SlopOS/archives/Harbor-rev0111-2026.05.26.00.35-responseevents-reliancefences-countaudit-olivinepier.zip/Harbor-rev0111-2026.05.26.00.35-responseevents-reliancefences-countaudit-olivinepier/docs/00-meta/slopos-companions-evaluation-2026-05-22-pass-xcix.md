# SlopOS companion evaluation — 2026-05-22 pass XCIX

**Revision:** `rev0099`  
**Companion:** Harbor relative to SlopOS and sibling cubes.  
**Focus:** mutation triage as boundary-aftercare, not a test dashboard.

## SlopOS fit

SlopOS already pressures Harbor with executable transport and durability evidence: accepted-only append history, checkpoint/resume, truncation, malformed-envelope rejection, and durable request receipts. Harbor's F090 through F093 bundles made those boundary residues checkable. F094 now adds aftercare for the checkers themselves.

The important companion claim is:

> A checker result is another crossing record. It has a source, a version, a policy basis, a scope, and non-promises.

F094 does not fully model checker provenance yet, but it prevents the first common failure: treating a survived mutant, killed mutant, or mutation count as self-explanatory truth.

## Sibling-cube implications

| Cube | Borrowed pressure | Harbor response |
|---|---|---|
| SlopOS | executable evidence can become too trusted once it passes | checker observations get triage packets and non-promises |
| Helm | UI warnings can overclaim certainty | mutation-score/dashboard language remains non-promoted |
| Schell | CLI/tool outputs may hide authority phrases in strings | accepted string values are scanned for forbidden status/authority overclaims |
| ViewFS | canonical paths/order may be stricter than semantic identity | member-label order kills are recorded as canonicality, not domain truth |
| Steward | retry/replay artifacts need pruning and budgets | mutation corpus growth is pruned rather than rewarded |
| Ward | delegated review needs explicit authority | human-review flags are required before promotion packets matter |
| Foundry | classification pins can drift | triage classes are explicit and checked but not promoted as a schema |

## What changed for SlopOS integration

The Harbor checker hardening matters directly for SlopOS-style surfaces. A portal/network crossing can have a valid route, digest, and append record while an accepted explanatory string tries to say "global truth" or "trusted content." F094 makes that a rejected checker state.

This preserves the older Harbor/SlopOS split:

```text
SlopOS proves bounded transport/durability facts.
Harbor refuses to let those facts become broader authority.
```

## Next companion seam

The next seam should be checker provenance and self-attestation:

```text
which checker emitted this observation?
which digest/version/policy did it use?
was the checker run against the fixture it claims?
were guards disabled?
can a checker result be replayed or challenged?
```

That is a natural F095 because F094 has made checker observations load-bearing enough to require their own receipt discipline.

## Non-promotions

No checker registry, CI system, mutation dashboard, test framework, SlopOS integration API, public certification badge, or final datacube shape is promoted in this pass.
