# Datacube derivative repair retention and expiry

F100 adds a narrow pressure surface for evidence after derivative repair propagation has already happened. The question is no longer whether a notice, acknowledgement, quarantine, or repair was observed; it is how long that observation can safely support later status claims.

## Compression

A retention/expiry record is admissible only when Harbor can keep seven facts apart:

1. the repaired derivative or stale derivative subject digest;
2. the repair/acknowledgement/quarantine evidence being retained;
3. the retention policy or local review rule that keeps or prunes it;
4. the clock basis and expiry window;
5. any compaction, tombstone, privacy-minimization, migration, or hold exception;
6. the recheck result or explicit absence of recheck;
7. the current verdict: active-for-window, expired/recheck-required, compacted, held, privacy-minimized, quarantined, superseded by later correction, or refused counterfeit confidence.

The status word attaches to the current evidence state, not to the original repair event. A retained record can remain useful while its repair-currentness expires.

## Safe statuses

- `active_within_retention_window` — repair evidence is still inside its clocked window and may support current repair for that derivative scope only.
- `expired_recheck_required_not_current` — the old evidence remains useful history, but cannot support current repair without a new recheck.
- `compacted_tombstone_retained` — raw material was compacted, but subject and receipt digests preserve review residue.
- `hold_preserves_evidence_not_freshness` — a hold keeps evidence, not freshness, repair, or compliance.
- `superseded_by_new_source_correction` — a later source correction makes the prior repair state stale until rechecked.
- `quarantine_residue_retained_not_repair` — quarantined stale material is contained, not repaired.
- `digest_pointer_only_not_full_evidence` — pruned evidence leaves a pointer, not full proof.
- `stale_recurrence_reopened` — recurrence after expiry reopens warning residue.
- `privacy_minimized_tombstone` — minimization reduces retained material without proving no stale copies exist.
- `scoped_reviewer_note_only` — an expiring reviewer waiver is a note, not a machine result change.
- `refused_counterfeit_retention_confidence` — a candidate collapses retention, deletion, hold, schedule, acknowledgement, or pruning into current repair.

## Hard refusals

Harbor refuses to treat retention as currentness, expiry as repair failure, legal hold as freshness, deletion as repair, compaction digest as full evidence, recheck scheduling as recheck passing, privacy minimization as proof of no stale copies, stale acknowledgement as current acknowledgement, quarantine expiry as repair, or a borrowed retention window as subject-scope authority.

## Research pressure

Records and preservation practice are useful pressure because retained logs and preservation metadata can support review over time without turning archive presence into truth. BagIt fixity pressure keeps retained manifests and tag manifests distinct from payload semantics. PROV pressure keeps invalidation, derivation, and activity records separate from current quality judgments. PREMIS pressure reminds Harbor that preservation events, rights, agents, and significant properties can be carried as metadata while still requiring interpretation. NIST log-retention language is useful specifically because retention is archiving as part of operations, not a semantic upgrade.

## Non-promotion line

This surface does not define a records-management system, legal-hold workflow, privacy-erasure API, retention schedule registry, evidence-vault format, consumer cache API, compliance workflow, or final SlopOS datacube shape. It only records enough evidence to keep repair-currentness from outliving its scoped proof window.
