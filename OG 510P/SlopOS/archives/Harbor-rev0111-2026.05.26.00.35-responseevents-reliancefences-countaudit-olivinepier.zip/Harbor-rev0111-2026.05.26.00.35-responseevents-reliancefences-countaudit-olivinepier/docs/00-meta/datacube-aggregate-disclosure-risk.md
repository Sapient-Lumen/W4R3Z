# Datacube aggregate disclosure risk

This surface is a **review aid**, not a schema, privacy policy, statistical disclosure-control method, differential-privacy system, query broker, or public API.

It exists because replay-evidence access split visible answers from raw proof. That split creates a new temptation: "the consumer may see aggregates, therefore any aggregate is safe." That is false. Aggregates can leak through small cells, small denominators, dominance by one contributor, structural-zero confusion, differencing across releases, repeated near-neighbor queries, and noisy releases whose privacy parameters are not tracked.

## Stance
- Answerability is not releaseability.
- Exactness is not privacy safety.
- Suppression is an answer mode, not a failure to compute.
- Noise or perturbation is not a privacy proof unless contribution bounds, parameters, mechanism, and composition/accounting are named.
- A public copy should carry its disclosure treatment; stripped labels are a downstream hazard.
- Harbor should refuse, collapse, perturb, or downgrade before leaking the value behind a refusal.

## Release modes for specimens

| mode | meaning | must not infer |
| --- | --- | --- |
| `exact_release_allowed` | exact aggregate may be shown to the audience | safe for every sibling table or repeated query |
| `collapsed_release` | a coarser grouping replaces unsafe fine cells | hidden fine-cell values are recoverable or promised |
| `suppressed_release` | one or more cells withheld or marked | suppressed value is zero, missing, or unimportant |
| `complementary_suppression_required` | extra cells/totals must be withheld to protect a primary suppression | one redacted cell is enough |
| `perturbed_release` | deterministic or stochastic noise/rounding/perturbation applied | exact additivity or exact recompute still holds |
| `dp_candidate` | release claims a differential-privacy-style guarantee only if accounting evidence exists | any noise is DP |
| `budget_exhausted_refusal` | repeated or overlapping query would exceed the release policy | data is absent or the user is blacklisted |
| `unsafe_to_release` | no safe aggregate copy exists under current policy | internal exact answer does not exist |
| `auditor_only_review` | a reviewer may inspect evidence under a ticket | public consumer may see the same evidence |

## Review handles

### Release cell
A compact note about the cell that may be released, transformed, collapsed, or refused.

Minimum fields for review:

- metric and grain;
- grouping keys and hierarchy level;
- answer cut and source cut;
- exactness class before disclosure treatment;
- release mode after disclosure treatment;
- public copy label and safe refusal copy.

### Contributor evidence
A proof note that says what contributor basis was checked without necessarily revealing the contributors.

Candidate fields:

- raw contributor count or hidden contributor-count class;
- effective contributor count if weights, deduplication, or entity bridges are involved;
- denominator basis for rates and percentages;
- whether contributor evidence is exact, estimated, unavailable, or audience-hidden.

### Small-cell guard
A release check for low-count cells or small denominators.

Healthy posture:

- evaluate underlying contributor count, not only displayed weighted estimates;
- treat rates with small denominators as risky even when the percentage is ordinary-looking;
- keep structural zeros separate from suppressed zeros;
- avoid revealing the threshold by producing too-specific refusal text.

### Dominance guard
A release check for magnitude cells where one or a few contributors dominate totals, means, maxima, or ranges.

Healthy posture:

- evaluate dominance before publishing exact totals, top-k, min/max, or ranges;
- treat dominance as different from small count;
- name whether the cell was collapsed, suppressed, perturbed, or auditor-only.

### Sibling-cut set
The set of already-released or candidate releases that can be combined with the new answer.

Healthy posture:

- include same-table totals, margins, rollups, filters, time cuts, provider cuts, and public semantic-export copies;
- test whether a suppressed cell can be solved by subtracting released siblings;
- mark whether complementary suppression, perturbation, or collapse is needed.

### Repeated-query ledger
Process residue that notices when many individually safe questions become unsafe together.

Candidate fields:

- requester/audience class;
- query family and grain;
- source cut or moving-head window;
- overlap basis;
- accounting/budget note if one exists;
- refusal or delay behavior when the pattern becomes unsafe.

### Disclosure-budget note
A compact note that says a release has consumed or would consume a bounded disclosure allowance.

This is deliberately not an authority token. It should not be portable grant memory. It is a review handle for privacy accounting, release throttling, and repeated-query refusal.

### Noise or perturbation receipt
A note that says a public copy differs from the exact answer because of disclosure treatment.

Minimum fields:

- mechanism family if known;
- deterministic versus stochastic posture;
- whether the same cell receives stable treatment across sibling releases;
- parameter/privacy-loss evidence if claimed;
- exactness/additivity consequences;
- whether internal exact answer and public treated answer can both be cited.

### Release/refusal copy
Consumer-facing text that explains the release outcome without leaking the hidden value.

Healthy copy should say:

- whether the answer is exact, collapsed, suppressed, perturbed/noisy, approximate, or refused;
- why in class-level language;
- what coarser alternative is available;
- whether an auditor can request a bounded review;
- which labels must travel with downstream exports.

## Minimum proof obligations before promoting any aggregate-disclosure noun
- State answerability versus releaseability.
- State cell grain, grouping, and source/published cut.
- State contributor-count/denominator/dominance posture without leaking protected values.
- State sibling-cut and repeated-query posture.
- State release mode and disclosure treatment.
- State exactness/additivity/utility consequences.
- State public copy labels and safe refusal language.
- State which evidence is hidden, auditor-only, or source-owner-only.

## Anti-counterfeit checklist
- Aggregate-only is not automatically safe.
- Exact internal answer is not public release permission.
- A low displayed estimate can hide a lower underlying contributor count.
- A harmless-looking percentage can have a dangerous denominator.
- A zero can be structural, rounded, perturbed, suppressed, absent, or truly zero.
- Suppressing one cell without margins/siblings review can disclose the cell anyway.
- Noise without mechanism/accounting evidence is not differential privacy.
- Perturbation can break exact additivity, equality checks, and downstream reconciliation.
- Repeated near-neighbor queries can leak more than one query.
- A refusal must not reveal the hidden value by being too specific.
- Public BI/export copies must preserve release labels; a stripped label is a new risk.

## Promotion triggers
This vocabulary should remain process residue until repeated specimens show Harbor needs a durable artifact. Possible triggers:

- a real consumer needs public aggregate release with small-cell or dominance suppression;
- a real downstream export strips suppression/noise labels;
- repeated-query pressure appears across semantic exports or dashboard filters;
- SlopOS promotes durable observation-export privacy accounting or aggregate-release policy;
- a regulator/auditor asks for release evidence that cannot be represented as ordinary exactness or redaction notes;
- suppressed/noisy public answers need restatement or retirement with historical copy hygiene.

## Explicit non-decisions
This pass does not promote:

- a statistical disclosure-control method;
- a k-anonymity or threshold policy;
- a differential-privacy mechanism or accountant;
- a disclosure-budget service;
- a query broker;
- a public aggregate-release API;
- a privacy label ontology;
- a BI/export governance product;
- a de-identification standard;
- or final SlopOS datacube shape.
