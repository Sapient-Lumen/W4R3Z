# Datacube crossing records, scope algebra, and warning lifecycle guards

**Status:** design-phase review surface for `rev0094`; not an ADR, schema, state-machine runtime, scope engine, public status-page product, compliance workflow, deadline service, recheck service, rollback protocol, agent-memory subsystem, browser credential profile, MCP integration, VEX/CSAF profile, in-toto predicate, SCITT dependency, transparency-log policy, or final SlopOS datacube constitution.

## Why this exists

Harbor already has strong public-copy correction hygiene. SlopOS now has stronger executable request evidence. The missing bridge is a minimal crossing/aftermath record that can carry SlopOS-like route and admission evidence into Harbor without letting it become trusted content, compliance, current truth, or global repair.

The counterfeit is easy: a portal accepted a request, so the response is trusted; a correction was published, so the world is repaired; one clean recheck happened, so the warning can be marked resolved; a transparency receipt exists, so the statement is true; an agent saw an invalidation, so future agents are corrected. Harbor must keep all of those claims scoped.

## Two strata

Harbor now names two strata for review purposes:

| Stratum | Owns | Must not own |
|---|---|---|
| **Harbor-Core** | membrane crossing records: request, route, admission, detour, callback, materialization, credential/tool presentation, outcome, aftermath | outside truth, user cognition, durable authority, global identity, compliance |
| **Harbor-PublicCopy** | correction/public-copy lifecycle: adoption, instruction, implementation evidence, publication, propagation observation, recheck, recurrence, warning lifecycle | universal recall, downstream non-use, source-owner truth, legal/compliance status, all-agent memory repair |

This split is a naming aid only. It does not create a package boundary or stable API.

## `CrossingRecord v0` specimen shape

Every new crossing-oriented specimen should be able to emit or reject this shape:

```json
{
  "crossing_id": "harbor-crossing-...",
  "subject": {
    "kind": "public_copy | uri | artifact | credential | tool_result | callback | correction | warning | agent_memory",
    "ref": "...",
    "digest": "...",
    "basis_time": "..."
  },
  "route": {
    "from_membrane": "...",
    "to_membrane": "...",
    "route_family": "browser | portal | mcp | oauth | public_copy | mirror | callback | chooser | credential | agent_cache"
  },
  "admission": {
    "decision": "accepted | rejected | deferred | detoured | degraded",
    "authority_basis": "...",
    "visible_to_user": true
  },
  "scope": {
    "artifact": "...",
    "audience": "...",
    "jurisdiction": "...",
    "surface": "...",
    "time_window": "..."
  },
  "outcome": {
    "class": "materialized | opened | published | corrected | stale_observed | warning_issued | warning_sunset | recheck_failed | contradiction_observed",
    "non_promises": [
      "not_global_truth",
      "not_compliance",
      "not_all_copies_clean"
    ]
  },
  "aftermath": {
    "receipts": ["..."],
    "recheck_window": "...",
    "rollback_or_reopen_triggers": ["..."]
  }
}
```

Minimum review rule: if a packet cannot name subject, route, admission, scope, outcome, and aftermath, it should not be promoted beyond prose residue.

## Scope algebra

Harbor should compare scopes before comparing status words.

```text
same_scope(a, b)             # same artifact/cut/audience/surface/window/evidence lane
narrower_than(a, b)          # a is contained by b and carries no hidden widened claim
overlaps(a, b)               # comparable along at least one axis but not identical
incomparable(a, b)           # axes differ enough that winner-selection is unsafe
supersedes_within_scope(a,b) # a replaces b only inside the named scope
stale_after(a, b)            # b's observation/cut/window is older than a's currentness basis
```

Required refusal: Harbor must be able to say `incomparable` even when two records both use words like `fixed`, `corrected`, `resolved`, `clean`, or `accepted`.

## Public status state machine

Public-copy and correction status must move through named states, not adjectives:

```text
found
→ accepted_for_local_review
→ adopted
→ instructed | recommended | advisory
→ implementation_claimed
→ implementation_evidence_received
→ public_copy_published
→ propagation_observed
→ recheck_clean_for_scope
→ warning_sunset_for_scope
```

Exception branches:

```text
missed_deadline
failed_recheck
contradictory_evidence
rollback_or_reopen
stale_recurrence_after_clean_window
appeal_or_stay
scope_split
warning_reescalated
authority_disputed
incomparable_status_surfaces
```

No state is allowed to imply compliance, user comprehension, all-copy repair, downstream non-use, or agent-memory erasure unless a separate proof obligation names that exact claim and authority.

## Clock basis

Every deadline, recheck, stay, warning sunset, or recurrence decision needs a clock-basis note:

```json
{
  "clock_basis": {
    "deadline_source": "external_order | local_policy | publication_notice | advisory_window",
    "deadline_time": "2026-06-01T00:00:00Z",
    "rendered_local_time": "...",
    "observation_time": "...",
    "publication_time": "...",
    "clock_source": "...",
    "known_skew_or_uncertainty": "...",
    "stay_or_extension": "none | pending | granted | disputed"
  }
}
```

Without this note, Harbor may say `deadline unknown`, not `met`, `missed`, `late`, `stayed`, or `noncompliant`.

## Agent-memory invalidation

Stale public copy can live in agent and model-adjacent surfaces:

```text
retrieval chunk
tool-result cache
conversation summary
agent scratch memory
prompt template
generated explanation
browser preview
MCP resource listing
training/eval fixture
localized or accessible summary
```

Harbor may record invalidation requested, invalidation observed, invalidation failed, or out-of-scope. It must not claim training unlearning, all-agent memory repair, global retrieval currentness, or future-behavior correction without separate evidence.

## Hostile receipt fixture set

New specimens should include at least some of these counterexamples:

```text
receipt with wrong subject digest
receipt copied from a similar artifact
receipt issued after deadline but backdated
receipt with correct artifact but wrong audience
publication receipt without implementation evidence
implementation receipt without propagation observation
clean recheck that hides excluded surfaces
receipt from an authority outside the claimed jurisdiction
label digest stripped during PDF/screenshot/export
prompt-injected correction notice
callback carrying plausible but authorityless metadata
MCP/tool annotation that overstates trust
transparency-log inclusion without semantic validation
```

## Warning lifecycle guard

A public warning may be issued, held, narrowed, re-escalated, or sunset only with:

- subject artifact/cut/digest and warning text digest;
- audience/jurisdiction/surface scope;
- evidence lane and last observation time;
- recurrence or clean-window basis;
- affected stale surfaces and unobserved surfaces;
- safe public wording;
- historical retention posture;
- non-promises.

`warning_sunset_for_scope` means the warning is no longer active for a named scope. It does not mean the underlying fact was false, globally repaired, safe for all audiences, or forgotten.

## Non-goals

No crossing-record schema, scope algebra library, state-machine implementation, clock service, warning status page, deadline tracker, recheck crawler, browser credential stack, OAuth profile, MCP integration, public-copy registry, agent-memory subsystem, transparency log, compliance workflow, reputation model, enforcement ladder, or final SlopOS datacube shape is promoted here.
