# SlopOS / companions evaluation — pass LXXVI

This pass asks a design-phase datacube question rather than a storage-engine question: what should Harbor steal from SlopOS and the sibling cubes now that outside research keeps offering semantic models, derived views, sidecars, watermarks, row lineage, and assertion compilers?

## What SlopOS teaches this pass
- **SlopOS is still design-phase, so Harbor should not pretend it is integrating with a settled datacube.** The right move is to preserve optionality and keep the datacube as reviewable archive vocabulary rather than a chosen warehouse, stream processor, semantic layer, or optimizer sidecar regime.
- **Imported facts must stay smaller than native truth.** SlopOS's current boundary-family discipline repeatedly says that imported provider-local payloads, browser-mediated identity artifacts, external policy hints, and connected-account signals are not portable durable truth. Harbor should apply the same rule to semantic-layer exports, view definitions, statistics blobs, lineage rows, watermarks, and assertion manifests.
- **Family indexes, singleton contracts, and same-revision wiring are process gold.** Harbor should continue stealing the hygiene pattern: when a new datacube idea is only a singleton pressure, label it as such; when it becomes a family, promote it intentionally; do not let stale singleton status or unindexed meaning pins linger.
- **Evidence references beat payload hoarding.** For datacube sidecars, Harbor should prefer compact receipts that say which cut, source, schema, and evidence class shaped an export rather than copying raw tool payloads into canonical meaning.

## What the companion cubes add
- **Foundry** keeps teaching semantic-spine humility: grain, population, coverage, exactness, input cuts, view lenses, and serving lanes are useful only when they stay smaller than native realization. Harbor should borrow this for option reservations: record a promising shape, but demand a specimen before promotion.
- **Schell** keeps teaching supersession and agreed-term discipline. Derived views, semantic exports, schema transforms, and assertion compiler targets should leave version and replacement residue rather than trusting moving-head folklore.
- **ViewFS** keeps teaching materialization boundaries. A view, pivot table, statistics blob, or sidecar reference is not a durable copied object unless the archive says it is.
- **Helm** keeps teaching chooser/display honesty. Dashboard, pivot, or semantic-layer displays should carry basis and refusal cues rather than hiding weak evidence behind polished UI.
- **Ward** keeps teaching tier and resolution honesty. Shared-looking IDs, dimensions, and measures should carry conformance, exactness, and ring/tier posture before cross-lane reuse.
- **Steward** keeps teaching aftermath receipts. Watermarks, late-data exceptions, restatements, and assertion failures need accountable followthrough rather than invisible cleanup.

## Harbor consequence
Harbor should add exactly one new design-phase surface now: `docs/00-meta/datacube-option-reservations.md`. It should be a watchlist, not an ADR. Each reservation should name the borrowed idea, why it is interesting, why Harbor is not deciding yet, a promotion trigger, and an anti-counterfeit rule.

## Still-not-yet decisions
- whether Harbor ever adopts first-class option-reservation cards or only keeps this watchlist as process residue;
- whether derived views, statistics/facet sidecars, watermarks, row-lineage receipts, schema-transform receipts, or assertion compiler targets ever become durable Harbor cards;
- whether SlopOS will later want a table-format, semantic-layer, stream-processing, catalog, or query-engine integration surface; and
- whether any sibling cube's datacube terms should become shared vocabulary rather than cited inspiration.

For now, the companion lesson is enough: **SlopOS remains unsettled, so Harbor should harvest brilliant ideas as option reservations and keep every borrowed helper derived, optional, and specimen-gated.**
