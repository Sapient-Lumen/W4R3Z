# Embryo promotion contract

Purpose: keep every newly promoted Harbor noun cluster explicit, reviewable, and hard to confuse with accidental family growth.

Why this exists:
- Harbor is still in the embryo phase, so a good specimen noun can easily harden into a fake permanent family before enough pressure accumulates,
- sibling work in SlopOS shows that **singleton-quality drift** is real: a seam can keep an official label long after the archive has stopped saying why it is still small,
- Harbor therefore needs one explicit rule that makes design-phase restraint inspectable without inventing a giant new schema or governance surface.

This doc does **not** add a new Harbor product surface.
It is an archive-hygiene contract for embryo vocabulary growth only.

## Contract

Every revision that promotes or seriously pressure-tests a new Harbor noun cluster must:
- keep the move tied to one concrete specimen, research pass, or companion-cube evaluation in the same revision,
- include one explicit anti-regrowth rule saying what the new cluster is still **smaller than**,
- say why **no broader multi-doc family exists yet** if the cluster is still being carried as a narrow specimen move,
- update the ledgers and the briefing surfaces in the **same revision** so the archive does not grow hidden side-lore,
- and refuse to let a second closely related cluster appear without either compressing it back down or paying for explicit structure in the **same revision**.

The point is not to freeze embryo nouns forever. The point is to keep every widening step deliberate, inspectable, and reversible while the datacube is still young.

## Non-goals

- This contract does **not** decide which candidate nouns should become permanent today.
- This contract does **not** create a new registry, schema, or promotion committee.
- This contract does **not** replace `design-splits-and-non-decisions.md`; that document remains the broader archive map of what stays split and what stays undecided.

## Review rule

Before retaining or promoting a new Harbor noun cluster, answer these questions in order:
1) Is this actually one narrow seam that earned a specimen, or the start of a broader family that should not pretend to stay small?
2) Does this revision state what the cluster is still **smaller than**?
3) Does this revision say why **no broader multi-doc family exists yet**, if that is still the claim?
4) If a second closely related seam now exists, did the archive either compress the pair or add explicit structure in the **same revision**?

If the answer to (1) through (4) is yes, keep the specimen, ledgers, and briefing surfaces aligned in that same revision.
