# SlopOS / companions evaluation — pass LXV

This pass asks a design-phase datacube hygiene question: if Harbor starts changing its published lanes while SlopOS and the sibling cubes are still actively discovering their own boundaries, how does Harbor stop one rename, recalculation, or backfill from silently mutating a promise? The answer is to copy the companions’ **explicit review surfaces** and add a small change-class / verdict seam.

## What the companions teach this pass
- **SlopOS** remains the strongest process teacher because its boundary-index and singleton contracts force unstable semantic surfaces to stay explicit, enumerated, and same-revision maintained. Harbor should copy that posture for lane changes: a change should not inherit a compatibility story by implication.
- **SlopOS RFC-0097** in the uploaded bundle is a useful adjacent lesson: rollback safety for mutable state is not assumed; compatibility and rollback barriers are declared explicitly. Harbor should steal the attitude even though it is not building an update system: a breaking lane rewrite deserves an explicit verdict and possibly a successor/history barrier, not a hand-wave.
- **Foundry** keeps teaching promotion-candidate discipline. That makes it a good nearby model for **bridge windows** and **successor-required** verdicts: a useful candidate can coexist with the current published lane while consumers migrate.
- **Ward** keeps teaching temporality and derivative honesty. Harbor should therefore keep **shadow diff evidence** smaller than canonical meaning instead of letting a green diff screenshot or sampled metric override the actual review surface.
- **Steward** keeps proving that small receipts beat folklore. Harbor should borrow that for compatibility work: deprecation receipts, promotion receipts, and retirement reservation notes should remain compact but explicit.

## Harbor consequence
Harbor should make exactly one modest repo/process expansion now:
- add a datacube change-classes surface;
- add one specimen around change-class cards, compatibility verdicts, bridge windows, and shadow diffs;
- refresh the source register with living sources that shape rename/bridge/version/deprecation hygiene; and
- keep restatement, semantic-front-door, and change-history pressure queued rather than pretending the compatibility story is complete.

## Still-not-yet decisions
- whether retirement reservation notes should ever become a first-class machine-readable registry;
- whether shadow diffs should later compile into a repeatable test harness;
- whether alias bridges belong in Harbor cards, generated artifacts, or both once real consumers exist.

For now, the repo/process lesson is enough: **classify the change, record the verdict, and never let a design-phase datacube smuggle breaking semantics through a schema-shaped patch.**
