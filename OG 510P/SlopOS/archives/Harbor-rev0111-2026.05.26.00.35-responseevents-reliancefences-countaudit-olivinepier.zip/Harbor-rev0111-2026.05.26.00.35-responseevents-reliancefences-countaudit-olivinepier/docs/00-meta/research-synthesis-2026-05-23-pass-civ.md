# Research synthesis — 2026-05-23 pass CIV

This pass pressure-tests what happens when a source correction arrives after consumer-side derivatives have already multiplied. F098 made derivative identity, transform scope, and cache/index/sync non-authority explicit. F099 asks how correction, invalidation, propagation, acknowledgement, and repair should travel without making delivery or acknowledgement impersonate repair.

## External pressure borrowed

- W3C PROV keeps revision/derivation tied to entities, activities, and agents. Harbor borrows the shape but refuses to let a revised derivative become the original source or global downstream truth.
- W3C Web Annotation keeps body, target, selector, motivation, and provenance separable. Harbor uses that separation to permit digest-bound repair notes while rejecting annotation-author authority and status rewrites.
- BagIt keeps fixity and transfer verification payload-agnostic. Harbor borrows the manifest/checksum discipline for derivative repair material while refusing to treat a valid transfer as semantic repair.
- OCI subject/referrers pressure keeps links to a subject useful without saying the subject is trusted, current, or reached. Harbor uses the same boundary for re-export supersession and parent/child maps.
- Linked Data Notifications and ActivityPub make delivery and inbox/outbox patterns visible. Harbor borrows the message-flow pressure while refusing delivery-as-read, read-as-applied, or broadcast-as-complete-reachability.
- HTTP Problem Details gives Harbor a useful error-shape reminder: machine-readable failure reasons are helpful only when they stay scoped and do not become workflow closure or compliance.

## Harbor conclusion

Derivative repair needs a five-part chain: corrected source digest, derivative inventory, propagation or invalidation action, acknowledgement posture, and post-action derivative material state. The narrowest accepted record may say “notice acknowledged, not repaired” or “quarantined unreached,” and that is a success because it preserves uncertainty instead of faking repair.

## Speculative seam

The next seam is repair-evidence retention and expiry. If Harbor can say a derivative was repaired today, it still needs to say how long the repair evidence is usable, what happens when the corrected source changes again, and whether stale repair receipts should be rechecked, archived, compacted, or forgotten. That is F100 pressure, not a repair attestation profile yet.
