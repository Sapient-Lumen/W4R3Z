# Research synthesis — 2026-05-22 pass C

## Seam

F095 borrows from software-supply-chain provenance and policy-decision auditing, but it keeps the borrowed forms smaller than Harbor authority.

The useful pattern is not “signed means trusted.”  The useful pattern is that a result should carry enough evidence about the procedure that produced it: source identity, policy or checker identity, input digest, environment or bundle context, invocation, and review boundary.

## Source pressure

- SLSA provenance is explicitly about verifiable information describing where, when, and how an artifact was produced.  Harbor borrows the where/when/how shape for checker observations, but refuses to turn that into correctness or dependency-cleanliness.
- SLSA build levels distinguish mere provenance existence from stronger tamper resistance.  Harbor borrows that humility: source digest and self-test existence are evidence, not a trust root.
- OPA decision logs include policy, input, bundle metadata, and other audit/debug context.  Harbor borrows the policy/input/bundle-context idea for checker observations.
- OPA signed bundles show that policy integrity evidence is separable from the policy decision itself.  Harbor therefore records checker source and fixture pairing separately from subject-bundle truth.
- GitHub artifact attestations produce signed claims about build provenance and require verification of signature, timestamp, and signer identity for meaningful security benefit.  Harbor borrows the “verification context travels with the claim” posture, not the product workflow.
- Reproducible Builds guidance says the build environment should be defined or recorded.  Harbor borrows that as a future seam for release-package/bootstrap evidence, not as a reason to claim reproducible releases now.

## Design consequence

Checker observations now need their own aftermath record:

```text
which checker source
which harness source
which fixture digest
which guard families enabled
which invocation
which self-test receipt
which reviewer override boundary
what this observation does not prove
```

This makes it harder for Harbor to launder a stale checker run into fresh confidence.

## What changed

F095 adds a deterministic checker-provenance bundle across the five prior executable checkers, plus hostile cases for disabled guards, stale fixture/checker pairings, missing self-test receipts, and unscoped reviewer overrides.

## What remains missing

The new bundle intentionally excludes recursive self-attestation of its own checker.  F096 should inspect release packaging, archive index drift, build-environment capture, deterministic zip production, and bootstrap trust without promoting release attestations into a trust root.

## Source anchors

`EXT-SLSA-PROVENANCE-V1`, `EXT-SLSA-VERIFYING-ARTIFACTS-2026`, `EXT-OPA-DECISION-LOGS-2026`, `EXT-OPA-BUNDLES-2026`, `EXT-GITHUB-ARTIFACT-ATTESTATIONS-2026`, `EXT-GITHUB-ATTESTATION-VERIFY-2026`, and `EXT-REPRODUCIBLE-BUILDS-RECORDING-2026`.
