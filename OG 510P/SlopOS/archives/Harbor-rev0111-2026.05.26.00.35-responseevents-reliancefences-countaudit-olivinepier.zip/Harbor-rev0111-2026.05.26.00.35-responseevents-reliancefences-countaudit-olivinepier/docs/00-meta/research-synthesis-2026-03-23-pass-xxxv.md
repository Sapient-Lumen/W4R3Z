# Research synthesis — pass XXXV

This pass keeps Harbor narrow and learns one more thing from support lists, capability/config flags, and transport/chooser hints: **advertised support can shape a crossing without settling which method was actually negotiated or admitted here.**

## Outside lessons
1. **Support listings can be partial on purpose.**  
   RFC 8414 says `scopes_supported` is only RECOMMENDED, and servers MAY choose not to advertise some supported scope values even when they publish the parameter. Harbor should steal the humility: a support advert can be useful and still not be a complete map of what will work.

2. **Absence is not always absence.**  
   OpenID Connect Discovery makes many support declarations optional and assigns defaults when omitted. For example, if `grant_types_supported` is omitted, the default is `["authorization_code", "implicit"]`, and other booleans likewise default when absent. That is a very good anti-folklore lesson: “not listed here” and “not supported here” are not always the same sentence.

3. **Hints are not requirements.**  
   WebAuthn Level 3 says hints are not requirements and do not bind the user agent, and that transport and other enum-like hints can carry unknown values that clients must ignore. Harbor should therefore treat method/transport hints as chooser-shaping pressure, not negotiated-method truth.

4. **Capability/config flags can shape candidate space without becoming outcome truth.**  
   FedCM’s IdP config can declare things like `supports_use_other_account`, account labels, and multiple config files bound to the same account/login endpoints. Those flags materially shape what the browser will show or hide, but they still do not tell Harbor which account, route, or finish method actually won.

## Resulting Harbor move
Do not decide yet whether the durable nouns are exactly `support advert`, `method hint`, `negotiation witness`, and `unsupported-here honesty`, or whether later pressure compresses some of them behind smaller route/admission surfaces.
For now, keep them alive as specimen nouns and demand that they improve:
- one OAuth/OIDC specimen where support lists and defaulted capability fields shape the crossing without masquerading as a complete usable-now contract;
- one WebAuthn specimen where hints/transports meaningfully narrow or guide the crossing without binding the final chosen path;
- and one FedCM specimen where config flags and account labels shape browser UI/candidate space without becoming portable account/session or final selection truth.

## Fresh ideas worth stealing
- **support advert** — compact description of what an outside party claims to support, kept visibly smaller than current negotiated path truth.
- **method hint** — caller, browser, provider, or credential-side preference that can nudge route/transport/method choice without binding it.
- **negotiation witness** — inspectable residue saying which exact method/path actually survived and was admitted here.
- **unsupported-here honesty** — explicit local bottom-out when a listed or hinted capability does not land on a usable path here now.
- **advert smaller than negotiated path** — standing anti-regrowth rule.
