# Datacube derivative correction propagation

F099 adds a narrow pressure surface for the moment after a corrected source meets already-multiplied consumer derivatives.

## Compression

A derivative repair record is only admissible when Harbor can keep five facts apart:

1. a source correction exists for a scoped source digest;
2. a local derivative inventory identifies the derivative and its basis;
3. a propagation notice or invalidation action targeted that derivative;
4. a consumer acknowledgement says exactly what was observed;
5. the derivative state after action is verified, quarantined, partial/unknown, or notice-only.

The status word must attach to the derivative state, not to the mere correction, notice, route, acknowledgement, or sync provider state.

## Safe statuses

- `repaired_or_superseded_for_scope` — material evidence was checked for the scoped derivative.
- `quarantined_unreached` — stale material was contained, not repaired.
- `partially_propagated_unknown_surfaces_preserved` — some targets remain unknown.
- `notice_acknowledged_not_repaired` — acknowledgement was received, but no material repair is claimed.
- `refused_counterfeit_derivative_repair` — the candidate collapses notice, acknowledgement, sync, search, or signer posture into repair.

## Hard refusals

Harbor refuses to treat delivery as read, read as applied, acknowledgement as repair, sync green as digest verification, index rebuild as search truth, local patch as upstream repair, quarantine as repair, or any one derivative repair as global downstream repair.

## Research pressure

PROV-style derivation/revision language is useful because a revised derivative remains a derivative, not the original source. Web Annotation pressure matters because annotations bind bodies to targets and can themselves travel across systems. BagIt fixity pressure keeps transfer/manifest validation distinct from payload semantics. OCI referrers pressure keeps subject links distinct from trust, reachability, or repair. Linked Data Notifications and ActivityPub add notification/delivery pressure while still requiring Harbor to refuse delivery-as-read or delivery-as-application.

## Non-promotion line

This surface does not define a derivative invalidation ledger, notification protocol, cache API, repair attestation profile, sync-state authority, or compliance workflow. It only records enough evidence to prevent local repair status from becoming broader than the observed derivative material and scope.
