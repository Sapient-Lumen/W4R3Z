# Datacube recurrence and escalation hygiene

**Status:** design-phase review surface for `rev0090`; not an ADR, schema, status-page product, escalation workflow, regulator/auditor program, claims tribunal, reputation system, reliability score, enforcement ladder, takedown process, appeal court, customer-notification system, transparency log, VEX/CSAF profile, in-toto predicate, or final SlopOS datacube constitution.

## Why this exists

`rev0089` let Harbor record disputed remediation, expired acknowledgements, contradictory impact reports, unverifiable use attestations, and public-status drift without forcing closure. `F085` applies the next pressure: the same messy states can recur.

A catalog can repair a stale public copy and then regress during a later export. A downstream owner can acknowledge notices every cycle while never producing verifiable repair evidence. A non-use attestation can remain unverifiable across multiple windows. An external reporter can be correct on one stale copy and wrong on another. A stale public warning can remain useful for a while, then become misleading after targets repair or evidence goes cold.

Harbor needs language for recurrence, escalation, cooldown, and sunset. It must not turn that language into a trust score, reporter ranking, enforcement ladder, or incident-management product.

## Tight stance

- **Recurrence is a pattern, not a verdict.** Repeated stale copies justify more caution and better receipts; they do not by themselves prove bad faith, harm, or future failure.
- **Escalation needs a subject and a window.** Harbor can escalate one stale target, one claim family, or one public warning; it must not escalate a whole actor by vibe.
- **Cooldown is evidence-based, not forgiveness theater.** If repeated checks stay clean for a named window, public warning copy may narrow. The historical residue remains.
- **Sunset does not erase.** A warning can be retired for new public display while historical proofs, correction anchors, and old stale-use impact remain preserved.
- **Mixed reporter accuracy needs scope maps.** A reporter may be reliable on label stripping and wrong on disclosure impact. Harbor should store claim-level outcomes, not a person-level reputation score.
- **Serial expiry returns to unknown.** Expired acknowledgements across cycles show weak process evidence, but not non-use, use, refusal, repair, or harm.
- **Standing challenges must be bounded.** A standing challenge says a named claim family is not currently trusted without additional evidence; it is not a permanent blacklist.
- **Public warning text must degrade honestly.** Warning states should say current, active, cooling, historical-only, superseded, disputed, or unsafe-to-summarize; they should not keep screaming after the proof basis narrows.

## States under observation

These are composable labels, not a final state machine.

| State | Meaning | Counterfeit to avoid |
| --- | --- | --- |
| `recurrence_observed` | same subject class regressed again in a named window | actor bad-faith verdict |
| `regression_confirmed` | old stale condition reappeared on the same target or copy class | universal target failure |
| `serial_acknowledgement_expiry` | acknowledgements repeatedly expired without verifiable repair | proof of refusal or harm |
| `claim_family_unverifiable` | repeated attestations lack checkable basis for the same claim family | non-use or repair proof |
| `mixed_accuracy_reporter` | reporter had both confirmed and rejected claims | reputation score |
| `standing_challenge_open` | a named claim family requires extra evidence before use | permanent blacklist |
| `escalation_recommended` | recurrence pattern meets criteria for more visible review or outreach | enforcement decision |
| `external_escalation_needed` | internal process is insufficient for a named scope and audience | regulator/auditor workflow |
| `cooldown_active` | clean observations are accumulating after a recurrence | repaired forever |
| `warning_sunset_candidate` | public warning may be narrowed or retired for future use | deletion of history |
| `warning_sunset` | public-facing warning retired or moved historical-only | proof that all copies are safe |
| `public_log_divergence` | append-only/logged claim differs from current status surface | log is wrong or status is true by default |
| `unsafe_to_rank` | evidence cannot support actor/reporter scoring | hiding accountability |
| `unresolved_recurring` | repeated issue remains open after attempts | automatic escalation closure |

## Candidate process handles

These handles are watchlist vocabulary, not promoted schema.

### `recurrence_pattern_receipt`

A bounded packet that says a stale-copy, acknowledgement, attestation, reporter-claim, or warning-state pattern repeated.

Candidate fields:

- pattern id, source correction anchor, public artifact/copy ids, target class, actor class, claim family, label digest, payload digest, and audience;
- first observed, latest observed, recurrence window, clean windows, missed windows, target authority, and evidence lane;
- recurrence type: stale-copy regression, acknowledgement expiry, unverifiable attestation, repeated label stripping, warning drift, reporter contradiction, public-log/status divergence, or unsafe repeated summary;
- result: confirmed recurrence, scope mismatch, unconfirmed, under review, standing challenge, cooldown, sunset candidate, historical-only, or refused.

### `regression_guard_receipt`

A guard for a previously repaired target that becomes stale again.

Candidate fields:

- target id, prior remediation id, prior verification basis, repair observation, regression observation, old/new digest comparison, label-preservation check, exporter/renderer/cache basis, and target authority;
- allowed consequence: re-notify, recheck, challenge, escalate, quarantine public copy, mark unsafe for new use, or no action;
- non-promises: actor intent, all mirrors affected, all uses harmful, or all future releases unsafe.

### `serial_acknowledgement_note`

A note that an actor repeatedly acknowledged correction notices but did not provide fresh repair or non-use evidence.

Candidate fields:

- notice ids, acknowledgement ids, actor authority, acknowledged subject sets, expiry windows, recheck attempts, unreachable/refused/renewed states, and any remediation replacements;
- consequence: keep historical-only, require renewed acknowledgement, request proof, open challenge, or escalate visibility;
- explicit non-claims: no proof of use, non-use, refusal, negligence, or repair.

### `claim_reliability_limiter`

A claim-family limitation, not a score for a person or organization.

Candidate fields:

- claim family, claimant class, target scope, supporting evidence seen, missing evidence repeated, contradicted evidence, verified subclaims, rejected subclaims, and sealed evidence boundary;
- limitation result: accepted for scope, accepted with recheck, requires verifier packet, under standing challenge, public-safe only, or unusable;
- anti-score rule: the limiter cannot be aggregated into a general actor/reporter trust score.

### `reporter_claim_outcome_map`

A map of specific external reports and outcomes.

Candidate fields:

- report ids, reporter class, cited artifacts/copies, claim types, evidence basis, Harbor match result, confirmed fields, rejected fields, unresolved fields, and public response;
- mixed-accuracy posture: accurate-on-target, accurate-on-label, stale-on-version, wrong-audience, wrong-method, unsupported-severity, sensitive-evidence-unassessable, or duplicate;
- no ranking, score, or durable reporter profile.

### `escalation_cooldown_sunset_note`

A small decision note for a public warning or challenge posture.

Candidate fields:

- subject, current warning/challenge state, recurrence evidence, consumer risk, exposure window, last clean observations, stakeholders, safe public copy, escalation target, cooldown criteria, sunset criteria, and historical retention posture;
- outcomes: escalate internally, external-review packet needed, auditor/regulator packet needed, notify-only, cooldown active, sunset warning, keep active, or refuse public summary;
- non-promises: external authority acceptance, universal repair, all consumers reached, legal compliance, actor fault, reporter score, or log truth.

### `public_log_status_divergence_note`

A note that transparency/publication evidence and current public status differ.

Candidate fields:

- public log id or inclusion proof reference, status-page/card/banner id, signed claim subject, current proof packet status, divergence type, repair attempt, audience, and public copy;
- allowed conclusion: logged old claim, current status stale, both scoped differently, unresolved, or unsafe to summarize.

## Anti-counterfeit checks

- If a recurrence packet does not name subject, copy/claim family, window, and evidence lane, it is anecdote.
- If repeated acknowledgement expiry is shown as refusal or harm, it overclaims.
- If a claim-family limiter becomes a general actor or reporter score, it has escaped its scope.
- If a mixed reporter map collapses confirmed and rejected fields into one trust label, it invents reputation.
- If escalation lacks a target, audience, and consequence, it is process theater.
- If cooldown lacks clean observations and a window, it is premature closure.
- If sunset deletes the historical warning or correction chain, it counterfeits memory-hole recall.
- If public-log inclusion is treated as proof of current truth, transparency has replaced verification.
- If a status-page banner and public log diverge without a divergence note, downstream consumers cannot know which surface is stale.
- If standing challenges never expire, recheck, or name conditions for exit, they become blacklists.

## Minimum proof obligations before any promotion

A candidate recurrence/escalation noun must show at least these before it graduates from process residue:

1. It names the subject, source correction anchor, copy/claim family, target class, actor/reporter class, label/payload digest when available, audience, recurrence window, and evidence lane.
2. It distinguishes recurrence, regression, serial expiry, unverifiability, contradiction, scope mismatch, mixed accuracy, escalation, cooldown, and sunset.
3. It states what consequence is allowed now and which conclusions remain unsupported.
4. It preserves public/private/sealed evidence boundaries.
5. It includes an exit path: recheck, cooldown criteria, sunset criteria, standing-challenge renewal, or explicit unresolved state.
6. It refuses actor-wide reputation, reporter-wide scoring, legal/compliance closure, enforcement decisions, universal recall, model unlearning, and proof of non-use unless separately evidenced.

## Design-phase use

Use this surface to keep recurring stale-copy and weak-claim patterns visible. Do not make it a compliance program, status-page service, enforcement ladder, or SlopOS-wide reputation substrate.
