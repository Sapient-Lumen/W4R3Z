# Datacube time axes

Purpose: keep Harbor honest that a design-phase datacube can carry **more than one legitimate time** without pretending one timestamp explains everything.

Design-phase cubes repeatedly get into trouble when they flatten these into one column or one ambient “as of now” story:
- when something **occurred**;
- when a fact or assignment was **valid / in force**;
- when Harbor **learned / recorded** it;
- when a curated lane or snapshot **cut / published** it; and
- when a consumer **queried / observed** it.

Harbor should not freeze one universal temporal stack now.
It does need one small review surface that stops occurrence, validity, knowledge, and publish cuts from counterfeiting one another.

## Core rule
A timestamp is only meaningful once Harbor names **which axis** it belongs to.

A late-arriving event can have an old occurrence time and a new knowledge time.
A policy assignment can become valid in the future even though Harbor already knows it now.
A published lane can represent one cut of knowledge even after later restatements arrive.
A current consumer question can ask either “what was true then?” or “what did Harbor know then?” and those are not the same query.

Harbor therefore needs a compact way to say **which time axis a lane, field, or answer is using**.

## Minimal time-axis families (Phase 1)
Harbor should keep the first set small and descriptive rather than pretending every lane needs every axis.

1. **occurrence time**
   - when the underlying crossing, event, or external change happened.
   - closest to stream/event-time thinking.
   - strongest for “what happened when?” questions.

2. **validity time**
   - when a fact, assignment, route, classification, or enrichment was in force for business/semantic purposes.
   - strongest for “what was true/in-effect at that date?” questions.
   - should stay separate from mere recording time.

3. **knowledge time**
   - when Harbor learned, ingested, recorded, or made available a fact.
   - strongest for “what did Harbor know by then?” and restatement questions.
   - often the axis that late-arrival and correction pressure mutates.

4. **publish cut time**
   - the explicit snapshot/tag/revision/cut that a curated lane or derived artifact used.
   - strongest for replayability and explaining why one published answer differed from a later one.
   - should not be mistaken for occurrence or validity time.

These are review classes, not a commitment to one SQL engine, stream processor, or warehouse-wide physical schema.

## Time-axis card
Harbor should allow a compact **time-axis card** beside a curated lane.

The card can say:
- which axes the lane actually uses;
- which axis is canonical for grouping / filtering / joins;
- which axes are optional sidecars only;
- whether validity windows are allowed to overlap, forbidden to overlap, or not yet decided; and
- which consumer slices are safe to ask of this lane.

The point is not to make every lane bitemporal or quad-temporal.
The point is to stop one timestamp column from impersonating several truths.

## As-of witness
Harbor should allow a compact **as-of witness** whenever a query or published answer depends on an explicit temporal basis.

An as-of witness can say:
- which axis the question was asked on;
- the exact timestamp / interval / cut used;
- whether the basis came from inline query text, session-level context, or a pinned snapshot/tag;
- whether multiple time criteria were attempted or would conflict; and
- whether the answer is head-relative, cut-relative, or history-relative.

This matters because “as of business time X”, “as of system knowledge time X”, and “as of published cut Y” are different questions even if they talk about the same row family.

## Knowledge-cut note
Harbor should allow a compact **knowledge-cut note** beside a published lane or derived artifact.

A knowledge-cut note can say:
- the cut timestamp or tag used for publication;
- whether late arrivals after that cut are expected;
- whether restatement is possible, pending, or already performed;
- whether the published lane is meant for live operational use, historical replay, or both; and
- which evidence-grade or freshness posture, if any, still applies.

This matters because a published cut is often a statement about **what Harbor had incorporated by then**, not a timeless statement about what really happened in the world.

## Overlap discipline
When Harbor uses validity windows, it should say whether overlaps are:
- forbidden and should fail closed;
- temporarily tolerated during migration/rehearsal; or
- unresolved design debt.

Harbor does not need one giant overlap engine now.
It does need to avoid silently letting two simultaneously valid rows masquerade as one clean answer.

## What this forbids in Phase 1
- no silently treating occurrence time as if it proved current validity;
- no silently treating knowledge/ingest time as if it were the business-valid date;
- no silently treating a published cut as if it proved Harbor would have answered the same way at every later head;
- no silently asking “as of” questions without naming which axis the question uses;
- no forcing every lane into bitemporal or multi-temporal machinery before repeated specimens show it is truly needed.

## What this still leaves open
- exact machine schema for time-axis cards, as-of witnesses, or knowledge-cut notes;
- exact mapping onto stream/event-time systems, warehouse temporal tables, or semantic-layer products;
- exact cross-cube vocabulary sharing with SlopOS, Ward, Foundry, or Steward;
- whether Harbor later needs stronger overlap enforcement for selected published lanes.

Harbor only needs the review behavior now: **name the axis, keep “as of” explicit, and treat publish cuts as knowledge cuts rather than as timeless reality.**
