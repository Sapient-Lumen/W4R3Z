# SlopOS / companions evaluation — pass LXIX

This pass asks a datacube-discipline question rather than a warehouse question: if Harbor starts publishing design-phase lanes while SlopOS is still in design phase too, how does Harbor stop occurrence time, validity time, knowledge time, and published-cut time from collapsing into one counterfeit “latest” answer?

## What the companions teach this pass
- **SlopOS** remains the strongest process teacher because it keeps explicit discovery heads, exact reviewed artifacts, singleton-versus-family status, and same-revision maintenance visible. Harbor should steal that posture for temporal questions too: a moving head, an exact reviewed cut, and a business-valid date are different temporal truths.
- **Steward** keeps teaching exact receipts and accountable aftermath. That transfers well here: a published answer should be able to point at the exact cut/revision/receipt that produced it instead of letting “latest” do all the work.
- **Ward** keeps teaching tier honesty. That transfers here too: a historical replay cut can be exact and still be the wrong answer for a present-tense operational consumer.
- **Foundry** keeps teaching residue-class discipline. For Harbor, that is a reminder that occurrence, validity, knowledge, and publish-cut time should not all compress into one timestamp just because one dashboard prefers simplicity.
- **ViewFS** keeps teaching that materialization time and object identity are not the same fact. Harbor can reuse that instinct: when something was published or copied is not automatically when it happened or when it was valid.

## Harbor consequence
Harbor should make exactly one modest repo/process expansion now:
- add a datacube time-axes surface;
- add one specimen around time-axis cards, as-of witnesses, and knowledge-cut notes;
- refresh the load-bearing source register with living sources that keep occurrence / validity / knowledge / cut discipline visible; and
- keep semantic-front-door and restatement-feed pressure alive without pretending this pass finishes temporal design.

## Still-not-yet decisions
- whether Harbor later needs one shared machine-readable time-axis enum with sibling cubes;
- whether validity-overlap checks stay review/process residue or later become stricter enforcement on selected published lanes;
- whether publish cuts should later compile into a stronger snapshot registry or remain lightweight release/process residue.

For now, the companion lesson is enough: **separate what happened, what was in force, what Harbor knew, and what cut got published.**
