# Research synthesis — 2026-05-25 pass CVIII

## Focus

Foreign-import revocation and correction after cross-cube evidence import.

## External pressure

- W3C PROV separates entities, activities, agents, derivation, revision, and invalidation.  Harbor borrows the pressure that later invalidation or revision is another provenance fact, not automatic erasure of the earlier observation.
- TUF keeps rollback, freeze, version, and expiration checks explicit.  Harbor borrows the pressure that newer or expired metadata needs local policy checks; it is not freshness by itself.
- SPDX external document references and package verification code pressure Harbor to keep external references and material identity separate from local semantic adoption.
- in-toto/SLSA verification pressure Harbor to keep attestations smaller than policy expectations and local verification.

## Harbor consequence

A companion withdrawal, supersession, dispute, expiry, or re-scope must become a scoped overlay with parent import identity, digest, clock, local impact analysis, downstream quarantine, history residue, and recheck plan.  It must not become prior falsity, negligence judgment, automatic derivative repair, companion trust-root authority, or public green badge.

## Audit/refactor consequence

The executable proof-slice count has grown enough that a duplicated checker list is itself drift pressure.  Rev0108 centralizes checker order in an executable-surface registry and adds a registry audit.  The registry remains maintenance scaffolding only.
