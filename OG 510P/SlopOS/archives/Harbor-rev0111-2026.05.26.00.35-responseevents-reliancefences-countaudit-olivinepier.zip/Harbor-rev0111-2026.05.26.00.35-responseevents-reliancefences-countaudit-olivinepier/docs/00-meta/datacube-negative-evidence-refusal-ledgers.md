# Datacube negative evidence and refusal ledgers

Purpose: give Harbor a small review grammar for negative outcomes around datacube artifacts without creating a second authority plane.

This surface extends `docs/00-meta/datacube-presence-semantics.md`, `docs/00-meta/datacube-evidence-grades.md`, `docs/00-meta/datacube-assertion-posture.md`, and `docs/00-meta/datacube-option-reservation-cuts.md`.

It is deliberately smaller than a schema, incident manager, data-quality product, export policy language, sidecar registry, tombstone model, or universal event log.

## Standing rule
A negative-evidence row may be retained only when it names all of the following:

1. the request, artifact, assertion, export, or frontier that was evaluated;
2. the basis cut used for the evaluation;
3. the negative class;
4. the scope of the negative claim;
5. the consumer-visible consequence;
6. the expiry, retry, or supersession rule; and
7. at least one anti-counterfeit warning.

If those seven pieces are missing, the negative residue is too easy to misread as durable truth.

## NE-001 — missing sidecar note
**Use when:** an optional statistics, lineage, sketch, facet, optimizer, or debug sidecar is absent or unreadable.

**Required proof fields:**
- sidecar id or expected sidecar class;
- linked source lane / export / view and basis cut;
- sidecar optionality class: optional, expected-but-not-contractual, required-by-this-consumer, or required-by-this-contract;
- absence cause if known: not produced, withheld, expired, unreadable, incompatible-version, not requested, or unknown;
- fallback posture;
- consumer-facing consequence;
- expiry or retry rule.

**Anti-counterfeit tests:**
- missing sidecar does not mean missing row data;
- missing lineage does not mean no lineage exists;
- missing stats do not prove zero rows, no distinct values, or no skew;
- an absent optional sidecar cannot silently downgrade the base contract;
- an absent required sidecar is a contract/evidence failure, not a row-value mutation.

## NE-002 — blocked export receipt
**Use when:** Harbor or SlopOS refuses to emit an observation-shaped export, diagnostics bundle, view artifact, sidecar, or contract subset.

**Required proof fields:**
- export request id;
- requested artifact and tier;
- active policy or gate basis;
- blocked component classes;
- reason class: policy-denied, over-bound, withheld-sensitive, unsupported-tier, stale-source-cut, missing-consent, or unknown;
- whether a smaller export was emitted;
- requester-visible message class;
- retry path or no-retry statement.

**Anti-counterfeit tests:**
- blocked export does not prove the underlying data is absent;
- blocked export does not prove the requester lacks every entitlement;
- redaction/withholding is not null;
- a partial export cannot be described as complete;
- a denial receipt must not leak more detail than the export policy permits.

## NE-003 — unsupported assertion target note
**Use when:** a declarative assertion cannot be compiled or executed faithfully in a chosen target engine.

**Required proof fields:**
- source assertion id and version;
- compiler version;
- target engine and target version;
- unsupported semantics;
- downgraded semantics, if any;
- whether any generated artifact was emitted;
- result posture: no-result, partial-result, warn-only, observe-only, or blocked;
- followthrough requirement.

**Anti-counterfeit tests:**
- unsupported compilation is not assertion success;
- no target artifact is not evidence that the assertion is unnecessary;
- a downgraded generated check cannot widen a public contract;
- target-engine pass cannot erase unsupported source semantics;
- a warning-only fallback cannot become a blocking gate without separate policy.

## NE-004 — stale frontier notice
**Use when:** a watermark/frontier/progress witness is old, domain-mismatched, regressed, compacted away, or insufficient for a consumer question.

**Required proof fields:**
- frontier id and domain;
- source lane / stream / view and basis cut;
- observed frontier value and observation time;
- required frontier posture for the attempted question;
- stale reason: age-threshold, no-progress, domain-mismatch, compaction-gap, late-data-aperture-open, or unknown;
- what can still change;
- acceptable answers: refuse, preview-only, stale-labeled, exact-as-of-old-cut, or require rebuild;
- retry/rebuild rule.

**Anti-counterfeit tests:**
- stale frontier does not mean the underlying data is stale in every domain;
- old event-time progress is not the same as old published-cut time;
- a stale frontier is not permanent incompleteness;
- compaction gap is not proof that the event never existed;
- preview-only output must not be rendered as finalized.

## NE-005 — consumer-facing refusal ledger row
**Use when:** Harbor chooses not to answer, export, compile, join, or promote because the proof packet is insufficient.

**Required proof fields:**
- request id or promotion candidate id;
- consumer or caller class;
- refused action;
- refusal reason class;
- evidence basis and missing proof obligation;
- safe alternative, if any;
- expiry, owner, or followthrough item;
- visibility tier: internal, operator-visible, consumer-visible, or public;
- non-leak note when relevant.

**Anti-counterfeit tests:**
- a refusal ledger is not a blacklist;
- refusal of one action is not refusal of every action;
- refusal is not proof that the requested fact is false;
- refusal expiry is not permission to forget the reason too early;
- consumer copy must not expose withheld/sensitive evidence.

## NE-006 — tombstone / withdrawal humility note
**Use when:** a negative current lookup depends on a deletion marker, tombstone, suppression marker, or withdrawal state.

**Required proof fields:**
- key or scoped identity family;
- current lookup behavior;
- marker type and basis cut;
- retention / compaction / purge posture;
- resurrection or reuse hazard;
- replay/history availability;
- consumer-facing wording.

**Anti-counterfeit tests:**
- tombstone is not null;
- withdrawn current state is not proof that no history exists;
- purged marker is not proof that the object never existed;
- identity reuse before the quarantine/fence is unsafe;
- compaction timing can make negative evidence unavailable to late readers.

## Negative classes
Harbor should prefer a small closed list in specimens before it invents custom refusal dialects:

| class | means | does not mean |
| --- | --- | --- |
| `missing_optional_evidence` | expected helper evidence is absent but base row meaning may remain usable | row absence or contract failure |
| `missing_required_evidence` | a proof obligation for this lane/export/consumer is not satisfied | data value is false |
| `blocked_by_policy` | the requested emission is forbidden by an active policy/gate | requester knows the withheld fact is present or absent |
| `unsupported_target` | a compiler/query/export target cannot preserve required semantics | source assertion or source data is invalid |
| `stale_progress` | a progress witness is too old or wrong-domain for the question | all freshness claims are false |
| `preview_only` | an answer is useful but not final | finalized evidence exists |
| `withdrawn_currently` | ordinary lookup should behave absent because of a marker or withdrawal | safe purge, safe identity reuse, or no historical evidence |
| `unknown_not_observed` | Harbor lacks a trustworthy observation | negative truth |

## Refusal lifecycle
A refusal row must have a lifecycle no later than the same specimen that introduces it:

1. **created** — the refusal is recorded with basis and reason class;
2. **visible** — a bounded message is shown to the allowed audience;
3. **actionable** — retry, downgrade, rebuild, policy-review, or no-retry is declared;
4. **rechecked** — a later attempt either confirms, supersedes, or clears the refusal;
5. **retired** — the row is retained only as historical process evidence, not current authority.

## Promotion gate
A negative-evidence or refusal-ledger noun can be promoted beyond process vocabulary only after two independent specimens show:

- the same required proof fields recur;
- consumers benefit from seeing a bounded refusal instead of a generic failure;
- privacy/export bounds are not weakened;
- the negative row has a lifecycle and expiry/recheck posture;
- the evidence remains smaller than row truth, smaller than policy truth, and smaller than final datacube schema;
- a source-register refresh confirms relevant external posture has not changed.

## Explicit non-decisions
- no Harbor-wide incident manager;
- no global refusal ledger schema;
- no tombstone or delete-file implementation;
- no assertion compiler, query engine, or data-quality tool;
- no mandatory sidecar registry;
- no global freshness/frontier service;
- no public negative-evidence API;
- no decision that SlopOS's final datacube must expose these rows.

## Pass LXXX application
Specimen flow 75 exercises five negative cases together: missing optional lineage sidecar, blocked observation export, unsupported assertion compilation, stale frontier, and a consumer-facing refusal ledger row. The verdict is positive for review vocabulary and negative for durable promotion.
