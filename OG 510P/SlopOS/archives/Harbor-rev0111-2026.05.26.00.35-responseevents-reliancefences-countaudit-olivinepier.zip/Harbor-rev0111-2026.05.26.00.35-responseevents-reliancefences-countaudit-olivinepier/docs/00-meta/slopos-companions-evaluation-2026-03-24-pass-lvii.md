# SlopOS / companions evaluation — pass LVII

This pass re-checks Harbor against SlopOS and the sibling cubes after adding a required-authorization / actionable-detail-offer / authorization-type-slate specimen, and again chooses one narrow crossing seam over any early family bloom.

## What the current cubes still teach
- **SlopOS** remains the strongest restraint mechanism. Its auth-mediation boundaries keep RAR, token packaging, verifier-visible policy, and provider-local auth discovery on the provider-local side rather than portable substrate truth. That lines up with Harbor treating required authorization-details combinations and actionable error bodies as crossing residue only.
- **SlopOS** also keeps reinforcing that the resource server may know what this request needs without exporting a portable entitlement catalog. A required-types expression is therefore best read as a local demand surface, not a cross-provider grant grammar.
- **Ward** still reinforces visible-veto posture: a token can be target-valid and even strong enough on authentication, yet still bottom out because the structured authorization details are missing or shaped wrong.
- **Helm** still contributes UI humility: a helpful surface can explain “you need payment_approval plus stronger auth,” but the displayed explanation should not become durable approval or policy truth.
- **Foundry** still teaches aftermath honesty: request-scoped actionable offers and type slates are useful residue without becoming runtime or entitlement truth.
- **Steward** still teaches typed endings: when the right ending is “required details missing” or “actionable next request available,” the receipt should say that plainly.

## Harbor consequence
Harbor should keep this move modest:
- add one specimen around **required-authorization rail**, **actionable authorization-detail offer**, and **authorization-type slate**;
- keep target-valid fit, stronger-here authentication demands, missing scope, missing authorization-details, and later granted detail visibly separate; and
- leave any future authorization-details registry, entitlement grammar, or portable policy lattice outside Harbor for now.

## Still-not-yet decisions
- Whether **required-authorization rail** deserves its own Harbor family, or should remain only an annotation on specific protected-resource challenge specimens.
- Whether **actionable authorization-detail offer** belongs in Harbor at all, or should remain only a request-scoped note attached to one aftermath surface.
- Whether **authorization-type slate** belongs in Harbor, or should stay a compact local discovery/challenge explanation that never blooms into a portable entitlement or policy registry.
