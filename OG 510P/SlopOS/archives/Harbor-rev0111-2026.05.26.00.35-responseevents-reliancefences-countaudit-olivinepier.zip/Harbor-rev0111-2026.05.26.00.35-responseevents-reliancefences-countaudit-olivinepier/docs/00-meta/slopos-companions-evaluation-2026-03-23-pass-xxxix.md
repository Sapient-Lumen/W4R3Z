# SlopOS / companions evaluation — pass XXXIX

This pass re-checks Harbor against the uploaded cube ecology and keeps the archive embryonic.

## What the current cubes still teach
- **SlopOS** is the clearest teacher here. `approval-basis-posture-v0.md` and `acp-action-schema-v0.md` both insist that mutable review basis must already be reflected in exact action bytes and that stale basis must fail closed. That is almost a direct Harbor lesson: if Harbor names review or prompt residue at all, it should preserve a **basis witness** and a **stale-basis denial**, not a floating approval cache.
- **SlopOS** also sharpens the anti-fake-prompt lesson. `tool-ui-display-surface-boundary-v0.md` says rendered tool/server UI cannot become a hidden trusted modal or approval-basis seam, and `mcp-prompt-import-boundary-v0.md` says imported prompt catalogs/messages are provider-local drafting material rather than workflow/policy/approval truth. Harbor should copy that humility as **requester-copy negation**.
- **Steward** remains a useful sibling reminder that chrome, labels, and visible status can be productively small. That maps well onto Harbor’s need to keep reviewed surfaces bounded and inspectable rather than letting them overgrow into authority.
- **Foundry** still teaches overlay/config humility: fetched or rendered material can be current enough to inform a choice while still being smaller than actual admission or consequence. That supports Harbor’s **summary freshness** instinct.

## Harbor consequence
Harbor should keep these nouns provisional.
The right near-term move is small:
- add one specimen around `basis witness`, `summary freshness`, `stale-basis denial`, and `requester-copy negation`;
- keep reviewed prompt/copy surfaces visibly separate from durable grant/account/session truth;
- and let SlopOS or some later approval-specific cube own any portable trusted-UI protocol, approval-basis registry, or cached review substrate if those ever become necessary.

## Still-not-yet decisions
- Whether `basis witness` should be its own first-class card or a field attached to a broader review/mediation residue.
- Whether `summary freshness` deserves a separate verdict card or is better treated as one facet of stale-basis denial.
- Whether Harbor should ever expose typed requester-copy rejection reasons, or keep requester-copy negation as a single standing rule.
