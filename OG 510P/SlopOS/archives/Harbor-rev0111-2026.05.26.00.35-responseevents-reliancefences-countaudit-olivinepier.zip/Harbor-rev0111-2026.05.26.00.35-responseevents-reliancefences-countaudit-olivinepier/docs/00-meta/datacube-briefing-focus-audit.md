# Datacube briefing focus audit

Rev0110 added an audit/refactor pass on the entrypoint documents. The root `README.md`, `START_HERE.md`, and `docs/README.md` had accreted stale appended sections from prior revision summaries even though the existing hygiene suite passed. That is a Harbor-shaped bug: the visible landing surface can carry an old focus while the machine-visible release metadata says something newer.

Rev0111 keeps the audit but removes one brittle hand-maintained value: executable-slice count.  `tools/check_harbor_briefing_focus.py` now imports `tools/harbor_executable_surface_registry.py` and expects the registry-derived `EXECUTABLE_SURFACE_COUNT_PHRASE` rather than a hardcoded word such as "sixteen".

The guard checks that the three landing surfaces:

- name the current revision and current focus exactly once;
- include the latest research, companion evaluation, meta surface, verification doc, fixture, harness, checker, and specimen paths;
- mention the current latest executable surface and latest specimen from `SURFACE-STATUS.json`;
- carry the registry-derived executable-slice count phrase;
- do not contain stale revision fragments or old appended `Harbor living archive` blocks;
- keep links to the embryo-promotion contract and datacube design principles.

This audit is intentionally smaller than a documentation site generator, release-status API, trust root, badge, conformance suite, or promotion gate. It is a current-landing-surface sanity check.
