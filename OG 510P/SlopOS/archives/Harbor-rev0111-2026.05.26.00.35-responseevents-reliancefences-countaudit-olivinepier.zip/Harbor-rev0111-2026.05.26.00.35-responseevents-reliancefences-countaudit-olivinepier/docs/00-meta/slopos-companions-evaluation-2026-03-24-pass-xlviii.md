# SlopOS / companions evaluation — pass XLVIII

This pass re-checks Harbor against SlopOS and the sibling cubes after adding a requested-versus-issued target specimen, and again chooses one narrow crossing seam over any early family bloom.

## What the current cubes still teach
- **SlopOS** remains the strongest restraint mechanism. Its MCP auth discovery, metadata-fetch, and exact-match boundaries already keep resource identifiers, issuer equality, fetched metadata, and callback handling provider-local instead of silently becoming portable trust or route truth. That lines up cleanly with Harbor treating requested target, discovered AS route, and issued-resource echo as small crossing residue rather than as a new portable target or grant plane.
- **SlopOS** also contributes a broader posture lesson: imported metadata can be exact, useful, and still smaller than adopted local meaning. Harbor should borrow that restraint directly for discovery-time target routing.
- **Ward** keeps reinforcing the exact-basis instinct: a token or callback that looks valid still loses if the local side cannot prove it belongs to the exact place and exact target expected here.
- **ViewFS** keeps the anti-alias lesson alive from a neighboring seam: stable identifiers and explicit materialization beats nearby-path folklore. Harbor can borrow that posture for resource identifiers without inheriting ViewFS’s object-identity mission.
- **Foundry** keeps the foreign-runtime lesson alive: what another system says happened next can stay real aftermath without silently becoming local consequence or durable scope truth.
- **Steward** keeps the accountability lesson alive: a target mismatch or unbounded target should survive as inspectable aftermath instead of dissolving into a generic “success” or “failure” bucket.

## Harbor consequence
Harbor should keep this move modest:
- add one specimen around **request-target receipt**, **effective-target echo**, and **unbounded-target warning**;
- keep requested target, discovered AS route, exact proof target, and returned target/resource cues visibly smaller than durable issuer/resource/grant/adoption truth;
- collect **discovery-source note** and **narrowed-target subset** as inspiration only;
- and leave any future registry of resource classes, target negotiation, or portable issuance receipts outside Harbor for now.

## Still-not-yet decisions
- Whether **request-target receipt** deserves its own Harbor family, or should remain an annotation on the request envelope.
- Whether **effective-target echo** belongs in Harbor at all, or should remain a smaller aftermath note attached to specific specimens.
- Whether **unbounded-target warning** belongs in Harbor, or should stay a typed local caution that never blooms into a target-negotiation ladder.
