# Research synthesis — pass LIV

This pass keeps Harbor narrow and learns five compatible things at once: **JWT-secured introspection responses are signed and audience-bound to a particular protected resource without becoming generic client-facing protected-resource proof; the signed wrapper and the nested token-introspection payload are deliberately separated to avoid claim confusion; explicit returned `resource` confirmation is still stronger for clients than audience values learned from introspection or token self-inspection; resource servers still own exact accepted identifiers or alias families and must refuse mismatches; and Harbor should preserve those differences without freezing a portable target-confidence or alias registry too early.**

## Outside lessons
1. **JWT-secured introspection is receiver-facing, not client-facing proof.**  
   RFC 9701 lets a protected resource ask for an introspection response as `application/token-introspection+jwt`. The authorization server returns a signed JWT whose top-level `aud` identifies the resource server receiving the response, while the actual introspection members live under a separate `token_introspection` claim to avoid conflict with top-level JWT claims. Harbor should preserve a **JWT introspection response card** rather than overreading a signed response as portable exact-resource truth.

2. **Signed introspection still bottoms out on receiver fit.**  
   RFC 9701 says that if the access token is invalid, expired, revoked, or not intended for the calling resource server, the authorization server must set `token_introspection.active = false` and omit the other members. Harbor should therefore keep signed introspection evidence visibly smaller than durable adoption or entitlement truth.

3. **Returned `resource` still outranks audience folklore for the client.**  
   The March 2026 resource-token-response draft says clients cannot rely on audience information from either introspection or local inspection of a self-contained token to determine whether an access token is applicable to a specific protected resource. When a token request included resource parameters and the response includes `resource`, the returned set must contain at least one requested resource; it may also contain a strict subset of requested resources plus server-assigned resources. Harbor should therefore preserve **response-over-token precedence**.

4. **Resource servers still own exact local expectation.**  
   RFC 9068 says a resource server must reject a JWT access token if `aud` does not contain an identifier the resource server expects for itself, and the March 2026 OAuth 2.1 draft still says resource servers must verify on every request that the token was meant for that particular resource server and refuse otherwise. Harbor should therefore preserve local alias-family or exact-identifier mismatch as a visible ending instead of flattening it into token plausibility.

5. **Signed wrappers and token payloads can speak about different targets.**  
   In RFC 9701 the top-level JWT `aud` identifies the protected resource that received the introspection response, while the nested token metadata can still contain audience-like identifiers describing the introspected token. Harbor should collect a future **recipient-target split** idea without promoting it yet.

## Resulting Harbor move
Do not decide yet whether Harbor needs durable nouns such as **JWT introspection response card**, **response-over-token precedence**, or **alias-family mismatch note**.
For this revision:
- add one specimen around RFC 9701 JWT introspection responses, explicit returned-resource-over-audience precedence, and receiver-local alias-family mismatch;
- preserve the difference between “the authorization server signed a response to this resource server”, “the nested token metadata named these audiences”, “the client did or did not receive explicit `resource` confirmation”, and “this receiver still refused the turn here”; and
- collect **recipient-target split** as inspiration only, without promoting a new registry today.

## Fresh ideas worth stealing
- **JWT introspection response card** — compact residue that the authorization server signed a token-introspection reply to one exact resource server.
- **response-over-token precedence** — standing reminder that explicit returned `resource` confirmation can outrank ambiguous audience hints from tokens or introspection.
- **alias-family mismatch note** — local note that a token looked plausible but still missed the current receiver’s accepted identifier family.
- **recipient-target split** — future-facing reminder that the signed recipient of an introspection JWT and the target identifiers nested inside it are different strengths of fact.
- **signed-but-still-smaller-than-adoption** — anti-regrowth rule for cryptographically strong but semantically limited evidence.
