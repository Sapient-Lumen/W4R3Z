# Research synthesis — 2026-05-13 pass LXXVI

Question: while SlopOS and Harbor are both still in design phase, what should Harbor learn from current datacube, semantic-layer, table-format, streaming, observability, and assertion systems **without** turning any of those ideas into a premature Harbor constitution?

## What current sources say
1. **Observation-shaped modeling is still valuable, but one giant ontology is not the prize.**
   The RDF Data Cube vocabulary is useful because it separates observations from components such as dimensions, measures, and attributes. Harbor should steal that observation-component discipline, not an RDF commitment or a universal cube ontology.

2. **Semantic layers are tempting because they centralize meaning, but they can become counterfeit truth.**
   dbt Semantic Layer / MetricFlow and Looker both show why entities, dimensions, measures, and join relationships matter. The useful steal is narrower: semantic exports should be compiled artifacts with named inputs, join/additivity posture, and refusal modes. They should not become Harbor's native row truth while the lane vocabulary is still settling.

3. **Views are metadata and versioned definitions, not owned data.**
   Iceberg's view spec is a strong example of a view surface that stores metadata, dialect representations, and history without claiming to own base data. Harbor should collect the idea of a `derived-view receipt`: name the base cut, dialect, lineage, freshness basis, and invalidation rule; do not let a view impersonate a lane.

4. **Statistics, indexes, sketches, and facets are powerful sidecars.**
   Puffin-style blobs, OpenLineage facets, and retained sketches all point toward the same pattern: optional metadata can be extremely useful if it is typed, namespaced, versioned, and allowed to be absent. Harbor should steal the anti-counterfeit rule: a sidecar can guide cost, lineage, audit, or approximation, but it does not silently strengthen the contract of the base row.

5. **Watermarks are progress claims, not timeless closure.**
   Flink's event-time discipline keeps watermarks as statements about expected event-time progress in a world where late data can still appear. Harbor should steal a future `watermark/frontier witness` idea only as a measured, source-scoped progress claim, never as proof that old facts cannot be corrected or restated.

6. **Row lineage is useful debug and evolution residue, not universal identity.**
   Iceberg row lineage shows a credible table-format direction for source sequence numbers and row IDs. Harbor should keep row-lineage receipts optional and scoped until real specimens show whether row IDs carry enough meaning across extracts, restatements, deletions, and sibling-cube boundaries.

7. **Assertions and schema transforms should compile down, not define the cube.**
   DataHub Open Assertions and OpenTelemetry schemas both teach a good humility pattern: keep declarative checks and schema-version transforms explicit, portable, and tool-compilable. Harbor should steal compiler targets and schema-transform receipts, not choose one assertion engine or telemetry schema regime now.

8. **SQL cube/pivot operators are query affordances, not proof of base semantics.**
   `CUBE`, `ROLLUP`, `GROUPING SETS`, and `PIVOT` are convenient answer shapes. Harbor should let them inspire export and review tests, but should not infer base grain, additive legality, conformance, or exactness from the fact that a query engine can render a cube-shaped table.

## Harbor consequence
Harbor should make one modest process expansion now:
- add an **option-reservations surface** that collects promising datacube ideas with promotion triggers and anti-counterfeit notes;
- refresh lessons, inspiration harvests, load-bearing sources, ledgers, and briefing surfaces around observation components, derived views, statistics/facet sidecars, row-lineage restraint, watermarks, schema transforms, assertion compilers, and pivot/cube query affordances;
- keep semantic models, views, statistics blobs, watermarks, facets, schema transforms, and assertion compilers derived or optional until specimens prove otherwise; and
- keep the current measurement-semantics pressure as the single `next` followthrough slot rather than pretending this pass already selected a warehouse, semantic layer, streaming engine, row-identity regime, or sidecar registry.

## What Harbor still should not decide yet
- one RDF / relational / OLAP / lakehouse / semantic-layer substrate;
- one universal semantic front door, metric API, or query-planning product;
- one mandatory view representation, statistics blob schema, or facet registry;
- one global watermark/frontier model for every lane;
- one universal row-ID or row-lineage constitution; or
- one assertion engine, data-quality DSL, schema-transform grammar, or cube/pivot output format.

The design-phase lesson is enough for now: **reserve the option, name the counterfeit risk, demand a specimen, and keep every shiny helper smaller than row meaning and smaller than published-lane truth.**
