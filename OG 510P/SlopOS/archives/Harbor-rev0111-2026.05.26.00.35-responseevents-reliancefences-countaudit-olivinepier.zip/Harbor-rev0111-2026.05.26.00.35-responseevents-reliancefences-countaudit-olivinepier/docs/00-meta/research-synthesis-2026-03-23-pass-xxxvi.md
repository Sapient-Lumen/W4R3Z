# Research synthesis — pass XXXVI

This pass keeps Harbor narrow and learns one more thing from assurance requests, returned assurance claims, and passkey verification posture: **what a caller or resource asks for is not the same as what was actually achieved, and method evidence is not a universal assurance tier by itself.**

## Outside lessons
1. **OpenID Connect separates requested assurance from achieved assurance.**  
   OpenID Connect Core says `acr_values` is an OPTIONAL request parameter listing requested `acr` values in order of preference, and that parameter only requests the `acr` Claim as a Voluntary Claim. By contrast, when `acr` is requested as an Essential Claim with specific `value`/`values`, the Authorization Server MUST either return a matching `acr` value or treat the outcome as a failed authentication attempt. Harbor should steal that split: a stronger ask can be advisory or mandatory, but neither one is the same thing as the achieved rung.

2. **Returned method evidence is useful, but smaller than assurance truth.**  
   OpenID Connect defines `amr` as a JSON array of identifiers for authentication methods used, while RFC 8176 establishes a registry for those `amr` values. That is an excellent anti-regrowth lesson: methods used can explain *how* authentication happened without universally settling *how strong* it was.

3. **WebAuthn asks for verification separately from reporting that it happened.**  
   WebAuthn Level 3 lets the RP request `userVerification` as `required`, `preferred`, or `discouraged`; the effective behavior depends on authenticator capability, and if `required` cannot be satisfied during conditional mediation the operation fails with `ConstraintError`. Separately, the signed authenticator data carries the UV bit to say whether the user was verified. Harbor should preserve that difference between requested verification pressure and returned verification evidence.

4. **Mixed passkey posture is a real deployment idea, not just theory.**  
   Recent FIDO Alliance assurance guidance explicitly recommends mixed deployments in moderate-assurance environments: synced passkeys for standard users and device-bound passkeys for the highest-protection or highest-privilege cases, while warning that relying parties need extra policy steps to ensure the correct credential type is used for high-assurance access. Harbor should steal the humility: the crossing may carry evidence about the rung or method used, but policy about which rung is acceptable remains local and situational.

## Resulting Harbor move
Do not decide yet whether the durable nouns are exactly `assurance ask`, `achieved rung`, `method receipt`, and `unable-here honesty`, or whether later pressure compresses some of them behind smaller route/admission residue.
For now, keep them alive as specimen nouns and demand that they improve:
- one OIDC specimen where requested `acr`/`auth_time` strength can be voluntary or essential and the actual returned `acr` still deserves its own residue;
- one WebAuthn specimen where `userVerification` pressure and UV-bit evidence stay visibly separate;
- and one mixed-passkey specimen where policy distinguishes synced and device-bound passkeys without turning method labels into a portable assurance registry.

## Fresh ideas worth stealing
- **assurance ask** — typed request for a stronger or more specific authentication rung.
- **achieved rung** — inspectable statement of the actual assurance class or verification rung that this crossing achieved.
- **method receipt** — compact evidence about the methods or verification properties actually used, kept smaller than assurance truth.
- **unable-here honesty** — explicit local bottom-out when the requested rung cannot be met here now.
- **method smaller than achieved rung** — standing anti-regrowth rule.
