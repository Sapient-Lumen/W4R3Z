# Datacube stability rings

Purpose: keep Harbor honest about **how strong a promise** each curated datacube surface currently makes.

Why this exists:
- Harbor is still in design phase, so it would be unhealthy for every promising lane, semantic-model file, or export surface to imply the same permanence;
- modern systems repeatedly show that explicit maturity stages, explicit compatibility promises, and explicit deprecation windows are healthier than folklore;
- Harbor therefore needs one small review surface that says which datacube lanes are still rehearsal, which are candidate, which are published, and which are frozen historical references.

This doc does **not** choose a warehouse engine, schema registry, catalog product, semantic-layer vendor, or exact version-number syntax.
It is a design-phase contract for maturity and compatibility posture only.

## Rings (Phase 1)

1. **Rehearsal ring**
   - Purpose: pressure-test one contract, backfill, export, or sidecar shape.
   - Compatibility promise: **none**.
   - Expected lifetime: explicit and short.
   - Derived artifacts may exist, but they remain experimental and smaller than canonical review surfaces.

2. **Candidate ring**
   - Purpose: allow limited downstream trial by real consumers without pretending the lane is final.
   - Compatibility promise: explicit but narrow, usually **latest-only** or **additive-only during the candidate window**.
   - A candidate lane must name its owner, review trigger, and expiry/re-promotion expectation.

3. **Published ring**
   - Purpose: provide the default curated surface Harbor is willing to stand behind.
   - Compatibility promise: explicit and reviewable.
   - Breaking changes require either a successor lane/version or a clearly staged deprecation path; they must not arrive as silent reinterpretation.

4. **Historical ring**
   - Purpose: keep a frozen audit/replay reference.
   - Compatibility promise: **frozen exact history** for that reference.
   - Historical references are not the live head and should not silently inherit later schema or semantic changes.

## Compatibility windows

Harbor should describe compatibility in a compact reviewable way instead of leaving “stable” undefined.
Current allowed window labels are:
- **none** — rehearsal only;
- **latest-only** — only the latest named version or lane head is promised during the evaluation window;
- **additive/backward** — additive columns/facets and backward-safe changes are allowed, destructive reinterpretation is not;
- **frozen exact** — historical tag/snapshot only.

These labels are process discipline, not a commitment to one vendor’s enforcement engine.

## Required notes for any non-rehearsal lane
A candidate, published, or historical lane should carry:
- one **stability ring card**;
- one explicit **compatibility window**;
- one **consumer-pin note** when a known consumer depends on that lane or historical tag;
- and, when retiring or superseding a published lane, one **deprecation receipt**.

## Deprecation receipt
A deprecation receipt should say:
- which lane/reference is being retired or superseded;
- which successor lane/reference replaces it, if any;
- what overlap or warning period exists;
- what compatibility promise remains during the overlap; and
- when the older surface becomes historical-only or disappears.

## What this forbids in Phase 1
- no saying a lane is “stable” without saying **what kind** of compatibility it currently promises;
- no silent destructive reinterpretation of a published lane;
- no deprecating a stronger published lane in favor of a weaker, less stable successor without saying so;
- no moving published contract pointers at a mutable branch head while pretending they are immutable history;
- no giant early governance registry just because the first few rings proved useful.

## What this still leaves open
- exact version numbering syntax;
- exact retention period lengths;
- exact enforcement or CI policy for compatibility checks;
- exact mapping from rings to views, marts, semantic models, tags, or branch names.

Harbor only needs the review behavior now: **name the ring, name the compatibility window, and leave a receipt when promises change.**
