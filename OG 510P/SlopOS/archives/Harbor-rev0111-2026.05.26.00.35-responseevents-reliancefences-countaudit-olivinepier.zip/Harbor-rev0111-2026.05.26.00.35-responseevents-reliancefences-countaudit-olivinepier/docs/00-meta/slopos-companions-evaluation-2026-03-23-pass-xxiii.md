# SlopOS / companions evaluation — pass XXIII

This pass re-checks Harbor against the uploaded cube ecology and keeps the architecture embryonic.

## What the current cubes still teach
- **SlopOS** keeps auth mediation, browser-session selection, login-state export, auth-result export, account-binding export, and authorization-context export provider-local or request-local. That means Harbor should model only the *crossing truth* about mediation posture, not who is signed in or which account is bound.
- **Steward** reinforces that chooser surfaces and post-completion truth should stay inspectable rather than ambient. Harbor can borrow that discipline for chooser-light versus explicit-interaction aftermath.
- **ViewFS** keeps remembered designators, revalidation, and live handles separate. That is a good analogy for remembered account relation versus whether the browser can proceed silently right now.
- **Helm** still teaches humility about continuity postcards and revalidation checkpoints. Harbor can expose a small UI-mediation residue without inflating it into a session/account object.
- **Ward** still teaches the hard rule: strong outside success signals remain weaker than durable local appraisal.

## Harbor consequence
Harbor should keep mediation nouns provisional.
The right near-term move is small:
- add one specimen around requested mediation rung, silent probe, chooser-light mediation, and typed interaction floors;
- keep provider/browser-local login state, current account choice, and final auth-result truth outside Harbor-owned durable vocabulary;
- keep mismatch and bottom-out honesty explicit so silent attempts degrade to chooser, login, consent, reauth, or stop instead of counterfeit smoothness.

## Still-not-yet decisions
- Whether `conditional chooser` deserves first-class Harbor status or remains just one case of mediation rung.
- Whether `interaction floor` should be a compact aftermath family or merely typed fallback on route/adoption objects.
- Whether forced reauthentication should sit beside chooser/login/consent or deserve a visibly stronger floor of its own.
