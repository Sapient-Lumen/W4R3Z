## Pass CVIII additions

- A foreign revocation notice is an overlay on a prior import, not a verdict that the prior import was false.
- Withdrawal, supersession, dispute, expiry, and re-scope can require local recheck without becoming downstream repair, compliance failure, public truth, or companion authority.
- Historical residue matters: erasing the earlier import story is itself a counterfeit because consumers need to know which derivative state was based on which foreign fragment and when that basis changed.
- Maintenance registries help only when they remain maintenance. A checker registry that starts sounding like conformance or trust authority has crossed the wrong membrane.

## Pass C additions
- A checker result needs its own provenance packet: source digest, fixture digest, invocation, guard state, and self-test receipt are separate facts.
- A reviewer override may explain or schedule followthrough, but it must not change the machine result or turn failure into success.
- Self-testing is useful evidence and still smaller than checker certification, CI status, trust-root creation, or subject-bundle truth.

## Pass XCIX additions

- **A survived mutant is a question, not a failure class.** Harbor now records unsafe survivors, equivalent survivors, overstrict kills, and pruning candidates as different review packets.
- **Checker gaps can hide in strings.** Blocking a forbidden key is not enough when an accepted string value says `global truth`, `fresh now`, or `trusted content`.
- **Equivalent survivors need receipts.** A harmless reorder or wording change should not weaken counterfeits, inflate coverage, or silently become schema law.
- **Overstrict kills can be intentional.** Canonical order may be a reproducibility guard even when the semantic content is unchanged.
- **Pruning is historical bookkeeping.** Removing redundant generated cases requires reason, replacement coverage, and retained historical trace.
- **Scores are not safety.** Mutation totals, killed counts, and survivor counts remain diagnostics, not Harbor correctness, completeness, or conformance claims.

## Pass XCVII additions

- **Verifier disagreement is evidence, not embarrassment.** Accept/refuse/inconclusive/currentness-unknown splits should stay visible rather than being crushed into one badge.
- **Policy epochs are part of the fact.** A policy id without policy digest, epoch, and input digest is not enough to compare verifier outcomes.
- **New policy does not erase old basis.** It may require recheck, warning, or revised public copy, but it must not memory-hole historical publication evidence.
- **Unknown currentness is not fresh.** Inclusion, timestamping, or one verifier pass cannot prove issuer status, log consistency, revocation, mirror status, or generated-explanation freshness.
- **Majority is not authority.** Two passes and one refusal still need scope, jurisdiction, verifier role, and policy-family comparison before any public status travels.
- **Issuer compromise is a recheck trigger.** It is not automatic truth, automatic falsity, global revocation, or clean-since-compromise proof.
- **Badges should be humble.** Withheld, split, scoped, recheck-required, prior-epoch-with-notice, or incomparable-review are safer than green/trusted/resolved/all-clear.

## Pass XCIII additions

## Pass XCIV additions
- **Crossing records are aftermath receipts, not truth containers.** Subject, route, admission, scope, outcome, and aftermath must be explicit before any status word travels.
- **Scope comparison comes before closure language.** `same_scope`, `overlaps`, and `incomparable` block deadline, warning, and correction evidence from widening silently.
- **A warning sunset is scoped.** It is not global repair, compliance, downstream non-use, or all-agent correction.
- **Agent invalidation is not forgetting.** A cache or generated explanation can be invalidated without proving training unlearning or future-behavior repair.
- **SlopOS executable evidence helps only if Harbor keeps it small.** Portal acceptance, checkpoint/resume, truncation, and append history are route/process facts, not trusted content.
- **Implementation is not closure.** A corrected canonical bundle proves only that a named action happened for named artifacts and cuts; it does not prove mirror refresh, snippet refresh, downstream repair, non-use, legal compliance, or absence of stale public copies.
- **Deadlines are scoped windows, not verdicts.** A mandate, recommendation, advisory note, appeal stay, and jurisdiction-specific duty need separate receipts before Harbor can say what was due and what was merely suggested.
- **Partial repair must stay visible.** The honest state after a public correction may be canonical-clean / snippet-stale / mirror-unreachable / generated-explainer-invalidated / localized-summary-stale all at once.
- **Rechecks are observations, not warranties.** Monitoring receipts should name target surfaces, method, coverage, clean/stale/inconclusive results, and next horizon without claiming future cleanliness or global recall.
- **Audience splits are safer than false consensus.** Jurisdiction-specific or audience-specific public copy should be explicit and recomposition-guarded rather than collapsed into one global wording.

## Pass XCII additions

- Outside findings are imported evidence packets; Harbor-local adoption is a separate act.
- Scope normalization must come before contradiction: subject, window, audience, method, evidence lane, and authority basis decide whether two findings are comparable.
- Source-owner speech, auditor findings, regulator-facing determinations, reporter claims, and transparency receipts each have different powers and none should silently outrank the others.
- Mandated, recommended, advisory, proposed, and refused corrections must not share one public word like `fixed`.
- Sealed-only findings can change safe wording only through redaction-bound adoption notes; they must not become public proof.
- Appeal outcomes can change status or public copy without deleting correction anchors, stale-use evidence, recurrence evidence, or old warning history.
- Finding expiry removes current reliance; it does not refute or erase the historical finding.

## Pass XCI additions

External escalation is safest when it is cargo-like: a named packet, a named recipient/audience, a named challenge, a named window, a sealed/open/public split, and explicit non-promises. Harbor should learn from CVD, PSIRT/CSIRT, TLP/IEP, appeals, SCITT, in-toto, and SlopOS attestation boundaries that a handoff receipt is not review, an acknowledgement is not repair, an appeal is not reversal, sealed evidence is not public truth, and a log entry is not current status.

What Harbor must preserve:

- source-owner, auditor, regulator, coordinator, and public-reader roles are different audiences, not one authority class;
- appeal windows need challenged decision, grounds, remedy, deadline, standing, completeness, and explicit stay posture;
- sealed packets need digests, redaction maps, handling labels, reveal conditions, verifier operations, expiry, and public-summary limits;
- public summaries must guide current users without leaking suppressed values, raw logs, private reporter details, or sealed replay evidence;
- public-log/status divergence after escalation is an expected condition that deserves a note, not a forced winner;
- sunset appeals preserve historical correction chains and old warning evidence even when active display changes.

## Pass XC additions

- **Recurrence is pattern evidence, not motive evidence.** Repeated stale copies justify stronger guards and review, but not bad-faith, harm, or future-failure claims.
- **Regression preserves both facts.** A target can have been repaired when observed and later serve stale material again; do not rewrite either receipt.
- **Serial acknowledgement expiry is weak process evidence.** It can justify recheck or verifier evidence, but it does not prove refusal, use, non-use, or repair.
- **Mixed reporter accuracy needs claim maps.** Confirmed stale-copy evidence and rejected disclosure-impact claims can live in the same report without ranking the reporter.
- **Standing challenge is scoped.** It should name the claim family and exit conditions; otherwise it becomes a blacklist.
- **Cooldown and sunset must preserve history.** A warning can move historical-only after clean windows, but correction chains and old stale-use evidence remain.
- **Public logs and status pages can diverge honestly.** Inclusion can prove an old claim was published while current proof says challenged or recurring.

## Pass LXXXIX additions

- **Resolved is a presentation claim, not an evidence state.** Harbor must be able to say the source artifact is corrected while a catalog banner, mirror, dashboard export, search snippet, generated explanation, or model/eval card is still stale or disputed.
- **Expired acknowledgement is not refusal, non-use, repair, or harm.** It only means the old receipt no longer supports current posture.
- **Contradictions need scope maps.** Artifact id, version/cut, label digest, audience, time window, method, and actor authority decide whether two claims conflict or simply talk about different things.
- **Unverifiable non-use is a claim, not proof.** Cooperation is useful; missing logs, dependency locks, retrieval-index versions, model/eval paths, and retention windows must remain visible.
- **Transparency is not truth.** Signed, timestamped, append-only publication proves that a claim existed; Harbor still needs verification before treating it as correct.
- **Unresolved-for-now is safer than fake closure.** Design-phase Harbor should preserve disputed, unverifiable, scope-mismatch, and unsafe-to-summarize states rather than inventing a tribunal.

## Pass LXXXVIII additions
- **Stale use is a chain, not a badge.** Separate exposure, use, reliance, impact, acknowledgement, remediation claim, verified remediation, residual risk, and historical-only posture.
- **Acknowledgement is not repair.** A consumer can receive and acknowledge a correction while reports, dashboards, caches, users, models, or evals remain stale.
- **Fix claims need a subject and an action.** A remediation statement that does not name what was changed, by whom, with what evidence, and what remains risky is not proof.
- **No-use claims are scoped.** A downstream attestation that one team did not use one stale artifact in one window cannot prove global non-use.
- **Label impact can be material even when numbers do not change.** Missing suppression/noise/non-DP/exactness labels can mislead users without numeric drift.
- **Model/eval contamination needs humility.** A stale dataset card warning does not prove unlearning, corpus deletion, benchmark repair, or behavior change.
- **Safe public impact copy must carry non-promises.** It should guide users to the corrected artifact without leaking suppressed values or implying universal recall.

## Pass LXXXVII additions
- **Source fixed is not world fixed.** A valid correction anchor says Harbor's source is current; it does not prove every catalog, mirror, cache, snippet, agent answer, training set, or archive has updated.
- **Propagation attempts are not propagation success.** Purges, recrawl requests, sitemap timestamps, and URL-change pings need observed status or must be labeled attempt-only.
- **Mixed-current is a real state.** A target can link to the current artifact while its human description, snippet, cached chart, downloadable copy, or label sidecar remains stale.
- **Agent memories need invalidators.** Generated explanations and retrieval chunks must be invalidated when source labels, correction anchors, or public status change.
- **Training and eval copies are sticky.** A stale-copy notice can inform downstream users, but it does not prove model unlearning, corpus deletion, or benchmark repair.
- **Crawler directives are not erasure.** Robots, noindex, snippets, and freshness signals influence access or surfacing; they do not delete already copied public artifacts.
- **Unreachable mirrors deserve receipts.** Harbor should preserve a warning and successor link for copies it cannot update instead of pretending unknown copies vanished.

## Pass LXXXVI additions
- **Corrections supersede; they do not erase.** A corrected public copy needs old/new status and successor links without pretending every cached or cited old copy vanished.
- **Annotations need targets and provenance.** A note attached to a chart, row, label, or summary is only useful if Harbor can see body, target, selector, source, review status, and safety lane.
- **Citation freshness is not semantic truth.** A URL or DOI can resolve while still pointing to a superseded, stale, or metadata-lagged copy.
- **Generated explanations are derived copy.** A model-written explanation must carry source artifacts, label digests, omitted-label warnings, review status, and invalidation triggers.
- **Disputes are not disclosure grants.** A consumer can contest a suppression or noise label without gaining raw hidden cells, contributor evidence, or sealed replay packets.
- **Translated errata can drift.** A correction notice in another language must preserve machine label IDs, non-promises, status relations, and unresolved terminology warnings.

## Pass LXXXV additions
- **Translation is not relabeling authority.** A translated public copy is valid only when machine label IDs, non-promises, suppression/noise/exactness warnings, and restatement links survive translation.
- **Locale formatting is notation, not new measurement.** Decimal marks, percent displays, unit names, calendars, and collation need receipts that point back to canonical value, unit, time, and label basis.
- **Accessibility is structure, not a caption.** Charts need reachable data and text alternatives; tables need captions, headers, source links, and carried labels before they can review the same copy.
- **Plain-language summaries are not proof bundles.** Summaries are valuable, but they become dangerous when they omit the labels that made the public copy honest.
- **Renderers can reorder meaning.** Sorting, grouping, top-N folding, hidden rows, pagination, and locale collation can change consumer inference even when all cells are unchanged.
- **Friendly variants need refusal language.** Harbor should be able to say “this rendering is explanatory-only” or “this copy is invalid until repaired” without claiming the source artifact is bad.

## Pass LXXXIV additions
- **Release is not copy hygiene.** A public aggregate can be valid at release time and still become misleading when labels are stripped in CSV, BI, PDF, chart, mirror, or cache copies.
- **Labels are cargo, not decoration.** Suppression, perturbation, exactness downgrade, structural-zero, non-DP, source-cut, and restatement labels must travel with the public payload or be explicitly refused.
- **Restatement is not retroactive rewrite.** A new public copy can supersede an older copy without pretending the old copy was erased, exact, or never released.
- **Withdrawal is not recall.** Harbor can warn, deprecate, supersede, or mark a copy unsafe for new use; it should not promise that lawful downstream copies vanished.
- **Copy proof is not raw proof.** Digest/manifest/label receipts can prove emitted public bytes without disclosing replay bundles, suppressed values, or contributor evidence.
- **Valid copies can compose unsafely.** Individually acceptable public artifacts may reconstruct hidden values when combined, so sibling-copy and recomposition warnings belong beside the release.

## Pass LXXXIII additions
- **Aggregate-only is not disclosure-safe.** A value can be an aggregate and still leak through small cells, small denominators, dominance, sibling cuts, or repeated queries.
- **Answerability is not releaseability.** Harbor can know an exact frozen answer internally while refusing or coarsening the public copy.
- **Suppression needs neighborhood review.** A hidden cell can be solved from margins, sibling tables, or provider-excluded cuts unless complementary suppression or perturbation is part of the release plan.
- **Noise is not differential privacy by vibes.** A noisy output needs mechanism, contribution bounds, parameters, composition/accounting, and exactness/additivity consequences before it can claim privacy protection.
- **Zero is not one thing.** Structural zero, true zero, rounded zero, perturbed zero, suppressed zero-like display, missing evidence, and refusal need different labels.
- **Refusal copy can leak.** Explaining why a cell is suppressed must stay class-level enough not to reveal the hidden count, denominator, or dominant contributor.

## Pass LXXXII additions
- **Proof visibility is a lane.** An answer can be visible while its survivor evidence remains sealed, redacted, auditor-only, operator-only, or undiscloseable.
- **Verification is not disclosure.** A derived proof, digest, inclusion proof, or signed attestation can support a claim without granting raw-row access or proving every hidden fact.
- **Redaction is not de-identification.** Masking, hashing, and field removal reduce exposure, but they do not automatically defeat linkage, differencing, or repeated-query risk.
- **Verifier tickets expire.** A scoped proof request should carry audience, allowed claims, redaction cut, source locks, expiry, revocation, and non-recursive fetch limits.
- **Current policy cannot prove old history by vibes.** Old answers need old source/policy/runtime locks or an explicit equivalence proof; otherwise Harbor must downgrade or refuse exact verifier language.
- **Proof bundles are not verdict planes.** A bundle label or transparency-log inclusion witnesses bytes/events, not semantic approval, public disclosure safety, or install/replay authority.

## Pass LXXVI additions
- **Observation components beat one giant ontology.** A datacube can name observation, dimension, measure, and attribute roles without forcing every source into one RDF, warehouse, semantic-layer, or BI-product constitution.
- **Views are publication metadata, not data or meaning.** A derived view receipt can be valuable only if it names base cuts, dialect/runtime, invalidation, and lineage instead of impersonating a first-class lane.
- **Semantic layers are exports until promoted.** Entities, dimensions, measures, metrics, and join relationships are excellent compiled surfaces, but they stay derived while SlopOS and Harbor are still design-phase.
- **Sidecars and facets need anti-counterfeit boundaries.** Statistics blobs, sketches, indexes, and metadata facets are useful only when they remain optional, namespaced, versioned, and smaller than base-row contract truth.
- **Watermarks are progress claims, not timeless closure.** A frontier can say how far a source believes event-time processing has advanced; it cannot prove that late data, corrections, or restatements are impossible.
- **Row lineage is debug/evolution residue, not universal identity.** Source sequence and row identifiers can help explain change, but they must not become a cross-system person/object/key constitution by accident.
- **Assertion compilers verify; they do not define.** Declarative data-quality checks are useful when they compile to observed tests and keep promise, evidence, severity, and waiver posture separate.
- **Schema transforms are receipts, not proof meaning stayed the same.** A transform can say how a consumer moved across versions; it must also say what was preserved, weakened, dropped, or only mechanically converted.
- **Cube and pivot operators are answer shapes.** `CUBE`, `ROLLUP`, `GROUPING SETS`, and `PIVOT` can pressure-test Harbor, but safe rollup still depends on grain, conformance, additivity, exactness, and fanout evidence.

## Pass LXXV additions
- **Named axes beat one fake latest.** Occurrence time, validity time, knowledge time, and published-cut time answer different questions and should not collapse into one ambient timestamp.
- **A contract is narrower than all assertions.** A public promise can be one selected subset of checks, while other assertions remain local evidence or experimentation residue.
- **Freshness needs a basis.** “Fresh” without an explicit clock, threshold, and last-seen witness is just mood.
- **Join safety is part of measure meaning.** Base-grain uniqueness, join relationship, and non-additive axes belong in the review surface before a visible number starts traveling.
- **History convenience can erase truth.** Changed-row feeds, flattened CDC payloads, and tombstone-light exports are useful, but they are weaker than full change history and should say so.
- **Row lineage is promising but smaller than constitutional identity.** A lineage receipt may help later without forcing Harbor to adopt one universal row-ID regime now.
- **Additive evolution is healthier than destructive reinterpretation.** New columns, sidecars, and successor lanes preserve optionality better than silent same-name semantic rewrites.


## Pass LXXIV additions
- **A scalar is not yet a quantity.** Harbor should name what kind of thing is being measured before values, units, and displays start impersonating one settled truth.
- **Display unit is weaker than coded unit.** Pretty suffixes and localized renders are useful, but they should not outrank the machine-comparable coded basis.
- **Percent is often a rendering choice, not stored meaning.** Fractions/utilization often travel more honestly in unity form with percent display left to the edge.
- **Money is not physical conversion.** Cross-currency comparison needs an explicit rate witness because exchange rates vary and denominations/history move.
- **Single-quantity/single-unit discipline prevents quiet drift.** A lane that mixes milliseconds and seconds or original and converted currency without saying so is already lying.


## Pass LXXII additions
- **Exactness is part of meaning.** An integer-looking scalar can still be an estimate, and Harbor should say so explicitly.
- **Mergeable is not exact.** A sketch that re-aggregates well is analytically powerful, but it is still weaker than preserved exact rows or exact retained components.
- **Error posture belongs beside the value.** If a source gives confidence, relative error, upper/lower bounds, or only a point estimate, Harbor should keep that visible.
- **Mixed-exactness arithmetic needs a witness.** Exact numerators over estimated denominators should not masquerade as uniformly exact rates.
- **Exactness drift is a real change class.** Switching a lane from exact to estimate-backed or between estimate families deserves explicit lineage and review residue.


## Pass LXXI additions
- **Conformance is stronger than resemblance.** Same-looking column names do not prove shared domain contents, shared meaning, or safe drill-across.
- **Shared dimensions should grow incrementally.** A small conformed subset can be enough to align lanes now without forcing a universal entity registry.
- **Bridges need explicit time basis.** Many-to-many or changing mappings are only trustworthy when the bridge and its as-of/effective-time posture are named.
- **Higher-grain shared slices can be smaller than the base dimension.** Rollup lanes often need a shrunken conformed slice, not every low-grain attribute.
- **Canonical-looking IDs can still be shadows.** A helpful surrogate or derived alias should stay visibly smaller than final entity truth until repeated specimens prove otherwise.


## Pass LXX additions
- **Not every number rolls up legally.** Additive counts, semi-additive snapshots, ratios, and distinct/set questions are different classes of truth even when they all render as scalars.
- **Fanout is a change of question, not just extra rows.** A one-to-many join can multiply a measure unless Harbor fences the base grain explicitly.
- **Ratios should usually travel as components.** Numerator and denominator age better than pre-computed subgroup ratios that later get re-summed.
- **Distinct and set questions deserve honest posture.** Exact distinct, approximate mergeable sketches, and already-aggregated distinct counts are different promises.
- **Rollup legality belongs in the contract surface.** If a measure is unsafe across one axis or join path, Harbor should name that explicitly instead of leaving it to dashboard folklore.


## Pass LXVIII additions
- **Current and exact are different strengths.** A fresh moving head can be the best operational answer today while still being weaker than a pinned snapshot for replayability and exact review basis.
- **Freshness is computed evidence, not atmosphere.** If no threshold or calculable basis exists, that should stay visibly different from a passing freshness check.
- **Summary green is weaker than detailed evidence.** A status badge or summary-only validation run should not impersonate a richly evidenced observation with explicit measured values.
- **Contract promise and current evidence are different facts.** A published lane may keep its contract while the evidence backing today's trust reading becomes stale, partial, or unknown.
- **Moving heads need humility notes.** “Looked good at the latest head” and “reviewed exact snapshot X” should never collapse into one trust sentence.


## Pass LXVII additions
- **Presence is smaller than value bytes.** Systems that care about correctness repeatedly track whether a field was set separately from the value it happens to carry.
- **Default-looking values can counterfeit intent.** A `false`, `0`, or first enum member can be real, or can merely be the default shadow left behind when explicit presence was lost.
- **Blank is not one thing.** Unknown, not applicable, withheld, late/not-yet-materialized, and query-omitted should not collapse into one ambient null story.
- **Storage/layout absence is not automatically producer meaning.** Separate validity/definition channels exist precisely because no-value and value-bytes are different facts.
- **Constraint families must stay distinct.** Referential integrity, not-null posture, and policy suppression are different promises even when they all show up as empty-looking cells.


## Pass LXVI additions
- assertion result posture is smaller than row meaning, shape contract, and compatibility verdict.
- a missing or partial observation is weaker than either pass or fail and deserves its own visible posture.
- warning, blocking, and waived are different truths and should not flatten into one ambient "quality status."
- temporary exceptions should leave expiry-bound receipts instead of silent folklore.
- one consumer slice can be blocked by a service/freshness problem while another slice remains analytically usable.

## Pass LXV additions
- compatibility promises have different strengths; latest-only and transitive safety should never be flattened into the same word.
- alias/default-backed bridges can ease migration, but they do not prove semantic sameness.
- same-name / same-type recalculation can still be a breaking semantic change for consumers.
- retired published identifiers should not be casually reused without an explicit reservation/review note.
- requiredness increases on published surfaces are design debt magnets; treat them as breaking unless proven otherwise.

# Lessons we must learn

## Pass LXIX additions
- **One timestamp can counterfeit four truths.** Occurrence time, validity time, knowledge time, and published-cut time should not collapse into one ambient “as of now” field.
- **Transaction/system time is not automatically business-valid time.** A row can be current in storage and still be the wrong answer to “what was in force then?”
- **“As of” must name an axis.** “As of occurrence time,” “as of validity time,” “as of knowledge time,” and “as of published cut” are different questions.
- **Late arrivals mutate knowledge, not occurrence.** A backfill can be newly known without newly happening.
- **Overlap is a policy choice, not background noise.** If Harbor uses validity windows, it should say whether overlaps are forbidden, tolerated temporarily, or still unresolved.


## Pass LXIV additions
- **Not every contract tier matures together.** A lane may safely promise returned shape before it is ready to promise richer business meaning or service posture.
- **Assertions should verify meaning, not impersonate it.** Freshness, volume, schema, and anomaly checks deserve a neighboring plane instead of smuggling semantic rewrites into the row contract.
- **Consumer needs are narrower than provider fear.** A downstream user often depends on a small slice of fields, checks, and history behavior rather than the whole lane.
- **Generated checks are smaller than reviewed promise.** dbt tests, monitoring rules, and warehouse-native assertions are useful derived artifacts and should not outrank the review surface that defined the tier.
- **Tiered stability preserves optionality.** Publishing shape now can be healthier than waiting for full semantic, assertion, and SLA closure.


## Pass LXIII additions
- **Unstable surfaces need explicit maturity, not atmosphere.** Rehearsal, candidate, published, and historical are different promises and should stay different.
- **Compatibility is a contract, not a compliment.** A lane should say whether it promises nothing, latest-only continuity, additive/backward safety, or frozen history.
- **Deprecation is part of publishing.** A curated surface is not really published unless Harbor can also retire it honestly with overlap, warnings, and receipts.
- **Immutable version pointers beat moving folklore.** Published contract references should resolve to one exact family/version, not a shifting head.
- **Small modular contracts age better.** Narrow lane cards and sidecars are easier to evolve safely than one giant universal datacube schema.


## Pass LXII additions
- **Experimental lanes are cheaper than permanent mistakes.** Branch/tag-style rehearsals let a datacube test contract changes without pretending the first draft is production law.
- **Reference lifecycle matters.** Temporary rehearsal lanes, published lanes, and frozen historical tags should not share one vague retention story.
- **Live head and frozen history are different contracts.** An evolving lane can add fields while an older published snapshot still needs to stay interpretable as it was.
- **Generated artifacts are smaller than reviewed meaning.** A catalog export, semantic-model file, or engine-specific schema can be useful and still remain derived.
- **Promotion deserves a receipt.** When a rehearsal lane becomes the published lane, the archive should leave explicit adoption history rather than trusting memory.

## Pass LX additions
- **Actionable detail bodies can be interaction-specific.** Risk scores, risk profiles, and interaction IDs are useful retry aids without becoming durable grant, approval, or entitlement truth.
- **Helpful bodies still have an audience.** A resource server's actionable `authorization_details` object is aimed at its trusted authorization servers, not every nearby AS or client integration.
- **`no-store` is part of the semantics.** If an actionable body is cached or replayed later, the failure is often about stale retry material rather than wrong target, wrong account, or session collapse.
- **Metadata cache and body replay are different seams.** Ordinary metadata/schema caching can coexist with non-cacheable actionable bodies, so Harbor should keep those ages and repair stories separate.
- **Repair stays smaller than truth.** Re-fetching metadata/schema and rebuilding a retry object deserves an honest receipt, but it does not retroactively turn the old body into durable authorization truth.

## Enduring rules
1. **The browser, chooser, provider, and local app do not share one truth surface.** If Harbor flattens them, the whole ecology becomes dishonest.
2. **Clean return paths are not the same thing as durable local adoption.** Exactness, local appraisal, and explicit consequence still matter after a technically successful crossing.
3. **Verified associations, registry facts, continuity residue, and remembered routes are all useful — and all smaller than current authority.**
4. **Late policy may refine, exclude, or ask for more mediation, but it must not silently widen authority.**
5. **Same-device comfort is never stronger than issuer identity, exact return shape, and current login truth.**


## Pass LIX additions
- **Schema source is smaller than type law.** Inline schema, fetched `schema_uri`, and preconfigured local knowledge can all guide construction without becoming Harbor-owned entitlement or policy truth.
- **Receiver enrichment is real and local.** A receiver-specific JWT or introspection view can be filtered or extended for one verifier without becoming universal grant truth.
- **Cache drift deserves its own honesty.** Fetched metadata and schema guidance can become stale under ordinary HTTP caching rules, and that explanation should not be flattened into wrong target, wrong account, or session collapse.
- **Human-readable docs stay advisory.** Descriptions, examples, and docs pages can help people and still remain smaller than validation or authorization decisions.
- **Built shape is not final truth.** A client-built authorization-details object can be well-formed relative to one schema source and still differ from later granted or receiver-enriched views.

## Pass XXIII additions
- **UI posture is truthy and smaller than success.** Silent probe, conditional chooser, required interaction, and forced reauth are different aftermaths and should not be flattened into one “auth succeeded or failed” story.
- **If silent auth is impossible, the honest result is typed bottom-out, not counterfeit continuity.** OIDC `prompt=none` error families, FedCM auto-reauth rejection, and credential-mediation fallbacks all teach the same restraint.
- **Conditional mediation is still mediation.** Discoverable/passkey-style or FedCM chooser-light flows may feel smoother, but the user agent still owns disclosure and consent posture.
- **Forced reauthentication deserves its own floor.** A request that requires explicit user presence or account switching should not look the same as an ordinary chooser turn.
- **Disconnect and logout must remain real.** Browser/provider remembered-account memory may exist today and be gone tomorrow, so Harbor must preserve mismatch honesty.


## Pass XXIV additions
- Preference hints are not selections; Harbor must preserve the gap between “please prefer this” and “the chooser actually selected this”.
- Provider-managed labels and caller-supplied hints may both shape a chooser while remaining smaller than selected-account or selected-credential truth.
- WebAuthn is right to treat authenticator hints as guidance rather than binding requirements; Harbor should borrow that humility.
- When hinting mismatches current reality, the truthful next step is a typed prompt or reset, not counterfeit continuity.


## Pass XXV additions
- **Logout and disconnect are typed requests, not universal amnesia.** OIDC RP-initiated logout, FedCM disconnect, and sign-out signals can all be real while still stopping short of proving that every layer forgot the user.
- **A memory reset is valuable even when it is partial.** Silent-suppression flags, connected-account removal, and authenticator cleanup signals are useful because they change the next mediation posture without pretending every candidate vanished everywhere.
- **Cold-start after sign-out deserves its own floor.** “Come back through chooser/login again” is a different truth from generic failure and from durable account/session loss.
- **Cleanup signals are smaller than current identity truth.** WebAuthn-style credential cleanup is a great precedent for post-crossing maintenance signals that do not mint a portable selected-account or logged-out-everywhere artifact.


## Pass XXVI additions
- **A recency demand is not the same thing as recency proof.** `max_age` and similar challenges ask for an actively recent authentication event; by themselves they do not prove one already happened.
- **`auth_time` is an event receipt, not a freshness verdict.** It says when active authentication occurred, and that fact keeps aging after it is returned.
- **A newly issued token is not automatically a newly authenticated user.** OIDC and RFC 9470 both make room for returned authentication context that survives token renewal, so Harbor must not treat fresh token minting as fresh human interaction by default.
- **Freshness should bottom out honestly.** When a recency ask cannot be met silently, the right result is a typed interaction/login floor, not counterfeit “still fresh enough” folklore.
- **Decay deserves UI honesty.** Once-fresh auth should be allowed to become stale/unknown/miss rather than staying cosmetically “fresh” in chips, receipts, or route explanations.



## Pass XXVII additions
- **Security events are statements of fact, not commands.** Later auth/session drift can be important and signed without obligating one universal local consequence.
- **Later attenuation should narrow continuity without rewriting the past.** A crossing can remain historically real while its present-tense continuation becomes weaker, colder, or invalid.
- **Delivery posture is smaller than current authority truth.** Push/poll/stream state is useful operational residue, not a portable live-session oracle.
- **Receiver stance deserves its own seam.** Keep, narrow, revalidate, and cold-start are different local reactions and should not be flattened into one vague “session changed” story.


## Pass XXVIII additions
- **A match handle is not the same thing as the matched subject.** Opaque `sid`, `sub_id`, `account_id`, `userHandle`, and credential IDs can be extremely useful without becoming portable identity/session/account truth.
- **Identifier shape is smaller than subject resolution.** Structured identifier formats help the receiver parse what it got, but they do not settle what kind of principal it is or how local state should resolve it.
- **Correlation thrift matters.** Combining multiple identifiers can reveal more than intended, so Harbor should preserve match basis without normalizing giant identifier bundles.
- **Mismatch deserves its own honest path.** “Parsed but not safely matched here” should quarantine or revalidate rather than silently overreach.
- **Scope should stay visible.** Issuer-, provider-, RP-, credential-, and session-scoped handles should never quietly masquerade as global truth.


## Pass XXIX additions
- **Status adverts are smaller than login truth.** Browser/provider-local states such as `unknown`, `logged-in`, `logged-out`, `changed`, or `unchanged` can materially shape the next crossing without settling durable account/session truth.
- **Changed means verify, not assume.** OIDC-style session change signals should trigger a re-check turn, not counterfeit immediate logout or success.
- **Mismatch deserves a visible floor.** When remembered status and fetched reality disagree, the honest move is a mismatch dialog, chooser, or login turn rather than magical smoothness.
- **Unknown is honest.** Harbor should preserve `unknown` as a first-class outcome instead of forcing every crossing into positive or negative certainty.
- **Absence should not leak cheaply.** Platforms that refuse to instantly reveal “no candidates here” are teaching the right privacy lesson for Harbor too.


## Pass XXX additions
- **Waiting is not failure and not success.** A crossing can be honestly in flight without needing to counterfeit smooth completion or generic error.
- **Backoff is real truth.** Signals like `slow_down` are worth preserving because they shape safe next behavior without deciding the crossing.
- **Refusal, abandonment, and expiry are different endings.** Explicit denial, user dismissal, and expired pending windows should not be flattened together.
- **Quiet cold endings deserve honesty.** A dismissed chooser or non-modal dialog is not approval, but it is also not always a crisp “denied” verdict.
- **Pending windows must terminate cleanly.** When a protocol says the in-flight interval concluded, Harbor should record expiry rather than spinning forever.


## Pass XXXI additions
- **Exact replay only beats magical resume.** Reloads, repeated callbacks, repeated proofs, and retry-after-uncertainty should only be allowed to replay the same canonical crossing, not mutate it.
- **Duplicate-suppressed is useful truth.** A replay that produced no new effect still deserves honest residue instead of disappearing into folklore.
- **Spent crossing material should stay spent.** One-shot or limited-use codes, proofs, and handles should degrade into consumed or expired residue rather than pretending to be resumable authority.
- **Replay evidence is smaller than present authority.** Even good replay detection or clone-detection signals should narrow or explain local handling without overgrowing into portable session/account truth.
- **Late duplicates still teach.** A duplicate arrival can be historically real and operationally useful even when it must not spend consequence twice.


## Pass XXXII additions
- **Cancellation is coordination, not verdict.** Caller aborts, chooser dismissals, and local deadlines are real crossing truths, but they do not automatically prove what the provider or remote side decided.
- **Abort should stay distinct from refusal.** WebAuthn is right to separate `AbortError` from catch-all `NotAllowedError`; Harbor should preserve that honesty instead of flattening every stop into denial.
- **Deadlines deserve their own floor.** “We cannot honestly wait any longer on this lane” is different from provider refusal and different from universal failure.
- **Completion can race cancel.** A local stop signal may arrive before, during, or after remote completion, so Harbor should keep local stop residue and late-result residue visibly compatible instead of pretending only one can be true.
- **Dismissal can leave local residue.** FedCM-style cooldowns after dialog dismissal teach that abandoned chooser UI can shape the next attempt without settling durable identity/session truth.


## Pass XXXIII additions
- **A lane binder is smaller than current ownership.** `state`, `nonce`, PKCE binders, and WebAuthn challenges help prove which attempt a result belongs to, but they do not by themselves settle durable session/account truth.
- **Restarted or superseded lanes deserve honest fences.** Once a fresher lane exists, an older lane can remain historically real without retaining adoption rights.
- **Late valid-looking results may still be stale here.** Structural validity is not enough if the result no longer matches the live lane the local side is willing to adopt.
- **Quarantine beats counterfeit resume.** A late old-lane completion should bottom out as inspectable stale residue rather than being silently adopted or erased.
- **Only the live lane should spend local consequence.** Harbor should preserve current-lane ownership without inventing a portable session/watch plane.


## Pass XXXIV additions
- **Fetched discovery is smaller than admitted truth.** Well-known metadata, config files, and server-refreshed rules can all be precise and useful without settling whether the local side should actually route, trust, or adopt.
- **Exact metadata identity checks matter.** RFC 8414 and RFC 9728 are right to require exact issuer/resource matching before metadata is used; Harbor should treat discovery exactness as a safety property, not an implementation detail.
- **Resolved overlays should stay visible.** Trust-chain policy resolution, manifest ceilings, and other bounded overlays are great precisely because they refine raw discovery without erasing where it came from.
- **Cache age deserves its own seam.** A fetched description can be useful and still too old, mismatched, or refresh-needed for current admission.
- **Support listings are hints with edges.** Enumerated authorization servers, endpoints, labels, or paths improve explanation and narrowing, but they are still smaller than current route ownership or durable trust.


## Pass XXXV additions
- **Support adverts are smaller than negotiated path truth.** Capability lists, feature flags, and supported-method declarations can narrow the candidate space without settling what will actually work here now.
- **Absence can hide defaults or partiality.** Omitted fields and intentionally incomplete support lists mean “not advertised” is not always the same as “unsupported.”
- **Hints are not requirements.** Caller/browser/provider/credential hints can improve UX while remaining non-binding on the final path.
- **Negotiated path deserves its own witness.** The exact method or path that actually survived is stronger than an advert or hint and should not be reconstructed from folklore later.
- **Unsupported-here honesty beats counterfeit capability.** When a listed or hinted option does not land locally, Harbor should preserve that mismatch plainly instead of pretending broader support existed.


## Pass XXXVI additions
- **assurance ask** — typed request for a stronger or more specific authentication/verification rung.
- **achieved rung** — inspectable statement of the actual assurance class or verification rung that survived here.
- **method receipt** — compact evidence about the methods or verification properties actually used.
- **unable-here honesty** — explicit local bottom-out when the requested rung cannot be met or proven here now.
- **method smaller than achieved rung** — standing anti-regrowth rule.



## Pass XXXVII additions
- **A requested fact is not a released fact.** OIDC is right to keep requested Claims separate from the Claims that actually come back.
- **A released bundle is not adopted local truth.** Even a rich set of outside-supplied facts can remain chooser/display/review material instead of local subject or account adoption.
- **Provenance deserves its own seam.** Aggregated/distributed claims and multi-source account data should not dissolve into one flat “profile blob.”
- **Display-facing identity strings need boundaries.** WebAuthn is right to insist that display-bound account strings be visually contained instead of allowed to blur into surrounding UI.
- **Omission is honest.** Harbor should preserve partial release and missing facts without faking either success or error.


## Pass XXXVIII additions
- **Prompt provenance matters.** RFC 8252, FedCM, and WebAuthn all teach that where a prompt lives is a real safety property, not decorative chrome.
- **Reviewed summary is smaller than grant truth.** A good summary can be derived from structured or protected request basis without becoming the grant, account, or session truth itself.
- **Requester copy is not canonical review.** App text, widget chrome, and provider marketing copy can be helpful, but they must not silently masquerade as the trusted review surface.
- **Consent, presence, and verification are neighboring but non-identical facts.** WebAuthn is right to keep authorization gesture, user presence, and user verification distinct enough to inspect separately.
- **Missing trusted review deserves honest bottom-out.** When Harbor cannot say the review surface was host/browser/authenticator-owned, it should say so plainly instead of counterfeiting approval.


## Pass XXXIX additions
- **Exact review basis beats floating prose.** Structured and integrity-protected asks are much safer anchors for review than arbitrary nearby copy.
- **Chooser/UA-owned prompts deserve explicit provenance.** A review surface that is distinguishable from requester UI is a materially different fact from requester-rendered chrome.
- **Displayed summaries need visible boundaries.** WebAuthn is right that displayed account fields should stay bounded and not bleed into surrounding UI.
- **Stale reviewed basis deserves typed denial.** A summary that was once correct should fail closed once the reviewed basis drifts.
- **Requester copy is smaller than trusted review.** Marketing text, widgets, screenshots, or copied summaries must not silently become approval truth.


## Pass XL additions
- **Review should stay on bounded cards.** Long merged asks can still be honestly reviewed, but the shown surface should remain one bounded card instead of free-floating prose.
- **The requester/RP cue deserves its own seam.** Credential choosers and authenticator/browser prompts are strongest when they carry an explicit origin or RP cue.
- **Displayed fields need hard containment.** WebAuthn is right that displayed account strings should not bleed into surrounding UI.
- **Shortened display should admit itself.** A cropped, collapsed, or truncated card is still real history, but it is not the same as full reviewed basis.
- **Display is smaller than reviewed basis.** Even a good host-owned card should stay smaller than exact ask, durable approval, grant, account, or session truth.


## Pass XLI additions
- **Visual aids help humans but remain smaller than truth.** Caller names, logos, account pictures, and account labels can improve recognition while still remaining weaker than issuer truth, selected-account truth, and reviewed approval basis.
- **Origin provenance can stay explicit without showing everything.** Origin-scoped cues are often enough for host-owned chooser trust; Harbor should resist overreaching into full path or callback disclosure unless the basis really requires it.
- **Chooser images are a privacy surface.** Image fetch timing can leak chooser use, so Harbor should treat preview assets as a bounded, privacy-sensitive aid rather than harmless decoration.
- **Filtering is not verdict.** Hidden or filtered accounts, labels, and badges shape candidate space but do not by themselves say an account is absent, adopted, or durably trusted.
- **Preview chrome should admit its limits.** A cached, transformed, omitted, or stale preview is still useful history, but it must not masquerade as canonical truth.


## Pass XLII additions
- **One displayed party is not always enough.** A host-owned surface may need to name both the embedding site and the embedded requester when those are meaningfully different.
- **A structured return package is still smaller than durable truth.** Better packaging can improve inspection and ergonomics without settling issuer, account, approval, or session truth.
- **Exact binding still beats pretty UI.** Exact issuer, redirect, request-basis, and live-lane checks must outrank attractive review surfaces and tidy payload shapes.
- **Design-phase hygiene is a semantic defense.** If a new noun cluster cannot explain why it is still small, the archive is already drifting toward counterfeit permanence.
- **Same-revision promotion rules preserve honesty.** When a second close sibling appears, the archive should either compress or explicitly structure the seam in that same revision instead of accumulating side-lore.

## Pass XLIII additions
- **brand sameness is not context sameness** — the same provider label, issuer, or email can still belong to the wrong toolkit, tenant, or lane.
- **finish callback is smaller than consequence** — a callback/finish only earns weight after exact local context and finish proof validate.
- **same-context or nothing** — standing anti-regrowth rule: local adoption rights belong to the exact context that started the crossing.
- **path tricks are not identity** — clever callback or metadata path parameters are weaker than exact known endpoint and origin/client checks.
- **cleanup can be honest without being truth** — future chooser/credential refresh signals may be useful while staying smaller than durable account truth.


## Pass XLIV additions
- **window lane is smaller than result truth** — a finish arriving on `opener` versus `parent` is real residue, but it is still weaker than durable adoption.
- **both ends of browser messaging matter** — exact receiver origin and exact sender origin are separate safety checks, and popup polish should not blur them.
- **origin-scoped return can widen the leak surface** — moving a finish from redirect path to `postMessage` origin changes what nearby XSS can see.
- **browser messaging needs explicit quarantine paths** — a plausible message on the wrong lane or wrong origin should bottom out as visible residue, not counterfeit success.
- **issued target is smaller than durable consequence** — future issuance-time target echoes may help without becoming durable local truth.


## Pass XLV additions
- **The inter-device gap is not self-authenticating.** Cross-device flows still ask humans to bridge an unauthenticated channel between the device that started the request and the device that approves it.
- **A shared code or binding message is a cue, not a verdict.** Matching `user_code` or `binding_message` helps users interlock two screens, but it does not by itself settle issuer, account, session, or adopted consequence truth.
- **Cross-device should stay cross-device.** Reusing a cross-device protocol on the same device is not a harmless convenience path; it changes the threat model and may deserve a visible veto or downgrade.
- **Notification should stay smaller than result.** A ping or callback stub that merely tells the client which continuation to resume is safer Harbor material than a callback that tries to masquerade as the full durable result.
- **Transaction-bound keys are clever but still smaller than adoption.** Binding a device flow continuation to one DPoP key is a strong future idea, but it still belongs below durable local truth.

## Pass XLVI additions
- **Cleanup signals are valuable even when they are advisory.** Hiding or suppressing stale chooser entries improves honesty without pretending the browser or authenticator instantly proved universal account deletion or logout.
- **Remembered candidates can go stale before UI catches up.** A chooser entry that still appears plausible may already deserve local quarantine or revalidation.
- **A refreshed label is not adopted identity.** Better account names or display strings help future selection, but they do not settle durable subject or account truth.
- **Best-effort cleanup is still smaller than durable state change.** Capability gaps, unattached authenticators, and periodic retries are clues that cleanup pulses and display refreshes should remain residue.
- **Sign-out can reset mediation without proving universal logout.** Changing the next-time credential-return posture is a real fact, but it is much smaller than revocation, disconnect, or full state erasure.


## Pass XLVII additions
- **Issuer sameness is smaller than endpoint sameness.** A nearby issuer or provider label can still hide the wrong PAR, token, or other security-relevant endpoint.
- **Audience basis deserves explicit capture.** JAR-style issuer audiences and client-assertion exact-endpoint audiences are both valid, but they are not the same fact.
- **Exact request target is a real crossing fact.** DPoP-style `htu` checks show that the exact HTTP target URI can carry security meaning without becoming durable grant or account truth.
- **Alias-friendly convenience needs a visible veto.** Same-brand or same-host-family endpoint aliases should fail honestly when they do not match the exact target basis that the flow requires.
- **Returned target cues are helpful and still smaller than grant truth.** A token response telling you which resource survived issuance can improve explanation without settling durable adoption or authorization meaning.


## Pass XLVIII additions
- **Requested target is not issued target.** A client can ask for one protected resource and still receive a token whose effective target was narrowed, substituted, supplemented, or left unbounded.
- **Discovery-time routing is smaller than issuance-time confirmation.** Resource metadata and RS-first discovery can point toward the right authorization server without proving what target the issued result actually covers.
- **Exact proof target still matters after discovery.** DPoP-style `htu` exactness is valuable residue even when the interesting business question is which protected resource survived issuance.
- **Missing returned target deserves typed honesty.** When a result comes back without specific target bounds, Harbor should say so plainly instead of backfilling certainty from the request.
- **One target family would be premature.** Requested target, proof target, discovered route, and issued target are neighboring facts, not one portable truth object.


## Pass XLIX additions
- Discovery source changes the safety rule: exact direct metadata, relaxed challenge-derived metadata, and token-exchange target discovery should not be flattened into one generic route-truth story.
- Candidate target services are scoped hints, not a global catalog: what is available can depend on both the subject token and the authenticated client.
- Breadth compounds quickly: multi-resource and multi-audience asks can become wider than they look, so Harbor should keep negotiation residue visible.
- Subset survival deserves typed honesty: a narrowed returned target set is different from intact acceptance and different again from `invalid_target` refusal.
- Typed refusal beats counterfeit entitlement: when nothing acceptable survives, refusal is healthier than pretending the original ask quietly won.


## Pass L additions
- **Token-time narrowing is smaller than grant truth.** RFC 8707 is right that token-endpoint `resource` values for authorization-code or refresh-token turns are restrictions within what the grant already allowed, not fresh durable entitlement creation.
- **Refresh must not widen silently.** A later refresh may ask for less, but Harbor should never let it counterfeit more.
- **Returned resources can be partly asked-for and partly assigned.** A scope- or policy-derived extra resource can be real while still being smaller than exact request mirroring or durable entitlement truth.
- **No-request results need typed honesty.** A response that omits `resource`, or returns only assigned resources, should not be overread as exact requested-target confirmation.
- **Target refusal is its own ending.** `invalid_target` is better modeled as typed refusal than as vague auth failure or universal denial.


## Pass LI additions
- **Omission is not confirmation.** A missing `resource` value can mean assigned specificity or no resource-specific restriction, but Harbor should not backfill exact requested-target confirmation from silence.
- **Discovery and confirmation are different strengths of fact.** Dynamic route discovery can be useful while still remaining smaller than issuance-time resource confirmation.
- **Requested anchors matter.** If a client asked for resources, at least one requested anchor needs to survive the response before Harbor should treat the turn as resource-confirmed.
- **Preconfiguration earns only weaker grace.** Prior local knowledge may justify weaker continuation when confirmation is absent, but it is still smaller than fresh issuance-time proof.
- **Strict clients should discard ambiguity.** When the client depends on dynamic discovery or strict resource binding, missing confirmation is better treated as discard than as a guess.



## Pass LIV additions
- **Signed introspection is still receiver-facing.** A JWT-secured introspection response can strongly authenticate what the authorization server told one protected resource without becoming generic client-facing exact-resource proof.
- **Recipient and token target facts are different.** The signed recipient of an introspection JWT and the nested audience-like token metadata are related but distinct facts.
- **Returned resource outranks audience folklore for clients.** When explicit `resource` confirmation exists, it is stronger client-facing evidence than introspection or self-inspected audience hints.
- **Receiver-local fit still decides.** A protected resource can still refuse the turn even when the signed introspection response and token audiences both look plausible.
- **Cryptographic strength does not erase semantic modesty.** Signed wrappers deserve more provenance credit, not automatic promotion into durable adoption or entitlement truth.

## Pass LIII additions
- **Introspection audience is receiver-facing, not client certainty.** RFC 7662 gives the protected resource audience-like token metadata, but those values are still service-specific identifiers rather than a portable concrete resource oracle.
- **Receiver expectation is a real seam.** A protected resource’s own accepted audience identifiers or aliases matter, and a structurally valid token can still deserve refusal here.
- **Audience restriction is stronger than plausibility.** OAuth 2.1 is right that tokens should be audience-restricted and the wrong receiver must refuse them.
- **Audience and returned resource are different strengths of fact.** Token-format evidence can help explain coverage while still remaining smaller than explicit returned `resource` confirmation.
- **Confidence should stay runged.** Response-confirmed, receiver-locally-accepted, and token-format-only target confidence should not collapse into one generic success bit.

## Pass LII additions
- **default-target cue** — a token-format or policy-derived hint about likely protected-resource scope that remains smaller than exact client-facing confirmation.
- **coverage note** — a local note that challenge-derived protected-resource metadata covered the requested URL by same-origin path-prefix rules.
- **confirmation-gap receipt** — typed aftermath honesty that exact client-facing confirmation stayed missing, malformed, or weaker than discovery/cue posture suggested.
- **audience smaller than confirmation** — standing reminder that JWT `aud` and token-response `resource` are not the same fact.
- **broader coverage smaller than exact issuance truth** — standing anti-regrowth rule.


## Pass LV additions
- **Recipient and token target facts are different.** A JWT-secured introspection response can be signed to one exact protected resource while the nested token metadata still names broader or differently shaped target identifiers.
- **Default or mapped audience is smaller than explicit confirmation.** A default `aud` or mapped audience value can help routing and receiver checks without becoming the client’s strongest exact-resource fact.
- **Introspection stays receiver-scoped.** Different protected resources can legitimately see different introspection answers or scope slices for the same token.
- **Alias drift deserves a typed ending.** Same-origin or same-family cues can still bottom out in a visible local mismatch when the receiver’s accepted identifier family narrows or changes.
- **Signed provenance does not erase semantic modesty.** Cryptographic strength should upgrade our confidence in who got told what, not flatten target meaning into one universal truth object.

## Pass LVI additions
- **receiver-scoped disclosure note** — one resource server's introspection answer can legitimately expose a narrower scope slice than broader token folklore suggests; do not flatten that into portable token truth.
- **stronger-here challenge rail** — a token can be target-valid for this receiver yet still insufficiently authenticated for this operation here and now.
- **coverage-drift note** — broader challenge-derived protected-resource coverage is useful for discovery, not proof that every deeper path shares one operation policy.


## Pass LVII additions
- **Required type combinations are smaller than a global authorization grammar.** Protected resources can advertise acceptable `authorization_details` combinations without authoring Harbor’s permanent ontology.
- **Actionable missing-details bodies are offers, not approvals.** A resource server can help the client build the next OAuth + RAR turn without thereby proving durable entitlement truth.
- **Requested, granted, and RS-visible details can legitimately differ.** RAR already allows enrichment, filtering, or omission across request, token response, and introspection views.
- **Step-up and richer authorization should not collapse into one hierarchy.** Stronger authentication, missing scope, and missing authorization details can all be real at once and still need distinct endings.
- **Type slates should stay local for now.** Harbor should collect them as discovery/challenge residue rather than minting a portable authorization-policy registry while the cube is still embryonic.


## Pass LVIII additions
- **Granted detail views are smaller than durable entitlement.** Token-response `authorization_details` say what this token got, not what permanently exists everywhere.
- **Receiver-filtered detail cards are legitimately receiver-scoped.** JWT or introspection-visible details can be filtered or extended for one audience or RS without becoming universal grant truth.
- **Schema mismatch deserves a typed veto.** Wrong field types, unknown fields, invalid values, and missing required fields should bottom out plainly rather than being coerced or over-read.
- **Schema guidance is not policy truth.** Metadata `schema` / `schema_uri`, examples, and descriptions can help construction and validation without becoming Harbor’s permanent authorization language.
- **Requested, granted, and receiver-visible details can all differ honestly.** Harbor should keep those views separate while the cube is still embryonic.


## Pass LXI additions
- **grain first or confusion forever** — if Harbor cannot say what one row/card/receipt represents, every later dimension or metric family becomes suspect.
- **atomic history beats clever summaries at design time** — early rollups optimize for the questions we happen to have today; atomic grain survives the ones we have not discovered yet.
- **late context is normal, not an exception path** — facts, dimensions, corrections, and restatements arrive out of order, so Harbor needs typed completion/restatement honesty.
- **physical layout is smaller than semantic truth** — partitioning, clustering, and storage tricks can change without changing what the curated Harbor contract means.
- **additive evolution is healthier than semantic rewrite** — a new field or annotation should usually enter via a smaller sidecar/facet or explicit evolution lane before it mutates old meaning.
- **contracts belong on curated surfaces** — downstream stability should attach to deliberate Harbor views/cards/receipts, not every raw ingest or intermediate representation.
- **optional metadata should earn promotion** — versioned facets are a safer first home for new hints than immediate core-schema inflation.
- **change history is part of the product** — requested change, completed change, and restatement are useful facts in their own right.


## Pass LXXIII additions
- **state is not history** — a current-state lane can answer present-tense questions while still being weaker than an audit trail.
- **changed rows are not all changes** — an incremental export that returns the latest values for changed rows is useful and still smaller than ordered change history.
- **net diffs are not replay logs** — the surviving delta across two cuts is a different promise from every intermediate change in between.
- **physical rewrite is smaller than logical change** — copy-on-write carry-over rows and compaction artifacts must not counterfeit business history.
- **restated history needs a receipt** — when published history changes because late data or corrected logic arrived, Harbor should leave explicit residue instead of pretending the new answer was always true.


## Pass LXXVII additions
- **A unit is not a suffix.** Source unit, canonical machine unit, and display unit need separate cuts before a scalar-looking lane can be trusted.
- **Percent is a rendering trap.** Unity-stored ratios can render as percents, but a dashboard cell must not multiply twice or store percent points under a unity contract.
- **Money conversion is not physics.** Currency codes are necessary, but an exchange-rate comparison is a dated, sourced, restatable derived view.
- **Logical type is not semantic proof.** Parquet logical annotations, Arrow validity, and Avro aliases/defaults can bridge physical representation, but they do not prove quantity family, presence cause, or meaning equivalence by themselves.
- **Pivot output is not rollup authority.** Cube, rollup, grouping-set, and pivot shapes are useful review artifacts, not proof of additive legality, conformance, exactness, or history posture.
- **Sidecars explain; they do not authorize.** Row lineage, statistics blobs, sketches, facets, and watermarks are optional evidence unless a proof packet says otherwise.
- **Rollback must account for mutable data.** A derived view, rate restatement, or schema migration can make old code or old answers unsafe unless rollback barriers and snapshot/cut evidence stay explicit.
- **Promotion needs a proof packet.** The new proof-obligations surface is the anti-counterfeit membrane between good ideas and premature Harbor vocabulary.

## Pass LXXVIII additions — semantic exports
- Semantic front doors are derived lenses with refusal surfaces; they are not authority planes.
- Public contracts should expose only the assertion subset they mean to promise, not every internal validation result.
- Freshness needs a basis: source cut, built-at/published-at time, threshold, age calculation, time axis, and explicit non-promises.
- Join relationships are proof obligations, not product settings; fanout refusal is a feature, not a missing dashboard.
- Row-lineage sidecars are scoped, partial, and optional; they are not person, account, subject, or universal row identity.
- A generated semantic model can make safe questions easier, but it must make unsafe questions easier to refuse.


## Pass LXXIX additions
- **Observation shape is not an ontology.** Explicit dimensions, measures, and attributes make an export legible, but they do not settle Harbor's public API or SlopOS's final datacube model.
- **Views own definitions, not rows.** A versioned derived view can be a useful receipt only while it names source cuts, dialect/query basis, and invalidation conditions.
- **Sidecars are evidence, not contract upgrades.** Statistics, sketches, facets, and row-lineage blobs help plan and debug, but their absence is not data absence and their presence is not identity or exactness proof.
- **Frontiers have domains.** Event-time watermarks, logical read/write frontiers, published cuts, and export build times answer different questions and must not collapse into one freshness badge.
- **Compilers and transforms need downgrade receipts.** Generated assertion targets and schema transforms must name preserved semantics, unsupported semantics, and non-equivalence warnings.

## Pass LXXX additions
- **Negative evidence needs scope, not swagger.** A missing sidecar, blocked export, unsupported compiler target, stale frontier, or tombstone is evidence about one basis and one question; it is not proof that data is absent, false, complete, or permanently unreplayable.
- **No-result is a result posture.** Unsupported assertion compilation should stay visibly different from pass, fail, warn, or waived. Silent target downgrades are counterfeit contract evidence.
- **Refusal copy has two audiences.** Consumer-visible refusal should be bounded and non-leaking; operator-visible refusal should retain basis, missing proof obligation, safe alternative, owner/recheck trigger, and expiry.
- **Tombstone is not null.** A withdrawal marker, delete file, or compacted tombstone can make current lookup negative while history, replay evidence, and identity-reuse hazards remain real.
- **Stale progress narrows claims.** A stale event-time watermark or wrong-domain frontier should turn a fresh-through claim into preview/as-of/refuse, not into a generic stale-data badge.
- **Retention windows are design pressure.** The next hard problem is not only whether a cube-shaped answer was correct then; it is whether Harbor can still reproduce or only explain that answer after cuts, tombstones, sidecars, and correction evidence expire on different clocks.


## Pass LXXXI additions
- **Historical answerability has modes.** Exact recompute, exact frozen answer, partial replay, explainable-not-replayable, unsafe-to-answer, and restated successor are different outcomes.
- **A survivor set beats time-travel folklore.** A historical answer needs retained base cuts, sidecars, tombstones, query definitions, policy epochs, and runtime semantics as applicable; one surviving artifact is not the whole proof.
- **Cleanup is a semantic event for consumers.** Vacuum, snapshot expiration, cleaning, compaction, frontier advancement, and tombstone expiry may be operational optimizations, but they can destroy an exact old-answer path.
- **Frozen output is not recomputation.** A preserved answer packet can be useful and exact about what was published then, but it does not prove current truth or raw-row replayability.
- **Emergency recovery is not ordinary query access.** Fail-safe and support-mediated recovery may save data from disaster, but that is a different promise from consumer-ready historical query.
- **Retention windows are plural.** Base data, transaction logs, delete markers, sidecars, assertions, policy histories, rates, and runtimes expire on different clocks; Harbor must not pretend one retention number governs the cube.


## Pass XCV additions
- **Executable humility beats prose humility.** If a crossing noun matters, it should have a positive fixture, a negative fixture, digest binding, scope comparison, non-promises, and a checker.
- **Route family decides the refusal set.** Portal, durability, callback, MCP/tool, browser credential, and public-copy aftermath records fail in different ways, so one generic `not trusted` label is too weak.
- **A rejected candidate should leave no record id.** Rejection residue can explain pressure without creating the very durable truth it refused.
- **Latest evidence is not scope algebra.** Later tickets and banners cannot bypass same/narrower/overlap/incomparable comparisons.

## Pass XCVI additions

- A transparency or provenance receipt is useful only after Harbor names which layer it speaks for: receipt existence, subject binding, currentness, verifier policy, or aftermath.
- Inclusion is not truth. Manifest binding is not real-world authenticity. Build provenance is not dependency cleanliness. Timestamping is not event time.
- Currentness is plural: none, checkpoint-only, timestamp-only, recheck-required, or policy-epoch-bound.
- Redacted and derived proofs should be allowed to prove selected claims without becoming full-evidence entitlement.
- Issuer compromise is a recheck trigger, not a magic button that turns all past receipts true or false.
- Any receipt-import noun without positive fixtures, hostile fixtures, digest binding, currentness cuts, verifier epoch, and non-promises is still only prose.


## Pass XCVII additions

- Verifier disagreement should be preserved as evidence, not arbitrated into one badge.
- Policy id, policy digest, policy epoch, input digest, and currentness basis matter before two verifier decisions can be compared.
- Currentness unknown is not fresh. Issuer compromise is a recheck trigger, not automatic truth or automatic falsity.
- Public badge posture is safer when withheld, split, scoped, recheck-required, or prior-epoch-with-notice than when green/resolved/all-clear.

## Pass XCVIII additions

- Passing deterministic fixtures are not enough; checkers need targeted mutations that prove they reject predictable counterfeits.
- Generated cases should retain operator names, invariant labels, baseline digests, mutant digests, checker reasons, and shrink notes.
- Killed/survived is a diagnostic, not a correctness proof, compliance proof, or coverage badge.
- A survived mutant should create triage pressure: checker gap, intentionally equivalent mutation, out-of-scope pressure, or new hand-authored hostile fixture.
- Property-style pressure is useful precisely when Harbor refuses to let generated conformance suites replace specimen discipline.

## Pass CI additions

- A source-tree fixture cannot contain the final archive digest without creating a bootstrap lie; final zip digest belongs after packaging.
- Deterministic ZIP metadata is useful evidence, but it is not a general reproducible-build claim across unknown builders.
- Archive-index coherence is inventory evidence, not a signature, attestation, CI badge, or package trust root.
- Build-environment capture should make hidden inputs visible while refusing to prove portability or same-build status elsewhere.
- A release receipt must reject embedded stale release zips and stale root names before downstream consumers can treat a package as current.

## Pass CII additions

- Do not let a filename stand in for bytes.
- Do not let a pasted digest stand in for possession of material.
- Do not let an upload timestamp become freshness or currentness.
- Do not let callback success become verification.
- Do not let consumer acknowledgement become reliance, security, compliance, or downstream copy state.

## Pass CIII additions

- **A verified import is not a future derivative warranty.** Every annotation, summary, subset, index, cache, re-export, and sync copy needs its own scope and invalidation posture.
- **Derivatives need target digests.** A local annotation or generated explanation without source/target digest posture is commentary, not status.
- **Search hits are not truth.** A local index can accelerate finding material, but it does not prove currentness, correctness, compliance, or repair.
- **Cache hits age differently from sources.** Cached explanations must carry revision/digest basis, expiry, and invalidation triggers.
- **Local repair is not upstream repair.** A consumer patch may be useful, but it does not repair the source or all derived copies.

## Pass CIV additions
- A correction is the start of derivative repair work, not the end.
- Notice delivery, read observation, application, acknowledgement, invalidation, quarantine, and repair are separate states.
- A notice-only acknowledgement can be a valid record precisely because it refuses repair.
- Quarantine preserves uncertainty; it does not fix stale material.
- Wrong target digest repair acknowledgements are worse than missing acknowledgements because they counterfeit precision.

## Pass CV additions

- Retention is evidence availability, not currentness.
- Expiry is a recheck cut, not proof of failure or repair.
- A hold can preserve evidence while saying nothing about freshness.
- Compaction and privacy minimization need tombstone subject digests or they become clean-slate theater.
- A later source correction can make yesterday's repaired derivative stale without erasing the historical repair receipt.


## Pass CVI additions

- Correction epochs are partial-order evidence, not global truth.
- Latest correction is not the default winner; oldest receipt is not current repair.
- A derivative repaired under epoch A can be useful history and stale for epoch B at the same time.
- Scope overlap decides whether epochs can coexist, split, dispute, or require recheck; it must not widen field repair to whole-artifact currentness.
- Rollback is a new branch with recheck pressure, not an eraser for intermediate warning history.
- Public green badges are unsafe across mixed-epoch derivatives; split/scoped/disputed/recheck-required cards are safer.

## Pass CVII additions

- Cross-cube lineage import must enter Harbor as quarantined material: cube id, foreign revision, archive digest, fragment family, parent context, and local observation clock before any status conversation.
- Companion evidence is useful precisely because it is bounded. SlopOS can order, Foundry can label, Steward can record attempts, Schell can contextualize retention, ViewFS can show volition evidence, Ward can route delegation, and Helm can trace repairs; none of those facts inherit Harbor authority.
- Scope translation is the first safety rail after identity. If native scope cannot be mapped to Harbor scope, the import remains historical, sealed, incomparable, or rejected.
- Majority across companion cubes is a counterfeit tribunal unless Harbor has an explicit policy/clock/scope basis. Incomparable fragments are safer than a green badge.

## Pass CIX additions

- Propagating a revocation overlay is not the same as proving it was read, applied, repaired, compliant, or globally mirrored.
- A public warning card should prefer split, scoped, history-preserving language over badge collapse.
- Generated summaries must carry source digests, scope, and non-promises or they become stale-status amplifiers.
- Shared checker helper code reduces drift only while it refuses to become a schema or trust root.

## Pass CX additions

- A user-visible explanation is not a badge; it is wording plus scope, digest, caveat, and history posture.
- Clear wording can help users act, but it does not prove comprehension, consent, reliance, or repair.
- Status messages need text and programmatic posture; color alone is not explanation.
- A localized variant needs source digest and provenance before it can carry overlay meaning.
- Machine-readable reason codes should travel with human wording, not replace it.
- Action affordances should inspect, recheck, or export evidence before they imply repair.

## Pass CXI additions

- A response event is an interaction trace, not comprehension, consent, reliance, repair, or compliance.
- Parent explanation digest is the minimum anchor for interpreting a response; without it, the event floats free of the words and scope it supposedly answers.
- Follow-up action is not outcome: recheck requested is not recheck passed, appeal started is not appeal granted, retry scheduled is not repair.
- Response telemetry needs minimization, expiry, and pseudonymous actor posture before it is safe to keep.
- Landing-page executable counts should be derived from the registry, not retyped as fragile prose.
