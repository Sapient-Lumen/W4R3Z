# SlopOS / companions evaluation — pass XLIX

This pass re-checks Harbor against SlopOS and the sibling cubes after adding a discovery-source / narrowing specimen, and again chooses one narrow crossing seam over any early family bloom.

## What the current cubes still teach
- **SlopOS** remains the strongest restraint mechanism. Its provider-local auth discovery, metadata fetch, exact-match posture, and imported-auth-context boundaries already keep discovered routes, fetched descriptions, and local admission separate from durable portable truth. That lines up cleanly with Harbor treating discovery source and candidate targets as crossing residue rather than as a global target-service map.
- **SlopOS** also reinforces a process lesson: route/discovery details can matter deeply without graduating into a portable registry. Harbor should borrow that humility directly for challenge-derived metadata, exact direct metadata, and token-exchange target discovery.
- **Ward** again reinforces the exact-basis instinct: when discovery source changes the validation rule, the exact basis must stay visible or later acceptance becomes counterfeit certainty.
- **Helm** keeps contributing subset honesty: a smaller affected set is often the truthful answer, and the truthful answer should remain inspectable rather than bloating into a giant family.
- **Foundry** keeps the aftermath lesson alive: an outside narrowing or refusal can stay real aftermath without silently becoming durable local entitlement truth.
- **Steward** keeps the accountability lesson alive: typed refusal (`invalid_target`) and narrowed subsets deserve explicit receipts, not generic “something changed” blur.

## Harbor consequence
Harbor should keep this move modest:
- add one specimen around **discovery-source note**, **narrowed-target subset**, and **target-negotiation rail**;
- keep discovery provenance, candidate targets, explicit request breadth, returned subset/refusal, and durable grant/adoption meaning visibly separate;
- collect **authorized-candidate slate** and **grant-bounded narrowing floor** as inspiration only;
- and leave any future registry of target catalogs, portable entitlements, or negotiation ladders outside Harbor for now.

## Still-not-yet decisions
- Whether **discovery-source note** deserves its own Harbor family, or should remain only an annotation on request/discovery surfaces.
- Whether **narrowed-target subset** belongs in Harbor at all, or should remain only a smaller aftermath note attached to specific auth specimens.
- Whether **target-negotiation rail** belongs in Harbor, or should stay a typed local explanation that never blooms into a portable target-service or entitlement registry.
