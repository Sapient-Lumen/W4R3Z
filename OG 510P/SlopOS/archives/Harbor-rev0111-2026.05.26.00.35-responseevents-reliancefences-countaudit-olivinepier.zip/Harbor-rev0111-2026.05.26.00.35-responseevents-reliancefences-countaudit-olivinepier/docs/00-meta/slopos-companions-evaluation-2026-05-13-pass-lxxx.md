# SlopOS / companions evaluation — pass LXXX

This pass asks how Harbor should evaluate `F075` while SlopOS's datacube is still in design phase. The answer is to make negative outcomes reviewable without letting negative residue become a hidden constitution.

## SlopOS lessons used directly
- **Exports fail closed.** SlopOS RFC-0076 treats observation export as an exfiltration surface and requires explicit policy, bounds, allowlists, and fail-closed behavior. Harbor applies this to blocked observation exports: a refusal must name the policy basis and safe smaller shape without leaking whether sensitive values were present.

- **Mutable data needs gates and rollback barriers.** SlopOS RFC-0097 warns that code rollback does not automatically restore mutable data compatibility. Harbor applies this to tombstones, stale frontiers, and compaction: if exact replay depends on retained negative evidence or frozen cuts, the retention barrier must be visible.

- **Receipts are explanatory, not authoritative.** SlopOS's recurring receipt posture keeps adapter receipts, proof bundles, and policy digests smaller than the underlying authority. Harbor keeps missing-sidecar notes, unsupported-target notes, stale-frontier notices, and refusal rows smaller than row truth and smaller than policy truth.

- **Bounded messages beat exception strings.** A greenfield OS should not export raw exception detail as consumer-facing truth. Harbor therefore separates consumer-visible refusal copy from operator-visible detail.

## Companion-cube pressure
- **Foundry:** absence witnesses, tombstone markers, resurrection fences, watermark frontiers, closure classes, and lateness apertures directly shaped Harbor's tombstone humility and stale-frontier posture. The key borrowed lesson is that current absence, durable withdrawal, safe purge, progress, closure, and lateness are separate truths.

- **Schell:** activation receipts, denial residue, and snapshot watermarks warn that refusal and partial-capture evidence should say what happened to the baton/cut without pretending that denial residue is the whole world.

- **ViewFS:** materialization and follow surfaces reinforce that a missing materialized helper or stale follow watermark should produce a bounded gap verdict, not a fake empty folder or complete listing.

- **Helm:** patrol routes and review queues suggest that a refusal should be actionable and reviewable, with owner/recheck/expiry, rather than an inert error string.

- **Ward:** tier witnesses and resolution bindings warn that negative evidence is local to a resolution tier and identity family; it must not become global subject/account truth.

- **Steward:** aftermath receipts and reconciliation posture reinforce that late repairs, compaction, and backfill deserve followthrough entries instead of silent regeneration.

## Harbor consequence
This pass closes `F075` by adding:

- `docs/00-meta/datacube-negative-evidence-refusal-ledgers.md` — a review surface for missing sidecars, blocked exports, unsupported assertion targets, stale frontiers, refusal rows, and tombstone/withdrawal humility;
- `docs/30-architecture/specimen-flow-75-negative-evidence-refusal-ledger-stale-frontier.md` — a concrete negative-evidence specimen;
- refreshed ledgers, source register, bibliography, roadmap, briefings, manifest, and archive index.

## What stays open
- Whether the final SlopOS datacube exposes refusal rows, incidents, assertions, or only internal proof packets.
- Whether tombstone/withdrawal posture belongs in Harbor, Foundry, Steward, or a shared future datacube substrate.
- Whether stale-frontier notices should be tied to stream processors, catalogs, frozen cuts, or only per-export receipts.
- Whether unsupported assertion compilation should be managed by DataHub-like compilers, dbt-like tests, Great Expectations-like validation runs, or no product at all.
- How much consumer-visible refusal copy can be shown without violating SlopOS export policy.

## Non-decision reaffirmed
No sibling cube is flattened into Harbor. SlopOS remains the likely owner of export policy and OS-level data-contract gates. Foundry remains better positioned for generalized absence/tombstone/replay modeling. Steward remains better positioned for aftermath reconciliation. Harbor only records the membrane-facing datacube residue needed to avoid counterfeit cube answers.
