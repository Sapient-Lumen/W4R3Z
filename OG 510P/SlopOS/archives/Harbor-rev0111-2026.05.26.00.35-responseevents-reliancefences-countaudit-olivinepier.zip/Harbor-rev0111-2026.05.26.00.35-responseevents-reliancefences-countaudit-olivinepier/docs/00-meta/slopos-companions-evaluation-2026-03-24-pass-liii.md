# SlopOS / companions evaluation — pass LIII

This pass re-checks Harbor against SlopOS and the sibling cubes after adding a token-format target witness / resource-server coverage specimen, and again chooses one narrow crossing seam over any early family bloom.

## What the current cubes still teach
- **SlopOS** remains the strongest restraint mechanism. Its imported auth-discovery, auth-response-packaging, token-passthrough, and authorization-context seams keep fetched auth metadata, response packaging, and upstream token targeting provider-local or request-local rather than portable cross-cube truth. That lines up with Harbor treating introspection audiences and JWT `aud` as crossing residue rather than durable entitlement or target truth.
- **SlopOS** also keeps reinforcing the design-phase lesson that provider- or resource-server-local acceptance rules should stay local until repeated specimens prove otherwise. Harbor should borrow that humility directly for resource-server coverage cards and any local-expectation veto.
- **Ward** still reinforces exact-basis and typed refusal posture: if a protected resource’s local expectation does not match the token-format witness, the right move is a visible veto or discard, not counterfeit confidence.
- **Helm** still contributes display humility: visible target labels or UI explanations can help operators, but they remain subordinate to exact receiver expectation and exact local refusal.
- **Foundry** still teaches aftermath honesty: a turn can leave useful residue like “audience looked plausible” or “receiver family accepted this alias” without becoming runtime authority.
- **Steward** still teaches accountable endings: when Harbor bottoms out in a local-expectation mismatch, the archive should say so plainly instead of flattering the turn into silent success.

## Harbor consequence
Harbor should keep this move modest:
- add one specimen around **token-format target witness**, **resource-server coverage card**, and **client-confidence ladder**;
- keep introspection/JWT token-format target evidence, resource-server local acceptance rules, explicit client-facing `resource` confirmation, and local mismatch veto visibly separate;
- collect **local-expectation veto** and **response-over-token precedence** as inspiration only;
- and leave any future portable audience, coverage, or confidence registry outside Harbor for now.

## Still-not-yet decisions
- Whether **token-format target witness** deserves its own Harbor family, or should remain only an annotation on request and aftermath surfaces.
- Whether **resource-server coverage card** belongs in Harbor at all, or should remain only a local receiver-policy annotation attached to specific resource interactions.
- Whether **client-confidence ladder** belongs in Harbor, or should stay a typed local explanation that never blooms into a portable target-confidence or entitlement registry.
