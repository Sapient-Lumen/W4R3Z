# Datacube exactness semantics

Purpose: keep Harbor honest that a design-phase datacube can publish **numbers and summaries with different strengths of exactness** without flattening them into one fake scalar truth.

Design-phase cubes repeatedly get into trouble when they let exact counts, exact recomputations, sketch-derived estimates, sample-derived estimates, and heuristics all travel under the same metric label.
That flattening hurts later because:
- consumers cannot tell whether a displayed number is exact or estimated;
- an estimate with a confidence/error posture can get mistaken for a hard count;
- mergeable sketches can be useful and re-aggregatable while still being weaker than exact rows;
- a dashboard can mix exact numerators with approximate denominators and present a ratio that looks exact; and
- later backfills can silently switch a lane from exact to estimated or vice versa without leaving review residue.

Harbor should not choose one sketch engine, one warehouse function family, or one error language now.
It does need one compact review surface that keeps **exactness class**, **estimate witness**, and **error-band posture** visible whenever a curated lane stops being purely exact.

## Core rule
A Harbor scalar only counts as durable analytic truth once Harbor names **how exact it is and what kind of estimate it is, if any**.

Exactness is not binary.
A row-preserving exact count is stronger than a value recomputed from exact additive components.
A sketch estimate can still be operationally excellent and mergeable while remaining weaker than an exact count.
A sample- or heuristic-based proxy is useful too, but should not silently inherit the same rollup or replay promises as exact data.

## Minimal exactness classes (Phase 1)
Harbor should keep the first set small and descriptive rather than inventing a giant statistics ontology.

1. **exact**
   - derived from exact retained detail or an exact algebra over exact retained components.
   - no intended statistical uncertainty.
   - still subject to ordinary grain, time-axis, and change-history constraints.

2. **exact-from-components**
   - displayed value is not stored as a primitive row fact, but is recomputed from exact additive or otherwise exact retained components.
   - useful when a rate, ratio, or share is exact *given the retained components*.
   - should stay visibly different from a primitive additive measure.

3. **sketch-estimate**
   - derived from a mergeable sketch or other compact bounded summary.
   - may support partial aggregation and re-aggregation.
   - should carry a witness for algorithm family, merge posture, and error/precision basis.

4. **sample-or-proxy estimate**
   - derived from a sample, heuristic, incomplete view, or otherwise weaker proxy.
   - should carry enough witness detail that consumers do not mistake it for sketch-backed bounded estimation or exact truth.

These are review classes, not a commitment to BigQuery functions, DataSketches, HyperLogLog, KLL, T-Digest, Druid, DuckDB, or any one engine.

## Exactness-class card
Harbor should allow a compact **exactness-class card** beside a curated lane or published scalar family.

The card can say:
- whether the value is exact, exact-from-components, sketch-estimate, or sample/proxy estimate;
- whether the exactness claim applies to the stored column, the rendered metric, or the merge/recompute procedure;
- whether the value can be re-aggregated safely at all and under what class of merge; and
- whether exact replay requires raw rows, exact retained components, or preserved sketch sidecars.

The point is not to force statistics everywhere.
The point is to stop one familiar-looking scalar from counterfeiting more certainty than the lane actually owns.

## Sketch witness
Harbor should allow a compact **sketch witness** whenever a curated value depends on a sketch or mergeable summary.

A sketch witness can say:
- the sketch family or algorithm class if known;
- whether the sketch supports partial aggregation, re-aggregation, union/intersection, or only selected merges;
- whether precision or memory is system-defined, user-tunable, or unknown;
- whether the retained object is the sketch itself, a derived point estimate only, or both; and
- whether downstream consumers may merge sketches, or only read extracted estimates.

This matters because a mergeable sketch can be analytically powerful while still being weaker than exact rows.
Harbor should preserve the strength difference instead of flattening “mergeable” into “exact enough to forget.”

## Error-band note
Harbor should allow a compact **error-band note** beside any estimate-backed value.

An error-band note can say:
- whether the stated uncertainty is absolute, relative, rank-based, confidence-bounded, threshold-based, or merely qualitative;
- the confidence or probability basis if the source provides one;
- whether the bound is preconfigured, empirically observed, or algorithmically returned by the sketch;
- whether the lane currently carries only a point estimate and no retained bound; and
- whether different rows/groups may carry different uncertainty.

Harbor does not need one universal statistical DSL now.
It does need a place to say when a number has a bounded estimate, when it only has a point estimate, and when the confidence language is weaker than consumers may assume.

## Mixed-exactness veto
Harbor should keep one standing anti-regrowth rule: **mixed-exactness composition needs an explicit note**.

If a dashboard or published lane combines:
- exact counts with sketch-estimated distinct counts,
- exact numerators with estimated denominators,
- exact group totals with approximate top-k or quantile summaries,
- exact history slices with sample/proxy current views,

then Harbor should require a visible note or derived-lane witness instead of letting the result masquerade as one uniformly exact metric family.

## Estimate lineage note
Harbor should allow a compact **estimate lineage note** when a value switched from exact to estimated, estimated to exact, or from one estimate family to another.

The note can say:
- what changed in the computation or retained artifact;
- whether old and new results are directly comparable;
- whether a bridge/overlap window or shadow diff is needed; and
- whether historical results were restated or only future heads changed.

This matters because a cube often stays schema-stable while its strength of evidence quietly changes.
Harbor should make that change class reviewable.

## What this forbids in Phase 1
- no silently treating a sketch-derived point estimate as if it were an exact count;
- no silently treating mergeable sketches as proof that the underlying value is exact;
- no silently mixing exact and estimated components into one displayed metric without an explicit witness;
- no silently downgrading or upgrading a lane’s exactness posture without review residue; and
- no forcing Harbor into a premature sketch library, quantile engine, or universal error-language choice.

## What this still leaves open
- exact machine schema for exactness-class cards, sketch witnesses, error-band notes, or estimate-lineage notes;
- exact mapping onto SQL views, semantic-model metadata, warehouse-native sketch types, or sibling-cube registries;
- exact promotion criteria for when an estimate-backed lane is publishable;
- whether Harbor later needs machine checks to prevent exact/estimate drift or unsupported sketch merges.

Harbor only needs the review behavior now: **name how exact a value is, witness every estimate, and keep uncertainty smaller than durable truth.**
