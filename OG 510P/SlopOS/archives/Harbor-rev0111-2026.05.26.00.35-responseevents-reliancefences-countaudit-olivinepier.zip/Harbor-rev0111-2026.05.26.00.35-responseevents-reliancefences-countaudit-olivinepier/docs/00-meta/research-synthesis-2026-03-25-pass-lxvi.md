# Research synthesis — pass LXVI

This pass asks a smaller question than "what is the final contract system?"

It asks: **when a design-phase datacube runs checks, how do we stop one failed or missing check from silently rewriting the lane's meaning, while still making the result operationally useful?**

## What the outside material teaches
1. **Assertions and contracts are related, but they are not identical.**
   OpenMetadata's contract spec explicitly separates schema, semantics, security, business assertions, SLA, terms of use, and status. DataHub likewise treats assertions as the building blocks of contracts rather than as the contract itself. Harbor should steal that separation: one failing freshness or quality check should not automatically rewrite row meaning or compatibility story.

2. **Severity needs to be explicit.**
   Great Expectations assigns expectations a severity level such as critical, warning, or info, and dbt lets tests move between `warn` and `error` with explicit `warn_if` and `error_if` thresholds. The shared lesson is not that Harbor should adopt either product's exact enum; it is that assertion results have graded consequence and should not all flatten into pass/fail folklore.

3. **Observed evidence is often smaller than the headline status.**
   Great Expectations notes that observed values may not always be available depending on expectation type and result format. Harbor should steal the humility: a status badge without an observed-value note may still be useful, but it is weaker than a result with explicit measured value, evaluation window, and evidence basis.

4. **Warnings can legitimately coexist with operation, but they should not become invisible.**
   dbt's warning thresholds and Great Expectations' severity-driven actions both show a mature middle ground between "ignore it" and "everything blocks." Harbor should therefore make room for `observe-only`, `warn`, and `blocking` posture instead of treating every non-green result as either ambient noise or a semantic crisis.

5. **Temporary exceptions deserve explicit residue.**
   Modern data-quality systems often support incidents, alerts, and other tracked exceptions. Harbor should copy the process habit without committing to a tool: if a published lane remains in use despite a blocking assertion failure, leave a bounded **waiver receipt** rather than silently pretending the lane passed.

## Harbor consequence
Harbor should add one modest datacube/process seam now:
- **assertion posture** — compact declaration that a result is observe-only, warn, blocking, or unknown/not-observed;
- **observed-value note** — compact evidence note carrying measured value, interval, threshold family, and exactness/availability posture;
- **waiver receipt** — explicit temporary exception with scope, owner, expiry, and covered consumer slices.

## What Harbor still should not decide yet
- exact monitoring or data-quality product;
- exact rule language;
- exact notification routing or incident workflow;
- exact machine-readable waiver schema shared across the ecology.

The design-phase lesson is enough for now: **assertion result posture should be explicit, evidence should stay visible, and temporary exceptions should leave receipts instead of atmosphere.**
