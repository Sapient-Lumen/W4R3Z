# Research synthesis — 2026-05-24 pass CV

This pass pressure-tests what happens after derivative repair evidence ages. F099 made correction propagation and repair acknowledgement explicit. F100 asks whether retained repair evidence remains current, expires into history, compacts into a tombstone, falls under a hold, gets privacy-minimized, or becomes stale because the source changed again.

## External pressure borrowed

- NIST log-retention language is useful because it treats retention as archiving records for later operations and review, not as a semantic upgrade of the record.
- BagIt keeps manifests and tag manifests useful for fixity and transfer while refusing payload semantics. Harbor borrows that distinction for retained repair receipts and compacted tombstones.
- W3C PROV keeps derivation, invalidation, generation, activity, and agent facts separable. Harbor uses that to record expiration and later correction without turning either into blame or repair.
- PREMIS-style preservation metadata pressure reminds Harbor to distinguish preserved objects, preservation events, agents, rights/permissions, and significant properties from current validity or compliance.
- Records-retention and privacy-minimization practice create useful tension: keeping evidence supports later review, while pruning material can be desirable. Harbor must preserve the tombstone and subject digest without pretending pruning proves repair or no stale copies.

## Harbor conclusion

Retention is evidence availability, not currentness. Expiry is a status cut, not a moral failure. A retained receipt may become stale; a compacted tombstone may preserve digest pointers; a hold may preserve evidence; a privacy-minimized record may preserve warning residue; a second source correction may reopen recheck. None of those facts should promote into current repair without a fresh scoped check.

## Speculative seam

The next seam is overlapping correction epochs. F100 can expire a repair receipt, but Harbor still needs to handle two or more corrections that overlap different derivatives and consumer windows: repair for correction A may be obsolete for source B while still relevant history for a stale derivative that never saw B. That is F101 pressure, not a multi-epoch repair ledger yet.
