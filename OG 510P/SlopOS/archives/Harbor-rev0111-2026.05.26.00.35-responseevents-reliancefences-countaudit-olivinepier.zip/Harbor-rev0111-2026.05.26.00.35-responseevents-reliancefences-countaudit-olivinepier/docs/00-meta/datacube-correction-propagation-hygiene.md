# Datacube correction propagation hygiene

**Status:** design-phase review surface for `rev0087`; not an ADR, schema, CDN plan, crawler policy, search-indexing integration, public catalog, mirror network, agent memory system, training-data governance program, takedown workflow, or final SlopOS datacube constitution.

## Why this exists

`rev0086` gave Harbor a way to anchor corrections, errata, annotations, stale citations, generated explanations, and consumer disputes. `F082` applies the next pressure: after the source-side correction is correct, older copies still travel through catalogs, mirrors, search snippets, CDN/browser caches, generated explainers, agent retrieval indexes, public web archives, downstream training/evaluation datasets, and external mirrors that may be unreachable or uncooperative.

Harbor should record propagation attempts and stale-copy facts without pretending it can recall the internet. A corrected artifact can be the source of truth while a mirror, snippet, cache, agent answer, dataset card, or crawl archive remains stale. The datacube needs language for that gap.

## Tight stance

- **Source fixed is not world fixed.** A correction anchor establishes Harbor's current source-side status; it does not prove that every catalog, mirror, cache, search result, agent memory, or training copy has updated.
- **Propagation is evidence-bearing but not authoritative.** A propagation receipt can show that Harbor notified, revalidated, invalidated, recrawled, or requested refresh. It cannot guarantee downstream behavior unless the downstream target returns verifiable status.
- **Freshness signals are signals.** Sitemaps, `lastmod`, IndexNow-style URL-change pings, cache validators, robots/meta tags, and catalog version relations are useful cargo labels. They do not outrank the source correction anchor.
- **Snippets and explainers are derived copy.** Search snippets, AI answer summaries, dashboard captions, and agent-generated explainers need invalidation/staleness posture when source labels or correction status change.
- **Training/evaluation copies are sticky.** Once a public copy is absorbed into a dataset, benchmark, eval suite, crawl corpus, or retrieval index, Harbor may only be able to label the copy stale and publish correction metadata.
- **Unreachable mirrors need honest uncertainty.** A failed update, refused update, unknown owner, missing contact, or unreachable mirror is a propagation result, not a failure of the source correction.

## Propagation modes under observation

| Mode | Useful shape | Counterfeit to avoid |
| --- | --- | --- |
| `catalog_status_sync_receipt` | Catalog/mirror was notified, revalidated, and now points to current/superseded/unknown status | Catalog display as proof that source correction happened |
| `mirror_revalidation_receipt` | Mirror returned payload digest, label digest, status banner, and validation time | Mirror freshness inferred from URL reachability |
| `cache_invalidation_receipt` | Cache layer, key/URL, old validator, new validator, purge/revalidate action, and result | Purge request as proof every user cache refreshed |
| `search_snippet_stale_witness` | Search/index/answer snippet still quotes superseded summary, with observed time and source correction anchor | Treating snippet text as current source truth |
| `crawler_signal_receipt` | Sitemap `lastmod`, URL-change ping, robots/meta posture, or recrawl request emitted | Freshness signal as guaranteed reindexing |
| `agent_explanation_invalidator` | Cached generated explanation or retrieval answer is invalidated because source labels/status changed | Agent answer as durable fact after correction |
| `retrieval_index_refresh_receipt` | Vector/search index target, source artifact, chunk/version, label digest, and refresh result | Re-embedding as semantic proof or deletion of old answer |
| `training_eval_stale_notice` | Downstream dataset/model/eval copy is known to have absorbed stale labels or text | Stale training notice as proof model behavior changed |
| `external_mirror_unreachable_notice` | Known public copy could not be updated; reason and last attempt recorded | Silence as currentness or malice |
| `propagation_horizon_note` | States which targets Harbor tried, will not try, cannot know, or must leave to downstream owners | One global "propagated" badge |
| `consumer_stale_copy_warning` | Consumer-safe statement that a cited copy is superseded and where to find the current one | Warning that leaks suppressed values or private evidence |
| `copy-impact_triage_packet` | Bounded triage for whether stale copy affected reports, charts, citations, model/eval docs, or agent answers | Incident-management platform by accident |

## Candidate receipt fields

These are watchlist handles, not promoted schema.

### Propagation target register

- target id, target class, owner/contact class, public/private posture, and update authority;
- target URL, catalog id, mirror id, cache key, snippet query, agent/index id, dataset/model/eval id, or crawl reference;
- source artifact id, source cut, correction anchor id, successor artifact, payload digest, label digest, and affected variants;
- expected propagation action: notify, recrawl, revalidate, purge, replace, supersede, annotate, deprecate, withdraw-for-new-use, or do-not-touch;
- allowed evidence lane: public, operator-only, auditor-only, sealed, refused, or unknown;
- horizon posture: best-effort, contractual, observable-only, no-authority, unreachable, or out-of-scope.

### Catalog status sync receipt

- catalog/mirror/discovery endpoint and version relation used;
- old catalog status, new catalog status, timestamp, actor/tool, and result;
- relation class: has-current-version, was-revision-of, replaces, obsoletes, is-obsoleted-by, correction-of, cites-old, external-only, or unknown;
- payload/label digest observed or failure reason;
- whether catalog metadata, downloadable artifact, human description, and search preview agree.

### Cache invalidation receipt

- cache layer: CDN, gateway, object store public cache, browser/client cache, service worker, dashboard cache, package mirror, BI extract, or unknown;
- URL/key/scope, old validator, new validator, purge/revalidate method, TTL/freshness basis, and observed response;
- whether stale-if-error, offline mode, public cacheability, or client-held copy can still serve old bytes;
- non-promise: invalidation request does not prove all replicas, clients, or archives updated.

### Search snippet stale witness

- search/index provider class, query or retrieval basis, observed title/snippet/answer text, observed time, and screenshot/hash if available;
- current correction anchor and successor artifact;
- whether snippet quotes old summary, old labels, old status banner, old chart alt text, or old generated explanation;
- action taken: recrawl request, sitemap update, IndexNow-like signal, robots/meta change, outdated-content request, or no authority;
- next check posture and safe public copy.

### Agent explanation invalidator

- generated explanation id, agent/cache/retrieval index id, original source bundle, label digest, prompt/retrieval basis, and model/tool/source posture;
- invalidation trigger: source correction, label digest change, public status change, suppression/noise label change, translation erratum, annotation acceptance, or dispute resolution;
- result: revoked, stale-bannered, regenerated, quarantined, still-cached, unknown, or refused;
- whether the old answer is allowed as historical copy, unsafe for new use, or must be hidden from a specific audience.

### Training/evaluation stale-copy notice

- downstream dataset, benchmark, eval suite, model-card/dataset-card, crawl corpus, or fine-tuning/training source class;
- stale artifact absorbed, known version/cut/date, known label loss, and correction anchor;
- what Harbor can prove: included, likely included, observed in card/manifest, reported by downstream, unknown, or impossible to know;
- remediation posture: notice filed, card updated, evaluation excluded, successor dataset published, unreachable, or no authority;
- non-promise: notice does not prove model unlearning, benchmark repair, or corpus deletion.

### External mirror unreachable notice

- mirror id/URL, last observed digest/status, contact/update route attempted, status code/error, and retry horizon;
- consumer-facing warning and successor link;
- whether Harbor will continue monitoring, stop monitoring, or require human escalation;
- non-promise: unreachable mirror is stale/unknown, not source truth.

## Minimum proof obligations before any promotion

A candidate propagation noun must show at least these before it graduates from process residue:

1. It names the source correction anchor, source artifact, source cut, payload digest, and label digest.
2. It names the downstream target class and the exact action attempted or observed.
3. It separates source currentness from target currentness, cache currentness, snippet currentness, agent answer currentness, and training/eval copy currentness.
4. It records status relation rather than only green/red success: current, stale, superseded, unreachable, refused, unknown, historical-only, unsafe-for-new-use, or out-of-scope.
5. It preserves labels and non-promises through catalog metadata, snippets, generated explanations, and dataset/eval notices.
6. It states which propagation evidence is public, operator-only, auditor-only, sealed, or unavailable.
7. It records whether Harbor has authority to update, only authority to notify, or no authority over the downstream copy.
8. It has safe refusal copy for stale snippets, unreachable mirrors, training copies, and generated explanations that would otherwise leak suppressed evidence or imply universal recall.

## Anti-counterfeit checks

- If a propagation receipt does not cite a correction anchor and digest basis, it is merely an operational note.
- If a cache purge or URL-change ping has no observed downstream response, it is an attempt, not success.
- If a catalog points at the current artifact but its human description quotes the old summary, the catalog is mixed-current, not current.
- If a search snippet quotes a superseded summary, Harbor should mark the snippet stale rather than treating the live page as broken.
- If an agent regenerates an explanation from an unlabeled source or missing label digest, the old counterfeit was replaced by a new counterfeit.
- If a training/eval copy is stale, Harbor can publish a notice and successor relation; it must not promise model unlearning, model behavior change, or corpus deletion without separate proof.
- If robots, noindex, or crawler directives are changed after publication, Harbor should treat them as future-access/crawl signals, not erasure of already-copied public data.
- If an unreachable external mirror cannot be updated, Harbor should preserve a visible stale-copy warning and successor link, not silently erase the target from ledgers.
- If a propagation horizon says "all targets updated," it must list the target set; otherwise the claim is too broad.

## Promotion triggers

Only consider promoting durable nouns after repeated specimens show that:

- corrected public artifacts repeatedly need catalog/mirror/search/agent/training propagation status;
- stale snippets and generated explanations repeatedly mislead consumers after source correction;
- retrieval indexes and agent caches repeatedly need invalidation receipts tied to label digests;
- downstream dataset/eval/model cards repeatedly absorb stale labels and need visible correction notices;
- unreachable mirrors repeatedly need horizon/status language that users understand;
- SlopOS or companion cubes repeatedly need the same target classes and receipt fields.

Until then, keep `propagation target register`, `catalog status sync receipt`, `mirror revalidation receipt`, `cache invalidation receipt`, `search snippet stale witness`, `agent explanation invalidator`, `retrieval index refresh receipt`, `training/evaluation stale-copy notice`, `external mirror unreachable notice`, and `propagation horizon note` as process residue.

## Explicit non-decisions

This document does not choose a CDN, cache layer, crawler policy, robots profile, sitemap format, IndexNow integration, search console workflow, public catalog, catalog vocabulary, DOI policy, mirror network, agent memory architecture, vector index, unlearning process, training-data governance program, takedown workflow, incident manager, public status API, or final SlopOS datacube shape.
