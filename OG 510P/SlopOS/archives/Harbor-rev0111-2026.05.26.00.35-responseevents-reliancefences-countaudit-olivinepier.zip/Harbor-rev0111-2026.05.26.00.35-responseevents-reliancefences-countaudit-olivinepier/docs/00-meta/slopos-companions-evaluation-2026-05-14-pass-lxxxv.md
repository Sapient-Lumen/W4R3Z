# SlopOS and companions evaluation — pass LXXXV

**Revision:** `rev0085`  
**Date:** 2026-05-14  
**Focus:** localized render variants, accessibility alternatives, human-readable summaries, and renderer drift.

## SlopOS pressure

SlopOS remains in design phase. That makes it especially important not to freeze Harbor's datacube around one UI, localization stack, or accessibility model.

The strongest SlopOS lessons for this pass:

- **Observation export policy must remain explicit.** SlopOS observation-export posture already prefers bounded, reviewable, policy-digest-bearing exports. Harbor should make render variants carry their source artifact, label digest, and policy/cut basis instead of letting a translated CSV or chart float free.
- **Display mode is not authority.** SlopOS display-surface boundaries warn that rendering, foregrounding, and user-facing presentation should not become trusted modal, cancellation, completion, or verdict authority. Harbor should apply the same rule to locale display, chart presentation, and summaries.
- **Accessibility is a lane, not a privilege escalator.** SlopOS accessibility/automation leases separate observation from injection and review from automation. Harbor should make accessible alternatives better review surfaces without turning them into ambient query or reconstruction authority.
- **No ambient global index.** A translated or screen-reader-friendly copy must not become an unbounded side channel that permits searching, recomposition, or inference beyond the labeled public copy.

## Companion pressure

- **Foundry:** pinned cuts and serving-lane humility suggest every render variant needs a source cut and lane note; pre-aggregation or presentation cannot become the cube.
- **ViewFS:** projection/local realization discipline reinforces that a pretty path, localized surface, or materialized view is not object truth. This is related to, but not identical with, language localization.
- **Schell:** assistive witnesses and accessibility lanes are the closest sibling prior art: observe, review, presentation, input, and automation rights must stay separate, and accessible mirrors are alternate review surfaces rather than hidden authority upgrades.
- **Ward:** display-unit and resolution-binding lessons map directly to locale number/unit rendering: display suffixes and localized units must not rewrite canonical contract values.
- **Helm:** review warnings and stale fences suggest localized summaries need stale/restated-copy warnings, not just friendly words.
- **Steward:** remediation lanes are useful for mistranslation, stripped labels, inaccessible chart variants, and renderer drift repairs.

## Harbor delta

`rev0085` adds:

- `docs/00-meta/datacube-localized-render-variants.md`
- specimen flow 80 for translated labels, locale unit/number rendering, accessible chart/table alternatives, plain-language summary tethers, and renderer sorting/grouping drift;
- proof obligations for locale/translation, accessible alternatives, renderer transforms, and summary tether honesty;
- fresh source-register, bibliography, lessons, inspiration, roadmap, and ledgers.

## Deliberate non-promotion

This pass does not promote a locale receipt schema, translation workflow, accessibility conformance claim, renderer registry, human-readable-public-copy card, public data portal, BI product, or final SlopOS datacube shape.
