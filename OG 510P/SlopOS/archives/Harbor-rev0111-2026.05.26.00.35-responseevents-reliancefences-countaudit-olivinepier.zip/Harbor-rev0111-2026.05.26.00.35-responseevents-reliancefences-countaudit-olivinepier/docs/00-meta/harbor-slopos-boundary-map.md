# Harbor ↔ SlopOS boundary map

**Status:** design-phase companion map for `rev0094`; not an integration contract, API, schema, authority hierarchy, portal implementation, network stack, tool protocol profile, or final SlopOS datacube shape.

## Purpose

SlopOS now offers stronger evidence for `portal.net.request`, checkpoint/resume, truncation, append, and malformed-envelope handling. Harbor should import that evidence only as scoped crossing evidence.

| Harbor concern | SlopOS surface | Evidence Harbor may import | Harbor must not claim |
|---|---|---|---|
| request envelope | `portal.net.request` envelope | route family, request subject, admitted/rejected/degraded posture, local digest | accepted transport means trusted content |
| route/admission | portal/chooser evidence | mediated route, user-visible step if SlopOS records it, local policy result | user understood, consented broadly, or granted durable authority |
| callback/reentry | OpenURI/callback continuation | callback arrived on a route, with digest/session binding if present | callback proves same outside authority or same human intention |
| truncation | truncated response or suffix-guard evidence | incompleteness, discarded-suffix boundary, safe degradation reason | summary is complete, safe, or equivalent to full evidence |
| checkpoint/resume | checkpoint/resume records | local processing continuity and restart basis | outside state, public copy, or source authority stayed unchanged |
| accepted-only append | append history over accepted events | durable local order and successor records | later append repairs earlier stale use or memory-holes history |
| malformed-envelope rejection | envelope validator/rejection corpus | hostile receipt fixture and refusal basis | all future malformed forms are covered |
| public warning | SlopOS status/result surfaces | status surface was emitted or updated | warning was seen, understood, globally propagated, or legally adequate |
| evidence export | SlopOS no-secrets/no-export fences | public-safe subset and redaction boundary | sealed evidence, private logs, suppressed cells, or internal traces are public |
| MCP/tool resource | tool/resource/prompt metadata | offered capability, annotation, and local trust posture | annotation is true, safe, non-malicious, or user-approved |
| credential or identity flow | browser/OAuth/FedCM/WebAuthn-like crossing | credential/authorization presentation occurred for a named audience | global identity, issuer endorsement, or all-purpose authorization |

## Crossing import rule

A SlopOS record may fill `route`, `admission`, `subject.digest`, `outcome.class`, and `aftermath.receipts` fields in `CrossingRecord v0`. It may not fill `truth`, `compliance`, `all copies clean`, `user comprehension`, or `downstream repair` fields because those fields do not exist in the crossing record.

## Replay and append rule

When Harbor consumes SlopOS replay or append evidence, it must preserve:

```text
basis event id
accepted/rejected posture
checkpoint id if any
resume id if any
truncation/degradation note if any
append position or successor relation if any
subject digest
scope/audience/surface
non-promises
```

If any of those are missing, Harbor may still keep prose residue, but it must refuse proof-grade status promotion.

## Public-copy aftercare rule

SlopOS evidence can say that Harbor's own process handled a crossing. Public-copy aftercare still needs Harbor-PublicCopy proof: correction adoption, instruction, implementation evidence, publication receipt, propagation observation, recheck, recurrence, and warning lifecycle all remain separate.
