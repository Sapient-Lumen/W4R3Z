# Research synthesis — pass XCVI, transparency/provenance receipt import

**Revision:** `rev0096`  
**Date:** 2026-05-21  
**Question:** How should Harbor import signed, logged, timestamped, manifest-bound, or verifier-produced receipts without letting them become truth, freshness, or legal closure?

## Result

Harbor should add a deterministic receipt-import bundle, not a reliance policy. F091 therefore introduces a fixture and checker for SCITT-like inclusion, C2PA/content credentials, in-toto/SLSA provenance, Rekor/CT-style logs, timestamp anchors, redacted derived proofs, issuer-compromise notices, and verifier policy decisions.

The central split is:

```text
receipt evidence -> binding analysis -> currentness analysis -> verifier decision -> aftermath
```

A receipt can be accepted while every larger interpretation is blocked.

## External lessons folded in

- SCITT-style architecture separates signed statements, transparency receipts, registration policies, relying parties, auditors, and transparency services. Harbor imports that split as `scitt_inclusion`, while refusing statement truth and currentness by default.
- C2PA content credentials and manifests are useful because they bind provenance information to digital assets, but Harbor treats that as asset/manifest evidence rather than real-world authenticity, editorial approval, or transform survival.
- in-toto/SLSA-style attestations help name subjects, builders, predicates, and materials. Harbor imports subject/materials discipline without treating provenance as dependency cleanliness, deployment truth, or vulnerability status.
- Rekor/CT-style systems teach inclusion proof and tree/checkpoint discipline. Harbor borrows inclusion/currentness cuts without turning the log into semantic approval.
- Timestamp tokens can bind a message imprint to a time authority response. Harbor records that as timestamp-only evidence, not event time or current state.
- Redacted/derived proof systems are useful because they support selected claims. Harbor refuses to call selected claims full evidence.
- Issuer compromise is not automatic erasure and not automatic trust. Harbor records recheck requirements, affected windows, and non-promises.

## New executable surfaces

- `docs/00-meta/datacube-transparency-provenance-receipt-import.md`
- `docs/40-verification/harbor-transparency-provenance-receipt-bundle-v0.md`
- `fixtures/harbor-transparency-provenance-receipt-bundle-v0.json`
- `tools/harbor_transparency_receipt_harness.py`
- `tools/check_harbor_transparency_receipt_bundle.py`
- `docs/30-architecture/specimen-flow-91-transparency-provenance-receipt-import.md`

## New watchlist handles

- `receipt_family_non_promises`
- `binding.analysis`
- `currentness.analysis`
- `policy_epoch_bound`
- `redacted_binding_sufficient_for_claims`
- `revocation_or_compromise_recheck_required`
- `no_import_record_emitted`
- `latest_log_wins_scope_substitution_rejection`

## Practical design rule

A receipt may become Harbor evidence only when it carries:

```text
subject digest + receipt family + issuer/observer facts + binding verdict + currentness verdict + verifier epoch + non-promises + rejection cases
```

Without those fields it remains source material, not Harbor residue.

## Followthrough result

`F091` is now complete. `F092` should pressure-test multi-verifier disagreement and policy-epoch drift: one verifier accepts, one refuses, one cannot establish currentness, the policy changes after public copy, and a dashboard wants a single badge anyway.
