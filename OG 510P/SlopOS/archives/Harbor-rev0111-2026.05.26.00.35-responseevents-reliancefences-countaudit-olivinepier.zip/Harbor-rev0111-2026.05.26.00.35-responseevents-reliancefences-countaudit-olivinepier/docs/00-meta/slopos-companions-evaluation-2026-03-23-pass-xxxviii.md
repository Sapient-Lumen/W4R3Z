# SlopOS / companions evaluation — pass XXXVIII

This pass re-checks Harbor against the uploaded cube ecology and keeps the archive embryonic.

## What the current cubes still teach
- **SlopOS** now looks even more like Harbor’s best brake against fake approval. `powerbox-posture-v0.md` keeps consent mediation chooser-owned and summary-bound, `volition-posture-v0.md` keeps trusted-UI gesture evidence local-only and one-shot, and `approval-basis-posture-v0.md` keeps mutable review basis from floating away from exact action bytes. That strongly supports a Harbor move that names the review surface without letting it regrow into portable approval, account, or session truth.
- **SlopOS** also sharpens the anti-widget lesson in `tool-ui-authority-boundary-v0.md` and `auth-link-ui-trigger-boundary-v0.md`: rendered tool/server chrome may propose, decorate, or trigger host-local mediation, but it must not become chooser truth or hidden auth-broker authority. Harbor should copy that humility directly.
- **Steward** remains a good sibling reminder that exact reviewed targets and exact chooser surfaces are healthier than ambient scraped text or whatever happened to be visible. That maps cleanly onto Harbor’s need for reviewed summaries smaller than real consequence.
- **Helm** still teaches that good cards and review surfaces can be user-useful while remaining smaller than settlement or substrate authority. That makes it a good neighbor for prompt provenance and reviewed summary residue.

## Harbor consequence
Harbor should keep review/prompt nouns provisional.
The right near-term move is small:
- add one specimen around `prompt provenance`, `reviewed summary`, `review witness`, and `no-fake-approval honesty`;
- keep review location, reviewed copy, and durable grant/account/session truth visibly separate;
- and let SlopOS or future approval-specific seams own any portable consent receipt, approval-basis catalog, or trusted-UI protocol if those ever become necessary.

## Still-not-yet decisions
- Whether `reviewed summary` deserves its own first-class card or belongs as one field on a broader mediation/aftermath object.
- Whether `review witness` should stay generic across browser/authenticator/host-owned review surfaces or later split into narrower kinds.
- Whether Harbor should ever name trusted-versus-untrusted review surfaces as a small enum, or keep provenance opaque and typed only by witness/annotation posture.
