# Research synthesis — pass LXIV

This pass learns the next restraint for a design-phase datacube: **Harbor should not pretend that every published lane makes one giant all-or-nothing promise. It should steal contract tiers, a smaller assertion plane, and consumer-obligation slices so useful surfaces can stabilize gradually instead of freezing the entire cube up front.**

## Outside lessons
1. **A data contract is really several promise families wearing one name.**
   OpenMetadata’s data-contract model explicitly separates schema, semantics, security, business assertions, SLA, terms of use, and status for one asset. Harbor should steal the restraint, not the full product surface: one lane may earn a shape promise before it earns a semantic or SLA promise.

2. **Assertions are healthier as a neighboring plane than as disguised row meaning.**
   DataHub treats assertions as data-quality tests and explicitly says assertions are the building blocks of data contracts. Its open assertions specification goes further by defining assertions in one YAML format that can be compiled into tool-specific artifacts. Harbor should therefore keep a small **assertion plane** that can verify a lane without silently becoming the lane’s core row contract.

3. **Returned shape and post-build checks are different kinds of guarantees.**
   dbt draws the line clearly: model contracts define the returned dataset shape, while data tests validate content after the model is built. Harbor should steal that split. Shape contracts belong on curated lanes; richer data-quality and freshness checks can stay in an assertion plane.

4. **Consumer-driven expectations are narrower than provider folklore.**
   Pact’s consumer-driven contracts only test the interactions actually used by consumers, leaving unused provider behavior free to change. Harbor should steal a **consumer-obligation slice**: each downstream consumer should declare the subset of fields, assertions, and compatibility promises it truly depends on, so Harbor does not accidentally promise the whole lane forever.

5. **Versioned schema pointers still matter once tiers exist.**
   OpenTelemetry keeps schema URLs unique per schema version and expects consumers to transform from a received schema version to the version they target. Harbor should keep using immutable family/version pointers for any tier or facet that graduates into a published contract.

## Harbor consequence
Harbor should add one modest datacube/process seam now:
- **contract-tier card** — compact declaration of which promise families a lane currently makes (for example shape, meaning, assertion, or service/freshness), without forcing all tiers at once;
- **assertion plane** — a smaller, explicitly neighboring surface for schema/freshness/volume/custom checks that verifies a lane without redefining its row meaning;
- **consumer-obligation slice** — compact note of what one downstream consumer actually pins to (fields, tiers, assertions, history expectations);
- **tiered stability** — a lane may be published for shape while still only candidate for richer meaning or assertion posture; and
- **compiled-check humility** — generated dbt tests, monitoring rules, SQL checks, or catalog artifacts remain derived from the review surface rather than outranking it.

## What Harbor still should not decide yet
- exact machine-readable schema for contract tiers or consumer slices;
- exact registry or catalog product for assertion definitions;
- exact enforcement engine for quality/freshness checks;
- whether tiered contracts eventually live as views, semantic models, catalog metadata, or separate policy files.

Those are later implementation choices. The lesson to keep now is the **behavioral split**: let shape stabilize sooner than semantics, let assertions verify rather than redefine, and let each consumer declare the slice it truly needs.
