# Research synthesis — pass LII

This pass keeps Harbor narrow and learns five compatible things at once: **JWT access tokens can carry a default resource cue when no `resource` was requested; challenge-derived protected-resource metadata can legitimately cover broader same-origin path prefixes; those cues still differ from issuance-time client confirmation; duplicate returned `resource` values are a hard client-validation failure; and Harbor should preserve the resulting confidence gap without freezing a portable target-inference model too early.**

## Outside lessons
1. **A default target cue is real, but it is still only a cue.**  
   RFC 9068 says that if the request does not include a `resource` parameter, the authorization server MUST use a default resource indicator in the JWT access token `aud` claim, and SHOULD infer that default from scope when possible. Resource servers must then validate that `aud` contains a resource indicator value corresponding to themselves. Harbor should preserve a **default-target cue** instead of flattening JWT audience defaults into exact issuance-time confirmation.

2. **Coverage can widen under challenge-derived discovery without becoming a grant truth.**  
   The February 2026 RFC9728bis update draft relaxes validation only for metadata retrieved through a `WWW-Authenticate` challenge: the protected-resource metadata `resource` value may share the same TLS origin and cover the request URL by path-prefix match on segment boundaries. The draft explicitly says metadata retrieved directly from a well-known URI keeps RFC 9728’s exact-match rule. Harbor should preserve a **coverage note** instead of pretending all protected-resource discovery yields the same strength or scope.

3. **Client-facing confirmation is not the same thing as token-format audience.**  
   The March 2026 resource-token-response draft says returning `resource` in the token response is more useful to the client than returning audience or scope information because `resource` is the client-facing mechanism for identifying the target protected resource, while audience encoding and enforcement remain token-format and resource-server concerns. Harbor should therefore keep JWT default-target cues visibly smaller than issuance-time response confirmation.

4. **Duplicate returned resources are a typed confirmation failure.**  
   The same March 2026 draft says that when the client requested one or more resources, the returned `resource` set must include at least one requested value and validation fails if the response contains duplicate resource identifiers, including duplicates that emerge after normalization. Harbor should preserve a **confirmation-gap receipt** instead of silently accepting a response whose confirmation surface is malformed.

5. **Broad coverage plus weak confirmation is exactly where over-design starts.**  
   Challenge-derived metadata may correctly say that one authorization setup covers a family of paths, and JWT `aud` may still hint at a default resource, yet the client can remain short of strong issuance-time confirmation. Harbor should make that shortfall legible rather than inventing a new portable target or entitlement family.

## Resulting Harbor move
Do not decide yet whether Harbor needs durable nouns such as **default-target cue**, **coverage note**, or **confirmation-gap receipt**.
For this revision:
- add one specimen around JWT default-resource indicators, challenge-derived broader protected-resource coverage, and duplicate-response validation failure;
- preserve the difference between “what discovery says is in scope,” “what the token format hints at,” “what the client-facing token response confirms,” and “what local validation still refuses to certify”;
- and collect **segment-bounded coverage** plus **client-confidence ladder** as inspiration only, without promoting a new registry today.

## Fresh ideas worth stealing
- **default-target cue** — compact reminder that a no-`resource` turn may still carry a token-format hint about the likely protected resource.
- **coverage note** — inspectable note that challenge-derived metadata covers a broader same-origin path family without claiming issuance-time confirmation.
- **confirmation-gap receipt** — local residue that the route looked plausible but exact client-facing confirmation stayed missing, malformed, or weaker than hoped.
- **segment-bounded coverage** — future-facing reminder that broader discovery coverage should stay exact about path-prefix and segment-boundary rules.
- **client-confidence ladder** — future-facing reminder that local confidence can move from discovery-only, to cue-backed, to response-confirmed, without pretending all three are the same truth.
