# SlopOS companion evaluation — 2026-05-24 pass CV

## Harbor / SlopOS boundary

SlopOS can preserve append histories, checkpoint/resume cuts, truncation receipts, portal/callback materialization evidence, and replay traces. F100 uses those as evidence inputs but refuses to let a retained SlopOS record prove current Harbor repair after the record's recheck window expires.

## What Harbor should ask SlopOS for later

- replayable materialization receipts that can distinguish redisplayed cache from rebuilt derivative;
- append/checkpoint histories with enough timestamps to compare against Harbor expiry windows;
- truncation and compaction receipts that say what was lost and what digest/tombstone remains;
- callback/portal receipts with explicit non-promises about user read, application, and currentness;
- revalidation traces for derivatives after a later source correction;
- out-of-band verification hooks that can recheck retained receipts without becoming a sync-state authority.

## What Harbor must refuse

- retained portal/callback receipt as current derivative repair;
- checkpoint survival as freshness;
- replay availability as semantic correctness;
- truncation/compaction as full evidence;
- deleted stale material as repair or clean slate;
- file-library or sync timestamp as retention clock authority;
- legal-hold-style preservation as compliance or freshness;
- privacy pruning as proof that no stale copies remain.

## Companion note

Schell is now a direct neighbor because retention budgets, forgetting ledgers, minimization fences, and stale-residue handling are first-order pressures. ViewFS remains relevant for material identity after retained evidence is rechecked; Helm for repair/intervention traces; Steward for acknowledgement expiry and retry windows; Ward for delegated retention duties; Foundry for classification pins that must survive compaction; and SlopOS for replayable boundary evidence that stays smaller than truth.
