# SlopOS / companions evaluation — pass LXXXIV

This pass asks how Harbor should evaluate `F079` while SlopOS's datacube remains in design phase. The answer is to make public-copy hygiene visible without choosing SlopOS's public data substrate or turning Harbor into a BI/export governance product.

## SlopOS lessons used directly
- **Observation export is bounded, pull-only, and non-authoritative.** SlopOS D-OBS says export is explicit, policy-killable, bounded, redaction-first, and does not grant effects. Harbor borrows this posture for public aggregate copies: a public copy is a constrained release artifact, not an ambient query endpoint or authority grant.

- **Export policy must be recorded with the output.** SlopOS observation-export posture expects the applied policy digest to travel with outputs when CH-OBSPOL is enabled. Harbor maps that to public-copy labels and release-artifact receipts: suppression/noise/coarsening labels must travel with the copy, not just live in the reviewer memory.

- **No ambient global indexing remains a critical guard.** SlopOS forbids a Phase-1 global observation search service. Harbor carries that through to recomposition risk: a public-copy search or mirror layer must not become an unbounded reconstruction oracle over historical aggregate copies.

- **Replay bundles are sensitive even when answer proofs are public.** SlopOS CH-RRBUNDLE packages digest-bound replay/audit payloads but warns that bundles may contain secrets and user data. Harbor therefore answers proof-of-public-copy requests with digest/manifest/label receipts rather than raw replay payloads.

- **Safe-open export boundaries are useful analogies.** SlopOS safe-open export classification, destination, and lineage boundaries say kept outputs are new artifacts, fresh-destination-first, quarantined by default, and tied to source by explicit parent digest instead of hidden identity continuity. Harbor steals the shape: a public aggregate copy has its own identity and digest, plus explicit source/public-cut lineage; it is not a live alias of the internal answer.

- **Revocation epochs do not imply remote erasure.** SlopOS is rich in revocation/indirection posture, but public data copies require humility: after release, Harbor can publish supersession/deprecation/withdrawal receipts and mark mirrors stale; it cannot guarantee all external copies vanished.

## Companion-cube pressure
- **Foundry:** package manifests, pinned cuts, and digest-addressed artifacts are the right home for exact source/public-copy identity. Harbor should depend on those shapes rather than inventing its own package substrate.

- **ViewFS:** materialized views, folder ghosts, and displayed labels make the copy problem visible. Harbor should assume some viewers preserve labels and some flatten them, then require a label-preservation check before treating an export as a valid public copy.

- **Helm:** review packets, least-widening, and user-visible warnings map to public-copy review: a label-stripped export needs a red warning and a coarser/safe alternative, not quiet success.

- **Steward:** remediation lanes are the natural home for stale public copies, bad mirrors, label-stripping incidents, and restatement followthrough.

- **Ward:** runtime/platform evidence can help prove which bytes were emitted, but Harbor should not treat that as proof that downstream consumers interpreted labels correctly.

- **Schell:** authorization and proof discipline can help future verifier tickets, but public-copy proof remains smaller than a durable authority token.

## What this revision adds to Harbor
- `docs/00-meta/datacube-public-copy-hygiene.md` — a review surface for labels, release artifacts, mirrors, restatements, recomposition guards, notice propagation, and proof-of-copy tickets;
- `docs/30-architecture/specimen-flow-79-public-copy-labels-mirror-hygiene-restatement.md` — a concrete public-copy specimen;
- additional public-copy proof obligations in `docs/00-meta/datacube-proof-obligations.md`;
- refreshed lessons, inspiration harvest, source register, bibliography, roadmap, ledgers, manifest, and briefing surfaces.

## What stays open
- Whether public-copy labels become Harbor cards, SlopOS observation-export labels, Foundry package metadata, ViewFS display metadata, or a shared release-artifact surface.
- Whether public copies are packaged using CSVW, Data Package, BagIt, RO-Crate, DCAT, SPDX-like verification, signed manifests, or simple internal receipts.
- Whether restatement policy attaches to public copy, metric, source cut, audience, contract, or all of them.
- Whether mirror validation is pull-based, push-notified, catalog-driven, cache-header-like, or entirely out of scope.
- How much downstream recomposition detection Harbor can reasonably do once public copies leave its membrane.

## Non-decision reaffirmed
No sibling cube is flattened into Harbor. SlopOS remains the likely owner of OS-level export policy and observation boundaries. Foundry remains better positioned for package/digest/cut mechanics. ViewFS remains better positioned for materialized-copy display and label preservation. Helm remains better positioned for human-facing review and warnings. Steward remains better positioned for remediation. Harbor only records the membrane-facing datacube residue needed to keep public copies from counterfeiting the release they came from.

