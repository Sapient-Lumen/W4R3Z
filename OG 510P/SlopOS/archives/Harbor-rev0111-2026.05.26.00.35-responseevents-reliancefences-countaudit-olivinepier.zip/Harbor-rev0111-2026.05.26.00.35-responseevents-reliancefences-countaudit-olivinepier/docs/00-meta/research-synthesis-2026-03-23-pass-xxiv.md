# Research synthesis — pass XXIV

This pass keeps Harbor narrow and learns one more thing from identity and chooser systems: **a preference or narrowing hint is real, but it is still smaller than an explicit reviewed selection and much smaller than durable local adoption**.

## Outside lessons
1. **OIDC distinguishes a hint from an explicit account-selection demand.**  
   `login_hint` is advisory and its meaning is left to the provider’s discretion, while `prompt=select_account` asks the provider to force an account-selection turn. Harbor should preserve that gap instead of pretending “preferred account” already means “selected account”.

2. **FedCM treats login/domain hints as chooser filters, not as selected-account truth.**  
   `loginHint` and `domainHint` narrow which accounts are shown. When no current account matches, the truthful next step is a login or mismatch prompt rather than counterfeit continuity. Auto-selection is also carried separately from the minted credential.

3. **WebAuthn Level 3 says hints are hints.**  
   `PublicKeyCredentialHint` values such as `security-key`, `client-device`, and `hybrid` help the user agent provide a better experience, but they are not requirements and do not bind the user agent. That is excellent Harbor precedent.

4. **Hints can come from different loci without becoming stronger truth.**  
   Some narrowing signals are caller-provided (`login_hint`, `domainHint`, WebAuthn hints); some are provider-maintained (for example FedCM custom account labels). Harbor should notice that distinction without promoting either kind into selected-account or selected-credential truth.

5. **Chooser priming is often the honest middle layer.**  
   A hint may filter, sort, or pre-shape the chooser without deciding the chooser’s answer. Harbor should keep that middle layer visible because products otherwise jump straight from “hint supplied” to “user/account/device chosen”.

## Resulting Harbor move
Do not decide yet whether the durable nouns are exactly `selector hint`, `chooser priming`, `mismatch prompt`, and `selection honesty`, or whether later pressure will compress them into a smaller chooser-input family.
For now, keep them alive as specimen nouns and demand that they improve:
- one OIDC specimen where `login_hint` is present but the provider still needs `select_account` or explicit login;
- one FedCM specimen where `loginHint`, `domainHint`, or provider-managed account labels filter the chooser but do not themselves answer selection truth;
- and one WebAuthn specimen where `hints` guide the user agent without binding it to a specific authenticator path.

## Fresh ideas worth stealing
- **selector hint** — bounded preference or narrowing signal about a likely account, domain, or authenticator path.
- **chooser priming** — visible effect a hint has on filtering, sorting, or staging candidate choices.
- **provider label rail** — provider-maintained account labeling that stays smaller than selected-account truth.
- **mismatch prompt** — typed truth that a hint did not land on a currently usable candidate and more interaction is needed.
- **hint smaller than selected** — a standing anti-regrowth rule.
