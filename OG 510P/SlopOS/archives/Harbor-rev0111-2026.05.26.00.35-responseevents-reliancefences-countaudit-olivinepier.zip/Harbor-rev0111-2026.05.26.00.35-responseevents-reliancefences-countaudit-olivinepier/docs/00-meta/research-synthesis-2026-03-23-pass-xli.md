# Research synthesis — pass XLI

This pass keeps Harbor narrow and learns one more thing from browser-owned choosers and review cards: **coarse origin cues, preview assets, and chooser labels can help a human orient themselves, but they still remain smaller than issuer truth, account truth, and reviewed approval basis.**

## Outside lessons
1. **Display metadata is useful and risky at the same time.**  
   OpenID Connect Dynamic Client Registration says `client_name`, `logo_uri`, `policy_uri`, and related human-facing metadata may be shown to end users, may have locale-specific variants, and must be treated carefully by an authorization server because a rogue client can supply URLs that should not be blindly displayed. Harbor should steal the lesson that caller-supplied visual metadata is only a **preview asset**, never durable authority truth.

2. **Origin cues should stay explicit but coarse.**  
   Credential Management says chooser UI must be distinguishable from website UI and must include an indication of the requesting origin. FedCM’s client-metadata and assertion requests expose the RP via the `Origin` header, while its accounts fetch deliberately withholds RP origin/referrer. Harbor should preserve a **coarse origin cue** that is strong enough for provenance but smaller than the full path, callback URL, or request basis.

3. **Preview images can leak chooser usage if fetched carelessly.**  
   Credential Management explicitly warns that if chooser UI displays origin-supplied images such as favicons, requests for those images must not be directly tied to chooser instantiation, or chooser usage can leak. It also says user edits to names or icons should not be reflected back to the website. Harbor should therefore keep **preview assets** and **asset honesty** separate from grant/account truth and separate from network-observable chooser timing.

4. **Branding and account pictures are guidance, not a UI contract.**  
   The FedCM specification says IdP branding preferences are intentionally high-level and abstract so user agents can evolve their own UI, and it allows the user agent to ignore, crop, or transform unsuitable icons. FedCM account data can also include a `picture` URL. Harbor should steal the idea that a picture or logo may help the human chooser while still remaining smaller than selected-account or issuer truth.

5. **Chooser labels are filters, not verdicts.**  
   Current Chrome FedCM guidance allows custom account labels via config files and account metadata so an RP can filter which accounts appear. Hidden or filtered accounts are intentionally not the same thing as “that account does not exist” or “this selected account is now durable truth.” Harbor should keep labels as **chooser labels** or narrowing residue, not as portable account classes.

## Resulting Harbor move
Do not decide yet whether the durable nouns are exactly `coarse origin cue`, `preview asset`, `chooser label`, and `asset honesty`, or whether later pressure compresses some behind `review card`, `origin cue`, or `selector hint`.
For now, keep them alive as specimen nouns and require that they improve:
- one OIDC client-registration specimen where `client_name` / `logo_uri` are displayed but remain smaller than redirect or issuer truth;
- one FedCM specimen where account pictures and custom account labels shape the chooser without becoming selected-account truth;
- and one chooser-image specimen where caching or delayed fetching prevents chooser-use leakage.

## Fresh ideas worth stealing
- **coarse origin cue** — explicit origin-scoped provenance cue on a host-owned chooser or review surface, intentionally smaller than full request-path or callback truth.
- **preview asset** — logo, icon, picture, or other visual aid shown on a chooser/review surface that remains smaller than issuer or account truth.
- **chooser label** — small category or badge used to narrow or disambiguate visible candidates without settling selected-account truth.
- **asset honesty** — inspectable reminder that a visual preview may be omitted, transformed, cached, filtered, or stale.
- **preview smaller than truth** — standing anti-regrowth rule.
