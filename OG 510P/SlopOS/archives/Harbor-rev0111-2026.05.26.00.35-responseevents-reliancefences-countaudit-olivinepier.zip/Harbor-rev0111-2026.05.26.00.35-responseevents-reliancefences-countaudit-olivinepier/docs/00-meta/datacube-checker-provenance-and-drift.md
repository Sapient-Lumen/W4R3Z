# Checker provenance and drift

Harbor has enough executable proof slices now that the next counterfeit is no longer only a bad fixture.  It is a good-looking checker observation with missing evidence about the checker that produced it.

F095 adds a small checker-provenance bundle.  It records source digests, harness digests, fixture digests, invocation receipts, guard-state receipts, fixture/checker pairing posture, self-test receipts, and reviewer-override limits for the current Harbor checker stack.

This is still smaller than a checker registry, CI status API, trust-root schema, automated reliance workflow, or final SlopOS datacube shape.

## The new minimum packet

A checker observation packet must say:

```text
checker id
checker source path and digest
owning harness path and digest
fixture path, file digest, bundle digest, schema, version, and revision
invocation command
self-test result and stdout/stderr digests
guard families that were expected and observed enabled
fixture/checker pairing result
reviewer override packet, if any
non-promises
```

The observation may support review of the Harbor archive.  It does not prove the subject bundle is semantically correct, does not establish a CI status, does not certify a checker, and does not create a portable trust root.

## Accepted records

Harbor admits a checker-observation packet only when:

- the checker source digest, harness source digest, fixture file digest, and fixture bundle digest are present;
- the fixture schema and fixture revision match the checker expectation;
- every required guard family is observed enabled;
- the checker self-test receipt is present and passing;
- any reviewer override is narrow, expiring, human-reviewable, and unable to change the machine result.

## Refused records

Harbor refuses:

```text
disabled guard evidence
stale fixture/checker pairing
missing self-test receipt
reviewer override that marks failure as success
reviewer override with global scope or no expiry
checker observation presented as CI status
checker digest presented as trust root
self-test presented as semantic proof of the subject bundle
```

## Reviewer override rule

A reviewer override is not a bypass.  It can explain why a result is retained, parked, or rechecked.  It cannot mutate the checker result.

Allowed override shape:

```text
narrow scope
expiry or next-review boundary
human-review bit
machine-result unchanged bit
failure-not-marked-success bit
followthrough-if-repeated bit
explicit non-promises
```

## Bootstrap humility

The new checker-provenance bundle records the five prior executable checkers.  It deliberately does not try to attest recursively to itself in the same bundle.  Self-recursive checker attestation would create false fixed-point confidence.  The next seam should inspect release-package and archive-build evidence instead.

## Proof obligations added

- `PO-CP-001` — checker source and invocation proof.
- `PO-CP-002` — fixture/checker pairing proof.
- `PO-CP-003` — guard-state proof.
- `PO-CP-004` — self-test receipt proof.
- `PO-CP-005` — reviewer override proof.
- `PO-CP-006` — bootstrap and non-promotion proof.
