# Research synthesis — pass XCI, external escalation handoff hygiene

**Revision:** `rev0091`  
**Date:** 2026-05-15  
**Question:** How should Harbor hand standing challenges and stale-copy warnings to source owners, auditors, regulators, coordinators, and public status surfaces without turning handoff, appeal, sealed evidence, public logs, or external replies into closure?

## Result

Harbor should treat external escalation as **bounded packet exchange**, not as adjudication.

The useful move is to record seven small packets:

1. a standing challenge handoff packet;
2. an external escalation receipt;
3. an appeal window note;
4. a sealed evidence transfer manifest;
5. an auditor/regulator packet note;
6. a post-handoff status divergence note;
7. a disputed sunset appeal note.

Together they let Harbor say: "we sent this bounded challenge to the source owner, opened this appeal window, gave this sealed packet to an authorized reviewer, received only acknowledgement so far, and the public log/status page currently differ by scope." They do not prove acceptance, remediation, non-use, harm, legal compliance, public disclosure safety, source-owner fault, or current truth.

## External lessons folded in

- NIST SP 800-61 Rev. 3 keeps incident response tied to broader risk management, preparation, detection, response, recovery, and learning. Harbor should borrow staged response evidence, not import an incident-response program.
- FIRST PSIRT/CSIRT frameworks emphasize stakeholder communication, reporting, triage, coordination, and capability building. Harbor should steal intake/routing/status expectations, not become a PSIRT or CSIRT.
- CERT/CC's CVD guide frames coordinated disclosure around finders, vendors, coordinators, process phases, and operational problems. Harbor should borrow stakeholder-role clarity and failure-mode humility for source-owner/auditor/regulator handoffs.
- ISO/IEC 29147 reinforces receipt of reports, remediation disclosure information, disclosure concepts, policy considerations, and communications. Harbor should borrow required-contents discipline for handoff packets, not a vulnerability-disclosure standard.
- FIRST TLP and IEP show that sharing boundaries must travel with the information, and wider sharing can require source permission. Harbor should attach handling labels, redaction cuts, and reveal conditions to sealed evidence rather than relying on social memory.
- IETF appeal procedures provide a useful pattern: name the action/decision, grounds, and remedy sought; keep appeals factual; identify out-of-scope issues; preserve public records where appropriate. Harbor should borrow appeal-contents and scope discipline, not an IETF governance clone.
- SCITT's architecture separates signed statements, receipts, transparency services, registration policies, relying parties, and auditors; it also warns that transparency supports accountability but relying parties choose what they trust. Harbor should borrow log/receipt humility: inclusion evidence is not current truth.
- in-toto and SLSA keep attestations subject-bound and parser-humble. Harbor should keep source-owner, auditor, regulator, and sealed-evidence replies tied to named subjects, windows, policies, and digests.

## SlopOS-specific interpretation

SlopOS remains design-phase, so Harbor should avoid a native escalation authority model.

The SlopOS lessons are:

- attestation export is policy-killable and non-mutating, so Harbor handoff should be refusal-capable and should not mutate status simply because a packet is prepared;
- SlopOS pins no-secrets-in-band and opaque evidence handling, so Harbor public summaries must not leak sealed evidence;
- freshness/challenge and collateral status are verifier-local, so Harbor cannot import an external currentness/status reply as ambient truth;
- VEX/SBOM producer/status/explanation boundaries keep imported advisory claims as evidence, not owner truth;
- transparency/logging support accountability but do not replace local appraisal.

## New watchlist handles

- `standing_challenge_handoff_packet`
- `external_escalation_receipt`
- `appeal_window_note`
- `sealed_evidence_transfer_manifest`
- `auditor_regulator_packet_note`
- `source_owner_response_receipt`
- `post_handoff_status_divergence_note`
- `disputed_sunset_appeal_note`
- `public_safe_handoff_summary`

## Practical design rule

Prefer handoff language that preserves boundaries:

- `packet sent to source owner`, not `source owner notified and responsible`;
- `acknowledged receipt`, not `accepted fault`;
- `appeal received`, not `warning invalid`;
- `appeal expired`, not `decision proven correct`;
- `sealed packet available to verifier`, not `evidence public`;
- `auditor accepted review`, not `auditor verified`;
- `regulator-facing reviewer received scoped packet`, not `compliance decided`;
- `public log says escalation sent`, not `public status is current truth`;
- `sunset appealed`, not `history deleted or restored`.

## Followthrough result

`F086` is now complete as a pressure test. The next seam is external decision return and adoption: conflicting source-owner/auditor/regulator findings, partial findings, mandated or recommended corrections, sealed finding expiry, appeal outcomes, local adoption boundaries, and public-copy updates after outside review.
