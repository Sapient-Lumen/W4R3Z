# SlopOS / companions evaluation — pass LXXXIII

This pass asks how Harbor should evaluate `F078` while SlopOS's datacube remains in design phase. The answer is to make aggregate release risk visible without choosing SlopOS's privacy substrate or turning Harbor into a query broker.

## SlopOS lessons used directly
- **Observation export is bounded and policy-killable.** SlopOS `CH-OBSPOL v0` names allowlists, redaction classes, and hard bounds, and D-OBS keeps export pull-only, explicit, and non-authoritative. Harbor borrows that posture for aggregates: a public metric export is a constrained release act, not an ambient public query surface.

- **Metrics export exists but is not unlimited analysis.** SlopOS lets observation policy allow metrics while still bounding export size/classes and refusing on policy mismatch. Harbor should therefore treat aggregate cells as release cells with policy, cut, and refusal posture rather than as free-form dashboard truth.

- **No ambient global indexing.** SlopOS D-OBS rejects a global query/search service as a Phase-1 default. That maps directly to repeated-query leakage: Harbor should not let a public aggregate front door become an unbounded reconstruction oracle.

- **Replay bundles are sensitive even when answers are aggregates.** SlopOS `CH-RRBUNDLE v0` warns that replay bundles may contain secrets, device reads, and user data. Harbor keeps the raw survivor set hidden while separately reviewing whether the aggregate answer itself can be released.

- **Digest-first audit does not disclose plaintext.** SlopOS `CH-CRYPTOAUDIT v0` keeps audit evidence redaction-safe by using digests, lengths, decisions, and policy links instead of raw secrets. Harbor borrows the shape for disclosure receipts: release proof can cite policy and risk checks without dumping contributor identities.

- **Budgets are explicit but not ambient.** SlopOS `CH-BUDGET v0` and payer semantics separate explicit bounded spending authority from ambient current-payer folklore. Harbor borrows only the humility: a disclosure-budget note must be explicit process residue, not a hidden global counter, access token, or authority grant.

## Companion-cube pressure
- **Foundry:** pinned cuts and package manifests are the right home for exact source/public-copy cut identity. Harbor should not own the substrate, only the membrane-facing release-risk receipt.

- **Helm:** review queues, least-widening, and user-visible warnings map to safe refusal copy and coarser-answer alternatives. Helm remains the likely surface for human-facing release review, not Harbor.

- **Schell:** basis cards and activation receipts warn that a release-budget note is not authority to run more queries or re-export results.

- **ViewFS:** materialization/export discipline keeps disclosure-treated public copies as new artifacts with labels, not weaker aliases for internal exact answers.

- **Steward:** refusal lifecycle and followthrough matter when a request is denied, delayed, or redirected to a coarser answer; generalized remediation still belongs with Steward.

- **Ward:** tier/history witnesses suggest the public copy must carry release labels through history. A noisy or suppressed public answer should not later be mistaken for exact historical truth.

- **Foundry + SlopOS together:** pinned cuts plus bounded observation-export policy produce the key posture: public aggregates are artifacts with policy/cut/release labels, not database facts floating free.

## Harbor consequence
This pass closes `F078` by adding:

- `docs/00-meta/datacube-aggregate-disclosure-risk.md` — a review surface for release cells, contributor evidence, small-cell/dominance guards, sibling-cut differencing, repeated-query ledgers, disclosure-budget notes, noise receipts, and safe refusal copy;
- `docs/30-architecture/specimen-flow-78-aggregate-disclosure-small-cell-differencing-budget.md` — a concrete aggregate disclosure specimen;
- refreshed proof obligations, lessons, inspiration harvest, source register, bibliography, roadmap, ledgers, manifest, and briefing surfaces.

## What stays open
- Whether SlopOS owns durable aggregate-release policy or Harbor only emits small review residues.
- Whether the eventual privacy mechanism is suppression, perturbation, rounding, cell-key methods, differential privacy, human disclosure review, query throttling, or a mix.
- Whether disclosure-budget notes are tied to audience, source cut, query family, time window, public artifact, or all of the above.
- How BI tools, public mirrors, and downstream exports preserve disclosure-treatment labels.
- How public noisy/suppressed answers are corrected, restated, deprecated, or explained when exact internal history changes.

## Non-decision reaffirmed
No sibling cube is flattened into Harbor. SlopOS remains the likely owner of OS-level observation export policy, replay-bundle sensitivity, policy-killable export, and any eventual privacy-accounting substrate. Foundry remains better positioned for exact artifact/cut/package mechanics. Helm remains better positioned for user-facing review. Steward remains better positioned for remediation. Harbor only records the membrane-facing datacube residue needed to keep aggregate release from counterfeiting privacy safety.
