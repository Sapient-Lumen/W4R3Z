# SlopOS / companions evaluation — pass LXXV

This pass asks a design-phase datacube question rather than a warehouse-product question: if Harbor later grows a semantic front door, richer history exports, or explicit consumer contracts, what should it steal from the uploaded SlopOS ecology **without** freezing those choices too early?

## What the companions teach this pass
- **SlopOS** remains the strongest process teacher because it keeps current provider-owned truth, remembered request context, and published review surfaces visibly separate. That lesson transfers directly to a datacube: occurrence/validity/knowledge axes should stay named, semantic artifacts should stay derived, and helper exports should not silently become constitutional truth.
- **Foundry** keeps teaching that foreign realization is smaller than native realization. Harbor should steal that posture for contracts and lineage too: a selected bundle of checks or a helpful lineage receipt is still smaller than row meaning, smaller than lane truth, and smaller than a universal identity regime.
- **Ward** keeps teaching tier and resolution honesty. That is a good fit for joins and rollups: a same-shaped number is not yet safe to recombine, and a canonical-looking ID is not yet safe to treat as universal conformance truth.
- **Schell** keeps teaching supersession discipline and explicit agreed terms. Harbor can reuse that instinct for semantic exports and published contract slices: when an export or contract view changes, the archive should leave a promotion/supersession receipt instead of trusting moving-head folklore.
- **Steward** keeps teaching accountable aftermath and compact witnesses. That transfers well to freshness thresholds, contract subsets, history-loss posture, and any future row-lineage sidecar: small explicit receipts beat ambient trust.

## Harbor consequence
Harbor should make exactly one modest repo/process expansion now:
- add `docs/00-meta/datacube-review-loop.md` and wire it into repo hygiene so each design-phase datacube revision keeps sources, lessons, open questions, and packaging in sync;
- refresh the source register with the latest load-bearing lessons around additive evolution, explicit contract subsets, join-relationship discipline, history-loss warnings, and optional row-lineage posture; and
- add one new open question plus one queued followthrough item around semantic-front-door exports, contract subsets, and row-lineage sidecars while keeping the current measurement-semantics specimen pressure test as the single `next` slot.

## Still-not-yet decisions
- whether Harbor ever adopts one first-class semantic front door at all;
- whether row lineage becomes a first-class Harbor noun or stays an optional sidecar/receipt;
- whether contract subsets and freshness witnesses later become durable cards or remain process residue;
- whether any generated semantic export, catalog object, or API descriptor ever becomes canonical.

For now, the companion lesson is enough: **treat semantic exports as compiled artifacts, treat contracts as narrower than all assertions, keep history-loss explicit, and collect row-lineage ideas without turning them into premature constitution.**
