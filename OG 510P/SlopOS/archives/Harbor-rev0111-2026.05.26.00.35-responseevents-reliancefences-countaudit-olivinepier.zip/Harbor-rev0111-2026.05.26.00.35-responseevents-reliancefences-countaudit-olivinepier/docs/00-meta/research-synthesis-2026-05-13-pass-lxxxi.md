# Research synthesis — 2026-05-13 pass LXXXI

Question: how should Harbor pressure-test `F076` — replay after compaction, frozen-cut survivability, expired tombstone evidence, sidecar-retention mismatch, and exact historical answer requests — without promoting a storage engine, backup product, lakehouse format, immutable archive law, replay service, or final SlopOS datacube constitution?

## Result of this pass
The strongest next move is to split historical answers into a **survivability verdict** rather than a binary replay claim.

This pass therefore adds:

- `docs/00-meta/datacube-replay-survivability.md` — a compact review surface for survivor sets, retention-window notes, replay-readiness, explainable-but-not-replayable verdicts, and exact-answer refusals; and
- `docs/30-architecture/specimen-flow-76-replay-survivability-retention-window-exact-answer.md` — a concrete specimen covering replay after compaction, frozen answer/cut survival, expired tombstone evidence, sidecar retention mismatch, and a consumer asking for an exact old cube answer.

This closes `F076` while preserving the design-phase stance: Harbor can say which historical answers can still be recomputed, which can only be returned from a frozen answer packet, which can only be explained, and which must be refused.

## External lessons folded into this pass
1. **Time travel is a retention contract, not magic memory.** Iceberg snapshots support time-travel and rollback only while valid snapshots remain; expiring old snapshots removes them from metadata and makes them unavailable for time-travel queries. Delta Lake's `VACUUM` similarly removes old unreferenced data files and loses time travel beyond the retention period. Harbor should never say “exact historical answer available” merely because a table format once supported time travel.

2. **Cleanup is a cost / history tradeoff.** Hudi cleaning explicitly balances old-version retention against storage cost, while still preserving enough history for snapshot isolation and readers. Harbor should steal the explicit tradeoff: every replayable answer has a survivor budget, and every survivor budget has a cost and expiry posture.

3. **Tombstone retention bounds consumers.** Kafka's log-compaction setting for tombstones bounds how long a consumer has to read from offset zero and still obtain a valid final-state snapshot. Harbor should treat tombstone expiry as loss of negative evidence, not proof that the deleted event never existed.

4. **Fail-safe is not ordinary query access.** BigQuery's fail-safe period can preserve deleted data for emergency recovery after the time-travel window, but it is not directly queryable and does not restore all metadata. Snowflake similarly distinguishes user-queryable Time Travel from Fail-safe and makes retention-period changes consequential. Harbor should name emergency recoverability separately from ordinary exact answerability.

5. **State snapshots are scoped to programs and identifiers.** Flink savepoints are consistent images of job state; operator IDs matter for restoration, and dropped operators can leave non-restored state. Harbor should not let a streaming savepoint masquerade as a datacube replay cut unless the state, program identity, input cuts, and output contract are all named.

6. **Frontier compaction is a progress claim with loss semantics.** Differential-dataflow-style frontiers can compact old differences by advancing them to a frontier. Harbor should keep progress compaction separate from source erasure and from answer reproducibility: after compaction, some exact old cuts may be lost even though current answers remain correct.

7. **SlopOS already warns that rollback is not data rollback.** SlopOS RFC-0097's migration-gate posture and SlopOS record/replay/snapshot surfaces imply that mutable data and replay evidence require explicit barriers. Harbor applies that directly to datacube answers: old code, old query text, old sidecars, and old tombstones do not automatically survive together.

## New process shape
`docs/00-meta/datacube-replay-survivability.md` names seven review handles:

- survivor set;
- replay-readiness receipt;
- frozen-answer packet;
- retention-window note;
- sidecar-retention mismatch note;
- explainable-but-not-replayable verdict;
- exact-answer refusal row.

These are not canonical schema objects. They are review vocabulary for specimens, promotion packets, and future SlopOS datacube work.

## Specimen selected
Specimen flow 76 models a public callback datacube slice that was previously published and later requested as an exact historical answer after maintenance:

- the base table has been compacted and old snapshots may be expired;
- one frozen published answer packet survives;
- a late correction's tombstone evidence expired before a later consumer replay;
- a row-lineage sidecar expired sooner than the base aggregate cut;
- a view/query definition remains, but the target engine and policy epoch moved;
- the consumer asks for an exact answer, not a best-effort explanation.

A naive system would answer from current state, run the latest query, fill missing sidecars with blanks, or call emergency/fail-safe recovery equivalent to normal time travel. Harbor refuses those counterfeits.

## Still not decided
- one archival storage engine, lakehouse format, backup product, replay service, or event log;
- one retention policy for base rows, tombstones, sidecars, sketches, views, policies, and compiler targets;
- one public replay-survivability API;
- one answer-pack format;
- whether frozen answer packets belong in Harbor, SlopOS, Foundry, Steward, or a shared datacube substrate;
- whether `replay-readiness`, `retention-window`, or `explainable-not-replayable` becomes first-class Harbor vocabulary.

The deeper lesson is: **a historical answer has a survivor set, not a vibe.**
