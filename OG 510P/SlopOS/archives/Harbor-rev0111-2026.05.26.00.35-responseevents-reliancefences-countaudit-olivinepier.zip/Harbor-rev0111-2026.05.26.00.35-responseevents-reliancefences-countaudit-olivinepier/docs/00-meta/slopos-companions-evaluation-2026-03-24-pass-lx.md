# SlopOS / companions evaluation — pass LX

This pass re-checks Harbor against SlopOS and the sibling cubes after adding a trusted-schema-audience-note / schema-rotation-repair-receipt / detail-retry-cache-epoch specimen, and again chooses one narrow retry seam over any early registry bloom.

## What the current cubes still teach
- **SlopOS** remains the strongest restraint mechanism. Its MCP / auth-metadata / response-packaging boundaries keep imported metadata endpoints, response-body packaging, and provider acceptance rules provider-local or request-local rather than durable portable policy truth. That lines up directly with Harbor treating actionable authorization-details bodies as retry-scoped residue only.
- **SlopOS** also reinforces that fetched schemas, provider acceptance surfaces, and response packaging can stay local to the provider boundary even when they are machine-readable. That makes it a good warning against turning trusted-authorization-server sets or schema-rotation repairs into platform-wide truth.
- **Ward** still reinforces visible-veto posture: a replayed or stale actionable body can be structurally plausible and still deserve a typed bottom.
- **Helm** still contributes repair-surface humility: a front door can explain that the next retry needs fresh metadata or a new approval turn without claiming durable policy truth.
- **Foundry** still teaches aftermath honesty: a repaired retry, a stale body, or a rotated schema are good receipts, not runtime authority.
- **ViewFS** still reminds us that fetched JSON or replayed structured blobs do not become fresh native truth merely because they are available locally.

## Harbor consequence
Harbor should keep this move modest:
- add one specimen around **trusted-schema-audience note**, **schema-rotation repair receipt**, and **detail-retry cache epoch**;
- keep actionable body, trusted-AS set, schema source, metadata cache, and later granted details visibly separate; and
- leave any future trusted-authorization-server matrix, retry-body cache registry, or schema-rotation policy family outside Harbor for now.

## Still-not-yet decisions
- Whether **trusted-schema-audience note** deserves its own Harbor family, or should remain only an annotation on specific challenge/retry surfaces.
- Whether **schema-rotation repair receipt** belongs in Harbor at all, or should remain only a local aftermath note attached to specific challenge/retry specimens.
- Whether **detail-retry cache epoch** belongs in Harbor, or should stay a typed local explanation that never blooms into a portable cache, retry, or trusted-AS registry.
