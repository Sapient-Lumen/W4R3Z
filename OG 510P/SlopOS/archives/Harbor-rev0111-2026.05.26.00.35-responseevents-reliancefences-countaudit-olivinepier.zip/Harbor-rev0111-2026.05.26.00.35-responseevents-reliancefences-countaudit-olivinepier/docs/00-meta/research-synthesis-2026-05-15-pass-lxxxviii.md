# Research synthesis — pass LXXXVIII, stale downstream impact and remediation humility

**Revision:** `rev0088`  
**Date:** 2026-05-15  
**Question:** Once Harbor can identify stale downstream copies, how should it record impact, acknowledgements, remediation claims, and use attestations without pretending it can know every use or certify every repair?

## Result

Harbor should treat stale downstream use as a chain of scoped statuses, not as a binary incident badge.

The useful distinction is:

1. stale copy exposed;
2. stale copy used or non-use claimed;
3. reliance/impact assessed;
4. correction notice acknowledged;
5. remediation claimed;
6. remediation observed or verified;
7. residual risk published or carried forward;
8. old copy kept historical-only, unsafe-for-new-use, disputed, or unrepairable-now.

The next useful handles are `stale_use_impact_packet`, `consumer_acknowledgement_receipt`, `remediation_attestation`, `use_attestation_note`, `safe_public_impact_statement`, `residual_risk_note`, and `unrepairable_now_notice`. They should remain process residue.

## External lessons folded in

- VEX and CSAF are valuable because they scope status to specific products/components/vulnerabilities and distinguish statuses such as affected, not affected, fixed, and under investigation. Harbor should steal scoped-status discipline, not vulnerability-management governance.
- CISA's minimum VEX requirements and OpenVEX's affected/not-affected logic show that a status needs a justification or action statement. Harbor should require remediation claims to name subject, action, evidence, and residual risk.
- SLSA/in-toto provenance and verification-summary attestations show a clean subject/predicate/predicate-type pattern and parsing humility: consumers ignore unknown fields and major-version changes mark incompatibility. Harbor should borrow attestation shape for scoped remediation/use claims, not invent a broad trust registry.
- W3C Dataset Usage Vocabulary exists because publishers need structured ways to learn how datasets are cited, used, and discussed. Harbor can borrow use/feedback/citation framing for consumer acknowledgement receipts.
- W3C Data Quality Vocabulary is useful because quality information supports fitness-for-purpose judgment rather than claiming one universal quality truth. Harbor should keep impact/materiality lanes contextual.
- NIST AI RMF and OECD/AIID incident work reinforce socio-technical impact: actual harm, hazard, context, human interpretation, and response matter. Harbor should not reduce stale public-copy contamination to file replacement alone.
- PROV invalidation/revision and Crossmark/DataCite relation patterns remain useful background: old copies can be superseded, corrected, or invalidated for a named purpose while still existing as historical artifacts.

## SlopOS-specific interpretation

SlopOS is still design-phase. That is decisive. Do not invent a global stale-use registry, model-unlearning protocol, customer-notice pipeline, or incident taxonomy.

The SlopOS lesson is boundary discipline:

- imported provenance is digest-bound evidence, not recursive authority;
- LLM/tool text cannot become trusted UI or approval truth;
- cached/source/copy status must not collapse into capability grants;
- claim receipts should stay smaller than facts they claim about;
- negative evidence, refusal, and stale-frontier patterns matter just as much as positive repair claims.

Harbor should therefore record stale downstream impact as scoped evidence with authority limits, not as durable truth about the whole ecosystem.

## New watchlist handles

- `stale_use_impact_packet`
- `consumer_acknowledgement_receipt`
- `remediation_attestation`
- `use_attestation_note`
- `safe_public_impact_statement`
- `residual_risk_note`
- `unrepairable_now_notice`
- `historical_only_notice`
- `unsafe_for_new_use_notice`

## What stayed open

- public status API;
- customer-notification and acknowledgement workflow;
- legal/remediation process;
- audit evidence format;
- VEX/CSAF or in-toto profile;
- AI incident reporting taxonomy;
- model unlearning or evaluation repair governance;
- external dispute arbitration;
- final SlopOS datacube shape.
