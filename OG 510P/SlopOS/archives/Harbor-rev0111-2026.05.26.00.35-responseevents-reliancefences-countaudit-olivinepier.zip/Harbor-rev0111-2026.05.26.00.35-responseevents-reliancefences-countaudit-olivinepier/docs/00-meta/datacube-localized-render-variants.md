# Datacube localized render variants

**Status:** design-phase review surface for `rev0085`; not an ADR, schema, package format, renderer API, i18n framework, accessibility conformance program, translation system, BI governance product, or final SlopOS datacube constitution.

## Why this exists

Public-copy hygiene in `rev0084` made labels, mirrors, restatements, recomposition guards, and proof-of-copy tickets visible. `F080` applies the next pressure: a labeled public copy can be translated, localized, charted, summarized, paginated, sorted, grouped, or made accessible. Those variants help humans, but they can quietly become a second truth plane.

Harbor should collect the idea, not freeze the mechanism. A render variant is evidence-bearing because it can add, remove, reorder, hide, or mistranslate proof cues. A render variant is not source truth because the public artifact, label digest, release cut, and proof obligations remain upstream.

## Tight stance

- **Presentation is evidence-bearing, not authoritative.** A rendering can be valid, invalid, stale, partial, or explanatory-only; it does not become the canonical public artifact.
- **Locale formatting changes notation, not basis.** Decimal marks, grouping separators, percent display, date order, unit names, plural forms, and collation must point back to canonical value, unit, time axis, and label digest.
- **Translation changes human strings, not machine labels.** Machine label IDs, suppression/noise/exactness labels, non-promises, and restatement links must survive translation.
- **Accessibility variants are alternate review surfaces.** A data table, long description, caption, transcript, or keyboard-order repair is not permission to omit the labels that made the copy honest.
- **Human summaries need tethers.** A plain-language summary can explain a release, but if it omits proof labels it must be marked explanatory-only and tethered to the labeled bundle.
- **Renderer transforms are semantic hazards.** Sorting, filtering, grouping, top-N folding, pagination, truncation, pivoting, locale collation, and screen-reader order can all change what a consumer infers.

## Render-variant modes under observation

| Mode | Useful shape | Counterfeit to avoid |
| --- | --- | --- |
| `canonical_labeled_bundle` | Release artifact with label digest, payload digest, cut, and non-promises | Treating every rendered copy as equally proof-grade |
| `translated_label_set` | Human strings in another language with machine label IDs preserved | Translating away suppression/noise/exactness caveats |
| `locale_formatted_value` | Number/date/unit display with locale and resolved options recorded | Treating display conversion as a new measurement basis |
| `accessible_table_variant` | Table with bound headers, caption, source link, labels, and reading order | A hidden or unlabeled table that cannot prove equivalence |
| `chart_plus_table_variant` | Chart with short description, long description, and source-data table | Chart-only publication with unreachable data and no labels |
| `plain_language_summary` | Clear explanation tethered to the bundle and audience | Summary becoming the public copy or proof packet |
| `label_omitting_summary` | Explanatory-only copy that admits omitted machine labels | Claiming proof-grade status without label preservation |
| `renderer_reordered_copy` | Declared sort/collation/pagination transform | Local sort order changing top/bottom meaning silently |
| `renderer_grouped_copy` | Declared grouping, top-N, and “other” handling | Grouping away small-cell/suppression/noise warnings |
| `unknown_renderer_variant` | Quarantined copy until transform and labels are checked | Assuming downstream UI output inherited all labels correctly |
| `invalid_semantic_variant` | Refused or repaired copy | Letting a mistranslation or inaccessible chart stand as data |

## Candidate receipt fields

These are watchlist handles, not promoted schema.

### Locale receipt

- source public artifact ID and payload digest;
- label digest used by the source copy;
- language tag and locale tag;
- numbering system, calendar, time zone, unit display, currency display, percent display, and rounding posture when relevant;
- canonical value, canonical unit, and display-only flag;
- renderer or library name/version if known;
- unsupported-locale fallback and whether fallback changed strings, sorting, or formatting.

### Translation receipt

- source machine label IDs;
- human language tag;
- translator/reviewer source: human, machine, mixed, or unknown;
- glossary or reserved terms, especially `not_exact_public_copy`, `coarsened_for_disclosure`, `suppressed`, `perturbed`, `restated`, `withdrawn`, and `not_a_dp_claim`;
- unresolved terms and review warnings;
- evidence that machine IDs and non-promises survived translation.

### Accessible-variant receipt

- source artifact, cut, and label digest;
- table caption, row/column header binding, scope/headers posture, and source-data link;
- chart short description and long description or equivalent text;
- keyboard/focus order when interactive;
- color-only meaning check and redundant symbol/texture/text cues;
- whether the chart is hidden from assistive technology only because an equivalent table is present;
- labels carried into the accessible surface.

### Human-summary tether

- source artifact and label digest;
- audience and reading-level goal, if any;
- explicit omitted-label list;
- non-promises that remain visible;
- statement that the summary is explanatory-only unless all proof labels and release receipts are preserved;
- link or pointer to the proof-grade labeled bundle.

### Render-transform note

- sort order and collation;
- filters;
- grouping/pivoting;
- top-N/“other” rules;
- pagination/truncation;
- chart aggregation/resampling;
- row hiding and screen-reader order;
- whether exact values, suppression labels, noise labels, and recomposition guards survived.

## Minimum proof obligations before any promotion

A candidate render-variant noun must show at least these before it graduates from process residue:

1. It names the source public artifact, payload digest, label digest, and source cut.
2. It states the variant audience and render mode.
3. It records locale/translation/accessibility/render-transform posture at the level needed to detect drift.
4. It shows which labels were preserved, translated, omitted, or weakened.
5. It separates canonical values from display strings.
6. It states whether the variant is proof-grade, explanatory-only, stale, partial, invalid, or refused.
7. It has a repair lane for mistranslation, stripped labels, inaccessible charts, stale summaries, and renderer drift.

## Anti-counterfeit checks

- If a locale-formatted percent cannot point to a unity-ratio source and rounding basis, it is a display string, not a value.
- If a translated copy loses machine IDs or non-promises, it is not a valid labeled copy.
- If a chart has no data table or text equivalent, it is not a proof-grade public copy.
- If a summary omits suppression/noise/exactness labels, it must say it is explanatory-only.
- If a renderer changes sorting, grouping, filtering, top-N, or pagination without a transform note, it is invalid until repaired.
- If accessible output is generated from a stale cache while the labeled bundle has been restated, it needs a restatement link or refusal.
- If an assistive or translated surface enables recomposition that the original public copy forbids, it inherits the recomposition hazard.

## Promotion triggers

Only consider promoting a durable noun after repeated specimens show that:

- several renderers produce useful but detectably different variants;
- translated label sets repeatedly need a stable glossary/non-promise preservation lane;
- accessible chart/table alternates need a repeated equivalence receipt;
- summaries repeatedly need a standardized tether/refusal line;
- locale sorting/formatting repeatedly changes consumer inference.

Until then, keep `locale receipt`, `translated-label set`, `accessible variant`, `render-transform note`, and `summary tether` as process residue.

## Explicit non-decisions

This document does not choose a localization library, translation-memory system, language-tag profile, WCAG conformance target, charting library, BI/export platform, data-package format, public portal, accessibility testing program, renderer API, renderer registry, or final SlopOS datacube shape.
