## Pass CII load-bearing sources — artifact handoff and consumer import

| ref_id | why it is load-bearing for Harbor now | stability posture | review trigger |
|---|---|---|---|
| `EXT-BAGIT-RFC8493` | keeps received material tied to manifest completeness and checksum verification without knowing payload semantics | stable IETF RFC | before borrowing bag/manifest language for handoff checks |
| `EXT-SPDX-PACKAGE-VERIFICATION-2026` | keeps package-content identity separate from the metadata document that describes it | stable specification material as consulted | before treating embedded descriptors as package identity |
| `EXT-RO-CRATE-SPECS-2026` | distinguishes crate-as-a-whole, data entities, files, folders, and web-addressable resources | current specification material as consulted | before modeling extracted trees or copied member files |
| `EXT-OCI-IMAGE-LAYOUT-2026` | separates content-addressable blobs from location-addressable refs and transport mechanisms | living OCI specification | before treating paths, refs, or archive transport as identity |
| `EXT-FRICTIONLESS-DATA-PACKAGE-2026` | shows dataset packages described by descriptors without making the descriptor a verification result | current standard material as consulted | before borrowing data-package wording for consumer import |

## Pass C load-bearing sources — checker provenance and drift

| ref_id | why it is load-bearing for Harbor now | stability posture | review trigger |
|---|---|---|---|
| `EXT-SLSA-PROVENANCE-V1` | keeps source/procedure provenance focused on where, when, and how a thing was produced rather than correctness | stable SLSA documentation as consulted | before treating checker provenance as subject truth or trust root |
| `EXT-SLSA-VERIFYING-ARTIFACTS-2026` | keeps verification as expectation-based inspection rather than provenance existence alone | stable SLSA documentation as consulted | before promoting checker observations to reliance decisions |
| `EXT-OPA-DECISION-LOGS-2026` | keeps policy query, input, bundle metadata, and audit/debug context attached to a decision | living project docs | before comparing checker observations or policy/verifier outcomes |
| `EXT-OPA-BUNDLES-2026` | keeps policy/data bundle integrity and activation distinct from the decision result | living project docs | before relying on current checker/policy source for old observations |
| `EXT-GITHUB-ARTIFACT-ATTESTATIONS-2026` | shows build provenance as signed claims that still need verification context | living platform docs | before using artifact-attestation language for Harbor release packages |
| `EXT-GITHUB-ATTESTATION-VERIFY-2026` | requires cryptographic verification of signature, timestamp, and signer identity for meaningful security benefit | living platform docs | before accepting attestation presence as security evidence |
| `EXT-REPRODUCIBLE-BUILDS-RECORDING-2026` | requires relevant build-environment information to be defined or recorded | living project guidance | before claiming deterministic package or reproducible release evidence |

## Pass XCVII load-bearing sources — verifier disagreement and policy-epoch drift

| ref_id | why it is load-bearing for Harbor now | stability posture | review trigger |
|---|---|---|---|
| `EXT-SLSA-VERIFYING-ARTIFACTS-2026` | keeps provenance useful only after verifier inspection against expectations | stable SLSA v1 documentation as consulted | before treating a provenance pass as trust or public badge |
| `EXT-SIGSTORE-POLICY-CONTROLLER-2026` | frames supply-chain metadata decisions as admission-policy decisions, not universal truth | living project docs | before borrowing admission or deployment-policy language |
| `EXT-TUF-SPEC-LATEST-2026` | keeps version, expiration, rollback, and freeze checks explicit for epoch/currentness drift | living specification; check before relying on exact wording | before promoting policy-epoch or currentness vocabulary |
| `EXT-C2PA-VALIDATION-2-4-2026` | keeps validation, status codes, and user presentation separate from truth and editorial judgment | current technical specification as consulted | before exposing media/content-credential badge posture |
| `EXT-IN-TOTO-SPEC-VERIFY-2026` | shows verification depends on layout, links, and inspections rather than one ambient verdict | living spec repository | before using layout/inspection style verifier results |
| `EXT-OPA-DECISION-LOGS-2026` | requires policy query, input, and bundle metadata for auditable policy decisions | living project docs | before comparing verifier policy decisions or drift |
| `EXT-OPA-BUNDLES-2026` | policy/data bundles can update on the fly; later active policy must not silently rewrite old decisions | living project docs | before modeling policy epoch updates or eventual consistency |


## Pass XCVI load-bearing sources — transparency/provenance receipt import

| ref_id | why it is load-bearing for Harbor now | stability posture | review trigger |
|---|---|---|---|
| `EXT-SCITT-ARCHITECTURE-2025` | keeps signed statements, receipts, registration policies, relying parties, auditors, and transparency services distinct | active IETF draft/RFC-ed-queue material | before importing inclusion receipts or relying on logged statements |
| `EXT-C2PA-SPEC-2-4-2026` | keeps asset manifests/content credentials and provenance assertions useful but smaller than real-world authenticity or editorial approval | current technical specification | before using content credentials for public-copy or media-asset evidence |
| `EXT-IN-TOTO-ATTESTATION-2026` | provides subject/predicate/material structure for verifiable claims without one verdict plane | living open specification | before accepting attestation envelopes as Harbor evidence |
| `EXT-SLSA-PROVENANCE-V1` | keeps build provenance focused on where/when/how an artifact was produced | stable SLSA v1 provenance documentation as consulted | before treating build provenance as broad trust or deployment truth |
| `EXT-SIGSTORE-REKOR-2026` | distinguishes transparency-log storage, retrieval, inclusion proof, and integrity verification | living project docs | before using log entries as public receipts |
| `EXT-RFC9162-CT-2022` | supplies inclusion/consistency and append-only audit concepts for currentness cuts | stable IETF RFC | before promoting log/currentness vocabulary |
| `EXT-RFC3161-TSP-2001` | keeps timestamp tokens tied to message-imprint existence time and TSA policy, not event truth | stable IETF RFC | before accepting timestamp anchors or ordering evidence |


## Pass XCIV load-bearing sources — crossing records and warning lifecycle guards

| ref_id | why it is load-bearing for Harbor now | stability posture | review trigger |
|---|---|---|---|
| `EXT-MCP-SPEC-2025-11-25` | separates tools/resources/prompts and client capabilities from semantic trust; useful for tool metadata humility | living protocol specification | before promoting MCP/tool-resource crossing vocabulary |
| `EXT-MCP-SECURITY-BEST-PRACTICES-2026` | reinforces consent, privacy, tool annotation distrust, and server trust posture | living security guidance | before trusting tool annotations or resource listings |
| `EXT-XDG-OPENURI` | demonstrates mediated URI opening where request evidence is separate from presentation and user cognition | stable desktop portal documentation | before treating portal-mediated openings as user comprehension |
| `EXT-WEBAUTHN-3` | keeps browser-mediated public-key credentials scoped and ceremony-bound | W3C Recommendation-track material | before treating credential presentation as global identity |
| `EXT-FEDCM-W3C` | keeps federated identity browser-mediated and privacy-scoped | W3C work as consulted | before treating identity crossing as durable local authority |
| `EXT-RFC9700-OAUTH-SECURITY-BCP-2025` | consolidates OAuth security best practices and insecure-flow deprecations | IETF BCP/RFC | before treating OAuth completion as broader authorization truth |
| `EXT-NIST-SP800-226-DP-2025` | requires DP claims to carry mechanism, parameters, adjacency, contribution bounds, and accounting posture | stable NIST publication | before making DP-style public-copy claims |
| `EXT-IETF-SCITT-RFC9943-AUTH48-2026` | keeps signed statement inclusion and relying-party judgment separate from truth/currentness | RFC Editor material as consulted | before using transparency receipts as verification |

## Pass XCIII load-bearing sources — correction implementation and monitoring hygiene

| ref_id | why it is load-bearing for Harbor now | stability posture | review trigger |
|---|---|---|---|
| `EXT-CSAF-2-1-2026` | reinforces remediation categories, product scope, availability dates, and conversion warnings without importing advisory governance | OASIS Committee Specification as consulted | before promoting correction instruction or implementation-status vocabulary |
| `EXT-OPENVEX-SPEC-2026` | keeps status as product/vulnerability relationship evidence and minimal/SBOM-agnostic, resisting global fixed badges | living open specification | before using affected/fixed/under-investigation or action status language |
| `EXT-NIST-SP800-61R3-2025` | frames response/recovery/improvement as ongoing risk-management activities, supporting monitoring windows without incident-program import | stable NIST final publication | before promoting post-decision monitoring or lessons-learned surfaces |
| `EXT-IETF-SCITT-RFC9943-AUTH48-2026` | separates signed statements, receipts, relying parties, auditors, and rejection/ignore conditions; useful for currentness humility | active IETF/RFC Editor material | before treating implementation-publication receipts as truth or current reliance |
| `EXT-IN-TOTO-ATTESTATION-2026` | supplies step/subject/materials/byproducts discipline for implementation evidence without forcing a predicate | living open specification | before promoting implementation evidence receipts or step attestations |
| `EXT-W3C-PROV-DM-2013` and `EXT-W3C-PROV-INVALIDATION-2013` | provide generation/revision/invalidation relation language for corrected and superseded public copies | stable W3C recommendations | before promoting rollback, invalidation, or successor-copy terms |
| `EXT-DATACITE-RELATED-IDENTIFIERS-2026` | supplies explicit relation labels for prior/new versions, reviews, variants, metadata, and obsolescence | living metadata-schema documentation | before adding public-copy relation labels after implementation |
| `EXT-STATUSPAGE-INCIDENT-COMMS-2026` | separates active updates, resolution, and postmortem communication; useful for public-status/proof-packet separation | living product guidance | before borrowing public status or monitoring-copy vocabulary |

## Pass XCII load-bearing sources — external decision return and adoption hygiene

| ref_id | why it is load-bearing for Harbor now | stability posture | review trigger |
|---|---|---|---|
| `EXT-CSAF-2-1-2026` | reinforces structured creation/update/exchange of scoped status and remediation claims without importing advisory governance | OASIS Committee Specification, current as consulted | before promoting correction instruction receipts or status/remediation vocabulary |
| `EXT-OPENVEX-SPEC-2026` | keeps status as a relationship between named product and vulnerability, supporting subject-bound finding returns | living open specification | before importing affected/fixed/under-investigation language or non-use claims |
| `EXT-SCITT-ARCHITECTURE-2025` | separates signed statements, receipts, registration policies, relying parties, auditors, and divergent transparency services | active IETF draft/RFC-ed-queue material | before treating logged outside findings as truth or currentness |
| `EXT-W3C-PROV-DM-2013` | provides revision/derivation and expanded-relation language for public-copy updates and historical evidence preservation | stable W3C Recommendation | before promoting post-review copy relations or memory-hole refusals |
| `EXT-DATACITE-RELATED-IDENTIFIERS-2026` | enumerates relation types for versions, derivations, review, obsolescence, translation, and metadata | living metadata-schema documentation | before adding public-copy relation labels or successor links |
| `EXT-C2PA-SPEC-2-4-2026` | distinguishes standard/update manifests and assertions without content changes; useful for wording/status updates with proof tethers | current technical specification | before borrowing update-manifest or redaction/ingredient patterns |

## Pass XCI load-bearing sources — handoff, appeal, and sealed-evidence hygiene

| ref_id | why it is load-bearing for Harbor now | stability posture | review trigger |
|---|---|---|---|
| `EXT-CERT-CVD-GUIDE-2017` | keeps stakeholder roles, coordination phases, and failure modes visible for source-owner/coordinator handoff without importing a CVD program | stable SEI/CERT guidance | before promoting external handoff packets or source-owner escalation receipts |
| `EXT-ISO-29147-AWI-2026` | keeps vulnerability disclosure packet contents, remediation information, policy considerations, and communications in view while the standard is under revision | under-development ISO work item | before borrowing disclosure-process language or communication packet requirements |
| `EXT-FIRST-TLP-2-0` | keeps sharing restrictions, source permission, and document/messaging labels attached to sensitive evidence | stable community standard | before promoting sealed evidence manifests or public/private packet splits |
| `EXT-FIRST-IEP-2-0` | keeps information-use restrictions explicit between provider and recipient | stable community framework | before promoting machine-readable handling policy or external evidence exchange notes |
| `EXT-IETF-IESG-APPEALS-2025` | keeps appeal contents, scope, public record, out-of-scope legal claims, and escalation paths visible without importing IETF governance | active IETF statement | before promoting appeal-window notes or challenged-status effects |
| `EXT-IAB-APPEALS-2026` | keeps appeal deadline, self-contained text, required fields, and resubmission handling visible | active IAB statement | before promoting appeal completeness or expiry semantics |
| `EXT-SCITT-ARCHITECTURE-2025` | keeps signed statements, receipts, registration policies, relying parties, auditors, and multiple transparency services separate | active IETF draft/RFC-ed-queue material | before promoting transparency/log evidence or external receipt dependencies |

## Pass XC load-bearing additions

- **EXT-FIRST-PSIRT-SERVICES-1-1** — FIRST PSIRT Services Framework 1.1.
  - Harbor use: external communication, vetting, routing, and remediation-status channels inform escalation receipts without importing a PSIRT program.
- **EXT-FIRST-CSIRT-SERVICES-2-1** — FIRST CSIRT Services Framework 2.1.
  - Harbor use: third-party report intake and vulnerability/disclosure coordination posture support reporter-claim outcome maps without creating a tribunal.
- **EXT-STATUSPAGE-INCIDENT-COMMS-2026** — Atlassian Statuspage incident communication/postmortem guidance.
  - Harbor use: separates active updates, customer-facing status, and postmortems; informs warning escalation, cooldown, and historical-only sunset.
- **EXT-RFC9111-HTTP-CACHING** — reused.
  - Harbor use: freshness, stale response, and revalidation semantics shape cooldown/sunset language for public warnings.
- **EXT-IETF-RATS-RFC9334** — IETF RFC 9334 RATS architecture.
  - Harbor use: separates evidence generation, verifier appraisal, attestation results, and relying-party appraisal for repeated weak claims.
- **EXT-IETF-SCITT-RFC9943-AUTH48-2026** — reused.
  - Harbor use: signed-statement transparency helps audit recurrence/status publication while staying smaller than current truth.
- **EXT-SIGSTORE-REKOR-2026** — reused.
  - Harbor use: log inclusion and consistency support public-log/status divergence receipts without turning logs into verdicts.

## Pass LXXXIX load-bearing additions

- **EXT-NIST-SP800-61R3-2025** — NIST SP 800-61 Rev. 3.
  - Harbor use: response/recovery and risk-management framing support status reconciliation without importing a cyber-incident program.
- **EXT-CSAF-2-1-2026** — reused.
  - Harbor use: scoped status/remediation statements reinforce subject/action/evidence boundaries.
- **EXT-OPENVEX-SPEC-2026** — reused.
  - Harbor use: status plus action/justification discipline helps distinguish affected, fixed, under-investigation, and unsupported claims.
- **EXT-IN-TOTO-ATTESTATION-2026** — reused.
  - Harbor use: subject/predicate/envelope structure informs scoped claim receipts.
- **EXT-IETF-SCITT-RFC9943-AUTH48-2026** — IETF SCITT architecture in RFC Editor AUTH48 as RFC-to-be 9943.
  - Harbor use: signed-statement transparency helps publication/audit evidence while remaining smaller than truth verification.
- **EXT-RFC9162-CT-2022** — Certificate Transparency v2.
  - Harbor use: append-only log and audit/consistency concepts inform claim-publication receipts without deciding Harbor needs a log.
- **EXT-SIGSTORE-REKOR-2026** — reused.
  - Harbor use: inclusion and consistency proof ideas support transparency humility.
- **EXT-C2PA-SPEC-2-4-2026** — reused.
  - Harbor use: manifest/assertion/claim packaging informs public asset and generated-explanation status drift.
- **EXT-W3C-PROV-CONSTRAINTS-2013** — W3C PROV constraints.
  - Harbor use: validity/equivalence/consistency posture informs contradiction maps.
- **EXT-STATUSPAGE-API-2026** — Atlassian Statuspage API docs.
  - Harbor use: incident/component/update/postmortem separation informs public-status sync receipts without choosing a status product.

## Pass LXXXVIII load-bearing additions
- **EXT-CISA-VEX-MINIMUM-2023** — CISA minimum requirements for VEX.
  - Harbor use: scoped affected/not-affected/fixed/under-investigation status and action/justification fields inform remediation-attestation proof without importing vulnerability governance.
- **EXT-OPENVEX-SPEC-2026** — OpenVEX specification.
  - Harbor use: status plus justification/action_statement discipline helps distinguish remediation claimed, verified, refused, or under investigation.
- **EXT-CSAF-2-1-2026** — OASIS CSAF 2.1.
  - Harbor use: product/vulnerability status groups and remediation requirements reinforce named subject/action status instead of global fixed badges.
- **EXT-SLSA-PROVENANCE-V1** — SLSA provenance v1.
  - Harbor use: subject/predicate parsing and versioning humility support scoped use/remediation attestations without a custom trust registry.
- **EXT-SLSA-VSA-V1** — SLSA verification summary attestation v1.
  - Harbor use: verification summaries remind Harbor that a claim can summarize a verification result while still needing subject, policy, and version boundaries.
- **EXT-W3C-DUV-2016** — W3C Dataset Usage Vocabulary.
  - Harbor use: use/citation/feedback framing supports consumer acknowledgement and stale-use reporting without making every comment authoritative.
- **EXT-W3C-DQV-2016** — W3C Data Quality Vocabulary.
  - Harbor use: fitness-for-purpose and community quality information map well to contextual impact/materiality lanes.
- **EXT-OECD-AI-INCIDENTS-2026** — OECD AI risks and incidents / AI Incidents Monitor.
  - Harbor use: incidents and hazards require context, evidence, and response; stale model/eval copies deserve hazard/impact language without false closure.
- **EXT-AIID-2026** — AI Incident Database / Partnership on AI.
  - Harbor use: public reports of AI harms show why known incidents, institutional response, and learning should be visible, but Harbor should not become an AI-incident database.
- **EXT-NIST-AI-RMF-2026** — reused.
  - Harbor use: socio-technical risk and impact management support safe public impact statements and residual-risk notes.

## Pass LXXXVII load-bearing additions
- **EXT-SITEMAPS-PROTOCOL-2016** — Sitemaps XML protocol.
  - Harbor use: `loc` and `lastmod` are useful public-copy freshness signals, but optional tags and crawler support limits keep them smaller than source truth.
- **EXT-INDEXNOW-PROTOCOL-2026** — IndexNow URL-change protocol.
  - Harbor use: steal URL-change signal receipts for added/updated/deleted pages without choosing the protocol or guaranteeing reindexing.
- **EXT-RFC9309-ROBOTS-EXCLUSION-2022** — IETF Robots Exclusion Protocol.
  - Harbor use: crawler directives may be cached and are not content security; treat robots changes as future crawl signals, not deletion.
- **EXT-GOOGLE-ROBOTS-META-2026** — Google Search robots meta tag documentation.
  - Harbor use: page-level indexing/snippet controls are presentation/indexing signals distinct from source correction truth.
- **EXT-GOOGLE-REFRESH-OUTDATED-CONTENT-2026** — Google Refresh Outdated Content tool.
  - Harbor use: outdated snippets and images can be refreshed when live content changed, but the tool does not remove pages from the web.
- **EXT-GOOGLE-REMOVALS-REPORT-2020** — Google Search Console removals report.
  - Harbor use: temporary hide/cache-clear/snippet wipe are bounded search-result actions, not universal recall.
- **EXT-BING-SITEMAPS-AI-SEARCH-2025** — Bing Webmaster guidance on sitemaps in AI-powered search.
  - Harbor use: accurate `lastmod` timestamps help prioritize recrawling and AI answer freshness, but remain signals.
- **EXT-OPENAI-CRAWLERS-2026** — OpenAI crawler documentation.
  - Harbor use: search crawler and training crawler lanes differ; Harbor should not collapse search freshness and training-use exclusion.
- **EXT-COMMONCRAWL-OPEN-CORPUS-2026** — Common Crawl open web archive overview.
  - Harbor use: public web data can persist at huge archive scale; correction propagation must include stale historical copy notices.
- **EXT-COMMONCRAWL-ERRATA-2026** — Common Crawl errata page.
  - Harbor use: long-lived corpus issues need public errata over many releases; Harbor can steal explicit scope windows without claiming deletion.
- **EXT-HUGGINGFACE-DATASET-CARDS-2026** — Hugging Face dataset-card docs.
  - Harbor use: downstream dataset/eval copies need card-level context and responsible-use notices when stale material was absorbed.
- **EXT-W3C-PROV-INVALIDATION-2013** — W3C PROV namespace invalidation/revision terms.
  - Harbor use: invalidation/revision shapes help describe stale derived entities, but target sets must be named before claiming propagation.

## Pass LXXXVI load-bearing additions
- **EXT-W3C-WEB-ANNOTATION-2017** — W3C Web Annotation Data Model.
  - Harbor use: steal body/target/selector/provenance posture for public annotations without making annotations verdicts.
- **EXT-CROSSREF-CROSSMARK-2026** — Crossref Crossmark.
  - Harbor use: keep a current-status check near public copies and downloaded artifacts without adopting scholarly-publisher workflow wholesale.
- **EXT-NISO-CREC-2024** — NISO RP-45-2024, Communication of Retractions, Removals, and Expressions of Concern.
  - Harbor use: correction/retraction/removal status needs metadata creation, transfer, and display discipline for both original and notice.
- **EXT-SCHEMAORG-CORRECTION-2026** — Schema.org `correction` / `CorrectionComment`.
  - Harbor use: lightweight web correction pointers are useful, but Harbor still needs digests, cuts, labels, and proof obligations.
- **EXT-DATACITE-RELATED-IDENTIFIERS-2026** — DataCite related identifiers and version/correction relations.
  - Harbor use: restatements and corrections should link old/new/canonical/obsoleted artifacts instead of overwriting public history.
- **EXT-JATS-RELATED-ARTICLE-2015** — NISO JATS related-article-type values.
  - Harbor use: corrected, correction-forward, retracted, partial-retraction, and commentary relations show why one generic “related” link is too weak.
- **EXT-NIST-AI-RMF-2026** — NIST AI Risk Management Framework materials.
  - Harbor use: generated explanations need documentation, reviewability, and risk-managed context rather than proof-grade status by default.
- **EXT-C2PA-SPEC-2-4-2026** — C2PA technical specification.
  - Harbor use: content provenance and hard/soft binding ideas inform generated explanation and corrected-render provenance without becoming Harbor's proof system.

# Load-bearing source register

## Pass LXXXV load-bearing additions
- **EXT-WCAG-2-2-2024** — W3C, Web Content Accessibility Guidelines (WCAG) 2.2.
  - Harbor use: accessibility claims for render variants need named, reviewable checks rather than vibes.
- **EXT-WAI-COMPLEX-IMAGES-2026** — W3C WAI tutorial on complex images.
  - Harbor use: chart variants need more than short alt text; long descriptions or equivalent data/text must carry labels.
- **EXT-USWDS-DATA-VIZ-2026** — U.S. Web Design System data-visualization guidance.
  - Harbor use: SVG/chart renderings need accessible data-table equivalents and narrative summaries kept distinct.
- **EXT-W3C-I18N-AUTHORING-2026** — W3C internationalization authoring techniques and language-tag guidance.
  - Harbor use: translated copies should declare language/locale posture, not infer it from flags or filenames.
- **EXT-UNICODE-CLDR-2026** — Unicode Common Locale Data Repository materials.
  - Harbor use: locale affects numbers, dates, units, and collation; render receipts need resolved locale behavior.
- **EXT-UNICODE-LDML-2026** — Unicode Locale Data Markup Language (UTS #35).
  - Harbor use: structured locale data is interchange evidence, not a Harbor commitment to a locale-data stack.
- **EXT-ECMA-402-2026** — ECMAScript Internationalization API Specification.
  - Harbor use: resolved locale-sensitive formatting options are useful witness material, while parsing/canonical measurement remains separate.
- **EXT-DIGITALGOV-PLAINLANG-2026** — Digital.gov / plain-language guidance.
  - Harbor use: summaries should serve the audience, use clear organization, and remain tethered to proof labels.
- **EXT-WAI-COGA-CLEAR-CONTENT-2026** — W3C cognitive-accessibility clear-content guidance.
  - Harbor use: simpler language helps but can lose mathematical/proof caveats; mark explanatory-only when labels are omitted.

This is a lightweight hygiene surface, not a lockfile.

Harbor is still in design phase, so the right move is to mark which outside sources are currently load-bearing enough that future editors should deliberately refresh them before promoting new datacube nouns or contracts.

## Why this exists
- several datacube-shaping sources are living docs, recent product documentation, or active project guidance rather than timeless law;
- bibliography links help discovery, but they do not tell future editors which sources deserve a deliberate re-check before promotion;
- Foundry and SlopOS both show that lightweight review discipline beats silent drift.

## Current rows

| ref_id | why it is load-bearing for Harbor now | stability posture | review trigger |
|---|---|---|---|
| `EXT-W3C-RDF-DATA-CUBE` | keeps observation/component discipline visible without forcing Harbor into RDF or one giant cube ontology | stable W3C recommendation | before promoting observation/component vocabulary or cube-shaped exchange exports |
| `EXT-ICEBERG-VIEW-SPEC` | keeps derived views as metadata/version-log artifacts that contain no data and should not outrank base row truth | living open spec | before promoting derived-view receipts or cross-engine view publication |
| `EXT-ICEBERG-PUFFIN` | keeps indexes/statistics/sketches as metadata blobs/sidecars with interpretation metadata instead of base contract meaning | living open spec | before promoting optimizer-stat, NDV/sketch, or sidecar registries |
| `EXT-ICEBERG-ROW-LINEAGE-2026` | keeps source row identifiers useful but scoped so lineage residue does not become universal identity truth | living open spec | before promoting row-lineage receipts beyond optional sidecars |
| `EXT-OPENLINEAGE-FACETS` | keeps metadata additions atomic, namespaced, and schema-url-backed instead of expanding one monolithic row contract | living open spec | before promoting metadata facets or sidecar extension points |
| `EXT-DATAHUB-OPEN-ASSERTIONS` | keeps assertion intent declarative and compilable without making one data-quality engine define Harbor meaning | living product spec | before promoting assertion-compiler targets or portable quality checks |
| `EXT-MATERIALIZE-TIMESTAMP-FRONTIERS-2026` | keeps logical read/write frontier claims visible so a queryable progress explanation does not counterfeit freshness or immutable history | living product docs | before promoting frontier/watermark witnesses or compaction-sensitive replay claims |
| `EXT-TIMELY-PROGRESS-FRONTIERS` | keeps progress frontiers as domain-scoped lower-bound/antichain-style evidence rather than one scalar currentness badge | stable project docs | before generalizing event-time watermarks into broader frontier vocabulary |
| `EXT-OTEL-SCHEMAS` | keeps schema-version transforms explicit and scoped instead of pretending mechanical conversion proves semantic equivalence | living open spec | before promoting schema-transform receipts |
| `EXT-DUCKDB-CUBE-PIVOT-2026` | reminds Harbor that CUBE/ROLLUP/PIVOT operators are useful query shapes, not evidence that base grain or semantic model has been settled | living project docs | before treating pivot/cube output as canonical lane shape |

| `EXT-KIMBALL-GRAIN` | keeps Harbor honest that grain must be declared before dimensions or facts | classic technique | before promoting any new durable value-bearing datacube family |
| `EXT-KIMBALL-LATE-FACT` | keeps late-arriving measurements and effective-time lookup pressure visible | classic technique | before promoting restatement or late-context nouns |
| `EXT-KIMBALL-LATE-DIMENSION` | keeps placeholder context and retroactive restatement pressure visible | classic technique | before promoting pending-context, completion, or correction nouns |
| `EXT-KIMBALL-DRILLING-ACROSS` | keeps unlike grains separate even when downstream users want one convenience report | classic technique | before flattening base crossing grain with receiver- or aftermath-shaped views |
| `EXT-ICEBERG-EVOLUTION` | keeps logical contract separate from physical partition/layout evolution and rewards additive changes | stable project docs | before freezing partition/layout-shaped semantics or destructive schema rewrites |
| `EXT-ICEBERG-ROW-LINEAGE-2026` | keeps Harbor open to explicit row-lineage receipts or sidecars without forcing one universal row-identity constitution too early | living open spec | before promoting row-lineage nouns or universal row IDs |
| `EXT-ICEBERG-BRANCHING` | pressures Harbor toward named experimental lanes, historical tags, and explicit promotion without forcing one product choice | stable project docs | before promoting publish-lane, audit-tag, or promotion-receipt nouns |
| `EXT-OPENLINEAGE-FACETS` | keeps optional metadata versioned, namespaced, and smaller than the core contract | stable open spec | before promoting facet-like annotations into the base row contract |
| `EXT-HUDI-TIMELINE` | keeps requested/completed change chronology visible instead of flattening every mutation into “latest wins” | stable project docs | before promoting change-history or restatement-feed nouns |
| `EXT-DELTA-CDF` | keeps row-level change feeds explicit and warns that non-additive schema changes complicate downstream interpretation | stable project docs | before promoting Harbor-owned change-history feeds or rename/drop semantics |
| `EXT-DELTA-SCHEMA-ENFORCEMENT` | keeps Harbor honest that incompatible writes should fail closed unless schema change is explicitly chosen | stable project docs | before treating schema drift or reinterpretation as harmless |
| `EXT-DBT-CONTRACTS` | keeps strong downstream guarantees on curated surfaces instead of every raw seam | living product docs | before freezing consumer-facing column promises |
| `EXT-DBT-SEMANTIC-MODELS-2026` | shows a thin entities/dimensions/measures spine that can wait until Harbor’s own nouns settle | living product docs | before promoting a universal semantic front door |
| `EXT-LAKEFS-ISOLATED-ENVIRONMENTS` | shows the value of zero-copy isolated rehearsal lanes and explicit merge/promotion | living product docs | before promising long-lived staging lanes, branch rehearsals, or promotion receipts |
| `EXT-LAKEFS-CATALOG-EXPORTS` | shows how branch/tag-specific metadata exports can preserve the same query shape while switching references under the hood | living product docs | before promoting branch-aware catalog exports or shadow publish surfaces |
| `EXT-CONFLUENT-SCHEMA-COMPAT` | keeps Harbor honest that a compatibility promise is a named policy, not a vibe, and that latest-only and transitive promises are different strengths | living product docs | before promising backward/additive/transitive safety for a published lane |
| `EXT-AVRO-SCHEMA-RESOLUTION` | keeps Harbor honest that aliases and defaults are useful reader-side bridges, but not proof that meaning or encoding obligations stayed the same | stable spec | before approving alias-backed rename or default-backed bridge claims on a published lane |
| `EXT-DBT-MODEL-VERSIONS` | keeps Harbor honest that mature-model overlap windows and deprecation dates are tools for intentional breaking change, while additive changes often stay in place | living product docs | before choosing between bridge window and successor lane/version |
| `EXT-K8S-FEATURE-GATES-2026` | teaches explicit maturity stages instead of vague experimental/stable folklore | living project docs | before naming a Harbor lane rehearsal, candidate, or published |
| `EXT-K8S-DEPRECATION-POLICY` | teaches that deprecation needs overlap, warnings, and minimum support windows and that stronger surfaces should not be retired in favor of weaker ones | living project docs | before retiring or superseding a published lane |
| `EXT-OTEL-SCHEMAS` | keeps schema-family/version pointers explicit and immutable once published | stable open spec | before freezing any immutable version-pointer behavior for Harbor lane contracts or facets |
| `EXT-PROTOBUF-DOS-DONTS` | pressures Harbor away from destructive type changes, identifier reuse, and requiredness creep on published surfaces | stable docs | before changing the meaning, requiredness, or retired-identifier posture of a published lane field |
| `EXT-PROTOBUF-1-1-1` | keeps Harbor biased toward small modular contract files instead of a giant universal schema surface | stable docs | before introducing one large multi-lane contract bundle |
| `EXT-OPENMETADATA-DATA-CONTRACTS-2026` | keeps Harbor honest that one “data contract” can carry separable categories such as schema, semantics, business assertions, and SLA for one asset | living product docs | before promising more than returned shape on a curated lane |
| `EXT-DATAHUB-ASSERTIONS` | keeps verification logic explicit and teaches that assertions are building blocks of contracts rather than substitutes for row meaning | living product docs | before promoting assertion-plane nouns or quality/freshness promises |
| `EXT-DATAHUB-OPEN-ASSERTIONS` | shows that assertion definitions can stay tool-agnostic and compile into engine-specific artifacts | living product docs | before treating dbt tests, warehouse checks, or monitor configs as canonical truth |
| `EXT-PACT-CONSUMER-DRIVEN` | keeps Harbor biased toward recording only the consumer-used slice instead of promising every possible behavior of a published lane | stable docs | before turning one consumer dependency into a giant universal contract |
| `EXT-DBT-TEST-SEVERITY` | keeps Harbor honest that warning and blocking thresholds are named choices instead of vibes | living product docs | before turning one assertion miss into a publish block or treating all non-green results alike |
| `EXT-GX-EXPECTATION-SEVERITY` | keeps Harbor honest that check outcomes can have graded severity and should stay smaller than semantic meaning | living product docs | before inventing Harbor-wide assertion posture or alert consequence nouns |
| `EXT-GX-VALIDATION-RUNS` | keeps Harbor honest that observed values and run details may be unavailable or thinner than the headline status | living product docs | before assuming every assertion result comes with exact measured evidence |
| `EXT-PROTOBUF-FIELD-PRESENCE` | keeps Harbor honest that explicit presence and implicit/default presence are different strengths of fact and that default-looking values may hide omission | stable docs | before promoting boolean/enum/default-valued fields into durable meaning without a presence witness |
| `EXT-ARROW-COLUMNAR-VALIDITY` | keeps Harbor honest that nullity may live on a separate channel from values and that nested validity can differ across levels | stable project docs | before flattening blank nested fields or materialized omissions into one generic absence story |
| `EXT-PARQUET-NULLS` | keeps Harbor honest that nullity can be encoded separately from data values and that no-value bytes are not the same as zero/default bytes | stable project docs | before treating storage-level absence as if it were explicit producer intent |
| `EXT-ICEBERG-CHANGELOG-VIEWS-2026` | keeps Harbor honest that ordered change history, net changes, update images, and carry-over rows are different promises | living project docs | before promoting Harbor-owned change-history lanes, net-diff exports, or replay cuts |
| `EXT-HUDI-INCREMENTAL-QUERIES-2026` | keeps Harbor honest that latest changed rows since a cut are different from full CDC history across that cut | living project docs | before promoting incremental changed-rows lanes as if they were complete history |
| `EXT-FLINK-TO-CHANGELOG-2026` | keeps Harbor honest that append-only downstream export can preserve explicit operation codes instead of flattening updates/deletes away | living project docs | before translating updating tables into append-only sinks or log exports |
| `EXT-DEBEZIUM-EVENT-FLATTENING-2026` | keeps Harbor honest that convenience flattening can discard before/delete semantics and thereby weaken history | living project docs | before flattening raw change events into after-only payloads or tombstone-light exports |
| `EXT-DBT-DATA-TEST-PROPERTY` | keeps Harbor honest that referential integrity and null intolerance are distinct promises and that null handling must be explicit | living product docs | before turning one blank-looking field into a universal test or semantic conclusion |
| `EXT-UCUM-SPEC-2024` | keeps Harbor honest that coded units have computable semantics and that semantic equivalence is stronger than literal string equality | stable open spec | before promoting canonical-unit or conversion nouns |
| `EXT-FHIR-QUANTITY-2026` | keeps Harbor honest that quantity kind and allowed units are contextual facts and that human display can stay smaller than coded system+code | living open spec | before publishing measured scalars with unit strings but no quantity-kind posture |
| `EXT-FHIR-MONEYQUANTITY-2026` | keeps Harbor honest that money quantities require explicit currency code/system posture and that display unit is not enough | living open spec | before publishing converted money or currency-bearing scalar lanes |
| `EXT-HL7-MONETARY-AMOUNT-2026` | keeps Harbor honest that currencies are not physical units because exchange rates vary | living open spec | before treating cross-currency conversion like ordinary unit normalization |
| `EXT-SIX-ISO4217-2026` | keeps Harbor honest that ISO 4217 currency codes, minor-unit posture, and maintenance history are living external facts | living maintenance source | before freezing money-lane code assumptions or converted-money contracts |
| `EXT-PROMETHEUS-METRIC-NAMING` | keeps Harbor honest that one measure should refer to a single quantity and a single unit and that ratios are often better than percentages | stable project docs | before mixing units or percent-scaled renders into one canonical lane |
| `EXT-OTEL-METRIC-UNITS-2026` | keeps Harbor honest that UCUM-coded units, unity-based utilization, and count annotations can stay explicit without forcing a giant semantic stack | living open spec | before publishing normalized ratio/utilization/count lanes |

| `EXT-DATAHUB-DATA-CONTRACT-2026` | keeps Harbor honest that a published contract can be a selected public subset of assertions on one physical asset rather than a vague promise about every possible behavior | living product docs | before flattening lane contract promise and current evidence posture into one badge |
| `EXT-DBT-FRESHNESS-2026` | keeps Harbor honest that freshness is a named calculation with explicit thresholds and that no calculation basis is different from a passing check | living product docs | before calling a live-head lane fresh without a witnessed age or threshold basis |
| `EXT-GX-FORMAT-RESULTS-2026` | keeps Harbor honest that result detail can be summary-only or richly evidenced and that coarse green status is weaker than explicit observed values | living product docs | before treating validation summary badges as if they guarantee detailed measured evidence |
| `EXT-FLINK-TIMELY-STREAM-PROCESSING` | keeps Harbor honest that occurrence/event time and processing/observation time are different truths with different determinism tradeoffs | living project docs | before flattening occurrence time and observation time into one cube field or freshness story |
| `EXT-DB2-BITEMPORAL-CREATING` | keeps Harbor honest that business-valid time and system-currentness are different axes and that overlap policy can be explicit | living vendor docs | before promoting validity windows, future-effective facts, or overlap assumptions |
| `EXT-DB2-QUERYING-TEMPORAL` | keeps Harbor honest that “as of” requires an explicit axis and cut/time basis rather than one ambient latest head | living vendor docs | before publishing any “as of” answer or replay surface without naming the axis |
| `EXT-SQLSERVER-TEMPORAL-USAGE` | keeps Harbor honest that transaction/system time may be the wrong substitute for business-valid time when data arrives late | living vendor docs | before treating ingest/currentness time as if it answered business-valid questions |
| `EXT-DBT-DIMENSIONS` | keeps Harbor honest that SCD validity windows need explicit `valid_from` / `valid_to` semantics and non-overlapping rows per natural key | living product docs | before joining facts against versioned dimensions or future-effective assignments without overlap discipline |

| `EXT-KIMBALL-ADDITIVITY` | keeps Harbor honest that measures have additive, semi-additive, and non-additive classes and that composite answers should often be rebuilt from additive parts | classic technique | before publishing reusable numeric lanes or derived ratios |
| `EXT-DBT-MEASURES-2026` | keeps Harbor honest that some dimensions are explicitly non-additive for a measure and should be named rather than guessed | living product docs | before declaring a measure safe to roll up across time or any other axis |
| `EXT-DBT-RATIO-METRICS-2026` | keeps Harbor honest that ratio answers should be built from numerator/denominator components and aligned common dimensions | living product docs | before publishing rates/percentages as durable Harbor numbers |
| `EXT-LOOKER-SYMMETRIC-AGGREGATES` | keeps Harbor honest that one-to-many joins can corrupt aggregates unless base-grain uniqueness and join relationships are explicit | living product docs | before publishing numbers from joined lanes with repeated child rows |
| `EXT-CUBE-MEASURE-ADDITIVITY-2026` | keeps Harbor honest that additivity changes which rollups and pre-aggregations are legal | living product docs | before promoting aggregate exports, semantic lanes, or pre-aggregated Harbor views |
| `EXT-DRUID-DATASKETCHES-2026` | keeps Harbor open to explicit mergeable approximate sidecars for hard distinct/set questions without counterfeiting exactness | living project docs | before promoting approximate distinct/set answers or optional sketch sidecars |
| `EXT-DRUID-THETA-SKETCHES-2026` | keeps Harbor honest that unique counts and set operations do not add up from ordinary aggregates and that mergeable sketches can preserve rollup rights with explicit approximation posture | living project docs | before publishing distinct-over-time or set-overlap numbers as durable Harbor lanes |
| `EXT-BIGQUERY-APPROX-AGG-2026` | keeps Harbor honest that approximate aggregates are explicitly uncertain and weaker than exact aggregation | living product docs | before publishing any estimate-backed lane as if it were exact |
| `EXT-BIGQUERY-HLL-2026` | keeps Harbor honest that retained sketches, partial aggregation, re-aggregation, and custom precision are a different promise from one-shot approximate functions | living product docs | before letting an extracted estimate masquerade as a preserved mergeable sketch |
| `EXT-DATASKETCHES-RESEARCH` | keeps Harbor honest that mergeable summaries make some non-additive questions additive-like without making them exact | living project docs | before promising exactness or rollup legality for sketch-backed values |
| `EXT-DATASKETCHES-HLL` | keeps Harbor honest that sketch error bounds/confidence posture belongs beside the estimate instead of disappearing behind an integer-like rendering | stable project docs | before publishing exactness-class or error-band nouns |
| `EXT-KIMBALL-CONFORMED-DIMENSIONS` | keeps Harbor honest that conformance requires shared names plus shared domain contents, not just similarly shaped columns | classic technique | before promoting any shared dimension or drill-across claim |
| `EXT-KIMBALL-BUS-ARCHITECTURE` | keeps Harbor honest that integration can be incremental when shared dimensions stay explicit | classic technique | before freezing an enterprise-wide conformance or entity-registry posture |
| `EXT-KIMBALL-SHRUNKEN-ROLLUP-DIMENSIONS` | keeps Harbor open to smaller shared slices for higher-grain lanes instead of forcing the full base dimension everywhere | classic technique | before promoting aggregate or higher-grain shared dimensions |
| `EXT-KIMBALL-BRIDGE-TABLES` | keeps Harbor honest that bridge mappings may need effective/expiration timestamps and an explicit snapshot moment | classic technique | before promoting many-to-many or time-varying conformance bridges |
| `EXT-DBT-JOIN-LOGIC-2026` | keeps Harbor honest that named entities and explicit allowed/disallowed join patterns can stay smaller than a universal canonical dimension regime | living product docs | before promoting Harbor-owned conformance lanes or semantic front doors |
| `EXT-LOOKER-JOIN-RELATIONSHIP-2025` | keeps Harbor honest that join relationship and key uniqueness must be explicit before shared dimensions can safely support aggregates | living product docs | before publishing metrics through shared or bridged dimensions |

| `EXT-PARQUET-LOGICAL-TYPES-2026` | keeps physical primitive storage separate from semantic interpretation and warns that annotations still need proof context | stable project docs | before treating decimal/time/unit-looking encodings as Harbor measurement truth |
| `EXT-BIGQUERY-GROUPINGSETS-2026` | shows cube/rollup/grouping-set outputs as useful query affordances that still need additivity and presence proof | living product docs | before treating a cube-shaped result as safe rollup authority |
| `EXT-SLOPOS-DATA-CONTRACT-GATES-2026` | keeps mutable-data rollback barriers and migration gates visible while Harbor explores restatements and derived views | included sibling archive | before promising rollback or reproducibility for data that may have migrated |
| `EXT-SLOPOS-OBSERVATION-EXPORT-POLICY-2026` | keeps export surfaces bounded, allowlisted, audited, and fail-closed | included sibling archive | before letting cube/export views become ambient dumps |
| `EXT-SLOPOS-FCELL-RECEIPT-NONAUTH-2026` | keeps request context, conflict keys, and adapter receipts non-authoritative and scoped | included sibling archive | before treating row-lineage, statistics, facets, or rate witnesses as authority |
| `EXT-DBT-SEMANTIC-LAYER-2026` | keeps centralized metric surfaces useful while reminding Harbor that generated questions need refusal boundaries and source-cut proof | living product docs | before treating a semantic front door as canonical row meaning |
| `EXT-CUBE-JOIN-RELATIONSHIPS-2026` | provides another compact join-cardinality vocabulary without requiring Harbor to choose the Cube product stack | living product docs | before promoting join-relationship notes or metric-export join safety |
| `EXT-DATAHUB-ASSERTION-ENTITY-2026` | keeps assertion identity, evaluation history, and contract-public subset posture visible | living product docs | before treating all internal assertions as one public contract promise |
| `EXT-ICEBERG-STATS-OPTIONAL-2026` | reinforces that statistics/sidecar artifacts can be informational and ignorable while the table remains readable | living open spec | before letting lineage/statistics sidecars upgrade contract tier or row truth |

## Pass LXXX additions

| ref_id | why it is load-bearing for Harbor now | stability posture | review trigger |
|---|---|---|---|
| `EXT-GX-UNEXPECTED-ROWS-2026` | keeps failed validation evidence inspectable without confusing failure rows with source truth or adopting a validation product | living product docs | before promoting negative-evidence receipts or failed-row evidence surfaces |
| `EXT-DBT-STORE-FAILURES-2026` | keeps stored test failures and warn/error posture visibly separate from row meaning and contract semantics | living product docs | before treating a failed/stored check as a publish block or consumer-facing fact |
| `EXT-OPENLINEAGE-RUN-CYCLE-2026` | keeps run completion, abort, and failure as scoped lifecycle evidence rather than durable data truth | living open spec | before promoting run/result/error residue into Harbor vocabulary |
| `EXT-OPENLINEAGE-ERROR-MESSAGE-FACET-2026` | keeps error detail as a namespaced run facet with producer/schema basis instead of one unbounded exception string | living open spec | before exposing operator-facing failure detail or consumer-facing refusal copy |
| `EXT-KAFKA-TOMBSTONE-RETENTION-2026` | keeps tombstone retention and compaction timing visible so negative evidence does not masquerade as timeless absence | living project docs | before promoting tombstone, withdrawal, purge, or replay-survivability vocabulary |
| `EXT-DEBEZIUM-TOMBSTONES-2026` | keeps delete event and tombstone marker separation visible for CDC-shaped history and compaction questions | living project docs | before promoting current-absence or delete-marker semantics |
| `EXT-FLINK-LATE-DATA-2026` | keeps late-arriving data and aggressive watermarking consequences visible for stale-frontier/refusal logic | living product docs | before treating stale progress as completeness or finality |

| `EXT-ICEBERG-SNAPSHOT-EXPIRATION-2026` | keeps snapshot expiration visibly tied to loss of time-travel/rollback availability rather than treating table-format support as permanent replay proof | living open docs | before promising exact historical recompute after maintenance |
| `EXT-DELTA-VACUUM-RETENTION-2026` | keeps file cleanup, transaction-log retention, and time-travel loss explicit so optimization does not counterfeit replay readiness | living open docs | before treating vacuumed/cleaned tables as still exact-answerable |
| `EXT-HUDI-CLEANING-2026` | keeps history retention framed as a storage-cost tradeoff with snapshot-isolation consequences | living open docs | before making old-version retention or cleanup invisible to consumers |
| `EXT-BIGQUERY-TIME-TRAVEL-2026` | keeps time-travel windows, fail-safe, direct-query limits, metadata limits, and recovery access visibly different | living product docs | before equating emergency recoverability with ordinary exact historical answers |
| `EXT-SNOWFLAKE-TIME-TRAVEL-RETENTION-2026` | keeps object retention settings, historical query windows, and retention changes explicit | living product docs | before claiming a historical answer outside the retained window |
| `EXT-FLINK-SAVEPOINTS-2026` | keeps state snapshots scoped to job/operator identity and restoration rules instead of treating streaming state as universal datacube replay | living project docs | before promoting savepoint-backed replay claims |

## Pass LXXXII additions

| ref_id | why it is load-bearing for Harbor now | stability posture | review trigger |
|---|---|---|---|
| `EXT-W3C-VC-DATA-MODEL-2-0` | keeps machine-verifiable and privacy-respecting presentation separate from raw evidence disclosure | stable W3C recommendation | before promoting verifier packets, proof presentations, or selective-disclosure-shaped evidence |
| `EXT-W3C-BBS-DERIVED-PROOFS-2026` | demonstrates base-proof versus derived-proof separation and selected-statement disclosure without forcing Harbor into one cryptosystem | living W3C specification | before treating redacted/derived proof packets as exact replay evidence |
| `EXT-OTEL-SENSITIVE-DATA-2026` | reminds Harbor to prefer non-collection/minimization before redaction processors and output filters | living open docs | before broadening replay payload capture or proof export |
| `EXT-NIST-SP800-122-PII` | keeps PII confidentiality, access, use, and disclosure impact contextual rather than one global safe/unsafe flag | stable NIST publication | before exposing row-level replay evidence or support bundles to non-operators |
| `EXT-NIST-SP800-188-DEID` | keeps de-identification as governance and disclosure-risk analysis rather than simple masking | stable NIST publication | before calling redacted proof rows safe for consumers |
| `EXT-IN-TOTO-ATTESTATION-2026` | keeps subject/material/predicate discipline available for verifier packets without turning signed claims into approval verdicts | living open spec | before packaging Harbor proof packets or proof bundles |
| `EXT-SIGSTORE-REKOR-2026` | keeps transparency-log inclusion and integrity verification visibly separate from semantic approval or policy satisfaction | living project docs | before anchoring frozen answers, proof packets, or disclosure transcripts in logs |
| `EXT-OPA-DECISION-LOGS-2026` | keeps policy decision evidence, bundle metadata, and masking hooks explicit for auditor/debug review | living project docs | before promoting policy/verifier decision transcripts |
| `EXT-OPA-SIGNED-BUNDLES-2026` | keeps signed policy bundle integrity and activation behavior visible for source-lock drift | living project docs | before using current policy engines to verify old answers |
| `EXT-CEDAR-VALIDATION-2026` | keeps policy/schema validation separate from runtime answer truth and reminds Harbor that policies need application context | living project docs | before promoting verifier-ticket policy language |
| `EXT-BISCUIT-SPEC-2026` | keeps offline attenuation and decentralized verification as a stealable shape without turning verifier tickets into bearer export grants | living project docs | before adopting ticket-like delegation patterns |
| `EXT-SLOPOS-PROOF-BUNDLE-ROLE-2026` | keeps proof-bundle role labels non-authoritative and smaller than verifier policy, bundle format, or approval state | included sibling archive | before turning frozen-answer proof packets into a portable verdict plane |
| `EXT-SLOPOS-REPLAY-BUNDLE-SCHEMA-2026` | keeps replay bundles sensitive, manifest/digest-bound, and export-gated | included sibling archive | before exposing replay-evidence survivor sets to consumers or auditors |
| `EXT-SLOPOS-OBSERVATION-EXPORT-REDUCTION-2026` | keeps observation export allowlists, bounds, redaction tiers, and fail-closed behavior explicit | included sibling archive | before widening cube/export surfaces or proof summaries |
| `EXT-SLOPOS-CRYPTO-AUDIT-REDACTION-2026` | keeps digest-first audit evidence redaction-safe without becoming a plaintext export channel | included sibling archive | before designing verifier-visible evidence transcripts |

## Pass LXXXIII additions

| ref_id | why it is load-bearing for Harbor now | stability posture | review trigger |
|---|---|---|---|
| `EXT-NIST-SP800-226-DP-2025` | keeps differential privacy framed as quantified privacy loss with practical hazards rather than a label for any noisy aggregate | stable NIST publication | before making any DP-style claim or disclosure-budget note |
| `EXT-US-CENSUS-DAS-DP-2020` | keeps reconstruction and disclosure-avoidance pressure visible for public statistics | public agency materials | before assuming published aggregates cannot reconstruct hidden rows |
| `EXT-ABS-AGGREGATE-DATA-CONFIDENTIALITY` | keeps low contributor count, magnitude dominance, and multiple-table differencing hazards explicit | public agency guidance | before releasing fine-grained aggregate cells or magnitude tables |
| `EXT-ONS-CENSUS2021-SDC` | keeps cell-key perturbation, sparse-output rules, and differencing protection visible as release choices with utility effects | public agency methodology | before treating noise or sparse-table blocking as invisible formatting |
| `EXT-US-CENSUS-FSRDC-DA-HANDBOOK-2024` | keeps collapse, suppression marking, and complementary suppression discipline visible | public agency handbook | before publishing one suppressed cell while leaving enough margins to infer it |
| `EXT-EUROSTAT-SDC-CENSUS-2024` | keeps SDC method tradeoffs across simplicity, perturbation, consistency, additivity, and large differences visible | public statistical guidance | before choosing a suppression/noise/rounding method or treating all methods as equivalent |
| `EXT-OPENDP-DOCS-2026` | keeps privacy-aware computations and composition as a stealable implementation shape without choosing a tool stack | living open project docs | before promoting a disclosure-budget engine or DP computation substrate |
| `EXT-SLOPOS-OBSERVATION-EXPORT-AGGREGATE-2026` | keeps aggregate/metric export bounded, redacted, policy-killable, and non-authoritative | included sibling archive | before letting public cube exports become ambient query services |
| `EXT-SLOPOS-BUDGET-LEASE-2026` | keeps budget-like notes explicit and non-ambient without confusing disclosure budgets with authority tokens | included sibling archive | before promoting privacy/disclosure-budget vocabulary |


## Pass LXXXIV load-bearing additions

- **EXT-W3C-DWBP-2017** — W3C Data on the Web Best Practices.
  - key: treats metadata, licensing, provenance, quality, versioning, identifiers, and feedback as publication/reuse concerns rather than decorative extras.
  - harbor_use: public aggregate copies must carry enough context to remain interpretable after export.

- **EXT-W3C-CSVW-METADATA-2015** — W3C Metadata Vocabulary for Tabular Data.
  - key: tabular data on the web needs metadata for validation, conversion, display, and search at group, table, and cell levels.
  - harbor_use: suppression, perturbation, structural-zero, exactness, and restatement labels may need table/cell-level binding or a sidecar.

- **EXT-W3C-DCAT3-2024** — W3C Data Catalog Vocabulary version 3.
  - key: catalogs, datasets, data services, and distributions are separate publication concepts.
  - harbor_use: dataset-level claims do not prove that every distribution/mirror preserved labels and basis.

- **EXT-FRICTIONLESS-DATA-PACKAGE-2024** — Frictionless Data Package.
  - key: a simple descriptor plus resources can package dataset structure without requiring a giant platform.
  - harbor_use: steal the descriptor/resource shape for release receipts while deferring the actual package format.

- **EXT-BAGIT-RFC8493** — BagIt file packaging format.
  - key: payload files and metadata tag files can be transferred with manifests and checksums while remaining payload-semantics-agnostic.
  - harbor_use: bind public payloads and label sidecars together so label stripping is detectable.

- **EXT-SPDX-PACKAGE-VERIFICATION-2026** — SPDX package verification code.
  - key: recipients can determine whether package files match the analyzed package contents.
  - harbor_use: proof-of-copy should be digest/manifest based without becoming raw replay evidence.

- **EXT-CREATIVE-COMMONS-IRREVOCABLE-2026** — Creative Commons irrevocability guidance.
  - key: CC licenses are not revocable once granted except for breach, and recipients may rely on granted rights while rights last.
  - harbor_use: public-copy withdrawal must not counterfeit remote recall; supersede/deprecate/warn instead.

- **EXT-RFC9111-HTTP-CACHING** — HTTP caching.
  - key: cached responses have freshness, staleness, and revalidation semantics.
  - harbor_use: mirror/copy status should distinguish fresh, stale, superseded, withdrawn, and unknown rather than one current boolean.

- **EXT-DATACITE-VERSIONING-2026** — DataCite versioning and related identifiers.
  - key: version succession can be expressed with relations such as `IsNewVersionOf` and `IsPreviousVersionOf`.
  - harbor_use: public aggregate restatements should link old and new artifacts instead of overwriting history.

- **EXT-W3C-PROV-DM-2013** — W3C PROV-DM.
  - key: provenance relates entities, activities, and agents involved in production and use.
  - harbor_use: release/copy/mirror/restatement can be represented as activities without making provenance a verdict plane.

- **EXT-W3C-ODRL-2018** — W3C ODRL Information Model.
  - key: permissions, prohibitions, duties, constraints, assets, and parties can be represented in policy expressions.
  - harbor_use: notice and reuse policy can travel with a public copy, but policy expression is not privacy safety or remote control.
| `EXT-HYPOTHESIS-SETTINGS-2026` | keeps Harbor honest that generated examples need replay/settings discipline and shrinking, but that a framework dependency is optional until repeated pressure justifies it | living project docs | before turning deterministic generated mutants into a property-test framework requirement |
| `EXT-STRYKER-MUTANT-METRICS-2026` | keeps Harbor honest that killed/survived/equivalent mutant states are diagnostics rather than proof of correctness | living project docs | before using mutation counts as a quality badge or conformance score |
| `EXT-AFLPLUSPLUS-CORPUS-2026` | keeps Harbor honest that interesting generated cases can seed future tests while still requiring corpus minimization and reproducibility discipline | living project docs | before promoting generated Harbor mutants into a fuzzing corpus |
| `EXT-COVERAGEPY-BRANCH-2026` | keeps Harbor honest that branch/transition coverage is an observation about exercised paths, not semantic completeness | living project docs | before treating a coverage report as a Harbor truth or trust score |
| `EXT-PIT-MUTATION-BASICS-2026` | keeps Harbor honest that survived mutants require triage and some mutants can be equivalent rather than evidence of a checker gap | living project docs | before promoting survived-mutant counts into checker changes or quality scores |
| `EXT-AFLPLUSPLUS-FUZZING-IN-DEPTH-2026` | keeps Harbor honest that generated corpora should be minimized to distinct pressure rather than bloated duplicates | living project docs | before pruning or expanding the mutation corpus |
| `EXT-SOURCE-DATE-EPOCH-2026` | keeps release timestamps explicit rather than ambient build-clock facts | stable reproducible-builds documentation | before claiming deterministic or reproducible package behavior |
| `EXT-SLSA-PROVENANCE-1-2` | pressures Harbor to distinguish build definition, run details, builder, parameters, dependencies, and subject | approved SLSA spec | before importing any release provenance or package receipt noun |
| `EXT-IN-TOTO-ATTESTATION-1-2` | reminds Harbor that subject, predicate, statement, envelope, and bundle are distinct layers | living spec, versioned releases | before treating internal fixture evidence as a signed attestation |
| `EXT-GITHUB-ARTIFACT-ATTESTATIONS-2026` | warns that attestation must be verified and policy-evaluated and is not artifact-security proof | current vendor documentation | before any package receipt or CI badge wording is exposed |

## Pass CIII additions

| ref_id | why it is load-bearing for Harbor now | stability posture | review trigger |
|---|---|---|---|
| `EXT-W3C-PROV-DM-2013` | keeps derivation and usage scoped rather than automatic source equivalence | stable W3C recommendation | before promoting local derivation vocabulary |
| `EXT-W3C-WEB-ANNOTATION-2017` | keeps annotation body/target/provenance separable | stable W3C recommendation | before treating annotations as source status or authority |
| `EXT-ROCRATE-1-2-2025` | pressures local derivative context packaging without truth overclaim | current recommendation as consulted | before exporting derivative metadata bundles |
| `EXT-BAGIT-RFC8493` | preserves fixity/manifest discipline for moved or re-exported material | stable RFC | before treating re-exported derivatives as source copies |
| `EXT-OCI-IMAGE-LAYOUT-2026` | separates content-addressable material from location-addressable references and transports | living OCI spec | before treating sync paths, refs, or archive names as identity |

## Pass CIV additions

| ref_id | why it is load-bearing for Harbor now | stability posture | review trigger |
|---|---|---|---|
| `EXT-W3C-PROV-DM-2013` | keeps correction, revision, derivation, activity, and agent roles distinct | stable W3C recommendation | before treating repaired derivatives as original source or global truth |
| `EXT-W3C-WEB-ANNOTATION-2017` | keeps repair notes bound to body/target/provenance instead of status authority | stable W3C recommendation | before accepting annotation-carried correction or repair notices |
| `EXT-BAGIT-RFC8493` | keeps transfer/fixity checks distinct from payload semantics | stable RFC | before treating a moved or re-exported derivative as semantically repaired |
| `EXT-OCI-REFERRERS-2024` | keeps subject/referrer links distinct from trust, reachability, and repair | stable OCI 1.1 pressure as consulted | before using parent/child maps or re-export supersession receipts |
| `EXT-W3C-LDN-2017` | pressures notification delivery while preserving sender/receiver/consumer separation | stable W3C recommendation | before treating a notice as read or applied |
| `EXT-W3C-ACTIVITYPUB-2018` | pressures federated delivery/update flows without proving recipient application | stable W3C recommendation | before treating broadcast/delivery success as all derivatives reached |
| `EXT-RFC9457-PROBLEM-DETAILS` | encourages machine-readable failure reasons without making them closure | stable RFC | before turning repair refusal reasons into workflow or compliance status |
| `EXT-NIST-LOG-RETENTION` | keeps log retention framed as archiving records for operational review rather than proof of current truth | stable glossary / NIST source | before treating retained receipts as current repair |
| `EXT-PREMIS-LOC-2026` | pressures Harbor to keep preservation metadata, events, agents, rights, and object identity distinct from current validity | living preservation metadata source | before promoting retained repair evidence into preservation or legal-hold vocabulary |

| `EXT-W3C-PROV-DM-2013` | keeps revisions and derivations separate from source identity and current validity | stable W3C recommendation | before turning repaired derivatives into the original source |
| `EXT-IETF-MEMENTO-7089` | pressures Harbor to preserve old representations with datetime context rather than treat them as current | stable RFC | before using retained repair states as current public copy |
| `EXT-NISO-RESOURCESYNC-2017` | shows modular change/synchronization capabilities for evolving resources and subsets | stable synchronization specification | before treating change delivery as derivative repair |
| `EXT-OCI-IMAGE-LAYOUT-2026` | separates content-addressable blobs from location-addressable refs across transports | living OCI source | before treating latest refs or names as epoch material identity |
| `EXT-SPDX-EXTERNAL-DOCREF-2026` | keeps external relationships tied to the external document context | stable specification material as consulted | before importing companion cube identifiers or relationship claims |
| `EXT-RO-CRATE-CONTEXTUAL-ENTITIES-2026` | separates data entities from contextual entities | stable specification material as consulted | before treating companion context as Harbor data/status |


## Pass CVIII sources

| Source | Harbor pressure | Stability note | Use before |
|---|---|---|---|
| `EXT-W3C-PROV-DM-2013` / `EXT-W3C-PROV-INVALIDATION-2013` | treats later revision/invalidation as provenance facts without erasing earlier observations | stable W3C recommendations/namespaces | promoting revocation overlays or history-residue vocabulary |
| `EXT-TUF-SPEC-LATEST-2026` | keeps rollback, freeze, version, and expiration checks explicit | living spec | treating newer companion notices or expired fragments as freshness/currentness |
| `EXT-SPDX-EXTERNAL-DOCREF-2026` | keeps external document references tied to parent context | stable specification material as consulted | importing or revoking companion fragments |
| `EXT-IN-TOTO-SPEC-VERIFY-2026` / `EXT-SLSA-VERIFYING-ARTIFACTS-2026` | keeps verification expectation-bound rather than evidence-existence-bound | living project specifications | treating foreign correction notices as local authority |

## Pass CIX sources

| Source | Harbor pressure | Stability note | Use before |
|---|---|---|---|
| `EXT-W3C-LDN-2017` | notification delivery/retrieval does not prove read, application, or repair | stable W3C Recommendation | treating overlay delivery as consumer repair |
| `EXT-W3C-WEB-ANNOTATION-2017` | body, target, state, and provenance remain separable | stable W3C Recommendation | letting overlay annotations rewrite target authority |
| `EXT-RFC9457-PROBLEM-DETAILS` | structured failure reasons do not equal workflow closure | stable RFC | promoting refusal reasons into compliance/status systems |
| `EXT-RESOURCESYNC-FRAMEWORK-2017` | change lists announce changes without proving destination synchronization | stable specification family | claiming all mirrors/public copies updated |
| `EXT-MEMENTO-RFC7089` | prior and current representations remain time-scoped | stable RFC | erasing prior import history after overlay propagation |

## Pass CX source register additions

- `EXT-WCAG22-2024`: used as accessibility-display pressure only; Harbor does not claim WCAG conformance.
- `EXT-WCAG22-STATUS-MESSAGES`: used to separate visible/programmatic status exposure from comprehension, read, or repair proof.
- `EXT-WCAG22-LABELS-INSTRUCTIONS`: used to require labeled action affordances without treating labels as consent or reliance.
- `EXT-W3C-WEB-ANNOTATION-2017`: reused for body/target/provenance separation in explanation cards.
- `EXT-RFC9457-PROBLEM-DETAILS`: reused for reason-code/human-copy pairing without workflow closure.

## Pass CXI source register additions

- `EXT-W3C-PRIVACY-PRINCIPLES-2025`: used as minimization and user-agency pressure only; Harbor does not infer comprehension, consent, or reliance from a response event.
- `EXT-KANTARA-CONSENT-RECEIPT-1-1`: used to keep acknowledgement smaller than a scoped consent transaction; Harbor does not adopt a consent receipt schema.
- `EXT-WCAG22-LABELS-INSTRUCTIONS`: reused to require clear affordance labels without treating clarity as consent or reliance.
- `EXT-WCAG22-STATUS-MESSAGES`: reused to separate status exposure/focus from read, comprehension, or repair proof.
- `EXT-RFC9457-PROBLEM-DETAILS`: reused for machine-routable reason/retry pressure without workflow or repair closure.
