# SlopOS / companions evaluation — pass XLV

This pass re-checks Harbor against SlopOS and the sibling cubes after adding a cross-device interlock specimen, and again chooses one narrow crossing seam over any early family bloom.

## What the current cubes still teach
- **SlopOS** remains the strongest restraint mechanism. Its device-authorization import boundary already says `device_code`, `user_code`, verification URIs, expiry/interval semantics, and token acquisition stay provider-local continuation mechanics rather than a portable cross-device auth broker or durable login-state substrate. That lines up cleanly with Harbor treating device split, pairing cue, and same-device veto as local crossing residue, not as a new connected-account plane.
- **SlopOS** also keeps the key design-phase lesson alive: request packaging, response packaging, and exact local validation can stay real value even when they never become public portable nouns. Harbor can do the same with pairing cues and same-device vetoes.
- **Ward** keeps contributing the right operational instinct: a legitimate-looking approval on another device can still be too weak to spend through safely if the surrounding context is wrong. A copied QR code, borrowed user code, or unexpected same-device collapse should bottom out honestly rather than counterfeit success.
- **Helm** keeps reminding Harbor that human-facing chrome can help people choose without outranking exact basis. A displayed code, label, or push prompt can be useful and still stay below exact local adoption.
- **Foundry** keeps the foreign-ground lesson alive: when completion happens on another device or another runtime, the membrane should preserve that foreignness rather than flattening it into “local success.”

## Harbor consequence
Harbor should keep this move modest:
- add one specimen around **device-split witness**, **pairing cue**, and **same-device veto**;
- keep cross-device hints, codes, messages, and notification callbacks visibly smaller than durable issuer/account/session/adoption truth;
- collect **continuation-bound key** and **notification stub** as inspiration only;
- and leave any future registry of device classes, proximity scores, or push-notification schemas outside Harbor for now.

## Still-not-yet decisions
- Whether **device-split witness** deserves its own Harbor family, or should remain only an annotation on existing detour/aftermath surfaces.
- Whether **pairing cue** belongs in Harbor at all, or should remain only a review/interlock annotation without a durable object family.
- Whether **same-device veto** belongs in Harbor, or should stay a smaller route/admission consequence with only receipt-level visibility.
