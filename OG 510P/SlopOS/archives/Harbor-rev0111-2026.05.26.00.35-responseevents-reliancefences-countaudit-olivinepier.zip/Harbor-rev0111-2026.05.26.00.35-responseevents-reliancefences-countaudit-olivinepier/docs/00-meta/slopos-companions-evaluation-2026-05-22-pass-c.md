# SlopOS companion evaluation — 2026-05-22 pass C

## Harbor/SlopOS boundary

SlopOS can emit precise portal-network and append/checkpoint evidence.  Harbor now has several checkers that inspect such evidence, but F095 adds the missing intermediate discipline: evidence about the checker observation itself.

This matters at the Harbor/SlopOS boundary because a future SlopOS import should not accept “Harbor checker passed” as an unscoped fact.  It should receive:

```text
checker source digest
harness source digest
fixture/checker pairing
self-test receipt
guard-state receipt
reviewer override packet, if any
non-promises
```

## Borrowed lesson from SlopOS

SlopOS already treats accepted prefixes, discarded suffixes, denied records, duplicate suppression, checkpoints, and resumes as separate facts.  Harbor applies the same separation to verification: source digest, fixture digest, checker run, self-test receipt, and reviewer override are separate facts.

## Do not import into SlopOS yet

F095 is not a SlopOS checker-result interchange format.  It should not be wired into portal.net.request, launch/result status, append histories, or replay bundles as a durable profile.

## Candidate future handoff

A future cross-cube handoff might carry:

```text
harbor_checker_observation_id
subject_bundle_digest
checker_source_digest
fixture_digest
selftest_digest
guard_state_digest
reviewer_override_digest
scope and expiry
```

That handoff should wait until repeated Harbor specimens show a stable need.

## Next pressure

F096 should look at package/release evidence.  SlopOS is already strong at append/corpus receipts; Harbor now needs to avoid overclaiming deterministic packaging, archive index freshness, and bootstrap trust.
