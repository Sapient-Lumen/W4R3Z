# Research synthesis — pass XCII, external decision return and adoption hygiene

**Revision:** `rev0092`  
**Date:** 2026-05-16  
**Question:** How should Harbor receive and use outside source-owner, auditor, regulator-facing, transparency, and appeal findings without letting external decision return become automatic truth, compliance, public proof, or memory-hole correction?

## Result

Harbor should treat outside decisions as **imported finding packets**, not as adopted truth.

The useful move is to record seven small packets:

1. an external finding return receipt;
2. a finding scope normalization note;
3. an authority conflict map;
4. a local finding adoption note;
5. an external correction instruction receipt;
6. a sealed finding expiry note;
7. an appeal outcome / public-copy update note.

Together they let Harbor say: "the source owner partially accepted this, the auditor disagreed on this scoped field, the regulator-facing reviewer returned a sealed-only determination, Harbor adopted only this public wording change, the appeal changed the cooldown banner but not history, and the sealed finding expires on this date." They do not prove repair, non-use, compliance, legal truth, public disclosure safety, source-owner fault, or current truth beyond their named scope.

## External lessons folded in

- CSAF 2.1 is useful because it structures creation, update, and exchange of advisories around product/vulnerability impact and remediation among interested parties. Harbor should borrow scoped status/remediation discipline, not a vulnerability-advisory constitution.
- OpenVEX is useful because status is a relationship between a vulnerability and a product: affected, not affected, fixed, or under investigation in common VEX practice. Harbor should borrow subject-bound status humility, not scanner suppression or latest-wins feeds.
- SCITT is useful because it separates signed statements, receipts, transparency services, registration policies, relying parties, and auditors; it also allows multiple transparency services and divergent opinions. Harbor should borrow receipt/accountability discipline while keeping local adoption separate.
- W3C PROV is useful because revision is a kind of derivation and PROV lets applications choose relation granularity. Harbor should borrow revision/derivation language for public-copy updates without pretending every public update changes the underlying data.
- DataCite related identifiers are useful because version, derivation, review, obsolescence, translation, and metadata relations are enumerated rather than implicit. Harbor should steal relation clarity for public-copy update notes and appeal outcomes.
- C2PA update manifests are useful because they add assertions without changing content, and because manifest/ingredient/redaction handling keeps current assertion packages distinct from the asset. Harbor should borrow update-without-content-change discipline for public wording changes and generated explanations, not an image/media provenance stack.
- SlopOS's VEX/SBOM/attestation posture is especially relevant: imported advisory, status, collateral, verifier result, producer, version, and supersession material is exact evidence under local appraisal, not native authority.

## SlopOS-specific interpretation

SlopOS remains design-phase, so Harbor should avoid a native decision-return authority model.

The SlopOS lessons are:

- digest-bound evidence remains smaller than authority; a finding must name exact subjects, cuts, digests, labels, and windows;
- export is policy-killable and no-secrets-in-band, so sealed findings must be public-summary-bound and refusal-capable;
- verifier-local currentness remains local, so an auditor or source-owner result does not become ambient current truth;
- VEX/SBOM document version and producer metadata are evidence, not latest-wins or owner-precedence rules;
- status-list and collateral checks are provider/verifier local, so Harbor should not import them as universal validity or approval.

## New watchlist handles

- `external_finding_return_receipt`
- `finding_scope_normalization_note`
- `authority_conflict_map`
- `finding_adoption_note`
- `external_correction_instruction_receipt`
- `sealed_finding_expiry_note`
- `appeal_outcome_receipt`
- `public_copy_update_after_review_note`
- `safe_outside_review_public_copy`

## Practical design rule

Prefer decision-return language that preserves boundaries:

- `finding received`, not `truth imported`;
- `source owner partially accepted`, not `source owner repaired`;
- `auditor found unsupported`, not `auditor proved misuse`;
- `regulator-facing sealed review returned`, not `compliance decided`;
- `recommended correction`, not `mandated correction`;
- `mandated within scope`, not `universally binding`;
- `adopted locally for wording`, not `adopted as system truth`;
- `appeal partially sustained`, not `history rewritten`;
- `finding expired for current reliance`, not `finding false`.

## Followthrough result

`F087` is now complete as a pressure test. The next seam is post-decision implementation and monitoring: mandated/recommended corrections, deadlines, partial implementation, recheck receipts, reopened appeals, jurisdiction/audience splits, stale public surfaces after adoption, and implementation evidence that must remain smaller than compliance or universal repair.
