
# SlopOS / companions evaluation — pass LXXVII

This pass asks what Harbor should do after the option-reservations watchlist: not which database-like substrate to select, but which proof discipline keeps the design-phase SlopOS datacube from congealing too early.

## SlopOS lessons used directly
- **Code rollback is not data rollback.** SlopOS's `rfcs/0097-data-contracts-and-migration-gates.md` is the most important local warning for the datacube: a breaking data write must carry a migration gate, rollback barrier, and compatible snapshot story. Harbor's derived views, rate-restated money comparisons, and future semantic exports need the same habit: do not advertise rollback or reproducibility unless the underlying mutable data cut still supports it.

- **Export policy is a choke point, not ambient permission.** SlopOS's `rfcs/0076-observation-export-policy.md` makes export surfaces bounded, allowlisted, auditable, and fail-closed. Harbor should borrow that shape for observation-shaped datacube exports: a cube/export receipt must name what leaves the archive, what class of evidence it carries, and what it refuses to include.

- **Receipts are non-authoritative until a separate rule says otherwise.** SlopOS's foreign-cell adapter and commutativity documents keep request context, conflict keys, and adapter receipts as correlation/order/audit residue rather than authority. Harbor should apply the same rule to row-lineage sidecars, statistics blobs, facets, and rate witnesses: they explain; they do not authorize row meaning.

- **Ordering and identity are scoped.** The foreign-cell commutativity contract's scoped conflict keys and explicit ordering witnesses are a strong model for datacube history. A row-lineage receipt or replay cut must say its scope instead of implying global row identity or universal ordering.

## Companion-cube pressure
- **Foundry:** semantic spines and serving lanes suggest that query/export shapes need basis receipts and serving-lane humility. Harbor should not let a semantic export become native truth.
- **Schell:** activation receipts and supersession discipline suggest that any proof packet should identify the version it supersedes and the bridge/compatibility window it leaves behind.
- **ViewFS:** materialization boundaries reinforce the difference between a view lens, a copied artifact, and an owned object. Harbor should require a derived-artifact proof before any view/pivot/table copy is treated as durable.
- **Helm:** door packs and review queues reinforce display-basis honesty. A percent-looking dashboard cell must carry storage and display proof; a converted amount must show its rate basis.
- **Ward:** tier witnesses and resolution bindings reinforce conformance humility. Shared-looking IDs and dimensions need exact tier/mapping proof before cross-lane reuse.
- **Steward:** aftermath receipts reinforce late-restatement hygiene. A late FX rate, late dimension repair, or corrected historical value needs followthrough instead of silent cleanup.

## Harbor consequence
This pass adds one new process surface and one harder specimen:
- `docs/00-meta/datacube-proof-obligations.md` becomes the promotion gate for datacube nouns and option reservations.
- `docs/30-architecture/specimen-flow-72-measurement-proof-cut-rate-restatement-display-honesty.md` completes the measurement-semantics followthrough while keeping conversion and FX governance unchosen.

## What stays open
- Whether proof obligations later become machine-readable cards.
- Whether SlopOS's eventual datacube wants table-format, semantic-layer, stream-processing, catalog, or query-engine integration.
- Whether Harbor owns only proof receipts or also owns any future exchange/export schema.
- Whether sibling-cube ideas remain citations or become shared vocabulary.

For now, the companion lesson is clear: **use proof obligations as the anti-counterfeit membrane, not a chosen substrate.**
