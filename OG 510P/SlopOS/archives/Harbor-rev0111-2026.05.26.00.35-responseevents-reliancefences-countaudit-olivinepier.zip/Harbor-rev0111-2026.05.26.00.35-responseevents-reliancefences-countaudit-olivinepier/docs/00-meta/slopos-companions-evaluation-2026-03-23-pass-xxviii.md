# SlopOS / companions evaluation — pass XXVIII

This pass re-checks Harbor against the uploaded cube ecology and keeps the architecture embryonic.

## What the current cubes still teach
- **SlopOS** still pushes the right anti-regrowth rule hardest. Its auth-exact-match import boundary, browser-session export boundary, login-state export boundary, and account-binding export boundary all keep scoped identifiers and provider-local truths from silently widening into portable platform facts. That strongly supports a Harbor move that records scoped matching aids without inventing a portable subject/session/account plane.
- **Ward** is again the closest sibling. Its subject-drift work already admits that later event subjects may map imperfectly to local identity state. Harbor should steal the matching humility but keep the exchange-side scope smaller: match aids are useful residue, not durable trust verdicts.
- **ViewFS** keeps exact basis cards, live handles, and durable refs visibly separate. That is a very good analogy for Harbor: a correlation handle should look more like basis than like a live authority object.
- **Steward** still separates discovery truth, lease chips, and presence adverts from durable readiness. Harbor should borrow that posture for identifier matching: “this is the handle we tried” is smaller than “this is the settled account/session.”
- **Helm** continues to reward inspectable front-door residue instead of magical success state. Harbor can use that to justify `match witness` and `mismatch quarantine` as product-facing residue instead of background folklore.

## Harbor consequence
Harbor should keep scoped-matching nouns provisional.
The right near-term move is small:
- add one specimen around `correlation handle`, `match witness`, `mismatch quarantine`, and `scope honesty`;
- keep durable subject/account/session truth in neighboring/provider-owned lanes;
- and keep identifier shape, local basis, and mismatch posture visibly separate.

## Still-not-yet decisions
- Whether `correlation handle` deserves its own first-class card or remains a typed annotation on attenuation, logout, and continuity residue.
- Whether `match witness` is distinct from broader aftermath receipts or just one precise receipt flavor.
- Whether Harbor ever needs a first-class identifier-family map at all, or whether scoped match honesty should remain a small anti-regrowth rule instead of a new registry.
