# Research synthesis — pass XLVII

This pass keeps Harbor narrow and learns five compatible things at once: **some signed envelopes name the authorization server while others must name the exact endpoint URI in use, issuer sameness is not enough when endpoint aliases drift, per-request target proofs deserve their own smaller residue, resource echoes can clarify issuance-time targeting without becoming grant truth, and Harbor should preserve exact-target hygiene without freezing a portable endpoint registry too early.**

## Outside lessons
1. **Client-assertion audience is a real safety seam.**  
   RFC 7523 requires a JWT assertion to contain an `aud` value identifying the authorization server, notes that the token endpoint URL MAY be used for that audience, and requires simple string comparison against configured values. The March 2026 OAuth security-topics update goes further for client assertions and says clients MUST use the exact endpoint URI to which the assertion is sent as the sole audience value. Harbor should preserve an **audience-basis witness** instead of flattening “who this assertion was for” into issuer-brand folklore.

2. **Some envelopes name the server while others name the endpoint.**  
   RFC 9101 says a signed JAR Request Object `aud` should be the authorization server issuer, while client assertions and DPoP proofs are tied to the exact endpoint URI that actually receives them. Harbor should keep those bases separate instead of pretending there is one universal audience rule.

3. **Alias-friendly endpoint thinking has already burned OAuth.**  
   RFC 9700 warns that storing only the authorization-server URL is not enough to stop mix-up attacks because an attacker can combine a legitimate authorization endpoint with a token endpoint under attacker control. Harbor should therefore preserve an **alias veto** path where same-provider or same-issuer polish still fails because the exact target basis is wrong.

4. **Request-target proofs are exact and still smaller than adoption.**  
   RFC 9449 makes DPoP validate the exact HTTP target URI (`htu`) of the current request, ignoring query and fragment parts and allowing normalization before comparison. Harbor should steal an **endpoint-target card** idea: exact target residue is valuable, but it is still smaller than durable grant, account, or adoption truth.

5. **Issued-resource echoes are clever but still smaller than truth.**  
   RFC 8707 lets a client ask for a specific protected resource, and the current resource-response draft says the token response can return the actual `resource` value(s) that survived issuance-time selection, while omission should be treated as unbounded in that draft. Harbor should collect **effective-target echo** as inspiration only, not as a durable new family.

## Resulting Harbor move
Do not decide yet whether Harbor needs durable nouns such as **audience-basis witness**, **endpoint-target card**, or **alias veto**.
For this revision:
- add one specimen around a signed Request Object, a PAR or token-endpoint client assertion, and an endpoint-alias mismatch;
- preserve the difference between “which authorization server identity this envelope names,” “which exact endpoint URI this assertion/proof targeted,” “which resource or target survived issuance-time selection,” and “none of those facts settle durable grant/account/session/adoption truth”;
- and collect **normalized-target note** plus **effective-target echo** as inspiration only, without promoting a new registry today.

## Fresh ideas worth stealing
- **audience-basis witness** — compact residue showing why a particular identifier counted as the audience basis here (`issuer`, exact PAR endpoint, exact token endpoint, etc.).
- **endpoint-target card** — inspectable note of the exact endpoint URI a proof or assertion targeted.
- **alias veto** — visible refusal when the proof is structurally valid but aimed at the wrong endpoint alias or endpoint class.
- **normalized-target note** — future-facing reminder that syntax- and scheme-normalized comparison can still be exact enough to be useful.
- **effective-target echo** — future-facing reminder that issuance-time returned target/resource details can clarify what really survived without becoming durable grant truth.
