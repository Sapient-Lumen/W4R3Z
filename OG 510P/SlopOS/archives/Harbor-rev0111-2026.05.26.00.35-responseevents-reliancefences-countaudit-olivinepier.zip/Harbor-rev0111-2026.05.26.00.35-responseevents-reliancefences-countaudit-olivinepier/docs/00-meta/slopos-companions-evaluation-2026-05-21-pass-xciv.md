# SlopOS and companions evaluation — pass XCIV

**Revision:** `rev0094`  
**Date:** 2026-05-21  
**Focus:** `CrossingRecord v0`, scope algebra, SlopOS portal boundary evidence, implementation exception handling, warning lifecycle, agent-memory invalidation, clock basis, and hostile receipt fixtures.

## SlopOS pressure

SlopOS has moved ahead of Harbor on executable request evidence. Its `portal.net.request` work pressures Harbor to stop relying on prose-only aftermath vocabulary and to define a compact crossing record that can receive SlopOS evidence without upgrading it.

The strongest SlopOS lessons for this pass:

- **Accepted transport is not trusted content.** A SlopOS accepted request can supply route/admission evidence, not a truth claim about the response, public copy, credential, or downstream correction.
- **Checkpoint/resume is continuity evidence.** It can support Harbor's aftermath record, but not claim that outside state, user intention, or source authority remained unchanged.
- **Truncation must stay visible.** Truncated response, shortened explanation, or summarized status is a degradation outcome with non-promises, not an acceptable substitute for complete evidence.
- **Accepted-only append history is not retroactive repair.** Later append entries can supersede, reopen, or contradict earlier entries, but they do not cleanse stale public use by themselves.
- **Malformed-envelope rejection is a Harbor fixture source.** SlopOS rejection cases should feed Harbor hostile receipt fixtures for wrong digest, wrong scope, hidden suffix, and authorityless metadata.
- **Portal/chooser/callback evidence is not user cognition.** User-mediated route evidence can be visible and still fail comprehension, authority, or local adoption.

## Companion pressure

- **ViewFS:** trusted paths and consent fences reinforce that visible/opened/presented does not imply understood, adopted, or authority-bearing. Harbor's scope algebra must carry audience/surface/path splits.
- **Helm:** intervention traces and remainder bridges reinforce explicit recheck windows, retry attempts, and clock-basis receipts for failed rechecks or reopened actions.
- **Schell:** minimization and forgetting ledgers reinforce that invalidation request is not deletion, unlearning, or global agent memory repair.
- **Ward:** delegation warrants and escalation handoffs reinforce recipient authority limits, appeal/stay posture, and no default winner between public status and proof packets.
- **Foundry:** classification pins and witness crosswalks reinforce label preservation, digest binding, and negative fixtures for scope-stripped receipts.
- **Steward:** retry/replay guards reinforce accepted-only append, no latest-wins repair, and explicit pushback budgets for overclaimed closure.

## Harbor delta

`rev0094` adds:

- `docs/00-meta/datacube-crossing-records-scope-and-warning-lifecycle.md`;
- `docs/00-meta/harbor-slopos-boundary-map.md`;
- `docs/00-meta/harbor-threat-model.md`;
- specimen flow 89 for missed deadlines, failed rechecks, contradictory evidence, rollback/reopen triggers, stale recurrence, and warning lifecycle decisions;
- implementation-exception proof obligations in `docs/00-meta/datacube-proof-obligations.md`;
- question-registry statuses, assumption/followthrough status normalization, and stricter repo hygiene checks;
- refreshed release metadata, research/evaluation surfaces, lessons, inspiration harvest, source register, bibliography, roadmap, context pack, manifest, and archive index.

## Deliberate non-promotion

This pass does not promote a crossing-record schema, scope engine, state-machine runtime, public status-page product, compliance workflow, deadline service, recheck service, rollback protocol, source-owner ticketing system, agent-memory subsystem, browser identity stack, MCP integration, OAuth profile, Digital Credentials profile, VEX/CSAF profile, in-toto predicate, SCITT dependency, transparency log, reputation model, enforcement ladder, or final SlopOS datacube shape.
