# Datacube assertion posture

Purpose: keep Harbor honest that an assertion result is not the same thing as row meaning, lane shape, or compatibility verdict.

Harbor already has contract tiers and an assertion plane.
What it still needs is a small way to say how strongly one assertion outcome should matter **right now** while the datacube is still in design phase.

## Core rule
An assertion can pressure a lane without silently redefining the lane.

A freshness miss, a volume dip, a duplicate spike, or a temporarily missing observed value may change whether Harbor is comfortable publishing or consuming a lane, but those events should stay visibly smaller than:
- the lane's row meaning;
- the lane's shape contract;
- the lane's change-class / compatibility story; and
- the lane's historical meaning.

## Compact posture ladder
Harbor should keep the posture ladder small.

1. **observe-only**
   - useful signal, no automatic publish or consumption block;
   - still worth recording if it repeatedly shapes operator behavior.

2. **warn**
   - noteworthy enough that people should see it, but not strong enough to counterfeit a contract break or force immediate retirement.

3. **blocking**
   - strong enough that Harbor should stop promotion, stop claiming the stronger service/assertion posture, or require an explicit waiver receipt.

4. **unknown / not observed**
   - not a pass;
   - use when Harbor lacks a trustworthy observed value, result window, or evaluation basis.

These are review-surface postures, not a commitment to any specific testing product or alerting vocabulary.

## Observed-value note
Every nontrivial assertion should be allowed to carry a compact **observed-value note**.

That note can include:
- the measured value or interval;
- the evaluation window;
- whether the value is exact, sampled, estimated, or unavailable;
- the comparison threshold or expectation family; and
- the evidence source or derived artifact where deeper details live.

The observed-value note matters because a red/yellow/green badge alone often hides the reason the status exists.
A lane may be `warn` because it is 8 hours stale against a 6-hour target, or because 2 of 10,000 rows duplicated, or because no trustworthy observation was produced at all.
Those are different truths.

## Waiver receipt
Harbor should permit a bounded **waiver receipt** when a lane is still worth using temporarily despite a blocking or warn-level assertion problem.

A waiver receipt should name:
- the affected lane and stability ring;
- the affected assertion(s);
- current posture (`warn` or `blocking`);
- who is accepting the exception;
- why the exception exists;
- what consumer slices are covered;
- what evidence was reviewed;
- when the waiver expires; and
- what would end the waiver early.

A waiver receipt is not a hidden success state.
It is explicit residue saying: the signal is real, the exception is deliberate, and the exception is temporary.

## Why this is smaller than a giant governance system
Harbor should **not** decide yet:
- exact alert routing;
- exact test-run storage product;
- exact waiver workflow engine;
- exact status enum shared across every neighboring cube; or
- exact machine-readable rule syntax.

The repo/process win is smaller: one review surface can now say whether a failing check is merely observed, visible-but-tolerated, temporarily waived, or promotion-blocking.

## Relation to the other datacube surfaces
- **stability rings** say how mature the lane is.
- **contract tiers** say what kinds of promise the lane makes.
- **change classes** say what kind of edit is being proposed.
- **assertion posture** says how strongly Harbor treats the current verification result.

Keeping those separate is how Harbor stays cautious while SlopOS and the sibling cubes are still discovering their own stable nouns.

## Pass LXXX note — unsupported target posture
An assertion target that cannot preserve source semantics yields `unsupported` or `no-result`, not pass, fail, warn, or waiver by default. A generated check may still be useful for a subset, but unsupported source semantics must remain visible and must not widen a public contract.
