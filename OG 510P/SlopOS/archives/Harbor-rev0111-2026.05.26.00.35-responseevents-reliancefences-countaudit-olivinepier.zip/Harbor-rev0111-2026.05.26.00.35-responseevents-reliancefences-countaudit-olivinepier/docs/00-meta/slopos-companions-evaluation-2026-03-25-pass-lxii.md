# SlopOS / companions evaluation — pass LXII

This pass asks a narrower repo/process question: if Harbor starts rehearsing datacube contracts on temporary lanes, how does it keep the archive honest while SlopOS itself is still designing its own semantics? The answer is to steal process discipline harder than product architecture.

## What the companions teach this pass
- **SlopOS** remains the strongest process teacher. Its profile-default artifact boundary says the markdown review surfaces are canonical and generated machine artifacts are derived only. Harbor should copy that exact posture for future datacube schemas, semantic-model files, and catalog exports.
- **SlopOS** also keeps singleton/family growth honest with explicit contracts. Harbor should continue resisting quiet family sprawl: if publish-lane or promotion surfaces multiply, the archive should either compress them or pay for explicit structure in the same revision.
- **SlopOS** trajectory mapping also teaches something subtle: keep a short, human-reviewable closure story and avoid rediscovering why a seam was closed. Harbor should therefore prefer compact promotion receipts over diffuse folklore when a datacube rehearsal lane becomes real.
- **Foundry** contributes two especially relevant hygiene moves: the noun-promotion rubric and the load-bearing source register. Harbor should steal both attitudes for datacube work, especially while many of the key outside sources are living docs.
- **Ward** keeps reminding Harbor that optional metadata and confidence signals should remain smaller than durable truth; that still applies when a branch rehearsal produces a tempting new export.
- **Steward** keeps history/accounting honesty in view: when a lane is promoted or retired, that change deserves an explicit record instead of disappearing into the newest shape.

## Harbor consequence
Harbor should make exactly one modest repo/process expansion now:
- add a datacube artifact boundary so generated artifacts stay derived;
- add a lightweight load-bearing source register so future promotion moves know which living sources to refresh;
- add one specimen around publish lanes, branch rehearsal, and explicit promotion receipts;
- keep the current followthrough focused on restatement, semantic-front-door, and change-history pressure rather than pretending the lane story is finished.

## Still-not-yet decisions
- whether Harbor will ever need a first-class publish-lane registry rather than a handful of explicit cards/receipts;
- whether historical tags belong to Harbor’s own release discipline or to a future storage/catalog substrate;
- whether branch rehearsal should later become a sibling-owned workflow rather than a Harbor-owned semantic seam.

For now, the repo/process lesson is enough: **review surfaces first, derived artifacts second, promotion explicit, and experimental lanes disposable.**
