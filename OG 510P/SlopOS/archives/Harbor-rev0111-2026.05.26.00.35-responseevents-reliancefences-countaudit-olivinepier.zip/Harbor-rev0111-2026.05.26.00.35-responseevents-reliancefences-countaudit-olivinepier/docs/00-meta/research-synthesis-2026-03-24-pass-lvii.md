# Research synthesis — pass LVII

This pass keeps Harbor narrow and learns five compatible things at once: **a protected resource can advertise machine-readable combinations of `authorization_details` types without promising a portable entitlement grammar; a resource server can return `insufficient_authorization_details` plus an optional actionable body that helps the client construct the next OAuth + RAR turn; `authorization_details` can be enriched, filtered, or receiver-scoped as they move into token or introspection responses; step-up authentication and richer authorization-details demands can legitimately coexist in one recovery path without collapsing into one state object; and Harbor should preserve those distinctions without freezing a portable authorization-policy registry too early.**

## Outside lessons
1. **Required type combinations are real, but still smaller than a universal authorization grammar.**  
   The February 2026 OAuth RAR Metadata and Error Signaling draft adds `authorization_details_types_supported` to protected-resource metadata and defines a *required types expression* with operators like `and`, `or`, `oneOf`, and `allOf`. That is powerful enough to explain “what combinations this resource accepts” without forcing Harbor to believe there is one portable cross-provider type lattice.

2. **An actionable authorization-details body is a request-scoped offer, not durable grant truth.**  
   The same draft defines `insufficient_authorization_details` and says a resource server MAY return an informative `authorization_details` array in the HTTP body, which the client MAY use in a later OAuth request. The resource server may only do that when all trusted authorization servers accept the type used. Harbor should therefore preserve an **actionable authorization-detail offer** rather than a counterfeit approved entitlement.

3. **RAR itself already teaches that requested details, granted details, and receiver-visible details can differ.**  
   RFC 9396 says token-response `authorization_details` attached to the access token MAY differ from what the client asked for, and the AS may enrich them. It also says JWT or introspection responses can carry `authorization_details`, filtered and extended for the specific RS making the introspection request. Harbor should preserve a **required-authorization rail** and an **authorization-type slate** instead of flattening request, grant, and RS-visible detail into one object.

4. **Step-up and richer authorization can combine without becoming one hierarchy.**  
   RFC 9470 lets a resource server return `insufficient_user_authentication` with `acr_values`, `max_age`, and optionally `scope`, which the client can use to construct a new authorization request. The combination with RAR-style actionable authorization details is therefore a real pressure: one turn may require stronger authentication *and* richer structured authorization, yet neither demand should silently absorb the other.

5. **The clever next move is a typed granted-detail view, but not yet as vocabulary.**  
   RFC 9396 already allows `authorization_details` in token and introspection responses, potentially filtered and extended for the RS; the March 2026 Identity Assertion JWT Authorization Grant draft makes that even more explicit by requiring the Resource Authorization Server to include granted `resource`, `scope`, and `authorization_details` in the access-token response and allowing it to modify, filter, or omit authorization details based on policy. Harbor should collect that as the next pressure test, not promote it yet.

## Resulting Harbor move
Do not decide yet whether Harbor needs durable nouns such as **required-authorization rail**, **actionable authorization-detail offer**, or **authorization-type slate**.
For this revision:
- add one specimen where a protected resource advertises a required-types expression, returns `insufficient_authorization_details`, and optionally includes an actionable `authorization_details` body;
- keep stronger-here authentication demands, scope demands, and authorization-detail demands visibly separate even when one recovery turn satisfies all of them; and
- queue granted-versus-requested-versus-RS-filtered authorization-details as the next outside pressure, without promoting a new registry today.

## Fresh ideas worth stealing
- **required-authorization rail** — compact residue that richer authorization was required here, separate from target fit and auth-strength fit.
- **actionable authorization-detail offer** — a request-scoped object offered by the resource server to help construct the next OAuth + RAR turn.
- **authorization-type slate** — a small local summary of which authorization-details types or combinations are acceptable here.
- **required-types expression** — the idea that combinations can be machine-readable without becoming Harbor’s permanent ontology.
- **granted-detail view** — future-facing reminder that token/introspection-visible details may be filtered or enriched for a particular receiver.
