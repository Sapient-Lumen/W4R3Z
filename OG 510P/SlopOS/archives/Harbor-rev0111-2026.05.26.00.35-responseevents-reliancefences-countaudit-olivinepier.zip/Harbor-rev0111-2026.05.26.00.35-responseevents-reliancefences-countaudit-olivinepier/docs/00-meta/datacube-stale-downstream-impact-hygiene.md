# Datacube stale-downstream impact hygiene

**Status:** design-phase review surface for `rev0088`; not an ADR, schema, incident manager, customer-notification platform, legal workflow, claim registry, audit program, VEX profile, AI-incident database, model unlearning program, public status API, or final SlopOS datacube constitution.

## Why this exists

`rev0087` let Harbor say that a source-side public correction was valid while catalogs, mirrors, caches, snippets, generated explainers, retrieval indexes, training/evaluation copies, and external mirrors might remain stale. `F083` applies the next pressure: someone actually used one of those stale copies.

A downstream use can appear as a report, dashboard, dataset card, benchmark score, model/eval result, agent answer, policy memo, blog chart, or audit packet. Harbor needs enough process language to describe impact, acknowledgement, remediation, and public statements without pretending it can know every use, force every downstream repair, or certify model behavior changed.

## Tight stance

- **Known stale use is not the same as known harm.** Harbor should separate stale-copy exposure, stale-copy use, decision reliance, observed error, material impact, and remediated impact.
- **Acknowledgement is weaker than remediation.** A consumer can acknowledge a correction notice without repairing reports, dashboards, models, evals, caches, or decisions that used stale data.
- **Remediation claims need subject, action, evidence, and limits.** A downstream owner saying "fixed" is useful only if the affected copy, action, status, timestamp, evidence lane, and unsupported claims are named.
- **Use attestations are scoped statements, not omniscience.** A consumer may attest "we did/did not use artifact X in report Y". Harbor must not turn that into "no one used X".
- **Impact statements must stay safe.** Public impact copy should name corrected artifact, affected public copies, known use class, current status, and safe next action without leaking suppressed values, private replay evidence, or sealed dispute material.
- **Stale model/eval results may be irreparable now.** A notice can quarantine or annotate a result, but it does not prove unlearning, benchmark repair, regenerated answers, or behavior change.
- **Third-party status is third-party status.** Harbor can record acknowledgements and remediation attestations; it should not silently upgrade them into Harbor source truth.

## Impact states under observation

These states are deliberately small and composable. They are not a final state machine.

| State | Meaning | Counterfeit to avoid |
| --- | --- | --- |
| `exposed_copy` | a stale copy was observable or available to a downstream target | assuming it was used |
| `claimed_non_use` | a downstream party says it did not use the stale copy | treating claim as global proof |
| `acknowledged_notice` | a downstream party received/acknowledged a correction notice | treating acknowledgement as repair |
| `use_confirmed` | a downstream artifact or statement is known to have used stale copy | treating all sibling artifacts as affected |
| `reliance_unknown` | stale material is present but decision/report reliance is not known | hiding uncertainty behind severity |
| `impact_assessed` | a scoped assessment says what may be wrong and what is not known | converting triage to incident closure |
| `remediation_claimed` | downstream owner claims repair or mitigation | treating claim as observed repair |
| `remediation_verified` | Harbor/auditor can verify named remedial action for a named subject | overgeneralizing beyond subject |
| `historical_only` | old result remains visible only as history with warning | treating history as current guidance |
| `unsafe_for_new_use` | stale output should not be used for new analysis/decisions | pretending all public copies were recalled |
| `unrepairable_now` | model/eval/archive/crawl copy cannot be fixed immediately | pretending no status can be published |
| `disputed` | a party contests use, impact, or remediation status | promoting one side as authority without evidence |

## Candidate process handles

These are watchlist handles, not promoted schema.

### `stale_use_impact_packet`

A bounded packet for one suspected stale downstream use.

Candidate fields:

- source artifact, source cut, correction anchor, payload digest, label digest, successor artifact, and public-safe correction summary;
- stale copy id/class, downstream target id/class, observed stale fields/labels, and propagation receipt or stale-copy witness;
- downstream use class: report, chart, dashboard, catalog entry, dataset card, benchmark/eval, model training/fine-tune, agent answer, policy memo, audit packet, citation, or unknown;
- exposure/use status: exposed, claimed non-use, use confirmed, use likely, reliance unknown, reliance confirmed, disputed;
- impact dimensions: numeric result drift, label omission, suppression/noise label loss, stale citation, accessibility/localization drift, recomposition risk, model/eval contamination, public misunderstanding, or unknown;
- materiality lane: none observed, minor, material, safety/privacy-sensitive, sealed/auditor-only, unknown;
- affected audience and evidence lane: public, operator-only, auditor-only, sealed, refused, unavailable;
- safe public status and non-promises.

### `consumer_acknowledgement_receipt`

A record that a downstream consumer received a correction notice.

Candidate fields:

- consumer/owner id class and contact lane;
- notice id, correction anchor, affected copy, successor link, notice language/locale, and timestamp;
- acknowledgement actor, method, authority-to-acknowledge, and whether acknowledgement is receipt-only, review-started, repair-planned, repair-declined, no-use-claimed, or disputed;
- non-promise that acknowledgement does not prove remediation, deletion, unlearning, or downstream notification.

### `remediation_attestation`

A scoped downstream claim that a stale use was repaired, mitigated, annotated, or retired.

Candidate fields:

- subject: exact report/dashboard/dataset/eval/model/card/citation/cache/explainer copy;
- action: replaced, corrected, annotated, retracted, quarantined, excluded, regenerated, card-updated, warning-added, user-notified, no-fix-planned, or unknown;
- basis: human assertion, machine check, digest proof, public URL, audit packet, ticket id, third-party statement, or sealed proof;
- result status: claimed, observed, verified, partially verified, refused, disputed, expired, or unrepairable-now;
- residual risk: cached old copy, uncontacted users, prior decisions, unretracted citations, model behavior, stale eval leaderboard, archive persistence, or unknown;
- expiry/recheck posture and safe public wording.

### `use_attestation_note`

A scoped statement by a downstream consumer about whether and how it used a stale public copy.

Candidate fields:

- attester, authority, subject artifact, use window, use context, and method of determination;
- statement type: used, not used, unknown, likely used, cannot determine, no longer used, historical-only;
- evidence: logs, report citation, dataset manifest, dependency lock, retrieval index version, model/dataset card, manual review, or unsupported assertion;
- limitations and expiry.

### `safe_public_impact_statement`

A public-facing statement that does not disclose sensitive detail or overclaim repair.

Minimum content:

- what was corrected;
- which public copies or use classes are known stale/affected;
- what current artifact should be used;
- what remediation is known, claimed, unknown, or impossible to prove;
- what Harbor is not claiming: universal recall, raw-value disclosure, deletion from training data, model behavior change, every consumer notified, or every downstream decision repaired.

## Anti-counterfeit checks

- If an acknowledgement receipt lacks a correction anchor and notice id, it is just contact history.
- If a remediation attestation does not name the subject and action, it is public relations, not evidence.
- If a use attestation does not name scope and method, it must not be used as non-use proof.
- If a status says "fixed" without residual-risk and recheck posture, it risks counterfeiting closure.
- If a model/eval stale-copy notice claims repair without retraining/eval regeneration proof, it is overclaiming.
- If a public impact statement gives exact suppressed values, private replay payloads, or sealed evidence, it violates the public-copy boundary.
- If Harbor cannot distinguish `acknowledged_notice`, `remediation_claimed`, and `remediation_verified`, it is not ready to promote any impact noun.
- If a report used stale labels but its numeric values are unchanged, the impact packet should still name label/interpretation risk rather than collapsing to no impact.
- If a consumer says "we notified users," Harbor should record who that statement covers and whether Harbor observed it.
- If a downstream owner refuses to acknowledge or repair, Harbor can publish current-source guidance and stale-copy warnings without fabricating cooperation.

## Minimum proof obligations before any promotion

A candidate stale-impact noun must show at least these before it graduates from process residue:

1. It names source artifact, correction anchor, stale copy, downstream subject, and evidence lane.
2. It separates exposure, use, reliance, impact, acknowledgement, remediation claim, verified remediation, and residual risk.
3. It records who made a claim and whether Harbor observed, verified, disputed, or merely received it.
4. It states target authority and limits: source owner, catalog owner, dataset owner, dashboard owner, model/eval owner, consumer, auditor, or unknown.
5. It carries label preservation and non-promises through public statements and remediation notes.
6. It handles `no-use`, `unknown-use`, `historical-only`, `unrepairable-now`, and `unsafe-for-new-use` without forcing a green/red closure.
7. It has safe public wording that avoids leaking suppressed values, sealed evidence, private replay data, or raw consumer logs.
8. It expires or requires recheck when the remediation evidence is only a claim, stale URL, old card, old dashboard, or old eval result.

## Promotion triggers

Only consider durable nouns after repeated specimens show that:

- stale public copies repeatedly influence external reports, dashboards, model/eval cards, agent explainers, or policy decisions;
- consumers repeatedly need acknowledgement receipts that are narrower than remediation;
- downstream owners repeatedly make repair claims that need subject/action/evidence/residual-risk structure;
- safe public impact statements repeatedly prevent either panic or false closure;
- SlopOS or companions repeatedly need the same stale-use/use-attestation/remediation fields.

Until then, keep `stale_use_impact_packet`, `consumer_acknowledgement_receipt`, `remediation_attestation`, `use_attestation_note`, `safe_public_impact_statement`, `residual_risk_note`, and `unrepairable_now_notice` as process residue.

## Explicit non-decisions

This document does not choose an incident-management platform, public status page, customer-notification workflow, legal/remediation workflow, VEX/CSAF profile, SLSA/in-toto predicate, AI-incident reporting taxonomy, audit evidence format, model unlearning program, eval governance program, external dispute process, public dashboard, or final SlopOS datacube shape.
