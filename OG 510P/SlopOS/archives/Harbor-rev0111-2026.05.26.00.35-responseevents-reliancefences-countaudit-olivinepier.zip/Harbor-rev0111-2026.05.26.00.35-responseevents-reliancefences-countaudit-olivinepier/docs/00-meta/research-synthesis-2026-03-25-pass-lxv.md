# Research synthesis — pass LXV

This pass learns the next restraint for a design-phase datacube: **Harbor should not talk about compatibility until it first classifies the change. It should steal change classes, explicit compatibility verdicts, bounded bridge windows, and shadow diffs so design-phase evolution stays honest instead of folklore-driven.**

## Outside lessons
1. **Compatibility modes are named policies, not vibes.**
   Confluent’s schema-registry docs distinguish backward, forward, full, and transitive modes, and explicitly note that the default `BACKWARD` mode is not `BACKWARD_TRANSITIVE`. Harbor should steal the discipline: a lane that is only checked against the latest published form should not pretend it proved deeper history compatibility.

2. **Alias and default bridges are migration aids, not proof that meaning stayed the same.**
   Avro allows aliases to rewrite a writer schema to the reader schema and lets readers use defaults for missing fields, but the spec also says defaults are used when reading missing fields and do not make a field optional at encoding time. Harbor should steal the caution: alias-backed rename or default-backed field introduction is a **bridge verdict**, not a universal non-breaking badge.

3. **Deleted identifiers should stay retired long enough to avoid accidental semantic resurrection.**
   Protobuf’s best-practices guide says not to re-use tag numbers, to reserve deleted field numbers and names, and not to add required fields. Harbor should steal the behavioral pattern without pretending to be Protobuf: once a published identifier is retired, leave a compact **retirement reservation note** before reusing its name in the same lane family.

4. **Versioned overlap is a mature-model tool, not something to spray everywhere on day one.**
   dbt’s model-version docs explicitly frame versions plus deprecation windows as a pathway for mature, widely-used models; they also say that additive changes often do not need a new version, while intentional column-name or data-type changes should create one. Harbor should steal that judgment posture: many additive changes can stay in-place, but meaning rewrites or intentional shape breaks deserve a successor or overlap window.

5. **Shape checks cannot adjudicate semantic drift by themselves.**
   dbt also notes the judgment-call problem: a recalculation can substantially change results even when names and data types stay the same. Harbor should therefore classify **meaning-reinterpreting** changes separately from shape-breaking changes and require their own verdicts.

## Harbor consequence
Harbor should add one modest datacube/process seam now:
- **change-class card** — compact declaration of what kind of change is proposed: shape-additive, shape-bridged, shape-breaking, meaning-clarifying, meaning-reinterpreting, assertion-only, service-only, or historical/restatement;
- **compatibility verdict** — compact statement of whether the change is safe in place, safe only with a bridge window, successor-required, historical-restatement-only, or not yet publishable;
- **bridge window** — bounded overlap period for alias-backed or dual-shape migrations;
- **shadow diff** — rehearsal comparison across affected consumer slices, keeping diff evidence smaller than canonical meaning; and
- **retirement reservation note** — small tombstone against accidental identifier reuse after published retirement.

## What Harbor still should not decide yet
- exact machine-readable diff format or checker;
- exact alias/bridge implementation (dual-write, view projection, semantic adapter, or generated artifact);
- exact version-number syntax or registry product;
- exact reservation representation for retired identifiers.

The lesson to keep now is the **classification discipline**: name the change class first, issue a compatibility verdict second, and only then decide whether an overlap window or successor lane is warranted.
