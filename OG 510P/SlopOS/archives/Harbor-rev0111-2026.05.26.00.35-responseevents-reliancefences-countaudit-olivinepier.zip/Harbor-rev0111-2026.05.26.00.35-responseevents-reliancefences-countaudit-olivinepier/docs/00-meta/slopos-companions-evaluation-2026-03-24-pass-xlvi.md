# SlopOS / companions evaluation — pass XLVI

This pass re-checks Harbor against SlopOS and the sibling cubes after adding a chooser-cleanup specimen, and again chooses one narrow crossing seam over any early family bloom.

## What the current cubes still teach
- **SlopOS** remains the strongest restraint mechanism. Its auth-teardown boundary already says logout, disconnect, and revocation stay provider-local rather than becoming portable control surfaces, and its browser-session boundary keeps remembered authenticated browser state smaller than portable authority. That lines up cleanly with Harbor treating cleanup pulses and silent-access resets as local crossing residue, not as a new durable account/session plane.
- **SlopOS** also keeps the design-phase lesson alive: exact local hygiene moves are worthwhile even when they never become public portable nouns. Harbor can do the same with stale-chooser quarantine and display refresh residue.
- **Ward** keeps contributing the right operational instinct: stale remembered candidates should bottom out into revalidation or quarantine instead of being spent through just because they still look plausible in UI.
- **Helm** keeps reminding Harbor that chooser chrome and account labels can be useful, refreshed, and honest without outranking exact local basis. A renamed account label is still weaker than adopted identity truth.
- **Foundry** keeps the foreign-ground lesson alive: chooser or authenticator state may live outside the local app/runtime, which is another reason cleanup signals should stay advisory rather than counterfeit immediate global truth.
- **Steward** keeps the accountability lesson alive: a cleanup request or sign-out pulse should be recorded as smaller aftermath than a confirmed durable completion or cross-system revocation.

## Harbor consequence
Harbor should keep this move modest:
- add one specimen around **cleanup pulse**, **stale-chooser quarantine**, and **display-refresh residue**;
- keep chooser cleanup, label refresh, and silent-access reset visibly smaller than durable issuer/account/session/adoption truth;
- collect **capability-gated cleanup** and **mediation reset** as inspiration only;
- and leave any future registry of chooser-state classes, authenticator-sync guarantees, or account-refresh schemas outside Harbor for now.

## Still-not-yet decisions
- Whether **cleanup pulse** deserves its own Harbor family, or should remain only an annotation on detour/aftermath surfaces.
- Whether **stale-chooser quarantine** belongs in Harbor at all, or should remain only a smaller local revalidation/veto outcome.
- Whether **display-refresh residue** belongs in Harbor, or should stay a compact review/selection note with receipt-level visibility only.
