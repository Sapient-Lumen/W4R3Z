# Research synthesis — 2026-03-28 pass LXXV

Question: while SlopOS and Harbor are both still in design phase, what must Harbor learn **before** it freezes a semantic front door, temporal defaults, or history/contract surfaces for the datacube?

## What current sources say
1. **Event time, processing time, and publish time are different truths.**
   Flink’s current time model still draws the sharpest line: event time follows when the thing happened, while processing time follows when the system happened to handle it. Harbor should keep stealing that lesson. A dashboard lane that groups by occurrence time, a freshness badge derived from latest knowledge time, and a published cut tagged at a revision are not interchangeable stories.

2. **Business-valid truth and system-current truth are different axes.**
   Db2’s bitemporal docs still make the distinction crisply: `BUSINESS_TIME` says when something was valid, while `SYSTEM_TIME` says when the database considered a row current. SQL Server’s temporal guidance sharpens the warning by saying transaction/system time can be the wrong substitute when load delay is significant. Harbor should steal the consequence, not the whole vendor stack: validity time, knowledge/currentness time, and published-cut time should stay visibly different.

3. **Safe evolution is additive first, destructive later.**
   Iceberg’s evolution docs say added, dropped, updated, and reordered fields are designed to avoid side effects; Delta’s schema-enforcement guidance is blunt that incompatible writes should fail unless change is intentionally allowed. Harbor should steal the design-phase posture: additions, sidecars, and explicit successor lanes are healthier defaults than silent reinterpretation or destructive rewrite.

4. **A contract is not every assertion, and freshness is not a vibe.**
   DataHub’s current contract docs say a contract can be a selected public subset of assertions on one asset, while assertions remain separate reusable building blocks. dbt’s freshness docs say freshness is an explicit calculation from the most recent record to now, with named warn/error thresholds. Harbor should steal both: lane promise, observed assertion results, and freshness basis should remain different review surfaces.

5. **Join safety and additivity must be declared, not guessed.**
   Looker still says symmetric aggregates depend on a unique primary key and the correct join relationship. dbt’s current measures docs keep the same lesson in smaller form by allowing explicit non-additive dimensions. Harbor should steal that discipline: repeated child rows, forbidden rollup axes, and base-grain uniqueness belong in the review surface before a visible number becomes a portable truth.

6. **History convenience surfaces can quietly weaken history.**
   Iceberg’s changelog tooling still distinguishes changed-row views from raw carry-over rows, and Debezium’s flattening transform still lets teams drop or rewrite delete/tombstone semantics for convenience. Harbor should steal the warning: changed rows, full change history, deletes, and restatements are different promises even when a downstream sink wishes they were one easy feed.

7. **Row lineage is a powerful idea, but it is still smaller than universal identity truth.**
   Iceberg’s current spec says row lineage becomes required for newly created rows in v3 tables. Harbor should collect the idea without overfreezing it: a row-lineage sidecar or receipt could be very useful later, but that still does not mean Harbor should rush into a universal row-ID constitution while the datacube is settling.

## Harbor consequence
Harbor should make one modest process expansion now:
- add a **datacube review loop** doc that says every design-phase revision must refresh living load-bearing sources, write the current research/evaluation passes, update lessons and steal-ideas surfaces, and leave generated semantic artifacts visibly derived;
- keep **semantic-model YAML, catalog exports, metric APIs, freshness configs, and join-relationship hints** smaller than the canonical review surfaces;
- collect **contract-subset posture, freshness-basis witnesses, join-relationship notes, delete-mode/history witnesses, and optional row-lineage sidecars** as strong ideas worth stealing; and
- keep the current measurement-semantics followthrough as the single `next` pressure test rather than pretending this pass already chose a warehouse, semantic-layer product, or row-identity regime.

## What Harbor still should not decide yet
- one universal semantic front door or metric API product;
- one mandatory global row identifier or row-lineage regime for every lane;
- one ambient default time axis for every “as of” or freshness question;
- one global contract/assertion/freshness badge that flattens promise, evidence, and thresholds together.

The design-phase lesson is enough for now: **name the axis, keep contracts smaller than assertions, keep joins/additivity explicit, keep history loss visible, and treat row lineage as a promising sidecar rather than a constitutional truth.**
