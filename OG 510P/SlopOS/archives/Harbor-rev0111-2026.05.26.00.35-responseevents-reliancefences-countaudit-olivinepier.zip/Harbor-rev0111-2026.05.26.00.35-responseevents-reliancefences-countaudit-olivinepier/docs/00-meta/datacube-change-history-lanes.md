# Datacube change-history lanes

Purpose: keep Harbor honest that a design-phase datacube can expose **current state, latest changed rows, full row-change history, and restatement history as different promises** instead of one counterfeit “history” surface.

Design-phase cubes repeatedly get into trouble when they flatten these different things together:
- a current-state table gets mistaken for an audit trail;
- a “changed rows since X” export gets mistaken for every intermediate change;
- a net-diff summary gets mistaken for ordered event history;
- physical rewrite artifacts get mistaken for logical business change; and
- a historical backfill or correction gets published as if nothing about previous results changed.

Harbor should not choose one CDC product, one lake format, one event bus, or one global operation-code ontology now.
It does need one compact review surface that keeps **lane class**, **replay cut**, and **restatement consequence** visible whenever a curated lane claims to show history.

## Core rule
A Harbor lane must not call itself “history” without saying **what kind of history it is**.

Current state, latest changed rows, all changes, net changes, and historical restatements answer different questions.
A design-phase cube can publish any of them, but it should not let one stand in for the others.

## Minimal lane classes (Phase 1)
Harbor should keep the first set small and descriptive rather than freezing a giant CDC vocabulary.

1. **current-state lane**
   - exposes the current or selected-as-of row state.
   - useful for present-tense answers and drill-across.
   - does **not** by itself prove how the row changed.

2. **changed-rows lane**
   - exposes the latest values for rows that changed after a named commit/snapshot/time cut.
   - useful for incremental downstream recomputation.
   - does **not** guarantee every intermediate change is present.

3. **change-history lane**
   - exposes typed row-level changes across a named replay cut.
   - may include inserts, deletes, and update before/after images if the source can support them.
   - should visibly say whether it is full ordered change history, append-only op-coded rows, or a weaker net-change view.

4. **net-change lane**
   - exposes the surviving delta between two cuts after intermediate changes have been collapsed.
   - useful for efficient reconciliation or downstream sync.
   - should stay visibly different from ordered change history.

These are review classes, not a commitment to Delta CDF, Iceberg changelog views, Hudi CDC, Debezium, Flink, Kafka, or one warehouse-native changelog format.

## Change-history lane card
Harbor should allow a compact **change-history lane card** beside any curated history-shaped lane.

The card can say:
- whether the lane is current-state, changed-rows, full change-history, or net-change;
- whether updates appear as before/after images, one merged row, or only final state;
- whether deletes are explicit, tombstoned, summarized, or omitted;
- whether the lane is intended for replay, audit, downstream sync, or merely convenience export; and
- whether the lane preserves ordering guarantees inside the replay cut.

The point is not to standardize every changelog.
The point is to stop one convenient export from counterfeiting more replayability than it owns.

## Replay cut note
Harbor should allow a compact **replay cut note** whenever a lane claims to show changes.

A replay cut note can say:
- the start and end basis for the slice (commit range, snapshot range, timestamp range, or other named cut);
- whether the cut is based on knowledge/commit time, event/occurrence time, or another axis;
- whether the lane is replay-safe, diff-only, or merely best-effort;
- whether late-arriving rows can still change the slice later; and
- whether the cut is open head, frozen snapshot, or historical tag.

This matters because “since yesterday” can mean very different things depending on whether the lane uses event time, commit time, or a replay tag.

## Carry-over veto
Harbor should keep one standing anti-regrowth rule: **physical carry-over rows do not automatically count as logical change**.

File rewrites, copy-on-write preservation rows, compaction artifacts, and similar substrate churn can produce delete/insert-looking pairs that are useful for engine internals while still being weaker than actual business change.
If Harbor later exports such rows, it should mark them explicitly rather than letting them impersonate logical history.

## Restatement receipt
Harbor should allow a compact **restatement receipt** whenever a curated history lane or published cut changes because Harbor recomputed or corrected prior history.

A restatement receipt can say:
- what lane or published cut was restated;
- whether the restatement was caused by late-arriving data, corrected source values, remapping logic, or changed computation;
- whether historical outputs are directly comparable before and after the restatement;
- whether Harbor kept both the old and new cuts, replaced the old cut, or published a bridge window; and
- whether consumers need replay, re-baselining, or no action.

This matters because history rewrites are often semantically larger than schema edits.
Harbor should leave explicit residue when yesterday’s published story changed.

## What this forbids in Phase 1
- no calling a current-state lane an audit trail;
- no calling a changed-rows export “full history” when intermediate changes were collapsed;
- no calling a net-diff slice a replayable ordered history;
- no silently flattening update/delete semantics into after-only payloads without saying so; and
- no silently restating published history without a receipt.

## What this still leaves open
- exact machine schema for change-history lane cards, replay cut notes, or restatement receipts;
- exact operation-code family Harbor may adopt later;
- exact retention, replay, and compaction policies for history-shaped lanes;
- whether Harbor later distinguishes more history classes such as tombstone-only, append-only event, or coarse aggregate-diff lanes.

Harbor only needs the review behavior now: **name the kind of history, witness the replay cut, and leave a receipt when history itself changes.**
