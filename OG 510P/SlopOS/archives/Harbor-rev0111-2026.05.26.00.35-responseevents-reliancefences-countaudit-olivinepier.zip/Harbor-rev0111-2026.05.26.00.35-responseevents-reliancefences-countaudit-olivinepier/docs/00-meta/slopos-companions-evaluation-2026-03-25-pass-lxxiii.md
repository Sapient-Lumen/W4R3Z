# SlopOS / companions evaluation — pass LXXIII

This pass asks a design-phase datacube question rather than a warehouse-product question: if Harbor later exposes current-state lanes, changed-rows exports, full change-history lanes, or corrected historical cuts, how does it stop those different strengths of history from collapsing into one vague “delta” surface?

## What the companions teach this pass
- **SlopOS** remains the strongest process teacher because it keeps moving heads, locked sources, review queues, and evidence indexes visibly separate. The transferable lesson is that Harbor should treat current-state heads, replayable history cuts, and corrected/restated history as different review surfaces. SlopOS’s hygiene posture keeps those distinctions same-revision maintained instead of leaving them to memory.
- **Steward** keeps teaching receipts and accountable aftermath. That transfers directly: if Harbor republishes prior history or corrects a historical cut, the change deserves a receipt rather than silent replacement.
- **Foundry** keeps teaching residue-class discipline. For Harbor, that becomes the reminder that current state, changed rows, ordered row changes, and restated history are different residue classes even when they all fit in tables.
- **Ward** keeps teaching tier honesty. That transfers well here: a convenient changed-rows export is useful while still smaller than a replayable full history lane.
- **ViewFS** keeps teaching import/open-in-place humility. Harbor can reuse that instinct for history exports too: an append-only transport or simplified downstream export can be helpful, but should not automatically become Harbor’s canonical change history.

## Harbor consequence
Harbor should make exactly one modest repo/process expansion now:
- add a datacube change-history-lanes surface;
- add one specimen around change-history lane cards, replay cuts, carry-over vetoes, and restatement receipts;
- refresh the load-bearing source register with living sources that keep current-state, changed-rows, full CDC history, and append-only op-coded exports visibly different; and
- keep semantic-front-door pressure alive without pretending this pass chooses a final CDC stack, event bus, or warehouse format.

## Still-not-yet decisions
- whether Harbor later publishes one canonical change-history lane or a family of differently scoped history lanes;
- whether restatement receipts become first-class machine-readable artifacts or remain smaller repo/process residue;
- whether Harbor later standardizes before/after images, tombstones, or only coarse operation classes;
- whether corrected history should always emit successor lanes, overlap windows, or replacement-in-place receipts.

For now, the companion lesson is enough: **keep state smaller than history, keep changed-rows smaller than full replay, and keep corrected history explicitly receipted.**
