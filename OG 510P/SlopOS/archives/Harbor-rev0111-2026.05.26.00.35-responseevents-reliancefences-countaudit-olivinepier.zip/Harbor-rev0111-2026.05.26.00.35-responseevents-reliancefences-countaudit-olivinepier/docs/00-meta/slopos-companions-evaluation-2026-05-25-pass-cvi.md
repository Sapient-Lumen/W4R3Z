# SlopOS companions evaluation — 2026-05-25 pass CVI

## Harbor / SlopOS seam

F101 keeps the Harbor-SlopOS boundary sharp. SlopOS can say which portal-net record was accepted, appended, resumed, truncated, replayed, or returned through a callback. Harbor uses that evidence as lineage material, not as currentness authority.

## Useful imports from SlopOS

- Accepted append history can order observed correction receipts, but only within the recorded stream.
- Checkpoint/resume evidence can explain why a derivative repair was based on epoch A rather than epoch B.
- Truncation and suffix rejection can prevent hidden bytes from entering a lineage record.
- Callback returns can show that a candidate update crossed back into local review, not that it repaired all derivatives.

## Refusals

- SlopOS order is not Harbor scope comparison.
- Portal success is not epoch currentness.
- Append-after-correction is not repair of earlier stale derivatives.
- Callback receipt is not source-owner closure.
- Replayable history is not public green badge authority.

## Next pressure

F102 should stress cross-cube lineage handoff: when Foundry/Steward/Schell/ViewFS/Ward/Helm each carry a fragment of epoch evidence, Harbor needs import packets that keep foreign lineage, local lineage, replay availability, retention windows, and warning state from collapsing into one inherited status.
