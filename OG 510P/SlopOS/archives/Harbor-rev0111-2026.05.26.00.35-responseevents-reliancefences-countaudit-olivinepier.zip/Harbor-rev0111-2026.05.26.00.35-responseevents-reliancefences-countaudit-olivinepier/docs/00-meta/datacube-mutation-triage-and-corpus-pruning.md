# Datacube mutation triage and corpus pruning

**Status:** embryo verification surface, not a dashboard, not a score, not a conformance suite.  
**Introduced:** `rev0099` / F094.  
**Owns:** the question "what should Harbor do when generated pressure is not simply killed by the checker?"

## Why this exists

F093 made Harbor's executable checkers pressure-sensitive: 38 deterministic mutations must be killed. That created a new risk. A mutation result can now be over-read in either direction:

```text
killed   -> "the checker is complete"
survived -> "the checker is broken"
```

Both are false. A survived mutant may reveal a real checker gap, but it may also be equivalent, cosmetic, out of scope, or intentionally left smaller than a durable fixture. A killed mutant may be a correct rejection, but it may also be an overstrict canonicality guard that would be harmless in a semantic JSON model.

F094 therefore adds a triage layer after mutation coverage. It does not increase the mutation count for its own sake. It records classification packets for unsafe survivors, equivalent survivors, checker-overstrict candidates, and pruning decisions.

## Core split

```text
generated or hand-minimized mutation
→ current checker observation
→ legacy/prior observation, if relevant
→ triage class
→ promotion or non-promotion packet
→ corpus-pruning decision
```

This is deliberately smaller than a mutation dashboard. Harbor cares about whether a counterfeit is understood, guarded, parked, or pruned. It does not care about a mutation score as a public badge.

## Triage classes

| Class | Meaning | Required action |
|---|---|---|
| `unsafe_survivor_guarded` | A prior or hypothetical checker accepted a semantically unsafe counterfeit. | Add or keep a checker guard, preserve a triage fixture, and record no open unsafe gap. |
| `equivalent_survivor_do_not_promote` | The current checker accepts a mutant because the fixture semantics did not change. | Keep the survivor as triage evidence, not a hostile fixture or coverage gap. |
| `overstrict_false_positive_candidate` | The current checker rejects a semantically harmless edit because deterministic fixture canonicality is stricter than the domain. | Do not relax the checker unless repeated pressure shows the strictness is harmful. |

## What rev0099 found

The deep pass found a real seam: earlier checkers rejected forbidden authority/truth **keys** but could miss forbidden authority/truth **phrases** in accepted string values. F094 adds a shared forbidden-phrase guard to the CrossingRecord, transparency/provenance receipt, and verifier-disagreement checkers.

Examples now killed by current checkers:

```text
guarded killed example: crossing.admission_authority_basis = "global truth confirmed by portal result"
guarded killed example: receipt.verifier.policy_id = "global truth verifier policy"
guarded killed example: disagreement.public_status.explanation = "One badge truth for all audiences"
```

These are not new schema fields. They are triaged unsafe survivor patterns that became checker guards.

## Equivalent survivors

F094 also preserves three current survivors as equivalent/cosmetic under the current fixture:

```text
crossing non_promises reordered
receipt currentness "none" reworded as "not applicable" while the verdict still refuses freshness
disagreement safe public-status explanation appended with "Recheck remains required."
```

These survive because the existing checkers do not require exact prose or list order where the semantic guard is already elsewhere. They do not become hostile fixtures, and they do not increase a mutation score.

If repeated examples show that one of these cosmetic changes hides a real status downgrade, a later followthrough should promote the case with a stronger packet.

## Overstrict false-positive candidate

F094 records one killed but semantically harmless mutation:

```text
crossing members sorted alphabetically instead of emitted in canonical member-label order
```

JSON object order is not semantic domain truth, but Harbor's deterministic fixture contract intentionally treats member-label order as load-bearing for archive reproducibility, review diffs, and case-table alignment. The checker stays strict. The triage packet prevents anyone from mistaking this kill for semantic insight.

## Corpus pruning

F094 makes four pruning decisions:

1. Do not expand F093's killed count with duplicate value-overclaim rows; the current checkers now carry the guard and F094 records the pattern.
2. Do not promote cosmetic survivors into hostile fixtures without repeated pressure.
3. Keep canonical member-label order strict for deterministic reproduction.
4. Park mutation scores, dashboards, and coverage gates.

## Non-promises

F094 does not prove:

- complete mutation adequacy;
- branch/path/fuzz coverage;
- conformance to any external standard;
- correctness of Harbor's object model;
- that all equivalent mutants are correctly classified;
- that future generated fixtures are safe to promote automatically;
- final SlopOS datacube shape.

## Promotion guard

A survived mutation may become a hand-authored hostile fixture only when its packet states:

```text
operator id
baseline digest
mutant digest
current checker observation
legacy/prior observation, if any
unsafe semantic delta
minimal reproducer
why existing fixture cases were insufficient
checker change made or deliberately refused
non-promotions that remain
```

Generated pressure remains subordinate to specimen discipline.
