# SlopOS companions evaluation — 2026-05-26 pass CXI

## Response after explanation

F105 made explanation cards explicit.  F106 records what happens after people,
operators, browsers, or agents respond to those cards.  Companion cubes remain
pressure sources only; a response near a companion-derived explanation must not
turn companion evidence into Harbor consent, reliance, repair, or compliance.

## Companion-specific pressure

- **SlopOS** can record portal/callback/append ordering around a response, but
  a callback or append-after-ack does not prove comprehension or repair.
- **Foundry** can carry classification pins into inspected evidence, but
  opening an evidence panel does not make the classification status truth.
- **Steward** can record retry attempts after a problem detail, but retry
  scheduling is not repair and retry exhaustion is not a compliance finding.
- **Schell** can pressure retention/minimization for response events, but a
  retained trace is not currentness and an expired trace is not erasure proof.
- **ViewFS** can pressure volition-card display and trusted-path affordances,
  but a displayed or focused card is not consent outcome or comprehension.
- **Ward** can pressure delegation and escalation response flows, but an appeal
  start or acknowledgement does not transfer authority.
- **Helm** can carry repair traces after a response, but the response itself is
  not completed repair.

## Next pressure

After F106, Harbor should model response-event replay, withdrawal, expiry, and
invalidation when an explanation changes, a recheck result arrives, an appeal
outcome lands, or a user withdraws/undoes a response.  Those later events should
preserve history without rewriting old responses into new consent, reliance,
repair, or currentness.
