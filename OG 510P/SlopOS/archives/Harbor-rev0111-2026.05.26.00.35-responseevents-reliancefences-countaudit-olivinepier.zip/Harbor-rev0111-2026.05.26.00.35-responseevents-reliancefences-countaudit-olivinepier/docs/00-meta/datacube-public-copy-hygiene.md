# Datacube public-copy hygiene

This surface is a **review aid**, not a schema, public data portal, data package format, catalog vocabulary, BI/export governance product, license engine, cache-control profile, provenance ontology, or final SlopOS datacube shape.

It exists because aggregate-disclosure review created a new hazard: a release can be safe only when its labels and release conditions remain attached. Public copies travel through CSV, BI exports, dashboards, PDFs, screenshots, catalogs, mirrors, caches, data packages, notebooks, and downstream reports. Each step can strip the very labels that made the public aggregate honest.

## Stance
- Release is not copy hygiene.
- A valid internal release does not make every downstream copy valid.
- A public copy is not a live alias of the internal answer.
- Labels are part of the cargo, not decoration.
- Restatement supersedes or deprecates old public copies; it does not rewrite the past.
- Withdrawal is not guaranteed recall.
- Proof of public copy should prove emitted bytes, labels, cut, and restatement relation without exposing raw replay evidence.

## Copy modes for specimens

| mode | meaning | must not infer |
| --- | --- | --- |
| `valid_labeled_public_copy` | emitted copy preserves required release labels and basis | safe for arbitrary recomposition |
| `label_stripped_copy` | copy lost suppression/noise/exactness/restatement labels | valid release or harmless mirror |
| `stale_public_copy` | copy was once valid but has not revalidated after restatement or expiry | current truth or current public recommendation |
| `superseded_public_copy` | newer public copy exists and names the relationship | old copy was wrong by absence of value |
| `withdrawn_public_copy` | publisher says do not use this copy under current policy | all downstream copies have been erased |
| `proof_only_copy` | verifier receives digest/manifest/labels without raw value or replay payload | raw evidence access or semantic approval |
| `unknown_mirror_copy` | downstream mirror cannot prove labels, digest, or basis | data absence or maliciousness by default |
| `invalid_recomposition_copy` | combination of copies would reconstruct hidden values | each input copy was invalid alone |

## Review handles

### Public copy label
A compact label set that must travel with the public artifact.

Candidate labels:

- `disclosure_treated`;
- `not_exact_public_copy`;
- `coarsened_for_disclosure`;
- `suppressed_cells_present`;
- `perturbed_release`;
- `not_a_dp_claim`;
- `structural_zero_labels_present`;
- `restated_by` / `supersedes`;
- `valid_until` / `revalidate_after`;
- `do_not_recompose_with` or equivalent sibling-cut warning.

### Release artifact receipt
A compact receipt that names the public artifact, source cut, public cut, release mode, release policy digest if any, label set, audience, and exactness/additivity consequences.

This is not a public API. It is proof residue for a particular release event.

### Copy-basis digest
A digest or manifest pointer for the emitted public bytes plus the label/metadata bytes that must be checked together.

Healthy posture:

- digest the data file and required metadata/label sidecar together;
- distinguish payload digest from label/manifest digest;
- reject proof claims when the data matches but labels were stripped;
- do not treat a screenshot/chart digest as proof of cell-level label preservation unless the label basis is also present.

### Mirror receipt
Process residue for a public mirror, dashboard tile, catalog distribution, cache, or downstream export.

Candidate fields:

- mirror identity or audience class;
- source release artifact;
- last validation time;
- digest/label match result;
- freshness/staleness posture;
- invalidation/restatement link;
- allowed consumer copy.

### Label-preservation check
A review check that asks whether the chosen export format can carry or bind all required labels.

Healthy posture:

- embedded labels if the format supports them;
- sidecar labels if the format does not;
- manifest-level binding so sidecar and payload cannot drift apart;
- refusal or warning when a downstream format cannot preserve enough meaning.

### Restatement chain
A record of public-copy succession.

It names:

- old public artifact;
- new public artifact;
- relation: correction, policy restatement, disclosure-treatment change, stale-cut retirement, or withdrawal;
- whether old copy remains citable, deprecated, invalid for new use, or unsafe;
- consumer-facing copy explaining the relation.

### Recomposition guard
A note that says which public copies, cuts, sibling tables, filters, dashboards, or mirrors should not be combined because the combination can reveal hidden values or defeat suppression/noise treatment.

This should remain smaller than a global query broker. It is a warning and review input, not a guarantee that the whole internet obeyed.

### Cache/freshness note
A note that borrows cache vocabulary without adopting HTTP as the datacube substrate.

Candidate states:

- fresh;
- stale but revalidatable;
- stale and unsafe to reuse;
- superseded;
- withdrawn;
- unknown mirror;
- source unavailable.

### Notice/license propagation note
A note that says which copyright/license/terms/attribution/disclosure-treatment notices must travel and what the publisher can honestly do after publication.

Healthy posture:

- notices travel with payload and metadata;
- a later withdrawal does not pretend every lawful prior copy can be remotely recalled;
- deprecation, supersession, and safety warnings are different from revocation;
- reuse rights are not disclosure-safety proof.

### Proof-of-copy ticket
A scoped proof response for a consumer, auditor, or mirror asking, “Is this the public copy Harbor released?”

Minimum response:

- public artifact id;
- payload digest;
- required metadata/label digest;
- release receipt digest;
- source/public cut ids;
- restatement status;
- label-preservation verdict;
- proof audience and expiry if needed;
- non-promises about raw evidence and downstream recomposition.

## Minimum proof obligations before promoting any public-copy noun
- State public artifact identity, audience, and copy format.
- State source cut, public cut, release mode, and disclosure treatment.
- State label set and how labels are embedded, sidecar-bound, or manifest-bound.
- State payload digest plus metadata/label digest or explain why proof is weaker.
- State mirror/cache freshness and restatement relation if any.
- State whether the copy may be recomposed with sibling copies.
- State notice/license propagation and non-recall posture.
- State which proof is visible to consumers versus auditors versus source owners.

## Anti-counterfeit checklist
- A correct release is not a valid copy after labels are stripped.
- A CSV without sidecar may be weaker than the table it came from.
- A BI tile that hides footnotes can turn suppression into false exactness.
- A PDF/screenshot digest proves pixels, not hidden cell-level semantics.
- A mirror can be stale even when its bytes are unchanged.
- A restatement is not a retroactive rewrite.
- Withdrawal is not internet recall.
- License permission is not privacy safety.
- Provenance is not approval.
- Proof of emitted bytes is not proof of safe recomposition.

## Promotion triggers
This vocabulary should remain process residue until repeated specimens show Harbor needs a durable artifact. Possible triggers:

- a real public aggregate copy must survive multiple export formats;
- a downstream mirror strips suppression/noise/exactness labels;
- a public restatement needs to supersede stale disclosure-treated copies;
- consumer proof requests need digest/manifest receipts without raw replay evidence;
- SlopOS promotes durable observation-export public-copy labels;
- Foundry/ViewFS promote a shared release-artifact package or label-binding substrate.

## Explicit non-decisions
This pass does not promote:

- a public data package format;
- a catalog/distribution vocabulary;
- a BI/export governance product;
- a license or rights-management engine;
- a cache-control profile;
- a provenance ontology;
- a mirror-validation service;
- a public aggregate-release API;
- a transparency log;
- a signature/verifier stack;
- or final SlopOS datacube shape.

