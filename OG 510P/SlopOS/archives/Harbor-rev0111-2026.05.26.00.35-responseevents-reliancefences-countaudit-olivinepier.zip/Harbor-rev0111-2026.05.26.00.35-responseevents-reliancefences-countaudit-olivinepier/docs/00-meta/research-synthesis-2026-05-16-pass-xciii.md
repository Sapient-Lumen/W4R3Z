# Research synthesis — pass XCIII, correction implementation and monitoring hygiene

**Revision:** `rev0093`  
**Date:** 2026-05-16  
**Question:** How should Harbor carry adopted external findings into mandated or recommended public corrections, partial implementation evidence, rechecks, reopened appeals, jurisdiction/audience splits, and stale public-surface monitoring without inventing a correction tracker, compliance automation, regulator workflow, or final SlopOS datacube shape?

## Result

Harbor should treat implementation after outside review as **observable correction work**, not as proof of repair, compliance, propagation, or world-currentness.

The useful move is to record eight small packets:

1. an adopted-correction work item receipt;
2. a mandate/recommendation/deadline scope note;
3. an implementation evidence receipt;
4. a public-copy publication receipt;
5. a partial-implementation and stale-surface note;
6. a recheck/monitoring window receipt;
7. a reopened appeal or rollback trigger note;
8. a jurisdiction/audience split note.

Together they let Harbor say: "this external finding was locally adopted; this narrow public correction is mandated by this deadline for this audience; this other correction is recommended only; these artifact digests were updated; these mirrors/snippets/render variants remain stale; this recheck observed a clean state on these surfaces only; this appeal reopened after new implementation evidence; and this jurisdiction copy differs for a named reason." They do not prove legal compliance, universal recall, downstream repair, non-use, source-owner correctness, or current truth outside their named subjects and windows.

## External lessons folded in

- CSAF is useful because its remediation model separates categories such as workaround, mitigation, vendor fix, optional patch, none available, and fix planned, and it binds them to product scope and availability dates. Harbor should borrow category/date/scope discipline, not a vulnerability advisory workflow.
- OpenVEX is useful because VEX status is explicitly product/vulnerability relationship evidence and remains minimal and SBOM-agnostic. Harbor should borrow subject-bound status humility for implementation claims, not scanner suppression or latest-wins repair.
- NIST SP 800-61 Rev. 3 is useful because response, recovery, and improvement are part of a continuing risk-management loop rather than a one-time resolved badge. Harbor should borrow monitoring and learning posture, not a cyber incident program.
- SCITT is useful because signed statements and receipts can be rejected or ignored by relying parties when trust or key state changes; publication remains different from acceptance and current reliance. Harbor should borrow receipt/currentness humility for implementation evidence.
- DataCite relation types and W3C PROV are useful because successor, prior version, revision, invalidation, and generation relations can be explicit without rewriting history. Harbor should borrow relation/invalidation language for public-copy updates and rollback notes.
- in-toto link attestations are useful because a step attestation names subject products, materials, command/name, environment, and byproducts. Harbor should borrow step-bound implementation evidence, not a supply-chain attestation requirement.
- Atlassian Statuspage/postmortem practice is useful because active incident updates, resolved state, and postmortem/learning reports are separate surfaces. Harbor should borrow surface separation for public status versus proof packet state, not a status-page product.

## SlopOS-specific interpretation

SlopOS remains design-phase, so Harbor should avoid native correction-implementation machinery.

The SlopOS lessons are:

- VEX remediation text and fixed status do not select a successor update target; implementation still needs local evidence and policy-bound adoption.
- VEX document version/supersession metadata does not become latest-wins repair or hold/resume policy; any comparison remains verifier-local.
- VEX producer identity and advisory references do not become remediation-owner, trust-root, fetch, or resolver rules.
- SBOM/VEX evidence sets do not create a native applicability closure; a correction can be implemented for one exact subject and still be unknown for another.
- Export remains policy-killable and no-secrets-in-band, so public correction copy must carry only safe summaries, not sealed replay data, suppressed cells, private reporter details, or internal regulator material.

## New watchlist handles

- `adopted_correction_work_item_receipt`
- `mandate_recommendation_deadline_note`
- `implementation_evidence_receipt`
- `public_copy_publication_receipt`
- `partial_implementation_stale_surface_note`
- `recheck_monitoring_window_receipt`
- `rollback_reopen_trigger_note`
- `jurisdiction_audience_split_note`
- `compliance_claim_refusal_note`
- `safe_post_decision_public_copy`

## Practical design rule

Prefer implementation language that preserves boundaries:

- `correction adopted`, not `truth fixed`;
- `mandated within scope`, not `universally binding`;
- `recommended`, not `required`;
- `implemented for this artifact digest`, not `world repaired`;
- `published successor copy`, not `old copy removed`;
- `recheck observed clean surfaces`, not `no stale copies exist`;
- `appeal reopened`, not `history undone`;
- `jurisdiction-specific wording`, not `contradiction resolved`;
- `compliance claim unsupported`, not `non-compliant` unless the evidence actually supports that claim.

## Followthrough result

`F088` is now complete as a pressure test. The next seam is post-implementation exception handling: missed deadlines, failed rechecks, rollback after bad corrections, contradictory implementation evidence, stale-surface recurrence after clean windows, and whether/how active warnings should re-escalate without inventing compliance automation or a universal correction ledger.
