# Datacube public correction and dispute hygiene

**Status:** design-phase review surface for `rev0086`; not an ADR, schema, public-comment platform, moderation system, ticketing system, DOI policy, annotation store, generated-explanation service, legal process, or final SlopOS datacube constitution.

## Why this exists

`rev0084` made public-copy labels cargo. `rev0085` made localized, accessible, and summarized variants evidence-bearing. `F081` applies the next pressure: after a friendly public copy escapes, people and machines will cite it, annotate it, summarize it, dispute it, translate corrections, and ask whether an older copy is still usable.

Harbor should make those post-release facts reviewable without pretending they are source truth. A correction, erratum, annotation, stale-citation warning, generated explanation, or consumer dispute can be useful residue. It should not silently rewrite the public artifact, reveal sealed evidence, erase the old copy, become a moderation platform, or decide SlopOS's final datacube shape.

## Tight stance

- **Correction anchors supersede; they do not erase.** A corrected public copy can point from old to new and mark old copy status, but Harbor should not pretend every downstream copy disappeared.
- **Errata are scoped changes, not new constitutions.** A translated erratum must preserve machine labels, affected artifact IDs, language/locale posture, and non-promises.
- **Annotations target artifacts; they do not become verdicts.** An annotation can target a bundle, cell, label, chart, paragraph, or explanation, but it needs provenance and review status before it can influence public truth.
- **Citation freshness is a witness, not endorsement.** A citation can be current, stale, superseded, dead, or unverifiable. That status does not prove the cited claim is correct.
- **Generated explanations are derived copy.** They need source artifacts, label digests, prompt/retrieval basis, model/tool posture, omitted labels, review status, and refusal lines before they can travel.
- **Disputes are process residue.** A consumer dispute can open a ticket, preserve the contested labels, and show an interim status without revealing suppressed evidence or accepting the claim.

## Correction and dispute modes under observation

| Mode | Useful shape | Counterfeit to avoid |
| --- | --- | --- |
| `correction_anchor` | Links affected public artifacts, old/new digests, status, reason class, and successor path | Rewriting old public history or claiming remote recall |
| `erratum_receipt` | Human-readable notice with affected labels, payload/label digest, language, reviewer, and status | Treating a translated correction as equivalent without label checks |
| `annotation_receipt` | Body/target/provenance/review status for comments, flags, disputes, or explanations | Letting any note on a chart become data truth |
| `stale_citation_witness` | Citation target, last-seen status, successor relation, and retrieval basis | Treating stale/dead links as either proof or deletion |
| `generated_explanation_receipt` | Source bundle, prompt/retrieval basis, model/tool, omitted-label list, and review status | Allowing a model summary to outrank labels or sealed evidence |
| `consumer_dispute_packet` | Claim, contested artifact/labels, evidence class, interim status, response, and non-disclosure lane | Revealing suppressed cells or treating complaint existence as correctness |
| `public_status_banner` | Small current-status cue: current, superseded, corrected, disputed, withdrawn, stale-copy, explanatory-only | One green/red badge that collapses correction, withdrawal, dispute, and staleness |
| `unsafe_annotation` | Quarantined or refused note with reason | Annotation flood, abuse, or unsupported claims becoming public evidence |
| `explanation_invalidation` | Mark generated copy stale when source labels/corrections change | Old explainer continuing to speak as if current |
| `dispute_resolution_note` | Close-loop record: accepted, rejected, repaired, no-change, needs sealed review, or cannot answer | Resolution language that exposes the hidden value or policy internals |

## Candidate receipt fields

These are watchlist handles, not promoted schema.

### Correction anchor

- source public artifact ID, source cut, payload digest, label digest, and variant IDs affected;
- correction class: typo, translation drift, label omission, stale cache, payload restatement, suppression/noise label error, accessibility mismatch, generated-explanation error, or withdrawn-for-new-use;
- old public status and new public status;
- successor artifact, successor cut, successor payload digest, successor label digest, and relation type when present;
- affected labels, cells, tables, chart variants, summaries, and citations;
- reason summary safe for public display;
- sealed-evidence pointer when the correction depends on evidence that cannot be disclosed;
- non-promises: no remote recall, no universal invalidation, no legal judgment, no raw-evidence disclosure.

### Erratum receipt

- source correction anchor;
- language tag and locale tag;
- translated strings and preserved machine label IDs;
- translator/reviewer posture and unresolved terms;
- whether the erratum itself is proof-grade, explanatory-only, or display-only;
- restatement, supersession, and stale-copy links.

### Annotation receipt

- target artifact, target selector or region, target digest when known, and whether target is a bundle, variant, cell, label, summary, citation, or explanation;
- body type: comment, flag, dispute, correction proposal, reviewer note, machine note, external citation, or explanation;
- body source, creator/source class, created/modified times, language, and evidence class;
- review status: unreviewed, triaged, accepted, rejected, superseded, quarantined, or informational;
- safety posture: public, operator-only, auditor-only, sealed, redacted, or refused;
- relation to correction anchors or dispute packets.

### Citation freshness witness

- citation text or identifier, URL/DOI/other target, resolver used, retrieval time, and response class;
- cited artifact/digest if the citation resolves to a Harbor public copy;
- currentness status: current, points-to-old-version, successor-known, dead-link, metadata-stale, unverifiable, or external-only;
- relation: cites, is-cited-by, is-new-version-of, is-obsoleted-by, correction-of, retraction-of, commentary-on, or unknown;
- whether the citation is evidence, attribution, background, or merely a pointer.

### Generated explanation receipt

- source public artifact IDs, source variants, payload/label digests, and correction anchors included;
- retrieval/query basis and prompt/input digest if available;
- model/tool/source class and version/posture if available;
- omitted labels and non-promises carried forward;
- whether the explanation includes sealed evidence, public-only data, or a redacted proof packet;
- review status and invalidation trigger when source copy, labels, correction anchors, or dispute status changes.

### Consumer dispute packet

- disputed artifact, variant, label, cell, summary, citation, or explanation;
- claimant/audience class without over-collecting identity;
- claim type: wrong value, wrong label, translation drift, inaccessible presentation, stale copy, recomposition risk, generated-explanation error, citation error, or cannot-understand labels;
- evidence submitted and evidence withheld;
- interim public status and safe response copy;
- resolution: accepted, rejected, corrected, superseded, sealed-review-only, cannot answer safely, or out-of-scope;
- appeal/reopen posture only if repeated specimens prove it belongs.

## Minimum proof obligations before any promotion

A candidate correction/dispute noun must show at least these before it graduates from process residue:

1. It names the affected artifact or variant and its digest/cut basis.
2. It separates source artifact status from annotation, citation, explanation, and dispute status.
3. It records whether the change supersedes, corrects, withdraws-for-new-use, restates, or merely comments.
4. It preserves machine label IDs and non-promises through any translated erratum or explanation.
5. It states public/auditor/operator/sealed evidence boundaries.
6. It records stale/dead/superseded citation status without treating link freshness as semantic truth.
7. It has a safe refusal lane for unsupported annotations, unsafe disputes, generated explanations that omit labels, and correction requests that would reveal suppressed evidence.

## Anti-counterfeit checks

- If a correction notice has no source artifact, digest, affected labels, and successor/status relation, it is an announcement, not a correction anchor.
- If a translated erratum loses machine label IDs or changes non-promises, it is invalid until repaired.
- If an annotation has no body/target/provenance/review status, it is not evidence-bearing.
- If a stale citation points at an old copy, Harbor should mark the citation stale rather than rewrite the citation silently.
- If a generated explanation omitted suppression/noise/exactness labels, it is explanatory-only at best and may need refusal.
- If a consumer dispute would require revealing suppressed cells, sealed replay evidence, or contributor identities, the response must stay class-level or auditor-only.
- If a correction depends on current policy to explain old history, it needs old source/policy/runtime locks or an explicit downgrade.
- If annotation volume or provenance looks abusive, Harbor should quarantine the annotations without changing artifact truth.

## Promotion triggers

Only consider promoting durable nouns after repeated specimens show that:

- public copies repeatedly need current-status banners across bundles, PDFs, charts, tables, and summaries;
- corrections repeatedly touch both machine labels and translated/human copies;
- stale citations repeatedly need watcher-like receipts;
- generated explanations repeatedly need invalidation and review tethers;
- consumer disputes repeatedly need safe interim statuses and sealed evidence boundaries.

Until then, keep `correction anchor`, `erratum receipt`, `annotation receipt`, `stale citation witness`, `generated explanation receipt`, and `consumer dispute packet` as process residue.

## Explicit non-decisions

This document does not choose an annotation protocol, comment system, moderation workflow, ticketing tool, DOI policy, citation resolver, generated-explanation system, AI governance standard, transparency log, legal removal process, public-feedback product, or final SlopOS datacube shape.
