# Datacube cross-cube lineage import

Revision `rev0107` adds a small executable pressure slice for cross-cube lineage import. Harbor can already keep overlapping correction epochs, derivative repair history, retention expiry, and local derivative state separate inside Harbor. F102 asks what happens when neighboring cubes contribute parts of the story: SlopOS append histories, Foundry classification pins, Steward retry attempts, Schell retention/forgetting context, ViewFS volition cards, Ward delegation warrants, and Helm repair traces.

The central rule is: **foreign lineage is imported as material, not inherited status.** A companion cube may provide evidence that helps Harbor order, label, recheck, route, or contextualize a correction epoch. It does not give Harbor currentness, repair, consent outcome, delegation authority, erasure proof, compliance, source-owner closure, or public badge authority.

## Packet families

- `foreign.material` records cube name, foreign revision, archive digest, fragment family, native status, parent-manifest presence, material digest, and the refusal to treat native status as Harbor status.
- `local.observation` records import id, observation clock, transport surface, material recheck, local root digest, foreign fragment digests, and the refusal to equate upload/callback success with adoption.
- `scope.translation` records native scope, Harbor scope, relation, scope-map digest, scope widening attempts, semantic-supersession attempts, and public-badge pressure.
- `authority.quarantine` records the import rule, allowed Harbor uses, native status strings, inherited-status flags, and non-promises for currentness, repair, consent, delegation, erasure, and compliance.
- `lineage.bridge` records the prior Harbor lineage bundle digest, foreign fragment digests, bridge digest, cross-cube clock-map posture, sealed-evidence public-summary limit, and no-majority/no-merge posture.
- `recheck.plan` records whether Harbor must recheck before any local status, whether the import is historical residue, whether repair/retention/warning evidence needs subject-digest checks, and the refusal to let a recheck plan become a passed recheck.
- `verdict.summary` admits only scoped foreign material under quarantine or refuses counterfeit status inheritance.

## Accepted posture

Harbor may admit SlopOS portal append history as an ordering witness, Foundry classification pins as label provenance, Steward retry history as attempt history, Schell retention context without a deletion/repair claim, ViewFS volition cards as consent evidence only, Ward delegation warrants as route or escalation evidence only, Helm repair traces with Harbor-side scope recheck, multi-cube conflicts as incomparable splits, sealed foreign packets by digest with public-summary limits, and stale companion revisions as historical residue.

## Refusals

Harbor rejects foreign green status inherited as Harbor status, replay availability as currentness, retention windows as repair, foreign warning state as public badge, companion revision as freshness, scope widening during import, archive digest mismatch, copied fragments without parent manifest, cross-cube total order without a clock map, majority-vote foreign policy, sealed evidence as public truth, foreign acknowledgement as consumer repair, callback success as authority, SlopOS append order as semantic supersession, Foundry classification pin as status truth, Steward retry exhaustion as compliance failure, Schell forgetting ledger as erasure proof, ViewFS volition card as consent outcome, Ward delegation warrant as authority transfer, and Helm repair trace as completed repair.

## Non-promotions

This pass does not create cross-cube status inheritance, a companion trust root, a foreign compliance workflow, a multi-cube conflict-resolution engine, a global public badge workflow, consent/delegation authority transfer, a repair-ledger import API, or a final SlopOS datacube shape.
