# SlopOS and companions evaluation — pass XCII

**Revision:** `rev0092`  
**Date:** 2026-05-16  
**Focus:** external decision return, conflicting outside findings, partial findings, mandated/recommended corrections, sealed finding expiry, appeal outcomes, local adoption boundaries, and public-copy updates after outside review.

## SlopOS pressure

SlopOS remains design-phase; that argues for scoped imported findings plus local adoption notes instead of a native authority hierarchy.

The strongest SlopOS lessons for this pass:

- **VEX is digest-bound evidence only.** SlopOS explicitly keeps VEX smaller than scanner suppression, feed semantics, latest-wins supersession, waiver, or remediation ownership. Harbor should treat source-owner and auditor findings the same way: exact evidence for a subject, not a status feed.
- **SBOM and VEX subject binding matters.** Findings that do not name exact artifact/cut/digest/label scope should not update public copy or consumer guidance.
- **Attestation results are verifier-local.** SlopOS keeps freshness, collateral, verifier result, endorsement, and reference values under explicit verifier policy. Harbor should not turn an auditor or regulator-facing return into ambient currentness or approval.
- **Credential status is not portable current validity.** SlopOS's VC status boundary is a useful mirror: imported status checks may inform one verifier at one time, but they do not become a portable approval or account-state plane. Harbor outside findings should stay similarly bounded.
- **Export is policy-killable and no-secrets-in-band.** Sealed findings can affect safe public copy only through public-summary-bound adoption notes; they must not leak raw suppressed cells, raw logs, reporter identity, or sealed replay data.

## Companion pressure

- **ViewFS:** public copy updates after review need exact copy/version/cut identities and successor relations; old visible copies may persist.
- **Helm:** appeal deadlines, extension windows, finding expiry, and recheck schedules need explicit window receipts rather than inferred timers.
- **Schell:** generated explanations and human summaries must reflect adoption boundaries and must not paraphrase sealed evidence into public proof.
- **Ward:** status/frontier discipline keeps finding-current, finding-expired, copy-current, copy-historical, and public-status-current separate.
- **Foundry:** exactness, label, and correction-horizon discipline support public-copy updates that say whether data, labels, wording, or status changed.
- **Steward:** remediation/cause-condition surfaces warn that adopted findings and correction instructions are not implementation, compliance, cause proof, or repair.
- **SlopOS:** attestation/VEX/SBOM/status boundaries reinforce exact subjects, local appraisal, and policy-gated export.

## Harbor delta

`rev0092` adds:

- `docs/00-meta/datacube-external-decision-return.md`;
- specimen flow 87 for external finding return, scope normalization, authority conflict maps, local finding adoption, correction instruction receipts, sealed finding expiry, appeal outcomes, and public-copy updates after outside review;
- external decision-return proof obligations in `docs/00-meta/datacube-proof-obligations.md`;
- refreshed lessons, inspiration harvest, source register, bibliography, ledgers, roadmap, briefing surfaces, manifest, and archive index.

## Deliberate non-promotion

This pass does not promote an external decision ingestion schema, finding-adoption API, authority precedence hierarchy, source-owner/auditor/regulator trust ranking, legal/compliance workflow, appeal court, correction-implementation tracker, sealed finding protocol, transparency-log dependency, public status-page product, VEX/CSAF profile, in-toto predicate, SCITT receipt requirement, source-owner ticketing workflow, reputation model, enforcement ladder, or final SlopOS datacube shape.
