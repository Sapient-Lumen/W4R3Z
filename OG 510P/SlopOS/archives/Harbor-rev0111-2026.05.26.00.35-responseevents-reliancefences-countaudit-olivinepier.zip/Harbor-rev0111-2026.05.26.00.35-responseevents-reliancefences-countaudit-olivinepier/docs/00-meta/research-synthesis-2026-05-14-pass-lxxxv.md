# Research synthesis — pass LXXXV, localized render variants

**Revision:** `rev0085`  
**Date:** 2026-05-14  
**Question:** How should Harbor treat translated, localized, accessible, summarized, or renderer-transformed public-copy variants without freezing a UI, i18n stack, accessibility program, or final SlopOS datacube shape?

## Result

Harbor should split the public artifact from its human-facing variants:

- the **public artifact** carries payload digest, label digest, cut, disclosure posture, restatement chain, and proof obligations;
- the **localized render variant** carries locale, translation, accessibility, summary, and renderer-transform receipts;
- the **summary** can explain but must not replace the proof-grade labeled bundle;
- the **accessible alternative** is a review surface, not a lower-integrity copy;
- the **renderer transform** must declare sort, filter, group, top-N, pagination, collation, truncation, and hidden-row behavior when those can change inference.

This is intentionally smaller than a schema. It is a pressure-test surface.

## External lessons folded in

- WCAG 2.2 frames accessibility as testable criteria and W3C advises using WCAG 2.2 where possible; Harbor should therefore require named accessibility checks for variants rather than letting “accessible” become a mood label.
- WAI complex-image guidance treats charts and graphs as complex images needing more than a short phrase; Harbor should prefer short description plus long description or source-data table for chart variants.
- USWDS data-visualization guidance warns that SVG can be difficult for screen readers and recommends an accessible data table; it also says tables alone do not provide a narrative, so Harbor should keep both data access and explanatory summary separate.
- W3C internationalization guidance emphasizes language tags and authoring-aware markup; Unicode CLDR/LDML show that locale affects date/time, numbers, units, labels, sorting, and structured locale data; ECMA-402 shows how runtime formatting APIs resolve locale-sensitive behavior. Harbor should therefore record resolved locale/render options instead of treating display strings as canonical values.
- W3C COGA and plain-language guidance reinforce that easy words, short blocks, summaries, and audience-aware copy matter; Harbor should steal the clarity discipline but keep summaries tethered to the proof-grade bundle.

## SlopOS-specific interpretation

SlopOS is still design-phase, so the useful move is not to decide how SlopOS localizes or renders data. The useful move is to preserve the boundaries SlopOS already cares about:

- export policy digest and bounded observation posture travel with outputs;
- display surfaces do not become trusted modal authority;
- accessibility/automation lanes separate observe, review, input, and injection rights;
- no ambient global indexing/query permission is smuggled in by a convenient accessible or translated variant.

## New watchlist handles

- `locale_receipt`
- `translated_label_set`
- `accessible_render_variant`
- `human_summary_tether`
- `render_transform_note`
- `renderer_drift_refusal`

These handles are not promoted. They merely name the next obvious place where human-friendly outputs can counterfeit truth.

## What stayed open

- language tag profile;
- locale-data library choice;
- translation workflow or translation memory;
- WCAG conformance target;
- charting or table component;
- renderer package/registry;
- BI/export governance product;
- public data portal;
- final SlopOS datacube shape.
