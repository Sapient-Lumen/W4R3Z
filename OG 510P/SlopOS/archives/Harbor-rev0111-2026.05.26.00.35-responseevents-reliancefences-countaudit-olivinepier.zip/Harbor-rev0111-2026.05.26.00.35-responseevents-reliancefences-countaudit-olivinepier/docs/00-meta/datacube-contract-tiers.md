# Datacube contract tiers

Purpose: keep Harbor honest that a “contracted” datacube lane may promise **different kinds of things at different strengths**.

Why this exists:
- Harbor is still in design phase, so it would be unhealthy for one promising lane to imply fully stable shape, meaning, freshness, assertions, and service posture all at once;
- modern contract systems repeatedly separate returned shape, semantic expectations, quality checks, and operational promises rather than flattening them into one word;
- Harbor therefore needs one small review surface that says **which tier is actually promised now**.

This doc does **not** choose a registry product, semantic-layer vendor, assertion engine, or machine-readable schema format.
It is a design-phase contract for promise separation only.

## Current tier labels (Phase 1)

1. **Shape tier**
   - Purpose: declare the returned lane shape that downstream users can expect.
   - Typical contents: field names, field types, nullability posture, and other returned-dataset facts.
   - This is the first tier most lanes should earn.

2. **Meaning tier**
   - Purpose: declare what one row/card/receipt means and what major value families mean.
   - Typical contents: grain contract, time policy, null semantics, enumerated statuses, and major interpretation notes.
   - A lane may be stable enough for shape while still candidate for meaning.

3. **Assertion tier**
   - Purpose: declare which checks verify the lane without redefining its row meaning.
   - Typical contents: schema checks, freshness checks, volume checks, custom SQL-style checks, or anomaly monitors.
   - Assertion results should live in a neighboring **assertion plane**, smaller than the core row contract.

4. **Service tier**
   - Purpose: declare bounded delivery expectations such as update cadence or freshness/SLA posture.
   - Typical contents: refresh targets, lateness budgets, warning thresholds, or support expectations.
   - Harbor should only publish this tier when real consumers need it.

## Tier posture rules
- A lane does **not** need to promise every tier.
- A lane may be **published** for shape while only **candidate** for meaning or assertion posture.
- If a tier is absent, Harbor should say it is absent instead of implying it.
- A later assertion or SLA addition should not silently redefine row meaning.
- A later semantic reinterpretation should not ride in under an assertion-only or service-only change.

## Assertion plane
The assertion plane is a neighboring review surface for verification logic.
It may include schema, freshness, volume, and custom checks, but it should stay visibly smaller than the lane’s core meaning.
Generated assertions for dbt, Great Expectations, monitoring systems, or warehouse-native checks remain **derived artifacts**.

## Consumer-obligation slice
A consumer-obligation slice should say what one downstream consumer actually depends on, such as:
- which lane/reference it pins to;
- which tiers it relies on;
- which exact fields or value families matter;
- which assertions or freshness promises are load-bearing; and
- whether it requires live head or frozen historical reproducibility.

This keeps Harbor from promising the whole lane when a consumer only needs a smaller slice.

## What this forbids in Phase 1
- no saying a lane is “contracted” without naming which tier(s) are actually promised;
- no letting assertion results silently redefine row meaning;
- no letting consumer folklore imply a stronger promise than the recorded slice;
- no letting generated check artifacts outrank the review surface that declared the tier.

## What this still leaves open
- exact machine-readable representation for contract-tier cards;
- exact schema for consumer-obligation slices;
- exact enforcement engine for assertion checks;
- exact mapping from tiers to views, marts, semantic models, or catalog entries.

Harbor only needs the review behavior now: **name the tier, keep verification smaller than meaning, and let consumers pin only the slice they actually use.**
