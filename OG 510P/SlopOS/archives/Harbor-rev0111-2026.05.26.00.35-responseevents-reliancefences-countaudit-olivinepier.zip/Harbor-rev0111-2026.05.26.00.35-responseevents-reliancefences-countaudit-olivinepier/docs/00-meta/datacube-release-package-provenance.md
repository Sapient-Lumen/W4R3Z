# Release-package provenance and bootstrap guards

`rev0101` adds a release-package proof slice for the boundary between the source tree and the distributed zip archive. Harbor has already learned to record checker provenance; this pass records the package process without allowing that record to become a package trust root.

## What the slice records

The `harbor-release-package-provenance-bundle-v0` fixture records:

- release-root identity: root directory name, manifest archive name, revision-field agreement, supersession, codename, and focus;
- file inventory: current source-file count, manifest count, generated release surfaces, and embedded-release-zip refusal;
- archive-index coherence: actual file list, listed file list, digests, and drift sets;
- package plan: package script digest, zip checker digest, stable ZIP timestamp policy, sorted entry order, compression, path-prefix policy, mode policy, and DS_Store filtering;
- build-environment capture: Python implementation/version, platform, zipfile basis, `SOURCE_DATE_EPOCH` observation, and `PYTHONDONTWRITEBYTECODE` observation;
- bootstrap verification: `make check`, `make package-release`, `unzip -t`, and Harbor's release-zip checker as out-of-band checks.

## What it refuses

This is deliberately not:

- a release attestation profile;
- a package trust root;
- a cryptographic archive signature;
- a reproducible-build claim across unknown builders;
- a CI status API;
- a guarantee that the archive is secure;
- a claim that the final zip digest can be embedded in the fixture that helps produce it.

The final zip digest belongs outside the source fixture: it is computed after `make package-release` emits the archive, by `tools/check_harbor_release_zip.py` and any external reviewer who wants to check the artifact.

## Counterfeit confidence cases

The bundle rejects seven counterfeit cases:

1. archive index drift;
2. embedded prior Harbor release zip inside the repo tree;
3. nondeterministic zip timestamp/order metadata;
4. stale release-root naming;
5. generated release artifact omitted from the index;
6. bootstrap self-trust, where the fixture alone is treated as the archive verifier;
7. attestation-as-security overclaim.

## Design note

Harbor uses a fixed ZIP timestamp of `1980-01-01T00:00:00Z` because Python's zip format floor makes that practical for deterministic archives. This is related to reproducible-build timestamp discipline, but Harbor does not claim general reproducibility: environment, toolchain, OS, file modes, and out-of-band packaging context are still evidence-bearing.

## Current proof posture

`F096` is closed by specimen flow 96, the fixture, the harness, the checker, and the post-package zip inspector. `F097` should next pressure artifact handoff: consumers may receive a zip, an extracted tree, a copied fixture, or a digest pasted into a message, and Harbor must distinguish those handoff forms without treating any one copy as ambient authority.
