# Research synthesis — pass XXX

This pass keeps Harbor narrow and learns one more thing from browser-mediated identity systems and deferred authorization flows: **in-flight waiting, pacing, refusal, quiet abandonment, and expiry should stay typed residue instead of collapsing into generic failure or counterfeit success.**

## Outside lessons
1. **RFC 8628 makes waiting a first-class state, not a half-failure.**  
   Device Authorization defines `authorization_pending` and `slow_down` as special cases with unique client behavior. That is an excellent Harbor pattern: a crossing can be truly in flight, and it may carry an explicit pacing hint, without yet becoming success, refusal, or durable local truth.

2. **RFC 8628 also treats expiry as a cleanly distinct ending.**  
   `expired_token` means the device authorization session has concluded, and the client may start over later but should not turn expiry into frantic blind retries. Harbor should steal that honesty: expiry is neither approval nor generic denial.

3. **OIDC and OAuth keep refusal typed instead of folkloric.**  
   `login_required`, `interaction_required`, `account_selection_required`, `consent_required`, and `access_denied` are not interchangeable. They prove that “not completed” has shape. Harbor should preserve refusal and UI-required bottoms rather than crushing them into one red failure lamp.

4. **Credential Management and FedCM distinguish quiet abandonment from explicit denial.**  
   Credential Management closes its non-modal dialog on an outside gesture without resolving or rejecting the promise, and FedCM separately models user-closed dialogs, failed fetches, and explicit continue-or-stop prompts. Harbor should learn that some crossings simply go cold or get abandoned without earning a durable “denied” verdict.

5. **WebAuthn keeps cancellation and abort smaller than identity truth.**  
   WebAuthn uses `AbortError` for explicit abort-signal interruption and `NotAllowedError` as a catch-all that includes common cases like user cancellation or lack of consent. This is a useful boundary lesson: stop reasons matter, but they still should not overgrow into portable session/account truth.

## Resulting Harbor move
Do not decide yet whether the durable nouns are exactly `pending rung`, `pace hint`, `refusal rail`, and `expiry honesty`, or whether later pressure compresses some of them behind a smaller pending/outcome family.
For now, keep them alive as specimen nouns and demand that they improve:
- one RFC 8628-style device authorization specimen where pending, backoff, and expiry stay visibly distinct;
- one OIDC silent-or-forced-UI specimen where typed bottom-out remains more precise than generic failure;
- and one browser-mediated chooser specimen where quiet abandonment or dialog close does not counterfeit explicit denial.

## Fresh ideas worth stealing
- **pending rung** — explicit “still in flight” posture that is smaller than both success and denial.
- **pace hint** — optional issuer/provider guidance about when to try again instead of guessing from silence.
- **refusal rail** — typed bottom-out for user/provider/local refusal that stays smaller than durable trust or account/session collapse.
- **expiry honesty** — standing rule that timeout, concluded session, or abandoned turn remain distinct from approval and distinct from one universal denial story.
- **abandonment is real** — a first-class anti-folklore rule.
