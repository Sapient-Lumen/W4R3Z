# Datacube post-import local derivation drift

A verified handoff is not the end of Harbor's boundary problem.  It is the point at which local derivatives start multiplying: annotations, generated summaries, extracted subsets, local search indexes, re-exported archives, cached explanations, cross-device synced copies, stale working copies, and consumer-side repair patches.

This surface records those local derivatives without letting them inherit source identity, source currentness, public-copy status, upstream repair, search truth, or compliance.

## Minimal local derivation record

```text
import context
  source revision/archive
  handoff bundle digest
  consumer verification basis
  import scope

derivative identity
  derivative kind/id/digest
  source material digest
  target digest
  parent context
  author scope

transform scope
  transform digest
  lossy/lossless posture
  label digest carry-forward
  non-promise carry-forward
  allowed statement
  forbidden promotions

freshness and invalidation
  source revision basis
  source changed since derivation
  invalidation trigger
  expiry/recheck window
  currentness basis

consumer copy state
  sync status
  conflict policy
  stale posture
  local patch posture
  acknowledgement posture
```

## Refusals

Harbor refuses these promotions:

- annotation as source status rewrite;
- generated summary as source-equivalent proof;
- extracted subset as label-preserving when treatment labels vanished;
- local search index result as truth;
- filesystem, upload, or index timestamp as currentness;
- re-exported filename as parent identity;
- cache hit as freshness after source revision drift;
- sync success as verification;
- stale consumer copy as current;
- derivative digest as original material digest;
- annotation author as source authority;
- latest-wins sync conflict as reconciliation;
- generated table without label digest as safe public copy;
- consumer local patch as upstream repair.

## Borrowed pressure

- PROV derivation is useful because a generated entity may be affected by a used entity, but derivation is subtle and not automatically implied by mere use.
- Web Annotation is useful because body and target are separate resources and annotation provenance need not be true for the body or target.
- RO-Crate is useful because root data entities, contextual entities, and provenance can travel together without turning a crate into semantic truth.
- BagIt and OCI-style digest/locator separation remain useful because content fixity and location/reference are different claims.

Harbor keeps all of this smaller than a local derivation receipt API, consumer cache API, sync-state ledger, annotation authority model, search truth plane, repair attestation profile, or final SlopOS datacube shape.
