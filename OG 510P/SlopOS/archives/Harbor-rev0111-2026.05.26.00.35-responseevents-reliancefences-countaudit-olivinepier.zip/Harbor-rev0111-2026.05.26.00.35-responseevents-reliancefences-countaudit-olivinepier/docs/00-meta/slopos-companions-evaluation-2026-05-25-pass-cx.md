# SlopOS companions evaluation — 2026-05-25 pass CX

## Explanation after overlay propagation

F104 got overlays onto public and local surfaces.  F105 asks what a person,
operator, or generated assistant should see when those overlays are explained.
The companion cubes remain pressure sources only; their labels, retries,
retention context, volition cards, delegation warrants, append history, and
repair traces cannot become Harbor badges through wording.

## Companion-specific pressure

- **SlopOS** can explain portal-net append or callback history, but the
  explanation must not convert append order into semantic repair or user
  understanding.
- **Foundry** can explain classification pins and crosswalk witnesses, but a
  label explanation is not status truth.
- **Steward** can explain retry attempts and pushback budgets, but exhausted
  retries are not fault or compliance findings.
- **Schell** can explain retention and forgetting context, but retention or
  expiry wording must not imply erasure proof.
- **ViewFS** can explain volition/consent display posture, but display of a
  volition card is not consent outcome or comprehension.
- **Ward** can explain delegation warrants and escalation handoffs, but public
  wording must not transfer authority.
- **Helm** can explain repair traces and intervention attempts, but a trace
  explanation is not completed repair.

## Next pressure

After F105, Harbor should model user response events: inspect, recheck request,
export, dismiss, appeal, share, or acknowledge.  Those events are useful but
must stay weaker than comprehension, consent, reliance, repair, legal posture,
or compliance status.
