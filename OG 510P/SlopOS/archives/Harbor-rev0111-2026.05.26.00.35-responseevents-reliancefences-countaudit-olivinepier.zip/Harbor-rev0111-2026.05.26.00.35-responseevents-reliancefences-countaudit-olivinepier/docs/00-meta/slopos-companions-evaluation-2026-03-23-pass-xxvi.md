# SlopOS / companions evaluation — pass XXVI

This pass re-checks Harbor against the uploaded cube ecology and keeps the architecture embryonic.

## What the current cubes still teach
- **SlopOS** already pins the most important anti-regrowth rule in `mcp-step-up-auth-import-boundary-v0.md`: imported `insufficient_user_authentication`, `acr_values`, and `max_age` stay provider-local reauthentication guidance, while imported `acr`, `auth_time`, and `amr` stay provider-local verifier context. That is exactly the posture Harbor needs if it wants to metabolize recency pressure without minting a portable recent-login oracle.
- **Steward** helps on the UX side. Its fresh-intent and freshness-decay posture insist that fresh, consumed, expired, missing, wrong-context, stale, and last-known are not synonyms. Harbor should steal that honesty for auth-recency explanation instead of leaving products to improvise sticky “recently authenticated” badges.
- **ViewFS** keeps observed bases, writable sessions, commit preconditions, and winning commits separate. Harbor can borrow that pattern: requested recentness, returned auth-event time, and current freshness verdict should be visibly separate rather than collapsed into one session bit.
- **Helm** keeps shell-owned chooser/session posture distinct from settled state. Harbor should analogize from that and avoid turning current browser/provider reauth posture into one frozen account/session-freshness verdict.
- **Ward** keeps continuous signals and attenuation pressure smaller than durable truth. That same humility belongs here once a returned `auth_time` starts aging.

## Harbor consequence
Harbor should keep recency/freshness nouns provisional.
The right near-term move is small:
- add one specimen around `recency ask`, `auth_time receipt`, `freshness verdict`, and decay honesty;
- keep durable assurance tiers, durable recent-login truth, and generic session-freshness registries outside Harbor-owned vocabulary;
- and keep returned authentication timestamps visibly smaller than present-tense “the user is freshly authenticated now” truth.

## Still-not-yet decisions
- Whether `auth_time receipt` deserves its own card or remains a typed aftermath annotation on route/adoption surfaces.
- Whether `freshness verdict` is distinct from broader risk/adoption surfaces or just one time-sensitive subtype.
- Whether Harbor ever needs a first-class recent-login object at all, or whether that should remain an anti-goal while layers keep differing in what they can attest and for how long.
