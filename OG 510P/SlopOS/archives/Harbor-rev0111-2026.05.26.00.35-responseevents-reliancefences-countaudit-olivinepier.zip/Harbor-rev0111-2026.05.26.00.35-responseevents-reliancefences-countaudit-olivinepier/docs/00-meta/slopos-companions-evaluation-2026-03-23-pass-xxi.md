# SlopOS / companions evaluation — pass XXI

This pass re-checks Harbor against the uploaded cube ecology and keeps the architecture embryonic.

## What the current cubes still teach
- **SlopOS** keeps discovery, exact-match validation, browser-session state, pending-auth residue, and account-linking pressure provider-local instead of making them portable truths.
- **Helm** benefits because user-visible route review still needs truthful fallback and exclusion stories.
- **Schell** benefits because helper/provider turns often succeed technically while local adoption still narrows or vetoes the consequence.
- **ViewFS** benefits because route refinement can change *where* a crossing lands without changing whether import/materialize/grant remain separate aftermaths.
- **Steward** benefits because a truthful fallback or narrowed route still deserves typed followthrough instead of vanishing into a generic failure bit.
- **Ward** should stay distinct: a stronger route or continuity signal is still weaker than durable trust.

## Harbor consequence
Harbor should keep route-ceiling and refinement nouns provisional.
The right near-term move is small:
- add one specimen around predeclared scope, late narrowing, and honest fallback;
- keep device-bound continuity as inspiration rather than a frozen Harbor family;
- refuse to turn SlopOS design-phase auth/session/discovery surfaces into Harbor-owned durable truth.

## Still-not-yet decisions
- Whether `route ceiling` belongs inside the `route set` or beside it as a separate card.
- Whether `exclusion rail` should be its own durable noun or just one mode of refinement.
- Whether any remembered same-device / same-key continuity residue belongs in Harbor at all, or remains a neighbor hint only.
