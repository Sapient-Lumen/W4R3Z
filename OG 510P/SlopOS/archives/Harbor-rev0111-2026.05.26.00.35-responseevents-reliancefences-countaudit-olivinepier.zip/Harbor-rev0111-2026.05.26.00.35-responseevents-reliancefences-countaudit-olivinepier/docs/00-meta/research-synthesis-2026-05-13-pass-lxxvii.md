
# Research synthesis — 2026-05-13 pass LXXVII

Question: after adding the option-reservations watchlist, what deeper proof discipline should Harbor add so SlopOS's design-phase datacube can collect excellent ideas without letting helper artifacts counterfeit semantic truth?

## Result of this pass
The strongest next move is not a new warehouse-shaped schema. It is a **promotion-obligation surface** plus a harder measurement specimen.

Harbor already has candidate seams for grain, time, presence, evidence, aggregation, conformance, exactness, history, measurement, and option reservations. The danger now is not that Harbor lacks nouns; it is that a useful helper — unit suffix, percent display, FX conversion, pivot output, view definition, row-lineage field, schema alias, or metadata facet — will look mature enough to promote without proof.

## External lessons folded into this pass
1. **Units are part of the nameable contract, not garnish.** Prometheus warns that missing units and type suffixes can cause collisions; OpenTelemetry metric conventions push designers to check existing semantic convention prior art before inventing names. Harbor should keep source unit, canonical machine unit, and display unit as separate proof cuts until repeated specimens prove a stronger unit regime.

2. **Currency codes are identifiers, but conversion is a dated assertion.** ISO 4217-style codes are necessary for money lanes, but an exchange result is not the same kind of truth as a millisecond-to-second scale conversion. A converted comparison view needs original currency, target currency, rate source, rate version, rate as-of time, application time, rounding/minor-unit posture, and restatement behavior.

3. **Logical annotations do not replace semantic proof.** Parquet logical types, Arrow validity channels, and Avro aliases/defaults are all useful bridges between physical bytes and reader expectations. They do not, by themselves, prove quantity kind, absence cause, business meaning, or safe rewrite equivalence.

4. **Query affordances can generate impressive-looking tables without proving rollup rights.** DuckDB and BigQuery support pivot/cube/grouping-set shapes that are excellent review outputs. Harbor should use them as specimens and counterfeit detectors, not as proof that a lane is additive, conformed, exact, current, or grain-correct.

5. **Semantic layers and versioned models are consumer APIs.** dbt's model-version posture and Looker's join-fanout discipline reinforce that downstream-facing models need stable contracts, join posture, and deprecation/overlap stories. Harbor should treat any semantic front door as a derived artifact until its proof packet names inputs, cuts, fanout fences, freshness basis, refusal cases, and version expectations.

6. **Sidecars and lineage are optional evidence, not base meaning.** Iceberg row lineage, Puffin statistics blobs, and OpenLineage facets are useful examples of metadata that can help audit, plan, trace, or extend. The lesson for Harbor is sidecar humility: optional metadata may refine evidence, but absence must be survivable and presence must not silently upgrade the base contract.

7. **Assertion compilers are not constitutions.** DataHub-style open assertions and OpenTelemetry-style schema transforms are valuable because they can compile or translate reviewed intent across tools. Harbor should reserve compiler targets and transform receipts, but still require separate proof of what the assertion observed, what consequence it carries, and what it cannot prove.

## New process shape
This pass adds `docs/00-meta/datacube-proof-obligations.md`. It is deliberately a gate/checklist, not an ADR and not a schema. Its job is to answer one question before any datacube term graduates: **what proof packet would make this noun honest?**

The proof surface now requires at least these cuts before promotion:
- row/grain meaning;
- time/as-of/knowledge basis;
- presence/absence/default posture;
- measurement/unit/display/rate basis;
- aggregation/fanout/additivity posture;
- conformance/identity/mapping posture;
- exactness/estimate/sketch posture;
- history/replay/restatement posture;
- contract/evidence/waiver posture;
- derived-artifact invalidation posture;
- sidecar optionality posture; and
- explicit anti-counterfeit notes for each borrowed helper.

## Measurement proof cut selected for specimen
Pass LXXVII completes the single `next` followthrough item by adding specimen flow 72. The specimen includes:
- mixed source-native duration inputs in milliseconds and seconds;
- a unity-stored utilization lane rendered as a percent;
- original-currency money values with a converted comparison view;
- a late FX-rate restatement that invalidates and reissues a derived view without rewriting source truth;
- proof cuts for machine basis, display honesty, rate basis, and knowledge/restatement basis; and
- explicit failures for `unit="mixed"`, percent double-scaling, converted-money-as-source-truth, pivot NULL placeholders, and lineages/sidecars that pretend to authorize meaning.

## Still not decided
- one conversion service or UCUM enforcement product;
- one FX source, treasury policy, or rounding governance stack;
- one warehouse, lakehouse, query engine, BI layer, or metric API;
- one row-lineage, sidecar, facet, or statistics registry;
- one assertion engine or schema-transform grammar; or
- whether proof obligations become first-class Harbor cards rather than process residue.

The deeper lesson is: **promotion requires a proof packet. A pretty scalar, a query output, a view, a sidecar, or a schema-compatible read is not enough.**
