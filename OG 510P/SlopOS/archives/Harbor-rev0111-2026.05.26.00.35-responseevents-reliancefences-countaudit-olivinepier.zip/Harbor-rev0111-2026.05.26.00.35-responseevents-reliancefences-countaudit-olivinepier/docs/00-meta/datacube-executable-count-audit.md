# Datacube executable-count audit

Rev0111 refactors the executable proof-slice count so landing-page checks derive from `tools/harbor_executable_surface_registry.py` instead of a spelled-out hand count.

The prior landing checks were useful but brittle: they required a literal phrase such as "sixteen executable proof slices" in `README.md`, `START_HERE.md`, and `docs/README.md`.  That made the count itself another place to update by hand whenever a proof slice was added.

The refactor adds:

- `EXECUTABLE_SURFACE_COUNT` in `tools/harbor_executable_surface_registry.py`;
- `EXECUTABLE_SURFACE_COUNT_PHRASE`, currently `17 executable proof slices`;
- registry-backed checks in `tools/check_harbor_executable_surface_registry.py`;
- registry-backed landing-page checks in `tools/check_harbor_briefing_focus.py`.

This is maintenance hygiene only.  It is not a conformance registry, checker trust root, CI status API, certification badge, or promotion gate.  It does not prove the proof slices are complete.  It only prevents a visible briefing surface from overstating or understating the number of registered executable slices.
