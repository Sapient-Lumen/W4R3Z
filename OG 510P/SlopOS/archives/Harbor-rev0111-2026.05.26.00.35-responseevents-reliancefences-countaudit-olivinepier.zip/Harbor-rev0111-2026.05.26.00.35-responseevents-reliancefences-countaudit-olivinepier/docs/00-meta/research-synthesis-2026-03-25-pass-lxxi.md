# Research synthesis — 2026-03-25 pass LXXI

Question: while SlopOS and Harbor are both still in design phase, what is the smallest honest way to support cross-lane drill-across and shared slicing **without** prematurely freezing one canonical enterprise entity model?

## What current sources say
1. **Conformance is about shared attributes and shared meaning, not just shared names.**
   Kimball’s conformed-dimensions guidance says separate dimension tables conform when the shared attributes have the same column names and domain contents, and that those conformed attributes let results from separate fact tables align on the same rows in drill-across reports. Harbor should steal the strictness: conformance is stronger than “these two tables both have a customer-ish column.”

2. **Incremental delivery is compatible with shared dimensions, but the shared surface must stay explicit.**
   Kimball’s bus architecture says enterprise integration can still be incremental because the architecture focuses on core business processes and associated conformed dimensions, letting teams deliver one process at a time without abandoning future alignment. Harbor should steal the habit, not the full program: use a small conformance surface so early lanes can align later without pretending the whole enterprise model is already settled.

3. **Many-to-many bridges need explicit time discipline.**
   Kimball’s dimensional-techniques PDF says multivalued bridge tables may need Type 2 dimensions plus effective and expiration timestamps, and that queries must constrain the bridge to a specific moment in time to produce a consistent snapshot. Harbor should steal that exact humility: a bridge witness should say what kind of mapping it is and which time axis it needs before anyone trusts a drill-across result.

4. **A smaller shared slice can still be the right shared surface.**
   Kimball’s shrunken-rollup guidance says a shrunken dimension is a subset of rows and/or columns of a base dimension, and that these smaller conformed dimensions are required for aggregate fact tables or naturally higher-grain business processes. Harbor should steal the idea of shrunken conformance slices: sometimes the honest shared surface is a smaller subset, not a giant universal dimension.

5. **Named entities are lighter than one canonical table.**
   dbt’s current semantic-model docs describe entities as join keys, allow entity names to be non-unique across models, and use those named entities to perform joins. MetricFlow’s join docs then use entity types to choose join strategies and explicitly disallow fan-out or chasm-prone combinations. Harbor should steal the shape, not the product: named join keys and explicit allowed/disallowed alignments are a lighter design-phase move than minting one giant canonical dimension too early.

6. **Join relationship and key uniqueness must stay explicit.**
   Looker’s relationship docs and best-practices guidance say join relationships must be declared correctly, primary-key uniqueness matters, and fanout can produce wrong measures or suppress measures entirely. Harbor should steal that lesson for conformance too: a “shared dimension” claim needs declared relationship posture and key discipline, not just convenience SQL.

## Harbor consequence
Harbor should add one modest datacube/process seam now:
- **conformance-lane card** — compact declaration of whether a lane is local-only, a conformed subset, a bridged alignment, or an identity-shadow convenience surface;
- **bridge witness** — compact note that states mapping multiplicity, effective-time basis, unresolved cases, and whether the bridge is exact or weaker; and
- **identity shadow note** — compact reminder that a provisional canonical-looking identifier may still be analytically useful while remaining smaller than final entity truth.

## What Harbor still should not decide yet
- exact canonical enterprise entity registry or MDM stack;
- exact machine-readable bus matrix shared with sibling cubes;
- exact bridge-engine/runtime or automatic semantic-join system;
- exact universal policy for when every conformance claim must be machine-validated.

The design-phase lesson is enough for now: **admit shared slicing incrementally, keep every bridge explicit, and treat canonical-looking IDs as suspect until proven durable.**
