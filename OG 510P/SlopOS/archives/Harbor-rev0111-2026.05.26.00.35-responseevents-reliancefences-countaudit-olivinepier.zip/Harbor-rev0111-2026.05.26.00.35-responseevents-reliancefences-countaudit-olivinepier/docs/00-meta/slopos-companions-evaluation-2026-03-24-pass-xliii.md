# SlopOS / companions evaluation — pass XLIII

This pass re-checks Harbor against the uploaded cube ecology and chooses one more exact-context specimen over any early family bloom.

## What the current cubes still teach
- **SlopOS** remains the clearest brake. Its auth-result export boundary keeps local sign-in distinct from portable authorization-code, token-set, and callback-result semantics, and its MCP exact-match auth-binding boundary says `resource` / `issuer` / `iss` equality checks remain provider-local validation rather than portable issuer/account/resource truth. That strongly supports Harbor keeping context/binding residue smaller than durable account or adoption truth.
- **SlopOS** also keeps teaching the right process move: narrow seams can stay small, but they must say why they are still small and when promotion is due. Harbor’s embryo-promotion contract continues to fit that discipline.
- **Ward** contributes the right escalation instinct: a browse-grade or earlier weaker read can orient the operator, but higher-risk consequence must cross a stronger revalidation fence. Harbor should treat callback completion the same way when connection context is even slightly ambiguous.
- **Helm** keeps reinforcing that compact chrome can surface exact basis and drift without becoming authority by itself. That is exactly the right temperament for a future connection-context witness.
- **Foundry** keeps current-actor primacy honest: audit trails and prior actor paths are useful, but they do not outrank current authority. Harbor should apply the same lesson to prior remembered account or provider cues when a new finish arrives.

## Harbor consequence
Harbor should keep this move modest:
- add one specimen around exact connection context, finish-hash verification, and foreign-finish veto;
- mark the displayed-party / return-parcel pressure test done;
- queue chooser-cleanup / display-refresh signals as inspiration only;
- and leave any future registry of connector contexts, finish-proof schemas, or chooser-cleanup semantics outside Harbor for now.

## Still-not-yet decisions
- Whether **connection-context witness** deserves its own Harbor family, or should remain only an annotation on existing lane / basis / aftermath surfaces.
- Whether **finish-hash witness** belongs in Harbor at all, or should remain an implementation-local verifier detail that Harbor only names at the edge.
- Whether **cleanup pulse** belongs in Harbor, or should stay a neighboring chooser/authenticator idea until more reset/reconciliation specimens accumulate.
