# Research synthesis — pass XXIII

This pass keeps Harbor narrow and learns one more thing from browser-mediated identity work: **UI mediation posture is a real fact, but it is still smaller than success, session truth, or durable local adoption**.

## Outside lessons
1. **Credential mediation teaches that “silent”, “conditional”, and “required” are materially different asks.**  
   A no-UI probe, a chooser-light/discoverable flow, and a hard reauthentication request are not interchangeable. Harbor should resist compressing them into one generic “auth happened” or “needs UI” story.

2. **OpenID Connect keeps the silent-floor honest.**  
   `prompt=none` means no interaction is allowed, and when silent completion is impossible the truthful result is one of the interaction-required families (`interaction_required`, `login_required`, `account_selection_required`, `consent_required`) rather than counterfeit continuity.

3. **FedCM and modern browser identity flows separate remembered relation from whether the browser may proceed silently right now.**  
   The browser can remember that an RP/IdP/account relation previously existed and may auto-reauth in bounded cases, but it still owns whether mediation is silent, optional, or interaction-bearing at this moment.

4. **WebAuthn/passkey flows reinforce that chooser-light is still mediated.**  
   Conditional mediation or discoverable credential UX may feel ambient, but user agents still protect privacy by preventing silent credential revelation or account identification.

5. **Disconnect and logout keep continuity defeasible.**  
   The same browser can remember a relation in one moment and lose it in the next, so Harbor should preserve typed mismatch or interaction-floor aftermath instead of carrying forward smoothness by inertia.

## Resulting Harbor move
Do not decide yet whether the durable nouns are exactly `mediation rung`, `silent probe`, `conditional chooser`, and `interaction floor`, or whether later pressure will compress them into a smaller UI-mediation family.
For now, keep them alive as specimen nouns and demand that they improve:
- one FedCM-style same-browser auto-reauth specimen,
- one WebAuthn/passkey conditional-mediation specimen,
- and one OIDC `prompt=none` specimen that bottoms out honestly at typed interaction-required aftermath.

## Fresh ideas worth stealing
- **mediation rung** — bounded statement of which UI posture a crossing requested.
- **silent probe** — no-UI attempt that may return null/typed floor instead of fake success.
- **conditional chooser** — chooser-light but still user-agent-mediated branch that stays smaller than account truth.
- **interaction floor** — typed bottom-out such as login, chooser, consent, or reauth required.
- **disconnect-aware continuity** — standing rule that remembered relations may disappear and must not be silently promoted across that boundary.
