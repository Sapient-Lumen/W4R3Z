# Datacube measurement semantics

Harbor is still in design phase, so this surface is intentionally small.

The goal is not to pick one unit-registry product, one FX stack, or one universal conversion engine.
The goal is simply to stop scalar-looking lanes from counterfeiting one shared measurement truth before Harbor has earned that confidence.

## The design problem
A single decimal-looking field can hide several distinct facts:
- **quantity kind** — duration, bytes, count, ratio/utilization, money, or another measured family;
- **coded machine unit** — the computable unit/code that Harbor is relying on for comparison or conversion;
- **display/render unit** — the human-facing suffix/symbol or rescaled presentation form; and
- **conversion basis** — for converted or normalized values, the rule/rate/as-of posture that produced the displayed scalar.

If Harbor flattens those into one number plus one pretty suffix, later consumers will infer more certainty than the lane really carries.

## Small Harbor nouns worth keeping
### 1) Measurement-kind card
A compact declaration of what kind of quantity a lane carries.
Examples:
- duration
- bytes
- count
- ratio/utilization
- money
- other measured quantity family (explicitly named)

This is smaller than a semantic front door.
It is only enough to stop unlike scalar families from silently pretending they are the same kind of thing.

### 2) Canonical-unit note
A compact note that says what coded unit Harbor is treating as the machine-comparable basis.
Examples:
- duration lane stored or normalized as `s`
- size lane stored or normalized as `By`
- count lane stored as unity/count-style code
- money lane carried in original ISO 4217 code

The canonical-unit note may say either:
- Harbor already normalized the lane to one coded unit, or
- Harbor preserved source-native coded units and requires an explicit downstream conversion step.

Either is acceptable in design phase as long as the lane does not counterfeit sameness.

### 3) Display-unit note
A compact reminder that human-friendly rendering is a different surface from machine-comparable coded basis.
Examples:
- show short durations in `ms`, long durations in `s`
- render ratios as percentages while the stored semantic remains unity `1`
- render money with locale-aware symbol/formatting while preserving explicit ISO 4217 code underneath

Display-unit notes are useful because they keep review surfaces honest about what is formatting versus what is semantic meaning.

### 4) Currency-rate witness
A compact note for any lane or view that converts money across currencies or denominations.
It should carry at least:
- source currency
- target currency
- rate source / authority
- as-of basis and time axis
- rounding / minor-unit posture
- whether the converted result is source truth, derived convenience, or later restatement

This is the most important anti-counterfeit rule in the seam:
**money conversion is weaker than physical-unit conversion because exchange rates vary and historic denominations exist.**

## Small rules Harbor should learn
1. **One lane, one quantity family.**
   A lane should not mix duration and size, ratio and percent-scaled count, or original money and converted money without saying so explicitly.

2. **Coded unit beats pretty suffix.**
   Human render strings help readers; they should not outrank the coded basis used for machine comparison.

3. **Unity beats percent for stored ratio semantics.**
   If Harbor stores a utilization/rate/fraction in unity form and renders a percent later, that should stay explicit.

4. **Original money beats converted money.**
   Converted comparisons are often useful, but they should remain visibly smaller than original-denomination truth unless a narrower contract explicitly promotes them.

5. **Minor-unit and redenomination drift are real.**
   Currency history and decimal posture can change; Harbor should not act as if all money is timeless fixed-scale physics.

## What not to decide yet
- no universal Harbor conversion service;
- no mandatory house base unit for every quantity family;
- no global treasury or FX governance stack;
- no assumption that display-unit choices belong in the canonical row contract;
- no assumption that every measured lane belongs behind one mature semantic front door already.

The seam is intentionally smaller than all of those decisions.
It only asks Harbor to preserve quantity kind, coded unit, display render, and rate basis as separate truths until later specimens prove a stronger integration is actually worth it.


## Pass LXXVII hardening — proof cuts
The specimen-flow-72 pressure test adds four named cuts that any future measurement promotion must keep separate:

1. **Source-unit cut:** preserve the source-native unit/currency beside the source value. Mixed source units can exist in a source lane only when each row says which unit it used.
2. **Canonical-machine-unit cut:** choose a computable comparison basis only for a lane or derived view that explicitly needs one. `unit="mixed"` is not a canonical unit.
3. **Display-render cut:** carry human-facing scale/suffix/symbol separately from storage. Unity-stored ratios may render as percents, but percent display must not rewrite storage semantics.
4. **Conversion/rate cut:** separate scale conversion, semantic-unit conversion, variable-rate money conversion, and presentation-only rescaling. Variable-rate conversion always carries source currency, target currency, rate source/version, rate as-of, applied-at, rounding/minor-unit posture, and restatement behavior.

### New anti-counterfeit rule
Source truth outranks derived convenience. A converted money view, normalized duration view, or percent-rendered dashboard cell can be useful, but it remains a derived or display artifact unless a narrower contract explicitly promotes it and satisfies the datacube proof obligations.
