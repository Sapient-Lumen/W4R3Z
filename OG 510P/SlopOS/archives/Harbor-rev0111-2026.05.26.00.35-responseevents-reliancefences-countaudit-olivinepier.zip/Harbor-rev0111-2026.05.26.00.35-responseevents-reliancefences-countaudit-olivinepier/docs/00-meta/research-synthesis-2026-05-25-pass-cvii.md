# Research synthesis — 2026-05-25 pass CVII

## Frame

Pass CVII studies cross-cube lineage import: the moment where one cube's useful evidence tries to arrive as another cube's status. The useful outside pressure is provenance interchange, external-document references, supply-chain attestation, and research-object packaging. The lesson is not to adopt any one interchange format. The lesson is to keep imported material, parent context, local scope translation, authority quarantine, and local recheck visibly separate.

## Load-bearing observations

- W3C PROV bundles are named sets of provenance descriptions and are themselves entities, allowing provenance-of-provenance. Harbor should steal the bundle boundary: an imported companion fragment can have provenance without becoming Harbor truth.
- SPDX external document references let one document relate to elements in another document. Harbor should steal the external-reference humility: foreign identifiers and relationships need document context before Harbor can use them.
- In-toto/SLSA-style supply-chain evidence separates materials, products, links, provenance, and expectations. Harbor should steal the expectation boundary: attestation material is useful only after local policy/scope checks.
- RO-Crate distinguishes data entities from contextual entities. Harbor should steal that distinction: a companion note about consent, delegation, retention, or classification may be context, not the data entity or Harbor status.

## F102 conclusions

Harbor needs import-quarantine packets with cube id, foreign revision, archive digest, fragment family, native status, parent manifest presence, local observation clock, scope translation, authority quarantine, cross-cube bridge digest, and local recheck plan. The packet must reject foreign green status, replay availability, retention windows, warning state, companion revision, scope widening, missing parent context, cross-cube total ordering, majority voting, sealed-evidence truth, acknowledgement-as-repair, callback authority, and companion-specific status overclaims.

## Non-adoptions

Do not import PROV, SPDX, in-toto, SLSA, RO-Crate, or any companion cube as Harbor schema. The lesson is narrower: foreign lineage is material with context, not inherited status.
