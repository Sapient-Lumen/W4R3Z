# Datacube user response-event capture

A user response-event bundle is not a consent system, comprehension detector, reliance ledger, repair proof, legal workflow, compliance workflow, analytics product, or identity registry.  It is a scoped record that a response affordance near a Harbor explanation was activated and that the activation stayed smaller than the meanings people may be tempted to infer from it.

F105 made explanation cards explicit.  F106 records what happens after those explanations are displayed:

- inspect/open evidence;
- request recheck;
- export a scope note;
- dismiss a card;
- start an appeal;
- copy/share a link;
- acknowledge receipt;
- focus/scroll a status message;
- ask for sealed detail;
- request an agent-generated follow-up;
- opt out of notices;
- batch-acknowledge named recipients;
- schedule an automated retry from a machine reason code.

Each event must carry its parent explanation digest, event kind, capture surface, guard language, follow-up state, privacy/retention posture, history link, and a verdict.  Missing parent explanation digest is a hard refusal, because otherwise the response floats free of the wording and scope it supposedly answers.

## Required cuts

### Explanation input

The event begins with a parent F105 explanation bundle digest, parent explanation case, surface kind, explanation digest, clock, stale-explanation flag, and non-promises.  It must not be created from a UI label alone.

### Response event

The event records an action kind and minimal actor reference.  The actor reference is pseudonymous by default.  A direct person identifier, agent-generated acknowledgement, transport-only delivery receipt, focus event, or scroll event may be recorded as evidence, but none may become comprehension, consent, reliance, or user action by itself.

### Capture context

The capture context states the surface and affordance used.  It also states whether scope maps were carried, whether localization widened the scope, whether undo/escape exists for final-looking actions, and whether delivery/focus/scroll were promoted unsafely.

### Interpretation guard

The guard carries negative meaning explicitly: response is not comprehension, acknowledgement is not consent, export is not reliance proof, request is not repair, and response trace is not compliance.  Accepted events have these as non-promises.  Rejected events show exactly which collapse was attempted.

### Follow-up action

Follow-up is narrower than outcome.  A recheck request is pending until a recheck result is observed.  An appeal start is not appeal success.  A share link is not all-recipient read.  An automated retry is not repair.

### Privacy and retention

Response traces are easy to turn into surveillance.  Harbor therefore records minimization posture, pseudonymous actor reference, retention window, raw-identifier presence, analytics re-identification risk, and whether a counterfeit consent record was attempted.

### History trace

Response events stay linked to the parent explanation and overlay history.  A stale response to a stale explanation is preserved as history, not currentness.

## Counterfeits blocked

- click or focus as comprehension;
- acknowledgement as consent;
- export as third-party reliance;
- dismiss as acceptance;
- appeal submit as repair;
- share link as all-recipient read;
- acknowledgement as compliance;
- scroll depth as understanding;
- localized acknowledgement as scope widening;
- sealed-detail request as permission;
- recheck request as passed recheck;
- notification delivery as user action;
- response without parent explanation digest;
- aggregate metrics that identify a person;
- stale explanation response as currentness;
- agent-generated acknowledgement as user consent;
- final action without undo/escape;
- unbounded retention by default;
- problem-detail retry as repair.

## Non-promotion

F106 deliberately does not promote a consent receipt format, reliance ledger, analytics product, identity registry, UI telemetry API, notification-read guarantee, accessibility conformance claim, legal/compliance workflow, or final SlopOS datacube shape.
