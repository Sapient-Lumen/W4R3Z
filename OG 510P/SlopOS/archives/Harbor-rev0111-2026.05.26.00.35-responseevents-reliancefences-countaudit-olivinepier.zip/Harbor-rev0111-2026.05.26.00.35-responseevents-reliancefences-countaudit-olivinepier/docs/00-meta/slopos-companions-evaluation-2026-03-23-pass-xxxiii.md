# SlopOS / companions evaluation — pass XXXIII

This pass re-checks Harbor against the uploaded cube ecology and keeps the archive embryonic.

## What the current cubes still teach
- **SlopOS** remains the cleanest anchor. `CH-REQCTX` keeps correlation and parentage explicit but non-authoritative; Harbor should borrow that humility for lane witnesses instead of inventing a portable current-session plane.
- **SlopOS** also keeps exact replay narrow. Its network request-idempotency boundary says the same scoped request key may replay only the same canonical request, while changed meaning under that key must reject before effect. That is exactly the right instinct for Harbor when an old lane returns after a newer lane already exists.
- **SlopOS** keeps acceptance and later currentness separate. The ACP acceptance/completion posture says an accepted request is not proof of current live state, later completion, or continuing validity. Harbor should preserve the same split for late old-lane completions.
- **Steward** is a great sibling pressure here. Its fence-token and precondition-witness ideas show how a tiny stale-holder fence can block wrong-cycle side effects without freezing a giant distributed-control plane.
- **ViewFS** keeps stale bases, winning versions, and conflict receipts separate. That is a useful analogy: old lane, live lane, and historical arrival should remain different truths.

## Harbor consequence
Harbor should keep lane/supersession nouns provisional.
The right near-term move is small:
- add one specimen around `lane witness`, `supersession fence`, `stale-result quarantine`, and `live-lane adoption`;
- keep old-lane arrivals visibly smaller than provider-local current-session truth or durable local adoption;
- and let stronger siblings own any portable queue, current-session, or execution-status story.

## Still-not-yet decisions
- Whether `lane witness` deserves its own first-class card or remains an exact field within callback proof / finish-envelope material.
- Whether `supersession fence` is Harbor-owned residue or merely a rule that neighboring detour state must obey.
- Whether `stale-result quarantine` should become a first-class aftermath class or remain an annotation on historical receipts.
