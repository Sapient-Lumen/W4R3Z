# Datacube external escalation handoff hygiene

**Status:** design-phase review surface for `rev0091`; not an ADR, schema, external-escalation workflow, regulator/auditor program, source-owner ticketing system, appeal court, legal process, disclosure platform, transparency-log policy, sealed-evidence API, public status-page product, incident-response program, compliance system, or final SlopOS datacube constitution.

## Why this exists

`rev0090` let Harbor record recurrence, regression, serial acknowledgement expiry, standing challenges, cooldown, warning sunset, and public-log/status divergence. `F086` applies the next pressure: some standing challenges cannot be resolved inside Harbor alone.

A source owner may need a packet that explains exactly what changed and which proof is missing. An auditor may need a verifier packet without raw suppressed values. A regulator may need sealed evidence with handling boundaries. A downstream owner may need a bounded appeal window for a warning or sunset decision. A public log may record that escalation happened while the public status page says something narrower.

Harbor needs language for handoff and appeal without pretending that handoff is acceptance, that a sealed packet is verification, that a public log is current truth, or that an external party's silence proves anything.

## Tight stance

- **Handoff is not closure.** Sending a packet records an attempt, target, basis, and audience. It does not prove receipt, review, agreement, repair, compliance, or harm.
- **Appeal is a bounded challenge, not a veto by default.** Appeals need standing, challenged decision, grounds, remedy sought, evidence basis, window, and stay posture.
- **Sealed evidence is still evidence.** A sealed packet must name digests, redaction cuts, handling labels, reveal conditions, verifier operations, retention/expiry, and non-promises. It must not become a secret second truth.
- **External authority is scoped.** A source owner can speak for its copy or remediation; an auditor can speak for a verification event; a regulator can speak for its jurisdiction or request. None of those automatically become Harbor source truth.
- **Public copy needs safe words.** Public escalation summaries should explain target, status, current user guidance, and uncertainty without leaking suppressed cells, raw replay data, private logs, or sensitive reporter/source details.
- **Divergence after escalation is normal.** A logged handoff, status-page banner, auditor note, source-owner reply, and public warning can all be true for different scopes and times. Harbor should record the mismatch, not flatten it.
- **Sunset appeals preserve history.** A disputed warning sunset can reopen active review or keep a warning in cooldown; it must not delete the historical correction chain or pretend previous risk never existed.

## States under observation

These are composable labels, not a final state machine.

| State | Meaning | Counterfeit to avoid |
| --- | --- | --- |
| `handoff_prepared` | packet assembled but not sent | escalation completed |
| `handoff_sent` | packet sent to named target/audience | accepted or reviewed |
| `handoff_acknowledged` | recipient acknowledged receipt | agreement, repair, or compliance |
| `handoff_unreachable` | target could not be reached or endpoint failed | refusal or bad faith |
| `appeal_window_open` | bounded challenge window is available | automatic stay or reversal |
| `appeal_window_expired` | no timely appeal, or appeal window elapsed | challenged decision is proven correct |
| `appeal_received` | challenged decision, grounds, and remedy were submitted | valid, complete, or successful appeal |
| `appeal_out_of_scope` | appeal does not match scope, standing, window, or evidence requirements | actor untrustworthy |
| `sealed_evidence_bound` | sealed packet has manifest, digest, handling label, and reveal limits | verifier accepted or all evidence disclosed |
| `auditor_packet_sent` | verifier-facing packet sent with sealed/open parts | audit result produced |
| `regulator_packet_sent` | regulator-facing packet sent with jurisdiction/handling scope | legal compliance or enforcement outcome |
| `source_owner_response_received` | source owner replied for named subject/action | remediation proof or policy truth |
| `public_summary_safe` | public copy is safe for current users | complete disclosure |
| `post_handoff_status_divergence` | logged escalation/public status/current proof differ | one surface is necessarily false |
| `sunset_appeal_pending` | historical-only downgrade is challenged | old warning must remain active forever |
| `unsafe_to_externalize` | packet cannot be sent as requested without over-disclosure or scope confusion | Harbor is hiding proof |

## Candidate process handles

These handles are watchlist vocabulary, not promoted schema.

### `standing_challenge_handoff_packet`

A packet for a named standing challenge that another party may be able to answer.

Candidate fields:

- challenge id, challenged claim family, source correction anchor, stale/corrected artifact ids, target copy class, payload digest, label digest, current public status, evidence lane, missing evidence, and requested proof;
- recipient class: source owner, downstream owner, auditor, regulator, coordinator, or reviewer;
- open section, sealed section, public-safe section, handling labels, redaction cuts, retention/expiry, and contact or submission route;
- requested action: acknowledge, provide verifier packet, correct public copy, clarify non-use basis, assess sealed evidence, or decline scope.

### `external_escalation_receipt`

A receipt that Harbor escalated a bounded claim or warning to an external target.

Candidate fields:

- escalation id, subject, target authority, escalation reason, recurrence/status basis, appeal posture, public warning state, delivery channel, timestamp, response window, follow-up window, and current outcome;
- result states: prepared, sent, acknowledged, accepted-for-review, declined, out-of-scope, unreachable, superseded, withdrawn, or unsafe-to-send;
- non-promises: no proof of review, agreement, repair, harm, legal notice, or compliance.

### `appeal_window_note`

A bounded opportunity to challenge a warning, sunset, standing challenge, or handoff decision.

Candidate fields:

- decision id, challenged field, challenger authority/standing, window opened, deadline, evidence allowed, required contents, stay posture, remedy sought, public-safe interim status, and result;
- appeal results: received, complete, incomplete, out-of-scope, accepted-for-review, rejected, withdrawn, expired, extended, or superseded;
- anti-counterfeit rule: appeal existence does not automatically freeze public guidance unless an explicit stay note says so.

### `sealed_evidence_transfer_manifest`

A manifest for evidence that cannot be made public but must still be checkable by an authorized verifier.

Candidate fields:

- sealed packet id, subject set, artifact digests, label digests, proof packet digest, redaction map digest, handling label, source owner/reporter privacy constraints, recipient class, reveal conditions, verifier operations, expiry, revocation, retention, and audit trail;
- allowed verifier operations: digest match, label-preservation check, replay-cut check, small-cell/suppression check, access-log window check, retrieval-index comparison, or source-owner authority check;
- non-promises: no raw public disclosure, no proof of correctness until verifier result, no universal access right, no permanent retention.

### `auditor_regulator_packet_note`

A summary of what an auditor, regulator, coordinator, or similar outside reviewer received and may conclude.

Candidate fields:

- recipient role, jurisdiction/scope if any, authority basis, public/private split, sealed manifest ids, policy/handling labels, allowed questions, disallowed questions, expected response types, and public-summary boundary;
- outcomes: no response, receipt only, accepted-for-review, asks for more evidence, cannot assess, partial finding, sealed finding, public finding, out-of-scope, or withdrawn;
- non-promises: no legal opinion, no compliance proof, no enforcement posture, no universal correctness.

### `post_handoff_status_divergence_note`

A note that a log, status page, public warning, auditor note, source-owner reply, or appeal window now says different things.

Candidate fields:

- surfaces compared, subject/cut/window/audience, current proof packet state, logged claim, status-page claim, handoff receipt, appeal state, public wording, and next recheck;
- divergence classes: old log/current status mismatch, appeal-open/status-fixed mismatch, sealed finding/public-safe mismatch, source-owner response/auditor result mismatch, or sunset/public-log mismatch;
- non-promises: neither surface wins by default.

### `disputed_sunset_appeal_note`

A small note for a warning moved or proposed to move to historical-only while someone still challenges the downgrade.

Candidate fields:

- warning id, sunset basis, clean windows, challenger, challenged field, evidence received, public-safe interim status, historical retention posture, active-warning posture, and final/next review state;
- outcomes: keep historical-only, reopen active warning, extend cooldown, narrow audience, request sealed review, refuse unsafe appeal summary, or supersede warning;
- anti-memory-hole rule: sunset never deletes correction anchors, stale-use evidence, recurrence receipts, or old public copy labels.

## Anti-counterfeit checks

- If a handoff packet lacks subject, audience, evidence lane, requested action, and non-promises, it is process theater.
- If a handoff acknowledgement is displayed as agreement, repair, or compliance, it overclaims.
- If an appeal lacks challenged decision, grounds, remedy sought, standing, and deadline, it is not ready for status effect.
- If an appeal is treated as an automatic stay without an explicit stay note, it has become a veto.
- If sealed evidence lacks manifest, digest, redaction map, handling label, reveal conditions, and verifier operations, it is an opaque trust-me blob.
- If public summary text leaks suppressed values, reporter identity, raw logs, or sealed replay evidence, it violates the lane.
- If a regulator/auditor packet is treated as a legal/compliance finding before a scoped response exists, external authority has been counterfeited.
- If public-log inclusion is treated as current truth after a status change, transparency has replaced verification.
- If a source-owner response is treated as remediation without observed proof, owner speech has become data truth.
- If a sunset appeal erases the historical warning, it counterfeits recall.

## Minimum proof obligations before any promotion

A candidate external-escalation noun must show at least these before it graduates from process residue:

1. It can name the challenged subject, decision/status, window, audience, evidence lane, and requested action.
2. It can separate prepared, sent, acknowledged, accepted-for-review, answered, declined, unreachable, and unsafe-to-send.
3. It can carry a sealed/open/public evidence split with digest, redaction, handling, expiry, and verifier-operation boundaries.
4. It can record appeal standing, challenged decision, grounds, remedy, deadline, completeness, and stay posture without making appeal equal reversal.
5. It can represent external roles without making source owners, auditors, regulators, coordinators, or transparency logs into Harbor truth sources.
6. It can produce safe public copy when escalation is active, appealed, out-of-scope, sealed, unresolved, sunset, or divergent.
7. It can preserve old correction chains and recurrence evidence after warning sunset or appeal outcome.

## Deliberate non-promotions

This pass does **not** promote:

- external escalation handoff schema;
- appeal-window API;
- source-owner ticketing workflow;
- regulator/auditor packet format;
- sealed-evidence transfer protocol;
- public status-page product;
- transparency-log policy;
- legal/compliance workflow;
- incident-response program;
- CVD/PSIRT/CSIRT operating model;
- VEX/CSAF profile;
- in-toto predicate;
- SCITT receipt dependency;
- reporter/source-owner reputation model;
- enforcement ladder;
- final SlopOS datacube shape.

## New pressure queued

After `F086`, the next seam is external decision return and adoption: conflicting source-owner/auditor/regulator determinations, partial findings, mandated or recommended corrections, sealed finding expiry, appeal outcomes, local adoption boundaries, and public copy updates after outside review.
