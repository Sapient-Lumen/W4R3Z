# Artifact handoff and consumer import

## Purpose

F097 records what happens after a Harbor release package leaves the source tree. A consumer may receive a zip, extract a tree, copy a fixture, paste a digest, rename an archive, upload it to a file library, or route it through a portal/callback surface. Each path can be useful evidence, but none of those paths is authority by itself.

The surface separates four questions:

1. what release or fixture was claimed;
2. how the material crossed the boundary;
3. what bytes, tree, or fixture file the consumer actually checked;
4. what narrow identity statement is allowed afterward.

## Handoff record sketch

```json
{
  "release_claim": {
    "claimed_revision": "rev0102",
    "claimed_archive_name": "Harbor-rev0102-...",
    "claim_source": "manifest | filename | pasted_digest | portal_callback | file_library_upload",
    "filename_is_not_identity": true
  },
  "transport_observation": {
    "channel": "downloaded_zip | extracted_directory | copied_fixture_file | chat_or_issue_comment | renamed_archive | file_library_upload | portal_callback | downstream_repack",
    "transform": "none | zip_extraction | file_copy | digest_paste | filename_rename | upload_copy | portal_mediated_transfer | repack",
    "transport_is_not_authority": true,
    "callback_success_is_not_verification": true,
    "upload_timestamp_is_not_currentness": true
  },
  "material_identity": {
    "material_kind": "release_zip_bytes | extracted_tree | fixture_file | pasted_digest",
    "digest_scope": "release_zip_bytes | extracted_tree_manifest | fixture_file_bytes | digest_text_only",
    "computed_digest_present": true,
    "digest_matches_reference": true,
    "archive_index_present": true,
    "fixture_parent_bundle_present": false,
    "material_identity_established": false
  },
  "consumer_verification": {
    "verification_action": "compute release zip digest and compare out-of-band",
    "requires_consumer_side_computation": true,
    "does_not_establish_package_trust_root": true,
    "does_not_establish_artifact_security": true
  },
  "scope_comparison": {
    "scope_comparison": "same bytes within fixture reference digest | derived extraction with manifest/index match | narrow fixture-file match with parent-bundle context | incomparable or insufficient"
  }
}
```

The sketch is deliberately not a schema. It is pressure vocabulary for the executable F097 bundle.

## Allowed statements

- A received zip may be treated as matching the observed release-byte scope only after consumer-side bytes are checked against the expected digest scope.
- A renamed archive may still match if the bytes match; the name mismatch is recorded rather than used as identity.
- An extracted tree may be derived-comparable to the release only when the archive index and manifest revision are present and no hidden generated artifacts are added.
- A copied fixture can support a narrow fixture-file statement only when its parent bundle/checker context is present.
- A portal/callback or file-library upload can be part of the route story only after material verification happens after the handoff.

## Refusals

- A filename match is not identity.
- A pasted digest is not possession of material.
- A file-library upload timestamp is not freshness or currentness.
- A callback success receipt is not verification.
- A zip digest cannot validate an extracted tree unless the digest scope says so.
- A repacked archive with a different digest is not the same artifact merely because contents look similar.
- A consumer acknowledgement is not proof of reliance, security, compliance, or downstream copy state.

## Why this belongs in Harbor

Harbor is the membrane cube. Release-package provenance stopped at the archive boundary. F097 adds the next boundary: consumer import. That makes Harbor responsible for preventing transport evidence from becoming package authority, while still keeping actual package signing, CI, notarization, provenance profiles, and consumer-verification APIs out of scope.
