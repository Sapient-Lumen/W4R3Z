# Datacube note: revocation-overlay propagation

F104 asks what happens after Harbor has accepted a companion withdrawal,
supersession, correction, dispute, expiry, or re-scope as a scoped overlay
over a prior foreign import.  The overlay has to reach people and local
machinery, but propagation evidence must remain smaller than status.

## Separation

A revocation overlay packet must keep these layers separate:

1. **Overlay source** — parent F103 bundle digest, parent case, overlay id,
   overlay digest, notice clock, sealed/stale posture, and source
   non-promises.
2. **Target surface** — public copy, mirror, generated summary, consumer
   notice, local index, warning card, sealed public summary, or mixed
   multi-cube card.
3. **Propagation action** — reached surfaces, unreached/unknown surfaces,
   source digest carry-forward, label carry-forward, history link, and scope
   map.
4. **Visibility render** — scoped public wording, split warning state, or
   sealed-summary boundary.
5. **Consumer notice** — delivery/read/applied/acknowledgement kept apart.
6. **Index/warning state** — local index refresh, recheck basis, stale overlay
   posture, and warning-card state kept apart.
7. **History linkage** — prior import history remains visible; overlay changes
   current display, not the fact that an earlier import was observed.
8. **Verdict** — Harbor may propagate a scoped overlay or refuse a status
   collapse.

## Counterfeits

The bundle refuses green badges, red global-failure badges, compliance
remediation/failure claims, prior-falsity banners, mirror-clean-as-all-clean,
summaries that lose source digest, notice-delivery-as-read/applied, index
refresh as truth, warning sunset without scope, sealed notice as public truth,
stale overlay as current, automatic repair, majority-vote overlay verdicts,
single badges over mixed states, global downstream repair, retraction as
history erasure, callback success as overlay status, timestamp freshness, and
missing source revocation digests.

## Audit/refactor consequence

Rev0109 also introduces `tools/harbor_bundle_common.py` and
`tools/check_harbor_bundle_common_audit.py`.  The helper centralizes digest,
assertion, digest-string, JSON-load, and forbidden-confidence scanning
routines for new proof slices.  It is maintenance scaffolding only: not a
schema, checker trust root, conformance registry, validation API, or promotion
gate.
