# Datacube executable crossing evidence

**Revision:** `rev0095`  
**Status:** F090 design and verification surface; not a schema, runtime, canonical datacube package, SlopOS import contract, MCP authorization model, browser credential profile, public status-page product, compliance workflow, or final SlopOS datacube shape.

## Why this exists

`CrossingRecord v0` is useful only if it can fail. Prose can say that a route record is not truth, that a callback is not authority, and that a browser credential presentation is not global identity. The F090 harness makes those refusals checkable.

The move is intentionally small:

- one deterministic fixture;
- one emitter;
- one checker;
- ten stable cases;
- exact member-label vocabulary;
- route-specific non-promises;
- rejected candidates for the easiest counterfeits.

This is the first Harbor surface where a crossing record is not just described. It must survive a tiny replayable bundle comparison.

## The crossing/import split

Harbor now keeps three facts apart:

| Fact | May be accepted | Must not become |
|---|---|---|
| Outside evidence exists | yes, with subject digest and route family | outside truth |
| Harbor admits a crossing record | yes, with scope and non-promises | durable trust or compliance |
| Aftermath needs monitoring | yes, with receipts, windows, and triggers | closure or global repair |

The harness checks this split by allowing some accepted cases and forcing some rejected cases to remain rejection residue only.

## What F090 proves

F090 proves that Harbor can bind `CrossingRecord v0` to executable evidence for:

- SlopOS `portal.net.request` route/admission import;
- SlopOS-style checkpoint/resume/truncation/append accepted-prefix evidence;
- malformed-envelope rejection;
- subject digest mismatch rejection;
- callback continuation boundaries;
- MCP/tool metadata untrusted posture;
- browser-mediated credential presentation posture;
- public-copy aftermath and warning recurrence;
- refused global `resolved` status overclaim;
- latest-wins scope-substitution rejection.

## What F090 deliberately does not prove

The bundle does not prove:

- that SlopOS internals are Harbor schema;
- that a portal accepted request means content is trusted;
- that a checkpoint/resume chain preserves outside truth;
- that a callback return proves same authority;
- that MCP annotations are truthful;
- that user consent or visibility equals user comprehension;
- that a browser credential presentation establishes global identity;
- not that a corrected public copy is compliant or repaired everywhere;
- not that a status banner saying `resolved` is a Harbor closure state;
- that a later ticket wins over scope comparison.

## Promotion posture

F090 upgrades the review method, not the noun. `CrossingRecord v0` remains a proof target. The new evidence bundle is allowed to harden because it catches drift, but the data model is still embryo-stage until repeated specimens show that the same shape survives transparency receipts, signed attestations, provenance chains, redaction cuts, and real SlopOS handoff pressure.

## New proof pressure opened

The next seam is transparency/provenance import. Harbor should pressure-test SCITT-like inclusion receipts, C2PA/content-credential manifests, in-toto/SLSA-style attestations, Rekor/CT-style inclusion/currentness evidence, timestamp anchors, redacted proof bundles, and issuer compromise stories without letting any receipt become truth.
