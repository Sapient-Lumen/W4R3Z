# Datacube transparency and provenance receipt import

**Revision:** `rev0096`  
**Status:** F091 design and verification surface; not a transparency-log reliance policy, C2PA verifier profile, in-toto/SLSA predicate profile, SCITT profile, timestamp authority policy, redaction proof system, issuer-reputation model, legal status workflow, or final SlopOS datacube shape.

## Why this exists

F090 made crossing evidence executable. F091 adds the next missing edge: outside systems increasingly return receipts that look authoritative because they are signed, logged, timestamped, content-bound, or verifier-produced. Harbor needs to import those receipts without letting them promote themselves.

The new rule is:

```text
receipt observed < subject bound < verifier judged < current for one checkpoint < safe to rely on for one scope
```

Each step must be named. None may be inferred from the previous one by aesthetic confidence.

## Receipt families under pressure

F091 keeps eight receipt families distinct:

| family | Harbor may import | Harbor must not infer |
|---|---|---|
| `scitt_inclusion` | signed-statement registration and receipt digest | statement truth, currentness, policy satisfaction, issuer authority beyond scope |
| `c2pa_manifest` | asset/manifest binding and active-manifest observation | real-world authenticity, editorial approval, transform survival, trust-signal truth |
| `intoto_slsa_provenance` | subject, builder, predicate, materials, and policy-epoch evidence | build trust by default, dependency cleanliness, deployment truth, vulnerability status |
| `rekor_ct_inclusion` | inclusion proof, tree/checkpoint, entry retrieval | semantic approval, currentness beyond checkpoint, revocation absence |
| `timestamp_anchor` | message-imprint/time authority receipt | event time, source truth, current state |
| `redacted_derived_proof` | selected claim verification and disclosure scope | full evidence, no hidden contradiction, recursive disclosure entitlement |
| `issuer_compromise_advisory` | compromise window and recheck requirement | automatic truth, automatic falsity, global revocation |
| `verifier_policy_decision` | local policy result over named inputs and epoch | content truth, future policy pass, legal closure, global authority |

## Import record split

A Harbor receipt-import record is still embryo-stage. It exists only inside the F091 fixture, but the split is now mandatory for future specimens:

```text
subject: what artifact, statement, asset, attestation, signature, token, proof, issuer-status note, or verifier run is named
receipt: which family produced which receipt digest and issuer/observer facts
binding: whether the receipt binds the subject digest or only a selected/redacted claim
scope: artifact, audience, jurisdiction, surface, and time window
verifier: policy id, policy digest, epoch, decision, and no-semantic-truth bit
currentness: checkpoint/timestamp/revocation/compromise posture
outcome: narrow class plus receipt-family non-promises
aftermath: recheck window and rollback/reopen triggers
```

The checker is intentionally not a JSON schema. It is a refusal harness. Its job is to catch the most tempting category errors.

## Currentness cuts

Harbor distinguishes:

- `currentness_not_established` — receipt exists, but no current-state claim survived review;
- `fresh_for_checkpoint_only` — one checkpoint/tree head/currentness basis was named;
- `timestamp_only` — a message existed at or before a timestamp authority response;
- `revocation_or_compromise_recheck_required` — issuer/key/log status may affect prior reliance;
- `policy_epoch_bound` — a verifier decision is only as current as the policy/input epoch.

This lets a log receipt, content credential, timestamp token, or verifier result be useful without becoming a current-world claim.

## Hostile imports

F091 rejects six counterfeits:

1. subject digest mismatch between receipt evidence and import candidate;
2. inclusion mutated into `trusted` outcome;
3. log inclusion mutated into fresh-now currentness;
4. issuer-compromise state hidden while recheck non-promises are stripped;
5. redacted/selected proof mutated into full evidence;
6. newer receipt used to widen audience/surface scope.

These are not exotic attacks. They are the default failure modes of receipt-rich systems when a downstream product wants a green badge.

## Relation to CrossingRecord v0

The receipt-import bundle does not replace the F090 CrossingRecord bundle. It sits after it:

```text
CrossingRecord v0 says an outside evidence crossing occurred within scope.
ReceiptImportRecord v0 says a specific external receipt was imported within scope.
Neither says the world is true, fresh, repaired, approved, or safe.
```

A future Harbor-Core promotion candidate must survive both harnesses.

## Promotion posture

F091 closes the transparency/provenance seam only as executable pressure. It does not promote a transparency log dependency, C2PA verifier, in-toto predicate, SLSA trust level, SCITT registry reliance rule, Rekor/CT currentness rule, timestamp authority policy, redaction proof runtime, issuer-reputation score, or legal closure workflow.

The next pressure should combine receipt import with **multi-verifier disagreement and policy-epoch drift**: one verifier accepts, one refuses, one cannot check currentness, policy changes after the fact, and the public copy wants a single status badge anyway.
