# Research synthesis — pass XLVIII

This pass keeps Harbor narrow and learns five compatible things at once: **requested protected resources, exact proof targets, and issued-resource confirmation are different seams; discovery-time routing remains smaller than issuance-time confirmation; omission of returned resource bounds deserves typed honesty; exact request-target residue is valuable without becoming grant truth; and Harbor should preserve target clarity without freezing a portable target registry too early.**

## Outside lessons
1. **Requested resource identity is its own fact.**  
   RFC 8707 lets a client indicate the protected resource it wants by sending a `resource` parameter, says the value must be an absolute URI, and recommends the most specific URI the client can provide. Harbor should keep a **request-target receipt** rather than flattening target intent into scopes, issuer labels, or generic API folklore.

2. **Exact proof target is still separate from requested resource.**  
   RFC 9449 requires the DPoP `htu` claim to match the HTTP URI of the request in which the proof is received, ignoring query and fragment parts, and recommends syntax- and scheme-based normalization before comparison. Harbor should continue to preserve exact target residue without pretending it settles grant or resource meaning by itself.

3. **Discovery-time routing is smaller than issuance-time confirmation.**  
   RFC 9767 lets a GNAP authorization server publish RS-facing discovery at `/.well-known/gnap-as-rs`, including the `grant_request_endpoint` that client instances should use. That is useful routing truth, but it still lives at discovery time. Harbor should not confuse “this is the AS endpoint the RS told me about” with “this is the protected resource the issued result actually covers.”

4. **Issued-resource echo is the clever new pressure point.**  
   The current OAuth resource-token-response draft says a token response can return `resource` so the client can confirm which protected resource the issued token is valid for, specifically to mitigate ambiguity and resource mix-up attacks. It also stresses that metadata and discovery describe static relationships and do not prove issuance-time selection. Harbor should collect an **effective-target echo** and keep it smaller than durable grant truth.

5. **Missing target bounds deserve typed honesty.**  
   The same draft distinguishes between responses that carry a concrete returned `resource` and cases where omission means the token is not specific to any resource in the sense of that draft. Harbor should preserve an **unbounded-target warning** instead of silently pretending the client got exactly what it first asked for.

## Resulting Harbor move
Do not decide yet whether Harbor needs durable nouns such as **request-target receipt**, **effective-target echo**, or **unbounded-target warning**.
For this revision:
- add one specimen around a requested resource, an exact DPoP proof target, RS-first or metadata-driven authorization-server discovery, and an issuance-time `resource` echo or omission;
- preserve the difference between “what resource the client asked for”, “what exact endpoint the proof targeted”, “what resource the server says the token is actually for”, and “none of those facts by themselves settle durable grant/account/session/adoption truth”;
- and collect **discovery-source note** plus **narrowed-target subset** as inspiration only, without promoting a new registry today.

## Fresh ideas worth stealing
- **request-target receipt** — compact residue of the exact protected resource identifier the client asked for here.
- **effective-target echo** — inspectable note of the `resource` value(s) the issuer returned at issuance time.
- **unbounded-target warning** — explicit local note that the result did not come back with specific returned target bounds.
- **discovery-source note** — future-facing reminder of whether the AS route came from RS-first discovery, metadata, or local configuration.
- **narrowed-target subset** — future-facing reminder that an issuer may accept only part of a requested set without that subset becoming durable grant truth.
