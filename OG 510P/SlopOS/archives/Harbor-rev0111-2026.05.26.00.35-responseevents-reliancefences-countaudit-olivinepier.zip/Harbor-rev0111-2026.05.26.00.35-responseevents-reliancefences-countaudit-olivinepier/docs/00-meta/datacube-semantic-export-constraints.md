# Datacube semantic export constraints

This surface is a **review checklist**, not a schema, ADR, API, semantic-layer decision, BI model, or catalog contract.

It exists because Harbor will eventually need to explain consumer-facing datacube exports. The design-phase danger is that a generated semantic model, dashboard explore, metric API, catalog view, or AI-facing ontology will look like settled truth before the underlying SlopOS datacube has earned that commitment.

## Standing rule
A semantic export is a derived lens. It can advertise safe questions and honest refusals. It cannot silently promote row meaning, contract strength, join safety, currentness, row lineage, or universal identity.

## Process vocabulary reserved here
These terms are allowed as process vocabulary for review and specimens. They are not durable schema terms yet.

### semantic export receipt
A compact record that says a semantic front door was derived from named source cuts.

Minimum contents:
- export id and revision;
- base lane/tag/cut inputs;
- generated artifact(s), if any;
- dialect/runtime/product assumptions, if any;
- dimensions/entities/measures/metrics exposed;
- joins allowed/refused;
- freshness basis and evidence grade;
- contract subset exposed;
- invalidation/restatement trigger; and
- refused questions.

Anti-counterfeit rule: the receipt owns no data and does not outrank base lane proof.

### contract subset
The selected public slice of shape, meaning, assertion, freshness, service, and consumer-obligation promises exposed through one export.

Minimum contents:
- fields/metrics exposed;
- assertions included;
- assertions omitted or private;
- severity/blocking posture;
- freshness threshold and evidence basis;
- consumer obligations; and
- non-promises.

Anti-counterfeit rule: a contract subset is not the whole contract, not all checks, and not a universal promise to every consumer.

### freshness basis witness
A small statement of how a freshness claim was calculated.

Minimum contents:
- source cut or observation cut;
- published cut or knowledge cut;
- threshold;
- measured age;
- time axis used;
- evidence grade; and
- late-arrival/restatement posture.

Anti-counterfeit rule: freshness does not imply exact replayability, complete history, or live-head truth unless those proof obligations are separately satisfied.

### join-relationship note / fanout fence
A statement of which joins are safe for the exposed metrics and which are refused.

Minimum contents:
- left and right grains;
- key fields and uniqueness proof;
- relationship class as observed for this cut;
- aggregate classes affected;
- fanout/chasm risk;
- allowed metrics; and
- refused metrics or required pre-aggregation.

Anti-counterfeit rule: a join note is a proof witness, not a magic incantation. If the base grain is wrong or uniqueness evidence is absent, the export refuses.

### optional row-lineage sidecar
A scoped tracing artifact that can help audit row survival, split, restatement, or source-family debugging.

Minimum contents:
- source system or lane scope;
- cut/snapshot scope;
- lineage field(s) present;
- null/unknown behavior;
- update/delete caveats;
- whether sidecar is required, optional, stale, partial, or absent; and
- what the sidecar cannot prove.

Anti-counterfeit rule: row lineage is not subject identity, not conformance, not authorization, not a join key by default, and not universal row truth.

## Hard no list
- No semantic export owns source rows.
- No generated metric model outranks the reviewed proof packet.
- No public contract exposes all assertions by default.
- No freshness badge omits threshold, basis, and time axis.
- No one-to-many join is allowed to feed additive or ratio metrics without a fanout fence or pre-aggregated child metric.
- No row-lineage sidecar becomes universal identity.
- No sidecar presence silently upgrades contract tier.
- No sidecar absence silently falsifies data.
- No product vocabulary from dbt, Looker, Cube, DataHub, Iceberg, OpenLineage, or any sibling cube is imported as Harbor law without specimen pressure.

## Proof obligations normally required
A semantic export candidate normally touches these proof obligations from `docs/00-meta/datacube-proof-obligations.md`:

- PO-DC-001 — grain proof;
- PO-DC-002 — time-axis proof;
- PO-DC-005 — aggregation and fanout proof;
- PO-DC-006 — conformance proof;
- PO-DC-007 — exactness proof;
- PO-DC-008 — history and restatement proof;
- PO-DC-009 — contract and evidence proof;
- PO-DC-010 — derived-artifact proof;
- PO-DC-011 — sidecar optionality proof; and
- PO-DC-012 — noun-promotion proof.

## Minimum refusal surface
Every semantic export receipt should be able to say:

```text
can_answer:
  - metric/dimension combinations backed by proof
cannot_answer:
  - unsafe drilldowns
  - unproved joins
  - per-row or per-subject questions not in the contract subset
  - latest/live-head questions when the export is a frozen cut
  - exactness or freshness questions beyond the evidence grade
requires_review:
  - new metric families
  - new join paths
  - new freshness thresholds
  - restated historical cuts
  - sidecar-dependent debugging questions
```

## Current status
Pass LXXVIII uses this checklist for specimen flow 73. It does not promote semantic export receipts, contract subsets, freshness basis witnesses, join-relationship notes, fanout fences, or row-lineage sidecars into durable Harbor schema.
