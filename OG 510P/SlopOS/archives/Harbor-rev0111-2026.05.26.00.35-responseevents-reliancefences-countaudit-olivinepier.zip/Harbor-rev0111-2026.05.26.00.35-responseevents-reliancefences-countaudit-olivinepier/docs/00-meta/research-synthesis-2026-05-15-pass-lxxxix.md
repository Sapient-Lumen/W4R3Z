# Research synthesis — pass LXXXIX, status reconciliation and disputed remediation

**Revision:** `rev0089`  
**Date:** 2026-05-15  
**Question:** How should Harbor handle disputed remediation, expired acknowledgements, contradictory external impact reports, unverifiable use attestations, and public-status drift without becoming a tribunal or status-page product?

## Result

Harbor should treat disputed downstream repair as **status reconciliation**, not adjudication.

The useful move is to record five small packets:

1. a remediation challenge receipt;
2. an acknowledgement expiry note;
3. an external impact claim map;
4. a use-attestation challenge note;
5. a public status sync receipt.

Together they let Harbor say, "this claim was received, this part is verified, this part is contradicted, this part is scope mismatch, this acknowledgement expired, this attestation is unverifiable, this public banner drifted, and this is the safe public wording." They do not decide every dispute, rank every reporter, prove all downstream uses, or certify repair.

## External lessons folded in

- NIST SP 800-61 Rev. 3 puts incident response inside broader cybersecurity risk-management activities and emphasizes preparation, reduced impact, and improved response/recovery. Harbor should borrow the response/recovery/learning posture, not import a cyber-incident lifecycle wholesale.
- CSAF 2.1 and OpenVEX keep impact/remediation status tied to named products/components/vulnerabilities and require status/action/justification discipline. Harbor should steal scoped status and action statements, not security-advisory governance.
- in-toto attestation separates subject, predicate, envelope, and bundle. Harbor should use that shape for use/remediation/status claims: a claim is about named subjects and a typed basis, not general truth.
- SCITT, Certificate Transparency, and Rekor show why append-only or signed publication evidence is powerful but limited. Inclusion proves a signed statement was recorded or observed; it does not prove the statement is semantically correct.
- C2PA's manifest/claim/assertion model is a useful reminder that provenance and active-manifest rules matter for public copies and generated explanations, but manifests remain trust signals rather than automatic truth.
- W3C PROV-DM and PROV-CONSTRAINTS distinguish provenance descriptions, validity, consistency, bundles, equivalence, and application-specific treatment. Harbor should borrow consistency/equivalence checks for contradiction maps.
- Status-page APIs expose incidents, components, incident updates, subscribers, and postmortems as separate objects. Harbor should steal the separation between outward status, component status, updates, and postmortems, while refusing to become a status-page product.

## SlopOS-specific interpretation

SlopOS is still design-phase, so Harbor should avoid durable dispute schemas.

The SlopOS lessons are:

- imported status claims must remain boundary-local and digest-bound;
- a provider, catalog, model card, or generated explanation cannot upgrade itself into SlopOS truth by saying `resolved`;
- stale acknowledgements and unverifiable non-use claims are exactly the kind of weak outside facts that Harbor exists to keep small;
- public status surfaces must be treated as copies that can drift, not as authority.

## New watchlist handles

- `status_reconciliation_packet`
- `remediation_challenge_receipt`
- `acknowledgement_expiry_note`
- `external_impact_claim_map`
- `use_attestation_challenge_note`
- `public_status_sync_receipt`
- `safe_disputed_status_statement`
- `unresolved_for_now_note`

## Practical design rule

Prefer status phrases that preserve uncertainty:

- `received`, not `verified`;
- `claimed repaired`, not `fixed`;
- `acknowledgement expired`, not `ignored`;
- `non-use claimed; unverifiable`, not `not used`;
- `scope mismatch`, not `contradiction`;
- `public status repaired for target X`, not `world updated`;
- `unresolved for now`, not `resolved by default`.

## Followthrough result

`F084` is now complete as a pressure test. The next seam is recurrence: repeated stale-copy regressions, serial acknowledgement expiry, repeated unverifiable attestations, mixed-accuracy external reports, and when stale/disputed public warnings should escalate, cool down, or sunset without creating a reputation system.
