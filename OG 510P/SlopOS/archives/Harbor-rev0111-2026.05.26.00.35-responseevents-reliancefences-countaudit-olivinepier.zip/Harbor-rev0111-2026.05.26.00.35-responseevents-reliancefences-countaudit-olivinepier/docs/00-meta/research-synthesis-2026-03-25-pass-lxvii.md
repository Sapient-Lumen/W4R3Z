# Research synthesis — pass LXVII

This pass asks a smaller question than “what is Harbor’s final null policy?”

It asks: **while the datacube is still embryonic, how do we stop blank-looking cells, default-looking values, and omitted fields from impersonating one another?**

## What the outside material teaches
1. **Presence and value are different facts.**
   Protobuf’s field-presence guidance draws a hard line between implicit presence and explicit presence. Under implicit presence, the API stores values only; under explicit presence, it also stores whether a field was set. The docs explicitly warn that implicit-presence scalar fields can make an explicit default value indistinguishable from omission, and recommend `optional` for proto3 basic types to smooth the path to editions.

2. **Columnar systems keep nullity separate from data values.**
   Arrow’s format keeps a dedicated validity bitmap alongside values, and Arrow’s struct validity is independent of child validity. Parquet likewise encodes nullity in definition levels and does not encode null values in the data stream itself. The shared lesson is bigger than either file format: absence is often tracked on a separate channel from value bytes.

3. **A blank cell can have multiple honest causes.**
   dbt’s `relationships` test automatically excludes `NULL` values and instructs users to add `not_null` separately if nulls should fail. That is a small but important signal: referential integrity and null intolerance are separate promises, not one generic cleanliness fact.

4. **Maturity and promise strength should remain explicit.**
   OpenTelemetry’s component and semantic-convention lifecycles make maturity explicit (`draft`/`experimental`/`stable`/`deprecated`/`removed`, or `development` through `stable`) rather than implying one universal finishedness. Harbor should steal the attitude for presence semantics too: presence classes can be review surfaces now without pretending the final shared enum is finished.

5. **Contracts can promise several kinds of things at once, but still need separation.**
   OpenMetadata splits contracts into sections such as schema, semantics, quality/assertions, SLA, and status, while DataHub describes data contracts as producer-owned, verifiable guarantees built on assertions. Harbor should therefore keep presence semantics in the meaning tier and not let assertions or service posture silently decide what an empty-looking slot means.

## Harbor consequence
Harbor should add one modest datacube/process seam now:
- **presence witness** — compact note that says whether a slot is explicit value, explicit null/unknown, not applicable, withheld/suppressed, or default-shadowed;
- **default shadow** — compact warning that the substrate collapsed explicit-default and unset states; and
- **absence witness** — compact note that says whether a blank is due to query omission, incomplete batch, policy withholding, inapplicability, serving-tier omission, or producer-side absence.

## What Harbor still should not decide yet
- one universal cube-wide null enum shared across every sibling repo;
- one machine-readable schema that every warehouse/export/runtime must emit;
- one mandatory mapping from presence classes to Arrow, Parquet, dbt, or protobuf representations;
- one universal rule for whether late data is a subtype of unknown, absence, or restatement.

The design-phase lesson is enough for now: **keep value separate from presence, keep absence causes explicit, and admit default-shadow where explicit intent was lost.**
