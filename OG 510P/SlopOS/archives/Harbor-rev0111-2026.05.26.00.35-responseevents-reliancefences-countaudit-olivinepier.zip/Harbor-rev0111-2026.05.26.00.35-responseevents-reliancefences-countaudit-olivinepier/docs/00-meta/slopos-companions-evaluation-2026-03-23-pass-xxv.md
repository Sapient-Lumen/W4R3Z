# SlopOS / companions evaluation — pass XXV

This pass re-checks Harbor against the uploaded cube ecology and keeps the architecture embryonic.

## What the current cubes still teach
- **SlopOS** is the loudest teacher here. Its browser-session export boundary and OpenURI session-selection boundary both refuse to mint portable browser-session/profile authority from local mediation. That means Harbor can safely record logout/disconnect/reset residue without pretending it owns a universal session/logout object.
- **ViewFS** keeps remembered designators, revalidation, live handles, and receipts separate. That is exactly the stance Harbor needs after sign-out: remembered candidates may still exist, but stronger action needs fresher truth.
- **Steward** says remembered shelves are convenience memory, not current truth. Harbor should steal that humility for post-logout account/credential/browser memory.
- **Helm** keeps session/profile selection shell-owned and not requester-authoritative. By analogy, logout/reset of remembered session/profile state should stay layer-owned rather than becoming one Harbor-wide verdict.
- **Schell** keeps restored, historical, and live state visibly different. Harbor should borrow that honesty for “signed out here” versus “forgotten everywhere.”

## Harbor consequence
Harbor should keep logout/reset nouns provisional.
The right near-term move is small:
- add one specimen around disconnect pulse, memory reset, cold-start floor, and residual-memory honesty;
- keep selected account / browser session / universal logout truth outside Harbor-owned durable vocabulary;
- and keep resettable browser/provider/authenticator memory visibly smaller than durable local adoption or durable account-binding meaning.

## Still-not-yet decisions
- Whether `memory reset` deserves its own card or remains a typed aftermath annotation on mediation/continuity surfaces.
- Whether `cold-start floor` is distinct from the broader interaction-floor family or just one post-logout subtype.
- Whether Harbor ever needs a first-class universal logout object at all, or whether that should remain an anti-goal while layers keep differing in what they remember.
