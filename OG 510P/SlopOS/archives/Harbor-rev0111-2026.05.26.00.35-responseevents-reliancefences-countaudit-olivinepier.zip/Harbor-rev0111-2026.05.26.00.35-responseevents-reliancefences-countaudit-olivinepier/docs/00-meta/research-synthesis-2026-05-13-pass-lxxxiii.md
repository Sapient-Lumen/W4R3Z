# Research synthesis — 2026-05-13 pass LXXXIII

Question: how should Harbor pressure-test `F078` — aggregate-only historical answers with small cells, differencing attacks across allowed cuts, repeated-query leakage, noisy or approximate disclosure candidates, and consumer-facing suppression/refusal — without promoting a privacy engine, statistical disclosure control system, differential-privacy stack, query broker, or final SlopOS datacube constitution?

## Result of this pass
The strongest next move is to split **answerability**, **releaseability**, and **privacy proof**.

A historical aggregate can be exact and visible to some internal reviewer while still unsafe for public release. A released aggregate can be disclosure-treated and useful while no longer preserving additivity, exact totals, or exact comparability across sibling tables. A noisy estimate can reduce disclosure risk while also changing the truth class of the answer. A suppressed cell can be the honest answer, not an error.

This pass therefore adds:

- `docs/00-meta/datacube-aggregate-disclosure-risk.md` — a compact review surface for small-cell, dominance, differencing, repeated-query, noisy-estimate, and suppression/refusal posture; and
- `docs/30-architecture/specimen-flow-78-aggregate-disclosure-small-cell-differencing-budget.md` — a concrete specimen covering a small exact cell, collapsed publication, differencing across two allowed cuts, repeated-query leakage, noisy/perturbed release candidates, structural-zero confusion, and consumer-facing refusal copy.

This closes `F078` while preserving the design-phase stance: Harbor can record why a cube-shaped aggregate is exact, suppressed, collapsed, noisy, budget-limited, or refused without choosing a disclosure-control regime.

## External lessons folded into this pass
1. **Differential privacy is a quantified privacy-loss framework, not a reassuring adjective.** NIST SP 800-226 frames differential privacy as a mathematical way to quantify privacy loss and warns about practical hazards when the framework is realized in software. Harbor should steal the demand for explicit parameters, contribution bounds, composition/accounting, and implementation assumptions; it should not label an aggregate `dp_safe` because noise was added.

2. **Reconstruction pressure is real.** The U.S. Census Bureau's 2020 disclosure-avoidance work was driven by the need to protect published statistics while maintaining utility, and the public materials frame differential privacy as a framework for measuring disclosure risk. Harbor should assume that enough overlapping aggregates can become a reconstruction tool unless release history and sibling cuts are part of the review.

3. **Aggregate tables leak through low counts, dominance, and linked tables.** The Australian Bureau of Statistics warns that aggregate tables can create disclosure risk through low contributor counts, magnitude cells dominated by one or a few contributors, and differencing across multiple tables with common elements. Harbor should carry contributor-count and dominance posture beside the released value rather than hiding them inside the query engine.

4. **Small-cell protection and differencing protection interact with utility.** ONS explains Census 2021 protections that combined record swapping, cell-key perturbation, and rules preventing very sparse table-builder outputs, explicitly including protection against disclosure by differencing. Harbor should treat suppression, perturbation, and table-detail limitation as release modes with quality consequences, not as invisible formatting.

5. **Suppression needs complementary suppression and clear markings.** The Census FSRDC disclosure handbook says problematic outputs may need cell collapse, suppression marked with a disclosure note, and complementary suppression to prevent users from deriving suppressed values from released cells. Harbor should not publish one `D` cell while leaving enough totals and sibling cells to solve it.

6. **SDC methods are tradeoffs, not one ladder.** Eurostat's census/demographics SDC guidance compares methods by simplicity, perturbation, consistency, additivity, and magnitude of differences, and notes that cell suppression becomes difficult for many linked tables. Harbor should preserve the tradeoff labels: exact-but-suppressed, perturbed-but-consistent, rounded-but-not-additive, and similar states cannot collapse into one safe-public boolean.

7. **OpenDP-like toolkits are useful as calculators, not constitutions.** OpenDP shows the value of composable privacy-aware computations. Harbor should steal the idea that privacy transformations need typed measurement, transformations, and proofs, while keeping the tool choice outside Harbor until real SlopOS specimens force it.

8. **SlopOS already biases toward bounded, redaction-first export.** The included SlopOS CH-OBSPOL and D-OBS posture make exports explicit, bounded, redacted, policy-killable, and non-authoritative. Harbor mirrors that posture for aggregate release: a metric export is not an ambient public query service, and a disclosure-budget note is not an authority token.

## New process shape
`docs/00-meta/datacube-aggregate-disclosure-risk.md` names nine review handles:

- release cell;
- contributor evidence;
- small-cell guard;
- dominance guard;
- sibling-cut set;
- repeated-query ledger;
- disclosure-budget note;
- noise/perturbation receipt;
- release/refusal copy.

These are not canonical schema objects. They are review vocabulary for specimens, promotion packets, and future SlopOS datacube work.

## Specimen selected
Specimen flow 78 models a historical callback success aggregate where the raw replay evidence remains hidden, but the consumer requests a public aggregate broken down by route family, provider family, and time cut:

- one cell has a contributor count of two;
- one rate has a small denominator even though the displayed percentage looks harmless;
- one magnitude cell is dominated by one provider;
- two individually allowed tables reveal a suppressed provider by differencing;
- repeated near-neighbor queries reconstruct a path over time;
- a noisy candidate breaks exact additivity and downstream reconciliation expectations;
- a zero is ambiguous between structural impossibility and suppression;
- and the consumer needs a refusal that does not leak the hidden value.

A naive system would say “aggregate only, therefore safe,” publish exact totals with a `D` cell, add ad hoc noise without an accounting note, let repeated queries drain no budget, or expose raw replay evidence to justify the refusal. Harbor refuses those counterfeits.

## Still not decided
- one statistical disclosure control method, suppression threshold, dominance rule, k-anonymity rule, cell-key perturbation mechanism, or differential-privacy framework;
- one disclosure-budget ledger, query broker, privacy accountant, or public aggregate-release API;
- whether aggregate release policy belongs in Harbor, SlopOS, Foundry, Steward, Helm, or a shared substrate;
- whether noisy outputs are expressed as exactness classes, privacy receipts, assertion results, or separate release copies;
- how public mirrors, exports, and BI tools preserve suppression/noise/refusal labels;
- how to reconcile exact internal answers with disclosure-treated public answers when corrections/restatements arrive later.

The deeper lesson is: **aggregate-only is not automatically disclosure-safe.**
