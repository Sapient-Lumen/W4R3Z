# Research synthesis — pass LX

This pass keeps Harbor narrow and learns five compatible things at once: **actionable `authorization_details` bodies can legitimately carry ephemeral, interaction-specific claims; those bodies are aimed at one resource server's trusted authorization-server set rather than the world; the same draft explicitly treats replay/caching of those bodies as a security concern and recommends `Cache-Control: no-store`; ordinary metadata/schema caching still exists beside that no-store body; and a later schema or trust-set change can require a visible repair step without turning Harbor into a portable authorization-details, trusted-AS, or schema-coherence registry.**

## Outside lessons
1. **Actionable error bodies can carry per-interaction facts.**  
   The February 2026 RAR metadata draft explicitly says resource servers may provide actionable `authorization_details` objects in `insufficient_authorization_details` responses and lists support for **ephemeral, interaction-specific claims** such as a risk score, a risk profile, or an internal interaction identifier. Harbor should therefore preserve a retry-scoped residue rather than pretending the body is a durable entitlement or approval object.

2. **Actionable bodies have a trust audience.**  
   The same draft says the audience of these error-body authorization-details objects is the resource server's **trusted authorization servers**, as advertised by the resource metadata, and says resource servers **SHALL** provide such objects only if **all** trusted authorization servers accept the authorization-details type used. Harbor therefore needs a **trusted-schema-audience note** instead of flattening one helpful body into world-portable policy truth.

3. **`no-store` is a semantic defense, not just transport hygiene.**  
   The draft warns that `403` responses with actionable bodies may be cached or replayed in unexpected contexts and recommends `Cache-Control: no-store`. Harbor should therefore keep a distinct **detail-retry cache epoch** or replay-warning story when a previously helpful body is reused later.

4. **Metadata/schema caching still happens next to no-store bodies.**  
   RFC 9728 says protected-resource metadata is fetched with HTTP `GET` and that normal HTTP caching behavior applies. That means a client can simultaneously have: cached resource metadata, cached schema fetched through a metadata endpoint, and a non-cacheable actionable body. Harbor should keep those cache layers visibly separate rather than compressing them into one stale-config blob.

5. **Repair is smaller than truth.**  
   When a trusted authorization-server set changes, or a `schema_uri`-backed detail shape rotates, or the ephemeral fields in an actionable body expire, the correct next move can be to re-fetch metadata/schema and rebuild the detail object. Harbor should preserve a **schema-rotation repair receipt** instead of turning repaired retry material into durable entitlement, approval, or session truth.

## Resulting Harbor move
Do not decide yet whether Harbor needs durable nouns such as **trusted-schema-audience note**, **schema-rotation repair receipt**, or **detail-retry cache epoch**.
For this revision:
- add one specimen where a resource server emits an actionable `authorization_details` body with ephemeral interaction-specific claims;
- keep the resource's trusted-authorization-server set separate from the client's later selected authorization server and from any later granted details;
- keep actionable-body replay/caching separate from ordinary metadata/schema caching; and
- treat repair-after-rotation or trust-set drift as smaller crossing residue rather than portable policy, schema, or approval truth.

## Fresh ideas worth stealing
- **trusted-schema-audience note** — compact residue that a helpful actionable detail body was only meant for one resource's trusted authorization-server set.
- **schema-rotation repair receipt** — typed note that a later retry succeeded only after refetching metadata/schema and rebuilding the detail object.
- **detail-retry cache epoch** — retry-scoped age/provenance note for actionable bodies and nearby schema guidance.
- **ephemeral-claim humility** — standing anti-regrowth rule: risk score, interaction ID, or risk profile in an actionable body is helpful retry material, not durable authorization truth.
- **no-store or quarantine** — standing anti-regrowth rule: a replayed actionable body should bottom out visibly, not silently ride forward as a generic retry.
