# Datacube presence semantics

Purpose: keep Harbor honest that **value** and **presence** are related but not identical.

Design-phase datacubes repeatedly get into trouble when they flatten all of these into one cell story:
- explicit value;
- explicit null / unknown;
- not applicable;
- withheld / suppressed;
- not yet observed / late; and
- implicit default where the producer or transport no longer tells us whether the value was really set.

Harbor should not freeze one giant universal null ontology now.
It does need one small review surface that stops early convenience from counterfeiting meaning.

## Core rule
A returned value is only half the truth.
Harbor should keep room to say **how the slot became present or absent**.

That means a zero is not automatically the same as “nothing happened,” a null is not automatically the same as “not applicable,” and a default-looking value is not automatically proof that the producer explicitly chose it.

## Compact presence classes (Phase 1)
Harbor should keep the first ladder small.

1. **explicit value**
   - a value is present and the producer/transport kept that fact distinct from absence.
   - examples: explicit number, explicit string, explicit enum, explicit boolean.

2. **explicit null / unknown**
   - the slot is present enough to say “there is no value here” or “the value is unknown,” rather than silently falling back to a default.
   - Harbor should allow local interpretation notes, because “unknown”, “not collected”, and “null” are often neighbors rather than synonyms.

3. **not applicable**
   - the slot does not apply for this row/card/receipt under the declared grain or type family.
   - this should stay visibly different from unknown and visibly different from zero.

4. **withheld / suppressed**
   - the slot was deliberately not exposed because of privacy, security, policy, or bounded review posture.
   - this should stay visibly different from unknown and visibly different from not applicable.

5. **default-shadowed / implicit presence**
   - the returned value may be real, but Harbor cannot tell whether it was explicitly set or simply inherited from an implicit/default discipline.
   - this is the humility class that stops default-looking values from impersonating explicit intent.

These are review classes, not a demand that every storage engine or neighbor cube use the same enum.

## Presence witness
Harbor should allow a compact **presence witness** beside a field, measure, or derived card.

A presence witness can say:
- which presence class is in force;
- whether the basis came from producer signal, transport/storage null tracking, derivation rule, filter omission, privacy suppression, or local inference;
- whether the slot is exact, estimated, or only weakly known; and
- whether the slot may change later because the value is late-arriving.

The witness matters because the same rendered cell can hide very different truths.
A displayed `0`, empty string, omitted child object, or blank measure can all mean different things.

## Default shadow
Harbor should keep one compact **default shadow** note for families where the transport or schema discipline collapses “unset” and “default value”.

This note is especially useful when:
- a boolean `false` may mean “explicitly false” or merely “never set”;
- an enum's first/default member may be indistinguishable from omission;
- a numeric zero may be indistinguishable from an implicit default; or
- a nested object can be null at one level even while child slots still carry values in storage/layout.

The point is not to ban defaults.
It is to stop Harbor from overclaiming explicit intent where the substrate only gave value bytes.

## Absence witness
Harbor should allow a compact **absence witness** when a field/measure is missing from a returned slice.

Useful causes include:
- filtered away by query shape;
- unavailable because the batch/window was incomplete;
- withheld by policy;
- not applicable for this row family;
- not materialized on this serving tier; or
- absent because the producer/transport genuinely emitted no value.

The absence witness is smaller than row meaning.
It only keeps blank space honest.

## What this forbids in Phase 1
- no silently treating default-looking scalar values as proof of explicit producer intent;
- no silently treating null, withheld, not-applicable, and late/not-yet-observed as one generic blank;
- no letting query-level omission counterfeit producer-level absence;
- no letting nested child values or layout bytes overrule a higher-level null without an explicit witness;
- no forcing one cube-wide null enum before repeated specimens show it is actually stable.

## What this still leaves open
- exact machine-readable schema for presence witnesses and absence witnesses;
- exact relationship between late-arriving context and explicit null / unknown;
- exact cross-cube vocabulary sharing with SlopOS, Ward, Foundry, or Steward;
- exact compilation to Arrow/Parquet/dbt/warehouse-native representations.

Harbor only needs the review behavior now: **keep value separate from presence, keep absence causes explicit, and admit default-shadow when explicit intent was lost.**

## Pass LXXX note — negative presence humility
Blocked export, withheld field, explicit null, not-observed value, and tombstone/withdrawal marker must remain separate. A refusal row may mention that a component was withheld or blocked, but that bounded statement is not allowed to reveal whether the sensitive value was present, absent, null, or historically withdrawn unless the export policy permits that disclosure.
