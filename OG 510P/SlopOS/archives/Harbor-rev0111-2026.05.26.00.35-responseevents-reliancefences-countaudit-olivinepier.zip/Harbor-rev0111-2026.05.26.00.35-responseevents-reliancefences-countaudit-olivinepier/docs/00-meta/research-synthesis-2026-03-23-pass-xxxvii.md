# Research synthesis — pass XXXVII

This pass keeps Harbor narrow and learns one more thing from requested identity/profile facts, released account/profile bundles, and claim/source provenance: **what a caller asks to learn is not the same thing as what an outside system releases, and a released bundle is still smaller than locally adopted subject/account truth.**

## Outside lessons
1. **OpenID Connect separates requested Claims from returned Claims.**  
   OpenID Connect Core says the `claims` request parameter is OPTIONAL and is used to request specific Claims from the UserInfo Endpoint and/or the ID Token. It also says support for that parameter is OPTIONAL, and if it is unsupported the OP may still return whatever Claims it believes are useful. Harbor should steal that humility: a claim ask is real and useful, but it does not bind the outside system to one exact release bundle.

2. **Omitted or partial release is honest.**  
   OpenID Connect Core says UserInfo Claims are returned as a JSON object and that, for privacy reasons, OpenID Providers may elect not to return some requested Claims; that is not an error condition. Harbor should therefore keep “asked for” separate from “actually released” instead of treating missing fields as counterfeit success or counterfeit failure.

3. **Claim provenance deserves its own seam.**  
   OpenID Connect Core explicitly distinguishes Normal Claims, Aggregated Claims, and Distributed Claims. For aggregated/distributed claims it uses `_claim_names` and `_claim_sources`, and it says an `iss` claim should be included in JWTs from a Claims Provider for signature validation. That is a brilliant Harbor pattern: preserve where a released fact came from instead of flattening every field into one undifferentiated profile blob.

4. **Browser-mediated account facts are chooser material, not adopted-account truth.**  
   FedCM’s accounts endpoint returns account fields such as `id`, `name`, `email`, `given_name`, `picture`, `approved_clients`, `login_hints`, and `domain_hints`. Those are excellent Harbor precedents for a release bundle that shapes mediation and display while remaining smaller than local adoption.

5. **Display-facing account strings need visible boundaries.**  
   WebAuthn Level 3 says `PublicKeyCredentialEntity.name` is human-palatable and intended only for display in the RP case, and `displayName` for the user account is intended only for display; the spec also says clients/platforms/authenticators should use UI elements that provide a clear boundary around `displayName` and avoid overflow into other elements. Harbor should steal that caution: displayable identity-ish text is useful but deserves its own clearly bounded surface.

## Resulting Harbor move
Do not decide yet whether the durable nouns are exactly `claim ask`, `release bundle`, `source witness`, and `not-adopted-here honesty`, or whether later pressure compresses some of them behind smaller admission/aftermath residue.
For now, keep them alive as specimen nouns and demand that they improve:
- one OIDC specimen where requested profile/email/group claims do not all come back and the omission stays honest;
- one OIDC specimen where aggregated or distributed claims carry explicit source/provenance instead of dissolving into a flat profile story;
- and one FedCM or WebAuthn specimen where display-facing account facts remain smaller than locally adopted subject/account truth.

## Fresh ideas worth stealing
- **claim ask** — typed request for specific identity/profile facts.
- **release bundle** — inspectable outside-provided set of facts that actually came back here.
- **source witness** — compact provenance about which issuer/provider/claims source asserted which released facts.
- **not-adopted-here honesty** — explicit reminder that a released bundle may still be display-only, chooser-only, or otherwise insufficient for local account adoption.
- **bundle smaller than adopted subject** — standing anti-regrowth rule.
