# Roadmap update — rev0111

## Rev0111 checkpoint

F106 is closed. Harbor can now represent a user response to an explanation card as scoped event evidence with parent explanation digest, event kind, capture context, interpretation guard, follow-up action, privacy/retention posture, history trace, and verdict. The pass refuses click/focus/scroll as comprehension, acknowledgement as consent or compliance, export as reliance, appeal/retry/recheck request as repair or passed result, share link as all-recipient read, notification delivery as user action, stale response as currentness, direct-person analytics, unbounded retention, and agent acknowledgement as user consent.

Rev0111 also refactors executable proof-slice counts: landing-page audits now derive the visible count from `tools/harbor_executable_surface_registry.py` rather than hardcoding a spelled-out count.

Next pressure (`F107`): response-event replay, withdrawal, expiry, and invalidation when explanations change, recheck results arrive, appeal outcomes land, users undo responses, or retention compacts the trace without retroactive consent, reliance, repair, currentness, or compliance.

Current revision focus (`rev0111`): user-response event capture, reliance/consent/comprehension fences, and registry-derived count audit.

# Roadmap update — rev0109

## Rev0109 checkpoint

F104 is closed. Harbor can now represent propagation of a foreign-revocation overlay into public and local surfaces while preserving source digest, target surface, reached/unreached surfaces, display posture, consumer-notice status, local index/warning state, and prior history linkage. The pass refuses badge collapse, compliance claims, prior-falsity banners, mirror/search truth, notice-delivery-as-read/applied, warning sunset without scope, stale-currentness, majority verdicts, global downstream repair, and callback/timestamp overclaims. Rev0109 also adds a bundle-common helper audit and generated-bytecode package hygiene.

Next pressure (`F105`): user-visible explanation bundles for revocation overlays, including minimum wording, digest context, stale-surface caveats, sealed-summary limits, accessibility/localization variants, and generated-explanation carry-forward without badge, compliance, or global-repair collapse.

Current revision focus (`rev0110`): user-visible explanation bundles, language overclaim refusal, and briefing focus audit.

# Roadmap update — rev0105


## Rev0108 checkpoint

F103 is closed. Harbor can now represent a companion withdrawal, supersession, correction, dispute, expiry, or re-scope as a scoped overlay over a prior F102 import. The revocation overlay preserves parent import identity, notice digest, local impact analysis, downstream quarantine, history residue, and recheck plan while refusing prior-falsity, automatic repair, companion trust-root, public badge, compliance, and majority-vote shortcuts. Rev0108 also refactors executable checker wiring through a maintenance registry and audit.

Next pressure (`F104`): propagate revocation overlays to public copies, mirrors, generated summaries, consumer notices, local indexes, and warning cards without badge collapse, compliance workflow promotion, prior-falsity judgment, or global downstream repair.


Current revision focus (`rev0108`): foreign-import revocation overlays, withdrawal/supersession guards, downstream quarantine, and executable registry audit.

- Closed `F100`: derivative repair evidence retention and expiry.
- Keep retained repair evidence, expiry, compaction, pruning, legal-hold-like preservation, reviewer notes, source re-correction, warning residue, and compliance as distinct statuses.
- Next: `F101`, overlapping correction epochs where derivatives repaired under different source corrections must not collapse into latest-wins or oldest-receipt shortcuts.

# Roadmap
Next pressure seam: `F097` artifact handoff and consumer import without transport-as-authority.

Current revision focus (`rev0103`): post-import local derivation drift, local indexes, cache fences, and sync-copy non-authority guards.

## rev0102 focus
- artifact handoff receipts so received zips, extracted trees, copied fixtures, pasted digests, renamed archives, file-library uploads, portal/callback transfers, and downstream repacks stay distinct;
- material identity checks so consumer-side bytes, tree inventories, and fixture context are checked under the correct digest scope;
- transport non-authority guards so filename, path, upload timestamp, callback success, and consumer acknowledgement cannot impersonate package authority;
- next pressure: post-import local derivation drift across annotations, generated summaries, extracted subsets, local indexes, re-exported archives, cached explanations, cross-device sync, and stale consumer copies.


## rev0100 focus
- checker-provenance packets so checker source digest, harness digest, fixture digest, invocation, self-test receipt, and observation boundary travel with the result;
- guard-state receipts so disabled refusal rails cannot hide behind a green-looking checker observation;
- fixture/checker pairing discipline so stale fixture revisions and copied digests cannot counterfeit current checker evidence;
- reviewer override limits so human review can explain, expire, or schedule followthrough but cannot turn failure into success;
- bootstrap humility so the new checker-provenance bundle records prior checkers without claiming recursive self-attestation or trust-root status;
- next pressure: release-package provenance, archive-index drift, deterministic zip evidence, build-environment capture, and bootstrap receipts without promoting release attestations or package trust roots.

## rev0099 focus
- mutation-triage evidence so unsafe survived mutants, equivalent survivors, overstrict false-positive candidates, fixture-promotion packets, and corpus-pruning notes stay visibly separate;
- checker hardening so forbidden authority/truth phrases in accepted string values are rejected, not only forbidden key names;
- equivalent-mutant humility so harmless order/wording/explanation changes can survive without becoming schema gaps or automatic fixture promotions;
- overstrictness discipline so a checker kill can be preserved as a deliberate canonicality/reproducibility guard rather than hidden schema law;
- corpus-pruning receipts so redundant generated pressure can be retired without erasing why it was once useful;
- next pressure: checker provenance, disabled-guard evidence, checker-version drift, self-test receipts, stale fixture/checker pairings, and reviewer override packets.

## rev0098 focus
- property/mutation meta-bundle so existing executable Harbor checkers are pressure-tested by targeted generated counterfeits;
- deterministic baseline digests so mutation evidence stays tied to emitted F090/F091/F092 bundles;
- killed/survived diagnostics so checker sensitivity is visible without becoming correctness, compliance, or certification;
- shrink notes so generated cases remain human-readable and do not become giant opaque JSON blobs;
- non-promotion guards so property-test frameworks, fuzzing campaigns, shared schemas, conformance suites, numeric gates, and production validators stay unpromoted;
- next pressure: survived-mutant, equivalent-mutant, and checker-overstrict triage without letting generated evidence bypass human promotion packets.

## rev0097 focus
- verifier-disagreement evidence so accept/refuse/inconclusive/currentness-unknown splits stay visible instead of collapsing into a green badge;
- policy-epoch drift discipline so policy id, policy digest, policy epoch, input digest, and public-copy time are required before comparing verifier decisions;
- currentness humility so inclusion, timestamping, prior policy pass, or one verifier success cannot become fresh-now;
- badge refusal so withheld, split, scoped, recheck-required, prior-epoch-with-notice, and incomparable-review postures remain safer than trusted/resolved/all-clear;
- hostile fixtures so retroactive erasure, stale-policy currentness, refusal overgeneralization, issuer-compromise auto-false, majority-vote authority, and missing-policy-digest candidates fail before a disagreement id is emitted.

## rev0096 focus
- receipt-import evidence so signed, logged, timestamped, manifest-bound, redacted, compromised-issuer, and verifier-produced records must survive a deterministic bundle rather than badge-shaped prose;
- binding/currentness cuts so subject digest, manifest/material binding, checkpoint freshness, timestamp-only evidence, policy epoch, and compromise recheck stay separate;
- hostile fixtures so digest mismatch, inclusion-as-trust, fresh-now overclaim, hidden compromise, redaction-as-full-evidence, and latest-wins scope substitution fail before import ids are emitted;
- transparency/provenance humility so SCITT-like, C2PA, in-toto/SLSA, Rekor/CT, timestamp, and redacted-proof evidence informs Harbor without becoming a reliance policy.

## rev0095 focus
- executable crossing evidence so CrossingRecord v0 must survive a deterministic bundle rather than prose-only review;
- route-family non-promises so portal-network, durability, callback, MCP/tool, browser credential, and public-copy aftermath cases cannot widen into trust, identity, user comprehension, compliance, or repair;
- hostile fixtures so ambient truth fields, digest mismatches, global `resolved` banners, and latest-wins scope substitution fail before aftermath;
- SlopOS portal-net bridge humility so accepted-only histories and checkpoint/resume/truncation/append evidence can inform Harbor without copying SlopOS internals;
- next pressure: transparency/provenance receipt import across SCITT, C2PA, in-toto/SLSA, Rekor/CT, timestamp anchors, redacted proof bundles, and issuer-compromise stories.

## rev0093 focus
- implementation receipts so adopted outside findings can become named correction work without becoming proof of repair, propagation, compliance, or source-owner truth;
- mandate/recommendation/deadline notes so binding instructions, non-binding clarifications, appeal stays, and jurisdiction/audience scopes stay separate;
- stale-surface guards so canonical public-copy updates can coexist honestly with stale snippets, mirrors, localized summaries, generated explainers, and unreachable targets;
- recheck windows so monitoring observations name surfaces, methods, clean/stale/inconclusive results, and recurrence/rollback triggers without claiming universal recall;
- next pressure: missed deadlines, failed rechecks, rollback after bad corrections, contradictory implementation evidence, stale-surface recurrence after clean windows, and re-escalation/sunset after implementation monitoring.

## rev0092 focus
- decision-return receipts so outside source-owner, auditor, regulator-facing, reporter, and appeal responses can arrive without becoming adopted truth;
- scope-normalization notes so conflicting findings are compared only after subject, window, audience, method, authority, and evidence lane match;
- finding-adoption notes so Harbor can accept only a narrow public-wording or warning effect while refusing compliance, repair, fault, or sealed-evidence disclosure;
- sealed finding expiry notes so current reliance can lapse without deleting historical evidence;
- next pressure: correction implementation and post-decision monitoring after adopted findings, including mandates, recommendations, partial implementation, rechecks, reopened appeals, and jurisdiction/audience splits.

## rev0091 focus
- handoff packets so standing challenges can be sent to source owners, auditors, regulators, coordinators, or reviewers without becoming closure;
- appeal windows so challenged warnings, sunsets, and standing challenges name standing, decision, grounds, remedy, deadline, completeness, and stay posture;
- sealed evidence manifests so sensitive proof can be digest-bound, redaction-bound, handling-bound, verifier-operation-bound, and public-summary-bound;
- post-handoff divergence notes so public logs, status pages, warning cards, auditor notes, source-owner replies, and appeal states can differ without one surface counterfeiting truth;
- next pressure: external decision return and adoption, conflicting findings, partial determinations, sealed finding expiry, appeal outcomes, and local public-copy updates after outside review.

## rev0090 focus
- recurrence receipts so repeated stale-copy, serial expiry, repeated unverifiability, mixed reporter outcomes, and public-log/status divergence stay visible without becoming actor reputation;
- regression guards so a target can be both previously repaired and currently regressed without rewriting either proof;
- escalation windows so standing challenges and active warnings name target, audience, evidence, consequence, and exit conditions;
- cooldown/sunset guards so clean windows can downgrade public warnings to historical-only without erasing correction chains or stale-use evidence;
- next pressure: external escalation handoff, appeal windows, auditor/regulator/source-owner packets, sealed evidence boundaries, and public-log/status-page divergence after escalation.

## rev0089 focus
- status reconciliation so remediation claims, consumer challenges, external reports, use attestations, acknowledgements, and public banners can be compared without inventing a tribunal;
- remediation challenge receipts so a claimed repair can be partially verified, disputed, scope-mismatched, or unresolved for a named subject/action instead of becoming a false fixed badge;
- acknowledgement expiry notes so stale receipts stop supporting current posture without pretending refusal, non-use, harm, or repair;
- contradiction maps so external impact reports are split into confirmed, unsupported, stale-citation, scope-mismatch, and unsafe-to-disclose pieces;
- public status sync receipts so outward `resolved` banners, catalog cards, generated explainers, and status pages match proof-packet state and non-promises;
- next pressure: recurring stale-copy regressions, serial acknowledgement expiry, repeated unverifiable attestations, mixed-accuracy external reports, and warning escalation/sunset.

## rev0088 focus
- stale-use impact packets so a stale public copy used in a report, dashboard, dataset, eval, agent answer, citation, or policy memo can be described without collapsing exposure, reliance, impact, and repair;
- consumer acknowledgement receipts so notice receipt, review started, no-use claimed, repair planned, repair refused, and disputed posture stay visibly weaker than remediation;
- remediation attestations so downstream owner repair claims must name subject, action, evidence, result status, residual risk, and recheck/expiry before Harbor treats them as useful;
- use-attestation humility so used/not-used/unknown statements remain scoped to an actor, window, method, logs/manifests/cards reviewed, and limitations;
- safe public impact statements so Harbor can guide users to corrected artifacts without leaking suppressed values, sealed evidence, raw replay data, or promising universal recall;
- next pressure: disputed remediation, expired acknowledgements, contradictory external impact reports, unverifiable use attestations, and public-status drift.


## rev0103 focus
- post-import local derivation drift so annotations, summaries, subsets, indexes, re-exports, caches, sync copies, stale copies, and local repair patches remain scoped derivatives rather than source truth;
- transform-scope and label/non-promise carry-forward so generated or extracted material cannot silently drop treatment labels or non-promises;
- freshness and invalidation guards so cache hits, timestamps, local search, and sync success cannot counterfeit currentness;
- local repair humility so consumer patches and acknowledgements do not become upstream repair, reliance, compliance, or global downstream state;
- next pressure: derivative correction propagation and consumer repair acknowledgement after source changes.


## rev0106 focus
- overlapping correction epochs so a source correction A, source correction B, rollback, dispute, and derivative repair history can coexist without latest-wins collapse;
- derivative lineage edges so repaired summaries, indexes, re-exports, caches, sync copies, and local patches name their epoch-specific subject digests;
- scope reconciliation so disjoint, partial-overlap, conflict, parallel, and unknown relations block whole-artifact status widening;
- rebase/rollback currentness windows so local patches and rollback material require maps and rechecks before current claims;
- public badge refusal so mixed-epoch derivative state remains split, scoped, disputed, or recheck-required rather than green/global;
- next pressure: cross-cube lineage import where sibling cubes contribute epoch evidence without transferring authority or status.

## Historical roadmap

## rev0087 focus
- propagation receipts so source-side public corrections can be tracked across catalog mirrors, download mirrors, caches, snippets, generated explainers, retrieval indexes, training/evaluation copies, and unreachable mirrors without claiming universal recall;
- search snippet stale witnesses so old snippets, previews, and answer summaries can be marked stale while the live source artifact remains correct;
- cache and crawler signal humility so purge/revalidate, sitemap `lastmod`, URL-change pings, robots/meta tags, and outdated-content requests remain attempt/observed receipts rather than guarantees;
- agent explanation invalidators so cached model-written explanations and retrieval chunks become stale when correction anchors, label digests, or public status change;
- training/evaluation stale-copy notices so downstream dataset/model/eval cards can acknowledge stale absorbed material without promising unlearning, corpus deletion, or benchmark repair;
- next pressure: stale-downstream impact assessment, consumer acknowledgement, remediation receipts, and use-attestation humility.

## rev0086 focus
- correction anchors so public copies, summaries, accessible variants, stale mirrors, and translated errata can be superseded or repaired without pretending older copies vanished;
- annotation provenance so comments, flags, reviewer notes, machine notes, and disputes carry body/target/selector/source/review-status posture before they influence public truth;
- stale-citation witnesses so links, DOIs, blogs, cached dashboards, and external metadata can be current, stale, dead, superseded, or unverifiable without becoming semantic proof;
- generated-explanation receipts so model-written summaries remain tethered to source artifacts, label digests, omitted labels, review status, and invalidation triggers;
- dispute fences so contested suppression/noise/exactness labels get safe interim statuses and sealed/auditor evidence lanes rather than public raw-value disclosure;
- next pressure: correction propagation and invalidation across catalog mirrors, search snippets, generated explainers, agent caches, and downstream training/evaluation copies.

## rev0085 focus
- localized render variants so translated labels, locale number/unit formats, accessible chart/table alternatives, human summaries, and renderer transforms stay tied to source public artifacts and label digests;
- locale and translation receipts so display strings do not rewrite canonical values, units, suppression/noise/exactness labels, or non-promises;
- accessible-variant proof so tables, long descriptions, source-data links, and carried labels remain reviewable surfaces rather than hidden authority upgrades;
- summary tether and renderer-drift refusals so plain-language copies and downstream dashboards can help humans without becoming proof-grade by accident;
- next pressure: public correction, errata, annotation, stale citation, generated explanation, and consumer dispute hygiene after localized or accessible copies escape.

## rev0084 focus
- public-copy hygiene so disclosure-treated aggregate labels survive BI exports, CSV mirrors, PDFs, charts, caches, and public-data-package copies instead of disappearing as decoration;
- release-artifact receipts so payload digest, label digest, source/public cut, audience, release mode, and exactness/additivity consequences travel together;
- restatement chains so old public copies can be superseded, deprecated, or withdrawn without pretending they were remotely recalled or retroactively rewritten;
- recomposition guards so individually acceptable public copies do not become a reconstruction attack when combined;
- next pressure: localization/accessibility/rendering variants for public copies, including translated labels, unit/locale formatting, alt text, and human-readable tables that do not become a second truth source.


## rev0083 focus
- aggregate disclosure risk so exact internal answers, safe public copies, suppressed/collapsed/noisy releases, and unsafe-to-release refusals do not collapse into one aggregate badge;
- small-cell and dominance guards so low contributors, small denominators, and dominant magnitude cells stay visible before public copy is emitted;
- differencing cuts and repeated-query ledgers so individually safe tables, near-neighbor filters, and time-window variants cannot quietly reconstruct hidden values;
- disclosure-budget humility so noisy or perturbed outputs carry mechanism/accounting evidence and exactness/additivity consequences instead of counterfeiting differential privacy;
- next pressure: downstream public-copy hygiene for disclosure-treated labels, mirrors, BI exports, restated public answers, and recomposition attempts.

## rev0082 focus
- replay-evidence access so a visible answer, a verifier proof, and raw survivor payloads do not collapse into one disclosure entitlement;
- redaction tickets so audience, allowed claims, disallowed payload classes, expiry, revocation, and non-recursive fetch are named before proof leaves the repo;
- verifier packets so selected statements, digests, source locks, and disclosure transcripts can support review without pretending to be full replay;
- source-lock drift so current policy/source/runtime state cannot silently prove an old answer without old locks or equivalence proof;
- next pressure: aggregate disclosure risk, small-cell suppression, differencing, repeated-query leakage, noisy estimates, and disclosure-budget humility.


## rev0081 focus
- replay survivability so old cube-shaped answers are classified by survivor set instead of time-travel folklore;
- retention windows so base cuts, transaction logs, tombstones, sidecars, views, assertions, policy epochs, rates, and runtimes can expire on different clocks without counterfeiting exact answerability;
- frozen cuts and answer packets so Harbor can return what it published then when recomputation is gone, while labeling it smaller than current truth and raw-row authority;
- exact-answer humility so current reruns, preserved query text, emergency recovery, and explanation-only receipts do not impersonate exact historical replay;
- next pressure: access, redaction, and verifier boundaries for replay evidence and frozen answer packets.

## rev0080 focus
- negative evidence so missing helper artifacts, blocked exports, unsupported compiler targets, stale frontiers, and tombstones do not counterfeit positive or negative facts;
- refusal ledgers so consumer-facing denial can name basis, scope, audience, lifecycle, safe alternative, and non-promises without becoming a blacklist or public API;
- stale-frontier receipts so insufficient event-time/progress evidence narrows labels to preview/as-of/refuse rather than becoming global stale truth;
- tombstone humility so withdrawal, compaction, replay, purge, and identity reuse remain visibly different;
- next pressure: replay-after-compaction and exact historical answer survivability when frozen cuts, tombstones, sidecars, and late-correction evidence have different retention windows.

## rev0079 focus
- reservation cuts so Harbor can rehearse observation exchange receipts, derived-view receipts, sidecar interpretation notes, frontier/watermark witnesses, assertion compiler receipts, and schema transform receipts without promoting them;
- view receipts so a no-data derived view names source cuts, dialect/query digest, invalidation conditions, and replay requirements instead of impersonating base row truth;
- frontier witnesses so event-time progress, published-cut closure, export build time, compaction posture, and freshness stay visibly separate;
- compiler humility so generated data-quality targets and schema transforms remain receipts with unsupported semantics and non-equivalence warnings;
- next pressure: negative evidence and refusal ledgers for missing sidecars, blocked exports, unsupported compilation, stale frontiers, and consumer-facing refusals.

## rev0078 focus
- semantic export cuts so consumer-facing datacube lenses say which questions are safe and which are refused instead of impersonating canonical row truth;
- contract subsets so public promises name only selected shape, assertion, freshness, exactness, and join obligations instead of publishing every internal check;
- fanout fences so many-to-one joins and one-to-many child-grain joins do not collapse into one flattering aggregate surface;
- lineage sidecar humility so source-scoped row traces can support debugging/restatement without becoming universal identity;
- next pressure: option reservations for observation-shaped exchange exports, versioned derived views, statistics/lineage sidecars, watermarks/frontiers, and assertion-compiler targets.

## Phase 0 — found the language
- freeze the first durable separations;
- keep the assumption, pressure, and question ledgers alive;
- sharpen neighbor boundaries with Helm, Schell, ViewFS, Steward, SlopOS, and the other new cubes.

## Phase 1 — specimen cuts
- design specimen flows that prove the vocabulary earns its keep before any registry or schema bloom;
- keep route, mediation, callback, chooser, and aftermath facts visibly separate;
- identify which sibling surfaces would consume compact Harbor receipts later.

## Phase 2 — narrow registries
- only after the specimen cuts survive pressure, grow registries, schemas, and promotion criteria;
- prefer refinement of existing nouns over adding overlapping new families.

## Phase 3 — operational proof
- require at least one example where exact review basis, summary freshness, and requester-copy negation remain visibly separate from durable approval or adopted consequence;
- require at least one example where a bounded review card, an explicit origin cue, and truncation honesty remain visibly separate from durable approval, grant, account, and session truth;
- require at least one example where a coarse origin cue, a preview asset, and chooser labels remain visibly separate from durable issuer, approval, grant, account, and session truth;
- require at least one example where exact connection context, finish-hash verification, and foreign-finish veto remain visibly separate from durable issuer, account, and adopted consequence truth;
- require at least one example where receiver-origin witness, secondary-window lane, and message-origin fence remain visibly separate from durable issuer, account, session, and adopted consequence truth;
- require at least one example where device-split witness, pairing cue, and same-device veto remain visibly separate from durable issuer, account, session, and adopted consequence truth;
- require at least one example where a cleanup pulse, stale-chooser quarantine, and display-refresh residue remain visibly separate from durable issuer, account, session, and adopted consequence truth;
- require at least one example where an audience basis, an exact endpoint target, and an alias veto remain visibly separate from durable issuer, resource, grant, account, session, and adopted consequence truth;
- require at least one example where a requested target, an issuance-time returned target echo, and an unbounded-target warning remain visibly separate from discovered AS routes, exact proof targets, durable grant truth, and adopted consequence;
- require at least one example where discovery source, candidate target slate, narrowed-target subset, and typed `invalid_target` refusal remain visibly separate from durable entitlement, grant, and adopted consequence truth;
- require at least one example where grant-bounded narrowing floor, server-assigned addition, and typed target-refusal rail remain visibly separate from durable entitlement, grant, and adopted consequence truth;
- require at least one example where assigned-only lane, requested-anchor minimum, and resource-confirmation floor remain visibly separate from discovery-time routing, durable entitlement/grant truth, and adopted consequence meaning;
- require at least one example where a default-target cue, a challenge-derived coverage note, and a confirmation-gap receipt remain visibly separate from discovery-time scope, token-format audience, exact client-facing response confirmation, and adopted consequence meaning;
- require at least one example where a token-format target witness, a resource-server coverage card, and a client-confidence ladder remain visibly separate from explicit returned-resource confirmation, durable entitlement/grant truth, and adopted consequence meaning;
- require at least one example where a JWT introspection response card, explicit returned-resource precedence, and alias-family mismatch note remain visibly separate from signed receiver-facing provenance, token-format audience hints, durable entitlement/grant truth, and adopted consequence meaning;
- require at least one end-to-end example where Harbor absorbs real outside pressure without flattening a sibling cube;
- require at least one example where selector hints and chooser priming remain visibly smaller than reviewed selection and adopted consequence;
- require at least one example where a disconnect pulse and memory reset remain visibly smaller than universal logout or universal forgetfulness;
- require at least one example where a recency ask, an `auth_time` receipt, and a current freshness verdict remain visibly separate from token issuance and durable session truth;
- require at least one example where an outside attenuation notice, a receiver stance, and a revalidation floor remain visibly separate from delivery mechanics and portable live-session truth;
- require at least one example where a scoped correlation handle, a local match witness, and a mismatch quarantine remain visibly separate from durable subject/session/account truth;
- require at least one example where a browser/provider status advert, a verification turn, and a mismatch floor remain visibly separate from durable login/account/session truth;
- require at least one example where fetched discovery, cache age, and bounded overlay resolution remain visibly separate from actual admitted route/resource truth;
- require at least one example where a support advert, a method hint, and a negotiated-path witness remain visibly separate from actual admitted capability/path truth;
- require at least one example where an assurance ask, an achieved rung, and a method receipt remain visibly separate from portable assurance registries, durable account/session truth, and local approval policy;
- require at least one example where a claim ask, a release bundle, and a source witness remain visibly separate from locally adopted subject/account truth and portable profile registries;
- require at least one example where prompt provenance, a reviewed summary, and a review witness remain visibly separate from requester-authored copy and durable grant/account/session truth;
- require at least one example where an in-flight pending rung, a pace hint, an explicit refusal rail, and an expired or abandoned ending remain visibly separate from durable success or durable account/session truth.

- require at least one example where an exact replay witness, a duplicate-suppressed outcome, and a spent crossing chance remain visibly separate from portable resume or exactly-once folklore;
- require at least one example where a caller/runtime abort, a chooser dismissal, a deadline floor, and a raced completion remain visibly separate from provider refusal or durable account/session truth;
- require at least one example where a lane witness, a supersession fence, and a stale-result quarantine remain visibly separate from current-lane adoption and durable account/session truth.


## rev0072 focus
- exactness classes so Harbor can say whether a published value is exact, exact-from-components, sketch-estimate, or sample/proxy estimate;
- sketch witnesses so mergeable summaries, retained sketch artifacts, and precision posture stay explicit instead of hiding behind integer-looking values;
- error-band notes so approximate outputs carry bounded uncertainty posture or an explicit “point estimate only” warning;
- next pressure: restatement receipts, semantic front doors, and change-history lanes.

## rev0071 focus
- conformance lanes so Harbor can say whether a shared-looking dimension is local-only, a true conformed subset, a bridge-based alignment, or only a convenience surface;
- bridge witnesses so changing or many-to-many mappings carry explicit multiplicity and time-basis posture instead of masquerading as one settled entity model;
- identity shadows so canonical-looking IDs remain useful while still visibly smaller than final truth;
- next pressure: restatement receipts, semantic front doors, and change-history lanes.

## rev0070 focus
- aggregation semantics so Harbor can declare whether a published number is additive, semi-additive, ratio/composite, or set/sketch-backed before others reuse it;
- fanout fences so one-to-many joins do not quietly multiply counts and totals that belong to a narrower base grain;
- rollup notes so ratios are recomputed from components, distinct/set questions carry honest exactness posture, and optional sketch sidecars stay visibly smaller than core row meaning;
- next pressure: restatement receipts, semantic front doors, and change-history lanes.

## rev0069 focus
- time axes so Harbor can name occurrence time, validity time, knowledge time, and published-cut time explicitly instead of overloading one timestamp;
- as-of witnesses so replay, validity, and knowledge questions name their temporal basis instead of relying on one ambient latest head;
- knowledge cuts so published answers stay replayable as exact cuts without pretending they were timeless reality;
- next pressure: restatement receipts, semantic front doors, and change-history lanes.

## rev0068 focus
- evidence grades so Harbor can say whether a trusted reading is fresh live head, exact frozen snapshot, partial evidence, or unknown instead of overclaiming one green state;
- head-trust notes so moving-head observations do not counterfeit exact reviewed snapshot history and exact historical tags do not counterfeit present-tense freshness;
- freshness witnesses so currentness remains a measured, thresholded, basis-bearing calculation rather than atmosphere;
- next pressure: restatement receipts, semantic front doors, and change-history lanes.

## rev0067 focus
- presence classes so Harbor can distinguish explicit value, explicit null/unknown, not applicable, withheld, and default-shadowed states without forcing a giant null ontology;
- default shadows so default-looking values do not counterfeit explicit producer intent when the substrate collapsed unset and default;
- absence witnesses so query omission, incompleteness, suppression, inapplicability, and producer-side absence stay visibly distinct;
- next pressure: restatement receipts, semantic front doors, and change-history lanes.

## rev0066 focus
- assertion posture so Harbor can say whether one verification result is observe-only, warn, blocking, or unknown/not-observed without mutating row meaning;
- waiver receipts so temporary exceptions have scope, owner, expiry, and reviewed evidence instead of lingering as folklore;
- observed-value notes so status badges do not hide measured value, evaluation window, or missing-evidence posture;
- next pressure: restatement receipts, semantic front doors, and change-history lanes.

## rev0065 focus
- change classes so Harbor classifies what kind of lane edit it is proposing before calling the edit compatible;
- compatibility verdicts so “safe in place,” “safe with bridge window,” “successor required,” and “historical restatement” stay explicit;
- shadow diffs so candidate edits are compared across affected consumer slices without letting one green check counterfeit universal safety;
- next pressure: restatement receipts, semantic front doors, and change-history lanes.

## rev0064 focus
- contract tiers so Harbor can promise shape, meaning, assertion, and service posture separately instead of through one vague public contract;
- assertion planes so schema/freshness/volume/custom checks verify a lane without silently redefining row meaning;
- consumer-obligation slices so one downstream dependency does not inflate into a universal promise for every field and every consumer;
- next pressure: restatement receipts, semantic front doors, and change-history lanes.

## rev0063 focus
- stability rings so rehearsal, candidate, published, and historical surfaces do not all pretend to make the same promise;
- compatibility windows so a curated lane says what kind of change is currently safe instead of relying on folklore;
- deprecation receipts so published-lane retirement or supersession leaves overlap and warning history;
- next pressure: restatement receipts, semantic front doors, and change-history lanes.

## rev0061 focus
- grain contracts before dimension/measure bloom, so every durable Harbor surface says what one row/card/receipt represents;
- late-bound evolution lanes instead of destructive schema rewrites or giant early registries;
- facet-version notes for optional metadata so experiments and neighbor-facing hints stay smaller than the core contract;
- next pressure: restatement receipts, semantic front doors, and change-history lanes.

## rev0059 focus
- schema-source notes instead of flattening inline schema, fetched `schema_uri`, and preconfigured knowledge into one type-truth story;
- receiver-enriched detail cards instead of universalizing one receiver's filtered or extended view;
- cache-staleness detail warnings instead of generic invalid-token or invalid-target failure language when fetched metadata/schema guidance drifts;
- next pressure: actionable-body replay fences, trusted-set snapshots, and schema-version receipts.

## Earlier focus notes retained from prior archive ordering

## rev0077 focus
- measurement proof cuts so source unit, canonical machine unit, display render, and conversion/rate basis do not collapse into one scalar-looking truth;
- rate witnesses so converted money remains a dated, sourced, restatable derived view rather than original-denomination truth;
- promotion obligations so every future datacube noun has a proof packet before it graduates from watchlist/process residue;
- next pressure: semantic-front-door export receipts, public contract subsets, freshness thresholds, join/fanout fences, and optional row-lineage sidecars under the proof-obligation gate.

## rev0076 focus
- option reservations so Harbor can collect excellent datacube ideas without promoting them before specimens prove the need;
- cube watchlist discipline so observation components, semantic exports, derived views, sidecars, watermarks, row lineage, schema transforms, assertion compilers, and cube/pivot query affordances remain tracked but unchosen;
- derived-view and sidecar humility so helper metadata stays smaller than row meaning, smaller than published-lane truth, and smaller than any premature warehouse, semantic-layer, streaming-engine, or sidecar-registry commitment;
- next pressure: semantic-front-door export receipts and contract-subset specimen pressure, while measurement-semantics remains the single next queued pressure test.

## rev0075 focus
- temporal witnesses so occurrence, validity, knowledge/currentness, and published-cut time do not collapse into one flattering “latest” story;
- contract subsets and freshness-basis witnesses so public promise, assertion evidence, and threshold math stay visibly distinct;
- lineage guards so join-relationship notes, history-loss posture, and optional row-lineage sidecars stay smaller than row meaning and smaller than any premature semantic front door or universal row-ID regime;
- next pressure: semantic-front-door export receipts and contract-subset specimen pressure, while measurement-semantics remains the single next queued pressure test.

## rev0074 focus
- measurement semantics so Harbor can say what quantity family a lane carries before scalar-looking values start impersonating one shared truth;
- canonical-unit notes so coded machine-comparable units stay explicit instead of hiding behind display suffixes or formatting;
- currency-rate witnesses so converted money outputs keep source/target currency, rate source, and as-of basis visible;
- next pressure: semantic front doors and restatement-promotion criteria.

## rev0073 focus
- change-history lanes so Harbor can say whether a lane is current-state, changed-rows, full change-history, or net-change instead of publishing one fake “history” surface;
- replay cuts so every history-shaped lane names the commit/snapshot/time basis and whether the slice is moving head or frozen cut;
- restatement receipts so corrected historical publications leave explicit residue when late data or new computation changes old answers;
- next pressure: semantic front doors, unit/currency semantics, and restatement-promotion criteria.

Current revision focus (`rev0095`): executable crossing evidence, scope fixtures, and portal-net bridge.


## rev0094 roadmap delta

- Keep CrossingRecord v0 as a specimen-shape proof target, not a schema.
- Use scope algebra as review vocabulary until repeated comparison failures justify code.
- Treat warning lifecycle as scoped public-copy process residue; do not add status-page product semantics.
- Make `F090` test SlopOS-style executable crossing evidence before any Harbor-Core promotion.

## rev0107 focus
- cross-cube lineage import so SlopOS, Foundry, Steward, Schell, ViewFS, Ward, and Helm evidence enters Harbor as quarantined material rather than inherited status;
- foreign material and parent-context checks so archive digests, fragment families, native statuses, and parent manifests are recorded before local use;
- scope translation and authority quarantine so foreign currentness, repair, consent, delegation, erasure, compliance, and public badges cannot cross membranes unexamined;
- lineage bridge and recheck plan so companion evidence can inform Harbor's F101 lineage without becoming a trust root or conflict-resolution engine;
- next pressure: foreign-import revocation and correction after companion withdrawal, supersession, dispute, expiry, or re-scope.

## Rev0110 route note

F105 closes the user-visible explanation seam. The next work is F106: response-event capture after explanation cards, keeping inspect/recheck/export/dismiss/appeal/share/acknowledge signals weaker than comprehension, consent, reliance, repair, legal posture, or compliance status.
