# SlopOS / companions evaluation — pass XLIV

This pass re-checks Harbor against SlopOS and the sibling cubes after adding a browser-messaging specimen, and again chooses one narrow crossing seam over any early family bloom.

## What the current cubes still teach
- **SlopOS** remains the strongest restraint mechanism. Its auth-result and response-packaging boundaries already insist that authorization responses, request packaging, exact issuer checks, and fetched metadata stay provider-local rather than becoming portable login/result truth. That lines up cleanly with Harbor treating popup/iframe `postMessage` mechanics as exact local crossing residue, not as a new durable account or session substrate.
- **SlopOS** also keeps reinforcing the design-phase habit Harbor needs most: local exact-match validation is real value even when it never becomes a public portable noun. A receiver-origin witness can stay that small.
- **Ward** keeps contributing the right operational instinct: historically real receipt material can still be too weak to spend through safely. A browser-messaging finish that lands on the wrong origin or wrong lane should bottom out as inspectable residue rather than counterfeit success.
- **Helm** keeps reminding Harbor that host-owned UI chrome can be honest and compact while still staying below exact basis. That matters here because popup labels or iframe framing should never outrank sender/receiver/lane checks.
- **Foundry** keeps the foreign-ground lesson alive: when a crossing returns from a foreign runtime or window, the membrane should preserve exactly how it came back instead of flattening that detail into “success.”

## Harbor consequence
Harbor should keep this move modest:
- add one specimen around receiver-origin witness, secondary-window lane, and message-origin fence;
- keep popup/iframe browser messaging visibly smaller than durable issuer/account/session/adoption truth;
- collect effective-target echo as inspiration only;
- and leave any future registry of browser lanes, message schemas, or universal web-message safety classes outside Harbor for now.

## Still-not-yet decisions
- Whether **receiver-origin witness** deserves its own Harbor family, or should remain only an annotation on existing lane / basis / aftermath surfaces.
- Whether **secondary-window lane** belongs in Harbor at all, or should remain only a browser-detour detail that leaks out through a smaller veto/receipt vocabulary.
- Whether **effective-target echo** belongs in Harbor, or should stay a neighboring OAuth issuance-time confirmation idea until more wrong-target specimens accumulate.
