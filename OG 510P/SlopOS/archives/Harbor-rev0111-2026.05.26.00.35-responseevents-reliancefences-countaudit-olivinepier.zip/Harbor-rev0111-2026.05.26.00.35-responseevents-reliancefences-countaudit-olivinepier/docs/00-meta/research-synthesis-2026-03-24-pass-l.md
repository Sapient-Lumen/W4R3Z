# Research synthesis — pass L

This pass keeps Harbor narrow and learns five compatible things at once: **token-time resource asks are further restrictions on a broader grant; refresh-token requests can narrow but must not expand; returned resource sets may contain server-assigned additions as long as an accepted requested anchor survives; omission of `resource` needs typed honesty; and Harbor should preserve narrowing and refusal residue without freezing a portable entitlement model too early.**

## Outside lessons
1. **Token-time resource asks are restrictions, not fresh entitlement creation.**  
   RFC 8707 says that when the `resource` parameter is used at the token endpoint, including for `authorization_code` and `refresh_token`, local policy may limit acceptable resources to those originally granted or a subset thereof. In the authorization-code case, when the requested resources are a subset of the original grant, the access token is based on that subset while any returned refresh token remains bound to the full original grant. Harbor should preserve a **grant-bounded narrowing floor** rather than flattening token-time narrowing into fresh durable entitlement truth.

2. **Refresh must not silently widen.**  
   The March 2026 resource-token-response draft says token-request resources are an additional restriction on the underlying grant, token-request values must stay within the grant, and refresh-token requests MUST NOT expand the set of authorized resources beyond those previously bound to the grant. Harbor should keep refresh-time narrowing visibly smaller than durable grant truth.

3. **Returned resources can include valid additions without being a mirror of the ask.**  
   The same draft says that when one or more requested resources are acceptable, the returned set may be a strict subset of the requested resources and may also contain additional **server-assigned** resources, but only alongside at least one accepted requested resource. Harbor should preserve a **server-assigned addition** rather than pretending every returned identifier was requested verbatim.

4. **Scope can imply extra resource reach.**  
   Appendix A.2 of the same draft gives an OpenID Connect-style example where `openid` implies access to the UserInfo endpoint, so the response returns both the client-requested API resource and an authorization-server-derived UserInfo resource. That is a strong reminder that scope-defined additions are smaller than durable entitlement truth and should remain inspectable as additions, not universal capability.

5. **Refusal needs a typed rail.**  
   RFC 8693 warns that multi-target requests broaden via the Cartesian product of scope and target services and says `invalid_target` can be used when a client asks for too many targets at once. The March 2026 resource-token-response draft likewise requires `invalid_target` when none of the requested resources are acceptable, and says clients must treat that as terminal for the current turn. Harbor should preserve a **target-refusal rail** instead of dissolving target refusal into generic auth failure.

## Resulting Harbor move
Do not decide yet whether Harbor needs durable nouns such as **grant-bounded narrowing floor**, **server-assigned addition**, or **target-refusal rail**.
For this revision:
- add one specimen around refresh-time further restriction, scope-defined extra resources, no-request assigned resources, and typed refusal;
- preserve the difference between “what the original grant authorized,” “what the token request narrowed to now,” “what additional resource identifiers the server assigned,” “what type of refusal bottomed the turn out,” and “none of those facts by themselves settle durable entitlement/account/session/adoption truth”;
- and collect **requested-anchor minimum** plus **assigned-only lane** as inspiration only, without promoting a new registry today.

## Fresh ideas worth stealing
- **grant-bounded narrowing floor** — compact reminder that token-time asks can narrow within a grant without silently widening it.
- **server-assigned addition** — inspectable note that an extra returned resource came from server policy, config, or requested scope rather than exact client request text.
- **target-refusal rail** — typed explanation path for `invalid_target` rather than generic auth failure.
- **requested-anchor minimum** — future-facing reminder that returned resource sets should stay tied to at least one accepted requested anchor when the client did ask for resources.
- **assigned-only lane** — future-facing reminder that a no-request token response may still return an assigned resource set, and that this is different from exact request mirroring.
