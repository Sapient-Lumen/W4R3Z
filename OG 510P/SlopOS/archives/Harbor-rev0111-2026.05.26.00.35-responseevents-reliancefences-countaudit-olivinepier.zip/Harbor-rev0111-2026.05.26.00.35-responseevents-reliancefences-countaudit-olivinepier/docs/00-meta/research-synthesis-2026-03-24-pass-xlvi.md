# Research synthesis — pass XLVI

This pass keeps Harbor narrow and learns five compatible things at once: **chooser cleanup is useful even when it is only advisory, stale credentials deserve visible quarantine rather than fake success, display labels can be refreshed without settling account truth, sign-out signals should change mediation posture without pretending to revoke everything everywhere, and capability-gated cleanup is worth stealing without freezing a new family today.**

## Outside lessons
1. **Cleanup signals are real, but they stay smaller than truth.**  
   WebAuthn Level 3 adds `signalUnknownCredential()` and says the authenticator then deletes or hides the credential from future authentication ceremonies. Harbor should preserve a small **cleanup pulse** rather than overreading one signal as durable logout, durable account deletion, or durable chooser truth.

2. **Full-list cleanup is powerful and dangerous.**  
   `signalAllAcceptedCredentials()` lets a relying party provide the accepted credential list, but the spec warns that omitted valid credential IDs may be removed or hidden, potentially irreversibly, and says relying parties must exercise care. Harbor should therefore preserve a **stale-chooser quarantine** path instead of pretending cleanup lists are infallible truth.

3. **Display refresh is worth modeling separately from identity.**  
   `signalCurrentUserDetails()` signals a user’s current `name` and `displayName`, and the authenticator then updates other UI for the matching credential. Harbor should steal a **display-refresh residue** idea: labels can get fresher without becoming durable adopted-account truth.

4. **Cleanup may be delayed, partial, or capability-gated.**  
   WebAuthn Level 3 notes that authenticators might not be attached when these signal methods run, so relying parties may choose to invoke them periodically, and the spec also exposes capability discovery for the signal methods. Harbor should treat cleanup and refresh as best-effort residue rather than as synchronous global state change.

5. **Sign-out posture is smaller than universal logout.**  
   Credential Management’s `preventSilentAccess()` is explicitly described as a signal from the origin that the user signed out, setting a flag so credentials will not be automatically handed back next time. Harbor should preserve this as a **mediation reset** instinct, not as proof that all accounts, sessions, or browser memory everywhere are gone.

## Resulting Harbor move
Do not decide yet whether Harbor needs durable nouns such as **cleanup pulse**, **stale-chooser quarantine**, or **display-refresh residue**.
For this revision:
- add one specimen around chooser cleanup and display refresh after account deletion, credential rotation, and local sign-out;
- preserve the difference between “the local side asked the chooser/authenticator to hide or refresh something,” “the browser next asks for mediation,” “a stale credential candidate was quarantined or revalidated,” and “none of those facts settle durable account/session/adoption truth”;
- and collect **capability-gated cleanup** plus **mediation reset** as inspiration only, without promoting a new family today.

## Fresh ideas worth stealing
- **cleanup pulse** — compact advisory signal that stale chooser or authenticator entries should be hidden, refreshed, or re-mediated.
- **stale-chooser quarantine** — explicit local posture for a credential or account candidate that still appears in UI but is no longer safely accepted here.
- **display-refresh residue** — small note that labels or names were refreshed for future chooser UI without changing durable account truth.
- **capability-gated cleanup** — future-facing reminder that cleanup/refresh paths should be discovered and used only when the client actually supports them.
- **mediation reset** — small sign-out aftermath that changes the next credential-return posture without pretending to be universal logout.
