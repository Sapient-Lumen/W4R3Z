# Research synthesis — pass XCVII, verifier disagreement and policy-epoch drift

**Revision:** `rev0097`  
**Date:** 2026-05-22  
**Question:** How should Harbor handle multiple verifier results when policies, epochs, currentness checks, scopes, and issuer status disagree?

## Result

Harbor should add a deterministic verifier-disagreement bundle, not an arbitration model. F092 therefore introduces a fixture and checker for accept/refuse splits, currentness unknowns, policy changes after public copy, issuer status changes after timestamp, sealed/public incomparable bases, local/global scope splits, and hostile badge collapse attempts.

The central split is:

```text
receipt set -> verifier runs -> policy epoch comparison -> disagreement analysis -> badge posture -> aftermath
```

A verifier decision can be accepted as evidence while every larger interpretation is blocked.

## External lessons folded in

- SLSA verification guidance keeps provenance useful only after someone inspects it against expectations. Harbor imports the idea that a provenance result is a verifier judgment over named expectations, not broad trust.
- Sigstore Policy Controller treats supply-chain metadata checks as admission-policy decisions. Harbor borrows the scoped-decision discipline while refusing to convert admission into future reliance.
- TUF uses versions, expirations, and rollback/freeze checks to make stale metadata explicit. Harbor borrows the need for epoch/currentness checks without becoming an update framework.
- C2PA validation separates validation work, status codes, and user presentation. Harbor treats media/content-credential validation status as evidence that needs public badge humility.
- in-toto verification depends on layouts, link metadata, and inspections. Harbor preserves verifier basis before comparing results.
- OPA decision logs and bundles keep policy, input, bundle metadata, and policy updates visible. Harbor uses this as a pattern for policy id, policy digest, policy epoch, and input digest requirements.

## New executable surfaces

- `docs/00-meta/datacube-verifier-disagreement-policy-epoch-drift.md`
- `docs/40-verification/harbor-verifier-disagreement-policy-epoch-bundle-v0.md`
- `fixtures/harbor-verifier-disagreement-policy-epoch-bundle-v0.json`
- `tools/harbor_verifier_disagreement_harness.py`
- `tools/check_harbor_verifier_disagreement_bundle.py`
- `docs/30-architecture/specimen-flow-92-verifier-disagreement-policy-epoch-drift.md`

## New watchlist handles

- `verifier_run.policy_digest`
- `policy_epoch.relation`
- `preserved_disagreement`
- `majority_or_latest_wins_refused`
- `badge_withheld`
- `split_status`
- `prior_epoch_retained_with_notice`
- `currentness_unknown`
- `issuer_status_after_timestamp`
- `incomparable_policy_family`

## Practical design rule

A verifier-disagreement record may become Harbor evidence only when it carries:

```text
subject digest + receipt set + verifier run digests + policy id/digest/epoch + input digest + decision/currentness basis + epoch relation + disagreement class + badge posture + non-promises + hostile rejection cases
```

Without those fields it remains source material, not Harbor residue.

## Followthrough result

`F092` is now complete. `F093` should pressure-test property-style fixture generation and mutation coverage across the three executable bundles: CrossingRecord v0, receipt import, and verifier disagreement. The goal is generated negative coverage without promoting schemas or hiding the hand-authored hostile cases.
