# SlopOS / companions evaluation — pass L

This pass re-checks Harbor against SlopOS and the sibling cubes after adding a grant-bounded narrowing / server-assigned-addition specimen, and again chooses one narrow crossing seam over any early family bloom.

## What the current cubes still teach
- **SlopOS** remains the strongest restraint mechanism. Its provider-local auth-result, browser-session, and authorization-context boundaries already keep granted scope, provider-local auth state, and portable export semantics separate. That lines up with Harbor treating server-assigned resource additions and refresh-time narrowing as crossing residue rather than as a portable entitlement registry.
- **SlopOS** also keeps teaching the same design-phase lesson: exact local auth and grant context can matter deeply without blooming into a portable family. Harbor should borrow that humility directly for grant-bounded narrowing floors and assigned-resource additions.
- **Ward** keeps reinforcing exact-basis and typed-veto posture: if the current turn drifts outside the allowed target set, the answer should be an explicit refusal rail before any stronger consequence talk.
- **Helm** keeps contributing subset honesty: a smaller returned set can be the truthful answer, and it should remain inspectable rather than inflated into a permanent capability family.
- **Foundry** keeps the aftermath lesson alive: an outside-issued token can carry smaller target truth while remaining visibly weaker than adopted runtime authority.
- **Steward** keeps the accountability lesson alive: typed refusal and assigned additions deserve receipts, not generic “auth changed” blur.

## Harbor consequence
Harbor should keep this move modest:
- add one specimen around **grant-bounded narrowing floor**, **server-assigned addition**, and **target-refusal rail**;
- keep original grant breadth, token-time restriction, returned requested anchors, returned assigned additions, typed refusal, and durable entitlement/adoption meaning visibly separate;
- collect **requested-anchor minimum** and **assigned-only lane** as inspiration only;
- and leave any future registry of portable entitlements, target catalogs, or resource-assignment policy outside Harbor for now.

## Still-not-yet decisions
- Whether **grant-bounded narrowing floor** deserves its own Harbor family, or should remain only an annotation on request and aftermath surfaces.
- Whether **server-assigned addition** belongs in Harbor at all, or should remain only a smaller note attached to specific token-response specimens.
- Whether **target-refusal rail** belongs in Harbor, or should stay a typed local explanation that never blooms into a portable entitlement or target-policy registry.
