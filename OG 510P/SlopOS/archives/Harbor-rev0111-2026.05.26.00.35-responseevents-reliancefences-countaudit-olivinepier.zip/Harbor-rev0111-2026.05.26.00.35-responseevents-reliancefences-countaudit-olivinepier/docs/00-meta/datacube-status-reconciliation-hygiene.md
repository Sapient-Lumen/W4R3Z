# Datacube status reconciliation hygiene

**Status:** design-phase review surface for `rev0089`; not an ADR, schema, status-page product, claims tribunal, customer-notification system, compliance workflow, VEX/CSAF profile, in-toto predicate, transparency-log policy, moderation process, legal dispute process, reputation system, or final SlopOS datacube constitution.

## Why this exists

`rev0088` let Harbor record stale downstream impact, consumer acknowledgements, remediation attestations, use-attestation notes, and safe public impact statements. `F084` applies the next pressure: those claims do not stay tidy.

A downstream owner can claim remediation while a consumer still sees stale output. An acknowledgement can expire. A third-party impact report can contradict Harbor's assessment. A non-use attestation can be impossible to verify. A public status banner can drift out of sync with the proof packet. Harbor needs process language for reconciling status claims without becoming a court, reputation system, or universal incident workflow.

## Tight stance

- **Dispute is a status, not a failure of process.** If evidence conflicts, Harbor should label the conflict and scope it, not force premature closure.
- **Expired acknowledgement returns to unknown, not false.** A stale acknowledgement no longer supports current posture, but it is not evidence that the consumer ignored, repaired, or broke anything.
- **Contradictions need maps, not winners.** External reports may be right about one scope and wrong about another; reconcile artifact, cut, label, audience, window, and method before ranking claims.
- **Unverifiable use attestations are still evidence about the attester.** They may show cooperation or intent, but they cannot prove non-use, repair, deletion, model unlearning, or downstream notification.
- **Public status must be synchronized with proof basis.** A banner that says resolved while the proof packet says disputed is a public-copy bug, even when the source data is correct.
- **Challenge packets must stay smaller than tribunals.** Harbor can record who challenged what, evidence requested, evidence received, unresolved fields, and safe public wording without owning a legal or compliance process.
- **Transparency proves publication, not truth.** Inclusion, signature, or timestamp evidence can show a claim existed at a time; it does not prove the claim is correct.

## Status states under observation

These are deliberately composable labels, not a final state machine.

| State | Meaning | Counterfeit to avoid |
| --- | --- | --- |
| `claim_received` | Harbor received a remediation, use, impact, or status claim | treating receipt as verification |
| `challenge_open` | a party challenges scope, evidence, or result | treating challenge as proof of falsehood |
| `evidence_requested` | Harbor requested named supporting evidence | implying evidence exists |
| `evidence_partially_received` | some support arrived but gaps remain | calling the claim verified |
| `acknowledgement_expired` | an acknowledgement is past its recheck horizon | treating it as refusal or non-use proof |
| `attestation_unverifiable` | use/non-use/remediation claim lacks checkable basis | upgrading cooperation to proof |
| `contradiction_observed` | two claims conflict on a named subject/window | picking a winner without scope map |
| `scope_mismatch` | claims describe different artifacts, cuts, audiences, or windows | inventing contradiction where there is none |
| `reconciled_same_scope` | conflict resolved for a named scope | overgeneralizing to adjacent scopes |
| `reconciled_scope_mismatch` | conflict explained by different scope | hiding unresolved sibling claims |
| `public_status_stale` | outward status page/banner/card lags proof packet | treating UI as source truth |
| `public_status_repaired` | public status has been realigned with proof packet | pretending every mirror/snippet updated |
| `unresolved_for_now` | current evidence cannot settle the claim | silent closure |
| `unsafe_to_summarize` | public copy cannot safely compress the dispute | leaking sealed evidence or overclaiming |

## Candidate process handles

These handles are watchlist vocabulary, not promoted schema.

### `status_reconciliation_packet`

A bounded packet for comparing claims about one stale-impact or remediation subject.

Candidate fields:

- source artifact, source cut, correction anchor, payload digest, label digest, and successor relation;
- claim ids, claim authors, authority basis, subject artifact/copy, target audience, use window, method, and evidence lane;
- comparison axes: same subject, same version/cut, same label digest, same audience, same time window, same remediation action, same public status surface, same evidence basis;
- result: compatible, contradicted, scope mismatch, partially reconciled, unresolved, unverifiable, stale, withdrawn, superseded, or refused;
- public-safe status and non-promises.

### `remediation_challenge_receipt`

A record that a remediation claim has been challenged.

Candidate fields:

- challenged remediation id, subject, action, actor, timestamp, claimed result, and residual-risk note;
- challenger class: consumer, source owner, downstream owner, auditor, external researcher, reporter, automated check, or unknown;
- challenge type: stale copy still visible, action incomplete, wrong subject, label missing, evidence inaccessible, model/eval unrepaired, status page drift, user notification unproven, or unsupported universal claim;
- evidence requested, evidence received, sealed evidence posture, response deadline/recheck horizon, and interim public status.

### `acknowledgement_expiry_note`

A recheck note for acknowledgements that no longer support current state.

Candidate fields:

- acknowledgement id, notice id, correction anchor, acknowledged subject set, actor authority, timestamp, recheck horizon, and expiry reason;
- current result: renewed, expired, replaced by remediation, replaced by non-use claim, challenged, unreachable, refused, or unknown;
- safe consequence: re-notify, mark stale, keep historical-only, escalate to challenge, or no action.

### `external_impact_claim_map`

A scope map for third-party impact reports.

Candidate fields:

- external report id, reporter class, report timestamp, cited artifact/copy, quoted values/labels, evidence basis, and public URL or sealed intake id;
- Harbor matching result: exact subject match, stale citation, wrong version, label-only drift, numeric drift, audience mismatch, suppression/noise misunderstanding, unknown basis, or unverifiable;
- relation to Harbor status: confirms, contradicts, narrows, broadens, duplicates, stale, unrelated, or unsafe to assess publicly;
- safe reply and non-disclosure boundary.

### `use_attestation_challenge_note`

A challenge or limitation note for used/not-used/unknown claims.

Candidate fields:

- attestation id, attester authority, subject, use window, method, reviewed logs/manifests/cards, and limitations;
- challenge reason: no logs, incomplete window, wrong artifact id, generated explainer cache omitted, model/eval path excluded, manual review only, stale source lock, or expired retention;
- result: accepted for scope, limited, unverifiable, contradicted by public evidence, contradicted by private evidence, withdrawn, or recheck required.

### `public_status_sync_receipt`

A receipt that outward status matches the proof packet.

Candidate fields:

- status surface id: page, banner, catalog card, dataset card, model/eval card, search snippet, release note, generated explainer, or mirror;
- expected status from proof packet, observed status, observed time, payload/label/status digest, status author, and update authority;
- mismatch type: resolved-versus-disputed, fixed-versus-claimed, current-versus-stale, no-warning, wrong successor, missing non-promises, missing localization/accessibility label, or unsafe summary;
- repair action, observed repair, remaining mirrors/caches, and next recheck.

### `safe_disputed_status_statement`

A public-facing statement for unresolved or challenged status.

Minimum content:

- current source artifact to use;
- claim under challenge and the subject it covers;
- what is confirmed, unknown, disputed, expired, unverifiable, or unsafe to disclose;
- safe next action for consumers;
- explicit non-promises: universal recall, complete downstream repair, model unlearning, raw-value disclosure, all consumers notified, or proof of non-use.

## Anti-counterfeit checks

- If a challenge lacks a subject, claim id, and challenged field, it is feedback, not a challenge receipt.
- If a contradiction map does not compare artifact/cut/audience/window/method, it cannot decide conflict.
- If an acknowledgement expiry note implies the consumer failed, repaired, or used the artifact, it overclaims.
- If an unverifiable non-use claim is displayed as `not_used`, it counterfeits proof.
- If a public status says resolved while remediation is only claimed or disputed, the public status is stale.
- If a transparency receipt is used as evidence that a claim is true, Harbor is confusing publication with verification.
- If a status reconciliation packet does not preserve sealed/auditor-only boundaries, it risks leaking replay or suppressed aggregate evidence.
- If conflicting external reports are collapsed into one severity value without scope, Harbor is inventing a tribunal.
- If public status repair does not include label digest/non-promise checks, it can still be misleading.
- If the only evidence of resolution is a generated explanation, the dispute remains unresolved for proof purposes.

## Minimum proof obligations before any promotion

A candidate status-reconciliation noun must show at least these before it graduates from process residue:

1. It names source artifact, correction anchor, stale copy or downstream subject, claim id, claimant, challenged field, evidence lane, and target audience.
2. It distinguishes receipt, acknowledgement, expired acknowledgement, claim, challenge, partial evidence, verification, contradiction, scope mismatch, public status drift, and unresolved-for-now.
3. It compares claims on subject, version/cut, label digest, audience, time window, method, actor authority, and residual risk before saying compatible or contradictory.
4. It records whether Harbor observed, verified, merely received, challenged, expired, or refused a claim.
5. It produces safe public wording that does not leak suppressed values, sealed evidence, private logs, raw replay payloads, or unverifiable model/eval internals.
6. It can repair public-status drift without claiming every mirror, snippet, cache, model, eval, or consumer copy was repaired.
7. It has recheck/expiry semantics for acknowledgements, claims, challenges, and public status surfaces.
8. It has an honest terminal-for-now state for unresolved, unverifiable, unsafe-to-summarize, and externally contradicted situations.

## Promotion triggers

Only consider durable nouns after repeated specimens show that:

- disputed remediation claims recur across catalogs, dashboards, dataset cards, generated explainers, and model/eval reports;
- acknowledgement expiry repeatedly changes safe consumer guidance;
- external impact reports repeatedly need scope reconciliation rather than simple correction;
- public status drift repeatedly misleads consumers after proof packets change;
- SlopOS or companions repeatedly need the same challenge/expiry/contradiction/status-sync fields.

Until then, keep `status_reconciliation_packet`, `remediation_challenge_receipt`, `acknowledgement_expiry_note`, `external_impact_claim_map`, `use_attestation_challenge_note`, `public_status_sync_receipt`, `safe_disputed_status_statement`, and `unresolved_for_now_note` as process residue.

## Explicit non-decisions

This document does not choose a status page product, issue tracker, ticketing workflow, customer notification system, public dispute UI, claims tribunal, moderation system, legal workflow, compliance regime, VEX/CSAF profile, in-toto predicate, transparency-log policy, C2PA profile, reputation score, reporter trust model, model-unlearning process, public status API, or final SlopOS datacube shape.
