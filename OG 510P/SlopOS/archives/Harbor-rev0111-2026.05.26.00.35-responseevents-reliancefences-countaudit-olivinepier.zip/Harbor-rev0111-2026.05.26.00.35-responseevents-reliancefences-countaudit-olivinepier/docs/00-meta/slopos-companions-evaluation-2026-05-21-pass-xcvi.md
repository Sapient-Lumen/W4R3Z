# SlopOS and companions evaluation — pass XCVI

**Revision:** `rev0096`  
**Date:** 2026-05-21  
**Focus:** transparency/provenance receipt import, binding/currentness cuts, verifier policy epochs, redacted proof boundaries, and issuer-compromise rechecks.

## SlopOS pressure

SlopOS gives Harbor an upstream habit worth preserving: an accepted record must stay smaller than the thing it reports. F090 applied that to portal-network crossings. F091 applies it to receipt-rich systems.

The Harbor-side receipt bundle keeps SlopOS-compatible discipline by requiring:

- exact subject digest binding;
- deterministic fixture output;
- accepted and rejected cases;
- no emitted id for rejected candidates;
- digest-bound verdict summaries;
- explicit non-promises per receipt family;
- recheck triggers for compromise, log/currentness, manifest binding, policy epoch, and scope substitution.

Harbor still does not import SlopOS internals, SlopOS policy state, or final SlopOS datacube shape.

## Companion pressure

- **Helm:** repair and intervention traces push receipt import to preserve recheck triggers instead of green-badge finality.
- **Schell:** minimization and forgetting surfaces push redacted proofs to remain selected-claim evidence rather than disclosure entitlement.
- **ViewFS:** trusted-path and consent fences push content credentials and verifier results to stay presentation/verification events, not user understanding.
- **Ward:** delegation warrants push issuer authority and verifier policy to remain scoped, named, and revocable.
- **Foundry:** classification pins and witness crosswalks push subject digest, manifest binding, and label preservation into checks.
- **Steward:** replay and pushback budgets push currentness to be checkpoint/epoch-bound, not a floating current-state claim.

## Harbor delta

`rev0096` adds:

- a transparency/provenance receipt import design surface;
- a deterministic fourteen-case receipt bundle;
- a harness and checker wired into `make check` and `package-release`;
- proof obligations `PO-TP-001` through `PO-TP-006`;
- specimen flow 91;
- pass XCVI research and companion evaluation surfaces;
- source/register, lessons, inspiration, manifest, roadmap, context, and briefing updates.

## Deliberate non-promotion

This pass does not promote a receipt-import schema, transparency-log reliance policy, C2PA verifier profile, in-toto/SLSA predicate profile, SCITT profile, timestamp authority policy, redaction proof format, issuer-reputation model, legal status workflow, public status API, badge model, or final SlopOS datacube shape. It only promotes the expectation that receipt-rich proposals must survive positive and negative executable fixtures.
