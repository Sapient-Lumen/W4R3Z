## Pass C additions
- **EXT-GITHUB-ARTIFACT-ATTESTATIONS-2026** — GitHub Docs, Artifact attestations — https://docs.github.com/en/actions/concepts/security/artifact-attestations
  - key: artifact attestations create signed claims establishing build provenance, with repository/workflow/commit/event context.
  - harbor_use: source and build claims must remain checkable evidence, not ambient trust.
- **EXT-GITHUB-ATTESTATION-VERIFY-2026** — GitHub REST API docs for artifact attestations — https://docs.github.com/en/rest/users/attestations
  - key: meaningful security benefits require cryptographic verification of signature/timestamps and signer identity validation.
  - harbor_use: attestation presence is not enough; verifier context and identity checks must travel with the observation.
- **EXT-REPRODUCIBLE-BUILDS-RECORDING-2026** — Reproducible Builds, Recording the build environment — https://reproducible-builds.org/docs/recording/
  - key: relevant build-environment information should be defined or recorded.
  - harbor_use: future release-package proof must capture environment and toolchain basis without claiming a trust root.

## Pass XCVII additions
- **EXT-SLSA-VERIFYING-ARTIFACTS-2026** — SLSA, Verifying Artifacts — https://slsa.dev/spec/v1.0/verifying-artifacts
  - key: provenance only helps when inspected by a verifier against expectations; verification is a separate act.
  - harbor_use: verifier pass/fail must remain named policy/input evidence, not broad trust.
- **EXT-SIGSTORE-POLICY-CONTROLLER-2026** — Sigstore Policy Controller overview — https://docs.sigstore.dev/policy-controller/overview/
  - key: admission decisions can enforce supply-chain metadata policy and resolve image tags at admission time.
  - harbor_use: admission-time verifier decisions are scoped to policy and moment, not future reliance or global approval.
- **EXT-TUF-SPEC-LATEST-2026** — The Update Framework Specification — https://theupdateframework.github.io/specification/latest/
  - key: metadata version, expiration, rollback, and freeze checks make stale or older metadata explicitly unsafe.
  - harbor_use: policy epoch and currentness drift need monotonicity/expiry checks without importing update-system governance.
- **EXT-C2PA-VALIDATION-2-4-2026** — C2PA Technical Specification 2.4 validation/security considerations — https://spec.c2pa.org/specifications/specifications/2.4/specs/C2PA_Specification.html
  - key: manifest consumers validate signatures, credentials, and assertions, then present status to users for judgment.
  - harbor_use: validation status is a user-facing evidence surface, not automatically a single badge truth.
- **EXT-IN-TOTO-SPEC-VERIFY-2026** — in-toto specification, verification and inspections — https://github.com/in-toto/docs/blob/master/in-toto-spec.md
  - key: clients verify layouts/links and may perform inspections against the delivered product.
  - harbor_use: verifier outcomes depend on layout, link metadata, and inspection basis; disagreement should preserve basis.
- **EXT-OPA-DECISION-LOGS-2026** — Open Policy Agent, Decision Logs — https://openpolicyagent.org/docs/management-decision-logs
  - key: decision logs include the policy queried, input, bundle metadata, and other context for audit/debugging.
  - harbor_use: policy decisions need input/policy/bundle trace before they can be compared.
- **EXT-OPA-BUNDLES-2026** — Open Policy Agent, Bundles — https://openpolicyagent.org/docs/management-bundles
  - key: policies and data loaded from bundles can update without restart and are enforced immediately, with eventual consistency concerns.
  - harbor_use: policy epoch drift must be explicit; a later bundle is not retroactive erasure of an earlier decision.


## Pass XCVI additions
- **EXT-SCITT-ARCHITECTURE-2025** — IETF Datatracker, draft-ietf-scitt-architecture-22 — https://datatracker.ietf.org/doc/draft-ietf-scitt-architecture/
  - key: signed statements, transparency receipts, registration policies, relying parties, auditors, and divergent transparency services stay separate.
  - harbor_use: receipt inclusion can prove registration evidence without truth, currentness, or policy satisfaction.
- **EXT-C2PA-SPEC-2-4-2026** — C2PA Technical Specification 2.4 — https://spec.c2pa.org/specifications/specifications/2.4/specs/C2PA_Specification.html
  - key: content credentials/manifests bind provenance information to digital assets while implementations must handle versioning and unknown data.
  - harbor_use: manifest/content binding is useful evidence but not real-world authenticity, editorial approval, or transform survival.
- **EXT-IN-TOTO-ATTESTATION-2026** — in-toto Attestation Framework — https://github.com/in-toto/attestation
  - key: attestations generate verifiable claims about how software is produced, with subject and predicate discipline.
  - harbor_use: subject/material/predicate structure informs receipt import without promoting one predicate profile.
- **EXT-SLSA-PROVENANCE-V1** — SLSA Provenance v1 — https://slsa.dev/spec/v1.0/provenance
  - key: provenance describes where, when, and how an artifact was produced.
  - harbor_use: build provenance remains smaller than deployment truth, dependency cleanliness, vulnerability status, or broad trust.
- **EXT-SIGSTORE-REKOR-2026** — Sigstore Rekor transparency log overview — https://docs.sigstore.dev/logging/overview/
  - key: Rekor supports storing and retrieving entries, inclusion proof, and log integrity verification.
  - harbor_use: log inclusion and integrity checks are evidence slices, not semantic approval.
- **EXT-RFC9162-CT-2022** — IETF RFC 9162, Certificate Transparency Version 2.0 — https://datatracker.ietf.org/doc/html/rfc9162
  - key: transparency-log inclusion and auditing/consistency ideas are useful for append-only observation systems.
  - harbor_use: borrow checkpoint/currentness separation without making logs into verdicts.
- **EXT-RFC3161-TSP-2001** — IETF RFC 3161, Time-Stamp Protocol — https://datatracker.ietf.org/doc/html/rfc3161
  - key: a timestamp authority creates tokens to indicate that data existed at a particular time.
  - harbor_use: timestamp anchors become message-imprint/time evidence, not event time or source truth.


## Pass XCIV additions
- **EXT-MCP-SPEC-2025-11-25** — Model Context Protocol specification (2025-11-25), https://modelcontextprotocol.io/specification/2025-11-25
  - key: MCP separates resources, prompts, tools, and client capabilities; Harbor should not treat offered metadata as trusted truth.
  - harbor_use: crossing-record route/admission evidence for tool/resource surfaces without importing semantic trust.
- **EXT-MCP-SECURITY-BEST-PRACTICES-2026** — Model Context Protocol security best practices, https://modelcontextprotocol.io/specification/2025-11-25/basic/security_best_practices
  - key: user consent, privacy, server trust, and untrusted annotations must stay visible.
  - harbor_use: hostile receipt fixtures for authorityless tool annotations and stale resource listings.
- **EXT-RFC9700-OAUTH-SECURITY-BCP-2025** — IETF RFC 9700, Best Current Practice for OAuth 2.0 Security, https://www.rfc-editor.org/rfc/rfc9700.html
  - key: OAuth completion is a scoped authorization ceremony, not all-purpose trust.
  - harbor_use: browser/OAuth crossings stay smaller than identity or compliance.
- **EXT-W3C-DIGITAL-CREDENTIALS-2026** — W3C Digital Credentials API, https://www.w3.org/TR/digital-credentials/
  - key: browser-mediated credential presentation/issuance remains scoped and user-agent mediated.
  - harbor_use: credential presentation records without issuer/global identity overclaim.

## Pass XCIII additions
- **EXT-CSAF-2-1-2026** — OASIS, Common Security Advisory Framework Version 2.1 — https://docs.oasis-open.org/csaf/csaf/v2.1/csaf-v2.1.html
  - key: remediation categories include workaround, mitigation, vendor fix, optional patch, none available, and fix planned, with product scope and date fields.
  - harbor_use: mandate/recommendation/deadline notes and implementation receipts without advisory governance.
- **EXT-OPENVEX-SPEC-2026** — OpenVEX Specification — https://github.com/openvex/spec/blob/main/OPENVEX-SPEC.md
  - key: VEX status is product/vulnerability relationship evidence and the format is intentionally minimal and SBOM-agnostic.
  - harbor_use: subject-bound implementation status humility.
- **EXT-NIST-SP800-61R3-2025** — NIST, SP 800-61 Rev. 3: Incident Response Recommendations and Considerations for Cybersecurity Risk Management — https://csrc.nist.gov/pubs/sp/800/61/r3/final
  - key: response, recovery, and improvement live inside ongoing risk-management activity.
  - harbor_use: recheck/monitoring windows and lessons-learned posture without importing incident-response governance.
- **EXT-IETF-SCITT-RFC9943-AUTH48-2026** — IETF / RFC Editor, SCITT architecture draft in AUTH48 as RFC-to-be 9943 — https://www.rfc-editor.org/auth48/rfc9943 and https://datatracker.ietf.org/doc/draft-ietf-scitt-architecture/
  - key: signed statements, transparency receipts, relying parties, auditors, and rejection/ignore paths stay separate.
  - harbor_use: implementation-publication receipts without current-truth or transparency dependency.
- **EXT-IN-TOTO-ATTESTATION-2026** — in-toto Attestation Framework — https://github.com/in-toto/attestation
  - key: link attestations identify subject products, materials, step names/commands, environment, and byproducts.
  - harbor_use: correction implementation evidence receipts without freezing an in-toto predicate.
- **EXT-W3C-PROV-DM-2013** — W3C, PROV-DM: The PROV Data Model — https://www.w3.org/TR/prov-dm/
  - key: provenance connects entities, activities, and agents and supports revision/derivation relations.
  - harbor_use: corrected public-copy chains and rollback/appeal history.
- **EXT-W3C-PROV-INVALIDATION-2013** — W3C, PROV-O invalidation/generation terms — https://www.w3.org/TR/prov-o/
  - key: generated and invalidated times/activities can bound entity lifetimes.
  - harbor_use: stale/invalidated public surfaces without memory holes.
- **EXT-DATACITE-RELATED-IDENTIFIERS-2026** — DataCite related identifiers / relationType — https://datacite-metadata-schema.readthedocs.io/en/4.5/appendices/appendix-1/relationType/
  - key: relation types include versions, variants, review, metadata, and predecessor/successor links.
  - harbor_use: successor public copy and jurisdiction/audience variant labels.
- **EXT-STATUSPAGE-INCIDENT-COMMS-2026** — Atlassian Statuspage incident communication and postmortem guidance — https://support.atlassian.com/statuspage/docs/create-a-postmortem/
  - key: active incident updates, resolved state, and postmortem/learning copy are different surfaces.
  - harbor_use: public status/proof-packet/recheck separation.

## Pass XCII additions
- **EXT-CSAF-2-1-2026** — OASIS, Common Security Advisory Framework Version 2.1 — https://docs.oasis-open.org/csaf/csaf/v2.1/csaf-v2.1.html
  - key: structured creation, update, and exchange of security-advisory status/remediation among interested parties.
  - harbor_use: scoped outside finding and correction-instruction discipline without advisory governance.
- **EXT-OPENVEX-SPEC-2026** — OpenVEX Specification — https://github.com/openvex/spec/blob/main/OPENVEX-SPEC.md
  - key: status is the known relationship a vulnerability has to a product.
  - harbor_use: subject-bound status humility for outside findings and non-use claims.
- **EXT-SCITT-ARCHITECTURE-2025** — IETF Datatracker, draft-ietf-scitt-architecture-22 — https://datatracker.ietf.org/doc/draft-ietf-scitt-architecture/
  - key: signed statements, receipts, transparency services, relying parties, auditors, and multiple services stay distinct.
  - harbor_use: finding publication and receipt evidence without importing truth or currentness.
- **EXT-W3C-PROV-DM-2013** — W3C, PROV-DM: The PROV Data Model — https://www.w3.org/TR/prov-dm/
  - key: revision is a derivation and applications choose granularity for relations.
  - harbor_use: public-copy update and historical-evidence preservation without memory holes.
- **EXT-DATACITE-RELATED-IDENTIFIERS-2026** — DataCite related identifiers — https://datacite-metadata-schema.readthedocs.io/en/4.7/properties/relatedidentifier/
  - key: relation types include versions, derivations, reviews, obsolescence, translations, and metadata links.
  - harbor_use: explicit successor/review relation labels for post-review public copies.
- **EXT-C2PA-SPEC-2-4-2026** — C2PA Technical Specification 2.4 — https://spec.c2pa.org/specifications/specifications/2.4/specs/C2PA_Specification.html
  - key: update manifests can add assertions without changing content and keep ingredient/active-manifest references.
  - harbor_use: status/wording update discipline without changing source payloads or leaking sealed evidence.

- **EXT-FIRST-PSIRT-SERVICES-1-1** — FIRST, PSIRT Services Framework 1.1 — https://www.first.org/standards/frameworks/psirts/psirt_services_framework_v1.1
  - key: PSIRTs should provide external communication channels, advertise remediation status, vet/qualify external communication, and route issues appropriately.
  - harbor_use: borrow external intake, routing, and remediation-status hygiene without creating a PSIRT program.
- **EXT-FIRST-CSIRT-SERVICES-2-1** — FIRST, CSIRT Services Framework Version 2.1 — https://www.first.org/standards/frameworks/csirts/csirt_services_framework_v2.1
  - key: CSIRTs should anticipate vulnerability reports/questions from constituents and third parties and provide reporting mechanisms, processes, and guidance.
  - harbor_use: reporter-claim outcome maps need intake and routing, not reporter scoring.
- **EXT-STATUSPAGE-INCIDENT-COMMS-2026** — Atlassian Statuspage, Incident communication tips and postmortem guidance — https://support.atlassian.com/statuspage/docs/incident-communication-tips/ and https://support.atlassian.com/statuspage/docs/create-a-postmortem/
  - key: incident communication should acknowledge known impact and provide ongoing updates; postmortems are written after incidents are resolved.
  - harbor_use: separate active warning, current public status, and historical/post-hoc explanation.
- **EXT-IETF-RATS-RFC9334** — IETF RFC 9334, Remote ATtestation procedureS (RATS) Architecture — https://www.rfc-editor.org/rfc/rfc9334
  - key: attesters generate evidence, verifiers appraise evidence and create attestation results, and relying parties appraise those results.
  - harbor_use: split downstream claims, verifier packets, public decisions, and repeated weak-claim handling.

- **EXT-NIST-SP800-61R3-2025** — NIST, SP 800-61 Rev. 3: Incident Response Recommendations and Considerations for Cybersecurity Risk Management — https://csrc.nist.gov/pubs/sp/800/61/r3/final
  - key: incident response is framed as part of cybersecurity risk management, including preparation, response, recovery, and improvement.
  - harbor_use: borrow response/recovery/learning posture for disputed remediation without importing a cyber incident program.
- **EXT-IETF-SCITT-RFC9943-AUTH48-2026** — IETF / RFC Editor, SCITT architecture draft in AUTH48 as RFC-to-be 9943 — https://www.rfc-editor.org/auth48/rfc9943 and https://datatracker.ietf.org/doc/draft-ietf-scitt-architecture/
  - key: signed statement transparency is moving through RFC publication; useful for traceability and auditability, but not yet a Harbor transparency-log decision.
  - harbor_use: publication receipts can prove a claim was registered, not that the claim is true.
- **EXT-RFC9162-CT-2022** — IETF RFC 9162, Certificate Transparency Version 2.0 — https://datatracker.ietf.org/doc/html/rfc9162
  - key: append-only logs make issued/observed certificates auditable and support log auditing.
  - harbor_use: inclusion/consistency ideas help status-publication receipts while preserving semantic verification as separate.
- **EXT-W3C-PROV-CONSTRAINTS-2013** — W3C, Constraints of the PROV Data Model — https://www.w3.org/TR/prov-constraints/
  - key: valid PROV instances satisfy definitions, inferences, and constraints so provenance can support safe reasoning and equivalence checks.
  - harbor_use: contradiction maps should compare normalized subject/version/audience/window/method before declaring conflict.
- **EXT-STATUSPAGE-API-2026** — Atlassian, Statuspage API Documentation — https://developer.statuspage.io/
  - key: incidents, incident updates, subscribers, components, and postmortems are separate API concepts.
  - harbor_use: public status is a surface that can drift from proof packets; keep status sync receipts separate from source truth.

# Bibliography

## Pass LXXXV additions
- **EXT-WCAG-2-2-2024** — W3C, *Web Content Accessibility Guidelines (WCAG) 2.2*, https://www.w3.org/TR/WCAG22/
- **EXT-WAI-COMPLEX-IMAGES-2026** — W3C WAI, *Complex Images Tutorial*, https://www.w3.org/WAI/tutorials/images/complex/
- **EXT-USWDS-DATA-VIZ-2026** — U.S. Web Design System, *Data visualizations*, https://designsystem.digital.gov/components/data-visualizations/
- **EXT-W3C-I18N-AUTHORING-2026** — W3C Internationalization, *Authoring web pages*, https://www.w3.org/International/techniques/authoring-html
- **EXT-UNICODE-CLDR-2026** — Unicode CLDR, *CLDR charts and repository documentation*, https://cldr.unicode.org/index/charts
- **EXT-UNICODE-LDML-2026** — Unicode, *Locale Data Markup Language (UTS #35)*, https://www.unicode.org/reports/tr35/
- **EXT-ECMA-402-2026** — TC39, *ECMAScript Internationalization API Specification*, https://tc39.es/ecma402/
- **EXT-DIGITALGOV-PLAINLANG-2026** — Digital.gov and Plainlanguage.gov guidance on clear government writing, https://digital.gov/
- **EXT-WAI-COGA-CLEAR-CONTENT-2026** — W3C WAI, *Use clear and understandable content*, https://www.w3.org/WAI/WCAG2/supplemental/objectives/o3-clear-content/

- **EXT-MCP-AUTH-2026** — Model Context Protocol, Understanding Authorization in MCP — https://modelcontextprotocol.io/docs/tutorials/security/authorization
- **EXT-MCP-AUTH-SPEC-2025** — Model Context Protocol Authorization spec (2025-06-18) — https://modelcontextprotocol.io/specification/2025-06-18/basic/authorization
- **EXT-RFC-8252** — IETF RFC 8252, OAuth 2.0 for Native Apps — https://www.rfc-editor.org/rfc/rfc8252.html
- **EXT-RFC-7636** — IETF RFC 7636, Proof Key for Code Exchange — https://www.rfc-editor.org/rfc/rfc7636.html
- **EXT-OAUTH-2-1-2026** — IETF OAuth 2.1 draft — https://datatracker.ietf.org/doc/draft-ietf-oauth-v2-1/
- **EXT-OAUTH-SECURITY-UPDATE-2026** — IETF draft, Updates to OAuth 2.0 Security Best Current Practice — https://datatracker.ietf.org/doc/draft-ietf-oauth-security-topics-update/
- **EXT-XDG-PORTAL** — XDG Desktop Portal overview — https://flatpak.github.io/xdg-desktop-portal/
- **EXT-XDG-OPENURI** — XDG Desktop Portal, OpenURI — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.OpenURI.html
- **EXT-XDG-DOCUMENTS** — XDG Desktop Portal, Documents — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Documents.html
- **EXT-ANDROID-VERIFY-APP-LINKS** — Android Developers, Verify App Links — https://developer.android.com/training/app-links/verify-applinks
- **EXT-APPLE-ASSOCIATED-DOMAINS** — Apple, Supporting associated domains — https://developer.apple.com/documentation/xcode/supporting-associated-domains
- **EXT-FEDCM** — W3C Federated Credential Management API — https://www.w3.org/TR/fedcm/
- **EXT-MCP-SEPS-2026** — MCP SEPs index (including auth, registry, and enterprise-control work) — https://modelcontextprotocol.io/seps
- **EXT-MCP-ROADMAP-2026** — MCP roadmap security and authorization work — https://modelcontextprotocol.io/development/roadmap
- **EXT-DIGITAL-ASSET-LINKS** — Google Digital Asset Links — https://developers.google.com/digital-asset-links/v1/getting-started
- **EXT-APPLE-UNIVERSAL-LINKS** — Apple universal links and associated domains — https://developer.apple.com/documentation/xcode/supporting-universal-links-in-your-app
- **EXT-FEDCM-CHROME** — Chrome FedCM overview — https://developer.chrome.com/docs/identity/fedcm/overview
- **EXT-OAUTH-CROSS-DEVICE-2025** — IETF draft, Cross-Device Flows: Security Best Current Practice — https://datatracker.ietf.org/doc/draft-ietf-oauth-cross-device-security/
- **EXT-XDG-FILETRANSFER** — XDG Desktop Portal, FileTransfer — https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.FileTransfer.html
- **EXT-OAUTH-FIRST-PARTY-2026** — IETF draft, OAuth 2.0 for First-Party Applications — https://datatracker.ietf.org/doc/draft-ietf-oauth-first-party-apps/
- **EXT-ANDROID-DYNAMIC-APP-LINKS** — Android Developers, About App Links / Dynamic App Links — https://developer.android.com/training/app-links/about
- **EXT-FEDCM-W3C** — W3C Federated Credential Management API — https://www.w3.org/TR/fedcm/
- **EXT-APPLE-ASWEBAUTH-EPHEMERAL** — Apple, `prefersEphemeralWebBrowserSession` — https://developer.apple.com/documentation/authenticationservices/aswebauthenticationsession/prefersephemeralwebbrowsersession
- **EXT-APPLE-UNIVERSAL-LINKS-2026** — Apple, supporting universal links — https://developer.apple.com/documentation/xcode/supporting-universal-links-in-your-app
- **EXT-FEDCM-MIGRATION-2026** — Google Identity, FedCM migration guide — https://developers.google.com/identity/gsi/web/guides/fedcm-migration

- **EXT-RFC-9126** — IETF RFC 9126, OAuth 2.0 Pushed Authorization Requests — https://www.rfc-editor.org/rfc/rfc9126.html
- **EXT-RFC-9449** — IETF RFC 9449, OAuth 2.0 Demonstrating Proof of Possession (DPoP) — https://www.rfc-editor.org/rfc/rfc9449.html

- **EXT-RFC-9396** — IETF RFC 9396, OAuth 2.0 Rich Authorization Requests — https://www.rfc-editor.org/rfc/rfc9396.html
- **EXT-ANDROID-DYNAMIC-APP-LINKS-COMPAT** — Android Developers, Dynamic App Links compatibility FAQ — https://developer.android.com/training/app-links/faq
- **EXT-XDG-DOCUMENTS-FUSE** — XDG Desktop Portal, Documents & FUSE — https://flatpak.github.io/xdg-desktop-portal/docs/documents-and-fuse.html
- **EXT-FEDCM-PRIVACY-2025** — Privacy Sandbox FedCM overview — https://privacysandbox.google.com/cookies/fedcm

- **EXT-RFC-9635** — IETF RFC 9635, Grant Negotiation and Authorization Protocol (GNAP) — https://www.rfc-editor.org/rfc/rfc9635.html
- **EXT-RFC-8628** — IETF RFC 8628, OAuth 2.0 Device Authorization Grant — https://www.rfc-editor.org/rfc/rfc8628.html
- **EXT-CIBA-FINAL** — OpenID Client-Initiated Backchannel Authentication Core 1.0 — https://openid.net/specs/openid-client-initiated-backchannel-authentication-core-1_0-final.html
- **EXT-JARM-FINAL** — JWT Secured Authorization Response Mode for OAuth 2.0 — https://openid.net/specs/oauth-v2-jarm-final.html
- **EXT-OAUTH-DPOP-DEVICE-FLOW-2025** — IETF draft, DPoP for the OAuth 2.0 Device Authorization Grant — https://datatracker.ietf.org/doc/draft-parecki-oauth-dpop-device-flow/
- **EXT-FAPI-CIBA** — OpenID Financial-grade API: Client Initiated Backchannel Authentication Profile — https://openid.net/specs/openid-financial-api-ciba.html

- **EXT-RFC-9207** — IETF RFC 9207, OAuth 2.0 Authorization Server Issuer Identification — https://www.rfc-editor.org/rfc/rfc9207.html
- **EXT-RFC-9700** — IETF RFC 9700, Best Current Practice for OAuth 2.0 Security — https://www.rfc-editor.org/rfc/rfc9700.html
- **EXT-RFC-9701** — IETF RFC 9701, JSON Web Token (JWT) Response for OAuth Token Introspection — https://www.rfc-editor.org/rfc/rfc9701.html
- **EXT-RFC-9470** — IETF RFC 9470, OAuth 2.0 Step Up Authentication Challenge Protocol — https://www.rfc-editor.org/rfc/rfc9470.html
- **EXT-RFC-9728** — IETF RFC 9728, OAuth 2.0 Protected Resource Metadata — https://www.rfc-editor.org/rfc/rfc9728.html
- **EXT-RFC-8414** — IETF RFC 8414, OAuth 2.0 Authorization Server Metadata — https://www.rfc-editor.org/rfc/rfc8414.html
- **EXT-OAUTH-CROSS-DEVICE-2026** — IETF draft, Cross-Device Flows: Security Best Current Practice — https://datatracker.ietf.org/doc/draft-ietf-oauth-cross-device-security/
- **EXT-RFC-8707** — IETF RFC 8707, Resource Indicators for OAuth 2.0 — https://www.rfc-editor.org/rfc/rfc8707.html
- **EXT-RFC-9068** — IETF RFC 9068, JSON Web Token (JWT) Profile for OAuth 2.0 Access Tokens — https://www.rfc-editor.org/rfc/rfc9068.html
- **EXT-RFC-9101** — IETF RFC 9101, JWT-Secured Authorization Request (JAR) — https://www.rfc-editor.org/rfc/rfc9101.html
- **EXT-DBSC-W3C** — W3C Device Bound Session Credentials — https://www.w3.org/TR/dbsc/
- **EXT-CTAP-2-2-HYBRID** — FIDO CTAP 2.2 (hybrid / cross-device transport) — https://fidoalliance.org/specs/fido-v2.2-ps-20250714/fido-client-to-authenticator-protocol-v2.2-ps-20250714.html

- **EXT-FEDCM-AUTO-REAUTH** — Privacy Sandbox, support auto-reauthentication in FedCM — https://privacysandbox.google.com/blog/fedcm-auto-reauthn

- **EXT-CREDENTIAL-MANAGEMENT-1** — W3C Credential Management Level 1 — https://www.w3.org/TR/credential-management-1/
- **EXT-WEBAUTHN-3** — W3C Web Authentication Level 3 — https://www.w3.org/TR/webauthn-3/
- **EXT-OIDC-CORE** — OpenID Connect Core 1.0 — https://openid.net/specs/openid-connect-core-1_0-final.html
- **EXT-OIDC-RP-INITIATED-LOGOUT** — OpenID Connect RP-Initiated Logout 1.0 — https://openid.net/specs/openid-connect-rpinitiated-1_0.html
- **EXT-OIDC-BACKCHANNEL-LOGOUT** — OpenID Connect Back-Channel Logout 1.0 — https://openid.net/specs/openid-connect-backchannel-1_0.html
- **EXT-OIDC-FRONTCHANNEL-LOGOUT** — OpenID Connect Front-Channel Logout 1.0 — https://openid.net/specs/openid-connect-frontchannel-1_0.html
- **EXT-OIDC-NATIVE-SSO** — OpenID Connect Native SSO for Mobile Apps 1.0 (draft 07) — https://openid.net/specs/openid-connect-native-sso-1_0.html
- **EXT-OIDC-SESSION-MANAGEMENT** — OpenID Connect Session Management 1.0 — https://openid.net/specs/openid-connect-session-1_0.html


- **EXT-RFC-8417** — IETF RFC 8417, Security Event Token (SET) — https://www.rfc-editor.org/rfc/rfc8417.html
- **EXT-RFC-8935** — IETF RFC 8935, Push-Based Security Event Token (SET) Delivery Using HTTP — https://www.rfc-editor.org/rfc/rfc8935.html
- **EXT-RFC-8936** — IETF RFC 8936, Poll-Based Security Event Token (SET) Delivery Using HTTP — https://www.rfc-editor.org/rfc/rfc8936.html
- **EXT-RFC-9493** — IETF RFC 9493, Subject Identifiers for Security Event Tokens — https://www.rfc-editor.org/rfc/rfc9493.html
- **EXT-SSF-1-0** — OpenID Shared Signals Framework Specification 1.0 — https://openid.net/specs/openid-sharedsignals-framework-1_0-final.html
- **EXT-CAEP-1-0** — OpenID Continuous Access Evaluation Profile 1.0 — https://openid.net/specs/openid-caep-1_0-final.html
- **EXT-RISC-1-0** — OpenID RISC Profile Specification 1.0 — https://openid.net/specs/openid-risc-1_0-final.html

- **EXT-RFC-6749** — IETF RFC 6749, The OAuth 2.0 Authorization Framework — https://www.rfc-editor.org/rfc/rfc6749.html
- **EXT-RFC-7662** — IETF RFC 7662, OAuth 2.0 Token Introspection — https://www.rfc-editor.org/rfc/rfc7662.html

- **EXT-GO-CONTEXT** — Go standard library `context` package — https://pkg.go.dev/context
- **EXT-CAPNP-CXXRPC** — Cap'n Proto C++ RPC overview — https://capnproto.org/cxxrpc.html
- **EXT-FEDCM-IDP-IMPLEMENT** — Chrome for Developers, Implement an identity solution with FedCM on the Identity Provider side — https://developer.chrome.com/docs/identity/fedcm/implement/identity-provider
- **EXT-OIDC-DISCOVERY** — OpenID Connect Discovery 1.0 incorporating errata set 2 — https://openid.net/specs/openid-connect-discovery-1_0.html
- **EXT-OPENID-FEDERATION-1-0** — OpenID Federation 1.0 — https://openid.net/specs/openid-federation-1_0.html

- **EXT-RFC-8176** — IETF RFC 8176, Authentication Method Reference Values — https://www.rfc-editor.org/rfc/rfc8176.html
- **EXT-FIDO-HIGH-ASSURANCE-2024** — FIDO Alliance, High Assurance Enterprise FIDO Authentication — https://fidoalliance.org/white-paper-high-assurance-enterprise-fido-authentication/
- **EXT-FIDO-MODERATE-ASSURANCE-2024** — FIDO Alliance, FIDO Authentication for Moderate Assurance Use Cases — https://fidoalliance.org/white-paper-fido-authentication-for-moderate-assurance-use-cases/

- **EXT-OIDC-REGISTRATION** — OpenID Connect Dynamic Client Registration 1.0 incorporating errata set 2 — https://openid.net/specs/openid-connect-registration-1_0.html
- **EXT-FEDCM-CUSTOM-LABELS-2025** — Chrome for Developers, Implement an identity solution with FedCM on the Identity Provider side (custom account labeling) — https://developer.chrome.com/docs/identity/fedcm/implement/identity-provider

- **EXT-FEDCM-IFRAME-DOMAIN-2025** — Chrome for Developers, FedCM updates: Display iframe domain — https://developer.chrome.com/blog/fedcm-chrome-142-updates
- **EXT-FEDCM-STRUCTURED-JSON-2026** — Chrome for Developers, FedCM updates in Chrome 143 — https://developer.chrome.com/blog/fedcm-chrome-143-updates
- **EXT-CEDAR** — Cedar Policy Language Reference Guide — https://docs.cedarpolicy.com/
- **EXT-BISCUIT** — Eclipse Biscuit — https://www.biscuitsec.org/
- **EXT-ZCAP** — Authorization Capabilities for Linked Data v0.3 — https://w3c-ccg.github.io/zcap-spec/


- **EXT-OAUTH-WEB-MESSAGE-2025** — IETF draft, OAuth 2.0 Web Message Response Mode for Popup- and Iframe-based Authorization Flows — https://datatracker.ietf.org/doc/draft-meyerzuselha-oauth-web-message-response-mode/
- **EXT-OAUTH-BROWSER-APPS-2025** — IETF draft, OAuth 2.0 for Browser-Based Applications — https://datatracker.ietf.org/doc/draft-ietf-oauth-browser-based-apps/
- **EXT-OAUTH-RESOURCE-TOKEN-RESP-2026** — IETF draft, OAuth 2.0 Resource Parameter in Access Token Response — https://datatracker.ietf.org/doc/draft-mcguinness-oauth-resource-token-resp/

- **EXT-RFC-9767** — IETF RFC 9767, Grant Negotiation and Authorization Protocol Resource Server Connections — https://www.rfc-editor.org/rfc/rfc9767.html
- **EXT-OAUTH-RESOURCE-RESPONSE-2026** — IETF draft, Resource Indicator Response Parameter for OAuth 2.0 — https://datatracker.ietf.org/doc/draft-skokan-oauth-resource-response/
- **EXT-OAUTH-RFC9728BIS-2026** — IETF draft, Update to OAuth 2.0 Protected Resource Metadata Resource Identifier Validation — https://datatracker.ietf.org/doc/draft-mcguinness-oauth-rfc9728bis/
- **EXT-RFC-8693** — IETF RFC 8693, OAuth 2.0 Token Exchange — https://www.rfc-editor.org/rfc/rfc8693.html
- **EXT-OAUTH-TOKEN-XCHG-TARGET-SVC-DISCO-2026** — IETF draft, OAuth 2.0 Token Exchange Target Service Discovery — https://datatracker.ietf.org/doc/draft-mcguinness-token-xchg-target-svc-disco/
- **EXT-ZEHAVI-RAR-METADATA-2026** — IETF draft, OAuth 2.0 RAR Metadata and Error Signaling — https://datatracker.ietf.org/doc/draft-zehavi-oauth-rar-metadata/
- **EXT-OAUTH-IDENTITY-ASSERTION-AUTHZ-GRANT-2026** — IETF draft, Identity Assertion JWT Authorization Grant — https://datatracker.ietf.org/doc/draft-ietf-oauth-identity-assertion-authz-grant/

- **EXT-KIMBALL-GRAIN** — Kimball Group, Grain — https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/grain/
- **EXT-KIMBALL-FOUR-STEP** — Kimball Group, Four-Step Dimensional Design Process — https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/four-4-step-design-process/
- **EXT-KIMBALL-LATE-FACT** — Kimball Group, Late Arriving Facts — https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/late-arriving-fact/
- **EXT-KIMBALL-LATE-DIMENSION** — Kimball Group, Late Arriving Dimensions — https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/late-arriving-dimension/
- **EXT-KIMBALL-SCD** — Kimball Group, Slowly Changing Dimensions — https://www.kimballgroup.com/2008/08/slowly-changing-dimensions/
- **EXT-KIMBALL-DRILLING-ACROSS** — Kimball Group, Drilling Across — https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/drilling-across/
- **EXT-ICEBERG-PARTITIONING** — Apache Iceberg, Partitioning / hidden partitioning — https://iceberg.apache.org/docs/latest/partitioning/
- **EXT-ICEBERG-EVOLUTION** — Apache Iceberg, Evolution — https://iceberg.apache.org/docs/1.7.1/evolution/
- **EXT-ICEBERG-ROW-LINEAGE-2026** — Apache Iceberg Spec, Row Lineage — https://iceberg.apache.org/spec/
- **EXT-ANCHOR-TUTORIALS** — Anchor Modeling tutorials — https://www.anchormodeling.com/tutorials/
- **EXT-DBT-CONTRACTS** — dbt docs, model contract configuration — https://docs.getdbt.com/reference/resource-configs/contract
- **EXT-DBT-SEMANTIC-ARCH** — dbt docs, Semantic Layer architecture — https://docs.getdbt.com/docs/use-dbt-semantic-layer/sl-architecture
- **EXT-DBT-ENTITIES** — dbt docs, Entities — https://docs.getdbt.com/docs/build/entities
- **EXT-DBT-DIMENSIONS** — dbt docs, Dimensions — https://docs.getdbt.com/docs/build/dimensions
- **EXT-OPENLINEAGE-FACETS** — OpenLineage, Facets & Extensibility — https://openlineage.io/docs/spec/facets/
- **EXT-HUDI-TIMELINE** — Apache Hudi, Timeline — https://hudi.apache.org/docs/timeline/
- **EXT-DELTA-CDF** — Delta Lake, Change Data Feed — https://docs.delta.io/delta-change-data-feed/
- **EXT-DELTA-SCHEMA-ENFORCEMENT** — Delta Lake blog, Schema Enforcement — https://delta.io/blog/2022-11-16-delta-lake-schema-enforcement/
- **EXT-ICEBERG-BRANCHING** — Apache Iceberg, Branching and Tagging — https://iceberg.apache.org/docs/latest/branching/
- **EXT-DBT-SEMANTIC-MODELS-2026** — dbt docs, Semantic models — https://docs.getdbt.com/docs/build/semantic-models
- **EXT-LAKEFS-ISOLATED-ENVIRONMENTS** — lakeFS docs, Isolated Dev & Test Environments — https://docs.lakefs.io/v1.79/understand/use_cases/etl_testing/
- **EXT-LAKEFS-CATALOG-EXPORTS** — lakeFS docs, Data Catalogs Exports — https://docs.lakefs.io/v1.60/howto/catalog_exports/

- **EXT-CONFLUENT-SCHEMA-COMPAT** — Confluent Schema Registry, Schema Evolution and Compatibility — https://docs.confluent.io/platform/current/schema-registry/fundamentals/schema-evolution.html

- **EXT-AVRO-SCHEMA-RESOLUTION** — Apache Avro, Specification / Aliases and Schema Resolution — https://avro.apache.org/docs/1.12.0/specification/

- **EXT-DBT-MODEL-VERSIONS** — dbt docs, Model versions — https://docs.getdbt.com/docs/mesh/govern/model-versions

- **EXT-K8S-FEATURE-GATES-2026** — Kubernetes, Feature Gates — https://kubernetes.io/docs/reference/command-line-tools-reference/feature-gates/

- **EXT-K8S-DEPRECATION-POLICY** — Kubernetes, Deprecation Policy — https://kubernetes.io/docs/reference/using-api/deprecation-policy/

- **EXT-PROTOBUF-DOS-DONTS** — Protocol Buffers, Proto Best Practices — https://protobuf.dev/best-practices/dos-donts/

- **EXT-PROTOBUF-1-1-1** — Protocol Buffers, 1-1-1 Best Practice — https://protobuf.dev/best-practices/1-1-1/

- **EXT-OTEL-SCHEMAS** — OpenTelemetry, Telemetry Schemas — https://opentelemetry.io/docs/specs/otel/schemas/

- **EXT-OPENMETADATA-DATA-CONTRACTS-2026** — OpenMetadata docs, Creating Data Contracts — https://docs.open-metadata.org/v1.12.x/how-to-guides/data-contracts/spec
- **EXT-DATAHUB-ASSERTIONS** — DataHub docs, Assertions — https://docs.datahub.com/docs/managed-datahub/observe/assertions
- **EXT-DATAHUB-OPEN-ASSERTIONS** — DataHub docs, Open Data Quality Assertions Specification — https://docs.datahub.com/docs/assertions/open-assertions-spec
- **EXT-PACT-CONSUMER-DRIVEN** — Pact docs, Introduction / Consumer Driven Contracts — https://docs.pact.io/

- **EXT-DBT-TEST-SEVERITY** — dbt docs, severity / error_if / warn_if — https://docs.getdbt.com/reference/resource-configs/severity
- **EXT-GX-EXPECTATION-SEVERITY** — Great Expectations docs, Expectations overview / failure severity — https://docs.greatexpectations.io/docs/cloud/expectations/expectations_overview/
- **EXT-GX-VALIDATION-RUNS** — Great Expectations docs, Validation run history / observed values — https://docs.greatexpectations.io/docs/cloud/validations/run_validations/

- **EXT-PROTOBUF-FIELD-PRESENCE** — Protocol Buffers docs, Application Note: Field Presence — https://protobuf.dev/programming-guides/field_presence/
- **EXT-ARROW-COLUMNAR-VALIDITY** — Apache Arrow Columnar Format, validity bitmaps / struct validity — https://arrow.apache.org/docs/format/Columnar.html
- **EXT-PARQUET-NULLS** — Apache Parquet file format, Nulls / definition levels — https://parquet.apache.org/docs/file-format/nulls/
- **EXT-DBT-DATA-TEST-PROPERTY** — dbt docs, data-tests property / relationships vs `NULL` — https://docs.getdbt.com/reference/resource-properties/data-tests

- **EXT-DATAHUB-DATA-CONTRACT-2026** — DataHub docs, Data Contracts — https://docs.datahub.com/docs/managed-datahub/observe/data-contract
- **EXT-DBT-FRESHNESS-2026** — dbt docs, freshness — https://docs.getdbt.com/reference/resource-properties/freshness
- **EXT-GX-FORMAT-RESULTS-2026** — Great Expectations docs, Format results — https://docs.greatexpectations.io/docs/cloud/validations/format_results/

- **EXT-FLINK-TIMELY-STREAM-PROCESSING** — Apache Flink: Timely Stream Processing — https://nightlies.apache.org/flink/flink-docs-stable/docs/concepts/time/
  - key: separates processing time from event time; processing time is simple and low-latency but not deterministic in distributed asynchronous environments, while event time plus watermarks supports out-of-order and historical reprocessing.
  - harbor_use: keep occurrence time and processing/observation time visibly separate before one timestamp becomes fake truth.

- **EXT-DB2-BITEMPORAL-CREATING** — IBM Db2: Creating a bitemporal table — https://www.ibm.com/docs/en/db2/12.1.x?topic=bt-creating
  - key: distinguishes BUSINESS_TIME validity from SYSTEM_TIME currentness and supports `BUSINESS_TIME WITHOUT OVERLAPS`.
  - harbor_use: keep validity windows separate from knowledge/currentness windows and keep overlap policy explicit.

- **EXT-DB2-QUERYING-TEMPORAL** — IBM Db2: Querying temporal tables — https://www.ibm.com/docs/en/db2-for-zos/13.0.0?topic=tables-querying-temporal
  - key: requires `FOR SYSTEM_TIME` or `FOR BUSINESS_TIME` plus `AS OF` / `FROM` / `BETWEEN`, and also supports session-level temporal special registers.
  - harbor_use: steal explicit as-of witnesses instead of relying on one ambient “latest” basis.

- **EXT-SQLSERVER-TEMPORAL-USAGE** — Microsoft Learn: Temporal table usage scenarios — https://learn.microsoft.com/en-us/sql/relational-databases/tables/temporal-table-usage-scenarios?view=sql-server-ver17
  - key: system-versioned temporal tables are fine for SCD only when transaction-time validity fits business logic; significant load delay can make transaction time unacceptable.
  - harbor_use: keep transaction/currentness time visibly smaller than business-valid time.

- **EXT-KIMBALL-ADDITIVITY** — Kimball Group, Additive, Semi-Additive, and Non-Additive Facts — https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/additive-semi-additive-non-additive-fact/
- **EXT-DBT-MEASURES-2026** — dbt docs, Measures / non_additive_dimension — https://docs.getdbt.com/docs/build/measures
- **EXT-DBT-RATIO-METRICS-2026** — dbt docs, Ratio metrics — https://docs.getdbt.com/docs/build/ratio
- **EXT-LOOKER-SYMMETRIC-AGGREGATES** — Looker docs, Understanding symmetric aggregates — https://docs.cloud.google.com/looker/docs/best-practices/understanding-symmetric-aggregates
- **EXT-CUBE-MEASURE-ADDITIVITY-2026** — Cube docs, Concepts / measure additivity — https://cube.dev/docs/product/data-modeling/concepts
- **EXT-DRUID-DATASKETCHES-2026** — Apache Druid docs, DataSketches extension — https://druid.apache.org/docs/latest/development/extensions-core/datasketches-extension/
- **EXT-DRUID-THETA-SKETCHES-2026** — Apache Druid docs, Approximations with Theta sketches — https://druid.apache.org/docs/latest/tutorials/tutorial-sketches-theta/

- **EXT-KIMBALL-CONFORMED-DIMENSIONS** — added for rev0071 conformance / bridge / join-discipline pressure — https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/conformed-dimension/
- **EXT-KIMBALL-BUS-ARCHITECTURE** — added for rev0071 conformance / bridge / join-discipline pressure — https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/kimball-data-warehouse-bus-architecture/
- **EXT-KIMBALL-SHRUNKEN-ROLLUP-DIMENSIONS** — added for rev0071 conformance / bridge / join-discipline pressure — https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/kimball-techniques/dimensional-modeling-techniques/shrunken-rollup-dimension/
- **EXT-KIMBALL-BRIDGE-TABLES** — added for rev0071 conformance / bridge / join-discipline pressure — https://www.kimballgroup.com/wp-content/uploads/2013/08/2013.09-Kimball-Dimensional-Modeling-Techniques11.pdf
- **EXT-DBT-JOIN-LOGIC-2026** — added for rev0071 conformance / bridge / join-discipline pressure — https://docs.getdbt.com/docs/build/join-logic
- **EXT-LOOKER-JOIN-RELATIONSHIP-2025** — added for rev0071 conformance / bridge / join-discipline pressure — https://docs.cloud.google.com/looker/docs/reference/param-explore-join-relationship


- **EXT-BIGQUERY-APPROX-AGG-2026** — BigQuery docs, Approximate aggregate functions — https://docs.cloud.google.com/bigquery/docs/reference/standard-sql/approximate_aggregate_functions
- **EXT-BIGQUERY-HLL-2026** — BigQuery docs, HLL++ functions — https://docs.cloud.google.com/bigquery/docs/reference/standard-sql/hll_functions
- **EXT-DATASKETCHES-RESEARCH** — Apache DataSketches, Research Directions — https://datasketches.apache.org/docs/Community/Research.html
- **EXT-DATASKETCHES-HLL** — Apache DataSketches, HLL Sketches — https://datasketches.apache.org/docs/HLL/HllSketches.html
- **EXT-DATASKETCHES-FREQ-ITEMS** — Apache DataSketches, Frequent Items Overview — https://datasketches.apache.org/docs/Frequency/FrequentItemsOverview.html
- **EXT-DUCKDB-APPROX-AGGREGATES-2026** — DuckDB docs, Aggregate functions / Approximate Aggregates — https://duckdb.org/docs/stable/sql/functions/aggregates


- **EXT-ICEBERG-CHANGELOG-VIEWS-2026** — Apache Iceberg docs, Spark procedures / create_changelog_view — https://iceberg.apache.org/docs/latest/spark-procedures/
- **EXT-HUDI-INCREMENTAL-QUERIES-2026** — Apache Hudi docs, SQL queries / incremental queries — https://hudi.apache.org/docs/sql_queries/
- **EXT-FLINK-TO-CHANGELOG-2026** — Apache Flink docs, Changelog conversion / TO_CHANGELOG — https://nightlies.apache.org/flink/flink-docs-master/docs/sql/reference/queries/changelog/
- **EXT-DEBEZIUM-EVENT-FLATTENING-2026** — Debezium docs, New Record State Extraction / event flattening — https://debezium.io/documentation/reference/stable/transformations/event-flattening.html


- **EXT-UCUM-SPEC-2024** — UCUM Specification v2.2 — https://ucum.org/ucum
- **EXT-FHIR-QUANTITY-2026** — HL7 FHIR R6 datatypes / Quantity — https://build.fhir.org/datatypes.html
- **EXT-FHIR-MONEYQUANTITY-2026** — HL7 FHIR R6 MoneyQuantity profile — https://build.fhir.org/moneyquantity.profile.xml.html
- **EXT-HL7-MONETARY-AMOUNT-2026** — HL7 CDA core, MonetaryAmount detailed definitions — https://build.fhir.org/ig/HL7/CDA-core-sd//StructureDefinition-MO-definitions.html
- **EXT-SIX-ISO4217-2026** — SIX, Global Financial Data Standards / ISO 4217 maintenance agency posture — https://www.six-group.com/en/products-services/financial-information/market-reference-data/data-standards.html
- **EXT-PROMETHEUS-METRIC-NAMING** — Prometheus docs, Metric and label naming — https://prometheus.io/docs/practices/naming/
- **EXT-OTEL-METRIC-UNITS-2026** — OpenTelemetry semantic conventions, Metrics / instrument units — https://opentelemetry.io/docs/specs/semconv/general/metrics/
- **EXT-W3C-RDF-DATA-CUBE** — W3C, The RDF Data Cube Vocabulary — https://www.w3.org/TR/vocab-data-cube/
- **EXT-ICEBERG-VIEW-SPEC** — Apache Iceberg, View Spec — https://iceberg.apache.org/view-spec/
- **EXT-ICEBERG-PUFFIN** — Apache Iceberg, Puffin Spec — https://iceberg.apache.org/puffin-spec/
- **EXT-DUCKDB-CUBE-PIVOT-2026** — DuckDB docs, GROUPING SETS / ROLLUP / CUBE and PIVOT — https://duckdb.org/docs/stable/sql/query_syntax/grouping_sets and https://duckdb.org/docs/stable/sql/statements/pivot.html

- **EXT-PARQUET-LOGICAL-TYPES-2026** — Apache Parquet docs, Logical Types — https://parquet.apache.org/docs/file-format/types/logicaltypes/
- **EXT-BIGQUERY-GROUPINGSETS-2026** — GoogleSQL query syntax, GROUPING SETS / ROLLUP / CUBE — https://docs.cloud.google.com/bigquery/docs/reference/standard-sql/query-syntax
- **EXT-SLOPOS-DATA-CONTRACT-GATES-2026** — included SlopOS archive, `rfcs/0097-data-contracts-and-migration-gates.md`
- **EXT-SLOPOS-OBSERVATION-EXPORT-POLICY-2026** — included SlopOS archive, `rfcs/0076-observation-export-policy.md`
- **EXT-SLOPOS-FCELL-RECEIPT-NONAUTH-2026** — included SlopOS archive, `docs/30-architecture/fcell-adapter-receipt-schema-v1.md` and `docs/30-architecture/fcell-commutativity-contract-v0.md`
- **EXT-DBT-SEMANTIC-LAYER-2026** — dbt docs, Use the dbt Semantic Layer — https://docs.getdbt.com/docs/use-dbt-semantic-layer/dbt-sl
- **EXT-CUBE-JOIN-RELATIONSHIPS-2026** — Cube docs, Joins between cubes / relationship vocabulary — https://cube.dev/docs/product/data-modeling/concepts/working-with-joins
- **EXT-DATAHUB-ASSERTION-ENTITY-2026** — DataHub metamodel, Assertion entity — https://docs.datahub.com/docs/generated/metamodel/entities/assertion
- **EXT-ICEBERG-STATS-OPTIONAL-2026** — Apache Iceberg spec, Table Statistics / optional statistics posture — https://iceberg.apache.org/spec/

- **EXT-MATERIALIZE-TIMESTAMP-FRONTIERS-2026** — Materialize docs, EXPLAIN TIMESTAMP / read and write frontiers — https://materialize.com/docs/sql/explain-timestamp/
  - key: distinguishes read frontiers advanced by compaction from write frontiers that bound correct immediate answers.
  - harbor_use: keep frontier witnesses domain-scoped instead of treating one timestamp as freshness, completeness, or replay proof.
- **EXT-TIMELY-PROGRESS-FRONTIERS** — Timely Dataflow book, Progress Tracking — https://timelydataflow.github.io/timely-dataflow/chapter_5/chapter_5_2.html
  - key: progress tracking summarizes timestamped dataflow state through frontiers tied to operator ports and timestamp domains.
  - harbor_use: keep future Harbor frontier vocabulary scoped to one dataflow/export basis rather than one global currentness badge.

- **EXT-GX-UNEXPECTED-ROWS-2026** — Great Expectations docs, Retrieve all unexpected rows — https://docs.greatexpectations.io/docs/core/run_validations/retrieve_all_unexpected_rows
- **EXT-DBT-STORE-FAILURES-2026** — dbt docs, store_failures — https://docs.getdbt.com/reference/resource-configs/store_failures
- **EXT-OPENLINEAGE-RUN-CYCLE-2026** — OpenLineage docs, The Run Cycle — https://openlineage.io/docs/spec/run-cycle/
- **EXT-OPENLINEAGE-ERROR-MESSAGE-FACET-2026** — OpenLineage docs, Error Message Facet — https://openlineage.io/docs/1.44.0/spec/facets/run-facets/error_message/
- **EXT-KAFKA-TOMBSTONE-RETENTION-2026** — Apache Kafka docs, topic configs / delete.retention.ms — https://kafka.apache.org/41/configuration/topic-configs/
- **EXT-DEBEZIUM-TOMBSTONES-2026** — Debezium docs, applying transformations selectively / tombstone events — https://debezium.io/documentation/reference/stable/transformations/applying-transformations-selectively.html
- **EXT-FLINK-LATE-DATA-2026** — Confluent Cloud for Apache Flink docs, Handle late-arriving data — https://docs.confluent.io/cloud/current/flink/how-to-guides/handle-late-arriving-data.html

- **EXT-ICEBERG-SNAPSHOT-EXPIRATION-2026** — Apache Iceberg docs, Maintenance / expire snapshots — https://iceberg.apache.org/docs/latest/maintenance/
- **EXT-DELTA-VACUUM-RETENTION-2026** — Delta Lake docs, Table utility commands / VACUUM — https://docs.delta.io/delta-utility/
- **EXT-HUDI-CLEANING-2026** — Apache Hudi docs, Cleaning — https://hudi.apache.org/docs/cleaning/
- **EXT-BIGQUERY-TIME-TRAVEL-2026** — Google BigQuery docs, Data retention with time travel and fail-safe — https://docs.cloud.google.com/bigquery/docs/time-travel
- **EXT-SNOWFLAKE-TIME-TRAVEL-RETENTION-2026** — Snowflake docs, Understanding and using Time Travel — https://docs.snowflake.com/en/user-guide/data-time-travel
- **EXT-FLINK-SAVEPOINTS-2026** — Apache Flink docs, Savepoints — https://nightlies.apache.org/flink/flink-docs-stable/docs/ops/state/savepoints/

- **EXT-W3C-VC-DATA-MODEL-2-0** — W3C, Verifiable Credentials Data Model v2.0 — https://www.w3.org/TR/vc-data-model-2.0/
- **EXT-W3C-BBS-DERIVED-PROOFS-2026** — W3C, Data Integrity BBS Cryptosuites v1.0 — https://www.w3.org/TR/vc-di-bbs/
- **EXT-OPENID-4VP-SELECTIVE-DISCLOSURE-2025** — OpenID, OpenID for Verifiable Presentations / selective disclosure — https://openid.net/specs/openid-4-verifiable-presentations-1_0-29.html
- **EXT-OTEL-SENSITIVE-DATA-2026** — OpenTelemetry docs, Handling sensitive data — https://opentelemetry.io/docs/security/handling-sensitive-data/
- **EXT-NIST-SP800-122-PII** — NIST SP 800-122, Guide to Protecting the Confidentiality of PII — https://csrc.nist.gov/pubs/sp/800/122/final
- **EXT-NIST-SP800-188-DEID** — NIST SP 800-188, De-Identifying Government Datasets — https://csrc.nist.gov/pubs/sp/800/188/final
- **EXT-IN-TOTO-ATTESTATION-2026** — in-toto Attestation Framework — https://github.com/in-toto/attestation
- **EXT-SIGSTORE-REKOR-2026** — Sigstore Rekor transparency log overview — https://docs.sigstore.dev/logging/overview/
- **EXT-OPA-DECISION-LOGS-2026** — Open Policy Agent, Decision Logs — https://www.openpolicyagent.org/docs/management-decision-logs
- **EXT-OPA-SIGNED-BUNDLES-2026** — Open Policy Agent, Bundles / Signing — https://www.openpolicyagent.org/docs/management-bundles
- **EXT-CEDAR-VALIDATION-2026** — Cedar policy validation — https://docs.cedarpolicy.com/policies/validation.html
- **EXT-BISCUIT-SPEC-2026** — Eclipse Biscuit specifications — https://doc.biscuitsec.org/reference/specifications.html
- **EXT-SLOPOS-PROOF-BUNDLE-ROLE-2026** — included SlopOS archive, `docs/30-architecture/proof-bundle-role-boundary-v0.md`
- **EXT-SLOPOS-REPLAY-BUNDLE-SCHEMA-2026** — included SlopOS archive, `docs/30-architecture/replay-bundle-schema-v0.md`
- **EXT-SLOPOS-OBSERVATION-EXPORT-REDUCTION-2026** — included SlopOS archive, `docs/30-architecture/observation-export-policy-schema-v0.md` and `docs/30-architecture/diagnostic-snapshot-bundle-schema-v0.md`
- **EXT-SLOPOS-CRYPTO-AUDIT-REDACTION-2026** — included SlopOS archive, `docs/30-architecture/crypto-audit-schema-v0.md`

- **EXT-NIST-SP800-226-DP-2025** — NIST SP 800-226, Guidelines for Evaluating Differential Privacy Guarantees — https://csrc.nist.gov/pubs/sp/800/226/final
- **EXT-US-CENSUS-DAS-DP-2020** — U.S. Census Bureau, Understanding Differential Privacy / Disclosure Avoidance System materials — https://www.census.gov/programs-surveys/decennial-census/decade/2020/planning-management/process/disclosure-avoidance/differential-privacy.html
- **EXT-ABS-AGGREGATE-DATA-CONFIDENTIALITY** — Australian Bureau of Statistics, Treating aggregate data — https://www.abs.gov.au/about/data-services/data-confidentiality-guide/treating-aggregate-data
- **EXT-ONS-CENSUS2021-SDC** — Office for National Statistics, Protecting personal data in Census 2021 results — https://www.ons.gov.uk/peoplepopulationandcommunity/populationandmigration/populationestimates/methodologies/protectingpersonaldataincensus2021results
- **EXT-US-CENSUS-FSRDC-DA-HANDBOOK-2024** — U.S. Census Bureau, FSRDC Disclosure Avoidance Methods Handbook — https://www2.census.gov/adrm/FSRDC/Resources/FSRDC-Disclosure-Avoidance-Methods-Handbook.pdf
- **EXT-EUROSTAT-SDC-CENSUS-2024** — Eurostat, Guidelines for statistical disclosure control methods for census and demographics data — https://ec.europa.eu/eurostat/documents/3859598/20715808/KS-01-24-014-EN-N.pdf
- **EXT-OPENDP-DOCS-2026** — OpenDP documentation — https://docs.opendp.org/
- **EXT-SLOPOS-OBSERVATION-EXPORT-AGGREGATE-2026** — included SlopOS archive, `docs/30-architecture/observation-export-policy-schema-v0.md` and `docs/30-architecture/observation-export-posture-v0.md`
- **EXT-SLOPOS-BUDGET-LEASE-2026** — included SlopOS archive, `docs/30-architecture/budget-lease-schema-v0.md` and `docs/30-architecture/budget-payer-semantics-v0.md`

- **EXT-W3C-DWBP-2017** — W3C, Data on the Web Best Practices — https://www.w3.org/TR/dwbp/
- **EXT-W3C-CSVW-METADATA-2015** — W3C, Metadata Vocabulary for Tabular Data — https://www.w3.org/TR/tabular-metadata/
- **EXT-W3C-DCAT3-2024** — W3C, Data Catalog Vocabulary (DCAT) Version 3 — https://www.w3.org/TR/vocab-dcat-3/
- **EXT-FRICTIONLESS-DATA-PACKAGE-2024** — Frictionless Data, Data Package Specs Suite — https://frictionlessdata.io/specs/
- **EXT-BAGIT-RFC8493** — RFC 8493, The BagIt File Packaging Format (V1.0) — https://datatracker.ietf.org/doc/rfc8493/
- **EXT-RO-CRATE-SPECS-2026** — Research Object Crate, Specs & Tooling — https://www.researchobject.org/specs/
- **EXT-SPDX-PACKAGE-VERIFICATION-2026** — SPDX Specification 3.0.1, PackageVerificationCode — https://spdx.github.io/spdx-spec/v3.0.1/model/Core/Classes/PackageVerificationCode/
- **EXT-CREATIVE-COMMONS-IRREVOCABLE-2026** — Creative Commons, FAQ and licensing considerations on irrevocability — https://creativecommons.org/faq/ and https://creativecommons.org/share-your-work/licensing-considerations/version4/
- **EXT-RFC9111-HTTP-CACHING** — RFC 9111, HTTP Caching — https://www.rfc-editor.org/rfc/rfc9111.html
- **EXT-DATACITE-VERSIONING-2026** — DataCite Support, Versioning and related identifiers — https://support.datacite.org/docs/versioning
- **EXT-W3C-ODRL-2018** — W3C, ODRL Information Model 2.2 — https://www.w3.org/TR/odrl-model/
- **EXT-W3C-PROV-DM-2013** — W3C, PROV-DM: The PROV Data Model — https://www.w3.org/TR/prov-dm/
- **EXT-SCHEMA-DATASET-ISBASEDON-2026** — Schema.org Dataset and isBasedOn property — https://schema.org/Dataset and https://schema.org/isBasedOn

- **EXT-W3C-WEB-ANNOTATION-2017** — W3C, Web Annotation Data Model — https://www.w3.org/TR/annotation-model/
  - key: annotations link Body and Target resources, with external resource identity, format, language, and selectors/provenance available in the model.
  - harbor_use: keep public annotations target-specific and provenance-bearing without treating them as verdicts.
- **EXT-CROSSREF-CROSSMARK-2026** — Crossref, Crossmark — https://www.crossref.org/services/crossmark/
  - key: gives readers current status of content, including corrections, retractions, or updates, and can be embedded in PDFs for later downloaded copies.
  - harbor_use: steal current-status-near-the-copy discipline for public datacube artifacts.
- **EXT-NISO-CREC-2024** — NISO RP-45-2024, Communication of Retractions, Removals, and Expressions of Concern — https://www.niso.org/publications/rp-45-2024-crec
  - key: establishes practices for metadata creation, transfer, and display for original publications and retraction/removal/EoC statements.
  - harbor_use: public correction and dispute statuses need durable metadata and display discipline.
- **EXT-SCHEMAORG-CORRECTION-2026** — Schema.org `correction` property and `CorrectionComment` — https://schema.org/correction
  - key: associates a correction with a CreativeWork via a correction comment, text, or URL.
  - harbor_use: correction pointers are useful but must be augmented with Harbor digests, cuts, labels, and status relations.
- **EXT-DATACITE-RELATED-IDENTIFIERS-2026** — DataCite, Connecting different versions, formats and more with Related Identifiers — https://support.datacite.org/docs/connecting-versions-with-related-identifiers
  - key: uses relations such as `IsNewVersionOf`, `IsPreviousVersionOf`, `HasVersion`, `IsVersionOf`, `IsObsoletedBy`, and `Obsoletes` for versions and corrections.
  - harbor_use: public restatements should link old and new artifacts rather than overwriting history.
- **EXT-JATS-RELATED-ARTICLE-2015** — NISO JATS 1.1, `related-article-type` — https://jats.nlm.nih.gov/archiving/tag-library/1.1/attribute/related-article-type.html
  - key: distinguishes corrected article, correction-forward, retracted article, partial retraction, retraction-forward, commentary, and related article roles.
  - harbor_use: typed correction/retraction/commentary relations beat one generic related-link.
- **EXT-NIST-AI-RMF-2026** — NIST AI Risk Management Framework — https://www.nist.gov/itl/ai-risk-management-framework
  - key: frames AI risk management around documented processes for risks to individuals, organizations, and society.
  - harbor_use: generated explanations should stay documented, reviewable, and risk-scoped rather than proof-grade by default.
- **EXT-C2PA-SPEC-2-4-2026** — C2PA Technical Specification 2.4 — https://spec.c2pa.org/specifications/specifications/2.4/specs/C2PA_Specification.html
  - key: defines provenance, provenance data, hard/soft content binding, active manifests, and trust signals for digital assets.
  - harbor_use: provenance/binding ideas can inform corrected render and generated-explanation receipts without becoming Harbor's proof system.

- **EXT-SITEMAPS-PROTOCOL-2016** — Sitemaps.org, Sitemaps XML format — https://www.sitemaps.org/protocol.html
  - key: a sitemap lists URL entries with required `loc`; `lastmod`, `changefreq`, and `priority` are optional and support varies.
  - harbor_use: use sitemap entries as freshness signals, never as proof that downstream indexes updated.
- **EXT-INDEXNOW-PROTOCOL-2026** — IndexNow.org, Documentation — https://www.indexnow.org/documentation
  - key: `url-changed` represents a URL that was added, updated, or deleted.
  - harbor_use: record URL-change notification as a crawler signal receipt, not a reindex guarantee.
- **EXT-RFC9309-ROBOTS-EXCLUSION-2022** — IETF RFC 9309, Robots Exclusion Protocol — https://datatracker.ietf.org/doc/html/rfc9309
  - key: crawlers may cache `robots.txt`, should avoid using cached robots rules beyond 24 hours unless unreachable, and robots is not a substitute for access control.
  - harbor_use: treat crawler directives as future crawl signals, not deletion or secrecy.
- **EXT-GOOGLE-ROBOTS-META-2026** — Google Search Central, Robots meta tag documentation — https://developers.google.com/search/docs/crawling-indexing/robots-meta-tag
  - key: robots meta tags provide granular page-specific control over how an HTML page should be indexed and served in Google Search.
  - harbor_use: separate search/snippet controls from source artifact truth.
- **EXT-GOOGLE-REFRESH-OUTDATED-CONTENT-2026** — Google Search Console Help, Refresh Outdated Content tool — https://support.google.com/webmasters/answer/7041154
  - key: the tool can request updates to search results for pages/images that no longer exist or have significantly changed; it does not remove a page from the web.
  - harbor_use: model stale snippet refresh as a bounded request with status, not recall.
- **EXT-GOOGLE-REMOVALS-REPORT-2020** — Google Search Central Blog, New Removals report in Search Console — https://developers.google.com/search/blog/2020/01/new-removals-report-in-search-console
  - key: temporary removal hides a URL for about six months and clears cached copy; clear-cache wipes cached page and description snippet until recrawl.
  - harbor_use: keep temporary search-result actions smaller than public-copy deletion.
- **EXT-BING-SITEMAPS-AI-SEARCH-2025** — Bing Webmaster Blog, Keeping Content Discoverable with Sitemaps in AI Powered Search — https://blogs.bing.com/webmaster/July-2025/Keeping-Content-Discoverable-with-Sitemaps-in-AI-Powered-Search
  - key: accurate `lastmod` timestamps help Bing prioritize recrawling/reindexing and AI answer freshness; `changefreq` and `priority` are ignored by Bing.
  - harbor_use: use truthful modified-time signals; do not inflate them into guarantees.
- **EXT-OPENAI-CRAWLERS-2026** — OpenAI, Overview of OpenAI Crawlers — https://developers.openai.com/api/docs/bots
  - key: OAI-SearchBot and GPTBot settings are independent, separating search surfacing from potential training use.
  - harbor_use: keep search-answer freshness and training-use exclusion as separate lanes.
- **EXT-COMMONCRAWL-OPEN-CORPUS-2026** — Common Crawl, Open repository overview — https://commoncrawl.org/
  - key: Common Crawl maintains a free open corpus spanning over 300 billion pages and adds billions of pages each month.
  - harbor_use: expect public copies to persist in historical crawl/training/evaluation corpora.
- **EXT-COMMONCRAWL-ERRATA-2026** — Common Crawl, Errata — https://commoncrawl.org/errata
  - key: corpus/index issues can span named earliest/latest crawl releases and require public errata rather than silent repair.
  - harbor_use: copy and dataset errata should name scope windows and known affected releases.
- **EXT-HUGGINGFACE-DATASET-CARDS-2026** — Hugging Face, Create a dataset card — https://huggingface.co/docs/datasets/dataset_card
  - key: dataset cards help users understand dataset contents, context, creation, responsible use, biases, and metadata.
  - harbor_use: stale downstream training/eval copies should get card-level correction notices when possible.
- **EXT-W3C-PROV-INVALIDATION-2013** — W3C PROV namespace — https://www.w3.org/ns/prov
  - key: PROV names generation, revision, quotation, influence, and invalidation of entities.
  - harbor_use: invalidation is useful only when the exact target entity/set is named.

- **EXT-CISA-VEX-MINIMUM-2023** — CISA, Minimum Requirements for Vulnerability Exploitability eXchange (VEX) — https://www.cisa.gov/sites/default/files/2023-04/minimum-requirements-for-vex-508c.pdf
  - key: VEX statements carry status; affected statuses need action statements and not-affected statuses need justification or impact statement.
  - harbor_use: require remediation/status claims to include subject, action/justification, and status boundaries.
- **EXT-OPENVEX-SPEC-2026** — OpenVEX Specification — https://github.com/openvex/spec/blob/main/OPENVEX-SPEC.md
  - key: statements can be affected, not_affected, fixed, or under_investigation, with structured requirements for justification or action.
  - harbor_use: use scoped status discipline for remediation attestations without adopting VEX as Harbor schema.
- **EXT-CSAF-2-1-2026** — OASIS, Common Security Advisory Framework Version 2.1 — https://docs.oasis-open.org/csaf/csaf/v2.1/csaf-v2.1.html
  - key: CSAF defines status/remediation structures for affected, under-investigation, fixed, and not-affected product groups.
  - harbor_use: borrow named-subject status/remediation discipline; do not import product-security advisory governance.
- **EXT-SLSA-PROVENANCE-V1** — SLSA Provenance v1 — https://slsa.dev/provenance/v1
  - key: provenance follows in-toto parsing rules; consumers ignore unrecognized fields and major version changes carry incompatibility.
  - harbor_use: keep use/remediation attestations scoped, versioned, and parser-humble.
- **EXT-SLSA-VSA-V1** — SLSA Verification Summary Attestation v1 — https://slsa.dev/verification_summary/v1
  - key: verification summaries follow in-toto attestation parsing rules and summarize a verifier's result for subjects and policy.
  - harbor_use: model remediation verification as a scoped summary, not as universal trust.
- **EXT-W3C-DUV-2016** — W3C, Dataset Usage Vocabulary — https://www.w3.org/TR/vocab-duv/
  - key: DUV describes consumer experiences, citations, and feedback about datasets from a human perspective.
  - harbor_use: structure acknowledgement/use/citation feedback without making feedback authoritative.
- **EXT-W3C-DQV-2016** — W3C, Data Quality Vocabulary — https://www.w3.org/TR/vocab-dqv/
  - key: DQV provides a framework for quality information so users can judge fitness for purpose; it does not define one universal quality truth.
  - harbor_use: keep impact/materiality contextual and evidence-bound.
- **EXT-OECD-AI-INCIDENTS-2026** — OECD, AI risks and incidents / AIM — https://www.oecd.org/en/topics/sub-issues/ai-risks-and-incidents.html
  - key: AI incidents and hazards need evidence about risks, harms, and response context.
  - harbor_use: frame stale model/eval contamination and downstream effects as scoped hazards/impacts.
- **EXT-AIID-2026** — Partnership on AI / AI Incident Database — https://partnershiponai.org/workstream/ai-incidents-database/
  - key: AIID collects reports of intelligent systems causing safety, fairness, or other real-world problems.
  - harbor_use: visible incident/response learning is useful, but Harbor should not become an incident database.

- **EXT-CERT-CVD-GUIDE-2017** — CERT/CC, The CERT Guide to Coordinated Vulnerability Disclosure — https://certcc.github.io/CERT-Guide-to-CVD/
  - key: describes CVD stakeholders, roles, process phases, operational considerations, and problems that arise in coordination.
  - harbor_use: external escalation packets should name roles, requested action, and coordination failure modes without making Harbor a CVD program.
- **EXT-ISO-29147-AWI-2026** — ISO/IEC AWI 29147, Cybersecurity — Vulnerability disclosure processes — https://www.iso.org/standard/92945.html
  - key: under-development Edition 3 covers receiving reports, disclosing remediation information, concepts, policy considerations, and communications.
  - harbor_use: borrow required-content and communication discipline; do not import a vulnerability-disclosure standard as Harbor governance.
- **EXT-FIRST-TLP-2-0** — FIRST, Traffic Light Protocol — https://www.first.org/tlp/
  - key: TLP labels communicate sharing boundaries; wider sharing than the label permits requires explicit source permission.
  - harbor_use: sealed evidence manifests should carry handling labels and explicit sharing/reveal boundaries.
- **EXT-FIRST-IEP-2-0** — FIRST, Information Exchange Policy 2.0 Framework Definition — https://www.first.org/iep/iep_framework_2_0
  - key: IEP helps providers inform recipients how information may be used and reduces misunderstandings about restrictions.
  - harbor_use: external evidence exchange should keep use restrictions and recipient obligations explicit.
- **EXT-IETF-IESG-APPEALS-2025** — IETF Datatracker, IESG Statement on the Conflict Resolution and Appeals Processes — https://datatracker.ietf.org/doc/statement-iesg-statement-on-the-conflict-resolution-and-appeals-processes/
  - key: appeals should name the action or decision, grounds, and remedy sought; legal claims are out of scope for the IESG process.
  - harbor_use: appeal-window notes should be factual, scoped, and explicit about remedy/stay rather than becoming a grievance bucket.
- **EXT-IAB-APPEALS-2026** — IETF Datatracker, IAB Statement on Submitting Appeals to the IAB — https://datatracker.ietf.org/doc/statement-iab-statement-on-submitting-appeals-to-the-iab/
  - key: IAB appeals require the action/decision, grounds, remedy, self-contained text, and a deadline tied to public knowledge of the challenged action.
  - harbor_use: Harbor appeals should have completeness, deadline, resubmission, and public-record posture without copying IETF governance.
- **EXT-SCITT-ARCHITECTURE-2025** — IETF Datatracker, draft-ietf-scitt-architecture-22 — https://datatracker.ietf.org/doc/draft-ietf-scitt-architecture/
  - key: separates signed statements, transparency services, receipts, registration policies, relying parties, and auditors; relying parties choose what they trust.
  - harbor_use: public logs and receipts are accountability evidence, not current truth or automatic acceptance.
- **EXT-HYPOTHESIS-SETTINGS-2026** — Hypothesis documentation, settings and deterministic profiles — https://hypothesis.readthedocs.io/en/latest/settings.html
  - key: generated examples can be governed by settings/profiles and replayed/shrunk for debugging.
  - harbor_use: borrow replay/shrink humility without importing a property-test framework dependency into the embryo repo.
- **EXT-STRYKER-MUTANT-METRICS-2026** — Stryker, Mutant states and metrics — https://stryker-mutator.io/docs/mutation-testing-elements/mutant-states-and-metrics/
  - key: mutation reports distinguish killed, survived, no coverage, timeout, compile error, ignored, and other states.
  - harbor_use: record killed/survived status as diagnostic evidence, not a correctness or compliance score.
- **EXT-AFLPLUSPLUS-CORPUS-2026** — AFL++, fuzzing approach and corpus discipline — https://github.com/AFLplusplus/AFLplusplus/blob/stable/docs/afl-fuzz_approach.md
  - key: fuzzing creates small self-contained corpora of interesting cases useful for later regimes.
  - harbor_use: keep generated mutants small, reproducible, and shrinkable before considering any corpus promotion.
- **EXT-COVERAGEPY-BRANCH-2026** — coverage.py, branch coverage measurement — https://coverage.readthedocs.io/en/latest/branch.html
  - key: branch coverage compares measured transitions to possible transitions and identifies missing branches.
  - harbor_use: treat coverage reports as diagnostics, not as semantic completeness or truth.
- **EXT-PIT-MUTATION-BASICS-2026** — PIT mutation testing, basic concepts — https://pitest.org/quickstart/basic_concepts/
  - key: mutation testing distinguishes killed and survived mutants, and names equivalent mutations as cases that behave the same as the original.
  - harbor_use: keep survived-mutant triage separate from automatic checker failure, and require equivalent-mutant packets before treating a survivor as a gap.
- **EXT-AFLPLUSPLUS-FUZZING-IN-DEPTH-2026** — AFL++, fuzzing in depth / corpus minimization — https://aflplus.plus/docs/fuzzing_in_depth/
  - key: corpus minimization removes inputs that do not produce new path/coverage, preventing bloated duplicate corpora.
  - harbor_use: borrow pruning discipline for generated Harbor mutants without promoting a fuzzing campaign or coverage gate.
- **EXT-SOURCE-DATE-EPOCH-2026** — Reproducible Builds, SOURCE_DATE_EPOCH — https://reproducible-builds.org/docs/source-date-epoch/
  - key: `SOURCE_DATE_EPOCH` standardizes a build timestamp input so tools can produce reproducible output rather than reading ambient build time.
  - harbor_use: treat timestamp policy as explicit package evidence while refusing broad reproducible-build claims.
- **EXT-SLSA-PROVENANCE-1-2** — SLSA, Build: Provenance v1.2 — https://slsa.dev/spec/v1.2/build-provenance
  - key: provenance describes where, when, and how artifacts were produced, including build definition, run details, builder, parameters, and dependencies.
  - harbor_use: borrow build/run separation for package evidence without importing SLSA as Harbor's release schema.
- **EXT-IN-TOTO-ATTESTATION-1-2** — in-toto Attestation Framework Spec — https://github.com/in-toto/attestation/blob/main/spec/README.md
  - key: attestations separate predicate, statement, envelope, and bundle layers bound to subjects.
  - harbor_use: keep release package statements subject-bound and refuse internal fixtures as signed envelopes.
- **EXT-GITHUB-ARTIFACT-ATTESTATIONS-2026** — GitHub Docs, Artifact attestations — https://docs.github.com/en/actions/concepts/security/artifact-attestations
  - key: attestations provide build provenance and integrity claims that must still be verified and evaluated against consumer policy; they are not artifact-security guarantees.
  - harbor_use: block attestation-as-security and CI-status overclaims for Harbor release packages.
- **EXT-OCI-IMAGE-LAYOUT-2026** — OCI Image Layout Specification — https://github.com/opencontainers/image-spec/blob/main/image-layout.md
  - key: image layout separates content-addressable blobs from location-addressable references and can move through archives, filesystems, or network transfer.
  - harbor_use: borrow the split between digest identity, locator, and transport for artifact handoff without importing OCI.

- **EXT-FRICTIONLESS-DATA-PACKAGE-2026** — Data Package Standard — https://datapackage.org/standard/data-package/
  - key: a data package is a simple container format for describing a coherent collection of data and resources.
  - harbor_use: borrow descriptor humility for consumer import without promoting a data-package schema.


## Pass CIII additions

- **EXT-W3C-PROV-DM-2013** — W3C, PROV-DM: The PROV Data Model — https://www.w3.org/TR/prov-dm/
  - key: derivation connects generated and used entities but does not make mere use sufficient for equivalence.
  - harbor_use: local derivatives must name source/target digest, transform, and invalidation posture.
- **EXT-W3C-WEB-ANNOTATION-2017** — W3C, Web Annotation Data Model — https://www.w3.org/TR/annotation-model/
  - key: annotation body, target, and annotation provenance are separable resources.
  - harbor_use: annotation authorship must not become target authority or source status rewrite.
- **EXT-ROCRATE-1-2-2025** — RO-Crate 1.2 — https://www.researchobject.org/ro-crate/specification/1.2/index.html
  - key: data entities, contextual entities, and provenance can travel together.
  - harbor_use: derivative metadata can travel with local material without becoming truth or compliance.
- **EXT-BAGIT-RFC8493** — BagIt file packaging format — https://www.rfc-editor.org/rfc/rfc8493.html
  - key: manifests/checksums can support transfer/fixity while remaining payload-semantics-agnostic.
  - harbor_use: re-exported and subset copies need fixity while refusing semantic overclaim.
- **EXT-OCI-IMAGE-LAYOUT-2026** — OCI Image Layout Specification — https://github.com/opencontainers/image-spec/blob/main/image-layout.md
  - key: content-addressable blobs and location-addressable references are distinct.
  - harbor_use: local paths, refs, sync names, and indexes are not identity or currentness.

## Pass CIV bibliography additions

- **EXT-W3C-LDN-2017** — W3C Linked Data Notifications, 2017. Harbor use: notification delivery can be described without proving read/application/repair.
- **EXT-W3C-ACTIVITYPUB-2018** — W3C ActivityPub, 2018. Harbor use: delivery and update flows pressure propagation semantics without establishing all-recipient reachability.
- **EXT-OCI-REFERRERS-2024** — OCI Image and Distribution 1.1 referrers/subject relationship. Harbor use: subject-linked artifacts can support supersession maps without becoming trust or repair.
- **EXT-RFC9457-PROBLEM-DETAILS** — RFC 9457 Problem Details for HTTP APIs. Harbor use: structured failure reasons are useful but not workflow closure.
- **EXT-NIST-LOG-RETENTION** — NIST CSRC glossary, Log Retention — https://csrc.nist.gov/glossary/term/log_retention
- **EXT-PREMIS-LOC-2026** — Library of Congress PREMIS preservation metadata maintenance activity — https://www.loc.gov/standards/premis/
- **EXT-SPDX-EXTERNAL-DOCREF-2026** — SPDX 2.3, external document references — https://spdx.github.io/spdx-spec/v2.3/package-information/
  - key: SPDX document references keep relationships into external documents explicitly scoped by the referenced document.
  - Harbor use: pressure cross-cube lineage import to keep companion identifiers and relationships bound to parent document/archive context.
- **EXT-RO-CRATE-CONTEXTUAL-ENTITIES-2026** — RO-Crate 1.2, contextual entities — https://www.researchobject.org/ro-crate/specification/1.2/contextual-entities.html
  - key: RO-Crate distinguishes data entities from contextual entities.
  - Harbor use: pressure Harbor to treat consent, delegation, classification, retention, and repair notes as contextual evidence unless locally re-scoped.


## Pass CVIII cited/reused sources

- **EXT-W3C-PROV-DM-2013** — W3C, PROV-DM: The PROV Data Model — https://www.w3.org/TR/prov-dm/
- **EXT-W3C-PROV-INVALIDATION-2013** — W3C PROV invalidation/revision vocabulary — https://www.w3.org/TR/prov-o/
- **EXT-TUF-SPEC-LATEST-2026** — The Update Framework Specification — https://theupdateframework.github.io/specification/latest/
- **EXT-SPDX-EXTERNAL-DOCREF-2026** — SPDX 2.3, external document references — https://spdx.github.io/spdx-spec/v2.3/package-information/
- **EXT-IN-TOTO-SPEC-VERIFY-2026** — in-toto specification, verification and inspections — https://github.com/in-toto/docs/blob/master/in-toto-spec.md
- **EXT-SLSA-VERIFYING-ARTIFACTS-2026** — SLSA, Verifying Artifacts — https://slsa.dev/spec/v1.0/verifying-artifacts

## Pass CIX bibliography additions

- **EXT-W3C-LDN-2017** — W3C, Linked Data Notifications — https://www.w3.org/TR/ldn/
  - key: receivers can receive pushed messages and consumers may retrieve them; delivery does not prove interpretation or application.
  - harbor_use: keep consumer notice delivery weaker than read, applied, or repaired.
- **EXT-W3C-WEB-ANNOTATION-2017** — W3C, Web Annotation Data Model — https://www.w3.org/TR/annotation-model/
  - key: annotations, bodies, and targets can carry distinct properties, state, and motivation.
  - harbor_use: keep overlay annotations from rewriting target truth or source authority.
- **EXT-RFC9457-PROBLEM-DETAILS** — IETF RFC 9457, Problem Details for HTTP APIs — https://www.rfc-editor.org/rfc/rfc9457.html
  - key: machine-readable problem details can carry error/failure information without defining a whole workflow.
  - harbor_use: carry refusal reasons without turning them into compliance status or closure.
- **EXT-RESOURCESYNC-FRAMEWORK-2017** — ResourceSync Framework / notification and change-list materials — https://www.openarchives.org/rs/notification
  - key: change capabilities and notifications describe changes and changed resources without proving all destinations synchronized.
  - harbor_use: keep mirror/public-copy propagation smaller than global repair.
- **EXT-MEMENTO-RFC7089** — IETF RFC 7089, HTTP Framework for Time-Based Access to Resource States — https://www.rfc-editor.org/rfc/rfc7089
  - key: time-based access separates original resources, mementos, and timegates/timemaps.
  - harbor_use: retain prior import history after overlay propagation without treating it as currentness.

## Pass CX bibliography additions

- **EXT-WCAG22-2024** — W3C, Web Content Accessibility Guidelines (WCAG) 2.2 — https://www.w3.org/TR/WCAG22/
  - key: WCAG 2.2 gives accessibility-oriented requirements and success criteria for web content.
  - harbor_use: pressure explanation cards to carry accessible display posture while refusing accessibility conformance claims.
- **EXT-WCAG22-STATUS-MESSAGES** — W3C/WAI, Understanding Success Criterion 4.1.3: Status Messages — https://www.w3.org/WAI/WCAG22/Understanding/status-messages.html
  - key: status messages inform users about results, waiting state, progress, or errors without necessarily changing context.
  - harbor_use: pressure Harbor to separate status-message exposure from user comprehension, read proof, or repair.
- **EXT-WCAG22-LABELS-INSTRUCTIONS** — W3C/WAI, Understanding Success Criterion 3.3.2: Labels or Instructions — https://www.w3.org/WAI/WCAG22/Understanding/labels-or-instructions.html
  - key: controls and input expectations need labels or instructions so users can understand what they are selecting or entering.
  - harbor_use: pressure explanation action panels to carry clear labels without treating that clarity as consent or reliance.
- **EXT-W3C-WEB-ANNOTATION-2017** — W3C, Web Annotation Data Model — https://www.w3.org/TR/annotation-model/
  - key: annotation, body, target, and provenance can be separated.
  - harbor_use: explanation cards remain annotations over overlay targets, not target truth or authority.
- **EXT-RFC9457-PROBLEM-DETAILS** — RFC 9457, Problem Details for HTTP APIs — https://www.rfc-editor.org/rfc/rfc9457.html
  - key: problem details carry machine-readable error/problem information without requiring every API to define a new format.
  - harbor_use: pair reason codes with user-facing explanation while refusing machine-code-only user messages or workflow closure.

## Pass CXI bibliography additions

- **EXT-W3C-PRIVACY-PRINCIPLES-2025** — W3C, Privacy Principles — https://www.w3.org/TR/privacy-principles/
  - key: privacy principles pressure meaningful user agency, minimization, and careful treatment of user data.
  - harbor_use: response-event capture must not become comprehension, consent, reliance, surveillance, or identity proof.
- **EXT-KANTARA-CONSENT-RECEIPT-1-1** — Kantara Initiative, Consent Receipt Specification v1.1 — https://kantarainitiative.org/download/consent-receipt-specification/
  - key: consent receipts record a consent transaction and its context.
  - harbor_use: acknowledgement events are refused as consent unless a separate consent basis is specified outside this specimen.
- **EXT-WCAG22-LABELS-INSTRUCTIONS** — W3C/WAI, Understanding Success Criterion 3.3.2: Labels or Instructions — https://www.w3.org/WAI/WCAG22/Understanding/labels-or-instructions.html
  - key: user controls need labels and instructions.
  - harbor_use: response affordances need clear labels, but labels do not prove consent or reliance.
- **EXT-WCAG22-STATUS-MESSAGES** — W3C/WAI, Understanding Success Criterion 4.1.3: Status Messages — https://www.w3.org/WAI/WCAG22/Understanding/status-messages.html
  - key: status messages can be exposed programmatically without moving focus.
  - harbor_use: focus or status exposure remains weaker than reading, comprehension, or repair.
- **EXT-RFC9457-PROBLEM-DETAILS** — RFC 9457, Problem Details for HTTP APIs — https://www.rfc-editor.org/rfc/rfc9457.html
  - key: machine-readable problem details help clients route errors without defining all workflows.
  - harbor_use: automated retry from a reason code is not repair or human reliance.
