# Research synthesis — pass XLIII

This pass keeps Harbor narrow and learns six compatible things at once: **exact redirect and issuer checks are necessary but not always sufficient, centralized clients can confuse one OAuth connection context with another even under the same provider brand, finish callbacks need exact per-request proof, path-shaped metadata shortcuts are brittle, and cleanup signals are worth harvesting without deciding a new family today.**

## Outside lessons
1. **Exact matching still matters.**  
   RFC 9700 still requires exact string matching for registered redirect URIs (except localhost ports for native apps) and requires clients that talk to multiple authorization servers to store the intended issuer per authorization request and abort on mismatch. Harbor should keep learning the old lesson: no amount of plausible UI, remembered account display, or tidy return packaging outranks exact request binding.

2. **Context can outrun issuer.**  
   The current OAuth security-topics update draft describes **Cross-toolkit OAuth Account Takeover (COAT)** as confusion within an OAuth connection context — explicitly, a combination of **provider, toolkit, and tenant** — rather than only confusion between two authorization servers. That is a strong warning for Harbor: a result can look brand-correct and still land in the wrong local connection context.

3. **Finish proof must be local and exact.**  
   RFC 9635 requires the authorization server to provide an interaction hash and requires the client instance to validate it. The hash binds the callback to client nonce, server nonce, interaction reference, and the grant endpoint URI actually used. Harbor should therefore keep room for a **finish-hash witness** without pretending that a finish callback is automatically durable success.

4. **Endpoint validation beats clever path tricks.**  
   Chrome 143’s FedCM updates tighten client-metadata validation specifically to prevent an IdP from matching a relying party to a unique identifier passed as a path parameter. Harbor should treat path-shaped correlation tricks as suspect pressure, not as a reason to invent a portable path-identity substrate.

5. **Browser-mediated identity crossings remain exact-request ceremonies.**  
   Chrome’s FedCM IdP guidance still requires `Sec-Fetch-Dest: webidentity` checks plus exact `Origin` and `account_id` / `account_hint` matching against the `client_id`-derived RP. That is a useful reminder that polished browser mediation still rests on exact checked request context, not on the prettiest visible label.

6. **Cleanup signals are powerful but should stay provisional.**  
   WebAuthn Level 3 adds `signalUnknownCredential`, `signalCurrentUserDetails`, and `signalAllAcceptedCredentials` so a relying party can tell the client/authenticator that remembered chooser state should be hidden or refreshed. Harbor should collect that pattern as a future **cleanup pulse / display refresh** idea, but not decide a new family while the cube is still embryonic.

## Resulting Harbor move
Do not decide yet whether Harbor needs durable nouns such as **connection-context witness**, **finish-hash witness**, or **foreign-finish veto**.
For this revision:
- add one specimen around cross-toolkit / cross-tenant OAuth confusion and callback-finish binding;
- keep displayed identities and returned parcels visibly smaller than exact connection-context / basis / lane checks;
- and collect chooser-cleanup / display-refresh signals as inspiration only, without promoting them into Harbor structure yet.

## Fresh ideas worth stealing
- **connection-context witness** — exact local tuple for which provider/toolkit/tenant/lane initiated a crossing.
- **finish-hash witness** — exact proof that a finish callback belonged to that initiated crossing and not a sibling context.
- **foreign-finish veto** — visible quarantine/abort when a result validates somewhere but not for the local context that started here.
- **cleanup pulse** — small follow-up signal that remembered chooser or credential state should be hidden, refreshed, or re-labeled without pretending this is durable account truth.
- **same-context or nothing** — standing anti-regrowth rule: brand sameness, account sameness, or issuer sameness is still weaker than the exact local connection context that started the crossing.
