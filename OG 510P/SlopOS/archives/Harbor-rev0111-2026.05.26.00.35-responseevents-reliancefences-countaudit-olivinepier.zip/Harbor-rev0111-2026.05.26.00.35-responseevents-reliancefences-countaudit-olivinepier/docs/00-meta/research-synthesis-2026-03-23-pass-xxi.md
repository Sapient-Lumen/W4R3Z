# Research synthesis — pass XXI

This pass keeps Harbor narrow and learns one more thing from mature routing and session-hardening systems: **late policy can refine route eligibility without owning it, and continuity can be device-bound without becoming portable session truth**.

## Outside lessons
1. **Android 15 Dynamic App Links separates a static route ceiling from late refinement.**  
   The manifest declares the maximum scope, while server-side rules refresh dynamically and can refine or exclude within that scope. Harbor should steal this “predeclare broadly, refine later, never widen authority silently” move.

2. **Compatibility tells the truth by falling back, not by pretending the refinement existed everywhere.**  
   Older Android versions ignore the dynamic refinement field and continue using only the manifest rules. Harbor should therefore make graceful fallback a first-class truthful aftermath instead of treating it as embarrassment.

3. **Device-bound continuity is valuable precisely because it is smaller than login portability.**  
   DBSC-style work hardens session continuity by proving possession of a device-held key and reducing cookie theft, while explicitly not solving every local-compromise problem. Harbor should steal the anti-regrowth lesson without deciding yet whether any continuity residue belongs inside Harbor.

4. **The uploaded cube ecology keeps provider-local truths small.**  
   SlopOS keeps discovery, exact-match validation, pending auth state, account-linking pressure, and browser-session export provider-local. Harbor can therefore add route-ceiling/refinement ideas without turning into a universal routing registry, account broker, or portable session cube.

## Resulting Harbor move
Do not decide yet whether the durable nouns are `route ceiling`, `refinement rail`, `exclusion rail`, and `fallback honesty`, or whether one later compresses behind a smaller route-state family.
For now, keep them alive as specimen nouns and demand that they improve:
- one verified native route whose server-side rules later narrow it,
- one route that is explicitly excluded and honestly falls back to web or chooser,
- and one mixed-version specimen where dynamic refinement is absent but the static ceiling still tells the truth.

## Fresh ideas worth stealing
- **route ceiling** — predeclared maximum eligible native scope, stronger than affiliation and weaker than admission.
- **refinement rail** — late-arriving narrowing rules that remain smaller than route verdict and trust.
- **exclusion rail** — an explicit negative rule that removes paths or parameters from otherwise eligible native handling.
- **fallback honesty** — typed aftermath saying the route degraded to web, chooser, or no-action without overclaiming failure or success.
- **device-bound continuity** — strong inspiration for “smaller than login” continuity, but not yet a frozen Harbor noun.
