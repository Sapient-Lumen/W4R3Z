# SlopOS / companions evaluation — pass XXIX

This pass re-checks Harbor against the uploaded cube ecology and keeps the architecture embryonic.

## What the current cubes still teach
- **SlopOS** is especially sharp here. Its `login-state-export-boundary-v0.md` explicitly refuses portable `logged_in`, `session_state`, `active_account`, `available_accounts`, or equivalent account-state export, and it points to dedicated browser/auth artifacts instead of ambient result meaning. That strongly supports a Harbor move that records status adverts and verification turns without inventing a portable login-state plane.
- **SlopOS** also keeps browser-session export separate from auth-result export and auth-teardown control. That means Harbor should stay disciplined: a remembered sign-in hint, changed-session signal, or empty account list may matter to the crossing without becoming browser-session truth, auth-result truth, or durable logout truth.
- **Steward** contributes the cleanest sibling analogy. Its presence-advertisement posture keeps advertised presence, readiness, and runtime identity separate; Harbor can borrow that exact temperament for sign-in/status adverts. “The browser thinks this IdP is logged in” is smaller than “the user is definitely signed in here now.”
- **Ward** keeps later signals and receiver stance visibly separate. That is a very good fit for Harbor’s verification-turn idea: one changed-status or mismatch signal should point to a next turn, not silently settle the crossing.
- **Helm** still rewards compact, inspectable front-door residue. Harbor can use that to justify small product-facing residue such as `unknown`, `changed`, `mismatch`, or `verification required` instead of magical smoothness.

## Harbor consequence
Harbor should keep status-advert nouns provisional.
The right near-term move is small:
- add one specimen around `presence advert`, `verification turn`, `mismatch prompt`, and `status honesty`;
- keep portable login/account/session truth outside Harbor;
- and keep advert, verification, and durable consequence visibly separate.

## Still-not-yet decisions
- Whether `presence advert` deserves its own first-class card or remains a typed annotation on mediation and continuity residue.
- Whether `verification turn` is distinct from broader revalidation turns or merely one status-specific flavor.
- Whether Harbor ever needs a first-class advert family at all, or whether status honesty should remain a small anti-regrowth rule instead of a new registry.
