# Research synthesis — 2026-05-13 pass LXXXIV

Question: how should Harbor pressure-test `F079` — downstream public-copy hygiene for disclosure-treated aggregate labels, mirrors, exports, restatements, recomposition attempts, and consumer proof requests — without promoting a BI governance product, public data portal, license engine, cache-control system, package format, provenance ontology, or final SlopOS datacube constitution?

## Result of this pass
The strongest next move is to split **release**, **copy**, **mirror**, **restatement**, and **proof-of-copy**.

A disclosure-treated public aggregate can be safe only as a particular copy with labels, cut identity, exactness/downgrade notes, and release policy residue intact. The moment it becomes a CSV download, BI tile, PDF chart, data package, catalog distribution, mirror, screenshot, or cached response, Harbor has a new question: did the copy preserve the facts that made the release honest?

This pass therefore adds:

- `docs/00-meta/datacube-public-copy-hygiene.md` — a compact review surface for public-copy labels, release-artifact receipts, mirror/caching posture, restatement chains, recomposition guards, license/notice propagation, and proof-of-copy requests; and
- `docs/30-architecture/specimen-flow-79-public-copy-labels-mirror-hygiene-restatement.md` — a concrete specimen covering preserved labels, stripped labels, restated noisy/suppressed answers, downstream recomposition attempts, stale mirrors/caches, notice propagation, non-recallable public copies, and digest-based proof without raw evidence disclosure.

This closes `F079` while preserving the design-phase stance: Harbor can say which public copy was released, what labels had to travel, which mirrors are stale or invalid, and which restatement supersedes which copy without owning a full data portal, catalog, package format, license system, or final SlopOS datacube shape.

## External lessons folded into this pass
1. **Web data reuse needs metadata, license, provenance, quality, and versioning in the ecosystem, not just bytes.** W3C Data on the Web Best Practices treats discoverability, reuse, provenance, licensing, and versioning as core publication concerns. Harbor should steal the ecosystem stance: a public aggregate is not honest if its release conditions and lineage cannot travel with it.

2. **Tabular data needs metadata at the group/table/cell boundary.** CSVW exists because validation, conversion, display, and search need metadata to interpret tabular data, including levels as fine as cells. Harbor should treat suppression, perturbation, exactness, structural-zero, and public-copy labels as cargo that may need sidecar or embedded representations when a table leaves Harbor.

3. **Catalog records and distributions are different things.** DCAT 3 models catalogs, datasets, data services, and distributions. Harbor should steal the distinction: a dataset-level promise does not prove every downloadable distribution preserved the same labels, digest, freshness, or treatment notes.

4. **Simple package manifests are powerful when they stay boring.** Frictionless Data Package uses a descriptor plus resources; BagIt uses payload/tag manifests and checksums for reliable transfer; SPDX package verification codes let recipients determine whether a package's files changed. Harbor should borrow manifest/digest discipline for release artifacts without adopting one package format as the canonical datacube container.

5. **Provenance and rights metadata are useful but not magic authority.** PROV distinguishes entities, activities, and agents; ODRL can express permissions, prohibitions, duties, and constraints; open-data and Creative Commons materials remind us that reuse rights and notices travel beyond the origin's runtime. Harbor should record source/copy/restatement activities and notice obligations, but not pretend a policy expression controls every downstream copy.

6. **Public licenses and public copies cannot be recalled by vibes.** Creative Commons states that CC licenses are not revocable once granted unless breached, and recipients may rely on them while rights last. Harbor should use withdrawal/deprecation/supersession language for old public copies, not fake recall semantics.

7. **Caching has freshness semantics; mirrors need similar humility.** HTTP caching distinguishes fresh, stale, and revalidated responses, with directives controlling reuse. Harbor should steal the vocabulary shape for public aggregate mirrors: a mirror can be valid, stale-pending-revalidation, superseded, or unknown, and consumer copy should say which.

8. **Version links are first-class publication hygiene.** DataCite recommends relation types such as `IsNewVersionOf` and `IsPreviousVersionOf` for version succession. Harbor should make aggregate restatements link old and new release artifacts instead of silently overwriting history or pretending the old public copy never existed.

9. **SlopOS already warns against ambient export and hidden copy-back.** SlopOS D-OBS keeps observation export explicit, bounded, redaction-first, killable, and non-authoritative. SlopOS safe-open export boundaries keep exports fresh-destination-first and lineage-explicit with parent digests. Harbor mirrors that posture for public aggregate copies: released copies are artifacts with labels and lineage, not ambient query truth or mutable remote control.

## New process shape
`docs/00-meta/datacube-public-copy-hygiene.md` names ten review handles:

- public copy label;
- release artifact receipt;
- copy-basis digest;
- mirror receipt;
- label-preservation check;
- restatement chain;
- recomposition guard;
- cache/freshness note;
- notice/license propagation note;
- proof-of-copy ticket.

These are not canonical schema objects. They are review vocabulary for specimens, promotion packets, and future SlopOS datacube work.

## Specimen selected
Specimen flow 79 models a public callback-success aggregate that was already disclosure-treated in specimen 78. It then leaves Harbor through multiple copies:

- a BI export that preserves `disclosure_treated`, `not_exact_public_copy`, suppression, perturbation, source-cut, public-cut, and restatement labels;
- a CSV mirror that strips labels and therefore becomes an invalid public copy;
- a restated release that supersedes one noisy/suppressed answer without retroactively turning the old copy into an exact answer;
- a downstream recomposition attempt combining multiple public copies to infer a suppressed provider cell;
- a stale cache/mirror that still serves the old public copy after restatement;
- a screenshot/PDF/chart copy that visually hides cell-level labels;
- a notice/license propagation case where public reuse rights cannot be recalled, only superseded or deprecated; and
- a proof-of-copy request that should receive manifest/digest/label proof, not raw replay evidence.

A naive system would publish a correct table once and consider the job done. Harbor refuses that shortcut.

## Still not decided
- one public data package format, catalog vocabulary, BI export system, mirror protocol, provenance ontology, license-policy language, cache-header profile, or release portal;
- whether labels are embedded, sidecar, manifest-only, table-cell annotations, catalog metadata, signed receipts, or all of the above depending on copy type;
- whether SlopOS, Foundry, ViewFS, Helm, Steward, or Harbor owns durable release-artifact packaging;
- how far Harbor must chase downstream copies outside its control;
- whether public restatement policy is source-owned, release-owned, auditor-owned, or consumer-contract-owned;
- how public copy proof intersects with future transparency logs, verifiable credentials, catalogs, or package signatures.

The deeper lesson is: **publication is not the end of disclosure control; it is the beginning of copy hygiene.**

