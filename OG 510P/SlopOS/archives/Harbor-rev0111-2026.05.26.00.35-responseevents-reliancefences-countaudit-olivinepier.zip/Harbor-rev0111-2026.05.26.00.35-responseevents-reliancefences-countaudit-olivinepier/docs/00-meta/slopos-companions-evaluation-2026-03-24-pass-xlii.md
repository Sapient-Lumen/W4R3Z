# SlopOS / companions evaluation — pass XLII

This pass re-checks Harbor against the uploaded cube ecology and chooses hygiene plus one more specimen over premature bloom.

## What the current cubes still teach
- **SlopOS** remains the clearest brake. Its auth-result, tool-UI, and import boundaries keep rendered prompts, response packaging, and host-owned display choreography smaller than durable approval, workflow, account, or session truth. That strongly supports Harbor refusing to overread a structured return parcel as durable adoption.
- **SlopOS** also now contributes a particularly valuable process lesson: its intentional-singleton contract refuses to let one narrow seam linger as a stale label once close siblings accumulate. Harbor should steal that discipline for embryo noun growth while SlopOS itself is still moving.
- **ViewFS** continues to sharpen a neighboring separation that matters here: request, selection, grant, bind, and durable reopen truth should not be flattened just because a surface looks polished. That supports Harbor keeping displayed-party cues, return parcels, and durable consequence visibly separate.
- **Helm** still shows why front-door chrome can be helpful without becoming a trusted control plane. More visible provenance can be good; collapsing it into durable authority is still bad.

## Harbor consequence
Harbor should keep this move modest:
- add one specimen around embedded third-party display cues and structured return packaging;
- add one repo/process contract for embryo promotion hygiene;
- mark the lingering preview-asset pressure test done;
- and leave any future registry of multi-party display surfaces, structured return schemas, or trusted-display policy outside Harbor for now.

## Still-not-yet decisions
- Whether `displayed-party split` deserves its own Harbor noun family, or is merely a richer case of `origin cue` / `coarse origin cue`.
- Whether `return parcel` belongs in Harbor at all, or should remain only an annotation beside aftermath receipts and existing basis/lane witnesses.
- Whether Harbor’s embryo-promotion contract should stay cube-local, or later graduate into a shared archive pattern across sibling cubes.
