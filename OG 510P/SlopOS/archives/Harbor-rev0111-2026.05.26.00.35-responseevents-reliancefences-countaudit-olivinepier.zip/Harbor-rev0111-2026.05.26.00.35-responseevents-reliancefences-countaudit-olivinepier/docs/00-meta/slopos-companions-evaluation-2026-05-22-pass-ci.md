# SlopOS companions evaluation — 2026-05-22 pass CI

## SlopOS seam

SlopOS already pressures accepted-prefix durability, checkpoint/resume, truncation, and append history. Harbor's release-package pass applies the same principle at a higher boundary: only the accepted source-tree inventory can be packaged, and the archive has to be checked after materialization.

## Companion borrowings

- From SlopOS: accepted-only history and no hidden discarded suffix. Harbor applies that to release archives by refusing embedded stale release zips and archive-index drift.
- From Foundry: classification pins. Harbor's package evidence names fixture, harness, checker, and release zip checker roles without letting them blur into a trust root.
- From Schell: retention/forgetting humility. A package process records what was included, not what every downstream copy will retain or forget.
- From ViewFS: trusted-path and consent-fence discipline. A user-visible zip check is not the same thing as user comprehension or downstream reliance.
- From Helm: repair attempts. Packaging can repair an index drift before release, but the receipt of repair is not proof that every distributed copy is repaired.
- From Steward and Ward: escalation and delegation limits. A reviewer can demand out-of-band verification, but cannot mutate the machine result into archive security.

## What changed in Harbor

F096 adds a release-package bundle, harness, checker, and emitted-zip inspector. It keeps package evidence narrower than release attestations, CI status, signatures, reproducible builds, notarization, or final datacube shape.

## Next companion pressure

F097 should test handoff/import across SlopOS-style portal surfaces: a zip acquired by file upload, an extracted directory, and a digest pasted through a chat or callback should produce different confidence records.
