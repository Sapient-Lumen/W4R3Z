# Research synthesis — pass XXXIV

This pass keeps Harbor narrow and learns one more thing from discovery, well-known metadata, and browser-owned configuration surfaces: **fetched configuration is useful residue, but it is still smaller than admitted route or local adoption truth.**

## Outside lessons
1. **Well-known discovery is exact on purpose.**  
   RFC 8414 says authorization server metadata is fetched from a well-known URL derived from the issuer identifier, and the returned `issuer` value **must be identical** to the issuer identifier used to fetch it; otherwise the metadata must not be used. RFC 9728 does the same for protected resources: the returned `resource` value must be identical to the resource identifier used to derive the metadata URL. Harbor should steal the exactness and humility together: a fetched discovery document is a precise input, not self-justifying trust.

2. **Discovery still does not settle local admission by itself.**  
   RFC 8414 is explicit that secure determination of the right protected resource is out of scope and warns that using an inappropriate protected resource can create a man-in-the-middle proxy situation. RFC 9728 adds that `authorization_servers` listings can be cross-checked against authorization-server metadata when both sides can enumerate each other. That is a beautiful Harbor pattern: discovery can narrow the search space and improve explanation, but the local side still owes an admission decision.

3. **Layered resolution is worth stealing, but only as a visible layer.**  
   OpenID Federation 1.0 says Resolved Metadata is produced by fetching entity configuration, assembling and verifying a trust chain, and applying metadata policies. This is a strong lesson for Harbor: external configuration, resolved overlays, and local consequence should stay visibly different rather than collapsing into one “provider config says so” truth blob.

4. **Browser/platform config surfaces already behave like refreshable bounded residue.**  
   FedCM requires a well-known file, a config file, specific endpoints, and browser-maintained login-status signaling. Android Dynamic App Links in Android 15+ periodically refresh `assetlinks.json`, merge dynamic rules with manifest scope, and let server-side rules refine or exclude paths without expanding static manifest scope. Harbor should steal the shape: keep **discovery residue refreshable, cache-aware, and smaller than admitted route truth**.

## Resulting Harbor move
Do not decide yet whether the durable nouns are exactly `discovery card`, `cache epoch`, `overlay witness`, and `admission truth`, or whether later pressure compresses some of them behind smaller route/admission objects.
For now, keep them alive as specimen nouns and demand that they improve:
- one OAuth/OIDC specimen where RFC 8414 or RFC 9728 discovery is fetched exactly, cross-checked, and still remains smaller than local admission;
- one FedCM specimen where well-known data, config-file data, and browser-owned status/config caches shape the next turn without becoming portable login/account truth;
- and one Dynamic App Links specimen where server-refreshed rules and cache age stay visibly smaller than manifest ceilings and actual admitted path handling.

## Fresh ideas worth stealing
- **discovery card** — compact fetched description of an outside route/provider/resource/config surface that stays smaller than local admission truth.
- **cache epoch** — inspectable age/provenance marker for fetched discovery or config residue.
- **overlay witness** — visible note that raw discovery was refined by policy, trust-chain resolution, server-side path rules, or another bounded overlay process.
- **admission truth** — explicit local verdict that decides whether fetched discovery is usable here now, needs refresh, falls back to a static floor, or must be rejected.
- **fetched config smaller than admitted route** — standing anti-regrowth rule.
