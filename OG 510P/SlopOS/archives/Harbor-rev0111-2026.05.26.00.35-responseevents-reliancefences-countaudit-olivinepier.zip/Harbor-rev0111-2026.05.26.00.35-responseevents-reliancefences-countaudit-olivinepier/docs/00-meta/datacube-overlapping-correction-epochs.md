# Datacube overlapping correction epochs and derivative lineage

Revision `rev0106` adds a small executable pressure slice for correction epoch overlap. Harbor already knew that a derivative repair receipt can expire or be retained as history. F101 asks what happens when the source is corrected again while derivatives, caches, summaries, indexes, re-exports, and local patches are still distributed across earlier repair states.

The central rule is: **epoch lineage is evidence posture, not a conflict-resolution tribunal.** A later source correction may supersede an earlier derivative repair for a named field, but it does not erase the earlier repair, expand to the whole artifact, repair every derivative, green-light a public badge, or give a source owner authority to close the lineage.

## Packet families

- `source.epoch` records correction ids, epoch digests, observation clocks, scope, partial-order edges, rollback/dispute branches, and the refusal to treat epoch order as global truth or source-owner closure.
- `derivative.lineage` records prior and post-epoch derivative digests, lineage edges, rebase/rollback edges, cycle detection, and the refusal to equate a derivative lineage with the original source or global downstream state.
- `repair.action` records whether Harbor is repairing to epoch B, preserving epoch A as history, splitting state by scope, rebasing a local patch, quarantining/disputing a derivative, or rolling back with recheck.
- `scope.reconciliation` records disjoint, overlapping, partially overlapping, parallel, conflict, and unknown relations without allowing latest-wins or whole-artifact widening.
- `currentness.window` records evaluation clocks and retention cuts so old receipts remain historical residue unless revalidated for the current epoch.
- `consumer.state` records mixed-epoch visibility, warning-history preservation, acknowledgement scope, and public-badge posture.
- `verdict.summary` admits only scoped lineage outcomes and refuses counterfeit lineage confidence.

## Accepted posture

Harbor may admit a linear repair to the latest named scope, retain epoch-A repair as history after epoch B, let disjoint corrections coexist, split derivative state across overlapping scopes, reopen a prior repair through rollback while preserving the intermediate history, repair only a subset under epoch B, rebase a local consumer patch with a delta map, preserve a stale epoch-A acknowledgement as residue, mark an external conflicting epoch as disputed/recheck-required, or supersede only named fields.

## Refusals

Harbor rejects latest-epoch wins without a scope-overlap map, epoch-A repair as current after an overlapping epoch-B correction, rollback that erases warning history, disjoint corrections falsely marked as conflict, overlapping corrections merged without a delta map, consumer patches applied to the wrong epoch base, epoch-A acknowledgements counted for epoch B, derivative digest reuse across epochs, missing epoch order/clock basis, total ordering of parallel epochs without authority, field-scope widening to whole artifact, stale subset as global currentness, dispute as repair, source-owner closure overriding lineage, retention-expiry ignored during currentness claims, green public badges across mixed epochs, material rollback without recheck, and cycles in the lineage graph.

## Non-promotions

This pass does not create a correction-epoch registry, derivative repair ledger, conflict-resolution engine, source-owner closure authority, public badge workflow, consumer cache API, compliance workflow, or final SlopOS datacube shape.
