# Datacube aggregation semantics

Purpose: keep Harbor honest that a design-phase datacube can expose **numbers with different rollup rights** without pretending every published measure is safely summable everywhere.

Design-phase cubes repeatedly get into trouble when they flatten these into one generic “metric” story:
- counts that are fully additive;
- snapshot-like amounts that are additive across some axes but not others;
- ratios and percentages that should be recomputed from components rather than summed from displayed values;
- distinct/set questions that often need either exact base grain or explicit approximate/mergeable sidecars; and
- values that become wrong as soon as a one-to-many join quietly fans the base grain out.

Harbor should not freeze one universal semantic layer now.
It does need one small review surface that stops published numbers from counterfeiting rollup rights they do not really have.

## Core rule
A Harbor number is only trustworthy once Harbor names **how it is allowed to aggregate**.

If Harbor publishes a ratio, the ratio should normally be built from a numerator and denominator rather than summed across groups.
If Harbor publishes a daily balance-like or snapshot-like value, Harbor should say which axis it must not roll up across.
If Harbor publishes a distinct question, Harbor should say whether the answer depends on exact base grain, a bounded approximation, or a mergeable sketch sidecar.
If Harbor publishes a joined lane, Harbor should say whether repeated child rows can multiply the measure unless a fence is applied first.

Harbor therefore needs a compact way to say **what class of measure a lane is carrying and what rollups are honest**.

## Minimal aggregation classes (Phase 1)
Harbor should keep the first set small and descriptive rather than pretending every lane needs a full metric engine.

1. **additive**
   - can be summed across the declared slicing dimensions without changing the question.
   - strongest for simple event counts and explicit additive components.

2. **semi-additive**
   - can be summed across some dimensions but not all.
   - often unsafe across one temporal axis or across repeated snapshot cuts.
   - strongest when Harbor can name the forbidden axis explicitly.

3. **ratio/composite**
   - should usually be computed from additive components or subquery-aligned inputs.
   - strongest for rates, percentages, and averages that should not be summed from displayed subgroup values.

4. **set/distinct or sketch-backed**
   - often unsafe to roll up from ordinary displayed aggregates alone.
   - may require exact base grain, a deduplicated set operation, or an explicit mergeable approximation sidecar.
   - strongest when Harbor keeps exactness posture visible instead of hiding it.

These are review classes, not a commitment to one BI tool, warehouse engine, or semantic-layer vendor.

## Aggregation-class card
Harbor should allow a compact **aggregation-class card** beside a curated lane or published measure family.

The card can say:
- what class each published number belongs to;
- which dimensions/axes are safe to roll up across;
- which dimensions are explicitly non-additive or forbidden;
- whether the number is built from additive components, from a ratio formula, or from a sketch/distinct sidecar; and
- whether the answer is exact, approximate, or still undecided.

The point is not to make every lane fully semantic-model-aware.
The point is to stop a visible number from pretending it can be summed or recombined when that would answer a different question.

## Fanout fence
Harbor should allow a compact **fanout fence** whenever a measure can be multiplied by a one-to-many join.

A fanout fence can say:
- the base grain the measure belongs to;
- which joins or child collections can multiply that grain;
- whether Harbor must aggregate before joining, deduplicate by key, or use a symmetric-aggregate style protection;
- what primary or unique key anchors the fence; and
- whether the fence is required for every consumer or only for selected published lanes.

This matters because a correct number at crossing grain can become wrong immediately after Harbor joins repeated tags, repeated targets, or repeated annotations.

## Rollup note
Harbor should allow a compact **rollup note** beside derived or non-fully-additive measures.

A rollup note can say:
- whether the measure is additive, semi-additive, ratio/composite, or sketch-backed;
- whether it should be recomputed from components at query time;
- which dimensions are safe/unsafe for rollup;
- whether approximate merge/union operations are allowed; and
- whether the lane expects exact replay, bounded approximation, or both.

This matters because “daily rate,” “unique targets,” and “current balance” all look like single numbers even though they do not age or aggregate the same way.

## Optional sketch sidecars
Harbor should stay open to compact **sketch sidecars** for selected high-cardinality or set-operation questions.

A sketch sidecar can remain smaller than the core row contract and still say:
- the sketch family used;
- what it approximates (distinct count, quantiles, set overlap, histogram-like summary);
- whether it is mergeable across cuts or groups;
- what error or approximation posture Harbor is willing to admit; and
- whether the exact base-grain route remains available for slower replay or audit.

Harbor does not need to choose a sketch stack now.
It should simply leave room for the idea that some hard rollup questions are better served by an explicit sidecar than by fake exactness or by re-scanning all detail forever.

## What this forbids in Phase 1
- no silently summing rates, percentages, or averages across groups just because they are numeric;
- no silently rolling semi-additive snapshot-like values across a forbidden axis;
- no silently trusting joined one-to-many result sets as if they preserved base measure grain;
- no silently treating exact distinct counts and approximate mergeable set summaries as the same promise; and
- no forcing every Harbor lane into one universal metric engine or semantic-layer stack before repeated specimens prove that need.

## What this still leaves open
- exact machine schema for aggregation-class cards, fanout fences, rollup notes, or sketch sidecars;
- exact mapping onto dbt, Cube, Looker, SQL views, or engine-native aggregate protections;
- exact policy for when Harbor should preserve exact components versus optional approximate sidecars; and
- exact cross-cube vocabulary sharing with SlopOS, Foundry, Ward, or Steward.

Harbor only needs the review behavior now: **name the rollup class, fence fanout explicitly, and keep displayed numbers smaller than the question they actually answer.**
