# Datacube option-reservation cuts

Purpose: give Harbor a concrete review grammar for candidate datacube artifacts that are worth testing but not ready to become durable schema, API, or ownership law.

This surface extends `docs/00-meta/datacube-option-reservations.md`. It is deliberately smaller than an ADR, schema, compiler, query API, semantic layer, sidecar registry, or warehouse contract.

## Standing rule
An option reservation may appear in a specimen only when it carries:

1. a source cut or basis;
2. a declared owner of the artifact and a declared non-owner of base row truth;
3. an invalidation or restatement posture;
4. an explicit optionality/refusal rule; and
5. at least one anti-counterfeit test.

If those five pieces are missing, the artifact is too persuasive to be safe.

## ORC-001 — observation exchange receipt
**Use when:** Harbor emits a small observation-shaped exchange export.

**Required proof fields:**
- export id and tier;
- source lane and cut;
- observation grain;
- component roles: dimensions, measures, attributes, evidence fields;
- withheld/suppressed/default-shadowed fields;
- export bounds and redaction class;
- consumer-facing non-promises.

**Anti-counterfeit tests:**
- an observation export is not a full diagnostic dump;
- component names are not universal semantic identities;
- a measure column is not additive unless the aggregation proof says so;
- a withheld field is not a null value;
- RDF/JSON/Parquet shape is not Harbor's durable ontology.

## ORC-002 — derived-view receipt
**Use when:** Harbor publishes or reviews a view definition that owns no data.

**Required proof fields:**
- view id and version;
- source cuts and grouping basis;
- SQL / query text digest and dialect;
- owner of the view metadata;
- compatibility posture with previous view version;
- invalidation conditions;
- replay/rebuild requirements.

**Anti-counterfeit tests:**
- a view is not a base lane;
- a successful query is not evidence that every engine agrees on semantics;
- a view version is not a historical snapshot unless the source cuts survive;
- a pretty pivot/cube result is not proof of grain, additivity, or fanout safety.

## ORC-003 — sidecar interpretation note
**Use when:** statistics, sketches, row-lineage, optimizer hints, facets, or debug metadata accompany a lane/export.

**Required proof fields:**
- sidecar id, producer, schema/version, and interpretation basis;
- linked artifact or source cut;
- optionality rule;
- absence meaning;
- allowed uses;
- forbidden uses;
- retention and invalidation posture.

**Anti-counterfeit tests:**
- sidecar absence does not mean row absence;
- sidecar presence does not upgrade the contract tier;
- row lineage is not subject, account, device, or global row identity;
- statistics are not values promised to consumers;
- facet schemas are extension metadata, not row meaning.

## ORC-004 — frontier / watermark witness
**Use when:** a lane/export needs a progress statement about event time, logical time, published-cut time, or compaction.

**Required proof fields:**
- frontier id;
- domain: event-time watermark, logical read frontier, logical write frontier, published-cut frontier, or other named basis;
- source lanes and cuts;
- timestamp or antichain/progress value;
- lateness and compaction posture;
- what can still change;
- which queries may use the witness.

**Anti-counterfeit tests:**
- a watermark is not a promise that late data cannot exist;
- a read frontier is not the same as freshness;
- a published cut is not live-head truth;
- compaction can destroy fine-grained replay evidence;
- “complete through T” has no meaning without a domain.

## ORC-005 — assertion compiler receipt
**Use when:** a declarative assertion is compiled into dbt tests, warehouse checks, DataHub assertions, Great Expectations expectations, Snowflake DMFs, or another executable target.

**Required proof fields:**
- source assertion id and version;
- compiler version;
- target engine and generated artifact digest;
- exact semantics preserved;
- unsupported/downgraded semantics;
- evidence/result return path;
- blocking/warn/observe-only posture;
- recompile trigger.

**Anti-counterfeit tests:**
- generated tests are not the source assertion;
- target-engine success is not universal validation;
- unsupported semantics must be visible, not silently dropped;
- a compiler output cannot widen a public contract subset;
- warning-only checks cannot block publication unless a separate policy says so.

## ORC-006 — schema transform receipt
**Use when:** a published or exported artifact is rewritten across a schema family/version, field rename, unit-name change, or representation change.

**Required proof fields:**
- transform id and source/target schema versions;
- mechanical mapping;
- semantic deltas and non-equivalences;
- consumer replay basis;
- retired identifiers and alias windows;
- rollback/restatement posture.

**Anti-counterfeit tests:**
- a rename is not necessarily same meaning;
- a unit/name transform is not measurement proof;
- default/backfilled values need presence witnesses;
- old identifiers must not be reused casually;
- mechanical conversion is not semantic equivalence.

## Promotion gate
An option-reservation cut can be promoted beyond process vocabulary only after two independent specimens demonstrate:

- the same required proof fields recur;
- the anti-counterfeit tests catch real failure modes;
- a source-register refresh confirms the external idea has not materially changed;
- the queue/ledger/manifest surfaces are updated in the same revision;
- a non-decision statement names what remains unchosen.

## Explicit non-decisions
- no chosen observation exchange encoding;
- no RDF, SDMX, warehouse, lakehouse, stream processor, query engine, catalog, or semantic layer;
- no sidecar registry or statistics file format;
- no universal row identity;
- no assertion DSL or compiler target;
- no schema registry or transform language.

## Pass LXXIX application
Specimen flow 74 exercises all six cuts together. The verdict is positive for review vocabulary and negative for durable promotion. Harbor now has stronger counterfeit detectors for the option-reservation backlog, but the backlog remains a backlog.

## Pass LXXX application
Specimen flow 75 adds the negative counterpart to option-reservation cuts. Every tempting helper artifact now needs not only a success receipt, but also a bounded refusal path for missing sidecars, blocked exports, unsupported targets, stale frontiers, and tombstone/withdrawal evidence. The verdict remains negative for durable schema promotion.
