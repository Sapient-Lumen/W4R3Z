# Datacube note: bundle-common audit

Harbor now has enough executable proof slices that duplicated checker helper
idioms are a drift source.  Rev0109 introduces `tools/harbor_bundle_common.py`
for deterministic JSON digests, file digests, JSON loading, assertion failure,
digest-string checks, and guarded confidence-phrase scanning.

`tools/check_harbor_bundle_common_audit.py` checks that every registered
executable fixture has a schema, version, digest, revision, members, and
global non-promotion list, and that generated Python bytecode is absent from
the source tree.  It also checks that the newest F104 checker actually uses
the common helper.

This is an audit/refactor surface only.  It is not a shared bundle schema, not
a conformance suite, not a checker trust root, not a CI status API, and not a
promotion gate.
