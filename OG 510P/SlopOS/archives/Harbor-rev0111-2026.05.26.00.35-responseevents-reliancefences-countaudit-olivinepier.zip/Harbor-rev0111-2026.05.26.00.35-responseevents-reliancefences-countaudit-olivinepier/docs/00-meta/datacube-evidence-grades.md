# Datacube evidence grades

Purpose: keep Harbor honest that a lane can be **published** without Harbor pretending it always has the same kind of current evidence in hand.

Design-phase datacubes repeatedly get into trouble when they flatten all of these into one vague green status:
- a review against one exact snapshot/tag;
- a fresh read of a moving live head;
- a stale but still interpretable live-head read;
- a partial/sample/summary-only validation result; and
- no trustworthy current observation at all.

Harbor should not freeze one giant observability stack or snapshot registry now.
It does need one small review surface that stops currentness, exactness, and detail from counterfeiting one another.

## Core rule
A lane promise is not the same thing as the evidence currently backing today's trust reading.

A lane may have a stable shape contract and still be backed only by a moving live head.
A lane may be reviewed against an exact frozen snapshot and still be stale for present-tense consumers.
A lane may have a green headline status while the detailed observed evidence is partial or missing.

Harbor therefore needs a compact way to say **what kind of evidence is actually in hand**.

## Compact evidence grades (Phase 1)
Harbor should keep the first ladder small.

1. **snapshot-pinned**
   - the trust reading is tied to one explicit snapshot, tag, version pointer, or frozen historical reference.
   - strongest for replayability and exact review basis.
   - not automatically current.

2. **head-fresh**
   - the trust reading comes from a moving live head observed within the declared freshness window.
   - strongest for present-tense usefulness.
   - weaker than `snapshot-pinned` for exact replay unless Harbor also records the concrete snapshot witness.

3. **head-stale**
   - the trust reading comes from a moving live head, but the observation is older than the desired freshness window or currentness target.
   - still interpretable, but not honest as a fresh read.

4. **partial / summary-only**
   - the trust reading is backed only by a sample, summary badge, coarse run result, or incomplete evidence payload.
   - useful, but thinner than a full measured observation.

5. **unknown / unobserved**
   - Harbor lacks a trustworthy current observation, freshness basis, or exact evidence handle.
   - not a pass.

These are review classes, not a commitment to one warehouse engine, monitoring product, or shared ecology-wide enum.
They are also **not a total ordering**: `snapshot-pinned` and `head-fresh` are different strengths rather than one simple stronger/weaker axis.

## Head-trust note
Harbor should allow a compact **head-trust note** beside a lane, card, or promotion decision.

A head-trust note can say:
- whether the reading came from a moving live head or one explicit snapshot/tag;
- whether the exact snapshot identifier was preserved;
- whether the evidence came from direct computation, warehouse metadata, cached status, or external ingestion;
- whether the evidence is exact, sampled, summarized, or missing; and
- which consumer slices are safe to treat this reading as sufficient for.

The note matters because "latest looked good" and "we reviewed exact bytes/rows from snapshot X" are different truths.

## Freshness witness
Harbor should allow a compact **freshness witness** whenever currentness is part of the story.

A freshness witness can say:
- the observation timestamp;
- the measured age or interval;
- the freshness window or warn/error thresholds;
- whether the age was derived from row timestamps, warehouse metadata, or another basis; and
- whether freshness was actually computable at all.

This matters because a live head is only "fresh" relative to a named clock rule.
No threshold, no loaded-at basis, or no trustworthy metadata should stay visibly different from a passing freshness check.

## Evidence-grade card
Harbor should allow one compact **evidence-grade card** beside a curated lane.

The card can combine:
- the evidence grade;
- the head-trust note;
- the freshness witness; and
- any link to a deeper historical tag, run receipt, or derived artifact where detailed evidence lives.

The card is smaller than row meaning and smaller than the lane's contract tier.
It only keeps today's trust story honest.

## What this forbids in Phase 1
- no silently treating a moving live head as if it were an exact reviewed historical reference;
- no silently treating a frozen old snapshot as if it proved current live-head truth;
- no silently treating a green status badge as if detailed observed evidence definitely exists;
- no silently treating missing freshness computation as if it were the same thing as fresh data;
- no forcing one universal snapshot/evidence enum before repeated specimens show that it is actually stable.

## What this still leaves open
- exact machine-readable schema for evidence-grade cards, head-trust notes, or freshness witnesses;
- exact integration with dbt, DataHub, Great Expectations, or any other tool;
- exact relationship between historical tags, reproducibility receipts, and change-history feeds;
- exact cross-cube vocabulary sharing with SlopOS, Ward, Foundry, or Steward.

Harbor only needs the review behavior now: **separate currentness from exactness, separate headline status from detailed evidence, and keep freshness as a witnessed calculation rather than atmosphere.**

## Pass LXXX note — negative evidence grades
Missing sidecar, unsupported compiler target, stale frontier, blocked export, and tombstone/withdrawal residue are evidence postures, not row facts. They should be recorded with source cut, scope, audience, lifecycle, and non-promises before any consumer sees a green, red, blank, fresh, or final-looking badge.
