# Research synthesis — 2026-03-25 pass LXXIII

Question: while SlopOS and Harbor are both still in design phase, what is the smallest honest way to let Harbor publish **current state, latest changed rows, full row-change history, and corrected history** without counterfeiting replayability or forcing an early CDC/product choice?

## What current sources say
1. **A row-change feed is a different promise from current state.**
   Delta Lake’s current change-data-feed docs say CDF tracks row-level changes *between versions* of a table, recording change events with row data plus metadata about whether a row was inserted, deleted, or updated. The same page explicitly lists an audit-trail table as a use case and says enabling CDF is an explicit choice rather than a default. Harbor should steal that: current state and change history are separate publish choices, not one default truth.

2. **Full change history, net changes, and update images are different promises.**
   Iceberg’s current `create_changelog_view` docs say changelog views expose CDC metadata columns such as `_change_type`, `_change_ordinal`, and `_commit_snapshot_id`; they can optionally output **net changes** instead of all intermediate changes; and they can compute `UPDATE_BEFORE` / `UPDATE_AFTER` images using identifier columns. Harbor should steal that distinction: ordered change history, net diff, and before/after update images should not be flattened into one generic “history” lane.

3. **Engine rewrites can fabricate change-looking rows that are not business changes.**
   The same Iceberg docs say carry-over rows arise from row-level operations under copy-on-write and are removed by default because they are not actual table changes. Harbor should steal that caution: physical rewrite artifacts are weaker than logical history and need an explicit veto instead of silent promotion.

4. **“Changed rows since X” is a different promise from “all changes since X.”**
   Hudi’s current SQL docs say incremental queries return the **latest values for all records that have changed** after a commit time, while CDC queries process **all changes** in a time window. Harbor should steal that blunt separation: an incremental changed-rows lane is useful, but it is not an ordered history lane.

5. **Append-only export often requires explicit operation coding.**
   Flink’s `TO_CHANGELOG` docs say an updating table can be converted into an append-only table with an explicit operation-code column, preserving whether the original row kind was `INSERT`, `UPDATE_BEFORE`, `UPDATE_AFTER`, or `DELETE`. Harbor should steal the idea that append-only transport is fine as long as the operation class remains visible.

6. **Convenience flattening can erase the very history consumers later need.**
   Debezium’s event-flattening docs say raw change events include metadata plus row state *before* and *after* the change, while the flattening SMT replaces the event with only the `after` field and, by default, drops delete change events because many consumers cannot handle them. Harbor should steal the warning: convenience exports can be useful, but they must not silently masquerade as faithful history.

## Harbor consequence
Harbor should add one modest datacube/process seam now:
- **change-history lane card** — compact declaration of whether a curated lane is current-state, changed-rows, full change-history, or net-change;
- **replay cut note** — compact note that says which commit/snapshot/time cut the lane covers and on which time axis;
- **carry-over veto** — compact anti-regrowth rule that physical copy-on-write or rewrite residue is not automatically logical change; and
- **restatement receipt** — compact note that says when Harbor recomputed or corrected previously published history and whether consumers must re-baseline.

## What Harbor still should not decide yet
- exact operation-code enum beyond the smallest interoperable set Harbor can borrow later;
- exact backing technology for change-history lanes (Delta, Iceberg, Hudi, Debezium/Kafka, or otherwise);
- exact retention window, compaction behavior, or replay guarantee for every future lane;
- exact policy for when every corrected history needs a successor lane versus a same-lane restatement.

The design-phase lesson is enough for now: **state is not history, changed rows are not all changes, net diffs are not replay logs, and corrected history deserves an explicit receipt.**
