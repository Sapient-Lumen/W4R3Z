# SlopOS / companions evaluation — pass XLI

This pass re-checks Harbor against the uploaded cube ecology and still chooses refinement over bloom.

## What the current cubes still teach
- **SlopOS** remains the clearest brake. Its tool-UI and prompt-import boundary docs keep rendered surfaces, imported prompts, and host-owned display choreography smaller than approval or workflow truth. That strongly supports Harbor keeping logos, pictures, and labels as **preview assets** rather than a new trusted-display registry.
- **SlopOS** also continues to separate account/session/export truth from mediation and display truth. That means Harbor should not let chooser labels or account pictures quietly harden into adopted-account or issuer truth.
- **Steward** remains a useful sibling reminder that chips, labels, and visible presence cues can help humans reason about the present without becoming lifecycle authority. That maps cleanly onto Harbor’s candidate `chooser label` and `asset honesty` residue.
- **Helm** still shows why front-door chrome matters: visible provenance cues and bounded shell/browser surfaces can improve trust without collapsing all visible surfaces into a trusted control plane.

## Harbor consequence
Harbor should keep this move modest:
- add one specimen around `coarse origin cue`, `preview asset`, `chooser label`, and `asset honesty`;
- keep those nouns explicitly smaller than issuer/account/approval truth;
- and leave any future registry of brand assets, issuer display policy, or display-surface caching behavior outside Harbor for now.

## Still-not-yet decisions
- Whether `coarse origin cue` is a real first-class Harbor noun, or merely a more specific property of `origin cue`.
- Whether `preview asset` belongs with review cards, claim-release bundles, or selector/chooser surfaces.
- Whether `chooser label` should stay a Harbor noun at all, or collapse back into provider label rails / selector hints once more pressure accumulates.
