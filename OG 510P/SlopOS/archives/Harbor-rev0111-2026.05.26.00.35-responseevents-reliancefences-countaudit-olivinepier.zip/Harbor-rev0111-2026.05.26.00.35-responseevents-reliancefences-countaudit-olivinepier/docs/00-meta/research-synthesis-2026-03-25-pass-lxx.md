# Research synthesis — pass LXX

This pass asks a smaller question than “what is Harbor’s final metric or semantic layer?”

It asks: **while the datacube is still embryonic, how do we stop one visible number from pretending it is safely summable, safely joinable, and safely replayable across every axis?**

## What the outside material teaches
1. **Measures have different rollup rights.**
   Kimball’s dimensional-modeling guidance separates fully additive, semi-additive, and non-additive facts. Additive facts can be summed across any associated dimension, semi-additive facts can be summed across some but not all dimensions, and ratios are examples of non-additive facts. Kimball also recommends storing the fully additive components of a non-additive fact where possible and computing the final non-additive answer later. Harbor should steal that split: a number should declare whether it is additive, semi-additive, or composite before it is widely reused.

2. **Some dimensions are explicitly non-additive.**
   dbt’s measure spec includes `non_additive_dimension` for measures that cannot be aggregated over certain dimensions, with examples like balances or recurring revenue over time. Harbor should steal the behavioral lesson: when a measure is unsafe across one axis, the forbidden axis should be named instead of left as analyst folklore.

3. **Ratios are safer when built from components, not re-summed from displayed subgroup values.**
   dbt’s ratio metrics require a numerator metric and a denominator metric, and when they come from different semantic models, dbt computes them in subqueries and then joins on common dimensions before calculating the final ratio. Harbor should steal the posture: rates and percentages deserve component-first construction and dimension-aligned recomputation.

4. **Fanout is a correctness problem, not just a performance problem.**
   Looker’s symmetric-aggregates guidance shows how one-to-many joins can produce incorrect sums, averages, and counts. Looker’s mitigation depends on a unique primary key and the correct join relationship so each fact is counted the correct number of times. Harbor should steal the lesson: a joined lane must say how it fences fanout before it publishes numbers from that join.

5. **Additivity changes what rollups and pre-aggregations are legal.**
   Cube’s data-modeling docs make additivity explicit and note that only some measure types are additive, while others are non-additive. Harbor should steal the design habit even without choosing Cube: rollup legality should be named beside the measure, not inferred later from query accidents.

6. **Mergeable approximations can be honest neighbors to exact detail.**
   Apache Druid’s DataSketches support treats sketches as mergeable approximate algorithms and can store them as additive metrics; Druid’s Theta-sketch tutorial shows why unique counts and set operations do not add up from ordinary aggregates, and how sketches enable rollup plus set operations with known approximation posture. Harbor should steal the optional sidecar idea: for selected hard distinct/set questions, an explicit sketch sidecar may be healthier than fake exactness or repeated full-detail rescans.

## Harbor consequence
Harbor should add one modest datacube/process seam now:
- **aggregation-class card** — compact declaration of whether a published number is additive, semi-additive, ratio/composite, or set/sketch-backed;
- **fanout fence** — compact note saying which base grain a measure belongs to and how one-to-many joins are prevented from multiplying it; and
- **rollup note** — compact note saying whether a number should be recomputed from components, whether it is exact or approximate, and which axes are safe/unsafe for rollup.

## What Harbor still should not decide yet
- exact semantic-layer product or warehouse-native implementation;
- exact universal registry for measure types and rollup legality;
- exact sketch family Harbor would standardize on, if any; and
- exact policy for when every published lane must carry fully machine-readable aggregation metadata.

The design-phase lesson is enough for now: **name the rollup class, keep fanout honest, and derive composite answers from components instead of from accidentally re-aggregated display values.**
