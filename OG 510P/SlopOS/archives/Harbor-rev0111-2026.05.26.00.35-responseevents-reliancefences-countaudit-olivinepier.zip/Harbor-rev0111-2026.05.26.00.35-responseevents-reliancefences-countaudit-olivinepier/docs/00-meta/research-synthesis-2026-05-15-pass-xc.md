# Research synthesis — pass XC, recurrence and escalation hygiene

**Revision:** `rev0090`  
**Date:** 2026-05-15  
**Question:** How should Harbor handle recurring stale-copy regressions, serial acknowledgement expiry, repeated unverifiable attestations, mixed-accuracy external reports, stale/disputed public warnings, and public-log/status divergence without inventing a reputation system, enforcement ladder, or incident platform?

## Result

Harbor should treat recurrence as **evidence of a pattern**, not evidence of motive or durable reliability.

The useful move is to record six small packets:

1. a recurrence pattern receipt;
2. a regression guard receipt;
3. a serial acknowledgement note;
4. a claim reliability limiter;
5. a reporter claim outcome map;
6. an escalation/cooldown/sunset note, plus a public-log/status divergence note when needed.

Together they let Harbor say: "this target regressed again, this acknowledgement history is weak, this claim family remains unverifiable, this reporter was right here and wrong there, this warning should escalate, this warning can cool down, and this old log/status surface no longer matches current proof." They do not score actors, rank reporters, prove harm, enforce remediation, certify non-use, or decide compliance.

## External lessons folded in

- NIST SP 800-61 Rev. 3 frames incident response as part of broader cybersecurity risk management and emphasizes preparation, reduced impact, and improved detection, response, and recovery. Harbor should steal continuous learning and recovery evidence, not a cyber-incident program.
- FIRST PSIRT and CSIRT service frameworks emphasize communication channels, vetting/qualification, routing, and expectations for external reports and stakeholders. Harbor should steal intake/route/status hygiene, not a PSIRT/CSIRT operating model.
- CSAF and OpenVEX keep status/action/justification tied to named subjects. Harbor should use that scoped-status discipline for recurring claims and standing challenges, not import vulnerability-advisory governance.
- RFC 9111 caching keeps freshness, staleness, and revalidation visible. Harbor should model warning cooldown/sunset similarly: time and validation matter, and stale does not mean false.
- Statuspage guidance separates incident updates, status, and postmortems; customer communication should start early and continue during an active event, while postmortems happen after resolution. Harbor should separate active warning, status surface, historical explanation, and post-hoc learning.
- RATS separates Evidence, Verifier appraisal, Attestation Results, and Relying Party appraisal. Harbor should borrow the split: a downstream claim, a verifier packet, and a public decision are different artifacts.
- SCITT and Rekor reinforce that signed or logged statements improve auditability and inclusion evidence, but the log does not decide current truth.
- W3C PROV invalidation/revision language is useful for exact target entities, but recurrence and sunset must name the entity/set being invalidated, superseded, or moved historical-only.

## SlopOS-specific interpretation

SlopOS is still in design phase, so Harbor should avoid durable recurrence/reputation schemas.

The SlopOS lessons are:

- explicit local evidence beats ambient latest status;
- multiple evidence artifacts do not create one closure rule;
- adapter receipts and foreign-cell observations stay non-authoritative unless explicit ordering/evidence witnesses exist;
- update/SBOM/VEX/attestation status artifacts are imported evidence with subject boundaries, not native SlopOS truth;
- recurrence language must remain smaller than SlopOS authority, smaller than actor identity, and smaller than enforcement.

## New watchlist handles

- `recurrence_pattern_receipt`
- `regression_guard_receipt`
- `serial_acknowledgement_note`
- `claim_reliability_limiter`
- `reporter_claim_outcome_map`
- `escalation_cooldown_sunset_note`
- `public_log_status_divergence_note`
- `standing_challenge_open`
- `warning_sunset_candidate`

## Practical design rule

Prefer pattern language that preserves uncertainty:

- `regressed again on target X`, not `actor is unreliable`;
- `acknowledgement expired again`, not `ignored the correction`;
- `claim family requires verifier evidence`, not `claimant is untrusted`;
- `report confirmed in fields A/B; rejected in C`, not `reporter confidence 70%`;
- `warning active for target X`, not `global hazard`;
- `cooldown after clean windows`, not `forgiven`;
- `sunset to historical-only`, not `deleted`;
- `logged old claim differs from current status`, not `log is truth` or `status page is truth`.

## Followthrough result

`F085` is now complete as a pressure test. The next seam is external escalation and review-packet handoff: standing challenges that need auditor/regulator/source-owner packets, appeal windows, public-log/status-page divergence, and sealed evidence boundaries after escalation.
