# SlopOS and companions evaluation — pass XCVIII

**Revision:** `rev0098`  
**Date:** 2026-05-22  
**Focus:** deterministic mutation pressure over executable Harbor bundles without promoting a shared schema or generated conformance suite.

## SlopOS pressure

SlopOS has been pushing Harbor toward accepted-only durable evidence, replayable fixtures, and refusal of hidden suffixes or malformed envelopes. F093 extends that discipline one layer upward: the checkers themselves must face deliberate mutations.

The Harbor-side property/mutation bundle keeps SlopOS-compatible discipline by requiring:

- deterministic baseline bundle digests;
- named mutation operators;
- killed/survived results;
- checker reasons rather than silent pass/fail booleans;
- explicit shrink notes;
- no record id for rejected candidates;
- no generated conformance suite;
- no imported SlopOS internal shape.

Harbor still does not copy SlopOS internals, SlopOS replay formats, or final SlopOS datacube shape. It only borrows the habit that a claim must be replayable and bounded by what was actually checked.

## Companion pressure

- **Steward:** replay guards and pushback budgets argue for deterministic mutation replay and no background fuzz campaign.
- **Foundry:** classification pins and witness crosswalks argue that operator names, invariant labels, and checker reasons stay explicit.
- **Schell:** retention and forgetting ledgers argue that generated mutants must not become permanent memory unless promoted by a human-readable packet.
- **ViewFS:** trusted-path and consent fences argue that a generated case is not user comprehension or authorization.
- **Helm:** repair/intervention traces argue that survived mutants become triage/repair records, not immediate schema conclusions.
- **Ward:** delegation warrants argue that checker authority remains local to the bundle it checks.

## Harbor delta

`rev0098` adds:

- a property/mutation coverage design surface;
- a deterministic 38-mutation meta-bundle;
- a harness and checker wired into `make check` and `package-release`;
- proof obligations `PO-PM-001` through `PO-PM-006`;
- specimen flow 93;
- pass XCVIII research and companion evaluation surfaces;
- source/register, lessons, inspiration, manifest, roadmap, context, and briefing updates.

## Deliberate non-promotion

This pass does not promote a property-testing framework dependency, fuzzing campaign, shared bundle schema, generated conformance suite, numeric coverage gate, certification badge, production validator, or final SlopOS datacube shape. It only promotes the expectation that executable Harbor checkers should be mutation-pressured before their vocabulary is trusted more widely.
