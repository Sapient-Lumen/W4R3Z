# SlopOS / companions evaluation — pass LXXXII

This pass asks how Harbor should evaluate `F077` while SlopOS's datacube remains in design phase. The answer is to make replay evidence audience-bound and redaction-aware without choosing a proof substrate or turning proof bundles into portable authority.

## SlopOS lessons used directly
- **Replay bundles are sensitive.** SlopOS `CH-RRBUNDLE v0` says record/replay bundles may contain secrets, device reads, user data, and other sensitive payloads; export should go through explicit portal/consent paths and manifest entries remain digest-bound even when payloads are encrypted. Harbor borrows the warning: exact replay evidence is not automatically consumer-visible.

- **Observation export is policy-constrained, not authority-granting.** SlopOS `CH-OBSPOL v0` pins allowlists, bounds, redaction classes, and fail-closed export behavior, while saying the policy constrains exports rather than granting authority. Harbor turns that into redaction cuts and audience-bound evidence views for datacube answers.

- **Proof-bundle labels are descriptive.** SlopOS `proof-bundle-role-boundary-v0` refuses to let `proof_bundle` imply a universal format, verifier profile, approval state, recursive fetch plane, or install shortcut. Harbor applies the same rule to frozen-answer proof packets: bundle presence does not pick verifier policy or discloseability.

- **Digest-first audit payloads are not plaintext channels.** SlopOS `CH-CRYPTOAUDIT v0` keeps crypto-operation transcripts redaction-safe by recording operation kind, key attribution, lengths, digests, decision, and policy/lease links without raw secrets. Harbor borrows the pattern for replay-evidence receipts: exact digests can support verification without dumping payloads.

- **Source locks must remain exact.** SlopOS boundary-index, policy-handle, replay, and proof-bundle surfaces all favor exact digests, canonical encoding, and pinned generations over ambient current truth. Harbor extends replay-survivability with source-lock drift warnings: old proof must name the old source/policy/runtime basis or refuse.

## Companion-cube pressure
- **Foundry:** pinned input cuts, serving-lane humility, and replay-class pressure map to source locks and frozen answers. Foundry remains the better home for generalized package/cut mechanics; Harbor only records membrane-facing evidence-access residue.

- **Helm:** access verdicts, least-widening, review queues, and slot ledgers suggest the right audience split: consumer copy, operator copy, auditor verifier packet, and source-owner sealed packet should not collapse.

- **Schell:** basis cards and activation receipts warn that a verifier ticket is not authority to act or re-export. It is a scoped basis for one check under one policy.

- **ViewFS:** materialization/export discipline keeps a redacted proof packet as a new artifact with parent/provenance evidence, not a weaker alias for raw replay evidence.

- **Steward:** aftermath receipts and reconciliation loops suggest that refused or expired verifier tickets need followthrough, but generalized remediation belongs with Steward rather than Harbor.

- **Ward:** tier/history witnesses pressure Harbor to keep key/history evidence separate from disclosure entitlement; a historical proof can be valid and still inaccessible to the requester.

- **Foundry + SlopOS together:** pinned cuts plus proof-bundle boundary discipline produce the key posture: exact old evidence can be digest-bound, sealed, and auditable without being public or authoritative by itself.

## Harbor consequence
This pass closes `F077` by adding:

- `docs/00-meta/datacube-replay-evidence-access.md` — a review surface for evidence audiences, redaction cuts, verifier tickets, source locks, and disclosure transcripts;
- `docs/30-architecture/specimen-flow-77-replay-evidence-redaction-verifier-boundaries.md` — a concrete access/redaction/verifier specimen;
- refreshed proof obligations, lessons, inspiration harvest, source register, bibliography, roadmap, ledgers, manifest, and briefing surfaces.

## What stays open
- Whether SlopOS owns durable replay-evidence bundle formats or Harbor only emits small review residues.
- Whether redacted proof is implemented by selective disclosure, signed attestations, sealed enclaves, transparency logs, auditor challenge/response, or ordinary policy-mediated review.
- Whether public consumers ever see verifier tickets or only textual proof summaries.
- Whether source-lock drift is solved through archived policy bundles, equivalence proofs, replay sandboxes, or refusal.
- Whether aggregate visibility requires additional small-cell/privacy-budget pressure beyond replay-evidence redaction.

## Non-decision reaffirmed
No sibling cube is flattened into Harbor. SlopOS remains the likely owner of OS-level observation export policy, proof-bundle role boundaries, replay-bundle formats, and durable substrate choices. Foundry remains better positioned for generalized pinned cuts and package mechanics. Steward remains better positioned for followthrough and remediation. Harbor only records the membrane-facing datacube residue needed to avoid counterfeit evidence disclosure.
