# Research synthesis — pass XXXVIII

This pass keeps Harbor narrow and learns one more thing from browser-owned, authenticator-owned, or otherwise host-mediated review surfaces: **where the human was asked to continue matters, what they were shown matters, and both are still smaller than the grant/account/session truth that may or may not follow.**

## Outside lessons
1. **Structured asks make better reviewed summaries possible.**  
   RFC 9396 introduces `authorization_details` so OAuth requests can carry fine-grained authorization data instead of one flat scope string. Harbor should steal the shape, not the whole stack: a crossing can carry enough exact structure to support a meaningful reviewed summary without implying that the summary itself is the final grant.

2. **Protected asks matter because review basis should not be free-floating prose.**  
   RFC 9101 lets authorization request parameters ride in a signed and optionally encrypted JWT so the authorization request gains integrity, source authentication, and confidentiality properties. Harbor should steal the restraint: if a reviewed summary matters, it should stay visibly tied to exact request material rather than to requester-supplied marketing copy.

3. **Prompt location is a real safety property.**  
   RFC 8252 says native-app authorization requests should only be made through external user-agents, primarily the browser, and says embedded user-agents are unsafe because the hosting app can access the user’s full authentication credential. Harbor should therefore preserve **prompt provenance** instead of flattening all prompts into one generic “user saw a screen” story.

4. **Browser mediation and permission are real facts.**  
   FedCM places the user agent as a mediator between RP and IdP and requires user permission before the RP and IdP learn about their connection to the user. This is a great Harbor precedent: browser-owned review can be historically real without becoming adopted-account or grant truth.

5. **Consent, user presence, and user verification are neighboring but non-identical facts.**  
   WebAuthn Level 3 defines an authorization gesture as what provides consent for a ceremony to proceed; that gesture may involve a simple test of user presence or user verification; and the prompt should display RP and user display fields when possible. Harbor should steal the separation: a reviewed surface can truthfully say where the prompt lived and what was shown without pretending that every gesture equals the same assurance or the same durable consequence.

## Resulting Harbor move
Do not decide yet whether the durable nouns are exactly `prompt provenance`, `reviewed summary`, `review witness`, and `no-fake-approval honesty`, or whether later pressure compresses some of them behind smaller mediation/admission/aftermath residue.
For now, keep them alive as specimen nouns and demand that they improve:
- one structured-and-protected ask specimen where exact request basis survives into review without turning summary into grant truth;
- one browser-owned review specimen where prompt provenance stays visibly distinct from requester-owned chrome;
- and one WebAuthn authorization-gesture specimen where consent, user presence, and user verification remain neighboring but non-identical facts.

## Fresh ideas worth stealing
- **prompt provenance** — compact statement of where the human-facing review or approval prompt actually lived.
- **reviewed summary** — bounded description of what the user was actually shown, derived from exact ask/basis rather than free-floating prose.
- **review witness** — inspectable residue that a host/browser/authenticator-owned review turn really occurred here.
- **no-fake-approval honesty** — explicit bottom-out when only requester text, widget chrome, or otherwise untrusted copy was available.
- **review smaller than grant** — standing anti-regrowth rule.
