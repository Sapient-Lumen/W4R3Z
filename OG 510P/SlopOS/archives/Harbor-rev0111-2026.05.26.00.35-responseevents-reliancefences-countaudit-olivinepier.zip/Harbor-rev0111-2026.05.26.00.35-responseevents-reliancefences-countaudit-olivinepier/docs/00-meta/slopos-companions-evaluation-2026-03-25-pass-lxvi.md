# SlopOS / companions evaluation — pass LXVI

This pass asks a process question rather than a warehouse question: if Harbor starts attaching assertions to candidate or published lanes while SlopOS is still in design phase, how does Harbor stop assertion noise, outages, and temporary exceptions from turning into ambient folklore?

## What the companions teach this pass
- **SlopOS** remains the strongest process teacher because it keeps claim surfaces, posture surfaces, and evidence surfaces separate. Its profile-claim matrix, profile-posture matrix, evidence index, and review queues all teach the same lesson: saying what is claimed, how strongly it is claimed, and what evidence supports it are different jobs. Harbor should steal that discipline for datacube assertions.
- **SlopOS** also keeps mutable-head source review explicit instead of trusting memory. That is a good nearby model for assertion waivers: temporary exceptions should have a visible expiry and re-review moment instead of lingering as invisible tribal knowledge.
- **Foundry** keeps teaching promotion-candidate discipline. That makes it a good neighborly reminder that a failing assertion can block promotion without rewriting the candidate lane's underlying meaning.
- **Ward** keeps teaching tier witnesses and hybrid seams. Harbor should borrow that attitude for observed-value notes: sampled, estimated, unavailable, and exact evidence should not collapse into one flat badge.
- **Steward** keeps proving that compact receipts beat oral history. Harbor should therefore prefer a small waiver receipt over a vague "we know this lane is flaky right now" folk story.

## Harbor consequence
Harbor should make exactly one modest repo/process expansion now:
- add a datacube assertion-posture surface;
- add one specimen around assertion posture cards, observed-value notes, and waiver receipts;
- refresh the load-bearing source register with living sources that shape severity and threshold discipline; and
- keep restatement, semantic-front-door, and change-history pressure as the next major datacube frontier instead of pretending assertion posture solves those larger questions.

## Still-not-yet decisions
- whether waivers ever deserve a first-class machine-readable registry;
- whether observed-value notes should later compile from warehouse/test output automatically;
- whether neighboring cubes should share one common severity vocabulary.

For now, the companion lesson is enough: **separate claim from posture, separate posture from evidence, and leave temporary exceptions as typed residue rather than atmosphere.**
