# SlopOS / companions evaluation — pass LIV

This pass re-checks Harbor against SlopOS and the sibling cubes after adding a JWT-secured introspection / response-precedence / alias-mismatch specimen, and again chooses one narrow crossing seam over any early family bloom.

## What the current cubes still teach
- **SlopOS** remains the strongest restraint mechanism. Its imported auth-discovery, auth-response-packaging, token-passthrough, and authorization-context seams keep fetched auth metadata, response packaging, and upstream token targeting provider-local or request-local rather than portable cross-cube truth. That lines up with Harbor treating JWT-secured introspection as signed receiver-facing residue rather than portable protected-resource proof.
- **SlopOS** also keeps reinforcing the design-phase lesson that exact resource acceptance rules stay local until repeated specimens prove otherwise. Harbor should borrow that humility directly for alias-family mismatch notes and any response-over-token precedence rule.
- **Ward** still reinforces exact-basis and typed refusal posture: a signed or audience-plausible token can still deserve refusal when the current receiver’s exact expectation fails.
- **Helm** still contributes display humility: explanatory UI can say “the token named ledger-api”, but that remains subordinate to exact returned-resource confirmation and receiver-local refusal.
- **Foundry** still teaches aftermath honesty: a turn can leave useful residue like “signed introspection succeeded for this receiver” or “returned `resource` outranked token audience” without becoming runtime authority.
- **Steward** still teaches accountable endings: when Harbor bottoms out in alias-family mismatch, the archive should say so plainly instead of flattering the turn into silent success.

## Harbor consequence
Harbor should keep this move modest:
- add one specimen around **JWT introspection response card**, **response-over-token precedence**, and **alias-family mismatch note**;
- keep signed introspection recipient facts, nested token audience facts, explicit returned-resource confirmation, and receiver-local refusal visibly separate;
- collect **recipient-target split** as inspiration only; and
- leave any future portable audience, alias, or target-confidence registry outside Harbor for now.

## Still-not-yet decisions
- Whether **JWT introspection response card** deserves its own Harbor family, or should remain only an annotation on specific receiver-facing aftermath surfaces.
- Whether **response-over-token precedence** belongs in Harbor at all, or should remain only a standing interpretation rule attached to specific token-response specimens.
- Whether **alias-family mismatch note** belongs in Harbor, or should stay a typed local explanation that never blooms into a portable target-confidence, coverage, or entitlement registry.
