# SlopOS / companions evaluation — pass XXVII

This pass re-checks Harbor against the uploaded cube ecology and keeps the architecture embryonic.

## What the current cubes still teach
- **SlopOS** keeps the most important watch-state warning pinned in several places: imported MCP progress remains provider-local liveness signaling only, imported MCP logging remains provider-local diagnostic signaling only, imported caller-auth/session guidance remains provider-local live auth mechanics only, and core portal sessions keep one terminal outcome with no generic resume/list/watch surface. That strongly supports a Harbor move that metabolizes later attenuation signals **without** inventing a portable live-session or generic stream-management plane.
- **Ward** is the closest sibling for this pass. Its newer work keeps attenuation events, status receivers, and local consequence visibly separate. Harbor should borrow the posture but keep the exchange-side scope smaller: later auth/session drift can demote continuity or demand revalidation without becoming a full trust-verdict cube.
- **Steward** still helps on the UX side. Its freshness, liveness, and followthrough cuts keep probes and renewal smaller than durable readiness or completion. Harbor should steal that honesty for signal-driven revalidation instead of flattening everything into “session dead” or “session alive”.
- **ViewFS** keeps watchers, notifications, and auto-refresh advisory and rebuild-friendly rather than perfect authority truth. Harbor should analogize from that and avoid turning SSF/CAEP delivery posture into a live current-state oracle.
- **Helm** continues to separate request acceptance, local durability, replication, and receiver-visible settlement. Harbor can borrow the same discipline: signal receipt and local consequence are not the same seam.

## Harbor consequence
Harbor should keep continuous-attenuation nouns provisional.
The right near-term move is small:
- add one specimen around `attenuation notice`, `receiver stance`, `revalidation floor`, and signal drift honesty;
- keep event-stream ownership, subject-matching registries, durable session truth, and generic watch surfaces outside Harbor-owned vocabulary;
- and keep later security events visibly smaller than universal logout, universal compromise, or a portable live-session plane.

## Still-not-yet decisions
- Whether `attenuation notice` deserves its own first-class card or remains a typed aftermath/update annotation on route and continuity surfaces.
- Whether `receiver stance` is distinct from broader risk/adoption vocabulary or just one local consequence family.
- Whether Harbor ever needs a first-class stream/status object at all, or whether delivery and management posture should remain anti-goals while providers and neighboring cubes keep owning the live mechanics.
