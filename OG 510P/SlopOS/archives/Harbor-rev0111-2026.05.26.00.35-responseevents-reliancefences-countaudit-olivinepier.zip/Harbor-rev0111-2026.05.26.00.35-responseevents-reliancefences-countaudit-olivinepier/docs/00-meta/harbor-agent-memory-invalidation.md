# Harbor agent-memory invalidation notes

**Status:** design-phase note for `rev0094`; not an agent-memory system, vector index, crawler, deletion workflow, model-unlearning process, eval governance program, or final SlopOS datacube shape.

Stale public copy can survive in generated explanations, retrieval chunks, prompt templates, summaries, tool-result caches, browser previews, MCP resource listings, and eval fixtures. Harbor may record `requested`, `observed`, `failed`, or `out_of_scope` invalidation for named surfaces. It must not claim training unlearning, all-agent memory repair, global retrieval currentness, or future behavior correction.

Minimum note:

```text
subject public copy / digest:
stale surface:
expected current label or wording digest:
agent/cache/tool surface:
invalidation action requested:
observation basis:
status: requested | observed | failed | out_of_scope
non-promises:
```

Counterfeit blocked: `the agent saw a correction once` becoming `the agent is corrected forever`.
