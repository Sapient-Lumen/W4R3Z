# Research synthesis — pass XXXIX

This pass keeps Harbor narrow and learns one more thing from structured asks and mediated prompts: **what was reviewed must stay tied to an exact basis, stale summaries must fail closed, and requester-owned copy must stay smaller than trusted review.**

## Outside lessons
1. **Exact review basis beats floating prose.**  
   RFC 9101 says the authorization server MUST only use the parameters in the Request Object even if the same parameter is also provided in the query, and the `client_id` in the request parameter and Request Object MUST be identical. Harbor should steal that exactness: when a reviewed summary matters, it should point back to one inspectable basis rather than to whatever copy happened to be visible.

2. **Fine-grained asks help, but they still need protected transport.**  
   RFC 9396 introduces `authorization_details` for fine-grained authorization data and recommends request objects / `request_uri` with PAR for large or security-sensitive asks. Harbor should therefore treat rich asks as a better source for summaries, not as permission to let free-floating UI prose become canonical.

3. **Chooser/prompt UI must be distinguishable from website UI.**  
   Credential Management says a chooser UI should be distinguishable from UI a website could produce and must include an indication of the requesting origin. Harbor should steal both ideas directly: prompt provenance and exact requester identity cues are real review facts.

4. **Browser-mediated permission only counts when the user agent owns the turn.**  
   FedCM requires user permission, gates token fetch on user interaction with user-agent UI, and says the user agent cannot be spoofed or otherwise tricked for that token fetch. Harbor should therefore preserve explicit residue for “this review happened on a host/UA-owned surface” and explicit negation for requester-owned chrome.

5. **Displayed review fields need boundaries and freshness.**  
   WebAuthn Level 3 says the authorization-gesture prompt is shown by the authenticator if it has output capability or by the user agent otherwise; it should display RP and user fields when possible; and displayed `displayName` values should have a clear UI boundary. Harbor should steal the broader principle: a reviewed summary needs a visible boundary and should bottom out honestly when it no longer matches the live basis.

## Resulting Harbor move
Do not decide yet whether the durable nouns are exactly `basis witness`, `summary freshness`, `stale-basis denial`, and `requester-copy negation`, or whether later pressure compresses some of them behind smaller mediation/review residue.
For now, keep them alive as specimen nouns and require that they improve:
- one JAR/RAR specimen where an exact ask survives into review without free-floating copy becoming canonical;
- one chooser/browser-mediated specimen where fake requester chrome is explicitly smaller than the host-owned prompt;
- and one stale-mutable-basis specimen where approval/review depends on the exact reviewed revision and fails closed once the basis drifts.

## Fresh ideas worth stealing
- **basis witness** — inspectable tie from a reviewed summary or prompt to the exact structured ask / revision / descriptor it was based on.
- **summary freshness** — compact truth about whether the rendered summary still matches the live basis at approval/adoption time.
- **stale-basis denial** — explicit bottom-out when the review or approval surface was based on an older mutable state.
- **requester-copy negation** — standing rule that requester-owned prose, widget chrome, or copied summary text cannot substitute for host/UA/authenticator-reviewed basis.
- **review basis smaller than consequence** — standing anti-regrowth rule.
