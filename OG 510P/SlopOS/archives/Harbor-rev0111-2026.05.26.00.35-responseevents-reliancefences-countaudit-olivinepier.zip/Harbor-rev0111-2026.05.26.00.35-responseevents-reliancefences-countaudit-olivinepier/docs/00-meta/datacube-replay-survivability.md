# Datacube replay survivability

This surface is a **review surface**, not a schema, storage policy, archival product, replay service, or ADR.

It exists because Harbor now has enough history, restatement, negative-evidence, sidecar, and option-reservation seams that old cube-shaped answers can fail in subtle ways. A system can still explain why an answer once existed after it can no longer recompute it exactly. That distinction must be visible before SlopOS chooses any final datacube substrate.

## Standing rule
Historical answerability is a survivor-set question:

> To answer exactly, Harbor must know which old artifacts must survive together, which have actually survived, and which answer mode is still honest.

## Handles reserved for review
These handles are intentionally small. They are useful words for specimens and proof packets, not durable datacube objects yet.

### Survivor set
The minimum artifact set needed for the requested historical answer mode.

Typical members:
- base data cut or snapshot;
- change-history / tombstone / delete evidence;
- schema, contract, and policy epoch;
- query/view/semantic-export definition and digest;
- assertion compiler target and version, if assertions are part of the answer;
- sidecars used by the answer: lineage, statistics, sketches, frontiers, facets, indexes;
- unit/currency/rate and measurement basis;
- engine/runtime/dialect assumptions when exact recomputation depends on them;
- frozen published answer packet, if the requested mode accepts answer replay rather than recomputation.

### Replay-readiness receipt
A compact note that says an exact recompute is still possible for one question and cut. It must name the retained survivor set and any access constraints.

### Frozen-answer packet
A preserved output plus enough basis, digest, and contract/policy metadata to say “this was the answer Harbor published then.” It can support exact old-answer retrieval, but it does not prove that the answer is still current, still authorized for every consumer, or recomputable from base rows.

### Retention-window note
A note naming the retention clocks that affect the answer. Base snapshots, transaction logs, tombstones, sidecars, policy histories, compiler targets, and query definitions may expire on different schedules.

### Sidecar-retention mismatch note
A note that base replay may remain possible while drilldown, lineage, sketch-merge, frontier, or optimizer-stat evidence is gone, or vice versa.

### Explainable-but-not-replayable verdict
A verdict that enough receipts remain to explain a past answer, but not enough artifacts remain to recompute it exactly or return it as a preserved frozen answer.

### Exact-answer refusal row
A bounded refusal when the consumer asks for an exact historical answer and the survivor set is incomplete, inaccessible, or policy-blocked.

## Answer modes

| mode | allowed claim | minimum posture |
| --- | --- | --- |
| `exact_recompute_ready` | Harbor can recompute the old answer from retained artifacts | survivor set retained and accessible; runtime/query/policy basis named |
| `exact_frozen_answer_ready` | Harbor can return the exact answer it published then | frozen-answer packet retained with digest and basis; current authorization checked |
| `partial_replay_ready` | Harbor can recompute a narrower answer | missing dimensions/drilldowns/sidecars named; exact scope narrowed |
| `explainable_not_replayable` | Harbor can explain but not recompute or return exact old answer | retained receipts list what survived and what expired |
| `unsafe_to_answer` | Harbor refuses the historical answer | missing/inaccessible survivor set or policy block named without leaking sensitive facts |
| `restated_successor_only` | Harbor can show a newer corrected answer and restatement receipt | old exact answer not returned as current truth; restatement basis named |

## Retention clocks to inspect

| artifact class | why it matters |
| --- | --- |
| base row/table snapshot | without it, exact recomputation may fail even if query text survives |
| transaction/change log | needed for as-of reconstruction, changed-row history, and restatement audit |
| tombstone/delete evidence | absence after compaction does not prove no delete happened |
| sidecar: lineage/statistics/sketch/facet/frontier | may be required for drilldown, exactness, frontier, or proof obligation even when base rows survive |
| view/semantic export definition | preserved definitions are lenses, not data; missing definitions can block exact old question shape |
| assertion compiler target | old check result may depend on target semantics that changed or were unsupported |
| policy/contract epoch | current authorization and old publication rights are different questions |
| measurement/rate basis | converted or normalized values need the old rate/unit basis to replay exactly |
| engine/dialect/runtime | exact query equivalence may depend on planner, rounding, null semantics, time zone, or function versions |
| frozen answer packet | can preserve old output even when recomputation is impossible, but remains smaller than row truth |

## Anti-counterfeit tests

| counterfeit | expected Harbor response |
| --- | --- |
| `time_travel_supported` shown as `exact_answer_available` | reject; name the retained cut and expiry basis |
| current query rerun shown as old answer | reject; current state is not an as-of cut |
| expired tombstone treated as proof of no deletion | reject; tombstone expiry is evidence loss |
| retained sidecar used as proof that base rows survive | reject; sidecars are not base data |
| retained base cut used as proof that lineage drilldown survives | reject; drilldown depends on its own survivor set |
| emergency/fail-safe recoverability shown as ordinary query access | reject; recovery mode, access, and metadata limits must be named |
| frozen answer packet shown as current truth | reject; it can only say what was published then |
| exact old answer shown to a consumer whose current policy no longer allows it | reject or redact; current access policy still matters |
| compaction/frontier advancement shown as business deletion | reject; progress compaction and logical withdrawal are different |
| query definition preserved but engine/dialect semantics changed silently | reject; exactness needs runtime/dialect basis or a downgrade verdict |

## Minimum survivability packet

```text
Historical question:
Requested mode:
Original publication/cut:
Survivor set required:
Survivor set present:
Survivor set missing or inaccessible:
Retention clocks checked:
Policy/contract epoch checked:
Sidecar mismatch, if any:
Tombstone/delete evidence posture:
Frozen answer packet posture:
Recompute/runtime basis:
Verdict: exact_recompute_ready | exact_frozen_answer_ready | partial_replay_ready | explainable_not_replayable | unsafe_to_answer | restated_successor_only
Consumer-visible copy:
Operator-visible detail:
Non-promises:
Followthrough / recheck:
```

## Non-decisions
This surface does not choose:
- a warehouse, lakehouse, event log, stream processor, object store, backup system, or replay service;
- one retention duration;
- one public historical-answer API;
- one answer-pack schema;
- one policy for emergency recovery or auditor access;
- one final SlopOS datacube representation.

## Relationship to existing Harbor surfaces
- `datacube-change-history-lanes.md` says what kind of history a lane promises.
- `datacube-evidence-grades.md` says how strong the current evidence is.
- `datacube-negative-evidence-refusal-ledgers.md` says how to record scoped missing/refused evidence.
- This surface asks whether enough of the old survivor set remains to answer the old question honestly.

## Pass LXXXI status
Specimen flow 76 exercises replay survivability but does not promote the handles above into durable schema. The open question is whether repeated retention-window failures make a minimal survivability packet necessary for every published datacube lane.
