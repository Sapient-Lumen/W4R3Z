# Datacube review loop

Purpose: keep Harbor’s datacube repo honest while the cube is still in design phase.

Harbor is healthiest when each revision does a small number of things completely:
- refresh the living outside sources that are load-bearing for the current question;
- write down what this pass learned and what it still refused to decide;
- keep generated semantic artifacts visibly smaller than review surfaces; and
- package a deterministic handoff so later revisions inherit one clean evidential state.

## Required loop for design-phase datacube revisions
1. **Name the question of the pass.**
   Every datacube-side revision should say what design pressure it is actually studying: time axes, contracts, rollups, history, measurement semantics, semantic-front-door exports, or something else.

2. **Refresh living sources before noun promotion.**
   If a new noun depends on living product or standards docs, refresh those sources in the same revision before promoting the noun.

3. **Write both pass notes when the datacube moved.**
   A datacube-moving revision should leave:
   - one research-synthesis note; and
   - one SlopOS / companions evaluation note.
   The pair keeps outside facts and cube-ecology lessons visibly separate.

4. **Promote nouns only with evidence or an explicit open question.**
   A new card, note, witness, or lane should connect to a same-revision specimen, a same-revision research pass, or an explicit question/followthrough item.

5. **Keep generated artifacts derived.**
   Semantic-model YAML, BI explores, catalog exports, metric APIs, freshness configs, join-relationship hints, row-lineage manifests, and engine-specific DDL may exist, but they stay compiled artifacts until Harbor explicitly says otherwise.

6. **Refresh the repo surfaces together.**
   If the pass is load-bearing, update:
   - `docs/00-meta/lessons-we-must-learn.md`;
   - `docs/90-inspirations/steal-these-ideas.md`;
   - `docs/00-meta/load-bearing-source-register.md`;
   - the relevant ledgers/queues; and
   - the briefing surfaces (`README.md`, `START_HERE.md`, `docs/README.md`, `CHANGELOG.md`).

7. **Keep one `next` item.**
   Harbor may have many queued ideas, but only one followthrough item should hold the single `next` slot.

8. **Run hygiene and deterministic packaging.**
   Refresh the archive index and manifest, run repo hygiene, and emit the deterministic release zip in the same revision.

## Anti-drift rules
- Do not let a generated semantic artifact silently outrank the archive prose/specimen surfaces.
- Do not create a new family/index/registry just because a vendor product has one.
- Do not flatten contract promise, assertion result, freshness basis, and current evidence into one flattering badge.
- Do not let row-lineage or surrogate-ID ideas harden into constitutional truth before repeated specimens show they are truly needed.
- Do not let a pass add multiple simultaneous `next` items or leave release/briefing surfaces stale.

## Design-phase reading of this rule
The point is not bureaucracy. The point is to preserve optionality while the datacube is still moving.

A good Harbor revision is therefore allowed to be narrow, but it should still leave behind:
- refreshed sources,
- one explicit lesson,
- one explicit non-decision,
- one honest queue state, and
- one deterministic package.


## Pass LXXVII proof-obligation gate
Before a datacube noun moves from watchlist/process note into embryo vocabulary, the reviewer must assemble a proof packet using `docs/00-meta/datacube-proof-obligations.md`.

Minimum review sequence:
1. identify the specimen that creates repeated pressure;
2. name which proof obligations are satisfied and which are not;
3. state the counterfeit being blocked;
4. record what irreversible decisions remain avoided;
5. update source register, ledgers, followthrough, manifest, briefing surfaces, and archive index in the same revision; and
6. keep exactly one `next` followthrough item.

This gate is especially important for measurement, semantic-front-door, derived-view, row-lineage, statistics-sidecar, watermark/frontier, schema-transform, and assertion-compiler ideas because each of them can look authoritative before it is actually earned.


## Pass LXXVIII review-loop addition
Semantic-export changes must refresh the export receipt, contract subset, freshness basis, join/fanout proofs, row-lineage sidecar posture, and refused-questions list together. A generated semantic model, BI configuration, or catalog export is not enough evidence unless the refusal surface and proof obligations are also present.

## Pass LXXX review addendum
When a datacube-moving revision records a negative result, it must say whether the result is missing optional evidence, missing required evidence, blocked by policy, unsupported target, stale progress, preview-only, withdrawn-currently, or unknown/not-observed. It must also separate consumer-visible refusal copy from operator-visible evidence and name the recheck/expiry path before the refusal can influence a publish decision.
