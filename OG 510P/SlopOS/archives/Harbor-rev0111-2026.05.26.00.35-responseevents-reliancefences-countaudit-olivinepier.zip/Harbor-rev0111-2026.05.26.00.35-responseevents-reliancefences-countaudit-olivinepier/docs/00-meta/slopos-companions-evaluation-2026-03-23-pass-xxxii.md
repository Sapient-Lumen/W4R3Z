# SlopOS / companions evaluation — pass XXXII

This pass re-checks Harbor against the uploaded cube ecology and keeps the architecture embryonic.

## What the current cubes still teach
- **SlopOS** is the clearest anchor again. RFC-0105 standardizes request contexts with deadlines and cancellation while saying, in plain language, that cancellation/deadlines are coordination and resource hygiene, not a security boundary. Harbor should steal the posture without stealing a universal context substrate.
- **SlopOS** also recommends minting a fresh root context for work that intentionally outlives its caller. That is exactly the anti-regrowth lesson Harbor needs: a crossing that survives caller abandonment should do so by explicit re-ownership elsewhere, not by pretending the old lane still owns it.
- **Schell** is a good sibling for this pressure. Its pipefail/wait posture rewards explicit non-completion and makes it easier to keep “stopped here” different from “provider refused” or “nothing happened.”
- **Steward** keeps cancellation, lease expiry, and follow-on effects operationally explicit. Harbor should borrow the honesty while staying much smaller than a supervisor, workflow manager, or durable job ledger.
- **ViewFS** already distinguishes cancel, terminate, forget, reset, and rerun. That is useful pressure on Harbor: caller abort, chooser dismissal, deadline expiry, and local re-run should not collapse into one generic failure bucket.

## Harbor consequence
Harbor should keep cancellation-state nouns provisional.
The right near-term move is small:
- add one specimen around `abort pulse`, `cancellation witness`, `deadline floor`, and `completion-race honesty`;
- keep dismissals, aborts, and deadline bottoms visibly smaller than provider refusal or durable account/session truth;
- and keep any work that survives caller cancellation owned by a stronger neighboring cube instead of by Harbor.

## Still-not-yet decisions
- Whether `cancellation witness` deserves its own first-class card or remains an annotation on detour state / aftermath receipt.
- Whether `completion-race honesty` should become a first-class aftermath modifier or stay a standing anti-regrowth rule.
- Whether `dismissal cooldown` is Harbor material at all, or whether it belongs as browser/provider-local residue only mentioned in specimens.
