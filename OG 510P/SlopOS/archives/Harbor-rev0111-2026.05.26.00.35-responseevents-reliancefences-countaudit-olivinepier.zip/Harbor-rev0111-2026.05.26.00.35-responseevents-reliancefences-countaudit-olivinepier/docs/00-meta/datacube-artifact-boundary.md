# Datacube artifact boundary

Purpose: keep Harbor’s datacube review surfaces canonical while the cube is still in design phase.

Why this exists:
- Harbor now has enough datacube pressure that generated artifacts will start to look tempting: SQL DDL, dbt semantic-model YAML, catalog-export files, test branches, historical tags, pre-aggregation manifests, or engine-specific table definitions;
- SlopOS already teaches the healthier order: markdown/JSON review surfaces stay canonical, while generated machine artifacts remain compiled or derived outputs until the repo explicitly decides otherwise;
- Harbor therefore needs one explicit rule that keeps experiment lanes, publish lanes, and generated datacube artifacts from silently becoming a second source of truth.

This doc does **not** choose a warehouse engine, table format, catalog product, branch system, semantic-layer vendor, or universal row-identity regime.
It is a design-phase boundary for review surfaces and derived datacube artifacts only.

## Boundary (Phase 1)

1. **Canonical review surfaces stay in the archive.**
   - The durable review surfaces for Harbor’s datacube remain the prose/specimen/ledger docs in this repo.
   - Grain declarations, history posture, promotion rules, and open questions are reviewed here before any engine-specific artifact becomes important.

2. **Generated datacube artifacts are derived artifacts only.**
   - Generated SQL DDL, dbt semantic-model configs, catalog-export descriptors, schema files, BI explore definitions, metric API descriptors, freshness configs, join-relationship hints, row-lineage manifests, or engine-specific lane definitions may exist, but they are derived from the review surfaces and remain smaller than them.
   - A generated artifact must name the exact Harbor revision and lane it reflects.

3. **Experiment lanes are not canonical truth.**
   - A branch rehearsal, audit tag, shadow catalog, or temporary publish lane may pressure-test a contract or a backfill.
   - Until Harbor records an explicit promotion move, those lanes remain experimental residue rather than canonical datacube truth.

4. **Promotion must be explicit.**
   - If an experimental lane is adopted, Harbor should leave a compact promotion receipt explaining what advanced, what stayed experimental, and what historical surfaces remain frozen.

5. **No second source of truth.**
   - A generated artifact, a catalog export, or one successful experimental branch must not silently outrank the repo’s review surfaces.
   - If Harbor ever wants generated datacube artifacts to become authoritative, that decision must land as one explicit new RFC/ADR-grade surface in the same revision that introduces the change.

## What this forbids in Phase 1
- no hidden upgrade from specimen docs to “official” engine-specific schema law;
- no silent assumption that one catalog export or semantic-layer config now defines Harbor’s ontology;
- no immortal staging branches that behave like production without explicit adoption;
- no retroactive rewriting of old published revision meaning because a branch head evolved later.

## Why this is worth deciding now
- It protects optionality while Harbor and SlopOS are both still designing their datacube story.
- It lets Harbor steal good ideas from Iceberg and lakeFS without committing to either product.
- It keeps repo hygiene stronger than tool convenience.
- It gives future generated artifacts a crisp place to stand: useful, versioned, inspectable, and still smaller than canonical review truth.
