# Research synthesis — pass XLIV

This pass keeps Harbor narrow and learns five compatible things at once: **browser auth increasingly returns through secondary windows and `postMessage`, exact receiver/sender origin checks are a real boundary rather than an implementation footnote, popup/iframe lane choice needs truthful residue, the shift from redirect-path confinement to origin-level confinement changes the leak surface, and resource-selection echoes are interesting enough to collect without freezing a new family today.**

## Outside lessons
1. **Secondary-window auth is real, not an edge case.**  
   The current web-message response-mode draft defines `web_message` for popup-based and iframe-based authorization flows and notes that these multi-window flows are already widely used in practice. Harbor should therefore treat secondary-window returns as a first-class pressure source rather than an SDK oddity.

2. **Receiver origin must be exact.**  
   The same draft requires the authorization server to use the full redirection URI as the `postMessage` receiver origin, and explicitly says the server must not parse the URI itself. Harbor should preserve a small **receiver-origin witness** rather than assuming “same app shell” is good enough.

3. **Sender origin must be checked too.**  
   RFC 9700 documents three concrete in-browser messaging failures: wildcard receiver origins, attacker-provided receiver origins, and insufficient sender-origin validation. The browser-based-apps draft then states the client must verify both the initiator origin and the receiver origin of a `postMessage`. Harbor should keep room for a **message-origin fence** without pretending it already owns a universal browser-message security model.

4. **Lane choice matters in browser messaging flows.**  
   The web-message draft adds `web_message.opener` and `web_message.parent` so a client can signal whether the primary window reference should be `window.opener` or `window.parent`. That is a useful Harbor signal: the lane that was meant to receive the finish is a separate fact from the finish itself.

5. **Origin-scoped return is broader than path-scoped return.**  
   The web-message draft explicitly notes that redirect-based flows confine the authorization response to a path-bearing redirection URI, while web-message confidentiality is scoped only to the receiver origin. That is exactly the kind of historical lesson Harbor should keep visible: the same auth ceremony can become wider or leakier when its finish moves from redirect path to origin-scoped browser messaging.

## Resulting Harbor move
Do not decide yet whether Harbor needs durable nouns such as **receiver-origin witness**, **secondary-window lane**, or **message-origin fence**.
For this revision:
- add one specimen around popup/iframe auth returns delivered via `postMessage`;
- preserve the difference between opener/parent lane choice, expected receiver origin, observed sender origin, and any later local adoption;
- and collect **effective-target echo** as inspiration only from newer OAuth resource-selection work, without promoting a new aftermath family yet.

## Fresh ideas worth stealing
- **receiver-origin witness** — exact locally expected origin that a browser-messaging finish was allowed to target.
- **secondary-window lane** — compact residue for whether the finish was supposed to land through `opener`, `parent`, or another strictly named browser lane.
- **message-origin fence** — explicit local check that the sending origin, receiving origin, and lane all match the intended crossing before adoption.
- **origin beats chrome** — a standing anti-regrowth rule: polished popup or iframe UX remains weaker than exact sender/receiver/lane checks.
- **effective-target echo** — future-facing idea from OAuth resource-selection work: the issued result can echo what target actually survived, while still remaining smaller than durable local consequence.
