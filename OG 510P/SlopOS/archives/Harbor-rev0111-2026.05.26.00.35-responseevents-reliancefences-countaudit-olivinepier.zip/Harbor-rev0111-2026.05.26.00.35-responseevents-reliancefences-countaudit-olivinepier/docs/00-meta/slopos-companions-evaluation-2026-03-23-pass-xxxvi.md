# SlopOS / companions evaluation — pass XXXVI

This pass re-checks Harbor against the uploaded cube ecology and keeps the archive embryonic.

## What the current cubes still teach
- **SlopOS** already pins the most important anti-regrowth rule in `mcp-step-up-auth-import-boundary-v0.md`: imported `insufficient_user_authentication`, `acr_values`, `max_age`, `acr`, `auth_time`, and `amr` stay provider-local reauthentication guidance or verifier context rather than becoming portable assurance, recent-login, or account/session truth.
- **SlopOS** also keeps adjacent auth surfaces small: `login-state-export-boundary-v0.md`, `auth-result-export-boundary-v0.md`, and `browser-session-export-boundary-v0.md` all refuse the temptation to turn local auth success into portable account/session authority.
- **Steward** remains a strong sibling reminder that advisory posture and current-state truth are different strengths of fact. That makes it a good check against overreading returned method labels into durable local approval.
- **ViewFS** continues to reward exact basis versus applied local consequence. That is useful here too: an achieved rung or method receipt can inform local adoption without becoming the adoption itself.

## Harbor consequence
Harbor should keep assurance/verification nouns provisional.
The right near-term move is small:
- add one specimen around `assurance ask`, `achieved rung`, `method receipt`, and `unable-here honesty`;
- keep requested assurance, achieved assurance, and method evidence visibly separate from durable account/session/grant truth;
- and let SlopOS or future auth-specific seams own portable assurance registries, enterprise policy engines, or approval-basis catalogs if those ever become necessary.

## Still-not-yet decisions
- Whether `achieved rung` deserves its own first-class card or belongs as one field on a broader result/admission witness.
- Whether `method receipt` should stay generic across OIDC/WebAuthn/passkey families or later split into narrower evidence chips.
- Whether Harbor should ever name device-bound versus synced passkey distinctions directly, or leave that entirely to provider-local and policy-local interpretation.
