# SlopOS / companions evaluation — pass LXXXI

This pass asks how Harbor should evaluate `F076` while SlopOS's datacube is still in design phase. The answer is to make historical answerability explicit without committing SlopOS to a storage substrate or a universal replay engine.

## SlopOS lessons used directly
- **Rollback needs mutable-data gates.** SlopOS RFC-0097 says atomic code rollback does not automatically make mutable data rollback-safe. Harbor applies the same rule to datacube answers: exact replay depends on the retained data cut, schema/contract epoch, policy epoch, sidecars, tombstones, query/compiler definition, and runtime assumptions.

- **Record/replay is scoped evidence.** SlopOS RFC-0013 treats deterministic replay as a bounded nondeterminism boundary rather than a claim to determinize the whole world. Harbor borrows that restraint: a replay-ready cube answer must name its scope and survivor set.

- **Snapshots are explicit, not ambient.** SlopOS D-PERSIST snapshot semantics and config generations reinforce that retained cuts and generations are deliberate artifacts with retention and GC policy outside the core. Harbor keeps frozen cuts as optional evidence, not a constitutional requirement.

- **Replay bundles can be sensitive.** SlopOS replay-bundle and observation-policy posture warns that exact replay evidence can contain secrets, device reads, raw logs, or suppressed fields. Harbor therefore does not turn exact replay into a public entitlement; it names access and redaction pressure as the next seam.

## Companion-cube pressure
- **Foundry:** pinned cuts, serving-lane humility, snapshot-resume hazards, and raw-retention honesty map directly to replay survivability. The borrow is not a new package format; it is the discipline that a fast/served answer and an exact/pinned answer are different artifacts.

- **Steward:** aftermath receipts and reconciliation pressure suggest that old answers need followthrough when later evidence restates them. Steward is the better home for generalized repair work; Harbor only records the membrane-facing answerability verdict.

- **Schell:** activation receipts and denial residue warn that a replay packet must not pretend to be the whole user/application truth. It is a scoped proof cut for one lane, one question, and one consequence.

- **ViewFS:** import/open/materialize surfaces keep helper materialization smaller than original authority. A frozen answer artifact is a materialized witness, not a substitute for underlying row authority.

- **Helm:** review queues, conflict ledgers, and restore/replay vocabulary suggest how operators might see a survivability verdict: exact-replay-ready, frozen-answer-only, explainable-only, or refuse.

- **Ward:** key/history witness discipline warns against treating retained history as automatic trust. A historical answer can be verifiable yet still not locally authorized for the requesting consumer.

- **Foundry + SlopOS together:** pinned cuts plus migration gates are the strongest combination: record what exact old answer requires before cleanup or migration, then force a visible barrier when cleanup breaks that promise.

## Harbor consequence
This pass closes `F076` by adding:

- `docs/00-meta/datacube-replay-survivability.md` — a review surface for historical answer survivor sets and replay modes;
- `docs/30-architecture/specimen-flow-76-replay-survivability-retention-window-exact-answer.md` — a concrete retention-window and exact-answer specimen;
- refreshed proof obligations, lessons, inspiration harvest, source register, bibliography, roadmap, ledgers, manifest, and briefing surfaces.

## What stays open
- Whether exact replay is implemented by table snapshots, event logs, answer packs, object-store snapshots, or a future SlopOS substrate.
- Whether frozen historical answer packets are product-visible, operator-only, auditor-only, or never exposed.
- How much replay evidence can be exported without violating SlopOS observation policy.
- Whether retention windows become consumer contract fields or remain internal promotion proof.
- Whether exact historical answerability is worth the storage cost for every lane.

## Non-decision reaffirmed
No sibling cube is flattened into Harbor. SlopOS remains the likely owner of OS-level data-contract gates, observation policy, and durable substrate choices. Foundry remains better positioned for generalized pinned-cut/package semantics. Steward remains better positioned for aftermath reconciliation. Harbor only records the membrane-facing datacube residue needed to avoid counterfeit historical answers.
