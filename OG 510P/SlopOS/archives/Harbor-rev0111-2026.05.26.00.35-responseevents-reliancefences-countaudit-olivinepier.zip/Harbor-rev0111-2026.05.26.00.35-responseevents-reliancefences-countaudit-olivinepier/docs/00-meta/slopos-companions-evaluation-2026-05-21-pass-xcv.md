# SlopOS and companions evaluation — pass XCV

**Revision:** `rev0095`  
**Date:** 2026-05-21  
**Focus:** executable `CrossingRecord v0` evidence, SlopOS portal-net bridge, route-family non-promises, negative fixtures, and checker-backed scope humility.

## SlopOS pressure

SlopOS now has a deep `portal.net.request` evidence stack: mutation rejection, sequence/recovery/snapshot/crash-prefix evidence, checkpoint/lineage/linearization, append, truncation, resume, recheckpoint, rollback, and append-after-latest-truncation guards. Harbor should not copy that machinery. It should require that any imported SlopOS result arrive as a small crossing record with explicit non-promises.

`rev0095` therefore adds a Harbor-side harness with ten cases. The positive cases borrow SlopOS's route/admission and accepted-prefix lessons. The negative cases reject the Harbor counterfeits that SlopOS's rigor makes easy to spot: ambient truth fields, digest mismatch, refused global resolved banners, and latest-wins scope substitution.

## Companion pressure

- **Helm:** repair/retry/intervention traces push Harbor to make crossing evidence replayable and failure-visible rather than prose-only.
- **Schell:** forgetting/minimization fences push the public-copy aftermath case to refuse all-agent correction and training unlearning claims.
- **ViewFS:** consent/trusted-path surfaces push `visible_to_user` to stay boolean, not comprehension proof.
- **Ward:** delegation and escalation warrants push authority basis to remain per-record and scoped.
- **Foundry:** classification pins and witness crosswalks push subject digest and label binding into the checker.
- **Steward:** replay/pushback budgets push accepted-only append and no-latest-wins posture.

## Harbor delta

`rev0095` adds:

- `docs/40-verification/harbor-crossing-record-evidence-bundle-v0.md`;
- `fixtures/harbor-crossing-record-evidence-bundle-v0.json`;
- `tools/harbor_crossing_record_harness.py`;
- `tools/check_harbor_crossing_record_bundle.py`;
- `docs/00-meta/datacube-executable-crossing-evidence.md`;
- specimen flow 90;
- executable crossing proof obligations in `docs/00-meta/datacube-proof-obligations.md`;
- repo hygiene wiring so `make check` fails if the fixture or current revision wiring drifts.

## Deliberate non-promotion

This pass does not promote a durable crossing schema, SlopOS import profile, MCP authorization model, browser credential trust profile, public-copy status API, transparency-log policy, in-toto predicate, SCITT profile, C2PA verifier, CT/Rekor reliance rule, compliance workflow, reputation model, enforcement ladder, or final SlopOS datacube shape. It only promotes the expectation that future crossing-record proposals should come with deterministic positive and negative fixtures.
