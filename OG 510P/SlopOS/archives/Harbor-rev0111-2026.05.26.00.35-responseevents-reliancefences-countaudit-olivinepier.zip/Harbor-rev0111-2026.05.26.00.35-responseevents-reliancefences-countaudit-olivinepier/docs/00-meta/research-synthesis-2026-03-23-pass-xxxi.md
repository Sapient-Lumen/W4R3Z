# Research synthesis — pass XXXI

This pass keeps Harbor narrow and learns one more thing from browser-mediated identity systems and replay-aware protocols: **the right retry story is exact replay only, not magical resume, mutable reuse, or double spend.**

## Outside lessons
1. **RFC 9126 makes pushed authorization references effectively one-shot.**  
   A client MUST only use a `request_uri` value once because pieces of the request, such as the `code_challenge`, are unique to a particular authorization request. Authorization servers SHOULD treat `request_uri` values as one-time use, MAY allow duplicate requests caused by reload/refresh, and MUST reject expired `request_uri` values as invalid. Harbor should steal the shape: exact replays may be tolerated narrowly, but changed or expired reuse should not masquerade as fresh authority.

2. **RFC 7636 makes code binding per-attempt, not ambient.**  
   PKCE requires a unique `code_verifier` for every authorization request. That is excellent Harbor precedent: crossing material is often bound to one attempt and should not quietly widen into a resumable session or a mutable retry bucket.

3. **RFC 9449 treats replay resistance as first-class truth.**  
   DPoP exists to detect replay attacks. Its `jti` claim must be unique within the relevant validity window, and the specification explicitly recommends server-provided nonces as an effective replay defense. Harbor should therefore preserve replay-aware residue instead of flattening duplicate arrivals into either fresh success or vague failure.

4. **WebAuthn keeps replay prevention and clone detection honest.**  
   WebAuthn requires server-generated random challenges to avoid replay attacks, and it treats the signature counter as a tool to help relying parties detect cloned authenticators. Even then, a counter mismatch can also reflect malfunction or race. That is a beautiful Harbor lesson: duplicate or surprising repeat evidence deserves typed local handling, not folklore.

5. **SlopOS and Steward both reinforce exact-replay discipline.**  
   SlopOS already pins one honest rule in several places: the same scoped request key may replay only the same canonical request, and changed bytes under that key reject before effect. Steward separately argues that duplicate-suppressed is useful truth and that some transient powers should be visibly consumed rather than remaining replayable from stale history. Harbor should borrow that posture without becoming an exactly-once plane.

## Resulting Harbor move
Do not decide yet whether the durable nouns are exactly `replay witness`, `duplicate suppression`, and `consumption honesty`, or whether later pressure compresses some of them behind a smaller attempt/outcome family.
For now, keep them alive as specimen nouns and demand that they improve:
- one PAR/PKCE-style specimen where a refresh-triggered duplicate is visibly smaller than a new crossing;
- one proof-bound or challenge-bound specimen where replay evidence narrows or rejects instead of creating fresh success;
- and one local retry specimen where same-handle changed-context reuse bottoms out honestly instead of acting like mutable upsert or magical resume.

## Fresh ideas worth stealing
- **replay witness** — inspectable residue about whether a later arrival matched an already-known canonical crossing.
- **duplicate suppression** — no-new-effect outcome for an exact replay that is equivalent enough to return prior aftermath honestly.
- **consumption honesty** — clear statement that a code, handle, proof, or crossing chance has already been spent or aged out.
- **exact replay only** — standing anti-regrowth rule: same handle may safely replay the same canonical crossing, but changed meaning under that handle must reject before effect.
- **late duplicates still teach** — a standing reminder that duplicate arrivals are real operational truth even when they should not spend consequence twice.
