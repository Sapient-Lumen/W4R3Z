# SlopOS / companions evaluation — pass LIX

This pass re-checks Harbor against SlopOS and the sibling cubes after adding a schema-source-note / receiver-enriched-detail-card / cache-staleness-detail-warning specimen, and again chooses one narrow crossing seam over any early family bloom.

## What the current cubes still teach
- **SlopOS** remains the strongest restraint mechanism. Its MCP/RAR import boundary keeps imported `authorization_details`, metadata endpoints, granted-detail responses, and inadequate-details signaling provider-local or request-local rather than portable approval or entitlement truth. That lines up directly with Harbor treating schema sources and receiver-enriched detail views as crossing residue only.
- **SlopOS** also reinforces that schema and metadata planes are allowed to stay provider-local. A client may need them to construct or validate a request, but they do not automatically become a platform-wide schema or approval language.
- **Ward** still reinforces visible-veto posture: a request can be in-family and still bottom out because cached metadata or cached schema guidance has gone stale.
- **Helm** still contributes UI humility: a helpful repair surface may explain where the schema came from or what changed, but the explanation remains smaller than durable entitlement or policy truth.
- **Foundry** still teaches aftermath honesty: receiver-enriched details and stale-cache warnings are useful residue without becoming runtime authority.
- **ViewFS** still reminds us that fetched or cached JSON does not become fresh native truth merely because it is materialized locally.

## Harbor consequence
Harbor should keep this move modest:
- add one specimen around **schema-source note**, **receiver-enriched detail card**, and **cache-staleness detail warning**;
- keep discovery metadata, schema fetch/caching, built request shape, and receiver-visible enriched detail shape visibly separate; and
- leave any future schema registry, trusted-authorization-server matrix, or cache-coherence family outside Harbor for now.

## Still-not-yet decisions
- Whether **schema-source note** deserves its own Harbor family, or should remain only an annotation on specific discovery/request surfaces.
- Whether **receiver-enriched detail card** belongs in Harbor at all, or should remain only a receiver-scoped note attached to JWT/introspection specimens.
- Whether **cache-staleness detail warning** belongs in Harbor, or should stay a typed local explanation that never blooms into a portable cache or schema-coherence registry.
