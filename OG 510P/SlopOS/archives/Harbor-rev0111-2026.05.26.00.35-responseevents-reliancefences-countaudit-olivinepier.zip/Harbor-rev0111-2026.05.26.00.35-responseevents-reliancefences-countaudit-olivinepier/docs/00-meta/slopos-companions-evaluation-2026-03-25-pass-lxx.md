# SlopOS / companions evaluation — pass LXX

This pass asks a datacube-discipline question rather than a warehouse question: if Harbor starts publishing design-phase numeric lanes while SlopOS is still in design phase too, how does Harbor stop one visible number from counterfeiting rollup rights it has not actually earned?

## What the companions teach this pass
- **SlopOS** remains the strongest process teacher because it keeps unstable meaning surfaces explicit, grouped, and same-revision maintained. The lesson transfers well here: measure meaning, join discipline, and publication posture should not hide inside ad hoc query text or dashboards.
- **Foundry** keeps teaching residue-class discipline. For Harbor, that is the reminder that an additive count, a ratio, and a distinct/set question are different residue families even when they all render as one scalar.
- **Ward** keeps teaching tier honesty. That transfers here too: a convenience dashboard total may be useful while still being weaker than a reviewed exact rollup policy.
- **Steward** keeps teaching receipts and aftermath. That matters for numeric publication as well: if Harbor changes a rollup policy or replaces a ratio definition, the archive should leave explicit review residue rather than trusting memory.
- **ViewFS** keeps teaching that materialization convenience and identity truth are different facts. Harbor can reuse that instinct: a pre-aggregated or exported number is not automatically entitled to the same semantic promise as the base grain that produced it.

## Harbor consequence
Harbor should make exactly one modest repo/process expansion now:
- add a datacube aggregation-semantics surface;
- add one specimen around aggregation-class cards, fanout fences, rollup notes, and optional sketch sidecars;
- refresh the load-bearing source register with living sources that keep additivity, fanout, ratio discipline, and mergeable approximation ideas visible; and
- keep semantic-front-door pressure alive without pretending this pass picks a final metric engine.

## Still-not-yet decisions
- whether Harbor later needs one shared machine-readable aggregation registry with sibling cubes;
- whether exact-versus-approximate sidecars become first-class published contracts or remain narrower optional residue;
- whether fanout protection later compiles into engine-specific SQL rewrites, model-level metadata, or manual review gates.

For now, the companion lesson is enough: **separate measure class, join safety, and publication convenience before a design-phase number becomes fake authority.**
