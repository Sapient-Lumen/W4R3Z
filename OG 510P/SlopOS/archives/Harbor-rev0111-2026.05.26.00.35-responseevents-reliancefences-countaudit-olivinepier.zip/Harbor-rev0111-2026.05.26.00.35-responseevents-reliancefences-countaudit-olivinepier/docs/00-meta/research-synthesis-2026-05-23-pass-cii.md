# Research synthesis — 2026-05-23 pass CII

## Handoff as a second materialization boundary

F096 stopped at release packaging. F097 moves one step downstream: received zip, extracted tree, copied fixture, pasted digest, renamed archive, file-library upload, portal/callback transfer, and downstream repack are different handoff surfaces. The key split is transport observation versus material identity.

## Borrowed pressures

- BagIt is useful because it treats receipt as a completeness and checksum question over a payload and tag files. Harbor borrows the habit of checking manifest-bound material, while refusing to import BagIt as the release format.
- SPDX package verification code is useful because it names a reproducible content identifier over package files, while excluding the SPDX document itself when embedded. Harbor borrows the distinction between package-content identity and metadata-about-that-identity.
- RO-Crate is useful because it treats a root data entity as the crate-as-a-whole and can describe files or web-addressable resources. Harbor borrows the root-versus-member distinction for extracted trees and copied fixtures.
- OCI image layout is useful because it separates content-addressable blobs from location-addressable references and can move through archive, filesystem, or network transports. Harbor borrows that separation for filename, locator, and digest scope.
- Frictionless Data Package is useful because it describes coherent data collections through a descriptor. Harbor borrows the package-description idea while keeping consumer import smaller than a data-package schema.

## Harbor-specific seam

The same archive may be renamed without changing bytes, and the same apparent name may point to different bytes. The same digest may be pasted without material, or computed over the wrong scope. The same callback may show successful transfer without showing that a consumer verified anything. F097 therefore requires release claim, transport observation, material identity, consumer verification, and scope comparison to remain separate.

## Speculative next seam

F098 should pressure post-import drift. After a consumer imports material, they may annotate it, subset it, re-export it, cache generated summaries, build local indexes, or sync it across devices. Harbor will need local derivation receipts that prevent a verified import from becoming proof that every derived consumer copy stayed current.
