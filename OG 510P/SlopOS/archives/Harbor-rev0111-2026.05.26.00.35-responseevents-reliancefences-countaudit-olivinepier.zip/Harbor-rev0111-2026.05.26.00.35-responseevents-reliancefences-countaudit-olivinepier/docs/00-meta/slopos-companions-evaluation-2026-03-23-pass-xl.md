# SlopOS / companions evaluation — pass XL

This pass re-checks Harbor against the uploaded cube ecology and keeps the archive embryonic.

## What the current cubes still teach
- **SlopOS** remains the clearest brake. `tool-ui-display-surface-boundary-v0.md` says host-owned modals and display-mode changes stay presentation choreography rather than trusted approval/login/file-selection surfaces. `mcp-prompt-import-boundary-v0.md` says imported prompt catalogs and returned prompt messages are proposal material rather than workflow/policy/approval truth. That is almost a direct Harbor lesson: if Harbor names the reviewed display surface at all, it should be a bounded **review card** with explicit **origin cue**, not a second approval substrate.
- **SlopOS** also keeps exact review basis and mutable drift honest through `approval-basis-posture-v0.md`. Harbor should therefore make truncation/shortening smaller than exact basis, not a substitute for it.
- **Steward** remains a good sibling reminder that visible chrome, presence, and surface labels can be useful while still staying smaller than lifecycle authority. That supports Harbor keeping display-bound cues small and inspectable.
- **Helm** is still the right reminder that shell/browser/compositor chrome can communicate provenance and surface boundaries without turning every visible surface into trusted authority.

## Harbor consequence
Harbor should keep these nouns provisional.
The right near-term move is small:
- add one specimen around `review card`, `origin cue`, `bounded field`, and `truncation honesty`;
- keep browser/authenticator-owned review surfaces visibly separate from durable grant/account/session truth;
- and let SlopOS or some later review-specific cube own any portable trusted-display or approval-surface registry if one ever becomes necessary.

## Still-not-yet decisions
- Whether `review card` deserves to be its own first-class card or stays attached to broader mediation/review residue.
- Whether `bounded field` is independently useful, or whether it should remain a property of the review card rather than a new family.
- Whether Harbor should expose typed truncation reasons (`cropped`, `collapsed`, `redacted`, `localized-short`) or keep one generic truncation-honesty posture.
