# Pass CI release-package proof obligations

### PO-RP-001 — Release root and manifest identity proof
The packet states release root, manifest archive name, revision fields, supersession, codename, and current focus.

**Counterfeits blocked:** stale root as current release; manifest name folklore; matching directory name as trust root.

### PO-RP-002 — Archive index and file inventory proof
The packet states actual file count, manifest file count, archive-index count, file-list digest, index digest, generated release surfaces, and embedded-release-zip refusal.

**Counterfeits blocked:** unlisted generated artifact; embedded old release; archive index as attestation.

### PO-RP-003 — Deterministic zip plan proof
The packet states package script digest, zip checker digest, stable timestamp policy, sorted entry order, compression, path prefix, and mode policy.

**Counterfeits blocked:** filesystem mtime as release fact; unsorted entry order; package-script drift hidden by old fixture.

### PO-RP-004 — Build-environment capture proof
The packet states Python implementation/version, platform, zipfile basis, `SOURCE_DATE_EPOCH` observation, and bytecode/write posture.

**Counterfeits blocked:** unknown rebuilder environment as same build; environment capture as portability proof; build clock as hidden input.

### PO-RP-005 — Bootstrap and out-of-band verification proof
The packet states `make check`, `make package-release`, zip integrity check, Harbor zip checker, and the rule that final zip digest is computed after packaging.

**Counterfeits blocked:** source fixture as final archive verifier; digest predicted before archive exists; internal receipt as external review.

### PO-RP-006 — Release-attestation and trust-root refusal proof
The packet states which stronger claims are not made: release attestation profile, package trust root, reproducible-build claim, CI status API, archive signature, artifact security, or final SlopOS datacube shape.

**Counterfeits blocked:** attestation as security; deterministic local package as reproducible build; zip passes as compliance badge.

## Pass CI release-package exercise
Specimen flow 96 exercises `PO-RP-001` through `PO-RP-006` across current release surfaces, deterministic zip plans, build-environment capture, out-of-band verification receipts, archive-index drift, embedded release zips, nondeterministic ZIP metadata, stale roots, unlisted generated artifacts, bootstrap self-trust, and attestation-as-security overclaim. The proof result is deliberately insufficient for release-attestation, trust-root, reproducible-build, CI-status, archive-signature, or final SlopOS datacube promotion.

# Pass C checker-provenance proof obligations

### PO-CP-001 — Checker source and invocation proof
The packet states checker id, source path, source digest, invocation command, role, and the observation boundary.

**Counterfeits blocked:** checker pass as ambient CI status; source digest as trust root; invocation folklore as evidence.

### PO-CP-002 — Fixture/checker pairing proof
The packet states fixture path, file digest, bundle digest, schema, version, observed revision, expected revision, and whether the pair is current for this checker.

**Counterfeits blocked:** stale fixture checked by a new checker; prior digest reused as current; schema match as epoch match.

### PO-CP-003 — Guard-state proof
The packet states required guard families, observed enabled/disabled state, guard-state digest, and refusal outcome when a required guard is off.

**Counterfeits blocked:** disabled refusal rail hidden behind a green result; guard list assumed from source comments; partial checker run as full checker run.

### PO-CP-004 — Self-test receipt proof
The packet states self-test command, exit code, stdout/stderr digest, pass-string observation, and the non-promise that self-test does not certify checker correctness.

**Counterfeits blocked:** checker observation with no run receipt; self-test as semantic truth; stdout pasted without invocation.

### PO-CP-005 — Reviewer override proof
The packet states reviewer basis, scope, expiry, human-review bit, machine-result-unchanged bit, failure-not-marked-success bit, and followthrough-if-repeated bit.

**Counterfeits blocked:** reviewer override as bypass; global waiver; failure recast as success; unexpiring human exception.

### PO-CP-006 — Bootstrap and non-promotion proof
The packet states which checker stack is covered, which checker is deliberately excluded from recursive self-attestation, and which stronger surfaces remain unpromoted.

**Counterfeits blocked:** recursive fixed-point confidence; checker registry promotion; CI status API; trust-root schema; automated reliance workflow.

## Pass C checker-provenance exercise
Specimen flow 95 exercises `PO-CP-001` through `PO-CP-006` across current checker observations, disabled guard evidence, stale fixture/checker pairing, missing self-test receipts, scoped reviewer override packets, and unscoped override attempts. The proof result is deliberately insufficient for checker-registry, CI-status, trust-root, certification, automated-reliance, or final SlopOS datacube promotion.

# Pass XCIX mutation triage proof obligations

### PO-MT-001 — Unsafe-survivor triage proof
The packet states the operator, baseline digest, mutant digest, prior or legacy survivor observation, current checker result, unsafe semantic delta, and whether a guard was added or the gap remains open.

**Counterfeits blocked:** survived mutation ignored as noise; unsafe authority phrase hidden in accepted string values; checker hardening with no reproducible case.

### PO-MT-002 — Equivalent-survivor proof
The packet states why the mutant survived, why it is equivalent for this fixture, which semantic guard remains elsewhere, and what repeated pressure would be needed to reopen it.

**Counterfeits blocked:** every survivor as emergency; every survivor as harmless; cosmetic mutation promoted as hostile fixture bloat.

### PO-MT-003 — Overstrict false-positive proof
The packet states why the checker killed the candidate, what semantic model would treat it as harmless, and why Harbor keeps or relaxes the strictness.

**Counterfeits blocked:** killed mutation as domain truth; relaxing canonicality without repeated evidence; fixture determinism confused with external semantics.

### PO-MT-004 — Fixture-promotion packet proof
The packet states whether the generated candidate is promoted to a triage fixture, a hand-authored hostile fixture, a checker guard, or a parked equivalent case, plus human-review and non-promotion bits.

**Counterfeits blocked:** automatic generated-fixture promotion; checker changes with no review record; hostile fixture added only to improve a score.

### PO-MT-005 — Corpus-pruning proof
The packet states whether a candidate is retained, pruned, parked, merged, or left as generated-only pressure, and why counting it would or would not add evidence.

**Counterfeits blocked:** corpus bloat as rigor; duplicate mutants as progress; pruning as silent loss of pressure.

### PO-MT-006 — Score/dashboard refusal proof
The packet states mutation count, killed count, survived count, and unsafe-open count only as diagnostics, with explicit refusal of score, dashboard, certification, conformance, or final-schema meaning.

**Counterfeits blocked:** mutation score as correctness; killed count as compliance; survived count as public failure badge.

## Pass XCIX mutation-triage exercise
Specimen flow 94 exercises `PO-MT-001` through `PO-MT-006` across unsafe survivor hardening, equivalent survivor classification, overstrict canonicality, and corpus-pruning decisions. The proof result is deliberately insufficient for dashboard or conformance-suite promotion: the triage bundle records how Harbor interprets checker outcomes only.

# Pass XCVIII property/mutation coverage proof obligations

### PO-PM-001 — Baseline digest proof
The packet states which executable bundles were used as baselines, their emitted digests, case counts, accepted counts, rejected counts, and original owning harness/checker.

**Counterfeits blocked:** generated mutants floating free of a known baseline; a coverage report silently testing stale or edited fixtures.

### PO-PM-002 — Mutation-operator proof
The packet states the operator id, target bundle, invariant list, minimal mutated target, baseline digest, mutant digest, and expected killed/survived outcome.

**Counterfeits blocked:** unexplainable random failures; generated cases with no human-readable counterfeit; a mutation operator pretending to be a schema field.

### PO-PM-003 — Checker-result proof
The packet states which checker evaluated the mutant, whether it was killed or survived, and the checker reason or exception class that made the result reproducible.

**Counterfeits blocked:** hidden survived mutants; green coverage with no diagnostic reason; checker pass/fail folklore.

### PO-PM-004 — Shrink and fixture-promotion proof
The packet states the minimal reproduction target, why the case is human-readable, whether it should remain generated, and what extra packet would be needed before promoting it to a hand-authored hostile fixture.

**Counterfeits blocked:** giant generated JSON blobs as design evidence; automatic fixture promotion; corpus bloat masquerading as rigor.

### PO-PM-005 — Coverage-claim humility proof
The packet states mutation count, killed count, survived count, bundle/operator/invariant coverage, and the exact coverage claim, including what the claim does not prove.

**Counterfeits blocked:** mutation score as correctness; branch/path/fuzz coverage overclaim; conformance-suite promotion.

### PO-PM-006 — Equivalent/out-of-scope mutant proof
If a generated mutant survives, the packet states whether it is a true checker gap, intentionally equivalent, out-of-scope, or blocked by a sibling-cube boundary, and records the followthrough item.

**Counterfeits blocked:** every survived mutant as emergency; every survived mutant ignored; generated pressure bypassing human triage.

## Pass XCVIII property/mutation exercise
Specimen flow 93 exercises `PO-PM-001` through `PO-PM-006` across 38 deterministic mutations over the CrossingRecord, transparency/provenance receipt-import, and verifier-disagreement bundles. The proof result is deliberately insufficient for schema or conformance-suite promotion: the meta-bundle records targeted checker sensitivity only.

# Datacube proof obligations

## Additional verifier-disagreement and policy-epoch drift proof obligations

These obligations come from specimen flow 92. They are intentionally smaller than a verifier arbitration schema, policy-drift ledger, public badge model, reliance API, compliance workflow, legal status resolver, issuer-reputation model, trust-root policy, or final SlopOS datacube shape.

### PO-VD-001 — Verifier run identity and policy digest proof

Before Harbor compares verifier results, each verifier run must name verifier identity, decision, policy id, policy digest, policy epoch, input digest, currentness basis, scope, reason, and the no-semantic-truth bit. A run missing policy digest cannot support epoch comparison.

### PO-VD-002 — Disagreement preservation proof

Before Harbor emits public status from multiple verifier results, it must preserve the full decision set, verifier count, comparable/incomparable basis, refusal reason, and majority/latest-wins refusal. Accept/refuse/inconclusive/currentness-unknown splits must not collapse into one truth value.

### PO-VD-003 — Policy-epoch drift proof

Before Harbor applies a newer policy result to a public copy or prior receipt, it must name the old and new policy epochs, policy digests, public-copy time, relation, recheck requirement, and retroactive-erasure refusal. New policy may require recheck; it must not memory-hole the old basis.

### PO-VD-004 — Currentness uncertainty proof

Before Harbor uses a verifier result as current, it must say whether currentness is checkpoint-only, timestamp-only, unknown, recheck-required, selected-claim-only, scope-bound, or policy-epoch-bound. Unknown currentness must not become fresh-now.

### PO-VD-005 — Badge refusal and scope proof

Before Harbor emits any badge-like public posture, it must choose only a bounded posture: badge withheld, split status, scoped pass with disclosure, recheck required, prior epoch retained with notice, incomparable review, or no public badge. Green/trusted/resolved/compliant/global/all-clear/fresh-now posture is refused in this seam.

### PO-VD-006 — Issuer status and timestamp recheck proof

Before Harbor changes reliance after an issuer/key/compromise status update, it must compare timestamp evidence, affected key set, compromise window, verifier epoch, and subject digest. Issuer compromise creates recheck pressure, not automatic truth, automatic falsity, or global revocation.

### PO-VD-007 — Incomparable-basis proof

Before Harbor chooses between sealed selected-claim review and public full-evidence review, or between local and global scope policies, it must record why the bases are incomparable or only partially comparable. Incomparable is a valid outcome, not a request for forced arbitration.

## Pass XCVII verifier-disagreement exercise

Specimen flow 92 exercises accept/refuse splits, currentness unknowns, policy changes after public copy, issuer status after timestamp, sealed/public incomparable bases, local/global scope splits, badge collapse, retroactive erasure, stale-policy currentness, refusal overgeneralization, issuer-status collapse, majority-vote collapse, and missing policy digest rejection. The proof result is deliberately insufficient to promote schema. It is sufficient to close `F092` as a reversible pressure test.


## Additional transparency/provenance receipt-import proof obligations

These obligations come from specimen flow 91. They are intentionally smaller than a receipt-import schema, transparency-log reliance policy, C2PA verifier profile, in-toto/SLSA predicate profile, SCITT profile, timestamp authority policy, redaction proof system, issuer-reputation model, legal status workflow, public status API, or final SlopOS datacube shape.

### PO-TP-001 — Receipt-family non-promise proof

Before Harbor imports a transparency or provenance receipt, it must name the receipt family and attach the family-specific non-promises: inclusion is not statement truth, C2PA manifest binding is not real-world authenticity, in-toto/SLSA provenance is not dependency cleanliness, log inclusion is not semantic approval, timestamping is not event time, redaction is not full evidence, issuer compromise is not automatic falsity/truth, and verifier policy pass is not future authority.

### PO-TP-002 — Subject/material/manifest binding proof

Before Harbor admits a receipt-import record, it must bind the receipt evidence to the subject digest or explicitly downgrade to selected/redacted claim binding. Subject digest mismatch, materials mismatch, manifest-binding loss, or scope substitution must reject the candidate before an import id is emitted.

### PO-TP-003 — Currentness/checkpoint/timestamp proof

Before Harbor says a receipt is current for any purpose, it must state whether currentness is not established, fresh only for a named checkpoint, timestamp-only, recheck-required because of revocation/compromise, or bound to one policy epoch. A timestamp token cannot become event time; log inclusion cannot become fresh-now by default.

### PO-TP-004 — Verifier-policy epoch proof

Before Harbor carries a verifier result, it must name policy id, policy digest, policy epoch, input/decision trace digest, checked receipt families, and the no-semantic-truth bit. A verifier pass may support a scoped workflow decision but not content truth, future policy pass, legal closure, or global authority.

### PO-TP-005 — Redacted/derived proof boundary proof

Before Harbor accepts a redacted or derived proof bundle, it must name selected claims, base-proof linkage, redaction scope, hidden-material limits, recursive disclosure refusals, and whether the binding is sufficient only for selected claims.

### PO-TP-006 — Issuer-compromise recheck proof

Before Harbor continues relying on receipts from a potentially compromised issuer, it must name compromise window, affected key set, affected receipt families, recheck status, downgraded claims, and why the advisory is neither automatic deletion nor automatic trust.

## Pass XCVI transparency/provenance receipt-import exercise

Specimen flow 91 exercises a deterministic receipt-import bundle across SCITT-like inclusion, C2PA/content credentials, in-toto/SLSA provenance, Rekor/CT-style inclusion/currentness, timestamp anchors, redacted derived proofs, issuer-compromise notices, local verifier policy decisions, digest mismatch, inclusion-as-trust, inclusion-as-fresh-now, hidden compromise, redaction-as-full-evidence, and latest-wins scope widening. The proof result is deliberately insufficient to promote a durable receipt-import schema. It is sufficient to close `F091` as an executable pressure test.


## Additional executable crossing-evidence proof obligations

These obligations come from specimen flow 90. They are intentionally smaller than a crossing-record schema, SlopOS import contract, MCP trust profile, browser credential profile, public status API, transparency profile, compliance workflow, or final SlopOS datacube shape.

### PO-XE-001 — Executable bundle proof

Before Harbor treats `CrossingRecord v0` as more than prose, it must have a deterministic bundle with stable case ids, exact member labels, positive and negative cases, digest-bound verdict summaries, and a checker that can fail on drift.

### PO-XE-002 — Route-family non-promise proof

Before Harbor admits a crossing record, it must attach route-family non-promises. Portal/network evidence must refuse transport trust, content truth, current lease, and user comprehension. Durability evidence must refuse discarded-suffix preservation, denied/duplicate durable state, and outside-truth continuity. Callback, MCP/tool, browser credential, and public-copy aftermath routes must each carry their own refusal set.

### PO-XE-003 — Subject digest and hostile-envelope proof

Before Harbor accepts an outside crossing candidate, it must bind subject digest to the external evidence, reject ambient authority/truth fields, reject forbidden outcome classes such as `resolved`, `compliant`, `trusted`, and `global_truth`, and ensure rejected candidates emit no crossing id.

### PO-XE-004 — Callback/tool/credential humility proof

Before Harbor admits callback, MCP/tool, or browser credential residue, it must name why the event is smaller than same authority, tool annotation truth, consent proof, user comprehension, holder authority, global identity, or global authorization.

### PO-XE-005 — Accepted-prefix aftermath proof

Before Harbor imports SlopOS-style checkpoint/resume/truncation/append evidence, it must name exact accepted-prefix scope, discarded suffix rejection, denied/duplicate non-commit exclusion, cursor/update effect, and why the record does not preserve outside truth.

## Pass XCV executable-crossing exercise

Specimen flow 90 exercises a deterministic CrossingRecord evidence bundle across SlopOS portal-net route/admission, checkpoint/resume/truncation/append accepted-prefix import, malformed-envelope rejection, digest mismatch rejection, callback continuation, MCP/tool metadata, browser credential presentation, public-copy warning aftermath, status-banner overclaim, and latest-wins scope substitution. The proof result is deliberately insufficient to promote schema. It is sufficient to close `F090` as an executable pressure test.

## Additional implementation-exception and crossing-record proof obligations

These obligations come from specimen flow 89. They are intentionally smaller than a crossing-record schema, scope engine, public status-state runtime, deadline tracker, recheck service, rollback protocol, warning API, compliance workflow, agent-memory subsystem, SlopOS integration contract, or final SlopOS datacube shape.

### PO-XR-001 — Crossing-record scope proof

Before Harbor treats any crossing as proof-grade residue, it must name subject kind/ref/digest/basis time, route membranes/family, admission decision/authority/user-visible posture, artifact/audience/jurisdiction/surface/window scope, outcome class, receipts, recheck window, rollback/reopen triggers, and non-promises.

### PO-XR-002 — Hostile receipt rejection proof

Before Harbor accepts a receipt into a crossing or public-copy aftermath packet, it must reject or downgrade wrong digest, wrong subject, wrong audience, copied receipt, backdated receipt, authorityless receipt, hidden excluded-surface receipt, label-stripped export, prompt-injected notice, and tool annotation overclaim cases.

### PO-IX-001 — Clock/deadline proof

Before Harbor says a deadline was met, missed, stayed, extended, or late, it must name deadline source, deadline time, rendered local time if relevant, publication time, observation time, clock source, known skew/uncertainty, stay/extension posture, and unsupported compliance conclusions.

### PO-IX-002 — Failed-recheck proof

Before Harbor says a recheck failed or stayed clean, it must name prior clean basis, recheck window, target surfaces, observation method, clean/stale/inconclusive surfaces, failed fields, digest/label comparison, and why the result is not global repair or global regression.

### PO-IX-003 — Contradictory-evidence proof

Before Harbor compares implementation evidence packets, it must normalize subject, artifact/cut, digest, audience, jurisdiction, surface, time window, evidence lane, issuer authority, and comparable fields; it must preserve `incomparable` and `overlaps-but-not-same-scope` results without latest-wins selection.

### PO-IX-004 — Rollback/reopen proof

Before Harbor rolls back wording, reopens an appeal, stays a recommendation, or changes audience-specific copy, it must name trigger evidence, challenged effect, stay posture, affected copies, historical retention, memory-hole refusal, sealed-evidence limits, public-copy impact, and next review boundary.

### PO-IX-005 — Stale recurrence after clean-window proof

Before Harbor treats a stale observation as recurrence, it must name prior clean observation, recurrence observation, stale text or label digest, expected current digest, affected surface, suspected path if known, agent/cache/mirror invalidation status, and non-promises about bad faith or global recurrence.

### PO-IX-006 — Warning lifecycle proof

Before Harbor re-escalates, narrows, holds, or sunsets a public warning, it must name warning id/text digest, subject artifact/cut/digest, audience/jurisdiction/surface scope, evidence lane, last clean/stale observations, unobserved surfaces, recurrence or clean-window basis, safe public wording, historical retention posture, and unsupported closure/compliance claims.

## Pass XCIV implementation-exception exercise

Specimen flow 89 exercises missed deadlines, failed rechecks, contradictory implementation evidence, rollback/reopen triggers, stale recurrence after clean windows, warning lifecycle receipts, CrossingRecord v0 scope proof, and hostile receipt rejection. The proof result is deliberately insufficient to promote schema. It is sufficient to close `F089` as a reversible pressure test.

## Additional correction-implementation monitoring proof obligations

These obligations come from specimen flow 88. They are intentionally smaller than a correction implementation ledger, deadline tracker, compliance automation, regulator workflow, post-decision monitoring service, status-page product, rollback protocol, jurisdiction policy engine, VEX/CSAF profile, in-toto predicate, SCITT dependency, or final SlopOS datacube shape.

### PO-CI-001 — Adopted correction work-item proof

Before Harbor treats an adopted outside finding as an implementation obligation, it must name finding return, local adoption note, affected artifact/copy/cut, payload digest, label digest, required public effect, refused effects, owner class, evidence needed, and non-promises.

### PO-CI-002 — Mandate/recommendation/deadline proof

Before Harbor treats a correction instruction as time-bound or binding, it must classify mandate, recommendation, advisory, source-owner proposal, clarification request, or non-binding preference; name issuer, authority basis, deadline/window, jurisdiction/audience, appeal/stay posture, and unsupported compliance conclusions.

### PO-CI-003 — Implementation evidence proof

Before Harbor marks a correction implemented, it must record action, actor role, subject artifacts, old/new digests, changed/unchanged fields, source cut, public cut, label digest, tests/assertions, reviewer, timestamp, materials/byproducts, and unsupported propagation/compliance claims.

### PO-CI-004 — Public-copy publication proof

Before Harbor publishes a corrected public copy, it must record predecessor, successor, relation, changed rows/labels/summaries/citations/status banners, unchanged evidence, localization/accessibility variants, stale-copy warnings, and propagation obligations.

### PO-CI-005 — Partial implementation and stale-surface proof

Before Harbor says an implementation is complete, partial, stale, failed, unreachable, or unknown, it must enumerate canonical bundles, catalogs, mirrors, snippets, cached explainers, localized/accessibility variants, and public guidance with observation basis and non-promises.

### PO-CI-006 — Recheck and monitoring proof

Before Harbor relies on a post-decision recheck, it must name window, target surfaces, method, sample/coverage, clean findings, stale findings, inconclusive findings, recheck horizon, recurrence/rollback triggers, and why the result is not universal recall or compliance.

### PO-CI-007 — Reopen/rollback/audience-split proof

Before Harbor reopens an appeal, rolls back wording, splits audiences, or changes jurisdiction-specific public copy after implementation evidence, it must name trigger evidence, challenged effect, stay posture, affected copies, historical retention, sealed-evidence limits, recomposition warnings, and next review boundary.

## Pass XCIII correction-implementation exercise

Specimen flow 88 exercises adopted correction work items, mandate/recommendation/deadline notes, implementation evidence receipts, publication receipts, partial implementation and stale-surface notes, recheck windows, reopened appeals, rollback triggers, and jurisdiction/audience splits. The proof result is deliberately insufficient to promote schema. It is sufficient to close `F088` as a reversible pressure test.

## Additional external decision-return proof obligations

These obligations come from specimen flow 87. They are intentionally smaller than an external decision ingestion schema, finding-adoption API, authority hierarchy, legal/compliance workflow, appeal court, correction tracker, sealed finding protocol, public status-page product, transparency-log policy, or final SlopOS datacube shape.

### PO-DR-001 — Finding return proof

Before Harbor treats an outside response as useful, it must name issuer, role, authority basis, handoff/escalation id, subject artifact, cut, payload digest, label digest, affected public copy, challenged status/decision, response class, evidence lane, and expiry/recheck posture.

### PO-DR-002 — Scope normalization proof

Before Harbor declares findings conflicting, it must normalize subject, window, audience, method, evidence lane, authority basis, and comparable fields. Harbor must be able to say `not comparable` or `partially comparable` without choosing a winner.

### PO-DR-003 — Local adoption proof

Before Harbor lets an outside finding change public copy, consumer guidance, warning state, cooldown, or correction task status, it must record a separate adoption note naming adopted effects, refused effects, proof obligations passed/failed, sealed evidence boundaries, expiry, and reversal triggers.

### PO-DR-004 — Correction instruction proof

Before Harbor treats an outside instruction as binding, it must distinguish mandate, recommendation, advisory note, source-owner proposal, request for clarification, or non-binding preference; name deadline, scope, appeal posture, and evidence needed; and refuse compliance claims unless explicitly supported.

### PO-DR-005 — Sealed finding proof

Before Harbor uses sealed-only findings in public wording, it must record sealed manifest id, allowed operations, public-safe conclusion, handling label, expiry, renewal basis, withheld basis, and exact public statements allowed. Public copy must not imply raw evidence is public.

### PO-DR-006 — Appeal outcome proof

Before Harbor applies an appeal outcome, it must name challenged decision, outcome, remedy, stay posture, public-copy effects, unchanged historical evidence, onward appeal window if any, and memory-hole refusals.

### PO-DR-007 — Post-review public-copy proof

Before Harbor publishes a post-review public copy, it must name old copy, successor copy, relation, source cut, finding/adoption basis, changed labels/summaries/citations, unchanged evidence, stale-copy warnings, and propagation needs.

## Pass XCII external decision-return exercise

Specimen flow 87 exercises source-owner partial acceptance, auditor/source-owner conflict, regulator-facing sealed-only determination, local adoption notes, correction instructions, appeal outcomes, public-copy updates, and sealed-finding expiry. The proof result is deliberately insufficient to promote schema. It is sufficient to close `F087` as a reversible pressure test.

## Additional recurrence/escalation proof obligations

These obligations come from specimen flow 85. They are intentionally smaller than a recurrence ledger, reliability score, reporter ranking, escalation workflow, regulator/auditor program, status-page product, transparency-log policy, enforcement ladder, or final SlopOS datacube shape.

### PO-RE-001 — Recurrence subject proof

Before Harbor treats an issue as recurring, it must name source correction anchor, public artifact/copy or claim family, target class, actor/reporter class, payload digest, label digest, audience, first/latest observation, recurrence window, clean/missed windows, and evidence lane.

### PO-RE-002 — Regression proof

Before Harbor says a repaired target regressed, it must preserve the prior remediation claim, prior verification basis, current observation, old/new digest or label comparison, target authority, suspected path if known, and unsupported conclusions.

### PO-RE-003 — Serial acknowledgement and unverifiable-claim proof

Before Harbor escalates acknowledgement or non-use/remediation claim weakness, it must record notice ids, acknowledgement ids, expiry/recheck horizons, claimant authority, reviewed evidence, repeated missing evidence, and the exact claim family being limited. Expiry and unverifiability must not become proof of use, non-use, refusal, repair, harm, or negligence.

### PO-RE-004 — Reporter claim outcome proof

Before Harbor summarizes an external reporter's reliability for this seam, it must map each claim to subject, version/cut, label digest, evidence basis, confirmed fields, rejected fields, unresolved fields, and safe public response. It must not produce actor-wide or reporter-wide scores.

### PO-RE-005 — Escalation/cooldown/sunset proof

Before Harbor escalates, cools down, or sunsets a public warning or standing challenge, it must name recurrence evidence, target/audience, consumer risk, last clean observations, escalation target if any, cooldown criteria, sunset criteria, historical retention posture, and public-safe wording.

### PO-RE-006 — Public-log/status divergence proof

Before Harbor relies on a public log, signed statement, status banner, catalog card, or status page after a recurrence, it must compare signed/logged claim subject, current proof packet status, status surface digest if available, observed time, divergence type, repair attempt, and audience. Publication evidence must not become current-truth evidence.

## Pass XCI external-escalation handoff exercise

Specimen flow 86 exercises standing challenge handoff, source-owner packet, auditor packet, external escalation, appeal window, sealed regulator-facing evidence, post-handoff public-log/status divergence, and disputed sunset appeal. The proof result is deliberately insufficient to promote schema. It is sufficient to close `F086` as a reversible pressure test.

## Additional external-escalation handoff proof obligations

These obligations come from specimen flow 86. They are intentionally smaller than an external escalation workflow, source-owner ticketing system, appeal court, regulator/auditor packet format, sealed-evidence protocol, public status-page product, transparency-log policy, legal/compliance workflow, incident-response program, CVD/PSIRT/CSIRT operating model, VEX/CSAF profile, in-toto predicate, SCITT dependency, or final SlopOS datacube shape.

### PO-SE-001 — Handoff subject proof

Before Harbor sends or records an external handoff, it must name challenge id, challenged decision or claim family, source correction anchor, target artifact/copy/version/cut, payload digest, label digest, current status, evidence lane, recipient class, requested action, response window, and non-promises.

### PO-SE-002 — Recipient authority proof

Before Harbor treats an external response as useful, it must record recipient identity or role, authority basis, scope, contact/submission route, handling constraints, subject set, and whether the recipient can speak for source ownership, downstream copy operation, audit result, regulator-facing review, coordination, or only receipt.

### PO-SE-003 — Appeal window proof

Before Harbor gives an appeal status effect, it must record challenged decision, challenger standing, grounds, remedy sought, deadline, completeness, allowed evidence, stay posture, public-safe interim status, result, and whether any extension or resubmission window exists.

### PO-SE-004 — Sealed evidence proof

Before Harbor transfers or cites sealed evidence, it must record sealed packet id, artifact/proof digests, redaction map digest, handling label, recipient class, reveal conditions, allowed verifier operations, retention/expiry, revocation, and public-summary limits.

### PO-SE-005 — External response scope proof

Before Harbor displays an external response, it must classify the result as no response, receipt only, accepted-for-review, asks for more evidence, cannot assess, partial finding, sealed finding, public finding, out-of-scope, declined, withdrawn, or superseded; it must not display acknowledgement as agreement, repair, non-use, harm, compliance, or proof.

### PO-SE-006 — Post-handoff divergence proof

Before Harbor reconciles a public log, status page, public warning, appeal note, source-owner reply, auditor note, or regulator-facing packet, it must compare subject, cut, window, audience, proof-packet state, current public wording, logged claim, status claim, and next recheck; neither surface wins by default.

### PO-SE-007 — Safe public escalation copy proof

Before Harbor publishes escalation or appeal copy, it must check that the text includes current user guidance, status uncertainty, appeal/stay posture, sealed-evidence limits, non-promises, localization/accessibility label preservation, and no suppressed values, raw replay data, private logs, private reporter/source details, or unapproved verifier conclusions.

## Pass XC recurrence/escalation exercise

Specimen flow 85 exercises stale-copy regression, serial acknowledgement expiry, repeated unverifiable non-use claims, mixed-accuracy reporter claims, escalation/cooldown/sunset, and public-log/status divergence. The proof result is deliberately insufficient to promote schema. It is sufficient to close `F085` as a reversible pressure test.

## Additional status-reconciliation proof obligations

These obligations come from specimen flow 84. They are intentionally smaller than a status page product, claims tribunal, customer-notification workflow, VEX/CSAF profile, in-toto predicate, transparency-log policy, reputation system, public dispute UI, or final SlopOS datacube shape.

### PO-SR-001 — Claim scope proof

Before Harbor compares remediation, use, impact, or status claims, it must name claim id, claimant, authority basis, source artifact, correction anchor, stale/downstream subject, version or cut, payload digest, label digest, audience, time window, and evidence lane.

### PO-SR-002 — Challenge proof

Before Harbor treats a claim as disputed, it must record challenged field, challenger class, challenge evidence, evidence requested, evidence received, sealed/auditor-only posture, response deadline or recheck horizon, and safe interim public status.

### PO-SR-003 — Acknowledgement expiry proof

Before Harbor uses an acknowledgement for current status, it must verify notice id, actor authority, acknowledged subject set, timestamp, recheck horizon, renewal/replacement status, and whether the acknowledgement is historical-only, expired, challenged, refused, unreachable, or still current.

### PO-SR-004 — Contradiction map proof

Before Harbor calls two claims contradictory or compatible, it must compare subject, version/cut, label digest, audience, time window, method, actor authority, evidence basis, residual risk, and public/private evidence boundary. Scope mismatch must not be reported as contradiction.

### PO-SR-005 — Unverifiable attestation proof

Before Harbor accepts a use/non-use/remediation attestation, it must name reviewed logs, manifests, cards, dependency locks, retrieval-index versions, model/eval paths, retention limits, manual-review scope, and missing evidence. An unverifiable statement may be recorded as cooperation, not proof.

### PO-SR-006 — Public-status synchronization proof

Before Harbor displays `resolved`, `fixed`, `repaired`, or equivalent public copy, it must check the proof packet state, correction anchor, successor link, payload/label/status digest, non-promises, localization/accessibility labels, observed public surface, mirrors/caches/snippets if in scope, and next recheck.

## Pass LXXXIX status-reconciliation exercise

Specimen flow 84 exercises a remediation challenge, expired acknowledgement, contradictory external report, unverifiable non-use attestation, and public status drift. The proof result is deliberately insufficient to promote schema. It is sufficient to close `F084` as a reversible pressure test.

## Additional stale-downstream impact proof obligations

These obligations come from specimen flow 83. They are intentionally smaller than an incident manager, public status API, customer-notification platform, VEX/CSAF profile, in-toto predicate, audit program, model unlearning process, eval governance program, or final SlopOS datacube shape.

### PO-SI-001 — Stale-use subject proof

Before Harbor treats a stale downstream use as evidence, it must name the source artifact, correction anchor, stale copy, downstream subject, payload digest, label digest, propagation/stale-copy witness, evidence lane, and exact use class.

### PO-SI-002 — Exposure/use/reliance/impact separation proof

Before Harbor publishes severity or impact, it must separately record exposure, use, reliance, numeric drift, label/interpretation drift, affected audience, materiality lane, unknowns, and sensitive evidence boundaries.

### PO-SI-003 — Acknowledgement proof

Before Harbor counts a consumer acknowledgement, it must record notice id, actor, authority, timestamp, method, acknowledged subject set, unacknowledged target set, and whether the acknowledgement is receipt-only, review-started, repair-planned, no-use-claimed, refused, or disputed.

### PO-SI-004 — Remediation attestation proof

Before Harbor treats a remediation claim as repaired, it must name the subject, action, actor, basis, observed evidence, result status, residual risk, expiry/recheck posture, and unsupported claims such as model unlearning, corpus deletion, user notification, prior-decision repair, or eval-result retraction.

### PO-SI-005 — Use-attestation scope proof

Before Harbor accepts a use or non-use statement, it must name attester authority, subject artifact, use window, use context, method of determination, logs/manifests/cards reviewed, limitations, expiry, and whether the statement is used, not-used, unknown, likely-used, no-longer-used, or historical-only.

### PO-SI-006 — Safe public impact proof

Before Harbor publishes an impact statement, it must check that the copy names current source and affected use class, avoids suppressed/raw/sealed evidence, carries non-promises, distinguishes acknowledgement from repair, and gives safe next action without claiming universal recall.

## Pass LXXXVIII stale-impact exercise

Specimen flow 83 exercises a stale report, acknowledgement-only consumer response, partial remediation attestation, stale eval/model copy, scoped non-use attestation, failed generated-explanation repair, interpretation-only impact, disputed reliance, and historical-only archive posture. The proof result is deliberately insufficient to promote schema. It is sufficient to close `F083` as a reversible pressure test.

## Additional correction-propagation proof obligations

These obligations come from specimen flow 82. They are intentionally smaller than a propagation ledger, CDN/search integration, crawler policy, catalog sync API, agent invalidation bus, vector-index contract, training-data governance program, or final SlopOS datacube shape.

### PO-CP-001 — Source-to-target basis proof

Before Harbor treats a propagation result as meaningful, it must name the source correction anchor, source artifact, source cut, payload digest, label digest, successor relation, downstream target id/class, and exact target authority: update, notify-only, observe-only, no-authority, or unknown.

### PO-CP-002 — Target-currentness proof

Before Harbor calls a target current, it must separately check payload digest, label digest, status/correction banner, human description, downloadable artifact, cached variant, snippet/preview, and metadata relation where applicable. Mixed-current targets must be marked mixed, not current.

### PO-CP-003 — Cache and crawler signal proof

Before Harbor relies on purge, revalidation, sitemap, URL-change, robots/meta, recrawl, or outdated-content actions, it must record the emitted signal, target scope, old/new validators, TTL/freshness basis, observed response if any, and whether the record is attempt-only or observed-success.

### PO-CP-004 — Derived-explanation invalidation proof

Before Harbor allows a generated explanation, agent answer, or retrieval-index chunk to remain usable after a correction, it must prove source cut, label digest, correction anchors included, omitted-label list, index/cache version, regeneration basis, and review status. Otherwise it must be stale-bannered, quarantined, or refused.

### PO-CP-005 — Training/evaluation stale-copy proof

Before Harbor claims a downstream dataset, model, benchmark, eval suite, crawl corpus, or dataset/model card is repaired, it must state what stale material was absorbed, what correction notice or successor relation was emitted, what downstream status is observed, and which claims remain unsupported: model unlearning, corpus deletion, eval-result retraction, or behavior change.

### PO-CP-006 — Propagation horizon proof

Before Harbor says propagation is complete, it must name the target set, unknowns, out-of-scope copies, unreachable mirrors, refused updates, retry horizon, and safe consumer wording. Without a named target set, "complete" is counterfeit.

## Pass LXXXVII correction-propagation exercise

Specimen flow 82 exercises catalog/mirror sync, cache invalidation, stale search snippets, crawler signals, agent-explanation invalidation, retrieval-index refresh, stale training/evaluation copy notices, and unreachable external mirrors. The proof result is deliberately insufficient to promote schema. It is sufficient to close `F082` as a reversible pressure test.

## Additional public-correction and dispute proof obligations

These obligations come from specimen flow 81. They are intentionally smaller than a public-feedback ledger, correction API, annotation platform, citation resolver, generated-explanation service, moderation workflow, or final SlopOS datacube shape.

### PO-PC-001 — Correction anchor proof

Before Harbor treats a public correction as valid, it must name the affected artifact or variant, source cut, payload digest, label digest, affected labels/cells/summaries/citations, correction class, old status, new status, successor relation if any, public-safe reason, sealed-evidence posture, and non-promises around remote recall and raw evidence disclosure.

### PO-PC-002 — Annotation provenance proof

Before Harbor lets an annotation influence public-copy status, it must record body type, exact target or selector, target digest when known, creator/source class, created/modified time, language, evidence class, review status, safety lane, and relation to any correction anchor or dispute packet.

### PO-PC-003 — Citation freshness proof

Before Harbor relies on a citation to public data, it must record the cited target, retrieval/resolver basis, last-checked time, relation type when known, currentness status, successor/obsolescence status, and whether the citation is evidence, attribution, background, or a stale pointer.

### PO-PC-004 — Generated explanation proof

Before Harbor publishes or accepts a generated explanation over a public copy, it must record source artifacts, payload and label digests, correction anchors included, retrieval/prompt basis, model/tool/source posture, omitted-label list, non-promises carried forward, review status, and invalidation triggers when source labels or correction/dispute status changes.

### PO-PC-005 — Consumer dispute response proof

Before Harbor responds to a consumer dispute, it must identify the disputed artifact/variant/label/cell/summary/explanation, claimant/audience class, claim type, evidence submitted, evidence withheld, interim status, safe public response, sealed/auditor-only review posture, resolution, and non-disclosure boundary for suppressed values or sensitive replay evidence.

## Additional localized-render proof obligations

These obligations come from specimen flow 80. They are intentionally smaller than a localization framework, accessibility program, renderer API, or final SlopOS datacube shape.

### PO-PR-001 — Locale and translation proof

Before Harbor treats a localized public-copy variant as valid, it must name the source artifact, source cut, payload digest, label digest, language/locale tag, resolved formatting options, translation review posture, machine-label preservation, and any fallback used. Locale display must point back to canonical values and units.

### PO-PR-002 — Accessible alternative proof

Before Harbor treats an accessible chart/table variant as proof-grade, it must show the carried labels, table caption, header binding, source link, chart short description, chart long description or equivalent text/data, keyboard/focus posture if interactive, and color-only-meaning check.

### PO-PR-003 — Render-transform proof

Before Harbor trusts a downstream renderer variant, it must record sorting, collation, filtering, grouping, top-N folding, pagination, truncation, hidden rows, and whether exact values, suppression labels, noise labels, and recomposition guards survived.

### PO-PR-004 — Human-summary tether proof

Before Harbor treats a human-readable summary as anything more than explanatory copy, it must state audience, source artifact, label digest, omitted-label list, visible non-promises, restatement link, and proof-grade status. A summary that omits machine labels must be marked explanatory-only.

**Hard no:** no locale receipt, translated-label set, accessible render variant, render-transform note, human-readable-public-copy card, or summary tether is promoted without passing PO-PR-001 through PO-PR-004 across repeated specimens.

## Pass LXXXV localized-render exercise

Specimen flow 80 exercises translated labels, locale number/unit rendering, accessible chart/table alternatives, human-readable summaries, and downstream renderer sorting/grouping drift. The proof result is deliberately insufficient to promote schema. It is sufficient to close `F080` as a reversible pressure test.

# Datacube proof obligations

This surface is a **promotion gate**, not a schema, ADR, registry, or implementation plan.

It exists because Harbor has now collected enough datacube seams that the next danger is premature confidence. A candidate noun may look useful because it appears in a metric system, semantic layer, table format, BI view, assertion tool, or sibling cube. Harbor should not promote it unless the proof packet says what it proves, what it does not prove, and which counterfeits it blocks.

## Rules for this surface
- A proof obligation is not a decision to promote anything.
- A proof packet must stay smaller than row meaning, lane truth, published contract truth, and SlopOS authority.
- A proof packet must cite the specimen, source/register pressure, ledgers, and any sibling-cube borrowing that justified it.
- A helper artifact can satisfy only the obligation it actually proves. A view does not prove source truth; a sidecar does not prove contract strength; a schema alias does not prove semantic equivalence; a pivot output does not prove additivity.
- A noun promoted without a proof packet is counterfeit until repaired.

## Required proof obligations before datacube noun promotion

### PO-DC-001 — grain proof
The packet states the row/observation meaning, population, inclusion/exclusion rule, and whether the lane is base, derived, sampled, rolled up, or externally observed.

**Counterfeits blocked:** one row pretending to mean multiple grains; derived rows masquerading as base rows; convenience population filters becoming invisible truth.

### PO-DC-002 — time-axis proof
The packet states occurrence/event time, business-valid time, system/currentness time, published-cut time, knowledge/as-of time, and any replay cut that affects the answer.

**Counterfeits blocked:** one `timestamp` field pretending to answer every temporal question; moving heads masquerading as exact reviewed snapshots.

### PO-DC-003 — presence proof
The packet states explicit value, explicit null/unknown, not applicable, withheld, omitted, default-shadowed, and missing-evidence posture.

**Counterfeits blocked:** zero/blank/default/null collapse; storage-level absence pretending to be producer intent.

### PO-DC-004 — measurement proof
The packet states quantity family, source unit, canonical machine unit if any, display/render unit, ratio/percent storage posture, money/currency code, conversion/rate basis, rounding/minor-unit posture, and restatement behavior.

**Counterfeits blocked:** unit suffix as semantics; `unit="mixed"`; percent double-scaling; converted money masquerading as original money; dated rates pretending to be physics.

### PO-DC-005 — aggregation and fanout proof
The packet states whether the value is additive, semi-additive, non-additive, ratio/composite, distinct/set/sketch-backed, or presentation-only, and names fanout fences for joins.

**Counterfeits blocked:** one-to-many joins multiplying truth; ratios summed instead of recomputed; cube/pivot output treated as proof of safe rollup.

### PO-DC-006 — conformance proof
The packet states whether shared dimensions/entities are local-only, exactly conformed, shrunken subsets, bridged, provisional, or identity shadows, including effective dates and multiplicity.

**Counterfeits blocked:** same-looking IDs becoming universal identity; local dimensions pretending to support drill-across.

### PO-DC-007 — exactness proof
The packet states exact, exact-from-components, sketch-estimate, sampled/proxy estimate, point-estimate-only, or unknown exactness posture, plus error bands or retained sketch references where applicable.

**Counterfeits blocked:** estimates rendered as exact integers; sidecar sketches silently upgrading base values.

### PO-DC-008 — history and restatement proof
The packet states current-state, changed-rows-since-cut, full change-history, net change, replay cut, carry-over behavior, update/delete posture, correction/restatement trigger, and historical invalidation rule.

**Counterfeits blocked:** after-only history; silent correction; rollback folklore when mutable data already moved.

### PO-DC-009 — contract and evidence proof
The packet states contract tier, assertion plane, observed evidence, severity/blocking posture, waiver/suppression posture, freshness threshold, and consumer-obligation slice.

**Counterfeits blocked:** green badge as full promise; warning as meaning change; consumer-specific slice as universal contract.

### PO-DC-010 — derived-artifact proof
The packet states whether a view, pivot, export, semantic model, compiled assertion, or transformed schema owns data or only names a lens; it names base cuts, dialect/runtime, invalidation rule, freshness basis, and refusal cases.

**Counterfeits blocked:** view metadata impersonating a lane; semantic front door claiming native row truth; schema transform hiding lossy reinterpretation.

### PO-DC-011 — sidecar optionality proof
The packet states whether row lineage, statistics blobs, facets, sketches, indexes, watermarks/frontiers, or other sidecars are optional, required, absent, stale, incompatible, or scope-limited.

**Counterfeits blocked:** optional metadata as mandatory truth; sidecar presence silently strengthening a contract; sidecar absence treated as false data.

### PO-DC-012 — noun-promotion proof
The packet explains why existing surfaces are insufficient, which specimen demonstrates repeated pressure, which irreversible decisions remain avoided, which followthrough item is closed or opened, and what minimal term is being promoted.

**Counterfeits blocked:** one shiny external feature becoming Harbor vocabulary without local pressure; sibling-cube nouns copied without boundary; process notes becoming schema law by accident.

## Additional negative-outcome proof obligations

### PO-NE-001 — negative-class proof
The packet states which negative class is being recorded, what basis cut was checked, what scope the negative claim has, what it does not prove, and which consumer consequence is allowed.

**Counterfeits blocked:** missing helper evidence as row absence; blocked export as absent fact; unsupported target as assertion success; stale progress as permanent incompleteness; tombstone as null or safe purge.

### PO-NE-002 — refusal-lifecycle proof
The packet states created/visible/actionable/recheck/retired posture for a refusal row, including audience, safe alternative, owner or followthrough, expiry, and non-leak note.

**Counterfeits blocked:** refusal as blacklist; one scoped refusal as universal denial; consumer copy as sensitive evidence leak; expired refusal as forgotten design pressure.


## Additional replay-survivability proof obligations

### PO-RS-001 — survivor-set proof
The packet states the minimum artifact set needed for the requested historical answer, which artifacts survived, which expired, which are inaccessible, and which answer modes remain honest.

**Counterfeits blocked:** time-travel folklore; current reruns as old answers; retained sidecars as base data; retained base cuts as lineage proof.

### PO-RS-002 — answer-mode proof
The packet states whether the requested answer is exact recompute, exact frozen answer, partial replay, explainable-not-replayable, unsafe-to-answer, or restated-successor-only.

**Counterfeits blocked:** explanation as recomputation; frozen output as current truth; restated successor as if it were always the original answer.

### PO-RS-003 — retention-mutation proof
The packet states compaction, snapshot expiration, vacuum/cleaning, tombstone/delete retention, sidecar expiry, policy epoch movement, and runtime/dialect drift that affected the old answer.

**Counterfeits blocked:** cleanup as harmless optimization; expired tombstone as no-history; preserved query text as preserved semantics.


## Additional replay-evidence access proof obligations

### PO-RA-001 — audience-bound evidence proof
The packet states which audience may see the answer, which audience may see which evidence view, which audiences are explicitly excluded, and which safe alternatives exist.

**Counterfeits blocked:** aggregate visibility as raw evidence access; auditor-visible proof as consumer-visible proof; operator incident authority as public disclosure approval.

### PO-RA-002 — redaction-cut proof
The packet states what was removed, transformed, disclosed, sealed, or refused, plus which proof obligations remain valid and which are broken by the redaction.

**Counterfeits blocked:** masking as de-identification; digest-only evidence as explanation; derived proof as complete replay.

### PO-RA-003 — verifier-ticket proof
The packet states ticket scope, requester, verifier material, allowed claims, disallowed payload classes, expiry, revocation, nonce/session binding if any, non-recursive fetch rule, and disclosure transcript binding.

**Counterfeits blocked:** verifier ticket as durable access token; proof-bundle presence as policy selection; stale ticket as current authority.

### PO-RA-004 — source-lock drift proof
The packet states old and current source, policy, contract, runtime, assertion/compiler, sidecar, and verifier-bundle locks, plus whether old locks are available, equivalence is proven, or exact verification must be refused.

**Counterfeits blocked:** current policy proving old answers by accident; preserved query text as preserved semantics; source rename as semantic equivalence.


## Additional aggregate-disclosure proof obligations

### PO-AD-001 — releaseability proof
The packet states the exact internal answer mode, the proposed public release mode, audience, source/published cut, grouping grain, and why answerability does or does not imply releaseability.

**Counterfeits blocked:** aggregate-only as safe; exact frozen answer as public release permission; auditor-visible aggregate as consumer-visible aggregate.

### PO-AD-002 — contributor and dominance proof
The packet states contributor-count, denominator, and dominance posture at a class level sufficient for review without leaking the protected value or threshold.

**Counterfeits blocked:** weighted estimate as contributor count; harmless-looking percentage with tiny denominator; magnitude cell dominated by one contributor.

### PO-AD-003 — differencing and repeated-query proof
The packet states sibling-cut/margin/release-history posture and repeated-query/accounting posture for near-neighbor requests over the same source cut or moving head.

**Counterfeits blocked:** one-table-only suppression; provider-excluded table revealing provider-included table; many individually safe filters becoming reconstruction.

### PO-AD-004 — disclosure-treatment proof
The packet states suppression, complementary suppression, collapse, rounding, perturbation, noisy estimate, or refusal mode; names exactness/additivity/utility consequences; and states whether any DP-style claim is supported by mechanism, contribution bounds, parameters, and composition/accounting evidence.

**Counterfeits blocked:** one `D` cell as protection; noise as differential privacy; perturbed public copy as exact; zero-like display as true zero.



## Additional public-copy hygiene proof obligations

### PO-PC-001 — label-preservation proof
The packet states the required public-copy labels, how they are embedded or sidecar-bound, whether the chosen copy format preserves them, and what must be refused or downgraded when labels are stripped.

**Counterfeits blocked:** correct release as valid unlabeled export; BI footnote as machine-readable treatment; matching payload digest as complete proof.

### PO-PC-002 — release-artifact identity proof
The packet states public artifact id, source cut, public cut, payload digest, metadata/label digest, release receipt digest, audience, and exactness/additivity consequences.

**Counterfeits blocked:** screenshot proof as cell proof; dashboard display as artifact identity; current head as emitted public copy.

### PO-PC-003 — mirror/restatement proof
The packet states mirror identity, freshness/staleness posture, last validation, old/new public artifact relation, supersession/deprecation/withdrawal status, and consumer-facing copy.

**Counterfeits blocked:** stale mirror as current truth; restatement as retroactive rewrite; withdrawal as internet recall.

### PO-PC-004 — recomposition and notice proof
The packet states which public copies may not be combined without review, which notice/license/disclosure-treatment labels must travel, and which rights/reuse facts do not imply privacy safety.

**Counterfeits blocked:** valid single copy as safe recomposition; license permission as disclosure safety; provenance as approval.

## Minimum proof packet template
A promotion candidate should include:

```text
Candidate noun:
Owning surface:
Specimen(s):
Pressure/source IDs:
Sibling-cube borrow, if any:
Proof obligations satisfied:
Proof obligations not satisfied:
Counterfeits blocked:
Known residual risks:
Irreversible decisions avoided:
Followthrough item closed/opened:
Promotion verdict: reject | keep as process note | reserve option | promote embryo | promote stable
```

## Additional artifact-handoff / consumer-import proof obligations

### PO-HI-001 — release-claim versus material proof
The packet states the claimed revision/archive/fixture and the material actually observed by the consumer, and refuses filename, locator, or pasted text as identity.

**Counterfeits blocked:** filename-only match; renamed archive as identity; pasted digest as material possession.

### PO-HI-002 — transport non-authority proof
The packet states channel, transform, locator, callback status, upload time, and route evidence while explicitly marking transport as non-authority.

**Counterfeits blocked:** upload timestamp as freshness; portal callback as verification; file-library path as trust root.

### PO-HI-003 — digest-scope proof
The packet states which material the digest covers: release zip bytes, extracted tree manifest, fixture file bytes, or digest text only.

**Counterfeits blocked:** zip digest applied to tree; tree digest applied to zip; repack mismatch hidden by similar contents.

### PO-HI-004 — derived tree / copied fixture context proof
The packet states extraction index/manifest presence, hidden extra artifacts, fixture parent bundle/checker context, and allowed narrow statement.

**Counterfeits blocked:** extracted tree missing index; copied fixture detached from parent bundle; hidden generated artifact after extraction.

### PO-HI-005 — consumer acknowledgement non-promotion proof
The packet states whether a consumer acknowledgement exists and what it does not prove about reliance, security, compliance, or downstream copies.

**Counterfeits blocked:** acknowledgement as reliance; import confirmation as security; consumer response as global downstream copy state.

### PO-HI-006 — handoff non-promotion proof
The packet states which consumer verification API, handoff attestation, package trust root, CI status, artifact-security claim, file-library authority, callback authority, and final SlopOS datacube shape remain unpromoted.

**Counterfeits blocked:** one handoff specimen becoming durable schema; transport convenience becoming product trust; checker pass becoming consumer CI.


## Additional post-import local-derivation proof obligations

### PO-LD-001 — import-context proof
The packet states the source revision/archive, handoff bundle digest, consumer verification basis, import scope, and why import evidence is not derivative currentness or truth.

**Counterfeits blocked:** verified handoff as future derivative authority; portal/callback success as local derivative verification.

### PO-LD-002 — derivative-identity proof
The packet states derivative kind/id/digest, source material digest, target digest, parent handoff context, author scope, and whether a local patch exists.

**Counterfeits blocked:** derivative digest as original digest; annotation author as source authority; local patch as upstream repair.

### PO-LD-003 — transform-scope proof
The packet states transform digest, lossy/lossless posture, label-digest carry-forward, non-promise carry-forward, allowed statement, and forbidden promotions.

**Counterfeits blocked:** summary as source equivalence; subset without suppression labels; generated table without label digest.

### PO-LD-004 — freshness and invalidation proof
The packet states source revision basis, source-change posture, invalidation trigger, expiry/recheck window, and currentness basis.

**Counterfeits blocked:** timestamp as currentness; cache hit as freshness; stale copy as current.

### PO-LD-005 — consumer-copy-state proof
The packet states sync status, conflict policy, stale posture, acknowledgement posture, local patch posture, and global downstream non-promise.

**Counterfeits blocked:** sync success as verification; latest-wins as reconciliation; acknowledgement as repair or reliance.

### PO-LD-006 — local-derivation non-promotion proof
The packet states which local derivation receipt API, consumer cache API, sync-state ledger, annotation authority model, local search truth plane, repair attestation profile, and final SlopOS datacube shape remain unpromoted.

**Counterfeits blocked:** one derivative specimen becoming a product API; local index/search becoming truth; repair patch becoming source correction.

## Hard no list
- No local annotation, generated summary, extracted subset, local index, re-export, cached explanation, synced copy, stale copy, or local repair term is promoted without PO-LD-001 through PO-LD-006.
- No unit, currency, display, or conversion term is promoted without PO-DC-004.
- No aggregate, metric, cube, pivot, or BI export term is promoted without PO-DC-005 and PO-DC-010.
- No shared dimension/entity term is promoted without PO-DC-006.
- No restatement/history term is promoted without PO-DC-002 and PO-DC-008.
- No semantic-front-door term is promoted without PO-DC-005, PO-DC-009, and PO-DC-010.
- No row-lineage/statistics/facet/watermark sidecar term is promoted without PO-DC-011.
- No replay-evidence access, redaction, verifier-ticket, derived-proof, or source-lock term is promoted without PO-RA-001 through PO-RA-004.
- No aggregate-disclosure, small-cell, dominance, differencing, repeated-query, disclosure-budget, noise/perturbation, or release-copy term is promoted without PO-AD-001 through PO-AD-004.
- No public-copy label, release-artifact receipt, mirror-hygiene note, restatement chain, recomposition guard, notice/license propagation note, or proof-of-copy ticket is promoted without PO-PC-001 through PO-PC-004.
- No transparency/provenance receipt import, content credential, in-toto/SLSA attestation, SCITT-like inclusion, Rekor/CT-style inclusion, timestamp anchor, verifier policy result, issuer-compromise advisory, or redacted proof term is promoted without PO-TP-001 through PO-TP-006.
- No generated mutation, coverage claim, shrink note, property-test operator, fuzzer corpus, mutation dashboard, or conformance-suite term is promoted without PO-PM-001 through PO-PM-006 and PO-MT-001 through PO-MT-006 when survived/overstrict/pruning behavior is involved.
- No checker observation, guard-state receipt, self-test receipt, reviewer override, stale-pairing note, checker registry, CI status, trust-root schema, or automated reliance workflow is promoted without PO-CP-001 through PO-CP-006.
- No release package, archive index, deterministic ZIP plan, build-environment receipt, package digest, release attestation, trust-root claim, CI status, archive signature, or reproducible-build claim is promoted without PO-RP-001 through PO-RP-006.
- No artifact handoff, consumer import, renamed archive, file-library upload, portal/callback transfer, pasted digest, extracted tree, copied fixture, or consumer acknowledgement term is promoted without PO-HI-001 through PO-HI-006.
- No schema alias/default/transform is treated as semantic equivalence without PO-DC-003, PO-DC-006, PO-DC-009, and PO-DC-010 as applicable.

## Current status
Pass LXXVII uses this surface immediately for measurement semantics and rate-restatement pressure, but it does not promote proof obligations into a machine-readable schema yet. The surface remains process residue until repeated specimens show that Harbor needs a stricter artifact.


## Pass LXXVIII semantic-export exercise
Specimen flow 73 exercises `PO-DC-005`, `PO-DC-009`, `PO-DC-010`, `PO-DC-011`, and `PO-DC-012` for a semantic export receipt, contract subset, freshness basis witness, join/fanout fence, and optional row-lineage sidecar. The proof result is deliberately insufficient for durable schema promotion: semantic exports remain derived lenses with refusals.


## Pass LXXIX option-reservation exercise
Specimen flow 74 exercises `PO-DC-010`, `PO-DC-011`, and `PO-DC-012` across observation exchange receipts, derived-view receipts, sidecar notes, frontier/watermark witnesses, assertion compiler receipts, and schema transform receipts. The proof result is deliberately insufficient for durable schema promotion: every artifact remains an option-reservation cut with anti-counterfeit tests.


## Pass LXXX negative-evidence exercise
Specimen flow 75 exercises `PO-DC-003`, `PO-DC-009`, `PO-DC-010`, `PO-DC-011`, `PO-DC-012`, `PO-NE-001`, and `PO-NE-002` across missing sidecars, blocked exports, unsupported assertion targets, stale frontiers, tombstone/withdrawal residue, and consumer-facing refusal rows. The proof result is deliberately insufficient for durable schema promotion: negative evidence remains scoped process residue with lifecycle and non-promises.


## Pass LXXXI replay-survivability exercise
Specimen flow 76 exercises `PO-DC-002`, `PO-DC-008`, `PO-DC-010`, `PO-DC-011`, `PO-NE-001`, `PO-NE-002`, `PO-RS-001`, `PO-RS-002`, and `PO-RS-003` across replay after compaction, frozen answer packets, expired tombstone evidence, sidecar-retention mismatch, runtime/policy drift, and exact historical answer requests. The proof result is deliberately insufficient for durable schema promotion: replay survivability remains answerability process residue until repeated real retention-window failures prove otherwise.


## Pass LXXXII replay-evidence access exercise
Specimen flow 77 exercises `PO-DC-009`, `PO-DC-010`, `PO-DC-011`, `PO-RS-001`, `PO-RS-002`, `PO-RS-003`, `PO-RA-001`, `PO-RA-002`, `PO-RA-003`, and `PO-RA-004` across redacted replay bundles, access-controlled frozen answers, auditor verifier packets, aggregate-visible/raw-hidden consumers, ticket expiry, and source-lock drift. The proof result is deliberately insufficient for durable schema promotion: replay-evidence access remains audience-bound process residue until repeated real disclosure-pressure specimens prove otherwise.


## Pass LXXXIII aggregate-disclosure exercise
Specimen flow 78 exercises `PO-DC-005`, `PO-DC-007`, `PO-DC-009`, `PO-DC-010`, `PO-NE-001`, `PO-NE-002`, `PO-RA-001`, `PO-AD-001`, `PO-AD-002`, `PO-AD-003`, and `PO-AD-004` across small-cell suppression, small-denominator rates, magnitude dominance, sibling-cut differencing, repeated-query leakage, noisy/perturbed release candidates, structural-zero confusion, and safe refusal copy. The proof result is deliberately insufficient for durable schema promotion: aggregate-disclosure posture remains release-process residue until repeated real public-copy specimens prove otherwise.

## Pass LXXXIV public-copy hygiene exercise
Specimen flow 79 exercises `PO-DC-005`, `PO-DC-007`, `PO-DC-009`, `PO-DC-010`, `PO-RA-001`, `PO-AD-001`, `PO-AD-003`, `PO-AD-004`, and `PO-PC-001` through `PO-PC-004` across valid labeled public copies, label-stripped mirrors, restated disclosure-treated answers, recomposition attempts, stale caches, notice/license propagation, and proof-of-copy tickets. The proof result is deliberately insufficient for durable schema promotion: public-copy hygiene remains release-process residue until repeated real mirrors/exports prove otherwise.

## Additional derivative correction propagation proof obligations

### PO-DR-001 — source-correction scope proof
The packet states correction id, prior source digest, corrected source digest, delta digest, target scope, and whether any rollback/dispute branch requires a scope map.

**Counterfeits blocked:** latest correction wins; correction as global repair; correction as consumer compliance.

### PO-DR-002 — derivative inventory proof
The packet states derivative id, kind, prior derivative digest, basis source digest, local derivation bundle digest, label posture, and parent/child map posture.

**Counterfeits blocked:** source correction applied to the wrong derivative; re-export parent identity overwrite; label loss hidden by rebuild.

### PO-DR-003 — propagation notice proof
The packet states route family, delivery observation, read/application separation, unreached surfaces, and notice non-promises.

**Counterfeits blocked:** delivery as user read; notification as application; broadcast as all derivatives reached.

### PO-DR-004 — invalidation and material-state proof
The packet states quarantine, rebuild, revalidation, supersession, or notice-only action, corrected-source digest posture, output digest posture, and recheck/expiry window.

**Counterfeits blocked:** invalidation as repair; cache refresh without source revalidation; index rebuild as search truth.

### PO-DR-005 — consumer acknowledgement proof
The packet states acknowledgement type, target derivative digest, signer scope, and whether acknowledgement claims repair, compliance, or authority.

**Counterfeits blocked:** acknowledgement as repair; wrong derivative digest; local signer as source authority; consumer repair as compliance.

### PO-DR-006 — derivative repair non-promotion proof
The packet states which derivative invalidation ledger, consumer cache API, repair attestation profile, sync-state authority, notification delivery guarantee, compliance workflow, retention API, and final SlopOS datacube shape remain unpromoted.

**Counterfeits blocked:** one derivative repair specimen becoming a product API; one repaired derivative becoming global downstream closure.

## Additional derivative repair retention/expiry proof obligations

### PO-RE-001 — evidence-subject proof
The packet states the derivative repair bundle digest, source material digest, derivative digest, repair receipt digest, acknowledgement digest, and subject scope.

**Counterfeits blocked:** retention applied to the wrong derivative; retained receipt as global repair; tombstone without subject identity.

### PO-RE-002 — retention-policy scope proof
The packet states the policy basis, retention window, compaction allowance, subject-scope match, and why retention extends evidence availability rather than truth.

**Counterfeits blocked:** retention schedule as currentness; borrowed window as authority; policy as compliance.

### PO-RE-003 — expiry-clock proof
The packet states receipt-observed time, expiry time, evaluated time, clock basis, and whether the receipt is expired at evaluation.

**Counterfeits blocked:** clockless expiry; expired receipt as current repair; expiry as fault or repair.

### PO-RE-004 — compaction/pruning/hold proof
The packet states raw-evidence posture, tombstone posture, subject-digest carry-forward, privacy minimization, migration map, warning residue, and hold/waiver exception.

**Counterfeits blocked:** compaction digest as full evidence; deletion as repair; privacy minimization as no-stale-copy proof; hold as freshness.

### PO-RE-005 — recheck and later-correction proof
The packet states whether recheck was performed or only scheduled, the recheck result, any later source-correction digest, and whether that later correction was considered.

**Counterfeits blocked:** scheduled recheck as passed; second correction ignored; stale repair receipt as current repair.

### PO-RE-006 — retention/expiry non-promotion proof
The packet states which records-management system, legal-hold workflow, privacy-erasure API, retention schedule registry, evidence-vault format, consumer cache API, compliance workflow, and final SlopOS datacube shape remain unpromoted.

**Counterfeits blocked:** one retention specimen becoming a records system; retained evidence becoming legal/compliance authority; privacy pruning becoming erasure proof.

## Pass CV derivative repair retention/expiry exercise
Specimen flow 100 exercises `PO-RE-001` through `PO-RE-006` across active repair windows, expired receipts, compacted tombstones, legal-hold-like preservation, later source corrections, quarantine residue, digest-pointer-only retention, stale recurrence warning reopen, privacy-minimized tombstones, reviewer waiver notes, and hostile retention overclaims. The proof result is deliberately insufficient for durable schema promotion: retention/expiry remains scoped process residue until repeated real repair-evidence aging specimens prove otherwise.

## Additional overlapping correction-epoch lineage proof obligations

### PO-OL-001 — source-epoch and order proof
The packet states source material digest, correction epoch ids, epoch digests, observation clock basis, partial-order edges, rollback/dispute/parallel posture, and why epoch order is not global truth or source-owner closure.

**Counterfeits blocked:** latest epoch wins; source-owner closure; parallel epochs total-ordered without authority; clockless epoch comparison.

### PO-OL-002 — derivative-lineage proof
The packet states derivative id, pre-epoch digest, epoch-specific post-repair digests, lineage edges, rebase/rollback edges, digest-reuse posture, cycle detection, and subject-digest scope.

**Counterfeits blocked:** derivative digest reused across epochs; cycles in lineage graph; derivative lineage as original source or global downstream state.

### PO-OL-003 — repair/rebase/rollback action proof
The packet states action class, base epoch, target epoch, scope map, delta map, rebase map, rollback recheck posture, retention-expiry consideration, and acknowledgement epoch.

**Counterfeits blocked:** wrong-epoch local patch; rollback without recheck; overlap merge without delta map; acknowledgement for epoch A counted for epoch B.

### PO-OL-004 — scope reconciliation proof
The packet states whether correction scopes are disjoint, overlapping, partially overlapping, conflicting, parallel, or unknown, plus scope-map digest and whole-artifact widening posture.

**Counterfeits blocked:** disjoint corrections as conflict; field-scope widening to whole artifact; latest-wins without overlap map; stale subset as global current.

### PO-OL-005 — currentness and consumer-state proof
The packet states evaluation clock, epoch-A and epoch-B status, retention cut, recheck requirement, public badge posture, mixed-epoch visibility, warning-history preservation, and source-owner closure attempt.

**Counterfeits blocked:** old receipt as current repair; retention expiry ignored; green badge across mixed epochs; rollback erases intermediate warning history.

### PO-OL-006 — lineage non-promotion proof
The packet states which correction-epoch registry, derivative repair ledger, conflict-resolution engine, source-owner closure authority, public badge workflow, consumer cache API, compliance workflow, cross-cube lineage API, and final SlopOS datacube shape remain unpromoted.

**Counterfeits blocked:** one lineage specimen becoming a registry, repair ledger, tribunal, badge engine, compliance system, or inherited-status API.

## Pass CVI overlapping correction-epoch lineage exercise
Specimen flow 101 exercises `PO-OL-001` through `PO-OL-006` across linear epoch chains, retained epoch-A repair history, disjoint correction coexistence, overlapping split states, rollback branches, partial subset repair, consumer patch rebase, stale acknowledgement residue, external disputes, named-field supersession, latest-wins, stale-currentness, rollback erasure, false conflict, missing delta maps, wrong patch bases, acknowledgement epoch mismatch, digest reuse, missing clocks, unauthorized parallel ordering, field widening, stale subset global currentness, source-owner closure, green badges, rollback without recheck, and lineage cycles. The proof result is deliberately insufficient for correction-registry, repair-ledger, conflict-resolution, public-badge, compliance, cross-cube import, or final SlopOS datacube promotion.

## Additional cross-cube lineage import proof obligations

### PO-XC-001 — foreign-material identity proof
The packet states cube id, foreign revision, archive name, archive digest, fragment family, native status, parent-manifest posture, and fragment digest before Harbor imports any evidence.

**Counterfeits blocked:** filename or revision as identity; copied fragment without parent context; archive digest mismatch; native status as Harbor status.

### PO-XC-002 — local-observation and transport proof
The packet states import id, observation clock, transport surface, material recheck posture, local root digest, and foreign fragment digests.

**Counterfeits blocked:** upload timestamp as freshness; callback success as authority; pasted digest as material; transport success as adoption.

### PO-XC-003 — scope-translation proof
The packet states native scope, Harbor scope, relation, scope-map digest, widened-scope attempts, semantic-supersession pressure, and single-badge pressure.

**Counterfeits blocked:** foreign scope widened to whole artifact; SlopOS append order as semantic supersession; multi-cube warning state as one public badge.

### PO-XC-004 — authority-quarantine proof
The packet states native statuses, allowed Harbor uses, quarantine state, inherited-status flags, and non-promises for currentness, repair, consent, delegation, erasure, compliance, and public truth.

**Counterfeits blocked:** foreign green status as Harbor status; replay availability as currentness; retention as repair; ViewFS volition as consent outcome; Ward warrant as authority transfer; Schell forgetting as erasure proof.

### PO-XC-005 — lineage-bridge and recheck proof
The packet states prior Harbor lineage bundle digest, bridge digest, foreign fragment digests, cross-cube clock-map posture, sealed-evidence public-summary posture, and required local recheck before any status admission.

**Counterfeits blocked:** cross-cube total order without clock map; foreign policy majority vote; sealed evidence as public truth; Helm trace as completed repair.

### PO-XC-006 — cross-cube import non-promotion proof
The packet states which cross-cube status inheritance, companion trust root, foreign compliance workflow, multi-cube conflict-resolution engine, global public badge workflow, consent/delegation authority transfer, repair-ledger import API, foreign-import revocation API, and final SlopOS datacube shape remain unpromoted.

**Counterfeits blocked:** one import specimen becoming a companion trust system, status API, badge engine, compliance workflow, revocation API, or final datacube shape.

## Pass CVII cross-cube lineage import exercise
Specimen flow 102 exercises `PO-XC-001` through `PO-XC-006` across SlopOS append history, Foundry classification pins, Steward retry attempts, Schell retention context, ViewFS volition cards, Ward delegation warrants, Helm repair traces, multi-cube incomparable splits, sealed foreign packets, stale companion revisions, and hostile inherited-status overclaims. The proof result is deliberately insufficient for cross-cube status inheritance, companion trust roots, foreign compliance workflows, multi-cube conflict-resolution engines, global public badge workflows, consent/delegation authority transfer, repair-ledger import APIs, foreign-import revocation APIs, or final SlopOS datacube promotion.

## Additional foreign-import revocation/correction proof obligations

### PO-FR-001 — parent import and foreign-material proof
The packet states the parent F102 import id, parent bundle digest, foreign cube id, foreign revision, archive digest, fragment family, prior native status, prior safe Harbor use, parent-manifest posture, and prior fragment digest.

**Counterfeits blocked:** notice without parent import; revision as identity; companion native status as Harbor status; copied fragment without parent context.

### PO-FR-002 — foreign change notice proof
The packet states withdrawal, supersession, correction, dispute, expiry, or re-scope notice class; issuer; notice clock; notice digest; archive-digest posture; sealed/public posture; stale-notice posture; and change-scope posture.

**Counterfeits blocked:** missing change digest; archive mismatch; notice timestamp as currentness; sealed notice as public truth; stale notice as freshness.

### PO-FR-003 — local impact and history-residue proof
The packet states local impact analysis, scope relation, whether current use changes, why prior import history is retained, and why revocation does not imply prior falsehood, Harbor negligence, dispute adjudication, erasure, or repair.

**Counterfeits blocked:** revocation as prior falsity; dispute as falsehood; expiry as erasure or repair; supersession as trust promotion; companion notice as Harbor authority.

### PO-FR-004 — downstream quarantine and recheck proof
The packet states affected derivatives, known/unreached surfaces, quarantine state, rollback preconditions, recheck clock basis, and why notice delivery or consumer acknowledgement is not repair.

**Counterfeits blocked:** withdrawal as automatic downstream repair; consumer acknowledgement as repair; rollback without recheck; supersession as global derivative closure.

### PO-FR-005 — multi-notice and scope-split proof
The packet states whether notices are comparable, conflicting, stale, sealed, majority-pressured, or scope-split, plus why Harbor refuses majority vote, foreign re-scope widening, and single badge collapse.

**Counterfeits blocked:** majority-vote revocation; foreign scope widened to Harbor scope; public green badge from revocation; multi-cube notice set as global truth.

### PO-FR-006 — foreign revocation non-promotion proof
The packet states which foreign revocation API, companion trust root, automatic downstream repair workflow, prior-falsity judgment, negligence judgment, foreign compliance workflow, global public badge workflow, cross-cube status inheritance, and final SlopOS datacube shape remain unpromoted.

**Counterfeits blocked:** one revocation specimen becoming a trust system, repair engine, compliance workflow, public badge system, negligence adjudicator, status inheritance API, or final datacube shape.

## Pass CVIII foreign-import revocation exercise
Specimen flow 103 exercises `PO-FR-001` through `PO-FR-006` across withdrawn SlopOS append imports, superseded Foundry pins, corrected Steward retry history, expired Schell retention context, re-scoped ViewFS volition evidence, withdrawn Ward warrants, disputed Helm repair traces, multi-cube conflicting revocations, sealed notices, stale supersession notices, and hostile foreign-change overclaims.  The proof result is deliberately insufficient for foreign revocation APIs, companion trust roots, downstream repair workflows, negligence judgments, compliance workflows, public badge systems, cross-cube status inheritance, or final SlopOS datacube promotion.

## Executable surface registry audit obligation
The rev0108 audit refactor centralizes the F090-F103 executable proof-slice list in `tools/harbor_executable_surface_registry.py` and verifies path existence, checker order, followthrough state, latest-surface wiring, and README count wording.  The registry is maintenance scaffolding only; it is not a conformance registry, checker trust root, CI status API, certification badge, promotion gate, or final SlopOS datacube shape.

## Additional revocation-overlay propagation proof obligations

### PO-RO-001 — overlay-source proof
The packet states parent F103 bundle digest, parent case, overlay id, overlay digest, overlay clock, sealed/stale posture, and source non-promises before any public/local propagation.

**Counterfeits blocked:** missing source revocation digest; sealed notice as public truth; timestamp as currentness; companion notice as Harbor authority.

### PO-RO-002 — target-surface proof
The packet states the exact public copy, mirror, generated summary, consumer notice, local index, warning card, sealed summary, or multi-cube card targeted by the overlay.

**Counterfeits blocked:** one public surface as all surfaces; mirror/search truth; warning-card global badge; generated summary as source equivalent.

### PO-RO-003 — propagation-action proof
The packet states reached surfaces, unreached/unknown surfaces, source digest carry-forward, label carry-forward, history link, and scope map.

**Counterfeits blocked:** mirror clean as all copies clean; summary rewrite without source digest; global downstream repair; history erasure on retraction.

### PO-RO-004 — notice and visibility proof
The packet states display mode, public wording posture, green/red badge refusal, compliance refusal, consumer delivery/read/applied separation, and problem-detail failure reason if rejected.

**Counterfeits blocked:** delivery as read/applied/repaired; overlay as compliance remediation/failure; overlay as prior falsehood; badge collapse.

### PO-RO-005 — index/warning/currentness proof
The packet states local index refresh posture, warning-card split state, recheck clock basis, stale-overlay handling, and mixed-overlay comparability.

**Counterfeits blocked:** index refresh as truth; warning sunset without scope; stale overlay as current; majority-vote overlay verdict; single badge over mixed overlays.

### PO-RO-006 — propagation non-promotion proof
The packet states which revocation propagation API, public badge workflow, compliance workflow, prior-falsity judgment, global downstream repair, notification guarantee, mirror/search truth plane, warning-card status engine, bundle schema, and final SlopOS datacube shape remain unpromoted.

**Counterfeits blocked:** one overlay-propagation specimen becoming a badge engine, public status workflow, compliance system, notification guarantee, or schema.

## Pass CIX revocation-overlay propagation exercise
Specimen flow 104 exercises `PO-RO-001` through `PO-RO-006` across public copies, mirrors, generated summaries, consumer notices, local indexes, warning cards, partial propagation, sealed summaries, stale mirrors, multi-cube cards, badges, compliance claims, prior-falsity banners, mirror/global closure, source-digest-free summaries, delivery/read/application confusion, search truth, warning sunset, stale currentness, majority vote, single badge collapse, global repair, history erasure, callback status, timestamp freshness, and missing source digests. The proof result is deliberately insufficient for revocation propagation APIs, public badge workflows, compliance workflows, notification guarantees, mirror/search truth planes, warning-card engines, shared bundle schemas, or final SlopOS datacube promotion.

## Additional user-visible explanation proof obligations

### PO-UX-001 — overlay-input and scope proof
The packet states parent F104 bundle digest, parent case reference, surface kind, overlay digest, scope-map digest, source non-promises, and observation clock before any public wording can be accepted.

**Counterfeits blocked:** badge-only display; missing source overlay digest; missing scope map; public text detached from parent overlay.

### PO-UX-002 — explanation-copy proof
The packet states headline, body, caveats, plain-language posture, copy digest, and explicit flags for badge, closure, prior-fault, sealed-detail, confidence, and legal-advice language.

**Counterfeits blocked:** closure labels; prior-falsehood/negligence claims; confidence-as-truth; sealed detail leakage; legal advice language.

### PO-UX-003 — reason-code and action-affordance proof
The packet states machine-readable reason code, human-text pairing, allowed user actions, repair/read/application/legal/compliance flags, and action digest.

**Counterfeits blocked:** machine-code-only user messages; inspect/recheck controls turned into repair; delivery turned into read/application; action labels as consent or reliance.

### PO-UX-004 — access/localization proof
The packet states programmatic-label posture, text-not-color-only posture, localization source digest, localized variant digest, translation provenance, and scope-widening flag.

**Counterfeits blocked:** color-only status; missing programmatic label; translation without provenance; localized scope widening; accessibility conformance or localization equivalence overclaim.

### PO-UX-005 — history and mixed-state proof
The packet states parent overlay bundle digest, prior import digest, prior-history visibility, mixed-overlay preservation, timestamp-currentness flag, and history digest.

**Counterfeits blocked:** hidden prior history; mixed companion overlays collapsed into one sentence; timestamp freshness as currentness; retraction as history erasure.

### PO-UX-006 — user-visible explanation non-promotion proof
The packet states which public badge workflow, compliance workflow, legal-finding vocabulary, global downstream repair workflow, notification read guarantee, accessibility conformance claim, localization equivalence guarantee, explanation API, and final SlopOS datacube shape remain unpromoted.

**Counterfeits blocked:** one explanation specimen becoming product UX law, compliance status, legal advice, or a new trust surface.

## Pass CX user-visible explanation exercise
Specimen flow 105 exercises `PO-UX-001` through `PO-UX-006` across scoped public-copy cards, stale mirror recheck explanations, generated summary caveats, consumer notice delivery/read splits, local-index snippets, warning-card split states, sealed public summaries, mixed companion cards, localized variants, status messages, problem-detail-like reason codes, action panels, and hostile explanation collapses. The proof result is deliberately insufficient for an explanation API, badge workflow, accessibility conformance claim, localization guarantee, compliance workflow, legal-finding system, notification-read guarantee, or final SlopOS datacube promotion.

## Additional user-response event proof obligations

### PO-UR-001 — parent explanation proof
The packet states parent F105 explanation bundle digest, parent explanation case, surface kind, explanation digest, explanation clock, stale-explanation flag, and source non-promises before any response event can be interpreted.

**Counterfeits blocked:** response without parent explanation digest; stale explanation response as currentness; UI label alone as response basis.

### PO-UR-002 — response-event proof
The packet states event kind, event clock, event text, pseudonymous actor posture, agent-generation flag, delivery-receipt-only flag, and event digest.

**Counterfeits blocked:** notification delivery as user action; agent-generated acknowledgement as user consent; direct person identifier as default response identity.

### PO-UR-003 — capture-context proof
The packet states surface, affordance, instrumentation level, scope-map carry-forward, localized scope posture, undo/escape availability, and delivery/focus/scroll promotion flags.

**Counterfeits blocked:** focus as seen; scroll depth as understanding; localized acknowledgement as scope widening; final action without undo/escape.

### PO-UR-004 — interpretation and follow-up proof
The packet states guard flags for comprehension, consent, reliance, repair, compliance, all-recipient read, permission, recheck-passed, and currentness claims, plus follow-up actions and result-observation posture.

**Counterfeits blocked:** click as comprehension; acknowledgement as consent or compliance; export as reliance; appeal/retry/recheck request as repair or passed result; share link as all-recipient read.

### PO-UR-005 — privacy/retention and history proof
The packet states minimization, actor reference kind, raw identifier posture, retention window/expiry, consent-record attempts, analytics risk, parent explanation history, and stale-response residue.

**Counterfeits blocked:** response analytics that identify a person; unbounded retention by default; stale responses as currentness; response traces as identity registries or analytics products.

### PO-UR-006 — user-response non-promotion proof
The packet states which consent record system, reliance ledger, repair proof, compliance workflow, legal posture, all-recipient read guarantee, user-identity registry, analytics product, UI telemetry API, notification-read guarantee, and final SlopOS datacube shape remain unpromoted.

**Counterfeits blocked:** one response-event specimen becoming a consent system, reliance status plane, analytics product, identity registry, repair workflow, or compliance result.

## Pass CXI user-response event exercise
Specimen flow 106 exercises `PO-UR-001` through `PO-UR-006` across inspect, recheck request, export, dismiss, appeal start, share-link copy, acknowledgement, focus, localized acknowledgement, sealed-detail request, agent follow-up, notification opt-out, batch acknowledgement, automated retry, and hostile response-status collapses. The proof result is deliberately insufficient for consent receipt formats, reliance ledgers, UI telemetry APIs, analytics products, identity registries, notification-read guarantees, legal/compliance workflows, repair proof, or final SlopOS datacube promotion.
