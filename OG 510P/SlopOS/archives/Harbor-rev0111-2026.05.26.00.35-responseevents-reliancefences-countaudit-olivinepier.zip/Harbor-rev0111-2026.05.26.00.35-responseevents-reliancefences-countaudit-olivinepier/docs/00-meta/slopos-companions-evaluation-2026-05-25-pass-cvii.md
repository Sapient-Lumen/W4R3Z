# SlopOS companions evaluation — 2026-05-25 pass CVII

## Harbor / SlopOS seam

F102 makes the Harbor-SlopOS boundary explicit for cross-cube import. SlopOS can prove that a `portal.net` request was accepted, appended, resumed, truncated, replayed, or returned through a callback. Harbor can import that as ordering and materialization evidence, but not as Harbor currentness, semantic supersession, user comprehension, public badge authority, or derivative repair.

## Companion seams

- Foundry classification pins and crosswalk witnesses are label provenance, not Harbor status truth.
- Steward retry attempts and pushback budgets are attempt history, not compliance success or failure.
- Schell retention budgets and forgetting ledgers are retention context, not deletion, repair, or erasure proof.
- ViewFS volition cards and consent fences are consent evidence, not durable consent outcome or local authorization.
- Ward stewardship charters and delegation warrants are route/escalation evidence, not authority transfer.
- Helm repair attempts and intervention traces are repair evidence that still needs Harbor scope comparison and recheck.

## Refusals

- Foreign green status is not Harbor status.
- Replayable foreign history is not currentness.
- Retained or forgotten foreign evidence is not repair or erasure proof.
- Warning state is not public badge authority.
- Companion revision is not freshness.
- Callback success is not authority transfer.
- Majority across companion cubes is not policy resolution.

## Next pressure

F103 should stress foreign-import revocation and correction: what happens when a companion cube later withdraws, supersedes, disputes, or expires the imported fragment Harbor used as evidence.
