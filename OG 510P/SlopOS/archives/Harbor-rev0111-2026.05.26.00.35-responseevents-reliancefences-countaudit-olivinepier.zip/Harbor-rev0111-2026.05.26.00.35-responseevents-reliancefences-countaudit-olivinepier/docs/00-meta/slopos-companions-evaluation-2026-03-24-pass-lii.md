# SlopOS / companions evaluation — pass LII

This pass re-checks Harbor against SlopOS and the sibling cubes after adding a default-target-cue / coverage-note specimen, and again chooses one narrow crossing seam over any early family bloom.

## What the current cubes still teach
- **SlopOS** remains the strongest restraint mechanism. Its provider-local auth-discovery, auth-result, and authorization-context boundaries already keep fetched routing, callback packaging, and durable export semantics separate. That lines up with Harbor treating default JWT audience cues and challenge-derived coverage as crossing residue rather than portable entitlement or target truth.
- **SlopOS** also keeps reinforcing the design-phase lesson that imported/provider-owned auth facts stay provider-local until a separate seam earns promotion. Harbor should borrow that humility directly for confirmation-gap receipts.
- **Ward** still reinforces exact-basis and typed-veto posture: if the response confirmation surface is absent, duplicated, or weaker than the discovery cue suggested, the right move is a visible local gap or discard, not counterfeit certainty.
- **Helm** still contributes bounded-display humility: good visible hints help the operator, but default cues and broader coverage notes should remain subordinate to exact basis and exact confirmation.
- **Foundry** still teaches aftermath honesty: a turn can leave useful residue like “likely covered” or “not strongly confirmed” without becoming runtime authority.
- **Steward** still teaches accountability: when Harbor bottoms out in a confirmation gap, the archive should say so plainly instead of flattering the turn into silent success.

## Harbor consequence
Harbor should keep this move modest:
- add one specimen around **default-target cue**, **coverage note**, and **confirmation-gap receipt**;
- keep challenge-derived coverage, token-format default targeting, client-facing token-response confirmation, and local discard/gap posture visibly separate;
- collect **segment-bounded coverage** and **client-confidence ladder** as inspiration only;
- and leave any future portable target-inference, coverage, or confidence registry outside Harbor for now.

## Still-not-yet decisions
- Whether **default-target cue** deserves its own Harbor family, or should remain only an annotation on request and aftermath surfaces.
- Whether **coverage note** belongs in Harbor at all, or should remain only a discovery annotation attached to specific protected-resource metadata specimens.
- Whether **confirmation-gap receipt** belongs in Harbor, or should stay a typed local explanation that never blooms into a portable target-confirmation or confidence registry.
