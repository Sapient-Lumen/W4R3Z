# Research synthesis — pass LIII

This pass keeps Harbor narrow and learns five compatible things at once: **token introspection is a protected-resource-facing metadata channel rather than a concrete protected-resource oracle; JWT access-token audiences and introspection audiences can help resource servers reason about coverage without giving clients interoperable certainty about exact protected-resource applicability; modern guidance still wants audience restriction, preferably to a single resource server, with the resource server refusing mismatches; local resource-server expectation is therefore a real crossing fact; and Harbor should preserve the resulting confidence ladder without freezing a portable target or entitlement registry too early.**

## Outside lessons
1. **Introspection is RS-facing metadata, not a concrete URL oracle.**  
   RFC 7662 defines token introspection as a way for a protected resource to query the authorization server about token state and metadata. Its standard response members can include `scope`, `client_id`, `username`, and `aud`, where `aud` is only a service-specific string identifier or list of identifiers representing intended audience. Harbor should preserve a **token-format target witness** instead of pretending introspection produces portable concrete protected-resource truth.

2. **Audience restriction still needs a local receiver check.**  
   The March 2026 OAuth 2.1 draft says access tokens should be audience-restricted, preferably to a single resource server, and every resource server must verify on each request that the token was meant for that particular resource server and refuse service otherwise. Harbor therefore needs a visible **resource-server coverage card** that is smaller than durable grant truth but stronger than generic “the token looked plausible”.

3. **JWT audience and client-facing resource confirmation are different strengths of fact.**  
   RFC 9068 requires a resource server to reject a JWT access token if `aud` does not contain a resource indicator the resource server expects for itself. If the request omitted `resource`, the authorization server must still put a default resource indicator in `aud`. But the March 2026 resource-token-response draft says clients cannot rely on audience information from either introspection or local inspection of a self-contained token to determine whether the token is applicable to a specific protected resource. Harbor should therefore keep token-format target evidence smaller than explicit client-facing resource confirmation.

4. **Multi-audience breadth should not flatten local expectation.**  
   OAuth 2.1 explicitly contemplates a token audience being either a single resource server or a list of resource servers. That breadth can be real, but Harbor should not let one list-like audience fact masquerade as exact acceptance by every endpoint, alias, or path the local protected resource might expose.

5. **Confidence deserves an honest ladder.**  
   Some turns end with exact client-facing `resource` confirmation, some only with resource-server local audience/alias acceptance, and some only with token-format or introspection hints. Harbor should preserve a **client-confidence ladder** rather than counterfeiting one level into another.

## Resulting Harbor move
Do not decide yet whether Harbor needs durable nouns such as **token-format target witness**, **resource-server coverage card**, or **client-confidence ladder**.
For this revision:
- add one specimen around RFC 7662 introspection audiences, JWT access-token audience checks, and local protected-resource expectation mismatch;
- preserve the difference between “what the token/introspection surface says”, “what this resource server locally expects or aliases”, “what a client-facing `resource` response might later confirm”, and “what local mismatch veto still bottomed out here”;
- and collect **local-expectation veto** plus **response-over-token precedence** as inspiration only, without promoting a new registry today.

## Fresh ideas worth stealing
- **token-format target witness** — compact residue that a token string or introspection response named certain audience or resource-like identifiers.
- **resource-server coverage card** — local note about which audience identifiers or aliases this protected resource will currently treat as in-family.
- **client-confidence ladder** — inspectable distinction between response-confirmed, receiver-locally-accepted, and token-format-only target confidence.
- **local-expectation veto** — future-facing reminder that a token can look structurally valid yet still fail the current resource server’s exact expectation.
- **response-over-token precedence** — future-facing reminder that client-facing returned `resource` confirmation can outrank ambiguous audience folklore when both are present.
