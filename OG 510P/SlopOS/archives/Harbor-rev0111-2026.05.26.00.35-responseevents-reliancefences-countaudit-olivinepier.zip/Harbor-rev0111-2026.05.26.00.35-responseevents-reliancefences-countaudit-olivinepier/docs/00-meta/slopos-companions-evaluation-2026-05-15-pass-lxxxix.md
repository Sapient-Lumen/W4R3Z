# SlopOS and companions evaluation — pass LXXXIX

**Revision:** `rev0089`  
**Date:** 2026-05-15  
**Focus:** disputed remediation, acknowledgement expiry, contradictory impact reports, unverifiable use attestations, and public-status drift.

## SlopOS pressure

SlopOS remains in design phase; that argues for scoped reconciliation packets rather than a status tribunal.

The strongest SlopOS lessons for this pass:

- **Status is not authority.** A public banner, provider note, catalog card, generated explanation, or model/eval card can drift out of sync with proof basis.
- **Claim receipts stay smaller than truth.** Remediation claims, non-use claims, and external impact reports need subject, digest, method, actor authority, window, and limits before they can influence Harbor status.
- **Boundary-local weak facts must not become native facts.** Expired acknowledgements and unverifiable attestations are useful process residue, not SlopOS truth.
- **Challenge is not hostility.** A disputed remediation receipt is a normal state when copies, mirrors, dashboards, generated explainers, and model/eval artifacts update on different clocks.
- **Safe public copy is still a copy.** The public status statement needs correction anchors and non-promises; it does not control every mirror, snippet, cache, or downstream copy.

## Companion pressure

- **ViewFS:** reminds Harbor that visible public status, cached object state, and source object state can diverge; status-sync receipts should treat banners/cards as copies.
- **Helm:** epoch and route-staleness habits support acknowledgement expiry, recheck horizons, and current-vs-historical posture.
- **Schell:** prompt/output provenance warns against treating generated explanations or provider-written summaries as remediation proof.
- **Ward:** reconciliation and completeness-frontier habits fit contradiction maps where some scopes are proven, some are unknown, and some are unsafe to disclose.
- **Foundry:** exactness and correction-horizon discipline warns that labels, proof posture, and interpretation can change even when numbers do not.
- **Steward:** remediation lanes and cause/condition vocabulary are tempting, but Harbor should not import a workflow engine before repeated specimens demand it.
- **SlopOS:** attestation, VEX, SBOM, status, and auth-boundary surfaces all point to the same move: imported status is a bounded claim with provenance, not a native grant or fact.

## Harbor delta

`rev0089` adds:

- `docs/00-meta/datacube-status-reconciliation-hygiene.md`;
- specimen flow 84 for disputed remediation, expired acknowledgement, contradictory external impact report, unverifiable use/non-use attestation, and public-status drift;
- status-reconciliation proof obligations in `docs/00-meta/datacube-proof-obligations.md`;
- refreshed lessons, inspiration harvest, source register, bibliography, ledgers, roadmap, briefing surfaces, manifest, and archive index.

## Deliberate non-promotion

This pass does not promote a status reconciliation schema, dispute-resolution ledger, acknowledgement-expiry rule set, impact-claim reconciliation API, use-attestation challenge registry, status-page product, legal/compliance workflow, VEX/CSAF profile, in-toto predicate, transparency-log policy, reputation system, reporter trust model, or final SlopOS datacube shape.
