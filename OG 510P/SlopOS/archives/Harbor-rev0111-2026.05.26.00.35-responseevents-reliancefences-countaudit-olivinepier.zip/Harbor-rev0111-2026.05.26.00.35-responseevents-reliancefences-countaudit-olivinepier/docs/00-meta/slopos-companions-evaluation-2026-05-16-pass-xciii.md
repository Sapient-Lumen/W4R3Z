# SlopOS and companions evaluation — pass XCIII

**Revision:** `rev0093`  
**Date:** 2026-05-16  
**Focus:** correction implementation after outside decision returns, mandated/recommended correction scopes, partial implementation, recheck windows, reopened appeals, jurisdiction/audience splits, and stale-surface monitoring.

## SlopOS pressure

SlopOS remains design-phase; that argues for implementation receipts and recheck windows as process residue instead of native correction ledgers or compliance automation.

The strongest SlopOS lessons for this pass:

- **VEX remediation selection stays non-native.** SlopOS pins remediation text and fixed status as evidence, not successor-update selection. Harbor should require implementation evidence before saying a public-copy correction happened.
- **Advisory supersession is not latest-wins truth.** SlopOS keeps VEX document version and supersession as imported evidence, not a hold/resume or replacement rule. Harbor should keep rollback, successor copy, and appeal reopening explicit.
- **Producer identity is not owner authority.** SlopOS keeps advisory producer metadata smaller than trust-root, remediation-owner, or issuer-selection semantics. Harbor should not treat a source-owner or regulator-facing decision as automatic implementer authority.
- **Evidence sets are not closure.** SlopOS keeps SBOM/VEX co-packaging from becoming a native applicability closure. Harbor should let a correction be implemented for one artifact/cut and still unknown for another jurisdiction, surface, or mirror.
- **Export remains policy-killable.** Implementation and monitoring copy must avoid leaking sealed evidence, suppressed cells, private reporter details, internal tickets, and raw replay data.

## Companion pressure

- **ViewFS:** successor public copies, stale mirrors, and visible old copies need exact artifact identity, relation, and copy-state notes.
- **Helm:** deadlines, appeal windows, recheck horizons, and monitoring intervals need explicit clock receipts rather than implicit timers.
- **Schell:** generated summaries and status copy need tethered wording so implementation evidence is not paraphrased into proof or compliance.
- **Ward:** currentness lanes keep adopted, implemented, published, propagated, monitored, rechecked, and expired states distinct.
- **Foundry:** exactness and restatement discipline keep data-change, label-change, wording-change, and status-change corrections separate.
- **Steward:** cause-condition and remediation surfaces warn that implementation evidence is not root cause, prevention, or complete repair.
- **SlopOS:** VEX/SBOM/attestation boundaries reinforce exact subjects, verifier-local appraisal, and no latest-wins remediation.

## Harbor delta

`rev0093` adds:

- `docs/00-meta/datacube-correction-implementation-monitoring.md`;
- specimen flow 88 for adopted correction work items, mandate/recommendation/deadline notes, implementation evidence, publication receipts, stale-surface notes, monitoring rechecks, reopened appeals, and jurisdiction/audience splits;
- correction-implementation monitoring proof obligations in `docs/00-meta/datacube-proof-obligations.md`;
- refreshed lessons, inspiration harvest, source register, bibliography, ledgers, roadmap, briefing surfaces, manifest, and archive index.

## Deliberate non-promotion

This pass does not promote a correction implementation ledger, deadline tracker, compliance automation, regulator workflow, remediation registry, post-decision monitoring service, public status-page product, external ticketing integration, in-toto predicate, VEX/CSAF profile, SCITT dependency, rollback protocol, jurisdiction policy engine, source-owner authority hierarchy, enforcement ladder, or final SlopOS datacube shape.
