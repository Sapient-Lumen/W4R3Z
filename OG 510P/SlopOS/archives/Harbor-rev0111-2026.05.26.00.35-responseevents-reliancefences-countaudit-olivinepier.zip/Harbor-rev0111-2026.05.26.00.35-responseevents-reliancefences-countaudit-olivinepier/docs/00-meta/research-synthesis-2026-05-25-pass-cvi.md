# Research synthesis — 2026-05-25 pass CVI

## Frame

Pass CVI studies overlapping correction epochs: the moment where retained repair evidence, derivative repair, local derivation, and source-correction history all collide. The useful outside pressure is not one standard to adopt. It is a set of neighboring disciplines that all separate versions, revisions, synchronization changes, snapshots, and references more carefully than ordinary product status copy.

## Load-bearing observations

- W3C PROV treats revision as a kind of derivation. Harbor should steal that separation: a derivative repaired under correction epoch A remains a derived entity, not the original source and not proof that later epoch B also applies.
- The Memento framework separates original resources, time gates, prior representations, and datetime negotiation. Harbor should steal the idea that old representations remain accessible evidence without becoming the current representation.
- ResourceSync separates resource lists, change lists, dumps, and incremental synchronization. Harbor should steal modular synchronization pressure while refusing to turn change delivery into repaired derivative state.
- OCI layouts separate content-addressable blobs from location-addressable references. Harbor should steal digest/ref humility: a ref can point to a new epoch without rewriting what old bytes were.

## F101 conclusions

Harbor needs explicit epoch lineage packets with correction id, epoch digest, order/clock basis, scope relation, derivative lineage edges, rebase or rollback map, currentness window, consumer state, and non-promises. The packet should be small enough to be checked by deterministic fixtures but loud enough to reject latest-wins, oldest-receipt-wins, source-owner closure, and public green badge collapse.

## Non-adoptions

Do not import PROV, Memento, ResourceSync, OCI, or any sync/versioning system as Harbor schema. The lesson is narrower: versions, revisions, changed resources, snapshots, and refs are all weaker than semantic currentness.
