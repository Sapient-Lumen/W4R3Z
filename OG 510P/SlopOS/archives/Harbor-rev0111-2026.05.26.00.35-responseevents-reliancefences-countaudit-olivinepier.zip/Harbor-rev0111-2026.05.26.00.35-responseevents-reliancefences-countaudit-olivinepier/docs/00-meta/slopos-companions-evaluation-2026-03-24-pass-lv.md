# SlopOS / companions evaluation — pass LV

This pass re-checks Harbor against SlopOS and the sibling cubes after adding a recipient-target-split / default-audience-conflict / alias-drift specimen, and again chooses one narrow crossing seam over any early family bloom.

## What the current cubes still teach
- **SlopOS** remains the strongest restraint mechanism. Its imported auth-discovery, auth-response-packaging, token-passthrough, and authorization-context seams keep upstream audience, packaging, and provider routing facts provider-local or request-local rather than portable cross-cube truth. That lines up with Harbor treating signed JWT introspection recipients, token-format audiences, and returned-resource confirmations as separate crossing residue.
- **SlopOS** also keeps reinforcing that exact local fit stays local. A broad or default audience can help route a turn, but the final protected-resource acceptance rule still belongs to the receiver and its provider-local policy.
- **Ward** still reinforces exact-basis and visible-veto posture: a token can be cryptographically plausible and still wrong here.
- **Helm** still contributes display humility: good UI can explain why a broader audience looked tempting, but display should not erase exact returned-resource confirmation or current receiver refusal.
- **Foundry** still teaches aftermath honesty: signed introspection-to-this-receiver, returned-resource-over-default precedence, and alias-family drift are all useful residue without becoming runtime or entitlement truth.
- **Steward** still teaches typed endings: when a turn bottoms out because a local alias family drifted or narrowed, the receipt should say that plainly.

## Harbor consequence
Harbor should keep this move modest:
- add one specimen around **recipient-target split**, **returned-resource-over-default-audience conflict**, and **alias-family drift note**;
- keep signed introspection recipient facts, nested token audience facts, explicit returned-resource confirmation, challenge-derived coverage, and receiver-local refusal visibly separate;
- leave any future portable alias, target-confidence, or coverage registry outside Harbor for now.

## Still-not-yet decisions
- Whether **recipient-target split** deserves its own Harbor family, or should remain only an annotation on specific signed-introspection aftermath surfaces.
- Whether **returned-resource-over-default-audience conflict** belongs in Harbor at all, or should remain only a standing interpretation rule on specific token-response specimens.
- Whether **alias-family drift note** belongs in Harbor, or should stay a typed local explanation that never blooms into a portable alias, coverage, or target-confidence registry.
