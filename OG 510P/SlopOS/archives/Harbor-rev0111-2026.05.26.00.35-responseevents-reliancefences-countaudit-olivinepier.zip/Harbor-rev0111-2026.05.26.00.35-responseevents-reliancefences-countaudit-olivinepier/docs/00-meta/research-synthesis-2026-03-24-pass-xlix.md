# Research synthesis — pass XLIX

This pass keeps Harbor narrow and learns five compatible things at once: **discovery source changes the validation rule; candidate target services are scoped hints rather than global truth; multi-target requests can broaden faster than products expect; issuance can narrow a requested set or refuse it outright; and Harbor should preserve target-negotiation residue without freezing a portable target-service registry too early.**

## Outside lessons
1. **Discovery source changes the safety rule.**  
   RFC 9728 requires exact resource-identifier matching for protected-resource metadata, while the current RFC9728bis update draft relaxes validation only for metadata obtained from `WWW-Authenticate`, allowing same-origin path-prefix matching there and keeping direct well-known retrieval on exact-match rules. Harbor should preserve a **discovery-source note** rather than flattening all routes into one generic “metadata told us so” story.

2. **Candidate target services are scoped hints, not global truth.**  
   The token-exchange target-service-discovery draft defines an authorization-server endpoint that returns token-exchange targets for a specific **subject token plus authenticated client**, and it may legitimately return an empty `supported_targets` array. Harbor should treat discovered candidates as an **authorized-candidate slate** smaller than entitlement or durable grant truth.

3. **Breadth compounds quickly.**  
   RFC 8693 allows repeated `resource` values and explains that requesting scope across multiple audience/resource targets can effectively form a Cartesian-product breadth request. Harbor should preserve a **target-negotiation rail** so multi-target ambition stays inspectable instead of dissolving into one vague success bit.

4. **Subset survival deserves typed honesty.**  
   The March 2026 resource-token-response draft says a token response may return a strict subset of requested `resource` values, may also include additional server-assigned identifiers, and should use `invalid_target` when nothing acceptable survives. Harbor should preserve a **narrowed-target subset** and a typed refusal rail rather than pretending the original ask necessarily survived intact.

5. **Grant-bounded narrowing is smaller than durable adoption.**  
   The same resource-token-response work says refresh-token and authorization-code-time resource requests can further restrict but must not expand what is authorized. Harbor should record narrowing as local negotiation residue, not as a permanent target or entitlement registry.

## Resulting Harbor move
Do not decide yet whether Harbor needs durable nouns such as **discovery-source note**, **narrowed-target subset**, or **target-negotiation rail**.
For this revision:
- add one specimen around challenge-versus-direct discovery, token-exchange target-service discovery, multi-resource request breadth, and issuance-time narrowing or typed refusal;
- preserve the difference between “where the route came from,” “which candidate targets were available for this client/token,” “what the client asked for,” “what narrower subset or refusal came back,” and “none of those facts by themselves settle durable issuer/resource/grant/account/session/adoption truth”;
- and collect **authorized-candidate slate** plus **grant-bounded narrowing floor** as inspiration only, without promoting a new registry today.

## Fresh ideas worth stealing
- **discovery-source note** — compact residue of whether this route came from exact direct metadata, relaxed challenge-derived metadata, token-exchange target-service discovery, or local configuration.
- **narrowed-target subset** — inspectable note that only part of the requested target set survived issuance.
- **target-negotiation rail** — a typed explanation path for intact acceptance, narrowed acceptance, or `invalid_target` refusal.
- **authorized-candidate slate** — future-facing reminder that discovered targets are scoped to a subject token and authenticated client, not a universal catalog.
- **grant-bounded narrowing floor** — future-facing reminder that later requests may restrict but should not silently expand what the grant already allowed.
