# Datacube property/mutation coverage

**Status:** embryo verification surface, not a schema, not a fuzzer, not a conformance suite.  
**Introduced:** `rev0098` / F093.  
**Owns:** the question "do our current executable Harbor checkers reject the failures they were written to reject?"

## Why this exists

Harbor now has three deterministic executable proof slices:

1. CrossingRecord v0 evidence bundle.
2. Transparency/provenance receipt-import bundle.
3. Verifier-disagreement / policy-epoch drift bundle.

That creates a new counterfeit: because a fixture is machine-checkable, it may look complete. It is not. A fixture can pass while its checker silently forgets a refusal. F093 therefore adds a small property/mutation meta-bundle that deliberately mutates existing bundles and records whether the existing checkers kill those mutations.

This is not stochastic fuzzing. It is deterministic mutation pressure over named invariants.

## Core split

```text
baseline bundle
→ property claim
→ named mutation operator
→ mutated bundle
→ existing bundle checker
→ killed/survived result
→ shrink note
→ coverage summary
```

The meta-bundle is evidence about checker sensitivity. It is not evidence that Harbor has a complete schema, complete test suite, complete model, or complete SlopOS datacube shape.

## Shared invariant vocabulary

The F093 harness currently uses ten invariant handles:

- `digest_binding`
- `member_alignment`
- `expected_admission_consistency`
- `non_promotion_guard`
- `accepted_subject_binding`
- `rejected_no_record_emission`
- `scope_or_binding_refusal`
- `family_specific_non_promises`
- `badge_and_currentness_refusal`
- `hostile_fixture_explainability`

These names are intentionally cross-bundle vocabulary, not shared schema fields. Each underlying bundle still owns its local member labels, case ids, digest functions, and refusal details.

## Mutation operator classes

F093 introduces four operator families:

| Family | Purpose | Examples |
|---|---|---|
| `common.*` | prove every executable bundle rejects common structural and posture failures | digest corruption, member-label insertion, case-id removal, expected/admission flip, non-promotion bit removal, rejected record emission |
| `crossing.*` | prove CrossingRecord checks still reject crossing-specific overclaims | accepted subject-digest mutation, stripped route guards, scope widening, aftermath overclaim |
| `receipt.*` | prove receipt-import checks still reject provenance-currentness overclaims | accepted subject-digest mutation, freshness upgrade, verifier decision as semantic truth, forbidden trusted outcome, aftermath overclaim |
| `disagreement.*` | prove verifier-disagreement checks still reject badge and epoch collapse | green badge, majority/latest wins, unknown currentness as fresh, missing verifier policy digest, hidden disagreement |

Every generated mutant must retain:

```text
operator name
bundle target
invariant list
baseline digest
mutant digest
checker reason
minimal shrink target
human-readable explanation obligation
```

If a mutation survives, that is not an automatic schema failure. It becomes a followthrough question: should Harbor strengthen the checker, add a hand-authored hostile fixture, or mark the mutation as intentionally equivalent/out-of-scope?

## What passed in rev0098

The F093 deterministic meta-bundle creates 38 mutations across the three existing executable bundles. Current result:

```text
mutation_count: 38
killed_count:   38
survived_count: 0
```

The most important result is not the number. The important result is that Harbor now has a repeatable place to say:

> This checker killed this class of counterfeit, under this named invariant, with this minimal mutation.

## Non-promises

The F093 bundle does not prove:

- stochastic fuzz coverage;
- complete branch or path coverage;
- complete schema coverage;
- conformance to external standards;
- semantic completeness of Harbor;
- correctness of all future generated cases;
- compatibility with SlopOS internals;
- final datacube shape.

## Promotion guard

Do not promote a generated mutation into a durable fixture unless the promotion packet states:

```text
operator id
survived or repeated hostile value
minimal reproducer
human-readable counterfeit
why existing hand-authored cases were insufficient
which checker was strengthened or deliberately not strengthened
which non-promises remain
```

F093 deliberately keeps generation smaller than Harbor's specimen discipline.
