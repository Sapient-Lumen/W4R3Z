# Datacube change classes

Purpose: keep Harbor honest that a published-lane change needs **an explicit classification and compatibility verdict** before anyone calls it additive, safe, or breaking.

Why this exists:
- Harbor is still in design phase, so it would be unhealthy to let every edit inherit one vague label like “small change” or “non-breaking”;
- schema systems repeatedly show that latest-only, backward, transitive, alias-bridged, and breaking changes are different strengths of promise;
- semantic-model systems repeatedly show that a same-name / same-type recalculation can still surprise consumers even when schema checks pass;
- Harbor therefore needs one small review surface that says **what kind of change this is** and **what sort of compatibility verdict it earned**.

This doc does **not** choose a schema registry, diff engine, warehouse format, catalog product, or version-number syntax.
It is a design-phase contract for change classification only.

## Change classes (Phase 1)

1. **Shape-additive**
   - Purpose: add a new optional field, facet, or sidecar without invalidating the existing published slice.
   - Typical examples: new nullable field, new optional facet, new derived column family that older consumers can ignore.
   - Default posture: may be safe in place if the lane’s compatibility window allows additive change.

2. **Shape-bridged**
   - Purpose: rename, split, or merge returned structure while keeping a deliberate bridge for existing consumers.
   - Typical examples: alias-backed rename, dual-projected field window, old-name compatibility view, controlled split where the old field remains temporarily available.
   - Default posture: needs an explicit **bridge window** and retirement plan; it is not the same thing as “no change.”

3. **Shape-breaking**
   - Purpose: remove, re-type, make-required, or otherwise change returned structure in a way older consumers cannot safely ignore.
   - Typical examples: non-compatible type change, requiredness increase, destructive drop, incompatible cardinality shift.
   - Default posture: requires successor version/lane or an explicit historical split; never smuggle this through as a tiny patch.

4. **Meaning-clarifying**
   - Purpose: improve documentation, labels, or explicit semantics while keeping the practical consumer meaning the same.
   - Typical examples: clearer description, explicit null-policy note, richer enum docs, bug explanation that does not change results.
   - Default posture: may be safe in place, but still deserves a recorded verdict.

5. **Meaning-reinterpreting**
   - Purpose: keep similar shape while substantially changing what values mean or how they are computed.
   - Typical examples: same-name/same-type recalculation, enum semantic drift, time-policy change, unit change, changed inclusion rule.
   - Default posture: usually requires successor version/lane, overlap, or historical freeze; passing a schema check is not enough.

6. **Assertion-only**
   - Purpose: change verification logic without changing the lane’s row meaning.
   - Typical examples: new freshness check, tighter volume threshold, extra schema check, new custom SQL assertion.
   - Default posture: may be safe if the affected contract tier says so, but must not secretly redefine meaning.

7. **Service-only**
   - Purpose: change cadence, freshness target, or support posture without changing row meaning.
   - Typical examples: refresh target change, support escalation rule, warning-threshold adjustment.
   - Default posture: needs explicit consumer notice when load-bearing, especially if tighter than before.

8. **Historical / restatement**
   - Purpose: correct or recompute already-published history.
   - Typical examples: backfill, late-arriving context repair, correction replay, frozen-history rebuild.
   - Default posture: needs a restatement receipt and a compatibility verdict about live head versus historical references.

## Compatibility verdicts (Phase 1)

Allowed verdict labels:
- **safe in place** — compatible with the lane’s current window and consumer slices as recorded;
- **safe with bridge window** — compatible only while an explicit bridge/overlap exists;
- **successor required** — publish a successor lane/version or historical split before claiming compatibility;
- **historical restatement** — requires explicit restatement/history handling even if the live head survives; and
- **no publish verdict yet** — change remains rehearsal/candidate only.

These verdicts are process discipline, not a commitment to one vendor’s compatibility checker.

## Bridge window
A bridge window is a bounded overlap period for a shape-bridged change.
It should say:
- what old and new forms coexist;
- which consumer slices still rely on the older form;
- what warning or deprecation signal exists;
- when the bridge ends; and
- what the post-bridge verdict will be.

## Shadow diff
Before publishing any non-trivial change, Harbor should prefer a **shadow diff** across the affected consumer slices:
- compare current published output to candidate output;
- separate shape diff from value diff from assertion/service diff;
- keep sampled failing rows or differing aggregates as **derived evidence**, smaller than the review surface; and
- avoid letting a green diff on one consumer slice counterfeit universal compatibility.

## Retirement reservation note
When Harbor retires a published field, value family, or facet name, it should leave a compact **retirement reservation note** before reusing that identifier in the same family.
The note is process discipline, not a fixed registry product.
Its only job is to stop accidental resurrection or semantic recycling.

## What this forbids in Phase 1
- no calling a same-name / same-type semantic rewrite “non-breaking” without an explicit verdict;
- no letting alias/default bridges masquerade as semantic sameness;
- no reusing a retired published identifier in the same family without a reservation/review note;
- no treating latest-only compatibility as if it were transitive compatibility;
- no letting assertion or service tightening sneak in under a shape-only review.

## What this still leaves open
- exact machine-readable schema for change-class cards or verdict receipts;
- exact diff engine or replay harness for shadow diffs;
- exact representation of retirement reservations;
- exact mapping from change classes to version numbers, tags, views, or semantic models.

Harbor only needs the review behavior now: **classify the change, issue a verdict, keep bridge windows explicit, and leave evidence smaller than meaning.**
