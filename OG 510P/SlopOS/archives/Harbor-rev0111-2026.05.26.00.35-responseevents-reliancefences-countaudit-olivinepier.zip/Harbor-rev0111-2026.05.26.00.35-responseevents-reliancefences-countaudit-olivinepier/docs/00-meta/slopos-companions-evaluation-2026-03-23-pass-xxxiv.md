# SlopOS / companions evaluation — pass XXXIV

This pass re-checks Harbor against the uploaded cube ecology and keeps the archive embryonic.

## What the current cubes still teach
- **SlopOS** remains the best local brake on discovery regrowth. Its adjunct-index contract keeps implementation-facing discovery surfaces closed and explicit instead of allowing wildcard inference.
- **SlopOS** is also very clear that replicated route hints and cached metadata are smaller than authority. The `caprpc-proxy-replication-boundary-v0` doc keeps replicated proxy state to owner-routed metadata only and requires consumers to fail closed when owner metadata is stale or missing.
- **SlopOS** keeps approval and precondition witnesses from turning into reusable review caches. That is the right anti-lesson for Harbor too: yesterday's fetched config is not a timeless admission badge.
- **Foundry** is an especially good sibling pressure here. Its configuration-layer and overlay-gate posture shows how raw config, detachable overlays, and admitted realization can stay visibly different.
- **Steward** reinforces the same point with discovery-truth and lease-chip humility: adverts and remembered descriptors can shape behavior while remaining smaller than current readiness/authority.

## Harbor consequence
Harbor should keep discovery/config nouns provisional.
The right near-term move is small:
- add one specimen around `discovery card`, `cache epoch`, `overlay witness`, and `admission truth`;
- keep fetched and resolved config visibly smaller than manifest ceilings, provider/browser-local status, and durable local adoption;
- and let stronger siblings own portable config registries, trust-chain services, or long-lived capability/discovery catalogs.

## Still-not-yet decisions
- Whether `discovery card` deserves its own first-class card or remains an exact field inside route/admission surfaces.
- Whether `overlay witness` is Harbor-owned residue or merely an explanation chip on top of route/refinement material.
- Whether `cache epoch` should become a first-class object, or whether it belongs only as provenance on fetched route/config residue.
