# SlopOS companions evaluation — 2026-05-23 pass CII

## SlopOS seam

SlopOS portal and callback evidence can say that a route was accepted or resumed, but not that the returned material was trusted, understood, or imported correctly. F097 mirrors that discipline for release artifacts: a portal/callback success or upload event becomes route evidence only, and material identity still needs a post-handoff check.

## Companion borrowings

- From SlopOS: accepted-only durability and no hidden suffix. Harbor applies this to handoff by refusing hidden generated artifacts and digest-scope mismatches.
- From ViewFS: trusted paths and consent fences. Harbor records file-library uploads and user-visible locators without treating them as currentness or identity.
- From Schell: copied helpers and retained artifacts need context. Harbor accepts copied fixture files only with parent bundle/checker context.
- From Helm: route repair and intervention traces. A renamed archive can be repaired by bytes verification, but not by name.
- From Foundry: classification pins. Handoff cases pin release zip, extracted tree, fixture file, pasted digest, upload, callback, and repack as distinct classes.
- From Steward and Ward: acknowledgement/delegation limits. Consumer acknowledgement can explain process state but cannot mutate a failed import check into success.

## What changed in Harbor

F097 adds an artifact handoff / consumer import bundle, harness, checker, fixture, verification document, specimen, and meta surface. The checker rejects filename-only, pasted-digest-only, callback-only, upload-timestamp, wrong-digest-scope, stale/missing-context, repack-mismatch, hidden-extra-artifact, and acknowledgement-overclaim cases.

## Next companion pressure

F098 should test local consumer derivations: annotations, summaries, extracted subsets, regenerated indexes, local cache state, re-exported archives, and cross-device sync after import.
