# SlopOS and companions evaluation — pass XC

**Revision:** `rev0090`  
**Date:** 2026-05-15  
**Focus:** recurring stale-copy regressions, serial acknowledgement expiry, repeated unverifiable attestations, mixed-accuracy reporters, escalation/cooldown, warning sunset, and public-log/status divergence.

## SlopOS pressure

SlopOS remains design-phase; that argues for small recurrence receipts instead of a reputation subsystem.

The strongest SlopOS lessons for this pass:

- **Status inputs are local evidence, not ambient truth.** SlopOS attestation collateral boundaries keep certificate status, CRLs/OCSP, TCB info, identity blobs, and cache snapshots explicit and verifier-local. Harbor should do the same for public status, warnings, and recurrence evidence.
- **Multiple evidence artifacts do not create closure.** SlopOS SBOM/VEX evidence-set boundaries refuse to treat adjacent artifacts as one applicability closure. Harbor should not treat repeated acknowledgements, public log entries, or reporter notes as one truth closure.
- **Ordering is explicit or absent.** SlopOS foreign-cell adapter commutativity says receipts can commute unless an ordering witness exists. Harbor recurrence windows need explicit observed windows instead of folklore sequence.
- **Boundary-local weak facts stay weak.** Imported status, non-use claims, old public logs, and reporter notes should remain digest-bound and window-bound.
- **Reputation is too big for the seam.** The design-phase answer is claim-family limitation and standing challenge, not actor scoring.

## Companion pressure

- **ViewFS:** warns that visible copy state, cached state, and source object state can diverge repeatedly; recurrence receipts should name target and view/copy class.
- **Helm:** epoch and route-staleness habits support expiry windows, clean observation windows, and cooldown criteria.
- **Schell:** prompt/output provenance warns that generated explanations and reporter summaries may be useful but must not become verifier evidence.
- **Ward:** frontier/completeness discipline supports standing challenges and unresolved-recurring states when some windows are observed and others are missing.
- **Foundry:** exactness/correction-horizon discipline supports warning sunset only after digest/label/currentness checks, not after vibes.
- **Steward:** remediation and cause/condition surfaces are tempting, but Harbor should not import a workflow engine, incident manager, or enforcement ladder yet.
- **SlopOS:** attestation/SBOM/VEX/update/status boundaries reinforce subject-bound evidence and verifier-local interpretation.

## Harbor delta

`rev0090` adds:

- `docs/00-meta/datacube-recurrence-escalation-hygiene.md`;
- specimen flow 85 for recurrence, regression, serial acknowledgement expiry, repeated unverifiable claims, mixed-accuracy reporter claims, escalation/cooldown/sunset, and public-log/status divergence;
- recurrence/escalation proof obligations in `docs/00-meta/datacube-proof-obligations.md`;
- refreshed lessons, inspiration harvest, source register, bibliography, ledgers, roadmap, briefing surfaces, manifest, and archive index.

## Deliberate non-promotion

This pass does not promote a recurrence ledger, reliability note, reporter-confidence label, escalation trigger, status-sunset rule, standing-challenge registry, public warning API, external escalation workflow, regulator/auditor packet, PSIRT/CSIRT program, status-page product, compliance workflow, transparency-log policy, reputation model, enforcement ladder, or final SlopOS datacube shape.
