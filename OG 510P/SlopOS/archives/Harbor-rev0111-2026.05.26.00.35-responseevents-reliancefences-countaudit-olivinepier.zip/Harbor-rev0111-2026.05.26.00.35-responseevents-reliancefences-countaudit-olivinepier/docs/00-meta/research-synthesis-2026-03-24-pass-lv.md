# Research synthesis — pass LV

This pass keeps Harbor narrow and learns five compatible things at once: **a JWT-secured introspection response is signed to one exact recipient protected resource, while the nested token metadata can still talk about different target-like identifiers; default or mapped token audiences remain weaker client-facing facts than an explicit returned `resource`; protected-resource metadata and alias families can broaden or drift operationally without proving current receiver fit; resource servers and authorization servers are allowed to answer differently for different receivers; and Harbor should preserve those differences without freezing a portable target-confidence or alias registry too early.**

## Outside lessons
1. **Signed JWT introspection has an exact recipient that is not the whole target story.**  
   RFC 9701 says the top-level `aud` of a JWT-secured introspection response must identify the resource server receiving that response, while the actual introspection members live under a separate `token_introspection` claim to prevent conflict and confusion with top-level JWT claims. Harbor should preserve a **recipient-target split** instead of flattening signed recipient provenance and token target metadata into one counterfeit target object.

2. **Introspection is still specific to the calling protected resource.**  
   RFC 7662 defines an active token in part as one that is valid for use at the protected resource making the introspection call, says the authorization server may respond differently to different protected resources, and says the server must determine whether a token can be used at the resource server making the call. Harbor should therefore treat introspection as receiver-scoped evidence, not portable client certainty.

3. **Default or mapped audiences are real and still smaller than explicit returned-resource confirmation.**  
   RFC 8707 says an authorization server may use the exact `resource` value as audience or map it to a more general URI or abstract identifier, and may also process a request with a predefined default resource when the client omits `resource`. RFC 9068 then says that if the request does not include a `resource` parameter, the authorization server must use a default resource indicator in the JWT access-token `aud` claim. Harbor should therefore keep **returned-resource-over-default-audience conflict** visible instead of pretending every audience cue is exact client-facing confirmation.

4. **Explicit returned `resource` is still the stronger client-facing target fact.**  
   The March 2026 resource-token-response draft says clients cannot rely on audience information from introspection or local token inspection to determine exact protected-resource applicability. It says returning `resource` in the token response is more useful to a client than returning audience or scope information, and when no resource was requested, the authorization server may return server-assigned resource values or omit `resource` entirely, in which case the token is not resource-specific in the sense of the draft. Harbor should therefore preserve **response-over-token precedence** even when a token carries a plausible default audience.

5. **Alias-family drift should end visibly, not flatter the token.**  
   RFC 9728bis relaxes validation only for metadata obtained via `WWW-Authenticate`, allowing same-origin path-prefix coverage for challenge-derived protected-resource metadata. RFC 9068 still requires the current resource server to reject a JWT access token if its `aud` does not contain an identifier the resource server expects for itself. Harbor should therefore preserve **alias-family drift notes** as typed receiver-local endings rather than as generic invalid-token folklore.

## Resulting Harbor move
Do not decide yet whether Harbor needs durable nouns such as **recipient-target split**, **returned-resource-over-default-audience conflict**, or **alias-family drift note**.
For this revision:
- add one specimen where a JWT-secured introspection response is signed to one exact receiver while the nested token metadata remains broader or differently named;
- keep the difference between default or mapped token audience, explicit returned `resource` confirmation, and current receiver fit visible all the way to the end; and
- collect receiver-scoped disclosure and stronger-here challenge ideas for later, without promoting a new registry today.

## Fresh ideas worth stealing
- **recipient-target split** — compact residue that signed introspection recipient provenance and nested token target metadata are different facts.
- **returned-resource-over-default-audience conflict** — compact reminder that explicit returned `resource` can outrank broad or default `aud` cues for client-side exactness.
- **alias-family drift note** — typed ending that says the current receiver family or local accepted alias set drifted away from what the broad/default cue seemed to suggest.
- **receiver-scoped disclosure lens** — future-facing reminder that introspection and returned scope may legitimately differ by receiver.
- **signed-but-still-not-exact-resource** — anti-regrowth rule for cryptographically strong but semantically modest target evidence.
