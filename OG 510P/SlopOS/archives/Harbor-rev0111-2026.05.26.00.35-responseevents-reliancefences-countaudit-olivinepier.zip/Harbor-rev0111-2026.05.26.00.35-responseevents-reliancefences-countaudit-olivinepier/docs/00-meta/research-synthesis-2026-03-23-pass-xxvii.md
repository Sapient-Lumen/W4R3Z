# Research synthesis — pass XXVII

This pass keeps Harbor narrow and learns one more thing from continuous security-event systems: **later attenuation signals should narrow continuity without pretending to be commands, durable session truth, or a portable live watch plane.**

## Outside lessons
1. **Security events are statements of fact, not commands.**  
   RFC 8417 defines Security Event Tokens (SETs) as statements of fact from the perspective of the issuer about a subject. It is explicit that recipients validate and interpret received SETs and then take their own independent actions, if any. Harbor should steal that restraint directly.

2. **The Shared Signals Framework gives those facts a typed subject vocabulary instead of one universal session string.**  
   SSF 1.0 requires a top-level `sub_id` and allows both simple and complex subject descriptions. Complex subjects can include `user`, `device`, `session`, `application`, `tenant`, and more. Harbor should learn from that without rushing into a universal subject-braid object of its own.

3. **CAEP now standardizes multiple kinds of later auth/session drift.**  
   CAEP 1.0 final defines event types including `session-revoked`, `token-claims-change`, `credential-change`, `assurance-level-change`, `device-compliance-change`, `session-established`, `session-presented`, and `risk-level-change`. The important Harbor lesson is not the full catalog; it is that later change is typed and may either narrow or strengthen local posture without rewriting the original crossing.

4. **CAEP also preserves provenance about why and when the drift happened.**  
   Optional claims such as `event_timestamp`, `initiating_entity`, `reason_admin`, and `reason_user` make later attenuation or recovery legible without pretending the receiver must adopt one universal outcome. That is a great pattern for Harbor explanation surfaces.

5. **Delivery rails are smaller than current authority truth.**  
   RFC 8935 and RFC 8936 separate push and poll delivery mechanics from the meaning of the event itself, and RFC 8936 even distinguishes poll-only, acknowledge-only, and combined acknowledge-and-poll behavior. Harbor should therefore resist inventing a generic live stream/session oracle out of event delivery posture.

6. **Ward already learned the trust-side version of this lesson.**  
   The uploaded Ward cube keeps attenuation events and receiver stance visibly separate from durable spend truth. Harbor can borrow that shape on the exchange side: a later signal may demote continuity, require revalidation, or cold-start the next crossing without erasing the fact that an earlier crossing once succeeded.

## Resulting Harbor move
Do not decide yet whether the durable nouns are exactly `attenuation notice`, `receiver stance`, `revalidation floor`, and `signal drift honesty`, or whether later pressure compresses some of them behind a smaller continuous-attenuation family.
For now, keep them alive as specimen nouns and demand that they improve:
- one CAEP specimen where a later `session-revoked` or `risk-level-change` event narrows previously smooth continuity;
- one SET/SSF specimen where delivery succeeds but the receiver still chooses its own local consequence;
- and one shell/product specimen where the next visible posture becomes revalidation or cold-start instead of generic failure or counterfeit live-session truth.

## Fresh ideas worth stealing
- **attenuation notice** — typed outside signal that continuity, risk, or session posture has changed.
- **receiver stance** — explicit local keep/narrow/revalidate/cold-start response after interpreting a notice.
- **revalidation floor** — the next required posture once silent continuity is no longer honest.
- **signal drift honesty** — rule that later signals may narrow earlier continuity without rewriting the past crossing into fiction.
- **event notice smaller than command** — a standing anti-regrowth rule.
