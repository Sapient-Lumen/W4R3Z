# SlopOS / companions evaluation — pass XXXVII

This pass re-checks Harbor against the uploaded cube ecology and keeps the archive embryonic.

## What the current cubes still teach
- **SlopOS** already pins the strongest anti-regrowth rule in `identity-claim-export-boundary-v0.md`: explicit local login or credential mediation does not create a portable subject/email/profile/account-identity export seam. That strongly supports a Harbor move that keeps requested facts, released facts, and local account adoption visibly separate.
- **SlopOS** also keeps nearby auth surfaces small in `login-state-export-boundary-v0.md` and `auth-result-export-boundary-v0.md`, which reinforces the idea that returned fields or profile bundles should not silently turn into session/account truth.
- **Helm** remains the best sibling reminder that user-facing cards and chooser chrome are allowed to be truthful without becoming substrate authority. That makes it a good neighbor for display-facing account/profile bundles.
- **ViewFS** still rewards exact basis versus applied consequence. That is useful here too: a released bundle or source witness can inform local decisions without becoming the local decision.

## Harbor consequence
Harbor should keep claim/provenance nouns provisional.
The right near-term move is small:
- add one specimen around `claim ask`, `release bundle`, `source witness`, and `not-adopted-here honesty`;
- keep requested facts, returned bundles, and local account/profile adoption visibly separate;
- and let SlopOS or future identity-specific seams own any portable profile, verified-attribute, or adopted-account registries if those ever become necessary.

## Still-not-yet decisions
- Whether `release bundle` deserves its own first-class card or belongs as one field on a broader aftermath receipt.
- Whether `source witness` should stay generic across OIDC/FedCM/WebAuthn display surfaces or later split into narrower provenance chips.
- Whether Harbor should ever name particular profile fields directly, or keep field sets opaque and typed only by request/release/provenance posture.
