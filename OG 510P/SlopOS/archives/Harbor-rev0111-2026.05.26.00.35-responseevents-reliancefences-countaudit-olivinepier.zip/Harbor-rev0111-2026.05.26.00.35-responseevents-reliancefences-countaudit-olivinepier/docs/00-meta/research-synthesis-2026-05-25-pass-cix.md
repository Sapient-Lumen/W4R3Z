# Research synthesis — 2026-05-25 pass CIX

## Focus

Revocation-overlay propagation across public copies, mirrors, generated
summaries, consumer notices, local indexes, and warning cards.

## External pressure

- Linked Data Notifications pressures Harbor to separate message delivery
  from recipient retrieval, interpretation, or application.
- Web Annotation pressures Harbor to keep body, target, state, and provenance
  separate, so an overlay annotation cannot rewrite target authority.
- RFC 9457 Problem Details pressures Harbor to carry machine-readable failure
  reasons without treating a reason object as workflow closure.
- ResourceSync change lists pressure Harbor to treat change propagation and
  inventory/update announcements as change facts, not proof that every
  destination has synchronized or repaired.
- Memento-style time/version thinking continues to pressure Harbor to keep
  prior representations and current representations separate.

## Harbor consequence

Public overlay propagation needs a record of source digest, target surface,
reached/unreached surfaces, display wording, notice status, index/warning
state, and prior-history linkage.  The record must refuse green/red badges,
compliance claims, prior-falsity banners, mirror/search truth, delivery-as-read,
warning sunset without scope, sealed-public-truth collapse, majority-vote
overlay verdicts, and automatic downstream repair.

## Audit/refactor consequence

Bundle helper routines are now centralized in `harbor_bundle_common.py`, and a
bundle-common audit checks fixture metadata and generated-bytecode absence.
This reduces checker dialect drift without promoting a shared schema.
