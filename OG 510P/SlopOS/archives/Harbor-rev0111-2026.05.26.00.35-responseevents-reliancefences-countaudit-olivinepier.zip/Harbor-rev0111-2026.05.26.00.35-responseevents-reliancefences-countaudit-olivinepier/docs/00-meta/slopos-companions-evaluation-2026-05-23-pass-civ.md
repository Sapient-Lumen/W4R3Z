# SlopOS companion evaluation — 2026-05-23 pass CIV

## Harbor / SlopOS boundary

SlopOS can provide portal, callback, append, checkpoint/resume, truncation, and materialization evidence. F099 uses that style without importing SlopOS internals: a correction propagation event may have a route receipt, but Harbor still asks whether the derivative material was invalidated, rebuilt, revalidated, quarantined, or merely acknowledged.

## What Harbor should ask SlopOS for later

- post-import invalidation event ids that can be referenced without becoming cache authority;
- append/resume histories that say which local derivative was based on which source digest;
- notification/callback delivery receipts that explicitly refuse read/application status;
- portal/file-transfer receipts that can bind the material checked after repair;
- replay traces that show whether a stale generated explanation was rebuilt or just redisplayed;
- device/sync route facts that remain smaller than sync-state truth.

## What Harbor must refuse

- portal or callback success as derivative repair;
- notification delivery as user read or application;
- broadcast success as all derivatives reached;
- sync-provider green as byte-digest verification;
- consumer acknowledgement as repair, reliance, security, or compliance;
- local patch as upstream source repair;
- one derivative repair as global downstream closure.

## Companion note

ViewFS remains relevant for trusted-path/materialization distinctions, Schell for retention and forgetting of stale repair receipts, Helm for intervention/repair traces, Steward for acknowledgement/retry pressure, and Ward when consumer repair starts resembling delegated obligation or escalation.
