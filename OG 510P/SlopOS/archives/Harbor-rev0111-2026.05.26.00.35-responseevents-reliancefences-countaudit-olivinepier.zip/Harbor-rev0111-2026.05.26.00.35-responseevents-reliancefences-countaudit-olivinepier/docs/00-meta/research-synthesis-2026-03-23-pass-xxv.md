# Research synthesis — pass XXV

This pass keeps Harbor narrow and learns one more thing from sign-out, disconnect, and credential-cleanup systems: **a logout/reset gesture is a real typed crossing, but it is still smaller than “every layer forgot everything.”**

## Outside lessons
1. **OIDC RP-initiated logout is a request, not magic universal state erasure.**  
   An RP can ask an OP to log the user out and optionally redirect back afterward, but the OP may need to ask the user to confirm logout when `id_token_hint` is absent or mismatched. The request is intentionally idempotent, which is excellent Harbor precedent: a logout request can be real even when the OP does not currently consider the user logged in there.

2. **Credential Management gives sign-out a specific silent-suppression lever.**  
   `navigator.credentials.preventSilentAccess()` is explicitly meant as a signal that the origin signed the user out. It sets a flag so credentials will not be handed back automatically on the next visit. That is a powerful pattern for Harbor: the next turn can be colder without Harbor claiming universal account/session deletion.

3. **FedCM keeps browser memory explicit and resettable.**  
   FedCM maintains a connected-accounts set and a login-status map. The disconnect endpoint exists so a previously made federated-login connection can be removed from the user agent’s connected-accounts set, and IDPs can set login status to `logged-out`. This is exactly the kind of browser-owned memory Harbor should record as a resettable layer, not as portable system truth.

4. **WebAuthn Level 3 normalizes post-auth cleanup signals.**  
   `signalUnknownCredential()` tells the client a credential ID is no longer recognized, while `signalAllAcceptedCredentials()` and `signalCurrentUserDetails()` help refresh authenticator-side state. Those are wonderful Harbor precedents because they are maintenance/update signals, not fresh login truth.

5. **Cleanup can be partial, delayed, and still worth modeling.**  
   FedCM clears login-status and connected-account state when browsing data is cleared. WebAuthn notes that authenticators might not be attached when cleanup signals are sent, so relying parties may rerun them later. Harbor should therefore preserve *residual-memory honesty*: a reset signal can be successful and still not prove that every remembering layer is already clean.

## Resulting Harbor move
Do not decide yet whether the durable nouns are exactly `disconnect pulse`, `memory reset`, `cold-start floor`, and `residual-memory honesty`, or whether later pressure will compress them into a smaller post-logout vocabulary.
For now, keep them alive as specimen nouns and demand that they improve:
- one OIDC RP-initiated logout specimen where the OP may still ask the user to confirm logout and where post-logout redirection is bounded;
- one FedCM / Credential Management specimen where disconnect or silent-suppression makes the next visit start colder without proving universal logout;
- and one WebAuthn cleanup specimen where stale credential knowledge is pushed back to the authenticator without minting new selected-account truth.

## Fresh ideas worth stealing
- **disconnect pulse** — typed request that a layer should sever or demote a remembered relation.
- **memory reset** — layer-local removal, suppression, or refresh of remembered candidates or connected-account state.
- **cold-start floor** — next return must re-enter chooser/login/reauth posture instead of piggybacking on stale continuity folklore.
- **residual-memory honesty** — rule that reset in one layer does not prove every layer forgot.
- **cleanup smaller than logout** — a standing anti-regrowth rule.
