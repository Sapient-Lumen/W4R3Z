# Research synthesis — 2026-05-13 pass LXXVIII

Question: after adding proof obligations, how should Harbor pressure-test semantic-front-door exports, public contract subsets, freshness thresholds, join/fanout safety, and optional row-lineage sidecars without choosing a semantic layer, BI product, warehouse, lakehouse, row-ID constitution, or governance stack?

## Result of this pass
The strongest next move is to treat a semantic-front-door export as a **derived review lens with a refusal surface**.

Harbor should be able to publish a small, consumer-facing export that says “these dimensions, measures, metrics, joins, freshness thresholds, and assertion subsets are safe to ask here.” That is not the same as saying the semantic layer owns row truth, that every assertion is public, that every join is safe, or that row-lineage metadata creates universal identity.

Pass LXXVIII therefore adds one process surface, `docs/00-meta/datacube-semantic-export-constraints.md`, and one specimen, `docs/30-architecture/specimen-flow-73-semantic-export-contract-subset-fanout-sidecar-honesty.md`. The new surface is a checklist and anti-counterfeit guide, not a schema, ADR, product choice, or API.

## External lessons folded into this pass
1. **Semantic layers are useful precisely because they narrow questions.** dbt's Semantic Layer / MetricFlow pattern centralizes metrics and lets tooling generate joins, but the strongest lesson for Harbor is refusal: covered questions can be deterministic, uncovered questions should fail or route to review rather than guessing.

2. **Entity and join graphs are not magic.** dbt join logic names fan-out and chasm joins as failure modes and restricts them; Looker's relationship parameter asks modelers to state cardinality so symmetric aggregates can be invoked judiciously; Cube's join relationship vocabulary shows the same small shape from another ecosystem. Harbor should steal the explicit relationship note and fanout refusal, not the product stack.

3. **Contract subsets are safer than whole-world promises.** DataHub-style assertions and data contracts show that schema, freshness, volume, field, SQL, and other checks can verify a contract, but one public surface should publish only the assertions and freshness thresholds it means to expose. The rest can remain private evidence, internal checks, or not observed.

4. **Freshness is a calculation with a basis.** A public “fresh” badge needs a source cut, observed/published cut, threshold, age calculation, and evidence grade. It cannot mean both live-head currentness and replayable historical exactness unless the proof packet says so.

5. **Sidecars must remain optional evidence.** OpenLineage facets are atomic metadata extensions with names and schemas; Iceberg statistics files are informational and readers can ignore them; Puffin blobs can store indexes/statistics that manifests cannot. Harbor should use this sidecar posture for row lineage, statistics, facets, and sketches: helpful when present, survivable when absent, never a silent contract upgrade.

6. **Row lineage is scoped and caveated.** Iceberg v3 row lineage is powerful, but its own spec names inheritance, upgraded-table null behavior, and equality-delete limitations. Harbor should not let any `_row_id`-like field become a universal person/account/object identity. The sidecar can answer “which source row family was traced at this cut?” not “what is the true global row?”

7. **SlopOS already knows not to export ambient dumps.** CH-OBSPOL-style allowlists and data-contract migration gates reinforce the Harbor rule: a semantic export names what leaves, how it was cut, what it promises, and how rollback/restatement works. It does not become a full diagnostic dump, mutable-data rollback guarantee, or authority plane.

## New process shape
`docs/00-meta/datacube-semantic-export-constraints.md` reserves five proof terms as process vocabulary:

- semantic export receipt;
- contract subset;
- freshness basis witness;
- join-relationship note / fanout fence; and
- optional row-lineage sidecar.

None is promoted as durable schema. Each is a review handle for the specimen and for future revisions.

## Specimen selected
Specimen flow 73 models a small public “daily provider funnel” export over callback-attempt facts. It includes:

- a derived semantic export receipt that owns no data;
- a public contract subset that exposes only selected shape, metric, assertion, and freshness promises;
- a freshness basis with source cut, published cut, threshold, and age calculation;
- a many-to-one provider-dimension join that is allowed;
- a one-to-many claims join that is refused for aggregate metrics because it causes fanout;
- an optional partial row-lineage sidecar that helps trace rows but cannot act as a join key, subject identity, or contract strengthener; and
- explicit refusal cases for arbitrary drilldown, latest-live-head claims, per-person identity, and claim-scope aggregate questions that lack a safe base grain.

## Still not decided
- one semantic layer, metric engine, BI tool, warehouse, lakehouse, catalog, or query dialect;
- one public-contract schema or assertion DSL;
- one row-lineage implementation or universal row identity;
- one sidecar/facet/statistics registry;
- whether semantic export receipts become first-class Harbor cards; or
- whether SlopOS's eventual datacube should expose a semantic front door at all.

The deeper lesson is: **semantic exports should advertise safe questions and honest refusals. They should not counterfeit source truth, all assertions, all joins, or universal row identity.**
