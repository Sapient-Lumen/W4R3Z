# SlopOS and companions evaluation — pass LXXXVII

**Revision:** `rev0087`  
**Date:** 2026-05-15  
**Focus:** correction propagation, stale snippets, cached generated explainers, downstream training/evaluation copies, and unreachable mirrors after Harbor has a valid source correction anchor.

## SlopOS pressure

SlopOS remains in design phase. That argues for a reversible propagation surface rather than an indexing, catalog, or crawler subsystem.

The strongest SlopOS lessons for this pass:

- **Cache hints are not authority.** SlopOS's cache-topology authority boundary keeps cache facts as placement hints, not trust or admission truth. Harbor should similarly treat caches/search snippets as downstream currentness claims, not source truth.
- **Provenance breadcrumbs do not grant refresh.** SlopOS's import-to-docref provenance boundary explicitly avoids implicit restore, re-fetch, or refresh from provenance metadata. Harbor should record that a mirror saw a correction without giving that mirror recursive fetch authority.
- **LLM/tool requests cannot define trusted truth.** SlopOS's LLM/elicitation boundary keeps remote tool text smaller than trusted UI and local authority. Harbor should invalidate generated explanations when source labels change rather than letting agent prose define current truth.
- **Digest-bound provenance is evidence, not a registry.** SlopOS CH-PROV is deliberately smaller than release-registry or recursive-query semantics. Harbor's propagation receipts should remain digest/status evidence, not a global registry.
- **Crawl/search/training lanes differ.** SlopOS's broad boundary posture favors separating search visibility, training use, web crawl, generated answer, and local source truth instead of one crawl-policy badge.

## Companion pressure

- **ViewFS:** committed objects, access propagation, public cache copies, cache trails, live facets, and receipts are explicitly separate seams. This is the direct sibling pattern for Harbor's source-fixed/world-stale split.
- **Helm:** epoch stamps and stale fences say whether older review/watch/coverage posture still binds current footing. Harbor should borrow stale-fence language for snippets, agents, and mirrors.
- **Schell:** history correction, undo, safe retry, prompt provenance, and provider-sidecar humility warn that history, correction proposals, provider-local status, and current truth must not collapse.
- **Ward:** completeness frontiers and correction lineage keep provisional answers, late corrections, current winners, raw history, and delete-aware history visibly distinct.
- **Foundry:** exactness class and correction horizon keep “currently shown” smaller than “forever final,” especially when late corrections can restate a value.
- **Steward:** external source locks and remediation lanes support a future impact/remediation pass without turning this revision into an incident manager.

## Harbor delta

`rev0087` adds:

- `docs/00-meta/datacube-correction-propagation-hygiene.md`;
- specimen flow 82 for catalog propagation, stale search snippets, cache invalidation, generated explainer invalidation, retrieval-index refresh, stale training/evaluation copy notices, and unreachable mirror warnings;
- correction-propagation proof obligations in `docs/00-meta/datacube-proof-obligations.md`;
- refreshed lessons, inspiration harvest, source register, bibliography, ledgers, roadmap, and briefing surfaces.

## Deliberate non-promotion

This pass does not promote a CDN/cache layer, crawler policy, sitemap/IndexNow integration, Search Console workflow, public catalog, catalog vocabulary, mirror-validation service, agent-memory system, retrieval index, training-data unlearning process, eval governance program, takedown workflow, public status API, or final SlopOS datacube shape.
