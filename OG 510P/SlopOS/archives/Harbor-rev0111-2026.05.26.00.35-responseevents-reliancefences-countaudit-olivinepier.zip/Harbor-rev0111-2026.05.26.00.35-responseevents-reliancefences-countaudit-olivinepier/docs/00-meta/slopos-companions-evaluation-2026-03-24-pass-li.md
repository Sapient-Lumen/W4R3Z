# SlopOS / companions evaluation — pass LI

This pass re-checks Harbor against SlopOS and the sibling cubes after adding an assigned-only-lane / requested-anchor-minimum specimen, and again chooses one narrow crossing seam over any early family bloom.

## What the current cubes still teach
- **SlopOS** remains the strongest restraint mechanism. Its provider-local auth-result, authorization-context, and import-boundary cuts already keep discovered routing, provider-owned auth state, and portable export semantics separate. That lines up with Harbor treating missing or weaker resource confirmation as crossing residue rather than as a portable entitlement registry.
- **SlopOS** also keeps teaching the same design-phase lesson: preconfigured local knowledge can matter without blooming into universal truth. Harbor should borrow that humility directly for resource-confirmation floors and omission grace.
- **Ward** keeps reinforcing exact-basis and typed-veto posture: if a returned resource set contains none of the requested anchors, the answer should be an explicit local discard or refusal before any stronger consequence talk.
- **Helm** keeps contributing subset and miss honesty: the right answer can be “partly confirmed,” “not confirmed,” or “missed the anchor,” and those are still useful receipts smaller than durable truth.
- **Foundry** keeps the aftermath lesson alive: foreign-issued artifacts can arrive with usable but weaker confirmation status and still remain visibly weaker than adopted runtime authority.
- **Steward** keeps the accountability lesson alive: if the current turn bottomed out in weaker confirmation or a requested-anchor mismatch, the system should write that down instead of flattering it into a silent success.

## Harbor consequence
Harbor should keep this move modest:
- add one specimen around **assigned-only lane**, **requested-anchor minimum**, and **resource-confirmation floor**;
- keep discovery source, explicit request, issuance-time returned resource set, assigned-only or unbounded omission, and local discard posture visibly separate;
- collect **preconfigured-omission grace** and **strict-discovery discard** as inspiration only;
- and leave any future portable target-confirmation or entitlement registry outside Harbor for now.

## Still-not-yet decisions
- Whether **assigned-only lane** deserves its own Harbor family, or should remain only an annotation on request and aftermath surfaces.
- Whether **requested-anchor minimum** belongs in Harbor at all, or should remain only a client-validation note attached to specific token-response specimens.
- Whether **resource-confirmation floor** belongs in Harbor, or should stay a typed local explanation that never blooms into a portable entitlement or target-confirmation registry.
