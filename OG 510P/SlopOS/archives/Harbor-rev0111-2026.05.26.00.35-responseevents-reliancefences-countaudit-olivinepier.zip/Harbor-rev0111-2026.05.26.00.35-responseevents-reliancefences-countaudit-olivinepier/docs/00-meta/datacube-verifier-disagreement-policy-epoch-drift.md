# Datacube verifier disagreement and policy-epoch drift

**Revision:** `rev0097`  
**Status:** F092 design and verification surface; not a verifier arbitration schema, policy-drift ledger, public badge semantics, reliance API, compliance workflow, legal-status resolver, transparency-log reliance policy, C2PA/SLSA/in-toto/SCITT profile, issuer-reputation model, or final SlopOS datacube shape.

## Why this exists

F091 taught Harbor to import transparency and provenance receipts without turning them into truth, freshness, or closure. F092 adds the next pressure: more than one verifier may examine the same receipt bundle and disagree because they use different policy epochs, trust roots, issuer status feeds, currentness checks, scopes, or disclosure lanes.

The new rule is:

```text
verifier result < verifier result set < policy-epoch comparison < currentness posture < public badge posture
```

No edge may be inferred. A verifier pass is not a badge. A verifier refusal is not global failure. A newer policy is not retroactive erasure. A majority of passes is not authority. Unknown currentness is not freshness.

## Disagreement classes

F092 keeps these disagreement classes distinct:

| class | Harbor may record | Harbor must not infer |
|---|---|---|
| `accept_refuse_split` | one verifier accepted and another refused under named inputs | green badge, red badge, majority truth, compliance |
| `accepted_plus_currentness_unknown` | receipt evidence passed one check while currentness is unestablished | fresh-now, safe-to-rely, warning sunset |
| `policy_drift_after_public_copy` | a public copy was made under one policy and a later policy changes the result | memory-hole, retroactive wrongdoing, automatic rollback |
| `timestamp_then_issuer_status_change` | timestamp evidence predates a later issuer/key/compromise status change | automatic truth, automatic falsity, clean-since-compromise |
| `incomparable_bases` | sealed/public or selected/full-evidence verifiers are not comparable | forced arbitration, disclosure entitlement, one public verdict |
| `scope_split` | local/audience-specific pass and broader-scope refusal both stand | global status, all-mirror status, all-agent status |
| `majority_without_authority` | multiple verifiers have numerical disagreement | majority-wins without authority/scope proof |

## Required split

A verifier-disagreement record is still embryo-stage. It exists only inside the F092 fixture, but future specimens must preserve this split:

```text
subject: artifact/copy/bundle under review, including digest and scope
receipt_set: receipt digests and families feeding the verifier runs
verifiers: each verifier run digest, policy id, policy digest, policy epoch, input digest, decision, currentness basis, and no-semantic-truth bit
policy_epochs: whether epochs are same, mixed, newer-after-copy, superseded, issuer-status-after-timestamp, incomparable, or unknown
disagreement: class, preserved verifier count, and explicit majority/latest-wins refusal
currentness: whether currentness is bounded, unknown, checkpoint-only, recheck-required, selected-claim-only, or scope-bound
public_status: badge posture and visible disagreement wording
aftermath: recheck window and rollback/reopen triggers
```

The record is a membrane artifact, not an arbitration tribunal.

## Badge postures

Harbor allows only narrow public badge postures in this seam:

- `badge_withheld` — useful evidence exists, but public badge would overclaim;
- `split_status` — disagreement is displayed as disagreement;
- `scoped_pass_with_disclosure` — a pass is shown only with its audience/surface limits;
- `recheck_required` — issuer, currentness, or policy state requires re-evaluation;
- `prior_epoch_retained_with_notice` — historical public-copy basis remains visible while new policy is pending;
- `incomparable_review` — the bases are not comparable enough for one status;
- `no_public_badge` — no badge should be emitted.

Forbidden badge postures include `green`, `trusted`, `resolved`, `compliant`, `globally_approved`, `all_clear`, and `fresh_now` unless a later, separately promoted surface proves such language is safe. F092 does not prove that.

## Hostile candidates

F092 rejects eight counterfeits:

1. multi-verifier split collapsed into one green badge;
2. latest policy used to erase historical public-copy basis;
3. superseded policy claimed as current;
4. one verifier refusal upgraded to global failure;
5. unknown currentness upgraded to fresh-now;
6. issuer compromise collapsed into automatic falsity;
7. majority vote treated as truth without authority basis;
8. verifier run without policy digest used for epoch comparison.

These are the likely failure modes of dashboard, compliance, and deployment surfaces that want one attractive status badge.

## Relation to F090 and F091

```text
CrossingRecord v0 says an outside evidence crossing occurred within scope.
ReceiptImportRecord v0 says a transparency/provenance receipt was imported within scope.
VerifierDisagreementRecord v0 says multiple verifier/policy/currentness results were preserved without collapsing them.
No line says the world is true, fresh, repaired, approved, compliant, or safe.
```

F092 intentionally keeps the third line as a fixture artifact, not a promoted schema.

## Promotion posture

F092 closes the multi-verifier/policy-epoch seam only as executable pressure. It does not promote verifier arbitration, policy-drift ledgers, public badge semantics, reliance APIs, compliance workflows, legal status handling, external authority precedence, trust-root management, issuer reputation, or final SlopOS datacube shape.

The next pressure should combine disagreement with **property-style fixture generation and mutation coverage**: prove that the three executable bundles can be fuzzed or generated without accidentally promoting schemas or weakening the explicit hostile cases.
