# Research synthesis — pass LXIX

This pass asks a smaller question than “what is Harbor’s final temporal model?”

It asks: **while the datacube is still embryonic, how do we stop one timestamp from impersonating event time, validity time, knowledge time, and published-cut time all at once?**

## What the outside material teaches
1. **Event time and processing time are different truths, not just different clocks.**
   Apache Flink’s time model is explicit that processing time uses machine wall clocks, gives the best performance and lowest latency, and is simpler, but it does not provide determinism in distributed asynchronous environments. Event time instead follows the time embedded in the data, uses watermarks, and is what lets out-of-order or historical reprocessing still produce the right event-time windows. Harbor should steal the split: occurrence time and observation/processing time must not collapse into one column.

2. **Transaction/system time is not automatically business-valid time.**
   SQL Server’s temporal-table guidance is blunt that system-versioned temporal tables are acceptable for slowly changing dimensions only if transaction-time validity is good enough for the business logic, and if data is loaded with significant delay, transaction time may not be acceptable. Harbor should steal that warning: knowledge/recorded time and validity/effective time are neighboring but non-identical axes.

3. **Bitemporal systems keep business-valid time and system-currentness separate on purpose.**
   Db2’s bitemporal table guidance distinguishes BUSINESS_TIME (when a row is valid from the business/application perspective) from SYSTEM_TIME (when the row is current in the database), and also supports `BUSINESS_TIME WITHOUT OVERLAPS`. Harbor should steal the pattern without prematurely choosing Db2 or a universal bitemporal engine: validity windows and knowledge/currentness windows deserve separate review surfaces.

4. **“As of” needs an explicit axis.**
   Db2 temporal querying requires `FOR SYSTEM_TIME` or `FOR BUSINESS_TIME` plus `AS OF`, `FROM`, or `BETWEEN`, and also supports session-level special registers so the temporal basis stays explicit even when not repeated in every statement. Harbor should steal that behavioral lesson: an answer should be able to say whether it is “as of validity time”, “as of knowledge time”, or “as of published cut”, rather than relying on one ambient “latest.”

5. **Historical joins and semantic models need non-overlapping validity windows.**
   dbt’s semantic-model guidance for SCD Type II dimensions requires `valid_from` / `valid_to`, expects non-overlapping periods with one matching row per natural key, and recommends snapshots for maintaining that layout. Harbor should steal the discipline: if a lane uses validity windows, it should say whether overlaps are forbidden, tolerated temporarily, or still unresolved design debt.

## Harbor consequence
Harbor should add one modest datacube/process seam now:
- **time-axis card** — compact declaration of which temporal axes a lane actually uses and which axis is canonical for grouping/filtering;
- **as-of witness** — compact note saying which axis a query or published answer was asked on and what exact cut/timestamp/interval it used; and
- **knowledge-cut note** — compact note saying which published cut/snapshot/tag was in force, whether late arrivals after that cut are expected, and whether restatement is possible.

## What Harbor still should not decide yet
- exact warehouse or stream-processing substrate for temporal semantics;
- exact machine-readable multi-temporal schema shared across sibling cubes;
- exact universal overlap-enforcement engine;
- exact global rule for when every lane must carry all four temporal axes.

The design-phase lesson is enough for now: **name the time axis, keep “as of” explicit, and treat published cuts as knowledge cuts instead of timeless truth.**
