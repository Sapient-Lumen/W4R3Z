# SlopOS / companions evaluation — pass LXXIV

This pass asks a design-phase datacube question rather than a warehouse-product question: if Harbor later carries durations, bytes, ratios, counts, and monetary amounts, how does it stop unit strings, display formatting, and currency conversion from counterfeiting one settled measurement truth?

## What the companions teach this pass
- **SlopOS** remains the strongest process teacher because it repeatedly pins compact machine-facing units instead of letting display convenience become ambient truth. `CH-METER v0` uses closed `kind` values such as `mem_bytes`, `net_bytes`, and `cpu_ticks`, and its `limit` carries a bounded `{ unit: bytes|ticks|count, value: u64 }` shape. Elsewhere SlopOS is willing to say “units profile-defined” instead of bluffing a universal semantics too early. The transferable lesson is that Harbor should keep quantity kind, coded unit, and profile-local display/render decisions visibly separate.
- **Foundry** keeps teaching residue-class discipline. That transfers directly here: physical measures, ratios, counts, and money are all scalar-looking, but they should not inherit one generic conversion story.
- **Ward** keeps teaching tier honesty. That matters for quantity surfaces too: a display-only percent or currency render can be useful while still smaller than the canonical coded basis.
- **Steward** keeps teaching receipts and accountable aftermath. That transfers well to converted-money outputs: if Harbor restates a converted amount because the rate source or as-of basis changed, the lane should leave a rate/restatement witness.
- **ViewFS** keeps teaching import/open-in-place humility. Harbor can reuse that instinct here: source-native units are often worth preserving even when a normalized comparison lane is also useful.

## Harbor consequence
Harbor should make exactly one modest repo/process expansion now:
- add a datacube measurement-semantics surface;
- add one specimen around measurement-kind cards, canonical-unit notes, display-unit notes, and currency-rate witnesses;
- refresh the load-bearing source register with living sources that keep coded units, display units, ratio-versus-percent posture, and ISO-4217-backed money semantics visibly different; and
- keep semantic-front-door pressure alive without pretending this pass chooses a final conversion engine, finance policy stack, or enterprise semantic API.

## Still-not-yet decisions
- whether Harbor later standardizes one house canonical unit for every quantity family or allows multiple source-native canonical families with explicit conversion witnesses;
- whether Harbor later publishes conversion rates as first-class lanes, compact receipts, or purely external references;
- whether utilization/fraction values always stay in unity form with optional percent display, or whether some published surfaces carry percent-rendered values directly;
- whether Harbor later standardizes minor-unit enforcement for money lanes or leaves it to narrower product/consumer contracts.

For now, the companion lesson is enough: **keep quantity kind smaller than scalar rendering, keep coded unit smaller than display label, and keep converted money visibly smaller than original-denomination truth.**
