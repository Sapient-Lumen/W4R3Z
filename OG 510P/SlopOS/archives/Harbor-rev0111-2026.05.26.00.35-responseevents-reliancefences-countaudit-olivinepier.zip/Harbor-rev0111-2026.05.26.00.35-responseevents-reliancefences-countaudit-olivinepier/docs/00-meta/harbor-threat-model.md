# Harbor threat model for crossings and public-copy aftermath

**Status:** design-phase threat model for `rev0094`; not a security certification, adversary taxonomy standard, abuse-detection system, compliance program, trust registry, or enforcement ladder.

## Security property

A membrane crossing must not silently upgrade weak outside facts into native authority, local truth, public-copy repair, compliance status, user comprehension, or global currentness.

## Adversaries and counterfeit moves

| Actor or failure mode | Counterfeit move | Required Harbor response |
|---|---|---|
| source owner seeking absolution | treats implementation receipt as resolved/compliant | require scope, authority, evidence lane, non-promises |
| stale mirror or cache | inherits fresh labels without proof | require mirror/restatement proof and stale-surface note |
| over-eager internal operator | closes warning after one clean recheck | require warning lifecycle receipt and clean-window scope |
| external reviewer | speaks outside its jurisdiction or audience | require authority-basis and scope comparison note |
| stale retrieval index | returns old chunk with fresh explanation | require agent-memory invalidation note and stale observation |
| generated explainer | paraphrases corrected copy into overclaim | require summary tether and unsupported-conclusion list |
| annotation/proxy layer | strips label digest, warning, or scope | reject or downgrade as label-stripped public copy |
| prompt-injected correction | says a public copy was fixed without receipt | require digest-bound correction/publication evidence |
| browser callback attacker | supplies plausible but authorityless result | require callback proof and local adoption gate |
| MCP/tool server | offers attractive metadata or tool annotation | treat annotations as untrusted unless the server/trust posture is in scope |
| credential issuer or wallet | implies universal identity or endorsement | record presentation scope, issuer limits, and audience |
| transparency/log operator | shows inclusion as truth | separate inclusion, consistency, semantic validation, and relying-party judgment |

## Negative fixture rule

Every new crossing or public-copy aftermath specimen should include at least one rejection path. A passing specimen with only happy-path receipts is not enough for durable vocabulary.

## Public language guard

Public text may say `observed`, `accepted`, `adopted`, `published`, `stale observed`, `clean for this window`, `warning sunset for this scope`, or `reopened`. It must not say `resolved`, `compliant`, `corrected everywhere`, `safe`, `trusted`, `verified identity`, `all agents updated`, or `global truth` unless a named proof obligation and authority basis explicitly support that exact claim.

## Residual risks

This threat model does not detect malicious content, prove credential validity, verify all mirrors, audit external authorities, ensure users understood UI, enforce legal compliance, erase model memory, or make transparency logs trustworthy. It only keeps Harbor's local records from overstating what the evidence can support.
