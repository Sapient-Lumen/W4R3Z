# Research synthesis — pass LVIII

This pass keeps Harbor narrow and learns five compatible things at once: **a granted `authorization_details` view in a token response is smaller than durable entitlement truth; JWT or introspection-visible `authorization_details` can be filtered or extended for one specific receiver; schema and type metadata can help clients build or validate objects without becoming Harbor’s permanent authorization grammar; malformed detail objects deserve a typed schema veto rather than silent coercion; and even cross-domain/token-exchange style Resource Authorization Servers can legitimately modify, filter, omit, and then return granted details without exporting a portable policy substrate.**

## Outside lessons
1. **Granted details are required output, not permanent truth.**  
   RFC 9396 says the AS **MUST** return `authorization_details` in the token response as granted and assigned to the access token, and it **MAY omit values** to the client. Harbor should therefore preserve a **granted-detail view**, not counterfeit full grant or entitlement truth.

2. **Granted details may differ from what the client asked for.**  
   The same RFC says the authorization details attached to an access token **may differ** from the request and can be **enriched** during the authorization process. Harbor should keep that as a request-versus-grant distinction rather than flattening request JSON into “what exists now”.

3. **Receiver-visible details are allowed to be receiver-scoped.**  
   RFC 9396 recommends adding `authorization_details` to JWT access tokens **filtered to the specific audience** and says introspection-visible `authorization_details` may be **filtered and extended for the RS making the introspection request**. Harbor therefore needs a **filtered-detail card** for what one receiver sees, not a portable authorization ledger.

4. **Schema mismatch deserves a typed bottom.**  
   RFC 9396 requires `invalid_authorization_details` when objects contain unknown types, unknown fields for the type, wrong field types, invalid values, or missing required fields. That is exactly a Harbor **detail-schema veto**: the turn bottoms out because the detail object shape is wrong, not because the target, account, or session story changed.

5. **Metadata and cross-domain exchanges make the distinction sharper, not flatter.**  
   The February 2026 RAR metadata draft defines metadata endpoints with `schema` or `schema_uri`, examples, and human-readable documentation, while explicitly warning that human-readable description fields are not for validation decisions. The March 2026 Identity Assertion JWT Authorization Grant draft says the Resource Authorization Server may **modify, filter, or omit** `authorization_details` based on policy and **must include the granted** `resource`, `scope`, and `authorization_details` in the access-token response. Harbor should collect those ideas without promoting a portable schema or entitlement registry.

## Resulting Harbor move
Do not decide yet whether Harbor needs durable nouns such as **granted-detail view**, **filtered-detail card**, or **detail-schema veto**.
For this revision:
- add one specimen where a client receives a granted `authorization_details` view, a specific RS later sees a filtered or extended detail view, and a malformed next request bottoms out with `invalid_authorization_details`;
- keep requested detail objects, granted detail objects, receiver-visible detail objects, and schema-validation failures visibly separate; and
- treat metadata `schema` / `schema_uri` as build-or-validate aids rather than Harbor’s permanent type language.

## Fresh ideas worth stealing
- **granted-detail view** — compact residue that says what the token response actually granted.
- **filtered-detail card** — receiver-scoped detail view that stays smaller than universal grant truth.
- **detail-schema veto** — typed bottom for malformed or unknown detail shapes.
- **schema-source note** — small note about whether shape guidance came from inline schema, `schema_uri`, or preconfigured local knowledge.
- **omitted-field humility** — standing reminder that values omitted to the client may still exist in the AS/RS policy universe without becoming Harbor truth.
