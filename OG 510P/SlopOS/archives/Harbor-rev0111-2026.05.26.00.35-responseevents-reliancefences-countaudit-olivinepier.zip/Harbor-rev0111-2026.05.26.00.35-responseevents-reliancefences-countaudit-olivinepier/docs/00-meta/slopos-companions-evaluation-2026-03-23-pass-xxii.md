# SlopOS / companions evaluation — pass XXII

This pass re-checks Harbor against the uploaded cube ecology and keeps the architecture embryonic.

## What the current cubes still teach
- **SlopOS** keeps browser-session selection, auth-session handling, login-state export, account-binding export, and auth-result export provider-local or request-local instead of turning them into portable system truth.
- **ViewFS** is a useful analogy teacher: remembered designators, revalidation, continuity lockers, live handles, and receipts stay visibly separate. Harbor can borrow that humility without importing ViewFS authority semantics.
- **Helm** keeps continuity postcards and revalidation checkpoints basis-honest. That suggests Harbor can expose modest return residue without pretending it is live truth.
- **Ward** still teaches the hard rule: strong provider/browser success signals remain weaker than durable local appraisal.
- **Schell** still teaches that technically clean helper/provider returns may need a separate local adoption turn.

## Harbor consequence
Harbor should keep continuity nouns provisional.
The right near-term move is small:
- add one specimen around same-device continuity, returning-account hints, and explicit revalidation;
- keep provider/browser-local login state, account-linking, and current session truth outside Harbor-owned durable vocabulary;
- keep mismatch honesty explicit so stale continuity degrades to chooser, login, or refusal instead of counterfeit smoothness.

## Still-not-yet decisions
- Whether `continuity hint` belongs beside `detour state` or inside a later, smaller continuity-residue family.
- Whether `returning-account hint` deserves first-class Harbor status or remains only neighboring/browser/provider-local context.
- Whether `mismatch honesty` should be one explicit aftermath class or just one mode of fallback/adoption veto.
