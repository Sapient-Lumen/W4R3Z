# SlopOS / companions evaluation — pass LXIII

This pass asks a narrower datacube-process question: if Harbor starts accumulating real downstream consumers before SlopOS itself has frozen its final datacube shape, how does Harbor avoid making accidental permanence promises? The answer is to copy explicit maturity and review posture harder than storage architecture.

## What the companions teach this pass
- **SlopOS** remains the best maturity teacher because so many of its important surfaces are explicitly named `v0` posture docs. That is already a stability-ring habit in disguise: useful, reviewable, intentionally provisional, and not pretending to be final law.
- **SlopOS** trajectory mapping also keeps closure visible. Harbor should borrow that and insist that a published lane retirement leaves one compact **deprecation receipt** instead of disappearing into the newest head contract.
- **Helm** is a good nearby reminder that candidate contracts can exist without pretending to be final ontology. Harbor should be willing to mark a datacube lane as candidate instead of either freezing it too early or hiding it entirely.
- **Schell** keeps proving that same-revision discipline matters: when a new datacube process seam appears, the review surfaces, ledgers, and release bundle should all update together.
- **Foundry** keeps teaching lightweight source-refresh hygiene and noun-promotion discipline; those become more important once Harbor starts making compatibility promises to consumers.
- **ViewFS** keeps repeating the best anti-regrowth lesson of all: keep neighboring strengths of fact separate. For Harbor, that means ring, compatibility promise, consumer pin, derived artifact, and retirement history should not collapse into one vague “publishedness” badge.

## Harbor consequence
Harbor should make exactly one modest repo/process expansion now:
- add a datacube stability-rings surface;
- add one specimen around stability ring cards, compatibility windows, consumer pins, and deprecation receipts;
- refresh the source register with living sources that shape maturity/compatibility/deprecation behavior; and
- keep the main queued pressure on restatement, semantic front doors, and change-history lanes rather than pretending the compatibility story is complete.

## Still-not-yet decisions
- whether Harbor ever needs a first-class lane registry rather than a small set of explicit cards/receipts;
- whether compatibility windows should later borrow exact terms like backward/transitive/full from one external system;
- whether consumer-pin notes should stay in Harbor’s own review surfaces or migrate into future generated artifacts.

For now, the repo/process lesson is enough: **name the maturity, scope the compatibility promise, keep version pointers immutable when published, and retire old surfaces with a receipt instead of folklore.**
