# Research synthesis — 2026-05-22 pass XCIX

**Revision:** `rev0099`  
**Focus:** survived-mutant triage, equivalent mutants, checker-overstrict false positives, and corpus pruning.

## Research pressure

Mutation-testing literature and tools distinguish killed and survived mutants, but they also warn that not every surviving mutant is meaningful. PIT's basic concepts explicitly call out equivalent mutations: some mutants behave the same as the original, and others may differ only outside the test scope. That maps directly to Harbor's need for an `equivalent_survivor_do_not_promote` packet.

Fuzzing practice adds a second lesson. AFL++ recommends corpus uniqueness/minimization before fuzzing because duplicate or uninteresting inputs bloat the corpus and slow useful progress. Harbor's generated mutants have the same problem: adding more rows can inflate confidence without adding new refusal pressure.

Coverage tooling adds a third caution. Branch coverage is an observation about measured transitions compared with possible transitions; it is a useful diagnostic, not proof of semantic completeness. Harbor therefore keeps mutation counts and checker results as pressure evidence rather than public correctness scores.

## What Harbor borrowed

- From mutation testing: killed/survived/equivalent state vocabulary, but not mutation-score authority.
- From property-based testing: minimized, replayable counterexamples, but not a property-test framework dependency.
- From fuzzing: corpus pruning and uniqueness discipline, but not a fuzzing campaign.
- From coverage tools: diagnostic humility about exercised paths, but not completeness claims.

## New finding

F093's killed set was useful, but it also hid a real next seam: some checkers rejected forbidden keys such as `global_truth`, while unsafe authority claims could still appear as accepted string values. F094 hardens all three core executable checkers with a guarded phrase scan and captures the unsafe survivor pattern in the mutation-triage bundle.

The hardening is intentionally narrow. It catches phrases such as:

```text
guarded forbidden phrase: global truth
guarded forbidden phrase: semantic truth
guarded forbidden phrase: compliance truth
guarded forbidden phrase: authority truth
guarded forbidden phrase: trusted content
guarded forbidden phrase: fresh now
guarded forbidden phrase: global authority
guarded forbidden phrase: one badge truth
```

The scan exempts negating forms such as `not_global_authority`, because Harbor's accepted non-promises depend on visible refusal language.

## Speculative seam

The next verification seam is no longer "more mutations." It is checker trust roots and adversarial checker drift:

```text
checker version/digest provenance
checker dependency drift
fixture generated under one checker but reviewed under another
checker self-test fixtures
reviewer override of a checker result
ambiguous pass caused by disabled guard
```

A future F095 should prevent the checker itself from becoming an unaudited authority surface.

## Non-promotions

Pass XCIX does not promote mutation dashboards, mutation scores, property-test frameworks, fuzzing campaigns, coverage thresholds, automatic hostile-fixture promotion, or final SlopOS datacube shape.
