# Research synthesis — pass XCIV, crossing records and warning lifecycle guards

**Revision:** `rev0094`  
**Date:** 2026-05-21  
**Question:** How should Harbor close the gap between SlopOS's executable `portal.net.request` evidence and Harbor's public-copy correction discipline without turning crossing receipts, scope comparisons, warnings, deadlines, credentials, or transparency logs into global truth?

## Result

Harbor should add a **small crossing/aftermath core** and then use it to pressure-test implementation exceptions. The core is not a schema freeze. It is a shared specimen shape that lets every crossing say:

- what subject crossed a membrane;
- which route family and authority basis admitted, rejected, deferred, degraded, or detoured it;
- which scope the outcome binds;
- which public/status/user-facing effect was observed;
- which receipts, recheck windows, rollback triggers, and non-promises survive afterward.

That move closes a real sync gap: SlopOS can now emit accepted-only durable request evidence for portal-network flows with checkpoint/resume/truncation/append discipline, while Harbor has been richer on public-copy correction language than on compact crossing records. `rev0094` keeps the SlopOS evidence import narrow: transport acceptance can feed Harbor crossing records, but it must not become trusted content, user comprehension, correction propagation, compliance, or global current truth.

## Nine changes folded in

1. **`CrossingRecord v0` specimen shape.** Add a minimal JSON-like record for subject, route, admission, scope, outcome, and aftermath. It is a proof target and negative-fixture carrier, not a production schema.
2. **Scope algebra.** Add `same_scope`, `narrower_than`, `overlaps`, `incomparable`, `supersedes_within_scope`, and `stale_after` so status phrases cannot silently widen from artifact/audience/window to world.
3. **Public status state machine.** Separate found, accepted-for-review, adopted, instructed, implementation-evidence-received, public-copy-published, propagation-observed, recheck-clean-for-scope, warning-sunset, re-escalated, failed-recheck, missed-deadline, contradictory-evidence, rollback, and appeal/stay branches.
4. **Threat model.** Name the attackers: overclaiming source owner, stale mirror, over-eager operator, scope-stripping annotation layer, prompt-injected correction, stale retrieval index, authorityless callback, and attractive but untrusted tool metadata.
5. **Harbor ↔ SlopOS boundary map.** Map `portal.net.request`, chooser evidence, callbacks, truncation/resume, accepted-only append history, public warnings, and status surfaces to the Harbor claims they can and cannot support.
6. **Agent-memory invalidation surface.** Treat retrieval chunks, tool-result caches, conversation summaries, generated explanations, prompt templates, browser previews, MCP resource listings, and eval fixtures as possible stale public-copy residues.
7. **Clock-basis note.** Bind deadline, observation time, publication time, recheck window, stay/extension posture, and known clock uncertainty before saying a deadline was met, missed, or stayed.
8. **Hostile receipt fixtures.** Add negative examples for wrong digest, wrong audience, copied receipt, backdated receipt, implementation-without-propagation, publication-without-implementation, scope-hidden recheck, and label-stripped export.
9. **Research seams.** Keep OAuth/WebAuthn/FedCM/Digital Credentials, MCP, XDG portals, OpenVEX/CSAF, NIST SP 800-61 Rev. 3, NIST SP 800-226, SCITT/CT/Rekor, PROV/DataCite/C2PA as source pressure only; no external workflow or log is promoted.

## External lessons folded in

- MCP-style tool/resource/prompt surfaces are useful because they separate capabilities and user-facing consent from trusted semantic content. Harbor should borrow capability/consent humility, not treat MCP metadata as inherently trusted.
- XDG portal patterns are useful because mediated URI/file openings give request evidence, while presentation and user cognition remain separate claims. Harbor should borrow mediated-crossing discipline, not desktop-specific APIs.
- WebAuthn, FedCM, OAuth security guidance, and Digital Credentials work are useful because browser/user-agent-mediated identity and credential flows are scoped, consent-sensitive, and privacy-sensitive. Harbor should record credential presentation and authorization completion as scoped crossing evidence only.
- OpenVEX and CSAF are useful because they constrain status to named subjects/products and actions. Harbor should borrow subject-bound status posture, not vulnerability-advisory governance.
- NIST SP 800-61 Rev. 3 is useful because response/recovery/improvement are ongoing risk-management loops. Harbor should borrow lifecycle humility, not an incident-response program.
- NIST SP 800-226 is useful because differential privacy is a quantified mechanism/accounting claim. Harbor should refuse DP-sounding public-copy claims unless mechanism, parameters, adjacency, contribution bounds, and accounting evidence exist.
- SCITT, Certificate Transparency, Rekor, C2PA, PROV, and DataCite are useful because they separate publication, inclusion, provenance, relation, revision, invalidation, and verifier/relying-party judgment. Harbor should borrow receipt/currentness humility, not a mandatory transparency substrate.

## SlopOS-specific interpretation

SlopOS's `portal.net.request` corpus gives Harbor a stronger upstream evidence substrate, but only within SlopOS's own constraints:

- accepted network request records can support route/admission facts, not trusted response semantics;
- checkpoint/resume evidence can support continuity of SlopOS processing, not unchanged outside truth;
- truncation evidence can support honest incompleteness, not safe summarization;
- accepted-only append history can support durable local record order, not retroactive repair;
- malformed-envelope rejection can feed hostile receipt tests;
- portal/chooser/callback surfaces can support mediated crossing posture, not user comprehension or authority transfer.

## New watchlist handles

- `crossing_record_v0`
- `scope_comparison_note`
- `public_status_state_transition_note`
- `clock_basis_note`
- `missed_deadline_receipt`
- `failed_recheck_receipt`
- `contradictory_implementation_evidence_packet`
- `rollback_or_reopen_trigger_note`
- `stale_surface_recurrence_receipt`
- `warning_lifecycle_receipt`
- `agent_memory_invalidation_note`
- `hostile_receipt_fixture_set`
- `harbor_slopos_boundary_map`

## Practical design rule

Prefer language that leaves the crossing small:

- `accepted by this portal route`, not `trusted`;  
- `credential presented for this audience`, not `identity established everywhere`;  
- `deadline missed under this clock basis`, not `non-compliant`;  
- `recheck clean for this surface/window`, not `resolved`;  
- `warning sunset within this scope`, not `safe`;  
- `receipt included`, not `truth verified`;  
- `agent cache invalidation requested`, not `all future agents corrected`.

## Followthrough result

`F089` is now complete as a pressure test. It exercises missed deadlines, failed rechecks, contradictory implementation evidence, rollback/reopen triggers, stale-surface recurrence after a clean window, and warning re-escalation/sunset. The next seam is `F090`: run the new `CrossingRecord v0` shape against real SlopOS-style portal/network evidence, callbacks, truncation/resume, accepted-only append history, MCP/tool resources, credential presentation, and public-copy aftermath before promoting any crossing record into durable schema.
