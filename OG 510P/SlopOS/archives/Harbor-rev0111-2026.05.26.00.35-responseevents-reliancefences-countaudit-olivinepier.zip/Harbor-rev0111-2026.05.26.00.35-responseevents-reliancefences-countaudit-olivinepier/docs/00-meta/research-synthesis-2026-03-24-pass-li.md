# Research synthesis — pass LI

This pass keeps Harbor narrow and learns five compatible things at once: **omitted `resource` can mean either assigned specificity or no resource-specific restriction; dynamically discovered clients deserve stricter confirmation than preconfigured ones; requested resources need at least one surviving requested anchor; discovery helps route but does not confirm issuance-time resource selection; and Harbor should preserve confirmation posture without freezing a portable target-confirmation model too early.**

## Outside lessons
1. **Omission is allowed, but omission is not one thing.**  
   RFC 8707 says that if the client omits the `resource` parameter when requesting authorization, the authorization server MAY process the request with no specific resource or with a predefined default resource, or MAY reject the request with `invalid_target`. The March 2026 resource-token-response draft sharpens the response side: if the client did not request a resource and the authorization server assigns one or more server-assigned resources, it SHOULD include them in the response; if it does not apply any resource-specific restriction, it SHOULD omit `resource`. Harbor should preserve an **assigned-only lane** instead of flattening all omitted-request cases into one truth.

2. **Discovery-time routing is smaller than issuance-time confirmation.**  
   RFC 9728 gives clients a way to discover protected-resource metadata, including dynamically discovered cases, while the March 2026 resource-token-response draft says those discovery mechanisms do not provide issuance-time confirmation of which resource an issued token is actually valid for. Harbor should keep discovery and resource confirmation visibly separate.

3. **Preconfigured clients and discovered clients deserve different omission rules.**  
   The March 2026 resource-token-response draft says a client without pre-configured knowledge of both the authorization server and the protected resource MUST require the `resource` parameter in the response and MUST discard the token if it is absent. A client with pre-configured knowledge of both SHOULD treat an absent `resource` as **not resource-confirmed**, though it MAY continue with prior behavior. Harbor should preserve a **resource-confirmation floor** instead of pretending omission always means failure or always means success.

4. **Requested anchors are a floor, not a garnish.**  
   The same draft says that when the client requested one or more resources, a returned `resource` value must contain at least one identifier matching a requested resource; validation fails if the returned set contains none of the requested resources, even if server-assigned resources could have been returned. Harbor should preserve a **requested-anchor minimum** instead of letting assigned additions counterfeit exact request success.

5. **Validation mismatch deserves typed refusal before reuse.**  
   The March 2026 resource-token-response draft advises clients to validate returned `resource` values and treat mismatches as errors, and it warns that absence of `resource` can be a potential ambiguity for clients needing strict binding. Harbor should keep confirmation failure visibly smaller than durable grant truth or adopted consequence meaning.

## Resulting Harbor move
Do not decide yet whether Harbor needs durable nouns such as **assigned-only lane**, **requested-anchor minimum**, or **resource-confirmation floor**.
For this revision:
- add one specimen around preconfigured omission grace, dynamically discovered omission refusal, and requested-anchor validation mismatch;
- preserve the difference between “what route/discovery told us,” “what the client explicitly requested,” “what the authorization server actually confirmed at issuance time,” “what assigned-only or unbounded outcome still remains,” and “none of those facts by themselves settle durable entitlement/account/session/adoption truth”;
- and collect **preconfigured-omission grace** plus **strict-discovery discard** as inspiration only, without promoting a new registry today.

## Fresh ideas worth stealing
- **assigned-only lane** — compact reminder that a no-request turn can still return an authorization-server-assigned resource set.
- **requested-anchor minimum** — inspectable floor that at least one requested resource must survive if the client did ask for resources.
- **resource-confirmation floor** — local status explaining whether issuance-time resource confirmation actually happened.
- **preconfigured-omission grace** — future-facing reminder that preconfigured clients may continue with weaker confirmation instead of counterfeit exactness.
- **strict-discovery discard** — future-facing reminder that dynamically discovered clients should treat missing response confirmation as a discard condition, not as a guessable omission.
