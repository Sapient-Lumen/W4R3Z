# SlopOS companion evaluation — 2026-05-23 pass CIII

## Harbor / SlopOS boundary

SlopOS gives Harbor increasingly concrete evidence for mediated request, portal, callback, checkpoint/resume, truncation, append, and file-materialization events. F097 used that style to distinguish handoff transport from consumer verification. F098 extends the boundary one step further: after material arrives, consumer-side derivatives are not automatically covered by the original crossing.

## What Harbor should ask SlopOS for later

- post-materialization event ids that can be referenced without becoming truth;
- callback/portal success receipts that remain smaller than derivative verification;
- file/open/import route receipts that do not imply local search/index/cache currentness;
- append/resume histories that can invalidate cached explanations when source revision or digest changes;
- safe failure modes when a local derivative cannot be traced back to the imported material.

## What Harbor must refuse

- portal/callback success as derivative currentness;
- file-library upload time as source freshness;
- synced path equality as byte equality;
- local search result as source truth;
- generated summary as proof of compliance or upstream repair;
- local patch as source correction.

## Companion note

ViewFS and Schell remain relevant here: ViewFS for trusted-path and copy/materialization boundaries, Schell for retention and forgetting pressure around local caches and summaries. Steward and Ward become relevant when consumer repair acknowledgement or external duty claims appear in F099.
