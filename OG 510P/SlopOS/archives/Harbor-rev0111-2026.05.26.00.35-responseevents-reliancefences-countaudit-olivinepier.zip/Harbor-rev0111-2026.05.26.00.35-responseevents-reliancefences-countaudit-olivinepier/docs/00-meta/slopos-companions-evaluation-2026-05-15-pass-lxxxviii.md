# SlopOS and companions evaluation — pass LXXXVIII

**Revision:** `rev0088`  
**Date:** 2026-05-15  
**Focus:** stale downstream impact assessment, consumer acknowledgements, remediation attestations, use attestations, and safe public impact statements after correction propagation.

## SlopOS pressure

SlopOS remains in design phase; that argues for small, scoped impact receipts rather than a broad incident/compliance subsystem.

The strongest SlopOS lessons for this pass:

- **Claim receipts are not authority upgrades.** A downstream remediation claim may be important, but it should not become source truth or grant hidden capabilities.
- **Imported evidence must remain digest-bound.** Use and remediation attestations should name subject, cut, digest, method, and limits rather than becoming recursive access paths.
- **LLM/tool summaries are not repair.** A regenerated explanation is only repaired if it can name its corrected source, label digest, omitted-label check, and review status.
- **No-use claims need scope.** A consumer's non-use attestation should name logs, report ids, dataset manifests, time windows, or manual review basis; it is not a global proof that nobody used the stale copy.
- **Unrepairable-now is honest.** Some stale model/eval/archive/crawl uses cannot be repaired immediately. SlopOS-style boundary hygiene prefers a truthful unsafe/historical notice over a false fixed badge.

## Companion pressure

- **ViewFS:** access propagation and public cache copies already separate observed object state from downstream consumer state. Harbor should reuse that split for stale use and residual risk.
- **Helm:** epoch stamps and stale fences suggest acknowledgement expiry and remediation recheck windows.
- **Schell:** prompt provenance and provider-sidecar humility warn against accepting generated explanations, provider status, or tool claims as repair without source-bound proof.
- **Ward:** correction lineage and completeness frontiers support partial impact assessment where some uses are known and others remain unknown.
- **Foundry:** exactness and correction horizons warn that unchanged numbers can still have changed labels, exactness posture, or public interpretation.
- **Steward:** bootstrap reconciliation and remediation lanes are the natural future consumer of `remediation_attestation`, but this revision should not import Steward's process machinery.

## Harbor delta

`rev0088` adds:

- `docs/00-meta/datacube-stale-downstream-impact-hygiene.md`;
- specimen flow 83 for a stale public copy used in a downstream report, a consumer acknowledgement, a catalog/dataset remediation claim, an unrepairable stale eval/model result, and a safe public impact statement;
- stale-impact proof obligations in `docs/00-meta/datacube-proof-obligations.md`;
- refreshed lessons, inspiration harvest, source register, bibliography, ledgers, roadmap, README surfaces, manifest, and archive index.

## Deliberate non-promotion

This pass does not promote an incident manager, customer notification workflow, acknowledgement ledger, remediation registry, VEX/CSAF profile, in-toto predicate, AI incident taxonomy, audit program, model unlearning process, eval governance program, public status API, or final SlopOS datacube shape.
