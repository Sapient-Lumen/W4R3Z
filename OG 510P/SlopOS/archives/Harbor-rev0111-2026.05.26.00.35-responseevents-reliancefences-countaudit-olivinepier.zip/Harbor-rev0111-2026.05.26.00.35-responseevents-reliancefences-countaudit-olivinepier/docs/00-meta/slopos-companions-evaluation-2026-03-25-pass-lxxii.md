# SlopOS / companions evaluation — pass LXXII

This pass asks a design-phase datacube question rather than a warehouse-product question: if Harbor later exposes exact counts, exact recomputations, sketch-backed estimates, or sample/proxy summaries side by side, how does it stop those different strengths of truth from collapsing into one generic “metric” surface?

## What the companions teach this pass
- **SlopOS** remains the strongest process teacher because it keeps discovery surfaces closed, singleton seams explicit, and same-revision maintenance mandatory. Two SlopOS habits matter especially here: boundary-index/singleton contracts prevent ambiguous review surfaces, and the worker-pool summary posture explicitly refuses metrics/debug/extension-bag drift on the portable summary surface. The transferable lesson is that Harbor should not let estimate posture arrive as an unreviewed “metrics bag.” If exactness changes, the exactness surface should change in the same revision.
- **Foundry** keeps teaching residue-class discipline. For Harbor, that becomes the reminder that exact values, sketch estimates, and sample/proxy estimates are different residue families even if they all render as numbers.
- **Ward** keeps teaching tier honesty and hybrid seams. That transfers well here: a useful executive estimate can still be smaller than exact row truth and should stay visibly weaker.
- **Steward** keeps teaching receipts and accountable aftermath. That matters for estimate lineage too: if a lane switches from exact to sketch-backed or adopts a new precision regime, Harbor should leave a note or receipt rather than silently changing the strength of truth.
- **ViewFS** keeps teaching imported/open-in-place humility. Harbor can reuse that instinct for estimate artifacts too: imported sketches, pre-aggregated distinct counts, and downstream-provided approximations are useful, but they should not automatically become Harbor’s exact canonical numbers.

## Harbor consequence
Harbor should make exactly one modest repo/process expansion now:
- add a datacube exactness-semantics surface;
- add one specimen around exactness-class cards, sketch witnesses, error-band notes, and mixed-exactness vetoes;
- refresh the load-bearing source register with living sources that keep approximate functions, mergeable sketches, and explicit uncertainty posture visible; and
- keep semantic-front-door and restatement pressure alive without pretending this pass chooses a final metric engine, sketch library, or warehouse implementation.

## Still-not-yet decisions
- whether Harbor later retains raw rows, sketches, or both for estimate-backed lanes;
- whether exactness-class cards later become first-class machine-readable artifacts or remain smaller review residue;
- whether one universal error language is worth standardizing; and
- whether estimate-backed lanes later need stronger drift gates for exactness downgrades, merge legality, or confidence-band preservation.

For now, the companion lesson is enough: **keep exactness classes explicit, keep estimate lineage reviewable, and do not let a convenient scalar become fake certainty.**
