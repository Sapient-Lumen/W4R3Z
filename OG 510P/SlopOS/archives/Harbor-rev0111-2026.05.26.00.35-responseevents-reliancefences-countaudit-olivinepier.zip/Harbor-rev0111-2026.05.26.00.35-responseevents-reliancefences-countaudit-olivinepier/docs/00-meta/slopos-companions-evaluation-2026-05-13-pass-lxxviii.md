# SlopOS / companions evaluation — pass LXXVIII

This pass asks how Harbor should pressure-test semantic-front-door exports while SlopOS's datacube is still in design phase. The answer is not to choose a semantic layer; it is to make every consumer-facing export carry a narrow proof packet and a refusal surface.

## SlopOS lessons used directly
- **Observation export is an allowlisted act.** SlopOS's observation export policy makes exported diagnostics bounded, tiered, auditable, and fail-closed. Harbor should borrow the same shape for semantic exports: the export receipt names dimensions, measures, assertions, freshness thresholds, row-level details, sidecars, and refusal cases rather than becoming an ambient cube dump.

- **Mutable-data rollback remains separate from code rollback.** SlopOS's data-contract and migration-gate RFC warns that data evolution can cross rollback barriers. Harbor's semantic exports need invalidation/restatement posture: a published semantic lens over migrated or restated data cannot promise replay unless the source cuts and compatible snapshots still exist.

- **Receipts explain; they do not authorize.** SlopOS repeatedly keeps adapter receipts, request contexts, conflict keys, and tool annotations smaller than authority. Harbor applies the same rule to semantic export receipts, join-relationship notes, freshness witnesses, and row-lineage sidecars. They are review/evidence surfaces, not row truth or authorization.

- **Proof obligations are already a native SlopOS habit.** The SlopOS proof-obligation registry is full of fail-closed, bounded, deterministic checks. Harbor's datacube proof obligations are aligned with that culture: a public contract subset must say what it checks, when it checked, and what it cannot prove.

## Companion-cube pressure
- **Foundry:** serving lanes and semantic spines are useful only when the published basis and pinned cut stay visible. Harbor should make semantic exports declare their source cut and refusal surface.
- **Schell:** activation receipts and supersession discipline suggest that export receipts should identify which earlier export or proof packet they supersede, and which compatibility window remains.
- **ViewFS:** materialization boundaries warn that a view/lens/export is not an owned object. Harbor keeps semantic exports derived and row-owning claims elsewhere.
- **Helm:** review queues and display-basis cues reinforce that dashboard-friendly metrics need visible basis, thresholds, and refusal explanations.
- **Ward:** tier witnesses and resolution bindings reinforce that shared-looking entities require cardinality/conformance proof before they become join keys.
- **Steward:** aftermath receipts reinforce that late corrections need explicit followthrough, not silent semantic-model regeneration.

## Harbor consequence
This pass closes `F073` by adding:

- `docs/00-meta/datacube-semantic-export-constraints.md` — a review checklist for derived semantic exports, contract subsets, freshness basis witnesses, fanout fences, and optional row-lineage sidecars;
- `docs/30-architecture/specimen-flow-73-semantic-export-contract-subset-fanout-sidecar-honesty.md` — a concrete public daily-provider-funnel export specimen;
- refreshed ledgers and pass notes keeping semantic exports as derived artifacts rather than canonical datacube schema.

## What stays open
- Whether a future SlopOS datacube gets a semantic front door at all.
- Whether export receipts become machine-readable cards.
- Whether row-lineage sidecars are worth retaining beyond debugging/restatement specimens.
- Whether public contract subsets should be generated from assertion tools or written directly in Harbor review language.
- Which sibling cube, if any, should own future UI display of semantic-export refusals.

For now, the companion lesson is clear: **export a bounded reviewed lens, not a constitution.**
