# SlopOS companions evaluation — 2026-05-25 pass CIX

## Overlay propagation after companion change

F103 let Harbor import companion withdrawals, supersessions, disputes,
expiries, corrections, and re-scopes as scoped overlays.  F104 asks how those
overlays travel to public and local surfaces without becoming badges.

## Companion-specific pressure

- **SlopOS** overlay propagation may update portal-net public wording, but
  accepted append history remains ordering evidence, not semantic repair.
- **Foundry** overlay propagation may update classification-label notes, but
  a new label pin is not Harbor truth.
- **Steward** overlay propagation may update retry-attempt summaries, but
  delivery of that notice is not fault, compliance failure, or repair.
- **Schell** overlay propagation may update retention-context warnings, but
  expiry or retention is not erasure proof.
- **ViewFS** overlay propagation may update consent/volition explanations,
  but display changes do not prove user outcome or comprehension.
- **Ward** overlay propagation may update delegation warning cards, but
  delegated route evidence is not authority transfer.
- **Helm** overlay propagation may quarantine repair traces, but it cannot
  make stale derivatives repaired or false.

## Next pressure

After F104, Harbor should pressure-test user-visible explanation bundles:
what minimum words, digests, scope maps, and stale-surface caveats must appear
in public overlay cards, generated summaries, and consumer notices before a
person can safely rely on them without receiving badge-shaped overclaim.
