# Research synthesis — pass XLII

This pass keeps Harbor narrow and learns three compatible things at once: **host-owned review surfaces may need to show more than one relevant party, structured return packages can get richer without becoming durable truth, and design-phase cubes need explicit promotion hygiene so specimen nouns do not fossilize by accident.**

## Outside lessons
1. **One visible party is not always enough.**  
   Recent FedCM work in Chrome 142 adds an option to display the embedded iframe domain in addition to the top-level site when a relying party is meaningfully third-party to the page that embeds it. That is a sharp reminder that one coarse requester cue can sometimes under-explain a crossing. Harbor should keep room for a **displayed-party split** without freezing a giant trusted-display registry.

2. **Structured return packaging is still just packaging.**  
   Recent FedCM work in Chrome 143 allows the `token` value returned by the ID assertion endpoint to be a structured JSON object instead of forcing a serialized string. That is a useful ergonomics improvement, but it does not magically turn the returned parcel into durable account, session, or approval truth. Harbor should preserve the lesson that a rich **return parcel** is still smaller than adopted consequence.

3. **Exact binding still outranks attractive UI and rich payloads.**  
   RFC 9700 requires exact string matching for registered redirect URIs (except localhost ports for native apps) and requires clients that talk to multiple authorization servers to prevent mix-up attacks by storing issuer identity per authorization request and aborting on issuer mismatch. Harbor should keep learning the old lesson: helpful display cues and well-shaped result parcels never replace exact request / issuer / lane binding.

4. **Display metadata remains advisory even when standards encourage showing it.**  
   OpenID Connect Dynamic Client Registration still says `client_name`, `logo_uri`, `policy_uri`, and `tos_uri` may be shown to end users, while also warning authorization servers to be extremely careful with end-user-visible URLs supplied by clients. Harbor should therefore keep preview surfaces advisory and resist any urge to turn client-supplied display metadata into durable issuer or approval truth.

5. **Design-phase hygiene is itself a semantic safeguard.**  
   SlopOS now carries an explicit boundary-singleton contract: a singleton seam must say why no broader family exists yet, and if a second close sibling appears, the archive must pay for explicit promotion in the same revision. Harbor should steal that process idea, adapted to embryo vocabulary growth, because stale singleton labels and accidental noun clusters are two faces of the same design-phase dishonesty.

## Resulting Harbor move
Do not decide yet whether Harbor needs durable nouns such as `displayed-party split`, `embedded-party cue`, or `return parcel`.
For this revision:
- add one specimen that pressure-tests embedded third-party display cues plus structured return packaging;
- add one explicit embryo-promotion contract so new noun clusters cannot linger by inertia;
- and keep exact issuer/basis/lane witnesses as the stronger truth while richer display and return surfaces remain smaller residue.

## Fresh ideas worth stealing
- **displayed-party split** — host-owned chooser/review UI may need to surface both the embedding site and the embedded requester when those are meaningfully different.
- **return parcel** — structured outcome package that can carry richer result detail while remaining smaller than durable adoption.
- **exact binding beats attractive packaging** — standing anti-regrowth rule: shiny UI and tidy JSON never outrank exact issuer, request, and lane checks.
- **same-revision promotion rule** — if a second closely related seam appears, pay for explicit structure in the same revision instead of letting a singleton or specimen noun linger by inertia.
