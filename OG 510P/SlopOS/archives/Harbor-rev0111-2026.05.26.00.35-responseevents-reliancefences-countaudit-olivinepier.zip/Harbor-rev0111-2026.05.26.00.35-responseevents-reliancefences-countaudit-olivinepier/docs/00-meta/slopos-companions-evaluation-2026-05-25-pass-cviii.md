# SlopOS companions evaluation — 2026-05-25 pass CVIII

## Companion import aftercare

F102 let Harbor import companion fragments as quarantined evidence.  F103 asks what happens when companions later change their minds, change their scopes, or publish stale/disputed corrections.

## Companion-specific pressure

- **SlopOS** can withdraw or supersede portal append history.  Harbor may retain ordering history and require recheck; it cannot infer semantic supersession or freshness.
- **Foundry** can supersede classification pins.  Harbor may quarantine or narrow label use; it cannot promote classification truth.
- **Steward** can correct retry history.  Harbor may adjust attempt history; it cannot infer compliance failure or fault.
- **Schell** can expire retention context.  Harbor may require recheck; it cannot infer erasure or repair.
- **ViewFS** can narrow volition/consent evidence.  Harbor may narrow consent-evidence use; it cannot infer user outcome.
- **Ward** can withdraw delegation warrants.  Harbor may recheck route/escalation authority; it cannot import authority transfer.
- **Helm** can dispute repair traces.  Harbor may quarantine derivative repair evidence; it cannot decide repair falsehood or completion.

## Next pressure

After F103, Harbor should test a public correction/export story where a revocation overlay has to reach consumers, mirrors, summaries, and local derivative indexes without becoming a public green/red badge or compliance workflow.
