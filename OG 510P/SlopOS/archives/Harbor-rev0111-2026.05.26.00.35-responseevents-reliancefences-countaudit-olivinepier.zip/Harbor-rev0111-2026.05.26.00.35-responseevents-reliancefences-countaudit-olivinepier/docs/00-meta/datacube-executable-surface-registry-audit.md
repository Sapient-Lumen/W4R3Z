# Datacube executable surface registry audit

Rev0108 added a small maintenance registry for executable proof slices.  Rev0111 extends that registry through F106 and adds a registry-derived executable-slice count phrase so landing-page audits do not hardcode a spelled-out count.

The registry is not part of Harbor's semantic model.  It is a refactor to reduce duplicated checker lists, make missing proof-slice paths fail early, and keep visible briefing counts aligned with the actual registered executable surfaces.

`tools/harbor_executable_surface_registry.py` lists F090 through F106 with their meta doc, specimen, verification doc, fixture, harness, checker, checker module, and originating revision.  It also exposes:

- `EXECUTABLE_SURFACE_COUNT`;
- `EXECUTABLE_SURFACE_COUNT_PHRASE`.

`tools/check_all.py` imports that registry and runs the registry-provided checker order.

`tools/check_harbor_executable_surface_registry.py` verifies:

- executable ids are contiguous F090-F106;
- every registered meta doc, specimen, verification doc, fixture, harness, and checker exists;
- every registered F-item is marked `done`;
- specimen path numbers match F-item numbers;
- the latest registry entry matches `SURFACE-STATUS.json`;
- latest registry paths are present in `RELEASE-MANIFEST.json`;
- README states the registry-derived executable-slice count phrase;
- the registry refuses conformance, trust-root, CI, certification, or promotion-gate semantics.

The registry exists to catch drift.  It does not establish correctness, conformance, security, compliance, authority, public truth, or final SlopOS datacube shape.
