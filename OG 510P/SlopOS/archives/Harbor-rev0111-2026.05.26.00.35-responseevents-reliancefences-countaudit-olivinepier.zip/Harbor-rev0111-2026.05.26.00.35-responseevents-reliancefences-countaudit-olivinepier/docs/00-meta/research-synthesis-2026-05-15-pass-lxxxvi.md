# Research synthesis — pass LXXXVI, public correction and dispute hygiene

**Revision:** `rev0086`  
**Date:** 2026-05-15  
**Question:** How should Harbor treat corrections, errata, annotations, stale citations, generated explanations, and consumer disputes over public datacube copies without freezing an annotation platform, DOI policy, moderation workflow, or final SlopOS datacube shape?

## Result

Harbor should treat post-release feedback as **status-bearing residue** with explicit targets and provenance:

- a correction anchor points to affected artifacts, labels, digests, cuts, and successor status;
- an erratum receipt carries human-readable correction text while preserving machine label IDs and non-promises;
- an annotation receipt names body, target, selector, provenance, review status, and safety lane;
- a stale-citation witness says whether a citation is current, stale, superseded, dead, unverifiable, or external-only;
- a generated-explanation receipt tethers model output to source artifacts, label digests, omitted labels, review status, and invalidation triggers;
- a dispute packet records contested labels/cells/explanations while protecting sealed evidence and safe refusal lines.

This is intentionally smaller than schema. It is a pressure-test surface for keeping public copy status, annotation status, citation status, explanation status, and dispute status separate.

## External lessons folded in

- W3C Web Annotation gives the body/target split that Harbor should steal: annotations can link resources while recording target identity, format, language, selectors, and bodies. Harbor should use this shape without making every annotation a verdict.
- Crossref Crossmark shows a durable current-status pattern for content that may later be corrected, retracted, or updated, including PDFs that readers downloaded earlier. Harbor should steal the “status check near the work” habit without adopting scholarly publishing workflows wholesale.
- NISO CREC emphasizes metadata creation, transfer, and display for original items and retraction/removal/expression-of-concern statements so readers can identify editorial status. Harbor should steal the display/transfer discipline for public datacube corrections.
- Schema.org `correction` and `CorrectionComment` show a lightweight web vocabulary for associating a correction with a CreativeWork. Harbor should steal the pointer shape while retaining its own digest/cut/label proof obligations.
- DataCite related identifiers distinguish new versions, previous versions, canonical-version relations, and obsoleted/corrected versions. Harbor should steal relation clarity for restatements and corrections rather than overwriting old copies.
- JATS related-article types distinguish corrected articles, correction-forward links, retractions, partial retractions, and related commentary. Harbor should steal the typed relationship lesson without becoming a journal-article model.
- NIST AI RMF and C2PA both reinforce provenance/documentation pressure for generated or transformed content. Harbor should therefore treat generated explanations as derived, provenance-bearing copies with invalidation and review tethers.

## SlopOS-specific interpretation

SlopOS is still design-phase. That makes it dangerous to freeze Harbor around one feedback product or public-correction substrate. The safer move is to preserve SlopOS's existing boundary instincts:

- imported annotations, resource hints, and tool hints remain advisory unless a reviewed seam promotes them;
- external-source/citation hygiene separates operational heads from citation-ready reviewed heads;
- LLM/generated explanations stay derived and review-bound, not authority;
- display surfaces and accessibility variants do not become trusted modal or approval truth;
- bounded observation/export policy still controls what can be disclosed when a dispute asks for hidden evidence.

## New watchlist handles

- `correction_anchor`
- `erratum_receipt`
- `annotation_receipt`
- `stale_citation_witness`
- `generated_explanation_receipt`
- `consumer_dispute_packet`
- `public_status_banner`
- `explanation_invalidation`

These handles are not promoted. They merely name the next obvious place where post-release public feedback can counterfeit truth.

## What stayed open

- annotation protocol or storage;
- moderation and abuse handling;
- ticketing / support workflow;
- DOI or identifier policy;
- citation resolver / link checker;
- generated-explanation system;
- public status banner vocabulary;
- legal withdrawal / removal process;
- final SlopOS datacube shape.
