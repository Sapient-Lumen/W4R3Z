# Research synthesis — 2026-05-13 pass LXXIX

Question: how should Harbor pressure-test the `F074` option-reservation cluster — observation-shaped exchange exports, versioned derived-view definitions, statistics/lineage sidecars, watermark/frontier witnesses, assertion-compiler targets, and schema-transform receipts — without choosing a warehouse, RDF stack, streaming engine, semantic layer, data-quality product, sidecar registry, or universal datacube API?

## Result of this pass
The strongest next move is to treat each tempting artifact as a **cut with an anti-counterfeit warning**, not as a new Harbor constitution.

The pass therefore adds:

- `docs/00-meta/datacube-option-reservation-cuts.md` — a compact review surface for option-reservation artifacts that are useful enough to test but not mature enough to promote; and
- `docs/30-architecture/specimen-flow-74-option-reservation-export-view-sidecar-frontier-compiler.md` — a specimen that exercises the whole cluster together.

This closes `F074` while preserving the design-phase stance: Harbor can collect brilliant external shapes, name the proof packets they would need, and refuse counterfeit authority before SlopOS or the sibling cubes have settled a final datacube architecture.

## External lessons folded into this pass
1. **Observation-shaped exchange is useful precisely when it is small.** W3C RDF Data Cube shows the value of explicit observations, dimensions, measures, attributes, and dataset structure, but Harbor should steal the component discipline rather than adopt RDF, SDMX, or a single statistics ontology as its permanent API.

2. **A derived view is metadata with an evolution story, not row truth.** Iceberg view metadata keeps schema, properties, current and past versions, and SQL representations with dialect tags. Harbor should borrow the view-version receipt shape: source cuts, dialect/engine basis, invalidation conditions, and compatibility notes. It should not treat a view definition as owned data, a proof of reproducibility, or a guarantee that every engine interprets the SQL the same way.

3. **Sidecars are helpful only while they stay optional and interpretable.** Puffin's blob+metadata posture, Iceberg optional table statistics, OpenLineage facet schema URLs, and row-lineage caveats all point to the same rule: sidecars can speed debugging, planning, lineage, and review, but a missing sidecar must not mean missing data and a present sidecar must not strengthen the base contract unless the contract explicitly says so.

4. **Watermarks and frontiers are progress claims with domains.** Flink watermarks advance event-time progress. Materialize exposes read/write frontiers that say where correct immediate answers are possible or where output may still change. Timely-style frontiers generalize progress tracking. Harbor should steal the idea of a frontier witness, while keeping it separate from occurrence time, published-cut time, freshness, completeness, and late-arrival restatement.

5. **Assertion compilers produce target artifacts, not truth.** DataHub's Open Assertions model shows a declarative assertion can compile into tool-specific checks. The Harbor lesson is to require compiler receipts that name the source assertion, target engine, generated artifact, unsupported semantics, and evidence return channel. A compiled dbt test, warehouse check, Great Expectations expectation, Snowflake DMF, or monitor config is not the assertion's meaning by itself.

6. **Schema transforms need semantic non-equivalence warnings.** OpenTelemetry schema files and other schema-resolution systems make mechanical migration feasible, but a transform receipt should say what changed, what was not preserved, and which consumers were replay-tested. Mechanical conversion is not proof of identical meaning.

7. **SlopOS makes export policy a choke point.** CH-OBSPOL's allowlist/bounds/fail-closed shape and RFC-0097's mutable-data migration gates are exactly the sibling discipline Harbor needs: if a datacube artifact crosses a boundary, the export must name what left, why it was allowed, which cut it used, and when it becomes invalid.

## New process shape
`docs/00-meta/datacube-option-reservation-cuts.md` names six process handles:

- observation exchange receipt;
- derived-view receipt;
- sidecar interpretation note;
- frontier / watermark witness;
- assertion compiler receipt;
- schema transform receipt.

These are not new canonical schema objects. They are review vocabulary for specimens and future promotion packets.

## Specimen selected
Specimen flow 74 models a `callback-observation-exchange-v0` export over the existing callback-attempt theme:

- an observation-shaped exchange export with explicit component roles and non-RDF posture;
- a versioned derived-view receipt that owns no data and pins source cuts, SQL dialect, grouping basis, and invalidation conditions;
- a statistics sidecar and partial lineage sidecar that remain optional evidence;
- an event-time watermark plus published-cut frontier witness that identifies what can still change;
- an assertion compiler receipt that translates a public freshness/non-null/uniqueness subset into one target artifact while recording unsupported semantics; and
- a schema transform receipt that maps an older observation field name to a newer one while refusing semantic-equivalence overreach.

## Still not decided
- one observation vocabulary, RDF/JSON/Parquet layout, or API envelope;
- one warehouse, lakehouse, stream processor, semantic layer, catalog, assertion engine, or schema registry;
- one view dialect, lineage field, sidecar registry, or statistics format;
- whether SlopOS's final datacube exposes observations, views, contracts, or sidecars at all;
- whether any of the six option-reservation handles become first-class Harbor cards.

The deeper lesson is: **option reservations are useful because they let Harbor rehearse the seam before deciding. Every reservation must carry a counterfeit detector.**
