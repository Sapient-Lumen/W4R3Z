# Research synthesis — pass XCVIII, property/mutation coverage without schema promotion

**Revision:** `rev0098`  
**Date:** 2026-05-22  
**Question:** How should Harbor increase confidence in executable bundle checkers without turning generated cases into schemas, conformance suites, or coverage theater?

## Result

Harbor should add deterministic targeted mutation coverage, not stochastic fuzzing and not a general property-testing framework dependency. F093 therefore introduces a meta-bundle that imports the F090/F091/F092 emitted bundles, applies named one-step mutations, and records whether the existing checkers kill those mutants.

The core split is:

```text
baseline bundle -> property claim -> mutation operator -> mutated bundle -> checker result -> shrink note -> coverage summary
```

This gives Harbor a repeatable place to say which counterfeits its checkers currently catch, while preserving the rule that finite fixtures and generated mutants are evidence, not public schema law.

## External lessons folded in

- Property-based testing systems such as Hypothesis emphasize generated examples, replayability/settings, and shrinking. Harbor borrows the shrink/replay posture but refuses a framework dependency in the embryo repo.
- Mutation-testing systems such as Stryker distinguish killed and survived mutants. Harbor borrows that vocabulary while refusing numeric mutation-score gates.
- Coverage tools distinguish exercised code from unexercised code, and branch coverage is about possible transitions versus observed transitions. Harbor borrows the humility: coverage is a diagnostic, not correctness.
- Coverage-guided fuzzers such as AFL++ value small corpora of interesting cases. Harbor borrows corpus-shrink discipline but does not promote a fuzzer corpus or stochastic campaign.

## New executable surfaces

- `docs/00-meta/datacube-property-mutation-coverage.md`
- `docs/40-verification/harbor-property-mutation-coverage-bundle-v0.md`
- `fixtures/harbor-property-mutation-coverage-bundle-v0.json`
- `tools/harbor_property_mutation_harness.py`
- `tools/check_harbor_property_mutation_bundle.py`
- `docs/30-architecture/specimen-flow-93-property-mutation-coverage-without-schema-promotion.md`

## New watchlist handles

- `mutation.operator`
- `baseline.digest`
- `mutant.digest`
- `checker_reason`
- `killed_by_checker`
- `survived_and_requires_new_fixture`
- `minimal_target`
- `generated_case_retains_operator_name`
- `do_not_auto_promote_to_fixture`
- `coverage_claim`

## Practical design rule

A generated negative case may become Harbor evidence only when it carries:

```text
operator id + bundle target + invariant list + baseline digest + mutant digest + checker reason + minimal shrink target + human-readable counterfeit explanation + explicit non-promotion list
```

A generated negative case may not become durable fixture vocabulary merely because a script emitted it.

## Followthrough result

`F093` is complete. `F094` should pressure-test failure intake: what happens if a mutation survives, a hand-authored hostile fixture contradicts a generated mutant, or a checker becomes too strict and kills an intentionally equivalent mutation? The next seam is not more generated cases. It is triage discipline for generated evidence.
