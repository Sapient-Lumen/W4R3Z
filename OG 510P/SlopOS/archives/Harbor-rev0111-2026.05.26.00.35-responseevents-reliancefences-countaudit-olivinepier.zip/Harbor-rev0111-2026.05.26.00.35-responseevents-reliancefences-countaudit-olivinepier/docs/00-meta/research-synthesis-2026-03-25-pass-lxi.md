# Research synthesis — pass LXI

This pass deliberately steps up one layer from protocol detail and learns seven compatible things at once: **a datacube must declare its grain before it grows dimensions or measures; atomic history is still the safest default when questions are unpredictable; late-arriving context and historical restatement are normal rather than edge cases; logical semantics should stay separate from physical layout and partitioning tricks; schema evolution should prefer additive/non-destructive moves when possible; stable downstream contracts belong on curated surfaces rather than every raw seam; and optional metadata should begin life as versioned sidecars/facets before Harbor promotes them into core truth.**

## Outside lessons
1. **Grain is the first contract, not a cleanup step.**  
   Kimball keeps insisting on this because teams still get it wrong: declare the grain before choosing dimensions or facts, and start from atomic grain when future questions are not yet known. Harbor should therefore preserve a **grain contract card** before it even considers a wider dimension/measure bloom.

2. **Mixed grain is where honest cubes go to die.**  
   Kimball’s dimensional guidance also warns that different grains belong in different physical tables, and that drilling across works by aligning separate result sets on conformed attributes rather than by stuffing unlike facts into one pseudo-table. Harbor should not quietly mix request-turn, detour-turn, and aftermath/restatement facts into one convenience row.

3. **Late-arriving context and restatement are normal.**  
   Kimball’s late-arriving fact and late-arriving dimension guidance makes the old lesson explicit: facts can arrive before full dimensional context, placeholder rows may be needed, and retroactive type-2 changes can force restatement. Harbor should therefore keep **late context**, **correction**, and **restatement receipt** visibly separate instead of hiding everything behind “latest row wins.”

4. **History policy must be explicit.**  
   Kimball’s slowly changing dimension guidance is still useful because it distinguishes error correction from history-preserving change and warns that some overwrite styles destroy history. Harbor should keep field-level or card-level history posture explicit instead of pretending every shape change has the same semantics.

5. **Physical layout should not leak into logical meaning.**  
   Iceberg’s hidden partitioning and partition evolution posture is the cleanest modern reminder here: producers and consumers should not need to know the partition layout, and partition schemes should evolve without changing query semantics. Harbor should steal the **logical-versus-physical split** while refusing to commit to Iceberg itself.

6. **Additive evolution beats destructive rewrites.**  
   Iceberg supports in-place schema evolution, and Anchor Modeling goes even further by showing additive schema evolution, absence-of-rows instead of overloaded `NULL`, and database evolution without altering existing tables. Harbor should therefore prefer a **late-bound evolution lane** and optional sidecars/facets before it rewrites old history or redefines old cards.

7. **Stable downstream contracts should be curated.**  
   dbt’s model contracts are useful because they enforce a predictable dataset shape for downstream consumers, while the dbt Semantic Layer separates entities, dimensions, and metrics into a more deliberate interface. Harbor should steal the idea of a **curated semantic front door later**, but only after the cube’s own pressure classes stabilize.

8. **Optional metadata wants versioned facets, not early schema inflation.**  
   OpenLineage’s facet model is elegant for design-phase work: metadata can remain atomic, custom facets need distinct prefixes, and the schema URL for a given version should be immutable. Harbor should therefore preserve a **facet-version note** for optional or experimental annotations instead of promoting them immediately into the core row contract.

9. **Change history deserves explicit instants and feeds.**  
   Hudi’s timeline distinguishes requested versus completed instants, while Delta Lake’s change data feed records row-level inserts, updates, and deletes with metadata. Those are excellent ideas to steal conceptually: Harbor should preserve explicit change receipts and history lanes. But Delta’s own docs also warn that non-additive schema changes complicate change feeds, which is a reminder not to pretend any change-log surface is magically semantics-proof.

## Resulting Harbor move
Do not choose an engine, table format, or semantic-layer product yet.
For this revision:
- add one specimen where Harbor must distinguish mixed grain, additive evolution, and optional sidecar metadata;
- add one repo/process surface that states the design-phase datacube rules plainly;
- keep physical layout, semantic contract, history policy, and optional facets visibly separate; and
- treat modern table-format / semantic-layer features as **stealable ideas**, not commitments.

## Fresh ideas worth stealing
- **grain contract card** — compact declaration of what one Harbor row/card/receipt actually represents.
- **late-bound evolution lane** — explicit path for adding new fields or sidecars without rewriting old meaning.
- **facet-version note** — optional annotation with its own versioned schema identity, smaller than the core contract.
- **restatement receipt** — typed note that history was recomputed or corrected, distinct from ordinary arrival.
- **requested-versus-completed change pair** — tiny two-step chronology for mutation surfaces.
- **semantic front door** — a later curated entities/dimensions/metrics layer, but only after Harbor’s own nouns stop moving every revision.
