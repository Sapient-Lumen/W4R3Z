# SlopOS / companions evaluation — pass LXXI

This pass asks a design-phase datacube question rather than a warehouse-product question: if Harbor starts lining up shared dimensions across its own lanes and across sibling cubes, how does it avoid turning “helpful alignment” into a counterfeit canonical entity model?

## What the companions teach this pass
- **SlopOS** remains the strongest process teacher because it keeps closed sets, singleton seams, promotion criteria, and source-review surfaces explicit. The transferable lesson is that conformance should also stay explicit: if a shared dimension is only a subset, a bridge, or a provisional convenience surface, Harbor should say so in the same revision rather than letting conformance drift by folklore.
- **Foundry** keeps teaching residue-class discipline. For Harbor, that becomes the reminder that local-only keys, bridged mappings, and genuinely shared dimensions are different residue families even when they all look like IDs.
- **Ward** keeps teaching resolution bindings and tier honesty. That transfers well here: one “canonical” identifier can be operationally useful while still being only a weaker resolution product rather than final truth.
- **Steward** keeps teaching receipts and history policy. That matters for bridge maintenance too: if a mapping changes, splits, or collapses, Harbor should leave bridge witness residue and time-bounded notes rather than silently rewriting yesterday’s alignment.
- **ViewFS** keeps teaching fresh-identity and open-in-place humility. Harbor can reuse that instinct: imported or neighbor-supplied IDs are useful, but they should not automatically become Harbor’s final account/entity ontology.

## Harbor consequence
Harbor should make exactly one modest repo/process expansion now:
- add a datacube conformance-lanes surface;
- add one specimen around conformance-lane cards, bridge witnesses, identity-shadow notes, and shrunken conformance slices;
- refresh the load-bearing source register with living sources that keep conformed-dimension, bridge-discipline, shrunken-slice, and explicit-join ideas visible; and
- keep semantic-front-door pressure alive without pretending this pass chooses a final MDM stack, entity registry, or semantic-layer product.

## Still-not-yet decisions
- whether Harbor later needs one shared machine-readable entity/conformance registry with sibling cubes;
- whether bridged mappings later become published first-class artifacts or remain narrower review residue;
- whether a provisional canonical identifier ever becomes more than an identity shadow note; and
- whether shrunken conformance slices later need stronger drift gates.

For now, the companion lesson is enough: **separate exact shared dimensions, bridged alignment, and convenience identity surfaces before a design-phase key becomes fake authority.**
