## Pass CVIII additions

- Steal the notion of invalidation/revision as new provenance facts, but do not steal the whole provenance stack.
- Steal update-system paranoia about expiration, rollback, and freeze checks, but do not let "newer" mean "fresh enough".
- Steal external-document-reference discipline for cross-cube fragments: parent context and digest first, local meaning later.
- Steal a registry for executable surfaces only as drift control; refuse to make it a dashboard, badge, trust root, or conformance suite.

## Pass C additions
- Steal SLSA's where/when/how provenance posture for checker observations, but refuse to import its ecosystem as a trust badge.
- Steal OPA decision-log humility: policy/checker decisions should carry input and bundle context for audit, not ambient authority.
- Steal reproducible-builds build-environment recording as a future package-release seam, not as a claim Harbor already satisfies.

## Pass XCIX additions

- **Steal PIT's equivalent-mutant caution.** Killed/survived vocabulary is useful only when equivalent behavior is explicitly triaged.
- **Steal AFL++ corpus minimization humility.** Keep a small corpus of distinct pressure, not a bloated pile of duplicate cases.
- **Steal coverage-tool skepticism.** Coverage and mutation numbers can guide review but must not become correctness badges.
- **Steal SlopOS replay discipline.** A checker result should carry enough basis to replay or distrust it later.
- **Steal triage queues from vulnerability practice.** A survivor needs classification, owner, disposition, and promotion/refusal notes before it changes a checker.
- **Steal shrink notes.** The smallest human-readable counterfeit is better Harbor residue than a giant generated blob.

## Pass XCVII additions

- **Steal SLSA's verifier expectation split.** Provenance matters only when checked against expected builder/source/ref/policy; Harbor should require the expectation next to the result.
- **Steal Sigstore Policy Controller's admission humility.** Admission-time policy decisions are useful, but they are not future reliance, user comprehension, or global approval.
- **Steal TUF's stale-metadata paranoia.** Version, expiration, rollback, and freeze checks are the right mood for policy epochs and currentness.
- **Steal C2PA validation-status presentation humility.** Validation output should help users judge; it should not silently mint one truth badge.
- **Steal in-toto's layout/inspection basis.** A verifier's answer depends on the layout, links, inspections, and available evidence. Preserve that basis.
- **Steal OPA decision/bundle traceability.** Policy id, policy digest, bundle revision/metadata, input, and decision trace are required before comparing policy runs.
- **Steal badge refusal.** Product surfaces want green checks; Harbor should make withheld/split/scoped/recheck/incomparable postures first-class.

## Pass XCIII additions

## Pass XCIV additions
- **Steal a tiny crossing record.** Subject, route, admission, scope, outcome, and aftermath are enough to pressure-test crossings without freezing schema.
- **Steal scope algebra.** Let `incomparable` be a first-class answer when status surfaces use similar words for different audiences, cuts, or windows.
- **Steal warning lifecycle receipts.** Re-escalation, narrowing, holding, and sunset should be explicit decisions with evidence windows and non-promises.
- **Steal hostile receipt fixtures.** Wrong digest, wrong audience, backdated, copied, label-stripped, authorityless, and hidden-exclusion receipts should be routine negative tests.
- **Steal SlopOS append humility.** Accepted-only append history is great evidence of local record order and terrible evidence of retroactive repair.
- **Steal CSAF's remediation category discipline, not its advisory kingdom.** `vendor_fix`, `optional_patch`, `workaround`, `mitigation`, `fix_planned`, and availability dates are useful shapes for correction instructions, but Harbor should keep them outside the base datacube schema.
- **Steal OpenVEX's subject-bound minimality.** Implementation status should stay attached to exact subject/cut/digest windows, not float as a global fixed badge.
- **Steal in-toto's step evidence shape.** A correction implementation receipt can name subject, materials, step/action, environment, byproducts, and unsupported conclusions without adopting the attestation framework.
- **Steal PROV/DataCite relation clarity.** Successor public copies, invalidated copies, reviewed copies, variants, translations, and prior versions should be named explicitly instead of rewritten away.
- **Steal status-page separation of active update, resolved state, and postmortem.** Harbor should keep public banner, proof packet, recheck receipt, and learning note as different surfaces.

## Pass XCII additions

- **external finding return receipt** — scoped outside response with issuer, authority basis, subject, evidence lane, and expiry.
- **scope normalization note** — compare subject/window/audience/method/evidence before declaring contradiction.
- **authority conflict map** — source-owner, auditor, regulator-facing, reporter, and transparency claims can disagree without a default winner.
- **finding adoption note** — separate Harbor-local effect from outside speech: wording, warning, correction task, consumer guidance, or no effect.
- **correction instruction receipt** — distinguish mandate, recommendation, advisory note, proposal, and clarification request.
- **sealed finding expiry note** — current reliance can expire while historical evidence remains.
- **appeal outcome receipt** — apply remedy without memory holes.
- **post-review public-copy update note** — say whether data, labels, wording, status, or guidance changed after outside review.

## Pass XCI additions

- From CERT/CC CVD and ISO/IEC 29147: require report/handoff packets to name stakeholders, requested action, disclosure/remediation information, communication path, and failure modes.
- From FIRST PSIRT/CSIRT: separate intake, triage, coordination, notification, and status communication instead of collapsing them into one escalation bit.
- From FIRST TLP and IEP: make sharing restrictions travel with the evidence, and require explicit permission for wider sharing when the label demands it.
- From IETF appeals: require challenged decision, grounds, remedy sought, factual content, scope boundaries, public-record posture, and deadline.
- From SCITT/Rekor-style transparency: use signed/logged receipts for accountability while refusing to treat inclusion as current truth.
- From in-toto/SLSA: bind every claim packet to subjects, predicates/policies, digests, and verifier context; unrecognized or unsupported fields do not magically carry authority.
- From SlopOS: keep exports policy-killable, no-secret-in-band, verifier-local, and smaller than native trust.

## Pass XC additions

- **recurrence pattern receipt** — compact pattern evidence naming subject, window, copy/claim family, target, labels, evidence lane, and non-promises.
- **regression guard receipt** — old remediation plus new stale observation without overwriting either.
- **serial acknowledgement note** — acknowledgement history with expiry/recheck posture, kept smaller than repair or refusal.
- **claim reliability limiter** — claim-family limitation that refuses to become actor or reporter score.
- **reporter claim outcome map** — field-by-field report handling: confirmed, rejected, unresolved, scope mismatch, unsafe to assess.
- **escalation/cooldown/sunset note** — explicit criteria for active warning, external review, cooldown windows, historical-only sunset, and non-promises.
- **public-log/status divergence note** — small receipt when logged/signed/publication evidence and current status surfaces do not agree.
- **standing challenge with exit conditions** — a named challenge that can renew, downgrade, or close rather than becoming a permanent blacklist.

## Pass LXXXIX additions

- **VEX/CSAF scoped status discipline.** Steal status/action/justification fields that bind claims to named subjects; do not import vulnerability-advisory governance.
- **in-toto subject/predicate/envelope separation.** Use the shape to keep remediation and use attestations about a named subject rather than general truth.
- **SCITT/CT/Rekor transparency humility.** Inclusion, consistency, and signed-statement receipts are excellent evidence that something was published; they must not become semantic verification.
- **C2PA active-manifest and assertion/claim packaging.** Useful for generated explanations and public assets where provenance can update, drift, or be embedded/remote; not a Harbor proof stack decision.
- **PROV consistency and equivalence checks.** Before saying two claims conflict, normalize subject/version/audience/window/method and see whether they are actually comparable.
- **Status-page object separation.** Incidents, components, updates, subscribers, and postmortems are distinct; Harbor can steal that separation while rejecting a status-page product commitment.
- **NIST response/recovery/learning posture.** Treat disputed remediation as ongoing risk response with recovery evidence and lessons, not a one-bit incident badge.

## Pass LXXXVIII additions
- **stale use impact packet** — one bounded packet for a stale downstream report, dashboard, dataset, eval, agent answer, or policy use.
- **consumer acknowledgement receipt** — proof that a correction notice was received, with scope and authority, while staying smaller than remediation.
- **remediation attestation** — downstream owner claim naming subject, action, evidence, result status, residual risk, and recheck/expiry.
- **use attestation note** — scoped used/not-used/unknown statement with method, window, limitations, and expiry.
- **safe public impact statement** — public copy that says what changed, what is known stale, what to use now, and what Harbor does not claim.
- **residual risk note** — reusable reminder that old reports, dashboards, cached copies, old decisions, stale evals, archives, and user copies may persist.
- **unrepairable-now notice** — honest status for model/eval/archive/crawl copies that can only be warning-labeled or quarantined now.
- **historical-only / unsafe-for-new-use split** — old copy may remain visible as history while being refused for fresh analysis.

## Pass LXXXVII additions
- **propagation target register** — small scoped list of catalogs, mirrors, caches, snippets, agents, indexes, datasets, and archives known to carry a public copy.
- **catalog status sync receipt** — evidence that catalog metadata, human description, version relation, and downloadable artifact agree or drift.
- **mirror revalidation receipt** — observed payload digest, label digest, status banner, and validation time for a downstream copy.
- **cache invalidation receipt** — purge/revalidate action with old/new validators and attempt-versus-observed-success posture.
- **search snippet stale witness** — record that a search result, answer snippet, or preview quotes superseded text while the source is already corrected.
- **agent explanation invalidator** — trigger that marks generated explanations or retrieval answers stale when labels or correction status changes.
- **retrieval index refresh receipt** — proof that text and machine labels both survived re-indexing; re-embedding alone is not enough.
- **training/evaluation stale-copy notice** — downstream dataset/model/eval card warning that names absorbed stale material without claiming unlearning.
- **external mirror unreachable notice** — visible record that a stale public copy cannot be updated and must be treated as historical or unsafe for new use.
- **propagation horizon note** — named target set plus unknowns, no-authority targets, refused updates, and retry posture.

## Pass LXXXVI additions
- **correction anchor** — compact old/new status tether naming affected artifact, digests, labels, correction class, successor relation, and non-recall promises.
- **erratum receipt** — translated or human-readable correction notice that preserves machine label IDs, language/locale posture, reviewer source, and unresolved terms.
- **annotation receipt** — body/target/provenance/review-status residue for comments, flags, disputes, reviewer notes, and machine notes.
- **stale citation witness** — compact note saying whether a citation is current, stale, superseded, dead, unverifiable, or merely external background.
- **generated explanation receipt** — source/label/prompt/model/review tether that keeps LLM or machine-written explanation smaller than proof labels.
- **consumer dispute packet** — safe process residue for contested suppression/noise/exactness labels that does not reveal sealed evidence.
- **public status banner** — small current-status cue that keeps current, corrected, superseded, disputed, withdrawn, stale-copy, and explanatory-only states distinct.

## Pass LXXXV additions
- **Locale receipt:** steal the resolved-options habit from internationalization APIs, but keep it display-only and source-bound.
- **Translated-label set:** steal glossary/reviewer discipline from translation practice, but preserve machine label IDs and non-promises as the proof spine.
- **Accessible table twin:** steal the chart-plus-data-table pattern from accessibility guidance, but require labels and source links to travel with the table.
- **Long-description tether:** steal the idea that complex charts need short and long text alternatives, then bind those alternatives back to the labeled release bundle.
- **Summary tether:** steal plain-language summaries, but downgrade them to explanatory-only unless they preserve proof labels.
- **Render-transform note:** steal sort/filter/group/pagination transparency from data-grid UX and make it a receipt, not a renderer constitution.
- **Renderer-drift refusal:** steal fail-closed posture from export policy: a pretty copy that strips warnings is invalid until repaired.

## Pass LXXXIV additions
- **public-copy label** — a small machine-readable plus human-readable label set that must travel with the released payload.
- **release artifact receipt** — digest-bound note of public artifact id, source/public cut, release mode, label set, audience, and exactness/additivity consequences.
- **label-preservation check** — review gate that rejects exports whose format, mirror, or chart cannot carry the labels that made the release honest.
- **mirror receipt** — compact record of mirror identity, last validation, digest/label match, freshness, and restatement status.
- **restatement chain** — explicit relation from old public copy to new public copy without rewriting historical release evidence.
- **recomposition guard** — warning that certain public copies, filters, or sibling tables cannot safely be combined.
- **proof-of-copy ticket** — scoped digest/manifest/label proof that a copy matches a release without opening raw replay evidence.
- **withdrawal-not-recall posture** — standing reminder that public deprecation and safety warnings do not guarantee downstream erasure.

## Pass LXXXIII additions
- **release cell** — a small note that names the metric, grouping, source cut, exactness-before-treatment, and public release mode.
- **small-cell guard** — contributor-count and denominator posture kept hidden enough to avoid leaking the threshold but explicit enough to justify suppression or collapse.
- **dominance guard** — separate check for magnitude cells dominated by one or a few contributors even when counts are not small.
- **sibling-cut set** — the already-released and candidate tables/cuts that can be differenced against the new answer.
- **repeated-query ledger** — scoped process residue that notices near-neighbor queries becoming unsafe together without becoming a durable user blacklist.
- **disclosure-budget note** — a humility label for privacy-accounting pressure, not a grant, token, or global privacy engine.
- **noise/perturbation receipt** — public-copy label that says whether exactness, additivity, or reconciliation was weakened and whether any DP claim is actually supported.
- **safe refusal copy** — consumer-facing text that offers coarser alternatives without revealing the hidden cell or threshold.

## Pass LXXXII additions
- **evidence audience card** — a tiny note separating consumer, contract-consumer, auditor, operator, source-owner, and no-export evidence views.
- **redaction cut** — a proof packet label that says what was removed, transformed, disclosed, sealed, or refused and which proof obligations survived.
- **verifier ticket** — scoped, expiring, revocable review residue naming allowed claims, source locks, verifier materials, and non-recursive fetch posture.
- **source-lock drift note** — a warning when old policy/source/runtime digests differ from the current verifier basis and no equivalence proof exists.
- **derived-proof packet** — selected-statement proof that stays visibly smaller than raw replay and does not grant row-level access.
- **disclosure transcript digest** — compact residue of what evidence view was shown, to whom, under which ticket, without becoming public data truth.
- **sealed payload reference** — exact evidence exists and is digest-bound, but disclosure is operator-only, enclave-only, source-owner-only, or refused.

## Pass LXXVI additions
- **option-reservation card** — a tiny borrowed-idea watchlist record with `why interesting`, `why not decided`, `promotion trigger`, and `anti-counterfeit rule` fields.
- **observation-shape lint** — a review check that asks whether each visible value has an observation grain, component role, unit/measure posture, and presence/evidence class before export.
- **derived-view receipt** — a versioned view/lens note that names base cut, dialect/runtime, lineage inputs, freshness basis, and invalidation rule while owning no data.
- **statistics/blob sidecar** — a namespaced optional artifact for histograms, sketches, indexes, NDV, or cost hints that never upgrades the base contract silently.
- **facet-promotion path** — a way for metadata to begin as an optional namespaced facet and earn promotion only after repeated specimens prove it belongs in core vocabulary.
- **watermark/frontier witness** — a source-scoped event-time progress claim that stays visibly weaker than finality and carries late-data/restatement posture.
- **row-lineage receipt** — scoped source-row trace residue useful for restatement/debug behavior but forbidden from becoming global identity.
- **assertion-compiler target** — reviewed assertion intent compiled to multiple runtimes while keeping promise, evidence, consequence, and waiver posture separate.
- **schema-transform receipt** — a consumer-facing version bridge that names what was preserved, mechanically transformed, weakened, or lost.
- **semantic-export refusal mode** — a semantic model export that explicitly says which joins, rollups, freshness bases, or dimensions it refuses rather than emitting flattering nonsense.
- **sibling-cube borrow card** — a small citation to Foundry/Steward/Schell/ViewFS/Helm/Ward discipline that borrows the pattern without importing the sibling's authority.

## Pass LXXV additions
- **datacube review loop** — one explicit checklist that forces research refresh, pass notes, ledger updates, and deterministic packaging together.
- **contract subset** — let a published promise name only the selected assertions Harbor is willing to stand behind publicly.
- **freshness-basis witness** — carry the clock, threshold, and last-seen basis beside any freshness claim.
- **join-relationship note** — compact declaration of base-grain key, expected join relationship, and fanout hazard.
- **delete-mode / history-loss witness** — compact note saying whether deletes, tombstones, before-images, or carry-over rows were preserved, rewritten, or dropped.
- **row-lineage sidecar** — optional lineage receipt or sidecar kept visibly smaller than row meaning and smaller than any universal row-ID constitution.
- **compiled semantic front door** — treat semantic-model YAML, explores, or metric APIs as generated exports until Harbor intentionally promotes them.


## Pass LXXIV additions
- **measurement-kind card** — compact declaration of whether a lane carries duration, bytes, count, ratio/utilization, money, or another quantity family.
- **canonical-unit note** — compact note naming the coded machine-comparable unit basis.
- **display-unit note** — compact note naming the preferred human-facing render unit or symbol without letting it outrank coded semantics.
- **currency-rate witness** — compact note carrying source currency, target currency, rate source, as-of basis, and rounding/minor-unit posture for converted outputs.
- **unity-not-percent posture** — keep stored ratio/utilization semantics in unity when possible and let percent remain a render choice.
- **source-native preservation** — allow original units or currencies to stay visible even when a normalized comparison lane also exists.


## Pass LXXII additions
- **exactness-class card** — compact declaration of whether a value is exact, exact-from-components, sketch-estimate, or sample/proxy estimate.
- **sketch witness** — explicit note of retained sketch artifact, merge posture, and whether precision is system-defined, tunable, or unknown.
- **error-band note** — compact note of confidence/error posture or the explicit absence of one.
- **mixed-exactness veto** — standing rule that exact and estimate-backed components do not silently compose into one fake exact metric.
- **estimate-lineage note** — compact record that a lane changed from exact to estimate-backed, vice versa, or between estimate families.


## Pass LXXI additions
- **conformance-lane card** — compact declaration of whether a lane is local-only, a conformed subset, bridged, or only a convenience identity surface.
- **bridge witness** — explicit note of mapping multiplicity, time basis, unresolved cases, and whether the bridge is exact or weaker.
- **identity shadow note** — compact warning that a canonical-looking ID may still be derived, provisional, or only safe for selected uses.
- **shrunken conformance slice** — smaller shared subset for higher-grain or aggregate lanes instead of a giant universal base dimension.
- **named-entity spine** — lightweight join vocabulary that can support future semantic work without freezing one enterprise entity table today.


## Pass LXX additions
- **aggregation-class card** — compact declaration of whether a number is additive, semi-additive, ratio/composite, or set/sketch-backed.
- **fanout fence** — explicit protection that says where a measure’s base grain lives and how one-to-many joins are prevented from multiplying it.
- **rollup note** — compact explanation of which axes are safe to aggregate across and when recomputation from components is required.
- **component-first ratios** — keep numerator and denominator durable, then compute the displayed rate from them at the target grouping.
- **optional sketch sidecars** — leave room for mergeable approximate summaries as smaller neighbors to exact detail instead of hiding them as fake exactness.


## Pass LXVIII additions
- **evidence-grade card** — compact note saying whether a lane is snapshot-pinned, head-fresh, head-stale, partial/summary-only, or unknown.
- **head-trust note** — compact reminder that moving-head truth and exact-snapshot truth are different strengths.
- **freshness witness** — compact evidence note carrying observation time, measured age, threshold window, and calculation basis.
- **current-versus-exact split** — standing anti-regrowth rule: operational freshness and replayable exactness should not flatten into one badge.
- **summary-status quarantine** — standing anti-regrowth rule: a coarse green headline stays smaller than a detailed observed-value receipt.


## Pass LXVII additions
- **presence witness** — steal a tiny note that says whether a slot is explicit value, explicit null/unknown, not applicable, withheld, or default-shadowed.
- **default shadow** — steal a compact warning that the substrate collapsed explicit-default and unset states.
- **absence witness** — steal a compact note about why a blank exists: query omission, incomplete materialization, policy suppression, inapplicability, or producer-side absence.
- **nested-validity humility** — steal the reminder that a parent object and its children can disagree about validity, so flattened blanks need a witness.
- **display-default quarantine** — steal the rule that analyst-facing convenience fills stay display residue unless the meaning tier explicitly promotes them.


## Pass LXVI additions
- steal **assertion-posture cards** so verification consequence can be explicit without rewriting row meaning.
- steal **observed-value notes** so a status badge does not hide the measured value, interval, or missing-evidence posture.
- steal **waiver receipts** so temporary exceptions have owner, scope, expiry, and reviewed evidence.
- steal **consumer-specific assertion impact** so one strict operational dependency does not universalize every warning into a global block.

## Pass LXV additions
- **change-class card** — compact declaration of what kind of edit a published lane is actually making.
- **compatibility verdict** — compact label for safe-in-place, bridge-window, successor-required, or historical-restatement posture.
- **bridge window** — bounded overlap period for rename/split/merge migrations.
- **shadow diff** — consumer-slice rehearsal diff kept smaller than canonical meaning.
- **retirement reservation note** — compact tombstone that prevents accidental reuse of a retired published identifier.
- **semantic-drift veto** — standing reminder that schema sameness does not prove result sameness.

# Steal these ideas

## Pass LXIV additions
- **contract-tier card** — tiny declaration of which promise families a lane currently makes.
- **assertion plane** — neighboring verification surface for schema/freshness/volume/custom checks.
- **consumer-obligation slice** — compact note of what one downstream consumer truly depends on.
- **tiered stability** — permission for shape to publish earlier than richer meaning or service posture.
- **compiled-check humility** — generated tests and monitors stay smaller than the review surface that defined the tier.
- **assertions as building blocks, not row meaning** — keep verification strong without letting it rewrite the core contract.


## Pass LXIII additions
- **stability ring card** — tiny declaration of whether a lane is rehearsal, candidate, published, or historical.
- **compatibility window** — compact note saying what sort of change is currently safe for that lane.
- **consumer-pin note** — explicit reminder that a downstream consumer may depend on one named lane or historical tag.
- **deprecation receipt** — compact history of how an older published lane was warned, overlapped, and retired.
- **immutable version pointer** — one family/version reference for published contract docs or facets instead of a mutable head.
- **small-contract bias** — keep lane contracts narrow enough that successor versions and refactors stay cheap.


## High-value moves worth stealing
- **ceilings before dynamic refinement** — steal Android’s pattern where late rules narrow or exclude inside a predeclared local scope instead of widening authority.
- **browser-owned connected-account memory** — steal the shape of FedCM continuity without stealing browser-local truth as portable system truth.
- **per-session device-bound continuity** — steal DBSC’s anti-theft posture without minting a stable device identifier or exported session blob.
- **typed interaction-required aftermath** — steal OIDC’s honesty: when silent auth is impossible, say *interaction/login/account selection/consent required* instead of pretending the route already won.
- **conditional mediation as a distinct rung** — steal passkey/WebAuthn and credential-management posture where credentials can be discoverable and chooser-light without becoming ambient identity leakage.
- **explicit disconnect/disassociation** — steal the idea that a remembered relation can be revoked and should stop silently participating.

## Anti-ideas to avoid
- turning provider-local account memory into Harbor-owned durable account truth;
- treating silent probe failure as an invisible retry rather than a typed floor;
- treating a sign-out/disconnect click as proof that every browser/provider/authenticator memory layer has been cleared;
- treating a newly issued token or refreshed session as proof of fresh human interaction;
- letting returned `auth_time` quietly become a portable recent-login oracle or timeless freshness badge;
- compressing chooser, reauth, consent, and account-selection pressure into one generic “needs UI” blob before specimens prove that is safe.



## Pass LX additions
- **trusted-schema-audience note** — compact residue that a helpful actionable detail body was only meant for one resource's trusted authorization-server set.
- **schema-rotation repair receipt** — typed note that a later retry succeeded only after refetching metadata/schema and rebuilding the detail object.
- **detail-retry cache epoch** — retry-scoped age/provenance note for actionable bodies and nearby schema guidance.
- **ephemeral-claim humility** — standing anti-regrowth rule: interaction-scoped risk or consent hints are useful but still smaller than durable authorization truth.
- **no-store or quarantine** — standing anti-regrowth rule: a replayed actionable body should bottom out visibly instead of silently passing as a generic retry.

## Pass XXIV additions
- **selector hint** — bounded preference or narrowing signal about a likely account, domain, or authenticator path.
- **chooser priming** — filter/sort/highlight effect on a chooser that stays smaller than a chosen result.
- **provider label rail** — provider-maintained account labeling that remains smaller than selected-account truth.
- **mismatch prompt** — typed truth that a hint failed to land on a presently usable candidate.
- **hint smaller than selected** — a standing anti-regrowth rule.


## Pass XXV additions
- **disconnect pulse** — typed request that a given layer should sever or demote a remembered relation.
- **memory reset rail** — explicit suppression/removal/update path for silent reuse, connected-account memory, or remembered credential candidates.
- **cold-start floor** — honest next-turn posture after sign-out: mediate again instead of faking continuity.
- **residual-memory honesty** — standing reminder that one layer's reset is not proof that every layer forgot.


## Pass XXVI additions
- **recency ask** — typed demand for a bounded age since active authentication.
- **auth_time receipt** — exact statement of when the active authentication event occurred.
- **freshness verdict** — current evaluation that a present crossing does or does not satisfy the ask.
- **stale-auth lamp** — compact chrome that admits once-fresh auth has aged out.
- **token issuance smaller than fresh login** — a standing anti-regrowth rule.



## Pass XXVII additions
- **attenuation notice** — typed outside signal that continuity, risk, or session posture changed.
- **receiver stance** — local keep/narrow/revalidate/cold-start reaction after interpreting a signal.
- **revalidation floor** — visible next posture once seamless continuity is no longer honest.
- **signal drift honesty** — later signals can narrow earlier continuity without erasing the fact that the earlier crossing happened.
- **event notice smaller than command** — a standing anti-regrowth rule.


## Pass XXVIII additions
- **correlation handle** — issuer/provider/RP/credential-scoped identifier used only to attempt a local match.
- **match witness** — inspectable residue about how a local match was justified.
- **mismatch quarantine** — explicit hold/revalidate/ignore path when a handle parses but does not safely land.
- **scope honesty** — visible reminder of the scope in which an identifier is meaningful.
- **match smaller than subject** — a standing anti-regrowth rule.

- **browser-owned status adverts with reset semantics** — steal FedCM’s small login-status map (`unknown` / `logged-in` / `logged-out`) without stealing browser-local truth as portable system truth.
- **changed means verify** — steal OIDC Session Management’s habit that status drift triggers a re-check turn instead of instant final truth.
- **mismatch dialog before folklore** — steal FedCM’s explicit mismatch handling when remembered status and fetched accounts disagree.
- **no cheap negative reveal** — steal Credential Management’s refusal to immediately leak “no credentials here” as requester-visible truth.


## Pass XXX additions
- **pending rung** — exact “still in flight” residue smaller than both success and denial.
- **pace hint** — optional “wait longer / retry later” guidance instead of guessed polling.
- **refusal rail** — typed non-completion truth that stays smaller than durable account/session collapse.
- **expiry honesty** — explicit cold/expired ending instead of endless spinners or counterfeit denial.
- **abandonment is real** — a standing rule that dismissed or quietly dropped UI should not be rewritten as approval.


## Pass XXXI additions
- **replay witness** — compact residue explaining why a later arrival was treated as same-as-before, suspiciously-different, or too-late-to-spend.
- **duplicate suppression** — explicit no-new-effect aftermath that can still point back to the prior receipt.
- **consumption honesty** — chips or cards that admit a code, proof, or crossing chance is already spent.
- **exact replay only** — standing anti-regrowth rule: same handle may safely replay only the same canonical crossing.
- **late duplicate as inspectable residue** — do not hide the second arrival just because it should not have fresh effect.


## Pass XXXII additions
- **abort pulse** — explicit stop request that is smaller than provider refusal or durable result.
- **cancellation witness** — compact residue saying which layer pulled the stop and how.
- **deadline floor** — typed “waiting is no longer honest here” state.
- **completion-race honesty** — keep cancel residue and late completion residue compatible instead of forcing a fake single winner.
- **dismissal cooldown** — browser/local quiet-period residue after user dismissal that shapes the next attempt without becoming identity truth.


## Pass XXXIII additions
- **lane witness** — per-attempt binder that stays smaller than durable subject/session/account truth.
- **supersession fence** — tiny stale-lane blocker saying a fresher lane now owns adoption rights.
- **stale-result quarantine** — honest place for late arrivals that validate structurally but no longer belong to the live lane.
- **historical-but-not-adopted residue** — do not hide late stale arrivals just because they should not win.
- **live lane only** — standing anti-regrowth rule: only the current locally owned lane may mint consequence.


## Pass XXXIV additions
- **discovery card** — compact fetched description of a provider/resource/path config surface.
- **cache epoch** — visible freshness/provenance marker for fetched discovery or config.
- **overlay witness** — note that raw discovery was refined by policy, trust-chain resolution, or a manifest/static ceiling.
- **admission truth** — local usable-now / refresh / fallback / reject verdict kept separate from fetched config.
- **fetched config smaller than admitted route** — standing anti-regrowth rule.


## Pass XXXV additions
- **support advert** — compact statement of what an outside party claims to support, smaller than usable-now truth.
- **method hint** — caller/browser/provider/credential preference that can shape a crossing without binding it.
- **negotiation witness** — inspectable record of the exact method/path that actually won here.
- **unsupported-here honesty** — explicit local bottom-out when a listed or hinted option does not land.
- **advert smaller than negotiated path** — standing anti-regrowth rule.


## Pass XXXVI additions
- **assurance ask** — typed request for a stronger or more specific authentication rung that stays smaller than success.
- **achieved rung** — exact result of the authentication/verification level that actually survived here.
- **method receipt** — explain how the rung was reached (`amr`, UV, device-bound posture) without letting method labels become assurance truth.
- **mixed passkey posture** — steal the idea of letting ordinary paths use synced passkeys while privileged paths require device-bound posture, but keep the policy local.
- **method smaller than achieved rung** — standing reminder that evidence about methods used does not automatically settle assurance policy.


## Pass XXXVII additions
- **claim ask** — typed request for specific identity/profile facts that stays smaller than release reality.
- **release bundle** — inspectable set of account/profile facts that actually came back here.
- **source witness** — compact provenance about which provider or claims source asserted which facts.
- **not-adopted-here honesty** — explicit reminder that returned or displayed facts may still be chooser-only, display-only, or otherwise insufficient for local adoption.
- **bundle smaller than adopted subject** — standing reminder that profile-like data is not the same thing as local account truth.


## Pass XXXVIII additions
- **prompt provenance** — compact fact about where the human-facing prompt or review surface actually lived.
- **reviewed summary** — bounded description of what the user was actually shown, derived from exact ask/basis rather than free-floating prose.
- **review witness** — inspectable residue that a host/browser/authenticator-owned review turn really occurred here.
- **no-fake-approval honesty** — explicit reminder that requester-owned copy or widget chrome is not the same thing as trusted approval.
- **review smaller than grant** — standing reminder that a good prompt surface still does not settle durable grant/account/session truth.



## Pass XXXIX additions
- **basis witness** — compact tie from a reviewed surface to the exact ask / revision / descriptor it summarized.
- **summary freshness** — typed truth about whether a reviewed summary still matches the live basis.
- **stale-basis denial** — explicit fail-closed bottom-out for drifted mutable review basis.
- **requester-copy negation** — inspectable reminder that requester-owned prose or widget chrome did not count as trusted review.
- **copy smaller than reviewed basis** — standing anti-regrowth rule.


## Pass XL additions
- **review card** — host/UA/authenticator-owned bounded surface that summarizes the reviewed crossing.
- **origin cue** — explicit requester/RP/origin indication carried on that card.
- **bounded field** — display-contained field that cannot visually bleed into surrounding UI or chrome.
- **truncation honesty** — inspectable reminder that the shown card or field was shortened or partial.
- **display smaller than reviewed basis** — standing anti-regrowth rule.


## Pass XLI additions
- **coarse origin cue** — explicit origin-scoped provenance cue on a host-owned chooser or review surface.
- **preview asset** — logo, icon, picture, or other bounded visual aid that remains smaller than issuer/account truth.
- **chooser label** — small category or badge that narrows or disambiguates visible candidates without becoming selected-account truth.
- **asset honesty** — inspectable reminder that a preview asset may be cached, transformed, omitted, filtered, or stale.
- **preview smaller than truth** — standing anti-regrowth rule.


## Pass XLII additions
- **displayed-party split** — steal FedCM’s growing willingness to show both the top-level site and the embedded requester when one visible party would under-explain the crossing.
- **return parcel** — steal the idea that a mediated result can come back as structured JSON instead of a string blob, while still staying smaller than durable adoption.
- **PARC-style scratch tuple** — Cedar’s principal/action/resource/context request shape is a great internal anti-sprawl scaffold for specimen writing and review, even if Harbor never exposes those nouns directly.
- **attenuation by restriction, not reinterpretation** — Biscuit and zcap both reinforce that delegation gets safer by narrowing target, action, or expiry rather than by inventing fuzzy new meanings; keep that as a neighboring-cube lesson on standby.
- **same-revision promotion rule** — steal SlopOS’s singleton-drift discipline: if a second close sibling exists, pay for explicit structure immediately instead of letting the archive collect stale “temporary” labels.

## Pass XLIII additions
- **connection-context witness** — steal the idea that one local tuple should remember which provider/toolkit/tenant/lane actually started a crossing.
- **finish-hash witness** — steal GNAP’s habit of proving a finish belongs to one exact initiated request instead of trusting nearby callbacks.
- **foreign-finish veto** — steal the idea that a structurally valid but context-foreign result deserves visible quarantine, not silent acceptance or erasure.
- **cleanup pulse** — steal WebAuthn’s signal pattern for hiding or refreshing stale chooser state without promoting it to durable account truth.
- **same-context or nothing** — keep exact local context as the stronger truth than brand, account, or issuer sameness.


## Pass XLIV additions
- **receiver-origin witness** — steal the idea that the exact allowed receiver origin should survive as a small local fact for browser-messaging finishes.
- **secondary-window lane** — steal the habit of naming whether a finish belonged to `opener` or `parent` instead of flattening all popup/iframe returns together.
- **message-origin fence** — steal the combination of sender-origin, receiver-origin, lane, and format checks before any adoption.
- **origin beats chrome** — keep exact browser-message routing facts stronger than polished popup or iframe UI.
- **effective-target echo** — steal the future idea that a result can say which target actually survived, while staying smaller than durable consequence.


## Pass XLV additions
- **device-split witness** — steal a compact reminder that a crossing really depended on different consumption and authorization devices.
- **pairing cue** — steal short matching codes or `binding_message` style interlocks that help users verify “this phone action belongs to that screen.”
- **same-device veto** — steal the habit of refusing or downgrading when a cross-device route collapses into same-device use.
- **notification stub** — steal the idea that a client callback can carry only enough to resume the right retrieval path, not the whole durable result.
- **continuation-bound key** — steal DPoP’s device-flow move of binding the continuation to one key from the beginning.

## Pass XLVI additions
- **cleanup pulse** — steal a compact advisory signal that stale chooser or authenticator entries should be hidden, refreshed, or re-mediated.
- **stale-chooser quarantine** — steal the habit of treating remembered-but-no-longer-accepted candidates as inspectable quarantine, not counterfeit success.
- **display-refresh residue** — steal account-label refresh without overreading it as adopted identity truth.
- **capability-gated cleanup** — steal WebAuthn’s reminder to probe support before assuming cleanup or refresh paths exist.
- **mediation reset** — steal the idea that local sign-out can tighten the next chooser posture without pretending to be universal logout.


## Pass XLVII additions
- **audience-basis witness** — steal a compact note explaining why a specific identifier counted as the audience basis here.
- **endpoint-target card** — steal the habit of keeping the exact endpoint URI that a proof or assertion targeted.
- **alias veto** — steal a visible refusal path for same-provider or same-issuer endpoint mismatches that are “close” but still wrong.
- **normalized-target note** — steal DPoP's reminder that normalization can help exact comparison without turning the check into vague similarity.
- **effective-target echo** — steal the future idea that issuance-time returned resource/target details can clarify what actually survived.


## Pass XLVIII additions
- **request-target receipt** — steal a compact note of the exact protected resource the client asked for here.
- **effective-target echo** — steal the issuer-returned `resource` value as issuance-time clarification without letting it become durable grant truth.
- **unbounded-target warning** — steal a typed caution when no specific returned target bounds come back.
- **discovery-source note** — steal the reminder of whether the route came from RS-first discovery, resource metadata, or local configuration.
- **narrowed-target subset** — steal the idea that a returned subset can improve explanation without becoming a portable target registry.


## Pass XLIX additions
- **discovery-source note** — small residue of how the route or metadata was learned, because the validation rule can change with the source.
- **narrowed-target subset** — compact note that only part of the requested target set survived issuance.
- **target-negotiation rail** — typed explanation path for intact acceptance, narrowed acceptance, or `invalid_target` refusal.
- **authorized-candidate slate** — a future-facing, explicitly scoped list of offered targets for one subject token and one authenticated client.
- **grant-bounded narrowing floor** — reminder that later requests may narrow what the grant allows without silently expanding it.


## Pass L additions
- **grant-bounded narrowing floor** — steal the reminder that token-time target asks can narrow inside a broader grant without silently widening it.
- **server-assigned addition** — steal the habit of marking extra returned resources as server-derived rather than pretending they were requested verbatim.
- **target-refusal rail** — steal a typed path for `invalid_target` instead of collapsing resource refusal into generic auth failure.
- **requested-anchor minimum** — steal the rule that returned assigned additions should stay anchored to at least one accepted requested resource when the client did ask for resources.
- **assigned-only lane** — steal the distinction between “no resource requested, server assigned one” and “client explicitly asked for this exact target.”


## Pass LI additions
- **assigned-only lane** — steal a compact note that the server returned assigned resources or unbounded omission without any explicit requested anchor in this turn.
- **requested-anchor minimum** — steal the validation floor that at least one requested resource must survive when the client did ask for resources.
- **resource-confirmation floor** — steal a local status that says whether issuance-time resource confirmation is strong, weak, or absent.
- **preconfigured-omission grace** — steal the idea that preconfigured clients can continue with explicit weaker confirmation instead of counterfeit exactness.
- **strict-discovery discard** — steal the idea that dynamically discovered clients should discard a token when response confirmation is absent rather than guessing.



## Pass LIV additions
- **JWT introspection response card** — compact residue that the authorization server signed an introspection reply to one exact protected resource.
- **response-over-token precedence** — explicit returned `resource` confirmation can outrank ambiguous audience hints from tokens or introspection.
- **alias-family mismatch note** — a token can look ledger-shaped and still be wrong for this receiver family.
- **recipient-target split** — signed recipient facts and nested token target facts should not collapse into one pseudo-target object.
- **signed-but-still-smaller-than-adoption** — stronger provenance does not justify stronger semantic claims by itself.

## Pass LIII additions
- **token-format target witness** — compact residue that a token or introspection response named certain audience-like identifiers.
- **resource-server coverage card** — local note about what this receiver currently treats as in-family.
- **client-confidence ladder** — explicit separation between response-confirmed, receiver-locally-accepted, and token-format-only target confidence.
- **local-expectation veto** — standing reminder that a token can look plausible and still be wrong here.
- **response-over-token precedence** — standing reminder that explicit returned `resource` confirmation can outrank ambiguous audience folklore.

## Pass LII additions
- **default-target cue** — steal RFC 9068's willingness to make a no-`resource` turn carry a default protected-resource hint in JWT `aud`, while keeping that hint smaller than client confirmation.
- **coverage note** — steal RFC9728bis's same-origin path-prefix rule for challenge-derived protected-resource metadata, but keep it scoped to discovery rather than durable grant truth.
- **confirmation-gap receipt** — steal the resource-token-response draft's typed client-validation failure for missing or duplicated response confirmation, and keep the weakness visible.
- **segment-bounded coverage** — steal the idea that broader coverage can still be exact on path-segment boundaries instead of fuzzy.
- **client-confidence ladder** — steal the idea that discovery, cue, and confirmation can be three different rungs instead of one binary success bit.


## Pass LV additions
- **recipient-target split** — steal the habit of writing down who received a signed introspection answer separately from what target-like identifiers the token metadata named.
- **returned-resource-over-default-audience conflict** — steal a compact note when explicit returned `resource` beats a broad/default `aud` for client-side exactness.
- **alias-family drift note** — steal a visible local ending for “same-family enough to tempt you, still wrong here.”
- **receiver-scoped disclosure lens** — steal the reminder that introspection answers and scope slices may legitimately differ by receiver.
- **signed-but-still-not-exact-resource** — steal the anti-regrowth rule that stronger provenance does not mean stronger semantic scope.
- **receiver-scoped disclosure note** — steal RFC 7662's allowance for receiver-specific scope slices, but keep it smaller than universal token meaning.
- **stronger-here challenge rail** — steal RFC 9470's “authentication stronger here” move as a typed rail, not a global assurance taxonomy.
- **coverage-drift note** — steal RFC9728bis's broader challenge-derived coverage only as discovery residue, not as an operation-policy registry.
- **actionable authorization-detail offer** — collect the February 2026 RAR metadata/error-signaling draft as the next pressure test, not a committed Harbor family.

## Pass LVI additions
- **receiver-scoped disclosure note** — steal RFC 7662's allowance for receiver-specific scope slices, but keep it smaller than universal token meaning.
- **stronger-here challenge rail** — steal RFC 9470's "authentication stronger here" move as a typed rail, not a global assurance taxonomy.
- **coverage-drift note** — steal RFC9728bis's broader challenge-derived coverage only as discovery residue, not as an operation-policy registry.
- **actionable authorization-detail offer** — collect the February 2026 RAR metadata/error-signaling draft as the next pressure test, not a committed Harbor family.


## Pass LVII additions
- **required-authorization rail** — steal a typed ending for “target fit was fine, richer structured authorization was still required here.”
- **actionable authorization-detail offer** — steal the idea that a resource server can provide a request-scoped `authorization_details` object to guide the next OAuth + RAR turn.
- **authorization-type slate** — steal a compact local summary of which `authorization_details` types or combinations are acceptable here.
- **required-types expression** — steal machine-readable combinations (`and`, `or`, `oneOf`, `allOf`) without freezing Harbor’s permanent type ontology.
- **granted-detail view** — collect the future idea that token or introspection-visible details may be filtered or enriched for one receiver.


## Pass LVIII additions
- **granted-detail view** — steal a compact note for what the token response actually granted.
- **filtered-detail card** — steal a receiver-scoped card for JWT or introspection-visible `authorization_details`.
- **detail-schema veto** — steal a typed ending for malformed or unknown detail shapes.
- **schema-source note** — steal a tiny note about whether detail-shape guidance came from inline schema, `schema_uri`, or preconfigured local knowledge.
- **omitted-field humility** — steal the reminder that values omitted to the client do not thereby stop existing in AS/RS policy space.


## Pass LXI additions
- **grain contract card** — steal Kimball's discipline of declaring exactly what one durable Harbor row/card/receipt stands for before adding dimensions, measures, or convenience rollups.
- **atomic-first posture** — steal the bias toward atomic grain when future questions are still unknown.
- **late-bound evolution lane** — steal Iceberg/Anchor Modeling's refusal to make every new field a destructive rewrite.
- **facet-version note** — steal OpenLineage's atomic, versioned facet idea so optional metadata can stay smaller than the core contract.
- **restatement receipt** — steal the old warehouse lesson that late-arriving context and retroactive corrections deserve explicit repair history.
- **requested-versus-completed change pair** — steal Hudi's two-step timeline habit for mutation surfaces.
- **change-feed humility** — steal Delta Lake's useful row-level change feed idea, but also its warning that non-additive schema changes make history surfaces trickier than they look.
- **semantic front door later** — steal dbt's entities/dimensions/metrics interface shape as a future publishing surface, not an immediate design obligation.


## Pass LXII additions
- **publish lane card** — a tiny declaration of what one curated downstream lane promises right now.
- **branch rehearsal** — an isolated, disposable lane for testing one contract, backfill, or export without pretending it is already canonical.
- **promotion merge receipt** — compact residue that an experimental lane became the published lane.
- **historical tag** — frozen reference kept for audit/replay without forcing the live head to stop evolving.
- **derived artifact rule** — generated schema/catalog/semantic files stay smaller than canonical review surfaces.
- **same SQL, explicit reference** — borrow lakeFS’s ergonomic ambition but never hide which lane or tag a query is actually using.

## Pass LXIX additions
- **time-axis card** — compact declaration of which temporal axes a lane actually uses.
- **as-of witness** — explicit reminder of which axis and cut/timestamp a query or published answer used.
- **knowledge-cut note** — compact note about which published cut included which known facts.
- **overlap posture** — explicit note that validity windows are forbidden-to-overlap, temporarily tolerated, or unresolved.
- **axis before timestamp** — standing anti-regrowth rule.


## Pass LXXIII additions
- **change-history lane card** — steal a tiny declaration of whether a lane is current-state, changed-rows, full change-history, or net-change.
- **replay cut note** — steal the habit of naming the exact commit/snapshot/time cut and time axis behind a history claim.
- **carry-over veto** — steal the warning that storage rewrite artifacts are not automatically business changes.
- **restatement receipt** — steal a compact receipt for when previously published history is recomputed or corrected.
- **history smaller than transport** — steal the reminder that append-only export shape should not erase delete/update semantics.


## Pass LXXVII additions
- **Steal proof obligations, not giant schemas.** A lightweight promotion packet lets Harbor ask what a noun proves before inventing an implementation stack.
- **Steal source/canonical/display cuts.** Unit-bearing systems are useful because they force the value, machine basis, and human render to stay separate.
- **Steal rate witnesses for money views.** Every converted comparison should carry rate source, version, as-of, applied-at, and rounding posture.
- **Steal sidecar humility.** Puffin-like blobs, OpenLineage-style facets, row-lineage fields, and sketches are best treated as optional, scoped evidence.
- **Steal query outputs as tests.** Pivot/cube/grouping-set tables make excellent counterexample generators, especially when NULL placeholders, fanout, and non-additive measures can be inspected.
- **Steal SlopOS migration-gate discipline.** Mutable data and derived answers need rollback barriers and restatement receipts, not comforting code-rollback folklore.

## Pass LXXVIII additions — semantic export pieces to steal
- **Semantic export receipt:** a small card that names source cuts, exposed dimensions/metrics, allowed joins, refused joins, freshness basis, sidecars, and invalidation triggers.
- **Contract subset card:** a consumer-facing promise that lists only selected assertions and non-promises.
- **Freshness basis witness:** a thresholded age calculation tied to a named cut and time axis.
- **Join-relationship note:** a many-to-one / one-to-many / many-to-many statement with evidence and allowed metrics.
- **Fanout refusal rail:** a friendly refusal that shows the exact duplication hazard instead of silently applying magic.
- **Optional row-lineage sidecar:** scoped trace evidence that survives absence and refuses identity upgrades.
- **Refused-questions section:** put unsafe drilldowns beside exposed metrics so consumers learn the boundary.


## Pass LXXIX additions
- **Steal observation components, not RDF lock-in.** Use dimensions/measures/attributes/evidence fields as a review checklist while leaving encoding open.
- **Steal view-version receipts.** A view should have source cuts, query digest, dialect, current/past version posture, and invalidation rules before it gets consumer trust.
- **Steal blob sidecars with interpretation metadata.** Let statistics, indexes, sketches, facets, and lineage travel as optional evidence with schema/version tags and forbidden-use notes.
- **Steal progress witnesses.** Watermarks and frontiers are excellent when they say exactly which time/progress domain they speak for and what can still change.
- **Steal compiler receipts.** Declarative checks can compile to target engines, but every target artifact should carry preserved, downgraded, and unsupported semantics.
- **Steal transform non-equivalence warnings.** Mechanical schema migration is safer when it loudly records semantic deltas and retired identifiers.

## Pass LXXX additions
- **Steal unexpected-row evidence, not product lock-in.** Great Expectations-style failed-row retrieval is valuable because it keeps a quality failure inspectable; Harbor should copy the evidence posture without choosing a validation product.
- **Steal stored failures and severity thresholds.** dbt-style warn/error thresholds and stored failures show how a check can be visible, stored, or blocking by policy rather than by vibe.
- **Steal assertion compilers' humility.** DataHub-style open assertions suggest declarative checks can compile into targets, but Harbor should also preserve unsupported semantics and no-result posture when a target cannot represent the source meaning.
- **Steal run/error facets as scoped receipts.** OpenLineage-style run states and error facets are useful as bounded run evidence; do not turn them into global lineage ontology or row meaning.
- **Steal tombstone retention warnings.** Kafka/Debezium/Iceberg deletion mechanics remind Harbor that delete evidence has retention and replay consequences; current absence, durable withdrawal, compaction, and safe purge are separate ideas.
- **Steal late-data side channels.** Flink/Materialize progress discipline suggests stale frontiers should produce preview or refusal states with domain and lateness posture, not fake finality.
- **Steal impossible-transform honesty.** OpenTelemetry schema transforms explicitly admit that some conversions are impossible; Harbor should carry the same admission for assertion targets, export transforms, and presence-semantics downgrades.


## Pass LXXXI additions
- **Steal survivor-set receipts.** Before promising exact replay, list the base cut, sidecars, tombstones, view/query definition, policy epoch, rates, and runtime pieces that must survive together.
- **Steal answer modes.** Let historical requests bottom out as exact recompute, exact frozen answer, partial replay, explanation-only, restated successor, or refusal instead of a boolean pass/fail.
- **Steal cleanup-as-contract-change warnings.** Treat vacuum, snapshot expiration, cleaner services, and compaction as events that may narrow old-answer promises.
- **Steal frozen answer packets cautiously.** Preserve output digests and basis metadata for selected published answers without claiming they replace raw row authority.
- **Steal tombstone-expiry humility.** Expired delete evidence should create an explainability gap, not a no-history claim.
- **Steal recovery-mode labels.** Time travel, fail-safe, support recovery, savepoint restore, and current rerun deserve distinct badges.


## Pass XCV additions
- **Steal SlopOS's finite corpus habit, not its internals.** A tiny Harbor fixture can borrow accepted-prefix discipline without importing a portal-net schema.
- **Steal MCP's annotation distrust.** Tool metadata is useful precisely when the host refuses to treat the annotation as truth by default.
- **Steal browser-mediated credential scoping.** A credential presentation should name audience and mediation, then stop before identity folklore.
- **Steal transparency systems' receipt/currentness split.** Inclusion evidence is a receipt; verifier judgment and current truth are separate next-pass obligations.

## Pass XCVI additions

- **Steal receipt/currentness split.** SCITT, Rekor, CT, C2PA, timestamping, and verifier summaries all show that evidence can be useful without becoming current truth.
- **Steal subject/material binding.** in-toto/SLSA-style shapes are valuable because they force a subject and predicate boundary before trust folklore starts.
- **Steal checkpoint humility.** A tree head, timestamp token, or policy epoch should be a named cut, not a blanket freshness badge.
- **Steal selected-claim proofs.** Redacted/derived proof bundles are most useful when they loudly refuse full-evidence entitlement.
- **Steal compromise as recheck.** Issuer/key compromise should create scoped revalidation work, not automatic deletion or automatic trust.
- **Steal badge refusal.** When receipt families disagree, Harbor should prefer a refusal card over one flattering public badge.


## Pass XCVII additions

- **Steal policy digests.** A verifier decision is easier to compare when the policy identity and digest travel with it.
- **Steal visible disagreement.** Split status is better than one flattering badge when verifier runs disagree.
- **Steal epoch humility.** Newer policy can trigger recheck without rewriting old public-copy history.
- **Steal currentness unknown.** Unknown should be a first-class result, not a failure silently converted into stale or fresh.

## Pass XCVIII additions

- **Steal killed/survived language.** Mutation testing gives Harbor a small vocabulary for checker sensitivity without importing mutation-score theater.
- **Steal shrink notes.** Property-based testing is valuable because counterexamples become smaller and replayable; Harbor should demand the same from generated hostile cases.
- **Steal corpus minimization.** Fuzzers teach that interesting cases should be small and reusable, not massive opaque dumps.
- **Steal branch-coverage humility.** A coverage report identifies what was exercised; it does not prove semantic truth.
- **Steal generated pressure, not generated law.** Mutants should propose repair or fixture promotion; they should not become schema by accident.

## Pass CI additions

- **Steal timestamp explicitness.** Reproducible-build practice teaches that build time should be an input or fixed policy, not ambient state.
- **Steal build/run separation.** SLSA-style provenance is useful because it asks where, when, how, by whom, and with which parameters before trust talk starts.
- **Steal subject-bound statements.** in-toto's layers are a reminder that a package receipt must name its subject and still remain smaller than an envelope/signature.
- **Steal verifier humility.** Artifact-attestation guidance is strongest when it says consumers must verify and apply policy; Harbor should copy that warning.
- **Steal post-materialization checks.** The zip's digest and CRC belong after packaging, not in a source fixture that helps create the zip.

## Pass CII additions

- Steal manifest discipline from BagIt, but not a package format commitment.
- Steal content-identity humility from SPDX package verification code.
- Steal crate/root/member separation from RO-Crate.
- Steal content-address versus location-reference separation from OCI layouts.
- Steal descriptor humility from Data Package without promoting a data-package schema.

## Pass CIII additions

- Steal PROV's entity/activity/agent/derivation shape, but keep derivation smaller than source equivalence.
- Steal Web Annotation's body/target split, but keep annotation authorship smaller than target authority.
- Steal RO-Crate's contextual-entity packaging posture, but keep crate metadata smaller than truth or compliance.
- Steal BagIt/OCI-style fixity versus locator separation for re-exports, sync copies, and local indexes.
- Steal cache invalidation humility from every system that learned that a derived artifact needs its own clock.

## Pass CIV additions
- Steal PROV's revision/derivation distinction, but never let a derivative become the original source.
- Steal Web Annotation's target binding for repair notes, but keep annotation authorship smaller than authority.
- Steal notification protocols as delivery pressure, not as read/application proof.
- Steal OCI referrer-style subject links for supersession maps without turning links into trust.
- Steal Problem Details style failure reasons while refusing workflow or compliance closure.

## Pass CV additions

- From log retention: keep retained evidence useful for later review without making archive presence a truth claim.
- From BagIt: let manifests and tag manifests preserve fixity while refusing payload semantics.
- From PROV/PREMIS: record events, agents, preservation actions, and invalidation without collapsing them into current validity.
- From privacy minimization: prune raw material only when a tombstone and digest posture keep warning residue honest.


## Pass CVI additions

- Steal PROV revision humility: a revision is a derivation, not the original source and not later-epoch currentness.
- Steal Memento datetime posture: past representations stay useful only when their time basis travels with them.
- Steal ResourceSync change-list discipline: changed-resource notices are synchronization pressure, not proof that every derivative repaired.
- Steal OCI digest/ref separation: latest references and material digests are different facts.
- Steal branch/history preservation from version-control culture without importing merge authority or conflict resolution.

## Pass CVII additions

- Steal PROV's bundle boundary: provenance can itself have provenance, so an imported fragment can be tracked without becoming native truth.
- Steal SPDX's external-document humility: references into another document need document identity and relationship context before local use.
- Steal in-toto/SLSA's expectation boundary: attestations are material for verification against local expectations, not automatic policy pass.
- Steal RO-Crate's data/context split: companion evidence about consent, delegation, classification, retention, or repair may be contextual entity material rather than the artifact or status itself.

## Pass CIX additions

- Steal LDN's delivery/retrieval separation, but never its existence as proof of read or application.
- Steal Web Annotation's body/target/provenance split for public overlay cards.
- Steal Problem Details-style machine-readable failure reasons without importing workflow closure.
- Steal ResourceSync's change-list humility: change announcements are not all-destination synchronization.

## Pass CX additions

- Steal status-message humility from WCAG: expose state accessibly without claiming the user understood it.
- Steal labels/instructions discipline: controls need clear wording, but clear wording is not consent.
- Steal Web Annotation's body/target split for explanation cards, keeping card text smaller than target authority.
- Steal Problem Details-style reason codes, but always pair them with user-facing text and refusal of workflow closure.
- Steal localization provenance: translated cards need source digests, not just fluent words.

## Pass CXI additions

- Steal privacy-principles humility: user agency needs clear choices and minimization, but an event trace is not proof of what the user understood or intended.
- Steal consent-receipt discipline: consent needs a scoped transaction and terms; acknowledgement alone is not consent.
- Steal WCAG label/status pressure: controls and status messages should be clear and programmatically exposed, but exposure is not comprehension.
- Steal Problem Details separation: machine-readable reason codes can trigger routing or retry without becoming repair or human reliance.
- Steal registry-derived counts: maintenance inventories should compute visible counts instead of relying on hand-spelled text.
