## rev0111 — responseevents-reliancefences-countaudit-olivinepier

- Closed `F106` with specimen flow 106 and a deterministic user-response event bundle.
- Added `docs/00-meta/datacube-user-response-event-capture.md`, `docs/40-verification/harbor-user-response-event-bundle-v0.md`, `fixtures/harbor-user-response-event-bundle-v0.json`, `tools/harbor_user_response_event_harness.py`, `tools/check_harbor_user_response_event_bundle.py`, and `docs/30-architecture/specimen-flow-106-user-response-reliance-event-capture.md`.
- Added accepted cases for inspect, pending recheck request, scope-note export, dismissal without acceptance, appeal start without outcome, share-link copy with unknown recipients, acknowledgement without understanding, focus without read, localized acknowledgement with bound scope, denied sealed-detail request, agent follow-up with caveats, notice opt-out without repair, partial batch acknowledgement, and automated retry without human reliance.
- Added hostile cases for click-as-comprehension, checkbox-as-consent, export-as-reliance, dismiss-as-acceptance, appeal-as-repair, share-as-all-read, acknowledgement-as-compliance, scroll/focus-as-understanding, localized scope widening, sealed request-as-permission, recheck-request-as-passed, delivery-as-user-action, missing parent explanation digest, re-identifying analytics, stale response-as-currentness, agent acknowledgement-as-user-consent, irreversible action without undo, unbounded retention, and retry-as-repair.
- Added `PO-UR-001` through `PO-UR-006`.
- Added audit/refactor `docs/00-meta/datacube-executable-count-audit.md`; landing-page executable-slice count checks now derive from `tools/harbor_executable_surface_registry.py` instead of a hardcoded spelled-out count.
- Updated the executable-surface registry and checker cascade to include F106.
- Added `F107` as the next seam: response-event replay, withdrawal, expiry, and invalidation after explanation changes without retroactive consent, reliance, repair, currentness, or compliance overclaim.

## rev0110 — explanationbundles-languagerefusals-landingtrim-jasperquay

- Closed `F105` with specimen flow 105 and a deterministic user-visible explanation bundle.
- Added `docs/00-meta/datacube-user-visible-explanation-bundles.md`, `docs/40-verification/harbor-user-visible-explanation-bundle-v0.md`, `fixtures/harbor-user-visible-explanation-bundle-v0.json`, `tools/harbor_user_visible_explanation_harness.py`, `tools/check_harbor_user_visible_explanation_bundle.py`, and `docs/30-architecture/specimen-flow-105-user-visible-explanation-bundles.md`.
- Added accepted cases for scoped public-copy cards, stale mirror recheck explanations, generated summary caveats, consumer notice delivery/read splits, local index snippets, warning-card split states, sealed public summaries, mixed-cube cards, localized variants, accessible status messages, problem-detail-like reason codes, and inspect/recheck/export affordances.
- Added hostile cases for badge-only display, red global-failure banners, closure wording, prior-fault claims, color-only indicators, missing scope maps, missing source overlay digests, localized scope widening, source-equivalent summaries, delivery-as-read/application, global repair actions, hidden history, sealed detail leakage, timestamp currentness, machine-code-only messages, missing programmatic labels, translation without provenance, mixed-overlay collapse, confidence-as-truth, and legal advice language.
- Added `PO-UX-001` through `PO-UX-006`.
- Added audit/refactor `tools/check_harbor_briefing_focus.py` and `docs/00-meta/datacube-briefing-focus-audit.md`; trimmed stale appended briefing sections from `README.md`, `START_HERE.md`, and `docs/README.md`.
- Updated the executable-surface registry and checker cascade to include F105 and the briefing focus audit.
- Added `F106` as the next seam: user response and reliance-event capture after explanation cards without comprehension, consent, reliance, repair, or compliance overclaim.

## rev0109 — revocation-overlay propagation, public-surface fences, and bundle utility audit

- closed `F104` with specimen flow 104 and a deterministic revocation-overlay propagation bundle;
- added `docs/00-meta/datacube-revocation-overlay-propagation.md`, `docs/30-architecture/specimen-flow-104-revocation-overlay-propagation-public-surfaces.md`, `docs/40-verification/harbor-revocation-overlay-propagation-bundle-v0.md`, `fixtures/harbor-revocation-overlay-propagation-bundle-v0.json`, `tools/harbor_revocation_overlay_propagation_harness.py`, and `tools/check_harbor_revocation_overlay_propagation_bundle.py`;
- added accepted cases for scoped overlays on public copies, mirrors, generated summaries, consumer notices, local indexes, warning cards, partial propagation, sealed summaries, stale mirrors, and multi-cube public cards;
- added hostile cases for green/red badge collapse, compliance claims, prior-falsity banners, mirror-global closure, digestless summaries, delivery/read/application confusion, index truth, warning sunset without scope, sealed public truth, stale currentness, automatic repair, majority verdicts, single mixed badges, global repair, history erasure, callback status, timestamp freshness, and missing source revocation digest;
- added proof obligations `PO-RO-001` through `PO-RO-006`;
- added the audit/refactor surface `tools/harbor_bundle_common.py`, `tools/check_harbor_bundle_common_audit.py`, and `docs/00-meta/datacube-bundle-common-audit.md`;
- updated release/package hygiene to exclude and reject generated Python bytecode;
- added `F105` as the next seam for user-visible explanation bundles and overlay-card wording;
- promoted no revocation propagation API, public badge workflow, compliance workflow, notification guarantee, mirror/search truth plane, warning-card status engine, shared bundle schema, automatic global repair, prior-falsity judgment, or final SlopOS datacube shape.

## rev0108 — foreign-import revocation overlays, withdrawal/supersession guards, downstream quarantine, and executable registry audit

- Closed `F103` with specimen flow 103 and the deterministic foreign-import revocation bundle.
- Added parent-import identity, foreign change notices, local impact analysis, downstream quarantine, history residue, and recheck-plan checks for withdrawal, supersession, correction, dispute, expiry, and re-scope events.
- Added accepted cases for SlopOS, Foundry, Steward, Schell, ViewFS, Ward, Helm, multi-cube conflicting notices, sealed notices, and stale supersession notices.
- Added hostile cases rejecting revocation as prior falsehood, withdrawal as repair, supersession as trust promotion, dispute as falsehood, expiry as erasure/repair, re-scope widening, compliance failure, revision/timestamp freshness, missing digests, archive mismatch, missing parent import id, badge changes without local impact analysis, companion authority, majority vote, sealed public truth, rollback without recheck, global derivative closure, and consumer acknowledgement as repair.
- Added executable proof obligations `PO-FR-001` through `PO-FR-006`.
- Added audit/refactor surface `tools/harbor_executable_surface_registry.py`, refactored `tools/check_all.py` to read it, and added `tools/check_harbor_executable_surface_registry.py` to audit F090-F103 path wiring and latest-surface state.
- Added `F104` as the next seam: propagation of revocation overlays into public copies, mirrors, summaries, consumer notices, local indexes, and warning cards without badge/compliance collapse.

## rev0107 — cross-cube lineage import, status quarantine, foreign material bridges, scope translation, and companion overclaim refusal

- Closed `F102` with specimen flow 102 and a deterministic cross-cube lineage import bundle.
- Added `docs/00-meta/datacube-cross-cube-lineage-import.md`, `docs/40-verification/harbor-cross-cube-lineage-import-bundle-v0.md`, `fixtures/harbor-cross-cube-lineage-import-bundle-v0.json`, `tools/harbor_cross_cube_lineage_import_harness.py`, and `tools/check_harbor_cross_cube_lineage_import_bundle.py`.
- Added accepted import-quarantine cases for SlopOS ordering witnesses, Foundry label provenance, Steward attempt history, Schell retention context, ViewFS consent evidence, Ward route/delegation evidence, Helm repair traces requiring Harbor recheck, multi-cube incomparable splits, sealed foreign packet summaries, and stale companion revision residue.
- Added hostile cases refusing foreign green status as Harbor status, replay availability as currentness, retention windows as repair, warning state as public badge, revision as freshness, scope widening, digest mismatch, copied fragments without parent manifests, cross-cube total order without clock maps, majority-vote foreign policy, sealed evidence as public truth, foreign acknowledgement as repair, callback success as authority, SlopOS append order as semantic supersession, Foundry classification as status truth, Steward retry exhaustion as compliance failure, Schell forgetting ledger as erasure proof, ViewFS volition as consent outcome, Ward delegation as authority transfer, and Helm repair trace as completed repair.
- Added `PO-XC-001` through `PO-XC-006` and wired the new checker into `make check`.
- Added `F103` as the next seam: foreign-import revocation and correction after companion withdrawal, supersession, dispute, or expiry.

## rev0106 — overlapepochs-lineagemaps-rebaseguards-copperharbor

- Closed `F101` with a deterministic overlapping correction-epoch lineage bundle, fixture, harness, and checker.
- Added source-epoch, derivative-lineage, repair-action, scope-reconciliation, currentness-window, consumer-state, and verdict packets.
- Accepted scoped latest-epoch repair, epoch-A history after epoch B, disjoint coexistence, overlapping scope splits, rollback with preserved history, partial subset repair, consumer patch rebase, stale acknowledgement residue, disputed external epoch state, and named-field-only supersession.
- Rejected latest-wins, stale epoch-A currentness, rollback history erasure, false disjoint conflicts, overlap merges without delta maps, wrong patch bases, acknowledgement epoch mismatch, digest reuse across epochs, clockless order, unauthorized parallel total order, field-to-artifact widening, stale subset global-currentness, dispute-as-repair, source-owner closure, retention-expiry ignorance, green badges across mixed epochs, rollback without recheck, and lineage cycles.
- Added `F102` as the next pressure seam: cross-cube lineage import without inherited status.

# Changelog

## rev0105 — retentionexpiry-pruningholds-recheckfences-onyxharbor

- Closed `F100` with a deterministic derivative repair retention / expiry bundle, fixture, harness, checker, verification document, and specimen.
- Added accepted cases for active repair receipts inside a clocked window, expired recheck-required evidence history, compacted tombstones with digest pointers, legal-hold-like preservation without freshness, prior repair staled by a later source correction, quarantine residue after material pruning, digest-pointer-only residue, stale recurrence warning reopen, privacy-minimized tombstones, and expiring reviewer waiver notes.
- Added hostile cases for expired-as-current, retention-policy truth extension, hold-as-freshness, compaction digest as full evidence, deletion as repair, ignored later source correction, scheduled recheck as passed recheck, pruned evidence as verified success, quarantine expiry as repair, expired acknowledgement as current, hold-release warning loss, clockless expiry, wrong-scope retention, tombstone without subject digest, privacy minimization as proof of no stale copies, and evidence migration without a map.
- Added `PO-RE-001` through `PO-RE-006`.
- Wired the new checker into `make check` and `make package-release`.
- Added `F101` as the next seam: overlapping correction epochs and derivative repair lineage across multiple source corrections.

## rev0104 — derivative repairs, acknowledgement fences, propagation receipts

- Closed `F099` with specimen flow 99 and a deterministic derivative correction propagation / consumer repair acknowledgement bundle.
- Added `docs/00-meta/datacube-derivative-correction-propagation.md`, `docs/40-verification/harbor-derivative-correction-propagation-bundle-v0.md`, `fixtures/harbor-derivative-correction-propagation-bundle-v0.json`, `tools/harbor_derivative_repair_harness.py`, `tools/check_harbor_derivative_repair_bundle.py`, and `docs/30-architecture/specimen-flow-99-derivative-correction-propagation-and-repair-ack.md`.
- Accepted scoped repaired/superseded derivatives, quarantined unreached copies, partial propagation with unknown surfaces preserved, and notice-only acknowledgement.
- Rejected notice-as-repair, broadcast-as-reachability, cache/index/sync currentness overclaims, warning-label loss, wrong derivative digests, notification delivery as read/applied, latest-wins without scope, and acknowledgement signer authority.
- Added `F100` as the next pressure seam: derivative repair evidence retention and expiry.

## rev0103 — post-import local derivation drift, local indexes, cache fences, and sync-copy non-authority guards

- Closed `F098` with a deterministic post-import local derivation drift bundle, fixture, harness, checker, verification document, and specimen.
- Added accepted cases for target-digest-bound annotations, source-digest/expiry-bound summaries, subset manifests with loss notes, local indexes with invalidation triggers, re-exports with parent digest and new scope, revalidated cached explanations, byte-digest-rechecked cross-device copies, and quarantined stale consumer copies.
- Added hostile cases for annotation status rewrites without target digest, generated-summary source equivalence, label loss, timestamp-as-currentness, re-export name-as-identity, stale cache after source change, sync success-as-verification, stale copy-as-current, derivative digest-as-original, local search truth, summary-as-compliance-proof, annotation-author authority, latest-wins sync conflict, generated table label loss, and local patch-as-upstream repair.
- Added `PO-LD-001` through `PO-LD-006`.
- Wired the new checker into `make check` and `make package-release`; regenerated handoff and release-package evidence for the rev0103 root.
- Added `F099` as the next pressure seam: derivative correction propagation and consumer repair acknowledgement without cache APIs, sync ledgers, repair attestations, or final SlopOS datacube shape.

## rev0102 — handoffreceipts-consumerimport-copyidentity-emeraldpier

- Closed `F097` with a deterministic artifact handoff / consumer import bundle, fixture, harness, checker, verification document, and specimen.
- Added accepted cases for verified release zips, manifest/index-checked extracted trees, parent-context-bound copied fixtures, renamed archives with matching bytes, portal/callback transfers followed by post-material verification, and file-library uploads followed by digest rechecks.
- Added hostile cases for filename-only matches, pasted digests without material, renamed names as identity, missing archive indexes, copied fixtures without parent context, file-library timestamps as freshness, portal/callback success as verification, wrong digest scopes, downstream repack mismatches, hidden generated artifacts, and consumer acknowledgement overclaims.
- Added `PO-HI-001` through `PO-HI-006`.
- Wired the new checker into `make check` and `make package-release`; regenerated release-package evidence for the current environment.
- Added `F098` as the next pressure seam: post-import local derivation drift across annotations, generated summaries, extracted subsets, local indexes, re-exported archives, cached explanations, cross-device sync, and stale consumer copies.

## rev0101 — releaseprovenance-deterministicarchives-bootstrapguards-azuredock

- Closed `F096` with a deterministic release-package provenance bundle, harness, fixture, checker, and post-package zip inspector.
- Added release-root identity, file inventory, archive-index coherence, deterministic ZIP plan, build-environment capture, bootstrap verification, and final zip digest boundary evidence.
- Added hostile cases for archive-index drift, embedded release zips, nondeterministic ZIP metadata, stale release roots, generated artifacts omitted from the index, bootstrap self-trust, and attestation-as-security overclaim.
- Added `PO-RP-001` through `PO-RP-006` and wired the release-package checker into `make check` and `package-release`; `package-release` now verifies the emitted archive after writing it.
- Added `F097` as the next pressure seam: artifact handoff and consumer import across zips, extracted trees, copied fixtures, pasted digests, renamed archives, file-library uploads, and portal/callback-mediated transfers.

## rev0100 — checker provenance, guard-state receipts, self-test pairing, and reviewer override limits

- closed `F095` with specimen flow 95 and a deterministic checker-provenance bundle;
- added `docs/00-meta/datacube-checker-provenance-and-drift.md`, `docs/40-verification/harbor-checker-provenance-bundle-v0.md`, `fixtures/harbor-checker-provenance-bundle-v0.json`, `tools/harbor_checker_provenance_harness.py`, `tools/check_harbor_checker_provenance_bundle.py`, and `docs/30-architecture/specimen-flow-95-checker-provenance-and-guard-drift.md`;
- recorded checker source digests, harness source digests, fixture file digests, fixture bundle digests, invocation receipts, self-test receipts, guard-state receipts, fixture/checker pairing status, and reviewer override packets across the five prior executable checkers;
- added hostile cases for disabled guard evidence, stale fixture/checker pairing, missing self-test receipt, and unscoped reviewer override attempts;
- added proof obligations `PO-CP-001` through `PO-CP-006`;
- wired the checker-provenance checker into `make check` and `package-release`, bringing Harbor to six executable proof slices;
- refreshed pass C research, companion evaluation, bibliography, source register, lessons, inspirations, roadmap, context pack, manifest, revision receipt, and briefing surfaces;
- promoted no checker registry, CI status API, trust-root schema, checker certification badge, recursive self-attestation scheme, automated reliance workflow, release-package attestation profile, or final SlopOS datacube shape.

## rev0099 — survived-mutant triage, equivalent-mutant packets, overstrictness notes, and corpus pruning

- closed `F094` with specimen flow 94 and a deterministic mutation-triage bundle;
- added `docs/00-meta/datacube-mutation-triage-and-corpus-pruning.md`, `docs/40-verification/harbor-mutation-triage-bundle-v0.md`, `fixtures/harbor-mutation-triage-bundle-v0.json`, `tools/harbor_mutation_triage_harness.py`, `tools/check_harbor_mutation_triage_bundle.py`, and `docs/30-architecture/specimen-flow-94-survived-mutant-triage-and-corpus-pruning.md`;
- hardened the F090/F091/F092 checkers against forbidden authority/truth phrases inside accepted string values, closing a real survivor pattern left by key-only truth scans;
- added seven triage cases covering unsafe survivors now guarded, equivalent/cosmetic survivors, and one retained overstrict canonicality kill;
- added proof obligations `PO-MT-001` through `PO-MT-006`;
- wired the mutation-triage checker into `make check` and `package-release`, bringing Harbor to five executable proof slices;
- refreshed pass XCIX research, companion evaluation, bibliography, source register, lessons, inspirations, roadmap, context pack, manifest, revision receipt, and briefing surfaces;
- promoted no mutation dashboard, numeric coverage gate, property-test framework dependency, generated conformance suite, production validator, checker registry, CI status API, trust-root schema, automated reliance workflow, or final SlopOS datacube shape.

## rev0098 — property/mutation coverage, shrink discipline, and checker sensitivity

- closed `F093` with specimen flow 93 and a deterministic property/mutation coverage meta-bundle;
- added `docs/00-meta/datacube-property-mutation-coverage.md`, `docs/40-verification/harbor-property-mutation-coverage-bundle-v0.md`, `fixtures/harbor-property-mutation-coverage-bundle-v0.json`, `tools/harbor_property_mutation_harness.py`, `tools/check_harbor_property_mutation_bundle.py`, and `docs/30-architecture/specimen-flow-93-property-mutation-coverage-without-schema-promotion.md`;
- generated 38 targeted mutations across the CrossingRecord, transparency/provenance receipt-import, and verifier-disagreement bundles;
- required all 38 current mutants to be killed by the existing F090/F091/F092 checkers and recorded checker reasons plus shrink notes;
- added proof obligations `PO-PM-001` through `PO-PM-006`;
- wired the property/mutation checker into `make check` and `package-release`;
- refreshed pass XCVIII research, companion evaluation, bibliography, source register, lessons, inspirations, roadmap, context pack, manifest, revision receipt, and briefing surfaces;
- promoted no property-test framework dependency, fuzzing campaign, shared bundle schema, generated conformance suite, numeric coverage gate, certification badge, production validator, or final SlopOS datacube shape.

## rev0097 — verifier disagreement, policy epochs, and badge refusal

- closed `F092` with specimen flow 92 and a deterministic multi-verifier disagreement / policy-epoch drift bundle;
- added `docs/00-meta/datacube-verifier-disagreement-policy-epoch-drift.md`, `docs/40-verification/harbor-verifier-disagreement-policy-epoch-bundle-v0.md`, `fixtures/harbor-verifier-disagreement-policy-epoch-bundle-v0.json`, `tools/harbor_verifier_disagreement_harness.py`, `tools/check_harbor_verifier_disagreement_bundle.py`, and `docs/30-architecture/specimen-flow-92-verifier-disagreement-policy-epoch-drift.md`;
- added accepted cases for split accept/refuse, currentness unknown with badge withheld, policy update after public copy, issuer status after timestamp, sealed/public incomparable review, and local/global scope split;
- added rejected cases for green-badge collapse, retroactive latest-policy erasure, stale-policy currentness overclaim, refusal-to-global-failure, unknown-currentness-as-fresh, issuer-compromise auto-false, majority-vote authority, and missing policy digest;
- added proof obligations `PO-VD-001` through `PO-VD-007`;
- wired the verifier-disagreement checker into `make check` and `package-release`;
- refreshed pass XCVII research, companion evaluation, bibliography, source register, lessons, inspirations, roadmap, context pack, manifest, revision receipt, and briefing surfaces;
- promoted no verifier arbitration schema, policy-drift ledger, public badge semantics, reliance API, compliance workflow, legal resolver, trust-root policy, issuer-reputation model, generated conformance suite, shared bundle schema, or final SlopOS datacube shape.

## rev0096 — 2026-05-21
- added pass XCVI research and SlopOS/companions evaluation for transparency/provenance receipt import, binding/currentness cuts, verifier policy epochs, redacted proof boundaries, and issuer-compromise rechecks;
- added `docs/00-meta/datacube-transparency-provenance-receipt-import.md`, `docs/40-verification/harbor-transparency-provenance-receipt-bundle-v0.md`, and `docs/30-architecture/specimen-flow-91-transparency-provenance-receipt-import.md`;
- added `fixtures/harbor-transparency-provenance-receipt-bundle-v0.json`, `tools/harbor_transparency_receipt_harness.py`, and `tools/check_harbor_transparency_receipt_bundle.py`;
- wired `make check` and `make package-release` to verify both the F090 crossing bundle and the F091 receipt-import bundle before repo hygiene;
- added transparency/provenance receipt-import proof obligations for receipt-family non-promises, subject/material/manifest binding, currentness/checkpoint/timestamp cuts, verifier-policy epochs, redacted/derived proof boundaries, and issuer-compromise rechecks;
- closed `F091`; moved `F092` to the single `next` slot for multi-verifier disagreement and policy-epoch drift pressure;
- promoted no receipt-import schema, transparency-log reliance policy, C2PA verifier profile, in-toto/SLSA predicate profile, SCITT profile, timestamp authority policy, redaction proof system, issuer-reputation model, legal status workflow, public badge semantics, reliance API, or final SlopOS datacube shape.


## rev0095 — 2026-05-21
- added pass XCV research and SlopOS/companions evaluation for executable CrossingRecord v0 evidence, SlopOS portal-net bridge humility, route-family non-promises, hostile fixtures, and checker-backed scope discipline;
- added `docs/00-meta/datacube-executable-crossing-evidence.md`, `docs/40-verification/harbor-crossing-record-evidence-bundle-v0.md`, and `docs/30-architecture/specimen-flow-90-portal-net-crossing-record-fixture-harness.md`;
- added `fixtures/harbor-crossing-record-evidence-bundle-v0.json`, `tools/harbor_crossing_record_harness.py`, and `tools/check_harbor_crossing_record_bundle.py`;
- wired `make check` and `make package-release` to verify the deterministic crossing fixture before repo hygiene;
- added executable crossing proof obligations for bundle stability, route-family non-promises, subject digest/hostile envelope checks, callback/tool/credential humility, and accepted-prefix aftermath;
- closed `F090`; moved `F091` to the single `next` slot for transparency and provenance receipt import pressure;
- promoted no CrossingRecord schema, SlopOS import profile, MCP trust profile, browser credential trust profile, public status API, transparency-log policy, in-toto predicate, C2PA verifier, SCITT profile, compliance workflow, reputation model, enforcement ladder, or final SlopOS datacube shape.

## rev0094 — 2026-05-21
- added pass XCIV research and SlopOS/companions evaluation for CrossingRecord v0, scope algebra, Harbor-Core/PublicCopy strata, SlopOS portal boundary mapping, agent-memory invalidation, clock-basis notes, hostile receipt fixtures, and warning lifecycle guards;
- added `docs/00-meta/datacube-crossing-records-scope-and-warning-lifecycle.md`, `docs/00-meta/harbor-slopos-boundary-map.md`, `docs/00-meta/harbor-threat-model.md`, `docs/00-meta/harbor-agent-memory-invalidation.md`, and `docs/00-meta/harbor-clock-basis-and-hostile-receipts.md` as bounded review surfaces;
- added specimen flow 89 to pressure-test missed mandated deadlines, failed rechecks, contradictory implementation evidence, rollback/reopen triggers, stale-surface recurrence after a clean window, warning re-escalation/sunset, and hostile receipt rejection;
- added implementation-exception and crossing-record proof obligations to `docs/00-meta/datacube-proof-obligations.md`;
- normalized legacy followthrough and assumption statuses, added question-state taxonomy, marked prior answered questions as specimen-answered, added new open crossing-record questions, and strengthened repo hygiene checks for status, focus, and semantic overclaim drift;
- closed `F089`; moved `F090` to the single `next` slot for SlopOS-style portal/network crossing evidence, callbacks, truncation/resume, accepted-only append history, MCP/tool metadata, credential presentation, and public-copy aftermath;
- promoted no crossing-record schema, scope engine, state-machine runtime, deadline tracker, recheck service, rollback protocol, warning API, compliance workflow, agent-memory subsystem, MCP integration, browser credential profile, transparency log, reputation model, enforcement ladder, or final SlopOS datacube shape.

## rev0093 — implementation receipts, recheck windows, and stale-surface guards
- Added pass XCIII research and SlopOS/companions evaluation.
- Added `docs/00-meta/datacube-correction-implementation-monitoring.md`.
- Added specimen flow 88 for adopted correction work items, mandated deadlines, recommended non-binding corrections, implementation evidence, public-copy publication receipts, partial stale public surfaces, monitoring rechecks, reopened appeals, and jurisdiction/audience splits.
- Added correction-implementation monitoring proof obligations to `docs/00-meta/datacube-proof-obligations.md`.
- Closed `F088`; moved `F089` to the single `next` slot for missed deadlines, failed rechecks, rollback after bad corrections, contradictory implementation evidence, stale-surface recurrence, and re-escalation/sunset after monitoring.
- Refreshed lessons, inspiration harvest, source register, bibliography, ledgers, roadmap, briefings, manifest, and archive index.
- Promoted no correction implementation ledger, deadline tracker, compliance automation, regulator workflow, source-owner ticketing system, post-decision monitoring service, status-page product, rollback protocol, jurisdiction policy engine, VEX/CSAF profile, in-toto predicate, SCITT dependency, enforcement ladder, or final SlopOS datacube shape.

## rev0092 — 2026-05-16
- added pass XCII research and SlopOS/companions evaluation for external decision return, conflicting outside findings, partial findings, mandated/recommended corrections, sealed finding expiry, appeal outcomes, local adoption boundaries, and public-copy updates after outside review;
- added `docs/00-meta/datacube-external-decision-return.md` as a bounded review surface for finding-return receipts, scope normalization, authority conflict maps, finding adoption notes, correction instruction receipts, sealed finding expiry notes, appeal outcome receipts, and post-review public-copy updates;
- added specimen flow 87 to pressure-test source-owner partial acceptance, auditor/source-owner conflict, regulator-facing sealed-only determination, Harbor-local adoption, appeal outcome, public-copy wording update, and sealed-finding expiry;
- added external decision-return proof obligations to `docs/00-meta/datacube-proof-obligations.md`;
- closed `F087` and moved `F088` to the single `next` slot for correction implementation and post-decision monitoring;
- refreshed lessons, inspiration harvest, source register, bibliography, ledgers, roadmap, briefing surfaces, manifest, and archive index;
- promoted no external decision ingestion schema, finding-adoption API, authority hierarchy, legal/compliance workflow, appeal court, correction-implementation tracker, sealed finding protocol, transparency-log dependency, public status-page product, VEX/CSAF profile, in-toto predicate, SCITT receipt requirement, reputation model, enforcement ladder, or final SlopOS datacube shape.

## rev0091 — 2026-05-15
- added pass XCI research and SlopOS/companions evaluation for external escalation handoff, appeal windows, source-owner/auditor/regulator packets, sealed evidence boundaries, public-log/status-page divergence after handoff, and disputed sunset appeals;
- added `docs/00-meta/datacube-external-escalation-handoff.md` as a bounded review surface for handoff packets, escalation receipts, appeal-window notes, sealed evidence manifests, auditor/regulator packet notes, post-handoff divergence notes, and disputed sunset appeal notes;
- added specimen flow 86 to pressure-test standing challenge handoff, source-owner and auditor packets, external escalation with no automatic stay, regulator-facing sealed evidence, source-owner/auditor response receipts, public-log/status divergence, and a disputed warning sunset appeal;
- refreshed proof obligations, lessons, inspiration harvest, source register, bibliography, ledgers, roadmap, briefing surfaces, release manifest, and deterministic archive index;
- closed F086 and moved F087 external decision return/adoption pressure to the single next slot without promoting an external escalation workflow, appeal process, regulator/auditor packet format, sealed-evidence protocol, status-page product, transparency-log policy, legal/compliance workflow, incident-response program, CVD/PSIRT/CSIRT operating model, VEX/CSAF profile, in-toto predicate, SCITT dependency, reputation model, enforcement ladder, or final SlopOS datacube shape.

## rev0090 (2026-05-15)
- Focus: recurrence receipts, escalation windows, and sunset guards.
- Adds:
  - `docs/00-meta/datacube-recurrence-escalation-hygiene.md`.
  - `docs/30-architecture/specimen-flow-85-recurrence-escalation-sunset-warning.md`.
  - pass XC research and SlopOS/companions evaluation.
  - recurrence/escalation proof obligations in `docs/00-meta/datacube-proof-obligations.md`.
- Closes `F085` and moves `F086` to the single `next` slot without promoting a recurrence ledger, reliability score, reporter-confidence label, escalation trigger, status-sunset rule, standing-challenge registry, public warning API, status-page product, external escalation workflow, regulator/auditor packet, transparency-log policy, reputation model, enforcement ladder, or final SlopOS datacube shape.

## rev0089 (2026-05-15)

- Status reconciliation / disputed-remediation pressure test:
  - add `docs/00-meta/datacube-status-reconciliation-hygiene.md`, keeping remediation challenges, acknowledgement expiry, external impact claim maps, use-attestation challenges, public status sync receipts, safe disputed-status statements, and unresolved-for-now notes as process residue rather than schema.
  - add `docs/30-architecture/specimen-flow-84-status-reconciliation-disputed-remediation.md`, exercising a disputed remediation receipt, an expired acknowledgement, a contradictory external impact report, an unverifiable non-use attestation, and a stale public status banner.
  - add status-reconciliation proof obligations to `docs/00-meta/datacube-proof-obligations.md`.
- Research / companions / source hygiene:
  - add pass LXXXIX research and SlopOS/companions evaluation.
  - refresh lessons, inspiration harvest, load-bearing source register, bibliography, ledgers, roadmap, briefing surfaces, manifest wiring, and archive index.
  - close `F084` and move `F085` to the single `next` slot without promoting a status page product, claims tribunal, acknowledgement-expiry rules, impact-claim reconciliation API, use-attestation challenge registry, VEX/CSAF profile, in-toto predicate, transparency-log policy, reputation model, or final SlopOS datacube shape.

## rev0088 — impact triage, acknowledgement receipts, and remediation attestations
- continued online and sibling-archive research with a deeper focus on stale downstream use after correction propagation: consumer reports, acknowledgements, remediation claims, use/non-use attestations, stale model/eval results, generated explanations, and safe public impact statements;
- added pass LXXXVIII research and companion-cube evaluation notes plus `docs/00-meta/datacube-stale-downstream-impact-hygiene.md` so stale-use impact packets, consumer acknowledgement receipts, remediation attestations, use attestation notes, safe public impact statements, residual risk notes, historical-only notices, unsafe-for-new-use notices, and unrepairable-now notices can be rehearsed without becoming an incident manager, compliance registry, VEX/CSAF profile, in-toto predicate, AI incident taxonomy, or public status API;
- added specimen flow 83 around a stale public summary used by an external report, acknowledgement without remediation, partial catalog/dataset-owner remediation, an eval/model copy that cannot be repaired immediately, a scoped non-use attestation, a generated-explanation repair failure, interpretation-only impact, disputed reliance, and historical-only archive posture;
- refreshed proof obligations, lessons, inspiration harvests, source register, bibliography, ledgers, roadmap, release wiring, and briefing surfaces; marked `F083` done and moved disputed/expired remediation and external-impact-claim reconciliation to the single `next` slot;
- promoted no impact ledger, acknowledgement ledger, remediation registry, notification workflow, legal workflow, customer-status platform, VEX/CSAF profile, in-toto predicate, AI incident database, model unlearning process, eval governance program, public status API, or final SlopOS datacube shape.

## rev0087 — propagation receipts, snippet staleness, and agent invalidators
- continued online and sibling-archive research with a deeper focus on correction propagation after source-side public corrections: catalogs, mirrors, caches, snippets, crawler signals, generated explainers, retrieval indexes, training/evaluation copies, and unreachable external mirrors;
- added pass LXXXVII research and companion-cube evaluation notes plus `docs/00-meta/datacube-correction-propagation-hygiene.md` so propagation target registers, catalog status sync receipts, mirror revalidation receipts, cache invalidation receipts, search snippet stale witnesses, crawler signal receipts, agent explanation invalidators, retrieval index refresh receipts, training/evaluation stale-copy notices, external mirror unreachable notices, and propagation horizon notes can be rehearsed without becoming a crawler/indexing/catalog/agent subsystem;
- added specimen flow 82 around a corrected public summary whose status only partly propagates to catalog mirrors, download mirrors, CDN/browser caches, search snippets, sitemap/URL-change signals, cached agent explainers, vector indexes, public eval dataset cards, web archives, and uncooperative mirrors;
- refreshed proof obligations, lessons, inspiration harvests, source register, bibliography, ledgers, roadmap, release wiring, and briefing surfaces; marked `F082` done and moved stale-downstream impact/remediation pressure to the single `next` slot;
- promoted no propagation ledger, CDN/cache integration, crawler policy, sitemap/IndexNow workflow, Search Console workflow, public catalog, mirror-validation service, agent-memory system, retrieval index, training-data unlearning process, eval governance program, takedown workflow, public status API, or final SlopOS datacube shape.

## rev0086 — correction anchors, annotation provenance, stale citations, and dispute fences
- continued online and sibling-archive research with a deeper focus on public correction status, errata metadata, annotation body/target discipline, stale citations, generated explanations, and consumer disputes after localized or accessible public copies escape;
- added pass LXXXVI research and companion-cube evaluation notes plus `docs/00-meta/datacube-public-correction-dispute-hygiene.md` so correction anchors, erratum receipts, annotation receipts, stale-citation witnesses, generated-explanation receipts, public status banners, and consumer dispute packets can be rehearsed without becoming a public-feedback platform;
- added specimen flow 81 around corrected summaries, translated errata, stale external citations, public/reviewer annotations, generated-explanation invalidation, cached variant drift, and suppression-label disputes;
- refreshed proof obligations, lessons, inspiration harvests, source register, bibliography, ledgers, roadmap, release wiring, and briefing surfaces; marked `F081` done and moved correction-propagation / agent-cache invalidation pressure to the single `next` slot;
- promoted no correction API, annotation store, moderation workflow, ticketing product, citation resolver, DOI policy, generated-explanation service, public status vocabulary, legal-removal process, or final SlopOS datacube shape.

## rev0085 — 2026-05-14
- added pass LXXXV research and SlopOS/companions evaluation for localized public-copy variants, accessible chart/table alternatives, human-readable summaries, and renderer drift;
- added `docs/00-meta/datacube-localized-render-variants.md` as a bounded review surface for locale receipts, translated label sets, accessible render variants, human-summary tethers, render-transform notes, and renderer-drift refusals;
- added specimen flow 80 to pressure-test translated labels, locale-specific unit/number rendering, accessible chart/table alternatives, a plain-language summary that omits machine labels, and a downstream renderer that changes sorting/grouping;
- refreshed proof obligations, lessons, inspiration harvest, source register, bibliography, ledgers, roadmap, briefing surfaces, release manifest, and deterministic archive index;
- closed F080 and moved F081 public correction / errata / annotation pressure to the single next slot without promoting a localization framework, translation memory, accessibility conformance program, renderer API, renderer registry, BI/export product, public portal, or final SlopOS datacube shape.

## rev0084 — 2026-05-13
- added pass LXXXIV research and SlopOS/companions evaluation for downstream public-copy hygiene after disclosure-treated aggregate release;
- added `docs/00-meta/datacube-public-copy-hygiene.md` as a bounded review surface for public-copy labels, release-artifact receipts, mirror/caching posture, label-preservation checks, restatement chains, recomposition guards, notice/license propagation, and proof-of-copy tickets;
- added specimen flow 79 to pressure-test valid labeled BI exports, label-stripped CSV mirrors, restated noisy/suppressed public answers, downstream recomposition attempts, stale caches, notice/license non-recall, and digest-based copy proof without raw replay disclosure;
- refreshed proof obligations, lessons, inspiration harvest, source register, bibliography, ledgers, roadmap, briefing surfaces, release manifest, and deterministic archive index;
- closed F079 and moved F080 public-copy localization/accessibility/rendering-variant pressure to the single next slot without promoting a data package format, catalog vocabulary, BI governance product, mirror-validation service, cache-control profile, license engine, provenance ontology, public aggregate-release API, transparency log, verifier stack, or final SlopOS datacube shape.

## rev0083 — aggregate disclosure risk, small-cell guards, differencing cuts, and disclosure-budget humility
- continued online research with a stronger focus on statistical disclosure control, differential-privacy evaluation hazards, census reconstruction/differencing pressure, small-cell and dominance guards, repeated-query leakage, noisy release copy, and safe suppression/refusal language while SlopOS's datacube remains design-phase;
- added pass LXXXIII research synthesis, pass LXXXIII SlopOS / companions evaluation, `docs/00-meta/datacube-aggregate-disclosure-risk.md`, and specimen flow 78 for release cells, contributor evidence, small-cell/dominance guards, sibling-cut differencing, repeated-query ledgers, disclosure-budget notes, noise receipts, and public refusal copy;
- refreshed proof obligations, lessons, inspiration harvest, source register, bibliography, ledgers, roadmap, briefing surfaces, release manifest, archive index, and deterministic packaging while promoting no privacy engine, SDC method, differential-privacy accountant, query broker, public aggregate-release API, BI governance product, de-identification standard, or final SlopOS datacube shape.

## rev0082 — replay-evidence access, redaction tickets, verifier packets, and source-lock drift
- added pass LXXXII research and companion-cube evaluation notes focused on replay-evidence disclosure boundaries, verifier tickets, redaction cuts, derived proof packets, source-lock drift, ticket expiry, and aggregate-visible/raw-hidden consumer posture;
- added `docs/00-meta/datacube-replay-evidence-access.md` and specimen flow 77 so frozen-answer proof can be audience-bound without becoming a proof-bundle API, verifier service, de-identification standard, selective-disclosure system, transparency log, policy engine, or replay service;
- refreshed proof obligations, lessons, inspiration harvests, source register, bibliography, ledgers, roadmap, release wiring, and briefing surfaces; marked F077 done and moved aggregate disclosure risk / small-cell and repeated-query leakage pressure to the single `next` slot.

## rev0081 — replay survivability, retention windows, frozen cuts, and exact-answer humility
- continued online and sibling-archive research with a deeper focus on time-travel retention, snapshot expiration, vacuum/cleaning, tombstone retention, fail-safe access, savepoints, frontier compaction, and SlopOS mutable-data rollback gates;
- added pass LXXXI research and companion-cube evaluation notes plus `docs/00-meta/datacube-replay-survivability.md` so survivor sets, replay-readiness receipts, frozen answer packets, retention-window notes, sidecar-retention mismatch notes, explainable-not-replayable verdicts, and exact-answer refusals can be rehearsed without becoming canonical schema;
- added specimen flow 76 around replay after compaction, frozen answer survival, expired tombstone evidence, sidecar retention mismatch, runtime/policy drift, and exact historical answer requests;
- refreshed proof obligations, lessons, inspiration harvests, load-bearing source register, bibliography, question/assumption/pressure/followthrough ledgers, roadmap, briefing surfaces, release manifest, and deterministic packaging hygiene while promoting no replay service, archive substrate, answer-pack API, retention policy, warehouse/lakehouse/event-log choice, backup product, or final SlopOS datacube shape.

## rev0080 — negative evidence, refusal ledgers, stale-frontier receipts, and tombstone humility
- continued online research with a stronger focus on failed/blocked/missing datacube evidence: Great Expectations unexpected rows, dbt severity and stored failures, DataHub assertion/compiler posture, OpenLineage run/error receipts, Kafka/Debezium tombstones, Flink late-data/watermark discipline, Materialize frontiers, OpenTelemetry schema-transform impossibility, and SlopOS export-policy / migration-gate rules;
- added pass LXXX research synthesis and SlopOS/companions evaluation while keeping SlopOS explicitly design-phase;
- added `docs/00-meta/datacube-negative-evidence-refusal-ledgers.md` and specimen flow 75 for missing sidecars, blocked observation exports, unsupported assertion targets, stale frontiers, tombstone/withdrawal residue, and consumer-facing refusal rows;
- refreshed lessons, inspiration harvests, load-bearing sources, ledgers, roadmap, briefing surfaces, release manifest, and deterministic archive index;
- marked `F075` done and moved replay-after-compaction / retention-window survivability pressure to the single `next` slot;
- promoted no global refusal schema, public negative-evidence API, incident manager, assertion compiler, sidecar registry, frontier service, tombstone/delete implementation, or final SlopOS datacube shape.

## rev0079 — reservation cuts, view receipts, frontier witnesses, and compiler humility
- continued online research with a stronger focus on option-reservation artifacts: W3C observation/component discipline, Iceberg view metadata and Puffin sidecars, OpenLineage facets, Flink/Materialize/Timely progress frontiers, DataHub assertion-compilation posture, OpenTelemetry schema transforms, and SlopOS export/migration gates;
- added pass LXXIX research synthesis, pass LXXIX SlopOS/companions evaluation, `docs/00-meta/datacube-option-reservation-cuts.md`, and specimen flow 74 to pressure-test bounded observation exchange, no-data derived view, optional sidecars, frontier witnesses, assertion compiler receipts, and schema transform receipts;
- refreshed lessons, inspirations, load-bearing sources, ledgers, roadmap, manifest wiring, and release/process briefings; closed `F074` and moved negative-evidence/refusal-ledger pressure to `F075` as the single `next` item;
- promoted no observation API, RDF/SDMX contract, warehouse/lakehouse/streaming engine, semantic layer, sidecar registry, assertion DSL, or schema-transform language.

## rev0078 — semantic export cuts, contract subsets, fanout fences, and lineage sidecars
- added pass LXXVIII research and SlopOS/companion evaluation focused on semantic exports as derived review lenses with explicit refusal surfaces;
- added `docs/00-meta/datacube-semantic-export-constraints.md` as a checklist and anti-counterfeit guide rather than a schema, ADR, product choice, or API;
- added `docs/30-architecture/specimen-flow-73-semantic-export-contract-subset-fanout-sidecar-honesty.md` to close `F073` with public contract subsets, freshness basis, safe many-to-one joins, refused one-to-many fanout joins, and optional source-scoped row-lineage sidecars;
- refreshed lessons, inspiration harvests, source register, bibliography, ledgers, roadmap, briefing surfaces, manifest, and archive index; moved `F074` to the single `next` slot;
- still promoted no semantic layer, BI product, warehouse/lakehouse, public-contract schema, row-lineage constitution, or sidecar registry.

## rev0077 — measurement proof cuts, rate witnesses, and promotion obligations
- continued online and sibling-archive research with a deeper focus on measurement proof cuts, logical-type humility, cube/pivot query affordances, optional sidecars, and SlopOS data-contract/export/receipt discipline;
- added pass LXXVII research and companion-cube evaluation notes plus `docs/00-meta/datacube-proof-obligations.md` so future datacube nouns need proof packets before promotion;
- added specimen flow 72 around mixed source duration units, unity-stored percent rendering, original-currency money, converted comparison views, and late FX-rate restatement;
- refreshed measurement semantics, option reservations, review loop, lessons, inspiration harvests, source register, ledgers, followthrough state, manifest wiring, briefing surfaces, and deterministic packaging hygiene while promoting no universal conversion service, FX stack, warehouse, or semantic layer.

## rev0076 — option reservations, cube watchlist, and derived-view humility
- continued online research with a stronger focus on observation/component discipline, derived semantic-model exports, versioned view metadata, optional statistics/facet sidecars, event-time watermarks, schema-transform receipts, and assertion-compiler targets while the datacube is still embryonic;
- added pass LXXVI research synthesis, pass LXXVI SlopOS / companions evaluation, and `docs/00-meta/datacube-option-reservations.md` so Harbor can collect strong ideas without freezing a warehouse, semantic layer, streaming engine, row-identity regime, or sidecar registry;
- refreshed lessons, inspiration harvests, load-bearing source register, bibliography, ledgers, manifests, briefing surfaces, and deterministic packaging while keeping measurement semantics as the single `next` pressure-test lane.

## rev0075 — temporal witnesses, contract subsets, and lineage guards
- continued online research with a stronger focus on explicit time axes, contract/assertion separation, freshness-threshold posture, additive schema evolution, history-loss warnings, and optional row-lineage ideas;
- added pass LXXV research synthesis, pass LXXV SlopOS / companions evaluation, and a new `datacube-review-loop.md` process surface selected to preserve optionality while strengthening repo hygiene;
- refreshed lessons, inspiration harvests, source registers, ledgers, manifests, briefing surfaces, and deterministic packaging while keeping measurement semantics as the single `next` pressure-test lane.

## rev0074 — measurement semantics, rate witnesses, and canonical units
- continued online research with a stronger focus on UCUM semantic equivalence, FHIR Quantity and MoneyQuantity constraints, monetary-versus-physical-unit humility, base-unit discipline, and explicit currency-rate posture while the datacube is still embryonic;
- added pass LXXIV datacube evaluation, pass LXXIV research synthesis, `docs/00-meta/datacube-measurement-semantics.md`, and a seventy-first specimen selected to preserve optionality;
- refreshed lessons, inspirations, load-bearing sources, ledgers, manifests, and briefing surfaces; kept semantic-front-door and restatement-promotion pressure queued; strengthened repo hygiene so the new measurement-semantics surface stays wired; and reran the deterministic release hygiene flow.

## rev0073 — change-history lanes, replay cuts, and restatement receipts
- continued online research with a stronger focus on change-data feeds, changelog views, changed-row incremental queries, append-only operation-coded exports, and restatement humility while the datacube is still embryonic;
- added pass LXXIII datacube evaluation, pass LXXIII research synthesis, `docs/00-meta/datacube-change-history-lanes.md`, and a seventieth specimen selected to preserve optionality;
- refreshed lessons, inspirations, load-bearing sources, ledgers, manifests, and briefing surfaces; kept semantic-front-door and unit/currency pressure queued; strengthened repo hygiene so the new change-history-lanes surface stays wired; and reran the deterministic release hygiene flow.

## rev0072 — exactness classes, sketch witnesses, and error bands
- added `docs/00-meta/datacube-exactness-semantics.md`.
- added `docs/00-meta/research-synthesis-2026-03-25-pass-lxxii.md`.
- added `docs/00-meta/slopos-companions-evaluation-2026-03-25-pass-lxxii.md`.
- added `docs/30-architecture/specimen-flow-69-exactness-class-card-sketch-witness-and-error-band-note.md`.
- refreshed lessons, inspirations, source register, ledgers, manifest wiring, and release/process briefings for the new exactness-semantics seam.

## rev0071 — conformance lanes, bridge witnesses, and identity shadows
- added `docs/00-meta/datacube-conformance-lanes.md`.
- added `docs/00-meta/research-synthesis-2026-03-25-pass-lxxi.md`.
- added `docs/00-meta/slopos-companions-evaluation-2026-03-25-pass-lxxi.md`.
- added `docs/30-architecture/specimen-flow-68-conformance-lane-card-bridge-witness-and-identity-shadow-note.md`.
- refreshed lessons, inspirations, source register, ledgers, manifest wiring, and release/process briefings for the new conformance-lanes seam.

## rev0070 — aggregation semantics, fanout fences, and rollup classes
- added `docs/00-meta/datacube-aggregation-semantics.md`.
- added `docs/00-meta/research-synthesis-2026-03-25-pass-lxx.md`.
- added `docs/00-meta/slopos-companions-evaluation-2026-03-25-pass-lxx.md`.
- added `docs/30-architecture/specimen-flow-67-aggregation-class-card-fanout-fence-and-rollup-note.md`.
- refreshed lessons, inspirations, source register, ledgers, manifest wiring, and release/process briefings for the new aggregation-semantics seam.

## rev0069 — time axes, as-of witnesses, and knowledge cuts
- continued online research with a stronger focus on time-axis discipline for embryonic datacubes: Flink event-time versus processing-time, Db2 BUSINESS_TIME versus SYSTEM_TIME and explicit `AS OF` querying, SQL Server temporal-table caveats for delayed loads, and dbt SCD validity-window guidance;
- added pass LXIX research synthesis, pass LXIX SlopOS/companions evaluation, and a sixty-sixth specimen selected to pressure-test occurrence time, validity time, knowledge time, and published-cut time without freezing a temporal engine too early;
- added `docs/00-meta/datacube-time-axes.md` so Harbor can name temporal axes explicitly, keep “as of” basis visible, and treat published answers as knowledge cuts rather than timeless truth;
- refreshed lessons, inspirations, load-bearing sources, ledgers, briefing surfaces, manifest wiring, and repo hygiene for the new revision; and reran deterministic packaging.

## rev0068 — 2026-03-25
- continued online research with a stronger focus on contract-versus-evidence separation, producer-public assertion subsets, explicit freshness computation posture, and summary-result-versus-detailed-evidence discipline;
- added a pass LXVIII datacube evaluation, a pass LXVIII research synthesis, and a sixty-fifth specimen selected to preserve optionality;
- added `docs/00-meta/datacube-evidence-grades.md`, refreshed the load-bearing source register, refreshed ledgers/manifests/briefings, strengthened repo hygiene so evidence-grade wiring stays explicit, and reran deterministic packaging.

## rev0067 — 2026-03-25
- continued online research with a stronger focus on presence semantics, default-shadow humility, and absence-cause honesty across protobuf/schema and columnar systems;
- added a pass LXVII datacube evaluation, a pass LXVII research synthesis, and a sixty-fourth specimen selected to preserve optionality;
- added `docs/00-meta/datacube-presence-semantics.md`, refreshed the load-bearing source register and briefing/process surfaces, and reran repo hygiene checks.

## rev0066 — 2026-03-25
- continued online research with a stronger focus on data-contract categories, assertion building blocks, severity thresholds, observed-value availability, and temporary exception posture;
- added a pass LXVI datacube evaluation, a pass LXVI research synthesis, and a sixty-third specimen selected to preserve optionality;
- added datacube assertion posture, waiver receipts, and observed-value notes as compact process surfaces smaller than row meaning, compatibility verdicts, and engine choice;
- refreshed source registers, ledgers, manifests, briefing surfaces, and deterministic release packaging; kept the next major datacube pressure on restatement, semantic front doors, and change-history lanes.

## rev0065 — change classes, compatibility verdicts, and shadow diffs
- continued online research with a stronger focus on change classification, latest-only versus transitive compatibility, alias/default bridge discipline, retired-identifier hygiene, and mature-model overlap windows instead of premature universal versioning;
- added pass LXV datacube evaluation, pass LXV research synthesis, `docs/00-meta/datacube-change-classes.md`, and a sixty-second specimen selected to preserve optionality;
- refreshed lessons, inspirations, load-bearing sources, ledgers, manifests, and briefing surfaces; kept restatement / semantic-front-door / change-history pressure queued; strengthened repo hygiene so the new change-classes surface stays wired; and reran the deterministic release hygiene flow.

## rev0064 — contract tiers, assertion planes, and consumer-obligation slices
- continued online research with a stronger focus on data-contract category splits, assertion-plane portability, and consumer-driven obligation slicing instead of premature universal contract closure;
- added pass LXIV datacube evaluation, pass LXIV research synthesis, `docs/00-meta/datacube-contract-tiers.md`, and a sixty-first specimen selected to preserve optionality;
- refreshed lessons, inspirations, load-bearing sources, ledgers, manifests, and briefing surfaces; kept restatement / semantic-front-door / change-history pressure queued; strengthened repo hygiene so the new contract-tiers surface stays wired; and reran the deterministic release hygiene flow.

## rev0063 — stability rings, compatibility windows, and deprecation receipts

- added pass LXIII research synthesis on maturity rings, compatibility windows, immutable version pointers, and deprecation receipts;
- added pass LXIII SlopOS/companions evaluation focused on explicit surface maturity and same-revision hygiene while the sibling cubes are still in design phase;
- added `docs/00-meta/datacube-stability-rings.md` and refreshed `docs/00-meta/load-bearing-source-register.md`;
- added specimen flow 60 around stability ring cards, compatibility windows, consumer pins, and deprecation receipts;
- refreshed ledgers, followthrough state, release wiring, and repo/process surfaces for the new revision.

---
## rev0062 — publish lanes, derived artifacts, and promotion receipts

- added pass LXII research synthesis on publish lanes, branch rehearsals, historical tags, explicit promotion, and derived artifact discipline;
- added pass LXII SlopOS/companions evaluation focused on canonical review surfaces, lightweight source-refresh hygiene, and explicit datacube promotion history;
- added `docs/00-meta/datacube-artifact-boundary.md` and `docs/00-meta/load-bearing-source-register.md`;
- added specimen flow 59 around publish lane cards, branch rehearsals, and promotion merge receipts;
- refreshed ledgers, followthrough state, release wiring, and repo/process surfaces for the new revision.

---
## rev0061 — 2026-03-25
- continued online research with a stronger focus on datacube lessons from Kimball, Iceberg, Anchor Modeling, dbt, OpenLineage, Hudi, and Delta Lake; the main theme is grain-first design, additive evolution, versioned sidecars, and curated downstream contracts;
- added pass LXI datacube evaluation, pass LXI research synthesis, a datacube-design-principles process surface, and a fifty-eighth specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; re-queued the earlier actionable-body replay pressure as general backlog; queued restatement / semantic-front-door / change-history pressure next; strengthened repo hygiene so the new design-principles surface stays wired; and reran the deterministic release hygiene flow.

## rev0060 — 2026-03-24
- continued online research with a stronger focus on the February 2026 RAR metadata draft's actionable `authorization_details` bodies, ephemeral interaction-specific claims, trusted authorization-server-set rule, and `Cache-Control: no-store` guidance, plus RFC 9728 metadata caching and repair-after-rotation pressure;
- added pass LX datacube evaluation, pass LX research synthesis, and a fifty-seventh specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; marked the latest trusted-schema-audience pressure test done; and reran the deterministic release hygiene flow.

## rev0059 — schema-source notes, receiver-enriched detail cards, and cache-staleness detail warnings
- continued online research with a stronger focus on the February 2026 RAR metadata/error-signaling draft’s `authorization_details_types_metadata_endpoint`, mutually exclusive inline `schema` versus external `schema_uri`, required-types expressions, and actionable-body trusted-AS limits; RFC 9728 metadata caching; RFC 9396 receiver-filtered and extended detail views; and the March 2026 Identity Assertion JWT Authorization Grant draft’s modify/filter/omit behavior across the IdP and Resource Authorization Server;
- added a pass LIX datacube evaluation, a pass LIX research synthesis, and a fifty-sixth specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; marked the lingering schema-source / receiver-enriched-detail / cache-staleness pressure test done; queued trusted-schema-audience / stale-actionable-body pressure next; and reran packaging.

## rev0058 — granted-detail views, filtered-detail cards, and detail-schema vetoes
- continued online research with a stronger focus on RFC 9396 token-response granted details, receiver-filtered JWT and introspection detail views, schema-shaped `invalid_authorization_details` bottoms, and metadata-driven detail validation without portable schema overreach;
- added a pass LVIII datacube evaluation, a pass LVIII research synthesis, and a fifty-fifth specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; marked the granted-detail pressure test done; queued schema-source-note pressure next; and reran packaging.

## rev0057 — required-authorization rails, actionable authorization-detail offers, and authorization-type slates
- continued online research with a stronger focus on the February 2026 RAR metadata/error-signaling draft’s required-types expressions and actionable error bodies, RFC 9396 granted-versus-requested-versus-RS-filtered authorization_details, RFC 9470 stronger-here composition, and the March 2026 Identity Assertion JWT Authorization Grant draft’s granted-detail response behavior;
- added a pass LVII datacube evaluation, a pass LVII research synthesis, and a fifty-fourth specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; marked the lingering required-authorization / actionable-detail pressure test done; queued granted-detail-view / schema-mismatch pressure next; and reran packaging.

## rev0055 — recipient-target splits, default-audience conflicts, and alias-family drift notes
- continued online research with a stronger focus on RFC 9701 JWT-secured introspection recipient binding, RFC 7662 receiver-scoped introspection behavior, RFC 8707 / RFC 9068 default-or-mapped audience cues, and the March 2026 resource-token-response draft’s returned-resource-over-audience precedence;
- added pass LV datacube evaluation, pass LV research synthesis, and a fifty-second specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; marked the lingering recipient-target-split / default-audience-conflict pressure test done; queued receiver-scoped-disclosure / stronger-here-challenge pressure next; and reran packaging.

## rev0054 — JWT introspection response cards, response-over-token precedence, and alias-family mismatch notes
- continued online research with a stronger focus on RFC 9701 JWT-secured introspection responses, signed recipient-vs-nested-token target separation, March 2026 returned-resource-over-audience precedence, and receiver-local alias-family mismatch;
- added pass LIV datacube evaluation, pass LIV research synthesis, and a fifty-first specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; marked the lingering JWT-introspection / response-precedence pressure test done; queued recipient-target-split / precedence-conflict pressure next; and reran packaging.

## rev0053 — token-format target witnesses, resource-server coverage cards, and client-confidence ladders
- added pass LIII research synthesis and pass LIII datacube evaluation;
- added specimen flow 50 around token-format target witnesses, resource-server coverage cards, and client-confidence ladders;
- refreshed lessons, inspirations, promotion gates, ledgers, context pack, manifests, and archive index for the new release.

## rev0052 — 2026-03-24
- continued online research with a stronger focus on RFC 9068 default-resource-indicator cues, the February 2026 RFC9728bis challenge-derived broader-coverage rule, and the March 2026 resource-token-response draft’s duplicate-response validation failures and client-facing confirmation semantics;
- added a pass LII datacube evaluation, a pass LII research synthesis, and a forty-ninth specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; marked the lingering default-target-cue / coverage-note pressure test done; queued token-format-target / introspection-confidence pressure next; and reran packaging.

## rev0051 — 2026-03-24
- continued online research with a stronger focus on RFC 8707 omission/default-resource posture, RFC 9728 dynamic discovery, the March 2026 resource-token-response draft’s assigned-only and client-validation rules, and issuance-time resource confirmation discipline;
- added pass LI synthesis/evaluation plus specimen flow 48 on assigned-only lanes, requested-anchor minimums, and resource-confirmation floors;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; marked the lingering assigned-only-lane / requested-anchor-minimum / resource-confirmation-floor pressure test done; queued default-resource-indicator / confirmation-gap pressure next; and reran packaging.

## rev0050 — 2026-03-24
- continued online research with a stronger focus on RFC 8707 token-time restriction, March 2026 resource-response grant-bounded narrowing, scope-defined extra resources, no-request assigned resources, and typed `invalid_target` refusal;
- added a pass L datacube evaluation, a pass L research synthesis, and a forty-seventh specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; marked the lingering grant-bounded narrowing / assigned-resource pressure test done; queued resource-confirmation / assigned-only-lane pressure next; and reran packaging.

## rev0049 — 2026-03-24
- continued online research with a stronger focus on RFC9728bis challenge-versus-direct resource validation, token-exchange target-service discovery, RFC 8693 multi-target breadth, and resource-response subset/refusal rules;
- added a pass XLIX datacube evaluation, a pass XLIX research synthesis, and a forty-sixth specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; marked the lingering discovery-source / multi-resource narrowing pressure test done; queued grant-bounded narrowing / server-assigned-target pressure next; and reran packaging.

## rev0048 — 2026-03-24
- continued online research with a stronger focus on requested protected resources, exact DPoP `htu` proof targets, GNAP RS-first discovery, issuance-time `resource` echoes, and typed honesty for target-unbounded token results;
- added a pass XLVIII datacube evaluation, a pass XLVIII research synthesis, and a forty-fifth specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; marked the lingering request-target / effective-target-echo pressure test done; queued discovery-source / multi-resource narrowing pressure next; and reran packaging.

## rev0047 — 2026-03-24
- continued online research with a stronger focus on client-assertion exact endpoint audiences, JAR-versus-endpoint audience separation, endpoint-alias mismatch, DPoP target exactness, and future issuance-time target echoes;
- added a pass XLVII datacube evaluation, a pass XLVII research synthesis, and a forty-fourth specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; marked the lingering audience-basis pressure test done; queued exact-target/echo pressure next; and reran packaging.

## rev0046 — 2026-03-24
- continued online research with a stronger focus on chooser cleanup signals, stale credential suppression, display refresh, capability-gated support, and mediation reset after local sign-out;
- added a pass XLVI datacube evaluation, a pass XLVI research synthesis, and a forty-third specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; marked the lingering chooser-cleanup pressure test done; queued audience-basis / endpoint-alias pressure next; and reran packaging.

## rev0045 — 2026-03-24
- continued online research with a stronger focus on cross-device consent phishing pressure, user-code and `binding_message` interlocks, same-device collapse, notification-only callbacks, and continuation-bound key ideas;
- added a pass XLV datacube evaluation, a pass XLV research synthesis, and a forty-second specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; repaired followthrough drift for the completed web-message pressure test; and reran packaging.


## rev0044 — 2026-03-24
- continued online research with a stronger focus on popup- and iframe-based web-message auth returns, exact receiver/sender origin validation, opener-versus-parent lane choice, and origin-scoped leak surfaces;
- added a pass XLIV datacube evaluation, a pass XLIV research synthesis, and a forty-first specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; queued future effective-target echo pressure without promoting it; and reran packaging.

## rev0043 — 2026-03-24
- continued online research with a stronger focus on cross-toolkit or cross-tenant OAuth confusion, exact finish-hash verification, path-shaped metadata pitfalls, and future chooser-cleanup signals;
- added a pass XLIII datacube evaluation, a pass XLIII research synthesis, and a fortieth specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, followthrough state, manifests, and briefing surfaces; repaired stale followthrough drift from the previous revision; and reran packaging.

## rev0042 — 2026-03-24
- continued online research with a stronger focus on embedded third-party display cues, structured FedCM return parcels, exact issuer/basis binding, and design-phase singleton/promotion hygiene;
- added a pass XLII datacube evaluation, a pass XLII research synthesis, and a thirty-ninth specimen selected to preserve optionality;
- added an embryo-promotion contract, refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; marked the lingering preview-asset pressure test done; and strengthened repo hygiene so the new contract must stay wired across briefing surfaces before release.

## rev0041 — 2026-03-23
- continued online research with a stronger focus on client-display metadata, FedCM account pictures and custom labels, chooser-image privacy leakage, and origin-scoped provenance cues;
- added a pass XLI datacube evaluation, a pass XLI research synthesis, and a thirty-eighth specimen selected to refine the review-surface line without freezing a brand or trusted-display registry;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; marked the lingering review-card pressure test done; and strengthened repo hygiene so latest pass/specimen wiring must stay aligned before release.

## rev0040 — 2026-03-23
- continued online research with a stronger focus on bounded consent/review cards, explicit requester/RP cues, browser-owned chooser prompts, and honest shortening of displayed summaries;
- added a pass XL datacube evaluation, a pass XL research synthesis, and a thirty-seventh specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; marked the latest display-bound review pressure test done; and strengthened repo hygiene so roadmap focus drift now fails release.

## rev0039 — 2026-03-23
- continued online research with a stronger focus on exact review basis, request-object supremacy, chooser/browser distinguishability, fake-prompt resistance, and bounded displayed summaries;
- added a pass XXXIX datacube evaluation, a pass XXXIX research synthesis, and a thirty-sixth specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; strengthened repo hygiene so the latest pass heading must surface in lessons and inspirations; and reran deterministic packaging.

## rev0038 — 2026-03-23
- continued online research with a stronger focus on structured authorization asks, protected request basis, external/browser-owned prompt provenance, FedCM mediation, and WebAuthn authorization gestures;
- added a pass XXXVIII datacube evaluation, a pass XXXVIII research synthesis, and a thirty-fifth specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; marked the latest claim-release pressure test done; and strengthened repo hygiene so question IDs must now stay gapless before release.

## rev0037 — 2026-03-23
- continued online research with a stronger focus on OIDC requested-versus-returned claims, OIDC aggregated/distributed claim provenance, FedCM accounts-endpoint display facts, and WebAuthn display-bound account strings;
- added a pass XXXVII datacube evaluation, a pass XXXVII research synthesis, and a thirty-fourth specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; marked the latest assurance pressure test done; and strengthened repo hygiene so duplicate specimen-flow numbers on disk now fail release.

## rev0036 — 2026-03-23
- continued online research with a stronger focus on OIDC requested-versus-achieved `acr`, `amr` method evidence, WebAuthn `userVerification` versus UV, and mixed synced/device-bound passkey posture;
- added a pass XXXVI datacube evaluation, a pass XXXVI research synthesis, and a thirty-third specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; marked the latest support-advert pressure test done; and strengthened repo hygiene so the changelog must lead with the current revision before release.

## rev0035 — 2026-03-23
- continued online research with a stronger focus on RFC 8414 partial capability adverts, OpenID Connect Discovery defaults, WebAuthn non-binding hints/transports, and FedCM config flags that shape browser candidate space;
- added a pass XXXV datacube evaluation, a pass XXXV research synthesis, and a thirty-second specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; fixed a malformed bibliography/source line; and strengthened repo hygiene so bibliography entry collisions now fail release.

## rev0034 — 2026-03-23
- continued online research with a stronger focus on RFC 8414 / RFC 9728 well-known discovery exactness, FedCM well-known-plus-config layering, OpenID Federation resolved metadata, and Android Dynamic App Links refresh/ceiling behavior;
- added a pass XXXIV datacube evaluation, a pass XXXIV research synthesis, and a thirty-first specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; marked the latest live-lane pressure test done; fixed an old duplicate changelog revision heading; and strengthened repo hygiene so duplicate revision headings now fail release.

## rev0033 — 2026-03-23
- continued online research with a stronger focus on OAuth/OIDC `state` and `nonce`, PKCE per-request binders, WebAuthn challenge matching, and the boundary between late valid-looking results and live-lane adoption;
- added a pass XXXIII datacube evaluation, a pass XXXIII research synthesis, and a thirtieth specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; marked the latest cancel/deadline pressure test done; and reran the deterministic release hygiene flow.

## rev0032 — 2026-03-23
- continued online research with a stronger focus on Credential Management abort semantics, FedCM dialog dismissal and cooldown, WebAuthn `AbortError` versus `NotAllowedError`, Go request-context cancellation/deadline patterns, and the boundary between local stop signals and remote/provider verdicts;
- added a pass XXXII datacube evaluation, a pass XXXII research synthesis, and a twenty-ninth specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; marked the latest replay pressure test done; and reran the deterministic release hygiene flow.

## rev0031 — 2026-03-23
- continued online research with a stronger focus on PAR one-time `request_uri` semantics, PKCE per-request code binders, DPoP replay detection, WebAuthn challenge/signCount replay discipline, and exact-replay-only lessons worth stealing;
- added a pass XXXI datacube evaluation, a pass XXXI research synthesis, and a twenty-eighth specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; marked the latest pending/backoff pressure test done; and strengthened queue hygiene around duplicate specimen-flow numbers.

## rev0030 — 2026-03-23
- continued online research with a stronger focus on RFC 8628 pending/backoff/expiry semantics, typed refusal bottoms from OAuth/OIDC, and browser-mediated abandonment versus explicit denial;
- added a pass XXX datacube evaluation, a pass XXX research synthesis, and a twenty-seventh specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; marked the latest status-advert pressure test done; and strengthened queue hygiene around duplicate `next` and stale completed-latest drift.

## rev0029 — 2026-03-23
- continued online research with a stronger focus on FedCM login-status maps, mismatch dialogs, OIDC Session Management changed/unchanged re-checks, and privacy-preserving no-cheap-absence handling;
- added a pass XXIX datacube evaluation, a pass XXIX research synthesis, and a twenty-sixth specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, briefing surfaces, and deterministic packaging for the new revision.

## rev0028 — 2026-03-23
- continued online research with a stronger focus on OIDC logout `sid`, Native SSO `sid` validation, RFC 9493 subject identifiers, FedCM account matching/disconnect semantics, and WebAuthn user-handle versus credential-ID scope;
- added a pass XXVIII datacube evaluation, a pass XXVIII research synthesis, and a twenty-fifth specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; strengthened repo hygiene so a revision cannot silently claim it supersedes itself; and reran packaging.

## rev0027 — 2026-03-23
- continued online research with a stronger focus on OIDC `max_age`, `auth_time`, RFC 9470 recentness challenges, and the boundary between returned auth-event time and current freshness truth;
- added a pass XXVI datacube evaluation, a pass XXVI research synthesis, and a twenty-third specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and briefing surfaces; strengthened wiring hygiene for the latest pass/specimen docs; and reran packaging.

## rev0025 — 2026-03-23
- continued online research with a stronger focus on logout/disconnect/reset flows, silent-suppression posture, connected-account cleanup, and post-logout honesty;
- added a pass XXV datacube evaluation, a pass XXV research synthesis, and a twenty-second specimen selected to preserve optionality;
- refreshed lessons, inspirations, ledgers, manifests, and context surfaces; strengthened zip-ingestion hygiene; and simplified the release path.

## rev0024 — 2026-03-23
- continued online research with a stronger focus on OIDC login hints, FedCM chooser filtering, WebAuthn Level 3 hinting, and the boundary between primed choice and actual reviewed selection;
- added a pass XXIV datacube evaluation, a pass XXIV research synthesis, and a twenty-first specimen selected to preserve optionality;
- refreshed ledgers/manifests/briefings, repaired duplicate assumption/changelog drift, strengthened repo hygiene checks for duplicate IDs and duplicate top-level headings, and reran packaging.

## rev0023 — 2026-03-23
- continued online research with a stronger focus on browser-mediated silent auth, conditional mediation, typed interaction-required aftermath, and honest reauthentication floors;
- added a pass XXIII datacube evaluation, a pass XXIII research synthesis, and a twentieth specimen selected to preserve optionality;
- refreshed ledgers/manifests/briefings, added bibliography entries for mediation and OIDC specs, strengthened repo hygiene checks for summary/codename/stale-revision drift, and reran packaging.

## rev0022 — continuity hints, revalidation turns, and mismatch honesty
- added pass XXII research synthesis and pass XXII datacube evaluation;
- added specimen flow 19 around continuity hints, returning-account hints, revalidation turns, and mismatch honesty;
- refreshed lessons, inspirations, ledgers, context pack, manifests, docs map, and archive index for the new release;
- strengthened repo hygiene checks around shared revision fields and manifest core-doc references.

## rev0021 — route ceilings, refinement rails, and fallback honesty
- added pass XXI research synthesis and pass XXI datacube evaluation;
- added specimen flow 18 around route ceilings, refinement rails, exclusion rails, and fallback honesty;
- refreshed lessons, inspirations, ledgers, context pack, manifests, docs map, and archive index for the new release;
- added a deterministic release packager and strengthened repo hygiene checks around manifest/file-count drift.

## rev0020 — proximity signals, timebound codes, and risk ladders
- added pass XX research synthesis and pass XX datacube evaluation;
- added specimen flow 17 around proximity signals, timebound codes, and risk ladders;
- refreshed lessons, inspirations, ledgers, context pack, manifests, and archive index for the new release.

## rev0019 — resource audiences, scope splits, and auth targets
- added pass XIX research synthesis and pass XIX datacube evaluation;
- added specimen flow 16 around resource audiences, scope splits, and auth targets;
- refreshed lessons, inspirations, ledgers, context pack, manifests, and archive index for the new release.

## rev0018 — step-up challenges, resource metadata, and auth stairs
- added pass XVIII research synthesis and pass XVIII datacube evaluation;
- added specimen flow 15 around step-up challenges, resource metadata, and auth stairs;
- refreshed lessons, inspirations, ledgers, context pack, manifests, and archive index for the new release.

## rev0017 — request objects, policy witnesses, and signed finish envelopes
- added pass XVIII research synthesis and pass XVIII datacube evaluation;
- added specimen flow 14 around request objects, policy witnesses, and signed finish envelopes;
- refreshed lessons, inspirations, ledgers, context pack, manifests, and archive index for the new release.

## rev0016 — issuer pins, mix-up vetoes, and origin cards
- added pass XVI research synthesis and pass XVI datacube evaluation;
- added specimen flow 13 around issuer pins, mix-up vetoes, and origin cards;
- refreshed lessons, inspirations, ledgers, context pack, manifests, and archive index for the new release.

## rev0015 — backchannel challenges, finish envelopes, and veto floors
- added pass XV research synthesis and pass XV datacube evaluation;
- added specimen flow 12 around backchannel challenge finish envelope and veto floor;
- refreshed lessons, inspirations, ledgers, context pack, manifests, and archive index for the new release.

## rev0014 — interaction references, finish tickets, and adoption checkpoints
- added pass XIV research synthesis and pass XIV datacube evaluation;
- added specimen flow 11 around interaction references, finish tickets, and adoption checkpoints;
- refreshed ledgers, context pack, manifests, and archive index for the new release.

## rev0013 — 2026-03-23
- continued online research with a stronger focus on GNAP-style continuations, finish methods, and capability-floor hygiene
- added a pass XII datacube evaluation, a pass XII research synthesis, and a ninth specimen selected to preserve optionality
- refreshed lessons, inspirations, ledgers, manifests, and context surfaces; then reran repo hygiene checks

## rev0011 — 2026-03-23
- continued online research with a stronger focus on typed requested consequences, continuation bonds, and adoption-veto hygiene;
- added a pass XI datacube evaluation, a pass XI research synthesis, and an eighth specimen selected to preserve optionality;
- refreshed lessons, inspirations, queues, manifests, and context surfaces; cleaned duplicate sections from prior passes; and reran repo hygiene checks.

## rev0008 — 2026-03-23
- continued online research with a stronger focus on PAR-style staged authorization, opaque request references, and DPoP-like proof-bound return exchange;
- added a pass VIII datacube evaluation, a pass VIII research synthesis, and a fifth specimen selected to preserve optionality;
- refreshed lessons, queues, manifests, and context surfaces; repaired duplicate lesson sections; and reran repo hygiene checks.

## rev0007 — 2026-03-23
- continued online research with a stronger focus on ephemeral browser sessions, associated-domain fallback, FedCM-style bounded identity mediation, and post-return adoption;
- added a pass VII datacube evaluation, a pass VII research synthesis, and a fourth specimen selected to preserve optionality;
- repaired changelog drift, refreshed queues/ledgers/manifests, and reran repo hygiene checks.

## rev0006 — 2026-03-23
- continued online research with a stronger focus on lessons from cross-device flows, dynamic routing, session hardening, capability routing, restore-time humility, and explicit rebound/reacquire patterns;
- added a pass VI datacube evaluation, a pass VI research synthesis, and a third specimen selected to preserve optionality;
- cleaned registry/ledger identifiers, refreshed bibliography and release metadata, and reran repo hygiene checks.

## rev0005 — 2026-03-23
- continued online research with a stronger focus on lessons worth stealing from mature ecosystems and current standards;
- added a pass V datacube evaluation, a pass V research synthesis, and a second specimen selected to preserve optionality;
- refreshed repo/process surfaces, queues, ledgers, bibliography, and release metadata while keeping the cube embryonic.

## rev0004 — 2026-03-23
- continued online research with a focus on anti-lessons, specimen flows, and option-preserving architecture moves;
- added a pass IV datacube evaluation plus a new research synthesis and a first concrete specimen document;
- refreshed lessons, inspiration, queues, ledgers, bibliography, and repo hygiene/process surfaces.

## rev0003 — 2026-03-23
- continued online research and a deeper readthrough of SlopOS plus companion cubes;
- added a lessons-from-the-past file, a datacube evaluation pass, and promotion gates/specimen tests;
- added followthrough/irreversible-decision hygiene surfaces and a runnable repo check.

## rev0002 — 2026-03-23
- deepened the founding embryo after reading the current cube ecology and official outside sources;
- sharpened the cube’s internal separations and neighbor boundaries;
- added roadmap, trajectory, ledgers, ADRs, and expanded architecture notes.
