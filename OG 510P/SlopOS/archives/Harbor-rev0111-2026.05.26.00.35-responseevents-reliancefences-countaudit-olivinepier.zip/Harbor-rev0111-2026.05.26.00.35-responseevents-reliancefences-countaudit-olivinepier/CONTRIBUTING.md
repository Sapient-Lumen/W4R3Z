# Contributing

Keep additions small and typed.
Prefer strengthening one existing distinction over inventing a new umbrella abstraction.
New documents should usually justify themselves as a decision surface, a registry, a specimen proof cut, or a hygiene/process surface.
Before adding a new permanent noun, ask whether it can survive at least one specimen test without borrowing hidden truth from a sibling cube.

If a second closely related noun cluster appears, either compress it back down or pay for explicit structure in the same revision; do not let singleton/specimen status linger by inertia.

Apply the archive-side review questions in `docs/00-meta/embryo-promotion-contract.md` before retaining or promoting any new Harbor noun cluster.

When a crossing smells auth-shaped, check whether exact local connection context is the real truth before promoting any new display, callback, or account-adjacent noun.

When a crossing smells cross-device, check whether the smallest truthful move is a pairing cue or same-device veto before promoting any portable handoff or connected-account noun.

When a crossing smells resource-target-shaped, check whether the smallest truthful move is weaker confirmation, assigned-only residue, or a requested-anchor veto before promoting any new entitlement or target-confirmation noun.


Before widening Harbor's datacube, re-read `docs/00-meta/datacube-design-principles.md` and make sure the move states the grain, history policy, and whether the new field belongs in the core contract or a smaller facet/sidecar first.

Before widening a consumer-facing Harbor datacube lane, re-read `docs/00-meta/datacube-stability-rings.md` and make the maturity ring, compatibility window, and retirement/deprecation posture explicit before calling the surface stable.


Before declaring a published-lane edit “compatible,” re-read `docs/00-meta/datacube-change-classes.md` and classify whether the move is shape-additive, shape-bridged, shape-breaking, meaning-reinterpreting, assertion/service-only, or historical/restatement first.


Before turning a failing or missing Harbor check into a semantic conclusion, re-read `docs/00-meta/datacube-assertion-posture.md` and make the result posture, observed-value basis, and any waiver expiry explicit first.

Before treating a blank, zero, default enum member, or missing child as the same kind of fact, re-read `docs/00-meta/datacube-presence-semantics.md` and make the presence class, absence cause, and any default shadow explicit first.

Before treating a stable or green-looking Harbor lane as if it were both current and exactly replayable, re-read `docs/00-meta/datacube-evidence-grades.md` and make the evidence grade, head-trust note, and freshness witness explicit first.


Before treating a Harbor number as safely summable or safely reusable after a one-to-many join, re-read `docs/00-meta/datacube-aggregation-semantics.md` and make the aggregation class, fanout fence, and rollup note explicit first.


Before treating a shared-looking Harbor key or label as one settled enterprise dimension, re-read `docs/00-meta/datacube-conformance-lanes.md`, `docs/00-meta/datacube-exactness-semantics.md` and make the conformance class, bridge witness, shrunken-slice scope, and any identity shadow explicit first.
Before promoting a borrowed datacube idea, re-read `docs/00-meta/datacube-option-reservations.md` and verify the idea is still a reservation, has a specimen trigger, and has not smuggled in a warehouse, semantic layer, stream processor, row identity, assertion engine, or sidecar registry.


Before turning missing, blocked, unsupported, stale, withdrawn, or refused evidence into a conclusion, re-read `docs/00-meta/datacube-negative-evidence-refusal-ledgers.md` and make the basis, scope, audience, lifecycle, safe alternative, and non-promises explicit first.


## rev0089 process note

Status reconciliation remains design-phase process residue. Review `docs/00-meta/datacube-status-reconciliation-hygiene.md` and `docs/30-architecture/specimen-flow-84-status-reconciliation-disputed-remediation.md` before adding any dispute/status/acknowledgement vocabulary, and keep the embryo-promotion contract and datacube design principles in force.
