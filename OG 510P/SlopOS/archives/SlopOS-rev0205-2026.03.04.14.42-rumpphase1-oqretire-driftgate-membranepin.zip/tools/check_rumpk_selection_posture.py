#!/usr/bin/env python3
"""CI drift gate: pin D-RUMPK v0 selection posture (keeps OQ-0003 resolved).

Why this exists
--------------
Sealed compatibility already has a pinned membrane contract (D-FCELL), but the
choice of what runtime runs *inside* a Foreign Cell (D-RUMPK) can drift into
hand-wavy prose and reopen the comparison space every time.

This check enforces a small, implementable v0 posture document and keeps it
wired into the discovery surfaces, so sealed-compat work stays anchored and reviewable.

Additionally, it keeps the CH-FCELL manifest doc *and the membrane contract* honest
by requiring them to reflect the pinned v0 runtime posture (no accidental
"we support LKL" drift).

Exit code:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

DOC = ROOT / "docs/30-architecture/rumpk-selection-posture-v0.md"
FCELL_MANIFEST = ROOT / "docs/30-architecture/foreign-cell-manifest-schema-v0.md"
FCELL_CONTRACT = ROOT / "docs/30-architecture/foreign-cell-contract.md"

DISCOVERY_SURFACES = {
    # Decision map lives next to the posture doc, so references often use the basename.
    ROOT / "docs/30-architecture/decision-map.md": ["rumpk-selection-posture-v0.md"],
    # Trajectory map references use full paths.
    ROOT / "docs/00-meta/trajectory-map.md": ["docs/30-architecture/rumpk-selection-posture-v0.md"],
    # docs index uses docs-relative paths.
    ROOT / "docs/README.md": ["30-architecture/rumpk-selection-posture-v0.md"],
}


def fail(msg: str) -> None:
    print(f"[rumpk-posture] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[rumpk-posture] OK: {msg}")


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def extract_open_question_block(md: str) -> str:
    lines = md.splitlines()
    in_section = False
    out: list[str] = []
    for ln in lines:
        if ln.strip() == "## Open questions (tracked as decision surfaces)":
            in_section = True
            continue
        if in_section and ln.startswith("## "):
            break
        if in_section:
            out.append(ln)
    return "\n".join(out)


def main() -> None:
    if not DOC.exists():
        fail("missing docs/30-architecture/rumpk-selection-posture-v0.md")

    doc_txt = read(DOC)
    for tok in ["D-RUMPK", "D-FCELL", "OQ-0003"]:
        if tok not in doc_txt:
            fail(f"posture doc does not mention required anchor token: {tok}")

    # Pin the Phase-1 scope decision: "no second runtime family".
    if "Phase 1" not in doc_txt or "second compat runtime" not in doc_txt:
        fail("posture doc must state the Phase-1 ban on introducing a second compat runtime family")

    # Ensure the posture doc is discoverable from core indices.
    missing = []
    for p, needles in DISCOVERY_SURFACES.items():
        if not p.exists():
            fail(f"missing discovery surface: {p}")
        txt = read(p)
        if not any(n in txt for n in needles):
            missing.append(str(p.relative_to(ROOT)))
    if missing:
        fail("posture doc not referenced from discovery surfaces: " + ", ".join(missing))

    # Ensure OQ-0003 is recorded as resolved (not open) and points to the posture doc.
    traj = read(ROOT / "docs/00-meta/trajectory-map.md")
    if "OQ-0003" not in traj:
        fail("trajectory-map does not contain OQ-0003")
    if "docs/30-architecture/rumpk-selection-posture-v0.md" not in traj:
        fail("trajectory-map OQ-0003 does not point at docs/30-architecture/rumpk-selection-posture-v0.md")

    open_block = extract_open_question_block(traj)
    if "OQ-0003" in open_block:
        fail("trajectory-map still lists OQ-0003 under Open questions (it must be resolved/removed)")

    # Minimal research wiring: posture doc should cite at least one compat runtime REF.
    if "REF-RUMPKERNEL" not in doc_txt:
        fail("posture doc should cite at least one REF-RUMPKERNEL* entry")

    # Keep sealed compat honest: CH-FCELL v0 must reflect the pinned v0 runtime posture.
    if not FCELL_MANIFEST.exists():
        fail("missing docs/30-architecture/foreign-cell-manifest-schema-v0.md")
    fcell_txt = read(FCELL_MANIFEST)
    required_phrases = [
        "`runtime.kind` MUST be `rump`",
        "see `rumpk-selection-posture-v0.md`",
    ]
    for ph in required_phrases:
        if ph not in fcell_txt:
            fail(f"CH-FCELL v0 manifest doc missing required D-RUMPK v0 posture linkage: {ph}")

    # Keep the membrane contract honest: it must call out rump-only v0 posture (no implied LKL/gVisor support).
    if not FCELL_CONTRACT.exists():
        fail("missing docs/30-architecture/foreign-cell-contract.md")
    contract_txt = read(FCELL_CONTRACT)
    required_contract_phrases = [
        "v0 internal runtime posture is **rump-only**",
        "see `rumpk-selection-posture-v0.md`",
    ]
    for ph in required_contract_phrases:
        if ph not in contract_txt:
            fail(f"foreign-cell contract doc missing required D-RUMPK v0 posture statement: {ph}")

    ok("D-RUMPK v0 selection posture is present, Phase-1 scoped, discoverable, and reflected in CH-FCELL + membrane contract")


if __name__ == "__main__":
    main()
