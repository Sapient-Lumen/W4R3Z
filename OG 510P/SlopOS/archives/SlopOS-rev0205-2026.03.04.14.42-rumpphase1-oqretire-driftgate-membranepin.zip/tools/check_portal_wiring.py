#!/usr/bin/env python3
"""Portal taxonomy wiring drift gate.

Goal: keep the closed `portal.*` promise-token set coherent across the
archive's authority substrate surfaces.

We treat `docs/30-architecture/portal-family-registry.md` as the canonical
portal token list, and enforce that other control points match it:
  - CH-PLEDGE token list (pledge-contract-schema-v0.md)
  - pledge token→effect mapping table (pledge-token-mapping.md)
  - CH-FCELL portal allowlist seeds (foreign-cell-manifest-schema-v0.md)
  - lane gate keys for portal families (cfg.params.lane.portal.*; closed and complete)

This prevents “taxonomy drift” that would silently weaken:
  - sealed-compat (Foreign Cell interop allowlists), and
  - workflow mediation (portal intents),
by ensuring validators can keep the set closed and fail-closed.

Design constraints: tiny, dependency-free, deterministic.
"""

from __future__ import annotations

import re
import sys
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Problem:
    path: str
    detail: str


RE_BT_PORTAL = re.compile(r"`(portal\.[a-z0-9]+)`")
RE_LANE_PORTAL = re.compile(r"cfg\.params\.lane\.portal\.([a-z0-9_]+)")


def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def read_text(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def _strip_bt(s: str) -> str:
    return s.strip().strip("`").strip()


def parse_portal_tokens_from_portal_registry(md: str) -> tuple[list[str], set[str]]:
    """Return (ordered_tokens, token_set) from portal-family-registry.md.

    We parse the portal families markdown table and extract the CH-PLEDGE token column.
    The table may gain columns over time; we locate the token column by header name.
    """
    lines = md.splitlines()

    hdr_i = None
    for i, ln in enumerate(lines):
        if ln.strip().startswith("| Portal family |"):
            hdr_i = i
            break
    if hdr_i is None:
        return [], set()

    header = [p.strip() for p in lines[hdr_i].strip().strip("|").split("|")]
    try:
        idx_token = header.index("CH-PLEDGE token")
    except ValueError:
        return [], set()

    ordered: list[str] = []
    for ln in lines[hdr_i + 2 :]:
        s = ln.strip()
        if not s.startswith("|"):
            break
        if s.startswith("|---") or s.startswith("| Portal family"):
            continue
        parts = [p.strip() for p in s.strip("|").split("|")]
        if len(parts) <= idx_token:
            continue
        tok = _strip_bt(parts[idx_token])
        if tok.startswith("portal."):
            ordered.append(tok)

    return ordered, set(ordered)


def parse_portal_tokens_from_mapping_table(md: str) -> set[str]:
    toks: set[str] = set()
    for ln in md.splitlines():
        s = ln.strip()
        if not s.startswith("|"):
            continue
        if s.startswith("|---") or s.startswith("| CH-PLEDGE token"):
            continue
        parts = [p.strip() for p in s.strip("|").split("|")]
        if not parts:
            continue
        tok = _strip_bt(parts[0])
        if tok.startswith("portal."):
            toks.add(tok)
    return toks


def parse_portal_tokens_from_backticks(md: str) -> set[str]:
    return set(RE_BT_PORTAL.findall(md))


def parse_lane_gate_portals(md: str) -> set[str]:
    toks: set[str] = set()
    for m in RE_LANE_PORTAL.finditer(md):
        name = m.group(1).replace("_", "-")
        toks.add(f"portal.{name}")
    return toks


def main() -> int:
    root = repo_root()

    p_portal = root / "docs/30-architecture/portal-family-registry.md"
    p_pledge = root / "docs/30-architecture/pledge-contract-schema-v0.md"
    p_map = root / "docs/30-architecture/pledge-token-mapping.md"
    p_fcell = root / "docs/30-architecture/foreign-cell-manifest-schema-v0.md"
    p_cfg = root / "docs/30-architecture/config-toggle-registry.md"
    p_effcon = root / "docs/30-architecture/effect-contract-schema-v0.md"

    missing = [p for p in [p_portal, p_pledge, p_map, p_fcell, p_cfg, p_effcon] if not p.exists()]
    if missing:
        for p in missing:
            print(f"ERROR: missing required file: {p}")
        return 2

    portal_md = read_text(p_portal)
    ordered, canonical = parse_portal_tokens_from_portal_registry(portal_md)

    problems: list[Problem] = []

    # Uniqueness check: duplicates in canonical list are drift.
    seen: set[str] = set()
    dups: set[str] = set()
    for t in ordered:
        if t in seen:
            dups.add(t)
        seen.add(t)
    if dups:
        problems.append(Problem(str(p_portal.relative_to(root)), f"duplicate portal tokens in registry: {', '.join(sorted(dups))}"))

    pledge_tokens = parse_portal_tokens_from_backticks(read_text(p_pledge))
    map_tokens = parse_portal_tokens_from_mapping_table(read_text(p_map))

    fcell_md = read_text(p_fcell)
    fcell_tokens = parse_portal_tokens_from_backticks(fcell_md)

    # pledge contract includes non-portal tokens too; we only pick portal.* via regex.

    def check_set(name: str, path: Path, s: set[str]) -> None:
        extra = sorted([t for t in s if t not in canonical])
        missing = sorted([t for t in canonical if t not in s])
        if extra:
            problems.append(Problem(str(path.relative_to(root)), f"{name}: contains portal tokens not in portal registry: {', '.join(extra)}"))
        if missing:
            problems.append(Problem(str(path.relative_to(root)), f"{name}: missing portal tokens present in portal registry: {', '.join(missing)}"))

    check_set("pledge-contract", p_pledge, pledge_tokens)
    check_set("pledge-token-mapping", p_map, map_tokens)

    # CH-FCELL portal allowlist seeds: we support two shapes.
    #
    # 1) Enumerated seed list (legacy): doc literally lists the full canonical portal token set.
    # 2) Canonical-reference (preferred): doc states that portal_token is the closed set from
    #    portal-family-registry.md (avoids duplication drift). In this mode, any example
    #    portal tokens mentioned in backticks must be a subset of canonical.
    if "portal-family-registry.md" in fcell_md and "closed set of CH-PLEDGE portal tokens" in fcell_md:
        extra = sorted([t for t in fcell_tokens if t not in canonical])
        if extra:
            problems.append(Problem(str(p_fcell.relative_to(root)), f"foreign-cell-manifest: contains portal tokens not in portal registry: {', '.join(extra)}"))
    else:
        # Enforce that the *allowlisted tokens* it names are coherent.
        check_set("foreign-cell-manifest", p_fcell, fcell_tokens)

    # Lane-gate keys referencing portal families must map to canonical portal tokens.
    lane_tokens = parse_lane_gate_portals(read_text(p_cfg)) | parse_lane_gate_portals(read_text(p_effcon))
    lane_unknown = sorted([t for t in lane_tokens if t not in canonical])
    if lane_unknown:
        problems.append(Problem("docs/30-architecture/config-toggle-registry.md + effect-contract-schema-v0.md", f"lane portal keys reference unknown portal tokens: {', '.join(lane_unknown)}"))

    # Every portal family must be policy-killable via a cfg.params.lane.portal.<family> toggle.
    missing_lane = sorted([t for t in canonical if t not in lane_tokens])
    if missing_lane:
        problems.append(Problem("docs/30-architecture/config-toggle-registry.md", "missing cfg.params.lane.portal.* kill switches for portal families: " + ', '.join(missing_lane)))

    if problems:
        print("Portal wiring drift detected:\n")
        for pr in problems:
            print(f"- {pr.path}: {pr.detail}")
        print("\nFix: update the relevant docs so all portal token sets match portal-family-registry.md.")
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
