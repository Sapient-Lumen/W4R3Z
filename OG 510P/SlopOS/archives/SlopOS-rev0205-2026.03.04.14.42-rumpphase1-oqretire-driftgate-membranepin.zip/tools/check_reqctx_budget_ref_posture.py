#!/usr/bin/env python3
"""CI drift gate: keep CH-REQCTX budget reference posture discoverable + wired.

Rationale
---------
CH-REQCTX v1 carries `budget_desc_digests` as an *untyped* digest list.
That is deliberate early-surface minimalism, but it can drift into ambiguous
"resolve anything" semantics unless we pin a consumer-typed contract.

This guardrail is intentionally narrow:
- Requires the posture doc to exist and be linked from key discovery surfaces.
- Requires the capshell budget enforcement seam to reference the posture.
- Requires OQ-0008 to point at the pinned v0 posture.

Fail-closed: if any anchor is missing, lint fails.
"""

from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def fail(msg: str) -> int:
    print(f"[reqctx-budgetref] FAIL: {msg}")
    return 1


def ok(msg: str) -> None:
    print(f"[reqctx-budgetref] OK: {msg}")


def main() -> int:
    posture = ROOT / "docs/30-architecture/reqctx-budget-ref-posture-v0.md"
    docs_readme = ROOT / "docs/README.md"
    reqctx = ROOT / "docs/30-architecture/request-context-schema-v1.md"
    acp_sem = ROOT / "docs/70-llm-control/acp-validator-semantics.md"
    poreg = ROOT / "docs/20-assurance/proof-obligation-registry.md"
    traj = ROOT / "docs/00-meta/trajectory-map.md"
    evid = ROOT / "docs/00-meta/evidence-index.md"
    tools_readme = ROOT / "tools/README.md"
    aref_posture = "artifact-resolution-posture-v0.md"

    for p in (posture, docs_readme, reqctx, acp_sem, poreg, traj, evid, tools_readme):
        if not p.exists():
            return fail(f"missing required file: {p.relative_to(ROOT)}")

    # 1) Posture doc includes the key contract phrases.
    t = read(posture)
    must = [
        "untyped",
        "only",
        "CH-BUDGET v0",
        "non-ambient",
        "locator",
        aref_posture,
    ]
    missing = [m for m in must if m not in t]
    if missing:
        return fail(f"posture doc missing anchor(s): {', '.join(missing)}")
    ok("posture doc contains required anchors")

    # 2) Discoverability from docs/README.md.
    if "reqctx-budget-ref-posture-v0.md" not in read(docs_readme):
        return fail("docs/README.md missing link to reqctx-budget-ref-posture-v0.md")
    ok("docs/README.md links the posture doc")

    # 3) CH-REQCTX schema doc references the posture.
    r = read(reqctx)
    if "reqctx-budget-ref-posture-v0.md" not in r:
        return fail("request-context-schema-v1.md missing reference to posture doc")
    if aref_posture not in r:
        return fail("request-context-schema-v1.md missing reference to artifact-resolution posture")
    ok("CH-REQCTX schema doc wires the posture")

    # 4) ACP validator semantics references the posture.
    s = read(acp_sem)
    if "reqctx-budget-ref-posture-v0.md" not in s:
        return fail("acp-validator-semantics.md missing reference to posture doc")
    ok("ACP validator semantics wire the posture")

    # 5) PO-CAPSHELL-BUDGET-REQ references the posture.
    ptxt = read(poreg)
    if "PO-CAPSHELL-BUDGET-REQ" not in ptxt:
        return fail("proof-obligation-registry.md missing PO-CAPSHELL-BUDGET-REQ")
    if "reqctx-budget-ref-posture-v0.md" not in ptxt:
        return fail("PO-CAPSHELL-BUDGET-REQ missing posture reference")
    ok("PO-CAPSHELL-BUDGET-REQ references the posture")

    # 6) Open question OQ-0008 points at the posture.
    tr = read(traj)
    if "OQ-0008" not in tr or "reqctx-budget-ref-posture-v0.md" not in tr:
        return fail("trajectory-map.md OQ-0008 must reference reqctx-budget-ref-posture-v0.md")
    ok("trajectory-map OQ-0008 references posture")

    # 7) Evidence index includes an entry for this drift gate.
    ev = read(evid)
    if "EVID-2026-205" not in ev or "tools/check_reqctx_budget_ref_posture.py" not in ev:
        return fail("evidence-index.md missing EVID-2026-205 entry pointing at this tool")
    ok("Evidence index includes EVID-2026-205")

    # 8) tools/README mentions the drift gate (check_guardrail_wiring expects it).
    if "check_reqctx_budget_ref_posture.py" not in read(tools_readme):
        return fail("tools/README.md missing check_reqctx_budget_ref_posture.py entry")
    ok("tools/README mentions the drift gate")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
