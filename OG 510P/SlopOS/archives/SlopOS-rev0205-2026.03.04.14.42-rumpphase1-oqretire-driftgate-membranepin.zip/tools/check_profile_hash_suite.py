#!/usr/bin/env python3
"""CI drift gate: pin the archive-wide v0 meaning of "profile hash".

Why this exists
--------------
Many specs say "digest length matches the profile hash" / "hashlen" without
saying which hash suite that means.

We pin the v0 contract (D-HASH) to avoid drift:
- mixed algorithms or lengths across validators/tools,
- human-facing encodings accidentally becoming privileged inputs,
- and receipt/conflict-key/ordering hook mismatches.

Checks (fail closed):
- The posture doc exists: docs/30-architecture/profile-hash-suite-v0.md
- It is discoverable (docs/README.md) and must-read (llm-runbook)
- It is referenced from the key seams that rely on hashlen:
  - typed-id-contract-v0.md
  - conflict-key-derivation-registry.md
  - decision-map.md includes D-HASH and links the doc
- The posture doc states SHA-256 and hashlen=32 and cites primary refs.

Design constraints: tiny, dependency-free, deterministic.
"""

from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

DOC = ROOT / "docs/30-architecture/profile-hash-suite-v0.md"
DOCS_README = ROOT / "docs/README.md"
RUNBOOK = ROOT / "docs/00-meta/llm-runbook.md"
DECISIONS = ROOT / "docs/30-architecture/decision-map.md"
TYPEDID = ROOT / "docs/30-architecture/typed-id-contract-v0.md"
CKDERIVE = ROOT / "docs/30-architecture/conflict-key-derivation-registry.md"


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def fail(msg: str) -> None:
    print(f"[hashsuite] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[hashsuite] OK: {msg}")


def must_read_contains(path: str) -> bool:
    rb = read(RUNBOOK)
    # Must-read bullets are of the form: - `docs/...`
    return f"`{path}`" in rb


def main() -> None:
    if not DOC.exists():
        fail("missing docs/30-architecture/profile-hash-suite-v0.md")

    if not DOCS_README.exists():
        fail("missing docs/README.md")
    if not RUNBOOK.exists():
        fail("missing docs/00-meta/llm-runbook.md")

    dr = read(DOCS_README)
    if "30-architecture/profile-hash-suite-v0.md" not in dr and "profile-hash-suite-v0.md" not in dr:
        fail("docs/README.md does not reference profile-hash-suite-v0.md")

    if not must_read_contains("docs/30-architecture/profile-hash-suite-v0.md"):
        fail("llm-runbook must-read set does not include docs/30-architecture/profile-hash-suite-v0.md")

    for p, name in [(DECISIONS, "decision-map.md"), (TYPEDID, "typed-id-contract-v0.md"), (CKDERIVE, "conflict-key-derivation-registry.md")]:
        if not p.exists():
            fail(f"missing required file: {name}")

    if "D-HASH" not in read(DECISIONS) or "profile-hash-suite-v0.md" not in read(DECISIONS):
        fail("decision-map.md missing D-HASH entry or missing link to profile-hash-suite-v0.md")

    if "profile-hash-suite-v0.md" not in read(TYPEDID):
        fail("typed-id-contract-v0.md does not reference profile-hash-suite-v0.md")

    if "profile-hash-suite-v0.md" not in read(CKDERIVE):
        fail("conflict-key-derivation-registry.md does not reference profile-hash-suite-v0.md")

    txt = read(DOC)
    if "SHA-256" not in txt:
        fail("profile-hash-suite-v0.md does not mention SHA-256")
    if not re.search(r"\bhashlen\b", txt):
        fail("profile-hash-suite-v0.md does not mention hashlen")
    if "32" not in txt:
        fail("profile-hash-suite-v0.md does not mention 32 (hashlen)")

    # Primary refs are required for this posture.
    for ref in ("REF-FIPS180-4", "REF-RFC6234"):
        if ref not in txt:
            fail(f"profile-hash-suite-v0.md missing required reference token: {ref}")

    ok("profile hash suite posture is present and wired (discoverable + referenced from core seams)")


if __name__ == "__main__":
    main()
