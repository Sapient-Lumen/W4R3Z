#!/usr/bin/env python3
"""Run the repo lint suite in a single Python process.

Why this exists
--------------
`make lint` previously spawned a fresh Python interpreter per drift gate.
That is easy to read but slow in constrained environments (and encourages
people to skip lint locally).

This runner keeps the suite *auditable* while reducing overhead:
- Runs `tools/lint_archive.py` first.
- Then runs every `tools/check_*.py` drift gate in a deterministic order.

Note: drift gates remain tiny, standalone scripts; this runner simply executes
them via `runpy` under a single interpreter.
"""

from __future__ import annotations

import os
import runpy
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def run_script(rel: str) -> None:
    path = ROOT / rel
    if not path.exists():
        raise SystemExit(f"[lint-suite] missing script: {rel}")
    # Execute as if run as __main__. Many drift gates use SystemExit for status.
    try:
        runpy.run_path(str(path), run_name="__main__")
    except SystemExit as e:
        code = e.code
        # SystemExit(None) is treated as success.
        if code is None:
            return
        if isinstance(code, int) and code == 0:
            return
        raise


def main() -> None:
    os.chdir(str(ROOT))

    run_script("tools/lint_archive.py")

    checks = sorted((ROOT / "tools").glob("check_*.py"))
    for p in checks:
        run_script(f"tools/{p.name}")


if __name__ == "__main__":
    main()
