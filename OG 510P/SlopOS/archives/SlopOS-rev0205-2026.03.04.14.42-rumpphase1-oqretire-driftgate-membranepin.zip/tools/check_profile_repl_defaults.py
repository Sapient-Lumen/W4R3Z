#!/usr/bin/env python3
"""Drift gate: pin replication object families + profile defaults.

Why this exists
--------------
Hybrid multicore (ADR-0005) depends on explicit cross-cluster ownership/replication semantics.
CH-REPLCONTRACT v0 uses `object_family` strings; left open, they drift quickly.

This check pins three low-noise invariants:
- `object_family` tokens are registry-closed (replication-object-family-registry.md).
- A–D defaults are complete and closed over that registry (profile-repl-defaults.md).
- RC4 ordered-log semantics are reserved to `object_family=tlog` in v0.

It also enforces discovery wiring so these surfaces remain reviewable.

Exit code:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]

REGISTRY = ROOT / "docs/30-architecture/replication-object-family-registry.md"
DEFAULTS = ROOT / "docs/30-architecture/profile-repl-defaults.md"
DOCS_README = ROOT / "docs/README.md"
SCHEMA = ROOT / "docs/30-architecture/replication-contract-schema-v0.md"
VOCAB = ROOT / "docs/30-architecture/replication-contracts-v0.md"

ALLOWED_RC = {
    "rc0_local",
    "rc1_owner",
    "rc2_epoch_snapshot",
    "rc3_comm_merge",
    "rc4_ordered_log",
}


def fail(msg: str) -> None:
    print(f"[repl-defaults] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[repl-defaults] OK: {msg}")


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def parse_md_table_first_col_tokens(md: str, header_key: str) -> list[str]:
    """Parse a markdown table and return backticked tokens in the first column.

    `header_key` must match the header line (contains the column name), so we
    don't accidentally parse unrelated tables.
    """
    lines = md.splitlines()

    # Find the header row.
    start = None
    for i, ln in enumerate(lines):
        if ln.strip().startswith("|") and header_key in ln:
            start = i
            break
    if start is None:
        fail(f"could not find table header containing '{header_key}'")

    # Expect a divider row next.
    if start + 1 >= len(lines) or "---" not in lines[start + 1]:
        fail(f"table divider row missing after header '{header_key}'")

    toks: list[str] = []
    for ln in lines[start + 2 :]:
        s = ln.strip()
        if not s.startswith("|"):
            break
        cols = [c.strip() for c in s.strip("|").split("|")]
        if not cols or not cols[0]:
            continue
        m = re.match(r"^`([^`]+)`$", cols[0])
        if not m:
            # Header repeats or malformed row.
            continue
        toks.append(m.group(1))

    if not toks:
        fail(f"no rows parsed from table '{header_key}'")
    return toks


def parse_profile_defaults_table(md: str) -> dict[str, list[str]]:
    """Return mapping: object_family -> [A, B, C, D] replication_class tokens."""
    lines = md.splitlines()

    # Locate header row.
    start = None
    for i, ln in enumerate(lines):
        if ln.strip().startswith("|") and "object_family" in ln and "A (workstation)" in ln:
            start = i
            break
    if start is None:
        fail("could not find profile defaults table header")
    if start + 1 >= len(lines) or "---" not in lines[start + 1]:
        fail("profile defaults table divider row missing")

    rows: dict[str, list[str]] = {}

    for ln in lines[start + 2 :]:
        s = ln.strip()
        if not s.startswith("|"):
            break
        cols = [c.strip() for c in s.strip("|").split("|")]
        if len(cols) < 6:
            continue
        fam_cell = cols[0]
        m = re.match(r"^`([^`]+)`$", fam_cell)
        if not m:
            continue
        fam = m.group(1)

        rcs: list[str] = []
        for j in range(1, 5):
            cell = cols[j]
            mrc = re.match(r"^`([^`]+)`$", cell)
            if not mrc:
                fail(f"defaults table cell for {fam} missing backticked rc token in column {j+1}: {cell!r}")
            rc = mrc.group(1)
            if rc not in ALLOWED_RC:
                fail(f"defaults table uses unknown replication_class token: {rc} (family={fam})")
            rcs.append(rc)

        if fam in rows:
            fail(f"duplicate object_family row in defaults table: {fam}")
        rows[fam] = rcs

    if not rows:
        fail("no object_family rows parsed from profile defaults table")
    return rows


def check_discovery_wiring() -> None:
    if not REGISTRY.exists():
        fail("missing replication-object-family-registry.md")
    if not DEFAULTS.exists():
        fail("missing profile-repl-defaults.md")
    if not DOCS_README.exists():
        fail("missing docs/README.md")

    dr = read(DOCS_README)
    if "30-architecture/replication-object-family-registry.md" not in dr:
        fail("docs/README.md does not reference replication-object-family-registry.md")
    if "30-architecture/profile-repl-defaults.md" not in dr:
        fail("docs/README.md does not reference profile-repl-defaults.md")

    # Schema + vocab docs should name the registry (keeps closure discoverable).
    if not SCHEMA.exists():
        fail("missing replication-contract-schema-v0.md")
    sc = read(SCHEMA)
    if "replication-object-family-registry.md" not in sc:
        fail("replication-contract-schema-v0.md does not reference replication-object-family-registry.md")
    if "profile-repl-defaults.md" not in sc:
        fail("replication-contract-schema-v0.md does not reference profile-repl-defaults.md")

    if not VOCAB.exists():
        fail("missing replication-contracts-v0.md")
    vc = read(VOCAB)
    if "RC4 admission posture (v0)" not in vc:
        fail("replication-contracts-v0.md missing 'RC4 admission posture (v0)' section")
    if "replication-object-family-registry.md" not in vc:
        fail("replication-contracts-v0.md does not reference replication-object-family-registry.md")
    if "profile-repl-defaults.md" not in vc:
        fail("replication-contracts-v0.md does not reference profile-repl-defaults.md")

    ok("discovery wiring present (docs index + schema + replication vocab)")


def check_registry_and_defaults() -> None:
    reg_txt = read(REGISTRY)
    # Parse canonical families table.
    fams = parse_md_table_first_col_tokens(reg_txt, "object_family")
    fam_set = set(fams)

    if len(fams) != len(fam_set):
        fail("replication object-family registry contains duplicate tokens")

    defaults_txt = read(DEFAULTS)
    rows = parse_profile_defaults_table(defaults_txt)

    row_set = set(rows.keys())

    missing = sorted(fam_set - row_set)
    extra = sorted(row_set - fam_set)
    if missing:
        fail(f"profile-repl-defaults missing {len(missing)} object_family row(s): {', '.join(missing)}")
    if extra:
        fail(f"profile-repl-defaults contains unknown object_family row(s): {', '.join(extra)}")

    # RC4 reserved to tlog.
    for fam, rcs in rows.items():
        for rc in rcs:
            if rc == "rc4_ordered_log" and fam != "tlog":
                fail(f"RC4 is reserved to object_family=tlog in v0, but found rc4_ordered_log under {fam}")

    # Ensure tlog row exists and includes at least one non-rc0 value in defaults.
    if "tlog" not in rows:
        fail("defaults table missing required tlog row")

    ok(f"registry/defaults closed and coherent ({len(fam_set)} object families)")


def main() -> None:
    check_discovery_wiring()
    check_registry_and_defaults()
    print("[repl-defaults] All checks passed.")


if __name__ == "__main__":
    main()
