#!/usr/bin/env python3
"""CI drift gate: keep CH-REQCTX temporal-capability reference posture discoverable + wired.

Rationale
---------
CH-REQCTX v0/v1 carries `tcap_desc_digests` as an *untyped* digest list.
That is deliberate early-surface minimalism, but it can drift into ambiguous
"resolve anything" semantics unless we pin a consumer-typed contract.

This guardrail is intentionally narrow:
- Requires the posture doc to exist and be linked from key discovery surfaces.
- Requires CH-REQCTX schema docs to reference the posture.
- Requires the evidence index + tools README to register this drift gate.

Fail-closed: if any anchor is missing, lint fails.
"""

from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def fail(msg: str) -> int:
    print(f"[reqctx-tcapref] FAIL: {msg}")
    return 1


def ok(msg: str) -> None:
    print(f"[reqctx-tcapref] OK: {msg}")


def main() -> int:
    posture = ROOT / "docs/30-architecture/reqctx-tcap-ref-posture-v0.md"
    docs_readme = ROOT / "docs/README.md"
    reqctx0 = ROOT / "docs/30-architecture/request-context-schema-v0.md"
    reqctx1 = ROOT / "docs/30-architecture/request-context-schema-v1.md"
    evid = ROOT / "docs/00-meta/evidence-index.md"
    tools_readme = ROOT / "tools/README.md"

    for p in (posture, docs_readme, reqctx0, reqctx1, evid, tools_readme):
        if not p.exists():
            return fail(f"missing required file: {p.relative_to(ROOT)}")

    # 1) Posture doc includes the key contract phrases.
    t = read(posture)
    must = [
        "tcap_desc_digests",
        "untyped",
        "CH-TCAP v0",
        "type-strict",
        "non-ambient",
        "locator",
        "artifact-resolution-posture-v0.md",
    ]
    missing = [m for m in must if m not in t]
    if missing:
        return fail(f"posture doc missing anchor(s): {', '.join(missing)}")
    ok("posture doc contains required anchors")

    # 2) Discoverability from docs/README.md.
    if "reqctx-tcap-ref-posture-v0.md" not in read(docs_readme):
        return fail("docs/README.md missing link to reqctx-tcap-ref-posture-v0.md")
    ok("docs/README.md links the posture doc")

    # 3) CH-REQCTX schema docs reference the posture.
    for p in (reqctx0, reqctx1):
        txt = read(p)
        if "reqctx-tcap-ref-posture-v0.md" not in txt:
            return fail(f"{p.name} missing reference to posture doc")
    ok("CH-REQCTX schema docs wire the posture")

    # 4) Evidence index includes an entry for this drift gate.
    ev = read(evid)
    if "EVID-2026-208" not in ev or "tools/check_reqctx_tcap_ref_posture.py" not in ev:
        return fail("evidence-index.md missing EVID-2026-208 entry pointing at this tool")
    ok("Evidence index includes EVID-2026-208")

    # 5) tools/README mentions the drift gate (check_guardrail_wiring expects it).
    if "check_reqctx_tcap_ref_posture.py" not in read(tools_readme):
        return fail("tools/README.md missing check_reqctx_tcap_ref_posture.py entry")
    ok("tools/README mentions the drift gate")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
