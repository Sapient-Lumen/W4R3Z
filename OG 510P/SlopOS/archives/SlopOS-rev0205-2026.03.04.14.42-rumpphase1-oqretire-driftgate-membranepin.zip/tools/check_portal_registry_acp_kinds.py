#!/usr/bin/env python3
"""CI drift gate: keep portal-family registry wired to ACP kinds.

Why this exists
--------------
We treat portal families (`portal.*`) as a closed workflow authority surface
(`docs/30-architecture/portal-family-registry.md`). The ACP kind registry already
pins per-kind conflict keys + commutativity metadata, but without explicit wiring
it's easy for the portal registry to drift into a purely conceptual taxonomy.

This check makes the automation surface discoverable and reviewable:
- Each portal family row MUST either:
  - list the corresponding `portal.<family>.*` CH-ACP kind token(s), OR
  - explicitly say `none` (manual-only v0; no ACP kind yet).
- Any kind token listed in the portal registry must exist in
  `docs/70-llm-control/acp-action-kind-registry.md`.
- Every ACP kind whose name starts with `portal.` MUST appear in the matching
  portal-family row (prevents “automation exists but portal registry says none”).

Exit code:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

import re
from pathlib import Path

RE_BT = re.compile(r"`([^`]+)`")


def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def fail(msg: str) -> None:
    print(f"[portalacp] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[portalacp] OK: {msg}")


def portal_root_from_family_cell(cell: str) -> str | None:
    """Map a portal registry family cell like `portal.net.*` to `portal.net`."""
    cell = cell.strip()
    toks = RE_BT.findall(cell)
    if not toks:
        return None
    tok = toks[0].strip().rstrip(".,;:")
    if not tok.startswith("portal."):
        return None
    parts = tok.split(".")
    if len(parts) < 2:
        return None
    fam = parts[1]
    if fam == "*":
        return None
    return f"portal.{fam}"


def portal_root_from_kind(kind: str) -> str | None:
    if not kind.startswith("portal."):
        return None
    parts = kind.split(".")
    if len(parts) < 2:
        return None
    fam = parts[1]
    return f"portal.{fam}"


def load_acp_kinds() -> set[str]:
    root = repo_root()
    p = root / "docs/70-llm-control/acp-action-kind-registry.md"
    if not p.exists():
        fail("missing docs/70-llm-control/acp-action-kind-registry.md")

    kinds: set[str] = set()
    for ln in read(p).splitlines():
        s = ln.strip()
        if not s.startswith("|"):
            continue
        # table row: | `kind` | ...
        m = re.match(r"^\|\s*`([^`]+)`\s*\|", s)
        if not m:
            continue
        kinds.add(m.group(1).strip())

    if not kinds:
        fail("ACP kind registry yielded no kinds")
    return kinds


def parse_portal_registry() -> tuple[dict[str, set[str]], set[str]]:
    """Return (family->kinds, manual_only_families)."""
    root = repo_root()
    p = root / "docs/30-architecture/portal-family-registry.md"
    if not p.exists():
        fail("missing docs/30-architecture/portal-family-registry.md")
    lines = read(p).splitlines()

    # Find the portal families table header.
    hdr_i = None
    for i, ln in enumerate(lines):
        if ln.strip().startswith("| Portal family |") and "ACP kind" in ln:
            hdr_i = i
            break
    if hdr_i is None:
        fail("could not find portal families table header with an ACP kind(s) column")

    header = [c.strip() for c in lines[hdr_i].strip().strip("|").split("|")]
    try:
        idx_family = header.index("Portal family")
        idx_acp = header.index("ACP kind(s) (automation surface)")
    except ValueError as e:
        fail(f"portal families table missing required column: {e}")

    family_to_kinds: dict[str, set[str]] = {}
    manual_only: set[str] = set()

    # Parse rows until we hit a non-table line or a new section.
    for ln in lines[hdr_i + 2 :]:
        s = ln.strip()
        if not s.startswith("|"):
            break
        if s.startswith("|---"):
            continue
        if s.startswith("| Portal family"):
            continue
        cells = [c.strip() for c in s.strip().strip("|").split("|")]
        if len(cells) <= max(idx_family, idx_acp):
            continue

        fam_cell = cells[idx_family]
        acp_cell = cells[idx_acp]
        fam_root = portal_root_from_family_cell(fam_cell)
        if not fam_root:
            continue

        kind_tokens = set(RE_BT.findall(acp_cell))
        has_none = "none" in acp_cell.lower()

        if not kind_tokens and not has_none:
            fail(
                f"portal-family row for {fam_root} must list ACP kind token(s) or say `none` (cell={acp_cell!r})"
            )
        if kind_tokens and has_none:
            fail(
                f"portal-family row for {fam_root} ACP kind(s) cell mixes kind tokens with 'none' (cell={acp_cell!r})"
            )

        if has_none:
            manual_only.add(fam_root)
            family_to_kinds.setdefault(fam_root, set())
            continue

        # Ensure only portal.* kinds appear here.
        for k in kind_tokens:
            if not k.startswith("portal."):
                fail(
                    f"portal-family row for {fam_root} lists non-portal ACP kind {k!r} (only portal.* kinds belong here)"
                )
            # Ensure the kind matches the family.
            if portal_root_from_kind(k) != fam_root:
                fail(
                    f"portal-family row for {fam_root} lists ACP kind {k!r} which belongs to {portal_root_from_kind(k)!r}"
                )

        family_to_kinds.setdefault(fam_root, set()).update(kind_tokens)

    if not family_to_kinds:
        fail("portal-family-registry table parse yielded no portal families")

    return family_to_kinds, manual_only


def main() -> None:
    acp_kinds = load_acp_kinds()
    fam_to_kinds, manual_only = parse_portal_registry()

    # Check that all kinds mentioned in the portal registry exist.
    unknown = sorted(
        [k for ks in fam_to_kinds.values() for k in ks if k not in acp_kinds]
    )
    if unknown:
        fail(
            "portal-family-registry lists ACP kind token(s) not present in acp-action-kind-registry.md: "
            + ", ".join(unknown)
        )

    # Check that every portal.* ACP kind is listed in the matching family row.
    portal_kinds = sorted([k for k in acp_kinds if k.startswith("portal.")])
    missing: list[str] = []
    for k in portal_kinds:
        fam = portal_root_from_kind(k)
        if fam not in fam_to_kinds:
            missing.append(f"{k} (missing portal family row for {fam})")
            continue
        if fam in manual_only:
            missing.append(f"{k} (portal family {fam} marked manual-only via `none`)")
            continue
        if k not in fam_to_kinds.get(fam, set()):
            missing.append(f"{k} (not listed under portal family {fam})")

    if missing:
        fail(
            "ACP portal kinds must be listed in the matching portal family row (keeps commutativity metadata discoverable):\n- "
            + "\n- ".join(missing[:50])
            + ("\n..." if len(missing) > 50 else "")
        )

    ok(
        f"portal registry is wired to ACP kinds ({len(fam_to_kinds)} portal families; {len(portal_kinds)} portal ACP kind(s))"
    )


if __name__ == "__main__":
    main()
