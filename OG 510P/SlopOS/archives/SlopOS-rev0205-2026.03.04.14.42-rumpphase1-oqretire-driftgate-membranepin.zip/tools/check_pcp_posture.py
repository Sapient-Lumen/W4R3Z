#!/usr/bin/env python3
"""CI drift gate: pin D-PCP v0 posture (release-only PCP) and keep it discoverable.

Why this exists
--------------
Proof-carrying provenance (D-PCP) is an expensive design axis that tends to
sprawl into "prove everything at boot" ideas.

This gate pins a narrow, implementable v0 stance:
- PCP is a *release artifact* (CI / release tooling).
- Boot-time verification stays small: IF-BOOT verifies binding when enabled,
  but does not validate bulky proofs/models.

It also enforces discovery wiring so the posture doesn't drift into an orphan doc.

Exit code:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

PCP_DOC = ROOT / "docs/60-engineering/pcp-posture-v0.md"
DOCS_README = ROOT / "docs/README.md"
DECISION_MAP = ROOT / "docs/30-architecture/decision-map.md"
SUPPLY_CHAIN = ROOT / "docs/60-engineering/supply-chain-repro.md"


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def fail(msg: str) -> None:
    print(f"[pcp-posture] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[pcp-posture] OK: {msg}")


def main() -> None:
    if not PCP_DOC.exists():
        fail("missing docs/60-engineering/pcp-posture-v0.md")
    if not DOCS_README.exists():
        fail("missing docs/README.md")
    if not DECISION_MAP.exists():
        fail("missing docs/30-architecture/decision-map.md")
    if not SUPPLY_CHAIN.exists():
        fail("missing docs/60-engineering/supply-chain-repro.md")

    pcp = read(PCP_DOC)

    # Anchor: require the exact v0 posture phrase.
    if "v0 posture" not in pcp or "release-only PCP" not in pcp:
        fail("pcp posture doc must contain the v0 posture anchor 'release-only PCP'")

    # Discovery wiring: docs index.
    dr = read(DOCS_README)
    if "60-engineering/pcp-posture-v0.md" not in dr and "pcp-posture-v0.md" not in dr:
        fail("docs/README.md does not reference docs/60-engineering/pcp-posture-v0.md")

    # Decision-map wiring.
    dm = read(DECISION_MAP)
    if "D-PCP" not in dm:
        fail("decision-map.md missing D-PCP decision surface")
    if "pcp-posture-v0.md" not in dm:
        fail("decision-map.md D-PCP section must reference pcp-posture-v0.md")
    if "release-only PCP" not in dm:
        fail("decision-map.md D-PCP section must mention 'release-only PCP'")

    # Engineering wiring.
    sc = read(SUPPLY_CHAIN)
    if "pcp-posture-v0.md" not in sc:
        fail("supply-chain-repro.md must reference pcp-posture-v0.md (avoid posture drift into prose)")

    ok("D-PCP v0 posture is pinned and wired (doc + decision map + engineering + docs index)")


if __name__ == "__main__":
    main()
