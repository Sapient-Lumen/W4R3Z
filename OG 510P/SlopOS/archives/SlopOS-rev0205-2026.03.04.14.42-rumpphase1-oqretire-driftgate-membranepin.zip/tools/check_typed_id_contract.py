#!/usr/bin/env python3
"""CI guardrail: keep typed-id canonicalization discoverable and wired.

Why this exists
--------------
Several pinned action and commutativity seams refer to typed ids (as_id, view_id, …) that feed
conflict-key derivation. If their encoding is left implicit, LLM/human edits tend to reintroduce
"profile-defined" ambiguity that breaks D-COMMUTE evidence and ordering-scope stability.

This check is intentionally tiny and conservative:
- Requires the typed-id contract doc to exist.
- Requires docs/README.md to link it (discovery surface).
- Requires conflict-key-derivation-registry.md to reference it (where ck_id inputs matter).
- Requires D-TYPEDID to exist in the decision map (prevents orphan decision tokens).

Exit code:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Problem:
    path: str
    detail: str


ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / "docs"
DOCS_README = DOCS / "README.md"
TYPED_ID_DOC = DOCS / "30-architecture/typed-id-contract-v0.md"
CK_DERIVE = DOCS / "30-architecture/conflict-key-derivation-registry.md"
DECISION_MAP = DOCS / "30-architecture/decision-map.md"


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def main() -> int:
    problems: list[Problem] = []

    for req in [DOCS_README, TYPED_ID_DOC, CK_DERIVE, DECISION_MAP]:
        if not req.exists():
            problems.append(Problem(str(req.relative_to(ROOT)), "missing required file"))

    if problems:
        for pr in problems:
            print(f"- {pr.path}: {pr.detail}")
        return 1

    # Discovery wiring
    if "typed-id-contract-v0.md" not in read(DOCS_README):
        problems.append(Problem(str(DOCS_README.relative_to(ROOT)), "docs/README.md must link typed-id-contract-v0.md"))

    if "typed-id-contract-v0.md" not in read(CK_DERIVE):
        problems.append(Problem(str(CK_DERIVE.relative_to(ROOT)), "conflict-key-derivation-registry.md must reference typed-id-contract-v0.md"))

    # Decision token exists
    if "## D-TYPEDID" not in read(DECISION_MAP):
        problems.append(Problem(str(DECISION_MAP.relative_to(ROOT)), "decision-map.md must include a D-TYPEDID entry"))

    # Contract doc mentions the decision token (prevents doc drift into prose-only rationale)
    if "D-TYPEDID" not in read(TYPED_ID_DOC):
        problems.append(Problem(str(TYPED_ID_DOC.relative_to(ROOT)), "typed-id-contract-v0.md must mention D-TYPEDID"))

    if problems:
        print("[typed-id] FAIL: typed-id contract wiring drift detected:\n")
        for pr in problems:
            print(f"- {pr.path}: {pr.detail}")
        return 1

    print("[typed-id] OK: typed-id contract is present and wired (docs index + derivation registry + decision map)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
