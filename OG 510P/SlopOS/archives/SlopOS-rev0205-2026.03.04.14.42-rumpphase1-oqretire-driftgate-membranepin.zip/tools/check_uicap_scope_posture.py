#!/usr/bin/env python3
"""CI drift gate: pin D-UICAP v0 scope posture and keep it discoverable.

Why this exists
--------------
D-UICAP is an expensive decision axis that can sprawl into "pick a UI stack" debates
or drift into ambiguous prose.

This gate pins a narrow v0 scope posture:
- UI boundary is treated as a capability seam when enabled.
- Focus-gated input + surface isolation are required properties.
- High-risk UI authority stays portal-mediated (and ideally leased).
- Interactive profiles that claim spoof resistance must support a secure-attention
  entry (SAS) into a visually distinct secure UI mode.

It also enforces discovery wiring so the posture doesn't become an orphan doc.

Exit code:
- 0 on success
- 1 on failure
"""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

UICAP_DOC = ROOT / "docs/30-architecture/uicap-scope-posture-v0.md"
DOCS_README = ROOT / "docs/README.md"
DECISION_MAP = ROOT / "docs/30-architecture/decision-map.md"
TRAJECTORY = ROOT / "docs/00-meta/trajectory-map.md"


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def fail(msg: str) -> None:
    print(f"[uicap-scope] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[uicap-scope] OK: {msg}")


def main() -> None:
    for p in [UICAP_DOC, DOCS_README, DECISION_MAP, TRAJECTORY]:
        if not p.exists():
            fail(f"missing required file: {p.relative_to(ROOT)}")

    doc = read(UICAP_DOC)

    # Minimal anchors so the posture can't silently drift.
    for needle in [
        "v0 posture",
        "Scope by product shape",
        "SAS",
        "I-UICAP-1",
        "I-UICAP-2",
        "PO-SAS-DELIVER",
    ]:
        if needle not in doc:
            fail(f"uicap scope posture doc missing required anchor/content: {needle!r}")

    # Discovery wiring: docs index.
    dr = read(DOCS_README)
    if "uicap-scope-posture-v0.md" not in dr:
        fail("docs/README.md does not reference uicap-scope-posture-v0.md")

    # Decision-map wiring.
    dm = read(DECISION_MAP)
    if "## D-UICAP" not in dm or "D-UICAP" not in dm:
        fail("decision-map.md missing D-UICAP decision surface")
    if "uicap-scope-posture-v0.md" not in dm:
        fail("decision-map.md D-UICAP section must reference uicap-scope-posture-v0.md")

    # Trajectory map: OQ-0004 should not remain open once pinned.
    tr = read(TRAJECTORY)
    if "OQ-0004" in tr:
        fail("trajectory-map.md still contains OQ-0004; v0 scope should be pinned (remove or re-scope via a new OQ id)")

    ok("D-UICAP v0 scope posture is pinned and wired (doc + decision map + docs index; OQ-0004 retired)")


if __name__ == "__main__":
    main()
