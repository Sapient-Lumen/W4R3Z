#!/usr/bin/env python3
"""CI drift gate: keep CH-SPROJ (state projection receipt) wired and discoverable.

Why this exists
--------------
D-COMMUTE swap-order tests require a stable, bounded notion of "final externally visible state".
If this is left as prose, it drifts:
- different docs mention different "state digest" ideas,
- commutativity tests become unimplementable,
- planners become unsafe (reordering based on stale assumptions).

This gate pins the v0 posture:
- CH-SPROJ v0 exists and is registered (schema registry closure),
- ACP commutativity predicate registry uses `digest(CH-SPROJ v0)` as the normalized state hook,
- ACP kind registry mentions CH-SPROJ as an expected receipt ref for commutativity-tested kinds,
- discovery surfaces (docs index + must-read set) include the CH-SPROJ schema doc.

Fail closed.
"""

from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def fail(msg: str) -> None:
    print(f"[sproj] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[sproj] OK: {msg}")


def must_contain(path: Path, needle: str, label: str) -> None:
    if not path.exists():
        fail(f"missing {label}: {path.relative_to(ROOT)}")
    txt = path.read_text(encoding="utf-8")
    if needle not in txt:
        fail(f"{label} missing required text: {needle!r} ({path.relative_to(ROOT)})")


def main() -> None:
    schema_doc = ROOT / "docs/30-architecture/state-projection-schema-v0.md"
    if not schema_doc.exists():
        fail("missing CH-SPROJ schema doc: docs/30-architecture/state-projection-schema-v0.md")

    schema_reg = ROOT / "docs/30-architecture/schema-registry.md"
    must_contain(schema_reg, "CH-SPROJ v0", "schema registry")

    pred_reg = ROOT / "docs/70-llm-control/acp-commutativity-predicate-registry.md"
    must_contain(pred_reg, "digest(CH-SPROJ v0)", "ACP commutativity predicate registry")
    must_contain(pred_reg, "state-projection-schema-v0.md", "ACP commutativity predicate registry")

    kind_reg = ROOT / "docs/70-llm-control/acp-action-kind-registry.md"
    must_contain(kind_reg, "CH-SPROJ v0", "ACP kind registry")

    docs_index = ROOT / "docs/README.md"
    must_contain(docs_index, "30-architecture/state-projection-schema-v0.md", "docs index")

    runbook = ROOT / "docs/00-meta/llm-runbook.md"
    must_contain(runbook, "docs/30-architecture/state-projection-schema-v0.md", "LLM runbook must-read set")

    ok("CH-SPROJ wiring is present (registered + indexed + referenced from ACP commutativity surfaces)")


if __name__ == "__main__":
    main()
