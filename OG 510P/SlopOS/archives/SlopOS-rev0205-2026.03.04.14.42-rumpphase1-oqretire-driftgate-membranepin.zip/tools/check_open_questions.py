#!/usr/bin/env python3
"""CI drift gate: open questions must have stable OQ ids and attach to decision surfaces.

Why this exists
--------------
The trajectory map is a primary "amnesia resistor". Open questions are the highest-entropy
area, and they tend to drift into prose.

This guardrail enforces:
- Every open question bullet has a stable OQ-#### id.
- OQ ids are unique and monotonically increasing in the doc (keeps diffs reviewable).
- Each open question text explicitly attaches to at least one existing surface token
  (D-/CH-/I-/PO-/ADR-/RFC-/IF-/AC-/C-/EVID-/REF-).

We intentionally do not require a dedicated registry yet; this is a light-touch hygiene gate.
"""

from __future__ import annotations

import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
TRAJ = ROOT / "docs/00-meta/trajectory-map.md"

RE_OQ = re.compile(r"^\-\s+\*\*(OQ\-\d{4})\s+.+\*\*:\s+.+$")
RE_ATTACH = re.compile(r"\b(D\-|CH\-|I\-|PO\-|ADR\-|RFC\-|IF\-|AC\-|C\-|EVID\-|REF\-)\b")


def fail(msg: str) -> None:
    print(f"[openq] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[openq] OK: {msg}")


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def extract_open_question_lines(md: str) -> list[str]:
    lines = md.splitlines()
    in_section = False
    out: list[str] = []
    for ln in lines:
        if ln.strip() == "## Open questions (tracked as decision surfaces)":
            in_section = True
            continue
        if in_section and ln.startswith("## "):
            break
        if not in_section:
            continue
        s = ln.strip()
        if s.startswith("- "):
            out.append(s)
    return out


def main() -> None:
    if not TRAJ.exists():
        fail("missing docs/00-meta/trajectory-map.md")

    oq_lines = extract_open_question_lines(read(TRAJ))
    if not oq_lines:
        fail("no open questions found under trajectory-map heading")

    ids: list[str] = []
    for ln in oq_lines:
        m = RE_OQ.match(ln)
        if not m:
            fail(
                "open question bullet must look like '- **OQ-0001 Title**: ...' (got: "
                + ln
                + ")"
            )
        oq_id = m.group(1)
        ids.append(oq_id)

        if not RE_ATTACH.search(ln):
            fail(f"{oq_id} does not attach to any surface token (D-/CH-/I-/PO-/ADR-/RFC-/...)")

    # Unique and monotonic (diff-friendly ordering).
    if len(set(ids)) != len(ids):
        dupes = sorted({x for x in ids if ids.count(x) > 1})
        fail("duplicate OQ id(s): " + ", ".join(dupes))

    nums = [int(x.split("-")[1]) for x in ids]
    if nums != sorted(nums):
        fail("OQ ids must be listed in increasing order")

    ok(f"open questions are OQ-id'd and surface-attached ({len(ids)} item(s))")


if __name__ == "__main__":
    main()
