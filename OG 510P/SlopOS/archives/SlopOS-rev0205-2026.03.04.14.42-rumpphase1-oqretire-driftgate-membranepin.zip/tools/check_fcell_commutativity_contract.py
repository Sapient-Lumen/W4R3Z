#!/usr/bin/env python3
"""CI drift gate: sealed compat adapter commutativity posture must stay pinned and discoverable.

Why this exists
--------------
Sealed compatibility (D-FCELL) is a high-drift zone: it is tempting to reintroduce
ambient authority and/or implicit serialization when bridging POSIX expectations.

This guardrail keeps the Hybrid + D-COMMUTE posture mechanical:
- A dedicated v0 posture doc exists and is discoverable.
- CH-FADAPT schemas retain explicit observability hooks (`conflict_key_digest`, `order_digest`).
- The `cell.adapter` conflict-key family remains registered.
- Evidence index includes a stable anchor for this posture.

We keep this check conservative and text-based (no heavy parsing).
"""

from __future__ import annotations

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

DOC = ROOT / "docs/30-architecture/fcell-commutativity-contract-v0.md"
DOCS_README = ROOT / "docs/README.md"
DECISION_MAP = ROOT / "docs/30-architecture/decision-map.md"
FADAPT_V0 = ROOT / "docs/30-architecture/fcell-adapter-receipt-schema-v0.md"
FADAPT_V1 = ROOT / "docs/30-architecture/fcell-adapter-receipt-schema-v1.md"
FCELL = ROOT / "docs/30-architecture/foreign-cell-manifest-schema-v0.md"
TYPED_ID = ROOT / "docs/30-architecture/typed-id-contract-v0.md"
CK_DERIV = ROOT / "docs/30-architecture/conflict-key-derivation-registry.md"
CK_FAM = ROOT / "docs/30-architecture/conflict-key-family-registry.md"
EVID = ROOT / "docs/00-meta/evidence-index.md"


def fail(msg: str) -> None:
    print(f"[fcell-commute] FAIL: {msg}")
    raise SystemExit(1)


def ok(msg: str) -> None:
    print(f"[fcell-commute] OK: {msg}")


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def must_contain(p: Path, needle: str, label: str) -> None:
    if needle not in read(p):
        fail(f"{label}: missing required text '{needle}'")


def main() -> None:
    if not DOC.exists():
        fail("missing docs/30-architecture/fcell-commutativity-contract-v0.md")

    # Minimal posture anchors (keeps doc from collapsing into vague prose).
    txt = read(DOC)
    for needle in [
        "Conflict key binding (cell.adapter)",
        "Commutativity stance (receipt emission)",
        "order_digest",
        "conflict_key_digest",
        "CH-ORDERTOK",
    ]:
        if needle not in txt:
            fail(f"posture doc missing anchor: {needle}")

    must_contain(DOCS_README, "30-architecture/fcell-commutativity-contract-v0.md", "docs/README.md")
    must_contain(DECISION_MAP, "fcell-commutativity-contract-v0.md", "decision-map.md")

    # CH-FADAPT schemas keep the observability hooks and reference the posture.
    for p in [FADAPT_V0, FADAPT_V1]:
        if not p.exists():
            fail(f"missing {p}")
        must_contain(p, "cell_id: bstr", p.name)
        must_contain(p, "conflict_key_digest", p.name)
        must_contain(p, "order_digest", p.name)
        must_contain(p, "fcell-commutativity-contract-v0.md", p.name)

    # CH-FCELL + typed-id contract pin cell_id encoding (keeps adapter key stability mechanical).
    must_contain(FCELL, "cell_id:", "foreign-cell-manifest-schema-v0.md")
    must_contain(FCELL, "typed-id-contract-v0.md", "foreign-cell-manifest-schema-v0.md")
    must_contain(TYPED_ID, "`cell_id`", "typed-id-contract-v0.md")

    # Conflict key family must remain registered.
    must_contain(CK_DERIV, "`cell.adapter`", "conflict-key-derivation-registry.md")
    must_contain(CK_FAM, "`cell.adapter`", "conflict-key-family-registry.md")

    # Evidence anchor must exist.
    must_contain(EVID, "EVID-2026-201", "evidence-index.md")

    ok("fcell adapter commutativity posture is pinned and wired")


if __name__ == "__main__":
    main()
