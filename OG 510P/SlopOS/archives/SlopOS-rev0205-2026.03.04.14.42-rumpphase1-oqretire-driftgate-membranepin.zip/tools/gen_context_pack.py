#!/usr/bin/env python3
"""Generate a compact context pack for future archive editing runs.

Design goals:
- Fast, dependency-free, deterministic output.
- Points at canonical docs and current constraints.
- Summarizes *open questions* and recent changes without copying large text.

Output:
- Markdown written to --out (default: out/context_pack.md).
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path


def repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def read_text(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def parse_top_changelog(changelog: str) -> tuple[str, str, list[str]]:
    """Return (revision, date, bullet_lines) from the top changelog entry.

    We preserve up to one level of sub-bullets so the context pack can carry
    meaningful detail without forcing readers to open the changelog.

    Returned bullet lines already include their `-` marker (and indentation).
    """
    lines = changelog.splitlines()
    rev = "(unknown)"
    date = "(unknown)"

    # Find first header like: ## Revised95 (2026-02-27)
    for i, line in enumerate(lines):
        m = re.match(r"^##\s+(Revised\d+)\s+\((\d{4}-\d{2}-\d{2})\)", line.strip())
        if not m:
            continue
        rev, date = m.group(1), m.group(2)
        start = i + 1
        break
    else:
        return rev, date, []

    bullets: list[str] = []
    max_lines = 12

    for j in range(start, len(lines)):
        ln = lines[j]
        if ln.startswith("## "):
            break

        # Top-level bullets.
        m0 = re.match(r"^\-\s+(.+?)\s*$", ln)
        if m0:
            bullets.append(f"- {m0.group(1).strip()}")
        else:
            # One level of sub-bullets (indented).
            m1 = re.match(r"^\s{2,}\-\s+(.+?)\s*$", ln)
            if m1:
                bullets.append(f"  - {m1.group(1).strip()}")

        if len(bullets) >= max_lines:
            break

    return rev, date, bullets


def parse_must_read(runbook: str) -> list[str]:
    """Extract backtick-quoted file paths from the Must-read set section."""
    lines = runbook.splitlines()
    in_section = False
    out: list[str] = []

    for line in lines:
        if line.strip() == "## Must-read set (refresh before making changes)":
            in_section = True
            continue
        if in_section and line.startswith("## "):
            break
        if not in_section:
            continue
        # Match bullets like: - `docs/...`
        m = re.match(r"^\-\s+`([^`]+)`\s*$", line.strip())
        if m:
            out.append(m.group(1))

    # De-dup while preserving order.
    seen: set[str] = set()
    uniq: list[str] = []
    for p in out:
        if p in seen:
            continue
        seen.add(p)
        uniq.append(p)
    return uniq


def parse_non_negotiables(runbook: str) -> list[str]:
    """Extract the numbered non-negotiables from the runbook.

    Preserves simple sub-bullets by folding them into the parent item.
    """
    lines = runbook.splitlines()
    in_section = False

    items: list[tuple[str, list[str]]] = []
    cur_head: str | None = None
    cur_subs: list[str] = []

    for line in lines:
        if line.strip() == "## Non-negotiables (must not degrade)":
            in_section = True
            continue
        if in_section and line.startswith("## "):
            break
        if not in_section:
            continue

        m = re.match(r"^\s*\d+\)\s+(.+?)\s*$", line)
        if m:
            if cur_head is not None:
                items.append((cur_head, cur_subs))
            cur_head = m.group(1).strip()
            cur_subs = []
            continue

        # Capture indented sub-bullets under the current numbered item.
        if cur_head is not None:
            sb = re.match(r"^\s{2,}-\s+(.+?)\s*$", line)
            if sb:
                cur_subs.append(sb.group(1).strip())

    if cur_head is not None:
        items.append((cur_head, cur_subs))

    out: list[str] = []
    for head, subs in items:
        if subs:
            # Keep it compact; context pack is a prompt surface.
            folded = "; ".join(subs[:3])
            if len(subs) > 3:
                folded += "; …"
            out.append(f"{head} ({folded})")
        else:
            out.append(head)
    return out


def parse_open_questions(trajectory: str) -> list[str]:
    """Extract the bullet list under '## Open questions'."""
    lines = trajectory.splitlines()
    in_section = False
    out: list[str] = []

    re_oq = re.compile(r"^\-\s+\*\*(OQ\-\d{4})\s+(.+?)\*\*:\s+(.+)$")

    for line in lines:
        if line.strip() == "## Open questions (tracked as decision surfaces)":
            in_section = True
            continue
        if in_section and line.startswith("## "):
            break
        if not in_section:
            continue
        if re.match(r"^\-\s+", line.strip()):
            s = line.strip()
            m = re_oq.match(s)
            if m:
                oq_id, title, rest = m.group(1), m.group(2).strip(), m.group(3).strip()
                out.append(f"{oq_id} — {title}: {rest}")
            else:
                out.append(s[2:].strip())

    return out


def _slice_under_heading(md: str, heading: str) -> list[str]:
    """Return lines under an exact heading until the next markdown heading.

    We treat any heading level (`#`, `##`, `###`, ...) as a stop marker.
    """
    lines = md.splitlines()
    out: list[str] = []
    in_section = False
    for line in lines:
        if line.strip() == heading:
            in_section = True
            continue
        if in_section and line.startswith("#"):
            break
        if not in_section:
            continue
        out.append(line.rstrip())
    return out


def parse_profile_matrix(trajectory: str) -> tuple[list[str], list[tuple[str, str, list[str]]]]:
    """Extract (shared_bullets, profiles[(name, goal, bullets)]) from trajectory map.

    This is intentionally conservative and formatting-sensitive: trajectory-map.md is a
    canonical drift-control doc, so we prefer to fail gracefully (empty output) rather
    than guess.
    """
    shared_lines = _slice_under_heading(trajectory, "### Shared substrate (always)")
    shared_bullets = [ln.strip()[2:].strip() for ln in shared_lines if ln.strip().startswith("- ")]

    profiles: list[tuple[str, str, list[str]]] = []
    for h in [
        "### Workstation profile",
        "### Cloud substrate profile",
        "### Embedded / separation profile",
        "### Agent/automation profile",
    ]:
        sect = _slice_under_heading(trajectory, h)
        goal = ""
        bullets: list[str] = []
        for ln in sect:
            s = ln.strip()
            if s.startswith("Goal:") and not goal:
                goal = s.replace("Goal:", "", 1).strip()
                continue
            if s.startswith("- "):
                bullets.append(s[2:].strip())
        if sect:
            profiles.append((h.replace("### ", ""), goal, bullets))

    return shared_bullets, profiles


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="out/context_pack.md", help="output markdown path")
    args = ap.parse_args()

    root = repo_root()
    out_path = (root / args.out).resolve()
    out_path.parent.mkdir(parents=True, exist_ok=True)

    changelog = read_text(root / "CHANGELOG.md")
    rev, date, bullets = parse_top_changelog(changelog)

    runbook_path = root / "docs/00-meta/llm-runbook.md"
    must_read: list[str] = []
    non_negs: list[str] = []
    if runbook_path.exists():
        rb_txt = read_text(runbook_path)
        must_read = parse_must_read(rb_txt)
        non_negs = parse_non_negotiables(rb_txt)

    traj_path = root / "docs/00-meta/trajectory-map.md"
    open_qs: list[str] = []
    shared: list[str] = []
    profiles: list[tuple[str, str, list[str]]] = []
    if traj_path.exists():
        traj_txt = read_text(traj_path)
        open_qs = parse_open_questions(traj_txt)
        shared, profiles = parse_profile_matrix(traj_txt)

    lines: list[str] = []
    lines.append(f"# Context pack — {rev} ({date})")
    lines.append("")
    lines.append("This is a compact, copy/paste-friendly summary for continuing work on the living archive.")
    lines.append("")

    lines.append("## Current orientation")
    lines.append(f"- Latest revision: **{rev}** ({date})")
    lines.append("- Mile-high map: `docs/00-meta/trajectory-map.md`")
    lines.append("- Charter (north star): `docs/00-meta/charter.md`")
    lines.append("")

    if bullets:
        lines.append("## New in latest revision")
        for b in bullets:
            lines.append(b)
        lines.append("")

    if non_negs:
        lines.append("## Non-negotiables (must not degrade)")
        for x in non_negs:
            lines.append(f"- {x}")
        lines.append("")

    if must_read:
        lines.append("## Must-read set (refresh before edits)")
        for p in must_read:
            lines.append(f"- `{p}`")
        lines.append("")

    if shared or profiles:
        lines.append("## Profile matrix (no forks; profiles/layers only)")
        if shared:
            lines.append("**Shared substrate (always):**")
            for b in shared[:8]:
                lines.append(f"- {b}")
            if len(shared) > 8:
                lines.append("- …")
            lines.append("")

        if profiles:
            lines.append("| Profile | Goal | Key seams (examples) |")
            lines.append("|---|---|---|")
            for name, goal, bullets in profiles:
                # Keep the table compact; this is a continuation prompt surface.
                ex = "<br>".join([b for b in bullets[:4]]) if bullets else ""
                if len(bullets) > 4:
                    ex = (ex + "<br>…") if ex else "…"
                lines.append(f"| {name} | {goal} | {ex} |")
            lines.append("")

    if open_qs:
        lines.append("## Open questions (from trajectory map)")
        for q in open_qs:
            lines.append(f"- {q}")
        lines.append("")

    lines.append("## Commands")
    lines.append("- `make lint`")
    lines.append("- `make context-pack`")
    lines.append("")

    out_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(str(out_path.relative_to(root)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
