# LLM runbook (avoid archive amnesia)

This runbook is a **process guardrail** for editing this living archive.
It exists to reduce “LLM drift” and keep revisions **tight, composable, and reviewable**.

## Non-negotiables (must not degrade)

1) **No ambient authority**: authority must be explicit, inspectable, and reviewable end-to-end (especially in workflows: shell/automation/CLI/UI).
2) **Sealed compatibility**: POSIX/legacy runs only as a **Foreign Cell** behind a fail-closed membrane; interop only via portals/intents/receipts; killable by policy.
3) **Multicore verification is required**: no “single-core-only” proof plan.
4) **Scalability direction**:
   - Hybrid multicore (ADR-0005): multikernel across clusters/NUMA/chiplets; SMP within a cluster.
   - Interface-first scalability: design hot-path actions to **commute** under explicit preconditions when possible; make non-commutative boundaries explicit.
5) **LLM-first ecosystem**: LLMs propose; deterministic validators execute. Schemas + validators + receipts are the stable product surface.

## Must-read set (refresh before making changes)

- `README.md`
- `docs/README.md`
- `docs/00-meta/charter.md`
- `docs/00-meta/trajectory-map.md`
- `docs/00-meta/archive-policy.md`
- `docs/00-meta/id-conventions.md`
- `docs/00-meta/bibliography.md`
- `docs/00-meta/evidence-index.md`
- `docs/10-threat-model/threat-model.md`
- `docs/10-threat-model/assumption-registry.md`
- `docs/20-assurance/claim-registry.md`
- `docs/20-assurance/invariant-registry.md`
- `docs/20-assurance/proof-obligation-registry.md`
- `docs/20-assurance/non-claims.md`
- `docs/20-assurance/traceability.md`
- `docs/30-architecture/decision-map.md`
- `docs/30-architecture/schema-registry.md`
- `docs/30-architecture/interface-registry.md`
- `docs/30-architecture/commutativity-and-interface-scalability.md`
- `docs/30-architecture/state-projection-schema-v0.md`
- `docs/30-architecture/typed-id-contract-v0.md`
- `docs/30-architecture/profile-hash-suite-v0.md`
- `docs/30-architecture/schema-canonical-bytes-v0.md`
- `docs/30-architecture/reqctx-budget-ref-posture-v0.md`
- `docs/30-architecture/hot-action-surface-v0.md`
- `docs/30-architecture/hot-action-boundaries-v0.md`
- `docs/30-architecture/foreign-cell-contract.md`

## When working on multicore direction (refresh before edits touching concurrency/placement)

- `docs/30-architecture/multicore-architecture-options.md`
- `docs/30-architecture/commutativity-and-interface-scalability.md`
- `docs/30-architecture/state-projection-schema-v0.md`

## How to make changes

- Prefer **small, composable edits** (one concept per doc).
- New ideas must:
  - attach to an existing decision/schema/invariant/PO/evidence hook, **or**
  - introduce exactly one new decision surface or schema with an explicit entropy justification.
- Keep sealed-compat honest:
  - no ambient channels (implicit paths/env/implicit net);
  - foreign-cell interop must be portalized and policy-killable.
- Keep Hybrid + commutativity honest:
  - for any new/modified externally visible action, specify conflict keys and commutativity conditions;
  - if non-commutative, state the minimal required serialization boundary and where it lives.
- Keep links and registries wired:
  - update `docs/README.md` for new key docs;
  - register new CH/IF/D/REF/EVID IDs where appropriate.

## Per-iteration requirement

Each iteration must include at least ONE of:
- an entropy-reducing refactor (dedupe/simplify/unify/wiring),
- a new guardrail/tool/check that prevents drift/amnesia,
- or a new integrated feature/idea explicitly profiled and wired into registries + discovery.

## Required outputs for each run

1) A high-level summary of what changed and why (tie back to the non-negotiables and the four product shapes).
2) A concise list of new/updated files.
3) Any new/updated open questions captured (prefer `docs/00-meta/trajectory-map.md`).
   - Use stable **OQ-####** ids so follow-ups can reference open questions without copying prose.
4) Confirm `make lint` was run and fix failures.
5) Provide a working link to the latest zipped archive.

## Commands

- Lint/hygiene: `make lint` (runs archive lints + discovery-surface checks)
- Generate a compact context pack for future runs: `make context-pack` (writes `out/context_pack.md`).
