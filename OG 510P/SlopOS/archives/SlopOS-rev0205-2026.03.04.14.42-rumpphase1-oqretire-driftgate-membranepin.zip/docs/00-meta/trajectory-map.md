# Trajectory map (4 profile stacks + non-negotiables)

This doc records a *mile-high* synthesis of what we are building and the constraints we are choosing.
It is intentionally short: it exists to reduce “local optimum” design drift.

## Non-negotiables (current intent)

1) **One core substrate, four profile stacks** (no forked OSes):
- **Workstation/developer OS** (human-usable daily driver)
- **Cloud substrate / microVM host** (fleet-managed isolation boundary)
- **Embedded / separation-kernel-ish deployments** (small TCB, narrow surface)
- **Agent/automation OS** (LLM-first workflows; auditable actions)

2) **Compatibility is always sealed**: POSIX/legacy environments are treated as **foreign cells** behind an explicit, fail-closed membrane. We may host them for bootstrap and compatibility, but we do not accept their ambient authority model as a system design constraint.

3) **Multicore verification is required**: we do not plan a “single-core-only proof” as our flagship outcome. UP-only prototypes may exist for bring-up, but they are not the verification end state.

4) **Interface-first scalability discipline**: prefer action surfaces whose common-case operations **commute** (D-COMMUTE), so we can scale by sharding/replication and keep global serialization explicit and rare.
   - Composes with Hybrid multicore (D-MK) and keeps the four profile stacks aligned.

5) **LLMs are first-class developers and users** (humans still matter): the stable product surface must be machine-consumable (schemas + validators + receipts), and all high-risk actions must remain deterministic and reviewable.

## What we are (one sentence)

A capability OS whose core product is **explicit, auditable, and enforceable authority** across humans *and* agents, with legacy runtimes hosted only as sealed foreign cells.

## One substrate, four profile stacks

We preserve all four trajectories by keeping the privileged core stable and treating “the rest” as composable stacks.

### Shared substrate (always)
- Capability-mediated resources + IPC + mapping discipline (D-CAP/D-KABI).
- **Portals + receipts** for high-risk authority changes (D-PLUMB/D-VOLITION/D-EXPLAIN).
- A closed, schema-pinned **intent envelope** for workflow glue (CH-PLUMBMSG) and capability-safe automation (D-CAPSHELL/D-WALLET).
- Stable typed-id canonicalization for conflict keys and ordering scopes (D-TYPEDID; `docs/30-architecture/typed-id-contract-v0.md`).
- A pinned v0 profile digest function/length for `digest(CH-*)` seams and receipt correlation hooks (D-HASH; `docs/30-architecture/profile-hash-suite-v0.md`).
- Deterministic validator semantics (“propose → validate → authorize → execute → log”) for both humans and LLMs (docs/70-llm-control).
- A sealed-compat membrane for foreign cells (D-FCELL + I-COMPAT-1, I-COMPAT-2, I-FCELL-1).

### Workstation profile
Goal: make least-privilege usable.
- Rich portals (open/share/print/screenshot/input/capture/net) with usage-control framing.
- First-class CLI plumbing so terminal workflows do not reintroduce ambient authority (D-PLUMB).

### Cloud substrate profile
Goal: measurable isolation + operability.
- MicroVM profile (D-MICROVM), fleet-friendly provenance/boot binding (CH-BOOT/CH-PROV), optional CC annex (D-CC).
- Ops surfaces are capability-mediated services, not ambient daemons.

### Embedded / separation profile
Goal: narrow surface + static composition.
- Static CH-INIT/CH-COMP instantiation, small exit surface budget.
- Profile gates to disable dynamic code, broad I/O, rich portals (D-SEAL/D-DYNCODE/D-DRVDOM).

### Agent/automation profile
Goal: action safety at scale.
- Capshell + wallets + drift gates as first-class workflow tooling (D-CAPSHELL/D-WALLET).
- Receipts/transcripts are default outputs; replay/diff is expected (D-RR).

## Profile compatibility contract (design constraints)

These constraints exist to prevent “silent divergence” between profiles:

- **Core primitives must serve ≥2 profiles** or be explicitly profile-scoped.
- **No ambient “escape hatches”**: if humans can do it, agents can propose it, and validators must enforce it.
- **Legacy/POSIX is never policy-authoritative**: it is always a foreign cell.
- **Authority must be legible**: every grant or widening has a diff/receipt path (D-EXPLAIN) and can be gated in CI (authority drift gates).
- **Multicore is not an afterthought**: concurrency choices must be compatible with the verification strategy from day 0.

## Proof-bearing slice (candidate)

We should pursue a small end-to-end slice that exercises the non-negotiables:

- Multicore kernel core (at least an SMP profile) + explicit memory model scope (D-CONC/D-MEMMODEL).
- One portal workflow (e.g., `portal.uri.*` or `portal.net.*`) with receipts (CH-RECEIPT) and authority diffs (CH-CAPDIFF).
- One capshell flow (learn → tighten → drift-gate) that uses a wallet digest.
- One foreign POSIX cell demonstrating “attempted escape” failing closed.

See: `docs/40-verification/minimum-viable-proof-slice.md` and `docs/30-architecture/multicore-architecture-options.md`.

## Recently resolved (keep short)

- **OQ-0002 D-FCELL membrane contract**: v0 membrane is pinned in `docs/30-architecture/foreign-cell-contract.md`, and adapter receipt commutativity/ordering posture is pinned in `docs/30-architecture/fcell-commutativity-contract-v0.md` (D-FCELL, I-COMPAT-1/I-COMPAT-2, I-FCELL-1, D-COMMUTE). Remaining work is evidence/harnessing, not a design decision.
- **OQ-0003 D-RUMPK selection**: v0 internal compat runtime posture is pinned as **rump kernels, filesystem-image handling only** in `docs/30-architecture/rumpk-selection-posture-v0.md`, and **Phase 1 explicitly forbids introducing a second compat runtime family** (LKL/userspace-kernel/libOS/POSIX facades are Phase 2+ via RFC + new negative tests).

## Open questions (tracked as decision surfaces)

- **OQ-0001 Hybrid follow-ups (ADR-0005)**: keep CH-CLUSTERMAP stable while tightening topology facts only as needed; keep CH-REPLCONTRACT object families registry-closed (see `replication-object-family-registry.md`) and use `profile-repl-defaults.md` as the A–D diff surface; v0 RC4 admission is narrow (RC4 reserved to `tlog`), so remaining work is deciding which families are RC0/RC1/RC2/RC3 in Phase 1 vs later and clarifying scale/NUMA targets for Phase 1 vs later.
- **OQ-0005 D-ATTN revisit trigger**: v0 stance is **no dedicated attention-lease descriptor**; urgent is a policy-gated CH-NOTIF `importance="urgent"` hint (see `docs/30-architecture/attention-lease-posture-v0.md`). Revisit only if we need a durable TTL/renew lease surface.
- **OQ-0006 D-PLUMB lane defaults representation**: v0 recommended A–D defaults for `cfg.params.lane.*` keys are pinned (non-authoritatively) in `docs/30-architecture/profile-lane-defaults.md` as a stable diff surface. Remaining question: whether to later encode these defaults as machine-checked CH-CFG templates (still veto-only) or keep them as guidance consumed by policy-bundle tooling.
- **OQ-0007 CH-EXECPACK replay-safety follow-up (D-CAPSHELL / D-RETRYSAFE)**: request-context binding is pinned (CH-EXECPACK v2 carries `reqctx_digest = digest(CH-REQCTX v1)` and validators require coherence with CH-ACP `meta.reqctx_digest`). CH-EXECPACK v2 supports an optional non-authoritative intent envelope (`plumbmsg_digest = digest(CH-PLUMBMSG v0)`) that strict profiles may require to keep workflow intent explicit. D-RETRYSAFE treats CH-EFFCON `contract_id` as the canonical idempotency key for `capshell.exec` duplicate suppression. v0 output normal form is pinned (exportable outputs are `digest(CH-AREF v0)`; duplicates return the same output digests; CH-ACPOUT `receipt_refs` provides the stable envelope): see `docs/30-architecture/capshell-output-normal-form-v0.md`. Remaining question: whether we need a future schema for named output trees / resource-usage telemetry beyond digest lists.
- **OQ-0008 CH-REQCTX budget reference typing (D-BUDGET follow-up)**: CH-REQCTX v1 `budget_desc_digests` is an untyped digest list. v0 posture is pinned: consumers that require sponsorship are type-strict and non-ambient (only CH-BUDGET v0 counts; schema mismatches count as missing; no locator deref): `reqctx-budget-ref-posture-v0.md`. Remaining question: whether we ever need a future CH-REQCTX revision with typed `{schema,digest}` refs (or split lists) if multi-schema sponsorship becomes real (avoid early schema bloat).
