# Profile replication defaults matrix (A–D; no forks)

Purpose: pin **non-authoritative** default guidance for cross-cluster replication contracts (CH-REPLCONTRACT v0) across the four product shapes:

- (A) secure workstation,
- (B) cloud micro-VM / hosted compute substrate,
- (C) embedded / separation-kernel-ish appliance,
- (D) agent/automation OS.

This matrix is a **composition aid**, not a fork mechanism:
- Profiles may override these defaults in signed policy bundles / config compilers.
- Replication contracts are **non-authoritative** (PO-REPL-NOAMP): they cannot grant authority.
- Unknown `object_family` tokens are rejected in strict profiles (see `replication-object-family-registry.md`).

Stability rule: treat this file as a **stable diff surface**. Any changes must keep A–D viable and keep D-REPL honest: global ordering is rare and explicit.

## Defaults (v0 seed; conservative)

Values are the CH-REPLCONTRACT v0 `replication_class` tokens:
- `rc0_local`
- `rc1_owner`
- `rc2_epoch_snapshot`
- `rc3_comm_merge`
- `rc4_ordered_log`

| object_family | A (workstation) | B (cloud substrate) | C (embedded/separation) | D (agent/automation) | Notes |
|---|---|---|---|---|---|
| `view` | `rc1_owner` | `rc1_owner` | `rc0_local` | `rc1_owner` | C defaults to local-only views (no cross-cluster UX surface); others route authoritative mutations to owner |
| `transcript` | `rc3_comm_merge` | `rc3_comm_merge` | `rc2_epoch_snapshot` | `rc3_comm_merge` | C prefers epoch snapshots to bound storage/export; others use commutative event-set merge |
| `receipt` | `rc3_comm_merge` | `rc3_comm_merge` | `rc2_epoch_snapshot` | `rc3_comm_merge` | same rationale as transcripts; receipts remain non-authoritative evidence artifacts |
| `quota` | `rc3_comm_merge` | `rc3_comm_merge` | `rc0_local` | `rc3_comm_merge` | C often disables metering lanes; if enabled, keep it local unless explicitly justified |
| `budget` | `rc1_owner` | `rc1_owner` | `rc0_local` | `rc1_owner` | mint/split/revoke boundary is owner-sharded (non-commutative boundary is explicit) |
| `caprpc_proxy` | `rc1_owner` | `rc1_owner` | `rc0_local` | `rc1_owner` | cross-cluster access is via owned proxies, not copied handles |
| `namecert` | `rc3_comm_merge` | `rc3_comm_merge` | `rc3_comm_merge` | `rc3_comm_merge` | signed bundles merge as a set; policy resolves trust/visibility |
| `tlog` | `rc0_local` | `rc4_ordered_log` | `rc0_local` | `rc2_epoch_snapshot` | RC4 is reserved to `tlog` in v0; A/C default off; D prefers snapshots unless it is operating a log |

## RC4 admission rule (v0)

`rc4_ordered_log` is **reserved to `object_family = tlog`** in v0.
If any other family needs RC4 semantics, the archive must:
- update D-REPL posture (why order is required and where serialization lives), and
- add an evidence hook showing why RC3/RC2 is insufficient.

## Guardrail

CI enforces:
- `object_family` values are registry-closed (see `replication-object-family-registry.md`),
- `replication_class` values are from the closed enum above, and
- RC4 appears only in the `tlog` row.

Evidence: EVID-2026-214.

Tool: `tools/check_profile_repl_defaults.py`.
