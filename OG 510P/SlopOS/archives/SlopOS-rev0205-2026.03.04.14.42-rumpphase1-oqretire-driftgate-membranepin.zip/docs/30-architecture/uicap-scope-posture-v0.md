# D-UICAP v0 scope posture: trusted UI path without a UI stack

Purpose: resolve **OQ-0004 (D-UICAP scope)** by pinning a narrow, implementable v0 scope for capability-mediated UI.

This is a *posture* document, not a new schema.
It does **not** pick a toolkit, compositor protocol, remote display protocol, or desktop UX.

## v0 posture

**v0 posture:** if D-UICAP is enabled, SlopOS treats the UI boundary as a **capability seam** and supports a **spoof-resistant trusted entry** for high-risk flows, while keeping the privileged core small.

Minimum required properties (when enabled):

1) **Surface isolation** (I-UICAP-1): no ambient pixel readback or cross-client surface control.
2) **Focus-gated input** (I-UICAP-2): unfocused clients do not receive input; “global” interception/injection is capability-gated.
3) **High-risk UI authority is portal-only** (D-PLUMB): capture/remote-control/screenshot/automation sessions are workflow-mediated (and SHOULD be leased under D-LEASE).
4) **Secure attention entry (SAS) is supported for interactive profiles that claim spoof resistance** (I-SAS-1): a non-interceptable user gesture that enters a visually distinct secure UI mode.

Everything beyond this minimum is *explicitly out of scope* for v0.

## Scope by product shape (A–D)

This archive carries four product shapes. v0 scope is intentionally profile-shaped rather than “one desktop for all.”

| Shape | D-UICAP default | SAS / secure UI mode | D-VOLITION | D-UIAUT (automation) |
|---|---|---|---|---|
| (A) secure workstation | **on (recommended)** | **required** for login/unlock + high-risk consent surfaces | on (recommended) | observation-only by default; injection is portal + lease + explicit policy |
| (B) cloud micro-VM / substrate | off (default) | n/a | optional (headless approvals via external console if present) | off (default) |
| (C) embedded / separation appliance | off (default) | optional (only if interactive local admin UI exists) | optional | off (default) |
| (D) agent/automation OS | optional | **required** if any human approval surface is claimed | on (recommended when human-in-loop exists) | on (expected), but injection remains leased + transcript-visible |

Notes:
- “Default” here is *guidance*, not authority: profiles remain policy-driven via the normal config/lane posture surfaces.
- When D-UICAP is off, any “desktop-like” UI is treated as untrusted application space; do **not** claim spoof resistance.

## Secure attention + secure UI mode (v0 semantics)

If SAS is enabled, v0 semantics are:

- SAS is delivered **only** to the secure UI component(s) (PO-SAS-DELIVER / I-SAS-1).
- SAS enters a visually distinct **secure UI mode** that occludes/freezes normal surfaces.
- While in secure UI mode:
  - normal applications do not receive input;
  - capture and injection authorities are disabled unless explicitly permitted by policy;
  - high-risk prompts (login/unlock, consent/powerbox) are hosted only by the secure UI component.

This posture is compatible with multiple implementation strategies:
- hardware-driven attention keys where available,
- reserved key chord (e.g., Ctrl+Alt+Del style) if the platform can deliver it exclusively,
- out-of-band console/management UI on headless targets.

See: RFC-0080; REF-MS-WINLOGON-SAS; REF-MS-UAC-SECUREDESKTOP; REF-IBM-AIX-TRUSTEDPATH.

## Non-goals (explicitly out of scope for v0)

To keep v0 implementable and prevent scope creep, D-UICAP v0 does **not** require:

- a specified compositor IPC protocol,
- a specified rendering stack/toolkit,
- global hotkey APIs for third-party apps,
- cross-client accessibility tree/text readback as ambient capability,
- “secure input session” leases for arbitrary sensitive widgets (RFC-0080 mentions this as optional; defer until there is evidence pressure).

If any of the above becomes necessary, introduce it via an RFC and attach new evidence hooks.

## Evidence hooks

- **EVID-2026-078**: compositor harness negative tests (pixel isolation, focus gating, portal-only capture).
- **EVID-2026-095**: SAS + secure mode integration harness (exclusive delivery, occlusion/freeze, fail-closed recovery).

