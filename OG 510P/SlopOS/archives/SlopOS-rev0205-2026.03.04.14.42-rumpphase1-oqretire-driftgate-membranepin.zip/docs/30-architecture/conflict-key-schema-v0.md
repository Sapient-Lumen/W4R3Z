# CH-CONFLICTKEY v0: Conflict key descriptor (schema)

Purpose: provide a small, deterministic descriptor for an action’s **conflict key**.

- A **conflict key** is the smallest resource identity whose concurrent mutation can conflict.
- D-COMMUTE uses conflict keys to state when actions commute (different keys) vs must serialize (same key).
- CH-ORDERTOK uses conflict keys to scope ordered streams: ordering is **never global by accident**.

**Important:** CH-CONFLICTKEY is **non-authoritative**.
It MUST NOT carry bearer secrets or raw capabilities.
It exists for validators, receipts, commutativity tests, and Hybrid routing.

## Encoding
Candidate baseline: canonical CBOR (D-ENC).
Decoders MUST reject non-canonical encodings (I-ENC-1; PO-ENC-DECODE).

## Data model (conceptual)

CH-CONFLICTKEY v0 := {
  v: 0,

  ; closed enum identifying the family
  family: tstr,   ; canonical allowlist is pinned in `conflict-key-family-registry.md`

  ; family-specific payload; all fields MUST be bounded
  key: { * tstr => any },

  meta?: { * tstr => any }   ; optional; MUST be ignored unless whitelisted
}

### Family payloads (v0 seed; canonical family list: `conflict-key-family-registry.md`)

This v0 schema intentionally covers only the families needed by the pinned hot action surface + current ACP/compat seams.
New families require an RFC and registry updates.

1) `mem.range`
- `as_key: bstr` — digest of a stable address-space identity tuple (profile-defined)
- `vaddr_lo: uint`
- `vaddr_len: uint`

2) `ipc.endpoint`
- `endpoint_key: bstr` — digest of a stable endpoint identity tuple

3) `view.slot`
- `view_key: bstr` — digest of a stable view identity tuple
- `slot_id: uint` — bounded slot id

4) `log.eventset`
- `log_key: bstr` — digest of a stable log identity tuple

5) `budget.issuer`
- `issuer_key: bstr` — digest of a stable issuer/meter identity tuple

6) `budget.lease`
- `budget_key: bstr` — digest of a stable budget lease identity tuple

7) `policy.param`
- `param: tstr` — **canonical config/policy parameter key** (bounded).
  - **Derivation (normative for ACP v0):** `param` MUST be the exact `cfg.params.*` key string (or other IF-CFG parameter key) as listed in `config-toggle-registry.md` (no aliasing, no case-folding, no normalization beyond exact UTF-8 bytes).
  - Equality is exact string match; if a profile supports parameter aliases, alias expansion MUST happen *before* conflict-key derivation and MUST be transcript-visible.

8) `domain.id`
- `domain_key: bstr` — **canonical domain conflict key digest**.
  - **Derivation (normative for ACP v0):** compute `domain_key = ck_domain(domain_id)` where `domain_id` is the domain identifier carried by the action (typed handle/id at IF-ACP / IF-KABI).
    - `ck_domain(x)` := if `x` is already a digest-sized opaque id (length == profile hash length), then `ck_domain(x) = x` (avoid double-hashing).
    - otherwise `ck_domain(x) = digest(canonical_bytes(x))`, where `canonical_bytes(x)` is the canonical encoding of the domain identifier as it appears in the action’s typed `target` (profile-defined, but MUST be deterministic and closed-world).

9) `cell.id`
- `cell_id: bstr` — must match the launched CH-FCELL.cell_id (digest-sized; D-TYPEDID)

10) `cell.adapter`
- `cell_id: bstr` — CH-FCELL.cell_id (digest-sized; D-TYPEDID)
- `portal_token: tstr` — CH-PLEDGE `portal.*` token (closed set)

### Derivation commitments (v0; ACP + hot-action seams)

This section pins derivation rules for the **conflict-key families that appear on pinned action surfaces** so validators, receipts, and commutativity/ordering evidence cannot drift.

Source of truth for the digest-valued `*_key` fields is `conflict-key-derivation-registry.md`.

- `mem.range`: the derived conflict key is `digest(CH-CONFLICTKEY)` with `family="mem.range"` and `key.as_key` derived as `ck_id("mem.as", as_id)` (see derivation registry). `vaddr_lo`/`vaddr_len` are raw bounded integers.
- `ipc.endpoint`: the derived conflict key is `digest(CH-CONFLICTKEY)` with `family="ipc.endpoint"` and `key.endpoint_key = ck_id("ipc.endpoint", endpoint_id)` (see derivation registry).
- `view.slot`: the derived conflict key is `digest(CH-CONFLICTKEY)` with `family="view.slot"` and `key.view_key = ck_id("view.id", view_id)` (see derivation registry). `slot_id` is a raw bounded integer.
- `log.eventset`: the derived conflict key is `digest(CH-CONFLICTKEY)` with `family="log.eventset"` and `key.log_key = ck_id("log.eventset", log_id)` (see derivation registry).
- `budget.issuer`: the derived conflict key is `digest(CH-CONFLICTKEY)` with `family="budget.issuer"` and `key.issuer_key = ck_id("budget.issuer", meter_id)` (see derivation registry).
- `budget.lease`: the derived conflict key is `digest(CH-CONFLICTKEY)` with `family="budget.lease"` and `key.budget_key = ck_id("budget.lease", budget_id)` (see derivation registry).
- `policy.param`: the derived conflict key is `digest(CH-CONFLICTKEY)` with `family="policy.param"` and `key.param` set to the exact `cfg.params.*` (or IF-CFG) parameter key string (see item 7). No ambient aliasing.
- `domain.id`: the derived conflict key is `digest(CH-CONFLICTKEY)` with `family="domain.id"` and `key.domain_key = ck_domain(domain_id)` (see item 8). Avoid double-hashing digest-sized ids.

Notes:
- These commitments are **non-authoritative**: they exist to keep D-COMMUTE/CH-ORDERTOK scoping stable and reviewable, not to grant power.
- Additional families may remain profile-defined until an RFC pins them; where a family includes a digest-valued identity field, the preferred pattern is `ck_id(..)` from the derivation registry.

## Validation rules (minimum)
Validators MUST be total and fail closed (PO-CONFLICTKEY-VALIDATE):
1) `v == 0` and required fields present.
2) `family` is a closed allowlist (per `conflict-key-family-registry.md`); unknown families reject.
3) All payload fields are within declared bounds.
4) **Non-authoritative rule:** the descriptor MUST NOT contain bearer secrets or raw capability identifiers.

## Use in ordered actions and receipts

- Ordered actions MUST carry `order_digest = digest(CH-ORDERTOK)`.
- CH-ORDERTOK `scope.key_digest` MUST equal `digest(CH-CONFLICTKEY)` for the action’s conflict key (I-ORDERTOK-2).
- Receipts SHOULD record `conflict_key_digest = digest(CH-CONFLICTKEY)` for hot actions to support commutativity tests and Hybrid routing.

## Security notes

- Prefer digests of stable identity tuples rather than raw object ids to reduce oracle surface.
- Conflict keys are informational. They may support deny-only routing or sharding decisions, but never grant authority.
