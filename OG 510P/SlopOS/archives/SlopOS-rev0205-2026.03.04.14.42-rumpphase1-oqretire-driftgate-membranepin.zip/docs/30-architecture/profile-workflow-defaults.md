# Profile workflow defaults matrix (A–D; no forks)

Purpose: pin **non-authoritative** default guidance for workflow-facing **policy knobs** that shape
how automation executes under D-CAPSHELL.

This matrix is a **composition aid**, not a fork mechanism:
- Profiles may override these defaults in signed CH-CFG / policy bundles.
- Missing/unknown keys MUST be rejected by IF-CFG per `config-toggle-registry.md` (PO-CFGTOGGLE-VERIFY).
- Enabling a workflow knob never grants authority; it only **narrows** allowed behavior (veto-only).

Stability rule: treat this file as a **stable diff surface**. Any changes must:
- keep A–D viable (no forks),
- preserve sealed-compat posture (Foreign Cell remains portal/intent/receipt only; killable), and
- preserve “no ambient authority” (workflow knobs must not introduce implicit channels).

## Defaults (v0 seed; conservative)

Values:
- `on`: recommended to be enabled in the profile’s default config/policy bundle.
- `off`: recommended to be disabled in the profile’s default config/policy bundle.

| Param key | A (workstation) | B (cloud substrate) | C (embedded/separation) | D (agent/automation) | Notes |
|---|---|---|---|---|---|
| `cfg.params.capshell.minimal_context` | off | on | on | on | When on, `capshell.exec` requires a *minimal* execution context: empty CH-ENV, CH-CWD `kind="empty"`, CH-STDIO `(null, drop, drop)`, and empty CH-FDSET. This reduces workflow attack surface and improves replay/test determinism. |
| `cfg.params.capshell.require_budget_lease` | off | on | on | on | When on **and** `cfg.params.lane.metering=true`, `capshell.exec` requires the bound CH-REQCTX v1 to include at least one `budget_desc_digests` entry that resolves/validates as CH-BUDGET v0. This prevents implicit sponsorship and makes “who pays” explicit in automation. |
| `cfg.params.capshell.require_plumbmsg` | off | on | off | on | When on, `capshell.exec` requires CH-EXECPACK v2 to include `plumbmsg_digest = digest(CH-PLUMBMSG v0)` (non-authoritative workflow intent envelope). This keeps workflow intent reviewable and discourages ambient/prose-only intent channels; validators deny missing/invalid envelopes deterministically (recommended CH-DENY: `plumbmsg-missing`). |

## Guardrail

CI enforces:
- every `cfg.params.capshell.*` key in `config-toggle-registry.md` appears in the table above,
- no extra keys are introduced here,
- values are from the closed set `{on, off}`.

Tool: `tools/check_profile_workflow_defaults.py`.
