# Decision map (major branches + decision evidence)

Each D-* is an RFC topic; once evidence exists it becomes an ADR.
Rule: decisions that change claims, interfaces, or TCB must update registries.

Drift gate: `tools/check_decision_map_refs.py` enforces that any `D-...` identifier referenced in the `docs/` tree has a corresponding entry in this map (prevents orphan decision ids and keeps the decision→evidence surfaces discoverable).

Related drift gate: `tools/check_assurance_token_refs.py` enforces registry-closure for A-/C-/I-/PO- references across repo markdown (keeps decision→invariant/PO/evidence chains coherent under LLM edits).

## D-ARCH: architecture shape
Options: hypervisor-first; microkernel-first; separation-kernel-first.  
Evidence: privileged surface size, exit/IPC complexity, proof surface; alignment with threat model and supply-chain posture.

## D-ISA: initial ISA family
Options: x86_64; AArch64; RISC-V (S-mode; H extension if hypervisor-first).  
Evidence: virtualization + IOMMU maturity; trap/MMU simplicity; bring-up speed; availability of formal ISA semantics.

## D-CHERI: optional capability-hardware profile
Options: ignore; hybrid ABI support; pure-capability (“purecap”) compartments; user-mode only vs privileged adoption.  
Evidence: reduction in memory-corruption exploitability for unsafe compartments; performance/compatibility impact; toolchain/provenance feasibility.

## D-MEMTAG: hardware memory tagging + hardening profiles (optional)
Options: ignore; Arm MTE for selected user-space compartments; broader MTE posture; software-sanitizer-only for tests.
Evidence: catch-rate and exploit-hardening gains for unsafe/legacy compartments; overhead/compatibility impact; ability to bind hardening intent as data (CH-HARDEN) without expanding the privileged core.
See: RFC-0062.


## D-VERIF: verification program
Options: Verus-first; proof-assistant-first; hybrid (model-check early, mechanize later).  
Evidence: ability to express invariants/refinement; trust story; iteration speed; proof maintenance plan.

## D-DRT: definitional models + differential randomized testing (evidence method)
Options: none (ad hoc tests); DRT for CH-KABI/CH-ACP only; DRT for all CH-* schemas + validators.  
Evidence: counterexample-finding speed; ability to keep reference models tiny/auditable; reduction of “spec drift” before mechanization.

## D-KABI: privileged ABI shape + minimization strategy
Options: syscall ABI; hypercall ABI; static partition ABI; ABI-as-action-set.  
Evidence: totality/fail-closed behavior; stable encoding; reducible action space for proofs (<PO-ABI-*>).

## D-CAP: capability semantics (derive/mint/revoke)
Options: derivation-only attenuation; allow amplification via explicit “authority objects”; revocation model (none / lazy / eager / epoch).  
Evidence: ability to specify/verify I-CAP-1 + I-REVOKE-1; complexity of revocation proofs; impact on KABI and object model.

## D-COMP: manifested system composition (component graph + capability routing)
Options: no manifest (hand-coded init); minimal CH-COMP consumed by user-space init; richer framework (realms/dynamic resolution).  
Evidence: ability to make cross-component authority edges explicit (reviewable + lintable), tie composition to provenance (CH-BOOT binding), and enforce “no undeclared routes” (I-COMP-1) without expanding the privileged core.

## D-SUPV: supervision trees and restart policy (optional)
Options: none; Erlang/OTP-style supervision trees in user space; MINIX3-style reincarnation server; hybrid (structured restart + component-level policy).  
Evidence: ability to recover from driver/service faults without privileged policy, keep failure handling reviewable/lintable, and integrate with updates/checkpoints (D-ATOMICUPD, D-CHKPT) while preserving authority discipline (I-CAP-1).

## D-ACTIVATE: activation-owned stable handles + bounded handle stores (optional)
Options: none (default); supervisor-owned stable exports + activation set delivery (CH-ACTSET) + optional per-component handle store (RFC-0081).
Evidence: restart continuity without dropped inbound traffic; deterministic Stop→Kill lifecycle; handle-store phase gating interacts cleanly with D-SEAL; wrong-instance restore fails closed and bounds prevent DoS.
See: RFC-0017 (restart policy seam), RFC-0041 (crash-only/microreboot discipline).


## D-INITSNAP: initial state snapshots / capability distribution (optional)
Options: none (implicit init); CH-INIT snapshot validated at boot; adopt/import capDL-style snapshot language.
Evidence: seL4 capDL + Microkit show that a static system description compiled into an initializer can keep runtime tiny and make “boot matches snapshot” arguments tractable.
Evidence: ability to pin time-0 authority edges for audit/debug, seed D-RR replay, and enable mechanized ‘boot reaches snapshot’ arguments without expanding privileged policy logic.

## D-CAPX: capability export/import across trust boundaries (optional)
Options: proxy-based CapTP-style references; cryptographic bearer tokens (macaroons/biscuit); hybrid.  
Evidence: ability to bind remote authority to local objects (I-CAPX-1) and keep attenuation monotonic (I-CAPX-2) without importing a large distributed-systems TCB.

Adjunct: CH-SREF (“sturdyrefs” / offline capabilities) as an out-of-band handoff/persistence seam (RFC-0014).

## D-CAPRPC: object-capability RPC profile (optional)
Options: none (default); adopt a capability-RPC frame (CH-CAPRPC) for component calls with payloads governed by pinned CH-IFACE descriptors (D-IDL); optionally support promise pipelining/persistent capabilities in later phases.
Evidence: whether RPC boundaries can remain capability-mediated (no ambient endpoints), transcriptable (CH-LOG), and small enough to model-check; integration with D-CAPX/CH-SREF for remote and offline references.

## D-APIEVO: interface evolution posture (optional)
Options: treat all interfaces as closed (break/replace only); allow “open” interfaces that can be safely extended with explicit unknown-op semantics; support adapters/translators as first-class components for compatibility.
Evidence: ability to upgrade components without confused-deputy fallbacks; deterministic error reporting for unknown interface/method; tooling that can gate upgrades when required interfaces disappear (CH-IFACE supersedes breadcrumbs + CH-BOOT/CH-UPD policy).
See: RFC-0071.

## D-NAMECERT: local naming certificates (optional)
Options: none (default); user-space SPKI/SDSI-style local name+delegation bundles (CH-NAMECERT); integrate with views/sturdyrefs.  
Evidence: whether local namespaces + delegation improve usability/auditability without importing PKI complexity; ability to keep evaluation out of the privileged core and retain non-amplifying semantics (I-NAME-2).

## D-NS: view/namespace semantics (v1) (optional)
Options: minimal v0 views (bind/mount/resolve only); per-process copy-on-write namespaces with **union mounts** (Plan 9 style); add “service trees” (file-like hierarchies) as a tooling/introspection convention (optionally 9P-like transport for remote mounts).
Evidence: usability wins without ambient authority; ability to keep resolve pure + non-amplifying (I-VIEW-1/I-VIEW-2); performance of union/overlay; auditability of namespace mutation (CH-LOG binding) and interaction with sealing (D-SEAL).

## D-MEMBRANE: membranes / revocable forwarders (optional)
Options: user-space membranes/wrappers; kernel-supported indirection (epochs/tables) if needed.  
Evidence: ability to make attenuation/revocation *transitive* across boundaries without leaking raw capabilities; overhead; proof surface.

## D-AUTHAGENT: key-holding authentication agent (optional)
Options: user-space “factotum/ssh-agent style” service; hardware-backed keys (TPM/TEE) as a profile annex.  
Evidence: reduction of key-material exposure; minimal interface shape; auditability (CH-LOG) without secret leakage; explicit assumptions.

## D-CRYPTOSVC: capability crypto services + key policy pins (optional)
Options: ad hoc agent APIs; adopt pinned descriptors (CH-KEYPOL/CH-KEYREF/CH-CRYPTOAUDIT) for reviewable key handles and redaction-safe crypto audit; hardware-backed provider annex (TPM/TEE) vs software-only agent.  
Evidence: ability to eliminate key-export APIs (I-CRYPTO-1), enforce purpose/context constraints (I-CRYPTO-2), make delegation + persistence safe (D-LEASE/D-PERSIST), and keep audit transcripts useful without leaking secrets (PO-CRYPTOAUDIT-REDACT).
See: RFC-0067.

## D-APPSECRET: per-application secret seeds via a portal (optional)
Options: none (default); add a secret portal (portal.secret) that issues per-application secret seeds for local encryption/integrity without introducing ambient keyring APIs. Emit a bounded CH-APPSECRET descriptor for receipts/audit. Optional stricter profile returns a non-exportable seed handle instead of bytes (composes with D-CRYPTOSVC).
Evidence: whether we can satisfy common app needs (local DB encryption, integrity tags) while preserving authority discipline: per-app isolation (I-APPSECRET-1), no secret bytes in transcripts/exports (I-APPSECRET-2), explicit rotation semantics and policy gating (I-APPSECRET-3), and fail-closed validation/enforcement (PO-APPSECRET-VALIDATE/PO-APPSECRET-ENF). Abuse-case coverage includes AC-089.

## D-VAULT: sealed secrets + vault service (optional)
Options: no standard vault (apps manage secrets ad hoc); standardize a user-space vault with pinned secret policy + durable secret references (CH-SECRETPOL/CH-SECRETREF) layered on D-CRYPTOSVC; add hardware sealing/attestation gates only in deployment profiles (TPM/TEE/D-CC).
Evidence: ability to eliminate ad hoc secret-export APIs; policy-bound context/evidence checks (I-VAULT-1/I-VAULT-2); rollback-safe persistence story when combined with D-PERSIST; ability to bind high-risk releases to volition/receipt seams (D-VOLITION/D-EXPLAIN) without expanding the privileged core.
See: RFC-0070.

## D-CONTRACT: contract-based channels (protocol state machines) (optional)
Options: library-enforced protocol FSMs (default); optional user-space runtime monitor; kernel-enforced contracts (avoid unless required).  
Evidence: prevention of protocol confusion; model-check tractability on small FSMs; codegen/maintenance impact; interaction with D-ENC and KABI.

## D-PAGER: user-mode pager/exception handling (optional)
Options: kernel-only paging (default); user-level pager per address space; hybrid fault routing for microVM profiles.  
Evidence: kernel TCB reduction vs authority leakage and DoS; ability to keep fault surface closed and auditable (CH-KABI/CH-LOG) and to preserve isolation invariants.
See: RFC-0044.

## D-CONC: concurrency scope (staged)
Options:
- UP-only prototypes (bring-up only; not a flagship verification end state)
- SMP-big-lock baseline (verified multicore sequentialization point)
- SMP-refined locking/sharding
- Hybrid/multikernel evolutions when scale requires

Evidence: proof complexity vs scalability; performance requirements; ability to specify an explicit memory model (D-MEMMODEL).
See: docs/30-architecture/multicore-architecture-options.md.


## D-COMMUTE: interface-first scalability via commutativity

**Status**: Required discipline for privileged action surfaces (ADR-0005).

Options:
- Ignore (traditional “correctness first; hope it scales”)
- Annotate action specs with conflict keys + commutation predicates (documentation only)
- Enforce commutativity claims via generated tests and evidence hooks (preferred)
  - Pin per-action metadata on stable surfaces: `hot-action-surface-v0.md` for the hot privileged surface, `docs/70-llm-control/acp-action-kind-registry.md` for CH-ACP kinds (conflict keys, ordering witnesses, retry safety), and `docs/70-llm-control/acp-commutativity-predicate-registry.md` for per-kind commutation predicates + normalized observation boundary.
- Use commutativity metadata as a scheduler/planner hint (optional; must not affect correctness)

Receipt surface note: when D-COMMUTE observability is in scope, ordering failures MUST remain digest-bound and non-ambient: CH-DENY for `conflict-key-invalid` / `order-witness-*` binds `conflict_key_digest` and/or `order_digest` so transcripts can name the serialization domain without implementation logs (I-DENY-4; PO-DENY-ORDER-BIND).

Evidence: spec-level commutation proofs/tests (PO-COMMUTE-SPEC, PO-COMMUTE-TEST); reduced coordination in hot paths; ability to evolve from SMP → hybrid/multikernel without ABI breakage.

See: `commutativity-and-interface-scalability.md` (REF-SCR-TOCS15), `serialization-boundary-registry.md` (closed `validator`/`svc:<name>`/`none` tokens for ordered kinds), `hot-action-surface-v0.md` (pinned hot surface v0), `conflict-key-family-registry.md` (closed CH-CONFLICTKEY family allowlist), and `conflict-key-derivation-registry.md` (pins deterministic tuple→digest derivation for the digest-valued `*_key` payload fields used by pinned surfaces), plus `typed-id-contract-v0.md` (pins canonical encoding for the `*_id` inputs that feed `ck_id(..)`).



## D-TYPEDID: canonical encoding for core typed identifiers (v0: opaque digests)

**Status**: Adopt v0 contract (Revised184).

Problem: several hot action / ACP seams refer to typed ids (`as_id`, `endpoint_id`, `view_id`, …)
that feed conflict keys and ordered-stream scopes. If their encoding is “profile-defined”, drift
becomes inevitable and commutativity evidence rots.

Decision (v0): for the core ids that feed `ck_id(..)` / `ck_domain(..)` on pinned surfaces,
represent ids as **opaque digest bytes**: a `bstr` of length `hashlen` (profile digest length).
See: `typed-id-contract-v0.md`.

Evidence: deterministic canonical encoding (raw bytes); minimal privileged validation (length check);
keeps hash agility profile-scoped; closes an otherwise-open “tuple encoding” ambiguity in D-COMMUTE
without inventing new schema surface area.

See: `typed-id-contract-v0.md`, `conflict-key-derivation-registry.md`, `conflict-key-schema-v0.md`.
References: REF-RFC6920, REF-GIT-HASH-TRANSITION, REF-MULTIHASH.


## D-HASH: profile hash suite (v0: SHA-256, fixed length)

**Status**: Adopt v0 contract (Revised194).

Problem: many pinned seams say “profile hash” / “profile digest length” without defining the
hash suite. Leaving it implicit invites drift:
- mixed digest algorithms across validators/tools,
- length mismatches that break receipt correlation,
- and human-facing encodings (hex/base64) accidentally becoming privileged inputs.

Decision (v0):
- `digest(bytes) := SHA-256(bytes)`
- `hashlen := 32`
- digests on privileged seams are raw digest bytes (no in-band algorithm tags).

Entropy justification: we spend **one** decision surface (D-HASH) to collapse ambiguity across
typed ids (D-TYPEDID), conflict keys / ordering scopes (D-COMMUTE), and receipt hooks. We do **not**
introduce a new schema surface for digests in v0.

See: `profile-hash-suite-v0.md`.
References: REF-FIPS180-4, REF-RFC6234.


## D-RETRYSAFE: deterministic retry + dedupe keys for validator-executed actions

**Status**: Required discipline for the LLM-first action surface.

Problem: in an agent-driven system, retries are normal (timeouts, restarts, duplicate delivery).
If retry behavior is left implicit, implementations tend to:
- accidentally repeat effects (double grants, double jobs, duplicate background grants), or
- smuggle in ambient state/order as a hidden idempotency mechanism.

Decision (v0): for any externally visible action kind that claims **at-least-once-safe** retry semantics,
we require a **schema-pinned, explicit idempotency/dedupe key**:
- the key is named in the kind’s registry row (stable diff surface),
- the key is carried in an existing bound descriptor (or the action params) and is **non-authoritative**,
- validators/owner services suppress duplicates *before* any effect, and
- outcomes are transcript-visible (CH-LOG/CH-ACPOUT) so duplicate suppression is auditable; when CH-ACPOUT is emitted for an accepted-but-deduped proposal, producers SHOULD set `effect="duplicate_suppressed"` (CH-ACPOUT v0) so tooling can distinguish “applied” from “suppressed” without implementation-specific logs.

Canonical examples (already present surfaces):
- `capshell.exec` uses CH-EFFCON `contract_id` as the idempotency key for duplicate suppression (paired with the capshell output normal form: exportable outputs are CH-AREF digests and duplicates return the same output digests; see `capshell-output-normal-form-v0.md`).
- `portal.clock.timeproof.sample` uses CH-TIMEREQ `req_id`.
- `portal.jobs.submit` uses CH-JOBREQ `job_id`.
- `portal.background.request` uses CH-BGREQ `req_id`.
- `portal.attn.request` uses CH-NOTIF `.id` for upsert/dedupe semantics.

Evidence: small retry/dedup harnesses (swap-order + duplicate-delivery) complement D-COMMUTE tests;
Jepsen/Knossos-style reasoning applies to ordered streams and dedupe keys (REF-KNOSSOS-JEPSEN).

Guardrail: `tools/check_retry_dedupe_wiring.py` fails `make lint` if any ACP kind marked
*at-least-once-safe* does not name an explicit stable dedupe key token.

## D-MK: multicore structure (SMP vs multikernel vs hybrid)

**Status**: Adopt **Hybrid** as the default direction (ADR-0005). SMP variants remain permitted as *in-cluster* implementations/profiles.
Options:
- Shared-kernel SMP (possibly big-kernel-lock as an early verified baseline)
- SMP with explicit sharding/replication of key state (clustered objects)
- Multikernel-style per-core kernels/monitors coordinating via explicit messages
- Hybrid: multikernel across NUMA/chiplets; SMP within a cluster
- Application-directed sharing (Corey-style) as an explicit configuration surface

Evidence: ability to keep ownership of shared state explicit (reduce hidden sharing) and stage proof obligations; scalability on many cores/NUMA; interaction with determinism/replay; how cleanly CH-HWFACT/SKB can drive placement and topology decisions.
See: docs/30-architecture/multicore-architecture-options.md.

## D-CLUSTERMAP: cluster derivation + partition artifact (Hybrid adjunct)

**Status**: Required seam for Hybrid (ADR-0005). Early phases may default to a single cluster, but the artifact surface is stable.

Options:
- Implicit/opaque kernel clustering (avoid; hard to audit and reason about)
- User-space derivation from CH-HWFACT with optional profile knobs, emitting CH-CLUSTERMAP (preferred)
- Profile-pinned cluster maps (static configs for appliances / separation profiles)
- Adaptive clustering at runtime (avoid early; tends to explode proof surface and observability)

Evidence: determinism (PO-CLUSTERMAP-DERIVE), fail-closed validation (PO-CLUSTERMAP-VALIDATE), and ability to state cross-cluster ownership/replication contracts against stable cluster ids.
See: `cluster-derivation.md` and CH-CLUSTERMAP v0.

## D-REPL: cross-cluster replication/consistency contracts (Hybrid adjunct)

**Status**: Adopt a conservative v0 contract vocabulary and schema seam (ADR-0006).

Options:
- Implicit global services/shared state (avoid; defeats Hybrid)
- Ad-hoc per-service replication semantics (avoid; hard to audit and prove)
- Bounded contract vocabulary (RC0..RC4) expressed as CH-REPLCONTRACT (preferred)
- Strong global consensus for broad state (defer; must be explicit and justified)

Evidence: ability to state ownership and ordering requirements against stable cluster ids; fail-closed validation (PO-REPLCONTRACT-VALIDATE); no authority amplification from replicated metadata (PO-REPL-NOAMP); compatibility with D-COMMUTE tests for RC3 objects (PO-REPL-MERGE).
See: `replication-contracts-v0.md` and CH-REPLCONTRACT v0.

Guardrails: treat CH-REPLCONTRACT `object_family` tokens as registry-closed (see `replication-object-family-registry.md`) and pin A–D default guidance in `profile-repl-defaults.md` so global ordering (RC4) stays rare and explicit.


## D-SCHED: scheduling stance (verification-first)
Options: deterministic (Phase 1 default); nondeterministic but constrained; SMP-first.  
Evidence: whether determinism can collapse early proof obligations; interaction with time/interrupts; compatibility with the platform profile.

## D-TURNS: turn-based concurrency for selected services (optional)
Options: none (default); per-service event-loop ("vat") runtimes for selected components; profile-mandated turn-based delivery for specified service sets (often those exposed via CapRPC).  
Evidence: reduction in reentrancy/ordering hazards; easier deterministic replay/logging (D-RR); improved reasoning/verification tractability; measurable overhead vs threaded runtimes and ability to shard explicitly when needed.
See: RFC-0078; interacts with RFC-0026 (CapRPC).

## D-REQCTX: request contexts (deadlines + cancellation + trace correlation) (optional)
Options: ad hoc per-interface params (default); standard request-context conventions + CH-REQCTX descriptors; integrate into CapRPC framing (CH-CAPRPC v1 `ctx_digest`) for correlation.

Evidence: reduction in orphan work and shutdown complexity (avoid timeout soup); deterministic cancel/timeout outcomes that are replay/log-friendly; ability to keep context **non-authoritative** and bounded (no covert “baggage” store); adoption ergonomics in stub generators and supervisors.
See: RFC-0105.

Note: CH-REQCTX v1 includes optional untyped digest lists (`budget_desc_digests`, `tcap_desc_digests`) for audit/deny-only correlation. When a consumer treats `budget_desc_digests` as required sponsorship (e.g., `capshell.exec` under `cfg.params.capshell.require_budget_lease=true`), interpretation is pinned as type-strict and non-ambient (no locator deref): see `reqctx-budget-ref-posture-v0.md`. Likewise, if any consumer treats `tcap_desc_digests` as required temporal sponsorship, it MUST be type-strict and non-ambient: see `reqctx-tcap-ref-posture-v0.md`.

## D-BRACKET: privilege bracketing + call-chain contexts (optional)
Options: none (default); user-space runtime convention that makes **privileged capabilities** inaccessible by default when servicing inbound requests (borrowed mode), unless code explicitly enters a scoped privileged block; optionally attach a bounded CH-CALLCHAIN digest in CH-REQCTX v1 for audit/deny-only routing.
Evidence: whether the pattern materially reduces in-process confused-deputy incidents in plugin/helper ecosystems; ability to keep the mechanism **veto-only** (never grants authority), exception-safe (no privilege leakage), and adoptable in real codebases without growing the privileged core.
See: RFC-0118.

## D-QUIESCE: quiescence + drain protocol for maintenance operations (optional)
Options:
- ad hoc stop semantics/signals per service (default)
- cooperative quiesce + drain/cancel protocol (recommended seam)
- stop-the-world freezer as the primary maintenance primitive (avoid early)

Evidence: ability to shut down and upgrade services under load without orphan work; ability to obtain a consistent cut for checkpoint/restore; bounded and deterministic outcomes (no silent background work after cancel); composability with D-REQCTX (deadlines), D-SUPV (escalation), D-ACTIVATE (continuity), and D-CHKPT (capture).
See: RFC-0108.



## D-WAITSET: wait sets + object signals for scalable event loops (optional)
Options:
- wait_many only (baseline; O(n) scan)
- wait_many + WaitSet (epoll/kqueue/IOCP/Zircon ports–style) (recommended)
- programmable filters (avoid early)

Evidence: scalability of event-driven servers and driver loops; ability to keep the API bounded and deterministic; interaction with D-REQCTX cancellation and D-NONDET clock/timeout posture; assurance that waiting cannot amplify authority (I-WAITSET-1).
See: RFC-0106.


## D-UWAIT: wait-on-address (futex) primitives for userspace synchronization (optional)
Options:
- none (spin/poll or heavy kernel objects)
- process-local wait-on-address (WaitOnAddress/Zircon futex style) (recommended seam)
- cross-process wait-on-address for explicitly shared regions (defer until justified)
- add PI/owner variants (defer; expands scheduler coupling)

Evidence: reduce CPU waste and watchdog false positives from spinning; enable pthread/runtime compatibility without per-lock kernel objects; bounded and attributable waiter state avoids DoS; interacts cleanly with D-REQCTX (timeouts/cancel) and D-RR (replay determinism).
See: RFC-0110.


## D-ROBUSTLOCK: robust locks + owner-death semantics for shared synchronization (optional)
Options:
- none (timeouts / supervision-only recovery)
- robust sets + OWNER_DIED flag for shared user-space lock words (recommended seam)
- kernel-managed lock objects (reject; expands TCB and policy surface)

Evidence: prevent permanent deadlock when an owner terminates while holding a shared lock; make “protected state may be inconsistent” explicit to the next acquirer; must be bounded/charged (D-METER) and non-amplifying (cannot register addresses outside writable/shared regions); integrates with D-UWAIT and deterministic replay (D-RR).
See: RFC-0111.


## D-RCU: grace periods + deferred reclamation for read-mostly shared state (optional)
Options:
- none (locks/refcounts only)
- user-space GraceDomain service/library (QSBR/EBR/RCU patterns) (recommended seam)
- kernel-assisted participant tracking (avoid unless required; expands TCB)

Evidence: whether we can make read-mostly shared state fast for readers without importing a large kernel policy surface; bounded limbo/deferred-free growth under stalls; clean integration with D-UWAIT/D-WAITSET for blocking waits; determinism hooks for D-RR profiles.
See: RFC-0112.


## D-RSEQ: restartable sequences + CPU-local fast paths (optional)
Options:
- none (atomics/locks only)
- user-mode rseq regions + per-thread cpu-id cache (Linux rseq lineage) (recommended seam)
- kernel-managed per-CPU objects (reject; expands TCB/policy surface)

Evidence: whether we need a kernel-assisted primitive for *bounded* “CPU-local fast paths” (per-CPU allocators/counters/queues) without turning every operation into a syscall; interaction with D-SCHED migration and D-NONDET posture (CPU-id as a potential oracle); profile gating for D-RR determinism.

See: RFC-0113.


## D-IOQ: I/O submission queues + completion events (optional)
Options:
- none (per-op IPC/syscalls)
- bounded IoQueue object (shared rings + doorbell; io_uring/I/O rings shape) (recommended seam)
- rich programmable I/O language (avoid early)

Evidence: whether batching reduces boundary-crossing overhead for I/O-heavy services and drivers without expanding the privileged core; clean integration with D-WAITSET signals; preservation of capability discipline (targets are explicit handles); bounded rings and deterministic overflow behavior.
See: RFC-0107.


## D-SEAL: initialization→sealed steady-state posture (capability attenuation)
Options: none (default); voluntary init→seal discipline in key services; profile-mandated seal for selected components.  
Concrete mechanisms (stackable):
- **capability attenuation**: drop capabilities and revoke introducers after init (baseline).
- **promise masks** (optional): install a one-way allowlist of effect families the domain may invoke (CH-PLEDGE v0).
- **namespace narrowing** (optional): "unveil"-style reduction by sealing/removing subtrees from view objects (D-NS).
- **capability mode** (optional): forbid any ambient/global acquisition after init (D-CAPMODE).

Evidence: (1) monotonicity (cannot widen post-seal); (2) enforcement at every privileged-effect boundary (no bypass fast paths); (3) ergonomics/uptake in large services and compat shims; (4) similarity to pledge/unveil patterns while keeping "handles not paths."


## D-DYNCODE: dynamic code loading + executable memory policy (W^X / execmod) (optional)
Options:
- sealed code spaces (no dynamic native modules; exec mappings bound to sealed artifacts)
- capability-gated “execmod” (RW→RX flips and non-sealed exec mappings require explicit authority)
- permissive baseline (compat-first; not recommended for tight provenance)

Evidence: (1) W^X enforcement (no RWX); (2) “execmod” gating is non-bypassable at the KABI; (3) profile feasibility for JIT-heavy apps (broker/dual-map patterns); (4) supply-chain / attestation clarity when executable pages are digest-bound (D-ATOMICUPD).  
See RFC-0059 for the detailed posture and evidence plan.


## D-VERITY: verified blobs + Merkle integrity for immutable content (optional)
Options:
- none (default)
- file-level verified blobs (fs-verity-style; VerifiedBlob objects)
- volume-level verified roots (dm-verity-style; verity-protected read-only volumes)
- hybrid (volumes for base OS; VerifiedBlob for packages/app artifacts)

Evidence: whether we can make “immutable bytes stay immutable” mechanically checkable without inflating the privileged core: fail-closed verified reads, digest identity that composes with CH-AREF/CH-UPD/CH-BOOT provenance, bounded verification caches (D-METER), and clear diagnostics for integrity failures.
See: RFC-0114.


## D-CAPMODE: ambient authority elimination (capability mode) (optional)
Options: none (default); per-process “capability mode” that forbids authority acquisition from ambient namespaces; system-wide “no ambient acquire” profile.
Evidence: ability to enforce “no new authority from globals” without bloating IF-KABI; alignment with views (I-VIEW-1/I-VIEW-2) and seal patterns (D-SEAL); ease of mechanical justification.

## D-TRANS: user-space translators / stackable filesystem servers (optional)
Options: none (default); “translator” servers attachable to view nodes (per-path or per-directory); a constrained set of standard translators (net, proc, auth, vfs adapters) as profiles.  
Evidence: whether extensibility can live in user space without reintroducing ambient authority; ability to keep resolution inside view objects (I-VIEW-1/I-VIEW-2) and keep translator attachment an explicit, auditable action (CH-LOG binding), similar to GNU Hurd “translators”.

## D-ATTRFS: filesystem attributes + query as a first-class primitive (optional)
Options: no special metadata (default); xattr-style key/value attributes only; indexed attributes + query language (BeOS/Haiku BFS style) scoped by views.  
Evidence: whether attribute indexing/query improves UX and auditability without becoming a covert channel or integrity hole; ability to bound attribute schema (CH-ATTR) and query predicates (CH-ATTRQ) and ensure access checks are capability-mediated (I-VIEW-2).

## D-PERSIST: orthogonal persistence + capability store (optional)
See: RFC-0065 (CH-CAPSTORE v0).
Options: mutable filesystem only; snapshotting CoW filesystem service; **CapStore** with named durable roots; broader “orthogonal persistence” profile (KeyKOS/EROS style) implemented as a user-space store.  
Evidence: whether durability can remain **explicit authority** (no ambient persistence), restore is non-amplifying (I-PERSIST-2), and rollback/resurrection is detectable and policy-gated (I-PERSIST-3).


## D-ATOMICUPD: atomic system image updates + rollback (optional)
Options: traditional package mutation (avoid for base); A/B partitions with bounded tries + health-commit (CH-BOOTSEL); immutable deployments with content-addressed trees (OSTree/rpm-ostree style) plus per-deployment provenance binding (CH-PROV/CH-BOOT).
Evidence: whether atomic rollback meaningfully reduces update failure modes and supports our evidence linkage (prov digest ↔ deployment digest) without bloating trusted boot logic; and (if profiles require it) whether **mutable data rollback hazards** are made explicit via CH-CFG `data_contracts` + snapshot barriers (RFC-0097) rather than hidden footguns.



## D-TUF: survivable update repository metadata (optional)
Options: none (direct CH-UPD fetch + signatures only); TUF baseline (root/targets/snapshot/timestamp); fleet extension (Uptane director split).
Evidence: resistance to rollback/freeze/mix-and-match; operational feasibility of key rotation and compromise recovery without bricking fleets; integration with D-ATOMICUPD/D-TLOG while keeping privileged boot agnostic.
See: RFC-0079.

## D-UPTANE: fleet-grade update distribution extensions (optional)
Options: none (default); Uptane-style director split layered on D-TUF for multi-ECU/fleet management scenarios.
Evidence: whether the additional roles/infrastructure reduce real fleet risk (replay/rollback and compromise blast radius) enough to justify operational complexity; ability to keep the privileged boot path agnostic and keep failure modes fail-closed.
Note: D-UPTANE is a **profile extension**; D-TUF remains the baseline decision node.
See: RFC-0079 and `docs/60-engineering/update-repository-metadata-and-key-rotation.md`.


## D-HEALTH: explicit health predicate + boot-success commit (optional)
Options: implicit success (avoid); time-only heuristic (weak); **pinned health predicate artifact (CH-HEALTH) + capability-gated commit**, with audit evidence (CH-HEALTHREC) and optional readiness barrier integration (CH-COMP `ready`).
Evidence: whether we can make “boot success” non-ambiguous, spoof-resistant, and transcript-visible to support A/B rollback semantics (CH-BOOTSEL) and structured recovery (D-SUPV) without importing a scripting VM or large policy engine.
See: RFC-0074 (health predicates + boot-success commit), RFC-0051 (atomic updates), RFC-0017 (supervision).

## D-RECOVERY: recovery mode + rescue environment (optional)
Options: none (default); manual recovery target (boot menu / physical presence); manual + bounded trial-boot loop via CH-BOOTSEL pending; auto-enter recovery after repeated failures (defer until evidence justifies extra selector state).
Evidence: whether we can keep a recovery environment bootable independent of the normal stack, provenance-bound like any other deployment, and fail-closed on entry (physical presence) while avoiding a hidden privileged admin shell.
See: RFC-0098.

## D-FPM: functional build graphs + content-addressed store (optional)
Options: conventional package mutation; semi-immutable base image + mutable apps; functional package management (Nix/Guix-like) where build outputs are addressed by their inputs and system configuration composes a verifiable closure.
Evidence: reproducibility and rollback ergonomics; how easily we can bind derivations/closures into provenance (CH-PROV) and atomic deployments (D-ATOMICUPD) without bloating IF-BOOT; storage overhead and GC; ability to keep “install” effects as explicit, reviewable actions (CH-KABI/CH-ACP).

## D-SBOM: SBOM artifacts and closure binding (optional)
Options: none (default); publish normalized CH-SBOM only; attach full external SBOM documents (SPDX/CycloneDX) via CH-AREF; attach VEX exploitability statements as a separate CH-VEX artifact (or link to external VEX docs via CH-AREF).
Evidence: ability to bind SBOMs to the exact deployed root/component digest (avoid drift), keep exports bounded/policy-scoped (CH-OBSPOL), and integrate with provenance/transparency logs without expanding IF-BOOT.
See: RFC-0091.

## D-VEX: vulnerability exploitability statements (optional)
Options: none (default); publish normalized CH-VEX only; attach full external VEX documents (OpenVEX/CSAF/CycloneDX) via CH-AREF; optionally link to a CH-SBOM digest for component context.
Evidence: ability to reduce vulnerability-scanner noise with digest-bound, reviewable statements (avoid drift), while keeping exports bounded/policy-scoped (CH-OBSPOL) and avoiding “VEX as authority” in the privileged core.
See: RFC-0092.

## D-BOOTSTRAP: bootstrappable toolchains + minimal trust seed (optional)
Options: conventional bootstrap binaries (default); reduced binary seed (Guix/Mes-style); “stage0” style minimal chain; full-source bootstrap target.  
Evidence: whether we can keep the seed set small and explicitly listed; ability to bind seed/toolchain digests into CH-PROV and keep release profiles honest without bloating IF-BOOT.  
See: RFC-0061.

## D-DDC: diverse double-compiling as a compiler-trust mitigation (optional)
Options: none (default); DDC gate for the compiler used to build trusted artifacts; broader DDC gates for the release toolchain.  
Evidence: determinism and bit-for-bit matching under the chosen reproducibility posture; ability to make failures explainable and bind outcomes into provenance (CH-PROV) without expanding runtime TCB.  
See: RFC-0061.

## D-POWERBOX: consent mediators / powerbox UX (optional)
Options: none (default); user-space powerbox service (IF-CONSENT) issuing CH-AUTHZ approvals; integrate with ACP (IF-ACP) for high-risk actions.
Evidence: whether UX-mediated grants reduce capability confusion without importing UI/agent complexity into the privileged core; ability to bind human consent to action digests (I-CONSENT-1).

## D-VOLITION: trusted UI path + volition tokens (optional)
Options: none (default); user-space UI root emits CH-VOL “volition tokens” bound to a rendered action-summary digest; integrate with IF-CONSENT so approvals require a fresh volition token.
Evidence: whether we can prevent UI spoofing/clickjacking style confused-deputy approvals while keeping UI complexity out of the privileged core; ability to bind consent to a user gesture and to an action digest (I-VOLITION-1, I-CONSENT-1) with fail-closed validation.

## D-UICAP: capability-mediated UI compositor + secure attention (optional)
Options: no pinned UI contract (default); user-space compositor/UI root that mediates **surfaces + input** as object-capabilities; focus-gated input delivery; screenshot/screencast/remote-control only via portal workflows (D-PLUMB) and ideally lease-based (D-LEASE). Optional secure attention sequence (SAS) to enter a “secure UI mode” for login/high-risk consent.

Evidence: whether we can make UI isolation usable without ambient global window state: (a) surface isolation (no screen scrape), (b) focus-gated input (no global keylogging), (c) portal-mediated high-risk UI authority with clear receipts; and whether SAS can be delivered in a non-interceptable way without expanding the kernel TCB.

v0 scope posture is pinned in `docs/30-architecture/uicap-scope-posture-v0.md` (resolves OQ-0004).

See: RFC-0080.

## D-UIAUT: accessibility/automation sessions (optional)
Options: none (default); observation-only accessibility sessions; injection-capable sessions (higher-risk); dev/test-only automation; remote-control automation via portals with strict leases.
Evidence: whether we can support assistive tooling and UI automation without reintroducing ambient global hooks: (a) no ambient UI tree/text readback, (b) injection/remote control only via explicit portal grants with TTLs and indicators, (c) focus-chain and UI structure disclosure treated as sensitive metadata.
See: RFC-0099.


## D-CAPTURE: portal-mediated media capture sessions (optional)
Options: none (default); user-space capture portal that mediates camera/microphone/screencast/remote-desktop sessions as explicit, attributable **leases** and emits CH-CAPTURE descriptors for audit/receipts.

Evidence: whether we can eliminate ambient capture paths (audio-server sockets, global screen readback), enforce TTL/renew/escalation via portal mediation, and require user-visible indicators without expanding the privileged core.

See: RFC-0095.

## D-EXPLAIN: authority diffs + consent receipts (optional)
Options: none (default); require “authority diff” previews for any grant that adds authority; emit CH-RECEIPT records bound to action + shown diff/summary + result.
Preferred diff structure: CH-CAPDIFF v0 (see RFC-0069).
Adjunct (validator-facing, UI-optional): emit **CH-DENY v0** records for deterministic validator rejections (policy/lane/ordering/schema), bound from CH-LOG via `deny_digest`, so “killable by policy” and fail-closed workflows remain mechanically auditable without treating rejections as approvals. `deny_code` values are closed-world per `deny-code-registry.md`.
Evidence: whether diff+receipt reduces confused-deputy and “grant creep” without spamming the user; ability to make the shown diff a deterministic function of the approved action + relevant state (I-EXPLAIN-1) and to bind receipts to reality (I-EXPLAIN-2) while keeping receipts non-authoritative (I-EXPLAIN-3).

## D-LEASE: capability leases + limited-use proxies (optional)
Options: none (default); or standardize **time-limited / use-limited** capability proxies as a user-space pattern for “temporary authority”.

If enabled: portals/gateways SHOULD default to issuing **leased proxy capabilities** (not raw caps) when crossing trust boundaries or when UX expects “temporary share” semantics. Leases are implemented in user space using membranes/forwarders (D-MEMBRANE) plus optional Clock handles (D-NONDET) for time-based expiry.

Impacts:
- Adds **CH-CAPLEASE v0** (redaction-safe descriptor; no secrets) for audit/consent receipts.
- Adds invariants I-LEASE-1..3, proof obligations PO-LEASE-VALIDATE/ENF/NOAMP, and abuse case AC-055.
- Composes naturally with D-PLUMB (portal grants), D-EXPLAIN (authority diffs), D-CAPX (imported tokens), and D-PERSIST (non-durable-by-default).

See: RFC-0066.

## D-NETLEASE: outbound network leases via a portal (optional)
Option: keep outbound networking ambient (not recommended); or make outbound network authority **explicit and lease-based**.

If enabled: components obtain outbound networking only via a network portal (`portal.net`) that returns scoped `NetDialer`/`NetListener` capabilities with a redaction-safe **CH-NETLEASE** descriptor. This composes with D-PLUMB (workflow routing), D-EXPLAIN (authority diffs + receipts), and D-ATTN (optional prompts/notifications).

If enabled, expose the **lease request seam** as an ACP kind (`portal.net.request`) so **LLMs propose; deterministic validators execute** and receipts/transcripts remain the stable product surface. ACP proposals bind `netreq_digest = digest(CH-NETREQ v0)` (bounded request descriptor); the portal returns **CH-NETLEASE v0** (bounds receipt) and an opaque network authority handle.

Impacts:
- Adds CH-NETREQ v0 (bounded request descriptor) and CH-NETLEASE v0 (bounds descriptor), plus optional invariants I-NETLEASE-1..3.
- Adds proof obligations PO-NETLEASE-VALIDATE/ENFORCE/DNSBIND and abuse case AC-047.
- Strengthens D-QUAR safe-open: disposables start with no network lease by default.

See: RFC-0056.

## D-LOCLEASE: location leases via a portal (optional)
Options: keep location ambient (not recommended); or make location authority **explicit and lease-based** via a location portal.

If enabled: components obtain location only via a location portal (`portal.location`) that returns scoped location capabilities with a redaction-safe **CH-LOCLEASE** descriptor. Policy can clamp **coarse vs precise**, enforce TTL/cadence, and gate background tracking; continuous tracking should imply shell-driven indicators.

Impacts:
- Adds CH-LOCLEASE v0 (bounds descriptor; no coordinates).
- Adds invariants I-LOCLEASE-1..3, proof obligations PO-LOCLEASE-VALIDATE/PO-LOCLEASE-ENF, and abuse case AC-086.
- Should not imply networking; if providers require network lookups, that authority remains inside the portal/service (composes with D-NETLEASE).

See: RFC-0101.


## D-ATTN: attention authority + notifications (optional)
Options: none (default); notification portal (`portal.attn.*`) with origin branding + explicit lane kill switch (`cfg.params.lane.portal.attn`), using CH-NOTIF v0 as the bounded request seam; notification channels + per-app budgets; “attention leases” for urgent/critical alerts requiring explicit consent.
If enabled, expose the attention request seam as an ACP kind (`portal.attn.request`) so **LLMs propose; deterministic validators execute** and receipts/transcripts remain the stable product surface.
Evidence: whether we can bound notification spam/phishing, make notification origin unspoofable, and ensure notification actions require fresh volition (D-VOLITION) and show authority diffs (D-EXPLAIN) when they grant new authority; interaction with D-QUAR safe-open flows and D-EPHEM disposables.
See: RFC-0055.

v0 stance: do **not** introduce a dedicated attention-lease descriptor; treat urgency as a policy-gated CH-NOTIF `importance` hint (see `docs/30-architecture/attention-lease-posture-v0.md`).

## D-PLUMB: workflow router + portals (optional)
Options: none (default); user-space workflow router that mediates open/save/share/clipboard/drag-drop via portal sessions, a pinned CH-PLUMBMSG envelope for intent messages (canonical `intent.kind` taxonomy pinned in `intent-kind-registry.md`), and CH-ROUTE deterministic routing rules; optional CH-XFER v0 transfer descriptors for auditable transfer grants (RFC-0094); integrate with D-POWERBOX and D-VOLITION for user-mediated grants that return capabilities (not paths); optional document portal providing durable handles (CH-DOCREF) for “recent documents” without ambient paths (RFC-0089).
Evidence: whether explicit routing + portal handles reduce ambient authority and confused-deputy flows; ability to audit grants/denials; ability to keep the privileged core agnostic while supporting a rich desktop/workflow ecosystem.
Profile defaults: recommended `cfg.params.lane.portal.*` defaults for A–D are pinned (non-authoritatively) in `profile-lane-defaults.md` to keep “no forks” honest and keep default posture reviewable.

## D-CAPSHELL: capability-safe shell + automation components (optional)
Options: none (default); wrapper-first runner (Plash/Capsicum style) with learn-mode; integrated capshell (interactive + automation) with capability wallets and explicit effect contracts.
Evidence: whether we can eliminate ambient authority in “glue” workflows (shell scripts, cron, CI, admin runbooks) while keeping adoption cheap (learn mode, deterministic violations) and preserving capability discipline (views/portals/sealing).
If enabled:
- standardize **CH-EFFCON v0** as the *veto-only* effect contract descriptor bound to a CH-WALLET core digest (no bearer secrets; no ambient paths/env as permissions).
- standardize **CH-ARGV v0** as the typed argv token list for automation execution, so workflows bind to already-held descriptor digests rather than ambient host paths/env; executable selection is **explicit and unique**: validators require exactly one `role="exec"` selector and runners never consult an ambient PATH (see `capshell-exec-selector-posture-v0.md`).
- standardize **CH-ENV v0** as the typed environment token list for automation execution, so workflow runners do not inherit ambient environments and descriptor references bind to already-held handles.
- standardize **CH-CWD v0** as the typed working-directory selector for automation execution, so workflow runners do not inherit ambient host cwd and directory bindings are explicit and handle-based.
- standardize **CH-STDIO v0** as typed stdio bindings for automation execution, so workflow runners do not inherit ambient host stdio/TTY state and all stream bindings are explicit and handle-based.
- standardize **CH-FDSET v0** as typed extra child-handle bindings for automation execution (slots >= 3), so workflow runners do not inherit an ambient host handle/FD table and all extra bindings are explicit and handle-based.
- standardize **CH-EXECPACK v2** as the capshell *execution pack* completeness seal: `capshell.exec` binds the complete execution context (CH-EFFCON/ARGV/ENV/CWD/STDIO/FDSET) plus `reqctx_digest = digest(CH-REQCTX v1)` and optional `plumbmsg_digest = digest(CH-PLUMBMSG v0)` for an explicit, non-authoritative workflow intent envelope, preventing ambient workflow context and implicit correlation/intent drift.
- add an optional runner surface **IF-CAPSHELL** that executes steps only when an explicit CH-EFFCON is present and validated.
- expose automation execution as a CH-ACP kind (e.g., `capshell.exec`) so **LLMs propose; validators execute** and receipts/transcripts remain the stable product surface.
- standardize **CH-ACPOUT v0** as a non-authoritative ACP outcome receipt (digest-only) so accept/reject outcomes are schema-pinned and tooling does not drift into ad-hoc strings.
- keep the lane policy-killable via `cfg.params.lane.capshell` (see `config-toggle-registry.md`); when disabled, dependent actions must reject deterministically and be transcript-visible (PO-LANE-KILL).
- optionally tighten workflow ambient-authority posture via `cfg.params.capshell.minimal_context` (veto-only): when true, `capshell.exec` requires a minimal execution context (empty CH-ENV, CH-CWD `kind="empty"`, CH-STDIO `(null, drop, drop)`, empty CH-FDSET). Recommended per-profile defaults are pinned in `profile-workflow-defaults.md` (no forks).
- optionally tighten explicit workflow-intent posture via `cfg.params.capshell.require_plumbmsg` (veto-only): when true, `capshell.exec` requires CH-EXECPACK v2 to include `plumbmsg_digest = digest(CH-PLUMBMSG v0)` and validators must validate CH-PLUMBMSG before any effect. Missing intent envelopes fail closed and are transcript-visible (recommended CH-DENY code: `plumbmsg-missing`). Recommended per-profile defaults are pinned in `profile-workflow-defaults.md` (no forks).
- optionally tighten “explicit sponsorship” posture via `cfg.params.capshell.require_budget_lease` (veto-only): when true **and** `cfg.params.lane.metering=true`, `capshell.exec` requires the bound CH-REQCTX v1 to include at least one CH-BUDGET v0 lease digest (resolved + validated) so automation never runs on implicit sponsorship (D-BUDGET; I-BUDGET-1). Recommended per-profile defaults are pinned in `profile-workflow-defaults.md` (no forks).
See: RFC-0115.

## D-WALLET: capability wallet descriptors for drift gates (optional)
Options: none (default); user-space runners/portals emit **CH-WALLET v0** descriptors as non-authoritative summaries of active authority; tools use wallet digests for prompts, receipts, and CI drift gates.
Evidence: whether we can make "what authority is active" cheap to inspect and "authority widening" cheap to reject **without** adding privileged mechanisms: closed-world inventories, strict bounds, stable authority digests, and clean composition with D-EXPLAIN (CH-CAPDIFF) and one-way tightening (D-SEAL/D-CAPMODE).
See: RFC-0116.

## D-EPHEM: disposable domains / one-shot sandboxes (optional)
Options: none (default); disposable process domains; disposable microVM domains (D-MICROVM); disposable partition cells (D-PART).
Evidence: whether disposables materially reduce real-world compromise persistence and improve UX for risky tasks without expanding the privileged core; ability to make exports explicit via portals (D-PLUMB) and keep disposal/teardown deterministic and auditable.

## D-QUAR: origin metadata + quarantine + safe-open defaults (optional)
Options: none (default); origin/quarantine tags only; tags + safe-open routing; tags + safe-open + sanitizing exports.
Evidence: whether monotonic tagging + default-to-disposable materially reduces compromise persistence; bypass resistance for extraction/container formats; ability to keep clearing explicit and transcript-logged.

## D-WASM: Wasm components as the default extension runtime (optional)
Options: native-only; Wasm for plugins/tools (default); Wasm-first user space; mixed runtime targets.
Evidence: confinement/TCO of the runtime under IF-SBX; interface typing + import closure auditing; performance; cross-ISA portability; alignment with D-CAPMODE/D-PLUMB and D-FPM supply-chain posture.

## D-IDL: interface definition + code generation (optional)
Options: handwritten marshalling (avoid); minimal IDL that generates stubs/validators; reuse an existing IDL (e.g., CAmkES-style, WIT-like, Cap’n Proto) while keeping CH-* schemas canonical.
Evidence: whether codegen shrinks `unsafe` and improves traceability (I-UNSAFE-1), keeps IF-KABI small (D-KABI/D-XS), and reduces drift between spec and implementation.
If enabled: require canonical `idl_digest` computation and stable method ordinals (CH-ORD) where CapRPC is used (RFC-0072).

## D-METER: resource accounting + denial-of-service controls (optional)
Options: none (default); meter/quota objects in the core; delegated accounting in userland.  
If enabled: treat **meters** as capability-shaped budget containers that can be split attenuation-only; any resource-creating privileged effect must name an explicit **payer** (a meter) and transcript-log a redaction-safe **CH-METER v0** descriptor digest.
Evidence: whether the mechanism can stay small while enabling bounded resource consumption, clear payer attribution (avoid confused-deputy billing), and deterministic fail-closed exhaustion.


## D-KOBJQ: kernel object quotas (cap slots/endpoints) (optional)
Options: none (default); cap-slot quotas only; cap-slot + endpoint/object quotas (Genode-style).  
Evidence: whether we can prevent kernel resource exhaustion with a small mechanism (charged to meters) without enlarging IF-KABI/IF-OBS significantly.

## D-BUDGET: operation-scoped budget leases (optional)
Options: none (default); explicit budget handles required for metered effects; portal-issued budgets (common) + ad-hoc budgets (advanced).  
Evidence: whether explicit “who pays?” tokens reduce confused-deputy billing and make resource use auditable without harming ergonomics (especially for portal workflows).
See: RFC-0058 (CH-BUDGET v0; I-BUDGET-1..3; PO-BUDGET-VALIDATE/PO-BUDGET-CHARGE/PO-BUDGET-NOIMPLICIT).

## D-PRESSURE: resource pressure + backpressure signals (optional)
Options: none (default); coarse per-container pressure levels; PSI-like stall-time signals (scoped + rate-limited).  
Evidence: whether a small, scoped observability primitive enables robust load-shedding/latency control in user space without becoming a cross-domain oracle.
See: RFC-0057 (CH-PRESSURE v0; I-PRESSURE-1..3; PO-PRESSURE-VALIDATE/PO-PRESSURE-SCOPE/PO-PRESSURE-RATELIMIT).

## D-JOBS: constraint-based background work via a job portal (optional)
Options: none (default); user-space job portal for deferrable work; optional periodic profiles; optional durability under D-PERSIST.
Evidence: whether we can eliminate ambient cron/alarms, coalesce background work for power/latency, and enforce bounded runtime (wall time + optional TCaps) without growing the privileged core.
See: RFC-0096 (CH-JOBREQ v0).
If enabled: expose job submission as an ACP kind `portal.jobs.submit` so **LLMs propose; validators execute** and outcomes are transcript-visible (CH-ACPOUT/CH-DENY); keep the lane policy-killable via `cfg.params.lane.portal.jobs` (PO-LANE-KILL; PO-ACP-JOBS-SUBMIT).

## D-BGLEASE: background execution + login autostart as leased authority (optional)
Options: none (default); background portal for background execution only; background + autostart grants with periodic review; strict profiles deny-by-default with volition for long-lived grants.
Evidence: whether we can eliminate ambient daemons/autostart registries, enforce TTL/renewal clamps, provide user-visible indicators, and compose cleanly with D-JOBS and other portalized authorities (no implicit net/file/device/location).
See: RFC-0103 (CH-BGREQ v0, CH-BGLEASE v0; I-BGREQ-1; I-BGLEASE-1..3; PO-BGREQ-VALIDATE/PO-BGLEASE-VALIDATE/PO-BGLEASE-ENF; AC-088).
If enabled: expose background grant requests as an ACP kind `portal.background.request` so **LLMs propose; validators execute** and outcomes are transcript-visible (CH-ACPOUT/CH-DENY); bind `bgreq_digest = digest(CH-BGREQ v0)` and keep the seam policy-killable via `cfg.params.lane.portal.background` (PO-LANE-KILL; PO-ACP-BGLEASE-REQUEST).


## D-INHIBITLEASE: inhibit leases for idle/suspend/logout/shutdown via a portal (optional)
Options: none (default); user-space inhibit portal issuing leased inhibition handles (delay-by-default); privileged block inhibits for system components under policy; optional monitor session for transition state updates.
Evidence: whether we can eliminate ambient keep-awake APIs, clamp TTL/renewal, and make long-lived inhibits visible and auditable without embedding power policy in the privileged core.
See: RFC-0102 (CH-INHIBITLEASE v0; I-INHIBIT-1..3; PO-INHIBIT-VALIDATE/PO-INHIBIT-ENF; AC-087).

## D-CAPAUD: capability graph export for audit/debug (optional)
Options: none (default); debug-only; policy-gated export via IF-OBS (CH-CAPG).  
Evidence: usefulness for leak detection and audits versus side-channel risk; ability to keep exports bounded and redacted.

## D-TCAP: temporal capabilities (time/CPU as explicit authority) (optional)
Options: none (default); temporal capabilities (TCaps) for CPU budgets/periods/priority; TCaps integrated with D-METER accounting.  
See RFC-0049 for the scheduling-context + time-donation design seam.
Evidence: ability to model and enforce time/CPU authority deterministically in early phases; whether it shrinks scheduling policy in the core while remaining mechanistic.

## D-IOBUF: copyless I/O buffer objects (optional)
Options: bounded-copy IPC only (default); immutable shared buffer objects; IO-Lite style unified buffering with explicit sharing.  
Evidence: performance vs proof/TCB cost; ability to maintain “no hidden sharing” and stable ownership semantics.
See: RFC-0084.

## D-SKB: system knowledge base / hardware facts posture (optional)
Options: none (default); user-space SKB consuming CH-HWFACT; optional CH-HWEVENT event log for post-boot fact evolution (hotplug/link state); richer query engine (CLP/Datalog) in user space; named-query IDL surface for a small set of stable queries.
Evidence: whether pushing hardware discovery/selection logic out of the privileged core shrinks TCB while keeping decisions deterministic and auditable (bind CH-HWFACT digest in CH-BOOT; bind hotplug decisions to `{epoch,event_seq}` when enabled).
Notes: with D-DEVGUARD, treat hotplug notifications as fact-evolution events (CH-HWEVENT) so attach/detach policy remains transcript-visible and race-resistant; never treat device names/paths as authority.


## D-RR: deterministic record/replay substrate (optional)
Options: none; transcript-only replay for privileged actions; broader replay profiles with explicit nondeterminism providers (D-NONDET); full system replay for targeted profiles.  
Evidence: ability to make state evolution auditable and reproducible; hardware nondeterminism constraints; value for debugging/evidence **and** incident handoff.
Notes: treat *time-travel debugging* as a user-space ecosystem layer over CH-KABI/CH-LOG/CH-RR; optional D-CHKPT accelerates reverse queries. See RFC-0013 and `docs/60-engineering/diagnostics-stack.md`.
Additional wiring: when CH-LOG entries carry `deny_digest` (CH-DENY v0), replay/audit bundles (CH-RRBUNDLE) SHOULD include the referenced denial records (deny_stream) or explicitly declare a redaction profile that omits them (PO-RR-BUNDLE-CLOSURE).

## D-NONDET: nondeterminism authority (clock + entropy handles) (optional)
Options: ambient POSIX-like time/RNG APIs (avoid); explicit Clock/Entropy handles issued by `portal.clock`/`portal.entropy` portals (or host shims); deterministic providers for test/replay.
Evidence: ability to eliminate ambient time/entropy acquisition (I-NONDET-1), keep high-resolution timing as explicit authority (I-NONDET-2), and bind clock/entropy reads to CH-RR in replay profiles (I-NONDET-4).
See: RFC-0063 (CH-CLOCK v0, CH-ENTROPY v0).

ACP/portal seam (optional, but preferred when D-NONDET is enabled):
- Entropy handles/leases are obtained only via ACP kind `portal.entropy.request` binding `entreq_digest = digest(CH-ENTREQ v0)` (no ambient RNG constructors; lane kill switch `cfg.params.lane.portal.entropy`; PO-ACP-ENTROPY-REQUEST; I-NONDET-1).
- Clock/timeproof sampling is obtained via `portal.clock.timeproof.sample` binding `timereq_digest = digest(CH-TIMEREQ v0)` (no ambient NTP; lane kill switches `cfg.params.lane.portal.clock` + `cfg.params.lane.timeproof`).


## D-CHKPT: checkpoint/restore + migration substrate (optional)
Options: none; cooperative checkpoints (quiesce + explicit state export/import); limited checkpoints for Wasm components only; transparent user-space C/R via runtime interception (avoid for MVP).  
Evidence: ability to support debugging, fast reboot, and live upgrade/migration without violating capability invariants (no authority amplification), while keeping secret handling explicit and restore semantics bounded.

## D-UPCALL: kernel→user upcall interface for scheduling (optional)
Options: none; scheduler-activations style upcalls; event-driven vCPU model only.  
Evidence: whether upcalls reduce kernel scheduling policy while preserving isolation guarantees and not exploding concurrency proofs.

## D-CONSTR: constructor/confinement mechanism for building components (optional)
Options: none; EROS/KeyKOS-style constructor objects + confinement test; limited “service templates” only.  
Evidence: whether it shrinks authority at component boundaries, improves auditability, and stays expressible in the abstract machine. See RFC-0042.

## D-MEMMODEL: memory model stance (SMP/Hybrid baseline)
Options:
- small, explicit primitive set for privileged code (e.g., single-copy atomic + acquire/release + fences); forbid ad-hoc atomics
- stronger ordering for simplicity (at explicit performance cost)
- architecture-specific axioms with a pinned litmus suite per target ISA

Evidence: existence of tractable model checks/litmus suites (PO-MEM-LITMUS); ability to link concrete atomic/fence patterns to invariants and to D-COMMUTE conflict-key/ordering boundaries under multicore execution (I-CONC-1).

## D-DMA: DMA model
Options: IOMMU-required; devices-in-TCB; constrained I/O (no DMA).  
Evidence: threat-model requirements; hardware availability; ability to make C-ISO-2 either provable or explicitly weakened.

## D-ADDRNET: address translation synthesis posture (optional)
Options: ad-hoc platform code (avoid); CH-ADDRNET + generator/checker pipeline; mechanized refinement later.  
Evidence: whether we can treat page-table/IOMMU setup as a pinned artifact with validation (PO-ADDRNET-VALIDATE) and eventually mechanized correspondence (PO-PTGEN-CORRECT) without bloating the privileged core.

## D-DRVDOM: driver domains / deprivileged device logic (optional)
Options: in-kernel drivers; user-space driver domains with IO resource caps; mixed (critical drivers only).  
Evidence: TCB reduction vs performance/complexity; ability to mediate MMIO/IRQ/DMA via explicit objects and satisfy I-DMA-1/I-IORES-1 under A-DMA-1.
See: RFC-0008, RFC-0045, RFC-0083.

## D-DEVGUARD: device authorization and hotplug portals (optional)
Options: ambient devfs/udev-like device exposure (avoid); deny-by-default hotplug + explicit attach portals; allow only into a dedicated peripheral domain; deterministic rule policy as data (CH-DEVGUARD).  
Evidence: ability to treat peripherals as explicit capability grants, preserve transcript visibility, and fail closed when DMA posture cannot be met (D-DMA).  
See: RFC-0085, RFC-0045.

## D-IOLEASE: device leasing / data-plane bypass for I/O (optional)
Options: none (default); lease bounded device queues/resources to user space (driver domains/library dataplanes); kernel/hypervisor stays control-plane only.
Evidence: ability to keep device models out of the TCB while maintaining DMA containment (D-DMA/D-ADDRNET) and explicit authorization/logging for lease grant/revoke.
See: RFC-0045.


## D-FCELL: Foreign Cell compatibility membrane (sealed legacy/POSIX lane)
Options: none (default); enable a **Foreign Cell** lane with an explicit, fail-closed membrane contract ([foreign-cell-contract.md](foreign-cell-contract.md)) and non-authoritative launch manifests (CH-FCELL v0).

Evidence:
- ability to keep the privileged core unchanged while hosting a legacy ABI
- negative tests for ambient filesystem/network/time acquisition from inside the cell (AC-071)
- policy-killable behavior (boot-time and runtime) with deterministic failures
- compatibility membrane invariants remain satisfied (I-COMPAT-1/I-COMPAT-2/I-FCELL-1)

Notes:
- v0 CH-FCELL manifest validators MUST accept only `runtime.kind="rump"` (reserved kinds reject) per `rumpk-selection-posture-v0.md` (keeps sealed compat honest).
- D-FCELL pins the *membrane*. D-RUMPK selects the runtime strategy inside the cell.
- The lane kill switch is `cfg.params.lane.fcell` (see `config-toggle-registry.md`); when disabled, `fcell.*` actions reject deterministically and emit receipt/log evidence (PO-LANE-KILL).
- Adapter-mediated interop is additionally killable per adapter kind via `cfg.params.lane.fcell.adapter.<adapter_kind>` (normalize `.`→`_`) checked alongside the bound portal lane gate (fail closed; PO-LANE-KILL).
- Adapter-mediated host effects on behalf of a cell MUST be portalized and accompanied by per-op CH-FADAPT receipts (v0 or v1) (portal token + issued handle digests), enabling mechanical “interop only via portals/intents/receipts” audits (PO-FADAPT-EMIT). In profiles that propagate request context end-to-end, CH-FADAPT v1 MAY carry `reqctx_digest = digest(CH-REQCTX v1)` as a non-authoritative correlation/veto-only hook.
- Adapter kinds are a closed, reviewable set in `fcell-adapter-kind-registry.md` (prevents compat interop drift and keeps audits mechanical).
- Adapter receipts participate in D-COMMUTE via derived `cell.adapter` conflict keys and optional ordering witnesses (CH-CONFLICTKEY/CH-ORDERTOK); see `fcell-commutativity-contract-v0.md`.


## D-RUMPK: rump-kernel compatibility domains for legacy drivers/FS (optional)
Options: none (default); use rump kernels for untrusted filesystem images only; broaden to selected network/storage drivers; hosted rump domains as a driver-dev/test tool; alternative compatibility runtimes (Linux-kernel-library / userspace-kernel / library-OS picoprocess) for legacy stacks.
Evidence: time-to-hardware/portability wins versus code-volume risk; ability to keep the privileged core unchanged by running legacy subsystems in isolated domains; membrane must satisfy D-FCELL and remain capability-mediated (I-COMPAT-1/I-COMPAT-2); performance and memory overhead; ergonomics of exposing compat-backed services via translators (D-TRANS) and views (D-NS).
v0 posture: pin the initial internal runtime choice and scope (rump kernels, filesystem-image handling only) in `rumpk-selection-posture-v0.md`.
See: RFC-0036, RFC-0083.


## D-BOOT: boot/update model
Options: verified boot; measured boot; both; anti-rollback.  
Evidence: operational needs; supply-chain attacker model (ADV-SUPPLY); reproducibility feasibility.

## D-ATTEST: device attestation posture (optional)
Options: none (default); produce an attestation token bound to CH-BOOT (CH-ATTEST) using a hardware RoT (e.g., DICE/TPM/TEE) and optionally align claims with EAT.
Evidence: whether verifiers can check binding (boot digest, policy revision) and freshness under explicit assumptions without adding privileged complexity; operational value for update gates and fleet integrity.

## D-PCP: proof-carrying provenance target
Options: “attest build only” (C-PROV-1); “end-to-end binding” (C-PROV-2); “release-only PCP” vs “every boot PCP”.  
Evidence: whether we can bind running binaries to source+spec+proof bundles without ballooning TCB; operational viability; verifier simplicity.
v0 posture: **release-only PCP** (CI/release artifact); boot-time verification stays small: IF-BOOT verifies binding (PO-PROV-BIND) when enabled, but does not validate bulky proofs/models. Pinned in `docs/60-engineering/pcp-posture-v0.md`.


## D-AREF: artifact references / content-addressed evidence (optional)
Options: none (default); allow CH-AREF pointers for heavyweight evidence (proofs, corpora, logs); optional external CAS backing; policy-gated locator schemes.
Evidence: ability to keep the archive small while preserving mechanical checkability (digest binding), and avoid locator-based attacks (scheme allowlists; fail closed) (I-AREF-1).
See: `artifact-resolution-posture-v0.md` (v0: no privileged locator dereference; resolution is portalized and lane-killable).
## D-TLOG: transparency-log anchoring for evidence (optional)
Options: none (default); publish signed digests to an external transparency log (CH-TLOG anchors); run a private tile-based log for releases.  
Evidence: operational value for independent auditing; tooling maturity; keeping this entirely out-of-band (no kernel dependency).

## D-WITNESS: witnessed checkpoints for transparency logs (optional)
Options: none (default); require threshold witness signatures over log checkpoints for “audit-complete” releases; optionally anchor to multiple independent logs.
Evidence: availability of practical witness stacks (or independent operators), cost/ops overhead, and whether witnessed checkpoints meaningfully reduce split-view/equivocation risk without coupling boot to external infrastructure.

## D-UPD-SIGN: signature posture for update/config artifacts
Options: embedded signatures in CH-*; detached envelope objects (CH-SIGENV / DSSE-style); hybrid; optional keyless profiles (D-KEYLESS) that accept cert-bound identities.  
Evidence: verifier simplicity (B0/B3), distribution constraints, unambiguous binding to digests.

## D-SIGENV: signature envelope format for signed CH-* payloads (optional)
Options: none (default early); CH-SIGENV v0 (DSSE-style type+digest binding) as the canonical envelope; embedded vs detached distribution.  
Evidence: prevent type-confusion; make verification tooling uniform; keep verifiers small; interop with TUF (D-TUF) and transparency anchors (D-TLOG).
See: RFC-0093.

## D-KEYLESS: keyless signing posture (Sigstore-style) (optional)
Options: none (default); accept `keyless_cert` signatures under issuer+identity allowlists; higher-assurance channels may require a transparency anchor (D-TLOG) and short validity windows.  
Evidence: operational burden reduction vs reliance on external identity/CA infrastructure; time/freshness interactions; revocation/incident workflows; audit value of public logs.
See: RFC-0093.


## D-ENC: canonical encoding and hashing
Options:
- **Canonical CBOR (recommended):** canonical CBOR (REF-CBOR-RFC8949) as the *normative bytes* for all CH-* payloads.
- **Authoring JSON (optional):** accept JSON for human authoring only, but require JCS canonicalization (REF-JCS-RFC8785) and deterministic transcoding to canonical CBOR before hashing/signing.
- **Other (defer):** protobuf-with-canonicalization or a bespoke format (avoid early unless evidence forces it).

Evidence:
- deterministic decode + stable hashing as a security primitive (I-ENC-1; PO-ENC-DECODE)
- parser auditability and "fail closed" behavior under malformed inputs
- ability to keep schema evolution disciplined (closed enums; reject unknown keys by default)

v0 posture (pinned for hashing semantics):
- `digest(CH-XYZ vN)` hashes the schema's **canonical bytes** as defined in `schema-canonical-bytes-v0.md`.

## D-MICROVM: microVM profile (hypervisor-first slice)
Options: minimal paravirt device set; “no emulation” (fail-closed); limited emulation (declared + closed).  
Evidence: exit-surface budget; device-model TCB; whether the profile yields a compelling A2/A3 slice.

## D-PART: static partition policy profile (optional)
Options: none (default); static “cells” with CH-PART policy + no emulation; partitioning hypervisor slice.  
Evidence: whether policy-as-data + overlap validation yields a strong early deliverable with small TCB; whether DMA/IOMMU posture is tractable (PO-PART-DMA).

## D-CC: confidential-computing stance (optional)
See: RFC-0064.
Options: none (default); TEE-backed profile (SEV-SNP / TDX / CCA); “attestation only” vs “enforced isolation guarantees”.  
Evidence: explicit assumption set (A-CC-1); init/measurement correctness; residual side-channel posture (D-SIDECH).

## D-IFC: information-flow stance (optional)
Options: none (default); IFC-lite on selected channels/observations; stronger noninterference model.  
Evidence: ability to define an observation model and prove/validate it without exploding the state space; alignment with C-OBS-1 and D-SIDECH.
See: RFC-0047 (D-IFC), CH-LABEL v0, and AC-072.

## D-LLM: LLM-assisted operations posture
Options: “LLM proposes; deterministic validator executes”; “no LLM in privileged loop”; limited read-only copilots.  
Evidence: threat model (prompt injection / tool abuse); ability to prove “text cannot create authority” (<I-LLM-*>; <PO-ACT-*>).

## D-POLICY: veto-only policy bundles for operational guardrails (optional)
Options: none (default); veto-only policy engine for ACP and composition constraints (CH-POLICY); richer pinned contexts (still veto-only).  
Evidence: practical ability to encode guardrails without creating authority; determinism and auditability; keeping policy out of the privileged core.
Receipt surface note: when CH-DENY v0 is emitted for policy/authority failures (`missing-approval`, `expired-approval`, `policy-deny`), denials MUST bind `reason.kind="policy"` and `reason.ref_digest = digest(CH-POLICY v0)` **or** `digest(CH-POLICYHANDLE v0)` so “which policy was in force?” is non-ambient and transcript-visible.

## D-EVENTBUS: capability-mediated event plumbing (optional)
Options: none (default); user-space event router with capability-checked publish/subscribe; privileged primitive (only if later justified).  
Evidence: whether it reduces ambient channels and helps operator/ACP workflows without expanding the privileged core; ability to validate schemas and log deterministically.

## D-OBS: observation export posture (IF-OBS)
Options: minimal export (CH-OBS only); richer export (logs/traces/inspect/cap-graphs); local-only vs shareable bundles; sanitized-only default vs operator-authorized full exports.
Evidence: risk of data exfiltration/covert channels vs operator/incident value; ability to enforce redaction/minimization deterministically (I-OBS-1) and keep exports non-authoritative (I-OBS-2); impact on side-channel scope (D-SIDECH).

## D-OBSPOL: observation export policy artifact (optional)
Options: implicit/compiled policy (default early); pinned policy-as-data (CH-OBSPOL) selected by profile/tier; per-workflow policy digests bound into exported artifacts.
Evidence: reviewability + deterministic enforcement; ability to keep “what we export” explicit, bounded, and auditable without expanding privileged code paths.
See: RFC-0076.

## D-TRIAGE: on-device triage rules and diagnosis predicates (optional)
Options: none (default); pinned triage rules (CH-TRIAGE) evaluated over inspect/crash artifacts; triage + snapshot assembly integration (advisory only).
Evidence: whether triage materially reduces "dump everything" behavior without increasing exfil risk; ability to keep rule evaluation bounded/deterministic (I-TRIAGE-1) and non-authoritative (I-TRIAGE-2); ability to test rule sets with golden inputs; interaction with CH-OBSPOL and portal workflows.
See: RFC-0087.


## D-TRACE: tracing/tracepoints posture (optional)
Options: none (default); static tracepoints only; patchable/static-key tracepoints; user-space only (no kernel events).
Evidence: safety (no code injection); explicit authorization + redaction via IF-OBS; overhead when disabled/enabled; impact on side-channel scope (D-SIDECH).

## D-TRACEPROC: programmable trace processing pipelines (optional)
Options: none (default); user-space processors over CH-TRACE (recommended); in-kernel programmable hooks (avoid early).
Evidence: ability to answer “one question” without dumping raw traces; overhead vs raw export; strength of bounds/redaction against exfil/covert channels; composability with D-WASM and D-BUDGET.
See: RFC-0068.

## D-TPROBE: tracepoint descriptor manifest (optional)
Options: none (default); ship a pinned tracepoint schema table (CH-TPROBE) with the build/profile; optionally include/advertise the CH-TPROBE digest alongside exported trace artifacts.
Evidence: ability to name/type-check trace fields for predicates and tools; avoidance of index-based interpretation bugs; enforcement of redaction/semantic constraints (e.g., no raw addrs) using field metadata; fail-closed behavior on schema mismatches.
See: RFC-0077.

## D-TPRED: trace predicates / prefiltering (optional)
Options: none (default); portal-only filtering (recommended early); optional source-prefilter for selected probes via CH-TPRED.
Evidence: ability to reduce trace volume/overhead without in-kernel scripting; validator simplicity; bounded evaluation cost; determinism of drop/overflow behavior; interaction with D-TRACEPROC and D-SIDECH.
See: RFC-0073.

## D-INSPECT: structured diagnostics trees + snapshot bundles (optional)
Options: none (default); per-component inspect trees exported as CH-INSPECT snapshots; optional crash capsules (CH-CRASHCAP) and support/incident snapshot bundles (CH-SNAPSHOT) assembled by user-space tooling.
Evidence: whether structured state snapshots materially reduce reliance on stringly logs; bounded CPU/memory overhead under adversarial components; redaction/minimization posture (I-OBS-1) and export gating; usefulness for incident workflows (crash reports, topology, counters).
See: RFC-0075.

## D-FLIGHTREC: flight recorder retention rings + incident capture triggers (optional)
Options: none (default); volatile-only rings (recommended baseline); bounded persistent retention; crash-survivor region (pstore-like) for last-gasp logs.
Evidence: bounded overhead under high event rates; deterministic overload behavior (drop/rotate); no scope amplification beyond CH-OBSPOL; whether incident workflows materially improve (crash/hang triage time, reduced “please reproduce with debug logs”).
See: RFC-0109.

## D-FAILPOINT: failpoints and fault injection posture (optional)
Options: none (default); dev/test-only failpoints loaded from a pinned profile (CH-FAIL); limited in-core hooks for seams user space cannot reach.
Evidence: ability to exercise failure paths without TCB bloat; determinism/replay compatibility (D-RR); bounded damage radius and no authority amplification (I-FAIL-1).

## D-SIDECH: side-channel scope posture
Options: explicit non-claim (default); scoped timing-only; bounded microarchitectural model.  
Evidence: ability to specify/mechanize an observation model; cost/benefit; explicit non-claims in `assurance-claims.md`.

## D-UNSAFE: Rust subset and boundary
Options: minimal unsafe HAL; wider unsafe but audited; unsafe in external drivers only.  
Evidence: ability to tie each unsafe site to a U-ID + invariant contract (C-UNSAFE-1; U-*).

## D-ZEROIZE: memory remanence policy
Options: always-zeroize; zeroize on cross-domain reuse; best-effort only (non-claim).  
Evidence: threat model for remanence; performance budget; feasibility of proving enforcement (<I-REUSE-*>; <PO-ZEROIZE-*>).

## D-TIME: time source for security policies
Options: none (no expiry/anti-rollback); monotonic counter only; secure RTC + counter; monotonic + authenticated time bootstrap (D-TIMEPROOF).
Evidence: threat model for rollback/expiry; availability of monotonic hardware source; ability to make C-TIME-1 meaningful under A-BOOT-2.

## D-TIMEPROOF: authenticated network time bootstrap + time proofs (optional)
Options: none (default); Roughtime-style signed time samples for bootstrap; NTS-secured NTP for steady-state; hybrid (Roughtime bootstrap + NTS discipline).
Evidence: whether deployments lack a trustworthy RTC; whether expiry-based mechanisms (D-TUF, cert validity) must function at first boot; network adversary model; acceptable privacy leakage (time server identifiers, RTT); ability to keep security time monotonic (I-TIME-1) while still exporting bounded proof artifacts (CH-TIMEPROOF).
See: RFC-0090.

Wiring (v0 seed):
- User-space implementation is a portal-clock extension (no privileged time-sync protocol in kernel).
- LLM-first invocation uses ACP kind `portal.clock.timeproof.sample` bound to `timereq_digest = digest(CH-TIMEREQ v0)`; the portal emits `CH-TIMEPROOF v0` as bounded evidence.
- Profile kill switches: `cfg.params.lane.portal.clock` **and** `cfg.params.lane.timeproof` (missing/false fail closed; PO-LANE-KILL).


## D-XS: exit/entry surface budget
Options: strict closed action sets with tight budgets vs flexible interfaces.  
Evidence: proof tractability; exploit surface; ability to enforce PO-XS-CLOSESET; see `exit-surface-budget.md`.
