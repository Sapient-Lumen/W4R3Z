# CH-REQCTX temporal-capability reference posture v0 (untyped digest list, consumer-typed)

Purpose: keep **D-TCAP** (temporal/scheduling-context style capability objects) auditable and non-ambient even though CH-REQCTX carries an *untyped* `tcap_desc_digests` list.

This doc is intentionally narrow: it pins how consumers interpret `tcap_desc_digests` when a workflow or policy wants to **require explicit temporal capability sponsorship** (e.g., a future “metered timeproof” or “CPU-time donated” workflow).

## Posture (v0)

1) **`tcap_desc_digests` is untyped by design (CH-REQCTX v0/v1)**
   - The list elements are `bytes32` digests only.
   - The list MUST NOT be treated as a polymorphic “resolver hint”.

2) **Consumers are type-strict (veto-only)**
   - When an interface requires a temporal capability descriptor, **only** descriptors that validate as **CH-TCAP v0** satisfy the requirement.
   - Any digest that resolves to a different schema version/kind MUST be treated as **not a tcap** (do not guess).

3) **Resolution is non-ambient**
   - Validators MUST resolve digests using **only** explicitly provided artifact material (e.g., the proposal bundle / local artifact store) and MUST NOT dereference locators (`file:`, `https:`, etc.).
   - This composes with the repo’s artifact posture: locators are hints only; privileged code does not dereference them (`artifact-resolution-posture-v0.md`).

4) **Failure modes are deterministic and transcript-visible**
   - If a required tcap is missing, unresolvable, invalid, or schema-mismatched, the action rejects deterministically.
   - Recommended deny vocabulary remains `tcap-missing` bound to the active CH-REQCTX digest and the required schema (`reason.kind="schema"`, `reason.ref_schema="CH-TCAP v0"`).

## Rationale

- Keeps “no ambient time / scheduling sponsorship” honest without inflating CH-REQCTX early.
- Avoids “helpful” fallback that would turn CH-REQCTX into an ambient authority channel.
- Aligns with capability OS patterns where CPU-time is a first-class object (see REF-SEL4-MCS / REF-SEL4-API-SC-UNBIND).

## Wiring

- CH-REQCTX schemas: `request-context-schema-v0.md`, `request-context-schema-v1.md`.
- CH-TCAP descriptor: `temporal-capability-schema-v0.md`.
- Artifact posture: `artifact-resolution-posture-v0.md`.

CI drift gate:
- `tools/check_reqctx_tcap_ref_posture.py` fails `make lint` if this posture is not discoverable and referenced from the CH-REQCTX security notes.
