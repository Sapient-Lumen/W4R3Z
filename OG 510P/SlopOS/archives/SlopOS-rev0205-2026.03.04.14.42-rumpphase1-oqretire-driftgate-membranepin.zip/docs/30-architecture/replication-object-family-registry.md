# Replication object-family registry (v0)

CH-REPLCONTRACT v0 uses `object_family` strings to describe cross-cluster ownership/replication semantics under Hybrid (ADR-0005).
Left “open”, these strings become an amnesia/drift seam: new families appear in prose, tooling diverges, and reviewers lose the closed-world surface.

This registry closes that seam by pinning a **reviewable allowlist** of v0 `object_family` tokens.

## Rules (v0)

- **Strict posture:** IF-CFG / IF-BOOT validators in strict profiles MUST reject CH-REPLCONTRACT entries whose `object_family` is not listed here.
- **Non-authoritative:** replication artifacts never grant authority (PO-REPL-NOAMP). These families are *descriptions* only.
- **RC4 admission is narrow:** `replication_class = rc4_ordered_log` is reserved to `object_family = tlog` in v0.
  - Any other use of RC4 requires an explicit decision update (D-REPL) + evidence.

## Canonical v0 families

| object_family | What it names | Default RC stance (v0) | Conflict-key tag(s) | Notes |
|---|---|---|---|---|
| `view` | view/namespace binding metadata (attach/detach, slot bindings) | `rc1_owner` | `view_id` | authoritative mutations routed to owner (see `hot-action-surface-v0.md`) |
| `transcript` | audit transcript/event-set export metadata (CH-LOG) | `rc3_comm_merge` | `log_id` | commutative merge; timeline order is canonicalized, not authoritative |
| `receipt` | receipt/event-set export metadata (e.g., CH-ACPOUT, CH-DENY, CH-FADAPT receipts) | `rc3_comm_merge` | `log_id` | treat as content-addressed set; do not require global order |
| `quota` | spend/charge state summaries for metering/quota | `rc3_comm_merge` | `budget_id` | charges are additive/commutative within allocated credit; mint/revoke lives elsewhere |
| `budget` | mint/split/revoke authoritative budget state | `rc1_owner` | `budget_id` | owner-sharded, explicit serialization at mint/revoke boundary |
| `caprpc_proxy` | cross-cluster proxy metadata for capability-RPC endpoints | `rc1_owner` | `endpoint_id` | proxies are owned; cross-cluster calls route to owner |
| `namecert` | local naming certificates / delegation bundles (D-NAMECERT) | `rc3_comm_merge` | `name_domain` | signed bundles merge as a set; conflict resolution is by signature + policy |
| `tlog` | transparency log checkpoints/receipts (non-authoritative evidence lane) | `rc4_ordered_log` (when enabled) | `log_id` | RC4 reserved here; see `replication-contracts-v0.md` + REF-CT-RFC6962/REF-CT-RFC9162/REF-TRILLIAN and witness notes (REF-COSI-2015, REF-TRANSPARENCY-WITNESS) |

## Change control

To add a new `object_family` token:
1) add exactly one new row above (justify why it is cross-cluster relevant),
2) update `profile-repl-defaults.md` so A–D defaults remain coherent (no forks),
3) if the family needs RC4, update the RC4 admission posture (D-REPL) and add evidence,
4) update docs wiring (`docs/README.md`), and
5) add/extend a drift gate + EVID entry if the new family meaning could drift.

## Related docs

- `replication-contract-schema-v0.md` (CH-REPLCONTRACT v0 schema)
- `replication-contracts-v0.md` (RC0..RC4 vocabulary + v0 posture)
- `profile-repl-defaults.md` (A–D default guidance)
