# Attention lease posture (v0): no new lease descriptor

Purpose: close the D-ATTN “attention lease” follow-up **without adding a new schema surface**.

Decision (v0 stance): **do not introduce a dedicated attention-lease descriptor** for urgent/critical alerts.
Instead, treat urgency as a *policy-gated hint* on the existing request seam **CH-NOTIF v0**.

Why this is high-leverage:
- Keeps the privileged/UI TCB smaller (no new lease lifecycle to implement or audit).
- Keeps “sealed compat” + “no ambient channels” honest: urgency cannot become an implicit bypass.
- Keeps automation safe: LLM-proposed notifications remain a bounded request that can be deterministically denied.

This document refines **D-ATTN** and applies to the `portal.attn.*` family.

## What “urgent” means in v0

CH-NOTIF already has an optional `importance` hint with a closed enum including `"urgent"`.
In v0:
- `importance="urgent"` is **never** a grant and never a bypass.
- It is a **request** that the portal may ignore, downgrade, coalesce, or deny.
- Any “critical alert” behavior is controlled by **portal policy + explicit user settings**, not by requester fields.

(Design inspiration: mobile platforms treat “critical” interruption as explicitly privileged / user-gated, not app-chosen; see REF-APPLE-CRITICAL-ALERTS and REF-ANDROID-NOTIF-CHANNELS.)

## Normative obligations

These obligations keep Hybrid + commutativity + sealed compat honest while we delay any lease invention.

1) **No bypass of volition** (I-ATTN-2):
   - `importance="urgent"` MUST NOT enable background execution or auto-running notification actions.
   - If `actions[*]` are rendered, executing them still requires the normal D-VOLITION posture and digest-binding.

2) **No bypass of budgets/coalescing** (I-ATTN-3; PO-ATTN-BUDGET):
   - Urgent requests are subject to the same deterministic budget/coalescing rules as non-urgent requests.
   - Policy MAY apply stricter limits for urgent (e.g., lower budget ceilings, longer cooldowns), but never looser.

3) **Explicit policy gating for urgent** (new PO-ATTN-URGENT):
   - If a profile/policy does not allow urgent interruption for the origin/channel, the portal MUST deterministically deny or downgrade the request.
   - Denials SHOULD be transcript-visible when the request is mediated via ACP (`portal.attn.request`) using CH-DENY `deny_code="policy-deny"` or `"cfg-deny"` (when denied via an explicit posture knob).

4) **Replay stability** (D-RR):
   - Given the same request bytes + the same policy bundle/handle, the portal’s urgent downgrade/deny decision MUST be deterministic.

## Profile posture (guidance; not a fork)

To keep the four product shapes aligned, v0 guidance is:
- **A (secure workstation):** urgent allowed only by explicit user opt-in per origin/channel; defaults conservative.
- **B (cloud substrate):** urgent generally denied (fleet policy); use non-urgent operational channels.
- **C (embedded/separation):** urgent denied unless the device’s mission profile explicitly enables it.
- **D (agent/automation):** urgent denied-by-default; policy may allow for narrowly scoped, owner-approved channels.

These are *policy defaults*; the schema does not fork.

## Future hook (if we later need a lease)

If we eventually need a first-class lease (e.g., “critical alerts” that survive restarts with TTL/renewal semantics),
that requires an RFC and a new schema surface (a new attention-lease schema) with:
- explicit TTL/renew, revoke, and audit semantics,
- policy-killable issuance,
- and digest-only receipts.

Until then, urgency remains a CH-NOTIF hint that policy may clamp.
