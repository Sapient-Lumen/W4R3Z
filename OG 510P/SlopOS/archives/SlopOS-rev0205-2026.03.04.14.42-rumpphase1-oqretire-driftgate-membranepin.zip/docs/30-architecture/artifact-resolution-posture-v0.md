# Artifact resolution posture (v0: no ambient locator deref)

Purpose: keep **D-AREF** “sealed compat” honest when we reference heavyweight artifacts via **CH-AREF v0**.
CH-AREF is *content identity* (digest is authoritative); **resolution is a workflow** and must not reintroduce ambient paths/env/implicit network.

This doc does **not** introduce a new schema surface. It pins how implementations treat CH-AREF `locator` hints.

Related:
- CH-AREF v0: `artifact-reference-schema-v0.md`
- D-AREF: `decision-map.md`
- Portal families: `portal-family-registry.md`
- Network lease request: `network-request-schema-v0.md` (CH-NETREQ v0)

Assurance anchors:
- I-AREF-1
- PO-AREF-VERIFY
- PO-LANE-KILL (when network/file workflows are used)

## v0 rules (tight)

1) **`locator` is never authority**
   - The only authoritative identity is `(digest_alg, digest)` (and optional `size`).
   - Verifiers MAY ignore `locator` entirely.

2) **No privileged dereference**
   - Privileged validators/verifiers MUST NOT dereference `locator` (no implicit `file:` reads, no implicit `https:` fetches).
   - Privileged code only verifies bytes that are already provided via an explicit channel.

3) **Resolution uses explicit workflows (killable by policy)**
   When bytes are needed, the system MUST obtain them via *explicit* workflow seams:

   - **Network**: acquire connectivity via `portal.net.*` (lane-gated by `cfg.params.lane.portal.net`).
     - Requests SHOULD use CH-NETREQ v0 with `purpose="aref_fetch"` and a tight destination predicate (prefer `dest.kind=service` where policy can pin the mapping).
     - Any fetched bytes MUST be verified against the CH-AREF digest before use.

   - **Local files / user-supplied artifacts**: obtain a handle via `portal.file.*` (lane-gated by `cfg.params.lane.portal.file`).
     - The handle (e.g., CH-DOCREF) is the access path; raw host paths MUST NOT become an authority channel.
     - Bytes read through the handle MUST be verified against the CH-AREF digest before use.

4) **Scheme guidance (non-normative)**
   - `ni:` is preferred when you want a *digest-first name* that composes across tooling (still a hint, still may be ignored).
   - `cas:`/`https:` are acceptable only when the resolver is explicitly operating under a network lease.
   - `file:` locators are allowed as a *debug hint* for user-space tooling, but MUST NOT be dereferenced by privileged code.

5) **Cache semantics (commutative by construction)**
   If a resolver maintains a local cache, it MUST be idempotent keyed by digest:
   - inserting the same bytes for the same digest is a no-op,
   - mismatched bytes for a digest is a deterministic integrity failure.

## Profile notes (A–D)

- **A (secure workstation):** allow resolution only via portals; default to strict scheme allowlists; treat `file:` as UI-only.
- **B (cloud micro-VM substrate):** prefer CAS/REAPI-like retrieval under `portal.net` with service-scoped CH-NETREQ predicates.
- **C (embedded / separation-ish):** default to *no resolution* unless artifacts are provisioned out-of-band; keep locators ignored.
- **D (agent/automation):** require deterministic “no ambient fetch” posture so LLM-proposed steps cannot smuggle authority via URLs.

## References
- REF-RFC6920 (ni: URIs)
- REF-REAPI-PROTO (REAPI digest-addressed blobs)
- REF-NIX-CA-OUTPUTS (digest-first build outputs)
