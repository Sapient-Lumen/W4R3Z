# Conflict key derivation registry (v0 seed)

Purpose: pin **deterministic derivation** rules for the digest-valued fields used inside `CH-CONFLICTKEY v0` payloads.

Why this exists:
- D-COMMUTE + Hybrid rely on conflict keys as **stable, reviewable artifacts**.
- CH-ORDERTOK scopes ordered streams to conflict keys; if key derivation drifts, ordering evidence drifts.
- Several conflict-key families use `*_key: bstr` fields that are intended to be **digests of stable identity tuples**.
  This registry makes those tuple→digest commitments explicit without inventing new authority.

Non-goals:
- This does **not** define new conflict-key families (see `conflict-key-family-registry.md`).
- This does **not** grant authority. All derived keys are **non-authoritative** metadata.

## Canonical helpers (normative for v0)

Let:
- `digest(..)` be the profile hash (fixed length; D-HASH),
- `cbor(..)` be canonical CBOR encoding (D-ENC; see `schema-canonical-bytes-v0.md`),
- and `hashlen` be the profile digest length.

For v0, D-HASH pins `digest(..)` and `hashlen` (see `profile-hash-suite-v0.md`).

### `ck_id(tag, x)`

```
ck_id(tag, x) :=
  if is_bstr(x) and len(x) == hashlen:
    x                  ; avoid double-hashing digest-sized ids
  else:
    digest(cbor([tag, x]))
```

Rules:
- `tag` is a short ASCII string (bounded) that disambiguates the tuple space.
- `x` MUST be a bounded, canonically encodable identifier value (tstr/bstr/uint/map/array as pinned by the relevant surface).
- Producers MUST reject (fail closed) any `x` whose encoding is not canonical or exceeds bounds.

Rationale:
- Including `tag` prevents cross-family collisions when different object types reuse the same underlying id shape.
- The “avoid double-hash” clause keeps evidence stable when ids are already digest-sized (mirrors `ck_domain(..)` in `conflict-key-schema-v0.md`).

## Typed id inputs (v0)

To keep Hybrid + D-COMMUTE evidence **closed-world and deterministic**, v0 pins the canonical
encoding of the `*_id` inputs that feed `ck_id(..)` on the pinned surfaces.

Decision: **D-TYPEDID** (see `typed-id-contract-v0.md`).

Normative for v0:
- `as_id`, `endpoint_id`, `view_id`, `log_id`, `meter_id`, `budget_id`, and `cell_id` are digest-sized `bstr`
  values of length `hashlen` (profile digest length).
- Therefore the common-case `ck_id(tag, x)` rule returns `x` (avoid double-hashing).

Profiles that later choose a structured id encoding must first introduce an explicit schema surface
for that encoding (and update the typed-id contract) rather than silently changing `ck_id(..)` inputs.

## Derivation commitments (v0)

The table below pins how digest-valued payload fields must be derived.

| CH-CONFLICTKEY family | Digest-valued payload field(s) | Derivation commitment | Notes |
|---|---|---|---|
| `mem.range` | `as_key` | `as_key = ck_id("mem.as", as_id)` | `as_id` is pinned as digest-sized `bstr` by `typed-id-contract-v0.md` (D-TYPEDID). `vaddr_lo`/`vaddr_len` remain raw bounded integers. |
| `ipc.endpoint` | `endpoint_key` | `endpoint_key = ck_id("ipc.endpoint", endpoint_id)` | `endpoint_id` is pinned as digest-sized `bstr` by `typed-id-contract-v0.md` (D-TYPEDID). |
| `view.slot` | `view_key` | `view_key = ck_id("view.id", view_id)` | `view_id` is pinned as digest-sized `bstr` by `typed-id-contract-v0.md` (D-TYPEDID). `slot_id` remains a raw bounded integer. |
| `log.eventset` | `log_key` | `log_key = ck_id("log.eventset", log_id)` | `log_id` is pinned as digest-sized `bstr` by `typed-id-contract-v0.md` (D-TYPEDID). |
| `budget.issuer` | `issuer_key` | `issuer_key = ck_id("budget.issuer", meter_id)` | `meter_id` is pinned as digest-sized `bstr` by `typed-id-contract-v0.md` (D-TYPEDID). |
| `budget.lease` | `budget_key` | `budget_key = ck_id("budget.lease", budget_id)` | `budget_id` is pinned as digest-sized `bstr` by `typed-id-contract-v0.md` (D-TYPEDID). |
| `domain.id` | `domain_key` | As pinned in `conflict-key-schema-v0.md` (`ck_domain(..)`; avoid double-hash) | `domain_id` follows the typed-id contract when carried as a digest-sized id; otherwise `ck_domain(..)` applies. |
| `policy.param` | *(none)* | Exact string match (no aliasing) as pinned in `conflict-key-schema-v0.md` | This family does not use a digest-valued `*_key` field. |
| `cell.id` | *(none)* | `cell_id` is a digest-sized `bstr` per `typed-id-contract-v0.md` (D-TYPEDID) | Compat cell identity remains intentionally opaque, but its encoding is pinned (raw digest bytes). |
| `cell.adapter` | *(none)* | `cell_id` is a digest-sized `bstr` per `typed-id-contract-v0.md` + closed `portal_token` | Adapter ops bind to `(cell_id, portal_token)` with `cell_id` treated as digest bytes. |

## Ordering-token vocabulary commitment

CH-ORDERTOK `scope.family` MUST use the **same family token set** as CH-CONFLICTKEY.
The canonical allowlist is pinned in `conflict-key-family-registry.md`.

## Wiring requirements

- `docs/README.md` MUST link this registry.
- `conflict-key-schema-v0.md` MUST reference this registry and incorporate these derivation commitments.
- `ordering-token-schema-v0.md` MUST treat `scope.family` as a closed allowlist pinned by `conflict-key-family-registry.md`.
- CI MUST fail if:
  - this registry is missing or unlinked from `docs/README.md`,
  - CH-CONFLICTKEY derivation commitments drift away from this registry, or
  - CH-ORDERTOK family tokens drift outside the CH-CONFLICTKEY family allowlist.
