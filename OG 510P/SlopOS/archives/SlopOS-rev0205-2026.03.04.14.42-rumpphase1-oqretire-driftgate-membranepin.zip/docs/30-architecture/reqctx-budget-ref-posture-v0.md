# CH-REQCTX budget reference posture v0 (untyped digest list, consumer-typed)

Purpose: make explicit-budget enforcement (D-BUDGET) **mechanically checkable** even though CH-REQCTX v1 carries an *untyped* `budget_desc_digests` list.

This doc is intentionally narrow: it pins how validators interpret `budget_desc_digests` when a workflow **requires** explicit sponsorship (e.g., `capshell.exec` under `cfg.params.capshell.require_budget_lease=true`).

## Posture (v0)

1) **`budget_desc_digests` is untyped by design (CH-REQCTX v1)**
   - The list elements are `bytes32` digests only.
   - The list MUST NOT be treated as a polymorphic “resolver hint”.

2) **Consumers are type-strict (veto-only)**
   - When an interface requires a budget, **only** descriptors that validate as **CH-BUDGET v0** satisfy the requirement.
   - Any digest that resolves to a different schema version/kind MUST be treated as **not a budget** (do not guess).

3) **Resolution is non-ambient**
   - Validators MUST resolve digests using **only** explicitly provided artifact material (e.g., the proposal bundle / local artifact store) and MUST NOT dereference locators (`file:`, `https:`, etc.).
   - This composes with the repo’s artifact posture: locators are hints only; privileged code does not dereference them (`artifact-resolution-posture-v0.md`).

4) **Failure modes are deterministic and transcript-visible**
   - If a required budget is missing, unresolvable, invalid, or schema-mismatched, the action rejects deterministically.
   - Recommended deny vocabulary remains `budget-missing` bound to the active CH-REQCTX digest (PO-CAPSHELL-BUDGET-REQ).

## Rationale

- Keeps “no implicit sponsorship” honest without inflating early schemas.
- Avoids “helpful” fallback that would turn CH-REQCTX into an ambient authority channel.
- Leaves room for a future CH-REQCTX revision **only if** we need multi-schema sponsorship references (tracked as OQ-0008).

## Wiring

- CH-REQCTX v1 schema: `request-context-schema-v1.md` (field definition + bounds).
- Capshell budget requirement: `acp-validator-semantics.md`, `acp-action-kind-registry.md`, and PO-CAPSHELL-BUDGET-REQ.
- Sealed compat posture: no locator deref in privileged resolution (`artifact-resolution-posture-v0.md`).

CI drift gate:
- `tools/check_reqctx_budget_ref_posture.py` fails `make lint` if this posture is not discoverable and referenced from the capshell budget enforcement seam.
