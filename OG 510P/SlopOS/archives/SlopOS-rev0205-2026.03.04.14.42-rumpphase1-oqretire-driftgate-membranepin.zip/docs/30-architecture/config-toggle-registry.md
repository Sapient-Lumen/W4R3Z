# CH-CFG toggle registry (v0)

Purpose: make CH-CFG’s “closed set” real by pinning a **reviewable, stable** list of:
- allowed `cfg.feature_flags` values (profile extensions), and
- allowed `cfg.params.*` keys (operational lane gates / bounds).

This is an **authority substrate** seam:
- Toggles are **veto-only** signals used by validators/policy to *reject* actions or disable lanes.
- Toggles never grant authority (I-POLICY-2). Capabilities/approvals remain the source of authority.

If a toggle is missing here, it is not a toggle.

## `cfg.feature_flags` values (profile extensions; closed set)

Rule: unknown `feature_flags` values MUST be rejected by IF-CFG (PO-CFGTOGGLE-VERIFY).

| Flag value | Meaning | Primary scope | Notes |
|---|---|---|---|
| `ext.static_partitioning` | Static partitioning mode (fixed cores + fixed memory partitions; no overcommit) | P1/P2; C-friendly | narrows scheduling/memory behavior to reduce proof cost (ADR-0002) |
| `ext.microvm` | MicroVM profile (minimal device model; tight exit/entry budget) | B/C; P1/P2 | aligns with D-MICROVM + D-XS closed sets |
| `ext.confidential_computing.attest_only` | TEE-backed attestation evidence only (no isolation claim) | B; P1/P2 | explicit assumption surface; does not imply side-channel safety (RFC-0064) |
| `ext.confidential_computing.enforced` | TEE-backed guest isolation + attestation (claim-scoped) | B; P2 | requires <A-CC-*> + explicit side-channel posture |
| `ext.cheri` | CHERI-enabled mode (selected components) | A/C; research | must scope what is CHERI-enforced vs not |
| `ext.capx_remote_delegation` | Networked capability delegation via CH-CAPX envelopes | B/D; P1/P2 | observation/redaction posture required (D-CAPX) |
| `ext.wasm_plugins` | Wasm plugin profile for extension components | A/B/D | keep host boundary capability-only; pairs with D-SEAL |
| `ext.ifc_lite` | IFC-lite mode for scoped IPC/buffer/object ops | A/B/D | explicit label budget; avoid “label everything” |
| `ext.user_mode_pager` | User-mode pager profile (faults via IPC to pager server) | B/C | pairs with D-PAGER; DoS posture recommended (D-METER) |

Default guidance rule: recommended per-profile defaults for `cfg.feature_flags` values are pinned (non-authoritatively) in
`profile-feature-flag-defaults.md` to keep A–D viable without forks and keep optional semantic slices reviewable.

## `cfg.params.*` keys (operational lane gates; closed set)

Rule: unknown `cfg.params.*` keys MUST be rejected by IF-CFG (PO-CFGTOGGLE-VERIFY).

Naming rule: `cfg.params.lane.*` keys are **kill switches**. When `false`, the lane MUST reject deterministically.

Default guidance rule: recommended per-profile defaults for lane keys are pinned (non-authoritatively) in
`profile-lane-defaults.md` to keep A–D viable without forks and keep default posture reviewable.

Default guidance rule: recommended per-profile defaults for workflow posture knobs are pinned (non-authoritatively) in
`profile-workflow-defaults.md` to keep A–D viable without forks and keep workflow ambient-authority posture reviewable.

| Param key | Type | Default guidance | Gated surface(s) | Notes |
|---|---:|---|---|---|
| `cfg.params.lane.fcell` | bool | off by default | `fcell.launch`, `fcell.kill` (CH-ACP) | sealed POSIX/legacy lane; must remain policy-killable (D-FCELL) |
| `cfg.params.lane.fcell.adapter.posix_open_via_doc_portal` | bool | off by default | `posix.open_via_doc_portal` adapter (D-FCELL) | granular compat adapter kill switch; enable only alongside `cfg.params.lane.fcell` + `cfg.params.lane.portal.file` |
| `cfg.params.lane.fcell.adapter.posix_socket_via_net_portal` | bool | off by default | `posix.socket_via_net_portal` adapter (D-FCELL) | granular compat adapter kill switch; enable only alongside `cfg.params.lane.fcell` + `cfg.params.lane.portal.net` |
| `cfg.params.lane.capshell` | bool | off by default | `capshell.exec` (CH-ACP), IF-CAPSHELL | workflow glue seam; eliminates ambient authority when enabled (D-CAPSHELL) |
| `cfg.params.capshell.minimal_context` | bool | see `profile-workflow-defaults.md` | `capshell.exec` (CH-ACP), IF-CAPSHELL | When true, capshell execution requires a minimal context (empty env, empty cwd selector, null/drop stdio, empty fdset). Veto-only; denies non-minimal packs (PO-CAPSHELL-MINCTX-ENF). |
| `cfg.params.capshell.require_budget_lease` | bool | see `profile-workflow-defaults.md` | `capshell.exec` (CH-ACP), IF-CAPSHELL | When true **and** `cfg.params.lane.metering=true`, `capshell.exec` proposals must bind a CH-REQCTX v1 whose `budget_desc_digests` includes at least one digest that resolves/validates as CH-BUDGET v0 (no implicit sponsorship; PO-CAPSHELL-BUDGET-REQ). |
| `cfg.params.capshell.require_plumbmsg` | bool | see `profile-workflow-defaults.md` | `capshell.exec` (CH-ACP), IF-CAPSHELL | When true, `capshell.exec` proposals must bind CH-EXECPACK v2 that includes `plumbmsg_digest = digest(CH-PLUMBMSG v0)`; validators must validate CH-PLUMBMSG before any effect (non-authoritative intent envelope; veto-only; PO-CAPSHELL-PLUMBMSG-REQ). Missing/invalid intent envelopes fail closed (recommended CH-DENY code: `plumbmsg-missing`). |
| `cfg.params.lane.metering` | bool | off by default | `budget.mint` (CH-ACP) | enables D-METER/D-BUDGET surfaces; still requires explicit payer tokens |
| `cfg.params.lane.portal.file` | bool | see `profile-lane-defaults.md` | `portal.file` effect family (CH-EFFCON) | mediated open/save/export/share workflows; killable by policy |
| `cfg.params.lane.portal.uri` | bool | see `profile-lane-defaults.md` | `portal.uri` effect family (CH-EFFCON) | mediated OpenURI workflows; killable by policy |
| `cfg.params.lane.portal.print` | bool | see `profile-lane-defaults.md` | `portal.print` effect family (CH-EFFCON) | mediated print workflows; killable by policy |
| `cfg.params.lane.portal.device` | bool | see `profile-lane-defaults.md` | `portal.device` effect family (CH-EFFCON) | device pick/lease workflows; killable by policy |
| `cfg.params.lane.portal.net` | bool | off by default | `portal.net` effect family (CH-EFFCON) | outbound connectivity is profile-gated; no ambient sockets |
| `cfg.params.lane.portal.location` | bool | off by default | `portal.location` effect family (CH-EFFCON) | location leases; often disabled except explicit profiles |
| `cfg.params.lane.portal.secret` | bool | off by default | `portal.secret` effect family (CH-EFFCON) | secret-seed workflows; prefer app-scoped seeds + redaction |
| `cfg.params.lane.portal.clock` | bool | see `profile-lane-defaults.md` | `portal.clock` effect family (CH-EFFCON) | explicit time sources as handles; coarse by default; fine clock requires explicit grant (D-NONDET) |
| `cfg.params.lane.timeproof` | bool | see `profile-lane-defaults.md` | `portal.clock.timeproof.sample` (CH-ACP) | D-TIMEPROOF optional; authenticated time bootstrap/proofs; requires `cfg.params.lane.portal.clock` (and typically `cfg.params.lane.portal.net` inside the portal) |
| `cfg.params.lane.portal.entropy` | bool | see `profile-lane-defaults.md` | `portal.entropy` effect family (CH-EFFCON) | explicit entropy sources as handles; seed-by-default; deterministic is explicit for test/replay (D-NONDET) |
| `cfg.params.lane.portal.capture` | bool | off by default | `portal.capture` effect family (CH-EFFCON) | camera/mic/screencast; must be leased + indicator-visible |
| `cfg.params.lane.portal.xfer` | bool | see `profile-lane-defaults.md` | `portal.xfer` effect family (CH-EFFCON) | transfer workflows; policy-killable to clamp sharing/export |
| `cfg.params.lane.portal.attn` | bool | see `profile-lane-defaults.md` | `portal.attn` effect family (CH-EFFCON) | notifications/attention portal; origin branding + budgets; actions bind to CH-ROUTE/CH-ACP digests |
| `cfg.params.lane.portal.jobs` | bool | see `profile-lane-defaults.md` | `portal.jobs` effect family (CH-EFFCON) | background job workflows; prefer D-JOBS; killable by policy |
| `cfg.params.lane.portal.background` | bool | off by default | `portal.background` effect family (CH-EFFCON) | long-lived background/autostart is profile-gated; prefer D-JOBS |
| `cfg.params.lane.portal.inhibit` | bool | see `profile-lane-defaults.md` | `portal.inhibit` effect family (CH-EFFCON) | inhibit/sleep prevention workflows; killable by policy |
| `cfg.params.lane.portal.a11y` | bool | off by default | `portal.a11y` effect family (CH-EFFCON) | observe ≠ inject; leased sessions + indicators |

## Validation + evidence hooks

- IF-CFG validation: reject unknown toggle names and enforce type/bounds (PO-CFGTOGGLE-VERIFY).
- Lane gates: actions that require a disabled lane MUST deterministically reject and emit a transcript-visible receipt/log event (PO-LANE-KILL).
- Portal lanes are a closed and complete set: there is a `cfg.params.lane.portal.<family>` kill switch for every portal family token in `portal-family-registry.md` (I-PORTAL-KILL-1).
- Evidence seeds: EVID-2026-127 (toggle-closure + lane-gate negative tests); EVID-2026-148 (docs cfg.params reference closure drift gate).
- Feature-flag reference closure drift gate: EVID-2026-170 (docs `ext.*` references are registry-closed).
- Profile lane-defaults drift gate: EVID-2026-149 (profile lane-defaults matrix closure + wiring).
- Profile feature-flag defaults drift gate: EVID-2026-167 (profile feature-flag defaults matrix closure + wiring).
- Profile workflow-defaults drift gate: EVID-2026-183 (profile workflow-defaults matrix closure + wiring for cfg.params.capshell.* knobs).

Refs: REF-FUCHSIA-CML (closed, typed manifest fields as a drift-resistance pattern), REF-SEL4-COMPREHENSIVE (scope discipline).
