# Bootstrap open — rev0950

Use the exact archive, an absent destination, and only the opener streamed from inside that archive:

```sh
archive='/absolute/path/SlopOS-rev0950-2026.08.08.02.57-winnerintent-claimcanary-fdpinning-resultbinding.zip'
root='SlopOS-rev0950-2026.08.08.02.57-winnerintent-claimcanary-fdpinning-resultbinding'
destination='/absolute/path/to/absent-destination'
opener="$(mktemp)"
trap 'rm -f "$opener"' EXIT
unzip -p "$archive" "$root/UNPACK.py" > "$opener"
python3 -B "$opener" "$archive" "$destination"
cd "$destination/$root"
python3 -B CURRENT/tools/resume.py basic
```

Do not use generic full extraction as the trusted path. The embedded opener validates names and types before extraction, stages privately, normalizes modes, checks exact file and directory manifests, and publishes with no-replace semantics.

A passing open proves local physical reconstruction only. Continue with `CURRENT/office/READ-FIRST.md`.
