#pragma once

#include "slopos/e0/generation_journal/record.hpp"

#include <cstddef>
#include <filesystem>

namespace slopos::e0::handoff_cell::harness {

struct SettlementCampaignCounts final {
    std::size_t cases{0U};
    std::size_t counterexamples{0U};
    std::size_t crash_cuts{0U};
    unsigned int race_contenders{0U};
    unsigned int race_local_claims{0U};
    unsigned int race_provider_fresh_commits{0U};
    unsigned int race_provider_duplicates{0U};
    unsigned int race_effects{0U};
};

[[nodiscard]] SettlementCampaignCounts run_settlement_campaign(
    const std::filesystem::path& output,
    const std::filesystem::path& scratch,
    const generation_journal::EncodedRecord& pending);

}  // namespace slopos::e0::handoff_cell::harness
