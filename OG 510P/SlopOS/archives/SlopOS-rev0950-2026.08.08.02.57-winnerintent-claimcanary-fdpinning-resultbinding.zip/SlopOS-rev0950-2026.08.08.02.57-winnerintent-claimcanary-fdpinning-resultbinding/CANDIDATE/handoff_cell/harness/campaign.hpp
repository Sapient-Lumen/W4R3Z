#pragma once

#include <filesystem>

namespace slopos::e0::handoff_cell::harness {
int run_campaign(const std::filesystem::path& output);
}
