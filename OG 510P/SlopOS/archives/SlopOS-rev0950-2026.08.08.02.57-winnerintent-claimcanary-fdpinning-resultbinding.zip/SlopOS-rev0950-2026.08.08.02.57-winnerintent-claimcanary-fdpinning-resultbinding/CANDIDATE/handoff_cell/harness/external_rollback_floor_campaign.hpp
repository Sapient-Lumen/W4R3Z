#pragma once

#include <cstddef>
#include <filesystem>

namespace slopos::e0::handoff_cell::harness {

struct ExternalRollbackFloorCampaignCounts final {
    std::size_t cases{0U};
    std::size_t counterexamples{0U};
    std::size_t exact_profile_profiles{0U};
    std::size_t v18_spend_profiles{0U};
    std::size_t prestate_certified_profiles{0U};
    std::size_t extend_request_profiles{0U};
    std::size_t poststate_certified_profiles{0U};
    std::size_t witness_advanced_profiles{0U};
    std::size_t query_only_profiles{0U};
    std::size_t complete_transcript_profiles{0U};
    std::size_t cross_ledger_join_profiles{0U};
    std::size_t external_floor_profiles{0U};
    std::size_t mutation_rejections{0U};
};

[[nodiscard]] ExternalRollbackFloorCampaignCounts
run_external_rollback_floor_campaign(const std::filesystem::path& output);

}  // namespace slopos::e0::handoff_cell::harness
