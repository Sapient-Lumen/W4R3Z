#include "principal_campaign.hpp"

#include "slopos/e0/handoff_cell/principal_cell.hpp"

#include <array>
#include <cerrno>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <stdexcept>
#include <string>
#include <vector>

#include <fcntl.h>
#include <grp.h>
#include <sys/prctl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

namespace slopos::e0::handoff_cell::harness {
namespace {

using generation_journal::EncodedRecord;
using generation_journal::Record;
using generation_journal::RecordKind;
using generation_journal::Result;

constexpr uid_t kProviderUid = 21001U;
constexpr gid_t kProviderGid = 21001U;
constexpr uid_t kWorkloadUid = 21002U;
constexpr gid_t kWorkloadGid = 21002U;

struct PrincipalRow final {
    std::string name;
    std::string observation;
    bool passed{false};
    bool retained_counterexample{false};
    std::string judgment;
};

struct PublicationRow final {
    std::string name;
    std::string append;
    std::string query;
    std::uint64_t version{0U};
    bool retained_counterexample{false};
    std::string judgment;
};

struct CounterexampleRow final {
    std::string name;
    bool reproduced{false};
    std::string defeats;
    std::string retained_law;
};

struct ProviderReport final {
    int no_new_privs{0};
    int factory{0};
    int stage{0};
    int burn{0};
    int pending_query{0};
    int result_v1{0};
    int result_v1_query{0};
    int publication_v1{0};
    int publication_v1_query{0};
    int result_v2{0};
    int result_v2_query{0};
    int publication_v2{0};
    int publication_v2_query{0};
    int duplicate_result_v1{0};
    int duplicate_result_v1_query{0};
    int result_v2_without_v1{0};
    int publication_without_result{0};
    int exact_v1{0};
    int v2_after_exact_v1{0};
    int stage_residue{0};
    int wrong_kind{0};
    int same_uid_prepared{0};
};

struct WorkloadReport final {
    int root_open_errno{0};
    int leaf_open_errno{0};
    int link_errno{0};
    int rename_errno{0};
    int unlink_errno{0};
};

[[noreturn]] void fail(const std::string& detail) {
    throw std::runtime_error(detail);
}

void require(const bool condition, const std::string& detail) {
    if (!condition) fail(detail);
}

[[nodiscard]] std::string bool_text(const bool value) {
    return value ? "true" : "false";
}

void write_exact(const int fd, const void* data, const std::size_t size) {
    const auto* bytes = static_cast<const std::uint8_t*>(data);
    std::size_t offset = 0U;
    while (offset < size) {
        const ssize_t count = ::write(fd, bytes + offset, size - offset);
        if (count < 0 && errno == EINTR) continue;
        require(count > 0, "write exact pipe record");
        offset += static_cast<std::size_t>(count);
    }
}

void read_exact(const int fd, void* data, const std::size_t size) {
    auto* bytes = static_cast<std::uint8_t*>(data);
    std::size_t offset = 0U;
    while (offset < size) {
        const ssize_t count = ::read(fd, bytes + offset, size - offset);
        if (count < 0 && errno == EINTR) continue;
        require(count > 0, "read exact pipe record");
        offset += static_cast<std::size_t>(count);
    }
}

void close_or_exit(const int fd) noexcept {
    if (fd >= 0 && ::close(fd) != 0) _exit(120);
}

void drop_to(const uid_t uid, const gid_t gid) noexcept {
    if (::setgroups(0U, nullptr) != 0) _exit(121);
    if (::setresgid(gid, gid, gid) != 0) _exit(122);
    if (::setresuid(uid, uid, uid) != 0) _exit(123);
    if (::prctl(PR_SET_NO_NEW_PRIVS, 1L, 0L, 0L, 0L) != 0) _exit(124);
    if (::geteuid() != uid || ::getegid() != gid) _exit(125);
}

[[nodiscard]] std::array<std::uint8_t, 32U> binding(
    const std::uint8_t base) noexcept {
    std::array<std::uint8_t, 32U> value{};
    for (std::size_t index = 0U; index < value.size(); ++index) {
        value[index] = static_cast<std::uint8_t>(
            static_cast<unsigned int>(base)
            + static_cast<unsigned int>(index));
    }
    return value;
}

[[nodiscard]] EncodedRecord record_bytes(const RecordKind kind,
                                         const std::uint64_t sequence,
                                         const Result result) {
    Record record;
    record.kind = kind;
    record.sequence = sequence;
    record.generation_from = 41U;
    record.generation_to = 42U;
    record.operation_binding = binding(1U);
    record.spent_receipt_binding = binding(161U);
    record.result = result;
    record.consumed_dispatch = true;
    record.reconciled = sequence == 2U;
    EncodedRecord encoded{};
    require(generation_journal::encode_record(record, encoded),
            "encode principal campaign record");
    return encoded;
}

void make_provider_root(const std::filesystem::path& path) {
    require(std::filesystem::create_directory(path),
            "create provider root " + path.string());
    require(::chown(path.c_str(), kProviderUid, kProviderGid) == 0,
            "chown provider root");
    require(::chmod(path.c_str(), 0700) == 0, "chmod provider root");
}

[[nodiscard]] int open_root(const int base_fd, const char* leaf) noexcept {
    return ::openat(base_fd, leaf,
                    O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
}

[[nodiscard]] std::optional<PrincipalCell> create_cell(
    const int base_fd, const char* root_leaf) noexcept {
    const int root_fd = open_root(base_fd, root_leaf);
    if (root_fd < 0) return std::nullopt;
    int error_number = 0;
    auto cell = PrincipalCell::create_fixed_beneath(
        root_fd, kProviderUid, error_number);
    const int close_result = ::close(root_fd);
    if (close_result != 0) return std::nullopt;
    return cell;
}

[[nodiscard]] int enum_value(const StageDisposition value) noexcept {
    return static_cast<int>(value);
}
[[nodiscard]] int enum_value(const BurnDisposition value) noexcept {
    return static_cast<int>(value);
}
[[nodiscard]] int enum_value(const PendingDisposition value) noexcept {
    return static_cast<int>(value);
}
[[nodiscard]] int enum_value(const AppendDisposition value) noexcept {
    return static_cast<int>(value);
}
[[nodiscard]] int enum_value(const ExactRecordDisposition value) noexcept {
    return static_cast<int>(value);
}

[[nodiscard]] ProviderReport provider_run(
    const int base_fd, const EncodedRecord& pending) {
    ProviderReport report;
    report.no_new_privs = ::prctl(PR_GET_NO_NEW_PRIVS, 0L, 0L, 0L, 0L);
    const EncodedRecord result_v1 = record_bytes(
        RecordKind::result, 1U, Result::uncertain);
    const EncodedRecord publication_v1 = record_bytes(
        RecordKind::publication, 1U, Result::uncertain);
    const EncodedRecord result_v2 = record_bytes(
        RecordKind::result, 2U, Result::effect);
    const EncodedRecord publication_v2 = record_bytes(
        RecordKind::publication, 2U, Result::effect);
    const EncodedRecord result_v1_exact = record_bytes(
        RecordKind::result, 1U, Result::effect);

    {
        auto cell = create_cell(base_fd, "vertical");
        report.factory = cell.has_value() ? 1 : 0;
        if (!cell.has_value()) return report;
        report.stage = enum_value(cell->stage_pending_exact(pending).disposition);
        report.burn = enum_value(cell->burn_before_decode().disposition);
        report.pending_query = enum_value(
            cell->query_pending_exact(pending).disposition);
        report.result_v1 = enum_value(
            cell->append_result_exact(result_v1).disposition);
        report.result_v1_query = enum_value(
            cell->query_result_exact(1U, result_v1).disposition);
        report.publication_v1 = enum_value(
            cell->append_publication_exact(publication_v1).disposition);
        report.publication_v1_query = enum_value(
            cell->query_publication_exact(1U, publication_v1).disposition);
        report.result_v2 = enum_value(
            cell->append_result_exact(result_v2).disposition);
        report.result_v2_query = enum_value(
            cell->query_result_exact(2U, result_v2).disposition);
        report.publication_v2 = enum_value(
            cell->append_publication_exact(publication_v2).disposition);
        report.publication_v2_query = enum_value(
            cell->query_publication_exact(2U, publication_v2).disposition);
        report.duplicate_result_v1 = enum_value(
            cell->append_result_exact(result_v1).disposition);
        report.duplicate_result_v1_query = enum_value(
            cell->query_result_exact(1U, result_v1).disposition);
        report.wrong_kind = enum_value(
            cell->append_result_exact(publication_v1).disposition);
    }
    {
        auto cell = create_cell(base_fd, "v2-without-v1");
        if (cell.has_value()) {
            report.result_v2_without_v1 = enum_value(
                cell->append_result_exact(result_v2).disposition);
        }
    }
    {
        auto cell = create_cell(base_fd, "publication-without-result");
        if (cell.has_value()) {
            report.publication_without_result = enum_value(
                cell->append_publication_exact(publication_v1).disposition);
        }
    }
    {
        auto cell = create_cell(base_fd, "exact-v1");
        if (cell.has_value()) {
            report.exact_v1 = enum_value(
                cell->append_result_exact(result_v1_exact).disposition);
            report.v2_after_exact_v1 = enum_value(
                cell->append_result_exact(result_v2).disposition);
        }
    }
    {
        auto cell = create_cell(base_fd, "stage-residue");
        if (cell.has_value()) {
            const int root_fd = open_root(base_fd, "stage-residue");
            if (root_fd >= 0) {
                const int cell_fd = ::openat(
                    root_fd, kProviderCellLeaf,
                    O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
                if (cell_fd >= 0) {
                    const int stage_fd = ::openat(
                        cell_fd, kResultStageV1Leaf,
                        O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW,
                        S_IRUSR);
                    if (stage_fd >= 0) close_or_exit(stage_fd);
                    close_or_exit(cell_fd);
                }
                close_or_exit(root_fd);
            }
            report.stage_residue = enum_value(
                cell->append_result_exact(result_v1).disposition);
        }
    }
    {
        auto cell = create_cell(base_fd, "same-uid");
        if (cell.has_value()) {
            const StageResult stage = cell->stage_pending_exact(pending);
            const BurnResult burn = cell->burn_before_decode();
            report.same_uid_prepared =
                stage.disposition == StageDisposition::staged_and_synced
                && burn.namespace_bound() ? 1 : 0;
        }
    }
    return report;
}

[[nodiscard]] ProviderReport run_provider_child(
    const int base_fd, const EncodedRecord& pending) {
    int report_pipe[2]{};
    require(::pipe2(report_pipe, O_CLOEXEC) == 0, "provider report pipe");
    const pid_t child = ::fork();
    require(child >= 0, "fork provider child");
    if (child == 0) {
        close_or_exit(report_pipe[0]);
        drop_to(kProviderUid, kProviderGid);
        const ProviderReport report = provider_run(base_fd, pending);
        write_exact(report_pipe[1], &report, sizeof(report));
        close_or_exit(report_pipe[1]);
        _exit(0);
    }
    require(::close(report_pipe[1]) == 0, "close provider writer parent");
    ProviderReport report;
    read_exact(report_pipe[0], &report, sizeof(report));
    require(::close(report_pipe[0]) == 0, "close provider reader parent");
    int status = 0;
    require(::waitpid(child, &status, 0) == child
            && WIFEXITED(status) && WEXITSTATUS(status) == 0,
            "provider child success");
    return report;
}

[[nodiscard]] WorkloadReport run_workload_attacks(const int base_fd) {
    int report_pipe[2]{};
    require(::pipe2(report_pipe, O_CLOEXEC) == 0, "workload report pipe");
    const pid_t child = ::fork();
    require(child >= 0, "fork workload child");
    if (child == 0) {
        close_or_exit(report_pipe[0]);
        drop_to(kWorkloadUid, kWorkloadGid);
        WorkloadReport report;
        constexpr char root[] = "vertical";
        constexpr char pending[] = "vertical/cell/pending";
        constexpr char alias[] = "workload/alias";
        constexpr char renamed[] = "workload/renamed";
        int fd = ::openat(base_fd, root,
                          O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
        report.root_open_errno = fd < 0 ? errno : 0;
        if (fd >= 0) close_or_exit(fd);
        fd = ::openat(base_fd, pending, O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
        report.leaf_open_errno = fd < 0 ? errno : 0;
        if (fd >= 0) close_or_exit(fd);
        report.link_errno = ::linkat(base_fd, pending, base_fd, alias, 0) != 0
            ? errno : 0;
        report.rename_errno = ::renameat(base_fd, pending, base_fd, renamed) != 0
            ? errno : 0;
        report.unlink_errno = ::unlinkat(base_fd, pending, 0) != 0 ? errno : 0;
        write_exact(report_pipe[1], &report, sizeof(report));
        close_or_exit(report_pipe[1]);
        _exit(0);
    }
    require(::close(report_pipe[1]) == 0, "close workload writer parent");
    WorkloadReport report;
    read_exact(report_pipe[0], &report, sizeof(report));
    require(::close(report_pipe[0]) == 0, "close workload reader parent");
    int status = 0;
    require(::waitpid(child, &status, 0) == child
            && WIFEXITED(status) && WEXITSTATUS(status) == 0,
            "workload child success");
    return report;
}

[[nodiscard]] bool same_uid_mutates(const int base_fd) {
    constexpr char pending[] = "same-uid/cell/pending";
    const pid_t child = ::fork();
    require(child >= 0, "fork same uid child");
    if (child == 0) {
        drop_to(kProviderUid, kProviderGid);
        if (::fchmodat(base_fd, pending, S_IRUSR | S_IWUSR, 0) != 0) _exit(131);
        const int fd = ::openat(base_fd, pending,
                                O_WRONLY | O_CLOEXEC | O_NOFOLLOW);
        if (fd < 0) _exit(132);
        const std::uint8_t changed = 0x58U;
        if (::pwrite(fd, &changed, 1U, 0) != 1) _exit(133);
        if (::fsync(fd) != 0) _exit(134);
        close_or_exit(fd);
        _exit(0);
    }
    int status = 0;
    require(::waitpid(child, &status, 0) == child, "wait same uid child");
    return WIFEXITED(status) && WEXITSTATUS(status) == 0;
}

[[nodiscard]] bool leaked_fd_survives_uid_drop(const int base_fd) {
    int create_fd = ::openat(base_fd, "leaked-fd/object",
                             O_RDWR | O_CREAT | O_EXCL | O_CLOEXEC
                                 | O_NOFOLLOW,
                             0600);
    require(create_fd >= 0, "create leaked-fd object");
    require(::fchown(create_fd, kProviderUid, kProviderGid) == 0,
            "chown leaked-fd object");
    const std::uint8_t initial = 0x41U;
    require(::write(create_fd, &initial, 1U) == 1, "seed leaked-fd object");
    require(::fsync(create_fd) == 0, "sync leaked-fd object");
    const pid_t child = ::fork();
    require(child >= 0, "fork leaked fd child");
    if (child == 0) {
        drop_to(kWorkloadUid, kWorkloadGid);
        const std::uint8_t changed = 0x42U;
        if (::pwrite(create_fd, &changed, 1U, 0) != 1) _exit(141);
        if (::fsync(create_fd) != 0) _exit(142);
        close_or_exit(create_fd);
        _exit(0);
    }
    int status = 0;
    require(::waitpid(child, &status, 0) == child, "wait leaked fd child");
    const bool child_ok = WIFEXITED(status) && WEXITSTATUS(status) == 0;
    std::uint8_t observed = 0U;
    require(::pread(create_fd, &observed, 1U, 0) == 1,
            "read leaked-fd object");
    require(::close(create_fd) == 0, "close leaked-fd object");
    return child_ok && observed == 0x42U;
}

[[nodiscard]] bool root_override_reads(const int base_fd) {
    const int fd = ::openat(base_fd, "vertical/cell/pending",
                            O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
    if (fd < 0) return false;
    std::array<std::uint8_t, 1U> byte{};
    const bool read_ok = ::read(fd, byte.data(), byte.size()) == 1;
    const bool close_ok = ::close(fd) == 0;
    return read_ok && close_ok;
}

void write_principal_rows(const std::filesystem::path& output,
                          const std::vector<PrincipalRow>& rows) {
    std::ofstream stream(output / "principal-cases.tsv", std::ios::binary);
    require(stream.good(), "open principal-cases.tsv");
    stream << "case\tobservation\tpassed\tretained_counterexample\tjudgment\n";
    for (const auto& row : rows) {
        stream << row.name << '\t' << row.observation << '\t'
               << bool_text(row.passed) << '\t'
               << bool_text(row.retained_counterexample) << '\t'
               << row.judgment << '\n';
    }
}

void write_publication_rows(const std::filesystem::path& output,
                            const std::vector<PublicationRow>& rows) {
    std::ofstream stream(output / "publication-cases.tsv", std::ios::binary);
    require(stream.good(), "open publication-cases.tsv");
    stream << "case\tappend\tquery\tversion\tretained_counterexample"
              "\tjudgment\n";
    for (const auto& row : rows) {
        stream << row.name << '\t' << row.append << '\t' << row.query << '\t'
               << row.version << '\t'
               << bool_text(row.retained_counterexample) << '\t'
               << row.judgment << '\n';
    }
}

void write_counterexamples(const std::filesystem::path& output,
                           const std::vector<CounterexampleRow>& rows) {
    std::ofstream stream(output / "principal-counterexamples.tsv",
                         std::ios::binary);
    require(stream.good(), "open principal-counterexamples.tsv");
    stream << "counterexample\treproduced\tdefeats\tretained_law\n";
    for (const auto& row : rows) {
        stream << row.name << '\t' << bool_text(row.reproduced) << '\t'
               << row.defeats << '\t' << row.retained_law << '\n';
    }
}

void write_summary(const std::filesystem::path& output,
                   const std::size_t principal_cases,
                   const std::size_t publication_cases,
                   const std::size_t counterexamples) {
    std::ofstream stream(output / "principal-summary.json", std::ios::binary);
    require(stream.good(), "open principal-summary.json");
    stream
        << "{\n"
        << "  \"authority_granted\": false,\n"
        << "  \"authenticated_provider\": false,\n"
        << "  \"cloudtainer_role\": \"HOST_LAB_ONLY\",\n"
        << "  \"counterexamples\": " << counterexamples << ",\n"
        << "  \"descriptor_topology_proved\": false,\n"
        << "  \"distinct_uid_path_attacks_denied\": true,\n"
        << "  \"external_rollback_floor\": false,\n"
        << "  \"fixed_cell_leaf\": \"cell\",\n"
        << "  \"immutable_publication_versions_observed\": 2,\n"
        << "  \"no_new_privs_observed\": true,\n"
        << "  \"principal_cases\": " << principal_cases << ",\n"
        << "  \"provider_uid\": 21001,\n"
        << "  \"publication_cases\": " << publication_cases << ",\n"
        << "  \"root_equivalent_administration_excluded\": false,\n"
        << "  \"schema\": \"slopos.rev0888.handoff-principal-publication.v1\",\n"
        << "  \"stable_media_proved\": false,\n"
        << "  \"status\": \"PASS\",\n"
        << "  \"workload_uid\": 21002\n"
        << "}\n";
}

}  // namespace

PrincipalCampaignCounts run_principal_campaign(
    const std::filesystem::path& output,
    const std::filesystem::path& scratch,
    const EncodedRecord& pending) {
    require(::geteuid() == 0,
            "principal campaign requires euid 0 only to create two disposable numeric principals");
    const auto base = scratch / "principal";
    require(std::filesystem::create_directory(base), "create principal scratch");
    require(::chmod(base.c_str(), 0711) == 0,
            "make principal scratch searchable without listing");
    for (const char* name : {"vertical", "v2-without-v1",
                             "publication-without-result", "exact-v1",
                             "stage-residue", "same-uid", "leaked-fd"}) {
        make_provider_root(base / name);
    }
    const auto workload_root = base / "workload";
    require(std::filesystem::create_directory(workload_root),
            "create workload root");
    require(::chown(workload_root.c_str(), kWorkloadUid, kWorkloadGid) == 0,
            "chown workload root");
    require(::chmod(workload_root.c_str(), 0700) == 0,
            "chmod workload root");
    const int base_fd = ::open(base.c_str(),
                               O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
    require(base_fd >= 0, "open principal scratch descriptor");

    const ProviderReport provider = run_provider_child(base_fd, pending);
    require(provider.factory == 1, "principal factory");
    require(provider.no_new_privs == 1, "provider no_new_privs");
    require(provider.stage == enum_value(StageDisposition::staged_and_synced),
            "principal stage");
    require(provider.burn == enum_value(BurnDisposition::bound_and_synced)
            || provider.burn
                == enum_value(BurnDisposition::bound_sync_uncertain),
            "principal burn");
    require(provider.pending_query
                == enum_value(PendingDisposition::exact_pending),
            "principal pending query");

    const WorkloadReport workload = run_workload_attacks(base_fd);
    const bool path_denied = workload.root_open_errno == EACCES
        && workload.leaf_open_errno == EACCES;
    const bool namespace_denied = workload.link_errno == EACCES
        && workload.rename_errno == EACCES
        && workload.unlink_errno == EACCES;
    require(path_denied, "distinct uid path denial");
    require(namespace_denied, "distinct uid namespace denial");

    const bool same_uid = same_uid_mutates(base_fd);
    const bool leaked_fd = leaked_fd_survives_uid_drop(base_fd);
    const bool root_override = root_override_reads(base_fd);
    require(provider.same_uid_prepared == 1 && same_uid,
            "same uid counterexample");
    require(leaked_fd, "leaked descriptor counterexample");
    require(root_override, "root override counterexample");
    require(::close(base_fd) == 0, "close principal scratch descriptor");

    const auto append_ok = [](const int value) {
        return value == enum_value(AppendDisposition::bound_and_synced)
            || value
                == enum_value(AppendDisposition::bound_sync_uncertain);
    };
    require(append_ok(provider.result_v1), "result v1 append");
    require(provider.result_v1_query
                == enum_value(ExactRecordDisposition::exact),
            "result v1 query");
    require(append_ok(provider.publication_v1), "publication v1 append");
    require(provider.publication_v1_query
                == enum_value(ExactRecordDisposition::exact),
            "publication v1 query");
    require(append_ok(provider.result_v2), "result v2 append");
    require(provider.result_v2_query
                == enum_value(ExactRecordDisposition::exact),
            "result v2 query");
    require(append_ok(provider.publication_v2), "publication v2 append");
    require(provider.publication_v2_query
                == enum_value(ExactRecordDisposition::exact),
            "publication v2 query");
    require(provider.duplicate_result_v1
                == enum_value(AppendDisposition::final_exists),
            "duplicate result no replace");
    require(provider.duplicate_result_v1_query
                == enum_value(ExactRecordDisposition::exact),
            "duplicate preserves exact result");
    require(provider.result_v2_without_v1
                == enum_value(AppendDisposition::missing_predecessor),
            "v2 requires v1");
    require(provider.publication_without_result
                == enum_value(AppendDisposition::missing_predecessor),
            "publication requires result");
    require(append_ok(provider.exact_v1), "exact v1 append");
    require(provider.v2_after_exact_v1
                == enum_value(AppendDisposition::refinement_rejected),
            "only uncertain refines");
    require(provider.stage_residue
                == enum_value(AppendDisposition::stage_exists),
            "stage residue fails stop");
    require(provider.wrong_kind
                == enum_value(AppendDisposition::wrong_record_kind),
            "wrong kind rejection");

    std::vector<PrincipalRow> principal_rows{
        {"provider_creates_fixed_owner_only_cell",
         "uid=21001 mode=0700 fixed_leaf=cell no_new_privs=true", true,
         false, "SCOPED_PROVIDER_PRINCIPAL_OBSERVED"},
        {"distinct_workload_cannot_open_provider_root",
         "open_root=EACCES", path_denied, false,
         "DAC_PATH_SEARCH_CLOSED_FOR_DECLARED_WORKLOAD_UID"},
        {"distinct_workload_cannot_open_pending_leaf",
         "open_pending=EACCES", path_denied, false,
         "NO_WORKLOAD_READ_OR_WRITE_PATH"},
        {"distinct_workload_cannot_link_rename_or_unlink",
         "link=EACCES rename=EACCES unlink=EACCES", namespace_denied, false,
         "NO_WORKLOAD_NAMESPACE_MUTATION_PATH"},
        {"same_uid_peer_can_chmod_and_mutate",
         "same_uid_write=true", same_uid, true,
         "UID_SEPARATION_IS_A_REQUIRED_PREMISE"},
        {"inherited_writable_fd_survives_uid_drop",
         "post_setresuid_pwrite=true", leaked_fd, true,
         "EXACT_DESCRIPTOR_TABLE_IS_A_REQUIRED_PREMISE"},
        {"root_equivalent_actor_bypasses_owner_only_mode",
         "root_open=true", root_override, true,
         "ADMINISTRATION_PLANE_REMAINS_OUTSIDE_DAC_CLAIM"},
    };

    std::vector<PublicationRow> publication_rows{
        {"append_uncertain_result_v1", append_name(
             static_cast<AppendDisposition>(provider.result_v1)),
         exact_record_name(static_cast<ExactRecordDisposition>(
             provider.result_v1_query)), 1U, false,
         "IMMUTABLE_UNCERTAIN_RESULT_BOUND"},
        {"publish_uncertain_v1_after_result", append_name(
             static_cast<AppendDisposition>(provider.publication_v1)),
         exact_record_name(static_cast<ExactRecordDisposition>(
             provider.publication_v1_query)), 1U, false,
         "PUBLICATION_REQUIRES_EXACT_RESULT"},
        {"append_exact_result_v2_after_uncertain_v1", append_name(
             static_cast<AppendDisposition>(provider.result_v2)),
         exact_record_name(static_cast<ExactRecordDisposition>(
             provider.result_v2_query)), 2U, false,
         "UNCERTAINTY_REFINED_WITHOUT_OVERWRITE"},
        {"publish_exact_v2_after_publication_v1", append_name(
             static_cast<AppendDisposition>(provider.publication_v2)),
         exact_record_name(static_cast<ExactRecordDisposition>(
             provider.publication_v2_query)), 2U, false,
         "BOTH_PUBLICATION_VERSIONS_RETAINED"},
        {"duplicate_result_v1_fails_no_replace", append_name(
             static_cast<AppendDisposition>(provider.duplicate_result_v1)),
         exact_record_name(static_cast<ExactRecordDisposition>(
             provider.duplicate_result_v1_query)), 1U, false,
         "EXISTING_RESULT_PRESERVED"},
        {"result_v2_without_v1_fails_stop", append_name(
             static_cast<AppendDisposition>(provider.result_v2_without_v1)),
         "NOT_QUERIED", 2U, false, "REFINEMENT_PREDECESSOR_REQUIRED"},
        {"publication_without_result_fails_stop", append_name(
             static_cast<AppendDisposition>(provider.publication_without_result)),
         "NOT_QUERIED", 1U, false, "PUBLICATION_CANNOT_INVENT_RESULT"},
        {"exact_v1_cannot_be_rewritten_as_v2", append_name(
             static_cast<AppendDisposition>(provider.v2_after_exact_v1)),
         "V1_RETAINED", 2U, false,
         "ONLY_UNCERTAIN_V1_MAY_REFINE"},
        {"staging_residue_requires_separate_repair", append_name(
             static_cast<AppendDisposition>(provider.stage_residue)),
         "NO_MUTATING_RECOVERY", 1U, false,
         "PROTOCOL_RECONCILIATION_DOES_NOT_CLEAN_STORAGE"},
        {"publication_record_rejected_by_result_api", append_name(
             static_cast<AppendDisposition>(provider.wrong_kind)),
         "NOT_QUERIED", 1U, false,
         "RESULT_AND_PUBLICATION_KINDS_REMAIN_DISTINCT"},
    };

    std::vector<CounterexampleRow> counterexamples{
        {"same_uid_peer_mutates_owner_file", same_uid,
         "claim that mode 0700 alone separates mutually untrusted same-UID processes",
         "provider and workload require distinct principals or a stronger boundary"},
        {"writable_descriptor_survives_uid_drop", leaked_fd,
         "claim that later credential narrowing revokes an already-open writable descriptor",
         "launch must construct an exact descriptor table before untrusted execution"},
        {"root_equivalent_actor_bypasses_dac", root_override,
         "claim that discretionary owner-only mode closes the administration plane",
         "root-equivalent and capability-bearing actors remain in the provider threat model"},
    };

    require(principal_rows.size() == 7U, "principal case inventory");
    require(publication_rows.size() == 10U, "publication case inventory");
    require(counterexamples.size() == 3U, "principal counterexample inventory");
    write_principal_rows(output, principal_rows);
    write_publication_rows(output, publication_rows);
    write_counterexamples(output, counterexamples);
    write_summary(output, principal_rows.size(), publication_rows.size(),
                  counterexamples.size());
    return {principal_rows.size(), publication_rows.size(),
            counterexamples.size()};
}

}  // namespace slopos::e0::handoff_cell::harness
