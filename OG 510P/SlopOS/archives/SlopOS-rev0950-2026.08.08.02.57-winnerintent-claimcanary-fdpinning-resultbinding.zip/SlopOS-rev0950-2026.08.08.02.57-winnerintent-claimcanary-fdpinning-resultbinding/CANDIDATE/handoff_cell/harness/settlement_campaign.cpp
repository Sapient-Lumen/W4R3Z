#include "settlement_campaign.hpp"

#include "slopos/e0/handoff_cell/cell.hpp"
#include "slopos/e0/handoff_cell/endpoint_claim.hpp"
#include "slopos/e0/handoff_cell/hosted_settlement.hpp"

#include <algorithm>
#include <array>
#include <atomic>
#include <cerrno>
#include <csignal>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <stdexcept>
#include <string>
#include <thread>
#include <type_traits>
#include <utility>
#include <vector>

#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

namespace slopos::e0::handoff_cell::harness {
namespace {

using generation_journal::EncodedRecord;
using generation_journal::Record;
using generation_journal::RecordKind;
using generation_journal::Result;

static_assert(std::is_copy_constructible_v<SettlementObservation>);
static_assert(!std::is_copy_constructible_v<ClaimedPending>);

struct UniqueFd final {
    int value{-1};
    UniqueFd() = default;
    explicit UniqueFd(const int fd) noexcept : value(fd) {}
    UniqueFd(const UniqueFd&) = delete;
    UniqueFd& operator=(const UniqueFd&) = delete;
    UniqueFd(UniqueFd&& other) noexcept : value(other.value) {
        other.value = -1;
    }
    UniqueFd& operator=(UniqueFd&& other) noexcept {
        if (this != &other) {
            if (value >= 0) (void)::close(value);
            value = other.value;
            other.value = -1;
        }
        return *this;
    }
    ~UniqueFd() {
        if (value >= 0) (void)::close(value);
    }
};

struct CaseRow final {
    std::string name;
    std::string immediate;
    std::string reconciled;
    std::string evidence;
    unsigned int submits{0U};
    unsigned int queries{0U};
    unsigned int effects{0U};
    bool request_examined{false};
    bool query_only{true};
    bool response_authority{false};
    bool retry_authority{false};
    bool retained_counterexample{false};
    std::string judgment;
};

struct CounterexampleRow final {
    std::string name;
    bool reproduced{false};
    std::string defeats;
    std::string retained_law;
};

struct CrashRow final {
    std::string cut;
    std::string provider_state;
    unsigned int submits{0U};
    unsigned int effects{0U};
    std::string reopen_claim;
    std::string settlement;
    std::string evidence;
    bool query_only{true};
    bool retry_authority{false};
};

[[noreturn]] void fail(const std::string& detail) {
    throw std::runtime_error(detail);
}

void require(const bool condition, const std::string& detail) {
    if (!condition) fail(detail);
}

[[nodiscard]] std::string bool_text(const bool value) {
    return value ? "true" : "false";
}

void put_u32(EndpointRequest& request, const std::size_t offset,
             const std::uint32_t value) noexcept {
    for (std::size_t index = 0U; index < 4U; ++index) {
        request[offset + index] = static_cast<std::uint8_t>(
            value >> static_cast<unsigned int>(index * 8U));
    }
}

void put_u64(EndpointRequest& request, const std::size_t offset,
             const std::uint64_t value) noexcept {
    for (std::size_t index = 0U; index < 8U; ++index) {
        request[offset + index] = static_cast<std::uint8_t>(
            value >> static_cast<unsigned int>(index * 8U));
    }
}

[[nodiscard]] EndpointRequest make_request(const EncodedRecord& pending) {
    Record record;
    require(generation_journal::decode_record(pending, record)
                && record.kind == RecordKind::pending,
            "decode settlement request fixture");
    EndpointRequest request{};
    constexpr std::array<std::uint8_t, 8U> magic{
        'S', 'L', 'O', 'P', 'E', 'P', 'C', '1'};
    std::copy(magic.begin(), magic.end(), request.begin());
    put_u32(request, 8U, 1U);
    put_u64(request, 16U, record.generation_from);
    put_u64(request, 24U, record.generation_to);
    std::copy(record.operation_binding.begin(), record.operation_binding.end(),
              request.begin() + 32);
    std::copy(record.spent_receipt_binding.begin(),
              record.spent_receipt_binding.end(), request.begin() + 64);
    return request;
}

[[nodiscard]] EncodedRecord make_result(
    const EncodedRecord& pending, const Result result) {
    Record record;
    require(generation_journal::decode_record(pending, record)
                && record.kind == RecordKind::pending,
            "decode settlement result fixture");
    record.kind = RecordKind::result;
    record.result = result;
    if (result == Result::uncertain) {
        record.sequence = 1U;
        record.reconciled = false;
    } else {
        record.sequence = 2U;
        record.reconciled = true;
    }
    EncodedRecord encoded{};
    require(generation_journal::encode_record(record, encoded),
            "encode settlement result fixture");
    return encoded;
}

[[nodiscard]] EncodedRecord make_foreign_result(
    const EncodedRecord& pending) {
    Record record;
    require(generation_journal::decode_record(pending, record),
            "decode foreign result fixture");
    record.kind = RecordKind::result;
    record.sequence = 2U;
    record.result = Result::effect;
    record.reconciled = true;
    record.operation_binding[0U] ^= 0x5aU;
    EncodedRecord encoded{};
    require(generation_journal::encode_record(record, encoded),
            "encode foreign result fixture");
    return encoded;
}

[[nodiscard]] std::filesystem::path make_cell(
    const std::filesystem::path& scratch, const std::string& name) {
    const auto path = scratch / ("settlement-" + name);
    require(std::filesystem::create_directory(path),
            "create settlement cell " + name);
    require(::chmod(path.c_str(), static_cast<mode_t>(0700)) == 0,
            "chmod settlement cell " + name);
    return path;
}

[[nodiscard]] UniqueFd open_directory(const std::filesystem::path& path) {
    const int fd = ::open(path.c_str(), O_RDONLY | O_DIRECTORY | O_CLOEXEC);
    require(fd >= 0, "open settlement directory");
    return UniqueFd(fd);
}

void write_complete(const int fd, const EncodedRecord& bytes) {
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const ssize_t count = ::write(
            fd, bytes.data() + offset, bytes.size() - offset);
        if (count < 0 && errno == EINTR) continue;
        require(count > 0, "write settlement fixture");
        offset += static_cast<std::size_t>(count);
    }
}

void write_pending(const int directory_fd, const EncodedRecord& pending) {
    UniqueFd fd(::openat(directory_fd, kPendingLeaf,
                         O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC,
                         S_IRUSR | S_IWUSR));
    require(fd.value >= 0, "open settlement pending fixture");
    write_complete(fd.value, pending);
    require(::fdatasync(fd.value) == 0, "fdatasync settlement pending");
    require(::fchmod(fd.value, S_IRUSR) == 0,
            "chmod settlement pending read-only");
    require(::fsync(directory_fd) == 0, "fsync settlement directory");
}

[[nodiscard]] EndpointClaimCell retain_claim(const int directory_fd) {
    int error_number = 0;
    auto cell = EndpointClaimCell::retain_host_cell_directory(
        directory_fd, ::geteuid(), error_number);
    require(cell.has_value(),
            "retain settlement claim errno=" + std::to_string(error_number));
    return std::move(*cell);
}

[[nodiscard]] EndpointClaimAttempt fresh_claim(
    const std::filesystem::path& scratch, const std::string& name,
    const EncodedRecord& pending) {
    const auto path = make_cell(scratch, name);
    const UniqueFd directory = open_directory(path);
    write_pending(directory.value, pending);
    EndpointClaimCell cell = retain_claim(directory.value);
    EndpointClaimAttempt attempt = cell.claim_pending_exact(pending);
    require(attempt.fresh.has_value()
                && attempt.observation.disposition
                    == EndpointClaimDisposition::claimed_exact,
            "fresh settlement claim " + name);
    return attempt;
}

enum class ScriptMode : std::uint8_t {
    effect_return,
    no_effect_return,
    effect_drop_reply,
    no_effect_drop_reply,
    drop_before_commit,
    malformed_after_effect,
    foreign_after_effect,
    uncertain_return,
    fail_stop_return,
};

enum class ProviderState : std::uint8_t {
    unused,
    effect,
    no_effect,
    uncertain,
    fail_stop,
};

class ScriptedProvider final : public HostedSettlementProvider {
public:
    ScriptedProvider(const EncodedRecord& pending, const ScriptMode mode)
        : pending_(pending), mode_(mode) {}

    [[nodiscard]] ProviderSubmitReply submit_exact(
        const EncodedRecord& expected_pending) noexcept override {
        std::lock_guard<std::mutex> lock(mutex_);
        ++submit_calls_;
        if (expected_pending != pending_) {
            return {ProviderSubmitDisposition::malformed_return, {}};
        }
        if (state_ != ProviderState::unused) {
            ++duplicate_submits_;
            return {ProviderSubmitDisposition::exact_record,
                    encoded_state_locked()};
        }
        if (mode_ == ScriptMode::drop_before_commit) {
            return {ProviderSubmitDisposition::no_return, {}};
        }

        switch (mode_) {
            case ScriptMode::effect_return:
            case ScriptMode::effect_drop_reply:
            case ScriptMode::malformed_after_effect:
            case ScriptMode::foreign_after_effect:
                state_ = ProviderState::effect;
                ++effect_count_;
                break;
            case ScriptMode::no_effect_return:
            case ScriptMode::no_effect_drop_reply:
                state_ = ProviderState::no_effect;
                break;
            case ScriptMode::uncertain_return:
                state_ = ProviderState::uncertain;
                break;
            case ScriptMode::fail_stop_return:
                state_ = ProviderState::fail_stop;
                break;
            case ScriptMode::drop_before_commit:
                break;
        }
        ++fresh_commits_;

        if (mode_ == ScriptMode::effect_drop_reply
            || mode_ == ScriptMode::no_effect_drop_reply) {
            return {ProviderSubmitDisposition::no_return, {}};
        }
        if (mode_ == ScriptMode::malformed_after_effect) {
            EncodedRecord malformed = encoded_state_locked();
            malformed[124U] ^= 0x01U;
            return {ProviderSubmitDisposition::malformed_return, malformed};
        }
        if (mode_ == ScriptMode::foreign_after_effect) {
            return {ProviderSubmitDisposition::exact_record,
                    make_foreign_result(pending_)};
        }
        return {ProviderSubmitDisposition::exact_record,
                encoded_state_locked()};
    }

    [[nodiscard]] ProviderQueryReply query_exact(
        const EncodedRecord& expected_pending) noexcept override {
        std::lock_guard<std::mutex> lock(mutex_);
        ++query_calls_;
        if (expected_pending != pending_) {
            return {ProviderQueryDisposition::malformed_return, {}};
        }
        if (!query_available_) {
            return {ProviderQueryDisposition::unavailable, {}};
        }
        if (query_malformed_) {
            EncodedRecord malformed{};
            malformed[0U] = 0x7fU;
            return {ProviderQueryDisposition::malformed_return, malformed};
        }
        if (state_ == ProviderState::unused) {
            return {ProviderQueryDisposition::exact_unused, {}};
        }
        return {ProviderQueryDisposition::exact_record,
                encoded_state_locked()};
    }

    void set_query_available(const bool value) noexcept {
        std::lock_guard<std::mutex> lock(mutex_);
        query_available_ = value;
    }

    void set_query_malformed(const bool value) noexcept {
        std::lock_guard<std::mutex> lock(mutex_);
        query_malformed_ = value;
    }

    void forget_terminal_record() noexcept {
        std::lock_guard<std::mutex> lock(mutex_);
        state_ = ProviderState::unused;
    }

    [[nodiscard]] unsigned int submit_calls() const noexcept {
        std::lock_guard<std::mutex> lock(mutex_);
        return submit_calls_;
    }
    [[nodiscard]] unsigned int query_calls() const noexcept {
        std::lock_guard<std::mutex> lock(mutex_);
        return query_calls_;
    }
    [[nodiscard]] unsigned int effect_count() const noexcept {
        std::lock_guard<std::mutex> lock(mutex_);
        return effect_count_;
    }
    [[nodiscard]] unsigned int fresh_commits() const noexcept {
        std::lock_guard<std::mutex> lock(mutex_);
        return fresh_commits_;
    }
    [[nodiscard]] unsigned int duplicate_submits() const noexcept {
        std::lock_guard<std::mutex> lock(mutex_);
        return duplicate_submits_;
    }

private:
    [[nodiscard]] EncodedRecord encoded_state_locked() const noexcept {
        switch (state_) {
            case ProviderState::effect:
                return make_result(pending_, Result::effect);
            case ProviderState::no_effect:
                return make_result(pending_, Result::no_effect);
            case ProviderState::uncertain:
                return make_result(pending_, Result::uncertain);
            case ProviderState::fail_stop:
                return make_result(pending_, Result::fail_stop);
            case ProviderState::unused:
                return {};
        }
        return {};
    }

    EncodedRecord pending_{};
    ScriptMode mode_{ScriptMode::effect_return};
    mutable std::mutex mutex_{};
    ProviderState state_{ProviderState::unused};
    bool query_available_{true};
    bool query_malformed_{false};
    unsigned int submit_calls_{0U};
    unsigned int query_calls_{0U};
    unsigned int effect_count_{0U};
    unsigned int fresh_commits_{0U};
    unsigned int duplicate_submits_{0U};
};

struct SharedProviderState final {
    int state{0};
    unsigned int submit_calls{0U};
    unsigned int effect_count{0U};
};

class SharedProvider final : public HostedSettlementProvider {
public:
    SharedProvider(const EncodedRecord& pending, SharedProviderState* state,
                   const int desired_state, const int signal_fd,
                   const bool block_after_commit) noexcept
        : pending_(pending), state_(state), desired_state_(desired_state),
          signal_fd_(signal_fd), block_after_commit_(block_after_commit) {}

    static void signal_for_harness(const int fd, const char value) noexcept {
        write_one(fd, value);
    }

    [[nodiscard]] ProviderSubmitReply submit_exact(
        const EncodedRecord& expected_pending) noexcept override {
        (void)__atomic_add_fetch(
            &state_->submit_calls, 1U, __ATOMIC_SEQ_CST);
        if (expected_pending != pending_) {
            return {ProviderSubmitDisposition::malformed_return, {}};
        }
        int expected_state = 0;
        if (__atomic_compare_exchange_n(
                &state_->state, &expected_state, desired_state_, false,
                __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST)
            && desired_state_ == 1) {
            (void)__atomic_add_fetch(
                &state_->effect_count, 1U, __ATOMIC_SEQ_CST);
        }
        if (signal_fd_ >= 0) write_one(signal_fd_, 'C');
        if (block_after_commit_) {
            for (;;) ::pause();
        }
        return {ProviderSubmitDisposition::exact_record,
                encoded_state()};
    }

    [[nodiscard]] ProviderQueryReply query_exact(
        const EncodedRecord& expected_pending) noexcept override {
        if (expected_pending != pending_) {
            return {ProviderQueryDisposition::malformed_return, {}};
        }
        const int state = __atomic_load_n(&state_->state, __ATOMIC_SEQ_CST);
        if (state == 0) {
            return {ProviderQueryDisposition::exact_unused, {}};
        }
        return {ProviderQueryDisposition::exact_record, encoded_state()};
    }

private:
    static void write_one(const int fd, const char value) noexcept {
        ssize_t count = -1;
        do {
            count = ::write(fd, &value, 1U);
        } while (count < 0 && errno == EINTR);
        if (count != 1) _exit(151);
    }

    [[nodiscard]] EncodedRecord encoded_state() const noexcept {
        const int state = __atomic_load_n(&state_->state, __ATOMIC_SEQ_CST);
        if (state == 1) return make_result(pending_, Result::effect);
        if (state == 2) return make_result(pending_, Result::no_effect);
        if (state == 3) return make_result(pending_, Result::uncertain);
        return {};
    }

    EncodedRecord pending_{};
    SharedProviderState* state_{nullptr};
    int desired_state_{1};
    int signal_fd_{-1};
    bool block_after_commit_{false};
};

[[nodiscard]] char read_one(const int fd) {
    char value = '\0';
    ssize_t count = -1;
    do {
        count = ::read(fd, &value, 1U);
    } while (count < 0 && errno == EINTR);
    require(count == 1, "read settlement crash marker");
    return value;
}

void wait_killed(const pid_t child) {
    int status = 0;
    require(::waitpid(child, &status, 0) == child,
            "wait settlement crash child");
    require(WIFSIGNALED(status) && WTERMSIG(status) == SIGKILL,
            "settlement child must die at scheduled cut");
}

[[nodiscard]] CrashRow run_crash_cut(
    const std::filesystem::path& scratch,
    const std::string& name,
    const int phase,
    const EncodedRecord& pending,
    const EndpointRequest& request) {
    const auto path = make_cell(scratch, "crash-" + name);
    const UniqueFd directory = open_directory(path);
    write_pending(directory.value, pending);

    auto* shared = static_cast<SharedProviderState*>(::mmap(
        nullptr, sizeof(SharedProviderState),
        PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0));
    require(shared != MAP_FAILED, "mmap settlement provider state");
    *shared = SharedProviderState{};

    int pipe_fds[2]{};
    require(::pipe2(pipe_fds, O_CLOEXEC) == 0,
            "create settlement crash pipe");
    UniqueFd reader(pipe_fds[0]);
    UniqueFd writer(pipe_fds[1]);

    const pid_t child = ::fork();
    require(child >= 0, "fork settlement crash child");
    if (child == 0) {
        (void)::close(reader.value);
        try {
            EndpointClaimCell cell = retain_claim(directory.value);
            EndpointClaimAttempt attempt = cell.claim_pending_exact(pending);
            if (!attempt.fresh.has_value()) _exit(152);
            if (phase == 0) {
                SharedProvider::signal_for_harness(writer.value, 'K');
                for (;;) ::pause();
            }
            const int desired = phase == 1 ? 1 : phase == 2 ? 2 : 3;
            SharedProvider provider(
                pending, shared, desired, writer.value, true);
            (void)HostedSettlement::settle_exact(
                std::move(*attempt.fresh), request, provider);
            _exit(153);
        } catch (...) {
            _exit(154);
        }
    }
    (void)::close(writer.value);
    writer.value = -1;
    (void)read_one(reader.value);
    require(::kill(child, SIGKILL) == 0,
            "kill settlement crash child");
    wait_killed(child);

    EndpointClaimCell reopened = retain_claim(directory.value);
    EndpointClaimAttempt duplicate = reopened.claim_pending_exact(pending);
    require(!duplicate.fresh.has_value()
                && duplicate.observation.disposition
                    == EndpointClaimDisposition::already_claimed_exact,
            "settlement crash reopen query-only");

    SharedProvider provider(pending, shared, 1, -1, false);
    const SettlementObservation settlement =
        HostedSettlement::reconcile_exact(pending, provider);
    const int state = __atomic_load_n(&shared->state, __ATOMIC_SEQ_CST);
    const unsigned int submits = __atomic_load_n(
        &shared->submit_calls, __ATOMIC_SEQ_CST);
    const unsigned int effects = __atomic_load_n(
        &shared->effect_count, __ATOMIC_SEQ_CST);

    const SettlementDisposition expected = phase == 0
        ? SettlementDisposition::no_effect
        : phase == 1 ? SettlementDisposition::effect
        : phase == 2 ? SettlementDisposition::no_effect
                     : SettlementDisposition::uncertain;
    require(settlement.disposition == expected
                && settlement.provider_query_called
                && !settlement.provider_submit_called
                && settlement.query_only
                && !settlement.retry_authority,
            "settlement crash reconciliation");
    require(::munmap(shared, sizeof(SharedProviderState)) == 0,
            "munmap settlement provider state");

    const std::string state_name = state == 0 ? "UNUSED"
        : state == 1 ? "EFFECT"
        : state == 2 ? "NO_EFFECT" : "UNCERTAIN";
    return {
        name,
        state_name,
        submits,
        effects,
        endpoint_claim_name(duplicate.observation.disposition),
        settlement_name(settlement.disposition),
        settlement_evidence_name(settlement.evidence),
        settlement.query_only,
        settlement.retry_authority,
    };
}

void write_cases(const std::filesystem::path& output,
                 const std::vector<CaseRow>& rows) {
    std::ofstream stream(output / "settlement-cases.tsv", std::ios::binary);
    require(stream.good(), "open settlement-cases.tsv");
    stream
        << "case\timmediate\treconciled\tevidence\tsubmits\tqueries\teffects"
           "\trequest_examined\tquery_only\tresponse_authority"
           "\tretry_authority\tretained_counterexample\tjudgment\n";
    for (const CaseRow& row : rows) {
        stream << row.name << '\t' << row.immediate << '\t'
               << row.reconciled << '\t' << row.evidence << '\t'
               << row.submits << '\t' << row.queries << '\t'
               << row.effects << '\t' << bool_text(row.request_examined)
               << '\t' << bool_text(row.query_only) << '\t'
               << bool_text(row.response_authority) << '\t'
               << bool_text(row.retry_authority) << '\t'
               << bool_text(row.retained_counterexample) << '\t'
               << row.judgment << '\n';
    }
}

void write_counterexamples(
    const std::filesystem::path& output,
    const std::vector<CounterexampleRow>& rows) {
    std::ofstream stream(
        output / "settlement-counterexamples.tsv", std::ios::binary);
    require(stream.good(), "open settlement-counterexamples.tsv");
    stream << "counterexample\treproduced\tdefeats\tretained_law\n";
    for (const CounterexampleRow& row : rows) {
        stream << row.name << '\t' << bool_text(row.reproduced) << '\t'
               << row.defeats << '\t' << row.retained_law << '\n';
    }
}

void write_crash_cuts(const std::filesystem::path& output,
                      const std::vector<CrashRow>& rows) {
    std::ofstream stream(
        output / "settlement-crash-cuts.tsv", std::ios::binary);
    require(stream.good(), "open settlement-crash-cuts.tsv");
    stream
        << "cut\tprovider_state\tsubmits\teffects\treopen_claim\tsettlement"
           "\tevidence\tquery_only\tretry_authority\n";
    for (const CrashRow& row : rows) {
        stream << row.cut << '\t' << row.provider_state << '\t'
               << row.submits << '\t' << row.effects << '\t'
               << row.reopen_claim << '\t' << row.settlement << '\t'
               << row.evidence << '\t' << bool_text(row.query_only) << '\t'
               << bool_text(row.retry_authority) << '\n';
    }
}

void write_race(const std::filesystem::path& output,
                const unsigned int contenders,
                const unsigned int local_claims,
                const ScriptedProvider& provider,
                const unsigned int settled_effects) {
    std::ofstream stream(
        output / "settlement-races.tsv", std::ios::binary);
    require(stream.good(), "open settlement-races.tsv");
    stream
        << "race\tcontenders\tlocal_fresh_claims\tprovider_submits"
           "\tprovider_fresh_commits\tprovider_duplicates\teffects"
           "\tsettled_effect_observations\n"
        << "sixteen_coherent_claim_histories_one_shared_provider\t"
        << contenders << '\t' << local_claims << '\t'
        << provider.submit_calls() << '\t' << provider.fresh_commits() << '\t'
        << provider.duplicate_submits() << '\t' << provider.effect_count()
        << '\t' << settled_effects << '\n';
}

void write_summary(const std::filesystem::path& output,
                   const std::size_t cases,
                   const std::size_t counterexamples,
                   const std::size_t crash_cuts,
                   const ScriptedProvider& race_provider,
                   const unsigned int race_contenders,
                   const unsigned int race_local_claims,
                   const unsigned int race_settled_effects) {
    std::ofstream stream(
        output / "settlement-summary.json", std::ios::binary);
    require(stream.good(), "open settlement-summary.json");
    stream
        << "{\n"
        << "  \"authority_granted\": false,\n"
        << "  \"cases\": " << cases << ",\n"
        << "  \"counterexamples\": " << counterexamples << ",\n"
        << "  \"crash_cuts\": " << crash_cuts << ",\n"
        << "  \"exact_provider_identity_proved\": false,\n"
        << "  \"external_rollback_floor\": false,\n"
        << "  \"hosted_settlement_adapter_implemented\": true,\n"
        << "  \"independent_reopen\": false,\n"
        << "  \"protected_effect\": false,\n"
        << "  \"protected_settlement\": false,\n"
        << "  \"query_recovery_submit_calls\": 0,\n"
        << "  \"race_contenders\": " << race_contenders << ",\n"
        << "  \"race_effects\": " << race_provider.effect_count() << ",\n"
        << "  \"race_local_fresh_claims\": " << race_local_claims << ",\n"
        << "  \"race_provider_duplicates\": "
        << race_provider.duplicate_submits() << ",\n"
        << "  \"race_provider_fresh_commits\": "
        << race_provider.fresh_commits() << ",\n"
        << "  \"race_provider_submits\": "
        << race_provider.submit_calls() << ",\n"
        << "  \"race_settled_effect_observations\": "
        << race_settled_effects << ",\n"
        << "  \"response_authority\": false,\n"
        << "  \"retry_authority\": false,\n"
        << "  \"schema\": \"slopos.rev0896.hosted-settlement-campaign.v1\",\n"
        << "  \"status\": \"PASS\",\n"
        << "  \"uncertainty_is_retry_permission\": false\n"
        << "}\n";
}

[[nodiscard]] CaseRow row_from(
    const std::string& name,
    const SettlementObservation& immediate,
    const SettlementObservation* reconciled,
    const ScriptedProvider& provider,
    const bool retained_counterexample,
    const std::string& judgment) {
    return {
        name,
        settlement_name(immediate.disposition),
        reconciled == nullptr ? "NOT_QUERIED"
                              : settlement_name(reconciled->disposition),
        reconciled == nullptr
            ? settlement_evidence_name(immediate.evidence)
            : settlement_evidence_name(reconciled->evidence),
        provider.submit_calls(),
        provider.query_calls(),
        provider.effect_count(),
        immediate.request_examined,
        reconciled == nullptr ? immediate.query_only : reconciled->query_only,
        reconciled == nullptr ? immediate.response_authority
                              : reconciled->response_authority,
        reconciled == nullptr ? immediate.retry_authority
                              : reconciled->retry_authority,
        retained_counterexample,
        judgment,
    };
}

}  // namespace

SettlementCampaignCounts run_settlement_campaign(
    const std::filesystem::path& output,
    const std::filesystem::path& scratch,
    const EncodedRecord& pending) {
    const EndpointRequest request = make_request(pending);
    std::vector<CaseRow> rows;
    std::vector<CounterexampleRow> counterexamples;
    std::vector<CrashRow> crash_rows;

    {
        EndpointClaimAttempt claim = fresh_claim(
            scratch, "effect-return", pending);
        ScriptedProvider provider(pending, ScriptMode::effect_return);
        const SettlementObservation immediate = HostedSettlement::settle_exact(
            std::move(*claim.fresh), request, provider);
        require(immediate.effect_confirmed()
                    && provider.submit_calls() == 1U
                    && provider.effect_count() == 1U
                    && immediate.query_only
                    && !immediate.response_authority
                    && !immediate.retry_authority,
                "exact effect settlement");
        rows.push_back(row_from(
            "exact_effect_return", immediate, nullptr, provider, false,
            "ONE_SUBMISSION_EFFECT_RESULT_QUERY_ONLY"));
    }

    {
        EndpointClaimAttempt claim = fresh_claim(
            scratch, "no-effect-return", pending);
        ScriptedProvider provider(pending, ScriptMode::no_effect_return);
        const SettlementObservation immediate = HostedSettlement::settle_exact(
            std::move(*claim.fresh), request, provider);
        require(immediate.no_effect_confirmed()
                    && provider.submit_calls() == 1U
                    && provider.effect_count() == 0U,
                "exact no-effect settlement");
        rows.push_back(row_from(
            "exact_no_effect_return", immediate, nullptr, provider, false,
            "ONE_SUBMISSION_NO_EFFECT_RESULT_QUERY_ONLY"));
    }

    {
        EndpointClaimAttempt claim = fresh_claim(
            scratch, "malformed-request", pending);
        EndpointRequest malformed = request;
        malformed[0U] ^= 0x01U;
        ScriptedProvider provider(pending, ScriptMode::effect_return);
        const SettlementObservation immediate = HostedSettlement::settle_exact(
            std::move(*claim.fresh), malformed, provider);
        require(immediate.disposition
                    == SettlementDisposition::malformed_request
                    && provider.submit_calls() == 0U
                    && provider.effect_count() == 0U,
                "malformed request cannot submit");
        rows.push_back(row_from(
            "malformed_request_burns_without_submit", immediate, nullptr,
            provider, false, "CLAIM_BURN_PRECEDES_REJECTION_NO_PROVIDER_CALL"));
    }

    {
        EndpointClaimAttempt claim = fresh_claim(
            scratch, "spent-claim", pending);
        ScriptedProvider provider(pending, ScriptMode::effect_return);
        ClaimedPending token = std::move(*claim.fresh);
        const SettlementObservation first = HostedSettlement::settle_exact(
            std::move(token), request, provider);
        const SettlementObservation second = HostedSettlement::settle_exact(
            std::move(token), request, provider);
        require(first.effect_confirmed()
                    && second.disposition
                        == SettlementDisposition::claim_missing_or_spent
                    && provider.submit_calls() == 1U
                    && provider.effect_count() == 1U,
                "spent claim cannot resubmit");
        rows.push_back(row_from(
            "spent_claim_second_call_no_submit", second, nullptr, provider,
            false, "LOCAL_ONE_USE_ADAPTER_NO_REPLAY"));
    }

    {
        EndpointClaimAttempt claim = fresh_claim(
            scratch, "effect-drop", pending);
        ScriptedProvider provider(pending, ScriptMode::effect_drop_reply);
        const SettlementObservation immediate = HostedSettlement::settle_exact(
            std::move(*claim.fresh), request, provider);
        const SettlementObservation reconciled =
            HostedSettlement::reconcile_exact(pending, provider);
        require(immediate.bounded_uncertain()
                    && reconciled.effect_confirmed()
                    && provider.submit_calls() == 1U
                    && provider.query_calls() == 1U
                    && provider.effect_count() == 1U,
                "effect reply loss reconciliation");
        rows.push_back(row_from(
            "effect_reply_lost_then_query_effect", immediate, &reconciled,
            provider, false, "NONRETURN_IS_UNCERTAIN_QUERY_REFINES_EFFECT"));
    }

    {
        EndpointClaimAttempt claim = fresh_claim(
            scratch, "no-effect-drop", pending);
        ScriptedProvider provider(pending, ScriptMode::no_effect_drop_reply);
        const SettlementObservation immediate = HostedSettlement::settle_exact(
            std::move(*claim.fresh), request, provider);
        const SettlementObservation reconciled =
            HostedSettlement::reconcile_exact(pending, provider);
        require(immediate.bounded_uncertain()
                    && reconciled.no_effect_confirmed()
                    && provider.submit_calls() == 1U
                    && provider.effect_count() == 0U,
                "no-effect reply loss reconciliation");
        rows.push_back(row_from(
            "no_effect_reply_lost_then_query_no_effect",
            immediate, &reconciled, provider, false,
            "NONRETURN_IS_UNCERTAIN_QUERY_REFINES_NO_EFFECT"));
    }

    {
        EndpointClaimAttempt claim = fresh_claim(
            scratch, "precommit-drop", pending);
        ScriptedProvider provider(pending, ScriptMode::drop_before_commit);
        const SettlementObservation immediate = HostedSettlement::settle_exact(
            std::move(*claim.fresh), request, provider);
        const SettlementObservation reconciled =
            HostedSettlement::reconcile_exact(pending, provider);
        require(immediate.bounded_uncertain()
                    && reconciled.no_effect_confirmed()
                    && reconciled.evidence
                        == SettlementEvidence::query_exact_unused
                    && provider.submit_calls() == 1U
                    && provider.effect_count() == 0U,
                "precommit loss exact-unused reconciliation");
        rows.push_back(row_from(
            "precommit_reply_lost_then_exact_unused", immediate, &reconciled,
            provider, false, "EXACT_UNUSED_SETTLES_NO_EFFECT_WITHOUT_RETRY"));
    }

    {
        EndpointClaimAttempt claim = fresh_claim(
            scratch, "malformed-return", pending);
        ScriptedProvider provider(pending, ScriptMode::malformed_after_effect);
        const SettlementObservation immediate = HostedSettlement::settle_exact(
            std::move(*claim.fresh), request, provider);
        const SettlementObservation reconciled =
            HostedSettlement::reconcile_exact(pending, provider);
        require(immediate.bounded_uncertain()
                    && reconciled.effect_confirmed()
                    && provider.effect_count() == 1U,
                "malformed return after effect is uncertainty");
        rows.push_back(row_from(
            "malformed_return_after_effect_then_query", immediate,
            &reconciled, provider, true,
            "MALFORMED_RETURN_IS_UNCERTAINTY_NOT_DENIAL"));
        counterexamples.push_back({
            "malformed_return_can_follow_committed_effect", true,
            "claim that malformed response proves no effect",
            "preserve uncertainty until an exact provider query refines it",
        });
    }

    {
        EndpointClaimAttempt claim = fresh_claim(
            scratch, "foreign-return", pending);
        ScriptedProvider provider(pending, ScriptMode::foreign_after_effect);
        const SettlementObservation immediate = HostedSettlement::settle_exact(
            std::move(*claim.fresh), request, provider);
        const SettlementObservation reconciled =
            HostedSettlement::reconcile_exact(pending, provider);
        require(immediate.bounded_uncertain()
                    && immediate.evidence
                        == SettlementEvidence::foreign_or_invalid_result
                    && reconciled.effect_confirmed()
                    && provider.effect_count() == 1U,
                "foreign result after effect is uncertainty");
        rows.push_back(row_from(
            "foreign_result_after_effect_then_query", immediate, &reconciled,
            provider, true, "FOREIGN_RESULT_NEVER_FLATTENS_TO_NO_EFFECT"));
    }

    {
        EndpointClaimAttempt claim = fresh_claim(
            scratch, "uncertain-return", pending);
        ScriptedProvider provider(pending, ScriptMode::uncertain_return);
        const SettlementObservation immediate = HostedSettlement::settle_exact(
            std::move(*claim.fresh), request, provider);
        const SettlementObservation reconciled =
            HostedSettlement::reconcile_exact(pending, provider);
        require(immediate.bounded_uncertain()
                    && reconciled.bounded_uncertain()
                    && provider.submit_calls() == 1U
                    && provider.query_calls() == 1U,
                "exact uncertainty remains uncertainty");
        rows.push_back(row_from(
            "exact_uncertain_record_persists", immediate, &reconciled,
            provider, false, "UNCERTAINTY_IS_FIRST_CLASS_STABLE_RESULT"));
    }

    {
        EndpointClaimAttempt claim = fresh_claim(
            scratch, "query-unavailable", pending);
        ScriptedProvider provider(pending, ScriptMode::effect_drop_reply);
        const SettlementObservation immediate = HostedSettlement::settle_exact(
            std::move(*claim.fresh), request, provider);
        provider.set_query_available(false);
        const SettlementObservation reconciled =
            HostedSettlement::reconcile_exact(pending, provider);
        require(immediate.bounded_uncertain()
                    && reconciled.bounded_uncertain()
                    && reconciled.evidence
                        == SettlementEvidence::query_unavailable
                    && provider.submit_calls() == 1U
                    && provider.effect_count() == 1U,
                "unavailable query preserves uncertainty");
        rows.push_back(row_from(
            "query_unavailable_preserves_uncertainty", immediate, &reconciled,
            provider, false, "UNAVAILABLE_QUERY_NEVER_MINTS_RETRY"));
    }

    {
        EndpointClaimAttempt claim = fresh_claim(
            scratch, "fail-stop", pending);
        ScriptedProvider provider(pending, ScriptMode::fail_stop_return);
        const SettlementObservation immediate = HostedSettlement::settle_exact(
            std::move(*claim.fresh), request, provider);
        require(immediate.disposition == SettlementDisposition::fail_stop
                    && provider.submit_calls() == 1U
                    && provider.effect_count() == 0U,
                "exact fail-stop result");
        rows.push_back(row_from(
            "exact_fail_stop_result", immediate, nullptr, provider, false,
            "FAIL_STOP_RESULT_QUERY_ONLY_NO_RETRY"));
    }

    {
        ScriptedProvider provider(pending, ScriptMode::effect_return);
        EndpointClaimAttempt claim = fresh_claim(
            scratch, "copy-reconcile-seed", pending);
        const SettlementObservation immediate = HostedSettlement::settle_exact(
            std::move(*claim.fresh), request, provider);
        require(immediate.effect_confirmed(), "copy reconcile seed");
        const SettlementObservation a =
            HostedSettlement::reconcile_exact(pending, provider);
        const SettlementObservation b = a;
        const SettlementObservation c =
            HostedSettlement::reconcile_exact(pending, provider);
        require(a.effect_confirmed() && b.effect_confirmed()
                    && c.effect_confirmed()
                    && provider.submit_calls() == 1U
                    && provider.query_calls() == 2U
                    && provider.effect_count() == 1U
                    && a.query_only && b.query_only && c.query_only
                    && !a.retry_authority && !b.retry_authority
                    && !c.retry_authority,
                "copied recovery observations remain powerless");
        rows.push_back(row_from(
            "copied_reconciliation_observations_no_submit", c, nullptr,
            provider, false, "COPYABLE_RESULTS_NEVER_AUTHORIZE_SUBMISSION"));
    }

    {
        EncodedRecord invalid = pending;
        invalid[0U] ^= 0x01U;
        ScriptedProvider provider(pending, ScriptMode::effect_return);
        const SettlementObservation observed =
            HostedSettlement::reconcile_exact(invalid, provider);
        require(observed.disposition == SettlementDisposition::fail_stop
                    && observed.evidence
                        == SettlementEvidence::invalid_expected_pending
                    && provider.submit_calls() == 0U
                    && provider.query_calls() == 0U,
                "invalid expected pending fails before query");
        rows.push_back(row_from(
            "invalid_expected_pending_fails_before_query", observed, nullptr,
            provider, false, "INVALID_IDENTITY_NO_PROVIDER_CONTACT"));
    }

    constexpr unsigned int contenders = 16U;
    ScriptedProvider race_provider(pending, ScriptMode::effect_return);
    std::atomic<unsigned int> ready{0U};
    std::atomic<bool> go{false};
    std::atomic<unsigned int> local_claims{0U};
    std::atomic<unsigned int> settled_effects{0U};
    std::vector<std::filesystem::path> race_paths;
    race_paths.reserve(contenders);
    for (unsigned int index = 0U; index < contenders; ++index) {
        const auto path = make_cell(
            scratch, "race-" + std::to_string(index));
        const UniqueFd directory = open_directory(path);
        write_pending(directory.value, pending);
        race_paths.push_back(path);
    }
    std::vector<std::thread> threads;
    threads.reserve(contenders);
    for (const auto& path : race_paths) {
        threads.emplace_back([&, path]() {
            ready.fetch_add(1U, std::memory_order_seq_cst);
            while (!go.load(std::memory_order_seq_cst)) {
                std::this_thread::yield();
            }
            const UniqueFd directory = open_directory(path);
            EndpointClaimCell cell = retain_claim(directory.value);
            EndpointClaimAttempt attempt = cell.claim_pending_exact(pending);
            if (!attempt.fresh.has_value()) return;
            local_claims.fetch_add(1U, std::memory_order_seq_cst);
            const SettlementObservation observed =
                HostedSettlement::settle_exact(
                    std::move(*attempt.fresh), request, race_provider);
            if (observed.effect_confirmed()) {
                settled_effects.fetch_add(1U, std::memory_order_seq_cst);
            }
        });
    }
    while (ready.load(std::memory_order_seq_cst) != contenders) {
        std::this_thread::yield();
    }
    go.store(true, std::memory_order_seq_cst);
    for (std::thread& thread : threads) thread.join();
    require(local_claims.load() == contenders
                && settled_effects.load() == contenders
                && race_provider.submit_calls() == contenders
                && race_provider.fresh_commits() == 1U
                && race_provider.duplicate_submits() == contenders - 1U
                && race_provider.effect_count() == 1U,
            "sixteen claim histories one shared provider");
    write_race(output, contenders, local_claims.load(), race_provider,
               settled_effects.load());

    {
        ScriptedProvider first(pending, ScriptMode::effect_return);
        ScriptedProvider second(pending, ScriptMode::effect_return);
        EndpointClaimAttempt a = fresh_claim(
            scratch, "provider-clone-a", pending);
        EndpointClaimAttempt b = fresh_claim(
            scratch, "provider-clone-b", pending);
        const SettlementObservation one = HostedSettlement::settle_exact(
            std::move(*a.fresh), request, first);
        const SettlementObservation two = HostedSettlement::settle_exact(
            std::move(*b.fresh), request, second);
        const bool reproduced = one.effect_confirmed()
            && two.effect_confirmed()
            && first.effect_count() + second.effect_count() == 2U;
        require(reproduced, "provider clone repeats effect");
        counterexamples.push_back({
            "coherent_provider_clones_each_commit_effect", true,
            "claim that client one-attempt ordering creates global one-use",
            "provider identity and nonrollback history must be protected outside the client",
        });
    }

    {
        ScriptedProvider provider(pending, ScriptMode::effect_return);
        EndpointClaimAttempt first_claim = fresh_claim(
            scratch, "eviction-first", pending);
        const SettlementObservation first = HostedSettlement::settle_exact(
            std::move(*first_claim.fresh), request, provider);
        provider.forget_terminal_record();
        EndpointClaimAttempt second_claim = fresh_claim(
            scratch, "eviction-second", pending);
        const SettlementObservation second = HostedSettlement::settle_exact(
            std::move(*second_claim.fresh), request, provider);
        const bool reproduced = first.effect_confirmed()
            && second.effect_confirmed()
            && provider.effect_count() == 2U;
        require(reproduced, "idempotency eviction repeats effect");
        counterexamples.push_back({
            "finite_idempotency_retention_reopens_exact_operation", true,
            "claim that a bounded deduplication window is permanent spend custody",
            "exact operation identity must remain consumed for the full governed lifetime",
        });
    }

    {
        ScriptedProvider first(pending, ScriptMode::effect_return);
        ScriptedProvider second(pending, ScriptMode::effect_return);
        EndpointClaimAttempt a = fresh_claim(
            scratch, "provider-identity-a", pending);
        EndpointClaimAttempt b = fresh_claim(
            scratch, "provider-identity-b", pending);
        const SettlementObservation one = HostedSettlement::settle_exact(
            std::move(*a.fresh), request, first);
        const SettlementObservation two = HostedSettlement::settle_exact(
            std::move(*b.fresh), request, second);
        const ProviderQueryReply q1 = first.query_exact(pending);
        const ProviderQueryReply q2 = second.query_exact(pending);
        const bool reproduced = one.effect_confirmed()
            && two.effect_confirmed()
            && q1.disposition == ProviderQueryDisposition::exact_record
            && q2.disposition == ProviderQueryDisposition::exact_record
            && q1.encoded == q2.encoded
            && first.effect_count() + second.effect_count() == 2U;
        require(reproduced, "byte-identical result provider ambiguity");
        counterexamples.push_back({
            "byte_identical_results_from_distinct_providers", true,
            "claim that exact result bytes authenticate provider identity or epoch",
            "the pending/result identity must bind an owner-admitted provider incarnation",
        });
    }

    crash_rows.push_back(run_crash_cut(
        scratch, "after_claim_before_submit", 0, pending, request));
    crash_rows.push_back(run_crash_cut(
        scratch, "after_effect_commit_before_reply", 1, pending, request));
    crash_rows.push_back(run_crash_cut(
        scratch, "after_no_effect_commit_before_reply", 2, pending, request));
    crash_rows.push_back(run_crash_cut(
        scratch, "after_uncertain_commit_before_reply", 3, pending, request));

    require(rows.size() == 14U, "settlement case inventory");
    require(counterexamples.size() == 4U,
            "settlement counterexample inventory");
    require(crash_rows.size() == 4U, "settlement crash inventory");

    write_cases(output, rows);
    write_counterexamples(output, counterexamples);
    write_crash_cuts(output, crash_rows);
    write_summary(output, rows.size(), counterexamples.size(), crash_rows.size(),
                  race_provider, contenders, local_claims.load(),
                  settled_effects.load());

    return {
        rows.size(),
        counterexamples.size(),
        crash_rows.size(),
        contenders,
        local_claims.load(),
        race_provider.fresh_commits(),
        race_provider.duplicate_submits(),
        race_provider.effect_count(),
    };
}

}  // namespace slopos::e0::handoff_cell::harness
