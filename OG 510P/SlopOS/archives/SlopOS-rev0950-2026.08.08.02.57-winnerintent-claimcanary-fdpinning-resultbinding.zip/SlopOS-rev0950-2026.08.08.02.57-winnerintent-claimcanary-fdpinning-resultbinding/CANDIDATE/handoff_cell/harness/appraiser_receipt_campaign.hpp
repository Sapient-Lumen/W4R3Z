#pragma once

#include <cstddef>
#include <filesystem>

namespace slopos::e0::handoff_cell::harness {

struct AppraiserReceiptCampaignCounts final {
    std::size_t cases{0U};
    std::size_t counterexamples{0U};
    std::size_t canonical_receipt_profiles{0U};
    std::size_t signed_statement_profiles{0U};
    std::size_t independent_appraisal_profiles{0U};
    std::size_t v13_eligible_profiles{0U};
    std::size_t mutation_rejections{0U};
};

[[nodiscard]] AppraiserReceiptCampaignCounts run_appraiser_receipt_campaign(
    const std::filesystem::path& output);

}  // namespace slopos::e0::handoff_cell::harness
