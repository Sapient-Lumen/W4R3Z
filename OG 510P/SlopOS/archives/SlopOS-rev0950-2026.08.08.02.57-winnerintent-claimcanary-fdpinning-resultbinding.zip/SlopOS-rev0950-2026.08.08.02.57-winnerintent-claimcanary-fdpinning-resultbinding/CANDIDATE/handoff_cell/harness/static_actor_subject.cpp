#include <cstddef>
#include <cstdint>

namespace {

constexpr long kSysRead = 0;
constexpr long kSysWrite = 1;
constexpr long kSysMmap = 9;
constexpr long kSysMprotect = 10;
constexpr long kSysSocket = 41;
constexpr long kSysConnect = 42;
constexpr long kSysSendto = 44;
constexpr long kSysRecvmsg = 47;
constexpr long kSysClone = 56;
constexpr long kSysExecve = 59;
constexpr long kSysPrctl = 157;
constexpr long kSysExitGroup = 231;
constexpr long kSysOpenat = 257;
constexpr long kSysSeccomp = 317;
constexpr long kSysMemfdCreate = 319;
constexpr long kSysExecveat = 322;
constexpr long kSysIoUringSetup = 425;

constexpr long kAtFdcwd = -100;
constexpr long kAtEmptyPath = 0x1000;
constexpr long kProtRead = 0x1;
constexpr long kProtExec = 0x4;
constexpr long kMapPrivate = 0x02;
constexpr long kMapAnonymous = 0x20;
constexpr long kPrSetSeccomp = 22;
constexpr long kSeccompModeFilter = 2;
constexpr int kInputFd = 3;
constexpr int kOutputFd = 4;
constexpr int kConsumedExecFd = 5;
constexpr std::uint64_t kInputMagic = 0x534c4f505631494eULL;
constexpr std::uint64_t kReportMagic = 0x534c4f5056315354ULL;
constexpr std::size_t kChallengeBytes = 32U;
constexpr std::size_t kCanaryPathBytes = 192U;

struct ActorInput final {
    std::uint64_t magic;
    std::uint8_t challenge[kChallengeBytes];
    char absolute_exec_canary[kCanaryPathBytes];
};
static_assert(sizeof(ActorInput) == 232U);

struct ActorReport final {
    std::uint64_t magic;
    std::uint8_t challenge[kChallengeBytes];
    std::uint8_t response[kChallengeBytes];
    std::int32_t openat_errno;
    std::int32_t socket_errno;
    std::int32_t connect_errno;
    std::int32_t sendto_errno;
    std::int32_t recvmsg_errno;
    std::int32_t clone_errno;
    std::int32_t mmap_exec_errno;
    std::int32_t mprotect_exec_errno;
    std::int32_t memfd_create_errno;
    std::int32_t execve_errno;
    std::int32_t execveat_closed_fd_errno;
    std::int32_t absolute_execveat_errno;
    std::int32_t seccomp_errno;
    std::int32_t prctl_seccomp_errno;
    std::int32_t io_uring_setup_errno;
    std::int32_t read_wrong_fd_errno;
    std::int32_t write_wrong_fd_errno;
};
static_assert(sizeof(ActorReport) == 144U);

[[nodiscard]] inline long syscall1(const long number, const long a0) noexcept {
    long result;
    asm volatile("syscall"
                 : "=a"(result)
                 : "a"(number), "D"(a0)
                 : "rcx", "r11", "memory");
    return result;
}

[[nodiscard]] inline long syscall2(const long number, const long a0,
                                   const long a1) noexcept {
    long result;
    asm volatile("syscall"
                 : "=a"(result)
                 : "a"(number), "D"(a0), "S"(a1)
                 : "rcx", "r11", "memory");
    return result;
}

[[nodiscard]] inline long syscall3(const long number, const long a0,
                                   const long a1, const long a2) noexcept {
    long result;
    asm volatile("syscall"
                 : "=a"(result)
                 : "a"(number), "D"(a0), "S"(a1), "d"(a2)
                 : "rcx", "r11", "memory");
    return result;
}

[[nodiscard]] inline long syscall4(const long number, const long a0,
                                   const long a1, const long a2,
                                   const long a3) noexcept {
    register long r10 asm("r10") = a3;
    long result;
    asm volatile("syscall"
                 : "=a"(result)
                 : "a"(number), "D"(a0), "S"(a1), "d"(a2), "r"(r10)
                 : "rcx", "r11", "memory");
    return result;
}

[[nodiscard]] inline long syscall5(const long number, const long a0,
                                   const long a1, const long a2,
                                   const long a3, const long a4) noexcept {
    register long r10 asm("r10") = a3;
    register long r8 asm("r8") = a4;
    long result;
    asm volatile("syscall"
                 : "=a"(result)
                 : "a"(number), "D"(a0), "S"(a1), "d"(a2), "r"(r10),
                   "r"(r8)
                 : "rcx", "r11", "memory");
    return result;
}

[[nodiscard]] inline long syscall6(const long number, const long a0,
                                   const long a1, const long a2,
                                   const long a3, const long a4,
                                   const long a5) noexcept {
    register long r10 asm("r10") = a3;
    register long r8 asm("r8") = a4;
    register long r9 asm("r9") = a5;
    long result;
    asm volatile("syscall"
                 : "=a"(result)
                 : "a"(number), "D"(a0), "S"(a1), "d"(a2), "r"(r10),
                   "r"(r8), "r"(r9)
                 : "rcx", "r11", "memory");
    return result;
}

[[nodiscard]] constexpr std::int32_t error_of(const long value) noexcept {
    return value < 0 && value >= -4095L
        ? static_cast<std::int32_t>(-value)
        : 0;
}

[[noreturn]] void terminate(const int code) noexcept {
    (void)syscall1(kSysExitGroup, static_cast<long>(code));
    __builtin_unreachable();
}

void read_exact(const int fd, std::uint8_t* bytes,
                const std::size_t size) noexcept {
    std::size_t offset = 0U;
    while (offset < size) {
        const long result = syscall3(
            kSysRead, static_cast<long>(fd),
            reinterpret_cast<long>(bytes + offset),
            static_cast<long>(size - offset));
        if (result <= 0) terminate(111);
        offset += static_cast<std::size_t>(result);
    }
}

void write_exact(const int fd, const void* data,
                 const std::size_t size) noexcept {
    const auto* bytes = static_cast<const std::uint8_t*>(data);
    std::size_t offset = 0U;
    while (offset < size) {
        const long result = syscall3(
            kSysWrite, static_cast<long>(fd),
            reinterpret_cast<long>(bytes + offset),
            static_cast<long>(size - offset));
        if (result <= 0) terminate(112);
        offset += static_cast<std::size_t>(result);
    }
}

[[nodiscard]] std::uint8_t transform(const std::uint8_t* challenge,
                                     const std::size_t index) noexcept {
    const std::size_t source = (index + 7U) % kChallengeBytes;
    return static_cast<std::uint8_t>(
        challenge[source] ^ static_cast<std::uint8_t>(0xA5U + index));
}

}  // namespace

extern "C" void* memset(void* destination, const int value,
                         const std::size_t size) noexcept {
    auto* bytes = static_cast<unsigned char*>(destination);
    for (std::size_t index = 0U; index < size; ++index) {
        bytes[index] = static_cast<unsigned char>(value);
    }
    return destination;
}

extern "C" [[noreturn, gnu::used, gnu::noinline]]
void slopos_actor_main() noexcept {
    ActorInput input{};
    read_exact(kInputFd, reinterpret_cast<std::uint8_t*>(&input), sizeof(input));
    if (input.magic != kInputMagic || input.absolute_exec_canary[0] != '/') {
        terminate(113);
    }
    bool path_terminated = false;
    for (std::size_t index = 1U; index < kCanaryPathBytes; ++index) {
        if (input.absolute_exec_canary[index] == '\0') {
            path_terminated = true;
            break;
        }
    }
    if (!path_terminated) terminate(114);

    ActorReport report{};
    report.magic = kReportMagic;
    for (std::size_t index = 0U; index < kChallengeBytes; ++index) {
        report.challenge[index] = input.challenge[index];
    }

    static constexpr char kEmpty[] = "";
    char* const empty_argv[] = {nullptr};
    char* const empty_envp[] = {nullptr};

    report.openat_errno = error_of(syscall4(
        kSysOpenat, kAtFdcwd, reinterpret_cast<long>(kEmpty), 0, 0));
    report.socket_errno = error_of(syscall3(kSysSocket, 1, 1, 0));
    report.connect_errno = error_of(syscall3(kSysConnect, -1, 0, 0));
    report.sendto_errno = error_of(syscall6(kSysSendto, -1, 0, 0, 0, 0, 0));
    report.recvmsg_errno = error_of(syscall3(kSysRecvmsg, kInputFd, 0, 0));
    report.clone_errno = error_of(syscall5(kSysClone, 0, 0, 0, 0, 0));
    report.mmap_exec_errno = error_of(syscall6(
        kSysMmap, 0, 4096, kProtRead | kProtExec,
        kMapPrivate | kMapAnonymous, -1, 0));
    report.mprotect_exec_errno = error_of(
        syscall3(kSysMprotect, 0, 4096, kProtExec));
    report.memfd_create_errno = error_of(syscall2(
        kSysMemfdCreate, reinterpret_cast<long>(kEmpty), 0));
    report.execve_errno = error_of(syscall3(
        kSysExecve, reinterpret_cast<long>(kEmpty),
        reinterpret_cast<long>(empty_argv),
        reinterpret_cast<long>(empty_envp)));
    report.execveat_closed_fd_errno = error_of(syscall5(
        kSysExecveat, kConsumedExecFd, reinterpret_cast<long>(kEmpty),
        reinterpret_cast<long>(empty_argv), reinterpret_cast<long>(empty_envp),
        kAtEmptyPath));
    report.absolute_execveat_errno = error_of(syscall5(
        kSysExecveat, kConsumedExecFd,
        reinterpret_cast<long>(input.absolute_exec_canary),
        reinterpret_cast<long>(empty_argv), reinterpret_cast<long>(empty_envp),
        kAtEmptyPath));
    report.seccomp_errno = error_of(syscall3(
        kSysSeccomp, kSeccompModeFilter, 0, 0));
    report.prctl_seccomp_errno = error_of(syscall5(
        kSysPrctl, kPrSetSeccomp, kSeccompModeFilter, 0, 0, 0));
    report.io_uring_setup_errno = error_of(syscall2(kSysIoUringSetup, 1, 0));
    report.read_wrong_fd_errno = error_of(syscall3(kSysRead, 0, 0, 0));
    report.write_wrong_fd_errno = error_of(syscall3(kSysWrite, 1, 0, 0));

    for (std::size_t index = 0U; index < kChallengeBytes; ++index) {
        report.response[index] = transform(input.challenge, index);
    }
    write_exact(kOutputFd, &report, sizeof(report));
    terminate(0);
}

// Linux enters an ELF process with %rsp 16-byte aligned. A compiler-generated
// C++ function expects the call-site convention instead: %rsp is aligned before
// CALL and is therefore 8 modulo 16 on function entry. Keep the raw ELF entry
// as an assembly-only shim so aligned local stores in the freestanding subject
// cannot fault merely because no C runtime supplied the usual startup frame.
extern "C" __attribute__((naked, noreturn, used)) void _start() noexcept {
    asm volatile(
        "andq $-16, %rsp\n\t"
        "call slopos_actor_main\n\t"
        "ud2\n\t");
}
