#pragma once

#include "slopos/e0/generation_journal/record.hpp"

#include <cstddef>
#include <filesystem>

namespace slopos::e0::handoff_cell::harness {

struct EndpointClaimCampaignCounts final {
    std::size_t cases{0U};
    std::size_t counterexamples{0U};
    std::size_t race_contenders{0U};
    std::size_t crash_cuts{0U};
};

[[nodiscard]] EndpointClaimCampaignCounts run_endpoint_claim_campaign(
    const std::filesystem::path& output,
    const std::filesystem::path& scratch,
    const generation_journal::EncodedRecord& pending);

}  // namespace slopos::e0::handoff_cell::harness
