#include "slopos/e0/handoff_cell/external_rollback_floor.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

#include <openssl/evp.h>
#include <sys/utsname.h>
#include <unistd.h>

namespace slopos::e0::handoff_cell::harness {
namespace {

constexpr std::array<std::uint8_t, 32U> kWitnessPrivateSeed{{
    0x4cU,0xcdU,0x08U,0x9bU,0x28U,0xffU,0x96U,0xdaU,
    0x9dU,0xb6U,0xc3U,0x46U,0xecU,0x11U,0x4eU,0x0fU,
    0x5bU,0x8aU,0x31U,0x9fU,0x35U,0xabU,0xa6U,0x24U,
    0xdaU,0x8cU,0xf6U,0xedU,0x4fU,0xb8U,0xa6U,0xfbU,
}};
using WitnessSignature = std::array<std::uint8_t, 64U>;

struct CaseRow final {
    std::string name;
    bool observed{false};
    bool expected{false};
    std::string detail;
};
struct CounterexampleRow final {
    std::string name;
    bool reproduced{false};
    std::string defeats;
    std::string retained_law;
};

[[noreturn]] void fail(const std::string& detail) {
    throw std::runtime_error(detail);
}
void require(const bool condition, const std::string& detail) {
    if (!condition) fail(detail);
}
[[nodiscard]] const char* boolean(const bool value) noexcept {
    return value ? "true" : "false";
}
[[nodiscard]] ExternalFloorDigest binding(const std::uint8_t base) noexcept {
    ExternalFloorDigest value{};
    for (std::size_t index = 0U; index < value.size(); ++index) {
        value[index] = static_cast<std::uint8_t>(
            static_cast<unsigned int>(base) + static_cast<unsigned int>(index));
    }
    return value;
}
[[nodiscard]] bool command_available(const std::string_view command) {
    const char* raw = std::getenv("PATH");
    if (raw == nullptr) return false;
    const std::string path(raw);
    std::size_t begin = 0U;
    while (begin <= path.size()) {
        const std::size_t end = path.find(':', begin);
        const std::string directory = path.substr(
            begin, end == std::string::npos ? std::string::npos : end - begin);
        const auto candidate =
            (directory.empty() ? std::filesystem::path(".")
                               : std::filesystem::path(directory)) / command;
        if (::access(candidate.c_str(), X_OK) == 0) return true;
        if (end == std::string::npos) break;
        begin = end + 1U;
    }
    return false;
}

[[nodiscard]] WitnessSignature sign_digest(const ExternalFloorDigest& digest) {
    WitnessSignature signature{};
    EVP_PKEY* key = EVP_PKEY_new_raw_private_key(
        EVP_PKEY_ED25519, nullptr, kWitnessPrivateSeed.data(),
        kWitnessPrivateSeed.size());
    require(key != nullptr, "create witness key");
    EVP_MD_CTX* context = EVP_MD_CTX_new();
    require(context != nullptr, "create witness signing context");
    std::size_t size = signature.size();
    const bool ok = EVP_DigestSignInit(
            context, nullptr, nullptr, nullptr, key) == 1
        && EVP_DigestSign(context, signature.data(), &size,
                          digest.data(), digest.size()) == 1;
    EVP_MD_CTX_free(context);
    EVP_PKEY_free(key);
    require(ok && size == signature.size(), "sign witness digest");
    return signature;
}

[[nodiscard]] bool verify_digest(const ExternalFloorDigest& digest,
                                 const WitnessSignature& signature) {
    EVP_PKEY* private_key = EVP_PKEY_new_raw_private_key(
        EVP_PKEY_ED25519, nullptr, kWitnessPrivateSeed.data(),
        kWitnessPrivateSeed.size());
    require(private_key != nullptr, "create witness private key");
    std::array<std::uint8_t, 32U> public_key{};
    std::size_t public_size = public_key.size();
    require(EVP_PKEY_get_raw_public_key(
                private_key, public_key.data(), &public_size) == 1
            && public_size == public_key.size(),
            "derive witness public key");
    EVP_PKEY_free(private_key);
    EVP_PKEY* key = EVP_PKEY_new_raw_public_key(
        EVP_PKEY_ED25519, nullptr, public_key.data(), public_key.size());
    require(key != nullptr, "create witness public key");
    EVP_MD_CTX* context = EVP_MD_CTX_new();
    require(context != nullptr, "create witness verify context");
    const bool ok = EVP_DigestVerifyInit(
            context, nullptr, nullptr, nullptr, key) == 1
        && EVP_DigestVerify(context, signature.data(), signature.size(),
                            digest.data(), digest.size()) == 1;
    EVP_MD_CTX_free(context);
    EVP_PKEY_free(key);
    return ok;
}

class RestorableWitness final {
public:
    RestorableWitness(const std::uint64_t generation,
                      const ExternalFloorDigest& head) noexcept
        : generation_(generation), head_(head) {}

    [[nodiscard]] bool compare_advance(
        const std::uint64_t expected_generation,
        const ExternalFloorDigest& expected_head,
        const std::uint64_t target_generation,
        const ExternalFloorDigest& target_head) noexcept {
        if (generation_ == target_generation && head_ == target_head) {
            return true;
        }
        if (generation_ != expected_generation || head_ != expected_head
            || target_generation != expected_generation + 1U) {
            return false;
        }
        generation_ = target_generation;
        head_ = target_head;
        return true;
    }

    [[nodiscard]] ExternalFloorDigest receipt_digest() const {
        std::array<std::uint8_t, 40U> bytes{};
        for (std::size_t index = 0U; index < 8U; ++index) {
            bytes[index] = static_cast<std::uint8_t>(
                (generation_ >> static_cast<unsigned int>(index * 8U)) & 0xffU);
        }
        std::copy(head_.begin(), head_.end(), bytes.begin() + 8);
        return generation_journal::sha256(
            std::span<const std::uint8_t>(bytes.data(), bytes.size()));
    }

private:
    std::uint64_t generation_{0U};
    ExternalFloorDigest head_{};
};

void write_cases(const std::filesystem::path& output,
                 const std::vector<CaseRow>& rows) {
    std::ofstream stream(output / "external-floor-host-cases.tsv", std::ios::binary);
    require(stream.good(), "open host cases");
    stream << "case\tobserved\texpected\tpass\tdetail\n";
    for (const CaseRow& row : rows) {
        stream << row.name << '\t' << boolean(row.observed) << '\t'
               << boolean(row.expected) << '\t'
               << boolean(row.observed == row.expected) << '\t'
               << row.detail << '\n';
    }
}

void write_counterexamples(const std::filesystem::path& output,
                           const std::vector<CounterexampleRow>& rows) {
    std::ofstream stream(output / "external-floor-host-counterexamples.tsv",
                         std::ios::binary);
    require(stream.good(), "open host counterexamples");
    stream << "counterexample\treproduced\tdefeats\tretained_law\n";
    for (const CounterexampleRow& row : rows) {
        stream << row.name << '\t' << boolean(row.reproduced) << '\t'
               << row.defeats << '\t' << row.retained_law << '\n';
    }
}

}  // namespace

int external_rollback_floor_probe_main(const std::filesystem::path& output) {
    std::filesystem::create_directories(output);

    generation_journal::SpendRecordV1 spend;
    spend.owner_epoch = 11U;
    spend.constructor_epoch = 29U;
    spend.spend_serial = 37U;
    spend.generation_from = 101U;
    spend.generation_to = 102U;
    spend.owner_statement = binding(0x10U);
    spend.constructor_image = binding(0x30U);
    spend.provider_subject = binding(0x50U);
    spend.publication_receipt = binding(0x70U);
    spend.expectation_record = binding(0x90U);
    spend.operation = binding(0xB0U);
    spend.pending_result = binding(0xD0U);
    spend.predecessor_head = binding(0x20U);
    EncodedReceiptSpendRecord encoded_spend{};
    require(generation_journal::encode_spend_record(spend, encoded_spend),
            "encode spend record");
    const auto candidate = make_external_floor_record(
        encoded_spend, binding(0x40U), binding(0x60U), binding(0x80U),
        binding(0xA0U), binding(0xC0U));
    require(candidate.has_value(), "make external floor record");
    const ExternalFloorDigest successor =
        tpm_nv_extend_successor(spend.predecessor_head, *candidate);

    const RestorableWitness pristine(spend.generation_from,
                                     spend.predecessor_head);
    RestorableWitness first_clone = pristine;
    RestorableWitness second_clone = pristine;
    RestorableWitness restored_copy = pristine;
    const bool first_advanced = first_clone.compare_advance(
        spend.generation_from, spend.predecessor_head,
        spend.generation_to, successor);
    const bool second_advanced = second_clone.compare_advance(
        spend.generation_from, spend.predecessor_head,
        spend.generation_to, successor);
    const bool restored_advanced = restored_copy.compare_advance(
        spend.generation_from, spend.predecessor_head,
        spend.generation_to, successor);
    const WitnessSignature first_signature = sign_digest(first_clone.receipt_digest());
    const WitnessSignature second_signature = sign_digest(second_clone.receipt_digest());
    const bool first_signature_valid = verify_digest(
        first_clone.receipt_digest(), first_signature);
    const bool second_signature_valid = verify_digest(
        second_clone.receipt_digest(), second_signature);
    const bool clone_signatures_identical = first_signature == second_signature;

    RestorableWitness same_history(spend.generation_from, spend.predecessor_head);
    const bool same_history_first = same_history.compare_advance(
        spend.generation_from, spend.predecessor_head,
        spend.generation_to, successor);
    const bool same_history_duplicate = same_history.compare_advance(
        spend.generation_from, spend.predecessor_head,
        spend.generation_to, successor);

    // Abstract the two irreversible transitions without pretending to operate
    // a TPM. TPM2_NV_Extend has no expected-old operand. A crash after either
    // first transition therefore leaves a split state that read-only recovery
    // can classify but cannot converge.
    ExternalFloorDigest tpm_head = spend.predecessor_head;
    ExternalFloorDigest witness_head = spend.predecessor_head;
    tpm_head = tpm_nv_extend_successor(tpm_head, *candidate);
    const bool tpm_ahead_witness_behind =
        tpm_head == successor && witness_head == spend.predecessor_head;
    const ExternalFloorDigest queried_tpm_head = tpm_head;
    const ExternalFloorDigest queried_witness_head = witness_head;
    const bool query_only_cannot_converge =
        queried_tpm_head != queried_witness_head
        && tpm_head == queried_tpm_head && witness_head == queried_witness_head;
    const ExternalFloorDigest second_successor =
        tpm_nv_extend_successor(tpm_head, *candidate);
    const bool stale_precert_second_extend_advances_again =
        second_successor != successor && second_successor != spend.predecessor_head;

    ExternalFloorDigest inverse_tpm_head = spend.predecessor_head;
    ExternalFloorDigest inverse_witness_head = successor;
    const bool witness_ahead_tpm_behind =
        inverse_witness_head == successor
        && inverse_tpm_head == spend.predecessor_head;

    witness_head = successor;
    const bool happy_path_heads_equal = tpm_head == witness_head;
    const bool complete_transcript_not_atomic =
        happy_path_heads_equal && tpm_ahead_witness_behind
        && witness_ahead_tpm_behind && query_only_cannot_converge;

    const bool tpm0_present = ::access("/dev/tpm0", F_OK) == 0;
    const bool tpmrm0_present = ::access("/dev/tpmrm0", F_OK) == 0;
    const bool tpm2_getcap_available = command_available("tpm2_getcap");
    const bool tpm2_nvreadpublic_available = command_available("tpm2_nvreadpublic");
    const bool tpm2_nvcertify_available = command_available("tpm2_nvcertify");
    const bool tpm2_nvextend_available = command_available("tpm2_nvextend");
    struct utsname host {};
    require(::uname(&host) == 0, "uname");

    ExternalRollbackFloorObservationV1 hosted;
    hosted.profile_supplied = true;
    const auto assessment = assess_external_rollback_floor(hosted);

    const std::vector<CaseRow> cases{{
        {"v19_record_constructed", candidate.has_value(), true, "canonical 288-byte append record"},
        {"nv_extend_successor_nonzero", !generation_journal::digest_is_zero(successor), true, "SHA256(old || record)"},
        {"first_clone_advanced", first_advanced, true, "restorable witness copy"},
        {"second_clone_advanced", second_advanced, true, "same predecessor accepted again"},
        {"restored_copy_advanced", restored_advanced, true, "snapshot replay"},
        {"both_clone_signatures_valid", first_signature_valid && second_signature_valid, true, "same cloned seed"},
        {"clone_signatures_identical", clone_signatures_identical, true, "deterministic Ed25519 under same key"},
        {"same_history_first_advanced", same_history_first, true, "one local history"},
        {"same_history_duplicate_queryable", same_history_duplicate, true, "already-current local observation"},
        {"tpm_success_witness_predecessor_fracture", tpm_ahead_witness_behind, true, "crash cut after extend"},
        {"query_only_split_state_stable", query_only_cannot_converge, true, "observation cannot finish the edge"},
        {"stale_precert_second_extend_advances_again", stale_precert_second_extend_advances_again, true, "no expected-old operand"},
        {"witness_success_tpm_predecessor_fracture", witness_ahead_tpm_behind, true, "inverse ordering only moves cut"},
        {"happy_path_heads_equal", happy_path_heads_equal, true, "both endpoint writes completed"},
        {"complete_transcript_not_atomic", complete_transcript_not_atomic, true, "happy path does not close crash cuts"},
        {"dual_ledger_transcript_operated", false, false, "abstract counterproof only"},
        {"query_only_cross_ledger_recovery_bound", assessment.query_only_cross_ledger_recovery_bound, false, "no convergence authority"},
        {"tpm0_present", tpm0_present, false, "host device observation"},
        {"tpmrm0_present", tpmrm0_present, false, "host resource-manager observation"},
        {"tpm2_getcap_available", tpm2_getcap_available, false, "userspace observation"},
        {"tpm2_nvreadpublic_available", tpm2_nvreadpublic_available, false, "userspace observation"},
        {"tpm2_nvcertify_available", tpm2_nvcertify_available, false, "userspace observation"},
        {"tpm2_nvextend_available", tpm2_nvextend_available, false, "userspace observation"},
        {"exact_tpm_profile_operated", false, false, "no device command issued"},
        {"nv_public_read", false, false, "zero TPM reads"},
        {"pre_certify_observed", false, false, "zero attestations"},
        {"nv_extend_attempted", false, false, "zero TPM writes"},
        {"post_certify_observed", false, false, "zero attestations"},
        {"independent_witness_operated", false, false, "same cloudtainer only"},
        {"witness_outside_restorable_image", false, false, "counterproof is restorable"},
        {"witness_administration_distinct", false, false, "same root"},
        {"platform_replacement_succession_bound", false, false, "no platform profile"},
        {"nv_redefinition_detectable", false, false, "no external continuity"},
        {"portable_clone_replay_excluded", false, false, "clones both advanced"},
        {"external_rollback_floor_bound", assessment.external_rollback_floor_bound, false, "host stops at missing TPM profile"},
        {"v18_external_floor_premise", assessment.eligible_for_v18_external_floor_premise, false, "not established"},
        {"tpm_commands_issued", false, false, "no fallback or simulation"},
        {"network_attempted", false, false, "offline host probe"},
        {"ready_sent", false, false, "V13 untouched"},
        {"rights_imported", false, false, "no SCM_RIGHTS"},
        {"provider_operated", false, false, "no provider"},
        {"authority", false, false, "none"},
    }};

    const std::vector<CounterexampleRow> counterexamples{{
        {"two_restorable_witnesses_advance", first_advanced && second_advanced, "process or object count as external serialization", "both copies accept the same predecessor"},
        {"restored_witness_advances_again", restored_advanced, "snapshot-local witness as rollback floor", "restore reopens the transition"},
        {"two_valid_signatures_share_one_key", first_signature_valid && second_signature_valid, "signature count as independent constitution", "cloned key custody signs both histories"},
        {"deterministic_signatures_match", clone_signatures_identical, "different receipts as different roots", "same key and message are one cloned root"},
        {"same_history_duplicate_is_not_portable_exclusion", same_history_duplicate && restored_advanced, "local already-current as global one-use", "another restored history advances"},
        {"tpm_device_absence_is_not_profile_success", !tpm0_present && !tpmrm0_present, "missing device as implicit TPM", "profile remains unavailable"},
        {"tpm_tool_absence_is_not_profile_success", !tpm2_getcap_available, "missing tool as retained command evidence", "no command issued"},
        {"local_successor_is_not_nv_state", true, "SHA calculation as TPM operation", "device state must be certified"},
        {"local_key_is_not_external_witness", true, "Ed25519 validity as external administration", "key resides in restorable process image"},
        {"same_root_is_not_distinct_recovery", true, "different class instances as operator separation", "same administration controls all state"},
        {"record_crc_is_not_attestation", true, "canonical bytes as certified NV contents", "signed pre/post state remains absent"},
        {"same_nv_name_fixture_is_not_incarnation", true, "digest label as platform lifetime", "succession remains unproved"},
        {"no_tpm_fallback", true, "host stop as license to simulate operation", "absence stays false"},
        {"no_network_fallback", true, "host stop as remote service retry", "network remains zero"},
        {"no_scalar_fallback", true, "missing NV extend as local counter", "content binding remains mandatory"},
        {"no_resend_after_ambiguity", true, "unknown completion as second extend", "recovery is query-only"},
        {"tpm_success_before_witness_is_split", tpm_ahead_witness_behind, "successful TPM command as completed protocol", "the witness still names the predecessor"},
        {"query_only_does_not_converge_split", query_only_cannot_converge, "read-only classification as repair", "split ledgers remain split"},
        {"stale_precert_is_not_cas", stale_precert_second_extend_advances_again, "certified predecessor as atomic guard", "the second extend consumes the first successor"},
        {"witness_first_is_inverse_split", witness_ahead_tpm_behind, "reordered operations as atomic join", "the TPM can still name the predecessor"},
        {"happy_path_is_not_crash_theorem", complete_transcript_not_atomic, "complete transcript as all-cut recovery", "both fracture states remain reachable"},
        {"full_record_may_exceed_nv_buffer", kExternalFloorRecordBytes == 288U, "fixed record size as universal TPM capacity", "TPM2B_MAX_NV_BUFFER must be admitted"},
        {"extend_public_size_is_separate_premise", ExternalFloorDigest{}.size() == 32U, "TPM_NT_EXTEND as implicit dataSize", "public dataSize must equal the nameAlg digest size"},
        {"external_floor_not_v13", !assessment.eligible_for_v18_external_floor_premise, "profile fragment as READY", "V18 external floor premise is false"},
        {"external_floor_not_owner", !assessment.owner_authority, "rollback floor as owner constitution", "authority remains outside V19"},
        {"external_floor_not_provider", !assessment.provider_operated, "newestness as provider operation", "provider remains absent"},
        {"external_floor_not_living_law", !assessment.living_law, "mechanism as constitution", "remain in Epoch Zero"},
    }};

    require(cases.size() == 42U, "host case inventory");
    require(counterexamples.size() == 27U, "host counterexample inventory");
    for (const CaseRow& row : cases) {
        require(row.observed == row.expected, "host case " + row.name);
    }
    for (const CounterexampleRow& row : counterexamples) {
        require(row.reproduced, "host counterexample " + row.name);
    }
    write_cases(output, cases);
    write_counterexamples(output, counterexamples);

    std::ofstream summary(output / "external-floor-host-summary.json",
                          std::ios::binary);
    require(summary.good(), "open host summary");
    summary << "{\n"
            << "  \"authority\": false,\n"
            << "  \"cases\": " << cases.size() << ",\n"
            << "  \"clone_histories_advanced\": 2,\n"
            << "  \"clone_signatures_identical\": " << boolean(clone_signatures_identical) << ",\n"
            << "  \"complete_transcript_not_atomic\": " << boolean(complete_transcript_not_atomic) << ",\n"
            << "  \"counterexamples_reproduced\": " << counterexamples.size() << ",\n"
            << "  \"dual_ledger_transcript_operated\": false,\n"
            << "  \"exact_tpm_profile_operated\": false,\n"
            << "  \"external_rollback_floor_bound\": false,\n"
            << "  \"host_kernel_release\": \"" << host.release << "\",\n"
            << "  \"network_attempted\": false,\n"
            << "  \"portable_clone_replay_excluded\": false,\n"
            << "  \"query_only_cross_ledger_recovery_bound\": false,\n"
            << "  \"provider_operated\": false,\n"
            << "  \"ready_sent\": false,\n"
            << "  \"restored_copy_advanced\": " << boolean(restored_advanced) << ",\n"
            << "  \"rights_imported\": false,\n"
            << "  \"stale_precert_second_extend_reproduced\": "
            << boolean(stale_precert_second_extend_advances_again) << ",\n"
            << "  \"tpm_ahead_witness_behind_fracture_reproduced\": "
            << boolean(tpm_ahead_witness_behind) << ",\n"
            << "  \"schema\": \"slopos.rev0907.external-rollback-floor-host-probe.v19\",\n"
            << "  \"status\": \"PASS\",\n"
            << "  \"tpm0_present\": " << boolean(tpm0_present) << ",\n"
            << "  \"tpm2_getcap_available\": " << boolean(tpm2_getcap_available) << ",\n"
            << "  \"tpm2_nvcertify_available\": " << boolean(tpm2_nvcertify_available) << ",\n"
            << "  \"tpm2_nvextend_available\": " << boolean(tpm2_nvextend_available) << ",\n"
            << "  \"tpm2_nvreadpublic_available\": " << boolean(tpm2_nvreadpublic_available) << ",\n"
            << "  \"tpm_commands_issued\": 0,\n"
            << "  \"tpmrm0_present\": " << boolean(tpmrm0_present) << ",\n"
            << "  \"v18_external_floor_premise\": false,\n"
            << "  \"witness_administration_distinct\": false,\n"
            << "  \"witness_first_inverse_fracture_reproduced\": "
            << boolean(witness_ahead_tpm_behind) << ",\n"
            << "  \"witness_outside_restorable_image\": false\n"
            << "}\n";
    return 0;
}

}  // namespace slopos::e0::handoff_cell::harness

int main(const int argc, char** argv) {
    if (argc != 2) return 2;
    try {
        const int result =
            slopos::e0::handoff_cell::harness::external_rollback_floor_probe_main(
                std::filesystem::path(argv[1]));
        if (result == 0) {
            std::cout
                << "EXTERNAL_ROLLBACK_FLOOR_PROBE=PASS cases=42 counterexamples=27 "
                   "fracture=true stale_second_extend=true clone_advances=2 "
                   "restored=true signatures_same=true tpm_profile=false "
                   "external_floor=false authority=false\n";
        }
        return result;
    } catch (const std::exception& error) {
        std::cerr << "EXTERNAL_ROLLBACK_FLOOR_PROBE=FAIL detail="
                  << error.what() << '\n';
        return 1;
    }
}
