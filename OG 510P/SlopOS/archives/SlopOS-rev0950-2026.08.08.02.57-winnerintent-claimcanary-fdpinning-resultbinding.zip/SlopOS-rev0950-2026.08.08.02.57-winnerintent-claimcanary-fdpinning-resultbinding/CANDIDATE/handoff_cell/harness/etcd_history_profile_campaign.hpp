#pragma once

#include <cstddef>
#include <filesystem>

namespace slopos::e0::handoff_cell::harness {

struct EtcdHistoryProfileCampaignCounts final {
    std::size_t cases{0U};
    std::size_t counterexamples{0U};
    std::size_t exact_current_observations{0U};
    std::size_t ambiguous_query_refinements{0U};
    std::size_t foreign_cluster_rejections{0U};
    std::size_t serializable_read_rejections{0U};
    std::size_t synthetic_runtime_observations{0U};
};

EtcdHistoryProfileCampaignCounts run_etcd_history_profile_campaign(
    const std::filesystem::path& output);

}  // namespace slopos::e0::handoff_cell::harness
