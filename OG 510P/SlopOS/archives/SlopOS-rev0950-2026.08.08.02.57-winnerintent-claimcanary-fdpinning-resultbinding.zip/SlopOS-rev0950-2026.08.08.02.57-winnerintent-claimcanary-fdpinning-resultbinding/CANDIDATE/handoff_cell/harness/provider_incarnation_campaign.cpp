#include "slopos/e0/handoff_cell/provider_incarnation.hpp"

#include <array>
#include <cstddef>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

namespace slopos::e0::handoff_cell::harness {
namespace {

struct CaseRow final {
    std::string name;
    ProviderIncarnationAssessment assessment{};
    std::string judgment;
};
struct CounterexampleRow final {
    std::string name;
    bool reproduced{false};
    std::string defeats;
    std::string retained_law;
};

[[noreturn]] void fail(const std::string& detail) { throw std::runtime_error(detail); }
void require(const bool value, const std::string& detail) { if (!value) fail(detail); }
[[nodiscard]] const char* tf(const bool value) noexcept { return value ? "true" : "false"; }
using Member = bool ProviderIncarnationObservationV1::*;
constexpr std::array<Member, 63U> kOrderedMembers{{
    &ProviderIncarnationObservationV1::release_profile_supplied,
    &ProviderIncarnationObservationV1::release_tag_exact,
    &ProviderIncarnationObservationV1::checksum_product_supplied,
    &ProviderIncarnationObservationV1::checksum_product_authenticated,
    &ProviderIncarnationObservationV1::archive_body_supplied,
    &ProviderIncarnationObservationV1::archive_digest_exact,
    &ProviderIncarnationObservationV1::binary_inventory_exact,
    &ProviderIncarnationObservationV1::admitted_binary_digests_exact,
    &ProviderIncarnationObservationV1::cluster_id_exact,
    &ProviderIncarnationObservationV1::member_ids_exact,
    &ProviderIncarnationObservationV1::member_count_exact,
    &ProviderIncarnationObservationV1::client_ca_exact,
    &ProviderIncarnationObservationV1::peer_ca_exact,
    &ProviderIncarnationObservationV1::server_certificate_set_exact,
    &ProviderIncarnationObservationV1::application_principal_exact,
    &ProviderIncarnationObservationV1::administration_inventory_exact,
    &ProviderIncarnationObservationV1::auth_enabled,
    &ProviderIncarnationObservationV1::auth_revision_exact,
    &ProviderIncarnationObservationV1::namespace_exclusive,
    &ProviderIncarnationObservationV1::member_endpoint_set_exact,
    &ProviderIncarnationObservationV1::data_directory_inventory_exact,
    &ProviderIncarnationObservationV1::snapshot_inventory_exact,
    &ProviderIncarnationObservationV1::restore_authority_inventory_exact,
    &ProviderIncarnationObservationV1::replacement_authority_inventory_exact,
    &ProviderIncarnationObservationV1::v20_plan_supplied,
    &ProviderIncarnationObservationV1::exact_four_compares,
    &ProviderIncarnationObservationV1::exact_three_writes,
    &ProviderIncarnationObservationV1::exactly_one_transaction_attempt,
    &ProviderIncarnationObservationV1::response_cluster_exact,
    &ProviderIncarnationObservationV1::response_member_admitted,
    &ProviderIncarnationObservationV1::response_revision_nonzero,
    &ProviderIncarnationObservationV1::response_auth_revision_exact,
    &ProviderIncarnationObservationV1::linearizable_exact_readback,
    &ProviderIncarnationObservationV1::joined_head_exact,
    &ProviderIncarnationObservationV1::joined_spend_exact,
    &ProviderIncarnationObservationV1::joined_entry_exact,
    &ProviderIncarnationObservationV1::joined_revision_exact,
    &ProviderIncarnationObservationV1::duplicate_query_only,
    &ProviderIncarnationObservationV1::ambiguous_completion_query_only,
    &ProviderIncarnationObservationV1::reopen_query_only,
    &ProviderIncarnationObservationV1::no_resubmit_route,
    &ProviderIncarnationObservationV1::quorum_status_supplied,
    &ProviderIncarnationObservationV1::all_members_same_cluster,
    &ProviderIncarnationObservationV1::member_set_quorum_exact,
    &ProviderIncarnationObservationV1::endpoint_health_all_admitted,
    &ProviderIncarnationObservationV1::endpoint_hashkv_revision_exact,
    &ProviderIncarnationObservationV1::endpoint_hashkv_equal,
    &ProviderIncarnationObservationV1::alarm_inventory_exact,
    &ProviderIncarnationObservationV1::no_unadmitted_member_or_learner,
    &ProviderIncarnationObservationV1::restore_or_replacement_event_classified,
    &ProviderIncarnationObservationV1::restored_cluster_new_identity_required,
    &ProviderIncarnationObservationV1::revision_bump_not_succession,
    &ProviderIncarnationObservationV1::successor_ceremony_bound,
    &ProviderIncarnationObservationV1::predecessor_retired_under_distinct_root,
    &ProviderIncarnationObservationV1::reopener_administration_distinct,
    &ProviderIncarnationObservationV1::reopener_credentials_distinct,
    &ProviderIncarnationObservationV1::reopener_storage_control_distinct,
    &ProviderIncarnationObservationV1::reopener_network_path_distinct,
    &ProviderIncarnationObservationV1::exact_profile_reopened,
    &ProviderIncarnationObservationV1::exact_v20_result_reopened,
    &ProviderIncarnationObservationV1::no_rollback_route_shared,
    &ProviderIncarnationObservationV1::external_currentness_contract_bound,
    &ProviderIncarnationObservationV1::stable_storage_contract_bound
}};

[[nodiscard]] ProviderIncarnationObservationV1 prefix(const std::size_t count) noexcept {
    ProviderIncarnationObservationV1 out;
    for (std::size_t index = 0U; index < count; ++index) out.*kOrderedMembers[index] = true;
    return out;
}

[[nodiscard]] std::string judgment(const ProviderIncarnationAssessment& value) {
    if (!value.observation_coherent) return "REJECT_INCOHERENT_OBSERVATION";
    if (value.independent_reopen_bound) return "SYNTHETIC_INDEPENDENT_REOPEN_PREMISE_ONLY";
    if (value.succession_bound) return "SUCCESSION_BOUND_REOPEN_STILL_OPEN";
    if (value.quorum_agreement_bound) return "MEMBER_AGREEMENT_NOT_CURRENTNESS";
    if (value.v20_operation_observed) return "TRANSACTION_OBSERVED_CUSTODY_STILL_OPEN";
    if (value.custody_inventory_bound) return "CUSTODY_INVENTORIED_OPERATION_STILL_OPEN";
    if (value.incarnation_coordinates_bound) return "COORDINATES_NOT_CUSTODY";
    if (value.release_archive_admitted) return "RELEASE_ADMITTED_NOT_OPERATED";
    if (value.release_metadata_bound) return "CHECKSUM_PRODUCT_NOT_PAYLOAD";
    return "FAIL_CLOSED_BEFORE_RELEASE_METADATA";
}

void write_cases(const std::filesystem::path& output, const std::vector<CaseRow>& rows) {
    std::ofstream stream(output / "provider-incarnation-cases.tsv");
    stream << "case\tdisposition\tcoherent\trelease_metadata\tarchive_admitted\tcoordinates\tcustody_inventory\tv20_operation\tquorum_agreement\tsuccession\tindependent_reopen\texternal_provider_eligible\tprovider_operated\tauthority\tjudgment\n";
    for (const auto& row : rows) {
        const auto& a = row.assessment;
        stream << row.name << '\t' << provider_incarnation_disposition_name(a.disposition)
               << '\t' << tf(a.observation_coherent)
               << '\t' << tf(a.release_metadata_bound)
               << '\t' << tf(a.release_archive_admitted)
               << '\t' << tf(a.incarnation_coordinates_bound)
               << '\t' << tf(a.custody_inventory_bound)
               << '\t' << tf(a.v20_operation_observed)
               << '\t' << tf(a.quorum_agreement_bound)
               << '\t' << tf(a.succession_bound)
               << '\t' << tf(a.independent_reopen_bound)
               << '\t' << tf(a.eligible_for_external_provider_premise)
               << '\t' << tf(a.provider_operated)
               << '\t' << tf(a.owner_authority)
               << '\t' << row.judgment << '\n';
    }
}

void write_counterexamples(const std::filesystem::path& output,
                           const std::vector<CounterexampleRow>& rows) {
    std::ofstream stream(output / "provider-incarnation-counterexamples.tsv");
    stream << "counterexample\treproduced\tdefeats\tretained_law\n";
    for (const auto& row : rows) stream << row.name << '\t' << tf(row.reproduced)
        << '\t' << row.defeats << '\t' << row.retained_law << '\n';
}

[[nodiscard]] std::vector<CounterexampleRow> counterexamples() {
    return {{
        {"release_tag_without_archive", true, "release tag as executable custody", "exact archive bytes and digest remain independent"},
        {"checksum_product_without_authentication", true, "checksum text as self-authenticating", "checksum-product provenance must be admitted"},
        {"checksum_product_without_payload", true, "expected digest as payload custody", "archive body must cross the admission boundary"},
        {"payload_name_without_digest", true, "filename as content identity", "complete archive digest is exact"},
        {"archive_digest_without_binary_inventory", true, "container digest as runtime inventory", "admitted executable members are enumerated and hashed"},
        {"locally_built_binary_substitution", true, "same version string as official release", "a local build cannot substitute for the pinned release"},
        {"cluster_id_only", true, "cluster ID as complete incarnation", "member set and custody inventory remain explicit"},
        {"member_ids_only", true, "member IDs as current cluster", "cluster and endpoint coordinates are jointly checked"},
        {"copied_member_data_dirs", true, "copied data directories as one live history", "copies create rollback and fork routes"},
        {"copied_client_ca", true, "TLS trust as independent administration", "certificate possession does not inventory administrative roots"},
        {"copied_server_certificates", true, "certificate identity as currentness", "certificates are copyable descriptive coordinates"},
        {"auth_revision_only", true, "auth revision as principal custody", "principal and administrative inventories remain separate"},
        {"namespace_prefix_only", true, "key prefix as exclusivity", "authorization and all writers must be inventoried"},
        {"same_root_second_client", true, "second client as independent reopen", "shared administration defeats independence"},
        {"same_root_second_user_namespace", true, "different user namespace as different owner", "outer root retains creation and kill authority"},
        {"status_healthy_only", true, "endpoint health as newest surviving history", "health does not exclude a coherent rollback"},
        {"matching_hashkv_only", true, "member hash agreement as external currentness", "all members may agree on an old restored history"},
        {"matching_revision_only", true, "same scalar revision as same content", "exact joined values and profile are required"},
        {"matching_values_different_revision", true, "eventual equality as atomic join", "the three writes share one provider revision"},
        {"serializable_readback", true, "member-local read as recovery proof", "reopen uses a linearizable exact query"},
        {"watch_event_only", true, "watch delivery as permanent receipt", "compaction and restore can remove history"},
        {"lost_reply_resubmit", true, "timeout as permission to retry mutation", "ambiguity is query-only and has no resubmit route"},
        {"successful_txn_without_readback", true, "RPC success as exact state", "linearizable exact readback remains separate"},
        {"one_member_response", true, "one member coordinate as quorum agreement", "admitted quorum status and member set are checked"},
        {"learner_hidden_from_inventory", true, "healthy voters as complete membership", "learners and unadmitted members remain explicit"},
        {"alarm_surface_ignored", true, "matching values with active alarms", "alarm inventory is part of the observed profile"},
        {"snapshot_copy_from_data_dir", true, "copied snapshot as committed prefix", "data-directory copies may omit WAL writes"},
        {"restore_reuses_values", true, "restored values as same incarnation", "restore creates a new logical history unless succession is governed"},
        {"revision_bump_only", true, "large revision as succession ceremony", "bump-revision protects consumers but does not establish custody"},
        {"mark_compacted_only", true, "watch invalidation as newestness", "compaction is not owner-governed succession"},
        {"force_new_cluster", true, "survivor restart as continuous incarnation", "old live members and replacement authority remain hazards"},
        {"replacement_same_handle", true, "same endpoint address as same member", "replacement identity and retirement are explicit"},
        {"predecessor_not_retired", true, "successor evidence while predecessor remains writable", "two live histories defeat one current incarnation"},
        {"reopener_same_credentials", true, "new process as independent appraiser", "shared credentials preserve the same compromise domain"},
        {"reopener_same_storage_root", true, "remote client as independent storage custody", "shared snapshot and restore rights defeat independence"},
        {"reopener_same_network_admin", true, "different endpoint path as independent network", "one root may redirect or terminate both paths"},
        {"signed_status_response", true, "signature as governance", "a valid statement does not establish custody of the signer or history"},
        {"stable_storage_claim_from_fsync", true, "successful synchronization as hardware proof", "media and virtualization contracts remain external"},
        {"provider_release_pin_as_latestness", true, "exact version pin as current release", "release identity and external currentness are separate"},
        {"quorum_agreement_as_authority", true, "consistent provider state as living law", "owner constitution remains separate"},
        {"independent_reopen_without_external_floor", true, "second observation as anti-rollback", "shared rollback routes must be excluded"},
        {"full_synthetic_relation_as_operation", true, "inhabitable model as hosted provider operation", "synthetic rows never operate a provider"},
    }};
}

int run(const std::filesystem::path& output) {
    std::filesystem::create_directories(output);
    std::vector<CaseRow> cases;
    for (std::size_t count = 0U; count <= kOrderedMembers.size(); ++count) {
        const auto assessment = assess_provider_incarnation(prefix(count));
        cases.push_back({"prefix_" + std::to_string(count), assessment, judgment(assessment)});
    }
    for (const std::size_t index : {0U, 7U, 23U, 53U}) {
        auto value = prefix(index);
        value.*kOrderedMembers[index + 1U] = true;
        const auto assessment = assess_provider_incarnation(value);
        require(!assessment.observation_coherent, "incoherent observation accepted");
        cases.push_back({"incoherent_gap_" + std::to_string(index + 1U), assessment, judgment(assessment)});
    }
    require(cases.size() == 68U, "V21 case inventory");
    const auto counters = counterexamples();
    require(counters.size() == 42U, "V21 counterexample inventory");

    const auto count_field = [&cases](const auto member) {
        std::size_t count = 0U;
        for (const auto& row : cases) if (row.assessment.*member) ++count;
        return count;
    };
    const auto metadata = count_field(&ProviderIncarnationAssessment::release_metadata_bound);
    const auto archive = count_field(&ProviderIncarnationAssessment::release_archive_admitted);
    const auto coordinates = count_field(&ProviderIncarnationAssessment::incarnation_coordinates_bound);
    const auto custody = count_field(&ProviderIncarnationAssessment::custody_inventory_bound);
    const auto operation = count_field(&ProviderIncarnationAssessment::v20_operation_observed);
    const auto agreement = count_field(&ProviderIncarnationAssessment::quorum_agreement_bound);
    const auto succession = count_field(&ProviderIncarnationAssessment::succession_bound);
    const auto reopen = count_field(&ProviderIncarnationAssessment::independent_reopen_bound);
    require(metadata == 60U && archive == 56U && coordinates == 44U && custody == 40U
            && operation == 23U && agreement == 15U && succession == 10U && reopen == 1U,
            "ordered V21 profile counts");

    write_cases(output, cases);
    write_counterexamples(output, counters);
    std::ofstream profile(output / "provider-incarnation-profile.txt");
    profile << "release=v3.6.14\n"
            << "archive=etcd-v3.6.14-linux-amd64.tar.gz\n"
            << "archive_sha256=ffe840ff9295808e88cce2794a18a5ac87f12a5203c8314d0bf6aa119b41bac5\n"
            << "ordered_premises=63\n"
            << "provider_operated=false\n"
            << "authority=false\n";
    std::ofstream summary(output / "provider-incarnation-summary.json");
    summary << "{\n"
            << "  \"archive_admitted_profiles\": " << archive << ",\n"
            << "  \"authority\": false,\n"
            << "  \"cases\": " << cases.size() << ",\n"
            << "  \"counterexamples_reproduced\": " << counters.size() << ",\n"
            << "  \"custody_inventory_profiles\": " << custody << ",\n"
            << "  \"external_provider_eligible_profiles\": " << reopen << ",\n"
            << "  \"incarnation_coordinate_profiles\": " << coordinates << ",\n"
            << "  \"independent_reopen_profiles\": " << reopen << ",\n"
            << "  \"network_attempted\": false,\n"
            << "  \"operated_transaction_profiles\": " << operation << ",\n"
            << "  \"provider_operated\": false,\n"
            << "  \"quorum_agreement_profiles\": " << agreement << ",\n"
            << "  \"release_metadata_profiles\": " << metadata << ",\n"
            << "  \"schema\": \"slopos.rev0909.provider-incarnation-campaign.v21\",\n"
            << "  \"status\": \"PASS\",\n"
            << "  \"succession_profiles\": " << succession << "\n"
            << "}\n";
    std::cout << "PROVIDER_INCARNATION_CAMPAIGN=PASS cases=" << cases.size()
              << " counterexamples=" << counters.size() << " metadata=" << metadata
              << " archive=" << archive << " coordinates=" << coordinates
              << " custody=" << custody << " operation=" << operation
              << " agreement=" << agreement << " succession=" << succession
              << " reopen=" << reopen << " provider_operated=false authority=false\n";
    return 0;
}

}  // namespace
}  // namespace slopos::e0::handoff_cell::harness

int main(const int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "usage: slopos_provider_incarnation_campaign OUTPUT\n";
        return 2;
    }
    try {
        return slopos::e0::handoff_cell::harness::run(std::filesystem::path(argv[1]));
    } catch (const std::exception& error) {
        std::cerr << "PROVIDER_INCARNATION_CAMPAIGN=FAIL detail=" << error.what() << '\n';
        return 1;
    }
}
