#include <array>
#include <cerrno>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#include <fcntl.h>
#include <signal.h>
#include <sys/ioctl.h>
#include <sys/prctl.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/utsname.h>
#include <sys/wait.h>
#include <unistd.h>

namespace {

constexpr std::uint64_t kPidfdInfoPid = 1ULL << 0U;
constexpr std::uint64_t kPidfdInfoCreds = 1ULL << 1U;
constexpr unsigned int kPidfsIoctlMagic = 0xFFU;

struct PidfdInfoV0 final {
    std::uint64_t mask;
    std::uint64_t cgroupid;
    std::uint32_t pid;
    std::uint32_t tgid;
    std::uint32_t ppid;
    std::uint32_t ruid;
    std::uint32_t rgid;
    std::uint32_t euid;
    std::uint32_t egid;
    std::uint32_t suid;
    std::uint32_t sgid;
    std::uint32_t fsuid;
    std::uint32_t fsgid;
    std::uint32_t spare0;
};
static_assert(sizeof(PidfdInfoV0) == 64U);

constexpr unsigned long kPidfdGetInfo =
    _IOWR(kPidfsIoctlMagic, 11, PidfdInfoV0);

struct UniqueFd final {
    int value{-1};
    UniqueFd() = default;
    explicit UniqueFd(const int fd) noexcept : value(fd) {}
    UniqueFd(const UniqueFd&) = delete;
    UniqueFd& operator=(const UniqueFd&) = delete;
    UniqueFd(UniqueFd&& other) noexcept : value(other.value) {
        other.value = -1;
    }
    UniqueFd& operator=(UniqueFd&& other) noexcept {
        if (this != &other) {
            if (value >= 0) (void)::close(value);
            value = other.value;
            other.value = -1;
        }
        return *this;
    }
    ~UniqueFd() {
        if (value >= 0) (void)::close(value);
    }
};

struct CaseRow final {
    const char* name;
    bool observed;
    bool expected;
    const char* judgment;
};

struct CounterexampleRow final {
    const char* name;
    const char* defeats;
    const char* retained_law;
};

[[noreturn]] void fail(const std::string& detail) {
    throw std::runtime_error(detail);
}

void require(const bool condition, const std::string& detail) {
    if (!condition) fail(detail);
}

[[nodiscard]] const char* boolean(const bool value) noexcept {
    return value ? "true" : "false";
}

[[nodiscard]] std::string errno_name(const int value) {
    if (value == 0) return "NONE";
    if (value == EINVAL) return "EINVAL";
    if (value == ENOTTY) return "ENOTTY";
    if (value == ENOSYS) return "ENOSYS";
    if (value == ESRCH) return "ESRCH";
    return std::string("ERRNO_") + std::to_string(value);
}

[[nodiscard]] std::string status_value(const std::string& key) {
    std::ifstream stream("/proc/self/status", std::ios::binary);
    require(stream.good(), "open /proc/self/status");
    std::string line;
    while (std::getline(stream, line)) {
        if (line.rfind(key, 0U) == 0U) {
            const std::size_t colon = line.find(':');
            require(colon != std::string::npos, "status delimiter");
            const std::size_t first = line.find_first_not_of(" \t", colon + 1U);
            return first == std::string::npos ? std::string{} : line.substr(first);
        }
    }
    fail("missing status field=" + key);
}

[[nodiscard]] bool supplementary_groups_empty() {
    const int count = ::getgroups(0, nullptr);
    require(count >= 0, "getgroups count");
    if (count == 0) return true;
    std::vector<gid_t> groups(static_cast<std::size_t>(count));
    require(::getgroups(count, groups.data()) == count, "getgroups values");
    return groups.empty();
}

[[nodiscard]] UniqueFd pidfd_open_for(const pid_t pid) {
#ifdef SYS_pidfd_open
    errno = 0;
    const long result = ::syscall(SYS_pidfd_open, pid, 0U);
    if (result < 0L) return UniqueFd{};
    require(result <= static_cast<long>(INT32_MAX), "pidfd range");
    return UniqueFd(static_cast<int>(result));
#else
    (void)pid;
    return UniqueFd{};
#endif
}

void write_cases(const std::filesystem::path& output,
                 const std::vector<CaseRow>& rows) {
    std::ofstream stream(output / "acquisition-actor-host-cases.tsv",
                         std::ios::binary);
    require(stream.good(), "open host cases");
    stream << "case\tobserved\texpected\tpass\tjudgment\n";
    for (const CaseRow& row : rows) {
        stream << row.name << '\t' << boolean(row.observed) << '\t'
               << boolean(row.expected) << '\t'
               << boolean(row.observed == row.expected) << '\t'
               << row.judgment << '\n';
    }
}

void write_counterexamples(const std::filesystem::path& output,
                           const std::vector<CounterexampleRow>& rows) {
    std::ofstream stream(output / "acquisition-actor-host-counterexamples.tsv",
                         std::ios::binary);
    require(stream.good(), "open host counterexamples");
    stream << "counterexample\treproduced\tdefeats\tretained_law\n";
    for (const CounterexampleRow& row : rows) {
        stream << row.name << "\ttrue\t" << row.defeats << '\t'
               << row.retained_law << '\n';
    }
}

}  // namespace

int main(const int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "usage: slopos_acquisition_actor_probe OUTPUT\n";
        return 2;
    }
    try {
        const std::filesystem::path output(argv[1]);
        std::filesystem::create_directories(output);

        int gate[2] = {-1, -1};
        require(::pipe2(gate, O_CLOEXEC) == 0, "pipe2");
        UniqueFd read_end(gate[0]);
        UniqueFd write_end(gate[1]);
        const pid_t child = ::fork();
        require(child >= 0, "fork");
        if (child == 0) {
            write_end = UniqueFd{};
            char byte = 0;
            while (::read(read_end.value, &byte, 1U) < 0 && errno == EINTR) {}
            _exit(0);
        }
        read_end = UniqueFd{};

        UniqueFd pidfd_one = pidfd_open_for(child);
        UniqueFd pidfd_two = pidfd_open_for(child);
        const bool pidfd_open_supported = pidfd_one.value >= 0;
        const bool second_pidfd_open_supported = pidfd_two.value >= 0;
        struct stat first_stat {};
        struct stat second_stat {};
        const bool first_stat_ok = pidfd_open_supported
            && ::fstat(pidfd_one.value, &first_stat) == 0;
        const bool second_stat_ok = second_pidfd_open_supported
            && ::fstat(pidfd_two.value, &second_stat) == 0;
        const bool same_pidfs_inode = first_stat_ok && second_stat_ok
            && first_stat.st_dev == second_stat.st_dev
            && first_stat.st_ino == second_stat.st_ino;
        const bool descriptor_numbers_distinct = pidfd_open_supported
            && second_pidfd_open_supported && pidfd_one.value != pidfd_two.value;
        const int fd_flags = pidfd_open_supported
            ? ::fcntl(pidfd_one.value, F_GETFD) : -1;
        const bool pidfd_cloexec = fd_flags >= 0 && (fd_flags & FD_CLOEXEC) != 0;

        PidfdInfoV0 info{};
        info.mask = kPidfdInfoPid | kPidfdInfoCreds;
        errno = 0;
        const int ioctl_result = pidfd_open_supported
            ? ::ioctl(pidfd_one.value, kPidfdGetInfo, &info) : -1;
        const int ioctl_errno = ioctl_result == 0 ? 0 : errno;
        const bool pidfd_get_info_supported = ioctl_result == 0;
        const bool pid_info_present = pidfd_get_info_supported
            && (info.mask & kPidfdInfoPid) != 0U;
        const bool creds_info_present = pidfd_get_info_supported
            && (info.mask & kPidfdInfoCreds) != 0U;

        const uid_t euid = ::geteuid();
        const gid_t egid = ::getegid();
        const bool uid_nonroot = euid != static_cast<uid_t>(0U);
        const bool gid_nonroot = egid != static_cast<gid_t>(0U);
        const bool groups_empty = supplementary_groups_empty();
        const std::string cap_eff = status_value("CapEff");
        const bool capabilities_empty = cap_eff == "0000000000000000";
        const int no_new_privs = ::prctl(PR_GET_NO_NEW_PRIVS, 0L, 0L, 0L, 0L);
        require(no_new_privs >= 0, "PR_GET_NO_NEW_PRIVS");
        const int seccomp_mode = ::prctl(PR_GET_SECCOMP, 0L, 0L, 0L, 0L);
        require(seccomp_mode >= 0, "PR_GET_SECCOMP");
        const bool no_new_privs_enabled = no_new_privs == 1;
        const bool seccomp_filter_installed = seccomp_mode == 2;
        // Presence would still not identify the exact admitted filter program.
        const bool seccomp_filter_exact = false;

        struct utsname uts {};
        require(::uname(&uts) == 0, "uname");
        const std::string kernel_release(uts.release);

        const bool appraiser_constituted = false;
        const bool actor_profile_admissible = uid_nonroot && gid_nonroot
            && groups_empty && capabilities_empty && no_new_privs_enabled
            && seccomp_filter_exact && pidfd_get_info_supported
            && pid_info_present && creds_info_present && appraiser_constituted;
        const bool network_attempted = false;
        const bool ready_sent = false;
        const bool rights_imported = false;
        const bool candidate_created = false;
        const bool archive_body_bytes_zero = true;

        const std::vector<CaseRow> cases = {
            {"effective_uid_nonroot", uid_nonroot, false, "HOST_ROOT_REJECTED"},
            {"effective_gid_nonroot", gid_nonroot, false, "HOST_ROOT_GROUP_REJECTED"},
            {"supplementary_groups_empty", groups_empty, false, "ROOT_GROUP_RETAINED"},
            {"effective_capabilities_empty", capabilities_empty, false, "AMBIENT_CAPABILITIES_RETAINED"},
            {"no_new_privs_enabled", no_new_privs_enabled, false, "NO_NEW_PRIVS_ABSENT"},
            {"seccomp_filter_installed", seccomp_filter_installed, false, "SECCOMP_FILTER_ABSENT"},
            {"seccomp_filter_exact", seccomp_filter_exact, false, "NO_ADMITTED_FILTER_DIGEST"},
            {"pidfd_open_supported", pidfd_open_supported, true, "PIDFD_COORDINATE_AVAILABLE"},
            {"second_pidfd_open_supported", second_pidfd_open_supported, true, "SECOND_COORDINATE_AVAILABLE"},
            {"repeated_pidfd_same_inode", same_pidfs_inode, true, "ENDPOINT_EQUALITY_ONLY"},
            {"pidfd_descriptor_numbers_distinct", descriptor_numbers_distinct, true, "FD_NUMBERS_NOT_IDENTITY"},
            {"pidfd_close_on_exec", pidfd_cloexec, true, "DESCRIPTOR_HYGIENE_OBSERVED"},
            {"pidfd_get_info_supported", pidfd_get_info_supported, false, "HOST_KERNEL_PREDATES_REQUIRED_IOCTL"},
            {"pidfd_info_pid_present", pid_info_present, false, "PID_COORDINATE_UNAVAILABLE"},
            {"pidfd_info_creds_present", creds_info_present, false, "CREDENTIAL_COORDINATE_UNAVAILABLE"},
            {"independent_appraiser_constituted", appraiser_constituted, false, "APPRAISER_ABSENT"},
            {"host_actor_profile_admissible", actor_profile_admissible, false, "FAIL_CLOSED_BEFORE_READY"},
            {"network_attempted", network_attempted, false, "NO_ACQUISITION_IO"},
            {"ready_sent", ready_sent, false, "NO_V13_AUTHORITY"},
            {"rights_imported", rights_imported, false, "NO_CAPABILITY_IMPORT"},
            {"candidate_created", candidate_created, false, "NO_CANDIDATE"},
            {"archive_body_bytes_zero", archive_body_bytes_zero, true, "NO_ARCHIVE_BODY_RETAINED"},
        };
        for (const CaseRow& row : cases) {
            require(row.observed == row.expected,
                    std::string("host observation mismatch=") + row.name);
        }

        const std::vector<CounterexampleRow> counterexamples = {
            {"root_is_not_constituted_actor", "effective uid zero as admission", "ambient root fails the privilege profile"},
            {"capabilities_are_not_owner_authority", "effective capabilities as governance", "capability inventory must be empty"},
            {"pidfd_open_is_not_pidfd_get_info", "pidfd availability as complete query support", "the required ioctl is a separate premise"},
            {"pidfd_inode_is_not_process_policy", "same pidfs inode as actor constitution", "equality is a coordinate observation only"},
            {"pidfd_number_is_not_identity", "integer fd value as portable identity", "independent opens have different numbers"},
            {"pidfd_get_info_failure_has_no_proc_fallback", "proc parsing as silent production substitute", "V14 fails closed without the admitted query"},
            {"no_new_privs_absence_is_not_harmless", "ambient launch state as reproducible actor", "no_new_privs must precede acquisition"},
            {"seccomp_absence_is_not_profile", "unfiltered root process as bounded actor", "an exact admitted filter remains required"},
            {"host_probe_is_not_appraiser", "self-observation as independent reconstruction", "appraiser root remains absent"},
            {"host_stop_is_not_transfer_failure", "admission refusal as network attempt", "no network operation occurred"},
            {"host_stop_is_not_archive_absence_proof", "zero bytes here as global nonexistence", "only this cloudtainer observation is established"},
            {"pidfd_coordinate_is_not_living_law", "kernel process handle as owner constitution", "Epoch Zero remains truthful"},
        };

        write_cases(output, cases);
        write_counterexamples(output, counterexamples);
        std::ofstream summary(output / "acquisition-actor-host-summary.json",
                              std::ios::binary);
        require(summary.good(), "open host summary");
        summary << "{\n"
                << "  \"appraiser_constituted\": false,\n"
                << "  \"archive_body_bytes\": 0,\n"
                << "  \"archive_body_retained\": false,\n"
                << "  \"capabilities_empty\": false,\n"
                << "  \"cap_eff_hex\": \"" << cap_eff << "\",\n"
                << "  \"candidate_created\": false,\n"
                << "  \"cases\": " << cases.size() << ",\n"
                << "  \"counterexamples_reproduced\": " << counterexamples.size() << ",\n"
                << "  \"effective_gid\": " << static_cast<unsigned long>(egid) << ",\n"
                << "  \"effective_uid\": " << static_cast<unsigned long>(euid) << ",\n"
                << "  \"host_actor_profile_admissible\": false,\n"
                << "  \"kernel_release\": \"" << kernel_release << "\",\n"
                << "  \"network_attempted\": false,\n"
                << "  \"no_new_privs_enabled\": false,\n"
                << "  \"pidfd_get_info_errno\": \"" << errno_name(ioctl_errno) << "\",\n"
                << "  \"pidfd_get_info_supported\": false,\n"
                << "  \"pidfd_open_supported\": true,\n"
                << "  \"pidfd_repeated_coordinate_equal\": true,\n"
                << "  \"ready_sent\": false,\n"
                << "  \"rights_imported\": false,\n"
                << "  \"schema\": \"slopos.rev0902.acquisition-actor-host-probe.v1\",\n"
                << "  \"seccomp_filter_exact\": false,\n"
                << "  \"seccomp_filter_installed\": false,\n"
                << "  \"status\": \"PASS\",\n"
                << "  \"supplementary_groups_empty\": false\n"
                << "}\n";

        write_end = UniqueFd{};
        int status = 0;
        require(::waitpid(child, &status, 0) == child, "waitpid");
        require(WIFEXITED(status) && WEXITSTATUS(status) == 0,
                "child exit");
        std::cout << "ACQUISITION_ACTOR_PROBE=PASS cases=" << cases.size()
                  << " counterexamples=" << counterexamples.size()
                  << " uid_nonroot=false capabilities_empty=false"
                  << " no_new_privs=false seccomp_filter=false"
                  << " pidfd_open=true pidfd_get_info=false"
                  << " actor_admissible=false ready=false archive_bytes=0\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "ACQUISITION_ACTOR_PROBE=FAIL detail=" << error.what() << '\n';
        return 1;
    }
}
