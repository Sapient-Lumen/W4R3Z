#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <cerrno>
#include <climits>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <system_error>
#include <vector>

#include <fcntl.h>
#include <linux/memfd.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <unistd.h>

namespace {

class UniqueFd final {
public:
    explicit UniqueFd(const int value = -1) noexcept : value_(value) {}
    ~UniqueFd() { reset(); }
    UniqueFd(const UniqueFd&) = delete;
    UniqueFd& operator=(const UniqueFd&) = delete;
    UniqueFd(UniqueFd&& other) noexcept : value_(other.release()) {}
    UniqueFd& operator=(UniqueFd&& other) noexcept {
        if (this != &other) reset(other.release());
        return *this;
    }
    [[nodiscard]] int get() const noexcept { return value_; }
    [[nodiscard]] int release() noexcept {
        const int value = value_;
        value_ = -1;
        return value;
    }
    void reset(const int value = -1) noexcept {
        if (value_ >= 0) (void)::close(value_);
        value_ = value;
    }
private:
    int value_;
};

[[noreturn]] void fail(const std::string& detail) {
    throw std::runtime_error(detail + ": " + std::strerror(errno));
}

void write_all(const int fd, std::string_view body) {
    std::size_t offset = 0U;
    while (offset < body.size()) {
        const auto count = ::write(
            fd, body.data() + static_cast<std::ptrdiff_t>(offset),
            body.size() - offset);
        if (count < 0) fail("write");
        if (count == 0) throw std::runtime_error("zero write");
        offset += static_cast<std::size_t>(count);
    }
}

void create_regular(const std::filesystem::path& path, std::string_view body) {
    UniqueFd fd(::open(path.c_str(), O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC, 0600));
    if (fd.get() < 0) fail("create_regular");
    write_all(fd.get(), body);
}

[[nodiscard]] std::string pread_exact(const int fd, const std::size_t bytes,
                                      const off_t offset = 0) {
    std::string body(bytes, '\0');
    std::size_t total = 0U;
    while (total < bytes) {
        const auto count = ::pread(
            fd, body.data() + static_cast<std::ptrdiff_t>(total),
            bytes - total, offset + static_cast<off_t>(total));
        if (count < 0) fail("pread");
        if (count == 0) throw std::runtime_error("short pread");
        total += static_cast<std::size_t>(count);
    }
    return body;
}

[[nodiscard]] std::string read_exact(const int fd, const std::size_t bytes) {
    std::string body(bytes, '\0');
    std::size_t total = 0U;
    while (total < bytes) {
        const auto count = ::read(
            fd, body.data() + static_cast<std::ptrdiff_t>(total), bytes - total);
        if (count < 0) fail("read");
        if (count == 0) throw std::runtime_error("short read");
        total += static_cast<std::size_t>(count);
    }
    return body;
}

[[nodiscard]] bool same_inode(const struct stat& left,
                              const struct stat& right) noexcept {
    return left.st_dev == right.st_dev && left.st_ino == right.st_ino;
}

[[nodiscard]] UniqueFd create_sealable_memfd(const char* name) {
    const long raw = ::syscall(
        SYS_memfd_create, name,
        static_cast<unsigned int>(MFD_CLOEXEC | MFD_ALLOW_SEALING));
    if (raw < 0) fail("memfd_create");
    if (raw > INT_MAX) throw std::runtime_error("memfd descriptor overflow");
    return UniqueFd(static_cast<int>(raw));
}

[[nodiscard]] bool pwrite_rejected_with_eperm(
    const int fd, const char byte, const off_t offset) noexcept {
    errno = 0;
    const auto result = ::pwrite(fd, &byte, 1U, offset);
    return result < 0 && errno == EPERM;
}

[[nodiscard]] bool ftruncate_rejected_with_eperm(
    const int fd, const off_t size) noexcept {
    errno = 0;
    const int result = ::ftruncate(fd, size);
    return result < 0 && errno == EPERM;
}

void write_text(const std::filesystem::path& path, const std::string& body) {
    std::ofstream stream(path, std::ios::binary | std::ios::trunc);
    if (!stream) throw std::runtime_error("open output");
    stream << body;
    if (!stream) throw std::runtime_error("write output");
}

struct TempTree final {
    std::filesystem::path path;
    TempTree() {
        std::string pattern = "/tmp/slopos-release-fd-probe-XXXXXX";
        std::vector<char> storage(pattern.begin(), pattern.end());
        storage.push_back('\0');
        char* result = ::mkdtemp(storage.data());
        if (result == nullptr) fail("mkdtemp");
        path = result;
    }
    ~TempTree() {
        std::error_code ignored;
        std::filesystem::remove_all(path, ignored);
    }
};

}  // namespace

int main(const int argc, char** argv) {
    try {
        if (argc != 2) {
            std::cerr << "usage: slopos_release_fd_probe OUTPUT_DIRECTORY\n";
            return 2;
        }
        const std::filesystem::path output(argv[1]);
        std::filesystem::create_directories(output);
        TempTree temporary;
        const auto original = temporary.path / "release.tar.gz";
        const auto replacement = temporary.path / "replacement.tar.gz";
        const auto symlink_leaf = temporary.path / "release-link.tar.gz";
        const auto directory_leaf = temporary.path / "release-directory";
        constexpr std::string_view original_body{"ORIGINAL-ARCHIVE-BYTES"};
        constexpr std::string_view replacement_body{"REPLACEMENT-PAYLOAD"};

        create_regular(original, original_body);
        create_regular(replacement, replacement_body);

        UniqueFd pinned(::open(
            original.c_str(), O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK));
        if (pinned.get() < 0) fail("open pinned release");
        struct stat opened{};
        if (::fstat(pinned.get(), &opened) != 0) fail("fstat opened");
        const bool opened_regular = S_ISREG(opened.st_mode);

        if (::rename(replacement.c_str(), original.c_str()) != 0) {
            fail("replace pathname");
        }
        struct stat current_path{};
        if (::lstat(original.c_str(), &current_path) != 0) fail("lstat replacement");
        const bool path_identity_changed = !same_inode(opened, current_path);
        const bool pinned_reads_original =
            pread_exact(pinned.get(), original_body.size()) == original_body;

        UniqueFd reopened(::open(
            original.c_str(), O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK));
        if (reopened.get() < 0) fail("reopen replaced path");
        const bool reopened_reads_replacement =
            pread_exact(reopened.get(), replacement_body.size()) == replacement_body;

        if (::symlink(original.filename().c_str(), symlink_leaf.c_str()) != 0) {
            fail("create symlink");
        }
        errno = 0;
        const int symlink_result = ::open(
            symlink_leaf.c_str(), O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK);
        const bool symlink_leaf_rejected = symlink_result < 0 && errno == ELOOP;
        if (symlink_result >= 0) (void)::close(symlink_result);

        if (::mkdir(directory_leaf.c_str(), 0700) != 0) fail("mkdir leaf");
        UniqueFd directory_fd(::open(
            directory_leaf.c_str(), O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK));
        if (directory_fd.get() < 0) fail("open directory leaf");
        struct stat directory_stat{};
        if (::fstat(directory_fd.get(), &directory_stat) != 0) fail("fstat directory");
        const bool regular_check_rejects_directory = !S_ISREG(directory_stat.st_mode);

        if (::lseek(pinned.get(), 0, SEEK_SET) < 0) fail("lseek pinned");
        UniqueFd duplicate(::fcntl(pinned.get(), F_DUPFD_CLOEXEC, 0));
        if (duplicate.get() < 0) fail("duplicate pinned");
        const std::string first = read_exact(pinned.get(), 1U);
        const std::string second = read_exact(duplicate.get(), 1U);
        const bool duplicate_shares_offset = first == "O" && second == "R";
        const bool pread_ignores_shared_offset = pread_exact(duplicate.get(), 1U, 0) == "O";

        UniqueFd snapshot = create_sealable_memfd("slopos-release-snapshot");
        write_all(snapshot.get(), original_body);
        struct stat snapshot_stat{};
        if (::fstat(snapshot.get(), &snapshot_stat) != 0) fail("fstat memfd");
        const bool memfd_regular_unlinked =
            S_ISREG(snapshot_stat.st_mode) && snapshot_stat.st_nlink == 0;
        UniqueFd retained_writer(::fcntl(snapshot.get(), F_DUPFD_CLOEXEC, 0));
        if (retained_writer.get() < 0) fail("duplicate memfd writer");

        if (::fchmod(snapshot.get(), 0400) != 0) fail("fchmod memfd");
        constexpr char mutable_byte{'M'};
        const bool mode_only_writer_survives =
            ::pwrite(retained_writer.get(), &mutable_byte, 1U, 0) == 1;

        constexpr int required_seals =
            F_SEAL_WRITE | F_SEAL_GROW | F_SEAL_SHRINK | F_SEAL_SEAL;
        if (::fcntl(snapshot.get(), F_ADD_SEALS, required_seals) != 0) {
            fail("F_ADD_SEALS");
        }
        const int observed_seals = ::fcntl(snapshot.get(), F_GET_SEALS);
        if (observed_seals < 0) fail("F_GET_SEALS");
        const bool all_required_seals =
            (observed_seals & required_seals) == required_seals;
        const bool retained_writer_rejected =
            pwrite_rejected_with_eperm(retained_writer.get(), 'X', 0);
        const bool growth_rejected = ftruncate_rejected_with_eperm(
            snapshot.get(), static_cast<off_t>(original_body.size() + 1U));
        const bool shrink_rejected = ftruncate_rejected_with_eperm(
            snapshot.get(), static_cast<off_t>(original_body.size() - 1U));
        const bool sealed_bytes_retained =
            pread_exact(snapshot.get(), original_body.size())
                == std::string("MRIGINAL-ARCHIVE-BYTES");

        const bool pass = opened_regular && path_identity_changed
            && pinned_reads_original && reopened_reads_replacement
            && symlink_leaf_rejected && regular_check_rejects_directory
            && duplicate_shares_offset && pread_ignores_shared_offset
            && memfd_regular_unlinked && mode_only_writer_survives
            && all_required_seals && retained_writer_rejected
            && growth_rejected && shrink_rejected && sealed_bytes_retained;
        if (!pass) throw std::runtime_error("probe predicate failed");

        write_text(output / "release-fd-cases.tsv",
            "case\texpected\tobserved\tstatus\n"
            "open_regular_once\tregular file\tregular file\tPASS\n"
            "pinned_fd_after_path_replace\toriginal bytes\toriginal bytes\tPASS\n"
            "reopened_path_after_replace\treplacement bytes\treplacement bytes\tPASS\n"
            "path_identity_after_replace\tdifferent inode\tdifferent inode\tPASS\n"
            "nofollow_symlink_leaf\tELOOP\tELOOP\tPASS\n"
            "fstat_directory_leaf\tnonregular\tnonregular\tPASS\n"
            "duplicated_fd_cursor\tshared offset\tshared offset\tPASS\n"
            "pread_cursor\tposition independent\tposition independent\tPASS\n"
            "memfd_snapshot_identity\tregular and unlinked\tregular and unlinked\tPASS\n"
            "memfd_required_seals\tWRITE|GROW|SHRINK|SEAL\tWRITE|GROW|SHRINK|SEAL\tPASS\n"
            "retained_writer_after_seal\tEPERM\tEPERM\tPASS\n"
            "sealed_resize\tgrow and shrink EPERM\tgrow and shrink EPERM\tPASS\n");
        write_text(output / "release-fd-counterexamples.tsv",
            "id\ttempting_inference\tcounterexample\tconsequence\n"
            "CF01\tdigesting a pathname pins later parsing\tpathname reopen sees replacement bytes\tparse only a captured open object\n"
            "CF02\tO_NOFOLLOW proves regular-file custody\tdirectory opens successfully with O_NOFOLLOW\tfstat and S_ISREG remain mandatory\n"
            "CF03\tdup creates an independent read cursor\tduplicated descriptors share one open-file-description offset\tuse pread or one immutable snapshot\n"
            "CF04\tthe same pathname denotes the same release object\trename replacement preserves spelling while changing inode\tpathname is locator not identity\n"
            "CF05\tan anonymous unlinked snapshot is immutable\ta retained O_RDWR descriptor changes the memfd bytes\twrite-seal the complete inode before digest comparison\n"
            "CF06\tfchmod 0400 revokes already-open writers\tthe retained writer changes bytes after mode removal\tmode bits do not replace F_SEAL_WRITE\n");
        write_text(output / "release-fd-summary.json",
            "{\n"
            "  \"archive_payload_executed\": false,\n"
            "  \"cases\": 12,\n"
            "  \"counterexamples\": 6,\n"
            "  \"duplicate_shares_open_description_offset\": true,\n"
            "  \"fchmod_only_retained_writer\": true,\n"
            "  \"memfd_regular_unlinked\": true,\n"
            "  \"opened_regular_file\": true,\n"
            "  \"path_identity_changed_after_replace\": true,\n"
            "  \"path_reopen_reads_replacement\": true,\n"
            "  \"pinned_fd_reads_original\": true,\n"
            "  \"pread_position_independent\": true,\n"
            "  \"required_seals_observed\": true,\n"
            "  \"retained_writer_rejected_after_seal\": true,\n"
            "  \"schema\": \"slopos.rev0899.release-fd-probe.v2\",\n"
            "  \"sealed_grow_rejected\": true,\n"
            "  \"sealed_shrink_rejected\": true,\n"
            "  \"status\": \"PASS\",\n"
            "  \"symlink_leaf_rejected\": true\n"
            "}\n");
        std::cout
            << "RELEASE_FD_PROBE=PASS cases=12 counterexamples=6 "
            << "pinned_original=true reopened_replacement=true "
            << "memfd=REGULAR_UNLINKED seals=WRITE_GROW_SHRINK_SEAL "
            << "retained_writer=EPERM resize=EPERM "
            << "payload_executed=false\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "RELEASE_FD_PROBE=FAIL detail=" << error.what() << '\n';
        return 1;
    }
}
