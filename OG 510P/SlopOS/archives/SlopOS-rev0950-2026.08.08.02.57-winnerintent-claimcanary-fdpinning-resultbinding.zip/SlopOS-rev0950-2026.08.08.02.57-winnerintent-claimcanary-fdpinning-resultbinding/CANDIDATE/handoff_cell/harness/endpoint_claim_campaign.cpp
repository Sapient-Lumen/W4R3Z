#include "endpoint_claim_campaign.hpp"

#include "slopos/e0/handoff_cell/cell.hpp"
#include "slopos/e0/handoff_cell/endpoint_claim.hpp"

#include <algorithm>
#include <array>
#include <cerrno>
#include <csignal>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

#include <fcntl.h>
#include <linux/fs.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

namespace slopos::e0::handoff_cell::harness {
namespace {

using generation_journal::EncodedRecord;
using generation_journal::Record;
using generation_journal::RecordKind;

static_assert(!std::is_copy_constructible_v<ClaimedPending>);
static_assert(!std::is_copy_assignable_v<ClaimedPending>);
static_assert(std::is_move_constructible_v<ClaimedPending>);
static_assert(std::is_copy_constructible_v<EndpointClaimObservation>);

struct UniqueFd final {
    int value{-1};
    UniqueFd() = default;
    explicit UniqueFd(const int fd) noexcept : value(fd) {}
    UniqueFd(const UniqueFd&) = delete;
    UniqueFd& operator=(const UniqueFd&) = delete;
    UniqueFd(UniqueFd&& other) noexcept : value(other.value) {
        other.value = -1;
    }
    UniqueFd& operator=(UniqueFd&& other) noexcept {
        if (this != &other) {
            if (value >= 0) (void)::close(value);
            value = other.value;
            other.value = -1;
        }
        return *this;
    }
    ~UniqueFd() {
        if (value >= 0) (void)::close(value);
    }
};

struct Shape final {
    bool pending{false};
    bool claimed{false};
    std::uint64_t claimed_links{0U};
};

struct CaseRow final {
    std::string name;
    std::string claim;
    std::string payload;
    bool pending{false};
    bool claimed{false};
    unsigned int fresh_tokens{0U};
    unsigned int payload_entries{0U};
    unsigned int exact_accepts{0U};
    bool query_only{true};
    bool retained_counterexample{false};
    std::string judgment;
};

struct CounterexampleRow final {
    std::string name;
    bool reproduced{false};
    std::string defeats;
    std::string retained_law;
};

struct CrashRow final {
    std::string cut;
    bool pending{false};
    bool claimed{false};
    std::string reopen;
    unsigned int payload_entries_after_reopen{0U};
};

struct RaceReport final {
    std::int32_t disposition{0};
    std::int32_t fresh{0};
    std::int32_t payload_examined{0};
    std::int32_t exact{0};
};

[[noreturn]] void fail(const std::string& detail) {
    throw std::runtime_error(detail);
}

void require(const bool condition, const std::string& detail) {
    if (!condition) fail(detail);
}

[[nodiscard]] std::string bool_text(const bool value) {
    return value ? "true" : "false";
}

void put_u32(EndpointRequest& request, const std::size_t offset,
             const std::uint32_t value) noexcept {
    for (std::size_t index = 0U; index < 4U; ++index) {
        request[offset + index] = static_cast<std::uint8_t>(
            value >> static_cast<unsigned int>(index * 8U));
    }
}

void put_u64(EndpointRequest& request, const std::size_t offset,
             const std::uint64_t value) noexcept {
    for (std::size_t index = 0U; index < 8U; ++index) {
        request[offset + index] = static_cast<std::uint8_t>(
            value >> static_cast<unsigned int>(index * 8U));
    }
}

[[nodiscard]] EndpointRequest make_request(const EncodedRecord& pending) {
    Record record;
    require(generation_journal::decode_record(pending, record),
            "decode request fixture");
    EndpointRequest request{};
    constexpr std::array<std::uint8_t, 8U> magic{
        'S', 'L', 'O', 'P', 'E', 'P', 'C', '1'};
    std::copy(magic.begin(), magic.end(), request.begin());
    put_u32(request, 8U, 1U);
    put_u64(request, 16U, record.generation_from);
    put_u64(request, 24U, record.generation_to);
    std::copy(record.operation_binding.begin(), record.operation_binding.end(),
              request.begin() + 32);
    std::copy(record.spent_receipt_binding.begin(),
              record.spent_receipt_binding.end(), request.begin() + 64);
    return request;
}

[[nodiscard]] EncodedRecord alternate_pending(
    const EncodedRecord& pending) {
    Record record;
    require(generation_journal::decode_record(pending, record),
            "decode alternate fixture");
    record.operation_binding[0] ^= 0x5aU;
    EncodedRecord alternate{};
    require(generation_journal::encode_record(record, alternate),
            "encode alternate fixture");
    return alternate;
}

[[nodiscard]] std::filesystem::path make_cell(
    const std::filesystem::path& scratch, const std::string& name) {
    const auto path = scratch / ("endpoint-claim-" + name);
    require(std::filesystem::create_directory(path), "create cell " + name);
    require(::chmod(path.c_str(), static_cast<mode_t>(0700)) == 0,
            "chmod cell " + name);
    return path;
}

[[nodiscard]] UniqueFd open_directory(const std::filesystem::path& path) {
    const int fd = ::open(path.c_str(), O_RDONLY | O_DIRECTORY | O_CLOEXEC);
    require(fd >= 0, "open cell directory");
    return UniqueFd(fd);
}

void write_complete(const int fd, const EncodedRecord& bytes) {
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const ssize_t count = ::write(fd, bytes.data() + offset,
                                      bytes.size() - offset);
        if (count < 0 && errno == EINTR) continue;
        require(count > 0, "write fixture record");
        offset += static_cast<std::size_t>(count);
    }
}

[[nodiscard]] UniqueFd write_leaf_keep_fd(
    const int directory_fd, const char* leaf, const EncodedRecord& bytes) {
    UniqueFd fd(::openat(directory_fd, leaf,
                         O_RDWR | O_CREAT | O_EXCL | O_CLOEXEC,
                         S_IRUSR | S_IWUSR));
    require(fd.value >= 0, std::string("open fixture ") + leaf);
    write_complete(fd.value, bytes);
    require(::fdatasync(fd.value) == 0, "fdatasync fixture");
    require(::fchmod(fd.value, S_IRUSR) == 0, "chmod fixture read-only");
    require(::fsync(directory_fd) == 0, "fsync fixture directory");
    return fd;
}

void write_leaf(const int directory_fd, const char* leaf,
                const EncodedRecord& bytes) {
    UniqueFd fd = write_leaf_keep_fd(directory_fd, leaf, bytes);
}

[[nodiscard]] Shape observe(const int directory_fd) {
    Shape shape;
    struct stat status {};
    if (::fstatat(directory_fd, kPendingLeaf, &status,
                  AT_SYMLINK_NOFOLLOW) == 0) {
        shape.pending = true;
    } else {
        require(errno == ENOENT, "observe pending");
    }
    if (::fstatat(directory_fd, kClaimedLeaf, &status,
                  AT_SYMLINK_NOFOLLOW) == 0) {
        shape.claimed = true;
        shape.claimed_links = static_cast<std::uint64_t>(status.st_nlink);
    } else {
        require(errno == ENOENT, "observe claimed");
    }
    return shape;
}

[[nodiscard]] EndpointClaimCell retain_claim(const int directory_fd) {
    int error_number = 0;
    auto cell = EndpointClaimCell::retain_host_cell_directory(
        directory_fd, ::geteuid(), error_number);
    require(cell.has_value(),
            "retain claim errno=" + std::to_string(error_number));
    return std::move(*cell);
}

[[nodiscard]] PayloadParseResult parse_fresh(
    EndpointClaimAttempt& attempt, const EndpointRequest& request) {
    require(attempt.fresh.has_value(), "fresh token required");
    return PayloadAfterClaim::parse_exact(
        std::move(*attempt.fresh), request);
}

void write_one(const int fd, const char value) noexcept {
    ssize_t count = -1;
    do {
        count = ::write(fd, &value, 1U);
    } while (count < 0 && errno == EINTR);
    if (count != 1) _exit(121);
}

[[nodiscard]] char read_one(const int fd) {
    char value = '\0';
    ssize_t count = -1;
    do {
        count = ::read(fd, &value, 1U);
    } while (count < 0 && errno == EINTR);
    require(count == 1, "read synchronization byte");
    return value;
}

void write_report(const int fd, const RaceReport& report) noexcept {
    const auto* bytes = reinterpret_cast<const std::uint8_t*>(&report);
    std::size_t offset = 0U;
    while (offset < sizeof(report)) {
        const ssize_t count = ::write(fd, bytes + offset,
                                      sizeof(report) - offset);
        if (count < 0 && errno == EINTR) continue;
        if (count <= 0) _exit(122);
        offset += static_cast<std::size_t>(count);
    }
}

[[nodiscard]] RaceReport read_report(const int fd) {
    RaceReport report;
    auto* bytes = reinterpret_cast<std::uint8_t*>(&report);
    std::size_t offset = 0U;
    while (offset < sizeof(report)) {
        const ssize_t count = ::read(fd, bytes + offset,
                                     sizeof(report) - offset);
        if (count < 0 && errno == EINTR) continue;
        require(count > 0, "read race report");
        offset += static_cast<std::size_t>(count);
    }
    return report;
}

void wait_success(const pid_t child) {
    int status = 0;
    require(::waitpid(child, &status, 0) == child, "wait child");
    require(WIFEXITED(status) && WEXITSTATUS(status) == 0,
            "child exited unsuccessfully");
}

void wait_killed(const pid_t child) {
    int status = 0;
    require(::waitpid(child, &status, 0) == child, "wait killed child");
    require(WIFSIGNALED(status) && WTERMSIG(status) == SIGKILL,
            "child did not stop at SIGKILL cut");
}

[[nodiscard]] int raw_claim(const int directory_fd) noexcept {
#if defined(SYS_renameat2)
    return static_cast<int>(::syscall(
        SYS_renameat2, directory_fd, kPendingLeaf, directory_fd,
        kClaimedLeaf, static_cast<unsigned int>(RENAME_NOREPLACE)));
#else
    (void)directory_fd;
    errno = ENOSYS;
    return -1;
#endif
}

[[nodiscard]] CrashRow run_crash_cut(
    const std::filesystem::path& scratch, const std::string& name,
    const int phase, const EncodedRecord& pending,
    const EndpointRequest& request) {
    const auto path = make_cell(scratch, "crash-" + name);
    const UniqueFd directory = open_directory(path);
    write_leaf(directory.value, kPendingLeaf, pending);
    int pipe_fds[2]{};
    require(::pipe2(pipe_fds, O_CLOEXEC) == 0, "crash signal pipe");
    UniqueFd reader(pipe_fds[0]);
    UniqueFd writer(pipe_fds[1]);
    const pid_t child = ::fork();
    require(child >= 0, "fork crash child");
    if (child == 0) {
        (void)::close(reader.value);
        if (phase == 0) {
            write_one(writer.value, 'B');
        } else if (phase == 1) {
            if (raw_claim(directory.value) != 0) _exit(123);
            write_one(writer.value, 'R');
        } else {
            EndpointClaimCell cell = retain_claim(directory.value);
            EndpointClaimAttempt attempt = cell.claim_pending_exact(pending);
            if (!attempt.fresh.has_value()) _exit(124);
            if (phase == 2) {
                write_one(writer.value, 'T');
            } else {
                if (!parse_fresh(attempt, request).exact()) _exit(125);
                write_one(writer.value, 'P');
            }
        }
        for (;;) ::pause();
    }
    (void)::close(writer.value);
    writer.value = -1;
    (void)read_one(reader.value);
    require(::kill(child, SIGKILL) == 0, "kill crash child");
    wait_killed(child);

    const Shape shape = observe(directory.value);
    EndpointClaimCell reopened = retain_claim(directory.value);
    std::string reopen;
    if (phase == 0) {
        const EndpointClaimObservation query =
            reopened.observe_claimed_exact(pending);
        require(query.disposition == EndpointClaimDisposition::pending_missing,
                "before-claim reopen should see no claimed leaf");
        reopen = "NO_CLAIMED_OBSERVATION";
    } else {
        EndpointClaimAttempt duplicate = reopened.claim_pending_exact(pending);
        require(duplicate.observation.disposition
                    == EndpointClaimDisposition::already_claimed_exact
                    && duplicate.observation.query_only
                    && !duplicate.fresh.has_value(),
                "post-claim reopen must be query-only");
        reopen = "ALREADY_CLAIMED_EXACT_QUERY_ONLY";
    }
    return {name, shape.pending, shape.claimed, reopen, 0U};
}

void write_cases(const std::filesystem::path& output,
                 const std::vector<CaseRow>& rows) {
    std::ofstream stream(output / "endpoint-claim-cases.tsv", std::ios::binary);
    require(stream.good(), "open endpoint claim cases");
    stream << "case\tclaim\tpayload\tpending\tclaimed\tfresh_tokens"
              "\tpayload_entries\texact_accepts\tquery_only"
              "\tretained_counterexample\tjudgment\n";
    for (const CaseRow& row : rows) {
        stream << row.name << '\t' << row.claim << '\t' << row.payload << '\t'
               << bool_text(row.pending) << '\t' << bool_text(row.claimed)
               << '\t' << row.fresh_tokens << '\t' << row.payload_entries
               << '\t' << row.exact_accepts << '\t'
               << bool_text(row.query_only) << '\t'
               << bool_text(row.retained_counterexample) << '\t'
               << row.judgment << '\n';
    }
}

void write_counterexamples(
    const std::filesystem::path& output,
    const std::vector<CounterexampleRow>& rows) {
    std::ofstream stream(
        output / "endpoint-claim-counterexamples.tsv", std::ios::binary);
    require(stream.good(), "open endpoint claim counterexamples");
    stream << "counterexample\treproduced\tdefeats\tretained_law\n";
    for (const CounterexampleRow& row : rows) {
        stream << row.name << '\t' << bool_text(row.reproduced) << '\t'
               << row.defeats << '\t' << row.retained_law << '\n';
    }
}

void write_crashes(const std::filesystem::path& output,
                   const std::vector<CrashRow>& rows) {
    std::ofstream stream(
        output / "endpoint-claim-crash-cuts.tsv", std::ios::binary);
    require(stream.good(), "open endpoint claim crash cuts");
    stream << "cut\tpending\tclaimed\treopen"
              "\tpayload_entries_after_reopen\n";
    for (const CrashRow& row : rows) {
        stream << row.cut << '\t' << bool_text(row.pending) << '\t'
               << bool_text(row.claimed) << '\t' << row.reopen << '\t'
               << row.payload_entries_after_reopen << '\n';
    }
}

void write_race(const std::filesystem::path& output,
                const unsigned int fresh, const unsigned int duplicates,
                const unsigned int entries, const unsigned int exact) {
    std::ofstream stream(
        output / "endpoint-claim-races.tsv", std::ios::binary);
    require(stream.good(), "open endpoint claim races");
    stream << "scenario\tcontenders\tfresh_claims\tquery_only_duplicates"
              "\tpayload_entries\texact_accepts\tjudgment\n"
           << "sixteen_process_fixed_claim\t16\t" << fresh << '\t'
           << duplicates << '\t' << entries << '\t' << exact
           << "\tONE_LOCAL_WINNER\n";
}

void write_summary(const std::filesystem::path& output,
                   const std::size_t cases,
                   const std::size_t counterexamples,
                   const std::size_t crash_cuts) {
    std::ofstream stream(
        output / "endpoint-claim-summary.json", std::ios::binary);
    require(stream.good(), "open endpoint claim summary");
    stream
        << "{\n"
        << "  \"authority_granted\": false,\n"
        << "  \"cases\": " << cases << ",\n"
        << "  \"claim_before_payload_parse_observed\": true,\n"
        << "  \"claim_leaf\": \"claimed\",\n"
        << "  \"coherent_clone_fresh_claims\": 2,\n"
        << "  \"counterexamples_reproduced\": " << counterexamples << ",\n"
        << "  \"crash_cuts\": " << crash_cuts << ",\n"
        << "  \"directory_snapshot_rollback_reproduced\": true,\n"
        << "  \"duplicate_claim_query_only\": true,\n"
        << "  \"effect_performed\": false,\n"
        << "  \"external_rollback_floor\": false,\n"
        << "  \"fixed_claim_mutation_entrypoints\": 1,\n"
        << "  \"fixed_pending_leaf\": \"pending\",\n"
        << "  \"global_unique_claim_proved\": false,\n"
        << "  \"hardlink_alias_counterexample_reproduced\": true,\n"
        << "  \"inherited_writer_counterexample_reproduced\": true,\n"
        << "  \"maximum_payload_entries_per_fresh_local_claim\": 1,\n"
        << "  \"move_only_claim_token\": true,\n"
        << "  \"payload_parser_entrypoints\": 1,\n"
        << "  \"payload_request_bytes\": 96,\n"
        << "  \"physical_power_loss_proved\": false,\n"
        << "  \"protected_pending_entry_claim\": false,\n"
        << "  \"race_contenders\": 16,\n"
        << "  \"race_exact_accepts\": 1,\n"
        << "  \"race_fresh_claims\": 1,\n"
        << "  \"race_payload_entries\": 1,\n"
        << "  \"race_query_only_duplicates\": 15,\n"
        << "  \"recovery_payload_entrypoints\": 0,\n"
        << "  \"rename_flag\": \"RENAME_NOREPLACE\",\n"
        << "  \"response_authority\": false,\n"
        << "  \"schema\": \"slopos.rev0895.endpoint-claim-before-parse-evidence.v1\",\n"
        << "  \"settlement_implemented\": false,\n"
        << "  \"source_to_binary_proved\": false,\n"
        << "  \"stable_media_proved\": false,\n"
        << "  \"sync_uncertain_claim_query_only\": true,\n"
        << "  \"sync_uncertain_fresh_claims\": 0,\n"
        << "  \"sync_uncertain_namespace_claimed\": true,\n"
        << "  \"sync_uncertain_payload_entries\": 0,\n"
        << "  \"sync_uncertain_reopen_query_only\": true,\n"
        << "  \"status\": \"PASS\"\n"
        << "}\n";
}

}  // namespace

EndpointClaimCampaignCounts run_endpoint_claim_campaign(
    const std::filesystem::path& output,
    const std::filesystem::path& scratch,
    const EncodedRecord& pending) {
    const EndpointRequest request = make_request(pending);
    std::vector<CaseRow> rows;
    std::vector<CounterexampleRow> counterexamples;

    {
        const auto path = make_cell(scratch, "exact");
        const UniqueFd directory = open_directory(path);
        write_leaf(directory.value, kPendingLeaf, pending);
        EndpointClaimCell cell = retain_claim(directory.value);
        EndpointClaimAttempt fresh = cell.claim_pending_exact(pending);
        require(fresh.observation.fresh_exact() && fresh.fresh.has_value()
                    && !fresh.observation.query_only,
                "fresh exact claim");
        const PayloadParseResult parsed = parse_fresh(fresh, request);
        require(parsed.exact() && parsed.payload_examined
                    && !parsed.effect_performed && !parsed.response_authority,
                "exact payload parse");
        rows.push_back({
            "exact_claim_precedes_payload",
            endpoint_claim_name(fresh.observation.disposition),
            payload_disposition_name(parsed.disposition),
            false, true, 1U, 1U, 1U, false, false,
            "FRESH_TOKEN_ENTERS_ONLY_PARSER",
        });
        EndpointClaimAttempt duplicate = cell.claim_pending_exact(pending);
        require(duplicate.observation.disposition
                    == EndpointClaimDisposition::already_claimed_exact
                    && !duplicate.fresh.has_value()
                    && duplicate.observation.query_only,
                "duplicate exact query-only");
        rows.push_back({
            "duplicate_after_exact_is_query_only",
            endpoint_claim_name(duplicate.observation.disposition),
            "NOT_CALLED", false, true, 0U, 0U, 0U, true, false,
            "OBSERVATION_CANNOT_REENTER_PAYLOAD",
        });
    }

    {
        const auto path = make_cell(scratch, "malformed-payload");
        const UniqueFd directory = open_directory(path);
        write_leaf(directory.value, kPendingLeaf, pending);
        EndpointClaimCell cell = retain_claim(directory.value);
        EndpointClaimAttempt fresh = cell.claim_pending_exact(pending);
        EndpointRequest malformed = request;
        malformed[0] ^= 0xffU;
        const PayloadParseResult parsed = parse_fresh(fresh, malformed);
        require(parsed.disposition == PayloadDisposition::malformed_request
                    && parsed.payload_examined,
                "malformed payload consumes claim");
        rows.push_back({
            "malformed_payload_consumes_claim",
            endpoint_claim_name(fresh.observation.disposition),
            payload_disposition_name(parsed.disposition),
            false, true, 1U, 1U, 0U, false, false,
            "MALFORMED_CANNOT_RESTORE_ELIGIBILITY",
        });
        EndpointClaimAttempt retry = cell.claim_pending_exact(pending);
        require(retry.observation.disposition
                    == EndpointClaimDisposition::already_claimed_exact
                    && !retry.fresh.has_value(),
                "malformed retry query-only");
        rows.push_back({
            "retry_after_malformed_is_query_only",
            endpoint_claim_name(retry.observation.disposition),
            "NOT_CALLED", false, true, 0U, 0U, 0U, true, false,
            "REPLY_LOSS_OR_RETRY_DOES_NOT_REPARSE",
        });
    }

    {
        const auto path = make_cell(scratch, "malformed-record");
        const UniqueFd directory = open_directory(path);
        EncodedRecord malformed = pending;
        malformed[0] ^= 0xffU;
        write_leaf(directory.value, kPendingLeaf, malformed);
        EndpointClaimCell cell = retain_claim(directory.value);
        EndpointClaimAttempt attempt = cell.claim_pending_exact(malformed);
        require(attempt.observation.disposition
                    == EndpointClaimDisposition::decode_rejected
                    && attempt.observation.namespace_claimed
                    && !attempt.fresh.has_value(),
                "decode failure after claim");
        rows.push_back({
            "malformed_pending_claims_then_fails_stop",
            endpoint_claim_name(attempt.observation.disposition),
            "NOT_CALLED", false, true, 0U, 0U, 0U, true, false,
            "NO_REVERSE_RENAME_AFTER_DECODE_FAILURE",
        });
    }

    {
        const auto path = make_cell(scratch, "fifo");
        const UniqueFd directory = open_directory(path);
        require(::mkfifoat(directory.value, kPendingLeaf, S_IRUSR) == 0,
                "create fifo pending");
        require(::fsync(directory.value) == 0, "fsync fifo fixture");
        EndpointClaimCell cell = retain_claim(directory.value);
        EndpointClaimAttempt attempt = cell.claim_pending_exact(pending);
        require(attempt.observation.disposition
                    == EndpointClaimDisposition::not_regular
                    && attempt.observation.namespace_claimed,
                "fifo rejected after claim");
        rows.push_back({
            "fifo_claims_then_rejects_nonregular",
            endpoint_claim_name(attempt.observation.disposition),
            "NOT_CALLED", false, true, 0U, 0U, 0U, true, false,
            "NONREGULAR_OBJECT_CANNOT_BLOCK_OR_PARSE",
        });
    }

    {
        const auto path = make_cell(scratch, "preexisting-exact");
        const UniqueFd directory = open_directory(path);
        write_leaf(directory.value, kPendingLeaf, pending);
        write_leaf(directory.value, kClaimedLeaf, pending);
        EndpointClaimCell cell = retain_claim(directory.value);
        EndpointClaimAttempt attempt = cell.claim_pending_exact(pending);
        const Shape shape = observe(directory.value);
        require(attempt.observation.disposition
                    == EndpointClaimDisposition::already_claimed_exact
                    && shape.pending && shape.claimed,
                "preexisting exact no-replace");
        rows.push_back({
            "preexisting_claimed_exact_is_query_only",
            endpoint_claim_name(attempt.observation.disposition),
            "NOT_CALLED", true, true, 0U, 0U, 0U, true, false,
            "NOREPLACE_PRESERVES_BOTH_NAMES",
        });
    }

    {
        const auto path = make_cell(scratch, "preexisting-conflict");
        const UniqueFd directory = open_directory(path);
        write_leaf(directory.value, kPendingLeaf, pending);
        write_leaf(directory.value, kClaimedLeaf, alternate_pending(pending));
        EndpointClaimCell cell = retain_claim(directory.value);
        EndpointClaimAttempt attempt = cell.claim_pending_exact(pending);
        require(attempt.observation.disposition
                    == EndpointClaimDisposition::exact_mismatch
                    && !attempt.fresh.has_value(),
                "preexisting conflict fail-stop");
        rows.push_back({
            "preexisting_claimed_conflict_fails_stop",
            endpoint_claim_name(attempt.observation.disposition),
            "NOT_CALLED", true, true, 0U, 0U, 0U, true, false,
            "CONFLICT_IS_NOT_REPAIR_AUTHORITY",
        });
    }

    {
        const auto path = make_cell(scratch, "missing");
        const UniqueFd directory = open_directory(path);
        EndpointClaimCell cell = retain_claim(directory.value);
        EndpointClaimAttempt attempt = cell.claim_pending_exact(pending);
        require(attempt.observation.disposition
                    == EndpointClaimDisposition::pending_missing
                    && !attempt.fresh.has_value(),
                "missing pending no mint");
        rows.push_back({
            "missing_pending_no_mint",
            endpoint_claim_name(attempt.observation.disposition),
            "NOT_CALLED", false, false, 0U, 0U, 0U, true, false,
            "ABSENCE_IS_NOT_AUTHORITY",
        });
    }


    {
        // Deterministic late-sync fault: renameat2 accepts an O_PATH directory
        // descriptor as a dirfd, while fsync on that descriptor fails EBADF.
        // The completed namespace cut must remain claimed and query-only.
        const auto path = make_cell(scratch, "sync-uncertain");
        const UniqueFd directory = open_directory(path);
        write_leaf(directory.value, kPendingLeaf, pending);
        const UniqueFd path_only(::open(
            path.c_str(), O_PATH | O_DIRECTORY | O_CLOEXEC));
        require(path_only.value >= 0, "open O_PATH sync fault fixture");
        EndpointClaimCell cell = retain_claim(path_only.value);
        EndpointClaimAttempt attempt = cell.claim_pending_exact(pending);
        const Shape shape = observe(directory.value);
        require(attempt.observation.disposition
                    == EndpointClaimDisposition::claimed_exact_sync_uncertain
                    && attempt.observation.synchronization_uncertain()
                    && !attempt.observation.fresh_exact()
                    && attempt.observation.error_number == EBADF
                    && attempt.observation.namespace_claimed
                    && attempt.observation.query_only
                    && !attempt.observation.response_authority
                    && !attempt.fresh.has_value()
                    && !shape.pending && shape.claimed,
                "sync uncertainty cannot mint parser eligibility");
        EndpointClaimCell reopened = retain_claim(directory.value);
        const EndpointClaimObservation observed =
            reopened.observe_claimed_exact(pending);
        require(observed.disposition
                    == EndpointClaimDisposition::already_claimed_exact
                    && observed.namespace_claimed && observed.query_only
                    && !observed.fresh_exact(),
                "sync uncertain reopen remains query-only");
        rows.push_back({
            "directory_sync_failure_denies_parser",
            endpoint_claim_name(attempt.observation.disposition),
            "NOT_CALLED", false, true, 0U, 0U, 0U, true, false,
            "SYNC_UNCERTAINTY_CANNOT_MINT_FIRST_SEMANTICS",
        });
    }

    {
        const auto path = make_cell(scratch, "hardlink");
        const UniqueFd directory = open_directory(path);
        write_leaf(directory.value, kPendingLeaf, pending);
        require(::linkat(directory.value, kPendingLeaf,
                         directory.value, "alias", 0) == 0,
                "create hardlink alias");
        require(::fsync(directory.value) == 0, "fsync hardlink alias");
        EndpointClaimCell cell = retain_claim(directory.value);
        EndpointClaimAttempt attempt = cell.claim_pending_exact(pending);
        const Shape shape = observe(directory.value);
        require(attempt.observation.disposition
                    == EndpointClaimDisposition::alias_detected
                    && shape.claimed_links == 2U,
                "hardlink survives namespace claim");
        rows.push_back({
            "hardlink_alias_detected_after_claim",
            endpoint_claim_name(attempt.observation.disposition),
            "NOT_CALLED", false, true, 0U, 0U, 0U, true, true,
            "NAMESPACE_NAME_IS_NOT_SINGULAR_OBJECT_CUSTODY",
        });
        counterexamples.push_back({
            "hard_link_alias_survives_namespace_claim", true,
            "singular_claimed_object_identity",
            "post_claim_link_count_must_be_one_or_fail_stop",
        });
    }

    {
        const auto path = make_cell(scratch, "writer");
        const UniqueFd directory = open_directory(path);
        UniqueFd writer = write_leaf_keep_fd(
            directory.value, kPendingLeaf, pending);
        EndpointClaimCell cell = retain_claim(directory.value);
        EndpointClaimAttempt attempt = cell.claim_pending_exact(pending);
        require(attempt.fresh.has_value(), "writer fixture fresh claim");
        const std::uint8_t changed = 0x7fU;
        require(::pwrite(writer.value, &changed, 1U, 20) == 1,
                "mutate inherited writer");
        require(::fdatasync(writer.value) == 0, "sync inherited writer");
        const PayloadParseResult parsed = parse_fresh(attempt, request);
        const EndpointClaimObservation observed =
            cell.observe_claimed_exact(pending);
        require(parsed.exact()
                    && observed.disposition
                        == EndpointClaimDisposition::exact_mismatch,
                "token snapshot not content custody");
        rows.push_back({
            "inherited_writer_defeats_content_custody",
            endpoint_claim_name(attempt.observation.disposition),
            payload_disposition_name(parsed.disposition),
            false, true, 1U, 1U, 1U, false, true,
            "TOKEN_SNAPSHOT_IS_NOT_IMMUTABLE_OBJECT",
        });
        counterexamples.push_back({
            "open_writable_descriptor_survives_claim", true,
            "immutable_claimed_content_custody",
            "writer_exclusion_is_an_external_provider_obligation",
        });
    }

    {
        const auto first_path = make_cell(scratch, "clone-first");
        const UniqueFd first_dir = open_directory(first_path);
        write_leaf(first_dir.value, kPendingLeaf, pending);
        const auto second_path = scratch / "endpoint-claim-clone-second";
        std::filesystem::copy(
            first_path, second_path,
            std::filesystem::copy_options::recursive);
        require(::chmod(second_path.c_str(), static_cast<mode_t>(0700)) == 0,
                "chmod clone cell");
        const UniqueFd second_dir = open_directory(second_path);
        EndpointClaimCell first = retain_claim(first_dir.value);
        EndpointClaimCell second = retain_claim(second_dir.value);
        EndpointClaimAttempt a = first.claim_pending_exact(pending);
        EndpointClaimAttempt b = second.claim_pending_exact(pending);
        require(a.fresh.has_value() && b.fresh.has_value(),
                "coherent clone claims twice");
        require(parse_fresh(a, request).exact()
                    && parse_fresh(b, request).exact(),
                "coherent clone parses twice");
        rows.push_back({
            "coherent_clone_claims_once_per_history",
            "TWO_CLAIMED_EXACT", "TWO_EXACT_REQUESTS",
            false, true, 2U, 2U, 2U, false, true,
            "LOCAL_NOREPLACE_IS_NOT_GLOBAL_SPEND",
        });
        counterexamples.push_back({
            "coherent_directory_clone_claims_once_each", true,
            "globally_unique_claim_spend",
            "owner_admitted_nonrollback_provider_remains_required",
        });
    }

    {
        const auto live_path = make_cell(scratch, "rollback-live");
        {
            const UniqueFd directory = open_directory(live_path);
            write_leaf(directory.value, kPendingLeaf, pending);
        }
        const auto snapshot_path = scratch / "endpoint-claim-rollback-snapshot";
        std::filesystem::copy(
            live_path, snapshot_path,
            std::filesystem::copy_options::recursive);
        require(::chmod(snapshot_path.c_str(), static_cast<mode_t>(0700)) == 0,
                "chmod rollback snapshot");
        {
            const UniqueFd directory = open_directory(live_path);
            EndpointClaimCell cell = retain_claim(directory.value);
            EndpointClaimAttempt first = cell.claim_pending_exact(pending);
            require(first.fresh.has_value()
                        && parse_fresh(first, request).exact(),
                    "first rollback history claim");
        }
        std::filesystem::remove_all(live_path);
        std::filesystem::rename(snapshot_path, live_path);
        {
            const UniqueFd directory = open_directory(live_path);
            EndpointClaimCell cell = retain_claim(directory.value);
            EndpointClaimAttempt restored = cell.claim_pending_exact(pending);
            require(restored.fresh.has_value()
                        && parse_fresh(restored, request).exact(),
                    "restored rollback history claim");
        }
        rows.push_back({
            "snapshot_rollback_restores_pending",
            "TWO_CLAIMED_EXACT_ACROSS_ROLLBACK", "TWO_EXACT_REQUESTS",
            false, true, 2U, 2U, 2U, false, true,
            "NEWESTNESS_REQUIRES_EXTERNAL_FLOOR",
        });
        counterexamples.push_back({
            "directory_snapshot_rollback_restores_pending", true,
            "newest_claimed_history_and_durable_spend",
            "local_reopen_must_not_claim_nonrollback_or_stable_media",
        });
    }

    // Process race. Only aggregate counts are retained, avoiding PID/winner
    // nondeterminism while preserving the sixteen-contender theorem.
    unsigned int race_fresh = 0U;
    unsigned int race_duplicates = 0U;
    unsigned int race_entries = 0U;
    unsigned int race_exact = 0U;
    {
        const auto path = make_cell(scratch, "race");
        const UniqueFd directory = open_directory(path);
        write_leaf(directory.value, kPendingLeaf, pending);
        int start_pipe[2]{};
        int result_pipe[2]{};
        require(::pipe2(start_pipe, O_CLOEXEC) == 0, "race start pipe");
        require(::pipe2(result_pipe, O_CLOEXEC) == 0, "race result pipe");
        UniqueFd start_read(start_pipe[0]);
        UniqueFd start_write(start_pipe[1]);
        UniqueFd result_read(result_pipe[0]);
        UniqueFd result_write(result_pipe[1]);
        std::vector<pid_t> children;
        for (unsigned int index = 0U; index < 16U; ++index) {
            const pid_t child = ::fork();
            require(child >= 0, "fork claim contender");
            if (child == 0) {
                (void)index;
                (void)::close(start_write.value);
                (void)::close(result_read.value);
                (void)read_one(start_read.value);
                EndpointClaimCell cell = retain_claim(directory.value);
                EndpointClaimAttempt attempt = cell.claim_pending_exact(pending);
                RaceReport report;
                report.disposition = static_cast<std::int32_t>(
                    attempt.observation.disposition);
                report.fresh = attempt.fresh.has_value() ? 1 : 0;
                if (attempt.fresh.has_value()) {
                    const PayloadParseResult parsed = parse_fresh(attempt, request);
                    report.payload_examined = parsed.payload_examined ? 1 : 0;
                    report.exact = parsed.exact() ? 1 : 0;
                }
                write_report(result_write.value, report);
                _exit(0);
            }
            children.push_back(child);
        }
        (void)::close(start_read.value);
        start_read.value = -1;
        (void)::close(result_write.value);
        result_write.value = -1;
        for (unsigned int index = 0U; index < 16U; ++index) {
            write_one(start_write.value, 'G');
        }
        (void)::close(start_write.value);
        start_write.value = -1;
        for (unsigned int index = 0U; index < 16U; ++index) {
            const RaceReport report = read_report(result_read.value);
            if (report.fresh == 1) ++race_fresh;
            if (report.disposition == static_cast<std::int32_t>(
                    EndpointClaimDisposition::already_claimed_exact)) {
                ++race_duplicates;
            }
            if (report.payload_examined == 1) ++race_entries;
            if (report.exact == 1) ++race_exact;
        }
        for (const pid_t child : children) wait_success(child);
        require(race_fresh == 1U && race_duplicates == 15U
                    && race_entries == 1U && race_exact == 1U,
                "sixteen process local winner relation");
        write_race(output, race_fresh, race_duplicates,
                   race_entries, race_exact);
    }

    std::vector<CrashRow> crashes;
    crashes.push_back(run_crash_cut(
        scratch, "before_claim_call", 0, pending, request));
    crashes.push_back(run_crash_cut(
        scratch, "after_raw_rename_before_validation", 1, pending, request));
    crashes.push_back(run_crash_cut(
        scratch, "after_fresh_token_before_payload", 2, pending, request));
    crashes.push_back(run_crash_cut(
        scratch, "after_payload_before_reply", 3, pending, request));

    require(rows.size() == 14U, "endpoint claim case inventory");
    require(counterexamples.size() == 4U,
            "endpoint claim counterexample inventory");
    require(crashes.size() == 4U, "endpoint claim crash inventory");
    write_cases(output, rows);
    write_counterexamples(output, counterexamples);
    write_crashes(output, crashes);
    write_summary(output, rows.size(), counterexamples.size(), crashes.size());

    return {rows.size(), counterexamples.size(), 16U, crashes.size()};
}

}  // namespace slopos::e0::handoff_cell::harness
