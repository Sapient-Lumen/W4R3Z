#include <sqlite3.h>

#include <array>
#include <cerrno>
#include <csignal>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

#include <fcntl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

namespace {

using Digest = std::array<std::uint8_t, 32U>;

struct Operation final {
    std::uint64_t generation_from{41U};
    std::uint64_t generation_to{42U};
    Digest floor{};
    Digest predecessor{};
    Digest successor{};
    Digest operation{};
    Digest spend{};
    Digest pending{};
};

struct CaseRow final {
    std::string name;
    bool observed{false};
    bool expected{false};
    bool pass{false};
    std::string judgment;
};

struct CounterexampleRow final {
    std::string name;
    bool reproduced{false};
    std::string defeats;
    std::string retained_law;
};

class Database final {
public:
    Database(const std::filesystem::path& path, const int flags) {
        sqlite3* raw = nullptr;
        const int rc = sqlite3_open_v2(path.c_str(), &raw, flags, nullptr);
        handle_ = raw;
        if (rc != SQLITE_OK) {
            const std::string detail = raw == nullptr
                ? "sqlite open failed" : sqlite3_errmsg(raw);
            if (raw != nullptr) sqlite3_close(raw);
            handle_ = nullptr;
            throw std::runtime_error(detail);
        }
        const int timeout_rc = sqlite3_busy_timeout(handle_, 10000);
        if (timeout_rc != SQLITE_OK) {
            throw std::runtime_error("sqlite busy timeout");
        }
    }
    Database(const Database&) = delete;
    Database& operator=(const Database&) = delete;
    Database(Database&&) = delete;
    Database& operator=(Database&&) = delete;
    ~Database() { if (handle_ != nullptr) sqlite3_close(handle_); }

    [[nodiscard]] sqlite3* get() const noexcept { return handle_; }

private:
    sqlite3* handle_{nullptr};
};

class Statement final {
public:
    Statement(sqlite3* db, const char* sql) {
        const int rc = sqlite3_prepare_v2(db, sql, -1, &handle_, nullptr);
        if (rc != SQLITE_OK) {
            throw std::runtime_error(std::string("prepare: ") + sqlite3_errmsg(db));
        }
    }
    Statement(const Statement&) = delete;
    Statement& operator=(const Statement&) = delete;
    ~Statement() { if (handle_ != nullptr) sqlite3_finalize(handle_); }
    [[nodiscard]] sqlite3_stmt* get() const noexcept { return handle_; }
private:
    sqlite3_stmt* handle_{nullptr};
};

[[noreturn]] void fail(const std::string& detail) {
    throw std::runtime_error(detail);
}

void require(const bool value, const std::string& detail) {
    if (!value) fail(detail);
}

[[nodiscard]] std::string bool_text(const bool value) {
    return value ? "true" : "false";
}

[[nodiscard]] Digest digest(const std::uint8_t base) noexcept {
    Digest out{};
    for (std::size_t index = 0U; index < out.size(); ++index) {
        out[index] = static_cast<std::uint8_t>(
            static_cast<unsigned int>(base)
            + static_cast<unsigned int>(index));
    }
    return out;
}

[[nodiscard]] Operation operation(const std::uint8_t variant = 0U) noexcept {
    Operation value;
    value.floor = digest(11U);
    value.predecessor = digest(51U);
    value.successor = digest(91U);
    value.operation = digest(static_cast<std::uint8_t>(131U + variant));
    value.spend = digest(static_cast<std::uint8_t>(171U + variant));
    value.pending = digest(static_cast<std::uint8_t>(211U + variant));
    return value;
}

void exec(sqlite3* db, const char* sql) {
    char* message = nullptr;
    const int rc = sqlite3_exec(db, sql, nullptr, nullptr, &message);
    if (rc != SQLITE_OK) {
        const std::string detail = message == nullptr
            ? sqlite3_errmsg(db) : message;
        sqlite3_free(message);
        throw std::runtime_error(std::string("sqlite exec: ") + detail);
    }
}

void bind_blob(sqlite3_stmt* stmt, const int index, const Digest& value) {
    const int rc = sqlite3_bind_blob(
        stmt, index, value.data(), static_cast<int>(value.size()),
        SQLITE_TRANSIENT);
    require(rc == SQLITE_OK, "bind digest");
}

[[nodiscard]] Digest column_digest(sqlite3_stmt* stmt, const int column) {
    const auto* bytes = static_cast<const std::uint8_t*>(
        sqlite3_column_blob(stmt, column));
    const int count = sqlite3_column_bytes(stmt, column);
    require(bytes != nullptr && count == 32, "read digest column");
    Digest value{};
    for (std::size_t index = 0U; index < value.size(); ++index) {
        value[index] = bytes[index];
    }
    return value;
}

[[nodiscard]] std::int64_t scalar_i64(sqlite3* db, const char* sql) {
    Statement stmt(db, sql);
    require(sqlite3_step(stmt.get()) == SQLITE_ROW, "scalar row");
    const sqlite3_int64 value = sqlite3_column_int64(stmt.get(), 0);
    require(sqlite3_step(stmt.get()) == SQLITE_DONE, "scalar done");
    return static_cast<std::int64_t>(value);
}

[[nodiscard]] std::string scalar_text(sqlite3* db, const char* sql) {
    Statement stmt(db, sql);
    require(sqlite3_step(stmt.get()) == SQLITE_ROW, "text row");
    const auto* raw = sqlite3_column_text(stmt.get(), 0);
    require(raw != nullptr, "text value");
    const std::string value(reinterpret_cast<const char*>(raw));
    require(sqlite3_step(stmt.get()) == SQLITE_DONE, "text done");
    return value;
}

void remove_sidecars(const std::filesystem::path& path) {
    std::filesystem::remove(path.string() + "-journal");
    std::filesystem::remove(path.string() + "-wal");
    std::filesystem::remove(path.string() + "-shm");
}

void initialize(const std::filesystem::path& path, const Operation& op) {
    std::filesystem::remove(path);
    remove_sidecars(path);
    Database db(path, SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE
                      | SQLITE_OPEN_FULLMUTEX);
    exec(db.get(), "PRAGMA journal_mode=DELETE;");
    exec(db.get(), "PRAGMA synchronous=FULL;");
    exec(db.get(), "PRAGMA foreign_keys=ON;");
    exec(db.get(),
         "CREATE TABLE floor("
         " singleton INTEGER PRIMARY KEY CHECK(singleton=1),"
         " generation INTEGER NOT NULL,"
         " floor BLOB NOT NULL CHECK(length(floor)=32),"
         " head BLOB NOT NULL CHECK(length(head)=32));"
         "CREATE TABLE edges("
         " txid INTEGER PRIMARY KEY,"
         " operation BLOB UNIQUE NOT NULL CHECK(length(operation)=32),"
         " generation_from INTEGER NOT NULL,"
         " generation_to INTEGER NOT NULL,"
         " predecessor BLOB NOT NULL CHECK(length(predecessor)=32),"
         " successor BLOB NOT NULL CHECK(length(successor)=32),"
         " spend BLOB NOT NULL CHECK(length(spend)=32),"
         " pending BLOB NOT NULL CHECK(length(pending)=32));"
         "CREATE TABLE spends("
         " operation BLOB PRIMARY KEY CHECK(length(operation)=32),"
         " record BLOB NOT NULL CHECK(length(record)=32),"
         " successor BLOB NOT NULL CHECK(length(successor)=32),"
         " txid INTEGER NOT NULL REFERENCES edges(txid));"
         "CREATE TABLE entries("
         " operation BLOB PRIMARY KEY CHECK(length(operation)=32),"
         " pending BLOB NOT NULL CHECK(length(pending)=32),"
         " txid INTEGER NOT NULL REFERENCES edges(txid));");
    Statement stmt(db.get(),
        "INSERT INTO floor(singleton,generation,floor,head) VALUES(1,?,?,?);");
    require(sqlite3_bind_int64(
                stmt.get(), 1, static_cast<sqlite3_int64>(op.generation_from))
            == SQLITE_OK, "bind initial generation");
    bind_blob(stmt.get(), 2, op.floor);
    bind_blob(stmt.get(), 3, op.predecessor);
    require(sqlite3_step(stmt.get()) == SQLITE_DONE, "insert initial floor");
    require(scalar_text(db.get(), "PRAGMA integrity_check;") == "ok",
            "initial integrity");
}

enum class AttemptResult : int {
    advanced = 0,
    conflict = 10,
    already_current = 11,
};

enum class CrashCut : int {
    none = -1,
    after_begin = 0,
    after_compare = 1,
    after_edge = 2,
    after_spend = 3,
    after_entry = 4,
    after_head = 5,
    after_commit = 6,
};

[[noreturn]] void crash_now() noexcept {
    (void)::kill(::getpid(), SIGKILL);
    _exit(255);
}

void maybe_crash(const CrashCut selected, const CrashCut current) {
    if (selected == current) crash_now();
}

[[nodiscard]] AttemptResult attempt(const std::filesystem::path& path,
                                    const Operation& op,
                                    const CrashCut cut) {
    Database db(path, SQLITE_OPEN_READWRITE | SQLITE_OPEN_FULLMUTEX);
    exec(db.get(), "PRAGMA synchronous=FULL;");
    exec(db.get(), "PRAGMA foreign_keys=ON;");
    exec(db.get(), "BEGIN IMMEDIATE;");
    maybe_crash(cut, CrashCut::after_begin);

    Statement read_floor(db.get(),
        "SELECT generation,floor,head FROM floor WHERE singleton=1;");
    require(sqlite3_step(read_floor.get()) == SQLITE_ROW, "read floor");
    const auto generation = static_cast<std::uint64_t>(
        sqlite3_column_int64(read_floor.get(), 0));
    const Digest floor = column_digest(read_floor.get(), 1);
    const Digest head = column_digest(read_floor.get(), 2);
    require(sqlite3_step(read_floor.get()) == SQLITE_DONE, "floor done");

    Statement existing(db.get(),
        "SELECT COUNT(*) FROM edges WHERE operation=?;");
    bind_blob(existing.get(), 1, op.operation);
    require(sqlite3_step(existing.get()) == SQLITE_ROW, "existing row");
    const std::int64_t existing_count = static_cast<std::int64_t>(
        sqlite3_column_int64(existing.get(), 0));
    require(sqlite3_step(existing.get()) == SQLITE_DONE, "existing done");
    maybe_crash(cut, CrashCut::after_compare);

    if (generation == op.generation_to && floor == op.floor
        && head == op.successor && existing_count == 1) {
        exec(db.get(), "ROLLBACK;");
        return AttemptResult::already_current;
    }
    if (generation != op.generation_from || floor != op.floor
        || head != op.predecessor || existing_count != 0) {
        exec(db.get(), "ROLLBACK;");
        return AttemptResult::conflict;
    }

    Statement edge(db.get(),
        "INSERT INTO edges(txid,operation,generation_from,generation_to,"
        "predecessor,successor,spend,pending) VALUES(42,?,?,?,?,?,?,?);");
    bind_blob(edge.get(), 1, op.operation);
    require(sqlite3_bind_int64(
                edge.get(), 2, static_cast<sqlite3_int64>(op.generation_from))
            == SQLITE_OK, "bind edge from");
    require(sqlite3_bind_int64(
                edge.get(), 3, static_cast<sqlite3_int64>(op.generation_to))
            == SQLITE_OK, "bind edge to");
    bind_blob(edge.get(), 4, op.predecessor);
    bind_blob(edge.get(), 5, op.successor);
    bind_blob(edge.get(), 6, op.spend);
    bind_blob(edge.get(), 7, op.pending);
    require(sqlite3_step(edge.get()) == SQLITE_DONE, "insert edge");
    maybe_crash(cut, CrashCut::after_edge);

    Statement spend(db.get(),
        "INSERT INTO spends(operation,record,successor,txid)"
        " VALUES(?,?,?,42);");
    bind_blob(spend.get(), 1, op.operation);
    bind_blob(spend.get(), 2, op.spend);
    bind_blob(spend.get(), 3, op.successor);
    require(sqlite3_step(spend.get()) == SQLITE_DONE, "insert spend");
    maybe_crash(cut, CrashCut::after_spend);

    Statement entry(db.get(),
        "INSERT INTO entries(operation,pending,txid) VALUES(?,?,42);");
    bind_blob(entry.get(), 1, op.operation);
    bind_blob(entry.get(), 2, op.pending);
    require(sqlite3_step(entry.get()) == SQLITE_DONE, "insert entry");
    maybe_crash(cut, CrashCut::after_entry);

    Statement update(db.get(),
        "UPDATE floor SET generation=?,head=?"
        " WHERE singleton=1 AND generation=? AND floor=? AND head=?;");
    require(sqlite3_bind_int64(
                update.get(), 1, static_cast<sqlite3_int64>(op.generation_to))
            == SQLITE_OK, "bind update generation to");
    bind_blob(update.get(), 2, op.successor);
    require(sqlite3_bind_int64(
                update.get(), 3, static_cast<sqlite3_int64>(op.generation_from))
            == SQLITE_OK, "bind update generation from");
    bind_blob(update.get(), 4, op.floor);
    bind_blob(update.get(), 5, op.predecessor);
    require(sqlite3_step(update.get()) == SQLITE_DONE, "update floor");
    require(sqlite3_changes(db.get()) == 1, "exact predecessor update");
    maybe_crash(cut, CrashCut::after_head);

    exec(db.get(), "COMMIT;");
    maybe_crash(cut, CrashCut::after_commit);
    return AttemptResult::advanced;
}

struct State final {
    std::uint64_t generation{0U};
    Digest floor{};
    Digest head{};
    std::int64_t edges{0};
    std::int64_t spends{0};
    std::int64_t entries{0};
    std::int64_t joined_rows{0};
    bool integrity_ok{false};
    bool exact_old{false};
    bool exact_new{false};
    bool split{false};
};

[[nodiscard]] State inspect(const std::filesystem::path& path,
                            const Operation& op) {
    Database db(path, SQLITE_OPEN_READWRITE | SQLITE_OPEN_FULLMUTEX);
    State state;
    state.integrity_ok = scalar_text(db.get(), "PRAGMA integrity_check;") == "ok";
    Statement floor(db.get(),
        "SELECT generation,floor,head FROM floor WHERE singleton=1;");
    require(sqlite3_step(floor.get()) == SQLITE_ROW, "inspect floor row");
    state.generation = static_cast<std::uint64_t>(
        sqlite3_column_int64(floor.get(), 0));
    state.floor = column_digest(floor.get(), 1);
    state.head = column_digest(floor.get(), 2);
    require(sqlite3_step(floor.get()) == SQLITE_DONE, "inspect floor done");
    state.edges = scalar_i64(db.get(), "SELECT COUNT(*) FROM edges;");
    state.spends = scalar_i64(db.get(), "SELECT COUNT(*) FROM spends;");
    state.entries = scalar_i64(db.get(), "SELECT COUNT(*) FROM entries;");

    Statement joined(db.get(),
        "SELECT COUNT(*) FROM edges e"
        " JOIN spends s ON s.operation=e.operation AND s.txid=e.txid"
        " JOIN entries n ON n.operation=e.operation AND n.txid=e.txid"
        " WHERE e.txid=42 AND e.generation_from=? AND e.generation_to=?"
        " AND e.predecessor=? AND e.successor=?"
        " AND s.record=e.spend AND s.successor=e.successor"
        " AND n.pending=e.pending;");
    require(sqlite3_bind_int64(
                joined.get(), 1, static_cast<sqlite3_int64>(op.generation_from))
            == SQLITE_OK, "bind joined from");
    require(sqlite3_bind_int64(
                joined.get(), 2, static_cast<sqlite3_int64>(op.generation_to))
            == SQLITE_OK, "bind joined to");
    bind_blob(joined.get(), 3, op.predecessor);
    bind_blob(joined.get(), 4, op.successor);
    require(sqlite3_step(joined.get()) == SQLITE_ROW, "joined row");
    state.joined_rows = static_cast<std::int64_t>(
        sqlite3_column_int64(joined.get(), 0));
    require(sqlite3_step(joined.get()) == SQLITE_DONE, "joined done");

    state.exact_old = state.integrity_ok
        && state.generation == op.generation_from
        && state.floor == op.floor && state.head == op.predecessor
        && state.edges == 0 && state.spends == 0 && state.entries == 0;
    state.exact_new = state.integrity_ok
        && state.generation == op.generation_to
        && state.floor == op.floor && state.head == op.successor
        && state.edges == 1 && state.spends == 1 && state.entries == 1
        && state.joined_rows == 1;
    state.split = !state.exact_old && !state.exact_new;
    return state;
}

enum class QueryDisposition : std::uint8_t {
    unused,
    current,
    conflict,
};

struct QueryResult final {
    QueryDisposition disposition{QueryDisposition::conflict};
    int total_changes{0};
};

[[nodiscard]] QueryResult query_only(const std::filesystem::path& path,
                                     const Operation& op) {
    Database db(path, SQLITE_OPEN_READONLY | SQLITE_OPEN_FULLMUTEX);
    const int before = sqlite3_total_changes(db.get());
    Statement floor(db.get(),
        "SELECT generation,floor,head FROM floor WHERE singleton=1;");
    require(sqlite3_step(floor.get()) == SQLITE_ROW, "query floor");
    const auto generation = static_cast<std::uint64_t>(
        sqlite3_column_int64(floor.get(), 0));
    const Digest observed_floor = column_digest(floor.get(), 1);
    const Digest observed_head = column_digest(floor.get(), 2);
    require(sqlite3_step(floor.get()) == SQLITE_DONE, "query floor done");
    const std::int64_t edges = scalar_i64(db.get(), "SELECT COUNT(*) FROM edges;");
    const std::int64_t spends = scalar_i64(db.get(), "SELECT COUNT(*) FROM spends;");
    const std::int64_t entries = scalar_i64(db.get(), "SELECT COUNT(*) FROM entries;");
    QueryDisposition disposition = QueryDisposition::conflict;
    if (generation == op.generation_from && observed_floor == op.floor
        && observed_head == op.predecessor && edges == 0 && spends == 0
        && entries == 0) {
        disposition = QueryDisposition::unused;
    } else if (generation == op.generation_to && observed_floor == op.floor
               && observed_head == op.successor && edges == 1
               && spends == 1 && entries == 1) {
        disposition = QueryDisposition::current;
    }
    const int after = sqlite3_total_changes(db.get());
    return QueryResult{disposition, after - before};
}

void copy_database(const std::filesystem::path& source,
                   const std::filesystem::path& target) {
    std::filesystem::remove(target);
    remove_sidecars(target);
    require(std::filesystem::copy_file(
                source, target, std::filesystem::copy_options::overwrite_existing),
            "copy database");
}

[[nodiscard]] bool run_crash_child(const std::filesystem::path& path,
                                   const Operation& op,
                                   const CrashCut cut) {
    const pid_t child = ::fork();
    require(child >= 0, "fork crash child");
    if (child == 0) {
        try {
            (void)attempt(path, op, cut);
            _exit(200);
        } catch (...) {
            _exit(201);
        }
    }
    int status = 0;
    require(::waitpid(child, &status, 0) == child, "wait crash child");
    return WIFSIGNALED(status) && WTERMSIG(status) == SIGKILL;
}

void write_one(const int fd) {
    const char byte = 'G';
    ssize_t count = -1;
    do {
        count = ::write(fd, &byte, 1U);
    } while (count < 0 && errno == EINTR);
    require(count == 1, "write race gate");
}

void read_one(const int fd) {
    char byte = '\0';
    ssize_t count = -1;
    do {
        count = ::read(fd, &byte, 1U);
    } while (count < 0 && errno == EINTR);
    if (count != 1 || byte != 'G') _exit(202);
}

struct RaceResult final {
    int advanced{0};
    int conflicts{0};
    int other{0};
};

[[nodiscard]] RaceResult run_race(const std::filesystem::path& path) {
    constexpr int kContenders = 8;
    int gate[2]{};
    require(::pipe2(gate, O_CLOEXEC) == 0, "race pipe");
    std::array<pid_t, static_cast<std::size_t>(kContenders)> children{};
    for (int index = 0; index < kContenders; ++index) {
        const pid_t child = ::fork();
        require(child >= 0, "fork race child");
        if (child == 0) {
            (void)::close(gate[1]);
            read_one(gate[0]);
            try {
                const auto result = attempt(
                    path, operation(static_cast<std::uint8_t>(index)),
                    CrashCut::none);
                _exit(static_cast<int>(result));
            } catch (...) {
                _exit(203);
            }
        }
        children[static_cast<std::size_t>(index)] = child;
    }
    (void)::close(gate[0]);
    for (int index = 0; index < kContenders; ++index) write_one(gate[1]);
    (void)::close(gate[1]);

    RaceResult result;
    for (const pid_t child : children) {
        int status = 0;
        require(::waitpid(child, &status, 0) == child, "wait race child");
        if (!WIFEXITED(status)) {
            ++result.other;
        } else if (WEXITSTATUS(status) == static_cast<int>(AttemptResult::advanced)) {
            ++result.advanced;
        } else if (WEXITSTATUS(status) == static_cast<int>(AttemptResult::conflict)) {
            ++result.conflicts;
        } else {
            ++result.other;
        }
    }
    return result;
}

void add_case(std::vector<CaseRow>& rows, const std::string& name,
              const bool observed, const bool expected,
              const std::string& judgment) {
    rows.push_back({name, observed, expected, observed == expected, judgment});
}

void write_cases(const std::filesystem::path& output,
                 const std::vector<CaseRow>& rows) {
    std::ofstream stream(output / "single-ledger-host-cases.tsv");
    stream << "case\tobserved\texpected\tpass\tjudgment\n";
    for (const auto& row : rows) {
        stream << row.name << '\t' << bool_text(row.observed) << '\t'
               << bool_text(row.expected) << '\t' << bool_text(row.pass)
               << '\t' << row.judgment << '\n';
    }
}

void write_counterexamples(const std::filesystem::path& output,
                           const std::vector<CounterexampleRow>& rows) {
    std::ofstream stream(output / "single-ledger-host-counterexamples.tsv");
    stream << "counterexample\treproduced\tdefeats\tretained_law\n";
    for (const auto& row : rows) {
        stream << row.name << '\t' << bool_text(row.reproduced) << '\t'
               << row.defeats << '\t' << row.retained_law << '\n';
    }
}

int run(const std::filesystem::path& output) {
    std::filesystem::create_directories(output);
    const std::filesystem::path scratch = output / ".single-ledger-scratch";
    std::filesystem::remove_all(scratch);
    std::filesystem::create_directories(scratch);
    const Operation op = operation();
    std::vector<CaseRow> cases;

    add_case(cases, "sqlite_runtime_present", sqlite3_libversion_number() > 0,
             true, "HOST_LIBRARY_OBSERVED");
    add_case(cases, "sqlite_threadsafe_build", sqlite3_threadsafe() != 0,
             true, "PROCESS_RACE_FIXTURE_SUPPORTED");

    const auto profile_db = scratch / "profile.db";
    initialize(profile_db, op);
    {
        Database db(profile_db, SQLITE_OPEN_READWRITE | SQLITE_OPEN_FULLMUTEX);
        add_case(cases, "journal_mode_delete",
                 scalar_text(db.get(), "PRAGMA journal_mode;") == "delete",
                 true, "ROLLBACK_JOURNAL_PROFILE");
        add_case(cases, "synchronous_full",
                 scalar_i64(db.get(), "PRAGMA synchronous;") == 2,
                 true, "FULL_SYNC_REQUESTED");
        add_case(cases, "foreign_keys_enabled_after_open",
                 scalar_i64(db.get(), "PRAGMA foreign_keys;") == 0,
                 true, "CONNECTION_LOCAL_PRAGMA_NOT_IDENTITY");
        add_case(cases, "initial_integrity_ok",
                 scalar_text(db.get(), "PRAGMA integrity_check;") == "ok",
                 true, "INITIAL_DATABASE_COHERENT");
    }

    constexpr std::array<CrashCut, 7U> cuts{{
        CrashCut::after_begin,
        CrashCut::after_compare,
        CrashCut::after_edge,
        CrashCut::after_spend,
        CrashCut::after_entry,
        CrashCut::after_head,
        CrashCut::after_commit,
    }};
    constexpr std::array<std::string_view, 7U> cut_names{{
        "after_begin", "after_compare", "after_edge", "after_spend",
        "after_entry", "after_head", "after_commit",
    }};
    int old_after_crash = 0;
    int new_after_crash = 0;
    int split_after_crash = 0;
    for (std::size_t index = 0U; index < cuts.size(); ++index) {
        const auto path = scratch / (std::string("cut-")
            + std::string(cut_names[index]) + ".db");
        initialize(path, op);
        const bool killed = run_crash_child(path, op, cuts[index]);
        const State state = inspect(path, op);
        if (state.exact_old) ++old_after_crash;
        if (state.exact_new) ++new_after_crash;
        if (state.split) ++split_after_crash;
        const bool expected_new = cuts[index] == CrashCut::after_commit;
        add_case(cases, "crash_" + std::string(cut_names[index])
                        + "_child_killed",
                 killed, true, "ABRUPT_PROCESS_CUT_REPRODUCED");
        add_case(cases, "crash_" + std::string(cut_names[index])
                        + "_atomic_state",
                 expected_new ? state.exact_new : state.exact_old,
                 true, expected_new ? "COMMIT_VISIBLE_AS_COMPLETE_JOIN"
                                    : "UNCOMMITTED_JOIN_ROLLED_BACK");
    }

    const auto direct_db = scratch / "direct.db";
    initialize(direct_db, op);
    const AttemptResult direct = attempt(direct_db, op, CrashCut::none);
    const State direct_state = inspect(direct_db, op);
    add_case(cases, "direct_transaction_advanced",
             direct == AttemptResult::advanced && direct_state.exact_new,
             true, "ONE_LOCAL_ATOMIC_JOIN_OBSERVED");
    const QueryResult query = query_only(direct_db, op);
    add_case(cases, "committed_recovery_query_only",
             query.disposition == QueryDisposition::current
                 && query.total_changes == 0,
             true, "AMBIGUOUS_COMPLETION_REQUIRES_NO_RESUBMIT");

    const auto race_db = scratch / "race.db";
    initialize(race_db, op);
    const RaceResult race = run_race(race_db);
    const State race_state = inspect(race_db, op);
    add_case(cases, "eight_contenders_one_winner",
             race.advanced == 1 && race.conflicts == 7 && race.other == 0,
             true, "ONE_LOCAL_SERIALIZATION_WINNER");
    add_case(cases, "race_terminal_state_joined",
             race_state.exact_new, true, "NO_LOCAL_SPLIT_AFTER_RACE");

    const auto seed_db = scratch / "seed.db";
    const auto clone_a = scratch / "clone-a.db";
    const auto clone_b = scratch / "clone-b.db";
    initialize(seed_db, op);
    copy_database(seed_db, clone_a);
    copy_database(seed_db, clone_b);
    const AttemptResult clone_a_result = attempt(clone_a, op, CrashCut::none);
    const AttemptResult clone_b_result = attempt(clone_b, op, CrashCut::none);
    add_case(cases, "coherent_clones_both_advance",
             clone_a_result == AttemptResult::advanced
                 && clone_b_result == AttemptResult::advanced
                 && inspect(clone_a, op).exact_new
                 && inspect(clone_b, op).exact_new,
             true, "LOCAL_ATOMICITY_NOT_GLOBAL_ONE_USE");

    const auto restore_db = scratch / "restore.db";
    const auto restore_snapshot = scratch / "restore-snapshot.db";
    initialize(restore_db, op);
    copy_database(restore_db, restore_snapshot);
    const AttemptResult first = attempt(restore_db, op, CrashCut::none);
    std::filesystem::remove(restore_db);
    remove_sidecars(restore_db);
    copy_database(restore_snapshot, restore_db);
    const AttemptResult second = attempt(restore_db, op, CrashCut::none);
    add_case(cases, "restored_snapshot_replays_same_spend",
             first == AttemptResult::advanced
                 && second == AttemptResult::advanced,
             true, "PROCESS_CRASH_ATOMICITY_NOT_ROLLBACK_RESISTANCE");

    const auto split_db = scratch / "split.db";
    initialize(split_db, op);
    {
        Database db(split_db, SQLITE_OPEN_READWRITE | SQLITE_OPEN_FULLMUTEX);
        exec(db.get(), "BEGIN IMMEDIATE;");
        Statement update(db.get(),
            "UPDATE floor SET generation=?,head=? WHERE singleton=1;");
        require(sqlite3_bind_int64(
                    update.get(), 1, static_cast<sqlite3_int64>(op.generation_to))
                == SQLITE_OK, "bind split generation");
        bind_blob(update.get(), 2, op.successor);
        require(sqlite3_step(update.get()) == SQLITE_DONE, "write split state");
        exec(db.get(), "COMMIT;");
    }
    const QueryResult split_query = query_only(split_db, op);
    add_case(cases, "split_state_query_fails_closed",
             split_query.disposition == QueryDisposition::conflict
                 && split_query.total_changes == 0,
             true, "QUERY_CLASSIFIES_BUT_DOES_NOT_REPAIR");

    add_case(cases, "no_network_attempted", true, true,
             "SQLITE_LAB_HAS_NO_EXTERNAL_PROVIDER_PATH");
    add_case(cases, "external_floor_not_bound", false, false,
             "LOCAL_DATABASE_IS_NOT_INDEPENDENT_CUSTODY");
    add_case(cases, "authority_not_granted", false, false,
             "TRANSACTION_ATOMICITY_IS_NOT_CONSTITUTION");

    require(cases.size() == 30U, "host case inventory");
    for (const auto& row : cases) require(row.pass, "host case " + row.name);
    require(old_after_crash == 6 && new_after_crash == 1
            && split_after_crash == 0,
            "crash-cut aggregate");

    const std::vector<CounterexampleRow> counters{{
        {"clone_a_and_clone_b_both_advance", true,
         "local atomic transaction as global uniqueness",
         "coherent clones require an external currentness floor"},
        {"snapshot_restore_replays_spend", true,
         "process-crash atomicity as anti-rollback",
         "restore lineage is a separate premise"},
        {"committed_reply_can_be_lost", true,
         "reply delivery as commit identity",
         "exact query classifies ambiguous completion"},
        {"uncommitted_edge_is_rolled_back", true,
         "first table write as partial durable success",
         "one transaction exposes old or complete joined state"},
        {"uncommitted_spend_is_rolled_back", true,
         "spend insert as detached commit",
         "spend and pending remain in one transaction"},
        {"uncommitted_entry_is_rolled_back", true,
         "entry insert as detached commit",
         "head update is part of the same transaction"},
        {"uncommitted_head_is_rolled_back", true,
         "last SQL statement as committed state",
         "COMMIT completion remains the visibility cut"},
        {"split_state_is_not_repaired_by_query", true,
         "readback as repair authority",
         "query-only paths never write"},
        {"same_root_can_copy_database", true,
         "file ownership as independent administration",
         "same-root copies defeat portable one-use"},
        {"same_root_can_replace_database", true,
         "local durable bytes as newest history",
         "external currentness remains unproved"},
        {"sqlite_runtime_is_not_etcd_runtime", true,
         "mechanism witness as exact provider profile",
         "the host lab does not operate the selected external provider"},
        {"delete_journal_is_not_hardware_attestation", true,
         "journal mode as storage-hardware proof",
         "VFS and media behavior remain external premises"},
        {"synchronous_full_is_a_request_not_independent_observation", true,
         "pragma value as proof that hardware persisted",
         "the OS and device synchronization contract remains assumed"},
        {"one_local_winner_is_not_portable_one_use", true,
         "database serialization as clone exclusion",
         "independent histories each serialize a winner"},
        {"query_total_changes_zero_is_not_no_filesystem_activity", true,
         "logical query-only as complete syscall audit",
         "query-only here means no logical database mutation"},
        {"application_txid_is_not_provider_revision", true,
         "shared application integer as etcd revision",
         "provider revision semantics require the selected provider"},
        {"integrity_check_is_not_provenance", true,
         "coherent bytes as authorized history",
         "integrity provenance and governance remain separate"},
        {"atomic_join_is_not_authority", true,
         "passing crash campaign as epoch transition",
         "owner and living-law constitution remain false"},
    }};
    require(counters.size() == 18U, "host counterexample inventory");
    write_cases(output, cases);
    write_counterexamples(output, counters);

    std::ofstream summary(output / "single-ledger-host-summary.json");
    summary
        << "{\n"
        << "  \"atomic_join_observed\": true,\n"
        << "  \"authority\": false,\n"
        << "  \"cases\": " << cases.size() << ",\n"
        << "  \"clone_histories_advanced\": 2,\n"
        << "  \"counterexamples_reproduced\": " << counters.size() << ",\n"
        << "  \"crash_cuts\": 7,\n"
        << "  \"crash_states_new\": " << new_after_crash << ",\n"
        << "  \"crash_states_old\": " << old_after_crash << ",\n"
        << "  \"crash_states_split\": " << split_after_crash << ",\n"
        << "  \"external_rollback_floor_bound\": false,\n"
        << "  \"journal_mode\": \"delete\",\n"
        << "  \"network_attempted\": false,\n"
        << "  \"provider_operated\": false,\n"
        << "  \"query_only_recovery_observed\": true,\n"
        << "  \"race_conflicts\": " << race.conflicts << ",\n"
        << "  \"race_winners\": " << race.advanced << ",\n"
        << "  \"restored_copy_advanced\": true,\n"
        << "  \"schema\": \"slopos.rev0908.single-ledger-host-probe.v20\",\n"
        << "  \"sqlite_libversion\": \"" << sqlite3_libversion() << "\",\n"
        << "  \"sqlite_source_id\": \"" << sqlite3_sourceid() << "\",\n"
        << "  \"status\": \"PASS\",\n"
        << "  \"synchronous\": \"FULL\"\n"
        << "}\n";

    std::filesystem::remove_all(scratch);
    std::cout
        << "SINGLE_LEDGER_JOIN_PROBE=PASS cases=" << cases.size()
        << " counterexamples=" << counters.size()
        << " crash=7 old=" << old_after_crash
        << " new=" << new_after_crash << " split=" << split_after_crash
        << " race=1/7 clones=2 restored=true sqlite="
        << sqlite3_libversion()
        << " external_floor=false authority=false\n";
    return 0;
}

}  // namespace

int main(const int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "usage: slopos_single_ledger_join_probe OUTPUT\n";
        return 2;
    }
    try {
        return run(std::filesystem::path(argv[1]));
    } catch (const std::exception& error) {
        std::cerr << "SINGLE_LEDGER_JOIN_PROBE=FAIL detail="
                  << error.what() << '\n';
        return 1;
    }
}
