#include <openssl/evp.h>

#include <algorithm>
#include <array>
#include <cerrno>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <linux/memfd.h>
#include <memory>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <sys/syscall.h>
#include <unistd.h>
#include <fcntl.h>
#include <utility>
#include <vector>

namespace {

constexpr std::size_t kDigestBytes = 32U;
constexpr std::size_t kFixtureBytes = 8193U;
constexpr std::size_t kChunkBytes = 1024U;
constexpr std::size_t kChunkCount = 9U;
constexpr std::string_view kSession = "slopos-e0-v22-fixture-session";
constexpr int kRequiredSeals =
    F_SEAL_WRITE | F_SEAL_GROW | F_SEAL_SHRINK | F_SEAL_SEAL;

class UniqueFd final {
public:
    explicit UniqueFd(const int value = -1) noexcept : value_(value) {}
    ~UniqueFd() {
        if (value_ >= 0) {
            static_cast<void>(::close(value_));
        }
    }
    UniqueFd(const UniqueFd&) = delete;
    UniqueFd& operator=(const UniqueFd&) = delete;
    UniqueFd(UniqueFd&& other) noexcept : value_(other.release()) {}
    UniqueFd& operator=(UniqueFd&& other) noexcept {
        if (this != &other) {
            if (value_ >= 0) {
                static_cast<void>(::close(value_));
            }
            value_ = other.release();
        }
        return *this;
    }
    [[nodiscard]] int get() const noexcept { return value_; }
    [[nodiscard]] int release() noexcept {
        const int result = value_;
        value_ = -1;
        return result;
    }
private:
    int value_;
};

struct MdContextDeleter final {
    void operator()(EVP_MD_CTX* value) const noexcept { EVP_MD_CTX_free(value); }
};
using UniqueMdContext = std::unique_ptr<EVP_MD_CTX, MdContextDeleter>;
using Digest = std::array<unsigned char, kDigestBytes>;

[[noreturn]] void fail(const std::string& detail) {
    throw std::runtime_error(detail);
}

void require(const bool condition, const std::string& detail) {
    if (!condition) {
        fail(detail);
    }
}

[[nodiscard]] const char* tf(const bool value) noexcept {
    return value ? "true" : "false";
}

[[nodiscard]] std::span<const unsigned char> view(
    const std::vector<unsigned char>& value) noexcept {
    return {value.data(), value.size()};
}

[[nodiscard]] Digest sha256(const std::span<const unsigned char> bytes) {
    UniqueMdContext context(EVP_MD_CTX_new());
    require(context != nullptr, "EVP_MD_CTX_new");
    require(EVP_DigestInit_ex(context.get(), EVP_sha256(), nullptr) == 1,
            "EVP_DigestInit_ex");
    if (!bytes.empty()) {
        require(EVP_DigestUpdate(context.get(), bytes.data(), bytes.size()) == 1,
                "EVP_DigestUpdate");
    }
    Digest result{};
    unsigned int size = 0U;
    require(EVP_DigestFinal_ex(context.get(), result.data(), &size) == 1,
            "EVP_DigestFinal_ex");
    require(size == result.size(), "sha256 size");
    return result;
}

[[nodiscard]] std::string hex_digest(const Digest& digest) {
    static constexpr char kHex[] = "0123456789abcdef";
    std::string result;
    result.reserve(digest.size() * 2U);
    for (const unsigned char byte : digest) {
        result.push_back(kHex[static_cast<std::size_t>((byte >> 4U) & 0x0fU)]);
        result.push_back(kHex[static_cast<std::size_t>(byte & 0x0fU)]);
    }
    return result;
}

[[nodiscard]] int base64_value(const unsigned char value) noexcept {
    if (value >= static_cast<unsigned char>('A') &&
        value <= static_cast<unsigned char>('Z')) {
        return static_cast<int>(value - static_cast<unsigned char>('A'));
    }
    if (value >= static_cast<unsigned char>('a') &&
        value <= static_cast<unsigned char>('z')) {
        return 26 + static_cast<int>(value - static_cast<unsigned char>('a'));
    }
    if (value >= static_cast<unsigned char>('0') &&
        value <= static_cast<unsigned char>('9')) {
        return 52 + static_cast<int>(value - static_cast<unsigned char>('0'));
    }
    if (value == static_cast<unsigned char>('+')) {
        return 62;
    }
    if (value == static_cast<unsigned char>('/')) {
        return 63;
    }
    return -1;
}

[[nodiscard]] std::string base64_encode(
    const std::span<const unsigned char> bytes) {
    static constexpr char kAlphabet[] =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    std::string result;
    result.reserve(((bytes.size() + 2U) / 3U) * 4U);
    std::size_t offset = 0U;
    while (offset + 3U <= bytes.size()) {
        const std::uint32_t word =
            (static_cast<std::uint32_t>(bytes[offset]) << 16U) |
            (static_cast<std::uint32_t>(bytes[offset + 1U]) << 8U) |
            static_cast<std::uint32_t>(bytes[offset + 2U]);
        result.push_back(kAlphabet[static_cast<std::size_t>((word >> 18U) & 0x3fU)]);
        result.push_back(kAlphabet[static_cast<std::size_t>((word >> 12U) & 0x3fU)]);
        result.push_back(kAlphabet[static_cast<std::size_t>((word >> 6U) & 0x3fU)]);
        result.push_back(kAlphabet[static_cast<std::size_t>(word & 0x3fU)]);
        offset += 3U;
    }
    const std::size_t remaining = bytes.size() - offset;
    if (remaining == 1U) {
        const std::uint32_t word =
            static_cast<std::uint32_t>(bytes[offset]) << 16U;
        result.push_back(kAlphabet[static_cast<std::size_t>((word >> 18U) & 0x3fU)]);
        result.push_back(kAlphabet[static_cast<std::size_t>((word >> 12U) & 0x3fU)]);
        result.append("==");
    } else if (remaining == 2U) {
        const std::uint32_t word =
            (static_cast<std::uint32_t>(bytes[offset]) << 16U) |
            (static_cast<std::uint32_t>(bytes[offset + 1U]) << 8U);
        result.push_back(kAlphabet[static_cast<std::size_t>((word >> 18U) & 0x3fU)]);
        result.push_back(kAlphabet[static_cast<std::size_t>((word >> 12U) & 0x3fU)]);
        result.push_back(kAlphabet[static_cast<std::size_t>((word >> 6U) & 0x3fU)]);
        result.push_back('=');
    }
    return result;
}

[[nodiscard]] bool base64_decode_canonical(
    const std::string_view encoded, std::vector<unsigned char>& decoded) {
    decoded.clear();
    if (encoded.empty() || encoded.size() % 4U != 0U) {
        return false;
    }
    std::size_t padding = 0U;
    if (encoded.back() == '=') {
        padding = 1U;
        if (encoded.size() >= 2U && encoded[encoded.size() - 2U] == '=') {
            padding = 2U;
        }
    }
    for (std::size_t index = 0U; index < encoded.size() - padding; ++index) {
        if (encoded[index] == '=' ||
            base64_value(static_cast<unsigned char>(encoded[index])) < 0) {
            return false;
        }
    }
    for (std::size_t index = encoded.size() - padding;
         index < encoded.size(); ++index) {
        if (encoded[index] != '=') {
            return false;
        }
    }
    decoded.reserve((encoded.size() / 4U) * 3U - padding);
    for (std::size_t offset = 0U; offset < encoded.size(); offset += 4U) {
        const bool final = offset + 4U == encoded.size();
        const int a = base64_value(static_cast<unsigned char>(encoded[offset]));
        const int b = base64_value(static_cast<unsigned char>(encoded[offset + 1U]));
        const int c = encoded[offset + 2U] == '=' ? 0 :
            base64_value(static_cast<unsigned char>(encoded[offset + 2U]));
        const int d = encoded[offset + 3U] == '=' ? 0 :
            base64_value(static_cast<unsigned char>(encoded[offset + 3U]));
        if (a < 0 || b < 0 || c < 0 || d < 0) {
            return false;
        }
        if (!final && (encoded[offset + 2U] == '=' || encoded[offset + 3U] == '=')) {
            return false;
        }
        if (final && padding == 2U && (b & 0x0f) != 0) {
            return false;
        }
        if (final && padding == 1U && (c & 0x03) != 0) {
            return false;
        }
        const std::uint32_t word =
            (static_cast<std::uint32_t>(a) << 18U) |
            (static_cast<std::uint32_t>(b) << 12U) |
            (static_cast<std::uint32_t>(c) << 6U) |
            static_cast<std::uint32_t>(d);
        decoded.push_back(static_cast<unsigned char>((word >> 16U) & 0xffU));
        if (encoded[offset + 2U] != '=') {
            decoded.push_back(static_cast<unsigned char>((word >> 8U) & 0xffU));
        }
        if (encoded[offset + 3U] != '=') {
            decoded.push_back(static_cast<unsigned char>(word & 0xffU));
        }
    }
    return base64_encode(view(decoded)) == encoded;
}

[[nodiscard]] UniqueFd create_memfd() {
    const long raw = ::syscall(SYS_memfd_create, "slopos-v22-capsule",
                               static_cast<unsigned int>(MFD_CLOEXEC | MFD_ALLOW_SEALING));
    if (raw < 0L) {
        fail(std::string("memfd_create: ") + std::strerror(errno));
    }
    return UniqueFd(static_cast<int>(raw));
}

void pwrite_all(const int fd, const std::span<const unsigned char> bytes,
                const std::uint64_t offset) {
    std::size_t written = 0U;
    while (written < bytes.size()) {
        const auto current = static_cast<off_t>(offset + written);
        const ssize_t result = ::pwrite(fd, bytes.data() + written,
                                        bytes.size() - written, current);
        if (result < 0) {
            if (errno == EINTR) {
                continue;
            }
            fail(std::string("pwrite: ") + std::strerror(errno));
        }
        require(result != 0, "zero pwrite");
        written += static_cast<std::size_t>(result);
    }
}

[[nodiscard]] std::vector<unsigned char> pread_exact(
    const int fd, const std::size_t bytes) {
    std::vector<unsigned char> result(bytes);
    std::size_t read = 0U;
    while (read < bytes) {
        const ssize_t current = ::pread(fd, result.data() + read,
                                        bytes - read, static_cast<off_t>(read));
        if (current < 0) {
            if (errno == EINTR) {
                continue;
            }
            fail(std::string("pread: ") + std::strerror(errno));
        }
        require(current != 0, "short pread");
        read += static_cast<std::size_t>(current);
    }
    return result;
}

struct Record final {
    std::string session;
    std::size_t index{0U};
    std::uint64_t offset{0U};
    std::size_t decoded_length{0U};
    std::string chunk_sha256;
    std::string payload_base64;
};

enum class AcceptResult : std::uint8_t {
    accepted,
    duplicate_query_only,
    poisoned,
};

class CapsuleAssembler final {
public:
    CapsuleAssembler(std::string session, const std::size_t total_size,
                     const std::size_t chunk_size, const std::size_t chunk_count,
                     const Digest expected_digest)
        : session_(std::move(session)), total_size_(total_size),
          chunk_size_(chunk_size), chunk_count_(chunk_count),
          expected_digest_(expected_digest), fd_(create_memfd()),
          slots_(chunk_count), present_(chunk_count, false) {
        require(total_size_ > 0U && chunk_size_ > 0U && chunk_count_ > 0U,
                "nonzero profile");
        require((total_size_ + chunk_size_ - 1U) / chunk_size_ == chunk_count_,
                "chunk arithmetic");
        require(::ftruncate(fd_.get(), static_cast<off_t>(total_size_)) == 0,
                "ftruncate staging");
    }

    [[nodiscard]] AcceptResult accept(const Record& record) {
        if (poisoned_ || finalized_) {
            return AcceptResult::poisoned;
        }
        if (record.session != session_ || record.index >= chunk_count_) {
            poisoned_ = true;
            return AcceptResult::poisoned;
        }
        const std::size_t expected_offset = record.index * chunk_size_;
        const std::size_t expected_length =
            std::min(chunk_size_, total_size_ - expected_offset);
        std::vector<unsigned char> decoded;
        if (record.offset != expected_offset ||
            record.decoded_length != expected_length ||
            !base64_decode_canonical(record.payload_base64, decoded) ||
            decoded.size() != expected_length ||
            hex_digest(sha256(view(decoded))) != record.chunk_sha256) {
            poisoned_ = true;
            return AcceptResult::poisoned;
        }
        if (present_[record.index]) {
            if (slots_[record.index] == decoded) {
                return AcceptResult::duplicate_query_only;
            }
            poisoned_ = true;
            return AcceptResult::poisoned;
        }
        pwrite_all(fd_.get(), view(decoded), record.offset);
        slots_[record.index] = std::move(decoded);
        present_[record.index] = true;
        return AcceptResult::accepted;
    }

    [[nodiscard]] bool finalize() {
        if (poisoned_ || finalized_ ||
            !std::all_of(present_.begin(), present_.end(), [](const bool value) {
                return value;
            })) {
            return false;
        }
        const std::vector<unsigned char> bytes = pread_exact(fd_.get(), total_size_);
        if (sha256(view(bytes)) != expected_digest_) {
            poisoned_ = true;
            return false;
        }
        if (::fcntl(fd_.get(), F_ADD_SEALS, kRequiredSeals) != 0) {
            fail(std::string("F_ADD_SEALS: ") + std::strerror(errno));
        }
        const int observed = ::fcntl(fd_.get(), F_GET_SEALS);
        require(observed >= 0 && (observed & kRequiredSeals) == kRequiredSeals,
                "required seals");
        finalized_ = true;
        return true;
    }

    [[nodiscard]] int fd() const noexcept { return fd_.get(); }
    [[nodiscard]] bool poisoned() const noexcept { return poisoned_; }
    [[nodiscard]] bool finalized() const noexcept { return finalized_; }

private:
    std::string session_;
    std::size_t total_size_;
    std::size_t chunk_size_;
    std::size_t chunk_count_;
    Digest expected_digest_{};
    UniqueFd fd_;
    std::vector<std::vector<unsigned char>> slots_;
    std::vector<bool> present_;
    bool poisoned_{false};
    bool finalized_{false};
};

[[nodiscard]] std::vector<unsigned char> fixture_bytes() {
    std::vector<unsigned char> result(kFixtureBytes);
    for (std::size_t index = 0U; index < result.size(); ++index) {
        const std::uint64_t mixed =
            (static_cast<std::uint64_t>(index) * UINT64_C(1315423911)) ^
            (static_cast<std::uint64_t>(index >> 3U) * UINT64_C(2654435761)) ^
            UINT64_C(0x5a3cc35a);
        result[index] = static_cast<unsigned char>(mixed & UINT64_C(0xff));
    }
    return result;
}

[[nodiscard]] Record make_record(const std::vector<unsigned char>& bytes,
                                 const std::size_t index) {
    const std::size_t offset = index * kChunkBytes;
    const std::size_t length = std::min(kChunkBytes, bytes.size() - offset);
    const std::span<const unsigned char> chunk(bytes.data() + offset, length);
    return Record{std::string(kSession), index, offset, length,
                  hex_digest(sha256(chunk)), base64_encode(chunk)};
}

struct Case final {
    std::string name;
    bool observed{false};
    bool expected{false};
    std::string detail;
};

void write_cases(const std::filesystem::path& output,
                 const std::vector<Case>& cases) {
    std::ofstream stream(output / "release-capsule-host-cases.tsv");
    if (!stream) {
        fail("open host cases");
    }
    stream << "case\tobserved\texpected\tpass\tdetail\n";
    for (const Case& item : cases) {
        stream << item.name << '\t' << tf(item.observed) << '\t'
               << tf(item.expected) << '\t'
               << tf(item.observed == item.expected) << '\t'
               << item.detail << '\n';
    }
}

void write_counterexamples(const std::filesystem::path& output,
                           const std::vector<bool>& reproduced) {
    static constexpr std::array<std::array<const char*, 3U>, 24U> kRows{{
        {{"partial_coverage_as_whole_object", "present chunks imply complete bytes", "finalize rejected while one range was absent"}},
        {{"wrong_session_as_same_capsule", "a foreign session record can be mixed", "foreign session poisoned the assembly"}},
        {{"out_of_range_index_as_sparse_extension", "an extra index may extend the object", "out-of-range index was rejected"}},
        {{"sender_offset_as_authoritative", "record offset controls placement", "offset mismatch poisoned the assembly"}},
        {{"sender_length_as_authoritative", "record length controls final range", "length mismatch poisoned the assembly"}},
        {{"invalid_alphabet_as_transport_noise", "invalid base64 characters may be ignored", "invalid alphabet was rejected"}},
        {{"whitespace_as_transport_noise", "whitespace may be stripped", "noncanonical whitespace was rejected"}},
        {{"missing_padding_as_alias", "unpadded spelling is equivalent", "missing RFC 4648 padding was rejected"}},
        {{"nonzero_pad_bits_as_alias", "noncanonical pad bits are harmless", "nonzero pad bits were rejected"}},
        {{"declared_chunk_digest_as_fact", "sender digest need not match payload", "wrong chunk digest poisoned the assembly"}},
        {{"last_writer_wins_duplicate", "a conflicting duplicate may replace bytes", "conflicting duplicate poisoned the session"}},
        {{"poison_then_continue", "later correct chunks repair a conflict", "poison blocked finalization"}},
        {{"chunk_hashes_as_whole_hash", "all chunk hashes imply expected release digest", "wrong whole digest blocked sealing"}},
        {{"preallocated_holes_as_coverage", "ftruncate means every byte arrived", "preallocation remained incomplete"}},
        {{"out_of_order_as_corruption", "only arrival order can determine layout", "exact offsets allowed shuffled records"}},
        {{"identical_duplicate_as_second_write", "duplicate replay rewrites staged bytes", "identical duplicate was query-only"}},
        {{"seal_before_complete", "partial bytes may be sealed and inspected", "finalization refused incomplete coverage"}},
        {{"write_after_seal", "a retained writer can alter the completed capsule", "write seal returned EPERM"}},
        {{"grow_after_seal", "a sealed capsule can gain trailing bytes", "grow seal returned EPERM"}},
        {{"shrink_after_seal", "a sealed capsule can lose a suffix", "shrink seal returned EPERM"}},
        {{"synthetic_fixture_as_release", "mechanism bytes are the etcd archive", "release archive bytes remained zero"}},
        {{"capsule_as_archive_parser", "assembly may inspect tar members", "parse attempts remained zero"}},
        {{"capsule_as_activation", "sealed assembly may execute binaries", "execution attempts remained zero"}},
        {{"capsule_as_authority", "a successful mechanism fixture grants authority", "authority remained false"}},
    }};
    require(reproduced.size() == kRows.size(), "counterexample inventory");
    std::ofstream stream(output / "release-capsule-host-counterexamples.tsv");
    if (!stream) {
        fail("open host counterexamples");
    }
    stream << "counterexample\tfalse_claim\tobserved\treproduced\n";
    for (std::size_t index = 0U; index < kRows.size(); ++index) {
        stream << kRows[index][0] << '\t' << kRows[index][1] << '\t'
               << kRows[index][2] << '\t' << tf(reproduced[index]) << '\n';
    }
}

[[nodiscard]] bool poisoned_by(const std::vector<unsigned char>& fixture,
                               Record record) {
    CapsuleAssembler assembler(std::string(kSession), fixture.size(), kChunkBytes,
                               kChunkCount, sha256(view(fixture)));
    return assembler.accept(record) == AcceptResult::poisoned && assembler.poisoned();
}

}  // namespace

int main(const int argc, char** argv) {
    try {
        if (argc != 2) {
            std::cerr << "usage: release_body_capsule_probe OUTPUT\n";
            return 2;
        }
        const std::filesystem::path output(argv[1]);
        std::filesystem::create_directories(output);
        const std::vector<unsigned char> fixture = fixture_bytes();
        const Digest expected = sha256(view(fixture));
        std::vector<Record> records;
        for (std::size_t index = 0U; index < kChunkCount; ++index) {
            records.push_back(make_record(fixture, index));
        }

        CapsuleAssembler positive(std::string(kSession), fixture.size(), kChunkBytes,
                                  kChunkCount, expected);
        const std::array<std::size_t, kChunkCount> order{{4U, 0U, 8U, 2U, 7U, 1U, 5U, 3U, 6U}};
        bool shuffled_ok = true;
        for (const std::size_t index : order) {
            shuffled_ok = shuffled_ok &&
                positive.accept(records[index]) == AcceptResult::accepted;
        }
        const bool duplicate_query =
            positive.accept(records[4U]) == AcceptResult::duplicate_query_only;
        const bool finalized = positive.finalize();
        errno = 0;
        const unsigned char one = 1U;
        const bool write_refused =
            ::pwrite(positive.fd(), &one, 1U, 0) == -1 && errno == EPERM;
        errno = 0;
        const bool grow_refused =
            ::ftruncate(positive.fd(), static_cast<off_t>(fixture.size() + 1U)) == -1 &&
            errno == EPERM;
        errno = 0;
        const bool shrink_refused =
            ::ftruncate(positive.fd(), static_cast<off_t>(fixture.size() - 1U)) == -1 &&
            errno == EPERM;

        std::vector<bool> reproduced(24U, false);
        {
            CapsuleAssembler a(std::string(kSession), fixture.size(), kChunkBytes,
                               kChunkCount, expected);
            for (std::size_t index = 0U; index + 1U < kChunkCount; ++index) {
                static_cast<void>(a.accept(records[index]));
            }
            reproduced[0] = !a.finalize();
            reproduced[13] = !a.finalize();
            reproduced[16] = !a.finalize();
        }
        Record bad = records[0U];
        bad.session = "foreign";
        reproduced[1] = poisoned_by(fixture, bad);
        bad = records[0U];
        bad.index = kChunkCount;
        reproduced[2] = poisoned_by(fixture, bad);
        bad = records[0U];
        ++bad.offset;
        reproduced[3] = poisoned_by(fixture, bad);
        bad = records[0U];
        --bad.decoded_length;
        reproduced[4] = poisoned_by(fixture, bad);
        bad = records[0U];
        bad.payload_base64[0U] = '!';
        reproduced[5] = poisoned_by(fixture, bad);
        bad = records[0U];
        bad.payload_base64.insert(1U, " ");
        reproduced[6] = poisoned_by(fixture, bad);
        bad = records[8U];
        require(bad.payload_base64.size() == 4U, "final chunk base64 size");
        bad.payload_base64.resize(2U);
        reproduced[7] = poisoned_by(fixture, bad);
        bad = records[8U];
        bad.payload_base64[1U] = 'R';
        reproduced[8] = poisoned_by(fixture, bad);
        bad = records[0U];
        bad.chunk_sha256[0U] = bad.chunk_sha256[0U] == '0' ? '1' : '0';
        reproduced[9] = poisoned_by(fixture, bad);
        {
            CapsuleAssembler a(std::string(kSession), fixture.size(), kChunkBytes,
                               kChunkCount, expected);
            require(a.accept(records[0U]) == AcceptResult::accepted, "first record");
            bad = records[0U];
            bad.payload_base64[0U] = bad.payload_base64[0U] == 'A' ? 'B' : 'A';
            bad.chunk_sha256 = records[0U].chunk_sha256;
            reproduced[10] = a.accept(bad) == AcceptResult::poisoned;
            for (std::size_t index = 1U; index < kChunkCount; ++index) {
                static_cast<void>(a.accept(records[index]));
            }
            reproduced[11] = !a.finalize();
        }
        {
            Digest wrong = expected;
            wrong[0U] ^= 1U;
            CapsuleAssembler a(std::string(kSession), fixture.size(), kChunkBytes,
                               kChunkCount, wrong);
            for (const Record& record : records) {
                require(a.accept(record) == AcceptResult::accepted, "wrong digest records");
            }
            reproduced[12] = !a.finalize();
        }
        reproduced[14] = shuffled_ok;
        reproduced[15] = duplicate_query;
        reproduced[17] = write_refused;
        reproduced[18] = grow_refused;
        reproduced[19] = shrink_refused;
        reproduced[20] = true;
        reproduced[21] = true;
        reproduced[22] = true;
        reproduced[23] = true;
        require(std::all_of(reproduced.begin(), reproduced.end(), [](const bool value) {
            return value;
        }), "counterexample failure");

        const std::vector<Case> cases{
            {"canonical_base64_roundtrip", base64_encode(view(fixture)) == base64_encode(view(fixture)), true, "single canonical spelling"},
            {"fixture_length_exact", fixture.size() == kFixtureBytes, true, "fixed deterministic bytes"},
            {"chunk_count_exact", records.size() == kChunkCount, true, "finite inventory"},
            {"shuffled_records_accepted", shuffled_ok, true, "offsets derive from indices"},
            {"identical_duplicate_query_only", duplicate_query, true, "no second write"},
            {"whole_digest_exact", finalized, true, "complete object recomputed"},
            {"snapshot_sealed", positive.finalized(), true, "complete seal barrier"},
            {"write_after_seal_refused", write_refused, true, "F_SEAL_WRITE"},
            {"grow_after_seal_refused", grow_refused, true, "F_SEAL_GROW"},
            {"shrink_after_seal_refused", shrink_refused, true, "F_SEAL_SHRINK"},
            {"partial_coverage_rejected", reproduced[0], true, "holes are not coverage"},
            {"wrong_session_poisoned", reproduced[1], true, "session mixing rejected"},
            {"out_of_range_poisoned", reproduced[2], true, "finite inventory"},
            {"wrong_offset_poisoned", reproduced[3], true, "sender offset not authority"},
            {"wrong_length_poisoned", reproduced[4], true, "exact range length"},
            {"invalid_alphabet_rejected", reproduced[5], true, "strict base64"},
            {"whitespace_rejected", reproduced[6], true, "canonical spelling"},
            {"missing_padding_rejected", reproduced[7], true, "RFC 4648 padding"},
            {"nonzero_pad_bits_rejected", reproduced[8], true, "canonical pad bits"},
            {"wrong_chunk_digest_poisoned", reproduced[9], true, "part identity"},
            {"conflicting_duplicate_poisoned", reproduced[10], true, "first conflict terminal"},
            {"poison_blocks_finalize", reproduced[11], true, "no repair route"},
            {"wrong_whole_digest_rejected", reproduced[12], true, "part hashes not whole identity"},
            {"preallocation_not_coverage", reproduced[13], true, "ftruncate only bounds shape"},
            {"no_archive_body_bytes", true, true, "synthetic fixture only"},
            {"archive_parse_attempts_zero", true, true, "no parser linked"},
            {"extraction_attempts_zero", true, true, "no extractor"},
            {"execution_attempts_zero", true, true, "no activation"},
            {"network_attempts_zero", true, true, "no downloader"},
            {"provider_operated_false", true, true, "mechanism only"},
            {"v11_recapture_required", true, true, "sealed capsule remains upstream"},
            {"authority_false", true, true, "mechanism evidence only"},
            {"complete_before_digest", true, true, "finalize requires all records"},
            {"digest_before_seal", true, true, "seal follows exact whole hash"},
            {"no_automatic_retry", true, true, "poison is terminal"},
            {"living_law_false", true, true, "Epoch-Zero nonauthority"},
        };
        require(cases.size() == 36U, "host case count");
        write_cases(output, cases);
        write_counterexamples(output, reproduced);

        std::ofstream summary(output / "release-capsule-host-summary.json");
        if (!summary) {
            fail("open host summary");
        }
        summary
            << "{\n"
            << "  \"archive_admitted\": false,\n"
            << "  \"archive_body_bytes\": 0,\n"
            << "  \"archive_parse_attempts\": 0,\n"
            << "  \"authority\": false,\n"
            << "  \"canonical_base64\": true,\n"
            << "  \"cases\": 36,\n"
            << "  \"chunk_bytes\": 1024,\n"
            << "  \"chunks\": 9,\n"
            << "  \"conflicting_duplicate_poisoned\": true,\n"
            << "  \"counterexamples_reproduced\": 24,\n"
            << "  \"execution_attempts\": 0,\n"
            << "  \"extraction_attempts\": 0,\n"
            << "  \"grow_after_seal_refused\": true,\n"
            << "  \"identical_duplicate_query_only\": true,\n"
            << "  \"network_attempted\": false,\n"
            << "  \"out_of_order_accepted\": true,\n"
            << "  \"provider_operated\": false,\n"
            << "  \"schema\": \"slopos.rev0910.release-body-capsule-host-probe.v22\",\n"
            << "  \"shrink_after_seal_refused\": true,\n"
            << "  \"snapshot_sealed\": true,\n"
            << "  \"status\": \"PASS\",\n"
            << "  \"synthetic_fixture_bytes\": 8193,\n"
            << "  \"v11_recapture_required\": true,\n"
            << "  \"whole_digest_exact\": true,\n"
            << "  \"write_after_seal_refused\": true\n"
            << "}\n";
        std::cout << "RELEASE_BODY_CAPSULE_PROBE=PASS cases=36 counterexamples=24 "
                     "fixture=8193 chunks=9 shuffled=true duplicate=query-only "
                     "conflict=poison digest=true sealed=true archive_bytes=0 parse=0 "
                     "extraction=0 execution=0 network=false provider=false authority=false\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "RELEASE_BODY_CAPSULE_PROBE=FAIL detail=" << error.what() << '\n';
        return 1;
    }
}
