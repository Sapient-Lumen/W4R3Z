#pragma once

#include <cstddef>
#include <filesystem>

namespace slopos::e0::handoff_cell::harness {

struct StaticActorCampaignCounts final {
    std::size_t cases{0U};
    std::size_t counterexamples{0U};
    std::size_t static_profile_exact{0U};
    std::size_t pre_exec_filesystem_floor_bound{0U};
    std::size_t pre_exec_floor_bound{0U};
    std::size_t pre_exec_seccomp_installation_observation_bound{0U};
    std::size_t held_user_mapping_set_bound{0U};
    std::size_t post_exec_floor_bound{0U};
    std::size_t hosted_envelope_bound{0U};
    std::size_t independent_appraisal_bound{0U};
    std::size_t v15_evidence_eligible{0U};
    std::size_t v13_eligible{0U};
    std::size_t incoherent_observations{0U};
};

[[nodiscard]] StaticActorCampaignCounts run_static_actor_confinement_campaign(
    const std::filesystem::path& output);

}  // namespace slopos::e0::handoff_cell::harness
