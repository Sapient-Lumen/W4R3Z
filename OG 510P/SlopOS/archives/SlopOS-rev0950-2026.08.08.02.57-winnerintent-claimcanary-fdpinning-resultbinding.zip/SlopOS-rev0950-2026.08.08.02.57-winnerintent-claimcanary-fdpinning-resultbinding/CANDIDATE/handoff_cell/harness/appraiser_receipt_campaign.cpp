#include "appraiser_receipt_campaign.hpp"

#include "slopos/e0/handoff_cell/appraiser_receipt.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <stdexcept>
#include <string>
#include <vector>

#include <openssl/evp.h>

namespace slopos::e0::handoff_cell::harness {
namespace {

using Field = bool AppraiserReceiptObservationV1::*;
constexpr std::array<Field, 39U> kFields = {
    &AppraiserReceiptObservationV1::profile_supplied,
    &AppraiserReceiptObservationV1::v16_hosted_actor_epoch_supplied,
    &AppraiserReceiptObservationV1::appraiser_constitution_supplied,
    &AppraiserReceiptObservationV1::receipt_exact_length,
    &AppraiserReceiptObservationV1::receipt_decoded,
    &AppraiserReceiptObservationV1::receipt_canonical,
    &AppraiserReceiptObservationV1::receipt_domain_exact,
    &AppraiserReceiptObservationV1::receipt_schema_exact,
    &AppraiserReceiptObservationV1::receipt_reserved_zero,
    &AppraiserReceiptObservationV1::receipt_claim_flags_known,
    &AppraiserReceiptObservationV1::report_ordinal_nonzero,
    &AppraiserReceiptObservationV1::challenge_fresh,
    &AppraiserReceiptObservationV1::challenge_binding_exact,
    &AppraiserReceiptObservationV1::constitution_binding_exact,
    &AppraiserReceiptObservationV1::actor_epoch_binding_exact,
    &AppraiserReceiptObservationV1::v15_exec_input_binding_exact,
    &AppraiserReceiptObservationV1::v16_static_envelope_binding_exact,
    &AppraiserReceiptObservationV1::installed_policy_binding_exact,
    &AppraiserReceiptObservationV1::kernel_surface_binding_exact,
    &AppraiserReceiptObservationV1::process_coordinate_binding_exact,
    &AppraiserReceiptObservationV1::v14_dossier_binding_exact,
    &AppraiserReceiptObservationV1::hold_token_binding_exact,
    &AppraiserReceiptObservationV1::observation_order_exact,
    &AppraiserReceiptObservationV1::signature_suite_ed25519,
    &AppraiserReceiptObservationV1::public_key_pinned,
    &AppraiserReceiptObservationV1::signature_exact_length,
    &AppraiserReceiptObservationV1::signature_verifies,
    &AppraiserReceiptObservationV1::exactly_one_report_consumed,
    &AppraiserReceiptObservationV1::appraiser_process_separate,
    &AppraiserReceiptObservationV1::appraiser_administration_root_distinct,
    &AppraiserReceiptObservationV1::appraiser_key_custody_independent,
    &AppraiserReceiptObservationV1::appraiser_input_custody_independent,
    &AppraiserReceiptObservationV1::process_coordinate_lifetime_bound,
    &AppraiserReceiptObservationV1::installed_policy_independently_reconstructed,
    &AppraiserReceiptObservationV1::kernel_surfaces_independently_reconstructed,
    &AppraiserReceiptObservationV1::v14_dossier_independently_reopened,
    &AppraiserReceiptObservationV1::no_same_root_mutation_path,
    &AppraiserReceiptObservationV1::actor_epoch_held_through_v13_admission,
    &AppraiserReceiptObservationV1::portable_replay_excluded,
};

constexpr std::array<std::uint8_t, 32U> kTestPrivateSeed = {
    0x9dU, 0x61U, 0xb1U, 0x9dU, 0xefU, 0xfdU, 0x5aU, 0x60U,
    0xbaU, 0x84U, 0x4aU, 0xf4U, 0x92U, 0xecU, 0x2cU, 0xc4U,
    0x44U, 0x49U, 0xc5U, 0x69U, 0x7bU, 0x32U, 0x69U, 0x19U,
    0x70U, 0x3bU, 0xacU, 0x03U, 0x1cU, 0xaeU, 0x7fU, 0x60U,
};
constexpr AppraiserPublicKey kTestPublicKey = {
    0xd7U, 0x5aU, 0x98U, 0x01U, 0x82U, 0xb1U, 0x0aU, 0xb7U,
    0xd5U, 0x4bU, 0xfeU, 0xd3U, 0xc9U, 0x64U, 0x07U, 0x3aU,
    0x0eU, 0xe1U, 0x72U, 0xf3U, 0xdaU, 0xa6U, 0x23U, 0x25U,
    0xafU, 0x02U, 0x1aU, 0x68U, 0xf7U, 0x07U, 0x51U, 0x1aU,
};

struct CaseRow final {
    std::string name;
    std::size_t true_prefix{0U};
    std::string disposition;
    AppraiserReceiptAssessment assessment{};
    std::string judgment;
};

struct CounterexampleRow final {
    const char* name;
    const char* defeats;
    const char* retained_law;
};

[[noreturn]] void fail(const std::string& detail) {
    throw std::runtime_error(detail);
}

void require(const bool condition, const std::string& detail) {
    if (!condition) fail(detail);
}

[[nodiscard]] const char* boolean(const bool value) noexcept {
    return value ? "true" : "false";
}

[[nodiscard]] AppraiserBinding binding(const std::uint8_t base) noexcept {
    AppraiserBinding value{};
    for (std::size_t index = 0U; index < value.size(); ++index) {
        value[index] = static_cast<std::uint8_t>(
            static_cast<unsigned int>(base)
            + static_cast<unsigned int>(index));
    }
    return value;
}

[[nodiscard]] AppraiserReceiptObservationV1 prefix_observation(
    const std::size_t count) noexcept {
    AppraiserReceiptObservationV1 observation;
    const std::size_t bounded = count < kFields.size() ? count : kFields.size();
    for (std::size_t index = 0U; index < bounded; ++index) {
        observation.*kFields[index] = true;
    }
    return observation;
}

[[nodiscard]] AppraiserReceiptSignature sign_message(
    const AppraiserReceiptBytes& message) {
    AppraiserReceiptSignature signature{};
    EVP_PKEY* key = EVP_PKEY_new_raw_private_key(
        EVP_PKEY_ED25519, nullptr, kTestPrivateSeed.data(),
        kTestPrivateSeed.size());
    require(key != nullptr, "create Ed25519 test key");
    AppraiserPublicKey derived{};
    std::size_t derived_size = derived.size();
    require(EVP_PKEY_get_raw_public_key(
                key, derived.data(), &derived_size) == 1
            && derived_size == derived.size() && derived == kTestPublicKey,
            "derive pinned public test key");
    EVP_MD_CTX* context = EVP_MD_CTX_new();
    require(context != nullptr, "create signing context");
    const bool initialized = EVP_DigestSignInit(
        context, nullptr, nullptr, nullptr, key) == 1;
    std::size_t signature_size = signature.size();
    const bool signed_ok = initialized && EVP_DigestSign(
        context, signature.data(), &signature_size, message.data(),
        message.size()) == 1;
    EVP_MD_CTX_free(context);
    EVP_PKEY_free(key);
    require(signed_ok && signature_size == signature.size(),
            "sign canonical appraiser receipt");
    return signature;
}

void write_cases(const std::filesystem::path& output,
                 const std::vector<CaseRow>& rows) {
    std::ofstream stream(output / "appraiser-receipt-cases.tsv",
                         std::ios::binary);
    require(stream.good(), "open appraiser receipt cases");
    stream << "case\ttrue_prefix\tdisposition\tcoherent\tcanonical_receipt"
              "\tsigned_statement\tone_report\tindependent_constitution"
              "\tprocess_coordinate\tinstalled_policy\tkernel_surfaces"
              "\tv14_dossier\tindependent_appraisal\tv13_eligible"
              "\tauthority\tjudgment\n";
    for (const CaseRow& row : rows) {
        const auto& a = row.assessment;
        stream << row.name << '\t' << row.true_prefix << '\t'
               << row.disposition << '\t' << boolean(a.observation_coherent)
               << '\t' << boolean(a.canonical_receipt_bound)
               << '\t' << boolean(a.signed_appraiser_statement_bound)
               << '\t' << boolean(a.one_report_consumption_bound)
               << '\t' << boolean(a.independent_appraiser_constitution_bound)
               << '\t' << boolean(a.process_lifetime_coordinate_bound)
               << '\t' << boolean(a.installed_policy_bound)
               << '\t' << boolean(a.kernel_surfaces_bound)
               << '\t' << boolean(a.v14_dossier_bound)
               << '\t' << boolean(a.independently_appraised_actor_premise_bound)
               << '\t' << boolean(a.eligible_for_v13_actor_premise)
               << '\t' << boolean(a.owner_authority)
               << '\t' << row.judgment << '\n';
    }
}

void write_counterexamples(const std::filesystem::path& output,
                           const std::vector<CounterexampleRow>& rows) {
    std::ofstream stream(output / "appraiser-receipt-counterexamples.tsv",
                         std::ios::binary);
    require(stream.good(), "open appraiser receipt counterexamples");
    stream << "counterexample\treproduced\tdefeats\tretained_law\n";
    for (const CounterexampleRow& row : rows) {
        stream << row.name << "\ttrue\t" << row.defeats << '\t'
               << row.retained_law << '\n';
    }
}

}  // namespace

AppraiserReceiptCampaignCounts run_appraiser_receipt_campaign(
    const std::filesystem::path& output) {
    AppraiserReceiptRecordV1 record;
    record.claim_flags = kAppraiserReceiptKnownClaimMask;
    record.report_ordinal = 17U;
    record.challenge = binding(0x10U);
    record.appraiser_constitution = binding(0x20U);
    record.actor_epoch = binding(0x30U);
    record.v15_exec_input = binding(0x40U);
    record.v16_static_envelope = binding(0x50U);
    record.installed_policy = binding(0x60U);
    record.kernel_surfaces = binding(0x70U);
    record.process_coordinate = binding(0x80U);
    record.v14_dossier = binding(0x90U);
    record.hold_token = binding(0xA0U);

    AppraiserReceiptBytes encoded{};
    require(encode_appraiser_receipt(record, encoded), "encode receipt");
    AppraiserReceiptRecordV1 decoded;
    require(decode_appraiser_receipt(encoded, decoded), "decode receipt");
    AppraiserReceiptBytes reencoded{};
    require(encode_appraiser_receipt(decoded, reencoded)
            && reencoded == encoded, "canonical round trip");
    const AppraiserReceiptSignature signature = sign_message(encoded);
    require(verify_appraiser_receipt_ed25519(
                kTestPublicKey, encoded, signature),
            "verify exact receipt signature");

    std::size_t message_mutations = 0U;
    for (std::size_t byte = 0U; byte < encoded.size(); ++byte) {
        for (unsigned int bit = 0U; bit < 8U; ++bit) {
            AppraiserReceiptBytes changed = encoded;
            changed[byte] ^= static_cast<std::uint8_t>(1U << bit);
            require(!verify_appraiser_receipt_ed25519(
                        kTestPublicKey, changed, signature),
                    "message bit mutation accepted");
            ++message_mutations;
        }
    }
    std::size_t signature_mutations = 0U;
    for (std::size_t byte = 0U; byte < signature.size(); ++byte) {
        for (unsigned int bit = 0U; bit < 8U; ++bit) {
            AppraiserReceiptSignature changed = signature;
            changed[byte] ^= static_cast<std::uint8_t>(1U << bit);
            require(!verify_appraiser_receipt_ed25519(
                        kTestPublicKey, encoded, changed),
                    "signature bit mutation accepted");
            ++signature_mutations;
        }
    }
    std::size_t key_mutations = 0U;
    for (std::size_t byte = 0U; byte < kTestPublicKey.size(); ++byte) {
        for (unsigned int bit = 0U; bit < 8U; ++bit) {
            AppraiserPublicKey changed = kTestPublicKey;
            changed[byte] ^= static_cast<std::uint8_t>(1U << bit);
            require(!verify_appraiser_receipt_ed25519(
                        changed, encoded, signature),
                    "public-key bit mutation accepted");
            ++key_mutations;
        }
    }

    AppraiserReceiptBytes malformed = encoded;
    malformed[0U] ^= 1U;
    require(!decode_appraiser_receipt(malformed, decoded),
            "domain mutation decoded");
    malformed = encoded;
    malformed[32U] ^= 1U;
    require(!decode_appraiser_receipt(malformed, decoded),
            "schema mutation decoded");
    malformed = encoded;
    malformed[39U] |= 0x80U;
    require(!decode_appraiser_receipt(malformed, decoded),
            "unknown claim flag decoded");
    malformed = encoded;
    for (std::size_t index = 40U; index < 48U; ++index) malformed[index] = 0U;
    require(!decode_appraiser_receipt(malformed, decoded),
            "zero ordinal decoded");
    malformed = encoded;
    malformed[383U] = 1U;
    require(!decode_appraiser_receipt(malformed, decoded),
            "reserved mutation decoded");

    std::vector<CaseRow> cases;
    cases.reserve(kFields.size() + 3U);
    AppraiserReceiptCampaignCounts counts;
    for (std::size_t cut = 0U; cut <= kFields.size(); ++cut) {
        const AppraiserReceiptObservationV1 observation = prefix_observation(cut);
        const AppraiserReceiptAssessment assessment =
            assess_appraiser_receipt(observation);
        require(assessment.observation_coherent, "prefix observation incoherent");
        const std::string disposition =
            appraiser_receipt_disposition_name(assessment.disposition);
        cases.push_back({
            "ordered_prefix_" + std::to_string(cut),
            cut,
            disposition,
            assessment,
            cut == kFields.size()
                ? "SYNTHETIC_FULL_PREMISE_REACHES_V13_WITHOUT_AUTHORITY"
                : "FIRST_FALSE_PREMISE_STOPS_MONOTONICALLY",
        });
        counts.canonical_receipt_profiles +=
            assessment.canonical_receipt_bound ? 1U : 0U;
        counts.signed_statement_profiles +=
            assessment.signed_appraiser_statement_bound ? 1U : 0U;
        counts.independent_appraisal_profiles +=
            assessment.independently_appraised_actor_premise_bound ? 1U : 0U;
        counts.v13_eligible_profiles +=
            assessment.eligible_for_v13_actor_premise ? 1U : 0U;
    }

    AppraiserReceiptObservationV1 incoherent = prefix_observation(4U);
    incoherent.receipt_canonical = true;
    AppraiserReceiptAssessment incoherent_assessment =
        assess_appraiser_receipt(incoherent);
    require(!incoherent_assessment.observation_coherent
            && incoherent_assessment.disposition
                == AppraiserReceiptDisposition::observation_incoherent,
            "early incoherent observation accepted");
    cases.push_back({"incoherent_decode_gap", 4U,
                     appraiser_receipt_disposition_name(
                         incoherent_assessment.disposition),
                     incoherent_assessment,
                     "CANONICALITY_CANNOT_SKIP_DECODE"});

    incoherent = prefix_observation(29U);
    incoherent.appraiser_key_custody_independent = true;
    incoherent_assessment = assess_appraiser_receipt(incoherent);
    require(!incoherent_assessment.observation_coherent,
            "administration gap accepted");
    cases.push_back({"incoherent_administration_gap", 29U,
                     appraiser_receipt_disposition_name(
                         incoherent_assessment.disposition),
                     incoherent_assessment,
                     "KEY_CUSTODY_CANNOT_SKIP_DISTINCT_ADMINISTRATION"});

    const std::vector<CounterexampleRow> counterexamples = {
        {"valid_signature_is_independent_custody", "cryptographic validity as administration-root separation", "the signed statement cut precedes every custody premise"},
        {"public_test_key_is_enrolled_key", "public fixture key as governed appraiser identity", "test material proves only codec and verifier behavior"},
        {"separate_process_is_independent_appraiser", "process separation as constitutional independence", "the administration root is a separate premise"},
        {"distinct_user_namespace_is_independent_root", "namespace inode inequality as external administration", "an ancestor creator may still constitute mappings and terminate the child"},
        {"signed_claim_flag_is_fact", "a signed Boolean as reconstruction of policy or kernel bytes", "each claimed object must be independently rebound"},
        {"receipt_bytes_are_bearer_authority", "portable serialized bytes as V13 permission", "only a system-owned one-use endorsement may cross the cut"},
        {"one_local_read_excludes_replay", "one process consumption as global nonreuse", "portable replay exclusion is an independent final premise"},
        {"fresh_challenge_is_process_identity", "nonce equality as lifetime coordinate", "the process coordinate remains separately bound"},
        {"pid_number_is_process_coordinate", "numeric PID as lifetime identity", "an admitted lifetime-bearing coordinate is required"},
        {"pidfd_open_is_pidfd_get_info", "pidfd availability as complete process dossier", "the admitted query ABI remains independent"},
        {"filter_count_is_installed_policy", "seccomp mode or count as program identity", "the exact installed policy must be independently reconstructed"},
        {"entry_snapshot_is_installed_policy", "pre-copy trace bytes as kernel-consumed bytes", "the copy gap remains open without readback"},
        {"vdso_name_is_kernel_surface_identity", "procfs bracket name as exact executable bytes", "kernel surfaces require an exact independently reconstructed set"},
        {"kernel_release_is_kernel_surface_digest", "uname text as executable object identity", "profile and object identity are distinct"},
        {"v14_digest_is_v14_reopen", "a report field as custody of the dossier", "the appraiser must independently reopen the exact V14 subject"},
        {"actor_epoch_digest_is_continuous_hold", "endpoint digest equality as uninterrupted custody", "the held epoch must survive through V13 admission"},
        {"same_root_observer_is_harmless", "same-root mutation power as irrelevant", "the appraiser constitution must exclude the actor administration root"},
        {"signature_suite_is_key_custody", "Ed25519 selection as secret-key provenance", "algorithm and key custody are separate premises"},
        {"canonical_codec_is_source_provenance", "fixed bytes as appraiser executable identity", "constitution binds executable and policy independently"},
        {"transport_socket_is_endpoint_custody", "a local socketpair as anti-substitution channel", "endpoint ownership and one-use lifecycle remain system premises"},
        {"synthetic_full_prefix_is_operated_appraisal", "relation reachability as host success", "synthetic rows are proof-model evidence only"},
        {"signed_receipt_is_complete_process_image", "policy and kernel digests as every future instruction and datum", "complete process-image identity remains false"},
        {"appraisal_is_owner_constitution", "an independently appraised actor as governance", "owner and amendment law remain separate"},
        {"host_stop_is_archive_absence", "failure to appraise as proof no release exists", "the stop describes only this cloudtainer profile"},
    };

    write_cases(output, cases);
    write_counterexamples(output, counterexamples);
    counts.cases = cases.size();
    counts.counterexamples = counterexamples.size();
    counts.mutation_rejections =
        message_mutations + signature_mutations + key_mutations;

    std::ofstream summary(output / "appraiser-receipt-summary.json",
                          std::ios::binary);
    require(summary.good(), "open appraiser receipt summary");
    summary << "{\n"
            << "  \"canonical_receipt_profiles\": "
            << counts.canonical_receipt_profiles << ",\n"
            << "  \"cases\": " << counts.cases << ",\n"
            << "  \"counterexamples_reproduced\": "
            << counts.counterexamples << ",\n"
            << "  \"independent_appraisal_profiles\": "
            << counts.independent_appraisal_profiles << ",\n"
            << "  \"key_bit_mutations_rejected\": "
            << key_mutations << ",\n"
            << "  \"message_bit_mutations_rejected\": "
            << message_mutations << ",\n"
            << "  \"mutation_rejections\": "
            << counts.mutation_rejections << ",\n"
            << "  \"owner_authority\": false,\n"
            << "  \"public_test_key\": true,\n"
            << "  \"receipt_bytes\": " << kAppraiserReceiptBytes << ",\n"
            << "  \"schema\": \"slopos.rev0905.appraiser-receipt-campaign.v17\",\n"
            << "  \"signature_bit_mutations_rejected\": "
            << signature_mutations << ",\n"
            << "  \"signature_bytes\": "
            << kAppraiserReceiptSignatureBytes << ",\n"
            << "  \"signed_statement_not_custody\": true,\n"
            << "  \"signed_statement_profiles\": "
            << counts.signed_statement_profiles << ",\n"
            << "  \"status\": \"PASS\",\n"
            << "  \"v13_eligible_profiles\": "
            << counts.v13_eligible_profiles << "\n"
            << "}\n";

    return counts;
}

}  // namespace slopos::e0::handoff_cell::harness
