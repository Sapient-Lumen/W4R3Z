#pragma once

#include <cstddef>
#include <filesystem>

namespace slopos::e0::handoff_cell::harness {

struct ProviderGenesisCampaignCounts final {
    std::size_t cases{0U};
    std::size_t counterexamples{0U};
    std::size_t genesis_bit_mutations_rejected{0U};
    std::size_t append_bit_mutations_rejected{0U};
    std::size_t replay_exact_observations{0U};
    std::size_t conflicting_signed_successors{0U};
};

ProviderGenesisCampaignCounts run_provider_genesis_campaign(
    const std::filesystem::path& output);

}  // namespace slopos::e0::handoff_cell::harness
