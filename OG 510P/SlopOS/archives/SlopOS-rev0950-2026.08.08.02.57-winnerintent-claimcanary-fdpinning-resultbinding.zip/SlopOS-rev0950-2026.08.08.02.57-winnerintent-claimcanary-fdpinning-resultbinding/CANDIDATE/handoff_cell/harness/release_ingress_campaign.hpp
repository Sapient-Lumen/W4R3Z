#pragma once

#include <cstddef>
#include <filesystem>

namespace slopos::e0::handoff_cell::harness {

struct ReleaseIngressCampaignCounts final {
    std::size_t cases{0U};
    std::size_t counterexamples{0U};
    std::size_t exact_passive_admissions{0U};
    std::size_t path_replacement_admissions{0U};
    std::size_t activation_boundary_violations{0U};
    std::size_t incoherent_observations{0U};
};

ReleaseIngressCampaignCounts run_release_ingress_campaign(
    const std::filesystem::path& output);

}  // namespace slopos::e0::handoff_cell::harness
