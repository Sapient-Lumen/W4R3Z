#pragma once

#include "slopos/e0/generation_journal/record.hpp"

#include <cstddef>
#include <filesystem>

namespace slopos::e0::handoff_cell::harness {

struct PrincipalCampaignCounts final {
    std::size_t principal_cases{0U};
    std::size_t publication_cases{0U};
    std::size_t counterexamples{0U};
};

[[nodiscard]] PrincipalCampaignCounts run_principal_campaign(
    const std::filesystem::path& output,
    const std::filesystem::path& scratch,
    const generation_journal::EncodedRecord& pending);

}  // namespace slopos::e0::handoff_cell::harness
