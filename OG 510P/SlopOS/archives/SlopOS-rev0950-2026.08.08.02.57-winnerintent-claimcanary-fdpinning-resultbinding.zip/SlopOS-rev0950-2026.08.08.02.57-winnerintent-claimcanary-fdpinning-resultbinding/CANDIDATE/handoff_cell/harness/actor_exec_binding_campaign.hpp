#pragma once

#include <cstddef>
#include <filesystem>

namespace slopos::e0::handoff_cell::harness {

struct ActorExecCampaignCounts final {
    std::size_t cases{0U};
    std::size_t counterexamples{0U};
    std::size_t exec_input_bound_profiles{0U};
    std::size_t runtime_object_set_bound_profiles{0U};
    std::size_t exec_epoch_held_profiles{0U};
    std::size_t pre_exec_floor_bound_profiles{0U};
    std::size_t v13_eligible_profiles{0U};
    std::size_t incoherent_observations{0U};
};

ActorExecCampaignCounts run_actor_exec_binding_campaign(
    const std::filesystem::path& output);

}  // namespace slopos::e0::handoff_cell::harness
