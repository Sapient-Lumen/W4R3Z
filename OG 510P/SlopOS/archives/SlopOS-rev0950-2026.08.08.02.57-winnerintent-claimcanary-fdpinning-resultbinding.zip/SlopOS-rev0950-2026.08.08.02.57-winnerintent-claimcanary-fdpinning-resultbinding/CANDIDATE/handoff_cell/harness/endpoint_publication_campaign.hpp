#pragma once

#include <cstddef>
#include <filesystem>

namespace slopos::e0::handoff_cell::harness {

struct EndpointPublicationCampaignCounts final {
    std::size_t cases{0U};
    std::size_t counterexamples{0U};
};

[[nodiscard]] EndpointPublicationCampaignCounts
run_endpoint_publication_campaign(
    const std::filesystem::path& output,
    const std::filesystem::path& scratch);

[[nodiscard]] bool is_internal_endpoint_publication_worker(
    int argc, char** argv) noexcept;
[[nodiscard]] int run_internal_endpoint_publication_worker(
    int argc, char** argv) noexcept;

}  // namespace slopos::e0::handoff_cell::harness
