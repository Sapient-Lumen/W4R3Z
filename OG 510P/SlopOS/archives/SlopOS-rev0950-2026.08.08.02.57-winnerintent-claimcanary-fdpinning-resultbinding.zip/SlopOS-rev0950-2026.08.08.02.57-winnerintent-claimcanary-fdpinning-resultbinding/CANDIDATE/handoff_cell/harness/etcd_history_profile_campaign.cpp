#include "etcd_history_profile_campaign.hpp"

#include "slopos/e0/handoff_cell/etcd_history_profile.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace slopos::e0::handoff_cell::harness {
namespace {

struct CaseRow final {
    std::string name;
    EtcdHistoryAssessment assessment{};
    bool synthetic_runtime{true};
    bool retained_counterexample{false};
    std::string judgment;
};

struct CounterexampleRow final {
    std::string name;
    bool reproduced{false};
    std::string defeats;
    std::string retained_law;
};

[[noreturn]] void fail(const std::string& detail) {
    throw std::runtime_error(detail);
}

void require(const bool condition, const std::string& detail) {
    if (!condition) fail(detail);
}

[[nodiscard]] std::string bool_text(const bool value) {
    return value ? "true" : "false";
}

[[nodiscard]] ProviderDigest pattern(const std::uint8_t base) noexcept {
    ProviderDigest value{};
    for (std::size_t index = 0U; index < value.size(); ++index) {
        value[index] = static_cast<std::uint8_t>(
            static_cast<unsigned int>(base)
            + static_cast<unsigned int>(index));
    }
    return value;
}

[[nodiscard]] EtcdProfilePinV1 make_pin() {
    EtcdProfilePinV1 pin;
    pin.version = std::string(kEtcdProfileVersion);
    pin.release_archive_sha256 = kEtcdV3614LinuxAmd64ArchiveSha256;
    pin.cluster_id = 0x4f3b2a1908070605ULL;
    pin.member_ids = {
        0x1000000000000001ULL,
        0x1000000000000002ULL,
        0x1000000000000003ULL,
    };
    pin.client_ca = pattern(0x10U);
    pin.peer_ca = pattern(0x30U);
    pin.application_principal = pattern(0x50U);
    pin.administration_inventory = pattern(0x70U);
    pin.auth_revision = 17U;
    require(etcd_profile_pin_invariant(pin), "canonical etcd profile pin");
    return pin;
}

[[nodiscard]] EtcdHistoryExpectedV1 make_expected() {
    EtcdHistoryExpectedV1 expected;
    expected.generation_from = 41U;
    expected.generation_to = 42U;
    expected.operation_binding = pattern(0x01U);
    expected.floor_identity = pattern(0x21U);
    expected.predecessor_head = pattern(0x41U);
    expected.successor_head = pattern(0x61U);
    expected.spend_record = pattern(0x81U);
    expected.pending_entry = pattern(0xa1U);
    require(etcd_history_expected_invariant(expected),
            "canonical etcd history expectation");
    return expected;
}

[[nodiscard]] EtcdHistoryDossierV1 current_dossier(
    const EtcdProfilePinV1& pin,
    const EtcdHistoryExpectedV1& expected) {
    EtcdHistoryDossierV1 dossier;
    dossier.runtime_observed = true;
    dossier.version = pin.version;
    dossier.release_archive_sha256 = pin.release_archive_sha256;
    dossier.cluster_id = pin.cluster_id;
    dossier.member_id = pin.member_ids[0];
    dossier.auth_revision = pin.auth_revision;
    dossier.raft_term = 9U;
    dossier.txn_revision = 120U;
    dossier.query_revision = 120U;
    dossier.txn_reply = EtcdTxnReplyKind::compare_succeeded;
    dossier.query_delivered = true;
    dossier.linearizable_query = true;
    dossier.floor_present = true;
    dossier.head_present = true;
    dossier.spend_present = true;
    dossier.entry_present = true;
    dossier.floor_identity = expected.floor_identity;
    dossier.head = expected.successor_head;
    dossier.spend_record = expected.spend_record;
    dossier.pending_entry = expected.pending_entry;
    return dossier;
}

[[nodiscard]] EtcdHistoryDossierV1 unused_dossier(
    const EtcdProfilePinV1& pin,
    const EtcdHistoryExpectedV1& expected) {
    auto dossier = current_dossier(pin, expected);
    dossier.txn_reply = EtcdTxnReplyKind::no_reply;
    dossier.txn_revision = 0U;
    dossier.query_revision = 121U;
    dossier.head = expected.predecessor_head;
    dossier.spend_present = false;
    dossier.entry_present = false;
    dossier.spend_record = {};
    dossier.pending_entry = {};
    return dossier;
}

void require_assessment(const EtcdHistoryAssessment& assessment,
                        const EtcdHistoryDisposition expected,
                        const std::string& name) {
    require(assessment.disposition == expected,
            name + " disposition="
                + etcd_history_disposition_name(assessment.disposition));
    require(assessment.query_only, name + " not query-only");
    require(!assessment.response_authority, name + " response authority");
    require(!assessment.retry_authority, name + " retry authority");
    require(!assessment.provider_commit_proved,
            name + " provider commit promotion");
    require(!assessment.restore_continuity_proved,
            name + " restore continuity promotion");
    require(!assessment.external_currentness_proved,
            name + " external currentness promotion");
}

void add_case(std::vector<CaseRow>& rows,
              const std::string& name,
              const EtcdProfilePinV1& pin,
              const EtcdHistoryExpectedV1& expected,
              const EtcdHistoryDossierV1& dossier,
              const EtcdHistoryDisposition disposition,
              const bool synthetic_runtime,
              const bool retained_counterexample,
              const std::string& judgment) {
    const auto assessment = assess_etcd_history_dossier(
        pin, expected, dossier);
    require_assessment(assessment, disposition, name);
    rows.push_back({
        name, assessment, synthetic_runtime,
        retained_counterexample, judgment});
}

void write_cases(const std::filesystem::path& output,
                 const std::vector<CaseRow>& rows) {
    std::ofstream stream(output / "etcd-profile-cases.tsv", std::ios::binary);
    require(stream.good(), "open etcd-profile-cases.tsv");
    stream
        << "case\tdisposition\texact_release\texact_profile"
           "\tadmitted_cluster_coordinate\tlinearizable"
           "\texact_expected_state\tquery_only\tresponse_authority"
           "\tretry_authority\tprovider_commit_proved"
           "\trestore_continuity_proved\texternal_currentness_proved"
           "\tsynthetic_runtime\tretained_counterexample\tjudgment\n";
    for (const auto& row : rows) {
        stream
            << row.name << '\t'
            << etcd_history_disposition_name(row.assessment.disposition) << '\t'
            << bool_text(row.assessment.exact_release) << '\t'
            << bool_text(row.assessment.exact_profile) << '\t'
            << bool_text(row.assessment.admitted_cluster_coordinate) << '\t'
            << bool_text(row.assessment.linearizable) << '\t'
            << bool_text(row.assessment.exact_expected_state) << '\t'
            << bool_text(row.assessment.query_only) << '\t'
            << bool_text(row.assessment.response_authority) << '\t'
            << bool_text(row.assessment.retry_authority) << '\t'
            << bool_text(row.assessment.provider_commit_proved) << '\t'
            << bool_text(row.assessment.restore_continuity_proved) << '\t'
            << bool_text(row.assessment.external_currentness_proved) << '\t'
            << bool_text(row.synthetic_runtime) << '\t'
            << bool_text(row.retained_counterexample) << '\t'
            << row.judgment << '\n';
    }
}

void write_counterexamples(
    const std::filesystem::path& output,
    const std::vector<CounterexampleRow>& rows) {
    std::ofstream stream(
        output / "etcd-profile-counterexamples.tsv", std::ios::binary);
    require(stream.good(), "open etcd-profile-counterexamples.tsv");
    stream << "counterexample\treproduced\tdefeats\tretained_law\n";
    for (const auto& row : rows) {
        stream << row.name << '\t' << bool_text(row.reproduced) << '\t'
               << row.defeats << '\t' << row.retained_law << '\n';
    }
}

void write_plan(const std::filesystem::path& output,
                const EtcdHistoryTxnPlanV1& plan) {
    std::ofstream stream(output / "etcd-profile-plan.txt", std::ios::binary);
    require(stream.good(), "open etcd-profile-plan.txt");
    stream << "ETCD_PROFILE_VERSION=" << kEtcdProfileVersion << '\n';
    stream << "RELEASE_ARCHIVE_SHA256="
           << "ffe840ff9295808e88cce2794a18a5ac87f12a5203c8314d0bf6aa119b41bac5\n";
    stream << "KEY_PREFIX=" << kEtcdHistoryPrefix << '\n';
    stream << "SERIALIZABLE_READ=false\n";
    stream << "COMPARISONS=" << plan.comparisons << '\n';
    stream << "SUCCESS_WRITES=" << plan.success_writes << '\n';
    stream << "FAILURE_QUERIES=" << plan.failure_queries << '\n';
    stream << "--- TXN INTENT ---\n" << plan.interactive_txn;
    stream << "--- LINEARIZABLE QUERY INTENT ---\n"
           << plan.linearizable_query_script;
    stream << "--- END ---\n";
}

void write_summary(
    const std::filesystem::path& output,
    const EtcdHistoryProfileCampaignCounts& counts,
    const EtcdHistoryTxnPlanV1& plan) {
    std::ofstream stream(output / "etcd-profile-summary.json", std::ios::binary);
    require(stream.good(), "open etcd-profile-summary.json");
    stream
        << "{\n"
        << "  \"administration_plane_closed\": false,\n"
        << "  \"ambiguous_query_refinements\": "
        << counts.ambiguous_query_refinements << ",\n"
        << "  \"authority_granted\": false,\n"
        << "  \"cases\": " << counts.cases << ",\n"
        << "  \"comparisons\": " << plan.comparisons << ",\n"
        << "  \"counterexamples_reproduced\": "
        << counts.counterexamples << ",\n"
        << "  \"exact_current_observations\": "
        << counts.exact_current_observations << ",\n"
        << "  \"external_currentness_proved\": false,\n"
        << "  \"failure_queries\": " << plan.failure_queries << ",\n"
        << "  \"foreign_cluster_rejections\": "
        << counts.foreign_cluster_rejections << ",\n"
        << "  \"key_prefix\": \"/slopos/e0/provider-history/v1/\",\n"
        << "  \"linearizable_query_required\": true,\n"
        << "  \"operated_etcd_profile\": false,\n"
        << "  \"provider_commit_proved\": false,\n"
        << "  \"query_only\": true,\n"
        << "  \"release_archive_sha256\": "
           "\"ffe840ff9295808e88cce2794a18a5ac87f12a5203c8314d0bf6aa119b41bac5\",\n"
        << "  \"release_version\": \"v3.6.14\",\n"
        << "  \"response_authority\": false,\n"
        << "  \"restore_continuity_proved\": false,\n"
        << "  \"retry_authority\": false,\n"
        << "  \"schema\": "
           "\"slopos.rev0898.etcd-profile-shape-evidence.v1\",\n"
        << "  \"serializable_read_rejections\": "
        << counts.serializable_read_rejections << ",\n"
        << "  \"stable_media_proved\": false,\n"
        << "  \"status\": \"PASS\",\n"
        << "  \"success_writes\": " << plan.success_writes << ",\n"
        << "  \"synthetic_runtime_observations\": "
        << counts.synthetic_runtime_observations << "\n"
        << "}\n";
}

}  // namespace

EtcdHistoryProfileCampaignCounts run_etcd_history_profile_campaign(
    const std::filesystem::path& output) {
    const auto pin = make_pin();
    const auto expected = make_expected();
    const auto plan = make_etcd_history_txn_plan(expected);
    require(plan.has_value(), "construct exact etcd transaction plan");
    require(plan->comparisons == 4U, "plan comparison count");
    require(plan->success_writes == 3U, "plan success write count");
    require(plan->failure_queries == 4U, "plan failure query count");
    require(!plan->serializable_read, "plan must require linearizable query");

    std::vector<CaseRow> cases;

    auto dossier = current_dossier(pin, expected);
    dossier.runtime_observed = false;
    add_case(cases, "current_cloudtainer_runtime_unavailable",
             pin, expected, dossier,
             EtcdHistoryDisposition::runtime_unavailable,
             false, true, "NO_OPERATED_ETCD_PROFILE_THIS_CUT");

    dossier = current_dossier(pin, expected);
    add_case(cases, "exact_delivered_current",
             pin, expected, dossier,
             EtcdHistoryDisposition::exact_current_observation,
             true, false, "EXACT_DOSSIER_QUERY_ONLY");

    dossier = current_dossier(pin, expected);
    dossier.txn_reply = EtcdTxnReplyKind::no_reply;
    dossier.txn_revision = 0U;
    dossier.query_revision = 121U;
    add_case(cases, "lost_reply_query_current",
             pin, expected, dossier,
             EtcdHistoryDisposition::exact_current_after_ambiguous_reply,
             true, false, "AMBIGUITY_REFINED_BY_QUERY_NOT_RETRY");

    dossier = unused_dossier(pin, expected);
    add_case(cases, "lost_reply_query_unused",
             pin, expected, dossier,
             EtcdHistoryDisposition::exact_unused_after_ambiguous_reply,
             true, false, "UNUSED_ONLY_WITHIN_NAMED_PROFILE");

    dossier = current_dossier(pin, expected);
    dossier.txn_reply = EtcdTxnReplyKind::compare_failed;
    dossier.txn_revision = 120U;
    dossier.query_revision = 121U;
    add_case(cases, "compare_failed_query_current",
             pin, expected, dossier,
             EtcdHistoryDisposition::compare_failed_current_observation,
             true, false, "DUPLICATE_OR_OTHER_WRITER_QUERY_ONLY");

    dossier = unused_dossier(pin, expected);
    dossier.txn_reply = EtcdTxnReplyKind::compare_failed;
    dossier.txn_revision = 120U;
    add_case(cases, "compare_failed_query_unused",
             pin, expected, dossier,
             EtcdHistoryDisposition::compare_failed_unused_observation,
             true, false, "COMPARE_FAILURE_IS_NOT_RETRY_AUTHORITY");

    dossier = current_dossier(pin, expected);
    dossier.version = "v3.6.13";
    add_case(cases, "wrong_release_version",
             pin, expected, dossier,
             EtcdHistoryDisposition::release_mismatch,
             true, false, "REJECT_STALE_PATCH_PROFILE");

    dossier = current_dossier(pin, expected);
    dossier.release_archive_sha256[0] ^= 0x01U;
    add_case(cases, "wrong_release_archive_digest",
             pin, expected, dossier,
             EtcdHistoryDisposition::release_mismatch,
             true, false, "REJECT_UNPINNED_RELEASE_BYTES");

    dossier = current_dossier(pin, expected);
    dossier.cluster_id ^= 0x0101010101010101ULL;
    add_case(cases, "restored_new_cluster_exact_bytes",
             pin, expected, dossier,
             EtcdHistoryDisposition::foreign_cluster,
             true, true, "RESTORE_IS_NEW_LOGICAL_CLUSTER");

    dossier = current_dossier(pin, expected);
    dossier.member_id = 0x9999999999999999ULL;
    add_case(cases, "foreign_member",
             pin, expected, dossier,
             EtcdHistoryDisposition::foreign_member,
             true, false, "REJECT_MEMBER_OUTSIDE_FIXED_SET");

    dossier = current_dossier(pin, expected);
    dossier.auth_revision = pin.auth_revision + 1U;
    add_case(cases, "auth_revision_drift",
             pin, expected, dossier,
             EtcdHistoryDisposition::auth_revision_mismatch,
             true, false, "ADMINISTRATION_STATE_DRIFT_STOPS");

    dossier = current_dossier(pin, expected);
    dossier.query_delivered = false;
    add_case(cases, "query_unavailable",
             pin, expected, dossier,
             EtcdHistoryDisposition::query_unavailable,
             true, false, "PRESERVE_UNCERTAINTY");

    dossier = current_dossier(pin, expected);
    dossier.linearizable_query = false;
    add_case(cases, "serializable_stale_read",
             pin, expected, dossier,
             EtcdHistoryDisposition::serializable_query_rejected,
             true, true, "STALE_MEMBER_LOCAL_READ_IS_INADMISSIBLE");

    dossier = current_dossier(pin, expected);
    dossier.query_revision = dossier.txn_revision - 1U;
    add_case(cases, "query_revision_regression",
             pin, expected, dossier,
             EtcdHistoryDisposition::revision_regression,
             true, false, "REJECT_QUERY_BEHIND_DELIVERED_TXN");

    dossier = current_dossier(pin, expected);
    dossier.floor_identity[0] ^= 0x01U;
    add_case(cases, "floor_mismatch",
             pin, expected, dossier,
             EtcdHistoryDisposition::conflicting_observation,
             true, false, "REJECT_FOREIGN_FLOOR");

    dossier = current_dossier(pin, expected);
    dossier.head = expected.predecessor_head;
    add_case(cases, "partial_successor_state",
             pin, expected, dossier,
             EtcdHistoryDisposition::conflicting_observation,
             true, false, "REJECT_SPLIT_OR_REWRITTEN_STATE");

    dossier = current_dossier(pin, expected);
    add_case(cases, "coherent_clone_same_coordinates",
             pin, expected, dossier,
             EtcdHistoryDisposition::exact_current_observation,
             true, true, "SAME_IDS_AND_BYTES_DO_NOT_PROVE_NEWEST_HISTORY");

    dossier = current_dossier(pin, expected);
    add_case(cases, "root_rewrite_to_expected_bytes",
             pin, expected, dossier,
             EtcdHistoryDisposition::exact_current_observation,
             true, true, "EXACT_BYTES_DO_NOT_CLOSE_ADMIN_ROOT");

    EtcdProfilePinV1 malformed_pin = pin;
    malformed_pin.member_ids[2] = malformed_pin.member_ids[1];
    dossier = current_dossier(pin, expected);
    add_case(cases, "malformed_duplicate_member_pin",
             malformed_pin, expected, dossier,
             EtcdHistoryDisposition::profile_malformed,
             true, false, "REJECT_MALFORMED_PROFILE_PIN");

    const std::vector<CounterexampleRow> counterexamples{
        {
            "release_runtime_absent_in_cloudtainer",
            true,
            "exact_profile_plan_implies_operated_provider",
            "missing_exact_release_stops_before_cluster_or_transaction_claim",
        },
        {
            "coherent_clone_preserves_ids_and_bytes",
            true,
            "cluster_header_and_exact_values_prove_globally_newest_history",
            "external_nonrollback_currentness_remains_required",
        },
        {
            "root_role_rewrites_expected_values",
            true,
            "exact_query_closes_the_administration_plane",
            "all_root_membership_snapshot_and_restore_principals_are_premises",
        },
        {
            "restore_creates_new_logical_cluster",
            true,
            "copied_values_and_bumped_revision_preserve_provider_identity",
            "foreign_cluster_requires_owner_governed_successor_admission",
        },
        {
            "self_selected_profile_pin",
            true,
            "matching_release_cluster_ca_and_auth_coordinates_constitute_owner",
            "pin_provisioning_and_owner_ceremony_are_external",
        },
        {
            "exact_dossier_is_synthetic_fixture",
            true,
            "classifier_campaign_is_an_operated_etcd_experiment",
            "modeled_cases_test_logic_only_and_never_claim_runtime_operation",
        },
        {
            "rendered_txn_intent_not_transport",
            true,
            "deterministic_command_text_proves_submission_or_commit",
            "exact_release_admission_and_live_provider_execution_remain_required",
        },
    };

    EtcdHistoryProfileCampaignCounts counts;
    counts.cases = cases.size();
    counts.counterexamples = counterexamples.size();
    counts.exact_current_observations = static_cast<std::size_t>(std::count_if(
        cases.begin(), cases.end(), [](const CaseRow& row) {
            return row.assessment.exact_current();
        }));
    counts.ambiguous_query_refinements = 2U;
    counts.foreign_cluster_rejections = 1U;
    counts.serializable_read_rejections = 1U;
    counts.synthetic_runtime_observations = static_cast<std::size_t>(std::count_if(
        cases.begin(), cases.end(), [](const CaseRow& row) {
            return row.synthetic_runtime;
        }));

    require(counts.cases == 19U, "etcd profile case inventory");
    require(counts.counterexamples == 7U,
            "etcd profile counterexample inventory");
    require(counts.exact_current_observations == 5U,
            "etcd profile exact-current inventory");
    require(counts.synthetic_runtime_observations == 18U,
            "etcd profile synthetic runtime inventory");

    write_cases(output, cases);
    write_counterexamples(output, counterexamples);
    write_plan(output, *plan);
    write_summary(output, counts, *plan);
    return counts;
}

}  // namespace slopos::e0::handoff_cell::harness
