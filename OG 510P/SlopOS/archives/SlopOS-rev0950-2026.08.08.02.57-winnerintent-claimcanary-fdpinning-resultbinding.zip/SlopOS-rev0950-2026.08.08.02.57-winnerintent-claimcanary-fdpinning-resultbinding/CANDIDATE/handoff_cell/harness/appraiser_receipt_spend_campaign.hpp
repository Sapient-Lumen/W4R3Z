#pragma once
#include <cstddef>
#include <filesystem>
namespace slopos::e0::handoff_cell::harness {
struct AppraiserReceiptSpendCampaignCounts final {
    std::size_t cases{0U};
    std::size_t counterexamples{0U};
    std::size_t canonical_cross_bound_profiles{0U};
    std::size_t content_bound_spend_profiles{0U};
    std::size_t local_spend_profiles{0U};
    std::size_t external_floor_profiles{0U};
    std::size_t externally_spent_profiles{0U};
    std::size_t mutation_rejections{0U};
};
[[nodiscard]] AppraiserReceiptSpendCampaignCounts
run_appraiser_receipt_spend_campaign(const std::filesystem::path& output);
}  // namespace slopos::e0::handoff_cell::harness
