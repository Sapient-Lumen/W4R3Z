#pragma once

#include <cstddef>
#include <filesystem>

namespace slopos::e0::handoff_cell::harness {

struct SealedSnapshotOfferCampaignCounts final {
    std::size_t cases{0U};
    std::size_t counterexamples{0U};
    std::size_t admitted_ready_sources{0U};
    std::size_t mechanism_ready_actor_rejections{0U};
    std::size_t preoffer_alias_rejections{0U};
    std::size_t pre_receive_actor_rejections{0U};
    std::size_t post_receive_authority_import_incoherences{0U};
    std::size_t incoherent_observations{0U};
};

SealedSnapshotOfferCampaignCounts run_sealed_snapshot_offer_campaign(
    const std::filesystem::path& output);

}  // namespace slopos::e0::handoff_cell::harness
