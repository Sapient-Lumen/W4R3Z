#include "slopos/e0/handoff_cell/single_ledger_join.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

namespace slopos::e0::handoff_cell::harness {
namespace {

struct CaseRow final {
    std::string name;
    SingleLedgerJoinAssessment assessment{};
    std::string judgment;
};

struct CounterexampleRow final {
    std::string name;
    bool reproduced{false};
    std::string defeats;
    std::string retained_law;
};

[[noreturn]] void fail(const std::string& detail) {
    throw std::runtime_error(detail);
}

void require(const bool value, const std::string& detail) {
    if (!value) fail(detail);
}

[[nodiscard]] std::string bool_text(const bool value) {
    return value ? "true" : "false";
}

[[nodiscard]] ProviderDigest digest(const std::uint8_t base) noexcept {
    ProviderDigest out{};
    for (std::size_t index = 0U; index < out.size(); ++index) {
        out[index] = static_cast<std::uint8_t>(
            static_cast<unsigned int>(base)
            + static_cast<unsigned int>(index));
    }
    return out;
}

using ObservationMember = bool SingleLedgerJoinObservationV1::*;
constexpr std::array<ObservationMember, 46U> kOrderedMembers{{
    &SingleLedgerJoinObservationV1::profile_supplied,
    &SingleLedgerJoinObservationV1::exact_release_pinned,
    &SingleLedgerJoinObservationV1::provider_incarnation_supplied,
    &SingleLedgerJoinObservationV1::cluster_identity_exact,
    &SingleLedgerJoinObservationV1::member_set_exact,
    &SingleLedgerJoinObservationV1::client_ca_exact,
    &SingleLedgerJoinObservationV1::application_principal_exact,
    &SingleLedgerJoinObservationV1::administration_inventory_exact,
    &SingleLedgerJoinObservationV1::auth_revision_exact,
    &SingleLedgerJoinObservationV1::namespace_exclusive,
    &SingleLedgerJoinObservationV1::v18_spend_supplied,
    &SingleLedgerJoinObservationV1::v18_spend_canonical,
    &SingleLedgerJoinObservationV1::v18_spend_digest_exact,
    &SingleLedgerJoinObservationV1::edge_generation_exact,
    &SingleLedgerJoinObservationV1::edge_predecessor_exact,
    &SingleLedgerJoinObservationV1::edge_successor_exact,
    &SingleLedgerJoinObservationV1::operation_binding_exact,
    &SingleLedgerJoinObservationV1::floor_identity_exact,
    &SingleLedgerJoinObservationV1::pending_entry_exact,
    &SingleLedgerJoinObservationV1::key_derivation_exact,
    &SingleLedgerJoinObservationV1::head_compare_exact,
    &SingleLedgerJoinObservationV1::floor_compare_exact,
    &SingleLedgerJoinObservationV1::spend_absence_compare_exact,
    &SingleLedgerJoinObservationV1::entry_absence_compare_exact,
    &SingleLedgerJoinObservationV1::success_head_write_exact,
    &SingleLedgerJoinObservationV1::success_spend_write_exact,
    &SingleLedgerJoinObservationV1::success_entry_write_exact,
    &SingleLedgerJoinObservationV1::exactly_one_transaction_attempt,
    &SingleLedgerJoinObservationV1::result_observation_supplied,
    &SingleLedgerJoinObservationV1::response_cluster_exact,
    &SingleLedgerJoinObservationV1::response_member_admitted,
    &SingleLedgerJoinObservationV1::response_auth_revision_exact,
    &SingleLedgerJoinObservationV1::transaction_revision_nonzero,
    &SingleLedgerJoinObservationV1::linearizable_readback,
    &SingleLedgerJoinObservationV1::joined_head_exact,
    &SingleLedgerJoinObservationV1::joined_spend_exact,
    &SingleLedgerJoinObservationV1::joined_entry_exact,
    &SingleLedgerJoinObservationV1::joined_writes_share_revision,
    &SingleLedgerJoinObservationV1::duplicate_query_only,
    &SingleLedgerJoinObservationV1::ambiguous_completion_query_only,
    &SingleLedgerJoinObservationV1::reopen_query_only,
    &SingleLedgerJoinObservationV1::no_resubmit_route,
    &SingleLedgerJoinObservationV1::restore_replacement_detectable,
    &SingleLedgerJoinObservationV1::administration_root_distinct,
    &SingleLedgerJoinObservationV1::external_currentness_bound,
    &SingleLedgerJoinObservationV1::stable_storage_contract_bound,
}};

[[nodiscard]] SingleLedgerJoinObservationV1 prefix(
    const std::size_t true_count) noexcept {
    SingleLedgerJoinObservationV1 value;
    for (std::size_t index = 0U; index < true_count; ++index) {
        value.*kOrderedMembers[index] = true;
    }
    return value;
}

[[nodiscard]] std::string prefix_name(const std::size_t value) {
    std::ostringstream stream;
    stream << "ordered_prefix_" << std::setw(2) << std::setfill('0') << value;
    return stream.str();
}

[[nodiscard]] std::string judgment(
    const SingleLedgerJoinAssessment& value) {
    if (!value.observation_coherent) return "INCOHERENT_REJECTED";
    if (value.external_rollback_floor_bound) {
        return "SYNTHETIC_EXTERNAL_FLOOR_PREMISE";
    }
    if (value.external_currentness_bound) return "STORAGE_CONTRACT_MISSING";
    if (value.administration_distinct) return "EXTERNAL_CURRENTNESS_MISSING";
    if (value.restore_lineage_bound) return "INDEPENDENT_ADMINISTRATION_MISSING";
    if (value.query_only_recovery_bound) return "RESTORE_LINEAGE_MISSING";
    if (value.single_ledger_atomic_join_bound) {
        return "ATOMIC_JOIN_BOUND_EXTERNAL_CUSTODY_OPEN";
    }
    if (value.one_transaction_attempt_bound) return "RESULT_OBSERVATION_OPEN";
    if (value.exact_transaction_plan_bound) return "TRANSACTION_ATTEMPT_OPEN";
    if (value.v18_spend_input_bound) return "TRANSACTION_PLAN_OPEN";
    if (value.exact_provider_profile_bound) return "V18_INPUT_OPEN";
    return "ORDERED_PREMISE_OPEN";
}

void write_cases(const std::filesystem::path& output,
                 const std::vector<CaseRow>& rows) {
    std::ofstream stream(output / "single-ledger-cases.tsv");
    stream << "case\tdisposition\tcoherent\texact_profile\tv18_spend"
              "\ttransaction_plan\tone_attempt\tatomic_join\tquery_only"
              "\trestore_lineage\tadministration_distinct\texternal_currentness"
              "\texternal_floor\tv18_floor_eligible\tprovider_operated"
              "\tauthority\tjudgment\n";
    for (const auto& row : rows) {
        const auto& value = row.assessment;
        stream << row.name << '\t'
               << single_ledger_join_disposition_name(value.disposition) << '\t'
               << bool_text(value.observation_coherent) << '\t'
               << bool_text(value.exact_provider_profile_bound) << '\t'
               << bool_text(value.v18_spend_input_bound) << '\t'
               << bool_text(value.exact_transaction_plan_bound) << '\t'
               << bool_text(value.one_transaction_attempt_bound) << '\t'
               << bool_text(value.single_ledger_atomic_join_bound) << '\t'
               << bool_text(value.query_only_recovery_bound) << '\t'
               << bool_text(value.restore_lineage_bound) << '\t'
               << bool_text(value.administration_distinct) << '\t'
               << bool_text(value.external_currentness_bound) << '\t'
               << bool_text(value.external_rollback_floor_bound) << '\t'
               << bool_text(value.eligible_for_v18_external_floor_premise) << '\t'
               << bool_text(value.provider_operated) << '\t'
               << bool_text(value.owner_authority) << '\t'
               << row.judgment << '\n';
    }
}

void write_counterexamples(const std::filesystem::path& output,
                           const std::vector<CounterexampleRow>& rows) {
    std::ofstream stream(output / "single-ledger-counterexamples.tsv");
    stream << "counterexample\treproduced\tdefeats\tretained_law\n";
    for (const auto& row : rows) {
        stream << row.name << '\t' << bool_text(row.reproduced) << '\t'
               << row.defeats << '\t' << row.retained_law << '\n';
    }
}

void write_plan(const std::filesystem::path& output) {
    EtcdHistoryExpectedV1 expected;
    expected.generation_from = 41U;
    expected.generation_to = 42U;
    expected.operation_binding = digest(1U);
    expected.floor_identity = digest(41U);
    expected.predecessor_head = digest(81U);
    expected.successor_head = digest(121U);
    expected.spend_record = digest(161U);
    expected.pending_entry = digest(201U);
    const auto plan = make_etcd_history_txn_plan(expected);
    require(plan.has_value(), "exact V20 transaction plan");
    require(plan->comparisons == 4U && plan->success_writes == 3U
            && plan->failure_queries == 4U && !plan->serializable_read,
            "four-compare three-write four-query profile");
    require(plan->head_key == "/slopos/e0/provider-history/v1/head"
            && plan->floor_key == "/slopos/e0/provider-history/v1/floor",
            "fixed head/floor keys");
    require(plan->spend_key.starts_with(
                "/slopos/e0/provider-history/v1/spend/")
            && plan->entry_key.starts_with(
                "/slopos/e0/provider-history/v1/entry/"),
            "operation-bound spend and entry keys");
    std::ofstream stream(output / "single-ledger-plan.txt");
    stream << "profile_version=" << kEtcdProfileVersion << '\n'
           << "comparisons=4\n"
           << "success_writes=3\n"
           << "failure_queries=4\n"
           << "serializable_read=false\n"
           << "head_key=" << plan->head_key << '\n'
           << "floor_key=" << plan->floor_key << '\n'
           << "spend_key=" << plan->spend_key << '\n'
           << "entry_key=" << plan->entry_key << '\n'
           << "--- transaction intent ---\n" << plan->interactive_txn
           << "--- linearizable query intent ---\n"
           << plan->linearizable_query_script;
}

[[nodiscard]] std::vector<CounterexampleRow> counterexamples() {
    return {
        {"two_successful_writes_are_not_one_transaction", true,
         "write ordering as atomic join",
         "head spend and entry must be one provider transaction"},
        {"head_only_success_is_split_state", true,
         "head update as complete spend",
         "all three writes must share one committed revision"},
        {"spend_only_success_is_split_state", true,
         "spend record as complete join",
         "the pending entry is part of the same transaction"},
        {"entry_only_success_is_split_state", true,
         "pending entry as complete join",
         "the protected head and spend are part of the same transaction"},
        {"missing_floor_compare_accepts_foreign_incarnation", true,
         "head-only compare",
         "the exact floor identity is compared in the transaction"},
        {"missing_head_compare_accepts_stale_writer", true,
         "floor identity as predecessor",
         "the exact predecessor head is a compare operand"},
        {"missing_spend_absence_allows_duplicate", true,
         "head compare alone as one-use spend",
         "the operation-specific spend key must be absent"},
        {"missing_entry_absence_allows_republication", true,
         "spend absence alone as joined admission",
         "the operation-specific entry key must be absent"},
        {"multi_request_sequence_reopens_crash_cut", true,
         "three RPCs as one logical transaction",
         "one provider-native transaction request is required"},
        {"serializable_member_read_is_not_recovery", true,
         "member-local stale read as exact query",
         "recovery readback must be linearizable"},
        {"detached_success_reply_is_copyable", true,
         "response bytes as spend authority",
         "duplicate and reopen are query-only"},
        {"ambiguous_reply_resubmit_can_double_apply", true,
         "generic retry after timeout",
         "ambiguity is resolved only by exact query"},
        {"same_values_different_revisions_are_not_joined", true,
         "eventual equality as atomicity",
         "the three writes must share one transaction revision"},
        {"cluster_id_without_member_set_is_incomplete", true,
         "cluster ID alone as provider coordinate",
         "the admitted member set remains part of the profile"},
        {"member_id_without_cluster_id_is_incomplete", true,
         "member identity alone as provider incarnation",
         "cluster and member coordinates are jointly checked"},
        {"auth_revision_drift_changes_admission_surface", true,
         "static principal bytes as complete authorization",
         "the exact auth revision is checked"},
        {"client_ca_is_not_administration_inventory", true,
         "TLS trust root as complete governance",
         "all administration and restore roots remain explicit"},
        {"release_checksum_is_not_operated_runtime", true,
         "release pin as provider operation",
         "release admission and operation are separate"},
        {"rendered_plan_is_not_submission", true,
         "deterministic text as committed transaction",
         "transport and provider execution remain outside the relation"},
        {"self_hosted_database_is_not_independent", true,
         "local transaction engine as external custody",
         "administration roots must be distinct"},
        {"database_copy_preserves_atomic_history", true,
         "coherent clone as newest history",
         "external currentness is independent of local coherence"},
        {"snapshot_restore_rewinds_local_head", true,
         "crash atomicity as rollback resistance",
         "restore lineage must be detected and governed"},
        {"same_root_can_replace_database", true,
         "file permissions as constitutional custody",
         "same-root replacement remains an administrative attack"},
        {"same_root_can_rewrite_profile_pin", true,
         "caller-selected pin as owner constitution",
         "profile selection is not self-authenticating"},
        {"stable_storage_claim_needs_vfs_contract", true,
         "process-crash experiment as power-loss proof",
         "storage synchronization and hardware behavior remain premises"},
        {"fsync_success_is_not_external_newestness", true,
         "durability as anti-rollback",
         "durability and newest surviving history are separate"},
        {"query_only_classification_does_not_repair_conflict", true,
         "readback as mutation authority",
         "conflicts fail closed without repair writes"},
        {"operation_key_without_exact_bytes_is_insufficient", true,
         "operation identity as content identity",
         "spend and pending bytes are checked exactly"},
        {"generation_without_head_is_scalar_ambiguous", true,
         "monotonic number as winning-content identity",
         "generation and content head are bound together"},
        {"compaction_can_remove_event_history", true,
         "watch history as permanent receipt",
         "current exact state and retained immutable result are separate"},
        {"restore_to_new_cluster_is_history_break", true,
         "restored values as same provider incarnation",
         "replacement and restore require explicit succession"},
        {"atomic_join_is_not_authority", true,
         "one correct transaction as living law",
         "owner and epoch constitution remain separate"},
    };
}

int run(const std::filesystem::path& output) {
    std::filesystem::create_directories(output);
    std::vector<CaseRow> cases;
    for (std::size_t count = 0U; count <= kOrderedMembers.size(); ++count) {
        const auto assessment = assess_single_ledger_join(prefix(count));
        cases.push_back({prefix_name(count), assessment, judgment(assessment)});
    }

    for (std::size_t index : {0U, 9U, 27U, 37U}) {
        auto incoherent = prefix(index);
        incoherent.*kOrderedMembers[index + 1U] = true;
        const auto assessment = assess_single_ledger_join(incoherent);
        require(!assessment.observation_coherent,
                "incoherent observation accepted");
        cases.push_back({"incoherent_gap_" + std::to_string(index + 1U),
                         assessment, judgment(assessment)});
    }
    require(cases.size() == 51U, "V20 case inventory");

    const auto counters = counterexamples();
    require(counters.size() == 32U, "V20 counterexample inventory");
    write_cases(output, cases);
    write_counterexamples(output, counters);
    write_plan(output);

    const auto count_field = [&cases](const auto member) {
        std::size_t count = 0U;
        for (const auto& row : cases) {
            if (row.assessment.*member) ++count;
        }
        return count;
    };
    const std::size_t exact_profile = count_field(
        &SingleLedgerJoinAssessment::exact_provider_profile_bound);
    const std::size_t v18 = count_field(
        &SingleLedgerJoinAssessment::v18_spend_input_bound);
    const std::size_t plan = count_field(
        &SingleLedgerJoinAssessment::exact_transaction_plan_bound);
    const std::size_t attempts = count_field(
        &SingleLedgerJoinAssessment::one_transaction_attempt_bound);
    const std::size_t atomic = count_field(
        &SingleLedgerJoinAssessment::single_ledger_atomic_join_bound);
    const std::size_t query = count_field(
        &SingleLedgerJoinAssessment::query_only_recovery_bound);
    const std::size_t restore = count_field(
        &SingleLedgerJoinAssessment::restore_lineage_bound);
    const std::size_t external = count_field(
        &SingleLedgerJoinAssessment::external_rollback_floor_bound);
    require(exact_profile == 37U && v18 == 28U && plan == 20U
            && attempts == 19U && atomic == 9U && query == 5U
            && restore == 4U && external == 1U,
            "ordered V20 profile counts");

    std::ofstream summary(output / "single-ledger-summary.json");
    summary
        << "{\n"
        << "  \"atomic_join_profiles\": " << atomic << ",\n"
        << "  \"authority\": false,\n"
        << "  \"cases\": " << cases.size() << ",\n"
        << "  \"counterexamples_reproduced\": " << counters.size() << ",\n"
        << "  \"exact_profile_profiles\": " << exact_profile << ",\n"
        << "  \"external_floor_profiles\": " << external << ",\n"
        << "  \"network_attempted\": false,\n"
        << "  \"one_attempt_profiles\": " << attempts << ",\n"
        << "  \"provider_operated\": false,\n"
        << "  \"query_only_profiles\": " << query << ",\n"
        << "  \"restore_lineage_profiles\": " << restore << ",\n"
        << "  \"schema\": \"slopos.rev0908.single-ledger-join-campaign.v20\",\n"
        << "  \"status\": \"PASS\",\n"
        << "  \"transaction_plan_profiles\": " << plan << ",\n"
        << "  \"v18_floor_eligible_profiles\": " << external << ",\n"
        << "  \"v18_spend_profiles\": " << v18 << "\n"
        << "}\n";

    std::cout
        << "SINGLE_LEDGER_JOIN_CAMPAIGN=PASS cases=" << cases.size()
        << " counterexamples=" << counters.size()
        << " profile=" << exact_profile << " v18=" << v18
        << " plan=" << plan << " attempts=" << attempts
        << " atomic=" << atomic << " query=" << query
        << " restore=" << restore << " external=" << external
        << " provider_operated=false authority=false\n";
    return 0;
}

}  // namespace
}  // namespace slopos::e0::handoff_cell::harness

int main(const int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "usage: slopos_single_ledger_join_campaign OUTPUT\n";
        return 2;
    }
    try {
        return slopos::e0::handoff_cell::harness::run(
            std::filesystem::path(argv[1]));
    } catch (const std::exception& error) {
        std::cerr << "SINGLE_LEDGER_JOIN_CAMPAIGN=FAIL detail="
                  << error.what() << '\n';
        return 1;
    }
}
