#pragma once

#include <cstddef>
#include <filesystem>

namespace slopos::e0::handoff_cell::harness {

struct RootedReleaseCampaignCounts final {
    std::size_t cases{0U};
    std::size_t counterexamples{0U};
    std::size_t ready_descriptors{0U};
    std::size_t path_replacement_ready_descriptors{0U};
    std::size_t root_path_reopen_rejections{0U};
};

RootedReleaseCampaignCounts run_rooted_release_campaign(
    const std::filesystem::path& output);

}  // namespace slopos::e0::handoff_cell::harness
