#include "static_actor_confinement_campaign.hpp"

#include "slopos/e0/handoff_cell/static_actor_confinement.hpp"

#include <algorithm>
#include <array>
#include <filesystem>
#include <fstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

namespace slopos::e0::handoff_cell::harness {
namespace {

using slopos::e0::handoff_cell::StaticActorAssessment;
using slopos::e0::handoff_cell::StaticActorDisposition;
using slopos::e0::handoff_cell::StaticActorObservationV1;
using slopos::e0::handoff_cell::assess_static_actor_confinement;
using slopos::e0::handoff_cell::static_actor_disposition_name;

constexpr std::array<bool StaticActorObservationV1::*, 60U> kFields = {
    &StaticActorObservationV1::profile_supplied,
    &StaticActorObservationV1::v15_exec_input_object_bound,
    &StaticActorObservationV1::elf_profile_cross_bound_to_v15_object,
    &StaticActorObservationV1::elf64_little_endian_x86_64,
    &StaticActorObservationV1::elf_type_exact,
    &StaticActorObservationV1::program_header_table_bounded,
    &StaticActorObservationV1::entrypoint_inside_executable_load,
    &StaticActorObservationV1::pt_interp_absent,
    &StaticActorObservationV1::pt_dynamic_absent,
    &StaticActorObservationV1::executable_load_present,
    &StaticActorObservationV1::writable_executable_load_absent,
    &StaticActorObservationV1::executable_gnu_stack_absent,
    &StaticActorObservationV1::child_single_threaded,
    &StaticActorObservationV1::child_file_table_private,
    &StaticActorObservationV1::child_address_space_private,
    &StaticActorObservationV1::child_filesystem_context_private,
    &StaticActorObservationV1::pre_exec_root_and_cwd_same_empty_directory,
    &StaticActorObservationV1::pre_exec_root_path_unlinked,
    &StaticActorObservationV1::pre_exec_identity_nonroot,
    &StaticActorObservationV1::pre_exec_supplementary_groups_empty,
    &StaticActorObservationV1::pre_exec_capability_sets_empty,
    &StaticActorObservationV1::pre_exec_no_new_privs,
    &StaticActorObservationV1::pre_exec_read_implies_exec_absent,
    &StaticActorObservationV1::inherited_seccomp_stack_empty,
    &StaticActorObservationV1::tracer_prearmed,
    &StaticActorObservationV1::seccomp_entry_observed,
    &StaticActorObservationV1::seccomp_arch_exact,
    &StaticActorObservationV1::seccomp_operation_exact,
    &StaticActorObservationV1::seccomp_flags_exact,
    &StaticActorObservationV1::seccomp_program_snapshot_copied_at_entry,
    &StaticActorObservationV1::seccomp_instruction_count_exact,
    &StaticActorObservationV1::seccomp_instructions_exact,
    &StaticActorObservationV1::seccomp_install_succeeded,
    &StaticActorObservationV1::installed_seccomp_stack_exact_one,
    &StaticActorObservationV1::no_later_policy_install_before_exec,
    &StaticActorObservationV1::exec_event_completes_v15_entry,
    &StaticActorObservationV1::tracee_held_before_first_user_instruction,
    &StaticActorObservationV1::initial_mapping_inventory_complete,
    &StaticActorObservationV1::candidate_executable_mappings_match,
    &StaticActorObservationV1::interpreter_and_shared_object_mappings_absent,
    &StaticActorObservationV1::declared_kernel_executable_mappings_only,
    &StaticActorObservationV1::writable_executable_mappings_absent,
    &StaticActorObservationV1::post_exec_descriptor_inventory_exact,
    &StaticActorObservationV1::exec_descriptor_closed_on_exec,
    &StaticActorObservationV1::post_exec_root_and_cwd_same_held_directory,
    &StaticActorObservationV1::absolute_path_exec_canary_confined,
    &StaticActorObservationV1::later_exec_and_executable_mapping_routes_blocked,
    &StaticActorObservationV1::descriptor_acquisition_and_rights_import_blocked,
    &StaticActorObservationV1::process_peer_creation_blocked,
    &StaticActorObservationV1::network_and_async_bypass_blocked,
    &StaticActorObservationV1::post_exec_policy_behavior_exact,
    &StaticActorObservationV1::challenge_generated_after_held_appraisal,
    &StaticActorObservationV1::challenge_response_exact,
    &StaticActorObservationV1::appraiser_process_separate,
    &StaticActorObservationV1::appraiser_administration_root_distinct,
    &StaticActorObservationV1::installed_filter_independently_reconstructed,
    &StaticActorObservationV1::kernel_executable_surfaces_independently_bound,
    &StaticActorObservationV1::pidfd_get_info_coordinate_exact,
    &StaticActorObservationV1::v14_dossier_cross_bound,
    &StaticActorObservationV1::exec_epoch_held_through_v13_admission,
};

constexpr std::array<std::string_view, 60U> kCutNames = {
    "missing_profile",
    "v15_exec_input_unavailable",
    "elf_profile_not_cross_bound_to_v15_object",
    "elf_architecture_mismatch",
    "elf_type_mismatch",
    "program_header_table_unbounded",
    "entrypoint_outside_executable_load",
    "pt_interp_present",
    "pt_dynamic_present",
    "executable_load_missing",
    "writable_executable_load_present",
    "executable_gnu_stack_present",
    "single_threaded_child_unproved",
    "private_file_table_unproved",
    "private_address_space_unproved",
    "private_filesystem_context_unproved",
    "pre_exec_root_or_cwd_not_same_empty_directory",
    "pre_exec_root_path_still_linked",
    "pre_exec_identity_not_nonroot",
    "pre_exec_supplementary_groups_nonempty",
    "pre_exec_capability_floor_incomplete",
    "pre_exec_no_new_privs_missing",
    "read_implies_exec_personality_present",
    "inherited_seccomp_stack_present",
    "tracer_not_prearmed",
    "seccomp_entry_unobserved",
    "seccomp_architecture_mismatch",
    "seccomp_operation_mismatch",
    "seccomp_flags_mismatch",
    "seccomp_program_snapshot_unavailable",
    "seccomp_instruction_count_mismatch",
    "seccomp_instructions_mismatch",
    "seccomp_install_failed",
    "installed_seccomp_stack_not_exact_one",
    "later_policy_install_not_excluded",
    "exec_event_not_linked_to_v15_entry",
    "tracee_not_held_before_first_instruction",
    "initial_mapping_inventory_unavailable",
    "candidate_executable_mapping_mismatch",
    "foreign_interpreter_or_shared_mapping_present",
    "kernel_executable_mapping_set_mismatch",
    "writable_executable_mapping_present",
    "post_exec_descriptor_inventory_mismatch",
    "exec_descriptor_survived_exec",
    "post_exec_root_or_cwd_drifted",
    "absolute_path_exec_canary_escaped",
    "later_exec_or_executable_mapping_route_open",
    "descriptor_acquisition_or_rights_route_open",
    "process_peer_creation_route_open",
    "network_or_async_bypass_route_open",
    "post_exec_policy_behavior_mismatch",
    "challenge_not_generated_after_held_appraisal",
    "challenge_response_mismatch",
    "appraiser_process_absent",
    "appraiser_root_not_distinct",
    "installed_filter_not_independently_reconstructed",
    "kernel_executable_surfaces_not_independently_bound",
    "pidfd_get_info_coordinate_unavailable",
    "v14_dossier_not_cross_bound",
    "exec_epoch_not_held_through_v13_admission",
};

constexpr std::array<StaticActorDisposition, 60U> kExpected = {
    StaticActorDisposition::profile_unavailable,
    StaticActorDisposition::v15_exec_input_unavailable,
    StaticActorDisposition::elf_profile_cross_binding_unproved,
    StaticActorDisposition::elf_architecture_rejected,
    StaticActorDisposition::elf_type_rejected,
    StaticActorDisposition::program_header_table_rejected,
    StaticActorDisposition::entrypoint_rejected,
    StaticActorDisposition::interpreter_present,
    StaticActorDisposition::dynamic_segment_present,
    StaticActorDisposition::executable_load_missing,
    StaticActorDisposition::writable_executable_load_rejected,
    StaticActorDisposition::executable_stack_rejected,
    StaticActorDisposition::single_threaded_child_unproved,
    StaticActorDisposition::file_table_custody_unproved,
    StaticActorDisposition::address_space_custody_unproved,
    StaticActorDisposition::filesystem_context_custody_unproved,
    StaticActorDisposition::empty_root_custody_unproved,
    StaticActorDisposition::root_path_not_unlinked,
    StaticActorDisposition::pre_exec_identity_rejected,
    StaticActorDisposition::supplementary_groups_rejected,
    StaticActorDisposition::capability_floor_rejected,
    StaticActorDisposition::no_new_privs_missing,
    StaticActorDisposition::personality_floor_rejected,
    StaticActorDisposition::inherited_seccomp_stack_present,
    StaticActorDisposition::tracer_unavailable,
    StaticActorDisposition::seccomp_entry_unobserved,
    StaticActorDisposition::seccomp_architecture_rejected,
    StaticActorDisposition::seccomp_operation_rejected,
    StaticActorDisposition::seccomp_flags_rejected,
    StaticActorDisposition::seccomp_program_snapshot_unavailable,
    StaticActorDisposition::seccomp_instruction_count_mismatch,
    StaticActorDisposition::seccomp_instruction_mismatch,
    StaticActorDisposition::seccomp_install_failed,
    StaticActorDisposition::installed_seccomp_stack_mismatch,
    StaticActorDisposition::later_policy_install_unexcluded,
    StaticActorDisposition::exec_event_not_linked,
    StaticActorDisposition::first_instruction_hold_unproved,
    StaticActorDisposition::mapping_inventory_unavailable,
    StaticActorDisposition::candidate_mapping_mismatch,
    StaticActorDisposition::foreign_runtime_mapping_present,
    StaticActorDisposition::kernel_mapping_set_rejected,
    StaticActorDisposition::writable_executable_mapping_present,
    StaticActorDisposition::descriptor_inventory_rejected,
    StaticActorDisposition::exec_descriptor_not_closed,
    StaticActorDisposition::post_exec_root_custody_unproved,
    StaticActorDisposition::absolute_path_exec_route_open,
    StaticActorDisposition::later_exec_or_mapping_route_open,
    StaticActorDisposition::descriptor_acquisition_route_open,
    StaticActorDisposition::process_peer_creation_route_open,
    StaticActorDisposition::network_or_async_route_open,
    StaticActorDisposition::post_exec_policy_behavior_mismatch,
    StaticActorDisposition::challenge_order_rejected,
    StaticActorDisposition::challenge_response_rejected,
    StaticActorDisposition::appraiser_unavailable,
    StaticActorDisposition::appraiser_not_independent,
    StaticActorDisposition::installed_filter_not_independently_reconstructed,
    StaticActorDisposition::kernel_executable_surfaces_unbound,
    StaticActorDisposition::pidfd_coordinate_unavailable,
    StaticActorDisposition::v14_dossier_unavailable,
    StaticActorDisposition::exec_epoch_custody_unproved,
};

struct CaseRow final {
    std::string name;
    StaticActorAssessment assessment;
    bool retained_counterexample{false};
    std::string judgment;
};

struct CounterexampleRow final {
    std::string name;
    std::string defeats;
    std::string retained_law;
};

[[nodiscard]] std::string boolean(const bool value) {
    return value ? "true" : "false";
}

void require(const bool condition, const std::string& detail) {
    if (!condition) throw std::runtime_error(detail);
}

[[nodiscard]] StaticActorObservationV1 prefix_observation(
    const std::size_t count) {
    StaticActorObservationV1 observation;
    for (std::size_t index = 0U; index < count; ++index) {
        observation.*kFields[index] = true;
    }
    return observation;
}

void add_case(std::vector<CaseRow>& rows, const std::string& name,
              const StaticActorObservationV1& observation,
              const StaticActorDisposition expected,
              const bool counterexample, const std::string& judgment) {
    const StaticActorAssessment assessment =
        assess_static_actor_confinement(observation);
    require(assessment.disposition == expected,
            "static-actor disposition " + name);
    require(!assessment.complete_process_image_bound
                && !assessment.installed_seccomp_program_bound
                && !assessment.source_provenance_proved
                && !assessment.network_attempted && !assessment.ready_sent
                && !assessment.rights_imported && !assessment.candidate_created
                && !assessment.candidate_bytes_read
                && !assessment.archive_acquired && !assessment.archive_admitted
                && !assessment.provider_operated
                && !assessment.owner_authority && !assessment.living_law,
            "static-actor authority leak " + name);
    rows.push_back({name, assessment, counterexample, judgment});
}

void write_cases(const std::filesystem::path& output,
                 const std::vector<CaseRow>& rows) {
    std::ofstream stream(output / "static-actor-cases.tsv", std::ios::binary);
    require(stream.good(), "open static-actor-cases.tsv");
    stream << "case\tdisposition\tobservation_coherent\tstatic_exec_profile_exact"
              "\tpre_exec_filesystem_floor_bound\tpre_exec_privilege_floor_bound\tpre_exec_seccomp_installation_observation_bound"
              "\tinstalled_seccomp_program_bound"
              "\theld_initial_user_executable_mapping_set_bound\tpost_exec_substitution_floor_bound"
              "\thosted_static_actor_envelope_bound\tindependent_appraisal_bound"
              "\teligible_for_v15_runtime_and_preexec_evidence"
              "\tv14_dossier_bound_to_static_actor\teligible_for_v13_actor_premise"
              "\tcomplete_process_image_bound\tnetwork_attempted\tready_sent"
              "\trights_imported\tcandidate_bytes_read\tarchive_admitted"
              "\towner_authority\tliving_law\tretained_counterexample\tjudgment\n";
    for (const auto& row : rows) {
        const auto& a = row.assessment;
        stream << row.name << '\t' << static_actor_disposition_name(a.disposition)
               << '\t' << boolean(a.observation_coherent)
               << '\t' << boolean(a.static_exec_profile_exact)
               << '\t' << boolean(a.pre_exec_filesystem_floor_bound)
               << '\t' << boolean(a.pre_exec_privilege_floor_bound)
               << '\t' << boolean(a.pre_exec_seccomp_installation_observation_bound)
               << '\t' << boolean(a.installed_seccomp_program_bound)
               << '\t' << boolean(a.held_initial_user_executable_mapping_set_bound)
               << '\t' << boolean(a.post_exec_substitution_floor_bound)
               << '\t' << boolean(a.hosted_static_actor_envelope_bound)
               << '\t' << boolean(a.independent_appraisal_bound)
               << '\t' << boolean(a.eligible_for_v15_runtime_and_preexec_evidence)
               << '\t' << boolean(a.v14_dossier_bound_to_static_actor)
               << '\t' << boolean(a.eligible_for_v13_actor_premise)
               << '\t' << boolean(a.complete_process_image_bound)
               << '\t' << boolean(a.network_attempted)
               << '\t' << boolean(a.ready_sent)
               << '\t' << boolean(a.rights_imported)
               << '\t' << boolean(a.candidate_bytes_read)
               << '\t' << boolean(a.archive_admitted)
               << '\t' << boolean(a.owner_authority)
               << '\t' << boolean(a.living_law)
               << '\t' << boolean(row.retained_counterexample)
               << '\t' << row.judgment << '\n';
    }
}

void write_counterexamples(const std::filesystem::path& output,
                           const std::vector<CounterexampleRow>& rows) {
    std::ofstream stream(output / "static-actor-counterexamples.tsv",
                         std::ios::binary);
    require(stream.good(), "open static-actor-counterexamples.tsv");
    stream << "counterexample\treproduced\tdefeats\tretained_law\n";
    for (const auto& row : rows) {
        stream << row.name << "\ttrue\t" << row.defeats << '\t'
               << row.retained_law << '\n';
    }
}

void write_summary(const std::filesystem::path& output,
                   const StaticActorCampaignCounts& counts) {
    std::ofstream stream(output / "static-actor-summary.json", std::ios::binary);
    require(stream.good(), "open static-actor-summary.json");
    stream << "{\n"
           << "  \"archive_admitted\": false,\n"
           << "  \"cases\": " << counts.cases << ",\n"
           << "  \"complete_process_image_bound\": false,\n"
           << "  \"counterexamples_reproduced\": " << counts.counterexamples << ",\n"
           << "  \"eligible_for_v13_profiles\": " << counts.v13_eligible << ",\n"
           << "  \"held_user_mapping_set_bound_profiles\": " << counts.held_user_mapping_set_bound << ",\n"
           << "  \"hosted_envelope_bound_profiles\": " << counts.hosted_envelope_bound << ",\n"
           << "  \"incoherent_observations\": " << counts.incoherent_observations << ",\n"
           << "  \"independent_appraisal_bound_profiles\": " << counts.independent_appraisal_bound << ",\n"
           << "  \"installed_seccomp_program_bound\": false,\n"
           << "  \"living_law\": false,\n"
           << "  \"network_attempted\": false,\n"
           << "  \"owner_authority\": false,\n"
           << "  \"post_exec_floor_bound_profiles\": " << counts.post_exec_floor_bound << ",\n"
           << "  \"pre_exec_filesystem_floor_bound_profiles\": " << counts.pre_exec_filesystem_floor_bound << ",\n"
           << "  \"pre_exec_floor_bound_profiles\": " << counts.pre_exec_floor_bound << ",\n"
           << "  \"ready_sent\": false,\n"
           << "  \"rights_imported\": false,\n"
           << "  \"schema\": \"slopos.rev0904.static-actor-confinement-campaign.v16\",\n"
           << "  \"pre_exec_seccomp_installation_observation_bound_profiles\": " << counts.pre_exec_seccomp_installation_observation_bound << ",\n"
           << "  \"static_profile_exact_profiles\": " << counts.static_profile_exact << ",\n"
           << "  \"status\": \"PASS\",\n"
           << "  \"v15_evidence_eligible_profiles\": " << counts.v15_evidence_eligible << "\n"
           << "}\n";
}

}  // namespace

StaticActorCampaignCounts run_static_actor_confinement_campaign(
    const std::filesystem::path& output) {
    std::vector<CaseRow> rows;
    for (std::size_t cut = 0U; cut < kFields.size(); ++cut) {
        add_case(rows, std::string(kCutNames[cut]), prefix_observation(cut),
                 kExpected[cut], true, "ORDERED_PREFIX_FAIL_CLOSED");
    }

    auto incoherent = prefix_observation(0U);
    incoherent.v15_exec_input_object_bound = true;
    add_case(rows, "incoherent_v15_without_profile", incoherent,
             StaticActorDisposition::observation_incoherent, true,
             "LATER_FACT_CANNOT_LAUNDER_MISSING_PROFILE");

    add_case(rows, "synthetic_exact_static_actor_and_dossier",
             prefix_observation(kFields.size()),
             StaticActorDisposition::static_actor_and_dossier_bound, false,
             "SYNTHETIC_COMPOSITION_ONLY");

    const std::vector<CounterexampleRow> counterexamples = {
        {"static_binary_is_source_provenance", "static linkage as source or release provenance", "static shape is one runtime-edge fact only"},
        {"no_pt_interp_is_complete_runtime", "absence of PT_INTERP as closure of every executable mapping", "inventory actual mappings and later mapping routes"},
        {"no_pt_dynamic_prevents_later_mapping", "absence of PT_DYNAMIC as a future syscall policy", "later mmap mprotect shmat and exec routes remain separate"},
        {"no_wx_segment_prevents_jit", "ELF segment flags as a runtime mapping policy", "block executable mapping and permission changes after exec"},
        {"nonexec_stack_is_complete_memory_policy", "GNU_STACK NX as closure of all executable memory", "every executable mapping route remains explicit"},
        {"entrypoint_in_exec_load_is_behavior_identity", "entrypoint placement as proof of all future instructions", "the theorem binds an initial object set and floor only"},
        {"one_thread_is_private_files", "single-threadedness as absence of CLONE_FILES peers", "file-table custody is independent"},
        {"one_thread_is_private_vm", "single-threadedness as absence of CLONE_VM peers", "address-space custody is independent"},
        {"post_exec_nonroot_is_pre_exec_floor", "new-image credentials as confinement of the launch interval", "observe the floor before seccomp and exec"},
        {"empty_effective_caps_is_empty_bounding_set", "effective capability zero as impossibility of later regain", "bind all admitted capability sets and no_new_privs"},
        {"no_new_privs_is_seccomp_identity", "no_new_privs as an exact syscall policy", "bind the actual filter installation input"},
        {"mmap_exec_filter_ignores_personality", "PROT_EXEC checks without READ_IMPLIES_EXEC custody", "bind personality and prevent later changes"},
        {"filter_length_is_filter_identity", "classic-BPF instruction count as exact policy", "compare every code jt jf and k field"},
        {"finite_denials_are_filter_identity", "behavioral probes as proof of the complete filter", "retain exact installation-input bytes separately"},
        {"inherited_filter_stack_is_empty", "one observed filter input as the complete installed stack", "prove the inherited stack empty before installation"},
        {"seccomp_success_is_no_later_stack", "one successful install as the final filter stack", "require exactly one installed filter and exclude later seccomp and PR_SET_SECCOMP before exec"},
        {"install_input_is_independent_reconstruction", "same-root ptrace capture as independent post-exec appraisal", "a distinct root must reconstruct the installed policy"},
        {"maps_path_is_object_identity", "procfs pathname text as executable-object identity", "compare device inode and the sealed candidate"},
        {"maps_snapshot_is_future_closure", "one stopped mapping inventory as permanent runtime custody", "bind actor-controlled later substitution routes and external roots"},
        {"kernel_vdso_is_candidate_object", "all executable mappings as release-candidate bytes", "declare kernel-provided executable mappings separately"},
        {"kernel_surface_name_is_identity", "the strings vdso and vsyscall as exact kernel executable identity", "independent kernel-surface binding remains a separate premise"},
        {"held_ptrace_stop_is_owner_custody", "same-root ptrace control as owner constitution", "proof instrumentation is not a constitutional root"},
        {"exitkill_is_last_reference_custody", "PTRACE_O_EXITKILL as a production lifetime theorem", "EXITKILL is bounded laboratory cleanup"},
        {"cloexec_is_consumption", "closing the child exec descriptor as global one-use transfer", "the parent and other aliases remain separate"},
        {"fd_number_is_descriptor_identity", "fixed descriptor number as custody of one object", "inspect object shape and exact inventory"},
        {"no_open_is_no_fd_acquisition", "blocking pathname opens as closure of SCM_RIGHTS imports", "recvmsg and descriptor duplication routes remain explicit"},
        {"no_execve_is_no_exec", "blocking execve while allowing unrestricted execveat", "the one allowed execveat contract must be exact and its fd close-on-exec"},
        {"no_clone_is_no_external_writer", "blocking child creation as exclusion of outside process_vm_writev or ptrace", "external administration remains outside actor syscall policy"},
        {"no_socket_is_no_network_effect", "blocking socket creation as closure of inherited sockets and async submission", "inventory descriptors and block connect send and io_uring routes"},
        {"io_uring_block_is_complete_async_audit", "one async API denial as a complete effect taxonomy", "the filter is a named floor not complete effect confinement"},
        {"challenge_echo_is_program_identity", "one exact nonce response as proof of every executed instruction", "challenge is bounded liveness after stronger custody facts"},
        {"separate_process_is_distinct_root", "process separation as administrative independence", "root constitution is external to pid separation"},
        {"proc_status_replaces_pidfd_get_info", "procfs coordinates as the admitted process query", "V14 retains the exact PIDFD_GET_INFO requirement"},
        {"v16_replaces_v14", "static runtime and policy evidence as the complete actor dossier", "source egress timeout retry administration and appraisal remain V14"},
        {"static_actor_authorizes_network", "hosted confinement evidence as acquisition authority", "READY rights release bytes and authority remain false"},
        {"mutable_source_profile_is_sealed_target_profile", "ELF facts read from a mutable source as facts about later copied bytes", "inspect and digest the same sealed V15 object"},
        {"seccomp_scalars_bind_pointed_path", "classic-BPF argument checks as custody of pathname bytes", "seccomp cannot dereference the execveat pathname"},
        {"closed_exec_fd_blocks_absolute_path", "CLOEXEC consumption of fd five as denial of absolute-path execveat", "absolute paths ignore dirfd and require a separate filesystem floor"},
        {"chroot_alone_is_confinement", "chroot without cwd and descriptor closure as an actor-local pathname theorem", "bind root cwd emptiness unlinking and exact descriptor inventory together"},
        {"anonymous_empty_root_is_independent_custody", "an unlinked empty root as protection from same-host administrators", "the hosted root remains externally mutable through privileged administration"},
        {"complete_synthetic_row_is_living_law", "a pure relation row as constituted law", "owner adoption and public amendment remain absent"},
    };

    require(rows.size() == 62U, "static-actor case inventory");
    require(counterexamples.size() == 41U,
            "static-actor counterexample inventory");
    write_cases(output, rows);
    write_counterexamples(output, counterexamples);

    StaticActorCampaignCounts counts;
    counts.cases = rows.size();
    counts.counterexamples = counterexamples.size();
    counts.static_profile_exact = static_cast<std::size_t>(std::count_if(
        rows.begin(), rows.end(), [](const CaseRow& row) {
            return row.assessment.static_exec_profile_exact;
        }));
    counts.pre_exec_filesystem_floor_bound = static_cast<std::size_t>(std::count_if(
        rows.begin(), rows.end(), [](const CaseRow& row) {
            return row.assessment.pre_exec_filesystem_floor_bound;
        }));
    counts.pre_exec_floor_bound = static_cast<std::size_t>(std::count_if(
        rows.begin(), rows.end(), [](const CaseRow& row) {
            return row.assessment.pre_exec_privilege_floor_bound;
        }));
    counts.pre_exec_seccomp_installation_observation_bound = static_cast<std::size_t>(std::count_if(
        rows.begin(), rows.end(), [](const CaseRow& row) {
            return row.assessment.pre_exec_seccomp_installation_observation_bound;
        }));
    counts.held_user_mapping_set_bound = static_cast<std::size_t>(std::count_if(
        rows.begin(), rows.end(), [](const CaseRow& row) {
            return row.assessment.held_initial_user_executable_mapping_set_bound;
        }));
    counts.post_exec_floor_bound = static_cast<std::size_t>(std::count_if(
        rows.begin(), rows.end(), [](const CaseRow& row) {
            return row.assessment.post_exec_substitution_floor_bound;
        }));
    counts.hosted_envelope_bound = static_cast<std::size_t>(std::count_if(
        rows.begin(), rows.end(), [](const CaseRow& row) {
            return row.assessment.hosted_static_actor_envelope_bound;
        }));
    counts.independent_appraisal_bound = static_cast<std::size_t>(std::count_if(
        rows.begin(), rows.end(), [](const CaseRow& row) {
            return row.assessment.independent_appraisal_bound;
        }));
    counts.v15_evidence_eligible = static_cast<std::size_t>(std::count_if(
        rows.begin(), rows.end(), [](const CaseRow& row) {
            return row.assessment.eligible_for_v15_runtime_and_preexec_evidence;
        }));
    counts.v13_eligible = static_cast<std::size_t>(std::count_if(
        rows.begin(), rows.end(), [](const CaseRow& row) {
            return row.assessment.eligible_for_v13_actor_premise;
        }));
    counts.incoherent_observations = static_cast<std::size_t>(std::count_if(
        rows.begin(), rows.end(), [](const CaseRow& row) {
            return !row.assessment.observation_coherent;
        }));

    require(counts.static_profile_exact == 49U, "static profile count");
    require(counts.pre_exec_filesystem_floor_bound == 43U,
            "pre-exec filesystem floor count");
    require(counts.pre_exec_floor_bound == 37U, "pre-exec floor count");
    require(counts.pre_exec_seccomp_installation_observation_bound == 26U,
            "seccomp installation count");
    require(counts.held_user_mapping_set_bound == 19U, "held runtime count");
    require(counts.post_exec_floor_bound == 10U, "post-exec floor count");
    require(counts.hosted_envelope_bound == 8U, "hosted envelope count");
    require(counts.independent_appraisal_bound == 4U,
            "independent appraisal count");
    require(counts.v15_evidence_eligible == 4U, "V15 evidence count");
    require(counts.v13_eligible == 1U, "V13 eligibility count");
    require(counts.incoherent_observations == 1U, "incoherent count");
    write_summary(output, counts);
    return counts;
}

}  // namespace slopos::e0::handoff_cell::harness
