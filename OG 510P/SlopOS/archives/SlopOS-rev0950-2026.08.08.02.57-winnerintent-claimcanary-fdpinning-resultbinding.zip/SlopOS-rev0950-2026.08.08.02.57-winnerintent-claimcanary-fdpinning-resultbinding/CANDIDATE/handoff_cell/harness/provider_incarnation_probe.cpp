#include <cerrno>
#include <csignal>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fcntl.h>
#include <iterator>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sched.h>
#include <unistd.h>
#include <vector>

namespace {

struct CaseRow final {
    std::string name;
    bool observed{false};
    bool expected{false};
    std::string judgment;
};
struct CounterexampleRow final {
    std::string name;
    bool reproduced{false};
    std::string defeats;
    std::string retained_law;
};
struct Child final {
    pid_t pid{-1};
    bool userns_ready{false};
};

[[noreturn]] void fail(const std::string& detail) { throw std::runtime_error(detail); }
void require(const bool value, const std::string& detail) { if (!value) fail(detail); }
[[nodiscard]] const char* tf(const bool value) noexcept { return value ? "true" : "false"; }

[[nodiscard]] std::string read_all(const std::filesystem::path& path) {
    std::ifstream stream(path, std::ios::binary);
    if (!stream) fail("open " + path.string());
    return std::string(std::istreambuf_iterator<char>(stream), {});
}

[[nodiscard]] Child spawn_userns_child() {
    int pipefd[2]{-1, -1};
    if (::pipe2(pipefd, O_CLOEXEC) != 0) fail("pipe2");
    const pid_t pid = ::fork();
    if (pid < 0) fail("fork");
    if (pid == 0) {
        ::close(pipefd[0]);
        const unsigned char status = ::unshare(CLONE_NEWUSER) == 0 ? 1U : 0U;
        (void)::write(pipefd[1], &status, 1U);
        ::close(pipefd[1]);
        if (status == 0U) _exit(41);
        for (;;) ::pause();
    }
    ::close(pipefd[1]);
    unsigned char status = 0U;
    const ssize_t got = ::read(pipefd[0], &status, 1U);
    ::close(pipefd[0]);
    return Child{pid, got == 1 && status == 1U};
}

[[nodiscard]] bool ns_identity(const pid_t pid, struct stat& out) {
    const std::string path = "/proc/" + std::to_string(pid) + "/ns/user";
    return ::stat(path.c_str(), &out) == 0;
}

[[nodiscard]] bool uid_map_observable(const pid_t pid) {
    const std::string path = "/proc/" + std::to_string(pid) + "/uid_map";
    std::ifstream stream(path);
    return static_cast<bool>(stream);
}

[[nodiscard]] bool terminate_child(const pid_t pid, bool& pidfd_opened) {
#ifdef SYS_pidfd_open
    const int pidfd = static_cast<int>(::syscall(SYS_pidfd_open, pid, 0U));
#else
    const int pidfd = -1;
#endif
    pidfd_opened = pidfd >= 0;
    bool sent = false;
#ifdef SYS_pidfd_send_signal
    if (pidfd >= 0) sent = ::syscall(SYS_pidfd_send_signal, pidfd, SIGTERM, nullptr, 0U) == 0;
#endif
    if (!sent) sent = ::kill(pid, SIGTERM) == 0;
    if (pidfd >= 0) ::close(pidfd);
    int status = 0;
    while (::waitpid(pid, &status, 0) < 0 && errno == EINTR) {}
    return sent && (WIFSIGNALED(status) || WIFEXITED(status));
}

void write_cases(const std::filesystem::path& output, const std::vector<CaseRow>& rows) {
    std::ofstream stream(output / "provider-incarnation-host-cases.tsv");
    stream << "case\tobserved\texpected\tpass\tjudgment\n";
    for (const auto& row : rows) stream << row.name << '\t' << tf(row.observed)
        << '\t' << tf(row.expected) << '\t' << tf(row.observed == row.expected)
        << '\t' << row.judgment << '\n';
}

void write_counterexamples(const std::filesystem::path& output,
                           const std::vector<CounterexampleRow>& rows) {
    std::ofstream stream(output / "provider-incarnation-host-counterexamples.tsv");
    stream << "counterexample\treproduced\tdefeats\tretained_law\n";
    for (const auto& row : rows) stream << row.name << '\t' << tf(row.reproduced)
        << '\t' << row.defeats << '\t' << row.retained_law << '\n';
}

int run(const std::filesystem::path& output,
        const std::filesystem::path& checksums,
        const std::filesystem::path& transfer_observation) {
    std::filesystem::create_directories(output);
    const std::string checksum_bytes = read_all(checksums);
    const std::string transfer_bytes = read_all(transfer_observation);
    const std::string expected_checksum =
        "ffe840ff9295808e88cce2794a18a5ac87f12a5203c8314d0bf6aa119b41bac5  etcd-v3.6.14-linux-amd64.tar.gz\n";
    const bool checksum_exact = checksum_bytes == expected_checksum;
    const bool transfer_refused =
        transfer_bytes.find("status=REFUSED\n") != std::string::npos
        && transfer_bytes.find("response_content_type=application/gzip\n") != std::string::npos
        && transfer_bytes.find("response_bytes=24915654\n") != std::string::npos
        && transfer_bytes.find("retained_bytes=0\n") != std::string::npos;

    const Child first = spawn_userns_child();
    const Child second = spawn_userns_child();
    struct stat parent_ns{}, first_ns{}, second_ns{};
    const bool parent_stat = ns_identity(::getpid(), parent_ns);
    const bool first_stat = first.userns_ready && ns_identity(first.pid, first_ns);
    const bool second_stat = second.userns_ready && ns_identity(second.pid, second_ns);
    const bool namespaces_distinct = parent_stat && first_stat && second_stat
        && (parent_ns.st_dev != first_ns.st_dev || parent_ns.st_ino != first_ns.st_ino)
        && (parent_ns.st_dev != second_ns.st_dev || parent_ns.st_ino != second_ns.st_ino)
        && (first_ns.st_dev != second_ns.st_dev || first_ns.st_ino != second_ns.st_ino);
    const bool maps_observable = first.userns_ready && second.userns_ready
        && uid_map_observable(first.pid) && uid_map_observable(second.pid);
    bool first_pidfd = false;
    bool second_pidfd = false;
    const bool first_terminated = terminate_child(first.pid, first_pidfd);
    const bool second_terminated = terminate_child(second.pid, second_pidfd);
    const bool parent_control = first_terminated && second_terminated;
    const bool pidfd_control = first_pidfd && second_pidfd && parent_control;

    std::vector<CaseRow> cases{
        {"official_checksum_product_exact", checksum_exact, true, "EXPECTED_RELEASE_DIGEST_PRESENT"},
        {"archive_transfer_observation_exact", transfer_refused, true, "ARCHIVE_PAYLOAD_REFUSED"},
        {"archive_body_present", false, false, "ZERO_ARCHIVE_BYTES_RETAINED"},
        {"archive_body_bytes_nonzero", false, false, "ADMISSION_STOPS_BEFORE_PAYLOAD"},
        {"binary_inventory_available", false, false, "NO_ARCHIVE_NO_BINARY_INVENTORY"},
        {"binary_digests_admitted", false, false, "NO_RUNTIME_SUBSTITUTION"},
        {"provider_binary_executed", false, false, "NO_EXECUTION"},
        {"provider_network_attempted", false, false, "NO_PROVIDER_NETWORK"},
        {"provider_transaction_attempted", false, false, "NO_PROVIDER_TRANSACTION"},
        {"cluster_id_observed", false, false, "NO_OPERATED_CLUSTER"},
        {"member_ids_observed", false, false, "NO_OPERATED_MEMBERS"},
        {"auth_revision_observed", false, false, "NO_OPERATED_AUTH_STORE"},
        {"hashkv_agreement_observed", false, false, "NO_MEMBER_AGREEMENT_CLAIM"},
        {"restore_lineage_observed", false, false, "NO_OPERATED_RESTORE"},
        {"independent_reopen_observed", false, false, "NO_EXTERNAL_REOPENER"},
        {"unprivileged_userns_supported", first.userns_ready && second.userns_ready, true, "TWO_USER_NAMESPACES_CREATED"},
        {"user_namespaces_distinct", namespaces_distinct, true, "NAMESPACE_COORDINATES_DIFFER"},
        {"outer_parent_reads_uid_maps", maps_observable, true, "OUTER_ROOT_OBSERVES_BOTH"},
        {"outer_parent_opens_pidfds", first_pidfd && second_pidfd, true, "OUTER_ROOT_HOLDS_PROCESS_HANDLES"},
        {"outer_parent_terminates_children", parent_control, true, "OUTER_ROOT_CONTROLS_LIFETIME"},
        {"pidfd_termination_path", pidfd_control, true, "CONTROL_IS_NOT_INDEPENDENCE"},
        {"independent_administration", false, false, "USERNS_DIVERSITY_NOT_OWNER_DIVERSITY"},
        {"external_currentness_bound", false, false, "NO_EXTERNAL_NEWEST_HISTORY"},
        {"stable_storage_contract_bound", false, false, "NO_MEDIA_CONTRACT"},
        {"portable_clone_restore_replay_excluded", false, false, "NO_EXTERNAL_FLOOR"},
        {"v13_actor_premise", false, false, "NO_ACTOR_ADMISSION"},
        {"owner_authority", false, false, "NO_CONSTITUTION"},
        {"living_law", false, false, "EPOCH_ZERO_REMAINS"},
    };
    require(cases.size() == 28U, "host case inventory");
    for (const auto& row : cases) require(row.observed == row.expected, "host case " + row.name);

    const std::vector<CounterexampleRow> counters{{
        {"checksum_without_archive", true, "checksum custody as payload admission", "archive body remains absent"},
        {"transfer_refusal_as_release_absence", true, "transport policy as upstream nonexistence", "release metadata and payload custody are separate"},
        {"local_build_substitution", true, "locally compilable source as official binary", "no substitute binary is admitted"},
        {"distinct_userns_as_independent_owner", namespaces_distinct && parent_control, "namespace coordinate as administration", "outer root creates and terminates both"},
        {"uid_map_file_as_owner_custody", maps_observable && parent_control, "readable map file as constitutional separation", "outer root observes and controls both"},
        {"second_process_as_independent_reopen", true, "process multiplicity as independence", "administrative roots remain shared"},
        {"pidfd_as_actor_identity", pidfd_control, "process handle as constitutional identity", "pidfd supplies control not governance"},
        {"release_tag_as_currentness", true, "exact tag as newest surviving provider history", "release and history currentness are separate"},
        {"zero_network_as_provider_safety", true, "absence of operation as operated profile", "host stop is not provider evidence"},
        {"metadata_as_binary_inventory", true, "archive filename as member inventory", "member bytes were never admitted"},
        {"same_root_reopener", true, "fresh process as independent appraisal", "same outer root remains one compromise domain"},
        {"same_host_storage", true, "local filesystem as external stable storage", "storage controller and rollback roots are shared"},
        {"same_network_namespace", true, "separate process as network-path diversity", "outer network administration is shared"},
        {"unobserved_cluster_id", true, "expected cluster coordinate as observed coordinate", "no provider response exists"},
        {"unobserved_hashkv", true, "planned quorum check as member agreement", "no member was contacted"},
        {"unobserved_restore", true, "documented restore rule as operated succession", "no succession ceremony occurred"},
        {"archive_refusal_retry", true, "automatic retry as admission progress", "no retry or alternate transport is authorized"},
        {"raw_url_fallback", true, "different endpoint as equivalent custody", "no unpinned mirror or source build fallback exists"},
        {"host_probe_as_authority", true, "passing mechanism probe as epoch transition", "owner constitution remains false"},
        {"synthetic_relation_as_operation", true, "pure model as provider runtime", "provider operation remains false"},
    }};
    require(counters.size() == 20U, "host counterexample inventory");
    write_cases(output, cases);
    write_counterexamples(output, counters);

    std::ofstream summary(output / "provider-incarnation-host-summary.json");
    summary << "{\n"
            << "  \"archive_body_bytes\": 0,\n"
            << "  \"archive_body_present\": false,\n"
            << "  \"authority\": false,\n"
            << "  \"cases\": " << cases.size() << ",\n"
            << "  \"checksum_product_exact\": " << tf(checksum_exact) << ",\n"
            << "  \"counterexamples_reproduced\": " << counters.size() << ",\n"
            << "  \"distinct_user_namespaces\": " << tf(namespaces_distinct) << ",\n"
            << "  \"external_currentness_bound\": false,\n"
            << "  \"independent_administration\": false,\n"
            << "  \"independent_reopen_bound\": false,\n"
            << "  \"network_attempted\": false,\n"
            << "  \"outer_parent_control\": " << tf(parent_control) << ",\n"
            << "  \"pidfd_control\": " << tf(pidfd_control) << ",\n"
            << "  \"provider_operated\": false,\n"
            << "  \"schema\": \"slopos.rev0909.provider-incarnation-host-probe.v21\",\n"
            << "  \"stable_storage_contract_bound\": false,\n"
            << "  \"status\": \"PASS\",\n"
            << "  \"transfer_policy_refused_archive\": " << tf(transfer_refused) << ",\n"
            << "  \"unprivileged_userns_supported\": " << tf(first.userns_ready && second.userns_ready) << "\n"
            << "}\n";
    std::cout << "PROVIDER_INCARNATION_PROBE=PASS cases=" << cases.size()
              << " counterexamples=" << counters.size()
              << " checksum=" << tf(checksum_exact)
              << " transfer_refused=" << tf(transfer_refused)
              << " archive_bytes=0 userns=" << tf(namespaces_distinct)
              << " outer_control=" << tf(parent_control)
              << " provider_operated=false independent=false authority=false\n";
    return 0;
}

}  // namespace

int main(const int argc, char** argv) {
    if (argc != 4) {
        std::cerr << "usage: slopos_provider_incarnation_probe OUTPUT SHA256SUMS TRANSFER_OBSERVATION\n";
        return 2;
    }
    try {
        return run(std::filesystem::path(argv[1]), std::filesystem::path(argv[2]),
                   std::filesystem::path(argv[3]));
    } catch (const std::exception& error) {
        std::cerr << "PROVIDER_INCARNATION_PROBE=FAIL detail=" << error.what() << '\n';
        return 1;
    }
}
