#pragma once

#include <cstddef>
#include <filesystem>

namespace slopos::e0::handoff_cell::harness {

struct AcquisitionActorCampaignCounts final {
    std::size_t cases{0U};
    std::size_t counterexamples{0U};
    std::size_t admissible_profiles{0U};
    std::size_t incoherent_observations{0U};
    std::size_t host_applicable_profiles{0U};
};

[[nodiscard]] AcquisitionActorCampaignCounts
run_acquisition_actor_admission_campaign(const std::filesystem::path& output);

}  // namespace slopos::e0::handoff_cell::harness
