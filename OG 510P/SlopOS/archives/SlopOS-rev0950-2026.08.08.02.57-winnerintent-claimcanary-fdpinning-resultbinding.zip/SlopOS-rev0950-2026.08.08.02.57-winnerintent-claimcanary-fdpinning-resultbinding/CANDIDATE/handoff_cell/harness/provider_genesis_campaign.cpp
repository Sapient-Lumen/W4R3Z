#include "provider_genesis_campaign.hpp"

#include "slopos/e0/handoff_cell/provider_genesis.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <memory>
#include <span>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include <openssl/evp.h>

namespace slopos::e0::handoff_cell::harness {
namespace {

struct PkeyDeleter final {
    void operator()(EVP_PKEY* value) const noexcept { EVP_PKEY_free(value); }
};
using UniquePkey = std::unique_ptr<EVP_PKEY, PkeyDeleter>;

struct MdContextDeleter final {
    void operator()(EVP_MD_CTX* value) const noexcept { EVP_MD_CTX_free(value); }
};
using UniqueMdContext = std::unique_ptr<EVP_MD_CTX, MdContextDeleter>;

struct CaseRow final {
    std::string name;
    ProviderGenesisObservation observation{};
    bool retained_counterexample{false};
    std::string judgment;
};

struct CounterexampleRow final {
    std::string name;
    bool reproduced{false};
    std::string defeats;
    std::string retained_law;
};

struct Fixture final {
    std::array<std::uint8_t, 32U> owner_seed{};
    std::array<std::uint8_t, 32U> provider_seed{};
    Ed25519PublicKey owner_public{};
    Ed25519PublicKey provider_public{};
    OwnerProviderGenesisV1 genesis{};
    EncodedOwnerProviderGenesis encoded_genesis{};
    ProviderDigest genesis_digest{};
    OwnerGenesisPin pin{};
    ProviderAppendObservationV1 append{};
    EncodedProviderAppendObservation encoded_append{};
    ExpectedProviderAppend expected{};
};

[[noreturn]] void fail(const std::string& detail) {
    throw std::runtime_error(detail);
}

void require(const bool condition, const std::string& detail) {
    if (!condition) fail(detail);
}

[[nodiscard]] std::string bool_text(const bool value) {
    return value ? "true" : "false";
}

[[nodiscard]] std::array<std::uint8_t, 32U> pattern(
    const std::uint8_t base) noexcept {
    std::array<std::uint8_t, 32U> value{};
    for (std::size_t index = 0U; index < value.size(); ++index) {
        value[index] = static_cast<std::uint8_t>(
            static_cast<unsigned int>(base)
            + static_cast<unsigned int>(index));
    }
    return value;
}

[[nodiscard]] UniquePkey private_key(
    const std::array<std::uint8_t, 32U>& seed) {
    UniquePkey key(EVP_PKEY_new_raw_private_key_ex(
        nullptr, "ED25519", nullptr, seed.data(), seed.size()));
    require(key != nullptr, "create deterministic Ed25519 key");
    return key;
}

[[nodiscard]] Ed25519PublicKey public_key(
    const std::array<std::uint8_t, 32U>& seed) {
    UniquePkey key = private_key(seed);
    Ed25519PublicKey output{};
    std::size_t length = output.size();
    require(EVP_PKEY_get_raw_public_key(
                key.get(), output.data(), &length) == 1,
            "derive Ed25519 public key");
    require(length == output.size(), "Ed25519 public key length");
    return output;
}

[[nodiscard]] Ed25519Signature sign(
    const std::array<std::uint8_t, 32U>& seed,
    const std::span<const std::uint8_t> message) {
    UniquePkey key = private_key(seed);
    UniqueMdContext context(EVP_MD_CTX_new());
    require(context != nullptr, "create signature context");
    require(EVP_DigestSignInit_ex(
                context.get(), nullptr, nullptr, nullptr, nullptr,
                key.get(), nullptr) == 1,
            "initialize Ed25519 signing");
    Ed25519Signature signature{};
    std::size_t length = signature.size();
    require(EVP_DigestSign(
                context.get(), signature.data(), &length,
                message.data(), message.size()) == 1,
            "sign Ed25519 message");
    require(length == signature.size(), "Ed25519 signature length");
    return signature;
}

[[nodiscard]] ExpectedProviderAppend expected_from(
    const ProviderAppendObservationV1& value) noexcept {
    return {
        value.owner_epoch,
        value.provider_epoch,
        value.observation_serial,
        value.generation_from,
        value.generation_to,
        value.floor_identity,
        value.predecessor_head,
        value.successor_head,
        value.spend_record,
        value.pending_entry,
    };
}

[[nodiscard]] Fixture make_fixture(
    const std::uint8_t owner_seed_base,
    const std::uint8_t provider_seed_base,
    const std::uint8_t identity_base) {
    Fixture fixture;
    fixture.owner_seed = pattern(owner_seed_base);
    fixture.provider_seed = pattern(provider_seed_base);
    fixture.owner_public = public_key(fixture.owner_seed);
    fixture.provider_public = public_key(fixture.provider_seed);
    const auto appraiser_seed = pattern(
        static_cast<std::uint8_t>(identity_base + 96U));

    fixture.genesis.owner_epoch = 7U;
    fixture.genesis.provider_epoch = 11U;
    fixture.genesis.owner_constitution = pattern(identity_base);
    fixture.genesis.provider_public_key = fixture.provider_public;
    fixture.genesis.provider_subject = pattern(
        static_cast<std::uint8_t>(identity_base + 16U));
    fixture.genesis.provider_image = pattern(
        static_cast<std::uint8_t>(identity_base + 32U));
    fixture.genesis.floor_identity = pattern(
        static_cast<std::uint8_t>(identity_base + 48U));
    fixture.genesis.endpoint_epoch = pattern(
        static_cast<std::uint8_t>(identity_base + 64U));
    fixture.genesis.appraiser_public_key = public_key(appraiser_seed);
    const auto genesis_message =
        owner_provider_genesis_signing_message(fixture.genesis);
    const auto owner_signature = sign(fixture.owner_seed, genesis_message);
    require(encode_owner_provider_genesis(
                fixture.genesis, owner_signature,
                fixture.encoded_genesis),
            "encode owner provider genesis");
    require(owner_provider_genesis_digest(
                fixture.encoded_genesis, fixture.genesis_digest),
            "digest owner provider genesis");
    fixture.pin.owner_public_key = fixture.owner_public;
    fixture.pin.exact_genesis_digest = fixture.genesis_digest;

    fixture.append.owner_epoch = fixture.genesis.owner_epoch;
    fixture.append.provider_epoch = fixture.genesis.provider_epoch;
    fixture.append.observation_serial = 31U;
    fixture.append.generation_from = 41U;
    fixture.append.generation_to = 42U;
    fixture.append.genesis_digest = fixture.genesis_digest;
    fixture.append.floor_identity = fixture.genesis.floor_identity;
    fixture.append.predecessor_head = pattern(
        static_cast<std::uint8_t>(identity_base + 112U));
    fixture.append.successor_head = pattern(
        static_cast<std::uint8_t>(identity_base + 128U));
    fixture.append.spend_record = pattern(
        static_cast<std::uint8_t>(identity_base + 144U));
    fixture.append.pending_entry = pattern(
        static_cast<std::uint8_t>(identity_base + 160U));
    const auto append_message = provider_append_signing_message(fixture.append);
    const auto provider_signature = sign(fixture.provider_seed, append_message);
    require(encode_provider_append_observation(
                fixture.append, provider_signature,
                fixture.encoded_append),
            "encode provider append observation");
    fixture.expected = expected_from(fixture.append);
    return fixture;
}

void require_disposition(const ProviderGenesisObservation& observation,
                         const ProviderGenesisDisposition expected,
                         const std::string& name) {
    require(observation.disposition == expected,
            name + " disposition="
                + provider_genesis_disposition_name(observation.disposition));
    require(observation.query_only, name + " not query only");
    require(!observation.response_authority, name + " response authority");
    require(!observation.protected_provider_state,
            name + " protected provider state");
    require(!observation.globally_unique_spend,
            name + " global spend");
}

[[nodiscard]] ProviderGenesisObservation verify(
    const Fixture& fixture,
    const EncodedOwnerProviderGenesis& genesis,
    const EncodedProviderAppendObservation& append,
    const ExpectedProviderAppend& expected,
    const OwnerGenesisPin* pin = nullptr) noexcept {
    return verify_pinned_provider_append(
        pin == nullptr ? fixture.pin : *pin,
        genesis, append, expected);
}

void add_case(std::vector<CaseRow>& rows,
              const std::string& name,
              const ProviderGenesisObservation& observation,
              const ProviderGenesisDisposition expected,
              const bool retained_counterexample,
              const std::string& judgment) {
    require_disposition(observation, expected, name);
    rows.push_back({
        name, observation, retained_counterexample, judgment});
}

[[nodiscard]] std::size_t reject_all_genesis_bit_mutations(
    const Fixture& fixture) {
    std::size_t rejected = 0U;
    for (std::size_t byte = 0U; byte < fixture.encoded_genesis.size(); ++byte) {
        for (unsigned int bit = 0U; bit < 8U; ++bit) {
            auto mutated = fixture.encoded_genesis;
            mutated[byte] ^= static_cast<std::uint8_t>(1U << bit);
            OwnerGenesisPin repinned = fixture.pin;
            require(owner_provider_genesis_digest(
                        mutated, repinned.exact_genesis_digest),
                    "digest mutated genesis");
            const auto result = verify(
                fixture, mutated, fixture.encoded_append,
                fixture.expected, &repinned);
            require(!result.exact(), "genesis bit mutation accepted");
            require(result.disposition
                        != ProviderGenesisDisposition::cryptographic_error,
                    "genesis mutation caused cryptographic error");
            ++rejected;
        }
    }
    return rejected;
}

[[nodiscard]] std::size_t reject_all_append_bit_mutations(
    const Fixture& fixture) {
    std::size_t rejected = 0U;
    for (std::size_t byte = 0U; byte < fixture.encoded_append.size(); ++byte) {
        for (unsigned int bit = 0U; bit < 8U; ++bit) {
            auto mutated = fixture.encoded_append;
            mutated[byte] ^= static_cast<std::uint8_t>(1U << bit);
            const auto result = verify(
                fixture, fixture.encoded_genesis, mutated,
                fixture.expected);
            require(!result.exact(), "append bit mutation accepted");
            require(result.disposition
                        != ProviderGenesisDisposition::cryptographic_error,
                    "append mutation caused cryptographic error");
            ++rejected;
        }
    }
    return rejected;
}

void write_cases(const std::filesystem::path& output,
                 const std::vector<CaseRow>& rows) {
    std::ofstream stream(output / "provider-genesis-cases.tsv",
                         std::ios::binary);
    require(stream.good(), "open provider-genesis-cases.tsv");
    stream
        << "case\tdisposition\texact\texact_pin\towner_signature"
           "\tprovider_signature\texpected_fields\tquery_only"
           "\tresponse_authority\tretained_counterexample\tjudgment\n";
    for (const auto& row : rows) {
        stream
            << row.name << '\t'
            << provider_genesis_disposition_name(
                   row.observation.disposition) << '\t'
            << bool_text(row.observation.exact()) << '\t'
            << bool_text(row.observation.exact_pin_match) << '\t'
            << bool_text(row.observation.owner_signature_valid) << '\t'
            << bool_text(row.observation.provider_signature_valid) << '\t'
            << bool_text(row.observation.exact_expected_fields) << '\t'
            << bool_text(row.observation.query_only) << '\t'
            << bool_text(row.observation.response_authority) << '\t'
            << bool_text(row.retained_counterexample) << '\t'
            << row.judgment << '\n';
    }
}

void write_counterexamples(
    const std::filesystem::path& output,
    const std::vector<CounterexampleRow>& rows) {
    std::ofstream stream(output / "provider-genesis-counterexamples.tsv",
                         std::ios::binary);
    require(stream.good(), "open provider-genesis-counterexamples.tsv");
    stream << "counterexample\treproduced\tdefeats\tretained_law\n";
    for (const auto& row : rows) {
        stream << row.name << '\t' << bool_text(row.reproduced) << '\t'
               << row.defeats << '\t' << row.retained_law << '\n';
    }
}

void write_summary(
    const std::filesystem::path& output,
    const ProviderGenesisCampaignCounts& counts) {
    std::ofstream stream(output / "provider-genesis-summary.json",
                         std::ios::binary);
    require(stream.good(), "open provider-genesis-summary.json");
    stream
        << "{\n"
        << "  \"append_bit_mutations_rejected\": "
        << counts.append_bit_mutations_rejected << ",\n"
        << "  \"appraiser_independently_provisioned\": false,\n"
        << "  \"authority_granted\": false,\n"
        << "  \"cases\": " << counts.cases << ",\n"
        << "  \"conflicting_signed_successors\": "
        << counts.conflicting_signed_successors << ",\n"
        << "  \"counterexamples_reproduced\": "
        << counts.counterexamples << ",\n"
        << "  \"ed25519_public_key_bytes\": 32,\n"
        << "  \"ed25519_signature_bytes\": 64,\n"
        << "  \"endpoint_parser_entrypoints_from_observation\": 0,\n"
        << "  \"exact_genesis_pin_required\": true,\n"
        << "  \"genesis_bit_mutations_rejected\": "
        << counts.genesis_bit_mutations_rejected << ",\n"
        << "  \"globally_unique_spend_proved\": false,\n"
        << "  \"owner_constitution_proved\": false,\n"
        << "  \"owner_genesis_bytes\": 320,\n"
        << "  \"owner_signature_verified\": true,\n"
        << "  \"protected_provider_state_proved\": false,\n"
        << "  \"provider_append_observation_bytes\": 320,\n"
        << "  \"provider_commit_proved\": false,\n"
        << "  \"provider_signature_verified\": true,\n"
        << "  \"replay_exact_observations\": "
        << counts.replay_exact_observations << ",\n"
        << "  \"response_authority\": false,\n"
        << "  \"schema\": "
           "\"slopos.rev0897.provider-genesis-observation-evidence.v1\",\n"
        << "  \"signature_is_spend\": false,\n"
        << "  \"stable_media_proved\": false,\n"
        << "  \"status\": \"PASS\"\n"
        << "}\n";
}

}  // namespace

ProviderGenesisCampaignCounts run_provider_genesis_campaign(
    const std::filesystem::path& output) {
    const Fixture fixture = make_fixture(0x10U, 0x40U, 0x01U);
    const Fixture alternate = make_fixture(0x10U, 0x90U, 0x21U);
    const auto alternate_owner_public = public_key(pattern(0x70U));
    const auto alternate_provider_seed = pattern(0xb0U);

    std::vector<CaseRow> cases;
    add_case(cases, "exact_pinned_chain",
             verify(fixture, fixture.encoded_genesis,
                    fixture.encoded_append, fixture.expected),
             ProviderGenesisDisposition::exact_signed_observation,
             true, "SIGNED_CHAIN_ONLY_NOT_OWNER_CONSTITUTION");

    OwnerGenesisPin wrong_owner = fixture.pin;
    wrong_owner.owner_public_key = alternate_owner_public;
    add_case(cases, "wrong_owner_key",
             verify(fixture, fixture.encoded_genesis,
                    fixture.encoded_append, fixture.expected, &wrong_owner),
             ProviderGenesisDisposition::owner_signature_invalid,
             false, "REJECT_WRONG_PINNED_OWNER_KEY");

    OwnerGenesisPin wrong_digest = fixture.pin;
    wrong_digest.exact_genesis_digest[0] ^= 0x01U;
    add_case(cases, "wrong_genesis_digest_pin",
             verify(fixture, fixture.encoded_genesis,
                    fixture.encoded_append, fixture.expected, &wrong_digest),
             ProviderGenesisDisposition::genesis_pin_mismatch,
             false, "REJECT_UNPINNED_GENESIS_BYTES");

    auto tampered_owner_signature = fixture.encoded_genesis;
    tampered_owner_signature.back() ^= 0x01U;
    OwnerGenesisPin tampered_signature_pin = fixture.pin;
    require(owner_provider_genesis_digest(
                tampered_owner_signature,
                tampered_signature_pin.exact_genesis_digest),
            "digest owner signature tamper");
    add_case(cases, "owner_signature_tamper_repin",
             verify(fixture, tampered_owner_signature,
                    fixture.encoded_append, fixture.expected,
                    &tampered_signature_pin),
             ProviderGenesisDisposition::owner_signature_invalid,
             false, "DIGEST_PIN_DOES_NOT_REPLACE_SIGNATURE");

    auto tampered_genesis_body = fixture.encoded_genesis;
    tampered_genesis_body[100] ^= 0x01U;
    OwnerGenesisPin tampered_body_pin = fixture.pin;
    require(owner_provider_genesis_digest(
                tampered_genesis_body,
                tampered_body_pin.exact_genesis_digest),
            "digest genesis body tamper");
    add_case(cases, "genesis_body_tamper_repin",
             verify(fixture, tampered_genesis_body,
                    fixture.encoded_append, fixture.expected,
                    &tampered_body_pin),
             ProviderGenesisDisposition::owner_signature_invalid,
             false, "REPINNED_TAMPER_STILL_NEEDS_OWNER_SIGNATURE");

    add_case(cases, "alternate_genesis_under_original_pin",
             verify(fixture, alternate.encoded_genesis,
                    alternate.encoded_append, alternate.expected),
             ProviderGenesisDisposition::genesis_pin_mismatch,
             true, "EXACT_PIN_SELECTS_ONE_OWNER_SIGNED_PROFILE");

    auto tampered_provider_signature = fixture.encoded_append;
    tampered_provider_signature.back() ^= 0x01U;
    add_case(cases, "provider_signature_tamper",
             verify(fixture, fixture.encoded_genesis,
                    tampered_provider_signature, fixture.expected),
             ProviderGenesisDisposition::provider_signature_invalid,
             false, "REJECT_PROVIDER_SIGNATURE_TAMPER");

    auto tampered_provider_body = fixture.encoded_append;
    tampered_provider_body[200] ^= 0x01U;
    add_case(cases, "provider_body_tamper",
             verify(fixture, fixture.encoded_genesis,
                    tampered_provider_body, fixture.expected),
             ProviderGenesisDisposition::provider_signature_invalid,
             false, "REJECT_SIGNED_BODY_TAMPER");

    ProviderAppendObservationV1 foreign_genesis = fixture.append;
    foreign_genesis.genesis_digest[0] ^= 0x01U;
    const auto foreign_genesis_signature = sign(
        fixture.provider_seed,
        provider_append_signing_message(foreign_genesis));
    EncodedProviderAppendObservation foreign_genesis_encoded{};
    require(encode_provider_append_observation(
                foreign_genesis, foreign_genesis_signature,
                foreign_genesis_encoded),
            "encode foreign genesis append");
    add_case(cases, "foreign_genesis_binding",
             verify(fixture, fixture.encoded_genesis,
                    foreign_genesis_encoded, fixture.expected),
             ProviderGenesisDisposition::genesis_binding_mismatch,
             false, "REJECT_FOREIGN_GENESIS_BINDING");

    ProviderAppendObservationV1 foreign_floor = fixture.append;
    foreign_floor.floor_identity[0] ^= 0x01U;
    const auto foreign_floor_signature = sign(
        fixture.provider_seed,
        provider_append_signing_message(foreign_floor));
    EncodedProviderAppendObservation foreign_floor_encoded{};
    require(encode_provider_append_observation(
                foreign_floor, foreign_floor_signature,
                foreign_floor_encoded),
            "encode foreign floor append");
    add_case(cases, "foreign_floor_binding",
             verify(fixture, fixture.encoded_genesis,
                    foreign_floor_encoded, fixture.expected),
             ProviderGenesisDisposition::genesis_binding_mismatch,
             false, "REJECT_FOREIGN_FLOOR_BINDING");

    ExpectedProviderAppend stale_expected = fixture.expected;
    stale_expected.generation_from = 40U;
    stale_expected.generation_to = 41U;
    add_case(cases, "stale_expected_generation",
             verify(fixture, fixture.encoded_genesis,
                    fixture.encoded_append, stale_expected),
             ProviderGenesisDisposition::expected_mismatch,
             false, "REJECT_STALE_EXPECTATION");

    ExpectedProviderAppend foreign_successor_expected = fixture.expected;
    foreign_successor_expected.successor_head[0] ^= 0x01U;
    add_case(cases, "foreign_expected_successor",
             verify(fixture, fixture.encoded_genesis,
                    fixture.encoded_append, foreign_successor_expected),
             ProviderGenesisDisposition::expected_mismatch,
             false, "REJECT_FOREIGN_EXPECTED_SUCCESSOR");

    const auto substituted_signature = sign(
        alternate_provider_seed,
        provider_append_signing_message(fixture.append));
    EncodedProviderAppendObservation substituted_append{};
    require(encode_provider_append_observation(
                fixture.append, substituted_signature,
                substituted_append),
            "encode substituted provider signature");
    add_case(cases, "substituted_provider_key_signature",
             verify(fixture, fixture.encoded_genesis,
                    substituted_append, fixture.expected),
             ProviderGenesisDisposition::provider_signature_invalid,
             false, "REJECT_PROVIDER_KEY_SUBSTITUTION");

    const auto replay = verify(
        fixture, fixture.encoded_genesis,
        fixture.encoded_append, fixture.expected);
    add_case(cases, "replay_copy_one", replay,
             ProviderGenesisDisposition::exact_signed_observation,
             true, "COPYABLE_SIGNATURE_OBSERVATION");
    add_case(cases, "replay_copy_two",
             verify(fixture, fixture.encoded_genesis,
                    fixture.encoded_append, fixture.expected),
             ProviderGenesisDisposition::exact_signed_observation,
             true, "REPLAY_VERIFIES_AGAIN_QUERY_ONLY");
    add_case(cases, "coherent_history_copy_one",
             verify(fixture, fixture.encoded_genesis,
                    fixture.encoded_append, fixture.expected),
             ProviderGenesisDisposition::exact_signed_observation,
             true, "FIRST_HISTORY_VERIFIES");
    add_case(cases, "coherent_history_copy_two",
             verify(fixture, fixture.encoded_genesis,
                    fixture.encoded_append, fixture.expected),
             ProviderGenesisDisposition::exact_signed_observation,
             true, "SECOND_HISTORY_VERIFIES");

    ProviderAppendObservationV1 conflicting = fixture.append;
    conflicting.successor_head[0] ^= 0x5aU;
    conflicting.spend_record[1] ^= 0xa5U;
    conflicting.pending_entry[2] ^= 0x3cU;
    const auto conflicting_signature = sign(
        fixture.provider_seed,
        provider_append_signing_message(conflicting));
    EncodedProviderAppendObservation conflicting_encoded{};
    require(encode_provider_append_observation(
                conflicting, conflicting_signature,
                conflicting_encoded),
            "encode conflicting provider observation");
    add_case(cases, "conflicting_signed_successor_one",
             verify(fixture, fixture.encoded_genesis,
                    fixture.encoded_append, fixture.expected),
             ProviderGenesisDisposition::exact_signed_observation,
             true, "FIRST_SIGNED_SUCCESSOR_VALID_UNDER_OWN_EXPECTATION");
    add_case(cases, "conflicting_signed_successor_two",
             verify(fixture, fixture.encoded_genesis,
                    conflicting_encoded, expected_from(conflicting)),
             ProviderGenesisDisposition::exact_signed_observation,
             true, "SECOND_SIGNED_SUCCESSOR_VALID_UNDER_OWN_EXPECTATION");

    add_case(cases, "alternate_genesis_repin",
             verify(alternate, alternate.encoded_genesis,
                    alternate.encoded_append, alternate.expected),
             ProviderGenesisDisposition::exact_signed_observation,
             true, "REPINNING_SELECTS_ALTERNATE_OWNER_SIGNED_PROFILE");

    const std::size_t genesis_mutations =
        reject_all_genesis_bit_mutations(fixture);
    const std::size_t append_mutations =
        reject_all_append_bit_mutations(fixture);
    require(genesis_mutations == kOwnerProviderGenesisBytes * 8U,
            "genesis mutation inventory");
    require(append_mutations == kProviderAppendObservationBytes * 8U,
            "append mutation inventory");

    const std::vector<CounterexampleRow> counterexamples{
        {
            "hosted_actor_self_selects_owner_pin",
            true,
            "valid_signature_chain_implies_constituted_owner",
            "pin_provisioning_and_owner_ceremony_are_external_premises",
        },
        {
            "copy_and_replay_verify_repeatedly",
            true,
            "signed_observation_is_one_use_spend",
            "verification_is_query_only_and_replayable",
        },
        {
            "coherent_histories_verify_same_bytes",
            true,
            "signature_selects_globally_newest_history",
            "external_nonrollback_state_remains_required",
        },
        {
            "one_provider_key_signs_conflicting_successors",
            true,
            "signature_proves_honest_singleton_provider_state",
            "key_possession_does_not_prove_compare_commit_or_writer_honesty",
        },
        {
            "one_owner_key_signs_alternate_geneses",
            true,
            "valid_owner_signature_uniquely_selects_current_genesis",
            "exact_pin_and_governed_rotation_select_the_admitted_statement",
        },
    };

    ProviderGenesisCampaignCounts counts;
    counts.cases = cases.size();
    counts.counterexamples = counterexamples.size();
    counts.genesis_bit_mutations_rejected = genesis_mutations;
    counts.append_bit_mutations_rejected = append_mutations;
    counts.replay_exact_observations = 4U;
    counts.conflicting_signed_successors = 2U;

    write_cases(output, cases);
    write_counterexamples(output, counterexamples);
    write_summary(output, counts);
    return counts;
}

}  // namespace slopos::e0::handoff_cell::harness
