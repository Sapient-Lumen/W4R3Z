#include "external_rollback_floor_campaign.hpp"

#include "slopos/e0/handoff_cell/external_rollback_floor.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace slopos::e0::handoff_cell::harness {
namespace {

using Field = bool ExternalRollbackFloorObservationV1::*;
constexpr std::array<Field, 58U> kFields{{
    &ExternalRollbackFloorObservationV1::profile_supplied,
    &ExternalRollbackFloorObservationV1::tpm_family_2_0,
    &ExternalRollbackFloorObservationV1::exact_profile_release_pinned,
    &ExternalRollbackFloorObservationV1::platform_incarnation_supplied,
    &ExternalRollbackFloorObservationV1::platform_incarnation_exact,
    &ExternalRollbackFloorObservationV1::ak_coordinate_supplied,
    &ExternalRollbackFloorObservationV1::ak_coordinate_exact,
    &ExternalRollbackFloorObservationV1::nv_public_supplied,
    &ExternalRollbackFloorObservationV1::nv_name_recomputed_exact,
    &ExternalRollbackFloorObservationV1::name_alg_sha256,
    &ExternalRollbackFloorObservationV1::nv_type_extend,
    &ExternalRollbackFloorObservationV1::nv_buffer_capacity_sufficient,
    &ExternalRollbackFloorObservationV1::nv_data_size_digest_exact,
    &ExternalRollbackFloorObservationV1::orderly_clear,
    &ExternalRollbackFloorObservationV1::policy_write_only,
    &ExternalRollbackFloorObservationV1::policy_read_only,
    &ExternalRollbackFloorObservationV1::policy_delete,
    &ExternalRollbackFloorObservationV1::platform_create,
    &ExternalRollbackFloorObservationV1::candidate_lacks_platform_admin,
    &ExternalRollbackFloorObservationV1::appraiser_lacks_platform_admin,
    &ExternalRollbackFloorObservationV1::witness_administration_distinct,
    &ExternalRollbackFloorObservationV1::v18_spend_record_supplied,
    &ExternalRollbackFloorObservationV1::v18_spend_record_canonical,
    &ExternalRollbackFloorObservationV1::v18_spend_record_digest_exact,
    &ExternalRollbackFloorObservationV1::witness_challenge_fresh,
    &ExternalRollbackFloorObservationV1::pre_certify_supplied,
    &ExternalRollbackFloorObservationV1::pre_certify_signature_valid,
    &ExternalRollbackFloorObservationV1::pre_certify_qualifying_data_exact,
    &ExternalRollbackFloorObservationV1::pre_certify_nv_name_exact,
    &ExternalRollbackFloorObservationV1::pre_certify_contents_exact,
    &ExternalRollbackFloorObservationV1::predecessor_generation_exact,
    &ExternalRollbackFloorObservationV1::predecessor_head_exact,
    &ExternalRollbackFloorObservationV1::append_record_encoded,
    &ExternalRollbackFloorObservationV1::append_record_canonical,
    &ExternalRollbackFloorObservationV1::append_record_binds_profile,
    &ExternalRollbackFloorObservationV1::append_record_binds_v18_spend,
    &ExternalRollbackFloorObservationV1::nv_extend_successor_exact,
    &ExternalRollbackFloorObservationV1::exactly_one_nv_extend_attempt,
    &ExternalRollbackFloorObservationV1::post_certify_supplied,
    &ExternalRollbackFloorObservationV1::post_certify_signature_valid,
    &ExternalRollbackFloorObservationV1::post_certify_qualifying_data_exact,
    &ExternalRollbackFloorObservationV1::post_certify_nv_name_exact,
    &ExternalRollbackFloorObservationV1::post_certify_contents_exact,
    &ExternalRollbackFloorObservationV1::witness_predecessor_exact,
    &ExternalRollbackFloorObservationV1::exactly_one_witness_compare_advance,
    &ExternalRollbackFloorObservationV1::witness_response_content_bound,
    &ExternalRollbackFloorObservationV1::witness_response_exact,
    &ExternalRollbackFloorObservationV1::witness_receipt_signature_valid,
    &ExternalRollbackFloorObservationV1::duplicate_query_only,
    &ExternalRollbackFloorObservationV1::ambiguous_completion_query_only,
    &ExternalRollbackFloorObservationV1::reopen_query_only,
    &ExternalRollbackFloorObservationV1::no_second_nv_extend_route,
    &ExternalRollbackFloorObservationV1::witness_outside_restorable_image,
    &ExternalRollbackFloorObservationV1::witness_recovery_root_distinct,
    &ExternalRollbackFloorObservationV1::platform_replacement_requires_succession,
    &ExternalRollbackFloorObservationV1::nv_undefine_redefine_detectable,
    &ExternalRollbackFloorObservationV1::restore_continuity_bound,
    &ExternalRollbackFloorObservationV1::portable_clone_replay_excluded,
}};

struct CaseRow final {
    std::string name;
    std::size_t true_prefix{0U};
    ExternalRollbackFloorAssessment assessment{};
    std::string judgment;
};

struct CounterexampleRow final {
    const char* name;
    const char* defeats;
    const char* retained_law;
};

[[noreturn]] void fail(const std::string& detail) {
    throw std::runtime_error(detail);
}
void require(const bool condition, const std::string& detail) {
    if (!condition) fail(detail);
}
[[nodiscard]] const char* boolean(const bool value) noexcept {
    return value ? "true" : "false";
}
[[nodiscard]] ExternalFloorDigest binding(const std::uint8_t base) noexcept {
    ExternalFloorDigest value{};
    for (std::size_t index = 0U; index < value.size(); ++index) {
        value[index] = static_cast<std::uint8_t>(
            static_cast<unsigned int>(base) + static_cast<unsigned int>(index));
    }
    return value;
}
[[nodiscard]] ExternalRollbackFloorObservationV1 prefix_observation(
    const std::size_t count) noexcept {
    ExternalRollbackFloorObservationV1 observation;
    const std::size_t bounded = count < kFields.size() ? count : kFields.size();
    for (std::size_t index = 0U; index < bounded; ++index) {
        observation.*kFields[index] = true;
    }
    return observation;
}

void write_cases(const std::filesystem::path& output,
                 const std::vector<CaseRow>& rows) {
    std::ofstream stream(output / "external-floor-cases.tsv", std::ios::binary);
    require(stream.good(), "open cases");
    stream << "case\ttrue_prefix\tdisposition\tcoherent\texact_profile"
              "\tv18_spend_bound\tprestate_certified\textend_request"
              "\tpoststate_certified\twitness_advanced\tquery_only"
              "\tcomplete_transcript\tcross_ledger_join"
              "\tquery_only_cross_ledger_recovery"
              "\texternal_floor\tv18_floor_eligible\tclone_replay_excluded"
              "\tauthority\tjudgment\n";
    for (const CaseRow& row : rows) {
        const auto& value = row.assessment;
        stream << row.name << '\t' << row.true_prefix << '\t'
               << external_rollback_floor_disposition_name(value.disposition)
               << '\t' << boolean(value.observation_coherent)
               << '\t' << boolean(value.exact_tpm_nv_profile_bound)
               << '\t' << boolean(value.v18_spend_input_bound)
               << '\t' << boolean(value.prestate_certified)
               << '\t' << boolean(value.content_bound_extend_request)
               << '\t' << boolean(value.poststate_certified)
               << '\t' << boolean(value.independent_witness_advanced)
               << '\t' << boolean(value.query_only_recovery_bound)
               << '\t' << boolean(value.complete_dual_ledger_transcript_bound)
               << '\t' << boolean(value.cross_ledger_atomic_join_bound)
               << '\t' << boolean(value.query_only_cross_ledger_recovery_bound)
               << '\t' << boolean(value.external_rollback_floor_bound)
               << '\t' << boolean(value.eligible_for_v18_external_floor_premise)
               << '\t' << boolean(value.portable_clone_replay_excluded)
               << '\t' << boolean(value.owner_authority)
               << '\t' << row.judgment << '\n';
    }
}

void write_counterexamples(const std::filesystem::path& output,
                           const std::vector<CounterexampleRow>& rows) {
    std::ofstream stream(output / "external-floor-counterexamples.tsv",
                         std::ios::binary);
    require(stream.good(), "open counterexamples");
    stream << "counterexample\treproduced\tdefeats\tretained_law\n";
    for (const CounterexampleRow& row : rows) {
        stream << row.name << "\ttrue\t" << row.defeats << '\t'
               << row.retained_law << '\n';
    }
}

}  // namespace

ExternalRollbackFloorCampaignCounts run_external_rollback_floor_campaign(
    const std::filesystem::path& output) {
    generation_journal::SpendRecordV1 spend;
    spend.owner_epoch = 7U;
    spend.constructor_epoch = 19U;
    spend.spend_serial = 31U;
    spend.generation_from = 73U;
    spend.generation_to = 74U;
    spend.owner_statement = binding(0x10U);
    spend.constructor_image = binding(0x30U);
    spend.provider_subject = binding(0x50U);
    spend.publication_receipt = binding(0x70U);
    spend.expectation_record = binding(0x90U);
    spend.operation = binding(0xB0U);
    spend.pending_result = binding(0xD0U);
    spend.predecessor_head = binding(0x20U);
    EncodedReceiptSpendRecord encoded_spend{};
    require(generation_journal::encode_spend_record(spend, encoded_spend),
            "encode V18 spend record");

    const ExternalFloorDigest profile_identity = binding(0x40U);
    const ExternalFloorDigest platform_incarnation = binding(0x60U);
    const ExternalFloorDigest nv_name = binding(0x80U);
    const ExternalFloorDigest witness_challenge = binding(0xA0U);
    const ExternalFloorDigest witness_incarnation = binding(0xC0U);
    const auto candidate = make_external_floor_record(
        encoded_spend, profile_identity, platform_incarnation, nv_name,
        witness_challenge, witness_incarnation);
    require(candidate.has_value(), "construct V19 append record");
    ExternalFloorRecordV1 decoded;
    require(decode_external_floor_record(*candidate, decoded), "decode V19 record");
    require(decoded.profile_identity == profile_identity
            && decoded.platform_incarnation == platform_incarnation
            && decoded.nv_name == nv_name
            && decoded.predecessor_head == spend.predecessor_head
            && decoded.receipt_spend_head
                == generation_journal::spend_record_head(encoded_spend),
            "V19 record cross-binding");
    const ExternalFloorDigest successor =
        tpm_nv_extend_successor(spend.predecessor_head, *candidate);
    require(!generation_journal::digest_is_zero(successor), "successor nonzero");

    std::size_t record_mutation_rejections = 0U;
    for (std::size_t byte = 0U; byte < candidate->size(); ++byte) {
        for (unsigned int bit = 0U; bit < 8U; ++bit) {
            auto changed = *candidate;
            changed[byte] ^= static_cast<std::uint8_t>(1U << bit);
            ExternalFloorRecordV1 ignored;
            require(!decode_external_floor_record(changed, ignored),
                    "single-bit V19 record mutation accepted");
            ++record_mutation_rejections;
        }
    }

    std::size_t spend_mutation_rejections = 0U;
    for (std::size_t byte = 0U; byte < encoded_spend.size(); ++byte) {
        for (unsigned int bit = 0U; bit < 8U; ++bit) {
            auto changed = encoded_spend;
            changed[byte] ^= static_cast<std::uint8_t>(1U << bit);
            const auto mutated = make_external_floor_record(
                changed, profile_identity, platform_incarnation, nv_name,
                witness_challenge, witness_incarnation);
            require(!mutated.has_value(), "single-bit V18 spend mutation accepted");
            ++spend_mutation_rejections;
        }
    }

    std::vector<CaseRow> cases;
    for (std::size_t prefix = 0U; prefix <= kFields.size(); ++prefix) {
        const auto assessment = assess_external_rollback_floor(
            prefix_observation(prefix));
        cases.push_back({"ordered_prefix_" + std::to_string(prefix), prefix,
                         assessment,
                         prefix == kFields.size()
                             ? "SYNTHETIC_COMPLETE_TRANSCRIPT_JOIN_UNPROVED"
                             : "FAIL_CLOSED_AT_FIRST_MISSING_PREMISE"});
    }
    {
        auto observation = prefix_observation(0U);
        observation.tpm_family_2_0 = true;
        cases.push_back({"incoherent_profile_gap", 0U,
                         assess_external_rollback_floor(observation),
                         "LATER_PROFILE_FACT_WITHOUT_PROFILE"});
    }
    {
        auto observation = prefix_observation(30U);
        observation.append_record_encoded = true;
        cases.push_back({"incoherent_prestate_gap", 30U,
                         assess_external_rollback_floor(observation),
                         "APPEND_BEFORE_PREDECESSOR_BINDING"});
    }
    {
        auto observation = prefix_observation(52U);
        observation.witness_recovery_root_distinct = true;
        cases.push_back({"incoherent_custody_gap", 52U,
                         assess_external_rollback_floor(observation),
                         "DISTINCT_RECOVERY_WITHOUT_EXTERNAL_WITNESS"});
    }

    const std::vector<CounterexampleRow> counterexamples{{
        {"scalar_counter_has_no_receipt_identity", "generation scalar as content-bound spend", "bind the exact V18 spend record"},
        {"nv_extend_has_no_expected_predecessor_operand", "TPM extend as compare-and-swap", "pre-certify and external witness compare are separate premises"},
        {"nv_certify_is_not_sole_writer", "signed NV contents as writer exclusivity", "authorization and administration must be closed independently"},
        {"nv_name_is_not_platform_incarnation", "same public area Name as lifetime identity", "bind platform incarnation and succession"},
        {"undefine_redefine_can_recreate_public_area", "recreated index as continuous history", "redefinition must be externally detectable"},
        {"orderly_index_can_lag_power_loss", "orderly persistence as synchronous completion", "require the non-orderly persistence profile"},
        {"platform_created_is_not_candidate_unwritable", "attribute bit as authorization proof", "reconstruct the exact policy and admin roots"},
        {"policy_delete_is_not_independent_recovery", "delete policy as succession constitution", "name recovery and replacement administration"},
        {"ak_signature_is_not_freshness", "valid attestation as newestness", "fresh challenge and witness predecessor are mandatory"},
        {"qualifying_data_is_not_content_without_exact_check", "challenge presence as semantic binding", "exact qualifyingData comparison"},
        {"post_certify_without_pre_certify_is_not_transition", "post-state attestation as predecessor proof", "bind both endpoints"},
        {"pre_and_post_endpoints_are_not_uninterrupted_custody", "endpoint equality as continuity", "close intervening writers and replacement"},
        {"one_client_attempt_is_not_one_platform_attempt", "local call count as device command count", "exact command transcript is a premise"},
        {"lost_reply_does_not_license_resend", "ambiguity as retry authority", "recover by query and certify only"},
        {"duplicate_query_is_not_global_one_use", "same-session duplicate as portable spend", "external witness custody is required"},
        {"signed_witness_receipt_is_not_external", "signature as administration separation", "key and state must be outside the restorable image"},
        {"two_signatures_can_share_one_cloned_key", "signature cardinality as independence", "constitution is about custody roots"},
        {"forked_witnesses_accept_same_predecessor", "process separation as serialization", "one non-restorable writer history"},
        {"restored_witness_replays_successor", "local durable state as rollback floor", "restore continuity must be external"},
        {"same_root_tpm_and_witness_are_one_failure_domain", "different APIs as different administration", "operator roots must be distinct"},
        {"tpm_device_presence_is_not_profile_operation", "device node as exact profile", "read public area and certify exact state"},
        {"tpm_tool_presence_is_not_profile_operation", "userspace binary as operated TPM", "commands and responses must be retained"},
        {"firmware_version_string_is_not_platform_identity", "version label as incarnation", "bind an attested platform coordinate"},
        {"ek_or_ak_name_is_not_owner_constitution", "hardware key as authority", "governance remains external"},
        {"sha256_name_algorithm_is_not_collision_proof_governance", "hash selection as complete trust", "profile selection remains a premise"},
        {"record_crc_is_not_cryptographic_binding", "CRC as receipt digest", "SHA-256 domain binding remains separate"},
        {"record_digest_is_not_nv_successor", "record hash as cumulative head", "successor is SHA256(old || record)"},
        {"same_successor_is_not_same_platform", "head equality as device identity", "bind platform incarnation and NV Name"},
        {"platform_clear_is_a_history_event", "clear as harmless maintenance", "clear/reprovision requires explicit succession"},
        {"replacement_ak_is_a_history_event", "new signer as transparent continuation", "reopen exact succession receipt"},
        {"witness_unavailable_has_no_local_fallback", "availability failure as scalar fallback license", "fail closed"},
        {"malformed_certify_has_no_nv_read_fallback", "unsigned read as attested state", "fail closed"},
        {"foreign_witness_head_has_no_overwrite_path", "conflict as repair authority", "query only and stop"},
        {"tpm_success_then_crash_fractures_ledgers", "one successful extend as completed dual-ledger edge", "TPM successor plus witness predecessor is a split state"},
        {"query_only_cannot_finish_split_edge", "observation as convergence authority", "query-only recovery may classify but cannot advance either ledger"},
        {"stale_pre_certify_does_not_guard_extend", "pre-certify as compare-and-swap", "TPM2_NV_Extend has no expected-old operand"},
        {"second_extend_consumes_first_successor", "two stale callers as one idempotent successor", "the second extend hashes from the first successor"},
        {"witness_first_only_reverses_fracture", "reordering as atomicity", "crash leaves witness successor plus TPM predecessor"},
        {"complete_transcript_is_not_recoverable_protocol", "one happy-path transcript as crash closure", "every inter-ledger cut needs a convergence theorem"},
        {"nv_buffer_capacity_is_profile_specific", "record size as universally admissible NV input", "bind TPM2B_MAX_NV_BUFFER capacity before operation"},
        {"extend_index_data_size_must_match_digest", "extend type alone as complete public profile", "bind SHA-256 digest-sized dataSize"},
        {"external_floor_is_not_provider_commit", "rollback exclusion as settlement", "provider operation remains separate"},
        {"external_floor_is_not_actor_admission", "newestness as V13 READY authority", "V18 and V13 retain other premises"},
        {"external_floor_is_not_living_law", "proof mechanism as constitution", "Epoch Zero remains"},
    }};

    require(cases.size() == 62U, "case inventory");
    require(counterexamples.size() == 44U, "counterexample inventory");
    write_cases(output, cases);
    write_counterexamples(output, counterexamples);

    const auto count = [&cases](const auto member) {
        std::size_t total = 0U;
        for (const auto& row : cases) if (row.assessment.*member) ++total;
        return total;
    };
    const std::size_t exact_profile = count(
        &ExternalRollbackFloorAssessment::exact_tpm_nv_profile_bound);
    const std::size_t v18_spend = count(
        &ExternalRollbackFloorAssessment::v18_spend_input_bound);
    const std::size_t prestate = count(
        &ExternalRollbackFloorAssessment::prestate_certified);
    const std::size_t extend_request = count(
        &ExternalRollbackFloorAssessment::content_bound_extend_request);
    const std::size_t poststate = count(
        &ExternalRollbackFloorAssessment::poststate_certified);
    const std::size_t witness = count(
        &ExternalRollbackFloorAssessment::independent_witness_advanced);
    const std::size_t query_only = count(
        &ExternalRollbackFloorAssessment::query_only_recovery_bound);
    const std::size_t complete_transcript = count(
        &ExternalRollbackFloorAssessment::complete_dual_ledger_transcript_bound);
    const std::size_t cross_ledger_join = count(
        &ExternalRollbackFloorAssessment::cross_ledger_atomic_join_bound);
    const std::size_t external = count(
        &ExternalRollbackFloorAssessment::external_rollback_floor_bound);
    require(exact_profile == 38U && v18_spend == 34U && prestate == 27U
            && extend_request == 21U && poststate == 16U && witness == 11U
            && query_only == 7U && complete_transcript == 1U
            && cross_ledger_join == 0U && external == 0U,
            "ordered profile counts");

    std::ofstream summary(output / "external-floor-summary.json", std::ios::binary);
    require(summary.good(), "open summary");
    summary << "{\n"
            << "  \"authority\": false,\n"
            << "  \"cases\": " << cases.size() << ",\n"
            << "  \"complete_transcript_profiles\": " << complete_transcript << ",\n"
            << "  \"counterexamples_reproduced\": " << counterexamples.size() << ",\n"
            << "  \"cross_ledger_join_profiles\": " << cross_ledger_join << ",\n"
            << "  \"exact_profile_profiles\": " << exact_profile << ",\n"
            << "  \"external_floor_profiles\": " << external << ",\n"
            << "  \"extend_request_profiles\": " << extend_request << ",\n"
            << "  \"network_attempted\": false,\n"
            << "  \"poststate_certified_profiles\": " << poststate << ",\n"
            << "  \"prestate_certified_profiles\": " << prestate << ",\n"
            << "  \"query_only_profiles\": " << query_only << ",\n"
            << "  \"record_bytes\": " << candidate->size() << ",\n"
            << "  \"record_mutation_rejections\": " << record_mutation_rejections << ",\n"
            << "  \"schema\": \"slopos.rev0907.external-rollback-floor-campaign.v19\",\n"
            << "  \"spend_input_mutation_rejections\": " << spend_mutation_rejections << ",\n"
            << "  \"status\": \"PASS\",\n"
            << "  \"tpm_commands_issued\": 0,\n"
            << "  \"total_mutation_rejections\": "
            << record_mutation_rejections + spend_mutation_rejections << ",\n"
            << "  \"v18_spend_profiles\": " << v18_spend << ",\n"
            << "  \"witness_advanced_profiles\": " << witness << "\n"
            << "}\n";

    return ExternalRollbackFloorCampaignCounts{
        cases.size(), counterexamples.size(), exact_profile, v18_spend,
        prestate, extend_request, poststate, witness, query_only,
        complete_transcript, cross_ledger_join, external,
        record_mutation_rejections + spend_mutation_rejections};
}

}  // namespace slopos::e0::handoff_cell::harness
