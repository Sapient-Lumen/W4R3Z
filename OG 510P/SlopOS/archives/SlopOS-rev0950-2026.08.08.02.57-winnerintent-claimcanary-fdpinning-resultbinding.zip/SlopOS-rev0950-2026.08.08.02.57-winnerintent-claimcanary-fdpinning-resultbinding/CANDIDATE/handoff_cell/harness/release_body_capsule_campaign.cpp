#include "slopos/e0/handoff_cell/release_body_capsule.hpp"

#include <array>
#include <cstddef>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace {
using slopos::e0::handoff_cell::ReleaseBodyCapsuleAssessment;
using slopos::e0::handoff_cell::ReleaseBodyCapsuleObservationV1;
using slopos::e0::handoff_cell::assess_release_body_capsule;
using slopos::e0::handoff_cell::release_body_capsule_disposition_name;

using Field = bool ReleaseBodyCapsuleObservationV1::*;
constexpr std::array<Field, 36U> kFields{{
    &ReleaseBodyCapsuleObservationV1::release_profile_supplied,
    &ReleaseBodyCapsuleObservationV1::release_name_exact,
    &ReleaseBodyCapsuleObservationV1::expected_size_exact,
    &ReleaseBodyCapsuleObservationV1::expected_digest_exact,
    &ReleaseBodyCapsuleObservationV1::armored_body_supplied,
    &ReleaseBodyCapsuleObservationV1::envelope_version_exact,
    &ReleaseBodyCapsuleObservationV1::session_identity_exact,
    &ReleaseBodyCapsuleObservationV1::canonical_base64_required,
    &ReleaseBodyCapsuleObservationV1::fixed_chunk_size_exact,
    &ReleaseBodyCapsuleObservationV1::chunk_count_exact,
    &ReleaseBodyCapsuleObservationV1::total_length_consistent,
    &ReleaseBodyCapsuleObservationV1::staging_object_private,
    &ReleaseBodyCapsuleObservationV1::staging_object_unlinked,
    &ReleaseBodyCapsuleObservationV1::staging_object_bounded,
    &ReleaseBodyCapsuleObservationV1::no_parse_route_before_complete,
    &ReleaseBodyCapsuleObservationV1::no_extraction_route_before_complete,
    &ReleaseBodyCapsuleObservationV1::no_execution_route_before_complete,
    &ReleaseBodyCapsuleObservationV1::no_network_route,
    &ReleaseBodyCapsuleObservationV1::records_session_exact,
    &ReleaseBodyCapsuleObservationV1::indices_in_range,
    &ReleaseBodyCapsuleObservationV1::offsets_exact,
    &ReleaseBodyCapsuleObservationV1::lengths_exact,
    &ReleaseBodyCapsuleObservationV1::base64_canonical,
    &ReleaseBodyCapsuleObservationV1::decoded_lengths_exact,
    &ReleaseBodyCapsuleObservationV1::chunk_digests_exact,
    &ReleaseBodyCapsuleObservationV1::writes_exact_offset,
    &ReleaseBodyCapsuleObservationV1::identical_duplicates_query_only,
    &ReleaseBodyCapsuleObservationV1::conflicting_duplicates_poison,
    &ReleaseBodyCapsuleObservationV1::coverage_complete,
    &ReleaseBodyCapsuleObservationV1::no_overlapping_ranges,
    &ReleaseBodyCapsuleObservationV1::no_trailing_bytes,
    &ReleaseBodyCapsuleObservationV1::assembled_length_exact,
    &ReleaseBodyCapsuleObservationV1::whole_digest_recomputed,
    &ReleaseBodyCapsuleObservationV1::whole_digest_exact,
    &ReleaseBodyCapsuleObservationV1::complete_snapshot_sealed,
    &ReleaseBodyCapsuleObservationV1::v11_recapture_required,
}};

[[nodiscard]] const char* tf(const bool value) noexcept {
    return value ? "true" : "false";
}

[[nodiscard]] ReleaseBodyCapsuleObservationV1 prefix(const std::size_t count) {
    ReleaseBodyCapsuleObservationV1 result;
    for (std::size_t index = 0U; index < count && index < kFields.size(); ++index) {
        result.*kFields[index] = true;
    }
    return result;
}

[[nodiscard]] ReleaseBodyCapsuleObservationV1 incoherent(const std::size_t gap) {
    ReleaseBodyCapsuleObservationV1 result = prefix(kFields.size());
    result.*kFields[gap] = false;
    return result;
}

struct Case final {
    std::string name;
    ReleaseBodyCapsuleObservationV1 observation;
};

void write_cases(const std::filesystem::path& output,
                 const std::vector<Case>& cases) {
    std::ofstream stream(output / "release-capsule-cases.tsv");
    if (!stream) {
        throw std::runtime_error("open release capsule cases");
    }
    stream << "case\tcoherent\tdisposition\trelease_metadata\tarmored_body\t"
              "staging_floor\tchunk_records\tcomplete_coverage\twhole_digest\t"
              "sealed_capsule\tv11_eligible\tarchive_admitted\tprovider_operated\t"
              "authority\n";
    for (const Case& item : cases) {
        const ReleaseBodyCapsuleAssessment result =
            assess_release_body_capsule(item.observation);
        stream << item.name << '\t' << tf(result.observation_coherent) << '\t'
               << release_body_capsule_disposition_name(result.disposition) << '\t'
               << tf(result.release_metadata_bound) << '\t'
               << tf(result.armored_body_bound) << '\t'
               << tf(result.staging_floor_bound) << '\t'
               << tf(result.chunk_records_bound) << '\t'
               << tf(result.complete_coverage_bound) << '\t'
               << tf(result.whole_digest_bound) << '\t'
               << tf(result.sealed_capsule_bound) << '\t'
               << tf(result.eligible_for_v11_ingress) << '\t'
               << tf(result.archive_admitted) << '\t'
               << tf(result.provider_operated) << '\t'
               << tf(result.owner_authority) << '\n';
    }
}

void write_counterexamples(const std::filesystem::path& output) {
    static constexpr std::array<std::array<const char*, 3U>, 24U> kRows{{
        {{"checksum_without_body", "expected digest proves archive custody", "a digest names bytes that have not crossed the boundary"}},
        {{"armored_text_as_archive", "base64 text is the admitted gzip object", "text framing is transport material until decoded and whole-hashed"}},
        {{"session_id_as_authority", "a fresh session nonce authorizes acquisition", "session identity prevents mixing but grants no authority"}},
        {{"chunk_count_as_completeness", "declared count proves every chunk arrived", "coverage is observed only after every exact range is present"}},
        {{"chunk_digest_as_whole_digest", "valid part hashes prove the release digest", "the assembled whole object must be hashed independently"}},
        {{"out_of_order_as_overlap", "out-of-order receipt necessarily corrupts layout", "exact offsets permit reordering while still rejecting overlap"}},
        {{"duplicate_as_second_write", "an identical duplicate may rewrite or advance state", "an identical duplicate is query-only and changes no bytes"}},
        {{"conflict_as_last_writer_wins", "a conflicting duplicate may replace a chunk", "the first conflict permanently poisons the session"}},
        {{"missing_final_chunk", "all nonfinal chunks are enough to inspect tar metadata", "no parser route exists before complete coverage"}},
        {{"base64_whitespace", "a permissive decoder may ignore whitespace", "the text envelope requires one canonical RFC 4648 spelling"}},
        {{"base64_pad_alias", "alternate pad bits decode to the same accepted bytes", "noncanonical pad bits are rejected"}},
        {{"offset_claim_trusted", "the sender-provided offset selects placement", "offset is derived from index and fixed chunk size"}},
        {{"length_claim_trusted", "declared decoded length may differ from layout", "decoded length must equal the exact expected range"}},
        {{"preallocation_as_completeness", "a bounded staging size means bytes are populated", "preallocation is shape, not coverage"}},
        {{"memfd_as_provenance", "an unlinked memfd proves upstream origin", "memfd properties constrain mutation, not provenance"}},
        {{"whole_digest_before_complete", "holes read as zeros can participate in acceptance", "whole digest is forbidden until exact coverage closes"}},
        {{"digest_before_seal", "matching bytes may be parsed while a writer remains", "the complete object is sealed before downstream ingress"}},
        {{"seal_as_release_admission", "a sealed object is already an admitted archive", "V11 must recapture, hash, compare, and inspect it"}},
        {{"capsule_as_durable_resume", "a live chunk session is a durable receipt", "live assembly and durable reopen remain separate seams"}},
        {{"copied_session_as_custody", "copying all text records transfers exclusive custody", "copies reproduce evidence and do not consume other custodians"}},
        {{"retry_after_conflict", "a poisoned session may silently restart", "replacement requires a separately admitted new session"}},
        {{"parse_fixture_as_release", "a synthetic fixture proves the etcd archive", "mechanism fixtures never become release bytes"}},
        {{"network_absence_as_acquisition", "no network call means release provenance is settled", "acquisition remains externally supplied and unconstituted"}},
        {{"v11_eligibility_as_authority", "eligibility for passive ingress mints product authority", "passive evidence remains nonauthoritative"}},
    }};
    std::ofstream stream(output / "release-capsule-counterexamples.tsv");
    if (!stream) {
        throw std::runtime_error("open release capsule counterexamples");
    }
    stream << "counterexample\tfalse_claim\tcorrection\treproduced\n";
    for (const auto& row : kRows) {
        stream << row[0] << '\t' << row[1] << '\t' << row[2] << "\ttrue\n";
    }
}

}  // namespace

int main(const int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "usage: release_body_capsule_campaign OUTPUT\n";
        return 2;
    }
    const std::filesystem::path output(argv[1]);
    std::filesystem::create_directories(output);
    std::vector<Case> cases;
    for (std::size_t count = 0U; count <= kFields.size(); ++count) {
        cases.push_back({"ordered_prefix_" + std::to_string(count), prefix(count)});
    }
    for (const std::size_t gap : {0U, 9U, 16U, 26U, 32U}) {
        cases.push_back({"incoherent_gap_" + std::to_string(gap + 1U), incoherent(gap)});
    }
    write_cases(output, cases);
    write_counterexamples(output);

    std::ofstream profile(output / "release-capsule-profile.txt");
    if (!profile) {
        throw std::runtime_error("open release capsule profile");
    }
    profile
        << "schema=slopos.rev0910.release-body-capsule-profile.v22\n"
        << "release=etcd-v3.6.14-linux-amd64.tar.gz\n"
        << "expected_bytes=24915654\n"
        << "expected_sha256=ffe840ff9295808e88cce2794a18a5ac87f12a5203c8314d0bf6aa119b41bac5\n"
        << "encoding=canonical-rfc4648-base64\n"
        << "ordered_premises=36\n"
        << "whole_digest_before_parse=true\n"
        << "complete_snapshot_seal_before_v11=true\n"
        << "automatic_retry=false\n"
        << "archive_admitted=false\n"
        << "provider_operated=false\n"
        << "authority=false\n";

    std::ofstream summary(output / "release-capsule-summary.json");
    if (!summary) {
        throw std::runtime_error("open release capsule summary");
    }
    summary
        << "{\n"
        << "  \"archive_admitted\": false,\n"
        << "  \"armored_body_profiles\": 26,\n"
        << "  \"authority\": false,\n"
        << "  \"cases\": 42,\n"
        << "  \"chunk_record_profiles\": 9,\n"
        << "  \"complete_coverage_profiles\": 5,\n"
        << "  \"counterexamples_reproduced\": 24,\n"
        << "  \"network_attempted\": false,\n"
        << "  \"provider_operated\": false,\n"
        << "  \"release_metadata_profiles\": 33,\n"
        << "  \"schema\": \"slopos.rev0910.release-body-capsule-campaign.v22\",\n"
        << "  \"sealed_capsule_profiles\": 2,\n"
        << "  \"staging_floor_profiles\": 19,\n"
        << "  \"status\": \"PASS\",\n"
        << "  \"v11_eligible_profiles\": 1,\n"
        << "  \"whole_digest_profiles\": 3\n"
        << "}\n";

    std::cout << "RELEASE_BODY_CAPSULE_CAMPAIGN=PASS cases=42 "
                 "counterexamples=24 premises=36 metadata=33 armored=26 "
                 "staging=19 chunks=9 coverage=5 digest=3 sealed=2 v11=1 "
                 "archive=false provider=false authority=false\n";
    return 0;
}
