#pragma once

#include <cstdint>

namespace slopos::e0::handoff_cell {

// V16 is a pure ordered relation for one deliberately tiny static actor
// fixture. It separates a same-root hosted user-executable mapping and syscall
// floor from kernel-provided executable surfaces, independent appraisal, V14
// composition, authority, and living law.
enum class StaticActorDisposition : std::uint8_t {
    observation_incoherent,
    profile_unavailable,
    v15_exec_input_unavailable,
    elf_profile_cross_binding_unproved,
    elf_architecture_rejected,
    elf_type_rejected,
    program_header_table_rejected,
    entrypoint_rejected,
    interpreter_present,
    dynamic_segment_present,
    executable_load_missing,
    writable_executable_load_rejected,
    executable_stack_rejected,
    single_threaded_child_unproved,
    file_table_custody_unproved,
    address_space_custody_unproved,
    filesystem_context_custody_unproved,
    empty_root_custody_unproved,
    root_path_not_unlinked,
    pre_exec_identity_rejected,
    supplementary_groups_rejected,
    capability_floor_rejected,
    no_new_privs_missing,
    personality_floor_rejected,
    inherited_seccomp_stack_present,
    tracer_unavailable,
    seccomp_entry_unobserved,
    seccomp_architecture_rejected,
    seccomp_operation_rejected,
    seccomp_flags_rejected,
    seccomp_program_snapshot_unavailable,
    seccomp_instruction_count_mismatch,
    seccomp_instruction_mismatch,
    seccomp_install_failed,
    installed_seccomp_stack_mismatch,
    later_policy_install_unexcluded,
    exec_event_not_linked,
    first_instruction_hold_unproved,
    mapping_inventory_unavailable,
    candidate_mapping_mismatch,
    foreign_runtime_mapping_present,
    kernel_mapping_set_rejected,
    writable_executable_mapping_present,
    descriptor_inventory_rejected,
    exec_descriptor_not_closed,
    post_exec_root_custody_unproved,
    absolute_path_exec_route_open,
    later_exec_or_mapping_route_open,
    descriptor_acquisition_route_open,
    process_peer_creation_route_open,
    network_or_async_route_open,
    post_exec_policy_behavior_mismatch,
    challenge_order_rejected,
    challenge_response_rejected,
    appraiser_unavailable,
    appraiser_not_independent,
    installed_filter_not_independently_reconstructed,
    kernel_executable_surfaces_unbound,
    pidfd_coordinate_unavailable,
    v14_dossier_unavailable,
    exec_epoch_custody_unproved,
    static_actor_and_dossier_bound,
};

// Ordered prefix. Once one premise is false, every later premise must remain
// false. The first 53 fields may establish only a same-root hosted envelope.
// The vDSO/vsyscall set is merely enumerated there; its object identity and
// semantics remain outside the release object and must be appraised separately.
struct StaticActorObservationV1 final {
    bool profile_supplied{false};
    bool v15_exec_input_object_bound{false};
    bool elf_profile_cross_bound_to_v15_object{false};
    bool elf64_little_endian_x86_64{false};
    bool elf_type_exact{false};
    bool program_header_table_bounded{false};
    bool entrypoint_inside_executable_load{false};
    bool pt_interp_absent{false};
    bool pt_dynamic_absent{false};
    bool executable_load_present{false};
    bool writable_executable_load_absent{false};
    bool executable_gnu_stack_absent{false};
    bool child_single_threaded{false};
    bool child_file_table_private{false};
    bool child_address_space_private{false};
    bool child_filesystem_context_private{false};
    bool pre_exec_root_and_cwd_same_empty_directory{false};
    bool pre_exec_root_path_unlinked{false};
    bool pre_exec_identity_nonroot{false};
    bool pre_exec_supplementary_groups_empty{false};
    bool pre_exec_capability_sets_empty{false};
    bool pre_exec_no_new_privs{false};
    bool pre_exec_read_implies_exec_absent{false};
    bool inherited_seccomp_stack_empty{false};
    bool tracer_prearmed{false};
    bool seccomp_entry_observed{false};
    bool seccomp_arch_exact{false};
    bool seccomp_operation_exact{false};
    bool seccomp_flags_exact{false};
    bool seccomp_program_snapshot_copied_at_entry{false};
    bool seccomp_instruction_count_exact{false};
    bool seccomp_instructions_exact{false};
    bool seccomp_install_succeeded{false};
    bool installed_seccomp_stack_exact_one{false};
    bool no_later_policy_install_before_exec{false};
    bool exec_event_completes_v15_entry{false};
    bool tracee_held_before_first_user_instruction{false};
    bool initial_mapping_inventory_complete{false};
    bool candidate_executable_mappings_match{false};
    bool interpreter_and_shared_object_mappings_absent{false};
    bool declared_kernel_executable_mappings_only{false};
    bool writable_executable_mappings_absent{false};
    bool post_exec_descriptor_inventory_exact{false};
    bool exec_descriptor_closed_on_exec{false};
    bool post_exec_root_and_cwd_same_held_directory{false};
    bool absolute_path_exec_canary_confined{false};
    bool later_exec_and_executable_mapping_routes_blocked{false};
    bool descriptor_acquisition_and_rights_import_blocked{false};
    bool process_peer_creation_blocked{false};
    bool network_and_async_bypass_blocked{false};
    bool post_exec_policy_behavior_exact{false};
    bool challenge_generated_after_held_appraisal{false};
    bool challenge_response_exact{false};
    bool appraiser_process_separate{false};
    bool appraiser_administration_root_distinct{false};
    bool installed_filter_independently_reconstructed{false};
    bool kernel_executable_surfaces_independently_bound{false};
    bool pidfd_get_info_coordinate_exact{false};
    bool v14_dossier_cross_bound{false};
    bool exec_epoch_held_through_v13_admission{false};
};

struct StaticActorAssessment final {
    StaticActorDisposition disposition{
        StaticActorDisposition::observation_incoherent};
    bool observation_coherent{false};
    bool static_exec_profile_exact{false};
    bool pre_exec_filesystem_floor_bound{false};
    bool pre_exec_privilege_floor_bound{false};
    // Same-root observation theorem only: the tracer captured the installation
    // input at syscall entry, observed success and the stack count, and exercised
    // named behavior.  It does not identify the bytes the kernel ultimately
    // copied from mutable tracee memory.
    bool pre_exec_seccomp_installation_observation_bound{false};
    bool installed_seccomp_program_bound{false};
    bool held_initial_user_executable_mapping_set_bound{false};
    bool post_exec_substitution_floor_bound{false};
    bool hosted_static_actor_envelope_bound{false};
    bool independent_appraisal_bound{false};
    bool eligible_for_v15_runtime_and_preexec_evidence{false};
    bool v14_dossier_bound_to_static_actor{false};
    bool eligible_for_v13_actor_premise{false};
    // Mandatory nonclaim: the relation never identifies every kernel mapping,
    // mutable datum, future instruction, administrator, or external effect.
    bool complete_process_image_bound{false};
    bool source_provenance_proved{false};
    bool network_attempted{false};
    bool ready_sent{false};
    bool rights_imported{false};
    bool candidate_created{false};
    bool candidate_bytes_read{false};
    bool archive_acquired{false};
    bool archive_admitted{false};
    bool provider_operated{false};
    bool owner_authority{false};
    bool living_law{false};
};

[[nodiscard]] StaticActorAssessment assess_static_actor_confinement(
    const StaticActorObservationV1& observation) noexcept;
[[nodiscard]] const char* static_actor_disposition_name(
    StaticActorDisposition value) noexcept;

}  // namespace slopos::e0::handoff_cell
