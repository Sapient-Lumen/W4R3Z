#pragma once

#include "slopos/e0/generation_journal/record.hpp"
#include "slopos/e0/handoff_cell/endpoint_claim.hpp"

#include <cstdint>
#include <span>

namespace slopos::e0::handoff_cell {

// Provider responses are deliberately narrow observations. The provider is a
// host-selected Epoch-Zero premise: this interface does not authenticate it,
// protect its writer, make its state nonrollback, or grant its reply authority.
enum class ProviderSubmitDisposition : std::uint8_t {
    exact_record,
    no_return,
    unavailable,
    malformed_return,
};

struct ProviderSubmitReply final {
    ProviderSubmitDisposition disposition{
        ProviderSubmitDisposition::unavailable};
    generation_journal::EncodedRecord encoded{};
};

enum class ProviderQueryDisposition : std::uint8_t {
    exact_record,
    exact_unused,
    unavailable,
    malformed_return,
};

struct ProviderQueryReply final {
    ProviderQueryDisposition disposition{ProviderQueryDisposition::unavailable};
    generation_journal::EncodedRecord encoded{};
};

// The adapter owns neither provider identity nor provider state. A concrete
// provider may be remote, local, scripted, malicious, rollbackable, or
// unavailable. Only the client-side call ordering and result interpretation are
// proved here.
class HostedSettlementProvider {
public:
    HostedSettlementProvider() = default;
    HostedSettlementProvider(const HostedSettlementProvider&) = delete;
    HostedSettlementProvider& operator=(const HostedSettlementProvider&) = delete;
    virtual ~HostedSettlementProvider() = default;

    [[nodiscard]] virtual ProviderSubmitReply submit_exact(
        const generation_journal::EncodedRecord& expected_pending) noexcept = 0;

    [[nodiscard]] virtual ProviderQueryReply query_exact(
        const generation_journal::EncodedRecord& expected_pending) noexcept = 0;
};

enum class SettlementDisposition : std::uint8_t {
    effect,
    no_effect,
    uncertain,
    fail_stop,
    malformed_request,
    claim_missing_or_spent,
};

enum class SettlementEvidence : std::uint8_t {
    submit_exact_record,
    submit_no_return,
    submit_unavailable,
    submit_malformed,
    query_exact_record,
    query_exact_unused,
    query_unavailable,
    query_malformed,
    request_rejected,
    claim_absent,
    invalid_expected_pending,
    foreign_or_invalid_result,
};

// Copyable settlement evidence is intentionally powerless. It can report the
// hosted interpretation of one provider interaction, but cannot invoke,
// resubmit, retry, publish, compensate, or mint another claim.
struct SettlementObservation final {
    SettlementDisposition disposition{SettlementDisposition::uncertain};
    SettlementEvidence evidence{SettlementEvidence::query_unavailable};
    bool request_examined{false};
    bool provider_submit_called{false};
    bool provider_query_called{false};
    bool exact_operation_bound{false};
    bool query_only{true};
    bool response_authority{false};
    bool retry_authority{false};

    [[nodiscard]] constexpr bool effect_confirmed() const noexcept {
        return disposition == SettlementDisposition::effect;
    }

    [[nodiscard]] constexpr bool no_effect_confirmed() const noexcept {
        return disposition == SettlementDisposition::no_effect;
    }

    [[nodiscard]] constexpr bool bounded_uncertain() const noexcept {
        return disposition == SettlementDisposition::uncertain;
    }
};

class HostedSettlement final {
public:
    // Burns the existing ClaimedPending before inspecting request length or
    // fields. An exact request produces exactly one call to submit_exact. Every
    // returned observation is query-only; a no-return, unavailable, malformed,
    // or foreign response is uncertainty rather than permission to replay.
    [[nodiscard]] static SettlementObservation settle_exact(
        ClaimedPending&& claim,
        std::span<const std::uint8_t> request,
        HostedSettlementProvider& provider) noexcept;

    // Recovery/reopen path. It can issue one exact query and refine evidence;
    // it has no submission path and never mints first dispatch authority.
    [[nodiscard]] static SettlementObservation reconcile_exact(
        const generation_journal::EncodedRecord& expected_pending,
        HostedSettlementProvider& provider) noexcept;
};

[[nodiscard]] const char* provider_submit_name(
    ProviderSubmitDisposition value) noexcept;
[[nodiscard]] const char* provider_query_name(
    ProviderQueryDisposition value) noexcept;
[[nodiscard]] const char* settlement_name(
    SettlementDisposition value) noexcept;
[[nodiscard]] const char* settlement_evidence_name(
    SettlementEvidence value) noexcept;

}  // namespace slopos::e0::handoff_cell
