#pragma once

#include "slopos/e0/handoff_cell/provider_endpoint.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <optional>

#include <sys/types.h>

namespace slopos::e0::handoff_cell {

inline constexpr std::size_t kProviderExpectationBytes = 96U;
inline constexpr std::size_t kProviderExpectationBindingBytes = 32U;

// Parsed contents of one fixed, sealed, externally supplied process
// expectation.  The opaque binding has no meaning inside the hosted cell: it
// is retained only so that a future owner-admitted constructor can bind this
// process observation to owner law without changing the byte shape again.
struct ProviderExpectationView final {
    std::uint64_t serial{0U};
    uid_t provider_uid{0U};
    gid_t provider_gid{0U};
    uid_t query_uid{0U};
    gid_t query_gid{0U};
    EndpointProcessIdentity process{};
    std::array<std::uint8_t, kProviderExpectationBindingBytes> owner_binding{};
};

struct ExpectedProviderConnectResult;

// Move-only custody of a sealed expectation record and the pidfd whose pidfs
// identity that record names.  adopt_sealed() takes ownership of both supplied
// descriptors on success and failure.  It verifies fixed bytes, exact seals,
// close-on-exec state, addressed principals, a live pidfd-shaped object, and
// record/pidfd identity agreement.  These checks prove an immutable
// externally supplied observation shape; they do not prove who minted it or
// that any owner authorized the named process.
class ExpectedProviderProcess final {
public:
    ExpectedProviderProcess(const ExpectedProviderProcess&) = delete;
    ExpectedProviderProcess& operator=(const ExpectedProviderProcess&) = delete;
    ExpectedProviderProcess(ExpectedProviderProcess&& other) noexcept;
    ExpectedProviderProcess& operator=(ExpectedProviderProcess&& other) noexcept;
    ~ExpectedProviderProcess();

    [[nodiscard]] static std::optional<ExpectedProviderProcess> adopt_sealed(
        int record_fd, int pidfd,
        uid_t expected_query_uid, gid_t expected_query_gid,
        uid_t expected_provider_uid, gid_t expected_provider_gid,
        int& error_number) noexcept;

    [[nodiscard]] const ProviderExpectationView& view() const noexcept {
        return view_;
    }

private:
    friend struct ExpectedProviderConnectResult;
    friend ExpectedProviderConnectResult connect_fixed_endpoint_expected(
        int, uid_t, uid_t, uid_t, gid_t,
        ExpectedProviderProcess, int&) noexcept;

    ExpectedProviderProcess(
        int record_fd, int pidfd,
        const ProviderExpectationView& view) noexcept
        : record_fd_(record_fd), pidfd_(pidfd), view_(view), fresh_(true) {}

    int record_fd_{-1};
    int pidfd_{-1};
    ProviderExpectationView view_{};
    bool fresh_{false};
};

enum class ExpectedProviderConnectDisposition : std::uint8_t {
    connected_expected,
    expectation_invalid,
    connect_failed,
    process_mismatch,
};

// The query actor always consumes its two expectation descriptor slots before
// connect_fixed_endpoint() creates the transport socket. Prior duplicates in
// another slot or process are intentionally not revoked by this local burn.  A mismatch closes the new connection before any
// request bytes can be sent.  The returned object never exposes either the
// supplied pidfd or the connection's retained peer pidfd.
struct ExpectedProviderConnectResult final {
    ExpectedProviderConnectDisposition disposition{
        ExpectedProviderConnectDisposition::expectation_invalid};
    int error_number{0};
    std::uint64_t expectation_serial{0U};
    EndpointProcessIdentity expected_process{};
    EndpointProcessIdentity observed_process{};
    bool expectation_spent_before_connect{false};
    std::optional<EndpointConnection> connection{};

    [[nodiscard]] bool connected() const noexcept {
        return disposition
                == ExpectedProviderConnectDisposition::connected_expected
            && connection.has_value();
    }
};

[[nodiscard]] ExpectedProviderConnectResult connect_fixed_endpoint_expected(
    int public_directory_fd, uid_t expected_query_uid,
    uid_t expected_publisher_uid, uid_t expected_provider_uid,
    gid_t expected_provider_gid, ExpectedProviderProcess expectation,
    int& error_number) noexcept;

[[nodiscard]] const char* expected_provider_connect_name(
    ExpectedProviderConnectDisposition value) noexcept;

}  // namespace slopos::e0::handoff_cell
