#pragma once

#include "slopos/e0/generation_journal/record.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>

#include <sys/types.h>

namespace slopos::e0::handoff_cell {

class HostedSettlement;

inline constexpr char kClaimedLeaf[] = "claimed";
inline constexpr std::size_t kEndpointRequestBytes = 96U;
using EndpointRequest = std::array<std::uint8_t, kEndpointRequestBytes>;

enum class EndpointClaimDisposition : std::uint8_t {
    claimed_exact,
    claimed_exact_sync_uncertain,
    already_claimed_exact,
    pending_missing,
    not_regular,
    wrong_size,
    alias_detected,
    mutable_or_wrong_owner,
    exact_mismatch,
    decode_rejected,
    wrong_record_kind,
    unsupported,
    io_error,
};

// Copyable report only. It deliberately carries no parser eligibility.
struct EndpointClaimObservation final {
    EndpointClaimDisposition disposition{EndpointClaimDisposition::io_error};
    int error_number{0};
    std::uint64_t link_count{0U};
    bool namespace_claimed{false};
    bool query_only{true};
    bool response_authority{false};

    // True only when this observation corresponds to an internal parser token.
    // A completed namespace cut with failed directory synchronization remains
    // claimed but query-only and can never report fresh parser eligibility.
    [[nodiscard]] constexpr bool fresh_exact() const noexcept {
        return disposition == EndpointClaimDisposition::claimed_exact;
    }

    [[nodiscard]] constexpr bool synchronization_uncertain() const noexcept {
        return disposition
            == EndpointClaimDisposition::claimed_exact_sync_uncertain;
    }
};

// Process-local one-use bridge from a fresh fixed namespace claim to the sole
// semantic parser. It is not globally unique authority and is not a theorem
// about rollback, stable media, aliases, writers, or provider provenance.
class ClaimedPending final {
public:
    ClaimedPending(const ClaimedPending&) = delete;
    ClaimedPending& operator=(const ClaimedPending&) = delete;
    ClaimedPending(ClaimedPending&& other) noexcept;
    ClaimedPending& operator=(ClaimedPending&& other) noexcept;
    ~ClaimedPending();

    [[nodiscard]] bool available() const noexcept { return available_; }

private:
    friend class EndpointClaimCell;
    friend class PayloadAfterClaim;
    explicit ClaimedPending(
        const generation_journal::EncodedRecord& encoded) noexcept;
    [[nodiscard]] std::optional<generation_journal::EncodedRecord>
    consume() noexcept;

    generation_journal::EncodedRecord encoded_{};
    bool available_{false};
};

struct EndpointClaimAttempt final {
    EndpointClaimObservation observation{};
    std::optional<ClaimedPending> fresh{};

    EndpointClaimAttempt() = default;
    EndpointClaimAttempt(const EndpointClaimAttempt&) = delete;
    EndpointClaimAttempt& operator=(const EndpointClaimAttempt&) = delete;
    EndpointClaimAttempt(EndpointClaimAttempt&&) noexcept = default;
    EndpointClaimAttempt& operator=(EndpointClaimAttempt&&) noexcept = default;
};

enum class PayloadDisposition : std::uint8_t {
    exact_request,
    malformed_request,
    claim_missing_or_spent,
};

struct PayloadParseResult final {
    PayloadDisposition disposition{PayloadDisposition::claim_missing_or_spent};
    bool payload_examined{false};
    bool effect_performed{false};
    bool response_authority{false};

    [[nodiscard]] constexpr bool exact() const noexcept {
        return disposition == PayloadDisposition::exact_request;
    }
};

// Hosted fixed-directory adapter. The only mutation is the fixed
// pending -> claimed RENAME_NOREPLACE cut. The leaf is not opened, read,
// compared, or decoded until after that syscall returns success.
class EndpointClaimCell final {
public:
    EndpointClaimCell(const EndpointClaimCell&) = delete;
    EndpointClaimCell& operator=(const EndpointClaimCell&) = delete;
    EndpointClaimCell(EndpointClaimCell&& other) noexcept;
    EndpointClaimCell& operator=(EndpointClaimCell&& other) noexcept;
    ~EndpointClaimCell();

    [[nodiscard]] static std::optional<EndpointClaimCell>
    retain_host_cell_directory(int directory_fd, uid_t expected_owner,
                               int& error_number) noexcept;

    [[nodiscard]] EndpointClaimAttempt claim_pending_exact(
        const generation_journal::EncodedRecord& expected) noexcept;

    // Query-only duplicate/recovery path. This method cannot mint a token.
    [[nodiscard]] EndpointClaimObservation observe_claimed_exact(
        const generation_journal::EncodedRecord& expected) const noexcept;

private:
    EndpointClaimCell(int directory_fd, uid_t expected_owner) noexcept
        : directory_fd_(directory_fd), expected_owner_(expected_owner) {}

    int directory_fd_{-1};
    uid_t expected_owner_{0U};
};

class PayloadAfterClaim final {
public:
    // Eligibility is consumed before request length, magic, or fields are read.
    [[nodiscard]] static PayloadParseResult parse_exact(
        ClaimedPending&& claim,
        std::span<const std::uint8_t> request) noexcept;

private:
    friend class HostedSettlement;

    // The hosted settlement adapter needs the exact consumed pending bytes,
    // but they never become a public dispatch ticket. The claim is burned
    // before request length or content is inspected, exactly as in parse_exact.
    [[nodiscard]] static PayloadParseResult parse_exact_impl(
        ClaimedPending&& claim,
        std::span<const std::uint8_t> request,
        generation_journal::EncodedRecord* consumed) noexcept;
};

[[nodiscard]] const char* endpoint_claim_name(
    EndpointClaimDisposition value) noexcept;
[[nodiscard]] const char* payload_disposition_name(
    PayloadDisposition value) noexcept;

}  // namespace slopos::e0::handoff_cell
