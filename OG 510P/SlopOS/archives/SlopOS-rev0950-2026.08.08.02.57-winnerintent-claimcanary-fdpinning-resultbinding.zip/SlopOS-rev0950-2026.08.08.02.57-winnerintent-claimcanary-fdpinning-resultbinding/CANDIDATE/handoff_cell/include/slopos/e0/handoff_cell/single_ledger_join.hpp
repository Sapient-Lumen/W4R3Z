#pragma once

#include "slopos/e0/handoff_cell/appraiser_receipt_spend.hpp"
#include "slopos/e0/handoff_cell/etcd_history_profile.hpp"

#include <cstdint>

namespace slopos::e0::handoff_cell {

// V20 is an ordered proof relation for one provider-native transaction that
// compares the exact predecessor and atomically writes the new head, the exact
// V18 spend record, and the exact pending entry in one serialization history.
// The relation has no transport, socket, retry, provider, or authority path.
enum class SingleLedgerJoinDisposition : std::uint8_t {
    observation_incoherent,
    profile_unavailable,
    release_pin_unproved,
    provider_incarnation_unavailable,
    cluster_identity_mismatch,
    member_set_mismatch,
    client_ca_mismatch,
    application_principal_mismatch,
    administration_inventory_open,
    auth_revision_mismatch,
    namespace_not_exclusive,
    v18_spend_unavailable,
    v18_spend_noncanonical,
    v18_spend_digest_mismatch,
    edge_generation_mismatch,
    edge_predecessor_mismatch,
    edge_successor_mismatch,
    operation_binding_mismatch,
    floor_identity_mismatch,
    pending_entry_mismatch,
    key_derivation_mismatch,
    head_compare_mismatch,
    floor_compare_mismatch,
    spend_absence_compare_missing,
    entry_absence_compare_missing,
    head_write_mismatch,
    spend_write_mismatch,
    entry_write_mismatch,
    transaction_attempt_count_rejected,
    result_observation_unavailable,
    response_cluster_mismatch,
    response_member_mismatch,
    response_auth_revision_mismatch,
    transaction_revision_invalid,
    linearizable_readback_required,
    joined_head_mismatch,
    joined_spend_mismatch,
    joined_entry_mismatch,
    joined_revision_mismatch,
    duplicate_not_query_only,
    ambiguity_not_query_only,
    reopen_not_query_only,
    resubmit_route_open,
    restore_replacement_undetectable,
    administration_not_distinct,
    external_currentness_unproved,
    stable_storage_contract_unproved,
    external_rollback_floor_premise,
};

// The first 39 observations are sufficient only for the bounded
// single-serialization atomic-join theorem.  Query-only recovery closes at 43.
// The final four observations are independent provider-custody premises; they
// are not supplied by a local database, a self-hosted cluster, or this type.
struct SingleLedgerJoinObservationV1 final {
    bool profile_supplied{false};                         // 01
    bool exact_release_pinned{false};                    // 02
    bool provider_incarnation_supplied{false};           // 03
    bool cluster_identity_exact{false};                  // 04
    bool member_set_exact{false};                        // 05
    bool client_ca_exact{false};                         // 06
    bool application_principal_exact{false};             // 07
    bool administration_inventory_exact{false};          // 08
    bool auth_revision_exact{false};                     // 09
    bool namespace_exclusive{false};                     // 10
    bool v18_spend_supplied{false};                      // 11
    bool v18_spend_canonical{false};                     // 12
    bool v18_spend_digest_exact{false};                  // 13
    bool edge_generation_exact{false};                   // 14
    bool edge_predecessor_exact{false};                  // 15
    bool edge_successor_exact{false};                    // 16
    bool operation_binding_exact{false};                 // 17
    bool floor_identity_exact{false};                    // 18
    bool pending_entry_exact{false};                     // 19
    bool key_derivation_exact{false};                    // 20
    bool head_compare_exact{false};                      // 21
    bool floor_compare_exact{false};                     // 22
    bool spend_absence_compare_exact{false};             // 23
    bool entry_absence_compare_exact{false};             // 24
    bool success_head_write_exact{false};                // 25
    bool success_spend_write_exact{false};               // 26
    bool success_entry_write_exact{false};               // 27
    bool exactly_one_transaction_attempt{false};         // 28
    bool result_observation_supplied{false};              // 29
    bool response_cluster_exact{false};                  // 30
    bool response_member_admitted{false};                // 31
    bool response_auth_revision_exact{false};            // 32
    bool transaction_revision_nonzero{false};            // 33
    bool linearizable_readback{false};                   // 34
    bool joined_head_exact{false};                       // 35
    bool joined_spend_exact{false};                      // 36
    bool joined_entry_exact{false};                      // 37
    bool joined_writes_share_revision{false};            // 38
    bool duplicate_query_only{false};                    // 39
    bool ambiguous_completion_query_only{false};         // 40
    bool reopen_query_only{false};                       // 41
    bool no_resubmit_route{false};                       // 42
    bool restore_replacement_detectable{false};          // 43
    bool administration_root_distinct{false};            // 44
    bool external_currentness_bound{false};              // 45
    bool stable_storage_contract_bound{false};           // 46
};

struct SingleLedgerJoinAssessment final {
    SingleLedgerJoinDisposition disposition{
        SingleLedgerJoinDisposition::observation_incoherent};
    bool observation_coherent{false};
    bool exact_provider_profile_bound{false};
    bool v18_spend_input_bound{false};
    bool exact_transaction_plan_bound{false};
    bool one_transaction_attempt_bound{false};
    bool single_ledger_atomic_join_bound{false};
    bool query_only_recovery_bound{false};
    bool restore_lineage_bound{false};
    bool administration_distinct{false};
    bool external_currentness_bound{false};
    bool external_rollback_floor_bound{false};
    bool eligible_for_v18_external_floor_premise{false};
    bool provider_operated{false};
    bool network_attempted{false};
    bool ready_sent{false};
    bool rights_imported{false};
    bool owner_authority{false};
    bool living_law{false};
};

[[nodiscard]] SingleLedgerJoinAssessment assess_single_ledger_join(
    const SingleLedgerJoinObservationV1& observation) noexcept;
[[nodiscard]] const char* single_ledger_join_disposition_name(
    SingleLedgerJoinDisposition value) noexcept;

}  // namespace slopos::e0::handoff_cell
