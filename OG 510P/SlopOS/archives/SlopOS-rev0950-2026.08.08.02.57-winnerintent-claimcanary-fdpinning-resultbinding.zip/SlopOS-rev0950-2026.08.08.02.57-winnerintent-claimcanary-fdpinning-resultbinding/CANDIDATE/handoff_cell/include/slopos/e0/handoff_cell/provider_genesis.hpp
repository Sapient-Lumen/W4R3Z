#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <span>

namespace slopos::e0::handoff_cell {

using ProviderDigest = std::array<std::uint8_t, 32U>;
using Ed25519PublicKey = std::array<std::uint8_t, 32U>;
using Ed25519Signature = std::array<std::uint8_t, 64U>;

inline constexpr std::size_t kOwnerProviderGenesisUnsignedBytes = 256U;
inline constexpr std::size_t kOwnerProviderGenesisBytes = 320U;
inline constexpr std::size_t kProviderAppendUnsignedBytes = 256U;
inline constexpr std::size_t kProviderAppendObservationBytes = 320U;
inline constexpr std::size_t kProviderSigningDomainBytes = 32U;

using EncodedOwnerProviderGenesis =
    std::array<std::uint8_t, kOwnerProviderGenesisBytes>;
using EncodedProviderAppendObservation =
    std::array<std::uint8_t, kProviderAppendObservationBytes>;
using OwnerProviderGenesisSigningMessage = std::array<
    std::uint8_t,
    kProviderSigningDomainBytes + kOwnerProviderGenesisUnsignedBytes>;
using ProviderAppendSigningMessage = std::array<
    std::uint8_t,
    kProviderSigningDomainBytes + kProviderAppendUnsignedBytes>;

// Trusted input supplied by a future independently provisioned appraiser.
// The current hosted campaign self-selects this pin and therefore does not
// prove owner constitution, root custody, or independent provisioning.
struct OwnerGenesisPin final {
    Ed25519PublicKey owner_public_key{};
    ProviderDigest exact_genesis_digest{};
};

// Canonical owner statement. The signature is carried only in the encoded
// envelope. The structure contains no private key and no signing route.
struct OwnerProviderGenesisV1 final {
    std::uint64_t owner_epoch{0U};
    std::uint64_t provider_epoch{0U};
    ProviderDigest owner_constitution{};
    Ed25519PublicKey provider_public_key{};
    ProviderDigest provider_subject{};
    ProviderDigest provider_image{};
    ProviderDigest floor_identity{};
    ProviderDigest endpoint_epoch{};
    Ed25519PublicKey appraiser_public_key{};

    [[nodiscard]] friend constexpr bool operator==(
        const OwnerProviderGenesisV1&,
        const OwnerProviderGenesisV1&) noexcept = default;
};

// Signed query evidence for one proposed exact expected-head append and fixed
// pending-entry identity. It is not a provider transaction, spend, claim,
// effect, or settlement receipt.
struct ProviderAppendObservationV1 final {
    std::uint64_t owner_epoch{0U};
    std::uint64_t provider_epoch{0U};
    std::uint64_t observation_serial{0U};
    std::uint64_t generation_from{0U};
    std::uint64_t generation_to{0U};
    ProviderDigest genesis_digest{};
    ProviderDigest floor_identity{};
    ProviderDigest predecessor_head{};
    ProviderDigest successor_head{};
    ProviderDigest spend_record{};
    ProviderDigest pending_entry{};

    [[nodiscard]] friend constexpr bool operator==(
        const ProviderAppendObservationV1&,
        const ProviderAppendObservationV1&) noexcept = default;
};

struct ExpectedProviderAppend final {
    std::uint64_t owner_epoch{0U};
    std::uint64_t provider_epoch{0U};
    std::uint64_t observation_serial{0U};
    std::uint64_t generation_from{0U};
    std::uint64_t generation_to{0U};
    ProviderDigest floor_identity{};
    ProviderDigest predecessor_head{};
    ProviderDigest successor_head{};
    ProviderDigest spend_record{};
    ProviderDigest pending_entry{};
};

enum class ProviderGenesisDisposition : std::uint8_t {
    exact_signed_observation,
    genesis_malformed,
    genesis_pin_mismatch,
    owner_signature_invalid,
    append_malformed,
    genesis_binding_mismatch,
    provider_signature_invalid,
    expected_mismatch,
    cryptographic_error,
};

// Copyable evidence only. No endpoint or parser API accepts this type.
struct ProviderGenesisObservation final {
    ProviderGenesisDisposition disposition{
        ProviderGenesisDisposition::cryptographic_error};
    bool exact_pin_match{false};
    bool owner_signature_valid{false};
    bool provider_signature_valid{false};
    bool exact_expected_fields{false};
    bool query_only{true};
    bool response_authority{false};
    bool protected_provider_state{false};
    bool globally_unique_spend{false};

    [[nodiscard]] constexpr bool exact() const noexcept {
        return disposition
            == ProviderGenesisDisposition::exact_signed_observation;
    }
};

[[nodiscard]] bool provider_digest_is_zero(
    const ProviderDigest& value) noexcept;
[[nodiscard]] bool owner_provider_genesis_invariant(
    const OwnerProviderGenesisV1& value) noexcept;
[[nodiscard]] bool provider_append_observation_invariant(
    const ProviderAppendObservationV1& value) noexcept;

[[nodiscard]] bool encode_owner_provider_genesis(
    const OwnerProviderGenesisV1& value,
    const Ed25519Signature& signature,
    EncodedOwnerProviderGenesis& output) noexcept;
[[nodiscard]] bool decode_owner_provider_genesis(
    const EncodedOwnerProviderGenesis& input,
    OwnerProviderGenesisV1& value,
    Ed25519Signature& signature) noexcept;

[[nodiscard]] bool encode_provider_append_observation(
    const ProviderAppendObservationV1& value,
    const Ed25519Signature& signature,
    EncodedProviderAppendObservation& output) noexcept;
[[nodiscard]] bool decode_provider_append_observation(
    const EncodedProviderAppendObservation& input,
    ProviderAppendObservationV1& value,
    Ed25519Signature& signature) noexcept;

[[nodiscard]] OwnerProviderGenesisSigningMessage
owner_provider_genesis_signing_message(
    const OwnerProviderGenesisV1& value) noexcept;
[[nodiscard]] ProviderAppendSigningMessage provider_append_signing_message(
    const ProviderAppendObservationV1& value) noexcept;

[[nodiscard]] bool provider_sha256(
    std::span<const std::uint8_t> bytes,
    ProviderDigest& output) noexcept;
[[nodiscard]] bool owner_provider_genesis_digest(
    const EncodedOwnerProviderGenesis& encoded,
    ProviderDigest& output) noexcept;

// Verifies the exact pinned owner statement and the provider-signed append
// observation. The returned object is deliberately replayable query evidence;
// it cannot be consumed by EndpointClaimCell or PayloadAfterClaim.
[[nodiscard]] ProviderGenesisObservation verify_pinned_provider_append(
    const OwnerGenesisPin& pin,
    const EncodedOwnerProviderGenesis& genesis,
    const EncodedProviderAppendObservation& append,
    const ExpectedProviderAppend& expected) noexcept;

[[nodiscard]] const char* provider_genesis_disposition_name(
    ProviderGenesisDisposition value) noexcept;

}  // namespace slopos::e0::handoff_cell
