#pragma once

#include "slopos/e0/handoff_cell/provider_genesis.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <optional>
#include <string>
#include <string_view>

namespace slopos::e0::handoff_cell {

inline constexpr std::string_view kEtcdProfileVersion{"v3.6.14"};
inline constexpr std::string_view kEtcdHistoryPrefix{
    "/slopos/e0/provider-history/v1/"};
inline constexpr ProviderDigest kEtcdV3614LinuxAmd64ArchiveSha256{
    0xffU, 0xe8U, 0x40U, 0xffU, 0x92U, 0x95U, 0x80U, 0x8eU, 0x88U, 0xccU, 0xe2U, 0x79U, 0x4aU, 0x18U, 0xa5U, 0xacU, 0x87U, 0xf1U, 0x2aU, 0x52U, 0x03U, 0xc8U, 0x31U, 0x4dU, 0x0bU, 0xf6U, 0xaaU, 0x11U, 0x9bU, 0x41U, 0xbaU, 0xc5U};

// This pin names one exact operated-profile hypothesis.  It is still supplied
// by the caller.  The type does not constitute an owner, protect any root, or
// establish that the named cluster is the newest surviving history.
struct EtcdProfilePinV1 final {
    std::string version{};
    ProviderDigest release_archive_sha256{};
    std::uint64_t cluster_id{0U};
    std::array<std::uint64_t, 3U> member_ids{};
    ProviderDigest client_ca{};
    ProviderDigest peer_ca{};
    ProviderDigest application_principal{};
    ProviderDigest administration_inventory{};
    std::uint64_t auth_revision{0U};
};

struct EtcdHistoryExpectedV1 final {
    std::uint64_t generation_from{0U};
    std::uint64_t generation_to{0U};
    ProviderDigest operation_binding{};
    ProviderDigest floor_identity{};
    ProviderDigest predecessor_head{};
    ProviderDigest successor_head{};
    ProviderDigest spend_record{};
    ProviderDigest pending_entry{};
};

// Deterministic exact intent.  It is not a transport request and is not proof
// that etcdctl accepted, submitted, committed, or durably stored anything.
struct EtcdHistoryTxnPlanV1 final {
    std::string head_key{};
    std::string floor_key{};
    std::string spend_key{};
    std::string entry_key{};
    std::string interactive_txn{};
    std::string linearizable_query_script{};
    bool serializable_read{false};
    std::size_t comparisons{0U};
    std::size_t success_writes{0U};
    std::size_t failure_queries{0U};
};

enum class EtcdTxnReplyKind : std::uint8_t {
    no_reply,
    compare_succeeded,
    compare_failed,
};

// A normalized dossier assembled outside this library.  No method here opens
// a socket, launches etcdctl, retries, mutates a provider, or accepts a path.
struct EtcdHistoryDossierV1 final {
    bool runtime_observed{false};
    std::string version{};
    ProviderDigest release_archive_sha256{};
    std::uint64_t cluster_id{0U};
    std::uint64_t member_id{0U};
    std::uint64_t auth_revision{0U};
    std::uint64_t raft_term{0U};
    std::uint64_t txn_revision{0U};
    std::uint64_t query_revision{0U};
    EtcdTxnReplyKind txn_reply{EtcdTxnReplyKind::no_reply};
    bool query_delivered{false};
    bool linearizable_query{false};
    bool floor_present{false};
    bool head_present{false};
    bool spend_present{false};
    bool entry_present{false};
    ProviderDigest floor_identity{};
    ProviderDigest head{};
    ProviderDigest spend_record{};
    ProviderDigest pending_entry{};
};

enum class EtcdHistoryDisposition : std::uint8_t {
    runtime_unavailable,
    release_mismatch,
    profile_malformed,
    foreign_cluster,
    foreign_member,
    auth_revision_mismatch,
    query_unavailable,
    serializable_query_rejected,
    revision_regression,
    exact_current_observation,
    exact_current_after_ambiguous_reply,
    exact_unused_after_ambiguous_reply,
    compare_failed_current_observation,
    compare_failed_unused_observation,
    conflicting_observation,
};

// Copyable, query-only classification.  Even an exact current observation has
// no endpoint-parser, dispatch, retry, settlement, or living-law authority.
struct EtcdHistoryAssessment final {
    EtcdHistoryDisposition disposition{
        EtcdHistoryDisposition::profile_malformed};
    bool exact_release{false};
    bool exact_profile{false};
    bool admitted_cluster_coordinate{false};
    bool linearizable{false};
    bool exact_expected_state{false};
    bool query_only{true};
    bool response_authority{false};
    bool retry_authority{false};
    bool provider_commit_proved{false};
    bool restore_continuity_proved{false};
    bool external_currentness_proved{false};

    [[nodiscard]] constexpr bool exact_current() const noexcept {
        return disposition == EtcdHistoryDisposition::exact_current_observation
            || disposition == EtcdHistoryDisposition::exact_current_after_ambiguous_reply
            || disposition == EtcdHistoryDisposition::compare_failed_current_observation;
    }
};

[[nodiscard]] bool etcd_profile_pin_invariant(
    const EtcdProfilePinV1& pin) noexcept;
[[nodiscard]] bool etcd_history_expected_invariant(
    const EtcdHistoryExpectedV1& expected) noexcept;
[[nodiscard]] std::optional<EtcdHistoryTxnPlanV1>
make_etcd_history_txn_plan(const EtcdHistoryExpectedV1& expected);
[[nodiscard]] EtcdHistoryAssessment assess_etcd_history_dossier(
    const EtcdProfilePinV1& pin,
    const EtcdHistoryExpectedV1& expected,
    const EtcdHistoryDossierV1& dossier) noexcept;
[[nodiscard]] const char* etcd_history_disposition_name(
    EtcdHistoryDisposition value) noexcept;

}  // namespace slopos::e0::handoff_cell
