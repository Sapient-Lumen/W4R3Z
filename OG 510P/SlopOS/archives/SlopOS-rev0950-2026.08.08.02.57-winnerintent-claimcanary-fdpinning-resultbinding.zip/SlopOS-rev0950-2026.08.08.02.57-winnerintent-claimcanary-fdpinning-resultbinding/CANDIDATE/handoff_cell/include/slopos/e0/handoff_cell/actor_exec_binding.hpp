#pragma once

#include <cstdint>

namespace slopos::e0::handoff_cell {

// V15 is a pure ordered relation. It binds one successful descriptor-based
// exec transition to one exact, already-sealed *exec input object*. It does not
// claim that a dynamic interpreter, shared objects, later executable mappings,
// or the complete running process image are thereby identified.
enum class ActorExecDisposition : std::uint8_t {
    observation_incoherent,
    profile_unavailable,
    executable_descriptor_unavailable,
    executable_shape_rejected,
    executable_digest_mismatch,
    executable_mutability_rejected,
    single_threaded_child_unproved,
    file_table_custody_unproved,
    address_space_custody_unproved,
    challenge_channel_custody_unproved,
    pidfd_coordinate_unavailable,
    tracer_unavailable,
    traceexec_not_armed,
    execveat_entry_unobserved,
    execveat_contract_rejected,
    exec_argument_memory_custody_unproved,
    target_descriptor_query_unavailable,
    target_descriptor_unavailable,
    target_object_mismatch,
    target_seal_mismatch,
    target_digest_mismatch,
    exec_event_not_linked_to_entry,
    exec_event_unobserved,
    multiple_exec_events,
    challenge_order_rejected,
    challenge_response_rejected,
    runtime_objects_unbound,
    exec_epoch_custody_unproved,
    pre_exec_privilege_floor_unproved,
    pre_exec_seccomp_filter_unproved,
    v14_dossier_unavailable,
    dossier_order_rejected,
    dossier_executable_mismatch,
    dossier_process_mismatch,
    dossier_runtime_mismatch,
    dossier_challenge_mismatch,
    dossier_launch_envelope_mismatch,
    dossier_privilege_floor_mismatch,
    dossier_descriptor_inventory_mismatch,
    actor_exec_and_dossier_bound,
};

// Ordered prefix. Once one field is false, every later field must remain false.
// The first 36 predicates establish only EXEC_INPUT_OBJECT_BOUND. They do not
// identify the complete process image. Runtime-object closure, held exec-epoch
// custody, pre-exec confinement, and the independently evaluated V14 dossier
// are separate premises.
struct ActorExecObservationV2 final {
    bool profile_supplied{false};
    bool executable_descriptor_supplied{false};
    bool executable_regular{false};
    bool executable_readable{false};
    bool executable_unlinked{false};
    bool executable_size_bounded{false};
    bool executable_profile_digest_exact{false};
    bool executable_seal_query_supported{false};
    bool executable_seal_write{false};
    bool executable_seal_grow{false};
    bool executable_seal_shrink{false};
    bool executable_seal_seal{false};
    bool child_single_threaded{false};
    bool child_file_table_private_until_exec{false};
    bool child_address_space_private_until_exec{false};
    bool challenge_endpoint_exclusive_to_tracee{false};
    bool actor_pidfd_supplied_before_release{false};
    bool tracer_established_before_release{false};
    bool traceexec_armed_before_release{false};
    bool execveat_entry_observed{false};
    bool execveat_arch_exact{false};
    bool execveat_empty_path{false};
    bool execveat_flags_exact{false};
    bool execveat_target_fd_exact{false};
    bool exec_argument_memory_stable_until_consumed{false};
    bool pidfd_getfd_supported{false};
    bool target_descriptor_duplicated_while_stopped{false};
    bool target_regular{false};
    bool target_same_inode_as_sealed_executable{false};
    bool target_required_seals_present{false};
    bool target_digest_exact{false};
    bool exec_event_completes_observed_entry{false};
    bool successful_exec_event_observed{false};
    bool exactly_one_exec_event{false};
    bool challenge_generated_after_exec_event{false};
    bool challenge_response_exact{false};
    bool runtime_interpreter_and_objects_bound{false};
    bool exec_epoch_held_through_actor_admission{false};
    bool pre_exec_privilege_floor_exact{false};
    bool pre_exec_seccomp_filter_exact{false};
    bool v14_dossier_admissible{false};
    bool dossier_appraised_after_bound_exec{false};
    bool dossier_executable_digest_matches_exec_target{false};
    bool dossier_process_coordinate_matches_launch{false};
    bool dossier_runtime_objects_match_launch{false};
    bool dossier_challenge_matches_post_exec_epoch{false};
    bool dossier_launch_envelope_matches_observed_exec{false};
    bool dossier_privilege_and_filter_match_launch{false};
    bool dossier_inherited_descriptor_inventory_matches_launch{false};
};

struct ActorExecAssessment final {
    ActorExecDisposition disposition{
        ActorExecDisposition::observation_incoherent};
    bool observation_coherent{false};
    bool sealed_exec_input_exact{false};
    bool launch_coordinate_custody{false};
    bool traceexec_prearmed{false};
    bool execveat_contract_observed{false};
    bool target_descriptor_snapshotted{false};
    bool target_object_exact{false};
    bool target_digest_exact{false};
    bool successful_exec_event_exact{false};
    bool post_exec_challenge_exact{false};
    bool exec_input_object_bound{false};
    bool runtime_object_set_bound{false};
    bool exec_epoch_held{false};
    bool pre_exec_floor_bound{false};
    bool v14_dossier_bound_to_exec_epoch{false};
    bool eligible_for_v13_actor_premise{false};
    bool complete_process_image_bound{false};
    bool network_attempted{false};
    bool ready_sent{false};
    bool rights_imported{false};
    bool candidate_created{false};
    bool candidate_bytes_read{false};
    bool archive_acquired{false};
    bool archive_admitted{false};
    bool source_provenance_proved{false};
    bool owner_authority{false};
    bool living_law{false};
};

[[nodiscard]] ActorExecAssessment assess_actor_exec_binding(
    const ActorExecObservationV2& observation) noexcept;
[[nodiscard]] const char* actor_exec_disposition_name(
    ActorExecDisposition value) noexcept;

}  // namespace slopos::e0::handoff_cell
