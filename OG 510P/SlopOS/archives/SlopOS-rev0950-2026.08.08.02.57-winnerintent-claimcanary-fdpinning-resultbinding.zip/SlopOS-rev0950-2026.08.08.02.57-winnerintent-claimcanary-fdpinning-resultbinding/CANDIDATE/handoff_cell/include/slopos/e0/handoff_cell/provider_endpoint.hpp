#pragma once

#include <cstdint>
#include <optional>

#include <sys/types.h>

namespace slopos::e0::handoff_cell {

inline constexpr char kEndpointStageLeaf[] = "bound.sock";
inline constexpr char kEndpointPublicLeaf[] = "query.sock";

// A host-observed pidfs identity. On the admitted 64-bit Linux host profile,
// fstat(2) device+inode equality identifies two pidfds that refer to the same
// process instance. It is deliberately not an owner-admitted executable,
// service, machine, or endpoint epoch identity.
struct EndpointProcessIdentity final {
    std::uint64_t device{0U};
    std::uint64_t inode{0U};

    [[nodiscard]] constexpr bool valid() const noexcept {
        return device != 0U && inode != 0U;
    }
};

[[nodiscard]] constexpr bool operator==(
    const EndpointProcessIdentity& left,
    const EndpointProcessIdentity& right) noexcept {
    return left.device == right.device && left.inode == right.inode;
}

struct EndpointPeer final {
    pid_t pid{-1};
    uid_t uid{0U};
    gid_t gid{0U};
    EndpointProcessIdentity process{};
};

enum class EndpointPublishDisposition : std::uint8_t {
    published_and_synced,
    published_sync_uncertain,
    stage_missing,
    public_exists,
    wrong_custody,
    unsupported,
    io_error,
};

struct EndpointPublishResult final {
    EndpointPublishDisposition disposition{
        EndpointPublishDisposition::io_error};
    int error_number{0};
    std::uint64_t device{0U};
    std::uint64_t inode{0U};

    [[nodiscard]] constexpr bool namespace_published() const noexcept {
        return disposition == EndpointPublishDisposition::published_and_synced
            || disposition
                == EndpointPublishDisposition::published_sync_uncertain;
    }
};

// One connected SOCK_SEQPACKET endpoint plus two Linux observations of the
// connect-time peer: SO_PEERCRED coordinates and a retained SO_PEERPIDFD
// process-instance reference. The pidfd is owned by this object and is never
// exported as mutation authority. It can only be compared by the recorded
// pidfs identity and polled for exit. Neither observation authenticates an
// owner-admitted provider epoch or closes privileged administration.
class EndpointConnection final {
public:
    EndpointConnection(const EndpointConnection&) = delete;
    EndpointConnection& operator=(const EndpointConnection&) = delete;
    EndpointConnection(EndpointConnection&& other) noexcept;
    EndpointConnection& operator=(EndpointConnection&& other) noexcept;
    ~EndpointConnection();

    [[nodiscard]] int native_fd() const noexcept { return fd_; }
    [[nodiscard]] const EndpointPeer& peer() const noexcept { return peer_; }

    // Returns true only when the retained peer pidfd becomes readable or
    // hung-up within the supplied nonnegative timeout. false with
    // error_number==0 means the process remained live for that interval.
    [[nodiscard]] bool peer_process_exited(
        int timeout_milliseconds, int& error_number) const noexcept;

private:
    friend class ProviderEndpoint;
    friend std::optional<EndpointConnection> connect_fixed_endpoint(
        int, uid_t, uid_t, uid_t, gid_t, int&) noexcept;

    EndpointConnection(int fd, int peer_pidfd,
                       const EndpointPeer& peer) noexcept
        : fd_(fd), peer_pidfd_(peer_pidfd), peer_(peer) {}

    int fd_{-1};
    int peer_pidfd_{-1};
    EndpointPeer peer_{};
};

// Provider-side listener construction. The current process must already be the
// declared nonzero provider principal. The supplied directory must be fixed,
// owner-only, and provider-owned. This operation binds only "bound.sock",
// never unlinks any name, and retains the listening descriptor across a later
// namespace publication performed by a distinct custodian.
class ProviderEndpoint final {
public:
    ProviderEndpoint(const ProviderEndpoint&) = delete;
    ProviderEndpoint& operator=(const ProviderEndpoint&) = delete;
    ProviderEndpoint(ProviderEndpoint&& other) noexcept;
    ProviderEndpoint& operator=(ProviderEndpoint&& other) noexcept;
    ~ProviderEndpoint();

    [[nodiscard]] static std::optional<ProviderEndpoint> bind_fixed_stage(
        int stage_directory_fd, uid_t expected_provider_uid,
        gid_t expected_provider_gid, int& error_number) noexcept;

    [[nodiscard]] std::optional<EndpointConnection> accept_next(
        int timeout_milliseconds, int& error_number) noexcept;

    [[nodiscard]] int native_fd() const noexcept { return listener_fd_; }

private:
    ProviderEndpoint(int listener_fd, uid_t provider_uid,
                     gid_t provider_gid) noexcept
        : listener_fd_(listener_fd), provider_uid_(provider_uid),
          provider_gid_(provider_gid) {}

    int listener_fd_{-1};
    uid_t provider_uid_{0U};
    gid_t provider_gid_{0U};
};

// Moves the already-bound socket inode from provider-owned staging into one
// publisher-owned public directory with RENAME_NOREPLACE. It does not create,
// unlink, overwrite, retry, or repair an endpoint. A stale public leaf is a
// fail-closed collision whose cleanup belongs to a separately named recovery
// authority.
[[nodiscard]] EndpointPublishResult publish_fixed_endpoint_noreplace(
    int stage_directory_fd, int public_directory_fd,
    uid_t expected_provider_uid, uid_t expected_publisher_uid) noexcept;

// Query-side construction. The current process must already be the declared
// query principal. It inherits only the fixed public-directory descriptor,
// creates its own data socket after exec, connects to "query.sock", and checks
// the provider coordinate with SO_PEERCRED while retaining SO_PEERPIDFD. No
// path, route, version, retry, cleanup, publication, or mutation choice is
// accepted. This baseline function accepts no expected-process capsule; V6
// consumes one in connect_fixed_endpoint_expected() before calling it. Neither
// route constitutes owner admission.
[[nodiscard]] std::optional<EndpointConnection> connect_fixed_endpoint(
    int public_directory_fd, uid_t expected_query_uid,
    uid_t expected_publisher_uid, uid_t expected_provider_uid,
    gid_t expected_provider_gid, int& error_number) noexcept;

[[nodiscard]] const char* endpoint_publish_name(
    EndpointPublishDisposition value) noexcept;

}  // namespace slopos::e0::handoff_cell
