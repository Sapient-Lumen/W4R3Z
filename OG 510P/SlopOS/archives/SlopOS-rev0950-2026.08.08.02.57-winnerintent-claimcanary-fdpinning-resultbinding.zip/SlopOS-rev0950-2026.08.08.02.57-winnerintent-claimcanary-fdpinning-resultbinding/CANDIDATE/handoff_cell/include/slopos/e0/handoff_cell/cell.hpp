#pragma once

#include "slopos/e0/generation_journal/record.hpp"

#include <cstdint>
#include <optional>

namespace slopos::e0::handoff_cell {

using generation_journal::EncodedRecord;

inline constexpr char kLiveLeaf[] = "live";
inline constexpr char kPendingLeaf[] = "pending";

enum class BurnDisposition : std::uint8_t {
    bound_and_synced,
    bound_sync_uncertain,
    live_missing,
    pending_exists,
    unsupported,
    io_error,
};

struct BurnResult final {
    BurnDisposition disposition{BurnDisposition::io_error};
    int error_number{0};

    [[nodiscard]] constexpr bool namespace_bound() const noexcept {
        return disposition == BurnDisposition::bound_and_synced
            || disposition == BurnDisposition::bound_sync_uncertain;
    }
};

enum class PendingDisposition : std::uint8_t {
    exact_pending,
    missing,
    not_regular,
    wrong_size,
    alias_detected,
    exact_mismatch,
    decode_rejected,
    wrong_record_kind,
    io_error,
};

struct PendingResult final {
    PendingDisposition disposition{PendingDisposition::io_error};
    int error_number{0};
    std::uint64_t link_count{0U};

    [[nodiscard]] constexpr bool exact() const noexcept {
        return disposition == PendingDisposition::exact_pending;
    }
};

// A Cell retains one host-selected, already-open directory. Selecting and
// provisioning that directory is outside this primitive and remains an
// unprotected provider obligation. Once retained, the admission mutation
// accepts no path, route, operation id, or replacement policy: it is the fixed
// live -> pending no-replace cut. The API has no stage, mint, retry, rollback,
// reverse-rename, or recovery-apply method.
class Cell final {
public:
    Cell(const Cell&) = delete;
    Cell& operator=(const Cell&) = delete;
    Cell(Cell&& other) noexcept;
    Cell& operator=(Cell&& other) noexcept;
    ~Cell();

    // Hosted construction adapter. The caller-selected descriptor is an
    // explicit route/custody premise, not part of the burn-and-bind theorem.
    [[nodiscard]] static std::optional<Cell> retain_host_directory(
        int directory_fd, int& error_number) noexcept;

    // Performs no open, read, decode, checksum, or operation inspection before
    // the rename. A successful rename is always reported as bound, even if the
    // following directory fsync cannot confirm durability.
    [[nodiscard]] BurnResult burn_before_decode() noexcept;

    // Query-only post-burn readback. Exact bytes, single-link observation, and
    // canonical pending-record decoding are checked only under the pending
    // name. This call never mutates namespace or content.
    [[nodiscard]] PendingResult query_pending_exact(
        const EncodedRecord& expected) const noexcept;

private:
    explicit Cell(int directory_fd) noexcept : directory_fd_(directory_fd) {}
    int directory_fd_{-1};
};

[[nodiscard]] const char* burn_name(BurnDisposition value) noexcept;
[[nodiscard]] const char* pending_name(PendingDisposition value) noexcept;

}  // namespace slopos::e0::handoff_cell
