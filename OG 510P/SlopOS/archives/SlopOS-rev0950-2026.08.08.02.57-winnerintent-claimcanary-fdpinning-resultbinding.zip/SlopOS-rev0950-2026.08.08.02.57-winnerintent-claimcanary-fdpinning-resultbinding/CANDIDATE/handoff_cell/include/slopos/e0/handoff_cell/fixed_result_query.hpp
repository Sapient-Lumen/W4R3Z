#pragma once

#include "slopos/e0/generation_journal/record.hpp"

#include <cstdint>
#include <optional>

#include <sys/types.h>

namespace slopos::e0::handoff_cell {

enum class FixedQueryDisposition : std::uint8_t {
    exact_result_v2,
    missing_pending,
    missing_result_v2,
    not_regular,
    wrong_size,
    alias_detected,
    mutable_or_wrong_owner,
    decode_rejected,
    wrong_record_kind,
    operation_mismatch,
    io_error,
};

struct FixedQueryResult final {
    FixedQueryDisposition disposition{FixedQueryDisposition::io_error};
    int error_number{0};
    std::uint64_t pending_link_count{0U};
    std::uint64_t result_link_count{0U};
    generation_journal::EncodedRecord encoded{};

    [[nodiscard]] constexpr bool exact() const noexcept {
        return disposition == FixedQueryDisposition::exact_result_v2;
    }
};

// Read-only half of the hosted principal cell. It accepts one already-open,
// owner-selected provider-root descriptor and no path, version, route, retry,
// cleanup, publication, or mutation choice. It opens fixed child "cell", then
// joins fixed "pending" to fixed "result.2" by exact operation fields.
//
// This API narrows the query surface but does not authenticate the supplied
// root, the executing provider, the transport peer, stable media, newestness,
// or privileged administration.
class FixedResultQuery final {
public:
    FixedResultQuery(const FixedResultQuery&) = delete;
    FixedResultQuery& operator=(const FixedResultQuery&) = delete;
    FixedResultQuery(FixedResultQuery&& other) noexcept;
    FixedResultQuery& operator=(FixedResultQuery&& other) noexcept;
    ~FixedResultQuery();

    [[nodiscard]] static std::optional<FixedResultQuery> open_fixed_beneath(
        int provider_root_fd, uid_t expected_provider_uid,
        int& error_number) noexcept;

    [[nodiscard]] FixedQueryResult read_exact_result_v2() const noexcept;

private:
    explicit FixedResultQuery(int cell_fd, uid_t provider_uid) noexcept
        : cell_fd_(cell_fd), provider_uid_(provider_uid) {}

    int cell_fd_{-1};
    uid_t provider_uid_{0};
};

[[nodiscard]] const char* fixed_query_name(
    FixedQueryDisposition value) noexcept;

}  // namespace slopos::e0::handoff_cell
