#pragma once

#include <array>
#include <cstddef>
#include <cstdint>

namespace slopos::e0::handoff_cell {

inline constexpr std::size_t kAppraiserReceiptBytes = 384U;
inline constexpr std::size_t kAppraiserReceiptSignatureBytes = 64U;
inline constexpr std::size_t kAppraiserPublicKeyBytes = 32U;
inline constexpr std::uint32_t kAppraiserReceiptSchema = 1U;
inline constexpr std::uint32_t kAppraiserReceiptKnownClaimMask = 0x7FFU;

using AppraiserBinding = std::array<std::uint8_t, 32U>;
using AppraiserReceiptBytes = std::array<std::uint8_t, kAppraiserReceiptBytes>;
using AppraiserReceiptSignature =
    std::array<std::uint8_t, kAppraiserReceiptSignatureBytes>;
using AppraiserPublicKey = std::array<std::uint8_t, kAppraiserPublicKeyBytes>;

// The flag bits are signed statements made by an appraiser.  They are never
// converted into custody merely because the signature verifies.  Each must be
// established again by the receiving constitution as an external premise.
enum AppraiserReceiptClaim : std::uint32_t {
    appraiser_process_separate = 1U << 0U,
    appraiser_administration_root_distinct = 1U << 1U,
    appraiser_key_custody_independent = 1U << 2U,
    appraiser_input_custody_independent = 1U << 3U,
    process_coordinate_lifetime_bound = 1U << 4U,
    installed_policy_independently_reconstructed = 1U << 5U,
    kernel_surfaces_independently_reconstructed = 1U << 6U,
    v14_dossier_independently_reopened = 1U << 7U,
    no_same_root_mutation_path = 1U << 8U,
    actor_epoch_held_through_v13_admission = 1U << 9U,
    portable_replay_excluded = 1U << 10U,
};

// Canonical message body.  The 32-byte domain, schema, and sixteen zero
// reserved bytes are supplied by the codec.  All multibyte scalars are little
// endian.  The encoded message is exactly 384 bytes and the signature is a
// detached 64-byte Ed25519 signature.
struct AppraiserReceiptRecordV1 final {
    std::uint32_t claim_flags{0U};
    std::uint64_t report_ordinal{0U};
    AppraiserBinding challenge{};
    AppraiserBinding appraiser_constitution{};
    AppraiserBinding actor_epoch{};
    AppraiserBinding v15_exec_input{};
    AppraiserBinding v16_static_envelope{};
    AppraiserBinding installed_policy{};
    AppraiserBinding kernel_surfaces{};
    AppraiserBinding process_coordinate{};
    AppraiserBinding v14_dossier{};
    AppraiserBinding hold_token{};
};

[[nodiscard]] bool encode_appraiser_receipt(
    const AppraiserReceiptRecordV1& record,
    AppraiserReceiptBytes& encoded) noexcept;
[[nodiscard]] bool decode_appraiser_receipt(
    const AppraiserReceiptBytes& encoded,
    AppraiserReceiptRecordV1& record) noexcept;
[[nodiscard]] bool verify_appraiser_receipt_ed25519(
    const AppraiserPublicKey& public_key,
    const AppraiserReceiptBytes& message,
    const AppraiserReceiptSignature& signature) noexcept;

// V17 is an ordered relation.  The first 28 fields can establish only one
// canonical, signed, locally consumed statement.  The remaining eleven are
// externally constituted custody premises.  A true value after the first
// false value is incoherent rather than evidence.
enum class AppraiserReceiptDisposition : std::uint8_t {
    observation_incoherent,
    profile_unavailable,
    v16_actor_epoch_unavailable,
    appraiser_constitution_unavailable,
    receipt_length_rejected,
    receipt_decode_rejected,
    receipt_canonicality_rejected,
    receipt_domain_rejected,
    receipt_schema_rejected,
    receipt_reserved_bytes_rejected,
    receipt_claim_flags_rejected,
    report_ordinal_rejected,
    challenge_freshness_unproved,
    challenge_binding_mismatch,
    constitution_binding_mismatch,
    actor_epoch_binding_mismatch,
    v15_exec_input_binding_mismatch,
    v16_static_envelope_binding_mismatch,
    installed_policy_binding_mismatch,
    kernel_surface_binding_mismatch,
    process_coordinate_binding_mismatch,
    v14_dossier_binding_mismatch,
    hold_token_binding_mismatch,
    observation_order_rejected,
    signature_suite_rejected,
    public_key_pin_unproved,
    signature_length_rejected,
    signature_invalid,
    report_consumption_unproved,
    appraiser_process_not_separate,
    administration_root_not_distinct,
    independent_key_custody_unproved,
    independent_input_custody_unproved,
    process_lifetime_coordinate_unproved,
    installed_policy_reconstruction_unproved,
    kernel_surface_reconstruction_unproved,
    v14_dossier_reopen_unproved,
    same_root_mutation_path_open,
    actor_epoch_hold_unproved,
    portable_replay_open,
    independently_appraised_actor_premise,
};

struct AppraiserReceiptObservationV1 final {
    bool profile_supplied{false};
    bool v16_hosted_actor_epoch_supplied{false};
    bool appraiser_constitution_supplied{false};
    bool receipt_exact_length{false};
    bool receipt_decoded{false};
    bool receipt_canonical{false};
    bool receipt_domain_exact{false};
    bool receipt_schema_exact{false};
    bool receipt_reserved_zero{false};
    bool receipt_claim_flags_known{false};
    bool report_ordinal_nonzero{false};
    bool challenge_fresh{false};
    bool challenge_binding_exact{false};
    bool constitution_binding_exact{false};
    bool actor_epoch_binding_exact{false};
    bool v15_exec_input_binding_exact{false};
    bool v16_static_envelope_binding_exact{false};
    bool installed_policy_binding_exact{false};
    bool kernel_surface_binding_exact{false};
    bool process_coordinate_binding_exact{false};
    bool v14_dossier_binding_exact{false};
    bool hold_token_binding_exact{false};
    bool observation_order_exact{false};
    bool signature_suite_ed25519{false};
    bool public_key_pinned{false};
    bool signature_exact_length{false};
    bool signature_verifies{false};
    bool exactly_one_report_consumed{false};
    bool appraiser_process_separate{false};
    bool appraiser_administration_root_distinct{false};
    bool appraiser_key_custody_independent{false};
    bool appraiser_input_custody_independent{false};
    bool process_coordinate_lifetime_bound{false};
    bool installed_policy_independently_reconstructed{false};
    bool kernel_surfaces_independently_reconstructed{false};
    bool v14_dossier_independently_reopened{false};
    bool no_same_root_mutation_path{false};
    bool actor_epoch_held_through_v13_admission{false};
    bool portable_replay_excluded{false};
};

struct AppraiserReceiptAssessment final {
    AppraiserReceiptDisposition disposition{
        AppraiserReceiptDisposition::observation_incoherent};
    bool observation_coherent{false};
    bool canonical_receipt_bound{false};
    bool signed_appraiser_statement_bound{false};
    bool one_report_consumption_bound{false};
    bool independent_appraiser_constitution_bound{false};
    bool process_lifetime_coordinate_bound{false};
    bool installed_policy_bound{false};
    bool kernel_surfaces_bound{false};
    bool v14_dossier_bound{false};
    bool independently_appraised_actor_premise_bound{false};
    bool eligible_for_v13_actor_premise{false};
    bool complete_process_image_bound{false};
    bool archive_acquired{false};
    bool archive_admitted{false};
    bool network_attempted{false};
    bool ready_sent{false};
    bool rights_imported{false};
    bool provider_operated{false};
    bool owner_authority{false};
    bool living_law{false};
};

[[nodiscard]] AppraiserReceiptAssessment assess_appraiser_receipt(
    const AppraiserReceiptObservationV1& observation) noexcept;
[[nodiscard]] const char* appraiser_receipt_disposition_name(
    AppraiserReceiptDisposition value) noexcept;

}  // namespace slopos::e0::handoff_cell
