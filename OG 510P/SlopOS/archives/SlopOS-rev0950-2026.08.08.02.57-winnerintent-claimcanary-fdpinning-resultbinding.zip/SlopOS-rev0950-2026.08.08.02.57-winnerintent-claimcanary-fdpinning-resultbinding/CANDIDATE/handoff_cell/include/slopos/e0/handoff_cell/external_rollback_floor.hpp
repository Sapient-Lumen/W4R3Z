#pragma once

#include "slopos/e0/handoff_cell/appraiser_receipt_spend.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <optional>

namespace slopos::e0::handoff_cell {

using ExternalFloorDigest = generation_journal::Digest;
inline constexpr std::size_t kExternalFloorRecordBytes = 288U;
using EncodedExternalFloorRecord =
    std::array<std::uint8_t, kExternalFloorRecordBytes>;

struct ExternalFloorRecordV1 final {
    std::uint64_t generation_from{0U};
    std::uint64_t generation_to{0U};
    ExternalFloorDigest profile_identity{};
    ExternalFloorDigest platform_incarnation{};
    ExternalFloorDigest nv_name{};
    ExternalFloorDigest predecessor_head{};
    ExternalFloorDigest receipt_spend_head{};
    ExternalFloorDigest witness_challenge{};
    ExternalFloorDigest witness_incarnation{};

    [[nodiscard]] friend constexpr bool operator==(
        const ExternalFloorRecordV1&, const ExternalFloorRecordV1&) noexcept = default;
};

[[nodiscard]] bool encode_external_floor_record(
    const ExternalFloorRecordV1& record,
    EncodedExternalFloorRecord& output) noexcept;
[[nodiscard]] bool decode_external_floor_record(
    const EncodedExternalFloorRecord& input,
    ExternalFloorRecordV1& output) noexcept;
[[nodiscard]] ExternalFloorDigest external_floor_record_digest(
    const EncodedExternalFloorRecord& record);
[[nodiscard]] ExternalFloorDigest tpm_nv_extend_successor(
    const ExternalFloorDigest& predecessor,
    const EncodedExternalFloorRecord& record);
[[nodiscard]] std::optional<EncodedExternalFloorRecord>
make_external_floor_record(
    const EncodedReceiptSpendRecord& receipt_spend_record,
    const ExternalFloorDigest& profile_identity,
    const ExternalFloorDigest& platform_incarnation,
    const ExternalFloorDigest& nv_name,
    const ExternalFloorDigest& witness_challenge,
    const ExternalFloorDigest& witness_incarnation) noexcept;

enum class ExternalRollbackFloorDisposition : std::uint8_t {
    observation_incoherent,
    profile_unavailable,
    tpm_family_rejected,
    release_pin_unproved,
    platform_incarnation_unavailable,
    platform_incarnation_mismatch,
    ak_coordinate_unavailable,
    ak_coordinate_mismatch,
    nv_public_unavailable,
    nv_name_mismatch,
    name_algorithm_rejected,
    nv_type_rejected,
    nv_buffer_capacity_unproved,
    nv_data_size_rejected,
    orderly_persistence_unproved,
    write_policy_rejected,
    read_policy_rejected,
    delete_policy_rejected,
    platform_create_rejected,
    candidate_platform_admin_open,
    appraiser_platform_admin_open,
    witness_administration_not_distinct,
    v18_spend_record_unavailable,
    v18_spend_record_rejected,
    v18_spend_digest_mismatch,
    witness_challenge_rejected,
    pre_certify_unavailable,
    pre_certify_signature_rejected,
    pre_certify_qualifying_data_mismatch,
    pre_certify_nv_name_mismatch,
    pre_certify_contents_mismatch,
    predecessor_generation_mismatch,
    predecessor_head_mismatch,
    append_record_encode_rejected,
    append_record_canonicality_rejected,
    append_record_profile_mismatch,
    append_record_spend_mismatch,
    nv_extend_successor_mismatch,
    nv_extend_attempt_count_rejected,
    post_certify_unavailable,
    post_certify_signature_rejected,
    post_certify_qualifying_data_mismatch,
    post_certify_nv_name_mismatch,
    post_certify_contents_mismatch,
    witness_predecessor_mismatch,
    witness_compare_advance_count_rejected,
    witness_response_not_content_bound,
    witness_response_mismatch,
    witness_receipt_signature_rejected,
    duplicate_not_query_only,
    ambiguous_completion_not_query_only,
    reopen_not_query_only,
    second_nv_extend_route_open,
    witness_inside_restorable_image,
    witness_recovery_root_not_distinct,
    platform_succession_unproved,
    nv_redefinition_undetectable,
    restore_continuity_unproved,
    portable_clone_replay_open,
    cross_ledger_join_unproved,
    external_rollback_floor_premise,
};

// V19 is a strict ordered proof relation. The first fifty-two fields can
// describe one exact TPM/NV command transcript plus query-only endpoint
// recovery. The last six fields describe external custody and succession.
// Even the complete fifty-eight-premise profile is not an atomic cross-ledger
// protocol: TPM2_NV_Extend and witness compare-and-advance can be separated by
// a crash, and query-only recovery cannot complete that fractured edge.
struct ExternalRollbackFloorObservationV1 final {
    bool profile_supplied{false};
    bool tpm_family_2_0{false};
    bool exact_profile_release_pinned{false};
    bool platform_incarnation_supplied{false};
    bool platform_incarnation_exact{false};
    bool ak_coordinate_supplied{false};
    bool ak_coordinate_exact{false};
    bool nv_public_supplied{false};
    bool nv_name_recomputed_exact{false};
    bool name_alg_sha256{false};
    bool nv_type_extend{false};
    bool nv_buffer_capacity_sufficient{false};
    bool nv_data_size_digest_exact{false};
    bool orderly_clear{false};
    bool policy_write_only{false};
    bool policy_read_only{false};
    bool policy_delete{false};
    bool platform_create{false};
    bool candidate_lacks_platform_admin{false};
    bool appraiser_lacks_platform_admin{false};
    bool witness_administration_distinct{false};
    bool v18_spend_record_supplied{false};
    bool v18_spend_record_canonical{false};
    bool v18_spend_record_digest_exact{false};
    bool witness_challenge_fresh{false};
    bool pre_certify_supplied{false};
    bool pre_certify_signature_valid{false};
    bool pre_certify_qualifying_data_exact{false};
    bool pre_certify_nv_name_exact{false};
    bool pre_certify_contents_exact{false};
    bool predecessor_generation_exact{false};
    bool predecessor_head_exact{false};
    bool append_record_encoded{false};
    bool append_record_canonical{false};
    bool append_record_binds_profile{false};
    bool append_record_binds_v18_spend{false};
    bool nv_extend_successor_exact{false};
    bool exactly_one_nv_extend_attempt{false};
    bool post_certify_supplied{false};
    bool post_certify_signature_valid{false};
    bool post_certify_qualifying_data_exact{false};
    bool post_certify_nv_name_exact{false};
    bool post_certify_contents_exact{false};
    bool witness_predecessor_exact{false};
    bool exactly_one_witness_compare_advance{false};
    bool witness_response_content_bound{false};
    bool witness_response_exact{false};
    bool witness_receipt_signature_valid{false};
    bool duplicate_query_only{false};
    bool ambiguous_completion_query_only{false};
    bool reopen_query_only{false};
    bool no_second_nv_extend_route{false};
    bool witness_outside_restorable_image{false};
    bool witness_recovery_root_distinct{false};
    bool platform_replacement_requires_succession{false};
    bool nv_undefine_redefine_detectable{false};
    bool restore_continuity_bound{false};
    bool portable_clone_replay_excluded{false};
};

struct ExternalRollbackFloorAssessment final {
    ExternalRollbackFloorDisposition disposition{
        ExternalRollbackFloorDisposition::observation_incoherent};
    bool observation_coherent{false};
    bool exact_tpm_nv_profile_bound{false};
    bool v18_spend_input_bound{false};
    bool prestate_certified{false};
    bool content_bound_extend_request{false};
    bool poststate_certified{false};
    bool independent_witness_advanced{false};
    bool query_only_recovery_bound{false};
    bool complete_dual_ledger_transcript_bound{false};
    bool cross_ledger_atomic_join_bound{false};
    bool query_only_cross_ledger_recovery_bound{false};
    bool external_rollback_floor_bound{false};
    bool eligible_for_v18_external_floor_premise{false};
    bool portable_clone_replay_excluded{false};
    bool tpm_command_issued{false};
    bool network_attempted{false};
    bool ready_sent{false};
    bool rights_imported{false};
    bool provider_operated{false};
    bool owner_authority{false};
    bool living_law{false};
};

[[nodiscard]] ExternalRollbackFloorAssessment assess_external_rollback_floor(
    const ExternalRollbackFloorObservationV1& observation) noexcept;
[[nodiscard]] const char* external_rollback_floor_disposition_name(
    ExternalRollbackFloorDisposition value) noexcept;

}  // namespace slopos::e0::handoff_cell
