#pragma once

#include "slopos/e0/handoff_cell/provider_genesis.hpp"

#include <cstdint>

namespace slopos::e0::handoff_cell {

// This relation models a passive release-byte admission boundary.  It does not
// open a path, parse a tar stream, extract a file, execute a binary, or operate
// a provider.  Those observations are supplied by a separate host adapter.
enum class ReleaseIngressDisposition : std::uint8_t {
    observation_incoherent,
    locator_unavailable,
    descriptor_unpinned,
    nonregular_source,
    snapshot_incomplete,
    snapshot_unsealed,
    digest_mismatch,
    path_reopen_rejected,
    digest_order_rejected,
    archive_rejected,
    activation_boundary_violated,
    exact_passive_admission,
};

// The booleans describe an ordered observation prefix, not independent claims.
// A downstream fact without its prerequisite is rejected as incoherent rather
// than being reported as custody that never existed.
struct ReleaseIngressObservationV1 final {
    bool locator_opened{false};
    bool descriptor_pinned{false};
    bool regular_file{false};
    bool private_snapshot_complete{false};
    bool private_snapshot_write_sealed{false};
    ProviderDigest snapshot_sha256{};
    bool digest_compared_before_parse{false};
    bool archive_parse_attempted{false};
    bool archive_inventory_valid{false};
    bool required_binaries_hashed{false};
    bool supplied_path_reopened{false};
    bool pathname_replaced_after_open{false};
    bool binary_extraction_attempted{false};
    bool binary_execution_attempted{false};
};

// A copyable report, not a capability.  No endpoint, settlement, or provider
// API accepts it.  Even exact passive admission grants no right to activate the
// bytes or claim that any provider history was operated.
struct ReleaseIngressAssessment final {
    ReleaseIngressDisposition disposition{
        ReleaseIngressDisposition::observation_incoherent};
    bool observation_coherent{false};
    bool exact_release_bytes{false};
    bool descriptor_identity_retained{false};
    bool private_snapshot_used{false};
    bool snapshot_write_sealed{false};
    bool digest_before_parse{false};
    bool pathname_replacement_ignored{false};
    bool activation_boundary_observed{false};
    bool passive_only{true};
    bool supplied_path_authority{false};
    bool activation_authority{false};
    bool provider_operation_authority{false};
    bool cluster_operated{false};
    bool binary_execution_proved{false};

    [[nodiscard]] constexpr bool admitted() const noexcept {
        return disposition
            == ReleaseIngressDisposition::exact_passive_admission;
    }
};

[[nodiscard]] ReleaseIngressAssessment assess_release_ingress(
    const ProviderDigest& expected_archive_sha256,
    const ReleaseIngressObservationV1& observation) noexcept;
[[nodiscard]] const char* release_ingress_disposition_name(
    ReleaseIngressDisposition value) noexcept;

}  // namespace slopos::e0::handoff_cell
