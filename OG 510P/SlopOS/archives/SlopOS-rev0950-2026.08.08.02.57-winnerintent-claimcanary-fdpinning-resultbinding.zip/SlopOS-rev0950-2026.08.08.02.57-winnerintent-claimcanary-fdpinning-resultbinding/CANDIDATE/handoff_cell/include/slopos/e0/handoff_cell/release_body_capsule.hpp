#pragma once

#include <cstdint>

namespace slopos::e0::handoff_cell {

enum class ReleaseBodyCapsuleDisposition : std::uint8_t {
    observation_incoherent,
    release_profile_unavailable,
    release_name_mismatch,
    expected_size_mismatch,
    expected_digest_mismatch,
    armored_body_unavailable,
    envelope_version_mismatch,
    session_identity_mismatch,
    canonical_base64_unrequired,
    chunk_size_mismatch,
    chunk_count_mismatch,
    total_length_inconsistent,
    staging_object_not_private,
    staging_object_linked,
    staging_object_unbounded,
    parse_route_open_before_complete,
    extraction_route_open_before_complete,
    execution_route_open_before_complete,
    network_route_open,
    record_session_mismatch,
    chunk_index_out_of_range,
    chunk_offset_mismatch,
    chunk_length_mismatch,
    base64_noncanonical,
    decoded_length_mismatch,
    chunk_digest_mismatch,
    write_offset_mismatch,
    duplicate_not_query_only,
    conflicting_duplicate_not_poisoned,
    coverage_incomplete,
    range_overlap,
    trailing_bytes_present,
    assembled_length_mismatch,
    whole_digest_not_recomputed,
    whole_digest_mismatch,
    complete_snapshot_unsealed,
    v11_recapture_premise,
};

struct ReleaseBodyCapsuleObservationV1 final {
    bool release_profile_supplied{false};
    bool release_name_exact{false};
    bool expected_size_exact{false};
    bool expected_digest_exact{false};
    bool armored_body_supplied{false};
    bool envelope_version_exact{false};
    bool session_identity_exact{false};
    bool canonical_base64_required{false};
    bool fixed_chunk_size_exact{false};
    bool chunk_count_exact{false};
    bool total_length_consistent{false};
    bool staging_object_private{false};
    bool staging_object_unlinked{false};
    bool staging_object_bounded{false};
    bool no_parse_route_before_complete{false};
    bool no_extraction_route_before_complete{false};
    bool no_execution_route_before_complete{false};
    bool no_network_route{false};
    bool records_session_exact{false};
    bool indices_in_range{false};
    bool offsets_exact{false};
    bool lengths_exact{false};
    bool base64_canonical{false};
    bool decoded_lengths_exact{false};
    bool chunk_digests_exact{false};
    bool writes_exact_offset{false};
    bool identical_duplicates_query_only{false};
    bool conflicting_duplicates_poison{false};
    bool coverage_complete{false};
    bool no_overlapping_ranges{false};
    bool no_trailing_bytes{false};
    bool assembled_length_exact{false};
    bool whole_digest_recomputed{false};
    bool whole_digest_exact{false};
    bool complete_snapshot_sealed{false};
    bool v11_recapture_required{false};
};

struct ReleaseBodyCapsuleAssessment final {
    ReleaseBodyCapsuleDisposition disposition{
        ReleaseBodyCapsuleDisposition::observation_incoherent};
    bool observation_coherent{false};
    bool release_metadata_bound{false};
    bool armored_body_bound{false};
    bool staging_floor_bound{false};
    bool chunk_records_bound{false};
    bool complete_coverage_bound{false};
    bool whole_digest_bound{false};
    bool sealed_capsule_bound{false};
    bool eligible_for_v11_ingress{false};
    bool archive_admitted{false};
    bool archive_parse_attempted{false};
    bool extraction_attempted{false};
    bool execution_attempted{false};
    bool provider_operated{false};
    bool network_attempted{false};
    bool owner_authority{false};
    bool living_law{false};
};

[[nodiscard]] ReleaseBodyCapsuleAssessment assess_release_body_capsule(
    const ReleaseBodyCapsuleObservationV1& observation) noexcept;
[[nodiscard]] const char* release_body_capsule_disposition_name(
    ReleaseBodyCapsuleDisposition value) noexcept;

}  // namespace slopos::e0::handoff_cell
