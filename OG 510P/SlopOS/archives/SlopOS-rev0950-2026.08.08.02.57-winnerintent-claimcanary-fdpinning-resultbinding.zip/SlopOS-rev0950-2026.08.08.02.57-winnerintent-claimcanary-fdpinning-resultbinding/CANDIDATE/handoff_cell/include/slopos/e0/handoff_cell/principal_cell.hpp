#pragma once

#include "slopos/e0/generation_journal/record.hpp"
#include "slopos/e0/handoff_cell/cell.hpp"

#include <cstdint>
#include <optional>

#include <sys/types.h>

namespace slopos::e0::handoff_cell {

inline constexpr char kProviderCellLeaf[] = "cell";
inline constexpr char kResultV1Leaf[] = "result.1";
inline constexpr char kResultV2Leaf[] = "result.2";
inline constexpr char kPublicationV1Leaf[] = "publication.1";
inline constexpr char kPublicationV2Leaf[] = "publication.2";
inline constexpr char kResultStageV1Leaf[] = ".stage-result.1";
inline constexpr char kResultStageV2Leaf[] = ".stage-result.2";
inline constexpr char kPublicationStageV1Leaf[] = ".stage-publication.1";
inline constexpr char kPublicationStageV2Leaf[] = ".stage-publication.2";

enum class StageDisposition : std::uint8_t {
    staged_and_synced,
    live_exists,
    invalid_pending,
    io_error,
};

struct StageResult final {
    StageDisposition disposition{StageDisposition::io_error};
    int error_number{0};
};

enum class AppendDisposition : std::uint8_t {
    bound_and_synced,
    bound_sync_uncertain,
    stage_exists,
    final_exists,
    invalid_record,
    wrong_record_kind,
    missing_predecessor,
    refinement_rejected,
    unsupported,
    io_error,
};

struct AppendResult final {
    AppendDisposition disposition{AppendDisposition::io_error};
    int error_number{0};

    [[nodiscard]] constexpr bool namespace_bound() const noexcept {
        return disposition == AppendDisposition::bound_and_synced
            || disposition == AppendDisposition::bound_sync_uncertain;
    }
};

enum class ExactRecordDisposition : std::uint8_t {
    exact,
    missing,
    not_regular,
    wrong_size,
    alias_detected,
    exact_mismatch,
    decode_rejected,
    wrong_record_kind,
    io_error,
};

struct ExactRecordResult final {
    ExactRecordDisposition disposition{ExactRecordDisposition::io_error};
    int error_number{0};
    std::uint64_t link_count{0U};

    [[nodiscard]] constexpr bool exact() const noexcept {
        return disposition == ExactRecordDisposition::exact;
    }
};

// Hosted principal-bound experiment. The current process must already be the
// declared nonzero provider UID and must receive one owner-only provider-root
// descriptor. The factory creates exactly one fixed child directory and exports
// no cell descriptor. This narrows the old host-selected-cell adapter but does
// not authenticate the provider root, exclude root-equivalent administration,
// prove descriptor topology, or establish stable media.
class PrincipalCell final {
public:
    PrincipalCell(const PrincipalCell&) = delete;
    PrincipalCell& operator=(const PrincipalCell&) = delete;
    PrincipalCell(PrincipalCell&& other) noexcept;
    PrincipalCell& operator=(PrincipalCell&& other) noexcept;
    ~PrincipalCell();

    [[nodiscard]] static std::optional<PrincipalCell> create_fixed_beneath(
        int provider_root_fd, uid_t expected_provider_uid,
        int& error_number) noexcept;

    // Staging is inert and validates only that the bytes are one canonical
    // pending record. It creates fixed leaf "live" with O_EXCL, fsyncs the
    // file, and fsyncs the cell directory. No path or route is accepted.
    [[nodiscard]] StageResult stage_pending_exact(
        const generation_journal::EncodedRecord& pending) noexcept;

    [[nodiscard]] BurnResult burn_before_decode() noexcept;
    [[nodiscard]] PendingResult query_pending_exact(
        const generation_journal::EncodedRecord& expected) const noexcept;

    // Append immutable result and publication records under fixed versioned
    // leaves. Each operation writes and fsyncs a fixed staging leaf, performs
    // one RENAME_NOREPLACE bind, then fsyncs the directory. No overwrite,
    // cleanup, retry, apply, route, or rollback entrypoint is provided.
    [[nodiscard]] AppendResult append_result_exact(
        const generation_journal::EncodedRecord& encoded) noexcept;
    [[nodiscard]] AppendResult append_publication_exact(
        const generation_journal::EncodedRecord& encoded) noexcept;

    [[nodiscard]] ExactRecordResult query_result_exact(
        std::uint64_t version,
        const generation_journal::EncodedRecord& expected) const noexcept;
    [[nodiscard]] ExactRecordResult query_publication_exact(
        std::uint64_t version,
        const generation_journal::EncodedRecord& expected) const noexcept;

private:
    explicit PrincipalCell(int directory_fd, uid_t provider_uid) noexcept
        : directory_fd_(directory_fd), provider_uid_(provider_uid) {}

    int directory_fd_{-1};
    uid_t provider_uid_{0};
};

[[nodiscard]] const char* stage_name(StageDisposition value) noexcept;
[[nodiscard]] const char* append_name(AppendDisposition value) noexcept;
[[nodiscard]] const char* exact_record_name(
    ExactRecordDisposition value) noexcept;

}  // namespace slopos::e0::handoff_cell
