#pragma once

#include <cstdint>

namespace slopos::e0::handoff_cell {

// Pure classification of one externally assembled acquisition-actor dossier.
// No method here launches, connects, creates a candidate, sends READY, imports
// rights, reads release bytes, or mints authority.
enum class AcquisitionActorDisposition : std::uint8_t {
    observation_incoherent,
    profile_unavailable,
    executable_descriptor_unpinned,
    executable_digest_mismatch,
    dependency_epoch_mismatch,
    launch_envelope_rejected,
    privilege_identity_rejected,
    supplementary_groups_rejected,
    ambient_capabilities_rejected,
    no_new_privs_missing,
    seccomp_policy_missing,
    inherited_descriptor_inventory_rejected,
    source_policy_rejected,
    network_policy_rejected,
    timeout_policy_rejected,
    retry_policy_rejected,
    administration_inventory_incomplete,
    candidate_lifecycle_policy_rejected,
    output_snapshot_policy_rejected,
    pidfd_coordinate_unavailable,
    pidfd_get_info_unavailable,
    pidfd_info_incomplete,
    pidfd_coordinate_mismatch,
    appraiser_unavailable,
    appraiser_not_independent,
    appraisal_reconstruction_failed,
    appraisal_challenge_failed,
    actor_profile_admissible,
};

// This is an ordered prefix. Once one field is false, every later field must
// remain false. That rule prevents a later observation from laundering an
// earlier missing premise.
struct AcquisitionActorObservationV1 final {
    bool profile_supplied{false};
    bool executable_descriptor_pinned{false};
    bool executable_digest_exact{false};
    bool dependency_manifest_exact{false};
    bool argv_exact{false};
    bool environment_exact{false};
    bool working_directory_exact{false};
    bool umask_exact{false};
    bool uid_nonroot{false};
    bool gid_nonroot{false};
    bool supplementary_groups_empty{false};
    bool capabilities_empty{false};
    bool no_new_privs_enabled{false};
    bool seccomp_filter_exact{false};
    bool inherited_descriptor_inventory_exact{false};
    bool fixed_https_source{false};
    bool source_host_exact{false};
    bool proxy_inputs_absent{false};
    bool network_egress_fixed{false};
    bool timeout_bounded{false};
    bool retry_budget_zero{false};
    bool administration_inventory_complete{false};
    bool receiver_before_candidate_policy_exact{false};
    bool unlinked_sealable_output_only{false};
    bool complete_before_seal_required{false};
    bool full_seal_barrier_required{false};
    bool actor_pidfd_supplied{false};
    bool pidfd_get_info_supported{false};
    bool pidfd_info_pid_present{false};
    bool pidfd_info_creds_present{false};
    bool pidfd_pid_matches_peer{false};
    bool pidfd_tgid_matches_peer{false};
    bool pidfd_euid_matches_profile{false};
    bool pidfd_egid_matches_profile{false};
    bool pidfd_cgroup_matches_profile{false};
    bool appraiser_profile_supplied{false};
    bool appraiser_root_distinct{false};
    bool appraiser_reconstructed_dossier{false};
    bool appraiser_challenge_exact{false};
};

struct AcquisitionActorAssessment final {
    AcquisitionActorDisposition disposition{
        AcquisitionActorDisposition::observation_incoherent};
    bool observation_coherent{false};
    bool executable_epoch_exact{false};
    bool launch_envelope_exact{false};
    bool privilege_boundary_exact{false};
    bool inherited_descriptor_inventory_exact{false};
    bool source_policy_exact{false};
    bool network_policy_exact{false};
    bool timeout_policy_exact{false};
    bool retry_policy_exact{false};
    bool administration_inventory_exact{false};
    bool candidate_lifecycle_policy_exact{false};
    bool output_snapshot_policy_exact{false};
    bool pidfd_coordinate_observed{false};
    bool pidfd_get_info_validated{false};
    bool process_coordinate_matches{false};
    bool appraiser_independent{false};
    bool appraisal_reconstructible{false};
    bool actor_profile_admissible{false};
    // Always false in V14 alone. V15 must bind the running image and then
    // compose this dossier before the V13 actor premise can be established.
    bool eligible_for_v13_actor_premise{false};
    bool ready_sent{false};
    bool rights_imported{false};
    bool candidate_created{false};
    bool candidate_bytes_read{false};
    bool archive_acquired{false};
    bool archive_admitted{false};
    bool source_provenance_proved{false};
    bool owner_authority{false};
    bool living_law{false};
};

[[nodiscard]] AcquisitionActorAssessment assess_acquisition_actor(
    const AcquisitionActorObservationV1& observation) noexcept;
[[nodiscard]] const char* acquisition_actor_disposition_name(
    AcquisitionActorDisposition value) noexcept;

}  // namespace slopos::e0::handoff_cell
