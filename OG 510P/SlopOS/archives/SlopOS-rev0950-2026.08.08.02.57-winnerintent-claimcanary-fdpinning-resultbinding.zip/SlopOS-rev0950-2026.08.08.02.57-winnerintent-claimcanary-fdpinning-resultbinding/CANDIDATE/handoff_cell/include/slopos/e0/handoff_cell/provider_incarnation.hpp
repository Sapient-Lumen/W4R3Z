#pragma once

#include <cstdint>

namespace slopos::e0::handoff_cell {

// V21 is a pure ordered relation for admitting one exact provider release and
// history incarnation, observing one V20 transaction, classifying succession,
// and independently reopening the same result.  It has no downloader, network
// client, provider runtime, retry route, or authority path.
enum class ProviderIncarnationDisposition : std::uint8_t {
    observation_incoherent,
    release_profile_unavailable,
    release_tag_mismatch,
    checksum_product_unavailable,
    checksum_product_unauthenticated,
    archive_body_unavailable,
    archive_digest_mismatch,
    binary_inventory_mismatch,
    binary_digest_mismatch,
    cluster_id_mismatch,
    member_ids_mismatch,
    member_count_mismatch,
    client_ca_mismatch,
    peer_ca_mismatch,
    server_certificate_set_mismatch,
    application_principal_mismatch,
    administration_inventory_open,
    authentication_disabled,
    auth_revision_mismatch,
    namespace_not_exclusive,
    member_endpoint_set_mismatch,
    data_directory_inventory_open,
    snapshot_inventory_open,
    restore_authority_inventory_open,
    replacement_authority_inventory_open,
    v20_plan_unavailable,
    compare_set_mismatch,
    write_set_mismatch,
    transaction_attempt_count_rejected,
    response_cluster_mismatch,
    response_member_unadmitted,
    response_revision_invalid,
    response_auth_revision_mismatch,
    linearizable_readback_required,
    joined_head_mismatch,
    joined_spend_mismatch,
    joined_entry_mismatch,
    joined_revision_mismatch,
    duplicate_not_query_only,
    ambiguity_not_query_only,
    reopen_not_query_only,
    resubmit_route_open,
    quorum_status_unavailable,
    member_cluster_disagreement,
    member_quorum_mismatch,
    endpoint_health_incomplete,
    hashkv_revision_mismatch,
    hashkv_disagreement,
    alarm_inventory_open,
    unadmitted_member_or_learner,
    restore_event_unclassified,
    restored_identity_reused,
    revision_bump_laundered_as_succession,
    successor_ceremony_unbound,
    predecessor_retirement_unbound,
    reopener_administration_not_distinct,
    reopener_credentials_not_distinct,
    reopener_storage_not_distinct,
    reopener_network_path_not_distinct,
    profile_reopen_mismatch,
    v20_result_reopen_mismatch,
    rollback_route_shared,
    external_currentness_unproved,
    stable_storage_contract_unproved,
    independent_reopen_premise,
};

// The observations form one custody prefix.  Descriptive provider coordinates
// close before custody; member agreement closes before succession; and a second
// client is not an independent reopener unless administration, credentials,
// storage control, network path, and rollback domains are all distinct.
struct ProviderIncarnationObservationV1 final {
    bool release_profile_supplied{false};  // 01
    bool release_tag_exact{false};  // 02
    bool checksum_product_supplied{false};  // 03
    bool checksum_product_authenticated{false};  // 04
    bool archive_body_supplied{false};  // 05
    bool archive_digest_exact{false};  // 06
    bool binary_inventory_exact{false};  // 07
    bool admitted_binary_digests_exact{false};  // 08
    bool cluster_id_exact{false};  // 09
    bool member_ids_exact{false};  // 10
    bool member_count_exact{false};  // 11
    bool client_ca_exact{false};  // 12
    bool peer_ca_exact{false};  // 13
    bool server_certificate_set_exact{false};  // 14
    bool application_principal_exact{false};  // 15
    bool administration_inventory_exact{false};  // 16
    bool auth_enabled{false};  // 17
    bool auth_revision_exact{false};  // 18
    bool namespace_exclusive{false};  // 19
    bool member_endpoint_set_exact{false};  // 20
    bool data_directory_inventory_exact{false};  // 21
    bool snapshot_inventory_exact{false};  // 22
    bool restore_authority_inventory_exact{false};  // 23
    bool replacement_authority_inventory_exact{false};  // 24
    bool v20_plan_supplied{false};  // 25
    bool exact_four_compares{false};  // 26
    bool exact_three_writes{false};  // 27
    bool exactly_one_transaction_attempt{false};  // 28
    bool response_cluster_exact{false};  // 29
    bool response_member_admitted{false};  // 30
    bool response_revision_nonzero{false};  // 31
    bool response_auth_revision_exact{false};  // 32
    bool linearizable_exact_readback{false};  // 33
    bool joined_head_exact{false};  // 34
    bool joined_spend_exact{false};  // 35
    bool joined_entry_exact{false};  // 36
    bool joined_revision_exact{false};  // 37
    bool duplicate_query_only{false};  // 38
    bool ambiguous_completion_query_only{false};  // 39
    bool reopen_query_only{false};  // 40
    bool no_resubmit_route{false};  // 41
    bool quorum_status_supplied{false};  // 42
    bool all_members_same_cluster{false};  // 43
    bool member_set_quorum_exact{false};  // 44
    bool endpoint_health_all_admitted{false};  // 45
    bool endpoint_hashkv_revision_exact{false};  // 46
    bool endpoint_hashkv_equal{false};  // 47
    bool alarm_inventory_exact{false};  // 48
    bool no_unadmitted_member_or_learner{false};  // 49
    bool restore_or_replacement_event_classified{false};  // 50
    bool restored_cluster_new_identity_required{false};  // 51
    bool revision_bump_not_succession{false};  // 52
    bool successor_ceremony_bound{false};  // 53
    bool predecessor_retired_under_distinct_root{false};  // 54
    bool reopener_administration_distinct{false};  // 55
    bool reopener_credentials_distinct{false};  // 56
    bool reopener_storage_control_distinct{false};  // 57
    bool reopener_network_path_distinct{false};  // 58
    bool exact_profile_reopened{false};  // 59
    bool exact_v20_result_reopened{false};  // 60
    bool no_rollback_route_shared{false};  // 61
    bool external_currentness_contract_bound{false};  // 62
    bool stable_storage_contract_bound{false};  // 63
};

struct ProviderIncarnationAssessment final {
    ProviderIncarnationDisposition disposition{
        ProviderIncarnationDisposition::observation_incoherent};
    bool observation_coherent{false};
    bool release_metadata_bound{false};
    bool release_archive_admitted{false};
    bool incarnation_coordinates_bound{false};
    bool custody_inventory_bound{false};
    bool v20_operation_observed{false};
    bool quorum_agreement_bound{false};
    bool succession_bound{false};
    bool independent_reopen_bound{false};
    bool eligible_for_external_provider_premise{false};
    bool provider_operated{false};
    bool network_attempted{false};
    bool archive_body_bytes_read{false};
    bool ready_sent{false};
    bool rights_imported{false};
    bool owner_authority{false};
    bool living_law{false};
};

[[nodiscard]] ProviderIncarnationAssessment assess_provider_incarnation(
    const ProviderIncarnationObservationV1& observation) noexcept;
[[nodiscard]] const char* provider_incarnation_disposition_name(
    ProviderIncarnationDisposition value) noexcept;

}  // namespace slopos::e0::handoff_cell
