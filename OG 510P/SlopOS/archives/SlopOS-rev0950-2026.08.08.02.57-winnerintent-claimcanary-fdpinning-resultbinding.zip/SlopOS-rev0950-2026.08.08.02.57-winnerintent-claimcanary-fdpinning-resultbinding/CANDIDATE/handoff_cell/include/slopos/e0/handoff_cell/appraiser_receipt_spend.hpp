#pragma once

#include "slopos/e0/generation_journal/spend_floor.hpp"
#include "slopos/e0/handoff_cell/appraiser_receipt.hpp"

#include <cstdint>
#include <optional>

namespace slopos::e0::handoff_cell {

using ReceiptSpendDigest = generation_journal::Digest;
using ReceiptSpendRecord = generation_journal::SpendRecordV1;
using EncodedReceiptSpendRecord = generation_journal::EncodedSpendRecord;

[[nodiscard]] ReceiptSpendDigest appraiser_receipt_envelope_digest(
    const AppraiserReceiptBytes& message,
    const AppraiserReceiptSignature& signature,
    const AppraiserPublicKey& public_key);

[[nodiscard]] std::optional<EncodedReceiptSpendRecord>
make_appraiser_receipt_spend_record(
    const AppraiserReceiptBytes& message,
    const AppraiserReceiptSignature& signature,
    const AppraiserPublicKey& public_key,
    const ReceiptSpendDigest& floor_identity,
    const generation_journal::FloorPoint& predecessor,
    std::uint64_t owner_epoch,
    std::uint64_t constructor_epoch) noexcept;

enum class AppraiserReceiptSpendDisposition : std::uint8_t {
    observation_incoherent,
    profile_unavailable,
    receipt_unavailable,
    signature_unavailable,
    public_key_unavailable,
    receipt_decode_rejected,
    receipt_canonicality_rejected,
    signature_rejected,
    v17_signed_statement_unproved,
    challenge_cross_binding_mismatch,
    constitution_cross_binding_mismatch,
    actor_epoch_cross_binding_mismatch,
    v15_cross_binding_mismatch,
    v16_cross_binding_mismatch,
    installed_policy_cross_binding_mismatch,
    kernel_surfaces_cross_binding_mismatch,
    process_coordinate_cross_binding_mismatch,
    v14_cross_binding_mismatch,
    hold_token_cross_binding_mismatch,
    report_ordinal_rejected,
    floor_identity_unavailable,
    floor_identity_mismatch,
    local_floor_malformed,
    floor_observation_unavailable,
    floor_not_content_bound,
    floor_predecessor_mismatch,
    spend_record_encode_rejected,
    spend_record_canonicality_rejected,
    envelope_digest_mismatch,
    spend_subject_mapping_mismatch,
    compare_append_request_rejected,
    compare_append_attempt_count_rejected,
    compare_append_response_unavailable,
    compare_append_response_not_content_bound,
    compare_append_response_mismatch,
    compare_append_not_spent,
    local_confirmation_unproved,
    duplicate_not_query_only,
    reopen_not_query_only,
    second_append_route_open,
    appraiser_administration_root_not_distinct,
    independent_key_custody_unproved,
    independent_input_custody_unproved,
    external_challenge_spend_state_unproved,
    rollback_floor_inside_restorable_image,
    rollback_floor_administration_not_distinct,
    restore_continuity_unproved,
    process_lifetime_coordinate_unproved,
    installed_policy_reconstruction_unproved,
    kernel_surface_reconstruction_unproved,
    v14_dossier_reopen_unproved,
    same_root_mutation_path_open,
    actor_epoch_hold_unproved,
    portable_clone_replay_open,
    externally_spent_appraiser_premise,
};

// V18 is ordered. The first thirty-nine fields prove only a local coherent
// history. The remaining fourteen are externally constituted custody premises.
struct AppraiserReceiptSpendObservationV1 final {
    bool profile_supplied{false};
    bool receipt_supplied{false};
    bool signature_supplied{false};
    bool public_key_supplied{false};
    bool receipt_decoded{false};
    bool receipt_canonical{false};
    bool signature_verifies{false};
    bool v17_signed_statement_bound{false};
    bool challenge_cross_binding_exact{false};
    bool constitution_cross_binding_exact{false};
    bool actor_epoch_cross_binding_exact{false};
    bool v15_cross_binding_exact{false};
    bool v16_cross_binding_exact{false};
    bool installed_policy_cross_binding_exact{false};
    bool kernel_surfaces_cross_binding_exact{false};
    bool process_coordinate_cross_binding_exact{false};
    bool v14_cross_binding_exact{false};
    bool hold_token_cross_binding_exact{false};
    bool report_ordinal_nonzero{false};
    bool floor_identity_supplied{false};
    bool floor_identity_exact{false};
    bool local_floor_exact{false};
    bool floor_observation_available{false};
    bool floor_content_bound{false};
    bool floor_predecessor_exact{false};
    bool spend_record_encoded{false};
    bool spend_record_canonical{false};
    bool envelope_digest_exact{false};
    bool spend_subject_mapping_exact{false};
    bool compare_append_request_exact{false};
    bool exactly_one_compare_append_attempt{false};
    bool compare_append_response_received{false};
    bool compare_append_response_content_bound{false};
    bool compare_append_response_exact{false};
    bool append_decision_spent{false};
    bool local_confirmation_updated{false};
    bool duplicate_query_only{false};
    bool reopen_query_only{false};
    bool no_second_append_after_spend{false};
    bool appraiser_administration_root_distinct{false};
    bool appraiser_key_custody_independent{false};
    bool appraiser_input_custody_independent{false};
    bool external_challenge_spend_state{false};
    bool rollback_floor_outside_restorable_image{false};
    bool rollback_floor_administration_distinct{false};
    bool restore_continuity_bound{false};
    bool process_coordinate_lifetime_bound{false};
    bool installed_policy_independently_reconstructed{false};
    bool kernel_surfaces_independently_reconstructed{false};
    bool v14_dossier_independently_reopened{false};
    bool no_same_root_mutation_path{false};
    bool actor_epoch_held_through_v13_admission{false};
    bool portable_clone_replay_excluded{false};
};

struct AppraiserReceiptSpendAssessment final {
    AppraiserReceiptSpendDisposition disposition{
        AppraiserReceiptSpendDisposition::observation_incoherent};
    bool observation_coherent{false};
    bool canonical_receipt_cross_bound{false};
    bool content_bound_spend_record{false};
    bool compare_append_request_bound{false};
    bool one_local_receipt_spend_bound{false};
    bool duplicate_query_only_bound{false};
    bool external_rollback_floor_bound{false};
    bool independent_appraiser_constitution_bound{false};
    bool externally_spent_appraiser_premise_bound{false};
    bool eligible_for_v13_actor_premise{false};
    bool portable_clone_replay_excluded{false};
    bool archive_acquired{false};
    bool archive_admitted{false};
    bool network_attempted{false};
    bool ready_sent{false};
    bool rights_imported{false};
    bool provider_operated{false};
    bool owner_authority{false};
    bool living_law{false};
};

[[nodiscard]] AppraiserReceiptSpendAssessment assess_appraiser_receipt_spend(
    const AppraiserReceiptSpendObservationV1& observation) noexcept;
[[nodiscard]] const char* appraiser_receipt_spend_disposition_name(
    AppraiserReceiptSpendDisposition value) noexcept;

}  // namespace slopos::e0::handoff_cell
