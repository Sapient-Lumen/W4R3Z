# Hosted handoff vertical

This C++20 Linux package is one hosted proof island. It is not a protected
capability, authenticated provider, admitted endpoint epoch, durable result
service, product daemon, or release.

## Current refinement

V1–V7 established a bounded sequence of local facts: fixed no-replace handoff,
principal separation, immutable result versions, exact launch descriptor
census, authority-first ancillary rejection, staged endpoint publication,
process-instance observation, actor-local burn of one sealed expected-process
capsule, and finally fixed `pending -> claimed` before record or proposer
meaning. The V7 winner receives one internal move-only `ClaimedPending` only
after exact readback and successful directory synchronization. Every duplicate,
synchronization-uncertain outcome, and reopen is query-only.

V8 adds a **hosted one-attempt settlement adapter** inside this same island:

```text
fresh local claim
  -> consume before request meaning
  -> exact request makes one submit_exact call
  -> exact bound terminal record refines the result
  -> no-return / unavailable / malformed / foreign remains uncertain

reopen
  -> one query_exact call
  -> zero submit calls
  -> exact-unused may refine to no-effect under the provider premise
  -> no retry authority
```

The public `SettlementObservation` is copyable but powerless. It always remains
query-only and has `response_authority=false` and `retry_authority=false`.
There is no resubmit, retry, compensation, publication, reverse-claim, or
recovery-apply entrypoint.

## Evidence

The V8 campaign adds:

```text
14 settlement cases
4 scheduled settlement process-death cuts
16 coherent local histories against one shared scripted provider
16 submissions / 1 fresh provider commit / 15 duplicates / 1 effect
4 settlement countermodels
```

An independent Python oracle verifies the exact case inventory, source order,
one submit callsite, zero recovery-submit paths, exact crash outcomes, and
absence of response or retry authority.

The four governing V8 defeats are not caveats:

- a malformed return may follow a committed effect;
- coherent provider clones can each commit the same effect;
- finite idempotency retention permits a later duplicate effect; and
- distinct providers can emit byte-identical result records after two effects.

Therefore the provider object is a premise, not authority. V8 proves client
settlement behavior only under one supplied provider history. It does not prove
provider identity, exclusive writer custody, lifetime deduplication, restore or
failover continuity, external newestness, stable media, protected effect, or
protected settlement.

## V9 owner-pinned history observation

V9 adds a fixed 320-byte owner/provider genesis and a fixed 320-byte provider append observation. The exact genesis is selected by a SHA-256 pin and verified with an owner Ed25519 public key; the append is verified with the provider key named by that genesis and compared against every expected history-edge field. The returned `ProviderGenesisObservation` is copyable, replayable, query-only evidence. It has no response, retry, claim, effect, commit, or settlement authority and no endpoint/parser route.

The deterministic campaign retains twenty semantic cases, rejects all 2,560 one-bit mutations of each envelope, and retains five countermodels: self-selected roots, replay, coherent copies, conflicting successors signed by one provider key, and alternate owner-signed geneses. The implementation relies on OpenSSL public verification and SHA-256; deterministic private seeds and signing occur only in the harness. This construction describes signed bytes. It does not prove that an admitted provider executed a compare-and-commit, that the observation is newest, or that restore preserves the same history.

## Build and run

Build and run outside the checkpoint as root. Root is used only by the hosted
principal, publisher, and expectation-construction counterboundary campaigns.

```text
cmake -S CANDIDATE/handoff_cell -B /tmp/slopos-handoff-build -G Ninja
cmake --build /tmp/slopos-handoff-build
/tmp/slopos-handoff-build/slopos_handoff_cell campaign /tmp/slopos-handoff-output
python3 -B CANDIDATE/handoff_cell/proof/verify_campaign.py \
  /tmp/slopos-handoff-output --json /tmp/slopos-handoff-output/audit.json
python3 -B CANDIDATE/handoff_cell/proof/verify_endpoint_claim.py \
  /tmp/slopos-handoff-output \
  --json /tmp/slopos-handoff-output/endpoint-claim-audit.json
python3 -B CANDIDATE/handoff_cell/proof/verify_settlement.py \
  /tmp/slopos-handoff-output \
  --json /tmp/slopos-handoff-output/settlement-audit.json
python3 -B CANDIDATE/handoff_cell/proof/verify_provider_genesis.py \
  /tmp/slopos-handoff-output \
  --json /tmp/slopos-handoff-output/provider-genesis-audit.json
```

No build tree, binary, Python bytecode, temporary socket, database, snapshot,
or native process descriptor belongs in the checkpoint.

The GNU Release build deliberately compiles only `harness/campaign.cpp` at
`-O2`. GCC 14.2 was directly observed spending more than the cloudtainer command
envelope on that one proof-driver translation unit at `-O3`, while `-O2`
completed in seconds and reproduced the same canonical outputs. Candidate
library sources retain the selected Release optimization. This bounded compile
policy is an operator-resource constraint, not evidence of semantic equivalence
between arbitrary optimization modes.

## Inherited endpoint boundary

The provider still binds fixed `bound.sock` only after final-principal entry. A
separate publisher moves the same socket inode to fixed `query.sock` with
`RENAME_NOREPLACE`. The later query inherits no data socket, consumes one
sealed expected-process capsule before connect, and retains the connection only
when hidden connect-time and message-time process observations agree. Native
pidfds are never exported as generic process-control authority.

Those observations do not authenticate who selected the executable, minted the
capsule, published the endpoint, or controls root-equivalent administration.
Provider death is not effect completion, endpoint retirement, or successor
admission.

## Nonclaims

No owner genesis, protected provider constructor, authentic owner binding,
executable/dependency continuity, machine or service incarnation, durable
spend, global duplicate closure, stable endpoint epoch, stable media,
destructive power-loss proof, external rollback floor, authenticated provider,
independent appraiser, admitted source-to-operated-binary identity, release
authority, or epoch advance is established.

Read `spec/HANDOFF-CELL-V8.md`,
`DESIGN/HOSTED-CLAIM-SETTLEMENT.md`,
`EXCAVATION/SETTLEMENT-CUSTODY-SPINE/JUDGMENT.md`, and retained rev0896 handoff
evidence before reusing any result. V7 remains the inherited local
claim-before-parse premise; V6 remains the inherited expected-process premise.

## V10–V12 release-profile airlock

V10 retains the exact etcd v3.6.14 transaction/query profile as query-only
classification. V11 adds ordered, write-sealed passive release ingress. V12 now
adds a descriptor-rooted fixed-leaf locator prefix:

```text
caller-supplied O_PATH directory fd
  -> CLOEXEC duplicate
  -> effective-UID-owned mode-0700 hosted profile
  -> fixed etcd-v3.6.14-linux-amd64.tar.gz leaf
  -> openat2(BENEATH|NO_SYMLINKS|NO_MAGICLINKS|NO_XDEV, OPENAT2_REGULAR)
  -> post-open regular/same-device contract check only
  -> bounded candidate fd on a supporting host
  -> V11 complete pread capture into sealed memfd
  -> digest comparison and passive archive semantics
```

V12 contributes 24 finite relation cases and 11 countermodels. Exactly two ready
rows are synthetic supporting-host premises. The standalone Linux root-FD probe
contributes 21 syscall cases and 11 counterexamples,
including unsupported `OPENAT2_REGULAR`, the FIFO-open-before-`fstat` defect,
explicit `O_PATH` and duplication/identity separation, root-path replacement
versus pinned-root identity, profile drift and
`0700 -> 0755 -> 0700` ABA, and mutation of a rooted leaf before snapshot
capture. The ancestor-symlink escape uses a deliberately widened two-component
regression path; production accepts only the exact one-component leaf.

The retained 6.12.13 host cannot satisfy the atomic regular-only premise and
therefore produces no production candidate descriptor; there is no open-then-
`fstat` fallback. The profile is deliberately narrow. A host-private root is not constituted
owner custody; same-device is not provenance; rooted open is not immutable
content; sealed exact bytes are not activation; and activation is not provider
operation, commit, currentness, settlement, or authority. The exact archive is
absent, so no positive admission is claimed.

The current reconstruction additionally runs:

```text
/tmp/slopos-handoff-build/slopos_release_fd_probe /tmp/slopos-handoff-output
/tmp/slopos-handoff-build/slopos_release_rootfd_probe /tmp/slopos-handoff-output
python3 -B CANDIDATE/handoff_cell/proof/verify_release_ingress.py \
  /tmp/slopos-handoff-output \
  --json /tmp/slopos-handoff-output/release-ingress-audit.json
python3 -B CANDIDATE/handoff_cell/proof/verify_rooted_release.py \
  /tmp/slopos-handoff-output \
  --json /tmp/slopos-handoff-output/rooted-release-audit.json
python3 -B CANDIDATE/handoff_cell/proof/verify_release_rootfd_probe.py \
  /tmp/slopos-handoff-output \
  --json /tmp/slopos-handoff-output/release-rootfd-audit.json
```

Read `spec/HANDOFF-CELL-V12.md`,
`DESIGN/ROOTFD-BOUND-RELEASE-LOCATOR.md`, and the retained rev0900 evidence
boundary before reusing the locator result.

## V13 pre-admitted sealed-snapshot offer

V13 adds a second authority-negative ingress profile upstream of V11. The
receiver accepts only one exact `AF_UNIX/SOCK_SEQPACKET` offer after it has
sampled one peer credential/pidfd coordinate, externally established that it
holds zero aliases to this candidate, and externally admitted that actor before
READY and before every rights-bearing receive.

The production adapter carries the zero-alias premise as an independent input
and rejects its absence before actor admission, READY, and `recvmsg`; it is not
inferred from the message or from the received descriptor.

The complete proposition requires one fixed payload, no data/control
truncation, exactly one `SCM_RIGHTS` record carrying exactly one descriptor,
exactly one automatic credential record, exactly one automatic pidfd record, no
unknown controls, matching peer/message coordinates, and a close-on-exec,
readable, regular, unlinked, bounded object carrying
`F_SEAL_WRITE|F_SEAL_GROW|F_SEAL_SHRINK|F_SEAL_SEAL`. No candidate byte is read
before all predicates pass.

The first-ingress premise is explicit because `fork()` can preinstall a
candidate alias in the receiver. The positive hosted topology creates the
offered object only after receiver fork; a separate counterproof creates it
before fork and observes inheritance. This proves neither sender alias closure
nor global exclusive custody. The seal profile likewise proves present inode
behavior, not that `memfd_create()` was called, who called it, or which release
produced the bytes. Readability is independent: a fully sealed `O_WRONLY` alias
still cannot feed V11 `pread`.

The pure relation retains 36 cases and 20 countermodels: one admitted-ready
synthetic source, one pre-offer-alias rejection, one pre-receive actor rejection,
five incoherent orderings, and zero coherent mechanism-only actor rejection.
The Linux laboratory retains 39 cases and 15 counterexamples. It deliberately
imports one exact sealed descriptor before external actor admission, thereby
showing that a post-receive check has already admitted an ungoverned capability
while production readiness remains false. It also reproduces fork inheritance,
one rights record carrying multiple descriptors, sender retention,
`MSG_PEEK` descriptor duplication, `MSG_CTRUNC`, stream rejection, unsealed
mutability, linked-file namespace exposure, and a fully sealed write-only
reference rejected as an unreadable source.

The production Python self-test proves the repaired order: an unadmitted peer
receives no READY, no rights-bearing receive occurs, and zero candidate
descriptors are installed. A separate admitted control rejects a fully sealed
`O_WRONLY` descriptor before any candidate byte. V11 remains mandatory even after a positive V13
result: complete receiver-side `pread` recapture, fresh four-seal barrier,
SHA-256 recomputation, exact digest comparison, and only then passive archive
inspection.

The current reconstruction additionally runs:

```text
/tmp/slopos-handoff-build/slopos_release_offer_probe /tmp/slopos-handoff-output
python3 -B CANDIDATE/handoff_cell/proof/verify_sealed_snapshot_offer.py \
  /tmp/slopos-handoff-output \
  --json /tmp/slopos-handoff-output/sealed-snapshot-offer-audit.json
python3 -B CANDIDATE/handoff_cell/proof/verify_release_offer_probe.py \
  /tmp/slopos-handoff-output \
  --json /tmp/slopos-handoff-output/release-offer-audit.json
python3 -B TOOLS/test_sealed_offer_admission.py
```

Read `spec/HANDOFF-CELL-V13.md`,
`DESIGN/SEALED-SNAPSHOT-OFFER-AIRLOCK.md`, and the retained rev0901 evidence
boundary before reusing the result. V13 creates no downloader, broker, listener
service, retry route, activation target, provider runtime, or authority. The
exact archive body remains absent. Epoch Zero remains truthful.

## V14 acquisition-actor admission dossier

V14 turns V13's external actor premise into a pure 39-fact ordered classifier
and a separate Linux host counterproof. It binds exact executable and
dependencies, launch envelope, nonroot zero-capability floor,
`no_new_privs`, exact seccomp, inherited descriptors, source/egress/timeout and
zero-retry policy, sealed-output lifecycle, a `PIDFD_GET_INFO` coordinate, and
an independently rooted appraiser reconstruction plus challenge.

The relation retains 28 cases and 18 countermodels. One exact admissible dossier
is synthetic; zero are host-applicable. The Linux probe retains 22 cases and 12
counterexamples. This host is root, retains effective capabilities, has
`NoNewPrivs: 0` and `Seccomp: 0`, runs Linux 6.12.13, and rejects the Linux 6.13
`PIDFD_GET_INFO` request. It performs no network operation, sends no READY,
imports no rights, creates no candidate, and retains zero archive bytes.

The current checkpoint reconstruction covers V14 inside the shared 105-source,
84-product handoff campaign and records the exact canonical-byte total only in
retained evidence. Clang, GCC, and the sanitizer reconstruction must agree.
V14 has no launcher, downloader, broker, retry, activation, provider, or
authority API. V14 never satisfies V13 by itself. It must compose with V15
after a bound exec transition, runtime-object closure, held-epoch custody, and
independent appraisal. V13 zero-alias and V11 receiver recapture remain
mandatory.

## V15 data-sealed exec-input binding

V15 corrects V14's former launch-plan overclaim. It adds a 49-field ordered
relation and one bounded Linux laboratory. The first 36 premises bind a
successful `execveat` event to one exact stopped main input object; runtime
interpreter/shared-object closure, held exec-epoch custody, and pre-exec privilege and seccomp floors, and nine independently evaluated
post-exec V14 cross-binding premises remain separate.

The laboratory uses an explicit executable memfd, the write/grow/shrink/seal
barrier, full SHA-256, an exact x86-64 syscall-entry observation,
`pidfd_getfd` inspection while stopped, a linked PTRACE_EVENT_EXEC, and a fresh
post-event challenge. `PTRACE_O_EXITKILL` plus a kill-and-reap guard prevents a
failed proof run from leaking its tracee.

The retained host result is intentionally narrow: the main exec input is bound,
but PT_INTERP is present, the interpreter and shared-object set are unbound, the
exec epoch is not held through V14, the exact seccomp filter cannot be dumped,
`PIDFD_GET_INFO` is unavailable, and no independent appraiser exists. V13 eligibility, READY, rights, candidate bytes, archive bytes, and authority
are all false. Production acquisition remains uninitiated, while syscall-wide
network absence remains unaudited.

The pure relation retains 51 cases and 32 countermodels. The Linux laboratory
retains 62 cases and 29 countermodels. Read `spec/HANDOFF-CELL-V15.md`,
`DESIGN/SEALED-ACTOR-EXEC-BINDING.md`, and
`EXCAVATION/EXEC-IMAGE-CUSTODY-THREAD.md` before reusing the result.


## V16 static actor pre-exec confinement

V16 replaces neither V15 nor V14. It consumes V15's exact main-input witness
and adds a deliberately tiny freestanding static ET_EXEC fixture whose
filesystem, privilege, and syscall floors are established before exec. The
pure relation has 60 ordered premises, 62 cases, and 41 countermodels.

The Linux laboratory reads the ELF profile from the same sealed object bound by
V15. A fork-private filesystem context enters one exact empty 0555 root, sets
cwd to that root, and retains both after the only pathname is removed. A
counterexample demonstrates why this is independent of descriptor closure and
seccomp scalar checks: an absolute `execveat` pathname ignores `dirfd`; the
unrooted canary executes, while the actor's allowed-shape attempt stops at the
empty root with `ENOENT`.

The laboratory observes an empty inherited seccomp stack and copies one exact
30-instruction classic-BPF input snapshot at the stopped installation entry.
Linux copies that userspace program only after the tracer resumes, so the entry
snapshot is not promoted into the identity of the kernel-installed program.
The laboratory separately observes successful installation, a zero-to-one
filter-count transition, and the named denied behaviors. It then links the
exact V15 entry to one held exec event and inventories mappings, descriptors,
root, and cwd before the first user instruction. The file-backed user
executable mapping set is the sealed candidate; PT_INTERP, PT_DYNAMIC,
shared-object executable mappings, and W+X mappings are absent.

The positive result is `hosted_static_actor_envelope_bound=true`.
`installed_seccomp_program_bound` remains false. Kernel-provided executable
surfaces are only enumerated and remain independently unbound.
`PTRACE_SECCOMP_GET_FILTER` fails with `EINVAL`, the appraiser shares the
cloudtainer administration root, `PIDFD_GET_INFO` is unavailable, no V14
dossier is cross-bound, and V13 eligibility remains false. The host campaign
retains 94 cases and 50 counterexamples. It directly reinspects fd 5 at the
terminal stopped `execveat` entry rather than treating a finite fd-mutating
syscall list or equal endpoint inventories as uninterrupted descriptor-table
history. The same sealed-object profile also requires the exact raw x86-64
entry shim that aligns the process-entry stack, calls the C++ actor body, and
traps on an impossible return; an ordinary compiler-generated `_start` is
retained as a countermodel.

Fresh Clang, GCC, and Clang ASan/UBSan builds cover 105 audited sources and 84
canonical products byte-identically. The exact canonical-byte total is recorded
in retained evidence rather than copied into an audited source. The static
subject and all binaries remain outside the checkpoint.

The current reconstruction additionally runs:

```text
/tmp/slopos-handoff-build/slopos_static_actor_probe \
  /tmp/slopos-handoff-build/slopos_static_actor_subject \
  /tmp/slopos-handoff-output
python3 -B CANDIDATE/handoff_cell/proof/verify_static_actor_confinement.py \
  /tmp/slopos-handoff-output \
  --json /tmp/slopos-handoff-output/static-actor-audit.json
python3 -B CANDIDATE/handoff_cell/proof/verify_static_actor_probe.py \
  /tmp/slopos-handoff-output \
  --json /tmp/slopos-handoff-output/static-actor-host-audit.json
```

Read `spec/HANDOFF-CELL-V16.md`,
`DESIGN/STATIC-ACTOR-PREEXEC-CONFINEMENT.md`, and
`EXCAVATION/STATIC-ACTOR-CUSTODY-THREAD.md` before reusing the result. No
network acquisition, READY, rights import, archive admission, provider
operation, owner authority, or epoch advance is established.

## V17 canonical appraiser receipt and custody stop

V17 adds one exact 384-byte appraiser report codec, a detached 64-byte Ed25519
verification boundary, and a 39-premise ordered relation. A valid signature and
one local consumption establish only `signed_appraiser_statement_bound`; they
do not establish independent administration, key custody, input custody,
anti-replay, continuous actor hold, or V13 eligibility.

The pure campaign retains 42 relation cases, 24 countermodels, and exhaustive
rejection of 3,840 single-bit message, signature, and public-key mutations. Its
only V13-eligible row is a synthetic full-premise relation fixture. The Linux
host laboratory retains 40 cases and 18 countermodels. It demonstrates that the
same parent creates the child user namespace, writes both identity maps,
supplies all signed bytes, successfully seizes the child with ptrace, and
terminates it through a pidfd. Separate PID and namespace inode therefore remain
countermodels to independent administration. The public RFC 8032 fixture key is
not enrolled authority and the identical signed report verifies again.

The current reconstruction additionally runs:

```text
/tmp/slopos-handoff-build/slopos_appraiser_receipt_probe \
  /tmp/slopos-handoff-output
python3 -B CANDIDATE/handoff_cell/proof/verify_appraiser_receipt.py \
  /tmp/slopos-handoff-output \
  --json /tmp/slopos-handoff-output/appraiser-receipt-audit.json
python3 -B CANDIDATE/handoff_cell/proof/verify_appraiser_receipt_probe.py \
  /tmp/slopos-handoff-output \
  --json /tmp/slopos-handoff-output/appraiser-receipt-host-audit.json
```

Read `spec/HANDOFF-CELL-V17.md` before reusing the result. V17 creates no
appraiser service, key enrollment, process registry, network acquisition,
READY, rights import, archive admission, provider operation, owner authority,
or epoch advance.

## V18 exact receipt spend and rollback counterproof

V18 binds the exact V17 message, detached signature, public key, decoded subject
fields, floor identity, and predecessor into the existing Generation Journal
`SpendRecordV1`. The envelope identity is a domain-separated SHA-256 over the
exact 384-byte message, 64-byte signature, and 32-byte public key; semantic
cross-binding is still required independently of that digest.

The pure campaign retains 56 ordered relation cases, 32 countermodels, and
6,656 exhaustive single-bit mutation rejections across the V17 envelope and
canonical 352-byte spend record. It permits exactly one compare-and-append
attempt, accepts only an exact content-bound `advanced` or `already_current`
response, and keeps duplicate, reopen, and lost-reply recovery query-only.

The Linux probe creates the floor before `fork()`. Two child histories both
advance the same exact predecessor, and a restored pre-spend copy advances
again. The parent history correctly makes its duplicate query-only. Thus V18
proves only one local receipt spend in one coherent history. It does not prove
an external rollback floor, restore continuity, clone exclusion, independent
appraiser custody, V13 eligibility, or authority. The host exposes no TPM or
IMA profile and V18 performs no network fallback.

The current reconstruction additionally runs:

```text
/tmp/slopos-handoff-build/slopos_appraiser_receipt_spend_probe \
  /tmp/slopos-handoff-output
python3 -B CANDIDATE/handoff_cell/proof/verify_appraiser_receipt_spend.py \
  /tmp/slopos-handoff-output \
  --json /tmp/slopos-handoff-output/appraiser-receipt-spend-audit.json
python3 -B CANDIDATE/handoff_cell/proof/verify_appraiser_receipt_spend_probe.py \
  /tmp/slopos-handoff-output \
  --json /tmp/slopos-handoff-output/appraiser-receipt-spend-host-audit.json
```

Read `spec/HANDOFF-CELL-V18.md` before reusing the result. V18 creates no
receipt database, monotonic-counter service, appraiser daemon, key service,
network client, READY transition, rights import, archive admission, provider
operation, owner authority, or epoch advance.


## V19 exact NV-extend transcript and dual-ledger fracture

V19 consumes the exact V18 spend-record head and evaluates one 58-premise
profile. It separates a TPM-resident cumulative content transition from a
witness expected-predecessor transition. A TPM counter is scalar only.
`TPM2_NV_Extend` binds old contents and supplied data, but it does not compare an
expected predecessor. `TPM2_NV_Certify` attests selected NV contents and Name;
it does not establish sole writer, non-restorable history, platform succession,
or external newestness.

The canonical 288-byte record binds profile identity, platform incarnation, NV
Name, predecessor head, V18 spend-record head, fresh witness challenge, witness
incarnation, and consecutive generation. The successor is
`SHA-256(predecessor || canonical-record)`. The exact public-area profile also
requires sufficient `TPM2B_MAX_NV_BUFFER` capacity and digest-sized extend-index
`dataSize`; the fixed record is not assumed to fit every implementation.

The corrected relation does **not** promote a full endpoint transcript into an
external floor. TPM extend and witness compare-and-advance are separate
irreversible mutations. A crash can leave either endpoint at successor while
the other remains at predecessor. Query-only observation can classify but not
converge the split. Reissuing the same extend after stale pre-certification
advances again because the command has no expected-old operand.

The pure campaign retains 62 cases, 44 countermodels, 2,304 record-bit mutation
rejections, and 2,816 V18-spend-input mutation rejections. Exactly one synthetic
row reaches `complete_dual_ledger_transcript_bound`; zero rows reach
`cross_ledger_atomic_join_bound`, query-only cross-ledger recovery, external
rollback floor, or V18 external-floor eligibility.

The Linux host probe retains 42 cases and 27 counterexamples. It executes both
fracture orderings, stable query-only nonconvergence, stale second-extend
advancement, and a happy path whose equal endpoint heads still do not close the
crash cuts. It also demonstrates that cloned/restored witness histories accept
the same predecessor and cloned Ed25519 state emits valid byte-identical
signatures.

This Linux 6.12.13 cloudtainer exposes no TPM device or required tpm2-tools
commands. It issues zero TPM commands and performs no network fallback. Archive
acquisition, READY, rights import, provider operation, owner authority, living
law, and epoch advance remain false.

The current reconstruction additionally runs:

```text
/tmp/slopos-handoff-build/slopos_external_rollback_floor_probe \
  /tmp/slopos-handoff-output
python3 -B CANDIDATE/handoff_cell/proof/verify_external_rollback_floor.py \
  /tmp/slopos-handoff-output \
  --json /tmp/slopos-handoff-output/external-floor-audit.json
python3 -B CANDIDATE/handoff_cell/proof/verify_external_rollback_floor_probe.py \
  /tmp/slopos-handoff-output \
  --json /tmp/slopos-handoff-output/external-floor-host-audit.json
```

Read `spec/HANDOFF-CELL-V19.md` before reusing this result. V19 creates no TPM
daemon, remote-witness client, network protocol, key service, receipt database,
provider runtime, owner membrane, or fourth semantic island.

## V20 single-ledger atomic join

V20 corrects the V19 two-ledger fracture by requiring one provider-native
transaction to compare the exact predecessor and atomically write the new
head, exact V18 spend, and exact pending entry in one serialization history.
The pure 46-premise relation retains 51 cases and 32 countermodels. Nine
synthetic prefixes bind the narrow atomic join; five also bind query-only
recovery; one full synthetic prefix supplies every independent external-floor
premise. No row operates a provider or grants authority.

The exact plan is inherited rather than reimagined: etcd v3.6.14, four
compares, three success writes, four linearizable failure/recovery queries. A
successful or ambiguous operation has no resubmit route.

A separate SQLite 3 rollback-journal laboratory retains 30 cases and 18
counterexamples. Seven abrupt process-death cuts reopen at either the exact old
state or the complete joined state, never a split. An eight-process race has
one local winner. Coherent clones and a restored pre-spend snapshot each spend
again, proving that local transaction atomicity is not external currentness,
rollback resistance, or portable one-use. The SQLite executable is test-only;
it is not linked into the candidate library and does not create a database
service or fourth semantic island.

The current reconstruction additionally runs:

```text
/tmp/slopos-handoff-build/slopos_single_ledger_join_campaign \
  /tmp/slopos-handoff-output
/tmp/slopos-handoff-build/slopos_single_ledger_join_probe \
  /tmp/slopos-handoff-output
python3 -B CANDIDATE/handoff_cell/proof/verify_single_ledger_join.py \
  /tmp/slopos-handoff-output \
  --json /tmp/slopos-handoff-output/single-ledger-audit.json
python3 -B CANDIDATE/handoff_cell/proof/verify_single_ledger_join_probe.py \
  /tmp/slopos-handoff-output \
  --json /tmp/slopos-handoff-output/single-ledger-host-audit.json
```

Read `spec/HANDOFF-CELL-V20.md` before reusing this result. V20 creates no etcd
client, database adapter, transaction daemon, repair worker, external witness,
provider runtime, owner membrane, or authority surface.

## V21 provider-incarnation and independent-reopen boundary

V21 adds a 63-premise ordered C++20 relation separating release metadata,
archive and binary admission, provider coordinates, administrative/restore
custody, the V20 transaction, quorum agreement, succession, and independent
reopen. The pure campaign retains 68 cases and 42 countermodels. One full row
is synthetic and does not operate a provider.

The hosted probe retains the official v3.6.14 Linux-amd64 checksum product and
the exact archive-transfer stop. Zero archive-body bytes are admitted and no
fallback is permitted. Two distinct child user namespaces remain inspectable
and terminable by one outer parent, demonstrating that namespace diversity is
not independent administration. The probe performs no provider or network
operation and grants no authority.

Read `spec/HANDOFF-CELL-V21.md` before reuse. V21 adds no downloader, etcd
client, provider runtime, transaction service, restore controller, owner
membrane, or fourth semantic island.

## V22 finite release-body capsule

V22 answers the V21 archive-transfer stop without adding a downloader or
substitute release source. It accepts only a finite canonical RFC 4648 record
inventory into one private bounded memfd. Session, index, index-derived offset,
exact decoded length, per-chunk SHA-256, complete nonoverlapping coverage,
whole-object SHA-256, and the complete write/grow/shrink/seal barrier are
separate cuts.

An identical duplicate is query-only and writes no byte. The first conflicting
or malformed record permanently poisons the session. There is no automatic
retry, parser-before-complete edge, mirror fallback, source-build path, or
last-writer-wins repair. Even the full positive fixture is only eligible for the
inherited V11 receiver-owned recapture, fresh seal, digest comparison, and
passive archive inspection.

The reconstruction additionally runs:

```text
slopos_release_body_capsule_campaign OUTPUT
slopos_release_body_capsule_probe OUTPUT
python3 -B proof/verify_release_body_capsule.py OUTPUT --json OUTPUT/release-capsule-audit.json
python3 -B proof/verify_release_body_capsule_probe.py OUTPUT --json OUTPUT/release-capsule-host-audit.json
```

The hosted probe uses 8,193 synthetic bytes in nine shuffled chunks. It receives
zero etcd archive bytes, parses no archive, performs no network operation,
operates no provider, and grants no authority. Read
`spec/HANDOFF-CELL-V22.md` and `DESIGN/TEXT-SAFE-RELEASE-BODY-CAPSULE.md` before
reusing the result.
