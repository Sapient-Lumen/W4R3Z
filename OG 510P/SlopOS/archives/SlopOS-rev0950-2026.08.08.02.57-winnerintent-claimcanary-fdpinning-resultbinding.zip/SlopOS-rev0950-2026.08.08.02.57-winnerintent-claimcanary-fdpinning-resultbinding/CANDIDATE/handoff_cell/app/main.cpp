#include "campaign.hpp"
#include "endpoint_publication_campaign.hpp"
#include "launch_query_campaign.hpp"

#include <filesystem>
#include <iostream>
#include <string_view>

int main(const int argc, char** argv) {
    using namespace slopos::e0::handoff_cell::harness;
    if (is_internal_endpoint_publication_worker(argc, argv)) {
        return run_internal_endpoint_publication_worker(argc, argv);
    }
    if (is_internal_launch_query_worker(argc, argv)) {
        return run_internal_launch_query_worker(argc, argv);
    }
    if (argc != 3 || std::string_view(argv[1]) != "campaign") {
        std::cerr << "usage: slopos_handoff_cell campaign OUTPUT\n";
        return 2;
    }
    try {
        return run_campaign(std::filesystem::path(argv[2]));
    } catch (const std::exception& error) {
        std::cerr << "HANDOFF_CELL_CAMPAIGN=FAIL detail=" << error.what() << '\n';
        return 1;
    }
}
