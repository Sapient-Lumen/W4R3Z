#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,json
from pathlib import Path
def fail(d:str)->None:raise SystemExit(f"APPRAISER_RECEIPT_SPEND_HOST_AUDIT=FAIL detail={d}")
def rows(p:Path)->list[dict[str,str]]:
 with p.open(newline="",encoding="utf-8") as s:return list(csv.DictReader(s,delimiter="\t"))
def truth(v:str)->bool:
 if v not in {"true","false"}:fail(f"bad boolean={v!r}")
 return v=="true"
def main()->int:
 ap=argparse.ArgumentParser();ap.add_argument('output',type=Path);ap.add_argument('--json',type=Path,required=True);a=ap.parse_args();cases=rows(a.output/'appraiser-receipt-spend-host-cases.tsv');counter=rows(a.output/'appraiser-receipt-spend-host-counterexamples.tsv');summary=json.loads((a.output/'appraiser-receipt-spend-host-summary.json').read_text())
 if len(cases)!=32 or len({r['case'] for r in cases})!=32:fail(f"case inventory={len(cases)}")
 if len(counter)!=18 or len({r['counterexample'] for r in counter})!=18:fail(f"counter inventory={len(counter)}")
 for r in cases:
  if truth(r['observed'])!=truth(r['expected']) or not truth(r['pass']):fail(f"host case={r['case']}")
 if not all(truth(r['reproduced']) for r in counter):fail('unreproduced counterexample')
 host=summary.pop('host_kernel_release',None)
 if not isinstance(host,str) or not host:fail(f"kernel={host!r}")
 expected={"appraiser_administration_root_distinct":False,"appraiser_input_custody_independent":False,"appraiser_key_custody_independent":False,"archive_body_bytes":0,"authority":False,"cases":32,"counterexamples_reproduced":18,"external_rollback_floor_bound":False,"first_clone_advanced":True,"ima_securityfs_present":False,"local_receipt_spend_bound":True,"network_attempted":False,"parent_duplicate_query_only":True,"parent_history_advanced":True,"portable_clone_replay_excluded":False,"ready_sent":False,"restored_copy_advanced":True,"rights_imported":False,"schema":"slopos.rev0906.appraiser-receipt-spend-host-probe.v18","second_clone_advanced":True,"status":"PASS","tpm0_present":False,"tpm2_getcap_available":False,"tpmrm0_present":False,"v13_actor_premise":False}
 if summary!=expected:fail(f"summary mismatch={summary}")
 audit={"appraiser_administration_root_distinct":False,"archive_body_bytes":0,"authority_granted":False,"cases":32,"clone_histories_advanced":2,"counterexamples":18,"external_rollback_floor_bound":False,"host_kernel_release":host,"local_receipt_spend_bound":True,"network_attempted":False,"portable_clone_replay_excluded":False,"restored_copy_advanced":True,"schema":"slopos.rev0906.appraiser-receipt-spend-host-audit.v18","status":"PASS","v13_actor_premise":False};a.json.write_text(json.dumps(audit,indent=2,sort_keys=True)+"\n");print("APPRAISER_RECEIPT_SPEND_HOST_AUDIT=PASS cases=32 counterexamples=18 local=true clone_advances=2 restore_replay=true external_floor=false v13=false authority=false");return 0
if __name__=='__main__':raise SystemExit(main())
