#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def fail(detail: str) -> None:
    raise SystemExit(f"SEALED_SNAPSHOT_OFFER_AUDIT=FAIL detail={detail}")


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def truth(value: str) -> bool:
    if value not in {"true", "false"}:
        fail(f"non-boolean value={value!r}")
    return value == "true"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()
    cases = rows(args.output / "sealed-snapshot-offer-cases.tsv")
    counter = rows(args.output / "sealed-snapshot-offer-counterexamples.tsv")
    summary = json.loads(
        (args.output / "sealed-snapshot-offer-summary.json").read_text(
            encoding="utf-8"))
    if len(cases) != 36:
        fail(f"case count={len(cases)}")
    if len(counter) != 20 or not all(truth(row["reproduced"]) for row in counter):
        fail("counterexample inventory")
    by_name = {row["case"]: row for row in cases}
    ready = [row for row in cases if truth(row["sealed_snapshot_source_ready"])]
    if [row["case"] for row in ready] != ["exact_admitted_sealed_offer"]:
        fail(f"ready rows={[row['case'] for row in ready]}")
    alias_reject = by_name.get("receiver_preoffer_candidate_alias_present")
    if alias_reject is None:
        fail("missing pre-offer alias rejection")
    if (truth(alias_reject["receiver_preoffer_candidate_aliases_zero"])
            or truth(alias_reject["acquisition_actor_admitted"])
            or truth(alias_reject["transport_envelope_ready"])
            or truth(alias_reject["candidate_descriptor_received"])):
        fail("pre-offer alias rejection crossed the ingress boundary")
    pre_reject = by_name.get("actor_not_admitted_before_ready")
    if pre_reject is None:
        fail("missing pre-receive actor rejection")
    if (truth(pre_reject["acquisition_actor_admitted"])
            or truth(pre_reject["transport_envelope_ready"])
            or truth(pre_reject["candidate_descriptor_received"])):
        fail("pre-receive actor rejection imported authority")
    cardinality = by_name.get("one_rights_record_multiple_descriptors")
    if cardinality is None:
        fail("missing rights descriptor cardinality row")
    if (cardinality["disposition"] != "ANCILLARY_SHAPE_REJECTED"
            or truth(cardinality["candidate_descriptor_received"])):
        fail("one rights record was conflated with one descriptor")
    if not any(row["counterexample"] ==
               "one_scm_rights_record_can_carry_multiple_descriptors"
               for row in counter):
        fail("missing rights cardinality counterexample")
    if not any(row["counterexample"] ==
               "fork_inheritance_can_preinstall_candidate_alias"
               for row in counter):
        fail("missing fork-inheritance alias counterexample")
    write_only = by_name.get("candidate_write_only")
    if write_only is None:
        fail("missing write-only sealed descriptor row")
    if (write_only["disposition"] != "CANDIDATE_DESCRIPTOR_NOT_READABLE"
            or truth(write_only["candidate_descriptor_readable"])
            or truth(write_only["sealed_descriptor_profile_ready"])
            or truth(write_only["sealed_snapshot_source_ready"])):
        fail("write-only sealed descriptor crossed the source boundary")
    if not any(row["counterexample"] ==
               "fully_sealed_write_only_descriptor_is_not_a_source"
               for row in counter):
        fail("missing write-only sealed descriptor counterexample")
    mechanism_only = [
        row for row in cases
        if truth(row["transport_envelope_ready"])
        and truth(row["sealed_descriptor_profile_ready"])
        and not truth(row["acquisition_actor_admitted"])
    ]
    if mechanism_only:
        fail(f"coherent mechanism-only rows={[row['case'] for row in mechanism_only]}")
    incoherent = [row for row in cases if not truth(row["observation_coherent"])]
    if len(incoherent) != 5:
        fail(f"incoherent count={len(incoherent)}")
    for name in (
        "incoherent_ready_with_preoffer_alias",
        "incoherent_ready_before_actor_admission",
        "incoherent_descriptor_import_before_actor_admission",
    ):
        if name not in by_name or truth(by_name[name]["observation_coherent"]):
            fail(f"post-receive authority import not rejected name={name}")
    mandatory_false = (
        "candidate_bytes_read", "archive_digest_compared", "archive_parsed",
        "one_use_transfer_proved", "exclusive_custody_proved",
        "candidate_memfd_creation_proved", "source_provenance_proved",
        "durable_media_proved", "activation_authority",
        "provider_operation_authority", "owner_custody_proved",
    )
    for row in cases:
        for field in mandatory_false:
            if truth(row[field]):
                fail(f"authority leak case={row['case']} field={field}")
    expected_summary = {
        "acquisition_actor_admission_external": True,
        "activation_authority": False,
        "actor_admission_precedes_ready": True,
        "admitted_ready_sources": 1,
        "archive_digest_compared": False,
        "archive_parsed": False,
        "candidate_bytes_read": False,
        "candidate_memfd_creation_proved": False,
        "candidate_readable_required": True,
        "cases": 36,
        "counterexamples_reproduced": 20,
        "exact_offer_frame": "SLOPOS-E0-SEALED-OFFER-V1",
        "exclusive_custody_proved": False,
        "incoherent_observations": 5,
        "mechanism_ready_actor_rejections": 0,
        "preoffer_alias_rejections": 1,
        "post_receive_authority_import_incoherences": 2,
        "pre_receive_actor_rejections": 1,
        "one_use_transfer_proved": False,
        "owner_custody_proved": False,
        "provider_operation_authority": False,
        "receiver_preoffer_candidate_aliases_zero_required": True,
        "required_seals": "F_SEAL_WRITE|F_SEAL_GROW|F_SEAL_SHRINK|F_SEAL_SEAL",
        "schema": "slopos.rev0901.sealed-snapshot-offer-campaign.v13",
        "socket_profile": "AF_UNIX/SOCK_SEQPACKET+SO_PASSCRED+SO_PASSPIDFD",
        "source_provenance_proved": False,
        "status": "PASS",
    }
    if summary != expected_summary:
        fail(f"summary mismatch={summary}")
    audit = {
        "acquisition_actor_admission_external": True,
        "activation_authority": False,
        "actor_admission_precedes_ready": True,
        "admitted_ready_sources": 1,
        "archive_digest_compared": False,
        "archive_parsed": False,
        "candidate_bytes_read": False,
        "candidate_memfd_creation_proved": False,
        "candidate_readable_required": True,
        "cases": 36,
        "counterexamples": 20,
        "exclusive_custody_proved": False,
        "incoherent_observations": 5,
        "mechanism_ready_actor_rejections": 0,
        "preoffer_alias_rejections": 1,
        "post_receive_authority_import_incoherences": 2,
        "pre_receive_actor_rejections": 1,
        "one_use_transfer_proved": False,
        "owner_custody_proved": False,
        "provider_operation_authority": False,
        "receiver_preoffer_candidate_aliases_zero_required": True,
        "required_seals_observed_in_exact_row": True,
        "schema": "slopos.rev0901.sealed-snapshot-offer-audit.v3",
        "source_provenance_proved": False,
        "status": "PASS",
    }
    args.json.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n",
                         encoding="utf-8")
    print("SEALED_SNAPSHOT_OFFER_AUDIT=PASS cases=36 counterexamples=20 admitted_ready=1 readable_required=true preoffer_alias_reject=1 pre_receive_reject=1 mechanism_only=0")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
