#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path, PurePosixPath


def fail(detail: str) -> None:
    raise SystemExit(f"ACTOR_EXEC_HOST_AUDIT=FAIL detail={detail}")


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def truth(value: str) -> bool:
    if value not in {"true", "false"}:
        fail(f"bad boolean={value!r}")
    return value == "true"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()

    cases = read_rows(args.output / "actor-exec-host-cases.tsv")
    counterexamples = read_rows(
        args.output / "actor-exec-host-counterexamples.tsv"
    )
    summary = json.loads(
        (args.output / "actor-exec-host-summary.json").read_text(
            encoding="utf-8"
        )
    )

    if len(cases) != 62 or not all(truth(row["pass"]) for row in cases):
        fail(f"case inventory={len(cases)}")
    if len(counterexamples) != 29 or not all(
        truth(row["reproduced"]) for row in counterexamples
    ):
        fail("counterexample inventory")
    if len({row["case"] for row in cases}) != len(cases):
        fail("duplicate case")
    for row in cases:
        if truth(row["observed"]) != truth(row["expected"]):
            fail(f"case expectation mismatch={row['case']}")

    by_name = {row["case"]: row for row in cases}
    required_true = {
        "procfs_self_image_fixture_only",
        "memfd_exec_intent_explicit",
        "sealed_executable_regular",
        "sealed_executable_readable",
        "sealed_executable_unlinked",
        "sealed_executable_size_bounded",
        "sealed_executable_profile_digest_exact",
        "sealed_executable_required_seals_present",
        "same_bytes_distinct_inode_counterproof",
        "single_threaded_launch_child",
        "private_file_table_until_exec",
        "private_address_space_until_exec",
        "challenge_endpoint_exclusive_to_tracee",
        "pidfd_open_before_release",
        "ptrace_established_before_release",
        "traceexec_armed_before_release",
        "ptrace_exitkill_armed",
        "execveat_entry_observed",
        "execveat_arch_exact",
        "execveat_empty_path",
        "execveat_flags_exact",
        "execveat_target_fd_exact",
        "exec_argument_memory_stable_until_consumed",
        "pidfd_getfd_supported",
        "target_descriptor_duplicated_while_stopped",
        "target_descriptor_regular",
        "target_same_inode_as_sealed_executable",
        "target_required_seals_present",
        "target_digest_exact",
        "exec_event_completes_observed_entry",
        "successful_exec_event_observed",
        "exactly_one_exec_event",
        "post_exec_setup_report",
        "challenge_generated_after_exec_event",
        "challenge_response_exact",
        "target_elf64_little_endian_x86_64",
        "target_pt_interp_present",
        "target_interpreter_path_absolute",
        "actor_effective_uid_nonroot",
        "actor_effective_gid_nonroot",
        "actor_supplementary_groups_empty",
        "actor_capabilities_empty",
        "actor_no_new_privs_enabled",
        "actor_seccomp_filter_installed",
        "actor_getppid_denied",
        "exec_input_object_bound",
    }
    required_false = {
        "interpreter_object_bound",
        "loaded_shared_objects_bound",
        "runtime_object_set_bound",
        "exec_epoch_held_through_actor_admission",
        "pre_exec_privilege_floor",
        "pre_exec_seccomp_filter",
        "network_syscalls_audited",
        "seccomp_filter_dump_exact",
        "pidfd_get_info_supported",
        "independent_appraiser_constituted",
        "complete_process_image_bound",
        "v14_dossier_admissible",
        "eligible_for_v13_actor_premise",
        "ready_sent",
        "rights_imported",
        "candidate_bytes_read",
    }
    for name in required_true:
        if name not in by_name or not truth(by_name[name]["observed"]):
            fail(f"required true={name}")
    for name in required_false:
        if name not in by_name or truth(by_name[name]["observed"]):
            fail(f"required false={name}")

    fixed = {
        "actor_capabilities_empty": True,
        "actor_effective_gid": 65534,
        "actor_effective_uid": 65534,
        "actor_no_new_privs_enabled": True,
        "actor_seccomp_filter_installed": True,
        "actor_supplementary_groups_empty": True,
        "archive_body_bytes": 0,
        "cases": 62,
        "challenge_endpoint_exclusive_to_tracee": True,
        "challenge_generated_after_exec_event": True,
        "challenge_response_exact": True,
        "child_address_space_private_until_exec": True,
        "child_file_table_private_until_exec": True,
        "complete_process_image_bound": False,
        "counterexamples_reproduced": 29,
        "eligible_for_v13_actor_premise": False,
        "exec_epoch_held_through_actor_admission": False,
        "exec_event_completes_observed_entry": True,
        "exec_events": 1,
        "exec_input_object_bound": True,
        "exec_argument_memory_stable_until_consumed": True,
        "execveat_arch_exact": True,
        "execveat_entry_observed": True,
        "execveat_flags_exact": True,
        "independent_appraiser_constituted": False,
        "interpreter_object_bound": False,
        "loaded_shared_objects_bound": False,
        "memfd_exec_intent_explicit": True,
        "network_syscalls_audited": False,
        "pidfd_get_info_supported": False,
        "pidfd_getfd_supported": True,
        "ptrace_exitkill_armed": True,
        "pre_exec_privilege_floor": False,
        "pre_exec_seccomp_filter": False,
        "ready_sent": False,
        "rights_imported": False,
        "runtime_object_set_bound": False,
        "schema": "slopos.rev0903.actor-exec-target-host-probe.v2",
        "seccomp_filter_dump_exact": False,
        "source_procfs_fixture_only": True,
        "status": "PASS",
        "target_digest_exact": True,
        "target_elf64_little_endian_x86_64": True,
        "target_pt_interp_present": True,
        "target_required_seals_present": True,
        "target_same_inode": True,
        "v14_dossier_admissible": False,
    }
    for key, value in fixed.items():
        if summary.get(key) != value:
            fail(f"summary {key}={summary.get(key)!r}")

    if summary.get("filter_length") != -1:
        fail(f"filter length={summary.get('filter_length')!r}")

    interpreter_path = summary.get("interpreter_path")
    if not isinstance(interpreter_path, str) or not interpreter_path:
        fail("interpreter path missing")
    if not PurePosixPath(interpreter_path).is_absolute():
        fail(f"interpreter path not absolute={interpreter_path!r}")
    if summary.get("filter_dump_errno") not in {"EINVAL", "EPERM", "EACCES"}:
        fail(f"filter errno={summary.get('filter_dump_errno')!r}")
    if summary.get("pidfd_get_info_errno") not in {
        "EINVAL",
        "ENOTTY",
        "ENOSYS",
    }:
        fail(f"pidfd info errno={summary.get('pidfd_get_info_errno')!r}")

    audit = {
        "archive_body_bytes": 0,
        "capabilities_empty": True,
        "cases": 62,
        "complete_process_image_bound": False,
        "counterexamples": 29,
        "exec_epoch_held": False,
        "exec_input_object_bound": True,
        "independent_appraiser_constituted": False,
        "memfd_exec_intent_explicit": True,
        "network_syscalls_audited": False,
        "no_new_privs": True,
        "nonroot": True,
        "pidfd_get_info_supported": False,
        "pidfd_getfd_supported": True,
        "ptrace_exitkill_armed": True,
        "pre_exec_privilege_floor": False,
        "pre_exec_seccomp_filter": False,
        "ready_sent": False,
        "rights_imported": False,
        "runtime_object_set_bound": False,
        "schema": "slopos.rev0903.actor-exec-target-host-audit.v3",
        "seccomp_filter_dump_exact": False,
        "seccomp_filter_installed": True,
        "status": "PASS",
        "target_pt_interp_present": True,
        "v13_eligible": False,
        "v14_dossier_admissible": False,
    }
    args.json.write_text(
        json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(
        "ACTOR_EXEC_HOST_AUDIT=PASS cases=62 counterexamples=29 "
        "exec_input_bound=true pt_interp=true runtime_bound=false "
        "complete_image=false filter_dump=false pidfd_get_info=false "
        "appraiser=false v13=false network_audited=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
