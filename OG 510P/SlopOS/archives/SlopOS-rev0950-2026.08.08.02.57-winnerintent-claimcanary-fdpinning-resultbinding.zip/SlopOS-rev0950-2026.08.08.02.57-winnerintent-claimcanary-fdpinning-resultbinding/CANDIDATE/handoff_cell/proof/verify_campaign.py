#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

EXPECTED_CASES = {
    "exact_identity": ("BOUND_SYNCED", "EXACT_PENDING", "false", "true", "1", "false"),
    "malformed_burns_before_decode": ("BOUND_SYNCED", "DECODE_REJECTED", "false", "true", "1", "false"),
    "fifo_burns_then_fails_nonregular": ("BOUND_SYNCED", "NOT_REGULAR", "false", "true", "1", "false"),
    "pending_no_replace_conflict": ("PENDING_EXISTS", "NOT_QUERIED", "true", "true", "0", "false"),
    "missing_live_no_mint": ("LIVE_MISSING", "NOT_QUERIED", "false", "false", "0", "false"),
    "crash_before_admission_call": ("NOT_CALLED", "NOT_QUERIED", "true", "false", "0", "false"),
    "crash_after_burn_and_sync_return": ("BOUND_SYNCED", "EXACT_PENDING", "false", "true", "1", "false"),
    "crash_after_exact_readback": ("BOUND_SYNCED", "EXACT_PENDING", "false", "true", "1", "false"),
    "sixteen_process_race": ("ONE_BOUND_REST_REJECTED", "EXACT_PENDING", "false", "true", "1", "false"),
    "hardlink_alias_survives": ("BOUND_SYNCED", "ALIAS_DETECTED", "false", "true", "1", "true"),
    "open_writer_survives_rename": ("BOUND_SYNCED", "EXACT_MISMATCH", "false", "true", "1", "true"),
    "coherent_snapshot_rollback": ("BOUND_SYNCED", "LOCAL_PREBURN_SHAPE_REPRODUCED", "true", "false", "1", "true"),
}

EXPECTED_COUNTEREXAMPLES = {
    "hard_link_alias_survives_rename",
    "open_writable_fd_survives_rename",
    "coherent_local_snapshot_rollback",
}

EXPECTED_PRINCIPAL_CASES = {
    "provider_creates_fixed_owner_only_cell": ("true", "false"),
    "distinct_workload_cannot_open_provider_root": ("true", "false"),
    "distinct_workload_cannot_open_pending_leaf": ("true", "false"),
    "distinct_workload_cannot_link_rename_or_unlink": ("true", "false"),
    "same_uid_peer_can_chmod_and_mutate": ("true", "true"),
    "inherited_writable_fd_survives_uid_drop": ("true", "true"),
    "root_equivalent_actor_bypasses_owner_only_mode": ("true", "true"),
}

EXPECTED_PUBLICATION_CASES = {
    "append_uncertain_result_v1": ("BOUND_SYNCED", "EXACT", "1"),
    "publish_uncertain_v1_after_result": ("BOUND_SYNCED", "EXACT", "1"),
    "append_exact_result_v2_after_uncertain_v1": ("BOUND_SYNCED", "EXACT", "2"),
    "publish_exact_v2_after_publication_v1": ("BOUND_SYNCED", "EXACT", "2"),
    "duplicate_result_v1_fails_no_replace": ("FINAL_EXISTS", "EXACT", "1"),
    "result_v2_without_v1_fails_stop": ("MISSING_PREDECESSOR", "NOT_QUERIED", "2"),
    "publication_without_result_fails_stop": ("MISSING_PREDECESSOR", "NOT_QUERIED", "1"),
    "exact_v1_cannot_be_rewritten_as_v2": ("REFINEMENT_REJECTED", "V1_RETAINED", "2"),
    "staging_residue_requires_separate_repair": ("STAGE_EXISTS", "NO_MUTATING_RECOVERY", "1"),
    "publication_record_rejected_by_result_api": ("WRONG_RECORD_KIND", "NOT_QUERIED", "1"),
}

EXPECTED_PRINCIPAL_COUNTEREXAMPLES = {
    "same_uid_peer_mutates_owner_file",
    "writable_descriptor_survives_uid_drop",
    "root_equivalent_actor_bypasses_dac",
}



EXPECTED_LAUNCH_QUERY_CASES = {
    "provider_exec_descriptor_table_exact": ("true", "false"),
    "query_exec_descriptor_table_exact": ("true", "false"),
    "ambient_descriptors_closed_with_close_range_unshare": ("true", "false"),
    "provider_credential_and_capability_floor": ("true", "false"),
    "query_credential_and_capability_floor": ("true", "false"),
    "precreated_so_peercred_reports_root_creator": ("true", "true"),
    "passcred_ready_authenticates_current_provider_message": ("true", "false"),
    "valid_query_authenticates_current_query_sender": ("true", "false"),
    "fixed_query_returns_exact_result_v2": ("true", "false"),
    "unprivileged_scm_credential_forgery_is_denied": ("true", "false"),
    "scm_rights_injection_is_rejected_and_closed": ("true", "true"),
    "malformed_query_message_is_rejected": ("true", "false"),
    "wrong_uid_query_is_rejected": ("true", "false"),
    "silent_query_is_time_bounded": ("true", "false"),
    "incorrect_close_range_start_retains_fd7": ("true", "true"),
}

EXPECTED_LAUNCH_QUERY_COUNTEREXAMPLES = {
    "so_peercred_freezes_socketpair_creator_credentials",
    "scm_rights_arrives_before_query_validation",
    "off_by_one_close_range_preserves_ambient_descriptor",
}

EXPECTED_ENDPOINT_PUBLICATION_CASES = {
    "provider_prebind_descriptor_table_exact": ("true", "false"),
    "provider_binds_only_after_final_principal": ("true", "false"),
    "provider_binds_fixed_stage_without_unlink": ("true", "false"),
    "bound_socket_inode_moves_to_public_leaf": ("true", "false"),
    "public_directory_is_publisher_custody": ("true", "false"),
    "provider_cannot_unlink_public_endpoint": ("true", "false"),
    "sealed_expected_provider_record_is_immutable": ("true", "false"),
    "expected_provider_capsule_is_addressed_to_query": ("true", "false"),
    "expected_provider_capsule_is_burned_before_connect": ("true", "false"),
    "connected_provider_matches_consumed_expectation": ("true", "false"),
    "root_harness_self_mints_matching_sealed_expectation": ("true", "true"),
    "expectation_record_and_pidfd_are_duplicable": ("true", "true"),
    "query_preconnect_descriptor_table_exact": ("true", "false"),
    "query_connects_only_after_noreplace_publication": ("true", "false"),
    "renamed_listener_accepts_public_connection": ("true", "false"),
    "query_connect_time_peer_is_provider": ("true", "false"),
    "provider_accept_time_peer_is_query": ("true", "false"),
    "query_connect_peer_pidfd_is_provider_process": ("true", "false"),
    "provider_accept_peer_pidfd_is_query_process": ("true", "false"),
    "message_credentials_agree_with_connect_peers": ("true", "false"),
    "request_message_pidfd_agrees_with_accepted_peer": ("true", "false"),
    "response_message_pidfd_agrees_with_connected_peer": ("true", "false"),
    "fixed_query_returns_exact_result_v2_over_fresh_connection": ("true", "false"),
    "scm_rights_is_rejected_and_closed_before_bytes": ("true", "false"),
    "malformed_message_is_rejected": ("true", "false"),
    "wrong_uid_connection_is_rejected_at_accept": ("true", "false"),
    "peer_pidfd_observes_provider_exit": ("true", "false"),
    "provider_death_leaves_stale_public_leaf": ("true", "false"),
    "stale_endpoint_connect_fails_closed": ("true", "false"),
    "fresh_provider_can_bind_private_stage_behind_stale_public": ("true", "false"),
    "stale_public_leaf_blocks_noreplace_restart": ("true", "false"),
    "privileged_publisher_can_cleanup_and_republish": ("true", "true"),
    "privileged_republication_exposes_distinct_provider_process": ("true", "true"),
    "socketpair_peerpidfd_freezes_creator_while_message_pidfd_tracks_sender": ("true", "true"),
    "provider_owned_directory_allows_same_uid_live_replacement": ("true", "true"),
}

EXPECTED_ENDPOINT_PUBLICATION_COUNTEREXAMPLES = {
    "socketpair_peerpidfd_identifies_creator_not_forked_sender",
    "replacement_pidfd_is_distinct_but_not_admitted",
    "same_uid_restart_replaces_live_endpoint_in_writable_directory",
    "stale_public_leaf_requires_separate_recovery_authority",
    "root_publisher_can_replace_endpoint_epoch",
    "sealed_expected_process_is_root_self_assertion",
    "duplicated_capsule_escapes_actor_local_one_use",
}

def fail(detail: str) -> None:
    raise SystemExit(f"HANDOFF_CELL_AUDIT=FAIL detail={detail}")


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))



def verify_abstract_refinement() -> dict[str, object]:
    """Exhaust the small split and no-replace handoff relations independently.

    The split observer is the rev0886 local journal projection: pending absent
    does not distinguish unspent from spent-before-bind. The no-replace relation
    relies on the documented kernel rename contract and has no reachable empty
    namespace state between LIVE and PENDING. Alias, writer, and rollback
    countermodels remain outside that local relation and keep protection false.
    """
    split_states = {
        ("UNSPENT", True, False),
        ("SPENT_BEFORE_BIND", False, False),
        ("SPENT_BOUND", False, True),
    }
    empty_journal_histories = {
        authority for authority, _live, pending in split_states if not pending
    }
    if empty_journal_histories != {"UNSPENT", "SPENT_BEFORE_BIND"}:
        fail("split ambiguity construction")

    no_replace_states = {
        ("UNSPENT", True, False),
        ("SPENT_BOUND", False, True),
    }
    empty_no_replace_states = [
        state for state in no_replace_states if not state[1] and not state[2]
    ]
    if empty_no_replace_states:
        fail("no-replace empty intermediate")
    if any(live == pending for _authority, live, pending in no_replace_states):
        fail("no-replace live-pending partition")

    countermodels = {"hard_link_alias", "open_writable_fd", "coherent_rollback"}
    if len(countermodels) != 3:
        fail("protected identity countermodel inventory")
    return {
        "no_replace_empty_intermediate_states": 0,
        "no_replace_reachable_states": len(no_replace_states),
        "no_replace_live_pending_partition": True,
        "kernel_atomicity_contract_relied_on": True,
        "protected_identity_countermodels": len(countermodels),
        "split_ambiguous_observation_classes": 1,
        "split_empty_journal_histories": len(empty_journal_histories),
        "split_reachable_states": len(split_states),
    }

def verify_launch_refinement() -> dict[str, object]:
    """Exhaust the finite descriptor/credential distinctions used by V3.

    This is not a kernel proof. It checks that the claimed abstract relation
    has no accidental equivalence between an exact table and the retained
    off-by-one table, and that creation-time and message-time credentials are
    distinct coordinates.
    """
    ambient = set(range(0, 20))

    def after_exec(required: set[int], close_first: int,
                   explicitly_closed: set[int] | None = None) -> set[int]:
        staged = {descriptor for descriptor in ambient if descriptor < close_first}
        staged -= explicitly_closed or set()
        staged |= required
        staged.discard(3)  # executable descriptor is CLOEXEC
        return staged

    provider_required = {0, 1, 2, 3, 4, 5, 6}
    query_required = {0, 1, 2, 3, 5, 6}
    provider_exact = after_exec(provider_required, 7)
    query_exact = after_exec(query_required, 7, {4})
    provider_bad = after_exec(provider_required | {7}, 8)
    if provider_exact != {0, 1, 2, 4, 5, 6}:
        fail("provider descriptor refinement")
    if query_exact != {0, 1, 2, 5, 6}:
        fail("query descriptor refinement")
    if provider_bad != provider_exact | {7}:
        fail("off-by-one descriptor countermodel")

    creation_credential = (0, 0)
    provider_message_credential = (21001, 21001)
    query_message_credential = (21003, 21003)
    if creation_credential in {
        provider_message_credential, query_message_credential
    }:
        fail("credential coordinate collapse")

    rights_path = (
        "RECVMSG_INSTALL_RIGHT",
        "AUTHENTICATE_CREDENTIAL",
        "CLOSE_RIGHT",
        "REJECT_CONTROL_SURPLUS",
    )
    if "PARSE_PAYLOAD" in rights_path:
        fail("rights path parsed payload")
    if rights_path.index("CLOSE_RIGHT") > rights_path.index(
            "REJECT_CONTROL_SURPLUS"):
        fail("rights closure ordering")

    return {
        "creation_time_message_time_credentials_distinct": True,
        "off_by_one_extra_descriptors": len(provider_bad - provider_exact),
        "provider_post_exec_descriptors": sorted(provider_exact),
        "query_post_exec_descriptors": sorted(query_exact),
        "rights_rejection_parses_payload": False,
    }



def verify_endpoint_publication_refinement() -> dict[str, object]:
    """Exhaust the small endpoint-name custody relation independently.

    The model distinguishes listener creation, public-name publication, and
    cleanup authority. It intentionally admits publisher replacement and
    rejects the false inference that bind-after-drop alone constitutes a fresh
    endpoint epoch.
    """
    provider_owned_transitions = {
        ("OLD_LISTENER_NAMED", "SAME_UID_UNLINK", "OLD_LISTENER_NAMELESS"),
        ("OLD_LISTENER_NAMELESS", "SAME_UID_BIND", "NEW_LISTENER_NAMED"),
    }
    if len(provider_owned_transitions) != 2:
        fail("provider-owned endpoint transition inventory")

    split_states = {
        ("NO_PUBLIC", "FRESH_STAGE"),
        ("PUBLIC_OLD", "FRESH_STAGE"),
        ("PUBLIC_FRESH", "NO_STAGE"),
    }
    provider_actions = {"BIND_STAGE", "ACCEPT", "CLOSE_LISTENER"}
    publisher_actions = {"PUBLISH_NOREPLACE", "CLEANUP_PUBLIC"}
    if provider_actions & {"UNLINK_PUBLIC", "RENAME_PUBLIC"}:
        fail("provider public mutation leaked into abstract surface")
    if "CLEANUP_PUBLIC" not in publisher_actions:
        fail("publisher administration countermodel missing")
    collision = ("PUBLIC_OLD", "FRESH_STAGE")
    if collision not in split_states:
        fail("stale collision state missing")
    no_replace_successors = {
        ("NO_PUBLIC", "FRESH_STAGE"): ("PUBLIC_FRESH", "NO_STAGE"),
        ("PUBLIC_OLD", "FRESH_STAGE"): ("PUBLIC_OLD", "FRESH_STAGE"),
    }
    if no_replace_successors[collision] != collision:
        fail("no-replace collision did not preserve both names")

    return {
        "automatic_cleanup_transitions": 0,
        "bind_and_publication_authorities_distinct": True,
        "connect_time_credentials_are_epoch_tokens": False,
        "provider_public_mutation_actions": 0,
        "publisher_cleanup_authority_open": True,
        "same_uid_writable_directory_replacement_path_length": 2,
        "split_custody_states": len(split_states),
        "stale_collision_is_fixed_point_under_noreplace": True,
    }

def verify_endpoint_process_refinement() -> dict[str, object]:
    """Exhaust the finite process-reference distinctions used by V6.

    This relation deliberately separates a host-stable process instance from an
    owner-admitted provider epoch.  Equality of connect-time and per-message
    pidfds narrows sender substitution on one connection; it does not select
    which process the owner intended, close privileged credential selection, or
    turn a replacement process into an authorized successor.
    """
    creator = "CREATOR_PROCESS"
    query = "QUERY_PROCESS"
    provider_first = "PROVIDER_PROCESS_1"
    provider_second = "PROVIDER_PROCESS_2"

    pathname_connection = {
        "query_peer": provider_first,
        "provider_peer": query,
        "request_sender": query,
        "response_sender": provider_first,
    }
    if pathname_connection["query_peer"] != pathname_connection["response_sender"]:
        fail("provider connect/message pidfd disagreement")
    if pathname_connection["provider_peer"] != pathname_connection["request_sender"]:
        fail("query accept/message pidfd disagreement")

    socketpair = {"peer_at_creation": creator, "later_sender": query}
    if socketpair["peer_at_creation"] == socketpair["later_sender"]:
        fail("socketpair creator/sender countermodel collapsed")

    replacement = {
        "fixed_uid": 21001,
        "fixed_path": "query.sock",
        "first_process": provider_first,
        "second_process": provider_second,
    }
    if replacement["first_process"] == replacement["second_process"]:
        fail("replacement process identities collapsed")

    external_expectation = {
        "record_sealed": True,
        "expected_process": provider_first,
        "actor_state": "FRESH",
        "constructor": "ROOT_HARNESS",
    }
    duplicate_expectations = [dict(external_expectation), dict(external_expectation)]
    external_expectation["actor_state"] = "SPENT_BEFORE_CONNECT"
    if any(item["actor_state"] != "FRESH" for item in duplicate_expectations):
        fail("actor-local spend unexpectedly consumed duplicates")
    if external_expectation["expected_process"] != pathname_connection["query_peer"]:
        fail("expected provider process did not constrain connected peer")

    admitted_provider_processes: set[str] = set()
    if (provider_first in admitted_provider_processes
            or provider_second in admitted_provider_processes):
        fail("host observation accidentally became owner admission")

    return {
        "actor_local_expectation_states": 2,
        "capsule_duplicates_before_spend": len(duplicate_expectations),
        "connect_message_process_agreement_required": True,
        "expected_process_match_required": True,
        "expectation_constructor_protected": False,
        "expectation_record_immutable": True,
        "globally_unique_expectation_spend_proved": False,
        "owner_admitted_provider_processes": len(admitted_provider_processes),
        "peer_pidfd_exported_as_mutation_authority": False,
        "pidfd_exit_observation_changes_process_identity": False,
        "privileged_scm_pid_selection_closed": False,
        "process_instance_is_endpoint_epoch": False,
        "replacement_process_instances": 2,
        "same_uid_path_distinct_process_instances": 2,
        "socketpair_creation_sender_identity_distinct": True,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Independently check the handoff-cell campaign products.")
    parser.add_argument("campaign", type=Path)
    parser.add_argument("--json", required=True, type=Path)
    args = parser.parse_args()
    campaign = args.campaign.resolve()

    required = {
        "cases.tsv", "counterexamples.tsv", "cut-trace.tsv", "summary.json",
        "principal-cases.tsv", "publication-cases.tsv",
        "principal-counterexamples.tsv", "principal-summary.json",
        "launch-query-cases.tsv", "launch-query-counterexamples.tsv",
        "launch-query-summary.json",
        "endpoint-publication-cases.tsv",
        "endpoint-publication-counterexamples.tsv",
        "endpoint-publication-summary.json",
        "sealed-snapshot-offer-cases.tsv",
        "sealed-snapshot-offer-counterexamples.tsv",
        "sealed-snapshot-offer-summary.json",
        "acquisition-actor-cases.tsv",
        "acquisition-actor-counterexamples.tsv",
        "acquisition-actor-summary.json",
        "actor-exec-cases.tsv",
        "actor-exec-counterexamples.tsv",
        "actor-exec-summary.json",
        "external-floor-cases.tsv",
        "external-floor-counterexamples.tsv",
        "external-floor-summary.json",
    }
    observed = {path.name for path in campaign.iterdir() if path.is_file()}
    if not required <= observed:
        fail(f"missing={sorted(required - observed)}")

    summary = json.loads((campaign / "summary.json").read_text(encoding="utf-8"))
    exact_summary = {
        "schema": "slopos.rev0907.handoff-cell-campaign.v19",
        "status": "PASS",
        "acquisition_actor_cases": 28,
        "acquisition_actor_counterexamples": 18,
        "acquisition_actor_admissible_profiles": 1,
        "acquisition_actor_host_applicable_profiles": 0,
        "acquisition_actor_incoherent_observations": 1,
        "actor_exec_cases": 51,
        "actor_exec_counterexamples": 32,
        "actor_exec_exec_input_bound_profiles": 14,
        "actor_exec_runtime_object_set_bound_profiles": 13,
        "actor_exec_exec_epoch_held_profiles": 12,
        "actor_exec_pre_exec_floor_bound_profiles": 10,
        "actor_exec_v13_eligible_profiles": 1,
        "appraiser_receipt_spend_cases": 56,
        "appraiser_receipt_spend_counterexamples": 32,
        "appraiser_receipt_spend_canonical_cross_bound_profiles": 35,
        "appraiser_receipt_spend_content_bound_profiles": 25,
        "appraiser_receipt_spend_local_profiles": 18,
        "appraiser_receipt_spend_external_floor_profiles": 8,
        "appraiser_receipt_spend_external_profiles": 1,
        "appraiser_receipt_spend_mutation_rejections": 6656,
        "external_floor_cases": 62,
        "external_floor_counterexamples": 44,
        "external_floor_exact_profile_profiles": 38,
        "external_floor_v18_spend_profiles": 34,
        "external_floor_prestate_certified_profiles": 27,
        "external_floor_extend_request_profiles": 21,
        "external_floor_poststate_certified_profiles": 16,
        "external_floor_witness_advanced_profiles": 11,
        "external_floor_query_only_profiles": 7,
        "external_floor_complete_transcript_profiles": 1,
        "external_floor_cross_ledger_join_profiles": 0,
        "external_floor_bound_profiles": 0,
        "external_floor_mutation_rejections": 5120,
        "cases": 12,
        "counterexamples": 3,
        "canonical_record_bytes": 128,
        "decode_before_burn_calls": 0,
        "maximum_successful_bind_count": 1,
        "successful_race_binds": 1,
        "principal_cases": 7,
        "principal_counterexamples": 3,
        "process_crash_cuts": 3,
        "campaign_alone_proves_kernel_atomicity": False,
        "kernel_rename_atomicity_contract_relied_on": True,
        "process_visible_namespace_partition_observed": True,
        "writer_custody_counterexample_reproduced": True,
        "rollback_counterexample_reproduced": True,
        "recovery_apply_entrypoints": 0,
        "protected_spent_identity": False,
        "stable_media_proved": False,
        "physical_power_loss_proved": False,
        "external_rollback_floor": False,
        "independent_actor": False,
        "launch_query_cases": 15,
        "launch_query_counterexamples": 3,
        "endpoint_publication_cases": 35,
        "endpoint_publication_counterexamples": 7,
        "etcd_profile_cases": 19,
        "etcd_profile_counterexamples": 7,
        "etcd_profile_exact_current_observations": 5,
        "etcd_profile_operated": False,
        "etcd_profile_synthetic_runtime_observations": 18,
        "endpoint_claim_cases": 14,
        "endpoint_claim_counterexamples": 4,
        "endpoint_claim_crash_cuts": 4,
        "endpoint_claim_race_contenders": 16,
        "hosted_settlement_adapter_implemented": True,
        "settlement_cases": 14,
        "settlement_counterexamples": 4,
        "settlement_crash_cuts": 4,
        "settlement_race_contenders": 16,
        "settlement_race_local_claims": 16,
        "settlement_race_provider_fresh_commits": 1,
        "settlement_race_provider_duplicates": 15,
        "settlement_race_effects": 1,
        "settlement_response_authority": False,
        "settlement_retry_authority": False,
        "release_ingress_activation_authority": False,
        "release_ingress_activation_boundary_violations": 2,
        "release_ingress_cases": 17,
        "release_ingress_counterexamples": 9,
        "release_ingress_exact_passive_admissions": 2,
        "release_ingress_incoherent_observations": 1,
        "release_ingress_path_replacement_admissions": 1,
        "release_ingress_snapshot_write_seal_required": True,
        "rooted_release_cases": 24,
        "rooted_release_counterexamples": 11,
        "rooted_release_ready_descriptors": 2,
        "rooted_release_path_replacement_ready_descriptors": 1,
        "rooted_release_root_path_reopen_rejections": 1,
        "rooted_release_owner_custody_proved": False,
        "sealed_snapshot_offer_cases": 36,
        "sealed_snapshot_offer_counterexamples": 20,
        "sealed_snapshot_offer_admitted_ready_sources": 1,
        "sealed_snapshot_offer_mechanism_ready_actor_rejections": 0,
        "sealed_snapshot_offer_preoffer_alias_rejections": 1,
        "sealed_snapshot_offer_pre_receive_actor_rejections": 1,
        "sealed_snapshot_offer_post_receive_authority_import_incoherences": 2,
        "expected_provider_capsule_bytes": 96,
        "expected_provider_process_input_observed": True,
        "expected_provider_process_spent_before_connect": True,
        "expectation_constructor_protected": False,
        "globally_unique_expectation_spend_proved": False,
        "owner_admitted_provider_process": False,
        "source_to_binary_proved": False,
        "authority_granted": False,
        "fixed_live_leaf": "live",
        "fixed_pending_leaf": "pending",
        "publication_cases": 10,
        "provider_principal_observed": True,
        "rename_flag": "RENAME_NOREPLACE",
    }
    for key, expected in exact_summary.items():
        if summary.get(key) != expected:
            fail(f"summary {key} expected={expected!r} observed={summary.get(key)!r}")

    rows = read_tsv(campaign / "cases.tsv")
    if len(rows) != len(EXPECTED_CASES):
        fail(f"case_count={len(rows)}")
    by_name = {row["case"]: row for row in rows}
    if set(by_name) != set(EXPECTED_CASES):
        fail(f"case_inventory={sorted(by_name)}")
    disagreements = 0
    for name, expected in EXPECTED_CASES.items():
        row = by_name[name]
        observed_tuple = (
            row["burn"], row["validation"], row["live"], row["pending"],
            row["successful_binds"], row["retained_counterexample"],
        )
        if observed_tuple != expected:
            disagreements += 1
        expected_process_death = "true" if name in {
            "crash_before_admission_call",
            "crash_after_burn_and_sync_return",
            "crash_after_exact_readback",
        } else "false"
        if row["process_death_cut"] != expected_process_death:
            disagreements += 1
    if disagreements:
        fail(f"case_disagreements={disagreements}")
    if by_name["sixteen_process_race"]["contenders"] != "16":
        fail("race contender count")

    counterexamples = read_tsv(campaign / "counterexamples.tsv")
    if {row["counterexample"] for row in counterexamples} != EXPECTED_COUNTEREXAMPLES:
        fail("counterexample inventory")
    if any(row["reproduced"] != "true" for row in counterexamples):
        fail("counterexample not reproduced")

    principal_summary = json.loads(
        (campaign / "principal-summary.json").read_text(encoding="utf-8"))
    expected_principal_summary = {
        "schema": "slopos.rev0888.handoff-principal-publication.v1",
        "status": "PASS",
        "principal_cases": 7,
        "publication_cases": 10,
        "counterexamples": 3,
        "provider_uid": 21001,
        "workload_uid": 21002,
        "distinct_uid_path_attacks_denied": True,
        "no_new_privs_observed": True,
        "immutable_publication_versions_observed": 2,
        "descriptor_topology_proved": False,
        "root_equivalent_administration_excluded": False,
        "stable_media_proved": False,
        "external_rollback_floor": False,
        "authenticated_provider": False,
        "authority_granted": False,
        "cloudtainer_role": "HOST_LAB_ONLY",
        "fixed_cell_leaf": "cell",
    }
    for key, expected in expected_principal_summary.items():
        if principal_summary.get(key) != expected:
            fail(f"principal summary {key} expected={expected!r} "
                 f"observed={principal_summary.get(key)!r}")

    principal_rows = read_tsv(campaign / "principal-cases.tsv")
    principal_by_name = {row["case"]: row for row in principal_rows}
    if set(principal_by_name) != set(EXPECTED_PRINCIPAL_CASES):
        fail("principal case inventory")
    for name, expected in EXPECTED_PRINCIPAL_CASES.items():
        row = principal_by_name[name]
        if (row["passed"], row["retained_counterexample"]) != expected:
            fail(f"principal case mismatch {name}")

    publication_rows = read_tsv(campaign / "publication-cases.tsv")
    publication_by_name = {row["case"]: row for row in publication_rows}
    if set(publication_by_name) != set(EXPECTED_PUBLICATION_CASES):
        fail("publication case inventory")
    for name, expected in EXPECTED_PUBLICATION_CASES.items():
        row = publication_by_name[name]
        if (row["append"], row["query"], row["version"]) != expected:
            fail(f"publication case mismatch {name}")

    principal_counterexamples = read_tsv(
        campaign / "principal-counterexamples.tsv")
    if {row["counterexample"] for row in principal_counterexamples} \
            != EXPECTED_PRINCIPAL_COUNTEREXAMPLES:
        fail("principal counterexample inventory")
    if any(row["reproduced"] != "true" for row in principal_counterexamples):
        fail("principal counterexample not reproduced")

    launch_summary = json.loads(
        (campaign / "launch-query-summary.json").read_text(encoding="utf-8"))
    expected_launch_summary = {
        "schema": "slopos.rev0889.handoff-launch-query-evidence.v1",
        "status": "PASS",
        "cases": 15,
        "counterexamples_reproduced": 3,
        "provider_uid": 21001,
        "query_uid": 21003,
        "wrong_query_uid": 21002,
        "bounded_query_timeout_milliseconds": 250,
        "exact_descriptor_tables_observed": 2,
        "close_range_unshare_used": True,
        "execveat_empty_path_used": True,
        "capability_bounding_set_empty": True,
        "so_peercred_creation_time_counterexample": True,
        "scm_credentials_per_message_observed": True,
        "scm_rights_injection_rejected": True,
        "exact_result_v2_returned": True,
        "fixed_query_mutation_entrypoints": 0,
        "privileged_credential_forgery_closed": False,
        "administration_plane_closed": False,
        "provider_authenticated": False,
        "stable_media_proved": False,
        "source_to_binary_proved": False,
        "independent_actor": False,
        "authority_granted": False,
    }
    for key, expected in expected_launch_summary.items():
        if launch_summary.get(key) != expected:
            fail(f"launch summary {key} expected={expected!r} "
                 f"observed={launch_summary.get(key)!r}")

    launch_rows = read_tsv(campaign / "launch-query-cases.tsv")
    launch_by_name = {row["name"]: row for row in launch_rows}
    if set(launch_by_name) != set(EXPECTED_LAUNCH_QUERY_CASES):
        fail("launch-query case inventory")
    for name, expected in EXPECTED_LAUNCH_QUERY_CASES.items():
        row = launch_by_name[name]
        if (row["passed"], row["retained_counterexample"]) != expected:
            fail(f"launch-query case mismatch {name}")

    launch_counterexamples = read_tsv(
        campaign / "launch-query-counterexamples.tsv")
    if {row["name"] for row in launch_counterexamples} \
            != EXPECTED_LAUNCH_QUERY_COUNTEREXAMPLES:
        fail("launch-query counterexample inventory")
    if any(row["reproduced"] != "true" for row in launch_counterexamples):
        fail("launch-query counterexample not reproduced")


    endpoint_summary = json.loads(
        (campaign / "endpoint-publication-summary.json").read_text(
            encoding="utf-8"))
    expected_endpoint_summary = {
        "schema": "slopos.rev0892.endpoint-process-expectation-evidence.v2",
        "status": "PASS",
        "cases": 35,
        "counterexamples_reproduced": 7,
        "publisher_uid": 0,
        "provider_uid": 21001,
        "query_uid": 21003,
        "wrong_query_uid": 21002,
        "fixed_stage_leaf": "bound.sock",
        "fixed_public_leaf": "query.sock",
        "rename_flag": "RENAME_NOREPLACE",
        "endpoint_bind_after_final_principal": True,
        "inherited_query_data_socket": False,
        "connect_time_so_peercred_observed": True,
        "connect_time_so_peerpidfd_observed": True,
        "expected_process_match_required": True,
        "expectation_capsule_duplicate_counterexample": True,
        "expectation_constructor_protected": False,
        "expectation_record_bytes": 96,
        "expectation_record_exact_seals": True,
        "expectation_spent_before_connect": True,
        "externally_supplied_process_expectation_observed": True,
        "globally_unique_expectation_spend_proved": False,
        "provider_can_mutate_public_directory": False,
        "automatic_endpoint_cleanup_entrypoints": 0,
        "replacement_process_identity_distinct": True,
        "same_uid_writable_directory_replacement_reproduced": True,
        "sealed_self_assertion_counterexample_reproduced": True,
        "socketpair_creator_sender_counterexample_reproduced": True,
        "stale_public_leaf_blocks_noreplace_restart": True,
        "per_message_scm_pidfd_observed": True,
        "peer_pidfd_exit_observed": True,
        "owner_admission_authenticated": False,
        "pidfd_process_instance_authenticated": False,
        "privileged_publisher_can_replace": True,
        "process_descriptor_exported_to_caller": False,
        "provider_epoch_admitted": False,
        "stable_endpoint_epoch_proved": False,
        "administration_plane_closed": False,
        "stable_media_proved": False,
        "source_to_binary_proved": False,
        "independent_actor": False,
        "authority_granted": False,
    }
    for key, expected in expected_endpoint_summary.items():
        if endpoint_summary.get(key) != expected:
            fail(f"endpoint summary {key} expected={expected!r} "
                 f"observed={endpoint_summary.get(key)!r}")

    endpoint_rows = read_tsv(campaign / "endpoint-publication-cases.tsv")
    endpoint_by_name = {row["name"]: row for row in endpoint_rows}
    if set(endpoint_by_name) != set(EXPECTED_ENDPOINT_PUBLICATION_CASES):
        fail("endpoint-publication case inventory")
    for name, expected in EXPECTED_ENDPOINT_PUBLICATION_CASES.items():
        row = endpoint_by_name[name]
        if (row["passed"], row["retained_counterexample"]) != expected:
            fail(f"endpoint-publication case mismatch {name}")

    endpoint_counterexamples = read_tsv(
        campaign / "endpoint-publication-counterexamples.tsv")
    if {row["name"] for row in endpoint_counterexamples} \
            != EXPECTED_ENDPOINT_PUBLICATION_COUNTEREXAMPLES:
        fail("endpoint-publication counterexample inventory")
    if any(row["reproduced"] != "true"
           for row in endpoint_counterexamples):
        fail("endpoint-publication counterexample not reproduced")

    cuts = read_tsv(campaign / "cut-trace.tsv")
    expected_cuts = {
        "before_admission_call": "LIVE",
        "after_burn_and_directory_sync_return_before_decode": "PENDING",
        "after_exact_readback": "PENDING",
        "after_local_snapshot_restore": "LIVE",
    }
    if {row["cut"]: row["local_shape"] for row in cuts} != expected_cuts:
        fail("cut trace mismatch")
    if any("APPLY" in row["permitted_recovery"] and row["permitted_recovery"] != "NO_APPLY"
           for row in cuts if row["cut"] != "after_local_snapshot_restore"):
        fail("recovery apply vocabulary")

    refinement = verify_abstract_refinement()
    launch_refinement = verify_launch_refinement()
    endpoint_refinement = verify_endpoint_publication_refinement()
    process_refinement = verify_endpoint_process_refinement()
    audit = {
        "authority_granted": False,
        "campaign_case_disagreements": 0,
        "cases": len(rows),
        "principal_cases": len(principal_rows),
        "publication_cases": len(publication_rows),
        "counterexamples_reproduced": len(counterexamples),
        "principal_counterexamples_reproduced": len(principal_counterexamples),
        "launch_query_cases": len(launch_rows),
        "launch_query_counterexamples_reproduced": len(launch_counterexamples),
        "endpoint_publication_cases": len(endpoint_rows),
        "endpoint_publication_counterexamples_reproduced": len(
            endpoint_counterexamples),
        "cut_rows": len(cuts),
        "maximum_successful_bind_count": 1,
        "campaign_alone_proves_kernel_atomicity": False,
        "kernel_rename_atomicity_contract_relied_on": True,
        "process_visible_namespace_partition_observed": True,
        "protected_spent_identity": False,
        "refinement": refinement,
        "launch_refinement": launch_refinement,
        "endpoint_publication_refinement": endpoint_refinement,
        "endpoint_process_refinement": process_refinement,
        "recovery_apply_entrypoints": 0,
        "automatic_endpoint_cleanup_entrypoints": 0,
        "schema": "slopos.rev0903.handoff-cell-independent-audit.v8",
        "stable_media_proved": False,
        "status": "PASS",
    }
    args.json.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(
        "HANDOFF_CELL_AUDIT=PASS cases=12 principal_cases=7 publication_cases=10 "
        "launch_query_cases=15 endpoint_publication_cases=35 cut_rows=4 "
        "disagreements=0 counterexamples=16 "
        "split_ambiguity=1 "
        "no_replace_empty_states=0 "
        "protected_identity=false stable_media=false authority=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
