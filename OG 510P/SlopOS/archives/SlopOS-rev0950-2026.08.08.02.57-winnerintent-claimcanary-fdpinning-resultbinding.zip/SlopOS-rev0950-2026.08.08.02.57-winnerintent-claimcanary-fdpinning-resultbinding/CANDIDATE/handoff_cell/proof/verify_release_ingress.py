#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
SOURCE = ROOT / "CANDIDATE/handoff_cell"
DIGEST = "ffe840ff9295808e88cce2794a18a5ac87f12a5203c8314d0bf6aa119b41bac5"

EXPECTED_CASES: dict[str, dict[str, str]] = {
    "missing_locator": {
        "disposition": "LOCATOR_UNAVAILABLE",
        "observation_coherent": "true",
        "descriptor_identity_retained": "false",
        "private_snapshot_used": "false",
        "snapshot_write_sealed": "false",
        "exact_release_bytes": "false",
        "passive_only": "true",
    },
    "incoherent_boolean_bag": {
        "disposition": "OBSERVATION_INCOHERENT",
        "observation_coherent": "false",
        "descriptor_identity_retained": "false",
        "private_snapshot_used": "false",
        "snapshot_write_sealed": "false",
        "exact_release_bytes": "false",
        "passive_only": "true",
    },
    "unretained_descriptor": {
        "disposition": "DESCRIPTOR_UNPINNED",
        "descriptor_identity_retained": "false",
        "private_snapshot_used": "false",
        "snapshot_write_sealed": "false",
        "passive_only": "true",
    },
    "fifo_or_directory": {
        "disposition": "NONREGULAR_SOURCE",
        "descriptor_identity_retained": "true",
        "private_snapshot_used": "false",
        "snapshot_write_sealed": "false",
        "passive_only": "true",
    },
    "snapshot_short_read": {
        "disposition": "SNAPSHOT_INCOMPLETE",
        "descriptor_identity_retained": "true",
        "private_snapshot_used": "false",
        "snapshot_write_sealed": "false",
        "passive_only": "true",
    },
    "mutable_snapshot_before_digest_compare": {
        "disposition": "SNAPSHOT_UNSEALED",
        "descriptor_identity_retained": "true",
        "private_snapshot_used": "true",
        "snapshot_write_sealed": "false",
        "exact_release_bytes": "false",
        "passive_only": "true",
    },
    "wrong_digest_stops_before_parse": {
        "disposition": "DIGEST_MISMATCH",
        "snapshot_write_sealed": "true",
        "exact_release_bytes": "false",
        "digest_before_parse": "true",
        "passive_only": "true",
    },
    "wrong_digest_cannot_mask_early_parse": {
        "disposition": "DIGEST_ORDER_REJECTED",
        "snapshot_write_sealed": "true",
        "exact_release_bytes": "false",
        "digest_before_parse": "false",
        "passive_only": "true",
    },
    "hash_then_reopen_path": {
        "disposition": "PATH_REOPEN_REJECTED",
        "snapshot_write_sealed": "true",
        "exact_release_bytes": "true",
        "pathname_replacement_ignored": "false",
        "passive_only": "true",
    },
    "parse_before_digest": {
        "disposition": "DIGEST_ORDER_REJECTED",
        "snapshot_write_sealed": "true",
        "exact_release_bytes": "true",
        "digest_before_parse": "false",
        "passive_only": "true",
    },
    "digest_only_without_inventory": {
        "disposition": "ARCHIVE_REJECTED",
        "snapshot_write_sealed": "true",
        "exact_release_bytes": "true",
        "passive_only": "true",
    },
    "unsafe_archive_member": {
        "disposition": "ARCHIVE_REJECTED",
        "snapshot_write_sealed": "true",
        "exact_release_bytes": "true",
        "passive_only": "true",
    },
    "required_binary_missing": {
        "disposition": "ARCHIVE_REJECTED",
        "snapshot_write_sealed": "true",
        "exact_release_bytes": "true",
        "passive_only": "true",
    },
    "extraction_crosses_activation_boundary": {
        "disposition": "ACTIVATION_BOUNDARY_VIOLATED",
        "snapshot_write_sealed": "true",
        "exact_release_bytes": "true",
        "activation_boundary_observed": "true",
        "passive_only": "false",
    },
    "version_command_crosses_activation_boundary": {
        "disposition": "ACTIVATION_BOUNDARY_VIOLATED",
        "snapshot_write_sealed": "true",
        "exact_release_bytes": "true",
        "activation_boundary_observed": "true",
        "passive_only": "false",
    },
    "exact_write_sealed_snapshot": {
        "disposition": "EXACT_PASSIVE_ADMISSION",
        "snapshot_write_sealed": "true",
        "exact_release_bytes": "true",
        "activation_boundary_observed": "false",
        "passive_only": "true",
    },
    "path_replaced_after_descriptor_pin": {
        "disposition": "EXACT_PASSIVE_ADMISSION",
        "snapshot_write_sealed": "true",
        "exact_release_bytes": "true",
        "pathname_replacement_ignored": "true",
        "activation_boundary_observed": "false",
        "passive_only": "true",
    },
}
EXPECTED_COUNTEREXAMPLES = {
    "unordered_boolean_bag_is_not_proof",
    "anonymous_snapshot_is_not_immutable",
    "pathname_filename_is_release_identity",
    "hash_then_reopen_for_parse",
    "parse_before_digest_is_harmless",
    "digest_only_is_complete_admission",
    "execute_version_to_finish_byte_admission",
    "passive_release_receipt_implies_operated_provider",
    "path_replacement_changes_pinned_object",
}


def fail(detail: str) -> None:
    raise SystemExit(f"RELEASE_INGRESS_AUDIT=FAIL detail={detail}")


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        rows = list(reader)
    if not rows or any(any(value in (None, "") for value in row.values()) for row in rows):
        fail(f"empty output={path.name}")
    return rows


def strip_comments(text: str) -> str:
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.DOTALL)
    return re.sub(r"//.*", "", text)


def source_shape() -> dict[str, object]:
    header = (SOURCE / "include/slopos/e0/handoff_cell/release_ingress.hpp").read_text(
        encoding="utf-8")
    implementation = (SOURCE / "src/release_ingress.cpp").read_text(encoding="utf-8")
    campaign = (SOURCE / "harness/release_ingress_campaign.cpp").read_text(
        encoding="utf-8")
    for needle in (
        "ReleaseIngressObservationV1",
        "ReleaseIngressAssessment",
        "observation_incoherent",
        "snapshot_unsealed",
        "bool private_snapshot_write_sealed{false}",
        "bool observation_coherent{false}",
        "bool snapshot_write_sealed{false}",
        "bool activation_boundary_observed{false}",
        "bool supplied_path_authority{false}",
        "bool activation_authority{false}",
        "bool provider_operation_authority{false}",
        "bool cluster_operated{false}",
        "bool binary_execution_proved{false}",
    ):
        if needle not in header:
            fail(f"header shape missing={needle}")

    clean = strip_comments(header + "\n" + implementation)
    for forbidden in (
        "open", "fopen", "read", "write", "socket", "connect", "fork",
        "exec", "system", "popen", "rename", "unlink", "tar", "extract",
    ):
        if re.search(rf"\b[A-Za-z0-9_]*{forbidden}[A-Za-z0-9_]*\s*\(", clean,
                     flags=re.IGNORECASE):
            fail(f"host operation escaped pure release relation={forbidden}")

    assess = implementation.find("ReleaseIngressAssessment assess_release_ingress")
    names = implementation.find("const char* release_ingress_disposition_name", assess)
    if assess < 0 or names < 0:
        fail("assessment implementation boundary")
    body = implementation[assess:names]
    ordered = (
        "!observation_is_coherent(observation)",
        "!observation.locator_opened",
        "!observation.descriptor_pinned",
        "result.descriptor_identity_retained = true",
        "!observation.regular_file",
        "!observation.private_snapshot_complete",
        "result.private_snapshot_used = true",
        "!observation.private_snapshot_write_sealed",
        "result.snapshot_write_sealed = true",
        "observation.snapshot_sha256 == expected_archive_sha256",
        "observation.supplied_path_reopened",
        "!observation.digest_compared_before_parse",
        "!observation.archive_parse_attempted",
        "result.activation_boundary_observed",
        "exact_passive_admission",
    )
    position = -1
    for needle in ordered:
        current = body.find(needle, position + 1)
        if current < 0:
            fail(f"assessment order missing={needle}")
        position = current

    coherence = implementation[implementation.find("bool observation_is_coherent"):assess]
    for prerequisite in (
        "descriptor_pinned && !observation.locator_opened",
        "regular_file && !observation.descriptor_pinned",
        "private_snapshot_complete && !observation.regular_file",
        "private_snapshot_write_sealed",
        "archive_inventory_valid",
        "required_binaries_hashed",
    ):
        if prerequisite not in coherence:
            fail(f"coherence prerequisite missing={prerequisite}")
    if "result.passive_only = !result.activation_boundary_observed" not in implementation:
        fail("passive classification is not derived from activation attempts")

    endpoint = "\n".join(
        path.read_text(encoding="utf-8")
        for path in (
            SOURCE / "include/slopos/e0/handoff_cell/endpoint_claim.hpp",
            SOURCE / "src/endpoint_claim.cpp",
            SOURCE / "include/slopos/e0/handoff_cell/hosted_settlement.hpp",
            SOURCE / "src/hosted_settlement.cpp",
        )
    )
    for forbidden in (
        "ReleaseIngressObservationV1", "ReleaseIngressAssessment",
        "assess_release_ingress",
    ):
        if forbidden in endpoint:
            fail(f"passive release report reaches claim/settlement={forbidden}")

    for needle in (
        "incoherent_boolean_bag",
        "mutable_snapshot_before_digest_compare",
        "wrong_digest_cannot_mask_early_parse",
        "hash_then_reopen_path",
        "parse_before_digest",
        "path_replaced_after_descriptor_pin",
        "extraction_crosses_activation_boundary",
        "version_command_crosses_activation_boundary",
        "anonymous_snapshot_is_not_immutable",
    ):
        if needle not in campaign:
            fail(f"campaign shape missing={needle}")

    return {
        "candidate_filesystem_entrypoints": 0,
        "candidate_process_entrypoints": 0,
        "claim_or_settlement_consumers": 0,
        "descriptor_precedes_snapshot": True,
        "digest_precedes_archive_semantics": True,
        "observation_prefix_coherent": True,
        "passive_report_only": True,
        "snapshot_write_seal_precedes_digest_comparison": True,
    }


def verify_outputs(campaign: Path) -> dict[str, object]:
    rows = read_tsv(campaign / "release-ingress-cases.tsv")
    if {row["case"] for row in rows} != set(EXPECTED_CASES):
        fail("case inventory")
    for row in rows:
        for field, expected in EXPECTED_CASES[row["case"]].items():
            if row.get(field) != expected:
                fail(
                    f"case={row['case']} field={field} "
                    f"observed={row.get(field)!r} expected={expected!r}"
                )
        for field in (
            "supplied_path_authority", "activation_authority",
            "provider_operation_authority", "cluster_operated",
            "binary_execution_proved",
        ):
            if row[field] != "false":
                fail(f"case={row['case']} field={field} value={row[field]}")
        if row["case"] not in {
            "extraction_crosses_activation_boundary",
            "version_command_crosses_activation_boundary",
        } and row["activation_boundary_observed"] != "false":
            fail(f"unexpected activation observation={row['case']}")
        if row["case"] != "incoherent_boolean_bag" \
                and row["observation_coherent"] != "true":
            fail(f"coherent case rejected={row['case']}")

    counterexamples = read_tsv(campaign / "release-ingress-counterexamples.tsv")
    if {row["counterexample"] for row in counterexamples} != EXPECTED_COUNTEREXAMPLES:
        fail("counterexample inventory")
    if any(row["reproduced"] != "true" for row in counterexamples):
        fail("counterexample not reproduced")

    summary = json.loads(
        (campaign / "release-ingress-summary.json").read_text(encoding="utf-8"))
    expected_summary = {
        "activation_authority": False,
        "activation_boundary_violations": 2,
        "cases": 17,
        "cluster_operated": False,
        "counterexamples_reproduced": 9,
        "descriptor_opened_once_required": True,
        "digest_before_parse_required": True,
        "exact_passive_admissions": 2,
        "incoherent_observations_rejected": 1,
        "operated_binary_execution_attempted": False,
        "operated_binary_extraction_attempted": False,
        "path_replacement_admissions": 1,
        "private_snapshot_required": True,
        "provider_operation_authority": False,
        "release_archive_sha256": DIGEST,
        "release_version": "v3.6.14",
        "schema": "slopos.rev0899.release-ingress-shape-evidence.v2",
        "snapshot_write_seal_required": True,
        "status": "PASS",
        "supplied_path_authority": False,
        "supplied_path_reopened": False,
    }
    if summary != expected_summary:
        fail(f"summary mismatch={summary}")

    aggregate = json.loads((campaign / "summary.json").read_text(encoding="utf-8"))
    for key, value in (
        ("release_ingress_cases", 17),
        ("release_ingress_counterexamples", 9),
        ("release_ingress_exact_passive_admissions", 2),
        ("release_ingress_path_replacement_admissions", 1),
        ("release_ingress_activation_boundary_violations", 2),
        ("release_ingress_incoherent_observations", 1),
        ("release_ingress_snapshot_write_seal_required", True),
        ("release_ingress_activation_authority", False),
        ("schema", "slopos.rev0907.handoff-cell-campaign.v19"),
    ):
        if aggregate.get(key) != value:
            fail(f"aggregate field={key} value={aggregate.get(key)!r}")

    return {
        "activation_authority": False,
        "activation_boundary_violations": 2,
        "cases": len(rows),
        "counterexamples": len(counterexamples),
        "exact_passive_admissions": 2,
        "incoherent_observations": 1,
        "path_replacement_admissions": 1,
        "provider_operation_authority": False,
        "snapshot_write_seal_required": True,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Independently audit the passive release-ingress relation.")
    parser.add_argument("campaign", type=Path)
    parser.add_argument("--json", required=True, type=Path)
    args = parser.parse_args()
    required = {
        "release-ingress-cases.tsv",
        "release-ingress-counterexamples.tsv",
        "release-ingress-summary.json",
        "summary.json",
    }
    observed = {path.name for path in args.campaign.iterdir() if path.is_file()}
    if not required <= observed:
        fail(f"missing={sorted(required - observed)}")
    report = {
        **verify_outputs(args.campaign),
        "schema": "slopos.rev0899.release-ingress-independent-audit.v2",
        "source_shape": source_shape(),
        "status": "PASS",
    }
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n",
                         encoding="utf-8")
    print(
        "RELEASE_INGRESS_AUDIT=PASS cases=17 counterexamples=9 "
        "exact_passive=2 incoherent=1 activation_violations=2 "
        "snapshot_write_seal=true activation_authority=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
