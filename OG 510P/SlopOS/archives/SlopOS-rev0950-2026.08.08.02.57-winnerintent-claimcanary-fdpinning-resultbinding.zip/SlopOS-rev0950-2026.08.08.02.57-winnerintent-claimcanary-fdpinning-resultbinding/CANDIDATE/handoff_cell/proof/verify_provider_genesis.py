#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent

EXPECTED_CASES: dict[str, tuple[str, ...]] = {
    "exact_pinned_chain": (
        "EXACT_SIGNED_OBSERVATION", "true", "true", "true", "true", "true", "true", "false", "true"),
    "wrong_owner_key": (
        "OWNER_SIGNATURE_INVALID", "false", "true", "false", "false", "false", "true", "false", "false"),
    "wrong_genesis_digest_pin": (
        "GENESIS_PIN_MISMATCH", "false", "false", "false", "false", "false", "true", "false", "false"),
    "owner_signature_tamper_repin": (
        "OWNER_SIGNATURE_INVALID", "false", "true", "false", "false", "false", "true", "false", "false"),
    "genesis_body_tamper_repin": (
        "OWNER_SIGNATURE_INVALID", "false", "true", "false", "false", "false", "true", "false", "false"),
    "alternate_genesis_under_original_pin": (
        "GENESIS_PIN_MISMATCH", "false", "false", "false", "false", "false", "true", "false", "true"),
    "provider_signature_tamper": (
        "PROVIDER_SIGNATURE_INVALID", "false", "true", "true", "false", "false", "true", "false", "false"),
    "provider_body_tamper": (
        "PROVIDER_SIGNATURE_INVALID", "false", "true", "true", "false", "false", "true", "false", "false"),
    "foreign_genesis_binding": (
        "GENESIS_BINDING_MISMATCH", "false", "true", "true", "false", "false", "true", "false", "false"),
    "foreign_floor_binding": (
        "GENESIS_BINDING_MISMATCH", "false", "true", "true", "false", "false", "true", "false", "false"),
    "stale_expected_generation": (
        "EXPECTED_MISMATCH", "false", "true", "true", "true", "false", "true", "false", "false"),
    "foreign_expected_successor": (
        "EXPECTED_MISMATCH", "false", "true", "true", "true", "false", "true", "false", "false"),
    "substituted_provider_key_signature": (
        "PROVIDER_SIGNATURE_INVALID", "false", "true", "true", "false", "false", "true", "false", "false"),
    "replay_copy_one": (
        "EXACT_SIGNED_OBSERVATION", "true", "true", "true", "true", "true", "true", "false", "true"),
    "replay_copy_two": (
        "EXACT_SIGNED_OBSERVATION", "true", "true", "true", "true", "true", "true", "false", "true"),
    "coherent_history_copy_one": (
        "EXACT_SIGNED_OBSERVATION", "true", "true", "true", "true", "true", "true", "false", "true"),
    "coherent_history_copy_two": (
        "EXACT_SIGNED_OBSERVATION", "true", "true", "true", "true", "true", "true", "false", "true"),
    "conflicting_signed_successor_one": (
        "EXACT_SIGNED_OBSERVATION", "true", "true", "true", "true", "true", "true", "false", "true"),
    "conflicting_signed_successor_two": (
        "EXACT_SIGNED_OBSERVATION", "true", "true", "true", "true", "true", "true", "false", "true"),
    "alternate_genesis_repin": (
        "EXACT_SIGNED_OBSERVATION", "true", "true", "true", "true", "true", "true", "false", "true"),
}

EXPECTED_COUNTEREXAMPLES = {
    "hosted_actor_self_selects_owner_pin",
    "copy_and_replay_verify_repeatedly",
    "coherent_histories_verify_same_bytes",
    "one_provider_key_signs_conflicting_successors",
    "one_owner_key_signs_alternate_geneses",
}


def fail(detail: str) -> None:
    raise SystemExit(f"PROVIDER_GENESIS_AUDIT=FAIL detail={detail}")


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def strip_comments(text: str) -> str:
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.DOTALL)
    return re.sub(r"//.*", "", text)


def source_order(body: str, needles: list[str]) -> None:
    prior = -1
    for needle in needles:
        observed = body.find(needle)
        if observed < 0:
            fail(f"source-order needle missing={needle}")
        if observed <= prior:
            fail(f"source order violated at={needle}")
        prior = observed


def verify_source_shape() -> dict[str, object]:
    header_path = SOURCE / "include/slopos/e0/handoff_cell/provider_genesis.hpp"
    impl_path = SOURCE / "src/provider_genesis.cpp"
    harness_path = SOURCE / "harness/provider_genesis_campaign.cpp"
    endpoint_paths = [
        SOURCE / "include/slopos/e0/handoff_cell/endpoint_claim.hpp",
        SOURCE / "src/endpoint_claim.cpp",
    ]
    header = header_path.read_text(encoding="utf-8")
    impl = impl_path.read_text(encoding="utf-8")
    harness = harness_path.read_text(encoding="utf-8")

    for needle in (
        "struct OwnerGenesisPin final",
        "struct OwnerProviderGenesisV1 final",
        "struct ProviderAppendObservationV1 final",
        "struct ProviderGenesisObservation final",
        "bool query_only{true}",
        "bool response_authority{false}",
        "bool protected_provider_state{false}",
        "bool globally_unique_spend{false}",
        "verify_pinned_provider_append(",
    ):
        if needle not in header:
            fail(f"header shape missing={needle}")

    clean_header = strip_comments(header)
    for forbidden in (
        "private_key", "sign", "settle", "commit", "claim", "apply",
        "respond", "publish", "rotate", "revoke", "consume",
    ):
        if re.search(rf"\b[A-Za-z0-9_]*{forbidden}[A-Za-z0-9_]*\s*\(",
                     clean_header, flags=re.IGNORECASE):
            # Signing-message encoders are public grammar, not signing routes.
            if forbidden == "sign" and "signing_message(" in clean_header:
                scrubbed = clean_header.replace("signing_message(", "grammar_message(")
                if not re.search(r"\b[A-Za-z0-9_]*sign[A-Za-z0-9_]*\s*\(",
                                 scrubbed, flags=re.IGNORECASE):
                    continue
            fail(f"forbidden public authority route={forbidden}")

    for needle in (
        'EVP_PKEY_new_raw_public_key_ex(',
        'EVP_DigestVerifyInit_ex(',
        'EVP_DigestVerify(',
        'EVP_Q_digest(',
        '"SHA256"',
        '"ED25519"',
        'SlopOS/owner-provider-genesis/v1',
        'SlopOS/provider-append-obsv/v1',
    ):
        if needle not in impl:
            fail(f"implementation shape missing={needle}")

    candidate_code = "\n".join(
        path.read_text(encoding="utf-8")
        for root in (SOURCE / "include", SOURCE / "src")
        for path in sorted(root.rglob("*")) if path.is_file()
    )
    for forbidden in (
        "EVP_DigestSign", "EVP_PKEY_new_raw_private_key",
        "PEM_read_PrivateKey", "OSSL_STORE_open",
    ):
        if forbidden in candidate_code:
            fail(f"private/signing primitive escaped harness={forbidden}")
    for required in ("EVP_DigestSign", "EVP_PKEY_new_raw_private_key_ex"):
        if required not in harness:
            fail(f"deterministic harness signing fixture missing={required}")

    verify_start = impl.find("ProviderGenesisObservation verify_pinned_provider_append")
    disposition_start = impl.find("const char* provider_genesis_disposition_name", verify_start)
    if verify_start < 0 or disposition_start < 0:
        fail("verify implementation boundary")
    body = impl[verify_start:disposition_start]
    source_order(body, [
        "decode_owner_provider_genesis(",
        "owner_provider_genesis_digest(",
        "pin.exact_genesis_digest",
        "pin.owner_public_key",
        "decode_provider_append_observation(",
        "decoded_append.genesis_digest",
        "decoded_genesis.provider_public_key",
        "expected_matches(",
        "exact_signed_observation",
    ])

    endpoint = "\n".join(path.read_text(encoding="utf-8") for path in endpoint_paths)
    for forbidden in (
        "ProviderGenesisObservation", "ProviderAppendObservationV1",
        "EncodedProviderAppendObservation", "OwnerGenesisPin",
        "verify_pinned_provider_append",
    ):
        if forbidden in endpoint:
            fail(f"signed observation reaches endpoint parser surface={forbidden}")

    for needle in (
        "reject_all_genesis_bit_mutations",
        "reject_all_append_bit_mutations",
        "copy_and_replay_verify_repeatedly",
        "coherent_histories_verify_same_bytes",
        "one_provider_key_signs_conflicting_successors",
        "one_owner_key_signs_alternate_geneses",
        "cases.size()",
    ):
        if needle not in harness:
            fail(f"campaign shape missing={needle}")

    return {
        "candidate_private_key_entrypoints": 0,
        "candidate_signing_entrypoints": 0,
        "endpoint_parser_entrypoints_from_observation": 0,
        "exact_pin_precedes_owner_signature": True,
        "owner_signature_precedes_append_decode": True,
        "provider_signature_precedes_expected_match": True,
        "raw_public_key_verification": True,
        "sha256_genesis_pin": True,
    }


def verify_refinement() -> dict[str, object]:
    # Finite relational model of what the verifier establishes and what it does not.
    observations = {
        "exact": (True, True, True, True),
        "replay": (True, True, True, True),
        "history_copy": (True, True, True, True),
        "conflicting_a": (True, True, True, True),
        "conflicting_b": (True, True, True, True),
        "wrong_pin": (False, False, False, False),
        "wrong_owner": (True, False, False, False),
        "wrong_provider": (True, True, False, False),
        "wrong_expected": (True, True, True, False),
    }
    exact_names = {
        name for name, coordinates in observations.items()
        if all(coordinates)
    }
    if exact_names != {
        "exact", "replay", "history_copy", "conflicting_a", "conflicting_b"
    }:
        fail("finite verifier relation")
    if (observations["wrong_pin"][1]
            or observations["wrong_owner"][2]
            or observations["wrong_provider"][3]
            or observations["wrong_expected"][3]):
        fail("failure refinement")

    owner_key_signed_geneses = {"genesis_a", "genesis_b"}
    provider_key_signed_successors = {"successor_a", "successor_b"}
    exact_pin_a = {"genesis_a"}
    exact_pin_b = {"genesis_b"}
    if len(owner_key_signed_geneses) != 2 or len(provider_key_signed_successors) != 2:
        fail("countermodel inventory")
    if exact_pin_a & exact_pin_b or len(exact_pin_a | exact_pin_b) != 2:
        fail("exact pin selection model")

    return {
        "copyable_exact_observations": 3,
        "globally_unique_spend_proved": False,
        "one_owner_key_signed_geneses": len(owner_key_signed_geneses),
        "one_provider_key_signed_successors": len(provider_key_signed_successors),
        "owner_constitution_proved": False,
        "protected_provider_state_proved": False,
        "provider_commit_proved": False,
        "query_only_exact_states": len(exact_names),
        "repinning_selects_alternate_genesis": True,
        "response_authority": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Independently audit owner-pinned provider-genesis evidence.")
    parser.add_argument("campaign", type=Path)
    parser.add_argument("--json", required=True, type=Path)
    args = parser.parse_args()
    campaign = args.campaign.resolve()

    required = {
        "provider-genesis-cases.tsv",
        "provider-genesis-counterexamples.tsv",
        "provider-genesis-summary.json",
    }
    observed = {path.name for path in campaign.iterdir() if path.is_file()}
    if not required <= observed:
        fail(f"missing={sorted(required - observed)}")

    summary = json.loads(
        (campaign / "provider-genesis-summary.json").read_text(encoding="utf-8"))
    expected_summary = {
        "append_bit_mutations_rejected": 2560,
        "appraiser_independently_provisioned": False,
        "authority_granted": False,
        "cases": 20,
        "conflicting_signed_successors": 2,
        "counterexamples_reproduced": 5,
        "ed25519_public_key_bytes": 32,
        "ed25519_signature_bytes": 64,
        "endpoint_parser_entrypoints_from_observation": 0,
        "exact_genesis_pin_required": True,
        "genesis_bit_mutations_rejected": 2560,
        "globally_unique_spend_proved": False,
        "owner_constitution_proved": False,
        "owner_genesis_bytes": 320,
        "owner_signature_verified": True,
        "protected_provider_state_proved": False,
        "provider_append_observation_bytes": 320,
        "provider_commit_proved": False,
        "provider_signature_verified": True,
        "replay_exact_observations": 4,
        "response_authority": False,
        "schema": "slopos.rev0897.provider-genesis-observation-evidence.v1",
        "signature_is_spend": False,
        "stable_media_proved": False,
        "status": "PASS",
    }
    if summary != expected_summary:
        fail("summary exact mismatch")

    rows = read_tsv(campaign / "provider-genesis-cases.tsv")
    observed_cases: dict[str, tuple[str, ...]] = {}
    for row in rows:
        name = row["case"]
        if name in observed_cases:
            fail(f"duplicate case={name}")
        observed_cases[name] = (
            row["disposition"], row["exact"], row["exact_pin"],
            row["owner_signature"], row["provider_signature"],
            row["expected_fields"], row["query_only"],
            row["response_authority"], row["retained_counterexample"],
        )
    if observed_cases != EXPECTED_CASES:
        missing = sorted(set(EXPECTED_CASES) - set(observed_cases))
        extra = sorted(set(observed_cases) - set(EXPECTED_CASES))
        mismatched = sorted(
            name for name in set(observed_cases) & set(EXPECTED_CASES)
            if observed_cases[name] != EXPECTED_CASES[name])
        fail(f"case mismatch missing={missing} extra={extra} mismatched={mismatched}")

    counterexamples = read_tsv(campaign / "provider-genesis-counterexamples.tsv")
    names = {row["counterexample"] for row in counterexamples}
    if names != EXPECTED_COUNTEREXAMPLES or len(counterexamples) != 5:
        fail(f"counterexample inventory={sorted(names)}")
    if any(row["reproduced"] != "true" for row in counterexamples):
        fail("counterexample not reproduced")

    source_shape = verify_source_shape()
    refinement = verify_refinement()
    report = {
        "append_bit_mutations_rejected": 2560,
        "cases": len(rows),
        "counterexamples": len(counterexamples),
        "genesis_bit_mutations_rejected": 2560,
        "refinement": refinement,
        "schema": "slopos.rev0897.provider-genesis-independent-audit.v1",
        "source_shape": source_shape,
        "status": "PASS",
    }
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(
        "PROVIDER_GENESIS_AUDIT=PASS cases=20 counterexamples=5 "
        "genesis_bit_mutations=2560 append_bit_mutations=2560 "
        "endpoint_parser_entries=0 authority=false global_spend=false")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
