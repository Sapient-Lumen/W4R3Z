#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def fail(detail: str) -> None:
    raise SystemExit(f"APPRAISER_RECEIPT_AUDIT=FAIL detail={detail}")


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def truth(value: str) -> bool:
    if value not in {"true", "false"}:
        fail(f"bad boolean={value!r}")
    return value == "true"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()

    cases = rows(args.output / "appraiser-receipt-cases.tsv")
    counterexamples = rows(args.output / "appraiser-receipt-counterexamples.tsv")
    summary = json.loads((args.output / "appraiser-receipt-summary.json").read_text(encoding="utf-8"))

    if len(cases) != 42 or len({row["case"] for row in cases}) != 42:
        fail(f"case inventory={len(cases)}")
    if len(counterexamples) != 24 or len({row["counterexample"] for row in counterexamples}) != 24:
        fail(f"counterexample inventory={len(counterexamples)}")
    if not all(truth(row["reproduced"]) for row in counterexamples):
        fail("unreproduced counterexample")

    expected_counts = {
        "canonical_receipt": 17,
        "signed_statement": 13,
        "one_report": 12,
        "independent_constitution": 8,
        "process_coordinate": 7,
        "installed_policy": 6,
        "kernel_surfaces": 5,
        "v14_dossier": 4,
        "independent_appraisal": 1,
        "v13_eligible": 1,
    }
    true_names: dict[str, list[str]] = {}
    for field, expected in expected_counts.items():
        names = [row["case"] for row in cases if truth(row[field])]
        true_names[field] = names
        if len(names) != expected:
            fail(f"{field} count={len(names)} rows={names}")
    ordered = list(expected_counts)
    for wider, narrower in zip(ordered, ordered[1:]):
        if true_names[wider][-len(true_names[narrower]):] != true_names[narrower]:
            fail(f"ordered suffix={wider}->{narrower}")
    if true_names["v13_eligible"] != ["ordered_prefix_39"]:
        fail(f"V13 rows={true_names['v13_eligible']}")
    incoherent = [row["case"] for row in cases if not truth(row["coherent"])]
    if incoherent != ["incoherent_decode_gap", "incoherent_administration_gap"]:
        fail(f"incoherent={incoherent}")
    if any(truth(row["authority"]) for row in cases):
        fail("authority leak")

    expected_summary = {
        "canonical_receipt_profiles": 17,
        "cases": 42,
        "counterexamples_reproduced": 24,
        "independent_appraisal_profiles": 1,
        "key_bit_mutations_rejected": 256,
        "message_bit_mutations_rejected": 3072,
        "mutation_rejections": 3840,
        "owner_authority": False,
        "public_test_key": True,
        "receipt_bytes": 384,
        "schema": "slopos.rev0905.appraiser-receipt-campaign.v17",
        "signature_bit_mutations_rejected": 512,
        "signature_bytes": 64,
        "signed_statement_not_custody": True,
        "signed_statement_profiles": 13,
        "status": "PASS",
        "v13_eligible_profiles": 1,
    }
    if summary != expected_summary:
        fail(f"summary mismatch={summary}")

    audit = {
        "authority_granted": False,
        "canonical_receipt_profiles": 17,
        "cases": 42,
        "counterexamples": 24,
        "independent_appraisal_profiles": 1,
        "incoherent_observations": 2,
        "mutation_rejections": 3840,
        "network_attempted": False,
        "receipt_bytes": 384,
        "schema": "slopos.rev0905.appraiser-receipt-audit.v17",
        "signature_bytes": 64,
        "signed_statement_profiles": 13,
        "status": "PASS",
        "v13_eligible_profiles": 1,
    }
    args.json.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print("APPRAISER_RECEIPT_AUDIT=PASS cases=42 counterexamples=24 canonical=17 signed=13 independent=1 v13=1 mutations=3840 authority=false")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
