#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def fail(detail: str) -> None:
    raise SystemExit(f"ACQUISITION_ACTOR_HOST_AUDIT=FAIL detail={detail}")


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def truth(value: str) -> bool:
    if value not in {"true", "false"}:
        fail(f"bad boolean={value!r}")
    return value == "true"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()
    cases = rows(args.output / "acquisition-actor-host-cases.tsv")
    counter = rows(args.output / "acquisition-actor-host-counterexamples.tsv")
    summary = json.loads(
        (args.output / "acquisition-actor-host-summary.json").read_text(
            encoding="utf-8")
    )
    if len(cases) != 22 or not all(truth(row["pass"]) for row in cases):
        fail(f"case inventory/pass count={len(cases)}")
    if len(counter) != 12 or not all(truth(row["reproduced"]) for row in counter):
        fail("counterexample inventory")
    by_name = {row["case"]: row for row in cases}
    required_false = {
        "effective_uid_nonroot", "effective_gid_nonroot",
        "supplementary_groups_empty", "effective_capabilities_empty",
        "no_new_privs_enabled", "seccomp_filter_installed",
        "seccomp_filter_exact", "pidfd_get_info_supported",
        "pidfd_info_pid_present", "pidfd_info_creds_present",
        "independent_appraiser_constituted", "host_actor_profile_admissible",
        "network_attempted", "ready_sent", "rights_imported",
        "candidate_created",
    }
    required_true = {
        "pidfd_open_supported", "second_pidfd_open_supported",
        "repeated_pidfd_same_inode", "pidfd_descriptor_numbers_distinct",
        "pidfd_close_on_exec", "archive_body_bytes_zero",
    }
    for name in required_false:
        if name not in by_name or truth(by_name[name]["observed"]):
            fail(f"required false={name}")
    for name in required_true:
        if name not in by_name or not truth(by_name[name]["observed"]):
            fail(f"required true={name}")
    fixed = {
        "appraiser_constituted": False,
        "archive_body_bytes": 0,
        "archive_body_retained": False,
        "capabilities_empty": False,
        "candidate_created": False,
        "cases": 22,
        "counterexamples_reproduced": 12,
        "effective_gid": 0,
        "effective_uid": 0,
        "host_actor_profile_admissible": False,
        "network_attempted": False,
        "no_new_privs_enabled": False,
        "pidfd_get_info_supported": False,
        "pidfd_open_supported": True,
        "pidfd_repeated_coordinate_equal": True,
        "ready_sent": False,
        "rights_imported": False,
        "schema": "slopos.rev0902.acquisition-actor-host-probe.v1",
        "seccomp_filter_exact": False,
        "seccomp_filter_installed": False,
        "status": "PASS",
        "supplementary_groups_empty": False,
    }
    for key, value in fixed.items():
        if summary.get(key) != value:
            fail(f"summary field={key} observed={summary.get(key)!r}")
    if summary.get("cap_eff_hex") == "0000000000000000":
        fail("effective capabilities unexpectedly empty")
    if summary.get("pidfd_get_info_errno") not in {"EINVAL", "ENOTTY", "ENOSYS"}:
        fail(f"unsupported errno={summary.get('pidfd_get_info_errno')!r}")
    release = summary.get("kernel_release")
    if not isinstance(release, str) or not release.startswith("6.12.13"):
        fail(f"kernel release={release!r}")
    audit = {
        "ambient_capabilities_retained": True,
        "appraiser_constituted": False,
        "archive_body_bytes": 0,
        "cases": 22,
        "counterexamples": 12,
        "effective_root": True,
        "host_actor_profile_admissible": False,
        "kernel_release": release,
        "network_attempted": False,
        "no_new_privs_enabled": False,
        "pidfd_get_info_errno": summary["pidfd_get_info_errno"],
        "pidfd_get_info_supported": False,
        "pidfd_open_supported": True,
        "ready_sent": False,
        "rights_imported": False,
        "schema": "slopos.rev0902.acquisition-actor-host-audit.v1",
        "seccomp_filter_installed": False,
        "status": "PASS",
    }
    args.json.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n",
                         encoding="utf-8")
    print("ACQUISITION_ACTOR_HOST_AUDIT=PASS cases=22 counterexamples=12 root=true capabilities=true no_new_privs=false seccomp=false pidfd_open=true pidfd_get_info=false actor_admissible=false network=false ready=false archive_bytes=0")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
