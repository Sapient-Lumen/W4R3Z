#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def fail(detail: str) -> None:
    raise SystemExit(f"SINGLE_LEDGER_JOIN_AUDIT=FAIL detail={detail}")


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def truth(value: str) -> bool:
    if value not in {"true", "false"}:
        fail(f"bad boolean={value!r}")
    return value == "true"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()

    cases = rows(args.output / "single-ledger-cases.tsv")
    counter = rows(args.output / "single-ledger-counterexamples.tsv")
    summary = json.loads(
        (args.output / "single-ledger-summary.json").read_text(encoding="utf-8")
    )
    plan = (args.output / "single-ledger-plan.txt").read_text(encoding="utf-8")

    if len(cases) != 51 or len({row["case"] for row in cases}) != 51:
        fail(f"case inventory={len(cases)}")
    if len(counter) != 32 or len({row["counterexample"] for row in counter}) != 32:
        fail(f"counter inventory={len(counter)}")
    if not all(truth(row["reproduced"]) for row in counter):
        fail("unreproduced counterexample")

    expected_counts = {
        "exact_profile": 37,
        "v18_spend": 28,
        "transaction_plan": 20,
        "one_attempt": 19,
        "atomic_join": 9,
        "query_only": 5,
        "restore_lineage": 4,
        "administration_distinct": 3,
        "external_currentness": 2,
        "external_floor": 1,
        "v18_floor_eligible": 1,
    }
    names: dict[str, list[str]] = {}
    for field, expected in expected_counts.items():
        selected = [row["case"] for row in cases if truth(row[field])]
        names[field] = selected
        if len(selected) != expected:
            fail(f"{field} count={len(selected)} rows={selected}")

    ordered = [
        "exact_profile", "v18_spend", "transaction_plan", "one_attempt",
        "atomic_join", "query_only", "restore_lineage",
        "administration_distinct", "external_currentness", "external_floor",
    ]
    for wider, narrower in zip(ordered, ordered[1:]):
        if names[wider][-len(names[narrower]):] != names[narrower]:
            fail(f"ordered suffix={wider}->{narrower}")

    if names["external_floor"] != ["ordered_prefix_46"]:
        fail(f"external floor rows={names['external_floor']}")
    if names["v18_floor_eligible"] != ["ordered_prefix_46"]:
        fail(f"V18 eligibility rows={names['v18_floor_eligible']}")
    full = next(row for row in cases if row["case"] == "ordered_prefix_46")
    if full["disposition"] != "EXTERNAL_ROLLBACK_FLOOR_PREMISE":
        fail(f"full disposition={full['disposition']}")
    if full["judgment"] != "SYNTHETIC_EXTERNAL_FLOOR_PREMISE":
        fail(f"full judgment={full['judgment']}")

    incoherent = [row["case"] for row in cases if not truth(row["coherent"])]
    if incoherent != [
        "incoherent_gap_1", "incoherent_gap_10",
        "incoherent_gap_28", "incoherent_gap_38",
    ]:
        fail(f"incoherent={incoherent}")
    if any(truth(row["provider_operated"]) for row in cases):
        fail("provider operation leak")
    if any(truth(row["authority"]) for row in cases):
        fail("authority leak")

    expected_summary = {
        "atomic_join_profiles": 9,
        "authority": False,
        "cases": 51,
        "counterexamples_reproduced": 32,
        "exact_profile_profiles": 37,
        "external_floor_profiles": 1,
        "network_attempted": False,
        "one_attempt_profiles": 19,
        "provider_operated": False,
        "query_only_profiles": 5,
        "restore_lineage_profiles": 4,
        "schema": "slopos.rev0908.single-ledger-join-campaign.v20",
        "status": "PASS",
        "transaction_plan_profiles": 20,
        "v18_floor_eligible_profiles": 1,
        "v18_spend_profiles": 28,
    }
    if summary != expected_summary:
        fail(f"summary mismatch={summary}")

    required_plan = (
        "profile_version=v3.6.14",
        "comparisons=4",
        "success_writes=3",
        "failure_queries=4",
        "serializable_read=false",
        'value("/slopos/e0/provider-history/v1/head")',
        'value("/slopos/e0/provider-history/v1/floor")',
        'version("/slopos/e0/provider-history/v1/spend/',
        'version("/slopos/e0/provider-history/v1/entry/',
        "--- linearizable query intent ---",
    )
    missing = [fragment for fragment in required_plan if fragment not in plan]
    if missing:
        fail(f"plan missing={missing}")

    audit = {
        "administration_distinct_profiles": 3,
        "atomic_join_profiles": 9,
        "authority_granted": False,
        "cases": 51,
        "counterexamples": 32,
        "exact_profile_profiles": 37,
        "external_currentness_profiles": 2,
        "external_floor_profiles": 1,
        "incoherent_observations": 4,
        "network_attempted": False,
        "one_attempt_profiles": 19,
        "provider_operated": False,
        "query_only_profiles": 5,
        "restore_lineage_profiles": 4,
        "schema": "slopos.rev0908.single-ledger-join-audit.v20",
        "status": "PASS",
        "transaction_plan": {
            "comparisons": 4,
            "failure_queries": 4,
            "linearizable_read": True,
            "profile_version": "v3.6.14",
            "success_writes": 3,
        },
        "transaction_plan_profiles": 20,
        "v18_external_floor_eligible_profiles": 1,
        "v18_spend_profiles": 28,
    }
    args.json.write_text(
        json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(
        "SINGLE_LEDGER_JOIN_AUDIT=PASS cases=51 counterexamples=32 "
        "profile=37 v18=28 plan=20 attempt=19 atomic=9 query=5 "
        "restore=4 external=1 provider=false authority=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
