#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def fail(detail: str) -> None:
    raise SystemExit(f"EXTERNAL_ROLLBACK_FLOOR_AUDIT=FAIL detail={detail}")


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def truth(value: str) -> bool:
    if value not in {"true", "false"}:
        fail(f"bad boolean={value!r}")
    return value == "true"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()

    cases = rows(args.output / "external-floor-cases.tsv")
    counter = rows(args.output / "external-floor-counterexamples.tsv")
    summary = json.loads(
        (args.output / "external-floor-summary.json").read_text(encoding="utf-8")
    )

    if len(cases) != 62 or len({row["case"] for row in cases}) != 62:
        fail(f"case inventory={len(cases)}")
    if len(counter) != 44 or len({row["counterexample"] for row in counter}) != 44:
        fail(f"counter inventory={len(counter)}")
    if not all(truth(row["reproduced"]) for row in counter):
        fail("unreproduced counterexample")

    expected = {
        "exact_profile": 38,
        "v18_spend_bound": 34,
        "prestate_certified": 27,
        "extend_request": 21,
        "poststate_certified": 16,
        "witness_advanced": 11,
        "query_only": 7,
        "complete_transcript": 1,
        "cross_ledger_join": 0,
        "query_only_cross_ledger_recovery": 0,
        "external_floor": 0,
        "v18_floor_eligible": 0,
        "clone_replay_excluded": 1,
    }
    names: dict[str, list[str]] = {}
    for field, count in expected.items():
        names[field] = [row["case"] for row in cases if truth(row[field])]
        if len(names[field]) != count:
            fail(f"{field} count={len(names[field])} rows={names[field]}")

    ordered_positive = [
        "exact_profile",
        "v18_spend_bound",
        "prestate_certified",
        "extend_request",
        "poststate_certified",
        "witness_advanced",
        "query_only",
        "complete_transcript",
    ]
    for wider, narrower in zip(ordered_positive, ordered_positive[1:]):
        if names[wider][-len(names[narrower]) :] != names[narrower]:
            fail(f"ordered suffix={wider}->{narrower}")

    if names["complete_transcript"] != ["ordered_prefix_58"]:
        fail(f"complete transcript rows={names['complete_transcript']}")
    if names["clone_replay_excluded"] != ["ordered_prefix_58"]:
        fail(f"clone replay rows={names['clone_replay_excluded']}")
    for field in (
        "cross_ledger_join",
        "query_only_cross_ledger_recovery",
        "external_floor",
        "v18_floor_eligible",
    ):
        if names[field]:
            fail(f"forbidden positive rows={field}:{names[field]}")

    full = next(row for row in cases if row["case"] == "ordered_prefix_58")
    if full["disposition"] != "cross_ledger_join_unproved":
        fail(f"full disposition={full['disposition']}")
    if full["judgment"] != "SYNTHETIC_COMPLETE_TRANSCRIPT_JOIN_UNPROVED":
        fail(f"full judgment={full['judgment']}")

    incoherent = [row["case"] for row in cases if not truth(row["coherent"])]
    if incoherent != [
        "incoherent_profile_gap",
        "incoherent_prestate_gap",
        "incoherent_custody_gap",
    ]:
        fail(f"incoherent={incoherent}")
    if any(truth(row["authority"]) for row in cases):
        fail("authority leak")

    expected_summary = {
        "authority": False,
        "cases": 62,
        "complete_transcript_profiles": 1,
        "counterexamples_reproduced": 44,
        "cross_ledger_join_profiles": 0,
        "exact_profile_profiles": 38,
        "external_floor_profiles": 0,
        "extend_request_profiles": 21,
        "network_attempted": False,
        "poststate_certified_profiles": 16,
        "prestate_certified_profiles": 27,
        "query_only_profiles": 7,
        "record_bytes": 288,
        "record_mutation_rejections": 2304,
        "schema": "slopos.rev0907.external-rollback-floor-campaign.v19",
        "spend_input_mutation_rejections": 2816,
        "status": "PASS",
        "tpm_commands_issued": 0,
        "total_mutation_rejections": 5120,
        "v18_spend_profiles": 34,
        "witness_advanced_profiles": 11,
    }
    if summary != expected_summary:
        fail(f"summary mismatch={summary}")

    audit = {
        "authority_granted": False,
        "cases": 62,
        "complete_transcript_profiles": 1,
        "counterexamples": 44,
        "cross_ledger_join_profiles": 0,
        "exact_profile_profiles": 38,
        "external_floor_profiles": 0,
        "extend_request_profiles": 21,
        "incoherent_observations": 3,
        "mutation_rejections": 5120,
        "network_attempted": False,
        "poststate_certified_profiles": 16,
        "prestate_certified_profiles": 27,
        "query_only_cross_ledger_recovery_profiles": 0,
        "query_only_profiles": 7,
        "schema": "slopos.rev0907.external-rollback-floor-audit.v19",
        "status": "PASS",
        "tpm_commands_issued": 0,
        "v18_external_floor_eligible_profiles": 0,
        "v18_spend_profiles": 34,
        "witness_advanced_profiles": 11,
    }
    args.json.write_text(
        json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(
        "EXTERNAL_ROLLBACK_FLOOR_AUDIT=PASS cases=62 counterexamples=44 "
        "profile=38 v18=34 pre=27 extend=21 post=16 witness=11 query=7 "
        "transcript=1 cross_ledger_join=0 external=0 mutations=5120 authority=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
