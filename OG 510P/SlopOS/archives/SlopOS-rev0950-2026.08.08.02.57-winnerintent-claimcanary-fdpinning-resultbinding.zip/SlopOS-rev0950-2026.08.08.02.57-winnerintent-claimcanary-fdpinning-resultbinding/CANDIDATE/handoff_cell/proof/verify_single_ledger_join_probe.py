#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def fail(detail: str) -> None:
    raise SystemExit(f"SINGLE_LEDGER_JOIN_HOST_AUDIT=FAIL detail={detail}")


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def truth(value: str) -> bool:
    if value not in {"true", "false"}:
        fail(f"bad boolean={value!r}")
    return value == "true"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()

    cases = rows(args.output / "single-ledger-host-cases.tsv")
    counter = rows(args.output / "single-ledger-host-counterexamples.tsv")
    summary = json.loads(
        (args.output / "single-ledger-host-summary.json").read_text(encoding="utf-8")
    )

    if len(cases) != 30 or len({row["case"] for row in cases}) != 30:
        fail(f"case inventory={len(cases)}")
    if len(counter) != 18 or len({row["counterexample"] for row in counter}) != 18:
        fail(f"counter inventory={len(counter)}")
    for row in cases:
        if truth(row["observed"]) != truth(row["expected"]) or not truth(row["pass"]):
            fail(f"host case={row['case']}")
    if not all(truth(row["reproduced"]) for row in counter):
        fail("unreproduced counterexample")

    version = summary.pop("sqlite_libversion", None)
    source_id = summary.pop("sqlite_source_id", None)
    if not isinstance(version, str) or not version:
        fail(f"sqlite version={version!r}")
    if not isinstance(source_id, str) or not source_id:
        fail(f"sqlite source id={source_id!r}")

    expected = {
        "atomic_join_observed": True,
        "authority": False,
        "cases": 30,
        "clone_histories_advanced": 2,
        "counterexamples_reproduced": 18,
        "crash_cuts": 7,
        "crash_states_new": 1,
        "crash_states_old": 6,
        "crash_states_split": 0,
        "external_rollback_floor_bound": False,
        "journal_mode": "delete",
        "network_attempted": False,
        "provider_operated": False,
        "query_only_recovery_observed": True,
        "race_conflicts": 7,
        "race_winners": 1,
        "restored_copy_advanced": True,
        "schema": "slopos.rev0908.single-ledger-host-probe.v20",
        "status": "PASS",
        "synchronous": "FULL",
    }
    if summary != expected:
        fail(f"summary mismatch={summary}")

    required_cases = {
        "direct_transaction_advanced",
        "committed_recovery_query_only",
        "eight_contenders_one_winner",
        "coherent_clones_both_advance",
        "restored_snapshot_replays_same_spend",
        "split_state_query_fails_closed",
        "external_floor_not_bound",
        "authority_not_granted",
    }
    missing = sorted(required_cases - {row["case"] for row in cases})
    if missing:
        fail(f"missing cases={missing}")

    audit = {
        "atomic_join_observed": True,
        "authority_granted": False,
        "cases": 30,
        "clone_histories_advanced": 2,
        "counterexamples": 18,
        "crash_cuts": 7,
        "crash_states_new": 1,
        "crash_states_old": 6,
        "crash_states_split": 0,
        "external_rollback_floor_bound": False,
        "network_attempted": False,
        "provider_operated": False,
        "query_only_recovery_observed": True,
        "race_conflicts": 7,
        "race_winners": 1,
        "restored_copy_advanced": True,
        "schema": "slopos.rev0908.single-ledger-host-audit.v20",
        "sqlite_libversion": version,
        "sqlite_source_id": source_id,
        "status": "PASS",
    }
    args.json.write_text(
        json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(
        "SINGLE_LEDGER_JOIN_HOST_AUDIT=PASS cases=30 counterexamples=18 "
        "crash=7 old=6 new=1 split=0 race=1/7 clones=2 restore=true "
        "provider=false external=false authority=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
