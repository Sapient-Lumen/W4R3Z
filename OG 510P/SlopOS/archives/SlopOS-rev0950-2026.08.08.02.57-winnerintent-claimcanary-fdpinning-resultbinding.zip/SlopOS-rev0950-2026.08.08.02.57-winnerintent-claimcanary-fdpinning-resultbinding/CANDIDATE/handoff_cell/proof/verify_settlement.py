#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent

EXPECTED_CASES: dict[str, tuple[str, ...]] = {
    "exact_effect_return": (
        "EFFECT", "NOT_QUERIED", "SUBMIT_EXACT_RECORD", "1", "0", "1",
        "true", "true", "false", "false", "false"),
    "exact_no_effect_return": (
        "NO_EFFECT", "NOT_QUERIED", "SUBMIT_EXACT_RECORD", "1", "0", "0",
        "true", "true", "false", "false", "false"),
    "malformed_request_burns_without_submit": (
        "MALFORMED_REQUEST", "NOT_QUERIED", "REQUEST_REJECTED", "0", "0", "0",
        "true", "true", "false", "false", "false"),
    "spent_claim_second_call_no_submit": (
        "CLAIM_MISSING_OR_SPENT", "NOT_QUERIED", "CLAIM_ABSENT", "1", "0", "1",
        "false", "true", "false", "false", "false"),
    "effect_reply_lost_then_query_effect": (
        "UNCERTAIN", "EFFECT", "QUERY_EXACT_RECORD", "1", "1", "1",
        "true", "true", "false", "false", "false"),
    "no_effect_reply_lost_then_query_no_effect": (
        "UNCERTAIN", "NO_EFFECT", "QUERY_EXACT_RECORD", "1", "1", "0",
        "true", "true", "false", "false", "false"),
    "precommit_reply_lost_then_exact_unused": (
        "UNCERTAIN", "NO_EFFECT", "QUERY_EXACT_UNUSED", "1", "1", "0",
        "true", "true", "false", "false", "false"),
    "malformed_return_after_effect_then_query": (
        "UNCERTAIN", "EFFECT", "QUERY_EXACT_RECORD", "1", "1", "1",
        "true", "true", "false", "false", "true"),
    "foreign_result_after_effect_then_query": (
        "UNCERTAIN", "EFFECT", "QUERY_EXACT_RECORD", "1", "1", "1",
        "true", "true", "false", "false", "true"),
    "exact_uncertain_record_persists": (
        "UNCERTAIN", "UNCERTAIN", "QUERY_EXACT_RECORD", "1", "1", "0",
        "true", "true", "false", "false", "false"),
    "query_unavailable_preserves_uncertainty": (
        "UNCERTAIN", "UNCERTAIN", "QUERY_UNAVAILABLE", "1", "1", "1",
        "true", "true", "false", "false", "false"),
    "exact_fail_stop_result": (
        "FAIL_STOP", "NOT_QUERIED", "SUBMIT_EXACT_RECORD", "1", "0", "0",
        "true", "true", "false", "false", "false"),
    "copied_reconciliation_observations_no_submit": (
        "EFFECT", "NOT_QUERIED", "QUERY_EXACT_RECORD", "1", "2", "1",
        "false", "true", "false", "false", "false"),
    "invalid_expected_pending_fails_before_query": (
        "FAIL_STOP", "NOT_QUERIED", "INVALID_EXPECTED_PENDING", "0", "0", "0",
        "false", "true", "false", "false", "false"),
}

CASE_FIELDS = (
    "immediate", "reconciled", "evidence", "submits", "queries", "effects",
    "request_examined", "query_only", "response_authority", "retry_authority",
    "retained_counterexample",
)

EXPECTED_COUNTEREXAMPLES = {
    "malformed_return_can_follow_committed_effect",
    "coherent_provider_clones_each_commit_effect",
    "finite_idempotency_retention_reopens_exact_operation",
    "byte_identical_results_from_distinct_providers",
}

EXPECTED_CRASH = {
    "after_claim_before_submit": (
        "UNUSED", "0", "0", "ALREADY_CLAIMED_EXACT", "NO_EFFECT",
        "QUERY_EXACT_UNUSED", "true", "false"),
    "after_effect_commit_before_reply": (
        "EFFECT", "1", "1", "ALREADY_CLAIMED_EXACT", "EFFECT",
        "QUERY_EXACT_RECORD", "true", "false"),
    "after_no_effect_commit_before_reply": (
        "NO_EFFECT", "1", "0", "ALREADY_CLAIMED_EXACT", "NO_EFFECT",
        "QUERY_EXACT_RECORD", "true", "false"),
    "after_uncertain_commit_before_reply": (
        "UNCERTAIN", "1", "0", "ALREADY_CLAIMED_EXACT", "UNCERTAIN",
        "QUERY_EXACT_RECORD", "true", "false"),
}

CRASH_FIELDS = (
    "provider_state", "submits", "effects", "reopen_claim", "settlement",
    "evidence", "query_only", "retry_authority",
)


def fail(detail: str) -> None:
    raise SystemExit(f"HOSTED_SETTLEMENT_AUDIT=FAIL detail={detail}")


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def strip_comments(text: str) -> str:
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.DOTALL)
    return re.sub(r"//.*", "", text)


def function_body(text: str, start_needle: str, end_needle: str) -> str:
    start = text.find(start_needle)
    end = text.find(end_needle, start + len(start_needle))
    if start < 0 or end < 0:
        fail(f"function boundary start={start_needle} end={end_needle}")
    return strip_comments(text[start:end])


def verify_source_shape() -> dict[str, object]:
    header = (SOURCE / "include/slopos/e0/handoff_cell/hosted_settlement.hpp").read_text(
        encoding="utf-8")
    impl = (SOURCE / "src/hosted_settlement.cpp").read_text(encoding="utf-8")
    claim_header = (
        SOURCE / "include/slopos/e0/handoff_cell/endpoint_claim.hpp"
    ).read_text(encoding="utf-8")
    claim_impl = (SOURCE / "src/endpoint_claim.cpp").read_text(encoding="utf-8")
    campaign = (SOURCE / "harness/settlement_campaign.cpp").read_text(
        encoding="utf-8")

    for needle in (
        "class HostedSettlementProvider",
        "HostedSettlementProvider(const HostedSettlementProvider&) = delete",
        "submit_exact(",
        "query_exact(",
        "struct SettlementObservation",
        "bool query_only{true}",
        "bool response_authority{false}",
        "bool retry_authority{false}",
        "ClaimedPending&& claim",
        "reconcile_exact(",
    ):
        if needle not in header:
            fail(f"settlement header shape missing={needle}")

    clean_header = strip_comments(header)
    for forbidden in ("retry_exact", "resubmit", "apply", "compensate", "publish"):
        if re.search(rf"\b{forbidden}[A-Za-z0-9_]*\s*\(", clean_header,
                     flags=re.IGNORECASE):
            fail(f"forbidden settlement public endpoint={forbidden}")

    settle = function_body(
        impl, "HostedSettlement::settle_exact", "HostedSettlement::reconcile_exact")
    reconcile = function_body(
        impl, "HostedSettlement::reconcile_exact", "const char* provider_submit_name")
    parser = function_body(
        claim_impl, "PayloadAfterClaim::parse_exact_impl",
        "PayloadAfterClaim::parse_exact(")

    parse_at = settle.find("PayloadAfterClaim::parse_exact_impl")
    submit_at = settle.find("provider.submit_exact")
    if parse_at < 0 or submit_at < 0 or parse_at > submit_at:
        fail("claim consumption/parser gate does not precede provider submit")
    if settle.count("provider.submit_exact") != 1:
        fail("settle entry must contain exactly one provider submit callsite")
    if "provider.query_exact" in settle:
        fail("settle entry contains provider query")
    if re.search(r"\b(for|while)\s*\(|\bdo\s*\{", settle):
        fail("settle entry contains retry-capable loop")
    if "provider.submit_exact" in reconcile:
        fail("reconcile entry contains provider submission")
    if reconcile.count("provider.query_exact") != 1:
        fail("reconcile entry must contain exactly one provider query callsite")
    if re.search(r"\b(for|while)\s*\(|\bdo\s*\{", reconcile):
        fail("reconcile entry contains loop")

    consume_at = parser.find("claim.consume()")
    request_at = parser.find("request_matches(")
    if consume_at < 0 or request_at < 0 or consume_at > request_at:
        fail("request meaning precedes one-use claim consumption")
    if "friend class HostedSettlement" not in claim_header:
        fail("narrow internal settlement parser friendship missing")
    if "parse_exact_impl(" not in claim_header:
        fail("internal consumed-pending parser missing")

    for needle in (
        "SettlementDisposition::uncertain",
        "SettlementEvidence::foreign_or_invalid_result",
        "ProviderSubmitDisposition::no_return",
        "ProviderSubmitDisposition::malformed_return",
        "ProviderQueryDisposition::exact_unused",
        "SettlementDisposition::no_effect",
        "SettlementEvidence::query_exact_unused",
    ):
        if needle not in impl:
            fail(f"settlement implementation law missing={needle}")

    for needle in (
        "rows.size() == 14U",
        "counterexamples.size() == 4U",
        "crash_rows.size() == 4U",
        "sixteen_coherent_claim_histories_one_shared_provider",
        "malformed_return_can_follow_committed_effect",
        "coherent_provider_clones_each_commit_effect",
        "finite_idempotency_retention_reopens_exact_operation",
        "byte_identical_results_from_distinct_providers",
        "after_claim_before_submit",
        "after_effect_commit_before_reply",
        "after_no_effect_commit_before_reply",
        "after_uncertain_commit_before_reply",
    ):
        if needle not in campaign:
            fail(f"settlement campaign shape missing={needle}")

    return {
        "claim_consume_precedes_request_meaning": True,
        "provider_submit_callsites_in_settle": 1,
        "provider_query_callsites_in_reconcile": 1,
        "reconcile_submit_callsites": 0,
        "response_authority": False,
        "retry_authority": False,
        "settle_query_callsites": 0,
        "settle_retry_loops": 0,
    }


def verify_refinement() -> dict[str, object]:
    submit = {
        "EXACT_EFFECT": "EFFECT",
        "EXACT_NO_EFFECT": "NO_EFFECT",
        "EXACT_UNCERTAIN": "UNCERTAIN",
        "EXACT_FAIL_STOP": "FAIL_STOP",
        "NO_RETURN": "UNCERTAIN",
        "UNAVAILABLE": "UNCERTAIN",
        "MALFORMED": "UNCERTAIN",
        "FOREIGN": "UNCERTAIN",
    }
    query = {
        "EXACT_EFFECT": "EFFECT",
        "EXACT_NO_EFFECT": "NO_EFFECT",
        "EXACT_UNCERTAIN": "UNCERTAIN",
        "EXACT_FAIL_STOP": "FAIL_STOP",
        "EXACT_UNUSED": "NO_EFFECT",
        "UNAVAILABLE": "UNCERTAIN",
        "MALFORMED": "UNCERTAIN",
        "FOREIGN": "UNCERTAIN",
    }
    if any(submit[key] != "UNCERTAIN" for key in (
            "NO_RETURN", "UNAVAILABLE", "MALFORMED", "FOREIGN")):
        fail("ambiguous submit flattened")
    if query["EXACT_UNUSED"] != "NO_EFFECT":
        fail("exact-unused query refinement")
    if any(query[key] != "UNCERTAIN" for key in (
            "UNAVAILABLE", "MALFORMED", "FOREIGN")):
        fail("ambiguous query flattened")
    return {
        "ambiguous_submit_outcomes": 4,
        "ambiguous_submit_outcomes_preserving_uncertainty": 4,
        "exact_terminal_results": 4,
        "exact_unused_query_refines_no_effect": True,
        "first_dispatch_paths_in_recovery": 0,
        "global_one_use_proved": False,
        "provider_identity_proved": False,
        "provider_rollback_resistance_proved": False,
        "query_outcomes": len(query),
        "submit_outcomes": len(submit),
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Independently audit hosted settlement evidence.")
    parser.add_argument("campaign", type=Path)
    parser.add_argument("--json", required=True, type=Path)
    args = parser.parse_args()
    campaign = args.campaign.resolve()

    required = {
        "settlement-cases.tsv",
        "settlement-counterexamples.tsv",
        "settlement-crash-cuts.tsv",
        "settlement-races.tsv",
        "settlement-summary.json",
    }
    observed = {path.name for path in campaign.iterdir() if path.is_file()}
    if not required <= observed:
        fail(f"missing={sorted(required - observed)}")

    summary = json.loads(
        (campaign / "settlement-summary.json").read_text(encoding="utf-8"))
    expected_summary = {
        "authority_granted": False,
        "cases": 14,
        "counterexamples": 4,
        "crash_cuts": 4,
        "exact_provider_identity_proved": False,
        "external_rollback_floor": False,
        "hosted_settlement_adapter_implemented": True,
        "independent_reopen": False,
        "protected_effect": False,
        "protected_settlement": False,
        "query_recovery_submit_calls": 0,
        "race_contenders": 16,
        "race_effects": 1,
        "race_local_fresh_claims": 16,
        "race_provider_duplicates": 15,
        "race_provider_fresh_commits": 1,
        "race_provider_submits": 16,
        "race_settled_effect_observations": 16,
        "response_authority": False,
        "retry_authority": False,
        "schema": "slopos.rev0896.hosted-settlement-campaign.v1",
        "status": "PASS",
        "uncertainty_is_retry_permission": False,
    }
    if summary != expected_summary:
        fail("settlement summary mismatch")

    rows = read_tsv(campaign / "settlement-cases.tsv")
    if len(rows) != len(EXPECTED_CASES):
        fail(f"case count={len(rows)}")
    by_name = {row["case"]: row for row in rows}
    if set(by_name) != set(EXPECTED_CASES):
        fail("settlement case inventory")
    for name, expected in EXPECTED_CASES.items():
        observed_values = tuple(by_name[name][field] for field in CASE_FIELDS)
        if observed_values != expected:
            fail(f"case={name} observed={observed_values}")
        if by_name[name]["query_only"] != "true" \
                or by_name[name]["response_authority"] != "false" \
                or by_name[name]["retry_authority"] != "false":
            fail(f"case authority leakage={name}")

    counters = read_tsv(campaign / "settlement-counterexamples.tsv")
    if {row["counterexample"] for row in counters} != EXPECTED_COUNTEREXAMPLES:
        fail("settlement counterexample inventory")
    if any(row["reproduced"] != "true" for row in counters):
        fail("settlement counterexample not reproduced")

    crashes = read_tsv(campaign / "settlement-crash-cuts.tsv")
    crash_by_name = {row["cut"]: row for row in crashes}
    if set(crash_by_name) != set(EXPECTED_CRASH):
        fail("settlement crash inventory")
    for name, expected in EXPECTED_CRASH.items():
        observed_values = tuple(crash_by_name[name][field] for field in CRASH_FIELDS)
        if observed_values != expected:
            fail(f"crash={name} observed={observed_values}")

    races = read_tsv(campaign / "settlement-races.tsv")
    if len(races) != 1:
        fail(f"settlement race rows={len(races)}")
    race = races[0]
    expected_race = {
        "race": "sixteen_coherent_claim_histories_one_shared_provider",
        "contenders": "16",
        "local_fresh_claims": "16",
        "provider_submits": "16",
        "provider_fresh_commits": "1",
        "provider_duplicates": "15",
        "effects": "1",
        "settled_effect_observations": "16",
    }
    if race != expected_race:
        fail(f"settlement race mismatch={race}")

    source_shape = verify_source_shape()
    refinement = verify_refinement()
    audit = {
        "authority_granted": False,
        "cases": len(rows),
        "counterexamples_reproduced": len(counters),
        "crash_cuts": len(crashes),
        "effect_count_in_shared_provider_race": 1,
        "first_dispatch_paths_in_recovery": 0,
        "hosted_settlement_adapter_implemented": True,
        "independent_provider_identity": False,
        "protected_effect": False,
        "protected_settlement": False,
        "provider_fresh_commits_in_shared_race": 1,
        "provider_rollback_floor": False,
        "provider_submits_in_shared_race": 16,
        "query_only_observations": True,
        "race_rows": len(races),
        "refinement": refinement,
        "response_authority": False,
        "retry_authority": False,
        "schema": "slopos.rev0896.hosted-settlement-audit.v1",
        "source_shape": source_shape,
        "status": "PASS",
        "timeout_or_no_return_proves_no_effect": False,
    }
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(
        json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(
        "HOSTED_SETTLEMENT_AUDIT=PASS cases=14 counterexamples=4 "
        "crash_cuts=4 race_provider_commits=1 race_effects=1 "
        "recovery_submit_calls=0 response_authority=false "
        "retry_authority=false protected_settlement=false")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
