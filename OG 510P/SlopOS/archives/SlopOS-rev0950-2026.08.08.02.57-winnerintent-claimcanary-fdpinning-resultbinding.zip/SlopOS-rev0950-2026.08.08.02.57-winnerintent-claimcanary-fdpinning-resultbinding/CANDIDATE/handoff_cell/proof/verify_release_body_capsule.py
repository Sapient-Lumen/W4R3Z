#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json
from pathlib import Path
from typing import NoReturn

def fail(detail: str) -> NoReturn:
    raise SystemExit(f"RELEASE_BODY_CAPSULE_AUDIT=FAIL detail={detail}")

def rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))

def main() -> int:
    parser=argparse.ArgumentParser(); parser.add_argument("output",type=Path); parser.add_argument("--json",required=True,type=Path); args=parser.parse_args()
    cases=rows(args.output/"release-capsule-cases.tsv")
    counters=rows(args.output/"release-capsule-counterexamples.tsv")
    summary=json.loads((args.output/"release-capsule-summary.json").read_text(encoding="utf-8"))
    profile=(args.output/"release-capsule-profile.txt").read_text(encoding="utf-8")
    expected={"archive_admitted":False,"armored_body_profiles":26,"authority":False,"cases":42,"chunk_record_profiles":9,"complete_coverage_profiles":5,"counterexamples_reproduced":24,"network_attempted":False,"provider_operated":False,"release_metadata_profiles":33,"schema":"slopos.rev0910.release-body-capsule-campaign.v22","sealed_capsule_profiles":2,"staging_floor_profiles":19,"status":"PASS","v11_eligible_profiles":1,"whole_digest_profiles":3}
    if summary!=expected: fail(f"summary={summary}")
    if len(cases)!=42 or len(counters)!=24: fail("inventory")
    if any(row["reproduced"]!="true" for row in counters): fail("counterexample")
    if any(row["archive_admitted"]!="false" or row["provider_operated"]!="false" or row["authority"]!="false" for row in cases): fail("mandatory zero")
    if sum(row["coherent"]=="false" for row in cases)!=5: fail("incoherent count")
    if sum(row["v11_eligible"]=="true" for row in cases)!=1: fail("v11 count")
    full=[row for row in cases if row["case"]=="ordered_prefix_36"]
    if len(full)!=1 or full[0]["disposition"]!="v11_recapture_premise": fail("full prefix")
    required={"checksum_without_body","armored_text_as_archive","chunk_count_as_completeness","chunk_digest_as_whole_digest","duplicate_as_second_write","conflict_as_last_writer_wins","base64_pad_alias","whole_digest_before_complete","digest_before_seal","seal_as_release_admission","capsule_as_durable_resume","v11_eligibility_as_authority"}
    missing=sorted(required-{row["counterexample"] for row in counters})
    if missing: fail(f"missing={missing}")
    for fragment in ("release=etcd-v3.6.14-linux-amd64.tar.gz","expected_bytes=24915654","expected_sha256=ffe840ff9295808e88cce2794a18a5ac87f12a5203c8314d0bf6aa119b41bac5","encoding=canonical-rfc4648-base64","ordered_premises=36","whole_digest_before_parse=true","complete_snapshot_seal_before_v11=true","automatic_retry=false","archive_admitted=false","authority=false"):
        if fragment not in profile: fail(f"profile={fragment}")
    audit={"archive_admitted":False,"armored_body_profiles":26,"authority_granted":False,"cases":42,"chunk_record_profiles":9,"complete_coverage_profiles":5,"counterexamples":24,"incoherent_observations":5,"network_attempted":False,"ordered_premises":36,"provider_operated":False,"release_metadata_profiles":33,"schema":"slopos.rev0910.release-body-capsule-audit.v22","sealed_capsule_profiles":2,"staging_floor_profiles":19,"status":"PASS","v11_eligible_profiles":1,"whole_digest_profiles":3}
    args.json.write_text(json.dumps(audit,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print("RELEASE_BODY_CAPSULE_AUDIT=PASS cases=42 counterexamples=24 premises=36 metadata=33 armored=26 staging=19 chunks=9 coverage=5 digest=3 sealed=2 v11=1 archive=false provider=false authority=false")
    return 0
if __name__=="__main__": raise SystemExit(main())
