#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def fail(detail: str) -> None:
    raise SystemExit(f"ACQUISITION_ACTOR_AUDIT=FAIL detail={detail}")


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def truth(value: str) -> bool:
    if value not in {"true", "false"}:
        fail(f"bad boolean={value!r}")
    return value == "true"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()
    cases = rows(args.output / "acquisition-actor-cases.tsv")
    counter = rows(args.output / "acquisition-actor-counterexamples.tsv")
    summary = json.loads(
        (args.output / "acquisition-actor-summary.json").read_text(encoding="utf-8")
    )
    if len(cases) != 28:
        fail(f"case count={len(cases)}")
    if len(counter) != 18 or not all(truth(row["reproduced"]) for row in counter):
        fail("counterexample inventory")
    by_name = {row["case"]: row for row in cases}
    if len(by_name) != len(cases):
        fail("duplicate case")
    positive = [row for row in cases if truth(row["actor_profile_admissible"])]
    if [row["case"] for row in positive] != ["synthetic_exact_dossier"]:
        fail(f"positive rows={[row['case'] for row in positive]}")
    if truth(positive[0]["eligible_for_v13_actor_premise"]):
        fail("V14 dossier alone incorrectly V13 eligible")
    incoherent = [row for row in cases if not truth(row["observation_coherent"])]
    if [row["case"] for row in incoherent] != ["incoherent_descriptor_without_profile"]:
        fail(f"incoherent rows={[row['case'] for row in incoherent]}")
    required_dispositions = {
        "PROFILE_UNAVAILABLE", "EXECUTABLE_DESCRIPTOR_UNPINNED",
        "EXECUTABLE_DIGEST_MISMATCH", "DEPENDENCY_EPOCH_MISMATCH",
        "LAUNCH_ENVELOPE_REJECTED", "PRIVILEGE_IDENTITY_REJECTED",
        "SUPPLEMENTARY_GROUPS_REJECTED", "AMBIENT_CAPABILITIES_REJECTED",
        "NO_NEW_PRIVS_MISSING", "SECCOMP_POLICY_MISSING",
        "INHERITED_DESCRIPTOR_INVENTORY_REJECTED", "SOURCE_POLICY_REJECTED",
        "NETWORK_POLICY_REJECTED", "TIMEOUT_POLICY_REJECTED",
        "RETRY_POLICY_REJECTED", "ADMINISTRATION_INVENTORY_INCOMPLETE",
        "CANDIDATE_LIFECYCLE_POLICY_REJECTED", "OUTPUT_SNAPSHOT_POLICY_REJECTED",
        "PIDFD_COORDINATE_UNAVAILABLE", "PIDFD_GET_INFO_UNAVAILABLE",
        "PIDFD_INFO_INCOMPLETE", "PIDFD_COORDINATE_MISMATCH",
        "APPRAISER_UNAVAILABLE", "APPRAISER_NOT_INDEPENDENT",
        "APPRAISAL_RECONSTRUCTION_FAILED", "APPRAISAL_CHALLENGE_FAILED",
        "OBSERVATION_INCOHERENT", "ACTOR_PROFILE_ADMISSIBLE",
    }
    observed_dispositions = {row["disposition"] for row in cases}
    if observed_dispositions != required_dispositions:
        fail(f"dispositions={sorted(observed_dispositions)}")
    mandatory_false = (
        "ready_sent", "rights_imported", "candidate_created",
        "candidate_bytes_read", "archive_acquired", "archive_admitted",
        "source_provenance_proved", "owner_authority", "living_law",
    )
    for row in cases:
        for field in mandatory_false:
            if truth(row[field]):
                fail(f"authority leak case={row['case']} field={field}")
    expected_summary = {
        "admissible_profiles": 1,
        "appraiser_independence_required": True,
        "archive_acquired": False,
        "archive_admitted": False,
        "candidate_bytes_read": False,
        "candidate_created": False,
        "cases": 28,
        "counterexamples_reproduced": 18,
        "host_applicable_profiles": 0,
        "incoherent_observations": 1,
        "living_law": False,
        "owner_authority": False,
        "pidfd_get_info_required": True,
        "ready_sent": False,
        "retry_budget_zero_required": True,
        "rights_imported": False,
        "schema": "slopos.rev0903.acquisition-actor-admission-campaign.v14-corrected",
        "source_provenance_proved": False,
        "status": "PASS",
        "synthetic_v13_eligible_profiles": 0,
        "v15_launch_binding_required": True,
    }
    if summary != expected_summary:
        fail(f"summary mismatch={summary}")
    audit = {
        "admissible_profiles": 1,
        "archive_acquired": False,
        "archive_admitted": False,
        "candidate_bytes_read": False,
        "cases": 28,
        "counterexamples": 18,
        "host_applicable_profiles": 0,
        "incoherent_observations": 1,
        "living_law": False,
        "owner_authority": False,
        "pidfd_get_info_required": True,
        "ready_sent": False,
        "rights_imported": False,
        "schema": "slopos.rev0903.acquisition-actor-admission-audit.v2",
        "source_provenance_proved": False,
        "status": "PASS",
        "synthetic_v13_eligible_profiles": 0,
        "v15_launch_binding_required": True,
    }
    args.json.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n",
                         encoding="utf-8")
    print("ACQUISITION_ACTOR_AUDIT=PASS cases=28 counterexamples=18 synthetic_admissible=1 v13_eligible=0 host_applicable=0 ready=false archive=false authority=false")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
