#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json
from pathlib import Path
from typing import NoReturn

def fail(detail: str) -> NoReturn:
    raise SystemExit(f"RELEASE_BODY_CAPSULE_HOST_AUDIT=FAIL detail={detail}")

def rows(path: Path) -> list[dict[str,str]]:
    with path.open(newline="",encoding="utf-8") as stream: return list(csv.DictReader(stream,delimiter="\t"))

def main() -> int:
    parser=argparse.ArgumentParser(); parser.add_argument("output",type=Path); parser.add_argument("--json",required=True,type=Path); args=parser.parse_args()
    cases=rows(args.output/"release-capsule-host-cases.tsv"); counters=rows(args.output/"release-capsule-host-counterexamples.tsv")
    summary=json.loads((args.output/"release-capsule-host-summary.json").read_text(encoding="utf-8"))
    expected={"archive_admitted":False,"archive_body_bytes":0,"archive_parse_attempts":0,"authority":False,"canonical_base64":True,"cases":36,"chunk_bytes":1024,"chunks":9,"conflicting_duplicate_poisoned":True,"counterexamples_reproduced":24,"execution_attempts":0,"extraction_attempts":0,"grow_after_seal_refused":True,"identical_duplicate_query_only":True,"network_attempted":False,"out_of_order_accepted":True,"provider_operated":False,"schema":"slopos.rev0910.release-body-capsule-host-probe.v22","shrink_after_seal_refused":True,"snapshot_sealed":True,"status":"PASS","synthetic_fixture_bytes":8193,"v11_recapture_required":True,"whole_digest_exact":True,"write_after_seal_refused":True}
    if summary!=expected: fail(f"summary={summary}")
    if len(cases)!=36 or len(counters)!=24: fail("inventory")
    if any(row["pass"]!="true" for row in cases): fail("case failure")
    if any(row["reproduced"]!="true" for row in counters): fail("counterexample")
    required={"partial_coverage_as_whole_object","wrong_session_as_same_capsule","whitespace_as_transport_noise","nonzero_pad_bits_as_alias","last_writer_wins_duplicate","poison_then_continue","chunk_hashes_as_whole_hash","preallocated_holes_as_coverage","identical_duplicate_as_second_write","write_after_seal","grow_after_seal","shrink_after_seal","synthetic_fixture_as_release","capsule_as_archive_parser","capsule_as_authority"}
    missing=sorted(required-{row["counterexample"] for row in counters})
    if missing: fail(f"missing={missing}")
    audit={"archive_admitted":False,"archive_body_bytes":0,"archive_parse_attempts":0,"authority_granted":False,"canonical_base64":True,"cases":36,"chunk_bytes":1024,"chunks":9,"conflicting_duplicate_poisoned":True,"counterexamples":24,"execution_attempts":0,"extraction_attempts":0,"grow_after_seal_refused":True,"identical_duplicate_query_only":True,"network_attempted":False,"out_of_order_accepted":True,"provider_operated":False,"schema":"slopos.rev0910.release-body-capsule-host-audit.v22","shrink_after_seal_refused":True,"snapshot_sealed":True,"status":"PASS","synthetic_fixture_bytes":8193,"v11_recapture_required":True,"whole_digest_exact":True,"write_after_seal_refused":True}
    args.json.write_text(json.dumps(audit,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print("RELEASE_BODY_CAPSULE_HOST_AUDIT=PASS cases=36 counterexamples=24 fixture=8193 chunks=9 canonical=true shuffled=true duplicate=query-only conflict=poison digest=true sealed=true archive_bytes=0 parse=0 network=false provider=false authority=false")
    return 0
if __name__=="__main__": raise SystemExit(main())
