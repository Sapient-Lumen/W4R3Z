#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,json
from pathlib import Path
def fail(d:str)->None:raise SystemExit(f"APPRAISER_RECEIPT_SPEND_AUDIT=FAIL detail={d}")
def rows(p:Path)->list[dict[str,str]]:
 with p.open(newline="",encoding="utf-8") as s:return list(csv.DictReader(s,delimiter="\t"))
def truth(v:str)->bool:
 if v not in {"true","false"}:fail(f"bad boolean={v!r}")
 return v=="true"
def main()->int:
 ap=argparse.ArgumentParser();ap.add_argument("output",type=Path);ap.add_argument("--json",type=Path,required=True);a=ap.parse_args();cases=rows(a.output/"appraiser-receipt-spend-cases.tsv");counter=rows(a.output/"appraiser-receipt-spend-counterexamples.tsv");summary=json.loads((a.output/"appraiser-receipt-spend-summary.json").read_text())
 if len(cases)!=56 or len({r['case'] for r in cases})!=56:fail(f"case inventory={len(cases)}")
 if len(counter)!=32 or len({r['counterexample'] for r in counter})!=32:fail(f"counter inventory={len(counter)}")
 if not all(truth(r['reproduced']) for r in counter):fail("unreproduced counterexample")
 expected={"canonical_cross_bound":35,"content_bound_spend":25,"compare_append_request":24,"one_local_spend":18,"duplicate_query_only":15,"external_floor":8,"independent_constitution":3,"externally_spent":1,"v13_eligible":1,"clone_replay_excluded":1};names={}
 for field,count in expected.items():
  names[field]=[r['case'] for r in cases if truth(r[field])]
  if len(names[field])!=count:fail(f"{field} count={len(names[field])} rows={names[field]}")
 for wider,narrower in zip(expected,list(expected)[1:]):
  if names[wider][-len(names[narrower]):]!=names[narrower]:fail(f"ordered suffix={wider}->{narrower}")
 if names['externally_spent']!=['ordered_prefix_53']:fail(f"external rows={names['externally_spent']}")
 incoherent=[r['case'] for r in cases if not truth(r['coherent'])]
 if incoherent!=['incoherent_signature_gap','incoherent_floor_gap']:fail(f"incoherent={incoherent}")
 if any(truth(r['authority']) for r in cases):fail('authority leak')
 expected_summary={"authority":False,"canonical_cross_bound_profiles":35,"cases":56,"content_bound_spend_profiles":25,"counterexamples_reproduced":32,"envelope_mutation_rejections":3840,"external_floor_profiles":8,"externally_spent_profiles":1,"local_spend_profiles":18,"network_attempted":False,"ready_sent":False,"rights_imported":False,"schema":"slopos.rev0906.appraiser-receipt-spend-campaign.v18","spend_record_bytes":352,"spend_record_mutation_rejections":2816,"status":"PASS"}
 if summary!=expected_summary:fail(f"summary mismatch={summary}")
 audit={"authority_granted":False,"canonical_cross_bound_profiles":35,"cases":56,"content_bound_spend_profiles":25,"counterexamples":32,"external_floor_profiles":8,"externally_spent_profiles":1,"incoherent_observations":2,"local_spend_profiles":18,"mutation_rejections":6656,"network_attempted":False,"portable_clone_replay_excluded_profiles":1,"schema":"slopos.rev0906.appraiser-receipt-spend-audit.v18","status":"PASS","v13_eligible_profiles":1};a.json.write_text(json.dumps(audit,indent=2,sort_keys=True)+"\n");print("APPRAISER_RECEIPT_SPEND_AUDIT=PASS cases=56 counterexamples=32 crossbound=35 content=25 local=18 external_floor=8 external=1 mutations=6656 authority=false");return 0
if __name__=='__main__':raise SystemExit(main())
