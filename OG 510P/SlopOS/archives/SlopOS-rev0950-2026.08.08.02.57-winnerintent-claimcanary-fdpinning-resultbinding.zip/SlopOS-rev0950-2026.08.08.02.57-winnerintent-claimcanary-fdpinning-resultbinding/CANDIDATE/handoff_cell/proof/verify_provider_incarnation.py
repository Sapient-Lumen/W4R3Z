#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json
from pathlib import Path

def fail(detail: str) -> "NoReturn":
    raise SystemExit(f"PROVIDER_INCARNATION_AUDIT=FAIL detail={detail}")

def rows(path: Path):
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))

def main() -> int:
    parser=argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--json", required=True, type=Path)
    args=parser.parse_args()
    cases=rows(args.output/"provider-incarnation-cases.tsv")
    counters=rows(args.output/"provider-incarnation-counterexamples.tsv")
    summary=json.loads((args.output/"provider-incarnation-summary.json").read_text())
    profile=(args.output/"provider-incarnation-profile.txt").read_text()
    expected={
        "archive_admitted_profiles":56,
        "authority":False,
        "cases":68,
        "counterexamples_reproduced":42,
        "custody_inventory_profiles":40,
        "external_provider_eligible_profiles":1,
        "incarnation_coordinate_profiles":44,
        "independent_reopen_profiles":1,
        "network_attempted":False,
        "operated_transaction_profiles":23,
        "provider_operated":False,
        "quorum_agreement_profiles":15,
        "release_metadata_profiles":60,
        "schema":"slopos.rev0909.provider-incarnation-campaign.v21",
        "status":"PASS",
        "succession_profiles":10,
    }
    if summary != expected: fail(f"summary={summary}")
    if len(cases)!=68 or len(counters)!=42: fail("inventory")
    if any(row["reproduced"]!="true" for row in counters): fail("counterexample")
    if any(row["provider_operated"]!="false" or row["authority"]!="false" for row in cases): fail("mandatory zero")
    if sum(row["coherent"]=="false" for row in cases)!=4: fail("incoherent count")
    if sum(row["independent_reopen"]=="true" for row in cases)!=1: fail("reopen count")
    required={"release_tag_without_archive","matching_hashkv_only","revision_bump_only","same_root_second_user_namespace","full_synthetic_relation_as_operation"}
    missing=sorted(required-{row["counterexample"] for row in counters})
    if missing: fail(f"missing={missing}")
    for fragment in ("release=v3.6.14","ordered_premises=63","provider_operated=false","authority=false"):
        if fragment not in profile: fail(f"profile={fragment}")
    audit={
        "archive_admitted_profiles":56,
        "authority_granted":False,
        "cases":68,
        "counterexamples":42,
        "custody_inventory_profiles":40,
        "external_provider_eligible_profiles":1,
        "incarnation_coordinate_profiles":44,
        "independent_reopen_profiles":1,
        "network_attempted":False,
        "operated_transaction_profiles":23,
        "ordered_premises":63,
        "provider_operated":False,
        "quorum_agreement_profiles":15,
        "release_metadata_profiles":60,
        "schema":"slopos.rev0909.provider-incarnation-audit.v21",
        "status":"PASS",
        "succession_profiles":10,
    }
    args.json.write_text(json.dumps(audit,indent=2,sort_keys=True)+"\n")
    print("PROVIDER_INCARNATION_AUDIT=PASS cases=68 counterexamples=42 premises=63 metadata=60 archive=56 coordinates=44 custody=40 operation=23 agreement=15 succession=10 reopen=1 provider=false authority=false")
    return 0
if __name__=="__main__": raise SystemExit(main())
