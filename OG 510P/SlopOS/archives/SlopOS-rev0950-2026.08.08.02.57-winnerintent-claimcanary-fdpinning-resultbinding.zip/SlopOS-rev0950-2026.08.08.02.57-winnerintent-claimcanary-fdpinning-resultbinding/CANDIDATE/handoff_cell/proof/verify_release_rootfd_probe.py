#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
SOURCE = ROOT / "CANDIDATE/handoff_cell/harness/release_rootfd_probe.cpp"


def fail(detail: str) -> None:
    raise SystemExit(f"RELEASE_ROOTFD_PROBE_AUDIT=FAIL detail={detail}")


def rows(path: Path, fields: list[str]) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        if reader.fieldnames != fields:
            fail(f"header={path.name} observed={reader.fieldnames}")
        output = list(reader)
    if any(any(value is None or value == "" for value in row.values()) for row in output):
        fail(f"empty_or_short_row={path.name}")
    return output


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--json", required=True, type=Path)
    args = parser.parse_args()

    summary = json.loads(
        (args.output / "release-rootfd-summary.json").read_text(encoding="utf-8")
    )
    expected = {
        "activation_authority": False,
        "archive_digest_compared": False,
        "archive_parsed": False,
        "cases": 21,
        "counterexamples": 11,
        "cross_mount_rejected": True,
        "fixed_leaf_components": 1,
        "fixed_leaf_regular_same_device": True,
        "fixed_leaf_single_component": True,
        "leaf_symlink_rejected": True,
        "legacy_fifo_opened_before_shape_check": True,
        "openat2_regular_required": True,
        "openat2_regular_supported": False,
        "openat2_supported": True,
        "owner_custody_proved": False,
        "path_reopen_reads_replacement": True,
        "post_open_shape_check_is_too_late": True,
        "production_candidate_descriptor_ready": False,
        "production_stop_reason": "HOST_OPENAT2_REGULAR_UNAVAILABLE",
        "pinned_root_reads_original": True,
        "resolve_policy": "BENEATH|NO_SYMLINKS|NO_MAGICLINKS|NO_XDEV",
        "root_descriptor_profile": "O_PATH_DIRECTORY_EUID_0700_CLOEXEC",
        "root_owner_matches_euid": True,
        "root_identity_stable": True,
        "root_profile_aba_reproduced": True,
        "root_profile_continuity_proved": False,
        "root_profile_drift_open_succeeds": True,
        "root_profile_endpoint_equality_observed": True,
        "rooted_leaf_mutable_before_snapshot": True,
        "schema": "slopos.rev0900.release-rootfd-probe.v4",
        "source_provenance_proved": False,
        "status": "PASS",
        "widened_leaf_tail_nofollow_ancestor_escape_reproduced": True,
        "unknown_resolve_bit_rejected": True,
    }
    if summary != expected:
        fail(f"summary={summary!r}")

    cases = rows(
        args.output / "release-rootfd-cases.tsv",
        ["case", "expected", "observed", "status"],
    )
    counters = rows(
        args.output / "release-rootfd-counterexamples.tsv",
        ["id", "tempting_inference", "counterexample", "consequence"],
    )
    expected_cases = {
        "openat2_supported", "openat2_regular_supported",
        "legacy_fifo_open_before_fstat", "production_regular_only_gate",
        "root_descriptor_profile", "initial_rooted_open",
        "root_path_replacement", "pinned_root_after_replacement",
        "reopened_root_after_replacement", "pinned_root_identity",
        "fixed_leaf_shape", "leaf_symlink", "widened_leaf_ancestor_symlink_openat2",
        "widened_leaf_ancestor_symlink_tail_nofollow", "dotdot_escape", "absolute_escape",
        "cross_mount", "unknown_resolve_bit", "root_profile_change_after_pin",
        "root_profile_aba_between_checks", "rooted_leaf_before_snapshot",
    }
    if {row["case"] for row in cases} != expected_cases or any(
        row["status"] != "PASS" for row in cases
    ):
        fail("case coverage")
    if [row["id"] for row in counters] != [f"RF{i:02d}" for i in range(1, 12)]:
        fail("counterexample coverage")

    source = SOURCE.read_text(encoding="utf-8")
    for fragment in (
        "SYS_openat2",
        "RESOLVE_BENEATH | RESOLVE_NO_SYMLINKS",
        "RESOLVE_NO_MAGICLINKS | RESOLVE_NO_XDEV",
        "O_PATH | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW",
        "root_path_identity_changed",
        "pinned_root_reads_original",
        "reopened_root_reads_replacement",
        "widened_leaf_tail_nofollow_follows_ancestor",
        "dotdot_escape_rejected",
        "absolute_escape_rejected",
        "cross_mount_rejected",
        "unknown_resolve_rejected", "kOpenat2Regular",
        "openat2_regular_unavailable", "legacy_fifo_opened_before_shape_check",
        "production_candidate_descriptor_ready",
        "root_profile_drift_open_succeeds",
        "root_profile_aba_endpoint_equality",
        "rooted_leaf_still_mutable_before_snapshot",
        '"activation_authority\\": false',
        '"archive_parsed\\": false',
    ):
        if fragment not in source:
            fail(f"source fragment={fragment}")
    for forbidden in ("::system(", "::exec", "::popen(", "posix_spawn("):
        if forbidden in source:
            fail(f"activation surface={forbidden}")

    audit = {
        "activation_callsites": 0,
        "cases": len(cases),
        "counterexamples": len(counters),
        "cross_mount_rejected": True,
        "fixed_leaf_components": 1,
        "fixed_leaf_only": True,
        "fixed_leaf_single_component": True,
        "legacy_fifo_opened_before_shape_check": True,
        "openat2_complete_resolve_mask": True,
        "openat2_regular_required": True,
        "openat2_regular_supported": False,
        "owner_custody_proved": False,
        "post_open_shape_check_is_too_late": True,
        "production_candidate_descriptor_ready": False,
        "root_path_reopen_substitution_reproduced": True,
        "root_profile_aba_reproduced": True,
        "root_profile_continuity_proved": False,
        "root_profile_drift_open_succeeds": True,
        "rooted_leaf_mutability_before_snapshot_reproduced": True,
        "schema": "slopos.rev0900.release-rootfd-probe-audit.v4",
        "source_provenance_proved": False,
        "status": "PASS",
        "widened_leaf_tail_nofollow_ancestor_escape_reproduced": True,
    }
    args.json.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(
        "RELEASE_ROOTFD_PROBE_AUDIT=PASS cases=21 counterexamples=11 "
        "openat2_mask=true openat2_regular=false production=STOP fifo_before_fstat=true root_swap=true widened_leaf_regression=true "
        "profile_drift_open=true profile_aba=true continuity=false mutable_before_snapshot=true "
        "activation_callsites=0 authority=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
