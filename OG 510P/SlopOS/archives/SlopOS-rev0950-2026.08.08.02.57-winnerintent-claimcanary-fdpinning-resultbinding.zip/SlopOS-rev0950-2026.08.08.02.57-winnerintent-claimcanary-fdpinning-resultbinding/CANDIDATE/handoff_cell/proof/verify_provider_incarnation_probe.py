#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json
from pathlib import Path

def fail(detail: str) -> "NoReturn":
    raise SystemExit(f"PROVIDER_INCARNATION_HOST_AUDIT=FAIL detail={detail}")

def rows(path: Path):
    with path.open(newline="",encoding="utf-8") as stream:
        return list(csv.DictReader(stream,delimiter="\t"))

def main() -> int:
    parser=argparse.ArgumentParser()
    parser.add_argument("output",type=Path)
    parser.add_argument("--json",required=True,type=Path)
    args=parser.parse_args()
    cases=rows(args.output/"provider-incarnation-host-cases.tsv")
    counters=rows(args.output/"provider-incarnation-host-counterexamples.tsv")
    summary=json.loads((args.output/"provider-incarnation-host-summary.json").read_text())
    expected={
        "archive_body_bytes":0,
        "archive_body_present":False,
        "authority":False,
        "cases":28,
        "checksum_product_exact":True,
        "counterexamples_reproduced":20,
        "distinct_user_namespaces":True,
        "external_currentness_bound":False,
        "independent_administration":False,
        "independent_reopen_bound":False,
        "network_attempted":False,
        "outer_parent_control":True,
        "pidfd_control":True,
        "provider_operated":False,
        "schema":"slopos.rev0909.provider-incarnation-host-probe.v21",
        "stable_storage_contract_bound":False,
        "status":"PASS",
        "transfer_policy_refused_archive":True,
        "unprivileged_userns_supported":True,
    }
    if summary!=expected: fail(f"summary={summary}")
    if len(cases)!=28 or len(counters)!=20: fail("inventory")
    if any(row["pass"]!="true" for row in cases): fail("case failure")
    if any(row["reproduced"]!="true" for row in counters): fail("counterexample")
    required={"checksum_without_archive","distinct_userns_as_independent_owner","archive_refusal_retry","same_root_reopener","synthetic_relation_as_operation"}
    missing=sorted(required-{row["counterexample"] for row in counters})
    if missing: fail(f"missing={missing}")
    audit={
        "archive_body_bytes":0,
        "archive_body_present":False,
        "authority_granted":False,
        "cases":28,
        "checksum_product_exact":True,
        "counterexamples":20,
        "distinct_user_namespaces":True,
        "external_currentness_bound":False,
        "independent_administration":False,
        "independent_reopen_bound":False,
        "network_attempted":False,
        "outer_parent_control":True,
        "pidfd_control":True,
        "provider_operated":False,
        "schema":"slopos.rev0909.provider-incarnation-host-audit.v21",
        "stable_storage_contract_bound":False,
        "status":"PASS",
        "transfer_policy_refused_archive":True,
        "unprivileged_userns_supported":True,
    }
    args.json.write_text(json.dumps(audit,indent=2,sort_keys=True)+"\n")
    print("PROVIDER_INCARNATION_HOST_AUDIT=PASS cases=28 counterexamples=20 checksum=true transfer_refused=true archive_bytes=0 userns=true outer_control=true provider=false independent=false authority=false")
    return 0
if __name__=="__main__": raise SystemExit(main())
