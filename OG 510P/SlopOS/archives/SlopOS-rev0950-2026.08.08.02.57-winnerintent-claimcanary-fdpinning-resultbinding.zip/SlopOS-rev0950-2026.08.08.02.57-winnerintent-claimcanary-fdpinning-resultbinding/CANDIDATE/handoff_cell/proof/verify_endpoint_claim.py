#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent

EXPECTED_CASES = {
    "exact_claim_precedes_payload": (
        "CLAIMED_EXACT", "EXACT_REQUEST", "false", "true", "1", "1", "1", "false", "false"),
    "duplicate_after_exact_is_query_only": (
        "ALREADY_CLAIMED_EXACT", "NOT_CALLED", "false", "true", "0", "0", "0", "true", "false"),
    "malformed_payload_consumes_claim": (
        "CLAIMED_EXACT", "MALFORMED_REQUEST", "false", "true", "1", "1", "0", "false", "false"),
    "retry_after_malformed_is_query_only": (
        "ALREADY_CLAIMED_EXACT", "NOT_CALLED", "false", "true", "0", "0", "0", "true", "false"),
    "malformed_pending_claims_then_fails_stop": (
        "DECODE_REJECTED", "NOT_CALLED", "false", "true", "0", "0", "0", "true", "false"),
    "fifo_claims_then_rejects_nonregular": (
        "NOT_REGULAR", "NOT_CALLED", "false", "true", "0", "0", "0", "true", "false"),
    "preexisting_claimed_exact_is_query_only": (
        "ALREADY_CLAIMED_EXACT", "NOT_CALLED", "true", "true", "0", "0", "0", "true", "false"),
    "preexisting_claimed_conflict_fails_stop": (
        "EXACT_MISMATCH", "NOT_CALLED", "true", "true", "0", "0", "0", "true", "false"),
    "missing_pending_no_mint": (
        "PENDING_MISSING", "NOT_CALLED", "false", "false", "0", "0", "0", "true", "false"),
    "directory_sync_failure_denies_parser": (
        "CLAIMED_EXACT_SYNC_UNCERTAIN", "NOT_CALLED", "false", "true", "0", "0", "0", "true", "false"),
    "hardlink_alias_detected_after_claim": (
        "ALIAS_DETECTED", "NOT_CALLED", "false", "true", "0", "0", "0", "true", "true"),
    "inherited_writer_defeats_content_custody": (
        "CLAIMED_EXACT", "EXACT_REQUEST", "false", "true", "1", "1", "1", "false", "true"),
    "coherent_clone_claims_once_per_history": (
        "TWO_CLAIMED_EXACT", "TWO_EXACT_REQUESTS", "false", "true", "2", "2", "2", "false", "true"),
    "snapshot_rollback_restores_pending": (
        "TWO_CLAIMED_EXACT_ACROSS_ROLLBACK", "TWO_EXACT_REQUESTS", "false", "true", "2", "2", "2", "false", "true"),
}

EXPECTED_COUNTEREXAMPLES = {
    "hard_link_alias_survives_namespace_claim",
    "open_writable_descriptor_survives_claim",
    "coherent_directory_clone_claims_once_each",
    "directory_snapshot_rollback_restores_pending",
}


def fail(detail: str) -> None:
    raise SystemExit(f"ENDPOINT_CLAIM_AUDIT=FAIL detail={detail}")


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def strip_comments(text: str) -> str:
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.DOTALL)
    return re.sub(r"//.*", "", text)


def verify_source_shape() -> dict[str, object]:
    header = (SOURCE / "include/slopos/e0/handoff_cell/endpoint_claim.hpp").read_text(
        encoding="utf-8")
    impl = (SOURCE / "src/endpoint_claim.cpp").read_text(encoding="utf-8")
    campaign = (SOURCE / "harness/endpoint_claim_campaign.cpp").read_text(
        encoding="utf-8")

    for needle in (
        'kClaimedLeaf[] = "claimed"',
        "ClaimedPending(const ClaimedPending&) = delete",
        "EndpointClaimObservation",
        "synchronization_uncertain()",
        "bool response_authority{false}",
        "claim_pending_exact(",
        "observe_claimed_exact(",
        "PayloadAfterClaim",
        "ClaimedPending&& claim",
    ):
        if needle not in header:
            fail(f"header shape missing={needle}")

    clean_header = strip_comments(header)
    for forbidden in (
        "retry", "repair", "rollback", "reverse", "cleanup", "replace",
        "settle", "respond", "publish", "apply",
    ):
        if re.search(rf"\b{forbidden}[A-Za-z0-9_]*\s*\(", clean_header,
                     flags=re.IGNORECASE):
            fail(f"forbidden public endpoint={forbidden}")

    claim_start = impl.find("EndpointClaimCell::claim_pending_exact")
    claim_end = impl.find("EndpointClaimCell::observe_claimed_exact", claim_start)
    if claim_start < 0 or claim_end < 0:
        fail("claim implementation boundary")
    claim_body = impl[claim_start:claim_end]
    rename_index = claim_body.find("rename_pending_to_claimed(directory_fd_)")
    read_index = claim_body.find("read_claimed_exact(")
    if rename_index < 0 or read_index < 0 or rename_index > read_index:
        fail("pending semantics observed before fixed rename")
    for forbidden in (
        "::unlink(", "::unlinkat(", "::rename(", "::renameat(",
        "::link(", "::linkat(", "::truncate(", "::ftruncate(",
    ):
        if forbidden in strip_comments(claim_body):
            fail(f"claim mutation surface={forbidden}")
    if re.search(
            r"if\s*\(\s*synced\s*&&\s*read\.disposition\s*==\s*"
            r"ReadDisposition::exact\s*\)", claim_body) is None:
        fail("sync uncertainty can mint parser token")

    fresh_start = header.find("constexpr bool fresh_exact()")
    fresh_end = header.find("constexpr bool synchronization_uncertain()", fresh_start)
    if fresh_start < 0 or fresh_end < 0 \
            or "claimed_exact_sync_uncertain" in header[fresh_start:fresh_end]:
        fail("sync uncertainty reports fresh parser eligibility")

    parser_start = impl.find("PayloadAfterClaim::parse_exact")
    if parser_start < 0:
        fail("parser implementation missing")
    parser_body = impl[parser_start:impl.find("const char* endpoint_claim_name", parser_start)]
    consume_index = parser_body.find("claim.consume()")
    request_index = parser_body.find("request_matches(")
    if consume_index < 0 or request_index < 0 or consume_index > request_index:
        fail("request semantics precede claim consumption")

    for needle in (
        "sixteen_process_fixed_claim",
        "after_raw_rename_before_validation",
        "after_fresh_token_before_payload",
        "after_payload_before_reply",
        "hard_link_alias_survives_namespace_claim",
        "open_writable_descriptor_survives_claim",
        "coherent_directory_clone_claims_once_each",
        "directory_snapshot_rollback_restores_pending",
        "directory_sync_failure_denies_parser",
        "O_PATH | O_DIRECTORY | O_CLOEXEC",
        "rows.size() == 14U",
        "counterexamples.size() == 4U",
    ):
        if needle not in campaign:
            fail(f"campaign shape missing={needle}")

    return {
        "copyable_observation_authority": False,
        "fixed_claim_mutation_entrypoints": 1,
        "move_only_claim": True,
        "payload_parser_entrypoints": 1,
        "query_only_observation_entrypoints": 1,
        "rename_precedes_claimed_read": True,
        "token_consume_precedes_request_read": True,
    }


def verify_refinement() -> dict[str, object]:
    states = {
        "PENDING": (True, False, False),
        "CLAIMED_FRESH": (False, True, True),
        "CLAIMED_SYNC_UNCERTAIN": (False, True, False),
        "CLAIMED_SPENT": (False, True, False),
    }
    claim = {"PENDING": "CLAIMED_FRESH"}
    sync_uncertain_claim = {"PENDING": "CLAIMED_SYNC_UNCERTAIN"}
    parser = {
        ("CLAIMED_FRESH", "EXACT"): "CLAIMED_SPENT",
        ("CLAIMED_FRESH", "MALFORMED"): "CLAIMED_SPENT",
    }
    duplicates = {
        "CLAIMED_FRESH": "QUERY_ONLY",
        "CLAIMED_SYNC_UNCERTAIN": "QUERY_ONLY",
        "CLAIMED_SPENT": "QUERY_ONLY",
    }
    if claim["PENDING"] != "CLAIMED_FRESH":
        fail("claim refinement")
    if sync_uncertain_claim["PENDING"] != "CLAIMED_SYNC_UNCERTAIN" \
            or states["CLAIMED_SYNC_UNCERTAIN"][2]:
        fail("sync uncertainty refinement")
    if set(parser.values()) != {"CLAIMED_SPENT"}:
        fail("parser outcome does not consume token")
    if set(duplicates.values()) != {"QUERY_ONLY"}:
        fail("duplicate refinement")
    if states["PENDING"][1] or states["CLAIMED_FRESH"][0]:
        fail("namespace partition")
    coherent_histories = 2
    return {
        "coherent_history_fresh_claims": coherent_histories,
        "duplicate_payload_entry_transitions": 0,
        "global_unique_claim_proved": False,
        "namespace_states": len(states),
        "parse_outcomes_consuming_token": len(parser),
        "payload_semantics_before_claim": False,
        "protected_provider_proved": False,
        "sync_uncertain_parser_entries": 0,
        "sync_uncertain_query_only": True,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Independently audit endpoint claim-before-parse evidence.")
    parser.add_argument("campaign", type=Path)
    parser.add_argument("--json", required=True, type=Path)
    args = parser.parse_args()
    campaign = args.campaign.resolve()

    required = {
        "endpoint-claim-cases.tsv",
        "endpoint-claim-counterexamples.tsv",
        "endpoint-claim-crash-cuts.tsv",
        "endpoint-claim-races.tsv",
        "endpoint-claim-summary.json",
    }
    observed = {path.name for path in campaign.iterdir() if path.is_file()}
    if not required <= observed:
        fail(f"missing={sorted(required - observed)}")

    summary = json.loads(
        (campaign / "endpoint-claim-summary.json").read_text(encoding="utf-8"))
    expected_summary = {
        "schema": "slopos.rev0895.endpoint-claim-before-parse-evidence.v1",
        "status": "PASS",
        "cases": 14,
        "counterexamples_reproduced": 4,
        "crash_cuts": 4,
        "fixed_pending_leaf": "pending",
        "claim_leaf": "claimed",
        "rename_flag": "RENAME_NOREPLACE",
        "claim_before_payload_parse_observed": True,
        "duplicate_claim_query_only": True,
        "move_only_claim_token": True,
        "payload_request_bytes": 96,
        "payload_parser_entrypoints": 1,
        "fixed_claim_mutation_entrypoints": 1,
        "recovery_payload_entrypoints": 0,
        "maximum_payload_entries_per_fresh_local_claim": 1,
        "race_contenders": 16,
        "race_fresh_claims": 1,
        "race_query_only_duplicates": 15,
        "race_payload_entries": 1,
        "race_exact_accepts": 1,
        "coherent_clone_fresh_claims": 2,
        "hardlink_alias_counterexample_reproduced": True,
        "inherited_writer_counterexample_reproduced": True,
        "directory_snapshot_rollback_reproduced": True,
        "global_unique_claim_proved": False,
        "protected_pending_entry_claim": False,
        "settlement_implemented": False,
        "effect_performed": False,
        "response_authority": False,
        "external_rollback_floor": False,
        "physical_power_loss_proved": False,
        "stable_media_proved": False,
        "sync_uncertain_claim_query_only": True,
        "sync_uncertain_fresh_claims": 0,
        "sync_uncertain_namespace_claimed": True,
        "sync_uncertain_payload_entries": 0,
        "sync_uncertain_reopen_query_only": True,
        "source_to_binary_proved": False,
        "authority_granted": False,
    }
    for key, expected in expected_summary.items():
        if summary.get(key) != expected:
            fail(f"summary {key} expected={expected!r} observed={summary.get(key)!r}")

    cases = read_tsv(campaign / "endpoint-claim-cases.tsv")
    by_name = {row["case"]: row for row in cases}
    if set(by_name) != set(EXPECTED_CASES):
        fail("case inventory")
    for name, expected in EXPECTED_CASES.items():
        row = by_name[name]
        observed_case = (
            row["claim"], row["payload"], row["pending"], row["claimed"],
            row["fresh_tokens"], row["payload_entries"], row["exact_accepts"],
            row["query_only"], row["retained_counterexample"],
        )
        if observed_case != expected:
            fail(f"case mismatch={name}")

    counterexamples = read_tsv(
        campaign / "endpoint-claim-counterexamples.tsv")
    if {row["counterexample"] for row in counterexamples} != EXPECTED_COUNTEREXAMPLES:
        fail("counterexample inventory")
    if any(row["reproduced"] != "true" for row in counterexamples):
        fail("counterexample not reproduced")

    races = read_tsv(campaign / "endpoint-claim-races.tsv")
    expected_race = {
        "scenario": "sixteen_process_fixed_claim",
        "contenders": "16",
        "fresh_claims": "1",
        "query_only_duplicates": "15",
        "payload_entries": "1",
        "exact_accepts": "1",
        "judgment": "ONE_LOCAL_WINNER",
    }
    if races != [expected_race]:
        fail("race relation")

    crashes = read_tsv(campaign / "endpoint-claim-crash-cuts.tsv")
    expected_crashes = {
        "before_claim_call": ("true", "false", "NO_CLAIMED_OBSERVATION"),
        "after_raw_rename_before_validation": (
            "false", "true", "ALREADY_CLAIMED_EXACT_QUERY_ONLY"),
        "after_fresh_token_before_payload": (
            "false", "true", "ALREADY_CLAIMED_EXACT_QUERY_ONLY"),
        "after_payload_before_reply": (
            "false", "true", "ALREADY_CLAIMED_EXACT_QUERY_ONLY"),
    }
    if {row["cut"] for row in crashes} != set(expected_crashes):
        fail("crash inventory")
    for row in crashes:
        if (row["pending"], row["claimed"], row["reopen"]) \
                != expected_crashes[row["cut"]]:
            fail(f"crash mismatch={row['cut']}")
        if row["payload_entries_after_reopen"] != "0":
            fail(f"recovery reentered payload={row['cut']}")

    source_shape = verify_source_shape()
    refinement = verify_refinement()
    audit = {
        "authority_granted": False,
        "campaign_case_disagreements": 0,
        "cases": len(cases),
        "counterexamples_reproduced": len(counterexamples),
        "crash_cuts": len(crashes),
        "race_rows": len(races),
        "refinement": refinement,
        "schema": "slopos.rev0895.endpoint-claim-independent-audit.v1",
        "source_shape": source_shape,
        "stable_media_proved": False,
        "status": "PASS",
    }
    args.json.write_text(
        json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(
        "ENDPOINT_CLAIM_AUDIT=PASS cases=14 contenders=16 fresh=1 "
        "duplicates=15 crash_cuts=4 counterexamples=4 "
        "payload_before_claim=false protected_provider=false authority=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
