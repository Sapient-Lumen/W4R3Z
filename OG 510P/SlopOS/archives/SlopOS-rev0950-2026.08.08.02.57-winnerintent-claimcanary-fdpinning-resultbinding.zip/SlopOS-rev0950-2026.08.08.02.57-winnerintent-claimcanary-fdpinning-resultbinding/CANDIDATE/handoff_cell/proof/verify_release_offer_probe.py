#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def fail(detail: str) -> None:
    raise SystemExit(f"RELEASE_OFFER_PROBE_AUDIT=FAIL detail={detail}")


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def truth(value: str) -> bool:
    if value not in {"true", "false"}:
        fail(f"bad boolean={value!r}")
    return value == "true"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()
    cases = read_rows(args.output / "release-offer-cases.tsv")
    counter = read_rows(args.output / "release-offer-counterexamples.tsv")
    summary = json.loads(
        (args.output / "release-offer-summary.json").read_text(encoding="utf-8"))
    if len(cases) != 39 or not all(truth(row["pass"]) for row in cases):
        fail(f"case inventory/pass count={len(cases)}")
    if len(counter) != 15 or not all(truth(row["reproduced"]) for row in counter):
        fail("counterexample inventory")
    by_name = {row["case"]: row for row in cases}
    required_true = {
        "laboratory_mechanism_ready", "all_required_seals",
        "candidate_readable", "candidate_body_unread",
        "fully_sealed_write_only_descriptor_rejected",
        "peer_message_credentials_equal",
        "peer_message_pidfd_equal", "msg_peek_duplicates_rights",
        "multiple_rights_observable", "control_truncation_observable",
        "unsealed_memfd_rejected", "linked_regular_rejected",
        "exactly_one_rights_record", "exactly_one_rights_descriptor",
        "unadmitted_rights_installed",
        "receiver_preoffer_candidate_aliases_zero",
        "fork_inherited_candidate_alias_observed",
    }
    for name in required_true:
        if name not in by_name or not truth(by_name[name]["observed"]):
            fail(f"required true case={name}")
    required_false = {
        "actor_not_admitted_before_ready", "production_ingress_ready",
    }
    for name in required_false:
        if name not in by_name or truth(by_name[name]["observed"]):
            fail(f"required false case={name}")
    counter_names = {row["counterexample"] for row in counter}
    required_counterexamples = {
        "multiple_rights_single_cmsg",
        "post_receive_actor_check_imports_unadmitted_capability",
        "seal_profile_is_not_creator_provenance",
        "fork_inheritance_preinstalls_candidate_alias",
        "full_seal_profile_does_not_imply_readable_access",
    }
    missing = sorted(required_counterexamples - counter_names)
    if missing:
        fail(f"missing counterexamples={missing}")
    expected = {
        "acquisition_actor_admitted_before_ready": False,
        "actor_admission_precedes_rights_import": False,
        "archive_digest_compared": False,
        "archive_parsed": False,
        "candidate_bytes_read_before_validation": False,
        "candidate_memfd_creation_provenance_proved": False,
        "candidate_readable_observed": True,
        "cases": 39,
        "counterexamples_reproduced": 15,
        "exact_ancillary_shape": True,
        "fork_inherited_candidate_alias_reproduced": True,
        "full_seals_observed": True,
        "laboratory_mechanism_ready": True,
        "msg_peek_rights_duplication_reproduced": True,
        "one_use_transfer_proved": False,
        "owner_custody_proved": False,
        "peer_message_credentials_equal": True,
        "peer_message_pidfd_equal": True,
        "production_ingress_ready": False,
        "provider_operation_authority": False,
        "receiver_preoffer_candidate_aliases_zero": True,
        "schema": "slopos.rev0901.release-offer-host-probe.v2",
        "source_provenance_proved": False,
        "status": "PASS",
        "unadmitted_rights_installed": True,
        "write_only_sealed_descriptor_rejected": True,
    }
    if summary != expected:
        fail(f"summary mismatch={summary}")
    audit = {
        "acquisition_actor_admitted_before_ready": False,
        "actor_admission_precedes_rights_import": False,
        "archive_digest_compared": False,
        "archive_parsed": False,
        "candidate_bytes_read_before_validation": False,
        "candidate_memfd_creation_provenance_proved": False,
        "candidate_readable_observed": True,
        "cases": 39,
        "counterexamples": 15,
        "exact_ancillary_shape": True,
        "fork_inherited_candidate_alias_reproduced": True,
        "full_seals_observed": True,
        "laboratory_mechanism_ready": True,
        "msg_peek_rights_duplication_reproduced": True,
        "one_use_transfer_proved": False,
        "owner_custody_proved": False,
        "peer_message_credentials_equal": True,
        "peer_message_pidfd_equal": True,
        "production_ingress_ready": False,
        "provider_operation_authority": False,
        "receiver_preoffer_candidate_aliases_zero": True,
        "schema": "slopos.rev0901.release-offer-host-audit.v3",
        "source_provenance_proved": False,
        "status": "PASS",
        "unadmitted_rights_installed": True,
        "write_only_sealed_descriptor_rejected": True,
    }
    args.json.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n",
                         encoding="utf-8")
    print(
        "RELEASE_OFFER_PROBE_AUDIT=PASS cases=39 counterexamples=15 "
        "laboratory_mechanism_ready=true actor_admitted_before_ready=false "
        "unadmitted_rights_installed=true production_ingress_ready=false "
        "preoffer_aliases_zero=true fork_inherited_alias=true "
        "candidate_readable=true write_only_sealed_rejected=true")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
