#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def fail(detail: str) -> None:
    raise SystemExit(f"EXTERNAL_ROLLBACK_FLOOR_HOST_AUDIT=FAIL detail={detail}")


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def truth(value: str) -> bool:
    if value not in {"true", "false"}:
        fail(f"bad boolean={value!r}")
    return value == "true"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()

    cases = rows(args.output / "external-floor-host-cases.tsv")
    counter = rows(args.output / "external-floor-host-counterexamples.tsv")
    summary = json.loads(
        (args.output / "external-floor-host-summary.json").read_text(encoding="utf-8")
    )

    if len(cases) != 42 or len({row["case"] for row in cases}) != 42:
        fail(f"case inventory={len(cases)}")
    if len(counter) != 27 or len({row["counterexample"] for row in counter}) != 27:
        fail(f"counter inventory={len(counter)}")
    for row in cases:
        if truth(row["observed"]) != truth(row["expected"]) or not truth(row["pass"]):
            fail(f"host case={row['case']}")
    if not all(truth(row["reproduced"]) for row in counter):
        fail("unreproduced counterexample")

    host = summary.pop("host_kernel_release", None)
    if not isinstance(host, str) or not host:
        fail(f"kernel={host!r}")
    expected = {
        "authority": False,
        "cases": 42,
        "clone_histories_advanced": 2,
        "clone_signatures_identical": True,
        "complete_transcript_not_atomic": True,
        "counterexamples_reproduced": 27,
        "dual_ledger_transcript_operated": False,
        "exact_tpm_profile_operated": False,
        "external_rollback_floor_bound": False,
        "network_attempted": False,
        "portable_clone_replay_excluded": False,
        "query_only_cross_ledger_recovery_bound": False,
        "provider_operated": False,
        "ready_sent": False,
        "restored_copy_advanced": True,
        "rights_imported": False,
        "stale_precert_second_extend_reproduced": True,
        "tpm_ahead_witness_behind_fracture_reproduced": True,
        "schema": "slopos.rev0907.external-rollback-floor-host-probe.v19",
        "status": "PASS",
        "tpm0_present": False,
        "tpm2_getcap_available": False,
        "tpm2_nvcertify_available": False,
        "tpm2_nvextend_available": False,
        "tpm2_nvreadpublic_available": False,
        "tpm_commands_issued": 0,
        "tpmrm0_present": False,
        "v18_external_floor_premise": False,
        "witness_administration_distinct": False,
        "witness_first_inverse_fracture_reproduced": True,
        "witness_outside_restorable_image": False,
    }
    if summary != expected:
        fail(f"summary mismatch={summary}")

    audit = {
        "authority_granted": False,
        "cases": 42,
        "clone_histories_advanced": 2,
        "clone_signatures_identical": True,
        "complete_transcript_not_atomic": True,
        "counterexamples": 27,
        "dual_ledger_transcript_operated": False,
        "exact_tpm_profile_operated": False,
        "external_rollback_floor_bound": False,
        "host_kernel_release": host,
        "network_attempted": False,
        "portable_clone_replay_excluded": False,
        "query_only_cross_ledger_recovery_bound": False,
        "restored_copy_advanced": True,
        "schema": "slopos.rev0907.external-rollback-floor-host-audit.v19",
        "stale_precert_second_extend_reproduced": True,
        "status": "PASS",
        "tpm_ahead_witness_behind_fracture_reproduced": True,
        "tpm_commands_issued": 0,
        "v18_external_floor_premise": False,
        "witness_first_inverse_fracture_reproduced": True,
    }
    args.json.write_text(
        json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(
        "EXTERNAL_ROLLBACK_FLOOR_HOST_AUDIT=PASS cases=42 counterexamples=27 "
        "fracture=true stale_second_extend=true clones=2 restored=true "
        "signatures_same=true tpm_profile=false external_floor=false authority=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
