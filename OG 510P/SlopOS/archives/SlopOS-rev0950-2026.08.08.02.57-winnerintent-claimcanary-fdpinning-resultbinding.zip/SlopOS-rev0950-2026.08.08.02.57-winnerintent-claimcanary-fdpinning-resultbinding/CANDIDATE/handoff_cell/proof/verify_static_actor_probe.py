#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def fail(detail: str) -> None:
    raise SystemExit(f"STATIC_ACTOR_HOST_AUDIT=FAIL detail={detail}")


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def truth(value: str) -> bool:
    if value not in {"true", "false"}:
        fail(f"bad boolean={value!r}")
    return value == "true"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()

    cases = read_rows(args.output / "static-actor-host-cases.tsv")
    counterexamples = read_rows(
        args.output / "static-actor-host-counterexamples.tsv"
    )
    summary = json.loads(
        (args.output / "static-actor-host-summary.json").read_text(
            encoding="utf-8"
        )
    )

    if len(cases) != 94:
        fail(f"case count={len(cases)}")
    if len(counterexamples) != 50:
        fail(f"counterexample count={len(counterexamples)}")
    if len({row["case"] for row in cases}) != len(cases):
        fail("duplicate case")
    if len({row["counterexample"] for row in counterexamples}) != len(
        counterexamples
    ):
        fail("duplicate counterexample")
    for row in cases:
        if truth(row["observed"]) != truth(row["expected"]):
            fail(f"case expectation mismatch={row['case']}")

    ordered_names = [
        "subject_regular",
        "subject_unlinked",
        "subject_required_seals",
        "elf_profile_cross_bound_to_sealed_target",
        "elf64_x86_64",
        "elf_type_exec",
        "program_headers_bounded",
        "entrypoint_in_exec_load",
        "entry_stack_alignment_shim_exact",
        "pt_interp_absent",
        "pt_dynamic_absent",
        "writable_exec_load_absent",
        "executable_stack_absent",
        "child_single_threaded",
        "child_private_file_table",
        "child_private_address_space",
        "child_private_filesystem_context",
        "initial_root_and_cwd_exact_empty",
        "root_path_unlinked_before_policy",
        "seccomp_entry_root_held",
        "exec_entry_root_held",
        "pre_exec_filesystem_floor_bound",
        "pre_exec_nonroot",
        "pre_exec_groups_empty",
        "pre_exec_caps_and_bounding_empty",
        "pre_exec_no_new_privs",
        "pre_exec_read_implies_exec_absent",
        "inherited_seccomp_stack_empty",
        "pre_exec_seccomp_stack_exact_one",
        "post_exec_seccomp_stack_exact_one",
        "seccomp_entry_observed",
        "seccomp_arch_exact",
        "seccomp_operation_exact",
        "seccomp_flags_exact",
        "seccomp_program_snapshot_copied_at_entry",
        "seccomp_instruction_count_exact",
        "seccomp_instructions_exact",
        "seccomp_install_succeeded",
        "no_later_policy_install_before_exec",
        "exec_entry_observed",
        "exec_arch_exact",
        "exec_empty_path",
        "exec_flags_exact",
        "exec_target_fd_exact",
        "initial_descriptor_inventory_exact",
        "initial_target_duplicated_while_stopped",
        "initial_target_matches_subject",
        "exec_entry_descriptor_inventory_exact",
        "exec_entry_target_reinspected",
        "exec_entry_target_regular",
        "exec_entry_target_same_inode",
        "exec_entry_target_required_seals",
        "exec_entry_target_digest_exact",
        "exec_entry_target_cloexec",
        "exec_event_linked",
        "exactly_one_exec_event",
        "held_before_first_instruction",
        "mapping_inventory_complete",
        "one_file_backed_exec_mapping",
        "candidate_exec_mapping_matches",
        "kernel_exec_surfaces_declared",
        "writable_exec_mapping_absent",
        "post_exec_descriptor_inventory_exact",
        "exec_fd_closed_on_exec",
        "post_exec_root_and_cwd_held",
        "unrooted_absolute_path_ignores_dirfd",
        "rooted_absolute_path_canary_confined",
        "replacement_routes_denied",
        "descriptor_routes_denied",
        "peer_routes_denied",
        "network_async_routes_denied",
        "later_filter_routes_denied",
        "post_exec_policy_behavior_exact",
        "challenge_after_held_appraisal",
        "challenge_response_exact",
        "appraiser_process_separate",
        "appraiser_root_distinct",
        "same_root_filter_dump_exact",
        "independent_filter_reconstruction",
        "kernel_executable_surfaces_independently_bound",
        "pidfd_get_info_coordinate",
        "v14_dossier_cross_bound",
        "exec_epoch_held_through_v13",
        "hosted_static_actor_envelope",
        "independent_appraisal",
        "v13_actor_premise",
        "complete_process_image",
        "network_attempted",
        "ready_sent",
        "rights_imported",
        "candidate_bytes_read",
        "archive_admitted",
        "owner_authority",
        "living_law",
    ]
    if [row["case"] for row in cases] != ordered_names:
        fail("case order or inventory drift")

    required_false = {
        "appraiser_root_distinct",
        "same_root_filter_dump_exact",
        "independent_filter_reconstruction",
        "kernel_executable_surfaces_independently_bound",
        "pidfd_get_info_coordinate",
        "v14_dossier_cross_bound",
        "exec_epoch_held_through_v13",
        "independent_appraisal",
        "v13_actor_premise",
        "complete_process_image",
        "network_attempted",
        "ready_sent",
        "rights_imported",
        "candidate_bytes_read",
        "archive_admitted",
        "owner_authority",
        "living_law",
    }
    required_true = set(ordered_names) - required_false
    by_name = {row["case"]: row for row in cases}
    for name in required_true:
        if not truth(by_name[name]["observed"]):
            fail(f"required true={name}")
    for name in required_false:
        if truth(by_name[name]["observed"]):
            fail(f"required false={name}")
    if required_true | required_false != set(by_name):
        fail("case classification incomplete")

    expected_countermodels = {
        "mutable_source_profile_is_sealed_target_profile",
        "seccomp_scalars_bind_pointed_path",
        "closed_exec_fd_blocks_absolute_path",
        "chroot_alone_is_confinement",
        "anonymous_root_is_independent_custody",
        "equal_fd_inventories_are_continuity",
        "raw_elf_entry_is_called_cxx_function",
        "filter_input_is_installed_filter_independence",
        "kernel_surface_names_are_identity",
    }
    present_countermodels = {row["counterexample"] for row in counterexamples}
    if not expected_countermodels <= present_countermodels:
        fail("missing corrected countermodel")

    expected_summary = {
        "absolute_path_exec_canary_confined": True,
        "appraiser_administration_root_distinct": False,
        "appraiser_process_separate": True,
        "archive_body_bytes": 0,
        "cases": 94,
        "challenge_response_exact": True,
        "complete_process_image_bound": False,
        "counterexamples_reproduced": 50,
        "descriptor_inventory_exact": True,
        "eligible_for_v13_actor_premise": False,
        "elf_profile_cross_bound_to_v15_object": True,
        "entry_stack_alignment_shim_exact": True,
        "exec_entry_descriptor_inventory_exact": True,
        "exec_entry_target_cloexec": True,
        "exec_entry_target_reinspected": True,
        "exec_event_count": 1,
        "exec_input_object_bound": True,
        "file_backed_executable_mappings": 1,
        "filter_dump_errno": "EINVAL",
        "filter_instruction_count": 30,
        "held_initial_user_executable_mapping_set_bound": True,
        "hosted_static_actor_envelope_bound": True,
        "independent_appraisal_bound": False,
        "inherited_seccomp_stack_empty": True,
        "initial_descriptor_inventory_exact": True,
        "initial_target_matches_subject": True,
        "installed_seccomp_program_bound": False,
        "installed_seccomp_stack_exact_one": True,
        "kernel_executable_mappings": 1,
        "kernel_executable_surfaces_independently_bound": False,
        "network_attempted": False,
        "owner_authority": False,
        "post_exec_policy_behavior_exact": True,
        "post_exec_root_and_cwd_held": True,
        "pre_exec_capabilities_and_bounding_empty": True,
        "pre_exec_filesystem_floor_bound": True,
        "pre_exec_identity_nonroot": True,
        "pre_exec_no_new_privs": True,
        "pre_exec_root_path_unlinked": True,
        "pre_exec_seccomp_installation_observation_bound": True,
        "ready_sent": False,
        "rights_imported": False,
        "same_root_filter_dump_exact": False,
        "schema": "slopos.rev0904.static-actor-host-probe.v16",
        "seccomp_installation_input_snapshot_exact": True,
        "source_provenance_proved": False,
        "static_exec_profile_exact": True,
        "status": "PASS",
        "subject_size_bounded": True,
        "unrooted_absolute_exec_errno": "ENOEXEC",
        "v14_dossier_bound": False,
    }
    if summary != expected_summary:
        fail(f"summary mismatch={summary}")

    audit = {
        "absolute_path_exec_canary_confined": True,
        "appraiser_administration_root_distinct": False,
        "appraiser_process_separate": True,
        "archive_body_bytes": 0,
        "cases": 94,
        "complete_process_image_bound": False,
        "counterexamples": 50,
        "descriptor_inventory_exact": True,
        "eligible_for_v13_actor_premise": False,
        "elf_profile_cross_bound_to_v15_object": True,
        "entry_stack_alignment_shim_exact": True,
        "exec_entry_descriptor_inventory_exact": True,
        "exec_entry_target_cloexec": True,
        "exec_entry_target_reinspected": True,
        "exec_input_object_bound": True,
        "held_initial_user_executable_mapping_set_bound": True,
        "hosted_static_actor_envelope_bound": True,
        "independent_appraisal_bound": False,
        "inherited_seccomp_stack_empty": True,
        "initial_descriptor_inventory_exact": True,
        "initial_target_matches_subject": True,
        "installed_seccomp_program_bound": False,
        "installed_seccomp_stack_exact_one": True,
        "kernel_executable_surfaces_independently_bound": False,
        "network_attempted": False,
        "owner_authority": False,
        "post_exec_policy_behavior_exact": True,
        "post_exec_root_and_cwd_held": True,
        "post_exec_substitution_floor_bound": True,
        "pre_exec_filesystem_floor_bound": True,
        "pre_exec_privilege_floor_bound": True,
        "pre_exec_root_path_unlinked": True,
        "pre_exec_seccomp_installation_observation_bound": True,
        "ready_sent": False,
        "rights_imported": False,
        "schema": "slopos.rev0904.static-actor-host-audit.v16",
        "seccomp_installation_input_snapshot_exact": True,
        "source_provenance_proved": False,
        "static_exec_profile_exact": True,
        "status": "PASS",
        "v14_dossier_bound": False,
    }
    args.json.write_text(
        json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(
        "STATIC_ACTOR_HOST_AUDIT=PASS cases=94 counterexamples=50 "
        "static=true filesystem=true preexec=true seccomp_observation=true "
        "installed_program=false exec_target_reinspected=true "
        "held_user_maps=true rooted_path_floor=true substitution_floor=true "
        "hosted=true kernel_surfaces=false independent=false v14=false "
        "v13=false complete_image=false network=false authority=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
