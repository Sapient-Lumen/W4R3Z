#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def fail(detail: str) -> None:
    raise SystemExit(f"STATIC_ACTOR_CONFINEMENT_AUDIT=FAIL detail={detail}")


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def truth(value: str) -> bool:
    if value not in {"true", "false"}:
        fail(f"bad boolean={value!r}")
    return value == "true"


def true_rows(rows: list[dict[str, str]], field: str) -> list[str]:
    return [row["case"] for row in rows if truth(row[field])]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()

    cases = read_rows(args.output / "static-actor-cases.tsv")
    counterexamples = read_rows(
        args.output / "static-actor-counterexamples.tsv"
    )
    summary = json.loads(
        (args.output / "static-actor-summary.json").read_text(encoding="utf-8")
    )

    if len(cases) != 62:
        fail(f"case count={len(cases)}")
    if len(counterexamples) != 41 or not all(
        truth(row["reproduced"]) for row in counterexamples
    ):
        fail("counterexample inventory")
    if len({row["case"] for row in cases}) != len(cases):
        fail("duplicate case")
    if len({row["counterexample"] for row in counterexamples}) != len(
        counterexamples
    ):
        fail("duplicate counterexample")

    ordered_fields = {
        "static profile": ("static_exec_profile_exact", 49),
        "pre-exec filesystem floor": (
            "pre_exec_filesystem_floor_bound",
            43,
        ),
        "pre-exec privilege floor": (
            "pre_exec_privilege_floor_bound",
            37,
        ),
        "pre-exec seccomp installation observation": (
            "pre_exec_seccomp_installation_observation_bound",
            26,
        ),
        "held initial user executable mapping set": (
            "held_initial_user_executable_mapping_set_bound",
            19,
        ),
        "post-exec substitution floor": (
            "post_exec_substitution_floor_bound",
            10,
        ),
        "hosted envelope": ("hosted_static_actor_envelope_bound", 8),
        "independent appraisal": ("independent_appraisal_bound", 4),
        "V15 evidence": (
            "eligible_for_v15_runtime_and_preexec_evidence",
            4,
        ),
        "V14 cross-binding": ("v14_dossier_bound_to_static_actor", 2),
        "V13 eligibility": ("eligible_for_v13_actor_premise", 1),
    }
    observed: dict[str, list[str]] = {}
    for name, (field, expected_count) in ordered_fields.items():
        names = true_rows(cases, field)
        observed[name] = names
        if len(names) != expected_count:
            fail(f"{name} count={len(names)} rows={names}")

    expected_suffix_relations = (
        ("static profile", "pre-exec filesystem floor"),
        ("pre-exec filesystem floor", "pre-exec privilege floor"),
        ("pre-exec privilege floor", "pre-exec seccomp installation observation"),
        (
            "pre-exec seccomp installation observation",
            "held initial user executable mapping set",
        ),
        (
            "held initial user executable mapping set",
            "post-exec substitution floor",
        ),
        ("post-exec substitution floor", "hosted envelope"),
        ("hosted envelope", "independent appraisal"),
        ("independent appraisal", "V15 evidence"),
    )
    for wider, narrower in expected_suffix_relations:
        if observed[wider][-len(observed[narrower]) :] != observed[narrower]:
            fail(f"ordered suffix mismatch {wider}->{narrower}")
    if observed["independent appraisal"] != observed["V15 evidence"]:
        fail("independent appraisal and V15 evidence diverge")
    if observed["V14 cross-binding"] != [
        "exec_epoch_not_held_through_v13_admission",
        "synthetic_exact_static_actor_and_dossier",
    ]:
        fail(f"V14 rows={observed['V14 cross-binding']}")
    if observed["V13 eligibility"] != [
        "synthetic_exact_static_actor_and_dossier"
    ]:
        fail(f"V13 rows={observed['V13 eligibility']}")

    incoherent = [
        row["case"] for row in cases if not truth(row["observation_coherent"])
    ]
    if incoherent != ["incoherent_v15_without_profile"]:
        fail(f"incoherent={incoherent}")

    forbidden = (
        "installed_seccomp_program_bound",
        "complete_process_image_bound",
        "network_attempted",
        "ready_sent",
        "rights_imported",
        "candidate_bytes_read",
        "archive_admitted",
        "owner_authority",
        "living_law",
    )
    for row in cases:
        for field in forbidden:
            if truth(row[field]):
                fail(f"authority leak case={row['case']} field={field}")

    expected_summary = {
        "archive_admitted": False,
        "cases": 62,
        "complete_process_image_bound": False,
        "counterexamples_reproduced": 41,
        "eligible_for_v13_profiles": 1,
        "held_user_mapping_set_bound_profiles": 19,
        "hosted_envelope_bound_profiles": 8,
        "incoherent_observations": 1,
        "independent_appraisal_bound_profiles": 4,
        "installed_seccomp_program_bound": False,
        "living_law": False,
        "network_attempted": False,
        "owner_authority": False,
        "post_exec_floor_bound_profiles": 10,
        "pre_exec_filesystem_floor_bound_profiles": 43,
        "pre_exec_floor_bound_profiles": 37,
        "pre_exec_seccomp_installation_observation_bound_profiles": 26,
        "ready_sent": False,
        "rights_imported": False,
        "schema": "slopos.rev0904.static-actor-confinement-campaign.v16",
        "static_profile_exact_profiles": 49,
        "status": "PASS",
        "v15_evidence_eligible_profiles": 4,
    }
    if summary != expected_summary:
        fail(f"summary mismatch={summary}")

    audit = {
        "archive_admitted": False,
        "authority_granted": False,
        "cases": 62,
        "complete_process_image_bound": False,
        "counterexamples": 41,
        "eligible_for_v13_profiles": 1,
        "held_user_mapping_set_bound_profiles": 19,
        "hosted_envelope_bound_profiles": 8,
        "incoherent_observations": 1,
        "independent_appraisal_bound_profiles": 4,
        "installed_seccomp_program_bound": False,
        "network_attempted": False,
        "post_exec_floor_bound_profiles": 10,
        "pre_exec_filesystem_floor_bound_profiles": 43,
        "pre_exec_floor_bound_profiles": 37,
        "pre_exec_seccomp_installation_observation_bound_profiles": 26,
        "ready_sent": False,
        "rights_imported": False,
        "schema": "slopos.rev0904.static-actor-confinement-audit.v16",
        "static_profile_exact_profiles": 49,
        "status": "PASS",
        "v14_cross_bound_profiles": 2,
        "v15_evidence_eligible_profiles": 4,
    }
    args.json.write_text(
        json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(
        "STATIC_ACTOR_CONFINEMENT_AUDIT=PASS cases=62 "
        "counterexamples=41 static=49 filesystem=43 preexec=37 "
        "seccomp_observation=26 held_user_mappings=19 "
        "substitution_floor=10 hosted=8 independent=4 v14=2 v13=1 "
        "installed_program=false complete_image=false network=false "
        "authority=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
