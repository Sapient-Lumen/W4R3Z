#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def fail(detail: str) -> None:
    raise SystemExit(f"APPRAISER_RECEIPT_HOST_AUDIT=FAIL detail={detail}")


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def truth(value: str) -> bool:
    if value not in {"true", "false"}:
        fail(f"bad boolean={value!r}")
    return value == "true"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()

    cases = rows(args.output / "appraiser-receipt-host-cases.tsv")
    counterexamples = rows(args.output / "appraiser-receipt-host-counterexamples.tsv")
    summary = json.loads((args.output / "appraiser-receipt-host-summary.json").read_text(encoding="utf-8"))
    if len(cases) != 40 or len({row["case"] for row in cases}) != 40:
        fail(f"case inventory={len(cases)}")
    if len(counterexamples) != 18 or len({row["counterexample"] for row in counterexamples}) != 18:
        fail(f"counterexample inventory={len(counterexamples)}")
    for row in cases:
        if truth(row["observed"]) != truth(row["expected"]) or not truth(row["pass"]):
            fail(f"host case={row['case']}")
    if not all(truth(row["reproduced"]) for row in counterexamples):
        fail("unreproduced counterexample")

    expected = {
        "appraiser_administration_root_distinct": False,
        "appraiser_input_custody_independent": False,
        "appraiser_key_custody_independent": False,
        "appraiser_process_separate": True,
        "appraiser_user_namespace_distinct": True,
        "archive_body_bytes": 0,
        "authority": False,
        "cases": 40,
        "child_root_after_parent_map": True,
        "counterexamples_reproduced": 18,
        "independent_appraisal_bound": False,
        "installed_policy_independently_reconstructed": False,
        "kernel_surfaces_independently_reconstructed": False,
        "network_attempted": False,
        "one_local_report_consumed": True,
        "parent_created_identity_maps": True,
        "parent_pidfd_signal_control": True,
        "parent_ptrace_errno": "NONE",
        "parent_ptrace_seize_control": True,
        "pidfd_get_info_errno": "EINVAL",
        "pidfd_get_info_supported": False,
        "portable_replay_excluded": False,
        "public_test_key": True,
        "ready_sent": False,
        "receipt_bytes": 384,
        "rights_imported": False,
        "schema": "slopos.rev0905.appraiser-receipt-host-probe.v17",
        "signature_bytes": 64,
        "signed_statement_bound": True,
        "status": "PASS",
        "user_namespace_created": True,
        "v13_actor_premise": False,
        "v14_dossier_independently_reopened": False,
    }
    if summary != expected:
        fail(f"summary mismatch={summary}")

    audit = {
        "appraiser_administration_root_distinct": False,
        "appraiser_process_separate": True,
        "appraiser_user_namespace_distinct": True,
        "archive_body_bytes": 0,
        "authority_granted": False,
        "cases": 40,
        "counterexamples": 18,
        "independent_appraisal_bound": False,
        "network_attempted": False,
        "parent_created_identity_maps": True,
        "parent_pidfd_signal_control": True,
        "parent_ptrace_seize_control": True,
        "pidfd_get_info_supported": False,
        "portable_replay_excluded": False,
        "ready_sent": False,
        "rights_imported": False,
        "schema": "slopos.rev0905.appraiser-receipt-host-audit.v17",
        "signed_statement_bound": True,
        "status": "PASS",
        "v13_actor_premise": False,
    }
    args.json.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print("APPRAISER_RECEIPT_HOST_AUDIT=PASS cases=40 counterexamples=18 signed=true process=true userns=true parent_maps=true ptrace=true kill=true independent=false v13=false authority=false")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
