#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent
DIGEST = "ffe840ff9295808e88cce2794a18a5ac87f12a5203c8314d0bf6aa119b41bac5"
PREFIX = "/slopos/e0/provider-history/v1/"

# disposition, exact_release, exact_profile, admitted_cluster, linearizable,
# exact_state, synthetic_runtime, retained_counterexample
EXPECTED_CASES: dict[str, tuple[str, ...]] = {
    "current_cloudtainer_runtime_unavailable":
        ("RUNTIME_UNAVAILABLE", "false", "false", "false", "false", "false", "false", "true"),
    "exact_delivered_current":
        ("EXACT_CURRENT_OBSERVATION", "true", "true", "true", "true", "true", "true", "false"),
    "lost_reply_query_current":
        ("EXACT_CURRENT_AFTER_AMBIGUOUS_REPLY", "true", "true", "true", "true", "true", "true", "false"),
    "lost_reply_query_unused":
        ("EXACT_UNUSED_AFTER_AMBIGUOUS_REPLY", "true", "true", "true", "true", "true", "true", "false"),
    "compare_failed_query_current":
        ("COMPARE_FAILED_CURRENT_OBSERVATION", "true", "true", "true", "true", "true", "true", "false"),
    "compare_failed_query_unused":
        ("COMPARE_FAILED_UNUSED_OBSERVATION", "true", "true", "true", "true", "true", "true", "false"),
    "wrong_release_version":
        ("RELEASE_MISMATCH", "false", "false", "false", "false", "false", "true", "false"),
    "wrong_release_archive_digest":
        ("RELEASE_MISMATCH", "false", "false", "false", "false", "false", "true", "false"),
    "restored_new_cluster_exact_bytes":
        ("FOREIGN_CLUSTER", "true", "false", "false", "false", "false", "true", "true"),
    "foreign_member":
        ("FOREIGN_MEMBER", "true", "false", "true", "false", "false", "true", "false"),
    "auth_revision_drift":
        ("AUTH_REVISION_MISMATCH", "true", "false", "true", "false", "false", "true", "false"),
    "query_unavailable":
        ("QUERY_UNAVAILABLE", "true", "true", "true", "false", "false", "true", "false"),
    "serializable_stale_read":
        ("SERIALIZABLE_QUERY_REJECTED", "true", "true", "true", "false", "false", "true", "true"),
    "query_revision_regression":
        ("REVISION_REGRESSION", "true", "true", "true", "true", "false", "true", "false"),
    "floor_mismatch":
        ("CONFLICTING_OBSERVATION", "true", "true", "true", "true", "false", "true", "false"),
    "partial_successor_state":
        ("CONFLICTING_OBSERVATION", "true", "true", "true", "true", "false", "true", "false"),
    "coherent_clone_same_coordinates":
        ("EXACT_CURRENT_OBSERVATION", "true", "true", "true", "true", "true", "true", "true"),
    "root_rewrite_to_expected_bytes":
        ("EXACT_CURRENT_OBSERVATION", "true", "true", "true", "true", "true", "true", "true"),
    "malformed_duplicate_member_pin":
        ("PROFILE_MALFORMED", "false", "false", "false", "false", "false", "true", "false"),
}

EXPECTED_COUNTEREXAMPLES = {
    "release_runtime_absent_in_cloudtainer",
    "coherent_clone_preserves_ids_and_bytes",
    "root_role_rewrites_expected_values",
    "restore_creates_new_logical_cluster",
    "self_selected_profile_pin",
    "exact_dossier_is_synthetic_fixture",
    "rendered_txn_intent_not_transport",
}


def fail(detail: str) -> None:
    raise SystemExit(f"ETCD_PROFILE_AUDIT=FAIL detail={detail}")


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def strip_comments(text: str) -> str:
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.DOTALL)
    return re.sub(r"//.*", "", text)


def source_order(body: str, needles: list[str]) -> None:
    prior = -1
    for needle in needles:
        observed = body.find(needle)
        if observed < 0:
            fail(f"source-order needle missing={needle}")
        if observed <= prior:
            fail(f"source order violated={needle}")
        prior = observed


def verify_source_shape() -> dict[str, object]:
    header_path = SOURCE / "include/slopos/e0/handoff_cell/etcd_history_profile.hpp"
    impl_path = SOURCE / "src/etcd_history_profile.cpp"
    campaign_path = SOURCE / "harness/etcd_history_profile_campaign.cpp"
    header = header_path.read_text(encoding="utf-8")
    impl = impl_path.read_text(encoding="utf-8")
    campaign = campaign_path.read_text(encoding="utf-8")

    for needle in (
        'kEtcdProfileVersion{"v3.6.14"}',
        'kEtcdHistoryPrefix{',
        "struct EtcdProfilePinV1 final",
        "struct EtcdHistoryTxnPlanV1 final",
        "struct EtcdHistoryDossierV1 final",
        "struct EtcdHistoryAssessment final",
        "bool query_only{true}",
        "bool response_authority{false}",
        "bool retry_authority{false}",
        "bool provider_commit_proved{false}",
        "bool restore_continuity_proved{false}",
        "bool external_currentness_proved{false}",
    ):
        if needle not in header:
            fail(f"header shape missing={needle}")

    digest_bytes = [DIGEST[index:index + 2] for index in range(0, len(DIGEST), 2)]
    for byte in digest_bytes:
        if f"0x{byte}U" not in header:
            fail(f"archive digest byte missing={byte}")

    clean = strip_comments(header + "\n" + impl)
    forbidden_calls = (
        "system", "popen", "fork", "exec", "socket", "connect", "send",
        "recv", "open", "fopen", "rename", "unlink", "remove", "putenv",
    )
    for name in forbidden_calls:
        if re.search(rf"\b[A-Za-z0-9_]*{name}[A-Za-z0-9_]*\s*\(", clean,
                     flags=re.IGNORECASE):
            fail(f"transport or mutation call escaped profile seam={name}")
    if "etcdctl" in clean:
        fail("runtime command escaped profile seam=etcdctl")

    assess_start = impl.find("EtcdHistoryAssessment assess_etcd_history_dossier")
    names_start = impl.find("const char* etcd_history_disposition_name", assess_start)
    if assess_start < 0 or names_start < 0:
        fail("assessment implementation boundary")
    body = impl[assess_start:names_start]
    source_order(body, [
        "etcd_profile_pin_invariant(pin)",
        "!dossier.runtime_observed",
        "dossier.version == pin.version",
        "dossier.cluster_id != pin.cluster_id",
        "member_admitted(pin.member_ids, dossier.member_id)",
        "dossier.auth_revision != pin.auth_revision",
        "!dossier.query_delivered",
        "!dossier.linearizable_query",
        "dossier.query_revision == 0U",
        "current_state(expected, dossier)",
    ])

    endpoint = "\n".join(
        path.read_text(encoding="utf-8")
        for path in (
            SOURCE / "include/slopos/e0/handoff_cell/endpoint_claim.hpp",
            SOURCE / "src/endpoint_claim.cpp",
            SOURCE / "include/slopos/e0/handoff_cell/hosted_settlement.hpp",
            SOURCE / "src/hosted_settlement.cpp",
        )
    )
    for forbidden in (
        "EtcdProfilePinV1", "EtcdHistoryTxnPlanV1", "EtcdHistoryDossierV1",
        "EtcdHistoryAssessment", "assess_etcd_history_dossier",
    ):
        if forbidden in endpoint:
            fail(f"profile assessment reaches claim/settlement surface={forbidden}")

    for needle in (
        "current_cloudtainer_runtime_unavailable",
        "lost_reply_query_current",
        "serializable_stale_read",
        "restored_new_cluster_exact_bytes",
        "coherent_clone_same_coordinates",
        "root_rewrite_to_expected_bytes",
        "exact_dossier_is_synthetic_fixture",
        "rendered_txn_intent_not_transport",
    ):
        if needle not in campaign:
            fail(f"campaign shape missing={needle}")

    return {
        "candidate_runtime_process_entrypoints": 0,
        "candidate_socket_entrypoints": 0,
        "candidate_provider_mutation_entrypoints": 0,
        "endpoint_or_settlement_consumers": 0,
        "exact_release_check_precedes_cluster_check": True,
        "cluster_and_member_checks_precede_query": True,
        "linearizable_check_precedes_state_classification": True,
        "query_only_assessment": True,
    }


def verify_plan(path: Path) -> dict[str, object]:
    text = path.read_text(encoding="utf-8")
    for line in (
        "ETCD_PROFILE_VERSION=v3.6.14",
        f"RELEASE_ARCHIVE_SHA256={DIGEST}",
        f"KEY_PREFIX={PREFIX}",
        "SERIALIZABLE_READ=false",
        "COMPARISONS=4",
        "SUCCESS_WRITES=3",
        "FAILURE_QUERIES=4",
    ):
        if line not in text:
            fail(f"plan line missing={line}")
    for suffix in ("head", "floor"):
        if text.count(PREFIX + suffix) < 2:
            fail(f"fixed key absent from txn/query={suffix}")
    for suffix in ("spend/", "entry/"):
        if text.count(PREFIX + suffix) < 2:
            fail(f"operation key absent from txn/query={suffix}")
    if text.count("version(\"") != 2:
        fail("plan must contain exactly two create-version compares")
    if text.count("put ") != 3:
        fail("plan must contain exactly three writes")
    if text.count("get ") != 8:
        fail("plan must contain four failure and four recovery queries")
    return {
        "comparisons": 4,
        "success_writes": 3,
        "failure_queries": 4,
        "linearizable_query_required": True,
        "transport_submission_proved": False,
    }


def verify_outputs(output: Path) -> dict[str, object]:
    cases = read_tsv(output / "etcd-profile-cases.tsv")
    observed = {row["case"]: row for row in cases}
    if set(observed) != set(EXPECTED_CASES):
        fail(f"case inventory={sorted(observed)}")
    for name, expected in EXPECTED_CASES.items():
        row = observed[name]
        values = (
            row["disposition"], row["exact_release"], row["exact_profile"],
            row["admitted_cluster_coordinate"], row["linearizable"],
            row["exact_expected_state"], row["synthetic_runtime"],
            row["retained_counterexample"],
        )
        if values != expected:
            fail(f"case={name} observed={values} expected={expected}")
        for field in (
            "query_only", "response_authority", "retry_authority",
            "provider_commit_proved", "restore_continuity_proved",
            "external_currentness_proved",
        ):
            wanted = "true" if field == "query_only" else "false"
            if row[field] != wanted:
                fail(f"case={name} field={field} value={row[field]}")

    counterexamples = read_tsv(output / "etcd-profile-counterexamples.tsv")
    if {row["counterexample"] for row in counterexamples} != EXPECTED_COUNTEREXAMPLES:
        fail("counterexample inventory")
    if any(row["reproduced"] != "true" for row in counterexamples):
        fail("counterexample not reproduced")

    summary = json.loads((output / "etcd-profile-summary.json").read_text(encoding="utf-8"))
    expected_summary = {
        "administration_plane_closed": False,
        "ambiguous_query_refinements": 2,
        "authority_granted": False,
        "cases": 19,
        "comparisons": 4,
        "counterexamples_reproduced": 7,
        "exact_current_observations": 5,
        "external_currentness_proved": False,
        "failure_queries": 4,
        "foreign_cluster_rejections": 1,
        "key_prefix": PREFIX,
        "linearizable_query_required": True,
        "operated_etcd_profile": False,
        "provider_commit_proved": False,
        "query_only": True,
        "release_archive_sha256": DIGEST,
        "release_version": "v3.6.14",
        "response_authority": False,
        "restore_continuity_proved": False,
        "retry_authority": False,
        "schema": "slopos.rev0898.etcd-profile-shape-evidence.v1",
        "serializable_read_rejections": 1,
        "stable_media_proved": False,
        "status": "PASS",
        "success_writes": 3,
        "synthetic_runtime_observations": 18,
    }
    if summary != expected_summary:
        fail(f"summary mismatch={summary}")

    aggregate = json.loads((output / "summary.json").read_text(encoding="utf-8"))
    for key, value in (
        ("etcd_profile_cases", 19),
        ("etcd_profile_counterexamples", 7),
        ("etcd_profile_exact_current_observations", 5),
        ("etcd_profile_operated", False),
        ("etcd_profile_synthetic_runtime_observations", 18),
        ("schema", "slopos.rev0907.handoff-cell-campaign.v19"),
    ):
        if aggregate.get(key) != value:
            fail(f"aggregate field={key} value={aggregate.get(key)!r}")

    actual_runtime_rows = [row for row in cases if row["synthetic_runtime"] == "false"]
    if [row["case"] for row in actual_runtime_rows] != [
        "current_cloudtainer_runtime_unavailable"
    ]:
        fail("actual runtime boundary row")

    return {
        "cases": len(cases),
        "counterexamples_reproduced": len(counterexamples),
        "exact_current_observations": summary["exact_current_observations"],
        "synthetic_runtime_observations": summary["synthetic_runtime_observations"],
        "actual_runtime_observations": len(actual_runtime_rows),
        "operated_etcd_profile": False,
        "provider_commit_proved": False,
        "response_authority": False,
        "retry_authority": False,
        "external_currentness_proved": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Audit the fail-closed exact etcd v3.6.14 profile seam.")
    parser.add_argument("output", type=Path)
    parser.add_argument("--json", dest="json_path", type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    result = {
        **verify_outputs(output),
        "plan": verify_plan(output / "etcd-profile-plan.txt"),
        "source_shape": verify_source_shape(),
        "schema": "slopos.rev0898.etcd-profile-audit.v1",
        "status": "PASS",
    }
    if args.json_path is not None:
        args.json_path.write_text(
            json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(
        "ETCD_PROFILE_AUDIT=PASS cases=19 counterexamples=7 "
        "actual_runtime_observations=1 synthetic_runtime_observations=18 "
        "operated=false provider_commit=false response_authority=false "
        "retry_authority=false external_currentness=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
