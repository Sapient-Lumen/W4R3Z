#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
SOURCE = ROOT / "CANDIDATE/handoff_cell/harness/release_fd_probe.cpp"


def fail(detail: str) -> None:
    raise SystemExit(f"RELEASE_FD_PROBE_AUDIT=FAIL detail={detail}")


def rows(path: Path, fields: list[str]) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        if reader.fieldnames != fields:
            fail(f"header={path.name} observed={reader.fieldnames}")
        output = list(reader)
    if any(any(value is None or value == "" for value in row.values()) for row in output):
        fail(f"empty row={path.name}")
    return output


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--json", required=True, type=Path)
    args = parser.parse_args()
    summary = json.loads((args.output / "release-fd-summary.json").read_text(encoding="utf-8"))
    expected = {
        "archive_payload_executed": False,
        "cases": 12,
        "counterexamples": 6,
        "duplicate_shares_open_description_offset": True,
        "fchmod_only_retained_writer": True,
        "memfd_regular_unlinked": True,
        "opened_regular_file": True,
        "path_identity_changed_after_replace": True,
        "path_reopen_reads_replacement": True,
        "pinned_fd_reads_original": True,
        "pread_position_independent": True,
        "required_seals_observed": True,
        "retained_writer_rejected_after_seal": True,
        "schema": "slopos.rev0899.release-fd-probe.v2",
        "sealed_grow_rejected": True,
        "sealed_shrink_rejected": True,
        "status": "PASS",
        "symlink_leaf_rejected": True,
    }
    if summary != expected:
        fail(f"summary={summary!r}")
    cases = rows(args.output / "release-fd-cases.tsv", ["case", "expected", "observed", "status"])
    counters = rows(
        args.output / "release-fd-counterexamples.tsv",
        ["id", "tempting_inference", "counterexample", "consequence"],
    )
    expected_cases = {
        "open_regular_once", "pinned_fd_after_path_replace",
        "reopened_path_after_replace", "path_identity_after_replace",
        "nofollow_symlink_leaf", "fstat_directory_leaf",
        "duplicated_fd_cursor", "pread_cursor", "memfd_snapshot_identity",
        "memfd_required_seals", "retained_writer_after_seal", "sealed_resize",
    }
    if {row["case"] for row in cases} != expected_cases \
            or any(row["status"] != "PASS" for row in cases):
        fail("case coverage")
    if [row["id"] for row in counters] != [
        "CF01", "CF02", "CF03", "CF04", "CF05", "CF06"
    ]:
        fail("counterexample coverage")

    source = SOURCE.read_text(encoding="utf-8")
    for fragment in (
        "O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK",
        "::fstat(pinned.get(), &opened)",
        "S_ISREG(opened.st_mode)",
        "::rename(replacement.c_str(), original.c_str())",
        "pread_exact(pinned.get()",
        "F_DUPFD_CLOEXEC",
        "SYS_memfd_create",
        "MFD_CLOEXEC | MFD_ALLOW_SEALING",
        "F_SEAL_WRITE | F_SEAL_GROW | F_SEAL_SHRINK | F_SEAL_SEAL",
        "::fcntl(snapshot.get(), F_ADD_SEALS, required_seals)",
        "::fcntl(snapshot.get(), F_GET_SEALS)",
        "pwrite_rejected_with_eperm(retained_writer.get()",
        "ftruncate_rejected_with_eperm",
        '"archive_payload_executed\\": false',
    ):
        if fragment not in source:
            fail(f"source fragment={fragment}")
    if source.find("mode_only_writer_survives") > source.find("F_ADD_SEALS"):
        fail("mode-only counterexample must precede inode seal")
    if source.find("F_ADD_SEALS") > source.find("retained_writer_rejected"):
        fail("seal must precede retained-writer rejection")
    for forbidden in ("system(", "execve(", "posix_spawn(", "popen("):
        if forbidden in source:
            fail(f"payload execution surface={forbidden}")

    audit = {
        "archive_payload_execution_callsites": 0,
        "cases": len(cases),
        "counterexamples": len(counters),
        "fd_pinned_before_path_replace": True,
        "memfd_regular_unlinked_observed": True,
        "mode_bits_do_not_revoke_existing_writer_observed": True,
        "nofollow_leaf_observed": True,
        "path_reopen_substitution_reproduced": True,
        "pread_snapshot_relation_observed": True,
        "regular_file_check_observed": True,
        "required_inode_seals_observed": True,
        "retained_writer_rejected_after_seal": True,
        "schema": "slopos.rev0899.release-fd-probe-audit.v2",
        "sealed_resize_rejected": True,
        "status": "PASS",
    }
    args.json.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(
        "RELEASE_FD_PROBE_AUDIT=PASS cases=12 counterexamples=6 "
        "memfd=REGULAR_UNLINKED required_seals=true retained_writer=EPERM "
        "payload_execution_callsites=0"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
