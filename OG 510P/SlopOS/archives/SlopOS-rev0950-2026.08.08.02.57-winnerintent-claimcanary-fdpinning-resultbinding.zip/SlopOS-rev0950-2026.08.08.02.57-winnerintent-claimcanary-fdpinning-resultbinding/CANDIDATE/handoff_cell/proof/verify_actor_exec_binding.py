#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def fail(detail: str) -> None:
    raise SystemExit(f"ACTOR_EXEC_BINDING_AUDIT=FAIL detail={detail}")


def read_rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def truth(value: str) -> bool:
    if value not in {"true", "false"}:
        fail(f"bad boolean={value!r}")
    return value == "true"


def true_rows(rows: list[dict[str, str]], field: str) -> list[str]:
    return [row["case"] for row in rows if truth(row[field])]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    args = parser.parse_args()

    cases = read_rows(args.output / "actor-exec-cases.tsv")
    counterexamples = read_rows(args.output / "actor-exec-counterexamples.tsv")
    summary = json.loads(
        (args.output / "actor-exec-summary.json").read_text(encoding="utf-8")
    )

    if len(cases) != 51:
        fail(f"case count={len(cases)}")
    if len(counterexamples) != 32 or not all(
        truth(row["reproduced"]) for row in counterexamples
    ):
        fail("counterexample inventory")
    if len({row["case"] for row in cases}) != len(cases):
        fail("duplicate case")

    expected_exec_input = [
        "runtime_interpreter_or_objects_unbound",
        "exec_epoch_not_held_through_admission",
        "pre_exec_privilege_floor_unproved",
        "pre_exec_seccomp_filter_unproved",
        "v14_dossier_unavailable",
        "dossier_not_appraised_after_bound_exec",
        "dossier_executable_digest_mismatch",
        "dossier_process_coordinate_mismatch",
        "dossier_runtime_object_mismatch",
        "dossier_challenge_epoch_mismatch",
        "dossier_launch_envelope_mismatch",
        "dossier_privilege_floor_mismatch",
        "dossier_descriptor_inventory_mismatch",
        "synthetic_exact_exec_epoch_and_v14_dossier",
    ]
    expected_runtime = expected_exec_input[1:]
    expected_epoch = expected_exec_input[2:]
    expected_pre_exec = expected_exec_input[4:]
    exact = ["synthetic_exact_exec_epoch_and_v14_dossier"]

    observed_sets = {
        "exec input": true_rows(cases, "exec_input_object_bound"),
        "runtime set": true_rows(cases, "runtime_object_set_bound"),
        "exec epoch": true_rows(cases, "exec_epoch_held"),
        "pre-exec floor": true_rows(cases, "pre_exec_floor_bound"),
        "dossier cross-binding": true_rows(
            cases, "v14_dossier_bound_to_exec_epoch"
        ),
        "V13 eligibility": true_rows(cases, "eligible_for_v13_actor_premise"),
    }
    expected_sets = {
        "exec input": expected_exec_input,
        "runtime set": expected_runtime,
        "exec epoch": expected_epoch,
        "pre-exec floor": expected_pre_exec,
        "dossier cross-binding": exact,
        "V13 eligibility": exact,
    }
    for name, expected in expected_sets.items():
        if observed_sets[name] != expected:
            fail(f"{name} rows={observed_sets[name]}")

    incoherent = [
        row["case"] for row in cases if not truth(row["observation_coherent"])
    ]
    if incoherent != ["incoherent_descriptor_without_profile"]:
        fail(f"incoherent={incoherent}")

    forbidden = (
        "complete_process_image_bound",
        "network_attempted",
        "ready_sent",
        "rights_imported",
        "candidate_created",
        "candidate_bytes_read",
        "archive_acquired",
        "archive_admitted",
        "source_provenance_proved",
        "owner_authority",
        "living_law",
    )
    for row in cases:
        for field in forbidden:
            if truth(row[field]):
                fail(f"authority leak case={row['case']} field={field}")

    expected_summary = {
        "archive_acquired": False,
        "archive_admitted": False,
        "candidate_bytes_read": False,
        "cases": 51,
        "complete_process_image_bound": False,
        "counterexamples_reproduced": 32,
        "eligible_for_v13_profiles": 1,
        "exec_epoch_held_profiles": 12,
        "exec_input_bound_profiles": 14,
        "incoherent_observations": 1,
        "pre_exec_floor_bound_profiles": 10,
        "living_law": False,
        "network_attempted": False,
        "owner_authority": False,
        "ready_sent": False,
        "rights_imported": False,
        "runtime_object_set_bound_profiles": 13,
        "schema": "slopos.rev0903.actor-exec-target-binding-campaign.v15",
        "source_provenance_proved": False,
        "status": "PASS",
        "v14_alone_eligible_for_v13": False,
    }
    if summary != expected_summary:
        fail(f"summary mismatch={summary}")

    audit = {
        "archive_admitted": False,
        "authority_granted": False,
        "candidate_bytes_read": False,
        "cases": 51,
        "complete_process_image_bound": False,
        "counterexamples": 32,
        "exec_epoch_held_profiles": 12,
        "exec_input_bound_profiles": 14,
        "incoherent_observations": 1,
        "pre_exec_floor_bound_profiles": 10,
        "network_attempted": False,
        "ready_sent": False,
        "rights_imported": False,
        "runtime_object_set_bound_profiles": 13,
        "schema": "slopos.rev0903.actor-exec-target-binding-audit.v3",
        "status": "PASS",
        "v13_eligible_profiles": 1,
    }
    args.json.write_text(
        json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(
        "ACTOR_EXEC_BINDING_AUDIT=PASS cases=51 counterexamples=32 "
        "exec_input_bound=14 runtime_bound=13 exec_epoch_held=12 "
        "pre_exec_floor=10 v13_eligible=1 complete_image=false "
        "network=false authority=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
