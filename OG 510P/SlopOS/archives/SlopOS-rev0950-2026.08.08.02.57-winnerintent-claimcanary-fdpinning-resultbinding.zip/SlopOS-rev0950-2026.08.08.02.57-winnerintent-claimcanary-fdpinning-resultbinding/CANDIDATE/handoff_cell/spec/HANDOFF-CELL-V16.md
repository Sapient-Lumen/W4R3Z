# Handoff Cell V16 — static actor pre-exec confinement envelope

## Correction owned by V16

V15 binds one exact sealed main `execveat` input, but its hosted subject is
dynamically linked and establishes its privilege and seccomp state only after
exec. Those facts leave three live compressions:

```text
main exec-input object
!= initial user executable mapping set

post-exec nonroot and seccomp observations
!= a pre-exec privilege and syscall floor

closed exec descriptor plus scalar seccomp checks
!= pathname-resolution confinement
```

V16 adds one pure C++20 ordered relation and one bounded Linux laboratory. The
hosted positive theorem is deliberately named
`hosted_static_actor_envelope_bound`. It composes four narrower observations:

1. the exact static ELF profile is read from the same sealed object bound by
   V15;
2. a fork-private filesystem context holds one empty, actor-nonwritable root
   and current directory whose pathname is removed before policy installation;
3. one same-root pre-exec privilege and seccomp-installation observation is
   retained without claiming the exact kernel-installed filter; and
4. while the tracee is stopped at the linked exec event before its first user
   instruction, the sealed candidate accounts for every file-backed user
   executable mapping and the named actor-local substitution routes are closed.

This is not complete process-image identity. Kernel-provided executable
surfaces such as the vDSO and legacy vsyscall page are enumerated but not
independently identity-bound to the release object. Mutable data, kernel
semantics, external administrative mutation, source provenance, the exact
installed seccomp program, and every future instruction remain outside the
theorem.

## Ordered relation

`StaticActorObservationV1` contains 60 booleans. The observation is coherent
only as one prefix: after the first false field, every later field must remain
false. The order is:

```text
profile supplied
-> V15 exact main exec-input object bound
-> ELF profile cross-bound to that same sealed V15 object
-> ELF64 little-endian x86-64
-> exact ET_EXEC type
-> bounded program-header table
-> entry point inside an executable PT_LOAD
-> PT_INTERP absent
-> PT_DYNAMIC absent
-> at least one executable PT_LOAD
-> no writable-executable PT_LOAD
-> nonexecutable GNU_STACK
-> child single-threaded
-> child file table private
-> child address space private
-> child filesystem context private
-> pre-exec root and cwd are the same exact empty actor-nonwritable directory
-> pre-exec root pathname removed
-> pre-exec uid/gid nonroot
-> pre-exec supplementary groups empty
-> pre-exec capability sets and bounding set empty
-> no_new_privs set before policy installation
-> READ_IMPLIES_EXEC absent
-> inherited seccomp stack observed empty
-> tracer armed before policy installation
-> exact seccomp syscall entry observed
-> syscall architecture exact
-> operation exactly SECCOMP_SET_MODE_FILTER
-> flags exactly zero
-> one syscall-entry sock_fprog and instruction snapshot copied by the tracer
-> instruction count exact
-> every classic-BPF instruction exact
-> installation syscall succeeds
-> installed seccomp stack observed as exactly one filter
-> no later policy installation before exec
-> V15 exec event completes the observed entry
-> tracee held before first user instruction
-> initial mapping inventory complete
-> candidate executable mappings match
-> interpreter and shared-object executable mappings absent
-> only declared kernel executable mappings remain
-> writable-executable mappings absent
-> post-exec descriptor inventory exact
-> exec descriptor closed by CLOEXEC
-> post-exec root and cwd remain the same held empty directory
-> an allowed-shape absolute-path exec canary remains confined by that root
-> later exec and executable-mapping routes blocked
-> descriptor acquisition and SCM_RIGHTS import routes blocked
-> process and address-space peer-creation routes blocked
-> network and asynchronous bypass routes blocked
-> observed post-exec policy behavior exact
-> challenge generated only after held appraisal
-> challenge response exact
-> appraiser process separate
-> appraiser administration root distinct
-> installed filter independently reconstructed
-> kernel executable surfaces independently bound
-> PIDFD_GET_INFO coordinate exact
-> V14 dossier cross-bound
-> exec epoch held through V13 admission
```

The thresholds are intentionally asymmetric:

- 49 coherent prefixes have the exact sealed static ELF profile;
- 43 have the private empty-root filesystem floor;
- 37 have the pre-exec privilege floor;
- 26 have the pre-exec seccomp-installation observation;
- 19 have the held initial user executable mapping set;
- 10 have the named post-exec substitution floor;
- 8 have the same-root hosted envelope;
- 4 have synthetic independent appraisal and V15-evidence eligibility;
- 2 have synthetic V14 cross-binding; and
- 1 complete synthetic row reaches V13 actor-premise eligibility.

`installed_seccomp_program_bound` and `complete_process_image_bound` are always
false. Even the complete synthetic row is an actor-admission composition, not a
theorem about the kernel-copied filter, every kernel mapping, mutable datum,
instruction, administrator, provenance chain, or external effect.

## Exact hosted subject

The laboratory builds a dedicated freestanding C++20 subject with:

```text
ELF64 / little-endian / x86-64
ET_EXEC
four bounded program headers
one RX PT_LOAD containing the entry point
no PT_INTERP
no PT_DYNAMIC
no W+X PT_LOAD
RW nonexecutable GNU_STACK
no libc or sanitizer runtime
```

The subject performs only raw syscalls. It reads one fixed challenge frame from
fd 3, writes one fixed response and denied-route observations to fd 4, and
exits. It is a proof input, not a retained binary, product service, downloader,
or acquisition actor.

The parent copies that subject into an unlinked executable memfd, completes the
copy, installs the write/grow/shrink/seal barrier, re-reads and hashes the
sealed object, and reads the ELF profile from those same sealed bytes. At the
terminal stopped `execveat` entry the tracer independently reopens fd 5 through
the tracee's procfs descriptor coordinate, rechecks regular shape, device,
inode, size, all required seals, the complete SHA-256, and the CLOEXEC flag,
and only then permits the linked exec event. The child receives only:

```text
fd 3  challenge read end
fd 4  report write end
fd 5  sealed exec input, CLOEXEC
```

All other ordinary descriptors are closed. A normal `fork` supplies a private
file table, address space, and filesystem context for this bounded fixture.

The initial and terminal descriptor inventories are both exactly `{3,4,5}`.
Those equal endpoint observations do not prove an uninterrupted history: a
replace-and-restore ABA sequence could preserve the same numbers. The proof
therefore does not maintain a supposedly complete list of descriptor-mutating
syscalls. It reinspects the actual terminal fd 5 object while the single-thread
tracee is stopped at the exact syscall entry. The procfs reopen is proof
instrumentation and an object observation, not transfer, revocation, or
independent custody.

## Private empty-root filesystem floor

Before dropping privilege, the child changes into one newly created empty
0555 directory, performs `chroot(".")`, and sets cwd to `/`. The parent, while
the child is stopped, verifies through the tracee's procfs coordinates that
root and cwd are the same expected directory, the directory is empty, and it is
not writable by the future actor identity. The parent then removes the only
pathname to that directory and repeats the observation at the seccomp entry,
the exact exec entry, and the held post-exec stop.

The seccomp policy must still reason about pathname resolution. An absolute
pathname ignores the `dirfd` argument to `execveat`; therefore closing fd 5 does
not by itself close absolute-path execution. A retained counterexample executes
an external canary under the same admitted scalar shape outside the empty root.
The hosted actor repeats that shape and receives `ENOENT` because its held root
contains no pathname. This is a narrow actor-local filesystem floor, not mount
namespace identity, host-wide pathname custody, or protection from a privileged
administrator that can reach the tracee's root through process coordinates.

## Pre-exec privilege and seccomp observation

Before the exact exec transition, the child:

1. empties supplementary groups;
2. drops to uid/gid 65534;
3. clears effective, permitted, inheritable, ambient, and bounding
   capabilities;
4. sets `no_new_privs`;
5. clears `READ_IMPLIES_EXEC`; and
6. submits one 30-instruction classic-BPF seccomp installation input.

The observed program defaults to `EPERM` and admits only the subject's narrow
protocol: exit, exit-group, signal return, read on fd 3, write on fd 4, and one
exact `execveat(fd 5, pointer-to-empty-string, ..., AT_EMPTY_PATH)` scalar
shape. Seccomp cannot dereference the pathname pointer. The private empty-root
floor is therefore an independent premise, not something the BPF argument
checks can establish.

The same-root tracer does not infer installed-filter identity from
`Seccomp: 2` or from a few denied calls. At the exact stopped `seccomp()` entry
it copies one `sock_fprog` and every referenced instruction from the tracee,
then resumes the syscall, observes successful return, verifies that the
inherited stack was empty and the installed stack count is one, excludes
another policy-install syscall before exec, and exercises the named denied
routes after exec.

Linux performs separate user-memory copies while handling the resumed syscall:
it copies the `sock_fprog` and then the referenced instruction array. The
tracer's earlier snapshot is therefore not identity of the bytes the kernel
ultimately consumed. Same-root ptrace, `process_vm_writev`, or another admitted
memory mutator could alter that memory in the gap. V16 consequently establishes
only a same-root **installation observation and named behavior floor** for this
fixture. `installed_seccomp_program_bound` remains false.

## Held mapping cut

The tracer links the exact pending V15 entry to one `PTRACE_EVENT_EXEC` and
keeps the actor stopped before the first user instruction. At that stop it
records:

- the exact file-backed executable mapping set and device/inode match to the
  sealed candidate;
- absence of interpreter and shared-object executable mappings;
- absence of writable-executable mappings;
- declared kernel executable surfaces;
- the exact surviving descriptor inventory;
- close-on-exec consumption of fd 5 in this process; and
- persistence of the anonymous empty root and cwd.

A maps or filesystem snapshot is not permanent custody. The observed policy
supplies only a named actor-local floor against later substitution. Same-root
ptrace, process-vm writes, kernel compromise, restore, and other external
administrative roots remain outside the proof.

## Hosted result

The Linux 6.12.13 laboratory records:

```text
static exec profile cross-bound to sealed V15 object: true
pre-exec private empty-root filesystem floor bound:   true
pre-exec root pathname removed:                       true
pre-exec privilege floor bound:                       true
inherited seccomp stack empty:                        true
installed seccomp stack count exactly one:            true
seccomp installation input snapshot exact:            true
pre-exec seccomp installation observation bound:      true
installed seccomp program bound:                      false
held initial user executable mapping set bound:       true
post-exec root and cwd held:                           true
absolute-path exec canary confined:                    true
post-exec named substitution floor bound:             true
same-root hosted envelope bound:                      true
kernel executable surfaces independently bound:      false
PTRACE_SECCOMP_GET_FILTER exact dump:                 false (EINVAL)
independent appraiser root:                           false
PIDFD_GET_INFO:                                       false
V14 dossier cross-bound:                              false
V13 actor premise:                                    false
complete process image bound:                         false
network / READY / rights / archive bytes:             0 / 0 / 0 / 0
authority:                                            false
```

`PTRACE_SECCOMP_GET_FILTER` failure is retained as a host stop. It is not
interpreted as absence of a filter, because the installation entry, successful
return, procfs mode/count observations, and denied-route behavior are separate
facts. Conversely, those same-root facts neither identify the kernel-consumed
program bytes nor become independent appraisal.

The raw ELF entry is not modeled as an ordinary C++ call target. The retained
subject uses an assembly-only shim that establishes the call-site stack
convention before entering `slopos_actor_main`; the sealed-object profile
inspects that shim directly. The successful challenge then demonstrates bounded
execution of the exact object, not compiler provenance or complete code identity.

## Retained proofwork

The pure relation retains 62 cases and 41 countermodels. The Linux laboratory
retains 94 cases and 50 executable counterexamples. Clang, GCC, and Clang
ASan/UBSan independently reconstruct 105 audited sources into 84 canonical
products with byte-identical normalized content. The exact canonical-byte total
is recorded in retained evidence rather than projected back into an audited
source. The static subject and every build product remain external; only
normalized evidence is retained.

## Nonclaims

V16 does not prove source-to-binary correspondence, compiler or linker
provenance, exact installed seccomp-program identity, mount-namespace identity,
host-wide pathname custody, kernel executable-surface identity, complete
process-image identity, independent appraisal, PIDFD_GET_INFO, V14 dossier
equality, custody through V13 admission, release provenance, one-use transfer,
archive admission, provider operation, protected settlement, owner
constitution, restore continuity, external currentness, living law, or epoch
advancement.

Remain in Epoch Zero.
