# Handoff Cell V21 — provider-incarnation admission and independent reopen

## Status

Epoch-Zero hosted proof relation. V21 is package-local to `handoff_cell`. It is
not a downloader, etcd client, provider runtime, operator service, restore
controller, owner membrane, or authority API.

## Question

What evidence would be sufficient to treat one exact etcd v3.6.14 deployment as
one admitted provider-history incarnation, observe the exact V20 joined
transaction in that incarnation, classify restore or replacement, and later
reopen the same result from an administration domain that cannot roll the
candidate back?

V21 answers only by making the premises explicit and ordered. The hosted row
stops before archive-body admission.

## Ordered relation

`ProviderIncarnationObservationV1` contains 63 booleans. They form one prefix;
a true observation after a false observation is incoherent.

### 1. Release metadata, observations 1–4

The exact release profile and v3.6.14 tag are selected. The official checksum
product is present and separately authenticated. This binds metadata only.

### 2. Archive and binary admission, observations 5–8

The exact Linux amd64 archive body is present, hashes to
`ffe840ff9295808e88cce2794a18a5ac87f12a5203c8314d0bf6aa119b41bac5`,
and yields the exact admitted member inventory and binary digests. A release
page, tag, checksum line, filename, local source build, or version string cannot
satisfy this stage.

### 3. Incarnation coordinates, observations 9–20

Cluster ID, member IDs and count, client and peer trust roots, server
certificate set, application principal, complete administration inventory,
authentication state and revision, exclusive application namespace, and exact
member endpoint set agree. These are descriptive coordinates, not custody or
newestness.

### 4. Administrative and restore custody inventory, observations 21–24

Every data-directory controller, snapshot controller, restore authority, and
replacement authority is enumerated. Omission fails closed. File ownership,
TLS possession, a user namespace, or a second process is not independent
administration.

### 5. V20 native transaction observation, observations 25–41

The exact V20 plan is supplied: four compares, three success writes, one
transaction attempt, exact response coordinates and nonzero revision, then a
linearizable exact readback of head, spend, and pending entry at one revision.
Duplicate, ambiguous-completion, and reopen paths are query-only and expose no
resubmit route.

### 6. Quorum agreement, observations 42–49

Status and health are collected for the admitted quorum; members report the
same cluster; member and learner inventory is exact; `endpoint hashkv` agrees
at the exact revision; and alarm inventory is exact. This proves bounded member
agreement only. All admitted members can agree on a coherent restored past.

### 7. Restore, replacement, and succession, observations 50–54

Every restore or replacement is classified. An etcd snapshot restore creates a
new logical cluster identity. `--bump-revision` and `--mark-compacted` protect
consumers from stale caches; they are not succession. A successor ceremony must
bind the new incarnation, and the predecessor must be retired under a distinct
administration root.

### 8. Independent reopen, observations 55–63

The reopener has distinct administration, credentials, storage control, and
network path; reopens the exact profile and exact V20 result; shares no rollback
route; and is backed by explicit external-currentness and stable-storage
contracts. Only the full synthetic prefix reaches
`independent_reopen_premise`.

## Hosted result

The retained host probe admits the exact official checksum line and an exact
operator observation that the cloudtainer transfer boundary refused the
`application/gzip` archive after reporting 24,915,654 response bytes. Zero
archive bytes were retained. There is no mirror, source-build, package-manager,
or version-string fallback.

The same probe creates two distinct child user namespaces. Their outer parent
can inspect the namespace surfaces, open pidfds, and terminate both children.
This is an executable counterproof against treating namespace diversity as
independent administration.

```text
ordered premises:                    63
relation cases:                      68
relation countermodels:              42
full synthetic reopen profiles:       1
host cases:                          28
host counterexamples:                20
official checksum product exact:   true
archive transfer refused:          true
archive-body bytes:                    0
distinct child user namespaces:    true
outer-parent process control:      true
independent administration:       false
provider operated:                false
network attempted:                false
authority:                        false
```

## Nonclaims

V21 does not establish release-payload custody, official-binary provenance,
provider operation, cluster currentness, stable media, restore continuity,
independent administration, portable clone/restore exclusion, protected
settlement, owner constitution, living law, or epoch advancement.

## Next admissible cut

Provide the exact archive through an admitted byte channel or an independently
operated provider whose release, administration, data, snapshot, replacement,
and reopen roots are outside the datacube rollback domain. Do not introduce an
etcd client library, transaction daemon, automatic retry worker, local source
build, mirror fallback, or same-root “independent” reopener merely to make the
positive path run.
