# Handoff Cell V22 — finite release-body capsule, complete before parse

## Status

Epoch-Zero hosted proof relation and package-local Linux mechanism. V22 is not
a downloader, mirror, release cache, archive parser, extractor, installer,
provider runtime, retry service, durable upload service, owner membrane, or
authority API.

The exact etcd v3.6.14 Linux amd64 archive still has not crossed the cloudtainer
boundary. V22 constructs the missing finite byte-custody seam without pretending
that its synthetic fixture is that archive.

## Question

When a binary response is refused by the ambient transfer boundary but exact
text records can be supplied from outside, what conditions are necessary before
the reconstructed bytes may even be offered to the inherited passive release
ingress?

V22 answers with one strict rule:

> No chunk, declared count, sparse file, text transcript, or collection of part
> hashes is the release body. Only complete exact coverage, an independently
> recomputed whole-object digest, and an irreversible seal close the capsule;
> even then the result is merely eligible for V11 receiver-side recapture.

## Fixed release profile

```text
release:          etcd-v3.6.14-linux-amd64.tar.gz
expected bytes:   24,915,654
expected SHA-256: ffe840ff9295808e88cce2794a18a5ac87f12a5203c8314d0bf6aa119b41bac5
text encoding:    canonical RFC 4648 base64
```

The profile names expected bytes. It does not establish that those bytes were
received.

## Ordered relation

`ReleaseBodyCapsuleObservationV1` contains 36 booleans forming one prefix. A
true observation after a false observation is incoherent.

### 1. Release metadata, observations 1–4

The exact release profile, filename, expected byte length, and expected whole
SHA-256 are supplied. This is metadata only.

### 2. Text envelope, observations 5–11

A finite armored body is supplied under one exact envelope version and session
identity. Canonical RFC 4648 base64 is mandatory. Fixed decoded chunk size,
exact chunk count, and total-length arithmetic agree. Session identity prevents
mixing; it does not authorize acquisition or make records exclusive.

### 3. Staging floor, observations 12–18

The destination is private, unlinked, and bounded to the expected total length.
Archive parsing, extraction, execution, and network routes are absent before
completion. Preallocation constrains shape but does not prove coverage.

### 4. Chunk records, observations 19–28

Each record binds the exact session, in-range index, index-derived offset,
expected decoded length, canonical base64 spelling, exact decoded length, and
its own SHA-256. Writes occur only at the derived offset. An identical duplicate
is query-only and changes no byte. The first conflicting duplicate permanently
poisons that session; there is no last-writer-wins repair and no silent retry.

### 5. Complete coverage, observations 29–32

Every exact range is present once, ranges do not overlap, no trailing bytes
exist, and assembled length equals 24,915,654. A sparse or preallocated object
with holes cannot satisfy this stage.

### 6. Whole-object identity, observations 33–34

SHA-256 is recomputed over the complete assembled byte sequence and compared
with the exact expected release digest. Part hashes do not compose into this
claim. Reading holes as zeroes before coverage is forbidden.

### 7. Seal and inherited ingress, observations 35–36

The complete staging object is sealed against write, growth, shrinkage, and
further seal changes. That seal closes local mutation of the staged inode; it
does not establish provenance, exclusivity outside the receiver, or release
admission.

The sealed capsule remains upstream of V11. The receiver must still recapture
all bytes into a new private sealable memfd, apply a fresh complete seal barrier,
recompute SHA-256 from that receiver-owned object, compare exactly, and perform
passive archive inspection. V22 exposes no parser or shortcut around V11.

## Hosted mechanism witness

The host probe uses an 8,193-byte deterministic fixture split into nine chunks.
It exercises strict base64 decoding, shuffled arrival, identical duplicate
queries, conflicting-duplicate poisoning, missing coverage, wrong whole digest,
and the complete Linux file-seal barrier.

```text
relation cases:                    42
relation countermodels:            24
ordered premises:                  36
full V11-eligible profiles:         1
host cases:                        36
host counterexamples:              24
synthetic fixture bytes:         8193
fixture chunks:                      9
out-of-order exact records:      accepted
identical duplicate:          query-only
conflicting duplicate:           poisoned
whole digest recomputed:            true
write/grow/shrink after seal:    refused
archive-body bytes received:          0
archive parse attempts:               0
extraction attempts:                  0
execution attempts:                   0
network attempts:                      0
provider operated:                 false
authority:                         false
```

## Counterclaims explicitly defeated

V22 retains executable countermodels for checksum-without-body, base64-as-
archive, declared count as completeness, preallocation as coverage, part hashes
as whole identity, permissive base64 aliases, sender-controlled offsets,
last-writer-wins duplicates, poison-then-continue, digest-before-seal,
seal-as-admission, live session as durable resume, synthetic fixture as release,
and V11 eligibility as authority.

## Nonclaims

V22 does not establish source provenance, transport authenticity, durable
cross-host session reopen, exclusive upstream custody, archive admission,
official binary provenance, provider operation, external currentness, rollback
resistance, protected settlement, owner constitution, living law, or epoch
advancement.

## Next admissible cut

Supply the exact finite armored record set through an independently admitted
channel, retain the complete records and their external provenance, close the
capsule, then traverse V11 without changing bytes. A missing record is a stop.
A conflicting record is a poisoned session. There is no automatic retry,
mirror fallback, local source build, package substitution, parser-before-
complete path, or authority promotion.
