# Handoff Cell V7 — fixed endpoint claim before payload meaning

## Status

This is a hosted Epoch-Zero proof contract. It refines the existing handoff
island; it is not an admitted provider, protected endpoint, globally unique
spend, effect authorization, settlement service, stable-media theorem, or
living law.

## Question

Given one fixed candidate directory containing one exact encoded `pending`
record, can the endpoint establish a single process-local transition into
payload interpretation such that:

1. the fixed namespace claim occurs before any semantic inspection of the
   pending object or request payload;
2. only the fresh exact winner can enter the sole payload parser;
3. every duplicate and every reopen is query-only;
4. malformed object or payload cannot restore `pending` or mint another parser
   entry; and
5. the proof retains, rather than hides, alias, writer, clone, rollback,
   durability, provenance, and settlement countermodels?

V7 answers this hosted question only.

## Fixed objects

The caller retains one already-open directory descriptor selected by the host.
The only candidate namespace leaves are:

```text
pending
claimed
```

The only mutation entrypoint is:

```text
renameat2(dirfd, "pending", dirfd, "claimed", RENAME_NOREPLACE)
```

The implementation must not open, read, compare, decode, stat, or otherwise
interpret `pending` or `claimed` before that call returns success. It must not
accept a caller-selected path, leaf, route, version, retry policy, recovery
operation, or cleanup action.

## Claim ordering

For a fresh call:

```text
fixed pending -> claimed no-replace rename
  -> directory fsync attempt
  -> open fixed claimed leaf with O_NOFOLLOW | O_NONBLOCK
  -> require regular file, exact encoded-record size, nlink == 1
  -> require expected owner and no write bits
  -> read exactly one encoded record and no surplus byte
  -> require byte equality with the expected record
  -> decode and require record kind PENDING
  -> construct one internal ClaimedPending only if directory fsync succeeded
```

A directory-sync failure after successful rename is classified as an exact
claimed namespace state with synchronization uncertainty. It is never
translated back to `pending_missing`, `not_consumed`, or retry permission, but
it is query-only: it mints no `ClaimedPending` and cannot enter payload meaning.
A later normal reopen can report exact claimed bytes only as query evidence.

If `claimed` already exists, the method performs only the exact fixed
observation path. Exact duplicates return `already_claimed_exact`, with no
`ClaimedPending`. Missing, nonregular, wrong-size, aliased, writable,
wrong-owner, mismatched, undecodable, wrong-kind, unsupported, and I/O states
fail closed and mint no token.

## Type boundary

`EndpointClaimObservation` is copyable and deliberately powerless:

```text
query_only = true
response_authority = false
```

`ClaimedPending` is internal, move-only, and has no public constructor. Only a
fresh exact post-rename result whose directory-sync attempt succeeded may
contain one. Copy construction and copy assignment are deleted. It is a
process-local control-flow witness, not a
kernel capability and not a claim about aliases, snapshots, other histories,
or external revocation.

The sole semantic request parser has the shape:

```text
PayloadAfterClaim::parse_exact(ClaimedPending&&, request_bytes)
```

It consumes the claim before reading request length, magic, version,
generations, operation binding, or spent-receipt binding. Exact and malformed
payload outcomes both leave the token spent. A missing or previously spent
token cannot examine payload bytes.

## Fixed request

The hosted request is exactly 96 bytes:

```text
0..7    ASCII "SLOPEPC1"
8..11   little-endian version 1
12..15  reserved zero
16..23  generation_from
24..31  generation_to
32..63  operation_binding
64..95  spent_receipt_binding
```

It must match the exact decoded pending record. Parsing performs no effect,
settlement, response publication, or route selection.

## State relation

Within one coherent hosted directory history:

```text
PENDING
  -- fixed no-replace claim + directory sync success --> CLAIMED_FRESH

PENDING
  -- fixed no-replace claim + directory sync failure --> CLAIMED_SYNC_UNCERTAIN

CLAIMED_FRESH + exact payload
  -- consume internal token --> CLAIMED_SPENT / exact_request

CLAIMED_FRESH + malformed payload
  -- consume internal token --> CLAIMED_SPENT / malformed_request

CLAIMED_FRESH, CLAIMED_SYNC_UNCERTAIN, or CLAIMED_SPENT + duplicate/reopen
  -- observe only --> QUERY_ONLY
```

There is no reverse transition and no `claimed -> pending` API. Recovery cannot
mint `ClaimedPending`. Copying an observation cannot enter the parser.

## Required campaign

The retained campaign must include:

- exact fresh claim and exact payload;
- malformed payload burns eligibility and a retry is query-only;
- malformed record is claimed before decode rejection;
- FIFO/nonregular, wrong-size, writable/wrong-owner, exact mismatch, and missing
  cases;
- preexisting exact and conflicting `claimed` cases;
- deterministic successful rename followed by failed directory sync, with zero
  parser tokens and query-only reopen;
- hard-link alias and inherited writable-descriptor counterexamples;
- coherent directory-clone and snapshot-rollback counterexamples;
- sixteen process contenders sharing one directory;
- process death before claim, after raw rename, after fresh token, and after
  payload before reply; and
- an independent source-shape and evidence oracle.

For the sixteen-process hosted race, exactly one process may receive a fresh
claim, exactly one may enter the parser, and fifteen must be query-only exact
duplicates.

## Governing countermodels

The positive theorem is bounded by four defeats:

1. a hard-link alias survives namespace claim, so one name transition does not
   consume all object references;
2. a writable descriptor opened before claim can mutate the inode after exact
   readback, so the move-only token is a snapshot witness, not immutable object
   custody;
3. two coherent directory copies each admit one fresh claim, so local
   `RENAME_NOREPLACE` is not globally unique spend; and
4. restoring a pre-claim snapshot restores `pending`, so local reopen is not a
   nonrollback or newest-history theorem.

Directory `fsync` is a declared host operation, not a physical power-loss proof.
A successful rename can remain durability-uncertain. Known synchronization
failure is therefore a claimed/query-only stop, not permission for first
semantics. The cloudtainer still
chooses the directory, filesystem, mount, snapshots, backups, writers,
executable, provider, and administrative roots.

## Forbidden promotion

V7 does not prove:

```text
protected_pending_entry_claim
protected_provider
owner_admission
global_unique_claim_spend
exclusive_writer_custody
stable_media
physical_power_loss safety
external rollback floor
source-to-operated-binary identity
endpoint epoch authenticity
effect authorization
exact settlement
authenticated result
independent actor or reopen
living-law admission
```

The next legitimate construction must place the same ordering relation behind
an owner-admitted provider whose claim state cannot be cloned or restored with
the candidate, then join one exact claimed operation to bounded effect/no-effect
or uncertainty settlement and independent appraisal.
