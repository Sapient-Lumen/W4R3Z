# Handoff Cell V13 — pre-admitted sealed-snapshot offer

V13 adds one authority-negative descriptor-delivery prefix beside V12 and
upstream of V11. It is a bounded ingress relation inside the existing handoff
cell. It is not a downloader, package manager, release service, activation
service, provider launcher, owner, or living office, and it interprets no
candidate byte.

## Exact ordered prefix

A successful V13 relation means only that one externally admitted process
coordinate supplied the receiver's first candidate-specific descriptor alias to
one object with the accepted present-time profile. Every premise below is
ordered:

```text
caller supplies one already-connected descriptor
  -> receiver makes one close-on-exec duplicate
  -> AF_UNIX + SOCK_SEQPACKET
  -> SO_PASSCRED + SO_PASSPIDFD
  -> SO_PEERCRED + SO_PEERPIDFD establish one peer coordinate
  -> receiver is externally proved to hold zero aliases to this candidate
  -> an external office admits that exact acquisition-actor coordinate
  -> only then receiver emits the fixed READY frame
  -> only then recvmsg(MSG_CMSG_CLOEXEC) may import one OFFER record
  -> no MSG_TRUNC or MSG_CTRUNC
  -> payload equals SLOPOS-E0-SEALED-OFFER-V1 exactly
  -> exactly one SCM_RIGHTS control record
  -> exactly one descriptor in that SCM_RIGHTS integer array
  -> exactly one automatic SCM_CREDENTIALS record
  -> exactly one automatic SCM_PIDFD record
  -> no unknown ancillary record
  -> message pidfd identity equals admitted peer pidfd identity
  -> message credentials equal admitted peer credentials
  -> received descriptor is CLOEXEC
  -> F_GETFL access mode is O_RDONLY or O_RDWR and is not O_PATH
  -> received descriptor is regular, unlinked and bounded
  -> F_GET_SEALS succeeds
  -> F_SEAL_WRITE|F_SEAL_GROW|F_SEAL_SHRINK|F_SEAL_SEAL are present
  -> only then may the downstream V11 recapture read candidate bytes
```

The frame carries no path, release name, digest, claimed length, retry
instruction, activation target, or caller-selected metadata. An unadmitted peer
receives no READY and causes no rights-bearing receive. Any later missing,
repeated, surplus, mismatched, truncated, unreadable, linked, unsealed,
oversized, unsupported, or unknown condition closes every installed descriptor
and stops.

## First receiver ingress is an external premise

`SCM_RIGHTS` cannot prove that it created the receiver's first alias to the
candidate. A receiver forked after candidate creation inherits the descriptor
before any message is sent. V13 therefore requires the candidate-specific
`receiver_preoffer_candidate_aliases_zero` premise before READY. The premise is
constructed by lifecycle topology or an independently auditable equivalent; it
is never inferred from the delivered descriptor number, one packet, or one
control record.

The positive laboratory topology forks the receiver first and creates the
offered object afterward. A separate executable counterproof creates the object
before fork and observes the inherited alias. The zero-alias premise is local
to the receiver and candidate. It does not prove that the sender, another
process, or the wider host has no alias, and therefore does not establish
exclusive custody or one-use spend.

The production interface must carry this premise explicitly. It is not enough
for the relation or laboratory to mention zero aliases while the adapter accepts
only actor admission. `receive_sealed_offer()` therefore checks
`receiver_preoffer_candidate_aliases_zero` first, then actor admission, then
READY, then the single rights-bearing `recvmsg`. A false or unavailable premise
closes the channel before READY and imports zero candidate descriptors.

## Process coordinate is not governance

`SO_PEERCRED` and `SO_PEERPIDFD` identify the peer coordinate associated with
socket construction. Automatic per-message `SCM_CREDENTIALS` and `SCM_PIDFD`
identify the process represented in the offer. Equality excludes the retained
pre-created-socketpair sender-substitution countermodel on this connection. It
does not prove that an owner selected the actor, that privileged administration
is closed, or that the actor acquired bytes from the claimed upstream release.

`acquisition_actor_admitted_before_ready` is therefore a separate external
premise. It must hold before READY and before any `recvmsg` capable of installing
candidate rights. Checking it after receive is not a recoverable rejection: an
unadmitted capability has already entered the receiver.

The hosted adapter compares peer and message pidfds through equal `fstat()`
device/inode observations. That is a retained host-profile comparator, not a
portable pidfd identity ABI. `pidfd_open(2)` supplies the stable task reference;
a future target must additionally validate a documented identity query such as
`PIDFD_GET_INFO` where supported. Neither comparator constitutes the actor.

## Present object behavior is not creator history

The accepted descriptor is readable, regular, unlinked, bounded and carries
all four required seals. Those observations establish current descriptor and
inode behavior under the hosted Linux contract. They do not prove that
`memfd_create()` was called, who called it, which process populated the bytes,
or which release they came from. V13 consequently keeps
`candidate_memfd_creation_proved=false` and `source_provenance_proved=false` in
every assessment.

## Seals do not grant read access

The seal profile constrains mutation of the inode; it does not change the access
mode of an open file description. A descriptor reopened `O_WRONLY` from the same
fully sealed anonymous object still reports the complete seal set, but `pread`
fails with `EBADF`. V13 therefore queries `F_GETFL`, accepts only `O_RDONLY` or
`O_RDWR`, rejects `O_PATH`, and records `candidate_descriptor_readable` as an
independent premise before source readiness. Regular shape, link-count zero, and
all four seals cannot substitute for it.

## Pure relation

`SealedSnapshotOfferObservationV1` and
`assess_sealed_snapshot_offer()` retain **36 cases and 20 countermodels**.
Exactly one synthetic row has every premise and reaches
`SEALED_SNAPSHOT_SOURCE_READY`. One coherent row rejects a receiver-side
pre-offer candidate alias. One coherent row rejects missing actor admission
before READY, message receipt, and descriptor installation. Five temporally
impossible observations are incoherent, including READY with a pre-offer alias,
READY before actor admission, and descriptor import before actor admission.

The relation checks `SCM_RIGHTS` control-record cardinality and delivered-
descriptor cardinality independently. One record containing two descriptors is
rejected. Every row retains zero candidate-body reads, zero digest comparison,
zero archive parse, and false one-use transfer, exclusive custody, creator
provenance, source provenance, durable media, activation, provider operation,
owner custody, and living authority.

## Hosted Linux counterproof

The standalone Linux probe retains **39 cases and 15 counterexamples**. It is a
test-only bad-order laboratory, not a production adapter. It forks the receiver,
then creates and seals the offered object so the receiver begins with zero
aliases to that candidate. It establishes the peer coordinate, sends READY, and
imports one exact offer before any external actor admission. The receiver sees
one exact rights record carrying one descriptor, matching credentials and pidfd
identity, a readable unlinked regular object, and the complete seal set, while
reading zero candidate bytes. Because admission is intentionally late, the probe also
proves the defect: an unadmitted rights descriptor is already installed and
`production_ingress_ready=false`.

The host campaign separately reproduces:

- candidate creation before `fork()` preinstalling a receiver alias;
- one `SCM_RIGHTS` record carrying two descriptors;
- `MSG_PEEK` installing a second rights duplicate for one queued packet;
- a sender retaining its original descriptor after `sendmsg()`;
- `MSG_CTRUNC` when ancillary capacity is absent;
- stream-socket type rejection;
- unsealed-object mutability;
- linked regular-file namespace exposure; and
- a fully sealed `O_WRONLY` alias whose `pread` fails with `EBADF`.

The Python production self-test exercises both pre-receive cuts. A receiver
without the zero-alias premise and a receiver facing an unadmitted actor each
send no READY, perform no offer receive, install zero candidate descriptors,
read zero candidate bytes, and retain no mechanism receipt. Its fully admitted
test-only controls also reject a fully sealed write-only descriptor before body
access.

## Composition with V11

A V13-ready result is only one sealed-descriptor source under explicit hosted
premises. V11 still performs a complete `pread` recapture into a fresh private
sealable object, installs the same four seals, recomputes SHA-256 from that
receiver-controlled object, compares the exact pinned digest, and only then
performs passive archive interpretation on those same bytes. This cut keeps the
sender's open file description outside the parser's retained object and
preserves the existing digest-before-semantics theorem.

## Capability boundary

V13 proves neither upstream provenance nor an authentic release, one-use
transfer, global alias closure, exclusive custody, durable media, rollback
resistance, a constituted acquisition actor, safe activation, operated etcd,
compare-and-commit, settlement, owner constitution, or living law. The exact
etcd v3.6.14 archive body is absent. Epoch Zero remains truthful.
