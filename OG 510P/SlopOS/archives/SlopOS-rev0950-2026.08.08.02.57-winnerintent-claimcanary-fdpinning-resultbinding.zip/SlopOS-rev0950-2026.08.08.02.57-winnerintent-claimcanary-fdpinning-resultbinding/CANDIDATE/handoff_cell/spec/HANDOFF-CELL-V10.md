# Handoff Cell V10 — exact etcd profile intent and query-only dossier

## Status

```text
EPOCH_ZERO / HOSTED-CANDIDATE / NON-OPERATIONAL PROFILE SEAM
```

V10 extends the existing `handoff_cell` semantic island. It does not introduce
a fourth island, an etcd client, a provider abstraction, a retry worker, a
settlement daemon, or a new authority-bearing receipt.

## Purpose

V9 proved that one exact owner-pinned signed provider-history description can be
verified without gaining authority. It did not operate a provider. V10 narrows
the next provider experiment to one exact upstream release and one exact
transaction/query shape, then makes absence of that release an explicit stop.

The governing separation is:

```text
release checksum product
  != admitted release archive
  != operated binary
  != admitted cluster
  != protected provider commit
  != owner-governed current history
```

## Exact release hypothesis

The sole release hypothesis is:

```text
version: v3.6.14
platform: linux-amd64
archive: etcd-v3.6.14-linux-amd64.tar.gz
archive SHA-256:
  ffe840ff9295808e88cce2794a18a5ac87f12a5203c8314d0bf6aa119b41bac5
key prefix: /slopos/e0/provider-history/v1/
```

The checksum is retained from the official upstream `SHA256SUMS` product. The
archive itself was unavailable in this cloudtainer. Therefore V10 contains no
operated etcd result and no release-admission success receipt.

## Profile pin

`EtcdProfilePinV1` names one caller-supplied profile hypothesis:

```text
exact release version and archive digest
one nonzero cluster ID
three nonzero distinct member IDs
client CA digest
peer CA digest
application-principal digest
complete administration-inventory digest
nonzero auth revision
```

The pin is not self-authenticating. It does not say who selected or protects the
CAs, who can change membership/authentication, who can snapshot or restore, or
whether this cluster is the newest surviving history.

## Expected edge

`EtcdHistoryExpectedV1` binds:

```text
generation_from
exact generation_to = generation_from + 1
operation_binding
floor_identity
predecessor_head
successor_head
spend_record
pending_entry
```

Every digest must be nonzero and predecessor/successor must differ.

## Deterministic transaction intent

`make_etcd_history_txn_plan` derives four fixed keys:

```text
/slopos/e0/provider-history/v1/head
/slopos/e0/provider-history/v1/floor
/slopos/e0/provider-history/v1/spend/<operation-binding-hex>
/slopos/e0/provider-history/v1/entry/<operation-binding-hex>
```

The rendered transaction intent contains exactly four compares:

```text
head value equals predecessor_head
floor value equals floor_identity
spend-key version equals zero
entry-key version equals zero
```

Its success branch contains exactly three writes:

```text
head := successor_head
spend/<operation> := spend_record
entry/<operation> := pending_entry
```

Its failure/recovery intent queries exactly the four fixed keys. Query mode must
be linearizable; a serializable member-local read is rejected.

This text is a deterministic plan, not a transport object. V10 has no process,
socket, path, TLS, gRPC, etcdctl, submit, retry, or provider-mutation entrypoint.
It proves neither that the plan is accepted by etcd nor that its syntax is an
exhaustive production configuration.

## Normalized dossier

`EtcdHistoryDossierV1` is assembled outside the candidate. Before any key/value
state is classified, `assess_etcd_history_dossier` checks in order:

```text
profile and expected-edge invariants
runtime actually observed
exact release version and archive digest
exact cluster ID
member is in the fixed member set
exact auth revision
query delivered
query is linearizable
nonzero revision/term and no delivered-query regression
```

Only then may the four values be compared with the expected current or unused
state. The resulting `EtcdHistoryAssessment` is always copyable, query-only,
and carries:

```text
response_authority = false
retry_authority = false
provider_commit_proved = false
restore_continuity_proved = false
external_currentness_proved = false
```

No V10 type reaches endpoint claim, payload parsing, hosted settlement, or any
effect route.

## Dispositions

The classifier distinguishes:

```text
RUNTIME_UNAVAILABLE
RELEASE_MISMATCH
PROFILE_MALFORMED
FOREIGN_CLUSTER
FOREIGN_MEMBER
AUTH_REVISION_MISMATCH
QUERY_UNAVAILABLE
SERIALIZABLE_QUERY_REJECTED
REVISION_REGRESSION
EXACT_CURRENT_OBSERVATION
EXACT_CURRENT_AFTER_AMBIGUOUS_REPLY
EXACT_UNUSED_AFTER_AMBIGUOUS_REPLY
COMPARE_FAILED_CURRENT_OBSERVATION
COMPARE_FAILED_UNUSED_OBSERVATION
CONFLICTING_OBSERVATION
```

“Exact current” means only that one supplied dossier matches the named profile
and expected bytes under this classifier. It is not a provider commit, newest-
history, or administration-plane theorem.

## Campaign

The deterministic campaign retains nineteen cases. Exactly one row describes
the construction host:

```text
current_cloudtainer_runtime_unavailable
  -> RUNTIME_UNAVAILABLE
  -> synthetic_runtime = false
```

The remaining eighteen rows are explicitly synthetic classifier fixtures. They
cover exact delivered state, lost-reply current/unused refinement, compare-
failed current/unused refinement, release/version mismatch, foreign restore
cluster, foreign member, auth drift, unavailable query, stale serializable read,
revision regression, floor mismatch, partial state, coherent clone, root rewrite,
and malformed pin.

Seven counterexamples remain live:

1. missing release runtime defeats plan-as-operation;
2. coherent clones preserve IDs and values without proving newest history;
3. root authority can rewrite expected values;
4. restore creates a new logical cluster;
5. caller-selected pins do not constitute an owner;
6. synthetic dossiers are not operated experiments; and
7. rendered transaction intent is not submission or commit.

Three compiler/sanitizer lanes must produce byte-identical canonical evidence.
An independent Python oracle checks exact cases, source order, query-only flags,
transport/mutation absence, and separation from endpoint/settlement types.

## Release admission gate

`TOOLS/admit_etcd_v3614_release.py` is the only V10 release-byte gate. It:

```text
stops if the archive is absent or a symlink
hashes the complete archive before opening it
stops unless the SHA-256 is exact
rejects absolute, dot, parent, duplicate, symlink, hardlink and special members
requires etcd, etcdctl and etcdutl under the exact top directory
extracts only those regular binaries into a disposable directory
checks their reported 3.6.14 version
emits a release-bytes-only receipt
```

Even a future `PASS` would admit release bytes only. It would not admit a
cluster, owner, root inventory, provider history, transaction, or result.

## Positive theorem

V10 proves only:

```text
one exact v3.6.14 release hypothesis is pinned;
one exact four-compare/three-write/four-query plan is deterministic;
one fail-closed query-only dossier classifier rejects profile/query drift;
the current host honestly stops before operation because the runtime is absent.
```

## Forbidden promotion

V10 does not prove:

```text
archive provenance beyond the retained upstream checksum product
source-to-binary reproducibility or compiler provenance
TLS or gRPC transport correctness
cluster bootstrap, membership, quorum, lease or storage correctness
application least privilege or complete root-role inventory
provider compare-and-commit or stable media
one-use spend, protected effect or protected settlement
owner constitution, key protection or successor governance
snapshot/restore continuity, anti-rollback or newestness
independent appraisal or independently provisioned reopen
living-law admission
```

## Next admissible construction

Supply and independently admit the exact archive; provision owner/appraiser
roots outside the data directory; launch one fixed authenticated three-member
cluster; enumerate every administration, membership, snapshot and restore
principal; execute only the fixed transaction and linearizable query; then
attack concurrency, timeout, leader loss, stale reads, snapshot/restore, cloned
histories, auth drift, new-cluster identity, and independent reopen. Any missing
premise remains a stop. Epoch Zero remains open.
