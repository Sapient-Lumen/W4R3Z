# Handoff Cell V20 — single-ledger atomic join and local rollback counterproof

## Status

Epoch-Zero hosted proof surface, package-local to `handoff_cell`. V20 is not an
etcd client, database service, provider, rollback oracle, owner membrane, or
living-law surface. Its production relation is pure C++20. Its SQLite program
is a test-only crash/reopen mechanism witness and counterproof.

## Why V19 was insufficient

V19 correctly rejected a TPM-extend/witness pair as an atomic spend floor.
Either ledger can advance first; a crash can leave a durable split; query-only
recovery can classify but cannot repair it. Reversing the order only reverses
the fracture.

The old vault already contained the missing narrower shape in two places:

```text
V10 exact provider-history intent:
  compare head value
  compare floor value
  compare spend version = 0
  compare entry version = 0
  then atomically write head + spend + entry

V18 spend-floor law:
  compare expected generation and expected content head
  append the exact spend and pending entry in the same provider history
```

V20 composes those existing laws. It does not invent a second local ledger or
pretend that local transactionality supplies external custody.

## Ordered relation

`SingleLedgerJoinObservationV1` evaluates 46 ordered observations:

```text
01–10  exact admitted provider profile and exclusive namespace
11–19  exact canonical V18 spend and consecutive edge
20–27  exact four-compare / three-write transaction plan
28     exactly one transaction attempt
29–38  exact response and linearizable same-revision readback
39–42  duplicate, ambiguous completion, and reopen are query-only;
       no resubmit route exists
43     restore or replacement is independently detectable
44     provider administration is distinct from the datacube root
45     external currentness is independently bound
46     stable-storage contract is independently bound
```

The first 38 observations establish only
`single_ledger_atomic_join_bound`: one admitted provider serialization history
contains the exact predecessor compares and the exact head, spend, and entry
writes at one nonzero revision. Observations 39–42 establish query-only
recovery. The final four premises are independent custody facts; a local
SQLite database, self-hosted cluster, signed response, or successful campaign
does not supply them.

Exactly one synthetic full-prefix row reaches
`eligible_for_v18_external_floor_premise`. It is relation evidence, not an
operated external floor.

## Exact transaction shape

The campaign reuses the inherited V10 plan constructor and rejects drift from:

```text
release profile: etcd v3.6.14
compares:        4
success writes:  3
failure queries: 4
query mode:      linearizable (serializable/member-local is false)

compare exact head value
compare exact floor value
compare exact spend-key version = 0
compare exact entry-key version = 0

put exact successor head
put exact V18 spend digest/value
put exact pending entry
```

The three writes must be one provider transaction and must be observed at one
revision. Three successful calls, ordered file writes, or matching application
transaction IDs are not substitutes.

## Exactly-one-attempt and ambiguity law

The operation path has one transaction-attempt premise. Once submission may
have occurred, every duplicate, lost-reply, reopen, and recovery path is
linearizable query-only. It may classify exact-current, exact-unused, or
conflict. It cannot resubmit, compensate, repair a split, or mint authority.

## Local crash/reopen laboratory

The host probe uses SQLite 3 only to test the mechanism shape under one local
serialization history. It selects rollback-journal mode `DELETE` and requests
`synchronous=FULL`. One `BEGIN IMMEDIATE` transaction checks the exact old
floor and absence of edge/spend/entry, inserts edge/spend/entry, updates the
head, and commits.

Seven abrupt `SIGKILL` cuts are retained:

```text
after begin
 after compare
 after edge insert
 after spend insert
 after entry insert
 after head update
 after commit
```

The first six reopen at the exact old state; the post-commit cut reopens at the
complete new joined state; zero cuts expose a split. An eight-process race has
one local winner and seven conflicts. Query-only inspection performs zero
logical changes.

These are local process-crash observations only. `synchronous=FULL` is a
request to the SQLite/VFS/OS stack, not independent proof of physical-media
persistence.

## Counterproofs

Two coherent copies of the pre-spend database each advance the same spend. A
restored pre-spend snapshot advances again. A manually split state is
classified as conflict and is not repaired. Therefore:

```text
local transaction atomicity != external currentness
process-crash atomicity      != rollback resistance
one local race winner        != portable one-use
integrity_check = ok          != provenance or governance
SQLite runtime               != the exact etcd provider profile
successful commit            != owner authority
```

## Evidence inventory

The pure campaign retains 51 cases, 32 countermodels, one exact inherited
four-compare/three-write/four-query plan, nine synthetic atomic-join prefixes,
five query-only prefixes, and one synthetic complete external-floor premise.

The host probe retains 30 cases and 18 counterexamples: seven crash cuts, one
local eight-contender race, two coherent clone histories, one restored replay,
and one split-state fail-closed query. It performs zero network attempts and
operates no provider.

## Mandatory zeroes

No etcd process, cluster, network request, release acquisition, archive-body
read, READY frame, SCM_RIGHTS import, provider operation, protected settlement,
owner promotion, or living-law transition occurs. Remain in Epoch Zero.
