# Handoff cell v1 — burn and pending identity share one namespace call

**Status:** Epoch-Zero hosted Linux construction; nonauthoritative.  
**Obligation narrowed:** O57.  
**Authority granted:** none.

## Selected seam

The cell uses exactly two reserved leaves beneath one already-open directory:

```text
live       inert, exact 128-byte pending identity prepared before admission
pending    consumed identity visible to query-only reconciliation after admission
```

Admission is one fixed call:

```text
renameat2(cell_fd, "live", cell_fd, "pending", RENAME_NOREPLACE)
```

The burn method accepts no path, operation identifier, endpoint, route, or
overwrite choice. A hosted adapter does accept one pre-opened directory
descriptor; selection, provisioning, credentials, aliases, and writer custody
for that directory are explicit premises outside this primitive. Retaining the
descriptor checks only that it names a directory. The burn method performs no
leaf `stat`, `open`, `read`, decode, checksum, or policy decision before the
rename. Therefore malformed bytes cross the local one-way API cut before they
are rejected. A pre-existing `pending` leaf fails stop and is not replaced.

The directory is then fsynced. If the rename succeeds but directory fsync fails,
the result remains **name-bound, durability uncertain**. A post-cut failure is
never translated into an unspent or retryable result.

## Post-cut readback

Only `pending` can be queried. The query:

1. opens the fixed leaf without following a final symlink and with nonblocking
   semantics so a malformed FIFO cannot hold the query surface open;
2. requires a regular 128-byte file;
3. observes one hard link;
4. compares all bytes with an externally supplied expected canonical identity;
   that query key changes only the read result and grants no mutation; and
5. decodes the generation-journal pending record.

Every check occurs after the admission call. Rejection retains `pending`. The
API has no stage, mint, retry, apply, route, rollback, unlink, reverse-rename, or
descriptor-export method.

## Hosted result

On the recorded cloudtainer host and at the actual scheduled process-death
positions:

- the exact inode was observed under `live` before the call or under `pending`
  after the burn method returned;
- sixteen racing processes produced one successful bind;
- malformed bytes did not restore `live`;
- a malformed FIFO was consumed and rejected as nonregular without blocking;
- a present `pending` was never overwritten; and
- reconciliation could only read `pending`.

The SIGKILL positions are before the admission call, after the burn method and
its directory-sync attempt return, and after exact readback. There is no
injected cut inside the rename-to-fsync interval. The campaign exercises
outcomes consistent with Linux's documented rename contract; it does not
independently prove the kernel. This is a local process/namespace observation,
not a protected capability theorem.

## Retained defeats

`rename` preserves other hard links and open descriptors. The campaign retains
both a surviving hard-link alias and an already-open writable descriptor that
changes `pending` after exact readback while `st_nlink == 1`. Thus the real
provider must establish alias exclusion and exclusive writer custody before
this cut.

A coherent local snapshot can also reproduce the pre-burn `LIVE` observation.
Thus local storage cannot establish newestness. A protected deployment still
needs an independently rooted monotonic rollback floor or external durable
spent receipt.

Directory fsync is performed because the directory entry—not merely file
contents—must be flushed. It is not claimed to prove physical-power-loss
survival, device honesty, or filesystem recovery behavior.

## Advancement rule

This construction falsifies the idea that O57 can be solved by a move-only C++
token or by a local journal append after burn. It identifies one viable local
no-replace namespace shape under an external kernel contract, but it does not
wire a protected core-gate receipt to provider-owned staging or endpoint
execution. Epoch Zero remains open until a constituted named provider chooses
and controls the cell, all writers and aliases, stable spent/result media, an
authenticated bounded query, destructive cuts, an external rollback floor, and
independent reopen.
