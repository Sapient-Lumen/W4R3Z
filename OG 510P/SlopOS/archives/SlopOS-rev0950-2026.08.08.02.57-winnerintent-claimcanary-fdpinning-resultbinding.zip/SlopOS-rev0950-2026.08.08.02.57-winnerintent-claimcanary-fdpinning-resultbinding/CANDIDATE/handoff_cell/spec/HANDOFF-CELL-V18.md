# Handoff Cell V18 — exact appraiser-receipt spend airlock

## Status

Epoch-Zero hosted proof surface. V18 is package-local to `handoff_cell`. It is
not an appraiser service, key service, monotonic-counter service, provider,
installer, network client, authority membrane, or living-law surface.

## Narrow theorem

When all local premises through `no_second_append_after_spend` hold in order,
V18 may conclude only:

```text
one canonical V17 receipt decoded and exactly cross-bound
+ exact message/signature/public-key envelope domain-hashed
+ one canonical 352-byte spend record bound that envelope and selected subjects
+ one content-bound compare-and-append request named an exact predecessor
+ one exact advanced/already-current response interpreted query-only
+ duplicate and reopen in the same coherent history cannot initiate another append
= one_local_receipt_spend_bound
```

This is one coherent-history theorem, not portable anti-replay, rollback
resistance, external freshness, independent appraisal, actor admission,
settlement, owner constitution, or living law.

## Exact mapping

V18 reuses Generation Journal `SpendRecordV1`; it creates no parallel journal.

```text
owner_statement       = V17 appraiser_constitution
constructor_image      = V17 v16_static_envelope
provider_subject       = pinned floor_identity
publication_receipt    = SHA-256(domain || message || signature || public_key)
expectation_record     = V17 challenge
operation              = V17 actor_epoch
pending_result         = V17 hold_token
spend_serial           = V17 report_ordinal
predecessor_head       = exact content-bound predecessor
```

V15 input, installed policy, kernel surfaces, process coordinate, and V14
remain in the signed envelope and are also decoded and independently
cross-checked. A digest match is not accepted as semantic reconstruction.

## Compare-and-append cut

A scalar generation is insufficient. The request and response bind floor
identity, exact predecessor generation and head, exact consecutive target,
canonical record bytes, target head derived from those bytes, and the exact
current record on `advanced` or `already_current`. Unavailability, malformed or
scalar-only state, foreign content, identity mismatch, local-ahead state,
generation jump, and ambiguous reply fail closed. Lost reply recovery is exact
query/reconciliation only.

## External premises left false

External spend requires distinct appraiser administration; independent key and
input custody; external challenge/spend state; a rollback floor outside every
restorable candidate image under distinct administration; restore continuity;
a lifetime-bound process coordinate; independent policy, kernel-surface, and
V14 reconstruction; no same-root mutation path; actor hold through V13; and
portable clone/restore replay exclusion. This cloudtainer establishes none.

## Executable counterproof

The probe creates the content-bound floor in ordinary process memory before
`fork()`. Two children inherit the same pre-spend state and both accept the same
exact predecessor as `advanced`. A separately restored pre-spend copy advances
again. In one parent history, the duplicate is `already_current` and query-only.

```text
same-history duplicate exclusion
!= clone-safe one-use
!= snapshot rollback resistance
!= external monotonicity
```

## Host stop

The retained host exposes no `/dev/tpm0`, `/dev/tpmrm0`, IMA securityfs view, or
`tpm2_getcap`. V18 does not simulate them or fall back to a pathname, scalar
file, local timestamp, report ordinal, or network service. Even a TPM monotonic
counter needs a protected content mapping/log to identify which receipt won.

## Mandatory zeroes

No network, V13 READY, SCM_RIGHTS import, archive-body read, activation,
provider transaction, owner promotion, or living-law promotion occurs.
Remain in Epoch Zero.
