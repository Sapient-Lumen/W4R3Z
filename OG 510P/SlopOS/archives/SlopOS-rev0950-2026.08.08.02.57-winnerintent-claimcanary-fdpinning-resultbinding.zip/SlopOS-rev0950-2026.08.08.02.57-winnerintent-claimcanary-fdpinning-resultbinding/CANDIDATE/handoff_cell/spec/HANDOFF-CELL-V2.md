# Handoff cell v2 — scoped principal wall and immutable publication

**Status:** Epoch-Zero hosted Linux construction; nonauthoritative.  
**Obligations narrowed:** O57 and the local publication portion of O59.  
**Authority granted:** none.

V2 retains every V1 law and counterexample. It does not replace the low-level
`Cell` adapter; it adds one bounded provider-process experiment inside the same
package rather than creating a fourth hosted state-machine family.

## Scoped provider cell

The current provider process must already run as one declared nonzero UID and
receive an owner-only provider-root descriptor. The factory accepts no cell
name. It creates exactly fixed child `cell`, verifies provider ownership and
mode `0700`, fsyncs the provider root, and exports no cell descriptor.

The retained campaign uses provider UID 21001 and workload UID 21002. Both are
disposable numeric principals created by a root coordinator solely for the
hosted experiment. The provider sets `no_new_privs`, internally stages exact
pending bytes under fixed `live`, and then invokes the V1 fixed
`live -> pending` no-replace cut. The workload receives only path knowledge. On
the recorded host it cannot traverse the provider root, open `pending`, or
link, rename, or unlink within the cell.

This is a scoped DAC result, not authentic provider custody. The host still
selects the provider root, the root coordinator remains privileged, and the
campaign does not close capability-bearing administrators, mount/snapshot
writers, same-UID peers, leaked descriptors, provider compromise, or rollback.

## Immutable result and publication leaves

The provider cell reserves fixed leaves:

```text
result.1          immutable first terminal result, possibly UNCERTAIN
publication.1     immutable publication of result version 1
result.2          exact refinement, allowed only after UNCERTAIN result.1
publication.2     immutable publication of result version 2
```

Each append writes one fixed staging leaf with `O_EXCL`, changes it to
owner-read-only, fsyncs the file, performs one
`renameat2(..., RENAME_NOREPLACE)` into the fixed final leaf, then fsyncs the
cell directory. A successful bind followed by directory-sync failure is still
**bound, sync uncertain**. Existing final keys are preserved. A staging residue
fails stop; protocol reconciliation has no cleanup operation.

`publication.1` requires the exact retained `result.1`. `result.2` requires
immutable `result.1 = UNCERTAIN`, exact operation-field equality, and an exact
terminal class. `publication.2` requires exact `result.2` and prior uncertain
`publication.1`. Result and publication record kinds cannot be substituted.
Both versions remain queryable through fixed read-only methods.

## Retained principal defeats

Three new counterexamples are part of the result:

1. a peer running under the provider UID can chmod and mutate the owner file;
2. a writable descriptor opened before `setresuid` remains writable afterward;
3. a root-equivalent actor bypasses owner-only DAC.

These join V1's hard-link alias, already-open writer, and coherent rollback.
Therefore the observed UID wall is not a protected capability, exact descriptor
topology, administration-plane closure, or external floor.

## Proof boundary

Clang, GCC, and Clang ASan/UBSan produce byte-identical canonical outputs. An
independent Python oracle replays twelve V1 cases, seven principal cases, ten
publication cases, and six total retained counterexamples. The process campaign
relies on documented Linux credential, descriptor, rename, and sync contracts.
It does not independently prove the kernel, filesystem recovery, stable media,
physical power loss, provider authentication, independent reopen, or admitted
source-to-binary identity.

## Advancement rule

V2 falsifies two tempting promotions: `0700` is not complete custody, and an
immutable local filename is not stable result truth. Epoch Zero remains open.
O57 still needs an owner-constituted provider with exact descriptor and
administration custody. O59 still needs named stable media, destructive cuts,
rollback conflict, an external monotonic floor, and independently provisioned
reopen.
