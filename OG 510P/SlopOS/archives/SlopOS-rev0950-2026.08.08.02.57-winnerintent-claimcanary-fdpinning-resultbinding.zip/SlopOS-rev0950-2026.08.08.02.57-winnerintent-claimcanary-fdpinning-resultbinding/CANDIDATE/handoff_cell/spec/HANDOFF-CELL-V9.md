# Handoff Cell V9 — owner-pinned provider genesis and signed append observation

## Status

V9 extends, and does not replace, the V8 hosted one-attempt settlement seam. V8 remains the client-side settlement theorem; V9 adds only an owner-pinned, query-only description of one proposed provider history edge. No V9 evidence type is accepted by V8 settlement, V7 endpoint claim, or the payload parser.

This is an Epoch-Zero hosted proof contract. It adds an exact cryptographic
binding from one externally supplied owner pin to one provider-genesis envelope
and one provider-signed append observation. It does **not** constitute an owner,
protect a private key, perform a provider commit, consume a spend, authorize an
effect, settle an operation, select the newest history, survive rollback, prove
stable media, or admit a living service.

V9 is intentionally query-only. Its purpose is to make the missing owner and
provider premises explicit enough that a later protected provider cannot be
silently substituted by cloudtainer-selected response bytes.

## Question

Given:

1. one appraiser-supplied owner Ed25519 public key;
2. one appraiser-supplied exact SHA-256 digest of a canonical owner/provider
   genesis envelope;
3. that exact envelope, signed by the owner key;
4. one canonical append observation, signed by the provider key named in the
   genesis; and
5. one complete expected append relation,

can the candidate prove that the bytes match the pinned statement and both
signatures, while refusing to promote the result into endpoint-parser,
response, spend, commit, or settlement authority?

V9 answers that bounded question only.

## Trusted input boundary

`OwnerGenesisPin` contains exactly:

```text
owner_public_key       32 bytes
exact_genesis_digest   32 bytes (SHA-256 over all 320 encoded genesis bytes)
```

The pin is a premise. In the hosted campaign it is self-selected by the test
actor. Therefore successful verification proves neither owner constitution nor
independent provisioning. A future appraiser must receive or persist the pin
through a separately governed, nonrollback path.

## Canonical owner/provider genesis

The encoded envelope is exactly 320 bytes, all multibyte integers big-endian:

```text
0..7      ASCII "SLOPGEN1"
8..9      version = 1
10..11    kind = 1
12..15    encoded length = 320
16..23    owner_epoch
24..31    provider_epoch
32..63    owner_constitution digest
64..95    provider Ed25519 public key
96..127   provider_subject digest
128..159  provider_image digest
160..191  floor_identity digest
192..223  endpoint_epoch digest
224..255  appraiser Ed25519 public key
256..319  owner Ed25519 signature
```

Every epoch and every 32-byte field must be nonzero. The owner signs the
288-byte message:

```text
32-byte domain "SlopOS/owner-provider-genesis/v1"
|| 256 canonical unsigned genesis bytes
```

The exact envelope digest includes the signature. A digest pin therefore
selects one exact signed representation, while the signature proves only that
the holder of the corresponding owner private key signed its unsigned body.

## Canonical provider append observation

The append envelope is exactly 320 bytes:

```text
0..7      ASCII "SLOPOBS1"
8..9      version = 1
10..11    kind = 2
12..15    encoded length = 320
16..23    owner_epoch
24..31    provider_epoch
32..39    observation_serial
40..47    generation_from
48..55    generation_to = generation_from + 1
56..87    exact genesis digest
88..119   floor_identity digest
120..151  predecessor_head digest
152..183  successor_head digest
184..215  spend_record digest
216..247  pending_entry digest
248..255  canonical zero reservation
256..319  provider Ed25519 signature
```

All identity digests and the serial are nonzero. The provider signs:

```text
32-byte zero-padded domain "SlopOS/provider-append-obsv/v1"
|| 256 canonical unsigned observation bytes
```

The observation binds an expected transition. It is not the transition.

## Verification order

`verify_pinned_provider_append` must perform these gates in order:

```text
canonical genesis decode
-> SHA-256 of exact encoded genesis
-> constant-time exact digest-pin comparison
-> owner Ed25519 verification using only the pinned public key
-> canonical append decode
-> exact genesis digest / owner epoch / provider epoch / floor binding
-> provider Ed25519 verification using only the genesis-named public key
-> exact comparison with every caller-supplied expected append field
-> copyable query-only exact observation
```

Failure at any gate returns a distinct fail-closed disposition. The candidate
library contains no private-key import, key generation, signing, rotation,
revocation, claim, commit, effect, response, or settlement route. Deterministic
private seeds and signing APIs exist only in the harness.

## Type and parser boundary

`ProviderGenesisObservation` is copyable evidence and always carries:

```text
query_only = true
response_authority = false
protected_provider_state = false
globally_unique_spend = false
```

Neither `EndpointClaimCell` nor `PayloadAfterClaim` accepts this observation,
the encoded append, or the pin. The number of endpoint-parser entrypoints from
signed observations is zero. V9 cannot be composed into V7 by passing a boolean
or copyable receipt into the parser.

## Required campaign

The deterministic campaign must retain exactly twenty semantic cases:

- one exact pinned chain;
- wrong owner key and wrong digest pin;
- owner signature and signed-genesis-body mutation with recomputed digest pins;
- an alternate owner-signed genesis rejected by the original exact pin;
- provider signature and signed-body mutation;
- foreign genesis and floor bindings;
- stale generation and foreign successor expectations;
- a signature made by a substituted provider key;
- two exact replay copies;
- two coherent-history copies of the same signed bytes;
- two conflicting successors signed by the same provider key and accepted
  under their respective complete expectations; and
- an alternate owner-signed genesis accepted after explicit repinning.

It must also reject every one-bit mutation of each 320-byte envelope: 2,560
genesis mutations and 2,560 append mutations. An independent oracle checks the
case inventory, source order, private-key exclusion, parser separation, and a
finite refinement relation.

## Positive theorem

For the exact pinned fixture, the hosted candidate establishes:

```text
exact encoded genesis selected by SHA-256 pin
AND owner signature valid over canonical genesis body
AND append bound to that genesis, owner/provider epochs, and floor identity
AND provider signature valid over canonical append body
AND every expected append field equal
```

No stronger meaning follows automatically.

## Governing counterproofs

Five retained defeats bound the theorem:

1. **Self-selected pin.** The hosted actor can choose the owner key and digest,
   so valid verification does not constitute an owner or an appraiser.
2. **Replay.** Identical signed bytes verify repeatedly; a signature is not a
   one-use spend.
3. **Coherent histories.** Copies of the same history verify the same bytes;
   signatures do not select the newest nonrollback history.
4. **Conflicting successors.** One provider key can sign two incompatible
   successors; key possession does not prove compare-and-commit, singleton
   writer custody, or honest provider state.
5. **Alternate geneses.** One owner key can sign multiple genesis statements;
   only exact pinning and a governed rotation/continuity rule select the
   admitted one.

These are specification facts, not future caveats.

## Cryptographic scope

The implementation uses OpenSSL 3 provider APIs, raw public-key construction,
one-shot PureEd25519 verification, and SHA-256. Algorithm correctness and
cryptographic security are relied-on external contracts; the campaign does not
prove OpenSSL, Ed25519, SHA-256, compiler correctness, binary provenance,
side-channel resistance, key protection, entropy, or platform integrity.

## Forbidden promotion

V9 does not prove:

```text
constituted owner or threshold owner continuity
independently provisioned exact pin
protected owner/provider/appraiser private keys
provider executable, process, or writer admission
provider compare-and-commit
one-use or globally unique spend
newestness, anti-rollback, anti-freeze, or stable media
endpoint epoch authenticity
claim, effect, response, or settlement authority
source-to-operated-binary identity
independent reopen
living-law admission
```

## Next admissible construction

Do not add another signature envelope or receipt wrapper. The next accepted cut
must place a complete expected-head compare and pending-entry claim inside an
actually external protected provider, bind the provider commit identity to this
pinned genesis, retain a nonrollback floor across coherent restore, and let an
independently provisioned appraiser distinguish exact current, already spent,
foreign, stale, and bounded-uncertain outcomes. Until then, remain in Epoch
Zero.
