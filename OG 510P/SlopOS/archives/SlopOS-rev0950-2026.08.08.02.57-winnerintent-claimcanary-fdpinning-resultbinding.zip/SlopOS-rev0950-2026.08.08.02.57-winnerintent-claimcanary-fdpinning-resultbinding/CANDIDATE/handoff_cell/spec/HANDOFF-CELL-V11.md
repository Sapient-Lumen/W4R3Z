# Handoff Cell V11 — ordered, write-sealed passive release ingress

V11 retains every V10 nonclaim and inserts one narrow release-byte relation
before any future activation.

## Constructed relation

A host adapter may report an ordered prefix:

1. one supplied locator was opened;
2. the resulting descriptor was retained and named a regular source;
3. the complete source was copied into one private unlinked snapshot;
4. the complete snapshot was write-sealed against content and size mutation;
5. SHA-256 was recomputed from the sealed bytes;
6. the sealed digest was compared with the exact system-pinned release digest;
7. archive semantics consumed only that same sealed object;
8. inventory and required-member hashes were complete; and
9. no extraction or execution crossed the activation boundary.

The relation rejects any downstream fact whose prerequisite prefix is absent.
It therefore distinguishes `OBSERVATION_INCOHERENT`, `SNAPSHOT_UNSEALED`,
`DIGEST_MISMATCH`, `PATH_REOPEN_REJECTED`, `DIGEST_ORDER_REJECTED`,
`ARCHIVE_REJECTED`, and `ACTIVATION_BOUNDARY_VIOLATED` from
`EXACT_PASSIVE_ADMISSION`.

Seventeen retained cases and nine countermodels include an incoherent Boolean
bag, anonymous-but-mutable snapshot, wrong digest after premature parse,
hash-then-reopen, parse-before-digest, digest-only admission, extraction as
admission, execution as admission, and passive-receipt-as-provider-operation.

## Host counterproof

The companion Linux C++20 probe retains 12 cases and 6 counterexamples. It
shows that a pinned descriptor reads the original inode after pathname
replacement while a deliberate reopen reads replacement bytes; duplicated
descriptors share an open-file-description offset; unlink and `fchmod(0400)` do
not revoke an extant writer; and the required memfd seal set makes a retained
writer and grow/shrink attempts fail with `EPERM`.

## Capability boundary

`ReleaseIngressAssessment` is copyable evidence, never a capability. No claim,
settlement, endpoint, or provider API accepts it. Exact passive admission grants
zero activation, provider-operation, cluster, transaction, commit, restore,
currentness, owner, or living-law authority.

## Hosted status

The exact archive remains absent. The operated-profile ladder has not advanced.
V11 proves a hosted relation and counterproofs; it does not fabricate a
successful upstream admission. Epoch Zero remains truthful.
