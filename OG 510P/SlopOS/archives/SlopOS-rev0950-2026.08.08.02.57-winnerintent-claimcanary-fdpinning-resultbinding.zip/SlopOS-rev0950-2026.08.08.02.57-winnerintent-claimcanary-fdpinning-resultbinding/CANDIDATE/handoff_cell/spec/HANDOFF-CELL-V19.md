# Handoff Cell V19 — NV-Extend content chain and cross-ledger fracture gate

## Status

Epoch-Zero hosted proof surface, package-local to `handoff_cell`. It is not a
TPM service, witness daemon, transaction manager, provider, owner membrane, or
living-law surface.

## Why V18 was insufficient

V18 binds one receipt spend in one coherent local history; clones and restored
copies can spend again. A scalar counter supplies order but not winning-content
identity. NV-Extend supplies cumulative content but not expected-predecessor
compare-and-swap.

## Ordered relation

V19 evaluates 58 ordered observations covering:

```text
exact v185 TPM/profile/platform/NV identity
+ SHA-256 TPM_NT_EXTEND public shape
+ implementation capacity for the 288-byte input
+ digest-sized NV dataSize
+ explicit policy, writer, deletion and succession custody
+ exact V18 spend and fresh challenge
+ certified predecessor observation
+ canonical record and exact successor computation
+ at most one extend attempt and certified successor observation
+ witness compare-and-advance receipt over the same edge
+ query-only duplicate, ambiguity and reopen classification
+ restore, replacement and clone-domain premises
```

The full ordered prefix establishes only
`complete_dual_ledger_transcript_bound`. It deliberately returns
`cross_ledger_join_unproved`. `cross_ledger_atomic_join_bound`,
`query_only_cross_ledger_recovery_bound`, `external_rollback_floor_bound`, and
V18 external-floor eligibility remain false.

## Canonical record

The fixed 288-byte record contains version, algorithm, flags, consecutive
edge, and seven 32-byte bindings: profile identity, platform incarnation, NV
Name, predecessor, V18 spend head, fresh challenge, and witness incarnation.
Reserved bytes are zero. The CRC is structural only. Cryptographic identity is
SHA-256 of the complete record; successor is
`SHA-256(predecessor || canonical-record)`.

## The fracture theorem

TPM2_NV_Extend has no expected-old operand. A pre-certification is not an
atomic guard. With two independently mutating ledgers:

```text
TPM first     -> crash -> TPM successor / witness predecessor
witness first -> crash -> TPM predecessor / witness successor
```

Query-only recovery can identify these states but cannot converge them. A
second mutation would need separately constituted repair authority and an
explicit protocol. Reordering the writes merely exchanges the crash cut.

## Current v185 profile facts

The published v185 structures and commands establish that NV-Extend accepts a
`TPM2B_MAX_NV_BUFFER`, whose maximum is TPM-dependent; an EXTEND index is
digest-sized and uses its `nameAlg`; and `TPMA_NV_POLICY_DELETE` selects a
policy-authorized deletion route rather than automatically making the index
undeletable. V19 therefore treats capacity, dataSize, deletion policy, and
writer/succession custody as independent premises.

## Host counterproof

The Linux 6.12.13 host has no TPM device or required tpm2-tools. It issues zero
TPM commands and performs no network fallback. Fixtures reproduce both
cross-ledger crash orders, stale-precertification second extend, two cloned
histories, one restored history, and cloned byte-identical signatures.

## Mandatory zeroes

No archive acquisition, READY, SCM_RIGHTS import, provider operation,
settlement, owner promotion, or living-law transition occurs. Remain in Epoch
Zero.
