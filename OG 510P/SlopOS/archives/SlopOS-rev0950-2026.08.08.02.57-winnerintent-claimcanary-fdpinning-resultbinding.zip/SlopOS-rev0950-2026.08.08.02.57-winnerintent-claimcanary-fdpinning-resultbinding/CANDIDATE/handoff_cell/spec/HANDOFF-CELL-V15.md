# Handoff Cell V15 — data-sealed exec input to held actor epoch

## Correction owned by V15

V14 classifies an externally assembled acquisition-actor dossier. It does not
prove that the process named by that dossier crossed `exec` through the pinned
executable descriptor. Credentials, cgroup coordinates, a pidfd, and a planned
digest can all agree while different bytes are executed. V14 therefore emits
only `ACTOR_PROFILE_ADMISSIBLE`; it never emits V13 actor eligibility by itself.

V15 introduces one pure C++20 ordered relation and one bounded Linux laboratory.
The narrow hosted theorem is **exec-input-object binding**: the successful
`execveat` transition observed in the laboratory completed the exact syscall
entry whose stopped target descriptor referred to the same data-sealed inode
and bytes as the declared fixture.

That theorem is deliberately weaker than “complete process image.” A dynamic
interpreter, shared objects, later executable mappings, JIT output, mutable data,
and future `exec` transitions are not identified merely because the main ELF
input object is identified.

## Ordered relation

`ActorExecObservationV2` contains 49 booleans. The observation is coherent only
as one prefix: after the first false field every later field must remain false.
The order is:

```text
profile supplied
-> executable descriptor supplied
-> executable is regular, readable, unlinked, and size-bounded
-> executable profile SHA-256 exact
-> seal query supported
-> F_SEAL_WRITE, F_SEAL_GROW, F_SEAL_SHRINK, F_SEAL_SEAL present
-> launch child single-threaded
-> launch child file table private through exec
-> launch child address space private through exec
-> challenge endpoint exclusive to the tracee
-> actor pidfd supplied before release
-> tracer established before release
-> PTRACE_O_TRACEEXEC armed before release
-> execveat syscall entry observed
-> syscall architecture exact
-> empty path observed
-> flag word exactly AT_EMPTY_PATH
-> target descriptor number exact
-> exec argument memory stable until the kernel consumes it
-> pidfd_getfd supported
-> target descriptor duplicated while the tracee remains stopped
-> target regular
-> target inode equals the declared sealed executable inode
-> target carries the required data-seal barrier
-> target SHA-256 exact
-> PTRACE_EVENT_EXEC completes that exact pending syscall entry
-> successful exec event observed
-> exactly one exec event in the bounded interval
-> challenge generated only after that event
-> challenge response exact
-> interpreter and runtime-object set independently bound
-> the observed exec epoch held through actor admission
-> pre-exec privilege floor exact
-> pre-exec seccomp filter exact
-> V14 dossier admissible
-> dossier appraised after the bound exec
-> dossier executable digest matches the exec target
-> dossier process coordinate matches the launch
-> dossier runtime-object set matches the launch
-> dossier challenge matches the post-exec epoch
-> dossier launch envelope matches the observed exec
-> dossier privilege and filter facts match the launch
-> dossier inherited-descriptor inventory matches the launch
```

The first 36 premises establish only `EXEC_INPUT_OBJECT_BOUND`. Premise 37 adds
runtime-object-set closure. Premise 38 adds held exec-epoch custody. Premises 39
and 40 add the pre-exec privilege and seccomp floors. The final nine premises
compose that held and confined epoch with an independently evaluated V14
dossier. Only the complete 49-premise synthetic row is
`eligible_for_v13_actor_premise=true`.

Even that result is an admission relation, not a proof of every instruction or
mutable mapping in the running process. `complete_process_image_bound` remains
false by construction.

## Why the extra cuts exist

Single-threadedness does not imply that no `CLONE_FILES` peer exists, so private
file-table custody is separate. A one-thread tracee can still have a helper
holding the challenge endpoint, so channel exclusivity is separate. An exec
event does not identify its input; the exact pending `execveat` entry must be
linked to the event. A matching digest does not prove the same custody object;
inode identity and the data-seal barrier are also required. Conversely, the
four required seals constrain data mutation and size, but do not prove source
provenance, creator identity, every inode metadata field, or all future runtime
objects.

`pidfd_getfd` duplicates access; it is not a move, consumption, or revocation.
`PTRACE_EVENT_EXEC` is a transition observation, not independent appraisal.
A post-exec nonce is bounded liveness, not program identity. One denied syscall
is not an exact seccomp-filter digest. A PT_INTERP pathname names a dependency;
it does not bind the object the loader opened.

## Hosted Linux laboratory

The fixture is intentionally non-production:

1. copy `/proc/self/exe` into a fresh `MFD_EXEC | MFD_ALLOW_SEALING` memfd;
2. complete the copy, add the four data seals, and compute SHA-256;
3. parse the bounded ELF64 program-header table and retain the PT_INTERP path;
4. fork one child with a private file table and one exclusive challenge end;
5. establish ptrace and a pidfd before release;
6. arm `PTRACE_O_TRACEEXEC`, `PTRACE_O_TRACESYSGOOD`, and
   `PTRACE_O_EXITKILL`;
7. stop at the exact x86-64 `execveat(fd, "", ..., AT_EMPTY_PATH)` entry;
8. duplicate the target through `pidfd_getfd` while the child remains stopped;
9. compare regular shape, inode, required seals, size, and complete SHA-256;
10. require the next successful exec event to complete that same pending entry;
11. let the new image enter a small nonroot/no-capability/no-new-privileges
    seccomp laboratory; and
12. issue and verify a fresh challenge only after the exec event.

`PTRACE_O_EXITKILL` and a parent-side kill-and-reap guard are resource-custody
measures for this proof executable. They prevent a failed tracer from leaving a
stray child, but they do not strengthen the actor-identity theorem.

The observed executable is dynamically linked. The host records the absolute
PT_INTERP pathname but binds neither the interpreter object nor the loaded
shared-object set. The actor is not held through V14 appraisal. Exact seccomp
filter extraction and `PIDFD_GET_INFO` also fail on this host. Therefore the
actual result is:

```text
exec_input_object_bound=true
runtime_object_set_bound=false
exec_epoch_held=false
complete_process_image_bound=false
V14_dossier_admissible=false
V13_actor_premise=false
production_network_acquisition_initiated=false
network_syscalls_audited=false
READY_sent=false
rights_imported=0
candidate_bytes_read=0
archive_body_bytes=0
authority=false
```

## Retained proofwork

The pure relation retains 51 cases and 32 countermodels: one row for every
ordered cut, one incoherent observation, and one complete synthetic
composition. Fourteen coherent prefixes have the narrow exec-input witness,
thirteen also have synthetic runtime closure, twelve also have synthetic
held-epoch custody, ten also satisfy the synthetic pre-exec floor, and exactly
one complete synthetic row reaches V13 eligibility.

The Linux laboratory retains 62 cases and 29 countermodels. It positively
establishes only the exec-input-object mechanism and bounded cleanup. It
retains negative observations for runtime-object closure, held-epoch custody,
pre-exec privilege floor, exact filter reconstruction, `PIDFD_GET_INFO`,
independent appraisal, V14 composition, network audit, READY, rights, candidate
bytes, archive bytes, and authority.

Clang, GCC, and Clang ASan/UBSan must independently reconstruct byte-identical
normalized products before the revision may close. Retained binaries are
forbidden.

## Nonclaims

V15 does not prove source-to-binary correspondence, release provenance,
interpreter or dependency identity, full executable-mode metadata custody,
complete process-image identity, uninterrupted future behavior, exact seccomp,
root independence, one-use transfer, archive admission, provider operation,
protected settlement, owner constitution, or living law.

Remain in Epoch Zero.
