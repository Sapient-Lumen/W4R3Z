# Handoff cell v3 — exact hosted launch and fixed query cut

**Status:** Epoch-Zero hosted Linux construction; nonauthoritative.  
**Obligations narrowed:** O57 descriptor/query custody and the local query edge of O59.  
**Authority granted:** none.

V3 retains every V1 and V2 case. It adds no state-machine family and does not
promote `PrincipalCell` to a product provider. The new cut asks a smaller and
more falsifiable question: can one root-owned laboratory launcher construct two
post-exec processes with exact descriptor and credential floors, then expose
only one fixed read-only result query while retaining the failures that prevent
that arrangement from becoming authentic custody?

## Constructed process tables

The launcher opens its current ELF image with `O_PATH`, duplicates the intended
objects to fixed descriptors, closes the ambient suffix with
`close_range(..., CLOSE_RANGE_UNSHARE)`, drops the capability bounding set,
supplementary groups, real/effective/saved UID and GID, and sets
`PR_SET_NO_NEW_PRIVS`. It then executes the already-open image with
`execveat(..., AT_EMPTY_PATH)`.

The provider's observed post-exec table is exactly:

```text
0,1,2  inert /dev/null standard descriptors
4      fixed provider-root directory
5      fixed SOCK_SEQPACKET query channel
6      fixed report channel used only by the laboratory oracle
```

Descriptor 3 holds the executable before exec and is `CLOEXEC`; it must be
absent afterward. No descriptor at or above 7 may remain. The query actor's
table is identical except that descriptor 4 is absent. `/proc/self/fd` census is
a hosted observation, not a release measurement mechanism.

The retained off-by-one control closes from descriptor 8 and proves that
undeclared descriptor 7 survives. Exactness therefore depends on the declared
cut point, not generic close-on-exec folklore.

## Credential evidence and its trap

The socketpair is intentionally created before either child drops privilege.
`SO_PEERCRED` consequently reports the credentials in effect at
`socketpair(2)`: the root launcher, not the current post-drop peer. That result
is a retained counterexample.

Both endpoints enable `SO_PASSCRED`. Every accepted packet must carry exactly
one kernel-supplied `SCM_CREDENTIALS` item with the expected current UID and
GID. The hosted positive run observes provider UID/GID 21001 and query UID/GID
21003; UID/GID 21002 is rejected even with exact request bytes. An
unprivileged query actor's attempt to claim provider credentials fails with
`EPERM` on the recorded kernel.

This is not provider authentication. Linux permits appropriately privileged
senders to specify credential fields they could not claim unprivileged. The
root launcher selected the executable, root descriptor, socketpair, UID map,
and lifecycle. V3 neither closes nor authenticates that administration plane.

## Ancillary authority precedes payload meaning

A query packet can carry `SCM_RIGHTS`. Receipt installs a reference to an open
file description in the provider's descriptor table before application payload
validation. V3 therefore treats ancillary data as authority, not metadata:

1. receive with a bounded control buffer and `MSG_CMSG_CLOEXEC`;
2. require exactly one credentials item;
3. reject control truncation, unknown control items, or any received rights;
4. close every received descriptor;
5. re-census the table; and only then
6. interpret request bytes.

The campaign deliberately injects one descriptor, observes it, closes it,
restores the exact table, and returns a rights-rejection response. The defeat is
retained even though the implementation handles it correctly.

## Fixed result query

`FixedResultQuery` accepts only one already-open provider-root descriptor and
one expected provider UID. It accepts no path, cell name, version, route,
operation, retry, cleanup, publication, repair, or mutation choice. It opens
fixed child `cell`, then fixed leaves `pending` and `result.2`, with no symlink
following and read-only flags. It requires:

- provider-owned mode-0700 root and cell directories;
- regular owner-read-only records of exactly 128 bytes and link count one;
- canonical decode;
- `pending` sequence 1 with no result;
- terminal non-`UNCERTAIN` `result.2` sequence 2; and
- exact operation-field equality between pending and result.

The provider returns the exact encoded `result.2` over the fixed channel. The
query actor cannot select a different object or request a write. A malformed
packet, wrong principal, control surplus, and silent actor fail stop. Silence is
bounded at 250 ms in the hosted campaign and grants no retry or repair power.

## Proof and evidence boundary

Clang, GCC, and Clang ASan/UBSan must independently produce byte-identical
canonical campaign products. The Python oracle checks the old handoff,
principal, and publication cases plus fifteen launch/query cases and three new
counterexamples. A small finite refinement check distinguishes the intended
post-exec descriptor sets from the off-by-one set and distinguishes
creation-time peer credentials from message-time sender credentials.

The campaign relies on Linux `close_range`, `execveat`, Unix-domain ancillary
message, credential, capability, and filesystem contracts. It does not prove
the kernel, `/proc`, ELF admission, source-to-binary identity, namespace or
mount custody, signal/ptrace/cgroup/lifecycle administration, provider
availability, stable media, physical power loss, rollback resistance, an
external floor, independent reopen, or an independent actor.

## Advancement rule

V3 closes no Epoch-Zero gate. It replaces vague “exact descriptor topology”
debt with one observed table and three sharper open boundaries:

```text
hosted exact table != authenticated launch
current-message UID != closed administration plane
fixed read-only result query != durable authoritative result service
```

The next construction must constitute the launcher/provider boundary from an
owner-named external environment, enumerate and challenge all administrative
writers, admit the executable identity, and reopen a result from separately
rooted custody. Another local framework is waste.
