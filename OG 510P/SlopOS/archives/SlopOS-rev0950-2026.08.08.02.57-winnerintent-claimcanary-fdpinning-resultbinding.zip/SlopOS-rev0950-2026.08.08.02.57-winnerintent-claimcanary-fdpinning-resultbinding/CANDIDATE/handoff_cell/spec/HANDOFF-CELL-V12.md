# Handoff Cell V12 — descriptor-rooted regular-only release location

V12 adds one authority-negative locator prefix before V11 byte capture. It does
not replace V11 and it does not compose older handoff strata into authority.

## Accepted premise

The caller supplies one already-open Linux directory descriptor. Candidate
acquisition requires this ordered prefix:

1. duplicate the descriptor close-on-exec;
2. observe `O_PATH`, directory shape, effective-UID ownership and mode `0700`;
3. accept no caller pathname and no caller-selected leaf;
4. use exactly `etcd-v3.6.14-linux-amd64.tar.gz`;
5. call `openat2` with a zero-initialized `open_how` and
   `BENEATH|NO_SYMLINKS|NO_MAGICLINKS|NO_XDEV`;
6. include Linux `OPENAT2_REGULAR` in that same open operation;
7. treat post-open regular/same-device `fstat` only as a kernel-contract check;
8. reobserve root object and endpoint profile without claiming continuity; and
9. export no raw descriptor number.

Missing or unsupported policy is a stop. There is no `openat`, path reopen,
`/proc/self/fd` reconstruction, open-then-`fstat` fallback or weaker retry.

## Why file type belongs in the open

Opening first can already cross special-object semantics. The retained legacy
fixture opens a FIFO successfully with `O_NONBLOCK` before later `fstat`
rejection. Closing that descriptor does not prove the open harmless. Therefore
`regular_only_open_enforced` is an independent premise and
`post_open_shape_is_contract_check_only` remains true.

The consulted `OPENAT2_REGULAR` contract is pinned to Linux v7.2-rc5. The
retained Linux 6.12.13 host rejects the bit with `EINVAL`; production stops
before candidate acquisition. Final stable UAPI and target-host behavior must
be revalidated before any activation work.

## Pure relation

`RootedReleaseObservationV1` and `assess_rooted_release` model the prefix without
syscalls. Twenty-four cases and eleven countermodels distinguish missing
premises, non-`O_PATH` roots, profile rejection, unavailable resolution or
regular-only policy, a kernel contract violation, root/path/profile drift,
prohibited reopen and future supporting-host readiness.

Exactly two descriptor-ready rows are synthetic observations with the
regular-only premise set. They prove relation behavior, not that this host can
produce a candidate descriptor.

Countermodels reject these collapses:

```text
tail O_NOFOLLOW == all-component confinement
reopening a root pathname == using the pinned root object
successful duplication == retained identity
private host metadata == constituted owner custody
equal endpoint samples == continuous profile custody
open then fstat == harmless regular-only acquisition
post-open regular shape == proof the open had no prior effects
rooted regular file == immutable content or upstream provenance
complete policy == exact release digest admission
synthetic ready relation row == actual host readiness
candidate descriptor == activation or provider authority
```

## Host counterproof

The Linux C++20 probe retains twenty-one cases and eleven counterexamples. It
observes the complete resolution mask, rejects widened ancestor traversal,
retains visible-root replacement and profile ABA, reproduces mutable rooted
content, confirms `OPENAT2_REGULAR` is unsupported on this host, and proves the
former flags can open a FIFO before shape rejection. Production candidate
readiness is false and no archive payload is executed.

## Required downstream stage

On a supporting host, a descriptor-ready V12 result would still be mutable
content. V11 remains mandatory: complete `pread` capture into one private
unlinked sealable memfd; write/grow/shrink/seal barrier; digest recomputation
from sealed bytes; exact comparison; then passive archive semantics on the same
object. No extraction, execution, provider call or authority follows.

## Capability boundary

Rooted confinement, regular-only opening, a private mode, same-device shape and
sealed bytes do not establish upstream provenance, independently protected
custody, owner constitution, stable media, rollback resistance, safe activation,
cluster operation, provider commit, external currentness, settlement or living
law. Epoch Zero remains truthful.
