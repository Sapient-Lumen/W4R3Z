# Handoff cell v4 — staged provider bind and no-replace endpoint publication

**Status:** Epoch-Zero hosted Linux construction; nonauthoritative.  
**Obligations narrowed:** O57 endpoint/descriptor custody and the fixed query edge of O59.  
**Authority granted:** none.

V4 retains every V1, V2, and V3 case. It adds no state-machine family and does
not promote `ProviderEndpoint` or the root publisher to product roles. The new
cut tests whether socket construction, public-name publication, and later query
connection can be separated strongly enough to expose—rather than hide—the
remaining endpoint-epoch administration problem.

## Defect corrected

The proposed V3 successor said: “enter the final provider principal, then bind
the fixed public endpoint.” That statement is insufficient. A same-UID restart
with write/search authority over the pathname's parent can unlink a live or
stale socket name and bind a distinct listener at the same leaf. Existing
connections and the old listener descriptor may survive while new path lookups
reach the replacement.

V4 therefore separates:

```text
provider constructs listener inode
publisher publishes public name
query actor constructs later connection
recovery authority eventually retires stale name (not implemented)
```

## Fixed objects and principals

The hosted campaign uses:

```text
provider uid/gid  21001/21001
wrong query uid   21002
query uid/gid     21003/21003
publisher uid     0
stage leaf        bound.sock
public leaf       query.sock
```

The provider owns a private mode-0700 staging directory. The publisher owns a
mode-0711 public directory. The listener inode is provider-owned mode 0222.
Mode 0222 permits the intended pathname connection on the recorded Linux host;
it is a reachability relation, not query authorization. The provider accepts
only the fixed query UID after inspecting the accepted connection's peer.

## Provider bind cut

The provider is exec-entered with exactly:

```text
0,1,2  inert standard descriptors
4      fixed provider-root directory
5      fixed provider-owned staging directory
6      laboratory report channel
```

It inherits no query data socket. After verifying final UID/GID, no
supplementary groups, empty capability sets, `no_new_privs`, descriptor/path
identity, staging owner/mode, and fixed-leaf absence, it creates a Linux
`AF_UNIX/SOCK_SEQPACKET` listener at `bound.sock`.

`ProviderEndpoint::bind_fixed_stage` accepts no path or cleanup choice. It does
not call unlink, retry, or repair. Collision fails.

## No-replace publication cut

A distinct publisher holds descriptors for the staging and public parents. It
verifies their custody and calls exactly:

```text
renameat2(stage_fd, "bound.sock",
          public_fd, "query.sock",
          RENAME_NOREPLACE)
```

It verifies that `query.sock` names the same device/inode previously named by
`bound.sock` and that the staged name is absent. The provider retains the
listening descriptor while the pathname moves. On the recorded Linux/ext4
host, the listener accepts a connection through the renamed public path.

A pre-existing `query.sock` returns `EEXIST`. The candidate does not unlink it,
retry, choose another name, or infer whether it is live, stale, authentic, or
safe to retire.

## Later query connection

The query actor is exec-entered with exactly:

```text
0,1,2  inert standard descriptors
5      fixed publisher-owned public-directory descriptor
6      laboratory report channel
```

It inherits no query data socket. It verifies its final principal and the
public parent, creates its own `SOCK_SEQPACKET` socket, and connects only to the
fixed `query.sock`. It observes the provider coordinate with `SO_PEERCRED`; the
provider observes the query coordinate on the accepted socket. Request and
response `SCM_CREDENTIALS` agree with those coordinates in the retained run.

This is a Linux host observation. V4 does not use `SO_PEERCRED` as a persistent
provider-epoch token, and it does not claim the current documentation provides a
portable `SOCK_SEQPACKET` identity theorem.

## Query and ancillary safety retained

The V3 authority-first receive order remains mandatory. Received
`SCM_RIGHTS` are closed and rejected before request bytes are interpreted.
Missing, duplicate, unknown, malformed, or truncated control fails closed. A
wrong ordinary UID can reach the public socket but is closed immediately after
accepted-peer inspection. `FixedResultQuery` still reads only fixed
`cell/pending` and immutable `cell/result.2` and accepts no path, route, version,
apply, retry, cleanup, publication, or repair input.

## Stale endpoint fixed point

Closing the provider/listener leaves the public pathname. A later connection
returns a visible failure on the retained host. A fresh provider can bind a new
private `bound.sock`, but no-replace publication remains blocked by the stale
`query.sock`:

```text
STALE(public=L1) + STAGED(private=L2)
  -- publish_noreplace --> EEXIST, both preserved
```

That fixed point is intentional. Automatic unlink would erase evidence and
silently grant provider startup authority to select a successor endpoint epoch.
Retirement and cleanup belong to a separately constituted recovery/admin role.

## Counterexamples retained

V4 adds three first-class defeats:

1. a same-UID restart replaces a live pathname in a provider-writable public
   directory;
2. a stale public leaf requires separate recovery authority rather than
   unlink-before-bind; and
3. the root publisher can explicitly unlink and republish, proving the hosted
   administration plane remains dominant.

All V1–V3 defeats remain, including hard-link alias, open writer, coherent
rollback, same-UID file mutation, inherited writable descriptor, root DAC
bypass, creation-time peer confusion, ancillary-right transfer, and off-by-one
close-range topology.

## Proof and evidence boundary

The campaign emits twenty-two endpoint-publication cases and three new
counterexamples. The independent Python oracle models both the unsafe
provider-owned public directory and the split-custody no-replace relation. It
requires stale collision to be a fixed point and records the publisher cleanup
transition as open authority.

Clang, GCC, and Clang ASan/UBSan must independently produce byte-identical
canonical products. Source manifests cover the transparent package and three
fixed generation-journal codec dependencies. The campaign relies on Linux
pathname Unix-socket, procfs descriptor-path, `renameat2`, credential, DAC, and
filesystem contracts. It does not prove the kernel, source-to-binary identity,
mount/snapshot custody, signal/ptrace/lifecycle closure, stable media, physical
power loss, rollback resistance, external newestness, or independent custody.

## Advancement rule

V4 closes no Epoch-Zero gate. It establishes only:

```text
final-principal staged bind
  + separate no-replace public-name publication
  + later noninherited query connection
  + explicit stale collision
```

It does not establish:

```text
stable endpoint epoch
closed publisher/recovery administration
owner-authenticated provider
independently rooted query actor
durable authoritative result service
```

The next admissible construction is an owner-named external provider experiment
with explicit constructor, name-publisher, retirement/recovery, appraiser, and
administrator authorities. Another local endpoint manager, cleanup daemon, or
retry framework is waste.
