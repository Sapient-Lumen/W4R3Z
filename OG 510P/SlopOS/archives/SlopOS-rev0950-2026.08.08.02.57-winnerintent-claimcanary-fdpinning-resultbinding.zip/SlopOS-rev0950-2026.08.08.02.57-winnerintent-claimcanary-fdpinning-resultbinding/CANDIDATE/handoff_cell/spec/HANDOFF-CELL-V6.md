# Handoff cell v6 — sealed expected-process capsule, burned before connect

**Status:** Epoch-Zero hosted Linux construction; nonauthoritative.  
**Obligations narrowed:** the process-expectation edge of O57 and O62.  
**Authority granted:** none.

V6 retains every V1–V5 relation and counterexample. It adds one bounded seam to
the existing handoff vertical rather than a fourth state machine:

> A query actor may proceed to the fixed endpoint only after importing an
> externally supplied, sealed expectation for one exact provider process;
> the expectation descriptors are consumed before socket creation, and the
> process reached by the new connection must equal the consumed expectation
> before any request byte is sent.

This is an **expected-process gate**, not owner admission. The hosted root still
constructs the process, pidfd, record, binding bytes, and delivery path. V6
therefore proves an interface and ordering law while retaining the decisive
counterproof that immutable self-assertion is not provenance.

## Fixed capsule

The capsule has two close-on-exec descriptors:

```text
record fd   -> unlinked 96-byte regular memfd with exact seals
process fd  -> live pidfd whose pidfs identity equals the record
```

The record is canonical little-endian bytes:

| Offset | Bytes | Field | Rule |
|---:|---:|---|---|
| 0 | 8 | magic | ASCII `SLOPEXP1` |
| 8 | 4 | version | `1` |
| 12 | 4 | reserved | zero |
| 16 | 8 | serial | nonzero |
| 24 | 4 | provider UID | exact nonzero expected UID |
| 28 | 4 | provider GID | exact expected GID |
| 32 | 4 | query UID | exact nonzero current UID |
| 36 | 4 | query GID | exact current GID |
| 40 | 8 | pidfs device | nonzero |
| 48 | 8 | pidfs inode | nonzero |
| 56 | 32 | opaque owner binding | at least one nonzero byte |
| 88 | 8 | reserved | zero |

The opaque binding is deliberately uninterpreted. Its only current function is
to reserve a stable byte field for a future owner-rooted constructor. V6 does
not authenticate it, assign it a signature algorithm, or allow it to name its
own trust root.

## Import law

`ExpectedProviderProcess::adopt_sealed()` takes ownership of both descriptors on
success and failure. The actor must already be the addressed query principal.
Import requires:

- distinct valid descriptors with `FD_CLOEXEC`;
- an unlinked regular record with exact size 96;
- exactly `F_SEAL_SEAL | F_SEAL_SHRINK | F_SEAL_GROW | F_SEAL_WRITE`;
- canonical magic, version, reserved bytes, principals, serial, process
  identity, and nonempty opaque binding;
- a pidfd-shaped descriptor accepted by `pidfd_send_signal(..., 0, ...)`; and
- a nonterminal pidfd whose `fstat(2)` device/inode equals the record.

On the admitted 64-bit Linux profile, the pidfs source states that comparing
inode numbers compares pidfds for the same process. That host-specific relation
is not serialized across reboot and is not promoted into a portable identity.

Import proves only that the actor received an immutable record and a matching
live process reference. It does not prove who observed, minted, signed,
delivered, or retained the pair.

## Burn-before-connect law

The public connect helper accepts the move-only expectation by value. Before it
creates the AF_UNIX data socket it:

1. copies only the serial and expected pidfs identity into inert values;
2. closes the record fd;
3. closes the supplied pidfd;
4. marks the wrapper spent; and only then
5. invokes the existing fixed-path connection.

The resulting `SO_PEERPIDFD` identity must equal the consumed expectation. On
mismatch the newly connected socket and its hidden peer pidfd are destroyed
before a request can be sent. No supplied or observed pidfd is returned through
the public result object.

This ordering removes the expectation descriptors' signal, namespace,
`pidfd_getfd`, and duplication surfaces from the query actor before transport
effects begin. It does not erase copies held elsewhere.

## Descriptor topology

The valid query's exact post-exec, preconnect descriptor table is:

```text
0 stdin
1 stdout
2 stderr
5 public directory
6 report socket
7 sealed expectation record
8 expected provider pidfd
```

Descriptor 3, the executable image, is closed by exec. Descriptor 4, the
provider-root handle, is absent. Descriptor 9 and above are closed by the
launcher. After the expectation burn and successful connect, the exact table is
again seven descriptors: the five base descriptors plus the data socket and the
connection's private peer pidfd. The expectation pair is absent.

## Positive relation

The V6 hosted success relation is:

```text
sealed record R names process P
pidfd D refers to P
query Q is addressed by R
Q imports R+D after exec
Q closes R+D before creating a data socket
fresh fixed-path connection reaches P
message-time pidfds continue to agree with P
fixed exact result is returned
```

This is stronger than V5's post-connect observation: the connection is now
conditioned on an external expected process. It remains weaker than an admitted
provider epoch because the root harness supplies every premise.

## Two retained defeats

### Sealed self-assertion

The root harness creates P, opens its pidfd, writes arbitrary opaque binding
bytes, applies the exact seals, and supplies the pair. The query correctly
accepts the pair and reaches P. This demonstrates:

```text
immutable bytes + matching process
  != independent provenance
  != owner authorization
```

Seals prevent later mutation of an inode. They do not identify the writer or
ratify the writer's policy.

### Actor-local burn is not global spend

Before delivery, the harness duplicates both the record fd and pidfd with
`F_DUPFD_CLOEXEC`. The duplicates refer to the same sealed inode and process.
The query closes its own copies, but the harness's copies remain usable. Thus:

```text
move-only C++ wrapper + close-before-connect
  == actor-local consumption
  != globally unique one-use admission
```

Global one-use needs protected nonduplicable constructor state and a durable,
queryable spend receipt outside the actor that performs the effect.

## Why no more identity observations should be added now

The remaining gap is not another PID-shaped datum. It is custody of the fact
that P is the process an owner admitted. A valid next cut must originate the
expectation from an independently protected constructor that binds at least:

```text
owner constitution and key epoch
admitted executable and dependency identity
final principal and exact descriptor/capability floor
machine, service, boot, and namespace incarnation
public endpoint publication receipt
exact process reference
retirement and authorized successor relation
spend identity and durable spent state
independently rooted appraiser
```

More local registries, process metadata, or mutable endpoint tables before that
constructor would increase code while leaving the governing theorem false.

## Contemporary Linux speculation, not a dependency

A July 2026 Linux RFC proposes taskless future pidfds and a pidfd-based spawn
builder whose first authorized run claims the builder before copying payload.
That shape is relevant because it joins process construction and stable pidfs
identity earlier than `pidfd_open()` after launch. It is not merged target law,
is source-based in its first version, inherits substantial caller state, and
does not constitute SlopOS owners, executable dependencies, endpoint
publication, durable spend, or independent appraisal. V6 records the direction
without depending on the RFC or widening the current Linux 6.12 profile.

## Evidence

The endpoint campaign now contains 35 cases and seven endpoint counterexamples.
The independent oracle retains 16 total custody counterexamples, models two
capsule copies before spend, requires exact connected-process agreement, and
sets all of these to false:

```text
expectation_constructor_protected
globally_unique_expectation_spend_proved
owner_admitted_provider_process
```

Clang, GCC, and Clang ASan/UBSan must independently produce byte-identical
canonical products. V6 is hosted proof shape only: no stable-media theorem,
source-to-operated-binary proof, release authority, or epoch advance follows.
