# Handoff Cell V14 — acquisition-actor admission dossier

> **Rev0903 correction.** A positive V14 dossier does not bind the actual
> post-`exec` process image to the pinned executable object. V14 therefore
> never establishes V13 actor eligibility by itself. Handoff Cell V15 owns the
> required launch-image and dossier cross-binding.

V14 fills one premise that V13 deliberately left external: whether one exact
process coordinate is eligible to act as the acquisition actor *before* READY
and before any rights-bearing receive. It is a pure classifier plus a negative
Linux host probe. It is not a launcher, downloader, appraiser service, broker,
release admission, activation path, provider, owner, or living office.

## Ordered dossier

A dossier is coherent only as one ordered prefix. Once a premise is absent, no
later observation may be used to compensate for it:

```text
profile supplied
-> executable descriptor pinned
-> executable SHA-256 exact
-> dependency manifest exact
-> argv, environment, cwd and umask exact
-> non-root uid and gid
-> supplementary groups empty
-> effective/permitted/inheritable/ambient capabilities empty
-> no_new_privs enabled
-> exact admitted seccomp filter
-> inherited descriptor inventory exact
-> fixed HTTPS source, exact host and no proxy inputs
-> fixed egress policy
-> bounded timeout
-> retry budget zero
-> complete administration inventory
-> receiver-before-candidate lifecycle policy
-> unlinked sealable output only
-> completion before sealing
-> F_SEAL_WRITE|F_SEAL_GROW|F_SEAL_SHRINK|F_SEAL_SEAL required
-> actor pidfd supplied
-> PIDFD_GET_INFO supported
-> PID and credential result bits present
-> pid/tgid/euid/egid/cgroup coordinate matches the dossier and V13 peer
-> independent appraiser profile supplied
-> appraiser root distinct
-> appraiser reconstructs the exact dossier
-> one exact challenge passes
```

A positive result is only `ACTOR_PROFILE_ADMISSIBLE`: the dossier is internally
complete. It cannot satisfy V13 by itself because credentials, cgroup and pidfd
coordinates do not identify which executable object crossed `exec`. V15 must
add the sealed-object launch witness and exact digest/pidfd cross-binding. It sends no READY, imports no `SCM_RIGHTS`, creates no candidate,
reads no release byte, and proves no archive, provenance, owner, or living law.

## Why pidfd is insufficient

A pidfd is a race-resistant process reference. Its integer descriptor number is
process-local. Equal pidfs device/inode observations identify one hosted
coordinate at two observation points; they are not policy admission,
executable identity, uninterrupted custody, or owner constitution.

Linux 6.13 introduced `PIDFD_GET_INFO`. Version-zero is 64 bytes. Userspace must
inspect the returned mask before using PID or credential fields. The UAPI also
states that a successful result was correct when the kernel performed the work
but may already be stale if the process exits. V14 therefore treats the ioctl
as one required query coordinate, not as governance or continuity.

No `/proc/<pid>` parser, pidfd inode comparison, pathname, numeric PID, or
process transcript is a production fallback for the required query. A target
without the admitted ioctl fails before READY.

## Hosted stop

The retained host probe observes Linux 6.12.13, effective uid/gid zero,
non-empty supplementary group state, nonzero effective capabilities,
`NoNewPrivs: 0`, and `Seccomp: 0`. `pidfd_open` succeeds and repeated opens for
one live child report the same pidfs inode, but the Linux 6.13
`PIDFD_GET_INFO` request is unavailable (`EINVAL` on this host). No independent
appraiser exists.

The honest production result is therefore:

```text
HOST_ACTOR_PROFILE_ADMISSIBLE=false
network_attempted=false
READY_sent=false
rights_imported=0
candidate_created=false
candidate_bytes_read=0
archive_body_bytes=0
authority=false
```

Root access is not accepted as an operator shortcut. Ambient privilege is a
larger unclosed administration surface and causes rejection.

## Retained proofwork

The pure C++20 relation retains 28 cases and 18 countermodels. There is one
synthetic exact dossier, zero host-applicable dossiers, zero V14-only V13-eligible
dossiers, one incoherent ordered prefix, and one row for every fail-closed
disposition. Every row retains all
acquisition and authority side effects false.

The standalone Linux probe retains 22 cases and 12 countermodels. It creates
only a blocked child and two pidfds, performs no network operation, sends no
READY frame, receives no rights, creates no release candidate, and retains no
archive-body bytes.

## Composition boundary

V14 does not weaken V13 or V11. V13 still requires the receiver to have zero
candidate-specific aliases before READY and validates the exact offer envelope.
V11 still recaptures the complete body into a fresh private sealable object,
installs the full seal barrier, recomputes and compares the pinned SHA-256, and
performs passive archive interpretation only on those same sealed bytes.

No positive actor, archive receipt, release provenance, extraction, execution,
etcd operation, provider commit, protected settlement, owner constitution, or
living law is established. Remain in Epoch Zero.
