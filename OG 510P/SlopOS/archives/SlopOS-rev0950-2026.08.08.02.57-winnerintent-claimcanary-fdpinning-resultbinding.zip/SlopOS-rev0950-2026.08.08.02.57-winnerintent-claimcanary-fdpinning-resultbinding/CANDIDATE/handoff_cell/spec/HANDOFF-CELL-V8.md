# Handoff Cell V8 — hosted one-attempt settlement

## Status

```text
EPOCH_ZERO / HOSTED-CANDIDATE / NONAUTHORITATIVE
```

V8 is a client-side proof instrument inside the existing `handoff_cell`
semantic island. It does not admit a cloud provider, protect provider state,
authenticate an operator, make media nonrollback, perform an owner-authorized
effect, or grant a response authority.

## Question

Given the V7 local claim-before-parse witness, what is the smallest settlement
surface that preserves the result trilemma and cannot manufacture a first
submission during reopen?

The answer is deliberately narrower than “exactly once”:

```text
fresh exact local claim
  -> burn claim before request meaning
  -> for an exact request, make one provider submit call
  -> classify an exact bound terminal record
  -> otherwise preserve uncertainty

reopen / recovery
  -> query one exact operation identity
  -> never submit
  -> refine only from exact provider evidence
  -> never turn uncertainty into retry permission
```

## Fixed identities

The operation identity is the exact 128-byte generation-journal pending record.
A result is bound only when its generations, operation binding, and spent-
receipt binding match that pending record and its record kind is `result`.

Request meaning remains the fixed 96-byte endpoint request inherited from V7.
`PayloadAfterClaim::parse_exact_impl` consumes `ClaimedPending` before checking
request length, magic, version, generations, or bindings. It may privately
return the consumed pending bytes to `HostedSettlement`; no public ticket,
resubmit token, or provider handle is minted.

## Provider premise

`HostedSettlementProvider` has exactly two virtual observations:

```text
submit_exact(expected_pending) -> submit reply
query_exact(expected_pending)  -> query reply
```

The interface is a host-selected premise. It says nothing about who created the
provider, who can write or restore it, whether two handles name one history,
how long deduplication persists, whether query is linearized, or whether an
administrator can clone, reset, migrate, or replace it.

The submit reply classes are:

```text
EXACT_RECORD | NO_RETURN | UNAVAILABLE | MALFORMED_RETURN
```

The query reply classes are:

```text
EXACT_RECORD | EXACT_UNUSED | UNAVAILABLE | MALFORMED_RETURN
```

`EXACT_UNUSED` means no-effect only under the hosted provider contract: the
query must be exact, authoritative for the named operation identity, and
linearized over the same provider history. V8 does not establish those
premises for a real provider.

## Transition relation

Let local claim state be `FRESH` or `SPENT`. Let hosted provider state be one of
`UNUSED`, `EFFECT`, `NO_EFFECT`, `UNCERTAIN`, or `FAIL_STOP`.

### Submission entry

```text
settle_exact(FRESH, malformed_request):
  local := SPENT
  provider_submit_calls := 0
  result := MALFORMED_REQUEST

settle_exact(FRESH, exact_request):
  local := SPENT
  provider_submit_calls := 1
  exact bound EFFECT record     -> EFFECT
  exact bound NO_EFFECT record  -> NO_EFFECT
  exact bound UNCERTAIN record  -> UNCERTAIN
  exact bound FAIL_STOP record  -> FAIL_STOP
  no return / unavailable       -> UNCERTAIN
  malformed / foreign result    -> UNCERTAIN

settle_exact(SPENT, any_request):
  provider_submit_calls := 0
  result := CLAIM_MISSING_OR_SPENT
```

There is one `provider.submit_exact` callsite in this entry and no loop, query,
retry, compensation, reverse claim, or recovery branch.

### Reconciliation entry

```text
reconcile_exact(invalid_pending):
  provider_query_calls := 0
  result := FAIL_STOP

reconcile_exact(exact_pending):
  provider_query_calls := 1
  provider_submit_calls := 0
  exact bound terminal record -> matching result
  exact unused                -> NO_EFFECT
  unavailable / malformed     -> UNCERTAIN
  foreign record              -> UNCERTAIN
```

Reconciliation cannot create a first dispatch. An exact-unused observation
never restores `ClaimedPending` and never grants permission to submit later.

## Lemmas retained by source shape and campaign

### L8.1 — consume before meaning

The claim is consumed before request meaning. A malformed request therefore
burns the local witness and produces zero provider calls.

### L8.2 — one-attempt entry

For one invocation with one fresh witness and an exact request, the source has
one provider-submit callsite and no retry-capable loop. A second use of the same
moved-from witness produces no provider call.

This is an entrypoint theorem, not global provider deduplication.

### L8.3 — nonreturn is not denial

No return, provider unavailability, malformed return, or foreign exact-record
bytes may follow an effect. Each maps to `UNCERTAIN`, never `NO_EFFECT` and
never retry permission.

### L8.4 — recovery is query-only

The recovery function has one query callsite and zero submit callsites. Exact
query evidence may refine uncertainty; it cannot mint first dispatch.

### L8.5 — observations are powerless

`SettlementObservation` is copyable and always has:

```text
query_only=true
response_authority=false
retry_authority=false
```

Copying an effect observation cannot submit, apply, publish, compensate, or
claim again.

### L8.6 — one shared scripted history can deduplicate

Sixteen coherent local directory histories each obtain one fresh local claim
and each call the same thread-safe scripted provider once. The retained run
observes:

```text
local fresh claims          16
provider submissions        16
provider fresh commits       1
provider duplicate replies  15
effects                       1
settled effect observations 16
```

This demonstrates the needed provider relation when supplied as a premise. It
does not prove the premise exists outside the harness.

## Scheduled process-death cuts

The campaign forks after a local claim and kills the child at four exact cuts.
The provider state is shared independently of the child process.

```text
after claim, before submit               -> exact-unused -> NO_EFFECT
after effect commit, before reply        -> exact result -> EFFECT
after no-effect commit, before reply     -> exact result -> NO_EFFECT
after uncertain commit, before reply     -> exact result -> UNCERTAIN
```

All reopen paths first observe `ALREADY_CLAIMED_EXACT`, call only
`reconcile_exact`, and carry no retry authority.

## Governing countermodels

1. **Malformed return after committed effect.** Response parse failure cannot be
   flattened to no-effect.
2. **Coherent provider clones.** Two providers initialized from the same unused
   image each commit the effect. Client one-attempt order is not global spend.
3. **Finite idempotency retention.** Forgetting the terminal identity permits a
   later exact request to effect again. A bounded token window is not lifetime
   custody.
4. **Byte-identical results from distinct providers.** Two provider histories
   can each effect and emit identical result records. Exact bytes do not
   authenticate provider identity, incarnation, or newestness.

## Positive theorem

Within the compiled hosted adapter and the supplied provider object:

> A V7 fresh local claim is burned before request meaning; an exact request
> reaches one provider-submit callsite; ambiguous submit observations preserve
> uncertainty; and reopen can only query the exact operation identity.

## Nonclaims

V8 does not prove:

```text
constituted owner authority
provider authenticity or one-history identity
exclusive writer or administrator closure
lifetime deduplication
backup / restore / clone / migration continuity
external rollback resistance
stable media or physical power-loss safety
owner-authorized bounded effect
protected effect
protected settlement
result provenance or signature validity
independent appraisal or reopen
source-to-operated-binary identity
release authority or epoch advance
```

## Promotion rule

Do not call this exactly-once execution. The next valid construction must bind
one owner-admitted provider incarnation, its exact resource/index identity,
writer and restore authorities, lifetime duplicate semantics, external
newestness, and exact query result to the already-fixed claim-before-parse and
result-trilemma laws. Until then, V8 is hosted settlement scaffolding only.
