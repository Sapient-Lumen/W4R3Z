# Handoff cell v5 — process-instance pinning without provider-epoch admission

**Status:** Epoch-Zero hosted Linux construction; nonauthoritative.  
**Obligations narrowed:** O57 endpoint/descriptor/process custody and the fixed query edge of O59.  
**Authority granted:** none.

V5 retains every V1–V4 case. It extends the existing handoff vertical rather
than introducing a fourth semantic island. The new cut asks a narrower question
than “who owns this pathname?”:

> Once a query has connected, can the two ends retain a stable reference to the
> exact peer process instance, require every message to agree with that
> reference, and observe that process's death without pretending this proves
> which provider epoch the owner admitted?

The hosted answer is **yes** for the recorded Linux profile and **no** for the
admission inference. That separation is the point of V5.

## Defect corrected

V4 retained `SO_PEERCRED` as a connect-time principal coordinate. A numeric PID
is not by itself a process-lifetime object, and UID/GID equality does not
separate two successive same-principal providers. The stale-name experiment
also showed that root can retire and republish the public leaf. Without a
process-instance coordinate, a query could not even state whether a later
connection reached the same process as an earlier one.

The tempting correction would be too strong:

```text
SO_PEERPIDFD observed
  therefore authentic provider epoch
```

V5 rejects that inference. A pidfd identifies a process instance on the admitted
host profile. It does not say that the owner selected that process, that its
executable and dependencies are governed, that the machine or service
incarnation is admitted, or that the public pathname was published under a
closed administration plane.

## Identity layers kept separate

V5 names five different coordinates:

1. **numeric principal coordinate** — PID/UID/GID reported by the socket API;
2. **process-instance reference** — a retained pidfd and its host-observed
   pidfs device/inode identity;
3. **executable continuity** — the proposition that one admitted image remains
   the executing image across the relevant interval;
4. **owner-admitted provider epoch** — a governed statement selecting a
   particular service/machine/executable/process incarnation; and
5. **public endpoint binding** — the pathname socket inode selected by the
   publisher at `query.sock`.

Equality at one layer does not imply equality or authorization at another.
V5 implements only a bounded relation between layers 1 and 2, while preserving
V4's explicit layer-5 publication cut. Layers 3 and 4 remain open premises.

## Candidate surface

`EndpointConnection` now owns two close-on-exec descriptors:

```text
data socket
peer pidfd
```

The pidfd is deliberately private. The public C++ surface exposes only:

```text
EndpointPeer::process                 // device/inode observation
EndpointConnection::peer_process_exited(timeout, error)
```

There is no native pidfd accessor, signal method, `pidfd_getfd` bridge, namespace
entry, process-control method, replacement method, or process registry. The
candidate can compare a received process identity and poll for exit; it cannot
turn the pidfd into generic authority over the peer.

On the admitted rev0891 host, `fstat(2)` device/inode equality is used to compare
pidfds. This representation is explicitly host-profile evidence, not a portable
ABI promise and not a persistent identity suitable for storage across reboot.

## Connect-time process reference

Provider listener, accepted socket, and query socket enable both:

```text
SO_PASSCRED
SO_PASSPIDFD
```

After `accept4(2)` or `connect(2)`, the candidate obtains:

```text
SO_PEERCRED
SO_PEERPIDFD
```

The pidfd must be valid and close-on-exec. The provider's accepted connection
retains a pidfd for the query process; the query's connection retains a pidfd
for the provider process. Exact descriptor census expands by one retained
process descriptor at each connected endpoint:

```text
provider after accept: 9 descriptors including data socket and one peer pidfd
query after connect:    7 descriptors including data socket and one peer pidfd
```

The prebind and preconnect tables remain unchanged. The process descriptor is
created only after the connection exists and is closed with the connection.

## Per-message process agreement

Every received packet must carry exactly one `SCM_CREDENTIALS` record and
exactly one automatic `SCM_PIDFD` record. The receive path:

1. allocates bounded control space for credentials, one pidfd, and bounded
   `SCM_RIGHTS` input;
2. calls `recvmsg(2)` with `MSG_CMSG_CLOEXEC`;
3. rejects truncation, missing, duplicate, malformed, or unknown control;
4. records the pidfd's device/inode and verifies close-on-exec;
5. requires the message pidfd identity to equal the retained connect-time peer
   pidfd identity;
6. closes every received pidfd and every received right before interpreting
   request bytes; and
7. verifies exact descriptor topology again after closure.

Thus one accepted connection may not silently switch from query process Q1 to
another sender process Q2, and one query connection may not silently switch
from provider process P1 to P2, within the hosted relation. This is connection-
local sender consistency, not owner authorization.

## Process-death observation

The valid query stays alive after receiving the fixed result. The provider then
completes its bounded request sequence and exits. The query polls the retained
provider pidfd until Linux reports readable/hangup state and only then emits its
final report.

This establishes a useful temporal fact:

```text
connected to process P1
received messages agreeing with P1
observed P1 exit through the retained process reference
```

It does not retire `query.sock`, authorize replacement, establish why P1 died,
or prove stable-media completion. The stale public leaf remains and still
requires a separately constituted recovery judgment.

## Replacement counterproof

After P1 exits, the root publisher explicitly removes the stale public leaf and
publishes a fresh staged listener from provider process P2. A fresh query probe
observes:

```text
same provider UID/GID
same fixed public pathname
same fixed protocol shape
new pidfs process identity P2 != P1
```

Pidfds therefore improve discrimination: replacement is visible rather than
collapsed into one numeric-principal/path coordinate. They do not improve
admission by themselves. The privileged publisher still chose which process
occupied the public name, and the query has no independently rooted expected
provider-process token against which to compare P2.

## Socketpair creator/sender counterexample

A socketpair created before `fork(2)` retains creation-time peer state. The V5
counterexample observes the parent endpoint before and after fork:

```text
SO_PEERPIDFD == creator process
SCM_PIDFD    == forked child that sent the packet
```

The identities are distinct. Consequently, `SO_PEERPIDFD` on a pre-created
socketpair cannot be treated as the identity of whichever process later sends a
message. Connect-time construction plus per-message agreement is required for
the V5 relation. Even that relation still does not authenticate owner policy.

## Privileged credential boundary

Linux permits a sender with the relevant capability to supply credential values
that do not match its ordinary current coordinates. In the pinned kernel
source, the message's stored `struct pid` is the coordinate later used by the
UNIX ancillary receive path. V5 therefore does not claim that automatic
`SCM_PIDFD` closes a privileged same-host administration adversary.

The hosted workers deliberately enter final ordinary principals with empty
capability sets before data exchange. That makes the positive run meaningful
for those workers. It does not remove root, publisher, mount, namespace,
ptrace, signal, cgroup, kernel, or supervisor premises from the complete
system.

## Fixed platform profile

The retained rev0891 campaign admits only the recorded Linux 6.12 x86-64 host
shape. The selected UAPI values are:

```text
SO_PASSPIDFD  76
SO_PEERPIDFD  77
SCM_PIDFD     0x04
```

Fallback definitions permit compilation against older installed userspace
headers; they do not make an older kernel conform. Runtime failure is
fail-closed if the kernel does not implement the options. The source and
retained host profile, not the fallback numbers alone, constitute the tested
platform statement.

## Proof products

V5 emits twenty-nine endpoint/process cases and five endpoint counterexamples.
The independent Python oracle separately models:

- agreement between connect-time and message-time process instances;
- socketpair creation-time versus sender-time identity;
- two distinct provider processes behind the same UID/path contract;
- process death without identity mutation;
- zero owner-admitted provider processes; and
- privileged process-coordinate selection remaining open.

Clang, GCC, and Clang ASan/UBSan must independently produce byte-identical
canonical campaign products. The transparent source inventory includes this
specification and the three generation-journal codec dependencies. No build
tree or binary is retained.

## Counterexamples retained

V5 adds two first-class defeats to V4's three endpoint counterexamples:

1. `SO_PEERPIDFD` on a pre-created socketpair identifies the creator rather than
   the later forked sender; and
2. a distinct replacement pidfd proves process change but does not prove that
   the replacement is the owner-admitted provider epoch.

V4's same-UID writable-directory replacement, stale-leaf recovery requirement,
and root-publisher replacement remain. All V1–V3 alias, open-writer, rollback,
principal, descriptor, creation-time credential, ancillary-rights, and
close-range counterexamples also remain.

## What V5 does not prove

V5 does **not** establish:

- an authenticated provider or appraiser;
- owner admission of either observed process instance;
- source-to-binary or dependency identity;
- executable continuity for this candidate;
- boot, machine, service, or endpoint epoch freshness;
- exclusion of privileged credential forgery or root-equivalent replacement;
- pid namespace or cross-host portability of the process identity;
- durable endpoint publication, stable media, power-loss behavior, or rollback
  floor;
- a process registry, endpoint registry, service manager, generic launcher,
  retry loop, cleanup daemon, or administration plane; or
- release authority or an epoch advance.

## Next proof cut

The next endpoint proof should not add more observational identity APIs. It
should constitute an **owner-admitted expected provider epoch** outside the
query transport, then bind that admission to:

```text
provider executable/dependency identity
provider final principal
machine or protected execution root
service/boot incarnation
public endpoint publication receipt
exact process-instance reference
retirement and successor authorization
```

Only then can the query compare its connect-time pidfd to an independently
retained expectation. Until that constructor and receipt chain exists, V5 is a
stronger detector inside Epoch Zero, not an authenticator and not a product
service.
