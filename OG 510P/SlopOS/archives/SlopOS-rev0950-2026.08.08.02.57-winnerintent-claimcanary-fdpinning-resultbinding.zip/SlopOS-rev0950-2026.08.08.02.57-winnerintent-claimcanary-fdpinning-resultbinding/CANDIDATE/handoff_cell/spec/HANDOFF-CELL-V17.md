# Handoff Cell V17 — canonical appraiser receipt, signed statement, and custody stop

## Correction owned by V17

V16 deliberately stops because its appraiser shares the cloudtainer's
administration root and cannot independently reconstruct the installed seccomp
program, kernel executable surfaces, V14 dossier, or actor lifetime coordinate.
V17 does not manufacture that missing independence. It constructs the smallest
portable statement surface on which a future independent appraiser could report
those bindings without confusing cryptographic validity with custody:

```text
canonical report bytes
+ pinned verification key
+ valid detached signature
+ exactly one local consumption
= one signed appraiser statement

signed statement
!= independent administration
!= key custody
!= input custody
!= replay exclusion
!= independently appraised actor premise
```

The production candidate is a pure C++20 codec, Ed25519 verifier, and ordered
classifier. A separate Linux laboratory intentionally uses public RFC 8032 test
material and a child created, mapped, fed, traced, and terminated by the same
parent. It is a countermodel, not an appraiser deployment.

## Canonical receipt

`AppraiserReceiptRecordV1` encodes to exactly 384 bytes:

```text
32 bytes  domain: SLOPOS-E0-APPRAISER-RECEIPT-V1 plus two zero bytes
 4 bytes  little-endian schema = 1
 4 bytes  known claim flags only
 8 bytes  nonzero report ordinal
32 bytes  fresh challenge binding
32 bytes  appraiser constitution binding
32 bytes  actor-epoch binding
32 bytes  V15 exec-input binding
32 bytes  V16 static-envelope binding
32 bytes  installed-policy binding
32 bytes  kernel-surface binding
32 bytes  process-coordinate binding
32 bytes  V14 dossier binding
32 bytes  hold-token binding
16 bytes  reserved zero
```

The detached Ed25519 signature is exactly 64 bytes. Decode rejects a domain,
schema, flag, ordinal, or reserved-byte deviation. Encode and decode do not
interpret a signed claim flag as an established fact; each flag is only a
statement made by the signing key.

## Ordered relation

`AppraiserReceiptObservationV1` contains 39 premises and is coherent only as a
prefix. The first 28 premises establish at most one canonical signed locally
consumed statement:

```text
profile and V16 epoch supplied
-> appraiser constitution supplied
-> exact length, decode, canonicality, domain, schema, reserved bytes, flags
-> nonzero ordinal
-> fresh challenge and ten exact subject bindings
-> exact observation order
-> Ed25519 suite and pinned public key
-> exact signature length and successful verification
-> exactly one local report consumed
```

The remaining eleven premises must come from a separately constituted custody
system:

```text
appraiser process separate
-> administration root distinct
-> appraiser key custody independent
-> appraiser input custody independent
-> process coordinate lifetime-bound
-> installed policy independently reconstructed
-> kernel surfaces independently reconstructed
-> V14 dossier independently reopened
-> no same-root mutation path
-> actor epoch held through V13 admission
-> portable replay excluded
```

Only the full 39-premise prefix yields
`INDEPENDENTLY_APPRAISED_ACTOR_PREMISE`. Even then V17 grants no owner authority,
living law, provider authority, archive admission, or network authority.

## Pure campaign

The campaign uses one public RFC 8032 Ed25519 seed and public key solely as a
cryptographic fixture. It signs the exact 384-byte custom report and rejects
every single-bit mutation of:

```text
message:    384 * 8 = 3072
signature:   64 * 8 =  512
public key:  32 * 8 =  256
total:                 3840
```

The relation campaign retains 40 ordered prefixes and two incoherent gaps for
42 cases, plus 24 countermodels. One synthetic full-prefix row reaches V13
eligibility only as relation evidence. It remains nonauthoritative.

## Hosted Linux counterproof

The host fixture creates one `AF_UNIX` `SOCK_SEQPACKET` pair and one child. The
child enters a new user namespace. The same parent then:

1. writes `setgroups`, `uid_map`, and `gid_map`, constituting child uid/gid zero;
2. supplies every report byte and the public-fixture signature;
3. successfully performs `PTRACE_SEIZE`, interrupts, observes, and detaches the
   appraiser;
4. owns a pidfd and terminates the appraiser with `pidfd_send_signal`; and
5. can replay the identical signed report successfully.

The child is a separate process and has a distinct user-namespace inode, but
those are not an independent administration root. `PIDFD_GET_INFO` remains
unavailable on the retained Linux 6.12.13 host. The hosted result therefore is:

```text
signed_appraiser_statement_bound          = true
appraiser_process_separate                = true
appraiser_user_namespace_distinct         = true
parent_created_identity_maps              = true
parent_ptrace_seize_control               = true
parent_pidfd_signal_control               = true
portable_replay_excluded                  = false
appraiser_administration_root_distinct     = false
independently_appraised_actor_premise      = false
V13 actor premise                         = false
READY / rights / archive bytes / network  = zero or false
authority                                 = false
```

## Nonclaims and next cut

V17 does not create an appraiser service, key-enrollment service, process
registry, broker, downloader, activation target, provider runtime, or fourth
semantic island. It does not prove source provenance, complete process-image
identity, key nonexportability, anti-replay state, external administrator
independence, or continuous actor custody.

The next honest construction is an external appraiser constitution whose key,
inputs, process coordinate, and actor hold are protected from the candidate's
administration root. Until that exists, V13 READY and rights-bearing receive
remain forbidden. Epoch Zero remains the only truthful state.
