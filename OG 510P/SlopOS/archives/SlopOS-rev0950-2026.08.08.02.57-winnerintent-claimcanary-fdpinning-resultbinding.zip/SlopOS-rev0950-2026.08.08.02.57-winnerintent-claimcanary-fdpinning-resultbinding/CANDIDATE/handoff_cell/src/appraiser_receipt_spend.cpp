#include "slopos/e0/handoff_cell/appraiser_receipt_spend.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <span>

namespace slopos::e0::handoff_cell {
namespace {

constexpr std::array<std::uint8_t, 33U> kEnvelopeDomain{{
    'S','l','o','p','O','S','/','a','p','p','r','a','i','s','e','r',
    '/','r','e','c','e','i','p','t','/','s','p','e','n','d','/','v','1',
}};

[[nodiscard]] bool nonzero(const ReceiptSpendDigest& value) noexcept {
    return !generation_journal::digest_is_zero(value);
}

using Field = bool AppraiserReceiptSpendObservationV1::*;
constexpr std::array<Field, 53U> kFields{{
    &AppraiserReceiptSpendObservationV1::profile_supplied,
    &AppraiserReceiptSpendObservationV1::receipt_supplied,
    &AppraiserReceiptSpendObservationV1::signature_supplied,
    &AppraiserReceiptSpendObservationV1::public_key_supplied,
    &AppraiserReceiptSpendObservationV1::receipt_decoded,
    &AppraiserReceiptSpendObservationV1::receipt_canonical,
    &AppraiserReceiptSpendObservationV1::signature_verifies,
    &AppraiserReceiptSpendObservationV1::v17_signed_statement_bound,
    &AppraiserReceiptSpendObservationV1::challenge_cross_binding_exact,
    &AppraiserReceiptSpendObservationV1::constitution_cross_binding_exact,
    &AppraiserReceiptSpendObservationV1::actor_epoch_cross_binding_exact,
    &AppraiserReceiptSpendObservationV1::v15_cross_binding_exact,
    &AppraiserReceiptSpendObservationV1::v16_cross_binding_exact,
    &AppraiserReceiptSpendObservationV1::installed_policy_cross_binding_exact,
    &AppraiserReceiptSpendObservationV1::kernel_surfaces_cross_binding_exact,
    &AppraiserReceiptSpendObservationV1::process_coordinate_cross_binding_exact,
    &AppraiserReceiptSpendObservationV1::v14_cross_binding_exact,
    &AppraiserReceiptSpendObservationV1::hold_token_cross_binding_exact,
    &AppraiserReceiptSpendObservationV1::report_ordinal_nonzero,
    &AppraiserReceiptSpendObservationV1::floor_identity_supplied,
    &AppraiserReceiptSpendObservationV1::floor_identity_exact,
    &AppraiserReceiptSpendObservationV1::local_floor_exact,
    &AppraiserReceiptSpendObservationV1::floor_observation_available,
    &AppraiserReceiptSpendObservationV1::floor_content_bound,
    &AppraiserReceiptSpendObservationV1::floor_predecessor_exact,
    &AppraiserReceiptSpendObservationV1::spend_record_encoded,
    &AppraiserReceiptSpendObservationV1::spend_record_canonical,
    &AppraiserReceiptSpendObservationV1::envelope_digest_exact,
    &AppraiserReceiptSpendObservationV1::spend_subject_mapping_exact,
    &AppraiserReceiptSpendObservationV1::compare_append_request_exact,
    &AppraiserReceiptSpendObservationV1::exactly_one_compare_append_attempt,
    &AppraiserReceiptSpendObservationV1::compare_append_response_received,
    &AppraiserReceiptSpendObservationV1::compare_append_response_content_bound,
    &AppraiserReceiptSpendObservationV1::compare_append_response_exact,
    &AppraiserReceiptSpendObservationV1::append_decision_spent,
    &AppraiserReceiptSpendObservationV1::local_confirmation_updated,
    &AppraiserReceiptSpendObservationV1::duplicate_query_only,
    &AppraiserReceiptSpendObservationV1::reopen_query_only,
    &AppraiserReceiptSpendObservationV1::no_second_append_after_spend,
    &AppraiserReceiptSpendObservationV1::appraiser_administration_root_distinct,
    &AppraiserReceiptSpendObservationV1::appraiser_key_custody_independent,
    &AppraiserReceiptSpendObservationV1::appraiser_input_custody_independent,
    &AppraiserReceiptSpendObservationV1::external_challenge_spend_state,
    &AppraiserReceiptSpendObservationV1::rollback_floor_outside_restorable_image,
    &AppraiserReceiptSpendObservationV1::rollback_floor_administration_distinct,
    &AppraiserReceiptSpendObservationV1::restore_continuity_bound,
    &AppraiserReceiptSpendObservationV1::process_coordinate_lifetime_bound,
    &AppraiserReceiptSpendObservationV1::installed_policy_independently_reconstructed,
    &AppraiserReceiptSpendObservationV1::kernel_surfaces_independently_reconstructed,
    &AppraiserReceiptSpendObservationV1::v14_dossier_independently_reopened,
    &AppraiserReceiptSpendObservationV1::no_same_root_mutation_path,
    &AppraiserReceiptSpendObservationV1::actor_epoch_held_through_v13_admission,
    &AppraiserReceiptSpendObservationV1::portable_clone_replay_excluded,
}};

constexpr std::array<AppraiserReceiptSpendDisposition, 53U> kFailures{{
    AppraiserReceiptSpendDisposition::profile_unavailable,
    AppraiserReceiptSpendDisposition::receipt_unavailable,
    AppraiserReceiptSpendDisposition::signature_unavailable,
    AppraiserReceiptSpendDisposition::public_key_unavailable,
    AppraiserReceiptSpendDisposition::receipt_decode_rejected,
    AppraiserReceiptSpendDisposition::receipt_canonicality_rejected,
    AppraiserReceiptSpendDisposition::signature_rejected,
    AppraiserReceiptSpendDisposition::v17_signed_statement_unproved,
    AppraiserReceiptSpendDisposition::challenge_cross_binding_mismatch,
    AppraiserReceiptSpendDisposition::constitution_cross_binding_mismatch,
    AppraiserReceiptSpendDisposition::actor_epoch_cross_binding_mismatch,
    AppraiserReceiptSpendDisposition::v15_cross_binding_mismatch,
    AppraiserReceiptSpendDisposition::v16_cross_binding_mismatch,
    AppraiserReceiptSpendDisposition::installed_policy_cross_binding_mismatch,
    AppraiserReceiptSpendDisposition::kernel_surfaces_cross_binding_mismatch,
    AppraiserReceiptSpendDisposition::process_coordinate_cross_binding_mismatch,
    AppraiserReceiptSpendDisposition::v14_cross_binding_mismatch,
    AppraiserReceiptSpendDisposition::hold_token_cross_binding_mismatch,
    AppraiserReceiptSpendDisposition::report_ordinal_rejected,
    AppraiserReceiptSpendDisposition::floor_identity_unavailable,
    AppraiserReceiptSpendDisposition::floor_identity_mismatch,
    AppraiserReceiptSpendDisposition::local_floor_malformed,
    AppraiserReceiptSpendDisposition::floor_observation_unavailable,
    AppraiserReceiptSpendDisposition::floor_not_content_bound,
    AppraiserReceiptSpendDisposition::floor_predecessor_mismatch,
    AppraiserReceiptSpendDisposition::spend_record_encode_rejected,
    AppraiserReceiptSpendDisposition::spend_record_canonicality_rejected,
    AppraiserReceiptSpendDisposition::envelope_digest_mismatch,
    AppraiserReceiptSpendDisposition::spend_subject_mapping_mismatch,
    AppraiserReceiptSpendDisposition::compare_append_request_rejected,
    AppraiserReceiptSpendDisposition::compare_append_attempt_count_rejected,
    AppraiserReceiptSpendDisposition::compare_append_response_unavailable,
    AppraiserReceiptSpendDisposition::compare_append_response_not_content_bound,
    AppraiserReceiptSpendDisposition::compare_append_response_mismatch,
    AppraiserReceiptSpendDisposition::compare_append_not_spent,
    AppraiserReceiptSpendDisposition::local_confirmation_unproved,
    AppraiserReceiptSpendDisposition::duplicate_not_query_only,
    AppraiserReceiptSpendDisposition::reopen_not_query_only,
    AppraiserReceiptSpendDisposition::second_append_route_open,
    AppraiserReceiptSpendDisposition::appraiser_administration_root_not_distinct,
    AppraiserReceiptSpendDisposition::independent_key_custody_unproved,
    AppraiserReceiptSpendDisposition::independent_input_custody_unproved,
    AppraiserReceiptSpendDisposition::external_challenge_spend_state_unproved,
    AppraiserReceiptSpendDisposition::rollback_floor_inside_restorable_image,
    AppraiserReceiptSpendDisposition::rollback_floor_administration_not_distinct,
    AppraiserReceiptSpendDisposition::restore_continuity_unproved,
    AppraiserReceiptSpendDisposition::process_lifetime_coordinate_unproved,
    AppraiserReceiptSpendDisposition::installed_policy_reconstruction_unproved,
    AppraiserReceiptSpendDisposition::kernel_surface_reconstruction_unproved,
    AppraiserReceiptSpendDisposition::v14_dossier_reopen_unproved,
    AppraiserReceiptSpendDisposition::same_root_mutation_path_open,
    AppraiserReceiptSpendDisposition::actor_epoch_hold_unproved,
    AppraiserReceiptSpendDisposition::portable_clone_replay_open,
}};

[[nodiscard]] bool ordered(const AppraiserReceiptSpendObservationV1& value) noexcept {
    bool false_seen = false;
    for (const Field field : kFields) {
        const bool present = value.*field;
        if (!present) false_seen = true;
        else if (false_seen) return false;
    }
    return true;
}

}  // namespace

ReceiptSpendDigest appraiser_receipt_envelope_digest(
    const AppraiserReceiptBytes& message,
    const AppraiserReceiptSignature& signature,
    const AppraiserPublicKey& public_key) {
    std::array<std::uint8_t,
        kEnvelopeDomain.size() + kAppraiserReceiptBytes
        + kAppraiserReceiptSignatureBytes + kAppraiserPublicKeyBytes> input{};
    auto cursor = input.begin();
    cursor = std::copy(kEnvelopeDomain.begin(), kEnvelopeDomain.end(), cursor);
    cursor = std::copy(message.begin(), message.end(), cursor);
    cursor = std::copy(signature.begin(), signature.end(), cursor);
    (void)std::copy(public_key.begin(), public_key.end(), cursor);
    return generation_journal::sha256(
        std::span<const std::uint8_t>(input.data(), input.size()));
}

std::optional<EncodedReceiptSpendRecord> make_appraiser_receipt_spend_record(
    const AppraiserReceiptBytes& message,
    const AppraiserReceiptSignature& signature,
    const AppraiserPublicKey& public_key,
    const ReceiptSpendDigest& floor_identity,
    const generation_journal::FloorPoint& predecessor,
    const std::uint64_t owner_epoch,
    const std::uint64_t constructor_epoch) noexcept {
    if (!nonzero(floor_identity) || predecessor.generation == 0U
        || !nonzero(predecessor.head)
        || predecessor.generation == std::numeric_limits<std::uint64_t>::max()
        || owner_epoch == 0U || constructor_epoch == 0U) {
        return std::nullopt;
    }
    AppraiserReceiptRecordV1 decoded;
    AppraiserReceiptBytes canonical{};
    if (!decode_appraiser_receipt(message, decoded)
        || !encode_appraiser_receipt(decoded, canonical) || canonical != message
        || !verify_appraiser_receipt_ed25519(public_key, message, signature)
        || decoded.report_ordinal == 0U) {
        return std::nullopt;
    }
    ReceiptSpendRecord record;
    record.owner_epoch = owner_epoch;
    record.constructor_epoch = constructor_epoch;
    record.spend_serial = decoded.report_ordinal;
    record.generation_from = predecessor.generation;
    record.generation_to = predecessor.generation + 1U;
    record.owner_statement = decoded.appraiser_constitution;
    record.constructor_image = decoded.v16_static_envelope;
    record.provider_subject = floor_identity;
    record.publication_receipt = appraiser_receipt_envelope_digest(
        message, signature, public_key);
    record.expectation_record = decoded.challenge;
    record.operation = decoded.actor_epoch;
    record.pending_result = decoded.hold_token;
    record.predecessor_head = predecessor.head;
    EncodedReceiptSpendRecord encoded{};
    if (!generation_journal::encode_spend_record(record, encoded)) {
        return std::nullopt;
    }
    return encoded;
}

AppraiserReceiptSpendAssessment assess_appraiser_receipt_spend(
    const AppraiserReceiptSpendObservationV1& observation) noexcept {
    AppraiserReceiptSpendAssessment result;
    if (!ordered(observation)) return result;
    result.observation_coherent = true;
    std::size_t prefix = 0U;
    while (prefix < kFields.size() && observation.*kFields[prefix]) ++prefix;
    result.disposition = prefix == kFields.size()
        ? AppraiserReceiptSpendDisposition::externally_spent_appraiser_premise
        : kFailures[prefix];
    result.canonical_receipt_cross_bound = prefix >= 19U;
    result.content_bound_spend_record = prefix >= 29U;
    result.compare_append_request_bound = prefix >= 30U;
    result.one_local_receipt_spend_bound = prefix >= 36U;
    result.duplicate_query_only_bound = prefix >= 39U;
    result.external_rollback_floor_bound = prefix >= 46U;
    result.independent_appraiser_constitution_bound = prefix >= 51U;
    result.externally_spent_appraiser_premise_bound = prefix == kFields.size();
    result.eligible_for_v13_actor_premise = prefix == kFields.size();
    result.portable_clone_replay_excluded = prefix == kFields.size();
    return result;
}

const char* appraiser_receipt_spend_disposition_name(
    const AppraiserReceiptSpendDisposition value) noexcept {
#define SLOPOS_CASE(name) case AppraiserReceiptSpendDisposition::name: return #name
    switch (value) {
    SLOPOS_CASE(observation_incoherent); SLOPOS_CASE(profile_unavailable);
    SLOPOS_CASE(receipt_unavailable); SLOPOS_CASE(signature_unavailable);
    SLOPOS_CASE(public_key_unavailable); SLOPOS_CASE(receipt_decode_rejected);
    SLOPOS_CASE(receipt_canonicality_rejected); SLOPOS_CASE(signature_rejected);
    SLOPOS_CASE(v17_signed_statement_unproved); SLOPOS_CASE(challenge_cross_binding_mismatch);
    SLOPOS_CASE(constitution_cross_binding_mismatch); SLOPOS_CASE(actor_epoch_cross_binding_mismatch);
    SLOPOS_CASE(v15_cross_binding_mismatch); SLOPOS_CASE(v16_cross_binding_mismatch);
    SLOPOS_CASE(installed_policy_cross_binding_mismatch); SLOPOS_CASE(kernel_surfaces_cross_binding_mismatch);
    SLOPOS_CASE(process_coordinate_cross_binding_mismatch); SLOPOS_CASE(v14_cross_binding_mismatch);
    SLOPOS_CASE(hold_token_cross_binding_mismatch); SLOPOS_CASE(report_ordinal_rejected);
    SLOPOS_CASE(floor_identity_unavailable); SLOPOS_CASE(floor_identity_mismatch);
    SLOPOS_CASE(local_floor_malformed); SLOPOS_CASE(floor_observation_unavailable);
    SLOPOS_CASE(floor_not_content_bound); SLOPOS_CASE(floor_predecessor_mismatch);
    SLOPOS_CASE(spend_record_encode_rejected); SLOPOS_CASE(spend_record_canonicality_rejected);
    SLOPOS_CASE(envelope_digest_mismatch); SLOPOS_CASE(spend_subject_mapping_mismatch);
    SLOPOS_CASE(compare_append_request_rejected); SLOPOS_CASE(compare_append_attempt_count_rejected);
    SLOPOS_CASE(compare_append_response_unavailable); SLOPOS_CASE(compare_append_response_not_content_bound);
    SLOPOS_CASE(compare_append_response_mismatch); SLOPOS_CASE(compare_append_not_spent);
    SLOPOS_CASE(local_confirmation_unproved); SLOPOS_CASE(duplicate_not_query_only);
    SLOPOS_CASE(reopen_not_query_only); SLOPOS_CASE(second_append_route_open);
    SLOPOS_CASE(appraiser_administration_root_not_distinct); SLOPOS_CASE(independent_key_custody_unproved);
    SLOPOS_CASE(independent_input_custody_unproved); SLOPOS_CASE(external_challenge_spend_state_unproved);
    SLOPOS_CASE(rollback_floor_inside_restorable_image); SLOPOS_CASE(rollback_floor_administration_not_distinct);
    SLOPOS_CASE(restore_continuity_unproved); SLOPOS_CASE(process_lifetime_coordinate_unproved);
    SLOPOS_CASE(installed_policy_reconstruction_unproved); SLOPOS_CASE(kernel_surface_reconstruction_unproved);
    SLOPOS_CASE(v14_dossier_reopen_unproved); SLOPOS_CASE(same_root_mutation_path_open);
    SLOPOS_CASE(actor_epoch_hold_unproved); SLOPOS_CASE(portable_clone_replay_open);
    SLOPOS_CASE(externally_spent_appraiser_premise);
    }
#undef SLOPOS_CASE
    return "invalid";
}

}  // namespace slopos::e0::handoff_cell
