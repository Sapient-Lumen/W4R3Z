#include "slopos/e0/handoff_cell/cell.hpp"

#include <array>
#include <cerrno>
#include <cstddef>
#include <cstring>
#include <limits>

#include <fcntl.h>
#include <linux/fs.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <unistd.h>

namespace slopos::e0::handoff_cell {
namespace {

[[nodiscard]] int rename_no_replace(const int directory_fd) noexcept {
#if defined(SYS_renameat2)
    return static_cast<int>(::syscall(
        SYS_renameat2, directory_fd, kLiveLeaf, directory_fd, kPendingLeaf,
        static_cast<unsigned int>(RENAME_NOREPLACE)));
#else
    (void)directory_fd;
    errno = ENOSYS;
    return -1;
#endif
}

[[nodiscard]] bool read_complete(const int fd, EncodedRecord& bytes,
                                 int& error_number) noexcept {
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const std::size_t remaining = bytes.size() - offset;
        const ssize_t count = ::read(fd, bytes.data() + offset, remaining);
        if (count == 0) return false;
        if (count < 0) {
            if (errno == EINTR) continue;
            error_number = errno;
            return false;
        }
        offset += static_cast<std::size_t>(count);
    }
    return true;
}

}  // namespace

Cell::Cell(Cell&& other) noexcept : directory_fd_(other.directory_fd_) {
    other.directory_fd_ = -1;
}

Cell& Cell::operator=(Cell&& other) noexcept {
    if (this != &other) {
        if (directory_fd_ >= 0) (void)::close(directory_fd_);
        directory_fd_ = other.directory_fd_;
        other.directory_fd_ = -1;
    }
    return *this;
}

Cell::~Cell() {
    if (directory_fd_ >= 0) (void)::close(directory_fd_);
}

std::optional<Cell> Cell::retain_host_directory(const int directory_fd,
                                           int& error_number) noexcept {
    error_number = 0;
    struct stat status {};
    if (::fstat(directory_fd, &status) != 0) {
        error_number = errno;
        return std::nullopt;
    }
    if (!S_ISDIR(status.st_mode)) {
        error_number = ENOTDIR;
        return std::nullopt;
    }
    const int duplicate = ::fcntl(directory_fd, F_DUPFD_CLOEXEC, 3);
    if (duplicate < 0) {
        error_number = errno;
        return std::nullopt;
    }
    return Cell(duplicate);
}

BurnResult Cell::burn_before_decode() noexcept {
    if (directory_fd_ < 0) return {BurnDisposition::io_error, EBADF};

    // This syscall is the complete pre-validation mutation boundary. There is
    // intentionally no preflight stat/open/read/decode of either leaf.
    if (rename_no_replace(directory_fd_) == 0) {
        if (::fsync(directory_fd_) == 0) {
            return {BurnDisposition::bound_and_synced, 0};
        }
        // Never translate a completed namespace cut into "not consumed".
        return {BurnDisposition::bound_sync_uncertain, errno};
    }

    const int observed = errno;
    switch (observed) {
        case ENOENT:
            return {BurnDisposition::live_missing, observed};
        case EEXIST:
            return {BurnDisposition::pending_exists, observed};
        case ENOSYS:
        case EINVAL:
            return {BurnDisposition::unsupported, observed};
        default:
            return {BurnDisposition::io_error, observed};
    }
}

PendingResult Cell::query_pending_exact(
    const EncodedRecord& expected) const noexcept {
    if (directory_fd_ < 0) {
        return {PendingDisposition::io_error, EBADF, 0U};
    }
    // O_NONBLOCK prevents a malformed FIFO pending object from
    // turning the query-only surface into a blocking rendezvous before fstat.
    // It does not weaken regular-file readback semantics.
    const int fd = ::openat(directory_fd_, kPendingLeaf,
                            O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK);
    if (fd < 0) {
        const int observed = errno;
        if (observed == ENOENT) {
            return {PendingDisposition::missing, observed, 0U};
        }
        return {PendingDisposition::io_error, observed, 0U};
    }

    struct stat status {};
    if (::fstat(fd, &status) != 0) {
        const int observed = errno;
        (void)::close(fd);
        return {PendingDisposition::io_error, observed, 0U};
    }
    const auto links = static_cast<std::uint64_t>(status.st_nlink);
    if (!S_ISREG(status.st_mode)) {
        (void)::close(fd);
        return {PendingDisposition::not_regular, 0, links};
    }
    if (status.st_size != static_cast<off_t>(expected.size())) {
        (void)::close(fd);
        return {PendingDisposition::wrong_size, 0, links};
    }
    if (status.st_nlink != 1) {
        (void)::close(fd);
        return {PendingDisposition::alias_detected, 0, links};
    }

    EncodedRecord observed{};
    int read_error = 0;
    if (!read_complete(fd, observed, read_error)) {
        (void)::close(fd);
        return {PendingDisposition::io_error,
                read_error == 0 ? EIO : read_error, links};
    }
    std::array<std::uint8_t, 1U> surplus{};
    ssize_t surplus_count = -1;
    do {
        surplus_count = ::read(fd, surplus.data(), surplus.size());
    } while (surplus_count < 0 && errno == EINTR);
    const int surplus_error = surplus_count < 0 ? errno : 0;
    const int close_result = ::close(fd);
    const int close_error = close_result != 0 ? errno : 0;
    if (surplus_count < 0) {
        return {PendingDisposition::io_error, surplus_error, links};
    }
    if (close_result != 0) {
        return {PendingDisposition::io_error, close_error, links};
    }
    if (surplus_count != 0) {
        return {PendingDisposition::wrong_size, 0, links};
    }
    if (observed != expected) {
        return {PendingDisposition::exact_mismatch, 0, links};
    }

    generation_journal::Record decoded;
    if (!generation_journal::decode_record(observed, decoded)) {
        return {PendingDisposition::decode_rejected, 0, links};
    }
    if (decoded.kind != generation_journal::RecordKind::pending) {
        return {PendingDisposition::wrong_record_kind, 0, links};
    }
    return {PendingDisposition::exact_pending, 0, links};
}

const char* burn_name(const BurnDisposition value) noexcept {
    switch (value) {
        case BurnDisposition::bound_and_synced: return "BOUND_SYNCED";
        case BurnDisposition::bound_sync_uncertain: return "BOUND_SYNC_UNCERTAIN";
        case BurnDisposition::live_missing: return "LIVE_MISSING";
        case BurnDisposition::pending_exists: return "PENDING_EXISTS";
        case BurnDisposition::unsupported: return "UNSUPPORTED";
        case BurnDisposition::io_error: return "IO_ERROR";
    }
    return "IO_ERROR";
}

const char* pending_name(const PendingDisposition value) noexcept {
    switch (value) {
        case PendingDisposition::exact_pending: return "EXACT_PENDING";
        case PendingDisposition::missing: return "MISSING";
        case PendingDisposition::not_regular: return "NOT_REGULAR";
        case PendingDisposition::wrong_size: return "WRONG_SIZE";
        case PendingDisposition::alias_detected: return "ALIAS_DETECTED";
        case PendingDisposition::exact_mismatch: return "EXACT_MISMATCH";
        case PendingDisposition::decode_rejected: return "DECODE_REJECTED";
        case PendingDisposition::wrong_record_kind: return "WRONG_RECORD_KIND";
        case PendingDisposition::io_error: return "IO_ERROR";
    }
    return "IO_ERROR";
}

}  // namespace slopos::e0::handoff_cell
