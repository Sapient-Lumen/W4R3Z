#include "slopos/e0/handoff_cell/release_body_capsule.hpp"

#include <array>

namespace slopos::e0::handoff_cell {
namespace {

[[nodiscard]] std::array<bool, 36U> ordered_values(
    const ReleaseBodyCapsuleObservationV1& value) noexcept {
    return {{
        value.release_profile_supplied,
        value.release_name_exact,
        value.expected_size_exact,
        value.expected_digest_exact,
        value.armored_body_supplied,
        value.envelope_version_exact,
        value.session_identity_exact,
        value.canonical_base64_required,
        value.fixed_chunk_size_exact,
        value.chunk_count_exact,
        value.total_length_consistent,
        value.staging_object_private,
        value.staging_object_unlinked,
        value.staging_object_bounded,
        value.no_parse_route_before_complete,
        value.no_extraction_route_before_complete,
        value.no_execution_route_before_complete,
        value.no_network_route,
        value.records_session_exact,
        value.indices_in_range,
        value.offsets_exact,
        value.lengths_exact,
        value.base64_canonical,
        value.decoded_lengths_exact,
        value.chunk_digests_exact,
        value.writes_exact_offset,
        value.identical_duplicates_query_only,
        value.conflicting_duplicates_poison,
        value.coverage_complete,
        value.no_overlapping_ranges,
        value.no_trailing_bytes,
        value.assembled_length_exact,
        value.whole_digest_recomputed,
        value.whole_digest_exact,
        value.complete_snapshot_sealed,
        value.v11_recapture_required,
    }};
}

[[nodiscard]] bool is_ordered_prefix(
    const std::array<bool, 36U>& values) noexcept {
    bool false_seen = false;
    for (const bool value : values) {
        if (!value) {
            false_seen = true;
        } else if (false_seen) {
            return false;
        }
    }
    return true;
}

[[nodiscard]] ReleaseBodyCapsuleAssessment base_assessment() noexcept {
    ReleaseBodyCapsuleAssessment result;
    result.archive_admitted = false;
    result.archive_parse_attempted = false;
    result.extraction_attempted = false;
    result.execution_attempted = false;
    result.provider_operated = false;
    result.network_attempted = false;
    result.owner_authority = false;
    result.living_law = false;
    return result;
}

}  // namespace

ReleaseBodyCapsuleAssessment assess_release_body_capsule(
    const ReleaseBodyCapsuleObservationV1& observation) noexcept {
    ReleaseBodyCapsuleAssessment result = base_assessment();
    if (!is_ordered_prefix(ordered_values(observation))) {
        result.disposition = ReleaseBodyCapsuleDisposition::observation_incoherent;
        return result;
    }
    result.observation_coherent = true;

#define SLOPOS_V22_REQUIRE(field, disposition_name) \
    if (!observation.field) { \
        result.disposition = ReleaseBodyCapsuleDisposition::disposition_name; \
        return result; \
    }

    SLOPOS_V22_REQUIRE(release_profile_supplied, release_profile_unavailable)
    SLOPOS_V22_REQUIRE(release_name_exact, release_name_mismatch)
    SLOPOS_V22_REQUIRE(expected_size_exact, expected_size_mismatch)
    SLOPOS_V22_REQUIRE(expected_digest_exact, expected_digest_mismatch)
    result.release_metadata_bound = true;

    SLOPOS_V22_REQUIRE(armored_body_supplied, armored_body_unavailable)
    SLOPOS_V22_REQUIRE(envelope_version_exact, envelope_version_mismatch)
    SLOPOS_V22_REQUIRE(session_identity_exact, session_identity_mismatch)
    SLOPOS_V22_REQUIRE(canonical_base64_required, canonical_base64_unrequired)
    SLOPOS_V22_REQUIRE(fixed_chunk_size_exact, chunk_size_mismatch)
    SLOPOS_V22_REQUIRE(chunk_count_exact, chunk_count_mismatch)
    SLOPOS_V22_REQUIRE(total_length_consistent, total_length_inconsistent)
    result.armored_body_bound = true;

    SLOPOS_V22_REQUIRE(staging_object_private, staging_object_not_private)
    SLOPOS_V22_REQUIRE(staging_object_unlinked, staging_object_linked)
    SLOPOS_V22_REQUIRE(staging_object_bounded, staging_object_unbounded)
    SLOPOS_V22_REQUIRE(no_parse_route_before_complete, parse_route_open_before_complete)
    SLOPOS_V22_REQUIRE(no_extraction_route_before_complete, extraction_route_open_before_complete)
    SLOPOS_V22_REQUIRE(no_execution_route_before_complete, execution_route_open_before_complete)
    SLOPOS_V22_REQUIRE(no_network_route, network_route_open)
    result.staging_floor_bound = true;

    SLOPOS_V22_REQUIRE(records_session_exact, record_session_mismatch)
    SLOPOS_V22_REQUIRE(indices_in_range, chunk_index_out_of_range)
    SLOPOS_V22_REQUIRE(offsets_exact, chunk_offset_mismatch)
    SLOPOS_V22_REQUIRE(lengths_exact, chunk_length_mismatch)
    SLOPOS_V22_REQUIRE(base64_canonical, base64_noncanonical)
    SLOPOS_V22_REQUIRE(decoded_lengths_exact, decoded_length_mismatch)
    SLOPOS_V22_REQUIRE(chunk_digests_exact, chunk_digest_mismatch)
    SLOPOS_V22_REQUIRE(writes_exact_offset, write_offset_mismatch)
    SLOPOS_V22_REQUIRE(identical_duplicates_query_only, duplicate_not_query_only)
    SLOPOS_V22_REQUIRE(conflicting_duplicates_poison, conflicting_duplicate_not_poisoned)
    result.chunk_records_bound = true;

    SLOPOS_V22_REQUIRE(coverage_complete, coverage_incomplete)
    SLOPOS_V22_REQUIRE(no_overlapping_ranges, range_overlap)
    SLOPOS_V22_REQUIRE(no_trailing_bytes, trailing_bytes_present)
    SLOPOS_V22_REQUIRE(assembled_length_exact, assembled_length_mismatch)
    result.complete_coverage_bound = true;

    SLOPOS_V22_REQUIRE(whole_digest_recomputed, whole_digest_not_recomputed)
    SLOPOS_V22_REQUIRE(whole_digest_exact, whole_digest_mismatch)
    result.whole_digest_bound = true;

    SLOPOS_V22_REQUIRE(complete_snapshot_sealed, complete_snapshot_unsealed)
    result.sealed_capsule_bound = true;

    SLOPOS_V22_REQUIRE(v11_recapture_required, v11_recapture_premise)
    result.eligible_for_v11_ingress = true;
    result.disposition = ReleaseBodyCapsuleDisposition::v11_recapture_premise;
#undef SLOPOS_V22_REQUIRE
    return result;
}

const char* release_body_capsule_disposition_name(
    const ReleaseBodyCapsuleDisposition value) noexcept {
#define SLOPOS_V22_NAME(name) case ReleaseBodyCapsuleDisposition::name: return #name;
    switch (value) {
        SLOPOS_V22_NAME(observation_incoherent)
        SLOPOS_V22_NAME(release_profile_unavailable)
        SLOPOS_V22_NAME(release_name_mismatch)
        SLOPOS_V22_NAME(expected_size_mismatch)
        SLOPOS_V22_NAME(expected_digest_mismatch)
        SLOPOS_V22_NAME(armored_body_unavailable)
        SLOPOS_V22_NAME(envelope_version_mismatch)
        SLOPOS_V22_NAME(session_identity_mismatch)
        SLOPOS_V22_NAME(canonical_base64_unrequired)
        SLOPOS_V22_NAME(chunk_size_mismatch)
        SLOPOS_V22_NAME(chunk_count_mismatch)
        SLOPOS_V22_NAME(total_length_inconsistent)
        SLOPOS_V22_NAME(staging_object_not_private)
        SLOPOS_V22_NAME(staging_object_linked)
        SLOPOS_V22_NAME(staging_object_unbounded)
        SLOPOS_V22_NAME(parse_route_open_before_complete)
        SLOPOS_V22_NAME(extraction_route_open_before_complete)
        SLOPOS_V22_NAME(execution_route_open_before_complete)
        SLOPOS_V22_NAME(network_route_open)
        SLOPOS_V22_NAME(record_session_mismatch)
        SLOPOS_V22_NAME(chunk_index_out_of_range)
        SLOPOS_V22_NAME(chunk_offset_mismatch)
        SLOPOS_V22_NAME(chunk_length_mismatch)
        SLOPOS_V22_NAME(base64_noncanonical)
        SLOPOS_V22_NAME(decoded_length_mismatch)
        SLOPOS_V22_NAME(chunk_digest_mismatch)
        SLOPOS_V22_NAME(write_offset_mismatch)
        SLOPOS_V22_NAME(duplicate_not_query_only)
        SLOPOS_V22_NAME(conflicting_duplicate_not_poisoned)
        SLOPOS_V22_NAME(coverage_incomplete)
        SLOPOS_V22_NAME(range_overlap)
        SLOPOS_V22_NAME(trailing_bytes_present)
        SLOPOS_V22_NAME(assembled_length_mismatch)
        SLOPOS_V22_NAME(whole_digest_not_recomputed)
        SLOPOS_V22_NAME(whole_digest_mismatch)
        SLOPOS_V22_NAME(complete_snapshot_unsealed)
        SLOPOS_V22_NAME(v11_recapture_premise)
    }
#undef SLOPOS_V22_NAME
    return "unknown";
}

}  // namespace slopos::e0::handoff_cell
