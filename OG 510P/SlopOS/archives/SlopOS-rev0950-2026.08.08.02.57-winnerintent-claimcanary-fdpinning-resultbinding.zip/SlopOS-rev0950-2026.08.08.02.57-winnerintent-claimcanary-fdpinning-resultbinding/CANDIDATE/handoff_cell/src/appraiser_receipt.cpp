#include "slopos/e0/handoff_cell/appraiser_receipt.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>

#include <openssl/evp.h>

namespace slopos::e0::handoff_cell {
namespace {

constexpr std::array<std::uint8_t, 32U> kDomain = {
    'S', 'L', 'O', 'P', 'O', 'S', '-', 'E', '0', '-', 'A', 'P', 'P', 'R', 'A',
    'I', 'S', 'E', 'R', '-', 'R', 'E', 'C', 'E', 'I', 'P', 'T', '-', 'V', '1',
    0U, 0U,
};
constexpr std::size_t kFieldCount = 39U;
using Fields = std::array<bool, kFieldCount>;

void put_u32(AppraiserReceiptBytes& out, const std::size_t offset,
             const std::uint32_t value) noexcept {
    for (std::size_t index = 0U; index < 4U; ++index) {
        out[offset + index] = static_cast<std::uint8_t>(
            (value >> (index * 8U)) & 0xFFU);
    }
}

void put_u64(AppraiserReceiptBytes& out, const std::size_t offset,
             const std::uint64_t value) noexcept {
    for (std::size_t index = 0U; index < 8U; ++index) {
        out[offset + index] = static_cast<std::uint8_t>(
            (value >> (index * 8U)) & 0xFFU);
    }
}

[[nodiscard]] std::uint32_t get_u32(const AppraiserReceiptBytes& in,
                                    const std::size_t offset) noexcept {
    std::uint32_t value = 0U;
    for (std::size_t index = 0U; index < 4U; ++index) {
        value |= static_cast<std::uint32_t>(in[offset + index]) << (index * 8U);
    }
    return value;
}

[[nodiscard]] std::uint64_t get_u64(const AppraiserReceiptBytes& in,
                                    const std::size_t offset) noexcept {
    std::uint64_t value = 0U;
    for (std::size_t index = 0U; index < 8U; ++index) {
        value |= static_cast<std::uint64_t>(in[offset + index]) << (index * 8U);
    }
    return value;
}

void put_binding(AppraiserReceiptBytes& out, const std::size_t offset,
                 const AppraiserBinding& value) noexcept {
    std::copy(value.begin(), value.end(), out.begin()
              + static_cast<std::ptrdiff_t>(offset));
}

void get_binding(const AppraiserReceiptBytes& in, const std::size_t offset,
                 AppraiserBinding& value) noexcept {
    std::copy_n(in.begin() + static_cast<std::ptrdiff_t>(offset), value.size(),
                value.begin());
}

[[nodiscard]] Fields fields(const AppraiserReceiptObservationV1& v) noexcept {
    return {
        v.profile_supplied,
        v.v16_hosted_actor_epoch_supplied,
        v.appraiser_constitution_supplied,
        v.receipt_exact_length,
        v.receipt_decoded,
        v.receipt_canonical,
        v.receipt_domain_exact,
        v.receipt_schema_exact,
        v.receipt_reserved_zero,
        v.receipt_claim_flags_known,
        v.report_ordinal_nonzero,
        v.challenge_fresh,
        v.challenge_binding_exact,
        v.constitution_binding_exact,
        v.actor_epoch_binding_exact,
        v.v15_exec_input_binding_exact,
        v.v16_static_envelope_binding_exact,
        v.installed_policy_binding_exact,
        v.kernel_surface_binding_exact,
        v.process_coordinate_binding_exact,
        v.v14_dossier_binding_exact,
        v.hold_token_binding_exact,
        v.observation_order_exact,
        v.signature_suite_ed25519,
        v.public_key_pinned,
        v.signature_exact_length,
        v.signature_verifies,
        v.exactly_one_report_consumed,
        v.appraiser_process_separate,
        v.appraiser_administration_root_distinct,
        v.appraiser_key_custody_independent,
        v.appraiser_input_custody_independent,
        v.process_coordinate_lifetime_bound,
        v.installed_policy_independently_reconstructed,
        v.kernel_surfaces_independently_reconstructed,
        v.v14_dossier_independently_reopened,
        v.no_same_root_mutation_path,
        v.actor_epoch_held_through_v13_admission,
        v.portable_replay_excluded,
    };
}

[[nodiscard]] bool coherent_prefix(const Fields& values) noexcept {
    bool false_seen = false;
    for (const bool value : values) {
        if (!value) {
            false_seen = true;
        } else if (false_seen) {
            return false;
        }
    }
    return true;
}

[[nodiscard]] std::size_t true_prefix(const Fields& values) noexcept {
    std::size_t count = 0U;
    while (count < values.size() && values[count]) ++count;
    return count;
}

[[nodiscard]] bool prefix(const Fields& values,
                          const std::size_t count) noexcept {
    if (count > values.size()) return false;
    return std::all_of(values.begin(),
                       values.begin() + static_cast<std::ptrdiff_t>(count),
                       [](const bool value) { return value; });
}

[[nodiscard]] AppraiserReceiptDisposition disposition_for_cut(
    const std::size_t cut) noexcept {
    constexpr std::array<AppraiserReceiptDisposition, kFieldCount> map = {
        AppraiserReceiptDisposition::profile_unavailable,
        AppraiserReceiptDisposition::v16_actor_epoch_unavailable,
        AppraiserReceiptDisposition::appraiser_constitution_unavailable,
        AppraiserReceiptDisposition::receipt_length_rejected,
        AppraiserReceiptDisposition::receipt_decode_rejected,
        AppraiserReceiptDisposition::receipt_canonicality_rejected,
        AppraiserReceiptDisposition::receipt_domain_rejected,
        AppraiserReceiptDisposition::receipt_schema_rejected,
        AppraiserReceiptDisposition::receipt_reserved_bytes_rejected,
        AppraiserReceiptDisposition::receipt_claim_flags_rejected,
        AppraiserReceiptDisposition::report_ordinal_rejected,
        AppraiserReceiptDisposition::challenge_freshness_unproved,
        AppraiserReceiptDisposition::challenge_binding_mismatch,
        AppraiserReceiptDisposition::constitution_binding_mismatch,
        AppraiserReceiptDisposition::actor_epoch_binding_mismatch,
        AppraiserReceiptDisposition::v15_exec_input_binding_mismatch,
        AppraiserReceiptDisposition::v16_static_envelope_binding_mismatch,
        AppraiserReceiptDisposition::installed_policy_binding_mismatch,
        AppraiserReceiptDisposition::kernel_surface_binding_mismatch,
        AppraiserReceiptDisposition::process_coordinate_binding_mismatch,
        AppraiserReceiptDisposition::v14_dossier_binding_mismatch,
        AppraiserReceiptDisposition::hold_token_binding_mismatch,
        AppraiserReceiptDisposition::observation_order_rejected,
        AppraiserReceiptDisposition::signature_suite_rejected,
        AppraiserReceiptDisposition::public_key_pin_unproved,
        AppraiserReceiptDisposition::signature_length_rejected,
        AppraiserReceiptDisposition::signature_invalid,
        AppraiserReceiptDisposition::report_consumption_unproved,
        AppraiserReceiptDisposition::appraiser_process_not_separate,
        AppraiserReceiptDisposition::administration_root_not_distinct,
        AppraiserReceiptDisposition::independent_key_custody_unproved,
        AppraiserReceiptDisposition::independent_input_custody_unproved,
        AppraiserReceiptDisposition::process_lifetime_coordinate_unproved,
        AppraiserReceiptDisposition::installed_policy_reconstruction_unproved,
        AppraiserReceiptDisposition::kernel_surface_reconstruction_unproved,
        AppraiserReceiptDisposition::v14_dossier_reopen_unproved,
        AppraiserReceiptDisposition::same_root_mutation_path_open,
        AppraiserReceiptDisposition::actor_epoch_hold_unproved,
        AppraiserReceiptDisposition::portable_replay_open,
    };
    return cut < map.size()
        ? map[cut]
        : AppraiserReceiptDisposition::independently_appraised_actor_premise;
}

}  // namespace

bool encode_appraiser_receipt(const AppraiserReceiptRecordV1& record,
                              AppraiserReceiptBytes& encoded) noexcept {
    if (record.report_ordinal == 0U
        || (record.claim_flags & ~kAppraiserReceiptKnownClaimMask) != 0U) {
        return false;
    }
    encoded.fill(0U);
    std::copy(kDomain.begin(), kDomain.end(), encoded.begin());
    put_u32(encoded, 32U, kAppraiserReceiptSchema);
    put_u32(encoded, 36U, record.claim_flags);
    put_u64(encoded, 40U, record.report_ordinal);
    put_binding(encoded, 48U, record.challenge);
    put_binding(encoded, 80U, record.appraiser_constitution);
    put_binding(encoded, 112U, record.actor_epoch);
    put_binding(encoded, 144U, record.v15_exec_input);
    put_binding(encoded, 176U, record.v16_static_envelope);
    put_binding(encoded, 208U, record.installed_policy);
    put_binding(encoded, 240U, record.kernel_surfaces);
    put_binding(encoded, 272U, record.process_coordinate);
    put_binding(encoded, 304U, record.v14_dossier);
    put_binding(encoded, 336U, record.hold_token);
    return true;
}

bool decode_appraiser_receipt(const AppraiserReceiptBytes& encoded,
                              AppraiserReceiptRecordV1& record) noexcept {
    if (!std::equal(kDomain.begin(), kDomain.end(), encoded.begin())) return false;
    if (get_u32(encoded, 32U) != kAppraiserReceiptSchema) return false;
    const std::uint32_t flags = get_u32(encoded, 36U);
    if ((flags & ~kAppraiserReceiptKnownClaimMask) != 0U) return false;
    const std::uint64_t ordinal = get_u64(encoded, 40U);
    if (ordinal == 0U) return false;
    if (!std::all_of(encoded.begin() + 368, encoded.end(),
                     [](const std::uint8_t value) { return value == 0U; })) {
        return false;
    }
    record = AppraiserReceiptRecordV1{};
    record.claim_flags = flags;
    record.report_ordinal = ordinal;
    get_binding(encoded, 48U, record.challenge);
    get_binding(encoded, 80U, record.appraiser_constitution);
    get_binding(encoded, 112U, record.actor_epoch);
    get_binding(encoded, 144U, record.v15_exec_input);
    get_binding(encoded, 176U, record.v16_static_envelope);
    get_binding(encoded, 208U, record.installed_policy);
    get_binding(encoded, 240U, record.kernel_surfaces);
    get_binding(encoded, 272U, record.process_coordinate);
    get_binding(encoded, 304U, record.v14_dossier);
    get_binding(encoded, 336U, record.hold_token);
    return true;
}

bool verify_appraiser_receipt_ed25519(
    const AppraiserPublicKey& public_key,
    const AppraiserReceiptBytes& message,
    const AppraiserReceiptSignature& signature) noexcept {
    EVP_PKEY* key = EVP_PKEY_new_raw_public_key(
        EVP_PKEY_ED25519, nullptr, public_key.data(), public_key.size());
    if (key == nullptr) return false;
    EVP_MD_CTX* context = EVP_MD_CTX_new();
    if (context == nullptr) {
        EVP_PKEY_free(key);
        return false;
    }
    const bool initialized = EVP_DigestVerifyInit(
        context, nullptr, nullptr, nullptr, key) == 1;
    const bool verified = initialized && EVP_DigestVerify(
        context, signature.data(), signature.size(), message.data(),
        message.size()) == 1;
    EVP_MD_CTX_free(context);
    EVP_PKEY_free(key);
    return verified;
}

AppraiserReceiptAssessment assess_appraiser_receipt(
    const AppraiserReceiptObservationV1& observation) noexcept {
    AppraiserReceiptAssessment result;
    const Fields values = fields(observation);
    if (!coherent_prefix(values)) {
        result.disposition = AppraiserReceiptDisposition::observation_incoherent;
        return result;
    }
    result.observation_coherent = true;
    const std::size_t cut = true_prefix(values);
    result.disposition = disposition_for_cut(cut);
    result.canonical_receipt_bound = prefix(values, 23U);
    result.signed_appraiser_statement_bound = prefix(values, 27U);
    result.one_report_consumption_bound = prefix(values, 28U);
    result.independent_appraiser_constitution_bound = prefix(values, 32U);
    result.process_lifetime_coordinate_bound = prefix(values, 33U);
    result.installed_policy_bound = prefix(values, 34U);
    result.kernel_surfaces_bound = prefix(values, 35U);
    result.v14_dossier_bound = prefix(values, 36U);
    result.independently_appraised_actor_premise_bound = prefix(values, 39U);
    result.eligible_for_v13_actor_premise =
        result.independently_appraised_actor_premise_bound;
    return result;
}

const char* appraiser_receipt_disposition_name(
    const AppraiserReceiptDisposition value) noexcept {
    switch (value) {
    case AppraiserReceiptDisposition::observation_incoherent: return "OBSERVATION_INCOHERENT";
    case AppraiserReceiptDisposition::profile_unavailable: return "PROFILE_UNAVAILABLE";
    case AppraiserReceiptDisposition::v16_actor_epoch_unavailable: return "V16_ACTOR_EPOCH_UNAVAILABLE";
    case AppraiserReceiptDisposition::appraiser_constitution_unavailable: return "APPRAISER_CONSTITUTION_UNAVAILABLE";
    case AppraiserReceiptDisposition::receipt_length_rejected: return "RECEIPT_LENGTH_REJECTED";
    case AppraiserReceiptDisposition::receipt_decode_rejected: return "RECEIPT_DECODE_REJECTED";
    case AppraiserReceiptDisposition::receipt_canonicality_rejected: return "RECEIPT_CANONICALITY_REJECTED";
    case AppraiserReceiptDisposition::receipt_domain_rejected: return "RECEIPT_DOMAIN_REJECTED";
    case AppraiserReceiptDisposition::receipt_schema_rejected: return "RECEIPT_SCHEMA_REJECTED";
    case AppraiserReceiptDisposition::receipt_reserved_bytes_rejected: return "RECEIPT_RESERVED_BYTES_REJECTED";
    case AppraiserReceiptDisposition::receipt_claim_flags_rejected: return "RECEIPT_CLAIM_FLAGS_REJECTED";
    case AppraiserReceiptDisposition::report_ordinal_rejected: return "REPORT_ORDINAL_REJECTED";
    case AppraiserReceiptDisposition::challenge_freshness_unproved: return "CHALLENGE_FRESHNESS_UNPROVED";
    case AppraiserReceiptDisposition::challenge_binding_mismatch: return "CHALLENGE_BINDING_MISMATCH";
    case AppraiserReceiptDisposition::constitution_binding_mismatch: return "CONSTITUTION_BINDING_MISMATCH";
    case AppraiserReceiptDisposition::actor_epoch_binding_mismatch: return "ACTOR_EPOCH_BINDING_MISMATCH";
    case AppraiserReceiptDisposition::v15_exec_input_binding_mismatch: return "V15_EXEC_INPUT_BINDING_MISMATCH";
    case AppraiserReceiptDisposition::v16_static_envelope_binding_mismatch: return "V16_STATIC_ENVELOPE_BINDING_MISMATCH";
    case AppraiserReceiptDisposition::installed_policy_binding_mismatch: return "INSTALLED_POLICY_BINDING_MISMATCH";
    case AppraiserReceiptDisposition::kernel_surface_binding_mismatch: return "KERNEL_SURFACE_BINDING_MISMATCH";
    case AppraiserReceiptDisposition::process_coordinate_binding_mismatch: return "PROCESS_COORDINATE_BINDING_MISMATCH";
    case AppraiserReceiptDisposition::v14_dossier_binding_mismatch: return "V14_DOSSIER_BINDING_MISMATCH";
    case AppraiserReceiptDisposition::hold_token_binding_mismatch: return "HOLD_TOKEN_BINDING_MISMATCH";
    case AppraiserReceiptDisposition::observation_order_rejected: return "OBSERVATION_ORDER_REJECTED";
    case AppraiserReceiptDisposition::signature_suite_rejected: return "SIGNATURE_SUITE_REJECTED";
    case AppraiserReceiptDisposition::public_key_pin_unproved: return "PUBLIC_KEY_PIN_UNPROVED";
    case AppraiserReceiptDisposition::signature_length_rejected: return "SIGNATURE_LENGTH_REJECTED";
    case AppraiserReceiptDisposition::signature_invalid: return "SIGNATURE_INVALID";
    case AppraiserReceiptDisposition::report_consumption_unproved: return "REPORT_CONSUMPTION_UNPROVED";
    case AppraiserReceiptDisposition::appraiser_process_not_separate: return "APPRAISER_PROCESS_NOT_SEPARATE";
    case AppraiserReceiptDisposition::administration_root_not_distinct: return "ADMINISTRATION_ROOT_NOT_DISTINCT";
    case AppraiserReceiptDisposition::independent_key_custody_unproved: return "INDEPENDENT_KEY_CUSTODY_UNPROVED";
    case AppraiserReceiptDisposition::independent_input_custody_unproved: return "INDEPENDENT_INPUT_CUSTODY_UNPROVED";
    case AppraiserReceiptDisposition::process_lifetime_coordinate_unproved: return "PROCESS_LIFETIME_COORDINATE_UNPROVED";
    case AppraiserReceiptDisposition::installed_policy_reconstruction_unproved: return "INSTALLED_POLICY_RECONSTRUCTION_UNPROVED";
    case AppraiserReceiptDisposition::kernel_surface_reconstruction_unproved: return "KERNEL_SURFACE_RECONSTRUCTION_UNPROVED";
    case AppraiserReceiptDisposition::v14_dossier_reopen_unproved: return "V14_DOSSIER_REOPEN_UNPROVED";
    case AppraiserReceiptDisposition::same_root_mutation_path_open: return "SAME_ROOT_MUTATION_PATH_OPEN";
    case AppraiserReceiptDisposition::actor_epoch_hold_unproved: return "ACTOR_EPOCH_HOLD_UNPROVED";
    case AppraiserReceiptDisposition::portable_replay_open: return "PORTABLE_REPLAY_OPEN";
    case AppraiserReceiptDisposition::independently_appraised_actor_premise: return "INDEPENDENTLY_APPRAISED_ACTOR_PREMISE";
    }
    return "UNKNOWN";
}

}  // namespace slopos::e0::handoff_cell
