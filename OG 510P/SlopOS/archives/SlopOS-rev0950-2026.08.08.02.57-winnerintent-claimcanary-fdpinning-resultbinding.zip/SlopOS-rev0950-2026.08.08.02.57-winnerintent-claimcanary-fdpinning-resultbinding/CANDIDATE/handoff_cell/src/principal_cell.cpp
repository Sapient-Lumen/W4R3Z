#include "slopos/e0/handoff_cell/principal_cell.hpp"

#include <array>
#include <cerrno>
#include <cstddef>
#include <cstring>
#include <utility>

#include <fcntl.h>
#include <linux/fs.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <unistd.h>

namespace slopos::e0::handoff_cell {
namespace {

using generation_journal::EncodedRecord;
using generation_journal::Record;
using generation_journal::RecordKind;
using generation_journal::Result;

[[nodiscard]] int rename_no_replace(const int directory_fd,
                                    const char* source,
                                    const char* destination) noexcept {
#if defined(SYS_renameat2)
    return static_cast<int>(::syscall(
        SYS_renameat2, directory_fd, source, directory_fd, destination,
        static_cast<unsigned int>(RENAME_NOREPLACE)));
#else
    (void)directory_fd;
    (void)source;
    (void)destination;
    errno = ENOSYS;
    return -1;
#endif
}

[[nodiscard]] bool write_complete(const int fd, const EncodedRecord& bytes,
                                  int& error_number) noexcept {
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const ssize_t count = ::write(fd, bytes.data() + offset,
                                      bytes.size() - offset);
        if (count < 0) {
            if (errno == EINTR) continue;
            error_number = errno;
            return false;
        }
        if (count == 0) {
            error_number = EIO;
            return false;
        }
        offset += static_cast<std::size_t>(count);
    }
    return true;
}

[[nodiscard]] bool read_complete(const int fd, EncodedRecord& bytes,
                                 int& error_number) noexcept {
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const ssize_t count = ::read(fd, bytes.data() + offset,
                                     bytes.size() - offset);
        if (count < 0) {
            if (errno == EINTR) continue;
            error_number = errno;
            return false;
        }
        if (count == 0) {
            error_number = EIO;
            return false;
        }
        offset += static_cast<std::size_t>(count);
    }
    return true;
}

[[nodiscard]] const char* result_leaf(const std::uint64_t version) noexcept {
    return version == 1U ? kResultV1Leaf
         : version == 2U ? kResultV2Leaf : nullptr;
}

[[nodiscard]] const char* result_stage_leaf(
    const std::uint64_t version) noexcept {
    return version == 1U ? kResultStageV1Leaf
         : version == 2U ? kResultStageV2Leaf : nullptr;
}

[[nodiscard]] const char* publication_leaf(
    const std::uint64_t version) noexcept {
    return version == 1U ? kPublicationV1Leaf
         : version == 2U ? kPublicationV2Leaf : nullptr;
}

[[nodiscard]] const char* publication_stage_leaf(
    const std::uint64_t version) noexcept {
    return version == 1U ? kPublicationStageV1Leaf
         : version == 2U ? kPublicationStageV2Leaf : nullptr;
}

[[nodiscard]] bool same_operation(const Record& left,
                                  const Record& right) noexcept {
    return left.generation_from == right.generation_from
        && left.generation_to == right.generation_to
        && left.operation_binding == right.operation_binding
        && left.spent_receipt_binding == right.spent_receipt_binding
        && left.consumed_dispatch == right.consumed_dispatch;
}

[[nodiscard]] ExactRecordResult query_exact(
    const int directory_fd, const char* leaf, const EncodedRecord& expected,
    const RecordKind expected_kind) noexcept {
    if (directory_fd < 0 || leaf == nullptr) {
        return {ExactRecordDisposition::io_error, EINVAL, 0U};
    }
    const int fd = ::openat(directory_fd, leaf,
                            O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK);
    if (fd < 0) {
        const int observed = errno;
        if (observed == ENOENT) {
            return {ExactRecordDisposition::missing, observed, 0U};
        }
        return {ExactRecordDisposition::io_error, observed, 0U};
    }

    struct stat status {};
    if (::fstat(fd, &status) != 0) {
        const int observed = errno;
        (void)::close(fd);
        return {ExactRecordDisposition::io_error, observed, 0U};
    }
    const auto links = static_cast<std::uint64_t>(status.st_nlink);
    if (!S_ISREG(status.st_mode)) {
        (void)::close(fd);
        return {ExactRecordDisposition::not_regular, 0, links};
    }
    if (status.st_size != static_cast<off_t>(expected.size())) {
        (void)::close(fd);
        return {ExactRecordDisposition::wrong_size, 0, links};
    }
    if (status.st_nlink != 1) {
        (void)::close(fd);
        return {ExactRecordDisposition::alias_detected, 0, links};
    }

    EncodedRecord observed{};
    int read_error = 0;
    if (!read_complete(fd, observed, read_error)) {
        (void)::close(fd);
        return {ExactRecordDisposition::io_error, read_error, links};
    }
    std::array<std::uint8_t, 1U> surplus{};
    ssize_t surplus_count = -1;
    do {
        surplus_count = ::read(fd, surplus.data(), surplus.size());
    } while (surplus_count < 0 && errno == EINTR);
    const int surplus_error = surplus_count < 0 ? errno : 0;
    const int close_result = ::close(fd);
    const int close_error = close_result != 0 ? errno : 0;
    if (surplus_count < 0) {
        return {ExactRecordDisposition::io_error, surplus_error, links};
    }
    if (close_result != 0) {
        return {ExactRecordDisposition::io_error, close_error, links};
    }
    if (surplus_count != 0) {
        return {ExactRecordDisposition::wrong_size, 0, links};
    }
    if (observed != expected) {
        return {ExactRecordDisposition::exact_mismatch, 0, links};
    }
    Record decoded;
    if (!generation_journal::decode_record(observed, decoded)) {
        return {ExactRecordDisposition::decode_rejected, 0, links};
    }
    if (decoded.kind != expected_kind) {
        return {ExactRecordDisposition::wrong_record_kind, 0, links};
    }
    return {ExactRecordDisposition::exact, 0, links};
}

[[nodiscard]] bool read_record(const int directory_fd, const char* leaf,
                               EncodedRecord& encoded, Record& decoded,
                               int& error_number) noexcept {
    error_number = 0;
    const int fd = ::openat(directory_fd, leaf,
                            O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK);
    if (fd < 0) {
        error_number = errno;
        return false;
    }
    struct stat status {};
    if (::fstat(fd, &status) != 0) {
        error_number = errno;
        (void)::close(fd);
        return false;
    }
    if (!S_ISREG(status.st_mode)
        || status.st_size != static_cast<off_t>(encoded.size())
        || status.st_nlink != 1) {
        error_number = EINVAL;
        (void)::close(fd);
        return false;
    }
    if (!read_complete(fd, encoded, error_number)) {
        (void)::close(fd);
        return false;
    }
    const int close_result = ::close(fd);
    if (close_result != 0) {
        error_number = errno;
        return false;
    }
    if (!generation_journal::decode_record(encoded, decoded)) {
        error_number = EINVAL;
        return false;
    }
    return true;
}

[[nodiscard]] AppendResult append_fixed(
    const int directory_fd, const EncodedRecord& encoded,
    const char* stage_leaf, const char* final_leaf) noexcept {
    const int fd = ::openat(directory_fd, stage_leaf,
                            O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC
                                | O_NOFOLLOW,
                            S_IRUSR | S_IWUSR);
    if (fd < 0) {
        const int observed = errno;
        if (observed == EEXIST) {
            return {AppendDisposition::stage_exists, observed};
        }
        return {AppendDisposition::io_error, observed};
    }
    int write_error = 0;
    if (!write_complete(fd, encoded, write_error)) {
        (void)::close(fd);
        return {AppendDisposition::io_error, write_error};
    }
    if (::fchmod(fd, S_IRUSR) != 0) {
        const int observed = errno;
        (void)::close(fd);
        return {AppendDisposition::io_error, observed};
    }
    if (::fsync(fd) != 0) {
        const int observed = errno;
        (void)::close(fd);
        return {AppendDisposition::io_error, observed};
    }
    if (::close(fd) != 0) {
        return {AppendDisposition::io_error, errno};
    }

    if (rename_no_replace(directory_fd, stage_leaf, final_leaf) != 0) {
        const int observed = errno;
        if (observed == EEXIST) {
            return {AppendDisposition::final_exists, observed};
        }
        if (observed == ENOSYS || observed == EINVAL) {
            return {AppendDisposition::unsupported, observed};
        }
        return {AppendDisposition::io_error, observed};
    }
    if (::fsync(directory_fd) == 0) {
        return {AppendDisposition::bound_and_synced, 0};
    }
    return {AppendDisposition::bound_sync_uncertain, errno};
}

}  // namespace

PrincipalCell::PrincipalCell(PrincipalCell&& other) noexcept
    : directory_fd_(other.directory_fd_), provider_uid_(other.provider_uid_) {
    other.directory_fd_ = -1;
    other.provider_uid_ = 0;
}

PrincipalCell& PrincipalCell::operator=(PrincipalCell&& other) noexcept {
    if (this != &other) {
        if (directory_fd_ >= 0) (void)::close(directory_fd_);
        directory_fd_ = other.directory_fd_;
        provider_uid_ = other.provider_uid_;
        other.directory_fd_ = -1;
        other.provider_uid_ = 0;
    }
    return *this;
}

PrincipalCell::~PrincipalCell() {
    if (directory_fd_ >= 0) (void)::close(directory_fd_);
}

std::optional<PrincipalCell> PrincipalCell::create_fixed_beneath(
    const int provider_root_fd, const uid_t expected_provider_uid,
    int& error_number) noexcept {
    error_number = 0;
    if (expected_provider_uid == 0 || ::geteuid() != expected_provider_uid) {
        error_number = EPERM;
        return std::nullopt;
    }
    struct stat root_status {};
    if (::fstat(provider_root_fd, &root_status) != 0) {
        error_number = errno;
        return std::nullopt;
    }
    if (!S_ISDIR(root_status.st_mode)
        || root_status.st_uid != expected_provider_uid
        || (root_status.st_mode & 0777U) != 0700U) {
        error_number = EPERM;
        return std::nullopt;
    }
    if (::mkdirat(provider_root_fd, kProviderCellLeaf, 0700) != 0) {
        error_number = errno;
        return std::nullopt;
    }
    const int cell_fd = ::openat(provider_root_fd, kProviderCellLeaf,
                                 O_RDONLY | O_DIRECTORY | O_CLOEXEC
                                     | O_NOFOLLOW);
    if (cell_fd < 0) {
        error_number = errno;
        return std::nullopt;
    }
    struct stat cell_status {};
    if (::fstat(cell_fd, &cell_status) != 0
        || !S_ISDIR(cell_status.st_mode)
        || cell_status.st_uid != expected_provider_uid
        || (cell_status.st_mode & 0777U) != 0700U) {
        error_number = errno == 0 ? EPERM : errno;
        (void)::close(cell_fd);
        return std::nullopt;
    }
    if (::fsync(provider_root_fd) != 0) {
        error_number = errno;
        (void)::close(cell_fd);
        return std::nullopt;
    }
    return PrincipalCell(cell_fd, expected_provider_uid);
}

StageResult PrincipalCell::stage_pending_exact(
    const EncodedRecord& pending) noexcept {
    if (directory_fd_ < 0 || ::geteuid() != provider_uid_) {
        return {StageDisposition::io_error, EPERM};
    }
    Record decoded;
    if (!generation_journal::decode_record(pending, decoded)
        || decoded.kind != RecordKind::pending) {
        return {StageDisposition::invalid_pending, EINVAL};
    }
    const int fd = ::openat(directory_fd_, kLiveLeaf,
                            O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC
                                | O_NOFOLLOW,
                            S_IRUSR | S_IWUSR);
    if (fd < 0) {
        const int observed = errno;
        if (observed == EEXIST) {
            return {StageDisposition::live_exists, observed};
        }
        return {StageDisposition::io_error, observed};
    }
    int write_error = 0;
    if (!write_complete(fd, pending, write_error)) {
        (void)::close(fd);
        return {StageDisposition::io_error, write_error};
    }
    if (::fchmod(fd, S_IRUSR) != 0) {
        const int observed = errno;
        (void)::close(fd);
        return {StageDisposition::io_error, observed};
    }
    if (::fsync(fd) != 0) {
        const int observed = errno;
        (void)::close(fd);
        return {StageDisposition::io_error, observed};
    }
    if (::close(fd) != 0) {
        return {StageDisposition::io_error, errno};
    }
    if (::fsync(directory_fd_) != 0) {
        return {StageDisposition::io_error, errno};
    }
    return {StageDisposition::staged_and_synced, 0};
}

BurnResult PrincipalCell::burn_before_decode() noexcept {
    if (directory_fd_ < 0 || ::geteuid() != provider_uid_) {
        return {BurnDisposition::io_error, EPERM};
    }
    int error_number = 0;
    auto cell = Cell::retain_host_directory(directory_fd_, error_number);
    if (!cell.has_value()) {
        return {BurnDisposition::io_error, error_number};
    }
    return cell->burn_before_decode();
}

PendingResult PrincipalCell::query_pending_exact(
    const EncodedRecord& expected) const noexcept {
    if (directory_fd_ < 0 || ::geteuid() != provider_uid_) {
        return {PendingDisposition::io_error, EPERM, 0U};
    }
    int error_number = 0;
    auto cell = Cell::retain_host_directory(directory_fd_, error_number);
    if (!cell.has_value()) {
        return {PendingDisposition::io_error, error_number, 0U};
    }
    return cell->query_pending_exact(expected);
}

AppendResult PrincipalCell::append_result_exact(
    const EncodedRecord& encoded) noexcept {
    if (directory_fd_ < 0 || ::geteuid() != provider_uid_) {
        return {AppendDisposition::io_error, EPERM};
    }
    Record candidate;
    if (!generation_journal::decode_record(encoded, candidate)) {
        return {AppendDisposition::invalid_record, EINVAL};
    }
    if (candidate.kind != RecordKind::result) {
        return {AppendDisposition::wrong_record_kind, EINVAL};
    }
    if (candidate.sequence == 2U) {
        EncodedRecord prior_encoded{};
        Record prior;
        int prior_error = 0;
        if (!read_record(directory_fd_, kResultV1Leaf, prior_encoded, prior,
                         prior_error)) {
            return {AppendDisposition::missing_predecessor, prior_error};
        }
        if (prior.kind != RecordKind::result || prior.sequence != 1U
            || prior.result != Result::uncertain
            || candidate.result == Result::uncertain
            || !same_operation(prior, candidate)) {
            return {AppendDisposition::refinement_rejected, EINVAL};
        }
    }
    return append_fixed(directory_fd_, encoded,
                        result_stage_leaf(candidate.sequence),
                        result_leaf(candidate.sequence));
}

AppendResult PrincipalCell::append_publication_exact(
    const EncodedRecord& encoded) noexcept {
    if (directory_fd_ < 0 || ::geteuid() != provider_uid_) {
        return {AppendDisposition::io_error, EPERM};
    }
    Record publication;
    if (!generation_journal::decode_record(encoded, publication)) {
        return {AppendDisposition::invalid_record, EINVAL};
    }
    if (publication.kind != RecordKind::publication) {
        return {AppendDisposition::wrong_record_kind, EINVAL};
    }
    EncodedRecord result_encoded{};
    Record result;
    int result_error = 0;
    if (!read_record(directory_fd_, result_leaf(publication.sequence),
                     result_encoded, result, result_error)) {
        return {AppendDisposition::missing_predecessor, result_error};
    }
    if (result.kind != RecordKind::result
        || result.sequence != publication.sequence
        || result.result != publication.result
        || result.reconciled != publication.reconciled
        || !same_operation(result, publication)) {
        return {AppendDisposition::refinement_rejected, EINVAL};
    }
    if (publication.sequence == 2U) {
        EncodedRecord prior_encoded{};
        Record prior;
        int prior_error = 0;
        if (!read_record(directory_fd_, kPublicationV1Leaf, prior_encoded,
                         prior, prior_error)) {
            return {AppendDisposition::missing_predecessor, prior_error};
        }
        if (prior.kind != RecordKind::publication || prior.sequence != 1U
            || prior.result != Result::uncertain
            || !same_operation(prior, publication)) {
            return {AppendDisposition::refinement_rejected, EINVAL};
        }
    }
    return append_fixed(directory_fd_, encoded,
                        publication_stage_leaf(publication.sequence),
                        publication_leaf(publication.sequence));
}

ExactRecordResult PrincipalCell::query_result_exact(
    const std::uint64_t version, const EncodedRecord& expected) const noexcept {
    if (directory_fd_ < 0 || ::geteuid() != provider_uid_) {
        return {ExactRecordDisposition::io_error, EPERM, 0U};
    }
    return query_exact(directory_fd_, result_leaf(version), expected,
                       RecordKind::result);
}

ExactRecordResult PrincipalCell::query_publication_exact(
    const std::uint64_t version, const EncodedRecord& expected) const noexcept {
    if (directory_fd_ < 0 || ::geteuid() != provider_uid_) {
        return {ExactRecordDisposition::io_error, EPERM, 0U};
    }
    return query_exact(directory_fd_, publication_leaf(version), expected,
                       RecordKind::publication);
}

const char* stage_name(const StageDisposition value) noexcept {
    switch (value) {
        case StageDisposition::staged_and_synced: return "STAGED_SYNCED";
        case StageDisposition::live_exists: return "LIVE_EXISTS";
        case StageDisposition::invalid_pending: return "INVALID_PENDING";
        case StageDisposition::io_error: return "IO_ERROR";
    }
    return "IO_ERROR";
}

const char* append_name(const AppendDisposition value) noexcept {
    switch (value) {
        case AppendDisposition::bound_and_synced: return "BOUND_SYNCED";
        case AppendDisposition::bound_sync_uncertain:
            return "BOUND_SYNC_UNCERTAIN";
        case AppendDisposition::stage_exists: return "STAGE_EXISTS";
        case AppendDisposition::final_exists: return "FINAL_EXISTS";
        case AppendDisposition::invalid_record: return "INVALID_RECORD";
        case AppendDisposition::wrong_record_kind: return "WRONG_RECORD_KIND";
        case AppendDisposition::missing_predecessor:
            return "MISSING_PREDECESSOR";
        case AppendDisposition::refinement_rejected:
            return "REFINEMENT_REJECTED";
        case AppendDisposition::unsupported: return "UNSUPPORTED";
        case AppendDisposition::io_error: return "IO_ERROR";
    }
    return "IO_ERROR";
}

const char* exact_record_name(const ExactRecordDisposition value) noexcept {
    switch (value) {
        case ExactRecordDisposition::exact: return "EXACT";
        case ExactRecordDisposition::missing: return "MISSING";
        case ExactRecordDisposition::not_regular: return "NOT_REGULAR";
        case ExactRecordDisposition::wrong_size: return "WRONG_SIZE";
        case ExactRecordDisposition::alias_detected: return "ALIAS_DETECTED";
        case ExactRecordDisposition::exact_mismatch: return "EXACT_MISMATCH";
        case ExactRecordDisposition::decode_rejected: return "DECODE_REJECTED";
        case ExactRecordDisposition::wrong_record_kind:
            return "WRONG_RECORD_KIND";
        case ExactRecordDisposition::io_error: return "IO_ERROR";
    }
    return "IO_ERROR";
}

}  // namespace slopos::e0::handoff_cell
