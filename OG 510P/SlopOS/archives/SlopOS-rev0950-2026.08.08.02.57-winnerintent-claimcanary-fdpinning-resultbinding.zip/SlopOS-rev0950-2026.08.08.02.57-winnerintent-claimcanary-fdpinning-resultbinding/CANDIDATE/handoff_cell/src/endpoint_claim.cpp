#include "slopos/e0/handoff_cell/endpoint_claim.hpp"

#include "slopos/e0/handoff_cell/cell.hpp"

#include <algorithm>
#include <array>
#include <cerrno>
#include <cstddef>
#include <cstdint>
#include <utility>

#include <fcntl.h>
#include <linux/fs.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <unistd.h>

namespace slopos::e0::handoff_cell {
namespace {

using generation_journal::EncodedRecord;
using generation_journal::Record;
using generation_journal::RecordKind;

enum class ReadDisposition : std::uint8_t {
    exact,
    missing,
    not_regular,
    wrong_size,
    alias_detected,
    mutable_or_wrong_owner,
    exact_mismatch,
    decode_rejected,
    wrong_record_kind,
    io_error,
};

struct ReadObservation final {
    ReadDisposition disposition{ReadDisposition::io_error};
    int error_number{0};
    std::uint64_t link_count{0U};
};

[[nodiscard]] int rename_pending_to_claimed(const int directory_fd) noexcept {
#if defined(SYS_renameat2)
    return static_cast<int>(::syscall(
        SYS_renameat2, directory_fd, kPendingLeaf, directory_fd,
        kClaimedLeaf, static_cast<unsigned int>(RENAME_NOREPLACE)));
#else
    (void)directory_fd;
    errno = ENOSYS;
    return -1;
#endif
}

[[nodiscard]] bool read_complete(const int fd, EncodedRecord& bytes,
                                 int& error_number) noexcept {
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const ssize_t count = ::read(fd, bytes.data() + offset,
                                     bytes.size() - offset);
        if (count < 0) {
            if (errno == EINTR) continue;
            error_number = errno;
            return false;
        }
        if (count == 0) {
            error_number = EIO;
            return false;
        }
        offset += static_cast<std::size_t>(count);
    }
    return true;
}

[[nodiscard]] ReadObservation read_claimed_exact(
    const int directory_fd, const uid_t expected_owner,
    const EncodedRecord& expected) noexcept {
    const int fd = ::openat(directory_fd, kClaimedLeaf,
                            O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK);
    if (fd < 0) {
        const int observed = errno;
        return {
            observed == ENOENT ? ReadDisposition::missing
                               : ReadDisposition::io_error,
            observed,
            0U,
        };
    }

    struct stat status {};
    if (::fstat(fd, &status) != 0) {
        const int observed = errno;
        (void)::close(fd);
        return {ReadDisposition::io_error, observed, 0U};
    }
    const auto links = static_cast<std::uint64_t>(status.st_nlink);
    if (!S_ISREG(status.st_mode)) {
        (void)::close(fd);
        return {ReadDisposition::not_regular, 0, links};
    }
    if (status.st_size != static_cast<off_t>(expected.size())) {
        (void)::close(fd);
        return {ReadDisposition::wrong_size, 0, links};
    }
    if (status.st_nlink != 1) {
        (void)::close(fd);
        return {ReadDisposition::alias_detected, 0, links};
    }
    if (status.st_uid != expected_owner
        || (status.st_mode & static_cast<mode_t>(0222)) != 0U) {
        (void)::close(fd);
        return {ReadDisposition::mutable_or_wrong_owner, 0, links};
    }

    EncodedRecord observed{};
    int read_error = 0;
    if (!read_complete(fd, observed, read_error)) {
        (void)::close(fd);
        return {ReadDisposition::io_error, read_error, links};
    }
    std::array<std::uint8_t, 1U> surplus{};
    ssize_t surplus_count = -1;
    do {
        surplus_count = ::read(fd, surplus.data(), surplus.size());
    } while (surplus_count < 0 && errno == EINTR);
    const int surplus_error = surplus_count < 0 ? errno : 0;
    if (::close(fd) != 0) {
        return {ReadDisposition::io_error, errno, links};
    }
    if (surplus_count < 0) {
        return {ReadDisposition::io_error, surplus_error, links};
    }
    if (surplus_count != 0) {
        return {ReadDisposition::wrong_size, 0, links};
    }
    if (observed != expected) {
        return {ReadDisposition::exact_mismatch, 0, links};
    }
    Record record;
    if (!generation_journal::decode_record(observed, record)) {
        return {ReadDisposition::decode_rejected, 0, links};
    }
    if (record.kind != RecordKind::pending) {
        return {ReadDisposition::wrong_record_kind, 0, links};
    }
    return {ReadDisposition::exact, 0, links};
}

[[nodiscard]] EndpointClaimObservation translate(
    const ReadObservation& read, const EndpointClaimDisposition exact,
    const bool namespace_claimed) noexcept {
    EndpointClaimObservation out;
    out.error_number = read.error_number;
    out.link_count = read.link_count;
    out.namespace_claimed = namespace_claimed;
    switch (read.disposition) {
        case ReadDisposition::exact: out.disposition = exact; break;
        case ReadDisposition::missing:
            out.disposition = EndpointClaimDisposition::pending_missing;
            out.namespace_claimed = false;
            break;
        case ReadDisposition::not_regular:
            out.disposition = EndpointClaimDisposition::not_regular; break;
        case ReadDisposition::wrong_size:
            out.disposition = EndpointClaimDisposition::wrong_size; break;
        case ReadDisposition::alias_detected:
            out.disposition = EndpointClaimDisposition::alias_detected; break;
        case ReadDisposition::mutable_or_wrong_owner:
            out.disposition =
                EndpointClaimDisposition::mutable_or_wrong_owner; break;
        case ReadDisposition::exact_mismatch:
            out.disposition = EndpointClaimDisposition::exact_mismatch; break;
        case ReadDisposition::decode_rejected:
            out.disposition = EndpointClaimDisposition::decode_rejected; break;
        case ReadDisposition::wrong_record_kind:
            out.disposition = EndpointClaimDisposition::wrong_record_kind; break;
        case ReadDisposition::io_error:
            out.disposition = EndpointClaimDisposition::io_error; break;
    }
    return out;
}

[[nodiscard]] std::uint32_t load_u32(
    const std::span<const std::uint8_t> bytes,
    const std::size_t offset) noexcept {
    std::uint32_t value = 0U;
    for (std::size_t index = 0U; index < 4U; ++index) {
        value |= static_cast<std::uint32_t>(bytes[offset + index])
            << static_cast<unsigned int>(index * 8U);
    }
    return value;
}

[[nodiscard]] std::uint64_t load_u64(
    const std::span<const std::uint8_t> bytes,
    const std::size_t offset) noexcept {
    std::uint64_t value = 0U;
    for (std::size_t index = 0U; index < 8U; ++index) {
        value |= static_cast<std::uint64_t>(bytes[offset + index])
            << static_cast<unsigned int>(index * 8U);
    }
    return value;
}

[[nodiscard]] bool request_matches(
    const EncodedRecord& encoded,
    const std::span<const std::uint8_t> request) noexcept {
    if (request.size() != kEndpointRequestBytes) return false;
    constexpr std::array<std::uint8_t, 8U> magic{
        'S', 'L', 'O', 'P', 'E', 'P', 'C', '1'};
    if (!std::equal(magic.begin(), magic.end(), request.begin())) return false;
    if (load_u32(request, 8U) != 1U || load_u32(request, 12U) != 0U) {
        return false;
    }
    Record record;
    if (!generation_journal::decode_record(encoded, record)
        || record.kind != RecordKind::pending) {
        return false;
    }
    return load_u64(request, 16U) == record.generation_from
        && load_u64(request, 24U) == record.generation_to
        && std::equal(record.operation_binding.begin(),
                      record.operation_binding.end(), request.begin() + 32)
        && std::equal(record.spent_receipt_binding.begin(),
                      record.spent_receipt_binding.end(), request.begin() + 64);
}

}  // namespace

ClaimedPending::ClaimedPending(const EncodedRecord& encoded) noexcept
    : encoded_(encoded), available_(true) {}

ClaimedPending::ClaimedPending(ClaimedPending&& other) noexcept
    : encoded_(other.encoded_),
      available_(std::exchange(other.available_, false)) {
    other.encoded_.fill(0U);
}

ClaimedPending& ClaimedPending::operator=(ClaimedPending&& other) noexcept {
    if (this != &other) {
        encoded_.fill(0U);
        encoded_ = other.encoded_;
        available_ = std::exchange(other.available_, false);
        other.encoded_.fill(0U);
    }
    return *this;
}

ClaimedPending::~ClaimedPending() {
    encoded_.fill(0U);
    available_ = false;
}

std::optional<EncodedRecord> ClaimedPending::consume() noexcept {
    if (!available_) return std::nullopt;
    available_ = false;
    EncodedRecord out = encoded_;
    encoded_.fill(0U);
    return out;
}

EndpointClaimCell::EndpointClaimCell(EndpointClaimCell&& other) noexcept
    : directory_fd_(std::exchange(other.directory_fd_, -1)),
      expected_owner_(std::exchange(other.expected_owner_, 0U)) {}

EndpointClaimCell& EndpointClaimCell::operator=(
    EndpointClaimCell&& other) noexcept {
    if (this != &other) {
        if (directory_fd_ >= 0) (void)::close(directory_fd_);
        directory_fd_ = std::exchange(other.directory_fd_, -1);
        expected_owner_ = std::exchange(other.expected_owner_, 0U);
    }
    return *this;
}

EndpointClaimCell::~EndpointClaimCell() {
    if (directory_fd_ >= 0) (void)::close(directory_fd_);
}

std::optional<EndpointClaimCell>
EndpointClaimCell::retain_host_cell_directory(
    const int directory_fd, const uid_t expected_owner,
    int& error_number) noexcept {
    error_number = 0;
    if (::geteuid() != expected_owner) {
        error_number = EPERM;
        return std::nullopt;
    }
    struct stat status {};
    if (::fstat(directory_fd, &status) != 0) {
        error_number = errno;
        return std::nullopt;
    }
    if (!S_ISDIR(status.st_mode) || status.st_uid != expected_owner
        || (status.st_mode & static_cast<mode_t>(0777)) != 0700U) {
        error_number = EPERM;
        return std::nullopt;
    }
    const int duplicate = ::fcntl(directory_fd, F_DUPFD_CLOEXEC, 3);
    if (duplicate < 0) {
        error_number = errno;
        return std::nullopt;
    }
    return EndpointClaimCell(duplicate, expected_owner);
}

EndpointClaimAttempt EndpointClaimCell::claim_pending_exact(
    const EncodedRecord& expected) noexcept {
    EndpointClaimAttempt attempt;
    if (directory_fd_ < 0) {
        attempt.observation = {
            EndpointClaimDisposition::io_error, EBADF, 0U, false, true, false};
        return attempt;
    }

    // Complete pre-semantic mutation boundary.
    if (rename_pending_to_claimed(directory_fd_) == 0) {
        const bool synced = ::fsync(directory_fd_) == 0;
        const int sync_error = synced ? 0 : errno;
        const ReadObservation read = read_claimed_exact(
            directory_fd_, expected_owner_, expected);
        attempt.observation = translate(
            read,
            synced ? EndpointClaimDisposition::claimed_exact
                   : EndpointClaimDisposition::claimed_exact_sync_uncertain,
            true);
        if (!synced && attempt.observation.error_number == 0) {
            attempt.observation.error_number = sync_error;
        }
        // A known directory-sync failure cannot mint the first semantic
        // capability. The namespace cut remains visible and query-only, but a
        // future effect must not be composed atop an explicitly uncertain cut.
        if (synced && read.disposition == ReadDisposition::exact) {
            attempt.observation.query_only = false;
            ClaimedPending token(expected);
            attempt.fresh = std::optional<ClaimedPending>(std::move(token));
        }
        return attempt;
    }

    const int observed = errno;
    if (observed == ENOSYS || observed == EINVAL) {
        attempt.observation = {
            EndpointClaimDisposition::unsupported, observed, 0U,
            false, true, false};
        return attempt;
    }
    if (observed != EEXIST && observed != ENOENT) {
        attempt.observation = {
            EndpointClaimDisposition::io_error, observed, 0U,
            false, true, false};
        return attempt;
    }
    const ReadObservation read = read_claimed_exact(
        directory_fd_, expected_owner_, expected);
    attempt.observation = translate(
        read, EndpointClaimDisposition::already_claimed_exact,
        read.disposition != ReadDisposition::missing);
    if (read.disposition == ReadDisposition::missing) {
        attempt.observation.error_number = observed;
    }
    return attempt;
}

EndpointClaimObservation EndpointClaimCell::observe_claimed_exact(
    const EncodedRecord& expected) const noexcept {
    if (directory_fd_ < 0) {
        return {
            EndpointClaimDisposition::io_error, EBADF, 0U, false, true, false};
    }
    const ReadObservation read = read_claimed_exact(
        directory_fd_, expected_owner_, expected);
    return translate(read, EndpointClaimDisposition::already_claimed_exact,
                     read.disposition != ReadDisposition::missing);
}

PayloadParseResult PayloadAfterClaim::parse_exact_impl(
    ClaimedPending&& claim,
    const std::span<const std::uint8_t> request,
    EncodedRecord* const consumed) noexcept {
    // Burn before even request length is observed.
    std::optional<EncodedRecord> encoded = claim.consume();
    if (!encoded.has_value()) {
        if (consumed != nullptr) consumed->fill(0U);
        return {PayloadDisposition::claim_missing_or_spent,
                false, false, false};
    }
    if (consumed != nullptr) *consumed = *encoded;
    return {
        request_matches(*encoded, request)
            ? PayloadDisposition::exact_request
            : PayloadDisposition::malformed_request,
        true,
        false,
        false,
    };
}

PayloadParseResult PayloadAfterClaim::parse_exact(
    ClaimedPending&& claim,
    const std::span<const std::uint8_t> request) noexcept {
    return parse_exact_impl(std::move(claim), request, nullptr);
}

const char* endpoint_claim_name(const EndpointClaimDisposition value) noexcept {
    switch (value) {
        case EndpointClaimDisposition::claimed_exact: return "CLAIMED_EXACT";
        case EndpointClaimDisposition::claimed_exact_sync_uncertain:
            return "CLAIMED_EXACT_SYNC_UNCERTAIN";
        case EndpointClaimDisposition::already_claimed_exact:
            return "ALREADY_CLAIMED_EXACT";
        case EndpointClaimDisposition::pending_missing: return "PENDING_MISSING";
        case EndpointClaimDisposition::not_regular: return "NOT_REGULAR";
        case EndpointClaimDisposition::wrong_size: return "WRONG_SIZE";
        case EndpointClaimDisposition::alias_detected: return "ALIAS_DETECTED";
        case EndpointClaimDisposition::mutable_or_wrong_owner:
            return "MUTABLE_OR_WRONG_OWNER";
        case EndpointClaimDisposition::exact_mismatch: return "EXACT_MISMATCH";
        case EndpointClaimDisposition::decode_rejected: return "DECODE_REJECTED";
        case EndpointClaimDisposition::wrong_record_kind:
            return "WRONG_RECORD_KIND";
        case EndpointClaimDisposition::unsupported: return "UNSUPPORTED";
        case EndpointClaimDisposition::io_error: return "IO_ERROR";
    }
    return "IO_ERROR";
}

const char* payload_disposition_name(const PayloadDisposition value) noexcept {
    switch (value) {
        case PayloadDisposition::exact_request: return "EXACT_REQUEST";
        case PayloadDisposition::malformed_request: return "MALFORMED_REQUEST";
        case PayloadDisposition::claim_missing_or_spent:
            return "CLAIM_MISSING_OR_SPENT";
    }
    return "CLAIM_MISSING_OR_SPENT";
}

}  // namespace slopos::e0::handoff_cell
