#include "slopos/e0/handoff_cell/provider_endpoint.hpp"

#include <array>
#include <cerrno>
#include <cstdio>
#include <cstring>
#include <limits>
#include <utility>

#include <fcntl.h>
#include <poll.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/un.h>
#include <unistd.h>

#ifndef SO_PASSPIDFD
#define SO_PASSPIDFD 76
#endif
#ifndef SO_PEERPIDFD
#define SO_PEERPIDFD 77
#endif

namespace slopos::e0::handoff_cell {
namespace {

struct DirectoryExpectation final {
    uid_t owner{0U};
    mode_t mode{0U};
};

[[nodiscard]] bool directory_matches(
    const int fd, const DirectoryExpectation expected,
    struct stat& observed, int& error_number) noexcept {
    if (::fstat(fd, &observed) != 0) {
        error_number = errno;
        return false;
    }
    if (!S_ISDIR(observed.st_mode)
        || observed.st_uid != expected.owner
        || (observed.st_mode & static_cast<mode_t>(0777)) != expected.mode) {
        error_number = EPERM;
        return false;
    }
    return true;
}

[[nodiscard]] bool fixed_proc_path(
    const int directory_fd, const char* const leaf,
    std::array<char, sizeof(sockaddr_un::sun_path)>& path,
    int& error_number) noexcept {
    if (directory_fd < 0 || leaf == nullptr) {
        error_number = EBADF;
        return false;
    }
    const int written = std::snprintf(
        path.data(), path.size(), "/proc/self/fd/%d/%s", directory_fd, leaf);
    if (written < 0
        || static_cast<std::size_t>(written) >= path.size()) {
        error_number = ENAMETOOLONG;
        return false;
    }
    struct stat descriptor_status {};
    struct stat path_status {};
    std::array<char, 64U> descriptor_path{};
    const int descriptor_written = std::snprintf(
        descriptor_path.data(), descriptor_path.size(),
        "/proc/self/fd/%d", directory_fd);
    if (descriptor_written < 0
        || static_cast<std::size_t>(descriptor_written)
            >= descriptor_path.size()) {
        error_number = ENAMETOOLONG;
        return false;
    }
    if (::fstat(directory_fd, &descriptor_status) != 0
        || ::stat(descriptor_path.data(), &path_status) != 0) {
        error_number = errno;
        return false;
    }
    if (descriptor_status.st_dev != path_status.st_dev
        || descriptor_status.st_ino != path_status.st_ino) {
        error_number = EXDEV;
        return false;
    }
    return true;
}

[[nodiscard]] bool make_address(
    const std::array<char, sizeof(sockaddr_un::sun_path)>& path,
    sockaddr_un& address, socklen_t& length,
    int& error_number) noexcept {
    const std::size_t path_length = std::strlen(path.data());
    if (path_length == 0U || path_length >= sizeof(address.sun_path)) {
        error_number = ENAMETOOLONG;
        return false;
    }
    address = sockaddr_un{};
    address.sun_family = AF_UNIX;
    std::memcpy(address.sun_path, path.data(), path_length + 1U);
    const std::size_t total = offsetof(sockaddr_un, sun_path)
        + path_length + 1U;
    if (total > static_cast<std::size_t>(
            std::numeric_limits<socklen_t>::max())) {
        error_number = EOVERFLOW;
        return false;
    }
    length = static_cast<socklen_t>(total);
    return true;
}

[[nodiscard]] bool enable_message_identity(
    const int fd, int& error_number) noexcept {
    const int enabled = 1;
    if (::setsockopt(fd, SOL_SOCKET, SO_PASSCRED, &enabled,
                     sizeof(enabled)) != 0
        || ::setsockopt(fd, SOL_SOCKET, SO_PASSPIDFD, &enabled,
                        sizeof(enabled)) != 0) {
        error_number = errno;
        return false;
    }
    return true;
}

[[nodiscard]] bool process_identity(
    const int pidfd, EndpointProcessIdentity& identity,
    int& error_number) noexcept {
    struct stat status {};
    if (::fstat(pidfd, &status) != 0) {
        error_number = errno;
        return false;
    }
    const int descriptor_flags = ::fcntl(pidfd, F_GETFD);
    if (descriptor_flags < 0) {
        error_number = errno;
        return false;
    }
    identity.device = static_cast<std::uint64_t>(status.st_dev);
    identity.inode = static_cast<std::uint64_t>(status.st_ino);
    if (!identity.valid() || (descriptor_flags & FD_CLOEXEC) == 0) {
        error_number = EPROTO;
        return false;
    }
    return true;
}

[[nodiscard]] bool read_peer(
    const int fd, EndpointPeer& peer, int& peer_pidfd,
    int& error_number) noexcept {
    struct ucred credential {};
    socklen_t credential_length = sizeof(credential);
    if (::getsockopt(fd, SOL_SOCKET, SO_PEERCRED,
                     &credential, &credential_length) != 0) {
        error_number = errno;
        return false;
    }
    if (credential_length != sizeof(credential)) {
        error_number = EPROTO;
        return false;
    }
    int observed_pidfd = -1;
    socklen_t pidfd_length = sizeof(observed_pidfd);
    if (::getsockopt(fd, SOL_SOCKET, SO_PEERPIDFD,
                     &observed_pidfd, &pidfd_length) != 0) {
        error_number = errno;
        return false;
    }
    if (pidfd_length != sizeof(observed_pidfd) || observed_pidfd < 0) {
        if (observed_pidfd >= 0) (void)::close(observed_pidfd);
        error_number = EPROTO;
        return false;
    }
    EndpointProcessIdentity identity{};
    if (!process_identity(observed_pidfd, identity, error_number)) {
        (void)::close(observed_pidfd);
        return false;
    }
    peer.pid = credential.pid;
    peer.uid = credential.uid;
    peer.gid = credential.gid;
    peer.process = identity;
    peer_pidfd = observed_pidfd;
    return true;
}

[[nodiscard]] bool fixed_socket_matches(
    const int directory_fd, const char* const leaf,
    const uid_t expected_owner, struct stat& observed,
    int& error_number) noexcept {
    if (::fstatat(directory_fd, leaf, &observed,
                  AT_SYMLINK_NOFOLLOW) != 0) {
        error_number = errno;
        return false;
    }
    if (!S_ISSOCK(observed.st_mode)
        || observed.st_uid != expected_owner
        || (observed.st_mode & static_cast<mode_t>(0777))
            != static_cast<mode_t>(0222)
        || observed.st_nlink != 1) {
        error_number = EPERM;
        return false;
    }
    return true;
}

}  // namespace

EndpointConnection::EndpointConnection(EndpointConnection&& other) noexcept
    : fd_(std::exchange(other.fd_, -1)),
      peer_pidfd_(std::exchange(other.peer_pidfd_, -1)),
      peer_(other.peer_) {}

EndpointConnection& EndpointConnection::operator=(
    EndpointConnection&& other) noexcept {
    if (this != &other) {
        if (fd_ >= 0) (void)::close(fd_);
        if (peer_pidfd_ >= 0) (void)::close(peer_pidfd_);
        fd_ = std::exchange(other.fd_, -1);
        peer_pidfd_ = std::exchange(other.peer_pidfd_, -1);
        peer_ = other.peer_;
    }
    return *this;
}

EndpointConnection::~EndpointConnection() {
    if (fd_ >= 0) (void)::close(fd_);
    if (peer_pidfd_ >= 0) (void)::close(peer_pidfd_);
}

bool EndpointConnection::peer_process_exited(
    const int timeout_milliseconds, int& error_number) const noexcept {
    error_number = 0;
    if (peer_pidfd_ < 0 || timeout_milliseconds < 0) {
        error_number = EINVAL;
        return false;
    }
    pollfd descriptor{peer_pidfd_, POLLIN | POLLHUP, 0};
    int result = -1;
    do {
        result = ::poll(&descriptor, 1U, timeout_milliseconds);
    } while (result < 0 && errno == EINTR);
    if (result < 0) {
        error_number = errno;
        return false;
    }
    if (result == 0) return false;
    if ((descriptor.revents
         & static_cast<short>(POLLIN | POLLHUP)) != 0) {
        return true;
    }
    error_number = EIO;
    return false;
}

ProviderEndpoint::ProviderEndpoint(ProviderEndpoint&& other) noexcept
    : listener_fd_(std::exchange(other.listener_fd_, -1)),
      provider_uid_(other.provider_uid_), provider_gid_(other.provider_gid_) {}

ProviderEndpoint& ProviderEndpoint::operator=(
    ProviderEndpoint&& other) noexcept {
    if (this != &other) {
        if (listener_fd_ >= 0) (void)::close(listener_fd_);
        listener_fd_ = std::exchange(other.listener_fd_, -1);
        provider_uid_ = other.provider_uid_;
        provider_gid_ = other.provider_gid_;
    }
    return *this;
}

ProviderEndpoint::~ProviderEndpoint() {
    if (listener_fd_ >= 0) (void)::close(listener_fd_);
}

std::optional<ProviderEndpoint> ProviderEndpoint::bind_fixed_stage(
    const int stage_directory_fd, const uid_t expected_provider_uid,
    const gid_t expected_provider_gid, int& error_number) noexcept {
    error_number = 0;
    if (expected_provider_uid == 0U
        || ::geteuid() != expected_provider_uid
        || ::getegid() != expected_provider_gid) {
        error_number = EPERM;
        return std::nullopt;
    }
    struct stat stage_status {};
    if (!directory_matches(stage_directory_fd,
                           {expected_provider_uid,
                            static_cast<mode_t>(0700)},
                           stage_status, error_number)) {
        return std::nullopt;
    }
    struct stat existing {};
    if (::fstatat(stage_directory_fd, kEndpointStageLeaf, &existing,
                  AT_SYMLINK_NOFOLLOW) == 0) {
        error_number = EEXIST;
        return std::nullopt;
    }
    if (errno != ENOENT) {
        error_number = errno;
        return std::nullopt;
    }

    std::array<char, sizeof(sockaddr_un::sun_path)> path{};
    sockaddr_un address{};
    socklen_t address_length = 0U;
    if (!fixed_proc_path(stage_directory_fd, kEndpointStageLeaf,
                         path, error_number)
        || !make_address(path, address, address_length, error_number)) {
        return std::nullopt;
    }
    const int listener = ::socket(
        AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC | SOCK_NONBLOCK, 0);
    if (listener < 0) {
        error_number = errno;
        return std::nullopt;
    }
    if (!enable_message_identity(listener, error_number)) {
        (void)::close(listener);
        return std::nullopt;
    }
    if (::bind(listener, reinterpret_cast<const sockaddr*>(&address),
               address_length) != 0) {
        error_number = errno;
        (void)::close(listener);
        return std::nullopt;
    }
    if (::fchmodat(stage_directory_fd, kEndpointStageLeaf,
                   static_cast<mode_t>(0222), 0) != 0) {
        error_number = errno;
        (void)::close(listener);
        return std::nullopt;
    }
    struct stat socket_status {};
    if (!fixed_socket_matches(stage_directory_fd, kEndpointStageLeaf,
                              expected_provider_uid, socket_status,
                              error_number)) {
        (void)::close(listener);
        return std::nullopt;
    }
    if (::listen(listener, 4) != 0) {
        error_number = errno;
        (void)::close(listener);
        return std::nullopt;
    }
    return ProviderEndpoint(listener, expected_provider_uid,
                            expected_provider_gid);
}

std::optional<EndpointConnection> ProviderEndpoint::accept_next(
    const int timeout_milliseconds, int& error_number) noexcept {
    error_number = 0;
    if (listener_fd_ < 0 || ::geteuid() != provider_uid_
        || ::getegid() != provider_gid_ || timeout_milliseconds < 0) {
        error_number = EPERM;
        return std::nullopt;
    }
    pollfd descriptor{listener_fd_, POLLIN, 0};
    int poll_result = -1;
    do {
        poll_result = ::poll(&descriptor, 1U, timeout_milliseconds);
    } while (poll_result < 0 && errno == EINTR);
    if (poll_result == 0) {
        error_number = ETIMEDOUT;
        return std::nullopt;
    }
    if (poll_result < 0) {
        error_number = errno;
        return std::nullopt;
    }
    if ((descriptor.revents & POLLIN) == 0) {
        error_number = ECONNABORTED;
        return std::nullopt;
    }
    int accepted = -1;
    do {
        accepted = ::accept4(listener_fd_, nullptr, nullptr, SOCK_CLOEXEC);
    } while (accepted < 0 && errno == EINTR);
    if (accepted < 0) {
        error_number = errno;
        return std::nullopt;
    }
    EndpointPeer peer{};
    int peer_pidfd = -1;
    if (!enable_message_identity(accepted, error_number)
        || !read_peer(accepted, peer, peer_pidfd, error_number)) {
        if (peer_pidfd >= 0) (void)::close(peer_pidfd);
        (void)::close(accepted);
        return std::nullopt;
    }
    return EndpointConnection(accepted, peer_pidfd, peer);
}

EndpointPublishResult publish_fixed_endpoint_noreplace(
    const int stage_directory_fd, const int public_directory_fd,
    const uid_t expected_provider_uid,
    const uid_t expected_publisher_uid) noexcept {
    EndpointPublishResult result;
    if (expected_provider_uid == 0U
        || expected_provider_uid == expected_publisher_uid
        || ::geteuid() != expected_publisher_uid) {
        result.disposition = EndpointPublishDisposition::wrong_custody;
        result.error_number = EPERM;
        return result;
    }
    struct stat stage_directory_status {};
    struct stat public_directory_status {};
    int observed_error = 0;
    if (!directory_matches(stage_directory_fd,
                           {expected_provider_uid,
                            static_cast<mode_t>(0700)},
                           stage_directory_status, observed_error)
        || !directory_matches(public_directory_fd,
                              {expected_publisher_uid,
                               static_cast<mode_t>(0711)},
                              public_directory_status, observed_error)
        || stage_directory_status.st_dev
            != public_directory_status.st_dev) {
        result.disposition = EndpointPublishDisposition::wrong_custody;
        result.error_number = observed_error == 0 ? EXDEV : observed_error;
        return result;
    }
    struct stat staged {};
    if (!fixed_socket_matches(stage_directory_fd, kEndpointStageLeaf,
                              expected_provider_uid, staged,
                              observed_error)) {
        result.disposition = observed_error == ENOENT
            ? EndpointPublishDisposition::stage_missing
            : EndpointPublishDisposition::wrong_custody;
        result.error_number = observed_error;
        return result;
    }
#if defined(SYS_renameat2)
    if (::syscall(SYS_renameat2, stage_directory_fd, kEndpointStageLeaf,
                  public_directory_fd, kEndpointPublicLeaf,
                  static_cast<unsigned int>(RENAME_NOREPLACE)) != 0) {
        const int rename_error = errno;
        result.disposition = rename_error == EEXIST
            ? EndpointPublishDisposition::public_exists
            : rename_error == ENOENT
                ? EndpointPublishDisposition::stage_missing
                : EndpointPublishDisposition::io_error;
        result.error_number = rename_error;
        return result;
    }
#else
    result.disposition = EndpointPublishDisposition::unsupported;
    result.error_number = ENOSYS;
    return result;
#endif
    struct stat published {};
    if (!fixed_socket_matches(public_directory_fd, kEndpointPublicLeaf,
                              expected_provider_uid, published,
                              observed_error)
        || published.st_dev != staged.st_dev
        || published.st_ino != staged.st_ino) {
        result.disposition = EndpointPublishDisposition::io_error;
        result.error_number = observed_error == 0 ? ESTALE : observed_error;
        return result;
    }
    struct stat absent {};
    if (::fstatat(stage_directory_fd, kEndpointStageLeaf, &absent,
                  AT_SYMLINK_NOFOLLOW) == 0 || errno != ENOENT) {
        result.disposition = EndpointPublishDisposition::io_error;
        result.error_number = errno == 0 ? EEXIST : errno;
        return result;
    }
    result.device = static_cast<std::uint64_t>(published.st_dev);
    result.inode = static_cast<std::uint64_t>(published.st_ino);
    const bool stage_synced = ::fsync(stage_directory_fd) == 0;
    const bool public_synced = ::fsync(public_directory_fd) == 0;
    result.disposition = stage_synced && public_synced
        ? EndpointPublishDisposition::published_and_synced
        : EndpointPublishDisposition::published_sync_uncertain;
    result.error_number = stage_synced && public_synced ? 0 : errno;
    return result;
}

std::optional<EndpointConnection> connect_fixed_endpoint(
    const int public_directory_fd, const uid_t expected_query_uid,
    const uid_t expected_publisher_uid, const uid_t expected_provider_uid,
    const gid_t expected_provider_gid, int& error_number) noexcept {
    error_number = 0;
    if (expected_query_uid == 0U || expected_provider_uid == 0U
        || expected_provider_uid == expected_publisher_uid
        || ::geteuid() != expected_query_uid) {
        error_number = EPERM;
        return std::nullopt;
    }
    struct stat public_directory_status {};
    if (!directory_matches(public_directory_fd,
                           {expected_publisher_uid,
                            static_cast<mode_t>(0711)},
                           public_directory_status, error_number)) {
        return std::nullopt;
    }
    struct stat public_socket {};
    if (!fixed_socket_matches(public_directory_fd, kEndpointPublicLeaf,
                              expected_provider_uid, public_socket,
                              error_number)) {
        return std::nullopt;
    }
    std::array<char, sizeof(sockaddr_un::sun_path)> path{};
    sockaddr_un address{};
    socklen_t address_length = 0U;
    if (!fixed_proc_path(public_directory_fd, kEndpointPublicLeaf,
                         path, error_number)
        || !make_address(path, address, address_length, error_number)) {
        return std::nullopt;
    }
    const int connection = ::socket(
        AF_UNIX, SOCK_SEQPACKET | SOCK_CLOEXEC, 0);
    if (connection < 0) {
        error_number = errno;
        return std::nullopt;
    }
    if (!enable_message_identity(connection, error_number)) {
        (void)::close(connection);
        return std::nullopt;
    }
    if (::connect(connection, reinterpret_cast<const sockaddr*>(&address),
                  address_length) != 0) {
        error_number = errno;
        (void)::close(connection);
        return std::nullopt;
    }
    EndpointPeer peer{};
    int peer_pidfd = -1;
    if (!read_peer(connection, peer, peer_pidfd, error_number)) {
        (void)::close(connection);
        return std::nullopt;
    }
    if (peer.uid != expected_provider_uid
        || peer.gid != expected_provider_gid) {
        error_number = EACCES;
        (void)::close(peer_pidfd);
        (void)::close(connection);
        return std::nullopt;
    }
    return EndpointConnection(connection, peer_pidfd, peer);
}

const char* endpoint_publish_name(
    const EndpointPublishDisposition value) noexcept {
    switch (value) {
        case EndpointPublishDisposition::published_and_synced:
            return "PUBLISHED_SYNCED";
        case EndpointPublishDisposition::published_sync_uncertain:
            return "PUBLISHED_SYNC_UNCERTAIN";
        case EndpointPublishDisposition::stage_missing:
            return "STAGE_MISSING";
        case EndpointPublishDisposition::public_exists:
            return "PUBLIC_EXISTS";
        case EndpointPublishDisposition::wrong_custody:
            return "WRONG_CUSTODY";
        case EndpointPublishDisposition::unsupported:
            return "UNSUPPORTED";
        case EndpointPublishDisposition::io_error:
            return "IO_ERROR";
    }
    return "IO_ERROR";
}

}  // namespace slopos::e0::handoff_cell
