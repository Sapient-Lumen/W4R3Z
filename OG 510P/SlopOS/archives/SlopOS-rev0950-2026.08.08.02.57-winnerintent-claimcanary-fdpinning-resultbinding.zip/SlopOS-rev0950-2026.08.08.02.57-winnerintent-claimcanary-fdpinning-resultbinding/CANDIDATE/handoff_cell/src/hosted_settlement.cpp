#include "slopos/e0/handoff_cell/hosted_settlement.hpp"

#include <utility>

namespace slopos::e0::handoff_cell {
namespace {

using generation_journal::EncodedRecord;
using generation_journal::Record;
using generation_journal::RecordKind;
using generation_journal::Result;

[[nodiscard]] bool decode_expected_pending(
    const EncodedRecord& encoded, Record& record) noexcept {
    return generation_journal::decode_record(encoded, record)
        && record.kind == RecordKind::pending;
}

[[nodiscard]] bool same_operation(
    const Record& expected, const Record& observed) noexcept {
    return expected.generation_from == observed.generation_from
        && expected.generation_to == observed.generation_to
        && expected.operation_binding == observed.operation_binding
        && expected.spent_receipt_binding == observed.spent_receipt_binding;
}

[[nodiscard]] SettlementObservation classify_record(
    const EncodedRecord& expected_pending,
    const EncodedRecord& encoded_result,
    const SettlementEvidence exact_evidence,
    const bool submit_called,
    const bool query_called,
    const bool request_examined) noexcept {
    Record expected;
    if (!decode_expected_pending(expected_pending, expected)) {
        return {
            SettlementDisposition::fail_stop,
            SettlementEvidence::invalid_expected_pending,
            request_examined,
            submit_called,
            query_called,
            false,
            true,
            false,
            false,
        };
    }

    Record observed;
    if (!generation_journal::decode_record(encoded_result, observed)
        || observed.kind != RecordKind::result
        || !same_operation(expected, observed)) {
        // A malformed or foreign return can arrive after an effect. It is
        // uncertainty, never denial and never replay permission.
        return {
            SettlementDisposition::uncertain,
            SettlementEvidence::foreign_or_invalid_result,
            request_examined,
            submit_called,
            query_called,
            false,
            true,
            false,
            false,
        };
    }

    SettlementDisposition disposition = SettlementDisposition::uncertain;
    switch (observed.result) {
        case Result::effect:
            disposition = SettlementDisposition::effect;
            break;
        case Result::no_effect:
            disposition = SettlementDisposition::no_effect;
            break;
        case Result::uncertain:
            disposition = SettlementDisposition::uncertain;
            break;
        case Result::fail_stop:
            disposition = SettlementDisposition::fail_stop;
            break;
        case Result::none:
            disposition = SettlementDisposition::uncertain;
            break;
    }
    return {
        disposition,
        exact_evidence,
        request_examined,
        submit_called,
        query_called,
        true,
        true,
        false,
        false,
    };
}

[[nodiscard]] SettlementObservation uncertain_observation(
    const SettlementEvidence evidence,
    const bool submit_called,
    const bool query_called,
    const bool request_examined) noexcept {
    return {
        SettlementDisposition::uncertain,
        evidence,
        request_examined,
        submit_called,
        query_called,
        false,
        true,
        false,
        false,
    };
}

}  // namespace

SettlementObservation HostedSettlement::settle_exact(
    ClaimedPending&& claim,
    const std::span<const std::uint8_t> request,
    HostedSettlementProvider& provider) noexcept {
    EncodedRecord expected_pending{};
    const PayloadParseResult parsed = PayloadAfterClaim::parse_exact_impl(
        std::move(claim), request, &expected_pending);
    if (parsed.disposition == PayloadDisposition::claim_missing_or_spent) {
        return {
            SettlementDisposition::claim_missing_or_spent,
            SettlementEvidence::claim_absent,
            false,
            false,
            false,
            false,
            true,
            false,
            false,
        };
    }
    if (parsed.disposition != PayloadDisposition::exact_request) {
        return {
            SettlementDisposition::malformed_request,
            SettlementEvidence::request_rejected,
            true,
            false,
            false,
            true,
            true,
            false,
            false,
        };
    }

    // There is one and only one provider submission in this entrypoint. A
    // no-return does not loop, retry, query, or reconstruct the spent claim.
    const ProviderSubmitReply reply = provider.submit_exact(expected_pending);
    switch (reply.disposition) {
        case ProviderSubmitDisposition::exact_record:
            return classify_record(
                expected_pending, reply.encoded,
                SettlementEvidence::submit_exact_record,
                true, false, true);
        case ProviderSubmitDisposition::no_return:
            return uncertain_observation(
                SettlementEvidence::submit_no_return, true, false, true);
        case ProviderSubmitDisposition::unavailable:
            return uncertain_observation(
                SettlementEvidence::submit_unavailable, true, false, true);
        case ProviderSubmitDisposition::malformed_return:
            return uncertain_observation(
                SettlementEvidence::submit_malformed, true, false, true);
    }
    return uncertain_observation(
        SettlementEvidence::submit_unavailable, true, false, true);
}

SettlementObservation HostedSettlement::reconcile_exact(
    const EncodedRecord& expected_pending,
    HostedSettlementProvider& provider) noexcept {
    Record expected;
    if (!decode_expected_pending(expected_pending, expected)) {
        return {
            SettlementDisposition::fail_stop,
            SettlementEvidence::invalid_expected_pending,
            false,
            false,
            false,
            false,
            true,
            false,
            false,
        };
    }

    const ProviderQueryReply reply = provider.query_exact(expected_pending);
    switch (reply.disposition) {
        case ProviderQueryDisposition::exact_record:
            return classify_record(
                expected_pending, reply.encoded,
                SettlementEvidence::query_exact_record,
                false, true, false);
        case ProviderQueryDisposition::exact_unused:
            // Under the hosted provider contract, an exact linearized unused
            // observation proves no effect for this identity. It remains
            // query-only and cannot authorize a late first submission.
            return {
                SettlementDisposition::no_effect,
                SettlementEvidence::query_exact_unused,
                false,
                false,
                true,
                true,
                true,
                false,
                false,
            };
        case ProviderQueryDisposition::unavailable:
            return uncertain_observation(
                SettlementEvidence::query_unavailable, false, true, false);
        case ProviderQueryDisposition::malformed_return:
            return uncertain_observation(
                SettlementEvidence::query_malformed, false, true, false);
    }
    return uncertain_observation(
        SettlementEvidence::query_unavailable, false, true, false);
}

const char* provider_submit_name(
    const ProviderSubmitDisposition value) noexcept {
    switch (value) {
        case ProviderSubmitDisposition::exact_record: return "EXACT_RECORD";
        case ProviderSubmitDisposition::no_return: return "NO_RETURN";
        case ProviderSubmitDisposition::unavailable: return "UNAVAILABLE";
        case ProviderSubmitDisposition::malformed_return:
            return "MALFORMED_RETURN";
    }
    return "UNAVAILABLE";
}

const char* provider_query_name(
    const ProviderQueryDisposition value) noexcept {
    switch (value) {
        case ProviderQueryDisposition::exact_record: return "EXACT_RECORD";
        case ProviderQueryDisposition::exact_unused: return "EXACT_UNUSED";
        case ProviderQueryDisposition::unavailable: return "UNAVAILABLE";
        case ProviderQueryDisposition::malformed_return:
            return "MALFORMED_RETURN";
    }
    return "UNAVAILABLE";
}

const char* settlement_name(const SettlementDisposition value) noexcept {
    switch (value) {
        case SettlementDisposition::effect: return "EFFECT";
        case SettlementDisposition::no_effect: return "NO_EFFECT";
        case SettlementDisposition::uncertain: return "UNCERTAIN";
        case SettlementDisposition::fail_stop: return "FAIL_STOP";
        case SettlementDisposition::malformed_request:
            return "MALFORMED_REQUEST";
        case SettlementDisposition::claim_missing_or_spent:
            return "CLAIM_MISSING_OR_SPENT";
    }
    return "UNCERTAIN";
}

const char* settlement_evidence_name(
    const SettlementEvidence value) noexcept {
    switch (value) {
        case SettlementEvidence::submit_exact_record:
            return "SUBMIT_EXACT_RECORD";
        case SettlementEvidence::submit_no_return: return "SUBMIT_NO_RETURN";
        case SettlementEvidence::submit_unavailable:
            return "SUBMIT_UNAVAILABLE";
        case SettlementEvidence::submit_malformed:
            return "SUBMIT_MALFORMED";
        case SettlementEvidence::query_exact_record:
            return "QUERY_EXACT_RECORD";
        case SettlementEvidence::query_exact_unused:
            return "QUERY_EXACT_UNUSED";
        case SettlementEvidence::query_unavailable:
            return "QUERY_UNAVAILABLE";
        case SettlementEvidence::query_malformed:
            return "QUERY_MALFORMED";
        case SettlementEvidence::request_rejected:
            return "REQUEST_REJECTED";
        case SettlementEvidence::claim_absent: return "CLAIM_ABSENT";
        case SettlementEvidence::invalid_expected_pending:
            return "INVALID_EXPECTED_PENDING";
        case SettlementEvidence::foreign_or_invalid_result:
            return "FOREIGN_OR_INVALID_RESULT";
    }
    return "QUERY_UNAVAILABLE";
}

}  // namespace slopos::e0::handoff_cell
