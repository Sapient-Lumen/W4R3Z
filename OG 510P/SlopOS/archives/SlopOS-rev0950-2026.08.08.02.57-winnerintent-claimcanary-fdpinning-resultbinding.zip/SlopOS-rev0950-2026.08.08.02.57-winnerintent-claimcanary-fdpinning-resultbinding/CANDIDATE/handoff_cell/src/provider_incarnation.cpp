#include "slopos/e0/handoff_cell/provider_incarnation.hpp"

#include <array>

namespace slopos::e0::handoff_cell {
namespace {

[[nodiscard]] std::array<bool, 63U> ordered_values(
    const ProviderIncarnationObservationV1& value) noexcept {
    return {{
        value.release_profile_supplied,
        value.release_tag_exact,
        value.checksum_product_supplied,
        value.checksum_product_authenticated,
        value.archive_body_supplied,
        value.archive_digest_exact,
        value.binary_inventory_exact,
        value.admitted_binary_digests_exact,
        value.cluster_id_exact,
        value.member_ids_exact,
        value.member_count_exact,
        value.client_ca_exact,
        value.peer_ca_exact,
        value.server_certificate_set_exact,
        value.application_principal_exact,
        value.administration_inventory_exact,
        value.auth_enabled,
        value.auth_revision_exact,
        value.namespace_exclusive,
        value.member_endpoint_set_exact,
        value.data_directory_inventory_exact,
        value.snapshot_inventory_exact,
        value.restore_authority_inventory_exact,
        value.replacement_authority_inventory_exact,
        value.v20_plan_supplied,
        value.exact_four_compares,
        value.exact_three_writes,
        value.exactly_one_transaction_attempt,
        value.response_cluster_exact,
        value.response_member_admitted,
        value.response_revision_nonzero,
        value.response_auth_revision_exact,
        value.linearizable_exact_readback,
        value.joined_head_exact,
        value.joined_spend_exact,
        value.joined_entry_exact,
        value.joined_revision_exact,
        value.duplicate_query_only,
        value.ambiguous_completion_query_only,
        value.reopen_query_only,
        value.no_resubmit_route,
        value.quorum_status_supplied,
        value.all_members_same_cluster,
        value.member_set_quorum_exact,
        value.endpoint_health_all_admitted,
        value.endpoint_hashkv_revision_exact,
        value.endpoint_hashkv_equal,
        value.alarm_inventory_exact,
        value.no_unadmitted_member_or_learner,
        value.restore_or_replacement_event_classified,
        value.restored_cluster_new_identity_required,
        value.revision_bump_not_succession,
        value.successor_ceremony_bound,
        value.predecessor_retired_under_distinct_root,
        value.reopener_administration_distinct,
        value.reopener_credentials_distinct,
        value.reopener_storage_control_distinct,
        value.reopener_network_path_distinct,
        value.exact_profile_reopened,
        value.exact_v20_result_reopened,
        value.no_rollback_route_shared,
        value.external_currentness_contract_bound,
        value.stable_storage_contract_bound
    }};
}

[[nodiscard]] bool is_ordered_prefix(
    const std::array<bool, 63U>& values) noexcept {
    bool false_seen = false;
    for (const bool value : values) {
        if (!value) false_seen = true;
        else if (false_seen) return false;
    }
    return true;
}

}  // namespace

ProviderIncarnationAssessment assess_provider_incarnation(
    const ProviderIncarnationObservationV1& observation) noexcept {
    ProviderIncarnationAssessment result;
    const auto values = ordered_values(observation);
    if (!is_ordered_prefix(values)) {
        result.disposition = ProviderIncarnationDisposition::observation_incoherent;
        return result;
    }
    result.observation_coherent = true;

#define SLOPOS_V21_REQUIRE(field, disposition_name) \
    if (!observation.field) { \
        result.disposition = ProviderIncarnationDisposition::disposition_name; \
        return result; \
    }

    SLOPOS_V21_REQUIRE(release_profile_supplied, release_profile_unavailable)
    SLOPOS_V21_REQUIRE(release_tag_exact, release_tag_mismatch)
    SLOPOS_V21_REQUIRE(checksum_product_supplied, checksum_product_unavailable)
    SLOPOS_V21_REQUIRE(checksum_product_authenticated, checksum_product_unauthenticated)
    result.release_metadata_bound = true;
    SLOPOS_V21_REQUIRE(archive_body_supplied, archive_body_unavailable)
    SLOPOS_V21_REQUIRE(archive_digest_exact, archive_digest_mismatch)
    SLOPOS_V21_REQUIRE(binary_inventory_exact, binary_inventory_mismatch)
    SLOPOS_V21_REQUIRE(admitted_binary_digests_exact, binary_digest_mismatch)
    result.release_archive_admitted = true;
    SLOPOS_V21_REQUIRE(cluster_id_exact, cluster_id_mismatch)
    SLOPOS_V21_REQUIRE(member_ids_exact, member_ids_mismatch)
    SLOPOS_V21_REQUIRE(member_count_exact, member_count_mismatch)
    SLOPOS_V21_REQUIRE(client_ca_exact, client_ca_mismatch)
    SLOPOS_V21_REQUIRE(peer_ca_exact, peer_ca_mismatch)
    SLOPOS_V21_REQUIRE(server_certificate_set_exact, server_certificate_set_mismatch)
    SLOPOS_V21_REQUIRE(application_principal_exact, application_principal_mismatch)
    SLOPOS_V21_REQUIRE(administration_inventory_exact, administration_inventory_open)
    SLOPOS_V21_REQUIRE(auth_enabled, authentication_disabled)
    SLOPOS_V21_REQUIRE(auth_revision_exact, auth_revision_mismatch)
    SLOPOS_V21_REQUIRE(namespace_exclusive, namespace_not_exclusive)
    SLOPOS_V21_REQUIRE(member_endpoint_set_exact, member_endpoint_set_mismatch)
    result.incarnation_coordinates_bound = true;
    SLOPOS_V21_REQUIRE(data_directory_inventory_exact, data_directory_inventory_open)
    SLOPOS_V21_REQUIRE(snapshot_inventory_exact, snapshot_inventory_open)
    SLOPOS_V21_REQUIRE(restore_authority_inventory_exact, restore_authority_inventory_open)
    SLOPOS_V21_REQUIRE(replacement_authority_inventory_exact, replacement_authority_inventory_open)
    result.custody_inventory_bound = true;
    SLOPOS_V21_REQUIRE(v20_plan_supplied, v20_plan_unavailable)
    SLOPOS_V21_REQUIRE(exact_four_compares, compare_set_mismatch)
    SLOPOS_V21_REQUIRE(exact_three_writes, write_set_mismatch)
    SLOPOS_V21_REQUIRE(exactly_one_transaction_attempt, transaction_attempt_count_rejected)
    SLOPOS_V21_REQUIRE(response_cluster_exact, response_cluster_mismatch)
    SLOPOS_V21_REQUIRE(response_member_admitted, response_member_unadmitted)
    SLOPOS_V21_REQUIRE(response_revision_nonzero, response_revision_invalid)
    SLOPOS_V21_REQUIRE(response_auth_revision_exact, response_auth_revision_mismatch)
    SLOPOS_V21_REQUIRE(linearizable_exact_readback, linearizable_readback_required)
    SLOPOS_V21_REQUIRE(joined_head_exact, joined_head_mismatch)
    SLOPOS_V21_REQUIRE(joined_spend_exact, joined_spend_mismatch)
    SLOPOS_V21_REQUIRE(joined_entry_exact, joined_entry_mismatch)
    SLOPOS_V21_REQUIRE(joined_revision_exact, joined_revision_mismatch)
    SLOPOS_V21_REQUIRE(duplicate_query_only, duplicate_not_query_only)
    SLOPOS_V21_REQUIRE(ambiguous_completion_query_only, ambiguity_not_query_only)
    SLOPOS_V21_REQUIRE(reopen_query_only, reopen_not_query_only)
    SLOPOS_V21_REQUIRE(no_resubmit_route, resubmit_route_open)
    result.v20_operation_observed = true;
    SLOPOS_V21_REQUIRE(quorum_status_supplied, quorum_status_unavailable)
    SLOPOS_V21_REQUIRE(all_members_same_cluster, member_cluster_disagreement)
    SLOPOS_V21_REQUIRE(member_set_quorum_exact, member_quorum_mismatch)
    SLOPOS_V21_REQUIRE(endpoint_health_all_admitted, endpoint_health_incomplete)
    SLOPOS_V21_REQUIRE(endpoint_hashkv_revision_exact, hashkv_revision_mismatch)
    SLOPOS_V21_REQUIRE(endpoint_hashkv_equal, hashkv_disagreement)
    SLOPOS_V21_REQUIRE(alarm_inventory_exact, alarm_inventory_open)
    SLOPOS_V21_REQUIRE(no_unadmitted_member_or_learner, unadmitted_member_or_learner)
    result.quorum_agreement_bound = true;
    SLOPOS_V21_REQUIRE(restore_or_replacement_event_classified, restore_event_unclassified)
    SLOPOS_V21_REQUIRE(restored_cluster_new_identity_required, restored_identity_reused)
    SLOPOS_V21_REQUIRE(revision_bump_not_succession, revision_bump_laundered_as_succession)
    SLOPOS_V21_REQUIRE(successor_ceremony_bound, successor_ceremony_unbound)
    SLOPOS_V21_REQUIRE(predecessor_retired_under_distinct_root, predecessor_retirement_unbound)
    result.succession_bound = true;
    SLOPOS_V21_REQUIRE(reopener_administration_distinct, reopener_administration_not_distinct)
    SLOPOS_V21_REQUIRE(reopener_credentials_distinct, reopener_credentials_not_distinct)
    SLOPOS_V21_REQUIRE(reopener_storage_control_distinct, reopener_storage_not_distinct)
    SLOPOS_V21_REQUIRE(reopener_network_path_distinct, reopener_network_path_not_distinct)
    SLOPOS_V21_REQUIRE(exact_profile_reopened, profile_reopen_mismatch)
    SLOPOS_V21_REQUIRE(exact_v20_result_reopened, v20_result_reopen_mismatch)
    SLOPOS_V21_REQUIRE(no_rollback_route_shared, rollback_route_shared)
    SLOPOS_V21_REQUIRE(external_currentness_contract_bound, external_currentness_unproved)
    SLOPOS_V21_REQUIRE(stable_storage_contract_bound, stable_storage_contract_unproved)
    result.independent_reopen_bound = true;

#undef SLOPOS_V21_REQUIRE

    result.eligible_for_external_provider_premise = true;
    result.disposition = ProviderIncarnationDisposition::independent_reopen_premise;
    return result;
}

const char* provider_incarnation_disposition_name(
    const ProviderIncarnationDisposition value) noexcept {
    switch (value) {
        case ProviderIncarnationDisposition::observation_incoherent:
            return "OBSERVATION_INCOHERENT";
        case ProviderIncarnationDisposition::release_profile_unavailable:
            return "RELEASE_PROFILE_UNAVAILABLE";
        case ProviderIncarnationDisposition::release_tag_mismatch:
            return "RELEASE_TAG_MISMATCH";
        case ProviderIncarnationDisposition::checksum_product_unavailable:
            return "CHECKSUM_PRODUCT_UNAVAILABLE";
        case ProviderIncarnationDisposition::checksum_product_unauthenticated:
            return "CHECKSUM_PRODUCT_UNAUTHENTICATED";
        case ProviderIncarnationDisposition::archive_body_unavailable:
            return "ARCHIVE_BODY_UNAVAILABLE";
        case ProviderIncarnationDisposition::archive_digest_mismatch:
            return "ARCHIVE_DIGEST_MISMATCH";
        case ProviderIncarnationDisposition::binary_inventory_mismatch:
            return "BINARY_INVENTORY_MISMATCH";
        case ProviderIncarnationDisposition::binary_digest_mismatch:
            return "BINARY_DIGEST_MISMATCH";
        case ProviderIncarnationDisposition::cluster_id_mismatch:
            return "CLUSTER_ID_MISMATCH";
        case ProviderIncarnationDisposition::member_ids_mismatch:
            return "MEMBER_IDS_MISMATCH";
        case ProviderIncarnationDisposition::member_count_mismatch:
            return "MEMBER_COUNT_MISMATCH";
        case ProviderIncarnationDisposition::client_ca_mismatch:
            return "CLIENT_CA_MISMATCH";
        case ProviderIncarnationDisposition::peer_ca_mismatch:
            return "PEER_CA_MISMATCH";
        case ProviderIncarnationDisposition::server_certificate_set_mismatch:
            return "SERVER_CERTIFICATE_SET_MISMATCH";
        case ProviderIncarnationDisposition::application_principal_mismatch:
            return "APPLICATION_PRINCIPAL_MISMATCH";
        case ProviderIncarnationDisposition::administration_inventory_open:
            return "ADMINISTRATION_INVENTORY_OPEN";
        case ProviderIncarnationDisposition::authentication_disabled:
            return "AUTHENTICATION_DISABLED";
        case ProviderIncarnationDisposition::auth_revision_mismatch:
            return "AUTH_REVISION_MISMATCH";
        case ProviderIncarnationDisposition::namespace_not_exclusive:
            return "NAMESPACE_NOT_EXCLUSIVE";
        case ProviderIncarnationDisposition::member_endpoint_set_mismatch:
            return "MEMBER_ENDPOINT_SET_MISMATCH";
        case ProviderIncarnationDisposition::data_directory_inventory_open:
            return "DATA_DIRECTORY_INVENTORY_OPEN";
        case ProviderIncarnationDisposition::snapshot_inventory_open:
            return "SNAPSHOT_INVENTORY_OPEN";
        case ProviderIncarnationDisposition::restore_authority_inventory_open:
            return "RESTORE_AUTHORITY_INVENTORY_OPEN";
        case ProviderIncarnationDisposition::replacement_authority_inventory_open:
            return "REPLACEMENT_AUTHORITY_INVENTORY_OPEN";
        case ProviderIncarnationDisposition::v20_plan_unavailable:
            return "V20_PLAN_UNAVAILABLE";
        case ProviderIncarnationDisposition::compare_set_mismatch:
            return "COMPARE_SET_MISMATCH";
        case ProviderIncarnationDisposition::write_set_mismatch:
            return "WRITE_SET_MISMATCH";
        case ProviderIncarnationDisposition::transaction_attempt_count_rejected:
            return "TRANSACTION_ATTEMPT_COUNT_REJECTED";
        case ProviderIncarnationDisposition::response_cluster_mismatch:
            return "RESPONSE_CLUSTER_MISMATCH";
        case ProviderIncarnationDisposition::response_member_unadmitted:
            return "RESPONSE_MEMBER_UNADMITTED";
        case ProviderIncarnationDisposition::response_revision_invalid:
            return "RESPONSE_REVISION_INVALID";
        case ProviderIncarnationDisposition::response_auth_revision_mismatch:
            return "RESPONSE_AUTH_REVISION_MISMATCH";
        case ProviderIncarnationDisposition::linearizable_readback_required:
            return "LINEARIZABLE_READBACK_REQUIRED";
        case ProviderIncarnationDisposition::joined_head_mismatch:
            return "JOINED_HEAD_MISMATCH";
        case ProviderIncarnationDisposition::joined_spend_mismatch:
            return "JOINED_SPEND_MISMATCH";
        case ProviderIncarnationDisposition::joined_entry_mismatch:
            return "JOINED_ENTRY_MISMATCH";
        case ProviderIncarnationDisposition::joined_revision_mismatch:
            return "JOINED_REVISION_MISMATCH";
        case ProviderIncarnationDisposition::duplicate_not_query_only:
            return "DUPLICATE_NOT_QUERY_ONLY";
        case ProviderIncarnationDisposition::ambiguity_not_query_only:
            return "AMBIGUITY_NOT_QUERY_ONLY";
        case ProviderIncarnationDisposition::reopen_not_query_only:
            return "REOPEN_NOT_QUERY_ONLY";
        case ProviderIncarnationDisposition::resubmit_route_open:
            return "RESUBMIT_ROUTE_OPEN";
        case ProviderIncarnationDisposition::quorum_status_unavailable:
            return "QUORUM_STATUS_UNAVAILABLE";
        case ProviderIncarnationDisposition::member_cluster_disagreement:
            return "MEMBER_CLUSTER_DISAGREEMENT";
        case ProviderIncarnationDisposition::member_quorum_mismatch:
            return "MEMBER_QUORUM_MISMATCH";
        case ProviderIncarnationDisposition::endpoint_health_incomplete:
            return "ENDPOINT_HEALTH_INCOMPLETE";
        case ProviderIncarnationDisposition::hashkv_revision_mismatch:
            return "HASHKV_REVISION_MISMATCH";
        case ProviderIncarnationDisposition::hashkv_disagreement:
            return "HASHKV_DISAGREEMENT";
        case ProviderIncarnationDisposition::alarm_inventory_open:
            return "ALARM_INVENTORY_OPEN";
        case ProviderIncarnationDisposition::unadmitted_member_or_learner:
            return "UNADMITTED_MEMBER_OR_LEARNER";
        case ProviderIncarnationDisposition::restore_event_unclassified:
            return "RESTORE_EVENT_UNCLASSIFIED";
        case ProviderIncarnationDisposition::restored_identity_reused:
            return "RESTORED_IDENTITY_REUSED";
        case ProviderIncarnationDisposition::revision_bump_laundered_as_succession:
            return "REVISION_BUMP_LAUNDERED_AS_SUCCESSION";
        case ProviderIncarnationDisposition::successor_ceremony_unbound:
            return "SUCCESSOR_CEREMONY_UNBOUND";
        case ProviderIncarnationDisposition::predecessor_retirement_unbound:
            return "PREDECESSOR_RETIREMENT_UNBOUND";
        case ProviderIncarnationDisposition::reopener_administration_not_distinct:
            return "REOPENER_ADMINISTRATION_NOT_DISTINCT";
        case ProviderIncarnationDisposition::reopener_credentials_not_distinct:
            return "REOPENER_CREDENTIALS_NOT_DISTINCT";
        case ProviderIncarnationDisposition::reopener_storage_not_distinct:
            return "REOPENER_STORAGE_NOT_DISTINCT";
        case ProviderIncarnationDisposition::reopener_network_path_not_distinct:
            return "REOPENER_NETWORK_PATH_NOT_DISTINCT";
        case ProviderIncarnationDisposition::profile_reopen_mismatch:
            return "PROFILE_REOPEN_MISMATCH";
        case ProviderIncarnationDisposition::v20_result_reopen_mismatch:
            return "V20_RESULT_REOPEN_MISMATCH";
        case ProviderIncarnationDisposition::rollback_route_shared:
            return "ROLLBACK_ROUTE_SHARED";
        case ProviderIncarnationDisposition::external_currentness_unproved:
            return "EXTERNAL_CURRENTNESS_UNPROVED";
        case ProviderIncarnationDisposition::stable_storage_contract_unproved:
            return "STABLE_STORAGE_CONTRACT_UNPROVED";
        case ProviderIncarnationDisposition::independent_reopen_premise:
            return "INDEPENDENT_REOPEN_PREMISE";
    }
    return "UNKNOWN";
}

}  // namespace slopos::e0::handoff_cell
