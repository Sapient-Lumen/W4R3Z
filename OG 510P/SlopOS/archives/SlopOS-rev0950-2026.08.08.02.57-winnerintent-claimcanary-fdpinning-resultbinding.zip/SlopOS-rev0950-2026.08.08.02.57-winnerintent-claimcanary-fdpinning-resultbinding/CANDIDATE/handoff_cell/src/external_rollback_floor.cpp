#include "slopos/e0/handoff_cell/external_rollback_floor.hpp"

#include "slopos/e0/generation_journal/record.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <span>

namespace slopos::e0::handoff_cell {
namespace {

constexpr std::array<std::uint8_t, 8U> kMagic{{'S','L','O','P','N','V','F','1'}};
constexpr std::uint8_t kVersion = 1U;
constexpr std::uint8_t kSha256Algorithm = 1U;
constexpr std::uint32_t kProfileFlags = 0x00000001U;

void put_u16(EncodedExternalFloorRecord& out, const std::size_t offset,
             const std::uint16_t value) noexcept {
    out[offset] = static_cast<std::uint8_t>(value & 0xffU);
    out[offset + 1U] = static_cast<std::uint8_t>((value >> 8U) & 0xffU);
}

void put_u32(EncodedExternalFloorRecord& out, const std::size_t offset,
             const std::uint32_t value) noexcept {
    for (std::size_t index = 0U; index < 4U; ++index) {
        out[offset + index] = static_cast<std::uint8_t>(
            (value >> static_cast<unsigned int>(index * 8U)) & 0xffU);
    }
}

void put_u64(EncodedExternalFloorRecord& out, const std::size_t offset,
             const std::uint64_t value) noexcept {
    for (std::size_t index = 0U; index < 8U; ++index) {
        out[offset + index] = static_cast<std::uint8_t>(
            (value >> static_cast<unsigned int>(index * 8U)) & 0xffU);
    }
}

[[nodiscard]] std::uint16_t get_u16(
    const EncodedExternalFloorRecord& in, const std::size_t offset) noexcept {
    return static_cast<std::uint16_t>(in[offset])
        | static_cast<std::uint16_t>(
            static_cast<std::uint16_t>(in[offset + 1U]) << 8U);
}

[[nodiscard]] std::uint32_t get_u32(
    const EncodedExternalFloorRecord& in, const std::size_t offset) noexcept {
    std::uint32_t value = 0U;
    for (std::size_t index = 0U; index < 4U; ++index) {
        value |= static_cast<std::uint32_t>(in[offset + index])
            << static_cast<unsigned int>(index * 8U);
    }
    return value;
}

[[nodiscard]] std::uint64_t get_u64(
    const EncodedExternalFloorRecord& in, const std::size_t offset) noexcept {
    std::uint64_t value = 0U;
    for (std::size_t index = 0U; index < 8U; ++index) {
        value |= static_cast<std::uint64_t>(in[offset + index])
            << static_cast<unsigned int>(index * 8U);
    }
    return value;
}

[[nodiscard]] bool nonzero(const ExternalFloorDigest& value) noexcept {
    return !generation_journal::digest_is_zero(value);
}

[[nodiscard]] bool invariant(const ExternalFloorRecordV1& value) noexcept {
    return value.generation_from > 0U
        && value.generation_from != std::numeric_limits<std::uint64_t>::max()
        && value.generation_to == value.generation_from + 1U
        && nonzero(value.profile_identity)
        && nonzero(value.platform_incarnation)
        && nonzero(value.nv_name)
        && nonzero(value.predecessor_head)
        && nonzero(value.receipt_spend_head)
        && nonzero(value.witness_challenge)
        && nonzero(value.witness_incarnation);
}

using Field = bool ExternalRollbackFloorObservationV1::*;
constexpr std::array<Field, 58U> kFields{{
    &ExternalRollbackFloorObservationV1::profile_supplied,
    &ExternalRollbackFloorObservationV1::tpm_family_2_0,
    &ExternalRollbackFloorObservationV1::exact_profile_release_pinned,
    &ExternalRollbackFloorObservationV1::platform_incarnation_supplied,
    &ExternalRollbackFloorObservationV1::platform_incarnation_exact,
    &ExternalRollbackFloorObservationV1::ak_coordinate_supplied,
    &ExternalRollbackFloorObservationV1::ak_coordinate_exact,
    &ExternalRollbackFloorObservationV1::nv_public_supplied,
    &ExternalRollbackFloorObservationV1::nv_name_recomputed_exact,
    &ExternalRollbackFloorObservationV1::name_alg_sha256,
    &ExternalRollbackFloorObservationV1::nv_type_extend,
    &ExternalRollbackFloorObservationV1::nv_buffer_capacity_sufficient,
    &ExternalRollbackFloorObservationV1::nv_data_size_digest_exact,
    &ExternalRollbackFloorObservationV1::orderly_clear,
    &ExternalRollbackFloorObservationV1::policy_write_only,
    &ExternalRollbackFloorObservationV1::policy_read_only,
    &ExternalRollbackFloorObservationV1::policy_delete,
    &ExternalRollbackFloorObservationV1::platform_create,
    &ExternalRollbackFloorObservationV1::candidate_lacks_platform_admin,
    &ExternalRollbackFloorObservationV1::appraiser_lacks_platform_admin,
    &ExternalRollbackFloorObservationV1::witness_administration_distinct,
    &ExternalRollbackFloorObservationV1::v18_spend_record_supplied,
    &ExternalRollbackFloorObservationV1::v18_spend_record_canonical,
    &ExternalRollbackFloorObservationV1::v18_spend_record_digest_exact,
    &ExternalRollbackFloorObservationV1::witness_challenge_fresh,
    &ExternalRollbackFloorObservationV1::pre_certify_supplied,
    &ExternalRollbackFloorObservationV1::pre_certify_signature_valid,
    &ExternalRollbackFloorObservationV1::pre_certify_qualifying_data_exact,
    &ExternalRollbackFloorObservationV1::pre_certify_nv_name_exact,
    &ExternalRollbackFloorObservationV1::pre_certify_contents_exact,
    &ExternalRollbackFloorObservationV1::predecessor_generation_exact,
    &ExternalRollbackFloorObservationV1::predecessor_head_exact,
    &ExternalRollbackFloorObservationV1::append_record_encoded,
    &ExternalRollbackFloorObservationV1::append_record_canonical,
    &ExternalRollbackFloorObservationV1::append_record_binds_profile,
    &ExternalRollbackFloorObservationV1::append_record_binds_v18_spend,
    &ExternalRollbackFloorObservationV1::nv_extend_successor_exact,
    &ExternalRollbackFloorObservationV1::exactly_one_nv_extend_attempt,
    &ExternalRollbackFloorObservationV1::post_certify_supplied,
    &ExternalRollbackFloorObservationV1::post_certify_signature_valid,
    &ExternalRollbackFloorObservationV1::post_certify_qualifying_data_exact,
    &ExternalRollbackFloorObservationV1::post_certify_nv_name_exact,
    &ExternalRollbackFloorObservationV1::post_certify_contents_exact,
    &ExternalRollbackFloorObservationV1::witness_predecessor_exact,
    &ExternalRollbackFloorObservationV1::exactly_one_witness_compare_advance,
    &ExternalRollbackFloorObservationV1::witness_response_content_bound,
    &ExternalRollbackFloorObservationV1::witness_response_exact,
    &ExternalRollbackFloorObservationV1::witness_receipt_signature_valid,
    &ExternalRollbackFloorObservationV1::duplicate_query_only,
    &ExternalRollbackFloorObservationV1::ambiguous_completion_query_only,
    &ExternalRollbackFloorObservationV1::reopen_query_only,
    &ExternalRollbackFloorObservationV1::no_second_nv_extend_route,
    &ExternalRollbackFloorObservationV1::witness_outside_restorable_image,
    &ExternalRollbackFloorObservationV1::witness_recovery_root_distinct,
    &ExternalRollbackFloorObservationV1::platform_replacement_requires_succession,
    &ExternalRollbackFloorObservationV1::nv_undefine_redefine_detectable,
    &ExternalRollbackFloorObservationV1::restore_continuity_bound,
    &ExternalRollbackFloorObservationV1::portable_clone_replay_excluded,
}};

constexpr std::array<ExternalRollbackFloorDisposition, 58U> kFailures{{
    ExternalRollbackFloorDisposition::profile_unavailable,
    ExternalRollbackFloorDisposition::tpm_family_rejected,
    ExternalRollbackFloorDisposition::release_pin_unproved,
    ExternalRollbackFloorDisposition::platform_incarnation_unavailable,
    ExternalRollbackFloorDisposition::platform_incarnation_mismatch,
    ExternalRollbackFloorDisposition::ak_coordinate_unavailable,
    ExternalRollbackFloorDisposition::ak_coordinate_mismatch,
    ExternalRollbackFloorDisposition::nv_public_unavailable,
    ExternalRollbackFloorDisposition::nv_name_mismatch,
    ExternalRollbackFloorDisposition::name_algorithm_rejected,
    ExternalRollbackFloorDisposition::nv_type_rejected,
    ExternalRollbackFloorDisposition::nv_buffer_capacity_unproved,
    ExternalRollbackFloorDisposition::nv_data_size_rejected,
    ExternalRollbackFloorDisposition::orderly_persistence_unproved,
    ExternalRollbackFloorDisposition::write_policy_rejected,
    ExternalRollbackFloorDisposition::read_policy_rejected,
    ExternalRollbackFloorDisposition::delete_policy_rejected,
    ExternalRollbackFloorDisposition::platform_create_rejected,
    ExternalRollbackFloorDisposition::candidate_platform_admin_open,
    ExternalRollbackFloorDisposition::appraiser_platform_admin_open,
    ExternalRollbackFloorDisposition::witness_administration_not_distinct,
    ExternalRollbackFloorDisposition::v18_spend_record_unavailable,
    ExternalRollbackFloorDisposition::v18_spend_record_rejected,
    ExternalRollbackFloorDisposition::v18_spend_digest_mismatch,
    ExternalRollbackFloorDisposition::witness_challenge_rejected,
    ExternalRollbackFloorDisposition::pre_certify_unavailable,
    ExternalRollbackFloorDisposition::pre_certify_signature_rejected,
    ExternalRollbackFloorDisposition::pre_certify_qualifying_data_mismatch,
    ExternalRollbackFloorDisposition::pre_certify_nv_name_mismatch,
    ExternalRollbackFloorDisposition::pre_certify_contents_mismatch,
    ExternalRollbackFloorDisposition::predecessor_generation_mismatch,
    ExternalRollbackFloorDisposition::predecessor_head_mismatch,
    ExternalRollbackFloorDisposition::append_record_encode_rejected,
    ExternalRollbackFloorDisposition::append_record_canonicality_rejected,
    ExternalRollbackFloorDisposition::append_record_profile_mismatch,
    ExternalRollbackFloorDisposition::append_record_spend_mismatch,
    ExternalRollbackFloorDisposition::nv_extend_successor_mismatch,
    ExternalRollbackFloorDisposition::nv_extend_attempt_count_rejected,
    ExternalRollbackFloorDisposition::post_certify_unavailable,
    ExternalRollbackFloorDisposition::post_certify_signature_rejected,
    ExternalRollbackFloorDisposition::post_certify_qualifying_data_mismatch,
    ExternalRollbackFloorDisposition::post_certify_nv_name_mismatch,
    ExternalRollbackFloorDisposition::post_certify_contents_mismatch,
    ExternalRollbackFloorDisposition::witness_predecessor_mismatch,
    ExternalRollbackFloorDisposition::witness_compare_advance_count_rejected,
    ExternalRollbackFloorDisposition::witness_response_not_content_bound,
    ExternalRollbackFloorDisposition::witness_response_mismatch,
    ExternalRollbackFloorDisposition::witness_receipt_signature_rejected,
    ExternalRollbackFloorDisposition::duplicate_not_query_only,
    ExternalRollbackFloorDisposition::ambiguous_completion_not_query_only,
    ExternalRollbackFloorDisposition::reopen_not_query_only,
    ExternalRollbackFloorDisposition::second_nv_extend_route_open,
    ExternalRollbackFloorDisposition::witness_inside_restorable_image,
    ExternalRollbackFloorDisposition::witness_recovery_root_not_distinct,
    ExternalRollbackFloorDisposition::platform_succession_unproved,
    ExternalRollbackFloorDisposition::nv_redefinition_undetectable,
    ExternalRollbackFloorDisposition::restore_continuity_unproved,
    ExternalRollbackFloorDisposition::portable_clone_replay_open,
}};

[[nodiscard]] bool ordered(
    const ExternalRollbackFloorObservationV1& value) noexcept {
    bool false_seen = false;
    for (const Field field : kFields) {
        const bool present = value.*field;
        if (!present) false_seen = true;
        else if (false_seen) return false;
    }
    return true;
}

}  // namespace

bool encode_external_floor_record(
    const ExternalFloorRecordV1& record,
    EncodedExternalFloorRecord& output) noexcept {
    if (!invariant(record)) return false;
    output.fill(0U);
    std::copy(kMagic.begin(), kMagic.end(), output.begin());
    output[8U] = kVersion;
    output[9U] = kSha256Algorithm;
    put_u16(output, 10U, static_cast<std::uint16_t>(output.size()));
    put_u32(output, 12U, kProfileFlags);
    put_u64(output, 16U, record.generation_from);
    put_u64(output, 24U, record.generation_to);
    std::copy(record.profile_identity.begin(), record.profile_identity.end(),
              output.begin() + 32);
    std::copy(record.platform_incarnation.begin(),
              record.platform_incarnation.end(), output.begin() + 64);
    std::copy(record.nv_name.begin(), record.nv_name.end(), output.begin() + 96);
    std::copy(record.predecessor_head.begin(), record.predecessor_head.end(),
              output.begin() + 128);
    std::copy(record.receipt_spend_head.begin(), record.receipt_spend_head.end(),
              output.begin() + 160);
    std::copy(record.witness_challenge.begin(), record.witness_challenge.end(),
              output.begin() + 192);
    std::copy(record.witness_incarnation.begin(),
              record.witness_incarnation.end(), output.begin() + 224);
    put_u32(output, 284U,
            generation_journal::record_crc32(output.data(), 284U));
    return true;
}

bool decode_external_floor_record(
    const EncodedExternalFloorRecord& input,
    ExternalFloorRecordV1& output) noexcept {
    if (!std::equal(kMagic.begin(), kMagic.end(), input.begin())
        || input[8U] != kVersion || input[9U] != kSha256Algorithm
        || get_u16(input, 10U) != input.size()
        || get_u32(input, 12U) != kProfileFlags
        || get_u32(input, 284U)
            != generation_journal::record_crc32(input.data(), 284U)) {
        return false;
    }
    for (std::size_t index = 256U; index < 284U; ++index) {
        if (input[index] != 0U) return false;
    }
    ExternalFloorRecordV1 candidate;
    candidate.generation_from = get_u64(input, 16U);
    candidate.generation_to = get_u64(input, 24U);
    std::copy(input.begin() + 32, input.begin() + 64,
              candidate.profile_identity.begin());
    std::copy(input.begin() + 64, input.begin() + 96,
              candidate.platform_incarnation.begin());
    std::copy(input.begin() + 96, input.begin() + 128,
              candidate.nv_name.begin());
    std::copy(input.begin() + 128, input.begin() + 160,
              candidate.predecessor_head.begin());
    std::copy(input.begin() + 160, input.begin() + 192,
              candidate.receipt_spend_head.begin());
    std::copy(input.begin() + 192, input.begin() + 224,
              candidate.witness_challenge.begin());
    std::copy(input.begin() + 224, input.begin() + 256,
              candidate.witness_incarnation.begin());
    if (!invariant(candidate)) return false;
    output = candidate;
    return true;
}

ExternalFloorDigest external_floor_record_digest(
    const EncodedExternalFloorRecord& record) {
    return generation_journal::sha256(
        std::span<const std::uint8_t>(record.data(), record.size()));
}

ExternalFloorDigest tpm_nv_extend_successor(
    const ExternalFloorDigest& predecessor,
    const EncodedExternalFloorRecord& record) {
    std::array<std::uint8_t,
               ExternalFloorDigest{}.size() + kExternalFloorRecordBytes> input{};
    auto cursor = std::copy(predecessor.begin(), predecessor.end(), input.begin());
    (void)std::copy(record.begin(), record.end(), cursor);
    return generation_journal::sha256(
        std::span<const std::uint8_t>(input.data(), input.size()));
}

std::optional<EncodedExternalFloorRecord> make_external_floor_record(
    const EncodedReceiptSpendRecord& receipt_spend_record,
    const ExternalFloorDigest& profile_identity,
    const ExternalFloorDigest& platform_incarnation,
    const ExternalFloorDigest& nv_name,
    const ExternalFloorDigest& witness_challenge,
    const ExternalFloorDigest& witness_incarnation) noexcept {
    generation_journal::SpendRecordV1 spend;
    if (!generation_journal::decode_spend_record(receipt_spend_record, spend)
        || !nonzero(profile_identity) || !nonzero(platform_incarnation)
        || !nonzero(nv_name) || !nonzero(witness_challenge)
        || !nonzero(witness_incarnation)) {
        return std::nullopt;
    }
    ExternalFloorRecordV1 record;
    record.generation_from = spend.generation_from;
    record.generation_to = spend.generation_to;
    record.profile_identity = profile_identity;
    record.platform_incarnation = platform_incarnation;
    record.nv_name = nv_name;
    record.predecessor_head = spend.predecessor_head;
    record.receipt_spend_head =
        generation_journal::spend_record_head(receipt_spend_record);
    record.witness_challenge = witness_challenge;
    record.witness_incarnation = witness_incarnation;
    EncodedExternalFloorRecord encoded{};
    if (!encode_external_floor_record(record, encoded)) return std::nullopt;
    return encoded;
}

ExternalRollbackFloorAssessment assess_external_rollback_floor(
    const ExternalRollbackFloorObservationV1& observation) noexcept {
    ExternalRollbackFloorAssessment result;
    if (!ordered(observation)) return result;
    result.observation_coherent = true;
    std::size_t prefix = 0U;
    while (prefix < kFields.size() && observation.*kFields[prefix]) ++prefix;
    result.disposition = prefix == kFields.size()
        ? ExternalRollbackFloorDisposition::cross_ledger_join_unproved
        : kFailures[prefix];
    result.exact_tpm_nv_profile_bound = prefix >= 21U;
    result.v18_spend_input_bound = prefix >= 25U;
    result.prestate_certified = prefix >= 32U;
    result.content_bound_extend_request = prefix >= 38U;
    result.poststate_certified = prefix >= 43U;
    result.independent_witness_advanced = prefix >= 48U;
    result.query_only_recovery_bound = prefix >= 52U;
    result.complete_dual_ledger_transcript_bound = prefix == kFields.size();
    result.cross_ledger_atomic_join_bound = false;
    result.query_only_cross_ledger_recovery_bound = false;
    result.external_rollback_floor_bound = false;
    result.eligible_for_v18_external_floor_premise = false;
    result.portable_clone_replay_excluded = prefix == kFields.size();
    return result;
}

const char* external_rollback_floor_disposition_name(
    const ExternalRollbackFloorDisposition value) noexcept {
#define SLOPOS_CASE(name) case ExternalRollbackFloorDisposition::name: return #name
    switch (value) {
    SLOPOS_CASE(observation_incoherent); SLOPOS_CASE(profile_unavailable);
    SLOPOS_CASE(tpm_family_rejected); SLOPOS_CASE(release_pin_unproved);
    SLOPOS_CASE(platform_incarnation_unavailable); SLOPOS_CASE(platform_incarnation_mismatch);
    SLOPOS_CASE(ak_coordinate_unavailable); SLOPOS_CASE(ak_coordinate_mismatch);
    SLOPOS_CASE(nv_public_unavailable); SLOPOS_CASE(nv_name_mismatch);
    SLOPOS_CASE(name_algorithm_rejected); SLOPOS_CASE(nv_type_rejected);
    SLOPOS_CASE(nv_buffer_capacity_unproved); SLOPOS_CASE(nv_data_size_rejected);
    SLOPOS_CASE(orderly_persistence_unproved); SLOPOS_CASE(write_policy_rejected);
    SLOPOS_CASE(read_policy_rejected); SLOPOS_CASE(delete_policy_rejected);
    SLOPOS_CASE(platform_create_rejected); SLOPOS_CASE(candidate_platform_admin_open);
    SLOPOS_CASE(appraiser_platform_admin_open); SLOPOS_CASE(witness_administration_not_distinct);
    SLOPOS_CASE(v18_spend_record_unavailable); SLOPOS_CASE(v18_spend_record_rejected);
    SLOPOS_CASE(v18_spend_digest_mismatch); SLOPOS_CASE(witness_challenge_rejected);
    SLOPOS_CASE(pre_certify_unavailable); SLOPOS_CASE(pre_certify_signature_rejected);
    SLOPOS_CASE(pre_certify_qualifying_data_mismatch); SLOPOS_CASE(pre_certify_nv_name_mismatch);
    SLOPOS_CASE(pre_certify_contents_mismatch); SLOPOS_CASE(predecessor_generation_mismatch);
    SLOPOS_CASE(predecessor_head_mismatch); SLOPOS_CASE(append_record_encode_rejected);
    SLOPOS_CASE(append_record_canonicality_rejected); SLOPOS_CASE(append_record_profile_mismatch);
    SLOPOS_CASE(append_record_spend_mismatch); SLOPOS_CASE(nv_extend_successor_mismatch);
    SLOPOS_CASE(nv_extend_attempt_count_rejected); SLOPOS_CASE(post_certify_unavailable);
    SLOPOS_CASE(post_certify_signature_rejected); SLOPOS_CASE(post_certify_qualifying_data_mismatch);
    SLOPOS_CASE(post_certify_nv_name_mismatch); SLOPOS_CASE(post_certify_contents_mismatch);
    SLOPOS_CASE(witness_predecessor_mismatch); SLOPOS_CASE(witness_compare_advance_count_rejected);
    SLOPOS_CASE(witness_response_not_content_bound); SLOPOS_CASE(witness_response_mismatch);
    SLOPOS_CASE(witness_receipt_signature_rejected); SLOPOS_CASE(duplicate_not_query_only);
    SLOPOS_CASE(ambiguous_completion_not_query_only); SLOPOS_CASE(reopen_not_query_only);
    SLOPOS_CASE(second_nv_extend_route_open); SLOPOS_CASE(witness_inside_restorable_image);
    SLOPOS_CASE(witness_recovery_root_not_distinct); SLOPOS_CASE(platform_succession_unproved);
    SLOPOS_CASE(nv_redefinition_undetectable); SLOPOS_CASE(restore_continuity_unproved);
    SLOPOS_CASE(portable_clone_replay_open); SLOPOS_CASE(cross_ledger_join_unproved);
    SLOPOS_CASE(external_rollback_floor_premise);
    }
#undef SLOPOS_CASE
    return "invalid";
}

}  // namespace slopos::e0::handoff_cell
