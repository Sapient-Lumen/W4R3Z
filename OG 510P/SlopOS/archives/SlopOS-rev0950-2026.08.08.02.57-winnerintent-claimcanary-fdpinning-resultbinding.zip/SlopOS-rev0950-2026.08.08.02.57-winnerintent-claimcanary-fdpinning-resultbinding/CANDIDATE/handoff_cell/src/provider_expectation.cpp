#include "slopos/e0/handoff_cell/provider_expectation.hpp"

#include <algorithm>
#include <array>
#include <cerrno>
#include <cstddef>
#include <cstdint>
#include <utility>

#include <fcntl.h>
#include <poll.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <unistd.h>

namespace slopos::e0::handoff_cell {
namespace {

constexpr std::array<std::uint8_t, 8U> kMagic{{
    'S', 'L', 'O', 'P', 'E', 'X', 'P', '1'}};
constexpr std::uint32_t kVersion = 1U;
constexpr int kRequiredSeals =
    F_SEAL_SEAL | F_SEAL_SHRINK | F_SEAL_GROW | F_SEAL_WRITE;

void close_if_open(int& fd) noexcept {
    if (fd >= 0) {
        (void)::close(fd);
        fd = -1;
    }
}

[[nodiscard]] bool descriptor_cloexec(
    const int fd, int& error_number) noexcept {
    const int flags = ::fcntl(fd, F_GETFD);
    if (flags < 0) {
        error_number = errno;
        return false;
    }
    if ((flags & FD_CLOEXEC) == 0) {
        error_number = EPROTO;
        return false;
    }
    return true;
}

[[nodiscard]] std::uint32_t read_u32(
    const std::array<std::uint8_t, kProviderExpectationBytes>& bytes,
    const std::size_t offset) noexcept {
    std::uint32_t value = 0U;
    for (std::size_t index = 0U; index < 4U; ++index) {
        value |= static_cast<std::uint32_t>(bytes[offset + index])
            << static_cast<unsigned int>(index * 8U);
    }
    return value;
}

[[nodiscard]] std::uint64_t read_u64(
    const std::array<std::uint8_t, kProviderExpectationBytes>& bytes,
    const std::size_t offset) noexcept {
    std::uint64_t value = 0U;
    for (std::size_t index = 0U; index < 8U; ++index) {
        value |= static_cast<std::uint64_t>(bytes[offset + index])
            << static_cast<unsigned int>(index * 8U);
    }
    return value;
}

[[nodiscard]] bool read_record(
    const int record_fd,
    std::array<std::uint8_t, kProviderExpectationBytes>& bytes,
    int& error_number) noexcept {
    std::size_t offset = 0U;
    while (offset < bytes.size()) {
        const ssize_t count = ::pread(
            record_fd, bytes.data() + offset, bytes.size() - offset,
            static_cast<off_t>(offset));
        if (count < 0 && errno == EINTR) continue;
        if (count <= 0) {
            error_number = count == 0 ? EPROTO : errno;
            return false;
        }
        offset += static_cast<std::size_t>(count);
    }
    return true;
}

[[nodiscard]] bool pidfd_shape(
    const int pidfd, int& error_number) noexcept {
#if defined(SYS_pidfd_send_signal)
    errno = 0;
    const long result = ::syscall(
        SYS_pidfd_send_signal, pidfd, 0, nullptr, 0U);
    if (result != 0 && errno != EPERM && errno != ESRCH) {
        error_number = errno == 0 ? EPROTO : errno;
        return false;
    }
#else
    error_number = ENOSYS;
    return false;
#endif
    pollfd descriptor{pidfd, POLLIN | POLLHUP, 0};
    int poll_result = -1;
    do {
        poll_result = ::poll(&descriptor, 1U, 0);
    } while (poll_result < 0 && errno == EINTR);
    if (poll_result < 0) {
        error_number = errno;
        return false;
    }
    if (poll_result != 0
        && (descriptor.revents
            & static_cast<short>(POLLIN | POLLHUP | POLLERR | POLLNVAL))
            != 0) {
        error_number = ESTALE;
        return false;
    }
    return true;
}

[[nodiscard]] bool parse_record(
    const std::array<std::uint8_t, kProviderExpectationBytes>& bytes,
    ProviderExpectationView& view) noexcept {
    if (!std::equal(kMagic.begin(), kMagic.end(), bytes.begin())
        || read_u32(bytes, 8U) != kVersion
        || read_u32(bytes, 12U) != 0U) {
        return false;
    }
    view.serial = read_u64(bytes, 16U);
    view.provider_uid = static_cast<uid_t>(read_u32(bytes, 24U));
    view.provider_gid = static_cast<gid_t>(read_u32(bytes, 28U));
    view.query_uid = static_cast<uid_t>(read_u32(bytes, 32U));
    view.query_gid = static_cast<gid_t>(read_u32(bytes, 36U));
    view.process.device = read_u64(bytes, 40U);
    view.process.inode = read_u64(bytes, 48U);
    std::copy_n(
        bytes.begin() + 56, kProviderExpectationBindingBytes,
        view.owner_binding.begin());
    const bool binding_nonzero = std::any_of(
        view.owner_binding.begin(), view.owner_binding.end(),
        [](const std::uint8_t value) { return value != 0U; });
    const bool reserved_zero = std::all_of(
        bytes.begin() + 88, bytes.end(),
        [](const std::uint8_t value) { return value == 0U; });
    return view.serial != 0U
        && view.provider_uid != 0U
        && view.query_uid != 0U
        && view.process.valid()
        && binding_nonzero
        && reserved_zero;
}

}  // namespace

ExpectedProviderProcess::ExpectedProviderProcess(
    ExpectedProviderProcess&& other) noexcept
    : record_fd_(std::exchange(other.record_fd_, -1)),
      pidfd_(std::exchange(other.pidfd_, -1)),
      view_(other.view_),
      fresh_(std::exchange(other.fresh_, false)) {}

ExpectedProviderProcess& ExpectedProviderProcess::operator=(
    ExpectedProviderProcess&& other) noexcept {
    if (this != &other) {
        close_if_open(record_fd_);
        close_if_open(pidfd_);
        record_fd_ = std::exchange(other.record_fd_, -1);
        pidfd_ = std::exchange(other.pidfd_, -1);
        view_ = other.view_;
        fresh_ = std::exchange(other.fresh_, false);
    }
    return *this;
}

ExpectedProviderProcess::~ExpectedProviderProcess() {
    close_if_open(record_fd_);
    close_if_open(pidfd_);
}

std::optional<ExpectedProviderProcess> ExpectedProviderProcess::adopt_sealed(
    int record_fd, int pidfd,
    const uid_t expected_query_uid, const gid_t expected_query_gid,
    const uid_t expected_provider_uid, const gid_t expected_provider_gid,
    int& error_number) noexcept {
    error_number = 0;
    auto reject = [&record_fd, &pidfd, &error_number](const int error) {
        close_if_open(record_fd);
        close_if_open(pidfd);
        error_number = error;
        return std::optional<ExpectedProviderProcess>{};
    };
    if (record_fd < 0 || pidfd < 0 || record_fd == pidfd) {
        return reject(EBADF);
    }
    if (expected_query_uid == 0U || expected_provider_uid == 0U
        || ::geteuid() != expected_query_uid
        || ::getegid() != expected_query_gid) {
        return reject(EPERM);
    }
    int observed_error = 0;
    if (!descriptor_cloexec(record_fd, observed_error)
        || !descriptor_cloexec(pidfd, observed_error)) {
        return reject(observed_error);
    }
    struct stat record_status {};
    if (::fstat(record_fd, &record_status) != 0) {
        return reject(errno);
    }
    if (!S_ISREG(record_status.st_mode)
        || record_status.st_nlink != 0
        || record_status.st_size
            != static_cast<off_t>(kProviderExpectationBytes)) {
        return reject(EPROTO);
    }
    const int seals = ::fcntl(record_fd, F_GET_SEALS);
    if (seals < 0) return reject(errno);
    if (seals != kRequiredSeals) return reject(EPROTO);

    std::array<std::uint8_t, kProviderExpectationBytes> bytes{};
    if (!read_record(record_fd, bytes, observed_error)) {
        return reject(observed_error);
    }
    ProviderExpectationView view{};
    if (!parse_record(bytes, view)
        || view.query_uid != expected_query_uid
        || view.query_gid != expected_query_gid
        || view.provider_uid != expected_provider_uid
        || view.provider_gid != expected_provider_gid) {
        return reject(EPROTO);
    }
    struct stat process_status {};
    if (::fstat(pidfd, &process_status) != 0) return reject(errno);
    const EndpointProcessIdentity process{
        static_cast<std::uint64_t>(process_status.st_dev),
        static_cast<std::uint64_t>(process_status.st_ino)};
    if (!process.valid() || !(process == view.process)) {
        return reject(ESTALE);
    }
    if (!pidfd_shape(pidfd, observed_error)) return reject(observed_error);
    return ExpectedProviderProcess(record_fd, pidfd, view);
}

ExpectedProviderConnectResult connect_fixed_endpoint_expected(
    const int public_directory_fd, const uid_t expected_query_uid,
    const uid_t expected_publisher_uid, const uid_t expected_provider_uid,
    const gid_t expected_provider_gid, ExpectedProviderProcess expectation,
    int& error_number) noexcept {
    ExpectedProviderConnectResult result;
    error_number = 0;
    if (!expectation.fresh_
        || expectation.record_fd_ < 0 || expectation.pidfd_ < 0
        || expectation.view_.query_uid != expected_query_uid
        || expectation.view_.provider_uid != expected_provider_uid
        || expectation.view_.provider_gid != expected_provider_gid) {
        error_number = EINVAL;
        result.error_number = error_number;
        return result;
    }

    result.expectation_serial = expectation.view_.serial;
    result.expected_process = expectation.view_.process;
    // The burn precedes socket creation.  This closes the supplied pidfd's
    // potential signal/setns/getfd surface as well as the immutable record.
    close_if_open(expectation.record_fd_);
    close_if_open(expectation.pidfd_);
    expectation.fresh_ = false;
    result.expectation_spent_before_connect = true;

    int connect_error = 0;
    auto connection = connect_fixed_endpoint(
        public_directory_fd, expected_query_uid, expected_publisher_uid,
        expected_provider_uid, expected_provider_gid, connect_error);
    if (!connection.has_value()) {
        error_number = connect_error;
        result.error_number = connect_error;
        result.disposition = ExpectedProviderConnectDisposition::connect_failed;
        return result;
    }
    result.observed_process = connection->peer().process;
    if (!(result.observed_process == result.expected_process)) {
        error_number = ESTALE;
        result.error_number = ESTALE;
        result.disposition =
            ExpectedProviderConnectDisposition::process_mismatch;
        return result;
    }
    result.disposition =
        ExpectedProviderConnectDisposition::connected_expected;
    result.connection.emplace(std::move(*connection));
    return result;
}

const char* expected_provider_connect_name(
    const ExpectedProviderConnectDisposition value) noexcept {
    switch (value) {
        case ExpectedProviderConnectDisposition::connected_expected:
            return "CONNECTED_EXPECTED";
        case ExpectedProviderConnectDisposition::expectation_invalid:
            return "EXPECTATION_INVALID";
        case ExpectedProviderConnectDisposition::connect_failed:
            return "CONNECT_FAILED";
        case ExpectedProviderConnectDisposition::process_mismatch:
            return "PROCESS_MISMATCH";
    }
    return "EXPECTATION_INVALID";
}

}  // namespace slopos::e0::handoff_cell
