#include "slopos/e0/handoff_cell/actor_exec_binding.hpp"

#include <array>
#include <cstddef>

namespace slopos::e0::handoff_cell {
namespace {

constexpr std::size_t kFieldCount = 49U;
using Fields = std::array<bool, kFieldCount>;

[[nodiscard]] Fields fields(const ActorExecObservationV2& v) noexcept {
    return {v.profile_supplied,
            v.executable_descriptor_supplied,
            v.executable_regular,
            v.executable_readable,
            v.executable_unlinked,
            v.executable_size_bounded,
            v.executable_profile_digest_exact,
            v.executable_seal_query_supported,
            v.executable_seal_write,
            v.executable_seal_grow,
            v.executable_seal_shrink,
            v.executable_seal_seal,
            v.child_single_threaded,
            v.child_file_table_private_until_exec,
            v.child_address_space_private_until_exec,
            v.challenge_endpoint_exclusive_to_tracee,
            v.actor_pidfd_supplied_before_release,
            v.tracer_established_before_release,
            v.traceexec_armed_before_release,
            v.execveat_entry_observed,
            v.execveat_arch_exact,
            v.execveat_empty_path,
            v.execveat_flags_exact,
            v.execveat_target_fd_exact,
            v.exec_argument_memory_stable_until_consumed,
            v.pidfd_getfd_supported,
            v.target_descriptor_duplicated_while_stopped,
            v.target_regular,
            v.target_same_inode_as_sealed_executable,
            v.target_required_seals_present,
            v.target_digest_exact,
            v.exec_event_completes_observed_entry,
            v.successful_exec_event_observed,
            v.exactly_one_exec_event,
            v.challenge_generated_after_exec_event,
            v.challenge_response_exact,
            v.runtime_interpreter_and_objects_bound,
            v.exec_epoch_held_through_actor_admission,
            v.pre_exec_privilege_floor_exact,
            v.pre_exec_seccomp_filter_exact,
            v.v14_dossier_admissible,
            v.dossier_appraised_after_bound_exec,
            v.dossier_executable_digest_matches_exec_target,
            v.dossier_process_coordinate_matches_launch,
            v.dossier_runtime_objects_match_launch,
            v.dossier_challenge_matches_post_exec_epoch,
            v.dossier_launch_envelope_matches_observed_exec,
            v.dossier_privilege_and_filter_match_launch,
            v.dossier_inherited_descriptor_inventory_matches_launch};
}

[[nodiscard]] bool coherent(const Fields& values) noexcept {
    bool gap = false;
    for (const bool value : values) {
        if (!value) {
            gap = true;
        } else if (gap) {
            return false;
        }
    }
    return true;
}

[[nodiscard]] bool prefix(const Fields& values,
                          const std::size_t count) noexcept {
    for (std::size_t index = 0U; index < count; ++index) {
        if (!values[index]) return false;
    }
    return true;
}

[[nodiscard]] std::size_t first_false(const Fields& values) noexcept {
    for (std::size_t index = 0U; index < values.size(); ++index) {
        if (!values[index]) return index;
    }
    return values.size();
}

[[nodiscard]] ActorExecDisposition disposition_for_cut(
    const std::size_t cut) noexcept {
    if (cut == 0U) return ActorExecDisposition::profile_unavailable;
    if (cut == 1U) return ActorExecDisposition::executable_descriptor_unavailable;
    if (cut < 6U) return ActorExecDisposition::executable_shape_rejected;
    if (cut == 6U) return ActorExecDisposition::executable_digest_mismatch;
    if (cut < 12U) return ActorExecDisposition::executable_mutability_rejected;
    if (cut == 12U) return ActorExecDisposition::single_threaded_child_unproved;
    if (cut == 13U) return ActorExecDisposition::file_table_custody_unproved;
    if (cut == 14U) return ActorExecDisposition::address_space_custody_unproved;
    if (cut == 15U) return ActorExecDisposition::challenge_channel_custody_unproved;
    if (cut == 16U) return ActorExecDisposition::pidfd_coordinate_unavailable;
    if (cut == 17U) return ActorExecDisposition::tracer_unavailable;
    if (cut == 18U) return ActorExecDisposition::traceexec_not_armed;
    if (cut == 19U) return ActorExecDisposition::execveat_entry_unobserved;
    if (cut < 24U) return ActorExecDisposition::execveat_contract_rejected;
    if (cut == 24U) return ActorExecDisposition::exec_argument_memory_custody_unproved;
    if (cut == 25U) return ActorExecDisposition::target_descriptor_query_unavailable;
    if (cut == 26U) return ActorExecDisposition::target_descriptor_unavailable;
    if (cut < 29U) return ActorExecDisposition::target_object_mismatch;
    if (cut == 29U) return ActorExecDisposition::target_seal_mismatch;
    if (cut == 30U) return ActorExecDisposition::target_digest_mismatch;
    if (cut == 31U) return ActorExecDisposition::exec_event_not_linked_to_entry;
    if (cut == 32U) return ActorExecDisposition::exec_event_unobserved;
    if (cut == 33U) return ActorExecDisposition::multiple_exec_events;
    if (cut == 34U) return ActorExecDisposition::challenge_order_rejected;
    if (cut == 35U) return ActorExecDisposition::challenge_response_rejected;
    if (cut == 36U) return ActorExecDisposition::runtime_objects_unbound;
    if (cut == 37U) return ActorExecDisposition::exec_epoch_custody_unproved;
    if (cut == 38U) return ActorExecDisposition::pre_exec_privilege_floor_unproved;
    if (cut == 39U) return ActorExecDisposition::pre_exec_seccomp_filter_unproved;
    if (cut == 40U) return ActorExecDisposition::v14_dossier_unavailable;
    if (cut == 41U) return ActorExecDisposition::dossier_order_rejected;
    if (cut == 42U) return ActorExecDisposition::dossier_executable_mismatch;
    if (cut == 43U) return ActorExecDisposition::dossier_process_mismatch;
    if (cut == 44U) return ActorExecDisposition::dossier_runtime_mismatch;
    if (cut == 45U) return ActorExecDisposition::dossier_challenge_mismatch;
    if (cut == 46U) return ActorExecDisposition::dossier_launch_envelope_mismatch;
    if (cut == 47U) return ActorExecDisposition::dossier_privilege_floor_mismatch;
    if (cut == 48U) return ActorExecDisposition::dossier_descriptor_inventory_mismatch;
    return ActorExecDisposition::actor_exec_and_dossier_bound;
}

}  // namespace

ActorExecAssessment assess_actor_exec_binding(
    const ActorExecObservationV2& observation) noexcept {
    const Fields values = fields(observation);
    ActorExecAssessment result;
    result.observation_coherent = coherent(values);
    result.sealed_exec_input_exact = prefix(values, 12U);
    result.launch_coordinate_custody = prefix(values, 17U);
    result.traceexec_prearmed = prefix(values, 19U);
    result.execveat_contract_observed = prefix(values, 25U);
    result.target_descriptor_snapshotted = prefix(values, 27U);
    result.target_object_exact = prefix(values, 30U);
    result.target_digest_exact = prefix(values, 31U);
    result.successful_exec_event_exact = prefix(values, 34U);
    result.post_exec_challenge_exact = prefix(values, 36U);
    result.exec_input_object_bound = result.observation_coherent
        && result.post_exec_challenge_exact;
    result.runtime_object_set_bound = result.observation_coherent
        && prefix(values, 37U);
    result.exec_epoch_held = result.observation_coherent
        && prefix(values, 38U);
    result.pre_exec_floor_bound = result.observation_coherent
        && prefix(values, 40U);
    result.v14_dossier_bound_to_exec_epoch = result.observation_coherent
        && prefix(values, 49U);
    result.eligible_for_v13_actor_premise =
        result.v14_dossier_bound_to_exec_epoch;
    // Even a complete V15 composition is an admission relation, not a proof of
    // every instruction or mutable mapping in a running process.
    result.complete_process_image_bound = false;
    result.disposition = result.observation_coherent
        ? disposition_for_cut(first_false(values))
        : ActorExecDisposition::observation_incoherent;
    return result;
}

const char* actor_exec_disposition_name(
    const ActorExecDisposition value) noexcept {
    switch (value) {
    case ActorExecDisposition::observation_incoherent: return "OBSERVATION_INCOHERENT";
    case ActorExecDisposition::profile_unavailable: return "PROFILE_UNAVAILABLE";
    case ActorExecDisposition::executable_descriptor_unavailable: return "EXECUTABLE_DESCRIPTOR_UNAVAILABLE";
    case ActorExecDisposition::executable_shape_rejected: return "EXECUTABLE_SHAPE_REJECTED";
    case ActorExecDisposition::executable_digest_mismatch: return "EXECUTABLE_DIGEST_MISMATCH";
    case ActorExecDisposition::executable_mutability_rejected: return "EXECUTABLE_MUTABILITY_REJECTED";
    case ActorExecDisposition::single_threaded_child_unproved: return "SINGLE_THREADED_CHILD_UNPROVED";
    case ActorExecDisposition::file_table_custody_unproved: return "FILE_TABLE_CUSTODY_UNPROVED";
    case ActorExecDisposition::address_space_custody_unproved: return "ADDRESS_SPACE_CUSTODY_UNPROVED";
    case ActorExecDisposition::challenge_channel_custody_unproved: return "CHALLENGE_CHANNEL_CUSTODY_UNPROVED";
    case ActorExecDisposition::pidfd_coordinate_unavailable: return "PIDFD_COORDINATE_UNAVAILABLE";
    case ActorExecDisposition::tracer_unavailable: return "TRACER_UNAVAILABLE";
    case ActorExecDisposition::traceexec_not_armed: return "TRACEEXEC_NOT_ARMED";
    case ActorExecDisposition::execveat_entry_unobserved: return "EXECVEAT_ENTRY_UNOBSERVED";
    case ActorExecDisposition::execveat_contract_rejected: return "EXECVEAT_CONTRACT_REJECTED";
    case ActorExecDisposition::exec_argument_memory_custody_unproved: return "EXEC_ARGUMENT_MEMORY_CUSTODY_UNPROVED";
    case ActorExecDisposition::target_descriptor_query_unavailable: return "TARGET_DESCRIPTOR_QUERY_UNAVAILABLE";
    case ActorExecDisposition::target_descriptor_unavailable: return "TARGET_DESCRIPTOR_UNAVAILABLE";
    case ActorExecDisposition::target_object_mismatch: return "TARGET_OBJECT_MISMATCH";
    case ActorExecDisposition::target_seal_mismatch: return "TARGET_SEAL_MISMATCH";
    case ActorExecDisposition::target_digest_mismatch: return "TARGET_DIGEST_MISMATCH";
    case ActorExecDisposition::exec_event_not_linked_to_entry: return "EXEC_EVENT_NOT_LINKED_TO_ENTRY";
    case ActorExecDisposition::exec_event_unobserved: return "EXEC_EVENT_UNOBSERVED";
    case ActorExecDisposition::multiple_exec_events: return "MULTIPLE_EXEC_EVENTS";
    case ActorExecDisposition::challenge_order_rejected: return "CHALLENGE_ORDER_REJECTED";
    case ActorExecDisposition::challenge_response_rejected: return "CHALLENGE_RESPONSE_REJECTED";
    case ActorExecDisposition::runtime_objects_unbound: return "RUNTIME_OBJECTS_UNBOUND";
    case ActorExecDisposition::exec_epoch_custody_unproved: return "EXEC_EPOCH_CUSTODY_UNPROVED";
    case ActorExecDisposition::pre_exec_privilege_floor_unproved: return "PRE_EXEC_PRIVILEGE_FLOOR_UNPROVED";
    case ActorExecDisposition::pre_exec_seccomp_filter_unproved: return "PRE_EXEC_SECCOMP_FILTER_UNPROVED";
    case ActorExecDisposition::v14_dossier_unavailable: return "V14_DOSSIER_UNAVAILABLE";
    case ActorExecDisposition::dossier_order_rejected: return "DOSSIER_ORDER_REJECTED";
    case ActorExecDisposition::dossier_executable_mismatch: return "DOSSIER_EXECUTABLE_MISMATCH";
    case ActorExecDisposition::dossier_process_mismatch: return "DOSSIER_PROCESS_MISMATCH";
    case ActorExecDisposition::dossier_runtime_mismatch: return "DOSSIER_RUNTIME_MISMATCH";
    case ActorExecDisposition::dossier_challenge_mismatch: return "DOSSIER_CHALLENGE_MISMATCH";
    case ActorExecDisposition::dossier_launch_envelope_mismatch: return "DOSSIER_LAUNCH_ENVELOPE_MISMATCH";
    case ActorExecDisposition::dossier_privilege_floor_mismatch: return "DOSSIER_PRIVILEGE_FLOOR_MISMATCH";
    case ActorExecDisposition::dossier_descriptor_inventory_mismatch: return "DOSSIER_DESCRIPTOR_INVENTORY_MISMATCH";
    case ActorExecDisposition::actor_exec_and_dossier_bound: return "ACTOR_EXEC_AND_DOSSIER_BOUND";
    }
    return "UNKNOWN";
}

}  // namespace slopos::e0::handoff_cell
