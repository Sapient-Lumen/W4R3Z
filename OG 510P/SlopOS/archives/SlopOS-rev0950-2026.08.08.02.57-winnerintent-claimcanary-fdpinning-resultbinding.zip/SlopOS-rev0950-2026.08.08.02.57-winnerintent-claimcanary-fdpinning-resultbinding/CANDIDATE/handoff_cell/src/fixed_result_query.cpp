#include "slopos/e0/handoff_cell/fixed_result_query.hpp"

#include "slopos/e0/handoff_cell/cell.hpp"
#include "slopos/e0/handoff_cell/principal_cell.hpp"

#include <array>
#include <cerrno>
#include <cstddef>
#include <utility>

#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

namespace slopos::e0::handoff_cell {
namespace {

using generation_journal::EncodedRecord;
using generation_journal::Record;
using generation_journal::RecordKind;
using generation_journal::Result;

struct ReadResult final {
    FixedQueryDisposition disposition{FixedQueryDisposition::io_error};
    int error_number{0};
    std::uint64_t link_count{0U};
    EncodedRecord encoded{};
    Record decoded{};
};

[[nodiscard]] bool read_complete(const int fd, EncodedRecord& encoded,
                                 int& error_number) noexcept {
    std::size_t offset = 0U;
    while (offset < encoded.size()) {
        const ssize_t count = ::read(fd, encoded.data() + offset,
                                     encoded.size() - offset);
        if (count < 0) {
            if (errno == EINTR) continue;
            error_number = errno;
            return false;
        }
        if (count == 0) {
            error_number = EIO;
            return false;
        }
        offset += static_cast<std::size_t>(count);
    }
    return true;
}

[[nodiscard]] ReadResult read_fixed_record(
    const int cell_fd, const char* leaf, const uid_t provider_uid,
    const FixedQueryDisposition missing) noexcept {
    ReadResult result;
    const int fd = ::openat(cell_fd, leaf,
                            O_RDONLY | O_CLOEXEC | O_NOFOLLOW | O_NONBLOCK);
    if (fd < 0) {
        result.error_number = errno;
        result.disposition = errno == ENOENT
            ? missing : FixedQueryDisposition::io_error;
        return result;
    }

    struct stat status {};
    if (::fstat(fd, &status) != 0) {
        result.error_number = errno;
        (void)::close(fd);
        return result;
    }
    result.link_count = static_cast<std::uint64_t>(status.st_nlink);
    if (!S_ISREG(status.st_mode)) {
        result.disposition = FixedQueryDisposition::not_regular;
        (void)::close(fd);
        return result;
    }
    if (status.st_size != static_cast<off_t>(result.encoded.size())) {
        result.disposition = FixedQueryDisposition::wrong_size;
        (void)::close(fd);
        return result;
    }
    if (status.st_nlink != 1) {
        result.disposition = FixedQueryDisposition::alias_detected;
        (void)::close(fd);
        return result;
    }
    if (status.st_uid != provider_uid
        || (status.st_mode & static_cast<mode_t>(0222)) != 0U) {
        result.disposition = FixedQueryDisposition::mutable_or_wrong_owner;
        (void)::close(fd);
        return result;
    }

    int read_error = 0;
    if (!read_complete(fd, result.encoded, read_error)) {
        result.error_number = read_error;
        (void)::close(fd);
        return result;
    }
    std::array<std::uint8_t, 1U> surplus{};
    ssize_t surplus_count = -1;
    do {
        surplus_count = ::read(fd, surplus.data(), surplus.size());
    } while (surplus_count < 0 && errno == EINTR);
    if (surplus_count < 0) {
        result.error_number = errno;
        (void)::close(fd);
        return result;
    }
    if (::close(fd) != 0) {
        result.error_number = errno;
        return result;
    }
    if (surplus_count != 0) {
        result.disposition = FixedQueryDisposition::wrong_size;
        return result;
    }
    if (!generation_journal::decode_record(result.encoded, result.decoded)) {
        result.disposition = FixedQueryDisposition::decode_rejected;
        return result;
    }
    result.disposition = FixedQueryDisposition::exact_result_v2;
    return result;
}

[[nodiscard]] bool same_operation(const Record& left,
                                  const Record& right) noexcept {
    return left.generation_from == right.generation_from
        && left.generation_to == right.generation_to
        && left.operation_binding == right.operation_binding
        && left.spent_receipt_binding == right.spent_receipt_binding
        && left.consumed_dispatch == right.consumed_dispatch;
}

}  // namespace

FixedResultQuery::FixedResultQuery(FixedResultQuery&& other) noexcept
    : cell_fd_(std::exchange(other.cell_fd_, -1)),
      provider_uid_(std::exchange(other.provider_uid_, 0U)) {}

FixedResultQuery& FixedResultQuery::operator=(FixedResultQuery&& other) noexcept {
    if (this != &other) {
        if (cell_fd_ >= 0) (void)::close(cell_fd_);
        cell_fd_ = std::exchange(other.cell_fd_, -1);
        provider_uid_ = std::exchange(other.provider_uid_, 0U);
    }
    return *this;
}

FixedResultQuery::~FixedResultQuery() {
    if (cell_fd_ >= 0) (void)::close(cell_fd_);
}

std::optional<FixedResultQuery> FixedResultQuery::open_fixed_beneath(
    const int provider_root_fd, const uid_t expected_provider_uid,
    int& error_number) noexcept {
    error_number = 0;
    if (expected_provider_uid == 0U || ::geteuid() != expected_provider_uid) {
        error_number = EPERM;
        return std::nullopt;
    }
    struct stat root_status {};
    if (::fstat(provider_root_fd, &root_status) != 0) {
        error_number = errno;
        return std::nullopt;
    }
    if (!S_ISDIR(root_status.st_mode)
        || root_status.st_uid != expected_provider_uid
        || (root_status.st_mode & static_cast<mode_t>(0777)) != 0700U) {
        error_number = EPERM;
        return std::nullopt;
    }
    const int cell_fd = ::openat(provider_root_fd, kProviderCellLeaf,
                                 O_RDONLY | O_DIRECTORY | O_CLOEXEC
                                     | O_NOFOLLOW);
    if (cell_fd < 0) {
        error_number = errno;
        return std::nullopt;
    }
    struct stat cell_status {};
    if (::fstat(cell_fd, &cell_status) != 0
        || !S_ISDIR(cell_status.st_mode)
        || cell_status.st_uid != expected_provider_uid
        || (cell_status.st_mode & static_cast<mode_t>(0777)) != 0700U) {
        error_number = errno == 0 ? EPERM : errno;
        (void)::close(cell_fd);
        return std::nullopt;
    }
    return FixedResultQuery(cell_fd, expected_provider_uid);
}

FixedQueryResult FixedResultQuery::read_exact_result_v2() const noexcept {
    FixedQueryResult output;
    if (cell_fd_ < 0 || provider_uid_ == 0U
        || ::geteuid() != provider_uid_) {
        output.error_number = EPERM;
        return output;
    }
    const ReadResult pending = read_fixed_record(
        cell_fd_, kPendingLeaf, provider_uid_,
        FixedQueryDisposition::missing_pending);
    output.pending_link_count = pending.link_count;
    if (pending.disposition != FixedQueryDisposition::exact_result_v2) {
        output.disposition = pending.disposition;
        output.error_number = pending.error_number;
        return output;
    }
    if (pending.decoded.kind != RecordKind::pending
        || pending.decoded.sequence != 1U
        || pending.decoded.result != Result::none) {
        output.disposition = FixedQueryDisposition::wrong_record_kind;
        return output;
    }

    const ReadResult result = read_fixed_record(
        cell_fd_, kResultV2Leaf, provider_uid_,
        FixedQueryDisposition::missing_result_v2);
    output.result_link_count = result.link_count;
    output.encoded = result.encoded;
    if (result.disposition != FixedQueryDisposition::exact_result_v2) {
        output.disposition = result.disposition;
        output.error_number = result.error_number;
        return output;
    }
    if (result.decoded.kind != RecordKind::result
        || result.decoded.sequence != 2U
        || result.decoded.result == Result::none
        || result.decoded.result == Result::uncertain) {
        output.disposition = FixedQueryDisposition::wrong_record_kind;
        return output;
    }
    if (!same_operation(pending.decoded, result.decoded)) {
        output.disposition = FixedQueryDisposition::operation_mismatch;
        return output;
    }
    output.disposition = FixedQueryDisposition::exact_result_v2;
    return output;
}

const char* fixed_query_name(const FixedQueryDisposition value) noexcept {
    switch (value) {
        case FixedQueryDisposition::exact_result_v2: return "EXACT_RESULT_V2";
        case FixedQueryDisposition::missing_pending: return "MISSING_PENDING";
        case FixedQueryDisposition::missing_result_v2: return "MISSING_RESULT_V2";
        case FixedQueryDisposition::not_regular: return "NOT_REGULAR";
        case FixedQueryDisposition::wrong_size: return "WRONG_SIZE";
        case FixedQueryDisposition::alias_detected: return "ALIAS_DETECTED";
        case FixedQueryDisposition::mutable_or_wrong_owner:
            return "MUTABLE_OR_WRONG_OWNER";
        case FixedQueryDisposition::decode_rejected: return "DECODE_REJECTED";
        case FixedQueryDisposition::wrong_record_kind: return "WRONG_RECORD_KIND";
        case FixedQueryDisposition::operation_mismatch: return "OPERATION_MISMATCH";
        case FixedQueryDisposition::io_error: return "IO_ERROR";
    }
    return "IO_ERROR";
}

}  // namespace slopos::e0::handoff_cell
