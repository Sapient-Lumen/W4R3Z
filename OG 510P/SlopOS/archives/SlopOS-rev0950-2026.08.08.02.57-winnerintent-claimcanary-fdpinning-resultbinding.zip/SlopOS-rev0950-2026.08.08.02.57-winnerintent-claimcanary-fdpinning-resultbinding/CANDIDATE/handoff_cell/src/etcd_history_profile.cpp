#include "slopos/e0/handoff_cell/etcd_history_profile.hpp"

#include <algorithm>
#include <array>
#include <iomanip>
#include <limits>
#include <sstream>
#include <utility>

namespace slopos::e0::handoff_cell {
namespace {

[[nodiscard]] bool exact_digest(const ProviderDigest& left,
                                const ProviderDigest& right) noexcept {
    return left == right;
}

[[nodiscard]] bool nonzero_digest(const ProviderDigest& value) noexcept {
    return !provider_digest_is_zero(value);
}

[[nodiscard]] bool member_admitted(
    const std::array<std::uint64_t, 3U>& members,
    const std::uint64_t member) noexcept {
    return member != 0U
        && std::find(members.begin(), members.end(), member) != members.end();
}

[[nodiscard]] std::string hex_digest(const ProviderDigest& value) {
    std::ostringstream stream;
    stream << std::hex << std::setfill('0');
    for (const auto byte : value) {
        stream << std::setw(2) << static_cast<unsigned int>(byte);
    }
    return stream.str();
}

[[nodiscard]] bool current_state(
    const EtcdHistoryExpectedV1& expected,
    const EtcdHistoryDossierV1& dossier) noexcept {
    return dossier.floor_present
        && dossier.head_present
        && dossier.spend_present
        && dossier.entry_present
        && exact_digest(dossier.floor_identity, expected.floor_identity)
        && exact_digest(dossier.head, expected.successor_head)
        && exact_digest(dossier.spend_record, expected.spend_record)
        && exact_digest(dossier.pending_entry, expected.pending_entry);
}

[[nodiscard]] bool unused_state(
    const EtcdHistoryExpectedV1& expected,
    const EtcdHistoryDossierV1& dossier) noexcept {
    return dossier.floor_present
        && dossier.head_present
        && !dossier.spend_present
        && !dossier.entry_present
        && exact_digest(dossier.floor_identity, expected.floor_identity)
        && exact_digest(dossier.head, expected.predecessor_head);
}

[[nodiscard]] EtcdHistoryAssessment base_assessment() noexcept {
    EtcdHistoryAssessment result;
    result.query_only = true;
    result.response_authority = false;
    result.retry_authority = false;
    result.provider_commit_proved = false;
    result.restore_continuity_proved = false;
    result.external_currentness_proved = false;
    return result;
}

}  // namespace

bool etcd_profile_pin_invariant(const EtcdProfilePinV1& pin) noexcept {
    const bool members_nonzero = std::all_of(
        pin.member_ids.begin(), pin.member_ids.end(),
        [](const std::uint64_t value) { return value != 0U; });
    const bool members_distinct = pin.member_ids[0] != pin.member_ids[1]
        && pin.member_ids[0] != pin.member_ids[2]
        && pin.member_ids[1] != pin.member_ids[2];
    return pin.version == kEtcdProfileVersion
        && exact_digest(pin.release_archive_sha256,
                        kEtcdV3614LinuxAmd64ArchiveSha256)
        && pin.cluster_id != 0U
        && members_nonzero
        && members_distinct
        && nonzero_digest(pin.client_ca)
        && nonzero_digest(pin.peer_ca)
        && nonzero_digest(pin.application_principal)
        && nonzero_digest(pin.administration_inventory)
        && pin.auth_revision != 0U;
}

bool etcd_history_expected_invariant(
    const EtcdHistoryExpectedV1& expected) noexcept {
    return expected.generation_from != 0U
        && expected.generation_from < std::numeric_limits<std::uint64_t>::max()
        && expected.generation_to == expected.generation_from + 1U
        && nonzero_digest(expected.operation_binding)
        && nonzero_digest(expected.floor_identity)
        && nonzero_digest(expected.predecessor_head)
        && nonzero_digest(expected.successor_head)
        && expected.predecessor_head != expected.successor_head
        && nonzero_digest(expected.spend_record)
        && nonzero_digest(expected.pending_entry);
}

std::optional<EtcdHistoryTxnPlanV1> make_etcd_history_txn_plan(
    const EtcdHistoryExpectedV1& expected) {
    if (!etcd_history_expected_invariant(expected)) return std::nullopt;

    EtcdHistoryTxnPlanV1 plan;
    const std::string operation = hex_digest(expected.operation_binding);
    const std::string prefix(kEtcdHistoryPrefix);
    plan.head_key = prefix + "head";
    plan.floor_key = prefix + "floor";
    plan.spend_key = prefix + "spend/" + operation;
    plan.entry_key = prefix + "entry/" + operation;
    plan.serializable_read = false;
    plan.comparisons = 4U;
    plan.success_writes = 3U;
    plan.failure_queries = 4U;

    std::ostringstream txn;
    txn << "value(\"" << plan.head_key << "\") = \""
        << hex_digest(expected.predecessor_head) << "\"\n";
    txn << "value(\"" << plan.floor_key << "\") = \""
        << hex_digest(expected.floor_identity) << "\"\n";
    txn << "version(\"" << plan.spend_key << "\") = \"0\"\n";
    txn << "version(\"" << plan.entry_key << "\") = \"0\"\n\n";
    txn << "put " << plan.head_key << ' '
        << hex_digest(expected.successor_head) << "\n";
    txn << "put " << plan.spend_key << ' '
        << hex_digest(expected.spend_record) << "\n";
    txn << "put " << plan.entry_key << ' '
        << hex_digest(expected.pending_entry) << "\n\n";
    txn << "get " << plan.head_key << "\n";
    txn << "get " << plan.floor_key << "\n";
    txn << "get " << plan.spend_key << "\n";
    txn << "get " << plan.entry_key << "\n";
    plan.interactive_txn = txn.str();

    std::ostringstream query;
    query << "get " << plan.head_key << "\n";
    query << "get " << plan.floor_key << "\n";
    query << "get " << plan.spend_key << "\n";
    query << "get " << plan.entry_key << "\n";
    plan.linearizable_query_script = query.str();
    return plan;
}

EtcdHistoryAssessment assess_etcd_history_dossier(
    const EtcdProfilePinV1& pin,
    const EtcdHistoryExpectedV1& expected,
    const EtcdHistoryDossierV1& dossier) noexcept {
    EtcdHistoryAssessment result = base_assessment();
    if (!etcd_profile_pin_invariant(pin)
        || !etcd_history_expected_invariant(expected)) {
        result.disposition = EtcdHistoryDisposition::profile_malformed;
        return result;
    }
    if (!dossier.runtime_observed) {
        result.disposition = EtcdHistoryDisposition::runtime_unavailable;
        return result;
    }
    result.exact_release = dossier.version == pin.version
        && exact_digest(dossier.release_archive_sha256,
                        pin.release_archive_sha256);
    if (!result.exact_release) {
        result.disposition = EtcdHistoryDisposition::release_mismatch;
        return result;
    }
    if (dossier.cluster_id != pin.cluster_id) {
        result.disposition = EtcdHistoryDisposition::foreign_cluster;
        return result;
    }
    result.admitted_cluster_coordinate = true;
    if (!member_admitted(pin.member_ids, dossier.member_id)) {
        result.disposition = EtcdHistoryDisposition::foreign_member;
        return result;
    }
    if (dossier.auth_revision != pin.auth_revision) {
        result.disposition = EtcdHistoryDisposition::auth_revision_mismatch;
        return result;
    }
    result.exact_profile = true;
    if (!dossier.query_delivered) {
        result.disposition = EtcdHistoryDisposition::query_unavailable;
        return result;
    }
    if (!dossier.linearizable_query) {
        result.disposition =
            EtcdHistoryDisposition::serializable_query_rejected;
        return result;
    }
    result.linearizable = true;
    if (dossier.query_revision == 0U || dossier.raft_term == 0U
        || (dossier.txn_reply != EtcdTxnReplyKind::no_reply
            && (dossier.txn_revision == 0U
                || dossier.query_revision < dossier.txn_revision))) {
        result.disposition = EtcdHistoryDisposition::revision_regression;
        return result;
    }

    const bool current = current_state(expected, dossier);
    const bool unused = unused_state(expected, dossier);
    result.exact_expected_state = current || unused;

    if (dossier.txn_reply == EtcdTxnReplyKind::compare_succeeded) {
        result.disposition = current
            ? EtcdHistoryDisposition::exact_current_observation
            : EtcdHistoryDisposition::conflicting_observation;
        return result;
    }
    if (dossier.txn_reply == EtcdTxnReplyKind::compare_failed) {
        result.disposition = current
            ? EtcdHistoryDisposition::compare_failed_current_observation
            : unused
                ? EtcdHistoryDisposition::compare_failed_unused_observation
                : EtcdHistoryDisposition::conflicting_observation;
        return result;
    }
    result.disposition = current
        ? EtcdHistoryDisposition::exact_current_after_ambiguous_reply
        : unused
            ? EtcdHistoryDisposition::exact_unused_after_ambiguous_reply
            : EtcdHistoryDisposition::conflicting_observation;
    return result;
}

const char* etcd_history_disposition_name(
    const EtcdHistoryDisposition value) noexcept {
    switch (value) {
        case EtcdHistoryDisposition::runtime_unavailable:
            return "RUNTIME_UNAVAILABLE";
        case EtcdHistoryDisposition::release_mismatch:
            return "RELEASE_MISMATCH";
        case EtcdHistoryDisposition::profile_malformed:
            return "PROFILE_MALFORMED";
        case EtcdHistoryDisposition::foreign_cluster:
            return "FOREIGN_CLUSTER";
        case EtcdHistoryDisposition::foreign_member:
            return "FOREIGN_MEMBER";
        case EtcdHistoryDisposition::auth_revision_mismatch:
            return "AUTH_REVISION_MISMATCH";
        case EtcdHistoryDisposition::query_unavailable:
            return "QUERY_UNAVAILABLE";
        case EtcdHistoryDisposition::serializable_query_rejected:
            return "SERIALIZABLE_QUERY_REJECTED";
        case EtcdHistoryDisposition::revision_regression:
            return "REVISION_REGRESSION";
        case EtcdHistoryDisposition::exact_current_observation:
            return "EXACT_CURRENT_OBSERVATION";
        case EtcdHistoryDisposition::exact_current_after_ambiguous_reply:
            return "EXACT_CURRENT_AFTER_AMBIGUOUS_REPLY";
        case EtcdHistoryDisposition::exact_unused_after_ambiguous_reply:
            return "EXACT_UNUSED_AFTER_AMBIGUOUS_REPLY";
        case EtcdHistoryDisposition::compare_failed_current_observation:
            return "COMPARE_FAILED_CURRENT_OBSERVATION";
        case EtcdHistoryDisposition::compare_failed_unused_observation:
            return "COMPARE_FAILED_UNUSED_OBSERVATION";
        case EtcdHistoryDisposition::conflicting_observation:
            return "CONFLICTING_OBSERVATION";
    }
    return "UNKNOWN";
}

}  // namespace slopos::e0::handoff_cell
