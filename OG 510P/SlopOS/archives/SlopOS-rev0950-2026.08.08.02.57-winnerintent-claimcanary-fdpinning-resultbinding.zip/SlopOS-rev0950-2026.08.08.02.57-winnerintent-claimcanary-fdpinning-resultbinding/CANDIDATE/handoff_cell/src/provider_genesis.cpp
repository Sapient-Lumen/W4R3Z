#include "slopos/e0/handoff_cell/provider_genesis.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <limits>
#include <span>
#include <string_view>

#include <openssl/crypto.h>
#include <openssl/evp.h>

namespace slopos::e0::handoff_cell {
namespace {

inline constexpr std::array<std::uint8_t, 8U> kGenesisMagic{
    'S', 'L', 'O', 'P', 'G', 'E', 'N', '1'};
inline constexpr std::array<std::uint8_t, 8U> kAppendMagic{
    'S', 'L', 'O', 'P', 'O', 'B', 'S', '1'};
inline constexpr std::uint16_t kVersion = 1U;
inline constexpr std::uint16_t kGenesisKind = 1U;
inline constexpr std::uint16_t kAppendKind = 2U;
inline constexpr std::string_view kGenesisDomain{
    "SlopOS/owner-provider-genesis/v1"};
inline constexpr std::string_view kAppendDomain{
    "SlopOS/provider-append-obsv/v1"};

static_assert(kGenesisDomain.size() == kProviderSigningDomainBytes);
static_assert(kAppendDomain.size() <= kProviderSigningDomainBytes);

void put_u16(std::span<std::uint8_t> output, const std::size_t offset,
             const std::uint16_t value) noexcept {
    output[offset] = static_cast<std::uint8_t>((value >> 8U) & 0xffU);
    output[offset + 1U] = static_cast<std::uint8_t>(value & 0xffU);
}

void put_u32(std::span<std::uint8_t> output, const std::size_t offset,
             const std::uint32_t value) noexcept {
    for (std::size_t index = 0U; index < 4U; ++index) {
        const auto shift = static_cast<unsigned int>((3U - index) * 8U);
        output[offset + index] =
            static_cast<std::uint8_t>((value >> shift) & 0xffU);
    }
}

void put_u64(std::span<std::uint8_t> output, const std::size_t offset,
             const std::uint64_t value) noexcept {
    for (std::size_t index = 0U; index < 8U; ++index) {
        const auto shift = static_cast<unsigned int>((7U - index) * 8U);
        output[offset + index] =
            static_cast<std::uint8_t>((value >> shift) & 0xffU);
    }
}

[[nodiscard]] std::uint16_t get_u16(
    std::span<const std::uint8_t> input,
    const std::size_t offset) noexcept {
    return static_cast<std::uint16_t>(
        (static_cast<std::uint16_t>(input[offset]) << 8U)
        | static_cast<std::uint16_t>(input[offset + 1U]));
}

[[nodiscard]] std::uint32_t get_u32(
    std::span<const std::uint8_t> input,
    const std::size_t offset) noexcept {
    std::uint32_t value = 0U;
    for (std::size_t index = 0U; index < 4U; ++index) {
        value = static_cast<std::uint32_t>(
            (value << 8U) | static_cast<std::uint32_t>(input[offset + index]));
    }
    return value;
}

[[nodiscard]] std::uint64_t get_u64(
    std::span<const std::uint8_t> input,
    const std::size_t offset) noexcept {
    std::uint64_t value = 0U;
    for (std::size_t index = 0U; index < 8U; ++index) {
        value = static_cast<std::uint64_t>(
            (value << 8U) | static_cast<std::uint64_t>(input[offset + index]));
    }
    return value;
}

template <std::size_t Size>
void put_array(std::span<std::uint8_t> output, const std::size_t offset,
               const std::array<std::uint8_t, Size>& value) noexcept {
    std::copy(value.begin(), value.end(), output.begin()
              + static_cast<std::ptrdiff_t>(offset));
}

template <std::size_t Size>
[[nodiscard]] std::array<std::uint8_t, Size> get_array(
    std::span<const std::uint8_t> input,
    const std::size_t offset) noexcept {
    std::array<std::uint8_t, Size> value{};
    std::copy_n(input.begin() + static_cast<std::ptrdiff_t>(offset), Size,
                value.begin());
    return value;
}

[[nodiscard]] bool exact_bytes(const ProviderDigest& left,
                               const ProviderDigest& right) noexcept {
    return CRYPTO_memcmp(left.data(), right.data(), left.size()) == 0;
}

void encode_genesis_unsigned(const OwnerProviderGenesisV1& value,
                             std::span<std::uint8_t> output) noexcept {
    std::fill(output.begin(), output.end(), 0U);
    std::copy(kGenesisMagic.begin(), kGenesisMagic.end(), output.begin());
    put_u16(output, 8U, kVersion);
    put_u16(output, 10U, kGenesisKind);
    put_u32(output, 12U,
            static_cast<std::uint32_t>(kOwnerProviderGenesisBytes));
    put_u64(output, 16U, value.owner_epoch);
    put_u64(output, 24U, value.provider_epoch);
    put_array(output, 32U, value.owner_constitution);
    put_array(output, 64U, value.provider_public_key);
    put_array(output, 96U, value.provider_subject);
    put_array(output, 128U, value.provider_image);
    put_array(output, 160U, value.floor_identity);
    put_array(output, 192U, value.endpoint_epoch);
    put_array(output, 224U, value.appraiser_public_key);
}

void encode_append_unsigned(const ProviderAppendObservationV1& value,
                            std::span<std::uint8_t> output) noexcept {
    std::fill(output.begin(), output.end(), 0U);
    std::copy(kAppendMagic.begin(), kAppendMagic.end(), output.begin());
    put_u16(output, 8U, kVersion);
    put_u16(output, 10U, kAppendKind);
    put_u32(output, 12U,
            static_cast<std::uint32_t>(kProviderAppendObservationBytes));
    put_u64(output, 16U, value.owner_epoch);
    put_u64(output, 24U, value.provider_epoch);
    put_u64(output, 32U, value.observation_serial);
    put_u64(output, 40U, value.generation_from);
    put_u64(output, 48U, value.generation_to);
    put_array(output, 56U, value.genesis_digest);
    put_array(output, 88U, value.floor_identity);
    put_array(output, 120U, value.predecessor_head);
    put_array(output, 152U, value.successor_head);
    put_array(output, 184U, value.spend_record);
    put_array(output, 216U, value.pending_entry);
    // bytes 248..256 remain canonical zero reservation.
}

enum class SignatureCheck : std::uint8_t { valid, invalid, error };

[[nodiscard]] SignatureCheck verify_ed25519(
    const Ed25519PublicKey& public_key,
    const Ed25519Signature& signature,
    std::span<const std::uint8_t> message) noexcept {
    EVP_PKEY* key = EVP_PKEY_new_raw_public_key_ex(
        nullptr, "ED25519", nullptr, public_key.data(), public_key.size());
    if (key == nullptr) return SignatureCheck::error;
    EVP_MD_CTX* context = EVP_MD_CTX_new();
    if (context == nullptr) {
        EVP_PKEY_free(key);
        return SignatureCheck::error;
    }
    const int initialized = EVP_DigestVerifyInit_ex(
        context, nullptr, nullptr, nullptr, nullptr, key, nullptr);
    if (initialized != 1) {
        EVP_MD_CTX_free(context);
        EVP_PKEY_free(key);
        return SignatureCheck::error;
    }
    const int verified = EVP_DigestVerify(
        context, signature.data(), signature.size(),
        message.data(), message.size());
    EVP_MD_CTX_free(context);
    EVP_PKEY_free(key);
    if (verified == 1) return SignatureCheck::valid;
    if (verified == 0) return SignatureCheck::invalid;
    return SignatureCheck::error;
}

[[nodiscard]] bool expected_matches(
    const ProviderAppendObservationV1& observed,
    const ExpectedProviderAppend& expected) noexcept {
    return observed.owner_epoch == expected.owner_epoch
        && observed.provider_epoch == expected.provider_epoch
        && observed.observation_serial == expected.observation_serial
        && observed.generation_from == expected.generation_from
        && observed.generation_to == expected.generation_to
        && observed.floor_identity == expected.floor_identity
        && observed.predecessor_head == expected.predecessor_head
        && observed.successor_head == expected.successor_head
        && observed.spend_record == expected.spend_record
        && observed.pending_entry == expected.pending_entry;
}

}  // namespace

bool provider_digest_is_zero(const ProviderDigest& value) noexcept {
    return std::all_of(value.begin(), value.end(),
                       [](const std::uint8_t byte) { return byte == 0U; });
}

bool owner_provider_genesis_invariant(
    const OwnerProviderGenesisV1& value) noexcept {
    return value.owner_epoch != 0U
        && value.provider_epoch != 0U
        && !provider_digest_is_zero(value.owner_constitution)
        && !provider_digest_is_zero(value.provider_public_key)
        && !provider_digest_is_zero(value.provider_subject)
        && !provider_digest_is_zero(value.provider_image)
        && !provider_digest_is_zero(value.floor_identity)
        && !provider_digest_is_zero(value.endpoint_epoch)
        && !provider_digest_is_zero(value.appraiser_public_key);
}

bool provider_append_observation_invariant(
    const ProviderAppendObservationV1& value) noexcept {
    return value.owner_epoch != 0U
        && value.provider_epoch != 0U
        && value.observation_serial != 0U
        && value.generation_from != 0U
        && value.generation_from < std::numeric_limits<std::uint64_t>::max()
        && value.generation_to == value.generation_from + 1U
        && !provider_digest_is_zero(value.genesis_digest)
        && !provider_digest_is_zero(value.floor_identity)
        && !provider_digest_is_zero(value.predecessor_head)
        && !provider_digest_is_zero(value.successor_head)
        && !provider_digest_is_zero(value.spend_record)
        && !provider_digest_is_zero(value.pending_entry);
}

bool encode_owner_provider_genesis(
    const OwnerProviderGenesisV1& value,
    const Ed25519Signature& signature,
    EncodedOwnerProviderGenesis& output) noexcept {
    if (!owner_provider_genesis_invariant(value)) return false;
    encode_genesis_unsigned(
        value, std::span<std::uint8_t>(output).first(
                   kOwnerProviderGenesisUnsignedBytes));
    put_array(std::span<std::uint8_t>(output),
              kOwnerProviderGenesisUnsignedBytes, signature);
    return true;
}

bool decode_owner_provider_genesis(
    const EncodedOwnerProviderGenesis& input,
    OwnerProviderGenesisV1& value,
    Ed25519Signature& signature) noexcept {
    const std::span<const std::uint8_t> bytes(input);
    if (!std::equal(kGenesisMagic.begin(), kGenesisMagic.end(), bytes.begin())
        || get_u16(bytes, 8U) != kVersion
        || get_u16(bytes, 10U) != kGenesisKind
        || get_u32(bytes, 12U) != kOwnerProviderGenesisBytes) {
        return false;
    }
    OwnerProviderGenesisV1 decoded;
    decoded.owner_epoch = get_u64(bytes, 16U);
    decoded.provider_epoch = get_u64(bytes, 24U);
    decoded.owner_constitution = get_array<32U>(bytes, 32U);
    decoded.provider_public_key = get_array<32U>(bytes, 64U);
    decoded.provider_subject = get_array<32U>(bytes, 96U);
    decoded.provider_image = get_array<32U>(bytes, 128U);
    decoded.floor_identity = get_array<32U>(bytes, 160U);
    decoded.endpoint_epoch = get_array<32U>(bytes, 192U);
    decoded.appraiser_public_key = get_array<32U>(bytes, 224U);
    if (!owner_provider_genesis_invariant(decoded)) return false;
    value = decoded;
    signature = get_array<64U>(bytes, kOwnerProviderGenesisUnsignedBytes);
    return true;
}

bool encode_provider_append_observation(
    const ProviderAppendObservationV1& value,
    const Ed25519Signature& signature,
    EncodedProviderAppendObservation& output) noexcept {
    if (!provider_append_observation_invariant(value)) return false;
    encode_append_unsigned(
        value, std::span<std::uint8_t>(output).first(
                   kProviderAppendUnsignedBytes));
    put_array(std::span<std::uint8_t>(output),
              kProviderAppendUnsignedBytes, signature);
    return true;
}

bool decode_provider_append_observation(
    const EncodedProviderAppendObservation& input,
    ProviderAppendObservationV1& value,
    Ed25519Signature& signature) noexcept {
    const std::span<const std::uint8_t> bytes(input);
    if (!std::equal(kAppendMagic.begin(), kAppendMagic.end(), bytes.begin())
        || get_u16(bytes, 8U) != kVersion
        || get_u16(bytes, 10U) != kAppendKind
        || get_u32(bytes, 12U) != kProviderAppendObservationBytes
        || !std::all_of(bytes.begin() + 248, bytes.begin() + 256,
                        [](const std::uint8_t byte) { return byte == 0U; })) {
        return false;
    }
    ProviderAppendObservationV1 decoded;
    decoded.owner_epoch = get_u64(bytes, 16U);
    decoded.provider_epoch = get_u64(bytes, 24U);
    decoded.observation_serial = get_u64(bytes, 32U);
    decoded.generation_from = get_u64(bytes, 40U);
    decoded.generation_to = get_u64(bytes, 48U);
    decoded.genesis_digest = get_array<32U>(bytes, 56U);
    decoded.floor_identity = get_array<32U>(bytes, 88U);
    decoded.predecessor_head = get_array<32U>(bytes, 120U);
    decoded.successor_head = get_array<32U>(bytes, 152U);
    decoded.spend_record = get_array<32U>(bytes, 184U);
    decoded.pending_entry = get_array<32U>(bytes, 216U);
    if (!provider_append_observation_invariant(decoded)) return false;
    value = decoded;
    signature = get_array<64U>(bytes, kProviderAppendUnsignedBytes);
    return true;
}

OwnerProviderGenesisSigningMessage owner_provider_genesis_signing_message(
    const OwnerProviderGenesisV1& value) noexcept {
    OwnerProviderGenesisSigningMessage message{};
    std::copy(kGenesisDomain.begin(), kGenesisDomain.end(), message.begin());
    encode_genesis_unsigned(
        value, std::span<std::uint8_t>(message).subspan(
                   kProviderSigningDomainBytes,
                   kOwnerProviderGenesisUnsignedBytes));
    return message;
}

ProviderAppendSigningMessage provider_append_signing_message(
    const ProviderAppendObservationV1& value) noexcept {
    ProviderAppendSigningMessage message{};
    std::copy(kAppendDomain.begin(), kAppendDomain.end(), message.begin());
    encode_append_unsigned(
        value, std::span<std::uint8_t>(message).subspan(
                   kProviderSigningDomainBytes,
                   kProviderAppendUnsignedBytes));
    return message;
}

bool provider_sha256(const std::span<const std::uint8_t> bytes,
                     ProviderDigest& output) noexcept {
    std::size_t length = 0U;
    const int result = EVP_Q_digest(
        nullptr, "SHA256", nullptr, bytes.data(), bytes.size(),
        output.data(), &length);
    if (result != 1 || length != output.size()) {
        output.fill(0U);
        return false;
    }
    return true;
}

bool owner_provider_genesis_digest(
    const EncodedOwnerProviderGenesis& encoded,
    ProviderDigest& output) noexcept {
    return provider_sha256(encoded, output);
}

ProviderGenesisObservation verify_pinned_provider_append(
    const OwnerGenesisPin& pin,
    const EncodedOwnerProviderGenesis& genesis,
    const EncodedProviderAppendObservation& append,
    const ExpectedProviderAppend& expected) noexcept {
    ProviderGenesisObservation result;
    OwnerProviderGenesisV1 decoded_genesis;
    Ed25519Signature owner_signature{};
    if (!decode_owner_provider_genesis(
            genesis, decoded_genesis, owner_signature)) {
        result.disposition = ProviderGenesisDisposition::genesis_malformed;
        return result;
    }

    ProviderDigest observed_genesis_digest{};
    if (!owner_provider_genesis_digest(genesis, observed_genesis_digest)) {
        result.disposition = ProviderGenesisDisposition::cryptographic_error;
        return result;
    }
    if (!exact_bytes(observed_genesis_digest, pin.exact_genesis_digest)) {
        result.disposition = ProviderGenesisDisposition::genesis_pin_mismatch;
        return result;
    }
    result.exact_pin_match = true;

    const auto genesis_message =
        owner_provider_genesis_signing_message(decoded_genesis);
    const SignatureCheck owner_check = verify_ed25519(
        pin.owner_public_key, owner_signature, genesis_message);
    if (owner_check == SignatureCheck::error) {
        result.disposition = ProviderGenesisDisposition::cryptographic_error;
        return result;
    }
    if (owner_check != SignatureCheck::valid) {
        result.disposition = ProviderGenesisDisposition::owner_signature_invalid;
        return result;
    }
    result.owner_signature_valid = true;

    ProviderAppendObservationV1 decoded_append;
    Ed25519Signature provider_signature{};
    if (!decode_provider_append_observation(
            append, decoded_append, provider_signature)) {
        result.disposition = ProviderGenesisDisposition::append_malformed;
        return result;
    }
    if (decoded_append.genesis_digest != observed_genesis_digest
        || decoded_append.owner_epoch != decoded_genesis.owner_epoch
        || decoded_append.provider_epoch != decoded_genesis.provider_epoch
        || decoded_append.floor_identity != decoded_genesis.floor_identity) {
        result.disposition =
            ProviderGenesisDisposition::genesis_binding_mismatch;
        return result;
    }

    const auto append_message = provider_append_signing_message(decoded_append);
    const SignatureCheck provider_check = verify_ed25519(
        decoded_genesis.provider_public_key,
        provider_signature, append_message);
    if (provider_check == SignatureCheck::error) {
        result.disposition = ProviderGenesisDisposition::cryptographic_error;
        return result;
    }
    if (provider_check != SignatureCheck::valid) {
        result.disposition =
            ProviderGenesisDisposition::provider_signature_invalid;
        return result;
    }
    result.provider_signature_valid = true;

    if (!expected_matches(decoded_append, expected)) {
        result.disposition = ProviderGenesisDisposition::expected_mismatch;
        return result;
    }
    result.exact_expected_fields = true;
    result.disposition =
        ProviderGenesisDisposition::exact_signed_observation;
    return result;
}

const char* provider_genesis_disposition_name(
    const ProviderGenesisDisposition value) noexcept {
    switch (value) {
        case ProviderGenesisDisposition::exact_signed_observation:
            return "EXACT_SIGNED_OBSERVATION";
        case ProviderGenesisDisposition::genesis_malformed:
            return "GENESIS_MALFORMED";
        case ProviderGenesisDisposition::genesis_pin_mismatch:
            return "GENESIS_PIN_MISMATCH";
        case ProviderGenesisDisposition::owner_signature_invalid:
            return "OWNER_SIGNATURE_INVALID";
        case ProviderGenesisDisposition::append_malformed:
            return "APPEND_MALFORMED";
        case ProviderGenesisDisposition::genesis_binding_mismatch:
            return "GENESIS_BINDING_MISMATCH";
        case ProviderGenesisDisposition::provider_signature_invalid:
            return "PROVIDER_SIGNATURE_INVALID";
        case ProviderGenesisDisposition::expected_mismatch:
            return "EXPECTED_MISMATCH";
        case ProviderGenesisDisposition::cryptographic_error:
            return "CRYPTOGRAPHIC_ERROR";
    }
    return "CRYPTOGRAPHIC_ERROR";
}

}  // namespace slopos::e0::handoff_cell
