#include "slopos/e0/handoff_cell/acquisition_actor_admission.hpp"

#include <array>
#include <cstddef>

namespace slopos::e0::handoff_cell {
namespace {

constexpr std::size_t kFieldCount = 39U;
using Fields = std::array<bool, kFieldCount>;

[[nodiscard]] Fields fields(const AcquisitionActorObservationV1& v) noexcept {
    return {v.profile_supplied,
            v.executable_descriptor_pinned,
            v.executable_digest_exact,
            v.dependency_manifest_exact,
            v.argv_exact,
            v.environment_exact,
            v.working_directory_exact,
            v.umask_exact,
            v.uid_nonroot,
            v.gid_nonroot,
            v.supplementary_groups_empty,
            v.capabilities_empty,
            v.no_new_privs_enabled,
            v.seccomp_filter_exact,
            v.inherited_descriptor_inventory_exact,
            v.fixed_https_source,
            v.source_host_exact,
            v.proxy_inputs_absent,
            v.network_egress_fixed,
            v.timeout_bounded,
            v.retry_budget_zero,
            v.administration_inventory_complete,
            v.receiver_before_candidate_policy_exact,
            v.unlinked_sealable_output_only,
            v.complete_before_seal_required,
            v.full_seal_barrier_required,
            v.actor_pidfd_supplied,
            v.pidfd_get_info_supported,
            v.pidfd_info_pid_present,
            v.pidfd_info_creds_present,
            v.pidfd_pid_matches_peer,
            v.pidfd_tgid_matches_peer,
            v.pidfd_euid_matches_profile,
            v.pidfd_egid_matches_profile,
            v.pidfd_cgroup_matches_profile,
            v.appraiser_profile_supplied,
            v.appraiser_root_distinct,
            v.appraiser_reconstructed_dossier,
            v.appraiser_challenge_exact};
}

[[nodiscard]] bool coherent(const Fields& v) noexcept {
    bool gap = false;
    for (const bool value : v) {
        if (!value) gap = true;
        else if (gap) return false;
    }
    return true;
}

[[nodiscard]] bool prefix(const Fields& v, const std::size_t count) noexcept {
    for (std::size_t i = 0U; i < count; ++i) {
        if (!v[i]) return false;
    }
    return true;
}

[[nodiscard]] std::size_t first_false(const Fields& v) noexcept {
    for (std::size_t i = 0U; i < v.size(); ++i) {
        if (!v[i]) return i;
    }
    return v.size();
}

[[nodiscard]] AcquisitionActorDisposition disposition_for_cut(
    const std::size_t cut) noexcept {
    if (cut == 0U) return AcquisitionActorDisposition::profile_unavailable;
    if (cut == 1U) return AcquisitionActorDisposition::executable_descriptor_unpinned;
    if (cut == 2U) return AcquisitionActorDisposition::executable_digest_mismatch;
    if (cut == 3U) return AcquisitionActorDisposition::dependency_epoch_mismatch;
    if (cut < 8U) return AcquisitionActorDisposition::launch_envelope_rejected;
    if (cut < 10U) return AcquisitionActorDisposition::privilege_identity_rejected;
    if (cut == 10U) return AcquisitionActorDisposition::supplementary_groups_rejected;
    if (cut == 11U) return AcquisitionActorDisposition::ambient_capabilities_rejected;
    if (cut == 12U) return AcquisitionActorDisposition::no_new_privs_missing;
    if (cut == 13U) return AcquisitionActorDisposition::seccomp_policy_missing;
    if (cut == 14U) return AcquisitionActorDisposition::inherited_descriptor_inventory_rejected;
    if (cut < 18U) return AcquisitionActorDisposition::source_policy_rejected;
    if (cut == 18U) return AcquisitionActorDisposition::network_policy_rejected;
    if (cut == 19U) return AcquisitionActorDisposition::timeout_policy_rejected;
    if (cut == 20U) return AcquisitionActorDisposition::retry_policy_rejected;
    if (cut == 21U) return AcquisitionActorDisposition::administration_inventory_incomplete;
    if (cut == 22U) return AcquisitionActorDisposition::candidate_lifecycle_policy_rejected;
    if (cut < 26U) return AcquisitionActorDisposition::output_snapshot_policy_rejected;
    if (cut == 26U) return AcquisitionActorDisposition::pidfd_coordinate_unavailable;
    if (cut == 27U) return AcquisitionActorDisposition::pidfd_get_info_unavailable;
    if (cut < 30U) return AcquisitionActorDisposition::pidfd_info_incomplete;
    if (cut < 35U) return AcquisitionActorDisposition::pidfd_coordinate_mismatch;
    if (cut == 35U) return AcquisitionActorDisposition::appraiser_unavailable;
    if (cut == 36U) return AcquisitionActorDisposition::appraiser_not_independent;
    if (cut == 37U) return AcquisitionActorDisposition::appraisal_reconstruction_failed;
    if (cut == 38U) return AcquisitionActorDisposition::appraisal_challenge_failed;
    return AcquisitionActorDisposition::actor_profile_admissible;
}

}  // namespace

AcquisitionActorAssessment assess_acquisition_actor(
    const AcquisitionActorObservationV1& observation) noexcept {
    const Fields v = fields(observation);
    AcquisitionActorAssessment result;
    result.observation_coherent = coherent(v);
    result.executable_epoch_exact = prefix(v, 4U);
    result.launch_envelope_exact = prefix(v, 8U);
    result.privilege_boundary_exact = prefix(v, 14U);
    result.inherited_descriptor_inventory_exact = prefix(v, 15U);
    result.source_policy_exact = prefix(v, 18U);
    result.network_policy_exact = prefix(v, 19U);
    result.timeout_policy_exact = prefix(v, 20U);
    result.retry_policy_exact = prefix(v, 21U);
    result.administration_inventory_exact = prefix(v, 22U);
    result.candidate_lifecycle_policy_exact = prefix(v, 23U);
    result.output_snapshot_policy_exact = prefix(v, 26U);
    result.pidfd_coordinate_observed = prefix(v, 27U);
    result.pidfd_get_info_validated = prefix(v, 30U);
    result.process_coordinate_matches = prefix(v, 35U);
    result.appraiser_independent = prefix(v, 37U);
    result.appraisal_reconstructible = prefix(v, 39U);
    result.actor_profile_admissible = result.observation_coherent
        && result.appraisal_reconstructible;
    // V14 classifies an externally assembled dossier. It does not bind the
    // post-exec process image to the pinned executable object. V15 must compose
    // that launch-image witness before V13 admission can become true.
    result.eligible_for_v13_actor_premise = false;
    result.disposition = result.observation_coherent
        ? disposition_for_cut(first_false(v))
        : AcquisitionActorDisposition::observation_incoherent;
    // Mandatory nonclaims: classification has no acquisition side effects.
    return result;
}

const char* acquisition_actor_disposition_name(
    const AcquisitionActorDisposition value) noexcept {
    switch (value) {
    case AcquisitionActorDisposition::observation_incoherent: return "OBSERVATION_INCOHERENT";
    case AcquisitionActorDisposition::profile_unavailable: return "PROFILE_UNAVAILABLE";
    case AcquisitionActorDisposition::executable_descriptor_unpinned: return "EXECUTABLE_DESCRIPTOR_UNPINNED";
    case AcquisitionActorDisposition::executable_digest_mismatch: return "EXECUTABLE_DIGEST_MISMATCH";
    case AcquisitionActorDisposition::dependency_epoch_mismatch: return "DEPENDENCY_EPOCH_MISMATCH";
    case AcquisitionActorDisposition::launch_envelope_rejected: return "LAUNCH_ENVELOPE_REJECTED";
    case AcquisitionActorDisposition::privilege_identity_rejected: return "PRIVILEGE_IDENTITY_REJECTED";
    case AcquisitionActorDisposition::supplementary_groups_rejected: return "SUPPLEMENTARY_GROUPS_REJECTED";
    case AcquisitionActorDisposition::ambient_capabilities_rejected: return "AMBIENT_CAPABILITIES_REJECTED";
    case AcquisitionActorDisposition::no_new_privs_missing: return "NO_NEW_PRIVS_MISSING";
    case AcquisitionActorDisposition::seccomp_policy_missing: return "SECCOMP_POLICY_MISSING";
    case AcquisitionActorDisposition::inherited_descriptor_inventory_rejected: return "INHERITED_DESCRIPTOR_INVENTORY_REJECTED";
    case AcquisitionActorDisposition::source_policy_rejected: return "SOURCE_POLICY_REJECTED";
    case AcquisitionActorDisposition::network_policy_rejected: return "NETWORK_POLICY_REJECTED";
    case AcquisitionActorDisposition::timeout_policy_rejected: return "TIMEOUT_POLICY_REJECTED";
    case AcquisitionActorDisposition::retry_policy_rejected: return "RETRY_POLICY_REJECTED";
    case AcquisitionActorDisposition::administration_inventory_incomplete: return "ADMINISTRATION_INVENTORY_INCOMPLETE";
    case AcquisitionActorDisposition::candidate_lifecycle_policy_rejected: return "CANDIDATE_LIFECYCLE_POLICY_REJECTED";
    case AcquisitionActorDisposition::output_snapshot_policy_rejected: return "OUTPUT_SNAPSHOT_POLICY_REJECTED";
    case AcquisitionActorDisposition::pidfd_coordinate_unavailable: return "PIDFD_COORDINATE_UNAVAILABLE";
    case AcquisitionActorDisposition::pidfd_get_info_unavailable: return "PIDFD_GET_INFO_UNAVAILABLE";
    case AcquisitionActorDisposition::pidfd_info_incomplete: return "PIDFD_INFO_INCOMPLETE";
    case AcquisitionActorDisposition::pidfd_coordinate_mismatch: return "PIDFD_COORDINATE_MISMATCH";
    case AcquisitionActorDisposition::appraiser_unavailable: return "APPRAISER_UNAVAILABLE";
    case AcquisitionActorDisposition::appraiser_not_independent: return "APPRAISER_NOT_INDEPENDENT";
    case AcquisitionActorDisposition::appraisal_reconstruction_failed: return "APPRAISAL_RECONSTRUCTION_FAILED";
    case AcquisitionActorDisposition::appraisal_challenge_failed: return "APPRAISAL_CHALLENGE_FAILED";
    case AcquisitionActorDisposition::actor_profile_admissible: return "ACTOR_PROFILE_ADMISSIBLE";
    }
    return "UNKNOWN";
}

}  // namespace slopos::e0::handoff_cell
