# Retained legacy candidate surface

Fourteen immediate directories remain from pre-V50 aggregate development. They
are retained in place because older evidence and proof spines name their exact
paths. Repository V51 does not select them, and path adjacency does not make
them current.

The authoritative immediate-child classification is `PATH-ROLES.tsv`. Removing
or relocating legacy trees requires a separate source-bound migration with exact
receipts and inherited-verifier repair. Until then, they are archaeology and
proof custody only.
