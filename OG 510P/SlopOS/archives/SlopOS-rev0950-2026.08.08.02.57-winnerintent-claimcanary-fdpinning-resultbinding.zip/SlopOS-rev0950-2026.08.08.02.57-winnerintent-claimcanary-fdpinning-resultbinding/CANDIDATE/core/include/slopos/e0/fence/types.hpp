#pragma once

#include <array>
#include <cstdint>
#include <string>
#include <string_view>
#include <tuple>

namespace slopos::e0::fence {

enum class DurableKind : std::uint8_t {
    empty,
    c1,
    c2,
    c3_no_effect,
    c3_effect,
    c3_uncertain,
    c4_no_effect,
    c4_effect,
    c4_uncertain,
};

enum class PendingKind : std::uint8_t { absent, exact, wrong };
enum class FloorKind : std::uint8_t {
    predecessor,
    successor,
    unavailable,
    malformed,
    wrong_identity,
};

// This is appraisal knowledge, not a serialized endpoint counter.  On every
// cold reopen of C2, local state is deliberately widened to unknown because
// the retained image cannot locate the effect relative to dispatch entry.
enum class DispatchKnowledge : std::uint8_t {
    not_entered,
    unknown,
    exact_no_effect,
    exact_effect,
};

enum class Event : std::uint8_t {
    admit,
    prepare_exact,
    prepare_wrong,
    plan_c2,
    advance_selector,
    advance_floor,
    advance_confirmed,
    retire_pending,
    activate_exact,
    activate_mismatch,
    enter_dispatch_exact,
    enter_dispatch_mismatch,
    return_no_effect,
    return_effect,
    return_malformed,
    reconcile_no_effect,
    reconcile_effect,
    reconcile_malformed,
    complete_no_effect,
    complete_effect,
    complete_uncertain,
    publish_no_effect,
    publish_effect,
    publish_uncertain,
    restart,
    observe_floor_predecessor,
    observe_floor_successor,
    observe_floor_unavailable,
    observe_floor_malformed,
    observe_floor_wrong_identity,
    rollback_local_keep_floor,
    rollback_local_and_floor,
    rollback_c2_keep_floor,
};

enum class Outcome : std::uint8_t { applied, rejected };

// effect_count is a ghost/audit component used only by the finite explorer.
// It is not recoverable from the local journal and never authorizes no-effect.
struct State final {
    DurableKind durable{DurableKind::empty};
    bool selector_successor{false};
    bool confirmed_successor{false};
    PendingKind pending{PendingKind::absent};
    FloorKind floor{FloorKind::predecessor};
    bool pending_activation{false};
    bool dispatch_permit{false};
    bool recovered{false};
    bool reconcile_only{false};
    DispatchKnowledge dispatch{DispatchKnowledge::not_entered};
    bool current_effect_occurred{false};
    std::uint8_t effect_count{0U};

    [[nodiscard]] friend constexpr bool operator==(
        const State&, const State&) noexcept = default;
    [[nodiscard]] friend constexpr bool operator<(
        const State& lhs, const State& rhs) noexcept {
        return std::tie(lhs.durable, lhs.selector_successor,
                        lhs.confirmed_successor, lhs.pending, lhs.floor,
                        lhs.pending_activation, lhs.dispatch_permit,
                        lhs.recovered, lhs.reconcile_only, lhs.dispatch,
                        lhs.current_effect_occurred, lhs.effect_count)
             < std::tie(rhs.durable, rhs.selector_successor,
                        rhs.confirmed_successor, rhs.pending, rhs.floor,
                        rhs.pending_activation, rhs.dispatch_permit,
                        rhs.recovered, rhs.reconcile_only, rhs.dispatch,
                        rhs.current_effect_occurred, rhs.effect_count);
    }
};

struct StepResult final {
    Outcome outcome{Outcome::rejected};
    State state{};
    bool effect_emitted{false};
};

inline constexpr std::array<Event, 33U> kEvents{{
    Event::admit, Event::prepare_exact, Event::prepare_wrong, Event::plan_c2,
    Event::advance_selector, Event::advance_floor, Event::advance_confirmed,
    Event::retire_pending, Event::activate_exact, Event::activate_mismatch,
    Event::enter_dispatch_exact, Event::enter_dispatch_mismatch,
    Event::return_no_effect, Event::return_effect, Event::return_malformed,
    Event::reconcile_no_effect, Event::reconcile_effect,
    Event::reconcile_malformed, Event::complete_no_effect,
    Event::complete_effect, Event::complete_uncertain,
    Event::publish_no_effect, Event::publish_effect,
    Event::publish_uncertain, Event::restart,
    Event::observe_floor_predecessor, Event::observe_floor_successor,
    Event::observe_floor_unavailable, Event::observe_floor_malformed,
    Event::observe_floor_wrong_identity, Event::rollback_local_keep_floor,
    Event::rollback_local_and_floor, Event::rollback_c2_keep_floor,
}};

[[nodiscard]] std::string_view durable_name(DurableKind value) noexcept;
[[nodiscard]] std::string_view pending_name(PendingKind value) noexcept;
[[nodiscard]] std::string_view floor_name(FloorKind value) noexcept;
[[nodiscard]] std::string_view dispatch_name(DispatchKnowledge value) noexcept;
[[nodiscard]] std::string_view event_name(Event value) noexcept;
[[nodiscard]] std::string_view outcome_name(Outcome value) noexcept;
[[nodiscard]] std::string state_key(const State& state);
[[nodiscard]] bool floor_regresses(const State& before,
                                   const State& after) noexcept;

}  // namespace slopos::e0::fence
