#pragma once

#include "slopos/e0/fence/types.hpp"
#include "slopos/e0/journal/durable_cut.hpp"
#include "slopos/e0/rollback/external_floor.hpp"

namespace slopos::e0::fence {

struct Fixtures final {
    journal::Descriptor descriptor{};
    journal::Descriptor wrong_descriptor{};
    journal::Completion no_effect_completion{};
    journal::Completion effect_completion{};
    journal::Completion uncertain_completion{};
    journal::DurableCutV1Image empty{};
    journal::DurableCutV1Image c1{};
    journal::DurableCutV1Image c2{};
    journal::DurableCutV1Image c3_no_effect{};
    journal::DurableCutV1Image c3_effect{};
    journal::DurableCutV1Image c3_uncertain{};
    journal::DurableCutV1Image c4_no_effect{};
    journal::DurableCutV1Image c4_effect{};
    journal::DurableCutV1Image c4_uncertain{};
    rollback::InstalledPoint predecessor{};
    rollback::InstalledPoint successor{};
    rollback::Transition transition{};
    rollback::Digest floor_identity{};
    rollback::Digest wrong_floor_identity{};
};

[[nodiscard]] const Fixtures& fixtures();
[[nodiscard]] State initial_state() noexcept;
[[nodiscard]] bool state_invariant(const State& state) noexcept;
[[nodiscard]] journal::DurableCutV1Image durable_image(DurableKind kind);
[[nodiscard]] rollback::JointObservation joint_observation(
    const State& state) noexcept;
[[nodiscard]] rollback::Decision joint_decision(const State& state) noexcept;
[[nodiscard]] StepResult step_core(const State& state, Event event) noexcept;

}  // namespace slopos::e0::fence
