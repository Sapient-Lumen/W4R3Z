#pragma once

#include <cstddef>
#include <string>

namespace slopos::e0::fence {

struct AmbiguityReport final {
    bool ok{};
    std::size_t hidden_histories{};
    std::size_t local_observation_classes{};
    std::size_t ambiguous_local_classes{};
    std::size_t exact_extended_classes{};
    std::string witness{};
    std::string detail{};
};

[[nodiscard]] AmbiguityReport explore_observation_ambiguity(
    const std::string& table_path = {},
    const std::string& certificate_path = {});

}  // namespace slopos::e0::fence
