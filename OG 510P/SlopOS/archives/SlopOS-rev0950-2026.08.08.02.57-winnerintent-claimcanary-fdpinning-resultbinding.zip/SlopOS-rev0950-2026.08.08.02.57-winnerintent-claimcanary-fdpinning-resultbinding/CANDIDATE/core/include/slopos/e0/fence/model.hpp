#pragma once
#include "slopos/e0/fence/types.hpp"
namespace slopos::e0::fence {
[[nodiscard]] StepResult step_model(const State& state, Event event) noexcept;
}  // namespace slopos::e0::fence
