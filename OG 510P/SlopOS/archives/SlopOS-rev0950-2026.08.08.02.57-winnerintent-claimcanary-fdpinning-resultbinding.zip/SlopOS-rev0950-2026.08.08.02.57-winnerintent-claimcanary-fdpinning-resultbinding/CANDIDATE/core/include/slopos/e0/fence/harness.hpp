#pragma once

#include "slopos/e0/fence/core.hpp"
#include "slopos/e0/fence/model.hpp"

#include <cstddef>
#include <string>

namespace slopos::e0::fence {

struct ExplorationReport final {
    bool ok{};
    std::size_t states{};
    std::size_t transitions{};
    std::size_t events_per_state{};
    std::size_t maximum_depth{};
    std::size_t differential_checks{};
    std::size_t invariant_checks{};
    std::size_t applied_edges{};
    std::size_t rejected_edges{};
    std::size_t restart_edges{};
    std::size_t effect_edges{};
    std::size_t recovered_c2_states{};
    std::size_t recovered_first_effect_edges{};
    std::size_t unknown_no_effect_completion_edges{};
    std::size_t uncertainty_completion_edges{};
    std::size_t exact_no_effect_completion_edges{};
    std::size_t selector_advance_edges{};
    std::size_t selector_advance_from_recovery{};
    bool duplicate_effect_with_floor_regression{};
    bool duplicate_effect_under_floor_monotonicity{};
    std::string rollback_counterexample{};
    std::string relation_fnv1a64{};
    std::string detail{};
};

[[nodiscard]] ExplorationReport explore(
    const std::string& certificate_path = {},
    const std::string& relation_path = {});

}  // namespace slopos::e0::fence
