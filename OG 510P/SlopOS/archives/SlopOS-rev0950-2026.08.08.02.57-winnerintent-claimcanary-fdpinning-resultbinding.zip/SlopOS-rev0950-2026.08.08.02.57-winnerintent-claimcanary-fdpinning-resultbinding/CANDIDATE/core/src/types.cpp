#include "slopos/e0/fence/types.hpp"

#include <string>

namespace slopos::e0::fence {

std::string_view durable_name(const DurableKind value) noexcept {
    switch (value) {
        case DurableKind::empty: return "empty";
        case DurableKind::c1: return "c1";
        case DurableKind::c2: return "c2";
        case DurableKind::c3_no_effect: return "c3-no-effect";
        case DurableKind::c3_effect: return "c3-effect";
        case DurableKind::c3_uncertain: return "c3-uncertain";
        case DurableKind::c4_no_effect: return "c4-no-effect";
        case DurableKind::c4_effect: return "c4-effect";
        case DurableKind::c4_uncertain: return "c4-uncertain";
    }
    return "unknown";
}
std::string_view pending_name(const PendingKind value) noexcept {
    switch (value) {
        case PendingKind::absent: return "absent";
        case PendingKind::exact: return "exact";
        case PendingKind::wrong: return "wrong";
    }
    return "unknown";
}
std::string_view floor_name(const FloorKind value) noexcept {
    switch (value) {
        case FloorKind::predecessor: return "predecessor";
        case FloorKind::successor: return "successor";
        case FloorKind::unavailable: return "unavailable";
        case FloorKind::malformed: return "malformed";
        case FloorKind::wrong_identity: return "wrong-identity";
    }
    return "unknown";
}
std::string_view dispatch_name(const DispatchKnowledge value) noexcept {
    switch (value) {
        case DispatchKnowledge::not_entered: return "not-entered";
        case DispatchKnowledge::unknown: return "unknown";
        case DispatchKnowledge::exact_no_effect: return "exact-no-effect";
        case DispatchKnowledge::exact_effect: return "exact-effect";
    }
    return "unknown-enum";
}
std::string_view event_name(const Event value) noexcept {
    switch (value) {
        case Event::admit: return "admit";
        case Event::prepare_exact: return "prepare-exact";
        case Event::prepare_wrong: return "prepare-wrong";
        case Event::plan_c2: return "plan-c2";
        case Event::advance_selector: return "advance-selector";
        case Event::advance_floor: return "advance-floor";
        case Event::advance_confirmed: return "advance-confirmed";
        case Event::retire_pending: return "retire-pending";
        case Event::activate_exact: return "activate-exact";
        case Event::activate_mismatch: return "activate-mismatch";
        case Event::enter_dispatch_exact: return "enter-dispatch-exact";
        case Event::enter_dispatch_mismatch: return "enter-dispatch-mismatch";
        case Event::return_no_effect: return "return-no-effect";
        case Event::return_effect: return "return-effect";
        case Event::return_malformed: return "return-malformed";
        case Event::reconcile_no_effect: return "reconcile-no-effect";
        case Event::reconcile_effect: return "reconcile-effect";
        case Event::reconcile_malformed: return "reconcile-malformed";
        case Event::complete_no_effect: return "complete-no-effect";
        case Event::complete_effect: return "complete-effect";
        case Event::complete_uncertain: return "complete-uncertain";
        case Event::publish_no_effect: return "publish-no-effect";
        case Event::publish_effect: return "publish-effect";
        case Event::publish_uncertain: return "publish-uncertain";
        case Event::restart: return "restart";
        case Event::observe_floor_predecessor: return "observe-floor-predecessor";
        case Event::observe_floor_successor: return "observe-floor-successor";
        case Event::observe_floor_unavailable: return "observe-floor-unavailable";
        case Event::observe_floor_malformed: return "observe-floor-malformed";
        case Event::observe_floor_wrong_identity: return "observe-floor-wrong-identity";
        case Event::rollback_local_keep_floor: return "rollback-local-keep-floor";
        case Event::rollback_local_and_floor: return "rollback-local-and-floor";
        case Event::rollback_c2_keep_floor: return "rollback-c2-keep-floor";
    }
    return "unknown";
}
std::string_view outcome_name(const Outcome value) noexcept {
    return value == Outcome::applied ? "applied" : "rejected";
}
std::string state_key(const State& s) {
    std::string r;
    r.reserve(192U);
    r += durable_name(s.durable); r += '|';
    r += s.selector_successor ? "S" : "P"; r += '|';
    r += s.confirmed_successor ? "S" : "P"; r += '|';
    r += pending_name(s.pending); r += '|';
    r += floor_name(s.floor); r += '|';
    r += s.pending_activation ? "pa1" : "pa0"; r += '|';
    r += s.dispatch_permit ? "dp1" : "dp0"; r += '|';
    r += s.recovered ? "r1" : "r0"; r += '|';
    r += s.reconcile_only ? "x1" : "x0"; r += '|';
    r += dispatch_name(s.dispatch); r += '|';
    r += s.current_effect_occurred ? "ce1" : "ce0"; r += '|';
    r += std::to_string(static_cast<unsigned int>(s.effect_count));
    return r;
}
bool floor_regresses(const State& before, const State& after) noexcept {
    return before.floor == FloorKind::successor
        && after.floor == FloorKind::predecessor;
}

}  // namespace slopos::e0::fence
