#include "slopos/e0/fence/core.hpp"

#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <optional>

namespace slopos::e0::fence {
namespace {

using journal::ActivationStatus;
using journal::PlanStatus;
using rollback::FloorAdvanceResult;
using rollback::FloorAdvanceStatus;
using rollback::FloorObservation;
using rollback::FloorReadStatus;
using rollback::JointObservation;
using rollback::Transition;

[[nodiscard]] journal::Digest seeded_journal_digest(
    const std::uint8_t seed) noexcept {
    journal::Digest result{};
    for (std::size_t i = 0; i < result.size(); ++i) {
        result[i] = static_cast<std::uint8_t>(
            static_cast<unsigned int>(seed)
            + static_cast<unsigned int>(i * 13U) + 1U);
    }
    return result;
}

[[nodiscard]] rollback::Digest seeded_floor_digest(
    const std::uint8_t seed) noexcept {
    rollback::Digest result{};
    for (std::size_t i = 0; i < result.size(); ++i) {
        result[i] = static_cast<std::uint8_t>(
            static_cast<unsigned int>(seed)
            + static_cast<unsigned int>(i * 17U) + 1U);
    }
    return result;
}

[[nodiscard]] journal::Completion make_completion(
    const std::uint64_t code, const char* text) noexcept {
    journal::Completion result{};
    result.result_code = code;
    std::size_t length = 0U;
    while (text[length] != '\0' && length < result.result.size()) {
        result.result[length] = static_cast<std::uint8_t>(text[length]);
        ++length;
    }
    result.result_length = static_cast<std::uint16_t>(length);
    return result;
}

[[nodiscard]] Fixtures make_fixtures() noexcept {
    Fixtures value{};
    value.descriptor.policy_body_digest = seeded_journal_digest(0x11U);
    value.descriptor.target_digest = seeded_journal_digest(0x21U);
    value.descriptor.final_image_digest = seeded_journal_digest(0x31U);
    value.descriptor.principal_effect_domain_digest =
        seeded_journal_digest(0x41U);
    value.descriptor.machine_incarnation_digest =
        seeded_journal_digest(0x51U);
    value.descriptor.replay_domain_digest = seeded_journal_digest(0x61U);
    value.descriptor.command_digest = seeded_journal_digest(0x71U);
    value.descriptor.payload_digest = seeded_journal_digest(0x81U);
    value.descriptor.policy_version = 7U;
    value.descriptor.operation_id = 41U;
    value.descriptor.route = 3U;
    value.descriptor.amount = 1U;
    value.wrong_descriptor = value.descriptor;
    value.wrong_descriptor.amount = 2U;
    value.no_effect_completion =
        make_completion(0x4e4f454646454354ULL, "NO_EFFECT");
    value.effect_completion =
        make_completion(0x434f4d4d49545445ULL, "COMMITTED");
    value.uncertain_completion =
        make_completion(0x554e434552544149ULL, "UNCERTAIN");

    value.empty = journal::empty_image();
    const journal::PlanResult c1 =
        journal::plan_admitted_v1(value.empty, value.descriptor);
    const journal::PlanResult c2 = journal::plan_dispatch_started_v1(c1.image);
    const journal::PlanResult c3_no =
        journal::plan_completed_v1(c2.image, value.no_effect_completion);
    const journal::PlanResult c3_yes =
        journal::plan_completed_v1(c2.image, value.effect_completion);
    const journal::PlanResult c3_unknown =
        journal::plan_completed_v1(c2.image, value.uncertain_completion);
    const journal::PlanResult c4_no =
        journal::plan_published_v1(c3_no.image, 1U);
    const journal::PlanResult c4_yes =
        journal::plan_published_v1(c3_yes.image, 1U);
    const journal::PlanResult c4_unknown =
        journal::plan_published_v1(c3_unknown.image, 1U);
    if (c1.status != PlanStatus::accepted || c2.status != PlanStatus::accepted
        || c3_no.status != PlanStatus::accepted
        || c3_yes.status != PlanStatus::accepted
        || c3_unknown.status != PlanStatus::accepted
        || c4_no.status != PlanStatus::accepted
        || c4_yes.status != PlanStatus::accepted
        || c4_unknown.status != PlanStatus::accepted) {
        std::abort();
    }
    value.c1 = c1.image;
    value.c2 = c2.image;
    value.c3_no_effect = c3_no.image;
    value.c3_effect = c3_yes.image;
    value.c3_uncertain = c3_unknown.image;
    value.c4_no_effect = c4_no.image;
    value.c4_effect = c4_yes.image;
    value.c4_uncertain = c4_unknown.image;

    value.predecessor =
        rollback::InstalledPoint{1U, seeded_floor_digest(0x12U)};
    value.successor =
        rollback::InstalledPoint{2U, seeded_floor_digest(0x34U)};
    value.transition = rollback::Transition{
        value.predecessor, value.successor, seeded_floor_digest(0x56U)};
    value.floor_identity = seeded_floor_digest(0x78U);
    value.wrong_floor_identity = seeded_floor_digest(0x9aU);
    return value;
}

[[nodiscard]] StepResult rejected(const State& state) noexcept {
    return StepResult{Outcome::rejected, state, false};
}
[[nodiscard]] StepResult applied(const State& state,
                                 const bool effect = false) noexcept {
    return StepResult{Outcome::applied, state, effect};
}
[[nodiscard]] bool no_ephemeral(const State& state) noexcept {
    return !state.pending_activation && !state.dispatch_permit;
}
[[nodiscard]] bool external_is(const State& state,
                               const rollback::Phase phase) noexcept {
    return joint_decision(state).phase == phase;
}
[[nodiscard]] bool exact_pending(const State& state) noexcept {
    return state.pending == PendingKind::exact;
}
[[nodiscard]] bool stable_predecessor(const State& state) noexcept {
    return !state.selector_successor && !state.confirmed_successor
        && state.pending == PendingKind::absent
        && state.floor == FloorKind::predecessor
        && external_is(state, rollback::Phase::stable);
}
[[nodiscard]] bool stable_successor(const State& state) noexcept {
    return state.selector_successor && state.confirmed_successor
        && state.pending == PendingKind::absent
        && state.floor == FloorKind::successor
        && external_is(state, rollback::Phase::stable);
}
[[nodiscard]] bool is_c3_or_c4(const DurableKind value) noexcept {
    return value == DurableKind::c3_no_effect
        || value == DurableKind::c3_effect
        || value == DurableKind::c3_uncertain
        || value == DurableKind::c4_no_effect
        || value == DurableKind::c4_effect
        || value == DurableKind::c4_uncertain;
}

}  // namespace

const Fixtures& fixtures() {
    static const Fixtures value = make_fixtures();
    return value;
}
State initial_state() noexcept { return State{}; }

bool state_invariant(const State& s) noexcept {
    if (s.effect_count > 2U) return false;
    if (s.pending_activation && s.dispatch_permit) return false;
    if (s.confirmed_successor && !s.selector_successor) return false;
    if ((s.recovered || s.reconcile_only) && !no_ephemeral(s)) return false;
    if (s.pending_activation) {
        if (s.durable != DurableKind::c2 || s.recovered || s.reconcile_only
            || s.dispatch != DispatchKnowledge::not_entered) return false;
    }
    if (s.dispatch_permit) {
        if (s.durable != DurableKind::c2 || s.recovered || s.reconcile_only
            || s.dispatch != DispatchKnowledge::not_entered
            || !stable_successor(s)) return false;
    }
    if (s.durable != DurableKind::c2 && !no_ephemeral(s)) return false;
    if (s.dispatch == DispatchKnowledge::exact_effect
        && !s.current_effect_occurred) return false;
    if (s.dispatch == DispatchKnowledge::exact_no_effect
        && s.current_effect_occurred) return false;
    if (s.current_effect_occurred && s.effect_count == 0U) return false;
    if (s.durable == DurableKind::c3_no_effect
        || s.durable == DurableKind::c4_no_effect) {
        if (s.dispatch != DispatchKnowledge::exact_no_effect
            || !no_ephemeral(s)) return false;
    }
    if (s.durable == DurableKind::c3_effect
        || s.durable == DurableKind::c4_effect) {
        if (s.dispatch != DispatchKnowledge::exact_effect
            || !no_ephemeral(s)) return false;
    }
    if (s.durable == DurableKind::c3_uncertain
        || s.durable == DurableKind::c4_uncertain) {
        if (s.dispatch != DispatchKnowledge::unknown
            || !no_ephemeral(s)) return false;
    }
    if ((s.durable == DurableKind::empty || s.durable == DurableKind::c1)
        && s.dispatch != DispatchKnowledge::not_entered) return false;
    return true;
}

journal::DurableCutV1Image durable_image(const DurableKind kind) {
    const Fixtures& f = fixtures();
    switch (kind) {
        case DurableKind::empty: return f.empty;
        case DurableKind::c1: return f.c1;
        case DurableKind::c2: return f.c2;
        case DurableKind::c3_no_effect: return f.c3_no_effect;
        case DurableKind::c3_effect: return f.c3_effect;
        case DurableKind::c3_uncertain: return f.c3_uncertain;
        case DurableKind::c4_no_effect: return f.c4_no_effect;
        case DurableKind::c4_effect: return f.c4_effect;
        case DurableKind::c4_uncertain: return f.c4_uncertain;
    }
    return f.empty;
}

rollback::JointObservation joint_observation(const State& state) noexcept {
    const Fixtures& f = fixtures();
    const rollback::InstalledPoint selector =
        state.selector_successor ? f.successor : f.predecessor;
    const rollback::InstalledPoint confirmed =
        state.confirmed_successor ? f.successor : f.predecessor;
    std::optional<Transition> pending;
    if (state.pending == PendingKind::exact) {
        pending = f.transition;
    } else if (state.pending == PendingKind::wrong) {
        Transition wrong = f.transition;
        wrong.successor = wrong.predecessor;
        pending = wrong;
    }
    FloorObservation floor{};
    switch (state.floor) {
        case FloorKind::predecessor:
            floor = FloorObservation{FloorReadStatus::available,
                                     f.floor_identity, 1U}; break;
        case FloorKind::successor:
            floor = FloorObservation{FloorReadStatus::available,
                                     f.floor_identity, 2U}; break;
        case FloorKind::unavailable:
            floor = FloorObservation{FloorReadStatus::unavailable,
                                     f.floor_identity, 0U}; break;
        case FloorKind::malformed:
            floor = FloorObservation{FloorReadStatus::malformed,
                                     f.floor_identity, 0U}; break;
        case FloorKind::wrong_identity:
            floor = FloorObservation{FloorReadStatus::identity_mismatch,
                                     f.wrong_floor_identity, 1U}; break;
    }
    return JointObservation{selector, confirmed, pending, floor};
}
rollback::Decision joint_decision(const State& state) noexcept {
    return rollback::evaluate(joint_observation(state), fixtures().floor_identity);
}

StepResult step_core(const State& input, const Event event) noexcept {
    State s = input;
    const Fixtures& f = fixtures();
    switch (event) {
        case Event::admit:
            if (s.durable != DurableKind::empty || !stable_predecessor(s)
                || !no_ephemeral(s) || s.current_effect_occurred) {
                return rejected(input);
            }
            s.durable = DurableKind::c1;
            s.recovered = false;
            s.reconcile_only = false;
            s.dispatch = DispatchKnowledge::not_entered;
            return applied(s);

        case Event::prepare_exact:
        case Event::prepare_wrong:
            if (s.durable != DurableKind::c1
                || s.pending != PendingKind::absent
                || !stable_predecessor(s) || !no_ephemeral(s)) {
                return rejected(input);
            }
            s.pending = event == Event::prepare_exact
                ? PendingKind::exact : PendingKind::wrong;
            return applied(s);

        case Event::plan_c2: {
            if (s.durable != DurableKind::c1 || !exact_pending(s)
                || !external_is(s, rollback::Phase::prepared)
                || !no_ephemeral(s)) return rejected(input);
            const journal::PlanResult plan =
                journal::plan_dispatch_started_v1(f.c1);
            if (plan.status != PlanStatus::accepted
                || !plan.pending_dispatch_activation.live) {
                return rejected(input);
            }
            s.durable = DurableKind::c2;
            s.dispatch = s.recovered
                ? DispatchKnowledge::unknown
                : DispatchKnowledge::not_entered;
            s.pending_activation = !s.recovered;
            s.reconcile_only = s.recovered;
            return applied(s);
        }

        case Event::advance_selector:
            if (s.durable != DurableKind::c2 || !exact_pending(s)
                || s.dispatch_permit
                || !external_is(s, rollback::Phase::prepared)
                || !rollback::exact_resume_matches(
                    joint_observation(s), f.transition, f.floor_identity)) {
                return rejected(input);
            }
            s.selector_successor = true;
            return applied(s);

        case Event::advance_floor: {
            if (s.durable != DurableKind::c2 || !exact_pending(s)
                || s.dispatch_permit
                || !external_is(s, rollback::Phase::selected_floor_pending)) {
                return rejected(input);
            }
            const auto request = rollback::make_floor_advance_request(
                joint_observation(s), f.transition, f.floor_identity);
            if (!request.has_value()) return rejected(input);
            const FloorAdvanceResult result{
                FloorAdvanceStatus::advanced, f.floor_identity, 1U, 2U};
            if (!rollback::accept_floor_advance_result(*request, result)) {
                return rejected(input);
            }
            s.floor = FloorKind::successor;
            return applied(s);
        }

        case Event::advance_confirmed:
            if (s.durable != DurableKind::c2 || !exact_pending(s)
                || s.dispatch_permit
                || !external_is(
                    s, rollback::Phase::floor_advanced_completion_pending)) {
                return rejected(input);
            }
            s.confirmed_successor = true;
            return applied(s);

        case Event::retire_pending:
            if (s.durable != DurableKind::c2 || !exact_pending(s)
                || s.dispatch_permit
                || !external_is(
                    s, rollback::Phase::confirmed_pending_cleanup)) {
                return rejected(input);
            }
            s.pending = PendingKind::absent;
            return applied(s);

        case Event::activate_exact:
        case Event::activate_mismatch: {
            if (s.durable != DurableKind::c2 || !s.pending_activation
                || s.recovered || s.reconcile_only
                || s.dispatch != DispatchKnowledge::not_entered
                || !stable_successor(s)) return rejected(input);
            journal::PendingDispatchActivation pending =
                journal::plan_dispatch_started_v1(f.c1)
                    .pending_dispatch_activation;
            const journal::DurableCutV1Image readback =
                event == Event::activate_exact ? f.c2 : f.c1;
            const journal::ActivationResult result =
                journal::activate_dispatch_permit_after_readback_v1(
                    pending, readback);
            s.pending_activation = false;
            if (event == Event::activate_exact) {
                if (result.status != ActivationStatus::accepted
                    || !result.dispatch_permit.live) return rejected(input);
                s.dispatch_permit = true;
            } else if (result.status != ActivationStatus::image_mismatch) {
                return rejected(input);
            }
            return applied(s);
        }

        case Event::enter_dispatch_exact:
        case Event::enter_dispatch_mismatch: {
            if (s.durable != DurableKind::c2 || !s.dispatch_permit
                || s.recovered || s.reconcile_only
                || s.dispatch != DispatchKnowledge::not_entered
                || !stable_successor(s)) return rejected(input);
            journal::DispatchPermit permit{};
            permit.live = true;
            permit.generation = 2U;
            permit.descriptor = f.descriptor;
            const bool ok = journal::consume_dispatch_permit(
                permit, event == Event::enter_dispatch_exact
                    ? f.descriptor : f.wrong_descriptor);
            s.dispatch_permit = false;
            if (event == Event::enter_dispatch_exact) {
                if (!ok || !permit.consumed) return rejected(input);
                s.dispatch = DispatchKnowledge::unknown;
                s.reconcile_only = true;
            } else if (ok || !permit.consumed) {
                return rejected(input);
            }
            return applied(s);
        }

        case Event::return_no_effect:
            if (s.durable != DurableKind::c2
                || s.dispatch != DispatchKnowledge::unknown
                || s.recovered || s.current_effect_occurred
                || !no_ephemeral(s)) return rejected(input);
            s.dispatch = DispatchKnowledge::exact_no_effect;
            return applied(s);

        case Event::return_effect:
            if (s.durable != DurableKind::c2
                || s.dispatch != DispatchKnowledge::unknown
                || s.recovered || s.current_effect_occurred
                || s.effect_count >= 2U || !no_ephemeral(s)) {
                return rejected(input);
            }
            s.current_effect_occurred = true;
            ++s.effect_count;
            s.dispatch = DispatchKnowledge::exact_effect;
            return applied(s, true);

        case Event::return_malformed:
            if (s.durable != DurableKind::c2
                || s.dispatch != DispatchKnowledge::unknown
                || s.recovered || !no_ephemeral(s)) return rejected(input);
            s.reconcile_only = true;
            return applied(s);

        case Event::reconcile_no_effect:
            if (s.durable != DurableKind::c2
                || s.dispatch != DispatchKnowledge::unknown
                || (!s.recovered && !s.reconcile_only)
                || s.current_effect_occurred || !no_ephemeral(s)) {
                return rejected(input);
            }
            s.dispatch = DispatchKnowledge::exact_no_effect;
            return applied(s);

        case Event::reconcile_effect:
            if (s.durable != DurableKind::c2
                || s.dispatch != DispatchKnowledge::unknown
                || (!s.recovered && !s.reconcile_only)
                || !s.current_effect_occurred || !no_ephemeral(s)) {
                return rejected(input);
            }
            s.dispatch = DispatchKnowledge::exact_effect;
            return applied(s);

        case Event::reconcile_malformed:
            if (s.durable != DurableKind::c2
                || s.dispatch != DispatchKnowledge::unknown
                || (!s.recovered && !s.reconcile_only)
                || !no_ephemeral(s)) return rejected(input);
            s.reconcile_only = true;
            return applied(s);

        case Event::complete_no_effect:
            if (s.durable != DurableKind::c2
                || s.dispatch != DispatchKnowledge::exact_no_effect
                || !stable_successor(s) || !no_ephemeral(s)) {
                return rejected(input);
            }
            s.durable = DurableKind::c3_no_effect;
            return applied(s);

        case Event::complete_effect:
            if (s.durable != DurableKind::c2
                || s.dispatch != DispatchKnowledge::exact_effect
                || !stable_successor(s) || !no_ephemeral(s)) {
                return rejected(input);
            }
            s.durable = DurableKind::c3_effect;
            return applied(s);

        case Event::complete_uncertain:
            if (s.durable != DurableKind::c2
                || s.dispatch != DispatchKnowledge::unknown
                || !stable_successor(s) || !no_ephemeral(s)) {
                return rejected(input);
            }
            s.durable = DurableKind::c3_uncertain;
            s.reconcile_only = true;
            return applied(s);

        case Event::publish_no_effect:
            if (s.durable != DurableKind::c3_no_effect || !no_ephemeral(s)) {
                return rejected(input);
            }
            s.durable = DurableKind::c4_no_effect;
            return applied(s);

        case Event::publish_effect:
            if (s.durable != DurableKind::c3_effect || !no_ephemeral(s)) {
                return rejected(input);
            }
            s.durable = DurableKind::c4_effect;
            return applied(s);

        case Event::publish_uncertain:
            if (s.durable != DurableKind::c3_uncertain || !no_ephemeral(s)) {
                return rejected(input);
            }
            s.durable = DurableKind::c4_uncertain;
            return applied(s);

        case Event::restart:
            s.pending_activation = false;
            s.dispatch_permit = false;
            s.recovered = true;
            if (s.durable == DurableKind::c2) {
                // The exact retained C2 bytes do not reveal whether dispatch
                // had not entered, entered and returned, or entered and lost
                // its return.  Reopen therefore widens to uncertainty.
                s.dispatch = DispatchKnowledge::unknown;
                s.reconcile_only = true;
            } else if (s.durable == DurableKind::c1) {
                s.reconcile_only = true;
            }
            return applied(s);

        case Event::observe_floor_predecessor:
        case Event::observe_floor_successor:
        case Event::observe_floor_unavailable:
        case Event::observe_floor_malformed:
        case Event::observe_floor_wrong_identity:
            if (!no_ephemeral(s)) return rejected(input);
            if (event == Event::observe_floor_predecessor) {
                s.floor = FloorKind::predecessor;
            } else if (event == Event::observe_floor_successor) {
                s.floor = FloorKind::successor;
            } else if (event == Event::observe_floor_unavailable) {
                s.floor = FloorKind::unavailable;
            } else if (event == Event::observe_floor_malformed) {
                s.floor = FloorKind::malformed;
            } else {
                s.floor = FloorKind::wrong_identity;
            }
            return applied(s);

        case Event::rollback_local_keep_floor:
            if (!is_c3_or_c4(s.durable) || s.effect_count == 0U) {
                return rejected(input);
            }
            s.durable = DurableKind::c1;
            s.selector_successor = false;
            s.confirmed_successor = false;
            s.pending = PendingKind::exact;
            s.pending_activation = false;
            s.dispatch_permit = false;
            s.recovered = true;
            s.reconcile_only = true;
            s.dispatch = DispatchKnowledge::not_entered;
            // The external effect survives the local rollback.
            s.current_effect_occurred = true;
            return applied(s);

        case Event::rollback_local_and_floor:
            if (!is_c3_or_c4(s.durable) || s.effect_count == 0U) {
                return rejected(input);
            }
            // This adversarial event restores a full restorable checkpoint,
            // including the live pre-dispatch process state and floor.  The
            // ghost effect count intentionally survives outside that image.
            s.durable = DurableKind::c1;
            s.selector_successor = false;
            s.confirmed_successor = false;
            s.pending = PendingKind::exact;
            s.floor = FloorKind::predecessor;
            s.pending_activation = false;
            s.dispatch_permit = false;
            s.recovered = false;
            s.reconcile_only = false;
            s.dispatch = DispatchKnowledge::not_entered;
            s.current_effect_occurred = false;
            return applied(s);

        case Event::rollback_c2_keep_floor:
            if (!is_c3_or_c4(s.durable) || s.effect_count == 0U) {
                return rejected(input);
            }
            s.durable = DurableKind::c2;
            s.selector_successor = true;
            s.confirmed_successor = true;
            s.pending = PendingKind::absent;
            s.pending_activation = false;
            s.dispatch_permit = false;
            s.recovered = true;
            s.reconcile_only = true;
            s.dispatch = DispatchKnowledge::unknown;
            s.current_effect_occurred = true;
            return applied(s);
    }
    return rejected(input);
}

}  // namespace slopos::e0::fence
