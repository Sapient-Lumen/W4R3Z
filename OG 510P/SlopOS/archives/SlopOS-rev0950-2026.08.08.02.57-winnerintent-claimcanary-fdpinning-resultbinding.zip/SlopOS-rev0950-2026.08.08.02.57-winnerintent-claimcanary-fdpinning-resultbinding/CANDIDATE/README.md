# Candidate surface — Repository V58

The current candidate has **three active semantic islands** and five product executables. Selection is explicit and fail-closed; no default island exists. Fourteen adjacent legacy immediate children remain retained and are not current build targets.

Three nested C++20 proof leaves form the current publication and representation seam without changing topology:

- `core_gate/ratification_subject/intake_fence` retains Atomic Packet V1 and its complete-or-absent local final-directory relation.
- `generation_journal/checkpoint_transport_commit` retains Checkpoint Transport Commit V2: complete hidden staging, exact comparison, mode restriction, file sync, no-replace publication, parent sync, and explicit non-writing exact-existing reconciliation.
- `generation_journal/shadow_pack` adds Rooted Shadow Pack V2: deterministic payload deduplication, descriptor-rooted source observation, exact logical-record-address and mode manifest, malformed-input rejection, hidden same-parent inverse, and no-replace complete visibility.

Rooted Shadow Pack's operated subject contains 1,637 entries and 6,945,527 logical file bytes; 3,812,999 duplicate bytes are represented once. Three C++20 lanes match an independent Python oracle and reconstruct exactly. All loose evidence remains.

No nested leaf is a sixth product, fourth island, service, owner act, or living admission. Transport synchronization does not prove stable media or provenance. Descriptor-rooted observation does not prove exclusive writers. Exact inversion does not authenticate the pack or authorize deletion.

Use `CANDIDATE/PATH-ROLES.tsv` for the exhaustive immediate namespace and `CANDIDATE/ACTIVE-BUILD.tsv` for the five product targets.
