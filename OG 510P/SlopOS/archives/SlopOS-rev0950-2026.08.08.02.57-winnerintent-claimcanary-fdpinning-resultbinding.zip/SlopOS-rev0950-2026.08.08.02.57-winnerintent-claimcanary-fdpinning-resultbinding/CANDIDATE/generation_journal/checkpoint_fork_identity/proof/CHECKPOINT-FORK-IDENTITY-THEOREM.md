# Checkpoint Fork Identity and Merge Fence theorem

For the bounded canonical relation retained by rev0927:

1. exact parent set, logical snapshot, and closure policy determine one semantic
   checkpoint identity;
2. changing only display metadata changes the representation record but not the
   semantic checkpoint identity;
3. a different logical snapshot under the same exact parent yields a sibling
   checkpoint even when the display label is identical;
4. one hosted compare-and-update history admits at most one child from one
   observed head;
5. cloning that registry before the update admits a countermodel in which both
   histories accept one local child, so global uniqueness does not follow;
6. a sealed transport requires an exact publication receipt and later exact
   reopen; a pre-seal workspace is a different subject;
7. a merge candidate requires two distinct exact parents, reopen evidence for
   both, an exact resolution digest, and an exact merged snapshot; and
8. none of these hosted facts constitutes owners, selects the globally current
   living lineage, or exits Epoch Zero.
