#include "slopos/e0/checkpoint_fork_identity/checkpoint_fork_identity.hpp"

#include <algorithm>
#include <array>
#include <cstring>
#include <limits>
#include <openssl/evp.h>
#include <stdexcept>
#include <string>
#include <vector>

namespace slopos::e0::checkpoint_fork_identity {
namespace {

template <std::size_t N> struct Writer {
  std::array<std::uint8_t, N> bytes{};
  std::size_t offset{};
  void raw(std::span<const std::uint8_t> value) {
    if (offset + value.size() > N) throw std::runtime_error("canonical overflow");
    std::copy(value.begin(), value.end(), bytes.begin() + static_cast<std::ptrdiff_t>(offset));
    offset += value.size();
  }
  void digest(const Digest& value) { raw(value); }
  void u64(std::uint64_t value) {
    std::array<std::uint8_t, 8> out{};
    for (std::size_t i = 0; i < out.size(); ++i) out[i] = static_cast<std::uint8_t>((value >> (8U * i)) & 0xffU);
    raw(out);
  }
  void magic(std::string_view value) {
    if (value.size() > 31) throw std::runtime_error("magic too long");
    std::array<std::uint8_t, 32> out{};
    std::copy(value.begin(), value.end(), out.begin());
    raw(out);
  }
};

Digest from_hex(std::string_view text) {
  if (text.size() != 64) throw std::runtime_error("bad digest length");
  Digest out{};
  auto nibble = [](char c) -> std::uint8_t {
    if (c >= '0' && c <= '9') return static_cast<std::uint8_t>(c - '0');
    if (c >= 'a' && c <= 'f') return static_cast<std::uint8_t>(10 + c - 'a');
    throw std::runtime_error("bad digest hex");
  };
  for (std::size_t i = 0; i < out.size(); ++i) out[i] = static_cast<std::uint8_t>((nibble(text[2*i]) << 4U) | nibble(text[2*i+1]));
  return out;
}

const Digest& parent_archive_sha() { static const Digest v = from_hex(SLOPOS_CFI_PARENT_ARCHIVE_SHA256_HEX); return v; }
const Digest& parent_root_sha() { static const Digest v = from_hex(SLOPOS_CFI_PARENT_ROOT_SHA256_HEX); return v; }
const Digest& parent_filename_sha() { static const Digest v = from_hex(SLOPOS_CFI_PARENT_FILENAME_SHA256_HEX); return v; }
const Digest& parent_checkpoint_sha() { static const Digest v = from_hex(SLOPOS_CFI_PARENT_CHECKPOINT_SHA256_HEX); return v; }
const Digest& closure_policy_sha() { static const Digest v = from_hex(SLOPOS_CFI_CLOSURE_POLICY_SHA256_HEX); return v; }
const Digest& branch_policy_sha() { static const Digest v = from_hex(SLOPOS_CFI_BRANCH_POLICY_SHA256_HEX); return v; }
const Digest& merge_policy_sha() { static const Digest v = from_hex(SLOPOS_CFI_MERGE_POLICY_SHA256_HEX); return v; }
const Digest& reopener_sha() { static const Digest v = from_hex(SLOPOS_CFI_REOPENER_IMPLEMENTATION_SHA256_HEX); return v; }

void append(std::vector<std::uint8_t>& out, const Digest& value) { out.insert(out.end(), value.begin(), value.end()); }
void append(std::vector<std::uint8_t>& out, std::uint64_t value) {
  for (std::size_t i = 0; i < 8; ++i) out.push_back(static_cast<std::uint8_t>((value >> (8U*i)) & 0xffU));
}

Digest checkpoint_semantic_id(const Digest& primary, const Digest& secondary, const Digest& snapshot,
                              const Digest& policy, std::uint64_t parent_count) {
  std::vector<std::uint8_t> payload;
  append(payload, digest_text("slopos.checkpoint-fork-identity.checkpoint-schema.v1"));
  append(payload, primary); append(payload, secondary); append(payload, snapshot); append(payload, policy); append(payload, parent_count);
  return digest_bytes("SlopOS/rev0927/checkpoint-fork-identity/checkpoint-id/v1", payload);
}

Digest sibling_record_id(const Digest& checkpoint_id, const Digest& snapshot_id) {
  std::vector<std::uint8_t> payload; append(payload, checkpoint_id); append(payload, snapshot_id);
  return digest_bytes("SlopOS/rev0927/checkpoint-fork-identity/sibling-record/v1", payload);
}

Digest secondary_transport_id(const BranchCustody& branch) {
  std::vector<std::uint8_t> payload; append(payload, branch.sibling_checkpoint_id); append(payload, branch.object_id);
  return digest_bytes("SlopOS/rev0927/checkpoint-fork-identity/secondary-transport/v1", payload);
}
Digest secondary_reopen_id(const BranchCustody& branch) {
  std::vector<std::uint8_t> payload; const auto transport = secondary_transport_id(branch);
  append(payload, transport); append(payload, reopener_sha());
  return digest_bytes("SlopOS/rev0927/checkpoint-fork-identity/secondary-reopen/v1", payload);
}

Digest object_id(ParentBinding value) { value.object_id = {}; auto bytes = serialize(value); return digest_bytes("SlopOS/rev0927/checkpoint-fork-identity/parent/v1", bytes); }
Digest object_id(SourceSnapshot value) { value.object_id = {}; auto bytes = serialize(value); return digest_bytes("SlopOS/rev0927/checkpoint-fork-identity/source-snapshot/v1", bytes); }
Digest record_id(CheckpointRecord value) { value.record_id = {}; auto bytes = serialize(value); return digest_bytes("SlopOS/rev0927/checkpoint-fork-identity/checkpoint-record/v1", bytes); }
Digest object_id(HeadObservation value) { value.object_id = {}; auto bytes = serialize(value); return digest_bytes("SlopOS/rev0927/checkpoint-fork-identity/head-observation/v1", bytes); }
Digest object_id(HeadUpdateReceipt value) { value.object_id = {}; auto bytes = serialize(value); return digest_bytes("SlopOS/rev0927/checkpoint-fork-identity/head-update/v1", bytes); }
Digest object_id(TransportReceipt value) { value.object_id = {}; auto bytes = serialize(value); return digest_bytes("SlopOS/rev0927/checkpoint-fork-identity/transport/v1", bytes); }
Digest object_id(ReopenReceipt value) { value.object_id = {}; auto bytes = serialize(value); return digest_bytes("SlopOS/rev0927/checkpoint-fork-identity/reopen/v1", bytes); }
Digest object_id(BranchCustody value) { value.object_id = {}; auto bytes = serialize(value); return digest_bytes("SlopOS/rev0927/checkpoint-fork-identity/branch-custody/v1", bytes); }
Digest merge_record_id(MergeRecord value) { value.record_id = {}; auto bytes = serialize(value); return digest_bytes("SlopOS/rev0927/checkpoint-fork-identity/merge-record/v1", bytes); }


Judgment reject(Reason reason, std::uint64_t stage, const Trace& trace) {
  Judgment out{}; out.accepted = false; out.reason = reason; out.durable_stage = stage;
  out.display_label_selects = false; out.global_lineage_unique = false; out.external_selection = false; out.owner_admission = false;
  out.checkpoint_id = trace.checkpoint.checkpoint_id; out.checkpoint_record_id = trace.checkpoint.record_id;
  out.merge_checkpoint_id = trace.merge.merge_checkpoint_id; return out;
}

bool any_after(const Trace& t, std::uint64_t stage) {
  const std::array<bool,9> values{t.has_parent,t.has_snapshot,t.has_checkpoint,t.has_head_observation,t.has_head_update,t.has_transport,t.has_reopen,t.has_branch,t.has_merge};
  for (std::size_t i = static_cast<std::size_t>(stage); i < values.size(); ++i) if (values[i]) return true;
  return false;
}

} // namespace

Digest digest_bytes(std::string_view domain, std::span<const std::uint8_t> bytes) {
  EVP_MD_CTX* context = EVP_MD_CTX_new();
  if (context == nullptr) throw std::runtime_error("EVP_MD_CTX_new");
  Digest out{}; unsigned int length = 0;
  const std::uint8_t zero = 0;
  const bool ok = EVP_DigestInit_ex(context, EVP_sha256(), nullptr) == 1
      && EVP_DigestUpdate(context, domain.data(), domain.size()) == 1
      && EVP_DigestUpdate(context, &zero, 1) == 1
      && (bytes.empty() || EVP_DigestUpdate(context, bytes.data(), bytes.size()) == 1)
      && EVP_DigestFinal_ex(context, out.data(), &length) == 1;
  EVP_MD_CTX_free(context);
  if (!ok || length != out.size()) throw std::runtime_error("sha256 failure");
  return out;
}
Digest digest_text(std::string_view text) {
  return digest_bytes("SlopOS/rev0927/checkpoint-fork-identity/text/v1",
                      std::span<const std::uint8_t>(reinterpret_cast<const std::uint8_t*>(text.data()), text.size()));
}
bool is_zero(const Digest& value) { return std::all_of(value.begin(), value.end(), [](std::uint8_t b){ return b == 0; }); }
std::string hex(const Digest& value) {
  static constexpr char chars[] = "0123456789abcdef"; std::string out; out.reserve(64);
  for (auto b : value) { out.push_back(chars[b >> 4U]); out.push_back(chars[b & 0x0fU]); } return out;
}
std::string reason_name(Reason reason) {
  switch (reason) {
    case Reason::accepted: return "ACCEPTED"; case Reason::missing_predecessor: return "MISSING_PREDECESSOR";
    case Reason::parent_binding: return "PARENT_BINDING"; case Reason::source_snapshot: return "SOURCE_SNAPSHOT";
    case Reason::checkpoint_record: return "CHECKPOINT_RECORD"; case Reason::head_observation: return "HEAD_OBSERVATION";
    case Reason::head_update: return "HEAD_UPDATE"; case Reason::transport_receipt: return "TRANSPORT_RECEIPT";
    case Reason::reopen_receipt: return "REOPEN_RECEIPT"; case Reason::branch_custody: return "BRANCH_CUSTODY";
    case Reason::merge_record: return "MERGE_RECORD"; case Reason::impossible_history: return "IMPOSSIBLE_HISTORY";
  }
  return "UNKNOWN";
}
std::string branch_name(BranchClass value) {
  switch (value) { case BranchClass::none: return "NONE"; case BranchClass::duplicate: return "DUPLICATE"; case BranchClass::fork: return "FORK"; }
  return "INVALID";
}

std::array<std::uint8_t, parent_bytes> serialize(const ParentBinding& v) {
  Writer<parent_bytes> w; w.magic("SLOPOS-CFI-PARENT-V1"); w.digest(v.archive_sha); w.u64(v.archive_bytes); w.u64(v.manifest_rows);
  w.digest(v.root_digest); w.digest(v.filename_digest); w.digest(v.checkpoint_projection_digest); w.digest(v.object_id); return w.bytes;
}
std::array<std::uint8_t, snapshot_bytes> serialize(const SourceSnapshot& v) {
  Writer<snapshot_bytes> w; w.magic("SLOPOS-CFI-SNAPSHOT-V1"); w.digest(v.snapshot_digest); w.digest(v.logical_root_digest);
  w.digest(v.repository_digest); w.digest(v.proof_projection_digest); w.digest(v.closure_policy_digest); w.u64(v.manifest_rows); w.digest(v.object_id); return w.bytes;
}
std::array<std::uint8_t, checkpoint_bytes> serialize(const CheckpointRecord& v) {
  Writer<checkpoint_bytes> w; w.magic("SLOPOS-CFI-CHECKPOINT-V1"); w.digest(v.schema_digest); w.digest(v.primary_parent_id);
  w.digest(v.secondary_parent_id); w.digest(v.snapshot_id); w.digest(v.closure_policy_digest); w.digest(v.display_label_digest);
  w.u64(v.created_ordinal); w.u64(v.parent_count); w.digest(v.checkpoint_id); w.digest(v.record_id); return w.bytes;
}
std::array<std::uint8_t, head_observation_bytes> serialize(const HeadObservation& v) {
  Writer<head_observation_bytes> w; w.magic("SLOPOS-CFI-HEAD-OBS-V1"); w.digest(v.registry_incarnation);
  w.digest(v.expected_head_checkpoint_id); w.u64(v.observed_generation); w.u64(v.observed_revision);
  w.digest(v.observer_policy_digest); w.digest(v.object_id); return w.bytes;
}
std::array<std::uint8_t, head_update_bytes> serialize(const HeadUpdateReceipt& v) {
  Writer<head_update_bytes> w; w.magic("SLOPOS-CFI-HEAD-UPDATE-V1"); w.digest(v.observation_id); w.digest(v.registry_incarnation);
  w.digest(v.expected_old_checkpoint_id); w.digest(v.new_checkpoint_id); w.u64(v.new_generation); w.u64(v.commit_revision);
  w.u64(static_cast<std::uint64_t>(v.result)); w.digest(v.object_id); return w.bytes;
}
std::array<std::uint8_t, transport_bytes> serialize(const TransportReceipt& v) {
  Writer<transport_bytes> w; w.magic("SLOPOS-CFI-TRANSPORT-V1"); w.digest(v.checkpoint_id); w.digest(v.checkpoint_record_id);
  w.digest(v.archive_sha); w.u64(v.archive_bytes); w.u64(v.manifest_rows); w.digest(v.root_digest); w.digest(v.archive_name_digest);
  w.u64(v.no_replace); w.u64(v.file_durable); w.u64(v.directory_durable); w.u64(v.publication_revision); w.digest(v.object_id); return w.bytes;
}
std::array<std::uint8_t, reopen_bytes> serialize(const ReopenReceipt& v) {
  Writer<reopen_bytes> w; w.magic("SLOPOS-CFI-REOPEN-V1"); w.digest(v.transport_receipt_id); w.digest(v.archive_sha);
  w.digest(v.extracted_root_digest); w.digest(v.manifest_digest); w.u64(v.manifest_rows); w.digest(v.reopener_implementation_digest);
  w.u64(v.result); w.digest(v.object_id); return w.bytes;
}
std::array<std::uint8_t, branch_bytes> serialize(const BranchCustody& v) {
  Writer<branch_bytes> w; w.magic("SLOPOS-CFI-BRANCH-V1"); w.digest(v.common_parent_id); w.digest(v.selected_checkpoint_id);
  w.digest(v.sibling_snapshot_id); w.digest(v.sibling_checkpoint_id); w.digest(v.sibling_record_id);
  w.u64(static_cast<std::uint64_t>(v.classification)); w.u64(v.known_sibling_count); w.digest(v.custody_policy_digest); w.digest(v.object_id); return w.bytes;
}
std::array<std::uint8_t, merge_bytes> serialize(const MergeRecord& v) {
  Writer<merge_bytes> w; w.magic("SLOPOS-CFI-MERGE-V1"); w.digest(v.primary_parent_checkpoint_id); w.digest(v.secondary_parent_checkpoint_id);
  w.digest(v.primary_parent_reopen_receipt_id); w.digest(v.secondary_parent_transport_receipt_id); w.digest(v.secondary_parent_reopen_receipt_id);
  w.digest(v.resolution_digest); w.digest(v.merged_snapshot_id); w.digest(v.merge_policy_digest); w.u64(v.parent_count);
  w.u64(v.all_parents_reopened); w.digest(v.merge_checkpoint_id); w.digest(v.record_id); return w.bytes;
}

ParentBinding make_parent_binding() {
  ParentBinding v{}; v.archive_sha = parent_archive_sha(); v.archive_bytes = SLOPOS_CFI_PARENT_ARCHIVE_BYTES;
  v.manifest_rows = SLOPOS_CFI_PARENT_MANIFEST_ROWS; v.root_digest = parent_root_sha(); v.filename_digest = parent_filename_sha();
  v.checkpoint_projection_digest = parent_checkpoint_sha(); v.object_id = object_id(v); return v;
}
SourceSnapshot make_source_snapshot(std::string_view label) {
  SourceSnapshot v{}; v.snapshot_digest = digest_text(std::string("logical-source-snapshot:") + std::string(label));
  v.logical_root_digest = digest_text("SlopOS/rev0927/logical-root/checkpoint-fork-preservation");
  v.repository_digest = digest_text("Repository-V49-three-semantic-islands");
  v.proof_projection_digest = digest_text("rev0926-one-use-response-consumption-105-8-97-840");
  v.closure_policy_digest = closure_policy_sha(); v.manifest_rows = 9600; v.object_id = object_id(v); return v;
}
CheckpointRecord make_checkpoint_record(const ParentBinding& parent, const SourceSnapshot& snapshot, std::string_view label) {
  CheckpointRecord v{}; v.schema_digest = digest_text("slopos.checkpoint-fork-identity.checkpoint-schema.v1");
  v.primary_parent_id = parent.object_id; v.secondary_parent_id = {}; v.snapshot_id = snapshot.object_id;
  v.closure_policy_digest = closure_policy_sha(); v.display_label_digest = digest_text(label); v.created_ordinal = 9271952;
  v.parent_count = 1; v.checkpoint_id = checkpoint_semantic_id(v.primary_parent_id, v.secondary_parent_id, v.snapshot_id, v.closure_policy_digest, v.parent_count);
  v.record_id = record_id(v); return v;
}
HeadObservation make_head_observation(const ParentBinding& parent) {
  HeadObservation v{}; v.registry_incarnation = digest_text("rev0927-hosted-lineage-registry-fixture");
  v.expected_head_checkpoint_id = parent.object_id; v.observed_generation = 926; v.observed_revision = 4100;
  v.observer_policy_digest = branch_policy_sha(); v.object_id = object_id(v); return v;
}
HeadUpdateReceipt make_head_update(const ParentBinding& parent, const CheckpointRecord& checkpoint, const HeadObservation& observation) {
  HeadUpdateReceipt v{}; v.observation_id = observation.object_id; v.registry_incarnation = observation.registry_incarnation;
  v.expected_old_checkpoint_id = parent.object_id; v.new_checkpoint_id = checkpoint.checkpoint_id;
  v.new_generation = observation.observed_generation + 1; v.commit_revision = observation.observed_revision + 1;
  v.result = UpdateResult::applied; v.object_id = object_id(v); return v;
}
TransportReceipt make_transport_receipt(const CheckpointRecord& checkpoint, const HeadUpdateReceipt& update) {
  TransportReceipt v{}; v.checkpoint_id = checkpoint.checkpoint_id; v.checkpoint_record_id = checkpoint.record_id;
  v.archive_sha = digest_text("rev0927-fixture-transport-bytes"); v.archive_bytes = 15000000; v.manifest_rows = 9700;
  v.root_digest = digest_text("SlopOS-rev0927-fixture-root"); v.archive_name_digest = digest_text("SlopOS-rev0927-fixture.zip");
  v.no_replace = 1; v.file_durable = 1; v.directory_durable = 1; v.publication_revision = update.commit_revision + 1;
  v.object_id = object_id(v); return v;
}
ReopenReceipt make_reopen_receipt(const TransportReceipt& transport) {
  ReopenReceipt v{}; v.transport_receipt_id = transport.object_id; v.archive_sha = transport.archive_sha;
  v.extracted_root_digest = transport.root_digest; v.manifest_digest = digest_text("rev0927-fixture-content-manifest");
  v.manifest_rows = transport.manifest_rows; v.reopener_implementation_digest = reopener_sha(); v.result = 1;
  v.object_id = object_id(v); return v;
}
BranchCustody make_branch_custody(const ParentBinding& parent, const CheckpointRecord& checkpoint, std::string_view sibling_label) {
  const auto sibling_snapshot = make_source_snapshot(sibling_label);
  BranchCustody v{}; v.common_parent_id = parent.object_id; v.selected_checkpoint_id = checkpoint.checkpoint_id;
  v.sibling_snapshot_id = sibling_snapshot.object_id;
  v.sibling_checkpoint_id = checkpoint_semantic_id(parent.object_id, {}, v.sibling_snapshot_id, closure_policy_sha(), 1);
  v.sibling_record_id = sibling_record_id(v.sibling_checkpoint_id, v.sibling_snapshot_id);
  v.classification = v.sibling_checkpoint_id == checkpoint.checkpoint_id ? BranchClass::duplicate : BranchClass::fork;
  v.known_sibling_count = 1; v.custody_policy_digest = branch_policy_sha(); v.object_id = object_id(v); return v;
}
MergeRecord make_merge_record(const CheckpointRecord& checkpoint, const ReopenReceipt& reopen, const BranchCustody& branch) {
  MergeRecord v{}; v.primary_parent_checkpoint_id = checkpoint.checkpoint_id; v.secondary_parent_checkpoint_id = branch.sibling_checkpoint_id;
  v.primary_parent_reopen_receipt_id = reopen.object_id; v.secondary_parent_transport_receipt_id = secondary_transport_id(branch);
  v.secondary_parent_reopen_receipt_id = secondary_reopen_id(branch); v.resolution_digest = digest_text("rev0927-explicit-sibling-resolution-map");
  v.merged_snapshot_id = digest_text("rev0927-merged-logical-source-snapshot"); v.merge_policy_digest = merge_policy_sha();
  v.parent_count = 2; v.all_parents_reopened = 1;
  v.merge_checkpoint_id = checkpoint_semantic_id(v.primary_parent_checkpoint_id, v.secondary_parent_checkpoint_id,
                                                  v.merged_snapshot_id, v.merge_policy_digest, v.parent_count);
  v.record_id = merge_record_id(v); return v;
}
Trace make_valid_trace() {
  Trace t{}; t.has_parent=t.has_snapshot=t.has_checkpoint=t.has_head_observation=t.has_head_update=true;
  t.has_transport=t.has_reopen=t.has_branch=t.has_merge=true; t.parent=make_parent_binding(); t.snapshot=make_source_snapshot();
  t.checkpoint=make_checkpoint_record(t.parent,t.snapshot); t.head_observation=make_head_observation(t.parent);
  t.head_update=make_head_update(t.parent,t.checkpoint,t.head_observation); t.transport=make_transport_receipt(t.checkpoint,t.head_update);
  t.reopen=make_reopen_receipt(t.transport); t.branch=make_branch_custody(t.parent,t.checkpoint); t.merge=make_merge_record(t.checkpoint,t.reopen,t.branch);
  t.physical_locator_digest=digest_text("/mnt/data/physical-workspace-a"); return t;
}
Trace prefix(const Trace& input, std::uint64_t stage) {
  Trace t=input;
  if(stage<9) t.has_merge=false;
  if(stage<8) t.has_branch=false;
  if(stage<7) t.has_reopen=false;
  if(stage<6) t.has_transport=false;
  if(stage<5) t.has_head_update=false;
  if(stage<4) t.has_head_observation=false;
  if(stage<3) t.has_checkpoint=false;
  if(stage<2) t.has_snapshot=false;
  if(stage<1) t.has_parent=false;
  return t;
}

Judgment evaluate_candidate(const Trace& t) {
  if (!t.has_parent) return any_after(t,0) ? reject(Reason::missing_predecessor,0,t) : reject(Reason::missing_predecessor,0,t);
  if (!(t.parent.archive_sha==parent_archive_sha() && t.parent.archive_bytes==SLOPOS_CFI_PARENT_ARCHIVE_BYTES
        && t.parent.manifest_rows==SLOPOS_CFI_PARENT_MANIFEST_ROWS && t.parent.root_digest==parent_root_sha()
        && t.parent.filename_digest==parent_filename_sha() && t.parent.checkpoint_projection_digest==parent_checkpoint_sha()
        && t.parent.object_id==object_id(t.parent))) return reject(Reason::parent_binding,0,t);
  std::uint64_t stage=1;
  if (!t.has_snapshot) { if(any_after(t,stage)) return reject(Reason::missing_predecessor,stage,t); Judgment j{}; j.accepted=true;j.reason=Reason::accepted;j.durable_stage=stage;return j; }
  if (is_zero(t.snapshot.snapshot_digest)||is_zero(t.snapshot.logical_root_digest)||is_zero(t.snapshot.repository_digest)
      ||is_zero(t.snapshot.proof_projection_digest)||t.snapshot.closure_policy_digest!=closure_policy_sha()
      ||t.snapshot.manifest_rows==0||t.snapshot.object_id!=object_id(t.snapshot)) return reject(Reason::source_snapshot,stage,t);
  stage=2;
  if (!t.has_checkpoint) { if(any_after(t,stage)) return reject(Reason::missing_predecessor,stage,t); Judgment j{};j.accepted=true;j.reason=Reason::accepted;j.durable_stage=stage;return j; }
  const auto expected_checkpoint=checkpoint_semantic_id(t.parent.object_id,{},t.snapshot.object_id,closure_policy_sha(),1);
  if (t.checkpoint.schema_digest!=digest_text("slopos.checkpoint-fork-identity.checkpoint-schema.v1")
      ||t.checkpoint.primary_parent_id!=t.parent.object_id||!is_zero(t.checkpoint.secondary_parent_id)
      ||t.checkpoint.snapshot_id!=t.snapshot.object_id||t.checkpoint.closure_policy_digest!=closure_policy_sha()
      ||is_zero(t.checkpoint.display_label_digest)||t.checkpoint.created_ordinal==0||t.checkpoint.parent_count!=1
      ||t.checkpoint.checkpoint_id!=expected_checkpoint||t.checkpoint.record_id!=record_id(t.checkpoint)) return reject(Reason::checkpoint_record,stage,t);
  stage=3;
  if (!t.has_head_observation) { if(any_after(t,stage)) return reject(Reason::missing_predecessor,stage,t); Judgment j{};j.accepted=true;j.reason=Reason::accepted;j.durable_stage=stage;j.checkpoint_identity_valid=true;j.checkpoint_id=t.checkpoint.checkpoint_id;j.checkpoint_record_id=t.checkpoint.record_id;return j; }
  if(is_zero(t.head_observation.registry_incarnation)||t.head_observation.expected_head_checkpoint_id!=t.parent.object_id
      ||t.head_observation.observed_generation!=926||t.head_observation.observed_revision!=4100
      ||t.head_observation.observer_policy_digest!=branch_policy_sha()||t.head_observation.object_id!=object_id(t.head_observation)) return reject(Reason::head_observation,stage,t);
  stage=4;
  if (!t.has_head_update) { if(any_after(t,stage)) return reject(Reason::missing_predecessor,stage,t); Judgment j{};j.accepted=true;j.reason=Reason::accepted;j.durable_stage=stage;j.checkpoint_identity_valid=true;j.checkpoint_id=t.checkpoint.checkpoint_id;j.checkpoint_record_id=t.checkpoint.record_id;return j; }
  if(t.head_update.observation_id!=t.head_observation.object_id||t.head_update.registry_incarnation!=t.head_observation.registry_incarnation
      ||t.head_update.expected_old_checkpoint_id!=t.parent.object_id||t.head_update.new_checkpoint_id!=t.checkpoint.checkpoint_id
      ||t.head_update.new_generation!=t.head_observation.observed_generation+1||t.head_update.commit_revision<=t.head_observation.observed_revision
      ||t.head_update.result!=UpdateResult::applied||t.head_update.object_id!=object_id(t.head_update)) return reject(Reason::head_update,stage,t);
  stage=5;
  if (!t.has_transport) { if(any_after(t,stage)) return reject(Reason::missing_predecessor,stage,t); Judgment j{};j.accepted=true;j.reason=Reason::accepted;j.durable_stage=stage;j.checkpoint_identity_valid=true;j.local_head_selected=true;j.checkpoint_id=t.checkpoint.checkpoint_id;j.checkpoint_record_id=t.checkpoint.record_id;return j; }
  if(t.transport.checkpoint_id!=t.checkpoint.checkpoint_id||t.transport.checkpoint_record_id!=t.checkpoint.record_id
      ||is_zero(t.transport.archive_sha)||t.transport.archive_bytes==0||t.transport.manifest_rows==0||is_zero(t.transport.root_digest)
      ||is_zero(t.transport.archive_name_digest)||t.transport.no_replace!=1||t.transport.file_durable!=1||t.transport.directory_durable!=1
      ||t.transport.publication_revision<=t.head_update.commit_revision||t.transport.object_id!=object_id(t.transport)) return reject(Reason::transport_receipt,stage,t);
  stage=6;
  if (!t.has_reopen) { if(any_after(t,stage)) return reject(Reason::missing_predecessor,stage,t); Judgment j{};j.accepted=true;j.reason=Reason::accepted;j.durable_stage=stage;j.checkpoint_identity_valid=true;j.local_head_selected=true;j.checkpoint_id=t.checkpoint.checkpoint_id;j.checkpoint_record_id=t.checkpoint.record_id;return j; }
  if(t.reopen.transport_receipt_id!=t.transport.object_id||t.reopen.archive_sha!=t.transport.archive_sha
      ||t.reopen.extracted_root_digest!=t.transport.root_digest||is_zero(t.reopen.manifest_digest)||t.reopen.manifest_rows!=t.transport.manifest_rows
      ||t.reopen.reopener_implementation_digest!=reopener_sha()||t.reopen.result!=1||t.reopen.object_id!=object_id(t.reopen)) return reject(Reason::reopen_receipt,stage,t);
  stage=7;
  if (!t.has_branch) { if(any_after(t,stage)) return reject(Reason::missing_predecessor,stage,t); Judgment j{};j.accepted=true;j.reason=Reason::accepted;j.durable_stage=stage;j.checkpoint_identity_valid=true;j.local_head_selected=true;j.checkpoint_id=t.checkpoint.checkpoint_id;j.checkpoint_record_id=t.checkpoint.record_id;return j; }
  const auto expected_sibling=checkpoint_semantic_id(t.parent.object_id,{},t.branch.sibling_snapshot_id,closure_policy_sha(),1);
  const auto expected_class=expected_sibling==t.checkpoint.checkpoint_id?BranchClass::duplicate:BranchClass::fork;
  if(t.branch.common_parent_id!=t.parent.object_id||t.branch.selected_checkpoint_id!=t.checkpoint.checkpoint_id
      ||is_zero(t.branch.sibling_snapshot_id)||t.branch.sibling_checkpoint_id!=expected_sibling
      ||t.branch.sibling_record_id!=sibling_record_id(expected_sibling,t.branch.sibling_snapshot_id)
      ||t.branch.classification!=expected_class||t.branch.known_sibling_count!=1||t.branch.custody_policy_digest!=branch_policy_sha()
      ||t.branch.object_id!=object_id(t.branch)) return reject(Reason::branch_custody,stage,t);
  stage=8;
  if (!t.has_merge) { if(any_after(t,stage)) return reject(Reason::missing_predecessor,stage,t); Judgment j{};j.accepted=true;j.reason=Reason::accepted;j.durable_stage=stage;j.checkpoint_identity_valid=true;j.local_head_selected=true;j.duplicate_closure=t.branch.classification==BranchClass::duplicate;j.fork_detected=t.branch.classification==BranchClass::fork;j.checkpoint_id=t.checkpoint.checkpoint_id;j.checkpoint_record_id=t.checkpoint.record_id;return j; }
  if(t.branch.classification!=BranchClass::fork||t.merge.primary_parent_checkpoint_id!=t.checkpoint.checkpoint_id
      ||t.merge.secondary_parent_checkpoint_id!=t.branch.sibling_checkpoint_id||t.merge.primary_parent_checkpoint_id==t.merge.secondary_parent_checkpoint_id
      ||t.merge.primary_parent_reopen_receipt_id!=t.reopen.object_id||t.merge.secondary_parent_transport_receipt_id!=secondary_transport_id(t.branch)
      ||t.merge.secondary_parent_reopen_receipt_id!=secondary_reopen_id(t.branch)||is_zero(t.merge.resolution_digest)||is_zero(t.merge.merged_snapshot_id)
      ||t.merge.merge_policy_digest!=merge_policy_sha()||t.merge.parent_count!=2||t.merge.all_parents_reopened!=1) return reject(Reason::merge_record,stage,t);
  const auto expected_merge=checkpoint_semantic_id(t.merge.primary_parent_checkpoint_id,t.merge.secondary_parent_checkpoint_id,
                                                    t.merge.merged_snapshot_id,t.merge.merge_policy_digest,2);
  if(t.merge.merge_checkpoint_id!=expected_merge||t.merge.record_id!=merge_record_id(t.merge)) return reject(Reason::merge_record,stage,t);
  Judgment j{}; j.accepted=true;j.reason=Reason::accepted;j.durable_stage=9;j.checkpoint_identity_valid=true;j.local_head_selected=true;
  j.fork_detected=true;j.merge_candidate_ready=true;j.display_label_selects=false;j.global_lineage_unique=false;j.external_selection=false;j.owner_admission=false;
  j.checkpoint_id=t.checkpoint.checkpoint_id;j.checkpoint_record_id=t.checkpoint.record_id;j.merge_checkpoint_id=t.merge.merge_checkpoint_id; return j;
}

} // namespace slopos::e0::checkpoint_fork_identity
