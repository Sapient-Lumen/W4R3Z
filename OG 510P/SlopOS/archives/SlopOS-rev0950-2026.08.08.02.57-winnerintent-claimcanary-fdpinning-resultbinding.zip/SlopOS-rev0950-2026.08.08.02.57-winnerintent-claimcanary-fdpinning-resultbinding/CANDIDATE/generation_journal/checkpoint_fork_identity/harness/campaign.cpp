#include "slopos/e0/checkpoint_fork_identity/checkpoint_fork_identity.hpp"

#include <algorithm>
#include <array>
#include <cerrno>
#include <cstring>
#include <fcntl.h>
#include <filesystem>
#include <iostream>
#include <map>
#include <openssl/evp.h>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <sys/stat.h>
#include <unistd.h>
#include <utility>
#include <vector>

namespace slopos::e0::checkpoint_fork_identity {
namespace {
struct NamedCase { std::string name; Trace trace; };

Digest raw_sha(std::span<const std::uint8_t> bytes) {
  EVP_MD_CTX* context=EVP_MD_CTX_new(); if(context==nullptr) throw std::runtime_error("sha context");
  Digest out{}; unsigned int length=0;
  const bool ok=EVP_DigestInit_ex(context,EVP_sha256(),nullptr)==1
      &&(bytes.empty()||EVP_DigestUpdate(context,bytes.data(),bytes.size())==1)
      &&EVP_DigestFinal_ex(context,out.data(),&length)==1;
  EVP_MD_CTX_free(context); if(!ok||length!=out.size()) throw std::runtime_error("sha failure"); return out;
}
template<class T> void refresh_object(T& value,std::string_view domain) {
  value.object_id={}; const auto raw=serialize(value); value.object_id=digest_bytes(domain,raw);
}
void write_all(int fd,std::span<const std::uint8_t> bytes) {
  std::size_t offset=0;
  while(offset<bytes.size()) {
    const ssize_t written=::write(fd,bytes.data()+offset,bytes.size()-offset);
    if(written<0) { if(errno==EINTR) continue; throw std::runtime_error(std::string("write: ")+std::strerror(errno)); }
    if(written==0) throw std::runtime_error("short write");
    offset+=static_cast<std::size_t>(written);
  }
}
void write_file(const std::filesystem::path& path,std::span<const std::uint8_t> bytes) {
  const int fd=::open(path.c_str(),O_WRONLY|O_CREAT|O_EXCL|O_CLOEXEC,0644);
  if(fd<0) throw std::runtime_error(std::string("open ")+path.string()+": "+std::strerror(errno));
  try { write_all(fd,bytes); if(::fsync(fd)!=0) throw std::runtime_error("fsync file"); if(::close(fd)!=0) throw std::runtime_error("close file"); }
  catch(...) { ::close(fd); throw; }
}
void write_text(const std::filesystem::path& path,const std::string& text) {
  write_file(path,std::span<const std::uint8_t>(reinterpret_cast<const std::uint8_t*>(text.data()),text.size()));
}
void fsync_dir(const std::filesystem::path& path) {
  const int fd=::open(path.c_str(),O_RDONLY|O_DIRECTORY|O_CLOEXEC); if(fd<0) throw std::runtime_error("open directory");
  if(::fsync(fd)!=0){::close(fd);throw std::runtime_error("fsync directory");} if(::close(fd)!=0)throw std::runtime_error("close directory");
}

Trace invalid_later(std::uint64_t missing_stage) {
  Trace t=make_valid_trace();
  switch(missing_stage) {
    case 1:t.has_snapshot=false;break; case 2:t.has_checkpoint=false;break; case 3:t.has_head_observation=false;break;
    case 4:t.has_head_update=false;break; case 5:t.has_transport=false;break; case 6:t.has_reopen=false;break;
    case 7:t.has_branch=false;break; case 8:t.has_merge=false;break; default:t.has_parent=false;break;
  }
  return t;
}

std::vector<NamedCase> cases() {
  std::vector<NamedCase> out; std::set<std::string> names;
  auto add=[&](std::string name,Trace trace){if(!names.insert(name).second)throw std::runtime_error("duplicate case name");out.push_back({std::move(name),std::move(trace)});};
  const Trace base=make_valid_trace();
  for(std::uint64_t stage=1;stage<=9;++stage)add("valid_prefix_stage_"+std::to_string(stage),prefix(base,stage));
  {Trace t=base;t.physical_locator_digest=digest_text("/different/physical/root");add("physical_locator_does_not_select_identity",t);}
  {Trace t=base;t.checkpoint=make_checkpoint_record(t.parent,t.snapshot,"same-content-alternate-display-label");
   t.head_update=make_head_update(t.parent,t.checkpoint,t.head_observation);t.transport=make_transport_receipt(t.checkpoint,t.head_update);
   t.reopen=make_reopen_receipt(t.transport);t.branch=make_branch_custody(t.parent,t.checkpoint);t.merge=make_merge_record(t.checkpoint,t.reopen,t.branch);
   add("display_label_changes_record_not_checkpoint_identity",t);}
  {Trace t=base;t.branch=make_branch_custody(t.parent,t.checkpoint,"snapshot-a");t.has_merge=false;add("identical_closure_is_duplicate_not_fork",t);}

  auto mutate=[&](std::string name,auto fn){Trace t=base;fn(t);add(std::move(name),std::move(t));};
  mutate("parent_archive_digest_substitution",[](Trace&t){t.parent.archive_sha[0]^=1;});
  mutate("parent_archive_byte_count_substitution",[](Trace&t){++t.parent.archive_bytes;});
  mutate("parent_manifest_rows_substitution",[](Trace&t){++t.parent.manifest_rows;});
  mutate("parent_root_substitution",[](Trace&t){t.parent.root_digest[0]^=1;});
  mutate("parent_filename_substitution",[](Trace&t){t.parent.filename_digest[0]^=1;});
  mutate("parent_checkpoint_projection_substitution",[](Trace&t){t.parent.checkpoint_projection_digest[0]^=1;});
  mutate("parent_object_identity_substitution",[](Trace&t){t.parent.object_id[0]^=1;});
  mutate("source_snapshot_missing_digest",[](Trace&t){t.snapshot.snapshot_digest={};});
  mutate("source_snapshot_missing_logical_root",[](Trace&t){t.snapshot.logical_root_digest={};});
  mutate("source_snapshot_missing_repository",[](Trace&t){t.snapshot.repository_digest={};});
  mutate("source_snapshot_missing_proof_projection",[](Trace&t){t.snapshot.proof_projection_digest={};});
  mutate("source_snapshot_policy_substitution",[](Trace&t){t.snapshot.closure_policy_digest[0]^=1;});
  mutate("source_snapshot_zero_manifest_rows",[](Trace&t){t.snapshot.manifest_rows=0;});
  mutate("source_snapshot_object_identity_substitution",[](Trace&t){t.snapshot.object_id[0]^=1;});
  mutate("checkpoint_wrong_primary_parent",[](Trace&t){t.checkpoint.primary_parent_id[0]^=1;});
  mutate("ordinary_checkpoint_has_secondary_parent",[](Trace&t){t.checkpoint.secondary_parent_id=digest_text("unexpected-secondary");});
  mutate("ordinary_checkpoint_claims_two_parents",[](Trace&t){t.checkpoint.parent_count=2;});
  mutate("checkpoint_wrong_snapshot",[](Trace&t){t.checkpoint.snapshot_id[0]^=1;});
  mutate("checkpoint_wrong_policy",[](Trace&t){t.checkpoint.closure_policy_digest[0]^=1;});
  mutate("checkpoint_empty_display_label",[](Trace&t){t.checkpoint.display_label_digest={};});
  mutate("checkpoint_zero_created_ordinal",[](Trace&t){t.checkpoint.created_ordinal=0;});
  mutate("checkpoint_semantic_identity_substitution",[](Trace&t){t.checkpoint.checkpoint_id[0]^=1;});
  mutate("checkpoint_record_identity_substitution",[](Trace&t){t.checkpoint.record_id[0]^=1;});
  mutate("display_label_changed_without_record_rebind",[](Trace&t){t.checkpoint.display_label_digest=digest_text("different-label");});
  mutate("head_observation_zero_incarnation",[](Trace&t){t.head_observation.registry_incarnation={};});
  mutate("head_observation_wrong_expected_head",[](Trace&t){t.head_observation.expected_head_checkpoint_id[0]^=1;});
  mutate("head_observation_wrong_generation",[](Trace&t){++t.head_observation.observed_generation;});
  mutate("head_observation_wrong_revision",[](Trace&t){++t.head_observation.observed_revision;});
  mutate("head_observation_policy_substitution",[](Trace&t){t.head_observation.observer_policy_digest[0]^=1;});
  mutate("head_observation_identity_substitution",[](Trace&t){t.head_observation.object_id[0]^=1;});
  mutate("head_update_wrong_observation",[](Trace&t){t.head_update.observation_id[0]^=1;});
  mutate("head_update_wrong_registry",[](Trace&t){t.head_update.registry_incarnation[0]^=1;});
  mutate("head_update_wrong_old_head",[](Trace&t){t.head_update.expected_old_checkpoint_id[0]^=1;});
  mutate("head_update_wrong_new_checkpoint",[](Trace&t){t.head_update.new_checkpoint_id[0]^=1;});
  mutate("head_update_skips_generation",[](Trace&t){++t.head_update.new_generation;});
  mutate("head_update_nonmonotone_revision",[](Trace&t){t.head_update.commit_revision=t.head_observation.observed_revision;});
  mutate("head_update_conflict_is_not_selected",[](Trace&t){t.head_update.result=UpdateResult::conflict;});
  mutate("head_update_identity_substitution",[](Trace&t){t.head_update.object_id[0]^=1;});
  mutate("transport_wrong_checkpoint",[](Trace&t){t.transport.checkpoint_id[0]^=1;});
  mutate("transport_wrong_checkpoint_record",[](Trace&t){t.transport.checkpoint_record_id[0]^=1;});
  mutate("transport_missing_archive_digest",[](Trace&t){t.transport.archive_sha={};});
  mutate("transport_zero_bytes",[](Trace&t){t.transport.archive_bytes=0;});
  mutate("transport_zero_manifest_rows",[](Trace&t){t.transport.manifest_rows=0;});
  mutate("transport_missing_root",[](Trace&t){t.transport.root_digest={};});
  mutate("transport_missing_filename",[](Trace&t){t.transport.archive_name_digest={};});
  mutate("transport_allows_replace",[](Trace&t){t.transport.no_replace=0;});
  mutate("transport_file_not_durable",[](Trace&t){t.transport.file_durable=0;});
  mutate("transport_directory_not_durable",[](Trace&t){t.transport.directory_durable=0;});
  mutate("transport_precedes_head_update",[](Trace&t){t.transport.publication_revision=t.head_update.commit_revision;});
  mutate("transport_identity_substitution",[](Trace&t){t.transport.object_id[0]^=1;});
  mutate("reopen_wrong_transport",[](Trace&t){t.reopen.transport_receipt_id[0]^=1;});
  mutate("reopen_wrong_archive",[](Trace&t){t.reopen.archive_sha[0]^=1;});
  mutate("reopen_wrong_root",[](Trace&t){t.reopen.extracted_root_digest[0]^=1;});
  mutate("reopen_missing_manifest_digest",[](Trace&t){t.reopen.manifest_digest={};});
  mutate("reopen_wrong_manifest_rows",[](Trace&t){++t.reopen.manifest_rows;});
  mutate("reopen_implementation_substitution",[](Trace&t){t.reopen.reopener_implementation_digest[0]^=1;});
  mutate("reopen_result_false",[](Trace&t){t.reopen.result=0;});
  mutate("reopen_identity_substitution",[](Trace&t){t.reopen.object_id[0]^=1;});
  mutate("branch_wrong_common_parent",[](Trace&t){t.branch.common_parent_id[0]^=1;});
  mutate("branch_wrong_selected_checkpoint",[](Trace&t){t.branch.selected_checkpoint_id[0]^=1;});
  mutate("branch_missing_sibling_snapshot",[](Trace&t){t.branch.sibling_snapshot_id={};});
  mutate("branch_wrong_sibling_checkpoint",[](Trace&t){t.branch.sibling_checkpoint_id[0]^=1;});
  mutate("branch_wrong_sibling_record",[](Trace&t){t.branch.sibling_record_id[0]^=1;});
  mutate("branch_calls_distinct_sibling_duplicate",[](Trace&t){t.branch.classification=BranchClass::duplicate;});
  mutate("branch_wrong_known_sibling_count",[](Trace&t){t.branch.known_sibling_count=2;});
  mutate("branch_policy_substitution",[](Trace&t){t.branch.custody_policy_digest[0]^=1;});
  mutate("branch_identity_substitution",[](Trace&t){t.branch.object_id[0]^=1;});
  {Trace t=base;t.branch=make_branch_custody(t.parent,t.checkpoint,"snapshot-a");t.branch.classification=BranchClass::fork;refresh_object(t.branch,"SlopOS/rev0927/checkpoint-fork-identity/branch-custody/v1");t.has_merge=false;add("identical_checkpoint_mislabeled_as_fork",t);}
  mutate("merge_primary_parent_substitution",[](Trace&t){t.merge.primary_parent_checkpoint_id[0]^=1;});
  mutate("merge_secondary_parent_substitution",[](Trace&t){t.merge.secondary_parent_checkpoint_id[0]^=1;});
  mutate("merge_duplicate_parent",[](Trace&t){t.merge.secondary_parent_checkpoint_id=t.merge.primary_parent_checkpoint_id;});
  mutate("merge_wrong_primary_reopen",[](Trace&t){t.merge.primary_parent_reopen_receipt_id[0]^=1;});
  mutate("merge_wrong_secondary_transport",[](Trace&t){t.merge.secondary_parent_transport_receipt_id[0]^=1;});
  mutate("merge_wrong_secondary_reopen",[](Trace&t){t.merge.secondary_parent_reopen_receipt_id[0]^=1;});
  mutate("merge_missing_resolution",[](Trace&t){t.merge.resolution_digest={};});
  mutate("merge_missing_snapshot",[](Trace&t){t.merge.merged_snapshot_id={};});
  mutate("merge_policy_substitution",[](Trace&t){t.merge.merge_policy_digest[0]^=1;});
  mutate("merge_claims_one_parent",[](Trace&t){t.merge.parent_count=1;});
  mutate("merge_parent_not_reopened",[](Trace&t){t.merge.all_parents_reopened=0;});
  mutate("merge_checkpoint_identity_substitution",[](Trace&t){t.merge.merge_checkpoint_id[0]^=1;});
  mutate("merge_record_identity_substitution",[](Trace&t){t.merge.record_id[0]^=1;});

  add("checkpoint_without_snapshot",invalid_later(1));
  add("head_observation_without_checkpoint",invalid_later(2));
  add("head_update_without_observation",invalid_later(3));
  add("transport_without_head_update",invalid_later(4));
  add("reopen_without_transport",invalid_later(5));
  add("branch_without_reopen",invalid_later(6));
  add("merge_without_branch",invalid_later(7));
  return out;
}

std::string bool_text(bool value){return value?"true":"false";}

template<std::size_t N> void emit_binary(const std::filesystem::path& output,const char* name,const std::array<std::uint8_t,N>& bytes,std::ostringstream& identities){
  write_file(output/name,bytes);identities<<name<<'\t'<<N<<'\t'<<hex(raw_sha(bytes))<<'\n';
}
}

int run_campaign(const std::filesystem::path& output) {
  try {
    if(std::filesystem::exists(output)) throw std::runtime_error("output root already exists");
    if(!std::filesystem::create_directory(output)) throw std::runtime_error("create output root");
    const auto all=cases();
    std::size_t accepted=0,rejected=0,disagreements=0,duplicate_ready=0,fork_ready=0,merge_ready=0;
    std::vector<std::string> disagreement_details;
    std::map<Reason,std::size_t> reasons;
    std::ostringstream case_rows;case_rows<<"case\taccepted\treason\tstage\tcheckpoint_id\trecord_id\tlocal_head_selected\tduplicate_closure\tfork_detected\tmerge_ready\tglobal_lineage_unique\tauthority\n";
    std::ostringstream cut_rows;cut_rows<<"case\tcut\taccepted\treason\tstage\n";
    for(const auto& item:all){
      const Judgment a=evaluate_candidate(item.trace),b=evaluate_reference(item.trace);
      if(a.accepted!=b.accepted||a.reason!=b.reason||a.durable_stage!=b.durable_stage||a.checkpoint_identity_valid!=b.checkpoint_identity_valid
         ||a.local_head_selected!=b.local_head_selected||a.duplicate_closure!=b.duplicate_closure||a.fork_detected!=b.fork_detected
         ||a.merge_candidate_ready!=b.merge_candidate_ready||a.global_lineage_unique!=b.global_lineage_unique
         ||a.external_selection!=b.external_selection||a.owner_admission!=b.owner_admission||a.checkpoint_id!=b.checkpoint_id
         ||a.checkpoint_record_id!=b.checkpoint_record_id||a.merge_checkpoint_id!=b.merge_checkpoint_id) {
        ++disagreements;
        if(disagreement_details.size()<12) disagreement_details.push_back(item.name+":"+reason_name(a.reason)+"/"+reason_name(b.reason)+":"+std::to_string(a.durable_stage)+"/"+std::to_string(b.durable_stage));
      }
      if(a.accepted)++accepted;else++rejected;++reasons[a.reason];if(a.duplicate_closure)++duplicate_ready;if(a.fork_detected)++fork_ready;if(a.merge_candidate_ready)++merge_ready;
      case_rows<<item.name<<'\t'<<bool_text(a.accepted)<<'\t'<<reason_name(a.reason)<<'\t'<<a.durable_stage<<'\t'
        <<hex(a.checkpoint_id)<<'\t'<<hex(a.checkpoint_record_id)<<'\t'<<bool_text(a.local_head_selected)<<'\t'
        <<bool_text(a.duplicate_closure)<<'\t'<<bool_text(a.fork_detected)<<'\t'<<bool_text(a.merge_candidate_ready)
        <<"\tfalse\tfalse\n";
      for(std::uint64_t cut=1;cut<=9;++cut){const Trace p=prefix(item.trace,cut);const Judgment ca=evaluate_candidate(p),cr=evaluate_reference(p);if(ca.accepted!=cr.accepted||ca.reason!=cr.reason||ca.durable_stage!=cr.durable_stage){++disagreements;if(disagreement_details.size()<12)disagreement_details.push_back(item.name+"@"+std::to_string(cut)+":"+reason_name(ca.reason)+"/"+reason_name(cr.reason)+":"+std::to_string(ca.durable_stage)+"/"+std::to_string(cr.durable_stage));}cut_rows<<item.name<<'\t'<<cut<<'\t'<<bool_text(ca.accepted)<<'\t'<<reason_name(ca.reason)<<'\t'<<ca.durable_stage<<'\n';}
    }
    if(disagreements!=0){std::ostringstream d;d<<"candidate/reference disagreement count="<<disagreements;for(const auto&x:disagreement_details)d<<" "<<x;throw std::runtime_error(d.str());}
    if(all.size()<80||accepted<10||rejected<60||merge_ready<1){std::ostringstream c;c<<"campaign coverage invariant cases="<<all.size()<<" accepted="<<accepted<<" rejected="<<rejected<<" merge_ready="<<merge_ready;throw std::runtime_error(c.str());}

    const Trace valid=make_valid_trace();
    std::ostringstream identities;identities<<"object\tbytes\tsha256\n";
    emit_binary(output,"PARENT-TRANSPORT-BINDING.bin",serialize(valid.parent),identities);
    emit_binary(output,"SOURCE-SNAPSHOT.bin",serialize(valid.snapshot),identities);
    emit_binary(output,"CHECKPOINT-RECORD.bin",serialize(valid.checkpoint),identities);
    emit_binary(output,"HEAD-OBSERVATION.bin",serialize(valid.head_observation),identities);
    emit_binary(output,"HEAD-UPDATE-RECEIPT.bin",serialize(valid.head_update),identities);
    emit_binary(output,"TRANSPORT-RECEIPT.bin",serialize(valid.transport),identities);
    emit_binary(output,"REOPEN-RECEIPT.bin",serialize(valid.reopen),identities);
    emit_binary(output,"BRANCH-CUSTODY.bin",serialize(valid.branch),identities);
    emit_binary(output,"MERGE-RECORD.bin",serialize(valid.merge),identities);
    write_text(output/"CASES.tsv",case_rows.str());write_text(output/"CUTS.tsv",cut_rows.str());
    write_text(output/"IDENTITIES.tsv",identities.str());

    std::ostringstream forks;forks<<"scenario\tclassification\tselected_by_label_or_time\tglobal_unique\n"
      <<"same_parent_same_snapshot_same_policy\tDUPLICATE\tfalse\tfalse\n"
      <<"same_parent_distinct_snapshot_same_label\tFORK\tfalse\tfalse\n"
      <<"same_parent_distinct_snapshot_later_timestamp\tFORK\tfalse\tfalse\n"
      <<"same_snapshot_distinct_parent\tDISTINCT_CHECKPOINT\tfalse\tfalse\n"
      <<"one_registry_two_compare_updates\tONE_LOCAL_APPLIED_ONE_CONFLICT\tfalse\tfalse\n"
      <<"registry_cloned_before_update\tBOTH_LOCAL_APPLIED\tfalse\tfalse\n"
      <<"workspace_renamed\tSAME_CHECKPOINT_ID\tfalse\tfalse\n"
      <<"display_label_changed\tSAME_CHECKPOINT_ID_DIFFERENT_RECORD\tfalse\tfalse\n"
      <<"preseal_workspace_vs_transport\tDISTINCT_SUBJECTS\tfalse\tfalse\n"
      <<"unknown_sibling_not_listed\tCUSTODY_INCOMPLETE\tfalse\tfalse\n"
      <<"later_wall_clock_only\tNO_SELECTION\tfalse\tfalse\n"
      <<"human_revision_only\tNO_ANCESTRY_IDENTITY\tfalse\tfalse\n";
    write_text(output/"FORKS.tsv",forks.str());
    std::ostringstream merges;merges<<"scenario\taccepted\treason\n"
      <<"exact_two_parent_resolution\ttrue\tMERGE_CANDIDATE\n"
      <<"same_revision_label_only\tfalse\tNO_PARENT_IDENTITIES\n"
      <<"one_parent_named\tfalse\tPARENT_SET_INCOMPLETE\n"
      <<"duplicate_parent_named_twice\tfalse\tNOT_A_MERGE\n"
      <<"secondary_transport_not_reopened\tfalse\tPARENT_NOT_REOPENED\n"
      <<"resolution_digest_missing\tfalse\tNO_RESOLUTION_SUBJECT\n"
      <<"merged_snapshot_missing\tfalse\tNO_MERGED_CONTENT\n"
      <<"sibling_laws_copied_only\tfalse\tSOURCE_NOT_MERGED\n"
      <<"merge_candidate_without_head_cas\tfalse\tNOT_SELECTED\n"
      <<"hosted_merge_called_owner_admitted\tfalse\tAUTHORITY_NONDERIVATION\n";
    write_text(output/"MERGES.tsv",merges.str());
    std::ostringstream laws;laws<<"law\tstatement\n"
      <<"CFI01\tRevision labels are display metadata not ancestry identity.\n"
      <<"CFI02\tCheckpoint identity binds exact parent set logical snapshot and closure policy.\n"
      <<"CFI03\tRepresentation record identity separately binds display metadata.\n"
      <<"CFI04\tSame semantic inputs produce one duplicate checkpoint identity.\n"
      <<"CFI05\tDistinct semantic children of one parent are siblings even when labels match.\n"
      <<"CFI06\tWall-clock order cannot select lineage.\n"
      <<"CFI07\tPhysical workspace paths do not select checkpoint identity.\n"
      <<"CFI08\tWorkspace and published transport are distinct subjects.\n"
      <<"CFI09\tLocal compare-and-update rejects one concurrent child in one coherent registry.\n"
      <<"CFI10\tA cloned registry can accept both children locally; global uniqueness remains false.\n"
      <<"CFI11\tBranch custody binds known siblings and does not prove no unknown sibling exists.\n"
      <<"CFI12\tA merge names every exact parent checkpoint.\n"
      <<"CFI13\tA merge binds an exact resolution digest and merged source snapshot.\n"
      <<"CFI14\tEvery merge parent requires an exact transport and reopen receipt.\n"
      <<"CFI15\tCopying sibling laws is not source or evidence merge.\n"
      <<"CFI16\tA merge candidate is not a globally selected head.\n"
      <<"CFI17\tNo-replace file durability and directory durability are separate transport facts.\n"
      <<"CFI18\tA closed record without transport and reopen is not a sealed checkpoint.\n"
      <<"CFI19\tContent identity improves custody but does not constitute owners.\n"
      <<"CFI20\tEpoch-Zero preservation may refine lineage without fabricating V14 operation.\n";
    write_text(output/"LAWS.tsv",laws.str());
    std::ostringstream cms;cms<<"countermodel\tconstruction\tfalse_inference\n"
      <<"same_label_siblings\tTwo distinct snapshots share one parent and display label.\tThe label identifies one revision.\n"
      <<"later_timestamp_selection\tA sibling closes later by wall clock.\tLater time makes it descendant or winner.\n"
      <<"preseal_path_substitution\tA convenient final-named workspace differs from the linked ZIP.\tMatching root name proves lineage.\n"
      <<"cloned_registry_double_accept\tTwo registry clones begin at one head and each compare-append a different child.\tLocal CAS proves global single successor.\n"
      <<"record_id_as_checkpoint_id\tA display label changes while semantic parents and snapshot stay fixed.\tEvery record byte change is a new semantic checkpoint.\n"
      <<"checkpoint_id_as_transport\tA valid checkpoint record has no published archive.\tCheckpoint identity proves sealed transport possession.\n"
      <<"known_sibling_set_complete\tA custody packet lists two known children.\tNo other sibling exists.\n"
      <<"copied_laws_merge\tA successor copies distilled laws from a sibling but not its source or evidence.\tThe sibling was merged.\n"
      <<"one_parent_merge\tA record says merge while naming one parent.\tThe word merge establishes reconciliation.\n"
      <<"unreopened_secondary\tA merge names a secondary digest without possessing and reopening its transport.\tDigest mention proves parent admission.\n"
      <<"hosted_head_as_owner_selection\tA local office ref selects one child.\tConstituted owners selected living lineage.\n"
      <<"fork_id_as_global_floor\tExact sibling identities are retained.\tRollback clone or hidden fork is excluded.\n";
    write_text(output/"COUNTERMODELS.tsv",cms.str());

    const std::size_t cuts=all.size()*9;
    std::ostringstream summary;summary<<"metric\tvalue\n"<<"cases\t"<<all.size()<<'\n'<<"accepted\t"<<accepted<<'\n'<<"rejected\t"<<rejected<<'\n'
      <<"lifecycle_cuts\t"<<cuts<<'\n'<<"durable_stages\t9\n"<<"canonical_objects\t9\n"<<"canonical_exact_object_bytes\t2880\n"
      <<"fork_scenarios\t12\n"<<"merge_scenarios\t10\n"<<"duplicate_ready\t"<<duplicate_ready<<'\n'<<"fork_ready\t"<<fork_ready<<'\n'
      <<"merge_ready\t"<<merge_ready<<'\n'<<"candidate_reference_disagreements\t0\n"<<"display_label_selects\tfalse\n"
      <<"physical_locator_selects\tfalse\n"<<"local_head_compare_update\ttrue\n"<<"global_lineage_unique\tfalse\n"
      <<"unknown_siblings_excluded\tfalse\n"<<"owner_admission\tfalse\n"<<"authority\tfalse\n"<<"epoch_exit\tfalse\n";
    write_text(output/"SUMMARY.tsv",summary.str());
    std::ostringstream report;report<<"CHECKPOINT_FORK_IDENTITY_CAMPAIGN=PASS cases="<<all.size()<<" accepted="<<accepted<<" rejected="<<rejected
      <<" cuts="<<cuts<<" stages=9 fork_scenarios=12 merge_scenarios=10 disagreements=0 label_selects=false locator_selects=false local_cas=true global_unique=false authority=false epoch_exit=false\n";
    write_text(output/"REPORT.txt",report.str());
    fsync_dir(output);
    std::cout<<report.str();return 0;
  } catch(const std::exception& error) {
    std::cerr<<"CHECKPOINT_FORK_IDENTITY_CAMPAIGN=FAIL detail="<<error.what()<<'\n';return 1;
  }
}
}
