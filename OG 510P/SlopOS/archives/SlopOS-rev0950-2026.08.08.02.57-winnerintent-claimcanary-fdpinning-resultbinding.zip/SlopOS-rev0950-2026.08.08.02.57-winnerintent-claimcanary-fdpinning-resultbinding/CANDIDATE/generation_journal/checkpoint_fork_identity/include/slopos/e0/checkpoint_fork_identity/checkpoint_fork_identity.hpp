#pragma once
#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <span>
#include <string>
#include <string_view>
#include <vector>

namespace slopos::e0::checkpoint_fork_identity {
using Digest = std::array<std::uint8_t, 32>;

enum class BranchClass : std::uint64_t { none = 0, duplicate = 1, fork = 2 };
enum class UpdateResult : std::uint64_t { none = 0, applied = 1, conflict = 2 };
enum class Reason : std::uint64_t {
  accepted = 0, missing_predecessor, parent_binding, source_snapshot, checkpoint_record,
  head_observation, head_update, transport_receipt, reopen_receipt, branch_custody,
  merge_record, impossible_history
};

struct ParentBinding {
  Digest archive_sha{}; std::uint64_t archive_bytes{}; std::uint64_t manifest_rows{};
  Digest root_digest{}; Digest filename_digest{}; Digest checkpoint_projection_digest{};
  Digest object_id{};
};
struct SourceSnapshot {
  Digest snapshot_digest{}; Digest logical_root_digest{}; Digest repository_digest{};
  Digest proof_projection_digest{}; Digest closure_policy_digest{};
  std::uint64_t manifest_rows{}; Digest object_id{};
};
struct CheckpointRecord {
  Digest schema_digest{}; Digest primary_parent_id{}; Digest secondary_parent_id{};
  Digest snapshot_id{}; Digest closure_policy_digest{}; Digest display_label_digest{};
  std::uint64_t created_ordinal{}; std::uint64_t parent_count{};
  Digest checkpoint_id{}; Digest record_id{};
};
struct HeadObservation {
  Digest registry_incarnation{}; Digest expected_head_checkpoint_id{};
  std::uint64_t observed_generation{}; std::uint64_t observed_revision{};
  Digest observer_policy_digest{}; Digest object_id{};
};
struct HeadUpdateReceipt {
  Digest observation_id{}; Digest registry_incarnation{}; Digest expected_old_checkpoint_id{};
  Digest new_checkpoint_id{}; std::uint64_t new_generation{}; std::uint64_t commit_revision{};
  UpdateResult result{UpdateResult::none}; Digest object_id{};
};
struct TransportReceipt {
  Digest checkpoint_id{}; Digest checkpoint_record_id{}; Digest archive_sha{};
  std::uint64_t archive_bytes{}; std::uint64_t manifest_rows{}; Digest root_digest{};
  Digest archive_name_digest{}; std::uint64_t no_replace{}; std::uint64_t file_durable{};
  std::uint64_t directory_durable{}; std::uint64_t publication_revision{}; Digest object_id{};
};
struct ReopenReceipt {
  Digest transport_receipt_id{}; Digest archive_sha{}; Digest extracted_root_digest{};
  Digest manifest_digest{}; std::uint64_t manifest_rows{}; Digest reopener_implementation_digest{};
  std::uint64_t result{}; Digest object_id{};
};
struct BranchCustody {
  Digest common_parent_id{}; Digest selected_checkpoint_id{}; Digest sibling_snapshot_id{};
  Digest sibling_checkpoint_id{}; Digest sibling_record_id{}; BranchClass classification{BranchClass::none};
  std::uint64_t known_sibling_count{}; Digest custody_policy_digest{}; Digest object_id{};
};
struct MergeRecord {
  Digest primary_parent_checkpoint_id{}; Digest secondary_parent_checkpoint_id{};
  Digest primary_parent_reopen_receipt_id{}; Digest secondary_parent_transport_receipt_id{};
  Digest secondary_parent_reopen_receipt_id{}; Digest resolution_digest{};
  Digest merged_snapshot_id{}; Digest merge_policy_digest{}; std::uint64_t parent_count{};
  std::uint64_t all_parents_reopened{}; Digest merge_checkpoint_id{}; Digest record_id{};
};
struct Trace {
  bool has_parent{}, has_snapshot{}, has_checkpoint{}, has_head_observation{}, has_head_update{};
  bool has_transport{}, has_reopen{}, has_branch{}, has_merge{};
  ParentBinding parent{}; SourceSnapshot snapshot{}; CheckpointRecord checkpoint{};
  HeadObservation head_observation{}; HeadUpdateReceipt head_update{};
  TransportReceipt transport{}; ReopenReceipt reopen{}; BranchCustody branch{}; MergeRecord merge{};
  Digest physical_locator_digest{};
};
struct Judgment {
  bool accepted{}; Reason reason{Reason::impossible_history}; std::uint64_t durable_stage{};
  bool checkpoint_identity_valid{}; bool display_label_selects{}; bool local_head_selected{};
  bool duplicate_closure{}; bool fork_detected{}; bool merge_candidate_ready{};
  bool global_lineage_unique{}; bool external_selection{}; bool owner_admission{};
  Digest checkpoint_id{}; Digest checkpoint_record_id{}; Digest merge_checkpoint_id{};
};

constexpr std::size_t parent_bytes = 256, snapshot_bytes = 256, checkpoint_bytes = 352;
constexpr std::size_t head_observation_bytes = 256, head_update_bytes = 320;
constexpr std::size_t transport_bytes = 352, reopen_bytes = 320, branch_bytes = 352, merge_bytes = 416;

Digest digest_text(std::string_view text);
Digest digest_bytes(std::string_view domain, std::span<const std::uint8_t> bytes);
bool is_zero(const Digest& value);
std::string hex(const Digest& value);
std::string reason_name(Reason reason);
std::string branch_name(BranchClass value);

ParentBinding make_parent_binding();
SourceSnapshot make_source_snapshot(std::string_view label = "snapshot-a");
CheckpointRecord make_checkpoint_record(const ParentBinding&, const SourceSnapshot&, std::string_view label = "rev0927");
HeadObservation make_head_observation(const ParentBinding&);
HeadUpdateReceipt make_head_update(const ParentBinding&, const CheckpointRecord&, const HeadObservation&);
TransportReceipt make_transport_receipt(const CheckpointRecord&, const HeadUpdateReceipt&);
ReopenReceipt make_reopen_receipt(const TransportReceipt&);
BranchCustody make_branch_custody(const ParentBinding&, const CheckpointRecord&, std::string_view sibling_label = "snapshot-b");
MergeRecord make_merge_record(const CheckpointRecord&, const ReopenReceipt&, const BranchCustody&);
Trace make_valid_trace();
Trace prefix(const Trace&, std::uint64_t stage);

std::array<std::uint8_t, parent_bytes> serialize(const ParentBinding&);
std::array<std::uint8_t, snapshot_bytes> serialize(const SourceSnapshot&);
std::array<std::uint8_t, checkpoint_bytes> serialize(const CheckpointRecord&);
std::array<std::uint8_t, head_observation_bytes> serialize(const HeadObservation&);
std::array<std::uint8_t, head_update_bytes> serialize(const HeadUpdateReceipt&);
std::array<std::uint8_t, transport_bytes> serialize(const TransportReceipt&);
std::array<std::uint8_t, reopen_bytes> serialize(const ReopenReceipt&);
std::array<std::uint8_t, branch_bytes> serialize(const BranchCustody&);
std::array<std::uint8_t, merge_bytes> serialize(const MergeRecord&);

Judgment evaluate_candidate(const Trace&);
Judgment evaluate_reference(const Trace&);
int run_campaign(const std::filesystem::path& output);
}
