# Checkpoint Fork Identity and Merge Fence V1

This is an Epoch-Zero preservation refinement inside the existing
`generation_journal` semantic island. It does not operate External Ceremony V14
and does not extend the authority chain. It closes a lineage-addressability
blocker already named by O67: a human revision label, timestamp, or convenient
workspace path cannot identify ancestry when concurrent or repeated closes
exist.

The relation separates:

- semantic checkpoint identity: exact parent set + logical snapshot + closure policy;
- representation record identity: semantic identity + display metadata;
- local head selection: one compare-and-update in one coherent registry;
- transport closure: exact archive, root, manifest, no-replace and durability receipt;
- independent hosted reopen;
- branch custody: exact known sibling identities under one parent; and
- merge candidature: every exact parent, every parent reopen, one resolution
  digest, and one merged logical snapshot.

It deliberately keeps global lineage uniqueness, exclusion of unknown siblings,
external selection, owner admission, authority, and Epoch-Zero exit false. A
registry cloned before local head update can accept two different children.

Builds are retained under `EVIDENCE/REV0927/CHECKPOINT-FORK-IDENTITY` and are
reopened by `proof/reopen_checkpoint_fork_identity.py` without calling the C++
serializers.
