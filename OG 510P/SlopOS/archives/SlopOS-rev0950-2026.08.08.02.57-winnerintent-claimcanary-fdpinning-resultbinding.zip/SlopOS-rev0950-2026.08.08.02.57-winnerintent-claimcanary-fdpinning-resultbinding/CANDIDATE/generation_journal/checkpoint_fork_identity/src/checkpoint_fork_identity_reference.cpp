#include "slopos/e0/checkpoint_fork_identity/checkpoint_fork_identity.hpp"

#include <algorithm>
#include <stdexcept>
#include <string_view>
#include <vector>

namespace slopos::e0::checkpoint_fork_identity {
namespace {
Digest parse_hex(std::string_view text) {
  if (text.size()!=64) throw std::runtime_error("reference digest length");
  Digest out{};
  auto n=[](char c)->std::uint8_t { if(c>='0'&&c<='9')return static_cast<std::uint8_t>(c-'0'); if(c>='a'&&c<='f')return static_cast<std::uint8_t>(10+c-'a'); throw std::runtime_error("reference digest hex"); };
  for(std::size_t i=0;i<32;++i) out[i]=static_cast<std::uint8_t>((n(text[2*i])<<4U)|n(text[2*i+1]));
  return out;
}
const Digest& p_archive(){static const Digest v=parse_hex(SLOPOS_CFI_PARENT_ARCHIVE_SHA256_HEX);return v;}
const Digest& p_root(){static const Digest v=parse_hex(SLOPOS_CFI_PARENT_ROOT_SHA256_HEX);return v;}
const Digest& p_file(){static const Digest v=parse_hex(SLOPOS_CFI_PARENT_FILENAME_SHA256_HEX);return v;}
const Digest& p_checkpoint(){static const Digest v=parse_hex(SLOPOS_CFI_PARENT_CHECKPOINT_SHA256_HEX);return v;}
const Digest& closure(){static const Digest v=parse_hex(SLOPOS_CFI_CLOSURE_POLICY_SHA256_HEX);return v;}
const Digest& branch_policy(){static const Digest v=parse_hex(SLOPOS_CFI_BRANCH_POLICY_SHA256_HEX);return v;}
const Digest& merge_policy(){static const Digest v=parse_hex(SLOPOS_CFI_MERGE_POLICY_SHA256_HEX);return v;}
const Digest& reopener(){static const Digest v=parse_hex(SLOPOS_CFI_REOPENER_IMPLEMENTATION_SHA256_HEX);return v;}
void add(std::vector<std::uint8_t>& v,const Digest& d){v.insert(v.end(),d.begin(),d.end());}
void add(std::vector<std::uint8_t>& v,std::uint64_t x){for(std::size_t i=0;i<8;++i)v.push_back(static_cast<std::uint8_t>((x>>(8U*i))&0xffU));}
Digest semantic(const Digest&a,const Digest&b,const Digest&s,const Digest&p,std::uint64_t count){std::vector<std::uint8_t> v;add(v,digest_text("slopos.checkpoint-fork-identity.checkpoint-schema.v1"));add(v,a);add(v,b);add(v,s);add(v,p);add(v,count);return digest_bytes("SlopOS/rev0927/checkpoint-fork-identity/checkpoint-id/v1",v);}
Digest sibling_record(const Digest&a,const Digest&b){std::vector<std::uint8_t>v;add(v,a);add(v,b);return digest_bytes("SlopOS/rev0927/checkpoint-fork-identity/sibling-record/v1",v);}
Digest secondary_transport(const BranchCustody& b){std::vector<std::uint8_t>v;add(v,b.sibling_checkpoint_id);add(v,b.object_id);return digest_bytes("SlopOS/rev0927/checkpoint-fork-identity/secondary-transport/v1",v);}
Digest secondary_reopen(const BranchCustody& b){std::vector<std::uint8_t>v;add(v,secondary_transport(b));add(v,reopener());return digest_bytes("SlopOS/rev0927/checkpoint-fork-identity/secondary-reopen/v1",v);}
template<class T> Digest oid(T value,std::string_view domain){value.object_id={};const auto raw=serialize(value);return digest_bytes(domain,raw);}
Digest rid(CheckpointRecord value){value.record_id={};return digest_bytes("SlopOS/rev0927/checkpoint-fork-identity/checkpoint-record/v1",serialize(value));}
Digest mrid(MergeRecord value){value.record_id={};return digest_bytes("SlopOS/rev0927/checkpoint-fork-identity/merge-record/v1",serialize(value));}
Judgment no(Reason r,std::uint64_t stage,const Trace&t){Judgment j{};j.reason=r;j.durable_stage=stage;j.checkpoint_id=t.checkpoint.checkpoint_id;j.checkpoint_record_id=t.checkpoint.record_id;j.merge_checkpoint_id=t.merge.merge_checkpoint_id;return j;}
Judgment yes(std::uint64_t stage,const Trace&t){
  Judgment j{};
  j.accepted=true; j.reason=Reason::accepted; j.durable_stage=stage;
  j.display_label_selects=false; j.global_lineage_unique=false; j.external_selection=false; j.owner_admission=false;
  if(stage>=3){j.checkpoint_identity_valid=true;j.checkpoint_id=t.checkpoint.checkpoint_id;j.checkpoint_record_id=t.checkpoint.record_id;}
  if(stage>=5)j.local_head_selected=true;
  if(stage>=8){j.duplicate_closure=t.branch.classification==BranchClass::duplicate;j.fork_detected=t.branch.classification==BranchClass::fork;}
  if(stage>=9){j.merge_candidate_ready=true;j.merge_checkpoint_id=t.merge.merge_checkpoint_id;}
  return j;
}
bool later(const Trace&t,std::uint64_t stage){const bool v[9]={t.has_parent,t.has_snapshot,t.has_checkpoint,t.has_head_observation,t.has_head_update,t.has_transport,t.has_reopen,t.has_branch,t.has_merge};for(std::size_t i=static_cast<std::size_t>(stage);i<9;++i)if(v[i])return true;return false;}
}

Judgment evaluate_reference(const Trace& t) {
  const bool p_ok=t.has_parent&&t.parent.archive_sha==p_archive()&&t.parent.archive_bytes==SLOPOS_CFI_PARENT_ARCHIVE_BYTES
      &&t.parent.manifest_rows==SLOPOS_CFI_PARENT_MANIFEST_ROWS&&t.parent.root_digest==p_root()&&t.parent.filename_digest==p_file()
      &&t.parent.checkpoint_projection_digest==p_checkpoint()&&t.parent.object_id==oid(t.parent,"SlopOS/rev0927/checkpoint-fork-identity/parent/v1");
  if(!t.has_parent) return no(Reason::missing_predecessor,0,t);
  if(!p_ok) return no(Reason::parent_binding,0,t);
  if(!t.has_snapshot)return later(t,1)?no(Reason::missing_predecessor,1,t):yes(1,t);
  const bool s_ok=!is_zero(t.snapshot.snapshot_digest)&&!is_zero(t.snapshot.logical_root_digest)&&!is_zero(t.snapshot.repository_digest)
      &&!is_zero(t.snapshot.proof_projection_digest)&&t.snapshot.closure_policy_digest==closure()&&t.snapshot.manifest_rows>0
      &&t.snapshot.object_id==oid(t.snapshot,"SlopOS/rev0927/checkpoint-fork-identity/source-snapshot/v1");
  if(!s_ok)return no(Reason::source_snapshot,1,t);
  if(!t.has_checkpoint)return later(t,2)?no(Reason::missing_predecessor,2,t):yes(2,t);
  const Digest cp=semantic(t.parent.object_id,{},t.snapshot.object_id,closure(),1);
  const bool c_ok=t.checkpoint.schema_digest==digest_text("slopos.checkpoint-fork-identity.checkpoint-schema.v1")
      &&t.checkpoint.primary_parent_id==t.parent.object_id&&is_zero(t.checkpoint.secondary_parent_id)
      &&t.checkpoint.snapshot_id==t.snapshot.object_id&&t.checkpoint.closure_policy_digest==closure()
      &&!is_zero(t.checkpoint.display_label_digest)&&t.checkpoint.created_ordinal>0&&t.checkpoint.parent_count==1
      &&t.checkpoint.checkpoint_id==cp&&t.checkpoint.record_id==rid(t.checkpoint);
  if(!c_ok)return no(Reason::checkpoint_record,2,t);
  if(!t.has_head_observation)return later(t,3)?no(Reason::missing_predecessor,3,t):yes(3,t);
  const bool o_ok=!is_zero(t.head_observation.registry_incarnation)&&t.head_observation.expected_head_checkpoint_id==t.parent.object_id
      &&t.head_observation.observed_generation==926&&t.head_observation.observed_revision==4100
      &&t.head_observation.observer_policy_digest==branch_policy()
      &&t.head_observation.object_id==oid(t.head_observation,"SlopOS/rev0927/checkpoint-fork-identity/head-observation/v1");
  if(!o_ok)return no(Reason::head_observation,3,t);
  if(!t.has_head_update)return later(t,4)?no(Reason::missing_predecessor,4,t):yes(4,t);
  const bool u_ok=t.head_update.observation_id==t.head_observation.object_id&&t.head_update.registry_incarnation==t.head_observation.registry_incarnation
      &&t.head_update.expected_old_checkpoint_id==t.parent.object_id&&t.head_update.new_checkpoint_id==t.checkpoint.checkpoint_id
      &&t.head_update.new_generation==927&&t.head_update.commit_revision>t.head_observation.observed_revision
      &&t.head_update.result==UpdateResult::applied&&t.head_update.object_id==oid(t.head_update,"SlopOS/rev0927/checkpoint-fork-identity/head-update/v1");
  if(!u_ok)return no(Reason::head_update,4,t);
  if(!t.has_transport)return later(t,5)?no(Reason::missing_predecessor,5,t):yes(5,t);
  const bool tr_ok=t.transport.checkpoint_id==t.checkpoint.checkpoint_id&&t.transport.checkpoint_record_id==t.checkpoint.record_id
      &&!is_zero(t.transport.archive_sha)&&t.transport.archive_bytes>0&&t.transport.manifest_rows>0&&!is_zero(t.transport.root_digest)
      &&!is_zero(t.transport.archive_name_digest)&&t.transport.no_replace==1&&t.transport.file_durable==1&&t.transport.directory_durable==1
      &&t.transport.publication_revision>t.head_update.commit_revision
      &&t.transport.object_id==oid(t.transport,"SlopOS/rev0927/checkpoint-fork-identity/transport/v1");
  if(!tr_ok)return no(Reason::transport_receipt,5,t);
  if(!t.has_reopen)return later(t,6)?no(Reason::missing_predecessor,6,t):yes(6,t);
  const bool r_ok=t.reopen.transport_receipt_id==t.transport.object_id&&t.reopen.archive_sha==t.transport.archive_sha
      &&t.reopen.extracted_root_digest==t.transport.root_digest&&!is_zero(t.reopen.manifest_digest)&&t.reopen.manifest_rows==t.transport.manifest_rows
      &&t.reopen.reopener_implementation_digest==reopener()&&t.reopen.result==1
      &&t.reopen.object_id==oid(t.reopen,"SlopOS/rev0927/checkpoint-fork-identity/reopen/v1");
  if(!r_ok)return no(Reason::reopen_receipt,6,t);
  if(!t.has_branch)return later(t,7)?no(Reason::missing_predecessor,7,t):yes(7,t);
  const Digest sibling=semantic(t.parent.object_id,{},t.branch.sibling_snapshot_id,closure(),1);
  const BranchClass kind=sibling==t.checkpoint.checkpoint_id?BranchClass::duplicate:BranchClass::fork;
  const bool b_ok=t.branch.common_parent_id==t.parent.object_id&&t.branch.selected_checkpoint_id==t.checkpoint.checkpoint_id
      &&!is_zero(t.branch.sibling_snapshot_id)&&t.branch.sibling_checkpoint_id==sibling
      &&t.branch.sibling_record_id==sibling_record(sibling,t.branch.sibling_snapshot_id)&&t.branch.classification==kind
      &&t.branch.known_sibling_count==1&&t.branch.custody_policy_digest==branch_policy()
      &&t.branch.object_id==oid(t.branch,"SlopOS/rev0927/checkpoint-fork-identity/branch-custody/v1");
  if(!b_ok)return no(Reason::branch_custody,7,t);
  if(!t.has_merge)return later(t,8)?no(Reason::missing_predecessor,8,t):yes(8,t);
  const Digest merge_id=semantic(t.merge.primary_parent_checkpoint_id,t.merge.secondary_parent_checkpoint_id,t.merge.merged_snapshot_id,t.merge.merge_policy_digest,2);
  const bool m_ok=t.branch.classification==BranchClass::fork&&t.merge.primary_parent_checkpoint_id==t.checkpoint.checkpoint_id
      &&t.merge.secondary_parent_checkpoint_id==t.branch.sibling_checkpoint_id&&t.merge.primary_parent_checkpoint_id!=t.merge.secondary_parent_checkpoint_id
      &&t.merge.primary_parent_reopen_receipt_id==t.reopen.object_id&&t.merge.secondary_parent_transport_receipt_id==secondary_transport(t.branch)
      &&t.merge.secondary_parent_reopen_receipt_id==secondary_reopen(t.branch)&&!is_zero(t.merge.resolution_digest)&&!is_zero(t.merge.merged_snapshot_id)
      &&t.merge.merge_policy_digest==merge_policy()&&t.merge.parent_count==2&&t.merge.all_parents_reopened==1
      &&t.merge.merge_checkpoint_id==merge_id&&t.merge.record_id==mrid(t.merge);
  if(!m_ok)return no(Reason::merge_record,8,t);
  return yes(9,t);
}
}
