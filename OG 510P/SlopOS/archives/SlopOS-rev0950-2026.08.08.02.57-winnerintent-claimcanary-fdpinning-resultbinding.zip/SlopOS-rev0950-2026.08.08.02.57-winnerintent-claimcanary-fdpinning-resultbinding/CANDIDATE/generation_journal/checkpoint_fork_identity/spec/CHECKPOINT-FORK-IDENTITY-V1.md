# Checkpoint Fork Identity and Merge Fence V1

## Scope

The construction is a preservation mechanism for the linked construction
office. It does not claim a living-project edge and does not simulate an owner,
provider, or globally current registry.

## Exact objects

1. Parent transport binding — exact rev0926 archive digest, byte length,
   manifest rows, root, filename, and checkpoint projection.
2. Logical source snapshot — exact snapshot, logical root, repository, proof
   projection, closure policy, and inventory count.
3. Checkpoint record — ordered parent set, snapshot, policy, display label,
   semantic checkpoint identity, and representation record identity.
4. Head observation — one hosted registry incarnation, expected head,
   generation, revision, and observer policy.
5. Head update receipt — compare-and-update from the exact observed head to the
   exact checkpoint.
6. Transport receipt — archive identity, root, manifest, no-replace, file
   durability, and directory durability.
7. Reopen receipt — exact transport, extraction root, manifest, and independent
   parser implementation.
8. Branch custody — common parent, selected child, exact known sibling, and
   duplicate-versus-fork classification.
9. Merge record — two distinct exact parent checkpoints, both reopen receipts,
   exact resolution digest, exact merged snapshot, and merge identity.

The canonical object total is 2,880 bytes.

## Identity law

```text
CheckpointId = H(schema,
                 ordered parent checkpoint identities,
                 logical snapshot identity,
                 closure policy identity)
```

The display revision label, wall clock, and physical workspace locator are not
inputs to `CheckpointId`. They may enter a separate representation record.

## Branch law

Two checkpoint records are duplicates exactly when their semantic checkpoint
identities match. Distinct checkpoint identities with one exact parent are
siblings even when their revision labels match. A branch-custody record binds
known siblings; it cannot prove that no undiscovered sibling exists.

## Local selection law

A compare-and-update can select one child in one coherent hosted registry. If
the registry is cloned before update, each clone can accept a different child.
The construction therefore does not prove global lineage uniqueness.

## Merge law

A merge candidate names every exact parent checkpoint, requires an exact reopen
receipt for each, and binds both a resolution digest and merged logical
snapshot. Copying a sibling law, referring to its digest, or reusing its revision
label is not a merge.

## Nonclaims

The relation does not prove global selection, hidden-sibling absence, external
publication, administrative independence, owner admission, authority, living
lineage, or Epoch-Zero exit.
