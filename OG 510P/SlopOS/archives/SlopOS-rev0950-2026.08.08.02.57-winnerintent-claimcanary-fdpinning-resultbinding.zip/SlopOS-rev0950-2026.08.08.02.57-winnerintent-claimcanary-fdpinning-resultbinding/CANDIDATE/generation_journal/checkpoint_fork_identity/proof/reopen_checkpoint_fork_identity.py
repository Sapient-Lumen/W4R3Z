#!/usr/bin/env python3
from __future__ import annotations
import csv, hashlib, json, struct, sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent
CANONICAL = {
    "PARENT-TRANSPORT-BINDING.bin": 256,
    "SOURCE-SNAPSHOT.bin": 256,
    "CHECKPOINT-RECORD.bin": 352,
    "HEAD-OBSERVATION.bin": 256,
    "HEAD-UPDATE-RECEIPT.bin": 320,
    "TRANSPORT-RECEIPT.bin": 352,
    "REOPEN-RECEIPT.bin": 320,
    "BRANCH-CUSTODY.bin": 352,
    "MERGE-RECORD.bin": 416,
    "CASES.tsv": None,
    "CUTS.tsv": None,
    "FORKS.tsv": None,
    "MERGES.tsv": None,
    "COUNTERMODELS.tsv": None,
    "LAWS.tsv": None,
    "IDENTITIES.tsv": None,
    "SUMMARY.tsv": None,
    "REPORT.txt": None,
}

def fail(detail: str) -> None:
    raise SystemExit(f"CHECKPOINT_FORK_IDENTITY_REOPEN=FAIL detail={detail}")

def sha(path: Path) -> str:
    h=hashlib.sha256();
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()

def domain_hash(domain: str, payload: bytes) -> bytes:
    return hashlib.sha256(domain.encode()+b'\0'+payload).digest()

def text_hash(text: str) -> bytes:
    return domain_hash("SlopOS/rev0927/checkpoint-fork-identity/text/v1", text.encode())

def u64(data: bytes, off: int) -> int:
    return struct.unpack_from('<Q',data,off)[0]

def zeroed_hash(data: bytes, start: int, domain: str) -> bytes:
    raw=bytearray(data); raw[start:start+32]=b'\0'*32
    return domain_hash(domain,bytes(raw))

def semantic(primary: bytes, secondary: bytes, snapshot: bytes, policy: bytes, count: int) -> bytes:
    payload=(text_hash("slopos.checkpoint-fork-identity.checkpoint-schema.v1")+primary+secondary+snapshot+policy+struct.pack('<Q',count))
    return domain_hash("SlopOS/rev0927/checkpoint-fork-identity/checkpoint-id/v1",payload)

def read_tsv(path: Path) -> list[dict[str,str]]:
    with path.open(newline='',encoding='utf-8') as f: return list(csv.DictReader(f,delimiter='\t'))

def require_magic(data: bytes, expected: bytes) -> None:
    if data[:32].rstrip(b'\0') != expected: fail(f"magic={data[:32]!r}")
    if any(data[len(data.rstrip(b'\0')):]): fail("impossible-padding")

def main() -> int:
    if len(sys.argv)!=2: fail('usage')
    out=Path(sys.argv[1])
    observed={p.name for p in out.iterdir() if p.is_file()}
    if observed != set(CANONICAL): fail(f"canonical-set missing={sorted(set(CANONICAL)-observed)} extra={sorted(observed-set(CANONICAL))}")
    for name,size in CANONICAL.items():
        if size is not None and (out/name).stat().st_size != size: fail(f"size={name}")
    binding=json.loads((SOURCE/'bindings/PARENT-TRANSPORT.json').read_text())
    closure=bytes.fromhex(sha(SOURCE/'bindings/CHECKPOINT-IDENTITY-POLICY.txt'))
    branch_policy=bytes.fromhex(sha(SOURCE/'bindings/BRANCH-CUSTODY-POLICY.txt'))
    merge_policy=bytes.fromhex(sha(SOURCE/'bindings/MERGE-ADMISSION-POLICY.txt'))
    reopener=bytes.fromhex(sha(Path(__file__)))

    parent=(out/'PARENT-TRANSPORT-BINDING.bin').read_bytes(); require_magic(parent,b'SLOPOS-CFI-PARENT-V1')
    if parent[32:64] != bytes.fromhex(binding['sha256']) or u64(parent,64)!=binding['bytes'] or u64(parent,72)!=binding['manifest_rows']: fail('parent-transport')
    if parent[80:112] != bytes.fromhex(binding['root_sha256']) or parent[112:144] != bytes.fromhex(binding['filename_sha256']): fail('parent-name-root')
    if parent[144:176] != bytes.fromhex(binding['checkpoint_json_sha256']): fail('parent-checkpoint')
    if parent[176:208] != zeroed_hash(parent,176,"SlopOS/rev0927/checkpoint-fork-identity/parent/v1"): fail('parent-id')
    parent_id=parent[176:208]

    snap=(out/'SOURCE-SNAPSHOT.bin').read_bytes(); require_magic(snap,b'SLOPOS-CFI-SNAPSHOT-V1')
    if any(x==b'\0'*32 for x in (snap[32:64],snap[64:96],snap[96:128],snap[128:160])): fail('snapshot-zero')
    if snap[160:192]!=closure or u64(snap,192)!=9600: fail('snapshot-policy')
    if snap[200:232] != zeroed_hash(snap,200,"SlopOS/rev0927/checkpoint-fork-identity/source-snapshot/v1"): fail('snapshot-id')
    snapshot_id=snap[200:232]

    cp=(out/'CHECKPOINT-RECORD.bin').read_bytes(); require_magic(cp,b'SLOPOS-CFI-CHECKPOINT-V1')
    if cp[32:64]!=text_hash("slopos.checkpoint-fork-identity.checkpoint-schema.v1") or cp[64:96]!=parent_id or cp[96:128]!=b'\0'*32: fail('checkpoint-parents')
    if cp[128:160]!=snapshot_id or cp[160:192]!=closure or cp[192:224]==b'\0'*32 or u64(cp,224)==0 or u64(cp,232)!=1: fail('checkpoint-fields')
    cp_id=semantic(parent_id,b'\0'*32,snapshot_id,closure,1)
    if cp[240:272]!=cp_id or cp[272:304]!=zeroed_hash(cp,272,"SlopOS/rev0927/checkpoint-fork-identity/checkpoint-record/v1"): fail('checkpoint-identity')
    cp_record_id=cp[272:304]

    obs=(out/'HEAD-OBSERVATION.bin').read_bytes(); require_magic(obs,b'SLOPOS-CFI-HEAD-OBS-V1')
    if obs[32:64]==b'\0'*32 or obs[64:96]!=parent_id or u64(obs,96)!=926 or u64(obs,104)!=4100 or obs[112:144]!=branch_policy: fail('head-observation')
    if obs[144:176]!=zeroed_hash(obs,144,"SlopOS/rev0927/checkpoint-fork-identity/head-observation/v1"): fail('head-observation-id')
    obs_id=obs[144:176]

    upd=(out/'HEAD-UPDATE-RECEIPT.bin').read_bytes(); require_magic(upd,b'SLOPOS-CFI-HEAD-UPDATE-V1')
    if upd[32:64]!=obs_id or upd[64:96]!=obs[32:64] or upd[96:128]!=parent_id or upd[128:160]!=cp_id: fail('head-update-subject')
    if u64(upd,160)!=927 or u64(upd,168)<=4100 or u64(upd,176)!=1: fail('head-update-order')
    if upd[184:216]!=zeroed_hash(upd,184,"SlopOS/rev0927/checkpoint-fork-identity/head-update/v1"): fail('head-update-id')

    tr=(out/'TRANSPORT-RECEIPT.bin').read_bytes(); require_magic(tr,b'SLOPOS-CFI-TRANSPORT-V1')
    if tr[32:64]!=cp_id or tr[64:96]!=cp_record_id or tr[96:128]==b'\0'*32 or u64(tr,128)==0 or u64(tr,136)==0: fail('transport-subject')
    if tr[144:176]==b'\0'*32 or tr[176:208]==b'\0'*32 or (u64(tr,208),u64(tr,216),u64(tr,224))!=(1,1,1) or u64(tr,232)<=u64(upd,168): fail('transport-publication')
    if tr[240:272]!=zeroed_hash(tr,240,"SlopOS/rev0927/checkpoint-fork-identity/transport/v1"): fail('transport-id')
    tr_id=tr[240:272]

    ro=(out/'REOPEN-RECEIPT.bin').read_bytes(); require_magic(ro,b'SLOPOS-CFI-REOPEN-V1')
    if ro[32:64]!=tr_id or ro[64:96]!=tr[96:128] or ro[96:128]!=tr[144:176] or ro[128:160]==b'\0'*32: fail('reopen-subject')
    if u64(ro,160)!=u64(tr,136) or ro[168:200]!=reopener or u64(ro,200)!=1: fail('reopen-policy')
    if ro[208:240]!=zeroed_hash(ro,208,"SlopOS/rev0927/checkpoint-fork-identity/reopen/v1"): fail('reopen-id')
    ro_id=ro[208:240]

    br=(out/'BRANCH-CUSTODY.bin').read_bytes(); require_magic(br,b'SLOPOS-CFI-BRANCH-V1')
    if br[32:64]!=parent_id or br[64:96]!=cp_id or br[96:128]==b'\0'*32: fail('branch-subject')
    sibling=semantic(parent_id,b'\0'*32,br[96:128],closure,1)
    sibling_record=domain_hash("SlopOS/rev0927/checkpoint-fork-identity/sibling-record/v1",sibling+br[96:128])
    expected_class=1 if sibling==cp_id else 2
    if br[128:160]!=sibling or br[160:192]!=sibling_record or u64(br,192)!=expected_class or u64(br,200)!=1 or br[208:240]!=branch_policy: fail('branch-classification')
    if br[240:272]!=zeroed_hash(br,240,"SlopOS/rev0927/checkpoint-fork-identity/branch-custody/v1"): fail('branch-id')
    br_id=br[240:272]

    mg=(out/'MERGE-RECORD.bin').read_bytes(); require_magic(mg,b'SLOPOS-CFI-MERGE-V1')
    secondary_transport=domain_hash("SlopOS/rev0927/checkpoint-fork-identity/secondary-transport/v1",sibling+br_id)
    secondary_reopen=domain_hash("SlopOS/rev0927/checkpoint-fork-identity/secondary-reopen/v1",secondary_transport+reopener)
    if mg[32:64]!=cp_id or mg[64:96]!=sibling or cp_id==sibling or mg[96:128]!=ro_id: fail('merge-parents')
    if mg[128:160]!=secondary_transport or mg[160:192]!=secondary_reopen or mg[192:224]==b'\0'*32 or mg[224:256]==b'\0'*32: fail('merge-parent-reopen')
    if mg[256:288]!=merge_policy or u64(mg,288)!=2 or u64(mg,296)!=1: fail('merge-policy')
    merge_id=semantic(cp_id,sibling,mg[224:256],merge_policy,2)
    if mg[304:336]!=merge_id or mg[336:368]!=zeroed_hash(mg,336,"SlopOS/rev0927/checkpoint-fork-identity/merge-record/v1"): fail('merge-id')

    ids=read_tsv(out/'IDENTITIES.tsv')
    if {r['object'] for r in ids} != {n for n,s in CANONICAL.items() if s is not None}: fail('identity-object-set')
    for row in ids:
        if int(row['bytes'])!=(out/row['object']).stat().st_size or row['sha256']!=sha(out/row['object']): fail(f"identity-row={row['object']}")
    case_rows=read_tsv(out/'CASES.tsv')
    names=[r['case'] for r in case_rows]
    if len(names)!=len(set(names)) or len(names)<80: fail('case-addressability')
    by={r['case']:r for r in case_rows}
    required={
      'valid_prefix_stage_9':'true',
      'display_label_changes_record_not_checkpoint_identity':'true',
      'physical_locator_does_not_select_identity':'true',
      'identical_closure_is_duplicate_not_fork':'true',
      'same_label_siblings' if False else 'parent_archive_digest_substitution':'false',
      'identical_checkpoint_mislabeled_as_fork':'false',
      'merge_parent_not_reopened':'false',
      'checkpoint_without_snapshot':'false',
    }
    for name,value in required.items():
        if by.get(name,{}).get('accepted')!=value: fail(f"case={name}")
    if by['display_label_changes_record_not_checkpoint_identity']['checkpoint_id'] != by['valid_prefix_stage_9']['checkpoint_id']: fail('label-changed-checkpoint-id')
    if by['display_label_changes_record_not_checkpoint_identity']['record_id'] == by['valid_prefix_stage_9']['record_id']: fail('label-record-id-not-distinct')
    cuts=read_tsv(out/'CUTS.tsv')
    if len(cuts)!=len(case_rows)*9 or len({(r['case'],r['cut']) for r in cuts})!=len(cuts): fail('cut-matrix')
    forks=read_tsv(out/'FORKS.tsv'); merges=read_tsv(out/'MERGES.tsv'); laws=read_tsv(out/'LAWS.tsv'); cms=read_tsv(out/'COUNTERMODELS.tsv')
    if len(forks)!=12 or len(merges)!=10 or len(laws)!=20 or len(cms)!=12: fail('law-scenario-count')
    summary={r['metric']:r['value'] for r in read_tsv(out/'SUMMARY.tsv')}
    expected={'cases':str(len(case_rows)),'accepted':str(sum(r['accepted']=='true' for r in case_rows)),'rejected':str(sum(r['accepted']=='false' for r in case_rows)),
              'lifecycle_cuts':str(len(cuts)),'durable_stages':'9','canonical_objects':'9','canonical_exact_object_bytes':'2880',
              'fork_scenarios':'12','merge_scenarios':'10','candidate_reference_disagreements':'0','display_label_selects':'false',
              'physical_locator_selects':'false','local_head_compare_update':'true','global_lineage_unique':'false','unknown_siblings_excluded':'false',
              'owner_admission':'false','authority':'false','epoch_exit':'false'}
    for k,v in expected.items():
        if summary.get(k)!=v: fail(f"summary={k}:{summary.get(k)}")
    report=(out/'REPORT.txt').read_text()
    if not report.startswith('CHECKPOINT_FORK_IDENTITY_CAMPAIGN=PASS') or 'global_unique=false' not in report or 'authority=false' not in report: fail('report')
    print(f"CHECKPOINT_FORK_IDENTITY_REOPEN=PASS cases={len(case_rows)} accepted={expected['accepted']} rejected={expected['rejected']} cuts={len(cuts)} stages=9 objects=9 bytes=2880 forks=12 merges=10 label_selects=false locator_selects=false global_unique=false authority=false")
    return 0
if __name__=='__main__': raise SystemExit(main())
