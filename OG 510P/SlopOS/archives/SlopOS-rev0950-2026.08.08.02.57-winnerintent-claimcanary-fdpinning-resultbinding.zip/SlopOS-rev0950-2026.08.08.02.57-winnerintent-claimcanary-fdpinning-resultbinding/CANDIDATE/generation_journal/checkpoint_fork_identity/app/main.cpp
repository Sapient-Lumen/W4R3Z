#include <filesystem>
#include <iostream>
#include "slopos/e0/checkpoint_fork_identity/checkpoint_fork_identity.hpp"
int main(int argc, char** argv) {
  if (argc != 2) { std::cerr << "usage: slopos_checkpoint_fork_identity OUTPUT_DIR\n"; return 2; }
  return slopos::e0::checkpoint_fork_identity::run_campaign(std::filesystem::path(argv[1]));
}
