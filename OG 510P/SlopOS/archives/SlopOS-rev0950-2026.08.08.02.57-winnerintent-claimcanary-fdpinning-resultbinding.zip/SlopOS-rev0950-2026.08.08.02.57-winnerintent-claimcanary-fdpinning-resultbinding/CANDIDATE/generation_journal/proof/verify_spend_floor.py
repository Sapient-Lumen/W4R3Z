#!/usr/bin/env python3
"""Independent replay for the hosted content-bound spend-floor relation.

The checker parses campaign bytes, independently decodes the 352-byte record,
recomputes SHA-256 domains, reconstructs every local/floor decision, and checks
race/counterexample invariants. It does not import or execute C++ logic.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import struct
from dataclasses import dataclass
from pathlib import Path

INTEGRITY_DOMAIN = b"SlopOS/spend/record/v1/integrity"
HEAD_DOMAIN = b"SlopOS/spend/record/v1/head" + b"\x00" * 5
ZERO = b"\x00" * 32


@dataclass(frozen=True)
class Decoded:
    owner_epoch: int
    constructor_epoch: int
    spend_serial: int
    generation_from: int
    generation_to: int
    predecessor_head: bytes


@dataclass(frozen=True)
class Decision:
    relation: str
    compare_append_allowed: bool = False
    query_only: bool = False
    rollback_detected: bool = False
    fail_stop: bool = True


def fail(detail: str) -> None:
    raise SystemExit(f"SPEND_FLOOR_AUDIT=FAIL detail={detail}")


def boolean(value: str) -> bool:
    if value == "true":
        return True
    if value == "false":
        return False
    fail(f"invalid boolean={value!r}")
    raise AssertionError


def bytes_field(value: str, length: int) -> bytes:
    try:
        result = bytes.fromhex(value)
    except ValueError as error:
        fail(f"invalid hex={value[:32]!r} error={error}")
    if len(result) != length:
        fail(f"hex length expected={length} observed={len(result)}")
    return result


def optional_record(value: str) -> bytes | None:
    return None if value == "-" else bytes_field(value, 352)


def decode_record(raw: bytes) -> Decoded | None:
    if len(raw) != 352:
        return None
    if raw[:8] != b"SLOPSP01":
        return None
    version, kind, length = struct.unpack(">HHI", raw[8:16])
    if (version, kind, length) != (1, 1, 352):
        return None
    if raw[312:320] != b"\x00" * 8:
        return None
    if raw[320:352] != hashlib.sha256(INTEGRITY_DOMAIN + raw[:320]).digest():
        return None
    values = struct.unpack(">QQQQQ", raw[16:56])
    owner_epoch, constructor_epoch, spend_serial, generation_from, generation_to = values
    if (
        owner_epoch == 0
        or constructor_epoch == 0
        or spend_serial == 0
        or generation_from == 0
        or generation_to == 0
        or generation_from == (1 << 64) - 1
        or generation_to != generation_from + 1
    ):
        return None
    digests = [raw[offset : offset + 32] for offset in range(56, 312, 32)]
    if len(digests) != 8 or any(value == ZERO for value in digests):
        return None
    return Decoded(
        owner_epoch=owner_epoch,
        constructor_epoch=constructor_epoch,
        spend_serial=spend_serial,
        generation_from=generation_from,
        generation_to=generation_to,
        predecessor_head=digests[-1],
    )


def record_head(raw: bytes) -> bytes:
    return hashlib.sha256(HEAD_DOMAIN + raw).digest()


def point_exact(generation: int, head: bytes) -> bool:
    return generation > 0 and head != ZERO


def reconstruct(row: dict[str, str]) -> Decision:
    local_generation = int(row["local_generation"])
    local_head = bytes_field(row["local_head"], 32)
    pending_present = boolean(row["pending_present"])
    pending = optional_record(row["pending_hex"])
    candidate = bytes_field(row["candidate_hex"], 352)
    expected_identity = bytes_field(row["expected_floor_identity"], 32)

    if expected_identity == ZERO or not point_exact(local_generation, local_head):
        return Decision("malformed")
    if pending_present != (pending is not None):
        return Decision("malformed")

    proposal = decode_record(candidate)
    if (
        proposal is None
        or proposal.generation_from != local_generation
        or proposal.predecessor_head != local_head
    ):
        return Decision("malformed")
    proposal_generation = proposal.generation_to
    proposal_head = record_head(candidate)

    if pending is not None:
        if decode_record(pending) is None:
            return Decision("malformed")
        if pending != candidate:
            return Decision("foreign_spend")

    floor_status = row["floor_status"]
    if floor_status == "unavailable":
        return Decision("floor_unavailable")
    if floor_status != "available":
        return Decision("malformed")

    floor_identity = bytes_field(row["floor_identity"], 32)
    if floor_identity != expected_identity:
        return Decision("identity_mismatch")
    floor_generation = int(row["floor_generation"])
    floor_head = bytes_field(row["floor_head"], 32)
    content_bound = boolean(row["floor_content_bound"])
    floor_record = optional_record(row["floor_record_hex"])
    if floor_generation == 0:
        return Decision("malformed")
    if not content_bound:
        if floor_head != ZERO or floor_record is not None:
            return Decision("malformed")
        return Decision(
            "scalar_ambiguous",
            rollback_detected=floor_generation > local_generation,
        )
    if floor_head == ZERO:
        return Decision("malformed")
    if floor_record is not None:
        observed = decode_record(floor_record)
        if (
            observed is None
            or observed.generation_to != floor_generation
            or record_head(floor_record) != floor_head
        ):
            return Decision("malformed")

    if floor_generation < local_generation:
        return Decision("local_ahead")
    if floor_generation == local_generation:
        if floor_head != local_head:
            return Decision("foreign_spend")
        if pending_present:
            return Decision(
                "prepared_exact",
                compare_append_allowed=True,
                fail_stop=False,
            )
        return Decision("fresh", compare_append_allowed=True, fail_stop=False)
    if floor_generation == proposal_generation:
        if floor_head == proposal_head:
            return Decision(
                "same_spend_committed",
                query_only=True,
                rollback_detected=True,
                fail_stop=False,
            )
        return Decision("foreign_spend", rollback_detected=True)
    return Decision(
        "generation_jump",
        rollback_detected=floor_generation > local_generation,
    )


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("campaign", type=Path)
    parser.add_argument("--json", required=True, type=Path)
    args = parser.parse_args()
    campaign = args.campaign.resolve()

    if len(INTEGRITY_DOMAIN) != 32 or len(HEAD_DOMAIN) != 32:
        fail("domain length")
    if hashlib.sha256(b"abc").hexdigest() != (
        "ba7816bf8f01cfea414140de5dae2223"
        "b00361a396177a9cb410ff61f20015ad"
    ):
        fail("host hashlib known answer")

    record_rows = read_tsv(campaign / "spend-records.tsv")
    if len(record_rows) != 2:
        fail(f"record fixtures={len(record_rows)}")
    mutation_rejections = 0
    for row in record_rows:
        raw = bytes_field(row["record_hex"], 352)
        decoded = decode_record(raw)
        if decoded is None:
            fail(f"record decode fixture={row['fixture']}")
        if int(row["bytes"]) != 352 or record_head(raw).hex() != row["head_sha256"]:
            fail(f"record metadata fixture={row['fixture']}")
        if decoded.owner_epoch != int(row["owner_epoch"]):
            fail(f"owner epoch fixture={row['fixture']}")
        if decoded.constructor_epoch != int(row["constructor_epoch"]):
            fail(f"constructor epoch fixture={row['fixture']}")
        if decoded.spend_serial != int(row["spend_serial"]):
            fail(f"serial fixture={row['fixture']}")
        if decoded.generation_from != int(row["generation_from"]):
            fail(f"generation from fixture={row['fixture']}")
        if decoded.generation_to != int(row["generation_to"]):
            fail(f"generation to fixture={row['fixture']}")
        for byte in range(len(raw)):
            for bit in range(8):
                mutant = bytearray(raw)
                mutant[byte] ^= 1 << bit
                if decode_record(bytes(mutant)) is None:
                    mutation_rejections += 1
    if mutation_rejections != 5632:
        fail(f"mutation rejections={mutation_rejections}")

    case_rows = read_tsv(campaign / "spend-cases.tsv")
    if len(case_rows) != 20:
        fail(f"spend cases={len(case_rows)}")
    disagreements = 0
    for row in case_rows:
        observed = reconstruct(row)
        retained = Decision(
            relation=row["relation"],
            compare_append_allowed=boolean(row["compare_append_allowed"]),
            query_only=boolean(row["query_only"]),
            rollback_detected=boolean(row["rollback_detected"]),
            fail_stop=boolean(row["fail_stop"]),
        )
        if observed != retained:
            disagreements += 1
    if disagreements:
        fail(f"python relation disagreements={disagreements}")

    race_rows = read_tsv(campaign / "spend-races.tsv")
    same = [row for row in race_rows if row["race"] == "same-spend-16"]
    foreign = [row for row in race_rows if row["race"] != "same-spend-16"]
    race_violations = 0
    if len(same) != 16:
        race_violations += 1
    if sum(row["append_status"] == "advanced" for row in same) != 1:
        race_violations += 1
    if sum(row["append_status"] == "already_current" for row in same) != 15:
        race_violations += 1
    if sum(boolean(row["invoke_once"]) for row in same) != 0:
        race_violations += 1
    if sum(boolean(row["query_only"]) for row in same) != 16:
        race_violations += 1
    if len(foreign) != 4 or sum(row["append_status"] == "conflict" for row in foreign) != 2:
        race_violations += 1
    if race_violations:
        fail(f"race violations={race_violations}")

    boundary_rows = read_tsv(campaign / "spend-boundary.tsv")
    expected_boundary = {
        "advanced-exact": (False, True, True, False),
        "already-current-exact": (False, True, True, False),
    }
    boundary_violations = 0
    if len(boundary_rows) != 11:
        boundary_violations += 1
    for row in boundary_rows:
        actual = (
            boolean(row["invoke_once"]),
            boolean(row["query_only"]),
            boolean(row["spent"]),
            boolean(row["fail_stop"]),
        )
        expected = expected_boundary.get(row["check"], (False, False, False, True))
        if actual != expected:
            boundary_violations += 1
    if boundary_violations:
        fail(f"boundary violations={boundary_violations}")

    counterexample_rows = read_tsv(campaign / "spend-counterexamples.tsv")
    if len(counterexample_rows) != 7:
        fail(f"counterexamples={len(counterexample_rows)}")

    summary = json.loads((campaign / "spend-summary.json").read_text(encoding="utf-8"))
    required_summary = {
        "schema": "slopos.rev0894.spend-floor-summary.v1",
        "status": "PASS",
        "spend_cases": 20,
        "record_fixtures": 2,
        "record_bytes": 352,
        "record_bit_mutations": 5632,
        "record_bit_mutations_rejected": 5632,
        "boundary_checks": 11,
        "counterexamples": 7,
        "same_spend_contenders": 16,
        "same_spend_advanced": 1,
        "same_spend_already_current": 15,
        "same_spend_invoke_once": 0,
        "same_spend_query_only": 16,
        "foreign_race_worlds": 2,
        "foreign_race_conflicts": 2,
        "replayed_advanced_invoke_decisions": 0,
        "candidate_reference_disagreements": 0,
        "provider_authenticated": False,
        "physical_rollback_resistance_proved": False,
        "global_spend_proved": False,
        "authority_granted": False,
    }
    for key, value in required_summary.items():
        if summary.get(key) != value:
            fail(f"summary key={key} expected={value!r} observed={summary.get(key)!r}")

    audit = {
        "boundary_violations": 0,
        "counterexamples": 7,
        "python_relation_disagreements": 0,
        "race_violations": 0,
        "record_bit_mutations_rejected": mutation_rejections,
        "record_codec_disagreements": 0,
        "record_fixtures": 2,
        "schema": "slopos.rev0894.spend-floor-audit.v1",
        "spend_cases": len(case_rows),
        "status": "PASS",
    }
    args.json.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(
        "SPEND_FLOOR_AUDIT=PASS "
        f"cases={len(case_rows)} record_fixtures=2 record_mutations={mutation_rejections} "
        "same_spend_advanced=1 same_spend_query_only=16 foreign_conflicts=2 "
        "python_relation_disagreements=0 authority=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
