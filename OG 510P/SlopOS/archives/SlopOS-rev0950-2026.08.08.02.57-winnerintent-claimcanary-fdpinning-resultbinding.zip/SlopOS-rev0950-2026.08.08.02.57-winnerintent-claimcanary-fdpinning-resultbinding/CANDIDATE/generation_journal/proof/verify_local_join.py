#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import re
from pathlib import Path


def fail(detail: str) -> None:
    raise SystemExit(f"LOCAL_JOIN_AUDIT=FAIL detail={detail}")


def read_tsv(path: Path, fields: list[str]) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream, delimiter="\t")
        if reader.fieldnames != fields:
            fail(f"header path={path.name} observed={reader.fieldnames}")
        rows = list(reader)
    if any(any(value is None for value in row.values()) for row in rows):
        fail(f"short row path={path.name}")
    return rows


def boolean(value: str) -> bool:
    if value == "true":
        return True
    if value == "false":
        return False
    fail(f"boolean={value!r}")


def integer(row: dict[str, str], field: str) -> int:
    try:
        return int(row[field])
    except (KeyError, ValueError) as error:
        fail(f"integer field={field} row={row} error={error}")


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Independently audit the rev0894 hosted joined-admission campaign."
    )
    parser.add_argument("campaign", type=Path)
    parser.add_argument("--json", required=True, type=Path)
    args = parser.parse_args()
    campaign = args.campaign.resolve()
    source = Path(__file__).resolve().parent.parent

    cases = read_tsv(
        campaign / "join-cases.tsv",
        [
            "case",
            "status",
            "endpoint_entry_created",
            "endpoint_bindings_exact",
            "query_only",
            "spent",
            "response_authority",
            "fail_stop",
            "endpoint_entries",
            "detail",
        ],
    )
    expected_cases = {
        "fresh-exact": ("admitted", True, True, True, True, False, False, 1),
        "duplicate-exact": (
            "already_current",
            False,
            True,
            True,
            True,
            False,
            False,
            1,
        ),
        "foreign-after-A": ("conflict", False, False, False, False, False, True, 1),
        "identity-mismatch": (
            "identity_mismatch",
            False,
            False,
            False,
            False,
            False,
            True,
            1,
        ),
        "malformed-request": (
            "malformed",
            False,
            False,
            False,
            False,
            False,
            True,
            0,
        ),
        "provider-unavailable": (
            "unavailable",
            False,
            False,
            False,
            False,
            False,
            True,
            0,
        ),
    }
    if len(cases) != len(expected_cases):
        fail(f"case rows={len(cases)}")
    for row in cases:
        observed = (
            row["status"],
            boolean(row["endpoint_entry_created"]),
            boolean(row["endpoint_bindings_exact"]),
            boolean(row["query_only"]),
            boolean(row["spent"]),
            boolean(row["response_authority"]),
            boolean(row["fail_stop"]),
            integer(row, "endpoint_entries"),
        )
        if observed != expected_cases.get(row["case"]):
            fail(f"case row={row}")

    races = read_tsv(
        campaign / "join-races.tsv",
        [
            "race",
            "contenders",
            "admitted",
            "already_current",
            "conflicts",
            "unavailable",
            "final_entries",
            "exact_final_state",
        ],
    )
    expected_races = {
        "same-spend-concurrent-16": (16, 1, 15, 0, 0, 1, True),
        "foreign-A-first": (2, 1, 0, 1, 0, 1, True),
        "foreign-B-first": (2, 1, 0, 1, 0, 1, True),
    }
    if len(races) != len(expected_races):
        fail(f"race rows={len(races)}")
    for row in races:
        observed = (
            integer(row, "contenders"),
            integer(row, "admitted"),
            integer(row, "already_current"),
            integer(row, "conflicts"),
            integer(row, "unavailable"),
            integer(row, "final_entries"),
            boolean(row["exact_final_state"]),
        )
        if observed != expected_races.get(row["race"]):
            fail(f"race row={row}")

    crashes = read_tsv(
        campaign / "join-crash-cuts.tsv",
        [
            "cut",
            "child_exit",
            "recovered_state",
            "recovered_entries",
            "retry_status",
            "retry_entries",
            "clean_read_only_reopen",
        ],
    )
    expected_crashes = {
        "after_begin": (81, "base", 0, "admitted", 1, True),
        "after_floor_update": (82, "base", 0, "admitted", 1, True),
        "after_endpoint_insert": (83, "base", 0, "admitted", 1, True),
        "after_commit_before_reply": (84, "target", 1, "already_current", 1, True),
    }
    if len(crashes) != len(expected_crashes):
        fail(f"crash rows={len(crashes)}")
    for row in crashes:
        observed = (
            integer(row, "child_exit"),
            row["recovered_state"],
            integer(row, "recovered_entries"),
            row["retry_status"],
            integer(row, "retry_entries"),
            boolean(row["clean_read_only_reopen"]),
        )
        if observed != expected_crashes.get(row["cut"]):
            fail(f"crash row={row}")

    replay = read_tsv(
        campaign / "join-response-replay.tsv",
        [
            "copies",
            "copyable_observation",
            "response_authorities",
            "endpoint_entries_before",
            "endpoint_entries_after",
            "new_endpoint_entries",
        ],
    )
    if len(replay) != 1 or (
        integer(replay[0], "copies"),
        boolean(replay[0]["copyable_observation"]),
        integer(replay[0], "response_authorities"),
        integer(replay[0], "endpoint_entries_before"),
        integer(replay[0], "endpoint_entries_after"),
        integer(replay[0], "new_endpoint_entries"),
    ) != (2, True, 0, 1, 1, 0):
        fail(f"response replay rows={replay}")

    clone = read_tsv(
        campaign / "join-rollback-clone.tsv",
        ["world", "status", "endpoint_entries", "exact_state"],
    )
    expected_clone = {
        "primary": ("admitted", 1, True),
        "pre-spend-clone": ("admitted", 1, True),
        "combined-hosted-histories": ("admitted", 2, False),
    }
    if len(clone) != len(expected_clone):
        fail(f"clone rows={len(clone)}")
    for row in clone:
        observed = (
            row["status"],
            integer(row, "endpoint_entries"),
            boolean(row["exact_state"]),
        )
        if observed != expected_clone.get(row["world"]):
            fail(f"clone row={row}")

    split = read_tsv(
        campaign / "join-split-gap.tsv",
        [
            "construction",
            "floor_successor_committed",
            "endpoint_entries",
            "independent_observation",
            "classification",
        ],
    )
    expected_split = [
        (
            "unsafe-split-append-then-entry",
            True,
            0,
            "malformed",
            "uncertain-fail-stop",
        ),
        (
            "joined-local-transaction",
            False,
            0,
            "available",
            "precommit-crash-rolls-back",
        ),
        (
            "joined-local-transaction",
            True,
            1,
            "available",
            "postcommit-crash-reopens-exact",
        ),
    ]
    observed_split = [
        (
            row["construction"],
            boolean(row["floor_successor_committed"]),
            integer(row, "endpoint_entries"),
            row["independent_observation"],
            row["classification"],
        )
        for row in split
    ]
    if observed_split != expected_split:
        fail(f"split rows={split}")

    linux = read_tsv(
        campaign / "join-linux-probes.tsv",
        [
            "probe",
            "supported",
            "peek_receives",
            "consume_receives",
            "installed_descriptor_references",
            "shared_offset_sequence",
            "authority",
        ],
    )
    if len(linux) != 1:
        fail(f"linux probe rows={len(linux)}")
    probe = linux[0]
    expected_linux = (
        "scm-rights-msg-peek",
        True,
        2,
        1,
        3,
        "ABC",
        False,
    )
    observed_linux = (
        probe["probe"],
        boolean(probe["supported"]),
        integer(probe, "peek_receives"),
        integer(probe, "consume_receives"),
        integer(probe, "installed_descriptor_references"),
        probe["shared_offset_sequence"],
        boolean(probe["authority"]),
    )
    if observed_linux != expected_linux:
        fail(f"linux probe row={probe}")

    summary = json.loads((campaign / "join-summary.json").read_text(encoding="utf-8"))
    required_summary = {
        "schema": "slopos.rev0894.local-joined-admission-summary.v1",
        "status": "PASS",
        "cases": 6,
        "crash_cuts": 4,
        "precommit_rollbacks": 3,
        "postcommit_exact_reopens": 1,
        "same_spend_contenders": 16,
        "same_spend_admitted": 1,
        "same_spend_already_current": 15,
        "admission_response_authorities": 0,
        "detached_response_copies": 2,
        "joined_split_gap_states": 0,
        "local_rollback_clone_admissions": 2,
        "scm_rights_installed_references": 3,
    }
    for key, expected in required_summary.items():
        if summary.get(key) != expected:
            fail(f"summary key={key} observed={summary.get(key)!r}")

    header = (source / "include/slopos/e0/generation_journal/local_join.hpp").read_text(
        encoding="utf-8"
    )
    implementation = (source / "src/local_join.cpp").read_text(encoding="utf-8")
    campaign_source = (source / "harness/local_join_campaign.cpp").read_text(
        encoding="utf-8"
    )
    spend_source = (source / "src/spend_floor.cpp").read_text(encoding="utf-8")
    cmake = (source / "CMakeLists.txt").read_text(encoding="utf-8")

    if "invoke_once" in header or "invoke_once" in implementation:
        fail("joined provider exposes invoke language")
    public_signatures = re.findall(r"\[\[nodiscard\]\][^;]+;", header, flags=re.S)
    if any("HostedJoinResult" in signature.split("(", 1)[-1] for signature in public_signatures):
        fail("joined result appears as a public input parameter")
    if "response_authority{false}" not in header or "response_authority = true" in implementation:
        fail("joined response authority invariant")
    for fragment in (
        "BEGIN IMMEDIATE;",
        "UPDATE slopos_floor",
        "INSERT INTO slopos_endpoint_admission",
        "COMMIT;",
        "result.query_only = true;",
        "result.response_authority = false;",
        "after_commit_before_reply",
    ):
        if fragment not in implementation:
            fail(f"implementation fragment={fragment}")
    for fragment in (
        "MSG_PEEK",
        "SCM_RIGHTS",
        "commit_unsafe_split_floor_only",
        "rollback-clone",
    ):
        if fragment not in campaign_source:
            fail(f"campaign source fragment={fragment}")
    if "AppendDecision{false, true, true, false}" not in spend_source:
        fail("detached advanced response is not observation-only")
    for fragment in ("find_package(SQLite3 REQUIRED)", "SQLite::SQLite3"):
        if fragment not in cmake:
            fail(f"cmake fragment={fragment}")

    audit = {
        "authority_granted": False,
        "case_disagreements": 0,
        "crash_atomicity_disagreements": 0,
        "detached_response_authorities": 0,
        "global_spend_proved": False,
        "joined_split_gap_states": 0,
        "linux_scm_rights_references_from_one_queued_message": 3,
        "local_rollback_clone_admissions": 2,
        "protected_provider": False,
        "race_disagreements": 0,
        "schema": "slopos.rev0894.local-joined-admission-audit.v1",
        "source_boundary_checks": 15,
        "status": "PASS",
    }
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(
        json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(
        "LOCAL_JOIN_AUDIT=PASS cases=6 races=3 crash_cuts=4 "
        "split_gap_states=0 response_authorities=0 rollback_clone_admissions=2 "
        "scm_rights_references=3 global_spend=false authority=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
