# Counterexample: an SCM_RIGHTS descriptor is not one-use authority

## Tempting inference

A file descriptor delivered with `SCM_RIGHTS` feels unforgeable and kernel
mediated. It is tempting to call the received descriptor a unique endpoint
admission ticket.

## Linux semantics

UNIX-domain ancillary delivery transfers a reference to an open file
description and is semantically descriptor duplication. `MSG_PEEK` returns
queued message data without removing it, so a later receive can observe the
same message again.

The rev0894 host probe sends one regular-file descriptor in one sequenced-packet
message, receives the packet twice with `MSG_PEEK`, then consumes it once. The
kernel installs three descriptor references. Reading one byte through each
returns `A`, `B`, and `C`, proving that the references share one open-file-
description offset.

## Consequence

The probe establishes two negative facts:

1. one queued ancillary message can install more than one descriptor reference;
2. each installed descriptor is another usable reference to the same kernel
   object.

Therefore neither “kernel-created fd” nor “received once in my code path” is a
proof of globally unique custody. Closing one copy does not revoke the others.
A descriptor can carry access to protected state, but its one-use semantics must
come from a consume operation in that protected state, not from the descriptor
number or delivery event.
