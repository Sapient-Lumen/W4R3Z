# Counterexample: local atomic transaction is not global spend

## Construction

Create a clean hosted joined-admission image at predecessor `(g,H)`. Make a
transactionally consistent copy before any spend. Submit the same exact request
to the original and to the copy.

## Observation

Both local images return `admitted`. Each independently reopens at the exact
successor with one exact endpoint-admission row. Across the two histories there
are two admissions for what governance intended to be one spend.

## Why local correctness is insufficient

The database transaction correctly joins its own floor row and endpoint row.
The failure is outside that transaction: the cloudtainer can clone and restore
the entire rollback domain. Integrity, `fsync`, strict schemas, write locks,
and exact readback cannot distinguish the original history from a coherent
pre-spend clone.

## Correction

The authentic floor identity and transition must be anchored in an external
rollback domain with owner-governed genesis, exclusive writer custody,
anti-substitution binding, backup/restore rules, independent appraisal, and a
successor/compromise procedure. Until then the hosted cell is a fault adapter,
not a durable global spend provider.
