# Counterexample: scalar floor is not spend identity

Let two valid spend records `A` and `B` share predecessor generation 41 and
predecessor head `H`, but bind different operations. Consider two worlds:

- world A: `A` wins and the external counter becomes 42;
- world B: `B` wins and the external counter becomes 42.

A reader that observes only `42` receives identical input in both worlds. Yet
recovery must bind different operations and different endpoint queries. No
deterministic function of the scalar observation can return the correct exact
spend in both worlds.

Therefore a monotonic scalar can establish that some later order point exists,
but cannot identify which spend owns it. The correction is an exact
content-bound head (and canonical record identity) at the protected floor.
