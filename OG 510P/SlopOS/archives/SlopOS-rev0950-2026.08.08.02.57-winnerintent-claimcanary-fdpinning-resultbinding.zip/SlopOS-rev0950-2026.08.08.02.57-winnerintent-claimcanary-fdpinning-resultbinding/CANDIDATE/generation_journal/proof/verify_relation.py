#!/usr/bin/env python3
"""Independent oracle for the epoch-zero generation-journal candidate.

This checker intentionally does not import, execute, or parse C++ implementation
logic.  It reconstructs the finite relation, fixed record codec, publication
witnesses, hosted boundary observations, and the burn-to-journal handoff
counterexample, then compares the campaign's retained bytes exactly.
"""
from __future__ import annotations

import argparse
import dataclasses
import json
import struct
import sys
import zlib
from collections.abc import Callable, Iterable
from pathlib import Path


PHASES = ("empty", "pending", "ready", "uncertain", "terminal", "fail_stop")
ENDPOINTS = ("predecessor", "successor_same", "successor_other")
RESULTS = ("none", "effect", "no_effect", "uncertain", "fail_stop")
EVENTS = (
    "accept_consumed_dispatch",
    "accept_wrong_dispatch",
    "persist_pending_exact",
    "persist_pending_mismatch",
    "external_successor_other",
    "invoke_effect_return",
    "invoke_no_effect_return",
    "invoke_nonreturn_before_effect",
    "invoke_nonreturn_after_effect",
    "invoke_malformed_before_effect",
    "invoke_malformed_after_effect",
    "restart",
    "recover_spent_receipt_exact",
    "recover_spent_receipt_mismatch",
    "recover_spent_receipt_missing",
    "query_predecessor",
    "query_successor_same",
    "query_successor_other",
    "query_unavailable",
    "recovery_apply_attempt",
    "mint_dispatch_attempt",
    "route_override_attempt",
    "retry_apply_attempt",
    "publish",
    "stale_publication_attempt",
)


@dataclasses.dataclass(frozen=True, order=True)
class State:
    phase: str = "empty"
    endpoint: str = "predecessor"
    result: str = "none"
    result_version: int = 0
    published_version: int = 0
    invocation_count: int = 0
    effect_count: int = 0
    receipt_bound: bool = False
    pending_exact: bool = False
    recovered: bool = False
    reconciled: bool = False


@dataclasses.dataclass(frozen=True)
class Step:
    outcome: str
    state: State
    endpoint_apply_called: bool = False
    result_refined: bool = False
    publication_appended: bool = False
    dispatch_minted: bool = False


@dataclasses.dataclass(frozen=True)
class Edge:
    state_id: int
    depth: int
    event: str
    step: Step
    next_state_id: int


def b(value: bool) -> str:
    return "true" if value else "false"


def state_key(state: State) -> str:
    return "|".join(
        (
            state.phase,
            state.endpoint,
            state.result,
            str(state.result_version),
            str(state.published_version),
            str(state.invocation_count),
            str(state.effect_count),
            "1" if state.receipt_bound else "0",
            "1" if state.pending_exact else "0",
            "1" if state.recovered else "0",
            "1" if state.reconciled else "0",
        )
    )


def invariant(s: State) -> bool:
    if s.phase not in PHASES or s.endpoint not in ENDPOINTS or s.result not in RESULTS:
        return False
    if s.invocation_count not in (0, 1) or s.effect_count not in (0, 1):
        return False
    if not (0 <= s.result_version <= 2):
        return False
    if not (0 <= s.published_version <= s.result_version):
        return False
    if (s.result == "none") != (s.result_version == 0):
        return False
    if (s.result_version == 2) != s.reconciled:
        return False
    if s.published_version > 0 and s.result == "none":
        return False
    if s.endpoint == "predecessor" and s.effect_count != 0:
        return False
    if s.endpoint == "successor_same" and s.effect_count != 1:
        return False
    if s.endpoint == "successor_other" and s.effect_count != 0:
        return False
    if s.effect_count == 1 and s.invocation_count != 1:
        return False
    if s.invocation_count == 1 and not s.pending_exact:
        return False
    if s.result == "effect" and not (
        s.endpoint == "successor_same" and s.effect_count == 1
    ):
        return False
    if s.result == "no_effect" and not (
        s.endpoint == "predecessor" and s.effect_count == 0
    ):
        return False
    if s.result == "uncertain" and s.result_version != 1:
        return False
    if s.reconciled and s.result == "uncertain":
        return False

    if s.phase == "empty":
        return s == State()
    if s.phase == "pending":
        return (
            s.receipt_bound
            and s.result == "none"
            and s.invocation_count == 0
            and not s.pending_exact
            and not s.recovered
            and not s.reconciled
        )
    if s.phase == "ready":
        return (
            s.receipt_bound
            and s.result == "none"
            and s.invocation_count == 0
            and s.pending_exact
            and not s.recovered
            and not s.reconciled
        )
    if s.phase == "uncertain":
        if not (
            s.receipt_bound
            and s.result == "uncertain"
            and s.result_version == 1
            and not s.reconciled
        ):
            return False
        if not s.pending_exact:
            return s.recovered and s.invocation_count == 0
        return True
    if s.phase == "terminal":
        return (
            s.receipt_bound
            and s.pending_exact
            and s.result in ("effect", "no_effect")
            and s.result_version in (1, 2)
        )
    if s.phase == "fail_stop":
        return s.result == "fail_stop" and s.result_version in (1, 2)
    return False


def applied(
    state: State,
    *,
    endpoint_apply: bool = False,
    refined: bool = False,
    published: bool = False,
) -> Step:
    return Step(
        "applied",
        state,
        endpoint_apply_called=endpoint_apply,
        result_refined=refined,
        publication_appended=published,
    )


def rejected(state: State) -> Step:
    return Step("rejected", state)


def set_result(
    state: State, *, phase: str, result: str, version: int, reconciled: bool
) -> State:
    return dataclasses.replace(
        state,
        phase=phase,
        result=result,
        result_version=version,
        reconciled=reconciled,
    )


def query_allowed(state: State) -> bool:
    return (
        state.phase == "uncertain"
        and state.result == "uncertain"
        and state.result_version == 1
        and state.receipt_bound
        and state.pending_exact
    )


def can_hide_other_successor(state: State) -> bool:
    return (
        state.phase in ("pending", "ready", "uncertain")
        and state.endpoint == "predecessor"
        and state.invocation_count == 0
        and state.result != "effect"
    )


def transition(before: State, event: str) -> Step:
    if event not in EVENTS or not invariant(before):
        return rejected(before)

    if event == "accept_consumed_dispatch":
        if before.phase != "empty":
            return rejected(before)
        return applied(dataclasses.replace(before, phase="pending", receipt_bound=True))

    if event == "accept_wrong_dispatch":
        if before.phase != "empty":
            return rejected(before)
        return applied(
            set_result(
                before,
                phase="fail_stop",
                result="fail_stop",
                version=1,
                reconciled=False,
            )
        )

    if event == "persist_pending_exact":
        if before.phase != "pending":
            return rejected(before)
        return applied(dataclasses.replace(before, phase="ready", pending_exact=True))

    if event == "persist_pending_mismatch":
        if before.phase != "pending":
            return rejected(before)
        return applied(
            set_result(
                before,
                phase="fail_stop",
                result="fail_stop",
                version=1,
                reconciled=False,
            )
        )

    if event == "external_successor_other":
        if not can_hide_other_successor(before):
            return rejected(before)
        return applied(dataclasses.replace(before, endpoint="successor_other"))

    invocation_events = {
        "invoke_effect_return",
        "invoke_no_effect_return",
        "invoke_nonreturn_before_effect",
        "invoke_nonreturn_after_effect",
        "invoke_malformed_before_effect",
        "invoke_malformed_after_effect",
    }
    if event in invocation_events:
        if before.phase != "ready" or before.invocation_count != 0:
            return rejected(before)
        after = dataclasses.replace(before, invocation_count=1)
        if before.endpoint == "successor_other":
            after = set_result(
                after,
                phase="fail_stop",
                result="fail_stop",
                version=1,
                reconciled=False,
            )
            return applied(after, endpoint_apply=True)
        if event == "invoke_effect_return":
            after = dataclasses.replace(after, endpoint="successor_same", effect_count=1)
            after = set_result(
                after,
                phase="terminal",
                result="effect",
                version=1,
                reconciled=False,
            )
            return applied(after, endpoint_apply=True)
        if event == "invoke_no_effect_return":
            after = set_result(
                after,
                phase="terminal",
                result="no_effect",
                version=1,
                reconciled=False,
            )
            return applied(after, endpoint_apply=True)
        if event in ("invoke_nonreturn_after_effect", "invoke_malformed_after_effect"):
            after = dataclasses.replace(after, endpoint="successor_same", effect_count=1)
        after = set_result(
            after,
            phase="uncertain",
            result="uncertain",
            version=1,
            reconciled=False,
        )
        return applied(after, endpoint_apply=True)

    if event == "restart":
        if before.phase in ("pending", "ready"):
            after = dataclasses.replace(before, recovered=True)
            after = set_result(
                after,
                phase="uncertain",
                result="uncertain",
                version=1,
                reconciled=False,
            )
            return applied(after)
        if before.phase in ("uncertain", "terminal", "fail_stop") and not before.recovered:
            return applied(dataclasses.replace(before, recovered=True))
        return rejected(before)

    if event == "recover_spent_receipt_exact":
        if not (
            before.phase == "uncertain"
            and before.recovered
            and not before.pending_exact
            and before.receipt_bound
        ):
            return rejected(before)
        return applied(dataclasses.replace(before, pending_exact=True))

    if event == "recover_spent_receipt_mismatch":
        if not (
            before.phase == "uncertain"
            and before.recovered
            and not before.pending_exact
            and before.receipt_bound
        ):
            return rejected(before)
        after = set_result(
            before,
            phase="fail_stop",
            result="fail_stop",
            version=2,
            reconciled=True,
        )
        return applied(after, refined=True)

    if event == "recover_spent_receipt_missing":
        if not (
            before.phase == "uncertain"
            and before.recovered
            and not before.pending_exact
            and before.receipt_bound
        ):
            return rejected(before)
        return applied(before)

    if event == "query_predecessor":
        if not query_allowed(before) or before.endpoint != "predecessor":
            return rejected(before)
        after = set_result(
            before,
            phase="terminal",
            result="no_effect",
            version=2,
            reconciled=True,
        )
        return applied(after, refined=True)

    if event == "query_successor_same":
        if not query_allowed(before) or before.endpoint != "successor_same":
            return rejected(before)
        after = set_result(
            before,
            phase="terminal",
            result="effect",
            version=2,
            reconciled=True,
        )
        return applied(after, refined=True)

    if event == "query_successor_other":
        if not query_allowed(before) or before.endpoint != "successor_other":
            return rejected(before)
        after = set_result(
            before,
            phase="fail_stop",
            result="fail_stop",
            version=2,
            reconciled=True,
        )
        return applied(after, refined=True)

    if event == "query_unavailable":
        return applied(before) if query_allowed(before) else rejected(before)

    if event == "publish":
        if before.result == "none" or before.published_version >= before.result_version:
            return rejected(before)
        after = dataclasses.replace(before, published_version=before.result_version)
        return applied(after, published=True)

    return rejected(before)


def construct_relation() -> tuple[list[State], list[int], list[Edge]]:
    states = [State()]
    depths = [0]
    ids = {states[0]: 0}
    edges: list[Edge] = []
    cursor = 0
    while cursor < len(states):
        before = states[cursor]
        if not invariant(before):
            raise AssertionError(f"oracle invariant before: {state_key(before)}")
        for event in EVENTS:
            result = transition(before, event)
            if not invariant(result.state):
                raise AssertionError(
                    f"oracle invariant after: {state_key(before)} {event} {state_key(result.state)}"
                )
            if result.outcome == "rejected" and result != rejected(before):
                raise AssertionError("rejected edge changed authority-bearing state")
            next_id = ids.get(result.state)
            if next_id is None:
                next_id = len(states)
                ids[result.state] = next_id
                states.append(result.state)
                depths.append(depths[cursor] + 1)
            edges.append(Edge(cursor, depths[cursor], event, result, next_id))
        cursor += 1
    return states, depths, edges


RESULT_VALUE = {
    "none": 0,
    "effect": 1,
    "no_effect": 2,
    "uncertain": 3,
    "fail_stop": 4,
}
KIND_VALUE = {"pending": 1, "result": 2, "publication": 3}
FIXED_ENDPOINT_ID = 0x534C4F50474A3031
RECORD_BYTES = 128


@dataclasses.dataclass(frozen=True)
class Record:
    kind: str
    sequence: int
    generation_from: int
    generation_to: int
    operation_binding: bytes
    spent_receipt_binding: bytes
    result: str
    consumed_dispatch: bool = True
    reconciled: bool = False


def record_invariant(record: Record) -> bool:
    if record.kind not in KIND_VALUE or record.result not in RESULT_VALUE:
        return False
    if not (1 <= record.sequence <= 2):
        return False
    if not (1 <= record.generation_from < (1 << 64) - 1):
        return False
    if record.generation_to != record.generation_from + 1:
        return False
    if not record.consumed_dispatch:
        return False
    if len(record.operation_binding) != 32 or not any(record.operation_binding):
        return False
    if len(record.spent_receipt_binding) != 32 or not any(record.spent_receipt_binding):
        return False
    if record.kind == "pending":
        return record.sequence == 1 and record.result == "none" and not record.reconciled
    if record.result not in ("effect", "no_effect", "uncertain", "fail_stop"):
        return False
    if record.result == "uncertain" and record.sequence != 1:
        return False
    return record.reconciled == (record.sequence == 2)


def encode_record(record: Record) -> bytes:
    if not record_invariant(record):
        raise ValueError("record invariant")
    out = bytearray(RECORD_BYTES)
    out[0:8] = b"SLOPGJ01"
    out[8] = 1
    out[9] = KIND_VALUE[record.kind]
    struct.pack_into("<H", out, 10, RECORD_BYTES)
    struct.pack_into("<Q", out, 12, record.sequence)
    struct.pack_into("<Q", out, 20, record.generation_from)
    struct.pack_into("<Q", out, 28, record.generation_to)
    out[36:68] = record.operation_binding
    out[68:100] = record.spent_receipt_binding
    struct.pack_into("<Q", out, 100, FIXED_ENDPOINT_ID)
    out[108] = RESULT_VALUE[record.result]
    out[109] = (1 if record.consumed_dispatch else 0) | (2 if record.reconciled else 0)
    struct.pack_into("<I", out, 124, zlib.crc32(out[:124]) & 0xFFFFFFFF)
    return bytes(out)


def decode_record(data: bytes) -> Record | None:
    if len(data) != RECORD_BYTES:
        return None
    if data[:8] != b"SLOPGJ01" or data[8] != 1:
        return None
    if struct.unpack_from("<H", data, 10)[0] != RECORD_BYTES:
        return None
    if struct.unpack_from("<Q", data, 100)[0] != FIXED_ENDPOINT_ID:
        return None
    if struct.unpack_from("<I", data, 124)[0] != (zlib.crc32(data[:124]) & 0xFFFFFFFF):
        return None
    if any(data[110:124]) or (data[109] & 0xFC):
        return None
    kind_by_value = {value: key for key, value in KIND_VALUE.items()}
    result_by_value = {value: key for key, value in RESULT_VALUE.items()}
    kind = kind_by_value.get(data[9])
    result = result_by_value.get(data[108])
    if kind is None or result is None:
        return None
    candidate = Record(
        kind=kind,
        sequence=struct.unpack_from("<Q", data, 12)[0],
        generation_from=struct.unpack_from("<Q", data, 20)[0],
        generation_to=struct.unpack_from("<Q", data, 28)[0],
        operation_binding=data[36:68],
        spent_receipt_binding=data[68:100],
        result=result,
        consumed_dispatch=bool(data[109] & 1),
        reconciled=bool(data[109] & 2),
    )
    return candidate if record_invariant(candidate) else None


def record_fixtures() -> list[tuple[str, Record, bytes]]:
    operation = bytes(range(1, 33))
    spent = bytes(range(161, 193))
    descriptions = (
        ("pending-v1", "pending", 1, "none", False),
        ("result-effect-v1", "result", 1, "effect", False),
        ("result-uncertain-v1", "result", 1, "uncertain", False),
        ("publication-uncertain-v1", "publication", 1, "uncertain", False),
        ("result-effect-v2", "result", 2, "effect", True),
        ("publication-effect-v2", "publication", 2, "effect", True),
    )
    result = []
    for name, kind, sequence, terminal, reconciled in descriptions:
        record = Record(
            kind=kind,
            sequence=sequence,
            generation_from=41,
            generation_to=42,
            operation_binding=operation,
            spent_receipt_binding=spent,
            result=terminal,
            reconciled=reconciled,
        )
        encoded = encode_record(record)
        if decode_record(encoded) != record:
            raise AssertionError(f"record roundtrip: {name}")
        result.append((name, record, encoded))
    return result


def mutation_campaign(fixtures: Iterable[tuple[str, Record, bytes]]) -> tuple[int, int]:
    mutations = 0
    rejected = 0
    for _name, _record, encoded in fixtures:
        for index in range(len(encoded)):
            for bit in range(8):
                mutations += 1
                mutant = bytearray(encoded)
                mutant[index] ^= 1 << bit
                if decode_record(bytes(mutant)) is None:
                    rejected += 1
    return mutations, rejected


BOUNDARY_ROWS = (
    ("hosted-receipt-begins-live", "PASS", "hosted fixture is explicit proof shape only"),
    ("planning-consumes-receipt", "PASS", "spent receipt cannot be reused in this process"),
    ("planning-is-inert-and-produces-pending", "PASS", "no invocation ticket is returned by planning"),
    ("wrong-readback-creates-no-ticket", "PASS", "mismatch fails closed"),
    ("wrong-readback-consumes-plan", "PASS", "activation attempt is one-shot"),
    ("consumed-plan-cannot-retry", "PASS", "mismatch cannot be followed by exact retry"),
    ("exact-readback-creates-one-ticket", "PASS", "ticket follows exact complete readback"),
    ("exact-readback-consumes-plan", "PASS", "successful activation is one-shot"),
    ("ticket-move-consumes-source", "PASS", "move-only proof shape"),
    ("recovery-creates-query-binding", "PASS", "recovery output is not an invocation ticket"),
    ("query-binding-is-move-only", "PASS", "one exact query use can be isolated by the future provider"),
    ("invalid-protected-observation-rejected", "PASS", "zero or discontinuous identity cannot bind recovery"),
    ("wrapped-generation-observation-rejected", "PASS", "UINT64_MAX to zero is not a successor generation"),
    ("recomputed-crc-does-not-authenticate", "PASS", "a deliberate alternate valid record with a recomputed CRC decodes"),
    ("endpoint-is-constant", "PASS", "no route is supplied by caller"),
)

HANDOFF_ROWS = (
    ("unspent", "absent", "absent", "false", "false", "may_admit_fresh"),
    ("spent_crash_before_bind", "absent", "exact", "true", "true", "query_only"),
)


def tsv(header: Iterable[str], rows: Iterable[Iterable[object]]) -> bytes:
    lines = ["\t".join(str(field) for field in header)]
    lines.extend("\t".join(str(field) for field in row) for row in rows)
    return ("\n".join(lines) + "\n").encode("utf-8")


def states_bytes(states: list[State], depths: list[int]) -> bytes:
    header = (
        "state_id",
        "depth",
        "phase",
        "endpoint",
        "result",
        "result_version",
        "published_version",
        "invocation_count",
        "effect_count",
        "receipt_bound",
        "pending_exact",
        "recovered",
        "reconciled",
        "state_key",
    )
    rows = (
        (
            index,
            depths[index],
            state.phase,
            state.endpoint,
            state.result,
            state.result_version,
            state.published_version,
            state.invocation_count,
            state.effect_count,
            b(state.receipt_bound),
            b(state.pending_exact),
            b(state.recovered),
            b(state.reconciled),
            state_key(state),
        )
        for index, state in enumerate(states)
    )
    return tsv(header, rows)


def relation_bytes(states: list[State], edges: list[Edge]) -> bytes:
    header = (
        "state_id",
        "depth",
        "event",
        "outcome",
        "next_state_id",
        "endpoint_apply_called",
        "result_refined",
        "publication_appended",
        "dispatch_minted",
        "before_key",
        "after_key",
    )
    rows = (
        (
            edge.state_id,
            edge.depth,
            edge.event,
            edge.step.outcome,
            edge.next_state_id,
            b(edge.step.endpoint_apply_called),
            b(edge.step.result_refined),
            b(edge.step.publication_appended),
            b(edge.step.dispatch_minted),
            state_key(states[edge.state_id]),
            state_key(edge.step.state),
        )
        for edge in edges
    )
    return tsv(header, rows)


def first_edge(
    edges: list[Edge], states: list[State], event: str, predicate: Callable[[State], bool]
) -> Edge:
    for edge in edges:
        if edge.event == event and predicate(states[edge.state_id]):
            return edge
    raise AssertionError(f"missing witness: {event}")


def witnesses_bytes(states: list[State], edges: list[Edge]) -> bytes:
    predicates: tuple[tuple[str, str, Callable[[State], bool]], ...] = (
        ("recovery_apply_is_rejected", "recovery_apply_attempt", lambda s: s.phase == "uncertain" and s.recovered and s.pending_exact),
        ("dispatch_mint_is_rejected", "mint_dispatch_attempt", lambda s: s.phase == "uncertain"),
        ("route_override_is_rejected", "route_override_attempt", lambda s: s.phase == "ready"),
        ("retry_apply_is_rejected", "retry_apply_attempt", lambda s: s.phase == "uncertain" and s.pending_exact),
        ("published_uncertainty_refines_to_effect_v2", "query_successor_same", lambda s: s.phase == "uncertain" and s.endpoint == "successor_same" and s.result == "uncertain" and s.result_version == 1 and s.published_version == 1 and s.pending_exact),
        ("refined_effect_publication_appends_v2", "publish", lambda s: s.phase == "terminal" and s.result == "effect" and s.result_version == 2 and s.published_version == 1),
        ("query_predecessor_refines_no_effect", "query_predecessor", lambda s: s.phase == "uncertain" and s.endpoint == "predecessor" and s.pending_exact),
        ("query_other_successor_fail_stops", "query_successor_other", lambda s: s.phase == "uncertain" and s.endpoint == "successor_other" and s.pending_exact),
        ("missing_spent_receipt_preserves_uncertainty", "recover_spent_receipt_missing", lambda s: s.phase == "uncertain" and s.recovered and not s.pending_exact),
        ("exact_spent_receipt_enables_query_only", "recover_spent_receipt_exact", lambda s: s.phase == "uncertain" and s.recovered and not s.pending_exact),
        ("malformed_after_effect_is_uncertain", "invoke_malformed_after_effect", lambda s: s.phase == "ready" and s.endpoint == "predecessor"),
        ("other_successor_before_invoke_fail_stops", "invoke_effect_return", lambda s: s.phase == "ready" and s.endpoint == "successor_other"),
        ("query_unavailable_preserves_uncertainty", "query_unavailable", lambda s: s.phase == "uncertain" and s.pending_exact),
        ("stale_publication_is_rejected", "stale_publication_attempt", lambda s: s.result != "none" and s.published_version == s.result_version),
    )
    header = (
        "name",
        "state_id",
        "event",
        "outcome",
        "next_state_id",
        "before_result",
        "before_version",
        "before_published",
        "after_result",
        "after_version",
        "after_published",
        "endpoint_apply_called",
        "result_refined",
        "publication_appended",
        "dispatch_minted",
    )
    rows = []
    for name, event, predicate in predicates:
        edge = first_edge(edges, states, event, predicate)
        before = states[edge.state_id]
        after = edge.step.state
        rows.append(
            (
                name,
                edge.state_id,
                edge.event,
                edge.step.outcome,
                edge.next_state_id,
                before.result,
                before.result_version,
                before.published_version,
                after.result,
                after.result_version,
                after.published_version,
                b(edge.step.endpoint_apply_called),
                b(edge.step.result_refined),
                b(edge.step.publication_appended),
                b(edge.step.dispatch_minted),
            )
        )
    return tsv(header, rows)


def records_bytes(fixtures: list[tuple[str, Record, bytes]]) -> bytes:
    header = (
        "fixture",
        "kind",
        "sequence",
        "generation_from",
        "generation_to",
        "result",
        "reconciled",
        "bytes",
        "hex",
    )
    rows = (
        (
            name,
            record.kind,
            record.sequence,
            record.generation_from,
            record.generation_to,
            record.result,
            b(record.reconciled),
            len(encoded),
            encoded.hex(),
        )
        for name, record, encoded in fixtures
    )
    return tsv(header, rows)


def expected_summary(
    states: list[State], edges: list[Edge], mutations: int, rejected_mutations: int
) -> dict[str, object]:
    return {
        "applied_edges": sum(edge.step.outcome == "applied" for edge in edges),
        "boundary_checks": len(BOUNDARY_ROWS),
        "candidate_reference_disagreements": 0,
        "dispatch_mints": sum(edge.step.dispatch_minted for edge in edges),
        "endpoint_apply_edges": sum(edge.step.endpoint_apply_called for edge in edges),
        "events_per_state": len(EVENTS),
        "handoff_indistinguishable_local_pairs": 1,
        "maximum_effect_count": max(state.effect_count for state in states),
        "maximum_invocation_count": max(state.invocation_count for state in states),
        "publication_append_edges": sum(edge.step.publication_appended for edge in edges),
        "published_revision2_states": sum(state.published_version == 2 for state in states),
        "published_uncertain_states": sum(state.result == "uncertain" and state.published_version == 1 for state in states),
        "record_bit_mutations": mutations,
        "record_bit_mutations_rejected": rejected_mutations,
        "record_bytes": RECORD_BYTES,
        "record_fixtures": 6,
        "result_refinement_edges": sum(edge.step.result_refined for edge in edges),
        "schema": "slopos.rev0886.generation-journal-summary.v1",
        "states": len(states),
        "status": "PASS",
        "transitions": len(edges),
        "version2_states": sum(state.result_version == 2 for state in states),
    }


def summary_bytes(summary: dict[str, object]) -> bytes:
    # C++ emits this exact key order and two-space indentation.
    return (json.dumps(summary, indent=2, ensure_ascii=True) + "\n").encode("utf-8")


def compare(path: Path, expected: bytes) -> None:
    try:
        observed = path.read_bytes()
    except OSError as exc:
        raise AssertionError(f"cannot read {path}: {exc}") from exc
    if observed != expected:
        mismatch = next(
            (i for i, (left, right) in enumerate(zip(observed, expected)) if left != right),
            min(len(observed), len(expected)),
        )
        raise AssertionError(
            f"byte disagreement {path.name} at {mismatch}: observed={len(observed)} expected={len(expected)}"
        )


def verify(output: Path) -> dict[str, object]:
    states, depths, edges = construct_relation()
    fixtures = record_fixtures()
    mutations, rejected_mutations = mutation_campaign(fixtures)
    if mutations != 6144 or rejected_mutations != mutations:
        raise AssertionError(
            f"record mutation oracle: {rejected_mutations}/{mutations} rejected"
        )
    summary = expected_summary(states, edges, mutations, rejected_mutations)

    expected_files = {
        "states.tsv": states_bytes(states, depths),
        "relation.tsv": relation_bytes(states, edges),
        "witnesses.tsv": witnesses_bytes(states, edges),
        "records.tsv": records_bytes(fixtures),
        "boundary.tsv": tsv(("check", "status", "detail"), BOUNDARY_ROWS),
        "handoff-counterexample.tsv": tsv(
            (
                "world",
                "local_journal",
                "protected_spent_identity",
                "gate_consumed",
                "endpoint_may_have_effect",
                "recovery_right",
            ),
            HANDOFF_ROWS,
        ),
        "summary.json": summary_bytes(summary),
    }
    for name, expected in expected_files.items():
        compare(output / name, expected)

    # The pair has the same local journal observation but different consumed
    # authority facts; no local-only recovery function can distinguish it.
    local_projection = {(row[1],) for row in HANDOFF_ROWS}
    authority_projection = {(row[2], row[3], row[4], row[5]) for row in HANDOFF_ROWS}
    if len(local_projection) != 1 or len(authority_projection) != 2:
        raise AssertionError("handoff indistinguishability witness collapsed")

    return {
        "schema": "slopos.rev0886.generation-journal-audit.v1",
        "status": "PASS",
        "checked_files": sorted(expected_files),
        "states": len(states),
        "events": len(EVENTS),
        "transitions": len(edges),
        "applied_edges": summary["applied_edges"],
        "python_relation_disagreements": 0,
        "record_codec_disagreements": 0,
        "record_bit_mutations": mutations,
        "record_bit_mutations_rejected": rejected_mutations,
        "handoff_counterexample_pairs": 1,
        "dispatch_mints": 0,
        "maximum_invocation_count": summary["maximum_invocation_count"],
        "maximum_effect_count": summary["maximum_effect_count"],
        "result_refinement_edges": summary["result_refinement_edges"],
        "publication_append_edges": summary["publication_append_edges"],
    }


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path, help="campaign output directory")
    parser.add_argument("--json", type=Path, help="optional audit output path")
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    try:
        audit = verify(args.output.resolve())
        if args.json is not None:
            args.json.parent.mkdir(parents=True, exist_ok=True)
            args.json.write_text(
                json.dumps(audit, indent=2, sort_keys=True) + "\n",
                encoding="utf-8",
            )
        print(
            "GENERATION_JOURNAL_AUDIT=PASS "
            f"states={audit['states']} events={audit['events']} "
            f"transitions={audit['transitions']} "
            f"record_mutations={audit['record_bit_mutations_rejected']} "
            f"handoff_pairs={audit['handoff_counterexample_pairs']} "
            "dispatch_mints=0"
        )
        return 0
    except (AssertionError, OSError, ValueError) as exc:
        print(f"GENERATION_JOURNAL_AUDIT=FAIL detail={exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
