# Counterexample: split append and endpoint entry leaves an uncertainty gap

## Tempting construction

```text
1. compare-and-append exact spend to protected floor
2. receive success
3. enqueue endpoint work
```

Each individual operation may be atomic. Their composition is not.

## Reachable trace

```text
S0: floor=(g,H), no endpoint entry
S1: floor=(g+1,H'), no endpoint entry     # append committed
CRASH
```

After reopen, exact spend is consumed but there is no protected fact proving
that endpoint work was entered. Retrying the endpoint risks duplication if the
entry actually happened in a different failure world; refusing it may lose an
effect if it did not. A success response cannot repair the gap because response
bytes are copyable and may never have reached the caller.

The rev0894 harness constructs `S1` deliberately by bypassing the joined API.
Independent observation sees the exact successor and zero entries and
classifies the image malformed/uncertain/fail-stop.

## Correction

The exact floor successor and fixed endpoint-admission row must become visible
in one protected commit domain, or the provider must expose an equivalent
single transition whose no-split property is independently proved. Recovery
may then observe `unused`, `exact pending`, `exact settled`, or bounded
uncertainty. It may not mint a fresh endpoint entry from detached response data.

The hosted SQLite transaction exercises this relation locally. Its coherent
rollback-clone counterexample keeps the global provider obligation open.
