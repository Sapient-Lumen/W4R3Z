# Counterexample: blind monotonic update is not compare-and-append

Suppose contenders A and B both prepared against predecessor `(41, H)`.

With a blind increment, A may increment 41 to 42 and stale B may then increment
42 to 43. Both calls report successful monotonic updates. The success result
does not say that the caller's expected predecessor was current, nor does it
bind the winning spend record.

With a blind extend, A may extend the current digest and stale B may then extend
again. Both records can appear in an ordered history, but both callers were
accepted even though only one could own the one-use admission from `(41, H)`.

Serialization is not conditional admission. The required primitive compares
the complete expected predecessor `(generation, head)` and appends the exact
record atomically, returning `conflict` to every stale or foreign contender.
