# Checkpoint transport commit and exact-final reconciliation

A nested C++20 proof leaf under `generation_journal`. V1 corrected a custody
failure in the checkpoint closer: a canonical final ZIP name must never be a
progress sink. V2 closes the next finite seam: a crash after no-replace rename
can leave a complete canonical final while the caller never receives success.

`publish` still requires an absent final. It copies a complete candidate into a
same-parent hidden stage, compares the bytes, makes the stage read-only,
synchronizes it, commits with Linux `renameat2(..., RENAME_NOREPLACE)`, then
synchronizes the pinned parent directory. It never adopts an existing final.

`reconcile` is separate and explicit. It requires an existing regular `0444`
final, compares it exactly with the caller-supplied candidate under stable
source/final descriptor observations, synchronizes the final and parent, and
returns without content writes, chmod, unlink, rename, or replacement. An
absent, conflicting, symlinked, nonregular, mutable, or wrong-mode final fails
closed. Reconciliation establishes exact equality and the operated fsync
protocol only; it does not infer who wrote the final or whether a previous
attempt performed any particular step.

Source, final, and parent traversal use `openat2` with `RESOLVE_BENEATH`,
`RESOLVE_NO_SYMLINKS`, and `RESOLVE_NO_MAGICLINKS` from pinned descriptors.

This is not a sixth product target or fourth semantic island. It proves a
bounded local publication/recovery relation, not stable media, remote-filesystem
semantics, exclusive writer custody, writer authenticity, owner ratification,
living admission, authority, or epoch exit.
