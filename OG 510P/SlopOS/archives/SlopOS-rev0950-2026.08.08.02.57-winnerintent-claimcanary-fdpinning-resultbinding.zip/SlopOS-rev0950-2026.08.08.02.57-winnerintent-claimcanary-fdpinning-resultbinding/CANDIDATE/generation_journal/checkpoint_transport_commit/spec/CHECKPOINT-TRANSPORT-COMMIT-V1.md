# Checkpoint Transport Commit V1

## Subject

Publish one already complete regular checkpoint archive from `SOURCE` to one
absent canonical `FINAL` pathname. The operation runs only on the Linux local
profile used by this cloudtainer.

## Preconditions

- `SOURCE` is an existing regular file reached with `openat2` from a pinned root
  descriptor using `RESOLVE_BENEATH`, `RESOLVE_NO_SYMLINKS`, and
  `RESOLVE_NO_MAGICLINKS`.
- `FINAL` has a regular directory parent reached under the same resolution
  policy, and its leaf is absent.
- The source and final parent may differ; the temporary stage is always in the
  final's same parent directory.

## Transition

1. Create a hidden same-parent stage with `O_CREAT|O_EXCL|O_NOFOLLOW`.
2. Copy all source bytes to the stage. No descriptor to `FINAL` is opened and
   the final leaf receives zero progressive writes.
3. Re-stat the source and compare source and stage bytes exactly.
4. Set the stage mode to `0444` and `fsync` the staged file.
5. Commit with `renameat2(..., RENAME_NOREPLACE)` in the pinned parent.
6. `fsync` the parent directory before reporting success.

## Crash cuts

- after stage create, first write, copy, or file `fsync`: `FINAL` remains absent;
  an incomplete hidden stage may remain and is not canonical.
- after rename but before parent `fsync`: the visible final is complete, while
  directory durability is explicitly unclaimed.
- successful return: file and parent-directory synchronization calls completed.

## Fail-closed properties

An existing regular final, an existing final symlink, a source symlink, parent
symlink traversal, a nonregular source, source mutation, short copy, or
`RENAME_NOREPLACE` collision fails without replacing the pre-existing leaf.

## Nonclaims

Namespace atomicity is narrower than stable-media persistence. This leaf does
not prove hardware write-cache behavior, mount-option semantics, network or
remote filesystem behavior, kernel correctness, exclusive writer custody,
archive authenticity, owner ratification, living-project admission, release,
or Epoch-Zero exit. `fsync` records the operated protocol and successful system
calls, not an external durability oracle.
