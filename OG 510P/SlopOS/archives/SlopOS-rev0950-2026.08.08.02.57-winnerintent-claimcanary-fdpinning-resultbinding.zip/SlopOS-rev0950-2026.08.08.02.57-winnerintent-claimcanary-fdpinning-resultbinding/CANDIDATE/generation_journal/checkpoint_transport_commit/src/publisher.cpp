#include "slopos/e0/generation_journal/checkpoint_transport_commit/publisher.hpp"

#include <algorithm>
#include <array>
#include <cerrno>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <fcntl.h>
#include <filesystem>
#include <optional>
#include <stdexcept>
#include <string>
#include <string_view>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <unistd.h>

#include <linux/openat2.h>

namespace slopos::e0::generation_journal::checkpoint_transport_commit {
namespace {

constexpr int kCrashExit = 86;
constexpr std::size_t kBufferBytes = 1U << 20U;

class Fd final {
 public:
  explicit Fd(int value = -1) noexcept : value_(value) {}
  ~Fd() {
    if (value_ >= 0) {
      (void)::close(value_);
    }
  }
  Fd(const Fd&) = delete;
  Fd& operator=(const Fd&) = delete;
  Fd(Fd&& other) noexcept : value_(other.value_) { other.value_ = -1; }
  Fd& operator=(Fd&& other) noexcept {
    if (this != &other) {
      if (value_ >= 0) {
        (void)::close(value_);
      }
      value_ = other.value_;
      other.value_ = -1;
    }
    return *this;
  }
  [[nodiscard]] int get() const noexcept { return value_; }

 private:
  int value_;
};

[[noreturn]] void system_error(std::string_view operation) {
  throw std::runtime_error(std::string(operation) + ": " + std::strerror(errno));
}

[[nodiscard]] std::string root_relative(const std::filesystem::path& input) {
  const auto absolute = std::filesystem::absolute(input).lexically_normal();
  if (!absolute.is_absolute()) {
    throw std::runtime_error("path did not become absolute");
  }
  std::string text = absolute.generic_string();
  if (text.empty() || text.front() != '/') {
    throw std::runtime_error("absolute path has no root slash");
  }
  text.erase(text.begin());
  if (text.empty()) {
    throw std::runtime_error("root itself is not an admissible object");
  }
  return text;
}

[[nodiscard]] Fd open_root() {
  const int value = ::open("/", O_PATH | O_DIRECTORY | O_CLOEXEC);
  if (value < 0) {
    system_error("open root");
  }
  return Fd(value);
}

[[nodiscard]] Fd open_beneath(int root, const std::filesystem::path& path,
                              std::uint64_t flags, std::uint64_t mode = 0) {
  const std::string relative = root_relative(path);
  open_how how{};
  how.flags = flags;
  how.mode = mode;
  how.resolve = RESOLVE_BENEATH | RESOLVE_NO_SYMLINKS | RESOLVE_NO_MAGICLINKS;
  const int value = static_cast<int>(
      ::syscall(SYS_openat2, root, relative.c_str(), &how, sizeof(how)));
  if (value < 0) {
    system_error("openat2 " + relative);
  }
  return Fd(value);
}

[[nodiscard]] Fd open_leaf_beneath(int parent, std::string_view leaf,
                                   std::uint64_t flags) {
  if (leaf.empty() || leaf == "." || leaf == ".." || leaf.find('/') != std::string_view::npos) {
    throw std::runtime_error("invalid final leaf");
  }
  open_how how{};
  how.flags = flags;
  how.resolve = RESOLVE_BENEATH | RESOLVE_NO_SYMLINKS | RESOLVE_NO_MAGICLINKS;
  const std::string owned(leaf);
  const int value = static_cast<int>(
      ::syscall(SYS_openat2, parent, owned.c_str(), &how, sizeof(how)));
  if (value < 0) {
    system_error("openat2 final leaf " + owned);
  }
  return Fd(value);
}

[[nodiscard]] struct stat stat_fd(int fd) {
  struct stat result {};
  if (::fstat(fd, &result) != 0) {
    system_error("fstat");
  }
  return result;
}

[[nodiscard]] bool same_identity(const struct stat& lhs,
                                 const struct stat& rhs) noexcept {
  return lhs.st_dev == rhs.st_dev && lhs.st_ino == rhs.st_ino &&
         lhs.st_size == rhs.st_size &&
         lhs.st_mtim.tv_sec == rhs.st_mtim.tv_sec &&
         lhs.st_mtim.tv_nsec == rhs.st_mtim.tv_nsec &&
         lhs.st_ctim.tv_sec == rhs.st_ctim.tv_sec &&
         lhs.st_ctim.tv_nsec == rhs.st_ctim.tv_nsec;
}

[[nodiscard]] std::uint64_t regular_size(const struct stat& value,
                                         std::string_view label) {
  if (!S_ISREG(value.st_mode)) {
    throw std::runtime_error(std::string(label) + " is not regular");
  }
  if (value.st_size < 0) {
    throw std::runtime_error(std::string(label) + " has negative size");
  }
  return static_cast<std::uint64_t>(value.st_size);
}

void require_unchanged(const struct stat& before, int fd,
                       std::string_view label) {
  if (!same_identity(before, stat_fd(fd))) {
    throw std::runtime_error(std::string(label) + " changed during operation");
  }
}

void crash_if(std::optional<CrashCut> selected, CrashCut here) noexcept {
  if (selected.has_value() && selected.value() == here) {
    ::_exit(kCrashExit);
  }
}

void crash_if(std::optional<ReconcileCrashCut> selected,
              ReconcileCrashCut here) noexcept {
  if (selected.has_value() && selected.value() == here) {
    ::_exit(kCrashExit);
  }
}

void write_all(int fd, const std::byte* data, std::size_t count) {
  std::size_t offset = 0;
  while (offset < count) {
    const auto remaining = count - offset;
    const ssize_t wrote = ::write(fd, data + offset, remaining);
    if (wrote < 0) {
      if (errno == EINTR) {
        continue;
      }
      system_error("write stage");
    }
    if (wrote == 0) {
      throw std::runtime_error("zero-length write to stage");
    }
    offset += static_cast<std::size_t>(wrote);
  }
}

void seek_start(int fd, std::string_view label) {
  if (::lseek(fd, 0, SEEK_SET) < 0) {
    system_error("lseek " + std::string(label));
  }
}

void compare_exact(int lhs_fd, std::string_view lhs_label,
                   int rhs_fd, std::string_view rhs_label,
                   std::uint64_t expected_bytes) {
  seek_start(lhs_fd, lhs_label);
  seek_start(rhs_fd, rhs_label);
  std::array<std::byte, kBufferBytes> lhs{};
  std::array<std::byte, kBufferBytes> rhs{};
  std::uint64_t compared = 0;
  for (;;) {
    ssize_t left;
    do {
      left = ::read(lhs_fd, lhs.data(), lhs.size());
    } while (left < 0 && errno == EINTR);
    if (left < 0) {
      system_error("read " + std::string(lhs_label));
    }
    ssize_t right;
    do {
      right = ::read(rhs_fd, rhs.data(), rhs.size());
    } while (right < 0 && errno == EINTR);
    if (right < 0) {
      system_error("read " + std::string(rhs_label));
    }
    if (left != right) {
      throw std::runtime_error("exact comparison length disagreement");
    }
    if (left == 0) {
      break;
    }
    const auto size = static_cast<std::size_t>(left);
    if (!std::equal(lhs.begin(), lhs.begin() + static_cast<std::ptrdiff_t>(size),
                    rhs.begin())) {
      throw std::runtime_error("exact comparison byte disagreement");
    }
    compared += static_cast<std::uint64_t>(size);
  }
  if (compared != expected_bytes) {
    throw std::runtime_error("exact comparison byte count disagreement");
  }
}

[[nodiscard]] std::string make_stage_leaf(std::string_view final_leaf) {
  static std::uint64_t serial = 0;
  ++serial;
  const std::string suffix = ".slopos-transport-stage-" +
                             std::to_string(::getpid()) + "-" +
                             std::to_string(serial);
  if (final_leaf.size() + suffix.size() > 240U) {
    throw std::runtime_error("final leaf too long for bounded stage name");
  }
  return "." + std::string(final_leaf) + suffix;
}

[[nodiscard]] Fd create_stage(int parent, const std::string& leaf) {
  const int value = ::openat(parent, leaf.c_str(),
                             O_RDWR | O_CREAT | O_EXCL | O_NOFOLLOW | O_CLOEXEC,
                             0600);
  if (value < 0) {
    system_error("create same-parent stage");
  }
  return Fd(value);
}

void unlink_stage(int parent, const std::string& leaf) noexcept {
  (void)::unlinkat(parent, leaf.c_str(), 0);
}

struct FinalLocation {
  std::filesystem::path absolute;
  std::filesystem::path parent_path;
  std::string leaf;
};

[[nodiscard]] FinalLocation final_location(
    const std::filesystem::path& final_path) {
  FinalLocation result{};
  result.absolute = std::filesystem::absolute(final_path).lexically_normal();
  result.parent_path = result.absolute.parent_path();
  result.leaf = result.absolute.filename().string();
  if (result.leaf.empty() || result.leaf == "." || result.leaf == "..") {
    throw std::runtime_error("invalid final leaf");
  }
  return result;
}

}  // namespace

std::optional<CrashCut> parse_crash_cut(std::string_view text) {
  if (text == "after-stage-create") {
    return CrashCut::after_stage_create;
  }
  if (text == "after-first-write") {
    return CrashCut::after_first_write;
  }
  if (text == "after-copy") {
    return CrashCut::after_copy;
  }
  if (text == "after-file-fsync") {
    return CrashCut::after_file_fsync;
  }
  if (text == "after-rename") {
    return CrashCut::after_rename;
  }
  return std::nullopt;
}

std::optional<ReconcileCrashCut> parse_reconcile_crash_cut(
    std::string_view text) {
  if (text == "after-final-fsync") {
    return ReconcileCrashCut::after_final_fsync;
  }
  if (text == "after-parent-fsync") {
    return ReconcileCrashCut::after_parent_fsync;
  }
  return std::nullopt;
}

PublishResult publish_complete_archive(
    const std::filesystem::path& source_path,
    const std::filesystem::path& final_path,
    std::optional<CrashCut> crash_cut) {
  const FinalLocation final = final_location(final_path);

  Fd root = open_root();
  Fd source = open_beneath(root.get(), source_path,
                           O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
  const struct stat source_before = stat_fd(source.get());
  const std::uint64_t source_bytes = regular_size(source_before, "source");

  Fd parent = open_beneath(root.get(), final.parent_path,
                           O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
  struct stat final_existing {};
  if (::fstatat(parent.get(), final.leaf.c_str(), &final_existing,
                AT_SYMLINK_NOFOLLOW) == 0) {
    throw std::runtime_error("final already exists");
  }
  if (errno != ENOENT) {
    system_error("inspect final");
  }

  const std::string stage_leaf = make_stage_leaf(final.leaf);
  Fd stage = create_stage(parent.get(), stage_leaf);
  bool stage_named = true;
  try {
    crash_if(crash_cut, CrashCut::after_stage_create);
    std::array<std::byte, kBufferBytes> buffer{};
    std::uint64_t copied = 0;
    bool first_write = true;
    for (;;) {
      ssize_t got;
      do {
        got = ::read(source.get(), buffer.data(), buffer.size());
      } while (got < 0 && errno == EINTR);
      if (got < 0) {
        system_error("read source");
      }
      if (got == 0) {
        break;
      }
      const auto count = static_cast<std::size_t>(got);
      write_all(stage.get(), buffer.data(), count);
      copied += static_cast<std::uint64_t>(count);
      if (first_write) {
        first_write = false;
        crash_if(crash_cut, CrashCut::after_first_write);
      }
    }
    crash_if(crash_cut, CrashCut::after_copy);

    require_unchanged(source_before, source.get(), "source");
    if (copied != source_bytes) {
      throw std::runtime_error("source size changed or copy truncated");
    }
    compare_exact(source.get(), "source", stage.get(), "stage", copied);
    // Close the rev0935 observation gap: comparison is followed by another
    // source identity check before the staged bytes can become canonical.
    require_unchanged(source_before, source.get(), "source");
    if (::fchmod(stage.get(), 0444) != 0) {
      system_error("fchmod stage");
    }
    if (::fsync(stage.get()) != 0) {
      system_error("fsync stage");
    }
    crash_if(crash_cut, CrashCut::after_file_fsync);

    const long renamed = ::syscall(SYS_renameat2, parent.get(),
                                   stage_leaf.c_str(), parent.get(),
                                   final.leaf.c_str(), RENAME_NOREPLACE);
    if (renamed != 0) {
      system_error("renameat2 RENAME_NOREPLACE");
    }
    stage_named = false;
    crash_if(crash_cut, CrashCut::after_rename);
    if (::fsync(parent.get()) != 0) {
      system_error("fsync parent directory");
    }
    return PublishResult{copied, true, true};
  } catch (...) {
    if (stage_named) {
      unlink_stage(parent.get(), stage_leaf);
    }
    throw;
  }
}

ReconcileResult reconcile_exact_existing_archive(
    const std::filesystem::path& source_path,
    const std::filesystem::path& final_path,
    std::optional<ReconcileCrashCut> crash_cut) {
  const FinalLocation final = final_location(final_path);

  Fd root = open_root();
  Fd source = open_beneath(root.get(), source_path,
                           O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
  Fd parent = open_beneath(root.get(), final.parent_path,
                           O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
  Fd existing = open_leaf_beneath(parent.get(), final.leaf,
                                  O_RDONLY | O_CLOEXEC | O_NOFOLLOW);

  const struct stat source_before = stat_fd(source.get());
  const struct stat final_before = stat_fd(existing.get());
  const std::uint64_t source_bytes = regular_size(source_before, "source");
  const std::uint64_t final_bytes = regular_size(final_before, "existing final");
  if ((final_before.st_mode & 07777) != 0444) {
    throw std::runtime_error("existing final mode is not exactly 0444");
  }
  if (source_bytes != final_bytes) {
    throw std::runtime_error("existing final length disagreement");
  }

  compare_exact(source.get(), "source", existing.get(), "existing final",
                source_bytes);
  require_unchanged(source_before, source.get(), "source");
  require_unchanged(final_before, existing.get(), "existing final");

  if (::fsync(existing.get()) != 0) {
    system_error("fsync existing final");
  }
  crash_if(crash_cut, ReconcileCrashCut::after_final_fsync);

  // A second exact observation after final fsync prevents return from being
  // based only on bytes observed before synchronization.
  compare_exact(source.get(), "source", existing.get(), "existing final",
                source_bytes);
  require_unchanged(source_before, source.get(), "source");
  require_unchanged(final_before, existing.get(), "existing final");

  if (::fsync(parent.get()) != 0) {
    system_error("fsync parent directory");
  }
  crash_if(crash_cut, ReconcileCrashCut::after_parent_fsync);

  require_unchanged(source_before, source.get(), "source");
  require_unchanged(final_before, existing.get(), "existing final");
  return ReconcileResult{source_bytes, true, true, true, 0, 0};
}

}  // namespace slopos::e0::generation_journal::checkpoint_transport_commit
