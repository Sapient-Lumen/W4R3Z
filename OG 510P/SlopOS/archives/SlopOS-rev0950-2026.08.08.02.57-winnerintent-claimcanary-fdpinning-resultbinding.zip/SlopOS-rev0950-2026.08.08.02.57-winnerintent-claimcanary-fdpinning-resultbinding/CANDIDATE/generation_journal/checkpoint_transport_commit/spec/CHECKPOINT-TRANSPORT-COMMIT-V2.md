# Checkpoint Transport Commit V2 — explicit exact-final reconciliation

## Two operations, not one permissive operation

V2 preserves the V1 first-attempt rule and adds a disjoint recovery rule.

- `publish(SOURCE, ABSENT_FINAL)` creates one canonical final by complete
  same-parent staging and `RENAME_NOREPLACE`. Any existing leaf is rejection.
- `reconcile(SOURCE, EXISTING_FINAL)` creates nothing and replaces nothing. It
  may return success only for an existing regular file with mode exactly `0444`
  and bytes exactly equal to `SOURCE` under stable descriptor observations.

The caller chooses reconciliation only after it has an external reason to treat
a previous publication result as uncertain. Exact equality is necessary for
recovery but is not evidence of provenance.

## Reconciliation preconditions

- `SOURCE`, the final parent, and `EXISTING_FINAL` are reached from pinned
  descriptors with Linux `openat2` using `RESOLVE_BENEATH`,
  `RESOLVE_NO_SYMLINKS`, and `RESOLVE_NO_MAGICLINKS`.
- Source and final are regular files; source size is nonnegative.
- Final mode is exactly `0444`; final length equals source length.

## Reconciliation transition

1. Pin source, final parent, and existing final descriptors.
2. Compare every source/final byte exactly.
3. Re-stat both descriptors and reject any identity/size/mtime/ctime change.
4. `fsync` the existing final.
5. Compare every byte again and repeat both stability checks.
6. `fsync` the pinned parent directory.
7. Re-stat both descriptors again, then return
   `EXACT_EXISTING_RECONCILED`.

The operation performs zero final-content writes, zero renames, zero unlinks,
and zero chmod calls.

## Crash cuts and idempotent query recovery

- after final `fsync`, before parent `fsync`;
- after parent `fsync`, before return.

Either cut leaves the same existing final pathname and bytes. An explicit
reconciliation retry re-runs the exact query and synchronization protocol; it
does not publish again and cannot replace a conflicting object.

## Publication strengthening

V2 adds a source identity check after the exact source/stage comparison and
before staged bytes can become canonical. This narrows a V1 observation gap but
does not establish exclusive writer custody.

## Fail-closed cases

Absent final, byte or length disagreement, wrong mode, final symlink, parent
symlink traversal, source symlink, nonregular source/final, or observed source or
final mutation rejects without replacing or rewriting the final.

## Nonclaims

A successful reconciliation says only that this invocation observed exact
source/final equality and completed final/parent `fsync` calls under the operated
Linux local profile. It does not establish that this program created the final,
that the prior attempt reached rename or fsync, that no concurrent writer ever
existed, stable-media persistence, hardware cache behavior, mount-option or
remote-filesystem semantics, archive authenticity, owner ratification, living
admission, authority, or Epoch-Zero exit.
