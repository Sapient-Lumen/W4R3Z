#include "slopos/e0/generation_journal/checkpoint_transport_commit/publisher.hpp"

#include <filesystem>
#include <iostream>
#include <stdexcept>
#include <string_view>

namespace transport =
    slopos::e0::generation_journal::checkpoint_transport_commit;

int main(int argc, char** argv) {
  try {
    if (argc == 4 && std::string_view(argv[1]) == "publish") {
      const auto result =
          transport::publish_complete_archive(argv[2], argv[3]);
      std::cout << "CHECKPOINT_TRANSPORT_COMMIT=PASS bytes=" << result.bytes
                << " file_fsync=true parent_fsync=true"
                   " progressive_final_writes=0\n";
      return 0;
    }
    if (argc == 5 && std::string_view(argv[1]) == "crash") {
      const auto cut = transport::parse_crash_cut(argv[2]);
      if (!cut.has_value()) {
        throw std::runtime_error("unknown publication crash cut");
      }
      (void)transport::publish_complete_archive(argv[3], argv[4], cut);
      throw std::runtime_error("selected publication crash cut did not terminate");
    }
    if (argc == 4 && std::string_view(argv[1]) == "reconcile") {
      const auto result =
          transport::reconcile_exact_existing_archive(argv[2], argv[3]);
      std::cout << "CHECKPOINT_TRANSPORT_RECONCILE=PASS bytes="
                << result.bytes
                << " exact_existing=true final_fsync=true parent_fsync=true"
                   " final_content_writes=0 rename_calls=0 provenance_inferred=false\n";
      return 0;
    }
    if (argc == 5 && std::string_view(argv[1]) == "crash-reconcile") {
      const auto cut = transport::parse_reconcile_crash_cut(argv[2]);
      if (!cut.has_value()) {
        throw std::runtime_error("unknown reconciliation crash cut");
      }
      (void)transport::reconcile_exact_existing_archive(argv[3], argv[4], cut);
      throw std::runtime_error("selected reconciliation crash cut did not terminate");
    }
    std::cerr
        << "usage: " << argv[0]
        << " publish SOURCE ABSENT_FINAL"
           " | crash CUT SOURCE ABSENT_FINAL"
           " | reconcile SOURCE EXISTING_FINAL"
           " | crash-reconcile CUT SOURCE EXISTING_FINAL\n";
    return 64;
  } catch (const std::exception& error) {
    std::cerr << "CHECKPOINT_TRANSPORT_COMMIT=FAIL detail=" << error.what()
              << "\n";
    return 1;
  }
}
