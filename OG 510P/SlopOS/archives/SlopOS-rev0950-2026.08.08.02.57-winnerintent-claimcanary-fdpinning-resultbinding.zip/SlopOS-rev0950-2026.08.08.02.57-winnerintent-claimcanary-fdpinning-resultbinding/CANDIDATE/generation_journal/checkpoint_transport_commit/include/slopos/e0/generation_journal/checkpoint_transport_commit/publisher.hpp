#pragma once

#include <cstdint>
#include <filesystem>
#include <optional>
#include <string_view>

namespace slopos::e0::generation_journal::checkpoint_transport_commit {

enum class CrashCut : std::uint8_t {
  after_stage_create,
  after_first_write,
  after_copy,
  after_file_fsync,
  after_rename,
};

enum class ReconcileCrashCut : std::uint8_t {
  after_final_fsync,
  after_parent_fsync,
};

struct PublishResult {
  std::uint64_t bytes{};
  bool file_fsync_before_rename{};
  bool parent_fsync_after_rename{};
};

struct ReconcileResult {
  std::uint64_t bytes{};
  bool exact_existing_final{};
  bool final_fsync{};
  bool parent_fsync{};
  std::uint64_t final_content_writes{};
  std::uint64_t rename_calls{};
};

[[nodiscard]] std::optional<CrashCut> parse_crash_cut(std::string_view text);
[[nodiscard]] std::optional<ReconcileCrashCut> parse_reconcile_crash_cut(std::string_view text);

[[nodiscard]] PublishResult publish_complete_archive(
    const std::filesystem::path& source,
    const std::filesystem::path& absent_final,
    std::optional<CrashCut> crash_cut = std::nullopt);

// Explicit recovery for a caller that already has evidence of post-commit
// uncertainty. This operation never creates, replaces, chmods, unlinks, or
// writes the final. It accepts only an existing regular 0444 final whose bytes
// are exactly equal to SOURCE under stable descriptor observations, then
// synchronizes the final and its pinned parent before returning.
[[nodiscard]] ReconcileResult reconcile_exact_existing_archive(
    const std::filesystem::path& source,
    const std::filesystem::path& existing_final,
    std::optional<ReconcileCrashCut> crash_cut = std::nullopt);

}  // namespace slopos::e0::generation_journal::checkpoint_transport_commit
