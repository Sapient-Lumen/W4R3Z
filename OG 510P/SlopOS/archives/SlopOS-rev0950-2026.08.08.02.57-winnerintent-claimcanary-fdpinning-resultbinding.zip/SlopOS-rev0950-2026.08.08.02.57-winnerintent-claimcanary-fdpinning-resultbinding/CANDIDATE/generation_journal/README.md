# Hosted generation journal, spend floor, and joined-admission cell

This package is the living Epoch-Zero proof seam after `CANDIDATE/core_gate/`.
It contains four connected but deliberately nonauthoritative layers.

1. The original generation-journal model receives an already-consumed dispatch
   receipt, retains and reads back one exact pending record, invokes one fixed
   endpoint, preserves versioned result truth, and makes recovery query-only.
2. The rev0893 content-bound spend relation encodes a canonical 352-byte record
   and compares exact floor identity, generation, and head. Exact duplicate is
   query-only; foreign, scalar, malformed, stale, or unavailable observations
   fail closed.
3. Rev0894 removes the remaining detached-response authority mistake and adds a
   hosted SQLite fault adapter that co-commits one exact floor successor and one
   fixed endpoint-admission row in a single local transaction.
4. Rev0935 added `checkpoint_transport_commit`, a nested C++20 closure leaf
   bound into the production checkpoint closer. Complete ZIP bytes remain under
   a hidden same-parent stage until exact comparison, mode restriction, file
   fsync, and one no-replace rename; successful return follows parent-directory
   fsync. Rev0936 preserves that absent-final rule and adds a separate explicit
   exact-existing reconciliation query after uncertain return. Reconciliation
   writes no final content, replaces nothing, and infers no provenance. The leaf
   is closure machinery, not a generation-journal product.

The rev0893 acceptance API intentionally showed its own flaw: replaying one
`advanced` response produced two hosted `invoke_once` decisions. Rev0894 changes
that result. Every detached append or join response is now observation-only;
replaying or copying it grants zero endpoint authority. Endpoint admission is a
protected-state fact, never a property of returned bytes.

Fresh finite evidence includes:

- sixteen concurrent same-spend joined contenders: one `admitted`, fifteen
  `already_current`, one exact final entry;
- opposite-order foreign contenders: one admission and one conflict per world;
- four killed-process transaction cuts: three clean precommit rollbacks and one
  exact postcommit reopen;
- an intentionally split floor-only commit that reaches target-without-entry
  and is independently rejected as uncertain;
- a pre-spend database clone that admits twice, proving local transaction
  atomicity is not a global nonrollback spend floor; and
- a Linux `SCM_RIGHTS`/`MSG_PEEK` probe that installs three descriptor
  references from one queued message, proving descriptor delivery is not
  one-use custody.

The adapter uses SQLite strict tables, rollback-journal mode,
`synchronous=FULL`, exact conditional update, same-transaction insertion, and
fresh readback. None of those choices authenticates the writer, survives a
coherent rollback domain controlled by the cloudtainer, proves physical
power-loss behavior, or executes a protected effect.

Ordinary C++ objects, hashes, database rows, file descriptors, process-local
move semantics, campaign output, and green tests are not authority. Builds and
reconstruction work belong outside the checkpoint. Use
`TOOLS/reconstruct_generation_journal.py`.

Read in this order:

1. `spec/GENERATION-JOURNAL-V1.md`
2. `spec/SPEND-RECORD-V1.md`
3. `spec/SPEND-FLOOR-V1.md`
4. `spec/JOINED-ADMISSION-V1.md`
5. `proof/OBLIGATIONS.tsv`
6. the `proof/COUNTEREXAMPLE-*` notes

Checkpoint transport has a separate read route:

1. `checkpoint_transport_commit/spec/CHECKPOINT-TRANSPORT-COMMIT-V1.md`
2. `checkpoint_transport_commit/spec/CHECKPOINT-TRANSPORT-COMMIT-V2.md`
3. `checkpoint_transport_commit/proof/OBLIGATIONS.tsv`
4. `checkpoint_transport_commit/proof/RECONCILIATION-OBLIGATIONS.tsv`
5. `DESIGN/CHECKPOINT-TRANSPORT-RECONCILIATION.md`
6. `EVIDENCE/REV0936/CHECKPOINT-TRANSPORT-RECONCILIATION/README.md`

Its successful local protocol does not prove stable media, remote filesystem
semantics, writer authenticity, owner ratification, or living admission.

## Rev0937 rooted shadow-pack leaf

`shadow_pack` is a separate nested direct-build C++20 proof leaf. It preserves the independent `SLOPSPK1` object format while replacing path-walk source intake and reconstruction with retained-directory-descriptor operations. It binds relative logical record addresses, kinds, modes, sizes, and payload digests; double-observes regular files; rechecks directory membership; reconstructs beneath a random hidden same-parent stage; rereads output; and publishes only with `renameat2(RENAME_NOREPLACE)`.

The retained three-lane campaign is byte-identical to an independent Python oracle and reconstructs the 1,637-record `EVIDENCE/CXX20` subject exactly. It also rejects malformed objects, symlink/special/mode/casefold/missing/extra source faults, preexisting destinations, and symlinked destination parents without leaving outputs.

This leaf is additive. It stores no pack in the checkpoint and deletes no loose record. Logical record address and byte equality do not prove producer, role, revision, provenance, exclusive writer custody, stable media, independent retention, garbage-collection safety, deletion authority, owner ratification, or living admission.
