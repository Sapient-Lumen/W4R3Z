#include "slopos/e0/generation_journal/reference.hpp"

namespace slopos::e0::generation_journal::reference {
namespace {

[[nodiscard]] Step deny(const State& state) noexcept {
    return Step{Outcome::rejected, state, false, false, false, false};
}

[[nodiscard]] Step allow(const State& state,
                         const bool called = false,
                         const bool refined = false,
                         const bool published = false) noexcept {
    return Step{Outcome::applied, state, called, refined, published, false};
}

void terminal(State& state, const Phase phase, const Result result,
              const std::uint8_t version, const bool reconciled) noexcept {
    state.phase = phase;
    state.result = result;
    state.result_version = version;
    state.reconciled = reconciled;
}

[[nodiscard]] bool is_invoke(const Event event) noexcept {
    return event == Event::invoke_effect_return
        || event == Event::invoke_no_effect_return
        || event == Event::invoke_nonreturn_before_effect
        || event == Event::invoke_nonreturn_after_effect
        || event == Event::invoke_malformed_before_effect
        || event == Event::invoke_malformed_after_effect;
}

}  // namespace

Step step(const State& before, const Event event) noexcept {
    State next = before;

    if (event == Event::accept_consumed_dispatch) {
        if (before.phase != Phase::empty) return deny(before);
        next.phase = Phase::pending;
        next.receipt_bound = true;
        return allow(next);
    }
    if (event == Event::accept_wrong_dispatch) {
        if (before.phase != Phase::empty) return deny(before);
        terminal(next, Phase::fail_stop, Result::fail_stop, 1U, false);
        return allow(next);
    }
    if (event == Event::persist_pending_exact) {
        if (before.phase != Phase::pending) return deny(before);
        next.phase = Phase::ready;
        next.pending_exact = true;
        return allow(next);
    }
    if (event == Event::persist_pending_mismatch) {
        if (before.phase != Phase::pending) return deny(before);
        terminal(next, Phase::fail_stop, Result::fail_stop, 1U, false);
        return allow(next);
    }
    if (event == Event::external_successor_other) {
        const bool eligible = (before.phase == Phase::pending
                || before.phase == Phase::ready
                || before.phase == Phase::uncertain)
            && before.endpoint == Endpoint::predecessor
            && before.invocation_count == 0U
            && before.result != Result::effect;
        if (!eligible) return deny(before);
        next.endpoint = Endpoint::successor_other;
        return allow(next);
    }
    if (is_invoke(event)) {
        if (before.phase != Phase::ready || before.invocation_count != 0U) {
            return deny(before);
        }
        next.invocation_count = 1U;
        if (before.endpoint == Endpoint::successor_other) {
            terminal(next, Phase::fail_stop, Result::fail_stop, 1U, false);
            return allow(next, true);
        }
        if (event == Event::invoke_effect_return) {
            next.endpoint = Endpoint::successor_same;
            next.effect_count = 1U;
            terminal(next, Phase::terminal, Result::effect, 1U, false);
            return allow(next, true);
        }
        if (event == Event::invoke_no_effect_return) {
            terminal(next, Phase::terminal, Result::no_effect, 1U, false);
            return allow(next, true);
        }
        if (event == Event::invoke_nonreturn_after_effect
                || event == Event::invoke_malformed_after_effect) {
            next.endpoint = Endpoint::successor_same;
            next.effect_count = 1U;
        }
        terminal(next, Phase::uncertain, Result::uncertain, 1U, false);
        return allow(next, true);
    }
    if (event == Event::restart) {
        if (before.phase == Phase::pending || before.phase == Phase::ready) {
            next.recovered = true;
            terminal(next, Phase::uncertain, Result::uncertain, 1U, false);
            return allow(next);
        }
        if ((before.phase == Phase::uncertain
                || before.phase == Phase::terminal
                || before.phase == Phase::fail_stop)
                && !before.recovered) {
            next.recovered = true;
            return allow(next);
        }
        return deny(before);
    }
    if (event == Event::recover_spent_receipt_exact) {
        if (before.phase != Phase::uncertain || !before.recovered
                || before.pending_exact || !before.receipt_bound) return deny(before);
        next.pending_exact = true;
        return allow(next);
    }
    if (event == Event::recover_spent_receipt_mismatch) {
        if (before.phase != Phase::uncertain || !before.recovered
                || before.pending_exact || !before.receipt_bound) return deny(before);
        terminal(next, Phase::fail_stop, Result::fail_stop, 2U, true);
        return allow(next, false, true);
    }
    if (event == Event::recover_spent_receipt_missing) {
        if (before.phase != Phase::uncertain || !before.recovered
                || before.pending_exact || !before.receipt_bound) return deny(before);
        return allow(next);
    }

    const bool queryable = before.phase == Phase::uncertain
        && before.result == Result::uncertain
        && before.result_version == 1U
        && before.receipt_bound && before.pending_exact;
    if (event == Event::query_predecessor) {
        if (!queryable || before.endpoint != Endpoint::predecessor) return deny(before);
        terminal(next, Phase::terminal, Result::no_effect, 2U, true);
        return allow(next, false, true);
    }
    if (event == Event::query_successor_same) {
        if (!queryable || before.endpoint != Endpoint::successor_same) return deny(before);
        terminal(next, Phase::terminal, Result::effect, 2U, true);
        return allow(next, false, true);
    }
    if (event == Event::query_successor_other) {
        if (!queryable || before.endpoint != Endpoint::successor_other) return deny(before);
        terminal(next, Phase::fail_stop, Result::fail_stop, 2U, true);
        return allow(next, false, true);
    }
    if (event == Event::query_unavailable) {
        if (!queryable) return deny(before);
        return allow(next);
    }
    if (event == Event::publish) {
        if (before.result == Result::none
                || before.published_version >= before.result_version) return deny(before);
        next.published_version = before.result_version;
        return allow(next, false, false, true);
    }

    // Recovery apply, minting, route selection, retry, and stale publication
    // are explicit state-preserving denials.
    return deny(before);
}

}  // namespace slopos::e0::generation_journal::reference
