#include "slopos/e0/generation_journal/spend_reference.hpp"

#include <limits>

namespace slopos::e0::generation_journal::spend_reference {
namespace {

[[nodiscard]] bool exact_point(const FloorPoint& point) noexcept {
    return point.generation != 0U && !digest_is_zero(point.head);
}

[[nodiscard]] SpendDecision stop(const SpendRelation relation,
                                 const bool rollback = false) noexcept {
    return SpendDecision{relation, false, false, rollback, true};
}

[[nodiscard]] bool request_well_formed(
    const CompareAppendRequest& request) noexcept {
    if (digest_is_zero(request.floor_identity)
        || !exact_point(request.expected) || !exact_point(request.target)
        || request.expected.generation == std::numeric_limits<std::uint64_t>::max()
        || request.target.generation != request.expected.generation + 1U) {
        return false;
    }
    SpendRecordV1 decoded;
    if (!decode_spend_record(request.record, decoded)) return false;
    return decoded.generation_from == request.expected.generation
        && decoded.generation_to == request.target.generation
        && decoded.predecessor_head == request.expected.head
        && spend_record_head(request.record) == request.target.head;
}

[[nodiscard]] bool exact_response(const CompareAppendRequest& request,
                                  const CompareAppendResponse& response) noexcept {
    if (response.floor_identity != request.floor_identity
        || response.current.generation != request.target.generation
        || response.current.head != request.target.head
        || !response.content_bound || !response.current_record.has_value()
        || *response.current_record != request.record) {
        return false;
    }
    SpendRecordV1 decoded;
    return decode_spend_record(*response.current_record, decoded)
        && decoded.generation_to == response.current.generation
        && spend_record_head(*response.current_record) == response.current.head;
}

}  // namespace

SpendDecision evaluate_spend(
    const LocalSpendObservation& local,
    const ProtectedFloorObservation& floor,
    const EncodedSpendRecord& candidate,
    const Digest& expected_floor_identity) noexcept {
    if (digest_is_zero(expected_floor_identity) || !exact_point(local.confirmed)
        || local.pending_present != static_cast<bool>(local.pending)) {
        return stop(SpendRelation::malformed);
    }

    SpendRecordV1 proposal;
    if (!decode_spend_record(candidate, proposal)
        || proposal.generation_from != local.confirmed.generation
        || proposal.predecessor_head != local.confirmed.head) {
        return stop(SpendRelation::malformed);
    }
    const FloorPoint proposal_point{
        proposal.generation_to, spend_record_head(candidate)};

    if (local.pending_present) {
        SpendRecordV1 staged;
        if (!decode_spend_record(*local.pending, staged)) {
            return stop(SpendRelation::malformed);
        }
        if (*local.pending != candidate) {
            return stop(SpendRelation::foreign_spend);
        }
    }

    if (floor.status == FloorReadStatus::unavailable) {
        return stop(SpendRelation::floor_unavailable);
    }
    if (floor.status != FloorReadStatus::available) {
        return stop(SpendRelation::malformed);
    }
    if (floor.floor_identity != expected_floor_identity) {
        return stop(SpendRelation::identity_mismatch);
    }
    if (floor.current.generation == 0U) {
        return stop(SpendRelation::malformed);
    }
    if (!floor.content_bound) {
        if (!digest_is_zero(floor.current.head) || floor.current_record.has_value()) {
            return stop(SpendRelation::malformed);
        }
        return stop(SpendRelation::scalar_ambiguous,
                    floor.current.generation > local.confirmed.generation);
    }
    if (digest_is_zero(floor.current.head)) {
        return stop(SpendRelation::malformed);
    }
    if (floor.current_record.has_value()) {
        SpendRecordV1 observed;
        if (!decode_spend_record(*floor.current_record, observed)
            || observed.generation_to != floor.current.generation
            || spend_record_head(*floor.current_record) != floor.current.head) {
            return stop(SpendRelation::malformed);
        }
    }

    if (floor.current.generation < local.confirmed.generation) {
        return stop(SpendRelation::local_ahead);
    }
    if (floor.current.generation == local.confirmed.generation) {
        if (floor.current.head != local.confirmed.head) {
            return stop(SpendRelation::foreign_spend);
        }
        if (local.pending_present) {
            return SpendDecision{SpendRelation::prepared_exact,
                                 true, false, false, false};
        }
        return SpendDecision{SpendRelation::fresh,
                             true, false, false, false};
    }
    if (floor.current.generation == proposal_point.generation) {
        if (floor.current.head == proposal_point.head) {
            return SpendDecision{SpendRelation::same_spend_committed,
                                 false, true, true, false};
        }
        return stop(SpendRelation::foreign_spend, true);
    }
    return stop(SpendRelation::generation_jump,
                floor.current.generation > local.confirmed.generation);
}

std::optional<CompareAppendRequest> make_compare_append_request(
    const LocalSpendObservation& local,
    const ProtectedFloorObservation& floor,
    const EncodedSpendRecord& candidate,
    const Digest& expected_floor_identity) noexcept {
    const SpendDecision relation = spend_reference::evaluate_spend(
        local, floor, candidate, expected_floor_identity);
    if (!relation.compare_append_allowed) return std::nullopt;
    SpendRecordV1 decoded;
    if (!decode_spend_record(candidate, decoded)) return std::nullopt;
    CompareAppendRequest request;
    request.floor_identity = expected_floor_identity;
    request.expected = local.confirmed;
    request.target = FloorPoint{decoded.generation_to, spend_record_head(candidate)};
    request.record = candidate;
    return request;
}

AppendDecision accept_compare_append_response(
    const CompareAppendRequest& request,
    const CompareAppendResponse& response) noexcept {
    if (!request_well_formed(request)
        || response.floor_identity != request.floor_identity) {
        return AppendDecision{};
    }
    if (response.status == AppendStatus::advanced
        && exact_response(request, response)) {
        return AppendDecision{false, true, true, false};
    }
    if (response.status == AppendStatus::already_current
        && exact_response(request, response)) {
        return AppendDecision{false, true, true, false};
    }
    return AppendDecision{};
}

}  // namespace slopos::e0::generation_journal::spend_reference
