#include "slopos/e0/generation_journal/spend_record.hpp"

#include <algorithm>
#include <array>
#include <limits>
#include <vector>

namespace slopos::e0::generation_journal {
namespace {

constexpr std::array<std::uint8_t, 8U> kMagic{{
    'S', 'L', 'O', 'P', 'S', 'P', '0', '1',
}};
constexpr std::uint16_t kVersion = 1U;
constexpr std::uint16_t kKind = 1U;
constexpr std::array<std::uint8_t, 32U> kIntegrityDomain{{
    'S', 'l', 'o', 'p', 'O', 'S', '/', 's', 'p', 'e', 'n', 'd', '/',
    'r', 'e', 'c', 'o', 'r', 'd', '/', 'v', '1', '/', 'i', 'n', 't',
    'e', 'g', 'r', 'i', 't', 'y',
}};
constexpr std::array<std::uint8_t, 32U> kHeadDomain{{
    'S', 'l', 'o', 'p', 'O', 'S', '/', 's', 'p', 'e', 'n', 'd', '/',
    'r', 'e', 'c', 'o', 'r', 'd', '/', 'v', '1', '/', 'h', 'e', 'a',
    'd', 0U, 0U, 0U, 0U, 0U,
}};

constexpr std::array<std::uint32_t, 64U> kRound{{
    0x428a2f98U, 0x71374491U, 0xb5c0fbcfU, 0xe9b5dba5U,
    0x3956c25bU, 0x59f111f1U, 0x923f82a4U, 0xab1c5ed5U,
    0xd807aa98U, 0x12835b01U, 0x243185beU, 0x550c7dc3U,
    0x72be5d74U, 0x80deb1feU, 0x9bdc06a7U, 0xc19bf174U,
    0xe49b69c1U, 0xefbe4786U, 0x0fc19dc6U, 0x240ca1ccU,
    0x2de92c6fU, 0x4a7484aaU, 0x5cb0a9dcU, 0x76f988daU,
    0x983e5152U, 0xa831c66dU, 0xb00327c8U, 0xbf597fc7U,
    0xc6e00bf3U, 0xd5a79147U, 0x06ca6351U, 0x14292967U,
    0x27b70a85U, 0x2e1b2138U, 0x4d2c6dfcU, 0x53380d13U,
    0x650a7354U, 0x766a0abbU, 0x81c2c92eU, 0x92722c85U,
    0xa2bfe8a1U, 0xa81a664bU, 0xc24b8b70U, 0xc76c51a3U,
    0xd192e819U, 0xd6990624U, 0xf40e3585U, 0x106aa070U,
    0x19a4c116U, 0x1e376c08U, 0x2748774cU, 0x34b0bcb5U,
    0x391c0cb3U, 0x4ed8aa4aU, 0x5b9cca4fU, 0x682e6ff3U,
    0x748f82eeU, 0x78a5636fU, 0x84c87814U, 0x8cc70208U,
    0x90befffaU, 0xa4506cebU, 0xbef9a3f7U, 0xc67178f2U,
}};

[[nodiscard]] constexpr std::uint32_t rotate_right(
    const std::uint32_t value, const unsigned int count) noexcept {
    return (value >> count) | (value << (32U - count));
}

void put_u16(EncodedSpendRecord& output, const std::size_t offset,
             const std::uint16_t value) noexcept {
    output[offset] = static_cast<std::uint8_t>(value >> 8U);
    output[offset + 1U] = static_cast<std::uint8_t>(value);
}

void put_u32(EncodedSpendRecord& output, const std::size_t offset,
             const std::uint32_t value) noexcept {
    output[offset] = static_cast<std::uint8_t>(value >> 24U);
    output[offset + 1U] = static_cast<std::uint8_t>(value >> 16U);
    output[offset + 2U] = static_cast<std::uint8_t>(value >> 8U);
    output[offset + 3U] = static_cast<std::uint8_t>(value);
}

void put_u64(EncodedSpendRecord& output, const std::size_t offset,
             const std::uint64_t value) noexcept {
    for (std::size_t index = 0U; index < 8U; ++index) {
        const unsigned int shift = static_cast<unsigned int>((7U - index) * 8U);
        output[offset + index] = static_cast<std::uint8_t>(value >> shift);
    }
}

[[nodiscard]] std::uint16_t get_u16(const EncodedSpendRecord& input,
                                    const std::size_t offset) noexcept {
    return static_cast<std::uint16_t>(
        (static_cast<std::uint16_t>(input[offset]) << 8U)
        | static_cast<std::uint16_t>(input[offset + 1U]));
}

[[nodiscard]] std::uint32_t get_u32(const EncodedSpendRecord& input,
                                    const std::size_t offset) noexcept {
    return (static_cast<std::uint32_t>(input[offset]) << 24U)
        | (static_cast<std::uint32_t>(input[offset + 1U]) << 16U)
        | (static_cast<std::uint32_t>(input[offset + 2U]) << 8U)
        | static_cast<std::uint32_t>(input[offset + 3U]);
}

[[nodiscard]] std::uint64_t get_u64(const EncodedSpendRecord& input,
                                    const std::size_t offset) noexcept {
    std::uint64_t value = 0U;
    for (std::size_t index = 0U; index < 8U; ++index) {
        value = (value << 8U) | static_cast<std::uint64_t>(input[offset + index]);
    }
    return value;
}

void put_digest(EncodedSpendRecord& output, const std::size_t offset,
                const Digest& value) noexcept {
    std::copy(value.begin(), value.end(), output.begin()
              + static_cast<std::ptrdiff_t>(offset));
}

[[nodiscard]] Digest get_digest(const EncodedSpendRecord& input,
                                const std::size_t offset) noexcept {
    Digest value{};
    std::copy_n(input.begin() + static_cast<std::ptrdiff_t>(offset), value.size(),
                value.begin());
    return value;
}

[[nodiscard]] Digest digest_with_domain(
    const std::array<std::uint8_t, 32U>& domain,
    const std::span<const std::uint8_t> payload) {
    std::vector<std::uint8_t> input;
    input.reserve(domain.size() + payload.size());
    input.insert(input.end(), domain.begin(), domain.end());
    input.insert(input.end(), payload.begin(), payload.end());
    return sha256(input);
}

}  // namespace

bool digest_is_zero(const Digest& value) noexcept {
    return std::all_of(value.begin(), value.end(), [](const std::uint8_t byte) {
        return byte == 0U;
    });
}

bool spend_record_invariant(const SpendRecordV1& record) noexcept {
    if (record.owner_epoch == 0U || record.constructor_epoch == 0U
        || record.spend_serial == 0U || record.generation_from == 0U
        || record.generation_to == 0U
        || record.generation_from == std::numeric_limits<std::uint64_t>::max()
        || record.generation_to != record.generation_from + 1U) {
        return false;
    }
    const std::array<const Digest*, 8U> fields{{
        &record.owner_statement,
        &record.constructor_image,
        &record.provider_subject,
        &record.publication_receipt,
        &record.expectation_record,
        &record.operation,
        &record.pending_result,
        &record.predecessor_head,
    }};
    return std::none_of(fields.begin(), fields.end(), [](const Digest* value) {
        return digest_is_zero(*value);
    });
}

Digest sha256(const std::span<const std::uint8_t> bytes) {
    std::vector<std::uint8_t> padded(bytes.begin(), bytes.end());
    const std::uint64_t bit_length = static_cast<std::uint64_t>(bytes.size()) * 8U;
    padded.push_back(0x80U);
    while ((padded.size() % 64U) != 56U) padded.push_back(0U);
    for (int shift = 56; shift >= 0; shift -= 8) {
        padded.push_back(static_cast<std::uint8_t>(bit_length
                                                  >> static_cast<unsigned int>(shift)));
    }

    std::array<std::uint32_t, 8U> state{{
        0x6a09e667U, 0xbb67ae85U, 0x3c6ef372U, 0xa54ff53aU,
        0x510e527fU, 0x9b05688cU, 0x1f83d9abU, 0x5be0cd19U,
    }};

    for (std::size_t block = 0U; block < padded.size(); block += 64U) {
        std::array<std::uint32_t, 64U> words{};
        for (std::size_t index = 0U; index < 16U; ++index) {
            const std::size_t base = block + index * 4U;
            words[index] = (static_cast<std::uint32_t>(padded[base]) << 24U)
                | (static_cast<std::uint32_t>(padded[base + 1U]) << 16U)
                | (static_cast<std::uint32_t>(padded[base + 2U]) << 8U)
                | static_cast<std::uint32_t>(padded[base + 3U]);
        }
        for (std::size_t index = 16U; index < words.size(); ++index) {
            const std::uint32_t s0 = rotate_right(words[index - 15U], 7U)
                ^ rotate_right(words[index - 15U], 18U)
                ^ (words[index - 15U] >> 3U);
            const std::uint32_t s1 = rotate_right(words[index - 2U], 17U)
                ^ rotate_right(words[index - 2U], 19U)
                ^ (words[index - 2U] >> 10U);
            words[index] = words[index - 16U] + s0
                + words[index - 7U] + s1;
        }

        std::uint32_t a = state[0U];
        std::uint32_t b = state[1U];
        std::uint32_t c = state[2U];
        std::uint32_t d = state[3U];
        std::uint32_t e = state[4U];
        std::uint32_t f = state[5U];
        std::uint32_t g = state[6U];
        std::uint32_t h = state[7U];
        for (std::size_t index = 0U; index < words.size(); ++index) {
            const std::uint32_t s1 = rotate_right(e, 6U)
                ^ rotate_right(e, 11U) ^ rotate_right(e, 25U);
            const std::uint32_t choose = (e & f) ^ ((~e) & g);
            const std::uint32_t temporary1 = h + s1 + choose
                + kRound[index] + words[index];
            const std::uint32_t s0 = rotate_right(a, 2U)
                ^ rotate_right(a, 13U) ^ rotate_right(a, 22U);
            const std::uint32_t majority = (a & b) ^ (a & c) ^ (b & c);
            const std::uint32_t temporary2 = s0 + majority;
            h = g;
            g = f;
            f = e;
            e = d + temporary1;
            d = c;
            c = b;
            b = a;
            a = temporary1 + temporary2;
        }
        state[0U] += a;
        state[1U] += b;
        state[2U] += c;
        state[3U] += d;
        state[4U] += e;
        state[5U] += f;
        state[6U] += g;
        state[7U] += h;
    }

    Digest output{};
    for (std::size_t index = 0U; index < state.size(); ++index) {
        output[index * 4U] = static_cast<std::uint8_t>(state[index] >> 24U);
        output[index * 4U + 1U] = static_cast<std::uint8_t>(state[index] >> 16U);
        output[index * 4U + 2U] = static_cast<std::uint8_t>(state[index] >> 8U);
        output[index * 4U + 3U] = static_cast<std::uint8_t>(state[index]);
    }
    return output;
}

bool encode_spend_record(const SpendRecordV1& record,
                         EncodedSpendRecord& output) noexcept {
    if (!spend_record_invariant(record)) return false;
    output.fill(0U);
    std::copy(kMagic.begin(), kMagic.end(), output.begin());
    put_u16(output, 8U, kVersion);
    put_u16(output, 10U, kKind);
    put_u32(output, 12U, static_cast<std::uint32_t>(kSpendRecordBytes));
    put_u64(output, 16U, record.owner_epoch);
    put_u64(output, 24U, record.constructor_epoch);
    put_u64(output, 32U, record.spend_serial);
    put_u64(output, 40U, record.generation_from);
    put_u64(output, 48U, record.generation_to);
    put_digest(output, 56U, record.owner_statement);
    put_digest(output, 88U, record.constructor_image);
    put_digest(output, 120U, record.provider_subject);
    put_digest(output, 152U, record.publication_receipt);
    put_digest(output, 184U, record.expectation_record);
    put_digest(output, 216U, record.operation);
    put_digest(output, 248U, record.pending_result);
    put_digest(output, 280U, record.predecessor_head);
    const Digest integrity = digest_with_domain(
        kIntegrityDomain,
        std::span<const std::uint8_t>(output.data(), 320U));
    put_digest(output, 320U, integrity);
    return true;
}

bool decode_spend_record(const EncodedSpendRecord& input,
                         SpendRecordV1& output) noexcept {
    if (!std::equal(kMagic.begin(), kMagic.end(), input.begin())
        || get_u16(input, 8U) != kVersion
        || get_u16(input, 10U) != kKind
        || get_u32(input, 12U) != kSpendRecordBytes
        || std::any_of(input.begin() + 312, input.begin() + 320,
                       [](const std::uint8_t value) { return value != 0U; })) {
        return false;
    }
    const Digest expected = digest_with_domain(
        kIntegrityDomain,
        std::span<const std::uint8_t>(input.data(), 320U));
    if (get_digest(input, 320U) != expected) return false;

    SpendRecordV1 decoded;
    decoded.owner_epoch = get_u64(input, 16U);
    decoded.constructor_epoch = get_u64(input, 24U);
    decoded.spend_serial = get_u64(input, 32U);
    decoded.generation_from = get_u64(input, 40U);
    decoded.generation_to = get_u64(input, 48U);
    decoded.owner_statement = get_digest(input, 56U);
    decoded.constructor_image = get_digest(input, 88U);
    decoded.provider_subject = get_digest(input, 120U);
    decoded.publication_receipt = get_digest(input, 152U);
    decoded.expectation_record = get_digest(input, 184U);
    decoded.operation = get_digest(input, 216U);
    decoded.pending_result = get_digest(input, 248U);
    decoded.predecessor_head = get_digest(input, 280U);
    if (!spend_record_invariant(decoded)) return false;
    output = decoded;
    return true;
}

Digest spend_record_head(const EncodedSpendRecord& record) {
    return digest_with_domain(kHeadDomain, record);
}

}  // namespace slopos::e0::generation_journal
