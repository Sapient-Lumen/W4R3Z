#include "slopos/e0/generation_journal/boundary.hpp"

#include <algorithm>
#include <limits>
#include <type_traits>
#include <utility>

namespace slopos::e0::generation_journal {
namespace {

[[nodiscard]] bool exact_operation(const ExactOperation& operation) noexcept {
    const bool operation_nonzero = std::any_of(
        operation.operation_binding.begin(), operation.operation_binding.end(),
        [](const std::uint8_t byte) { return byte != 0U; });
    const bool receipt_nonzero = std::any_of(
        operation.spent_receipt_binding.begin(),
        operation.spent_receipt_binding.end(),
        [](const std::uint8_t byte) { return byte != 0U; });
    return operation.generation_from > 0U
        && operation.generation_from
            != std::numeric_limits<std::uint64_t>::max()
        && operation.generation_to == operation.generation_from + 1U
        && operation_nonzero && receipt_nonzero;
}

}  // namespace

static_assert(!std::is_copy_constructible_v<ConsumedDispatchReceipt>);
static_assert(!std::is_copy_constructible_v<PendingPlan>);
static_assert(!std::is_copy_constructible_v<InvocationTicket>);
static_assert(!std::is_copy_constructible_v<QueryOnlyBinding>);
static_assert(std::is_move_constructible_v<ConsumedDispatchReceipt>);
static_assert(std::is_move_constructible_v<PendingPlan>);
static_assert(std::is_move_constructible_v<InvocationTicket>);
static_assert(std::is_move_constructible_v<QueryOnlyBinding>);

ConsumedDispatchReceipt::ConsumedDispatchReceipt(
    ExactOperation operation) noexcept
    : operation_(operation) {}

ConsumedDispatchReceipt::ConsumedDispatchReceipt(
    ConsumedDispatchReceipt&& other) noexcept
    : operation_(other.operation_), live_(other.live_) {
    other.live_ = false;
}

std::optional<ExactOperation> ConsumedDispatchReceipt::consume() noexcept {
    if (!live_) return std::nullopt;
    live_ = false;
    return operation_;
}

PendingPlan::PendingPlan(ExactOperation operation,
                         EncodedRecord intended) noexcept
    : operation_(operation), intended_(intended) {}

PendingPlan::PendingPlan(PendingPlan&& other) noexcept
    : operation_(other.operation_), intended_(other.intended_), live_(other.live_) {
    other.live_ = false;
}

bool PendingPlan::consume(ExactOperation& operation,
                          EncodedRecord& intended) noexcept {
    if (!live_) return false;
    live_ = false;
    operation = operation_;
    intended = intended_;
    return true;
}

InvocationTicket::InvocationTicket(ExactOperation operation) noexcept
    : operation_(operation) {}

InvocationTicket::InvocationTicket(InvocationTicket&& other) noexcept
    : operation_(other.operation_), live_(other.live_) {
    other.live_ = false;
}

QueryOnlyBinding::QueryOnlyBinding(ExactOperation operation) noexcept
    : operation_(operation) {}

QueryOnlyBinding::QueryOnlyBinding(QueryOnlyBinding&& other) noexcept
    : operation_(other.operation_), live_(other.live_) {
    other.live_ = false;
}

ConsumedDispatchReceipt HostedGateFixture::consumed(
    ExactOperation operation) noexcept {
    return ConsumedDispatchReceipt(operation);
}

std::optional<PendingPlan> EndpointBoundary::plan(
    ConsumedDispatchReceipt&& receipt) noexcept {
    const auto operation = receipt.consume();
    if (!operation.has_value() || !exact_operation(*operation)) {
        return std::nullopt;
    }
    Record record;
    record.kind = RecordKind::pending;
    record.sequence = 1U;
    record.generation_from = operation->generation_from;
    record.generation_to = operation->generation_to;
    record.operation_binding = operation->operation_binding;
    record.spent_receipt_binding = operation->spent_receipt_binding;
    record.result = Result::none;
    record.consumed_dispatch = true;
    record.reconciled = false;
    EncodedRecord encoded{};
    if (!encode_record(record, encoded)) return std::nullopt;
    return PendingPlan(*operation, encoded);
}

std::optional<InvocationTicket> EndpointBoundary::activate_after_readback(
    PendingPlan&& plan, const EncodedRecord& readback) noexcept {
    ExactOperation operation;
    EncodedRecord intended{};
    if (!plan.consume(operation, intended)) return std::nullopt;
    if (intended != readback) return std::nullopt;
    Record decoded;
    if (!decode_record(readback, decoded)
        || decoded.kind != RecordKind::pending
        || decoded.generation_from != operation.generation_from
        || decoded.generation_to != operation.generation_to
        || decoded.operation_binding != operation.operation_binding
        || decoded.spent_receipt_binding != operation.spent_receipt_binding) {
        return std::nullopt;
    }
    return InvocationTicket(operation);
}

std::optional<QueryOnlyBinding> EndpointBoundary::recover_query_only(
    const ExactOperation& protected_observation) noexcept {
    if (!exact_operation(protected_observation)) return std::nullopt;
    return QueryOnlyBinding(protected_observation);
}

}  // namespace slopos::e0::generation_journal
