#include "slopos/e0/generation_journal/machine.hpp"

#include <sstream>

namespace slopos::e0::generation_journal {
namespace {

[[nodiscard]] Step applied(const State& state,
                           const bool endpoint_apply = false,
                           const bool refined = false,
                           const bool published = false) noexcept {
    return Step{Outcome::applied, state, endpoint_apply, refined, published, false};
}

[[nodiscard]] Step rejected(const State& state) noexcept {
    return Step{Outcome::rejected, state, false, false, false, false};
}

void set_result(State& state, const Phase phase, const Result result,
                const std::uint8_t version, const bool reconciled) noexcept {
    state.phase = phase;
    state.result = result;
    state.result_version = version;
    state.reconciled = reconciled;
}

[[nodiscard]] bool query_allowed(const State& state) noexcept {
    return state.phase == Phase::uncertain
        && state.result == Result::uncertain
        && state.result_version == 1U
        && state.receipt_bound
        && state.pending_exact;
}

[[nodiscard]] bool can_hide_other_successor(const State& state) noexcept {
    return (state.phase == Phase::pending
            || state.phase == Phase::ready
            || state.phase == Phase::uncertain)
        && state.endpoint == Endpoint::predecessor
        && state.invocation_count == 0U
        && state.result != Result::effect;
}

}  // namespace

State initial_state() noexcept { return State{}; }

bool invariant(const State& s) noexcept {
    if (s.invocation_count > 1U || s.effect_count > 1U) return false;
    if (s.result_version > 2U || s.published_version > s.result_version) return false;
    if ((s.result == Result::none) != (s.result_version == 0U)) return false;
    if ((s.result_version == 2U) != s.reconciled) return false;
    if (s.published_version > 0U && s.result == Result::none) return false;
    if (s.endpoint == Endpoint::predecessor && s.effect_count != 0U) return false;
    if (s.endpoint == Endpoint::successor_same && s.effect_count != 1U) return false;
    if (s.endpoint == Endpoint::successor_other && s.effect_count != 0U) return false;
    if (s.effect_count == 1U && s.invocation_count != 1U) return false;
    if (s.invocation_count == 1U && !s.pending_exact) return false;
    if (s.result == Result::effect
            && (s.endpoint != Endpoint::successor_same || s.effect_count != 1U)) return false;
    if (s.result == Result::no_effect
            && (s.endpoint != Endpoint::predecessor || s.effect_count != 0U)) return false;
    if (s.result == Result::uncertain && s.result_version != 1U) return false;
    if (s.reconciled && s.result == Result::uncertain) return false;

    switch (s.phase) {
    case Phase::empty:
        return s.endpoint == Endpoint::predecessor
            && s.result == Result::none && s.result_version == 0U
            && s.published_version == 0U && s.invocation_count == 0U
            && s.effect_count == 0U && !s.receipt_bound
            && !s.pending_exact && !s.recovered && !s.reconciled;
    case Phase::pending:
        return s.receipt_bound && s.result == Result::none
            && s.invocation_count == 0U && !s.pending_exact
            && !s.recovered && !s.reconciled;
    case Phase::ready:
        return s.receipt_bound && s.result == Result::none
            && s.invocation_count == 0U && s.pending_exact
            && !s.recovered && !s.reconciled;
    case Phase::uncertain:
        if (!s.receipt_bound || s.result != Result::uncertain
                || s.result_version != 1U || s.reconciled) return false;
        if (!s.pending_exact) {
            return s.recovered && s.invocation_count == 0U;
        }
        return true;
    case Phase::terminal:
        return s.receipt_bound && s.pending_exact
            && (s.result == Result::effect || s.result == Result::no_effect)
            && (s.result_version == 1U || s.result_version == 2U);
    case Phase::fail_stop:
        return s.result == Result::fail_stop
            && (s.result_version == 1U || s.result_version == 2U);
    }
    return false;
}

Step step(const State& before, const Event event) noexcept {
    if (!invariant(before)) return rejected(before);
    State after = before;
    switch (event) {
    case Event::accept_consumed_dispatch:
        if (before.phase != Phase::empty) return rejected(before);
        after.phase = Phase::pending;
        after.receipt_bound = true;
        return applied(after);

    case Event::accept_wrong_dispatch:
        if (before.phase != Phase::empty) return rejected(before);
        set_result(after, Phase::fail_stop, Result::fail_stop, 1U, false);
        return applied(after);

    case Event::persist_pending_exact:
        if (before.phase != Phase::pending) return rejected(before);
        after.phase = Phase::ready;
        after.pending_exact = true;
        return applied(after);

    case Event::persist_pending_mismatch:
        if (before.phase != Phase::pending) return rejected(before);
        set_result(after, Phase::fail_stop, Result::fail_stop, 1U, false);
        return applied(after);

    case Event::external_successor_other:
        if (!can_hide_other_successor(before)) return rejected(before);
        after.endpoint = Endpoint::successor_other;
        return applied(after);

    case Event::invoke_effect_return:
    case Event::invoke_no_effect_return:
    case Event::invoke_nonreturn_before_effect:
    case Event::invoke_nonreturn_after_effect:
    case Event::invoke_malformed_before_effect:
    case Event::invoke_malformed_after_effect:
        if (before.phase != Phase::ready || before.invocation_count != 0U) {
            return rejected(before);
        }
        after.invocation_count = 1U;
        if (before.endpoint == Endpoint::successor_other) {
            set_result(after, Phase::fail_stop, Result::fail_stop, 1U, false);
            return applied(after, true);
        }
        if (event == Event::invoke_effect_return) {
            after.endpoint = Endpoint::successor_same;
            after.effect_count = 1U;
            set_result(after, Phase::terminal, Result::effect, 1U, false);
            return applied(after, true);
        }
        if (event == Event::invoke_no_effect_return) {
            set_result(after, Phase::terminal, Result::no_effect, 1U, false);
            return applied(after, true);
        }
        if (event == Event::invoke_nonreturn_after_effect
                || event == Event::invoke_malformed_after_effect) {
            after.endpoint = Endpoint::successor_same;
            after.effect_count = 1U;
        }
        set_result(after, Phase::uncertain, Result::uncertain, 1U, false);
        return applied(after, true);

    case Event::restart:
        if (before.phase == Phase::pending) {
            after.recovered = true;
            set_result(after, Phase::uncertain, Result::uncertain, 1U, false);
            return applied(after);
        }
        if (before.phase == Phase::ready) {
            after.recovered = true;
            set_result(after, Phase::uncertain, Result::uncertain, 1U, false);
            return applied(after);
        }
        if ((before.phase == Phase::uncertain
                || before.phase == Phase::terminal
                || before.phase == Phase::fail_stop)
                && !before.recovered) {
            after.recovered = true;
            return applied(after);
        }
        return rejected(before);

    case Event::recover_spent_receipt_exact:
        if (before.phase != Phase::uncertain || !before.recovered
                || before.pending_exact || !before.receipt_bound) {
            return rejected(before);
        }
        after.pending_exact = true;
        return applied(after);

    case Event::recover_spent_receipt_mismatch:
        if (before.phase != Phase::uncertain || !before.recovered
                || before.pending_exact || !before.receipt_bound) {
            return rejected(before);
        }
        set_result(after, Phase::fail_stop, Result::fail_stop, 2U, true);
        return applied(after, false, true);

    case Event::recover_spent_receipt_missing:
        if (before.phase != Phase::uncertain || !before.recovered
                || before.pending_exact || !before.receipt_bound) {
            return rejected(before);
        }
        return applied(after);

    case Event::query_predecessor:
        if (!query_allowed(before) || before.endpoint != Endpoint::predecessor) {
            return rejected(before);
        }
        set_result(after, Phase::terminal, Result::no_effect, 2U, true);
        return applied(after, false, true);

    case Event::query_successor_same:
        if (!query_allowed(before) || before.endpoint != Endpoint::successor_same) {
            return rejected(before);
        }
        set_result(after, Phase::terminal, Result::effect, 2U, true);
        return applied(after, false, true);

    case Event::query_successor_other:
        if (!query_allowed(before) || before.endpoint != Endpoint::successor_other) {
            return rejected(before);
        }
        set_result(after, Phase::fail_stop, Result::fail_stop, 2U, true);
        return applied(after, false, true);

    case Event::query_unavailable:
        if (!query_allowed(before)) return rejected(before);
        return applied(after);

    case Event::publish:
        if (before.result == Result::none
                || before.published_version >= before.result_version) {
            return rejected(before);
        }
        after.published_version = before.result_version;
        return applied(after, false, false, true);

    case Event::recovery_apply_attempt:
    case Event::mint_dispatch_attempt:
    case Event::route_override_attempt:
    case Event::retry_apply_attempt:
    case Event::stale_publication_attempt:
        return rejected(before);
    }
    return rejected(before);
}

std::string_view phase_name(const Phase value) noexcept {
    switch (value) {
    case Phase::empty: return "empty";
    case Phase::pending: return "pending";
    case Phase::ready: return "ready";
    case Phase::uncertain: return "uncertain";
    case Phase::terminal: return "terminal";
    case Phase::fail_stop: return "fail_stop";
    }
    return "invalid";
}

std::string_view endpoint_name(const Endpoint value) noexcept {
    switch (value) {
    case Endpoint::predecessor: return "predecessor";
    case Endpoint::successor_same: return "successor_same";
    case Endpoint::successor_other: return "successor_other";
    }
    return "invalid";
}

std::string_view result_name(const Result value) noexcept {
    switch (value) {
    case Result::none: return "none";
    case Result::effect: return "effect";
    case Result::no_effect: return "no_effect";
    case Result::uncertain: return "uncertain";
    case Result::fail_stop: return "fail_stop";
    }
    return "invalid";
}

std::string_view outcome_name(const Outcome value) noexcept {
    return value == Outcome::applied ? "applied" : "rejected";
}

std::string_view event_name(const Event value) noexcept {
    switch (value) {
    case Event::accept_consumed_dispatch: return "accept_consumed_dispatch";
    case Event::accept_wrong_dispatch: return "accept_wrong_dispatch";
    case Event::persist_pending_exact: return "persist_pending_exact";
    case Event::persist_pending_mismatch: return "persist_pending_mismatch";
    case Event::external_successor_other: return "external_successor_other";
    case Event::invoke_effect_return: return "invoke_effect_return";
    case Event::invoke_no_effect_return: return "invoke_no_effect_return";
    case Event::invoke_nonreturn_before_effect: return "invoke_nonreturn_before_effect";
    case Event::invoke_nonreturn_after_effect: return "invoke_nonreturn_after_effect";
    case Event::invoke_malformed_before_effect: return "invoke_malformed_before_effect";
    case Event::invoke_malformed_after_effect: return "invoke_malformed_after_effect";
    case Event::restart: return "restart";
    case Event::recover_spent_receipt_exact: return "recover_spent_receipt_exact";
    case Event::recover_spent_receipt_mismatch: return "recover_spent_receipt_mismatch";
    case Event::recover_spent_receipt_missing: return "recover_spent_receipt_missing";
    case Event::query_predecessor: return "query_predecessor";
    case Event::query_successor_same: return "query_successor_same";
    case Event::query_successor_other: return "query_successor_other";
    case Event::query_unavailable: return "query_unavailable";
    case Event::recovery_apply_attempt: return "recovery_apply_attempt";
    case Event::mint_dispatch_attempt: return "mint_dispatch_attempt";
    case Event::route_override_attempt: return "route_override_attempt";
    case Event::retry_apply_attempt: return "retry_apply_attempt";
    case Event::publish: return "publish";
    case Event::stale_publication_attempt: return "stale_publication_attempt";
    }
    return "invalid";
}

std::string state_key(const State& s) {
    std::ostringstream out;
    out << phase_name(s.phase) << '|'
        << endpoint_name(s.endpoint) << '|'
        << result_name(s.result) << '|'
        << static_cast<unsigned int>(s.result_version) << '|'
        << static_cast<unsigned int>(s.published_version) << '|'
        << static_cast<unsigned int>(s.invocation_count) << '|'
        << static_cast<unsigned int>(s.effect_count) << '|'
        << (s.receipt_bound ? '1' : '0') << '|'
        << (s.pending_exact ? '1' : '0') << '|'
        << (s.recovered ? '1' : '0') << '|'
        << (s.reconciled ? '1' : '0');
    return out.str();
}

std::string local_key(const State& s) {
    std::ostringstream out;
    out << phase_name(s.phase) << '|'
        << result_name(s.result) << '|'
        << static_cast<unsigned int>(s.result_version) << '|'
        << static_cast<unsigned int>(s.published_version) << '|'
        << static_cast<unsigned int>(s.invocation_count) << '|'
        << (s.pending_exact ? '1' : '0') << '|'
        << (s.recovered ? '1' : '0') << '|'
        << (s.reconciled ? '1' : '0');
    return out.str();
}

}  // namespace slopos::e0::generation_journal
