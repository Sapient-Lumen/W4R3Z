#include "slopos/e0/generation_journal/local_join.hpp"

#include <sqlite3.h>

#include <array>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <filesystem>
#include <limits>
#include <memory>
#include <optional>
#include <string>
#include <utility>

namespace slopos::e0::generation_journal {
namespace {

struct DatabaseCloser final {
    void operator()(sqlite3* database) const noexcept {
        if (database != nullptr) {
            (void)sqlite3_close_v2(database);
        }
    }
};
using Database = std::unique_ptr<sqlite3, DatabaseCloser>;

struct StatementCloser final {
    void operator()(sqlite3_stmt* statement) const noexcept {
        if (statement != nullptr) {
            (void)sqlite3_finalize(statement);
        }
    }
};
using Statement = std::unique_ptr<sqlite3_stmt, StatementCloser>;

struct FloorRow final {
    Digest identity{};
    FloorPoint point{};
    std::optional<EncodedSpendRecord> record{};
};

[[nodiscard]] std::array<std::uint8_t, 8U> encode_generation(
    const std::uint64_t value) noexcept {
    std::array<std::uint8_t, 8U> bytes{};
    for (std::size_t index = 0U; index < bytes.size(); ++index) {
        const std::size_t shift = (bytes.size() - 1U - index) * 8U;
        bytes[index] = static_cast<std::uint8_t>((value >> shift) & 0xffU);
    }
    return bytes;
}

[[nodiscard]] bool decode_generation(const void* data, const int bytes,
                                     std::uint64_t& value) noexcept {
    if (data == nullptr || bytes != 8) return false;
    const auto* input = static_cast<const std::uint8_t*>(data);
    std::uint64_t decoded = 0U;
    for (std::size_t index = 0U; index < 8U; ++index) {
        decoded = (decoded << 8U) | static_cast<std::uint64_t>(input[index]);
    }
    value = decoded;
    return true;
}

template <std::size_t Size>
[[nodiscard]] bool copy_blob(sqlite3_stmt* statement, const int column,
                             std::array<std::uint8_t, Size>& output) noexcept {
    const int bytes = sqlite3_column_bytes(statement, column);
    const void* data = sqlite3_column_blob(statement, column);
    if (data == nullptr || bytes != static_cast<int>(Size)) return false;
    const auto* input = static_cast<const std::uint8_t*>(data);
    for (std::size_t index = 0U; index < Size; ++index) {
        output[index] = input[index];
    }
    return true;
}

[[nodiscard]] bool execute(sqlite3* database, const char* sql) noexcept {
    char* detail = nullptr;
    const int status = sqlite3_exec(database, sql, nullptr, nullptr, &detail);
    if (detail != nullptr) sqlite3_free(detail);
    return status == SQLITE_OK;
}

[[nodiscard]] Database open_database(const std::filesystem::path& path,
                                     const int flags) noexcept {
    sqlite3* raw = nullptr;
    const std::string native = path.string();
    if (sqlite3_open_v2(native.c_str(), &raw, flags, nullptr) != SQLITE_OK) {
        if (raw != nullptr) (void)sqlite3_close_v2(raw);
        return Database{};
    }
    return Database(raw);
}

[[nodiscard]] bool configure_connection(sqlite3* database,
                                        const bool initialize) noexcept {
    if (sqlite3_busy_timeout(database, 10000) != SQLITE_OK) return false;
    if (!execute(database, "PRAGMA foreign_keys=ON;")) return false;
    if (!execute(database, "PRAGMA trusted_schema=OFF;")) return false;
    if (!execute(database, "PRAGMA synchronous=FULL;")) return false;
    if (initialize && !execute(database, "PRAGMA journal_mode=DELETE;")) {
        return false;
    }
    return true;
}

[[nodiscard]] Statement prepare(sqlite3* database, const char* sql) noexcept {
    sqlite3_stmt* raw = nullptr;
    if (sqlite3_prepare_v2(database, sql, -1, &raw, nullptr) != SQLITE_OK) {
        if (raw != nullptr) (void)sqlite3_finalize(raw);
        return Statement{};
    }
    return Statement(raw);
}

template <std::size_t Size>
[[nodiscard]] bool bind_blob(sqlite3_stmt* statement, const int parameter,
                             const std::array<std::uint8_t, Size>& value) noexcept {
    return sqlite3_bind_blob(statement, parameter, value.data(),
                             static_cast<int>(Size), SQLITE_TRANSIENT) == SQLITE_OK;
}

[[nodiscard]] bool exact_point(const FloorPoint& point) noexcept {
    return point.generation != 0U && !digest_is_zero(point.head);
}

[[nodiscard]] bool valid_request(const CompareAppendRequest& request,
                                 SpendRecordV1& decoded) noexcept {
    if (digest_is_zero(request.floor_identity)
        || !exact_point(request.expected) || !exact_point(request.target)
        || request.expected.generation == std::numeric_limits<std::uint64_t>::max()
        || request.target.generation != request.expected.generation + 1U
        || !decode_spend_record(request.record, decoded)) {
        return false;
    }
    return decoded.generation_from == request.expected.generation
        && decoded.generation_to == request.target.generation
        && decoded.predecessor_head == request.expected.head
        && spend_record_head(request.record) == request.target.head;
}

[[nodiscard]] bool read_floor(sqlite3* database, FloorRow& row) noexcept {
    Statement statement = prepare(database,
        "SELECT floor_identity, generation_be, head, current_record "
        "FROM slopos_floor WHERE singleton=1;");
    if (!statement || sqlite3_step(statement.get()) != SQLITE_ROW) return false;
    if (!copy_blob(statement.get(), 0, row.identity)) return false;
    if (!decode_generation(sqlite3_column_blob(statement.get(), 1),
                           sqlite3_column_bytes(statement.get(), 1),
                           row.point.generation)) {
        return false;
    }
    if (!copy_blob(statement.get(), 2, row.point.head)) return false;
    if (sqlite3_column_type(statement.get(), 3) == SQLITE_NULL) {
        row.record.reset();
    } else {
        EncodedSpendRecord record{};
        if (!copy_blob(statement.get(), 3, record)) return false;
        SpendRecordV1 decoded;
        if (!decode_spend_record(record, decoded)
            || decoded.generation_to != row.point.generation
            || spend_record_head(record) != row.point.head) {
            return false;
        }
        row.record = record;
    }
    if (sqlite3_step(statement.get()) != SQLITE_DONE) return false;
    return !digest_is_zero(row.identity) && exact_point(row.point);
}

[[nodiscard]] bool admission_count(sqlite3* database,
                                   std::uint64_t& count) noexcept {
    Statement statement = prepare(database,
        "SELECT count(*) FROM slopos_endpoint_admission;");
    if (!statement || sqlite3_step(statement.get()) != SQLITE_ROW) return false;
    const sqlite3_int64 observed = sqlite3_column_int64(statement.get(), 0);
    if (observed < 0) return false;
    count = static_cast<std::uint64_t>(observed);
    return sqlite3_step(statement.get()) == SQLITE_DONE;
}

[[nodiscard]] bool admissions_exact(sqlite3* database, const FloorRow& floor,
                                    const std::uint64_t expected_count) noexcept {
    Statement statement = prepare(database,
        "SELECT spend_head, floor_identity, generation_be, exact_record, "
        "provider_subject, publication_receipt, expectation_record, operation, pending_result "
        "FROM slopos_endpoint_admission ORDER BY generation_be;");
    if (!statement) return false;
    std::uint64_t count = 0U;
    bool current_seen = !floor.record.has_value();
    for (;;) {
        const int status = sqlite3_step(statement.get());
        if (status == SQLITE_DONE) break;
        if (status != SQLITE_ROW) return false;
        Digest head{};
        Digest identity{};
        EncodedSpendRecord exact{};
        Digest provider{};
        Digest publication{};
        Digest expectation{};
        Digest operation{};
        Digest pending{};
        std::uint64_t generation = 0U;
        if (!copy_blob(statement.get(), 0, head)
            || !copy_blob(statement.get(), 1, identity)
            || !decode_generation(sqlite3_column_blob(statement.get(), 2),
                                  sqlite3_column_bytes(statement.get(), 2), generation)
            || !copy_blob(statement.get(), 3, exact)
            || !copy_blob(statement.get(), 4, provider)
            || !copy_blob(statement.get(), 5, publication)
            || !copy_blob(statement.get(), 6, expectation)
            || !copy_blob(statement.get(), 7, operation)
            || !copy_blob(statement.get(), 8, pending)) {
            return false;
        }
        SpendRecordV1 decoded;
        if (!decode_spend_record(exact, decoded)
            || identity != floor.identity
            || generation != decoded.generation_to
            || head != spend_record_head(exact)
            || provider != decoded.provider_subject
            || publication != decoded.publication_receipt
            || expectation != decoded.expectation_record
            || operation != decoded.operation
            || pending != decoded.pending_result) {
            return false;
        }
        if (floor.record.has_value() && exact == *floor.record
            && generation == floor.point.generation && head == floor.point.head) {
            current_seen = true;
        }
        ++count;
    }
    return count == expected_count && current_seen;
}

[[nodiscard]] bool rollback(sqlite3* database) noexcept {
    return execute(database, "ROLLBACK;");
}

[[noreturn]] void cut_process(const HostedJoinFaultCut cut) noexcept {
    const int code = 80 + static_cast<int>(cut);
    std::_Exit(code);
}

[[nodiscard]] HostedJoinResult stopped(const HostedJoinStatus status,
                                       const FloorRow* row = nullptr,
                                       const std::uint64_t entries = 0U) noexcept {
    HostedJoinResult result;
    result.status = status;
    if (row != nullptr) {
        result.floor_identity = row->identity;
        result.current = row->point;
        result.current_record = row->record;
    }
    result.endpoint_entries = entries;
    return result;
}

[[nodiscard]] HostedJoinObservation unreadable(
    const HostedJoinReadStatus status) noexcept {
    HostedJoinObservation result;
    result.status = status;
    return result;
}

}  // namespace

bool initialize_hosted_join(const std::filesystem::path& path,
                            const Digest& floor_identity,
                            const FloorPoint& initial) noexcept {
    if (path.empty() || std::filesystem::exists(path)
        || digest_is_zero(floor_identity) || !exact_point(initial)) {
        return false;
    }
    Database database = open_database(
        path, SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE | SQLITE_OPEN_FULLMUTEX);
    if (!database || !configure_connection(database.get(), true)) return false;
    const char* schema =
        "BEGIN IMMEDIATE;"
        "CREATE TABLE slopos_floor("
        " singleton INTEGER PRIMARY KEY CHECK(singleton=1),"
        " floor_identity BLOB NOT NULL CHECK(length(floor_identity)=32),"
        " generation_be BLOB NOT NULL CHECK(length(generation_be)=8),"
        " head BLOB NOT NULL CHECK(length(head)=32),"
        " current_record BLOB CHECK(current_record IS NULL OR length(current_record)=352)"
        ") STRICT;"
        "CREATE TABLE slopos_endpoint_admission("
        " spend_head BLOB PRIMARY KEY CHECK(length(spend_head)=32),"
        " floor_identity BLOB NOT NULL CHECK(length(floor_identity)=32),"
        " generation_be BLOB NOT NULL UNIQUE CHECK(length(generation_be)=8),"
        " exact_record BLOB NOT NULL UNIQUE CHECK(length(exact_record)=352),"
        " provider_subject BLOB NOT NULL CHECK(length(provider_subject)=32),"
        " publication_receipt BLOB NOT NULL CHECK(length(publication_receipt)=32),"
        " expectation_record BLOB NOT NULL CHECK(length(expectation_record)=32),"
        " operation BLOB NOT NULL CHECK(length(operation)=32),"
        " pending_result BLOB NOT NULL CHECK(length(pending_result)=32)"
        ") STRICT;";
    if (!execute(database.get(), schema)) {
        (void)rollback(database.get());
        return false;
    }
    Statement insert = prepare(database.get(),
        "INSERT INTO slopos_floor(singleton, floor_identity, generation_be, head, current_record) "
        "VALUES(1, ?1, ?2, ?3, NULL);");
    const auto generation = encode_generation(initial.generation);
    if (!insert || !bind_blob(insert.get(), 1, floor_identity)
        || !bind_blob(insert.get(), 2, generation)
        || !bind_blob(insert.get(), 3, initial.head)
        || sqlite3_step(insert.get()) != SQLITE_DONE
        || !execute(database.get(), "COMMIT;")) {
        (void)rollback(database.get());
        return false;
    }
    return true;
}

HostedJoinResult compare_append_and_admit_hosted(
    const std::filesystem::path& path,
    const CompareAppendRequest& request,
    const HostedJoinFaultCut fault_cut) noexcept {
    SpendRecordV1 decoded;
    if (!valid_request(request, decoded)) {
        return stopped(HostedJoinStatus::malformed);
    }
    Database database = open_database(
        path, SQLITE_OPEN_READWRITE | SQLITE_OPEN_FULLMUTEX);
    if (!database || !configure_connection(database.get(), false)
        || !execute(database.get(), "BEGIN IMMEDIATE;")) {
        return stopped(HostedJoinStatus::unavailable);
    }
    if (fault_cut == HostedJoinFaultCut::after_begin) cut_process(fault_cut);

    FloorRow row;
    std::uint64_t entries = 0U;
    if (!read_floor(database.get(), row)
        || !admission_count(database.get(), entries)) {
        (void)rollback(database.get());
        return stopped(HostedJoinStatus::malformed);
    }
    if (row.identity != request.floor_identity) {
        (void)rollback(database.get());
        return stopped(HostedJoinStatus::identity_mismatch, &row, entries);
    }
    if (row.point == request.target) {
        if (!row.record.has_value() || *row.record != request.record) {
            (void)rollback(database.get());
            return stopped(HostedJoinStatus::conflict, &row, entries);
        }
        if (!admissions_exact(database.get(), row, entries)) {
            (void)rollback(database.get());
            return stopped(HostedJoinStatus::malformed, &row, entries);
        }
        if (!execute(database.get(), "COMMIT;")) {
            (void)rollback(database.get());
            return stopped(HostedJoinStatus::unavailable, &row, entries);
        }
        HostedJoinResult result = stopped(
            HostedJoinStatus::already_current, &row, entries);
        result.endpoint_bindings_exact = true;
        result.query_only = true;
        result.spent = true;
        result.response_authority = false;
        result.fail_stop = false;
        return result;
    }
    if (row.point != request.expected) {
        (void)rollback(database.get());
        return stopped(HostedJoinStatus::conflict, &row, entries);
    }

    const auto target_generation = encode_generation(request.target.generation);
    const auto expected_generation = encode_generation(request.expected.generation);
    Statement update = prepare(database.get(),
        "UPDATE slopos_floor SET generation_be=?1, head=?2, current_record=?3 "
        "WHERE singleton=1 AND floor_identity=?4 AND generation_be=?5 AND head=?6;");
    if (!update || !bind_blob(update.get(), 1, target_generation)
        || !bind_blob(update.get(), 2, request.target.head)
        || !bind_blob(update.get(), 3, request.record)
        || !bind_blob(update.get(), 4, request.floor_identity)
        || !bind_blob(update.get(), 5, expected_generation)
        || !bind_blob(update.get(), 6, request.expected.head)
        || sqlite3_step(update.get()) != SQLITE_DONE
        || sqlite3_changes(database.get()) != 1) {
        (void)rollback(database.get());
        return stopped(HostedJoinStatus::conflict, &row, entries);
    }
    if (fault_cut == HostedJoinFaultCut::after_floor_update) cut_process(fault_cut);

    Statement insert = prepare(database.get(),
        "INSERT INTO slopos_endpoint_admission("
        " spend_head, floor_identity, generation_be, exact_record, provider_subject,"
        " publication_receipt, expectation_record, operation, pending_result)"
        " VALUES(?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9);");
    if (!insert || !bind_blob(insert.get(), 1, request.target.head)
        || !bind_blob(insert.get(), 2, request.floor_identity)
        || !bind_blob(insert.get(), 3, target_generation)
        || !bind_blob(insert.get(), 4, request.record)
        || !bind_blob(insert.get(), 5, decoded.provider_subject)
        || !bind_blob(insert.get(), 6, decoded.publication_receipt)
        || !bind_blob(insert.get(), 7, decoded.expectation_record)
        || !bind_blob(insert.get(), 8, decoded.operation)
        || !bind_blob(insert.get(), 9, decoded.pending_result)
        || sqlite3_step(insert.get()) != SQLITE_DONE) {
        (void)rollback(database.get());
        return stopped(HostedJoinStatus::conflict, &row, entries);
    }
    if (fault_cut == HostedJoinFaultCut::after_endpoint_insert) cut_process(fault_cut);
    if (!execute(database.get(), "COMMIT;")) {
        (void)rollback(database.get());
        return stopped(HostedJoinStatus::unavailable, &row, entries);
    }
    if (fault_cut == HostedJoinFaultCut::after_commit_before_reply) {
        cut_process(fault_cut);
    }

    FloorRow committed;
    std::uint64_t committed_entries = 0U;
    if (!read_floor(database.get(), committed)
        || !admission_count(database.get(), committed_entries)
        || !admissions_exact(database.get(), committed, committed_entries)
        || committed_entries != entries + 1U
        || committed.point != request.target
        || !committed.record.has_value()
        || *committed.record != request.record) {
        return stopped(HostedJoinStatus::malformed);
    }
    HostedJoinResult result = stopped(
        HostedJoinStatus::admitted, &committed, committed_entries);
    result.endpoint_entry_created = true;
    result.endpoint_bindings_exact = true;
    result.query_only = true;
    result.spent = true;
    result.response_authority = false;
    result.fail_stop = false;
    return result;
}

HostedJoinObservation observe_hosted_join(
    const std::filesystem::path& path,
    const Digest& expected_floor_identity,
    const HostedJoinOpenMode mode) noexcept {
    const int flags = mode == HostedJoinOpenMode::read_only
        ? SQLITE_OPEN_READONLY | SQLITE_OPEN_FULLMUTEX
        : SQLITE_OPEN_READWRITE | SQLITE_OPEN_FULLMUTEX;
    Database database = open_database(path, flags);
    if (!database) return unreadable(HostedJoinReadStatus::unavailable);
    if (sqlite3_busy_timeout(database.get(), 10000) != SQLITE_OK
        || !execute(database.get(), "PRAGMA trusted_schema=OFF;")) {
        return unreadable(HostedJoinReadStatus::unavailable);
    }
    if (mode == HostedJoinOpenMode::recovering_read_write) {
        if (!execute(database.get(), "BEGIN IMMEDIATE;")
            || !execute(database.get(), "ROLLBACK;")) {
            return unreadable(HostedJoinReadStatus::unavailable);
        }
    } else if (!execute(database.get(), "PRAGMA query_only=ON;")) {
        return unreadable(HostedJoinReadStatus::unavailable);
    }
    FloorRow row;
    std::uint64_t entries = 0U;
    if (!read_floor(database.get(), row)
        || !admission_count(database.get(), entries)
        || !admissions_exact(database.get(), row, entries)) {
        return unreadable(HostedJoinReadStatus::malformed);
    }
    HostedJoinObservation result;
    result.status = row.identity == expected_floor_identity
        ? HostedJoinReadStatus::available
        : HostedJoinReadStatus::identity_mismatch;
    result.floor_identity = row.identity;
    result.current = row.point;
    result.current_record = row.record;
    result.endpoint_entries = entries;
    result.endpoint_bindings_exact = true;
    return result;
}

bool backup_hosted_join_snapshot(
    const std::filesystem::path& source,
    const std::filesystem::path& destination) noexcept {
    if (source.empty() || destination.empty() || source == destination
        || !std::filesystem::is_regular_file(source)
        || std::filesystem::exists(destination)) {
        return false;
    }
    Database from = open_database(source, SQLITE_OPEN_READONLY | SQLITE_OPEN_FULLMUTEX);
    Database to = open_database(destination,
        SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE | SQLITE_OPEN_FULLMUTEX);
    if (!from || !to || sqlite3_busy_timeout(from.get(), 10000) != SQLITE_OK
        || !configure_connection(to.get(), true)) {
        return false;
    }
    sqlite3_backup* backup = sqlite3_backup_init(
        to.get(), "main", from.get(), "main");
    if (backup == nullptr) return false;
    int status = SQLITE_OK;
    do {
        status = sqlite3_backup_step(backup, -1);
        if (status == SQLITE_BUSY || status == SQLITE_LOCKED) {
            sqlite3_sleep(1);
        }
    } while (status == SQLITE_BUSY || status == SQLITE_LOCKED);
    const int finish = sqlite3_backup_finish(backup);
    if (status != SQLITE_DONE || finish != SQLITE_OK) return false;
    FloorRow row;
    std::uint64_t entries = 0U;
    return read_floor(to.get(), row) && admission_count(to.get(), entries)
        && admissions_exact(to.get(), row, entries);
}

std::string_view hosted_join_status_name(const HostedJoinStatus value) noexcept {
    switch (value) {
    case HostedJoinStatus::admitted: return "admitted";
    case HostedJoinStatus::already_current: return "already_current";
    case HostedJoinStatus::conflict: return "conflict";
    case HostedJoinStatus::unavailable: return "unavailable";
    case HostedJoinStatus::malformed: return "malformed";
    case HostedJoinStatus::identity_mismatch: return "identity_mismatch";
    }
    return "invalid";
}

std::string_view hosted_join_read_status_name(
    const HostedJoinReadStatus value) noexcept {
    switch (value) {
    case HostedJoinReadStatus::available: return "available";
    case HostedJoinReadStatus::unavailable: return "unavailable";
    case HostedJoinReadStatus::malformed: return "malformed";
    case HostedJoinReadStatus::identity_mismatch: return "identity_mismatch";
    }
    return "invalid";
}

std::string_view hosted_join_fault_cut_name(
    const HostedJoinFaultCut value) noexcept {
    switch (value) {
    case HostedJoinFaultCut::none: return "none";
    case HostedJoinFaultCut::after_begin: return "after_begin";
    case HostedJoinFaultCut::after_floor_update: return "after_floor_update";
    case HostedJoinFaultCut::after_endpoint_insert: return "after_endpoint_insert";
    case HostedJoinFaultCut::after_commit_before_reply: return "after_commit_before_reply";
    }
    return "invalid";
}

}  // namespace slopos::e0::generation_journal
