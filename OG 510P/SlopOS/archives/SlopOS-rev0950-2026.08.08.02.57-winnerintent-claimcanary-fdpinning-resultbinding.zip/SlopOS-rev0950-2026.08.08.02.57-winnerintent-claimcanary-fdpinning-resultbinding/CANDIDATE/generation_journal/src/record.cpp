#include "slopos/e0/generation_journal/record.hpp"

#include <algorithm>
#include <limits>

namespace slopos::e0::generation_journal {
namespace {

void put_u16(EncodedRecord& out, const std::size_t offset,
             const std::uint16_t value) noexcept {
    out[offset] = static_cast<std::uint8_t>(value & 0xffU);
    out[offset + 1U] = static_cast<std::uint8_t>((value >> 8U) & 0xffU);
}

void put_u32(EncodedRecord& out, const std::size_t offset,
             const std::uint32_t value) noexcept {
    for (std::size_t index = 0U; index < 4U; ++index) {
        out[offset + index] = static_cast<std::uint8_t>(
            (value >> static_cast<unsigned int>(index * 8U)) & 0xffU);
    }
}

void put_u64(EncodedRecord& out, const std::size_t offset,
             const std::uint64_t value) noexcept {
    for (std::size_t index = 0U; index < 8U; ++index) {
        out[offset + index] = static_cast<std::uint8_t>(
            (value >> static_cast<unsigned int>(index * 8U)) & 0xffU);
    }
}

[[nodiscard]] std::uint16_t get_u16(const EncodedRecord& in,
                                    const std::size_t offset) noexcept {
    return static_cast<std::uint16_t>(in[offset])
         | static_cast<std::uint16_t>(
             static_cast<std::uint16_t>(in[offset + 1U]) << 8U);
}

[[nodiscard]] std::uint32_t get_u32(const EncodedRecord& in,
                                    const std::size_t offset) noexcept {
    std::uint32_t value = 0U;
    for (std::size_t index = 0U; index < 4U; ++index) {
        value |= static_cast<std::uint32_t>(in[offset + index])
              << static_cast<unsigned int>(index * 8U);
    }
    return value;
}

[[nodiscard]] std::uint64_t get_u64(const EncodedRecord& in,
                                    const std::size_t offset) noexcept {
    std::uint64_t value = 0U;
    for (std::size_t index = 0U; index < 8U; ++index) {
        value |= static_cast<std::uint64_t>(in[offset + index])
              << static_cast<unsigned int>(index * 8U);
    }
    return value;
}

[[nodiscard]] bool nonzero(const std::array<std::uint8_t, 32U>& value) noexcept {
    return std::any_of(value.begin(), value.end(),
                       [](const std::uint8_t byte) { return byte != 0U; });
}

[[nodiscard]] bool terminal_result(const Result result) noexcept {
    return result == Result::effect || result == Result::no_effect
        || result == Result::uncertain || result == Result::fail_stop;
}

}  // namespace

std::uint32_t record_crc32(const std::uint8_t* bytes,
                           const std::size_t length) noexcept {
    std::uint32_t crc = 0xffffffffU;
    for (std::size_t index = 0U; index < length; ++index) {
        crc ^= static_cast<std::uint32_t>(bytes[index]);
        for (unsigned int bit = 0U; bit < 8U; ++bit) {
            const std::uint32_t mask = 0U - (crc & 1U);
            crc = (crc >> 1U) ^ (0xedb88320U & mask);
        }
    }
    return ~crc;
}

bool record_invariant(const Record& record) noexcept {
    if (record.sequence == 0U || record.sequence > 2U
        || record.generation_from == 0U
        || record.generation_from == std::numeric_limits<std::uint64_t>::max()
        || record.generation_to != record.generation_from + 1U
        || !record.consumed_dispatch
        || !nonzero(record.operation_binding)
        || !nonzero(record.spent_receipt_binding)) {
        return false;
    }
    if (record.kind == RecordKind::pending) {
        return record.sequence == 1U && record.result == Result::none
            && !record.reconciled;
    }
    if (record.kind != RecordKind::result
            && record.kind != RecordKind::publication) return false;
    if (!terminal_result(record.result)) return false;
    if (record.result == Result::uncertain && record.sequence != 1U) return false;
    return record.reconciled == (record.sequence == 2U);
}

bool encode_record(const Record& record, EncodedRecord& output) noexcept {
    if (!record_invariant(record)) return false;
    output.fill(0U);
    constexpr std::array<std::uint8_t, 8U> magic{{
        'S', 'L', 'O', 'P', 'G', 'J', '0', '1'}};
    std::copy(magic.begin(), magic.end(), output.begin());
    output[8U] = 1U;
    output[9U] = static_cast<std::uint8_t>(record.kind);
    put_u16(output, 10U, static_cast<std::uint16_t>(kRecordBytes));
    put_u64(output, 12U, record.sequence);
    put_u64(output, 20U, record.generation_from);
    put_u64(output, 28U, record.generation_to);
    std::copy(record.operation_binding.begin(), record.operation_binding.end(),
              output.begin() + 36);
    std::copy(record.spent_receipt_binding.begin(),
              record.spent_receipt_binding.end(), output.begin() + 68);
    put_u64(output, 100U, kFixedEndpointId);
    output[108U] = static_cast<std::uint8_t>(record.result);
    output[109U] = static_cast<std::uint8_t>(
        (record.consumed_dispatch ? 1U : 0U)
        | (record.reconciled ? 2U : 0U));
    put_u32(output, 124U, record_crc32(output.data(), 124U));
    return true;
}

bool decode_record(const EncodedRecord& input, Record& output) noexcept {
    constexpr std::array<std::uint8_t, 8U> magic{{
        'S', 'L', 'O', 'P', 'G', 'J', '0', '1'}};
    if (!std::equal(magic.begin(), magic.end(), input.begin())
        || input[8U] != 1U
        || get_u16(input, 10U) != kRecordBytes
        || get_u64(input, 100U) != kFixedEndpointId
        || get_u32(input, 124U) != record_crc32(input.data(), 124U)) {
        return false;
    }
    for (std::size_t index = 110U; index < 124U; ++index) {
        if (input[index] != 0U) return false;
    }
    if ((input[109U] & 0xfcU) != 0U) return false;
    const auto kind = static_cast<RecordKind>(input[9U]);
    const auto result = static_cast<Result>(input[108U]);
    if ((kind != RecordKind::pending && kind != RecordKind::result
         && kind != RecordKind::publication)
        || static_cast<std::uint8_t>(result)
            > static_cast<std::uint8_t>(Result::fail_stop)) {
        return false;
    }
    Record candidate;
    candidate.kind = kind;
    candidate.sequence = get_u64(input, 12U);
    candidate.generation_from = get_u64(input, 20U);
    candidate.generation_to = get_u64(input, 28U);
    std::copy(input.begin() + 36, input.begin() + 68,
              candidate.operation_binding.begin());
    std::copy(input.begin() + 68, input.begin() + 100,
              candidate.spent_receipt_binding.begin());
    candidate.result = result;
    candidate.consumed_dispatch = (input[109U] & 1U) != 0U;
    candidate.reconciled = (input[109U] & 2U) != 0U;
    if (!record_invariant(candidate)) return false;
    output = candidate;
    return true;
}

}  // namespace slopos::e0::generation_journal
