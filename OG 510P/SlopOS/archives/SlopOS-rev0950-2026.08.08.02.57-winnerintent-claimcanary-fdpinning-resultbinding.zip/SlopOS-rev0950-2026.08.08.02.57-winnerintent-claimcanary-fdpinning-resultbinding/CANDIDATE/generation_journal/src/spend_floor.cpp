#include "slopos/e0/generation_journal/spend_floor.hpp"

#include <limits>

namespace slopos::e0::generation_journal {
namespace {

[[nodiscard]] constexpr SpendDecision decision(
    const SpendRelation relation, const bool compare_append_allowed,
    const bool query_only, const bool rollback_detected,
    const bool fail_stop) noexcept {
    return SpendDecision{relation, compare_append_allowed, query_only,
                         rollback_detected, fail_stop};
}

[[nodiscard]] bool point_exact(const FloorPoint& point) noexcept {
    return point.generation > 0U && !digest_is_zero(point.head);
}

[[nodiscard]] bool request_valid(const CompareAppendRequest& request) noexcept {
    if (digest_is_zero(request.floor_identity)
        || !point_exact(request.expected) || !point_exact(request.target)
        || request.expected.generation == std::numeric_limits<std::uint64_t>::max()
        || request.target.generation != request.expected.generation + 1U) {
        return false;
    }
    SpendRecordV1 record;
    return decode_spend_record(request.record, record)
        && record.generation_from == request.expected.generation
        && record.generation_to == request.target.generation
        && record.predecessor_head == request.expected.head
        && spend_record_head(request.record) == request.target.head;
}

[[nodiscard]] bool observed_record_valid(
    const ProtectedFloorObservation& floor) noexcept {
    if (!floor.current_record.has_value()) return true;
    if (!floor.content_bound) return false;
    SpendRecordV1 record;
    return decode_spend_record(*floor.current_record, record)
        && record.generation_to == floor.current.generation
        && spend_record_head(*floor.current_record) == floor.current.head;
}

[[nodiscard]] bool response_exact(
    const CompareAppendRequest& request,
    const CompareAppendResponse& response) noexcept {
    if (response.floor_identity != request.floor_identity
        || response.current != request.target || !response.content_bound
        || !response.current_record.has_value()
        || *response.current_record != request.record) {
        return false;
    }
    SpendRecordV1 record;
    return decode_spend_record(*response.current_record, record)
        && spend_record_head(*response.current_record) == response.current.head;
}

}  // namespace

SpendDecision evaluate_spend(
    const LocalSpendObservation& local,
    const ProtectedFloorObservation& floor,
    const EncodedSpendRecord& candidate,
    const Digest& expected_floor_identity) noexcept {
    if (digest_is_zero(expected_floor_identity)
        || !point_exact(local.confirmed)
        || local.pending_present != local.pending.has_value()) {
        return decision(SpendRelation::malformed, false, false, false, true);
    }

    SpendRecordV1 candidate_record;
    if (!decode_spend_record(candidate, candidate_record)
        || candidate_record.generation_from != local.confirmed.generation
        || candidate_record.predecessor_head != local.confirmed.head) {
        return decision(SpendRelation::malformed, false, false, false, true);
    }
    const FloorPoint target{candidate_record.generation_to,
                            spend_record_head(candidate)};

    if (local.pending.has_value()) {
        SpendRecordV1 pending_record;
        if (!decode_spend_record(*local.pending, pending_record)) {
            return decision(SpendRelation::malformed, false, false, false, true);
        }
        if (*local.pending != candidate) {
            return decision(SpendRelation::foreign_spend, false, false, false, true);
        }
    }

    if (floor.status == FloorReadStatus::unavailable) {
        return decision(SpendRelation::floor_unavailable, false, false, false, true);
    }
    if (floor.status == FloorReadStatus::malformed) {
        return decision(SpendRelation::malformed, false, false, false, true);
    }
    if (floor.floor_identity != expected_floor_identity) {
        return decision(SpendRelation::identity_mismatch, false, false, false, true);
    }
    if (floor.current.generation == 0U
        || (!floor.content_bound && (!digest_is_zero(floor.current.head)
                                     || floor.current_record.has_value()))
        || (floor.content_bound && digest_is_zero(floor.current.head))
        || !observed_record_valid(floor)) {
        return decision(SpendRelation::malformed, false, false, false, true);
    }
    if (!floor.content_bound) {
        return decision(SpendRelation::scalar_ambiguous, false, false,
                        floor.current.generation > local.confirmed.generation,
                        true);
    }
    if (floor.current.generation < local.confirmed.generation) {
        return decision(SpendRelation::local_ahead, false, false, false, true);
    }
    if (floor.current.generation == local.confirmed.generation) {
        if (floor.current.head != local.confirmed.head) {
            return decision(SpendRelation::foreign_spend, false, false, false, true);
        }
        return local.pending_present
            ? decision(SpendRelation::prepared_exact, true, false, false, false)
            : decision(SpendRelation::fresh, true, false, false, false);
    }
    if (floor.current.generation == target.generation) {
        if (floor.current.head == target.head) {
            return decision(SpendRelation::same_spend_committed, false, true,
                            true, false);
        }
        return decision(SpendRelation::foreign_spend, false, false, true, true);
    }
    return decision(SpendRelation::generation_jump, false, false,
                    floor.current.generation > local.confirmed.generation,
                    true);
}

std::optional<CompareAppendRequest> make_compare_append_request(
    const LocalSpendObservation& local,
    const ProtectedFloorObservation& floor,
    const EncodedSpendRecord& candidate,
    const Digest& expected_floor_identity) noexcept {
    const SpendDecision evaluated = evaluate_spend(
        local, floor, candidate, expected_floor_identity);
    if (!evaluated.compare_append_allowed) return std::nullopt;
    SpendRecordV1 record;
    if (!decode_spend_record(candidate, record)) return std::nullopt;
    return CompareAppendRequest{
        expected_floor_identity,
        local.confirmed,
        FloorPoint{record.generation_to, spend_record_head(candidate)},
        candidate,
    };
}

AppendDecision accept_compare_append_response(
    const CompareAppendRequest& request,
    const CompareAppendResponse& response) noexcept {
    if (!request_valid(request)) return AppendDecision{};
    if (response.floor_identity != request.floor_identity
        || response.status == AppendStatus::identity_mismatch) {
        return AppendDecision{};
    }
    switch (response.status) {
    case AppendStatus::advanced:
        if (response_exact(request, response)) {
            return AppendDecision{false, true, true, false};
        }
        return AppendDecision{};
    case AppendStatus::already_current:
        if (response_exact(request, response)) {
            return AppendDecision{false, true, true, false};
        }
        return AppendDecision{};
    case AppendStatus::conflict:
    case AppendStatus::unavailable:
    case AppendStatus::malformed:
    case AppendStatus::identity_mismatch:
        return AppendDecision{};
    }
    return AppendDecision{};
}

std::string_view floor_read_status_name(const FloorReadStatus value) noexcept {
    switch (value) {
    case FloorReadStatus::available: return "available";
    case FloorReadStatus::unavailable: return "unavailable";
    case FloorReadStatus::malformed: return "malformed";
    }
    return "invalid";
}

std::string_view spend_relation_name(const SpendRelation value) noexcept {
    switch (value) {
    case SpendRelation::fresh: return "fresh";
    case SpendRelation::prepared_exact: return "prepared_exact";
    case SpendRelation::same_spend_committed: return "same_spend_committed";
    case SpendRelation::foreign_spend: return "foreign_spend";
    case SpendRelation::scalar_ambiguous: return "scalar_ambiguous";
    case SpendRelation::floor_unavailable: return "floor_unavailable";
    case SpendRelation::local_ahead: return "local_ahead";
    case SpendRelation::generation_jump: return "generation_jump";
    case SpendRelation::malformed: return "malformed";
    case SpendRelation::identity_mismatch: return "identity_mismatch";
    }
    return "invalid";
}

std::string_view append_status_name(const AppendStatus value) noexcept {
    switch (value) {
    case AppendStatus::advanced: return "advanced";
    case AppendStatus::already_current: return "already_current";
    case AppendStatus::conflict: return "conflict";
    case AppendStatus::unavailable: return "unavailable";
    case AppendStatus::malformed: return "malformed";
    case AppendStatus::identity_mismatch: return "identity_mismatch";
    }
    return "invalid";
}

}  // namespace slopos::e0::generation_journal
