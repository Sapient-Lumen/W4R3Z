#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/exact_predecessor_consumption.hpp"

#include <algorithm>
#include <array>
#include <vector>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::exact_predecessor_consumption {
namespace {

constexpr std::size_t npos = chain_cut_count;

[[nodiscard]] bool any(const Digest& digest) noexcept {
    for (const auto octet : digest) if (octet != 0U) return true;
    return false;
}

[[nodiscard]] Digest basis_for(const Phase phase, const ChainTrace& trace) noexcept {
    switch (phase) {
    case Phase::witness_publication: return trace.parent.witness_digest;
    case Phase::floor_publication: return trace.parent.floor_digest;
    case Phase::join_publication: return trace.parent.cutover_id;
    case Phase::cold_reopen_receipt: return trace.parent.state.terminal_digest;
    case Phase::deletion_authorization: return trace.parent.state.transition_digest;
    }
    return Digest{};
}

[[nodiscard]] bool blank_absence(const PhaseReceipt& receipt) noexcept {
    const std::array<bool, 8U> flags{
        receipt.present, receipt.authenticated, receipt.durable, receipt.single_view,
        receipt.independently_reopenable, receipt.survives_restore,
        receipt.survives_succession, receipt.published};
    const std::array<Digest, 11U> digests{
        receipt.record_digest, receipt.cutover_id, receipt.request_id,
        receipt.transition_digest, receipt.register_incarnation,
        receipt.terminal_digest, receipt.witness_digest, receipt.floor_digest,
        receipt.basis_digest, receipt.predecessor_a, receipt.predecessor_b};
    return std::none_of(flags.cbegin(), flags.cend(), [](const bool value) { return value; })
        && std::none_of(digests.cbegin(), digests.cend(), [](const Digest& value) { return any(value); });
}

[[nodiscard]] ChainReport reject(const ChainCode code, const bool parent = false) noexcept {
    ChainReport result{};
    result.code = code;
    result.parent_accepted = parent;
    return result;
}

[[nodiscard]] ChainReport accept(
    const ChainCode code,
    const bool parent_safe,
    const bool subjects,
    const bool components,
    const bool unique,
    const bool edges,
    const bool publication,
    const bool order,
    const bool monotone,
    const bool prefixes,
    const bool complete,
    const bool safe,
    const bool stopped) noexcept {
    ChainReport result{};
    result.code = code;
    result.accepted = true;
    result.parent_accepted = true;
    result.parent_reclamation_safe = parent_safe;
    result.receipt_subjects_exact = subjects;
    result.receipt_components_exact = components;
    result.receipt_digests_unique = unique;
    result.exact_predecessor_edges = edges;
    result.durable_publications = publication;
    result.strict_phase_order = order;
    result.monotone_visibility = monotone;
    result.every_prefix_covered = prefixes;
    result.chain_complete = complete;
    result.deletion_safe = safe;
    result.live_record_must_remain = !safe;
    result.fail_stopped = stopped;
    return result;
}

}  // namespace

ChainReport evaluate_reference(const ChainTrace& trace) noexcept {
    const auto parent = proof_basis_cutover::evaluate_reference(trace.parent);
    if (!parent.accepted) return reject(ChainCode::parent_relation_rejected);
    if (trace.reclamation_requested != trace.parent.reclamation_requested) {
        return reject(ChainCode::reclamation_request_mismatch, true);
    }

    bool subjects = true;
    bool components = true;
    bool publication = true;
    std::vector<Digest> identities;
    identities.reserve(phase_count);
    for (std::size_t slot = 0U; slot < phase_count; ++slot) {
        const auto& receipt = trace.receipts[slot];
        if (!receipt.present) {
            if (!blank_absence(receipt)) return reject(ChainCode::receipt_shape_invalid, true);
            continue;
        }
        if (static_cast<std::size_t>(receipt.phase) != slot) {
            return reject(ChainCode::receipt_phase_mismatch, true);
        }
        const bool one_subject = receipt.cutover_id == trace.parent.cutover_id
            && receipt.request_id == trace.parent.state.request_id
            && receipt.transition_digest == trace.parent.state.transition_digest
            && receipt.register_incarnation == trace.parent.state.register_incarnation
            && receipt.terminal_digest == trace.parent.state.terminal_digest
            && receipt.witness_digest == trace.parent.witness_digest
            && receipt.floor_digest == trace.parent.floor_digest
            && receipt.terminal_kind == trace.parent.state.terminal_kind;
        if (!one_subject) return reject(ChainCode::receipt_subject_mismatch, true);
        subjects = subjects && one_subject;
        const bool one_component = receipt.basis_digest == basis_for(receipt.phase, trace);
        if (!one_component) return reject(ChainCode::receipt_component_mismatch, true);
        components = components && one_component;
        if (!any(receipt.record_digest)) return reject(ChainCode::receipt_digest_zero, true);
        identities.push_back(receipt.record_digest);
        publication = publication
            && receipt.authenticated && receipt.durable && receipt.single_view
            && receipt.independently_reopenable && receipt.survives_restore
            && receipt.survives_succession && receipt.published;
    }
    std::sort(identities.begin(), identities.end());
    if (std::adjacent_find(identities.begin(), identities.end()) != identities.end()) {
        return reject(ChainCode::receipt_digest_duplicate, true);
    }

    if (!trace.cuts[0].live_record_visible || trace.cuts[0].deletion_applied) {
        return reject(ChainCode::trace_initial_state_invalid, true);
    }
    for (const auto& snapshot : trace.cuts) {
        if (snapshot.live_record_visible && snapshot.deletion_applied) {
            return reject(ChainCode::trace_deleted_and_live, true);
        }
        if (!snapshot.live_record_visible && !snapshot.deletion_applied) {
            return reject(ChainCode::trace_absent_without_deletion, true);
        }
        for (std::size_t slot = 0U; slot < phase_count; ++slot) {
            if (snapshot.receipt_visible[slot] && !trace.receipts[slot].present) {
                return reject(ChainCode::receipt_shape_invalid, true);
            }
        }
    }

    const auto& w = trace.receipts[0];
    const auto& f = trace.receipts[1];
    const auto& j = trace.receipts[2];
    const auto& r = trace.receipts[3];
    const auto& a = trace.receipts[4];
    bool edges = true;
    if (w.present) edges = edges && !any(w.predecessor_a) && !any(w.predecessor_b);
    if (f.present) edges = edges && !any(f.predecessor_a) && !any(f.predecessor_b);
    if (j.present) edges = edges && w.present && f.present
        && j.predecessor_a == w.record_digest && j.predecessor_b == f.record_digest;
    if (r.present) edges = edges && j.present
        && r.predecessor_a == j.record_digest && !any(r.predecessor_b);
    if (a.present) edges = edges && r.present
        && a.predecessor_a == r.record_digest && !any(a.predecessor_b);

    bool any_delete = false;
    for (const auto& cut : trace.cuts) any_delete = any_delete || cut.deletion_applied;
    if (any_delete) edges = edges && a.present
        && trace.deletion_consumed_authorization_digest == a.record_digest;

    std::array<std::size_t, phase_count> first{};
    first.fill(npos);
    std::array<bool, phase_count> seen{};
    bool monotone = true;
    bool deleted = false;
    std::size_t first_deletion = npos;
    bool absent = false;
    for (std::size_t cut = 0U; cut < chain_cut_count; ++cut) {
        const auto& snapshot = trace.cuts[cut];
        for (std::size_t slot = 0U; slot < phase_count; ++slot) {
            if (snapshot.receipt_visible[slot] && first[slot] == npos) first[slot] = cut;
            if (seen[slot] && !snapshot.receipt_visible[slot]) monotone = false;
            seen[slot] = seen[slot] || snapshot.receipt_visible[slot];
        }
        if (snapshot.deletion_applied && first_deletion == npos) first_deletion = cut;
        if (deleted && !snapshot.deletion_applied) monotone = false;
        if (absent && snapshot.live_record_visible) monotone = false;
        deleted = deleted || snapshot.deletion_applied;
        absent = absent || !snapshot.live_record_visible;
    }

    bool order = true;
    if (first[2] != npos) order = first[0] != npos && first[1] != npos
        && first[0] < first[2] && first[1] < first[2];
    if (first[3] != npos) order = order && first[2] != npos && first[2] < first[3];
    if (first[4] != npos) order = order && first[3] != npos && first[3] < first[4];
    if (first_deletion != npos) order = order && first[4] != npos && first[4] < first_deletion;

    bool prefixes = true;
    for (std::size_t cut = 0U; cut < chain_cut_count; ++cut) {
        const auto& snapshot = trace.cuts[cut];
        if (!snapshot.deletion_applied) {
            prefixes = prefixes && snapshot.live_record_visible;
            continue;
        }
        bool complete_at_cut = true;
        for (const bool visible : snapshot.receipt_visible) complete_at_cut = complete_at_cut && visible;
        prefixes = prefixes && parent.reclamation_safe && complete_at_cut && edges && publication && order
            && first[4] != npos && first[4] < cut;
    }

    bool all_present = true;
    bool all_final = true;
    for (std::size_t slot = 0U; slot < phase_count; ++slot) {
        all_present = all_present && trace.receipts[slot].present;
        all_final = all_final && trace.cuts.back().receipt_visible[slot];
    }
    const bool complete = all_present && all_final && edges && publication && order && monotone;
    const bool safe = parent.reclamation_safe && trace.reclamation_requested
        && complete && prefixes && trace.cuts.back().deletion_applied
        && !trace.cuts.back().live_record_visible;
    const bool ready = complete && prefixes && trace.cuts.back().live_record_visible
        && !trace.cuts.back().deletion_applied;

    if (trace.equivocation_observed) {
        return accept(ChainCode::accepted_equivocation_fail_stop, parent.reclamation_safe,
            subjects, components, true, edges, publication, order, monotone, prefixes, complete, false, true);
    }
    if (!monotone) {
        return accept(ChainCode::accepted_regression_fail_stop, parent.reclamation_safe,
            subjects, components, true, edges, publication, order, monotone, prefixes, complete, false, true);
    }
    if (safe) return accept(ChainCode::accepted_chain_complete, true,
        subjects, components, true, true, true, true, true, true, true, true, false);
    if (ready) return accept(ChainCode::accepted_chain_ready_live_retained, parent.reclamation_safe,
        subjects, components, true, true, true, true, true, true, true, false, false);
    if (!edges) return accept(ChainCode::accepted_reclamation_refused_exact_predecessor, parent.reclamation_safe,
        subjects, components, true, false, publication, order, true, prefixes, false, false, false);
    if (!publication) return accept(ChainCode::accepted_reclamation_refused_publication, parent.reclamation_safe,
        subjects, components, true, true, false, order, true, prefixes, false, false, false);
    if (!order) return accept(ChainCode::accepted_reclamation_refused_phase_order, parent.reclamation_safe,
        subjects, components, true, true, true, false, true, prefixes, false, false, false);
    if (!prefixes) return accept(ChainCode::accepted_reclamation_refused_prefix_gap, parent.reclamation_safe,
        subjects, components, true, true, true, true, true, false, complete, false, false);
    return accept(ChainCode::accepted_chain_prefix_live_retained, parent.reclamation_safe,
        subjects, components, true, true, true, true, true, true, complete, false, false);
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::exact_predecessor_consumption
