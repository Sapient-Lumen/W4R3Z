#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/reopen_receipt_chain/external_premise_admission/control_fate_falsification/relocatable_provenance.hpp"

#include <filesystem>
#include <iostream>

int main(int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "usage: slopos_relocatable_provenance OUTPUT_DIRECTORY\n";
        return 2;
    }
    const bool ok = slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification::relocatable_provenance::run_campaign(
        std::filesystem::path(argv[1]));
    std::cout << "RELOCATABLE_PROVENANCE_HARNESS=" << (ok ? "PASS" : "FAIL") << '\n';
    return ok ? 0 : 1;
}
