# Proof Basis Cutover V1

## Boundary

This is a finite Epoch-Zero child of Terminal Outcome Continuity V1. It accepts
that parent's four path facts and asks whether proof custody remains complete at
every crash boundary while a live terminal record is replaced. It performs no
I/O and creates no new semantic island.

## The no-gap law

For crash cut `c`:

```text
ExecutionCovered(c) := LiveRecordExecution(c) OR SuccessorFloorExecution(c)
HistoryCovered(c)   := LiveRecordHistory(c)   OR TerminalWitnessHistory(c)
SameHistoryBasis(c) := CompleteLiveRecord(c)  OR JoinedReplacement(c)
CutCovered(c)       := ExecutionCovered(c)
                       AND HistoryCovered(c)
                       AND SameHistoryBasis(c)
                       AND PhaseOrderValid(c)
                       AND AuthorizationAndDeletionValid(c)
```

A cutover is safe only when every admitted cut is covered. Final-state
conjunction is insufficient. If the record is deleted after the witness but
before the floor, there is an execution gap even if the floor appears later. If
it is deleted after the floor but before the witness, there is a history gap. If
both exist but no exact join binds them to one request and history, there is a
join gap.

## Exact join

The join receipt binds one nonzero cutover identity, exact request, transition,
old register incarnation, terminal kind and digest, exact witness digest, and
exact floor digest. It must be authenticated, durable, and observed through one
non-equivocal view. Before reclamation, the joined basis must also be
independently reopenable and survive the admitted restore and later-succession
corpus.

The join is evidence of co-reference, not authority. A constructor can fabricate
all its bytes. External authenticity, currentness, custody, and owner admission
remain open.

## Seven cut boundaries

1. `T0_live`: the exact live terminal record is the complete basis.
2. `T1_first_replacement`: witness or floor may be prepared; live basis remains.
3. `T2_both_replacements`: both may exist; live basis remains.
4. `T3_join`: exact same-history join becomes durable; live basis remains.
5. `T4_cold_reopen`: a replacement-only reopener reconstructs the joined basis
   while the live basis remains available as the bridge.
6. `T5_authorize`: deletion authorization may become durable only after the
   observed cold reopen; live basis remains.
7. `T6_delete`: the live record may disappear only with the joined, reopened
   replacement basis.

Witness, floor, join, cold-reopen observation, authorization, and deletion are
monotone. The live record may transition from present to absent once;
resurrection or loss of a replacement is fail-stop.

## Strict predecessor order

State conjunction does not itself prove happens-before. For the first durable
observation of each step:

```text
IntroduceJoin(c)          -> WitnessAndFloorSeenBefore(c)
IntroduceColdReopen(c)    -> JoinSeenBefore(c)
IntroduceAuthorization(c) -> ColdReopenSeenBefore(c)
IntroduceDeletion(c)      -> AuthorizationSeenBefore(c)
```

“Before” means an earlier modeled crash cut, not another bit becoming true in
the same row. This hosted relation imports no transactional primitive capable of
atomically joining adjacent phases. A mechanism may later discharge a narrower
atomicity theorem, but until then same-cut phase collapse is refused and the
live record remains.

## Reclamation judgment

```text
ReclamationSafe := ReclamationRequested
                   AND EveryCutCovered
                   AND NoPhaseOrderGap
                   AND FinalRecordDeleted
                   AND FinalJoinedReplacement
                   AND FinalColdReopen
                   AND JoinSurvivesRestoreAndSuccession
```

`CutoverReady` means every cut is covered, the joined replacement has passed a
replacement-only cold reopen, and the live record is still retained. Readiness
is not authorization and authorization is not deletion. Anything weaker leaves
`live_record_must_remain = true`.

## Explicit nonproofs

The following do not close a cut: eventual arrival of a missing component,
client acknowledgement, TTL, a deletion marker, two valid but unjoined
receipts, constructor reopen, same-domain restore, same-cut join/reopen,
same-cut reopen/authorization, same-cut authorization/deletion, or a final state
that hides an earlier uncovered interval.

## Trace-shape conservation

The child and parent reclamation-request bits must be identical. Join visibility
requires witness and floor visibility in the same cut. A cold-reopen receipt
cannot precede a joined replacement basis. Record absence requires a recorded
deletion event; a mere disappearance is not reinterpreted as successful
reclamation. These are malformed traces, not weaker positive proofs.
