#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/reopen_receipt_chain/external_premise_admission/control_fate_falsification/relocatable_provenance/observed_output_closure.hpp"

#include "parent_output_set.hpp"
#include "slopos/e0/generation_journal/spend_record.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <span>
#include <string>
#include <string_view>
#include <vector>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification::relocatable_provenance::observed_output_closure {
namespace {

#ifndef SLOPOS_OOC_PARENT_OUTPUT_CARRIER_SHA256_HEX
#error "reference build requires exact prior output-set carrier"
#endif
#ifndef SLOPOS_OOC_PARENT_OUTPUT_CARRIER_BYTES
#error "reference build requires exact prior output-set carrier bytes"
#endif
#ifndef SLOPOS_OOC_RESERVED_POLICY_SHA256_HEX
#error "reference build requires exact reserved-namespace policy"
#endif
#ifndef SLOPOS_OOC_REOPENER_IMPLEMENTATION_SHA256_HEX
#error "reference build requires exact hosted reopener implementation"
#endif

[[nodiscard]] Digest parse_hex(const std::string_view text) noexcept {
    const auto nibble = [](const char c) noexcept -> std::uint8_t {
        if (c >= '0' && c <= '9') return static_cast<std::uint8_t>(c - '0');
        if (c >= 'a' && c <= 'f') return static_cast<std::uint8_t>(c - 'a' + 10);
        return 255U;
    };
    Digest out{};
    if (text.size() != 64U) return out;
    for (std::size_t i = 0U; i < out.size(); ++i) {
        const auto a = nibble(text[2U * i]);
        const auto b = nibble(text[2U * i + 1U]);
        if (a > 15U || b > 15U) return {};
        out[i] = static_cast<std::uint8_t>(a * 16U + b);
    }
    return out;
}

[[nodiscard]] bool nz(const Digest& value) noexcept {
    for (const auto byte : value) if (byte != 0U) return true;
    return false;
}

void append_text32(std::vector<std::uint8_t>& body, const std::string_view text) {
    for (std::size_t i = 0U; i < 32U; ++i) body.push_back(i < text.size() ? static_cast<std::uint8_t>(text[i]) : 0U);
}

template <std::size_t N>
void append_fixed(std::vector<std::uint8_t>& body, const std::array<std::uint8_t, N>& bytes) {
    body.insert(body.end(), bytes.begin(), bytes.end());
}

void append_u16(std::vector<std::uint8_t>& body, const std::uint16_t value) {
    body.push_back(static_cast<std::uint8_t>((value >> 8U) & 255U));
    body.push_back(static_cast<std::uint8_t>(value & 255U));
}

void append_u64(std::vector<std::uint8_t>& body, const std::uint64_t value) {
    for (int shift = 56; shift >= 0; shift -= 8) body.push_back(static_cast<std::uint8_t>((value >> static_cast<unsigned>(shift)) & 255U));
}

void append_bool(std::vector<std::uint8_t>& body, const bool value) { body.push_back(value ? 1U : 0U); }

template <std::size_t N>
[[nodiscard]] Digest seal_identity(std::vector<std::uint8_t> body) noexcept {
    constexpr std::size_t body_bytes = N - 32U;
    if (body.size() > body_bytes) return {};
    body.resize(body_bytes, 0U);
    const Digest integrity = generation_journal::sha256(std::span<const std::uint8_t>(body.data(), body.size()));
    std::array<std::uint8_t, N> complete{};
    std::copy(body.begin(), body.end(), complete.begin());
    std::copy(integrity.begin(), integrity.end(), complete.begin() + static_cast<std::ptrdiff_t>(body_bytes));
    return generation_journal::sha256(std::span<const std::uint8_t>(complete.data(), complete.size()));
}

[[nodiscard]] Digest reference_manifest_identity(const OutputSetManifest& value) noexcept {
    std::vector<std::uint8_t> body;
    body.reserve(encoded_output_manifest_bytes - 32U);
    append_text32(body, "SlopOS/OOC/output-manifest/v1");
    append_fixed(body, value.parent_relocated_receipt_digest);
    append_fixed(body, value.parent_build_claim_digest);
    append_fixed(body, value.parent_provenance_output_digest);
    append_fixed(body, value.parent_output_carrier_digest);
    append_fixed(body, value.reserved_namespace_policy_digest);
    body.push_back(value.entry_count);
    append_bool(body, value.present);
    append_bool(body, value.canonical);
    append_bool(body, value.exact_prior_set);
    append_bool(body, value.complete);
    append_bool(body, value.reserved_namespace_excluded);
    for (const auto& entry : value.entries) {
        append_fixed(body, entry.path);
        append_fixed(body, entry.content_digest);
        append_u64(body, entry.bytes);
        append_u16(body, entry.mode);
        body.push_back(entry.path_length);
        append_bool(body, entry.present);
        append_bool(body, entry.regular_file);
        append_bool(body, entry.reserved_namespace);
    }
    return seal_identity<encoded_output_manifest_bytes>(std::move(body));
}

[[nodiscard]] Digest reference_publication_identity(const ManifestPublicationReceipt& value) noexcept {
    std::vector<std::uint8_t> body;
    append_text32(body, "SlopOS/OOC/publication/v1");
    append_fixed(body, value.manifest_digest);
    append_fixed(body, value.parent_relocated_receipt_digest);
    append_fixed(body, value.parent_output_carrier_digest);
    append_fixed(body, value.publisher_digest);
    append_u64(body, value.carrier_bytes);
    append_bool(body, value.present);
    append_bool(body, value.durable);
    append_bool(body, value.no_replace_publication);
    append_bool(body, value.single_view_reopened);
    append_bool(body, value.exact_carrier_published);
    return seal_identity<encoded_publication_receipt_bytes>(std::move(body));
}

[[nodiscard]] Digest reference_reopen_identity(const OutputSetReopenReceipt& value) noexcept {
    std::vector<std::uint8_t> body;
    append_text32(body, "SlopOS/OOC/reopen/v1");
    append_fixed(body, value.publication_receipt_digest);
    append_fixed(body, value.manifest_digest);
    append_fixed(body, value.parent_output_carrier_digest);
    append_fixed(body, value.reopener_digest);
    append_fixed(body, value.reopener_implementation_digest);
    append_u64(body, value.carrier_bytes);
    append_bool(body, value.present);
    append_bool(body, value.durable);
    append_bool(body, value.separate_reopener_role);
    append_bool(body, value.exact_manifest_reopened);
    append_bool(body, value.all_entries_rehashed);
    return seal_identity<encoded_output_reopen_receipt_bytes>(std::move(body));
}

[[nodiscard]] Digest reference_claim_identity(const OutputClosureClaim& value) noexcept {
    std::vector<std::uint8_t> body;
    append_text32(body, "SlopOS/OOC/closure-claim/v1");
    append_fixed(body, value.parent_relocated_receipt_digest);
    append_fixed(body, value.parent_build_claim_digest);
    append_fixed(body, value.manifest_digest);
    append_fixed(body, value.publication_receipt_digest);
    append_fixed(body, value.reopen_receipt_digest);
    append_fixed(body, value.reserved_namespace_policy_digest);
    append_bool(body, value.present);
    append_bool(body, value.durable);
    append_bool(body, value.exact_prior_output_set_claimed);
    append_bool(body, value.child_products_outside_subject);
    append_bool(body, value.no_self_digest_transform_claimed);
    return seal_identity<encoded_output_closure_claim_bytes>(std::move(body));
}

[[nodiscard]] std::string path_string(const OutputEntry& entry) {
    if (entry.path_length > entry.path.size()) return {};
    return std::string(reinterpret_cast<const char*>(entry.path.data()), entry.path_length);
}

[[nodiscard]] bool reference_path_valid(const OutputEntry& entry) noexcept {
    if (entry.path_length == 0U || entry.path_length > entry.path.size()) return false;
    const std::string path(reinterpret_cast<const char*>(entry.path.data()), entry.path_length);
    if (path.front() == '/' || path.back() == '/' || path.find('\\') != std::string::npos
        || path.find("//") != std::string::npos) return false;
    std::size_t start = 0U;
    while (start < path.size()) {
        const std::size_t slash = path.find('/', start);
        const std::size_t end = slash == std::string::npos ? path.size() : slash;
        const std::string_view component(path.data() + static_cast<std::ptrdiff_t>(start), end - start);
        if (component == "." || component == ".." || component.empty()) return false;
        for (const char raw : component) {
            const auto c = static_cast<unsigned char>(raw);
            if (c < 0x21U || c > 0x7eU) return false;
        }
        if (slash == std::string::npos) break;
        start = slash + 1U;
    }
    for (std::size_t i = entry.path_length; i < entry.path.size(); ++i) if (entry.path[i] != 0U) return false;
    return true;
}

[[nodiscard]] bool reserved(const OutputEntry& entry) {
    using namespace slopos::e0::observed_output_closure_generated;
    const std::string path = path_string(entry);
    return path == reserved_manifest || path == reserved_publication || path == reserved_reopen
        || path == reserved_claim || path.rfind(std::string(reserved_prefix), 0U) == 0U;
}

struct Facts final {
    bool parent_ok{false};
    bool parent_exact{false};
    bool parent_binding{false};
    bool manifest_shape{false};
    bool paths{false};
    bool duplicate{false};
    bool ordered{false};
    bool entries{false};
    bool reserved_absent{false};
    bool policy{false};
    bool exact_set{false};
    bool manifest_identity{false};
    bool publication_shape{false};
    bool publication_binding{false};
    bool publication_identity{false};
    bool reopen_shape{false};
    bool reopen_binding{false};
    bool reopen_identity{false};
    bool claim_shape{false};
    bool claim_binding{false};
    bool claim_identity{false};
    bool cuts{false};
};

[[nodiscard]] bool zero_publication(const ManifestPublicationReceipt& value) noexcept { return value == ManifestPublicationReceipt{}; }
[[nodiscard]] bool zero_reopen(const OutputSetReopenReceipt& value) noexcept { return value == OutputSetReopenReceipt{}; }
[[nodiscard]] bool zero_claim(const OutputClosureClaim& value) noexcept { return value == OutputClosureClaim{}; }

[[nodiscard]] bool exact_expected_set(const OutputSetManifest& manifest) {
    using slopos::e0::observed_output_closure_generated::parent_output_entries;
    if (manifest.entry_count != parent_output_entries.size()
        || manifest.parent_output_carrier_digest != parse_hex(SLOPOS_OOC_PARENT_OUTPUT_CARRIER_SHA256_HEX)
        || manifest.reserved_namespace_policy_digest != parse_hex(SLOPOS_OOC_RESERVED_POLICY_SHA256_HEX)) return false;
    for (std::size_t i = 0U; i < parent_output_entries.size(); ++i) {
        const auto& got = manifest.entries[i];
        const auto& expected = parent_output_entries[i];
        if (path_string(got) != expected.path || got.content_digest != parse_hex(expected.sha256)
            || got.bytes != expected.bytes || got.mode != expected.mode || !got.present
            || !got.regular_file || got.reserved_namespace) return false;
    }
    return true;
}

[[nodiscard]] bool exact_cuts(const OutputClosureTrace& trace) noexcept {
    const Digest carrier = parse_hex(SLOPOS_OOC_PARENT_OUTPUT_CARRIER_SHA256_HEX);
    for (std::size_t i = 0U; i < output_cut_count; ++i) {
        OutputClosureCut expected{};
        expected.parent_output_carrier_digest = carrier;
        if (trace.manifest.present && i > 0U) expected.manifest_digest = trace.manifest.manifest_digest;
        if (trace.publication.present && i > 1U) expected.publication_receipt_digest = trace.publication.receipt_digest;
        if (trace.reopen.present && i > 2U) expected.reopen_receipt_digest = trace.reopen.receipt_digest;
        if (trace.claim.present && i > 3U) expected.closure_claim_digest = trace.claim.claim_digest;
        if (expected != trace.cuts[i]) return false;
    }
    return true;
}

[[nodiscard]] Facts inspect(const OutputClosureTrace& trace) {
    Facts f{};
    const ProvenanceReport parent = relocatable_provenance::evaluate_reference(trace.parent);
    f.parent_ok = parent.accepted;
    f.parent_exact = f.parent_ok && parent.code == ProvenanceCode::accepted_relocated_exact_subject && parent.relocation_witness;
    f.parent_binding = trace.manifest.present
        && trace.manifest.parent_relocated_receipt_digest == trace.parent.relocated_receipt.receipt_digest
        && trace.manifest.parent_build_claim_digest == trace.parent.relocated_observation.claim_digest
        && trace.manifest.parent_provenance_output_digest == trace.parent.relocated_observation.output_digest;
    f.manifest_shape = trace.manifest.present && trace.manifest.canonical && trace.manifest.exact_prior_set
        && trace.manifest.complete && trace.manifest.reserved_namespace_excluded
        && trace.manifest.entry_count == expected_parent_output_entries && nz(trace.manifest.manifest_digest)
        && nz(trace.manifest.parent_relocated_receipt_digest) && nz(trace.manifest.parent_build_claim_digest)
        && nz(trace.manifest.parent_provenance_output_digest) && nz(trace.manifest.parent_output_carrier_digest)
        && nz(trace.manifest.reserved_namespace_policy_digest);
    if (f.manifest_shape) {
        bool unused_zero = true;
        for (std::size_t i = trace.manifest.entry_count; i < trace.manifest.entries.size(); ++i) unused_zero = unused_zero && trace.manifest.entries[i] == OutputEntry{};
        f.manifest_shape = f.manifest_shape && unused_zero;
    }
    f.paths = true;
    f.ordered = true;
    f.entries = true;
    f.reserved_absent = true;
    std::string previous;
    for (std::size_t i = 0U; i < trace.manifest.entry_count && i < trace.manifest.entries.size(); ++i) {
        const auto& entry = trace.manifest.entries[i];
        const std::string current = path_string(entry);
        f.paths = f.paths && reference_path_valid(entry);
        if (i > 0U) {
            f.duplicate = f.duplicate || previous == current;
            f.ordered = f.ordered && previous < current;
        }
        previous = current;
        f.entries = f.entries && entry.present && entry.regular_file && !entry.reserved_namespace
            && nz(entry.content_digest) && entry.bytes > 0U
            && (entry.mode == output_mode_read_only || entry.mode == output_mode_read_execute);
        f.reserved_absent = f.reserved_absent && !reserved(entry);
    }
    f.policy = trace.manifest.reserved_namespace_excluded
        && trace.manifest.reserved_namespace_policy_digest == parse_hex(SLOPOS_OOC_RESERVED_POLICY_SHA256_HEX);
    f.exact_set = exact_expected_set(trace.manifest);
    f.manifest_identity = trace.manifest.manifest_digest == reference_manifest_identity(trace.manifest);
    f.publication_shape = trace.publication.present && trace.publication.durable
        && trace.publication.no_replace_publication && trace.publication.single_view_reopened
        && trace.publication.exact_carrier_published && trace.publication.carrier_bytes == SLOPOS_OOC_PARENT_OUTPUT_CARRIER_BYTES
        && nz(trace.publication.receipt_digest) && nz(trace.publication.manifest_digest)
        && nz(trace.publication.parent_relocated_receipt_digest) && nz(trace.publication.parent_output_carrier_digest)
        && nz(trace.publication.publisher_digest);
    f.publication_binding = trace.publication.manifest_digest == trace.manifest.manifest_digest
        && trace.publication.parent_relocated_receipt_digest == trace.parent.relocated_receipt.receipt_digest
        && trace.publication.parent_output_carrier_digest == parse_hex(SLOPOS_OOC_PARENT_OUTPUT_CARRIER_SHA256_HEX);
    f.publication_identity = trace.publication.receipt_digest == reference_publication_identity(trace.publication);
    f.reopen_shape = trace.reopen.present && trace.reopen.durable && trace.reopen.separate_reopener_role
        && trace.reopen.exact_manifest_reopened && trace.reopen.all_entries_rehashed
        && trace.reopen.carrier_bytes == SLOPOS_OOC_PARENT_OUTPUT_CARRIER_BYTES && nz(trace.reopen.receipt_digest)
        && nz(trace.reopen.publication_receipt_digest) && nz(trace.reopen.manifest_digest)
        && nz(trace.reopen.parent_output_carrier_digest) && nz(trace.reopen.reopener_digest)
        && nz(trace.reopen.reopener_implementation_digest);
    f.reopen_binding = trace.reopen.publication_receipt_digest == trace.publication.receipt_digest
        && trace.reopen.manifest_digest == trace.manifest.manifest_digest
        && trace.reopen.parent_output_carrier_digest == parse_hex(SLOPOS_OOC_PARENT_OUTPUT_CARRIER_SHA256_HEX)
        && trace.reopen.reopener_digest != trace.publication.publisher_digest
        && trace.reopen.reopener_implementation_digest == parse_hex(SLOPOS_OOC_REOPENER_IMPLEMENTATION_SHA256_HEX);
    f.reopen_identity = trace.reopen.receipt_digest == reference_reopen_identity(trace.reopen);
    f.claim_shape = trace.claim.present && trace.claim.durable && trace.claim.exact_prior_output_set_claimed
        && trace.claim.child_products_outside_subject && trace.claim.no_self_digest_transform_claimed
        && nz(trace.claim.claim_digest) && nz(trace.claim.parent_relocated_receipt_digest)
        && nz(trace.claim.parent_build_claim_digest) && nz(trace.claim.manifest_digest)
        && nz(trace.claim.publication_receipt_digest) && nz(trace.claim.reopen_receipt_digest)
        && nz(trace.claim.reserved_namespace_policy_digest);
    f.claim_binding = trace.claim.parent_relocated_receipt_digest == trace.parent.relocated_receipt.receipt_digest
        && trace.claim.parent_build_claim_digest == trace.parent.relocated_observation.claim_digest
        && trace.claim.manifest_digest == trace.manifest.manifest_digest
        && trace.claim.publication_receipt_digest == trace.publication.receipt_digest
        && trace.claim.reopen_receipt_digest == trace.reopen.receipt_digest
        && trace.claim.reserved_namespace_policy_digest == parse_hex(SLOPOS_OOC_RESERVED_POLICY_SHA256_HEX);
    f.claim_identity = trace.claim.claim_digest == reference_claim_identity(trace.claim);
    f.cuts = exact_cuts(trace);
    return f;
}

[[nodiscard]] ClosureReport stop(const ClosureCode code, const bool parent, const bool exact, const bool binding) noexcept {
    ClosureReport report{};
    report.code = code;
    report.parent_accepted = parent;
    report.parent_relocated_exact_subject = exact;
    report.parent_binding_valid = binding;
    return report;
}

[[nodiscard]] ClosureReport stage(const ClosureCode code, const bool manifest, const bool publication, const bool reopen, const bool claim) noexcept {
    ClosureReport report{};
    report.code = code;
    report.accepted = true;
    report.parent_accepted = true;
    report.parent_relocated_exact_subject = true;
    report.parent_binding_valid = true;
    report.manifest_valid = manifest;
    report.exact_parent_output_set = manifest;
    report.reserved_namespace_excluded = manifest;
    report.manifest_identity_valid = manifest;
    report.publication_valid = publication;
    report.publication_identity_valid = publication;
    report.reopen_valid = reopen;
    report.reopen_identity_valid = reopen;
    report.claim_valid = claim;
    report.claim_identity_valid = claim;
    report.cuts_ordered = true;
    report.closure_ready = claim;
    report.child_products_outside_subject = claim;
    return report;
}

}  // namespace

ClosureReport evaluate_reference(const OutputClosureTrace& trace) noexcept {
    const Facts f = inspect(trace);
    if (!f.parent_ok) return stop(ClosureCode::parent_rejected, false, false, false);
    if (!f.parent_exact) return stop(ClosureCode::parent_not_relocated_exact_subject, true, false, false);
    if (!trace.manifest.present) {
        if (!zero_publication(trace.publication) || !zero_reopen(trace.reopen) || !zero_claim(trace.claim)) {
            return stop(ClosureCode::publication_without_manifest, true, true, false);
        }
        if (!f.cuts) return stop(ClosureCode::output_cut_order_invalid, true, true, false);
        return stage(ClosureCode::accepted_prior_output_durable, false, false, false, false);
    }
    if (!f.parent_binding) return stop(ClosureCode::parent_binding_mismatch, true, true, false);
    if (!f.manifest_shape) return stop(ClosureCode::manifest_shape_invalid, true, true, true);
    if (!f.paths || !f.ordered) {
        return stop(!f.paths ? ClosureCode::output_path_invalid
                             : (f.duplicate ? ClosureCode::output_path_duplicate : ClosureCode::output_path_order_invalid), true, true, true);
    }
    if (!f.entries) return stop(ClosureCode::output_entry_invalid, true, true, true);
    if (!f.reserved_absent) return stop(ClosureCode::reserved_namespace_in_subject, true, true, true);
    if (!f.policy) return stop(ClosureCode::self_reference_policy_mismatch, true, true, true);
    if (!f.exact_set) return stop(ClosureCode::output_set_not_exact_parent, true, true, true);
    if (!f.manifest_identity) return stop(ClosureCode::manifest_digest_mismatch, true, true, true);
    if (!trace.publication.present) {
        if (!zero_reopen(trace.reopen) || !zero_claim(trace.claim)) return stop(ClosureCode::reopen_without_publication, true, true, true);
        if (!f.cuts) return stop(ClosureCode::output_cut_order_invalid, true, true, true);
        return stage(ClosureCode::accepted_manifest_durable, true, false, false, false);
    }
    if (!f.publication_shape) return stop(ClosureCode::publication_shape_invalid, true, true, true);
    if (!f.publication_binding) return stop(ClosureCode::publication_binding_mismatch, true, true, true);
    if (!f.publication_identity) return stop(ClosureCode::publication_digest_mismatch, true, true, true);
    if (!trace.reopen.present) {
        if (!zero_claim(trace.claim)) return stop(ClosureCode::claim_without_reopen, true, true, true);
        if (!f.cuts) return stop(ClosureCode::output_cut_order_invalid, true, true, true);
        return stage(ClosureCode::accepted_publication_durable, true, true, false, false);
    }
    if (!f.reopen_shape) return stop(ClosureCode::reopen_shape_invalid, true, true, true);
    if (!f.reopen_binding) return stop(ClosureCode::reopen_binding_mismatch, true, true, true);
    if (!f.reopen_identity) return stop(ClosureCode::reopen_digest_mismatch, true, true, true);
    if (!trace.claim.present) {
        if (!f.cuts) return stop(ClosureCode::output_cut_order_invalid, true, true, true);
        return stage(ClosureCode::accepted_reopen_durable, true, true, true, false);
    }
    if (!f.claim_shape) return stop(ClosureCode::claim_shape_invalid, true, true, true);
    if (!f.claim_binding) return stop(ClosureCode::claim_binding_mismatch, true, true, true);
    if (!f.claim_identity) return stop(ClosureCode::claim_digest_mismatch, true, true, true);
    if (!f.cuts) return stop(ClosureCode::output_cut_order_invalid, true, true, true);
    return stage(ClosureCode::accepted_closed_output_set, true, true, true, true);
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification::relocatable_provenance::observed_output_closure
