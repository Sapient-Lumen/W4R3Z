#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import sys
from pathlib import Path


def fail(detail: str) -> None:
    raise SystemExit(f"EXTERNAL_PREMISE_ADMISSION_PY=FAIL detail={detail}")


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def main() -> int:
    if len(sys.argv) != 2:
        fail("usage")
    root = Path(sys.argv[1]).resolve()
    required = {"CASES.tsv", "CUTS.tsv", "SUMMARY.json", "PHASES.tsv", "COUNTERTRACES.tsv", "INVARIANTS.txt"}
    if not root.is_dir() or {path.name for path in root.iterdir()} != required:
        fail("canonical file set")
    summary = json.loads((root / "SUMMARY.json").read_text(encoding="utf-8"))
    cases = rows(root / "CASES.tsv")
    cuts = rows(root / "CUTS.tsv")
    phases = rows(root / "PHASES.tsv")
    countertraces = rows(root / "COUNTERTRACES.tsv")
    if summary.get("schema") != "slopos.rev0920.external-premise-admission-campaign.v1" or summary.get("status") != "PASS":
        fail("summary identity")
    expected = {
        "cases": 132,
        "accepted_cases": 106,
        "rejected_cases": 26,
        "crash_cuts": 1320,
        "external_premise_dossier_ready_cases": 8,
        "partial_stage_cases": 16,
        "owner_rejected_cases": 4,
        "premise_refused_cases": 72,
        "fail_stopped_cases": 6,
        "candidate_reference_disagreements": 0,
    }
    for key, value in expected.items():
        if summary.get(key) != value:
            fail(f"summary {key}")
    if len(cases) != 132 or len(cuts) != 1320 or len(phases) != 10 or len(countertraces) != 10:
        fail("cardinality")
    names = [row["case"] for row in cases]
    if len(names) != len(set(names)):
        fail("duplicate case")
    if any(row["expected"] != row["candidate"] or row["candidate"] != row["reference"] or row["agreement"] != "true" for row in cases):
        fail("differential disagreement")
    if sum(row["accepted"] == "true" for row in cases) != 106:
        fail("accepted projection")
    if sum(row["external_premise_dossier_ready"] == "true" for row in cases) != 8:
        fail("ready projection")
    if sum(row["owner_rejected"] == "true" for row in cases) != 4:
        fail("owner reject projection")
    if sum(row["fail_stopped"] == "true" for row in cases) != 6:
        fail("fail-stop projection")
    mandatory_false = (
        "external_occurrence_proved", "owner_constitution_proved", "currentness_proved",
        "independent_custody_proved", "mechanism_operated_proved", "epoch_exit_proved",
        "authority_granted",
    )
    if any(row[field] != "false" for row in cases for field in mandatory_false):
        fail("mandatory nonclaim")
    if any(row["live_record_must_be_retained"] != "true" for row in cases if row["accepted"] == "true"):
        fail("live-retention projection")
    by_case: dict[str, list[dict[str, str]]] = {}
    for row in cuts:
        by_case.setdefault(row["case"], []).append(row)
    expected_cut_names = [
        "constitution_current", "annex_closed", "ratification_published", "ratification_reopened",
        "rehearsal_started", "corpus_complete", "appraisal_published", "appraisal_reopened",
        "owner_admission_published", "owner_admission_reopened_live_retained",
    ]
    if set(by_case) != set(names):
        fail("cut identity")
    for name, trace in by_case.items():
        if [int(row["cut_index"]) for row in trace] != list(range(10)):
            fail(f"cut index={name}")
        if [row["cut_name"] for row in trace] != expected_cut_names:
            fail(f"cut name={name}")
    required_cases = {
        "ready_external_premises_1", "profile_closed_unratified_1", "ratified_not_operated_1",
        "operated_not_appraised_1", "appraised_not_owner_admitted_1",
        "owner_rejected_live_retained_1", "refuse_constitution_self_nominated",
        "refuse_profile_self_ratifying", "refuse_separation_process_labels_only",
        "refuse_transparency_appraisal_split_view", "refuse_corpus_synthetic",
        "refuse_appraisal_self_review", "refuse_owner_admission_wrong_predecessor",
        "refuse_order_ratification_same_cut_as_annex", "fail_stop_unauthorized_deletion",
        "reject_profile_parent_authorization", "reject_owner_admission_appraisal",
    }
    if not required_cases <= set(names):
        fail(f"missing={sorted(required_cases - set(names))}")
    invariants = (root / "INVARIANTS.txt").read_text(encoding="utf-8")
    for law in (
        "self_nomination_is_ratification=false", "profile_completeness_is_ratification=false",
        "transparency_inclusion_proves_non_equivocation=false",
        "synthetic_corpus_proves_operation=false", "authority_granted=false",
    ):
        if law not in invariants:
            fail(f"invariant={law}")
    print(
        "EXTERNAL_PREMISE_ADMISSION_PY=PASS "
        f"cases={len(cases)} accepted=106 rejected=26 cuts={len(cuts)} "
        "ready=8 partial=16 refused=72 fail_stop=6 authority=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
