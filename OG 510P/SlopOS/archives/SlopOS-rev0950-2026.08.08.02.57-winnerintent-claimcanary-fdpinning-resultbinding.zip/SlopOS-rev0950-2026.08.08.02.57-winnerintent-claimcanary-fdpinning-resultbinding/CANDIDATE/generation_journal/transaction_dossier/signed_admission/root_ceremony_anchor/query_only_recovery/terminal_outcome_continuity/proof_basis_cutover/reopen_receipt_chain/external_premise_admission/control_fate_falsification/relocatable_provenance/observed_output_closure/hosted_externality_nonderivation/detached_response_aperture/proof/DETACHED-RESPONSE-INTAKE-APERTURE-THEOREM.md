# Theorem — configured trust and appraisal currentness do not self-ratify

Let `R` be one exact signed response and let `C_accept`, `C_policy`, and
`C_successor` be exact, separately supplied configurations. The retained model
constructs:

```text
VerifySignature(R, R.key) = true
Appraise(R, C_accept)      = accepted
Appraise(R, C_policy)      = required_claim_unresolved
Appraise(R, C_successor)   = owner_root_mismatch
```

while the bytes of `R` remain identical.

Therefore signature validity alone does not determine trusted-signer status,
an appraisal cannot precede the response's own issuance even when `not_before`
is earlier, and an appraisal under owner-root version `N` is not a current
authorization for consumption under version `N+1`.

The theorem is representation- and model-relative. It does not prove that the
response, trust configuration, publication, reopen, owner root, or timestamps
were supplied or operated externally. The complete retained state keeps owner
admission, authority, and Epoch-Zero exit false.
