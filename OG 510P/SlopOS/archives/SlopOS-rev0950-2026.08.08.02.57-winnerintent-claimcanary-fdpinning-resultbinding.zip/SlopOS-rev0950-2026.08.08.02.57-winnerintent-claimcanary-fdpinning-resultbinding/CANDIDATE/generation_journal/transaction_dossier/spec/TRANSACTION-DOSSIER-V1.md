# Transaction Dossier V1 — hosted epoch-zero kernel

## Status

Candidate schema only. This profile freezes bytes and rejection behavior for
laboratory comparison. It creates no owner authority and cannot advance an
epoch.

## Record layout

Every record is exactly 448 bytes, big-endian for integers:

| Offset | Bytes | Field |
|---:|---:|---|
| 0 | 8 | `SLOPTX01` |
| 8 | 2 | version = 1 |
| 10 | 1 | kind R1..R6 |
| 11 | 1 | zero |
| 12 | 4 | length = 448 |
| 16 | 4 | flags |
| 20 | 12 | zero |
| 32 | 32 | transaction id |
| 64 | 32 | predecessor record head; zero only at R1 |
| 96..383 | 9 × 32 | subject, policy, evidence, appraisal, permit, spend receipt, result, currentness, actor |
| 384 | 8 | generation from |
| 392 | 8 | generation to |
| 400 | 8 | transaction nonce |
| 408 | 1 | appraisal decision |
| 409 | 1 | terminal result |
| 410 | 1 | actor role |
| 411 | 5 | zero |
| 416 | 32 | SHA-256 integrity over domain plus bytes 0..415 |

The record head is a separate domain-separated SHA-256 over all 448 bytes. The
transaction id binds subject digest, policy digest, generation-from, and nonce.
All digest fields name exact bytes elsewhere; they are not signatures.

## Histories

A complete effect-bearing history is exactly:

1. R1 `SubjectEnvelope` by proposer.
2. R2 `EvidenceEnvelope` by acquirer.
3. R3 `AppraisalResult(PASS)` by appraiser.
4. R4 `AuthorityPermit(scoped)` by issuer.
5. R5 `EffectResult(spent, terminal)` by endpoint.
6. R6 `ReopenReceipt(reopened)` by reopener.

The strict fixture profile requires six distinct actor digests. That is a useful
separation test, not a universal theorem that digest inequality proves separate
administration.

R3 `REJECT` and `INDETERMINATE` terminate as valid three-record appraisal stops.
They are not complete dossiers, are not dispatch-eligible, and must never have
R4. This corrects the earlier prose ambiguity that appeared to require all six
records for every appraisal outcome.

## Validator verdict vocabulary

A six-record profile match is `structurally_complete=true` and
`effect_bearing=true`. Those fields describe the byte relation only. The hosted
validator never reports dispatch authority and must report
`epoch_exit_proved=false` and `authority_granted=false` for every input,
including valid histories. A valid R1–R3 appraisal stop reports both structural
completion and effect-bearing shape as false.

## Terminal generation rules

- `EFFECT`: generation-to = generation-from + 1.
- `NO_EFFECT`: generation-to = generation-from.
- `UNCERTAIN`: generation-to = 0 and query-only is set.
- `FAIL_STOP`: generation-to = generation-from.

R5 consumes the scoped permit before reporting a terminal class. R6 must repeat
R5's terminal and generation observation and add a nonzero currentness digest.
In this hosted kernel, “consumes” is a checked record relation, not protected
one-use authority.

## Nonclaims

SHA-256 detects accidental or exercised mutation but does not authenticate the
writer. A coherent adversary can rewrite a whole dossier and recompute every
integrity field. Move-only C++ values prevent some same-process reuse but do not
prevent pre-move cloning, restored snapshots, another process, or another
machine. The external one-use theorem therefore remains an epoch blocker.
