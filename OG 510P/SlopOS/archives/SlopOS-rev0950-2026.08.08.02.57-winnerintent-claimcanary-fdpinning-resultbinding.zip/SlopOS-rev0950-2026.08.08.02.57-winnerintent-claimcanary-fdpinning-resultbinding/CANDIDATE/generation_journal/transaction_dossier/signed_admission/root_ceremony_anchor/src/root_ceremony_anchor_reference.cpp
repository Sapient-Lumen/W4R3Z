#include "slopos/e0/signed_admission/root_ceremony_anchor.hpp"

#include <algorithm>
#include <array>
#include <limits>
#include <span>

namespace slopos::e0::signed_admission::root_ceremony_anchor {
namespace {

[[nodiscard]] bool zero(const Digest& value) noexcept {
    return std::all_of(value.begin(), value.end(), [](const std::uint8_t byte) {
        return byte == 0U;
    });
}

[[nodiscard]] RelationReport stop(
    const RelationCode code,
    RelationReport report) noexcept {
    report.code = code;
    report.valid = false;
    report.external_receipt_authenticity_proved = false;
    report.owner_constitution_proved = false;
    report.currentness_proved = false;
    report.independent_custody_proved = false;
    report.protected_transition_proved = false;
    report.independent_reopen_proved = false;
    report.epoch_exit_proved = false;
    report.authority_granted = false;
    return report;
}

}  // namespace

RelationReport validate_reference(
    const EncodedAnchor& encoded_anchor,
    const EncodedRootStatement& encoded_statement,
    const std::uint64_t observed_time) {
    RelationReport report{};
    RootCeremonyAnchorV1 a{};
    if (!decode_anchor(encoded_anchor, a)) {
        return stop(RelationCode::invalid_anchor, report);
    }
    report.canonical_anchor = true;
    root_succession::RootSuccessionStatementV1 s{};
    if (!root_succession::decode_root_statement(encoded_statement, s)) {
        return stop(RelationCode::invalid_statement, report);
    }
    report.canonical_statement = true;

    const std::array<Digest, 9U> required{{
        a.project_id, a.register_id, a.register_incarnation,
        a.predecessor_manifest_head, a.successor_manifest_head,
        a.rc0_starting_root_receipt_head, a.rc1_precommit_receipt_head,
        a.precommit_operation_id, a.policy_head,
    }};
    if (std::any_of(required.begin(), required.end(), zero)) {
        return stop(RelationCode::missing_identity, report);
    }
    report.external_receipts_bound = true;
    report.register_incarnation_bound = true;
    if (a.rc0_starting_root_receipt_head == a.rc1_precommit_receipt_head) {
        return stop(RelationCode::receipt_collision, report);
    }
    if (a.predecessor_version == std::numeric_limits<std::uint64_t>::max()
        || a.successor_version - a.predecessor_version != 1U
        || a.successor_version <= a.predecessor_version) {
        return stop(RelationCode::version_not_next, report);
    }
    report.exact_next_version = true;
    const Digest transition = transition_digest_for(a);
    if (!std::equal(transition.begin(), transition.end(), a.transition_digest.begin())) {
        return stop(RelationCode::transition_digest_mismatch, report);
    }
    report.transition_digest_match = true;
    const Digest request = request_id_for(a);
    if (!std::equal(request.begin(), request.end(), a.request_id.begin())) {
        return stop(RelationCode::request_id_mismatch, report);
    }
    report.deterministic_request_id = true;
    if (!(a.precommit_recorded_at < a.signing_not_before)) {
        return stop(RelationCode::precommit_chronology_invalid, report);
    }
    report.precommit_precedes_signing = true;
    if (!(a.signing_not_before < a.expires_at)
        || !(a.signing_not_before <= a.request_deadline)
        || !(a.request_deadline <= a.expires_at)) {
        return stop(RelationCode::time_window_invalid, report);
    }
    if (!(s.project_id == a.project_id)) {
        return stop(RelationCode::statement_project_mismatch, report);
    }
    if (!(s.register_id == a.register_id)) {
        return stop(RelationCode::statement_register_mismatch, report);
    }
    if (!(s.predecessor_manifest_head == a.predecessor_manifest_head)
        || !(s.successor_manifest_head == a.successor_manifest_head)) {
        return stop(RelationCode::statement_heads_mismatch, report);
    }
    if (s.predecessor_version != a.predecessor_version
        || s.successor_version != a.successor_version) {
        return stop(RelationCode::statement_versions_mismatch, report);
    }
    if (!(s.precommitted_successor_head == a.successor_manifest_head)) {
        return stop(RelationCode::statement_precommit_mismatch, report);
    }
    if (!(s.ceremony_id == anchor_head(encoded_anchor))) {
        return stop(RelationCode::statement_ceremony_mismatch, report);
    }
    if (s.not_before != a.signing_not_before || s.expires_at != a.expires_at) {
        return stop(RelationCode::statement_time_mismatch, report);
    }
    if (s.transition_nonce != request_nonce(a.request_id)) {
        return stop(RelationCode::statement_nonce_mismatch, report);
    }
    report.statement_bound = true;
    const bool in_window = observed_time >= a.signing_not_before
        && observed_time <= a.request_deadline
        && observed_time <= a.expires_at;
    if (!in_window) {
        return stop(RelationCode::observed_outside_window, report);
    }
    report.observed_in_window = true;
    report.code = RelationCode::relation_valid;
    report.valid = true;
    return report;
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor
