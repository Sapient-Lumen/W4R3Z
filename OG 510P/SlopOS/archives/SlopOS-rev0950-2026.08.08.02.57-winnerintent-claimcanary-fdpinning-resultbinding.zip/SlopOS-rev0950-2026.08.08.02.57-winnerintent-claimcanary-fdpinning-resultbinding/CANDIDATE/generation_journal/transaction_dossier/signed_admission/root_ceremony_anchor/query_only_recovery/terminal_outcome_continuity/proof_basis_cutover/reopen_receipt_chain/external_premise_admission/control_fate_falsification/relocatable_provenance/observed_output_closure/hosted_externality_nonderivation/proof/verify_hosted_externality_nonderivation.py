#!/usr/bin/env python3
from __future__ import annotations

import csv
import hashlib
import json
import struct
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve()
ROOT = next((parent for parent in HERE.parents if parent.name.startswith("SlopOS-rev")), HERE.parents[-1])
BINDINGS = ROOT / "EVIDENCE/REV0924/HOSTED-EXTERNALITY-NONDERIVATION/BINDINGS"
EXPECTED = {
    "HOSTED-OBSERVATION.bin": 320,
    "TWIN-WORLD-WITNESS.bin": 256,
    "OWNER-HANDOFF-REQUEST.bin": 320,
    "PREMISE-DEFICIT-CERTIFICATE.bin": 320,
    "CASES.tsv": None,
    "CUTS.tsv": None,
    "CLAIMS.tsv": None,
    "IDENTITIES.tsv": None,
    "LAWS.tsv": None,
    "COUNTERMODELS.tsv": None,
    "SUMMARY.tsv": None,
    "REPORT.txt": None,
}

def fail(detail: str) -> None:
    raise SystemExit(f"HOSTED_EXTERNALITY_NONDERIVATION_PY=FAIL detail={detail}")

def sha_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()

def sha(path: Path) -> str:
    return sha_bytes(path.read_bytes())

def rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))

def u16(value: bytes, offset: int) -> int:
    return struct.unpack_from(">H", value, offset)[0]

def u32(value: bytes, offset: int) -> int:
    return struct.unpack_from(">I", value, offset)[0]

def u64(value: bytes, offset: int) -> int:
    return struct.unpack_from(">Q", value, offset)[0]

def digest(value: bytes, offset: int) -> str:
    return value[offset:offset+32].hex()

def zero_tail(value: bytes, start: int) -> bool:
    return value[start:] == bytes(len(value) - start)

def main() -> int:
    if len(sys.argv) != 2:
        fail("usage")
    out = Path(sys.argv[1])
    if not out.is_dir():
        fail("output-directory")
    names = {p.name for p in out.iterdir() if p.is_file()}
    if names != set(EXPECTED):
        fail(f"canonical-set={sorted(names)}")
    for name, size in EXPECTED.items():
        if size is not None and (out / name).stat().st_size != size:
            fail(f"size={name}")

    identity_rows = rows(out / "IDENTITIES.tsv")
    identities = {row["object"]: row for row in identity_rows}
    for name in tuple(EXPECTED)[:4]:
        if name not in identities or identities[name]["sha256"] != sha(out / name):
            fail(f"identity={name}")
        if int(identities[name]["bytes"]) != (out / name).stat().st_size:
            fail(f"identity-bytes={name}")

    catalogue = sha(BINDINGS / "claim-catalogue.tsv")
    policy = sha(BINDINGS / "owner-handoff-policy.txt")
    profile = sha(BINDINGS / "response-profile.txt")
    lineage = json.loads((BINDINGS / "parent-lineage.json").read_text(encoding="utf-8"))
    parent_archive = lineage["archive_sha256"]
    parent_bytes = int(lineage["archive_bytes"])
    parent_rows = int(lineage["manifest_rows"])

    observation = (out / "HOSTED-OBSERVATION.bin").read_bytes()
    if observation[:8] != b"SLOPHO1\0" or u32(observation, 8) != 1 or u16(observation, 12) != 0x7fff or u16(observation, 14) != 0x000f:
        fail("observation-header")
    if u64(observation, 16) != parent_bytes or u64(observation, 24) != parent_rows:
        fail("observation-parent-size")
    if digest(observation, 160) != parent_archive or digest(observation, 192) != catalogue or digest(observation, 224) != policy:
        fail("observation-bindings")
    if not zero_tail(observation, 256):
        fail("observation-tail")
    observation_identity = sha_bytes(observation)

    witness = (out / "TWIN-WORLD-WITNESS.bin").read_bytes()
    if witness[:8] != b"SLOPTW1\0" or u32(witness, 8) != 1 or u16(witness, 12) != 0x7fff or u16(witness, 14) != 0x000f:
        fail("witness-header")
    if u16(witness, 16) != 0 or u16(witness, 18) != 0x7fff or u32(witness, 20) != 0:
        fail("witness-facts")
    if digest(witness, 24) != observation_identity or digest(witness, 120) != catalogue or digest(witness, 152) != policy:
        fail("witness-bindings")
    if digest(witness, 56) == digest(witness, 88) or not zero_tail(witness, 216):
        fail("witness-worlds")
    witness_identity = sha_bytes(witness)

    request = (out / "OWNER-HANDOFF-REQUEST.bin").read_bytes()
    if request[:8] != b"SLOPHR1\0" or u32(request, 8) != 1 or u16(request, 12) != 0x7fff or u16(request, 14) != 0x000f:
        fail("request-header")
    if u64(request, 16) != parent_bytes or u64(request, 24) != parent_rows:
        fail("request-parent-size")
    if digest(request, 32) != parent_archive or digest(request, 96) != observation_identity or digest(request, 128) != witness_identity:
        fail("request-lineage")
    if digest(request, 160) != catalogue or digest(request, 192) != policy or digest(request, 224) != profile:
        fail("request-bindings")
    if digest(request, 256) == "0" * 64 or not zero_tail(request, 288):
        fail("request-namespace")
    request_identity = sha_bytes(request)

    deficit = (out / "PREMISE-DEFICIT-CERTIFICATE.bin").read_bytes()
    if deficit[:8] != b"SLOPDF1\0" or u32(deficit, 8) != 1 or u16(deficit, 12) != 0x7fff or u16(deficit, 14) != 0x001f:
        fail("deficit-header")
    if digest(deficit, 16) != observation_identity or digest(deficit, 48) != witness_identity or digest(deficit, 80) != request_identity:
        fail("deficit-chain")
    if digest(deficit, 144) != catalogue or digest(deficit, 176) != policy or digest(deficit, 208) != profile:
        fail("deficit-bindings")
    if not zero_tail(deficit, 240):
        fail("deficit-tail")

    cases = rows(out / "CASES.tsv")
    cuts = rows(out / "CUTS.tsv")
    claims = rows(out / "CLAIMS.tsv")
    summary = {row["metric"]: row["value"] for row in rows(out / "SUMMARY.tsv")}
    required = {
        "cases": "112", "accepted_classifications": "21", "rejected_classifications": "91",
        "owner_handoff_ready_cases": "16", "lifecycle_cut_rows": "560", "durable_stages": "5",
        "external_claims": "15", "twin_world_countermodels": "15", "canonical_exact_object_bytes": "1216",
        "candidate_reference_disagreements": "0", "hosted_promotion_permitted": "false",
        "external_response_present": "false", "authority_granted": "false", "epoch_exit_proved": "false",
    }
    if any(summary.get(key) != value for key, value in required.items()):
        fail("summary")
    if len(cases) != 112 or len(cuts) != 560 or len(claims) != 15:
        fail("row-counts")
    if any(row["candidate"] != row["reference"] for row in cases):
        fail("case-disagreement")
    if any(row["candidate"] != row["reference"] for row in cuts):
        fail("cut-disagreement")
    if any(row["hosted_observation_equal"] != "true" or row["derived"] != "false" for row in claims):
        fail("claim-promotion")
    report = (out / "REPORT.txt").read_text(encoding="utf-8")
    if "HOSTED_EXTERNALITY_NONDERIVATION=PASS" not in report or "authority=false epoch_exit=false" not in report:
        fail("report")
    print("HOSTED_EXTERNALITY_NONDERIVATION_PY=PASS cases=112 cuts=560 claims=15 exact_objects=1216 external_response=false authority=false")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
