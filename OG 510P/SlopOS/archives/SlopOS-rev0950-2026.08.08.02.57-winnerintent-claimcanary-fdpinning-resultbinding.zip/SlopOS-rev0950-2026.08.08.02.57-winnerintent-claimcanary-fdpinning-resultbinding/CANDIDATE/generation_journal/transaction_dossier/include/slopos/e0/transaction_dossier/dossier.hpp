#pragma once

#include "slopos/e0/generation_journal/spend_record.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <span>
#include <string_view>
#include <vector>

namespace slopos::e0::transaction_dossier {

using generation_journal::Digest;

enum class Kind : std::uint8_t {
    subject_envelope = 1U,
    evidence_envelope = 2U,
    appraisal_result = 3U,
    authority_permit = 4U,
    effect_result = 5U,
    reopen_receipt = 6U,
};

enum class Decision : std::uint8_t {
    none = 0U,
    pass = 1U,
    reject = 2U,
    indeterminate = 3U,
};

enum class Terminal : std::uint8_t {
    none = 0U,
    effect = 1U,
    no_effect = 2U,
    uncertain = 3U,
    fail_stop = 4U,
};

enum class Role : std::uint8_t {
    proposer = 1U,
    acquirer = 2U,
    appraiser = 3U,
    issuer = 4U,
    endpoint = 5U,
    reopener = 6U,
};

enum Flag : std::uint32_t {
    permit_scoped = 1U << 0U,
    permit_spent = 1U << 1U,
    query_only = 1U << 2U,
    reopened = 1U << 3U,
};

struct RecordV1 final {
    Kind kind{Kind::subject_envelope};
    std::uint32_t flags{0U};
    Digest transaction_id{};
    Digest predecessor{};
    Digest subject{};
    Digest policy{};
    Digest evidence{};
    Digest appraisal{};
    Digest permit{};
    Digest spend_receipt{};
    Digest result{};
    Digest currentness{};
    Digest actor{};
    std::uint64_t generation_from{0U};
    std::uint64_t generation_to{0U};
    std::uint64_t nonce{0U};
    Decision decision{Decision::none};
    Terminal terminal{Terminal::none};
    Role role{Role::proposer};

    [[nodiscard]] friend constexpr bool operator==(
        const RecordV1&, const RecordV1&) noexcept = default;
};

inline constexpr std::size_t kRecordBytes = 448U;
using EncodedRecord = std::array<std::uint8_t, kRecordBytes>;

enum class ValidationCode : std::uint8_t {
    effect,
    no_effect,
    uncertain,
    fail_stop,
    reject_stop,
    indeterminate_stop,
    invalid_count,
    invalid_record,
    invalid_order,
    invalid_chain,
    invalid_binding,
    invalid_profile,
};

struct ValidationReport final {
    ValidationCode code{ValidationCode::invalid_record};
    std::size_t records{0U};
    bool valid{false};
    bool structurally_complete{false};
    bool effect_bearing{false};
    bool epoch_exit_proved{false};
    bool authority_granted{false};
    Terminal terminal{Terminal::none};

    [[nodiscard]] friend constexpr bool operator==(
        const ValidationReport&, const ValidationReport&) noexcept = default;
};

[[nodiscard]] bool encode_record(const RecordV1& record, EncodedRecord& output);
[[nodiscard]] bool decode_record(const EncodedRecord& input, RecordV1& output);
[[nodiscard]] Digest record_head(const EncodedRecord& record);
[[nodiscard]] Digest transaction_id_for(const Digest& subject,
                                        const Digest& policy,
                                        std::uint64_t generation_from,
                                        std::uint64_t nonce);
[[nodiscard]] Digest labeled_digest(std::string_view label);

[[nodiscard]] ValidationReport validate_candidate(
    std::span<const EncodedRecord> records);
[[nodiscard]] ValidationReport validate_reference(
    std::span<const EncodedRecord> records);

[[nodiscard]] std::string_view validation_code_name(ValidationCode value) noexcept;
[[nodiscard]] std::string_view terminal_name(Terminal value) noexcept;
[[nodiscard]] std::string_view decision_name(Decision value) noexcept;

[[nodiscard]] std::vector<EncodedRecord> make_complete_fixture(Terminal terminal,
                                                               std::string_view seed);
[[nodiscard]] std::vector<EncodedRecord> make_appraisal_stop_fixture(
    Decision decision, std::string_view seed);
[[nodiscard]] bool run_campaign(const std::filesystem::path& output_directory);

}  // namespace slopos::e0::transaction_dossier
