#include "slopos/e0/transaction_dossier/dossier.hpp"

#include <algorithm>
#include <limits>
#include <vector>

namespace slopos::e0::transaction_dossier {
namespace {

[[nodiscard]] bool zero(const Digest& digest) noexcept {
    for (const std::uint8_t byte : digest) {
        if (byte != 0U) return false;
    }
    return true;
}

[[nodiscard]] ValidationReport bad(const ValidationCode code,
                                   const std::size_t records) noexcept {
    ValidationReport report;
    report.code = code;
    report.records = records;
    return report;
}

[[nodiscard]] bool same_transaction(const RecordV1& first,
                                    const RecordV1& current) noexcept {
    return first.transaction_id == current.transaction_id
        && first.subject == current.subject
        && first.policy == current.policy
        && first.generation_from == current.generation_from
        && first.nonce == current.nonce;
}

[[nodiscard]] bool correct_terminal(const RecordV1& record) noexcept {
    switch (record.terminal) {
        case Terminal::effect:
            return record.generation_from != std::numeric_limits<std::uint64_t>::max()
                && record.generation_to == record.generation_from + 1U
                && record.flags == (permit_scoped | permit_spent);
        case Terminal::no_effect:
        case Terminal::fail_stop:
            return record.generation_to == record.generation_from
                && record.flags == (permit_scoped | permit_spent);
        case Terminal::uncertain:
            return record.generation_to == 0U
                && record.flags == (permit_scoped | permit_spent | query_only);
        case Terminal::none:
            return false;
    }
    return false;
}

}  // namespace

ValidationReport validate_reference(const std::span<const EncodedRecord> records) {
    const std::size_t count = records.size();
    if (count != 3U && count != 6U) return bad(ValidationCode::invalid_count, count);

    std::vector<RecordV1> r;
    r.reserve(count);
    for (std::size_t index = 0U; index < count; ++index) {
        RecordV1 item;
        if (!decode_record(records[index], item)) {
            return bad(ValidationCode::invalid_record, count);
        }
        if (static_cast<unsigned int>(item.kind) != index + 1U
            || static_cast<unsigned int>(item.role) != index + 1U) {
            return bad(ValidationCode::invalid_order, count);
        }
        if ((index == 0U && !zero(item.predecessor))
            || (index > 0U && item.predecessor != record_head(records[index - 1U]))) {
            return bad(ValidationCode::invalid_chain, count);
        }
        r.push_back(item);
    }

    const RecordV1& a = r[0U];
    if (zero(a.transaction_id) || zero(a.subject) || zero(a.policy) || zero(a.actor)
        || a.generation_from == 0U || a.nonce == 0U
        || a.generation_from == std::numeric_limits<std::uint64_t>::max()
        || a.generation_to != a.generation_from + 1U
        || a.transaction_id != transaction_id_for(a.subject, a.policy,
                                                   a.generation_from, a.nonce)) {
        return bad(ValidationCode::invalid_binding, count);
    }
    for (std::size_t index = 0U; index < count; ++index) {
        if (!same_transaction(a, r[index]) || zero(r[index].actor)) {
            return bad(ValidationCode::invalid_binding, count);
        }
        for (std::size_t other = 0U; other < index; ++other) {
            if (r[index].actor == r[other].actor) {
                return bad(ValidationCode::invalid_profile, count);
            }
        }
    }

    const auto empty_tail = [](const RecordV1& item, const int from) {
        const Digest* fields[] = {&item.evidence, &item.appraisal, &item.permit,
                                  &item.spend_receipt, &item.result, &item.currentness};
        for (int index = from; index < 6; ++index) {
            if (!zero(*fields[index])) return false;
        }
        return true;
    };

    if (a.flags != 0U || a.decision != Decision::none || a.terminal != Terminal::none
        || !empty_tail(a, 0)) {
        return bad(ValidationCode::invalid_profile, count);
    }
    const RecordV1& b = r[1U];
    if (b.flags != 0U || b.decision != Decision::none || b.terminal != Terminal::none
        || zero(b.evidence) || !empty_tail(b, 1)
        || b.generation_to != b.generation_from + 1U) {
        return bad(ValidationCode::invalid_profile, count);
    }
    const RecordV1& c = r[2U];
    if (c.flags != 0U || c.terminal != Terminal::none || c.evidence != b.evidence
        || zero(c.appraisal) || !empty_tail(c, 2)
        || c.generation_to != c.generation_from + 1U
        || (c.decision != Decision::pass && c.decision != Decision::reject
            && c.decision != Decision::indeterminate)) {
        return bad(ValidationCode::invalid_profile, count);
    }

    if (count == 3U) {
        ValidationReport report;
        report.records = count;
        report.valid = c.decision != Decision::pass;
        if (!report.valid) return bad(ValidationCode::invalid_count, count);
        report.code = c.decision == Decision::reject
            ? ValidationCode::reject_stop : ValidationCode::indeterminate_stop;
        return report;
    }
    if (c.decision != Decision::pass) return bad(ValidationCode::invalid_profile, count);

    const RecordV1& d = r[3U];
    const RecordV1& e = r[4U];
    const RecordV1& f = r[5U];
    if (d.flags != permit_scoped || d.decision != Decision::none
        || d.terminal != Terminal::none || d.evidence != c.evidence
        || d.appraisal != c.appraisal || zero(d.permit) || !empty_tail(d, 3)
        || d.generation_to != d.generation_from + 1U) {
        return bad(ValidationCode::invalid_profile, count);
    }
    if (e.decision != Decision::none || e.evidence != d.evidence
        || e.appraisal != d.appraisal || e.permit != d.permit
        || zero(e.spend_receipt) || zero(e.result) || !zero(e.currentness)
        || !correct_terminal(e)) {
        return bad(ValidationCode::invalid_profile, count);
    }
    if (f.flags != (e.flags | reopened) || f.decision != Decision::none
        || f.terminal != e.terminal || f.generation_to != e.generation_to
        || f.evidence != e.evidence || f.appraisal != e.appraisal
        || f.permit != e.permit || f.spend_receipt != e.spend_receipt
        || f.result != e.result || zero(f.currentness)) {
        return bad(ValidationCode::invalid_profile, count);
    }

    ValidationReport report;
    report.records = count;
    report.valid = true;
    report.structurally_complete = true;
    report.effect_bearing = true;
    report.epoch_exit_proved = false;
    report.terminal = e.terminal;
    switch (e.terminal) {
        case Terminal::effect: report.code = ValidationCode::effect; break;
        case Terminal::no_effect: report.code = ValidationCode::no_effect; break;
        case Terminal::uncertain: report.code = ValidationCode::uncertain; break;
        case Terminal::fail_stop: report.code = ValidationCode::fail_stop; break;
        case Terminal::none: return bad(ValidationCode::invalid_profile, count);
    }
    return report;
}

}  // namespace slopos::e0::transaction_dossier
