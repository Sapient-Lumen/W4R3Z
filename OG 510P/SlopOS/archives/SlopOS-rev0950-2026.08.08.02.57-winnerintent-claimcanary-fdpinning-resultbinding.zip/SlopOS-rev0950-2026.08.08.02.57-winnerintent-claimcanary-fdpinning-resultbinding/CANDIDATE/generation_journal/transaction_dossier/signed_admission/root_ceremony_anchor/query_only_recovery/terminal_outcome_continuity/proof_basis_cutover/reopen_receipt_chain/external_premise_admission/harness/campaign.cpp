#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/reopen_receipt_chain/external_premise_admission.hpp"

#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <string>
#include <string_view>
#include <system_error>
#include <utility>
#include <vector>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission {
namespace {

struct TestCase final {
    std::string name;
    AdmissionTrace trace;
    AdmissionCode expected;
};

[[nodiscard]] Digest digest(const std::uint8_t seed) noexcept {
    Digest value{};
    for (std::size_t index = 0U; index < value.size(); ++index) {
        value[index] = static_cast<std::uint8_t>(seed + static_cast<std::uint8_t>(index));
    }
    return value;
}

[[nodiscard]] TerminalState terminal(const TerminalKind kind = TerminalKind::effect) noexcept {
    return TerminalState{digest(0x11U), digest(0x31U), digest(0x51U), digest(0x71U), kind};
}

[[nodiscard]] ContinuityEvidence continuity(const TerminalState& state) noexcept {
    ContinuityEvidence value{};
    value.request_id = state.request_id;
    value.transition_digest = state.transition_digest;
    value.register_incarnation = state.register_incarnation;
    value.terminal_digest = state.terminal_digest;
    value.terminal_kind = state.terminal_kind;
    value.terminal_record_present = true;
    value.terminal_record_authenticated = true;
    value.terminal_record_durable = true;
    value.terminal_record_serialized = true;
    value.terminal_record_single_view = true;
    value.terminal_record_retained_full_horizon = true;
    value.terminal_record_fences_pending = true;
    value.terminal_record_survives_restore = true;
    value.terminal_record_survives_succession = true;
    value.terminal_record_independently_reopenable = true;
    value.terminal_witness_present = true;
    value.terminal_witness_authenticated = true;
    value.terminal_witness_binds_terminal = true;
    value.terminal_witness_durable = true;
    value.terminal_witness_independently_reopenable = true;
    value.terminal_witness_survives_restore = true;
    value.terminal_witness_survives_succession = true;
    value.successor_floor_present = true;
    value.successor_floor_authenticated = true;
    value.successor_floor_monotone = true;
    value.successor_floor_outside_restore_domain = true;
    value.successor_floor_binds_request_namespace = true;
    value.old_incarnation_rejected = true;
    value.pending_invocations_fenced = true;
    value.restore_preserves_floor = true;
    value.succession_preserves_floor = true;
    value.successor_floor_single_view = true;
    value.reclamation_requested = true;
    return value;
}

[[nodiscard]] JoinReceipt join(const CutoverTrace& trace) noexcept {
    JoinReceipt value{};
    value.cutover_id = trace.cutover_id;
    value.request_id = trace.state.request_id;
    value.transition_digest = trace.state.transition_digest;
    value.register_incarnation = trace.state.register_incarnation;
    value.terminal_digest = trace.state.terminal_digest;
    value.witness_digest = trace.witness_digest;
    value.floor_digest = trace.floor_digest;
    value.terminal_kind = trace.state.terminal_kind;
    value.present = true;
    value.authenticated = true;
    value.durable = true;
    value.single_view = true;
    value.independently_reopenable = true;
    value.survives_restore = true;
    value.survives_succession = true;
    return value;
}

[[nodiscard]] CutObservation pcut(
    const bool live, const bool witness, const bool floor, const bool joined,
    const bool authorized, const bool deleted, const bool reopened) noexcept {
    return CutObservation{live, witness, floor, joined, authorized, deleted, reopened};
}

[[nodiscard]] CutoverTrace parent_trace(const TerminalKind kind, const bool deleted) noexcept {
    CutoverTrace trace{};
    trace.state = terminal(kind);
    trace.continuity = continuity(trace.state);
    trace.cutover_id = digest(0x91U);
    trace.witness_digest = digest(0xB1U);
    trace.floor_digest = digest(0xD1U);
    trace.reclamation_requested = true;
    trace.join = join(trace);
    trace.cuts = {
        pcut(true, false, false, false, false, false, false),
        pcut(true, true, false, false, false, false, false),
        pcut(true, true, true, false, false, false, false),
        pcut(true, true, true, true, false, false, false),
        pcut(true, true, true, true, false, false, true),
        pcut(true, true, true, true, deleted, false, true),
        pcut(!deleted, true, true, true, deleted, deleted, true),
    };
    return trace;
}

[[nodiscard]] exact_predecessor_consumption::PhaseReceipt exact_receipt(
    const exact_predecessor_consumption::Phase phase,
    const std::uint8_t identity_seed,
    const exact_predecessor_consumption::ChainTrace& trace) noexcept {
    exact_predecessor_consumption::PhaseReceipt value{};
    value.phase = phase;
    value.record_digest = digest(identity_seed);
    value.cutover_id = trace.parent.cutover_id;
    value.request_id = trace.parent.state.request_id;
    value.transition_digest = trace.parent.state.transition_digest;
    value.register_incarnation = trace.parent.state.register_incarnation;
    value.terminal_digest = trace.parent.state.terminal_digest;
    value.witness_digest = trace.parent.witness_digest;
    value.floor_digest = trace.parent.floor_digest;
    value.terminal_kind = trace.parent.state.terminal_kind;
    switch (phase) {
    case exact_predecessor_consumption::Phase::witness_publication:
        value.basis_digest = trace.parent.witness_digest;
        break;
    case exact_predecessor_consumption::Phase::floor_publication:
        value.basis_digest = trace.parent.floor_digest;
        break;
    case exact_predecessor_consumption::Phase::join_publication:
        value.basis_digest = trace.parent.cutover_id;
        break;
    case exact_predecessor_consumption::Phase::cold_reopen_receipt:
        value.basis_digest = trace.parent.state.terminal_digest;
        break;
    case exact_predecessor_consumption::Phase::deletion_authorization:
        value.basis_digest = trace.parent.state.transition_digest;
        break;
    }
    value.present = true;
    value.authenticated = true;
    value.durable = true;
    value.single_view = true;
    value.independently_reopenable = true;
    value.survives_restore = true;
    value.survives_succession = true;
    value.published = true;
    return value;
}

[[nodiscard]] exact_predecessor_consumption::ChainCut exact_cut(
    const bool live,
    const std::array<bool, exact_predecessor_consumption::phase_count>& visible,
    const bool deleted = false) noexcept {
    return exact_predecessor_consumption::ChainCut{live, visible, deleted};
}

[[nodiscard]] exact_predecessor_consumption::ChainTrace exact_trace(
    const TerminalKind kind, const bool deleted) noexcept {
    using exact_predecessor_consumption::Phase;
    exact_predecessor_consumption::ChainTrace trace{};
    trace.parent = parent_trace(kind, deleted);
    trace.reclamation_requested = true;
    trace.receipts[0] = exact_receipt(Phase::witness_publication, 0x21U, trace);
    trace.receipts[1] = exact_receipt(Phase::floor_publication, 0x41U, trace);
    trace.receipts[2] = exact_receipt(Phase::join_publication, 0x61U, trace);
    trace.receipts[3] = exact_receipt(Phase::cold_reopen_receipt, 0x81U, trace);
    trace.receipts[4] = exact_receipt(Phase::deletion_authorization, 0xA1U, trace);
    trace.receipts[2].predecessor_a = trace.receipts[0].record_digest;
    trace.receipts[2].predecessor_b = trace.receipts[1].record_digest;
    trace.receipts[3].predecessor_a = trace.receipts[2].record_digest;
    trace.receipts[4].predecessor_a = trace.receipts[3].record_digest;
    trace.deletion_consumed_authorization_digest = trace.receipts[4].record_digest;
    const std::array<bool, exact_predecessor_consumption::phase_count> none{false, false, false, false, false};
    const std::array<bool, exact_predecessor_consumption::phase_count> witness{true, false, false, false, false};
    const std::array<bool, exact_predecessor_consumption::phase_count> components{true, true, false, false, false};
    const std::array<bool, exact_predecessor_consumption::phase_count> joined{true, true, true, false, false};
    const std::array<bool, exact_predecessor_consumption::phase_count> reopened{true, true, true, true, false};
    const std::array<bool, exact_predecessor_consumption::phase_count> authorized{true, true, true, true, true};
    trace.cuts = {
        exact_cut(true, none),
        exact_cut(true, witness),
        exact_cut(true, components),
        exact_cut(true, joined),
        exact_cut(true, reopened),
        exact_cut(true, authorized),
        exact_cut(true, authorized),
        exact_cut(!deleted, authorized, deleted),
    };
    return trace;
}

[[nodiscard]] SourceClosure source(const ReceiptChainTrace& trace) noexcept {
    SourceClosure value{};
    value.closure_digest = digest(0x15U);
    value.cutover_id = trace.predecessor.parent.cutover_id;
    value.join_digest = trace.join_digest;
    value.witness_digest = trace.predecessor.parent.witness_digest;
    value.floor_digest = trace.predecessor.parent.floor_digest;
    value.request_id = trace.predecessor.parent.state.request_id;
    value.transition_digest = trace.predecessor.parent.state.transition_digest;
    value.register_incarnation = trace.predecessor.parent.state.register_incarnation;
    value.terminal_digest = trace.predecessor.parent.state.terminal_digest;
    value.reopener_incarnation = digest(0x25U);
    value.verifier_id = digest(0x35U);
    value.verifier_policy_digest = digest(0x45U);
    value.terminal_kind = trace.predecessor.parent.state.terminal_kind;
    value.present = true;
    value.canonical = true;
    value.complete = true;
    value.independently_locatable = true;
    value.rollback_external = true;
    value.replacement_only = true;
    value.no_hidden_inputs = true;
    value.includes_live_terminal_record = false;
    return value;
}

[[nodiscard]] ReopenReceipt reopen(const ReceiptChainTrace& trace) noexcept {
    ReopenReceipt value{};
    value.receipt_digest = trace.predecessor.receipts[static_cast<std::size_t>(
        exact_predecessor_consumption::Phase::cold_reopen_receipt)].record_digest;
    value.closure_digest = trace.source.closure_digest;
    value.cutover_id = trace.predecessor.parent.cutover_id;
    value.join_digest = trace.join_digest;
    value.witness_digest = trace.predecessor.parent.witness_digest;
    value.floor_digest = trace.predecessor.parent.floor_digest;
    value.request_id = trace.predecessor.parent.state.request_id;
    value.transition_digest = trace.predecessor.parent.state.transition_digest;
    value.register_incarnation = trace.predecessor.parent.state.register_incarnation;
    value.terminal_digest = trace.predecessor.parent.state.terminal_digest;
    value.reopener_incarnation = trace.source.reopener_incarnation;
    value.verifier_id = trace.source.verifier_id;
    value.verifier_policy_digest = trace.source.verifier_policy_digest;
    value.terminal_kind = trace.predecessor.parent.state.terminal_kind;
    value.present = true;
    value.computed_from_closure = true;
    value.exact_result = true;
    value.authenticated = true;
    value.no_replace_published = true;
    value.durable = true;
    value.directory_entry_durable = true;
    value.single_view = true;
    value.independently_reopenable = true;
    return value;
}

[[nodiscard]] AuthorizationCapsule authorization(const ReceiptChainTrace& trace) noexcept {
    AuthorizationCapsule value{};
    value.authorization_digest = trace.predecessor.receipts[static_cast<std::size_t>(
        exact_predecessor_consumption::Phase::deletion_authorization)].record_digest;
    value.reopen_receipt_digest = trace.reopen.receipt_digest;
    value.cutover_id = trace.predecessor.parent.cutover_id;
    value.target_digest = trace.target_digest;
    value.owner_policy_digest = trace.owner_policy_digest;
    value.retention_policy_digest = trace.retention_policy_digest;
    value.present = true;
    value.authenticated = true;
    value.durable = true;
    value.no_replace_published = true;
    value.single_view = true;
    value.separately_governed = true;
    value.independently_reopenable = true;
    return value;
}

[[nodiscard]] DeletionReceipt deletion(const ReceiptChainTrace& trace) noexcept {
    DeletionReceipt value{};
    value.deletion_receipt_digest = digest(0x75U);
    value.authorization_digest = trace.authorization.authorization_digest;
    value.cutover_id = trace.predecessor.parent.cutover_id;
    value.target_digest = trace.target_digest;
    value.present = true;
    value.authenticated = true;
    value.durable = true;
    value.no_replace_published = true;
    value.single_view = true;
    value.target_absence_observed = true;
    return value;
}

[[nodiscard]] ReceiptCut rcut(
    const bool live, const bool started, const bool computed, const bool receipt,
    const bool receipt_reopened, const bool auth, const bool auth_reopened,
    const bool deleted, const bool deletion_receipt) noexcept {
    return ReceiptCut{live, true, started, computed, receipt, receipt_reopened,
        auth, auth_reopened, deleted, deletion_receipt};
}

[[nodiscard]] std::array<ReceiptCut, receipt_cut_count> complete_cuts() noexcept {
    return {
        rcut(true, false, false, false, false, false, false, false, false),
        rcut(true, true, false, false, false, false, false, false, false),
        rcut(true, true, true, false, false, false, false, false, false),
        rcut(true, true, true, true, false, false, false, false, false),
        rcut(true, true, true, true, true, false, false, false, false),
        rcut(true, true, true, true, true, true, false, false, false),
        rcut(true, true, true, true, true, true, true, false, false),
        rcut(false, true, true, true, true, true, true, true, false),
        rcut(false, true, true, true, true, true, true, true, true),
    };
}

[[nodiscard]] std::array<ReceiptCut, receipt_cut_count> ready_cuts() noexcept {
    auto cuts = complete_cuts();
    cuts[7] = rcut(true, true, true, true, true, true, true, false, false);
    cuts[8] = cuts[7];
    return cuts;
}

[[nodiscard]] std::array<ReceiptCut, receipt_cut_count> live_cuts() noexcept {
    std::array<ReceiptCut, receipt_cut_count> cuts{};
    for (auto& cut : cuts) cut = rcut(true, false, false, false, false, false, false, false, false);
    return cuts;
}

[[nodiscard]] ReceiptChainTrace base_trace(
    const bool deleted = false,
    const TerminalKind kind = TerminalKind::effect) noexcept {
    ReceiptChainTrace trace{};
    // The child owns the destructive extension.  Its embedded predecessor is
    // always the accepted still-live exact prefix, even for child-complete cases.
    trace.predecessor = exact_trace(kind, false);
    trace.join_digest = trace.predecessor.receipts[static_cast<std::size_t>(
        exact_predecessor_consumption::Phase::join_publication)].record_digest;
    trace.target_digest = digest(0x85U);
    trace.owner_policy_digest = digest(0x95U);
    trace.retention_policy_digest = digest(0xA5U);
    trace.source = source(trace);
    trace.reopen = reopen(trace);
    trace.authorization = authorization(trace);
    trace.deletion = deletion(trace);
    trace.cuts = deleted ? complete_cuts() : ready_cuts();
    trace.reclamation_requested = true;
    return trace;
}


[[nodiscard]] OwnerConstitution constitution(const AdmissionTrace& trace) noexcept {
    OwnerConstitution value{};
    value.constitution_digest = digest(0xC2U);
    value.project_id = trace.project_id;
    value.owner_root_digest = digest(0xC4U);
    value.constitution_policy_digest = digest(0xC6U);
    value.bootstrap_method_digest = digest(0xC8U);
    value.present = true;
    value.canonical = true;
    value.authenticated = true;
    value.threshold_satisfied = true;
    value.out_of_band_bootstrapped = true;
    value.current_root_selected = true;
    value.rollback_external = true;
    value.durable = true;
    value.single_view = true;
    value.independently_reopenable = true;
    return value;
}

[[nodiscard]] MechanismAnnex annex(const AdmissionTrace& trace) noexcept {
    MechanismAnnex value{};
    value.annex_digest = digest(0xCAU);
    value.project_id = trace.project_id;
    value.owner_constitution_digest = trace.constitution.constitution_digest;
    value.owner_root_digest = trace.constitution.owner_root_digest;
    value.parent_authorization_digest = trace.parent.authorization.authorization_digest;
    value.target_digest = trace.parent.target_digest;
    value.profile_id = digest(0xCCU);
    value.role_matrix_digest = digest(0xCEU);
    value.failure_corpus_spec_digest = digest(0xD0U);
    value.implementation_digest = digest(0xD2U);
    value.configuration_digest = digest(0xD4U);
    value.requirement_mask = required_profile_mask;
    value.present = true;
    value.canonical = true;
    value.complete = true;
    value.no_hidden_inputs = true;
    value.exact_mechanism_selected = true;
    value.bootstrap_method_declared = true;
    value.collision_fail_closed = true;
    value.non_equivocation_witness_required = true;
    return value;
}

[[nodiscard]] RatificationReceipt ratification(const AdmissionTrace& trace) noexcept {
    RatificationReceipt value{};
    value.ratification_digest = digest(0xD6U);
    value.annex_digest = trace.annex.annex_digest;
    value.owner_constitution_digest = trace.constitution.constitution_digest;
    value.owner_root_digest = trace.constitution.owner_root_digest;
    value.ratification_policy_digest = digest(0xD8U);
    value.present = true;
    value.authenticated = true;
    value.threshold_satisfied = true;
    value.owner_issued = true;
    value.durable = true;
    value.no_replace_published = true;
    value.single_view = true;
    value.independently_reopenable = true;
    value.current_root_observed = true;
    return value;
}

[[nodiscard]] RoleSeparation separation(const AdmissionTrace& trace) noexcept {
    RoleSeparation value{};
    value.separation_digest = digest(0xDAU);
    value.annex_digest = trace.annex.annex_digest;
    value.reopener_admin_digest = digest(0x10U);
    value.authorizer_admin_digest = digest(0x20U);
    value.appraiser_admin_digest = digest(0x30U);
    value.mechanism_admin_digest = digest(0x40U);
    value.reopener_rollback_digest = digest(0x50U);
    value.authorizer_rollback_digest = digest(0x60U);
    value.appraiser_rollback_digest = digest(0x70U);
    value.mechanism_rollback_digest = digest(0x80U);
    value.present = true;
    value.owner_ratified = true;
    value.distinct_administrative_roots = true;
    value.distinct_rollback_roots = true;
    value.distinct_credentials = true;
    value.recovery_roots_separate = true;
    value.appraiser_can_reopen_without_operator = true;
    value.collusion_model_declared = true;
    return value;
}

[[nodiscard]] OperatedCorpus corpus(const AdmissionTrace& trace) noexcept {
    OperatedCorpus value{};
    value.corpus_digest = digest(0xDCU);
    value.annex_digest = trace.annex.annex_digest;
    value.failure_corpus_spec_digest = trace.annex.failure_corpus_spec_digest;
    value.implementation_digest = trace.annex.implementation_digest;
    value.configuration_digest = trace.annex.configuration_digest;
    value.disposable_target_digest = digest(0xDEU);
    value.observed_scenario_mask = required_corpus_mask;
    value.present = true;
    value.canonical = true;
    value.complete = true;
    value.actual_not_synthetic = true;
    value.exact_binaries = true;
    value.exact_configuration = true;
    value.raw_traces_retained = true;
    value.independently_locatable = true;
    value.replayable = true;
    value.expected_outcomes_checked = true;
    value.disposable_target_separate = true;
    return value;
}

[[nodiscard]] AppraisalReceipt appraisal(const AdmissionTrace& trace) noexcept {
    AppraisalReceipt value{};
    value.appraisal_digest = digest(0xE0U);
    value.annex_digest = trace.annex.annex_digest;
    value.corpus_digest = trace.corpus.corpus_digest;
    value.separation_digest = trace.separation.separation_digest;
    value.appraiser_admin_digest = trace.separation.appraiser_admin_digest;
    value.appraisal_policy_digest = digest(0xE2U);
    value.present = true;
    value.authenticated = true;
    value.durable = true;
    value.no_replace_published = true;
    value.single_view = true;
    value.independently_reopenable = true;
    value.source_closed = true;
    value.independent_replay_performed = true;
    value.producer_not_appraiser = true;
    value.result_pass = true;
    return value;
}

[[nodiscard]] OwnerAdmission owner_admission(
    const AdmissionTrace& trace,
    const OwnerDecision decision = OwnerDecision::admit) noexcept {
    OwnerAdmission value{};
    value.admission_digest = digest(0xE4U);
    value.ratification_digest = trace.ratification.ratification_digest;
    value.appraisal_digest = trace.appraisal.appraisal_digest;
    value.parent_authorization_digest = trace.parent.authorization.authorization_digest;
    value.target_digest = trace.parent.target_digest;
    value.owner_root_digest = trace.constitution.owner_root_digest;
    value.decision = decision;
    value.present = true;
    value.authenticated = true;
    value.threshold_satisfied = true;
    value.durable = true;
    value.no_replace_published = true;
    value.single_view = true;
    value.independently_reopenable = true;
    value.current_root_observed = true;
    value.separately_governed = true;
    value.exact_predecessors_consumed = true;
    return value;
}

[[nodiscard]] AdmissionCut admission_cut(
    const std::size_t stage,
    const bool live = true,
    const bool deleted = false) noexcept {
    AdmissionCut value{};
    value.live_record_visible = live;
    value.owner_constitution_visible = true;
    value.annex_closed = stage >= 1U;
    value.ratification_visible = stage >= 2U;
    value.ratification_reopened = stage >= 3U;
    value.corpus_started = stage >= 4U;
    value.corpus_complete = stage >= 5U;
    value.appraisal_visible = stage >= 6U;
    value.appraisal_reopened = stage >= 7U;
    value.owner_admission_visible = stage >= 8U;
    value.owner_admission_reopened = stage >= 9U;
    value.record_deleted = deleted;
    return value;
}

[[nodiscard]] std::array<AdmissionCut, admission_cut_count> stopped_cuts(
    const std::size_t stage) noexcept {
    std::array<AdmissionCut, admission_cut_count> values{};
    for (std::size_t index = 0U; index < values.size(); ++index) {
        values[index] = admission_cut(std::min(index, stage));
    }
    return values;
}

[[nodiscard]] AdmissionTrace admission_trace(
    const OwnerDecision decision = OwnerDecision::admit,
    const TerminalKind kind = TerminalKind::effect) noexcept {
    AdmissionTrace trace{};
    trace.parent = base_trace(false, kind);
    trace.project_id = digest(0xC0U);
    trace.constitution = constitution(trace);
    trace.annex = annex(trace);
    trace.ratification = ratification(trace);
    trace.separation = separation(trace);
    trace.corpus = corpus(trace);
    trace.appraisal = appraisal(trace);
    trace.admission = owner_admission(trace, decision);
    trace.cuts = stopped_cuts(9U);
    trace.admission_requested = true;
    return trace;
}

void remove_ratification_and_after(AdmissionTrace& trace) noexcept {
    trace.ratification = RatificationReceipt{};
    trace.separation = RoleSeparation{};
    trace.corpus = OperatedCorpus{};
    trace.appraisal = AppraisalReceipt{};
    trace.admission = OwnerAdmission{};
    trace.cuts = stopped_cuts(1U);
}

void remove_corpus_and_after(AdmissionTrace& trace) noexcept {
    trace.corpus = OperatedCorpus{};
    trace.appraisal = AppraisalReceipt{};
    trace.admission = OwnerAdmission{};
    trace.cuts = stopped_cuts(3U);
}

void remove_appraisal_and_after(AdmissionTrace& trace) noexcept {
    trace.appraisal = AppraisalReceipt{};
    trace.admission = OwnerAdmission{};
    trace.cuts = stopped_cuts(5U);
}

void remove_admission(AdmissionTrace& trace) noexcept {
    trace.admission = OwnerAdmission{};
    trace.cuts = stopped_cuts(7U);
}

[[nodiscard]] std::vector<TestCase> cases() {
    std::vector<TestCase> values;
    const auto add = [&values](std::string name, AdmissionTrace trace, const AdmissionCode expected) {
        values.push_back(TestCase{std::move(name), std::move(trace), expected});
    };

    // Eight positive hosted dossiers.  They stop with the exact live record retained.
    for (std::uint8_t index = 0U; index < 8U; ++index) {
        auto trace = admission_trace(OwnerDecision::admit,
            (index % 2U == 0U) ? TerminalKind::effect : TerminalKind::no_effect);
        trace.project_id = digest(static_cast<std::uint8_t>(0xB0U + index));
        trace.constitution.project_id = trace.project_id;
        trace.annex.project_id = trace.project_id;
        add("ready_external_premises_" + std::to_string(index + 1U), trace,
            AdmissionCode::accepted_external_premises_ready_live_retained);
    }

    // Deliberately incomplete but non-destructive construction stages.
    for (std::uint8_t index = 0U; index < 4U; ++index) {
        auto trace = admission_trace(); remove_ratification_and_after(trace);
        trace.annex.profile_id = digest(static_cast<std::uint8_t>(0x91U + index));
        add("profile_closed_unratified_" + std::to_string(index + 1U), trace,
            AdmissionCode::accepted_profile_closed_unratified);
    }
    for (std::uint8_t index = 0U; index < 4U; ++index) {
        auto trace = admission_trace(); remove_corpus_and_after(trace);
        trace.ratification.ratification_policy_digest = digest(static_cast<std::uint8_t>(0x81U + index));
        add("ratified_not_operated_" + std::to_string(index + 1U), trace,
            AdmissionCode::accepted_ratified_not_operated);
    }
    for (std::uint8_t index = 0U; index < 4U; ++index) {
        auto trace = admission_trace(); remove_appraisal_and_after(trace);
        trace.corpus.disposable_target_digest = digest(static_cast<std::uint8_t>(0x72U + index));
        add("operated_not_appraised_" + std::to_string(index + 1U), trace,
            AdmissionCode::accepted_operated_not_appraised);
    }
    for (std::uint8_t index = 0U; index < 4U; ++index) {
        auto trace = admission_trace(); remove_admission(trace);
        trace.appraisal.appraisal_policy_digest = digest(static_cast<std::uint8_t>(0x62U + index));
        add("appraised_not_owner_admitted_" + std::to_string(index + 1U), trace,
            AdmissionCode::accepted_appraised_not_owner_admitted);
    }
    for (std::uint8_t index = 0U; index < 4U; ++index) {
        auto trace = admission_trace(OwnerDecision::reject);
        trace.cuts = stopped_cuts(9U);
        trace.admission.admission_digest = digest(static_cast<std::uint8_t>(0x52U + index));
        add("owner_rejected_live_retained_" + std::to_string(index + 1U), trace,
            AdmissionCode::accepted_owner_rejected_live_retained);
    }

    // Owner-constitution gaps: an annex cannot nominate the root that ratifies it.
    { auto t = admission_trace(); t.constitution.canonical = false; add("refuse_constitution_noncanonical", t, AdmissionCode::accepted_refused_constitution_gap); }
    { auto t = admission_trace(); t.constitution.authenticated = false; add("refuse_constitution_unauthenticated", t, AdmissionCode::accepted_refused_constitution_gap); }
    { auto t = admission_trace(); t.constitution.threshold_satisfied = false; add("refuse_constitution_threshold", t, AdmissionCode::accepted_refused_constitution_gap); }
    { auto t = admission_trace(); t.constitution.out_of_band_bootstrapped = false; add("refuse_constitution_bootstrap", t, AdmissionCode::accepted_refused_constitution_gap); }
    { auto t = admission_trace(); t.constitution.current_root_selected = false; add("refuse_constitution_stale_root", t, AdmissionCode::accepted_refused_constitution_gap); }
    { auto t = admission_trace(); t.constitution.rollback_external = false; add("refuse_constitution_inside_rollback_domain", t, AdmissionCode::accepted_refused_constitution_gap); }
    { auto t = admission_trace(); t.constitution.independently_reopenable = false; add("refuse_constitution_not_reopenable", t, AdmissionCode::accepted_refused_constitution_gap); }
    { auto t = admission_trace(); t.constitution.self_nominated = true; add("refuse_constitution_self_nominated", t, AdmissionCode::accepted_refused_constitution_gap); }

    // Profile gaps.
    { auto t = admission_trace(); t.annex.requirement_mask ^= 1U; add("refuse_profile_missing_requirement", t, AdmissionCode::accepted_refused_profile_gap); }
    { auto t = admission_trace(); t.annex.complete = false; add("refuse_profile_incomplete", t, AdmissionCode::accepted_refused_profile_gap); }
    { auto t = admission_trace(); t.annex.no_hidden_inputs = false; add("refuse_profile_hidden_inputs", t, AdmissionCode::accepted_refused_profile_gap); }
    { auto t = admission_trace(); t.annex.exact_mechanism_selected = false; add("refuse_profile_abstract_mechanism", t, AdmissionCode::accepted_refused_profile_gap); }
    { auto t = admission_trace(); t.annex.bootstrap_method_declared = false; add("refuse_profile_bootstrap_undeclared", t, AdmissionCode::accepted_refused_profile_gap); }
    { auto t = admission_trace(); t.annex.collision_fail_closed = false; add("refuse_profile_collision_open", t, AdmissionCode::accepted_refused_profile_gap); }
    { auto t = admission_trace(); t.annex.non_equivocation_witness_required = false; add("refuse_profile_no_consistency_witness", t, AdmissionCode::accepted_refused_profile_gap); }
    { auto t = admission_trace(); t.annex.self_ratifying = true; add("refuse_profile_self_ratifying", t, AdmissionCode::accepted_refused_profile_gap); }
    { auto t = admission_trace(); t.annex.profile_id = Digest{}; add("refuse_profile_identity_zero", t, AdmissionCode::accepted_refused_profile_gap); }
    { auto t = admission_trace(); t.annex.role_matrix_digest = Digest{}; add("refuse_profile_role_matrix_zero", t, AdmissionCode::accepted_refused_profile_gap); }

    // Ratification gaps.
    { auto t = admission_trace(); t.ratification.authenticated = false; add("refuse_ratification_unauthenticated", t, AdmissionCode::accepted_refused_ratification_gap); }
    { auto t = admission_trace(); t.ratification.threshold_satisfied = false; add("refuse_ratification_threshold", t, AdmissionCode::accepted_refused_ratification_gap); }
    { auto t = admission_trace(); t.ratification.owner_issued = false; add("refuse_ratification_not_owner_issued", t, AdmissionCode::accepted_refused_ratification_gap); }
    { auto t = admission_trace(); t.ratification.durable = false; add("refuse_ratification_not_durable", t, AdmissionCode::accepted_refused_ratification_gap); }
    { auto t = admission_trace(); t.ratification.no_replace_published = false; add("refuse_ratification_replaceable", t, AdmissionCode::accepted_refused_ratification_gap); }
    { auto t = admission_trace(); t.ratification.current_root_observed = false; add("refuse_ratification_stale_root", t, AdmissionCode::accepted_refused_ratification_gap); }
    { auto t = admission_trace(); t.ratification.self_issued_by_annex = true; add("refuse_ratification_self_issued", t, AdmissionCode::accepted_refused_ratification_gap); }
    { auto t = admission_trace(); t.ratification.independently_reopenable = false; add("refuse_ratification_not_reopened", t, AdmissionCode::accepted_refused_ratification_gap); }

    // Separation gaps.  Distinct labels do not prove distinct administrative fate.
    { auto t = admission_trace(); t.separation.owner_ratified = false; add("refuse_separation_not_ratified", t, AdmissionCode::accepted_refused_separation_gap); }
    { auto t = admission_trace(); t.separation.distinct_administrative_roots = false; add("refuse_separation_shared_admin", t, AdmissionCode::accepted_refused_separation_gap); }
    { auto t = admission_trace(); t.separation.distinct_rollback_roots = false; add("refuse_separation_shared_rollback", t, AdmissionCode::accepted_refused_separation_gap); }
    { auto t = admission_trace(); t.separation.distinct_credentials = false; add("refuse_separation_shared_credentials", t, AdmissionCode::accepted_refused_separation_gap); }
    { auto t = admission_trace(); t.separation.recovery_roots_separate = false; add("refuse_separation_shared_recovery", t, AdmissionCode::accepted_refused_separation_gap); }
    { auto t = admission_trace(); t.separation.appraiser_can_reopen_without_operator = false; add("refuse_separation_appraiser_depends_on_operator", t, AdmissionCode::accepted_refused_separation_gap); }
    { auto t = admission_trace(); t.separation.collusion_model_declared = false; add("refuse_separation_collusion_undeclared", t, AdmissionCode::accepted_refused_separation_gap); }
    { auto t = admission_trace(); t.separation.same_process_only = true; add("refuse_separation_process_labels_only", t, AdmissionCode::accepted_refused_separation_gap); }
    { auto t = admission_trace(); t.separation.appraiser_admin_digest = t.separation.mechanism_admin_digest; t.appraisal.appraiser_admin_digest = t.separation.appraiser_admin_digest; add("refuse_separation_duplicate_admin_digest", t, AdmissionCode::accepted_refused_separation_gap); }
    { auto t = admission_trace(); t.separation.appraiser_rollback_digest = t.separation.mechanism_rollback_digest; add("refuse_separation_duplicate_rollback_digest", t, AdmissionCode::accepted_refused_separation_gap); }

    // Transparency gaps: inclusion or publication without a single shared view is insufficient.
    { auto t = admission_trace(); t.appraisal.single_view = false; add("refuse_transparency_appraisal_split_view", t, AdmissionCode::accepted_refused_transparency_gap); }
    { auto t = admission_trace(); t.admission.single_view = false; add("refuse_transparency_admission_split_view", t, AdmissionCode::accepted_refused_transparency_gap); }

    // Operated-corpus gaps.
    { auto t = admission_trace(); t.corpus.observed_scenario_mask ^= 2U; add("refuse_corpus_missing_scenario", t, AdmissionCode::accepted_refused_corpus_gap); }
    { auto t = admission_trace(); t.corpus.canonical = false; add("refuse_corpus_noncanonical", t, AdmissionCode::accepted_refused_corpus_gap); }
    { auto t = admission_trace(); t.corpus.complete = false; add("refuse_corpus_incomplete", t, AdmissionCode::accepted_refused_corpus_gap); }
    { auto t = admission_trace(); t.corpus.actual_not_synthetic = false; add("refuse_corpus_synthetic", t, AdmissionCode::accepted_refused_corpus_gap); }
    { auto t = admission_trace(); t.corpus.exact_binaries = false; add("refuse_corpus_wrong_binary", t, AdmissionCode::accepted_refused_corpus_gap); }
    { auto t = admission_trace(); t.corpus.exact_configuration = false; add("refuse_corpus_wrong_configuration", t, AdmissionCode::accepted_refused_corpus_gap); }
    { auto t = admission_trace(); t.corpus.raw_traces_retained = false; add("refuse_corpus_no_raw_traces", t, AdmissionCode::accepted_refused_corpus_gap); }
    { auto t = admission_trace(); t.corpus.independently_locatable = false; add("refuse_corpus_not_locatable", t, AdmissionCode::accepted_refused_corpus_gap); }
    { auto t = admission_trace(); t.corpus.replayable = false; add("refuse_corpus_not_replayable", t, AdmissionCode::accepted_refused_corpus_gap); }
    { auto t = admission_trace(); t.corpus.disposable_target_separate = false; add("refuse_corpus_production_target", t, AdmissionCode::accepted_refused_corpus_gap); }

    // Independent appraisal gaps.
    { auto t = admission_trace(); t.appraisal.authenticated = false; add("refuse_appraisal_unauthenticated", t, AdmissionCode::accepted_refused_appraisal_gap); }
    { auto t = admission_trace(); t.appraisal.durable = false; add("refuse_appraisal_not_durable", t, AdmissionCode::accepted_refused_appraisal_gap); }
    { auto t = admission_trace(); t.appraisal.no_replace_published = false; add("refuse_appraisal_replaceable", t, AdmissionCode::accepted_refused_appraisal_gap); }
    { auto t = admission_trace(); t.appraisal.source_closed = false; add("refuse_appraisal_source_open", t, AdmissionCode::accepted_refused_appraisal_gap); }
    { auto t = admission_trace(); t.appraisal.independent_replay_performed = false; add("refuse_appraisal_no_replay", t, AdmissionCode::accepted_refused_appraisal_gap); }
    { auto t = admission_trace(); t.appraisal.producer_not_appraiser = false; add("refuse_appraisal_self_review", t, AdmissionCode::accepted_refused_appraisal_gap); }
    { auto t = admission_trace(); t.appraisal.result_pass = false; add("refuse_appraisal_failed", t, AdmissionCode::accepted_refused_appraisal_gap); }
    { auto t = admission_trace(); t.appraisal.independently_reopenable = false; add("refuse_appraisal_not_reopened", t, AdmissionCode::accepted_refused_appraisal_gap); }

    // Owner-admission gaps.
    { auto t = admission_trace(); t.admission_requested = false; add("refuse_owner_admission_unrequested", t, AdmissionCode::accepted_refused_owner_admission_gap); }
    { auto t = admission_trace(); t.admission.decision = OwnerDecision::none; add("refuse_owner_admission_no_decision", t, AdmissionCode::accepted_refused_owner_admission_gap); }
    { auto t = admission_trace(); t.admission.authenticated = false; add("refuse_owner_admission_unauthenticated", t, AdmissionCode::accepted_refused_owner_admission_gap); }
    { auto t = admission_trace(); t.admission.threshold_satisfied = false; add("refuse_owner_admission_threshold", t, AdmissionCode::accepted_refused_owner_admission_gap); }
    { auto t = admission_trace(); t.admission.durable = false; add("refuse_owner_admission_not_durable", t, AdmissionCode::accepted_refused_owner_admission_gap); }
    { auto t = admission_trace(); t.admission.no_replace_published = false; add("refuse_owner_admission_replaceable", t, AdmissionCode::accepted_refused_owner_admission_gap); }
    { auto t = admission_trace(); t.admission.current_root_observed = false; add("refuse_owner_admission_stale_root", t, AdmissionCode::accepted_refused_owner_admission_gap); }
    { auto t = admission_trace(); t.admission.separately_governed = false; add("refuse_owner_admission_same_governance", t, AdmissionCode::accepted_refused_owner_admission_gap); }
    { auto t = admission_trace(); t.admission.exact_predecessors_consumed = false; add("refuse_owner_admission_wrong_predecessor", t, AdmissionCode::accepted_refused_owner_admission_gap); }
    { auto t = admission_trace(); t.admission.self_issued_by_candidate = true; add("refuse_owner_admission_self_issued", t, AdmissionCode::accepted_refused_owner_admission_gap); }

    // Phase-order gaps, including same-cut collapse and a missing final consumption.
    { auto t = admission_trace(); t.cuts[1].ratification_visible = true; add("refuse_order_ratification_same_cut_as_annex", t, AdmissionCode::accepted_refused_order_gap); }
    { auto t = admission_trace(); t.cuts[2].ratification_reopened = true; add("refuse_order_reopen_same_cut_as_publish", t, AdmissionCode::accepted_refused_order_gap); }
    { auto t = admission_trace(); t.cuts[4].corpus_complete = true; add("refuse_order_complete_same_cut_as_start", t, AdmissionCode::accepted_refused_order_gap); }
    { auto t = admission_trace(); t.cuts[6].appraisal_reopened = true; add("refuse_order_appraisal_reopen_same_cut", t, AdmissionCode::accepted_refused_order_gap); }
    { auto t = admission_trace(); t.cuts[8].owner_admission_reopened = true; add("refuse_order_owner_reopen_same_cut", t, AdmissionCode::accepted_refused_order_gap); }
    { auto t = admission_trace(); t.cuts = stopped_cuts(8U); add("refuse_order_owner_admission_not_reopened", t, AdmissionCode::accepted_refused_order_gap); }

    // Fail-stop countermodels.
    { auto t = admission_trace(); t.cuts[9].live_record_visible = false; t.cuts[9].record_deleted = true; add("fail_stop_unauthorized_deletion", t, AdmissionCode::accepted_unauthorized_deletion_fail_stop); }
    { auto t = admission_trace(); t.cuts[8].live_record_visible = false; t.cuts[8].record_deleted = true; for (std::size_t i = 9U; i < admission_cut_count; ++i) t.cuts[i] = t.cuts[8]; add("fail_stop_early_deletion", t, AdmissionCode::accepted_unauthorized_deletion_fail_stop); }
    { auto t = admission_trace(); t.equivocation_observed = true; add("fail_stop_transparency_equivocation", t, AdmissionCode::accepted_equivocation_fail_stop); }
    { auto t = admission_trace(OwnerDecision::reject); t.equivocation_observed = true; add("fail_stop_rejected_but_equivocating", t, AdmissionCode::accepted_equivocation_fail_stop); }
    { auto t = admission_trace(); t.cuts[8].appraisal_reopened = false; add("fail_stop_appraisal_visibility_regression", t, AdmissionCode::accepted_regression_fail_stop); }
    { auto t = admission_trace(); t.cuts[9].annex_closed = false; add("fail_stop_annex_visibility_regression", t, AdmissionCode::accepted_regression_fail_stop); }

    // Structural and cross-layer binding rejections.
    { auto t = admission_trace(); t.parent.authorization.authorization_digest = digest(0xF1U); add("reject_parent_authorization_digest", t, AdmissionCode::parent_authorization_digest_mismatch); }
    { auto t = admission_trace(); t.parent.authorization.target_digest = digest(0xF2U); add("reject_parent_target_digest", t, AdmissionCode::parent_target_digest_mismatch); }
    { auto t = admission_trace(); t.parent.predecessor.parent.state.request_id = Digest{}; add("reject_receipt_chain", t, AdmissionCode::receipt_chain_rejected); }
    { auto t = admission_trace(); t.parent.cuts = live_cuts(); add("reject_receipt_chain_not_ready", t, AdmissionCode::receipt_chain_not_ready); }
    { auto t = admission_trace(); t.parent = base_trace(true); add("reject_receipt_chain_already_deleted", t, AdmissionCode::receipt_chain_already_deleted); }
    { auto t = admission_trace(); t.constitution.present = false; add("reject_constitution_shape", t, AdmissionCode::constitution_shape_invalid); }
    { auto t = admission_trace(); t.constitution.project_id = digest(0xF3U); add("reject_constitution_project", t, AdmissionCode::constitution_project_mismatch); }
    { auto t = admission_trace(); t.annex.present = false; add("reject_profile_shape", t, AdmissionCode::profile_shape_invalid); }
    { auto t = admission_trace(); t.annex.project_id = digest(0xF4U); add("reject_profile_project", t, AdmissionCode::profile_project_mismatch); }
    { auto t = admission_trace(); t.annex.owner_constitution_digest = digest(0xF5U); add("reject_profile_constitution", t, AdmissionCode::profile_constitution_mismatch); }
    { auto t = admission_trace(); t.annex.owner_root_digest = digest(0xF6U); add("reject_profile_owner_root", t, AdmissionCode::profile_owner_root_mismatch); }
    { auto t = admission_trace(); t.annex.parent_authorization_digest = digest(0xF7U); add("reject_profile_parent_authorization", t, AdmissionCode::profile_parent_authorization_mismatch); }
    { auto t = admission_trace(); t.annex.target_digest = digest(0xF8U); add("reject_profile_target", t, AdmissionCode::profile_target_mismatch); }
    { auto t = admission_trace(); t.ratification.present = false; add("reject_ratification_shape", t, AdmissionCode::ratification_shape_invalid); }
    { auto t = admission_trace(); t.ratification.annex_digest = digest(0xF9U); add("reject_ratification_profile", t, AdmissionCode::ratification_profile_mismatch); }
    { auto t = admission_trace(); t.separation.present = false; add("reject_separation_shape", t, AdmissionCode::separation_shape_invalid); }
    { auto t = admission_trace(); t.separation.annex_digest = digest(0xFAU); add("reject_separation_profile", t, AdmissionCode::separation_profile_mismatch); }
    { auto t = admission_trace(); t.corpus.present = false; add("reject_corpus_shape", t, AdmissionCode::corpus_shape_invalid); }
    { auto t = admission_trace(); t.corpus.implementation_digest = digest(0xFBU); add("reject_corpus_implementation", t, AdmissionCode::corpus_implementation_mismatch); }
    { auto t = admission_trace(); t.appraisal.present = false; add("reject_appraisal_shape", t, AdmissionCode::appraisal_shape_invalid); }
    { auto t = admission_trace(); t.appraisal.corpus_digest = digest(0xFCU); add("reject_appraisal_corpus", t, AdmissionCode::appraisal_corpus_mismatch); }
    { auto t = admission_trace(); t.admission.present = false; add("reject_owner_admission_shape", t, AdmissionCode::owner_admission_shape_invalid); }
    { auto t = admission_trace(); t.admission.appraisal_digest = digest(0xFDU); add("reject_owner_admission_appraisal", t, AdmissionCode::owner_admission_appraisal_mismatch); }
    { auto t = admission_trace(); t.cuts[0].owner_constitution_visible = false; add("reject_initial_cut", t, AdmissionCode::trace_initial_state_invalid); }
    { auto t = admission_trace(); t.cuts[9].record_deleted = true; add("reject_deleted_and_live", t, AdmissionCode::trace_deleted_and_live); }
    { auto t = admission_trace(); t.cuts[9].live_record_visible = false; add("reject_live_absent_without_deletion", t, AdmissionCode::trace_live_absent_without_deletion); }

    return values;
}

[[nodiscard]] bool write_text(const std::filesystem::path& path, const std::string& text) {
    std::ofstream stream(path, std::ios::binary | std::ios::trunc);
    if (!stream) return false;
    stream.write(text.data(), static_cast<std::streamsize>(text.size()));
    return static_cast<bool>(stream);
}

[[nodiscard]] std::string truth(const bool value) { return value ? "true" : "false"; }

[[nodiscard]] bool accepted_code(const AdmissionCode code) noexcept {
    return static_cast<std::uint8_t>(code)
        < static_cast<std::uint8_t>(AdmissionCode::receipt_chain_rejected);
}

}  // namespace

bool run_campaign(const std::filesystem::path& output_directory) {
    std::error_code error;
    std::filesystem::remove_all(output_directory, error);
    error.clear();
    if (!std::filesystem::create_directories(output_directory, error) || error) return false;

    const auto corpus_cases = cases();
    std::map<std::string, std::size_t> counts;
    std::size_t accepted_count = 0U;
    std::size_t disagreements = 0U;

    std::string cases_tsv =
        "case\texpected\tcandidate\treference\tagreement\taccepted\tparent_accepted\tparent_ready_live_retained"
        "\tconstitution_valid\tprofile_valid\tratification_core_valid\tratification_reopen_valid"
        "\tseparation_valid\ttransparency_valid\tcorpus_valid\tappraisal_core_valid"
        "\tappraisal_reopen_valid\towner_admission_core_valid\towner_admission_reopen_valid"
        "\tall_cuts_ordered\tself_ratification_detected\tcommon_control_detected"
        "\tsynthetic_corpus_detected\towner_rejected\texternal_premise_dossier_ready"
        "\tlive_record_must_be_retained\tunauthorized_deletion\tfail_stopped"
        "\texternal_occurrence_proved\towner_constitution_proved\tcurrentness_proved"
        "\tindependent_custody_proved\tmechanism_operated_proved\tepoch_exit_proved\tauthority_granted\n";
    std::string cuts_tsv =
        "case\tcut_index\tcut_name\tlive_record_visible\towner_constitution_visible\tannex_closed"
        "\tratification_visible\tratification_reopened\tcorpus_started\tcorpus_complete"
        "\tappraisal_visible\tappraisal_reopened\towner_admission_visible\towner_admission_reopened"
        "\trecord_deleted\n";

    for (const TestCase& item : corpus_cases) {
        const AdmissionReport candidate = evaluate_candidate(item.trace);
        const AdmissionReport reference = evaluate_reference(item.trace);
        const bool agreement = candidate == reference;
        if (!agreement) ++disagreements;
        if (!agreement || candidate.code != item.expected
            || candidate.accepted != accepted_code(item.expected)) {
            std::cerr << "CASE_MISMATCH name=" << item.name
                      << " expected=" << admission_code_name(item.expected)
                      << " candidate=" << admission_code_name(candidate.code)
                      << " reference=" << admission_code_name(reference.code)
                      << " accepted=" << truth(candidate.accepted)
                      << " expected_accepted=" << truth(accepted_code(item.expected)) << '\n';
            return false;
        }
        if (candidate.accepted) ++accepted_count;
        ++counts[std::string(admission_code_name(candidate.code))];
        cases_tsv += item.name + "\t" + std::string(admission_code_name(item.expected)) + "\t"
            + std::string(admission_code_name(candidate.code)) + "\t"
            + std::string(admission_code_name(reference.code)) + "\t" + truth(agreement)
            + "\t" + truth(candidate.accepted) + "\t" + truth(candidate.parent_accepted)
            + "\t" + truth(candidate.parent_ready_live_retained)
            + "\t" + truth(candidate.constitution_valid) + "\t" + truth(candidate.profile_valid)
            + "\t" + truth(candidate.ratification_core_valid) + "\t" + truth(candidate.ratification_reopen_valid)
            + "\t" + truth(candidate.separation_valid) + "\t" + truth(candidate.transparency_valid)
            + "\t" + truth(candidate.corpus_valid) + "\t" + truth(candidate.appraisal_core_valid)
            + "\t" + truth(candidate.appraisal_reopen_valid) + "\t" + truth(candidate.owner_admission_core_valid)
            + "\t" + truth(candidate.owner_admission_reopen_valid) + "\t" + truth(candidate.all_cuts_ordered)
            + "\t" + truth(candidate.self_ratification_detected) + "\t" + truth(candidate.common_control_detected)
            + "\t" + truth(candidate.synthetic_corpus_detected) + "\t" + truth(candidate.owner_rejected)
            + "\t" + truth(candidate.external_premise_dossier_ready)
            + "\t" + truth(candidate.live_record_must_be_retained)
            + "\t" + truth(candidate.unauthorized_deletion) + "\t" + truth(candidate.fail_stopped)
            + "\t" + truth(candidate.external_occurrence_proved) + "\t" + truth(candidate.owner_constitution_proved)
            + "\t" + truth(candidate.currentness_proved) + "\t" + truth(candidate.independent_custody_proved)
            + "\t" + truth(candidate.mechanism_operated_proved) + "\t" + truth(candidate.epoch_exit_proved)
            + "\t" + truth(candidate.authority_granted) + "\n";
        for (std::size_t index = 0U; index < item.trace.cuts.size(); ++index) {
            const AdmissionCut& cut = item.trace.cuts[index];
            cuts_tsv += item.name + "\t" + std::to_string(index) + "\t"
                + std::string(admission_cut_name(index)) + "\t" + truth(cut.live_record_visible)
                + "\t" + truth(cut.owner_constitution_visible) + "\t" + truth(cut.annex_closed)
                + "\t" + truth(cut.ratification_visible) + "\t" + truth(cut.ratification_reopened)
                + "\t" + truth(cut.corpus_started) + "\t" + truth(cut.corpus_complete)
                + "\t" + truth(cut.appraisal_visible) + "\t" + truth(cut.appraisal_reopened)
                + "\t" + truth(cut.owner_admission_visible) + "\t" + truth(cut.owner_admission_reopened)
                + "\t" + truth(cut.record_deleted) + "\n";
        }
    }

    const auto count = [&counts](const std::string_view name) -> std::size_t {
        const auto found = counts.find(std::string(name));
        return found == counts.end() ? 0U : found->second;
    };
    const std::size_t refused = count("accepted_refused_constitution_gap")
        + count("accepted_refused_profile_gap") + count("accepted_refused_ratification_gap")
        + count("accepted_refused_separation_gap") + count("accepted_refused_transparency_gap")
        + count("accepted_refused_corpus_gap") + count("accepted_refused_appraisal_gap")
        + count("accepted_refused_owner_admission_gap") + count("accepted_refused_order_gap");
    const std::size_t fail_stopped = count("accepted_unauthorized_deletion_fail_stop")
        + count("accepted_equivocation_fail_stop") + count("accepted_regression_fail_stop");
    const std::size_t structural_rejections = corpus_cases.size() - accepted_count;

    const std::string summary = "{\n"
        "  \"accepted_cases\": " + std::to_string(accepted_count) + ",\n"
        "  \"authority_granted\": false,\n"
        "  \"candidate_reference_disagreements\": " + std::to_string(disagreements) + ",\n"
        "  \"cases\": " + std::to_string(corpus_cases.size()) + ",\n"
        "  \"crash_cuts\": " + std::to_string(corpus_cases.size() * admission_cut_count) + ",\n"
        "  \"epoch_exit_proved\": false,\n"
        "  \"external_occurrence_proved\": false,\n"
        "  \"external_premise_dossier_ready_cases\": "
            + std::to_string(count("accepted_external_premises_ready_live_retained")) + ",\n"
        "  \"fail_stopped_cases\": " + std::to_string(fail_stopped) + ",\n"
        "  \"fourth_semantic_island\": false,\n"
        "  \"independent_custody_proved\": false,\n"
        "  \"mechanism_operated_proved\": false,\n"
        "  \"owner_rejected_cases\": " + std::to_string(count("accepted_owner_rejected_live_retained")) + ",\n"
        "  \"partial_stage_cases\": "
            + std::to_string(count("accepted_profile_closed_unratified")
                + count("accepted_ratified_not_operated") + count("accepted_operated_not_appraised")
                + count("accepted_appraised_not_owner_admitted")) + ",\n"
        "  \"premise_refused_cases\": " + std::to_string(refused) + ",\n"
        "  \"rejected_cases\": " + std::to_string(structural_rejections) + ",\n"
        "  \"schema\": \"slopos.rev0920.external-premise-admission-campaign.v1\",\n"
        "  \"status\": \"PASS\",\n"
        "  \"unauthorized_deletion_safe_cases\": 0\n"
        "}\n";

    const std::string phases =
        "phase\tdurable_predecessor\tdestructive\thosted_claim\n"
        "P0_constitution_current\treopen-receipt chain ready while live record remains\tfalse\texternal owner root is an input, never a child output\n"
        "P1_annex_closed\tcurrent constitution\tfalse\tcomplete mechanism profile is not ratification\n"
        "P2_ratification_publish\tclosed annex\tfalse\towner publication is not independent reopen\n"
        "P3_ratification_reopen\tratification publication\tfalse\texact current-root receipt consumed\n"
        "P4_rehearsal_start\tratification reopen and separation matrix\tfalse\tstart is not operation\n"
        "P5_corpus_complete\trehearsal start\tfalse\texact binary/configuration traces retained\n"
        "P6_appraisal_publish\tcomplete corpus\tfalse\treplay result is not owner admission\n"
        "P7_appraisal_reopen\tappraisal publication\tfalse\tindependent appraisal consumed\n"
        "P8_owner_admission_publish\tratification plus appraisal\tfalse\texact predecessors named\n"
        "P9_owner_admission_reopen\towner admission publication\tfalse\thosted dossier ready; live record retained\n";
    const std::string countertraces =
        "case\tlaw\tjudgment\n"
        "refuse_constitution_self_nominated\ta candidate cannot nominate the root that ratifies it\tREFUSE\n"
        "refuse_profile_self_ratifying\tprofile completeness is not owner ratification\tREFUSE\n"
        "refuse_separation_process_labels_only\tdistinct labels are not distinct administrative fate\tREFUSE\n"
        "refuse_transparency_appraisal_split_view\tinclusion is not non-equivocation\tREFUSE\n"
        "refuse_corpus_synthetic\tsynthetic examples are not operated failure evidence\tREFUSE\n"
        "refuse_appraisal_self_review\tproducer review is not independent appraisal\tREFUSE\n"
        "refuse_owner_admission_wrong_predecessor\towner admission consumes exact ratification, appraisal, and parent authorization\tREFUSE\n"
        "refuse_order_ratification_same_cut_as_annex\tsame-cut truth is not predecessor consumption\tREFUSE\n"
        "fail_stop_unauthorized_deletion\tthis child never authorizes deletion\tFAIL_STOP\n"
        "reject_profile_parent_authorization\tcross-layer predecessor substitution is structural corruption\tREJECT\n";
    const std::string invariants =
        "EXTERNAL_PREMISE_ADMISSION_V1\n"
        "strict_refinement_of_ready_live_reopen_receipt_chain=true\n"
        "owner_constitution_is_external_input=true\n"
        "self_nomination_is_ratification=false\n"
        "profile_completeness_is_ratification=false\n"
        "ratification_is_operation=false\n"
        "operation_is_independent_appraisal=false\n"
        "appraisal_is_owner_admission=false\n"
        "role_labels_prove_independent_administration=false\n"
        "transparency_inclusion_proves_non_equivocation=false\n"
        "synthetic_corpus_proves_operation=false\n"
        "owner_admission_consumes_exact_predecessors=true\n"
        "strict_predecessor_order=true\n"
        "same_cut_phase_collapse=false\n"
        "live_terminal_record_retained=true\n"
        "external_occurrence_proved=false\n"
        "owner_constitution_proved=false\n"
        "currentness_proved=false\n"
        "independent_custody_proved=false\n"
        "mechanism_operated_proved=false\n"
        "epoch_exit_proved=false\n"
        "authority_granted=false\n";

    return disagreements == 0U
        && write_text(output_directory / "CASES.tsv", cases_tsv)
        && write_text(output_directory / "CUTS.tsv", cuts_tsv)
        && write_text(output_directory / "SUMMARY.json", summary)
        && write_text(output_directory / "PHASES.tsv", phases)
        && write_text(output_directory / "COUNTERTRACES.tsv", countertraces)
        && write_text(output_directory / "INVARIANTS.txt", invariants);
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission
