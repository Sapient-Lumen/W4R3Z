#!/usr/bin/env python3
from __future__ import annotations

import csv
import hashlib
import json
import sys
from pathlib import Path


def fail(detail: str) -> None:
    raise SystemExit(f"CONTROL_FATE_FALSIFICATION_PY=FAIL detail={detail}")


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def main() -> int:
    if len(sys.argv) != 2:
        fail("usage")
    root = Path(sys.argv[1]).resolve()
    required = {
        "CASES.tsv", "INFLUENCE.tsv", "MONOTONICITY.tsv", "GRAPH-CUTS.tsv",
        "CANONICAL-BINDINGS.tsv", "LAWS.tsv", "COUNTERMODELS.tsv", "SUMMARY.json",
    }
    if not root.is_dir() or {path.name for path in root.iterdir()} != required:
        fail("canonical file set")
    summary = json.loads((root / "SUMMARY.json").read_text(encoding="utf-8"))
    cases = rows(root / "CASES.tsv")
    influence = rows(root / "INFLUENCE.tsv")
    monotonicity = rows(root / "MONOTONICITY.tsv")
    cuts = rows(root / "GRAPH-CUTS.tsv")
    bindings = rows(root / "CANONICAL-BINDINGS.tsv")
    laws = rows(root / "LAWS.tsv")
    countermodels = rows(root / "COUNTERMODELS.tsv")
    expected = {
        "schema": "slopos.rev0921.control-fate-falsification-campaign.v2",
        "status": "PASS",
        "cases": 97,
        "accepted_cases": 65,
        "rejected_cases": 32,
        "graph_cuts": 388,
        "no_common_fate_found_cases": 10,
        "common_fate_detected_cases": 42,
        "common_administrative_fate_cases": 18,
        "common_rollback_fate_cases": 12,
        "common_view_fate_cases": 4,
        "multiple_fate_cases": 8,
        "premise_refused_cases": 13,
        "monotonicity_rows": 13,
        "canonical_binding_vectors": 97,
        "canonical_binding_rejected_cases": 12,
        "candidate_reference_disagreements": 0,
        "inventory_completeness_proved": False,
        "transitive_independence_proved": False,
        "epoch_exit_proved": False,
        "authority_granted": False,
    }
    for key, value in expected.items():
        if summary.get(key) != value:
            fail(f"summary {key}={summary.get(key)!r}")
    if (len(cases), len(influence), len(monotonicity), len(cuts), len(bindings), len(laws), len(countermodels)) != (97, 97, 13, 388, 97, 16, 12):
        fail("cardinality")
    names = [row["case"] for row in cases]
    if len(names) != len(set(names)):
        fail("duplicate case")
    if any(row["expected"] != row["candidate"] or row["candidate"] != row["reference"] or row["agreement"] != "true" for row in cases):
        fail("candidate/reference differential")
    if sum(row["accepted"] == "true" for row in cases) != 65:
        fail("accepted projection")
    if sum(row["any_common_fate"] == "true" for row in cases) != 42:
        fail("common-fate projection")
    if sum(row["no_common_fate_found"] == "true" for row in cases) != 10:
        fail("negative-search projection")
    mandatory_false = (
        "inventory_completeness_proved", "transitive_independence_proved",
        "epoch_exit_proved", "authority_granted",
    )
    if any(row[field] != "false" for row in cases for field in mandatory_false):
        fail("mandatory nonclaim")
    if any(row["monotone_falsifier"] != "true" for row in cases):
        fail("monotone declaration")
    if any(row["live_record_retained"] != "true" for row in cases if row["accepted"] == "true"):
        fail("live record retention")
    if {row["case"] for row in influence} != set(names):
        fail("influence identity")
    if any(row["status"] != "PASS" or row["adding_edges_repaired_refutation"] != "false"
           or row["base_no_common"] != "true" or row["refuted_detected"] != "true"
           or row["extended_detected"] != "true" for row in monotonicity):
        fail("monotonicity witness")
    if {row["case"] for row in bindings} != set(names):
        fail("binding vector identity")
    by_binding = {row["case"]: row for row in bindings}
    for row in bindings:
        for prefix in ("graph", "publication", "challenge"):
            try:
                preimage = bytes.fromhex(row[f"{prefix}_preimage_hex"])
            except ValueError:
                fail(f"binding hex={row['case']}:{prefix}")
            if len(preimage) != int(row[f"{prefix}_preimage_bytes"]):
                fail(f"binding length={row['case']}:{prefix}")
            derived = hashlib.sha256(preimage).hexdigest()
            if derived != row[f"{prefix}_derived_sha256"]:
                fail(f"binding digest={row['case']}:{prefix}")
            bound = row[f"{prefix}_recorded_sha256"] == derived
            if row[f"{prefix}_bound"] != str(bound).lower():
                fail(f"binding projection={row['case']}:{prefix}")
    final_codes = {
        "accepted_no_common_fate_found_in_supplied_closure",
        "accepted_common_administrative_fate_detected",
        "accepted_common_rollback_fate_detected",
        "accepted_common_view_fate_detected",
        "accepted_multiple_common_fates_detected",
    }
    for row in cases:
        vector = by_binding[row["case"]]
        if row["candidate"] in final_codes:
            if any(vector[f"{prefix}_bound"] != "true" for prefix in ("graph", "publication", "challenge")):
                fail(f"final binding={row['case']}")
            if any(row[field] != "true" for field in (
                "scope_policy_bound", "canonical_order_valid", "canonical_tail_clear",
                "graph_digest_bound", "publication_receipt_bound", "challenge_receipt_bound")):
                fail(f"final report binding={row['case']}")
    expected_unbound = {
        "reject_graph_digest_content_mutation": "graph",
        "reject_graph_digest_claim_mutation": "graph",
        "reject_publication_receipt_subject_mismatch": "publication",
        "reject_publication_receipt_stale_after_flag_change": "publication",
        "reject_challenge_receipt_subject_mismatch": "challenge",
        "reject_challenge_receipt_stale_after_publication_rebind": "challenge",
    }
    for case, prefix in expected_unbound.items():
        if by_binding[case][f"{prefix}_bound"] != "false":
            fail(f"counterbinding={case}:{prefix}")

    by_case: dict[str, list[dict[str, str]]] = {}
    for row in cuts:
        by_case.setdefault(row["case"], []).append(row)
    if set(by_case) != set(names):
        fail("cut identity")
    expected_cut_names = ["capsule_assembled", "capsule_published", "capsule_reopened", "challenge_reopened"]
    for name, trace in by_case.items():
        if [int(row["cut_index"]) for row in trace] != list(range(4)):
            fail(f"cut index={name}")
        if [row["cut_name"] for row in trace] != expected_cut_names:
            fail(f"cut names={name}")
    required_names = {
        "clean_minimal_supplied_closure", "clean_cycle_confined_to_one_role",
        "admin_transitive_required_pair_0", "rollback_transitive_required_pair_5",
        "view_common_fate_1", "multiple_all_three_witness_owner",
        "refuse_inventory_complete_claim_false", "refuse_self_generated_capsule",
        "reject_parent_leaf_mismatch", "reject_graph_cut_phase_collapse",
        "reject_inventory_scope_digest_missing", "reject_omitted_edge_policy_digest_missing",
        "reject_canonical_binding_order", "reject_canonical_tail_hidden_node",
        "reject_graph_digest_content_mutation", "reject_graph_digest_claim_mutation",
        "reject_publication_receipt_subject_mismatch", "reject_publication_receipt_stale_after_flag_change",
        "reject_challenge_receipt_subject_mismatch", "reject_challenge_receipt_stale_after_publication_rebind",
    }
    if not required_names <= set(names):
        fail(f"missing cases={sorted(required_names - set(names))}")
    law_ids = {row["law"] for row in laws}
    if law_ids != {f"CFFL{index:02d}" for index in range(1, 17)}:
        fail("law identity")
    if {row["countermodel"] for row in countermodels} != {f"CFM{index:02d}" for index in range(1, 13)}:
        fail("countermodel identity")
    print(
        "CONTROL_FATE_FALSIFICATION_PY=PASS "
        "cases=97 accepted=65 rejected=32 graph_cuts=388 no_common=10 "
        "common=42 refused=13 monotonicity=13 authority=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
