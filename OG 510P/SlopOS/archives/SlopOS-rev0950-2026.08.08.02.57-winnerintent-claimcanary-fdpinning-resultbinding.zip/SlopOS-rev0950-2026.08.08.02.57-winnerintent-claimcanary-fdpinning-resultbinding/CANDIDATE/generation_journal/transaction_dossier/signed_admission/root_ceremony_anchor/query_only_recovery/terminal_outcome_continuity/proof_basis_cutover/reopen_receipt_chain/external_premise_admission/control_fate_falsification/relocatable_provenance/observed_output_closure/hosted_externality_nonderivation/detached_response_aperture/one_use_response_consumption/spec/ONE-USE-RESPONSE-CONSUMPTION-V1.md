# One-Use Response Consumption Interface V1

## Parent and scope

The child is nested below Detached Response Intake Aperture V1 and binds the
exact rev0925 output set, composition receipt, response, accepting configuration,
appraisal witness, consumption deficit, transport digest, byte count, and
manifest row count. It does not reconstruct or impersonate an owner response.

## Conditional currentness carrier

The model uses the exact accepted version-41 laboratory appraisal and a bounded
consumption window. That carrier is inspectable but hosted: it does not prove
externally provisioned trust, trusted time, current owner constitution, or
operation. Currentness gates a first effect. It does not erase a terminal fact
already retained by the coherent journal.

## Exact query observation

A lost invocation first enters a durable query-only stage. The query object binds
the exact invocation, request, operation, predecessor head, observed head,
generation, namespace, query policy, fixed observer role, revision, and time. Its
`exact_absence` finding is model-only. It proves neither external linearizability
nor terminal `NO_EFFECT`, and the later commit binds the exact observation.

## One coherent journal law

The first matching request may append one durable `APPLIED` record. An exact
retry returns the exact canonical terminal receipt without a second append only
when the retained spent-state witness agrees on response, request, commit digest,
successor head, successor generation, commit revision, and terminal receipt.
A mismatch fails stop. An unspent row containing residual spent fields also fails
stop. A different request for the same response is `RESPONSE_SPENT`; a predecessor
or generation mismatch before first effect is `PREDECESSOR_CONFLICT`.

Terminal classification precedes currentness. Thus an exact retry after appraisal
expiry still reopens the prior receipt, and a different request still observes
`RESPONSE_SPENT`; only a new effect is rejected as `STALE_CURRENTNESS`.

This is not a global one-use theorem. Two pre-spend clones or restored histories
can each apply locally. A future operated provider must place the rejection fact
outside every admitted rollback and clone domain.

## Nonclaims

The campaign proves no provider operation, linearizable external read, trusted
time, external currentness, nonrestorable spend floor, administrative
independence, owner admission, authority, or Epoch-Zero exit. It adds no service,
network runtime, database, provider SDK, signer, or fourth semantic island.
