# Query-only recovery latch

**Plane:** LAB. **Epoch:** Zero. **Authority:** false.

This nested C++20 relation closes one dangerous ambiguity in the external
root-currentness design. After an exact compare/apply invocation may have
reached its serialization point, the caller enters a monotone query-only phase.
A later linearizable read of “absent” is an observation of one instant, not a
terminal proof that the pending invocation can never commit.

The only modeled terminal `NO_EFFECT` path is an exact, authenticated,
linearizable, non-equivocal, durable **retirement record** for the same request,
transition, and register incarnation, created at the mutation serialization
point, retained across the reopen horizon, and respected by the original
compare/apply path as a late-commit fence. Without every premise, the result
remains `UNCERTAIN` or fails stop.

The mechanism is a proof relation and harness, not a provider adapter, network
client, durable store, retirement service, signer, repair path, or authority
API. It creates no external occurrence and keeps all authority-bearing
projections false.

## Build and run

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build
./build/slopos_query_only_recovery output
python3 -B proof/verify_query_only_recovery.py output
```

`SLOPOS_ENABLE_SANITIZERS=ON` enables AddressSanitizer and
UndefinedBehaviorSanitizer. Retained evidence is produced by GCC, Clang, and a
Clang sanitizer lane and cold-reopened by the independent Python evaluator.
