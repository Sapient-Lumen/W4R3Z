# Exact Predecessor Consumption V1

Status: hosted model, Epoch Zero, non-authoritative.

## Subject

Every phase receipt binds the same tuple:

`(cutover_id, request_id, transition_digest, register_incarnation, terminal_kind, terminal_digest, witness_digest, floor_digest)`.

A receipt with a different subject is not a weak match. It is rejected as a different history.

## Receipt chain

Let `W`, `F`, `J`, `R`, and `A` denote the durable receipt identities for witness publication, floor publication, joined-basis publication, cold reopen, and deletion authorization.

- `W` and `F` are roots and carry no predecessor.
- `J.predecessors = (digest(W), digest(F))`.
- `R.predecessor = digest(J)`.
- `A.predecessor = digest(R)`.
- the deletion effect consumes `digest(A)`.

Every present receipt is authenticated, durable, single-view, independently reopenable, published, and preserved across the modeled restore and succession horizons. Receipt identities are nonzero and unique. The chain is acyclic by construction because each edge points to a strict earlier publication cut.

## Crash-cut law

A Boolean that became true at an earlier cut is not evidence that a later phase consumed the exact record intended by the theorem. For each consumer, the predecessor receipt must have been durably published at a strictly earlier cut and the consumer must bind that exact digest.

The live terminal record covers every cut before deletion. A deletion cut is covered only when:

1. Proof Basis Cutover V1 already reports the parent trace reclamation-safe;
2. all five exact receipts are visible and publication-valid;
3. all exact predecessor edges hold;
4. authorization was first published at a strict earlier cut; and
5. the deletion effect names that exact authorization digest.

Final-state conjunction does not repair an earlier gap.

## Explicit non-claims

The relation proves no external occurrence, currentness, independent custody, provider authenticity, stable-media semantics, epoch exit, or authority. It contains no storage adapter, signer, deletion worker, garbage collector, lease manager, retry worker, or network client.
