
# Terminal continuity is a two-axis theorem

Let a completed request have exact terminal outcome `O`. Define:

- `E`: every admitted future history excludes execution or re-execution of the
  exact old or pending request; and
- `H`: every admitted future independent reopen can reconstruct exact `O`.

The terminal outcome is continuous exactly when `E ∧ H`.

## `E` does not imply `H`

Start with a terminal record for `O`. Install an externally monotone successor
floor that rejects the old request namespace and fences pending invocations.
Delete the terminal record and every exact outcome witness. Future execution is
excluded, so `E` holds. A reopener can observe only that the old namespace is
closed; both `O = EFFECT` and `O = NO_EFFECT` are compatible with that view.
Therefore `H` does not follow.

## `H` does not imply `E`

Export an exact authenticated witness for `O`. Restore a pre-terminal snapshot
whose request namespace remains live and whose pending invocation is not
fenced. The witness still reconstructs `O`, so `H` holds. The restored system
may execute the old request, so `E` does not hold. Therefore history retention
does not imply one-use terminality.

## Conjunction and reclamation

A live exact terminal record can establish both axes while it survives every
admitted restore and succession. Reclaiming that record changes the proof
basis. Before deletion, SlopOS must have both:

1. an exact durable independently reopenable terminal witness; and
2. an authenticated nonrollback successor floor that rejects old submissions,
   fences already-pending invocations, and survives restore and succession.

No TTL, acknowledgement, lease label, generation name, or successful local
reopen supplies the missing conjunct. A hosted relation can prove this logical
shape but cannot instantiate either external premise.
