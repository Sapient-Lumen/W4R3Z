# Hosted Externality Nonderivation theorem

For every claim bit in the exact catalogue, the retained campaign contains a pair of worlds with identical 320-byte hosted observation and opposite value for that external predicate. Because the candidate and independent reference consume only the trace and exact bindings, no accepted result promotes those predicates.

The strongest accepted result is `ACCEPTED_PREMISE_DEFICIT_DURABLE`: the parent is closed, the indistinguishability witness is exact, an owner-handoff request is durable, and all requested premises remain unresolved because no external response is present.

This is a boundary theorem, not an occurrence theorem. It proves that more hosted elaboration cannot substitute for the missing external channel.

## Catalogue cardinality correction

Authority and Epoch-Zero exit are separate predicates. An earlier donor compressed them into one bit while reporting two conclusions. V1 as retained here uses fifteen independent bits, preventing a conjunction-shaped catalogue entry from silently standing in for two claims.
