#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/reopen_receipt_chain/external_premise_admission/control_fate_falsification/relocatable_provenance.hpp"

#include "slopos/e0/generation_journal/spend_record.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <span>
#include <sstream>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification::relocatable_provenance {
namespace {

#ifndef SLOPOS_RPC_SOURCE_MANIFEST_SHA256_HEX
#error "focused build must bind the exact source manifest"
#endif
#ifndef SLOPOS_RPC_BUILD_PLAN_SHA256_HEX
#error "focused build must bind the exact build plan"
#endif
#ifndef SLOPOS_RPC_OUTPUT_CONTRACT_SHA256_HEX
#error "focused build must bind the exact output contract"
#endif
#ifndef SLOPOS_RPC_PARENT_BINDING_SHA256_HEX
#error "focused build must bind the exact parent object"
#endif
#ifndef SLOPOS_RPC_LOGICAL_ROOT_SHA256_HEX
#error "focused build must bind the exact logical-root carrier"
#endif
#ifndef SLOPOS_RPC_CLAIM_POLICY_SHA256_HEX
#error "focused build must bind the exact claim policy"
#endif
#ifndef SLOPOS_RPC_FIRST_LOCATOR_SHA256_HEX
#error "focused build must carry the first locator observation"
#endif
#ifndef SLOPOS_RPC_RELOCATED_LOCATOR_SHA256_HEX
#error "focused build must carry the relocated locator observation"
#endif

struct Case final {
    std::string name;
    RelocationTrace trace;
    ProvenanceCode expected;
};

[[nodiscard]] Digest digest(const std::string_view label) {
    return generation_journal::sha256(std::span<const std::uint8_t>(
        reinterpret_cast<const std::uint8_t*>(label.data()), label.size()));
}

[[nodiscard]] constexpr std::uint8_t hex_nibble(const char value) noexcept {
    if (value >= '0' && value <= '9') return static_cast<std::uint8_t>(value - '0');
    if (value >= 'a' && value <= 'f') return static_cast<std::uint8_t>(value - 'a' + 10);
    return 0xffU;
}

[[nodiscard]] Digest exact_digest(const std::string_view value) noexcept {
    Digest output{};
    if (value.size() != 64U) return output;
    for (std::size_t index = 0U; index < output.size(); ++index) {
        const std::uint8_t high = hex_nibble(value[index * 2U]);
        const std::uint8_t low = hex_nibble(value[index * 2U + 1U]);
        if (high > 15U || low > 15U) return {};
        output[index] = static_cast<std::uint8_t>((high << 4U) | low);
    }
    return output;
}

[[nodiscard]] std::string hex(const Digest& value) {
    std::ostringstream out;
    out << std::hex << std::setfill('0');
    for (const auto byte : value) out << std::setw(2) << static_cast<unsigned>(byte);
    return out.str();
}

[[nodiscard]] SourceEntry entry_exact(
    const std::string_view path,
    const Digest& content_digest,
    const std::uint64_t bytes,
    const std::uint16_t mode) {
    SourceEntry output{};
    if (path.size() > output.path.size()) return output;
    for (std::size_t index = 0U; index < path.size(); ++index) {
        output.path[index] = static_cast<std::uint8_t>(path[index]);
    }
    output.path_length = static_cast<std::uint8_t>(path.size());
    output.content_digest = content_digest;
    output.bytes = bytes;
    output.mode = mode;
    output.present = true;
    output.regular_file = true;
    return output;
}

[[nodiscard]] SourceEntry entry(
    const std::string_view path,
    const std::string_view content,
    const std::uint64_t bytes,
    const std::uint16_t mode) {
    return entry_exact(path, digest(content), bytes, mode);
}

void refresh_source(RelocationTrace& trace) {
    trace.source_closure.closure_digest = source_closure_identity(trace.source_closure);
}

void refresh_plan(RelocationTrace& trace) {
    trace.build_plan.plan_digest = build_plan_identity(trace.build_plan);
}

void refresh_capsule(RelocationTrace& trace) {
    trace.capsule.parent_challenge_receipt_digest = trace.parent.graph.challenge_receipt_digest;
    trace.capsule.logical_root_digest = trace.source_closure.logical_root_digest;
    trace.capsule.source_closure_digest = trace.source_closure.closure_digest;
    trace.capsule.build_plan_digest = trace.build_plan.plan_digest;
    trace.capsule.capsule_digest = provenance_capsule_identity(trace.capsule);
}

void refresh_observation(BuildObservation& observation, const RelocationTrace& trace) {
    observation.capsule_digest = trace.capsule.capsule_digest;
    observation.source_closure_digest = trace.source_closure.closure_digest;
    observation.build_plan_digest = trace.build_plan.plan_digest;
    observation.claim_digest = build_claim_identity(observation);
}

void refresh_receipt(
    ProvenanceReopenReceipt& receipt,
    const BuildObservation& observation,
    const RelocationTrace& trace) {
    receipt.claim_digest = observation.claim_digest;
    receipt.capsule_digest = trace.capsule.capsule_digest;
    receipt.source_closure_digest = trace.source_closure.closure_digest;
    receipt.build_plan_digest = trace.build_plan.plan_digest;
    receipt.output_digest = observation.output_digest;
    receipt.receipt_digest = reopen_receipt_identity(receipt);
}

void refresh_cuts(RelocationTrace& trace) {
    for (std::size_t index = 0U; index < trace.cuts.size(); ++index) {
        trace.cuts[index] = {};
        trace.cuts[index].source_closure_digest = trace.source_closure.closure_digest;
        if (index >= 1U) trace.cuts[index].build_plan_digest = trace.build_plan.plan_digest;
        if (index >= 2U) trace.cuts[index].capsule_digest = trace.capsule.capsule_digest;
        if (index >= 3U) trace.cuts[index].first_claim_digest = trace.first_observation.claim_digest;
        if (index >= 4U) trace.cuts[index].first_receipt_digest = trace.first_receipt.receipt_digest;
        if (index >= 5U) trace.cuts[index].relocated_claim_digest = trace.relocated_observation.claim_digest;
        if (index >= 6U) trace.cuts[index].relocated_receipt_digest = trace.relocated_receipt.receipt_digest;
    }
}

void refresh_from_source(RelocationTrace& trace) {
    refresh_source(trace);
    refresh_plan(trace);
    refresh_capsule(trace);
    refresh_observation(trace.first_observation, trace);
    refresh_observation(trace.relocated_observation, trace);
    refresh_receipt(trace.first_receipt, trace.first_observation, trace);
    refresh_receipt(trace.relocated_receipt, trace.relocated_observation, trace);
    refresh_cuts(trace);
}

void refresh_from_plan(RelocationTrace& trace) {
    refresh_plan(trace);
    refresh_capsule(trace);
    refresh_observation(trace.first_observation, trace);
    refresh_observation(trace.relocated_observation, trace);
    refresh_receipt(trace.first_receipt, trace.first_observation, trace);
    refresh_receipt(trace.relocated_receipt, trace.relocated_observation, trace);
    refresh_cuts(trace);
}

void refresh_from_capsule(RelocationTrace& trace) {
    refresh_capsule(trace);
    refresh_observation(trace.first_observation, trace);
    refresh_observation(trace.relocated_observation, trace);
    refresh_receipt(trace.first_receipt, trace.first_observation, trace);
    refresh_receipt(trace.relocated_receipt, trace.relocated_observation, trace);
    refresh_cuts(trace);
}

void refresh_from_observations(RelocationTrace& trace) {
    refresh_observation(trace.first_observation, trace);
    refresh_observation(trace.relocated_observation, trace);
    refresh_receipt(trace.first_receipt, trace.first_observation, trace);
    refresh_receipt(trace.relocated_receipt, trace.relocated_observation, trace);
    refresh_cuts(trace);
}

[[nodiscard]] RelocationTrace baseline() {
    RelocationTrace trace{};
    trace.parent = control_fate_falsification::make_hosted_clean_fixture();

    const Digest source_manifest = exact_digest(SLOPOS_RPC_SOURCE_MANIFEST_SHA256_HEX);
    const Digest build_plan_binding = exact_digest(SLOPOS_RPC_BUILD_PLAN_SHA256_HEX);
    const Digest output_contract = exact_digest(SLOPOS_RPC_OUTPUT_CONTRACT_SHA256_HEX);
    const Digest parent_binding = exact_digest(SLOPOS_RPC_PARENT_BINDING_SHA256_HEX);
    const Digest logical_root = exact_digest(SLOPOS_RPC_LOGICAL_ROOT_SHA256_HEX);
    const Digest claim_policy = exact_digest(SLOPOS_RPC_CLAIM_POLICY_SHA256_HEX);

    trace.source_closure.logical_root_digest = logical_root;
    trace.source_closure.parent_challenge_receipt_digest = trace.parent.graph.challenge_receipt_digest;
    trace.source_closure.entries[0] = entry_exact(
        "bindings/build-plan.json", build_plan_binding, SLOPOS_RPC_BUILD_PLAN_BYTES, mode_read_only);
    trace.source_closure.entries[1] = entry_exact(
        "bindings/claim-policy.txt", claim_policy, SLOPOS_RPC_CLAIM_POLICY_BYTES, mode_read_only);
    trace.source_closure.entries[2] = entry_exact(
        "bindings/logical-root.txt", logical_root, SLOPOS_RPC_LOGICAL_ROOT_BYTES, mode_read_only);
    trace.source_closure.entries[3] = entry_exact(
        "bindings/output-contract.json", output_contract, SLOPOS_RPC_OUTPUT_CONTRACT_BYTES, mode_read_only);
    trace.source_closure.entries[4] = entry_exact(
        "bindings/parent-binding.json", parent_binding, SLOPOS_RPC_PARENT_BINDING_BYTES, mode_read_only);
    trace.source_closure.entries[5] = entry_exact(
        "bindings/source-manifest.tsv", source_manifest, SLOPOS_RPC_SOURCE_MANIFEST_BYTES, mode_read_only);
    trace.source_closure.entry_count = 6U;
    trace.source_closure.present = true;
    trace.source_closure.canonical = true;
    trace.source_closure.complete = true;
    trace.source_closure.hidden_inputs_absent = true;
    refresh_source(trace);

    trace.build_plan.build_type_digest = digest("build-type:release-O0-g0-DNDEBUG");
    trace.build_plan.toolchain_digest = digest("toolchain-policy:cxx20-gcc-clang-hosted-lanes");
    trace.build_plan.flags_digest = digest("flags-policy:prefix-map-source-root-to-logical-root");
    trace.build_plan.environment_policy_digest = claim_policy;
    trace.build_plan.dependency_closure_digest = source_manifest;
    trace.build_plan.output_spec_digest = output_contract;
    trace.build_plan.deterministic_input_digest = build_plan_binding;
    trace.build_plan.present = true;
    trace.build_plan.canonical = true;
    trace.build_plan.all_behavior_inputs_bound = true;
    trace.build_plan.network_inputs_forbidden = true;
    refresh_plan(trace);

    const Digest output = output_contract;
    trace.capsule.parent_challenge_receipt_digest = trace.parent.graph.challenge_receipt_digest;
    trace.capsule.logical_root_digest = trace.source_closure.logical_root_digest;
    trace.capsule.source_closure_digest = trace.source_closure.closure_digest;
    trace.capsule.build_plan_digest = trace.build_plan.plan_digest;
    trace.capsule.expected_output_digest = output;
    trace.capsule.claim_policy_digest = claim_policy;
    trace.capsule.present = true;
    trace.capsule.canonical = true;
    trace.capsule.physical_locator_excluded_from_subject = true;
    trace.capsule.raw_logs_noncanonical = true;
    trace.capsule.ambient_locator_bound = false;
    refresh_capsule(trace);

    trace.first_observation.output_digest = output;
    trace.first_observation.physical_locator_digest = exact_digest(SLOPOS_RPC_FIRST_LOCATOR_SHA256_HEX);
    trace.first_observation.raw_log_digest = digest("raw-log:first-host-path-bearing-log");
    trace.first_observation.present = true;
    trace.first_observation.exact_inputs_consumed = true;
    trace.first_observation.output_set_complete = true;
    refresh_observation(trace.first_observation, trace);

    trace.relocated_observation = trace.first_observation;
    trace.relocated_observation.physical_locator_digest = exact_digest(SLOPOS_RPC_RELOCATED_LOCATOR_SHA256_HEX);
    trace.relocated_observation.raw_log_digest = digest("raw-log:relocated-host-path-bearing-log");
    refresh_observation(trace.relocated_observation, trace);

    trace.first_receipt.reopener_digest = digest("reopener:first-independent-reader");
    trace.first_receipt.present = true;
    trace.first_receipt.durable = true;
    trace.first_receipt.independently_administered = true;
    trace.first_receipt.exact_subject_reopened = true;
    refresh_receipt(trace.first_receipt, trace.first_observation, trace);

    trace.relocated_receipt.reopener_digest = digest("reopener:second-independent-reader");
    trace.relocated_receipt.present = true;
    trace.relocated_receipt.durable = true;
    trace.relocated_receipt.independently_administered = true;
    trace.relocated_receipt.exact_subject_reopened = true;
    refresh_receipt(trace.relocated_receipt, trace.relocated_observation, trace);
    refresh_cuts(trace);
    return trace;
}

void add_case(
    std::vector<Case>& cases,
    const std::string& name,
    RelocationTrace trace,
    const ProvenanceCode expected) {
    cases.push_back(Case{name, std::move(trace), expected});
}

template <std::size_t N>
[[nodiscard]] bool write_binary(
    const std::filesystem::path& path,
    const std::array<std::uint8_t, N>& bytes) {
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    output.write(reinterpret_cast<const char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
    return output.good();
}

[[nodiscard]] bool write_text(const std::filesystem::path& path, const std::string& text) {
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    output << text;
    return output.good();
}

[[nodiscard]] std::string path_text(const SourceEntry& value) {
    return std::string(reinterpret_cast<const char*>(value.path.data()), value.path_length);
}

[[nodiscard]] std::vector<Case> corpus() {
    const RelocationTrace good = baseline();
    std::vector<Case> cases;
    add_case(cases, "relocated_exact_subject", good, ProvenanceCode::accepted_relocated_exact_subject);

    {
        auto t = good;
        t.relocated_observation.physical_locator_digest = t.first_observation.physical_locator_digest;
        add_case(cases, "same_locator_is_not_relocation_witness", t, ProvenanceCode::accepted_same_locator_no_relocation_witness);
    }
    {
        auto t = good;
        t.source_closure.complete = false;
        refresh_from_source(t);
        add_case(cases, "source_closure_open", t, ProvenanceCode::accepted_refused_source_closure_open);
    }
    {
        auto t = good;
        t.source_closure.hidden_inputs_absent = false;
        refresh_from_source(t);
        add_case(cases, "hidden_source_inputs_not_excluded", t, ProvenanceCode::accepted_refused_source_closure_open);
    }
    {
        auto t = good;
        t.build_plan.all_behavior_inputs_bound = false;
        refresh_from_plan(t);
        add_case(cases, "build_behavior_inputs_open", t, ProvenanceCode::accepted_refused_build_plan_open);
    }
    {
        auto t = good;
        t.build_plan.network_inputs_forbidden = false;
        refresh_from_plan(t);
        add_case(cases, "network_inputs_not_forbidden", t, ProvenanceCode::accepted_refused_build_plan_open);
    }
    {
        auto t = good;
        t.first_observation.locator_used_as_semantic_input = true;
        t.relocated_observation.locator_used_as_semantic_input = true;
        refresh_from_observations(t);
        add_case(cases, "locator_influenced_both_outputs", t, ProvenanceCode::accepted_refused_locator_influenced_output);
    }
    {
        auto t = good;
        t.relocated_observation.output_digest = digest("output:diverged-under-relocation");
        refresh_from_observations(t);
        add_case(cases, "output_diverged_under_relocation", t, ProvenanceCode::accepted_refused_output_not_reproducible);
    }
    {
        auto t = good;
        t.capsule.expected_output_digest = digest("output:wrong-expectation");
        refresh_from_capsule(t);
        add_case(cases, "expected_output_not_observed", t, ProvenanceCode::accepted_refused_output_not_reproducible);
    }
    {
        auto t = good;
        t.parent.graph.graph_digest = {};
        add_case(cases, "parent_rejected", t, ProvenanceCode::parent_rejected);
    }
    {
        auto t = good;
        t.source_closure.present = false;
        add_case(cases, "source_missing", t, ProvenanceCode::source_closure_shape_invalid);
    }
    {
        auto t = good;
        t.source_closure.parent_challenge_receipt_digest = digest("wrong-parent-challenge");
        t.source_closure.closure_digest = source_closure_identity(t.source_closure);
        add_case(cases, "source_parent_binding_wrong", t, ProvenanceCode::source_closure_shape_invalid);
    }
    const std::array<std::string_view, 8U> bad_paths{{
        "/absolute.cpp", "../escape.cpp", "src/../x.cpp", "src//x.cpp",
        "src\\x.cpp", "SRC/x.cpp", "src/x.cpp/", "./x.cpp",
    }};
    for (std::size_t i = 0U; i < bad_paths.size(); ++i) {
        auto t = good;
        t.source_closure.entries[0] = entry(bad_paths[i], "bad-path", 10U, mode_read_only);
        t.source_closure.closure_digest = source_closure_identity(t.source_closure);
        add_case(cases, "bad_portable_path_" + std::to_string(i), t, ProvenanceCode::source_path_invalid);
    }
    {
        auto t = good;
        t.source_closure.entries[1] = t.source_closure.entries[0];
        t.source_closure.closure_digest = source_closure_identity(t.source_closure);
        add_case(cases, "duplicate_source_path", t, ProvenanceCode::source_path_duplicate);
    }
    {
        auto t = good;
        std::swap(t.source_closure.entries[0], t.source_closure.entries[1]);
        t.source_closure.closure_digest = source_closure_identity(t.source_closure);
        add_case(cases, "source_path_order_wrong", t, ProvenanceCode::source_path_order_invalid);
    }
    for (std::size_t i = 0U; i < 6U; ++i) {
        auto t = good;
        if (i == 0U) t.source_closure.entries[0].present = false;
        if (i == 1U) t.source_closure.entries[0].regular_file = false;
        if (i == 2U) t.source_closure.entries[0].content_digest = {};
        if (i == 3U) t.source_closure.entries[0].bytes = 0U;
        if (i == 4U) t.source_closure.entries[0].mode = 0644U;
        if (i == 5U) t.source_closure.entries[6] = entry("unused.cpp", "unused", 1U, mode_read_only);
        t.source_closure.closure_digest = source_closure_identity(t.source_closure);
        add_case(cases, "source_entry_invalid_" + std::to_string(i), t,
            i == 5U ? ProvenanceCode::source_closure_shape_invalid : ProvenanceCode::source_entry_invalid);
    }
    {
        auto t = good;
        t.source_closure.closure_digest[0] ^= 1U;
        add_case(cases, "source_identity_wrong", t, ProvenanceCode::source_closure_digest_mismatch);
    }
    for (std::size_t i = 0U; i < 7U; ++i) {
        auto t = good;
        if (i == 0U) t.build_plan.build_type_digest = {};
        if (i == 1U) t.build_plan.toolchain_digest = {};
        if (i == 2U) t.build_plan.flags_digest = {};
        if (i == 3U) t.build_plan.environment_policy_digest = {};
        if (i == 4U) t.build_plan.dependency_closure_digest = {};
        if (i == 5U) t.build_plan.output_spec_digest = {};
        if (i == 6U) t.build_plan.deterministic_input_digest = {};
        t.build_plan.plan_digest = build_plan_identity(t.build_plan);
        add_case(cases, "build_plan_shape_invalid_" + std::to_string(i), t, ProvenanceCode::build_plan_shape_invalid);
    }
    {
        auto t = good;
        t.build_plan.plan_digest[0] ^= 1U;
        add_case(cases, "build_plan_identity_wrong", t, ProvenanceCode::build_plan_digest_mismatch);
    }
    {
        auto t = good;
        t.capsule.present = false;
        add_case(cases, "capsule_missing", t, ProvenanceCode::provenance_capsule_shape_invalid);
    }
    const std::array<int, 4U> capsule_bindings{{0, 1, 2, 3}};
    for (const int which : capsule_bindings) {
        auto t = good;
        if (which == 0) t.capsule.parent_challenge_receipt_digest = digest("wrong-parent");
        if (which == 1) t.capsule.logical_root_digest = digest("wrong-root");
        if (which == 2) t.capsule.source_closure_digest = digest("wrong-closure");
        if (which == 3) t.capsule.build_plan_digest = digest("wrong-plan");
        t.capsule.capsule_digest = provenance_capsule_identity(t.capsule);
        add_case(cases, "capsule_binding_wrong_" + std::to_string(which), t, ProvenanceCode::provenance_capsule_binding_mismatch);
    }
    for (std::size_t i = 0U; i < 4U; ++i) {
        auto t = good;
        if (i == 0U) t.capsule.ambient_locator_bound = true;
        if (i == 1U) t.capsule.ambient_locator_digest = digest("poisoned-host-path");
        if (i == 2U) t.capsule.physical_locator_excluded_from_subject = false;
        if (i == 3U) t.capsule.raw_logs_noncanonical = false;
        t.capsule.capsule_digest = provenance_capsule_identity(t.capsule);
        add_case(cases, "ambient_locator_poison_" + std::to_string(i), t, ProvenanceCode::ambient_locator_poisoned_capsule);
    }
    {
        auto t = good;
        t.capsule.capsule_digest[0] ^= 1U;
        add_case(cases, "capsule_identity_wrong", t, ProvenanceCode::provenance_capsule_digest_mismatch);
    }
    for (std::size_t side = 0U; side < 2U; ++side) {
        {
            auto t = good;
            auto& o = side == 0U ? t.first_observation : t.relocated_observation;
            o.present = false;
            add_case(cases, (side == 0U ? "first" : "relocated") + std::string("_observation_missing"), t,
                side == 0U ? ProvenanceCode::first_observation_shape_invalid : ProvenanceCode::relocated_observation_shape_invalid);
        }
        {
            auto t = good;
            auto& o = side == 0U ? t.first_observation : t.relocated_observation;
            o.capsule_digest = digest("wrong-capsule-binding");
            o.claim_digest = build_claim_identity(o);
            add_case(cases, (side == 0U ? "first" : "relocated") + std::string("_observation_binding_wrong"), t,
                side == 0U ? ProvenanceCode::first_claim_binding_mismatch : ProvenanceCode::relocated_claim_binding_mismatch);
        }
        {
            auto t = good;
            auto& o = side == 0U ? t.first_observation : t.relocated_observation;
            o.claim_digest[0] ^= 1U;
            add_case(cases, (side == 0U ? "first" : "relocated") + std::string("_claim_identity_wrong"), t,
                side == 0U ? ProvenanceCode::first_claim_digest_mismatch : ProvenanceCode::relocated_claim_digest_mismatch);
        }
    }
    for (std::size_t side = 0U; side < 2U; ++side) {
        {
            auto t = good;
            auto& r = side == 0U ? t.first_receipt : t.relocated_receipt;
            r.durable = false;
            add_case(cases, (side == 0U ? "first" : "relocated") + std::string("_receipt_not_durable"), t,
                side == 0U ? ProvenanceCode::first_receipt_shape_invalid : ProvenanceCode::relocated_receipt_shape_invalid);
        }
        {
            auto t = good;
            auto& r = side == 0U ? t.first_receipt : t.relocated_receipt;
            r.output_digest = digest("wrong-receipt-output");
            r.receipt_digest = reopen_receipt_identity(r);
            add_case(cases, (side == 0U ? "first" : "relocated") + std::string("_receipt_binding_wrong"), t,
                side == 0U ? ProvenanceCode::first_receipt_binding_mismatch : ProvenanceCode::relocated_receipt_binding_mismatch);
        }
        {
            auto t = good;
            auto& r = side == 0U ? t.first_receipt : t.relocated_receipt;
            r.receipt_digest[0] ^= 1U;
            add_case(cases, (side == 0U ? "first" : "relocated") + std::string("_receipt_identity_wrong"), t,
                side == 0U ? ProvenanceCode::first_receipt_digest_mismatch : ProvenanceCode::relocated_receipt_digest_mismatch);
        }
    }
    for (std::size_t i = 0U; i < provenance_cut_count; ++i) {
        auto t = good;
        t.cuts[i].source_closure_digest[0] ^= 1U;
        add_case(cases, "cut_order_wrong_" + std::to_string(i), t, ProvenanceCode::provenance_cut_order_invalid);
    }
    return cases;
}

}  // namespace

bool run_campaign(const std::filesystem::path& output_directory) {
    // Publication is no-replace: a campaign may create one absent output root,
    // but it never recursively deletes or overwrites a pre-existing namespace.
    std::error_code error;
    if (std::filesystem::exists(output_directory, error) || error) return false;
    std::filesystem::create_directories(output_directory, error);
    if (error) return false;

    const RelocationTrace canonical = baseline();
    const std::vector<Case> cases = corpus();
    std::size_t disagreements = 0U;
    std::size_t expectation_failures = 0U;
    std::size_t accepted = 0U;
    std::size_t rejected = 0U;
    std::size_t relocation_witnesses = 0U;
    std::size_t safe_refusals = 0U;

    std::ostringstream cases_tsv;
    cases_tsv << "case\texpected\tcandidate\treference\tagree\taccepted\trelocation_witness\tlocators_distinct\tclaims_equal\toutputs_equal\tauthority\tepoch_exit\tlive_record_retained\n";
    for (const auto& test : cases) {
        const ProvenanceReport candidate = evaluate_candidate(test.trace);
        const ProvenanceReport reference = evaluate_reference(test.trace);
        const bool agree = candidate == reference;
        const bool expected = candidate.code == test.expected;
        disagreements += agree ? 0U : 1U;
        expectation_failures += expected ? 0U : 1U;
        accepted += candidate.accepted ? 1U : 0U;
        rejected += candidate.accepted ? 0U : 1U;
        relocation_witnesses += candidate.relocation_witness ? 1U : 0U;
        safe_refusals += candidate.accepted && !candidate.relocation_witness ? 1U : 0U;
        cases_tsv << test.name << '\t' << provenance_code_name(test.expected) << '\t'
            << provenance_code_name(candidate.code) << '\t' << provenance_code_name(reference.code) << '\t'
            << (agree ? "true" : "false") << '\t' << (candidate.accepted ? "true" : "false") << '\t'
            << (candidate.relocation_witness ? "true" : "false") << '\t'
            << (candidate.locators_distinct ? "true" : "false") << '\t'
            << (candidate.canonical_claims_equal ? "true" : "false") << '\t'
            << (candidate.outputs_equal ? "true" : "false") << '\t'
            << (candidate.authority_granted ? "true" : "false") << '\t'
            << (candidate.epoch_exit_proved ? "true" : "false") << '\t'
            << (candidate.live_record_must_be_retained ? "true" : "false") << '\n';
    }

    std::ostringstream matrix;
    matrix << "row\tfirst_locator\trelocated_locator\tfirst_claim\trelocated_claim\toutput\tclaim_invariant\trelocation_witness\n";
    std::size_t matrix_failures = 0U;
    for (std::size_t index = 0U; index < 24U; ++index) {
        auto trace = canonical;
        trace.first_observation.physical_locator_digest = digest("matrix:first:" + std::to_string(index));
        trace.first_observation.raw_log_digest = digest("matrix:first-log:" + std::to_string(index));
        trace.relocated_observation.physical_locator_digest = digest("matrix:relocated:" + std::to_string(index));
        trace.relocated_observation.raw_log_digest = digest("matrix:relocated-log:" + std::to_string(index));
        refresh_from_observations(trace);
        const auto result = evaluate_candidate(trace);
        const bool invariant = trace.first_observation.claim_digest == trace.relocated_observation.claim_digest;
        const bool witness = result.code == ProvenanceCode::accepted_relocated_exact_subject && result.relocation_witness;
        matrix_failures += invariant && witness ? 0U : 1U;
        matrix << index << '\t' << hex(trace.first_observation.physical_locator_digest) << '\t'
            << hex(trace.relocated_observation.physical_locator_digest) << '\t'
            << hex(trace.first_observation.claim_digest) << '\t'
            << hex(trace.relocated_observation.claim_digest) << '\t'
            << hex(trace.first_observation.output_digest) << '\t'
            << (invariant ? "true" : "false") << '\t' << (witness ? "true" : "false") << '\n';
    }

    EncodedSourceClosure source_bytes{};
    EncodedBuildPlan plan_bytes{};
    EncodedProvenanceCapsule capsule_bytes{};
    EncodedBuildClaim claim_bytes{};
    EncodedReopenReceipt first_receipt_bytes{};
    EncodedReopenReceipt relocated_receipt_bytes{};
    const bool encoded = encode_source_closure(canonical.source_closure, source_bytes)
        && encode_build_plan(canonical.build_plan, plan_bytes)
        && encode_provenance_capsule(canonical.capsule, capsule_bytes)
        && encode_build_claim(canonical.first_observation, claim_bytes)
        && encode_reopen_receipt(canonical.first_receipt, first_receipt_bytes)
        && encode_reopen_receipt(canonical.relocated_receipt, relocated_receipt_bytes);

    std::ostringstream entries_tsv;
    entries_tsv << "index\tpath\tbytes\tmode\tcontent_sha256\n";
    for (std::size_t index = 0U; index < canonical.source_closure.entry_count; ++index) {
        const auto& value = canonical.source_closure.entries[index];
        entries_tsv << index << '\t' << path_text(value) << '\t' << value.bytes << '\t'
            << std::oct << value.mode << std::dec << '\t' << hex(value.content_digest) << '\n';
    }

    std::ostringstream cuts_tsv;
    cuts_tsv << "index\tcut\tsource_closure\tbuild_plan\tcapsule\tfirst_claim\tfirst_receipt\trelocated_claim\trelocated_receipt\n";
    for (std::size_t index = 0U; index < provenance_cut_count; ++index) {
        const auto& cut = canonical.cuts[index];
        cuts_tsv << index << '\t' << provenance_cut_name(index) << '\t'
            << hex(cut.source_closure_digest) << '\t' << hex(cut.build_plan_digest) << '\t'
            << hex(cut.capsule_digest) << '\t' << hex(cut.first_claim_digest) << '\t'
            << hex(cut.first_receipt_digest) << '\t' << hex(cut.relocated_claim_digest) << '\t'
            << hex(cut.relocated_receipt_digest) << '\n';
    }

    std::ostringstream identities;
    identities << "object\tbytes\tidentity_sha256\n"
        << "source_closure\t" << source_bytes.size() << '\t' << hex(canonical.source_closure.closure_digest) << '\n'
        << "build_plan\t" << plan_bytes.size() << '\t' << hex(canonical.build_plan.plan_digest) << '\n'
        << "provenance_capsule\t" << capsule_bytes.size() << '\t' << hex(canonical.capsule.capsule_digest) << '\n'
        << "build_claim\t" << claim_bytes.size() << '\t' << hex(canonical.first_observation.claim_digest) << '\n'
        << "first_reopen_receipt\t" << first_receipt_bytes.size() << '\t' << hex(canonical.first_receipt.receipt_digest) << '\n'
        << "relocated_reopen_receipt\t" << relocated_receipt_bytes.size() << '\t' << hex(canonical.relocated_receipt.receipt_digest) << '\n';

    constexpr std::array<std::string_view, 17U> laws{{
        "logical source identity is root-relative and content-bound",
        "physical workspace locator is excluded from canonical claim identity",
        "raw build logs are observations and may retain host paths without becoming identity",
        "portable source paths reject absolute traversal duplicate and unordered names",
        "source closure binds exact retained source-manifest build-plan output-contract parent logical-root and claim-policy carriers",
        "source completeness and hidden-input absence are distinct obligations",
        "build plan binds the exact retained source-manifest build-plan and output-contract digests",
        "network inputs remain forbidden in the complete hosted plan",
        "a provenance capsule binds the exact accepted parent challenge receipt",
        "both build observations bind the same capsule source closure and plan",
        "different physical locators with one claim and output form a relocation witness",
        "one physical locator alone cannot establish locator noninterference",
        "output divergence under relocation is a refusal not proof",
        "independent reopen receipts bind exact claims and exact outputs",
        "the first exact reopen receipt is durable before the relocated claim is admitted",
        "every durable cut contains exactly the objects available at that stage",
        "relocation evidence grants no authority and does not exit Epoch Zero",
    }};
    std::ostringstream laws_tsv;
    laws_tsv << "law\tstatement\n";
    for (std::size_t index = 0U; index < laws.size(); ++index) laws_tsv << (index + 1U) << '\t' << laws[index] << '\n';

    constexpr std::array<std::string_view, 19U> countermodels{{
        "same absolute pathname with changed bytes",
        "different pathname without exact source closure",
        "CMakeCache absolute source directory treated as canonical identity",
        "debug path prefix embedded into otherwise matching outputs",
        "unordered directory walk presented as source closure",
        "relative path containing dot-dot escape",
        "source digest without file kind size or mode",
        "build command without dependency closure",
        "toolchain family named without exact version or digest",
        "environment allowed to fetch network inputs",
        "raw log digest substituted for canonical build claim",
        "one build copied to two directories and called two executions",
        "two executions with different outputs called reproducible",
        "two identical outputs with unknown hidden inputs",
        "receipt reopening a sibling claim",
        "first reopen receipt asserted durable without a predecessor cut",
        "capsule binding a host locator into its subject",
        "successful relocation called source authenticity",
        "successful relocation called authority or Epoch-Zero exit",
    }};
    std::ostringstream countermodels_tsv;
    countermodels_tsv << "countermodel\tstatement\n";
    for (std::size_t index = 0U; index < countermodels.size(); ++index) {
        countermodels_tsv << (index + 1U) << '\t' << countermodels[index] << '\n';
    }

    std::ostringstream summary;
    summary << "metric\tvalue\n"
        << "cases\t" << cases.size() << '\n'
        << "accepted_classifications\t" << accepted << '\n'
        << "rejected_classifications\t" << rejected << '\n'
        << "safe_refusals_or_nonwitnesses\t" << safe_refusals << '\n'
        << "relocation_witnesses\t" << relocation_witnesses << '\n'
        << "candidate_reference_disagreements\t" << disagreements << '\n'
        << "expectation_failures\t" << expectation_failures << '\n'
        << "relocation_matrix_rows\t24\n"
        << "relocation_matrix_failures\t" << matrix_failures << '\n'
        << "durable_cuts\t" << provenance_cut_count << '\n'
        << "source_entries\t" << static_cast<unsigned>(canonical.source_closure.entry_count) << '\n'
        << "canonical_object_bytes\t2180\n"
        << "laws\t" << laws.size() << '\n'
        << "countermodels\t" << countermodels.size() << '\n'
        << "authority_granted\tfalse\n"
        << "epoch_exit_proved\tfalse\n"
        << "parent_live_record_retained\ttrue\n"
        << "source_manifest_bound_into_subject\ttrue\n"
        << "build_plan_bound_into_subject\ttrue\n"
        << "output_contract_bound_into_subject\ttrue\n"
        << "reference_canonical_encoder_independent\ttrue\n"
        << "first_receipt_precedes_relocated_claim\ttrue\n";

    const bool files_ok = encoded
        && write_binary(output_directory / "SOURCE-CLOSURE.bin", source_bytes)
        && write_binary(output_directory / "BUILD-PLAN.bin", plan_bytes)
        && write_binary(output_directory / "PROVENANCE-CAPSULE.bin", capsule_bytes)
        && write_binary(output_directory / "BUILD-CLAIM.bin", claim_bytes)
        && write_binary(output_directory / "FIRST-REOPEN-RECEIPT.bin", first_receipt_bytes)
        && write_binary(output_directory / "RELOCATED-REOPEN-RECEIPT.bin", relocated_receipt_bytes)
        && write_text(output_directory / "CASES.tsv", cases_tsv.str())
        && write_text(output_directory / "RELOCATION-MATRIX.tsv", matrix.str())
        && write_text(output_directory / "SOURCE-ENTRIES.tsv", entries_tsv.str())
        && write_text(output_directory / "CUTS.tsv", cuts_tsv.str())
        && write_text(output_directory / "IDENTITIES.tsv", identities.str())
        && write_text(output_directory / "LAWS.tsv", laws_tsv.str())
        && write_text(output_directory / "COUNTERMODELS.tsv", countermodels_tsv.str())
        && write_text(output_directory / "SUMMARY.tsv", summary.str());

    const bool ok = files_ok && disagreements == 0U && expectation_failures == 0U
        && matrix_failures == 0U && cases.size() >= 60U;
    std::ostringstream report;
    report << "RELOCATABLE_PROVENANCE=" << (ok ? "PASS" : "FAIL") << '\n'
        << "cases=" << cases.size() << " accepted=" << accepted << " rejected=" << rejected
        << " relocation_witnesses=" << relocation_witnesses << " disagreements=" << disagreements
        << " expectation_failures=" << expectation_failures << " matrix_failures=" << matrix_failures << '\n'
        << "physical_locator_is_identity=false\n"
        << "raw_logs_are_canonical=false\n"
        << "source_manifest_bound_into_subject=true\n"
        << "build_plan_bound_into_subject=true\n"
        << "output_contract_bound_into_subject=true\n"
        << "reference_canonical_encoder_independent=true\n"
        << "first_receipt_precedes_relocated_claim=true\n"
        << "authority=false\n"
        << "epoch=EPOCH_ZERO\n";
    if (!write_text(output_directory / "REPORT.txt", report.str())) return false;
    std::cout << report.str();
    return ok;
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification::relocatable_provenance
