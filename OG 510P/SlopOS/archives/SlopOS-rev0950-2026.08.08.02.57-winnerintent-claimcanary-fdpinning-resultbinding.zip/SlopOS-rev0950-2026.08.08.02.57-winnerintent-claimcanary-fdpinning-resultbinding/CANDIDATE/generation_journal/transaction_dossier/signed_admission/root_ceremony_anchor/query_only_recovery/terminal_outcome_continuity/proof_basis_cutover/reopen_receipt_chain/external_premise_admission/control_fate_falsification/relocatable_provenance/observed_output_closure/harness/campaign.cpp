#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/reopen_receipt_chain/external_premise_admission/control_fate_falsification/relocatable_provenance/observed_output_closure.hpp"

#include "parent_output_set.hpp"
#include "slopos/e0/generation_journal/spend_record.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <span>
#include <sstream>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification::relocatable_provenance::observed_output_closure {
namespace {

#ifndef SLOPOS_RPC_SOURCE_MANIFEST_SHA256_HEX
#error "child fixture requires exact parent source manifest"
#endif
#ifndef SLOPOS_RPC_BUILD_PLAN_SHA256_HEX
#error "child fixture requires exact parent build plan"
#endif
#ifndef SLOPOS_RPC_OUTPUT_CONTRACT_SHA256_HEX
#error "child fixture requires exact parent output contract"
#endif
#ifndef SLOPOS_RPC_PARENT_BINDING_SHA256_HEX
#error "child fixture requires exact parent binding"
#endif
#ifndef SLOPOS_RPC_LOGICAL_ROOT_SHA256_HEX
#error "child fixture requires exact parent logical root"
#endif
#ifndef SLOPOS_RPC_CLAIM_POLICY_SHA256_HEX
#error "child fixture requires exact parent claim policy"
#endif
#ifndef SLOPOS_RPC_FIRST_LOCATOR_SHA256_HEX
#error "child fixture requires first locator"
#endif
#ifndef SLOPOS_RPC_RELOCATED_LOCATOR_SHA256_HEX
#error "child fixture requires relocated locator"
#endif
#ifndef SLOPOS_OOC_PARENT_OUTPUT_CARRIER_SHA256_HEX
#error "child fixture requires exact prior output-set carrier"
#endif
#ifndef SLOPOS_OOC_PARENT_OUTPUT_CARRIER_BYTES
#error "child fixture requires exact prior output-set carrier bytes"
#endif
#ifndef SLOPOS_OOC_RESERVED_POLICY_SHA256_HEX
#error "child fixture requires exact reserved-namespace policy"
#endif
#ifndef SLOPOS_OOC_REOPENER_IMPLEMENTATION_SHA256_HEX
#error "child fixture requires exact hosted reopener implementation"
#endif

struct Case final {
    std::string name;
    OutputClosureTrace trace;
    ClosureCode expected;
};

[[nodiscard]] Digest digest(const std::string_view label) {
    return generation_journal::sha256(std::span<const std::uint8_t>(
        reinterpret_cast<const std::uint8_t*>(label.data()), label.size()));
}

[[nodiscard]] constexpr std::uint8_t hex_nibble(const char value) noexcept {
    if (value >= '0' && value <= '9') return static_cast<std::uint8_t>(value - '0');
    if (value >= 'a' && value <= 'f') return static_cast<std::uint8_t>(value - 'a' + 10);
    return 0xffU;
}

[[nodiscard]] Digest exact_digest(const std::string_view value) noexcept {
    Digest output{};
    if (value.size() != 64U) return output;
    for (std::size_t index = 0U; index < output.size(); ++index) {
        const std::uint8_t high = hex_nibble(value[index * 2U]);
        const std::uint8_t low = hex_nibble(value[index * 2U + 1U]);
        if (high > 15U || low > 15U) return {};
        output[index] = static_cast<std::uint8_t>((high << 4U) | low);
    }
    return output;
}

[[nodiscard]] std::string hex(const Digest& value) {
    std::ostringstream out;
    out << std::hex << std::setfill('0');
    for (const auto byte : value) out << std::setw(2) << static_cast<unsigned>(byte);
    return out.str();
}

[[nodiscard]] SourceEntry source_entry_exact(
    const std::string_view path,
    const Digest& content_digest,
    const std::uint64_t bytes,
    const std::uint16_t mode) {
    SourceEntry output{};
    if (path.size() > output.path.size()) return output;
    for (std::size_t index = 0U; index < path.size(); ++index) output.path[index] = static_cast<std::uint8_t>(path[index]);
    output.path_length = static_cast<std::uint8_t>(path.size());
    output.content_digest = content_digest;
    output.bytes = bytes;
    output.mode = mode;
    output.present = true;
    output.regular_file = true;
    return output;
}

void refresh_parent_source(RelocationTrace& trace) { trace.source_closure.closure_digest = source_closure_identity(trace.source_closure); }
void refresh_parent_plan(RelocationTrace& trace) { trace.build_plan.plan_digest = build_plan_identity(trace.build_plan); }
void refresh_parent_capsule(RelocationTrace& trace) {
    trace.capsule.parent_challenge_receipt_digest = trace.parent.graph.challenge_receipt_digest;
    trace.capsule.logical_root_digest = trace.source_closure.logical_root_digest;
    trace.capsule.source_closure_digest = trace.source_closure.closure_digest;
    trace.capsule.build_plan_digest = trace.build_plan.plan_digest;
    trace.capsule.capsule_digest = provenance_capsule_identity(trace.capsule);
}
void refresh_parent_observation(BuildObservation& observation, const RelocationTrace& trace) {
    observation.capsule_digest = trace.capsule.capsule_digest;
    observation.source_closure_digest = trace.source_closure.closure_digest;
    observation.build_plan_digest = trace.build_plan.plan_digest;
    observation.claim_digest = build_claim_identity(observation);
}
void refresh_parent_receipt(ProvenanceReopenReceipt& receipt, const BuildObservation& observation, const RelocationTrace& trace) {
    receipt.claim_digest = observation.claim_digest;
    receipt.capsule_digest = trace.capsule.capsule_digest;
    receipt.source_closure_digest = trace.source_closure.closure_digest;
    receipt.build_plan_digest = trace.build_plan.plan_digest;
    receipt.output_digest = observation.output_digest;
    receipt.receipt_digest = reopen_receipt_identity(receipt);
}
void refresh_parent_cuts(RelocationTrace& trace) {
    for (std::size_t index = 0U; index < trace.cuts.size(); ++index) {
        trace.cuts[index] = {};
        trace.cuts[index].source_closure_digest = trace.source_closure.closure_digest;
        if (index >= 1U) trace.cuts[index].build_plan_digest = trace.build_plan.plan_digest;
        if (index >= 2U) trace.cuts[index].capsule_digest = trace.capsule.capsule_digest;
        if (index >= 3U) trace.cuts[index].first_claim_digest = trace.first_observation.claim_digest;
        if (index >= 4U) trace.cuts[index].first_receipt_digest = trace.first_receipt.receipt_digest;
        if (index >= 5U) trace.cuts[index].relocated_claim_digest = trace.relocated_observation.claim_digest;
        if (index >= 6U) trace.cuts[index].relocated_receipt_digest = trace.relocated_receipt.receipt_digest;
    }
}

[[nodiscard]] RelocationTrace parent_baseline() {
    RelocationTrace trace{};
    trace.parent = control_fate_falsification::make_hosted_clean_fixture();
    const Digest source_manifest = exact_digest(SLOPOS_RPC_SOURCE_MANIFEST_SHA256_HEX);
    const Digest build_plan_binding = exact_digest(SLOPOS_RPC_BUILD_PLAN_SHA256_HEX);
    const Digest output_contract = exact_digest(SLOPOS_RPC_OUTPUT_CONTRACT_SHA256_HEX);
    const Digest parent_binding = exact_digest(SLOPOS_RPC_PARENT_BINDING_SHA256_HEX);
    const Digest logical_root = exact_digest(SLOPOS_RPC_LOGICAL_ROOT_SHA256_HEX);
    const Digest claim_policy = exact_digest(SLOPOS_RPC_CLAIM_POLICY_SHA256_HEX);

    trace.source_closure.logical_root_digest = logical_root;
    trace.source_closure.parent_challenge_receipt_digest = trace.parent.graph.challenge_receipt_digest;
    trace.source_closure.entries[0] = source_entry_exact("bindings/build-plan.json", build_plan_binding, SLOPOS_RPC_BUILD_PLAN_BYTES, mode_read_only);
    trace.source_closure.entries[1] = source_entry_exact("bindings/claim-policy.txt", claim_policy, SLOPOS_RPC_CLAIM_POLICY_BYTES, mode_read_only);
    trace.source_closure.entries[2] = source_entry_exact("bindings/logical-root.txt", logical_root, SLOPOS_RPC_LOGICAL_ROOT_BYTES, mode_read_only);
    trace.source_closure.entries[3] = source_entry_exact("bindings/output-contract.json", output_contract, SLOPOS_RPC_OUTPUT_CONTRACT_BYTES, mode_read_only);
    trace.source_closure.entries[4] = source_entry_exact("bindings/parent-binding.json", parent_binding, SLOPOS_RPC_PARENT_BINDING_BYTES, mode_read_only);
    trace.source_closure.entries[5] = source_entry_exact("bindings/source-manifest.tsv", source_manifest, SLOPOS_RPC_SOURCE_MANIFEST_BYTES, mode_read_only);
    trace.source_closure.entry_count = 6U;
    trace.source_closure.present = true;
    trace.source_closure.canonical = true;
    trace.source_closure.complete = true;
    trace.source_closure.hidden_inputs_absent = true;
    refresh_parent_source(trace);

    trace.build_plan.build_type_digest = digest("build-type:release-O0-g0-DNDEBUG");
    trace.build_plan.toolchain_digest = digest("toolchain-policy:cxx20-gcc-clang-hosted-lanes");
    trace.build_plan.flags_digest = digest("flags-policy:prefix-map-source-root-to-logical-root");
    trace.build_plan.environment_policy_digest = claim_policy;
    trace.build_plan.dependency_closure_digest = source_manifest;
    trace.build_plan.output_spec_digest = output_contract;
    trace.build_plan.deterministic_input_digest = build_plan_binding;
    trace.build_plan.present = true;
    trace.build_plan.canonical = true;
    trace.build_plan.all_behavior_inputs_bound = true;
    trace.build_plan.network_inputs_forbidden = true;
    refresh_parent_plan(trace);

    trace.capsule.parent_challenge_receipt_digest = trace.parent.graph.challenge_receipt_digest;
    trace.capsule.logical_root_digest = trace.source_closure.logical_root_digest;
    trace.capsule.source_closure_digest = trace.source_closure.closure_digest;
    trace.capsule.build_plan_digest = trace.build_plan.plan_digest;
    trace.capsule.expected_output_digest = output_contract;
    trace.capsule.claim_policy_digest = claim_policy;
    trace.capsule.present = true;
    trace.capsule.canonical = true;
    trace.capsule.physical_locator_excluded_from_subject = true;
    trace.capsule.raw_logs_noncanonical = true;
    refresh_parent_capsule(trace);

    trace.first_observation.output_digest = output_contract;
    trace.first_observation.physical_locator_digest = exact_digest(SLOPOS_RPC_FIRST_LOCATOR_SHA256_HEX);
    trace.first_observation.raw_log_digest = digest("raw-log:first-host-path-bearing-log");
    trace.first_observation.present = true;
    trace.first_observation.exact_inputs_consumed = true;
    trace.first_observation.output_set_complete = true;
    refresh_parent_observation(trace.first_observation, trace);

    trace.relocated_observation = trace.first_observation;
    trace.relocated_observation.physical_locator_digest = exact_digest(SLOPOS_RPC_RELOCATED_LOCATOR_SHA256_HEX);
    trace.relocated_observation.raw_log_digest = digest("raw-log:relocated-host-path-bearing-log");
    refresh_parent_observation(trace.relocated_observation, trace);

    trace.first_receipt.reopener_digest = digest("reopener:first-independent-reader");
    trace.first_receipt.present = true;
    trace.first_receipt.durable = true;
    trace.first_receipt.independently_administered = true;
    trace.first_receipt.exact_subject_reopened = true;
    refresh_parent_receipt(trace.first_receipt, trace.first_observation, trace);

    trace.relocated_receipt.reopener_digest = digest("reopener:second-independent-reader");
    trace.relocated_receipt.present = true;
    trace.relocated_receipt.durable = true;
    trace.relocated_receipt.independently_administered = true;
    trace.relocated_receipt.exact_subject_reopened = true;
    refresh_parent_receipt(trace.relocated_receipt, trace.relocated_observation, trace);
    refresh_parent_cuts(trace);
    return trace;
}

[[nodiscard]] OutputEntry output_entry(
    const std::string_view path,
    const Digest& content,
    const std::uint64_t bytes,
    const std::uint16_t mode) {
    OutputEntry entry{};
    if (path.size() > entry.path.size()) return entry;
    for (std::size_t index = 0U; index < path.size(); ++index) entry.path[index] = static_cast<std::uint8_t>(path[index]);
    entry.path_length = static_cast<std::uint8_t>(path.size());
    entry.content_digest = content;
    entry.bytes = bytes;
    entry.mode = mode;
    entry.present = true;
    entry.regular_file = true;
    return entry;
}

void set_output_path(OutputEntry& entry, const std::string_view path) {
    entry.path.fill(0U);
    if (path.size() > entry.path.size()) { entry.path_length = 0U; return; }
    for (std::size_t index = 0U; index < path.size(); ++index) entry.path[index] = static_cast<std::uint8_t>(path[index]);
    entry.path_length = static_cast<std::uint8_t>(path.size());
}

void refresh_manifest(OutputClosureTrace& trace) { trace.manifest.manifest_digest = output_manifest_identity(trace.manifest); }
void refresh_publication(OutputClosureTrace& trace) {
    trace.publication.manifest_digest = trace.manifest.manifest_digest;
    trace.publication.parent_relocated_receipt_digest = trace.parent.relocated_receipt.receipt_digest;
    trace.publication.parent_output_carrier_digest = exact_digest(SLOPOS_OOC_PARENT_OUTPUT_CARRIER_SHA256_HEX);
    trace.publication.receipt_digest = publication_receipt_identity(trace.publication);
}
void refresh_reopen(OutputClosureTrace& trace) {
    trace.reopen.publication_receipt_digest = trace.publication.receipt_digest;
    trace.reopen.manifest_digest = trace.manifest.manifest_digest;
    trace.reopen.parent_output_carrier_digest = exact_digest(SLOPOS_OOC_PARENT_OUTPUT_CARRIER_SHA256_HEX);
    trace.reopen.receipt_digest = output_reopen_receipt_identity(trace.reopen);
}
void refresh_claim(OutputClosureTrace& trace) {
    trace.claim.parent_relocated_receipt_digest = trace.parent.relocated_receipt.receipt_digest;
    trace.claim.parent_build_claim_digest = trace.parent.relocated_observation.claim_digest;
    trace.claim.manifest_digest = trace.manifest.manifest_digest;
    trace.claim.publication_receipt_digest = trace.publication.receipt_digest;
    trace.claim.reopen_receipt_digest = trace.reopen.receipt_digest;
    trace.claim.reserved_namespace_policy_digest = exact_digest(SLOPOS_OOC_RESERVED_POLICY_SHA256_HEX);
    trace.claim.claim_digest = output_closure_claim_identity(trace.claim);
}
void refresh_cuts(OutputClosureTrace& trace) {
    for (std::size_t index = 0U; index < trace.cuts.size(); ++index) {
        trace.cuts[index] = {};
        trace.cuts[index].parent_output_carrier_digest = exact_digest(SLOPOS_OOC_PARENT_OUTPUT_CARRIER_SHA256_HEX);
        if (trace.manifest.present && index >= 1U) trace.cuts[index].manifest_digest = trace.manifest.manifest_digest;
        if (trace.publication.present && index >= 2U) trace.cuts[index].publication_receipt_digest = trace.publication.receipt_digest;
        if (trace.reopen.present && index >= 3U) trace.cuts[index].reopen_receipt_digest = trace.reopen.receipt_digest;
        if (trace.claim.present && index >= 4U) trace.cuts[index].closure_claim_digest = trace.claim.claim_digest;
    }
}
void refresh_from_manifest(OutputClosureTrace& trace) { refresh_manifest(trace); refresh_publication(trace); refresh_reopen(trace); refresh_claim(trace); refresh_cuts(trace); }
void refresh_from_publication(OutputClosureTrace& trace) { refresh_publication(trace); refresh_reopen(trace); refresh_claim(trace); refresh_cuts(trace); }
void refresh_from_reopen(OutputClosureTrace& trace) { refresh_reopen(trace); refresh_claim(trace); refresh_cuts(trace); }
void refresh_from_claim(OutputClosureTrace& trace) { refresh_claim(trace); refresh_cuts(trace); }

[[nodiscard]] OutputClosureTrace baseline() {
    OutputClosureTrace trace{};
    trace.parent = parent_baseline();
    trace.manifest.parent_relocated_receipt_digest = trace.parent.relocated_receipt.receipt_digest;
    trace.manifest.parent_build_claim_digest = trace.parent.relocated_observation.claim_digest;
    trace.manifest.parent_provenance_output_digest = trace.parent.relocated_observation.output_digest;
    trace.manifest.parent_output_carrier_digest = exact_digest(SLOPOS_OOC_PARENT_OUTPUT_CARRIER_SHA256_HEX);
    trace.manifest.reserved_namespace_policy_digest = exact_digest(SLOPOS_OOC_RESERVED_POLICY_SHA256_HEX);
    using slopos::e0::observed_output_closure_generated::parent_output_entries;
    for (std::size_t index = 0U; index < parent_output_entries.size(); ++index) {
        const auto& expected = parent_output_entries[index];
        trace.manifest.entries[index] = output_entry(expected.path, exact_digest(expected.sha256), expected.bytes, expected.mode);
    }
    trace.manifest.entry_count = static_cast<std::uint8_t>(parent_output_entries.size());
    trace.manifest.present = true;
    trace.manifest.canonical = true;
    trace.manifest.exact_prior_set = true;
    trace.manifest.complete = true;
    trace.manifest.reserved_namespace_excluded = true;
    refresh_manifest(trace);

    trace.publication.publisher_digest = digest("publisher:hosted-no-replace-output-manifest-writer");
    trace.publication.carrier_bytes = SLOPOS_OOC_PARENT_OUTPUT_CARRIER_BYTES;
    trace.publication.present = true;
    trace.publication.durable = true;
    trace.publication.no_replace_publication = true;
    trace.publication.single_view_reopened = true;
    trace.publication.exact_carrier_published = true;
    refresh_publication(trace);

    trace.reopen.reopener_digest = digest("reopener:separate-hosted-parent-output-set-rehasher");
    trace.reopen.reopener_implementation_digest = exact_digest(SLOPOS_OOC_REOPENER_IMPLEMENTATION_SHA256_HEX);
    trace.reopen.carrier_bytes = SLOPOS_OOC_PARENT_OUTPUT_CARRIER_BYTES;
    trace.reopen.present = true;
    trace.reopen.durable = true;
    trace.reopen.separate_reopener_role = true;
    trace.reopen.exact_manifest_reopened = true;
    trace.reopen.all_entries_rehashed = true;
    refresh_reopen(trace);

    trace.claim.present = true;
    trace.claim.durable = true;
    trace.claim.exact_prior_output_set_claimed = true;
    trace.claim.child_products_outside_subject = true;
    trace.claim.no_self_digest_transform_claimed = true;
    refresh_claim(trace);
    refresh_cuts(trace);
    return trace;
}

[[nodiscard]] OutputClosureTrace at_stage(const OutputClosureTrace& complete, const std::size_t stage) {
    OutputClosureTrace trace = complete;
    if (stage < 4U) trace.claim = {};
    if (stage < 3U) trace.reopen = {};
    if (stage < 2U) trace.publication = {};
    if (stage < 1U) trace.manifest = {};
    refresh_cuts(trace);
    return trace;
}

void add_case(std::vector<Case>& cases, const std::string& name, OutputClosureTrace trace, const ClosureCode expected) {
    cases.push_back(Case{name, std::move(trace), expected});
}

[[nodiscard]] std::vector<Case> corpus() {
    const OutputClosureTrace good = baseline();
    std::vector<Case> cases;
    add_case(cases, "prior_output_set_durable", at_stage(good, 0U), ClosureCode::accepted_prior_output_durable);
    add_case(cases, "manifest_durable", at_stage(good, 1U), ClosureCode::accepted_manifest_durable);
    add_case(cases, "publication_durable", at_stage(good, 2U), ClosureCode::accepted_publication_durable);
    add_case(cases, "hosted_reopener_durable", at_stage(good, 3U), ClosureCode::accepted_reopen_durable);
    add_case(cases, "closed_exact_prior_output_set", good, ClosureCode::accepted_closed_output_set);

    {
        auto t = good; t.parent.parent.graph.graph_digest = {};
        add_case(cases, "parent_relation_rejected", t, ClosureCode::parent_rejected);
    }
    {
        auto t = good;
        t.parent.relocated_observation.physical_locator_digest = t.parent.first_observation.physical_locator_digest;
        refresh_parent_observation(t.parent.relocated_observation, t.parent);
        refresh_parent_receipt(t.parent.relocated_receipt, t.parent.relocated_observation, t.parent);
        refresh_parent_cuts(t.parent);
        refresh_from_manifest(t);
        add_case(cases, "parent_has_no_relocation_witness", t, ClosureCode::parent_not_relocated_exact_subject);
    }
    {
        auto t = good; t.manifest.parent_relocated_receipt_digest = digest("wrong-parent-receipt"); refresh_from_manifest(t);
        add_case(cases, "manifest_wrong_parent_receipt", t, ClosureCode::parent_binding_mismatch);
    }
    {
        auto t = good; t.manifest.parent_build_claim_digest = digest("wrong-parent-claim"); refresh_from_manifest(t);
        add_case(cases, "manifest_wrong_parent_claim", t, ClosureCode::parent_binding_mismatch);
    }
    {
        auto t = good; t.manifest.parent_provenance_output_digest = digest("wrong-parent-output-contract"); refresh_from_manifest(t);
        add_case(cases, "manifest_wrong_parent_output_contract", t, ClosureCode::parent_binding_mismatch);
    }

    for (std::size_t i = 0U; i < 7U; ++i) {
        auto t = good;
        if (i == 0U) t.manifest.canonical = false;
        if (i == 1U) t.manifest.exact_prior_set = false;
        if (i == 2U) t.manifest.complete = false;
        if (i == 3U) t.manifest.reserved_namespace_excluded = false;
        if (i == 4U) t.manifest.entry_count = 14U;
        if (i == 5U) t.manifest.entries[15] = output_entry("UNUSED.bin", digest("unused"), 1U, output_mode_read_only);
        if (i == 6U) t.manifest.manifest_digest = {};
        if (i != 6U) refresh_from_manifest(t); else { refresh_publication(t); refresh_reopen(t); refresh_claim(t); refresh_cuts(t); }
        add_case(cases, "manifest_shape_invalid_" + std::to_string(i), t, ClosureCode::manifest_shape_invalid);
    }

    const std::array<std::string_view, 7U> bad_paths{{
        "/ABSOLUTE.bin", "A/", "A\\B.bin", "A//B.bin", "A/../B.bin", "./A.bin", "A/./B.bin",
    }};
    for (std::size_t i = 0U; i < bad_paths.size(); ++i) {
        auto t = good; set_output_path(t.manifest.entries[0], bad_paths[i]); refresh_from_manifest(t);
        add_case(cases, "invalid_output_path_" + std::to_string(i), t, ClosureCode::output_path_invalid);
    }
    {
        auto t = good; t.manifest.entries[1] = t.manifest.entries[0]; refresh_from_manifest(t);
        add_case(cases, "duplicate_output_path", t, ClosureCode::output_path_duplicate);
    }
    {
        auto t = good; std::swap(t.manifest.entries[0], t.manifest.entries[1]); refresh_from_manifest(t);
        add_case(cases, "output_path_order_wrong", t, ClosureCode::output_path_order_invalid);
    }
    for (std::size_t i = 0U; i < 6U; ++i) {
        auto t = good;
        if (i == 0U) t.manifest.entries[0].present = false;
        if (i == 1U) t.manifest.entries[0].regular_file = false;
        if (i == 2U) t.manifest.entries[0].reserved_namespace = true;
        if (i == 3U) t.manifest.entries[0].content_digest = {};
        if (i == 4U) t.manifest.entries[0].bytes = 0U;
        if (i == 5U) t.manifest.entries[0].mode = 0644U;
        refresh_from_manifest(t);
        add_case(cases, "output_entry_invalid_" + std::to_string(i), t, ClosureCode::output_entry_invalid);
    }
    {
        auto t = good; set_output_path(t.manifest.entries[8], "OUTPUT-CLOSURE-CLAIM.bin"); refresh_from_manifest(t);
        add_case(cases, "closure_claim_inside_subject", t, ClosureCode::reserved_namespace_in_subject);
    }
    {
        auto t = good; set_output_path(t.manifest.entries[14], "closure/self.bin"); refresh_from_manifest(t);
        add_case(cases, "reserved_prefix_inside_subject", t, ClosureCode::reserved_namespace_in_subject);
    }
    {
        auto t = good; t.manifest.reserved_namespace_policy_digest = digest("different-reserved-policy"); refresh_from_manifest(t);
        add_case(cases, "reserved_policy_identity_wrong", t, ClosureCode::self_reference_policy_mismatch);
    }
    {
        auto t = good; t.manifest.entries[2].content_digest = digest("different-cases"); refresh_from_manifest(t);
        add_case(cases, "parent_output_content_substituted", t, ClosureCode::output_set_not_exact_parent);
    }
    {
        auto t = good; ++t.manifest.entries[2].bytes; refresh_from_manifest(t);
        add_case(cases, "parent_output_size_substituted", t, ClosureCode::output_set_not_exact_parent);
    }
    {
        auto t = good; t.manifest.entries[2].mode = output_mode_read_execute; refresh_from_manifest(t);
        add_case(cases, "parent_output_mode_substituted", t, ClosureCode::output_set_not_exact_parent);
    }
    {
        auto t = good; set_output_path(t.manifest.entries[2], "CASES2.tsv"); refresh_from_manifest(t);
        add_case(cases, "parent_output_path_substituted", t, ClosureCode::output_set_not_exact_parent);
    }
    {
        auto t = good; t.manifest.parent_output_carrier_digest = digest("different-carrier"); refresh_from_manifest(t);
        add_case(cases, "parent_output_carrier_substituted", t, ClosureCode::output_set_not_exact_parent);
    }
    {
        auto t = good; t.manifest.manifest_digest[0] ^= 1U;
        add_case(cases, "manifest_identity_wrong", t, ClosureCode::manifest_digest_mismatch);
    }

    for (std::size_t i = 0U; i < 6U; ++i) {
        auto t = good;
        if (i == 0U) t.publication.durable = false;
        if (i == 1U) t.publication.no_replace_publication = false;
        if (i == 2U) t.publication.single_view_reopened = false;
        if (i == 3U) t.publication.exact_carrier_published = false;
        if (i == 4U) ++t.publication.carrier_bytes;
        if (i == 5U) t.publication.receipt_digest = {};
        if (i != 5U) refresh_from_publication(t); else { refresh_reopen(t); refresh_claim(t); refresh_cuts(t); }
        add_case(cases, "publication_shape_invalid_" + std::to_string(i), t, ClosureCode::publication_shape_invalid);
    }
    for (std::size_t i = 0U; i < 3U; ++i) {
        auto t = good;
        if (i == 0U) t.publication.manifest_digest = digest("other-manifest");
        if (i == 1U) t.publication.parent_relocated_receipt_digest = digest("other-parent-receipt");
        if (i == 2U) t.publication.parent_output_carrier_digest = digest("other-carrier");
        t.publication.receipt_digest = publication_receipt_identity(t.publication);
        refresh_reopen(t); refresh_claim(t); refresh_cuts(t);
        add_case(cases, "publication_binding_invalid_" + std::to_string(i), t, ClosureCode::publication_binding_mismatch);
    }
    {
        auto t = good; t.publication.receipt_digest[0] ^= 1U;
        add_case(cases, "publication_identity_wrong", t, ClosureCode::publication_digest_mismatch);
    }

    for (std::size_t i = 0U; i < 6U; ++i) {
        auto t = good;
        if (i == 0U) t.reopen.durable = false;
        if (i == 1U) t.reopen.separate_reopener_role = false;
        if (i == 2U) t.reopen.exact_manifest_reopened = false;
        if (i == 3U) t.reopen.all_entries_rehashed = false;
        if (i == 4U) ++t.reopen.carrier_bytes;
        if (i == 5U) t.reopen.receipt_digest = {};
        if (i != 5U) refresh_from_reopen(t); else { refresh_claim(t); refresh_cuts(t); }
        add_case(cases, "reopen_shape_invalid_" + std::to_string(i), t, ClosureCode::reopen_shape_invalid);
    }
    for (std::size_t i = 0U; i < 5U; ++i) {
        auto t = good;
        if (i == 0U) t.reopen.publication_receipt_digest = digest("other-publication");
        if (i == 1U) t.reopen.manifest_digest = digest("other-manifest");
        if (i == 2U) t.reopen.parent_output_carrier_digest = digest("other-carrier");
        if (i == 3U) t.reopen.reopener_digest = t.publication.publisher_digest;
        if (i == 4U) t.reopen.reopener_implementation_digest = digest("other-hosted-reopener-implementation");
        t.reopen.receipt_digest = output_reopen_receipt_identity(t.reopen);
        refresh_claim(t); refresh_cuts(t);
        add_case(cases, "reopen_binding_invalid_" + std::to_string(i), t, ClosureCode::reopen_binding_mismatch);
    }
    {
        auto t = good; t.reopen.receipt_digest[0] ^= 1U;
        add_case(cases, "reopen_identity_wrong", t, ClosureCode::reopen_digest_mismatch);
    }

    for (std::size_t i = 0U; i < 6U; ++i) {
        auto t = good;
        if (i == 0U) t.claim.durable = false;
        if (i == 1U) t.claim.exact_prior_output_set_claimed = false;
        if (i == 2U) t.claim.child_products_outside_subject = false;
        if (i == 3U) t.claim.no_self_digest_transform_claimed = false;
        if (i == 4U) t.claim.present = false;
        if (i == 5U) t.claim.claim_digest = {};
        if (i < 4U) refresh_from_claim(t);
        else if (i == 4U) refresh_cuts(t);
        add_case(cases, "claim_shape_invalid_" + std::to_string(i), t,
            i == 4U ? ClosureCode::accepted_reopen_durable : ClosureCode::claim_shape_invalid);
    }
    for (std::size_t i = 0U; i < 6U; ++i) {
        auto t = good;
        if (i == 0U) t.claim.parent_relocated_receipt_digest = digest("other-parent-receipt");
        if (i == 1U) t.claim.parent_build_claim_digest = digest("other-parent-claim");
        if (i == 2U) t.claim.manifest_digest = digest("other-manifest");
        if (i == 3U) t.claim.publication_receipt_digest = digest("other-publication");
        if (i == 4U) t.claim.reopen_receipt_digest = digest("other-reopen");
        if (i == 5U) t.claim.reserved_namespace_policy_digest = digest("other-policy");
        t.claim.claim_digest = output_closure_claim_identity(t.claim); refresh_cuts(t);
        add_case(cases, "claim_binding_invalid_" + std::to_string(i), t, ClosureCode::claim_binding_mismatch);
    }
    {
        auto t = good; t.claim.claim_digest[0] ^= 1U;
        add_case(cases, "claim_identity_wrong", t, ClosureCode::claim_digest_mismatch);
    }

    {
        auto t = good; t.manifest = {};
        refresh_cuts(t);
        add_case(cases, "publication_without_manifest", t, ClosureCode::publication_without_manifest);
    }
    {
        auto t = good; t.publication = {};
        refresh_cuts(t);
        add_case(cases, "reopen_without_publication", t, ClosureCode::reopen_without_publication);
    }
    {
        auto t = good; t.reopen = {};
        refresh_cuts(t);
        add_case(cases, "claim_without_reopen", t, ClosureCode::claim_without_reopen);
    }
    for (std::size_t i = 0U; i < output_cut_count; ++i) {
        auto t = good; t.cuts[i].parent_output_carrier_digest[0] ^= 1U;
        add_case(cases, "cut_order_invalid_" + std::to_string(i), t, ClosureCode::output_cut_order_invalid);
    }
    return cases;
}

template <std::size_t N>
[[nodiscard]] bool write_binary(const std::filesystem::path& path, const std::array<std::uint8_t, N>& bytes) {
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    output.write(reinterpret_cast<const char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
    return output.good();
}

[[nodiscard]] bool write_text(const std::filesystem::path& path, const std::string& text) {
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    output << text;
    return output.good();
}

[[nodiscard]] std::string output_path(const OutputEntry& entry) {
    return std::string(reinterpret_cast<const char*>(entry.path.data()), entry.path_length);
}

}  // namespace

bool run_campaign(const std::filesystem::path& output_directory) {
    std::error_code error;
    if (std::filesystem::exists(output_directory, error) || error) {
        std::cerr << "output directory must be absent\n";
        return false;
    }
    if (!std::filesystem::create_directory(output_directory, error) || error) {
        std::cerr << "cannot create output directory\n";
        return false;
    }

    const auto cases = corpus();
    const OutputClosureTrace good = baseline();
    std::size_t accepted = 0U;
    std::size_t rejected = 0U;
    std::size_t closure_ready = 0U;
    std::size_t disagreements = 0U;
    std::ostringstream case_rows;
    case_rows << "case\texpected\tcandidate\treference\taccepted\tclosure_ready\n";
    std::ostringstream countermodels;
    countermodels << "case\tcode\tboundary\n";

    for (const auto& item : cases) {
        const ClosureReport candidate = evaluate_candidate(item.trace);
        const ClosureReport reference = evaluate_reference(item.trace);
        if (candidate != reference) ++disagreements;
        if (candidate.code != item.expected || reference.code != item.expected) {
            std::cerr << "unexpected result case=" << item.name << " expected=" << closure_code_name(item.expected)
                      << " candidate=" << closure_code_name(candidate.code)
                      << " reference=" << closure_code_name(reference.code) << "\n";
            return false;
        }
        if (candidate.accepted) ++accepted; else ++rejected;
        if (candidate.closure_ready) ++closure_ready;
        case_rows << item.name << '\t' << closure_code_name(item.expected) << '\t'
                  << closure_code_name(candidate.code) << '\t' << closure_code_name(reference.code) << '\t'
                  << (candidate.accepted ? "true" : "false") << '\t'
                  << (candidate.closure_ready ? "true" : "false") << '\n';
        if (!candidate.accepted) countermodels << item.name << '\t' << closure_code_name(candidate.code)
            << "\tclaim does not cross this boundary\n";
    }
    if (disagreements != 0U) {
        std::cerr << "candidate/reference disagreement count=" << disagreements << "\n";
        return false;
    }

    std::ostringstream cuts;
    cuts << "case\tcut\tcut_name\tcandidate\treference\taccepted\tclosure_ready\n";
    std::size_t cut_rows = 0U;
    for (const auto& item : cases) {
        for (std::size_t cut = 0U; cut < output_cut_count; ++cut) {
            OutputClosureTrace projected = item.trace;
            if (cut < 4U) projected.claim = {};
            if (cut < 3U) projected.reopen = {};
            if (cut < 2U) projected.publication = {};
            if (cut < 1U) projected.manifest = {};
            refresh_cuts(projected);
            const ClosureReport candidate = evaluate_candidate(projected);
            const ClosureReport reference = evaluate_reference(projected);
            if (candidate != reference) {
                std::cerr << "cut disagreement case=" << item.name << " cut=" << cut << "\n";
                return false;
            }
            cuts << item.name << '\t' << cut << '\t' << output_cut_name(cut) << '\t'
                 << closure_code_name(candidate.code) << '\t' << closure_code_name(reference.code) << '\t'
                 << (candidate.accepted ? "true" : "false") << '\t'
                 << (candidate.closure_ready ? "true" : "false") << '\n';
            ++cut_rows;
        }
    }

    EncodedOutputManifest manifest_bytes{};
    EncodedPublicationReceipt publication_bytes{};
    EncodedOutputReopenReceipt reopen_bytes{};
    EncodedOutputClosureClaim claim_bytes{};
    if (!encode_output_manifest(good.manifest, manifest_bytes)
        || !encode_publication_receipt(good.publication, publication_bytes)
        || !encode_output_reopen_receipt(good.reopen, reopen_bytes)
        || !encode_output_closure_claim(good.claim, claim_bytes)) {
        std::cerr << "canonical encoding failed\n";
        return false;
    }

    std::ostringstream entries;
    entries << "path\tbytes\tsha256\tmode\treserved\n";
    for (std::size_t index = 0U; index < good.manifest.entry_count; ++index) {
        const auto& entry = good.manifest.entries[index];
        entries << output_path(entry) << '\t' << entry.bytes << '\t' << hex(entry.content_digest) << '\t'
                << std::oct << std::setw(4) << std::setfill('0') << entry.mode << std::dec << std::setfill(' ')
                << "\tfalse\n";
    }

    std::ostringstream identities;
    identities << "object\tbytes\tsha256\n"
        << "OUTPUT-SET-MANIFEST.bin\t" << manifest_bytes.size() << '\t' << hex(good.manifest.manifest_digest) << '\n'
        << "MANIFEST-PUBLICATION-RECEIPT.bin\t" << publication_bytes.size() << '\t' << hex(good.publication.receipt_digest) << '\n'
        << "OUTPUT-SET-REOPEN-RECEIPT.bin\t" << reopen_bytes.size() << '\t' << hex(good.reopen.receipt_digest) << '\n'
        << "OUTPUT-CLOSURE-CLAIM.bin\t" << claim_bytes.size() << '\t' << hex(good.claim.claim_digest) << '\n';

    const std::string laws =
        "law\tstatement\n"
        "L1\tThe exact prior output set is an already-durable object before its manifest.\n"
        "L2\tThe manifest binds the exact parent relocated receipt, build claim, output contract, carrier, policy, and fifteen entries.\n"
        "L3\tEntry paths are portable, ordered, unique, exact, and regular-file typed.\n"
        "L4\tThe closure receipt namespace is outside the identified prior output set.\n"
        "L5\tNo self-reference transform is silently assumed.\n"
        "L6\tPublication follows manifest durability and uses no-replace plus single-view reopen.\n"
        "L7\tA separate hosted reopener role follows publication and binds every exact entry.\n"
        "L8\tThe reopen receipt binds the exact hosted reopener implementation bytes.\n"
        "L9\tThe closure claim follows hosted reopen and binds all predecessor objects.\n"
        "L10\tEvery valid crash prefix is resumable without pretending a later object already exists.\n"
        "L11\tChild evidence products remain outside the child theorem subject.\n"
        "L12\tObserved output closure does not prove source truth, world dependency closure, or trusted builder control.\n"
        "L13\tExact reopener implementation identity does not prove administrative independence, owner admission, authority, or Epoch-Zero exit.\n";

    std::ostringstream summary;
    summary << "metric\tvalue\n"
        << "cases\t" << cases.size() << '\n'
        << "accepted_classifications\t" << accepted << '\n'
        << "rejected_classifications\t" << rejected << '\n'
        << "closure_ready_cases\t" << closure_ready << '\n'
        << "lifecycle_cut_rows\t" << cut_rows << '\n'
        << "durable_stages\t" << output_cut_count << '\n'
        << "parent_output_entries\t" << expected_parent_output_entries << '\n'
        << "parent_output_carrier_bytes\t" << SLOPOS_OOC_PARENT_OUTPUT_CARRIER_BYTES << '\n'
        << "canonical_exact_object_bytes\t2560\n"
        << "candidate_reference_disagreements\t0\n"
        << "self_reference_transform_claimed\tfalse\n"
        << "child_products_inside_subject\tfalse\n"
        << "authority_granted\tfalse\n"
        << "epoch_exit_proved\tfalse\n";

    std::ostringstream report;
    report << "OBSERVED_OUTPUT_CLOSURE=PASS\n"
        << "cases=" << cases.size() << " accepted=" << accepted << " rejected=" << rejected
        << " cuts=" << cut_rows << " closure_ready=" << closure_ready << "\n"
        << "parent_entries=" << expected_parent_output_entries
        << " carrier_bytes=" << SLOPOS_OOC_PARENT_OUTPUT_CARRIER_BYTES
        << " exact_objects=2560\n"
        << "candidate_reference_disagreements=0 reopener_implementation_bound=true self_reference_transform=false child_products_outside_subject=true\n"
        << "source_authenticity=false trusted_builder=false external_occurrence=false administrative_independence=false authority=false epoch_exit=false\n";

    const bool written = write_binary(output_directory / "OUTPUT-SET-MANIFEST.bin", manifest_bytes)
        && write_binary(output_directory / "MANIFEST-PUBLICATION-RECEIPT.bin", publication_bytes)
        && write_binary(output_directory / "OUTPUT-SET-REOPEN-RECEIPT.bin", reopen_bytes)
        && write_binary(output_directory / "OUTPUT-CLOSURE-CLAIM.bin", claim_bytes)
        && write_text(output_directory / "OUTPUT-ENTRIES.tsv", entries.str())
        && write_text(output_directory / "CASES.tsv", case_rows.str())
        && write_text(output_directory / "CUTS.tsv", cuts.str())
        && write_text(output_directory / "IDENTITIES.tsv", identities.str())
        && write_text(output_directory / "LAWS.tsv", laws)
        && write_text(output_directory / "COUNTERMODELS.tsv", countermodels.str())
        && write_text(output_directory / "SUMMARY.tsv", summary.str())
        && write_text(output_directory / "REPORT.txt", report.str());
    if (!written) return false;
    std::cout << report.str();
    return true;
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification::relocatable_provenance::observed_output_closure
