#include "slopos/e0/signed_admission/root_succession.hpp"

#include <algorithm>
#include <array>
#include <limits>
#include <span>
#include <string_view>
#include <vector>

#include <openssl/evp.h>

namespace slopos::e0::signed_admission::root_succession {
namespace {

constexpr std::array<std::uint8_t, 8U> kStatementMagic{{'S','L','O','P','R','S','0','1'}};
constexpr std::array<std::uint8_t, 8U> kEnvelopeMagic{{'S','L','O','P','R','E','0','1'}};
constexpr std::array<std::uint8_t, 8U> kReceiptMagic{{'S','L','O','P','R','R','0','1'}};
constexpr std::uint16_t kVersion = 1U;
constexpr std::uint16_t kStatementKind = 4U;
constexpr std::uint16_t kEnvelopeKind = 5U;
constexpr std::uint16_t kReceiptKind = 6U;
constexpr std::uint8_t kPurpose = 1U;
constexpr std::uint8_t kEd25519Suite = 1U;
constexpr std::string_view kStatementIntegrityDomain =
    "SlopOS/root-succession/statement-integrity/v1";
constexpr std::string_view kStatementHeadDomain =
    "SlopOS/root-succession/statement-head/v1";
constexpr std::string_view kEnvelopeIntegrityDomain =
    "SlopOS/root-succession/envelope-integrity/v1";
constexpr std::string_view kReceiptIntegrityDomain =
    "SlopOS/root-succession/receipt-integrity/v1";
constexpr std::string_view kSigningDomain = "SlopOS/root-succession/v1/DTE";

[[nodiscard]] bool all_zero(const std::span<const std::uint8_t> bytes) noexcept {
    return std::all_of(bytes.begin(), bytes.end(), [](const std::uint8_t byte) {
        return byte == 0U;
    });
}

[[nodiscard]] bool nonzero(const Digest& value) noexcept {
    return !all_zero(value);
}

[[nodiscard]] bool nonzero(const Signature& value) noexcept {
    return !all_zero(value);
}

template <std::size_t N>
void put_u16(std::array<std::uint8_t, N>& output,
             const std::size_t offset,
             const std::uint16_t value) noexcept {
    output[offset] = static_cast<std::uint8_t>(value >> 8U);
    output[offset + 1U] = static_cast<std::uint8_t>(value);
}

template <std::size_t N>
void put_u32(std::array<std::uint8_t, N>& output,
             const std::size_t offset,
             const std::uint32_t value) noexcept {
    output[offset] = static_cast<std::uint8_t>(value >> 24U);
    output[offset + 1U] = static_cast<std::uint8_t>(value >> 16U);
    output[offset + 2U] = static_cast<std::uint8_t>(value >> 8U);
    output[offset + 3U] = static_cast<std::uint8_t>(value);
}

template <std::size_t N>
void put_u64(std::array<std::uint8_t, N>& output,
             const std::size_t offset,
             const std::uint64_t value) noexcept {
    for (std::size_t index = 0U; index < 8U; ++index) {
        const unsigned int shift = static_cast<unsigned int>((7U - index) * 8U);
        output[offset + index] = static_cast<std::uint8_t>(value >> shift);
    }
}

template <std::size_t N>
[[nodiscard]] std::uint16_t get_u16(
    const std::array<std::uint8_t, N>& input,
    const std::size_t offset) noexcept {
    return static_cast<std::uint16_t>(
        (static_cast<std::uint16_t>(input[offset]) << 8U)
        | static_cast<std::uint16_t>(input[offset + 1U]));
}

template <std::size_t N>
[[nodiscard]] std::uint32_t get_u32(
    const std::array<std::uint8_t, N>& input,
    const std::size_t offset) noexcept {
    return (static_cast<std::uint32_t>(input[offset]) << 24U)
        | (static_cast<std::uint32_t>(input[offset + 1U]) << 16U)
        | (static_cast<std::uint32_t>(input[offset + 2U]) << 8U)
        | static_cast<std::uint32_t>(input[offset + 3U]);
}

template <std::size_t N>
[[nodiscard]] std::uint64_t get_u64(
    const std::array<std::uint8_t, N>& input,
    const std::size_t offset) noexcept {
    std::uint64_t value = 0U;
    for (std::size_t index = 0U; index < 8U; ++index) {
        value = (value << 8U) | static_cast<std::uint64_t>(input[offset + index]);
    }
    return value;
}

template <std::size_t Out, std::size_t In>
void put_array(std::array<std::uint8_t, Out>& output,
               const std::size_t offset,
               const std::array<std::uint8_t, In>& value) noexcept {
    std::copy(value.begin(), value.end(),
              output.begin() + static_cast<std::ptrdiff_t>(offset));
}

template <std::size_t Count, std::size_t N>
[[nodiscard]] std::array<std::uint8_t, Count> get_array(
    const std::array<std::uint8_t, N>& input,
    const std::size_t offset) noexcept {
    std::array<std::uint8_t, Count> value{};
    std::copy_n(input.begin() + static_cast<std::ptrdiff_t>(offset),
                static_cast<std::ptrdiff_t>(Count), value.begin());
    return value;
}

[[nodiscard]] Digest domain_digest(
    const std::string_view domain,
    const std::span<const std::uint8_t> payload) {
    std::vector<std::uint8_t> bytes;
    bytes.reserve(domain.size() + 1U + payload.size());
    bytes.insert(bytes.end(), domain.begin(), domain.end());
    bytes.push_back(0U);
    bytes.insert(bytes.end(), payload.begin(), payload.end());
    return generation_journal::sha256(bytes);
}

[[nodiscard]] bool statement_invariant(
    const RootSuccessionStatementV1& value) noexcept {
    const std::array<const Digest*, 6U> digests{{
        &value.project_id,
        &value.predecessor_manifest_head,
        &value.successor_manifest_head,
        &value.precommitted_successor_head,
        &value.register_id,
        &value.ceremony_id,
    }};
    return std::all_of(digests.begin(), digests.end(), [](const Digest* digest) {
               return nonzero(*digest);
           })
        && value.predecessor_version != 0U
        && value.predecessor_version != std::numeric_limits<std::uint64_t>::max()
        && value.successor_version != 0U
        && value.not_before < value.expires_at
        && value.transition_nonce != 0U;
}

[[nodiscard]] bool receipt_invariant(
    const RootTransitionReceiptV1& value) noexcept {
    const auto raw = static_cast<std::uint8_t>(value.disposition);
    const bool disposition_valid = raw >= static_cast<std::uint8_t>(ReceiptDisposition::committed)
        && raw <= static_cast<std::uint8_t>(ReceiptDisposition::uncertain_after_commit_query_only);
    const bool query_consistent =
        (value.disposition == ReceiptDisposition::committed && !value.query_only)
        || (value.disposition != ReceiptDisposition::committed && value.query_only);
    return disposition_valid && query_consistent
        && nonzero(value.register_id)
        && nonzero(value.predecessor_manifest_head)
        && nonzero(value.successor_manifest_head)
        && nonzero(value.statement_head)
        && nonzero(value.ceremony_id)
        && value.predecessor_version != 0U
        && value.predecessor_version != std::numeric_limits<std::uint64_t>::max()
        && value.successor_version == value.predecessor_version + 1U
        && value.transition_ordinal != 0U
        && value.observed_time != 0U;
}

[[nodiscard]] bool verify_ed25519(
    const PublicKey& public_key,
    const Signature& signature,
    const RootSigningMessage& message) noexcept {
    EVP_PKEY* raw_key = EVP_PKEY_new_raw_public_key(
        EVP_PKEY_ED25519, nullptr, public_key.data(), public_key.size());
    if (raw_key == nullptr) return false;
    EVP_MD_CTX* context = EVP_MD_CTX_new();
    if (context == nullptr) {
        EVP_PKEY_free(raw_key);
        return false;
    }
    const int initialized = EVP_DigestVerifyInit(
        context, nullptr, nullptr, nullptr, raw_key);
    const int verified = initialized == 1
        ? EVP_DigestVerify(context,
                           signature.data(), signature.size(),
                           message.data(), message.size())
        : 0;
    EVP_MD_CTX_free(context);
    EVP_PKEY_free(raw_key);
    return verified == 1;
}

[[nodiscard]] EvidenceReport stopped(
    const EvidenceCode code,
    const EvidenceReport& partial) noexcept {
    EvidenceReport report = partial;
    report.code = code;
    report.valid = false;
    report.owner_constitution_proved = false;
    report.currentness_proved = false;
    report.independent_custody_proved = false;
    report.protected_transition_proved = false;
    report.independent_reopen_proved = false;
    report.epoch_exit_proved = false;
    report.authority_granted = false;
    return report;
}

struct ThresholdOutcome final {
    bool valid{false};
    std::size_t verified{0U};
    EvidenceCode code{EvidenceCode::predecessor_below_threshold};
};

[[nodiscard]] ThresholdOutcome verify_threshold(
    const OwnerManifestV1& manifest,
    const std::array<SignatureSlotV1, kMaximumKeys>& signatures,
    const std::uint8_t signature_count,
    const RootSigningMessage& message,
    const bool predecessor) {
    ThresholdOutcome result;
    result.code = predecessor
        ? EvidenceCode::predecessor_below_threshold
        : EvidenceCode::successor_below_threshold;
    std::array<Digest, kMaximumKeys> observed_ids{};
    for (std::size_t index = 0U; index < signature_count; ++index) {
        const SignatureSlotV1& slot = signatures[index];
        for (std::size_t earlier = 0U; earlier < index; ++earlier) {
            if (observed_ids[earlier] == slot.key_id) {
                result.code = predecessor
                    ? EvidenceCode::predecessor_duplicate_signer
                    : EvidenceCode::successor_duplicate_signer;
                return result;
            }
        }
        observed_ids[index] = slot.key_id;
        const auto end = manifest.keys.begin()
            + static_cast<std::ptrdiff_t>(manifest.key_count);
        const auto key = std::find_if(
            manifest.keys.begin(), end,
            [&slot](const KeyV1& item) { return item.key_id == slot.key_id; });
        if (key == end) {
            result.code = predecessor
                ? EvidenceCode::predecessor_unknown_signer
                : EvidenceCode::successor_unknown_signer;
            return result;
        }
        if (!verify_ed25519(key->public_key, slot.signature, message)) {
            result.code = predecessor
                ? EvidenceCode::predecessor_invalid_signature
                : EvidenceCode::successor_invalid_signature;
            return result;
        }
        ++result.verified;
    }
    if (result.verified < manifest.threshold) return result;
    result.valid = true;
    return result;
}

[[nodiscard]] ApplyReport stopped_apply(
    const ApplyCode code,
    const EvidenceReport& evidence) noexcept {
    ApplyReport report;
    report.code = code;
    report.evidence = evidence;
    report.owner_constitution_proved = false;
    report.currentness_proved = false;
    report.independent_custody_proved = false;
    report.protected_transition_proved = false;
    report.independent_reopen_proved = false;
    report.epoch_exit_proved = false;
    report.authority_granted = false;
    return report;
}

[[nodiscard]] bool make_receipt(
    const RootSuccessionStatementV1& statement,
    const EncodedRootStatement& statement_bytes,
    const std::uint64_t ordinal,
    const std::uint64_t observed_time,
    const ReceiptDisposition disposition,
    EncodedRootReceipt& output) {
    RootTransitionReceiptV1 receipt;
    receipt.disposition = disposition;
    receipt.query_only = disposition != ReceiptDisposition::committed;
    receipt.register_id = statement.register_id;
    receipt.predecessor_manifest_head = statement.predecessor_manifest_head;
    receipt.successor_manifest_head = statement.successor_manifest_head;
    receipt.statement_head = root_statement_head(statement_bytes);
    receipt.ceremony_id = statement.ceremony_id;
    receipt.predecessor_version = statement.predecessor_version;
    receipt.successor_version = statement.successor_version;
    receipt.transition_ordinal = ordinal;
    receipt.observed_time = observed_time;
    return encode_root_receipt(receipt, output);
}

}  // namespace

Digest root_statement_head(const EncodedRootStatement& statement) {
    return domain_digest(kStatementHeadDomain, statement);
}

bool encode_root_statement(
    const RootSuccessionStatementV1& value,
    EncodedRootStatement& output) {
    if (!statement_invariant(value)) return false;
    output.fill(0U);
    std::copy(kStatementMagic.begin(), kStatementMagic.end(), output.begin());
    put_u16(output, 8U, kVersion);
    put_u16(output, 10U, kStatementKind);
    put_u32(output, 12U, static_cast<std::uint32_t>(kRootStatementBytes));
    output[16U] = kPurpose;
    output[17U] = kEd25519Suite;
    put_array(output, 32U, value.project_id);
    put_array(output, 64U, value.predecessor_manifest_head);
    put_array(output, 96U, value.successor_manifest_head);
    put_array(output, 128U, value.precommitted_successor_head);
    put_array(output, 160U, value.register_id);
    put_array(output, 192U, value.ceremony_id);
    put_u64(output, 224U, value.predecessor_version);
    put_u64(output, 232U, value.successor_version);
    put_u64(output, 240U, value.not_before);
    put_u64(output, 248U, value.expires_at);
    put_u64(output, 256U, value.transition_nonce);
    const Digest integrity = domain_digest(
        kStatementIntegrityDomain,
        std::span<const std::uint8_t>(output.data(), 288U));
    put_array(output, 288U, integrity);
    return true;
}

bool decode_root_statement(
    const EncodedRootStatement& input,
    RootSuccessionStatementV1& output) {
    if (!std::equal(kStatementMagic.begin(), kStatementMagic.end(), input.begin())
        || get_u16(input, 8U) != kVersion
        || get_u16(input, 10U) != kStatementKind
        || get_u32(input, 12U) != kRootStatementBytes
        || input[16U] != kPurpose
        || input[17U] != kEd25519Suite
        || !all_zero(std::span<const std::uint8_t>(input.data() + 18U, 14U))
        || !all_zero(std::span<const std::uint8_t>(input.data() + 264U, 24U))) {
        return false;
    }
    const Digest expected = domain_digest(
        kStatementIntegrityDomain,
        std::span<const std::uint8_t>(input.data(), 288U));
    if (get_array<32U>(input, 288U) != expected) return false;
    RootSuccessionStatementV1 value;
    value.project_id = get_array<32U>(input, 32U);
    value.predecessor_manifest_head = get_array<32U>(input, 64U);
    value.successor_manifest_head = get_array<32U>(input, 96U);
    value.precommitted_successor_head = get_array<32U>(input, 128U);
    value.register_id = get_array<32U>(input, 160U);
    value.ceremony_id = get_array<32U>(input, 192U);
    value.predecessor_version = get_u64(input, 224U);
    value.successor_version = get_u64(input, 232U);
    value.not_before = get_u64(input, 240U);
    value.expires_at = get_u64(input, 248U);
    value.transition_nonce = get_u64(input, 256U);
    if (!statement_invariant(value)) return false;
    output = value;
    return true;
}

bool encode_root_envelope(
    const DualThresholdEnvelopeV1& value,
    EncodedRootEnvelope& output) {
    RootSuccessionStatementV1 statement;
    if (value.predecessor_signature_count == 0U
        || value.predecessor_signature_count > kMaximumKeys
        || value.successor_signature_count == 0U
        || value.successor_signature_count > kMaximumKeys
        || !decode_root_statement(value.statement, statement)) {
        return false;
    }
    const auto slots_valid = [](const auto& signatures, const std::uint8_t count) {
        for (std::size_t index = 0U; index < kMaximumKeys; ++index) {
            if (index < count) {
                if (!nonzero(signatures[index].key_id)
                    || !nonzero(signatures[index].signature)) {
                    return false;
                }
            } else if (!all_zero(signatures[index].key_id)
                       || !all_zero(signatures[index].signature)) {
                return false;
            }
        }
        return true;
    };
    if (!slots_valid(value.predecessor_signatures, value.predecessor_signature_count)
        || !slots_valid(value.successor_signatures, value.successor_signature_count)) {
        return false;
    }
    output.fill(0U);
    std::copy(kEnvelopeMagic.begin(), kEnvelopeMagic.end(), output.begin());
    put_u16(output, 8U, kVersion);
    put_u16(output, 10U, kEnvelopeKind);
    put_u32(output, 12U, static_cast<std::uint32_t>(kRootEnvelopeBytes));
    output[16U] = value.predecessor_signature_count;
    output[17U] = value.successor_signature_count;
    output[18U] = kEd25519Suite;
    put_array(output, 32U, value.statement);
    for (std::size_t index = 0U; index < kMaximumKeys; ++index) {
        const std::size_t predecessor_base = 352U + index * 96U;
        put_array(output, predecessor_base, value.predecessor_signatures[index].key_id);
        put_array(output, predecessor_base + 32U,
                  value.predecessor_signatures[index].signature);
        const std::size_t successor_base = 640U + index * 96U;
        put_array(output, successor_base, value.successor_signatures[index].key_id);
        put_array(output, successor_base + 32U,
                  value.successor_signatures[index].signature);
    }
    const Digest integrity = domain_digest(
        kEnvelopeIntegrityDomain,
        std::span<const std::uint8_t>(output.data(), 992U));
    put_array(output, 992U, integrity);
    return true;
}

bool decode_root_envelope(
    const EncodedRootEnvelope& input,
    DualThresholdEnvelopeV1& output) {
    if (!std::equal(kEnvelopeMagic.begin(), kEnvelopeMagic.end(), input.begin())
        || get_u16(input, 8U) != kVersion
        || get_u16(input, 10U) != kEnvelopeKind
        || get_u32(input, 12U) != kRootEnvelopeBytes
        || input[18U] != kEd25519Suite
        || !all_zero(std::span<const std::uint8_t>(input.data() + 19U, 13U))
        || !all_zero(std::span<const std::uint8_t>(input.data() + 928U, 64U))) {
        return false;
    }
    const Digest expected = domain_digest(
        kEnvelopeIntegrityDomain,
        std::span<const std::uint8_t>(input.data(), 992U));
    if (get_array<32U>(input, 992U) != expected) return false;
    DualThresholdEnvelopeV1 value;
    value.predecessor_signature_count = input[16U];
    value.successor_signature_count = input[17U];
    if (value.predecessor_signature_count == 0U
        || value.predecessor_signature_count > kMaximumKeys
        || value.successor_signature_count == 0U
        || value.successor_signature_count > kMaximumKeys) {
        return false;
    }
    value.statement = get_array<kRootStatementBytes>(input, 32U);
    RootSuccessionStatementV1 statement;
    if (!decode_root_statement(value.statement, statement)) return false;
    for (std::size_t index = 0U; index < kMaximumKeys; ++index) {
        const std::size_t predecessor_base = 352U + index * 96U;
        value.predecessor_signatures[index].key_id =
            get_array<32U>(input, predecessor_base);
        value.predecessor_signatures[index].signature =
            get_array<64U>(input, predecessor_base + 32U);
        const std::size_t successor_base = 640U + index * 96U;
        value.successor_signatures[index].key_id =
            get_array<32U>(input, successor_base);
        value.successor_signatures[index].signature =
            get_array<64U>(input, successor_base + 32U);
        if (index < value.predecessor_signature_count) {
            if (!nonzero(value.predecessor_signatures[index].key_id)
                || !nonzero(value.predecessor_signatures[index].signature)) {
                return false;
            }
        } else if (!all_zero(value.predecessor_signatures[index].key_id)
                   || !all_zero(value.predecessor_signatures[index].signature)) {
            return false;
        }
        if (index < value.successor_signature_count) {
            if (!nonzero(value.successor_signatures[index].key_id)
                || !nonzero(value.successor_signatures[index].signature)) {
                return false;
            }
        } else if (!all_zero(value.successor_signatures[index].key_id)
                   || !all_zero(value.successor_signatures[index].signature)) {
            return false;
        }
    }
    output = value;
    return true;
}

RootSigningMessage root_signing_message_for(
    const EncodedRootStatement& statement) {
    RootSigningMessage message{};
    std::copy(kSigningDomain.begin(), kSigningDomain.end(), message.begin());
    put_u64(message, 32U, static_cast<std::uint64_t>(statement.size()));
    put_array(message, 40U, statement);
    return message;
}

bool encode_root_receipt(
    const RootTransitionReceiptV1& value,
    EncodedRootReceipt& output) {
    if (!receipt_invariant(value)) return false;
    output.fill(0U);
    std::copy(kReceiptMagic.begin(), kReceiptMagic.end(), output.begin());
    put_u16(output, 8U, kVersion);
    put_u16(output, 10U, kReceiptKind);
    put_u32(output, 12U, static_cast<std::uint32_t>(kRootReceiptBytes));
    output[16U] = static_cast<std::uint8_t>(value.disposition);
    output[17U] = value.query_only ? 1U : 0U;
    put_array(output, 32U, value.register_id);
    put_array(output, 64U, value.predecessor_manifest_head);
    put_array(output, 96U, value.successor_manifest_head);
    put_array(output, 128U, value.statement_head);
    put_array(output, 160U, value.ceremony_id);
    put_u64(output, 192U, value.predecessor_version);
    put_u64(output, 200U, value.successor_version);
    put_u64(output, 208U, value.transition_ordinal);
    put_u64(output, 216U, value.observed_time);
    const Digest integrity = domain_digest(
        kReceiptIntegrityDomain,
        std::span<const std::uint8_t>(output.data(), 224U));
    put_array(output, 224U, integrity);
    return true;
}

bool decode_root_receipt(
    const EncodedRootReceipt& input,
    RootTransitionReceiptV1& output) {
    if (!std::equal(kReceiptMagic.begin(), kReceiptMagic.end(), input.begin())
        || get_u16(input, 8U) != kVersion
        || get_u16(input, 10U) != kReceiptKind
        || get_u32(input, 12U) != kRootReceiptBytes
        || input[17U] > 1U
        || !all_zero(std::span<const std::uint8_t>(input.data() + 18U, 14U))) {
        return false;
    }
    const Digest expected = domain_digest(
        kReceiptIntegrityDomain,
        std::span<const std::uint8_t>(input.data(), 224U));
    if (get_array<32U>(input, 224U) != expected) return false;
    RootTransitionReceiptV1 value;
    value.disposition = static_cast<ReceiptDisposition>(input[16U]);
    value.query_only = input[17U] == 1U;
    value.register_id = get_array<32U>(input, 32U);
    value.predecessor_manifest_head = get_array<32U>(input, 64U);
    value.successor_manifest_head = get_array<32U>(input, 96U);
    value.statement_head = get_array<32U>(input, 128U);
    value.ceremony_id = get_array<32U>(input, 160U);
    value.predecessor_version = get_u64(input, 192U);
    value.successor_version = get_u64(input, 200U);
    value.transition_ordinal = get_u64(input, 208U);
    value.observed_time = get_u64(input, 216U);
    if (!receipt_invariant(value)) return false;
    output = value;
    return true;
}

EvidenceReport validate_candidate(
    const EncodedManifest& predecessor_manifest_bytes,
    const EncodedManifest& successor_manifest_bytes,
    const EncodedRootEnvelope& envelope_bytes,
    const std::uint64_t observed_time) {
    EvidenceReport report;
    OwnerManifestV1 predecessor_manifest;
    if (!decode_manifest(predecessor_manifest_bytes, predecessor_manifest)) {
        return stopped(EvidenceCode::invalid_predecessor_manifest, report);
    }
    report.predecessor_manifest_valid = true;
    OwnerManifestV1 successor_manifest;
    if (!decode_manifest(successor_manifest_bytes, successor_manifest)) {
        return stopped(EvidenceCode::invalid_successor_manifest, report);
    }
    report.successor_manifest_valid = true;
    DualThresholdEnvelopeV1 envelope;
    if (!decode_root_envelope(envelope_bytes, envelope)) {
        return stopped(EvidenceCode::invalid_envelope, report);
    }
    RootSuccessionStatementV1 statement;
    if (!decode_root_statement(envelope.statement, statement)) {
        return stopped(EvidenceCode::invalid_statement, report);
    }
    report.statement_valid = true;
    if (predecessor_manifest.project_id != successor_manifest.project_id
        || statement.project_id != predecessor_manifest.project_id) {
        return stopped(EvidenceCode::project_mismatch, report);
    }
    const Digest predecessor_head = manifest_head(predecessor_manifest_bytes);
    const Digest successor_head = manifest_head(successor_manifest_bytes);
    if (successor_manifest.predecessor_manifest != predecessor_head) {
        return stopped(EvidenceCode::predecessor_chain_mismatch, report);
    }
    if (predecessor_manifest.version == std::numeric_limits<std::uint64_t>::max()
        || successor_manifest.version != predecessor_manifest.version + 1U
        || statement.predecessor_version != predecessor_manifest.version
        || statement.successor_version != successor_manifest.version) {
        return stopped(EvidenceCode::version_not_next, report);
    }
    report.exact_next_version = true;
    if (statement.predecessor_manifest_head != predecessor_head
        || statement.successor_manifest_head != successor_head) {
        return stopped(EvidenceCode::statement_binding_mismatch, report);
    }
    if (statement.precommitted_successor_head != successor_head) {
        return stopped(EvidenceCode::statement_precommit_mismatch, report);
    }
    report.precommit_bound = true;
    if (observed_time < statement.not_before || observed_time >= statement.expires_at) {
        return stopped(EvidenceCode::time_window_mismatch, report);
    }
    report.time_window_match = true;
    const RootSigningMessage message = root_signing_message_for(envelope.statement);
    const ThresholdOutcome predecessor = verify_threshold(
        predecessor_manifest,
        envelope.predecessor_signatures,
        envelope.predecessor_signature_count,
        message,
        true);
    report.predecessor_verified_signatures = predecessor.verified;
    if (!predecessor.valid) return stopped(predecessor.code, report);
    report.predecessor_threshold_met = true;
    const ThresholdOutcome successor = verify_threshold(
        successor_manifest,
        envelope.successor_signatures,
        envelope.successor_signature_count,
        message,
        false);
    report.successor_verified_signatures = successor.verified;
    if (!successor.valid) return stopped(successor.code, report);
    report.successor_threshold_met = true;
    report.code = EvidenceCode::evidence_valid;
    report.valid = true;
    report.owner_constitution_proved = false;
    report.currentness_proved = false;
    report.independent_custody_proved = false;
    report.protected_transition_proved = false;
    report.independent_reopen_proved = false;
    report.epoch_exit_proved = false;
    report.authority_granted = false;
    return report;
}

ApplyReport apply_candidate(
    CurrentRootRegisterV1& root_register,
    const EncodedManifest& predecessor_manifest,
    const EncodedManifest& successor_manifest,
    const EncodedRootEnvelope& envelope,
    const std::uint64_t observed_time,
    const ReplyCut reply_cut) {
    const EvidenceReport evidence = validate_candidate(
        predecessor_manifest, successor_manifest, envelope, observed_time);
    if (!evidence.valid) return stopped_apply(ApplyCode::invalid_evidence, evidence);
    DualThresholdEnvelopeV1 decoded_envelope;
    RootSuccessionStatementV1 statement;
    if (!decode_root_envelope(envelope, decoded_envelope)
        || !decode_root_statement(decoded_envelope.statement, statement)) {
        return stopped_apply(ApplyCode::invalid_evidence, evidence);
    }
    if (root_register.register_id != statement.register_id) {
        return stopped_apply(ApplyCode::register_id_mismatch, evidence);
    }
    if (root_register.current_manifest_head == statement.successor_manifest_head
        && root_register.current_version == statement.successor_version) {
        ApplyReport report = stopped_apply(
            ApplyCode::already_current_query_only, evidence);
        report.query_only = true;
        report.receipt_present = make_receipt(
            statement, decoded_envelope.statement,
            root_register.transition_ordinal,
            observed_time,
            ReceiptDisposition::already_current_query_only,
            report.receipt);
        return report;
    }
    if (root_register.current_manifest_head != statement.predecessor_manifest_head
        || root_register.current_version != statement.predecessor_version) {
        return stopped_apply(ApplyCode::stale_current, evidence);
    }
    if (root_register.precommitted_successor_head
        != statement.successor_manifest_head) {
        return stopped_apply(ApplyCode::register_precommit_mismatch, evidence);
    }
    if (root_register.transition_ordinal == std::numeric_limits<std::uint64_t>::max()) {
        return stopped_apply(ApplyCode::stale_current, evidence);
    }
    root_register.current_manifest_head = statement.successor_manifest_head;
    root_register.current_version = statement.successor_version;
    ++root_register.transition_ordinal;
    root_register.precommitted_successor_head = {};

    ApplyReport report = stopped_apply(
        reply_cut == ReplyCut::reply_delivered
            ? ApplyCode::committed
            : ApplyCode::uncertain_after_commit_query_only,
        evidence);
    report.committed = true;
    report.query_only = reply_cut == ReplyCut::reply_lost_after_commit;
    const ReceiptDisposition disposition = reply_cut == ReplyCut::reply_delivered
        ? ReceiptDisposition::committed
        : ReceiptDisposition::uncertain_after_commit_query_only;
    report.receipt_present = make_receipt(
        statement, decoded_envelope.statement,
        root_register.transition_ordinal,
        observed_time,
        disposition,
        report.receipt);
    return report;
}

std::string_view evidence_code_name(const EvidenceCode value) noexcept {
    switch (value) {
        case EvidenceCode::evidence_valid: return "evidence_valid";
        case EvidenceCode::invalid_predecessor_manifest: return "invalid_predecessor_manifest";
        case EvidenceCode::invalid_successor_manifest: return "invalid_successor_manifest";
        case EvidenceCode::invalid_envelope: return "invalid_envelope";
        case EvidenceCode::invalid_statement: return "invalid_statement";
        case EvidenceCode::project_mismatch: return "project_mismatch";
        case EvidenceCode::predecessor_chain_mismatch: return "predecessor_chain_mismatch";
        case EvidenceCode::version_not_next: return "version_not_next";
        case EvidenceCode::statement_binding_mismatch: return "statement_binding_mismatch";
        case EvidenceCode::statement_precommit_mismatch: return "statement_precommit_mismatch";
        case EvidenceCode::time_window_mismatch: return "time_window_mismatch";
        case EvidenceCode::predecessor_unknown_signer: return "predecessor_unknown_signer";
        case EvidenceCode::predecessor_duplicate_signer: return "predecessor_duplicate_signer";
        case EvidenceCode::predecessor_invalid_signature: return "predecessor_invalid_signature";
        case EvidenceCode::predecessor_below_threshold: return "predecessor_below_threshold";
        case EvidenceCode::successor_unknown_signer: return "successor_unknown_signer";
        case EvidenceCode::successor_duplicate_signer: return "successor_duplicate_signer";
        case EvidenceCode::successor_invalid_signature: return "successor_invalid_signature";
        case EvidenceCode::successor_below_threshold: return "successor_below_threshold";
    }
    return "unknown";
}

std::string_view apply_code_name(const ApplyCode value) noexcept {
    switch (value) {
        case ApplyCode::committed: return "committed";
        case ApplyCode::already_current_query_only: return "already_current_query_only";
        case ApplyCode::uncertain_after_commit_query_only:
            return "uncertain_after_commit_query_only";
        case ApplyCode::invalid_evidence: return "invalid_evidence";
        case ApplyCode::register_id_mismatch: return "register_id_mismatch";
        case ApplyCode::stale_current: return "stale_current";
        case ApplyCode::register_precommit_mismatch: return "register_precommit_mismatch";
    }
    return "unknown";
}

}  // namespace slopos::e0::signed_admission::root_succession
