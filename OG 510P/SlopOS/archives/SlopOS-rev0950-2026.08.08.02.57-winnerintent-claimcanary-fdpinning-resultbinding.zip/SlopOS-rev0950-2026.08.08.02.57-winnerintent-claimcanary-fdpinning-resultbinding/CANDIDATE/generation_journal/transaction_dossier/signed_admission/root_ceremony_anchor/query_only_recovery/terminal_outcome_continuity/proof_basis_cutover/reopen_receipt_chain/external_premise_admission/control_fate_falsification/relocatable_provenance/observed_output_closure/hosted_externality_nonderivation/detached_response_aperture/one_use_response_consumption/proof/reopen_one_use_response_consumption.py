#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, hashlib, struct
from pathlib import Path

DOMAINS = {
    "PARENT-APERTURE-BINDING.bin": (288, "slopos.ourc.parent-binding.v1"),
    "CURRENT-APPRAISAL-CARRIER.bin": (320, "slopos.ourc.appraisal-carrier.v1"),
    "CONSUME-REQUEST.bin": (320, "slopos.ourc.consume-request.v1"),
    "PENDING-INVOCATION.bin": (256, "slopos.ourc.invocation.v1"),
    "QUERY-OBSERVATION.bin": (352, "slopos.ourc.query-observation.v1"),
    "JOURNAL-COMMIT.bin": (416, "slopos.ourc.journal-commit.v1"),
    "TERMINAL-RECEIPT.bin": (320, "slopos.ourc.terminal-receipt.v1"),
    "REOPEN-RECEIPT.bin": (288, "slopos.ourc.reopen-receipt.v1"),
}

def fail(detail: str) -> None:
    raise SystemExit(f"ONE_USE_RESPONSE_CONSUMPTION_REOPEN=FAIL detail={detail}")

def domain_hash(domain: str, body: bytes) -> bytes:
    return hashlib.sha256(domain.encode() + b"\0" + body).digest()

def u64(data: bytes, offset: int) -> int:
    return struct.unpack_from("<Q", data, offset)[0]

def u32(data: bytes, offset: int) -> int:
    return struct.unpack_from("<I", data, offset)[0]

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    root = args.output
    objects: dict[str, bytes] = {}
    for name, (size, domain) in DOMAINS.items():
        path = root / name
        if not path.is_file() or path.is_symlink(): fail(f"object={name}")
        data = path.read_bytes()
        if len(data) != size: fail(f"size={name}:{len(data)}")
        if data[:32] != domain_hash(domain, data[32:]): fail(f"identity={name}")
        objects[name] = data

    parent = objects["PARENT-APERTURE-BINDING.bin"]
    appraisal = objects["CURRENT-APPRAISAL-CARRIER.bin"]
    request = objects["CONSUME-REQUEST.bin"]
    invocation = objects["PENDING-INVOCATION.bin"]
    query = objects["QUERY-OBSERVATION.bin"]
    source_root = Path(__file__).resolve().parents[1]
    query_policy = hashlib.sha256((source_root / "bindings/QUERY-ONLY-RECOVERY-POLICY.txt").read_bytes()).digest()
    query_role = hashlib.sha256((source_root / "bindings/QUERY-OBSERVER-ROLE.txt").read_bytes()).digest()
    commit = objects["JOURNAL-COMMIT.bin"]
    terminal = objects["TERMINAL-RECEIPT.bin"]
    reopen = objects["REOPEN-RECEIPT.bin"]

    parent_id, response = parent[:32], parent[96:128]
    if appraisal[32:64] != parent_id or appraisal[64:96] != response: fail("appraisal-parent-binding")
    if u64(appraisal, 256) != 41 or u64(appraisal, 264) != 1200 or u64(appraisal, 272) != 1800: fail("appraisal-window")
    if appraisal[284:289] != bytes([1,1,1,1,0]): fail("appraisal-flags")
    appraisal_id = appraisal[:32]
    if request[32:64] != parent_id or request[64:96] != response or request[96:128] != appraisal_id: fail("request-binding")
    if u64(request,288) != 0 or not (1200 <= u64(request,296) <= 1800): fail("request-time-generation")
    if request[308:312] != bytes([1,1,1,1]): fail("request-flags")
    request_id, operation, predecessor = request[:32], request[160:192], request[128:160]
    if invocation[32:64] != request_id or invocation[64:96] != operation or invocation[96:128] != predecessor: fail("invocation-binding")
    if invocation[236:240] != bytes([1,1,0,1]): fail("invocation-query-only")
    invocation_id = invocation[:32]
    if query[32:64] != invocation_id or query[64:96] != request_id or query[96:128] != operation: fail("query-subject")
    if query[128:160] != predecessor or query[160:192] != predecessor: fail("query-head")
    if query[192:224] != request[192:224] or query[224:256] != invocation[192:224]: fail("query-namespace-policy")
    if query[256:288] != query_role: fail("query-role")
    if u64(query,288) != 0 or u64(query,296) != 1 or not (u64(invocation,224) <= u64(query,304) <= u64(appraisal,272)): fail("query-generation-revision-time")
    if u32(query,312) != 1 or query[316] != 1 or query[317:324] != bytes([1,1,1,1,1,0,0]): fail("query-finding-flags")
    query_id = query[:32]
    if commit[32:64] != request_id or commit[64:96] != response or commit[96:128] != appraisal_id: fail("commit-subject")
    if commit[128:160] != query_id or commit[160:192] != predecessor or commit[224:256] != operation: fail("commit-query-compare-binding")
    if commit[256:288] != request[192:224]: fail("commit-namespace")
    if u64(commit,352) != 0 or u64(commit,360) != 1 or u64(commit,368) != 2: fail("commit-generations")
    if commit[380] != 1 or commit[381:386] != bytes([1,1,1,1,1]): fail("commit-outcome-flags")
    commit_id, successor, payload = commit[:32], commit[192:224], commit[288:320]
    if terminal[32:64] != commit_id or terminal[64:96] != request_id or terminal[96:128] != response: fail("terminal-subject")
    if terminal[128:160] != predecessor or terminal[160:192] != successor or terminal[192:224] != operation: fail("terminal-head-operation")
    if terminal[224:256] != payload or terminal[308] != 1 or terminal[309:313] != bytes([1,1,1,1]): fail("terminal-outcome")
    terminal_id = terminal[:32]
    if reopen[32:64] != terminal_id or reopen[64:96] != commit_id or reopen[96:128] != request_id or reopen[128:160] != response: fail("reopen-binding")
    if reopen[268:274] != bytes([1,1,1,1,1,0]): fail("reopen-flags")

    summary = {}
    with (root / "SUMMARY.tsv").open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            summary[row["metric"]] = row["value"]
    expected = {
        "accepted":"8", "durable_stages":"8", "candidate_reference_disagreements":"0",
        "canonical_objects":"8", "canonical_exact_object_bytes":"2560", "contention_rows":"16",
        "canonical_transition_composed":"true", "request_subject_revalidated":"true",
        "exact_query_observation_bound":"true", "exact_query_observer_role_bound":"true",
        "terminal_no_effect_from_absence":"false", "terminal_fact_precedes_currentness":"true",
        "exact_retry_state_bound":"true", "generated_bytecode_in_source_closure":"false",
        "external_linearizable_read_proved":"false",
        "one_use_within_coherent_history":"true", "global_one_use_proved":"false",
        "external_operation_proved":"false", "authority":"false", "epoch_exit":"false",
    }
    for key, value in expected.items():
        if summary.get(key) != value: fail(f"summary={key}:{summary.get(key)!r}")
    cases = list(csv.DictReader((root / "CASES.tsv").open(newline="", encoding="utf-8"), delimiter="\t"))
    cuts = list(csv.DictReader((root / "CUTS.tsv").open(newline="", encoding="utf-8"), delimiter="\t"))
    contention = list(csv.DictReader((root / "CONTENTION.tsv").open(newline="", encoding="utf-8"), delimiter="\t"))
    if len(cases) != int(summary["cases"]) or len(cuts) != int(summary["lifecycle_cuts"]): fail("row-counts")
    if len(cases) != 105 or int(summary["cases"]) != 105 or int(summary["rejected"]) != 97 or int(summary["lifecycle_cuts"]) != 840: fail("summary-exact-counts")
    if len(contention) != 16: fail("contention-rows")
    case_names = [row["case"] for row in cases]
    scenario_names = [row["scenario"] for row in contention]
    if len(set(case_names)) != len(case_names): fail("duplicate-case-name")
    if len(set(scenario_names)) != len(scenario_names): fail("duplicate-contention-scenario")
    by_case = {row["case"]: row for row in cases}
    for name in ("durable_stage_3", "durable_stage_4", "query_role_substitution", "query_after_appraisal_window", "query_self_promotes_terminal_no_effect", "query_self_promotes_external_linearizability", "commit_query_observation_mismatch", "query_cut_order_tamper"):
        if name not in by_case: fail(f"query-case={name}")
    if by_case["durable_stage_4"]["candidate"] != "accepted_absent_query_durable": fail("query-stage")
    outcomes = {row["scenario"]: row["candidate"] for row in contention}
    references = {row["scenario"]: row["reference"] for row in contention}
    required = {
        "first_apply":"applied",
        "exact_retry":"already_applied",
        "exact_retry_after_currentness_expiry":"already_applied",
        "different_request_same_response":"response_spent",
        "spent_response_after_currentness_expiry":"response_spent",
        "predecessor_conflict":"predecessor_conflict",
        "stale_currentness_before_first_effect":"stale_currentness",
        "clone_a_before_use":"applied",
        "clone_b_before_use":"applied",
        "digest_field_reuse_after_payload_mutation":"fail_stop",
        "same_request_wrong_terminal_receipt":"fail_stop",
        "same_request_wrong_successor_head":"fail_stop",
        "same_request_wrong_successor_generation":"fail_stop",
        "same_request_wrong_commit":"fail_stop",
        "same_request_wrong_commit_revision":"fail_stop",
        "unspent_row_with_residual_receipt":"fail_stop",
    }
    if outcomes != required or references != required: fail(f"contention={outcomes}:{references}")
    by_name = {row["scenario"]: row for row in contention}
    if by_name["first_apply"]["plan_valid"] != "1": fail("first-apply-plan")
    for name in ("exact_retry", "exact_retry_after_currentness_expiry"):
        row = by_name[name]
        if row["exact_receipt_match"] != "1" or row["exact_state_match"] != "1" or row["retry_equivalent"] != "1":
            fail(f"exact-retry-state={name}")
    for name in ("exact_retry_after_currentness_expiry", "spent_response_after_currentness_expiry"):
        if by_name[name]["terminal_fact_precedes_currentness"] != "1": fail(f"terminal-precedence={name}")
    for name in (
        "same_request_wrong_terminal_receipt", "same_request_wrong_successor_head",
        "same_request_wrong_successor_generation", "same_request_wrong_commit",
        "same_request_wrong_commit_revision", "unspent_row_with_residual_receipt",
    ):
        if by_name[name]["candidate"] != "fail_stop": fail(f"spent-state-fence={name}")
    if by_name["digest_field_reuse_after_payload_mutation"]["plan_valid"] != "0": fail("digest-field-plan-valid")
    print(
        "ONE_USE_RESPONSE_CONSUMPTION_REOPEN=PASS "
        f"cases={summary['cases']} accepted=8 rejected={summary['rejected']} cuts={summary['lifecycle_cuts']} "
        "objects=8 bytes=2560 contention=16 composed_transition=true request_revalidated=true exact_query=true "
        "exact_query_role=true terminal_fact_precedes_currentness=true exact_retry_state_bound=true "
        "local_one_use=true global_one_use=false query_only=true external_operation=false authority=false"
    )
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
