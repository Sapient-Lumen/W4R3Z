#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover.hpp"

#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <string>
#include <string_view>
#include <system_error>
#include <utility>
#include <vector>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover {
namespace {

struct TestCase final {
    std::string name;
    CutoverTrace trace;
    CutoverCode expected;
};

[[nodiscard]] Digest digest(const std::uint8_t seed) noexcept {
    Digest value{};
    for (std::size_t index = 0U; index < value.size(); ++index) {
        value[index] = static_cast<std::uint8_t>(seed + static_cast<std::uint8_t>(index));
    }
    return value;
}

[[nodiscard]] bool nonzero(const Digest& value) noexcept {
    return std::any_of(value.begin(), value.end(), [](const std::uint8_t byte) {
        return byte != 0U;
    });
}

[[nodiscard]] TerminalState terminal(const TerminalKind kind = TerminalKind::effect) noexcept {
    return TerminalState{digest(0x11U), digest(0x31U), digest(0x51U), digest(0x71U), kind};
}

[[nodiscard]] ContinuityEvidence empty_continuity(const TerminalState& state) noexcept {
    ContinuityEvidence evidence{};
    evidence.request_id = state.request_id;
    evidence.transition_digest = state.transition_digest;
    evidence.register_incarnation = state.register_incarnation;
    evidence.terminal_digest = state.terminal_digest;
    evidence.terminal_kind = state.terminal_kind;
    return evidence;
}

void complete_record(ContinuityEvidence& value) noexcept {
    value.terminal_record_present = true;
    value.terminal_record_authenticated = true;
    value.terminal_record_durable = true;
    value.terminal_record_serialized = true;
    value.terminal_record_single_view = true;
    value.terminal_record_retained_full_horizon = true;
    value.terminal_record_fences_pending = true;
    value.terminal_record_survives_restore = true;
    value.terminal_record_survives_succession = true;
    value.terminal_record_independently_reopenable = true;
}

void complete_witness(ContinuityEvidence& value) noexcept {
    value.terminal_witness_present = true;
    value.terminal_witness_authenticated = true;
    value.terminal_witness_binds_terminal = true;
    value.terminal_witness_durable = true;
    value.terminal_witness_independently_reopenable = true;
    value.terminal_witness_survives_restore = true;
    value.terminal_witness_survives_succession = true;
}

void complete_floor(ContinuityEvidence& value) noexcept {
    value.successor_floor_present = true;
    value.successor_floor_authenticated = true;
    value.successor_floor_monotone = true;
    value.successor_floor_outside_restore_domain = true;
    value.successor_floor_binds_request_namespace = true;
    value.old_incarnation_rejected = true;
    value.pending_invocations_fenced = true;
    value.restore_preserves_floor = true;
    value.succession_preserves_floor = true;
    value.successor_floor_single_view = true;
}

[[nodiscard]] JoinReceipt exact_join(const CutoverTrace& trace) noexcept {
    JoinReceipt join{};
    join.cutover_id = trace.cutover_id;
    join.request_id = trace.state.request_id;
    join.transition_digest = trace.state.transition_digest;
    join.register_incarnation = trace.state.register_incarnation;
    join.terminal_digest = trace.state.terminal_digest;
    join.witness_digest = trace.witness_digest;
    join.floor_digest = trace.floor_digest;
    join.terminal_kind = trace.state.terminal_kind;
    join.present = true;
    join.authenticated = true;
    join.durable = true;
    join.single_view = true;
    join.independently_reopenable = true;
    join.survives_restore = true;
    join.survives_succession = true;
    return join;
}

[[nodiscard]] CutObservation cut(
    const bool live,
    const bool witness,
    const bool floor,
    const bool join,
    const bool authorized,
    const bool deleted,
    const bool reopened = false) noexcept {
    return CutObservation{live, witness, floor, join, authorized, deleted, reopened};
}

[[nodiscard]] CutoverTrace base_trace(const TerminalKind kind = TerminalKind::effect) noexcept {
    CutoverTrace trace{};
    trace.state = terminal(kind);
    trace.continuity = empty_continuity(trace.state);
    complete_record(trace.continuity);
    complete_witness(trace.continuity);
    complete_floor(trace.continuity);
    trace.continuity.reclamation_requested = true;
    trace.cutover_id = digest(0x91U);
    trace.witness_digest = digest(0xB1U);
    trace.floor_digest = digest(0xD1U);
    trace.reclamation_requested = true;
    trace.join = exact_join(trace);
    return trace;
}

[[nodiscard]] CutoverTrace witness_first(
    const TerminalKind kind = TerminalKind::effect,
    const bool delete_record = true) noexcept {
    auto trace = base_trace(kind);
    trace.cuts = {
        cut(true,  false, false, false, false, false),
        cut(true,  true,  false, false, false, false),
        cut(true,  true,  true,  false, false, false),
        cut(true,  true,  true,  true,  false, false),
        cut(true,  true,  true,  true,  false, false, true),
        cut(true,  true,  true,  true,  delete_record, false, true),
        cut(!delete_record, true, true, true, delete_record, delete_record, true),
    };
    return trace;
}

[[nodiscard]] CutoverTrace floor_first(
    const TerminalKind kind = TerminalKind::effect,
    const bool delete_record = true) noexcept {
    auto trace = base_trace(kind);
    trace.cuts = {
        cut(true,  false, false, false, false, false),
        cut(true,  false, true,  false, false, false),
        cut(true,  true,  true,  false, false, false),
        cut(true,  true,  true,  true,  false, false),
        cut(true,  true,  true,  true,  false, false, true),
        cut(true,  true,  true,  true,  delete_record, false, true),
        cut(!delete_record, true, true, true, delete_record, delete_record, true),
    };
    return trace;
}

[[nodiscard]] CutoverTrace parallel_prepare(
    const TerminalKind kind = TerminalKind::effect,
    const bool delete_record = true) noexcept {
    auto trace = base_trace(kind);
    trace.cuts = {
        cut(true,  false, false, false, false, false),
        cut(true,  false, false, false, false, false),
        cut(true,  true,  true,  false, false, false),
        cut(true,  true,  true,  true,  false, false),
        cut(true,  true,  true,  true,  false, false, true),
        cut(true,  true,  true,  true,  delete_record, false, true),
        cut(!delete_record, true, true, true, delete_record, delete_record, true),
    };
    return trace;
}

[[nodiscard]] CutoverTrace live_only(
    const TerminalKind kind = TerminalKind::effect,
    const bool witness_partial = false,
    const bool floor_partial = false) noexcept {
    auto trace = base_trace(kind);
    trace.continuity = empty_continuity(trace.state);
    complete_record(trace.continuity);
    if (witness_partial) complete_witness(trace.continuity);
    if (floor_partial) complete_floor(trace.continuity);
    trace.join = JoinReceipt{};
    trace.reclamation_requested = false;
    trace.cuts = {
        cut(true, false, false, false, false, false),
        cut(true, witness_partial, floor_partial, false, false, false),
        cut(true, witness_partial, floor_partial, false, false, false),
        cut(true, witness_partial, floor_partial, false, false, false),
        cut(true, witness_partial, floor_partial, false, false, false),
        cut(true, witness_partial, floor_partial, false, false, false),
        cut(true, witness_partial, floor_partial, false, false, false),
    };
    return trace;
}

[[nodiscard]] std::vector<TestCase> cases() {
    std::vector<TestCase> values;
    const auto add = [&values](std::string name, CutoverTrace trace, const CutoverCode expected) {
        values.push_back(TestCase{std::move(name), std::move(trace), expected});
    };

    add("safe_effect_witness_first", witness_first(TerminalKind::effect), CutoverCode::accepted_cutover_complete);
    add("safe_no_effect_witness_first", witness_first(TerminalKind::no_effect), CutoverCode::accepted_cutover_complete);
    add("safe_effect_floor_first", floor_first(TerminalKind::effect), CutoverCode::accepted_cutover_complete);
    add("safe_no_effect_floor_first", floor_first(TerminalKind::no_effect), CutoverCode::accepted_cutover_complete);
    add("safe_effect_parallel_prepare", parallel_prepare(TerminalKind::effect), CutoverCode::accepted_cutover_complete);
    add("safe_no_effect_parallel_prepare", parallel_prepare(TerminalKind::no_effect), CutoverCode::accepted_cutover_complete);
    {
        auto trace = witness_first();
        trace.continuity.client_acknowledged = true;
        add("safe_effect_client_ack_irrelevant", trace, CutoverCode::accepted_cutover_complete);
    }
    {
        auto trace = witness_first(TerminalKind::no_effect);
        trace.continuity.ttl_expired = true;
        add("safe_no_effect_ttl_irrelevant", trace, CutoverCode::accepted_cutover_complete);
    }

    add("ready_effect_witness_first_live_retained", witness_first(TerminalKind::effect, false), CutoverCode::accepted_cutover_ready_live_retained);
    add("ready_no_effect_floor_first_live_retained", floor_first(TerminalKind::no_effect, false), CutoverCode::accepted_cutover_ready_live_retained);
    add("ready_effect_parallel_live_retained", parallel_prepare(TerminalKind::effect, false), CutoverCode::accepted_cutover_ready_live_retained);
    add("ready_no_effect_joined_cold_reopen_live_retained", parallel_prepare(TerminalKind::no_effect, false), CutoverCode::accepted_cutover_ready_live_retained);
    {
        auto trace = witness_first(TerminalKind::effect, false);
        for (std::size_t index = 4U; index < trace.cuts.size(); ++index) {
            trace.cuts[index].cold_reopen_observed = false;
        }
        add("refused_reopen_gap_live_retained_without_cold_reopen", trace, CutoverCode::accepted_reclamation_refused_reopen_gap);
    }

    add("live_effect_record_only", live_only(TerminalKind::effect), CutoverCode::accepted_live_basis_retained);
    add("live_no_effect_record_only", live_only(TerminalKind::no_effect), CutoverCode::accepted_live_basis_retained);
    add("live_effect_partial_witness", live_only(TerminalKind::effect, true, false), CutoverCode::accepted_live_basis_retained);
    add("live_no_effect_partial_floor", live_only(TerminalKind::no_effect, false, true), CutoverCode::accepted_live_basis_retained);

    {
        auto trace = witness_first();
        trace.cuts[2] = cut(false, true, false, false, true, true);
        trace.cuts[3] = cut(false, true, true, false, true, true);
        trace.cuts[4] = cut(false, true, true, true, true, true, true);
        trace.cuts[5] = cut(false, true, true, true, true, true, true);
        trace.cuts[6] = cut(false, true, true, true, true, true, true);
        add("refused_execution_gap_delete_after_witness_then_floor", trace, CutoverCode::accepted_reclamation_refused_execution_gap);
    }
    {
        auto trace = floor_first();
        trace.cuts[2] = cut(false, false, true, false, true, true);
        trace.cuts[3] = cut(false, true, true, false, true, true);
        trace.cuts[4] = cut(false, true, true, true, true, true, true);
        trace.cuts[5] = cut(false, true, true, true, true, true, true);
        trace.cuts[6] = cut(false, true, true, true, true, true, true);
        add("refused_history_gap_delete_after_floor_then_witness", trace, CutoverCode::accepted_reclamation_refused_history_gap);
    }
    {
        auto trace = witness_first();
        for (std::size_t index = 2U; index < trace.cuts.size(); ++index) {
            trace.cuts[index].deletion_authorized = true;
        }
        add("refused_order_gap_authorize_before_join_then_repair", trace, CutoverCode::accepted_reclamation_refused_order_gap);
    }
    {
        auto trace = witness_first();
        trace.cuts[3] = cut(true, true, true, false, false, false);
        trace.cuts[4] = cut(false, true, true, false, true, true);
        trace.cuts[5] = cut(false, true, true, false, true, true);
        trace.cuts[6] = cut(false, true, true, true, true, true, true);
        add("refused_join_gap_eventual_join_cannot_repair_cut", trace, CutoverCode::accepted_reclamation_refused_join_gap);
    }
    {
        auto trace = witness_first();
        for (std::size_t index = 4U; index < trace.cuts.size(); ++index) {
            trace.cuts[index].cold_reopen_observed = false;
        }
        add("refused_reopen_gap_no_cold_reopen", trace, CutoverCode::accepted_reclamation_refused_reopen_gap);
    }
    {
        auto trace = witness_first();
        trace.join.independently_reopenable = false;
        add("refused_reopen_gap_join_not_independent", trace, CutoverCode::accepted_reclamation_refused_reopen_gap);
    }
    {
        auto trace = witness_first();
        trace.join.survives_restore = false;
        add("refused_reopen_gap_join_lost_on_restore", trace, CutoverCode::accepted_reclamation_refused_reopen_gap);
    }
    {
        auto trace = witness_first();
        trace.join.survives_succession = false;
        add("refused_reopen_gap_join_lost_on_succession", trace, CutoverCode::accepted_reclamation_refused_reopen_gap);
    }
    {
        auto trace = witness_first();
        trace.continuity.pending_invocations_fenced = false;
        add("refused_execution_gap_floor_does_not_fence_pending", trace, CutoverCode::accepted_reclamation_refused_execution_gap);
    }
    {
        auto trace = witness_first();
        trace.continuity.terminal_witness_independently_reopenable = false;
        add("refused_history_gap_witness_not_independent", trace, CutoverCode::accepted_reclamation_refused_history_gap);
    }
    {
        auto trace = witness_first();
        trace.join.authenticated = false;
        add("refused_join_gap_join_not_authenticated", trace, CutoverCode::accepted_reclamation_refused_join_gap);
    }
    {
        auto trace = witness_first();
        trace.join.durable = false;
        add("refused_join_gap_join_not_durable", trace, CutoverCode::accepted_reclamation_refused_join_gap);
    }
    {
        auto trace = witness_first();
        trace.join.single_view = false;
        add("refused_join_gap_join_not_single_view", trace, CutoverCode::accepted_reclamation_refused_join_gap);
    }
    {
        auto trace = witness_first();
        trace.cuts[5].deletion_authorized = false;
        trace.cuts[6].deletion_authorized = false;
        add("refused_order_gap_unauthorized_deletion", trace, CutoverCode::accepted_reclamation_refused_order_gap);
    }
    {
        auto trace = parallel_prepare();
        trace.cuts[2].join_visible = true;
        add("refused_order_gap_join_same_cut_as_components", trace, CutoverCode::accepted_reclamation_refused_order_gap);
    }
    {
        auto trace = witness_first();
        trace.cuts[3].cold_reopen_observed = true;
        add("refused_order_gap_reopen_same_cut_as_join", trace, CutoverCode::accepted_reclamation_refused_order_gap);
    }
    {
        auto trace = witness_first();
        trace.cuts[4].deletion_authorized = true;
        add("refused_order_gap_authorize_same_cut_as_reopen", trace, CutoverCode::accepted_reclamation_refused_order_gap);
    }
    {
        auto trace = witness_first();
        trace.cuts[5].live_record_visible = false;
        trace.cuts[5].record_deleted = true;
        add("refused_order_gap_delete_same_cut_as_authorization", trace, CutoverCode::accepted_reclamation_refused_order_gap);
    }

    {
        auto trace = witness_first();
        trace.equivocation_observed = true;
        add("equivocation_fail_stop", trace, CutoverCode::accepted_equivocation_fail_stop);
    }
    {
        auto trace = witness_first();
        trace.equivocation_observed = true;
        trace.cuts[6].deletion_authorized = false;
        add("equivocation_with_authorization_regression", trace, CutoverCode::accepted_equivocation_fail_stop);
    }
    {
        auto trace = witness_first();
        trace.cuts[6].witness_visible = false;
        add("regression_witness_disappears", trace, CutoverCode::accepted_regression_fail_stop);
    }
    {
        auto trace = witness_first();
        trace.cuts[6].floor_visible = false;
        add("regression_floor_disappears", trace, CutoverCode::accepted_regression_fail_stop);
    }
    {
        auto trace = witness_first();
        trace.cuts[6].join_visible = false;
        add("regression_join_disappears", trace, CutoverCode::accepted_regression_fail_stop);
    }
    {
        auto trace = witness_first();
        // Special adversarial trace: deletion becomes durable at the prior cut,
        // then the live record spuriously reappears.  The canonical safe trace
        // deletes only at T6; this case intentionally violates that phase map
        // so the monotone relation can prove resurrection is fail-stop.
        trace.cuts[5].live_record_visible = false;
        trace.cuts[5].record_deleted = true;
        trace.cuts[6].record_deleted = false;
        trace.cuts[6].live_record_visible = true;
        add("regression_live_record_resurrection", trace, CutoverCode::accepted_regression_fail_stop);
    }
    {
        auto trace = witness_first();
        trace.cuts[6].deletion_authorized = false;
        add("regression_authorization_disappears", trace, CutoverCode::accepted_regression_fail_stop);
    }

    for (const auto index : std::array<std::size_t, 4U>{0U, 1U, 2U, 3U}) {
        auto trace = witness_first();
        if (index == 0U) trace.state.request_id = Digest{};
        if (index == 1U) trace.state.transition_digest = Digest{};
        if (index == 2U) trace.state.register_incarnation = Digest{};
        if (index == 3U) trace.state.terminal_digest = Digest{};
        add("invalid_terminal_state_" + std::to_string(index), trace, CutoverCode::invalid_terminal_state);
    }
    {
        auto trace = witness_first(); trace.continuity.request_id = digest(0x12U);
        add("parent_request_mismatch", trace, CutoverCode::parent_evidence_rejected);
    }
    {
        auto trace = witness_first(); trace.continuity.transition_digest = digest(0x32U);
        add("parent_transition_mismatch", trace, CutoverCode::parent_evidence_rejected);
    }
    {
        auto trace = witness_first(); trace.continuity.register_incarnation = digest(0x52U);
        add("parent_incarnation_mismatch", trace, CutoverCode::parent_evidence_rejected);
    }
    {
        auto trace = witness_first(); trace.continuity.terminal_digest = digest(0x72U);
        add("parent_terminal_digest_mismatch", trace, CutoverCode::parent_evidence_rejected);
    }
    {
        auto trace = witness_first(); trace.continuity.terminal_kind = TerminalKind::no_effect;
        add("parent_terminal_kind_mismatch", trace, CutoverCode::parent_evidence_rejected);
    }
    {
        auto trace = witness_first(); trace.continuity.terminal_record_present = false;
        add("parent_record_shape_invalid", trace, CutoverCode::parent_evidence_rejected);
    }
    {
        auto trace = witness_first(); trace.continuity.terminal_witness_present = false;
        add("parent_witness_shape_invalid", trace, CutoverCode::parent_evidence_rejected);
    }
    {
        auto trace = witness_first(); trace.continuity.successor_floor_present = false;
        add("parent_floor_shape_invalid", trace, CutoverCode::parent_evidence_rejected);
    }
    {
        auto trace = witness_first(); trace.cutover_id = Digest{};
        add("zero_cutover_id", trace, CutoverCode::cutover_id_zero);
    }
    {
        auto trace = witness_first(); trace.witness_digest = Digest{};
        add("zero_witness_digest", trace, CutoverCode::witness_digest_zero);
    }
    {
        auto trace = witness_first(); trace.floor_digest = Digest{};
        add("zero_floor_digest", trace, CutoverCode::floor_digest_zero);
    }
    {
        auto trace = witness_first(); trace.reclamation_requested = false;
        add("reclamation_request_parent_true_trace_false", trace, CutoverCode::reclamation_request_mismatch);
    }
    {
        auto trace = witness_first(); trace.continuity.reclamation_requested = false;
        add("reclamation_request_parent_false_trace_true", trace, CutoverCode::reclamation_request_mismatch);
    }
    {
        auto trace = live_only(); trace.join.authenticated = true;
        add("join_shape_authenticated_without_present", trace, CutoverCode::join_receipt_shape_invalid);
    }
    {
        auto trace = live_only(); trace.join.cutover_id = digest(0x91U);
        add("join_shape_digest_without_present", trace, CutoverCode::join_receipt_shape_invalid);
    }
    {
        auto trace = witness_first(); trace.join.cutover_id = digest(0x92U);
        add("join_cutover_mismatch", trace, CutoverCode::join_cutover_id_mismatch);
    }
    {
        auto trace = witness_first(); trace.join.request_id = digest(0x12U);
        add("join_request_mismatch", trace, CutoverCode::join_request_id_mismatch);
    }
    {
        auto trace = witness_first(); trace.join.transition_digest = digest(0x32U);
        add("join_transition_mismatch", trace, CutoverCode::join_transition_digest_mismatch);
    }
    {
        auto trace = witness_first(); trace.join.register_incarnation = digest(0x52U);
        add("join_incarnation_mismatch", trace, CutoverCode::join_register_incarnation_mismatch);
    }
    {
        auto trace = witness_first(); trace.join.terminal_digest = digest(0x72U);
        add("join_terminal_digest_mismatch", trace, CutoverCode::join_terminal_digest_mismatch);
    }
    {
        auto trace = witness_first(); trace.join.terminal_kind = TerminalKind::no_effect;
        add("join_terminal_kind_mismatch", trace, CutoverCode::join_terminal_kind_mismatch);
    }
    {
        auto trace = witness_first(); trace.join.witness_digest = digest(0xB2U);
        add("join_witness_digest_mismatch", trace, CutoverCode::join_witness_digest_mismatch);
    }
    {
        auto trace = witness_first(); trace.join.floor_digest = digest(0xD2U);
        add("join_floor_digest_mismatch", trace, CutoverCode::join_floor_digest_mismatch);
    }
    {
        auto trace = witness_first(); trace.cuts[0].live_record_visible = false;
        add("trace_initial_no_live", trace, CutoverCode::trace_initial_state_invalid);
    }
    {
        auto trace = witness_first(); trace.cuts[6].live_record_visible = true;
        add("trace_deleted_and_live", trace, CutoverCode::trace_deleted_and_live);
    }
    {
        auto trace = witness_first(); trace.cuts[2].cold_reopen_observed = true;
        add("trace_reopen_without_joined_basis", trace, CutoverCode::trace_reopen_without_joined_basis);
    }
    {
        auto trace = witness_first(); trace.cuts[1].join_visible = true;
        add("trace_join_before_floor", trace, CutoverCode::trace_join_without_components);
    }
    {
        auto trace = parallel_prepare(); trace.cuts[1].join_visible = true;
        add("trace_join_before_both_components", trace, CutoverCode::trace_join_without_components);
    }
    {
        auto trace = witness_first();
        trace.cuts[6].live_record_visible = false;
        trace.cuts[6].record_deleted = false;
        add("trace_live_absent_without_recorded_delete", trace, CutoverCode::trace_live_absent_without_deletion);
    }

    return values;
}

[[nodiscard]] std::string truth(const bool value) {
    return value ? "true" : "false";
}

[[nodiscard]] bool write_text(const std::filesystem::path& path, const std::string& text) {
    std::ofstream stream(path, std::ios::binary | std::ios::trunc);
    if (!stream) return false;
    stream.write(text.data(), static_cast<std::streamsize>(text.size()));
    return stream.good();
}

[[nodiscard]] bool join_shape_valid_local(const JoinReceipt& join) noexcept {
    const bool dependent = join.authenticated || join.durable || join.single_view
        || join.independently_reopenable || join.survives_restore || join.survives_succession
        || nonzero(join.cutover_id) || nonzero(join.request_id) || nonzero(join.transition_digest)
        || nonzero(join.register_incarnation) || nonzero(join.terminal_digest)
        || nonzero(join.witness_digest) || nonzero(join.floor_digest);
    return join.present || !dependent;
}

}  // namespace

bool run_campaign(const std::filesystem::path& output_directory) {
    std::error_code error;
    std::filesystem::remove_all(output_directory, error);
    error.clear();
    if (!std::filesystem::create_directories(output_directory, error) || error) return false;

    const auto test_cases = cases();
    if (test_cases.size() != 75U) return false;

    std::string table =
        "case\tterminal_kind\tstate_nonzero\tparent_accepted\tcutover_id_nonzero\twitness_digest_nonzero\tfloor_digest_nonzero\t"
        "reclamation_request_match\tjoin_shape_valid\tjoin_cutover_match\tjoin_request_match\tjoin_transition_match\tjoin_incarnation_match\t"
        "join_terminal_digest_match\tjoin_terminal_kind_match\tjoin_witness_digest_match\tjoin_floor_digest_match\t"
        "trace_initial_valid\ttrace_deleted_live_conflict\ttrace_reopen_without_joined_basis\ttrace_join_without_components\t"
        "trace_live_absent_without_deletion\treclamation_requested\tequivocation\t"
        "parent_live_basis\tparent_witness_path\tparent_floor_path\tjoin_present\tjoin_authenticated\tjoin_durable\t"
        "join_single_view\tjoin_independent_reopen\tjoin_survives_restore\tjoin_survives_succession\t"
        "candidate_code\treference_code\tagreement\taccepted\tjoin_core_valid\tjoin_reopen_valid\tall_cuts_covered\t"
        "execution_gap\thistory_gap\tjoin_gap\treopen_gap\tphase_order_gap\tregression\tcutover_ready\treclamation_safe\t"
        "live_record_must_remain\tfail_stopped\teventual_repair_sufficient\texternal_occurrence\tauthority\n";
    std::string cuts_table =
        "case\tcut_index\tcut_name\tlive_record_visible\twitness_visible\tfloor_visible\tjoin_visible\t"
        "deletion_authorized\trecord_deleted\tcold_reopen_observed\texecution_covered\thistory_covered\t"
        "same_history_basis\tjoin_order_ok\treopen_order_ok\tauthorization_order_ok\t"
        "deletion_order_ok\tphase_order_ok\tdeletion_protocol_ok\tcut_covered\n";

    std::size_t accepted_count = 0U;
    std::size_t complete_count = 0U;
    std::size_t ready_count = 0U;
    std::size_t live_count = 0U;
    std::size_t refused_count = 0U;
    std::size_t fail_count = 0U;

    for (const auto& item : test_cases) {
        const auto candidate = evaluate_candidate(item.trace);
        const auto reference = evaluate_reference(item.trace);
        if (candidate != reference || candidate.code != item.expected) {
            std::cerr << "case=" << item.name
                      << " candidate=" << cutover_code_name(candidate.code)
                      << " reference=" << cutover_code_name(reference.code)
                      << " expected=" << cutover_code_name(item.expected) << "\n";
            return false;
        }
        if (candidate.eventual_repair_sufficient
            || candidate.external_occurrence_proved
            || candidate.currentness_proved
            || candidate.independent_custody_proved
            || candidate.epoch_exit_proved
            || candidate.authority_granted) return false;

        const auto parent = terminal_outcome_continuity::evaluate_candidate(item.trace.state, item.trace.continuity);
        const bool state_nonzero = nonzero(item.trace.state.request_id)
            && nonzero(item.trace.state.transition_digest)
            && nonzero(item.trace.state.register_incarnation)
            && nonzero(item.trace.state.terminal_digest);
        const bool join_cutover_match = !item.trace.join.present || item.trace.join.cutover_id == item.trace.cutover_id;
        const bool join_request_match = !item.trace.join.present || item.trace.join.request_id == item.trace.state.request_id;
        const bool join_transition_match = !item.trace.join.present || item.trace.join.transition_digest == item.trace.state.transition_digest;
        const bool join_incarnation_match = !item.trace.join.present || item.trace.join.register_incarnation == item.trace.state.register_incarnation;
        const bool join_terminal_digest_match = !item.trace.join.present || item.trace.join.terminal_digest == item.trace.state.terminal_digest;
        const bool join_terminal_kind_match = !item.trace.join.present || item.trace.join.terminal_kind == item.trace.state.terminal_kind;
        const bool join_witness_match = !item.trace.join.present || item.trace.join.witness_digest == item.trace.witness_digest;
        const bool join_floor_match = !item.trace.join.present || item.trace.join.floor_digest == item.trace.floor_digest;
        const bool trace_initial_valid = item.trace.cuts.front().live_record_visible && !item.trace.cuts.front().record_deleted;
        const bool reclamation_request_match = item.trace.reclamation_requested
            == item.trace.continuity.reclamation_requested;
        bool deleted_live_conflict = false;
        bool reopen_without_joined_basis = false;
        bool join_without_components = false;
        bool live_absent_without_deletion = false;
        bool complete_join_seen = false;
        for (std::size_t index = 0U; index < item.trace.cuts.size(); ++index) {
            const auto& observed = item.trace.cuts[index];
            deleted_live_conflict = deleted_live_conflict
                || (observed.record_deleted && observed.live_record_visible);
            const bool complete_join_here = observed.join_visible
                && observed.witness_visible
                && observed.floor_visible;
            reopen_without_joined_basis = reopen_without_joined_basis
                || (observed.cold_reopen_observed && !complete_join_here && !complete_join_seen);
            join_without_components = join_without_components
                || (observed.join_visible && (!observed.witness_visible || !observed.floor_visible)
                    && !complete_join_seen);
            complete_join_seen = complete_join_seen || complete_join_here;
            live_absent_without_deletion = live_absent_without_deletion
                || (!observed.live_record_visible && !observed.record_deleted);
        }

        accepted_count += candidate.accepted ? 1U : 0U;
        complete_count += candidate.code == CutoverCode::accepted_cutover_complete ? 1U : 0U;
        ready_count += candidate.code == CutoverCode::accepted_cutover_ready_live_retained ? 1U : 0U;
        live_count += candidate.code == CutoverCode::accepted_live_basis_retained ? 1U : 0U;
        refused_count += candidate.code == CutoverCode::accepted_reclamation_refused_execution_gap
            || candidate.code == CutoverCode::accepted_reclamation_refused_history_gap
            || candidate.code == CutoverCode::accepted_reclamation_refused_join_gap
            || candidate.code == CutoverCode::accepted_reclamation_refused_reopen_gap
            || candidate.code == CutoverCode::accepted_reclamation_refused_order_gap ? 1U : 0U;
        fail_count += candidate.fail_stopped ? 1U : 0U;

        table += item.name + "\t"
            + std::string(terminal_kind_name(item.trace.state.terminal_kind)) + "\t"
            + truth(state_nonzero) + "\t"
            + truth(parent.accepted) + "\t"
            + truth(nonzero(item.trace.cutover_id)) + "\t"
            + truth(nonzero(item.trace.witness_digest)) + "\t"
            + truth(nonzero(item.trace.floor_digest)) + "\t"
            + truth(reclamation_request_match) + "\t"
            + truth(join_shape_valid_local(item.trace.join)) + "\t"
            + truth(join_cutover_match) + "\t"
            + truth(join_request_match) + "\t"
            + truth(join_transition_match) + "\t"
            + truth(join_incarnation_match) + "\t"
            + truth(join_terminal_digest_match) + "\t"
            + truth(join_terminal_kind_match) + "\t"
            + truth(join_witness_match) + "\t"
            + truth(join_floor_match) + "\t"
            + truth(trace_initial_valid) + "\t"
            + truth(deleted_live_conflict) + "\t"
            + truth(reopen_without_joined_basis) + "\t"
            + truth(join_without_components) + "\t"
            + truth(live_absent_without_deletion) + "\t"
            + truth(item.trace.reclamation_requested) + "\t"
            + truth(item.trace.equivocation_observed) + "\t"
            + truth(parent.terminal_record_execution_path && parent.terminal_record_history_path) + "\t"
            + truth(parent.terminal_witness_history_path) + "\t"
            + truth(parent.successor_floor_execution_path) + "\t"
            + truth(item.trace.join.present) + "\t"
            + truth(item.trace.join.authenticated) + "\t"
            + truth(item.trace.join.durable) + "\t"
            + truth(item.trace.join.single_view) + "\t"
            + truth(item.trace.join.independently_reopenable) + "\t"
            + truth(item.trace.join.survives_restore) + "\t"
            + truth(item.trace.join.survives_succession) + "\t"
            + std::string(cutover_code_name(candidate.code)) + "\t"
            + std::string(cutover_code_name(reference.code)) + "\ttrue\t"
            + truth(candidate.accepted) + "\t"
            + truth(candidate.join_core_valid) + "\t"
            + truth(candidate.join_reopen_valid) + "\t"
            + truth(candidate.all_cuts_covered) + "\t"
            + truth(candidate.execution_gap_observed) + "\t"
            + truth(candidate.history_gap_observed) + "\t"
            + truth(candidate.join_gap_observed) + "\t"
            + truth(candidate.reopen_gap_observed) + "\t"
            + truth(candidate.phase_order_gap_observed) + "\t"
            + truth(candidate.regression_observed) + "\t"
            + truth(candidate.cutover_ready) + "\t"
            + truth(candidate.reclamation_safe) + "\t"
            + truth(candidate.live_record_must_remain) + "\t"
            + truth(candidate.fail_stopped) + "\t"
            + truth(candidate.eventual_repair_sufficient) + "\t"
            + truth(candidate.external_occurrence_proved) + "\t"
            + truth(candidate.authority_granted) + "\n";

        const bool join_identity = join_cutover_match && join_request_match && join_transition_match
            && join_incarnation_match && join_terminal_digest_match && join_terminal_kind_match
            && join_witness_match && join_floor_match;
        const bool join_core = item.trace.join.present && join_identity
            && item.trace.join.authenticated && item.trace.join.durable && item.trace.join.single_view;
        const bool join_reopen = join_core
            && item.trace.join.independently_reopenable
            && item.trace.join.survives_restore
            && item.trace.join.survives_succession;
        bool prior_witness = false;
        bool prior_floor = false;
        bool prior_join = false;
        bool prior_reopen = false;
        bool prior_authorization = false;
        bool prior_deletion = false;
        for (std::size_t index = 0U; index < item.trace.cuts.size(); ++index) {
            const auto& observed = item.trace.cuts[index];
            const bool execution = (observed.live_record_visible && parent.terminal_record_execution_path)
                || (observed.floor_visible && parent.successor_floor_execution_path);
            const bool history = (observed.live_record_visible && parent.terminal_record_history_path)
                || (observed.witness_visible && parent.terminal_witness_history_path);
            const bool joined = observed.witness_visible && observed.floor_visible && observed.join_visible
                && join_core && parent.terminal_witness_history_path && parent.successor_floor_execution_path;
            const bool basis = (observed.live_record_visible
                && parent.terminal_record_execution_path && parent.terminal_record_history_path) || joined;
            const bool reopened = observed.cold_reopen_observed && joined && join_reopen;
            const bool new_join = observed.join_visible && !prior_join;
            const bool new_reopen = observed.cold_reopen_observed && !prior_reopen;
            const bool new_authorization = observed.deletion_authorized && !prior_authorization;
            const bool new_deletion = observed.record_deleted && !prior_deletion;
            const bool join_order = !new_join || (prior_witness && prior_floor);
            const bool reopen_order = !new_reopen || prior_join;
            const bool authorization_order = !new_authorization || prior_reopen;
            const bool deletion_order = !new_deletion || prior_authorization;
            const bool phase_order = join_order && reopen_order && authorization_order && deletion_order;
            const bool authorization = !observed.deletion_authorized
                || (authorization_order && reopened);
            const bool deletion = authorization
                && (!observed.record_deleted
                    || (observed.deletion_authorized && deletion_order && reopened));
            const bool covered = execution && history && basis && phase_order && deletion;
            cuts_table += item.name + "\t" + std::to_string(index) + "\t"
                + std::string(cut_name(index)) + "\t"
                + truth(observed.live_record_visible) + "\t"
                + truth(observed.witness_visible) + "\t"
                + truth(observed.floor_visible) + "\t"
                + truth(observed.join_visible) + "\t"
                + truth(observed.deletion_authorized) + "\t"
                + truth(observed.record_deleted) + "\t"
                + truth(observed.cold_reopen_observed) + "\t"
                + truth(execution) + "\t"
                + truth(history) + "\t"
                + truth(basis) + "\t"
                + truth(join_order) + "\t"
                + truth(reopen_order) + "\t"
                + truth(authorization_order) + "\t"
                + truth(deletion_order) + "\t"
                + truth(phase_order) + "\t"
                + truth(deletion) + "\t"
                + truth(covered) + "\n";
            prior_witness = prior_witness || observed.witness_visible;
            prior_floor = prior_floor || observed.floor_visible;
            prior_join = prior_join || observed.join_visible;
            prior_reopen = prior_reopen || observed.cold_reopen_observed;
            prior_authorization = prior_authorization || observed.deletion_authorized;
            prior_deletion = prior_deletion || observed.record_deleted;
        }
    }

    if (accepted_count != 42U || complete_count != 8U || ready_count != 4U
        || live_count != 4U || refused_count != 19U || fail_count != 7U) {
        std::cerr << "counts accepted=" << accepted_count << " complete=" << complete_count
                  << " ready=" << ready_count << " live=" << live_count
                  << " refused=" << refused_count << " fail=" << fail_count << "\n";
        return false;
    }

    const std::string summary =
        "{\n"
        "  \"accepted_cases\": 42,\n"
        "  \"authority_granted\": false,\n"
        "  \"candidate_reference_disagreements\": 0,\n"
        "  \"cases\": 75,\n"
        "  \"cutover_complete_cases\": 8,\n"
        "  \"cutover_ready_live_retained_cases\": 4,\n"
        "  \"epoch_exit_proved\": false,\n"
        "  \"eventual_repair_sufficient_cases\": 0,\n"
        "  \"external_occurrence_proved\": false,\n"
        "  \"fail_stopped_cases\": 7,\n"
        "  \"independent_custody_proved\": false,\n"
        "  \"live_basis_retained_cases\": 4,\n"
        "  \"phase_order_refused_cases\": 6,\n"
        "  \"reclamation_refused_cases\": 19,\n"
        "  \"reclamation_safe_cases\": 8,\n"
        "  \"rejected_cases\": 33,\n"
        "  \"schema\": \"slopos.rev0918.proof-basis-cutover-campaign.v1\"\n"
        "}\n";
    const std::string phases =
        "cut_index\tname\tlive_record_rule\treplacement_rule\n"
        "0\tT0_live\tcomplete live basis required\treplacement optional\n"
        "1\tT1_first_replacement\tlive basis retained\twitness or floor may appear\n"
        "2\tT2_both_replacements\tlive basis retained\tboth replacement components may appear\n"
        "3\tT3_join\tlive basis retained\texact same-history join becomes durable\n"
        "4\tT4_cold_reopen\tlive basis retained\treplacement-only reopener reconstructs joined basis\n"
        "5\tT5_authorize\tlive basis retained\tdeletion authorization follows observed cold reopen\n"
        "6\tT6_delete\tmay disappear once\tjoined reopened basis must already cover the cut\n";
    const std::string countertraces =
        "row\ttrace\tcut\tlive\twitness\tfloor\tjoin\tcovered\tjudgment\n"
        "L0\tlive_bridge\tT0\ttrue\tfalse\tfalse\tfalse\ttrue\tlive record carries both axes\n"
        "E0\twitness_first_early_delete\tT2\tfalse\ttrue\tfalse\tfalse\tfalse\texecution gap\n"
        "E1\twitness_first_eventual_repair\tT6\tfalse\ttrue\ttrue\ttrue\ttrue\tfinal conjunction does not erase E0\n"
        "H0\tfloor_first_early_delete\tT2\tfalse\tfalse\ttrue\tfalse\tfalse\thistory gap\n"
        "H1\tfloor_first_eventual_repair\tT6\tfalse\ttrue\ttrue\ttrue\ttrue\tfinal conjunction does not erase H0\n"
        "J0\tunjoined_components\tT4\tfalse\ttrue\ttrue\tfalse\tfalse\ttwo components do not prove co-reference\n"
        "J1\teventual_join\tT6\tfalse\ttrue\ttrue\ttrue\ttrue\tlater join cannot cover J0\n"
        "D0\tabsence_without_delete\tT6\tfalse\ttrue\ttrue\ttrue\tfalse\tdisappearance without a recorded delete is malformed\n"
        "R0\tjoined_without_cold_reopen\tT5\ttrue\ttrue\ttrue\ttrue\ttrue\tcoverage is not deletion authorization\n"
        "O0\tsame_cut_reopen_and_authorize\tT4\ttrue\ttrue\ttrue\ttrue\tfalse\tno imported atomic transaction justifies collapsed phases\n"
        "O1\tstrict_predecessor_authorize\tT5\ttrue\ttrue\ttrue\ttrue\ttrue\tprior-cut cold reopen permits later authorization\n"
        "S0\tsafe_cutover\tALL\tbridge\ttrue\ttrue\ttrue\ttrue\tevery cut is covered before deletion\n";
    const std::string invariants =
        "EVERY_ADMITTED_CRASH_CUT_MUST_BE_COVERED=true\n"
        "FINAL_CONJUNCTION_DOES_NOT_ERASE_PRIOR_GAP=true\n"
        "LIVE_RECORD_IS_THE_BRIDGE_UNTIL_JOINED_REPLACEMENT=true\n"
        "WITNESS_WITHOUT_FLOOR_HAS_EXECUTION_GAP=true\n"
        "FLOOR_WITHOUT_WITNESS_HAS_HISTORY_GAP=true\n"
        "WITNESS_AND_FLOOR_WITHOUT_JOIN_HAVE_SAME_HISTORY_GAP=true\n"
        "DELETION_AUTHORIZATION_FOLLOWS_OBSERVED_COLD_REOPEN=true\n"
        "JOIN_REOPEN_AUTHORIZE_DELETE_REQUIRE_PRIOR_CUTS=true\n"
        "SAME_CUT_PHASE_COLLAPSE_IS_NOT_ATOMIC=true\n"
        "RECLAMATION_REQUEST_MUST_MATCH_PARENT=true\n"
        "JOIN_VISIBILITY_FOLLOWS_BOTH_COMPONENTS=true\n"
        "LIVE_ABSENCE_REQUIRES_RECORDED_DELETE=true\n"
        "CUTOVER_READY_REQUIRES_COLD_REOPEN=true\n"
        "REPLACEMENT_REGRESSION_FAILS_STOP=true\n"
        "LIVE_RECORD_RESURRECTION_FAILS_STOP=true\n"
        "EVENTUAL_REPAIR_SUFFICIENT=false\n"
        "EXTERNAL_OCCURRENCE_PROVED=false\n"
        "AUTHORITY_GRANTED=false\n";

    return write_text(output_directory / "CASES.tsv", table)
        && write_text(output_directory / "CUTS.tsv", cuts_table)
        && write_text(output_directory / "SUMMARY.json", summary)
        && write_text(output_directory / "PHASES.tsv", phases)
        && write_text(output_directory / "COUNTERTRACES.tsv", countertraces)
        && write_text(output_directory / "INVARIANTS.txt", invariants);
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover
