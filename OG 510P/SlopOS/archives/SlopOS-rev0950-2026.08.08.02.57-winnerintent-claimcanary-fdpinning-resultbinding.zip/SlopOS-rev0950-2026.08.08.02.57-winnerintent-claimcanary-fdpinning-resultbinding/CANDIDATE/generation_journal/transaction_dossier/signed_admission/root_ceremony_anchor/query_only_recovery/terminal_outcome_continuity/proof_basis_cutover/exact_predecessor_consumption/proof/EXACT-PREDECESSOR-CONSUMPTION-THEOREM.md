# Exact Predecessor Consumption Theorem

## Theorem

For every accepted `accepted_chain_complete` trace in the hosted relation:

1. the parent Proof Basis Cutover trace is reclamation-safe at every modeled crash prefix;
2. every present phase receipt binds the exact terminal subject;
3. receipt identities are nonzero and pairwise distinct;
4. `J` names the exact `W` and `F` identities, `R` names exact `J`, `A` names exact `R`, and deletion names exact `A`;
5. each predecessor publication occurs at a strict earlier cut than its consumer;
6. receipt visibility and deletion are monotone, or the trace fails stop;
7. the live record remains visible until a covered deletion cut; and
8. no accepted trace treats mere earlier visibility as sufficient.

Therefore a complete trace cannot obtain reclamation safety by substituting a stale, forked, skipped, same-cut, in-memory-only, or wrong-history predecessor receipt.

## Proof sketch

The candidate evaluator validates the parent relation, receipt shape, common subject, basis components, receipt identity uniqueness, exact edges, publication quality, first-visibility indices, monotone prefixes, and deletion coverage in that order. Hard subject and shape errors are rejected. Well-shaped but unsafe histories are admitted only as explicit reclamation refusals. Equivocation and regression fail stop.

The reference evaluator reconstructs the same judgment by sorting receipt identities, deriving a graph from predecessor fields, scanning first publication cuts, and independently checking prefix coverage. The campaign compares the complete report objects for 75 traces. The Python reopener reconstructs the digest graph and cut ordering from retained TSV artifacts without invoking either C++ evaluator.

## Boundary

This is a model theorem. It does not prove that a real platform made bytes durable, persisted a directory entry, serialized concurrent publishers, or performed deletion. External Ceremony V6 must bind the abstract publication and consumption cuts to selected mechanisms before any authority-bearing use.
