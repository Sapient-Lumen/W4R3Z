# Theorem — bounded one-use and stable terminal replay inside one coherent history

Let `P` be one exact canonical transition plan containing request `R`, commit
`C`, and terminal receipt `T`. Let `S` be one coherent unspent journal state whose
head and generation match `R`.

```text
ValidPlan(P)
Attempt(S, P, current=true) = APPLIED(C, C.successor, T)
Attempt(S', P, current=false) = ALREADY_APPLIED(C, C.successor, T)
```

`S'` is not identified by a receipt digest alone. It retains one exact spent-state
witness binding response, request, commit digest, successor head, successor
generation, commit revision, and terminal receipt. A mismatch in any member is
`FAIL_STOP`; an unspent row carrying residual spent fields is also `FAIL_STOP`.

Terminal classification precedes authorization currentness. Expired appraisal
blocks a first effect, but it does not erase an already committed result or change
a different request for the same response from `RESPONSE_SPENT` into an
authorization error. No retry path appends again.

The exact query observation preceding the commit is canonical and binds the
invocation, request, operation, predecessor, generation, policy, role, revision,
and time. It remains model-only and proves neither an external linearizable read
nor terminal no-effect.

The theorem is deliberately history-relative. If `S` is cloned before first use,
both clones can produce their own local `APPLIED` transition. Therefore this
construction establishes a precise interface and countermodel boundary, not
global one-use, external occurrence, owner admission, authority, or epoch exit.
