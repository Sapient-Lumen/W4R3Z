#include "slopos/e0/signed_admission/root_ceremony_anchor.hpp"

#include "slopos/e0/generation_journal/spend_record.hpp"

#include <algorithm>
#include <array>
#include <limits>
#include <span>
#include <string_view>
#include <vector>

namespace slopos::e0::signed_admission::root_ceremony_anchor {
namespace {

constexpr std::array<std::uint8_t, 8U> kMagic{{'S','L','O','P','C','A','0','1'}};
constexpr std::uint16_t kVersion = 1U;
constexpr std::uint16_t kKind = 7U;
constexpr std::string_view kIntegrityDomain = "SlopOS/root-ceremony-anchor/integrity/v1";
constexpr std::string_view kHeadDomain = "SlopOS/root-ceremony-anchor/head/v1";
constexpr std::string_view kTransitionDomain = "SlopOS/root-ceremony-anchor/transition/v1";
constexpr std::string_view kRequestDomain = "SlopOS/root-ceremony-anchor/request/v1";

[[nodiscard]] bool all_zero(const std::span<const std::uint8_t> bytes) noexcept {
    return std::all_of(bytes.begin(), bytes.end(), [](const std::uint8_t value) {
        return value == 0U;
    });
}

[[nodiscard]] bool nonzero(const Digest& value) noexcept {
    return !all_zero(value);
}

void put_u16(EncodedAnchor& out, const std::size_t offset, const std::uint16_t value) noexcept {
    out[offset] = static_cast<std::uint8_t>(value >> 8U);
    out[offset + 1U] = static_cast<std::uint8_t>(value);
}

void put_u32(EncodedAnchor& out, const std::size_t offset, const std::uint32_t value) noexcept {
    out[offset] = static_cast<std::uint8_t>(value >> 24U);
    out[offset + 1U] = static_cast<std::uint8_t>(value >> 16U);
    out[offset + 2U] = static_cast<std::uint8_t>(value >> 8U);
    out[offset + 3U] = static_cast<std::uint8_t>(value);
}

void put_u64(EncodedAnchor& out, const std::size_t offset, const std::uint64_t value) noexcept {
    for (std::size_t i = 0U; i < 8U; ++i) {
        const unsigned int shift = static_cast<unsigned int>((7U - i) * 8U);
        out[offset + i] = static_cast<std::uint8_t>(value >> shift);
    }
}

[[nodiscard]] std::uint16_t get_u16(const EncodedAnchor& in, const std::size_t offset) noexcept {
    return static_cast<std::uint16_t>(
        (static_cast<std::uint16_t>(in[offset]) << 8U)
        | static_cast<std::uint16_t>(in[offset + 1U]));
}

[[nodiscard]] std::uint32_t get_u32(const EncodedAnchor& in, const std::size_t offset) noexcept {
    return (static_cast<std::uint32_t>(in[offset]) << 24U)
        | (static_cast<std::uint32_t>(in[offset + 1U]) << 16U)
        | (static_cast<std::uint32_t>(in[offset + 2U]) << 8U)
        | static_cast<std::uint32_t>(in[offset + 3U]);
}

[[nodiscard]] std::uint64_t get_u64(const EncodedAnchor& in, const std::size_t offset) noexcept {
    std::uint64_t value = 0U;
    for (std::size_t i = 0U; i < 8U; ++i) {
        value = (value << 8U) | static_cast<std::uint64_t>(in[offset + i]);
    }
    return value;
}

template <std::size_t N>
void put_array(EncodedAnchor& out, const std::size_t offset,
               const std::array<std::uint8_t, N>& value) noexcept {
    std::copy(value.begin(), value.end(), out.begin() + static_cast<std::ptrdiff_t>(offset));
}

template <std::size_t N>
[[nodiscard]] std::array<std::uint8_t, N> get_array(
    const EncodedAnchor& in, const std::size_t offset) noexcept {
    std::array<std::uint8_t, N> value{};
    std::copy_n(in.begin() + static_cast<std::ptrdiff_t>(offset),
                static_cast<std::ptrdiff_t>(N), value.begin());
    return value;
}

[[nodiscard]] Digest domain_digest(
    const std::string_view domain,
    const std::span<const std::uint8_t> payload) {
    std::vector<std::uint8_t> bytes;
    bytes.reserve(domain.size() + 1U + payload.size());
    bytes.insert(bytes.end(), domain.begin(), domain.end());
    bytes.push_back(0U);
    bytes.insert(bytes.end(), payload.begin(), payload.end());
    return generation_journal::sha256(bytes);
}

void append(std::vector<std::uint8_t>& out, const Digest& digest) {
    out.insert(out.end(), digest.begin(), digest.end());
}

void append_u64(std::vector<std::uint8_t>& out, const std::uint64_t value) {
    for (std::size_t i = 0U; i < 8U; ++i) {
        const unsigned int shift = static_cast<unsigned int>((7U - i) * 8U);
        out.push_back(static_cast<std::uint8_t>(value >> shift));
    }
}

[[nodiscard]] RelationReport reject(
    const RelationCode code,
    RelationReport report) noexcept {
    report.code = code;
    report.valid = false;
    report.external_receipt_authenticity_proved = false;
    report.owner_constitution_proved = false;
    report.currentness_proved = false;
    report.independent_custody_proved = false;
    report.protected_transition_proved = false;
    report.independent_reopen_proved = false;
    report.epoch_exit_proved = false;
    report.authority_granted = false;
    return report;
}

[[nodiscard]] bool mandatory_nonzero(const RootCeremonyAnchorV1& value) noexcept {
    const std::array<const Digest*, 9U> fields{{
        &value.project_id,
        &value.register_id,
        &value.register_incarnation,
        &value.predecessor_manifest_head,
        &value.successor_manifest_head,
        &value.rc0_starting_root_receipt_head,
        &value.rc1_precommit_receipt_head,
        &value.precommit_operation_id,
        &value.policy_head,
    }};
    return std::all_of(fields.begin(), fields.end(), [](const Digest* value_ptr) {
        return nonzero(*value_ptr);
    });
}

}  // namespace

Digest transition_digest_for(const RootCeremonyAnchorV1& value) {
    std::vector<std::uint8_t> bytes;
    bytes.reserve(9U * 32U + 16U);
    append(bytes, value.project_id);
    append(bytes, value.register_id);
    append(bytes, value.register_incarnation);
    append(bytes, value.predecessor_manifest_head);
    append(bytes, value.successor_manifest_head);
    append(bytes, value.rc0_starting_root_receipt_head);
    append(bytes, value.rc1_precommit_receipt_head);
    append(bytes, value.precommit_operation_id);
    append(bytes, value.policy_head);
    append_u64(bytes, value.predecessor_version);
    append_u64(bytes, value.successor_version);
    return domain_digest(kTransitionDomain, bytes);
}

Digest request_id_for(const RootCeremonyAnchorV1& value) {
    std::vector<std::uint8_t> bytes;
    bytes.reserve(4U * 32U);
    append(bytes, value.transition_digest);
    append(bytes, value.register_id);
    append(bytes, value.register_incarnation);
    append(bytes, value.precommit_operation_id);
    return domain_digest(kRequestDomain, bytes);
}

Digest anchor_head(const EncodedAnchor& anchor) {
    return domain_digest(kHeadDomain, anchor);
}

std::uint64_t request_nonce(const Digest& request_id) noexcept {
    std::uint64_t value = 0U;
    for (std::size_t i = 0U; i < 8U; ++i) {
        value = (value << 8U) | static_cast<std::uint64_t>(request_id[i]);
    }
    return value;
}

bool encode_anchor(const RootCeremonyAnchorV1& value, EncodedAnchor& output) {
    output.fill(0U);
    std::copy(kMagic.begin(), kMagic.end(), output.begin());
    put_u16(output, 8U, kVersion);
    put_u16(output, 10U, kKind);
    put_u32(output, 12U, static_cast<std::uint32_t>(kAnchorBytes));
    put_array(output, 16U, value.project_id);
    put_array(output, 48U, value.register_id);
    put_array(output, 80U, value.register_incarnation);
    put_array(output, 112U, value.predecessor_manifest_head);
    put_array(output, 144U, value.successor_manifest_head);
    put_array(output, 176U, value.rc0_starting_root_receipt_head);
    put_array(output, 208U, value.rc1_precommit_receipt_head);
    put_array(output, 240U, value.precommit_operation_id);
    put_array(output, 272U, value.policy_head);
    put_array(output, 304U, value.transition_digest);
    put_array(output, 336U, value.request_id);
    put_u64(output, 368U, value.predecessor_version);
    put_u64(output, 376U, value.successor_version);
    put_u64(output, 384U, value.precommit_recorded_at);
    put_u64(output, 392U, value.signing_not_before);
    put_u64(output, 400U, value.expires_at);
    put_u64(output, 408U, value.request_deadline);
    const Digest integrity = domain_digest(
        kIntegrityDomain,
        std::span<const std::uint8_t>(output.data(), 480U));
    put_array(output, 480U, integrity);
    return true;
}

bool decode_anchor(const EncodedAnchor& input, RootCeremonyAnchorV1& output) {
    if (!std::equal(kMagic.begin(), kMagic.end(), input.begin())
        || get_u16(input, 8U) != kVersion
        || get_u16(input, 10U) != kKind
        || get_u32(input, 12U) != kAnchorBytes
        || !all_zero(std::span<const std::uint8_t>(input.data() + 416U, 64U))) {
        return false;
    }
    const Digest expected = domain_digest(
        kIntegrityDomain,
        std::span<const std::uint8_t>(input.data(), 480U));
    if (expected != get_array<32U>(input, 480U)) {
        return false;
    }
    RootCeremonyAnchorV1 value{};
    value.project_id = get_array<32U>(input, 16U);
    value.register_id = get_array<32U>(input, 48U);
    value.register_incarnation = get_array<32U>(input, 80U);
    value.predecessor_manifest_head = get_array<32U>(input, 112U);
    value.successor_manifest_head = get_array<32U>(input, 144U);
    value.rc0_starting_root_receipt_head = get_array<32U>(input, 176U);
    value.rc1_precommit_receipt_head = get_array<32U>(input, 208U);
    value.precommit_operation_id = get_array<32U>(input, 240U);
    value.policy_head = get_array<32U>(input, 272U);
    value.transition_digest = get_array<32U>(input, 304U);
    value.request_id = get_array<32U>(input, 336U);
    value.predecessor_version = get_u64(input, 368U);
    value.successor_version = get_u64(input, 376U);
    value.precommit_recorded_at = get_u64(input, 384U);
    value.signing_not_before = get_u64(input, 392U);
    value.expires_at = get_u64(input, 400U);
    value.request_deadline = get_u64(input, 408U);
    output = value;
    return true;
}

RelationReport validate_candidate(
    const EncodedAnchor& encoded_anchor,
    const EncodedRootStatement& encoded_statement,
    const std::uint64_t observed_time) {
    RelationReport report{};
    RootCeremonyAnchorV1 anchor{};
    if (!decode_anchor(encoded_anchor, anchor)) {
        return reject(RelationCode::invalid_anchor, report);
    }
    report.canonical_anchor = true;

    root_succession::RootSuccessionStatementV1 statement{};
    if (!root_succession::decode_root_statement(encoded_statement, statement)) {
        return reject(RelationCode::invalid_statement, report);
    }
    report.canonical_statement = true;

    if (!mandatory_nonzero(anchor)) {
        return reject(RelationCode::missing_identity, report);
    }
    report.external_receipts_bound = true;
    report.register_incarnation_bound = true;
    if (anchor.rc0_starting_root_receipt_head == anchor.rc1_precommit_receipt_head) {
        return reject(RelationCode::receipt_collision, report);
    }
    if (anchor.predecessor_version == std::numeric_limits<std::uint64_t>::max()
        || anchor.successor_version != anchor.predecessor_version + 1U) {
        return reject(RelationCode::version_not_next, report);
    }
    report.exact_next_version = true;
    if (anchor.transition_digest != transition_digest_for(anchor)) {
        return reject(RelationCode::transition_digest_mismatch, report);
    }
    report.transition_digest_match = true;
    if (anchor.request_id != request_id_for(anchor)) {
        return reject(RelationCode::request_id_mismatch, report);
    }
    report.deterministic_request_id = true;
    if (anchor.precommit_recorded_at >= anchor.signing_not_before) {
        return reject(RelationCode::precommit_chronology_invalid, report);
    }
    report.precommit_precedes_signing = true;
    if (anchor.signing_not_before >= anchor.expires_at
        || anchor.request_deadline < anchor.signing_not_before
        || anchor.request_deadline > anchor.expires_at) {
        return reject(RelationCode::time_window_invalid, report);
    }
    if (statement.project_id != anchor.project_id) {
        return reject(RelationCode::statement_project_mismatch, report);
    }
    if (statement.register_id != anchor.register_id) {
        return reject(RelationCode::statement_register_mismatch, report);
    }
    if (statement.predecessor_manifest_head != anchor.predecessor_manifest_head
        || statement.successor_manifest_head != anchor.successor_manifest_head) {
        return reject(RelationCode::statement_heads_mismatch, report);
    }
    if (statement.predecessor_version != anchor.predecessor_version
        || statement.successor_version != anchor.successor_version) {
        return reject(RelationCode::statement_versions_mismatch, report);
    }
    if (statement.precommitted_successor_head != anchor.successor_manifest_head) {
        return reject(RelationCode::statement_precommit_mismatch, report);
    }
    if (statement.ceremony_id != anchor_head(encoded_anchor)) {
        return reject(RelationCode::statement_ceremony_mismatch, report);
    }
    if (statement.not_before != anchor.signing_not_before
        || statement.expires_at != anchor.expires_at) {
        return reject(RelationCode::statement_time_mismatch, report);
    }
    if (statement.transition_nonce != request_nonce(anchor.request_id)) {
        return reject(RelationCode::statement_nonce_mismatch, report);
    }
    report.statement_bound = true;
    if (observed_time < anchor.signing_not_before
        || observed_time > anchor.request_deadline
        || observed_time > anchor.expires_at) {
        return reject(RelationCode::observed_outside_window, report);
    }
    report.observed_in_window = true;
    report.code = RelationCode::relation_valid;
    report.valid = true;
    return report;
}

std::string_view relation_code_name(const RelationCode value) noexcept {
    switch (value) {
        case RelationCode::relation_valid: return "RELATION_VALID";
        case RelationCode::invalid_anchor: return "INVALID_ANCHOR";
        case RelationCode::invalid_statement: return "INVALID_STATEMENT";
        case RelationCode::missing_identity: return "MISSING_IDENTITY";
        case RelationCode::receipt_collision: return "RECEIPT_COLLISION";
        case RelationCode::version_not_next: return "VERSION_NOT_NEXT";
        case RelationCode::transition_digest_mismatch: return "TRANSITION_DIGEST_MISMATCH";
        case RelationCode::request_id_mismatch: return "REQUEST_ID_MISMATCH";
        case RelationCode::precommit_chronology_invalid: return "PRECOMMIT_CHRONOLOGY_INVALID";
        case RelationCode::time_window_invalid: return "TIME_WINDOW_INVALID";
        case RelationCode::statement_project_mismatch: return "STATEMENT_PROJECT_MISMATCH";
        case RelationCode::statement_register_mismatch: return "STATEMENT_REGISTER_MISMATCH";
        case RelationCode::statement_heads_mismatch: return "STATEMENT_HEADS_MISMATCH";
        case RelationCode::statement_versions_mismatch: return "STATEMENT_VERSIONS_MISMATCH";
        case RelationCode::statement_precommit_mismatch: return "STATEMENT_PRECOMMIT_MISMATCH";
        case RelationCode::statement_ceremony_mismatch: return "STATEMENT_CEREMONY_MISMATCH";
        case RelationCode::statement_time_mismatch: return "STATEMENT_TIME_MISMATCH";
        case RelationCode::statement_nonce_mismatch: return "STATEMENT_NONCE_MISMATCH";
        case RelationCode::observed_outside_window: return "OBSERVED_OUTSIDE_WINDOW";
    }
    return "UNKNOWN";
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor
