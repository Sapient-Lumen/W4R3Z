#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover.hpp"

#include <algorithm>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover {
namespace {

[[nodiscard]] bool nonzero(const Digest& value) noexcept {
    return std::any_of(value.cbegin(), value.cend(), [](const std::uint8_t byte) {
        return byte != 0U;
    });
}

[[nodiscard]] bool terminal_state_valid(const TerminalState& state) noexcept {
    return nonzero(state.request_id)
        && nonzero(state.transition_digest)
        && nonzero(state.register_incarnation)
        && nonzero(state.terminal_digest);
}

[[nodiscard]] bool join_shape_valid(const JoinReceipt& join) noexcept {
    const bool dependent = join.authenticated
        || join.durable
        || join.single_view
        || join.independently_reopenable
        || join.survives_restore
        || join.survives_succession
        || nonzero(join.cutover_id)
        || nonzero(join.request_id)
        || nonzero(join.transition_digest)
        || nonzero(join.register_incarnation)
        || nonzero(join.terminal_digest)
        || nonzero(join.witness_digest)
        || nonzero(join.floor_digest);
    return join.present || !dependent;
}

[[nodiscard]] CutoverReport reject(const CutoverCode code) noexcept {
    CutoverReport value{};
    value.code = code;
    value.accepted = false;
    return value;
}

[[nodiscard]] CutoverReport report(
    const CutoverCode code,
    const bool live_basis,
    const bool witness_path,
    const bool floor_path,
    const bool join_core,
    const bool join_reopen,
    const bool all_cuts,
    const bool execution_gap,
    const bool history_gap,
    const bool join_gap,
    const bool reopen_gap,
    const bool phase_order_gap,
    const bool regression,
    const bool ready,
    const bool safe,
    const bool fail_stopped) noexcept {
    return CutoverReport{
        code,
        true,
        live_basis,
        witness_path,
        floor_path,
        join_core,
        join_reopen,
        all_cuts,
        execution_gap,
        history_gap,
        join_gap,
        reopen_gap,
        phase_order_gap,
        regression,
        ready,
        safe,
        !safe,
        fail_stopped,
        false,
        false,
        false,
        false,
        false,
        false,
    };
}

}  // namespace

CutoverReport evaluate_candidate(const CutoverTrace& trace) noexcept {
    if (!terminal_state_valid(trace.state)) {
        return reject(CutoverCode::invalid_terminal_state);
    }
    const auto parent = terminal_outcome_continuity::evaluate_candidate(
        trace.state, trace.continuity);
    if (!parent.accepted) {
        return reject(CutoverCode::parent_evidence_rejected);
    }
    if (!nonzero(trace.cutover_id)) {
        return reject(CutoverCode::cutover_id_zero);
    }
    if (!nonzero(trace.witness_digest)) {
        return reject(CutoverCode::witness_digest_zero);
    }
    if (!nonzero(trace.floor_digest)) {
        return reject(CutoverCode::floor_digest_zero);
    }
    if (trace.reclamation_requested != trace.continuity.reclamation_requested) {
        return reject(CutoverCode::reclamation_request_mismatch);
    }
    if (!join_shape_valid(trace.join)) {
        return reject(CutoverCode::join_receipt_shape_invalid);
    }
    if (trace.join.present) {
        if (trace.join.cutover_id != trace.cutover_id) {
            return reject(CutoverCode::join_cutover_id_mismatch);
        }
        if (trace.join.request_id != trace.state.request_id) {
            return reject(CutoverCode::join_request_id_mismatch);
        }
        if (trace.join.transition_digest != trace.state.transition_digest) {
            return reject(CutoverCode::join_transition_digest_mismatch);
        }
        if (trace.join.register_incarnation != trace.state.register_incarnation) {
            return reject(CutoverCode::join_register_incarnation_mismatch);
        }
        if (trace.join.terminal_digest != trace.state.terminal_digest) {
            return reject(CutoverCode::join_terminal_digest_mismatch);
        }
        if (trace.join.terminal_kind != trace.state.terminal_kind) {
            return reject(CutoverCode::join_terminal_kind_mismatch);
        }
        if (trace.join.witness_digest != trace.witness_digest) {
            return reject(CutoverCode::join_witness_digest_mismatch);
        }
        if (trace.join.floor_digest != trace.floor_digest) {
            return reject(CutoverCode::join_floor_digest_mismatch);
        }
    }

    if (!trace.cuts.front().live_record_visible || trace.cuts.front().record_deleted) {
        return reject(CutoverCode::trace_initial_state_invalid);
    }
    bool complete_join_seen = false;
    for (const auto& cut : trace.cuts) {
        if (cut.live_record_visible && cut.record_deleted) {
            return reject(CutoverCode::trace_deleted_and_live);
        }
        const bool complete_join_here = cut.join_visible
            && cut.witness_visible
            && cut.floor_visible;
        if (cut.cold_reopen_observed && !complete_join_here && !complete_join_seen) {
            return reject(CutoverCode::trace_reopen_without_joined_basis);
        }
        if (cut.join_visible && (!cut.witness_visible || !cut.floor_visible)
            && !complete_join_seen) {
            return reject(CutoverCode::trace_join_without_components);
        }
        complete_join_seen = complete_join_seen || complete_join_here;
        if (!cut.live_record_visible && !cut.record_deleted) {
            return reject(CutoverCode::trace_live_absent_without_deletion);
        }
    }

    const bool live_basis = parent.terminal_record_execution_path
        && parent.terminal_record_history_path;
    const bool witness_path = parent.terminal_witness_history_path;
    const bool floor_path = parent.successor_floor_execution_path;
    const bool join_core = trace.join.present
        && trace.join.authenticated
        && trace.join.durable
        && trace.join.single_view;
    const bool join_reopen = join_core
        && trace.join.independently_reopenable
        && trace.join.survives_restore
        && trace.join.survives_succession;

    bool all_cuts = true;
    bool execution_gap = false;
    bool history_gap = false;
    bool join_gap = false;
    bool phase_order_gap = false;
    bool regression = false;
    bool seen_witness = false;
    bool seen_floor = false;
    bool seen_join = false;
    bool seen_cold_reopen = false;
    bool seen_authorization = false;
    bool seen_deletion = false;
    bool live_was_absent = false;

    for (const auto& cut : trace.cuts) {
        const bool record_execution = cut.live_record_visible
            && parent.terminal_record_execution_path;
        const bool record_history = cut.live_record_visible
            && parent.terminal_record_history_path;
        const bool witness_history = cut.witness_visible && witness_path;
        const bool floor_execution = cut.floor_visible && floor_path;
        const bool joined_replacement = cut.witness_visible
            && cut.floor_visible
            && cut.join_visible
            && join_core
            && witness_path
            && floor_path;
        const bool execution_covered = record_execution || floor_execution;
        const bool history_covered = record_history || witness_history;
        const bool same_history_basis = (cut.live_record_visible && live_basis)
            || joined_replacement;
        const bool reopened_replacement = cut.cold_reopen_observed
            && joined_replacement
            && join_reopen;

        // Each destructive phase consumes a fact durable at a strictly earlier
        // crash cut.  Same-cut collapse is not treated as atomic because this
        // hosted relation imports no external transaction that could justify it.
        const bool new_join = cut.join_visible && !seen_join;
        const bool new_reopen = cut.cold_reopen_observed && !seen_cold_reopen;
        const bool new_authorization = cut.deletion_authorized && !seen_authorization;
        const bool new_deletion = cut.record_deleted && !seen_deletion;
        const bool join_order_ok = !new_join || (seen_witness && seen_floor);
        const bool reopen_order_ok = !new_reopen || seen_join;
        const bool authorization_order_ok = !new_authorization || seen_cold_reopen;
        const bool deletion_order_ok = !new_deletion || seen_authorization;
        const bool order_ok = join_order_ok
            && reopen_order_ok
            && authorization_order_ok
            && deletion_order_ok;
        const bool authorization_protocol = !cut.deletion_authorized
            || (authorization_order_ok && reopened_replacement);
        const bool deletion_protocol = authorization_protocol
            && (!cut.record_deleted
                || (cut.deletion_authorized
                    && deletion_order_ok
                    && reopened_replacement));
        const bool covered = execution_covered
            && history_covered
            && same_history_basis
            && order_ok
            && deletion_protocol;

        all_cuts = all_cuts && covered;
        execution_gap = execution_gap || !execution_covered;
        history_gap = history_gap || !history_covered;
        join_gap = join_gap
            || (execution_covered && history_covered && !same_history_basis);
        phase_order_gap = phase_order_gap || !order_ok;

        regression = regression
            || (seen_witness && !cut.witness_visible)
            || (seen_floor && !cut.floor_visible)
            || (seen_join && !cut.join_visible)
            || (seen_cold_reopen && !cut.cold_reopen_observed)
            || (seen_authorization && !cut.deletion_authorized)
            || (seen_deletion && !cut.record_deleted)
            || (live_was_absent && cut.live_record_visible);
        seen_witness = seen_witness || cut.witness_visible;
        seen_floor = seen_floor || cut.floor_visible;
        seen_join = seen_join || cut.join_visible;
        seen_cold_reopen = seen_cold_reopen || cut.cold_reopen_observed;
        seen_authorization = seen_authorization || cut.deletion_authorized;
        seen_deletion = seen_deletion || cut.record_deleted;
        live_was_absent = live_was_absent || !cut.live_record_visible;
    }

    const auto& final_cut = trace.cuts.back();
    const bool final_joined = final_cut.witness_visible
        && final_cut.floor_visible
        && final_cut.join_visible
        && join_core
        && witness_path
        && floor_path;
    const bool reopen_gap = trace.reclamation_requested
        && final_joined
        && (!join_reopen || !final_cut.cold_reopen_observed);
    const bool ready = !trace.equivocation_observed
        && !regression
        && !phase_order_gap
        && all_cuts
        && final_cut.live_record_visible
        && !final_cut.record_deleted
        && final_cut.cold_reopen_observed
        && final_joined
        && join_reopen;
    const bool safe = !trace.equivocation_observed
        && !regression
        && !phase_order_gap
        && all_cuts
        && trace.reclamation_requested
        && final_cut.record_deleted
        && !final_cut.live_record_visible
        && final_cut.deletion_authorized
        && final_cut.cold_reopen_observed
        && final_joined
        && join_reopen;

    if (trace.equivocation_observed) {
        return report(
            CutoverCode::accepted_equivocation_fail_stop,
            live_basis, witness_path, floor_path, join_core, join_reopen,
            false, execution_gap, history_gap, true, true, phase_order_gap,
            regression, false, false, true);
    }
    if (regression) {
        return report(
            CutoverCode::accepted_regression_fail_stop,
            live_basis, witness_path, floor_path, join_core, join_reopen,
            false, execution_gap, history_gap, join_gap, true, phase_order_gap,
            true, false, false, true);
    }
    if (safe) {
        return report(
            CutoverCode::accepted_cutover_complete,
            live_basis, witness_path, floor_path, join_core, join_reopen,
            true, false, false, false, false, false,
            false, false, true, false);
    }
    if (ready) {
        return report(
            CutoverCode::accepted_cutover_ready_live_retained,
            live_basis, witness_path, floor_path, join_core, join_reopen,
            true, false, false, false, false, false,
            false, true, false, false);
    }
    if (reopen_gap) {
        return report(
            CutoverCode::accepted_reclamation_refused_reopen_gap,
            live_basis, witness_path, floor_path, join_core, join_reopen,
            all_cuts, execution_gap, history_gap, join_gap, true,
            phase_order_gap, false, false, false, false);
    }
    if (all_cuts && final_cut.live_record_visible && live_basis) {
        return report(
            CutoverCode::accepted_live_basis_retained,
            live_basis, witness_path, floor_path, join_core, join_reopen,
            true, false, false, false, false, false,
            false, false, false, false);
    }
    if (execution_gap) {
        return report(
            CutoverCode::accepted_reclamation_refused_execution_gap,
            live_basis, witness_path, floor_path, join_core, join_reopen,
            false, true, history_gap, join_gap, reopen_gap, phase_order_gap,
            false, false, false, false);
    }
    if (history_gap) {
        return report(
            CutoverCode::accepted_reclamation_refused_history_gap,
            live_basis, witness_path, floor_path, join_core, join_reopen,
            false, false, true, join_gap, reopen_gap, phase_order_gap,
            false, false, false, false);
    }
    if (join_gap) {
        return report(
            CutoverCode::accepted_reclamation_refused_join_gap,
            live_basis, witness_path, floor_path, join_core, join_reopen,
            false, false, false, true, reopen_gap, phase_order_gap,
            false, false, false, false);
    }
    if (phase_order_gap) {
        return report(
            CutoverCode::accepted_reclamation_refused_order_gap,
            live_basis, witness_path, floor_path, join_core, join_reopen,
            false, false, false, false, reopen_gap, true,
            false, false, false, false);
    }
    return report(
        CutoverCode::accepted_reclamation_refused_reopen_gap,
        live_basis, witness_path, floor_path, join_core, join_reopen,
        all_cuts, false, false, false, true, false,
        false, false, false, false);
}

std::string_view cutover_code_name(const CutoverCode value) noexcept {
    switch (value) {
    case CutoverCode::accepted_cutover_complete: return "accepted_cutover_complete";
    case CutoverCode::accepted_cutover_ready_live_retained: return "accepted_cutover_ready_live_retained";
    case CutoverCode::accepted_live_basis_retained: return "accepted_live_basis_retained";
    case CutoverCode::accepted_reclamation_refused_execution_gap: return "accepted_reclamation_refused_execution_gap";
    case CutoverCode::accepted_reclamation_refused_history_gap: return "accepted_reclamation_refused_history_gap";
    case CutoverCode::accepted_reclamation_refused_join_gap: return "accepted_reclamation_refused_join_gap";
    case CutoverCode::accepted_reclamation_refused_reopen_gap: return "accepted_reclamation_refused_reopen_gap";
    case CutoverCode::accepted_reclamation_refused_order_gap: return "accepted_reclamation_refused_order_gap";
    case CutoverCode::accepted_equivocation_fail_stop: return "accepted_equivocation_fail_stop";
    case CutoverCode::accepted_regression_fail_stop: return "accepted_regression_fail_stop";
    case CutoverCode::invalid_terminal_state: return "invalid_terminal_state";
    case CutoverCode::parent_evidence_rejected: return "parent_evidence_rejected";
    case CutoverCode::cutover_id_zero: return "cutover_id_zero";
    case CutoverCode::witness_digest_zero: return "witness_digest_zero";
    case CutoverCode::floor_digest_zero: return "floor_digest_zero";
    case CutoverCode::reclamation_request_mismatch: return "reclamation_request_mismatch";
    case CutoverCode::join_receipt_shape_invalid: return "join_receipt_shape_invalid";
    case CutoverCode::join_cutover_id_mismatch: return "join_cutover_id_mismatch";
    case CutoverCode::join_request_id_mismatch: return "join_request_id_mismatch";
    case CutoverCode::join_transition_digest_mismatch: return "join_transition_digest_mismatch";
    case CutoverCode::join_register_incarnation_mismatch: return "join_register_incarnation_mismatch";
    case CutoverCode::join_terminal_digest_mismatch: return "join_terminal_digest_mismatch";
    case CutoverCode::join_terminal_kind_mismatch: return "join_terminal_kind_mismatch";
    case CutoverCode::join_witness_digest_mismatch: return "join_witness_digest_mismatch";
    case CutoverCode::join_floor_digest_mismatch: return "join_floor_digest_mismatch";
    case CutoverCode::trace_initial_state_invalid: return "trace_initial_state_invalid";
    case CutoverCode::trace_deleted_and_live: return "trace_deleted_and_live";
    case CutoverCode::trace_reopen_without_joined_basis: return "trace_reopen_without_joined_basis";
    case CutoverCode::trace_join_without_components: return "trace_join_without_components";
    case CutoverCode::trace_live_absent_without_deletion: return "trace_live_absent_without_deletion";
    }
    return "invalid";
}

std::string_view cut_name(const std::size_t index) noexcept {
    switch (index) {
    case 0U: return "T0_live";
    case 1U: return "T1_first_replacement";
    case 2U: return "T2_both_replacements";
    case 3U: return "T3_join";
    case 4U: return "T4_cold_reopen";
    case 5U: return "T5_authorize";
    case 6U: return "T6_delete";
    }
    return "invalid";
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover
