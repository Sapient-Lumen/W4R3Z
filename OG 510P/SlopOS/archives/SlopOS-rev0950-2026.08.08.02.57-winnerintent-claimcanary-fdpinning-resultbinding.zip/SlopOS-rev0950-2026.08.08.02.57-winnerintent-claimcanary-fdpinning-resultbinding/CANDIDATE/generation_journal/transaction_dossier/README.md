# Transaction dossier kernel

This nested C++20 project is a bounded construction inside the existing
`CANDIDATE/generation_journal` semantic island. It is not a fourth island, a
service, an authority API, or a living-project release.

It implements a fixed 448-byte codec for the six epoch-zero transaction record
types, a strict cross-record validator, a separately spelled C++ reference, an
independent Python reconstruction, four terminal fixtures, two appraisal-stop
prefixes, a finite negative corpus, and one deliberately valid coherent rewrite
showing that digest integrity is not authentication.


The validator vocabulary is intentionally narrower than the project epoch. A
six-record history can be `structurally_complete=true` and
`effect_bearing=true`; every hosted result must still report
`epoch_exit_proved=false` and `authority=false`. Structural completeness is not
owner admission, external spend proof, or living-project promotion.

Build and run in a writable worktree:

```sh
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build
./build/slopos_transaction_dossier campaign /tmp/slopos-dossier
python3 -B proof/verify_dossier.py /tmp/slopos-dossier
```

A complete effect-bearing dossier has exactly R1–R6 and requires R3 `PASS`.
R3 `REJECT` and `INDETERMINATE` are valid bounded three-record stops and may not
be followed by a permit. Every result remains `authority=false` because this
cloudtainer supplies no constituted owner, protected permit issuer, external
spend state, protected endpoint, or separately rooted reopener.
