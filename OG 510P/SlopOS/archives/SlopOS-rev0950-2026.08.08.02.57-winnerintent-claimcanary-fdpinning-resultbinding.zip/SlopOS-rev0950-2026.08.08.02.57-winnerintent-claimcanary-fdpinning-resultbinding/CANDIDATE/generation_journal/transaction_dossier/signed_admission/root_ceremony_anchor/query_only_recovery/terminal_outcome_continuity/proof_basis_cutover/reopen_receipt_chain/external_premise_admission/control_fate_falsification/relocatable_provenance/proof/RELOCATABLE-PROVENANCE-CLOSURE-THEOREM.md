# Relocatable Provenance Closure Theorem V1

Let `T` be a structurally valid trace whose parent is the exact accepted Control Fate Falsification trace with no common fate found in its **supplied** closure and whose live record remains retained.

If `T` contains:

- one exact logical source closure with portable, ordered, content-bound entries;
- one exact complete hosted build plan;
- a capsule that excludes physical locators and raw logs from its canonical subject;
- two exact build observations at distinct physical locators;
- equal canonical build-claim identities and equal output digests;
- independently administered exact-subject reopen receipts; and
- seven exact durable cuts, including the first receipt before the relocated claim;

then the relation accepts `T` as a **hosted relocation witness for that exact subject and output**.

The conclusion is intentionally weaker than “the build is reproducible.” It says only that the modeled host-path variation did not alter the canonical claim or output in this campaign. It does not quantify over all relevant environment variations, authenticate the source, establish builder trust, prove that the supplied control graph is complete, prove external occurrence, or grant authority.

The candidate evaluator uses ordered fail-fast validation. The reference evaluator first derives a declarative fact set, independently encodes every canonical object, independently validates portable paths, and then classifies the trace. The retained campaign requires exact agreement across 66 structured cases, 24 relocation pairs, and seven durable cuts.


## Hosted composition binding

The focused builder computes one exact root-relative `SOURCE-MANIFEST.tsv` from the current source closure before configuring any lane. It also emits exact build-plan, output-contract, parent-binding, logical-root, and claim-policy carriers. Their SHA-256 identities and byte counts are compile-time inputs to the C++ campaign and become the six ordered `SourceClosure` entries. The retained `COMPOSITION-RECEIPT.json` independently binds those entries to the actual three-lane CAS output set. This repairs the earlier split in which Python receipts named real source bytes while the C++ relation named invented labels. It still does not prove that the declared manifest is world-complete, that all environment inputs are known, or that an external trusted builder ran.
