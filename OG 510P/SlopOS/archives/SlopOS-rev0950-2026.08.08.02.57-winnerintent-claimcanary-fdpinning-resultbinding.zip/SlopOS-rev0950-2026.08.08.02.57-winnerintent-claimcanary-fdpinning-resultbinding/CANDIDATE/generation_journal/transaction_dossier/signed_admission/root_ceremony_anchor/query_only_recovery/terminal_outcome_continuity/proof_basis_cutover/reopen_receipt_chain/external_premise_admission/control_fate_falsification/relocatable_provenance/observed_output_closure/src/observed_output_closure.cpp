#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/reopen_receipt_chain/external_premise_admission/control_fate_falsification/relocatable_provenance/observed_output_closure.hpp"

#include "parent_output_set.hpp"
#include "slopos/e0/generation_journal/spend_record.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <span>
#include <string_view>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification::relocatable_provenance::observed_output_closure {
namespace {

#ifndef SLOPOS_OOC_PARENT_OUTPUT_CARRIER_SHA256_HEX
#error "focused build must bind the exact prior output-set carrier"
#endif
#ifndef SLOPOS_OOC_PARENT_OUTPUT_CARRIER_BYTES
#error "focused build must bind the exact prior output-set carrier bytes"
#endif
#ifndef SLOPOS_OOC_RESERVED_POLICY_SHA256_HEX
#error "focused build must bind the exact reserved-namespace policy"
#endif
#ifndef SLOPOS_OOC_REOPENER_IMPLEMENTATION_SHA256_HEX
#error "focused build must bind the exact hosted reopener implementation"
#endif

constexpr std::array<std::uint8_t, 32U> domain(const std::string_view text) noexcept {
    std::array<std::uint8_t, 32U> value{};
    const std::size_t count = std::min(text.size(), value.size());
    for (std::size_t index = 0U; index < count; ++index) value[index] = static_cast<std::uint8_t>(text[index]);
    return value;
}

inline constexpr auto manifest_domain = domain("SlopOS/OOC/output-manifest/v1");
inline constexpr auto publication_domain = domain("SlopOS/OOC/publication/v1");
inline constexpr auto reopen_domain = domain("SlopOS/OOC/reopen/v1");
inline constexpr auto claim_domain = domain("SlopOS/OOC/closure-claim/v1");

[[nodiscard]] bool nonzero(const Digest& value) noexcept {
    return std::any_of(value.begin(), value.end(), [](const std::uint8_t byte) { return byte != 0U; });
}

[[nodiscard]] constexpr std::uint8_t hex_nibble(const char value) noexcept {
    if (value >= '0' && value <= '9') return static_cast<std::uint8_t>(value - '0');
    if (value >= 'a' && value <= 'f') return static_cast<std::uint8_t>(value - 'a' + 10);
    return 0xffU;
}

[[nodiscard]] Digest exact_digest(const std::string_view value) noexcept {
    Digest output{};
    if (value.size() != 64U) return output;
    for (std::size_t index = 0U; index < output.size(); ++index) {
        const std::uint8_t high = hex_nibble(value[index * 2U]);
        const std::uint8_t low = hex_nibble(value[index * 2U + 1U]);
        if (high > 15U || low > 15U) return {};
        output[index] = static_cast<std::uint8_t>((high << 4U) | low);
    }
    return output;
}

[[nodiscard]] const Digest& expected_carrier_digest() noexcept {
    static const Digest value = exact_digest(SLOPOS_OOC_PARENT_OUTPUT_CARRIER_SHA256_HEX);
    return value;
}

[[nodiscard]] const Digest& expected_policy_digest() noexcept {
    static const Digest value = exact_digest(SLOPOS_OOC_RESERVED_POLICY_SHA256_HEX);
    return value;
}

[[nodiscard]] const Digest& expected_reopener_implementation_digest() noexcept {
    static const Digest value = exact_digest(SLOPOS_OOC_REOPENER_IMPLEMENTATION_SHA256_HEX);
    return value;
}

template <std::size_t N>
class Writer final {
public:
    explicit Writer(std::array<std::uint8_t, N>& bytes) noexcept : bytes_(bytes) { bytes_.fill(0U); }
    void u8(const std::uint8_t value) noexcept {
        if (position_ < body_end()) bytes_[position_++] = value;
        else overflow_ = true;
    }
    void u16(const std::uint16_t value) noexcept {
        u8(static_cast<std::uint8_t>((value >> 8U) & 0xffU));
        u8(static_cast<std::uint8_t>(value & 0xffU));
    }
    void u64(const std::uint64_t value) noexcept {
        for (std::size_t shift = 56U;; shift -= 8U) {
            u8(static_cast<std::uint8_t>((value >> shift) & 0xffU));
            if (shift == 0U) break;
        }
    }
    void boolean(const bool value) noexcept { u8(value ? 1U : 0U); }
    template <std::size_t M>
    void fixed(const std::array<std::uint8_t, M>& value) noexcept {
        for (const auto byte : value) u8(byte);
    }
    [[nodiscard]] bool seal() noexcept {
        if (overflow_) return false;
        while (position_ < body_end()) bytes_[position_++] = 0U;
        const Digest integrity = generation_journal::sha256(
            std::span<const std::uint8_t>(bytes_.data(), body_end()));
        std::copy(integrity.begin(), integrity.end(), bytes_.begin() + static_cast<std::ptrdiff_t>(body_end()));
        return true;
    }
private:
    [[nodiscard]] static constexpr std::size_t body_end() noexcept { return N - Digest{}.size(); }
    std::array<std::uint8_t, N>& bytes_;
    std::size_t position_{0U};
    bool overflow_{false};
};

template <std::size_t N>
[[nodiscard]] Digest encoded_identity(const std::array<std::uint8_t, N>& bytes) noexcept {
    return generation_journal::sha256(std::span<const std::uint8_t>(bytes.data(), bytes.size()));
}

[[nodiscard]] bool zero_entry(const OutputEntry& value) noexcept { return value == OutputEntry{}; }
[[nodiscard]] bool zero_publication(const ManifestPublicationReceipt& value) noexcept { return value == ManifestPublicationReceipt{}; }
[[nodiscard]] bool zero_reopen(const OutputSetReopenReceipt& value) noexcept { return value == OutputSetReopenReceipt{}; }
[[nodiscard]] bool zero_claim(const OutputClosureClaim& value) noexcept { return value == OutputClosureClaim{}; }

[[nodiscard]] int path_compare(const OutputEntry& left, const OutputEntry& right) noexcept {
    const std::size_t count = std::min<std::size_t>(left.path_length, right.path_length);
    for (std::size_t index = 0U; index < count; ++index) {
        if (left.path[index] < right.path[index]) return -1;
        if (left.path[index] > right.path[index]) return 1;
    }
    if (left.path_length < right.path_length) return -1;
    if (left.path_length > right.path_length) return 1;
    return 0;
}

[[nodiscard]] std::string_view path_view(const OutputEntry& value) noexcept {
    return std::string_view(reinterpret_cast<const char*>(value.path.data()), value.path_length);
}

[[nodiscard]] bool reserved_path(const OutputEntry& value) noexcept {
    const std::string_view path = path_view(value);
    using namespace slopos::e0::observed_output_closure_generated;
    return path == reserved_manifest || path == reserved_publication || path == reserved_reopen
        || path == reserved_claim || path.starts_with(reserved_prefix);
}

[[nodiscard]] bool manifest_shape(const OutputSetManifest& value) noexcept {
    if (!value.present || !value.canonical || !value.exact_prior_set || !value.complete
        || !value.reserved_namespace_excluded || value.entry_count != expected_parent_output_entries
        || !nonzero(value.manifest_digest) || !nonzero(value.parent_relocated_receipt_digest)
        || !nonzero(value.parent_build_claim_digest) || !nonzero(value.parent_provenance_output_digest)
        || !nonzero(value.parent_output_carrier_digest) || !nonzero(value.reserved_namespace_policy_digest)) {
        return false;
    }
    for (std::size_t index = value.entry_count; index < value.entries.size(); ++index) {
        if (!zero_entry(value.entries[index])) return false;
    }
    return true;
}

[[nodiscard]] bool paths_valid(const OutputSetManifest& value) noexcept {
    for (std::size_t index = 0U; index < value.entry_count; ++index) {
        if (!portable_output_path_valid(value.entries[index])) return false;
        if (index > 0U && path_compare(value.entries[index - 1U], value.entries[index]) >= 0) return false;
    }
    return true;
}

[[nodiscard]] bool entries_valid(const OutputSetManifest& value) noexcept {
    for (std::size_t index = 0U; index < value.entry_count; ++index) {
        const auto& entry = value.entries[index];
        if (!entry.present || !entry.regular_file || entry.reserved_namespace || !nonzero(entry.content_digest)
            || entry.bytes == 0U || (entry.mode != output_mode_read_only && entry.mode != output_mode_read_execute)) {
            return false;
        }
    }
    return true;
}

[[nodiscard]] bool exact_parent_entry(const OutputEntry& value, const std::size_t index) noexcept {
    using slopos::e0::observed_output_closure_generated::parent_output_entries;
    if (index >= parent_output_entries.size()) return false;
    const auto& expected = parent_output_entries[index];
    return path_view(value) == expected.path && value.content_digest == exact_digest(expected.sha256)
        && value.bytes == expected.bytes && value.mode == expected.mode && value.present
        && value.regular_file && !value.reserved_namespace;
}

[[nodiscard]] bool exact_parent_set(const OutputSetManifest& value) noexcept {
    if (value.entry_count != expected_parent_output_entries
        || value.parent_output_carrier_digest != expected_carrier_digest()
        || value.reserved_namespace_policy_digest != expected_policy_digest()) return false;
    for (std::size_t index = 0U; index < value.entry_count; ++index) {
        if (!exact_parent_entry(value.entries[index], index)) return false;
    }
    return true;
}

[[nodiscard]] bool publication_shape(const ManifestPublicationReceipt& value) noexcept {
    return value.present && value.durable && value.no_replace_publication && value.single_view_reopened
        && value.exact_carrier_published && value.carrier_bytes == SLOPOS_OOC_PARENT_OUTPUT_CARRIER_BYTES
        && nonzero(value.receipt_digest) && nonzero(value.manifest_digest)
        && nonzero(value.parent_relocated_receipt_digest) && nonzero(value.parent_output_carrier_digest)
        && nonzero(value.publisher_digest);
}

[[nodiscard]] bool reopen_shape(const OutputSetReopenReceipt& value) noexcept {
    return value.present && value.durable && value.separate_reopener_role
        && value.exact_manifest_reopened && value.all_entries_rehashed
        && value.carrier_bytes == SLOPOS_OOC_PARENT_OUTPUT_CARRIER_BYTES
        && nonzero(value.receipt_digest) && nonzero(value.publication_receipt_digest)
        && nonzero(value.manifest_digest) && nonzero(value.parent_output_carrier_digest)
        && nonzero(value.reopener_digest) && nonzero(value.reopener_implementation_digest);
}

[[nodiscard]] bool claim_shape(const OutputClosureClaim& value) noexcept {
    return value.present && value.durable && value.exact_prior_output_set_claimed
        && value.child_products_outside_subject && value.no_self_digest_transform_claimed
        && nonzero(value.claim_digest) && nonzero(value.parent_relocated_receipt_digest)
        && nonzero(value.parent_build_claim_digest) && nonzero(value.manifest_digest)
        && nonzero(value.publication_receipt_digest) && nonzero(value.reopen_receipt_digest)
        && nonzero(value.reserved_namespace_policy_digest);
}

[[nodiscard]] bool cuts_exact(const OutputClosureTrace& trace) noexcept {
    for (std::size_t index = 0U; index < trace.cuts.size(); ++index) {
        OutputClosureCut expected{};
        expected.parent_output_carrier_digest = expected_carrier_digest();
        if (trace.manifest.present && index >= 1U) expected.manifest_digest = trace.manifest.manifest_digest;
        if (trace.publication.present && index >= 2U) expected.publication_receipt_digest = trace.publication.receipt_digest;
        if (trace.reopen.present && index >= 3U) expected.reopen_receipt_digest = trace.reopen.receipt_digest;
        if (trace.claim.present && index >= 4U) expected.closure_claim_digest = trace.claim.claim_digest;
        if (trace.cuts[index] != expected) return false;
    }
    return true;
}

[[nodiscard]] ClosureReport base_report(
    const ClosureCode code,
    const bool parent_accepted,
    const bool parent_exact,
    const bool parent_binding) noexcept {
    ClosureReport report{};
    report.code = code;
    report.parent_accepted = parent_accepted;
    report.parent_relocated_exact_subject = parent_exact;
    report.parent_binding_valid = parent_binding;
    return report;
}

[[nodiscard]] ClosureReport accepted_stage(
    const ClosureCode code,
    const bool manifest,
    const bool publication,
    const bool reopen,
    const bool claim) noexcept {
    ClosureReport report{};
    report.code = code;
    report.accepted = true;
    report.parent_accepted = true;
    report.parent_relocated_exact_subject = true;
    report.parent_binding_valid = true;
    report.manifest_valid = manifest;
    report.exact_parent_output_set = manifest;
    report.reserved_namespace_excluded = manifest;
    report.manifest_identity_valid = manifest;
    report.publication_valid = publication;
    report.publication_identity_valid = publication;
    report.reopen_valid = reopen;
    report.reopen_identity_valid = reopen;
    report.claim_valid = claim;
    report.claim_identity_valid = claim;
    report.cuts_ordered = true;
    report.closure_ready = claim;
    report.child_products_outside_subject = claim;
    return report;
}

}  // namespace

bool portable_output_path_valid(const OutputEntry& entry) noexcept {
    if (entry.path_length == 0U || entry.path_length > entry.path.size()) return false;
    if (entry.path[0] == static_cast<std::uint8_t>('/') || entry.path[entry.path_length - 1U] == static_cast<std::uint8_t>('/')) return false;
    bool previous_slash = false;
    std::size_t component_start = 0U;
    for (std::size_t index = 0U; index < entry.path_length; ++index) {
        const std::uint8_t byte = entry.path[index];
        if (byte < 0x21U || byte > 0x7eU || byte == static_cast<std::uint8_t>('\\')) return false;
        const bool slash = byte == static_cast<std::uint8_t>('/');
        if (slash && previous_slash) return false;
        if (slash) {
            const std::size_t length = index - component_start;
            if ((length == 1U && entry.path[component_start] == '.')
                || (length == 2U && entry.path[component_start] == '.' && entry.path[component_start + 1U] == '.')) return false;
            component_start = index + 1U;
        }
        previous_slash = slash;
    }
    const std::size_t length = entry.path_length - component_start;
    if ((length == 1U && entry.path[component_start] == '.')
        || (length == 2U && entry.path[component_start] == '.' && entry.path[component_start + 1U] == '.')) return false;
    for (std::size_t index = entry.path_length; index < entry.path.size(); ++index) {
        if (entry.path[index] != 0U) return false;
    }
    return true;
}

bool encode_output_manifest(const OutputSetManifest& value, EncodedOutputManifest& output) noexcept {
    Writer<encoded_output_manifest_bytes> writer(output);
    writer.fixed(manifest_domain);
    writer.fixed(value.parent_relocated_receipt_digest);
    writer.fixed(value.parent_build_claim_digest);
    writer.fixed(value.parent_provenance_output_digest);
    writer.fixed(value.parent_output_carrier_digest);
    writer.fixed(value.reserved_namespace_policy_digest);
    writer.u8(value.entry_count);
    writer.boolean(value.present);
    writer.boolean(value.canonical);
    writer.boolean(value.exact_prior_set);
    writer.boolean(value.complete);
    writer.boolean(value.reserved_namespace_excluded);
    for (const auto& entry : value.entries) {
        writer.fixed(entry.path);
        writer.fixed(entry.content_digest);
        writer.u64(entry.bytes);
        writer.u16(entry.mode);
        writer.u8(entry.path_length);
        writer.boolean(entry.present);
        writer.boolean(entry.regular_file);
        writer.boolean(entry.reserved_namespace);
    }
    return writer.seal();
}

Digest output_manifest_identity(const OutputSetManifest& value) noexcept {
    EncodedOutputManifest bytes{};
    if (!encode_output_manifest(value, bytes)) return {};
    return encoded_identity(bytes);
}

bool encode_publication_receipt(const ManifestPublicationReceipt& value, EncodedPublicationReceipt& output) noexcept {
    Writer<encoded_publication_receipt_bytes> writer(output);
    writer.fixed(publication_domain);
    writer.fixed(value.manifest_digest);
    writer.fixed(value.parent_relocated_receipt_digest);
    writer.fixed(value.parent_output_carrier_digest);
    writer.fixed(value.publisher_digest);
    writer.u64(value.carrier_bytes);
    writer.boolean(value.present);
    writer.boolean(value.durable);
    writer.boolean(value.no_replace_publication);
    writer.boolean(value.single_view_reopened);
    writer.boolean(value.exact_carrier_published);
    return writer.seal();
}

Digest publication_receipt_identity(const ManifestPublicationReceipt& value) noexcept {
    EncodedPublicationReceipt bytes{};
    if (!encode_publication_receipt(value, bytes)) return {};
    return encoded_identity(bytes);
}

bool encode_output_reopen_receipt(const OutputSetReopenReceipt& value, EncodedOutputReopenReceipt& output) noexcept {
    Writer<encoded_output_reopen_receipt_bytes> writer(output);
    writer.fixed(reopen_domain);
    writer.fixed(value.publication_receipt_digest);
    writer.fixed(value.manifest_digest);
    writer.fixed(value.parent_output_carrier_digest);
    writer.fixed(value.reopener_digest);
    writer.fixed(value.reopener_implementation_digest);
    writer.u64(value.carrier_bytes);
    writer.boolean(value.present);
    writer.boolean(value.durable);
    writer.boolean(value.separate_reopener_role);
    writer.boolean(value.exact_manifest_reopened);
    writer.boolean(value.all_entries_rehashed);
    return writer.seal();
}

Digest output_reopen_receipt_identity(const OutputSetReopenReceipt& value) noexcept {
    EncodedOutputReopenReceipt bytes{};
    if (!encode_output_reopen_receipt(value, bytes)) return {};
    return encoded_identity(bytes);
}

bool encode_output_closure_claim(const OutputClosureClaim& value, EncodedOutputClosureClaim& output) noexcept {
    Writer<encoded_output_closure_claim_bytes> writer(output);
    writer.fixed(claim_domain);
    writer.fixed(value.parent_relocated_receipt_digest);
    writer.fixed(value.parent_build_claim_digest);
    writer.fixed(value.manifest_digest);
    writer.fixed(value.publication_receipt_digest);
    writer.fixed(value.reopen_receipt_digest);
    writer.fixed(value.reserved_namespace_policy_digest);
    writer.boolean(value.present);
    writer.boolean(value.durable);
    writer.boolean(value.exact_prior_output_set_claimed);
    writer.boolean(value.child_products_outside_subject);
    writer.boolean(value.no_self_digest_transform_claimed);
    return writer.seal();
}

Digest output_closure_claim_identity(const OutputClosureClaim& value) noexcept {
    EncodedOutputClosureClaim bytes{};
    if (!encode_output_closure_claim(value, bytes)) return {};
    return encoded_identity(bytes);
}

ClosureReport evaluate_candidate(const OutputClosureTrace& trace) noexcept {
    const ProvenanceReport parent = relocatable_provenance::evaluate_candidate(trace.parent);
    if (!parent.accepted) return base_report(ClosureCode::parent_rejected, false, false, false);
    const bool parent_exact = parent.code == ProvenanceCode::accepted_relocated_exact_subject && parent.relocation_witness;
    if (!parent_exact) return base_report(ClosureCode::parent_not_relocated_exact_subject, true, false, false);

    if (!trace.manifest.present) {
        if (!zero_publication(trace.publication) || !zero_reopen(trace.reopen) || !zero_claim(trace.claim)) {
            return base_report(ClosureCode::publication_without_manifest, true, true, false);
        }
        if (!cuts_exact(trace)) return base_report(ClosureCode::output_cut_order_invalid, true, true, false);
        return accepted_stage(ClosureCode::accepted_prior_output_durable, false, false, false, false);
    }

    const bool parent_binding = trace.manifest.parent_relocated_receipt_digest == trace.parent.relocated_receipt.receipt_digest
        && trace.manifest.parent_build_claim_digest == trace.parent.relocated_observation.claim_digest
        && trace.manifest.parent_provenance_output_digest == trace.parent.relocated_observation.output_digest;
    if (!parent_binding) return base_report(ClosureCode::parent_binding_mismatch, true, true, false);
    if (!manifest_shape(trace.manifest)) return base_report(ClosureCode::manifest_shape_invalid, true, true, true);
    if (!paths_valid(trace.manifest)) {
        bool invalid = false;
        bool duplicate = false;
        for (std::size_t index = 0U; index < trace.manifest.entry_count; ++index) {
            invalid = invalid || !portable_output_path_valid(trace.manifest.entries[index]);
            if (index > 0U) duplicate = duplicate || path_compare(trace.manifest.entries[index - 1U], trace.manifest.entries[index]) == 0;
        }
        return base_report(invalid ? ClosureCode::output_path_invalid
                                  : (duplicate ? ClosureCode::output_path_duplicate : ClosureCode::output_path_order_invalid), true, true, true);
    }
    if (!entries_valid(trace.manifest)) return base_report(ClosureCode::output_entry_invalid, true, true, true);
    for (std::size_t index = 0U; index < trace.manifest.entry_count; ++index) {
        if (reserved_path(trace.manifest.entries[index])) return base_report(ClosureCode::reserved_namespace_in_subject, true, true, true);
    }
    if (!trace.manifest.reserved_namespace_excluded
        || trace.manifest.reserved_namespace_policy_digest != expected_policy_digest()) {
        return base_report(ClosureCode::self_reference_policy_mismatch, true, true, true);
    }
    if (!exact_parent_set(trace.manifest)) return base_report(ClosureCode::output_set_not_exact_parent, true, true, true);
    if (trace.manifest.manifest_digest != output_manifest_identity(trace.manifest)) {
        return base_report(ClosureCode::manifest_digest_mismatch, true, true, true);
    }

    if (!trace.publication.present) {
        if (!zero_reopen(trace.reopen) || !zero_claim(trace.claim)) return base_report(ClosureCode::reopen_without_publication, true, true, true);
        if (!cuts_exact(trace)) return base_report(ClosureCode::output_cut_order_invalid, true, true, true);
        return accepted_stage(ClosureCode::accepted_manifest_durable, true, false, false, false);
    }
    if (!publication_shape(trace.publication)) return base_report(ClosureCode::publication_shape_invalid, true, true, true);
    if (trace.publication.manifest_digest != trace.manifest.manifest_digest
        || trace.publication.parent_relocated_receipt_digest != trace.parent.relocated_receipt.receipt_digest
        || trace.publication.parent_output_carrier_digest != expected_carrier_digest()) {
        return base_report(ClosureCode::publication_binding_mismatch, true, true, true);
    }
    if (trace.publication.receipt_digest != publication_receipt_identity(trace.publication)) {
        return base_report(ClosureCode::publication_digest_mismatch, true, true, true);
    }

    if (!trace.reopen.present) {
        if (!zero_claim(trace.claim)) return base_report(ClosureCode::claim_without_reopen, true, true, true);
        if (!cuts_exact(trace)) return base_report(ClosureCode::output_cut_order_invalid, true, true, true);
        return accepted_stage(ClosureCode::accepted_publication_durable, true, true, false, false);
    }
    if (!reopen_shape(trace.reopen)) return base_report(ClosureCode::reopen_shape_invalid, true, true, true);
    if (trace.reopen.publication_receipt_digest != trace.publication.receipt_digest
        || trace.reopen.manifest_digest != trace.manifest.manifest_digest
        || trace.reopen.parent_output_carrier_digest != expected_carrier_digest()
        || trace.reopen.reopener_digest == trace.publication.publisher_digest
        || trace.reopen.reopener_implementation_digest != expected_reopener_implementation_digest()) {
        return base_report(ClosureCode::reopen_binding_mismatch, true, true, true);
    }
    if (trace.reopen.receipt_digest != output_reopen_receipt_identity(trace.reopen)) {
        return base_report(ClosureCode::reopen_digest_mismatch, true, true, true);
    }

    if (!trace.claim.present) {
        if (!cuts_exact(trace)) return base_report(ClosureCode::output_cut_order_invalid, true, true, true);
        return accepted_stage(ClosureCode::accepted_reopen_durable, true, true, true, false);
    }
    if (!claim_shape(trace.claim)) return base_report(ClosureCode::claim_shape_invalid, true, true, true);
    if (trace.claim.parent_relocated_receipt_digest != trace.parent.relocated_receipt.receipt_digest
        || trace.claim.parent_build_claim_digest != trace.parent.relocated_observation.claim_digest
        || trace.claim.manifest_digest != trace.manifest.manifest_digest
        || trace.claim.publication_receipt_digest != trace.publication.receipt_digest
        || trace.claim.reopen_receipt_digest != trace.reopen.receipt_digest
        || trace.claim.reserved_namespace_policy_digest != expected_policy_digest()) {
        return base_report(ClosureCode::claim_binding_mismatch, true, true, true);
    }
    if (trace.claim.claim_digest != output_closure_claim_identity(trace.claim)) {
        return base_report(ClosureCode::claim_digest_mismatch, true, true, true);
    }
    if (!cuts_exact(trace)) return base_report(ClosureCode::output_cut_order_invalid, true, true, true);
    return accepted_stage(ClosureCode::accepted_closed_output_set, true, true, true, true);
}

std::string_view closure_code_name(const ClosureCode value) noexcept {
    switch (value) {
        case ClosureCode::accepted_prior_output_durable: return "accepted_prior_output_durable";
        case ClosureCode::accepted_manifest_durable: return "accepted_manifest_durable";
        case ClosureCode::accepted_publication_durable: return "accepted_publication_durable";
        case ClosureCode::accepted_reopen_durable: return "accepted_reopen_durable";
        case ClosureCode::accepted_closed_output_set: return "accepted_closed_output_set";
        case ClosureCode::parent_rejected: return "parent_rejected";
        case ClosureCode::parent_not_relocated_exact_subject: return "parent_not_relocated_exact_subject";
        case ClosureCode::parent_binding_mismatch: return "parent_binding_mismatch";
        case ClosureCode::manifest_shape_invalid: return "manifest_shape_invalid";
        case ClosureCode::output_path_invalid: return "output_path_invalid";
        case ClosureCode::output_path_duplicate: return "output_path_duplicate";
        case ClosureCode::output_path_order_invalid: return "output_path_order_invalid";
        case ClosureCode::output_entry_invalid: return "output_entry_invalid";
        case ClosureCode::reserved_namespace_in_subject: return "reserved_namespace_in_subject";
        case ClosureCode::output_set_not_exact_parent: return "output_set_not_exact_parent";
        case ClosureCode::self_reference_policy_mismatch: return "self_reference_policy_mismatch";
        case ClosureCode::manifest_digest_mismatch: return "manifest_digest_mismatch";
        case ClosureCode::publication_without_manifest: return "publication_without_manifest";
        case ClosureCode::publication_shape_invalid: return "publication_shape_invalid";
        case ClosureCode::publication_binding_mismatch: return "publication_binding_mismatch";
        case ClosureCode::publication_digest_mismatch: return "publication_digest_mismatch";
        case ClosureCode::reopen_without_publication: return "reopen_without_publication";
        case ClosureCode::reopen_shape_invalid: return "reopen_shape_invalid";
        case ClosureCode::reopen_binding_mismatch: return "reopen_binding_mismatch";
        case ClosureCode::reopen_digest_mismatch: return "reopen_digest_mismatch";
        case ClosureCode::claim_without_reopen: return "claim_without_reopen";
        case ClosureCode::claim_shape_invalid: return "claim_shape_invalid";
        case ClosureCode::claim_binding_mismatch: return "claim_binding_mismatch";
        case ClosureCode::claim_digest_mismatch: return "claim_digest_mismatch";
        case ClosureCode::output_cut_order_invalid: return "output_cut_order_invalid";
    }
    return "unknown";
}

std::string_view output_cut_name(const std::size_t index) noexcept {
    constexpr std::array<std::string_view, output_cut_count> names{{
        "parent_output_set_durable", "manifest_durable", "publication_receipt_durable",
        "hosted_reopener_receipt_durable", "closure_claim_durable",
    }};
    return index < names.size() ? names[index] : std::string_view{"unknown"};
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification::relocatable_provenance::observed_output_closure
