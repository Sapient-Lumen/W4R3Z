
# Terminal Outcome Continuity V1

**Plane:** LAB. **Epoch:** Zero. **Authority:** false.

This nested C++20 relation decomposes the inherited Boolean
`retention_covers_reopen` into two independent obligations:

1. **duplicate execution excluded** — the exact old or pending request can no
   longer execute or re-execute after reclamation, restore, or succession; and
2. **terminal outcome reopenable** — a separately governed future reopener can
   still reconstruct the exact terminal `EFFECT` or `NO_EFFECT` outcome.

Neither half implies the other. A monotone successor/incarnation floor may
reject old requests while destroying their result history. An archived result
may preserve history while a restored pre-terminal incarnation can execute the
old request. Terminal continuity is the conjunction. Reclamation is safe only
through an exact retained witness plus a successor floor that is monotone,
outside the rollback domain, binds the request namespace, fences already
pending invocations, survives restore and succession, and has one current view.

Client acknowledgement and elapsed TTL are modeled but never sufficient. The
relation is a finite hosted proof, not a database, provider adapter, garbage
collector, lease service, retirement daemon, signer, currentness oracle, or
authority API. It performs no external reclamation and proves no external fact.

## Build and run

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build
./build/slopos_terminal_outcome_continuity output
python3 -B proof/verify_terminal_outcome_continuity.py output
```

`SLOPOS_ENABLE_SANITIZERS=ON` enables AddressSanitizer and
UndefinedBehaviorSanitizer. Retained evidence is produced by GCC, Clang, and a
Clang sanitizer lane, compared byte-for-byte, and cold-reopened by the
independent Python evaluator.
