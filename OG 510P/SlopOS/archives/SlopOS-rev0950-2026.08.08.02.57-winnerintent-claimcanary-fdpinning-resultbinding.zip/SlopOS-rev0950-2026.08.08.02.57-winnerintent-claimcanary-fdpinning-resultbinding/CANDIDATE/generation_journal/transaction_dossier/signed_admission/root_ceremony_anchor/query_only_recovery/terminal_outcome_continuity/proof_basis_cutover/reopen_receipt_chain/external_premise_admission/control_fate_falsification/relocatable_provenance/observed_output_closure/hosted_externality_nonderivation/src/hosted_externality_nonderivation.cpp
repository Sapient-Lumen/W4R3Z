#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/reopen_receipt_chain/external_premise_admission/control_fate_falsification/relocatable_provenance/observed_output_closure/hosted_externality_nonderivation.hpp"

#include "slopos/e0/generation_journal/spend_record.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <span>
#include <string_view>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification::relocatable_provenance::observed_output_closure::hosted_externality_nonderivation {
namespace {

#ifndef SLOPOS_HEN_CLAIM_CATALOGUE_SHA256_HEX
#error "exact claim catalogue binding required"
#endif
#ifndef SLOPOS_HEN_HANDOFF_POLICY_SHA256_HEX
#error "exact handoff policy binding required"
#endif
#ifndef SLOPOS_HEN_RESPONSE_PROFILE_SHA256_HEX
#error "exact response profile binding required"
#endif
#ifndef SLOPOS_HEN_LINKED_PARENT_ARCHIVE_SHA256_HEX
#error "exact linked parent archive binding required"
#endif
#ifndef SLOPOS_HEN_LINKED_PARENT_ARCHIVE_BYTES
#error "exact linked parent archive byte count required"
#endif
#ifndef SLOPOS_HEN_LINKED_PARENT_MANIFEST_ROWS
#error "exact linked parent manifest rows required"
#endif

[[nodiscard]] constexpr std::uint8_t hex_nibble(const char value) noexcept {
    if (value >= '0' && value <= '9') return static_cast<std::uint8_t>(value - '0');
    if (value >= 'a' && value <= 'f') return static_cast<std::uint8_t>(value - 'a' + 10);
    return 0xffU;
}

[[nodiscard]] Digest exact_digest(const std::string_view value) noexcept {
    Digest output{};
    if (value.size() != 64U) return output;
    for (std::size_t index = 0U; index < output.size(); ++index) {
        const auto high = hex_nibble(value[index * 2U]);
        const auto low = hex_nibble(value[index * 2U + 1U]);
        if (high > 15U || low > 15U) return {};
        output[index] = static_cast<std::uint8_t>((high << 4U) | low);
    }
    return output;
}

[[nodiscard]] bool nonzero(const Digest& value) noexcept {
    std::uint8_t aggregate = 0U;
    for (const auto byte : value) aggregate = static_cast<std::uint8_t>(aggregate | byte);
    return aggregate != 0U;
}

template <std::size_t Size>
class CanonicalWriter final {
public:
    explicit CanonicalWriter(std::array<std::uint8_t, Size>& output) noexcept : output_(output) {
        output_.fill(0U);
    }

    void magic(const std::string_view value) noexcept {
        for (std::size_t index = 0U; index < 8U; ++index) put_u8(index < value.size() ? static_cast<std::uint8_t>(value[index]) : 0U);
    }
    void u16(const std::uint16_t value) noexcept {
        put_u8(static_cast<std::uint8_t>((value >> 8U) & 0xffU));
        put_u8(static_cast<std::uint8_t>(value & 0xffU));
    }
    void u32(const std::uint32_t value) noexcept {
        put_u8(static_cast<std::uint8_t>((value >> 24U) & 0xffU));
        put_u8(static_cast<std::uint8_t>((value >> 16U) & 0xffU));
        put_u8(static_cast<std::uint8_t>((value >> 8U) & 0xffU));
        put_u8(static_cast<std::uint8_t>(value & 0xffU));
    }
    void u64(const std::uint64_t value) noexcept {
        for (unsigned shift = 56U;; shift -= 8U) {
            put_u8(static_cast<std::uint8_t>((value >> shift) & 0xffU));
            if (shift == 0U) break;
        }
    }
    void digest(const Digest& value) noexcept {
        for (const auto byte : value) put_u8(byte);
    }
    [[nodiscard]] bool pad_to_end() noexcept {
        while (offset_ < Size) put_u8(0U);
        return valid_ && offset_ == Size;
    }

private:
    void put_u8(const std::uint8_t value) noexcept {
        if (offset_ >= Size) {
            valid_ = false;
            return;
        }
        output_[offset_++] = value;
    }

    std::array<std::uint8_t, Size>& output_;
    std::size_t offset_{0U};
    bool valid_{true};
};

[[nodiscard]] Digest digest_bytes(const std::span<const std::uint8_t> bytes) noexcept {
    return generation_journal::sha256(bytes);
}

[[nodiscard]] std::uint16_t observation_flags(const HostedObservation& value) noexcept {
    return static_cast<std::uint16_t>((value.present ? 1U : 0U)
        | (value.canonical ? 2U : 0U)
        | (value.hosted_bytes_only ? 4U : 0U)
        | (value.external_receipt_absent ? 8U : 0U));
}

[[nodiscard]] std::uint16_t witness_flags(const TwinWorldWitness& value) noexcept {
    return static_cast<std::uint16_t>((value.present ? 1U : 0U)
        | (value.canonical ? 2U : 0U)
        | (value.countermodel_only ? 4U : 0U)
        | (value.no_external_occurrence_claimed ? 8U : 0U));
}

[[nodiscard]] std::uint16_t request_flags(const OwnerHandoffRequest& value) noexcept {
    return static_cast<std::uint16_t>((value.present ? 1U : 0U)
        | (value.canonical ? 2U : 0U)
        | (value.request_only ? 4U : 0U)
        | (value.no_authority_claim ? 8U : 0U));
}

[[nodiscard]] std::uint16_t deficit_flags(const PremiseDeficitCertificate& value) noexcept {
    return static_cast<std::uint16_t>((value.present ? 1U : 0U)
        | (value.canonical ? 2U : 0U)
        | (value.all_requested_claims_unresolved ? 4U : 0U)
        | (value.external_response_absent ? 8U : 0U)
        | (value.no_acceptance_or_authority ? 16U : 0U));
}

[[nodiscard]] bool valid_claim_mask(const std::uint16_t value) noexcept {
    return value != 0U && (value & static_cast<std::uint16_t>(~all_external_claims_mask)) == 0U;
}

[[nodiscard]] bool valid_fact_set(const ExternalFacts& value) noexcept {
    return value.canonical && (value.true_mask & static_cast<std::uint16_t>(~all_external_claims_mask)) == 0U;
}

[[nodiscard]] bool observation_shape(const HostedObservation& value) noexcept {
    return value.present && value.canonical && value.hosted_bytes_only && value.external_receipt_absent
        && value.schema_version == externality_schema_version
        && value.linked_parent_archive_bytes == SLOPOS_HEN_LINKED_PARENT_ARCHIVE_BYTES
        && value.linked_parent_manifest_rows == SLOPOS_HEN_LINKED_PARENT_MANIFEST_ROWS;
}

[[nodiscard]] bool observation_binding(const HostedObservation& value, const OutputClosureTrace& parent) noexcept {
    return value.parent_closure_claim_digest == parent.claim.claim_digest
        && value.parent_manifest_digest == parent.manifest.manifest_digest
        && value.parent_publication_receipt_digest == parent.publication.receipt_digest
        && value.parent_reopen_receipt_digest == parent.reopen.receipt_digest
        && value.linked_parent_archive_digest == exact_digest(SLOPOS_HEN_LINKED_PARENT_ARCHIVE_SHA256_HEX)
        && value.claim_catalogue_digest == exact_digest(SLOPOS_HEN_CLAIM_CATALOGUE_SHA256_HEX)
        && value.handoff_policy_digest == exact_digest(SLOPOS_HEN_HANDOFF_POLICY_SHA256_HEX);
}

[[nodiscard]] bool witness_shape(const TwinWorldWitness& value) noexcept {
    return value.present && value.canonical && value.countermodel_only && value.no_external_occurrence_claimed
        && value.schema_version == externality_schema_version && valid_claim_mask(value.requested_claim_mask)
        && nonzero(value.left_world_label_digest) && nonzero(value.right_world_label_digest)
        && value.left_world_label_digest != value.right_world_label_digest;
}

[[nodiscard]] bool witness_binding(
    const TwinWorldWitness& value,
    const HostedObservation& observation,
    const ExternalFacts& left,
    const ExternalFacts& right,
    const OutputClosureTrace& parent) noexcept {
    return value.observation_digest == observation.observation_digest
        && value.claim_catalogue_digest == observation.claim_catalogue_digest
        && value.handoff_policy_digest == observation.handoff_policy_digest
        && value.parent_closure_claim_digest == parent.claim.claim_digest
        && value.requested_claim_mask == observation.requested_claim_mask
        && value.left_true_mask == left.true_mask
        && value.right_true_mask == right.true_mask;
}

[[nodiscard]] bool request_shape(const OwnerHandoffRequest& value) noexcept {
    return value.present && value.canonical && value.request_only && value.no_authority_claim
        && value.schema_version == externality_schema_version
        && value.linked_parent_archive_bytes == SLOPOS_HEN_LINKED_PARENT_ARCHIVE_BYTES
        && value.linked_parent_manifest_rows == SLOPOS_HEN_LINKED_PARENT_MANIFEST_ROWS
        && nonzero(value.response_namespace_digest);
}

[[nodiscard]] bool request_binding(
    const OwnerHandoffRequest& value,
    const HostedObservation& observation,
    const TwinWorldWitness& witness,
    const OutputClosureTrace& parent) noexcept {
    return value.linked_parent_archive_digest == exact_digest(SLOPOS_HEN_LINKED_PARENT_ARCHIVE_SHA256_HEX)
        && value.parent_closure_claim_digest == parent.claim.claim_digest
        && value.observation_digest == observation.observation_digest
        && value.witness_digest == witness.witness_digest
        && value.claim_catalogue_digest == exact_digest(SLOPOS_HEN_CLAIM_CATALOGUE_SHA256_HEX)
        && value.handoff_policy_digest == exact_digest(SLOPOS_HEN_HANDOFF_POLICY_SHA256_HEX)
        && value.requested_response_profile_digest == exact_digest(SLOPOS_HEN_RESPONSE_PROFILE_SHA256_HEX)
        && value.requested_claim_mask == observation.requested_claim_mask;
}

[[nodiscard]] bool deficit_shape(const PremiseDeficitCertificate& value) noexcept {
    return value.present && value.canonical && value.all_requested_claims_unresolved
        && value.external_response_absent && value.no_acceptance_or_authority
        && value.schema_version == externality_schema_version && valid_claim_mask(value.unresolved_claim_mask);
}

[[nodiscard]] bool deficit_binding(
    const PremiseDeficitCertificate& value,
    const HostedObservation& observation,
    const TwinWorldWitness& witness,
    const OwnerHandoffRequest& request,
    const OutputClosureTrace& parent) noexcept {
    return value.observation_digest == observation.observation_digest
        && value.witness_digest == witness.witness_digest
        && value.request_digest == request.request_digest
        && value.parent_closure_claim_digest == parent.claim.claim_digest
        && value.claim_catalogue_digest == exact_digest(SLOPOS_HEN_CLAIM_CATALOGUE_SHA256_HEX)
        && value.handoff_policy_digest == exact_digest(SLOPOS_HEN_HANDOFF_POLICY_SHA256_HEX)
        && value.requested_response_profile_digest == exact_digest(SLOPOS_HEN_RESPONSE_PROFILE_SHA256_HEX)
        && value.unresolved_claim_mask == observation.requested_claim_mask;
}

[[nodiscard]] bool cuts_match(const ExternalityTrace& trace) noexcept {
    std::array<ExternalityCut, externality_cut_count> expected{};
    for (std::size_t index = 0U; index < expected.size(); ++index) {
        expected[index].parent_closure_claim_digest = trace.parent.claim.claim_digest;
        if (trace.left_observation.present && trace.right_observation.present && index >= 1U) {
            expected[index].observation_digest = trace.left_observation.observation_digest;
        }
        if (trace.witness.present && index >= 2U) expected[index].witness_digest = trace.witness.witness_digest;
        if (trace.request.present && index >= 3U) expected[index].request_digest = trace.request.request_digest;
        if (trace.deficit.present && index >= 4U) expected[index].deficit_certificate_digest = trace.deficit.certificate_digest;
    }
    return trace.cuts == expected;
}

[[nodiscard]] BoundaryReport reject(const BoundaryReport& partial, const BoundaryCode code) noexcept {
    BoundaryReport output = partial;
    output.code = code;
    output.accepted = false;
    return output;
}

[[nodiscard]] BoundaryReport accept(const BoundaryReport& partial, const BoundaryCode code) noexcept {
    BoundaryReport output = partial;
    output.code = code;
    output.accepted = true;
    return output;
}

}  // namespace

bool encode_hosted_observation(const HostedObservation& value, EncodedHostedObservation& output) noexcept {
    CanonicalWriter<encoded_hosted_observation_bytes> writer(output);
    writer.magic("SLOPHO1");
    writer.u32(value.schema_version);
    writer.u16(value.requested_claim_mask);
    writer.u16(observation_flags(value));
    writer.u64(value.linked_parent_archive_bytes);
    writer.u64(value.linked_parent_manifest_rows);
    writer.digest(value.parent_closure_claim_digest);
    writer.digest(value.parent_manifest_digest);
    writer.digest(value.parent_publication_receipt_digest);
    writer.digest(value.parent_reopen_receipt_digest);
    writer.digest(value.linked_parent_archive_digest);
    writer.digest(value.claim_catalogue_digest);
    writer.digest(value.handoff_policy_digest);
    return writer.pad_to_end();
}

Digest hosted_observation_identity(const HostedObservation& value) noexcept {
    EncodedHostedObservation bytes{};
    if (!encode_hosted_observation(value, bytes)) return {};
    return digest_bytes(bytes);
}

bool encode_twin_world_witness(const TwinWorldWitness& value, EncodedTwinWorldWitness& output) noexcept {
    CanonicalWriter<encoded_twin_world_witness_bytes> writer(output);
    writer.magic("SLOPTW1");
    writer.u32(value.schema_version);
    writer.u16(value.requested_claim_mask);
    writer.u16(witness_flags(value));
    writer.u16(value.left_true_mask);
    writer.u16(value.right_true_mask);
    writer.u32(0U);
    writer.digest(value.observation_digest);
    writer.digest(value.left_world_label_digest);
    writer.digest(value.right_world_label_digest);
    writer.digest(value.claim_catalogue_digest);
    writer.digest(value.handoff_policy_digest);
    writer.digest(value.parent_closure_claim_digest);
    return writer.pad_to_end();
}

Digest twin_world_witness_identity(const TwinWorldWitness& value) noexcept {
    EncodedTwinWorldWitness bytes{};
    if (!encode_twin_world_witness(value, bytes)) return {};
    return digest_bytes(bytes);
}

bool encode_owner_handoff_request(const OwnerHandoffRequest& value, EncodedOwnerHandoffRequest& output) noexcept {
    CanonicalWriter<encoded_owner_handoff_request_bytes> writer(output);
    writer.magic("SLOPHR1");
    writer.u32(value.schema_version);
    writer.u16(value.requested_claim_mask);
    writer.u16(request_flags(value));
    writer.u64(value.linked_parent_archive_bytes);
    writer.u64(value.linked_parent_manifest_rows);
    writer.digest(value.linked_parent_archive_digest);
    writer.digest(value.parent_closure_claim_digest);
    writer.digest(value.observation_digest);
    writer.digest(value.witness_digest);
    writer.digest(value.claim_catalogue_digest);
    writer.digest(value.handoff_policy_digest);
    writer.digest(value.requested_response_profile_digest);
    writer.digest(value.response_namespace_digest);
    return writer.pad_to_end();
}

Digest owner_handoff_request_identity(const OwnerHandoffRequest& value) noexcept {
    EncodedOwnerHandoffRequest bytes{};
    if (!encode_owner_handoff_request(value, bytes)) return {};
    return digest_bytes(bytes);
}

bool encode_premise_deficit_certificate(
    const PremiseDeficitCertificate& value,
    EncodedPremiseDeficitCertificate& output) noexcept {
    CanonicalWriter<encoded_premise_deficit_certificate_bytes> writer(output);
    writer.magic("SLOPDF1");
    writer.u32(value.schema_version);
    writer.u16(value.unresolved_claim_mask);
    writer.u16(deficit_flags(value));
    writer.digest(value.observation_digest);
    writer.digest(value.witness_digest);
    writer.digest(value.request_digest);
    writer.digest(value.parent_closure_claim_digest);
    writer.digest(value.claim_catalogue_digest);
    writer.digest(value.handoff_policy_digest);
    writer.digest(value.requested_response_profile_digest);
    return writer.pad_to_end();
}

Digest premise_deficit_certificate_identity(const PremiseDeficitCertificate& value) noexcept {
    EncodedPremiseDeficitCertificate bytes{};
    if (!encode_premise_deficit_certificate(value, bytes)) return {};
    return digest_bytes(bytes);
}

BoundaryReport evaluate_candidate(const ExternalityTrace& trace) noexcept {
    BoundaryReport report{};
    const auto parent = observed_output_closure::evaluate_candidate(trace.parent);
    report.parent_accepted = parent.accepted;
    report.parent_closure_ready = parent.closure_ready;
    if (!parent.accepted) return reject(report, BoundaryCode::parent_rejected);
    if (!parent.closure_ready) return reject(report, BoundaryCode::parent_not_closure_ready);

    report.cuts_ordered = cuts_match(trace);
    if (!report.cuts_ordered) return reject(report, BoundaryCode::cut_order_invalid);

    const bool left_present = trace.left_observation.present;
    const bool right_present = trace.right_observation.present;
    if (!left_present && !right_present) {
        if (trace.witness.present || trace.request.present || trace.deficit.present) {
            return reject(report, BoundaryCode::witness_without_observation);
        }
        return accept(report, BoundaryCode::accepted_parent_closed);
    }
    if (left_present != right_present) return reject(report, BoundaryCode::observation_pair_incomplete);

    if (!observation_shape(trace.left_observation) || !observation_shape(trace.right_observation)) {
        return reject(report, BoundaryCode::observation_shape_invalid);
    }
    report.claim_mask_valid = valid_claim_mask(trace.left_observation.requested_claim_mask)
        && valid_claim_mask(trace.right_observation.requested_claim_mask);
    if (!report.claim_mask_valid) return reject(report, BoundaryCode::claim_mask_invalid);
    if (!observation_binding(trace.left_observation, trace.parent)
        || !observation_binding(trace.right_observation, trace.parent)) {
        return reject(report, BoundaryCode::observation_binding_mismatch);
    }
    EncodedHostedObservation left_bytes{};
    EncodedHostedObservation right_bytes{};
    if (!encode_hosted_observation(trace.left_observation, left_bytes)
        || !encode_hosted_observation(trace.right_observation, right_bytes)
        || trace.left_observation.observation_digest != digest_bytes(left_bytes)
        || trace.right_observation.observation_digest != digest_bytes(right_bytes)) {
        return reject(report, BoundaryCode::observation_digest_mismatch);
    }
    report.observations_valid = true;
    report.observations_byte_identical = left_bytes == right_bytes;
    if (!report.observations_byte_identical) return reject(report, BoundaryCode::observations_not_equivalent);

    if (!trace.witness.present) {
        if (trace.request.present || trace.deficit.present) return reject(report, BoundaryCode::request_without_witness);
        return accept(report, BoundaryCode::accepted_observation_durable);
    }

    report.external_facts_valid = valid_fact_set(trace.left_external_facts) && valid_fact_set(trace.right_external_facts);
    if (!report.external_facts_valid) return reject(report, BoundaryCode::external_fact_mask_invalid);
    const auto difference = static_cast<std::uint16_t>(trace.left_external_facts.true_mask ^ trace.right_external_facts.true_mask);
    report.requested_claims_diverge = difference == trace.left_observation.requested_claim_mask;
    if (!report.requested_claims_diverge) return reject(report, BoundaryCode::requested_claims_do_not_diverge);

    if (!witness_shape(trace.witness)) return reject(report, BoundaryCode::witness_shape_invalid);
    if (!witness_binding(trace.witness, trace.left_observation, trace.left_external_facts, trace.right_external_facts, trace.parent)) {
        return reject(report, BoundaryCode::witness_binding_mismatch);
    }
    EncodedTwinWorldWitness witness_bytes{};
    if (!encode_twin_world_witness(trace.witness, witness_bytes)
        || trace.witness.witness_digest != digest_bytes(witness_bytes)) {
        return reject(report, BoundaryCode::witness_digest_mismatch);
    }
    report.witness_valid = true;
    report.nonderivation_witness = true;

    if (!trace.request.present) {
        if (trace.deficit.present) return reject(report, BoundaryCode::deficit_without_request);
        return accept(report, BoundaryCode::accepted_nonderivation_witness);
    }
    if (!request_shape(trace.request)) return reject(report, BoundaryCode::request_shape_invalid);
    if (!request_binding(trace.request, trace.left_observation, trace.witness, trace.parent)) {
        return reject(report, BoundaryCode::request_binding_mismatch);
    }
    EncodedOwnerHandoffRequest request_bytes{};
    if (!encode_owner_handoff_request(trace.request, request_bytes)
        || trace.request.request_digest != digest_bytes(request_bytes)) {
        return reject(report, BoundaryCode::request_digest_mismatch);
    }
    report.request_valid = true;

    if (trace.promote_requested_claims_from_hosted_bytes) {
        return reject(report, BoundaryCode::hosted_promotion_forbidden);
    }

    if (!trace.deficit.present) return accept(report, BoundaryCode::accepted_handoff_request_durable);
    if (!deficit_shape(trace.deficit)) return reject(report, BoundaryCode::deficit_shape_invalid);
    if (!deficit_binding(trace.deficit, trace.left_observation, trace.witness, trace.request, trace.parent)) {
        return reject(report, BoundaryCode::deficit_binding_mismatch);
    }
    EncodedPremiseDeficitCertificate deficit_bytes{};
    if (!encode_premise_deficit_certificate(trace.deficit, deficit_bytes)
        || trace.deficit.certificate_digest != digest_bytes(deficit_bytes)) {
        return reject(report, BoundaryCode::deficit_digest_mismatch);
    }
    report.deficit_valid = true;
    report.owner_handoff_ready = true;
    return accept(report, BoundaryCode::accepted_premise_deficit_durable);
}

std::string_view boundary_code_name(const BoundaryCode value) noexcept {
    switch (value) {
        case BoundaryCode::accepted_parent_closed: return "ACCEPTED_PARENT_CLOSED";
        case BoundaryCode::accepted_observation_durable: return "ACCEPTED_OBSERVATION_DURABLE";
        case BoundaryCode::accepted_nonderivation_witness: return "ACCEPTED_NONDERIVATION_WITNESS";
        case BoundaryCode::accepted_handoff_request_durable: return "ACCEPTED_HANDOFF_REQUEST_DURABLE";
        case BoundaryCode::accepted_premise_deficit_durable: return "ACCEPTED_PREMISE_DEFICIT_DURABLE";
        case BoundaryCode::parent_rejected: return "PARENT_REJECTED";
        case BoundaryCode::parent_not_closure_ready: return "PARENT_NOT_CLOSURE_READY";
        case BoundaryCode::observation_pair_incomplete: return "OBSERVATION_PAIR_INCOMPLETE";
        case BoundaryCode::observation_shape_invalid: return "OBSERVATION_SHAPE_INVALID";
        case BoundaryCode::observation_binding_mismatch: return "OBSERVATION_BINDING_MISMATCH";
        case BoundaryCode::observation_digest_mismatch: return "OBSERVATION_DIGEST_MISMATCH";
        case BoundaryCode::observations_not_equivalent: return "OBSERVATIONS_NOT_EQUIVALENT";
        case BoundaryCode::claim_mask_invalid: return "CLAIM_MASK_INVALID";
        case BoundaryCode::external_fact_mask_invalid: return "EXTERNAL_FACT_MASK_INVALID";
        case BoundaryCode::requested_claims_do_not_diverge: return "REQUESTED_CLAIMS_DO_NOT_DIVERGE";
        case BoundaryCode::witness_without_observation: return "WITNESS_WITHOUT_OBSERVATION";
        case BoundaryCode::witness_shape_invalid: return "WITNESS_SHAPE_INVALID";
        case BoundaryCode::witness_binding_mismatch: return "WITNESS_BINDING_MISMATCH";
        case BoundaryCode::witness_digest_mismatch: return "WITNESS_DIGEST_MISMATCH";
        case BoundaryCode::request_without_witness: return "REQUEST_WITHOUT_WITNESS";
        case BoundaryCode::request_shape_invalid: return "REQUEST_SHAPE_INVALID";
        case BoundaryCode::request_binding_mismatch: return "REQUEST_BINDING_MISMATCH";
        case BoundaryCode::request_digest_mismatch: return "REQUEST_DIGEST_MISMATCH";
        case BoundaryCode::deficit_without_request: return "DEFICIT_WITHOUT_REQUEST";
        case BoundaryCode::deficit_shape_invalid: return "DEFICIT_SHAPE_INVALID";
        case BoundaryCode::deficit_binding_mismatch: return "DEFICIT_BINDING_MISMATCH";
        case BoundaryCode::deficit_digest_mismatch: return "DEFICIT_DIGEST_MISMATCH";
        case BoundaryCode::hosted_promotion_forbidden: return "HOSTED_PROMOTION_FORBIDDEN";
        case BoundaryCode::cut_order_invalid: return "CUT_ORDER_INVALID";
    }
    return "UNKNOWN";
}

std::string_view external_claim_name(const std::size_t bit) noexcept {
    constexpr std::array<std::string_view, external_claim_count> names{{
        "SOURCE_ORIGIN_AUTHENTIC",
        "DEPENDENCY_CLOSURE_COMPLETE",
        "BUILD_EXECUTION_OPERATED",
        "BUILDER_CONTROL_TRUSTED",
        "EXTERNAL_PUBLICATION_OCCURRED",
        "INDEPENDENT_EXACT_REOPEN_OPERATED",
        "ADMINISTRATIVE_ROOT_INDEPENDENT",
        "CUSTODY_ROOT_INDEPENDENT",
        "ROLLBACK_ROOT_INDEPENDENT",
        "SHARED_VIEW_CONSISTENT",
        "CONTROL_INVENTORY_COMPLETE",
        "OWNER_CONSTITUTION_VALID",
        "OWNER_ADMISSION_CURRENT",
        "AUTHORITY_GRANTED",
        "EPOCH_ZERO_EXITED",
    }};
    return bit < names.size() ? names[bit] : std::string_view{"UNKNOWN"};
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification::relocatable_provenance::observed_output_closure::hosted_externality_nonderivation
