# Root-ceremony anchor v1

**Status:** hosted Epoch-Zero relation and finite countermodel.
**Authority:** false. **External operation:** none.

## 1. Problem repaired

The root-succession statement in `ROOT-SUCCESSION-CAPSULE-V1.md` already binds
an exact predecessor, exact successor, root-register identifier, ceremony
identifier, adjacent versions, and an old/new dual-threshold envelope. Three
stronger interpretations were nevertheless possible if prose outran bytes:

- repeating the successor head in a field called `precommitted` does not prove
  that an authenticated precommit receipt existed before signatures;
- a register identifier does not distinguish a restored, replaced, or cloned
  incarnation of that register; and
- an arbitrary request identifier does not force the same effect proposition to
  be used after a lost response.

This anchor closes those **byte relations**. It does not prove the external
premises that make the named receipts trustworthy.

All integers are unsigned big-endian. Every reserved byte is zero. Every digest
below uses `SHA256(UTF8(domain) || 0x00 || payload)`.

## 2. Canonical anchor — 512 bytes

| Offset | Width | Field |
|---:|---:|---|
| 0 | 8 | `SLOPCA01` |
| 8 | 2 | version `1` |
| 10 | 2 | kind `7` |
| 12 | 4 | length `512` |
| 16 | 32 | project identifier |
| 48 | 32 | external register identifier |
| 80 | 32 | expected register-incarnation identifier |
| 112 | 32 | predecessor owner-manifest head |
| 144 | 32 | successor owner-manifest head |
| 176 | 32 | authenticated RC0 starting-root receipt head observation |
| 208 | 32 | authenticated RC1 precommit receipt head observation |
| 240 | 32 | RC1 precommit operation identifier observation |
| 272 | 32 | ceremony policy head |
| 304 | 32 | derived transition digest |
| 336 | 32 | derived external request identifier |
| 368 | 8 | predecessor version `N` |
| 376 | 8 | successor version `N+1` |
| 384 | 8 | RC1 receipt recorded time observation |
| 392 | 8 | signing not-before floor |
| 400 | 8 | root statement expiry |
| 408 | 8 | external request deadline |
| 416 | 64 | reserved, all zero |
| 480 | 32 | anchor integrity over bytes `0..479` |

The anchor head is:

```
SHA256("SlopOS/root-ceremony-anchor/head/v1" || 0x00 || exact_512_bytes)
```

The existing root-succession statement's `ceremony_id` MUST equal this anchor
head. The anchor deliberately excludes the root-statement head: including both
`statement_head` in the anchor and `anchor_head` in the statement would create
a circular fixed-point requirement.

## 3. Derived transition and request identities

The transition digest is:

```
SHA256(
  "SlopOS/root-ceremony-anchor/transition/v1" || 0x00 ||
  project_id || register_id || register_incarnation ||
  predecessor_manifest_head || successor_manifest_head ||
  rc0_starting_root_receipt_head || rc1_precommit_receipt_head ||
  precommit_operation_id || policy_head || uint64_be(N) || uint64_be(N+1)
)
```

The request identifier is:

```
SHA256(
  "SlopOS/root-ceremony-anchor/request/v1" || 0x00 ||
  transition_digest || register_id || register_incarnation ||
  precommit_operation_id
)
```

The root statement's `transition_nonce` MUST equal the first eight bytes of the
request identifier interpreted as one unsigned big-endian integer. This is
redundant with the ceremony-head binding but prevents the nonce from becoming a
second, arbitrarily selected request namespace.

A caller that loses a response MUST keep this request identity and enter a
query/reconciliation path. It may not mint a new request identity and replay an
effect on the theory that a timeout means no commit.

## 4. Valid relation

`RELATION_VALID` requires, in fail-closed order:

1. canonical anchor framing, reserved bytes, and integrity;
2. canonical 320-byte root-succession statement;
3. nonzero project, register, register incarnation, predecessor, successor,
   RC0 receipt, RC1 receipt, precommit operation, and policy identities;
4. distinct RC0 and RC1 receipt heads;
5. exact adjacent version `N -> N+1`, without overflow;
6. exact recomputation of the transition digest;
7. exact recomputation of the request identifier;
8. `precommit_recorded_at < signing_not_before`;
9. `signing_not_before < expires_at` and
   `signing_not_before <= request_deadline <= expires_at`;
10. statement/anchor equality for project, register, predecessor, successor,
    versions, successor precommit, not-before, and expiry;
11. statement `ceremony_id == anchor_head`;
12. statement transition nonce equal to the request-derived nonce; and
13. observation inside the signing/request/expiry window.

The strict chronology inequality is a relation over authenticated observations,
not a trusted-clock theorem. It is useful only when RC1 is an externally
verifiable receipt containing service-assigned material that could not have been
predicted before the receipt was issued, and when the receipt's time semantics
are part of the selected provider profile.

## 5. Nonclaims

A canonical anchor can be built around invented bytes. Therefore validation does
not imply any of the following:

- the RC0 or RC1 receipt was produced by the named service;
- the receipt time is authentic or globally ordered;
- the expected incarnation is the unique current incarnation;
- the external register cannot equivocate or be cloned;
- old and new signing thresholds represent independent custody;
- the request was accepted, committed once, or durably retained;
- a separate reopener queried the same protected history;
- the owner constituted this root; or
- SlopOS may exercise authority.

Those remain RC0–RC7 ceremony premises in the linked office. The projection of
all authority-bearing fields is hard-coded false in both C++ relations.

## 6. Retained finite campaign

The campaign has 46 cases: three valid window-boundary observations and 43
rejections. It covers framing and integrity corruption, each missing identity,
receipt collision, stasis/skip/overflow, wrong derived digests, chronology and
window failures, every statement cross-binding, observations outside the
request window, an alternate coherent RC1 anchor, and a restored-clone
incarnation. Candidate and separately spelled C++ relations must agree on every
report; an independent Python parser recomputes all hashes and validates the
retained fixtures.
