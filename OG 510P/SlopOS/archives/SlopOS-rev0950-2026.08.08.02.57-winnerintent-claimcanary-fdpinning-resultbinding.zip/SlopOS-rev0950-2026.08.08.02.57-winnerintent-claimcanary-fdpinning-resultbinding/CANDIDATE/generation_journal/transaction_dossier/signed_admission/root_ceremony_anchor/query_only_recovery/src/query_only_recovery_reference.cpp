#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery.hpp"

#include <algorithm>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery {
namespace {

[[nodiscard]] bool nonzero(const Digest& value) noexcept {
    return std::find_if(value.begin(), value.end(), [](const std::uint8_t byte) {
        return byte != 0U;
    }) != value.end();
}

[[nodiscard]] RecoveryReport make_report(
    const RecoveryCode code,
    const bool accepted,
    const Phase phase,
    const Outcome outcome) noexcept {
    return RecoveryReport{
        code,
        accepted,
        phase,
        outcome,
        phase == Phase::query_only,
        phase == Phase::terminal_effect
            || phase == Phase::terminal_no_effect
            || phase == Phase::fail_stopped,
        accepted && phase == Phase::terminal_no_effect,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
    };
}

[[nodiscard]] Outcome phase_outcome(const Phase phase) noexcept {
    const std::array<Outcome, 5U> values{
        Outcome::none,
        Outcome::uncertain,
        Outcome::effect,
        Outcome::no_effect,
        Outcome::fail_stop,
    };
    return values.at(static_cast<std::size_t>(phase));
}

[[nodiscard]] RecoveryReport reject(
    const RecoveryState& state,
    const RecoveryCode code) noexcept {
    return make_report(code, false, state.phase, phase_outcome(state.phase));
}

[[nodiscard]] RecoveryCode evidence_failure(
    const RecoveryStep& step,
    const bool durable,
    const bool retention) noexcept {
    if (!step.authenticated) {
        return RecoveryCode::authentication_required;
    }
    if (!step.linearizable) {
        return RecoveryCode::linearizable_observation_required;
    }
    if (!step.single_view) {
        return RecoveryCode::single_view_required;
    }
    if (durable && !step.durable_result) {
        return RecoveryCode::durable_result_required;
    }
    if (retention && !step.retention_covers_reopen) {
        return RecoveryCode::retention_horizon_required;
    }
    return RecoveryCode::invalid_state;
}

}  // namespace

RecoveryReport evaluate_reference(
    const RecoveryState& state,
    const RecoveryStep& step) noexcept {
    if (!(nonzero(state.request_id)
          && nonzero(state.transition_digest)
          && nonzero(state.register_incarnation))) {
        return reject(state, RecoveryCode::invalid_state);
    }
    const std::array<bool, 3U> identity_equal{
        step.request_id == state.request_id,
        step.transition_digest == state.transition_digest,
        step.register_incarnation == state.register_incarnation,
    };
    const std::array<RecoveryCode, 3U> identity_codes{
        RecoveryCode::request_id_mismatch,
        RecoveryCode::transition_digest_mismatch,
        RecoveryCode::register_incarnation_mismatch,
    };
    for (std::size_t index = 0U; index < identity_equal.size(); ++index) {
        if (!identity_equal[index]) {
            return reject(state, identity_codes[index]);
        }
    }

    if (state.phase == Phase::ready) {
        if (step.command != Command::submit_exact) {
            return reject(state, RecoveryCode::invalid_command_for_phase);
        }
        if (step.observation == Observation::no_reply) {
            return make_report(
                RecoveryCode::accepted_submit_uncertain,
                true,
                Phase::query_only,
                Outcome::uncertain);
        }
        if (step.observation != Observation::commit_reply) {
            return reject(state, RecoveryCode::invalid_observation_for_command);
        }
        const RecoveryCode failed = evidence_failure(step, true, true);
        if (failed != RecoveryCode::invalid_state) {
            return reject(state, failed);
        }
        return make_report(
            RecoveryCode::accepted_submit_commit,
            true,
            Phase::terminal_effect,
            Outcome::effect);
    }

    if (state.phase == Phase::query_only) {
        if (step.command == Command::reopen) {
            return step.observation == Observation::reopen_event
                ? make_report(
                    RecoveryCode::accepted_reopen_query_only,
                    true,
                    Phase::query_only,
                    Outcome::uncertain)
                : reject(state, RecoveryCode::invalid_observation_for_command);
        }
        if (step.command == Command::declare_no_effect
            && step.observation == Observation::absent_record) {
            return reject(state, RecoveryCode::absence_not_terminal);
        }
        const bool is_latch_break = step.command == Command::submit_exact
            || step.command == Command::clear_latch
            || step.command == Command::repair;
        if (is_latch_break) {
            return reject(state, RecoveryCode::query_only_latched);
        }
        if (step.command != Command::query_exact) {
            return reject(state, RecoveryCode::invalid_command_for_phase);
        }

        const std::array<Observation, 3U> direct_observations{
            Observation::unavailable,
            Observation::wrong_incarnation,
            Observation::split_view,
        };
        const std::array<RecoveryCode, 3U> direct_codes{
            RecoveryCode::accepted_query_unavailable,
            RecoveryCode::accepted_query_wrong_incarnation_fail_stop,
            RecoveryCode::accepted_query_split_view_fail_stop,
        };
        const std::array<Phase, 3U> direct_phases{
            Phase::query_only,
            Phase::fail_stopped,
            Phase::fail_stopped,
        };
        const std::array<Outcome, 3U> direct_outcomes{
            Outcome::uncertain,
            Outcome::fail_stop,
            Outcome::fail_stop,
        };
        for (std::size_t index = 0U; index < direct_observations.size(); ++index) {
            if (step.observation == direct_observations[index]) {
                return make_report(
                    direct_codes[index], true, direct_phases[index], direct_outcomes[index]);
            }
        }

        const bool committed = step.observation == Observation::committed_record;
        const bool absent = step.observation == Observation::absent_record;
        const bool retired = step.observation == Observation::retired_record;
        if (!(committed || absent || retired)) {
            return reject(state, RecoveryCode::invalid_observation_for_command);
        }
        const RecoveryCode failed = evidence_failure(
            step,
            committed || retired,
            committed || retired);
        if (failed != RecoveryCode::invalid_state) {
            return reject(state, failed);
        }
        if (absent) {
            return make_report(
                RecoveryCode::accepted_query_absent_unresolved,
                true,
                Phase::query_only,
                Outcome::uncertain);
        }
        if (committed) {
            return make_report(
                RecoveryCode::accepted_query_commit,
                true,
                Phase::terminal_effect,
                Outcome::effect);
        }
        if (!step.retirement_serialized) {
            return reject(state, RecoveryCode::retirement_record_required);
        }
        if (!step.late_commit_fenced) {
            return reject(state, RecoveryCode::late_commit_fence_required);
        }
        return make_report(
            RecoveryCode::accepted_query_retired,
            true,
            Phase::terminal_no_effect,
            Outcome::no_effect);
    }

    if (state.phase == Phase::terminal_effect) {
        return step.command == Command::reopen && step.observation == Observation::reopen_event
            ? make_report(
                RecoveryCode::accepted_reopen_terminal_effect,
                true,
                Phase::terminal_effect,
                Outcome::effect)
            : reject(state, RecoveryCode::terminal_immutable);
    }
    if (state.phase == Phase::terminal_no_effect) {
        return step.command == Command::reopen && step.observation == Observation::reopen_event
            ? make_report(
                RecoveryCode::accepted_reopen_terminal_no_effect,
                true,
                Phase::terminal_no_effect,
                Outcome::no_effect)
            : reject(state, RecoveryCode::terminal_immutable);
    }
    return step.command == Command::reopen && step.observation == Observation::reopen_event
        ? make_report(
            RecoveryCode::accepted_reopen_fail_stop,
            true,
            Phase::fail_stopped,
            Outcome::fail_stop)
        : reject(state, RecoveryCode::fail_stop_immutable);
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery
