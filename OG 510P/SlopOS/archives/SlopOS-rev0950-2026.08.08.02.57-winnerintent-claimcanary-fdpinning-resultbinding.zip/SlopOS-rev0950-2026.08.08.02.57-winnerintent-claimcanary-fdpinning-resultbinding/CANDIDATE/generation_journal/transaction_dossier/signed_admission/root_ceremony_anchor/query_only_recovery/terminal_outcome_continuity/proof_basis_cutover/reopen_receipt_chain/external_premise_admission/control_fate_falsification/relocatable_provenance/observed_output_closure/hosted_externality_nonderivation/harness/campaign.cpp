#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/reopen_receipt_chain/external_premise_admission/control_fate_falsification/relocatable_provenance/observed_output_closure/hosted_externality_nonderivation.hpp"

#include "parent_output_set.hpp"
#include "slopos/e0/generation_journal/spend_record.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <span>
#include <sstream>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification::relocatable_provenance::observed_output_closure::hosted_externality_nonderivation {
namespace {

#ifndef SLOPOS_HEN_CLAIM_CATALOGUE_SHA256_HEX
#error "fixture requires claim catalogue"
#endif
#ifndef SLOPOS_HEN_HANDOFF_POLICY_SHA256_HEX
#error "fixture requires handoff policy"
#endif
#ifndef SLOPOS_HEN_RESPONSE_PROFILE_SHA256_HEX
#error "fixture requires response profile"
#endif
#ifndef SLOPOS_HEN_LINKED_PARENT_ARCHIVE_SHA256_HEX
#error "fixture requires linked parent archive"
#endif
#ifndef SLOPOS_HEN_LINKED_PARENT_ARCHIVE_BYTES
#error "fixture requires linked parent archive bytes"
#endif
#ifndef SLOPOS_HEN_LINKED_PARENT_MANIFEST_ROWS
#error "fixture requires linked parent manifest rows"
#endif
#ifndef SLOPOS_RPC_SOURCE_MANIFEST_SHA256_HEX
#error "fixture requires exact parent source manifest"
#endif
#ifndef SLOPOS_RPC_BUILD_PLAN_SHA256_HEX
#error "fixture requires exact parent build plan"
#endif
#ifndef SLOPOS_RPC_OUTPUT_CONTRACT_SHA256_HEX
#error "fixture requires exact parent output contract"
#endif
#ifndef SLOPOS_RPC_PARENT_BINDING_SHA256_HEX
#error "fixture requires exact parent binding"
#endif
#ifndef SLOPOS_RPC_LOGICAL_ROOT_SHA256_HEX
#error "fixture requires exact parent logical root"
#endif
#ifndef SLOPOS_RPC_CLAIM_POLICY_SHA256_HEX
#error "fixture requires exact parent claim policy"
#endif
#ifndef SLOPOS_RPC_FIRST_LOCATOR_SHA256_HEX
#error "fixture requires first locator"
#endif
#ifndef SLOPOS_RPC_RELOCATED_LOCATOR_SHA256_HEX
#error "fixture requires relocated locator"
#endif
#ifndef SLOPOS_OOC_PARENT_OUTPUT_CARRIER_SHA256_HEX
#error "fixture requires exact prior output carrier"
#endif
#ifndef SLOPOS_OOC_PARENT_OUTPUT_CARRIER_BYTES
#error "fixture requires exact prior output carrier bytes"
#endif
#ifndef SLOPOS_OOC_RESERVED_POLICY_SHA256_HEX
#error "fixture requires reserved namespace policy"
#endif
#ifndef SLOPOS_OOC_REOPENER_IMPLEMENTATION_SHA256_HEX
#error "fixture requires hosted reopener implementation"
#endif

struct Case final {
    std::string name;
    ExternalityTrace trace;
    BoundaryCode expected;
};

[[nodiscard]] Digest digest(const std::string_view label) {
    return generation_journal::sha256(std::span<const std::uint8_t>(
        reinterpret_cast<const std::uint8_t*>(label.data()), label.size()));
}

[[nodiscard]] constexpr std::uint8_t hex_nibble(const char value) noexcept {
    if (value >= '0' && value <= '9') return static_cast<std::uint8_t>(value - '0');
    if (value >= 'a' && value <= 'f') return static_cast<std::uint8_t>(value - 'a' + 10);
    return 0xffU;
}

[[nodiscard]] Digest exact_digest(const std::string_view value) noexcept {
    Digest output{};
    if (value.size() != 64U) return output;
    for (std::size_t index = 0U; index < output.size(); ++index) {
        const std::uint8_t high = hex_nibble(value[index * 2U]);
        const std::uint8_t low = hex_nibble(value[index * 2U + 1U]);
        if (high > 15U || low > 15U) return {};
        output[index] = static_cast<std::uint8_t>((high << 4U) | low);
    }
    return output;
}

[[nodiscard]] std::string hex(const Digest& value) {
    std::ostringstream out;
    out << std::hex << std::setfill('0');
    for (const auto byte : value) out << std::setw(2) << static_cast<unsigned>(byte);
    return out.str();
}

[[nodiscard]] SourceEntry source_entry_exact(
    const std::string_view path,
    const Digest& content_digest,
    const std::uint64_t bytes,
    const std::uint16_t mode) {
    SourceEntry output{};
    if (path.size() > output.path.size()) return output;
    for (std::size_t index = 0U; index < path.size(); ++index) output.path[index] = static_cast<std::uint8_t>(path[index]);
    output.path_length = static_cast<std::uint8_t>(path.size());
    output.content_digest = content_digest;
    output.bytes = bytes;
    output.mode = mode;
    output.present = true;
    output.regular_file = true;
    return output;
}

void refresh_parent_source(RelocationTrace& trace) { trace.source_closure.closure_digest = source_closure_identity(trace.source_closure); }
void refresh_parent_plan(RelocationTrace& trace) { trace.build_plan.plan_digest = build_plan_identity(trace.build_plan); }
void refresh_parent_capsule(RelocationTrace& trace) {
    trace.capsule.parent_challenge_receipt_digest = trace.parent.graph.challenge_receipt_digest;
    trace.capsule.logical_root_digest = trace.source_closure.logical_root_digest;
    trace.capsule.source_closure_digest = trace.source_closure.closure_digest;
    trace.capsule.build_plan_digest = trace.build_plan.plan_digest;
    trace.capsule.capsule_digest = provenance_capsule_identity(trace.capsule);
}
void refresh_parent_observation(BuildObservation& observation, const RelocationTrace& trace) {
    observation.capsule_digest = trace.capsule.capsule_digest;
    observation.source_closure_digest = trace.source_closure.closure_digest;
    observation.build_plan_digest = trace.build_plan.plan_digest;
    observation.claim_digest = build_claim_identity(observation);
}
void refresh_parent_receipt(ProvenanceReopenReceipt& receipt, const BuildObservation& observation, const RelocationTrace& trace) {
    receipt.claim_digest = observation.claim_digest;
    receipt.capsule_digest = trace.capsule.capsule_digest;
    receipt.source_closure_digest = trace.source_closure.closure_digest;
    receipt.build_plan_digest = trace.build_plan.plan_digest;
    receipt.output_digest = observation.output_digest;
    receipt.receipt_digest = reopen_receipt_identity(receipt);
}
void refresh_parent_cuts(RelocationTrace& trace) {
    for (std::size_t index = 0U; index < trace.cuts.size(); ++index) {
        trace.cuts[index] = {};
        trace.cuts[index].source_closure_digest = trace.source_closure.closure_digest;
        if (index >= 1U) trace.cuts[index].build_plan_digest = trace.build_plan.plan_digest;
        if (index >= 2U) trace.cuts[index].capsule_digest = trace.capsule.capsule_digest;
        if (index >= 3U) trace.cuts[index].first_claim_digest = trace.first_observation.claim_digest;
        if (index >= 4U) trace.cuts[index].first_receipt_digest = trace.first_receipt.receipt_digest;
        if (index >= 5U) trace.cuts[index].relocated_claim_digest = trace.relocated_observation.claim_digest;
        if (index >= 6U) trace.cuts[index].relocated_receipt_digest = trace.relocated_receipt.receipt_digest;
    }
}

[[nodiscard]] RelocationTrace parent_baseline() {
    RelocationTrace trace{};
    trace.parent = control_fate_falsification::make_hosted_clean_fixture();
    const Digest source_manifest = exact_digest(SLOPOS_RPC_SOURCE_MANIFEST_SHA256_HEX);
    const Digest build_plan_binding = exact_digest(SLOPOS_RPC_BUILD_PLAN_SHA256_HEX);
    const Digest output_contract = exact_digest(SLOPOS_RPC_OUTPUT_CONTRACT_SHA256_HEX);
    const Digest parent_binding = exact_digest(SLOPOS_RPC_PARENT_BINDING_SHA256_HEX);
    const Digest logical_root = exact_digest(SLOPOS_RPC_LOGICAL_ROOT_SHA256_HEX);
    const Digest claim_policy = exact_digest(SLOPOS_RPC_CLAIM_POLICY_SHA256_HEX);

    trace.source_closure.logical_root_digest = logical_root;
    trace.source_closure.parent_challenge_receipt_digest = trace.parent.graph.challenge_receipt_digest;
    trace.source_closure.entries[0] = source_entry_exact("bindings/build-plan.json", build_plan_binding, SLOPOS_RPC_BUILD_PLAN_BYTES, mode_read_only);
    trace.source_closure.entries[1] = source_entry_exact("bindings/claim-policy.txt", claim_policy, SLOPOS_RPC_CLAIM_POLICY_BYTES, mode_read_only);
    trace.source_closure.entries[2] = source_entry_exact("bindings/logical-root.txt", logical_root, SLOPOS_RPC_LOGICAL_ROOT_BYTES, mode_read_only);
    trace.source_closure.entries[3] = source_entry_exact("bindings/output-contract.json", output_contract, SLOPOS_RPC_OUTPUT_CONTRACT_BYTES, mode_read_only);
    trace.source_closure.entries[4] = source_entry_exact("bindings/parent-binding.json", parent_binding, SLOPOS_RPC_PARENT_BINDING_BYTES, mode_read_only);
    trace.source_closure.entries[5] = source_entry_exact("bindings/source-manifest.tsv", source_manifest, SLOPOS_RPC_SOURCE_MANIFEST_BYTES, mode_read_only);
    trace.source_closure.entry_count = 6U;
    trace.source_closure.present = true;
    trace.source_closure.canonical = true;
    trace.source_closure.complete = true;
    trace.source_closure.hidden_inputs_absent = true;
    refresh_parent_source(trace);

    trace.build_plan.build_type_digest = digest("build-type:release-O0-g0-DNDEBUG");
    trace.build_plan.toolchain_digest = digest("toolchain-policy:cxx20-gcc-clang-hosted-lanes");
    trace.build_plan.flags_digest = digest("flags-policy:prefix-map-source-root-to-logical-root");
    trace.build_plan.environment_policy_digest = claim_policy;
    trace.build_plan.dependency_closure_digest = source_manifest;
    trace.build_plan.output_spec_digest = output_contract;
    trace.build_plan.deterministic_input_digest = build_plan_binding;
    trace.build_plan.present = true;
    trace.build_plan.canonical = true;
    trace.build_plan.all_behavior_inputs_bound = true;
    trace.build_plan.network_inputs_forbidden = true;
    refresh_parent_plan(trace);

    trace.capsule.parent_challenge_receipt_digest = trace.parent.graph.challenge_receipt_digest;
    trace.capsule.logical_root_digest = trace.source_closure.logical_root_digest;
    trace.capsule.source_closure_digest = trace.source_closure.closure_digest;
    trace.capsule.build_plan_digest = trace.build_plan.plan_digest;
    trace.capsule.expected_output_digest = output_contract;
    trace.capsule.claim_policy_digest = claim_policy;
    trace.capsule.present = true;
    trace.capsule.canonical = true;
    trace.capsule.physical_locator_excluded_from_subject = true;
    trace.capsule.raw_logs_noncanonical = true;
    refresh_parent_capsule(trace);

    trace.first_observation.output_digest = output_contract;
    trace.first_observation.physical_locator_digest = exact_digest(SLOPOS_RPC_FIRST_LOCATOR_SHA256_HEX);
    trace.first_observation.raw_log_digest = digest("raw-log:first-host-path-bearing-log");
    trace.first_observation.present = true;
    trace.first_observation.exact_inputs_consumed = true;
    trace.first_observation.output_set_complete = true;
    refresh_parent_observation(trace.first_observation, trace);

    trace.relocated_observation = trace.first_observation;
    trace.relocated_observation.physical_locator_digest = exact_digest(SLOPOS_RPC_RELOCATED_LOCATOR_SHA256_HEX);
    trace.relocated_observation.raw_log_digest = digest("raw-log:relocated-host-path-bearing-log");
    refresh_parent_observation(trace.relocated_observation, trace);

    trace.first_receipt.reopener_digest = digest("reopener:first-independent-reader");
    trace.first_receipt.present = true;
    trace.first_receipt.durable = true;
    trace.first_receipt.independently_administered = true;
    trace.first_receipt.exact_subject_reopened = true;
    refresh_parent_receipt(trace.first_receipt, trace.first_observation, trace);

    trace.relocated_receipt.reopener_digest = digest("reopener:second-independent-reader");
    trace.relocated_receipt.present = true;
    trace.relocated_receipt.durable = true;
    trace.relocated_receipt.independently_administered = true;
    trace.relocated_receipt.exact_subject_reopened = true;
    refresh_parent_receipt(trace.relocated_receipt, trace.relocated_observation, trace);
    refresh_parent_cuts(trace);
    return trace;
}

[[nodiscard]] OutputEntry output_entry(
    const std::string_view path,
    const Digest& content,
    const std::uint64_t bytes,
    const std::uint16_t mode) {
    OutputEntry entry{};
    if (path.size() > entry.path.size()) return entry;
    for (std::size_t index = 0U; index < path.size(); ++index) entry.path[index] = static_cast<std::uint8_t>(path[index]);
    entry.path_length = static_cast<std::uint8_t>(path.size());
    entry.content_digest = content;
    entry.bytes = bytes;
    entry.mode = mode;
    entry.present = true;
    entry.regular_file = true;
    return entry;
}

[[maybe_unused]] void set_output_path(OutputEntry& entry, const std::string_view path) {
    entry.path.fill(0U);
    if (path.size() > entry.path.size()) { entry.path_length = 0U; return; }
    for (std::size_t index = 0U; index < path.size(); ++index) entry.path[index] = static_cast<std::uint8_t>(path[index]);
    entry.path_length = static_cast<std::uint8_t>(path.size());
}

void refresh_manifest(OutputClosureTrace& trace) { trace.manifest.manifest_digest = output_manifest_identity(trace.manifest); }
void refresh_publication(OutputClosureTrace& trace) {
    trace.publication.manifest_digest = trace.manifest.manifest_digest;
    trace.publication.parent_relocated_receipt_digest = trace.parent.relocated_receipt.receipt_digest;
    trace.publication.parent_output_carrier_digest = exact_digest(SLOPOS_OOC_PARENT_OUTPUT_CARRIER_SHA256_HEX);
    trace.publication.receipt_digest = publication_receipt_identity(trace.publication);
}
void refresh_reopen(OutputClosureTrace& trace) {
    trace.reopen.publication_receipt_digest = trace.publication.receipt_digest;
    trace.reopen.manifest_digest = trace.manifest.manifest_digest;
    trace.reopen.parent_output_carrier_digest = exact_digest(SLOPOS_OOC_PARENT_OUTPUT_CARRIER_SHA256_HEX);
    trace.reopen.receipt_digest = output_reopen_receipt_identity(trace.reopen);
}
void refresh_claim(OutputClosureTrace& trace) {
    trace.claim.parent_relocated_receipt_digest = trace.parent.relocated_receipt.receipt_digest;
    trace.claim.parent_build_claim_digest = trace.parent.relocated_observation.claim_digest;
    trace.claim.manifest_digest = trace.manifest.manifest_digest;
    trace.claim.publication_receipt_digest = trace.publication.receipt_digest;
    trace.claim.reopen_receipt_digest = trace.reopen.receipt_digest;
    trace.claim.reserved_namespace_policy_digest = exact_digest(SLOPOS_OOC_RESERVED_POLICY_SHA256_HEX);
    trace.claim.claim_digest = output_closure_claim_identity(trace.claim);
}
void refresh_cuts(OutputClosureTrace& trace) {
    for (std::size_t index = 0U; index < trace.cuts.size(); ++index) {
        trace.cuts[index] = {};
        trace.cuts[index].parent_output_carrier_digest = exact_digest(SLOPOS_OOC_PARENT_OUTPUT_CARRIER_SHA256_HEX);
        if (trace.manifest.present && index >= 1U) trace.cuts[index].manifest_digest = trace.manifest.manifest_digest;
        if (trace.publication.present && index >= 2U) trace.cuts[index].publication_receipt_digest = trace.publication.receipt_digest;
        if (trace.reopen.present && index >= 3U) trace.cuts[index].reopen_receipt_digest = trace.reopen.receipt_digest;
        if (trace.claim.present && index >= 4U) trace.cuts[index].closure_claim_digest = trace.claim.claim_digest;
    }
}
[[maybe_unused]] void refresh_from_manifest(OutputClosureTrace& trace) { refresh_manifest(trace); refresh_publication(trace); refresh_reopen(trace); refresh_claim(trace); refresh_cuts(trace); }
[[maybe_unused]] void refresh_from_publication(OutputClosureTrace& trace) { refresh_publication(trace); refresh_reopen(trace); refresh_claim(trace); refresh_cuts(trace); }
[[maybe_unused]] void refresh_from_reopen(OutputClosureTrace& trace) { refresh_reopen(trace); refresh_claim(trace); refresh_cuts(trace); }
[[maybe_unused]] void refresh_from_claim(OutputClosureTrace& trace) { refresh_claim(trace); refresh_cuts(trace); }

[[nodiscard]] OutputClosureTrace parent_output_baseline() {
    OutputClosureTrace trace{};
    trace.parent = parent_baseline();
    trace.manifest.parent_relocated_receipt_digest = trace.parent.relocated_receipt.receipt_digest;
    trace.manifest.parent_build_claim_digest = trace.parent.relocated_observation.claim_digest;
    trace.manifest.parent_provenance_output_digest = trace.parent.relocated_observation.output_digest;
    trace.manifest.parent_output_carrier_digest = exact_digest(SLOPOS_OOC_PARENT_OUTPUT_CARRIER_SHA256_HEX);
    trace.manifest.reserved_namespace_policy_digest = exact_digest(SLOPOS_OOC_RESERVED_POLICY_SHA256_HEX);
    using slopos::e0::observed_output_closure_generated::parent_output_entries;
    for (std::size_t index = 0U; index < parent_output_entries.size(); ++index) {
        const auto& expected = parent_output_entries[index];
        trace.manifest.entries[index] = output_entry(expected.path, exact_digest(expected.sha256), expected.bytes, expected.mode);
    }
    trace.manifest.entry_count = static_cast<std::uint8_t>(parent_output_entries.size());
    trace.manifest.present = true;
    trace.manifest.canonical = true;
    trace.manifest.exact_prior_set = true;
    trace.manifest.complete = true;
    trace.manifest.reserved_namespace_excluded = true;
    refresh_manifest(trace);

    trace.publication.publisher_digest = digest("publisher:hosted-no-replace-output-manifest-writer");
    trace.publication.carrier_bytes = SLOPOS_OOC_PARENT_OUTPUT_CARRIER_BYTES;
    trace.publication.present = true;
    trace.publication.durable = true;
    trace.publication.no_replace_publication = true;
    trace.publication.single_view_reopened = true;
    trace.publication.exact_carrier_published = true;
    refresh_publication(trace);

    trace.reopen.reopener_digest = digest("reopener:separate-hosted-parent-output-set-rehasher");
    trace.reopen.reopener_implementation_digest = exact_digest(SLOPOS_OOC_REOPENER_IMPLEMENTATION_SHA256_HEX);
    trace.reopen.carrier_bytes = SLOPOS_OOC_PARENT_OUTPUT_CARRIER_BYTES;
    trace.reopen.present = true;
    trace.reopen.durable = true;
    trace.reopen.separate_reopener_role = true;
    trace.reopen.exact_manifest_reopened = true;
    trace.reopen.all_entries_rehashed = true;
    refresh_reopen(trace);

    trace.claim.present = true;
    trace.claim.durable = true;
    trace.claim.exact_prior_output_set_claimed = true;
    trace.claim.child_products_outside_subject = true;
    trace.claim.no_self_digest_transform_claimed = true;
    refresh_claim(trace);
    refresh_cuts(trace);
    return trace;
}


void refresh_observations(ExternalityTrace& trace) {
    trace.left_observation.observation_digest = hosted_observation_identity(trace.left_observation);
    trace.right_observation.observation_digest = hosted_observation_identity(trace.right_observation);
}
void refresh_witness(ExternalityTrace& trace) { trace.witness.witness_digest = twin_world_witness_identity(trace.witness); }
void refresh_request(ExternalityTrace& trace) { trace.request.request_digest = owner_handoff_request_identity(trace.request); }
void refresh_deficit(ExternalityTrace& trace) { trace.deficit.certificate_digest = premise_deficit_certificate_identity(trace.deficit); }
void refresh_externality_cuts(ExternalityTrace& trace) {
    for (std::size_t i = 0U; i < trace.cuts.size(); ++i) {
        trace.cuts[i] = {};
        trace.cuts[i].parent_closure_claim_digest = trace.parent.claim.claim_digest;
        if (i >= 1U && trace.left_observation.present && trace.right_observation.present) {
            trace.cuts[i].observation_digest = trace.left_observation.observation_digest;
        }
        if (i >= 2U && trace.witness.present) trace.cuts[i].witness_digest = trace.witness.witness_digest;
        if (i >= 3U && trace.request.present) trace.cuts[i].request_digest = trace.request.request_digest;
        if (i >= 4U && trace.deficit.present) trace.cuts[i].deficit_certificate_digest = trace.deficit.certificate_digest;
    }
}
[[maybe_unused]] void refresh_child_from_observation(ExternalityTrace& trace) {
    refresh_observations(trace);
    refresh_witness(trace);
    refresh_request(trace);
    refresh_deficit(trace);
    refresh_externality_cuts(trace);
}
void refresh_child_from_witness(ExternalityTrace& trace) {
    refresh_witness(trace);
    refresh_request(trace);
    refresh_deficit(trace);
    refresh_externality_cuts(trace);
}
void refresh_child_from_request(ExternalityTrace& trace) {
    refresh_request(trace);
    refresh_deficit(trace);
    refresh_externality_cuts(trace);
}
void refresh_child_from_deficit(ExternalityTrace& trace) {
    refresh_deficit(trace);
    refresh_externality_cuts(trace);
}

[[nodiscard]] ExternalityTrace baseline(const std::uint16_t mask = all_external_claims_mask) {
    ExternalityTrace trace{};
    trace.parent = parent_output_baseline();
    HostedObservation observation{};
    observation.parent_closure_claim_digest = trace.parent.claim.claim_digest;
    observation.parent_manifest_digest = trace.parent.manifest.manifest_digest;
    observation.parent_publication_receipt_digest = trace.parent.publication.receipt_digest;
    observation.parent_reopen_receipt_digest = trace.parent.reopen.receipt_digest;
    observation.linked_parent_archive_digest = exact_digest(SLOPOS_HEN_LINKED_PARENT_ARCHIVE_SHA256_HEX);
    observation.claim_catalogue_digest = exact_digest(SLOPOS_HEN_CLAIM_CATALOGUE_SHA256_HEX);
    observation.handoff_policy_digest = exact_digest(SLOPOS_HEN_HANDOFF_POLICY_SHA256_HEX);
    observation.linked_parent_archive_bytes = SLOPOS_HEN_LINKED_PARENT_ARCHIVE_BYTES;
    observation.linked_parent_manifest_rows = SLOPOS_HEN_LINKED_PARENT_MANIFEST_ROWS;
    observation.requested_claim_mask = mask;
    observation.schema_version = externality_schema_version;
    observation.present = true;
    observation.canonical = true;
    observation.hosted_bytes_only = true;
    observation.external_receipt_absent = true;
    trace.left_observation = observation;
    trace.right_observation = observation;
    refresh_observations(trace);

    trace.left_external_facts.true_mask = 0U;
    trace.left_external_facts.canonical = true;
    trace.right_external_facts.true_mask = mask;
    trace.right_external_facts.canonical = true;

    trace.witness.observation_digest = trace.left_observation.observation_digest;
    trace.witness.left_world_label_digest = digest("world:left:external-predicates-false");
    trace.witness.right_world_label_digest = digest("world:right:requested-external-predicates-true");
    trace.witness.claim_catalogue_digest = exact_digest(SLOPOS_HEN_CLAIM_CATALOGUE_SHA256_HEX);
    trace.witness.handoff_policy_digest = exact_digest(SLOPOS_HEN_HANDOFF_POLICY_SHA256_HEX);
    trace.witness.parent_closure_claim_digest = trace.parent.claim.claim_digest;
    trace.witness.requested_claim_mask = mask;
    trace.witness.left_true_mask = 0U;
    trace.witness.right_true_mask = mask;
    trace.witness.schema_version = externality_schema_version;
    trace.witness.present = true;
    trace.witness.canonical = true;
    trace.witness.countermodel_only = true;
    trace.witness.no_external_occurrence_claimed = true;
    refresh_witness(trace);

    trace.request.linked_parent_archive_digest = exact_digest(SLOPOS_HEN_LINKED_PARENT_ARCHIVE_SHA256_HEX);
    trace.request.parent_closure_claim_digest = trace.parent.claim.claim_digest;
    trace.request.observation_digest = trace.left_observation.observation_digest;
    trace.request.witness_digest = trace.witness.witness_digest;
    trace.request.claim_catalogue_digest = exact_digest(SLOPOS_HEN_CLAIM_CATALOGUE_SHA256_HEX);
    trace.request.handoff_policy_digest = exact_digest(SLOPOS_HEN_HANDOFF_POLICY_SHA256_HEX);
    trace.request.requested_response_profile_digest = exact_digest(SLOPOS_HEN_RESPONSE_PROFILE_SHA256_HEX);
    trace.request.response_namespace_digest = digest("external-response-namespace:owner-handoff-v1");
    trace.request.linked_parent_archive_bytes = SLOPOS_HEN_LINKED_PARENT_ARCHIVE_BYTES;
    trace.request.linked_parent_manifest_rows = SLOPOS_HEN_LINKED_PARENT_MANIFEST_ROWS;
    trace.request.requested_claim_mask = mask;
    trace.request.schema_version = externality_schema_version;
    trace.request.present = true;
    trace.request.canonical = true;
    trace.request.request_only = true;
    trace.request.no_authority_claim = true;
    refresh_request(trace);

    trace.deficit.observation_digest = trace.left_observation.observation_digest;
    trace.deficit.witness_digest = trace.witness.witness_digest;
    trace.deficit.request_digest = trace.request.request_digest;
    trace.deficit.parent_closure_claim_digest = trace.parent.claim.claim_digest;
    trace.deficit.claim_catalogue_digest = exact_digest(SLOPOS_HEN_CLAIM_CATALOGUE_SHA256_HEX);
    trace.deficit.handoff_policy_digest = exact_digest(SLOPOS_HEN_HANDOFF_POLICY_SHA256_HEX);
    trace.deficit.requested_response_profile_digest = exact_digest(SLOPOS_HEN_RESPONSE_PROFILE_SHA256_HEX);
    trace.deficit.unresolved_claim_mask = mask;
    trace.deficit.schema_version = externality_schema_version;
    trace.deficit.present = true;
    trace.deficit.canonical = true;
    trace.deficit.all_requested_claims_unresolved = true;
    trace.deficit.external_response_absent = true;
    trace.deficit.no_acceptance_or_authority = true;
    refresh_deficit(trace);
    refresh_externality_cuts(trace);
    return trace;
}

[[nodiscard]] ExternalityTrace at_stage(const ExternalityTrace& complete, const std::size_t stage) {
    ExternalityTrace trace = complete;
    trace.promote_requested_claims_from_hosted_bytes = false;
    if (stage < 4U) trace.deficit = {};
    if (stage < 3U) trace.request = {};
    if (stage < 2U) trace.witness = {};
    if (stage < 1U) {
        trace.left_observation = {};
        trace.right_observation = {};
        trace.left_external_facts = {};
        trace.right_external_facts = {};
    }
    refresh_externality_cuts(trace);
    return trace;
}

void add_case(std::vector<Case>& cases, const std::string& name, ExternalityTrace trace, const BoundaryCode expected) {
    cases.push_back(Case{name, std::move(trace), expected});
}

[[nodiscard]] std::vector<Case> corpus() {
    const auto good = baseline();
    std::vector<Case> cases;
    const std::array<BoundaryCode, externality_cut_count> stage_codes{{
        BoundaryCode::accepted_parent_closed,
        BoundaryCode::accepted_observation_durable,
        BoundaryCode::accepted_nonderivation_witness,
        BoundaryCode::accepted_handoff_request_durable,
        BoundaryCode::accepted_premise_deficit_durable,
    }};
    for (std::size_t stage = 0U; stage < stage_codes.size(); ++stage) {
        add_case(cases, "durable_stage_" + std::to_string(stage), at_stage(good, stage), stage_codes[stage]);
    }
    for (std::size_t bit = 0U; bit < external_claim_count; ++bit) {
        add_case(cases, "single_claim_" + std::to_string(bit), baseline(static_cast<std::uint16_t>(1U << bit)),
            BoundaryCode::accepted_premise_deficit_durable);
    }

    { auto t = good; t.parent.parent.parent.graph.graph_digest = {}; refresh_externality_cuts(t);
      add_case(cases, "parent_rejected", t, BoundaryCode::parent_rejected); }
    { auto t = good; t.parent.claim = {}; refresh_cuts(t.parent); refresh_externality_cuts(t);
      add_case(cases, "parent_not_closed", t, BoundaryCode::parent_not_closure_ready); }
    { auto t = good; t.right_observation = {}; refresh_externality_cuts(t);
      add_case(cases, "right_observation_missing", t, BoundaryCode::observation_pair_incomplete); }
    { auto t = good; t.left_observation = {}; refresh_externality_cuts(t);
      add_case(cases, "left_observation_missing", t, BoundaryCode::observation_pair_incomplete); }
    { auto t = at_stage(good, 0U); t.witness = good.witness; refresh_externality_cuts(t);
      add_case(cases, "witness_without_observation", t, BoundaryCode::witness_without_observation); }

    for (std::size_t i = 0U; i < 7U; ++i) {
        auto t = good;
        if (i == 0U) { t.left_observation.canonical = false; t.right_observation.canonical = false; }
        if (i == 1U) { t.left_observation.hosted_bytes_only = false; t.right_observation.hosted_bytes_only = false; }
        if (i == 2U) { t.left_observation.external_receipt_absent = false; t.right_observation.external_receipt_absent = false; }
        if (i == 3U) { t.left_observation.schema_version = 2U; t.right_observation.schema_version = 2U; }
        if (i == 4U) { ++t.left_observation.linked_parent_archive_bytes; ++t.right_observation.linked_parent_archive_bytes; }
        if (i == 5U) { ++t.left_observation.linked_parent_manifest_rows; ++t.right_observation.linked_parent_manifest_rows; }
        if (i == 6U) { t.left_observation.present = false; t.right_observation.present = false; t.witness = {}; t.request = {}; t.deficit = {}; }
        refresh_observations(t); refresh_externality_cuts(t);
        add_case(cases, "observation_shape_" + std::to_string(i), t,
            i == 6U ? BoundaryCode::accepted_parent_closed : BoundaryCode::observation_shape_invalid);
    }
    for (std::size_t i = 0U; i < 7U; ++i) {
        auto t = good;
        Digest wrong = digest("wrong-observation-binding-" + std::to_string(i));
        if (i == 0U) { t.left_observation.parent_closure_claim_digest = wrong; t.right_observation.parent_closure_claim_digest = wrong; }
        if (i == 1U) { t.left_observation.parent_manifest_digest = wrong; t.right_observation.parent_manifest_digest = wrong; }
        if (i == 2U) { t.left_observation.parent_publication_receipt_digest = wrong; t.right_observation.parent_publication_receipt_digest = wrong; }
        if (i == 3U) { t.left_observation.parent_reopen_receipt_digest = wrong; t.right_observation.parent_reopen_receipt_digest = wrong; }
        if (i == 4U) { t.left_observation.linked_parent_archive_digest = wrong; t.right_observation.linked_parent_archive_digest = wrong; }
        if (i == 5U) { t.left_observation.claim_catalogue_digest = wrong; t.right_observation.claim_catalogue_digest = wrong; }
        if (i == 6U) { t.left_observation.handoff_policy_digest = wrong; t.right_observation.handoff_policy_digest = wrong; }
        refresh_observations(t); refresh_externality_cuts(t);
        add_case(cases, "observation_binding_" + std::to_string(i), t, BoundaryCode::observation_binding_mismatch);
    }
    { auto t = good; t.left_observation.observation_digest[0] ^= 1U; t.right_observation.observation_digest = t.left_observation.observation_digest; refresh_externality_cuts(t);
      add_case(cases, "observation_digest_wrong", t, BoundaryCode::observation_digest_mismatch); }
    { auto t = good; t.right_observation.requested_claim_mask = 1U; t.right_observation.observation_digest = hosted_observation_identity(t.right_observation); refresh_externality_cuts(t);
      add_case(cases, "observations_not_equivalent", t, BoundaryCode::observations_not_equivalent); }
    for (const auto bad : std::array<std::uint16_t, 2U>{{0U, 0x8000U}}) {
        auto t = good; t.left_observation.requested_claim_mask = bad; t.right_observation.requested_claim_mask = bad;
        refresh_observations(t); refresh_externality_cuts(t);
        add_case(cases, "claim_mask_invalid_" + std::to_string(bad), t, BoundaryCode::claim_mask_invalid);
    }
    { auto t = good; t.left_external_facts.canonical = false;
      add_case(cases, "left_external_facts_noncanonical", t, BoundaryCode::external_fact_mask_invalid); }
    { auto t = good; t.right_external_facts.true_mask = 0x8000U;
      add_case(cases, "right_external_facts_out_of_domain", t, BoundaryCode::external_fact_mask_invalid); }
    { auto t = good; t.right_external_facts.true_mask = 0U;
      add_case(cases, "requested_claims_do_not_diverge", t, BoundaryCode::requested_claims_do_not_diverge); }

    for (std::size_t i = 0U; i < 6U; ++i) {
        auto t = good;
        if (i == 0U) t.witness.canonical = false;
        if (i == 1U) t.witness.countermodel_only = false;
        if (i == 2U) t.witness.no_external_occurrence_claimed = false;
        if (i == 3U) t.witness.schema_version = 2U;
        if (i == 4U) t.witness.left_world_label_digest = {};
        if (i == 5U) t.witness.right_world_label_digest = t.witness.left_world_label_digest;
        refresh_child_from_witness(t);
        add_case(cases, "witness_shape_" + std::to_string(i), t, BoundaryCode::witness_shape_invalid);
    }
    for (std::size_t i = 0U; i < 7U; ++i) {
        auto t = good; Digest wrong = digest("wrong-witness-binding-" + std::to_string(i));
        if (i == 0U) t.witness.observation_digest = wrong;
        if (i == 1U) t.witness.claim_catalogue_digest = wrong;
        if (i == 2U) t.witness.handoff_policy_digest = wrong;
        if (i == 3U) t.witness.parent_closure_claim_digest = wrong;
        if (i == 4U) t.witness.requested_claim_mask = 1U;
        if (i == 5U) t.witness.left_true_mask = 1U;
        if (i == 6U) t.witness.right_true_mask = 1U;
        refresh_child_from_witness(t);
        add_case(cases, "witness_binding_" + std::to_string(i), t, BoundaryCode::witness_binding_mismatch);
    }
    { auto t = good; t.witness.witness_digest[0] ^= 1U; refresh_externality_cuts(t);
      add_case(cases, "witness_digest_wrong", t, BoundaryCode::witness_digest_mismatch); }
    { auto t = good; t.witness = {}; refresh_externality_cuts(t);
      add_case(cases, "request_without_witness", t, BoundaryCode::request_without_witness); }

    for (std::size_t i = 0U; i < 6U; ++i) {
        auto t = good;
        if (i == 0U) t.request.canonical = false;
        if (i == 1U) t.request.request_only = false;
        if (i == 2U) t.request.no_authority_claim = false;
        if (i == 3U) t.request.schema_version = 2U;
        if (i == 4U) ++t.request.linked_parent_archive_bytes;
        if (i == 5U) t.request.response_namespace_digest = {};
        refresh_child_from_request(t);
        add_case(cases, "request_shape_" + std::to_string(i), t, BoundaryCode::request_shape_invalid);
    }
    for (std::size_t i = 0U; i < 8U; ++i) {
        auto t = good; Digest wrong = digest("wrong-request-binding-" + std::to_string(i));
        if (i == 0U) t.request.linked_parent_archive_digest = wrong;
        if (i == 1U) t.request.parent_closure_claim_digest = wrong;
        if (i == 2U) t.request.observation_digest = wrong;
        if (i == 3U) t.request.witness_digest = wrong;
        if (i == 4U) t.request.claim_catalogue_digest = wrong;
        if (i == 5U) t.request.handoff_policy_digest = wrong;
        if (i == 6U) t.request.requested_response_profile_digest = wrong;
        if (i == 7U) t.request.requested_claim_mask = 1U;
        refresh_child_from_request(t);
        add_case(cases, "request_binding_" + std::to_string(i), t, BoundaryCode::request_binding_mismatch);
    }
    { auto t = good; t.request.request_digest[0] ^= 1U; refresh_externality_cuts(t);
      add_case(cases, "request_digest_wrong", t, BoundaryCode::request_digest_mismatch); }
    { auto t = good; t.request = {}; refresh_externality_cuts(t);
      add_case(cases, "deficit_without_request", t, BoundaryCode::deficit_without_request); }

    for (std::size_t i = 0U; i < 6U; ++i) {
        auto t = good;
        if (i == 0U) t.deficit.canonical = false;
        if (i == 1U) t.deficit.all_requested_claims_unresolved = false;
        if (i == 2U) t.deficit.external_response_absent = false;
        if (i == 3U) t.deficit.no_acceptance_or_authority = false;
        if (i == 4U) t.deficit.schema_version = 2U;
        if (i == 5U) t.deficit.unresolved_claim_mask = 0U;
        refresh_child_from_deficit(t);
        add_case(cases, "deficit_shape_" + std::to_string(i), t, BoundaryCode::deficit_shape_invalid);
    }
    for (std::size_t i = 0U; i < 8U; ++i) {
        auto t = good; Digest wrong = digest("wrong-deficit-binding-" + std::to_string(i));
        if (i == 0U) t.deficit.observation_digest = wrong;
        if (i == 1U) t.deficit.witness_digest = wrong;
        if (i == 2U) t.deficit.request_digest = wrong;
        if (i == 3U) t.deficit.parent_closure_claim_digest = wrong;
        if (i == 4U) t.deficit.claim_catalogue_digest = wrong;
        if (i == 5U) t.deficit.handoff_policy_digest = wrong;
        if (i == 6U) t.deficit.requested_response_profile_digest = wrong;
        if (i == 7U) t.deficit.unresolved_claim_mask = 1U;
        refresh_child_from_deficit(t);
        add_case(cases, "deficit_binding_" + std::to_string(i), t, BoundaryCode::deficit_binding_mismatch);
    }
    { auto t = good; t.deficit.certificate_digest[0] ^= 1U; refresh_externality_cuts(t);
      add_case(cases, "deficit_digest_wrong", t, BoundaryCode::deficit_digest_mismatch); }
    for (std::size_t bit = 0U; bit < external_claim_count; ++bit) {
        auto t = baseline(static_cast<std::uint16_t>(1U << bit));
        t.promote_requested_claims_from_hosted_bytes = true;
        add_case(cases, "hosted_promotion_forbidden_" + std::to_string(bit), t, BoundaryCode::hosted_promotion_forbidden);
    }
    for (std::size_t cut = 0U; cut < externality_cut_count; ++cut) {
        auto t = good; t.cuts[cut].parent_closure_claim_digest[0] ^= 1U;
        add_case(cases, "cut_order_invalid_" + std::to_string(cut), t, BoundaryCode::cut_order_invalid);
    }
    return cases;
}

template <std::size_t N>
[[nodiscard]] bool write_binary(const std::filesystem::path& path, const std::array<std::uint8_t, N>& bytes) {
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    output.write(reinterpret_cast<const char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
    return output.good();
}
[[nodiscard]] bool write_text(const std::filesystem::path& path, const std::string& text) {
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    output << text;
    return output.good();
}
[[nodiscard]] std::string cut_name(const std::size_t cut) {
    constexpr std::array<std::string_view, externality_cut_count> names{{
        "PARENT_CLOSED", "OBSERVATION_DURABLE", "NONDERIVATION_WITNESS_DURABLE",
        "OWNER_HANDOFF_REQUEST_DURABLE", "PREMISE_DEFICIT_DURABLE",
    }};
    return cut < names.size() ? std::string(names[cut]) : std::string("UNKNOWN");
}

}  // namespace

int run_campaign(const std::filesystem::path& output_directory) {
    std::error_code error;
    if (std::filesystem::exists(output_directory, error) || error) {
        std::cerr << "output directory must be absent\n";
        return false;
    }
    if (!std::filesystem::create_directory(output_directory, error) || error) {
        std::cerr << "cannot create output directory\n";
        return false;
    }

    const auto cases = corpus();
    const auto good = baseline();
    std::size_t accepted = 0U;
    std::size_t rejected = 0U;
    std::size_t handoff_ready = 0U;
    std::size_t disagreements = 0U;
    std::ostringstream case_rows;
    case_rows << "case\texpected\tcandidate\treference\taccepted\tnonderivation_witness\towner_handoff_ready\n";
    std::ostringstream countermodels;
    countermodels << "case\tclaim_scope\tresult\tboundary\n";

    for (const auto& item : cases) {
        const auto candidate = evaluate_candidate(item.trace);
        const auto reference = evaluate_reference(item.trace);
        if (candidate != reference) ++disagreements;
        if (candidate.code != item.expected || reference.code != item.expected) {
            std::cerr << "unexpected result case=" << item.name << " expected=" << boundary_code_name(item.expected)
                      << " candidate=" << boundary_code_name(candidate.code)
                      << " reference=" << boundary_code_name(reference.code) << "\n";
            return false;
        }
        if (candidate.accepted) ++accepted; else ++rejected;
        if (candidate.owner_handoff_ready) ++handoff_ready;
        case_rows << item.name << '\t' << boundary_code_name(item.expected) << '\t'
                  << boundary_code_name(candidate.code) << '\t' << boundary_code_name(reference.code) << '\t'
                  << (candidate.accepted ? "true" : "false") << '\t'
                  << (candidate.nonderivation_witness ? "true" : "false") << '\t'
                  << (candidate.owner_handoff_ready ? "true" : "false") << '\n';
        if (!candidate.accepted) countermodels << item.name << "\tmechanical-boundary\tREJECTED\t"
            << boundary_code_name(candidate.code) << '\n';
    }
    if (disagreements != 0U) {
        std::cerr << "candidate/reference disagreements=" << disagreements << "\n";
        return false;
    }

    std::ostringstream cuts;
    cuts << "case\tcut\tcut_name\tcandidate\treference\taccepted\towner_handoff_ready\n";
    std::size_t cut_rows = 0U;
    for (const auto& item : cases) {
        for (std::size_t cut = 0U; cut < externality_cut_count; ++cut) {
            const auto projected = at_stage(item.trace, cut);
            const auto candidate = evaluate_candidate(projected);
            const auto reference = evaluate_reference(projected);
            if (candidate != reference) {
                std::cerr << "cut disagreement case=" << item.name << " cut=" << cut << "\n";
                return false;
            }
            cuts << item.name << '\t' << cut << '\t' << cut_name(cut) << '\t'
                 << boundary_code_name(candidate.code) << '\t' << boundary_code_name(reference.code) << '\t'
                 << (candidate.accepted ? "true" : "false") << '\t'
                 << (candidate.owner_handoff_ready ? "true" : "false") << '\n';
            ++cut_rows;
        }
    }

    EncodedHostedObservation observation_bytes{};
    EncodedTwinWorldWitness witness_bytes{};
    EncodedOwnerHandoffRequest request_bytes{};
    EncodedPremiseDeficitCertificate deficit_bytes{};
    if (!encode_hosted_observation(good.left_observation, observation_bytes)
        || !encode_twin_world_witness(good.witness, witness_bytes)
        || !encode_owner_handoff_request(good.request, request_bytes)
        || !encode_premise_deficit_certificate(good.deficit, deficit_bytes)) {
        std::cerr << "canonical encoding failed\n";
        return false;
    }

    std::ostringstream identities;
    identities << "object\tbytes\tsha256\n"
        << "HOSTED-OBSERVATION.bin\t" << observation_bytes.size() << '\t' << hex(good.left_observation.observation_digest) << '\n'
        << "TWIN-WORLD-WITNESS.bin\t" << witness_bytes.size() << '\t' << hex(good.witness.witness_digest) << '\n'
        << "OWNER-HANDOFF-REQUEST.bin\t" << request_bytes.size() << '\t' << hex(good.request.request_digest) << '\n'
        << "PREMISE-DEFICIT-CERTIFICATE.bin\t" << deficit_bytes.size() << '\t' << hex(good.deficit.certificate_digest) << '\n';

    std::ostringstream claims;
    claims << "bit\tmask\tclaim\tleft_world\tright_world\thosted_observation_equal\tderived\n";
    for (std::size_t bit = 0U; bit < external_claim_count; ++bit) {
        claims << bit << "\t0x" << std::hex << std::setw(4) << std::setfill('0') << (1U << bit)
               << std::dec << std::setfill(' ') << '\t' << external_claim_name(bit)
               << "\tfalse\ttrue\ttrue\tfalse\n";
        countermodels << "twin_world_claim_" << bit << '\t' << external_claim_name(bit)
                      << "\tNONDERIVABLE\tBYTE_IDENTICAL_HOSTED_OBSERVATION\n";
    }

    const std::string laws =
        "law\tstatement\n"
        "L1\tThe sole parent is one exact closure-ready Observed Output Closure trace.\n"
        "L2\tThe hosted observation binds exact parent closure, manifest, publication, reopen, archive, catalogue, and policy identities.\n"
        "L3\tFor every requested external claim there exist two modeled worlds with byte-identical hosted observation and opposite external fact.\n"
        "L4\tA deterministic verifier restricted to the hosted observation cannot soundly distinguish those worlds.\n"
        "L5\tThe twin-world witness is a countermodel only and is not evidence that either external world occurred.\n"
        "L6\tThe owner handoff request is a request-only object and grants no authority.\n"
        "L7\tThe premise deficit certificate keeps every requested claim unresolved while an external response is absent.\n"
        "L8\tNo hosted Boolean, digest, receipt, or role label may promote an external claim.\n"
        "L9\tExternal publication, operation, administration, custody, rollback fate, and shared view require evidence rooted outside the subject.\n"
        "L10\tSource truth, world dependency closure, trusted builder control, owner admission, authority, and Epoch-Zero exit remain false.\n"
        "L11\tEvery durable prefix is resumable and cannot imply a later object.\n"
        "L12\tThe child remains a nested proof island and adds no provider, network service, signer, database, or fourth semantic island.\n";

    std::ostringstream summary;
    summary << "metric\tvalue\n"
        << "cases\t" << cases.size() << '\n'
        << "accepted_classifications\t" << accepted << '\n'
        << "rejected_classifications\t" << rejected << '\n'
        << "owner_handoff_ready_cases\t" << handoff_ready << '\n'
        << "lifecycle_cut_rows\t" << cut_rows << '\n'
        << "durable_stages\t" << externality_cut_count << '\n'
        << "external_claims\t" << external_claim_count << '\n'
        << "twin_world_countermodels\t" << external_claim_count << '\n'
        << "canonical_exact_object_bytes\t" << canonical_exact_object_bytes << '\n'
        << "candidate_reference_disagreements\t0\n"
        << "hosted_promotion_permitted\tfalse\n"
        << "external_response_present\tfalse\n"
        << "authority_granted\tfalse\n"
        << "epoch_exit_proved\tfalse\n";

    std::ostringstream report;
    report << "HOSTED_EXTERNALITY_NONDERIVATION=PASS\n"
        << "cases=" << cases.size() << " accepted=" << accepted << " rejected=" << rejected
        << " cuts=" << cut_rows << " handoff_ready=" << handoff_ready << "\n"
        << "external_claims=" << external_claim_count << " twin_world_countermodels=" << external_claim_count
        << " exact_objects=" << canonical_exact_object_bytes << "\n"
        << "candidate_reference_disagreements=0 hosted_observations_byte_identical=true hosted_promotion=false\n"
        << "external_response=false source_truth=false trusted_builder=false external_occurrence=false administrative_independence=false authority=false epoch_exit=false\n";

    const bool written = write_binary(output_directory / "HOSTED-OBSERVATION.bin", observation_bytes)
        && write_binary(output_directory / "TWIN-WORLD-WITNESS.bin", witness_bytes)
        && write_binary(output_directory / "OWNER-HANDOFF-REQUEST.bin", request_bytes)
        && write_binary(output_directory / "PREMISE-DEFICIT-CERTIFICATE.bin", deficit_bytes)
        && write_text(output_directory / "CASES.tsv", case_rows.str())
        && write_text(output_directory / "CUTS.tsv", cuts.str())
        && write_text(output_directory / "CLAIMS.tsv", claims.str())
        && write_text(output_directory / "IDENTITIES.tsv", identities.str())
        && write_text(output_directory / "LAWS.tsv", laws)
        && write_text(output_directory / "COUNTERMODELS.tsv", countermodels.str())
        && write_text(output_directory / "SUMMARY.tsv", summary.str())
        && write_text(output_directory / "REPORT.txt", report.str());
    if (!written) return false;
    std::cout << report.str();
    return true;
}

}  // namespace
