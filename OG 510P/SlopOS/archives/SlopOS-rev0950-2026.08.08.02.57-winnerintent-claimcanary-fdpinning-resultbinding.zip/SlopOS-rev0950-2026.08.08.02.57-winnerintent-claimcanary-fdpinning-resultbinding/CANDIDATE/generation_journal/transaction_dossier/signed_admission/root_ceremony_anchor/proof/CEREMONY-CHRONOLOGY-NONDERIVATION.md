# Ceremony chronology and currentness nonderivation

## Proposition actually established

Let `A` be one canonical 512-byte anchor, `S` one canonical 320-byte
root-succession statement, and `t` an observation time. If
`AnchorRelation(A,S,t)` is valid, then the exact bytes of `S` commit to the head
of `A`; `A` in turn commits to exact RC0/RC1 receipt-head observations, expected
register incarnation, exact adjacent root edge, ceremony policy, ordered time
observations, and one deterministic request identity.

This is a **binding theorem**, not an occurrence theorem.

## Why chronology does not arise from a field name

The inherited statement carried both `successor_manifest_head` and
`precommitted_successor_head`. Equality of those fields proved only that the
statement repeated the same digest. It did not establish an event before
signing. The repaired relation binds an exact RC1 receipt head and requires its
recorded-time observation to precede the signing floor. Even that stronger
relation needs an authenticated, unpredictable, externally issued RC1 receipt;
otherwise a constructor can fabricate both bytes and timestamps before or after
signing.

## Countermodels retained

### C1 — fabricated receipt packet

An attacker invents plausible RC0 and RC1 byte strings, hashes them, constructs
a canonical anchor, and obtains signatures over its head. Every local byte
predicate can pass. The receipts are still unauthenticated. Therefore:

`valid_relation !-> external_receipt_authenticity`.

### C2 — same logical register, restored incarnation

A snapshot produces register `R` in incarnation `I2` while a ceremony was
anchored to `I1`. If the statement was signed over the `I1` anchor, the `I2`
anchor has another head and is rejected. This proves cross-binding, not that
`I1` is globally current. Selecting the expected incarnation remains an
external premise.

### C3 — two isolated current-looking clones

Two clones share the same RC0 receipt, RC1 receipt, anchor, signatures, and
request ID. Each validates locally. Unless both requests reach one protected
serialization point with durable duplicate suppression, each clone can commit
an effect in its own history. Therefore:

`deterministic_request_id !-> global_one_use`.

### C4 — equivocal receipt producer

A service signs two mutually inconsistent RC1 receipts for different observers.
Each observer can construct a valid anchor. A transparency structure can make
later comparison efficient, but without witness exchange or an externally
selected view, each observer can still hold a self-consistent fork. Therefore:

`authenticated_receipt !-> unique_current_view`.

### C5 — commit without response

The external register commits the request and the response is lost. Minting a
new request ID and retrying can produce a second effect. The anchor prevents
request-identity drift only if the provider stores duplicate identity and
returns or exposes the prior result. The safe client transition is effect to
query, never timeout to no-effect.

### C6 — one custody domain wears two threshold labels

Old and new threshold signatures can satisfy the byte relation while the same
operator controls every private key and the external register. Mathematical
threshold separation does not prove administrative independence.

## Remaining proof premises

The linked office must still obtain and retain:

1. an owner-ratified starting-root receipt;
2. a named external register and exact expected incarnation;
3. authenticated RC1 semantics, including unpredictable service material and a
   defined time/order interpretation;
4. old/new signer custody evidence and dual-threshold signatures over the exact
   anchor head;
5. one compare/apply request at a non-cloned serialization point;
6. a terminal response or query-only reconciliation under the same request ID;
7. a restore/fork drill proving the protected history's boundary; and
8. an independent reopen followed by owner judgment.

Until those events occur, Epoch Zero and `authority=false` are the only coherent
state.
