#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/reopen_receipt_chain.hpp"

#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <string>
#include <string_view>
#include <system_error>
#include <utility>
#include <vector>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain {
namespace {

struct TestCase final {
    std::string name;
    ReceiptChainTrace trace;
    ReceiptChainCode expected;
};

[[nodiscard]] Digest digest(const std::uint8_t seed) noexcept {
    Digest value{};
    for (std::size_t index = 0U; index < value.size(); ++index) {
        value[index] = static_cast<std::uint8_t>(seed + static_cast<std::uint8_t>(index));
    }
    return value;
}

[[nodiscard]] TerminalState terminal(const TerminalKind kind = TerminalKind::effect) noexcept {
    return TerminalState{digest(0x11U), digest(0x31U), digest(0x51U), digest(0x71U), kind};
}

[[nodiscard]] ContinuityEvidence continuity(const TerminalState& state) noexcept {
    ContinuityEvidence value{};
    value.request_id = state.request_id;
    value.transition_digest = state.transition_digest;
    value.register_incarnation = state.register_incarnation;
    value.terminal_digest = state.terminal_digest;
    value.terminal_kind = state.terminal_kind;
    value.terminal_record_present = true;
    value.terminal_record_authenticated = true;
    value.terminal_record_durable = true;
    value.terminal_record_serialized = true;
    value.terminal_record_single_view = true;
    value.terminal_record_retained_full_horizon = true;
    value.terminal_record_fences_pending = true;
    value.terminal_record_survives_restore = true;
    value.terminal_record_survives_succession = true;
    value.terminal_record_independently_reopenable = true;
    value.terminal_witness_present = true;
    value.terminal_witness_authenticated = true;
    value.terminal_witness_binds_terminal = true;
    value.terminal_witness_durable = true;
    value.terminal_witness_independently_reopenable = true;
    value.terminal_witness_survives_restore = true;
    value.terminal_witness_survives_succession = true;
    value.successor_floor_present = true;
    value.successor_floor_authenticated = true;
    value.successor_floor_monotone = true;
    value.successor_floor_outside_restore_domain = true;
    value.successor_floor_binds_request_namespace = true;
    value.old_incarnation_rejected = true;
    value.pending_invocations_fenced = true;
    value.restore_preserves_floor = true;
    value.succession_preserves_floor = true;
    value.successor_floor_single_view = true;
    value.reclamation_requested = true;
    return value;
}

[[nodiscard]] JoinReceipt join(const CutoverTrace& trace) noexcept {
    JoinReceipt value{};
    value.cutover_id = trace.cutover_id;
    value.request_id = trace.state.request_id;
    value.transition_digest = trace.state.transition_digest;
    value.register_incarnation = trace.state.register_incarnation;
    value.terminal_digest = trace.state.terminal_digest;
    value.witness_digest = trace.witness_digest;
    value.floor_digest = trace.floor_digest;
    value.terminal_kind = trace.state.terminal_kind;
    value.present = true;
    value.authenticated = true;
    value.durable = true;
    value.single_view = true;
    value.independently_reopenable = true;
    value.survives_restore = true;
    value.survives_succession = true;
    return value;
}

[[nodiscard]] CutObservation pcut(
    const bool live, const bool witness, const bool floor, const bool joined,
    const bool authorized, const bool deleted, const bool reopened) noexcept {
    return CutObservation{live, witness, floor, joined, authorized, deleted, reopened};
}

[[nodiscard]] CutoverTrace parent_trace(const TerminalKind kind, const bool deleted) noexcept {
    CutoverTrace trace{};
    trace.state = terminal(kind);
    trace.continuity = continuity(trace.state);
    trace.cutover_id = digest(0x91U);
    trace.witness_digest = digest(0xB1U);
    trace.floor_digest = digest(0xD1U);
    trace.reclamation_requested = true;
    trace.join = join(trace);
    trace.cuts = {
        pcut(true, false, false, false, false, false, false),
        pcut(true, true, false, false, false, false, false),
        pcut(true, true, true, false, false, false, false),
        pcut(true, true, true, true, false, false, false),
        pcut(true, true, true, true, false, false, true),
        pcut(true, true, true, true, deleted, false, true),
        pcut(!deleted, true, true, true, deleted, deleted, true),
    };
    return trace;
}

[[nodiscard]] exact_predecessor_consumption::PhaseReceipt exact_receipt(
    const exact_predecessor_consumption::Phase phase,
    const std::uint8_t identity_seed,
    const exact_predecessor_consumption::ChainTrace& trace) noexcept {
    exact_predecessor_consumption::PhaseReceipt value{};
    value.phase = phase;
    value.record_digest = digest(identity_seed);
    value.cutover_id = trace.parent.cutover_id;
    value.request_id = trace.parent.state.request_id;
    value.transition_digest = trace.parent.state.transition_digest;
    value.register_incarnation = trace.parent.state.register_incarnation;
    value.terminal_digest = trace.parent.state.terminal_digest;
    value.witness_digest = trace.parent.witness_digest;
    value.floor_digest = trace.parent.floor_digest;
    value.terminal_kind = trace.parent.state.terminal_kind;
    switch (phase) {
    case exact_predecessor_consumption::Phase::witness_publication:
        value.basis_digest = trace.parent.witness_digest;
        break;
    case exact_predecessor_consumption::Phase::floor_publication:
        value.basis_digest = trace.parent.floor_digest;
        break;
    case exact_predecessor_consumption::Phase::join_publication:
        value.basis_digest = trace.parent.cutover_id;
        break;
    case exact_predecessor_consumption::Phase::cold_reopen_receipt:
        value.basis_digest = trace.parent.state.terminal_digest;
        break;
    case exact_predecessor_consumption::Phase::deletion_authorization:
        value.basis_digest = trace.parent.state.transition_digest;
        break;
    }
    value.present = true;
    value.authenticated = true;
    value.durable = true;
    value.single_view = true;
    value.independently_reopenable = true;
    value.survives_restore = true;
    value.survives_succession = true;
    value.published = true;
    return value;
}

[[nodiscard]] exact_predecessor_consumption::ChainCut exact_cut(
    const bool live,
    const std::array<bool, exact_predecessor_consumption::phase_count>& visible,
    const bool deleted = false) noexcept {
    return exact_predecessor_consumption::ChainCut{live, visible, deleted};
}

[[nodiscard]] exact_predecessor_consumption::ChainTrace exact_trace(
    const TerminalKind kind, const bool deleted) noexcept {
    using exact_predecessor_consumption::Phase;
    exact_predecessor_consumption::ChainTrace trace{};
    trace.parent = parent_trace(kind, deleted);
    trace.reclamation_requested = true;
    trace.receipts[0] = exact_receipt(Phase::witness_publication, 0x21U, trace);
    trace.receipts[1] = exact_receipt(Phase::floor_publication, 0x41U, trace);
    trace.receipts[2] = exact_receipt(Phase::join_publication, 0x61U, trace);
    trace.receipts[3] = exact_receipt(Phase::cold_reopen_receipt, 0x81U, trace);
    trace.receipts[4] = exact_receipt(Phase::deletion_authorization, 0xA1U, trace);
    trace.receipts[2].predecessor_a = trace.receipts[0].record_digest;
    trace.receipts[2].predecessor_b = trace.receipts[1].record_digest;
    trace.receipts[3].predecessor_a = trace.receipts[2].record_digest;
    trace.receipts[4].predecessor_a = trace.receipts[3].record_digest;
    trace.deletion_consumed_authorization_digest = trace.receipts[4].record_digest;
    const std::array<bool, exact_predecessor_consumption::phase_count> none{false, false, false, false, false};
    const std::array<bool, exact_predecessor_consumption::phase_count> witness{true, false, false, false, false};
    const std::array<bool, exact_predecessor_consumption::phase_count> components{true, true, false, false, false};
    const std::array<bool, exact_predecessor_consumption::phase_count> joined{true, true, true, false, false};
    const std::array<bool, exact_predecessor_consumption::phase_count> reopened{true, true, true, true, false};
    const std::array<bool, exact_predecessor_consumption::phase_count> authorized{true, true, true, true, true};
    trace.cuts = {
        exact_cut(true, none),
        exact_cut(true, witness),
        exact_cut(true, components),
        exact_cut(true, joined),
        exact_cut(true, reopened),
        exact_cut(true, authorized),
        exact_cut(true, authorized),
        exact_cut(!deleted, authorized, deleted),
    };
    return trace;
}

[[nodiscard]] SourceClosure source(const ReceiptChainTrace& trace) noexcept {
    SourceClosure value{};
    value.closure_digest = digest(0x15U);
    value.cutover_id = trace.predecessor.parent.cutover_id;
    value.join_digest = trace.join_digest;
    value.witness_digest = trace.predecessor.parent.witness_digest;
    value.floor_digest = trace.predecessor.parent.floor_digest;
    value.request_id = trace.predecessor.parent.state.request_id;
    value.transition_digest = trace.predecessor.parent.state.transition_digest;
    value.register_incarnation = trace.predecessor.parent.state.register_incarnation;
    value.terminal_digest = trace.predecessor.parent.state.terminal_digest;
    value.reopener_incarnation = digest(0x25U);
    value.verifier_id = digest(0x35U);
    value.verifier_policy_digest = digest(0x45U);
    value.terminal_kind = trace.predecessor.parent.state.terminal_kind;
    value.present = true;
    value.canonical = true;
    value.complete = true;
    value.independently_locatable = true;
    value.rollback_external = true;
    value.replacement_only = true;
    value.no_hidden_inputs = true;
    value.includes_live_terminal_record = false;
    return value;
}

[[nodiscard]] ReopenReceipt reopen(const ReceiptChainTrace& trace) noexcept {
    ReopenReceipt value{};
    value.receipt_digest = trace.predecessor.receipts[static_cast<std::size_t>(
        exact_predecessor_consumption::Phase::cold_reopen_receipt)].record_digest;
    value.closure_digest = trace.source.closure_digest;
    value.cutover_id = trace.predecessor.parent.cutover_id;
    value.join_digest = trace.join_digest;
    value.witness_digest = trace.predecessor.parent.witness_digest;
    value.floor_digest = trace.predecessor.parent.floor_digest;
    value.request_id = trace.predecessor.parent.state.request_id;
    value.transition_digest = trace.predecessor.parent.state.transition_digest;
    value.register_incarnation = trace.predecessor.parent.state.register_incarnation;
    value.terminal_digest = trace.predecessor.parent.state.terminal_digest;
    value.reopener_incarnation = trace.source.reopener_incarnation;
    value.verifier_id = trace.source.verifier_id;
    value.verifier_policy_digest = trace.source.verifier_policy_digest;
    value.terminal_kind = trace.predecessor.parent.state.terminal_kind;
    value.present = true;
    value.computed_from_closure = true;
    value.exact_result = true;
    value.authenticated = true;
    value.no_replace_published = true;
    value.durable = true;
    value.directory_entry_durable = true;
    value.single_view = true;
    value.independently_reopenable = true;
    return value;
}

[[nodiscard]] AuthorizationCapsule authorization(const ReceiptChainTrace& trace) noexcept {
    AuthorizationCapsule value{};
    value.authorization_digest = trace.predecessor.receipts[static_cast<std::size_t>(
        exact_predecessor_consumption::Phase::deletion_authorization)].record_digest;
    value.reopen_receipt_digest = trace.reopen.receipt_digest;
    value.cutover_id = trace.predecessor.parent.cutover_id;
    value.target_digest = trace.target_digest;
    value.owner_policy_digest = trace.owner_policy_digest;
    value.retention_policy_digest = trace.retention_policy_digest;
    value.present = true;
    value.authenticated = true;
    value.durable = true;
    value.no_replace_published = true;
    value.single_view = true;
    value.separately_governed = true;
    value.independently_reopenable = true;
    return value;
}

[[nodiscard]] DeletionReceipt deletion(const ReceiptChainTrace& trace) noexcept {
    DeletionReceipt value{};
    value.deletion_receipt_digest = digest(0x75U);
    value.authorization_digest = trace.authorization.authorization_digest;
    value.cutover_id = trace.predecessor.parent.cutover_id;
    value.target_digest = trace.target_digest;
    value.present = true;
    value.authenticated = true;
    value.durable = true;
    value.no_replace_published = true;
    value.single_view = true;
    value.target_absence_observed = true;
    return value;
}

[[nodiscard]] ReceiptCut rcut(
    const bool live, const bool started, const bool computed, const bool receipt,
    const bool receipt_reopened, const bool auth, const bool auth_reopened,
    const bool deleted, const bool deletion_receipt) noexcept {
    return ReceiptCut{live, true, started, computed, receipt, receipt_reopened,
        auth, auth_reopened, deleted, deletion_receipt};
}

[[nodiscard]] std::array<ReceiptCut, receipt_cut_count> complete_cuts() noexcept {
    return {
        rcut(true, false, false, false, false, false, false, false, false),
        rcut(true, true, false, false, false, false, false, false, false),
        rcut(true, true, true, false, false, false, false, false, false),
        rcut(true, true, true, true, false, false, false, false, false),
        rcut(true, true, true, true, true, false, false, false, false),
        rcut(true, true, true, true, true, true, false, false, false),
        rcut(true, true, true, true, true, true, true, false, false),
        rcut(false, true, true, true, true, true, true, true, false),
        rcut(false, true, true, true, true, true, true, true, true),
    };
}

[[nodiscard]] std::array<ReceiptCut, receipt_cut_count> ready_cuts() noexcept {
    auto cuts = complete_cuts();
    cuts[7] = rcut(true, true, true, true, true, true, true, false, false);
    cuts[8] = cuts[7];
    return cuts;
}

[[nodiscard]] std::array<ReceiptCut, receipt_cut_count> live_cuts() noexcept {
    std::array<ReceiptCut, receipt_cut_count> cuts{};
    for (auto& cut : cuts) cut = rcut(true, false, false, false, false, false, false, false, false);
    return cuts;
}

[[nodiscard]] ReceiptChainTrace base_trace(
    const bool deleted = false,
    const TerminalKind kind = TerminalKind::effect) noexcept {
    ReceiptChainTrace trace{};
    // The child owns the destructive extension.  Its embedded predecessor is
    // always the accepted still-live exact prefix, even for child-complete cases.
    trace.predecessor = exact_trace(kind, false);
    trace.join_digest = trace.predecessor.receipts[static_cast<std::size_t>(
        exact_predecessor_consumption::Phase::join_publication)].record_digest;
    trace.target_digest = digest(0x85U);
    trace.owner_policy_digest = digest(0x95U);
    trace.retention_policy_digest = digest(0xA5U);
    trace.source = source(trace);
    trace.reopen = reopen(trace);
    trace.authorization = authorization(trace);
    trace.deletion = deletion(trace);
    trace.cuts = deleted ? complete_cuts() : ready_cuts();
    trace.reclamation_requested = true;
    return trace;
}

[[nodiscard]] std::vector<TestCase> cases() {
    std::vector<TestCase> values;
    const auto add = [&values](std::string name, ReceiptChainTrace trace, const ReceiptChainCode expected) {
        values.push_back(TestCase{std::move(name), std::move(trace), expected});
    };

    // Eight complete chains and four ready chains.
    add("complete_effect_exact", base_trace(true, TerminalKind::effect), ReceiptChainCode::accepted_chain_complete);
    add("complete_no_effect_exact", base_trace(true, TerminalKind::no_effect), ReceiptChainCode::accepted_chain_complete);
    for (std::uint8_t i = 0U; i < 6U; ++i) {
        auto trace = base_trace(true, (i % 2U == 0U) ? TerminalKind::effect : TerminalKind::no_effect);
        trace.source.reopener_incarnation = digest(static_cast<std::uint8_t>(0x26U + i));
        trace.reopen.reopener_incarnation = trace.source.reopener_incarnation;
        add("complete_distinct_reopener_" + std::to_string(i + 1U), trace, ReceiptChainCode::accepted_chain_complete);
    }
    for (std::uint8_t i = 0U; i < 4U; ++i) {
        auto trace = base_trace(false, (i % 2U == 0U) ? TerminalKind::effect : TerminalKind::no_effect);
        trace.owner_policy_digest = digest(static_cast<std::uint8_t>(0x96U + i));
        trace.authorization.owner_policy_digest = trace.owner_policy_digest;
        add("ready_live_retained_" + std::to_string(i + 1U), trace, ReceiptChainCode::accepted_chain_ready_live_retained);
    }

    // Four inert traces retain the complete live basis.
    for (std::uint8_t i = 0U; i < 4U; ++i) {
        auto trace = base_trace(false, TerminalKind::effect);
        trace.cuts = live_cuts();
        trace.target_digest = digest(static_cast<std::uint8_t>(0x86U + i));
        trace.authorization.target_digest = trace.target_digest;
        trace.deletion.target_digest = trace.target_digest;
        add("live_basis_retained_" + std::to_string(i + 1U), trace, ReceiptChainCode::accepted_live_basis_retained);
    }

    // Source-closure refusals.
    {
        auto trace = base_trace(false); trace.source.includes_live_terminal_record = true;
        add("refused_source_live_record_contamination", trace, ReceiptChainCode::accepted_reclamation_refused_source_closure_gap);
    }
    {
        auto trace = base_trace(false); trace.source.no_hidden_inputs = false;
        add("refused_source_hidden_inputs", trace, ReceiptChainCode::accepted_reclamation_refused_source_closure_gap);
    }
    {
        auto trace = base_trace(false); trace.source.replacement_only = false;
        add("refused_source_not_replacement_only", trace, ReceiptChainCode::accepted_reclamation_refused_source_closure_gap);
    }
    {
        auto trace = base_trace(false); trace.source.rollback_external = false;
        add("refused_source_inside_restore_domain", trace, ReceiptChainCode::accepted_reclamation_refused_source_closure_gap);
    }
    {
        auto trace = base_trace(false); trace.source.independently_locatable = false;
        add("refused_source_not_independently_locatable", trace, ReceiptChainCode::accepted_reclamation_refused_source_closure_gap);
    }
    {
        auto trace = base_trace(false); trace.source.complete = false;
        add("refused_source_incomplete", trace, ReceiptChainCode::accepted_reclamation_refused_source_closure_gap);
    }

    // Publication and independent-reopen refusals.
    {
        auto trace = base_trace(false); trace.reopen.no_replace_published = false;
        add("refused_publication_replaceable", trace, ReceiptChainCode::accepted_reclamation_refused_publication_gap);
    }
    {
        auto trace = base_trace(false); trace.reopen.durable = false;
        add("refused_publication_not_durable", trace, ReceiptChainCode::accepted_reclamation_refused_publication_gap);
    }
    {
        auto trace = base_trace(false); trace.reopen.directory_entry_durable = false;
        add("refused_publication_directory_not_durable", trace, ReceiptChainCode::accepted_reclamation_refused_publication_gap);
    }
    {
        auto trace = base_trace(false); trace.reopen.exact_result = false;
        add("refused_publication_wrong_reconstruction", trace, ReceiptChainCode::accepted_reclamation_refused_publication_gap);
    }
    {
        auto trace = base_trace(false); trace.reopen.independently_reopenable = false;
        add("refused_receipt_not_independently_reopenable", trace, ReceiptChainCode::accepted_reclamation_refused_receipt_reopen_gap);
    }
    {
        auto trace = base_trace(false); trace.cuts[4].reopen_receipt_reopened = false;
        for (std::size_t i = 5U; i < receipt_cut_count; ++i) trace.cuts[i].reopen_receipt_reopened = false;
        trace.cuts[5].authorization_visible = false; trace.cuts[6].authorization_visible = false;
        trace.cuts[6].authorization_reopened = false; trace.cuts[7] = trace.cuts[6]; trace.cuts[8] = trace.cuts[6];
        add("refused_receipt_never_reopened", trace, ReceiptChainCode::accepted_reclamation_refused_receipt_reopen_gap);
    }
    {
        auto trace = base_trace(false); trace.reopen.authenticated = false;
        add("refused_receipt_unauthenticated", trace, ReceiptChainCode::accepted_reclamation_refused_publication_gap);
    }
    {
        auto trace = base_trace(false); trace.reopen.single_view = false;
        add("refused_receipt_split_view", trace, ReceiptChainCode::accepted_reclamation_refused_publication_gap);
    }

    // Authorization refusals.
    {
        auto trace = base_trace(false); trace.authorization.separately_governed = false;
        add("refused_authorization_same_administration", trace, ReceiptChainCode::accepted_reclamation_refused_authorization_gap);
    }
    {
        auto trace = base_trace(false); trace.authorization.no_replace_published = false;
        add("refused_authorization_replaceable", trace, ReceiptChainCode::accepted_reclamation_refused_authorization_gap);
    }
    {
        auto trace = base_trace(false); trace.authorization.durable = false;
        add("refused_authorization_not_durable", trace, ReceiptChainCode::accepted_reclamation_refused_authorization_gap);
    }
    {
        auto trace = base_trace(false); trace.authorization.single_view = false;
        add("refused_authorization_split_view", trace, ReceiptChainCode::accepted_reclamation_refused_authorization_gap);
    }
    {
        auto trace = base_trace(false); trace.authorization.independently_reopenable = false;
        add("refused_authorization_not_independently_reopenable", trace, ReceiptChainCode::accepted_reclamation_refused_authorization_reopen_gap);
    }
    {
        auto trace = base_trace(false); trace.cuts[6].authorization_reopened = false;
        trace.cuts[7] = trace.cuts[6]; trace.cuts[8] = trace.cuts[6];
        add("refused_authorization_never_reopened", trace, ReceiptChainCode::accepted_reclamation_refused_authorization_reopen_gap);
    }

    // Same-cut and predecessor-order countermodels.
    {
        auto trace = base_trace(false); trace.cuts[1].reconstruction_computed = true;
        add("refused_order_compute_same_cut_as_start", trace, ReceiptChainCode::accepted_reclamation_refused_order_gap);
    }
    {
        auto trace = base_trace(false); trace.cuts[2].reopen_receipt_visible = true;
        add("refused_order_receipt_same_cut_as_compute", trace, ReceiptChainCode::accepted_reclamation_refused_order_gap);
    }
    {
        auto trace = base_trace(false); trace.cuts[3].reopen_receipt_reopened = true;
        add("refused_order_receipt_reopen_same_cut_as_publish", trace, ReceiptChainCode::accepted_reclamation_refused_order_gap);
    }
    {
        auto trace = base_trace(false); trace.cuts[4].authorization_visible = true;
        add("refused_order_authorize_same_cut_as_receipt_reopen", trace, ReceiptChainCode::accepted_reclamation_refused_order_gap);
    }
    {
        auto trace = base_trace(false); trace.cuts[5].authorization_reopened = true;
        add("refused_order_authorization_reopen_same_cut_as_publish", trace, ReceiptChainCode::accepted_reclamation_refused_order_gap);
    }
    {
        auto trace = base_trace(true); trace.cuts[6].record_deleted = true; trace.cuts[6].live_record_visible = false;
        add("fail_stop_order_delete_same_cut_as_authorization_reopen", trace, ReceiptChainCode::accepted_unauthorized_deletion_fail_stop);
    }
    {
        auto trace = base_trace(true); trace.cuts[7].deletion_receipt_visible = true;
        add("fail_stop_order_deletion_receipt_same_cut_as_delete", trace, ReceiptChainCode::accepted_unauthorized_deletion_fail_stop);
    }

    // Irreversible deletion without a complete predecessor chain.
    {
        auto trace = base_trace(true); trace.source.includes_live_terminal_record = true;
        add("fail_stop_deleted_with_contaminated_source", trace, ReceiptChainCode::accepted_unauthorized_deletion_fail_stop);
    }
    {
        auto trace = base_trace(true); trace.reopen.durable = false;
        add("fail_stop_deleted_without_durable_reopen_receipt", trace, ReceiptChainCode::accepted_unauthorized_deletion_fail_stop);
    }
    {
        auto trace = base_trace(true); trace.reopen.independently_reopenable = false;
        add("fail_stop_deleted_without_receipt_reopen", trace, ReceiptChainCode::accepted_unauthorized_deletion_fail_stop);
    }
    {
        auto trace = base_trace(true); trace.authorization.separately_governed = false;
        add("fail_stop_deleted_without_separate_authorization", trace, ReceiptChainCode::accepted_unauthorized_deletion_fail_stop);
    }
    {
        auto trace = base_trace(true); trace.authorization.independently_reopenable = false;
        add("fail_stop_deleted_without_authorization_reopen", trace, ReceiptChainCode::accepted_unauthorized_deletion_fail_stop);
    }
    {
        auto trace = base_trace(true); trace.deletion.present = false; trace.deletion = DeletionReceipt{};
        add("fail_stop_deleted_without_deletion_receipt", trace, ReceiptChainCode::accepted_deletion_receipt_gap_fail_stop);
    }
    {
        auto trace = base_trace(true); trace.deletion.durable = false;
        add("fail_stop_deletion_receipt_not_durable", trace, ReceiptChainCode::accepted_deletion_receipt_gap_fail_stop);
    }
    {
        auto trace = base_trace(true); trace.deletion.target_absence_observed = false;
        add("fail_stop_deletion_receipt_without_absence_observation", trace, ReceiptChainCode::accepted_deletion_receipt_gap_fail_stop);
    }

    // Equivocation and regression are fail-stop.
    {
        auto trace = base_trace(false); trace.equivocation_observed = true;
        add("fail_stop_equivocation_before_deletion", trace, ReceiptChainCode::accepted_equivocation_fail_stop);
    }
    {
        auto trace = base_trace(true); trace.equivocation_observed = true;
        add("fail_stop_equivocation_after_deletion", trace, ReceiptChainCode::accepted_equivocation_fail_stop);
    }
    {
        auto trace = base_trace(false); trace.cuts[5].reopen_receipt_reopened = false;
        add("fail_stop_regression_receipt_reopen_disappears", trace, ReceiptChainCode::accepted_regression_fail_stop);
    }
    {
        auto trace = base_trace(false); trace.cuts[7].authorization_visible = false;
        add("fail_stop_regression_authorization_disappears", trace, ReceiptChainCode::accepted_regression_fail_stop);
    }
    {
        auto trace = base_trace(true); trace.cuts[8].live_record_visible = true; trace.cuts[8].record_deleted = false;
        add("fail_stop_regression_live_record_resurrection", trace, ReceiptChainCode::accepted_regression_fail_stop);
    }
    {
        auto trace = base_trace(false); trace.cuts[4].replacement_visible = false;
        add("fail_stop_regression_replacement_disappears", trace, ReceiptChainCode::accepted_regression_fail_stop);
    }

    // Structural and binding rejections. Each mutation targets one rejection branch.
    {
        auto trace = base_trace(false); trace.predecessor.parent.state.request_id = Digest{};
        add("reject_exact_predecessor", trace, ReceiptChainCode::exact_predecessor_rejected);
    }
    {
        auto trace = base_trace(false);
        trace.predecessor = exact_trace(trace.predecessor.parent.state.terminal_kind, true);
        add("reject_already_deleted_exact_predecessor", trace, ReceiptChainCode::exact_predecessor_not_ready);
    }
    {
        auto trace = base_trace(false);
        const auto replacement = digest(0x62U);
        trace.predecessor.receipts[2].record_digest = replacement;
        trace.predecessor.receipts[3].predecessor_a = replacement;
        add("reject_exact_join_receipt_composition_mismatch", trace,
            ReceiptChainCode::exact_join_receipt_digest_mismatch);
    }
    {
        auto trace = base_trace(false);
        const auto replacement = digest(0x82U);
        trace.predecessor.receipts[3].record_digest = replacement;
        trace.predecessor.receipts[4].predecessor_a = replacement;
        add("reject_exact_reopen_receipt_composition_mismatch", trace,
            ReceiptChainCode::exact_reopen_receipt_digest_mismatch);
    }
    {
        auto trace = base_trace(false);
        const auto replacement = digest(0xA2U);
        trace.predecessor.receipts[4].record_digest = replacement;
        trace.predecessor.deletion_consumed_authorization_digest = replacement;
        add("reject_exact_authorization_receipt_composition_mismatch", trace,
            ReceiptChainCode::exact_authorization_receipt_digest_mismatch);
    }
    {
        auto trace = base_trace(false); trace.join_digest = Digest{};
        add("reject_join_digest_zero", trace, ReceiptChainCode::join_digest_zero);
    }
    {
        auto trace = base_trace(false); trace.target_digest = Digest{};
        add("reject_target_digest_zero", trace, ReceiptChainCode::target_digest_zero);
    }
    {
        auto trace = base_trace(false); trace.owner_policy_digest = Digest{};
        add("reject_owner_policy_zero", trace, ReceiptChainCode::owner_policy_digest_zero);
    }
    {
        auto trace = base_trace(false); trace.retention_policy_digest = Digest{};
        add("reject_retention_policy_zero", trace, ReceiptChainCode::retention_policy_digest_zero);
    }
    {
        auto trace = base_trace(false); trace.reclamation_requested = false;
        add("reject_reclamation_request_mismatch", trace, ReceiptChainCode::reclamation_request_mismatch);
    }
    {
        auto trace = base_trace(false); trace.source.present = false;
        add("reject_source_shape", trace, ReceiptChainCode::source_shape_invalid);
    }
    {
        auto trace = base_trace(false); trace.source.cutover_id = digest(0xF1U);
        add("reject_source_cutover_mismatch", trace, ReceiptChainCode::source_cutover_id_mismatch);
    }
    {
        auto trace = base_trace(false); trace.source.join_digest = digest(0xF2U);
        add("reject_source_join_mismatch", trace, ReceiptChainCode::source_join_digest_mismatch);
    }
    {
        auto trace = base_trace(false); trace.source.witness_digest = digest(0xF3U);
        add("reject_source_witness_mismatch", trace, ReceiptChainCode::source_witness_digest_mismatch);
    }
    {
        auto trace = base_trace(false); trace.source.floor_digest = digest(0xF4U);
        add("reject_source_floor_mismatch", trace, ReceiptChainCode::source_floor_digest_mismatch);
    }
    {
        auto trace = base_trace(false); trace.source.request_id = digest(0xF5U);
        add("reject_source_request_mismatch", trace, ReceiptChainCode::source_request_id_mismatch);
    }
    {
        auto trace = base_trace(false); trace.source.transition_digest = digest(0xF6U);
        add("reject_source_transition_mismatch", trace, ReceiptChainCode::source_transition_digest_mismatch);
    }
    {
        auto trace = base_trace(false); trace.source.register_incarnation = digest(0xF7U);
        add("reject_source_incarnation_mismatch", trace, ReceiptChainCode::source_register_incarnation_mismatch);
    }
    {
        auto trace = base_trace(false); trace.source.terminal_digest = digest(0xF8U);
        add("reject_source_terminal_mismatch", trace, ReceiptChainCode::source_terminal_digest_mismatch);
    }
    {
        auto trace = base_trace(false); trace.source.terminal_kind = TerminalKind::no_effect;
        add("reject_source_terminal_kind_mismatch", trace, ReceiptChainCode::source_terminal_kind_mismatch);
    }
    {
        auto trace = base_trace(false); trace.reopen.present = false;
        add("reject_reopen_shape", trace, ReceiptChainCode::reopen_shape_invalid);
    }
    {
        auto trace = base_trace(false); trace.reopen.closure_digest = digest(0xE1U);
        add("reject_reopen_closure_mismatch", trace, ReceiptChainCode::reopen_closure_digest_mismatch);
    }
    {
        auto trace = base_trace(false); trace.reopen.cutover_id = digest(0xE2U);
        add("reject_reopen_cutover_mismatch", trace, ReceiptChainCode::reopen_cutover_id_mismatch);
    }
    {
        auto trace = base_trace(false); trace.reopen.join_digest = digest(0xE3U);
        add("reject_reopen_join_mismatch", trace, ReceiptChainCode::reopen_join_digest_mismatch);
    }
    {
        auto trace = base_trace(false); trace.reopen.witness_digest = digest(0xE4U);
        add("reject_reopen_witness_mismatch", trace, ReceiptChainCode::reopen_witness_digest_mismatch);
    }
    {
        auto trace = base_trace(false); trace.reopen.floor_digest = digest(0xE5U);
        add("reject_reopen_floor_mismatch", trace, ReceiptChainCode::reopen_floor_digest_mismatch);
    }
    {
        auto trace = base_trace(false); trace.reopen.request_id = digest(0xE6U);
        add("reject_reopen_request_mismatch", trace, ReceiptChainCode::reopen_request_id_mismatch);
    }
    {
        auto trace = base_trace(false); trace.reopen.transition_digest = digest(0xE7U);
        add("reject_reopen_transition_mismatch", trace, ReceiptChainCode::reopen_transition_digest_mismatch);
    }
    {
        auto trace = base_trace(false); trace.reopen.register_incarnation = digest(0xE8U);
        add("reject_reopen_incarnation_mismatch", trace, ReceiptChainCode::reopen_register_incarnation_mismatch);
    }
    {
        auto trace = base_trace(false); trace.reopen.terminal_digest = digest(0xE9U);
        add("reject_reopen_terminal_mismatch", trace, ReceiptChainCode::reopen_terminal_digest_mismatch);
    }
    {
        auto trace = base_trace(false); trace.reopen.terminal_kind = TerminalKind::no_effect;
        add("reject_reopen_terminal_kind_mismatch", trace, ReceiptChainCode::reopen_terminal_kind_mismatch);
    }
    {
        auto trace = base_trace(false); trace.reopen.reopener_incarnation = digest(0xEAU);
        add("reject_reopen_reopener_mismatch", trace, ReceiptChainCode::reopen_reopener_incarnation_mismatch);
    }
    {
        auto trace = base_trace(false); trace.reopen.verifier_id = digest(0xEBU);
        add("reject_reopen_verifier_mismatch", trace, ReceiptChainCode::reopen_verifier_id_mismatch);
    }
    {
        auto trace = base_trace(false); trace.reopen.verifier_policy_digest = digest(0xECU);
        add("reject_reopen_policy_mismatch", trace, ReceiptChainCode::reopen_policy_digest_mismatch);
    }
    {
        auto trace = base_trace(false); trace.authorization.present = false;
        add("reject_authorization_shape", trace, ReceiptChainCode::authorization_shape_invalid);
    }
    {
        auto trace = base_trace(false); trace.authorization.reopen_receipt_digest = digest(0xD2U);
        add("reject_authorization_receipt_mismatch", trace, ReceiptChainCode::authorization_receipt_digest_mismatch);
    }
    {
        auto trace = base_trace(false); trace.authorization.cutover_id = digest(0xD3U);
        add("reject_authorization_cutover_mismatch", trace, ReceiptChainCode::authorization_cutover_id_mismatch);
    }
    {
        auto trace = base_trace(false); trace.authorization.target_digest = digest(0xD4U);
        add("reject_authorization_target_mismatch", trace, ReceiptChainCode::authorization_target_digest_mismatch);
    }
    {
        auto trace = base_trace(false); trace.authorization.owner_policy_digest = digest(0xD5U);
        add("reject_authorization_owner_policy_mismatch", trace, ReceiptChainCode::authorization_owner_policy_mismatch);
    }
    {
        auto trace = base_trace(false); trace.authorization.retention_policy_digest = digest(0xD6U);
        add("reject_authorization_retention_policy_mismatch", trace, ReceiptChainCode::authorization_retention_policy_mismatch);
    }
    {
        auto trace = base_trace(false); trace.deletion.present = false;
        add("reject_deletion_shape", trace, ReceiptChainCode::deletion_shape_invalid);
    }
    {
        auto trace = base_trace(false); trace.deletion.authorization_digest = digest(0xC1U);
        add("reject_deletion_authorization_mismatch", trace, ReceiptChainCode::deletion_authorization_digest_mismatch);
    }
    {
        auto trace = base_trace(false); trace.deletion.cutover_id = digest(0xC2U);
        add("reject_deletion_cutover_mismatch", trace, ReceiptChainCode::deletion_cutover_id_mismatch);
    }
    {
        auto trace = base_trace(false); trace.deletion.target_digest = digest(0xC3U);
        add("reject_deletion_target_mismatch", trace, ReceiptChainCode::deletion_target_digest_mismatch);
    }
    {
        auto trace = base_trace(false); trace.cuts[0].live_record_visible = false;
        add("reject_trace_initial", trace, ReceiptChainCode::trace_initial_state_invalid);
    }
    {
        auto trace = base_trace(false); trace.cuts[3].record_deleted = true;
        add("reject_trace_deleted_and_live", trace, ReceiptChainCode::trace_deleted_and_live);
    }
    {
        auto trace = base_trace(false); trace.cuts[3].live_record_visible = false;
        add("reject_trace_live_absent_without_delete", trace, ReceiptChainCode::trace_live_absent_without_deletion);
    }

    return values;
}

[[nodiscard]] std::string truth(const bool value) { return value ? "true" : "false"; }

[[nodiscard]] bool write_text(const std::filesystem::path& path, const std::string& text) {
    std::ofstream stream(path, std::ios::binary | std::ios::trunc);
    stream << text;
    return stream.good();
}

[[nodiscard]] bool accepted_code(const ReceiptChainCode code) noexcept {
    return static_cast<std::uint8_t>(code)
        <= static_cast<std::uint8_t>(ReceiptChainCode::accepted_regression_fail_stop);
}

}  // namespace

bool run_campaign(const std::filesystem::path& output_directory) {
    std::error_code error;
    std::filesystem::create_directories(output_directory, error);
    if (error) return false;

    const auto corpus = cases();
    std::string cases_tsv = "case\texpected\tcandidate\treference\tagreement\taccepted\texact_predecessor_safe\texact_predecessor_ready\tsource_valid\treopen_core\treopen_reopened\tauthorization_core\tauthorization_reopened\tdeletion_receipt_valid\tordered\tready\tcomplete\tunauthorized_deletion\tfail_stop\teventual_repair_sufficient\texternal_occurrence\tcurrentness\tcustody\tauthority\n";
    std::string cuts_tsv = "case\tcut\tname\tlive_record\treplacement\treopener_started\treconstruction_computed\treopen_receipt\treopen_receipt_reopened\tauthorization\tauthorization_reopened\trecord_deleted\tdeletion_receipt\n";
    std::map<std::string, std::size_t> counts;
    std::size_t disagreements = 0U;
    std::size_t accepted_count = 0U;

    for (const auto& item : corpus) {
        const auto candidate = evaluate_candidate(item.trace);
        const auto reference = evaluate_reference(item.trace);
        const bool agreement = candidate == reference;
        if (!agreement) ++disagreements;
        if (candidate.code != item.expected || candidate.accepted != accepted_code(item.expected)) {
            std::cerr << "CASE_MISMATCH name=" << item.name
                      << " expected=" << receipt_chain_code_name(item.expected)
                      << " candidate=" << receipt_chain_code_name(candidate.code)
                      << " reference=" << receipt_chain_code_name(reference.code)
                      << " accepted=" << truth(candidate.accepted)
                      << " expected_accepted=" << truth(accepted_code(item.expected)) << '\n';
            return false;
        }
        if (candidate.accepted) ++accepted_count;
        ++counts[std::string(receipt_chain_code_name(candidate.code))];
        cases_tsv += item.name + "\t" + std::string(receipt_chain_code_name(item.expected)) + "\t"
            + std::string(receipt_chain_code_name(candidate.code)) + "\t"
            + std::string(receipt_chain_code_name(reference.code)) + "\t" + truth(agreement)
            + "\t" + truth(candidate.accepted) + "\t" + truth(candidate.exact_predecessor_deletion_safe)
            + "\t" + truth(candidate.exact_predecessor_ready) + "\t" + truth(candidate.source_closure_valid)
            + "\t" + truth(candidate.reopen_receipt_core_valid) + "\t" + truth(candidate.reopen_receipt_reopen_valid)
            + "\t" + truth(candidate.authorization_core_valid) + "\t" + truth(candidate.authorization_reopen_valid)
            + "\t" + truth(candidate.deletion_receipt_valid) + "\t" + truth(candidate.all_cuts_ordered)
            + "\t" + truth(candidate.reclamation_ready) + "\t" + truth(candidate.reclamation_complete)
            + "\t" + truth(candidate.unauthorized_deletion) + "\t" + truth(candidate.fail_stopped)
            + "\t" + truth(candidate.eventual_repair_sufficient) + "\t" + truth(candidate.external_occurrence_proved)
            + "\t" + truth(candidate.currentness_proved) + "\t" + truth(candidate.independent_custody_proved)
            + "\t" + truth(candidate.authority_granted) + "\n";
        for (std::size_t index = 0U; index < item.trace.cuts.size(); ++index) {
            const auto& cut = item.trace.cuts[index];
            cuts_tsv += item.name + "\t" + std::to_string(index) + "\t" + std::string(receipt_cut_name(index))
                + "\t" + truth(cut.live_record_visible) + "\t" + truth(cut.replacement_visible)
                + "\t" + truth(cut.reopener_started) + "\t" + truth(cut.reconstruction_computed)
                + "\t" + truth(cut.reopen_receipt_visible) + "\t" + truth(cut.reopen_receipt_reopened)
                + "\t" + truth(cut.authorization_visible) + "\t" + truth(cut.authorization_reopened)
                + "\t" + truth(cut.record_deleted) + "\t" + truth(cut.deletion_receipt_visible) + "\n";
        }
    }

    const auto count = [&counts](const std::string_view name) -> std::size_t {
        const auto found = counts.find(std::string(name));
        return found == counts.end() ? 0U : found->second;
    };
    const std::size_t fail_stopped = count("accepted_unauthorized_deletion_fail_stop")
        + count("accepted_deletion_receipt_gap_fail_stop") + count("accepted_equivocation_fail_stop")
        + count("accepted_regression_fail_stop");
    const std::size_t refused = count("accepted_reclamation_refused_source_closure_gap")
        + count("accepted_reclamation_refused_publication_gap")
        + count("accepted_reclamation_refused_receipt_reopen_gap")
        + count("accepted_reclamation_refused_authorization_gap")
        + count("accepted_reclamation_refused_authorization_reopen_gap")
        + count("accepted_reclamation_refused_order_gap");

    const std::string summary = "{\n"
        "  \"accepted_cases\": " + std::to_string(accepted_count) + ",\n"
        "  \"authority_granted\": false,\n"
        "  \"candidate_reference_disagreements\": " + std::to_string(disagreements) + ",\n"
        "  \"cases\": " + std::to_string(corpus.size()) + ",\n"
        "  \"already_deleted_predecessor_rejections\": "
            + std::to_string(count("exact_predecessor_not_ready")) + ",\n"
        "  \"exact_predecessor_composition_rejections\": "
            + std::to_string(count("exact_join_receipt_digest_mismatch")
                + count("exact_reopen_receipt_digest_mismatch")
                + count("exact_authorization_receipt_digest_mismatch")) + ",\n"
        "  \"chain_complete_cases\": " + std::to_string(count("accepted_chain_complete")) + ",\n"
        "  \"chain_ready_live_retained_cases\": " + std::to_string(count("accepted_chain_ready_live_retained")) + ",\n"
        "  \"crash_cuts\": " + std::to_string(corpus.size() * receipt_cut_count) + ",\n"
        "  \"deletion_receipt_gap_fail_stop_cases\": " + std::to_string(count("accepted_deletion_receipt_gap_fail_stop")) + ",\n"
        "  \"epoch_exit_proved\": false,\n"
        "  \"eventual_repair_sufficient_cases\": 0,\n"
        "  \"external_occurrence_proved\": false,\n"
        "  \"external_reclamation_operated\": false,\n"
        "  \"fail_stopped_cases\": " + std::to_string(fail_stopped) + ",\n"
        "  \"fourth_semantic_island\": false,\n"
        "  \"independent_custody_proved\": false,\n"
        "  \"live_basis_retained_cases\": " + std::to_string(count("accepted_live_basis_retained")) + ",\n"
        "  \"phase_order_refused_cases\": " + std::to_string(count("accepted_reclamation_refused_order_gap")) + ",\n"
        "  \"reclamation_refused_cases\": " + std::to_string(refused) + ",\n"
        "  \"reclamation_safe_cases\": " + std::to_string(count("accepted_chain_complete")) + ",\n"
        "  \"rejected_cases\": " + std::to_string(corpus.size() - accepted_count) + ",\n"
        "  \"schema\": \"slopos.rev0919.reopen-receipt-chain-campaign.v1\",\n"
        "  \"source_closure_refused_cases\": " + std::to_string(count("accepted_reclamation_refused_source_closure_gap")) + ",\n"
        "  \"status\": \"PASS\",\n"
        "  \"total_composition_rejections\": "
            + std::to_string(count("exact_predecessor_not_ready")
                + count("exact_join_receipt_digest_mismatch")
                + count("exact_reopen_receipt_digest_mismatch")
                + count("exact_authorization_receipt_digest_mismatch")) + ",\n"
        "  \"unauthorized_deletion_fail_stop_cases\": " + std::to_string(count("accepted_unauthorized_deletion_fail_stop")) + "\n"
        "}\n";

    const std::string phases =
        "phase\tdurable_predecessor\tdestructive\thosted_claim\n"
        "R0_live_joined\texact-predecessor chain ready while live bridge remains\tfalse\tstarting premise only\n"
        "R1_reopener_start\texact replacement-only source closure\tfalse\tstart is not success\n"
        "R2_reconstruction\treopener start at earlier cut\tfalse\tcomputation is not publication\n"
        "R3_receipt_publish\treconstruction at earlier cut\tfalse\tno-replace durable publication\n"
        "R4_receipt_reopen\treceipt publication at earlier cut\tfalse\tindependent receipt consumption\n"
        "R5_authorization_publish\treceipt reopen at earlier cut\tfalse\tseparately governed exact-target authorization\n"
        "R6_authorization_reopen\tauthorization publication at earlier cut\tfalse\tindependent authorization consumption\n"
        "R7_delete\tauthorization reopen at earlier cut\ttrue\texact target only\n"
        "R8_deletion_receipt\tdeletion at earlier cut\tfalse\tpost-delete exact-target evidence only\n";
    const std::string countertraces =
        "case\tlaw\tjudgment\n"
        "refused_source_live_record_contamination\treplacement-only source closure\tREFUSE\n"
        "refused_publication_directory_not_durable\tfile bytes do not prove durable namespace entry\tREFUSE\n"
        "refused_receipt_never_reopened\tpublication is not independent reopen\tREFUSE\n"
        "refused_authorization_same_administration\treopen and destruction authority remain separated\tREFUSE\n"
        "refused_order_authorize_same_cut_as_receipt_reopen\tsame-cut truth is not predecessor consumption\tREFUSE\n"
        "fail_stop_deleted_without_durable_reopen_receipt\tdeletion without portable receipt cannot be repaired retroactively\tFAIL_STOP\n"
        "fail_stop_deletion_receipt_without_absence_observation\tdeletion receipt binds observed exact-target absence\tFAIL_STOP\n"
        "fail_stop_regression_live_record_resurrection\tterminal publication is monotone\tFAIL_STOP\n"
        "reject_already_deleted_exact_predecessor\ta completed parent cannot be resurrected as a live child prefix\tREJECT\n";
    const std::string invariants =
        "REOPEN_RECEIPT_CHAIN_V1\n"
        "exact_predecessor_trace_composed=true\n"
        "exact_predecessor_must_be_ready_live=true\n"
        "completed_exact_predecessor_rejected=true\n"
        "source_closure_excludes_live_terminal_record=true\n"
        "source_closure_binds_join_witness_floor_request_transition_incarnation_terminal=true\n"
        "successful_reconstruction_is_publication=false\n"
        "receipt_publication_is_independent_reopen=false\n"
        "authorization_binds_exact_receipt_policy_and_target=true\n"
        "strict_predecessor_order=true\n"
        "same_cut_phase_collapse=false\n"
        "deletion_without_chain=FAIL_STOP\n"
        "eventual_repair_sufficient=false\n"
        "external_occurrence_proved=false\n"
        "currentness_proved=false\n"
        "independent_custody_proved=false\n"
        "epoch_exit_proved=false\n"
        "authority_granted=false\n";

    return disagreements == 0U
        && write_text(output_directory / "CASES.tsv", cases_tsv)
        && write_text(output_directory / "CUTS.tsv", cuts_tsv)
        && write_text(output_directory / "SUMMARY.json", summary)
        && write_text(output_directory / "PHASES.tsv", phases)
        && write_text(output_directory / "COUNTERTRACES.tsv", countertraces)
        && write_text(output_directory / "INVARIANTS.txt", invariants);
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain
