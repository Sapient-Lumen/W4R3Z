#pragma once

#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/reopen_receipt_chain.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <string_view>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission {

inline constexpr std::size_t admission_cut_count = 10U;
inline constexpr std::uint64_t required_profile_mask = (std::uint64_t{1} << 18U) - 1U;
inline constexpr std::uint64_t required_corpus_mask = (std::uint64_t{1} << 18U) - 1U;

enum class OwnerDecision : std::uint8_t {
    none,
    admit,
    reject,
};

enum class AdmissionCode : std::uint8_t {
    accepted_external_premises_ready_live_retained,
    accepted_profile_closed_unratified,
    accepted_ratified_not_operated,
    accepted_operated_not_appraised,
    accepted_appraised_not_owner_admitted,
    accepted_owner_rejected_live_retained,
    accepted_refused_constitution_gap,
    accepted_refused_profile_gap,
    accepted_refused_ratification_gap,
    accepted_refused_separation_gap,
    accepted_refused_transparency_gap,
    accepted_refused_corpus_gap,
    accepted_refused_appraisal_gap,
    accepted_refused_owner_admission_gap,
    accepted_refused_order_gap,
    accepted_unauthorized_deletion_fail_stop,
    accepted_equivocation_fail_stop,
    accepted_regression_fail_stop,
    receipt_chain_rejected,
    receipt_chain_not_ready,
    receipt_chain_already_deleted,
    parent_authorization_digest_mismatch,
    parent_target_digest_mismatch,
    constitution_shape_invalid,
    constitution_project_mismatch,
    profile_shape_invalid,
    profile_project_mismatch,
    profile_constitution_mismatch,
    profile_owner_root_mismatch,
    profile_parent_authorization_mismatch,
    profile_target_mismatch,
    ratification_shape_invalid,
    ratification_profile_mismatch,
    ratification_constitution_mismatch,
    ratification_owner_root_mismatch,
    separation_shape_invalid,
    separation_profile_mismatch,
    corpus_shape_invalid,
    corpus_profile_mismatch,
    corpus_implementation_mismatch,
    corpus_configuration_mismatch,
    appraisal_shape_invalid,
    appraisal_profile_mismatch,
    appraisal_corpus_mismatch,
    appraisal_separation_mismatch,
    owner_admission_shape_invalid,
    owner_admission_ratification_mismatch,
    owner_admission_appraisal_mismatch,
    owner_admission_parent_authorization_mismatch,
    owner_admission_target_mismatch,
    trace_initial_state_invalid,
    trace_deleted_and_live,
    trace_live_absent_without_deletion,
};

struct OwnerConstitution final {
    Digest constitution_digest{};
    Digest project_id{};
    Digest owner_root_digest{};
    Digest constitution_policy_digest{};
    Digest bootstrap_method_digest{};
    bool present{false};
    bool canonical{false};
    bool authenticated{false};
    bool threshold_satisfied{false};
    bool out_of_band_bootstrapped{false};
    bool current_root_selected{false};
    bool rollback_external{false};
    bool durable{false};
    bool single_view{false};
    bool independently_reopenable{false};
    bool self_nominated{false};

    [[nodiscard]] friend constexpr bool operator==(const OwnerConstitution&, const OwnerConstitution&) noexcept = default;
};

struct MechanismAnnex final {
    Digest annex_digest{};
    Digest project_id{};
    Digest owner_constitution_digest{};
    Digest owner_root_digest{};
    Digest parent_authorization_digest{};
    Digest target_digest{};
    Digest profile_id{};
    Digest role_matrix_digest{};
    Digest failure_corpus_spec_digest{};
    Digest implementation_digest{};
    Digest configuration_digest{};
    std::uint64_t requirement_mask{0U};
    bool present{false};
    bool canonical{false};
    bool complete{false};
    bool no_hidden_inputs{false};
    bool exact_mechanism_selected{false};
    bool bootstrap_method_declared{false};
    bool collision_fail_closed{false};
    bool non_equivocation_witness_required{false};
    bool self_ratifying{false};

    [[nodiscard]] friend constexpr bool operator==(const MechanismAnnex&, const MechanismAnnex&) noexcept = default;
};

struct RatificationReceipt final {
    Digest ratification_digest{};
    Digest annex_digest{};
    Digest owner_constitution_digest{};
    Digest owner_root_digest{};
    Digest ratification_policy_digest{};
    bool present{false};
    bool authenticated{false};
    bool threshold_satisfied{false};
    bool owner_issued{false};
    bool durable{false};
    bool no_replace_published{false};
    bool single_view{false};
    bool independently_reopenable{false};
    bool current_root_observed{false};
    bool self_issued_by_annex{false};

    [[nodiscard]] friend constexpr bool operator==(const RatificationReceipt&, const RatificationReceipt&) noexcept = default;
};

struct RoleSeparation final {
    Digest separation_digest{};
    Digest annex_digest{};
    Digest reopener_admin_digest{};
    Digest authorizer_admin_digest{};
    Digest appraiser_admin_digest{};
    Digest mechanism_admin_digest{};
    Digest reopener_rollback_digest{};
    Digest authorizer_rollback_digest{};
    Digest appraiser_rollback_digest{};
    Digest mechanism_rollback_digest{};
    bool present{false};
    bool owner_ratified{false};
    bool distinct_administrative_roots{false};
    bool distinct_rollback_roots{false};
    bool distinct_credentials{false};
    bool recovery_roots_separate{false};
    bool appraiser_can_reopen_without_operator{false};
    bool collusion_model_declared{false};
    bool same_process_only{false};

    [[nodiscard]] friend constexpr bool operator==(const RoleSeparation&, const RoleSeparation&) noexcept = default;
};

struct OperatedCorpus final {
    Digest corpus_digest{};
    Digest annex_digest{};
    Digest failure_corpus_spec_digest{};
    Digest implementation_digest{};
    Digest configuration_digest{};
    Digest disposable_target_digest{};
    std::uint64_t observed_scenario_mask{0U};
    bool present{false};
    bool canonical{false};
    bool complete{false};
    bool actual_not_synthetic{false};
    bool exact_binaries{false};
    bool exact_configuration{false};
    bool raw_traces_retained{false};
    bool independently_locatable{false};
    bool replayable{false};
    bool expected_outcomes_checked{false};
    bool disposable_target_separate{false};

    [[nodiscard]] friend constexpr bool operator==(const OperatedCorpus&, const OperatedCorpus&) noexcept = default;
};

struct AppraisalReceipt final {
    Digest appraisal_digest{};
    Digest annex_digest{};
    Digest corpus_digest{};
    Digest separation_digest{};
    Digest appraiser_admin_digest{};
    Digest appraisal_policy_digest{};
    bool present{false};
    bool authenticated{false};
    bool durable{false};
    bool no_replace_published{false};
    bool single_view{false};
    bool independently_reopenable{false};
    bool source_closed{false};
    bool independent_replay_performed{false};
    bool producer_not_appraiser{false};
    bool result_pass{false};

    [[nodiscard]] friend constexpr bool operator==(const AppraisalReceipt&, const AppraisalReceipt&) noexcept = default;
};

struct OwnerAdmission final {
    Digest admission_digest{};
    Digest ratification_digest{};
    Digest appraisal_digest{};
    Digest parent_authorization_digest{};
    Digest target_digest{};
    Digest owner_root_digest{};
    OwnerDecision decision{OwnerDecision::none};
    bool present{false};
    bool authenticated{false};
    bool threshold_satisfied{false};
    bool durable{false};
    bool no_replace_published{false};
    bool single_view{false};
    bool independently_reopenable{false};
    bool current_root_observed{false};
    bool separately_governed{false};
    bool exact_predecessors_consumed{false};
    bool self_issued_by_candidate{false};

    [[nodiscard]] friend constexpr bool operator==(const OwnerAdmission&, const OwnerAdmission&) noexcept = default;
};

struct AdmissionCut final {
    bool live_record_visible{false};
    bool owner_constitution_visible{false};
    bool annex_closed{false};
    bool ratification_visible{false};
    bool ratification_reopened{false};
    bool corpus_started{false};
    bool corpus_complete{false};
    bool appraisal_visible{false};
    bool appraisal_reopened{false};
    bool owner_admission_visible{false};
    bool owner_admission_reopened{false};
    bool record_deleted{false};

    [[nodiscard]] friend constexpr bool operator==(const AdmissionCut&, const AdmissionCut&) noexcept = default;
};

struct AdmissionTrace final {
    ReceiptChainTrace parent{};
    Digest project_id{};
    OwnerConstitution constitution{};
    MechanismAnnex annex{};
    RatificationReceipt ratification{};
    RoleSeparation separation{};
    OperatedCorpus corpus{};
    AppraisalReceipt appraisal{};
    OwnerAdmission admission{};
    std::array<AdmissionCut, admission_cut_count> cuts{};
    bool admission_requested{false};
    bool equivocation_observed{false};

    [[nodiscard]] friend constexpr bool operator==(const AdmissionTrace&, const AdmissionTrace&) noexcept = default;
};

struct AdmissionReport final {
    AdmissionCode code{AdmissionCode::receipt_chain_rejected};
    bool accepted{false};
    bool parent_accepted{false};
    bool parent_ready_live_retained{false};
    bool constitution_valid{false};
    bool profile_valid{false};
    bool ratification_core_valid{false};
    bool ratification_reopen_valid{false};
    bool separation_valid{false};
    bool transparency_valid{false};
    bool corpus_valid{false};
    bool appraisal_core_valid{false};
    bool appraisal_reopen_valid{false};
    bool owner_admission_core_valid{false};
    bool owner_admission_reopen_valid{false};
    bool all_cuts_ordered{false};
    bool constitution_gap_observed{false};
    bool profile_gap_observed{false};
    bool ratification_gap_observed{false};
    bool separation_gap_observed{false};
    bool transparency_gap_observed{false};
    bool corpus_gap_observed{false};
    bool appraisal_gap_observed{false};
    bool owner_admission_gap_observed{false};
    bool phase_order_gap_observed{false};
    bool regression_observed{false};
    bool self_ratification_detected{false};
    bool common_control_detected{false};
    bool synthetic_corpus_detected{false};
    bool owner_rejected{false};
    bool external_premise_dossier_ready{false};
    bool live_record_must_be_retained{true};
    bool unauthorized_deletion{false};
    bool fail_stopped{false};
    bool external_occurrence_proved{false};
    bool owner_constitution_proved{false};
    bool currentness_proved{false};
    bool independent_custody_proved{false};
    bool mechanism_operated_proved{false};
    bool epoch_exit_proved{false};
    bool authority_granted{false};

    [[nodiscard]] friend constexpr bool operator==(const AdmissionReport&, const AdmissionReport&) noexcept = default;
};

[[nodiscard]] AdmissionReport evaluate_candidate(const AdmissionTrace& trace) noexcept;
[[nodiscard]] AdmissionReport evaluate_reference(const AdmissionTrace& trace) noexcept;
[[nodiscard]] std::string_view admission_code_name(AdmissionCode value) noexcept;
[[nodiscard]] std::string_view admission_cut_name(std::size_t index) noexcept;
[[nodiscard]] bool run_campaign(const std::filesystem::path& output_directory);

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission
