#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/reopen_receipt_chain/external_premise_admission.hpp"

#include <algorithm>
#include <array>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission {
namespace {

namespace parent = ::slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain;
namespace exact = ::slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::exact_predecessor_consumption;

[[nodiscard]] bool nonzero(const Digest& value) noexcept {
    return std::any_of(value.cbegin(), value.cend(), [](const std::uint8_t byte) { return byte != 0U; });
}

[[nodiscard]] bool constitution_shape_valid(const OwnerConstitution& value) noexcept {
    const bool dependent = nonzero(value.constitution_digest) || nonzero(value.project_id)
        || nonzero(value.owner_root_digest) || nonzero(value.constitution_policy_digest)
        || nonzero(value.bootstrap_method_digest) || value.canonical || value.authenticated
        || value.threshold_satisfied || value.out_of_band_bootstrapped || value.current_root_selected
        || value.rollback_external || value.durable || value.single_view
        || value.independently_reopenable || value.self_nominated;
    return value.present || !dependent;
}

[[nodiscard]] bool profile_shape_valid(const MechanismAnnex& value) noexcept {
    const bool dependent = nonzero(value.annex_digest) || nonzero(value.project_id)
        || nonzero(value.owner_constitution_digest) || nonzero(value.owner_root_digest)
        || nonzero(value.parent_authorization_digest) || nonzero(value.target_digest)
        || nonzero(value.profile_id) || nonzero(value.role_matrix_digest)
        || nonzero(value.failure_corpus_spec_digest) || nonzero(value.implementation_digest)
        || nonzero(value.configuration_digest) || value.requirement_mask != 0U || value.canonical
        || value.complete || value.no_hidden_inputs || value.exact_mechanism_selected
        || value.bootstrap_method_declared || value.collision_fail_closed
        || value.non_equivocation_witness_required || value.self_ratifying;
    return value.present || !dependent;
}

[[nodiscard]] bool ratification_shape_valid(const RatificationReceipt& value) noexcept {
    const bool dependent = nonzero(value.ratification_digest) || nonzero(value.annex_digest)
        || nonzero(value.owner_constitution_digest) || nonzero(value.owner_root_digest)
        || nonzero(value.ratification_policy_digest) || value.authenticated
        || value.threshold_satisfied || value.owner_issued || value.durable
        || value.no_replace_published || value.single_view || value.independently_reopenable
        || value.current_root_observed || value.self_issued_by_annex;
    return value.present || !dependent;
}

[[nodiscard]] bool separation_shape_valid(const RoleSeparation& value) noexcept {
    const bool dependent = nonzero(value.separation_digest) || nonzero(value.annex_digest)
        || nonzero(value.reopener_admin_digest) || nonzero(value.authorizer_admin_digest)
        || nonzero(value.appraiser_admin_digest) || nonzero(value.mechanism_admin_digest)
        || nonzero(value.reopener_rollback_digest) || nonzero(value.authorizer_rollback_digest)
        || nonzero(value.appraiser_rollback_digest) || nonzero(value.mechanism_rollback_digest)
        || value.owner_ratified || value.distinct_administrative_roots
        || value.distinct_rollback_roots || value.distinct_credentials
        || value.recovery_roots_separate || value.appraiser_can_reopen_without_operator
        || value.collusion_model_declared || value.same_process_only;
    return value.present || !dependent;
}

[[nodiscard]] bool corpus_shape_valid(const OperatedCorpus& value) noexcept {
    const bool dependent = nonzero(value.corpus_digest) || nonzero(value.annex_digest)
        || nonzero(value.failure_corpus_spec_digest) || nonzero(value.implementation_digest)
        || nonzero(value.configuration_digest) || nonzero(value.disposable_target_digest)
        || value.observed_scenario_mask != 0U || value.canonical || value.complete
        || value.actual_not_synthetic || value.exact_binaries || value.exact_configuration
        || value.raw_traces_retained || value.independently_locatable || value.replayable
        || value.expected_outcomes_checked || value.disposable_target_separate;
    return value.present || !dependent;
}

[[nodiscard]] bool appraisal_shape_valid(const AppraisalReceipt& value) noexcept {
    const bool dependent = nonzero(value.appraisal_digest) || nonzero(value.annex_digest)
        || nonzero(value.corpus_digest) || nonzero(value.separation_digest)
        || nonzero(value.appraiser_admin_digest) || nonzero(value.appraisal_policy_digest)
        || value.authenticated || value.durable || value.no_replace_published
        || value.single_view || value.independently_reopenable || value.source_closed
        || value.independent_replay_performed || value.producer_not_appraiser || value.result_pass;
    return value.present || !dependent;
}

[[nodiscard]] bool owner_admission_shape_valid(const OwnerAdmission& value) noexcept {
    const bool dependent = nonzero(value.admission_digest) || nonzero(value.ratification_digest)
        || nonzero(value.appraisal_digest) || nonzero(value.parent_authorization_digest)
        || nonzero(value.target_digest) || nonzero(value.owner_root_digest)
        || value.decision != OwnerDecision::none || value.authenticated || value.threshold_satisfied
        || value.durable || value.no_replace_published || value.single_view
        || value.independently_reopenable || value.current_root_observed
        || value.separately_governed || value.exact_predecessors_consumed
        || value.self_issued_by_candidate;
    return value.present || !dependent;
}

[[nodiscard]] bool all_distinct(const std::array<Digest, 4U>& values) noexcept {
    for (std::size_t left = 0U; left < values.size(); ++left) {
        if (!nonzero(values[left])) return false;
        for (std::size_t right = left + 1U; right < values.size(); ++right) {
            if (values[left] == values[right]) return false;
        }
    }
    return true;
}

[[nodiscard]] std::array<bool, 11U> phases(const AdmissionCut& cut) noexcept {
    return {
        cut.owner_constitution_visible,
        cut.annex_closed,
        cut.ratification_visible,
        cut.ratification_reopened,
        cut.corpus_started,
        cut.corpus_complete,
        cut.appraisal_visible,
        cut.appraisal_reopened,
        cut.owner_admission_visible,
        cut.owner_admission_reopened,
        cut.record_deleted,
    };
}

struct CutFacts final {
    bool ordered{true};
    bool phase_gap{false};
    bool regression{false};
    bool unauthorized_deletion{false};
};

[[nodiscard]] CutFacts analyze_cuts(const std::array<AdmissionCut, admission_cut_count>& cuts) noexcept {
    CutFacts facts{};
    auto prior = phases(cuts.front());
    for (std::size_t index = 0U; index < cuts.size(); ++index) {
        const auto current = phases(cuts[index]);
        facts.unauthorized_deletion = facts.unauthorized_deletion || cuts[index].record_deleted;
        for (std::size_t phase = 1U; phase < 10U; ++phase) {
            if (current[phase] && !current[phase - 1U]) facts.phase_gap = true;
        }
        if (index != 0U) {
            std::size_t newly_visible = 0U;
            for (std::size_t phase = 0U; phase < current.size(); ++phase) {
                if (prior[phase] && !current[phase]) facts.regression = true;
                if (phase < 10U && current[phase] && !prior[phase]) ++newly_visible;
            }
            if (newly_visible > 1U) facts.phase_gap = true;
        }
        prior = current;
    }
    facts.ordered = !facts.phase_gap && !facts.regression;
    return facts;
}

[[nodiscard]] AdmissionReport rejected(
    const AdmissionCode code,
    const bool parent_accepted = false,
    const bool parent_ready = false) noexcept {
    AdmissionReport report{};
    report.code = code;
    report.parent_accepted = parent_accepted;
    report.parent_ready_live_retained = parent_ready;
    return report;
}

[[nodiscard]] AdmissionReport accepted_report(
    const AdmissionCode code,
    const bool parent_accepted,
    const bool parent_ready,
    const bool constitution_valid,
    const bool profile_valid,
    const bool ratification_core_valid,
    const bool ratification_reopen_valid,
    const bool separation_valid,
    const bool transparency_valid,
    const bool corpus_valid,
    const bool appraisal_core_valid,
    const bool appraisal_reopen_valid,
    const bool owner_admission_core_valid,
    const bool owner_admission_reopen_valid,
    const CutFacts& cuts,
    const bool self_ratification,
    const bool common_control,
    const bool synthetic_corpus,
    const bool owner_rejected,
    const bool dossier_ready,
    const bool fail_stopped) noexcept {
    AdmissionReport report{};
    report.code = code;
    report.accepted = true;
    report.parent_accepted = parent_accepted;
    report.parent_ready_live_retained = parent_ready;
    report.constitution_valid = constitution_valid;
    report.profile_valid = profile_valid;
    report.ratification_core_valid = ratification_core_valid;
    report.ratification_reopen_valid = ratification_reopen_valid;
    report.separation_valid = separation_valid;
    report.transparency_valid = transparency_valid;
    report.corpus_valid = corpus_valid;
    report.appraisal_core_valid = appraisal_core_valid;
    report.appraisal_reopen_valid = appraisal_reopen_valid;
    report.owner_admission_core_valid = owner_admission_core_valid;
    report.owner_admission_reopen_valid = owner_admission_reopen_valid;
    report.all_cuts_ordered = cuts.ordered;
    report.constitution_gap_observed = !constitution_valid;
    report.profile_gap_observed = constitution_valid && !profile_valid;
    report.ratification_gap_observed = profile_valid && !ratification_reopen_valid;
    report.separation_gap_observed = ratification_reopen_valid && !separation_valid;
    report.transparency_gap_observed = separation_valid && !transparency_valid;
    report.corpus_gap_observed = transparency_valid && !corpus_valid;
    report.appraisal_gap_observed = corpus_valid && !appraisal_reopen_valid;
    report.owner_admission_gap_observed = appraisal_reopen_valid && !owner_admission_reopen_valid;
    report.phase_order_gap_observed = cuts.phase_gap;
    report.regression_observed = cuts.regression;
    report.self_ratification_detected = self_ratification;
    report.common_control_detected = common_control;
    report.synthetic_corpus_detected = synthetic_corpus;
    report.owner_rejected = owner_rejected;
    report.external_premise_dossier_ready = dossier_ready;
    report.live_record_must_be_retained = true;
    report.unauthorized_deletion = cuts.unauthorized_deletion;
    report.fail_stopped = fail_stopped;
    // Mandatory nonclaims remain false.  This hosted relation proves only that
    // a closed premise dossier is internally admissible, never that any event
    // occurred outside this datacube or that authority exists.
    return report;
}

}  // namespace

AdmissionReport evaluate_candidate(const AdmissionTrace& trace) noexcept {
    const auto expected_parent_authorization = trace.parent.predecessor.receipts[
        static_cast<std::size_t>(exact::Phase::deletion_authorization)].record_digest;
    if (trace.parent.authorization.present
        && trace.parent.authorization.authorization_digest != expected_parent_authorization) {
        return rejected(AdmissionCode::parent_authorization_digest_mismatch);
    }
    if (trace.parent.authorization.present
        && trace.parent.authorization.target_digest != trace.parent.target_digest) {
        return rejected(AdmissionCode::parent_target_digest_mismatch);
    }

    const auto parent_report = parent::evaluate_candidate(trace.parent);
    if (!parent_report.accepted) return rejected(AdmissionCode::receipt_chain_rejected);
    if (parent_report.code == parent::ReceiptChainCode::accepted_chain_complete
        || parent_report.code == parent::ReceiptChainCode::accepted_deletion_receipt_gap_fail_stop) {
        return rejected(AdmissionCode::receipt_chain_already_deleted, true);
    }
    const bool parent_ready = parent_report.code
        == parent::ReceiptChainCode::accepted_chain_ready_live_retained;
    if (!parent_ready) return rejected(AdmissionCode::receipt_chain_not_ready, true);

    if (!constitution_shape_valid(trace.constitution)) {
        return rejected(AdmissionCode::constitution_shape_invalid, true, true);
    }
    if (trace.constitution.present && trace.constitution.project_id != trace.project_id) {
        return rejected(AdmissionCode::constitution_project_mismatch, true, true);
    }
    if (!profile_shape_valid(trace.annex)) {
        return rejected(AdmissionCode::profile_shape_invalid, true, true);
    }
    if (trace.annex.present) {
        if (trace.annex.project_id != trace.project_id) {
            return rejected(AdmissionCode::profile_project_mismatch, true, true);
        }
        if (trace.annex.owner_constitution_digest != trace.constitution.constitution_digest) {
            return rejected(AdmissionCode::profile_constitution_mismatch, true, true);
        }
        if (trace.annex.owner_root_digest != trace.constitution.owner_root_digest) {
            return rejected(AdmissionCode::profile_owner_root_mismatch, true, true);
        }
        if (trace.annex.parent_authorization_digest != trace.parent.authorization.authorization_digest) {
            return rejected(AdmissionCode::profile_parent_authorization_mismatch, true, true);
        }
        if (trace.annex.target_digest != trace.parent.target_digest) {
            return rejected(AdmissionCode::profile_target_mismatch, true, true);
        }
    }
    if (!ratification_shape_valid(trace.ratification)) {
        return rejected(AdmissionCode::ratification_shape_invalid, true, true);
    }
    if (trace.ratification.present) {
        if (trace.ratification.annex_digest != trace.annex.annex_digest) {
            return rejected(AdmissionCode::ratification_profile_mismatch, true, true);
        }
        if (trace.ratification.owner_constitution_digest != trace.constitution.constitution_digest) {
            return rejected(AdmissionCode::ratification_constitution_mismatch, true, true);
        }
        if (trace.ratification.owner_root_digest != trace.constitution.owner_root_digest) {
            return rejected(AdmissionCode::ratification_owner_root_mismatch, true, true);
        }
    }
    if (!separation_shape_valid(trace.separation)) {
        return rejected(AdmissionCode::separation_shape_invalid, true, true);
    }
    if (trace.separation.present && trace.separation.annex_digest != trace.annex.annex_digest) {
        return rejected(AdmissionCode::separation_profile_mismatch, true, true);
    }
    if (!corpus_shape_valid(trace.corpus)) {
        return rejected(AdmissionCode::corpus_shape_invalid, true, true);
    }
    if (trace.corpus.present) {
        if (trace.corpus.annex_digest != trace.annex.annex_digest
            || trace.corpus.failure_corpus_spec_digest != trace.annex.failure_corpus_spec_digest) {
            return rejected(AdmissionCode::corpus_profile_mismatch, true, true);
        }
        if (trace.corpus.implementation_digest != trace.annex.implementation_digest) {
            return rejected(AdmissionCode::corpus_implementation_mismatch, true, true);
        }
        if (trace.corpus.configuration_digest != trace.annex.configuration_digest) {
            return rejected(AdmissionCode::corpus_configuration_mismatch, true, true);
        }
    }
    if (!appraisal_shape_valid(trace.appraisal)) {
        return rejected(AdmissionCode::appraisal_shape_invalid, true, true);
    }
    if (trace.appraisal.present) {
        if (trace.appraisal.annex_digest != trace.annex.annex_digest) {
            return rejected(AdmissionCode::appraisal_profile_mismatch, true, true);
        }
        if (trace.appraisal.corpus_digest != trace.corpus.corpus_digest) {
            return rejected(AdmissionCode::appraisal_corpus_mismatch, true, true);
        }
        if (trace.appraisal.separation_digest != trace.separation.separation_digest) {
            return rejected(AdmissionCode::appraisal_separation_mismatch, true, true);
        }
    }
    if (!owner_admission_shape_valid(trace.admission)) {
        return rejected(AdmissionCode::owner_admission_shape_invalid, true, true);
    }
    if (trace.admission.present) {
        if (trace.admission.ratification_digest != trace.ratification.ratification_digest) {
            return rejected(AdmissionCode::owner_admission_ratification_mismatch, true, true);
        }
        if (trace.admission.appraisal_digest != trace.appraisal.appraisal_digest) {
            return rejected(AdmissionCode::owner_admission_appraisal_mismatch, true, true);
        }
        if (trace.admission.parent_authorization_digest
            != trace.parent.authorization.authorization_digest) {
            return rejected(AdmissionCode::owner_admission_parent_authorization_mismatch, true, true);
        }
        if (trace.admission.target_digest != trace.parent.target_digest) {
            return rejected(AdmissionCode::owner_admission_target_mismatch, true, true);
        }
    }

    const auto& first = trace.cuts.front();
    const auto first_phases = phases(first);
    if (!first.live_record_visible || first.record_deleted || !first.owner_constitution_visible
        || std::any_of(first_phases.cbegin() + 1, first_phases.cbegin() + 10,
            [](const bool value) { return value; })) {
        return rejected(AdmissionCode::trace_initial_state_invalid, true, true);
    }
    for (const AdmissionCut& cut : trace.cuts) {
        if (cut.live_record_visible && cut.record_deleted) {
            return rejected(AdmissionCode::trace_deleted_and_live, true, true);
        }
        if (!cut.live_record_visible && !cut.record_deleted) {
            return rejected(AdmissionCode::trace_live_absent_without_deletion, true, true);
        }
    }

    const bool constitution_valid = trace.constitution.present
        && nonzero(trace.project_id) && nonzero(trace.constitution.constitution_digest)
        && nonzero(trace.constitution.owner_root_digest)
        && nonzero(trace.constitution.constitution_policy_digest)
        && nonzero(trace.constitution.bootstrap_method_digest)
        && trace.constitution.canonical && trace.constitution.authenticated
        && trace.constitution.threshold_satisfied && trace.constitution.out_of_band_bootstrapped
        && trace.constitution.current_root_selected && trace.constitution.rollback_external
        && trace.constitution.durable && trace.constitution.single_view
        && trace.constitution.independently_reopenable && !trace.constitution.self_nominated;

    const bool profile_valid = constitution_valid && trace.annex.present
        && nonzero(trace.annex.annex_digest) && nonzero(trace.annex.profile_id)
        && nonzero(trace.annex.role_matrix_digest) && nonzero(trace.annex.failure_corpus_spec_digest)
        && nonzero(trace.annex.implementation_digest) && nonzero(trace.annex.configuration_digest)
        && trace.annex.requirement_mask == required_profile_mask && trace.annex.canonical
        && trace.annex.complete && trace.annex.no_hidden_inputs
        && trace.annex.exact_mechanism_selected && trace.annex.bootstrap_method_declared
        && trace.annex.collision_fail_closed && trace.annex.non_equivocation_witness_required
        && !trace.annex.self_ratifying;

    const bool ratification_core_valid = profile_valid && trace.ratification.present
        && nonzero(trace.ratification.ratification_digest)
        && nonzero(trace.ratification.ratification_policy_digest)
        && trace.ratification.authenticated && trace.ratification.threshold_satisfied
        && trace.ratification.owner_issued && trace.ratification.durable
        && trace.ratification.no_replace_published && trace.ratification.current_root_observed
        && !trace.ratification.self_issued_by_annex;
    const bool ratification_reopen_valid = ratification_core_valid
        && trace.ratification.single_view && trace.ratification.independently_reopenable;

    const std::array<Digest, 4U> administrative_roots{
        trace.separation.reopener_admin_digest,
        trace.separation.authorizer_admin_digest,
        trace.separation.appraiser_admin_digest,
        trace.separation.mechanism_admin_digest,
    };
    const std::array<Digest, 4U> rollback_roots{
        trace.separation.reopener_rollback_digest,
        trace.separation.authorizer_rollback_digest,
        trace.separation.appraiser_rollback_digest,
        trace.separation.mechanism_rollback_digest,
    };
    const bool separation_valid = ratification_reopen_valid && trace.separation.present
        && nonzero(trace.separation.separation_digest) && trace.separation.owner_ratified
        && trace.separation.distinct_administrative_roots && trace.separation.distinct_rollback_roots
        && trace.separation.distinct_credentials && trace.separation.recovery_roots_separate
        && trace.separation.appraiser_can_reopen_without_operator
        && trace.separation.collusion_model_declared && !trace.separation.same_process_only
        && all_distinct(administrative_roots) && all_distinct(rollback_roots);

    const bool downstream_single_view = (!trace.appraisal.present || trace.appraisal.single_view)
        && (!trace.admission.present || trace.admission.single_view);
    const bool transparency_valid = separation_valid
        && trace.annex.non_equivocation_witness_required
        && trace.constitution.single_view && trace.ratification.single_view
        && downstream_single_view && !trace.equivocation_observed;

    const bool corpus_valid = transparency_valid && trace.corpus.present
        && nonzero(trace.corpus.corpus_digest) && nonzero(trace.corpus.disposable_target_digest)
        && trace.corpus.observed_scenario_mask == required_corpus_mask
        && trace.corpus.canonical && trace.corpus.complete && trace.corpus.actual_not_synthetic
        && trace.corpus.exact_binaries && trace.corpus.exact_configuration
        && trace.corpus.raw_traces_retained && trace.corpus.independently_locatable
        && trace.corpus.replayable && trace.corpus.expected_outcomes_checked
        && trace.corpus.disposable_target_separate
        && trace.corpus.disposable_target_digest != trace.parent.target_digest;

    const bool appraisal_core_valid = corpus_valid && trace.appraisal.present
        && nonzero(trace.appraisal.appraisal_digest)
        && nonzero(trace.appraisal.appraisal_policy_digest)
        && trace.appraisal.appraiser_admin_digest == trace.separation.appraiser_admin_digest
        && trace.appraisal.authenticated && trace.appraisal.durable
        && trace.appraisal.no_replace_published && trace.appraisal.source_closed
        && trace.appraisal.independent_replay_performed && trace.appraisal.producer_not_appraiser
        && trace.appraisal.result_pass;
    const bool appraisal_reopen_valid = appraisal_core_valid
        && trace.appraisal.single_view && trace.appraisal.independently_reopenable;

    const bool owner_admission_core_valid = appraisal_reopen_valid && trace.admission_requested
        && trace.admission.present && nonzero(trace.admission.admission_digest)
        && trace.admission.owner_root_digest == trace.constitution.owner_root_digest
        && trace.admission.decision != OwnerDecision::none
        && trace.admission.authenticated && trace.admission.threshold_satisfied
        && trace.admission.durable && trace.admission.no_replace_published
        && trace.admission.current_root_observed && trace.admission.separately_governed
        && trace.admission.exact_predecessors_consumed && !trace.admission.self_issued_by_candidate;
    const bool owner_admission_reopen_valid = owner_admission_core_valid
        && trace.admission.single_view && trace.admission.independently_reopenable;

    const auto cut_facts = analyze_cuts(trace.cuts);
    const bool self_ratification = trace.constitution.self_nominated || trace.annex.self_ratifying
        || trace.ratification.self_issued_by_annex || trace.admission.self_issued_by_candidate;
    const bool common_control = trace.separation.present
        && (trace.separation.same_process_only || !trace.separation.distinct_administrative_roots
            || !trace.separation.distinct_rollback_roots || !all_distinct(administrative_roots)
            || !all_distinct(rollback_roots));
    const bool synthetic_corpus = trace.corpus.present && !trace.corpus.actual_not_synthetic;
    const bool owner_rejected = owner_admission_reopen_valid
        && trace.admission.decision == OwnerDecision::reject;
    const bool final_phase_visible = trace.cuts.back().owner_admission_reopened;
    const bool dossier_ready = owner_admission_reopen_valid
        && trace.admission.decision == OwnerDecision::admit && cut_facts.ordered
        && final_phase_visible && !cut_facts.unauthorized_deletion && !trace.equivocation_observed;

    AdmissionCode code = AdmissionCode::accepted_external_premises_ready_live_retained;
    bool fail_stopped = false;
    if (cut_facts.unauthorized_deletion) {
        code = AdmissionCode::accepted_unauthorized_deletion_fail_stop;
        fail_stopped = true;
    } else if (trace.equivocation_observed) {
        code = AdmissionCode::accepted_equivocation_fail_stop;
        fail_stopped = true;
    } else if (cut_facts.regression) {
        code = AdmissionCode::accepted_regression_fail_stop;
        fail_stopped = true;
    } else if (cut_facts.phase_gap
        || (owner_admission_reopen_valid && trace.admission.decision == OwnerDecision::admit
            && !final_phase_visible)) {
        code = AdmissionCode::accepted_refused_order_gap;
    } else if (!constitution_valid) {
        code = AdmissionCode::accepted_refused_constitution_gap;
    } else if (!profile_valid) {
        code = AdmissionCode::accepted_refused_profile_gap;
    } else if (!trace.ratification.present) {
        code = AdmissionCode::accepted_profile_closed_unratified;
    } else if (!ratification_reopen_valid) {
        code = AdmissionCode::accepted_refused_ratification_gap;
    } else if (!separation_valid) {
        code = AdmissionCode::accepted_refused_separation_gap;
    } else if (!transparency_valid) {
        code = AdmissionCode::accepted_refused_transparency_gap;
    } else if (!trace.corpus.present) {
        code = AdmissionCode::accepted_ratified_not_operated;
    } else if (!corpus_valid) {
        code = AdmissionCode::accepted_refused_corpus_gap;
    } else if (!trace.appraisal.present) {
        code = AdmissionCode::accepted_operated_not_appraised;
    } else if (!appraisal_reopen_valid) {
        code = AdmissionCode::accepted_refused_appraisal_gap;
    } else if (!trace.admission.present) {
        code = AdmissionCode::accepted_appraised_not_owner_admitted;
    } else if (!owner_admission_reopen_valid) {
        code = AdmissionCode::accepted_refused_owner_admission_gap;
    } else if (owner_rejected) {
        code = AdmissionCode::accepted_owner_rejected_live_retained;
    } else if (!dossier_ready) {
        code = AdmissionCode::accepted_refused_order_gap;
    }

    return accepted_report(code, true, true, constitution_valid, profile_valid,
        ratification_core_valid, ratification_reopen_valid, separation_valid,
        transparency_valid, corpus_valid, appraisal_core_valid, appraisal_reopen_valid,
        owner_admission_core_valid, owner_admission_reopen_valid, cut_facts,
        self_ratification, common_control, synthetic_corpus, owner_rejected,
        dossier_ready, fail_stopped);
}

std::string_view admission_code_name(const AdmissionCode value) noexcept {
    switch (value) {
    case AdmissionCode::accepted_external_premises_ready_live_retained: return "accepted_external_premises_ready_live_retained";
    case AdmissionCode::accepted_profile_closed_unratified: return "accepted_profile_closed_unratified";
    case AdmissionCode::accepted_ratified_not_operated: return "accepted_ratified_not_operated";
    case AdmissionCode::accepted_operated_not_appraised: return "accepted_operated_not_appraised";
    case AdmissionCode::accepted_appraised_not_owner_admitted: return "accepted_appraised_not_owner_admitted";
    case AdmissionCode::accepted_owner_rejected_live_retained: return "accepted_owner_rejected_live_retained";
    case AdmissionCode::accepted_refused_constitution_gap: return "accepted_refused_constitution_gap";
    case AdmissionCode::accepted_refused_profile_gap: return "accepted_refused_profile_gap";
    case AdmissionCode::accepted_refused_ratification_gap: return "accepted_refused_ratification_gap";
    case AdmissionCode::accepted_refused_separation_gap: return "accepted_refused_separation_gap";
    case AdmissionCode::accepted_refused_transparency_gap: return "accepted_refused_transparency_gap";
    case AdmissionCode::accepted_refused_corpus_gap: return "accepted_refused_corpus_gap";
    case AdmissionCode::accepted_refused_appraisal_gap: return "accepted_refused_appraisal_gap";
    case AdmissionCode::accepted_refused_owner_admission_gap: return "accepted_refused_owner_admission_gap";
    case AdmissionCode::accepted_refused_order_gap: return "accepted_refused_order_gap";
    case AdmissionCode::accepted_unauthorized_deletion_fail_stop: return "accepted_unauthorized_deletion_fail_stop";
    case AdmissionCode::accepted_equivocation_fail_stop: return "accepted_equivocation_fail_stop";
    case AdmissionCode::accepted_regression_fail_stop: return "accepted_regression_fail_stop";
    case AdmissionCode::receipt_chain_rejected: return "receipt_chain_rejected";
    case AdmissionCode::receipt_chain_not_ready: return "receipt_chain_not_ready";
    case AdmissionCode::receipt_chain_already_deleted: return "receipt_chain_already_deleted";
    case AdmissionCode::parent_authorization_digest_mismatch: return "parent_authorization_digest_mismatch";
    case AdmissionCode::parent_target_digest_mismatch: return "parent_target_digest_mismatch";
    case AdmissionCode::constitution_shape_invalid: return "constitution_shape_invalid";
    case AdmissionCode::constitution_project_mismatch: return "constitution_project_mismatch";
    case AdmissionCode::profile_shape_invalid: return "profile_shape_invalid";
    case AdmissionCode::profile_project_mismatch: return "profile_project_mismatch";
    case AdmissionCode::profile_constitution_mismatch: return "profile_constitution_mismatch";
    case AdmissionCode::profile_owner_root_mismatch: return "profile_owner_root_mismatch";
    case AdmissionCode::profile_parent_authorization_mismatch: return "profile_parent_authorization_mismatch";
    case AdmissionCode::profile_target_mismatch: return "profile_target_mismatch";
    case AdmissionCode::ratification_shape_invalid: return "ratification_shape_invalid";
    case AdmissionCode::ratification_profile_mismatch: return "ratification_profile_mismatch";
    case AdmissionCode::ratification_constitution_mismatch: return "ratification_constitution_mismatch";
    case AdmissionCode::ratification_owner_root_mismatch: return "ratification_owner_root_mismatch";
    case AdmissionCode::separation_shape_invalid: return "separation_shape_invalid";
    case AdmissionCode::separation_profile_mismatch: return "separation_profile_mismatch";
    case AdmissionCode::corpus_shape_invalid: return "corpus_shape_invalid";
    case AdmissionCode::corpus_profile_mismatch: return "corpus_profile_mismatch";
    case AdmissionCode::corpus_implementation_mismatch: return "corpus_implementation_mismatch";
    case AdmissionCode::corpus_configuration_mismatch: return "corpus_configuration_mismatch";
    case AdmissionCode::appraisal_shape_invalid: return "appraisal_shape_invalid";
    case AdmissionCode::appraisal_profile_mismatch: return "appraisal_profile_mismatch";
    case AdmissionCode::appraisal_corpus_mismatch: return "appraisal_corpus_mismatch";
    case AdmissionCode::appraisal_separation_mismatch: return "appraisal_separation_mismatch";
    case AdmissionCode::owner_admission_shape_invalid: return "owner_admission_shape_invalid";
    case AdmissionCode::owner_admission_ratification_mismatch: return "owner_admission_ratification_mismatch";
    case AdmissionCode::owner_admission_appraisal_mismatch: return "owner_admission_appraisal_mismatch";
    case AdmissionCode::owner_admission_parent_authorization_mismatch: return "owner_admission_parent_authorization_mismatch";
    case AdmissionCode::owner_admission_target_mismatch: return "owner_admission_target_mismatch";
    case AdmissionCode::trace_initial_state_invalid: return "trace_initial_state_invalid";
    case AdmissionCode::trace_deleted_and_live: return "trace_deleted_and_live";
    case AdmissionCode::trace_live_absent_without_deletion: return "trace_live_absent_without_deletion";
    }
    return "unknown";
}

std::string_view admission_cut_name(const std::size_t index) noexcept {
    constexpr std::array<std::string_view, admission_cut_count> names{
        "constitution_current",
        "annex_closed",
        "ratification_published",
        "ratification_reopened",
        "rehearsal_started",
        "corpus_complete",
        "appraisal_published",
        "appraisal_reopened",
        "owner_admission_published",
        "owner_admission_reopened_live_retained",
    };
    return index < names.size() ? names[index] : std::string_view{"unknown"};
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission
