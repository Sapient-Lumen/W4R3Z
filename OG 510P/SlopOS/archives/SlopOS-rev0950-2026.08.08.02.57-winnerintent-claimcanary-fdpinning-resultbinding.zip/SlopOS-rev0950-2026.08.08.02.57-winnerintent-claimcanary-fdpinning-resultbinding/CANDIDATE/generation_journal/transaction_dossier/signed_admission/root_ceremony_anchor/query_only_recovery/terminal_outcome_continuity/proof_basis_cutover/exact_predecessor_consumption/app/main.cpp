#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/exact_predecessor_consumption.hpp"

#include <filesystem>
#include <iostream>

int main(const int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "usage: slopos_exact_predecessor_consumption OUTPUT_DIRECTORY\n";
        return 2;
    }
    if (!slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::exact_predecessor_consumption::run_campaign(std::filesystem::path(argv[1]))) {
        std::cerr << "EXACT_PREDECESSOR_CONSUMPTION_CAMPAIGN=FAIL\n";
        return 1;
    }
    std::cout << "EXACT_PREDECESSOR_CONSUMPTION_CAMPAIGN=PASS authority=false\n";
    return 0;
}
