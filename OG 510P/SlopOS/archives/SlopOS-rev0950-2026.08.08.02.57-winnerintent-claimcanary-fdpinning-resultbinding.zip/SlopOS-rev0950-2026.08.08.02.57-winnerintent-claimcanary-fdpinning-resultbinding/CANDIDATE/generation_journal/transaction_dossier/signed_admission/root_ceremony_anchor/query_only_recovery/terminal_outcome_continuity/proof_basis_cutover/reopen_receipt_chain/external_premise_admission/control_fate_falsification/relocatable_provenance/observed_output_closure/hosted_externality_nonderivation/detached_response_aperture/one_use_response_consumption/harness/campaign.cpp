#include "slopos/e0/detached_response_aperture/one_use_response_consumption.hpp"

#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <array>
#include <cerrno>
#include <cstdint>
#include <filesystem>
#include <iostream>
#include <set>
#include <sstream>
#include <string>
#include <utility>
#include <vector>

namespace slopos::e0::detached_response_aperture::one_use_response_consumption {
namespace {

struct Case final { std::string name; Trace trace; Code expected; };

[[nodiscard]] constexpr std::uint8_t hex_value(const char c) noexcept {
    return c >= '0' && c <= '9' ? static_cast<std::uint8_t>(c - '0')
        : c >= 'a' && c <= 'f' ? static_cast<std::uint8_t>(10 + c - 'a') : 0U;
}
[[nodiscard]] Digest exact_digest(const std::string_view text) noexcept {
    Digest result{};
    if (text.size() != 64U) return result;
    for (std::size_t i = 0U; i < result.size(); ++i) {
        result[i] = static_cast<std::uint8_t>((hex_value(text[2U * i]) << 4U) | hex_value(text[2U * i + 1U]));
    }
    return result;
}
[[nodiscard]] std::string hex(const Digest& value) {
    static constexpr char alphabet[] = "0123456789abcdef";
    std::string result(value.size() * 2U, '0');
    for (std::size_t i = 0U; i < value.size(); ++i) {
        result[2U * i] = alphabet[value[i] >> 4U];
        result[2U * i + 1U] = alphabet[value[i] & 0x0fU];
    }
    return result;
}
[[nodiscard]] Digest tamper(Digest value, const std::size_t index = 0U) noexcept {
    value[index % value.size()] ^= 0x01U;
    return value;
}
[[nodiscard]] Digest pair_digest(const std::string_view domain, const Digest& left, const Digest& right) noexcept {
    std::array<std::uint8_t, 64U> bytes{};
    std::copy(left.begin(), left.end(), bytes.begin());
    std::copy(right.begin(), right.end(), bytes.begin() + 32);
    return sha256_domain(domain, bytes.data(), bytes.size());
}
void refresh_parent(Trace& t) { t.parent.binding_digest = parent_binding_identity(t.parent); }
void refresh_appraisal(Trace& t) { t.appraisal.carrier_digest = appraisal_carrier_identity(t.appraisal); }
void refresh_request(Trace& t) { t.request.request_digest = consume_request_identity(t.request); }
void refresh_invocation(Trace& t) { t.invocation.invocation_digest = invocation_identity(t.invocation); }
void refresh_query(Trace& t) { t.query.observation_digest = query_observation_identity(t.query); }
void refresh_commit(Trace& t) { t.commit.commit_digest = journal_commit_identity(t.commit); }
void refresh_terminal(Trace& t) { t.terminal.receipt_digest = terminal_receipt_identity(t.terminal); }
void refresh_reopen(Trace& t) { t.reopen.receipt_digest = reopen_receipt_identity(t.reopen); }
void refresh_cuts(Trace& t) {
    for (std::size_t i = 0U; i < cut_count; ++i) {
        t.cuts[i] = {};
        if (t.parent.present) t.cuts[i].parent_binding_digest = t.parent.binding_digest;
        if (i >= 1U && t.appraisal.present) t.cuts[i].appraisal_carrier_digest = t.appraisal.carrier_digest;
        if (i >= 2U && t.request.present) t.cuts[i].request_digest = t.request.request_digest;
        if (i >= 3U && t.invocation.present) t.cuts[i].invocation_digest = t.invocation.invocation_digest;
        if (i >= 4U && t.query.present) t.cuts[i].query_observation_digest = t.query.observation_digest;
        if (i >= 5U && t.commit.present) t.cuts[i].commit_digest = t.commit.commit_digest;
        if (i >= 6U && t.terminal.present) t.cuts[i].terminal_receipt_digest = t.terminal.receipt_digest;
        if (i >= 7U && t.reopen.present) t.cuts[i].reopen_receipt_digest = t.reopen.receipt_digest;
    }
}
void refresh_from_parent(Trace& t) {
    refresh_parent(t);
    t.appraisal.parent_binding_digest = t.parent.binding_digest;
    t.request.parent_binding_digest = t.parent.binding_digest;
    refresh_appraisal(t);
    t.request.appraisal_carrier_digest = t.appraisal.carrier_digest;
    refresh_request(t);
    t.invocation.request_digest = t.request.request_digest;
    t.invocation.operation_id = t.request.operation_id;
    t.invocation.expected_predecessor_head = t.request.expected_predecessor_head;
    t.invocation.journal_namespace_digest = t.request.journal_namespace_digest;
    refresh_invocation(t);
    t.query.invocation_digest = t.invocation.invocation_digest;
    t.query.request_digest = t.request.request_digest;
    t.query.operation_id = t.request.operation_id;
    t.query.expected_predecessor_head = t.request.expected_predecessor_head;
    t.query.observed_head = t.request.expected_predecessor_head;
    t.query.journal_namespace_digest = t.request.journal_namespace_digest;
    t.query.query_policy_digest = t.invocation.query_policy_digest;
    t.query.observed_generation = t.request.expected_generation;
    refresh_query(t);
    t.commit.request_digest = t.request.request_digest;
    t.commit.response_digest = t.request.response_digest;
    t.commit.appraisal_carrier_digest = t.appraisal.carrier_digest;
    t.commit.query_observation_digest = t.query.observation_digest;
    t.commit.predecessor_head = t.request.expected_predecessor_head;
    t.commit.successor_head = pair_digest("slopos.ourc.successor-head.v2", t.request.expected_predecessor_head, t.request.request_digest);
    t.commit.operation_id = t.request.operation_id;
    t.commit.journal_namespace_digest = t.request.journal_namespace_digest;
    t.commit.terminal_payload_digest = sha256_domain("slopos.ourc.terminal-payload.v1", t.request.request_payload_digest.data(), t.request.request_payload_digest.size());
    t.commit.predecessor_generation = t.request.expected_generation;
    t.commit.successor_generation = t.request.expected_generation + 1U;
    t.commit.commit_revision = t.query.query_revision + 1U;
    refresh_commit(t);
    t.terminal.commit_digest = t.commit.commit_digest;
    t.terminal.request_digest = t.request.request_digest;
    t.terminal.response_digest = t.request.response_digest;
    t.terminal.predecessor_head = t.commit.predecessor_head;
    t.terminal.successor_head = t.commit.successor_head;
    t.terminal.operation_id = t.request.operation_id;
    t.terminal.terminal_payload_digest = t.commit.terminal_payload_digest;
    t.terminal.commit_revision = t.commit.commit_revision;
    refresh_terminal(t);
    t.reopen.terminal_receipt_digest = t.terminal.receipt_digest;
    t.reopen.commit_digest = t.commit.commit_digest;
    t.reopen.request_digest = t.request.request_digest;
    t.reopen.response_digest = t.request.response_digest;
    refresh_reopen(t);
    refresh_cuts(t);
}

[[nodiscard]] Trace baseline() {
    Trace t{};
    t.parent.parent_output_set_digest = exact_digest(SLOPOS_OURC_PARENT_OUTPUT_SET_SHA256_HEX);
    t.parent.parent_composition_receipt_digest = exact_digest(SLOPOS_OURC_PARENT_COMPOSITION_RECEIPT_SHA256_HEX);
    t.parent.response_digest = exact_digest(SLOPOS_OURC_PARENT_RESPONSE_SHA256_HEX);
    t.parent.accepting_configuration_digest = exact_digest(SLOPOS_OURC_PARENT_ACCEPTING_CONFIGURATION_SHA256_HEX);
    t.parent.appraisal_witness_digest = exact_digest(SLOPOS_OURC_PARENT_APPRAISAL_WITNESS_SHA256_HEX);
    t.parent.consumption_deficit_digest = exact_digest(SLOPOS_OURC_PARENT_CONSUMPTION_DEFICIT_SHA256_HEX);
    t.parent.parent_archive_digest = exact_digest(SLOPOS_OURC_PARENT_ARCHIVE_SHA256_HEX);
    t.parent.parent_archive_bytes = static_cast<std::uint64_t>(SLOPOS_OURC_PARENT_ARCHIVE_BYTES);
    t.parent.parent_manifest_rows = static_cast<std::uint64_t>(SLOPOS_OURC_PARENT_MANIFEST_ROWS);
    t.parent.schema = schema_version; t.parent.present = true; t.parent.canonical = true;
    t.parent.parent_aperture_pass = true; t.parent.parent_external_response_present = false;
    t.parent.parent_authority_granted = false;
    refresh_parent(t);

    t.appraisal.parent_binding_digest = t.parent.binding_digest;
    t.appraisal.response_digest = t.parent.response_digest;
    t.appraisal.accepting_configuration_digest = t.parent.accepting_configuration_digest;
    t.appraisal.appraisal_witness_digest = t.parent.appraisal_witness_digest;
    t.appraisal.owner_root_digest = text_digest("laboratory-owner-root:version-41");
    t.appraisal.appraisal_policy_digest = text_digest("laboratory-appraisal-policy:v1");
    t.appraisal.trusted_time_source_digest = text_digest("laboratory-time-source:not-external");
    t.appraisal.owner_root_version = 41U; t.appraisal.appraisal_time = 1200U;
    t.appraisal.consume_not_after = 1800U; t.appraisal.schema = schema_version;
    t.appraisal.present = true; t.appraisal.canonical = true; t.appraisal.appraisal_accepted = true;
    t.appraisal.laboratory_carrier = true; t.appraisal.external_currentness_proved = false;
    refresh_appraisal(t);

    t.request.parent_binding_digest = t.parent.binding_digest;
    t.request.response_digest = t.parent.response_digest;
    t.request.appraisal_carrier_digest = t.appraisal.carrier_digest;
    t.request.expected_predecessor_head = text_digest("one-use-journal:genesis-head");
    t.request.operation_id = text_digest("one-use-operation:response-6d5b:root-41:request-1");
    t.request.journal_namespace_digest = text_digest("journal-namespace:slopos-owner-response-consumption");
    t.request.consumption_policy_digest = exact_digest(SLOPOS_OURC_CONSUMPTION_POLICY_SHA256_HEX);
    t.request.request_payload_digest = text_digest("consume-payload:exact-parent-response-and-appraisal");
    t.request.expected_generation = 0U; t.request.requested_at = 1250U;
    t.request.schema = schema_version; t.request.present = true; t.request.canonical = true;
    t.request.fixed_payload = true; t.request.blind_retry_forbidden = true;
    refresh_request(t);

    t.invocation.request_digest = t.request.request_digest; t.invocation.operation_id = t.request.operation_id;
    t.invocation.expected_predecessor_head = t.request.expected_predecessor_head;
    t.invocation.journal_namespace_digest = t.request.journal_namespace_digest;
    t.invocation.submission_channel_digest = text_digest("abstract-compare-append-channel:not-operated");
    t.invocation.query_policy_digest = exact_digest(SLOPOS_OURC_QUERY_POLICY_SHA256_HEX);
    t.invocation.submitted_at = 1260U; t.invocation.schema = schema_version;
    t.invocation.present = true; t.invocation.canonical = true; t.invocation.response_returned = false;
    t.invocation.query_only_after_loss = true;
    refresh_invocation(t);

    t.query.invocation_digest = t.invocation.invocation_digest;
    t.query.request_digest = t.request.request_digest;
    t.query.operation_id = t.request.operation_id;
    t.query.expected_predecessor_head = t.request.expected_predecessor_head;
    t.query.observed_head = t.request.expected_predecessor_head;
    t.query.journal_namespace_digest = t.request.journal_namespace_digest;
    t.query.query_policy_digest = t.invocation.query_policy_digest;
    t.query.query_role_digest = exact_digest(SLOPOS_OURC_QUERY_OBSERVER_ROLE_SHA256_HEX);
    t.query.observed_generation = t.request.expected_generation;
    t.query.query_revision = 1U;
    t.query.queried_at = 1270U;
    t.query.schema = schema_version;
    t.query.finding = QueryFinding::exact_absence;
    t.query.present = true; t.query.canonical = true; t.query.durable = true;
    t.query.query_only = true; t.query.model_only = true;
    t.query.terminal_no_effect_proved = false;
    t.query.external_linearizable_read_proved = false;
    refresh_query(t);

    t.commit.request_digest = t.request.request_digest; t.commit.response_digest = t.request.response_digest;
    t.commit.appraisal_carrier_digest = t.appraisal.carrier_digest;
    t.commit.query_observation_digest = t.query.observation_digest;
    t.commit.predecessor_head = t.request.expected_predecessor_head;
    t.commit.successor_head = pair_digest("slopos.ourc.successor-head.v2", t.request.expected_predecessor_head, t.request.request_digest);
    t.commit.operation_id = t.request.operation_id; t.commit.journal_namespace_digest = t.request.journal_namespace_digest;
    t.commit.terminal_payload_digest = sha256_domain("slopos.ourc.terminal-payload.v1", t.request.request_payload_digest.data(), t.request.request_payload_digest.size());
    t.commit.compare_append_policy_digest = exact_digest(SLOPOS_OURC_CONSUMPTION_POLICY_SHA256_HEX);
    t.commit.predecessor_generation = 0U; t.commit.successor_generation = 1U; t.commit.commit_revision = 2U;
    t.commit.schema = schema_version; t.commit.outcome = Outcome::applied; t.commit.present = true;
    t.commit.canonical = true; t.commit.durable = true; t.commit.atomic_compare_append = true; t.commit.model_only = true;
    refresh_commit(t);

    t.terminal.commit_digest = t.commit.commit_digest; t.terminal.request_digest = t.request.request_digest;
    t.terminal.response_digest = t.request.response_digest; t.terminal.predecessor_head = t.commit.predecessor_head;
    t.terminal.successor_head = t.commit.successor_head; t.terminal.operation_id = t.request.operation_id;
    t.terminal.terminal_payload_digest = t.commit.terminal_payload_digest;
    t.terminal.receipt_policy_digest = exact_digest(SLOPOS_OURC_CONSUMPTION_POLICY_SHA256_HEX);
    t.terminal.commit_revision = t.commit.commit_revision; t.terminal.terminal_at = 1290U;
    t.terminal.schema = schema_version; t.terminal.outcome = Outcome::applied; t.terminal.present = true;
    t.terminal.canonical = true; t.terminal.durable = true; t.terminal.exact_retry_equivalence = true;
    refresh_terminal(t);

    t.reopen.terminal_receipt_digest = t.terminal.receipt_digest; t.reopen.commit_digest = t.commit.commit_digest;
    t.reopen.request_digest = t.request.request_digest; t.reopen.response_digest = t.request.response_digest;
    t.reopen.reopener_implementation_digest = exact_digest(SLOPOS_OURC_REOPENER_IMPLEMENTATION_SHA256_HEX);
    t.reopen.reopener_role_digest = text_digest("role:hosted-independent-code-reopener");
    t.reopen.reopen_policy_digest = exact_digest(SLOPOS_OURC_REOPEN_POLICY_SHA256_HEX);
    t.reopen.reopened_at = 1310U; t.reopen.schema = schema_version; t.reopen.present = true;
    t.reopen.canonical = true; t.reopen.durable = true; t.reopen.exact_receipt_reopened = true;
    t.reopen.separate_role_label = true; t.reopen.administrative_independence_proved = false;
    refresh_reopen(t);
    refresh_cuts(t);
    return t;
}

[[nodiscard]] Trace at_stage(const Trace& complete, const std::size_t stage) {
    Trace t = complete;
    if (stage < 7U) t.reopen = {};
    if (stage < 6U) t.terminal = {};
    if (stage < 5U) t.commit = {};
    if (stage < 4U) t.query = {};
    if (stage < 3U) t.invocation = {};
    if (stage < 2U) t.request = {};
    if (stage < 1U) t.appraisal = {};
    refresh_cuts(t);
    return t;
}
void add(std::vector<Case>& cases, std::string name, Trace trace, const Code expected) {
    cases.push_back(Case{std::move(name), std::move(trace), expected});
}

[[nodiscard]] std::vector<Case> corpus() {
    const Trace good = baseline();
    std::vector<Case> cases;
    const std::array<Code, cut_count> accepted{{
        Code::accepted_parent_bound, Code::accepted_appraisal_durable, Code::accepted_request_durable,
        Code::accepted_pending_query_only, Code::accepted_absent_query_durable,
        Code::accepted_commit_durable, Code::accepted_terminal_receipt_durable,
        Code::accepted_reopen_durable,
    }};
    for (std::size_t i = 0U; i < accepted.size(); ++i) add(cases, "durable_stage_" + std::to_string(i), at_stage(good, i), accepted[i]);

    { auto t=good; t.parent.binding_digest=tamper(t.parent.binding_digest); add(cases,"parent_digest_tamper",t,Code::parent_binding_invalid); }
    { auto t=good; t.parent.parent_output_set_digest=tamper(t.parent.parent_output_set_digest); refresh_from_parent(t); add(cases,"parent_output_set_substitution",t,Code::parent_binding_invalid); }
    { auto t=good; t.parent.parent_composition_receipt_digest=tamper(t.parent.parent_composition_receipt_digest); refresh_from_parent(t); add(cases,"parent_composition_substitution",t,Code::parent_binding_invalid); }
    { auto t=good; t.parent.response_digest=tamper(t.parent.response_digest); refresh_from_parent(t); add(cases,"parent_response_substitution",t,Code::parent_binding_invalid); }
    { auto t=good; ++t.parent.parent_archive_bytes; refresh_from_parent(t); add(cases,"parent_archive_size_substitution",t,Code::parent_binding_invalid); }
    { auto t=good; t.parent.parent_external_response_present=true; refresh_from_parent(t); add(cases,"parent_external_response_promotion",t,Code::parent_binding_invalid); }
    { auto t=good; t.parent.parent_authority_granted=true; refresh_from_parent(t); add(cases,"parent_authority_promotion",t,Code::parent_binding_invalid); }
    { auto t=good; t.parent.parent_aperture_pass=false; refresh_from_parent(t); add(cases,"parent_aperture_not_pass",t,Code::parent_binding_invalid); }

    { auto t=good; t.appraisal={}; refresh_cuts(t); add(cases,"later_objects_without_appraisal",t,Code::appraisal_without_parent); }
    { auto t=good; t.appraisal.canonical=false; refresh_appraisal(t); refresh_cuts(t); add(cases,"appraisal_noncanonical",t,Code::appraisal_invalid); }
    { auto t=good; t.appraisal.carrier_digest=tamper(t.appraisal.carrier_digest); add(cases,"appraisal_digest_tamper",t,Code::appraisal_invalid); }
    { auto t=good; t.appraisal.parent_binding_digest=tamper(t.appraisal.parent_binding_digest); refresh_appraisal(t); refresh_cuts(t); add(cases,"appraisal_parent_mismatch",t,Code::appraisal_invalid); }
    { auto t=good; t.appraisal.response_digest=tamper(t.appraisal.response_digest); refresh_appraisal(t); refresh_cuts(t); add(cases,"appraisal_response_mismatch",t,Code::appraisal_invalid); }
    { auto t=good; t.appraisal.accepting_configuration_digest=tamper(t.appraisal.accepting_configuration_digest); refresh_appraisal(t); refresh_cuts(t); add(cases,"appraisal_configuration_mismatch",t,Code::appraisal_invalid); }
    { auto t=good; t.appraisal.appraisal_witness_digest=tamper(t.appraisal.appraisal_witness_digest); refresh_appraisal(t); refresh_cuts(t); add(cases,"appraisal_witness_mismatch",t,Code::appraisal_invalid); }
    { auto t=good; t.appraisal.owner_root_version=42U; refresh_appraisal(t); refresh_cuts(t); add(cases,"appraisal_successor_root",t,Code::appraisal_invalid); }
    { auto t=good; t.appraisal.external_currentness_proved=true; refresh_appraisal(t); refresh_cuts(t); add(cases,"appraisal_external_currentness_promotion",t,Code::appraisal_invalid); }
    { auto t=good; t.appraisal.consume_not_after=t.appraisal.appraisal_time; refresh_appraisal(t); refresh_cuts(t); add(cases,"appraisal_empty_consumption_window",t,Code::appraisal_invalid); }

    { auto t=good; t.request={}; refresh_cuts(t); add(cases,"later_objects_without_request",t,Code::request_without_appraisal); }
    { auto t=good; t.request.canonical=false; refresh_request(t); refresh_cuts(t); add(cases,"request_noncanonical",t,Code::request_invalid); }
    { auto t=good; t.request.request_digest=tamper(t.request.request_digest); add(cases,"request_digest_tamper",t,Code::request_invalid); }
    { auto t=good; t.request.parent_binding_digest=tamper(t.request.parent_binding_digest); refresh_request(t); refresh_cuts(t); add(cases,"request_parent_mismatch",t,Code::request_invalid); }
    { auto t=good; t.request.response_digest=tamper(t.request.response_digest); refresh_request(t); refresh_cuts(t); add(cases,"request_response_mismatch",t,Code::request_invalid); }
    { auto t=good; t.request.appraisal_carrier_digest=tamper(t.request.appraisal_carrier_digest); refresh_request(t); refresh_cuts(t); add(cases,"request_appraisal_mismatch",t,Code::request_invalid); }
    { auto t=good; t.request.expected_predecessor_head={}; refresh_request(t); refresh_cuts(t); add(cases,"request_zero_predecessor",t,Code::request_invalid); }
    { auto t=good; t.request.operation_id={}; refresh_request(t); refresh_cuts(t); add(cases,"request_zero_operation",t,Code::request_invalid); }
    { auto t=good; t.request.consumption_policy_digest=tamper(t.request.consumption_policy_digest); refresh_request(t); refresh_cuts(t); add(cases,"request_policy_mismatch",t,Code::request_invalid); }
    { auto t=good; t.request.requested_at=1199U; refresh_request(t); refresh_cuts(t); add(cases,"request_before_appraisal",t,Code::request_time_invalid); }
    { auto t=good; t.request.requested_at=1801U; refresh_request(t); refresh_cuts(t); add(cases,"request_after_window",t,Code::request_time_invalid); }
    { auto t=good; t.request.blind_retry_forbidden=false; refresh_request(t); refresh_cuts(t); add(cases,"request_blind_retry_allowed",t,Code::request_invalid); }

    { auto t=good; t.invocation={}; refresh_cuts(t); add(cases,"later_objects_without_invocation",t,Code::invocation_without_request); }
    { auto t=good; t.invocation.canonical=false; refresh_invocation(t); refresh_cuts(t); add(cases,"invocation_noncanonical",t,Code::invocation_invalid); }
    { auto t=good; t.invocation.invocation_digest=tamper(t.invocation.invocation_digest); add(cases,"invocation_digest_tamper",t,Code::invocation_invalid); }
    { auto t=good; t.invocation.request_digest=tamper(t.invocation.request_digest); refresh_invocation(t); refresh_cuts(t); add(cases,"invocation_request_mismatch",t,Code::invocation_invalid); }
    { auto t=good; t.invocation.operation_id=tamper(t.invocation.operation_id); refresh_invocation(t); refresh_cuts(t); add(cases,"invocation_operation_mismatch",t,Code::invocation_invalid); }
    { auto t=good; t.invocation.response_returned=true; refresh_invocation(t); refresh_cuts(t); add(cases,"invocation_response_already_returned",t,Code::invocation_invalid); }
    { auto t=good; t.invocation.query_only_after_loss=false; refresh_invocation(t); refresh_cuts(t); add(cases,"invocation_blind_retry_route",t,Code::invocation_invalid); }
    { auto t=good; t.invocation.query_policy_digest=tamper(t.invocation.query_policy_digest); refresh_invocation(t); refresh_cuts(t); add(cases,"invocation_query_policy_mismatch",t,Code::invocation_invalid); }

    { auto t=good; t.query={}; refresh_cuts(t); add(cases,"later_objects_without_query_observation",t,Code::commit_without_query_observation); }
    { auto t=good; t.query.present=false; refresh_query(t); refresh_cuts(t); add(cases,"query_present_bit_cleared_with_later_objects",t,Code::commit_without_query_observation); }
    { auto t=good; t.query.canonical=false; refresh_query(t); refresh_cuts(t); add(cases,"query_noncanonical",t,Code::query_invalid); }
    { auto t=good; t.query.observation_digest=tamper(t.query.observation_digest); add(cases,"query_digest_tamper",t,Code::query_invalid); }
    { auto t=good; t.query.invocation_digest=tamper(t.query.invocation_digest); refresh_query(t); refresh_cuts(t); add(cases,"query_invocation_mismatch",t,Code::query_invalid); }
    { auto t=good; t.query.request_digest=tamper(t.query.request_digest); refresh_query(t); refresh_cuts(t); add(cases,"query_request_mismatch",t,Code::query_invalid); }
    { auto t=good; t.query.operation_id=tamper(t.query.operation_id); refresh_query(t); refresh_cuts(t); add(cases,"query_operation_mismatch",t,Code::query_invalid); }
    { auto t=good; t.query.expected_predecessor_head=tamper(t.query.expected_predecessor_head); refresh_query(t); refresh_cuts(t); add(cases,"query_expected_predecessor_mismatch",t,Code::query_invalid); }
    { auto t=good; t.query.observed_head=tamper(t.query.observed_head); refresh_query(t); refresh_cuts(t); add(cases,"query_observed_head_mismatch",t,Code::query_invalid); }
    { auto t=good; t.query.journal_namespace_digest=tamper(t.query.journal_namespace_digest); refresh_query(t); refresh_cuts(t); add(cases,"query_namespace_mismatch",t,Code::query_invalid); }
    { auto t=good; t.query.query_policy_digest=tamper(t.query.query_policy_digest); refresh_query(t); refresh_cuts(t); add(cases,"query_policy_mismatch",t,Code::query_invalid); }
    { auto t=good; t.query.query_role_digest=tamper(t.query.query_role_digest); refresh_query(t); refresh_cuts(t); add(cases,"query_role_substitution",t,Code::query_invalid); }
    { auto t=good; ++t.query.observed_generation; refresh_query(t); refresh_cuts(t); add(cases,"query_observed_generation_mismatch",t,Code::query_invalid); }
    { auto t=good; t.query.finding=QueryFinding::none; refresh_query(t); refresh_cuts(t); add(cases,"query_finding_none",t,Code::query_invalid); }
    { auto t=good; t.query.finding=QueryFinding::exact_commit; refresh_query(t); refresh_cuts(t); add(cases,"query_claims_commit_before_commit",t,Code::query_invalid); }
    { auto t=good; t.query.finding=QueryFinding::conflicting_record; refresh_query(t); refresh_cuts(t); add(cases,"query_conflicting_record",t,Code::query_invalid); }
    { auto t=good; t.query.finding=QueryFinding::unavailable; refresh_query(t); refresh_cuts(t); add(cases,"query_unavailable",t,Code::query_invalid); }
    { auto t=good; t.query.finding=static_cast<QueryFinding>(255U); refresh_query(t); refresh_cuts(t); add(cases,"query_enum_out_of_range",t,Code::query_invalid); }
    { auto t=good; t.query.query_revision=0U; refresh_query(t); refresh_cuts(t); add(cases,"query_revision_zero",t,Code::query_invalid); }
    { auto t=good; t.query.query_revision=2U; refresh_query(t); refresh_cuts(t); add(cases,"query_revision_noninitial",t,Code::query_invalid); }
    { auto t=good; t.query.queried_at=t.invocation.submitted_at-1U; refresh_query(t); refresh_cuts(t); add(cases,"query_before_submission",t,Code::query_invalid); }
    { auto t=good; t.query.queried_at=t.appraisal.consume_not_after+1U; refresh_query(t); refresh_cuts(t); add(cases,"query_after_appraisal_window",t,Code::query_invalid); }
    { auto t=good; t.query.schema=schema_version+1U; refresh_query(t); refresh_cuts(t); add(cases,"query_schema_mismatch",t,Code::query_invalid); }
    { auto t=good; t.query.durable=false; refresh_query(t); refresh_cuts(t); add(cases,"query_not_durable",t,Code::query_invalid); }
    { auto t=good; t.query.query_only=false; refresh_query(t); refresh_cuts(t); add(cases,"query_effectful_route",t,Code::query_invalid); }
    { auto t=good; t.query.model_only=false; refresh_query(t); refresh_cuts(t); add(cases,"query_model_boundary_removed",t,Code::query_invalid); }
    { auto t=good; t.query.terminal_no_effect_proved=true; refresh_query(t); refresh_cuts(t); add(cases,"query_self_promotes_terminal_no_effect",t,Code::query_invalid); }
    { auto t=good; t.query.external_linearizable_read_proved=true; refresh_query(t); refresh_cuts(t); add(cases,"query_self_promotes_external_linearizability",t,Code::query_invalid); }

    { auto t=good; t.commit={}; refresh_cuts(t); add(cases,"later_objects_without_commit",t,Code::receipt_without_commit); }
    { auto t=good; t.commit.canonical=false; refresh_commit(t); refresh_cuts(t); add(cases,"commit_noncanonical",t,Code::commit_invalid); }
    { auto t=good; t.commit.commit_digest=tamper(t.commit.commit_digest); add(cases,"commit_digest_tamper",t,Code::commit_invalid); }
    { auto t=good; t.commit.query_observation_digest=tamper(t.commit.query_observation_digest); refresh_commit(t); refresh_cuts(t); add(cases,"commit_query_observation_mismatch",t,Code::commit_invalid); }
    { auto t=good; ++t.commit.commit_revision; refresh_commit(t); refresh_cuts(t); add(cases,"commit_revision_not_after_query",t,Code::commit_invalid); }
    { auto t=good; t.commit.predecessor_head=tamper(t.commit.predecessor_head); refresh_commit(t); refresh_cuts(t); add(cases,"commit_predecessor_mismatch",t,Code::commit_compare_mismatch); }
    { auto t=good; t.commit.predecessor_generation=1U; refresh_commit(t); refresh_cuts(t); add(cases,"commit_generation_mismatch",t,Code::commit_compare_mismatch); }
    { auto t=good; t.commit.successor_head=tamper(t.commit.successor_head); refresh_commit(t); refresh_cuts(t); add(cases,"commit_successor_mismatch",t,Code::commit_invalid); }
    { auto t=good; t.commit.successor_head=sha256_domain("slopos.ourc.successor-head.v1", t.request.request_digest.data(), t.request.request_digest.size()); refresh_commit(t); refresh_cuts(t); add(cases,"legacy_request_only_successor_rejected",t,Code::commit_invalid); }
    { auto t=good; t.commit.outcome=Outcome::already_applied; refresh_commit(t); refresh_cuts(t); add(cases,"commit_wrong_outcome",t,Code::commit_invalid); }
    { auto t=good; t.commit.durable=false; refresh_commit(t); refresh_cuts(t); add(cases,"commit_not_durable",t,Code::commit_invalid); }
    { auto t=good; t.commit.atomic_compare_append=false; refresh_commit(t); refresh_cuts(t); add(cases,"commit_not_atomic",t,Code::commit_invalid); }
    { auto t=good; t.commit.model_only=false; refresh_commit(t); refresh_cuts(t); add(cases,"commit_model_boundary_removed",t,Code::commit_invalid); }

    { auto t=good; t.terminal={}; refresh_cuts(t); add(cases,"reopen_without_terminal",t,Code::receipt_without_commit); }
    { auto t=good; t.terminal.canonical=false; refresh_terminal(t); refresh_cuts(t); add(cases,"terminal_noncanonical",t,Code::receipt_invalid); }
    { auto t=good; t.terminal.receipt_digest=tamper(t.terminal.receipt_digest); add(cases,"terminal_digest_tamper",t,Code::receipt_invalid); }
    { auto t=good; t.terminal.commit_digest=tamper(t.terminal.commit_digest); refresh_terminal(t); refresh_cuts(t); add(cases,"terminal_commit_mismatch",t,Code::receipt_invalid); }
    { auto t=good; t.terminal.exact_retry_equivalence=false; refresh_terminal(t); refresh_cuts(t); add(cases,"terminal_retry_equivalence_missing",t,Code::receipt_invalid); }
    { auto t=good; t.terminal.outcome=Outcome::predecessor_conflict; refresh_terminal(t); refresh_cuts(t); add(cases,"terminal_wrong_outcome",t,Code::receipt_invalid); }

    { auto t=good; t.reopen.canonical=false; refresh_reopen(t); refresh_cuts(t); add(cases,"reopen_noncanonical",t,Code::reopen_invalid); }
    { auto t=good; t.reopen.receipt_digest=tamper(t.reopen.receipt_digest); add(cases,"reopen_digest_tamper",t,Code::reopen_invalid); }
    { auto t=good; t.reopen.terminal_receipt_digest=tamper(t.reopen.terminal_receipt_digest); refresh_reopen(t); refresh_cuts(t); add(cases,"reopen_terminal_mismatch",t,Code::reopen_invalid); }
    { auto t=good; t.reopen.reopener_implementation_digest=tamper(t.reopen.reopener_implementation_digest); refresh_reopen(t); refresh_cuts(t); add(cases,"reopen_implementation_substitution",t,Code::reopen_invalid); }
    { auto t=good; t.reopen.administrative_independence_proved=true; refresh_reopen(t); refresh_cuts(t); add(cases,"reopen_witnessless_independence",t,Code::reopen_invalid); }

    { auto t=at_stage(good,4U); t.declare_terminal_no_effect_from_absence=true; add(cases,"pending_absence_promoted_to_no_effect",t,Code::absent_query_promoted_to_no_effect); }
    { auto t=good; t.consume_under_successor_root_without_fresh_appraisal=true; add(cases,"stale_root_consumption",t,Code::stale_root_consumption_forbidden); }
    { auto t=good; t.promote_model_to_external_operation=true; add(cases,"hosted_operation_promotion",t,Code::hosted_operation_promotion_forbidden); }
    { auto t=good; t.promote_receipt_to_owner_admission=true; add(cases,"receipt_owner_admission_promotion",t,Code::owner_admission_promotion_forbidden); }
    { auto t=good; t.grant_authority=true; add(cases,"authority_promotion",t,Code::authority_promotion_forbidden); }
    { auto t=good; t.cuts[4U].query_observation_digest=tamper(t.cuts[4U].query_observation_digest); add(cases,"query_cut_order_tamper",t,Code::cut_order_invalid); }
    { auto t=good; t.cuts[5U].commit_digest=tamper(t.cuts[5U].commit_digest); add(cases,"commit_cut_order_tamper",t,Code::cut_order_invalid); }
    return cases;
}

[[nodiscard]] bool write_exact(const std::filesystem::path& path, const std::uint8_t* data, const std::size_t size) {
    const int fd = ::open(path.c_str(), O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC, 0444);
    if (fd < 0) return false;
    std::size_t offset = 0U;
    while (offset < size) {
        const ssize_t n = ::write(fd, data + offset, size - offset);
        if (n <= 0) { ::close(fd); return false; }
        offset += static_cast<std::size_t>(n);
    }
    const bool okay = ::fsync(fd) == 0 && ::close(fd) == 0;
    return okay;
}
[[nodiscard]] bool write_text(const std::filesystem::path& path, const std::string& text) {
    return write_exact(path, reinterpret_cast<const std::uint8_t*>(text.data()), text.size());
}
template <std::size_t N>
[[nodiscard]] bool write_array(const std::filesystem::path& path, const std::array<std::uint8_t,N>& value) {
    return write_exact(path, value.data(), value.size());
}
[[nodiscard]] bool fsync_directory(const std::filesystem::path& path) {
    const int fd = ::open(path.c_str(), O_RDONLY | O_DIRECTORY | O_CLOEXEC);
    if (fd < 0) return false;
    const bool okay = ::fsync(fd) == 0 && ::close(fd) == 0;
    return okay;
}

}  // namespace

bool run_campaign(const std::filesystem::path& output_directory) {
    std::error_code error;
    if (std::filesystem::exists(output_directory, error) || error) {
        std::cerr << "output root must be absent\n";
        return false;
    }
    if (!std::filesystem::create_directory(output_directory, error) || error) return false;

    const auto cases = corpus();
    std::set<std::string> unique_case_names;
    for (const auto& item : cases) {
        if (!unique_case_names.insert(item.name).second) {
            std::cerr << "duplicate case name=" << item.name << "\n";
            return false;
        }
    }
    std::size_t accepted = 0U;
    std::size_t rejected = 0U;
    std::size_t disagreements = 0U;
    std::ostringstream case_rows;
    case_rows << "case\texpected\tcandidate\treference\taccepted\tquery_only\tone_use_local\tglobal_one_use\texternal_operation\tauthority\n";
    std::ostringstream cut_rows;
    cut_rows << "case\tcut\tcut_name\tcandidate\treference\taccepted\tquery_only\tone_use_local\n";
    for (const auto& item : cases) {
        const Report candidate = evaluate_candidate(item.trace);
        const Report reference = evaluate_reference(item.trace);
        if (candidate != reference) {
            ++disagreements;
            std::cerr << "candidate/reference report disagreement case=" << item.name
                      << " candidate=" << code_name(candidate.code)
                      << " reference=" << code_name(reference.code) << "\n";
        }
        if (candidate.code != item.expected || reference.code != item.expected) {
            std::cerr << "unexpected case=" << item.name << " expected=" << code_name(item.expected)
                      << " candidate=" << code_name(candidate.code) << " reference=" << code_name(reference.code) << "\n";
            return false;
        }
        candidate.accepted ? ++accepted : ++rejected;
        case_rows << item.name << '\t' << code_name(item.expected) << '\t' << code_name(candidate.code) << '\t'
                  << code_name(reference.code) << '\t' << (candidate.accepted?1:0) << '\t'
                  << (candidate.query_only_required?1:0) << '\t' << (candidate.one_use_within_coherent_history?1:0)
                  << '\t' << (candidate.global_one_use_proved?1:0) << '\t' << (candidate.external_operation_proved?1:0)
                  << '\t' << (candidate.authority_granted?1:0) << '\n';
        for (std::size_t cut = 0U; cut < cut_count; ++cut) {
            Trace prefix = at_stage(item.trace, cut);
            const Report c = evaluate_candidate(prefix);
            const Report r = evaluate_reference(prefix);
            if (c != r) {
                ++disagreements;
                std::cerr << "candidate/reference cut disagreement case=" << item.name
                          << " cut=" << cut << " candidate=" << code_name(c.code)
                          << " reference=" << code_name(r.code) << "\n";
            }
            cut_rows << item.name << '\t' << cut << '\t' << cut_name(cut) << '\t' << code_name(c.code) << '\t'
                     << code_name(r.code) << '\t' << (c.accepted?1:0) << '\t' << (c.query_only_required?1:0)
                     << '\t' << (c.one_use_within_coherent_history?1:0) << '\n';
        }
    }
    if (disagreements != 0U) {
        std::cerr << "candidate/reference disagreements=" << disagreements << "\n";
        return false;
    }

    const Trace good = baseline();
    LedgerState empty{};
    empty.head = good.request.expected_predecessor_head;
    empty.generation = good.request.expected_generation;
    const Attempt first_c = attempt_candidate(empty, good, true);
    const Attempt first_r = attempt_reference(empty, good, true);
    if (first_c != first_r || first_c.outcome != Outcome::applied || !first_c.plan_valid || !first_c.state_changed
        || first_c.commit_digest != good.commit.commit_digest
        || first_c.successor_head != good.commit.successor_head
        || first_c.terminal_receipt != good.terminal.receipt_digest
        || first_c.successor_generation != good.commit.successor_generation
        || first_c.commit_revision != good.commit.commit_revision) {
        std::cerr << "first_apply composition check failed\n"; return false;
    }
    LedgerState spent{};
    spent.head = first_c.successor_head;
    spent.spent_response = good.request.response_digest;
    spent.applied_request = good.request.request_digest;
    spent.applied_commit = first_c.commit_digest;
    spent.spent_successor_head = first_c.successor_head;
    spent.terminal_receipt = first_c.terminal_receipt;
    spent.generation = first_c.successor_generation;
    spent.spent_successor_generation = first_c.successor_generation;
    spent.spent_commit_revision = first_c.commit_revision;
    spent.response_spent = true;
    const Attempt retry_c = attempt_candidate(spent, good, true);
    const Attempt retry_r = attempt_reference(spent, good, true);
    if (retry_c != retry_r || retry_c.outcome != Outcome::already_applied || !retry_c.retry_equivalent
        || !retry_c.exact_receipt_match || !retry_c.exact_state_match
        || retry_c.successor_head != good.commit.successor_head
        || retry_c.successor_generation != good.commit.successor_generation
        || retry_c.commit_revision != good.commit.commit_revision) {
        std::cerr << "exact_retry check failed\n"; return false;
    }
    const Attempt retry_expired_c = attempt_candidate(spent, good, false);
    const Attempt retry_expired_r = attempt_reference(spent, good, false);
    if (retry_expired_c != retry_expired_r || retry_expired_c.outcome != Outcome::already_applied
        || !retry_expired_c.terminal_fact_precedes_currentness || !retry_expired_c.exact_state_match
        || retry_expired_c.state_changed) {
        std::cerr << "terminal replay after currentness expiry failed\n"; return false;
    }
    Trace foreign = good;
    foreign.request.operation_id = text_digest("one-use-operation:foreign-request");
    foreign.request.request_payload_digest = text_digest("consume-payload:foreign");
    refresh_from_parent(foreign);
    const Attempt foreign_c = attempt_candidate(spent, foreign, true);
    const Attempt foreign_r = attempt_reference(spent, foreign, true);
    if (foreign_c != foreign_r || foreign_c.outcome != Outcome::response_spent || !foreign_c.plan_valid
        || !foreign_c.terminal_fact_precedes_currentness) { std::cerr << "foreign_request check failed\n"; return false; }
    const Attempt foreign_expired_c = attempt_candidate(spent, foreign, false);
    const Attempt foreign_expired_r = attempt_reference(spent, foreign, false);
    if (foreign_expired_c != foreign_expired_r || foreign_expired_c.outcome != Outcome::response_spent
        || !foreign_expired_c.terminal_fact_precedes_currentness) { std::cerr << "spent fact after currentness expiry failed\n"; return false; }
    LedgerState wrong = empty; wrong.head = text_digest("wrong-head");
    const Attempt wrong_c = attempt_candidate(wrong, good, true);
    const Attempt wrong_r = attempt_reference(wrong, good, true);
    if (wrong_c != wrong_r || wrong_c.outcome != Outcome::predecessor_conflict || !wrong_c.plan_valid) { std::cerr << "predecessor_conflict check failed\n"; return false; }
    const Attempt stale_c = attempt_candidate(empty, good, false);
    const Attempt stale_r = attempt_reference(empty, good, false);
    if (stale_c != stale_r || stale_c.outcome != Outcome::stale_currentness || !stale_c.plan_valid) { std::cerr << "stale_currentness check failed\n"; return false; }
    const Attempt clone_a_c = attempt_candidate(empty, good, true);
    const Attempt clone_a_r = attempt_reference(empty, good, true);
    const Attempt clone_b_c = attempt_candidate(empty, good, true);
    const Attempt clone_b_r = attempt_reference(empty, good, true);
    if (clone_a_c != clone_a_r || clone_b_c != clone_b_r || clone_a_c.outcome != Outcome::applied || clone_b_c.outcome != Outcome::applied) {
        std::cerr << "clone countermodel check failed\n"; return false;
    }
    Trace forged = good;
    forged.request.request_payload_digest = tamper(forged.request.request_payload_digest);
    const Attempt forged_c = attempt_candidate(spent, forged, true);
    const Attempt forged_r = attempt_reference(spent, forged, true);
    if (forged_c != forged_r || forged_c.outcome != Outcome::fail_stop || forged_c.plan_valid) {
        std::cerr << "digest-field substitution check failed\n"; return false;
    }
    LedgerState mismatched_receipt = spent;
    mismatched_receipt.terminal_receipt = tamper(mismatched_receipt.terminal_receipt);
    const Attempt receipt_mismatch_c = attempt_candidate(mismatched_receipt, good, true);
    const Attempt receipt_mismatch_r = attempt_reference(mismatched_receipt, good, true);
    if (receipt_mismatch_c != receipt_mismatch_r || receipt_mismatch_c.outcome != Outcome::fail_stop
        || !receipt_mismatch_c.plan_valid || receipt_mismatch_c.exact_receipt_match) {
        std::cerr << "receipt mismatch check failed\n"; return false;
    }
    LedgerState mismatched_head = spent;
    mismatched_head.spent_successor_head = tamper(mismatched_head.spent_successor_head);
    mismatched_head.head = mismatched_head.spent_successor_head;
    const Attempt head_mismatch_c = attempt_candidate(mismatched_head, good, true);
    const Attempt head_mismatch_r = attempt_reference(mismatched_head, good, true);
    if (head_mismatch_c != head_mismatch_r || head_mismatch_c.outcome != Outcome::fail_stop) {
        std::cerr << "spent successor head mismatch check failed\n"; return false;
    }
    LedgerState mismatched_generation = spent;
    ++mismatched_generation.spent_successor_generation;
    mismatched_generation.generation = mismatched_generation.spent_successor_generation;
    const Attempt generation_mismatch_c = attempt_candidate(mismatched_generation, good, true);
    const Attempt generation_mismatch_r = attempt_reference(mismatched_generation, good, true);
    if (generation_mismatch_c != generation_mismatch_r || generation_mismatch_c.outcome != Outcome::fail_stop) {
        std::cerr << "spent successor generation mismatch check failed\n"; return false;
    }
    LedgerState mismatched_commit = spent;
    mismatched_commit.applied_commit = tamper(mismatched_commit.applied_commit);
    const Attempt commit_mismatch_c = attempt_candidate(mismatched_commit, good, true);
    const Attempt commit_mismatch_r = attempt_reference(mismatched_commit, good, true);
    if (commit_mismatch_c != commit_mismatch_r || commit_mismatch_c.outcome != Outcome::fail_stop) {
        std::cerr << "spent commit mismatch check failed\n"; return false;
    }
    LedgerState mismatched_revision = spent;
    ++mismatched_revision.spent_commit_revision;
    const Attempt revision_mismatch_c = attempt_candidate(mismatched_revision, good, true);
    const Attempt revision_mismatch_r = attempt_reference(mismatched_revision, good, true);
    if (revision_mismatch_c != revision_mismatch_r || revision_mismatch_c.outcome != Outcome::fail_stop) {
        std::cerr << "spent revision mismatch check failed\n"; return false;
    }
    LedgerState residual_unspent = empty;
    residual_unspent.terminal_receipt = good.terminal.receipt_digest;
    const Attempt residual_c = attempt_candidate(residual_unspent, good, true);
    const Attempt residual_r = attempt_reference(residual_unspent, good, true);
    if (residual_c != residual_r || residual_c.outcome != Outcome::fail_stop) {
        std::cerr << "unspent residual state check failed\n"; return false;
    }

    std::ostringstream contention;
    contention << "scenario\tcandidate\treference\tplan_valid\tstate_changed\tretry_equivalent\texact_receipt_match\texact_state_match\tterminal_fact_precedes_currentness\tglobal_one_use_proved\n";
    const auto row = [&](const std::string_view name, const Attempt& c, const Attempt& r, const bool global) {
        contention << name << '\t' << outcome_name(c.outcome) << '\t' << outcome_name(r.outcome) << '\t'
                   << (c.plan_valid?1:0) << '\t' << (c.state_changed?1:0) << '\t' << (c.retry_equivalent?1:0)
                   << '\t' << (c.exact_receipt_match?1:0) << '\t' << (c.exact_state_match?1:0)
                   << '\t' << (c.terminal_fact_precedes_currentness?1:0) << '\t' << (global?1:0) << '\n';
    };
    row("first_apply", first_c, first_r, false);
    row("exact_retry", retry_c, retry_r, false);
    row("exact_retry_after_currentness_expiry", retry_expired_c, retry_expired_r, false);
    row("different_request_same_response", foreign_c, foreign_r, false);
    row("spent_response_after_currentness_expiry", foreign_expired_c, foreign_expired_r, false);
    row("predecessor_conflict", wrong_c, wrong_r, false);
    row("stale_currentness_before_first_effect", stale_c, stale_r, false);
    row("clone_a_before_use", clone_a_c, clone_a_r, false);
    row("clone_b_before_use", clone_b_c, clone_b_r, false);
    row("digest_field_reuse_after_payload_mutation", forged_c, forged_r, false);
    row("same_request_wrong_terminal_receipt", receipt_mismatch_c, receipt_mismatch_r, false);
    row("same_request_wrong_successor_head", head_mismatch_c, head_mismatch_r, false);
    row("same_request_wrong_successor_generation", generation_mismatch_c, generation_mismatch_r, false);
    row("same_request_wrong_commit", commit_mismatch_c, commit_mismatch_r, false);
    row("same_request_wrong_commit_revision", revision_mismatch_c, revision_mismatch_r, false);
    row("unspent_row_with_residual_receipt", residual_c, residual_r, false);

    const Trace pending = at_stage(good,3U);
    const Report pending_report = evaluate_candidate(pending);
    if (!pending_report.accepted || pending_report.code != Code::accepted_pending_query_only || !pending_report.query_only_required) {
        std::cerr << "pending query-only check failed code=" << code_name(pending_report.code) << "\n"; return false;
    }
    const Trace observed_absence = at_stage(good,4U);
    const Report observed_absence_report = evaluate_candidate(observed_absence);
    if (!observed_absence_report.accepted || observed_absence_report.code != Code::accepted_absent_query_durable
        || !observed_absence_report.query_valid || !observed_absence_report.query_only_required) {
        std::cerr << "durable absence-query check failed code=" << code_name(observed_absence_report.code) << "\n"; return false;
    }

    EncodedParentBinding parent_bytes{}; EncodedAppraisalCarrier appraisal_bytes{};
    EncodedConsumeRequest request_bytes{}; EncodedInvocation invocation_data{};
    EncodedQueryObservation query_bytes{}; EncodedJournalCommit commit_bytes{};
    EncodedTerminalReceipt terminal_bytes{}; EncodedReopenReceipt reopen_bytes{};
    const bool parent_encoded = encode_parent_binding(good.parent, parent_bytes);
    const bool appraisal_encoded = encode_appraisal_carrier(good.appraisal, appraisal_bytes);
    const bool request_encoded = encode_consume_request(good.request, request_bytes);
    const bool invocation_encoded = encode_invocation(good.invocation, invocation_data);
    const bool query_encoded = encode_query_observation(good.query, query_bytes);
    const bool commit_encoded = encode_journal_commit(good.commit, commit_bytes);
    const bool terminal_encoded = encode_terminal_receipt(good.terminal, terminal_bytes);
    const bool reopen_encoded = encode_reopen_receipt(good.reopen, reopen_bytes);
    if (!parent_encoded || !appraisal_encoded || !request_encoded || !invocation_encoded
        || !query_encoded || !commit_encoded || !terminal_encoded || !reopen_encoded) {
        std::cerr << "canonical encoding failed parent=" << parent_encoded
                  << " appraisal=" << appraisal_encoded << " request=" << request_encoded
                  << " invocation=" << invocation_encoded << " query=" << query_encoded
                  << " commit=" << commit_encoded
                  << " terminal=" << terminal_encoded << " reopen=" << reopen_encoded << "\n";
        return false;
    }

    std::ostringstream identities;
    identities << "object\tbytes\tidentity\n"
               << "PARENT-APERTURE-BINDING.bin\t" << parent_bytes.size() << '\t' << hex(good.parent.binding_digest) << '\n'
               << "CURRENT-APPRAISAL-CARRIER.bin\t" << appraisal_bytes.size() << '\t' << hex(good.appraisal.carrier_digest) << '\n'
               << "CONSUME-REQUEST.bin\t" << request_bytes.size() << '\t' << hex(good.request.request_digest) << '\n'
               << "PENDING-INVOCATION.bin\t" << invocation_data.size() << '\t' << hex(good.invocation.invocation_digest) << '\n'
               << "QUERY-OBSERVATION.bin\t" << query_bytes.size() << '\t' << hex(good.query.observation_digest) << '\n'
               << "JOURNAL-COMMIT.bin\t" << commit_bytes.size() << '\t' << hex(good.commit.commit_digest) << '\n'
               << "TERMINAL-RECEIPT.bin\t" << terminal_bytes.size() << '\t' << hex(good.terminal.receipt_digest) << '\n'
               << "REOPEN-RECEIPT.bin\t" << reopen_bytes.size() << '\t' << hex(good.reopen.receipt_digest) << '\n';

    const std::string laws =
        "law\tstatement\n"
        "L01\tOne-use is conditional on one coherent compare-and-append history.\n"
        "L02\tThe exact parent aperture output set and composition receipt enter the child binding.\n"
        "L03\tThe request binds response, appraisal, predecessor head, generation, namespace, operation, and payload.\n"
        "L04\tThe first matching request may append one applied commit.\n"
        "L05\tAn exact retry returns the exact terminal receipt and does not append again.\n"
        "L06\tA different request for the same response is rejected as spent.\n"
        "L07\tA predecessor or generation mismatch is a conflict, not a repair invitation.\n"
        "L08\tLoss of an invocation response enters query-only recovery.\n"
        "L09\tAn exact durable absent-query observation is bound to invocation, request, operation, expected and observed head, generation, policy, exact observer role, appraisal window, time, and revision; it remains model-only and nonterminal.\n"
        "L10\tA version-41 appraisal cannot authorize consumption after root 42 becomes current.\n"
        "L11\tThe modeled commit does not prove an external provider operated it.\n"
        "L12\tExact reopener code identity does not prove administrative independence.\n"
        "L13\tClone-before-use permits one local apply in each clone; global one-use remains false.\n"
        "L14\tA receipt is evidence of the modeled history, not owner admission or authority.\n"
        "L15\tThe contention transition returns the exact canonical commit successor and terminal receipt; no parallel receipt subject is accepted.\n"
        "L16\tA request digest field is not enough: the complete request and downstream plan are revalidated before replay classification.\n"
        "L17\tA witnessless absence Boolean cannot authorize later reasoning; the exact query observation is a first-class durable object and enters the commit subject.\n"
        "L18\tExact query bytes do not prove a provider-linearizable read or terminal no-effect.\n"
        "L19\tA terminal spent fact is classified before currentness: appraisal expiry can block a new effect but cannot erase ALREADY_APPLIED or RESPONSE_SPENT.\n"
        "L20\tExact retry requires one coherent spent-state witness binding request, response, commit, successor head, successor generation, commit revision, and terminal receipt.\n"
        "L21\tGenerated interpreter bytecode is excluded from the exact source closure; only authored source and declared carriers may enter source identity.\n";
    const std::string countermodels =
        "countermodel\tobservation\tmissing_fact\n"
        "C01\tTwo pre-spend clones each accept the exact same request once.\tExternal nonrestorable spend floor\n"
        "C02\tA pending invocation is queried absent and commits later.\tTerminal negative fence\n"
        "C03\tThe same idempotency key is reused with a different payload.\tExact request fingerprint binding\n"
        "C04\tA valid version-41 appraisal is replayed after version 42 becomes current.\tFresh current appraisal\n"
        "C05\tA local terminal receipt is copied to another same-root reopener.\tAdministrative independence\n"
        "C06\tA compare-and-append model is treated as proof that etcd or another provider ran.\tExternal occurrence\n"
        "C07\tA serializable stale read is treated as the current head.\tLinearizable current observation\n"
        "C08\tA finite idempotency-retention window expires before the reopen horizon.\tTerminal continuity\n"
        "C09\tA caller reuses the prior digest field after mutating request payload bytes.\tCanonical subject revalidation\n"
        "C10\tA local spend row retains the request digest but loses or substitutes the exact terminal receipt.\tExact retry receipt continuity\n"
        "C11\tA Boolean says absent while carrying no query subject, revision, head, generation, exact role, policy, or appraisal window.\tExact durable query observation\n"
        "C12\tExact hosted query bytes are treated as proof of a provider-linearizable read.\tExternal occurrence and control-plane appraisal\n"
        "C13\tAn exact prior receipt is presented beside a substituted successor head, generation, commit, or revision.\tCoherent spent-state witness\n"
        "C14\tAppraisal expiry is checked before an already-durable spend row, hiding the exact prior terminal result.\tTerminal-fact precedence over new-effect currentness\n"
        "C15\tGenerated Python bytecode is admitted as source identity.\tAuthored-source closure and interpreter-independent rebuild\n";

    std::ostringstream summary;
    summary << "metric\tvalue\n"
            << "cases\t" << cases.size() << '\n'
            << "accepted\t" << accepted << '\n'
            << "rejected\t" << rejected << '\n'
            << "lifecycle_cuts\t" << cases.size()*cut_count << '\n'
            << "durable_stages\t" << cut_count << '\n'
            << "candidate_reference_disagreements\t0\n"
            << "canonical_objects\t8\n"
            << "canonical_exact_object_bytes\t" << canonical_exact_object_bytes << '\n'
            << "contention_rows\t16\n"
            << "canonical_transition_composed\ttrue\n"
            << "request_subject_revalidated\ttrue\n"
            << "exact_query_observation_bound\ttrue\n"
            << "exact_query_observer_role_bound\ttrue\n"
            << "terminal_no_effect_from_absence\tfalse\n"
            << "terminal_fact_precedes_currentness\ttrue\n"
            << "exact_retry_state_bound\ttrue\n"
            << "generated_bytecode_in_source_closure\tfalse\n"
            << "external_linearizable_read_proved\tfalse\n"
            << "one_use_within_coherent_history\ttrue\n"
            << "global_one_use_proved\tfalse\n"
            << "external_operation_proved\tfalse\n"
            << "owner_admission\tfalse\n"
            << "authority\tfalse\n"
            << "epoch_exit\tfalse\n";
    std::ostringstream report;
    report << "ONE_USE_RESPONSE_CONSUMPTION_CAMPAIGN=PASS cases=" << cases.size()
           << " accepted=" << accepted << " rejected=" << rejected
           << " cuts=" << cases.size()*cut_count << " stages=" << cut_count
           << " contention=16 exact_objects=" << canonical_exact_object_bytes
           << " composed_transition=true request_revalidated=true exact_query=true exact_query_role=true terminal_precedence=true exact_retry_state=true"
           << " local_one_use=true global_one_use=false query_only=true external_operation=false authority=false\n";

    const bool written =
        write_array(output_directory/"PARENT-APERTURE-BINDING.bin",parent_bytes)
        && write_array(output_directory/"CURRENT-APPRAISAL-CARRIER.bin",appraisal_bytes)
        && write_array(output_directory/"CONSUME-REQUEST.bin",request_bytes)
        && write_array(output_directory/"PENDING-INVOCATION.bin",invocation_data)
        && write_array(output_directory/"QUERY-OBSERVATION.bin",query_bytes)
        && write_array(output_directory/"JOURNAL-COMMIT.bin",commit_bytes)
        && write_array(output_directory/"TERMINAL-RECEIPT.bin",terminal_bytes)
        && write_array(output_directory/"REOPEN-RECEIPT.bin",reopen_bytes)
        && write_text(output_directory/"CASES.tsv",case_rows.str())
        && write_text(output_directory/"CUTS.tsv",cut_rows.str())
        && write_text(output_directory/"CONTENTION.tsv",contention.str())
        && write_text(output_directory/"IDENTITIES.tsv",identities.str())
        && write_text(output_directory/"LAWS.tsv",laws)
        && write_text(output_directory/"COUNTERMODELS.tsv",countermodels)
        && write_text(output_directory/"SUMMARY.tsv",summary.str())
        && write_text(output_directory/"REPORT.txt",report.str());
    if (!written || !fsync_directory(output_directory)) return false;
    std::cout << report.str();
    return true;
}

}  // namespace slopos::e0::detached_response_aperture::one_use_response_consumption
