# Signed-admission evidence capsule

This C++20 construction is nested beneath the frozen transaction dossier inside
`CANDIDATE/generation_journal`. It does not add a semantic island, daemon,
network client, authority API, key-generation API, or living-project release.

The capsule verifies real Ed25519 signatures with OpenSSL's one-shot EVP
interface over one fixed 552-byte pre-authentication message. It binds a
canonical 384-byte manifest, a canonical 512-byte admission statement, and a
canonical 1,024-byte multi-signature envelope to the exact R1-R6 transaction
dossier. Candidate and separately spelled C++ relations are compared against an
independent Python/`cryptography` implementation over a finite substitution and
replay corpus.

The narrow success vocabulary is `evidence_valid`. It means only that:

- the supplied self-describing manifest is canonical;
- the exact statement is within its encoded time window;
- the statement binds the exact hosted dossier and selected profile;
- distinct listed keys produced enough valid Ed25519 signatures.

Every success still reports:

- `owner_constitution_proved=false`;
- `currentness_proved=false`;
- `global_one_use_proved=false`;
- `epoch_exit_proved=false`;
- `authority_granted=false`.

A retained positive countermodel is signed by a coherent attacker-created
2-of-3 manifest. It verifies fully. That result is deliberate: signatures prove
relative possession under the supplied manifest, not that SlopOS owners
constituted that manifest. A second countermodel validates two byte-identical
restored copies, showing that signatures do not create a global one-use fact.

Build in a writable worktree:

```sh
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build
./build/slopos_signed_admission campaign /tmp/slopos-signed-admission
python3 -B proof/verify_admission.py /tmp/slopos-signed-admission
```

Private fixture seeds exist only in `harness/campaign.cpp`. The public library
exposes verification, codecs, and exact digest relations; it exposes no signer,
private-key import, key generation, owner enrollment, or permission-mint path.

## Nested root-succession edge

Revision 0914 adds a second executable below this capsule rather than a fourth
repository island. `slopos_root_succession` validates one exact adjacent
owner-manifest edge and rehearses a local compare-and-apply register:

```sh
cmake --build build --target slopos_root_succession
./build/slopos_root_succession campaign /tmp/slopos-root-succession
python3 -B proof/verify_root_succession.py /tmp/slopos-root-succession
```

The edge is admissible only when the successor is exactly version `N+1`, names
the exact predecessor manifest head, equals a precommitted successor head, and
is signed to threshold under both the predecessor and successor manifests.
Candidate and independently spelled C++ relations agree with the independent
Python byte parser and Ed25519 verifier over 28 cases.

The register is intentionally a hosted in-memory model. It demonstrates local
compare-and-apply, idempotent query-only recovery, and reply-loss uncertainty.
It does **not** demonstrate a protected non-cloned register, owner-delivered
initial root, independent key custody, global currentness, independent reopen,
or authority. Three identical register copies are retained as a constructive
countermodel: two accept the same transition while a third remains at the old
root. Thus `evidence_valid` and even `committed` are local facts only.
