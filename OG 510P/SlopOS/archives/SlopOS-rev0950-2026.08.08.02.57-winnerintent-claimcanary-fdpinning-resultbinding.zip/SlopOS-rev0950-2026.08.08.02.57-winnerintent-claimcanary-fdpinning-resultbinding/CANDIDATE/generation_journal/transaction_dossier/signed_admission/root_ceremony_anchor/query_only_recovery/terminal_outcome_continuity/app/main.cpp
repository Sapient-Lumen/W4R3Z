
#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity.hpp"

#include <filesystem>
#include <iostream>

int main(const int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "usage: slopos_terminal_outcome_continuity OUTPUT_DIRECTORY\n";
        return 2;
    }
    const std::filesystem::path output(argv[1]);
    if (!slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::run_campaign(output)) {
        std::cerr << "TERMINAL_OUTCOME_CONTINUITY_CAMPAIGN=FAIL\n";
        return 1;
    }
    std::cout
        << "TERMINAL_OUTCOME_CONTINUITY_CAMPAIGN=PASS cases=52 accepted=19 rejected=33 "
        << "continuity=9 execution_only=4 history_only=3 neither=2 fail_stop=1 "
        << "reclamation_safe=4 disagreements=0 authority=false\n";
    return 0;
}
