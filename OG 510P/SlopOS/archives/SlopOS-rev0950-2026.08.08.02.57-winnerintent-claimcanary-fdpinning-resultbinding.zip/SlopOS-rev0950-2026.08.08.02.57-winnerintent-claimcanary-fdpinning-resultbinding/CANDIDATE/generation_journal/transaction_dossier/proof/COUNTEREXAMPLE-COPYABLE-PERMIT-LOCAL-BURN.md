# Counterexample — copyable permit plus local burn is not global one-use

Take a valid permit byte string `P` and a local state image `S` in which `P` is
unused. Clone `(P,S)` into histories A and B before either history mutates its
local image. If acceptance is a deterministic function only of `P` and the
clone-local state, A and B see the same accepting inputs. Each can mark its own
copy spent and dispatch once. The global execution has two accepts even though
each local history records one.

A move-only C++ wrapper starts after bytes have entered one process and therefore
cannot rule out the precondition. A signature authenticates a statement but does
not serialize its use. A nonce or expiry bounds replay space or time but does
not make two simultaneous clones disagree. A local unique database row works
only while all contenders share one non-restored serialized database history.

The campaign retains three model outcomes:

- clone-local burn: two accepts;
- one shared atomic spend set: one accept;
- two restored copies of that spend set: two accepts.

This is a countermodel, not proof of a protected provider. The theorem and the
required escape mechanisms are in `DESIGN/ONE-USE-AUTHORITY-THEOREM.md`.
