
# Terminal Outcome Continuity V1

## Status and boundary

This is an Epoch-Zero hosted relation below Query-Only Recovery V1. It does not
operate retention, garbage collection, restoration, succession, provider
identity, or external authority. It replaces no inherited rule and creates no
new semantic island.

## Problem

A single predicate such as `retention_covers_reopen` hides two logically
independent questions:

- **Can the exact old or pending request still execute?**
- **Can a future independent reopener recover the exact terminal outcome?**

A terminal claim that survives only one question is unsafe. A successor epoch
can reject old writes while forgetting whether the old request produced an
effect. An archive can remember the old result while a restored incarnation
still accepts the old request. The state space therefore has four quadrants,
only one of which is terminally continuous.

## State law

For exact request `R`, transition `T`, register incarnation `I`, terminal kind
`K`, and terminal digest `D`:

```text
DuplicateExcluded := RecordExecutionPath OR SuccessorFloorExecutionPath
OutcomeReopenable := RecordHistoryPath OR TerminalWitnessHistoryPath
TerminalContinuity := DuplicateExcluded AND OutcomeReopenable
ReclamationSafe := ReclamationRequested
                   AND SuccessorFloorExecutionPath
                   AND TerminalWitnessHistoryPath
```

`ReclamationSafe` deliberately does not follow from a live record alone. A live
record proves continuity while it remains live; deleting it requires an
independent witness and an execution fence that remain valid after deletion.

## Live terminal record paths

The record may supply execution exclusion only when it is exact,
authenticated, durable, serialized with the effect/retirement decision,
non-equivocal, retained through the full admitted horizon, fences pending
invocations, and survives restore and succession.

The same record may supply history only when the common premises hold and a
separately governed reopener can reconstruct it. Constructor self-reopen is not
independent reopen.

## Reclamation/succession paths

A retained terminal witness supplies history only when it is exact,
authenticated, durable, bound to the terminal kind and digest, independently
reopenable, and preserved through restore and succession.

A successor floor supplies execution exclusion only when it is authenticated,
monotone, outside the rollback domain, bound to the request namespace, rejects
the old incarnation, fences already-pending invocations, survives restore and
later succession, and has one current non-equivocal view.

A generation number stored beside the data it is intended to fence is not
outside the rollback domain. A floor that rejects later submissions but leaves
an already-pending request alive is not an execution fence. A receipt that says
“old epoch rejected” without the exact terminal outcome is not history.

## Explicit nonproofs

The following never establish either half by themselves:

- elapsed TTL or duplicate-record expiry;
- client acknowledgement, timeout, cancellation, or abandonment;
- deletion of a request row;
- a new deployment name or process ID;
- a successor label under the same snapshot/restore root;
- an archive lacking exact terminal binding;
- a terminal witness controlled only by the constructor; or
- compiler agreement over hosted fixtures.

## Fail-stop rule

Any equivocation about terminal outcome, successor floor, or governing view
fails stop. The relation does not choose a favored history and does not turn a
missing record into `NO_EFFECT`.

## Epoch rule

The finite relation proves vocabulary and countermodels only. Until actual
owners operate the exact witness, floor, restore, succession, custody, and
independent-reopen premises, SlopOS remains Epoch Zero and query-only wherever
terminal continuity is absent.
