# External Premise Admission Theorem

Let `R` be an accepted Reopen Receipt Chain trace at the ready-live prefix. Let `C, M, T, S, F, A, O` denote a constitution, mechanism annex, ratification, separation matrix, operated corpus, appraisal, and owner admission. Let `K0…K9` be the durable cuts.

The hosted evaluator may return `accepted_external_premises_ready_live_retained` only when:

- `R` is the exact accepted ready-live parent and its authorization/target identities are preserved;
- `C` is authenticated, threshold-satisfied, externally bootstrapped, current-root selected, rollback-external, durable, single-view, independently reopenable, and not self-nominated;
- `M` is a complete closed profile bound to `C` and `R`, but is not self-ratifying;
- `T` is an owner-issued current-root receipt over `M`, durably published and independently reopened;
- `S` proves distinct administrative and rollback roots rather than distinct labels alone;
- `F` records the full required scenario mask against the exact implementation and configuration, with raw independently locatable replay material from a separate disposable target;
- `A` is source-closed, producer-independent, authenticated, durably published, replayed, passing, and independently reopened;
- `O` is a separately governed threshold decision consuming the exact `T`, `A`, parent authorization, and target; and
- the ten visibility states are monotone, prefix-closed, and introduce at most one new phase per cut while the live record remains visible; and no unbound downstream production phase participates in readiness.

Then the report may mark the **hosted premise dossier** ready. It still cannot mark external occurrence, owner constitution, currentness, independent custody, mechanism operation, Epoch exit, or authority as proved.

### Countertheorem

Final possession of a profile, a receipt, a corpus, and an owner-shaped decision does not establish their external provenance or predecessor order. A candidate can synthesize all four, choose its own root, split views between consumers, run the corpus under different bytes, or collapse publication and consumption into one cut. Therefore premise provenance must be an explicit relation and cannot remain an unexamined Boolean on the authority path.
