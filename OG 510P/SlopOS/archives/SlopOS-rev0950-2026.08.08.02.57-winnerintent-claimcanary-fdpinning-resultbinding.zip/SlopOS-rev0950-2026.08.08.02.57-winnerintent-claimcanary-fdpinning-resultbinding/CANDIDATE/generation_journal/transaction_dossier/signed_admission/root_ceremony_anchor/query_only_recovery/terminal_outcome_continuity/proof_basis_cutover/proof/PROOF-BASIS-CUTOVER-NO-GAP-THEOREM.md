# Proof-basis cutover has no-gap and predecessor-order obligations

Let `L(c)` mean that the complete live terminal-record basis exists at crash cut
`c`. Let `W(c)` and `F(c)` mean that the exact terminal witness and successor
execution floor exist. Let `J(c)` mean that an authenticated durable receipt
joins `W` and `F` to the same exact request/history. Then replacement coverage
at `c` is `W(c) ∧ F(c) ∧ J(c)`.

A reclamation trace is continuous only if:

```text
for every admitted crash cut c:
    L(c) OR (W(c) AND F(c) AND J(c))
```

and the final joined basis survives independent reopen, restore, and
succession.

## Eventual conjunction does not imply continuous transfer

Delete `L` after exporting `W` but before installing `F`. Later install `F` and
write `J`. The final state satisfies `W ∧ F ∧ J`, but the intervening cut had no
execution fence. A pending old invocation could commit there. Therefore final
conjunction does not prove execution continuity.

Symmetrically, delete `L` after installing `F` but before exporting `W`. The
intervening cut has no exact outcome history. Later witness creation cannot
prove what an independent reopener could have reconstructed at that cut.

Finally, `W ∧ F` without `J` permits a split-history interpretation: the witness
may describe one branch while the floor closes another namespace or
incarnation. Two individually valid facts do not prove co-reference.

## State conjunction does not imply predecessor order

Even a row containing `J ∧ R ∧ A ∧ D` does not prove that the join (`J`) was
available to a replacement-only reopener (`R`), that the resulting observation
was available to the authorizer (`A`), or that durable authorization preceded
deletion (`D`). Without an imported atomic transaction, the least assumptive
relation requires each first observation to consume a predecessor durable at an
earlier crash cut:

```text
W,F  < J < R < A < D
```

Collapsing any adjacent pair into one cut is therefore refused. This is not a
claim that all implementations need four network round trips. It is a proof
boundary: an owner-selected mechanism may replace a pair of cuts only by
supplying a narrower atomicity theorem and crash evidence.

## Consequence

The live record is not garbage merely because replacement work has started. It
is the continuity bridge. It must remain until both replacement paths and their
same-history join are durable and a replacement-only cold reopener has actually
reconstructed them. Durable authorization follows that observation; deletion
follows authorization. A later repair cannot retroactively cover an earlier
crash or ordering gap.

## Conservation lemmas

1. **Request conservation.** The cutover cannot change whether reclamation was
   requested relative to the parent relation.
2. **Component-before-join.** A join cannot be observed before both objects it
   purports to join.
3. **Deletion observability.** Live-record absence without a recorded delete is a
   malformed trace, not proof that the ordered deletion protocol ran.
4. **Readiness observation.** Reopenability flags do not substitute for an
   observed replacement-only cold reopen before authorization.
5. **Predecessor durability.** Join, reopen, authorization, and deletion each
   require the immediately preceding proof fact at an earlier crash cut.
6. **No retrospective repair.** A later valid state cannot authorize an earlier
   irreversible transition.
