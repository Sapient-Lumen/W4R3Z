#pragma once

#include <array>
#include <cstdint>
#include <string_view>

namespace slopos::e0::observed_output_closure_generated {

struct ExpectedOutputEntry final {
    std::string_view path;
    std::string_view sha256;
    std::uint64_t bytes;
    std::uint16_t mode;
};

inline constexpr std::array<ExpectedOutputEntry, 15U> parent_output_entries{{
    {"BUILD-CLAIM.bin", "ed5ac4ddbc18a85e6d803ad55baf786c3a0d1b97f1fb0f7b34fd274e5a343469", 200U, 0444U},
    {"BUILD-PLAN.bin", "caf667cc6f907a4808a06f3f03334b3cee1f736f635baf61692ae71962da618d", 292U, 0444U},
    {"CASES.tsv", "cb5165526a863fb58d3d6ab921784ea170cd9c388b888c6be66259d5b8d59773", 10935U, 0444U},
    {"COUNTERMODELS.tsv", "2145c07c9a2c4227ecb40747b41c15f4c82e9d05cc404ea70002cda456f82949", 1040U, 0444U},
    {"CUTS.tsv", "59acdb4f8714c6047aaddcd4abf0115e014d8330f558dc86c1a4c6b8ce2df5aa", 3453U, 0444U},
    {"FIRST-REOPEN-RECEIPT.bin", "3e271fe204b6bc4f866b4a99b01a6f34914f46c4141fafb125adfa2ea0781ebf", 260U, 0444U},
    {"IDENTITIES.tsv", "0ffa2c35ffc288078f4d859a93153ce4ba9049108bb0f54535f31ddd8598d238", 546U, 0444U},
    {"LAWS.tsv", "ce7e2acac7df454a4e7fc2a6219d90fc05fc493ce8a51d59f600d6e95aa52562", 1324U, 0444U},
    {"PROVENANCE-CAPSULE.bin", "f23ff1020a7163dff62af73522c497182b5701e86b1b2ca6f07bd76ba159fcd8", 264U, 0444U},
    {"RELOCATED-REOPEN-RECEIPT.bin", "9ca8cab914f6ef3614c2315e659b16e5419485153fa4c7db2bfcfdf354d7b861", 260U, 0444U},
    {"RELOCATION-MATRIX.tsv", "e234b8ada8fdda0044e9b779a49abcc9376f2d8363e707b79475777a5c98d6b5", 8208U, 0444U},
    {"REPORT.txt", "05529d4dc66faf022a57a4867668d44c1e2e33f45e0fe1e0f0b6892b4081a38d", 441U, 0444U},
    {"SOURCE-CLOSURE.bin", "0b19f400030e71ffabd0d0aebadd89937b58aead02e3bf6903251dfcfad1610d", 904U, 0444U},
    {"SOURCE-ENTRIES.tsv", "1c109f7372865e5f1dbaa6b19cb35a9ba366802416d6f211ca84118318c754f2", 654U, 0444U},
    {"SUMMARY.tsv", "5769430b6445b81a29a2271b11836298be40ab585584c1a4589067543a701db2", 616U, 0444U},
}};

inline constexpr std::string_view reserved_prefix = "closure/";
inline constexpr std::string_view reserved_manifest = "OUTPUT-SET-MANIFEST.bin";
inline constexpr std::string_view reserved_publication = "MANIFEST-PUBLICATION-RECEIPT.bin";
inline constexpr std::string_view reserved_reopen = "OUTPUT-SET-REOPEN-RECEIPT.bin";
inline constexpr std::string_view reserved_claim = "OUTPUT-CLOSURE-CLAIM.bin";

}  // namespace slopos::e0::observed_output_closure_generated
