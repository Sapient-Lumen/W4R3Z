# Relocatable Provenance Closure V1

## Subject

The canonical subject is:

1. the exact accepted parent challenge receipt;
2. a logical root digest;
3. an ordered, duplicate-free set of portable root-relative source entries;
4. every entry's content digest, byte size, read-only mode, and regular-file kind;
5. a build plan binding build type, toolchain, flags, environment policy, dependency closure, output specification, deterministic input ordering, and network-input prohibition;
6. an expected output digest and claim policy;
7. exact build claims and two independently reopened receipt objects;
8. a seven-cut durable chronology in which the first receipt precedes the relocated claim.

The ambient extraction/build directory and raw build logs are excluded from the subject. They may be retained as noncanonical observations. The reference evaluator independently serializes every canonical subject object and independently validates portable paths rather than reusing the candidate encoder.

## Accepted classifications

- `accepted_relocated_exact_subject`: distinct physical locators, one exact canonical claim, one exact output, exact receipts, and ordered durable cuts.
- `accepted_same_locator_no_relocation_witness`: exact subject and output, but no distinct locator observation.
- safe refusals for open source closure, open build plan, locator-influenced output, or output divergence.

Malformed identities, bindings, paths, entries, receipts, and cuts fail closed. The first and relocated receipt bytes are retained separately; receipt durability may not be asserted only as an in-memory Boolean.

## Nonclaims

The relation never claims source authenticity, trusted-builder status, complete real-world inventory, external execution, transitive independence, authority, or Epoch-Zero exit. A path-normalized output is not by itself a reproducible build. A reproducible build is not by itself provenance or authority.


## Hosted composition binding

The focused builder computes one exact root-relative `SOURCE-MANIFEST.tsv` from the current source closure before configuring any lane. It also emits exact build-plan, output-contract, parent-binding, logical-root, and claim-policy carriers. Their SHA-256 identities and byte counts are compile-time inputs to the C++ campaign and become the six ordered `SourceClosure` entries. The retained `COMPOSITION-RECEIPT.json` independently binds those entries to the actual three-lane CAS output set. This repairs the earlier split in which Python receipts named real source bytes while the C++ relation named invented labels. It still does not prove that the declared manifest is world-complete, that all environment inputs are known, or that an external trusted builder ran.
