#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery.hpp"

#include <array>
#include <filesystem>
#include <fstream>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery {
namespace {

struct TestCase final {
    std::string_view name;
    RecoveryState state;
    RecoveryStep step;
    RecoveryCode expected;
};

[[nodiscard]] Digest digest(const std::uint8_t seed) {
    Digest value{};
    for (std::size_t index = 0U; index < value.size(); ++index) {
        value[index] = static_cast<std::uint8_t>(seed + static_cast<std::uint8_t>(index));
    }
    return value;
}

[[nodiscard]] RecoveryState state(const Phase phase) {
    return RecoveryState{phase, digest(0x10U), digest(0x40U), digest(0x70U)};
}

[[nodiscard]] RecoveryStep step(const Command command, const Observation observation) {
    return RecoveryStep{
        command,
        observation,
        digest(0x10U),
        digest(0x40U),
        digest(0x70U),
        true,
        true,
        true,
        true,
        true,
        true,
        true,
    };
}

[[nodiscard]] std::string truth(const bool value) {
    return value ? "true" : "false";
}

[[nodiscard]] bool write_text(const std::filesystem::path& path, const std::string& text) {
    std::ofstream stream(path, std::ios::binary | std::ios::trunc);
    stream.write(text.data(), static_cast<std::streamsize>(text.size()));
    return stream.good();
}

[[nodiscard]] std::vector<TestCase> cases() {
    std::vector<TestCase> values;
    const auto add = [&values](
        const std::string_view name,
        const RecoveryState& initial,
        const RecoveryStep& input,
        const RecoveryCode expected) {
        values.push_back(TestCase{name, initial, input, expected});
    };

    add("ready_commit_strong", state(Phase::ready), step(Command::submit_exact, Observation::commit_reply), RecoveryCode::accepted_submit_commit);
    add("ready_nonreturn_latches_query_only", state(Phase::ready), step(Command::submit_exact, Observation::no_reply), RecoveryCode::accepted_submit_uncertain);
    add("query_committed_strong", state(Phase::query_only), step(Command::query_exact, Observation::committed_record), RecoveryCode::accepted_query_commit);
    add("query_absent_is_unresolved", state(Phase::query_only), step(Command::query_exact, Observation::absent_record), RecoveryCode::accepted_query_absent_unresolved);
    add("query_retired_strong", state(Phase::query_only), step(Command::query_exact, Observation::retired_record), RecoveryCode::accepted_query_retired);
    add("query_unavailable_is_unresolved", state(Phase::query_only), step(Command::query_exact, Observation::unavailable), RecoveryCode::accepted_query_unavailable);
    add("query_wrong_incarnation_fail_stops", state(Phase::query_only), step(Command::query_exact, Observation::wrong_incarnation), RecoveryCode::accepted_query_wrong_incarnation_fail_stop);
    add("query_split_view_fail_stops", state(Phase::query_only), step(Command::query_exact, Observation::split_view), RecoveryCode::accepted_query_split_view_fail_stop);
    add("reopen_preserves_query_only", state(Phase::query_only), step(Command::reopen, Observation::reopen_event), RecoveryCode::accepted_reopen_query_only);
    add("reopen_preserves_terminal_effect", state(Phase::terminal_effect), step(Command::reopen, Observation::reopen_event), RecoveryCode::accepted_reopen_terminal_effect);
    add("reopen_preserves_terminal_no_effect", state(Phase::terminal_no_effect), step(Command::reopen, Observation::reopen_event), RecoveryCode::accepted_reopen_terminal_no_effect);
    add("reopen_preserves_fail_stop", state(Phase::fail_stopped), step(Command::reopen, Observation::reopen_event), RecoveryCode::accepted_reopen_fail_stop);

    {
        auto input = step(Command::submit_exact, Observation::commit_reply);
        input.request_id = digest(0x11U);
        add("ready_wrong_request_id", state(Phase::ready), input, RecoveryCode::request_id_mismatch);
    }
    {
        auto input = step(Command::submit_exact, Observation::commit_reply);
        input.transition_digest = digest(0x41U);
        add("ready_wrong_transition_digest", state(Phase::ready), input, RecoveryCode::transition_digest_mismatch);
    }
    {
        auto input = step(Command::submit_exact, Observation::commit_reply);
        input.register_incarnation = digest(0x71U);
        add("ready_wrong_register_incarnation", state(Phase::ready), input, RecoveryCode::register_incarnation_mismatch);
    }
    add("ready_query_forbidden", state(Phase::ready), step(Command::query_exact, Observation::committed_record), RecoveryCode::invalid_command_for_phase);
    add("ready_local_no_effect_forbidden", state(Phase::ready), step(Command::declare_no_effect, Observation::absent_record), RecoveryCode::invalid_command_for_phase);
    {
        auto input = step(Command::submit_exact, Observation::commit_reply);
        input.authenticated = false;
        add("ready_commit_unauthenticated", state(Phase::ready), input, RecoveryCode::authentication_required);
    }
    {
        auto input = step(Command::submit_exact, Observation::commit_reply);
        input.linearizable = false;
        add("ready_commit_nonlinearizable", state(Phase::ready), input, RecoveryCode::linearizable_observation_required);
    }
    {
        auto input = step(Command::submit_exact, Observation::commit_reply);
        input.single_view = false;
        add("ready_commit_split_view", state(Phase::ready), input, RecoveryCode::single_view_required);
    }
    {
        auto input = step(Command::submit_exact, Observation::commit_reply);
        input.durable_result = false;
        add("ready_commit_not_durable", state(Phase::ready), input, RecoveryCode::durable_result_required);
    }
    {
        auto input = step(Command::submit_exact, Observation::commit_reply);
        input.retention_covers_reopen = false;
        add("ready_commit_short_retention", state(Phase::ready), input, RecoveryCode::retention_horizon_required);
    }
    add("ready_submit_absent_invalid", state(Phase::ready), step(Command::submit_exact, Observation::absent_record), RecoveryCode::invalid_observation_for_command);
    add("query_resubmit_exact_latched", state(Phase::query_only), step(Command::submit_exact, Observation::no_reply), RecoveryCode::query_only_latched);
    {
        auto input = step(Command::submit_exact, Observation::no_reply);
        input.request_id = digest(0x12U);
        add("query_new_request_id_rejected", state(Phase::query_only), input, RecoveryCode::request_id_mismatch);
    }
    add("query_clear_latch_rejected", state(Phase::query_only), step(Command::clear_latch, Observation::none), RecoveryCode::query_only_latched);
    add("query_repair_rejected", state(Phase::query_only), step(Command::repair, Observation::none), RecoveryCode::query_only_latched);
    add("query_absence_cannot_declare_no_effect", state(Phase::query_only), step(Command::declare_no_effect, Observation::absent_record), RecoveryCode::absence_not_terminal);
    {
        auto input = step(Command::query_exact, Observation::committed_record);
        input.authenticated = false;
        add("query_commit_unauthenticated", state(Phase::query_only), input, RecoveryCode::authentication_required);
    }
    {
        auto input = step(Command::query_exact, Observation::committed_record);
        input.linearizable = false;
        add("query_commit_nonlinearizable", state(Phase::query_only), input, RecoveryCode::linearizable_observation_required);
    }
    {
        auto input = step(Command::query_exact, Observation::committed_record);
        input.single_view = false;
        add("query_commit_split_view", state(Phase::query_only), input, RecoveryCode::single_view_required);
    }
    {
        auto input = step(Command::query_exact, Observation::committed_record);
        input.durable_result = false;
        add("query_commit_not_durable", state(Phase::query_only), input, RecoveryCode::durable_result_required);
    }
    {
        auto input = step(Command::query_exact, Observation::committed_record);
        input.retention_covers_reopen = false;
        add("query_commit_short_retention", state(Phase::query_only), input, RecoveryCode::retention_horizon_required);
    }
    {
        auto input = step(Command::query_exact, Observation::absent_record);
        input.authenticated = false;
        add("query_absent_unauthenticated", state(Phase::query_only), input, RecoveryCode::authentication_required);
    }
    {
        auto input = step(Command::query_exact, Observation::absent_record);
        input.linearizable = false;
        add("query_absent_nonlinearizable", state(Phase::query_only), input, RecoveryCode::linearizable_observation_required);
    }
    {
        auto input = step(Command::query_exact, Observation::absent_record);
        input.single_view = false;
        add("query_absent_split_view", state(Phase::query_only), input, RecoveryCode::single_view_required);
    }
    {
        auto input = step(Command::query_exact, Observation::retired_record);
        input.authenticated = false;
        add("query_retired_unauthenticated", state(Phase::query_only), input, RecoveryCode::authentication_required);
    }
    {
        auto input = step(Command::query_exact, Observation::retired_record);
        input.linearizable = false;
        add("query_retired_nonlinearizable", state(Phase::query_only), input, RecoveryCode::linearizable_observation_required);
    }
    {
        auto input = step(Command::query_exact, Observation::retired_record);
        input.single_view = false;
        add("query_retired_split_view", state(Phase::query_only), input, RecoveryCode::single_view_required);
    }
    {
        auto input = step(Command::query_exact, Observation::retired_record);
        input.durable_result = false;
        add("query_retired_not_durable", state(Phase::query_only), input, RecoveryCode::durable_result_required);
    }
    {
        auto input = step(Command::query_exact, Observation::retired_record);
        input.retirement_serialized = false;
        add("query_retired_missing_serialized_retirement", state(Phase::query_only), input, RecoveryCode::retirement_record_required);
    }
    {
        auto input = step(Command::query_exact, Observation::retired_record);
        input.late_commit_fenced = false;
        add("query_retired_missing_late_commit_fence", state(Phase::query_only), input, RecoveryCode::late_commit_fence_required);
    }
    {
        auto input = step(Command::query_exact, Observation::retired_record);
        input.retention_covers_reopen = false;
        add("query_retired_short_retention", state(Phase::query_only), input, RecoveryCode::retention_horizon_required);
    }
    {
        auto input = step(Command::query_exact, Observation::committed_record);
        input.transition_digest = digest(0x42U);
        add("query_wrong_transition_digest", state(Phase::query_only), input, RecoveryCode::transition_digest_mismatch);
    }
    {
        auto input = step(Command::query_exact, Observation::committed_record);
        input.register_incarnation = digest(0x72U);
        add("query_wrong_bound_incarnation", state(Phase::query_only), input, RecoveryCode::register_incarnation_mismatch);
    }
    add("query_none_invalid", state(Phase::query_only), step(Command::none, Observation::none), RecoveryCode::invalid_command_for_phase);
    add("terminal_effect_submit_immutable", state(Phase::terminal_effect), step(Command::submit_exact, Observation::commit_reply), RecoveryCode::terminal_immutable);
    add("terminal_no_effect_submit_immutable", state(Phase::terminal_no_effect), step(Command::submit_exact, Observation::commit_reply), RecoveryCode::terminal_immutable);
    add("terminal_effect_clear_immutable", state(Phase::terminal_effect), step(Command::clear_latch, Observation::none), RecoveryCode::terminal_immutable);
    add("fail_stop_query_immutable", state(Phase::fail_stopped), step(Command::query_exact, Observation::committed_record), RecoveryCode::fail_stop_immutable);
    add("ready_reopen_forbidden", state(Phase::ready), step(Command::reopen, Observation::reopen_event), RecoveryCode::invalid_command_for_phase);
    add("query_reopen_wrong_observation", state(Phase::query_only), step(Command::reopen, Observation::absent_record), RecoveryCode::invalid_observation_for_command);
    {
        auto initial = state(Phase::ready);
        initial.request_id = Digest{};
        add("zero_state_identity_rejected", initial, step(Command::submit_exact, Observation::no_reply), RecoveryCode::invalid_state);
    }
    add("terminal_no_effect_query_immutable", state(Phase::terminal_no_effect), step(Command::query_exact, Observation::retired_record), RecoveryCode::terminal_immutable);
    return values;
}

}  // namespace

bool run_campaign(const std::filesystem::path& output_directory) {
    std::error_code error;
    if (std::filesystem::exists(output_directory, error)
        && !std::filesystem::is_empty(output_directory, error)) {
        return false;
    }
    std::filesystem::create_directories(output_directory, error);
    if (error) {
        return false;
    }

    const std::vector<TestCase> test_cases = cases();
    if (test_cases.size() != 54U) {
        return false;
    }
    std::string table =
        "case\tinitial_phase\tcommand\tobservation\texact_request\texact_transition\t"
        "exact_incarnation\tauthenticated\tlinearizable\tsingle_view\tdurable_result\t"
        "retirement_serialized\tlate_commit_fenced\tretention_covers_reopen\t"
        "candidate_code\treference_code\tagreement\taccepted\tnext_phase\toutcome\t"
        "query_only\tterminal\tterminal_no_effect_justified\tabsence_terminal\t"
        "resubmit_allowed\trecovery_mints_first_submit\tauthority\n";

    std::size_t accepted = 0U;
    std::size_t terminal_effect = 0U;
    std::size_t terminal_no_effect = 0U;
    std::size_t unresolved = 0U;
    std::size_t fail_stopped = 0U;
    for (const TestCase& item : test_cases) {
        const RecoveryReport candidate = evaluate_candidate(item.state, item.step);
        const RecoveryReport reference = evaluate_reference(item.state, item.step);
        if (candidate != reference || candidate.code != item.expected) {
            return false;
        }
        accepted += candidate.accepted ? 1U : 0U;
        terminal_effect += candidate.accepted && candidate.next_phase == Phase::terminal_effect ? 1U : 0U;
        terminal_no_effect += candidate.accepted && candidate.next_phase == Phase::terminal_no_effect ? 1U : 0U;
        unresolved += candidate.accepted && candidate.next_phase == Phase::query_only ? 1U : 0U;
        fail_stopped += candidate.accepted && candidate.next_phase == Phase::fail_stopped ? 1U : 0U;
        if (candidate.absence_terminal
            || candidate.resubmit_allowed
            || candidate.recovery_mints_first_submit
            || candidate.authority_granted
            || candidate.external_occurrence_proved
            || candidate.currentness_proved
            || candidate.independent_custody_proved
            || candidate.independent_reopen_proved
            || candidate.epoch_exit_proved) {
            return false;
        }
        table += std::string(item.name) + "\t"
            + std::string(phase_name(item.state.phase)) + "\t"
            + std::string(command_name(item.step.command)) + "\t"
            + std::string(observation_name(item.step.observation)) + "\t"
            + truth(item.step.request_id == item.state.request_id) + "\t"
            + truth(item.step.transition_digest == item.state.transition_digest) + "\t"
            + truth(item.step.register_incarnation == item.state.register_incarnation) + "\t"
            + truth(item.step.authenticated) + "\t"
            + truth(item.step.linearizable) + "\t"
            + truth(item.step.single_view) + "\t"
            + truth(item.step.durable_result) + "\t"
            + truth(item.step.retirement_serialized) + "\t"
            + truth(item.step.late_commit_fenced) + "\t"
            + truth(item.step.retention_covers_reopen) + "\t"
            + std::string(recovery_code_name(candidate.code)) + "\t"
            + std::string(recovery_code_name(reference.code)) + "\ttrue\t"
            + truth(candidate.accepted) + "\t"
            + std::string(phase_name(candidate.next_phase)) + "\t"
            + std::string(outcome_name(candidate.outcome)) + "\t"
            + truth(candidate.query_only) + "\t"
            + truth(candidate.terminal) + "\t"
            + truth(candidate.terminal_no_effect_justified) + "\t"
            + truth(candidate.absence_terminal) + "\t"
            + truth(candidate.resubmit_allowed) + "\t"
            + truth(candidate.recovery_mints_first_submit) + "\t"
            + truth(candidate.authority_granted) + "\n";
    }
    if (accepted != 12U || terminal_effect != 3U || terminal_no_effect != 2U
        || unresolved != 4U || fail_stopped != 3U) {
        return false;
    }

    const std::string summary =
        "{\n"
        "  \"absence_terminal_cases\": 0,\n"
        "  \"accepted_cases\": 12,\n"
        "  \"authority_granted\": false,\n"
        "  \"candidate_reference_disagreements\": 0,\n"
        "  \"cases\": 54,\n"
        "  \"currentness_proved\": false,\n"
        "  \"epoch_exit_proved\": false,\n"
        "  \"external_occurrence_proved\": false,\n"
        "  \"fail_stopped_cases\": 3,\n"
        "  \"independent_custody_proved\": false,\n"
        "  \"independent_reopen_proved\": false,\n"
        "  \"late_commit_fence_required\": true,\n"
        "  \"query_only_monotone\": true,\n"
        "  \"recovery_mints_first_submit_cases\": 0,\n"
        "  \"rejected_cases\": 42,\n"
        "  \"resubmit_allowed_cases\": 0,\n"
        "  \"schema\": \"slopos.rev0916.query-only-recovery-campaign.v1\",\n"
        "  \"terminal_effect_cases\": 3,\n"
        "  \"terminal_no_effect_cases\": 2,\n"
        "  \"terminal_no_effect_requires_retirement\": true,\n"
        "  \"unresolved_query_only_cases\": 4\n"
        "}\n";
    const std::string counterhistory =
        "row\tbranch\tevent\tinvocation_state\tvisible_register\teffect\tterminal_no_effect_sound\n"
        "P0\tshared\tcompare_apply_invoked\tpending\tN\tpossible\tfalse\n"
        "P1\tshared\tlinearizable_query_reads_absent\tpending\tN\tpossible\tfalse\n"
        "H0\tcompletion_without_commit\tinvocation_removed\tnot_committed\tN\tno_effect\ttrue\n"
        "H1\tlate_commit\tpending_invocation_linearizes\tcommitted\tN_plus_1\teffect\tfalse\n";
    const std::string invariants =
        "ABSENT_WHILE_PENDING_NOT_TERMINAL=true\n"
        "QUERY_ONLY_LATCH_MONOTONE=true\n"
        "TERMINAL_NO_EFFECT_REQUIRES_SERIALIZED_RETIREMENT=true\n"
        "TERMINAL_NO_EFFECT_REQUIRES_LATE_COMMIT_FENCE=true\n"
        "RETENTION_MUST_COVER_REOPEN=true\n"
        "RESTORE_DOES_NOT_CLEAR_QUERY_ONLY=true\n"
        "RESUBMIT_ALLOWED=false\n"
        "RECOVERY_MINTS_FIRST_SUBMIT=false\n"
        "AUTHORITY_GRANTED=false\n";

    return write_text(output_directory / "CASES.tsv", table)
        && write_text(output_directory / "SUMMARY.json", summary)
        && write_text(output_directory / "COUNTERHISTORY.tsv", counterhistory)
        && write_text(output_directory / "INVARIANTS.txt", invariants);
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery
