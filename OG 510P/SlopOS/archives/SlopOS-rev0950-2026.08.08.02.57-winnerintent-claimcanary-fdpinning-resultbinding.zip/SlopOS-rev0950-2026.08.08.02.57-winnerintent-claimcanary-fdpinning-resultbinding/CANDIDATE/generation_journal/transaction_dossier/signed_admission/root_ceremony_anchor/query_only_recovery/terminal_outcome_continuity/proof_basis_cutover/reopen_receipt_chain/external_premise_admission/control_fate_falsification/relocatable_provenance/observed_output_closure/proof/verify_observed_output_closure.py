#!/usr/bin/env python3
from __future__ import annotations

import csv
import hashlib
import re
import sys
from pathlib import Path

CANONICAL = {
    "OUTPUT-SET-MANIFEST.bin", "MANIFEST-PUBLICATION-RECEIPT.bin",
    "OUTPUT-SET-REOPEN-RECEIPT.bin", "OUTPUT-CLOSURE-CLAIM.bin",
    "OUTPUT-ENTRIES.tsv", "CASES.tsv", "CUTS.tsv", "IDENTITIES.tsv",
    "LAWS.tsv", "COUNTERMODELS.tsv", "SUMMARY.tsv", "REPORT.txt",
}
HEX64 = re.compile(r"[0-9a-f]{64}\Z")
OBJECTS = {
    "OUTPUT-SET-MANIFEST.bin": (1760, "SlopOS/OOC/output-manifest/v1"),
    "MANIFEST-PUBLICATION-RECEIPT.bin": (256, "SlopOS/OOC/publication/v1"),
    "OUTPUT-SET-REOPEN-RECEIPT.bin": (256, "SlopOS/OOC/reopen/v1"),
    "OUTPUT-CLOSURE-CLAIM.bin": (288, "SlopOS/OOC/closure-claim/v1"),
}


def fail(detail: str) -> None:
    raise SystemExit(f"OBSERVED_OUTPUT_CLOSURE_PY=FAIL detail={detail}")


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def metrics(path: Path) -> dict[str, str]:
    return {row["metric"]: row["value"] for row in rows(path)}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def padded_domain(text: str) -> bytes:
    raw = text.encode("ascii")
    if len(raw) > 32:
        fail(f"domain={text}")
    return raw + b"\0" * (32 - len(raw))


def validate_object(path: Path, size: int, domain: str) -> tuple[bytes, str]:
    data = path.read_bytes()
    if len(data) != size:
        fail(f"size={path.name}:{len(data)}")
    if data[:32] != padded_domain(domain):
        fail(f"domain={path.name}")
    if data[-32:] != hashlib.sha256(data[:-32]).digest():
        fail(f"integrity={path.name}")
    return data, sha(data)


def u64(data: bytes) -> int:
    return int.from_bytes(data, "big")


def u16(data: bytes) -> int:
    return int.from_bytes(data, "big")


def valid_portable(path: str) -> bool:
    if not path or path.startswith("/") or path.endswith("/") or "\\" in path or "//" in path:
        return False
    return all(part not in {"", ".", ".."} for part in path.split("/")) and all(0x21 <= ord(c) <= 0x7E for c in path)


def locate_root(script: Path) -> Path:
    for parent in script.parents:
        if (parent / "EVIDENCE/REV0922/RELOCATABLE-PROVENANCE/BLOBS/sha256").is_dir():
            return parent
    fail("datacube root")


def main() -> int:
    if len(sys.argv) != 2:
        fail("usage: OUTPUT_DIRECTORY")
    output = Path(sys.argv[1]).resolve()
    if not output.is_dir() or {p.name for p in output.iterdir()} != CANONICAL:
        fail("canonical file set")
    implementation_path = Path(__file__).resolve()
    implementation_digest = sha(implementation_path.read_bytes())
    root = locate_root(implementation_path)
    binding = root / "EVIDENCE/REV0923/OBSERVED-OUTPUT-CLOSURE/BINDINGS/PARENT-OUTPUT-SET.tsv"
    policy = root / "EVIDENCE/REV0923/OBSERVED-OUTPUT-CLOSURE/BINDINGS/reserved-namespace-policy.txt"
    expected_entries = rows(binding)
    if len(expected_entries) != 15:
        fail("binding entry count")
    carrier_digest = sha(binding.read_bytes())
    policy_digest = sha(policy.read_bytes())
    if carrier_digest != "539a0384d29e0f021ec1000b3e29b9ac90e322503a04076fd0be0c28b5e95324":
        fail("carrier identity")
    if policy_digest != "49ab4c5a95ae6b9609271c928bd93305ecb77fed2a266f3810f17082ac10bc31":
        fail("policy identity")

    summary = metrics(output / "SUMMARY.tsv")
    expected_summary = {
        "cases": "84", "accepted_classifications": "6", "rejected_classifications": "78",
        "closure_ready_cases": "1", "lifecycle_cut_rows": "420", "durable_stages": "5",
        "parent_output_entries": "15", "parent_output_carrier_bytes": "1391",
        "canonical_exact_object_bytes": "2560", "candidate_reference_disagreements": "0",
        "self_reference_transform_claimed": "false", "child_products_inside_subject": "false",
        "authority_granted": "false", "epoch_exit_proved": "false",
    }
    if summary != expected_summary:
        fail(f"summary={summary!r}")

    cases = rows(output / "CASES.tsv")
    if len(cases) != 84 or len({row["case"] for row in cases}) != 84:
        fail("case cardinality")
    if any(row["expected"] != row["candidate"] or row["candidate"] != row["reference"] for row in cases):
        fail("candidate reference differential")
    if sum(row["accepted"] == "true" for row in cases) != 6:
        fail("accepted count")
    if sum(row["closure_ready"] == "true" for row in cases) != 1:
        fail("closure-ready count")
    required = {
        "closed_exact_prior_output_set", "parent_relation_rejected", "parent_has_no_relocation_witness",
        "closure_claim_inside_subject", "reserved_prefix_inside_subject", "parent_output_content_substituted",
        "publication_without_manifest", "reopen_without_publication", "claim_without_reopen",
        "manifest_identity_wrong", "publication_identity_wrong", "reopen_identity_wrong", "claim_identity_wrong",
        "reopen_binding_invalid_4",
    }
    if not required <= {row["case"] for row in cases}:
        fail("required cases")

    cuts = rows(output / "CUTS.tsv")
    if len(cuts) != 420:
        fail("cut rows")
    if any(row["candidate"] != row["reference"] for row in cuts):
        fail("cut differential")
    if {int(row["cut"]) for row in cuts} != set(range(5)):
        fail("cut stages")

    identity_rows = {row["object"]: row for row in rows(output / "IDENTITIES.tsv")}
    if set(identity_rows) != set(OBJECTS):
        fail("identity rows")
    object_data: dict[str, bytes] = {}
    object_identity: dict[str, str] = {}
    for name, (size, domain) in OBJECTS.items():
        data, identity = validate_object(output / name, size, domain)
        row = identity_rows[name]
        if int(row["bytes"]) != size or row["sha256"] != identity or HEX64.fullmatch(identity) is None:
            fail(f"identity={name}")
        object_data[name] = data
        object_identity[name] = identity

    manifest = object_data["OUTPUT-SET-MANIFEST.bin"]
    parent_receipt = manifest[32:64].hex()
    parent_claim = manifest[64:96].hex()
    parent_output_contract = manifest[96:128].hex()
    if manifest[128:160].hex() != carrier_digest or manifest[160:192].hex() != policy_digest:
        fail("manifest carrier/policy binding")
    if manifest[192] != 15 or manifest[193:198] != b"\x01\x01\x01\x01\x01":
        fail("manifest shape flags")

    parsed_entries: list[dict[str, str | int]] = []
    cursor = 198
    for index in range(16):
        raw_path = manifest[cursor:cursor + 48]; cursor += 48
        content = manifest[cursor:cursor + 32].hex(); cursor += 32
        size = u64(manifest[cursor:cursor + 8]); cursor += 8
        mode = u16(manifest[cursor:cursor + 2]); cursor += 2
        path_length = manifest[cursor]; cursor += 1
        flags = manifest[cursor:cursor + 3]; cursor += 3
        if index < 15:
            if path_length == 0 or any(raw_path[path_length:]):
                fail(f"entry path carrier={index}")
            path = raw_path[:path_length].decode("ascii")
            if not valid_portable(path) or flags != b"\x01\x01\x00":
                fail(f"entry shape={index}")
            parsed_entries.append({"path": path, "bytes": size, "sha256": content, "mode": mode})
        elif raw_path != b"\0" * 48 or content != "0" * 64 or size != 0 or mode != 0 or path_length != 0 or flags != b"\0\0\0":
            fail("unused entry nonzero")
    if cursor != 1702 or any(manifest[cursor:-32]):
        fail("manifest canonical padding")
    if [str(row["path"]) for row in parsed_entries] != sorted(str(row["path"]) for row in parsed_entries):
        fail("manifest path order")
    for got, expected in zip(parsed_entries, expected_entries, strict=True):
        if got != {
            "path": expected["path"], "bytes": int(expected["bytes"]),
            "sha256": expected["sha256"], "mode": int(expected["mode"], 8),
        }:
            fail(f"exact entry={expected['path']}")
        blob = root / "EVIDENCE/REV0922/RELOCATABLE-PROVENANCE/BLOBS/sha256" / expected["sha256"][:2] / expected["sha256"]
        if not blob.is_file() or blob.stat().st_size != int(expected["bytes"]) or sha(blob.read_bytes()) != expected["sha256"]:
            fail(f"parent blob reopen={expected['path']}")

    parent_blob_root = root / "EVIDENCE/REV0922/RELOCATABLE-PROVENANCE/BLOBS/sha256"
    parent_receipt_blob = parent_blob_root / parent_receipt[:2] / parent_receipt
    parent_claim_blob = parent_blob_root / parent_claim[:2] / parent_claim
    if not parent_receipt_blob.is_file() or not parent_claim_blob.is_file():
        fail("parent object lookup")
    claim_bytes = parent_claim_blob.read_bytes()
    if claim_bytes[128:160].hex() != parent_output_contract:
        fail("parent output contract binding")

    publication = object_data["MANIFEST-PUBLICATION-RECEIPT.bin"]
    if publication[32:64].hex() != object_identity["OUTPUT-SET-MANIFEST.bin"]:
        fail("publication manifest binding")
    if publication[64:96].hex() != parent_receipt or publication[96:128].hex() != carrier_digest:
        fail("publication parent/carrier binding")
    if u64(publication[160:168]) != 1391 or publication[168:173] != b"\x01\x01\x01\x01\x01":
        fail("publication shape")

    reopen = object_data["OUTPUT-SET-REOPEN-RECEIPT.bin"]
    if reopen[32:64].hex() != object_identity["MANIFEST-PUBLICATION-RECEIPT.bin"]:
        fail("reopen publication binding")
    if reopen[64:96].hex() != object_identity["OUTPUT-SET-MANIFEST.bin"] or reopen[96:128].hex() != carrier_digest:
        fail("reopen manifest/carrier binding")
    if reopen[160:192].hex() != implementation_digest:
        fail("reopener implementation binding")
    if u64(reopen[192:200]) != 1391 or reopen[200:205] != b"\x01\x01\x01\x01\x01":
        fail("reopen shape")
    if reopen[128:160] == publication[128:160]:
        fail("publisher/reopener role collapse")
    if any(reopen[205:-32]):
        fail("reopen canonical padding")

    closure = object_data["OUTPUT-CLOSURE-CLAIM.bin"]
    expected_bindings = [
        parent_receipt,
        parent_claim,
        object_identity["OUTPUT-SET-MANIFEST.bin"],
        object_identity["MANIFEST-PUBLICATION-RECEIPT.bin"],
        object_identity["OUTPUT-SET-REOPEN-RECEIPT.bin"],
        policy_digest,
    ]
    for index, expected in enumerate(expected_bindings, start=1):
        if closure[index * 32:(index + 1) * 32].hex() != expected:
            fail(f"claim binding={index}")
    if closure[224:229] != b"\x01\x01\x01\x01\x01":
        fail("claim shape")

    output_entries = rows(output / "OUTPUT-ENTRIES.tsv")
    if len(output_entries) != 15 or [row["path"] for row in output_entries] != [row["path"] for row in expected_entries]:
        fail("output entries projection")
    if len(rows(output / "LAWS.tsv")) != 13 or len(rows(output / "COUNTERMODELS.tsv")) != 78:
        fail("law/countermodel count")
    report = (output / "REPORT.txt").read_text(encoding="utf-8")
    for marker in (
        "OBSERVED_OUTPUT_CLOSURE=PASS", "cases=84", "cuts=420", "closure_ready=1",
        "candidate_reference_disagreements=0", "reopener_implementation_bound=true",
        "self_reference_transform=false", "child_products_outside_subject=true",
        "administrative_independence=false", "authority=false", "epoch_exit=false",
    ):
        if marker not in report:
            fail(f"report marker={marker}")

    print(
        "OBSERVED_OUTPUT_CLOSURE_PY=PASS cases=84 accepted=6 rejected=78 cuts=420 "
        f"entries=15 exact_object_bytes=2560 reopener_implementation_sha256={implementation_digest} "
        "hosted_rehash=true administrative_independence=false self_reference=false authority=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
