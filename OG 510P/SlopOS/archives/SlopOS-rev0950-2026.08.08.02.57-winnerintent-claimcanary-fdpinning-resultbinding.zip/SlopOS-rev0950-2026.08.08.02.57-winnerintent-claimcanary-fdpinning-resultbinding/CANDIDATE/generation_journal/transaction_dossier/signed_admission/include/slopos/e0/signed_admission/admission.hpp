#pragma once

#include "slopos/e0/transaction_dossier/dossier.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <span>
#include <string_view>

namespace slopos::e0::signed_admission {

using transaction_dossier::Digest;
using PublicKey = std::array<std::uint8_t, 32U>;
using Signature = std::array<std::uint8_t, 64U>;

inline constexpr std::size_t kMaximumKeys = 3U;
inline constexpr std::size_t kManifestBytes = 384U;
inline constexpr std::size_t kStatementBytes = 512U;
inline constexpr std::size_t kEnvelopeBytes = 1024U;
inline constexpr std::size_t kSigningMessageBytes = 552U;

using EncodedManifest = std::array<std::uint8_t, kManifestBytes>;
using EncodedStatement = std::array<std::uint8_t, kStatementBytes>;
using EncodedEnvelope = std::array<std::uint8_t, kEnvelopeBytes>;
using SigningMessage = std::array<std::uint8_t, kSigningMessageBytes>;

struct KeyV1 final {
    Digest key_id{};
    PublicKey public_key{};

    [[nodiscard]] friend constexpr bool operator==(const KeyV1&, const KeyV1&) noexcept = default;
};

struct OwnerManifestV1 final {
    Digest project_id{};
    Digest constitution_id{};
    Digest predecessor_manifest{};
    std::uint64_t version{0U};
    std::uint8_t threshold{0U};
    std::uint8_t key_count{0U};
    std::array<KeyV1, kMaximumKeys> keys{};

    [[nodiscard]] friend constexpr bool operator==(
        const OwnerManifestV1&, const OwnerManifestV1&) noexcept = default;
};

enum class Purpose : std::uint8_t {
    effect_permit = 1U,
};

enum class TerminalScope : std::uint8_t {
    effect = 1U,
    no_effect = 2U,
    uncertain = 3U,
    fail_stop = 4U,
};

struct AdmissionStatementV1 final {
    Purpose purpose{Purpose::effect_permit};
    TerminalScope terminal_scope{TerminalScope::effect};
    Digest project_id{};
    Digest owner_manifest_head{};
    Digest profile_digest{};
    Digest transaction_id{};
    Digest prefix_digest{};
    Digest subject{};
    Digest policy{};
    Digest evidence{};
    Digest appraisal{};
    Digest issuer_actor{};
    Digest endpoint_actor{};
    Digest reopener_actor{};
    std::uint64_t generation_from{0U};
    std::uint64_t generation_to{0U};
    std::uint64_t nonce{0U};
    std::uint64_t not_before{0U};
    std::uint64_t expires_at{0U};
    std::uint64_t ceremony_nonce{0U};

    [[nodiscard]] friend constexpr bool operator==(
        const AdmissionStatementV1&, const AdmissionStatementV1&) noexcept = default;
};

struct SignatureSlotV1 final {
    Digest key_id{};
    Signature signature{};

    [[nodiscard]] friend constexpr bool operator==(
        const SignatureSlotV1&, const SignatureSlotV1&) noexcept = default;
};

struct SignedAdmissionEnvelopeV1 final {
    EncodedStatement statement{};
    std::uint8_t signature_count{0U};
    std::array<SignatureSlotV1, kMaximumKeys> signatures{};

    [[nodiscard]] friend constexpr bool operator==(
        const SignedAdmissionEnvelopeV1&, const SignedAdmissionEnvelopeV1&) noexcept = default;
};

enum class ValidationCode : std::uint8_t {
    evidence_valid,
    invalid_manifest,
    invalid_envelope,
    invalid_statement,
    manifest_binding_mismatch,
    profile_mismatch,
    time_window_mismatch,
    invalid_dossier,
    dossier_binding_mismatch,
    unknown_signer,
    duplicate_signer,
    invalid_signature,
    below_threshold,
};

struct ValidationReport final {
    ValidationCode code{ValidationCode::invalid_manifest};
    std::size_t verified_signatures{0U};
    bool valid{false};
    bool manifest_valid{false};
    bool statement_valid{false};
    bool signature_evidence_valid{false};
    bool threshold_met{false};
    bool dossier_bound{false};
    bool time_window_match{false};
    bool structurally_complete{false};
    bool effect_bearing{false};
    bool owner_constitution_proved{false};
    bool currentness_proved{false};
    bool global_one_use_proved{false};
    bool epoch_exit_proved{false};
    bool authority_granted{false};

    [[nodiscard]] friend constexpr bool operator==(
        const ValidationReport&, const ValidationReport&) noexcept = default;
};

[[nodiscard]] Digest key_id_for(const PublicKey& public_key);
[[nodiscard]] Digest manifest_head(const EncodedManifest& manifest);
[[nodiscard]] Digest statement_head(const EncodedStatement& statement);
[[nodiscard]] Digest dossier_prefix_digest(
    std::span<const transaction_dossier::EncodedRecord> records);
[[nodiscard]] Digest admitted_profile_digest();

[[nodiscard]] bool encode_manifest(const OwnerManifestV1& value, EncodedManifest& output);
[[nodiscard]] bool decode_manifest(const EncodedManifest& input, OwnerManifestV1& output);
[[nodiscard]] bool encode_statement(const AdmissionStatementV1& value, EncodedStatement& output);
[[nodiscard]] bool decode_statement(const EncodedStatement& input, AdmissionStatementV1& output);
[[nodiscard]] bool encode_envelope(const SignedAdmissionEnvelopeV1& value, EncodedEnvelope& output);
[[nodiscard]] bool decode_envelope(const EncodedEnvelope& input, SignedAdmissionEnvelopeV1& output);
[[nodiscard]] SigningMessage signing_message_for(const EncodedStatement& statement);

[[nodiscard]] ValidationReport validate_candidate(
    const EncodedManifest& manifest,
    const EncodedEnvelope& envelope,
    std::span<const transaction_dossier::EncodedRecord> dossier,
    std::uint64_t observed_time);
[[nodiscard]] ValidationReport validate_reference(
    const EncodedManifest& manifest,
    const EncodedEnvelope& envelope,
    std::span<const transaction_dossier::EncodedRecord> dossier,
    std::uint64_t observed_time);

[[nodiscard]] std::string_view validation_code_name(ValidationCode value) noexcept;
[[nodiscard]] bool run_campaign(const std::filesystem::path& output_directory);

}  // namespace slopos::e0::signed_admission
