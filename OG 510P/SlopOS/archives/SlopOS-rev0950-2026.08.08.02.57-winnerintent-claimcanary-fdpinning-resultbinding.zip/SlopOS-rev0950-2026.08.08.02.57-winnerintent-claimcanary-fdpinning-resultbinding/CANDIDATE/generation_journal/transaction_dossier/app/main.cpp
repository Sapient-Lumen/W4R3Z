#include "slopos/e0/transaction_dossier/dossier.hpp"

#include <filesystem>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

namespace td = slopos::e0::transaction_dossier;

namespace {

[[nodiscard]] bool read_records(const std::filesystem::path& path,
                                std::vector<td::EncodedRecord>& records) {
    std::ifstream input(path, std::ios::binary | std::ios::ate);
    if (!input) return false;
    const std::streamoff size = input.tellg();
    if (size < 0 || size % static_cast<std::streamoff>(td::kRecordBytes) != 0) {
        return false;
    }
    input.seekg(0);
    const std::size_t count = static_cast<std::size_t>(
        size / static_cast<std::streamoff>(td::kRecordBytes));
    records.resize(count);
    for (td::EncodedRecord& record : records) {
        input.read(reinterpret_cast<char*>(record.data()),
                   static_cast<std::streamsize>(record.size()));
        if (!input) return false;
    }
    return true;
}

}  // namespace

int main(const int argc, char** argv) {
    if (argc == 3 && std::string(argv[1]) == "campaign") {
        if (!td::run_campaign(argv[2])) {
            std::cerr << "TRANSACTION_DOSSIER_CAMPAIGN=FAIL\n";
            return 1;
        }
        std::cout << "TRANSACTION_DOSSIER_CAMPAIGN=PASS authority=false\n";
        return 0;
    }
    if (argc == 3 && std::string(argv[1]) == "verify") {
        std::vector<td::EncodedRecord> records;
        if (!read_records(argv[2], records)) {
            std::cerr << "TRANSACTION_DOSSIER_VERIFY=FAIL detail=read\n";
            return 2;
        }
        const td::ValidationReport candidate = td::validate_candidate(records);
        const td::ValidationReport reference = td::validate_reference(records);
        if (candidate != reference) {
            std::cerr << "TRANSACTION_DOSSIER_VERIFY=FAIL detail=reference-disagreement\n";
            return 3;
        }
        std::cout << "TRANSACTION_DOSSIER_VERIFY="
                  << (candidate.valid ? "PASS" : "REJECT")
                  << " code=" << td::validation_code_name(candidate.code)
                  << " records=" << candidate.records
                  << " structurally_complete="
                  << (candidate.structurally_complete ? "true" : "false")
                  << " effect_bearing=" << (candidate.effect_bearing ? "true" : "false")
                  << " epoch_exit_proved=" << (candidate.epoch_exit_proved ? "true" : "false")
                  << " authority=false\n";
        return candidate.valid ? 0 : 4;
    }
    std::cerr << "usage: slopos_transaction_dossier campaign OUTPUT_DIR | verify FILE\n";
    return 64;
}
