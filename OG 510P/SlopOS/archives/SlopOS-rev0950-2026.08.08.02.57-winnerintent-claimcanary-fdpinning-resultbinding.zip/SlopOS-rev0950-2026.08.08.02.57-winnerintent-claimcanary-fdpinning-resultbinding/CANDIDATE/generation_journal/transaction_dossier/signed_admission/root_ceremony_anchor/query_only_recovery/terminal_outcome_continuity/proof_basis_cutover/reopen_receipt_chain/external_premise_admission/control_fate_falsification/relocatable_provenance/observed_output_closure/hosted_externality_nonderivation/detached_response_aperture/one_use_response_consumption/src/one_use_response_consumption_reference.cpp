#include "slopos/e0/detached_response_aperture/one_use_response_consumption.hpp"

#include <openssl/evp.h>

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <string_view>

namespace slopos::e0::detached_response_aperture::one_use_response_consumption {
namespace {

[[nodiscard]] constexpr std::uint8_t hex_value(const char c) noexcept {
    return c >= '0' && c <= '9' ? static_cast<std::uint8_t>(c - '0')
        : c >= 'a' && c <= 'f' ? static_cast<std::uint8_t>(10 + c - 'a') : 0U;
}
[[nodiscard]] Digest decode_digest(const std::string_view text) noexcept {
    Digest result{};
    if (text.size() != 64U) return result;
    for (std::size_t i = 0U; i < result.size(); ++i) {
        result[i] = static_cast<std::uint8_t>((hex_value(text[2U * i]) << 4U) | hex_value(text[2U * i + 1U]));
    }
    return result;
}
[[nodiscard]] bool populated(const Digest& value) noexcept {
    for (const auto byte : value) if (byte != 0U) return true;
    return false;
}

[[nodiscard]] Digest reference_domain_hash(
    const std::string_view domain,
    const std::uint8_t* data,
    const std::size_t size) noexcept {
    Digest output{};
    EVP_MD_CTX* context = EVP_MD_CTX_new();
    if (context == nullptr) return output;
    const std::uint8_t separator = 0U;
    unsigned int written = 0U;
    const bool ok = EVP_DigestInit_ex(context, EVP_sha256(), nullptr) == 1
        && EVP_DigestUpdate(context, domain.data(), domain.size()) == 1
        && EVP_DigestUpdate(context, &separator, 1U) == 1
        && (size == 0U || EVP_DigestUpdate(context, data, size) == 1)
        && EVP_DigestFinal_ex(context, output.data(), &written) == 1
        && written == output.size();
    EVP_MD_CTX_free(context);
    if (!ok) output.fill(0U);
    return output;
}

template <std::size_t N>
class ReferenceBodyWriter final {
public:
    explicit ReferenceBodyWriter(std::array<std::uint8_t, N>& body) noexcept : body_(body) { body_.fill(0U); }
    void digest(const Digest& value) noexcept {
        for (const auto byte : value) append(byte);
    }
    void u64(const std::uint64_t value) noexcept {
        for (unsigned shift = 0U; shift < 64U; shift += 8U) append(static_cast<std::uint8_t>((value >> shift) & 0xffU));
    }
    void u32(const std::uint32_t value) noexcept {
        for (unsigned shift = 0U; shift < 32U; shift += 8U) append(static_cast<std::uint8_t>((value >> shift) & 0xffU));
    }
    void u8(const std::uint8_t value) noexcept { append(value); }
    void flag(const bool value) noexcept { append(value ? 1U : 0U); }
    [[nodiscard]] bool complete() const noexcept { return valid_; }
private:
    void append(const std::uint8_t value) noexcept {
        if (cursor_ >= body_.size()) { valid_ = false; return; }
        body_[cursor_] = value;
        ++cursor_;
    }
    std::array<std::uint8_t, N>& body_;
    std::size_t cursor_{0U};
    bool valid_{true};
};

template <std::size_t ObjectBytes, typename Emit>
[[nodiscard]] Digest reference_identity(const std::string_view domain, Emit&& emit) noexcept {
    static_assert(ObjectBytes >= 32U);
    std::array<std::uint8_t, ObjectBytes - 32U> body{};
    ReferenceBodyWriter<ObjectBytes - 32U> writer(body);
    emit(writer);
    if (!writer.complete()) return {};
    return reference_domain_hash(domain, body.data(), body.size());
}

void emit_parent(const ParentBinding& v, auto& w) noexcept {
    w.digest(v.parent_output_set_digest); w.digest(v.parent_composition_receipt_digest);
    w.digest(v.response_digest); w.digest(v.accepting_configuration_digest);
    w.digest(v.appraisal_witness_digest); w.digest(v.consumption_deficit_digest);
    w.digest(v.parent_archive_digest); w.u64(v.parent_archive_bytes); w.u64(v.parent_manifest_rows);
    w.u32(v.schema); w.flag(v.present); w.flag(v.canonical); w.flag(v.parent_aperture_pass);
    w.flag(v.parent_external_response_present); w.flag(v.parent_authority_granted);
}
void emit_appraisal(const AppraisalCarrier& v, auto& w) noexcept {
    w.digest(v.parent_binding_digest); w.digest(v.response_digest); w.digest(v.accepting_configuration_digest);
    w.digest(v.appraisal_witness_digest); w.digest(v.owner_root_digest); w.digest(v.appraisal_policy_digest);
    w.digest(v.trusted_time_source_digest); w.u64(v.owner_root_version); w.u64(v.appraisal_time);
    w.u64(v.consume_not_after); w.u32(v.schema); w.flag(v.present); w.flag(v.canonical);
    w.flag(v.appraisal_accepted); w.flag(v.laboratory_carrier); w.flag(v.external_currentness_proved);
}
void emit_request(const ConsumeRequest& v, auto& w) noexcept {
    w.digest(v.parent_binding_digest); w.digest(v.response_digest); w.digest(v.appraisal_carrier_digest);
    w.digest(v.expected_predecessor_head); w.digest(v.operation_id); w.digest(v.journal_namespace_digest);
    w.digest(v.consumption_policy_digest); w.digest(v.request_payload_digest);
    w.u64(v.expected_generation); w.u64(v.requested_at); w.u32(v.schema);
    w.flag(v.present); w.flag(v.canonical); w.flag(v.fixed_payload); w.flag(v.blind_retry_forbidden);
}
void emit_invocation(const PendingInvocation& v, auto& w) noexcept {
    w.digest(v.request_digest); w.digest(v.operation_id); w.digest(v.expected_predecessor_head);
    w.digest(v.journal_namespace_digest); w.digest(v.submission_channel_digest); w.digest(v.query_policy_digest);
    w.u64(v.submitted_at); w.u32(v.schema); w.flag(v.present); w.flag(v.canonical);
    w.flag(v.response_returned); w.flag(v.query_only_after_loss);
}
void emit_query(const QueryObservation& v, auto& w) noexcept {
    w.digest(v.invocation_digest); w.digest(v.request_digest); w.digest(v.operation_id);
    w.digest(v.expected_predecessor_head); w.digest(v.observed_head); w.digest(v.journal_namespace_digest);
    w.digest(v.query_policy_digest); w.digest(v.query_role_digest);
    w.u64(v.observed_generation); w.u64(v.query_revision); w.u64(v.queried_at); w.u32(v.schema);
    w.u8(static_cast<std::uint8_t>(v.finding)); w.flag(v.present); w.flag(v.canonical);
    w.flag(v.durable); w.flag(v.query_only); w.flag(v.model_only);
    w.flag(v.terminal_no_effect_proved); w.flag(v.external_linearizable_read_proved);
}
void emit_commit(const JournalCommit& v, auto& w) noexcept {
    w.digest(v.request_digest); w.digest(v.response_digest); w.digest(v.appraisal_carrier_digest);
    w.digest(v.query_observation_digest); w.digest(v.predecessor_head); w.digest(v.successor_head);
    w.digest(v.operation_id); w.digest(v.journal_namespace_digest); w.digest(v.terminal_payload_digest);
    w.digest(v.compare_append_policy_digest); w.u64(v.predecessor_generation);
    w.u64(v.successor_generation); w.u64(v.commit_revision); w.u32(v.schema);
    w.u8(static_cast<std::uint8_t>(v.outcome)); w.flag(v.present); w.flag(v.canonical);
    w.flag(v.durable); w.flag(v.atomic_compare_append); w.flag(v.model_only);
}
void emit_terminal(const TerminalReceipt& v, auto& w) noexcept {
    w.digest(v.commit_digest); w.digest(v.request_digest); w.digest(v.response_digest);
    w.digest(v.predecessor_head); w.digest(v.successor_head); w.digest(v.operation_id);
    w.digest(v.terminal_payload_digest); w.digest(v.receipt_policy_digest);
    w.u64(v.commit_revision); w.u64(v.terminal_at); w.u32(v.schema);
    w.u8(static_cast<std::uint8_t>(v.outcome)); w.flag(v.present); w.flag(v.canonical);
    w.flag(v.durable); w.flag(v.exact_retry_equivalence);
}
void emit_reopen(const ReopenReceipt& v, auto& w) noexcept {
    w.digest(v.terminal_receipt_digest); w.digest(v.commit_digest); w.digest(v.request_digest);
    w.digest(v.response_digest); w.digest(v.reopener_implementation_digest); w.digest(v.reopener_role_digest);
    w.digest(v.reopen_policy_digest); w.u64(v.reopened_at); w.u32(v.schema);
    w.flag(v.present); w.flag(v.canonical); w.flag(v.durable); w.flag(v.exact_receipt_reopened);
    w.flag(v.separate_role_label); w.flag(v.administrative_independence_proved);
}

[[nodiscard]] Digest ref_parent_identity(const ParentBinding& v) noexcept {
    return reference_identity<parent_binding_bytes>("slopos.ourc.parent-binding.v1", [&](auto& w){ emit_parent(v,w); });
}
[[nodiscard]] Digest ref_appraisal_identity(const AppraisalCarrier& v) noexcept {
    return reference_identity<appraisal_carrier_bytes>("slopos.ourc.appraisal-carrier.v1", [&](auto& w){ emit_appraisal(v,w); });
}
[[nodiscard]] Digest ref_request_identity(const ConsumeRequest& v) noexcept {
    return reference_identity<consume_request_bytes>("slopos.ourc.consume-request.v1", [&](auto& w){ emit_request(v,w); });
}
[[nodiscard]] Digest ref_invocation_identity(const PendingInvocation& v) noexcept {
    return reference_identity<invocation_bytes>("slopos.ourc.invocation.v1", [&](auto& w){ emit_invocation(v,w); });
}
[[nodiscard]] Digest ref_query_identity(const QueryObservation& v) noexcept {
    return reference_identity<query_observation_bytes>("slopos.ourc.query-observation.v1", [&](auto& w){ emit_query(v,w); });
}
[[nodiscard]] Digest ref_commit_identity(const JournalCommit& v) noexcept {
    return reference_identity<journal_commit_bytes>("slopos.ourc.journal-commit.v1", [&](auto& w){ emit_commit(v,w); });
}
[[nodiscard]] Digest ref_terminal_identity(const TerminalReceipt& v) noexcept {
    return reference_identity<terminal_receipt_bytes>("slopos.ourc.terminal-receipt.v1", [&](auto& w){ emit_terminal(v,w); });
}
[[nodiscard]] Digest ref_reopen_identity(const ReopenReceipt& v) noexcept {
    return reference_identity<reopen_receipt_bytes>("slopos.ourc.reopen-receipt.v1", [&](auto& w){ emit_reopen(v,w); });
}
[[nodiscard]] Digest pair_hash(const std::string_view domain, const Digest& left, const Digest& right) noexcept {
    std::array<std::uint8_t, 64U> bytes{};
    for (std::size_t i = 0U; i < left.size(); ++i) bytes[i] = left[i];
    for (std::size_t i = 0U; i < right.size(); ++i) bytes[left.size() + i] = right[i];
    return reference_domain_hash(domain, bytes.data(), bytes.size());
}

[[nodiscard]] bool exact_parent(const ParentBinding& p) noexcept {
    const std::array<bool, 18U> laws{{
        p.present, p.canonical, p.parent_aperture_pass,
        !p.parent_external_response_present, !p.parent_authority_granted,
        p.schema == schema_version,
        p.parent_output_set_digest == decode_digest(SLOPOS_OURC_PARENT_OUTPUT_SET_SHA256_HEX),
        p.parent_composition_receipt_digest == decode_digest(SLOPOS_OURC_PARENT_COMPOSITION_RECEIPT_SHA256_HEX),
        p.response_digest == decode_digest(SLOPOS_OURC_PARENT_RESPONSE_SHA256_HEX),
        p.accepting_configuration_digest == decode_digest(SLOPOS_OURC_PARENT_ACCEPTING_CONFIGURATION_SHA256_HEX),
        p.appraisal_witness_digest == decode_digest(SLOPOS_OURC_PARENT_APPRAISAL_WITNESS_SHA256_HEX),
        p.consumption_deficit_digest == decode_digest(SLOPOS_OURC_PARENT_CONSUMPTION_DEFICIT_SHA256_HEX),
        p.parent_archive_digest == decode_digest(SLOPOS_OURC_PARENT_ARCHIVE_SHA256_HEX),
        p.parent_archive_bytes == static_cast<std::uint64_t>(SLOPOS_OURC_PARENT_ARCHIVE_BYTES),
        p.parent_manifest_rows == static_cast<std::uint64_t>(SLOPOS_OURC_PARENT_MANIFEST_ROWS),
        p.binding_digest == ref_parent_identity(p),
        populated(p.response_digest), populated(p.parent_output_set_digest),
    }};
    return std::all_of(laws.begin(), laws.end(), [](const bool law) { return law; });
}
[[nodiscard]] bool exact_appraisal(const AppraisalCarrier& a, const ParentBinding& p) noexcept {
    const bool timing = a.appraisal_time == 1200U && a.consume_not_after > a.appraisal_time && a.consume_not_after <= 2000U;
    return a.present && a.canonical && a.appraisal_accepted && a.laboratory_carrier
        && !a.external_currentness_proved && a.schema == schema_version
        && a.parent_binding_digest == p.binding_digest && a.response_digest == p.response_digest
        && a.accepting_configuration_digest == p.accepting_configuration_digest
        && a.appraisal_witness_digest == p.appraisal_witness_digest
        && a.owner_root_version == 41U && timing && populated(a.owner_root_digest)
        && populated(a.appraisal_policy_digest) && populated(a.trusted_time_source_digest)
        && a.carrier_digest == ref_appraisal_identity(a);
}
[[nodiscard]] bool exact_request(const ConsumeRequest& r, const ParentBinding& p, const AppraisalCarrier& a) noexcept {
    const bool identities = r.parent_binding_digest == p.binding_digest
        && r.response_digest == p.response_digest && r.appraisal_carrier_digest == a.carrier_digest;
    const bool timing = r.requested_at >= a.appraisal_time && r.requested_at <= a.consume_not_after;
    const bool policy = r.consumption_policy_digest == decode_digest(SLOPOS_OURC_CONSUMPTION_POLICY_SHA256_HEX);
    return r.present && r.canonical && r.fixed_payload && r.blind_retry_forbidden
        && r.schema == schema_version && identities && timing && policy
        && r.expected_generation == 0U && populated(r.expected_predecessor_head)
        && populated(r.operation_id) && populated(r.journal_namespace_digest)
        && populated(r.request_payload_digest) && r.request_digest == ref_request_identity(r);
}
[[nodiscard]] bool exact_invocation(const PendingInvocation& i, const ConsumeRequest& r) noexcept {
    return i.present && i.canonical && !i.response_returned && i.query_only_after_loss
        && i.schema == schema_version && i.request_digest == r.request_digest
        && i.operation_id == r.operation_id && i.expected_predecessor_head == r.expected_predecessor_head
        && i.journal_namespace_digest == r.journal_namespace_digest
        && i.query_policy_digest == decode_digest(SLOPOS_OURC_QUERY_POLICY_SHA256_HEX)
        && populated(i.submission_channel_digest) && i.submitted_at >= r.requested_at
        && i.invocation_digest == ref_invocation_identity(i);
}
[[nodiscard]] bool exact_query(const QueryObservation& q, const PendingInvocation& i, const ConsumeRequest& r, const AppraisalCarrier& a) noexcept {
    const auto finding = static_cast<std::uint8_t>(q.finding);
    const bool subject = q.invocation_digest == i.invocation_digest && q.request_digest == r.request_digest
        && q.operation_id == r.operation_id && q.expected_predecessor_head == r.expected_predecessor_head
        && q.observed_head == r.expected_predecessor_head && q.journal_namespace_digest == r.journal_namespace_digest;
    const bool policy = q.query_policy_digest == i.query_policy_digest
        && q.query_role_digest == decode_digest(SLOPOS_OURC_QUERY_OBSERVER_ROLE_SHA256_HEX);
    const bool chronology = q.observed_generation == r.expected_generation && q.query_revision == 1U
        && q.queried_at >= i.submitted_at && q.queried_at <= a.consume_not_after;
    return q.present && q.canonical && q.durable && q.query_only && q.model_only
        && !q.terminal_no_effect_proved && !q.external_linearizable_read_proved
        && q.schema == schema_version && finding <= static_cast<std::uint8_t>(QueryFinding::unavailable)
        && q.finding == QueryFinding::exact_absence && subject && policy && chronology
        && q.observation_digest == ref_query_identity(q);
}
[[nodiscard]] bool exact_commit(const JournalCommit& c, const ConsumeRequest& r, const AppraisalCarrier& a, const QueryObservation& q) noexcept {
    const Digest successor = pair_hash("slopos.ourc.successor-head.v2", r.expected_predecessor_head, r.request_digest);
    const Digest payload = reference_domain_hash("slopos.ourc.terminal-payload.v1", r.request_payload_digest.data(), r.request_payload_digest.size());
    return c.present && c.canonical && c.durable && c.atomic_compare_append && c.model_only
        && c.schema == schema_version && c.outcome == Outcome::applied
        && c.request_digest == r.request_digest && c.response_digest == r.response_digest
        && c.appraisal_carrier_digest == a.carrier_digest
        && q.finding == QueryFinding::exact_absence
        && q.observed_head == r.expected_predecessor_head
        && q.observed_generation == r.expected_generation
        && c.query_observation_digest == q.observation_digest
        && c.predecessor_head == q.observed_head
        && c.successor_head == successor && c.operation_id == r.operation_id
        && c.journal_namespace_digest == r.journal_namespace_digest
        && c.terminal_payload_digest == payload
        && c.compare_append_policy_digest == decode_digest(SLOPOS_OURC_CONSUMPTION_POLICY_SHA256_HEX)
        && c.predecessor_generation == r.expected_generation
        && c.successor_generation == r.expected_generation + 1U
        && c.commit_revision == q.query_revision + 1U && c.commit_digest == ref_commit_identity(c);
}
[[nodiscard]] bool exact_terminal(const TerminalReceipt& t, const JournalCommit& c, const ConsumeRequest& r) noexcept {
    return t.present && t.canonical && t.durable && t.exact_retry_equivalence
        && t.schema == schema_version && t.outcome == Outcome::applied
        && t.commit_digest == c.commit_digest && t.request_digest == r.request_digest
        && t.response_digest == r.response_digest && t.predecessor_head == c.predecessor_head
        && t.successor_head == c.successor_head && t.operation_id == r.operation_id
        && t.terminal_payload_digest == c.terminal_payload_digest
        && t.receipt_policy_digest == decode_digest(SLOPOS_OURC_CONSUMPTION_POLICY_SHA256_HEX)
        && t.commit_revision == c.commit_revision && t.terminal_at >= r.requested_at
        && t.receipt_digest == ref_terminal_identity(t);
}
[[nodiscard]] bool exact_reopen(const ReopenReceipt& o, const TerminalReceipt& t, const JournalCommit& c, const ConsumeRequest& r) noexcept {
    return o.present && o.canonical && o.durable && o.exact_receipt_reopened
        && o.separate_role_label && !o.administrative_independence_proved
        && o.schema == schema_version && o.terminal_receipt_digest == t.receipt_digest
        && o.commit_digest == c.commit_digest && o.request_digest == r.request_digest
        && o.response_digest == r.response_digest
        && o.reopener_implementation_digest == decode_digest(SLOPOS_OURC_REOPENER_IMPLEMENTATION_SHA256_HEX)
        && o.reopen_policy_digest == decode_digest(SLOPOS_OURC_REOPEN_POLICY_SHA256_HEX)
        && populated(o.reopener_role_digest) && o.reopened_at >= t.terminal_at
        && o.receipt_digest == ref_reopen_identity(o);
}
[[nodiscard]] bool transition_plan_valid(const Trace& trace) noexcept {
    return exact_parent(trace.parent)
        && exact_appraisal(trace.appraisal, trace.parent)
        && exact_request(trace.request, trace.parent, trace.appraisal)
        && exact_invocation(trace.invocation, trace.request)
        && exact_query(trace.query, trace.invocation, trace.request, trace.appraisal)
        && exact_commit(trace.commit, trace.request, trace.appraisal, trace.query)
        && exact_terminal(trace.terminal, trace.commit, trace.request);
}
[[nodiscard]] bool ordered_cuts(const Trace& trace) noexcept {
    for (std::size_t i = 0U; i < cut_count; ++i) {
        if (trace.cuts[i].parent_binding_digest != (trace.parent.present ? trace.parent.binding_digest : Digest{})) return false;
        if (trace.cuts[i].appraisal_carrier_digest != (i >= 1U && trace.appraisal.present ? trace.appraisal.carrier_digest : Digest{})) return false;
        if (trace.cuts[i].request_digest != (i >= 2U && trace.request.present ? trace.request.request_digest : Digest{})) return false;
        if (trace.cuts[i].invocation_digest != (i >= 3U && trace.invocation.present ? trace.invocation.invocation_digest : Digest{})) return false;
        if (trace.cuts[i].query_observation_digest != (i >= 4U && trace.query.present ? trace.query.observation_digest : Digest{})) return false;
        if (trace.cuts[i].commit_digest != (i >= 5U && trace.commit.present ? trace.commit.commit_digest : Digest{})) return false;
        if (trace.cuts[i].terminal_receipt_digest != (i >= 6U && trace.terminal.present ? trace.terminal.receipt_digest : Digest{})) return false;
        if (trace.cuts[i].reopen_receipt_digest != (i >= 7U && trace.reopen.present ? trace.reopen.receipt_digest : Digest{})) return false;
    }
    return true;
}
[[nodiscard]] Report reject(const Code code, Report report) noexcept { report.code = code; report.accepted = false; return report; }
}  // namespace

Report evaluate_reference(const Trace& trace) noexcept {
    Report report{};
    const bool p = exact_parent(trace.parent);
    report.parent_valid = p;
    if (!p) return reject(Code::parent_binding_invalid, report);
    if (!trace.appraisal.present) {
        if (trace.request.present || trace.invocation.present || trace.query.present || trace.commit.present || trace.terminal.present || trace.reopen.present) return reject(Code::appraisal_without_parent, report);
        if (!ordered_cuts(trace)) return reject(Code::cut_order_invalid, report);
        report.code = Code::accepted_parent_bound; report.accepted = true; report.cuts_ordered = true; return report;
    }
    if (!exact_appraisal(trace.appraisal, trace.parent)) return reject(Code::appraisal_invalid, report);
    report.appraisal_valid = true;
    if (trace.consume_under_successor_root_without_fresh_appraisal) return reject(Code::stale_root_consumption_forbidden, report);
    if (!trace.request.present) {
        if (trace.invocation.present || trace.query.present || trace.commit.present || trace.terminal.present || trace.reopen.present) return reject(Code::request_without_appraisal, report);
        if (!ordered_cuts(trace)) return reject(Code::cut_order_invalid, report);
        report.code = Code::accepted_appraisal_durable; report.accepted = true; report.cuts_ordered = true; return report;
    }
    if (!exact_request(trace.request, trace.parent, trace.appraisal)) {
        if (trace.request.requested_at < trace.appraisal.appraisal_time || trace.request.requested_at > trace.appraisal.consume_not_after) return reject(Code::request_time_invalid, report);
        return reject(Code::request_invalid, report);
    }
    report.request_valid = true;
    if (!trace.invocation.present) {
        if (trace.query.present || trace.commit.present || trace.terminal.present || trace.reopen.present) return reject(Code::invocation_without_request, report);
        if (!ordered_cuts(trace)) return reject(Code::cut_order_invalid, report);
        report.code = Code::accepted_request_durable; report.accepted = true; report.cuts_ordered = true; return report;
    }
    if (!exact_invocation(trace.invocation, trace.request)) return reject(Code::invocation_invalid, report);
    report.invocation_valid = true;
    if (!trace.query.present) {
        if (trace.commit.present || trace.terminal.present || trace.reopen.present) return reject(Code::commit_without_query_observation, report);
        if (!ordered_cuts(trace)) return reject(Code::cut_order_invalid, report);
        report.code = Code::accepted_pending_query_only; report.accepted = true; report.cuts_ordered = true;
        report.query_only_required = true; return report;
    }
    if (!exact_query(trace.query, trace.invocation, trace.request, trace.appraisal)) return reject(Code::query_invalid, report);
    report.query_valid = true; report.query_only_required = true;
    if (trace.declare_terminal_no_effect_from_absence) return reject(Code::absent_query_promoted_to_no_effect, report);
    if (!trace.commit.present) {
        if (trace.terminal.present || trace.reopen.present) return reject(Code::receipt_without_commit, report);
        if (!ordered_cuts(trace)) return reject(Code::cut_order_invalid, report);
        report.code = Code::accepted_absent_query_durable; report.accepted = true; report.cuts_ordered = true; return report;
    }
    if (!exact_commit(trace.commit, trace.request, trace.appraisal, trace.query)) {
        if (trace.commit.predecessor_head != trace.request.expected_predecessor_head || trace.commit.predecessor_generation != trace.request.expected_generation) return reject(Code::commit_compare_mismatch, report);
        return reject(Code::commit_invalid, report);
    }
    report.commit_valid = true;
    if (!trace.terminal.present) {
        if (trace.reopen.present) return reject(Code::receipt_without_commit, report);
        if (!ordered_cuts(trace)) return reject(Code::cut_order_invalid, report);
        report.code = Code::accepted_commit_durable; report.accepted = true; report.cuts_ordered = true;
        report.exact_duplicate_excluded = true; report.one_use_within_coherent_history = true; return report;
    }
    if (!exact_terminal(trace.terminal, trace.commit, trace.request)) return reject(Code::receipt_invalid, report);
    report.terminal_valid = true;
    if (!trace.reopen.present) {
        if (!ordered_cuts(trace)) return reject(Code::cut_order_invalid, report);
        report.code = Code::accepted_terminal_receipt_durable; report.accepted = true; report.cuts_ordered = true;
        report.exact_duplicate_excluded = true; report.one_use_within_coherent_history = true; return report;
    }
    if (!exact_reopen(trace.reopen, trace.terminal, trace.commit, trace.request)) return reject(Code::reopen_invalid, report);
    report.reopen_valid = true;
    if (trace.promote_model_to_external_operation) return reject(Code::hosted_operation_promotion_forbidden, report);
    if (trace.promote_receipt_to_owner_admission) return reject(Code::owner_admission_promotion_forbidden, report);
    if (trace.grant_authority) return reject(Code::authority_promotion_forbidden, report);
    if (!ordered_cuts(trace)) return reject(Code::cut_order_invalid, report);
    report.code = Code::accepted_reopen_durable; report.accepted = true; report.cuts_ordered = true;
    report.exact_duplicate_excluded = true; report.exact_terminal_reopenable = true;
    report.one_use_within_coherent_history = true; return report;
}

Attempt attempt_reference(const LedgerState& state, const Trace& plan, const bool current_appraisal) noexcept {
    Attempt result{};
    if (!transition_plan_valid(plan)) { result.outcome = Outcome::fail_stop; return result; }
    result.plan_valid = true;
    const ConsumeRequest& request = plan.request;
    const bool has_any_spent_payload = populated(state.spent_response) || populated(state.applied_request)
        || populated(state.applied_commit) || populated(state.spent_successor_head)
        || populated(state.terminal_receipt) || state.spent_successor_generation != 0U
        || state.spent_commit_revision != 0U;
    const bool empty_row = !state.response_spent && !has_any_spent_payload;
    const bool complete_row = state.response_spent && populated(state.spent_response)
        && populated(state.applied_request) && populated(state.applied_commit)
        && populated(state.spent_successor_head) && populated(state.terminal_receipt)
        && state.spent_successor_generation != 0U && state.spent_commit_revision != 0U
        && state.generation == state.spent_successor_generation
        && state.head == state.spent_successor_head;
    if (!(empty_row || complete_row)) {
        result.outcome = Outcome::fail_stop;
        return result;
    }
    const bool same_response = complete_row && state.spent_response == request.response_digest;
    const bool same_request = same_response && state.applied_request == request.request_digest;
    if (same_response) result.terminal_fact_precedes_currentness = true;
    if (same_response && !same_request) {
        result.outcome = Outcome::response_spent;
        return result;
    }
    if (same_request) {
        const std::array<bool, 5U> equalities{{
            state.applied_commit == plan.commit.commit_digest,
            state.spent_successor_head == plan.commit.successor_head,
            state.terminal_receipt == plan.terminal.receipt_digest,
            state.spent_successor_generation == plan.commit.successor_generation,
            state.spent_commit_revision == plan.commit.commit_revision,
        }};
        if (!std::all_of(equalities.begin(), equalities.end(), [](const bool value) { return value; })) {
            result.outcome = Outcome::fail_stop;
            return result;
        }
        result.outcome = Outcome::already_applied;
        result.commit_digest = plan.commit.commit_digest;
        result.successor_head = plan.commit.successor_head;
        result.terminal_receipt = plan.terminal.receipt_digest;
        result.successor_generation = plan.commit.successor_generation;
        result.commit_revision = plan.commit.commit_revision;
        result.retry_equivalent = true;
        result.exact_receipt_match = true;
        result.exact_state_match = true;
        return result;
    }
    if (!current_appraisal) {
        result.outcome = Outcome::stale_currentness;
        return result;
    }
    if (state.head != request.expected_predecessor_head || state.generation != request.expected_generation) {
        result.outcome = Outcome::predecessor_conflict;
        return result;
    }
    result.outcome = Outcome::applied;
    result.commit_digest = plan.commit.commit_digest;
    result.successor_head = plan.commit.successor_head;
    result.terminal_receipt = plan.terminal.receipt_digest;
    result.successor_generation = plan.commit.successor_generation;
    result.commit_revision = plan.commit.commit_revision;
    result.state_changed = true;
    return result;
}

}  // namespace slopos::e0::detached_response_aperture::one_use_response_consumption
