# Proof Basis Cutover V1

**Plane:** LAB. **Epoch:** Zero. **Authority:** false.

Terminal Outcome Continuity V1 proves that safe reclamation eventually needs
both an exact outcome witness and a successor execution floor. This child
relation closes the next hidden gap: **eventual possession of both replacements
does not prove a continuous handoff from the live terminal record**.

The C++20 trace model evaluates seven crash boundaries. At every boundary there
must be either the complete live-record proof basis or a same-history joined
replacement basis. The live record may disappear only after the exact witness
and floor are present, an authenticated durable join binds both to the same
request/history, a replacement-only cold reopener has reconstructed that joined
basis, deletion is explicitly authorized after that observation, and the joined
basis survives restore and succession. A later repair does not erase an earlier
execution, history, join, reopen, or ordering gap.

The four destructive introductions are strict predecessor steps:

```text
components -> join -> cold reopen -> authorization -> deletion
```

Each right-hand fact must consume a left-hand fact durable at an earlier crash
cut. The model imports no external transaction that could make two adjacent
steps atomic. Six countertraces therefore refuse same-cut phase collapse or an
unserialized deletion.

The relation is not a garbage collector, record store, witness service, floor
service, provider adapter, signer, or authority API. It deletes nothing and
proves no external occurrence.

## Build and run

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build
./build/slopos_proof_basis_cutover output
python3 -B proof/verify_proof_basis_cutover.py output
```

The admitted campaign contains 75 traces and 525 crash observations. Candidate,
structurally different C++ reference, and independent Python reconstruction must
agree exactly.

## Shape checks retained

The outer reclamation request must exactly match the parent continuity evidence.
A join observation cannot precede both replacement components. A live record
cannot be absent without a recorded deletion event. A cold reopen cannot be
observed before a joined basis exists. A live-retained cutover is not ready until
that reopen has actually occurred. These shape checks are distinct from the
strict predecessor-order theorem.
