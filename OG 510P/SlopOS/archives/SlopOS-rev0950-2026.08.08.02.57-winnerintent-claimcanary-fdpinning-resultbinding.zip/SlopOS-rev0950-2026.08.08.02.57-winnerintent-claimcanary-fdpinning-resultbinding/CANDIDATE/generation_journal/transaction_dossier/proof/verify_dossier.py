#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import struct
from dataclasses import dataclass
from pathlib import Path

RECORD_BYTES = 448
MAGIC = b"SLOPTX01"
INTEGRITY_DOMAIN = b"SlopOS/transaction-dossier/v1/integrity\0"
HEAD_DOMAIN = b"SlopOS/transaction-dossier/v1/head\0"
TRANSACTION_DOMAIN = b"SlopOS/transaction-dossier/v1/transaction\0"
ZERO = b"\0" * 32

KIND_ROLE = {1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6}
DECISION = {"NONE": 0, "PASS": 1, "REJECT": 2, "INDETERMINATE": 3}
TERMINAL = {"NONE": 0, "EFFECT": 1, "NO_EFFECT": 2, "UNCERTAIN": 3, "FAIL_STOP": 4}
SCOPED = 1
SPENT = 2
QUERY_ONLY = 4
REOPENED = 8


@dataclass(frozen=True)
class Record:
    raw: bytes
    kind: int
    flags: int
    transaction_id: bytes
    predecessor: bytes
    subject: bytes
    policy: bytes
    evidence: bytes
    appraisal: bytes
    permit: bytes
    spend: bytes
    result: bytes
    currentness: bytes
    actor: bytes
    generation_from: int
    generation_to: int
    nonce: int
    decision: int
    terminal: int
    role: int


@dataclass(frozen=True)
class Report:
    code: str
    valid: bool = False
    structurally_complete: bool = False
    effect_bearing: bool = False
    epoch_exit_proved: bool = False
    authority_granted: bool = False


def digest(domain: bytes, payload: bytes) -> bytes:
    return hashlib.sha256(domain + payload).digest()


def head(raw: bytes) -> bytes:
    return digest(HEAD_DOMAIN, raw)


def transaction_id(subject: bytes, policy: bytes, generation: int, nonce: int) -> bytes:
    return digest(TRANSACTION_DOMAIN, subject + policy + struct.pack(">QQ", generation, nonce))


def parse(raw: bytes) -> Record | None:
    if len(raw) != RECORD_BYTES or raw[:8] != MAGIC:
        return None
    if struct.unpack_from(">H", raw, 8)[0] != 1 or struct.unpack_from(">I", raw, 12)[0] != RECORD_BYTES:
        return None
    if raw[11] != 0 or any(raw[20:32]) or any(raw[411:416]):
        return None
    if digest(INTEGRITY_DOMAIN, raw[:416]) != raw[416:448]:
        return None
    kind, decision, terminal, role = raw[10], raw[408], raw[409], raw[410]
    if kind not in KIND_ROLE or decision not in range(4) or terminal not in range(5) or role not in KIND_ROLE.values():
        return None
    fields = [raw[offset:offset + 32] for offset in range(32, 384, 32)]
    return Record(
        raw=raw,
        kind=kind,
        flags=struct.unpack_from(">I", raw, 16)[0],
        transaction_id=fields[0],
        predecessor=fields[1],
        subject=fields[2],
        policy=fields[3],
        evidence=fields[4],
        appraisal=fields[5],
        permit=fields[6],
        spend=fields[7],
        result=fields[8],
        currentness=fields[9],
        actor=fields[10],
        generation_from=struct.unpack_from(">Q", raw, 384)[0],
        generation_to=struct.unpack_from(">Q", raw, 392)[0],
        nonce=struct.unpack_from(">Q", raw, 400)[0],
        decision=decision,
        terminal=terminal,
        role=role,
    )


def validate(raw_records: list[bytes]) -> Report:
    count = len(raw_records)
    if count not in (3, 6):
        return Report("INVALID_COUNT")
    records: list[Record] = []
    for index, raw in enumerate(raw_records):
        item = parse(raw)
        if item is None:
            return Report("INVALID_RECORD")
        if item.kind != index + 1 or item.role != index + 1:
            return Report("INVALID_ORDER")
        if (index == 0 and item.predecessor != ZERO) or (
            index > 0 and item.predecessor != head(raw_records[index - 1])
        ):
            return Report("INVALID_CHAIN")
        records.append(item)

    first = records[0]
    if (
        ZERO in (first.transaction_id, first.subject, first.policy, first.actor)
        or first.generation_from == 0
        or first.generation_from == 2**64 - 1
        or first.nonce == 0
        or first.generation_to != first.generation_from + 1
        or first.transaction_id
        != transaction_id(first.subject, first.policy, first.generation_from, first.nonce)
    ):
        return Report("INVALID_BINDING")
    for item in records:
        if (
            item.transaction_id != first.transaction_id
            or item.subject != first.subject
            or item.policy != first.policy
            or item.generation_from != first.generation_from
            or item.nonce != first.nonce
            or item.actor == ZERO
        ):
            return Report("INVALID_BINDING")
    if len({item.actor for item in records}) != count:
        return Report("INVALID_PROFILE")

    r1, r2, r3 = records[:3]
    if (
        r1.flags != 0
        or r1.decision != DECISION["NONE"]
        or r1.terminal != TERMINAL["NONE"]
        or any(field != ZERO for field in (r1.evidence, r1.appraisal, r1.permit, r1.spend, r1.result, r1.currentness))
    ):
        return Report("INVALID_PROFILE")
    if (
        r2.flags != 0
        or r2.decision != DECISION["NONE"]
        or r2.terminal != TERMINAL["NONE"]
        or r2.evidence == ZERO
        or any(field != ZERO for field in (r2.appraisal, r2.permit, r2.spend, r2.result, r2.currentness))
        or r2.generation_to != r2.generation_from + 1
    ):
        return Report("INVALID_PROFILE")
    if (
        r3.flags != 0
        or r3.terminal != TERMINAL["NONE"]
        or r3.evidence != r2.evidence
        or r3.appraisal == ZERO
        or any(field != ZERO for field in (r3.permit, r3.spend, r3.result, r3.currentness))
        or r3.generation_to != r3.generation_from + 1
        or r3.decision not in (DECISION["PASS"], DECISION["REJECT"], DECISION["INDETERMINATE"])
    ):
        return Report("INVALID_PROFILE")

    if count == 3:
        if r3.decision == DECISION["REJECT"]:
            return Report("REJECT_STOP", valid=True)
        if r3.decision == DECISION["INDETERMINATE"]:
            return Report("INDETERMINATE_STOP", valid=True)
        return Report("INVALID_COUNT")
    if r3.decision != DECISION["PASS"]:
        return Report("INVALID_PROFILE")

    r4, r5, r6 = records[3:]
    if (
        r4.flags != SCOPED
        or r4.decision != DECISION["NONE"]
        or r4.terminal != TERMINAL["NONE"]
        or r4.evidence != r3.evidence
        or r4.appraisal != r3.appraisal
        or r4.permit == ZERO
        or any(field != ZERO for field in (r4.spend, r4.result, r4.currentness))
        or r4.generation_to != r4.generation_from + 1
    ):
        return Report("INVALID_PROFILE")

    expected_terminal = {
        TERMINAL["EFFECT"]: (r5.generation_from + 1, SCOPED | SPENT, "EFFECT"),
        TERMINAL["NO_EFFECT"]: (r5.generation_from, SCOPED | SPENT, "NO_EFFECT"),
        TERMINAL["UNCERTAIN"]: (0, SCOPED | SPENT | QUERY_ONLY, "UNCERTAIN"),
        TERMINAL["FAIL_STOP"]: (r5.generation_from, SCOPED | SPENT, "FAIL_STOP"),
    }
    terminal_profile = expected_terminal.get(r5.terminal)
    if (
        terminal_profile is None
        or r5.decision != DECISION["NONE"]
        or r5.evidence != r4.evidence
        or r5.appraisal != r4.appraisal
        or r5.permit != r4.permit
        or r5.spend == ZERO
        or r5.result == ZERO
        or r5.currentness != ZERO
        or r5.generation_to != terminal_profile[0]
        or r5.flags != terminal_profile[1]
    ):
        return Report("INVALID_PROFILE")
    if (
        r6.flags != (r5.flags | REOPENED)
        or r6.decision != DECISION["NONE"]
        or r6.terminal != r5.terminal
        or r6.generation_to != r5.generation_to
        or r6.evidence != r5.evidence
        or r6.appraisal != r5.appraisal
        or r6.permit != r5.permit
        or r6.spend != r5.spend
        or r6.result != r5.result
        or r6.currentness == ZERO
    ):
        return Report("INVALID_PROFILE")
    return Report(
        terminal_profile[2],
        valid=True,
        structurally_complete=True,
        effect_bearing=True,
        epoch_exit_proved=False,
    )


def read_records(path: Path) -> list[bytes]:
    data = path.read_bytes()
    if len(data) % RECORD_BYTES:
        return [data]
    return [data[offset : offset + RECORD_BYTES] for offset in range(0, len(data), RECORD_BYTES)]


def load_cases(root: Path) -> list[dict[str, str]]:
    with (root / "cases.tsv").open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        expected = [
            "case",
            "path",
            "expected_code",
            "expected_valid",
            "expected_structurally_complete",
            "expected_effect_bearing",
            "epoch_exit_proved",
            "coherent_nonauthority",
            "authority_granted",
        ]
        if reader.fieldnames != expected:
            raise ValueError("case header")
        return list(reader)


def verify(root: Path) -> dict[str, object]:
    campaign = json.loads((root / "audit.json").read_text(encoding="utf-8"))
    one_use = json.loads((root / "one-use-audit.json").read_text(encoding="utf-8"))
    cases = load_cases(root)
    if campaign != {
        "schema": "slopos.rev0912.transaction-dossier-campaign.v1",
        "status": "PASS",
        "record_bytes": 448,
        "complete_records": 6,
        "cases": 31,
        "valid_histories": 7,
        "rejected_histories": 24,
        "terminal_profiles": 4,
        "appraisal_stop_profiles": 2,
        "coherent_rewrite_countermodels": 1,
        "structurally_complete_histories": 5,
        "effect_bearing_histories": 5,
        "candidate_reference_disagreements": 0,
        "epoch_exit_true_results": 0,
        "authority_true_results": 0,
        "integrity_is_authentication": False,
        "global_one_use_proved": False,
        "authority_granted": False,
    }:
        raise ValueError(f"campaign summary {campaign!r}")
    if one_use != {
        "schema": "slopos.rev0912.one-use-countermodel.v1",
        "copyable_permit_instances": 2,
        "clone_local_accepts": 2,
        "shared_atomic_spend_accepts": 1,
        "restored_shared_snapshot_accepts": 2,
        "move_only_same_history_bound": True,
        "global_at_most_once_proved": False,
        "authority_granted": False,
    }:
        raise ValueError("one-use audit")
    if len(cases) != campaign["cases"]:
        raise ValueError("case count")

    valid = rejected = coherent = structurally_complete = effect_bearing = epoch_exit_true = 0
    for row in cases:
        path = root / row["path"]
        if not path.is_file():
            raise ValueError(f"missing {row['path']}")
        report = validate(read_records(path))
        expected_valid = row["expected_valid"] == "true"
        expected_complete = row["expected_structurally_complete"] == "true"
        expected_effect = row["expected_effect_bearing"] == "true"
        if (
            report.code != row["expected_code"]
            or report.valid != expected_valid
            or report.structurally_complete != expected_complete
            or report.effect_bearing != expected_effect
            or report.epoch_exit_proved
            or row["epoch_exit_proved"] != "false"
            or report.authority_granted
            or row["authority_granted"] != "false"
        ):
            raise ValueError(f"case {row['case']} report={report}")
        if report.valid:
            valid += 1
        else:
            rejected += 1
        structurally_complete += int(report.structurally_complete)
        effect_bearing += int(report.effect_bearing)
        epoch_exit_true += int(report.epoch_exit_proved)
        if row["coherent_nonauthority"] == "true":
            coherent += 1
            if not report.valid or report.authority_granted:
                raise ValueError("coherent rewrite boundary")
    if (valid, rejected, coherent, structurally_complete, effect_bearing, epoch_exit_true) != (7, 24, 1, 5, 5, 0):
        raise ValueError("aggregate")
    return {
        "schema": "slopos.rev0912.transaction-dossier-python-verification.v1",
        "status": "PASS",
        "cases": len(cases),
        "valid_histories": valid,
        "rejected_histories": rejected,
        "coherent_rewrite_countermodels": coherent,
        "structurally_complete_histories": structurally_complete,
        "effect_bearing_histories": effect_bearing,
        "epoch_exit_true_results": epoch_exit_true,
        "record_bytes": RECORD_BYTES,
        "global_one_use_proved": False,
        "authority_granted": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Independent transaction dossier verifier")
    parser.add_argument("root", type=Path)
    parser.add_argument("--audit-out", type=Path)
    args = parser.parse_args()
    try:
        result = verify(args.root)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"TRANSACTION_DOSSIER_PYTHON=FAIL detail={exc}")
        return 1
    text = json.dumps(result, sort_keys=True, separators=(",", ":"))
    if args.audit_out is not None:
        args.audit_out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"TRANSACTION_DOSSIER_PYTHON=PASS {text}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
