# Control-Fate Falsification

This nested C++20 harness repairs two representation holes in External Premise Admission:

1. distinct role-root digests can still converge on one upstream administrator, rollback authority, or view controller; and
2. a nonzero graph or receipt digest is only a label unless it is recomputed from an exact, domain-separated subject preimage.

Build and run:

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel 1
./build/slopos_control_fate_falsification out
python3 -B proof/verify_control_fate_falsification.py out
```

The candidate evaluator uses reverse traversal from role leaves. The reference evaluator independently constructs capability-specific transitive-closure matrices and independently serializes every graph and receipt proposition before SHA-256. Their complete reports and eight canonical campaign files must agree byte-for-byte across GCC, Clang, and a Clang ASan/UBSan lane. `CANONICAL-BINDINGS.tsv` retains all 97 exact preimages so the Python reopener can hash them without trusting either C++ evaluator.

A clean result is named `no_common_fate_found_in_supplied_closure`; it is deliberately not called proof of independence. Exact bytes and subject-bound receipts still do not prove inventory truth, external publication, independent challenge, owner constitution, or authority. The module creates no runtime and grants no authority.
