
#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity.hpp"

#include <array>
#include <cstdint>
#include <fstream>
#include <string>
#include <string_view>
#include <system_error>
#include <vector>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity {
namespace {

struct TestCase final {
    std::string name;
    TerminalState state;
    ContinuityEvidence evidence;
    ContinuityCode expected;
};

[[nodiscard]] Digest digest(const std::uint8_t seed) noexcept {
    Digest value{};
    for (std::size_t index = 0U; index < value.size(); ++index) {
        value[index] = static_cast<std::uint8_t>(seed + static_cast<std::uint8_t>(index));
    }
    return value;
}

[[nodiscard]] TerminalState state(const TerminalKind kind = TerminalKind::effect) noexcept {
    return TerminalState{digest(0x11U), digest(0x31U), digest(0x51U), digest(0x71U), kind};
}

[[nodiscard]] ContinuityEvidence empty(const TerminalState& value) noexcept {
    ContinuityEvidence evidence{};
    evidence.request_id = value.request_id;
    evidence.transition_digest = value.transition_digest;
    evidence.register_incarnation = value.register_incarnation;
    evidence.terminal_digest = value.terminal_digest;
    evidence.terminal_kind = value.terminal_kind;
    return evidence;
}

void complete_record(ContinuityEvidence& value) noexcept {
    value.terminal_record_present = true;
    value.terminal_record_authenticated = true;
    value.terminal_record_durable = true;
    value.terminal_record_serialized = true;
    value.terminal_record_single_view = true;
    value.terminal_record_retained_full_horizon = true;
    value.terminal_record_fences_pending = true;
    value.terminal_record_survives_restore = true;
    value.terminal_record_survives_succession = true;
    value.terminal_record_independently_reopenable = true;
}

void complete_witness(ContinuityEvidence& value) noexcept {
    value.terminal_witness_present = true;
    value.terminal_witness_authenticated = true;
    value.terminal_witness_binds_terminal = true;
    value.terminal_witness_durable = true;
    value.terminal_witness_independently_reopenable = true;
    value.terminal_witness_survives_restore = true;
    value.terminal_witness_survives_succession = true;
}

void complete_floor(ContinuityEvidence& value) noexcept {
    value.successor_floor_present = true;
    value.successor_floor_authenticated = true;
    value.successor_floor_monotone = true;
    value.successor_floor_outside_restore_domain = true;
    value.successor_floor_binds_request_namespace = true;
    value.old_incarnation_rejected = true;
    value.pending_invocations_fenced = true;
    value.restore_preserves_floor = true;
    value.succession_preserves_floor = true;
    value.successor_floor_single_view = true;
}

[[nodiscard]] std::vector<TestCase> cases() {
    std::vector<TestCase> values;
    const auto add = [&values](
        std::string name,
        const TerminalState& terminal,
        const ContinuityEvidence& evidence,
        const ContinuityCode expected) {
        values.push_back(TestCase{std::move(name), terminal, evidence, expected});
    };

    {
        const auto terminal = state(TerminalKind::effect);
        auto evidence = empty(terminal);
        complete_record(evidence);
        add("live_effect_complete", terminal, evidence, ContinuityCode::accepted_live_record_continuity);
    }
    {
        const auto terminal = state(TerminalKind::no_effect);
        auto evidence = empty(terminal);
        complete_record(evidence);
        add("live_no_effect_complete", terminal, evidence, ContinuityCode::accepted_live_record_continuity);
    }
    {
        const auto terminal = state();
        auto evidence = empty(terminal);
        complete_record(evidence);
        evidence.client_acknowledged = true;
        add("live_effect_ack_irrelevant", terminal, evidence, ContinuityCode::accepted_live_record_continuity);
    }
    {
        const auto terminal = state(TerminalKind::no_effect);
        auto evidence = empty(terminal);
        complete_record(evidence);
        evidence.ttl_expired = true;
        add("live_no_effect_ttl_irrelevant", terminal, evidence, ContinuityCode::accepted_live_record_continuity);
    }
    for (const auto& [name, kind] : std::array<std::pair<std::string_view, TerminalKind>, 2U>{
             std::pair{"reclaimed_effect_successor_witness", TerminalKind::effect},
             std::pair{"reclaimed_no_effect_successor_witness", TerminalKind::no_effect}}) {
        const auto terminal = state(kind);
        auto evidence = empty(terminal);
        complete_witness(evidence);
        complete_floor(evidence);
        evidence.reclamation_requested = true;
        add(std::string(name), terminal, evidence, ContinuityCode::accepted_successor_witness_continuity);
    }
    {
        const auto terminal = state();
        auto evidence = empty(terminal);
        complete_witness(evidence);
        complete_floor(evidence);
        add("successor_witness_continuity_no_gc", terminal, evidence, ContinuityCode::accepted_successor_witness_continuity);
    }
    for (const auto& [name, kind] : std::array<std::pair<std::string_view, TerminalKind>, 2U>{
             std::pair{"hybrid_effect_reclamation_ready", TerminalKind::effect},
             std::pair{"hybrid_no_effect_reclamation_ready", TerminalKind::no_effect}}) {
        const auto terminal = state(kind);
        auto evidence = empty(terminal);
        complete_record(evidence);
        complete_witness(evidence);
        complete_floor(evidence);
        evidence.reclamation_requested = true;
        add(std::string(name), terminal, evidence, ContinuityCode::accepted_hybrid_continuity);
    }
    {
        const auto terminal = state();
        auto evidence = empty(terminal);
        complete_floor(evidence);
        add("execution_only_successor_floor", terminal, evidence, ContinuityCode::accepted_execution_only);
    }
    {
        const auto terminal = state();
        auto evidence = empty(terminal);
        complete_record(evidence);
        evidence.terminal_record_independently_reopenable = false;
        add("execution_only_live_record_self_reopen", terminal, evidence, ContinuityCode::accepted_execution_only);
    }
    {
        const auto terminal = state();
        auto evidence = empty(terminal);
        complete_floor(evidence);
        complete_witness(evidence);
        evidence.terminal_witness_independently_reopenable = false;
        evidence.reclamation_requested = true;
        add("execution_only_weak_witness", terminal, evidence, ContinuityCode::accepted_execution_only);
    }
    {
        const auto terminal = state();
        auto evidence = empty(terminal);
        complete_floor(evidence);
        evidence.client_acknowledged = true;
        add("execution_only_floor_with_ack", terminal, evidence, ContinuityCode::accepted_execution_only);
    }
    {
        const auto terminal = state();
        auto evidence = empty(terminal);
        complete_witness(evidence);
        add("history_only_archived_witness", terminal, evidence, ContinuityCode::accepted_history_only);
    }
    {
        const auto terminal = state();
        auto evidence = empty(terminal);
        complete_record(evidence);
        evidence.terminal_record_fences_pending = false;
        add("history_only_live_record_without_pending_fence", terminal, evidence, ContinuityCode::accepted_history_only);
    }
    {
        const auto terminal = state();
        auto evidence = empty(terminal);
        complete_witness(evidence);
        complete_floor(evidence);
        evidence.restore_preserves_floor = false;
        add("history_only_floor_lost_on_restore", terminal, evidence, ContinuityCode::accepted_history_only);
    }
    {
        const auto terminal = state();
        auto evidence = empty(terminal);
        evidence.ttl_expired = true;
        add("neither_ttl_expiry", terminal, evidence, ContinuityCode::accepted_neither);
    }
    {
        const auto terminal = state();
        auto evidence = empty(terminal);
        evidence.client_acknowledged = true;
        add("neither_client_ack", terminal, evidence, ContinuityCode::accepted_neither);
    }
    {
        const auto terminal = state();
        auto evidence = empty(terminal);
        complete_record(evidence);
        complete_witness(evidence);
        complete_floor(evidence);
        evidence.equivocation_observed = true;
        evidence.reclamation_requested = true;
        add("equivocation_fail_stop", terminal, evidence, ContinuityCode::accepted_equivocation_fail_stop);
    }

    for (const auto& [name, index] : std::array<std::pair<std::string_view, std::size_t>, 4U>{
             std::pair{"zero_request_state", 0U},
             std::pair{"zero_transition_state", 1U},
             std::pair{"zero_incarnation_state", 2U},
             std::pair{"zero_terminal_state", 3U}}) {
        auto terminal = state();
        if (index == 0U) terminal.request_id = Digest{};
        if (index == 1U) terminal.transition_digest = Digest{};
        if (index == 2U) terminal.register_incarnation = Digest{};
        if (index == 3U) terminal.terminal_digest = Digest{};
        add(std::string(name), terminal, empty(terminal), ContinuityCode::invalid_state);
    }
    {
        const auto terminal = state();
        auto evidence = empty(terminal);
        evidence.request_id = digest(0x12U);
        add("wrong_request_id", terminal, evidence, ContinuityCode::request_id_mismatch);
    }
    {
        const auto terminal = state();
        auto evidence = empty(terminal);
        evidence.transition_digest = digest(0x32U);
        add("wrong_transition_digest", terminal, evidence, ContinuityCode::transition_digest_mismatch);
    }
    {
        const auto terminal = state();
        auto evidence = empty(terminal);
        evidence.register_incarnation = digest(0x52U);
        add("wrong_register_incarnation", terminal, evidence, ContinuityCode::register_incarnation_mismatch);
    }
    {
        const auto terminal = state();
        auto evidence = empty(terminal);
        evidence.terminal_digest = digest(0x72U);
        add("wrong_terminal_digest", terminal, evidence, ContinuityCode::terminal_digest_mismatch);
    }
    {
        const auto terminal = state(TerminalKind::effect);
        auto evidence = empty(terminal);
        evidence.terminal_kind = TerminalKind::no_effect;
        add("wrong_terminal_kind", terminal, evidence, ContinuityCode::terminal_kind_mismatch);
    }

    const std::array<std::pair<std::string_view, void (*)(ContinuityEvidence&)>, 9U> record_invalid{{
        {"orphan_record_authenticated", [](ContinuityEvidence& v) { v.terminal_record_authenticated = true; }},
        {"orphan_record_durable", [](ContinuityEvidence& v) { v.terminal_record_durable = true; }},
        {"orphan_record_serialized", [](ContinuityEvidence& v) { v.terminal_record_serialized = true; }},
        {"orphan_record_single_view", [](ContinuityEvidence& v) { v.terminal_record_single_view = true; }},
        {"orphan_record_retained", [](ContinuityEvidence& v) { v.terminal_record_retained_full_horizon = true; }},
        {"orphan_record_pending_fence", [](ContinuityEvidence& v) { v.terminal_record_fences_pending = true; }},
        {"orphan_record_restore", [](ContinuityEvidence& v) { v.terminal_record_survives_restore = true; }},
        {"orphan_record_succession", [](ContinuityEvidence& v) { v.terminal_record_survives_succession = true; }},
        {"orphan_record_reopen", [](ContinuityEvidence& v) { v.terminal_record_independently_reopenable = true; }},
    }};
    for (const auto& [name, mutate] : record_invalid) {
        const auto terminal = state();
        auto evidence = empty(terminal);
        mutate(evidence);
        add(std::string(name), terminal, evidence, ContinuityCode::terminal_record_shape_invalid);
    }

    const std::array<std::pair<std::string_view, void (*)(ContinuityEvidence&)>, 6U> witness_invalid{{
        {"orphan_witness_authenticated", [](ContinuityEvidence& v) { v.terminal_witness_authenticated = true; }},
        {"orphan_witness_binding", [](ContinuityEvidence& v) { v.terminal_witness_binds_terminal = true; }},
        {"orphan_witness_durable", [](ContinuityEvidence& v) { v.terminal_witness_durable = true; }},
        {"orphan_witness_reopen", [](ContinuityEvidence& v) { v.terminal_witness_independently_reopenable = true; }},
        {"orphan_witness_restore", [](ContinuityEvidence& v) { v.terminal_witness_survives_restore = true; }},
        {"orphan_witness_succession", [](ContinuityEvidence& v) { v.terminal_witness_survives_succession = true; }},
    }};
    for (const auto& [name, mutate] : witness_invalid) {
        const auto terminal = state();
        auto evidence = empty(terminal);
        mutate(evidence);
        add(std::string(name), terminal, evidence, ContinuityCode::terminal_witness_shape_invalid);
    }

    const std::array<std::pair<std::string_view, void (*)(ContinuityEvidence&)>, 9U> floor_invalid{{
        {"orphan_floor_authenticated", [](ContinuityEvidence& v) { v.successor_floor_authenticated = true; }},
        {"orphan_floor_monotone", [](ContinuityEvidence& v) { v.successor_floor_monotone = true; }},
        {"orphan_floor_outside_restore", [](ContinuityEvidence& v) { v.successor_floor_outside_restore_domain = true; }},
        {"orphan_floor_namespace", [](ContinuityEvidence& v) { v.successor_floor_binds_request_namespace = true; }},
        {"orphan_floor_rejects_old", [](ContinuityEvidence& v) { v.old_incarnation_rejected = true; }},
        {"orphan_floor_pending_fence", [](ContinuityEvidence& v) { v.pending_invocations_fenced = true; }},
        {"orphan_floor_restore", [](ContinuityEvidence& v) { v.restore_preserves_floor = true; }},
        {"orphan_floor_succession", [](ContinuityEvidence& v) { v.succession_preserves_floor = true; }},
        {"orphan_floor_single_view", [](ContinuityEvidence& v) { v.successor_floor_single_view = true; }},
    }};
    for (const auto& [name, mutate] : floor_invalid) {
        const auto terminal = state();
        auto evidence = empty(terminal);
        mutate(evidence);
        add(std::string(name), terminal, evidence, ContinuityCode::successor_floor_shape_invalid);
    }
    return values;
}

[[nodiscard]] std::string truth(const bool value) {
    return value ? "true" : "false";
}

[[nodiscard]] bool write_text(const std::filesystem::path& path, const std::string& text) {
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    output.write(text.data(), static_cast<std::streamsize>(text.size()));
    return output.good();
}

}  // namespace

bool run_campaign(const std::filesystem::path& output_directory) {
    std::error_code error;
    if (std::filesystem::exists(output_directory, error)
        && !std::filesystem::is_empty(output_directory, error)) {
        return false;
    }
    std::filesystem::create_directories(output_directory, error);
    if (error) {
        return false;
    }

    const auto test_cases = cases();
    if (test_cases.size() != 52U) {
        return false;
    }
    std::string table =
        "case\tterminal_kind\texact_request\texact_transition\texact_incarnation\texact_terminal\texact_kind\t"
        "record_present\trecord_authenticated\trecord_durable\trecord_serialized\trecord_single_view\t"
        "record_retained_full_horizon\trecord_fences_pending\trecord_survives_restore\trecord_survives_succession\trecord_independent_reopen\t"
        "witness_present\twitness_authenticated\twitness_binds_terminal\twitness_durable\twitness_independent_reopen\twitness_survives_restore\twitness_survives_succession\t"
        "floor_present\tfloor_authenticated\tfloor_monotone\tfloor_outside_restore\tfloor_binds_namespace\told_incarnation_rejected\tpending_invocations_fenced\t"
        "restore_preserves_floor\tsuccession_preserves_floor\tfloor_single_view\treclamation_requested\tclient_acknowledged\tttl_expired\tequivocation_observed\t"
        "candidate_code\treference_code\tagreement\taccepted\trecord_execution_path\trecord_history_path\twitness_history_path\tfloor_execution_path\t"
        "duplicate_execution_excluded\tterminal_outcome_reopenable\tterminal_continuity\treclamation_safe\tfail_stopped\tclient_ack_sufficient\tttl_sufficient\tauthority\n";

    std::size_t accepted = 0U;
    std::size_t continuity = 0U;
    std::size_t execution_only = 0U;
    std::size_t history_only = 0U;
    std::size_t neither = 0U;
    std::size_t fail_stopped = 0U;
    std::size_t reclamation_safe = 0U;
    for (const auto& item : test_cases) {
        const auto candidate = evaluate_candidate(item.state, item.evidence);
        const auto reference = evaluate_reference(item.state, item.evidence);
        if (candidate != reference || candidate.code != item.expected) {
            return false;
        }
        accepted += candidate.accepted ? 1U : 0U;
        continuity += candidate.accepted && candidate.terminal_continuity ? 1U : 0U;
        execution_only += candidate.accepted && candidate.duplicate_execution_excluded
            && !candidate.terminal_outcome_reopenable ? 1U : 0U;
        history_only += candidate.accepted && !candidate.duplicate_execution_excluded
            && candidate.terminal_outcome_reopenable ? 1U : 0U;
        neither += candidate.accepted && !candidate.duplicate_execution_excluded
            && !candidate.terminal_outcome_reopenable && !candidate.fail_stopped ? 1U : 0U;
        fail_stopped += candidate.accepted && candidate.fail_stopped ? 1U : 0U;
        reclamation_safe += candidate.accepted && candidate.reclamation_safe ? 1U : 0U;
        if (candidate.client_ack_sufficient
            || candidate.ttl_sufficient
            || candidate.external_occurrence_proved
            || candidate.currentness_proved
            || candidate.independent_custody_proved
            || candidate.epoch_exit_proved
            || candidate.authority_granted) {
            return false;
        }
        table += item.name + "\t"
            + std::string(terminal_kind_name(item.state.terminal_kind)) + "\t"
            + truth(item.evidence.request_id == item.state.request_id) + "\t"
            + truth(item.evidence.transition_digest == item.state.transition_digest) + "\t"
            + truth(item.evidence.register_incarnation == item.state.register_incarnation) + "\t"
            + truth(item.evidence.terminal_digest == item.state.terminal_digest) + "\t"
            + truth(item.evidence.terminal_kind == item.state.terminal_kind) + "\t"
            + truth(item.evidence.terminal_record_present) + "\t"
            + truth(item.evidence.terminal_record_authenticated) + "\t"
            + truth(item.evidence.terminal_record_durable) + "\t"
            + truth(item.evidence.terminal_record_serialized) + "\t"
            + truth(item.evidence.terminal_record_single_view) + "\t"
            + truth(item.evidence.terminal_record_retained_full_horizon) + "\t"
            + truth(item.evidence.terminal_record_fences_pending) + "\t"
            + truth(item.evidence.terminal_record_survives_restore) + "\t"
            + truth(item.evidence.terminal_record_survives_succession) + "\t"
            + truth(item.evidence.terminal_record_independently_reopenable) + "\t"
            + truth(item.evidence.terminal_witness_present) + "\t"
            + truth(item.evidence.terminal_witness_authenticated) + "\t"
            + truth(item.evidence.terminal_witness_binds_terminal) + "\t"
            + truth(item.evidence.terminal_witness_durable) + "\t"
            + truth(item.evidence.terminal_witness_independently_reopenable) + "\t"
            + truth(item.evidence.terminal_witness_survives_restore) + "\t"
            + truth(item.evidence.terminal_witness_survives_succession) + "\t"
            + truth(item.evidence.successor_floor_present) + "\t"
            + truth(item.evidence.successor_floor_authenticated) + "\t"
            + truth(item.evidence.successor_floor_monotone) + "\t"
            + truth(item.evidence.successor_floor_outside_restore_domain) + "\t"
            + truth(item.evidence.successor_floor_binds_request_namespace) + "\t"
            + truth(item.evidence.old_incarnation_rejected) + "\t"
            + truth(item.evidence.pending_invocations_fenced) + "\t"
            + truth(item.evidence.restore_preserves_floor) + "\t"
            + truth(item.evidence.succession_preserves_floor) + "\t"
            + truth(item.evidence.successor_floor_single_view) + "\t"
            + truth(item.evidence.reclamation_requested) + "\t"
            + truth(item.evidence.client_acknowledged) + "\t"
            + truth(item.evidence.ttl_expired) + "\t"
            + truth(item.evidence.equivocation_observed) + "\t"
            + std::string(continuity_code_name(candidate.code)) + "\t"
            + std::string(continuity_code_name(reference.code)) + "\ttrue\t"
            + truth(candidate.accepted) + "\t"
            + truth(candidate.terminal_record_execution_path) + "\t"
            + truth(candidate.terminal_record_history_path) + "\t"
            + truth(candidate.terminal_witness_history_path) + "\t"
            + truth(candidate.successor_floor_execution_path) + "\t"
            + truth(candidate.duplicate_execution_excluded) + "\t"
            + truth(candidate.terminal_outcome_reopenable) + "\t"
            + truth(candidate.terminal_continuity) + "\t"
            + truth(candidate.reclamation_safe) + "\t"
            + truth(candidate.fail_stopped) + "\t"
            + truth(candidate.client_ack_sufficient) + "\t"
            + truth(candidate.ttl_sufficient) + "\t"
            + truth(candidate.authority_granted) + "\n";
    }
    if (accepted != 19U || continuity != 9U || execution_only != 4U
        || history_only != 3U || neither != 2U || fail_stopped != 1U
        || reclamation_safe != 4U) {
        return false;
    }

    const std::string summary =
        "{\n"
        "  \"accepted_cases\": 19,\n"
        "  \"authority_granted\": false,\n"
        "  \"candidate_reference_disagreements\": 0,\n"
        "  \"cases\": 52,\n"
        "  \"client_ack_sufficient_cases\": 0,\n"
        "  \"currentness_proved\": false,\n"
        "  \"duplicate_execution_excluded_cases\": 13,\n"
        "  \"epoch_exit_proved\": false,\n"
        "  \"execution_only_cases\": 4,\n"
        "  \"external_occurrence_proved\": false,\n"
        "  \"fail_stopped_cases\": 1,\n"
        "  \"history_only_cases\": 3,\n"
        "  \"independent_custody_proved\": false,\n"
        "  \"neither_cases\": 2,\n"
        "  \"reclamation_safe_cases\": 4,\n"
        "  \"rejected_cases\": 33,\n"
        "  \"schema\": \"slopos.rev0917.terminal-outcome-continuity-campaign.v1\",\n"
        "  \"terminal_continuity_cases\": 9,\n"
        "  \"terminal_outcome_reopenable_cases\": 12,\n"
        "  \"ttl_sufficient_cases\": 0\n"
        "}\n";
    const std::string counterhistories =
        "row\tconstruction\tevent\tduplicate_execution_excluded\tterminal_outcome_reopenable\tterminal_continuity\tjudgment\n"
        "E0\texecution_only\tterminal_record_reclaimed_after_successor_floor\ttrue\tfalse\tfalse\told request rejected but exact outcome history lost\n"
        "E1\texecution_only\tindependent_reopener_observes_only_floor\ttrue\tfalse\tfalse\tnew incarnation safety does not reconstruct old result\n"
        "H0\thistory_only\texact_terminal_witness_archived\tfalse\ttrue\tfalse\tresult known but no execution fence exists\n"
        "H1\thistory_only\tpreterminal_snapshot_restored_and_old_request_accepted\tfalse\ttrue\tfalse\thistory retention does not prevent replay\n"
        "T0\tttl_only\tprovider_result_exists_before_expiry\tfalse\tfalse\tfalse\tfinite memory is not succession law\n"
        "T1\tttl_only\tresult_and_duplicate_metadata_expire\tfalse\tfalse\tfalse\ttime passage creates no exact fence or witness\n"
        "S0\tsafe_succession\texact_terminal_witness_exported_before_reclamation\tfalse\ttrue\tfalse\thistory half established first\n"
        "S1\tsafe_succession\tnonrollback_successor_floor_fences_old_and_pending_requests\ttrue\ttrue\ttrue\tboth halves survive restore succession and independent reopen\n";
    const std::string quadrants =
        "duplicate_execution_excluded\tterminal_outcome_reopenable\tname\tterminal_continuity\treclamation_judgment\n"
        "true\ttrue\tcontinuous\ttrue\teligible only with exact witness plus successor floor\n"
        "true\tfalse\texecution_only\tfalse\tdo not reclaim history\n"
        "false\ttrue\thistory_only\tfalse\tdo not admit one-use terminality\n"
        "false\tfalse\tneither\tfalse\tremain unresolved or fail stopped\n";
    const std::string invariants =
        "TERMINAL_CONTINUITY_EQUALS_EXECUTION_EXCLUDED_AND_OUTCOME_REOPENABLE=true\n"
        "EXECUTION_FENCE_DOES_NOT_IMPLY_HISTORY=true\n"
        "OUTCOME_WITNESS_DOES_NOT_IMPLY_EXECUTION_FENCE=true\n"
        "CLIENT_ACK_SUFFICIENT=false\n"
        "TTL_EXPIRY_SUFFICIENT=false\n"
        "SUCCESSOR_FLOOR_MUST_BIND_REQUEST_NAMESPACE=true\n"
        "SUCCESSOR_FLOOR_MUST_FENCE_PENDING_INVOCATIONS=true\n"
        "SUCCESSOR_FLOOR_MUST_SURVIVE_RESTORE_AND_SUCCESSION=true\n"
        "TERMINAL_WITNESS_MUST_BIND_EXACT_OUTCOME=true\n"
        "TERMINAL_WITNESS_MUST_BE_INDEPENDENTLY_REOPENABLE=true\n"
        "EQUIVOCATION_FAILS_STOP=true\n"
        "RECLAMATION_SAFE_REQUIRES_WITNESS_AND_SUCCESSOR_FLOOR=true\n"
        "EXTERNAL_OCCURRENCE_PROVED=false\n"
        "AUTHORITY_GRANTED=false\n";

    return write_text(output_directory / "CASES.tsv", table)
        && write_text(output_directory / "SUMMARY.json", summary)
        && write_text(output_directory / "COUNTERHISTORIES.tsv", counterhistories)
        && write_text(output_directory / "QUADRANTS.tsv", quadrants)
        && write_text(output_directory / "INVARIANTS.txt", invariants);
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity
