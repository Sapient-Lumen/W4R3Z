# Root-succession capsule v1

**Status:** hosted Epoch-Zero mechanism and countermodel. **Authority:** false.

This specification defines one finite relation for an exact root edge
`manifest(N) -> manifest(N+1)`. It reuses the 384-byte owner-manifest observation
from `SIGNED-ADMISSION-V1.md`. All integers are unsigned big-endian, every
reserved byte is zero, and every digest is
`SHA256(UTF8(domain) || 0x00 || payload)`.

The construction deliberately separates three questions:

1. **Is this exact edge cryptographically admissible under the supplied old and
   new manifests?** The capsule can answer this locally.
2. **Did this local register apply the edge?** The hosted compare-and-apply model
   can answer this for one process image.
3. **Is the successor the unique, owner-constituted, externally current SlopOS
   root?** No input or mechanism in this capsule can answer this.

## Root-succession statement — 320 bytes

| Offset | Width | Field |
|---:|---:|---|
| 0 | 8 | `SLOPRS01` |
| 8 | 2 | version `1` |
| 10 | 2 | kind `4` |
| 12 | 4 | length `320` |
| 16 | 1 | purpose `1` = adjacent root succession |
| 17 | 1 | suite `1` = Ed25519 |
| 18 | 14 | reserved |
| 32 | 32 | project identifier |
| 64 | 32 | exact predecessor-manifest head |
| 96 | 32 | exact successor-manifest head |
| 128 | 32 | precommitted successor-manifest head |
| 160 | 32 | root-register identifier |
| 192 | 32 | ceremony identifier observation |
| 224 | 8 | predecessor version `N` |
| 232 | 8 | successor version `N+1` |
| 240 | 8 | not-before time |
| 248 | 8 | exclusive expiry time |
| 256 | 8 | transition nonce |
| 264 | 24 | reserved |
| 288 | 32 | statement integrity over bytes `0..287` |

The statement is canonical only when all six digest fields are nonzero,
`N` is nonzero and not `UINT64_MAX`, the successor version is nonzero,
`not_before < expires_at`, and the nonce is nonzero. Canonicality alone does not
assert that the named ceremony occurred.

The statement head is
`SHA256("SlopOS/root-succession/statement-head/v1" || 0x00 || statement)`.

## Dual-threshold envelope — 1,024 bytes

| Offset | Width | Field |
|---:|---:|---|
| 0 | 8 | `SLOPRE01` |
| 8 | 2 | version `1` |
| 10 | 2 | kind `5` |
| 12 | 4 | length `1024` |
| 16 | 1 | predecessor signature count, `1..3` |
| 17 | 1 | successor signature count, `1..3` |
| 18 | 1 | suite `1` = Ed25519 |
| 19 | 13 | reserved |
| 32 | 320 | exact root-succession statement |
| 352 | 288 | three predecessor `(key_id[32], signature[64])` slots |
| 640 | 288 | three successor `(key_id[32], signature[64])` slots |
| 928 | 64 | reserved |
| 992 | 32 | envelope integrity over bytes `0..991` |

The fixed 360-byte signed message is:

```
zero-pad-to-32("SlopOS/root-succession/v1/DTE")
|| uint64_be(320)
|| exact_statement_bytes
```

Each side is evaluated independently against its own manifest. An active key ID
must resolve to the exact public key recorded in that manifest; signatures are
verified with Ed25519; a repeated key ID is rejected; and only verified distinct
manifest members count toward that manifest's threshold. The two manifest key
sets may overlap. Overlap does not weaken byte-level validity, but it also shows
why two mathematical thresholds do not prove two independent custody domains.

## Evidence-valid relation

`evidence_valid` requires, in order:

1. canonical predecessor and successor manifests;
2. canonical envelope and statement;
3. one project identifier across both manifests and the statement;
4. successor `predecessor_manifest` equal to the exact predecessor head;
5. successor version exactly predecessor version plus one, with both statement
   versions equal to their manifests;
6. statement predecessor and successor heads equal to the exact supplied
   manifest heads;
7. statement precommit equal to the exact successor head;
8. `not_before <= observed_time < expires_at`;
9. predecessor threshold satisfied by distinct valid signatures; and
10. successor threshold satisfied by distinct valid signatures.

Evaluation is fail-closed and preserves a diagnostic code for the first failed
predicate. A valid result still fixes all of these fields to false:

- `owner_constitution_proved`;
- `currentness_proved`;
- `independent_custody_proved`;
- `protected_transition_proved`;
- `independent_reopen_proved`;
- `epoch_exit_proved`;
- `authority_granted`.

## Hosted current-root register — 112 harness bytes

The campaign serializes its in-memory register for independent replay:

| Offset | Width | Field |
|---:|---:|---|
| 0 | 32 | register identifier |
| 32 | 32 | locally current manifest head |
| 64 | 32 | locally precommitted successor head |
| 96 | 8 | locally current version |
| 104 | 8 | transition ordinal |

After valid evidence, the local apply relation checks the register identifier,
returns an idempotent query-only result when the successor is already current,
requires exact predecessor head/version and exact register precommit, rejects
ordinal overflow, then changes head/version, increments the ordinal, and clears
the precommit. A simulated reply cut after mutation returns
`uncertain_after_commit_query_only`; callers must query rather than retry an
effect blindly.

This register is not durable or protected evidence. Its byte encoding is a
harness observation, not a persistence protocol, rollback floor, consensus
register, hardware root, or owner-administered service.

## Transition receipt — 256 bytes

| Offset | Width | Field |
|---:|---:|---|
| 0 | 8 | `SLOPRR01` |
| 8 | 2 | version `1` |
| 10 | 2 | kind `6` |
| 12 | 4 | length `256` |
| 16 | 1 | disposition: committed/already-current/uncertain-after-commit |
| 17 | 1 | query-only flag |
| 18 | 14 | reserved |
| 32 | 32 | register identifier |
| 64 | 32 | predecessor-manifest head |
| 96 | 32 | successor-manifest head |
| 128 | 32 | statement head |
| 160 | 32 | ceremony identifier |
| 192 | 8 | predecessor version |
| 200 | 8 | successor version |
| 208 | 8 | transition ordinal |
| 216 | 8 | observed time |
| 224 | 32 | receipt integrity over bytes `0..223` |

A receipt is a deterministic local observation. It is not signed by an
independent reopener and does not prove that another clone, restore, operator,
or rollback domain agrees.

## Retained campaign

The campaign contains 28 cases: eight cryptographically valid edge observations
and twenty rejected observations. Four valid cases commit a local transition;
two return query-only dispositions. The corpus covers 2-of-3 and 3-of-3 edges,
overlapping old/new key sets, stale and wrong registers, register-precommit
mismatch, idempotent recovery, reply loss, malformed inputs, project/chain/head
substitutions, version stasis and skips, time failures, unknown/duplicate/invalid
signers, and below-threshold evidence.

Candidate and separately spelled C++ relations agree on every case. A separate
Python implementation reparses all bytes, verifies Ed25519 with
`cryptography`, replays every register transition, and reconstructs every
receipt.
