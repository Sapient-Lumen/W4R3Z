#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/reopen_receipt_chain/external_premise_admission/control_fate_falsification/relocatable_provenance/observed_output_closure/hosted_externality_nonderivation/detached_response_aperture.hpp"

#include "slopos/e0/generation_journal/spend_record.hpp"

#include <openssl/evp.h>

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <span>
#include <string_view>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification::relocatable_provenance::observed_output_closure::hosted_externality_nonderivation::detached_response_aperture {
namespace {

#ifndef SLOPOS_DRA_RESPONSE_SHAPE_POLICY_SHA256_HEX
#error "exact response-shape policy binding required"
#endif
#ifndef SLOPOS_DRA_TRUST_CONFIGURATION_POLICY_SHA256_HEX
#error "exact trust-configuration policy binding required"
#endif
#ifndef SLOPOS_DRA_CONSUMPTION_FENCE_POLICY_SHA256_HEX
#error "exact consumption-fence policy binding required"
#endif
#ifndef SLOPOS_DRA_REOPENER_IMPLEMENTATION_SHA256_HEX
#error "exact reopener implementation binding required"
#endif
#ifndef SLOPOS_DRA_LINKED_PARENT_ARCHIVE_SHA256_HEX
#error "exact linked parent archive binding required"
#endif
#ifndef SLOPOS_DRA_LINKED_PARENT_ARCHIVE_BYTES
#error "exact linked parent archive byte count required"
#endif
#ifndef SLOPOS_DRA_LINKED_PARENT_MANIFEST_ROWS
#error "exact linked parent manifest rows required"
#endif

inline constexpr std::uint16_t all_missing_premises_mask = 0x003fU;

[[nodiscard]] constexpr std::uint8_t hex_nibble(const char value) noexcept {
    if (value >= '0' && value <= '9') return static_cast<std::uint8_t>(value - '0');
    if (value >= 'a' && value <= 'f') return static_cast<std::uint8_t>(value - 'a' + 10);
    return 0xffU;
}

[[nodiscard]] Digest exact_digest(const std::string_view value) noexcept {
    Digest output{};
    if (value.size() != 64U) return output;
    for (std::size_t index = 0U; index < output.size(); ++index) {
        const auto high = hex_nibble(value[index * 2U]);
        const auto low = hex_nibble(value[index * 2U + 1U]);
        if (high > 15U || low > 15U) return {};
        output[index] = static_cast<std::uint8_t>((high << 4U) | low);
    }
    return output;
}


[[nodiscard]] bool nonzero(const Digest& value) noexcept {
    std::uint8_t aggregate = 0U;
    for (const auto byte : value) aggregate = static_cast<std::uint8_t>(aggregate | byte);
    return aggregate != 0U;
}

[[nodiscard]] bool nonzero(const Signature& value) noexcept {
    std::uint8_t aggregate = 0U;
    for (const auto byte : value) aggregate = static_cast<std::uint8_t>(aggregate | byte);
    return aggregate != 0U;
}

template <std::size_t Size>
class CanonicalWriter final {
public:
    explicit CanonicalWriter(std::array<std::uint8_t, Size>& output) noexcept : output_(output) {
        output_.fill(0U);
    }

    void magic(const std::string_view value) noexcept {
        for (std::size_t index = 0U; index < 8U; ++index) {
            u8(index < value.size() ? static_cast<std::uint8_t>(value[index]) : 0U);
        }
    }
    void u8(const std::uint8_t value) noexcept { put(value); }
    void u16(const std::uint16_t value) noexcept {
        put(static_cast<std::uint8_t>((value >> 8U) & 0xffU));
        put(static_cast<std::uint8_t>(value & 0xffU));
    }
    void u32(const std::uint32_t value) noexcept {
        put(static_cast<std::uint8_t>((value >> 24U) & 0xffU));
        put(static_cast<std::uint8_t>((value >> 16U) & 0xffU));
        put(static_cast<std::uint8_t>((value >> 8U) & 0xffU));
        put(static_cast<std::uint8_t>(value & 0xffU));
    }
    void u64(const std::uint64_t value) noexcept {
        for (unsigned shift = 56U;; shift -= 8U) {
            put(static_cast<std::uint8_t>((value >> shift) & 0xffU));
            if (shift == 0U) break;
        }
    }
    void digest(const Digest& value) noexcept { bytes(value); }
    void public_key(const PublicKey& value) noexcept { bytes(value); }
    void signature(const Signature& value) noexcept { bytes(value); }
    template <std::size_t Count>
    void bytes(const std::array<std::uint8_t, Count>& value) noexcept {
        for (const auto byte : value) put(byte);
    }
    [[nodiscard]] bool pad_to_end() noexcept {
        while (offset_ < Size) put(0U);
        return valid_ && offset_ == Size;
    }

private:
    void put(const std::uint8_t value) noexcept {
        if (offset_ >= Size) {
            valid_ = false;
            return;
        }
        output_[offset_++] = value;
    }

    std::array<std::uint8_t, Size>& output_;
    std::size_t offset_{0U};
    bool valid_{true};
};

[[nodiscard]] Digest digest_bytes(const std::span<const std::uint8_t> bytes) noexcept {
    return generation_journal::sha256(bytes);
}

[[nodiscard]] std::uint16_t response_flags(const LabResponseFixture& value) noexcept {
    return static_cast<std::uint16_t>((value.present ? 1U : 0U)
        | (value.canonical ? 2U : 0U)
        | (value.laboratory_fixture ? 4U : 0U)
        | (value.detached_from_request ? 8U : 0U)
        | (value.external_occurrence_claimed ? 16U : 0U)
        | (value.trust_anchor_embedded ? 32U : 0U));
}

[[nodiscard]] std::uint16_t publication_flags(const ModeledPublicationReceipt& value) noexcept {
    return static_cast<std::uint16_t>((value.present ? 1U : 0U)
        | (value.canonical ? 2U : 0U)
        | (value.durable ? 4U : 0U)
        | (value.no_replace ? 8U : 0U)
        | (value.model_only ? 16U : 0U)
        | (value.external_occurrence_claimed ? 32U : 0U));
}

[[nodiscard]] std::uint16_t reopen_flags(const ModeledReopenReceipt& value) noexcept {
    return static_cast<std::uint16_t>((value.present ? 1U : 0U)
        | (value.canonical ? 2U : 0U)
        | (value.durable ? 4U : 0U)
        | (value.exact_response_rehashed ? 8U : 0U)
        | (value.separate_role_label ? 16U : 0U)
        | (value.model_only ? 32U : 0U)
        | (value.administrative_independence_claimed ? 64U : 0U));
}

[[nodiscard]] std::uint16_t configuration_flags(const TrustConfiguration& value) noexcept {
    return static_cast<std::uint16_t>((value.present ? 1U : 0U)
        | (value.canonical ? 2U : 0U)
        | (value.laboratory_configuration ? 4U : 0U)
        | (value.embedded_in_response ? 8U : 0U)
        | (value.external_provisioning_claimed ? 16U : 0U));
}

[[nodiscard]] std::uint16_t appraisal_flags(const AppraisalWitness& value) noexcept {
    return static_cast<std::uint16_t>((value.present ? 1U : 0U)
        | (value.canonical ? 2U : 0U)
        | (value.same_response_bytes ? 4U : 0U)
        | (value.opposite_policy_appraisals ? 8U : 0U)
        | (value.successor_currentness_rejected ? 16U : 0U)
        | (value.model_only ? 32U : 0U)
        | (value.no_external_trust_claim ? 64U : 0U));
}

[[nodiscard]] std::uint16_t deficit_flags(const ConsumptionDeficit& value) noexcept {
    return static_cast<std::uint16_t>((value.present ? 1U : 0U)
        | (value.canonical ? 2U : 0U)
        | (value.prior_appraisal_not_current ? 4U : 0U)
        | (value.external_response_absent ? 8U : 0U)
        | (value.external_trust_configuration_absent ? 16U : 0U)
        | (value.owner_admission_absent ? 32U : 0U)
        | (value.no_authority_claim ? 64U : 0U));
}

[[nodiscard]] bool claim_partition_valid(const LabResponseFixture& value) noexcept {
    const auto overlap = static_cast<std::uint16_t>(
        (value.accepted_claim_mask & value.rejected_claim_mask)
        | (value.accepted_claim_mask & value.unresolved_claim_mask)
        | (value.rejected_claim_mask & value.unresolved_claim_mask));
    const auto combined = static_cast<std::uint16_t>(
        value.accepted_claim_mask | value.rejected_claim_mask | value.unresolved_claim_mask);
    return overlap == 0U && combined == all_external_claims_mask;
}

[[nodiscard]] bool response_shape(const LabResponseFixture& value) noexcept {
    return value.present && value.canonical && value.laboratory_fixture
        && value.detached_from_request && !value.external_occurrence_claimed
        && value.schema_version == aperture_schema_version
        && value.linked_parent_archive_bytes == SLOPOS_DRA_LINKED_PARENT_ARCHIVE_BYTES
        && value.linked_parent_manifest_rows == SLOPOS_DRA_LINKED_PARENT_MANIFEST_ROWS
        && value.owner_root_version > 0U && value.not_before <= value.issued_at
        && value.issued_at < value.expires_at && nonzero(value.request_digest)
        && nonzero(value.linked_parent_archive_digest)
        && nonzero(value.parent_closure_claim_digest)
        && nonzero(value.claim_catalogue_digest)
        && nonzero(value.requested_response_profile_digest)
        && nonzero(value.owner_constitution_digest) && nonzero(value.owner_root_digest)
        && nonzero(value.appraisal_policy_digest) && nonzero(value.target_digest)
        && nonzero(value.response_namespace_digest) && nonzero(value.signer_public_key)
        && nonzero(value.signature);
}

[[nodiscard]] bool verify_response_signature(const LabResponseFixture& response) noexcept {
    EncodedResponseSigning message{};
    if (!encode_response_signing_message(response, message)) return false;
    using KeyPtr = std::unique_ptr<EVP_PKEY, decltype(&EVP_PKEY_free)>;
    using ContextPtr = std::unique_ptr<EVP_MD_CTX, decltype(&EVP_MD_CTX_free)>;
    KeyPtr key(EVP_PKEY_new_raw_public_key(
        EVP_PKEY_ED25519, nullptr, response.signer_public_key.data(), response.signer_public_key.size()),
        &EVP_PKEY_free);
    if (!key) return false;
    ContextPtr context(EVP_MD_CTX_new(), &EVP_MD_CTX_free);
    if (!context || EVP_DigestVerifyInit(context.get(), nullptr, nullptr, nullptr, key.get()) != 1) return false;
    return EVP_DigestVerify(context.get(), response.signature.data(), response.signature.size(),
        message.data(), message.size()) == 1;
}

[[nodiscard]] bool publication_shape(const ModeledPublicationReceipt& value) noexcept {
    return value.present && value.canonical && value.durable && value.no_replace
        && value.model_only && !value.external_occurrence_claimed
        && value.schema_version == aperture_schema_version && value.sequence > 0U
        && value.carrier_bytes == encoded_lab_response_bytes
        && nonzero(value.publication_namespace_digest) && nonzero(value.publisher_role_digest);
}

[[nodiscard]] bool reopen_shape(const ModeledReopenReceipt& value) noexcept {
    return value.present && value.canonical && value.durable && value.exact_response_rehashed
        && value.separate_role_label && value.model_only
        && !value.administrative_independence_claimed
        && value.schema_version == aperture_schema_version
        && value.carrier_bytes == encoded_lab_response_bytes
        && nonzero(value.reopener_role_digest);
}

[[nodiscard]] bool configuration_shape(const TrustConfiguration& value) noexcept {
    return value.present && value.canonical && value.laboratory_configuration
        && !value.external_provisioning_claimed
        && value.schema_version == aperture_schema_version
        && value.current_root_version > 0U && value.evaluation_time > 0U
        && value.required_accept_mask != 0U
        && (value.required_accept_mask & static_cast<std::uint16_t>(~all_external_claims_mask)) == 0U
        && (value.forbidden_reject_mask & static_cast<std::uint16_t>(~all_external_claims_mask)) == 0U
        && nonzero(value.owner_constitution_digest) && nonzero(value.current_owner_root_digest)
        && nonzero(value.appraisal_policy_digest) && nonzero(value.target_digest)
        && nonzero(value.response_namespace_digest) && nonzero(value.configuration_role_digest)
        && nonzero(value.trusted_signer_public_key);
}

[[nodiscard]] bool appraisal_shape(const AppraisalWitness& value) noexcept {
    return value.present && value.canonical && value.same_response_bytes
        && value.opposite_policy_appraisals && value.successor_currentness_rejected
        && value.model_only && value.no_external_trust_claim
        && value.schema_version == aperture_schema_version
        && value.appraisal_root_version > 0U
        && value.successor_root_version == value.appraisal_root_version + 1U;
}

[[nodiscard]] bool deficit_shape(const ConsumptionDeficit& value) noexcept {
    return value.present && value.canonical && value.prior_appraisal_not_current
        && value.external_response_absent && value.external_trust_configuration_absent
        && value.owner_admission_absent && value.no_authority_claim
        && value.schema_version == aperture_schema_version
        && value.missing_premise_mask == all_missing_premises_mask
        && value.appraisal_root_version > 0U
        && value.consumption_root_version == value.appraisal_root_version + 1U
        && value.consumption_time >= value.appraisal_time;
}

[[nodiscard]] bool cuts_match(const ApertureTrace& trace) noexcept {
    for (std::size_t index = 0U; index < trace.cuts.size(); ++index) {
        ApertureCut expected{};
        expected.parent_request_digest = trace.parent.request.request_digest;
        if (index >= 1U && trace.response.present) expected.response_digest = trace.response.response_digest;
        if (index >= 2U && trace.publication.present) expected.publication_receipt_digest = trace.publication.receipt_digest;
        if (index >= 3U && trace.reopen.present) expected.reopen_receipt_digest = trace.reopen.receipt_digest;
        if (index >= 4U && trace.accepting_configuration.present
            && trace.policy_reject_configuration.present && trace.successor_configuration.present) {
            expected.accepting_configuration_digest = trace.accepting_configuration.configuration_digest;
            expected.policy_reject_configuration_digest = trace.policy_reject_configuration.configuration_digest;
            expected.successor_configuration_digest = trace.successor_configuration.configuration_digest;
        }
        if (index >= 5U && trace.appraisal.present) expected.appraisal_witness_digest = trace.appraisal.witness_digest;
        if (index >= 6U && trace.deficit.present) expected.consumption_deficit_digest = trace.deficit.deficit_digest;
        if (expected != trace.cuts[index]) return false;
    }
    return true;
}

[[nodiscard]] ApertureReport finish(
    ApertureReport report, const ApertureCode code, const bool accepted) noexcept {
    report.code = code;
    report.accepted = accepted;
    return report;
}

}  // namespace

bool encode_response_signing_message(
    const LabResponseFixture& value, EncodedResponseSigning& output) noexcept {
    CanonicalWriter<encoded_response_signing_bytes> writer(output);
    writer.magic("DRARESP1");
    writer.u32(value.schema_version);
    writer.u16(response_flags(value));
    writer.u16(value.accepted_claim_mask);
    writer.u16(value.rejected_claim_mask);
    writer.u16(value.unresolved_claim_mask);
    writer.u64(value.linked_parent_archive_bytes);
    writer.u64(value.linked_parent_manifest_rows);
    writer.u64(value.owner_root_version);
    writer.u64(value.issued_at);
    writer.u64(value.not_before);
    writer.u64(value.expires_at);
    writer.digest(value.request_digest);
    writer.digest(value.linked_parent_archive_digest);
    writer.digest(value.parent_closure_claim_digest);
    writer.digest(value.claim_catalogue_digest);
    writer.digest(value.requested_response_profile_digest);
    writer.digest(value.owner_constitution_digest);
    writer.digest(value.owner_root_digest);
    writer.digest(value.appraisal_policy_digest);
    writer.digest(value.target_digest);
    writer.digest(value.response_namespace_digest);
    writer.public_key(value.signer_public_key);
    return writer.pad_to_end();
}

bool encode_lab_response(const LabResponseFixture& value, EncodedLabResponse& output) noexcept {
    EncodedResponseSigning signing{};
    if (!encode_response_signing_message(value, signing)) return false;
    std::copy(signing.begin(), signing.end(), output.begin());
    std::copy(value.signature.begin(), value.signature.end(), output.begin() + encoded_response_signing_bytes);
    return true;
}

Digest lab_response_identity(const LabResponseFixture& value) noexcept {
    EncodedLabResponse encoded{};
    if (!encode_lab_response(value, encoded)) return {};
    return digest_bytes(encoded);
}

bool encode_modeled_publication_receipt(
    const ModeledPublicationReceipt& value, EncodedPublicationReceipt& output) noexcept {
    CanonicalWriter<encoded_publication_receipt_bytes> writer(output);
    writer.magic("DRAPUB01");
    writer.u32(value.schema_version);
    writer.u16(publication_flags(value));
    writer.u64(value.sequence);
    writer.u64(value.carrier_bytes);
    writer.digest(value.response_digest);
    writer.digest(value.request_digest);
    writer.digest(value.linked_parent_archive_digest);
    writer.digest(value.publication_namespace_digest);
    writer.digest(value.publisher_role_digest);
    writer.digest(value.carrier_digest);
    writer.digest(value.publication_policy_digest);
    return writer.pad_to_end();
}

Digest modeled_publication_receipt_identity(const ModeledPublicationReceipt& value) noexcept {
    EncodedPublicationReceipt encoded{};
    if (!encode_modeled_publication_receipt(value, encoded)) return {};
    return digest_bytes(encoded);
}

bool encode_modeled_reopen_receipt(
    const ModeledReopenReceipt& value, EncodedReopenReceipt& output) noexcept {
    CanonicalWriter<encoded_reopen_receipt_bytes> writer(output);
    writer.magic("DRAREOP1");
    writer.u32(value.schema_version);
    writer.u16(reopen_flags(value));
    writer.u64(value.carrier_bytes);
    writer.digest(value.publication_receipt_digest);
    writer.digest(value.response_digest);
    writer.digest(value.request_digest);
    writer.digest(value.reopener_role_digest);
    writer.digest(value.reopener_implementation_digest);
    writer.digest(value.carrier_digest);
    writer.digest(value.reopen_policy_digest);
    return writer.pad_to_end();
}

Digest modeled_reopen_receipt_identity(const ModeledReopenReceipt& value) noexcept {
    EncodedReopenReceipt encoded{};
    if (!encode_modeled_reopen_receipt(value, encoded)) return {};
    return digest_bytes(encoded);
}

bool encode_trust_configuration(
    const TrustConfiguration& value, EncodedTrustConfiguration& output) noexcept {
    CanonicalWriter<encoded_trust_configuration_bytes> writer(output);
    writer.magic("DRACFG01");
    writer.u32(value.schema_version);
    writer.u16(configuration_flags(value));
    writer.u16(value.required_accept_mask);
    writer.u16(value.forbidden_reject_mask);
    writer.u64(value.current_root_version);
    writer.u64(value.evaluation_time);
    writer.digest(value.owner_constitution_digest);
    writer.digest(value.current_owner_root_digest);
    writer.digest(value.appraisal_policy_digest);
    writer.digest(value.target_digest);
    writer.digest(value.response_namespace_digest);
    writer.digest(value.configuration_role_digest);
    writer.public_key(value.trusted_signer_public_key);
    return writer.pad_to_end();
}

Digest trust_configuration_identity(const TrustConfiguration& value) noexcept {
    EncodedTrustConfiguration encoded{};
    if (!encode_trust_configuration(value, encoded)) return {};
    return digest_bytes(encoded);
}

bool encode_appraisal_witness(
    const AppraisalWitness& value, EncodedAppraisalWitness& output) noexcept {
    CanonicalWriter<encoded_appraisal_witness_bytes> writer(output);
    writer.magic("DRAAPP01");
    writer.u32(value.schema_version);
    writer.u16(appraisal_flags(value));
    writer.u8(static_cast<std::uint8_t>(value.accepting_result));
    writer.u8(static_cast<std::uint8_t>(value.policy_reject_result));
    writer.u8(static_cast<std::uint8_t>(value.successor_result));
    writer.u64(value.appraisal_root_version);
    writer.u64(value.successor_root_version);
    writer.digest(value.response_digest);
    writer.digest(value.publication_receipt_digest);
    writer.digest(value.reopen_receipt_digest);
    writer.digest(value.accepting_configuration_digest);
    writer.digest(value.policy_reject_configuration_digest);
    writer.digest(value.successor_configuration_digest);
    writer.digest(value.request_digest);
    writer.digest(value.appraisal_policy_digest);
    return writer.pad_to_end();
}

Digest appraisal_witness_identity(const AppraisalWitness& value) noexcept {
    EncodedAppraisalWitness encoded{};
    if (!encode_appraisal_witness(value, encoded)) return {};
    return digest_bytes(encoded);
}

bool encode_consumption_deficit(
    const ConsumptionDeficit& value, EncodedConsumptionDeficit& output) noexcept {
    CanonicalWriter<encoded_consumption_deficit_bytes> writer(output);
    writer.magic("DRADEF01");
    writer.u32(value.schema_version);
    writer.u16(deficit_flags(value));
    writer.u16(value.missing_premise_mask);
    writer.u64(value.appraisal_root_version);
    writer.u64(value.consumption_root_version);
    writer.u64(value.appraisal_time);
    writer.u64(value.consumption_time);
    writer.digest(value.response_digest);
    writer.digest(value.appraisal_witness_digest);
    writer.digest(value.accepting_configuration_digest);
    writer.digest(value.successor_configuration_digest);
    writer.digest(value.request_digest);
    writer.digest(value.appraised_owner_root_digest);
    writer.digest(value.consumption_owner_root_digest);
    writer.digest(value.consumption_policy_digest);
    return writer.pad_to_end();
}

Digest consumption_deficit_identity(const ConsumptionDeficit& value) noexcept {
    EncodedConsumptionDeficit encoded{};
    if (!encode_consumption_deficit(value, encoded)) return {};
    return digest_bytes(encoded);
}

AppraisalResult appraise_candidate(
    const LabResponseFixture& response, const TrustConfiguration& configuration) noexcept {
    if (!response_shape(response) || !claim_partition_valid(response)
        || lab_response_identity(response) != response.response_digest
        || !verify_response_signature(response)) {
        return AppraisalResult::malformed_response;
    }
    if (!configuration_shape(configuration)
        || trust_configuration_identity(configuration) != configuration.configuration_digest) {
        return AppraisalResult::malformed_configuration;
    }
    if (configuration.trusted_signer_public_key != response.signer_public_key) {
        return AppraisalResult::signer_untrusted;
    }
    if (configuration.owner_constitution_digest != response.owner_constitution_digest) {
        return AppraisalResult::constitution_mismatch;
    }
    if (configuration.current_owner_root_digest != response.owner_root_digest) {
        return AppraisalResult::owner_root_mismatch;
    }
    if (configuration.current_root_version != response.owner_root_version) {
        return AppraisalResult::root_version_mismatch;
    }
    if (configuration.appraisal_policy_digest != response.appraisal_policy_digest
        || configuration.response_namespace_digest != response.response_namespace_digest) {
        return AppraisalResult::policy_mismatch;
    }
    if (configuration.target_digest != response.target_digest) {
        return AppraisalResult::target_mismatch;
    }
    if (configuration.evaluation_time < response.not_before
        || configuration.evaluation_time < response.issued_at
        || configuration.evaluation_time >= response.expires_at) {
        return AppraisalResult::response_not_current;
    }
    if ((response.accepted_claim_mask & configuration.required_accept_mask)
        != configuration.required_accept_mask) {
        return AppraisalResult::required_claim_unresolved;
    }
    if ((response.rejected_claim_mask & configuration.forbidden_reject_mask) != 0U) {
        return AppraisalResult::rejected_claim_forbidden;
    }
    return AppraisalResult::accepted;
}

ApertureReport evaluate_candidate(const ApertureTrace& trace) noexcept {
    ApertureReport report{};
    const auto parent_report = hosted_externality_nonderivation::evaluate_candidate(trace.parent);
    report.parent_accepted = parent_report.accepted;
    report.parent_handoff_ready = parent_report.owner_handoff_ready;
    if (!parent_report.accepted) return finish(report, ApertureCode::parent_rejected, false);
    if (!parent_report.owner_handoff_ready) return finish(report, ApertureCode::parent_not_handoff_ready, false);

    report.cuts_ordered = cuts_match(trace);
    if (!report.cuts_ordered) return finish(report, ApertureCode::cut_order_invalid, false);
    if (trace.promote_fixture_to_external_response) {
        return finish(report, ApertureCode::hosted_response_promotion_forbidden, false);
    }
    if (trace.promote_appraisal_to_owner_admission) {
        return finish(report, ApertureCode::hosted_admission_promotion_forbidden, false);
    }
    if (trace.grant_authority) return finish(report, ApertureCode::authority_promotion_forbidden, false);

    if (!trace.response.present) {
        if (trace.publication.present || trace.reopen.present || trace.accepting_configuration.present
            || trace.policy_reject_configuration.present || trace.successor_configuration.present
            || trace.appraisal.present || trace.deficit.present) {
            return finish(report, ApertureCode::response_without_parent, false);
        }
        return finish(report, ApertureCode::accepted_parent_handoff_ready, true);
    }
    if (!response_shape(trace.response)) return finish(report, ApertureCode::response_shape_invalid, false);
    if (!claim_partition_valid(trace.response)) {
        return finish(report, ApertureCode::response_claim_partition_invalid, false);
    }
    if (trace.response.trust_anchor_embedded) {
        return finish(report, ApertureCode::response_self_nominated_trust, false);
    }
    const auto exact_parent_archive = exact_digest(SLOPOS_DRA_LINKED_PARENT_ARCHIVE_SHA256_HEX);
    if (trace.response.request_digest != trace.parent.request.request_digest
        || trace.response.linked_parent_archive_digest != exact_parent_archive
        || trace.response.parent_closure_claim_digest != trace.parent.parent.claim.claim_digest
        || trace.response.claim_catalogue_digest != trace.parent.request.claim_catalogue_digest
        || trace.response.requested_response_profile_digest
            != trace.parent.request.requested_response_profile_digest
        || trace.response.response_namespace_digest != trace.parent.request.response_namespace_digest) {
        return finish(report, ApertureCode::response_binding_mismatch, false);
    }
    if (lab_response_identity(trace.response) != trace.response.response_digest) {
        return finish(report, ApertureCode::response_digest_mismatch, false);
    }
    report.response_signature_valid = verify_response_signature(trace.response);
    if (!report.response_signature_valid) {
        return finish(report, ApertureCode::response_signature_invalid, false);
    }
    report.response_valid = true;

    if (!trace.publication.present) {
        if (trace.reopen.present || trace.accepting_configuration.present
            || trace.policy_reject_configuration.present || trace.successor_configuration.present
            || trace.appraisal.present || trace.deficit.present) {
            return finish(report, ApertureCode::publication_without_response, false);
        }
        return finish(report, ApertureCode::accepted_lab_response_durable, true);
    }
    if (!publication_shape(trace.publication)) {
        return finish(report, ApertureCode::publication_shape_invalid, false);
    }
    if (trace.publication.response_digest != trace.response.response_digest
        || trace.publication.request_digest != trace.parent.request.request_digest
        || trace.publication.linked_parent_archive_digest != exact_parent_archive
        || trace.publication.carrier_digest != trace.response.response_digest
        || trace.publication.publication_policy_digest
            != exact_digest(SLOPOS_DRA_RESPONSE_SHAPE_POLICY_SHA256_HEX)) {
        return finish(report, ApertureCode::publication_binding_mismatch, false);
    }
    if (modeled_publication_receipt_identity(trace.publication) != trace.publication.receipt_digest) {
        return finish(report, ApertureCode::publication_digest_mismatch, false);
    }
    report.publication_valid = true;

    if (!trace.reopen.present) {
        if (trace.accepting_configuration.present || trace.policy_reject_configuration.present
            || trace.successor_configuration.present || trace.appraisal.present || trace.deficit.present) {
            return finish(report, ApertureCode::reopen_without_publication, false);
        }
        return finish(report, ApertureCode::accepted_modeled_publication_durable, true);
    }
    if (!reopen_shape(trace.reopen)) return finish(report, ApertureCode::reopen_shape_invalid, false);
    if (trace.reopen.publication_receipt_digest != trace.publication.receipt_digest
        || trace.reopen.response_digest != trace.response.response_digest
        || trace.reopen.request_digest != trace.parent.request.request_digest
        || trace.reopen.reopener_implementation_digest
            != exact_digest(SLOPOS_DRA_REOPENER_IMPLEMENTATION_SHA256_HEX)
        || trace.reopen.carrier_digest != trace.response.response_digest
        || trace.reopen.reopen_policy_digest
            != exact_digest(SLOPOS_DRA_RESPONSE_SHAPE_POLICY_SHA256_HEX)) {
        return finish(report, ApertureCode::reopen_binding_mismatch, false);
    }
    if (modeled_reopen_receipt_identity(trace.reopen) != trace.reopen.receipt_digest) {
        return finish(report, ApertureCode::reopen_digest_mismatch, false);
    }
    report.reopen_valid = true;

    const unsigned configuration_count = static_cast<unsigned>(trace.accepting_configuration.present)
        + static_cast<unsigned>(trace.policy_reject_configuration.present)
        + static_cast<unsigned>(trace.successor_configuration.present);
    if (configuration_count == 0U) {
        if (trace.appraisal.present || trace.deficit.present) {
            return finish(report, ApertureCode::configurations_without_reopen, false);
        }
        return finish(report, ApertureCode::accepted_modeled_reopen_durable, true);
    }
    if (configuration_count != 3U) {
        return finish(report, ApertureCode::configuration_shape_invalid, false);
    }
    const std::array<const TrustConfiguration*, 3U> configurations{{
        &trace.accepting_configuration,
        &trace.policy_reject_configuration,
        &trace.successor_configuration,
    }};
    for (const auto* configuration : configurations) {
        if (!configuration_shape(*configuration)) {
            return finish(report, ApertureCode::configuration_shape_invalid, false);
        }
        if (configuration->embedded_in_response) {
            return finish(report, ApertureCode::configuration_embedded_in_response, false);
        }
        if (trust_configuration_identity(*configuration) != configuration->configuration_digest) {
            return finish(report, ApertureCode::configuration_digest_mismatch, false);
        }
    }
    if (trace.accepting_configuration.configuration_digest
            == trace.policy_reject_configuration.configuration_digest
        || trace.accepting_configuration.configuration_digest
            == trace.successor_configuration.configuration_digest
        || trace.policy_reject_configuration.configuration_digest
            == trace.successor_configuration.configuration_digest) {
        return finish(report, ApertureCode::configuration_digest_mismatch, false);
    }
    const auto accepting_result = appraise_candidate(trace.response, trace.accepting_configuration);
    const auto policy_reject_result = appraise_candidate(trace.response, trace.policy_reject_configuration);
    const auto successor_result = appraise_candidate(trace.response, trace.successor_configuration);
    report.accepting_configuration_accepts = accepting_result == AppraisalResult::accepted;
    if (!report.accepting_configuration_accepts) {
        return finish(report, ApertureCode::accepting_configuration_did_not_accept, false);
    }
    report.policy_reject_configuration_rejects =
        policy_reject_result == AppraisalResult::required_claim_unresolved;
    if (!report.policy_reject_configuration_rejects) {
        return finish(report, ApertureCode::policy_reject_configuration_did_not_reject, false);
    }
    report.successor_configuration_rejects_currentness =
        successor_result == AppraisalResult::owner_root_mismatch
        || successor_result == AppraisalResult::root_version_mismatch
        || successor_result == AppraisalResult::response_not_current;
    if (!report.successor_configuration_rejects_currentness) {
        return finish(report, ApertureCode::successor_configuration_did_not_reject_currentness, false);
    }
    report.configurations_valid = true;

    if (!trace.appraisal.present) {
        if (trace.deficit.present) {
            return finish(report, ApertureCode::consumption_deficit_without_appraisal, false);
        }
        return finish(report, ApertureCode::accepted_trust_configurations_durable, true);
    }
    if (!appraisal_shape(trace.appraisal)) {
        return finish(report, ApertureCode::appraisal_shape_invalid, false);
    }
    if (trace.appraisal.response_digest != trace.response.response_digest
        || trace.appraisal.publication_receipt_digest != trace.publication.receipt_digest
        || trace.appraisal.reopen_receipt_digest != trace.reopen.receipt_digest
        || trace.appraisal.accepting_configuration_digest
            != trace.accepting_configuration.configuration_digest
        || trace.appraisal.policy_reject_configuration_digest
            != trace.policy_reject_configuration.configuration_digest
        || trace.appraisal.successor_configuration_digest
            != trace.successor_configuration.configuration_digest
        || trace.appraisal.request_digest != trace.parent.request.request_digest
        || trace.appraisal.appraisal_policy_digest
            != exact_digest(SLOPOS_DRA_TRUST_CONFIGURATION_POLICY_SHA256_HEX)
        || trace.appraisal.accepting_result != accepting_result
        || trace.appraisal.policy_reject_result != policy_reject_result
        || trace.appraisal.successor_result != successor_result
        || trace.appraisal.appraisal_root_version
            != trace.accepting_configuration.current_root_version
        || trace.appraisal.successor_root_version
            != trace.successor_configuration.current_root_version) {
        return finish(report, ApertureCode::appraisal_binding_mismatch, false);
    }
    if (appraisal_witness_identity(trace.appraisal) != trace.appraisal.witness_digest) {
        return finish(report, ApertureCode::appraisal_digest_mismatch, false);
    }
    report.appraisal_witness_valid = true;
    report.same_response_opposite_appraisals = true;

    if (!trace.deficit.present) {
        return finish(report, ApertureCode::accepted_appraisal_witness_durable, true);
    }
    if (!deficit_shape(trace.deficit)) {
        return finish(report, ApertureCode::consumption_deficit_shape_invalid, false);
    }
    if (trace.deficit.response_digest != trace.response.response_digest
        || trace.deficit.appraisal_witness_digest != trace.appraisal.witness_digest
        || trace.deficit.accepting_configuration_digest
            != trace.accepting_configuration.configuration_digest
        || trace.deficit.successor_configuration_digest
            != trace.successor_configuration.configuration_digest
        || trace.deficit.request_digest != trace.parent.request.request_digest
        || trace.deficit.appraised_owner_root_digest
            != trace.accepting_configuration.current_owner_root_digest
        || trace.deficit.consumption_owner_root_digest
            != trace.successor_configuration.current_owner_root_digest
        || trace.deficit.consumption_policy_digest
            != exact_digest(SLOPOS_DRA_CONSUMPTION_FENCE_POLICY_SHA256_HEX)
        || trace.deficit.appraisal_root_version
            != trace.accepting_configuration.current_root_version
        || trace.deficit.consumption_root_version
            != trace.successor_configuration.current_root_version
        || trace.deficit.appraisal_time != trace.accepting_configuration.evaluation_time
        || trace.deficit.consumption_time != trace.successor_configuration.evaluation_time) {
        return finish(report, ApertureCode::consumption_deficit_binding_mismatch, false);
    }
    if (consumption_deficit_identity(trace.deficit) != trace.deficit.deficit_digest) {
        return finish(report, ApertureCode::consumption_deficit_digest_mismatch, false);
    }
    report.consumption_deficit_valid = true;
    report.prior_appraisal_current_at_consumption = false;
    return finish(report, ApertureCode::accepted_consumption_deficit_durable, true);
}

std::string_view appraisal_result_name(const AppraisalResult value) noexcept {
    switch (value) {
        case AppraisalResult::accepted: return "accepted";
        case AppraisalResult::malformed_response: return "malformed_response";
        case AppraisalResult::malformed_configuration: return "malformed_configuration";
        case AppraisalResult::signer_untrusted: return "signer_untrusted";
        case AppraisalResult::constitution_mismatch: return "constitution_mismatch";
        case AppraisalResult::owner_root_mismatch: return "owner_root_mismatch";
        case AppraisalResult::root_version_mismatch: return "root_version_mismatch";
        case AppraisalResult::policy_mismatch: return "policy_mismatch";
        case AppraisalResult::target_mismatch: return "target_mismatch";
        case AppraisalResult::response_not_current: return "response_not_current";
        case AppraisalResult::required_claim_unresolved: return "required_claim_unresolved";
        case AppraisalResult::rejected_claim_forbidden: return "rejected_claim_forbidden";
    }
    return "unknown";
}

std::string_view aperture_code_name(const ApertureCode value) noexcept {
    switch (value) {
        case ApertureCode::accepted_parent_handoff_ready: return "accepted_parent_handoff_ready";
        case ApertureCode::accepted_lab_response_durable: return "accepted_lab_response_durable";
        case ApertureCode::accepted_modeled_publication_durable: return "accepted_modeled_publication_durable";
        case ApertureCode::accepted_modeled_reopen_durable: return "accepted_modeled_reopen_durable";
        case ApertureCode::accepted_trust_configurations_durable: return "accepted_trust_configurations_durable";
        case ApertureCode::accepted_appraisal_witness_durable: return "accepted_appraisal_witness_durable";
        case ApertureCode::accepted_consumption_deficit_durable: return "accepted_consumption_deficit_durable";
        case ApertureCode::parent_rejected: return "parent_rejected";
        case ApertureCode::parent_not_handoff_ready: return "parent_not_handoff_ready";
        case ApertureCode::response_without_parent: return "response_without_parent";
        case ApertureCode::response_shape_invalid: return "response_shape_invalid";
        case ApertureCode::response_claim_partition_invalid: return "response_claim_partition_invalid";
        case ApertureCode::response_binding_mismatch: return "response_binding_mismatch";
        case ApertureCode::response_digest_mismatch: return "response_digest_mismatch";
        case ApertureCode::response_signature_invalid: return "response_signature_invalid";
        case ApertureCode::response_self_nominated_trust: return "response_self_nominated_trust";
        case ApertureCode::publication_without_response: return "publication_without_response";
        case ApertureCode::publication_shape_invalid: return "publication_shape_invalid";
        case ApertureCode::publication_binding_mismatch: return "publication_binding_mismatch";
        case ApertureCode::publication_digest_mismatch: return "publication_digest_mismatch";
        case ApertureCode::reopen_without_publication: return "reopen_without_publication";
        case ApertureCode::reopen_shape_invalid: return "reopen_shape_invalid";
        case ApertureCode::reopen_binding_mismatch: return "reopen_binding_mismatch";
        case ApertureCode::reopen_digest_mismatch: return "reopen_digest_mismatch";
        case ApertureCode::configurations_without_reopen: return "configurations_without_reopen";
        case ApertureCode::configuration_shape_invalid: return "configuration_shape_invalid";
        case ApertureCode::configuration_digest_mismatch: return "configuration_digest_mismatch";
        case ApertureCode::configuration_embedded_in_response: return "configuration_embedded_in_response";
        case ApertureCode::accepting_configuration_did_not_accept: return "accepting_configuration_did_not_accept";
        case ApertureCode::policy_reject_configuration_did_not_reject: return "policy_reject_configuration_did_not_reject";
        case ApertureCode::successor_configuration_did_not_reject_currentness: return "successor_configuration_did_not_reject_currentness";
        case ApertureCode::appraisal_without_configurations: return "appraisal_without_configurations";
        case ApertureCode::appraisal_shape_invalid: return "appraisal_shape_invalid";
        case ApertureCode::appraisal_binding_mismatch: return "appraisal_binding_mismatch";
        case ApertureCode::appraisal_digest_mismatch: return "appraisal_digest_mismatch";
        case ApertureCode::consumption_deficit_without_appraisal: return "consumption_deficit_without_appraisal";
        case ApertureCode::consumption_deficit_shape_invalid: return "consumption_deficit_shape_invalid";
        case ApertureCode::consumption_deficit_binding_mismatch: return "consumption_deficit_binding_mismatch";
        case ApertureCode::consumption_deficit_digest_mismatch: return "consumption_deficit_digest_mismatch";
        case ApertureCode::hosted_response_promotion_forbidden: return "hosted_response_promotion_forbidden";
        case ApertureCode::hosted_admission_promotion_forbidden: return "hosted_admission_promotion_forbidden";
        case ApertureCode::authority_promotion_forbidden: return "authority_promotion_forbidden";
        case ApertureCode::cut_order_invalid: return "cut_order_invalid";
    }
    return "unknown";
}

std::string_view aperture_cut_name(const std::size_t index) noexcept {
    constexpr std::array<std::string_view, aperture_cut_count> names{{
        "parent_handoff_ready",
        "lab_response_durable",
        "modeled_publication_durable",
        "modeled_reopen_durable",
        "trust_configurations_durable",
        "appraisal_witness_durable",
        "consumption_deficit_durable",
    }};
    return index < names.size() ? names[index] : "invalid";
}

}  // namespace ...::detached_response_aperture
