# Reopen Receipt Chain V1

This C++20 child relation is a strict crash-cut refinement of Exact Predecessor Consumption V1. It evaluates one concrete `accepted_chain_ready_live_retained` trace, then requires the source closure, reopen receipt, authorization capsule, and destructive target to consume the join, cold-reopen, and authorization receipt identities from that same still-live history. A bit saying that a cold reopen occurred is not a portable, durable, independently consumable fact.

The child remains nested under `generation_journal`; it creates no fourth semantic island and contains no provider client, signer, database, lease manager, garbage collector, deletion service, or network path.

Its hosted history refines the accepted exact-predecessor prefix while the complete live record remains present:

```text
exact still-live predecessor receipt graph
  -> replacement-only source closure and reconstruction
  -> no-replace durable reopen receipt
  -> independent reopen of that receipt
  -> separately governed authorization capsule
  -> independent reopen of authorization
  -> exact-target deletion
  -> durable deletion receipt
```

An already complete/deleted exact predecessor is rejected: it cannot coherently begin again at a live `R0` cut. Every right-hand phase consumes a predecessor visible at a strictly earlier crash cut, and the join/reopen/authorization digests must equal the corresponding exact-predecessor publication records. Same-cut conjunction is rejected as chronology, and deletion without the complete child chain is an irreversible fail-stop rather than a repairable refusal.

Build and run:

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel 2
./build/slopos_reopen_receipt_chain out
python3 proof/verify_reopen_receipt_chain.py out
```

All outputs are deterministic evidence only. They prove no external occurrence, custody, currentness, owner constitution, epoch exit, or authority.
