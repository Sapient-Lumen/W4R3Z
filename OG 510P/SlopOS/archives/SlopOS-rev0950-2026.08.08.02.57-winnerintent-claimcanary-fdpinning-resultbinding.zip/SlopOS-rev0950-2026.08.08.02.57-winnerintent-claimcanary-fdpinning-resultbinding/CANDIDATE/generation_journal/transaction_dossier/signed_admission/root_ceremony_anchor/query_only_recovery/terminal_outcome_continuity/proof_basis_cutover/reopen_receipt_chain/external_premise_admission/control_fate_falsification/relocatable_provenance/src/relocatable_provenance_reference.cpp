#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/reopen_receipt_chain/external_premise_admission/control_fate_falsification/relocatable_provenance.hpp"

#include "slopos/e0/generation_journal/spend_record.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <span>
#include <string_view>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification::relocatable_provenance {
namespace {

[[nodiscard]] bool nz(const Digest& digest) noexcept {
    return std::find_if(digest.begin(), digest.end(), [](const auto byte) { return byte != 0U; }) != digest.end();
}

[[nodiscard]] int lexical(const SourceEntry& a, const SourceEntry& b) noexcept {
    const std::size_t limit = std::min<std::size_t>(a.path_length, b.path_length);
    for (std::size_t i = 0U; i < limit; ++i) {
        if (a.path[i] != b.path[i]) return a.path[i] < b.path[i] ? -1 : 1;
    }
    return a.path_length == b.path_length ? 0 : (a.path_length < b.path_length ? -1 : 1);
}

[[nodiscard]] bool reference_path_valid(const SourceEntry& entry) noexcept {
    if (entry.path_length == 0U || entry.path_length > entry.path.size()) return false;
    for (std::size_t i = entry.path_length; i < entry.path.size(); ++i) {
        if (entry.path[i] != 0U) return false;
    }
    std::size_t segment_begin = 0U;
    for (std::size_t i = 0U; i <= entry.path_length; ++i) {
        const bool boundary = i == entry.path_length || entry.path[i] == static_cast<std::uint8_t>('/');
        if (!boundary) {
            const auto byte = entry.path[i];
            const bool permitted = (byte >= static_cast<std::uint8_t>('a') && byte <= static_cast<std::uint8_t>('z'))
                || (byte >= static_cast<std::uint8_t>('0') && byte <= static_cast<std::uint8_t>('9'))
                || byte == static_cast<std::uint8_t>('.') || byte == static_cast<std::uint8_t>('_')
                || byte == static_cast<std::uint8_t>('-');
            if (!permitted) return false;
            continue;
        }
        const std::size_t length = i - segment_begin;
        if (length == 0U) return false;
        if (length == 1U && entry.path[segment_begin] == static_cast<std::uint8_t>('.')) return false;
        if (length == 2U && entry.path[segment_begin] == static_cast<std::uint8_t>('.')
            && entry.path[segment_begin + 1U] == static_cast<std::uint8_t>('.')) return false;
        segment_begin = i + 1U;
    }
    return true;
}

constexpr std::array<std::uint8_t, 32U> reference_domain(const std::string_view text) noexcept {
    std::array<std::uint8_t, 32U> output{};
    const std::size_t count = text.size() < output.size() ? text.size() : output.size();
    for (std::size_t i = 0U; i < count; ++i) output[i] = static_cast<std::uint8_t>(text[i]);
    return output;
}

inline constexpr auto ref_source_domain = reference_domain("SlopOS/RPC/source-closure/v1");
inline constexpr auto ref_plan_domain = reference_domain("SlopOS/RPC/build-plan/v1");
inline constexpr auto ref_capsule_domain = reference_domain("SlopOS/RPC/provenance-capsule/v1");
inline constexpr auto ref_claim_domain = reference_domain("SlopOS/RPC/build-claim/v1");
inline constexpr auto ref_receipt_domain = reference_domain("SlopOS/RPC/reopen-receipt/v1");

using ReferenceSourceImage = std::array<std::uint8_t, 904U>;
using ReferencePlanImage = std::array<std::uint8_t, 292U>;
using ReferenceCapsuleImage = std::array<std::uint8_t, 264U>;
using ReferenceClaimImage = std::array<std::uint8_t, 200U>;
using ReferenceReceiptImage = std::array<std::uint8_t, 260U>;
static_assert(ReferenceSourceImage{}.size() == encoded_source_closure_bytes);
static_assert(ReferencePlanImage{}.size() == encoded_build_plan_bytes);
static_assert(ReferenceCapsuleImage{}.size() == encoded_provenance_capsule_bytes);
static_assert(ReferenceClaimImage{}.size() == encoded_build_claim_bytes);
static_assert(ReferenceReceiptImage{}.size() == encoded_reopen_receipt_bytes);

template <std::size_t N, std::size_t M>
[[nodiscard]] bool append_fixed(
    std::array<std::uint8_t, N>& image,
    std::size_t& cursor,
    const std::array<std::uint8_t, M>& value) noexcept {
    const std::size_t body = N - Digest{}.size();
    if (cursor > body || M > body - cursor) return false;
    std::copy(value.begin(), value.end(), image.begin() + static_cast<std::ptrdiff_t>(cursor));
    cursor += M;
    return true;
}

template <std::size_t N>
[[nodiscard]] bool append_byte(
    std::array<std::uint8_t, N>& image,
    std::size_t& cursor,
    const std::uint8_t value) noexcept {
    const std::size_t body = N - Digest{}.size();
    if (cursor >= body) return false;
    image[cursor++] = value;
    return true;
}

template <std::size_t N>
[[nodiscard]] bool append_u16(
    std::array<std::uint8_t, N>& image,
    std::size_t& cursor,
    const std::uint16_t value) noexcept {
    return append_byte(image, cursor, static_cast<std::uint8_t>((value >> 8U) & 0xffU))
        && append_byte(image, cursor, static_cast<std::uint8_t>(value & 0xffU));
}

template <std::size_t N>
[[nodiscard]] bool append_u64(
    std::array<std::uint8_t, N>& image,
    std::size_t& cursor,
    const std::uint64_t value) noexcept {
    for (unsigned shift = 56U;; shift -= 8U) {
        if (!append_byte(image, cursor, static_cast<std::uint8_t>((value >> shift) & 0xffU))) return false;
        if (shift == 0U) return true;
    }
}

template <std::size_t N>
[[nodiscard]] Digest seal_reference(std::array<std::uint8_t, N>& image, std::size_t cursor) noexcept {
    const std::size_t body = N - Digest{}.size();
    if (cursor > body) return {};
    std::fill(image.begin() + static_cast<std::ptrdiff_t>(cursor),
        image.begin() + static_cast<std::ptrdiff_t>(body), 0U);
    const Digest integrity = generation_journal::sha256(
        std::span<const std::uint8_t>(image.data(), body));
    std::copy(integrity.begin(), integrity.end(), image.begin() + static_cast<std::ptrdiff_t>(body));
    return generation_journal::sha256(std::span<const std::uint8_t>(image.data(), image.size()));
}

[[nodiscard]] Digest reference_source_identity(const SourceClosure& value) noexcept {
    ReferenceSourceImage image{};
    std::size_t cursor = 0U;
    bool ok = append_fixed(image, cursor, ref_source_domain)
        && append_fixed(image, cursor, value.logical_root_digest)
        && append_fixed(image, cursor, value.parent_challenge_receipt_digest)
        && append_byte(image, cursor, value.entry_count)
        && append_byte(image, cursor, value.present ? 1U : 0U)
        && append_byte(image, cursor, value.canonical ? 1U : 0U)
        && append_byte(image, cursor, value.complete ? 1U : 0U)
        && append_byte(image, cursor, value.hidden_inputs_absent ? 1U : 0U)
        && append_byte(image, cursor, 0U)
        && append_u16(image, cursor, 1U);
    for (const SourceEntry& entry : value.entries) {
        ok = ok && append_fixed(image, cursor, entry.path)
            && append_fixed(image, cursor, entry.content_digest)
            && append_u64(image, cursor, entry.bytes)
            && append_u16(image, cursor, entry.mode)
            && append_byte(image, cursor, entry.path_length)
            && append_byte(image, cursor, entry.present ? 1U : 0U)
            && append_byte(image, cursor, entry.regular_file ? 1U : 0U)
            && append_byte(image, cursor, 0U)
            && append_u16(image, cursor, 0U);
    }
    return ok ? seal_reference(image, cursor) : Digest{};
}

[[nodiscard]] Digest reference_plan_identity(const BuildPlan& value) noexcept {
    ReferencePlanImage image{};
    std::size_t cursor = 0U;
    const bool ok = append_fixed(image, cursor, ref_plan_domain)
        && append_fixed(image, cursor, value.build_type_digest)
        && append_fixed(image, cursor, value.toolchain_digest)
        && append_fixed(image, cursor, value.flags_digest)
        && append_fixed(image, cursor, value.environment_policy_digest)
        && append_fixed(image, cursor, value.dependency_closure_digest)
        && append_fixed(image, cursor, value.output_spec_digest)
        && append_fixed(image, cursor, value.deterministic_input_digest)
        && append_byte(image, cursor, value.present ? 1U : 0U)
        && append_byte(image, cursor, value.canonical ? 1U : 0U)
        && append_byte(image, cursor, value.all_behavior_inputs_bound ? 1U : 0U)
        && append_byte(image, cursor, value.network_inputs_forbidden ? 1U : 0U);
    return ok ? seal_reference(image, cursor) : Digest{};
}

[[nodiscard]] Digest reference_capsule_identity(const ProvenanceCapsule& value) noexcept {
    ReferenceCapsuleImage image{};
    std::size_t cursor = 0U;
    const bool ok = append_fixed(image, cursor, ref_capsule_domain)
        && append_fixed(image, cursor, value.parent_challenge_receipt_digest)
        && append_fixed(image, cursor, value.logical_root_digest)
        && append_fixed(image, cursor, value.source_closure_digest)
        && append_fixed(image, cursor, value.build_plan_digest)
        && append_fixed(image, cursor, value.expected_output_digest)
        && append_fixed(image, cursor, value.claim_policy_digest)
        && append_byte(image, cursor, value.present ? 1U : 0U)
        && append_byte(image, cursor, value.canonical ? 1U : 0U)
        && append_byte(image, cursor, value.physical_locator_excluded_from_subject ? 1U : 0U)
        && append_byte(image, cursor, value.raw_logs_noncanonical ? 1U : 0U)
        && append_byte(image, cursor, value.ambient_locator_bound ? 1U : 0U)
        && append_byte(image, cursor, 0U)
        && append_u16(image, cursor, 1U);
    return ok ? seal_reference(image, cursor) : Digest{};
}

[[nodiscard]] Digest reference_claim_identity(const BuildObservation& value) noexcept {
    ReferenceClaimImage image{};
    std::size_t cursor = 0U;
    const bool ok = append_fixed(image, cursor, ref_claim_domain)
        && append_fixed(image, cursor, value.capsule_digest)
        && append_fixed(image, cursor, value.source_closure_digest)
        && append_fixed(image, cursor, value.build_plan_digest)
        && append_fixed(image, cursor, value.output_digest)
        && append_byte(image, cursor, value.present ? 1U : 0U)
        && append_byte(image, cursor, value.exact_inputs_consumed ? 1U : 0U)
        && append_byte(image, cursor, value.output_set_complete ? 1U : 0U)
        && append_byte(image, cursor, value.locator_used_as_semantic_input ? 1U : 0U)
        && append_byte(image, cursor, value.hidden_input_observed ? 1U : 0U)
        && append_byte(image, cursor, 0U)
        && append_u16(image, cursor, 1U);
    return ok ? seal_reference(image, cursor) : Digest{};
}

[[nodiscard]] Digest reference_receipt_identity(const ProvenanceReopenReceipt& value) noexcept {
    ReferenceReceiptImage image{};
    std::size_t cursor = 0U;
    const bool ok = append_fixed(image, cursor, ref_receipt_domain)
        && append_fixed(image, cursor, value.claim_digest)
        && append_fixed(image, cursor, value.capsule_digest)
        && append_fixed(image, cursor, value.source_closure_digest)
        && append_fixed(image, cursor, value.build_plan_digest)
        && append_fixed(image, cursor, value.output_digest)
        && append_fixed(image, cursor, value.reopener_digest)
        && append_byte(image, cursor, value.present ? 1U : 0U)
        && append_byte(image, cursor, value.durable ? 1U : 0U)
        && append_byte(image, cursor, value.independently_administered ? 1U : 0U)
        && append_byte(image, cursor, value.exact_subject_reopened ? 1U : 0U);
    return ok ? seal_reference(image, cursor) : Digest{};
}

struct Facts final {
    bool parent_ok{false};
    bool parent_clean{false};
    bool parent_live{false};
    bool source_shape{false};
    bool source_paths{false};
    bool source_entries{false};
    bool source_identity{false};
    bool plan_shape{false};
    bool plan_identity{false};
    bool capsule_shape{false};
    bool capsule_binding{false};
    bool capsule_unpoisoned{false};
    bool capsule_identity{false};
    bool first_shape{false};
    bool first_binding{false};
    bool first_identity{false};
    bool relocated_shape{false};
    bool relocated_binding{false};
    bool relocated_identity{false};
    bool first_receipt_shape{false};
    bool first_receipt_binding{false};
    bool first_receipt_identity{false};
    bool relocated_receipt_shape{false};
    bool relocated_receipt_binding{false};
    bool relocated_receipt_identity{false};
    bool cuts{false};
};

[[nodiscard]] Facts inspect(const RelocationTrace& t) noexcept {
    Facts f{};
    const FateReport parent = control_fate_falsification::evaluate_reference(t.parent);
    f.parent_ok = parent.accepted;
    f.parent_clean = f.parent_ok && parent.code == FateCode::accepted_no_common_fate_found_in_supplied_closure
        && parent.no_common_fate_found_in_supplied_closure;
    f.parent_live = f.parent_ok && parent.live_record_must_be_retained;

    f.source_shape = t.source_closure.present && t.source_closure.canonical
        && t.source_closure.entry_count > 0U && t.source_closure.entry_count <= max_source_entries
        && nz(t.source_closure.closure_digest) && nz(t.source_closure.logical_root_digest)
        && nz(t.source_closure.parent_challenge_receipt_digest)
        && t.source_closure.parent_challenge_receipt_digest == t.parent.graph.challenge_receipt_digest;
    if (f.source_shape) {
        for (std::size_t i = t.source_closure.entry_count; i < max_source_entries; ++i) {
            if (t.source_closure.entries[i] != SourceEntry{}) f.source_shape = false;
        }
    }
    f.source_paths = f.source_shape;
    f.source_entries = f.source_shape;
    if (f.source_shape) {
        for (std::size_t i = 0U; i < t.source_closure.entry_count; ++i) {
            const SourceEntry& e = t.source_closure.entries[i];
            f.source_paths = f.source_paths && reference_path_valid(e);
            if (i != 0U) f.source_paths = f.source_paths && lexical(t.source_closure.entries[i - 1U], e) < 0;
            f.source_entries = f.source_entries && e.present && e.regular_file && nz(e.content_digest)
                && e.bytes != 0U && (e.mode == mode_read_only || e.mode == mode_read_execute);
        }
    }
    f.source_identity = f.source_shape && t.source_closure.closure_digest == reference_source_identity(t.source_closure);

    f.plan_shape = t.build_plan.present && t.build_plan.canonical && nz(t.build_plan.plan_digest)
        && nz(t.build_plan.build_type_digest) && nz(t.build_plan.toolchain_digest)
        && nz(t.build_plan.flags_digest) && nz(t.build_plan.environment_policy_digest)
        && nz(t.build_plan.dependency_closure_digest) && nz(t.build_plan.output_spec_digest)
        && nz(t.build_plan.deterministic_input_digest);
    f.plan_identity = f.plan_shape && t.build_plan.plan_digest == reference_plan_identity(t.build_plan);

    f.capsule_shape = t.capsule.present && t.capsule.canonical && nz(t.capsule.capsule_digest)
        && nz(t.capsule.parent_challenge_receipt_digest) && nz(t.capsule.logical_root_digest)
        && nz(t.capsule.source_closure_digest) && nz(t.capsule.build_plan_digest)
        && nz(t.capsule.expected_output_digest) && nz(t.capsule.claim_policy_digest);
    f.capsule_binding = f.capsule_shape
        && t.capsule.parent_challenge_receipt_digest == t.parent.graph.challenge_receipt_digest
        && t.capsule.logical_root_digest == t.source_closure.logical_root_digest
        && t.capsule.source_closure_digest == t.source_closure.closure_digest
        && t.capsule.build_plan_digest == t.build_plan.plan_digest;
    f.capsule_unpoisoned = f.capsule_shape && !t.capsule.ambient_locator_bound
        && !nz(t.capsule.ambient_locator_digest) && t.capsule.physical_locator_excluded_from_subject
        && t.capsule.raw_logs_noncanonical;
    f.capsule_identity = f.capsule_shape && t.capsule.capsule_digest == reference_capsule_identity(t.capsule);

    const auto observation_shape = [](const BuildObservation& o) noexcept {
        return o.present && nz(o.claim_digest) && nz(o.capsule_digest) && nz(o.source_closure_digest)
            && nz(o.build_plan_digest) && nz(o.output_digest) && nz(o.physical_locator_digest)
            && nz(o.raw_log_digest) && o.exact_inputs_consumed && o.output_set_complete
            && !o.hidden_input_observed;
    };
    const auto observation_binding = [&t](const BuildObservation& o) noexcept {
        return o.capsule_digest == t.capsule.capsule_digest
            && o.source_closure_digest == t.source_closure.closure_digest
            && o.build_plan_digest == t.build_plan.plan_digest;
    };
    f.first_shape = observation_shape(t.first_observation);
    f.first_binding = f.first_shape && observation_binding(t.first_observation);
    f.first_identity = f.first_shape && t.first_observation.claim_digest == reference_claim_identity(t.first_observation);
    f.relocated_shape = observation_shape(t.relocated_observation);
    f.relocated_binding = f.relocated_shape && observation_binding(t.relocated_observation);
    f.relocated_identity = f.relocated_shape
        && t.relocated_observation.claim_digest == reference_claim_identity(t.relocated_observation);

    const auto receipt_shape = [](const ProvenanceReopenReceipt& r) noexcept {
        return r.present && r.durable && r.independently_administered && r.exact_subject_reopened
            && nz(r.receipt_digest) && nz(r.claim_digest) && nz(r.capsule_digest)
            && nz(r.source_closure_digest) && nz(r.build_plan_digest) && nz(r.output_digest)
            && nz(r.reopener_digest);
    };
    const auto receipt_binding = [&t](const ProvenanceReopenReceipt& r, const BuildObservation& o) noexcept {
        return r.claim_digest == o.claim_digest && r.capsule_digest == t.capsule.capsule_digest
            && r.source_closure_digest == t.source_closure.closure_digest
            && r.build_plan_digest == t.build_plan.plan_digest && r.output_digest == o.output_digest;
    };
    f.first_receipt_shape = receipt_shape(t.first_receipt);
    f.first_receipt_binding = f.first_receipt_shape && receipt_binding(t.first_receipt, t.first_observation);
    f.first_receipt_identity = f.first_receipt_shape
        && t.first_receipt.receipt_digest == reference_receipt_identity(t.first_receipt);
    f.relocated_receipt_shape = receipt_shape(t.relocated_receipt);
    f.relocated_receipt_binding = f.relocated_receipt_shape
        && receipt_binding(t.relocated_receipt, t.relocated_observation);
    f.relocated_receipt_identity = f.relocated_receipt_shape
        && t.relocated_receipt.receipt_digest == reference_receipt_identity(t.relocated_receipt);

    f.cuts = true;
    for (std::size_t i = 0U; i < provenance_cut_count; ++i) {
        ProvenanceCut expected{};
        expected.source_closure_digest = t.source_closure.closure_digest;
        if (i > 0U) expected.build_plan_digest = t.build_plan.plan_digest;
        if (i > 1U) expected.capsule_digest = t.capsule.capsule_digest;
        if (i > 2U) expected.first_claim_digest = t.first_observation.claim_digest;
        if (i > 3U) expected.first_receipt_digest = t.first_receipt.receipt_digest;
        if (i > 4U) expected.relocated_claim_digest = t.relocated_observation.claim_digest;
        if (i > 5U) expected.relocated_receipt_digest = t.relocated_receipt.receipt_digest;
        f.cuts = f.cuts && t.cuts[i] == expected;
    }
    return f;
}

[[nodiscard]] ProvenanceReport reject(const ProvenanceCode code, const Facts& f) noexcept {
    ProvenanceReport r{};
    r.code = code;
    r.parent_accepted = f.parent_ok;
    r.parent_clean_supplied_closure = f.parent_clean;
    r.parent_live_record_retained = f.parent_live;
    return r;
}

}  // namespace

ProvenanceReport evaluate_reference(const RelocationTrace& t) noexcept {
    const Facts f = inspect(t);
    if (!f.parent_ok) return reject(ProvenanceCode::parent_rejected, f);
    if (!f.parent_clean) return reject(ProvenanceCode::parent_not_clean_supplied_closure, f);
    if (!f.parent_live) return reject(ProvenanceCode::parent_live_record_not_retained, f);
    if (!f.source_shape) return reject(ProvenanceCode::source_closure_shape_invalid, f);
    if (!f.source_paths) {
        bool duplicate = false;
        bool invalid = false;
        for (std::size_t i = 0U; i < t.source_closure.entry_count; ++i) {
            invalid = invalid || !reference_path_valid(t.source_closure.entries[i]);
            if (i > 0U) duplicate = duplicate || lexical(t.source_closure.entries[i - 1U], t.source_closure.entries[i]) == 0;
        }
        return reject(invalid ? ProvenanceCode::source_path_invalid
                              : (duplicate ? ProvenanceCode::source_path_duplicate : ProvenanceCode::source_path_order_invalid), f);
    }
    if (!f.source_entries) return reject(ProvenanceCode::source_entry_invalid, f);
    if (!f.source_identity) return reject(ProvenanceCode::source_closure_digest_mismatch, f);
    if (!f.plan_shape) return reject(ProvenanceCode::build_plan_shape_invalid, f);
    if (!f.plan_identity) return reject(ProvenanceCode::build_plan_digest_mismatch, f);
    if (!f.capsule_shape) return reject(ProvenanceCode::provenance_capsule_shape_invalid, f);
    if (!f.capsule_binding) return reject(ProvenanceCode::provenance_capsule_binding_mismatch, f);
    if (!f.capsule_unpoisoned) return reject(ProvenanceCode::ambient_locator_poisoned_capsule, f);
    if (!f.capsule_identity) return reject(ProvenanceCode::provenance_capsule_digest_mismatch, f);
    if (!f.first_shape) return reject(ProvenanceCode::first_observation_shape_invalid, f);
    if (!f.first_binding) return reject(ProvenanceCode::first_claim_binding_mismatch, f);
    if (!f.first_identity) return reject(ProvenanceCode::first_claim_digest_mismatch, f);
    if (!f.relocated_shape) return reject(ProvenanceCode::relocated_observation_shape_invalid, f);
    if (!f.relocated_binding) return reject(ProvenanceCode::relocated_claim_binding_mismatch, f);
    if (!f.relocated_identity) return reject(ProvenanceCode::relocated_claim_digest_mismatch, f);
    if (!f.first_receipt_shape) return reject(ProvenanceCode::first_receipt_shape_invalid, f);
    if (!f.first_receipt_binding) return reject(ProvenanceCode::first_receipt_binding_mismatch, f);
    if (!f.first_receipt_identity) return reject(ProvenanceCode::first_receipt_digest_mismatch, f);
    if (!f.relocated_receipt_shape) return reject(ProvenanceCode::relocated_receipt_shape_invalid, f);
    if (!f.relocated_receipt_binding) return reject(ProvenanceCode::relocated_receipt_binding_mismatch, f);
    if (!f.relocated_receipt_identity) return reject(ProvenanceCode::relocated_receipt_digest_mismatch, f);
    if (!f.cuts) return reject(ProvenanceCode::provenance_cut_order_invalid, f);

    ProvenanceReport r{};
    r.accepted = true;
    r.parent_accepted = true;
    r.parent_clean_supplied_closure = true;
    r.parent_live_record_retained = true;
    r.source_closure_shape_valid = true;
    r.source_paths_valid = true;
    r.source_entries_valid = true;
    r.source_closure_identity_valid = true;
    r.build_plan_shape_valid = true;
    r.build_plan_identity_valid = true;
    r.capsule_shape_valid = true;
    r.capsule_binding_valid = true;
    r.capsule_identity_valid = true;
    r.first_observation_valid = true;
    r.first_claim_identity_valid = true;
    r.relocated_observation_valid = true;
    r.relocated_claim_identity_valid = true;
    r.first_receipt_valid = true;
    r.relocated_receipt_valid = true;
    r.cuts_ordered = true;
    r.source_closure_complete = t.source_closure.complete && t.source_closure.hidden_inputs_absent;
    r.build_plan_complete = t.build_plan.all_behavior_inputs_bound && t.build_plan.network_inputs_forbidden;
    r.physical_locator_excluded_from_subject = true;
    r.locators_distinct = t.first_observation.physical_locator_digest != t.relocated_observation.physical_locator_digest;
    r.canonical_claims_equal = t.first_observation.claim_digest == t.relocated_observation.claim_digest;
    r.outputs_equal = t.first_observation.output_digest == t.relocated_observation.output_digest;

    if (!r.source_closure_complete) r.code = ProvenanceCode::accepted_refused_source_closure_open;
    else if (!r.build_plan_complete) r.code = ProvenanceCode::accepted_refused_build_plan_open;
    else if (t.first_observation.locator_used_as_semantic_input || t.relocated_observation.locator_used_as_semantic_input) {
        r.code = ProvenanceCode::accepted_refused_locator_influenced_output;
    } else if (!r.canonical_claims_equal || !r.outputs_equal
        || t.capsule.expected_output_digest != t.first_observation.output_digest) {
        r.code = ProvenanceCode::accepted_refused_output_not_reproducible;
    } else if (!r.locators_distinct) {
        r.code = ProvenanceCode::accepted_same_locator_no_relocation_witness;
    } else {
        r.code = ProvenanceCode::accepted_relocated_exact_subject;
        r.relocation_witness = true;
    }
    return r;
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification::relocatable_provenance
