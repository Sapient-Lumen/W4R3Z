# Exact Predecessor Consumption — hosted Epoch-Zero child

This directory is a **nested child relation** of Proof Basis Cutover V1. It does not create a fourth semantic island and it does not operate storage, signing, deletion, reclamation, retry, leases, currentness, or provider infrastructure.

## Correction carried by rev0919

Proof Basis Cutover V1 establishes a useful but weaker fact: each newly visible phase has a predecessor-shaped fact visible at an earlier modeled crash cut. Its Boolean trace does **not** identify the exact durable predecessor that a later phase observed and consumed. Calling that relation “consumption” overstates the executable theorem.

Exact Predecessor Consumption V1 separates the two claims:

1. **prior availability** — a suitable phase existed at a prior cut;
2. **exact consumption** — the consumer durably publishes the exact predecessor receipt digest, on the same cutover subject, after a strict publication cut.

The child relation binds witness publication, floor publication, same-history join publication, cold-reopen receipt, deletion authorization, and the deletion effect into an acyclic exact-digest chain. The complete live terminal record remains mandatory until both the parent crash-prefix theorem and this exact-consumption theorem hold.

## What the harness proves

The retained campaign exercises 75 cases and 600 cuts. Candidate and structurally separate reference evaluators agree on every case. Three compiler lanes and three independent Python cold reopeners must reproduce seven canonical artifacts byte-for-byte.

The hosted theorem denies all external claims. It does not establish that any real filesystem write, `fsync`, directory entry, selector update, signature, protected floor, or deletion occurred. Those remain External Ceremony V6 obligations.
