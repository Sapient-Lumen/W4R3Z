#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/reopen_receipt_chain/external_premise_admission/control_fate_falsification/relocatable_provenance/observed_output_closure/hosted_externality_nonderivation/detached_response_aperture.hpp"

#include <filesystem>
#include <iostream>

int main(int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "usage: slopos_detached_response_aperture OUTPUT_DIRECTORY\n";
        return 2;
    }
    return slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification::relocatable_provenance::observed_output_closure::hosted_externality_nonderivation::detached_response_aperture::run_campaign(std::filesystem::path(argv[1])) ? 0 : 1;
}
