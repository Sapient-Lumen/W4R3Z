#pragma once

#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <string_view>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover {

inline constexpr std::size_t cut_count = 7U;

enum class CutoverCode : std::uint8_t {
    accepted_cutover_complete,
    accepted_cutover_ready_live_retained,
    accepted_live_basis_retained,
    accepted_reclamation_refused_execution_gap,
    accepted_reclamation_refused_history_gap,
    accepted_reclamation_refused_join_gap,
    accepted_reclamation_refused_reopen_gap,
    accepted_reclamation_refused_order_gap,
    accepted_equivocation_fail_stop,
    accepted_regression_fail_stop,
    invalid_terminal_state,
    parent_evidence_rejected,
    cutover_id_zero,
    witness_digest_zero,
    floor_digest_zero,
    reclamation_request_mismatch,
    join_receipt_shape_invalid,
    join_cutover_id_mismatch,
    join_request_id_mismatch,
    join_transition_digest_mismatch,
    join_register_incarnation_mismatch,
    join_terminal_digest_mismatch,
    join_terminal_kind_mismatch,
    join_witness_digest_mismatch,
    join_floor_digest_mismatch,
    trace_initial_state_invalid,
    trace_deleted_and_live,
    trace_reopen_without_joined_basis,
    trace_join_without_components,
    trace_live_absent_without_deletion,
};

struct JoinReceipt final {
    Digest cutover_id{};
    Digest request_id{};
    Digest transition_digest{};
    Digest register_incarnation{};
    Digest terminal_digest{};
    Digest witness_digest{};
    Digest floor_digest{};
    TerminalKind terminal_kind{TerminalKind::effect};

    bool present{false};
    bool authenticated{false};
    bool durable{false};
    bool single_view{false};
    bool independently_reopenable{false};
    bool survives_restore{false};
    bool survives_succession{false};

    [[nodiscard]] friend constexpr bool operator==(
        const JoinReceipt&, const JoinReceipt&) noexcept = default;
};

struct CutObservation final {
    bool live_record_visible{false};
    bool witness_visible{false};
    bool floor_visible{false};
    bool join_visible{false};
    bool deletion_authorized{false};
    bool record_deleted{false};
    bool cold_reopen_observed{false};

    [[nodiscard]] friend constexpr bool operator==(
        const CutObservation&, const CutObservation&) noexcept = default;
};

struct CutoverTrace final {
    TerminalState state{};
    ContinuityEvidence continuity{};
    Digest cutover_id{};
    Digest witness_digest{};
    Digest floor_digest{};
    JoinReceipt join{};
    std::array<CutObservation, cut_count> cuts{};
    bool reclamation_requested{false};
    bool equivocation_observed{false};

    [[nodiscard]] friend constexpr bool operator==(
        const CutoverTrace&, const CutoverTrace&) noexcept = default;
};

struct CutoverReport final {
    CutoverCode code{CutoverCode::invalid_terminal_state};
    bool accepted{false};
    bool parent_live_record_basis{false};
    bool parent_witness_history_path{false};
    bool parent_floor_execution_path{false};
    bool join_core_valid{false};
    bool join_reopen_valid{false};
    bool all_cuts_covered{false};
    bool execution_gap_observed{false};
    bool history_gap_observed{false};
    bool join_gap_observed{false};
    bool reopen_gap_observed{false};
    bool phase_order_gap_observed{false};
    bool regression_observed{false};
    bool cutover_ready{false};
    bool reclamation_safe{false};
    bool live_record_must_remain{true};
    bool fail_stopped{false};
    bool eventual_repair_sufficient{false};
    bool external_occurrence_proved{false};
    bool currentness_proved{false};
    bool independent_custody_proved{false};
    bool epoch_exit_proved{false};
    bool authority_granted{false};

    [[nodiscard]] friend constexpr bool operator==(
        const CutoverReport&, const CutoverReport&) noexcept = default;
};

[[nodiscard]] CutoverReport evaluate_candidate(const CutoverTrace& trace) noexcept;
[[nodiscard]] CutoverReport evaluate_reference(const CutoverTrace& trace) noexcept;
[[nodiscard]] std::string_view cutover_code_name(CutoverCode value) noexcept;
[[nodiscard]] std::string_view cut_name(std::size_t index) noexcept;
[[nodiscard]] bool run_campaign(const std::filesystem::path& output_directory);

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover
