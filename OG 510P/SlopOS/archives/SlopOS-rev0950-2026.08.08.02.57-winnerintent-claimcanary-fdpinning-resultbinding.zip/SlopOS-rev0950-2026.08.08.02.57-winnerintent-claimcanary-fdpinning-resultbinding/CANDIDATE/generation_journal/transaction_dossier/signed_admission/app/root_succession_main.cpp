#include "slopos/e0/signed_admission/root_succession.hpp"

#include <iostream>
#include <string_view>

int main(const int argc, char** argv) {
    if (argc != 3 || std::string_view{argv[1]} != "campaign") {
        std::cerr << "usage: slopos_root_succession campaign OUTPUT_DIRECTORY\n";
        return 2;
    }
    return slopos::e0::signed_admission::root_succession::
        run_root_succession_campaign(argv[2]) ? 0 : 1;
}
