
#pragma once

#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery.hpp"

#include <cstdint>
#include <filesystem>
#include <string_view>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity {

enum class TerminalKind : std::uint8_t {
    effect,
    no_effect,
};

enum class ContinuityCode : std::uint8_t {
    accepted_live_record_continuity,
    accepted_successor_witness_continuity,
    accepted_hybrid_continuity,
    accepted_execution_only,
    accepted_history_only,
    accepted_neither,
    accepted_equivocation_fail_stop,
    invalid_state,
    request_id_mismatch,
    transition_digest_mismatch,
    register_incarnation_mismatch,
    terminal_digest_mismatch,
    terminal_kind_mismatch,
    terminal_record_shape_invalid,
    terminal_witness_shape_invalid,
    successor_floor_shape_invalid,
};

struct TerminalState final {
    Digest request_id{};
    Digest transition_digest{};
    Digest register_incarnation{};
    Digest terminal_digest{};
    TerminalKind terminal_kind{TerminalKind::effect};

    [[nodiscard]] friend constexpr bool operator==(
        const TerminalState&, const TerminalState&) noexcept = default;
};

struct ContinuityEvidence final {
    Digest request_id{};
    Digest transition_digest{};
    Digest register_incarnation{};
    Digest terminal_digest{};
    TerminalKind terminal_kind{TerminalKind::effect};

    bool terminal_record_present{false};
    bool terminal_record_authenticated{false};
    bool terminal_record_durable{false};
    bool terminal_record_serialized{false};
    bool terminal_record_single_view{false};
    bool terminal_record_retained_full_horizon{false};
    bool terminal_record_fences_pending{false};
    bool terminal_record_survives_restore{false};
    bool terminal_record_survives_succession{false};
    bool terminal_record_independently_reopenable{false};

    bool terminal_witness_present{false};
    bool terminal_witness_authenticated{false};
    bool terminal_witness_binds_terminal{false};
    bool terminal_witness_durable{false};
    bool terminal_witness_independently_reopenable{false};
    bool terminal_witness_survives_restore{false};
    bool terminal_witness_survives_succession{false};

    bool successor_floor_present{false};
    bool successor_floor_authenticated{false};
    bool successor_floor_monotone{false};
    bool successor_floor_outside_restore_domain{false};
    bool successor_floor_binds_request_namespace{false};
    bool old_incarnation_rejected{false};
    bool pending_invocations_fenced{false};
    bool restore_preserves_floor{false};
    bool succession_preserves_floor{false};
    bool successor_floor_single_view{false};

    bool reclamation_requested{false};
    bool client_acknowledged{false};
    bool ttl_expired{false};
    bool equivocation_observed{false};

    [[nodiscard]] friend constexpr bool operator==(
        const ContinuityEvidence&, const ContinuityEvidence&) noexcept = default;
};

struct ContinuityReport final {
    ContinuityCode code{ContinuityCode::invalid_state};
    bool accepted{false};
    bool terminal_record_execution_path{false};
    bool terminal_record_history_path{false};
    bool terminal_witness_history_path{false};
    bool successor_floor_execution_path{false};
    bool duplicate_execution_excluded{false};
    bool terminal_outcome_reopenable{false};
    bool terminal_continuity{false};
    bool reclamation_safe{false};
    bool fail_stopped{false};
    bool client_ack_sufficient{false};
    bool ttl_sufficient{false};
    bool external_occurrence_proved{false};
    bool currentness_proved{false};
    bool independent_custody_proved{false};
    bool epoch_exit_proved{false};
    bool authority_granted{false};

    [[nodiscard]] friend constexpr bool operator==(
        const ContinuityReport&, const ContinuityReport&) noexcept = default;
};

[[nodiscard]] ContinuityReport evaluate_candidate(
    const TerminalState& state,
    const ContinuityEvidence& evidence) noexcept;
[[nodiscard]] ContinuityReport evaluate_reference(
    const TerminalState& state,
    const ContinuityEvidence& evidence) noexcept;

[[nodiscard]] std::string_view terminal_kind_name(TerminalKind value) noexcept;
[[nodiscard]] std::string_view continuity_code_name(ContinuityCode value) noexcept;
[[nodiscard]] bool run_campaign(const std::filesystem::path& output_directory);

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity
