
#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity.hpp"

#include <algorithm>
#include <array>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity {
namespace {

[[nodiscard]] bool nonzero(const Digest& value) noexcept {
    return std::find_if(value.cbegin(), value.cend(), [](const std::uint8_t byte) {
        return byte != 0U;
    }) != value.cend();
}

[[nodiscard]] ContinuityReport report(
    const ContinuityCode code,
    const bool accepted,
    const std::array<bool, 4U>& paths,
    const bool fail_stopped,
    const bool reclamation_requested) noexcept {
    const bool execution = !fail_stopped && (paths[0] || paths[3]);
    const bool history = !fail_stopped && (paths[1] || paths[2]);
    return ContinuityReport{
        code,
        accepted,
        paths[0],
        paths[1],
        paths[2],
        paths[3],
        execution,
        history,
        execution && history,
        execution && history && reclamation_requested && paths[2] && paths[3],
        fail_stopped,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
    };
}

[[nodiscard]] ContinuityReport reject(const ContinuityCode code) noexcept {
    return report(code, false, {false, false, false, false}, false, false);
}

}  // namespace

ContinuityReport evaluate_reference(
    const TerminalState& state,
    const ContinuityEvidence& evidence) noexcept {
    const std::array<bool, 4U> state_nonzero{
        nonzero(state.request_id),
        nonzero(state.transition_digest),
        nonzero(state.register_incarnation),
        nonzero(state.terminal_digest),
    };
    if (!std::all_of(state_nonzero.cbegin(), state_nonzero.cend(), [](const bool value) {
            return value;
        })) {
        return reject(ContinuityCode::invalid_state);
    }

    const std::array<bool, 5U> identity{
        evidence.request_id == state.request_id,
        evidence.transition_digest == state.transition_digest,
        evidence.register_incarnation == state.register_incarnation,
        evidence.terminal_digest == state.terminal_digest,
        evidence.terminal_kind == state.terminal_kind,
    };
    const std::array<ContinuityCode, 5U> identity_codes{
        ContinuityCode::request_id_mismatch,
        ContinuityCode::transition_digest_mismatch,
        ContinuityCode::register_incarnation_mismatch,
        ContinuityCode::terminal_digest_mismatch,
        ContinuityCode::terminal_kind_mismatch,
    };
    for (std::size_t index = 0U; index < identity.size(); ++index) {
        if (!identity[index]) {
            return reject(identity_codes[index]);
        }
    }

    const std::array<bool, 9U> record_dependent{
        evidence.terminal_record_authenticated,
        evidence.terminal_record_durable,
        evidence.terminal_record_serialized,
        evidence.terminal_record_single_view,
        evidence.terminal_record_retained_full_horizon,
        evidence.terminal_record_fences_pending,
        evidence.terminal_record_survives_restore,
        evidence.terminal_record_survives_succession,
        evidence.terminal_record_independently_reopenable,
    };
    if (!evidence.terminal_record_present
        && std::any_of(record_dependent.cbegin(), record_dependent.cend(), [](const bool value) {
            return value;
        })) {
        return reject(ContinuityCode::terminal_record_shape_invalid);
    }
    const std::array<bool, 6U> witness_dependent{
        evidence.terminal_witness_authenticated,
        evidence.terminal_witness_binds_terminal,
        evidence.terminal_witness_durable,
        evidence.terminal_witness_independently_reopenable,
        evidence.terminal_witness_survives_restore,
        evidence.terminal_witness_survives_succession,
    };
    if (!evidence.terminal_witness_present
        && std::any_of(witness_dependent.cbegin(), witness_dependent.cend(), [](const bool value) {
            return value;
        })) {
        return reject(ContinuityCode::terminal_witness_shape_invalid);
    }
    const std::array<bool, 9U> floor_dependent{
        evidence.successor_floor_authenticated,
        evidence.successor_floor_monotone,
        evidence.successor_floor_outside_restore_domain,
        evidence.successor_floor_binds_request_namespace,
        evidence.old_incarnation_rejected,
        evidence.pending_invocations_fenced,
        evidence.restore_preserves_floor,
        evidence.succession_preserves_floor,
        evidence.successor_floor_single_view,
    };
    if (!evidence.successor_floor_present
        && std::any_of(floor_dependent.cbegin(), floor_dependent.cend(), [](const bool value) {
            return value;
        })) {
        return reject(ContinuityCode::successor_floor_shape_invalid);
    }
    if (evidence.equivocation_observed) {
        return report(
            ContinuityCode::accepted_equivocation_fail_stop,
            true,
            {false, false, false, false},
            true,
            evidence.reclamation_requested);
    }

    const bool record_core = evidence.terminal_record_present
        && evidence.terminal_record_authenticated
        && evidence.terminal_record_durable
        && evidence.terminal_record_single_view
        && evidence.terminal_record_retained_full_horizon
        && evidence.terminal_record_survives_restore
        && evidence.terminal_record_survives_succession;
    const std::array<bool, 4U> paths{
        record_core && evidence.terminal_record_serialized && evidence.terminal_record_fences_pending,
        record_core && evidence.terminal_record_independently_reopenable,
        evidence.terminal_witness_present
            && evidence.terminal_witness_authenticated
            && evidence.terminal_witness_binds_terminal
            && evidence.terminal_witness_durable
            && evidence.terminal_witness_independently_reopenable
            && evidence.terminal_witness_survives_restore
            && evidence.terminal_witness_survives_succession,
        evidence.successor_floor_present
            && evidence.successor_floor_authenticated
            && evidence.successor_floor_monotone
            && evidence.successor_floor_outside_restore_domain
            && evidence.successor_floor_binds_request_namespace
            && evidence.old_incarnation_rejected
            && evidence.pending_invocations_fenced
            && evidence.restore_preserves_floor
            && evidence.succession_preserves_floor
            && evidence.successor_floor_single_view,
    };
    const bool execution = paths[0] || paths[3];
    const bool history = paths[1] || paths[2];
    ContinuityCode code = ContinuityCode::accepted_neither;
    if (execution && history) {
        const bool live_only = paths[0] && paths[1] && !paths[2] && !paths[3];
        const bool successor_only = !paths[0] && !paths[1] && paths[2] && paths[3];
        code = live_only
            ? ContinuityCode::accepted_live_record_continuity
            : successor_only
                ? ContinuityCode::accepted_successor_witness_continuity
                : ContinuityCode::accepted_hybrid_continuity;
    } else if (execution) {
        code = ContinuityCode::accepted_execution_only;
    } else if (history) {
        code = ContinuityCode::accepted_history_only;
    }
    return report(code, true, paths, false, evidence.reclamation_requested);
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity
