#include "slopos/e0/signed_admission/root_succession.hpp"

#include <algorithm>
#include <array>
#include <limits>

#include <openssl/evp.h>

namespace slopos::e0::signed_admission::root_succession {
namespace {

[[nodiscard]] bool verify_signature(
    const PublicKey& key,
    const Signature& signature,
    const RootSigningMessage& message) noexcept {
    EVP_PKEY* public_key = EVP_PKEY_new_raw_public_key(
        EVP_PKEY_ED25519, nullptr, key.data(), key.size());
    if (public_key == nullptr) return false;
    EVP_MD_CTX* context = EVP_MD_CTX_new();
    if (context == nullptr) {
        EVP_PKEY_free(public_key);
        return false;
    }
    int result = EVP_DigestVerifyInit(context, nullptr, nullptr, nullptr, public_key);
    if (result == 1) {
        result = EVP_DigestVerify(
            context,
            signature.data(), signature.size(),
            message.data(), message.size());
    }
    EVP_MD_CTX_free(context);
    EVP_PKEY_free(public_key);
    return result == 1;
}

[[nodiscard]] EvidenceReport reject(
    const EvidenceCode code,
    const EvidenceReport& partial) noexcept {
    EvidenceReport result = partial;
    result.code = code;
    result.valid = false;
    result.owner_constitution_proved = false;
    result.currentness_proved = false;
    result.independent_custody_proved = false;
    result.protected_transition_proved = false;
    result.independent_reopen_proved = false;
    result.epoch_exit_proved = false;
    result.authority_granted = false;
    return result;
}

struct ThresholdResult final {
    std::size_t verified{0U};
    bool threshold_met{false};
    EvidenceCode failure{EvidenceCode::predecessor_below_threshold};
};

[[nodiscard]] ThresholdResult check_threshold(
    const OwnerManifestV1& manifest,
    const std::array<SignatureSlotV1, kMaximumKeys>& slots,
    const std::uint8_t count,
    const RootSigningMessage& message,
    const bool old_side) {
    ThresholdResult result;
    result.failure = old_side
        ? EvidenceCode::predecessor_below_threshold
        : EvidenceCode::successor_below_threshold;
    std::array<Digest, kMaximumKeys> seen{};
    for (std::size_t index = 0U; index < count; ++index) {
        const SignatureSlotV1& slot = slots[index];
        if (std::find(seen.begin(), seen.begin() + static_cast<std::ptrdiff_t>(index),
                      slot.key_id)
            != seen.begin() + static_cast<std::ptrdiff_t>(index)) {
            result.failure = old_side
                ? EvidenceCode::predecessor_duplicate_signer
                : EvidenceCode::successor_duplicate_signer;
            return result;
        }
        seen[index] = slot.key_id;
        const auto manifest_end = manifest.keys.begin()
            + static_cast<std::ptrdiff_t>(manifest.key_count);
        const auto found = std::find_if(
            manifest.keys.begin(), manifest_end,
            [&slot](const KeyV1& key) { return key.key_id == slot.key_id; });
        if (found == manifest_end) {
            result.failure = old_side
                ? EvidenceCode::predecessor_unknown_signer
                : EvidenceCode::successor_unknown_signer;
            return result;
        }
        if (!verify_signature(found->public_key, slot.signature, message)) {
            result.failure = old_side
                ? EvidenceCode::predecessor_invalid_signature
                : EvidenceCode::successor_invalid_signature;
            return result;
        }
        ++result.verified;
    }
    result.threshold_met = result.verified >= manifest.threshold;
    return result;
}

[[nodiscard]] ApplyReport reject_apply(
    const ApplyCode code,
    const EvidenceReport& evidence) noexcept {
    ApplyReport result;
    result.code = code;
    result.evidence = evidence;
    result.owner_constitution_proved = false;
    result.currentness_proved = false;
    result.independent_custody_proved = false;
    result.protected_transition_proved = false;
    result.independent_reopen_proved = false;
    result.epoch_exit_proved = false;
    result.authority_granted = false;
    return result;
}

[[nodiscard]] bool build_receipt(
    const RootSuccessionStatementV1& statement,
    const EncodedRootStatement& statement_bytes,
    const std::uint64_t ordinal,
    const std::uint64_t observed_time,
    const ReceiptDisposition disposition,
    EncodedRootReceipt& output) {
    RootTransitionReceiptV1 logical;
    logical.disposition = disposition;
    logical.query_only = disposition != ReceiptDisposition::committed;
    logical.register_id = statement.register_id;
    logical.predecessor_manifest_head = statement.predecessor_manifest_head;
    logical.successor_manifest_head = statement.successor_manifest_head;
    logical.statement_head = root_statement_head(statement_bytes);
    logical.ceremony_id = statement.ceremony_id;
    logical.predecessor_version = statement.predecessor_version;
    logical.successor_version = statement.successor_version;
    logical.transition_ordinal = ordinal;
    logical.observed_time = observed_time;
    return encode_root_receipt(logical, output);
}

}  // namespace

EvidenceReport validate_reference(
    const EncodedManifest& predecessor_manifest_bytes,
    const EncodedManifest& successor_manifest_bytes,
    const EncodedRootEnvelope& envelope_bytes,
    const std::uint64_t observed_time) {
    EvidenceReport report;
    OwnerManifestV1 old_root;
    if (!decode_manifest(predecessor_manifest_bytes, old_root)) {
        return reject(EvidenceCode::invalid_predecessor_manifest, report);
    }
    report.predecessor_manifest_valid = true;
    OwnerManifestV1 new_root;
    if (!decode_manifest(successor_manifest_bytes, new_root)) {
        return reject(EvidenceCode::invalid_successor_manifest, report);
    }
    report.successor_manifest_valid = true;
    DualThresholdEnvelopeV1 envelope;
    if (!decode_root_envelope(envelope_bytes, envelope)) {
        return reject(EvidenceCode::invalid_envelope, report);
    }
    RootSuccessionStatementV1 statement;
    if (!decode_root_statement(envelope.statement, statement)) {
        return reject(EvidenceCode::invalid_statement, report);
    }
    report.statement_valid = true;

    if (old_root.project_id != new_root.project_id
        || old_root.project_id != statement.project_id) {
        return reject(EvidenceCode::project_mismatch, report);
    }
    const Digest old_head = manifest_head(predecessor_manifest_bytes);
    const Digest new_head = manifest_head(successor_manifest_bytes);
    if (new_root.predecessor_manifest != old_head) {
        return reject(EvidenceCode::predecessor_chain_mismatch, report);
    }
    const bool next_version = old_root.version != std::numeric_limits<std::uint64_t>::max()
        && new_root.version == old_root.version + 1U
        && statement.predecessor_version == old_root.version
        && statement.successor_version == new_root.version;
    if (!next_version) return reject(EvidenceCode::version_not_next, report);
    report.exact_next_version = true;
    if (statement.predecessor_manifest_head != old_head
        || statement.successor_manifest_head != new_head) {
        return reject(EvidenceCode::statement_binding_mismatch, report);
    }
    if (statement.precommitted_successor_head != new_head) {
        return reject(EvidenceCode::statement_precommit_mismatch, report);
    }
    report.precommit_bound = true;
    if (!(statement.not_before <= observed_time && observed_time < statement.expires_at)) {
        return reject(EvidenceCode::time_window_mismatch, report);
    }
    report.time_window_match = true;

    const RootSigningMessage message = root_signing_message_for(envelope.statement);
    const ThresholdResult old_threshold = check_threshold(
        old_root, envelope.predecessor_signatures,
        envelope.predecessor_signature_count, message, true);
    report.predecessor_verified_signatures = old_threshold.verified;
    if (!old_threshold.threshold_met) return reject(old_threshold.failure, report);
    report.predecessor_threshold_met = true;

    const ThresholdResult new_threshold = check_threshold(
        new_root, envelope.successor_signatures,
        envelope.successor_signature_count, message, false);
    report.successor_verified_signatures = new_threshold.verified;
    if (!new_threshold.threshold_met) return reject(new_threshold.failure, report);
    report.successor_threshold_met = true;

    report.code = EvidenceCode::evidence_valid;
    report.valid = true;
    report.owner_constitution_proved = false;
    report.currentness_proved = false;
    report.independent_custody_proved = false;
    report.protected_transition_proved = false;
    report.independent_reopen_proved = false;
    report.epoch_exit_proved = false;
    report.authority_granted = false;
    return report;
}

ApplyReport apply_reference(
    CurrentRootRegisterV1& root_register,
    const EncodedManifest& predecessor_manifest,
    const EncodedManifest& successor_manifest,
    const EncodedRootEnvelope& envelope_bytes,
    const std::uint64_t observed_time,
    const ReplyCut reply_cut) {
    const EvidenceReport evidence = validate_reference(
        predecessor_manifest, successor_manifest, envelope_bytes, observed_time);
    if (!evidence.valid) return reject_apply(ApplyCode::invalid_evidence, evidence);

    DualThresholdEnvelopeV1 envelope;
    RootSuccessionStatementV1 statement;
    if (!decode_root_envelope(envelope_bytes, envelope)
        || !decode_root_statement(envelope.statement, statement)) {
        return reject_apply(ApplyCode::invalid_evidence, evidence);
    }
    if (statement.register_id != root_register.register_id) {
        return reject_apply(ApplyCode::register_id_mismatch, evidence);
    }
    if (root_register.current_version == statement.successor_version
        && root_register.current_manifest_head == statement.successor_manifest_head) {
        ApplyReport result = reject_apply(
            ApplyCode::already_current_query_only, evidence);
        result.query_only = true;
        result.receipt_present = build_receipt(
            statement, envelope.statement,
            root_register.transition_ordinal,
            observed_time,
            ReceiptDisposition::already_current_query_only,
            result.receipt);
        return result;
    }
    if (root_register.current_version != statement.predecessor_version
        || root_register.current_manifest_head != statement.predecessor_manifest_head) {
        return reject_apply(ApplyCode::stale_current, evidence);
    }
    if (root_register.precommitted_successor_head
        != statement.successor_manifest_head) {
        return reject_apply(ApplyCode::register_precommit_mismatch, evidence);
    }
    if (root_register.transition_ordinal == std::numeric_limits<std::uint64_t>::max()) {
        return reject_apply(ApplyCode::stale_current, evidence);
    }

    root_register.current_version = statement.successor_version;
    root_register.current_manifest_head = statement.successor_manifest_head;
    root_register.precommitted_successor_head = {};
    ++root_register.transition_ordinal;

    ApplyReport result = reject_apply(
        reply_cut == ReplyCut::reply_delivered
            ? ApplyCode::committed
            : ApplyCode::uncertain_after_commit_query_only,
        evidence);
    result.committed = true;
    result.query_only = reply_cut == ReplyCut::reply_lost_after_commit;
    result.receipt_present = build_receipt(
        statement, envelope.statement,
        root_register.transition_ordinal,
        observed_time,
        reply_cut == ReplyCut::reply_delivered
            ? ReceiptDisposition::committed
            : ReceiptDisposition::uncertain_after_commit_query_only,
        result.receipt);
    return result;
}

}  // namespace slopos::e0::signed_admission::root_succession
