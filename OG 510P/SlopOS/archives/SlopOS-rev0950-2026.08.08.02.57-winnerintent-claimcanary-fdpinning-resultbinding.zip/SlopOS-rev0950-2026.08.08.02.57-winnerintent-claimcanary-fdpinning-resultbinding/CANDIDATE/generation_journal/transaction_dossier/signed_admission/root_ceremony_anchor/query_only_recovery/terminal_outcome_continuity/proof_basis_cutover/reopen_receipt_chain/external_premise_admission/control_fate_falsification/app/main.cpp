#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/reopen_receipt_chain/external_premise_admission/control_fate_falsification.hpp"

#include <filesystem>
#include <iostream>

int main(int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "usage: slopos_control_fate_falsification OUTPUT_DIRECTORY\n";
        return 2;
    }
    const bool ok = slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification::run_campaign(
        std::filesystem::path(argv[1]));
    std::cout << "CONTROL_FATE_FALSIFICATION=" << (ok ? "PASS" : "FAIL") << '\n';
    return ok ? 0 : 1;
}
