#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/reopen_receipt_chain/external_premise_admission/control_fate_falsification.hpp"
#include "slopos/e0/generation_journal/spend_record.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <span>
#include <string_view>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification {
namespace {

[[nodiscard]] bool has_bytes(const Digest& digest) noexcept {
    std::uint8_t aggregate = 0U;
    for (const std::uint8_t byte : digest) aggregate = static_cast<std::uint8_t>(aggregate | byte);
    return aggregate != 0U;
}

[[nodiscard]] FateReport stop(
    const FateCode code,
    const bool parent_ok = false,
    const bool parent_ready = false) noexcept {
    FateReport output{};
    output.code = code;
    output.parent_accepted = parent_ok;
    output.parent_ready_live_retained = parent_ready;
    return output;
}

[[nodiscard]] bool exact_cut_sequence(const FateTrace& trace) noexcept {
    const bool publication = trace.graph.durable && trace.graph.no_replace_published && trace.graph.single_view;
    const bool reopen = publication && trace.graph.independently_reopenable;
    const bool challenge = reopen && trace.graph.independently_challenged;
    const std::array<GraphCut, graph_cut_count> expected{{
        {true, false, false, false},
        {true, publication, false, false},
        {true, publication, reopen, false},
        {true, publication, reopen, challenge},
    }};
    return trace.cuts == expected;
}

[[nodiscard]] std::uint8_t binding_leaf(
    const std::array<RoleBinding, role_count>& table,
    const Role role,
    const std::uint8_t capability) noexcept {
    for (const auto& entry : table) {
        if (entry.role != role) continue;
        if (capability == administrative_capability) return entry.administrative_leaf;
        if (capability == rollback_capability) return entry.rollback_leaf;
        return entry.view_leaf;
    }
    return no_index;
}

[[nodiscard]] Digest expected_admin(const AdmissionTrace& parent, const Role role) noexcept {
    if (role == Role::mechanism_operator) return parent.separation.mechanism_admin_digest;
    if (role == Role::independent_reopener) return parent.separation.reopener_admin_digest;
    if (role == Role::appraiser) return parent.separation.appraiser_admin_digest;
    return parent.separation.authorizer_admin_digest;
}

[[nodiscard]] Digest expected_rollback(const AdmissionTrace& parent, const Role role) noexcept {
    if (role == Role::mechanism_operator) return parent.separation.mechanism_rollback_digest;
    if (role == Role::independent_reopener) return parent.separation.reopener_rollback_digest;
    if (role == Role::appraiser) return parent.separation.appraiser_rollback_digest;
    return parent.separation.authorizer_rollback_digest;
}


struct ReferenceEncoder final {
    std::array<std::uint8_t, max_canonical_binding_bytes> storage{};
    std::size_t length{0U};

    void put(const std::uint8_t value) noexcept {
        if (length < storage.size()) storage[length++] = value;
    }

    void put_flag(const bool value) noexcept { put(value ? 1U : 0U); }

    void put_digest(const Digest& value) noexcept {
        for (const auto byte : value) put(byte);
    }

    void put_tag(const std::string_view value) noexcept {
        std::array<std::uint8_t, 32U> tag{};
        for (std::size_t index = 0U; index < value.size() && index < tag.size(); ++index) {
            tag[index] = static_cast<std::uint8_t>(value[index]);
        }
        for (const auto byte : tag) put(byte);
    }

    [[nodiscard]] Digest finish() const {
        return generation_journal::sha256(
            std::span<const std::uint8_t>(storage.data(), length));
    }
};

[[nodiscard]] Digest reference_graph_digest(const ControlGraphCapsule& graph) {
    ReferenceEncoder encoded{};
    encoded.put_tag("SlopOS/cff/graph/v2");
    encoded.put_digest(graph.parent_separation_digest);
    encoded.put_digest(graph.annex_digest);
    encoded.put_digest(graph.source_closure_digest);
    encoded.put_digest(graph.inventory_scope_digest);
    encoded.put_digest(graph.omitted_edge_policy_digest);
    encoded.put(graph.node_count);
    encoded.put(graph.edge_count);
    encoded.put(graph.binding_count);
    encoded.put_flag(graph.present);
    encoded.put_flag(graph.canonical);
    encoded.put_flag(graph.complete_inventory_claim);
    encoded.put_flag(graph.source_closed);
    encoded.put_flag(graph.exact_parent_bound);
    encoded.put_flag(graph.externally_supplied);
    encoded.put_flag(graph.owner_ratified);
    encoded.put_flag(graph.omitted_edge_policy_declared);
    encoded.put_flag(graph.self_generated_by_candidate);
    const auto nodes = std::min<std::size_t>(graph.node_count, graph.nodes.size());
    for (std::size_t index = 0U; index < nodes; ++index) {
        const auto& node = graph.nodes[index];
        encoded.put_digest(node.node_digest);
        encoded.put_digest(node.evidence_digest);
        encoded.put(static_cast<std::uint8_t>(node.kind));
        encoded.put_flag(node.present);
        encoded.put_flag(node.externally_identified);
    }
    const auto edges = std::min<std::size_t>(graph.edge_count, graph.edges.size());
    for (std::size_t index = 0U; index < edges; ++index) {
        const auto& edge = graph.edges[index];
        encoded.put(edge.controller);
        encoded.put(edge.controlled);
        encoded.put(edge.capability_mask);
        encoded.put_digest(edge.evidence_digest);
        encoded.put_flag(edge.present);
        encoded.put_flag(edge.externally_attested);
    }
    const auto bindings = std::min<std::size_t>(graph.binding_count, graph.bindings.size());
    for (std::size_t index = 0U; index < bindings; ++index) {
        const auto& binding = graph.bindings[index];
        encoded.put(static_cast<std::uint8_t>(binding.role));
        encoded.put(binding.administrative_leaf);
        encoded.put(binding.rollback_leaf);
        encoded.put(binding.view_leaf);
        encoded.put_digest(binding.binding_digest);
        encoded.put_flag(binding.present);
    }
    return encoded.finish();
}

[[nodiscard]] Digest reference_publication_digest(const ControlGraphCapsule& graph) {
    ReferenceEncoder encoded{};
    encoded.put_tag("SlopOS/cff/publish/v1");
    encoded.put_digest(graph.graph_digest);
    encoded.put_digest(graph.source_closure_digest);
    encoded.put_digest(graph.inventory_scope_digest);
    encoded.put_digest(graph.omitted_edge_policy_digest);
    encoded.put_flag(graph.durable);
    encoded.put_flag(graph.no_replace_published);
    encoded.put_flag(graph.single_view);
    return encoded.finish();
}

[[nodiscard]] Digest reference_challenge_digest(const ControlGraphCapsule& graph) {
    ReferenceEncoder encoded{};
    encoded.put_tag("SlopOS/cff/challenge/v1");
    encoded.put_digest(graph.graph_digest);
    encoded.put_digest(graph.publication_receipt_digest);
    encoded.put_digest(graph.source_closure_digest);
    encoded.put_digest(graph.inventory_scope_digest);
    encoded.put_digest(graph.omitted_edge_policy_digest);
    encoded.put_flag(graph.independently_reopenable);
    encoded.put_flag(graph.independently_challenged);
    return encoded.finish();
}

template <typename Value, std::size_t Extent>
[[nodiscard]] bool reference_tail_clear(
    const std::array<Value, Extent>& values,
    const std::size_t active) noexcept {
    for (std::size_t index = active; index < values.size(); ++index) {
        if (!(values[index] == Value{})) return false;
    }
    return true;
}

[[nodiscard]] bool reference_binding_order(const ControlGraphCapsule& graph) noexcept {
    for (std::size_t index = 0U; index < graph.binding_count; ++index) {
        if (static_cast<std::size_t>(graph.bindings[index].role) != index) return false;
    }
    return true;
}

[[nodiscard]] bool reference_tails_clear(const ControlGraphCapsule& graph) noexcept {
    return reference_tail_clear(graph.nodes, graph.node_count)
        && reference_tail_clear(graph.edges, graph.edge_count)
        && reference_tail_clear(graph.bindings, graph.binding_count);
}

}  // namespace

FateReport evaluate_reference(const FateTrace& trace) {
    const AdmissionReport parent = external_premise_admission::evaluate_reference(trace.parent);
    if (!parent.accepted) return stop(FateCode::parent_rejected);
    if (!(parent.external_premise_dossier_ready && parent.live_record_must_be_retained)) {
        return stop(FateCode::parent_not_ready_live, true, false);
    }

    const auto& graph = trace.graph;
    if (!graph.present || graph.node_count == 0U
        || graph.node_count > graph.nodes.size() || graph.edge_count > graph.edges.size()
        || graph.binding_count != graph.bindings.size()) {
        return stop(FateCode::graph_shape_invalid, true, true);
    }
    if (!graph.exact_parent_bound
        || !(graph.parent_separation_digest == trace.parent.separation.separation_digest)) {
        return stop(FateCode::parent_separation_binding_mismatch, true, true);
    }
    if (!(graph.annex_digest == trace.parent.annex.annex_digest)) {
        return stop(FateCode::annex_binding_mismatch, true, true);
    }

    for (std::size_t i = 0U; i < graph.node_count; ++i) {
        const ControlNode& node = graph.nodes[i];
        if (!(node.present && node.externally_identified && has_bytes(node.node_digest)
            && has_bytes(node.evidence_digest))) {
            return stop(FateCode::node_shape_invalid, true, true);
        }
        for (std::size_t j = 0U; j < i; ++j) {
            if (node.node_digest == graph.nodes[j].node_digest) {
                return stop(FateCode::duplicate_node_digest, true, true);
            }
        }
    }

    for (std::size_t i = 0U; i < graph.edge_count; ++i) {
        const ControlEdge& edge = graph.edges[i];
        const bool capability_ok = edge.capability_mask != 0U
            && (edge.capability_mask & static_cast<std::uint8_t>(~all_capabilities)) == 0U;
        if (!(edge.present && edge.externally_attested && has_bytes(edge.evidence_digest)
            && edge.controller < graph.node_count && edge.controlled < graph.node_count
            && edge.controller != edge.controlled && capability_ok)) {
            return stop(FateCode::edge_shape_invalid, true, true);
        }
        for (std::size_t j = 0U; j < i; ++j) {
            const ControlEdge& old = graph.edges[j];
            if (old.controller == edge.controller && old.controlled == edge.controlled
                && old.capability_mask == edge.capability_mask) {
                return stop(FateCode::duplicate_edge, true, true);
            }
        }
    }

    std::array<RoleBinding, role_count> ordered{};
    std::array<bool, role_count> observed{};
    for (std::size_t i = 0U; i < graph.binding_count; ++i) {
        const RoleBinding& binding = graph.bindings[i];
        const std::size_t role_number = static_cast<std::size_t>(binding.role);
        const bool leaves_in_range = binding.administrative_leaf < graph.node_count
            && binding.rollback_leaf < graph.node_count && binding.view_leaf < graph.node_count;
        if (!(binding.present && has_bytes(binding.binding_digest) && leaves_in_range)) {
            return stop(FateCode::binding_shape_invalid, true, true);
        }
        if (graph.nodes[binding.administrative_leaf].kind != NodeKind::role_leaf
            || graph.nodes[binding.rollback_leaf].kind != NodeKind::role_leaf
            || graph.nodes[binding.view_leaf].kind != NodeKind::role_leaf) {
            return stop(FateCode::binding_shape_invalid, true, true);
        }
        if (role_number >= observed.size() || observed[role_number]) {
            return stop(FateCode::binding_set_incomplete, true, true);
        }
        observed[role_number] = true;
        ordered[role_number] = binding;
    }
    for (const bool seen : observed) {
        if (!seen) return stop(FateCode::binding_set_incomplete, true, true);
    }

    const std::array<Role, 4U> inherited_roles{
        Role::mechanism_operator, Role::independent_reopener, Role::appraiser, Role::owner_admitter};
    for (const Role role : inherited_roles) {
        const auto& item = ordered[static_cast<std::size_t>(role)];
        if (graph.nodes[item.administrative_leaf].node_digest != expected_admin(trace.parent, role)
            || graph.nodes[item.rollback_leaf].node_digest != expected_rollback(trace.parent, role)) {
            return stop(FateCode::binding_leaf_mismatch, true, true);
        }
    }

    if (!has_bytes(graph.source_closure_digest)) {
        return stop(FateCode::source_closure_missing, true, true);
    }
    if (!has_bytes(graph.inventory_scope_digest)) {
        return stop(FateCode::inventory_scope_missing, true, true);
    }
    if (!has_bytes(graph.omitted_edge_policy_digest)) {
        return stop(FateCode::omitted_edge_policy_missing, true, true);
    }
    if (!reference_binding_order(graph)) {
        return stop(FateCode::canonical_binding_order_invalid, true, true);
    }
    if (!reference_tails_clear(graph)) {
        return stop(FateCode::canonical_tail_invalid, true, true);
    }
    if (graph.graph_digest != reference_graph_digest(graph)) {
        return stop(FateCode::graph_digest_mismatch, true, true);
    }
    if (graph.no_replace_published) {
        if (!has_bytes(graph.publication_receipt_digest)) {
            return stop(FateCode::publication_receipt_missing, true, true);
        }
        if (graph.publication_receipt_digest != reference_publication_digest(graph)) {
            return stop(FateCode::publication_receipt_binding_mismatch, true, true);
        }
    }
    if (graph.independently_challenged) {
        if (!has_bytes(graph.challenge_receipt_digest)) {
            return stop(FateCode::challenge_receipt_missing, true, true);
        }
        if (graph.challenge_receipt_digest != reference_challenge_digest(graph)) {
            return stop(FateCode::challenge_receipt_binding_mismatch, true, true);
        }
    }
    if (!exact_cut_sequence(trace)) return stop(FateCode::graph_cut_order_invalid, true, true);

    FateReport output{};
    output.accepted = true;
    output.parent_accepted = true;
    output.parent_ready_live_retained = true;
    output.parent_exactly_bound = true;
    output.graph_shape_valid = true;
    output.scope_policy_bound = true;
    output.canonical_order_valid = true;
    output.canonical_tail_clear = true;
    output.graph_digest_bound = true;
    output.publication_receipt_bound = !graph.no_replace_published
        || graph.publication_receipt_digest == reference_publication_digest(graph);
    output.challenge_receipt_bound = !graph.independently_challenged
        || graph.challenge_receipt_digest == reference_challenge_digest(graph);
    output.inventory_claim_closed = graph.canonical && graph.complete_inventory_claim
        && graph.source_closed && graph.externally_supplied && graph.owner_ratified
        && graph.omitted_edge_policy_declared && !graph.self_generated_by_candidate
        && output.scope_policy_bound && output.graph_digest_bound;
    output.publication_valid = graph.durable && graph.no_replace_published
        && graph.single_view && output.publication_receipt_bound;
    output.reopen_valid = output.publication_valid && graph.independently_reopenable;
    output.challenge_valid = output.reopen_valid && graph.independently_challenged
        && output.challenge_receipt_bound;
    output.cuts_ordered = true;

    if (graph.self_generated_by_candidate) {
        output.code = FateCode::accepted_refused_self_generated_capsule;
        return output;
    }
    if (!output.inventory_claim_closed) {
        output.code = FateCode::accepted_refused_inventory_open;
        return output;
    }
    if (!output.publication_valid) {
        output.code = FateCode::accepted_refused_capsule_unpublished;
        return output;
    }
    if (!output.reopen_valid) {
        output.code = FateCode::accepted_refused_capsule_not_reopened;
        return output;
    }
    if (!output.challenge_valid) {
        output.code = FateCode::accepted_refused_capsule_unchallenged;
        return output;
    }

    using Matrix = std::array<std::array<bool, max_control_nodes>, max_control_nodes>;
    std::array<Matrix, 3U> reaches{};
    for (std::size_t capability_index = 0U; capability_index < reaches.size(); ++capability_index) {
        for (std::size_t node = 0U; node < graph.node_count; ++node) reaches[capability_index][node][node] = true;
    }
    for (std::size_t edge_index = 0U; edge_index < graph.edge_count; ++edge_index) {
        const auto& edge = graph.edges[edge_index];
        for (std::size_t capability_index = 0U; capability_index < reaches.size(); ++capability_index) {
            const std::uint8_t bit = static_cast<std::uint8_t>(1U << capability_index);
            if ((edge.capability_mask & bit) != 0U) reaches[capability_index][edge.controller][edge.controlled] = true;
        }
    }
    for (std::size_t capability_index = 0U; capability_index < reaches.size(); ++capability_index) {
        for (std::size_t pivot = 0U; pivot < graph.node_count; ++pivot) {
            for (std::size_t from = 0U; from < graph.node_count; ++from) {
                if (!reaches[capability_index][from][pivot]) continue;
                for (std::size_t to = 0U; to < graph.node_count; ++to) {
                    reaches[capability_index][from][to] = reaches[capability_index][from][to]
                        || reaches[capability_index][pivot][to];
                }
            }
        }
    }

    struct PairRule final { Role a; Role b; std::uint8_t mask; };
    const std::array<PairRule, required_pair_count> rules{{
        {Role::mechanism_operator, Role::appraiser, 3U},
        {Role::corpus_producer, Role::appraiser, 3U},
        {Role::mechanism_operator, Role::owner_admitter, 3U},
        {Role::independent_reopener, Role::mechanism_operator, 3U},
        {Role::appraiser, Role::owner_admitter, 3U},
        {Role::transparency_witness, Role::owner_admitter, 7U},
    }};

    for (const auto& rule : rules) {
        for (std::size_t capability_index = 0U; capability_index < reaches.size(); ++capability_index) {
            const std::uint8_t bit = static_cast<std::uint8_t>(1U << capability_index);
            if ((rule.mask & bit) == 0U) continue;
            ++output.required_checks;
            const std::uint8_t left_leaf = binding_leaf(ordered, rule.a, bit);
            const std::uint8_t right_leaf = binding_leaf(ordered, rule.b, bit);
            for (std::size_t controller = 0U; controller < graph.node_count; ++controller) {
                if (!(reaches[capability_index][controller][left_leaf]
                    && reaches[capability_index][controller][right_leaf])) continue;
                ++output.refuted_checks;
                FateKind kind = FateKind::shared_view;
                if (bit == administrative_capability) {
                    kind = FateKind::administrative;
                    output.common_administrative_fate_detected = true;
                } else if (bit == rollback_capability) {
                    kind = FateKind::rollback;
                    output.common_rollback_fate_detected = true;
                } else {
                    output.common_view_fate_detected = true;
                }
                if (output.first_fate_kind == FateKind::none) {
                    output.first_fate_kind = kind;
                    output.first_role_a = rule.a;
                    output.first_role_b = rule.b;
                    output.first_common_node = static_cast<std::uint8_t>(controller);
                }
                break;
            }
        }
    }

    output.any_common_fate_detected = output.refuted_checks != 0U;
    output.no_common_fate_found_in_supplied_closure = !output.any_common_fate_detected;
    const std::uint8_t class_count = static_cast<std::uint8_t>(
        static_cast<std::uint8_t>(output.common_administrative_fate_detected)
        + static_cast<std::uint8_t>(output.common_rollback_fate_detected)
        + static_cast<std::uint8_t>(output.common_view_fate_detected));
    if (class_count > 1U) {
        output.code = FateCode::accepted_multiple_common_fates_detected;
        output.first_fate_kind = FateKind::multiple;
    } else if (output.common_administrative_fate_detected) {
        output.code = FateCode::accepted_common_administrative_fate_detected;
    } else if (output.common_rollback_fate_detected) {
        output.code = FateCode::accepted_common_rollback_fate_detected;
    } else if (output.common_view_fate_detected) {
        output.code = FateCode::accepted_common_view_fate_detected;
    } else {
        output.code = FateCode::accepted_no_common_fate_found_in_supplied_closure;
    }
    return output;
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification
