# Root ceremony anchor

**Plane:** LAB. **Epoch:** Zero. **Authority:** false.

This nested C++20 mechanism repairs three byte-level omissions in the hosted
root-succession rehearsal without pretending to operate the external ceremony:

1. the ceremony identifier now commits to exact RC0 and RC1 receipt digests,
   so “the successor was precommitted” cannot be inferred merely from a repeated
   successor head;
2. the signed relation commits to the expected register incarnation, not only a
   logical register name; and
3. the external compare/apply request identifier is derived from the exact
   transition, register incarnation, and precommit operation rather than chosen
   afresh after uncertainty.

The module is intentionally nested under
`generation_journal/transaction_dossier/signed_admission`. It is not a fourth
semantic island, provider client, signer, key manager, daemon, retry worker, or
authority API. It accepts already-observed receipt digests and one existing
320-byte root-succession statement. It cannot authenticate those receipts,
select the globally current external register, establish custody separation,
or advance the epoch.

## Build and run

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build
./build/slopos_root_ceremony_anchor output
python3 -B proof/verify_root_ceremony_anchor.py output
```

`SLOPOS_ENABLE_SANITIZERS=ON` enables AddressSanitizer and
UndefinedBehaviorSanitizer. The retained rev0915 evidence executes GCC, Clang,
and a sanitizer lane, compares all canonical campaign artifacts byte for byte,
and reopens them with the independent Python verifier.

## Result boundary

A `RELATION_VALID` result means only that canonical anchor bytes and canonical
root-statement bytes agree on exact identities, versions, receipt digests,
chronology fields, and deterministic request identity at the observed time.
Every valid report still says:

- external receipt authenticity: false;
- owner constitution: false;
- global currentness: false;
- independent custody: false;
- protected transition: false;
- independent reopen: false;
- epoch exit: false; and
- authority granted: false.
