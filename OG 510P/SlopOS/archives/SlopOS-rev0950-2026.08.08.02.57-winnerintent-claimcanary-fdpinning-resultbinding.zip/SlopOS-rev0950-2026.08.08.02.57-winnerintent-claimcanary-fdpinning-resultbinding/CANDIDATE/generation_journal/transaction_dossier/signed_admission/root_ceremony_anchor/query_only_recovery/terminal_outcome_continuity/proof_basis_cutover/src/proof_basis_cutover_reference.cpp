#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover.hpp"

#include <algorithm>
#include <array>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover {
namespace {

[[nodiscard]] bool any_byte(const Digest& value) noexcept {
    return std::find_if(value.begin(), value.end(), [](const std::uint8_t byte) {
        return byte != 0U;
    }) != value.end();
}

[[nodiscard]] CutoverReport refused(const CutoverCode code) noexcept {
    CutoverReport output{};
    output.code = code;
    output.accepted = false;
    return output;
}

[[nodiscard]] CutoverReport accepted(
    const CutoverCode code,
    const std::array<bool, 5U>& premises,
    const bool all_cuts,
    const bool execution_gap,
    const bool history_gap,
    const bool join_gap,
    const bool reopen_gap,
    const bool phase_order_gap,
    const bool regression,
    const bool ready,
    const bool safe,
    const bool fail_stop) noexcept {
    return CutoverReport{
        code,
        true,
        premises[0],
        premises[1],
        premises[2],
        premises[3],
        premises[4],
        all_cuts,
        execution_gap,
        history_gap,
        join_gap,
        reopen_gap,
        phase_order_gap,
        regression,
        ready,
        safe,
        !safe,
        fail_stop,
        false,
        false,
        false,
        false,
        false,
        false,
    };
}

}  // namespace

CutoverReport evaluate_reference(const CutoverTrace& trace) noexcept {
    const std::array<bool, 4U> state_fields{
        any_byte(trace.state.request_id),
        any_byte(trace.state.transition_digest),
        any_byte(trace.state.register_incarnation),
        any_byte(trace.state.terminal_digest),
    };
    if (!std::all_of(state_fields.begin(), state_fields.end(), [](const bool value) { return value; })) {
        return refused(CutoverCode::invalid_terminal_state);
    }

    const auto parent = terminal_outcome_continuity::evaluate_reference(
        trace.state, trace.continuity);
    if (!parent.accepted) return refused(CutoverCode::parent_evidence_rejected);
    if (!any_byte(trace.cutover_id)) return refused(CutoverCode::cutover_id_zero);
    if (!any_byte(trace.witness_digest)) return refused(CutoverCode::witness_digest_zero);
    if (!any_byte(trace.floor_digest)) return refused(CutoverCode::floor_digest_zero);
    if (trace.reclamation_requested != trace.continuity.reclamation_requested) {
        return refused(CutoverCode::reclamation_request_mismatch);
    }

    const std::array<bool, 13U> dependent_join_fields{
        trace.join.authenticated,
        trace.join.durable,
        trace.join.single_view,
        trace.join.independently_reopenable,
        trace.join.survives_restore,
        trace.join.survives_succession,
        any_byte(trace.join.cutover_id),
        any_byte(trace.join.request_id),
        any_byte(trace.join.transition_digest),
        any_byte(trace.join.register_incarnation),
        any_byte(trace.join.terminal_digest),
        any_byte(trace.join.witness_digest),
        any_byte(trace.join.floor_digest),
    };
    if (!trace.join.present
        && std::any_of(dependent_join_fields.begin(), dependent_join_fields.end(), [](const bool value) { return value; })) {
        return refused(CutoverCode::join_receipt_shape_invalid);
    }
    if (trace.join.present) {
        const std::array<bool, 8U> matches{
            trace.join.cutover_id == trace.cutover_id,
            trace.join.request_id == trace.state.request_id,
            trace.join.transition_digest == trace.state.transition_digest,
            trace.join.register_incarnation == trace.state.register_incarnation,
            trace.join.terminal_digest == trace.state.terminal_digest,
            trace.join.terminal_kind == trace.state.terminal_kind,
            trace.join.witness_digest == trace.witness_digest,
            trace.join.floor_digest == trace.floor_digest,
        };
        const std::array<CutoverCode, 8U> mismatch_codes{
            CutoverCode::join_cutover_id_mismatch,
            CutoverCode::join_request_id_mismatch,
            CutoverCode::join_transition_digest_mismatch,
            CutoverCode::join_register_incarnation_mismatch,
            CutoverCode::join_terminal_digest_mismatch,
            CutoverCode::join_terminal_kind_mismatch,
            CutoverCode::join_witness_digest_mismatch,
            CutoverCode::join_floor_digest_mismatch,
        };
        for (std::size_t index = 0U; index < matches.size(); ++index) {
            if (!matches[index]) return refused(mismatch_codes[index]);
        }
    }

    if (!trace.cuts[0].live_record_visible || trace.cuts[0].record_deleted) {
        return refused(CutoverCode::trace_initial_state_invalid);
    }
    bool joined_once = false;
    for (const auto& cut : trace.cuts) {
        if (cut.live_record_visible && cut.record_deleted) {
            return refused(CutoverCode::trace_deleted_and_live);
        }
        const bool joined_now = cut.join_visible
            && cut.witness_visible
            && cut.floor_visible;
        if (cut.cold_reopen_observed && !(joined_now || joined_once)) {
            return refused(CutoverCode::trace_reopen_without_joined_basis);
        }
        if (cut.join_visible && !(cut.witness_visible && cut.floor_visible)
            && !joined_once) {
            return refused(CutoverCode::trace_join_without_components);
        }
        joined_once = joined_once || joined_now;
        if (!(cut.live_record_visible || cut.record_deleted)) {
            return refused(CutoverCode::trace_live_absent_without_deletion);
        }
    }

    const std::array<bool, 5U> premises{
        parent.terminal_record_execution_path && parent.terminal_record_history_path,
        parent.terminal_witness_history_path,
        parent.successor_floor_execution_path,
        trace.join.present && trace.join.authenticated && trace.join.durable && trace.join.single_view,
        trace.join.present && trace.join.authenticated && trace.join.durable && trace.join.single_view
            && trace.join.independently_reopenable
            && trace.join.survives_restore
            && trace.join.survives_succession,
    };

    std::array<bool, cut_count> coverage{};
    bool execution_gap = false;
    bool history_gap = false;
    bool join_gap = false;
    bool phase_order_gap = false;
    bool regression = false;
    // witness, floor, join, reopen, authorization, deletion
    std::array<bool, 6U> latched{};
    bool live_absent = false;

    for (std::size_t index = 0U; index < trace.cuts.size(); ++index) {
        const auto& cut = trace.cuts[index];
        const std::array<bool, 4U> paths{
            cut.live_record_visible && parent.terminal_record_execution_path,
            cut.live_record_visible && parent.terminal_record_history_path,
            cut.witness_visible && premises[1],
            cut.floor_visible && premises[2],
        };
        const bool joined = cut.witness_visible
            && cut.floor_visible
            && cut.join_visible
            && premises[1]
            && premises[2]
            && premises[3];
        const bool execution = paths[0] || paths[3];
        const bool history = paths[1] || paths[2];
        const bool same_basis = (cut.live_record_visible && premises[0]) || joined;
        const bool reopened = cut.cold_reopen_observed && joined && premises[4];

        const std::array<bool, 6U> now{
            cut.witness_visible,
            cut.floor_visible,
            cut.join_visible,
            cut.cold_reopen_observed,
            cut.deletion_authorized,
            cut.record_deleted,
        };
        const bool new_join = now[2] && !latched[2];
        const bool new_reopen = now[3] && !latched[3];
        const bool new_authorization = now[4] && !latched[4];
        const bool new_deletion = now[5] && !latched[5];
        const std::array<bool, 4U> order_checks{
            !new_join || (latched[0] && latched[1]),
            !new_reopen || latched[2],
            !new_authorization || latched[3],
            !new_deletion || latched[4],
        };
        const bool order_ok = std::all_of(
            order_checks.begin(), order_checks.end(), [](const bool value) { return value; });
        const bool authorization_ok = !cut.deletion_authorized
            || (order_checks[2] && reopened);
        const bool deletion_ok = authorization_ok
            && (!cut.record_deleted
                || (cut.deletion_authorized && order_checks[3] && reopened));
        coverage[index] = execution && history && same_basis && order_ok && deletion_ok;
        execution_gap = execution_gap || !execution;
        history_gap = history_gap || !history;
        join_gap = join_gap || (execution && history && !same_basis);
        phase_order_gap = phase_order_gap || !order_ok;

        for (std::size_t slot = 0U; slot < now.size(); ++slot) {
            regression = regression || (latched[slot] && !now[slot]);
            latched[slot] = latched[slot] || now[slot];
        }
        regression = regression || (live_absent && cut.live_record_visible);
        live_absent = live_absent || !cut.live_record_visible;
    }

    const bool all_cuts = std::all_of(
        coverage.begin(), coverage.end(), [](const bool value) { return value; });
    const auto& last = trace.cuts.back();
    const bool final_joined = last.witness_visible
        && last.floor_visible
        && last.join_visible
        && premises[1]
        && premises[2]
        && premises[3];
    const bool reopen_gap = trace.reclamation_requested
        && final_joined
        && (!premises[4] || !last.cold_reopen_observed);
    const bool ready = !trace.equivocation_observed
        && !regression
        && !phase_order_gap
        && all_cuts
        && last.live_record_visible
        && !last.record_deleted
        && last.cold_reopen_observed
        && final_joined
        && premises[4];
    const bool safe = !trace.equivocation_observed
        && !regression
        && !phase_order_gap
        && all_cuts
        && trace.reclamation_requested
        && last.record_deleted
        && !last.live_record_visible
        && last.deletion_authorized
        && last.cold_reopen_observed
        && final_joined
        && premises[4];

    if (trace.equivocation_observed) {
        return accepted(
            CutoverCode::accepted_equivocation_fail_stop,
            premises, false, execution_gap, history_gap, true, true,
            phase_order_gap, regression, false, false, true);
    }
    if (regression) {
        return accepted(
            CutoverCode::accepted_regression_fail_stop,
            premises, false, execution_gap, history_gap, join_gap, true,
            phase_order_gap, true, false, false, true);
    }
    if (safe) {
        return accepted(
            CutoverCode::accepted_cutover_complete,
            premises, true, false, false, false, false,
            false, false, false, true, false);
    }
    if (ready) {
        return accepted(
            CutoverCode::accepted_cutover_ready_live_retained,
            premises, true, false, false, false, false,
            false, false, true, false, false);
    }
    if (reopen_gap) {
        return accepted(
            CutoverCode::accepted_reclamation_refused_reopen_gap,
            premises, all_cuts, execution_gap, history_gap, join_gap, true,
            phase_order_gap, false, false, false, false);
    }
    if (all_cuts && last.live_record_visible && premises[0]) {
        return accepted(
            CutoverCode::accepted_live_basis_retained,
            premises, true, false, false, false, false,
            false, false, false, false, false);
    }
    if (execution_gap) {
        return accepted(
            CutoverCode::accepted_reclamation_refused_execution_gap,
            premises, false, true, history_gap, join_gap, reopen_gap,
            phase_order_gap, false, false, false, false);
    }
    if (history_gap) {
        return accepted(
            CutoverCode::accepted_reclamation_refused_history_gap,
            premises, false, false, true, join_gap, reopen_gap,
            phase_order_gap, false, false, false, false);
    }
    if (join_gap) {
        return accepted(
            CutoverCode::accepted_reclamation_refused_join_gap,
            premises, false, false, false, true, reopen_gap,
            phase_order_gap, false, false, false, false);
    }
    if (phase_order_gap) {
        return accepted(
            CutoverCode::accepted_reclamation_refused_order_gap,
            premises, false, false, false, false, reopen_gap,
            true, false, false, false, false);
    }
    return accepted(
        CutoverCode::accepted_reclamation_refused_reopen_gap,
        premises, all_cuts, false, false, false, true,
        false, false, false, false, false);
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover
