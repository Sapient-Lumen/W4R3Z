#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/reopen_receipt_chain/external_premise_admission/control_fate_falsification/relocatable_provenance/observed_output_closure/hosted_externality_nonderivation.hpp"

#include "slopos/e0/generation_journal/spend_record.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <span>
#include <string_view>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification::relocatable_provenance::observed_output_closure::hosted_externality_nonderivation {
namespace {

[[nodiscard]] constexpr std::uint8_t nybble(const char c) noexcept {
    return c >= '0' && c <= '9' ? static_cast<std::uint8_t>(c - '0')
        : c >= 'a' && c <= 'f' ? static_cast<std::uint8_t>(c - 'a' + 10) : 0xffU;
}

[[nodiscard]] Digest parse_hash(const std::string_view text) noexcept {
    Digest result{};
    if (text.size() != 64U) return result;
    for (std::size_t i = 0U; i != result.size(); ++i) {
        const auto a = nybble(text[2U * i]);
        const auto b = nybble(text[2U * i + 1U]);
        if (a == 0xffU || b == 0xffU) return {};
        result[i] = static_cast<std::uint8_t>(a * 16U + b);
    }
    return result;
}

template <std::size_t N>
void ascii8(std::array<std::uint8_t, N>& bytes, const std::string_view text) noexcept {
    for (std::size_t i = 0U; i < 8U; ++i) bytes[i] = i < text.size() ? static_cast<std::uint8_t>(text[i]) : 0U;
}

template <std::size_t N>
void be16(std::array<std::uint8_t, N>& bytes, const std::size_t at, const std::uint16_t value) noexcept {
    bytes[at] = static_cast<std::uint8_t>(value / 256U);
    bytes[at + 1U] = static_cast<std::uint8_t>(value % 256U);
}

template <std::size_t N>
void be32(std::array<std::uint8_t, N>& bytes, const std::size_t at, const std::uint32_t value) noexcept {
    bytes[at] = static_cast<std::uint8_t>((value >> 24U) & 255U);
    bytes[at + 1U] = static_cast<std::uint8_t>((value >> 16U) & 255U);
    bytes[at + 2U] = static_cast<std::uint8_t>((value >> 8U) & 255U);
    bytes[at + 3U] = static_cast<std::uint8_t>(value & 255U);
}

template <std::size_t N>
void be64(std::array<std::uint8_t, N>& bytes, const std::size_t at, const std::uint64_t value) noexcept {
    for (std::size_t i = 0U; i < 8U; ++i) bytes[at + i] = static_cast<std::uint8_t>((value >> (56U - 8U * i)) & 255U);
}

template <std::size_t N>
void place(std::array<std::uint8_t, N>& bytes, const std::size_t at, const Digest& digest) noexcept {
    std::copy(digest.begin(), digest.end(), bytes.begin() + static_cast<std::ptrdiff_t>(at));
}

[[nodiscard]] std::uint16_t obs_bits(const HostedObservation& x) noexcept {
    return static_cast<std::uint16_t>((x.present ? 1U : 0U) + (x.canonical ? 2U : 0U)
        + (x.hosted_bytes_only ? 4U : 0U) + (x.external_receipt_absent ? 8U : 0U));
}
[[nodiscard]] std::uint16_t twin_bits(const TwinWorldWitness& x) noexcept {
    return static_cast<std::uint16_t>((x.present ? 1U : 0U) + (x.canonical ? 2U : 0U)
        + (x.countermodel_only ? 4U : 0U) + (x.no_external_occurrence_claimed ? 8U : 0U));
}
[[nodiscard]] std::uint16_t handoff_bits(const OwnerHandoffRequest& x) noexcept {
    return static_cast<std::uint16_t>((x.present ? 1U : 0U) + (x.canonical ? 2U : 0U)
        + (x.request_only ? 4U : 0U) + (x.no_authority_claim ? 8U : 0U));
}
[[nodiscard]] std::uint16_t deficit_bits(const PremiseDeficitCertificate& x) noexcept {
    return static_cast<std::uint16_t>((x.present ? 1U : 0U) + (x.canonical ? 2U : 0U)
        + (x.all_requested_claims_unresolved ? 4U : 0U) + (x.external_response_absent ? 8U : 0U)
        + (x.no_acceptance_or_authority ? 16U : 0U));
}

[[nodiscard]] EncodedHostedObservation observation_image(const HostedObservation& x) noexcept {
    EncodedHostedObservation b{};
    ascii8(b, "SLOPHO1");
    be32(b, 8U, x.schema_version); be16(b, 12U, x.requested_claim_mask); be16(b, 14U, obs_bits(x));
    be64(b, 16U, x.linked_parent_archive_bytes); be64(b, 24U, x.linked_parent_manifest_rows);
    place(b, 32U, x.parent_closure_claim_digest); place(b, 64U, x.parent_manifest_digest);
    place(b, 96U, x.parent_publication_receipt_digest); place(b, 128U, x.parent_reopen_receipt_digest);
    place(b, 160U, x.linked_parent_archive_digest); place(b, 192U, x.claim_catalogue_digest);
    place(b, 224U, x.handoff_policy_digest);
    return b;
}

[[nodiscard]] EncodedTwinWorldWitness twin_image(const TwinWorldWitness& x) noexcept {
    EncodedTwinWorldWitness b{};
    ascii8(b, "SLOPTW1");
    be32(b, 8U, x.schema_version); be16(b, 12U, x.requested_claim_mask); be16(b, 14U, twin_bits(x));
    be16(b, 16U, x.left_true_mask); be16(b, 18U, x.right_true_mask); be32(b, 20U, 0U);
    place(b, 24U, x.observation_digest); place(b, 56U, x.left_world_label_digest);
    place(b, 88U, x.right_world_label_digest); place(b, 120U, x.claim_catalogue_digest);
    place(b, 152U, x.handoff_policy_digest); place(b, 184U, x.parent_closure_claim_digest);
    return b;
}

[[nodiscard]] EncodedOwnerHandoffRequest handoff_image(const OwnerHandoffRequest& x) noexcept {
    EncodedOwnerHandoffRequest b{};
    ascii8(b, "SLOPHR1");
    be32(b, 8U, x.schema_version); be16(b, 12U, x.requested_claim_mask); be16(b, 14U, handoff_bits(x));
    be64(b, 16U, x.linked_parent_archive_bytes); be64(b, 24U, x.linked_parent_manifest_rows);
    place(b, 32U, x.linked_parent_archive_digest); place(b, 64U, x.parent_closure_claim_digest);
    place(b, 96U, x.observation_digest); place(b, 128U, x.witness_digest);
    place(b, 160U, x.claim_catalogue_digest); place(b, 192U, x.handoff_policy_digest);
    place(b, 224U, x.requested_response_profile_digest); place(b, 256U, x.response_namespace_digest);
    return b;
}

[[nodiscard]] EncodedPremiseDeficitCertificate deficit_image(const PremiseDeficitCertificate& x) noexcept {
    EncodedPremiseDeficitCertificate b{};
    ascii8(b, "SLOPDF1");
    be32(b, 8U, x.schema_version); be16(b, 12U, x.unresolved_claim_mask); be16(b, 14U, deficit_bits(x));
    place(b, 16U, x.observation_digest); place(b, 48U, x.witness_digest); place(b, 80U, x.request_digest);
    place(b, 112U, x.parent_closure_claim_digest); place(b, 144U, x.claim_catalogue_digest);
    place(b, 176U, x.handoff_policy_digest); place(b, 208U, x.requested_response_profile_digest);
    return b;
}

template <std::size_t N>
[[nodiscard]] Digest hash_image(const std::array<std::uint8_t, N>& bytes) noexcept {
    return generation_journal::sha256(std::span<const std::uint8_t>(bytes.data(), bytes.size()));
}

[[nodiscard]] bool digest_present(const Digest& x) noexcept {
    return std::any_of(x.begin(), x.end(), [](const std::uint8_t b) { return b != 0U; });
}

[[nodiscard]] bool mask_ok(const std::uint16_t x) noexcept {
    return x > 0U && (x & 0x8000U) == 0U;
}

[[nodiscard]] bool fact_ok(const ExternalFacts& x) noexcept {
    return x.canonical && (x.true_mask & 0x8000U) == 0U;
}

[[nodiscard]] bool stage_cuts(const ExternalityTrace& trace) noexcept {
    for (std::size_t i = 0U; i < trace.cuts.size(); ++i) {
        ExternalityCut wanted{};
        wanted.parent_closure_claim_digest = trace.parent.claim.claim_digest;
        if (i >= 1U && trace.left_observation.present && trace.right_observation.present) wanted.observation_digest = trace.left_observation.observation_digest;
        if (i >= 2U && trace.witness.present) wanted.witness_digest = trace.witness.witness_digest;
        if (i >= 3U && trace.request.present) wanted.request_digest = trace.request.request_digest;
        if (i >= 4U && trace.deficit.present) wanted.deficit_certificate_digest = trace.deficit.certificate_digest;
        if (wanted != trace.cuts[i]) return false;
    }
    return true;
}

[[nodiscard]] BoundaryReport end(BoundaryReport report, const BoundaryCode code, const bool accepted) noexcept {
    report.code = code;
    report.accepted = accepted;
    return report;
}

}  // namespace

BoundaryReport evaluate_reference(const ExternalityTrace& trace) noexcept {
    BoundaryReport r{};
    const auto p = observed_output_closure::evaluate_reference(trace.parent);
    r.parent_accepted = p.accepted;
    r.parent_closure_ready = p.closure_ready;
    if (!p.accepted) return end(r, BoundaryCode::parent_rejected, false);
    if (!p.closure_ready) return end(r, BoundaryCode::parent_not_closure_ready, false);

    r.cuts_ordered = stage_cuts(trace);
    if (!r.cuts_ordered) return end(r, BoundaryCode::cut_order_invalid, false);

    const unsigned observation_count = static_cast<unsigned>(trace.left_observation.present)
        + static_cast<unsigned>(trace.right_observation.present);
    if (observation_count == 0U) {
        if (trace.witness.present || trace.request.present || trace.deficit.present) {
            return end(r, BoundaryCode::witness_without_observation, false);
        }
        return end(r, BoundaryCode::accepted_parent_closed, true);
    }
    if (observation_count != 2U) return end(r, BoundaryCode::observation_pair_incomplete, false);

    const auto exact_archive = parse_hash(SLOPOS_HEN_LINKED_PARENT_ARCHIVE_SHA256_HEX);
    const auto exact_catalogue = parse_hash(SLOPOS_HEN_CLAIM_CATALOGUE_SHA256_HEX);
    const auto exact_policy = parse_hash(SLOPOS_HEN_HANDOFF_POLICY_SHA256_HEX);
    const auto exact_profile = parse_hash(SLOPOS_HEN_RESPONSE_PROFILE_SHA256_HEX);

    const auto observation_form = [](const HostedObservation& x) {
        return x.present && x.canonical && x.hosted_bytes_only && x.external_receipt_absent
            && x.schema_version == externality_schema_version
            && x.linked_parent_archive_bytes == SLOPOS_HEN_LINKED_PARENT_ARCHIVE_BYTES
            && x.linked_parent_manifest_rows == SLOPOS_HEN_LINKED_PARENT_MANIFEST_ROWS;
    };
    if (!observation_form(trace.left_observation) || !observation_form(trace.right_observation)) {
        return end(r, BoundaryCode::observation_shape_invalid, false);
    }
    r.claim_mask_valid = mask_ok(trace.left_observation.requested_claim_mask)
        && mask_ok(trace.right_observation.requested_claim_mask);
    if (!r.claim_mask_valid) return end(r, BoundaryCode::claim_mask_invalid, false);

    const auto observation_bound = [&](const HostedObservation& x) {
        const std::array<bool, 7U> links{{
            x.parent_closure_claim_digest == trace.parent.claim.claim_digest,
            x.parent_manifest_digest == trace.parent.manifest.manifest_digest,
            x.parent_publication_receipt_digest == trace.parent.publication.receipt_digest,
            x.parent_reopen_receipt_digest == trace.parent.reopen.receipt_digest,
            x.linked_parent_archive_digest == exact_archive,
            x.claim_catalogue_digest == exact_catalogue,
            x.handoff_policy_digest == exact_policy,
        }};
        return std::all_of(links.begin(), links.end(), [](const bool value) { return value; });
    };
    if (!observation_bound(trace.left_observation) || !observation_bound(trace.right_observation)) {
        return end(r, BoundaryCode::observation_binding_mismatch, false);
    }
    const auto left_image = observation_image(trace.left_observation);
    const auto right_image = observation_image(trace.right_observation);
    if (hash_image(left_image) != trace.left_observation.observation_digest
        || hash_image(right_image) != trace.right_observation.observation_digest) {
        return end(r, BoundaryCode::observation_digest_mismatch, false);
    }
    r.observations_valid = true;
    r.observations_byte_identical = std::equal(left_image.begin(), left_image.end(), right_image.begin(), right_image.end());
    if (!r.observations_byte_identical) return end(r, BoundaryCode::observations_not_equivalent, false);

    if (!trace.witness.present) {
        if (trace.request.present || trace.deficit.present) return end(r, BoundaryCode::request_without_witness, false);
        return end(r, BoundaryCode::accepted_observation_durable, true);
    }

    r.external_facts_valid = fact_ok(trace.left_external_facts) && fact_ok(trace.right_external_facts);
    if (!r.external_facts_valid) return end(r, BoundaryCode::external_fact_mask_invalid, false);
    r.requested_claims_diverge = static_cast<std::uint16_t>(trace.left_external_facts.true_mask ^ trace.right_external_facts.true_mask)
        == trace.left_observation.requested_claim_mask;
    if (!r.requested_claims_diverge) return end(r, BoundaryCode::requested_claims_do_not_diverge, false);

    const auto& w = trace.witness;
    const bool witness_form = w.present && w.canonical && w.countermodel_only && w.no_external_occurrence_claimed
        && w.schema_version == externality_schema_version && mask_ok(w.requested_claim_mask)
        && digest_present(w.left_world_label_digest) && digest_present(w.right_world_label_digest)
        && w.left_world_label_digest != w.right_world_label_digest;
    if (!witness_form) return end(r, BoundaryCode::witness_shape_invalid, false);
    const std::array<bool, 7U> witness_links{{
        w.observation_digest == trace.left_observation.observation_digest,
        w.claim_catalogue_digest == trace.left_observation.claim_catalogue_digest,
        w.handoff_policy_digest == trace.left_observation.handoff_policy_digest,
        w.parent_closure_claim_digest == trace.parent.claim.claim_digest,
        w.requested_claim_mask == trace.left_observation.requested_claim_mask,
        w.left_true_mask == trace.left_external_facts.true_mask,
        w.right_true_mask == trace.right_external_facts.true_mask,
    }};
    if (!std::all_of(witness_links.begin(), witness_links.end(), [](const bool value) { return value; })) {
        return end(r, BoundaryCode::witness_binding_mismatch, false);
    }
    if (hash_image(twin_image(w)) != w.witness_digest) return end(r, BoundaryCode::witness_digest_mismatch, false);
    r.witness_valid = true;
    r.nonderivation_witness = true;

    if (!trace.request.present) {
        if (trace.deficit.present) return end(r, BoundaryCode::deficit_without_request, false);
        return end(r, BoundaryCode::accepted_nonderivation_witness, true);
    }

    const auto& q = trace.request;
    const bool request_form = q.present && q.canonical && q.request_only && q.no_authority_claim
        && q.schema_version == externality_schema_version && mask_ok(q.requested_claim_mask)
        && q.linked_parent_archive_bytes == SLOPOS_HEN_LINKED_PARENT_ARCHIVE_BYTES
        && q.linked_parent_manifest_rows == SLOPOS_HEN_LINKED_PARENT_MANIFEST_ROWS
        && digest_present(q.response_namespace_digest);
    if (!request_form) return end(r, BoundaryCode::request_shape_invalid, false);
    const std::array<bool, 8U> request_links{{
        q.linked_parent_archive_digest == exact_archive,
        q.parent_closure_claim_digest == trace.parent.claim.claim_digest,
        q.observation_digest == trace.left_observation.observation_digest,
        q.witness_digest == w.witness_digest,
        q.claim_catalogue_digest == exact_catalogue,
        q.handoff_policy_digest == exact_policy,
        q.requested_response_profile_digest == exact_profile,
        q.requested_claim_mask == trace.left_observation.requested_claim_mask,
    }};
    if (!std::all_of(request_links.begin(), request_links.end(), [](const bool value) { return value; })) {
        return end(r, BoundaryCode::request_binding_mismatch, false);
    }
    if (hash_image(handoff_image(q)) != q.request_digest) return end(r, BoundaryCode::request_digest_mismatch, false);
    r.request_valid = true;
    if (trace.promote_requested_claims_from_hosted_bytes) return end(r, BoundaryCode::hosted_promotion_forbidden, false);

    if (!trace.deficit.present) return end(r, BoundaryCode::accepted_handoff_request_durable, true);

    const auto& d = trace.deficit;
    const bool deficit_form = d.present && d.canonical && d.all_requested_claims_unresolved
        && d.external_response_absent && d.no_acceptance_or_authority
        && d.schema_version == externality_schema_version && mask_ok(d.unresolved_claim_mask);
    if (!deficit_form) return end(r, BoundaryCode::deficit_shape_invalid, false);
    const std::array<bool, 8U> deficit_links{{
        d.observation_digest == trace.left_observation.observation_digest,
        d.witness_digest == w.witness_digest,
        d.request_digest == q.request_digest,
        d.parent_closure_claim_digest == trace.parent.claim.claim_digest,
        d.claim_catalogue_digest == exact_catalogue,
        d.handoff_policy_digest == exact_policy,
        d.requested_response_profile_digest == exact_profile,
        d.unresolved_claim_mask == trace.left_observation.requested_claim_mask,
    }};
    if (!std::all_of(deficit_links.begin(), deficit_links.end(), [](const bool value) { return value; })) {
        return end(r, BoundaryCode::deficit_binding_mismatch, false);
    }
    if (hash_image(deficit_image(d)) != d.certificate_digest) return end(r, BoundaryCode::deficit_digest_mismatch, false);
    r.deficit_valid = true;
    r.owner_handoff_ready = true;
    return end(r, BoundaryCode::accepted_premise_deficit_durable, true);
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification::relocatable_provenance::observed_output_closure::hosted_externality_nonderivation
