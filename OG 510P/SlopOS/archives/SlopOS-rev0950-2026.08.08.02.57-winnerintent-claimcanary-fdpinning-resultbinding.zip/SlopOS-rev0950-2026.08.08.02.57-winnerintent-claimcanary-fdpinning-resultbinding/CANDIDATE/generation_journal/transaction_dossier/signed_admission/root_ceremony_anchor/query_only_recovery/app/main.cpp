#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery.hpp"

#include <filesystem>
#include <iostream>

int main(const int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "usage: slopos_query_only_recovery OUTPUT_DIRECTORY\n";
        return 2;
    }
    const std::filesystem::path output(argv[1]);
    if (!slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::run_campaign(output)) {
        std::cerr << "QUERY_ONLY_RECOVERY_CAMPAIGN=FAIL\n";
        return 1;
    }
    std::cout
        << "QUERY_ONLY_RECOVERY_CAMPAIGN=PASS cases=54 accepted=12 rejected=42 "
        << "absence_terminal=0 terminal_no_effect=2 disagreements=0 authority=false\n";
    return 0;
}
