#include "slopos/e0/transaction_dossier/dossier.hpp"

#include <algorithm>
#include <array>
#include <limits>
#include <string>
#include <vector>

namespace slopos::e0::transaction_dossier {
namespace {

constexpr std::array<std::uint8_t, 8U> kMagic{{
    'S', 'L', 'O', 'P', 'T', 'X', '0', '1',
}};
constexpr std::uint16_t kVersion = 1U;
constexpr std::string_view kIntegrityDomain = "SlopOS/transaction-dossier/v1/integrity";
constexpr std::string_view kHeadDomain = "SlopOS/transaction-dossier/v1/head";
constexpr std::string_view kTransactionDomain = "SlopOS/transaction-dossier/v1/transaction";
constexpr std::string_view kLabelDomain = "SlopOS/rev0912/transaction-dossier/fixture";

[[nodiscard]] bool digest_zero(const Digest& value) noexcept {
    return std::all_of(value.begin(), value.end(), [](const std::uint8_t byte) {
        return byte == 0U;
    });
}

void put_u16(EncodedRecord& output, const std::size_t offset,
             const std::uint16_t value) noexcept {
    output[offset] = static_cast<std::uint8_t>(value >> 8U);
    output[offset + 1U] = static_cast<std::uint8_t>(value);
}

void put_u32(EncodedRecord& output, const std::size_t offset,
             const std::uint32_t value) noexcept {
    output[offset] = static_cast<std::uint8_t>(value >> 24U);
    output[offset + 1U] = static_cast<std::uint8_t>(value >> 16U);
    output[offset + 2U] = static_cast<std::uint8_t>(value >> 8U);
    output[offset + 3U] = static_cast<std::uint8_t>(value);
}

void put_u64(EncodedRecord& output, const std::size_t offset,
             const std::uint64_t value) noexcept {
    for (std::size_t index = 0U; index < 8U; ++index) {
        const unsigned int shift = static_cast<unsigned int>((7U - index) * 8U);
        output[offset + index] = static_cast<std::uint8_t>(value >> shift);
    }
}

[[nodiscard]] std::uint16_t get_u16(const EncodedRecord& input,
                                    const std::size_t offset) noexcept {
    return static_cast<std::uint16_t>(
        (static_cast<std::uint16_t>(input[offset]) << 8U)
        | static_cast<std::uint16_t>(input[offset + 1U]));
}

[[nodiscard]] std::uint32_t get_u32(const EncodedRecord& input,
                                    const std::size_t offset) noexcept {
    return (static_cast<std::uint32_t>(input[offset]) << 24U)
        | (static_cast<std::uint32_t>(input[offset + 1U]) << 16U)
        | (static_cast<std::uint32_t>(input[offset + 2U]) << 8U)
        | static_cast<std::uint32_t>(input[offset + 3U]);
}

[[nodiscard]] std::uint64_t get_u64(const EncodedRecord& input,
                                    const std::size_t offset) noexcept {
    std::uint64_t value = 0U;
    for (std::size_t index = 0U; index < 8U; ++index) {
        value = (value << 8U) | static_cast<std::uint64_t>(input[offset + index]);
    }
    return value;
}

void put_digest(EncodedRecord& output, const std::size_t offset,
                const Digest& value) noexcept {
    std::copy(value.begin(), value.end(), output.begin()
              + static_cast<std::ptrdiff_t>(offset));
}

[[nodiscard]] Digest get_digest(const EncodedRecord& input,
                                const std::size_t offset) noexcept {
    Digest value{};
    std::copy_n(input.begin() + static_cast<std::ptrdiff_t>(offset), value.size(),
                value.begin());
    return value;
}

[[nodiscard]] Digest digest_domain_payload(const std::string_view domain,
                                           const std::span<const std::uint8_t> payload) {
    std::vector<std::uint8_t> bytes;
    bytes.reserve(domain.size() + 1U + payload.size());
    bytes.insert(bytes.end(), domain.begin(), domain.end());
    bytes.push_back(0U);
    bytes.insert(bytes.end(), payload.begin(), payload.end());
    return generation_journal::sha256(bytes);
}

[[nodiscard]] bool valid_kind(const Kind value) noexcept {
    const auto raw = static_cast<std::uint8_t>(value);
    return raw >= static_cast<std::uint8_t>(Kind::subject_envelope)
        && raw <= static_cast<std::uint8_t>(Kind::reopen_receipt);
}

[[nodiscard]] bool valid_decision(const Decision value) noexcept {
    return static_cast<std::uint8_t>(value)
        <= static_cast<std::uint8_t>(Decision::indeterminate);
}

[[nodiscard]] bool valid_terminal(const Terminal value) noexcept {
    return static_cast<std::uint8_t>(value)
        <= static_cast<std::uint8_t>(Terminal::fail_stop);
}

[[nodiscard]] bool valid_role(const Role value) noexcept {
    const auto raw = static_cast<std::uint8_t>(value);
    return raw >= static_cast<std::uint8_t>(Role::proposer)
        && raw <= static_cast<std::uint8_t>(Role::reopener);
}

[[nodiscard]] bool fields_zero(
    const std::initializer_list<const Digest*> fields) noexcept {
    return std::all_of(fields.begin(), fields.end(), [](const Digest* value) {
        return digest_zero(*value);
    });
}

[[nodiscard]] bool same_core(const RecordV1& lhs, const RecordV1& rhs) noexcept {
    return lhs.transaction_id == rhs.transaction_id
        && lhs.subject == rhs.subject
        && lhs.policy == rhs.policy
        && lhs.generation_from == rhs.generation_from
        && lhs.nonce == rhs.nonce;
}

[[nodiscard]] ValidationReport invalid(const ValidationCode code,
                                       const std::size_t count) noexcept {
    return ValidationReport{code, count, false, false, false, false, false,
                            Terminal::none};
}

[[nodiscard]] bool exact_role(const RecordV1& record, const std::size_t index) noexcept {
    return static_cast<std::uint8_t>(record.role)
        == static_cast<std::uint8_t>(index + 1U);
}

[[nodiscard]] bool terminal_generation_exact(const RecordV1& record) noexcept {
    if (record.generation_from == 0U
        || record.generation_from == std::numeric_limits<std::uint64_t>::max()) {
        return false;
    }
    switch (record.terminal) {
        case Terminal::effect:
            return record.generation_to == record.generation_from + 1U
                && record.flags == (permit_scoped | permit_spent);
        case Terminal::no_effect:
            return record.generation_to == record.generation_from
                && record.flags == (permit_scoped | permit_spent);
        case Terminal::uncertain:
            return record.generation_to == 0U
                && record.flags == (permit_scoped | permit_spent | query_only);
        case Terminal::fail_stop:
            return record.generation_to == record.generation_from
                && record.flags == (permit_scoped | permit_spent);
        case Terminal::none:
            return false;
    }
    return false;
}

}  // namespace

bool encode_record(const RecordV1& record, EncodedRecord& output) {
    if (!valid_kind(record.kind) || !valid_decision(record.decision)
        || !valid_terminal(record.terminal) || !valid_role(record.role)) {
        return false;
    }
    output.fill(0U);
    std::copy(kMagic.begin(), kMagic.end(), output.begin());
    put_u16(output, 8U, kVersion);
    output[10U] = static_cast<std::uint8_t>(record.kind);
    put_u32(output, 12U, static_cast<std::uint32_t>(kRecordBytes));
    put_u32(output, 16U, record.flags);
    put_digest(output, 32U, record.transaction_id);
    put_digest(output, 64U, record.predecessor);
    put_digest(output, 96U, record.subject);
    put_digest(output, 128U, record.policy);
    put_digest(output, 160U, record.evidence);
    put_digest(output, 192U, record.appraisal);
    put_digest(output, 224U, record.permit);
    put_digest(output, 256U, record.spend_receipt);
    put_digest(output, 288U, record.result);
    put_digest(output, 320U, record.currentness);
    put_digest(output, 352U, record.actor);
    put_u64(output, 384U, record.generation_from);
    put_u64(output, 392U, record.generation_to);
    put_u64(output, 400U, record.nonce);
    output[408U] = static_cast<std::uint8_t>(record.decision);
    output[409U] = static_cast<std::uint8_t>(record.terminal);
    output[410U] = static_cast<std::uint8_t>(record.role);
    const Digest integrity = digest_domain_payload(
        kIntegrityDomain, std::span<const std::uint8_t>(output.data(), 416U));
    put_digest(output, 416U, integrity);
    return true;
}

bool decode_record(const EncodedRecord& input, RecordV1& output) {
    if (!std::equal(kMagic.begin(), kMagic.end(), input.begin())
        || get_u16(input, 8U) != kVersion
        || get_u32(input, 12U) != kRecordBytes
        || input[11U] != 0U
        || std::any_of(input.begin() + 20, input.begin() + 32,
                       [](const std::uint8_t byte) { return byte != 0U; })
        || std::any_of(input.begin() + 411, input.begin() + 416,
                       [](const std::uint8_t byte) { return byte != 0U; })) {
        return false;
    }
    const Digest expected = digest_domain_payload(
        kIntegrityDomain, std::span<const std::uint8_t>(input.data(), 416U));
    if (get_digest(input, 416U) != expected) return false;

    RecordV1 decoded;
    decoded.kind = static_cast<Kind>(input[10U]);
    decoded.flags = get_u32(input, 16U);
    decoded.transaction_id = get_digest(input, 32U);
    decoded.predecessor = get_digest(input, 64U);
    decoded.subject = get_digest(input, 96U);
    decoded.policy = get_digest(input, 128U);
    decoded.evidence = get_digest(input, 160U);
    decoded.appraisal = get_digest(input, 192U);
    decoded.permit = get_digest(input, 224U);
    decoded.spend_receipt = get_digest(input, 256U);
    decoded.result = get_digest(input, 288U);
    decoded.currentness = get_digest(input, 320U);
    decoded.actor = get_digest(input, 352U);
    decoded.generation_from = get_u64(input, 384U);
    decoded.generation_to = get_u64(input, 392U);
    decoded.nonce = get_u64(input, 400U);
    decoded.decision = static_cast<Decision>(input[408U]);
    decoded.terminal = static_cast<Terminal>(input[409U]);
    decoded.role = static_cast<Role>(input[410U]);
    if (!valid_kind(decoded.kind) || !valid_decision(decoded.decision)
        || !valid_terminal(decoded.terminal) || !valid_role(decoded.role)) {
        return false;
    }
    output = decoded;
    return true;
}

Digest record_head(const EncodedRecord& record) {
    return digest_domain_payload(kHeadDomain, record);
}

Digest transaction_id_for(const Digest& subject, const Digest& policy,
                          const std::uint64_t generation_from,
                          const std::uint64_t nonce) {
    std::array<std::uint8_t, 80U> payload{};
    std::copy(subject.begin(), subject.end(), payload.begin());
    std::copy(policy.begin(), policy.end(), payload.begin() + 32);
    for (std::size_t index = 0U; index < 8U; ++index) {
        const unsigned int shift = static_cast<unsigned int>((7U - index) * 8U);
        payload[64U + index] = static_cast<std::uint8_t>(generation_from >> shift);
        payload[72U + index] = static_cast<std::uint8_t>(nonce >> shift);
    }
    return digest_domain_payload(kTransactionDomain, payload);
}

Digest labeled_digest(const std::string_view label) {
    const auto* data = reinterpret_cast<const std::uint8_t*>(label.data());
    return digest_domain_payload(kLabelDomain,
                                 std::span<const std::uint8_t>(data, label.size()));
}

ValidationReport validate_candidate(const std::span<const EncodedRecord> records) {
    const std::size_t count = records.size();
    if (count != 3U && count != 6U) return invalid(ValidationCode::invalid_count, count);

    std::vector<RecordV1> decoded(count);
    for (std::size_t index = 0U; index < count; ++index) {
        if (!decode_record(records[index], decoded[index])) {
            return invalid(ValidationCode::invalid_record, count);
        }
        if (static_cast<std::uint8_t>(decoded[index].kind)
                != static_cast<std::uint8_t>(index + 1U)
            || !exact_role(decoded[index], index)) {
            return invalid(ValidationCode::invalid_order, count);
        }
        if (index == 0U) {
            if (!digest_zero(decoded[index].predecessor)) {
                return invalid(ValidationCode::invalid_chain, count);
            }
        } else if (decoded[index].predecessor != record_head(records[index - 1U])) {
            return invalid(ValidationCode::invalid_chain, count);
        }
    }

    const RecordV1& first = decoded.front();
    if (digest_zero(first.transaction_id) || digest_zero(first.subject)
        || digest_zero(first.policy) || digest_zero(first.actor)
        || first.generation_from == 0U || first.nonce == 0U
        || first.generation_from == std::numeric_limits<std::uint64_t>::max()
        || first.generation_to != first.generation_from + 1U
        || first.transaction_id != transaction_id_for(first.subject, first.policy,
                                                       first.generation_from, first.nonce)) {
        return invalid(ValidationCode::invalid_binding, count);
    }
    for (const RecordV1& record : decoded) {
        if (!same_core(first, record) || digest_zero(record.actor)) {
            return invalid(ValidationCode::invalid_binding, count);
        }
    }
    for (std::size_t lhs = 0U; lhs < count; ++lhs) {
        for (std::size_t rhs = lhs + 1U; rhs < count; ++rhs) {
            if (decoded[lhs].actor == decoded[rhs].actor) {
                return invalid(ValidationCode::invalid_profile, count);
            }
        }
    }

    const RecordV1& r1 = decoded[0U];
    const RecordV1& r2 = decoded[1U];
    const RecordV1& r3 = decoded[2U];
    if (r1.flags != 0U || r1.decision != Decision::none
        || r1.terminal != Terminal::none
        || !fields_zero({&r1.evidence, &r1.appraisal, &r1.permit,
                             &r1.spend_receipt, &r1.result, &r1.currentness})) {
        return invalid(ValidationCode::invalid_profile, count);
    }
    if (r2.flags != 0U || r2.decision != Decision::none
        || r2.terminal != Terminal::none || digest_zero(r2.evidence)
        || !fields_zero({&r2.appraisal, &r2.permit, &r2.spend_receipt,
                             &r2.result, &r2.currentness})
        || r2.generation_to != r2.generation_from + 1U) {
        return invalid(ValidationCode::invalid_profile, count);
    }
    if (r3.flags != 0U || r3.terminal != Terminal::none
        || r3.evidence != r2.evidence || digest_zero(r3.appraisal)
        || !fields_zero({&r3.permit, &r3.spend_receipt,
                             &r3.result, &r3.currentness})
        || r3.generation_to != r3.generation_from + 1U
        || (r3.decision != Decision::pass && r3.decision != Decision::reject
            && r3.decision != Decision::indeterminate)) {
        return invalid(ValidationCode::invalid_profile, count);
    }

    if (count == 3U) {
        if (r3.decision == Decision::reject) {
            return ValidationReport{ValidationCode::reject_stop, count, true, false,
                                    false, false, false, Terminal::none};
        }
        if (r3.decision == Decision::indeterminate) {
            return ValidationReport{ValidationCode::indeterminate_stop, count, true,
                                    false, false, false, false, Terminal::none};
        }
        return invalid(ValidationCode::invalid_count, count);
    }
    if (r3.decision != Decision::pass) {
        return invalid(ValidationCode::invalid_profile, count);
    }

    const RecordV1& r4 = decoded[3U];
    const RecordV1& r5 = decoded[4U];
    const RecordV1& r6 = decoded[5U];
    if (r4.flags != permit_scoped || r4.decision != Decision::none
        || r4.terminal != Terminal::none || r4.evidence != r3.evidence
        || r4.appraisal != r3.appraisal || digest_zero(r4.permit)
        || !fields_zero({&r4.spend_receipt, &r4.result, &r4.currentness})
        || r4.generation_to != r4.generation_from + 1U) {
        return invalid(ValidationCode::invalid_profile, count);
    }
    if (r5.decision != Decision::none || r5.evidence != r4.evidence
        || r5.appraisal != r4.appraisal || r5.permit != r4.permit
        || digest_zero(r5.spend_receipt) || digest_zero(r5.result)
        || !digest_zero(r5.currentness) || !terminal_generation_exact(r5)) {
        return invalid(ValidationCode::invalid_profile, count);
    }
    const std::uint32_t expected_r6_flags = r5.flags | reopened;
    if (r6.flags != expected_r6_flags || r6.decision != Decision::none
        || r6.terminal != r5.terminal || r6.generation_to != r5.generation_to
        || r6.evidence != r5.evidence || r6.appraisal != r5.appraisal
        || r6.permit != r5.permit || r6.spend_receipt != r5.spend_receipt
        || r6.result != r5.result || digest_zero(r6.currentness)) {
        return invalid(ValidationCode::invalid_profile, count);
    }

    ValidationCode code = ValidationCode::invalid_profile;
    switch (r5.terminal) {
        case Terminal::effect: code = ValidationCode::effect; break;
        case Terminal::no_effect: code = ValidationCode::no_effect; break;
        case Terminal::uncertain: code = ValidationCode::uncertain; break;
        case Terminal::fail_stop: code = ValidationCode::fail_stop; break;
        case Terminal::none: return invalid(ValidationCode::invalid_profile, count);
    }
    return ValidationReport{code, count, true, true, true, false, false, r5.terminal};
}

std::string_view validation_code_name(const ValidationCode value) noexcept {
    switch (value) {
        case ValidationCode::effect: return "EFFECT";
        case ValidationCode::no_effect: return "NO_EFFECT";
        case ValidationCode::uncertain: return "UNCERTAIN";
        case ValidationCode::fail_stop: return "FAIL_STOP";
        case ValidationCode::reject_stop: return "REJECT_STOP";
        case ValidationCode::indeterminate_stop: return "INDETERMINATE_STOP";
        case ValidationCode::invalid_count: return "INVALID_COUNT";
        case ValidationCode::invalid_record: return "INVALID_RECORD";
        case ValidationCode::invalid_order: return "INVALID_ORDER";
        case ValidationCode::invalid_chain: return "INVALID_CHAIN";
        case ValidationCode::invalid_binding: return "INVALID_BINDING";
        case ValidationCode::invalid_profile: return "INVALID_PROFILE";
    }
    return "INVALID_RECORD";
}

std::string_view terminal_name(const Terminal value) noexcept {
    switch (value) {
        case Terminal::none: return "NONE";
        case Terminal::effect: return "EFFECT";
        case Terminal::no_effect: return "NO_EFFECT";
        case Terminal::uncertain: return "UNCERTAIN";
        case Terminal::fail_stop: return "FAIL_STOP";
    }
    return "NONE";
}

std::string_view decision_name(const Decision value) noexcept {
    switch (value) {
        case Decision::none: return "NONE";
        case Decision::pass: return "PASS";
        case Decision::reject: return "REJECT";
        case Decision::indeterminate: return "INDETERMINATE";
    }
    return "NONE";
}

}  // namespace slopos::e0::transaction_dossier
