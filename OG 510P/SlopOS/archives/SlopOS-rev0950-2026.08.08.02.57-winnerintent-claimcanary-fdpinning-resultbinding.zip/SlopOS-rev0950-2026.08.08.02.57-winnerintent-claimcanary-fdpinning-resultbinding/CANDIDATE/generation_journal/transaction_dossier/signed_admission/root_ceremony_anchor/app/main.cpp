#include "slopos/e0/signed_admission/root_ceremony_anchor.hpp"

#include <filesystem>
#include <iostream>

int main(int argc, char** argv) {
    const std::filesystem::path output = argc == 2 ? argv[1] : "root-ceremony-anchor-output";
    const bool ok = slopos::e0::signed_admission::root_ceremony_anchor::run_campaign(output);
    std::cout << "ROOT_CEREMONY_ANCHOR_CAMPAIGN=" << (ok ? "PASS" : "FAIL")
              << " output=" << output.string()
              << " authority=false\n";
    return ok ? 0 : 1;
}
