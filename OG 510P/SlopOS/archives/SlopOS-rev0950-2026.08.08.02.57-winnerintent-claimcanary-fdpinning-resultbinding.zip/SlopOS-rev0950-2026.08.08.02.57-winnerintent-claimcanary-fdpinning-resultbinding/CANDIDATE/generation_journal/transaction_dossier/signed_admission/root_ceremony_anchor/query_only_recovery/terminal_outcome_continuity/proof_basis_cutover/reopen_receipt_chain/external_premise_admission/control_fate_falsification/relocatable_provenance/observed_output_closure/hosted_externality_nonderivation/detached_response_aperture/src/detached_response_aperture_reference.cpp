#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/reopen_receipt_chain/external_premise_admission/control_fate_falsification/relocatable_provenance/observed_output_closure/hosted_externality_nonderivation/detached_response_aperture.hpp"

#include "slopos/e0/generation_journal/spend_record.hpp"

#include <openssl/evp.h>

#include <array>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <span>
#include <string_view>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification::relocatable_provenance::observed_output_closure::hosted_externality_nonderivation::detached_response_aperture {
namespace {

#ifndef SLOPOS_DRA_RESPONSE_SHAPE_POLICY_SHA256_HEX
#error "reference requires response-shape policy"
#endif
#ifndef SLOPOS_DRA_TRUST_CONFIGURATION_POLICY_SHA256_HEX
#error "reference requires trust-configuration policy"
#endif
#ifndef SLOPOS_DRA_CONSUMPTION_FENCE_POLICY_SHA256_HEX
#error "reference requires consumption-fence policy"
#endif
#ifndef SLOPOS_DRA_REOPENER_IMPLEMENTATION_SHA256_HEX
#error "reference requires reopener implementation"
#endif
#ifndef SLOPOS_DRA_LINKED_PARENT_ARCHIVE_SHA256_HEX
#error "reference requires linked parent archive digest"
#endif
#ifndef SLOPOS_DRA_LINKED_PARENT_ARCHIVE_BYTES
#error "reference requires linked parent archive bytes"
#endif
#ifndef SLOPOS_DRA_LINKED_PARENT_MANIFEST_ROWS
#error "reference requires linked parent manifest rows"
#endif

constexpr std::uint16_t required_deficit_mask = 0x003fU;

template <std::size_t Extent>
class ByteImage final {
public:
    ByteImage() noexcept { bytes_.fill(0U); }

    void text8(const std::string_view text) noexcept {
        for (std::size_t index = 0U; index < 8U; ++index) append(
            index < text.size() ? static_cast<std::uint8_t>(text[index]) : 0U);
    }
    void be16(const std::uint16_t value) noexcept {
        append(static_cast<std::uint8_t>((value >> 8U) & 0xffU));
        append(static_cast<std::uint8_t>(value & 0xffU));
    }
    void be32(const std::uint32_t value) noexcept {
        append(static_cast<std::uint8_t>((value >> 24U) & 0xffU));
        append(static_cast<std::uint8_t>((value >> 16U) & 0xffU));
        append(static_cast<std::uint8_t>((value >> 8U) & 0xffU));
        append(static_cast<std::uint8_t>(value & 0xffU));
    }
    void be64(const std::uint64_t value) noexcept {
        for (std::size_t index = 0U; index < 8U; ++index) {
            const auto shift = static_cast<unsigned>((7U - index) * 8U);
            append(static_cast<std::uint8_t>((value >> shift) & 0xffU));
        }
    }
    void one(const std::uint8_t value) noexcept { append(value); }
    template <std::size_t Count>
    void block(const std::array<std::uint8_t, Count>& input) noexcept {
        for (const auto byte : input) append(byte);
    }
    [[nodiscard]] std::array<std::uint8_t, Extent> finish() noexcept {
        while (position_ < Extent) append(0U);
        return bytes_;
    }
    [[nodiscard]] bool good() const noexcept { return good_; }

private:
    void append(const std::uint8_t value) noexcept {
        if (position_ >= Extent) {
            good_ = false;
            return;
        }
        bytes_[position_++] = value;
    }

    std::array<std::uint8_t, Extent> bytes_{};
    std::size_t position_{0U};
    bool good_{true};
};

[[nodiscard]] constexpr std::uint8_t nibble(const char value) noexcept {
    if (value >= '0' && value <= '9') return static_cast<std::uint8_t>(value - '0');
    if (value >= 'a' && value <= 'f') return static_cast<std::uint8_t>(value - 'a' + 10);
    return 0xffU;
}

[[nodiscard]] Digest digest_literal(const std::string_view text) noexcept {
    Digest result{};
    if (text.size() != 64U) return result;
    for (std::size_t index = 0U; index < result.size(); ++index) {
        const auto upper = nibble(text[index * 2U]);
        const auto lower = nibble(text[index * 2U + 1U]);
        if (upper > 15U || lower > 15U) return {};
        result[index] = static_cast<std::uint8_t>((upper << 4U) | lower);
    }
    return result;
}

template <typename ByteArray>
[[nodiscard]] Digest hash_image(const ByteArray& image) noexcept {
    return generation_journal::sha256(std::span<const std::uint8_t>(image.data(), image.size()));
}

template <std::size_t Count>
[[nodiscard]] bool has_any(const std::array<std::uint8_t, Count>& value) noexcept {
    std::uint8_t folded = 0U;
    for (const auto byte : value) folded = static_cast<std::uint8_t>(folded | byte);
    return folded != 0U;
}

[[nodiscard]] std::uint16_t response_bits(const LabResponseFixture& value) noexcept {
    std::uint16_t flags = 0U;
    if (value.present) flags |= 1U;
    if (value.canonical) flags |= 2U;
    if (value.laboratory_fixture) flags |= 4U;
    if (value.detached_from_request) flags |= 8U;
    if (value.external_occurrence_claimed) flags |= 16U;
    if (value.trust_anchor_embedded) flags |= 32U;
    return flags;
}

[[nodiscard]] std::uint16_t publication_bits(const ModeledPublicationReceipt& value) noexcept {
    std::uint16_t flags = 0U;
    if (value.present) flags |= 1U;
    if (value.canonical) flags |= 2U;
    if (value.durable) flags |= 4U;
    if (value.no_replace) flags |= 8U;
    if (value.model_only) flags |= 16U;
    if (value.external_occurrence_claimed) flags |= 32U;
    return flags;
}

[[nodiscard]] std::uint16_t reopen_bits(const ModeledReopenReceipt& value) noexcept {
    std::uint16_t flags = 0U;
    if (value.present) flags |= 1U;
    if (value.canonical) flags |= 2U;
    if (value.durable) flags |= 4U;
    if (value.exact_response_rehashed) flags |= 8U;
    if (value.separate_role_label) flags |= 16U;
    if (value.model_only) flags |= 32U;
    if (value.administrative_independence_claimed) flags |= 64U;
    return flags;
}

[[nodiscard]] std::uint16_t configuration_bits(const TrustConfiguration& value) noexcept {
    std::uint16_t flags = 0U;
    if (value.present) flags |= 1U;
    if (value.canonical) flags |= 2U;
    if (value.laboratory_configuration) flags |= 4U;
    if (value.embedded_in_response) flags |= 8U;
    if (value.external_provisioning_claimed) flags |= 16U;
    return flags;
}

[[nodiscard]] std::uint16_t appraisal_bits(const AppraisalWitness& value) noexcept {
    std::uint16_t flags = 0U;
    if (value.present) flags |= 1U;
    if (value.canonical) flags |= 2U;
    if (value.same_response_bytes) flags |= 4U;
    if (value.opposite_policy_appraisals) flags |= 8U;
    if (value.successor_currentness_rejected) flags |= 16U;
    if (value.model_only) flags |= 32U;
    if (value.no_external_trust_claim) flags |= 64U;
    return flags;
}

[[nodiscard]] std::uint16_t deficit_bits(const ConsumptionDeficit& value) noexcept {
    std::uint16_t flags = 0U;
    if (value.present) flags |= 1U;
    if (value.canonical) flags |= 2U;
    if (value.prior_appraisal_not_current) flags |= 4U;
    if (value.external_response_absent) flags |= 8U;
    if (value.external_trust_configuration_absent) flags |= 16U;
    if (value.owner_admission_absent) flags |= 32U;
    if (value.no_authority_claim) flags |= 64U;
    return flags;
}

[[nodiscard]] EncodedResponseSigning reference_signing_image(const LabResponseFixture& value) noexcept {
    ByteImage<encoded_response_signing_bytes> image;
    image.text8("DRARESP1");
    image.be32(value.schema_version);
    image.be16(response_bits(value));
    image.be16(value.accepted_claim_mask);
    image.be16(value.rejected_claim_mask);
    image.be16(value.unresolved_claim_mask);
    image.be64(value.linked_parent_archive_bytes);
    image.be64(value.linked_parent_manifest_rows);
    image.be64(value.owner_root_version);
    image.be64(value.issued_at);
    image.be64(value.not_before);
    image.be64(value.expires_at);
    image.block(value.request_digest);
    image.block(value.linked_parent_archive_digest);
    image.block(value.parent_closure_claim_digest);
    image.block(value.claim_catalogue_digest);
    image.block(value.requested_response_profile_digest);
    image.block(value.owner_constitution_digest);
    image.block(value.owner_root_digest);
    image.block(value.appraisal_policy_digest);
    image.block(value.target_digest);
    image.block(value.response_namespace_digest);
    image.block(value.signer_public_key);
    return image.finish();
}

[[nodiscard]] EncodedLabResponse reference_response_image(const LabResponseFixture& value) noexcept {
    EncodedLabResponse image{};
    const auto signing = reference_signing_image(value);
    for (std::size_t index = 0U; index < signing.size(); ++index) image[index] = signing[index];
    for (std::size_t index = 0U; index < value.signature.size(); ++index) {
        image[encoded_response_signing_bytes + index] = value.signature[index];
    }
    return image;
}

[[nodiscard]] EncodedPublicationReceipt reference_publication_image(
    const ModeledPublicationReceipt& value) noexcept {
    ByteImage<encoded_publication_receipt_bytes> image;
    image.text8("DRAPUB01");
    image.be32(value.schema_version);
    image.be16(publication_bits(value));
    image.be64(value.sequence);
    image.be64(value.carrier_bytes);
    image.block(value.response_digest);
    image.block(value.request_digest);
    image.block(value.linked_parent_archive_digest);
    image.block(value.publication_namespace_digest);
    image.block(value.publisher_role_digest);
    image.block(value.carrier_digest);
    image.block(value.publication_policy_digest);
    return image.finish();
}

[[nodiscard]] EncodedReopenReceipt reference_reopen_image(const ModeledReopenReceipt& value) noexcept {
    ByteImage<encoded_reopen_receipt_bytes> image;
    image.text8("DRAREOP1");
    image.be32(value.schema_version);
    image.be16(reopen_bits(value));
    image.be64(value.carrier_bytes);
    image.block(value.publication_receipt_digest);
    image.block(value.response_digest);
    image.block(value.request_digest);
    image.block(value.reopener_role_digest);
    image.block(value.reopener_implementation_digest);
    image.block(value.carrier_digest);
    image.block(value.reopen_policy_digest);
    return image.finish();
}

[[nodiscard]] EncodedTrustConfiguration reference_configuration_image(
    const TrustConfiguration& value) noexcept {
    ByteImage<encoded_trust_configuration_bytes> image;
    image.text8("DRACFG01");
    image.be32(value.schema_version);
    image.be16(configuration_bits(value));
    image.be16(value.required_accept_mask);
    image.be16(value.forbidden_reject_mask);
    image.be64(value.current_root_version);
    image.be64(value.evaluation_time);
    image.block(value.owner_constitution_digest);
    image.block(value.current_owner_root_digest);
    image.block(value.appraisal_policy_digest);
    image.block(value.target_digest);
    image.block(value.response_namespace_digest);
    image.block(value.configuration_role_digest);
    image.block(value.trusted_signer_public_key);
    return image.finish();
}

[[nodiscard]] EncodedAppraisalWitness reference_appraisal_image(
    const AppraisalWitness& value) noexcept {
    ByteImage<encoded_appraisal_witness_bytes> image;
    image.text8("DRAAPP01");
    image.be32(value.schema_version);
    image.be16(appraisal_bits(value));
    image.one(static_cast<std::uint8_t>(value.accepting_result));
    image.one(static_cast<std::uint8_t>(value.policy_reject_result));
    image.one(static_cast<std::uint8_t>(value.successor_result));
    image.be64(value.appraisal_root_version);
    image.be64(value.successor_root_version);
    image.block(value.response_digest);
    image.block(value.publication_receipt_digest);
    image.block(value.reopen_receipt_digest);
    image.block(value.accepting_configuration_digest);
    image.block(value.policy_reject_configuration_digest);
    image.block(value.successor_configuration_digest);
    image.block(value.request_digest);
    image.block(value.appraisal_policy_digest);
    return image.finish();
}

[[nodiscard]] EncodedConsumptionDeficit reference_deficit_image(
    const ConsumptionDeficit& value) noexcept {
    ByteImage<encoded_consumption_deficit_bytes> image;
    image.text8("DRADEF01");
    image.be32(value.schema_version);
    image.be16(deficit_bits(value));
    image.be16(value.missing_premise_mask);
    image.be64(value.appraisal_root_version);
    image.be64(value.consumption_root_version);
    image.be64(value.appraisal_time);
    image.be64(value.consumption_time);
    image.block(value.response_digest);
    image.block(value.appraisal_witness_digest);
    image.block(value.accepting_configuration_digest);
    image.block(value.successor_configuration_digest);
    image.block(value.request_digest);
    image.block(value.appraised_owner_root_digest);
    image.block(value.consumption_owner_root_digest);
    image.block(value.consumption_policy_digest);
    return image.finish();
}

[[nodiscard]] bool partition_complete(const LabResponseFixture& response) noexcept {
    const auto duplicated = static_cast<std::uint16_t>(
        (response.accepted_claim_mask & response.rejected_claim_mask)
        | (response.accepted_claim_mask & response.unresolved_claim_mask)
        | (response.rejected_claim_mask & response.unresolved_claim_mask));
    const auto total = static_cast<std::uint16_t>(
        response.accepted_claim_mask | response.rejected_claim_mask | response.unresolved_claim_mask);
    return duplicated == 0U && total == all_external_claims_mask;
}

[[nodiscard]] bool response_well_formed(const LabResponseFixture& value) noexcept {
    return value.present && value.canonical && value.laboratory_fixture
        && value.detached_from_request && !value.external_occurrence_claimed
        && value.schema_version == aperture_schema_version
        && value.linked_parent_archive_bytes == SLOPOS_DRA_LINKED_PARENT_ARCHIVE_BYTES
        && value.linked_parent_manifest_rows == SLOPOS_DRA_LINKED_PARENT_MANIFEST_ROWS
        && value.owner_root_version != 0U && value.not_before <= value.issued_at
        && value.issued_at < value.expires_at && has_any(value.request_digest)
        && has_any(value.linked_parent_archive_digest) && has_any(value.parent_closure_claim_digest)
        && has_any(value.claim_catalogue_digest) && has_any(value.requested_response_profile_digest)
        && has_any(value.owner_constitution_digest) && has_any(value.owner_root_digest)
        && has_any(value.appraisal_policy_digest) && has_any(value.target_digest)
        && has_any(value.response_namespace_digest) && has_any(value.signer_public_key)
        && has_any(value.signature);
}

[[nodiscard]] bool publication_well_formed(const ModeledPublicationReceipt& value) noexcept {
    return value.present && value.canonical && value.durable && value.no_replace
        && value.model_only && !value.external_occurrence_claimed
        && value.schema_version == aperture_schema_version && value.sequence != 0U
        && value.carrier_bytes == encoded_lab_response_bytes
        && has_any(value.publication_namespace_digest) && has_any(value.publisher_role_digest);
}

[[nodiscard]] bool reopen_well_formed(const ModeledReopenReceipt& value) noexcept {
    return value.present && value.canonical && value.durable && value.exact_response_rehashed
        && value.separate_role_label && value.model_only
        && !value.administrative_independence_claimed
        && value.schema_version == aperture_schema_version
        && value.carrier_bytes == encoded_lab_response_bytes && has_any(value.reopener_role_digest);
}

[[nodiscard]] bool configuration_well_formed(const TrustConfiguration& value) noexcept {
    const auto outside = static_cast<std::uint16_t>(~all_external_claims_mask);
    return value.present && value.canonical && value.laboratory_configuration
        && !value.external_provisioning_claimed && value.schema_version == aperture_schema_version
        && value.current_root_version != 0U && value.evaluation_time != 0U
        && value.required_accept_mask != 0U
        && (value.required_accept_mask & outside) == 0U
        && (value.forbidden_reject_mask & outside) == 0U
        && has_any(value.owner_constitution_digest) && has_any(value.current_owner_root_digest)
        && has_any(value.appraisal_policy_digest) && has_any(value.target_digest)
        && has_any(value.response_namespace_digest) && has_any(value.configuration_role_digest)
        && has_any(value.trusted_signer_public_key);
}

[[nodiscard]] bool appraisal_well_formed(const AppraisalWitness& value) noexcept {
    return value.present && value.canonical && value.same_response_bytes
        && value.opposite_policy_appraisals && value.successor_currentness_rejected
        && value.model_only && value.no_external_trust_claim
        && value.schema_version == aperture_schema_version && value.appraisal_root_version != 0U
        && value.successor_root_version == value.appraisal_root_version + 1U;
}

[[nodiscard]] bool deficit_well_formed(const ConsumptionDeficit& value) noexcept {
    return value.present && value.canonical && value.prior_appraisal_not_current
        && value.external_response_absent && value.external_trust_configuration_absent
        && value.owner_admission_absent && value.no_authority_claim
        && value.schema_version == aperture_schema_version
        && value.missing_premise_mask == required_deficit_mask
        && value.appraisal_root_version != 0U
        && value.consumption_root_version == value.appraisal_root_version + 1U
        && value.consumption_time >= value.appraisal_time;
}

[[nodiscard]] bool signature_checks(const LabResponseFixture& response) noexcept {
    const auto message = reference_signing_image(response);
    using Key = std::unique_ptr<EVP_PKEY, decltype(&EVP_PKEY_free)>;
    using Context = std::unique_ptr<EVP_MD_CTX, decltype(&EVP_MD_CTX_free)>;
    Key key(EVP_PKEY_new_raw_public_key(
        EVP_PKEY_ED25519, nullptr, response.signer_public_key.data(), response.signer_public_key.size()),
        &EVP_PKEY_free);
    if (!key) return false;
    Context context(EVP_MD_CTX_new(), &EVP_MD_CTX_free);
    if (!context) return false;
    if (EVP_DigestVerifyInit(context.get(), nullptr, nullptr, nullptr, key.get()) != 1) return false;
    return EVP_DigestVerify(context.get(), response.signature.data(), response.signature.size(),
        message.data(), message.size()) == 1;
}

[[nodiscard]] AppraisalResult appraise_reference(
    const LabResponseFixture& response, const TrustConfiguration& configuration) noexcept {
    if (!response_well_formed(response) || !partition_complete(response)
        || hash_image(reference_response_image(response)) != response.response_digest
        || !signature_checks(response)) {
        return AppraisalResult::malformed_response;
    }
    if (!configuration_well_formed(configuration)
        || hash_image(reference_configuration_image(configuration)) != configuration.configuration_digest) {
        return AppraisalResult::malformed_configuration;
    }
    if (configuration.trusted_signer_public_key != response.signer_public_key) {
        return AppraisalResult::signer_untrusted;
    }
    if (configuration.owner_constitution_digest != response.owner_constitution_digest) {
        return AppraisalResult::constitution_mismatch;
    }
    if (configuration.current_owner_root_digest != response.owner_root_digest) {
        return AppraisalResult::owner_root_mismatch;
    }
    if (configuration.current_root_version != response.owner_root_version) {
        return AppraisalResult::root_version_mismatch;
    }
    if (configuration.appraisal_policy_digest != response.appraisal_policy_digest
        || configuration.response_namespace_digest != response.response_namespace_digest) {
        return AppraisalResult::policy_mismatch;
    }
    if (configuration.target_digest != response.target_digest) return AppraisalResult::target_mismatch;
    if (configuration.evaluation_time < response.not_before
        || configuration.evaluation_time < response.issued_at
        || configuration.evaluation_time >= response.expires_at) {
        return AppraisalResult::response_not_current;
    }
    if ((response.accepted_claim_mask & configuration.required_accept_mask)
        != configuration.required_accept_mask) {
        return AppraisalResult::required_claim_unresolved;
    }
    if ((response.rejected_claim_mask & configuration.forbidden_reject_mask) != 0U) {
        return AppraisalResult::rejected_claim_forbidden;
    }
    return AppraisalResult::accepted;
}

[[nodiscard]] bool exact_cut_sequence(const ApertureTrace& trace) noexcept {
    for (std::size_t stage = 0U; stage < aperture_cut_count; ++stage) {
        ApertureCut expected{};
        expected.parent_request_digest = trace.parent.request.request_digest;
        if (stage >= 1U && trace.response.present) expected.response_digest = trace.response.response_digest;
        if (stage >= 2U && trace.publication.present) {
            expected.publication_receipt_digest = trace.publication.receipt_digest;
        }
        if (stage >= 3U && trace.reopen.present) expected.reopen_receipt_digest = trace.reopen.receipt_digest;
        if (stage >= 4U && trace.accepting_configuration.present
            && trace.policy_reject_configuration.present && trace.successor_configuration.present) {
            expected.accepting_configuration_digest = trace.accepting_configuration.configuration_digest;
            expected.policy_reject_configuration_digest = trace.policy_reject_configuration.configuration_digest;
            expected.successor_configuration_digest = trace.successor_configuration.configuration_digest;
        }
        if (stage >= 5U && trace.appraisal.present) expected.appraisal_witness_digest = trace.appraisal.witness_digest;
        if (stage >= 6U && trace.deficit.present) expected.consumption_deficit_digest = trace.deficit.deficit_digest;
        if (trace.cuts[stage] != expected) return false;
    }
    return true;
}

[[nodiscard]] ApertureReport concluded(
    ApertureReport report, const ApertureCode code, const bool accepted) noexcept {
    report.code = code;
    report.accepted = accepted;
    return report;
}

}  // namespace

ApertureReport evaluate_reference(const ApertureTrace& trace) noexcept {
    ApertureReport report{};
    const auto parent = hosted_externality_nonderivation::evaluate_reference(trace.parent);
    report.parent_accepted = parent.accepted;
    report.parent_handoff_ready = parent.owner_handoff_ready;
    if (!parent.accepted) return concluded(report, ApertureCode::parent_rejected, false);
    if (!parent.owner_handoff_ready) return concluded(report, ApertureCode::parent_not_handoff_ready, false);

    report.cuts_ordered = exact_cut_sequence(trace);
    if (!report.cuts_ordered) return concluded(report, ApertureCode::cut_order_invalid, false);
    if (trace.promote_fixture_to_external_response) {
        return concluded(report, ApertureCode::hosted_response_promotion_forbidden, false);
    }
    if (trace.promote_appraisal_to_owner_admission) {
        return concluded(report, ApertureCode::hosted_admission_promotion_forbidden, false);
    }
    if (trace.grant_authority) return concluded(report, ApertureCode::authority_promotion_forbidden, false);

    if (!trace.response.present) {
        const bool child_exists = trace.publication.present || trace.reopen.present
            || trace.accepting_configuration.present || trace.policy_reject_configuration.present
            || trace.successor_configuration.present || trace.appraisal.present || trace.deficit.present;
        return concluded(report,
            child_exists ? ApertureCode::response_without_parent : ApertureCode::accepted_parent_handoff_ready,
            !child_exists);
    }
    if (!response_well_formed(trace.response)) {
        return concluded(report, ApertureCode::response_shape_invalid, false);
    }
    if (!partition_complete(trace.response)) {
        return concluded(report, ApertureCode::response_claim_partition_invalid, false);
    }
    if (trace.response.trust_anchor_embedded) {
        return concluded(report, ApertureCode::response_self_nominated_trust, false);
    }
    const auto parent_archive = digest_literal(SLOPOS_DRA_LINKED_PARENT_ARCHIVE_SHA256_HEX);
    if (trace.response.request_digest != trace.parent.request.request_digest
        || trace.response.linked_parent_archive_digest != parent_archive
        || trace.response.parent_closure_claim_digest != trace.parent.parent.claim.claim_digest
        || trace.response.claim_catalogue_digest != trace.parent.request.claim_catalogue_digest
        || trace.response.requested_response_profile_digest
            != trace.parent.request.requested_response_profile_digest
        || trace.response.response_namespace_digest != trace.parent.request.response_namespace_digest) {
        return concluded(report, ApertureCode::response_binding_mismatch, false);
    }
    if (hash_image(reference_response_image(trace.response)) != trace.response.response_digest) {
        return concluded(report, ApertureCode::response_digest_mismatch, false);
    }
    report.response_signature_valid = signature_checks(trace.response);
    if (!report.response_signature_valid) {
        return concluded(report, ApertureCode::response_signature_invalid, false);
    }
    report.response_valid = true;

    if (!trace.publication.present) {
        const bool later_exists = trace.reopen.present || trace.accepting_configuration.present
            || trace.policy_reject_configuration.present || trace.successor_configuration.present
            || trace.appraisal.present || trace.deficit.present;
        return concluded(report,
            later_exists ? ApertureCode::publication_without_response : ApertureCode::accepted_lab_response_durable,
            !later_exists);
    }
    if (!publication_well_formed(trace.publication)) {
        return concluded(report, ApertureCode::publication_shape_invalid, false);
    }
    if (trace.publication.response_digest != trace.response.response_digest
        || trace.publication.request_digest != trace.parent.request.request_digest
        || trace.publication.linked_parent_archive_digest != parent_archive
        || trace.publication.carrier_digest != trace.response.response_digest
        || trace.publication.publication_policy_digest
            != digest_literal(SLOPOS_DRA_RESPONSE_SHAPE_POLICY_SHA256_HEX)) {
        return concluded(report, ApertureCode::publication_binding_mismatch, false);
    }
    if (hash_image(reference_publication_image(trace.publication)) != trace.publication.receipt_digest) {
        return concluded(report, ApertureCode::publication_digest_mismatch, false);
    }
    report.publication_valid = true;

    if (!trace.reopen.present) {
        const bool later_exists = trace.accepting_configuration.present
            || trace.policy_reject_configuration.present || trace.successor_configuration.present
            || trace.appraisal.present || trace.deficit.present;
        return concluded(report,
            later_exists ? ApertureCode::reopen_without_publication
                         : ApertureCode::accepted_modeled_publication_durable,
            !later_exists);
    }
    if (!reopen_well_formed(trace.reopen)) {
        return concluded(report, ApertureCode::reopen_shape_invalid, false);
    }
    if (trace.reopen.publication_receipt_digest != trace.publication.receipt_digest
        || trace.reopen.response_digest != trace.response.response_digest
        || trace.reopen.request_digest != trace.parent.request.request_digest
        || trace.reopen.reopener_implementation_digest
            != digest_literal(SLOPOS_DRA_REOPENER_IMPLEMENTATION_SHA256_HEX)
        || trace.reopen.carrier_digest != trace.response.response_digest
        || trace.reopen.reopen_policy_digest
            != digest_literal(SLOPOS_DRA_RESPONSE_SHAPE_POLICY_SHA256_HEX)) {
        return concluded(report, ApertureCode::reopen_binding_mismatch, false);
    }
    if (hash_image(reference_reopen_image(trace.reopen)) != trace.reopen.receipt_digest) {
        return concluded(report, ApertureCode::reopen_digest_mismatch, false);
    }
    report.reopen_valid = true;

    const auto configuration_count = static_cast<unsigned>(trace.accepting_configuration.present)
        + static_cast<unsigned>(trace.policy_reject_configuration.present)
        + static_cast<unsigned>(trace.successor_configuration.present);
    if (configuration_count == 0U) {
        const bool later_exists = trace.appraisal.present || trace.deficit.present;
        return concluded(report,
            later_exists ? ApertureCode::configurations_without_reopen
                         : ApertureCode::accepted_modeled_reopen_durable,
            !later_exists);
    }
    if (configuration_count != 3U) {
        return concluded(report, ApertureCode::configuration_shape_invalid, false);
    }
    const std::array<const TrustConfiguration*, 3U> configurations{{
        &trace.accepting_configuration,
        &trace.policy_reject_configuration,
        &trace.successor_configuration,
    }};
    for (const auto* configuration : configurations) {
        if (!configuration_well_formed(*configuration)) {
            return concluded(report, ApertureCode::configuration_shape_invalid, false);
        }
        if (configuration->embedded_in_response) {
            return concluded(report, ApertureCode::configuration_embedded_in_response, false);
        }
        if (hash_image(reference_configuration_image(*configuration))
            != configuration->configuration_digest) {
            return concluded(report, ApertureCode::configuration_digest_mismatch, false);
        }
    }
    if (trace.accepting_configuration.configuration_digest
            == trace.policy_reject_configuration.configuration_digest
        || trace.accepting_configuration.configuration_digest
            == trace.successor_configuration.configuration_digest
        || trace.policy_reject_configuration.configuration_digest
            == trace.successor_configuration.configuration_digest) {
        return concluded(report, ApertureCode::configuration_digest_mismatch, false);
    }

    const auto accept_result = appraise_reference(trace.response, trace.accepting_configuration);
    const auto policy_result = appraise_reference(trace.response, trace.policy_reject_configuration);
    const auto successor_result = appraise_reference(trace.response, trace.successor_configuration);
    report.accepting_configuration_accepts = accept_result == AppraisalResult::accepted;
    if (!report.accepting_configuration_accepts) {
        return concluded(report, ApertureCode::accepting_configuration_did_not_accept, false);
    }
    report.policy_reject_configuration_rejects = policy_result == AppraisalResult::required_claim_unresolved;
    if (!report.policy_reject_configuration_rejects) {
        return concluded(report, ApertureCode::policy_reject_configuration_did_not_reject, false);
    }
    report.successor_configuration_rejects_currentness =
        successor_result == AppraisalResult::owner_root_mismatch
        || successor_result == AppraisalResult::root_version_mismatch
        || successor_result == AppraisalResult::response_not_current;
    if (!report.successor_configuration_rejects_currentness) {
        return concluded(report, ApertureCode::successor_configuration_did_not_reject_currentness, false);
    }
    report.configurations_valid = true;

    if (!trace.appraisal.present) {
        const bool deficit_without_appraisal = trace.deficit.present;
        return concluded(report,
            deficit_without_appraisal ? ApertureCode::consumption_deficit_without_appraisal
                                      : ApertureCode::accepted_trust_configurations_durable,
            !deficit_without_appraisal);
    }
    if (!appraisal_well_formed(trace.appraisal)) {
        return concluded(report, ApertureCode::appraisal_shape_invalid, false);
    }
    if (trace.appraisal.response_digest != trace.response.response_digest
        || trace.appraisal.publication_receipt_digest != trace.publication.receipt_digest
        || trace.appraisal.reopen_receipt_digest != trace.reopen.receipt_digest
        || trace.appraisal.accepting_configuration_digest
            != trace.accepting_configuration.configuration_digest
        || trace.appraisal.policy_reject_configuration_digest
            != trace.policy_reject_configuration.configuration_digest
        || trace.appraisal.successor_configuration_digest
            != trace.successor_configuration.configuration_digest
        || trace.appraisal.request_digest != trace.parent.request.request_digest
        || trace.appraisal.appraisal_policy_digest
            != digest_literal(SLOPOS_DRA_TRUST_CONFIGURATION_POLICY_SHA256_HEX)
        || trace.appraisal.accepting_result != accept_result
        || trace.appraisal.policy_reject_result != policy_result
        || trace.appraisal.successor_result != successor_result
        || trace.appraisal.appraisal_root_version != trace.accepting_configuration.current_root_version
        || trace.appraisal.successor_root_version != trace.successor_configuration.current_root_version) {
        return concluded(report, ApertureCode::appraisal_binding_mismatch, false);
    }
    if (hash_image(reference_appraisal_image(trace.appraisal)) != trace.appraisal.witness_digest) {
        return concluded(report, ApertureCode::appraisal_digest_mismatch, false);
    }
    report.appraisal_witness_valid = true;
    report.same_response_opposite_appraisals = true;

    if (!trace.deficit.present) {
        return concluded(report, ApertureCode::accepted_appraisal_witness_durable, true);
    }
    if (!deficit_well_formed(trace.deficit)) {
        return concluded(report, ApertureCode::consumption_deficit_shape_invalid, false);
    }
    if (trace.deficit.response_digest != trace.response.response_digest
        || trace.deficit.appraisal_witness_digest != trace.appraisal.witness_digest
        || trace.deficit.accepting_configuration_digest
            != trace.accepting_configuration.configuration_digest
        || trace.deficit.successor_configuration_digest
            != trace.successor_configuration.configuration_digest
        || trace.deficit.request_digest != trace.parent.request.request_digest
        || trace.deficit.appraised_owner_root_digest
            != trace.accepting_configuration.current_owner_root_digest
        || trace.deficit.consumption_owner_root_digest
            != trace.successor_configuration.current_owner_root_digest
        || trace.deficit.consumption_policy_digest
            != digest_literal(SLOPOS_DRA_CONSUMPTION_FENCE_POLICY_SHA256_HEX)
        || trace.deficit.appraisal_root_version != trace.accepting_configuration.current_root_version
        || trace.deficit.consumption_root_version != trace.successor_configuration.current_root_version
        || trace.deficit.appraisal_time != trace.accepting_configuration.evaluation_time
        || trace.deficit.consumption_time != trace.successor_configuration.evaluation_time) {
        return concluded(report, ApertureCode::consumption_deficit_binding_mismatch, false);
    }
    if (hash_image(reference_deficit_image(trace.deficit)) != trace.deficit.deficit_digest) {
        return concluded(report, ApertureCode::consumption_deficit_digest_mismatch, false);
    }
    report.consumption_deficit_valid = true;
    report.prior_appraisal_current_at_consumption = false;
    return concluded(report, ApertureCode::accepted_consumption_deficit_durable, true);
}

}  // namespace ...::detached_response_aperture
