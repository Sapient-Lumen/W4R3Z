#!/usr/bin/env python3
from __future__ import annotations

import csv
import hashlib
import re
import sys
from pathlib import Path

CANONICAL = {
    "BUILD-CLAIM.bin", "BUILD-PLAN.bin", "CASES.tsv", "COUNTERMODELS.tsv",
    "CUTS.tsv", "IDENTITIES.tsv", "LAWS.tsv", "PROVENANCE-CAPSULE.bin",
    "FIRST-REOPEN-RECEIPT.bin", "RELOCATED-REOPEN-RECEIPT.bin",
    "RELOCATION-MATRIX.tsv", "REPORT.txt", "SOURCE-CLOSURE.bin",
    "SOURCE-ENTRIES.tsv", "SUMMARY.tsv",
}
ZERO = "0" * 64
HEX64 = re.compile(r"[0-9a-f]{64}\Z")
OBJECTS = {
    "source_closure": ("SOURCE-CLOSURE.bin", 904, "SlopOS/RPC/source-closure/v1"),
    "build_plan": ("BUILD-PLAN.bin", 292, "SlopOS/RPC/build-plan/v1"),
    "provenance_capsule": ("PROVENANCE-CAPSULE.bin", 264, "SlopOS/RPC/provenance-capsule/v1"),
    "build_claim": ("BUILD-CLAIM.bin", 200, "SlopOS/RPC/build-claim/v1"),
    "first_reopen_receipt": ("FIRST-REOPEN-RECEIPT.bin", 260, "SlopOS/RPC/reopen-receipt/v1"),
    "relocated_reopen_receipt": ("RELOCATED-REOPEN-RECEIPT.bin", 260, "SlopOS/RPC/reopen-receipt/v1"),
}


def fail(detail: str) -> None:
    raise SystemExit(f"RELOCATABLE_PROVENANCE_PY=FAIL detail={detail}")


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def one_column(path: Path) -> dict[str, str]:
    return {row["metric"]: row["value"] for row in rows(path)}


def digest_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def label_digest(text: str) -> bytes:
    return hashlib.sha256(text.encode("utf-8")).digest()


def padded_domain(text: str) -> bytes:
    raw = text.encode("ascii")
    if len(raw) > 32:
        fail(f"domain length={text}")
    return raw + b"\0" * (32 - len(raw))


def valid_portable_path(path: str) -> bool:
    if not path or path.startswith("/") or path.endswith("/") or "\\" in path or ":" in path:
        return False
    if any(not (c.islower() or c.isdigit() or c in "._-/") for c in path):
        return False
    return all(segment not in {"", ".", ".."} for segment in path.split("/"))


def main() -> int:
    if len(sys.argv) != 2:
        fail("usage: OUTPUT_DIRECTORY")
    root = Path(sys.argv[1]).resolve()
    if not root.is_dir() or {path.name for path in root.iterdir()} != CANONICAL:
        fail("canonical file set")

    summary = one_column(root / "SUMMARY.tsv")
    expected = {
        "cases": "66",
        "accepted_classifications": "9",
        "rejected_classifications": "57",
        "safe_refusals_or_nonwitnesses": "8",
        "relocation_witnesses": "1",
        "candidate_reference_disagreements": "0",
        "expectation_failures": "0",
        "relocation_matrix_rows": "24",
        "relocation_matrix_failures": "0",
        "durable_cuts": "7",
        "source_entries": "6",
        "canonical_object_bytes": "2180",
        "laws": "17",
        "countermodels": "19",
        "authority_granted": "false",
        "epoch_exit_proved": "false",
        "parent_live_record_retained": "true",
        "source_manifest_bound_into_subject": "true",
        "build_plan_bound_into_subject": "true",
        "output_contract_bound_into_subject": "true",
        "reference_canonical_encoder_independent": "true",
        "first_receipt_precedes_relocated_claim": "true",
    }
    if summary != expected:
        fail(f"summary={summary!r}")

    cases = rows(root / "CASES.tsv")
    if len(cases) != 66 or len({row["case"] for row in cases}) != 66:
        fail("case cardinality")
    if any(
        row["expected"] != row["candidate"]
        or row["candidate"] != row["reference"]
        or row["agree"] != "true"
        for row in cases
    ):
        fail("candidate reference differential")
    if sum(row["accepted"] == "true" for row in cases) != 9:
        fail("accepted projection")
    if sum(row["relocation_witness"] == "true" for row in cases) != 1:
        fail("relocation projection")
    if any(row["authority"] != "false" or row["epoch_exit"] != "false" for row in cases):
        fail("mandatory nonclaim")
    if any(row["live_record_retained"] != "true" for row in cases):
        fail("live record retention")
    required = {
        "relocated_exact_subject", "same_locator_is_not_relocation_witness",
        "source_closure_open", "build_behavior_inputs_open",
        "locator_influenced_both_outputs", "output_diverged_under_relocation",
        "parent_rejected", "duplicate_source_path", "source_path_order_wrong",
        "ambient_locator_poison_0", "ambient_locator_poison_1",
        "first_receipt_binding_wrong", "relocated_receipt_identity_wrong",
        "cut_order_wrong_6",
    }
    if not required <= {row["case"] for row in cases}:
        fail("required cases")

    matrix = rows(root / "RELOCATION-MATRIX.tsv")
    if len(matrix) != 24 or [int(row["row"]) for row in matrix] != list(range(24)):
        fail("matrix cardinality")
    if any(row["claim_invariant"] != "true" or row["relocation_witness"] != "true" for row in matrix):
        fail("matrix result")
    if any(row["first_locator"] == row["relocated_locator"] for row in matrix):
        fail("matrix locator distinction")
    if any(row["first_claim"] != row["relocated_claim"] for row in matrix):
        fail("matrix claim identity")

    source_entries = rows(root / "SOURCE-ENTRIES.tsv")
    if len(source_entries) != 6:
        fail("source entry cardinality")
    paths = [row["path"] for row in source_entries]
    if paths != sorted(paths) or len(paths) != len(set(paths)) or not all(valid_portable_path(path) for path in paths):
        fail("portable source path closure")
    if any(int(row["bytes"]) <= 0 or row["mode"] not in {"444", "555"} for row in source_entries):
        fail("source entry metadata")
    if any(HEX64.fullmatch(row["content_sha256"]) is None for row in source_entries):
        fail("source entry digest")

    identities = {row["object"]: row for row in rows(root / "IDENTITIES.tsv")}
    if set(identities) != set(OBJECTS):
        fail("identity objects")
    object_digests: dict[str, str] = {}
    total = 0
    for object_name, (filename, size, domain) in OBJECTS.items():
        path = root / filename
        data = path.read_bytes()
        row = identities[object_name]
        if len(data) != size or int(row["bytes"]) != size:
            fail(f"object size={object_name}")
        if data[:32] != padded_domain(domain):
            fail(f"object domain={object_name}")
        if data[-32:] != hashlib.sha256(data[:-32]).digest():
            fail(f"object integrity={object_name}")
        identity = digest_bytes(data)
        if row["identity_sha256"] != identity or HEX64.fullmatch(identity) is None:
            fail(f"object identity={object_name}")
        object_digests[object_name] = identity
        total += size
    if total != 2180:
        fail("canonical aggregate")

    source = (root / "SOURCE-CLOSURE.bin").read_bytes()
    plan = (root / "BUILD-PLAN.bin").read_bytes()
    capsule = (root / "PROVENANCE-CAPSULE.bin").read_bytes()
    claim = (root / "BUILD-CLAIM.bin").read_bytes()
    first_receipt = (root / "FIRST-REOPEN-RECEIPT.bin").read_bytes()
    relocated_receipt = (root / "RELOCATED-REOPEN-RECEIPT.bin").read_bytes()
    logical_root = source[32:64]
    parent_challenge = source[64:96]
    if capsule[32:64] != parent_challenge or capsule[64:96] != logical_root:
        fail("capsule parent logical-root binding")
    if capsule[96:128].hex() != object_digests["source_closure"]:
        fail("capsule source closure binding")
    if capsule[128:160].hex() != object_digests["build_plan"]:
        fail("capsule build plan binding")
    if claim[32:64].hex() != object_digests["provenance_capsule"]:
        fail("claim capsule binding")
    if claim[64:96].hex() != object_digests["source_closure"] or claim[96:128].hex() != object_digests["build_plan"]:
        fail("claim source plan binding")
    for label, receipt in (("first", first_receipt), ("relocated", relocated_receipt)):
        if receipt[32:64].hex() != object_digests["build_claim"]:
            fail(f"{label} receipt claim binding")
        if receipt[64:96].hex() != object_digests["provenance_capsule"]:
            fail(f"{label} receipt capsule binding")
        if receipt[96:128].hex() != object_digests["source_closure"] or receipt[128:160].hex() != object_digests["build_plan"]:
            fail(f"{label} receipt source plan binding")
        if receipt[160:192] != claim[128:160]:
            fail(f"{label} receipt output binding")
    if first_receipt == relocated_receipt:
        fail("independent receipt identities collapsed")

    # BuildClaim and ProvenanceCapsule encodings contain only canonical subject fields.
    # Exact observed locator digests are checked against these bytes by the retained-evidence verifier.
    if len(capsule) != 264 or len(claim) != 200:
        fail("canonical subject object size")


    cuts = rows(root / "CUTS.tsv")
    if len(cuts) != 7 or [int(row["index"]) for row in cuts] != list(range(7)):
        fail("cut cardinality")
    fields = [
        ("source_closure", object_digests["source_closure"], 0),
        ("build_plan", object_digests["build_plan"], 1),
        ("capsule", object_digests["provenance_capsule"], 2),
        ("first_claim", object_digests["build_claim"], 3),
        ("first_receipt", object_digests["first_reopen_receipt"], 4),
        ("relocated_claim", object_digests["build_claim"], 5),
        ("relocated_receipt", object_digests["relocated_reopen_receipt"], 6),
    ]
    for row_index, row in enumerate(cuts):
        for field, value, first_present in fields:
            expected_value = value if row_index >= first_present else ZERO
            if row[field] != expected_value:
                fail(f"cut={row_index}:{field}")

    laws = rows(root / "LAWS.tsv")
    countermodels = rows(root / "COUNTERMODELS.tsv")
    if len(laws) != 17 or len(countermodels) != 19:
        fail("law countermodel cardinality")
    if [int(row["law"]) for row in laws] != list(range(1, 18)):
        fail("law order")
    if [int(row["countermodel"]) for row in countermodels] != list(range(1, 20)):
        fail("countermodel order")

    report = (root / "REPORT.txt").read_text(encoding="utf-8")
    for marker in (
        "RELOCATABLE_PROVENANCE=PASS", "physical_locator_is_identity=false",
        "raw_logs_are_canonical=false", "source_manifest_bound_into_subject=true",
        "build_plan_bound_into_subject=true", "output_contract_bound_into_subject=true",
        "reference_canonical_encoder_independent=true", "first_receipt_precedes_relocated_claim=true",
        "authority=false", "epoch=EPOCH_ZERO",
    ):
        if marker not in report:
            fail(f"report marker={marker}")

    print(
        "RELOCATABLE_PROVENANCE_PY=PASS cases=66 accepted=9 rejected=57 "
        "relocation_matrix=24 exact_object_bytes=2180 locator_identity=false authority=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
