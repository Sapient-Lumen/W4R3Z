#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery.hpp"

#include <algorithm>
#include <span>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery {
namespace {

[[nodiscard]] bool nonzero(const Digest& value) noexcept {
    return std::any_of(value.begin(), value.end(), [](const std::uint8_t byte) {
        return byte != 0U;
    });
}

[[nodiscard]] RecoveryReport report(
    const RecoveryCode code,
    const bool accepted,
    const Phase next_phase,
    const Outcome outcome) noexcept {
    const bool query_only = next_phase == Phase::query_only;
    const bool terminal = next_phase == Phase::terminal_effect
        || next_phase == Phase::terminal_no_effect
        || next_phase == Phase::fail_stopped;
    return RecoveryReport{
        code,
        accepted,
        next_phase,
        outcome,
        query_only,
        terminal,
        accepted && next_phase == Phase::terminal_no_effect,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
    };
}

[[nodiscard]] RecoveryReport reject(
    const RecoveryCode code,
    const RecoveryState& state) noexcept {
    const Outcome outcome = state.phase == Phase::terminal_effect
        ? Outcome::effect
        : state.phase == Phase::terminal_no_effect
            ? Outcome::no_effect
            : state.phase == Phase::query_only
                ? Outcome::uncertain
                : state.phase == Phase::fail_stopped
                    ? Outcome::fail_stop
                    : Outcome::none;
    return report(code, false, state.phase, outcome);
}

[[nodiscard]] RecoveryReport require_observation_proof(
    const RecoveryState& state,
    const RecoveryStep& step,
    const bool require_durable,
    const bool require_retention) noexcept {
    if (!step.authenticated) {
        return reject(RecoveryCode::authentication_required, state);
    }
    if (!step.linearizable) {
        return reject(RecoveryCode::linearizable_observation_required, state);
    }
    if (!step.single_view) {
        return reject(RecoveryCode::single_view_required, state);
    }
    if (require_durable && !step.durable_result) {
        return reject(RecoveryCode::durable_result_required, state);
    }
    if (require_retention && !step.retention_covers_reopen) {
        return reject(RecoveryCode::retention_horizon_required, state);
    }
    return report(RecoveryCode::invalid_state, true, state.phase, Outcome::none);
}

}  // namespace

RecoveryReport evaluate_candidate(
    const RecoveryState& state,
    const RecoveryStep& step) noexcept {
    if (!nonzero(state.request_id)
        || !nonzero(state.transition_digest)
        || !nonzero(state.register_incarnation)) {
        return reject(RecoveryCode::invalid_state, state);
    }
    if (step.request_id != state.request_id) {
        return reject(RecoveryCode::request_id_mismatch, state);
    }
    if (step.transition_digest != state.transition_digest) {
        return reject(RecoveryCode::transition_digest_mismatch, state);
    }
    if (step.register_incarnation != state.register_incarnation) {
        return reject(RecoveryCode::register_incarnation_mismatch, state);
    }

    switch (state.phase) {
    case Phase::ready: {
        if (step.command != Command::submit_exact) {
            return reject(RecoveryCode::invalid_command_for_phase, state);
        }
        if (step.observation == Observation::no_reply) {
            return report(
                RecoveryCode::accepted_submit_uncertain,
                true,
                Phase::query_only,
                Outcome::uncertain);
        }
        if (step.observation != Observation::commit_reply) {
            return reject(RecoveryCode::invalid_observation_for_command, state);
        }
        const RecoveryReport proof = require_observation_proof(state, step, true, true);
        if (!proof.accepted) {
            return proof;
        }
        return report(
            RecoveryCode::accepted_submit_commit,
            true,
            Phase::terminal_effect,
            Outcome::effect);
    }
    case Phase::query_only: {
        if (step.command == Command::reopen) {
            if (step.observation != Observation::reopen_event) {
                return reject(RecoveryCode::invalid_observation_for_command, state);
            }
            return report(
                RecoveryCode::accepted_reopen_query_only,
                true,
                Phase::query_only,
                Outcome::uncertain);
        }
        if (step.command == Command::declare_no_effect
            && step.observation == Observation::absent_record) {
            return reject(RecoveryCode::absence_not_terminal, state);
        }
        if (step.command == Command::submit_exact
            || step.command == Command::clear_latch
            || step.command == Command::repair) {
            return reject(RecoveryCode::query_only_latched, state);
        }
        if (step.command != Command::query_exact) {
            return reject(RecoveryCode::invalid_command_for_phase, state);
        }
        if (step.observation == Observation::unavailable) {
            return report(
                RecoveryCode::accepted_query_unavailable,
                true,
                Phase::query_only,
                Outcome::uncertain);
        }
        if (step.observation == Observation::wrong_incarnation) {
            return report(
                RecoveryCode::accepted_query_wrong_incarnation_fail_stop,
                true,
                Phase::fail_stopped,
                Outcome::fail_stop);
        }
        if (step.observation == Observation::split_view) {
            return report(
                RecoveryCode::accepted_query_split_view_fail_stop,
                true,
                Phase::fail_stopped,
                Outcome::fail_stop);
        }
        const bool is_committed = step.observation == Observation::committed_record;
        const bool is_absent = step.observation == Observation::absent_record;
        const bool is_retired = step.observation == Observation::retired_record;
        if (!is_committed && !is_absent && !is_retired) {
            return reject(RecoveryCode::invalid_observation_for_command, state);
        }
        const RecoveryReport proof = require_observation_proof(
            state,
            step,
            is_committed || is_retired,
            is_committed || is_retired);
        if (!proof.accepted) {
            return proof;
        }
        if (is_absent) {
            return report(
                RecoveryCode::accepted_query_absent_unresolved,
                true,
                Phase::query_only,
                Outcome::uncertain);
        }
        if (is_committed) {
            return report(
                RecoveryCode::accepted_query_commit,
                true,
                Phase::terminal_effect,
                Outcome::effect);
        }
        if (!step.retirement_serialized) {
            return reject(RecoveryCode::retirement_record_required, state);
        }
        if (!step.late_commit_fenced) {
            return reject(RecoveryCode::late_commit_fence_required, state);
        }
        return report(
            RecoveryCode::accepted_query_retired,
            true,
            Phase::terminal_no_effect,
            Outcome::no_effect);
    }
    case Phase::terminal_effect:
        if (step.command == Command::reopen && step.observation == Observation::reopen_event) {
            return report(
                RecoveryCode::accepted_reopen_terminal_effect,
                true,
                Phase::terminal_effect,
                Outcome::effect);
        }
        return reject(RecoveryCode::terminal_immutable, state);
    case Phase::terminal_no_effect:
        if (step.command == Command::reopen && step.observation == Observation::reopen_event) {
            return report(
                RecoveryCode::accepted_reopen_terminal_no_effect,
                true,
                Phase::terminal_no_effect,
                Outcome::no_effect);
        }
        return reject(RecoveryCode::terminal_immutable, state);
    case Phase::fail_stopped:
        if (step.command == Command::reopen && step.observation == Observation::reopen_event) {
            return report(
                RecoveryCode::accepted_reopen_fail_stop,
                true,
                Phase::fail_stopped,
                Outcome::fail_stop);
        }
        return reject(RecoveryCode::fail_stop_immutable, state);
    }
    return reject(RecoveryCode::invalid_state, state);
}

std::string_view phase_name(const Phase value) noexcept {
    switch (value) {
    case Phase::ready: return "ready";
    case Phase::query_only: return "query_only";
    case Phase::terminal_effect: return "terminal_effect";
    case Phase::terminal_no_effect: return "terminal_no_effect";
    case Phase::fail_stopped: return "fail_stopped";
    }
    return "invalid";
}

std::string_view command_name(const Command value) noexcept {
    switch (value) {
    case Command::submit_exact: return "submit_exact";
    case Command::query_exact: return "query_exact";
    case Command::declare_no_effect: return "declare_no_effect";
    case Command::reopen: return "reopen";
    case Command::clear_latch: return "clear_latch";
    case Command::repair: return "repair";
    case Command::none: return "none";
    }
    return "invalid";
}

std::string_view observation_name(const Observation value) noexcept {
    switch (value) {
    case Observation::commit_reply: return "commit_reply";
    case Observation::no_reply: return "no_reply";
    case Observation::committed_record: return "committed_record";
    case Observation::absent_record: return "absent_record";
    case Observation::retired_record: return "retired_record";
    case Observation::unavailable: return "unavailable";
    case Observation::wrong_incarnation: return "wrong_incarnation";
    case Observation::split_view: return "split_view";
    case Observation::reopen_event: return "reopen_event";
    case Observation::none: return "none";
    }
    return "invalid";
}

std::string_view outcome_name(const Outcome value) noexcept {
    switch (value) {
    case Outcome::none: return "none";
    case Outcome::uncertain: return "uncertain";
    case Outcome::effect: return "effect";
    case Outcome::no_effect: return "no_effect";
    case Outcome::fail_stop: return "fail_stop";
    }
    return "invalid";
}

std::string_view recovery_code_name(const RecoveryCode value) noexcept {
    switch (value) {
    case RecoveryCode::accepted_submit_commit: return "accepted_submit_commit";
    case RecoveryCode::accepted_submit_uncertain: return "accepted_submit_uncertain";
    case RecoveryCode::accepted_query_commit: return "accepted_query_commit";
    case RecoveryCode::accepted_query_absent_unresolved: return "accepted_query_absent_unresolved";
    case RecoveryCode::accepted_query_retired: return "accepted_query_retired";
    case RecoveryCode::accepted_query_unavailable: return "accepted_query_unavailable";
    case RecoveryCode::accepted_query_wrong_incarnation_fail_stop: return "accepted_query_wrong_incarnation_fail_stop";
    case RecoveryCode::accepted_query_split_view_fail_stop: return "accepted_query_split_view_fail_stop";
    case RecoveryCode::accepted_reopen_query_only: return "accepted_reopen_query_only";
    case RecoveryCode::accepted_reopen_terminal_effect: return "accepted_reopen_terminal_effect";
    case RecoveryCode::accepted_reopen_terminal_no_effect: return "accepted_reopen_terminal_no_effect";
    case RecoveryCode::accepted_reopen_fail_stop: return "accepted_reopen_fail_stop";
    case RecoveryCode::invalid_state: return "invalid_state";
    case RecoveryCode::request_id_mismatch: return "request_id_mismatch";
    case RecoveryCode::transition_digest_mismatch: return "transition_digest_mismatch";
    case RecoveryCode::register_incarnation_mismatch: return "register_incarnation_mismatch";
    case RecoveryCode::invalid_command_for_phase: return "invalid_command_for_phase";
    case RecoveryCode::invalid_observation_for_command: return "invalid_observation_for_command";
    case RecoveryCode::authentication_required: return "authentication_required";
    case RecoveryCode::linearizable_observation_required: return "linearizable_observation_required";
    case RecoveryCode::single_view_required: return "single_view_required";
    case RecoveryCode::durable_result_required: return "durable_result_required";
    case RecoveryCode::retention_horizon_required: return "retention_horizon_required";
    case RecoveryCode::retirement_record_required: return "retirement_record_required";
    case RecoveryCode::late_commit_fence_required: return "late_commit_fence_required";
    case RecoveryCode::absence_not_terminal: return "absence_not_terminal";
    case RecoveryCode::query_only_latched: return "query_only_latched";
    case RecoveryCode::terminal_immutable: return "terminal_immutable";
    case RecoveryCode::fail_stop_immutable: return "fail_stop_immutable";
    }
    return "invalid";
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery
