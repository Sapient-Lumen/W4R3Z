#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/exact_predecessor_consumption.hpp"

#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <sstream>
#include <string>
#include <string_view>
#include <system_error>
#include <utility>
#include <vector>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::exact_predecessor_consumption {
namespace {

struct TestCase final {
    std::string name;
    ChainTrace trace;
    ChainCode expected;
};

[[nodiscard]] Digest digest(const std::uint8_t seed) noexcept {
    Digest value{};
    for (std::size_t index = 0U; index < value.size(); ++index) {
        value[index] = static_cast<std::uint8_t>(seed + static_cast<std::uint8_t>(index));
    }
    return value;
}

[[nodiscard]] std::string hex(const Digest& value) {
    std::ostringstream stream;
    stream << std::hex << std::setfill('0');
    for (const auto byte : value) stream << std::setw(2) << static_cast<unsigned int>(byte);
    return stream.str();
}

[[nodiscard]] std::string truth(const bool value) { return value ? "true" : "false"; }

[[nodiscard]] TerminalState terminal(const TerminalKind kind) noexcept {
    return TerminalState{digest(0x11U), digest(0x31U), digest(0x51U), digest(0x71U), kind};
}

[[nodiscard]] ContinuityEvidence continuity(const TerminalState& state) noexcept {
    ContinuityEvidence value{};
    value.request_id = state.request_id;
    value.transition_digest = state.transition_digest;
    value.register_incarnation = state.register_incarnation;
    value.terminal_digest = state.terminal_digest;
    value.terminal_kind = state.terminal_kind;
    value.terminal_record_present = true;
    value.terminal_record_authenticated = true;
    value.terminal_record_durable = true;
    value.terminal_record_serialized = true;
    value.terminal_record_single_view = true;
    value.terminal_record_retained_full_horizon = true;
    value.terminal_record_fences_pending = true;
    value.terminal_record_survives_restore = true;
    value.terminal_record_survives_succession = true;
    value.terminal_record_independently_reopenable = true;
    value.terminal_witness_present = true;
    value.terminal_witness_authenticated = true;
    value.terminal_witness_binds_terminal = true;
    value.terminal_witness_durable = true;
    value.terminal_witness_independently_reopenable = true;
    value.terminal_witness_survives_restore = true;
    value.terminal_witness_survives_succession = true;
    value.successor_floor_present = true;
    value.successor_floor_authenticated = true;
    value.successor_floor_monotone = true;
    value.successor_floor_outside_restore_domain = true;
    value.successor_floor_binds_request_namespace = true;
    value.old_incarnation_rejected = true;
    value.pending_invocations_fenced = true;
    value.restore_preserves_floor = true;
    value.succession_preserves_floor = true;
    value.successor_floor_single_view = true;
    value.reclamation_requested = true;
    return value;
}

[[nodiscard]] JoinReceipt join_for(const CutoverTrace& trace) noexcept {
    JoinReceipt value{};
    value.cutover_id = trace.cutover_id;
    value.request_id = trace.state.request_id;
    value.transition_digest = trace.state.transition_digest;
    value.register_incarnation = trace.state.register_incarnation;
    value.terminal_digest = trace.state.terminal_digest;
    value.witness_digest = trace.witness_digest;
    value.floor_digest = trace.floor_digest;
    value.terminal_kind = trace.state.terminal_kind;
    value.present = true;
    value.authenticated = true;
    value.durable = true;
    value.single_view = true;
    value.independently_reopenable = true;
    value.survives_restore = true;
    value.survives_succession = true;
    return value;
}

[[nodiscard]] CutObservation pcut(
    const bool live,
    const bool witness,
    const bool floor,
    const bool join,
    const bool authorization,
    const bool deleted,
    const bool reopen = false) noexcept {
    return CutObservation{live, witness, floor, join, authorization, deleted, reopen};
}

[[nodiscard]] CutoverTrace parent_trace(
    const TerminalKind kind,
    const bool delete_record,
    const bool floor_first = false) noexcept {
    CutoverTrace trace{};
    trace.state = terminal(kind);
    trace.continuity = continuity(trace.state);
    trace.cutover_id = digest(0x91U);
    trace.witness_digest = digest(0xB1U);
    trace.floor_digest = digest(0xD1U);
    trace.reclamation_requested = true;
    trace.join = join_for(trace);
    if (floor_first) {
        trace.cuts = {
            pcut(true, false, false, false, false, false),
            pcut(true, false, true, false, false, false),
            pcut(true, true, true, false, false, false),
            pcut(true, true, true, true, false, false),
            pcut(true, true, true, true, false, false, true),
            pcut(true, true, true, true, delete_record, false, true),
            pcut(!delete_record, true, true, true, delete_record, delete_record, true),
        };
    } else {
        trace.cuts = {
            pcut(true, false, false, false, false, false),
            pcut(true, true, false, false, false, false),
            pcut(true, true, true, false, false, false),
            pcut(true, true, true, true, false, false),
            pcut(true, true, true, true, false, false, true),
            pcut(true, true, true, true, delete_record, false, true),
            pcut(!delete_record, true, true, true, delete_record, delete_record, true),
        };
    }
    return trace;
}

[[nodiscard]] PhaseReceipt receipt(
    const Phase phase,
    const std::uint8_t identity_seed,
    const ChainTrace& trace) noexcept {
    PhaseReceipt value{};
    value.phase = phase;
    value.record_digest = digest(identity_seed);
    value.cutover_id = trace.parent.cutover_id;
    value.request_id = trace.parent.state.request_id;
    value.transition_digest = trace.parent.state.transition_digest;
    value.register_incarnation = trace.parent.state.register_incarnation;
    value.terminal_digest = trace.parent.state.terminal_digest;
    value.witness_digest = trace.parent.witness_digest;
    value.floor_digest = trace.parent.floor_digest;
    value.terminal_kind = trace.parent.state.terminal_kind;
    switch (phase) {
    case Phase::witness_publication: value.basis_digest = trace.parent.witness_digest; break;
    case Phase::floor_publication: value.basis_digest = trace.parent.floor_digest; break;
    case Phase::join_publication: value.basis_digest = trace.parent.cutover_id; break;
    case Phase::cold_reopen_receipt: value.basis_digest = trace.parent.state.terminal_digest; break;
    case Phase::deletion_authorization: value.basis_digest = trace.parent.state.transition_digest; break;
    }
    value.present = true;
    value.authenticated = true;
    value.durable = true;
    value.single_view = true;
    value.independently_reopenable = true;
    value.survives_restore = true;
    value.survives_succession = true;
    value.published = true;
    return value;
}

[[nodiscard]] ChainCut ccut(
    const bool live,
    const std::array<bool, phase_count>& visible,
    const bool deleted = false) noexcept {
    return ChainCut{live, visible, deleted};
}

[[nodiscard]] ChainTrace complete_trace(
    const TerminalKind kind = TerminalKind::effect,
    const bool delete_record = true,
    const bool floor_first = false,
    const bool parallel_components = false) noexcept {
    ChainTrace trace{};
    trace.parent = parent_trace(kind, delete_record, floor_first);
    trace.reclamation_requested = true;
    trace.receipts[0] = receipt(Phase::witness_publication, 0x21U, trace);
    trace.receipts[1] = receipt(Phase::floor_publication, 0x41U, trace);
    trace.receipts[2] = receipt(Phase::join_publication, 0x61U, trace);
    trace.receipts[3] = receipt(Phase::cold_reopen_receipt, 0x81U, trace);
    trace.receipts[4] = receipt(Phase::deletion_authorization, 0xA1U, trace);
    trace.receipts[2].predecessor_a = trace.receipts[0].record_digest;
    trace.receipts[2].predecessor_b = trace.receipts[1].record_digest;
    trace.receipts[3].predecessor_a = trace.receipts[2].record_digest;
    trace.receipts[4].predecessor_a = trace.receipts[3].record_digest;
    trace.deletion_consumed_authorization_digest = trace.receipts[4].record_digest;
    const std::array<bool, phase_count> none{false, false, false, false, false};
    const std::array<bool, phase_count> witness{true, false, false, false, false};
    const std::array<bool, phase_count> floor{false, true, false, false, false};
    const std::array<bool, phase_count> components{true, true, false, false, false};
    const std::array<bool, phase_count> joined{true, true, true, false, false};
    const std::array<bool, phase_count> reopened{true, true, true, true, false};
    const std::array<bool, phase_count> authorized{true, true, true, true, true};
    if (parallel_components) {
        trace.cuts = {
            ccut(true, none), ccut(true, components), ccut(true, components), ccut(true, joined),
            ccut(true, reopened), ccut(true, authorized), ccut(true, authorized),
            ccut(!delete_record, authorized, delete_record),
        };
    } else if (floor_first) {
        trace.cuts = {
            ccut(true, none), ccut(true, floor), ccut(true, components), ccut(true, joined),
            ccut(true, reopened), ccut(true, authorized), ccut(true, authorized),
            ccut(!delete_record, authorized, delete_record),
        };
    } else {
        trace.cuts = {
            ccut(true, none), ccut(true, witness), ccut(true, components), ccut(true, joined),
            ccut(true, reopened), ccut(true, authorized), ccut(true, authorized),
            ccut(!delete_record, authorized, delete_record),
        };
    }
    return trace;
}

void remove_receipts_from(ChainTrace& trace, const std::size_t first_absent) noexcept {
    for (std::size_t slot = first_absent; slot < phase_count; ++slot) {
        trace.receipts[slot] = PhaseReceipt{};
        for (auto& cut : trace.cuts) cut.receipt_visible[slot] = false;
    }
    trace.deletion_consumed_authorization_digest = Digest{};
}

void delete_from(ChainTrace& trace, const std::size_t first_cut) noexcept {
    for (std::size_t cut = first_cut; cut < chain_cut_count; ++cut) {
        trace.cuts[cut].deletion_applied = true;
        trace.cuts[cut].live_record_visible = false;
    }
}

[[nodiscard]] std::vector<TestCase> cases() {
    std::vector<TestCase> values;
    const auto add = [&values](std::string name, ChainTrace trace, const ChainCode code) {
        values.push_back(TestCase{std::move(name), std::move(trace), code});
    };

    add("safe_effect_witness_first", complete_trace(), ChainCode::accepted_chain_complete);
    add("safe_no_effect_witness_first", complete_trace(TerminalKind::no_effect), ChainCode::accepted_chain_complete);
    add("safe_effect_floor_first", complete_trace(TerminalKind::effect, true, true), ChainCode::accepted_chain_complete);
    add("safe_no_effect_floor_first", complete_trace(TerminalKind::no_effect, true, true), ChainCode::accepted_chain_complete);
    add("safe_effect_parallel_components", complete_trace(TerminalKind::effect, true, false, true), ChainCode::accepted_chain_complete);
    add("safe_no_effect_parallel_components", complete_trace(TerminalKind::no_effect, true, false, true), ChainCode::accepted_chain_complete);
    { auto t = complete_trace(); t.parent.continuity.client_acknowledged = true; add("safe_client_ack_irrelevant", t, ChainCode::accepted_chain_complete); }
    { auto t = complete_trace(TerminalKind::no_effect); t.parent.continuity.ttl_expired = true; add("safe_ttl_irrelevant", t, ChainCode::accepted_chain_complete); }

    add("ready_effect_witness_first", complete_trace(TerminalKind::effect, false), ChainCode::accepted_chain_ready_live_retained);
    add("ready_no_effect_floor_first", complete_trace(TerminalKind::no_effect, false, true), ChainCode::accepted_chain_ready_live_retained);
    add("ready_effect_parallel", complete_trace(TerminalKind::effect, false, false, true), ChainCode::accepted_chain_ready_live_retained);
    add("ready_no_effect_parallel", complete_trace(TerminalKind::no_effect, false, false, true), ChainCode::accepted_chain_ready_live_retained);

    { auto t = complete_trace(TerminalKind::effect, false); remove_receipts_from(t, 0U); add("prefix_live_no_exact_receipts", t, ChainCode::accepted_chain_prefix_live_retained); }
    { auto t = complete_trace(TerminalKind::effect, false); remove_receipts_from(t, 1U); add("prefix_live_witness_only", t, ChainCode::accepted_chain_prefix_live_retained); }
    { auto t = complete_trace(TerminalKind::effect, false); remove_receipts_from(t, 2U); add("prefix_live_components_only", t, ChainCode::accepted_chain_prefix_live_retained); }
    { auto t = complete_trace(TerminalKind::effect, false); remove_receipts_from(t, 3U); add("prefix_live_through_join", t, ChainCode::accepted_chain_prefix_live_retained); }
    { auto t = complete_trace(TerminalKind::effect, false); remove_receipts_from(t, 4U); add("prefix_live_through_reopen", t, ChainCode::accepted_chain_prefix_live_retained); }
    { auto t = complete_trace(TerminalKind::effect, false); remove_receipts_from(t, 0U); t.receipts[1] = receipt(Phase::floor_publication, 0x41U, t); for (std::size_t i=1;i<chain_cut_count;++i) t.cuts[i].receipt_visible[1]=true; add("prefix_live_floor_only", t, ChainCode::accepted_chain_prefix_live_retained); }

    { auto t=complete_trace(); t.receipts[2].predecessor_a=digest(0x22U); add("refused_join_wrong_witness_predecessor",t,ChainCode::accepted_reclamation_refused_exact_predecessor); }
    { auto t=complete_trace(); t.receipts[2].predecessor_b=digest(0x42U); add("refused_join_wrong_floor_predecessor",t,ChainCode::accepted_reclamation_refused_exact_predecessor); }
    { auto t=complete_trace(); t.receipts[3].predecessor_a=digest(0x62U); add("refused_reopen_wrong_join_predecessor",t,ChainCode::accepted_reclamation_refused_exact_predecessor); }
    { auto t=complete_trace(); t.receipts[4].predecessor_a=digest(0x82U); add("refused_authorization_wrong_reopen_predecessor",t,ChainCode::accepted_reclamation_refused_exact_predecessor); }
    { auto t=complete_trace(); t.deletion_consumed_authorization_digest=digest(0xA2U); add("refused_delete_wrong_authorization_predecessor",t,ChainCode::accepted_reclamation_refused_exact_predecessor); }
    { auto t=complete_trace(); std::swap(t.receipts[2].predecessor_a,t.receipts[2].predecessor_b); add("refused_join_swapped_predecessors",t,ChainCode::accepted_reclamation_refused_exact_predecessor); }
    { auto t=complete_trace(); t.receipts[2].predecessor_a=digest(0x01U); add("refused_join_stale_witness_receipt",t,ChainCode::accepted_reclamation_refused_exact_predecessor); }
    { auto t=complete_trace(); t.receipts[2].predecessor_b=digest(0x02U); add("refused_join_stale_floor_receipt",t,ChainCode::accepted_reclamation_refused_exact_predecessor); }
    { auto t=complete_trace(); t.receipts[3].predecessor_a=t.receipts[0].record_digest; add("refused_reopen_skips_join",t,ChainCode::accepted_reclamation_refused_exact_predecessor); }
    { auto t=complete_trace(); t.receipts[4].predecessor_a=t.receipts[2].record_digest; add("refused_authorization_skips_reopen",t,ChainCode::accepted_reclamation_refused_exact_predecessor); }
    { auto t=complete_trace(); t.receipts[4].predecessor_a=digest(0xE1U); add("refused_cross_history_authorization_receipt",t,ChainCode::accepted_reclamation_refused_exact_predecessor); }
    { auto t=complete_trace(); t.receipts[3].predecessor_a=Digest{}; add("refused_zero_predecessor",t,ChainCode::accepted_reclamation_refused_exact_predecessor); }

    { auto t=complete_trace(); t.receipts[0].published=false; add("refused_witness_not_published",t,ChainCode::accepted_reclamation_refused_publication); }
    { auto t=complete_trace(); t.receipts[1].published=false; add("refused_floor_not_published",t,ChainCode::accepted_reclamation_refused_publication); }
    { auto t=complete_trace(); t.receipts[2].published=false; add("refused_join_not_published",t,ChainCode::accepted_reclamation_refused_publication); }
    { auto t=complete_trace(); t.receipts[3].published=false; add("refused_reopen_receipt_not_published",t,ChainCode::accepted_reclamation_refused_publication); }
    { auto t=complete_trace(); t.receipts[4].published=false; add("refused_authorization_not_published",t,ChainCode::accepted_reclamation_refused_publication); }
    { auto t=complete_trace(); t.receipts[0].durable=false; add("refused_witness_publication_not_durable",t,ChainCode::accepted_reclamation_refused_publication); }
    { auto t=complete_trace(); t.receipts[2].independently_reopenable=false; add("refused_join_not_independently_reopenable",t,ChainCode::accepted_reclamation_refused_publication); }
    { auto t=complete_trace(); t.receipts[4].survives_succession=false; add("refused_authorization_lost_on_succession",t,ChainCode::accepted_reclamation_refused_publication); }

    { auto t=complete_trace(); t.cuts[2].receipt_visible[2]=true; add("refused_join_same_cut_as_second_component",t,ChainCode::accepted_reclamation_refused_phase_order); }
    { auto t=complete_trace(); t.cuts[3].receipt_visible[3]=true; add("refused_reopen_same_cut_as_join",t,ChainCode::accepted_reclamation_refused_phase_order); }
    { auto t=complete_trace(); t.cuts[4].receipt_visible[4]=true; add("refused_authorization_same_cut_as_reopen",t,ChainCode::accepted_reclamation_refused_phase_order); }
    { auto t=complete_trace(); delete_from(t,5U); add("refused_delete_same_cut_as_authorization",t,ChainCode::accepted_reclamation_refused_phase_order); }
    { auto t=complete_trace(); for (std::size_t i=1U;i<chain_cut_count;++i) t.cuts[i].receipt_visible[2]=true; add("refused_join_before_floor",t,ChainCode::accepted_reclamation_refused_phase_order); }
    { auto t=complete_trace(); for (std::size_t i=2U;i<chain_cut_count;++i) t.cuts[i].receipt_visible[3]=true; add("refused_reopen_before_join",t,ChainCode::accepted_reclamation_refused_phase_order); }
    { auto t=complete_trace(); for (std::size_t i=3U;i<chain_cut_count;++i) t.cuts[i].receipt_visible[4]=true; add("refused_authorization_before_reopen",t,ChainCode::accepted_reclamation_refused_phase_order); }
    { auto t=complete_trace(); delete_from(t,4U); add("refused_delete_before_authorization",t,ChainCode::accepted_reclamation_refused_phase_order); }

    { auto t=complete_trace(); t.parent=parent_trace(TerminalKind::effect,false); add("refused_parent_not_reclamation_safe",t,ChainCode::accepted_reclamation_refused_prefix_gap); }
    { auto t=complete_trace(); t.parent.cuts[6].record_deleted=false; t.parent.cuts[6].live_record_visible=true; add("refused_parent_final_live_bridge",t,ChainCode::accepted_reclamation_refused_prefix_gap); }
    { auto t=complete_trace(); t.parent.cuts[5].deletion_authorized=false; t.parent.cuts[6].deletion_authorized=false; t.parent.cuts[6].record_deleted=false; t.parent.cuts[6].live_record_visible=true; add("refused_parent_missing_authorization",t,ChainCode::accepted_reclamation_refused_prefix_gap); }
    { auto t=complete_trace(); delete_from(t,6U); add("safe_earlier_delete_after_strict_authorization",t,ChainCode::accepted_chain_complete); }
    { auto t=complete_trace(); t.parent.equivocation_observed=true; add("parent_equivocation_is_accepted_fail_stop_not_safe",t,ChainCode::accepted_reclamation_refused_prefix_gap); }

    { auto t=complete_trace(); t.equivocation_observed=true; add("equivocation_fail_stop",t,ChainCode::accepted_equivocation_fail_stop); }
    { auto t=complete_trace(); t.cuts[6].receipt_visible[0]=false; add("witness_visibility_regression_fail_stop",t,ChainCode::accepted_regression_fail_stop); }
    { auto t=complete_trace(); t.cuts[6].receipt_visible[2]=false; add("join_visibility_regression_fail_stop",t,ChainCode::accepted_regression_fail_stop); }
    { auto t=complete_trace(); t.cuts[6].receipt_visible[4]=false; add("authorization_visibility_regression_fail_stop",t,ChainCode::accepted_regression_fail_stop); }
    { auto t=complete_trace(); delete_from(t,6U); t.cuts[7].deletion_applied=false; t.cuts[7].live_record_visible=true; add("deletion_regression_fail_stop",t,ChainCode::accepted_regression_fail_stop); }
    { auto t=complete_trace(); delete_from(t,6U); t.cuts[7].live_record_visible=true; t.cuts[7].deletion_applied=false; add("live_record_resurrection_fail_stop",t,ChainCode::accepted_regression_fail_stop); }

    { auto t=complete_trace(); t.parent.state.request_id=Digest{}; add("reject_parent_relation",t,ChainCode::parent_relation_rejected); }
    { auto t=complete_trace(); t.reclamation_requested=false; add("reject_reclamation_request_mismatch",t,ChainCode::reclamation_request_mismatch); }
    { auto t=complete_trace(); t.receipts[3].phase=Phase::join_publication; add("reject_receipt_phase_mismatch",t,ChainCode::receipt_phase_mismatch); }
    { auto t=complete_trace(); t.receipts[2].cutover_id=digest(0x92U); add("reject_subject_cutover_mismatch",t,ChainCode::receipt_subject_mismatch); }
    { auto t=complete_trace(); t.receipts[2].request_id=digest(0x12U); add("reject_subject_request_mismatch",t,ChainCode::receipt_subject_mismatch); }
    { auto t=complete_trace(); t.receipts[2].transition_digest=digest(0x32U); add("reject_subject_transition_mismatch",t,ChainCode::receipt_subject_mismatch); }
    { auto t=complete_trace(); t.receipts[2].register_incarnation=digest(0x52U); add("reject_subject_incarnation_mismatch",t,ChainCode::receipt_subject_mismatch); }
    { auto t=complete_trace(); t.receipts[2].terminal_digest=digest(0x72U); add("reject_subject_terminal_digest_mismatch",t,ChainCode::receipt_subject_mismatch); }
    { auto t=complete_trace(); t.receipts[2].terminal_kind=TerminalKind::no_effect; add("reject_subject_terminal_kind_mismatch",t,ChainCode::receipt_subject_mismatch); }
    { auto t=complete_trace(); t.receipts[0].witness_digest=digest(0xB2U); add("reject_subject_witness_digest_mismatch",t,ChainCode::receipt_subject_mismatch); }
    { auto t=complete_trace(); t.receipts[1].floor_digest=digest(0xD2U); add("reject_subject_floor_digest_mismatch",t,ChainCode::receipt_subject_mismatch); }
    { auto t=complete_trace(); t.receipts[0].basis_digest=digest(0xB2U); add("reject_witness_component_mismatch",t,ChainCode::receipt_component_mismatch); }
    { auto t=complete_trace(); t.receipts[1].basis_digest=digest(0xD2U); add("reject_floor_component_mismatch",t,ChainCode::receipt_component_mismatch); }
    { auto t=complete_trace(); t.receipts[2].basis_digest=digest(0x92U); add("reject_join_component_mismatch",t,ChainCode::receipt_component_mismatch); }
    { auto t=complete_trace(); t.receipts[3].record_digest=Digest{}; add("reject_zero_receipt_digest",t,ChainCode::receipt_digest_zero); }
    { auto t=complete_trace(); t.receipts[4].record_digest=t.receipts[3].record_digest; add("reject_duplicate_receipt_digest",t,ChainCode::receipt_digest_duplicate); }
    { auto t=complete_trace(); t.cuts[0].live_record_visible=false; t.cuts[0].deletion_applied=true; add("reject_initial_state_invalid",t,ChainCode::trace_initial_state_invalid); }
    { auto t=complete_trace(); t.cuts[6].deletion_applied=true; add("reject_deleted_and_live",t,ChainCode::trace_deleted_and_live); }

    return values;
}

[[nodiscard]] bool write_text(const std::filesystem::path& path, const std::string& text) {
    std::error_code error;
    std::filesystem::create_directories(path.parent_path(), error);
    if (error) return false;
    std::ofstream stream(path, std::ios::binary | std::ios::trunc);
    stream << text;
    return stream.good();
}

}  // namespace

bool run_campaign(const std::filesystem::path& output_directory) {
    const auto tests = cases();
    std::map<std::string, std::size_t> code_counts;
    std::size_t accepted = 0U;
    std::size_t disagreements = 0U;
    std::string cases_tsv =
        "case\texpected\tcode\taccepted\tagreement\tparent_accepted\tparent_safe\tsubjects_exact\tcomponents_exact\tdigests_unique\texact_edges\tdurable_publications\tstrict_order\tmonotone\tprefixes_covered\tchain_complete\tdeletion_safe\tlive_must_remain\tfail_stopped\tmere_visibility_sufficient\texternal_occurrence\tcurrentness\tcustody\tepoch_exit\tauthority\tparent_cutover_id\trequest_id\ttransition_digest\tregister_incarnation\tterminal_digest\twitness_digest\tfloor_digest\tterminal_kind\tdeletion_consumed_authorization_digest\n";
    std::string cuts_tsv =
        "case\tcut\tname\tlive_record\twitness_receipt\tfloor_receipt\tjoin_receipt\treopen_receipt\tauthorization_receipt\tdeletion_applied\n";
    std::string receipts_tsv =
        "case\tslot\tphase\tpresent\trecord_digest\tcutover_id\trequest_id\ttransition_digest\tregister_incarnation\tterminal_digest\twitness_digest\tfloor_digest\tbasis_digest\tpredecessor_a\tpredecessor_b\tauthenticated\tdurable\tsingle_view\tindependently_reopenable\tsurvives_restore\tsurvives_succession\tpublished\tterminal_kind\n";

    for (const auto& test : tests) {
        const auto candidate = evaluate_candidate(test.trace);
        const auto reference = evaluate_reference(test.trace);
        const bool agreement = candidate == reference;
        if (!agreement) ++disagreements;
        if (!agreement || candidate.code != test.expected) {
            std::cerr << "case=" << test.name << " expected=" << chain_code_name(test.expected)
                      << " candidate=" << chain_code_name(candidate.code)
                      << " reference=" << chain_code_name(reference.code) << "\n";
            return false;
        }
        accepted += candidate.accepted ? 1U : 0U;
        ++code_counts[std::string(chain_code_name(candidate.code))];
        cases_tsv += test.name + "\t" + std::string(chain_code_name(test.expected)) + "\t"
            + std::string(chain_code_name(candidate.code)) + "\t" + truth(candidate.accepted) + "\t"
            + truth(agreement) + "\t" + truth(candidate.parent_accepted) + "\t"
            + truth(candidate.parent_reclamation_safe) + "\t" + truth(candidate.receipt_subjects_exact) + "\t"
            + truth(candidate.receipt_components_exact) + "\t" + truth(candidate.receipt_digests_unique) + "\t"
            + truth(candidate.exact_predecessor_edges) + "\t" + truth(candidate.durable_publications) + "\t"
            + truth(candidate.strict_phase_order) + "\t" + truth(candidate.monotone_visibility) + "\t"
            + truth(candidate.every_prefix_covered) + "\t" + truth(candidate.chain_complete) + "\t"
            + truth(candidate.deletion_safe) + "\t" + truth(candidate.live_record_must_remain) + "\t"
            + truth(candidate.fail_stopped) + "\t" + truth(candidate.mere_prior_visibility_sufficient) + "\t"
            + truth(candidate.external_occurrence_proved) + "\t" + truth(candidate.currentness_proved) + "\t"
            + truth(candidate.independent_custody_proved) + "\t" + truth(candidate.epoch_exit_proved) + "\t"
            + truth(candidate.authority_granted) + "\t" + hex(test.trace.parent.cutover_id) + "\t"
            + hex(test.trace.parent.state.request_id) + "\t" + hex(test.trace.parent.state.transition_digest) + "\t"
            + hex(test.trace.parent.state.register_incarnation) + "\t" + hex(test.trace.parent.state.terminal_digest) + "\t"
            + hex(test.trace.parent.witness_digest) + "\t" + hex(test.trace.parent.floor_digest) + "\t"
            + (test.trace.parent.state.terminal_kind == TerminalKind::effect ? "effect" : "no_effect") + "\t"
            + hex(test.trace.deletion_consumed_authorization_digest) + "\n";
        for (std::size_t index = 0U; index < chain_cut_count; ++index) {
            const auto& cut = test.trace.cuts[index];
            cuts_tsv += test.name + "\t" + std::to_string(index) + "\t"
                + std::string(chain_cut_name(index)) + "\t" + truth(cut.live_record_visible);
            for (const bool visible : cut.receipt_visible) cuts_tsv += "\t" + truth(visible);
            cuts_tsv += "\t" + truth(cut.deletion_applied) + "\n";
        }
        for (std::size_t index = 0U; index < phase_count; ++index) {
            const auto& receipt_value = test.trace.receipts[index];
            receipts_tsv += test.name + "\t" + std::to_string(index) + "\t"
                + std::string(phase_name(receipt_value.phase)) + "\t" + truth(receipt_value.present) + "\t"
                + hex(receipt_value.record_digest) + "\t" + hex(receipt_value.cutover_id) + "\t"
                + hex(receipt_value.request_id) + "\t" + hex(receipt_value.transition_digest) + "\t"
                + hex(receipt_value.register_incarnation) + "\t" + hex(receipt_value.terminal_digest) + "\t"
                + hex(receipt_value.witness_digest) + "\t" + hex(receipt_value.floor_digest) + "\t"
                + hex(receipt_value.basis_digest) + "\t" + hex(receipt_value.predecessor_a) + "\t"
                + hex(receipt_value.predecessor_b) + "\t" + truth(receipt_value.authenticated) + "\t"
                + truth(receipt_value.durable) + "\t" + truth(receipt_value.single_view) + "\t"
                + truth(receipt_value.independently_reopenable) + "\t" + truth(receipt_value.survives_restore) + "\t"
                + truth(receipt_value.survives_succession) + "\t" + truth(receipt_value.published) + "\t"
                + (receipt_value.terminal_kind == TerminalKind::effect ? "effect" : "no_effect") + "\n";
        }
    }

    const auto count = [&code_counts](const std::string_view code) -> std::size_t {
        const auto found = code_counts.find(std::string(code));
        return found == code_counts.end() ? 0U : found->second;
    };
    const std::size_t complete = count("accepted_chain_complete");
    const std::size_t ready = count("accepted_chain_ready_live_retained");
    const std::size_t prefix = count("accepted_chain_prefix_live_retained");
    const std::size_t exact_refused = count("accepted_reclamation_refused_exact_predecessor");
    const std::size_t publication_refused = count("accepted_reclamation_refused_publication");
    const std::size_t order_refused = count("accepted_reclamation_refused_phase_order");
    const std::size_t prefix_refused = count("accepted_reclamation_refused_prefix_gap");
    const std::size_t fail_stopped = count("accepted_equivocation_fail_stop") + count("accepted_regression_fail_stop");
    const std::size_t rejected = tests.size() - accepted;

    std::ostringstream summary;
    summary << "{\n"
        << "  \"accepted_cases\": " << accepted << ",\n"
        << "  \"authority_granted\": false,\n"
        << "  \"candidate_reference_disagreements\": " << disagreements << ",\n"
        << "  \"cases\": " << tests.size() << ",\n"
        << "  \"chain_complete_cases\": " << complete << ",\n"
        << "  \"chain_ready_live_retained_cases\": " << ready << ",\n"
        << "  \"chain_prefix_live_retained_cases\": " << prefix << ",\n"
        << "  \"crash_cuts\": " << tests.size() * chain_cut_count << ",\n"
        << "  \"epoch_exit_proved\": false,\n"
        << "  \"exact_predecessor_refused_cases\": " << exact_refused << ",\n"
        << "  \"external_occurrence_proved\": false,\n"
        << "  \"fail_stopped_cases\": " << fail_stopped << ",\n"
        << "  \"independent_custody_proved\": false,\n"
        << "  \"mere_prior_visibility_sufficient_cases\": 0,\n"
        << "  \"phase_order_refused_cases\": " << order_refused << ",\n"
        << "  \"prefix_gap_refused_cases\": " << prefix_refused << ",\n"
        << "  \"publication_refused_cases\": " << publication_refused << ",\n"
        << "  \"reclamation_safe_cases\": " << complete << ",\n"
        << "  \"rejected_cases\": " << rejected << ",\n"
        << "  \"schema\": \"slopos.rev0919.exact-predecessor-consumption-campaign.v1\"\n"
        << "}\n";

    const std::string phases =
        "slot\tphase\trequired_predecessor\tstrict_cut_rule\n"
        "0\twitness_publication\tnone\tpublished before join\n"
        "1\tfloor_publication\tnone\tpublished before join\n"
        "2\tjoin_publication\texact witness receipt + exact floor receipt\tlater than both components\n"
        "3\tcold_reopen_receipt\texact join receipt\tlater than join publication\n"
        "4\tdeletion_authorization\texact cold-reopen receipt\tlater than cold reopen\n"
        "5\tdeletion_effect\texact authorization digest\tlater than authorization publication\n";
    const std::string countertraces =
        "row\ttrace\told_boolean_model\texact_predecessor_model\tjudgment\n"
        "V0\tprior_witness_boolean\tseen=true\treceipt digest absent\tvisibility is not consumption\n"
        "V1\tstale_join_input\tseen=true\tjoin predecessor differs\treclamation refused\n"
        "V2\tsame_cut_join\tcomponents=true\tpublication not strictly earlier\treclamation refused\n"
        "V3\tin_memory_reopen\treopen=true\treopen receipt not durable\treclamation refused\n"
        "V4\twrong_authorization\tauthorized=true\tconsumed reopen digest differs\treclamation refused\n"
        "V5\tfinal_safe_shape\tall booleans=true\tprior prefix contained a gap\teventual conjunction insufficient\n";
    const std::string invariants =
        "PRIOR_VISIBILITY_IS_NOT_EXACT_CONSUMPTION=true\n"
        "EVERY_CONSUMER_BINDS_EXACT_PREDECESSOR_DIGEST=true\n"
        "JOIN_BINDS_EXACT_WITNESS_AND_FLOOR_RECEIPTS=true\n"
        "PUBLICATION_PRECEDES_CONSUMPTION_AT_A_STRICT_CUT=true\n"
        "VISIBLE_BUT_UNPUBLISHED_IS_INSUFFICIENT=true\n"
        "DURABLE_BUT_WRONG_PREDECESSOR_IS_INSUFFICIENT=true\n"
        "EXACT_PREDECESSOR_WITHOUT_PARENT_PREFIX_COVERAGE_IS_INSUFFICIENT=true\n"
        "RECEIPT_VISIBILITY_IS_MONOTONE_OR_FAIL_STOP=true\n"
        "DELETION_CONSUMES_EXACT_AUTHORIZATION_DIGEST=true\n"
        "MERE_PRIOR_VISIBILITY_SUFFICIENT=false\n"
        "EXTERNAL_OCCURRENCE_PROVED=false\n"
        "AUTHORITY_GRANTED=false\n";

    return write_text(output_directory / "CASES.tsv", cases_tsv)
        && write_text(output_directory / "CUTS.tsv", cuts_tsv)
        && write_text(output_directory / "RECEIPTS.tsv", receipts_tsv)
        && write_text(output_directory / "SUMMARY.json", summary.str())
        && write_text(output_directory / "PHASES.tsv", phases)
        && write_text(output_directory / "COUNTERTRACES.tsv", countertraces)
        && write_text(output_directory / "INVARIANTS.txt", invariants);
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::exact_predecessor_consumption
