# Control-Fate Falsification V1

## Status

Epoch-Zero child relation. This module is a strict refinement of one **accepted, dossier-ready, live-record-retained** External Premise Admission trace. It is not a provider implementation, owner registry, IAM inventory service, recovery orchestrator, publisher, challenger, or authority API.

## Defects under test

The parent relation can require pairwise-distinct administrative and rollback leaf digests while remaining unable to represent a shared upstream identity tenant, deployment controller, recovery escrow, snapshot authority, backup controller, storage root, view router, or cloud control plane. Pairwise leaf inequality therefore does not decide transitive failure-domain separation.

The first hosted draft also accepted arbitrary nonzero values in `graph_digest`, `publication_receipt_digest`, and `challenge_receipt_digest`. Those labels did not bind the exact node, edge, role-binding, scope, omitted-edge policy, or lifecycle proposition. V1 now derives and independently reopens all three digests.

## Typed packet

The externally supplied `ControlGraphCapsule` contains:

- exact parent separation and mechanism-annex digests;
- exact source-closure, inventory-scope, and omitted-edge-policy digests;
- at most 24 typed nodes and 48 typed controller-to-controlled edges;
- exactly six ordered role bindings, each with administrative, rollback, and view leaves;
- an explicit complete-inventory claim and representation flags;
- no-replace publication and independent-challenge receipt digests; and
- four object-bearing cuts: assembled, published, reopened, challenged.

The six roles are mechanism operator, corpus producer, transparency witness, independent reopener, appraiser, and owner admitter. Administrative, rollback, and shared-view control are independent capability dimensions.

## Exact binding profile

The graph digest is SHA-256 over one bounded preimage with a 32-byte `SlopOS/cff/graph/v2` domain followed, in fixed order, by parent and annex identities, source closure, scope, omitted-edge policy, counts, claim flags, then exactly the counted nodes, edges, and ordered role bindings. Unused fixed-array tails must be default-zero; hidden data beyond a count is structural rejection.

The publication receipt uses a distinct `SlopOS/cff/publish/v1` domain and binds the graph digest, source closure, scope, omitted-edge policy, and the durable/no-replace/single-view proposition. The challenge receipt uses `SlopOS/cff/challenge/v1` and binds the graph digest, publication receipt, source closure, scope, omitted-edge policy, and the reopen/challenge proposition. Neither receipt proves that the named external event occurred; it only makes subject substitution detectable.

## Required conflict pairs

The supplied closure is searched for common administrative and rollback fate between:

1. mechanism operator and appraiser;
2. corpus producer and appraiser;
3. mechanism operator and owner admitter;
4. independent reopener and mechanism operator;
5. appraiser and owner admitter; and
6. transparency witness and owner admitter.

The final pair is also checked for common shared-view fate.

## Judgment discipline

A discovered common upstream controller **refutes** the affected separation claim. Absence of a witness is reported only as `no_common_fate_found_in_supplied_closure`. It does not prove graph completeness, real-world independence, source truth, external occurrence, currentness, independent custody, operation, epoch exit, or authority.

The falsifier is monotone with respect to edge addition: once a supplied graph contains a refuting common-control path, adding facts cannot make that witness disappear. The converse is unavailable: omitting an edge can make a non-independent world look separated.

## Repository boundary

The implementation is a deterministic C++20 value relation, a structurally independent reference evaluator, a 97-case/388-cut campaign, complete canonical-binding vectors, and read-only proof tooling. The live terminal record is retained in every accepted case. No deletion, provider, signer, credential, endpoint, database, lease, retry, backup, recovery, IAM, transparency-log, or control-plane runtime is admitted.
