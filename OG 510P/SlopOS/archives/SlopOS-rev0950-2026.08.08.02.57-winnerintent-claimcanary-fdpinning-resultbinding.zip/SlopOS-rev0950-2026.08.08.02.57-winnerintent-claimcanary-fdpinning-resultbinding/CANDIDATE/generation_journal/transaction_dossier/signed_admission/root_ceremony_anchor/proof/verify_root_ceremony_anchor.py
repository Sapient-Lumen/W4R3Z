#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path

ANCHOR_BYTES = 512
STATEMENT_BYTES = 320


def fail(detail: str) -> None:
    raise SystemExit(f"ROOT_CEREMONY_ANCHOR_PY=FAIL detail={detail}")


def domain_hash(domain: str, payload: bytes) -> bytes:
    return hashlib.sha256(domain.encode("utf-8") + b"\x00" + payload).digest()


def u16(data: bytes, offset: int) -> int:
    return int.from_bytes(data[offset : offset + 2], "big")


def u32(data: bytes, offset: int) -> int:
    return int.from_bytes(data[offset : offset + 4], "big")


def u64(data: bytes, offset: int) -> int:
    return int.from_bytes(data[offset : offset + 8], "big")


def digest(data: bytes, offset: int) -> bytes:
    return data[offset : offset + 32]


def parse_anchor(data: bytes) -> dict[str, bytes | int]:
    if len(data) != ANCHOR_BYTES:
        fail(f"anchor length={len(data)}")
    if data[:8] != b"SLOPCA01" or u16(data, 8) != 1 or u16(data, 10) != 7:
        fail("anchor framing")
    if u32(data, 12) != ANCHOR_BYTES or any(data[416:480]):
        fail("anchor length/reserved")
    expected_integrity = domain_hash(
        "SlopOS/root-ceremony-anchor/integrity/v1", data[:480]
    )
    if data[480:] != expected_integrity:
        fail("anchor integrity")
    names = (
        "project_id",
        "register_id",
        "register_incarnation",
        "predecessor_manifest_head",
        "successor_manifest_head",
        "rc0_starting_root_receipt_head",
        "rc1_precommit_receipt_head",
        "precommit_operation_id",
        "policy_head",
        "transition_digest",
        "request_id",
    )
    value: dict[str, bytes | int] = {
        name: digest(data, 16 + 32 * index) for index, name in enumerate(names)
    }
    value.update(
        predecessor_version=u64(data, 368),
        successor_version=u64(data, 376),
        precommit_recorded_at=u64(data, 384),
        signing_not_before=u64(data, 392),
        expires_at=u64(data, 400),
        request_deadline=u64(data, 408),
    )
    for name in names[:9]:
        if value[name] == bytes(32):
            fail(f"zero anchor identity={name}")
    if value["rc0_starting_root_receipt_head"] == value["rc1_precommit_receipt_head"]:
        fail("receipt collision")
    predecessor = int(value["predecessor_version"])
    successor = int(value["successor_version"])
    if predecessor == (1 << 64) - 1 or successor != predecessor + 1:
        fail("version adjacency")
    transition_payload = b"".join(bytes(value[name]) for name in names[:9]) + (
        predecessor.to_bytes(8, "big") + successor.to_bytes(8, "big")
    )
    expected_transition = domain_hash(
        "SlopOS/root-ceremony-anchor/transition/v1", transition_payload
    )
    if value["transition_digest"] != expected_transition:
        fail("transition digest")
    request_payload = (
        expected_transition
        + bytes(value["register_id"])
        + bytes(value["register_incarnation"])
        + bytes(value["precommit_operation_id"])
    )
    expected_request = domain_hash(
        "SlopOS/root-ceremony-anchor/request/v1", request_payload
    )
    if value["request_id"] != expected_request:
        fail("request id")
    if not int(value["precommit_recorded_at"]) < int(value["signing_not_before"]):
        fail("precommit chronology")
    if not (
        int(value["signing_not_before"]) < int(value["expires_at"])
        and int(value["signing_not_before"])
        <= int(value["request_deadline"])
        <= int(value["expires_at"])
    ):
        fail("anchor time window")
    return value


def parse_statement(data: bytes) -> dict[str, bytes | int]:
    if len(data) != STATEMENT_BYTES:
        fail(f"statement length={len(data)}")
    if data[:8] != b"SLOPRS01" or u16(data, 8) != 1 or u16(data, 10) != 4:
        fail("statement framing")
    if u32(data, 12) != STATEMENT_BYTES or data[16] != 1 or data[17] != 1:
        fail("statement length/purpose/suite")
    if any(data[18:32]) or any(data[264:288]):
        fail("statement reserved")
    expected_integrity = domain_hash(
        "SlopOS/root-succession/statement-integrity/v1", data[:288]
    )
    if data[288:] != expected_integrity:
        fail("statement integrity")
    names = (
        "project_id",
        "predecessor_manifest_head",
        "successor_manifest_head",
        "precommitted_successor_head",
        "register_id",
        "ceremony_id",
    )
    value: dict[str, bytes | int] = {
        name: digest(data, 32 + 32 * index) for index, name in enumerate(names)
    }
    value.update(
        predecessor_version=u64(data, 224),
        successor_version=u64(data, 232),
        not_before=u64(data, 240),
        expires_at=u64(data, 248),
        transition_nonce=u64(data, 256),
    )
    return value


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    root = args.output
    summary = json.loads((root / "SUMMARY.json").read_text(encoding="utf-8"))
    expected_summary = {
        "status": "PASS",
        "anchor_bytes": ANCHOR_BYTES,
        "root_statement_bytes": STATEMENT_BYTES,
        "cases": 46,
        "valid_cases": 3,
        "rejected_cases": 43,
        "candidate_reference_disagreements": 0,
        "rc0_receipt_bound": True,
        "rc1_receipt_bound": True,
        "register_incarnation_bound": True,
        "strict_precommit_before_signing": True,
        "deterministic_request_id": True,
        "external_receipt_authenticity_proved": False,
        "currentness_proved": False,
        "epoch_exit_proved": False,
        "authority_granted": False,
    }
    for key, expected in expected_summary.items():
        if summary.get(key) != expected:
            fail(f"summary.{key}={summary.get(key)!r}")

    with (root / "CASES.tsv").open(newline="", encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream, delimiter="\t"))
    if len(rows) != 46:
        fail(f"case rows={len(rows)}")
    for index, row in enumerate(rows, 1):
        if int(row["index"]) != index:
            fail(f"case index={row['index']}")
        if not (
            row["expected"] == row["candidate"] == row["reference"]
            and row["candidate_valid"] == row["reference_valid"]
            and row["agreement"] == "true"
            and row["authority"] == "false"
        ):
            fail(f"case disagreement={row['case']}")
    if sum(row["candidate_valid"] == "true" for row in rows) != 3:
        fail("valid row count")

    anchor_bytes = (root / "fixtures" / "valid.anchor.bin").read_bytes()
    statement_bytes = (root / "fixtures" / "valid.root-statement.bin").read_bytes()
    anchor = parse_anchor(anchor_bytes)
    statement = parse_statement(statement_bytes)

    cross = {
        "project_id": "project_id",
        "register_id": "register_id",
        "predecessor_manifest_head": "predecessor_manifest_head",
        "successor_manifest_head": "successor_manifest_head",
        "predecessor_version": "predecessor_version",
        "successor_version": "successor_version",
        "signing_not_before": "not_before",
        "expires_at": "expires_at",
    }
    for anchor_name, statement_name in cross.items():
        if anchor[anchor_name] != statement[statement_name]:
            fail(f"cross binding={anchor_name}")
    if statement["precommitted_successor_head"] != anchor["successor_manifest_head"]:
        fail("statement precommit")
    expected_head = domain_hash(
        "SlopOS/root-ceremony-anchor/head/v1", anchor_bytes
    )
    if statement["ceremony_id"] != expected_head:
        fail("ceremony head binding")
    expected_nonce = int.from_bytes(bytes(anchor["request_id"])[:8], "big")
    if statement["transition_nonce"] != expected_nonce:
        fail("request nonce binding")

    fixtures = root / "fixtures"
    text_checks = {
        "valid.anchor.hex": anchor_bytes.hex(),
        "valid.root-statement.hex": statement_bytes.hex(),
        "valid.anchor-head.txt": expected_head.hex(),
        "valid.transition-digest.txt": bytes(anchor["transition_digest"]).hex(),
        "valid.request-id.txt": bytes(anchor["request_id"]).hex(),
    }
    for name, expected in text_checks.items():
        actual = (fixtures / name).read_text(encoding="ascii").strip()
        if actual != expected:
            fail(f"fixture text={name}")

    print(
        "ROOT_CEREMONY_ANCHOR_PY=PASS cases=46 valid=3 rejected=43 "
        "anchor_bytes=512 statement_bytes=320 chronology=bound_observation "
        "incarnation=bound request_id=deterministic authenticity=false "
        "currentness=false epoch_exit=false authority=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
