#pragma once

#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/exact_predecessor_consumption.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <string_view>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain {

inline constexpr std::size_t receipt_cut_count = 9U;

enum class ReceiptChainCode : std::uint8_t {
    accepted_chain_complete,
    accepted_chain_ready_live_retained,
    accepted_live_basis_retained,
    accepted_reclamation_refused_source_closure_gap,
    accepted_reclamation_refused_publication_gap,
    accepted_reclamation_refused_receipt_reopen_gap,
    accepted_reclamation_refused_authorization_gap,
    accepted_reclamation_refused_authorization_reopen_gap,
    accepted_reclamation_refused_order_gap,
    accepted_unauthorized_deletion_fail_stop,
    accepted_deletion_receipt_gap_fail_stop,
    accepted_equivocation_fail_stop,
    accepted_regression_fail_stop,
    exact_predecessor_rejected,
    exact_predecessor_not_ready,
    exact_join_receipt_digest_mismatch,
    exact_reopen_receipt_digest_mismatch,
    exact_authorization_receipt_digest_mismatch,
    join_digest_zero,
    target_digest_zero,
    owner_policy_digest_zero,
    retention_policy_digest_zero,
    reclamation_request_mismatch,
    source_shape_invalid,
    source_cutover_id_mismatch,
    source_join_digest_mismatch,
    source_witness_digest_mismatch,
    source_floor_digest_mismatch,
    source_request_id_mismatch,
    source_transition_digest_mismatch,
    source_register_incarnation_mismatch,
    source_terminal_digest_mismatch,
    source_terminal_kind_mismatch,
    reopen_shape_invalid,
    reopen_closure_digest_mismatch,
    reopen_cutover_id_mismatch,
    reopen_join_digest_mismatch,
    reopen_witness_digest_mismatch,
    reopen_floor_digest_mismatch,
    reopen_request_id_mismatch,
    reopen_transition_digest_mismatch,
    reopen_register_incarnation_mismatch,
    reopen_terminal_digest_mismatch,
    reopen_terminal_kind_mismatch,
    reopen_reopener_incarnation_mismatch,
    reopen_verifier_id_mismatch,
    reopen_policy_digest_mismatch,
    authorization_shape_invalid,
    authorization_receipt_digest_mismatch,
    authorization_cutover_id_mismatch,
    authorization_target_digest_mismatch,
    authorization_owner_policy_mismatch,
    authorization_retention_policy_mismatch,
    deletion_shape_invalid,
    deletion_authorization_digest_mismatch,
    deletion_cutover_id_mismatch,
    deletion_target_digest_mismatch,
    trace_initial_state_invalid,
    trace_deleted_and_live,
    trace_live_absent_without_deletion,
};

struct SourceClosure final {
    Digest closure_digest{};
    Digest cutover_id{};
    Digest join_digest{};
    Digest witness_digest{};
    Digest floor_digest{};
    Digest request_id{};
    Digest transition_digest{};
    Digest register_incarnation{};
    Digest terminal_digest{};
    Digest reopener_incarnation{};
    Digest verifier_id{};
    Digest verifier_policy_digest{};
    TerminalKind terminal_kind{TerminalKind::effect};
    bool present{false};
    bool canonical{false};
    bool complete{false};
    bool independently_locatable{false};
    bool rollback_external{false};
    bool replacement_only{false};
    bool no_hidden_inputs{false};
    bool includes_live_terminal_record{false};

    [[nodiscard]] friend constexpr bool operator==(const SourceClosure&, const SourceClosure&) noexcept = default;
};

struct ReopenReceipt final {
    Digest receipt_digest{};
    Digest closure_digest{};
    Digest cutover_id{};
    Digest join_digest{};
    Digest witness_digest{};
    Digest floor_digest{};
    Digest request_id{};
    Digest transition_digest{};
    Digest register_incarnation{};
    Digest terminal_digest{};
    Digest reopener_incarnation{};
    Digest verifier_id{};
    Digest verifier_policy_digest{};
    TerminalKind terminal_kind{TerminalKind::effect};
    bool present{false};
    bool computed_from_closure{false};
    bool exact_result{false};
    bool authenticated{false};
    bool no_replace_published{false};
    bool durable{false};
    bool directory_entry_durable{false};
    bool single_view{false};
    bool independently_reopenable{false};

    [[nodiscard]] friend constexpr bool operator==(const ReopenReceipt&, const ReopenReceipt&) noexcept = default;
};

struct AuthorizationCapsule final {
    Digest authorization_digest{};
    Digest reopen_receipt_digest{};
    Digest cutover_id{};
    Digest target_digest{};
    Digest owner_policy_digest{};
    Digest retention_policy_digest{};
    bool present{false};
    bool authenticated{false};
    bool durable{false};
    bool no_replace_published{false};
    bool single_view{false};
    bool separately_governed{false};
    bool independently_reopenable{false};

    [[nodiscard]] friend constexpr bool operator==(const AuthorizationCapsule&, const AuthorizationCapsule&) noexcept = default;
};

struct DeletionReceipt final {
    Digest deletion_receipt_digest{};
    Digest authorization_digest{};
    Digest cutover_id{};
    Digest target_digest{};
    bool present{false};
    bool authenticated{false};
    bool durable{false};
    bool no_replace_published{false};
    bool single_view{false};
    bool target_absence_observed{false};

    [[nodiscard]] friend constexpr bool operator==(const DeletionReceipt&, const DeletionReceipt&) noexcept = default;
};

struct ReceiptCut final {
    bool live_record_visible{false};
    bool replacement_visible{false};
    bool reopener_started{false};
    bool reconstruction_computed{false};
    bool reopen_receipt_visible{false};
    bool reopen_receipt_reopened{false};
    bool authorization_visible{false};
    bool authorization_reopened{false};
    bool record_deleted{false};
    bool deletion_receipt_visible{false};

    [[nodiscard]] friend constexpr bool operator==(const ReceiptCut&, const ReceiptCut&) noexcept = default;
};

struct ReceiptChainTrace final {
    exact_predecessor_consumption::ChainTrace predecessor{};
    Digest join_digest{};
    Digest target_digest{};
    Digest owner_policy_digest{};
    Digest retention_policy_digest{};
    SourceClosure source{};
    ReopenReceipt reopen{};
    AuthorizationCapsule authorization{};
    DeletionReceipt deletion{};
    std::array<ReceiptCut, receipt_cut_count> cuts{};
    bool reclamation_requested{false};
    bool equivocation_observed{false};

    [[nodiscard]] friend constexpr bool operator==(const ReceiptChainTrace&, const ReceiptChainTrace&) noexcept = default;
};

struct ReceiptChainReport final {
    ReceiptChainCode code{ReceiptChainCode::exact_predecessor_rejected};
    bool accepted{false};
    bool exact_predecessor_accepted{false};
    bool exact_predecessor_deletion_safe{false};
    bool exact_predecessor_ready{false};
    bool source_closure_valid{false};
    bool reopen_receipt_core_valid{false};
    bool reopen_receipt_reopen_valid{false};
    bool authorization_core_valid{false};
    bool authorization_reopen_valid{false};
    bool deletion_receipt_valid{false};
    bool all_cuts_ordered{false};
    bool source_gap_observed{false};
    bool publication_gap_observed{false};
    bool receipt_reopen_gap_observed{false};
    bool authorization_gap_observed{false};
    bool authorization_reopen_gap_observed{false};
    bool deletion_receipt_gap_observed{false};
    bool phase_order_gap_observed{false};
    bool regression_observed{false};
    bool reclamation_ready{false};
    bool reclamation_complete{false};
    bool unauthorized_deletion{false};
    bool fail_stopped{false};
    bool eventual_repair_sufficient{false};
    bool external_occurrence_proved{false};
    bool currentness_proved{false};
    bool independent_custody_proved{false};
    bool epoch_exit_proved{false};
    bool authority_granted{false};

    [[nodiscard]] friend constexpr bool operator==(const ReceiptChainReport&, const ReceiptChainReport&) noexcept = default;
};

[[nodiscard]] ReceiptChainReport evaluate_candidate(const ReceiptChainTrace& trace) noexcept;
[[nodiscard]] ReceiptChainReport evaluate_reference(const ReceiptChainTrace& trace) noexcept;
[[nodiscard]] std::string_view receipt_chain_code_name(ReceiptChainCode value) noexcept;
[[nodiscard]] std::string_view receipt_cut_name(std::size_t index) noexcept;
[[nodiscard]] bool run_campaign(const std::filesystem::path& output_directory);

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain
