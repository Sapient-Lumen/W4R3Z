#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import sys
from pathlib import Path


def fail(detail: str) -> None:
    raise SystemExit(f"REOPEN_RECEIPT_CHAIN_PY=FAIL detail={detail}")


def rows(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def main() -> int:
    if len(sys.argv) != 2:
        fail("usage")
    root = Path(sys.argv[1]).resolve()
    required = {"CASES.tsv", "CUTS.tsv", "SUMMARY.json", "PHASES.tsv", "COUNTERTRACES.tsv", "INVARIANTS.txt"}
    if not root.is_dir() or {p.name for p in root.iterdir()} != required:
        fail("canonical file set")
    summary = json.loads((root / "SUMMARY.json").read_text(encoding="utf-8"))
    cases = rows(root / "CASES.tsv")
    cuts = rows(root / "CUTS.tsv")
    phases = rows(root / "PHASES.tsv")
    counter = rows(root / "COUNTERTRACES.tsv")
    if summary.get("status") != "PASS" or summary.get("schema") != "slopos.rev0919.reopen-receipt-chain-campaign.v1":
        fail("summary identity")
    if len(cases) != summary["cases"] or len(cuts) != summary["crash_cuts"] or len(cuts) != len(cases) * 9:
        fail("cardinality")
    if len(phases) != 9 or len(counter) != 9:
        fail("phase/countertrace cardinality")
    names = [row["case"] for row in cases]
    if len(names) != len(set(names)):
        fail("duplicate case")
    if any(row["expected"] != row["candidate"] or row["candidate"] != row["reference"] or row["agreement"] != "true" for row in cases):
        fail("differential disagreement")
    if sum(row["accepted"] == "true" for row in cases) != summary["accepted_cases"]:
        fail("accepted projection")
    if sum(row["complete"] == "true" for row in cases) != summary["chain_complete_cases"]:
        fail("complete projection")
    if sum(row["ready"] == "true" for row in cases) != summary["chain_ready_live_retained_cases"]:
        fail("ready projection")
    if sum(row["fail_stop"] == "true" for row in cases) != summary["fail_stopped_cases"]:
        fail("fail-stop projection")
    if summary.get("already_deleted_predecessor_rejections") != 1 or summary.get("total_composition_rejections") != 4:
        fail("temporal composition projection")
    if any(row[k] != "false" for row in cases for k in ("eventual_repair_sufficient", "external_occurrence", "currentness", "custody", "authority")):
        fail("mandatory nonclaims")
    by_case: dict[str, list[dict[str, str]]] = {}
    for row in cuts:
        by_case.setdefault(row["case"], []).append(row)
    if set(by_case) != set(names):
        fail("cut identity")
    expected_cut_names = [
        "R0_live_joined", "R1_reopener_start", "R2_reconstruction", "R3_receipt_publish",
        "R4_receipt_reopen", "R5_authorization_publish", "R6_authorization_reopen",
        "R7_delete", "R8_deletion_receipt",
    ]
    for name, trace in by_case.items():
        if [int(row["cut"]) for row in trace] != list(range(9)) or [row["name"] for row in trace] != expected_cut_names:
            fail(f"cut order={name}")
        if trace[0]["live_record"] != "true" and name not in {"reject_trace_initial"}:
            fail(f"initial live={name}")
    required_cases = {
        "complete_effect_exact",
        "ready_live_retained_1",
        "refused_source_live_record_contamination",
        "refused_publication_directory_not_durable",
        "refused_receipt_never_reopened",
        "refused_authorization_same_administration",
        "refused_order_authorize_same_cut_as_receipt_reopen",
        "fail_stop_deleted_without_durable_reopen_receipt",
        "fail_stop_deletion_receipt_without_absence_observation",
        "fail_stop_regression_live_record_resurrection",
        "reject_authorization_target_mismatch",
        "reject_deletion_target_mismatch",
        "reject_exact_join_receipt_composition_mismatch",
        "reject_exact_reopen_receipt_composition_mismatch",
        "reject_exact_authorization_receipt_composition_mismatch",
        "reject_already_deleted_exact_predecessor",
    }
    if not required_cases <= set(names):
        fail(f"missing={sorted(required_cases - set(names))}")
    print(
        "REOPEN_RECEIPT_CHAIN_PY=PASS "
        f"cases={len(cases)} accepted={summary['accepted_cases']} rejected={summary['rejected_cases']} "
        f"cuts={len(cuts)} complete={summary['chain_complete_cases']} "
        f"ready={summary['chain_ready_live_retained_cases']} refused={summary['reclamation_refused_cases']} "
        f"fail_stop={summary['fail_stopped_cases']} authority=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
