# Detached Response Intake Aperture V1

This package is a strict child of Hosted Externality Nonderivation. It consumes
one exact owner-handoff-ready parent trace and introduces seven durable local
prefixes: parent request, laboratory response, modeled publication, modeled
reopen, separately supplied laboratory trust configurations, appraisal witness,
and a consumption-currentness deficit.

The construction is intentionally not an owner simulator. The response, signer,
trust configurations, timestamps, publication, and reopen are laboratory
fixtures. A valid Ed25519 signature establishes integrity under the response's
key; the separately supplied configuration decides whether that key is trusted
for one policy, target, root, version, and evaluation time. A later root version
invalidates reuse of the prior appraisal for consumption.

No external response, external trust provisioning, independent administration,
owner admission, authority, or Epoch-Zero exit is claimed.
