# Reopen Receipt Chain V1

## Question

What must exist between a successful replacement-only reconstruction and irreversible deletion of the complete live terminal record?

## Exact objects

1. **Source closure** — binds cutover, same-history join, witness, successor floor, request, transition, register incarnation, terminal outcome, reopener incarnation, verifier identity, and verifier-policy digest. It is canonical, complete, independently locatable, rollback-external, free of hidden inputs, and explicitly excludes the live terminal record.
2. **Reopen receipt** — binds the exact source closure and reconstructed terminal outcome. It is authenticated, no-replace published, durably reachable including its namespace entry, single-view, and independently reopenable.
3. **Authorization capsule** — binds the exact reopen-receipt digest, owner policy, retention policy, cutover, and exact destructive target. It is separately governed, durably no-replace published, single-view, and independently reopenable.
4. **Deletion receipt** — binds the authorization, cutover, and exact target and records independently observed target absence after deletion.

## Refinement boundary

The input contains one `ExactPredecessorConsumption::ChainTrace`, not a parallel proof-basis summary. The child proceeds only when that exact trace is `accepted_chain_ready_live_retained`: every predecessor receipt is durably visible, but the complete live terminal record has not been deleted. An exact-predecessor trace that is already complete and deletion-safe is rejected because its live bridge cannot coherently reappear at child cut `R0`.

The child is a crash-cut refinement of that same still-live history, not a second transaction appended after an already completed parent. Its `join_digest`, `reopen.receipt_digest`, and `authorization.authorization_digest` must equal the join-publication, cold-reopen-receipt, and deletion-authorization record digests in the embedded trace. Substituting a valid sibling receipt from another trace is a structural rejection even when every local receipt-chain field is internally consistent.

## Nine crash cuts

`R0` live bridge and joined replacement; `R1` reopener start; `R2` reconstruction; `R3` receipt publication; `R4` independent receipt reopen; `R5` authorization publication; `R6` independent authorization reopen; `R7` deletion; `R8` deletion receipt.

A phase first becoming true at cut `Ri` may consume only predecessors latched before `Ri`. The model imports no hidden transaction capable of collapsing adjacent phases. Parent receipt identities are projections of this same history; parent deletion is absent throughout the accepted input prefix.

## Decision classes

- complete child chain extending a still-live exact-predecessor prefix;
- chain ready while live record remains;
- live basis retained;
- refusal for source, publication, receipt-reopen, authorization, authorization-reopen, or order gaps;
- fail-stop for unauthorized deletion, deletion-receipt failure after deletion, equivocation, or regression;
- structural rejection for malformed or mismatched objects, an already-deleted predecessor, or a child that substitutes join, reopen, or authorization identities from outside its accepted exact-predecessor trace.

## Nonclaims

The relation does not claim that bytes came from a real independent reopener, that authentication roots are owner-current, that storage honored sync requests, that the target was externally deleted, or that any authority exists. Those are owner-operated premises.
