#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/reopen_receipt_chain/external_premise_admission.hpp"

#include <algorithm>
#include <array>
#include <cstdint>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission {
namespace {

namespace parent_model = ::slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain;
namespace predecessor_model = ::slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::exact_predecessor_consumption;

[[nodiscard]] bool populated(const Digest& digest) noexcept {
    return std::find_if(digest.begin(), digest.end(), [](const std::uint8_t octet) {
        return octet != 0U;
    }) != digest.end();
}

[[nodiscard]] bool unique_nonzero(const Digest& a, const Digest& b, const Digest& c, const Digest& d) noexcept {
    return populated(a) && populated(b) && populated(c) && populated(d)
        && a != b && a != c && a != d && b != c && b != d && c != d;
}

[[nodiscard]] std::uint32_t encode(const AdmissionCut& cut) noexcept {
    std::uint32_t bits = 0U;
    const auto place = [&bits](const bool value, const std::uint32_t bit) {
        if (value) bits |= (std::uint32_t{1} << bit);
    };
    place(cut.owner_constitution_visible, 0U);
    place(cut.annex_closed, 1U);
    place(cut.ratification_visible, 2U);
    place(cut.ratification_reopened, 3U);
    place(cut.corpus_started, 4U);
    place(cut.corpus_complete, 5U);
    place(cut.appraisal_visible, 6U);
    place(cut.appraisal_reopened, 7U);
    place(cut.owner_admission_visible, 8U);
    place(cut.owner_admission_reopened, 9U);
    place(cut.record_deleted, 10U);
    return bits;
}

[[nodiscard]] bool prefix_closed(const std::uint32_t bits) noexcept {
    const std::uint32_t chronology = bits & 0x03FFU;
    if (chronology == 0U) return false;
    return (chronology & (chronology + 1U)) == 0U;
}

struct Timeline final {
    bool order{true};
    bool phase_hole{false};
    bool backwards{false};
    bool deletion{false};
};

[[nodiscard]] Timeline project_timeline(const AdmissionTrace& trace) noexcept {
    Timeline result{};
    std::uint32_t previous = encode(trace.cuts.front());
    for (const AdmissionCut& cut : trace.cuts) {
        const std::uint32_t now = encode(cut);
        const std::uint32_t chronology = now & 0x03FFU;
        if (!prefix_closed(now)) result.phase_hole = true;
        if ((previous & ~now) != 0U) result.backwards = true;
        const std::uint32_t additions = (now & ~previous) & 0x03FFU;
        if (additions != 0U && (additions & (additions - 1U)) != 0U) result.phase_hole = true;
        if ((now & 0x0400U) != 0U) result.deletion = true;
        previous = now;
        (void)chronology;
    }
    result.order = !result.phase_hole && !result.backwards;
    return result;
}

[[nodiscard]] AdmissionReport refusal(
    const AdmissionCode reason,
    const bool parent_ok = false,
    const bool parent_ready = false) noexcept {
    AdmissionReport output{};
    output.code = reason;
    output.parent_accepted = parent_ok;
    output.parent_ready_live_retained = parent_ready;
    return output;
}

[[nodiscard]] bool empty_constitution(const OwnerConstitution& value) noexcept {
    return !populated(value.constitution_digest) && !populated(value.project_id)
        && !populated(value.owner_root_digest) && !populated(value.constitution_policy_digest)
        && !populated(value.bootstrap_method_digest) && !value.canonical && !value.authenticated
        && !value.threshold_satisfied && !value.out_of_band_bootstrapped
        && !value.current_root_selected && !value.rollback_external && !value.durable
        && !value.single_view && !value.independently_reopenable && !value.self_nominated;
}

[[nodiscard]] bool empty_annex(const MechanismAnnex& value) noexcept {
    return !populated(value.annex_digest) && !populated(value.project_id)
        && !populated(value.owner_constitution_digest) && !populated(value.owner_root_digest)
        && !populated(value.parent_authorization_digest) && !populated(value.target_digest)
        && !populated(value.profile_id) && !populated(value.role_matrix_digest)
        && !populated(value.failure_corpus_spec_digest) && !populated(value.implementation_digest)
        && !populated(value.configuration_digest) && value.requirement_mask == 0U
        && !value.canonical && !value.complete && !value.no_hidden_inputs
        && !value.exact_mechanism_selected && !value.bootstrap_method_declared
        && !value.collision_fail_closed && !value.non_equivocation_witness_required
        && !value.self_ratifying;
}

[[nodiscard]] bool empty_ratification(const RatificationReceipt& value) noexcept {
    return !populated(value.ratification_digest) && !populated(value.annex_digest)
        && !populated(value.owner_constitution_digest) && !populated(value.owner_root_digest)
        && !populated(value.ratification_policy_digest) && !value.authenticated
        && !value.threshold_satisfied && !value.owner_issued && !value.durable
        && !value.no_replace_published && !value.single_view
        && !value.independently_reopenable && !value.current_root_observed
        && !value.self_issued_by_annex;
}

[[nodiscard]] bool empty_separation(const RoleSeparation& value) noexcept {
    return !populated(value.separation_digest) && !populated(value.annex_digest)
        && !populated(value.reopener_admin_digest) && !populated(value.authorizer_admin_digest)
        && !populated(value.appraiser_admin_digest) && !populated(value.mechanism_admin_digest)
        && !populated(value.reopener_rollback_digest) && !populated(value.authorizer_rollback_digest)
        && !populated(value.appraiser_rollback_digest) && !populated(value.mechanism_rollback_digest)
        && !value.owner_ratified && !value.distinct_administrative_roots
        && !value.distinct_rollback_roots && !value.distinct_credentials
        && !value.recovery_roots_separate && !value.appraiser_can_reopen_without_operator
        && !value.collusion_model_declared && !value.same_process_only;
}

[[nodiscard]] bool empty_corpus(const OperatedCorpus& value) noexcept {
    return !populated(value.corpus_digest) && !populated(value.annex_digest)
        && !populated(value.failure_corpus_spec_digest) && !populated(value.implementation_digest)
        && !populated(value.configuration_digest) && !populated(value.disposable_target_digest)
        && value.observed_scenario_mask == 0U && !value.canonical && !value.complete
        && !value.actual_not_synthetic && !value.exact_binaries && !value.exact_configuration
        && !value.raw_traces_retained && !value.independently_locatable && !value.replayable
        && !value.expected_outcomes_checked && !value.disposable_target_separate;
}

[[nodiscard]] bool empty_appraisal(const AppraisalReceipt& value) noexcept {
    return !populated(value.appraisal_digest) && !populated(value.annex_digest)
        && !populated(value.corpus_digest) && !populated(value.separation_digest)
        && !populated(value.appraiser_admin_digest) && !populated(value.appraisal_policy_digest)
        && !value.authenticated && !value.durable && !value.no_replace_published
        && !value.single_view && !value.independently_reopenable && !value.source_closed
        && !value.independent_replay_performed && !value.producer_not_appraiser
        && !value.result_pass;
}

[[nodiscard]] bool empty_admission(const OwnerAdmission& value) noexcept {
    return !populated(value.admission_digest) && !populated(value.ratification_digest)
        && !populated(value.appraisal_digest) && !populated(value.parent_authorization_digest)
        && !populated(value.target_digest) && !populated(value.owner_root_digest)
        && value.decision == OwnerDecision::none && !value.authenticated
        && !value.threshold_satisfied && !value.durable && !value.no_replace_published
        && !value.single_view && !value.independently_reopenable && !value.current_root_observed
        && !value.separately_governed && !value.exact_predecessors_consumed
        && !value.self_issued_by_candidate;
}

struct Premises final {
    bool constitution{false};
    bool profile{false};
    bool ratification_core{false};
    bool ratification_reopen{false};
    bool separation{false};
    bool transparency{false};
    bool corpus{false};
    bool appraisal_core{false};
    bool appraisal_reopen{false};
    bool admission_core{false};
    bool admission_reopen{false};
};

[[nodiscard]] Premises derive(const AdmissionTrace& trace) noexcept {
    Premises p{};
    p.constitution = trace.constitution.present && populated(trace.project_id)
        && populated(trace.constitution.constitution_digest)
        && populated(trace.constitution.owner_root_digest)
        && populated(trace.constitution.constitution_policy_digest)
        && populated(trace.constitution.bootstrap_method_digest)
        && trace.constitution.canonical && trace.constitution.authenticated
        && trace.constitution.threshold_satisfied && trace.constitution.out_of_band_bootstrapped
        && trace.constitution.current_root_selected && trace.constitution.rollback_external
        && trace.constitution.durable && trace.constitution.single_view
        && trace.constitution.independently_reopenable && !trace.constitution.self_nominated;

    p.profile = p.constitution && trace.annex.present && populated(trace.annex.annex_digest)
        && populated(trace.annex.profile_id) && populated(trace.annex.role_matrix_digest)
        && populated(trace.annex.failure_corpus_spec_digest)
        && populated(trace.annex.implementation_digest) && populated(trace.annex.configuration_digest)
        && trace.annex.requirement_mask == required_profile_mask && trace.annex.canonical
        && trace.annex.complete && trace.annex.no_hidden_inputs
        && trace.annex.exact_mechanism_selected && trace.annex.bootstrap_method_declared
        && trace.annex.collision_fail_closed && trace.annex.non_equivocation_witness_required
        && !trace.annex.self_ratifying;

    p.ratification_core = p.profile && trace.ratification.present
        && populated(trace.ratification.ratification_digest)
        && populated(trace.ratification.ratification_policy_digest)
        && trace.ratification.authenticated && trace.ratification.threshold_satisfied
        && trace.ratification.owner_issued && trace.ratification.durable
        && trace.ratification.no_replace_published && trace.ratification.current_root_observed
        && !trace.ratification.self_issued_by_annex;
    p.ratification_reopen = p.ratification_core && trace.ratification.single_view
        && trace.ratification.independently_reopenable;

    const bool admin_unique = unique_nonzero(trace.separation.reopener_admin_digest,
        trace.separation.authorizer_admin_digest, trace.separation.appraiser_admin_digest,
        trace.separation.mechanism_admin_digest);
    const bool rollback_unique = unique_nonzero(trace.separation.reopener_rollback_digest,
        trace.separation.authorizer_rollback_digest, trace.separation.appraiser_rollback_digest,
        trace.separation.mechanism_rollback_digest);
    p.separation = p.ratification_reopen && trace.separation.present
        && populated(trace.separation.separation_digest) && trace.separation.owner_ratified
        && trace.separation.distinct_administrative_roots && trace.separation.distinct_rollback_roots
        && trace.separation.distinct_credentials && trace.separation.recovery_roots_separate
        && trace.separation.appraiser_can_reopen_without_operator
        && trace.separation.collusion_model_declared && !trace.separation.same_process_only
        && admin_unique && rollback_unique;

    p.transparency = p.separation && trace.annex.non_equivocation_witness_required
        && trace.constitution.single_view && trace.ratification.single_view
        && (!trace.appraisal.present || trace.appraisal.single_view)
        && (!trace.admission.present || trace.admission.single_view)
        && !trace.equivocation_observed;

    p.corpus = p.transparency && trace.corpus.present && populated(trace.corpus.corpus_digest)
        && populated(trace.corpus.disposable_target_digest)
        && trace.corpus.observed_scenario_mask == required_corpus_mask
        && trace.corpus.canonical && trace.corpus.complete && trace.corpus.actual_not_synthetic
        && trace.corpus.exact_binaries && trace.corpus.exact_configuration
        && trace.corpus.raw_traces_retained && trace.corpus.independently_locatable
        && trace.corpus.replayable && trace.corpus.expected_outcomes_checked
        && trace.corpus.disposable_target_separate
        && trace.corpus.disposable_target_digest != trace.parent.target_digest;

    p.appraisal_core = p.corpus && trace.appraisal.present
        && populated(trace.appraisal.appraisal_digest)
        && populated(trace.appraisal.appraisal_policy_digest)
        && trace.appraisal.appraiser_admin_digest == trace.separation.appraiser_admin_digest
        && trace.appraisal.authenticated && trace.appraisal.durable
        && trace.appraisal.no_replace_published && trace.appraisal.source_closed
        && trace.appraisal.independent_replay_performed && trace.appraisal.producer_not_appraiser
        && trace.appraisal.result_pass;
    p.appraisal_reopen = p.appraisal_core && trace.appraisal.single_view
        && trace.appraisal.independently_reopenable;

    p.admission_core = p.appraisal_reopen && trace.admission_requested
        && trace.admission.present && populated(trace.admission.admission_digest)
        && trace.admission.owner_root_digest == trace.constitution.owner_root_digest
        && trace.admission.decision != OwnerDecision::none && trace.admission.authenticated
        && trace.admission.threshold_satisfied && trace.admission.durable
        && trace.admission.no_replace_published && trace.admission.current_root_observed
        && trace.admission.separately_governed && trace.admission.exact_predecessors_consumed
        && !trace.admission.self_issued_by_candidate;
    p.admission_reopen = p.admission_core && trace.admission.single_view
        && trace.admission.independently_reopenable;
    return p;
}

[[nodiscard]] AdmissionReport assemble(
    const AdmissionCode code,
    const Premises& p,
    const Timeline& time,
    const AdmissionTrace& trace,
    const bool ready,
    const bool stopped) noexcept {
    AdmissionReport result{};
    result.code = code;
    result.accepted = true;
    result.parent_accepted = true;
    result.parent_ready_live_retained = true;
    result.constitution_valid = p.constitution;
    result.profile_valid = p.profile;
    result.ratification_core_valid = p.ratification_core;
    result.ratification_reopen_valid = p.ratification_reopen;
    result.separation_valid = p.separation;
    result.transparency_valid = p.transparency;
    result.corpus_valid = p.corpus;
    result.appraisal_core_valid = p.appraisal_core;
    result.appraisal_reopen_valid = p.appraisal_reopen;
    result.owner_admission_core_valid = p.admission_core;
    result.owner_admission_reopen_valid = p.admission_reopen;
    result.all_cuts_ordered = time.order;
    result.constitution_gap_observed = !p.constitution;
    result.profile_gap_observed = p.constitution && !p.profile;
    result.ratification_gap_observed = p.profile && !p.ratification_reopen;
    result.separation_gap_observed = p.ratification_reopen && !p.separation;
    result.transparency_gap_observed = p.separation && !p.transparency;
    result.corpus_gap_observed = p.transparency && !p.corpus;
    result.appraisal_gap_observed = p.corpus && !p.appraisal_reopen;
    result.owner_admission_gap_observed = p.appraisal_reopen && !p.admission_reopen;
    result.phase_order_gap_observed = time.phase_hole;
    result.regression_observed = time.backwards;
    result.self_ratification_detected = trace.constitution.self_nominated
        || trace.annex.self_ratifying || trace.ratification.self_issued_by_annex
        || trace.admission.self_issued_by_candidate;
    result.common_control_detected = trace.separation.present
        && (trace.separation.same_process_only || !trace.separation.distinct_administrative_roots
            || !trace.separation.distinct_rollback_roots
            || !unique_nonzero(trace.separation.reopener_admin_digest,
                trace.separation.authorizer_admin_digest, trace.separation.appraiser_admin_digest,
                trace.separation.mechanism_admin_digest)
            || !unique_nonzero(trace.separation.reopener_rollback_digest,
                trace.separation.authorizer_rollback_digest, trace.separation.appraiser_rollback_digest,
                trace.separation.mechanism_rollback_digest));
    result.synthetic_corpus_detected = trace.corpus.present && !trace.corpus.actual_not_synthetic;
    result.owner_rejected = p.admission_reopen && trace.admission.decision == OwnerDecision::reject;
    result.external_premise_dossier_ready = ready;
    result.live_record_must_be_retained = true;
    result.unauthorized_deletion = time.deletion;
    result.fail_stopped = stopped;
    return result;
}

}  // namespace

AdmissionReport evaluate_reference(const AdmissionTrace& trace) noexcept {
    const Digest expected = trace.parent.predecessor.receipts[
        static_cast<std::size_t>(predecessor_model::Phase::deletion_authorization)].record_digest;
    if (trace.parent.authorization.present && trace.parent.authorization.authorization_digest != expected) {
        return refusal(AdmissionCode::parent_authorization_digest_mismatch);
    }
    if (trace.parent.authorization.present
        && trace.parent.authorization.target_digest != trace.parent.target_digest) {
        return refusal(AdmissionCode::parent_target_digest_mismatch);
    }

    const auto parent = parent_model::evaluate_reference(trace.parent);
    if (!parent.accepted) return refusal(AdmissionCode::receipt_chain_rejected);
    if (parent.code == parent_model::ReceiptChainCode::accepted_chain_complete
        || parent.code == parent_model::ReceiptChainCode::accepted_deletion_receipt_gap_fail_stop) {
        return refusal(AdmissionCode::receipt_chain_already_deleted, true);
    }
    if (parent.code != parent_model::ReceiptChainCode::accepted_chain_ready_live_retained) {
        return refusal(AdmissionCode::receipt_chain_not_ready, true);
    }

    if (!trace.constitution.present && !empty_constitution(trace.constitution)) {
        return refusal(AdmissionCode::constitution_shape_invalid, true, true);
    }
    if (trace.constitution.present && trace.constitution.project_id != trace.project_id) {
        return refusal(AdmissionCode::constitution_project_mismatch, true, true);
    }
    if (!trace.annex.present && !empty_annex(trace.annex)) {
        return refusal(AdmissionCode::profile_shape_invalid, true, true);
    }
    if (trace.annex.present) {
        if (trace.annex.project_id != trace.project_id) {
            return refusal(AdmissionCode::profile_project_mismatch, true, true);
        }
        if (trace.annex.owner_constitution_digest != trace.constitution.constitution_digest) {
            return refusal(AdmissionCode::profile_constitution_mismatch, true, true);
        }
        if (trace.annex.owner_root_digest != trace.constitution.owner_root_digest) {
            return refusal(AdmissionCode::profile_owner_root_mismatch, true, true);
        }
        if (trace.annex.parent_authorization_digest != trace.parent.authorization.authorization_digest) {
            return refusal(AdmissionCode::profile_parent_authorization_mismatch, true, true);
        }
        if (trace.annex.target_digest != trace.parent.target_digest) {
            return refusal(AdmissionCode::profile_target_mismatch, true, true);
        }
    }
    if (!trace.ratification.present && !empty_ratification(trace.ratification)) {
        return refusal(AdmissionCode::ratification_shape_invalid, true, true);
    }
    if (trace.ratification.present) {
        if (trace.ratification.annex_digest != trace.annex.annex_digest) {
            return refusal(AdmissionCode::ratification_profile_mismatch, true, true);
        }
        if (trace.ratification.owner_constitution_digest != trace.constitution.constitution_digest) {
            return refusal(AdmissionCode::ratification_constitution_mismatch, true, true);
        }
        if (trace.ratification.owner_root_digest != trace.constitution.owner_root_digest) {
            return refusal(AdmissionCode::ratification_owner_root_mismatch, true, true);
        }
    }
    if (!trace.separation.present && !empty_separation(trace.separation)) {
        return refusal(AdmissionCode::separation_shape_invalid, true, true);
    }
    if (trace.separation.present && trace.separation.annex_digest != trace.annex.annex_digest) {
        return refusal(AdmissionCode::separation_profile_mismatch, true, true);
    }
    if (!trace.corpus.present && !empty_corpus(trace.corpus)) {
        return refusal(AdmissionCode::corpus_shape_invalid, true, true);
    }
    if (trace.corpus.present) {
        if (trace.corpus.annex_digest != trace.annex.annex_digest
            || trace.corpus.failure_corpus_spec_digest != trace.annex.failure_corpus_spec_digest) {
            return refusal(AdmissionCode::corpus_profile_mismatch, true, true);
        }
        if (trace.corpus.implementation_digest != trace.annex.implementation_digest) {
            return refusal(AdmissionCode::corpus_implementation_mismatch, true, true);
        }
        if (trace.corpus.configuration_digest != trace.annex.configuration_digest) {
            return refusal(AdmissionCode::corpus_configuration_mismatch, true, true);
        }
    }
    if (!trace.appraisal.present && !empty_appraisal(trace.appraisal)) {
        return refusal(AdmissionCode::appraisal_shape_invalid, true, true);
    }
    if (trace.appraisal.present) {
        if (trace.appraisal.annex_digest != trace.annex.annex_digest) {
            return refusal(AdmissionCode::appraisal_profile_mismatch, true, true);
        }
        if (trace.appraisal.corpus_digest != trace.corpus.corpus_digest) {
            return refusal(AdmissionCode::appraisal_corpus_mismatch, true, true);
        }
        if (trace.appraisal.separation_digest != trace.separation.separation_digest) {
            return refusal(AdmissionCode::appraisal_separation_mismatch, true, true);
        }
    }
    if (!trace.admission.present && !empty_admission(trace.admission)) {
        return refusal(AdmissionCode::owner_admission_shape_invalid, true, true);
    }
    if (trace.admission.present) {
        if (trace.admission.ratification_digest != trace.ratification.ratification_digest) {
            return refusal(AdmissionCode::owner_admission_ratification_mismatch, true, true);
        }
        if (trace.admission.appraisal_digest != trace.appraisal.appraisal_digest) {
            return refusal(AdmissionCode::owner_admission_appraisal_mismatch, true, true);
        }
        if (trace.admission.parent_authorization_digest
            != trace.parent.authorization.authorization_digest) {
            return refusal(AdmissionCode::owner_admission_parent_authorization_mismatch, true, true);
        }
        if (trace.admission.target_digest != trace.parent.target_digest) {
            return refusal(AdmissionCode::owner_admission_target_mismatch, true, true);
        }
    }

    const AdmissionCut& opening = trace.cuts.front();
    if (!opening.live_record_visible || opening.record_deleted
        || !opening.owner_constitution_visible || opening.annex_closed
        || opening.ratification_visible || opening.ratification_reopened
        || opening.corpus_started || opening.corpus_complete || opening.appraisal_visible
        || opening.appraisal_reopened || opening.owner_admission_visible
        || opening.owner_admission_reopened) {
        return refusal(AdmissionCode::trace_initial_state_invalid, true, true);
    }
    for (const AdmissionCut& cut : trace.cuts) {
        if (cut.live_record_visible && cut.record_deleted) {
            return refusal(AdmissionCode::trace_deleted_and_live, true, true);
        }
        if (!cut.live_record_visible && !cut.record_deleted) {
            return refusal(AdmissionCode::trace_live_absent_without_deletion, true, true);
        }
    }

    const Premises p = derive(trace);
    const Timeline time = project_timeline(trace);
    const bool final_visible = trace.cuts.back().owner_admission_reopened;
    const bool ready = p.admission_reopen && trace.admission.decision == OwnerDecision::admit
        && time.order && final_visible && !time.deletion && !trace.equivocation_observed;

    AdmissionCode disposition = AdmissionCode::accepted_external_premises_ready_live_retained;
    bool stopped = false;
    if (time.deletion) {
        disposition = AdmissionCode::accepted_unauthorized_deletion_fail_stop;
        stopped = true;
    } else if (trace.equivocation_observed) {
        disposition = AdmissionCode::accepted_equivocation_fail_stop;
        stopped = true;
    } else if (time.backwards) {
        disposition = AdmissionCode::accepted_regression_fail_stop;
        stopped = true;
    } else if (time.phase_hole
        || (p.admission_reopen && trace.admission.decision == OwnerDecision::admit && !final_visible)) {
        disposition = AdmissionCode::accepted_refused_order_gap;
    } else if (!p.constitution) {
        disposition = AdmissionCode::accepted_refused_constitution_gap;
    } else if (!p.profile) {
        disposition = AdmissionCode::accepted_refused_profile_gap;
    } else if (!trace.ratification.present) {
        disposition = AdmissionCode::accepted_profile_closed_unratified;
    } else if (!p.ratification_reopen) {
        disposition = AdmissionCode::accepted_refused_ratification_gap;
    } else if (!p.separation) {
        disposition = AdmissionCode::accepted_refused_separation_gap;
    } else if (!p.transparency) {
        disposition = AdmissionCode::accepted_refused_transparency_gap;
    } else if (!trace.corpus.present) {
        disposition = AdmissionCode::accepted_ratified_not_operated;
    } else if (!p.corpus) {
        disposition = AdmissionCode::accepted_refused_corpus_gap;
    } else if (!trace.appraisal.present) {
        disposition = AdmissionCode::accepted_operated_not_appraised;
    } else if (!p.appraisal_reopen) {
        disposition = AdmissionCode::accepted_refused_appraisal_gap;
    } else if (!trace.admission.present) {
        disposition = AdmissionCode::accepted_appraised_not_owner_admitted;
    } else if (!p.admission_reopen) {
        disposition = AdmissionCode::accepted_refused_owner_admission_gap;
    } else if (trace.admission.decision == OwnerDecision::reject) {
        disposition = AdmissionCode::accepted_owner_rejected_live_retained;
    } else if (!ready) {
        disposition = AdmissionCode::accepted_refused_order_gap;
    }

    return assemble(disposition, p, time, trace, ready, stopped);
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission
