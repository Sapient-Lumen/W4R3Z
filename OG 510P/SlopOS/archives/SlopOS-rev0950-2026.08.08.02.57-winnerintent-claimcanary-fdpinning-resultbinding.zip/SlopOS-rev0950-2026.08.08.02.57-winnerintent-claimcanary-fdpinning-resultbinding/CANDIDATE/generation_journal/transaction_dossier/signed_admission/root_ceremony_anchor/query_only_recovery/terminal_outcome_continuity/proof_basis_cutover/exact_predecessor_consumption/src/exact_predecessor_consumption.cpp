#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/exact_predecessor_consumption.hpp"

#include <algorithm>
#include <array>
#include <limits>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::exact_predecessor_consumption {
namespace {

constexpr std::size_t witness_index = 0U;
constexpr std::size_t floor_index = 1U;
constexpr std::size_t join_index = 2U;
constexpr std::size_t reopen_index = 3U;
constexpr std::size_t authorization_index = 4U;
constexpr std::size_t unseen = chain_cut_count;

[[nodiscard]] bool nonzero(const Digest& value) noexcept {
    return std::any_of(value.cbegin(), value.cend(), [](const std::uint8_t byte) {
        return byte != 0U;
    });
}

[[nodiscard]] bool blank(const PhaseReceipt& value) noexcept {
    return !value.present
        && !value.authenticated
        && !value.durable
        && !value.single_view
        && !value.independently_reopenable
        && !value.survives_restore
        && !value.survives_succession
        && !value.published
        && !nonzero(value.record_digest)
        && !nonzero(value.cutover_id)
        && !nonzero(value.request_id)
        && !nonzero(value.transition_digest)
        && !nonzero(value.register_incarnation)
        && !nonzero(value.terminal_digest)
        && !nonzero(value.witness_digest)
        && !nonzero(value.floor_digest)
        && !nonzero(value.basis_digest)
        && !nonzero(value.predecessor_a)
        && !nonzero(value.predecessor_b);
}

[[nodiscard]] bool quality(const PhaseReceipt& value) noexcept {
    return value.present
        && value.authenticated
        && value.durable
        && value.single_view
        && value.independently_reopenable
        && value.survives_restore
        && value.survives_succession
        && value.published;
}

[[nodiscard]] bool subject_exact(const PhaseReceipt& value, const ChainTrace& trace) noexcept {
    return value.cutover_id == trace.parent.cutover_id
        && value.request_id == trace.parent.state.request_id
        && value.transition_digest == trace.parent.state.transition_digest
        && value.register_incarnation == trace.parent.state.register_incarnation
        && value.terminal_digest == trace.parent.state.terminal_digest
        && value.witness_digest == trace.parent.witness_digest
        && value.floor_digest == trace.parent.floor_digest
        && value.terminal_kind == trace.parent.state.terminal_kind;
}

[[nodiscard]] Digest expected_basis(const std::size_t index, const ChainTrace& trace) noexcept {
    switch (index) {
    case witness_index: return trace.parent.witness_digest;
    case floor_index: return trace.parent.floor_digest;
    case join_index: return trace.parent.cutover_id;
    case reopen_index: return trace.parent.state.terminal_digest;
    case authorization_index: return trace.parent.state.transition_digest;
    default: return Digest{};
    }
}

[[nodiscard]] ChainReport hard_reject(const ChainCode code, const bool parent_accepted = false) noexcept {
    ChainReport report{};
    report.code = code;
    report.parent_accepted = parent_accepted;
    return report;
}

[[nodiscard]] ChainReport classified(
    const ChainCode code,
    const bool parent_accepted,
    const bool parent_safe,
    const bool subjects,
    const bool components,
    const bool unique,
    const bool exact_edges,
    const bool publications,
    const bool order,
    const bool monotone,
    const bool prefixes,
    const bool complete,
    const bool deletion_safe,
    const bool fail_stopped) noexcept {
    return ChainReport{
        code,
        true,
        parent_accepted,
        parent_safe,
        subjects,
        components,
        unique,
        exact_edges,
        publications,
        order,
        monotone,
        prefixes,
        complete,
        deletion_safe,
        !deletion_safe,
        fail_stopped,
        false,
        false,
        false,
        false,
        false,
        false,
    };
}

}  // namespace

ChainReport evaluate_candidate(const ChainTrace& trace) noexcept {
    const auto parent = proof_basis_cutover::evaluate_candidate(trace.parent);
    if (!parent.accepted) {
        return hard_reject(ChainCode::parent_relation_rejected);
    }
    if (trace.reclamation_requested != trace.parent.reclamation_requested) {
        return hard_reject(ChainCode::reclamation_request_mismatch, true);
    }

    for (std::size_t index = 0U; index < phase_count; ++index) {
        const auto& receipt = trace.receipts[index];
        if (!receipt.present) {
            if (!blank(receipt)) {
                return hard_reject(ChainCode::receipt_shape_invalid, true);
            }
            continue;
        }
        if (receipt.phase != static_cast<Phase>(index)) {
            return hard_reject(ChainCode::receipt_phase_mismatch, true);
        }
        if (!subject_exact(receipt, trace)) {
            return hard_reject(ChainCode::receipt_subject_mismatch, true);
        }
        if (receipt.basis_digest != expected_basis(index, trace)) {
            return hard_reject(ChainCode::receipt_component_mismatch, true);
        }
        if (!nonzero(receipt.record_digest)) {
            return hard_reject(ChainCode::receipt_digest_zero, true);
        }
    }

    bool unique = true;
    for (std::size_t left = 0U; left < phase_count; ++left) {
        if (!trace.receipts[left].present) continue;
        for (std::size_t right = left + 1U; right < phase_count; ++right) {
            if (trace.receipts[right].present
                && trace.receipts[left].record_digest == trace.receipts[right].record_digest) {
                unique = false;
            }
        }
    }
    if (!unique) {
        return hard_reject(ChainCode::receipt_digest_duplicate, true);
    }

    if (!trace.cuts.front().live_record_visible || trace.cuts.front().deletion_applied) {
        return hard_reject(ChainCode::trace_initial_state_invalid, true);
    }
    for (const auto& cut : trace.cuts) {
        if (cut.live_record_visible && cut.deletion_applied) {
            return hard_reject(ChainCode::trace_deleted_and_live, true);
        }
        if (!cut.live_record_visible && !cut.deletion_applied) {
            return hard_reject(ChainCode::trace_absent_without_deletion, true);
        }
        for (std::size_t phase = 0U; phase < phase_count; ++phase) {
            if (cut.receipt_visible[phase] && !trace.receipts[phase].present) {
                return hard_reject(ChainCode::receipt_shape_invalid, true);
            }
        }
    }

    bool subjects = true;
    bool components = true;
    bool publications = true;
    for (std::size_t index = 0U; index < phase_count; ++index) {
        const auto& receipt = trace.receipts[index];
        if (!receipt.present) continue;
        subjects = subjects && subject_exact(receipt, trace);
        components = components && receipt.basis_digest == expected_basis(index, trace);
        publications = publications && quality(receipt);
    }

    const auto& witness = trace.receipts[witness_index];
    const auto& floor = trace.receipts[floor_index];
    const auto& join = trace.receipts[join_index];
    const auto& reopen = trace.receipts[reopen_index];
    const auto& authorization = trace.receipts[authorization_index];
    const bool join_edge = !join.present
        || (witness.present && floor.present
            && join.predecessor_a == witness.record_digest
            && join.predecessor_b == floor.record_digest);
    const bool reopen_edge = !reopen.present
        || (join.present && reopen.predecessor_a == join.record_digest
            && !nonzero(reopen.predecessor_b));
    const bool authorization_edge = !authorization.present
        || (reopen.present && authorization.predecessor_a == reopen.record_digest
            && !nonzero(authorization.predecessor_b));
    const bool deletion_edge = !std::any_of(
        trace.cuts.cbegin(), trace.cuts.cend(), [](const ChainCut& cut) { return cut.deletion_applied; })
        || (authorization.present
            && trace.deletion_consumed_authorization_digest == authorization.record_digest);
    const bool source_edges = (!witness.present
            || (!nonzero(witness.predecessor_a) && !nonzero(witness.predecessor_b)))
        && (!floor.present
            || (!nonzero(floor.predecessor_a) && !nonzero(floor.predecessor_b)));
    const bool exact_edges = source_edges && join_edge && reopen_edge && authorization_edge && deletion_edge;

    std::array<std::size_t, phase_count> first{};
    first.fill(unseen);
    bool monotone = true;
    bool deletion_seen = false;
    std::size_t first_deletion = unseen;
    bool live_absent_seen = false;
    std::array<bool, phase_count> visible_before{};
    for (std::size_t cut_index = 0U; cut_index < chain_cut_count; ++cut_index) {
        const auto& cut = trace.cuts[cut_index];
        for (std::size_t phase = 0U; phase < phase_count; ++phase) {
            if (cut.receipt_visible[phase] && first[phase] == unseen) {
                first[phase] = cut_index;
            }
            if (visible_before[phase] && !cut.receipt_visible[phase]) {
                monotone = false;
            }
            visible_before[phase] = visible_before[phase] || cut.receipt_visible[phase];
        }
        if (cut.deletion_applied && first_deletion == unseen) first_deletion = cut_index;
        if (deletion_seen && !cut.deletion_applied) monotone = false;
        if (live_absent_seen && cut.live_record_visible) monotone = false;
        deletion_seen = deletion_seen || cut.deletion_applied;
        live_absent_seen = live_absent_seen || !cut.live_record_visible;
    }

    bool order = true;
    if (first[join_index] != unseen) {
        order = order
            && first[witness_index] != unseen
            && first[floor_index] != unseen
            && first[witness_index] < first[join_index]
            && first[floor_index] < first[join_index];
    }
    if (first[reopen_index] != unseen) {
        order = order && first[join_index] != unseen && first[join_index] < first[reopen_index];
    }
    if (first[authorization_index] != unseen) {
        order = order && first[reopen_index] != unseen
            && first[reopen_index] < first[authorization_index];
    }
    if (first_deletion != unseen) {
        order = order && first[authorization_index] != unseen
            && first[authorization_index] < first_deletion;
    }

    bool prefixes = true;
    bool deletion_observed = false;
    for (std::size_t cut_index = 0U; cut_index < chain_cut_count; ++cut_index) {
        const auto& cut = trace.cuts[cut_index];
        if (cut.deletion_applied) {
            deletion_observed = true;
            const bool all_visible = std::all_of(
                cut.receipt_visible.cbegin(), cut.receipt_visible.cend(), [](const bool visible) { return visible; });
            prefixes = prefixes
                && all_visible
                && parent.reclamation_safe
                && exact_edges
                && publications
                && order
                && first[authorization_index] != unseen
                && first[authorization_index] < cut_index;
        } else {
            prefixes = prefixes && cut.live_record_visible;
        }
    }

    const auto& final_cut = trace.cuts.back();
    const bool all_present = std::all_of(
        trace.receipts.cbegin(), trace.receipts.cend(), [](const PhaseReceipt& receipt) { return receipt.present; });
    const bool all_visible_final = std::all_of(
        final_cut.receipt_visible.cbegin(), final_cut.receipt_visible.cend(), [](const bool visible) { return visible; });
    const bool complete = all_present
        && all_visible_final
        && exact_edges
        && publications
        && order
        && monotone;
    const bool safe = parent.reclamation_safe
        && trace.reclamation_requested
        && complete
        && prefixes
        && final_cut.deletion_applied
        && !final_cut.live_record_visible
        && deletion_observed;
    const bool ready = !final_cut.deletion_applied
        && final_cut.live_record_visible
        && complete
        && prefixes;

    if (trace.equivocation_observed) {
        return classified(
            ChainCode::accepted_equivocation_fail_stop, true, parent.reclamation_safe,
            subjects, components, unique, exact_edges, publications, order,
            monotone, prefixes, complete, false, true);
    }
    if (!monotone) {
        return classified(
            ChainCode::accepted_regression_fail_stop, true, parent.reclamation_safe,
            subjects, components, unique, exact_edges, publications, order,
            monotone, prefixes, complete, false, true);
    }
    if (safe) {
        return classified(
            ChainCode::accepted_chain_complete, true, true,
            subjects, components, unique, true, true, true, true, true, true, true, false);
    }
    if (ready) {
        return classified(
            ChainCode::accepted_chain_ready_live_retained, true, parent.reclamation_safe,
            subjects, components, unique, true, true, true, true, true, true, false, false);
    }
    if (!exact_edges) {
        return classified(
            ChainCode::accepted_reclamation_refused_exact_predecessor, true, parent.reclamation_safe,
            subjects, components, unique, false, publications, order, true, prefixes, false, false, false);
    }
    if (!publications) {
        return classified(
            ChainCode::accepted_reclamation_refused_publication, true, parent.reclamation_safe,
            subjects, components, unique, true, false, order, true, prefixes, false, false, false);
    }
    if (!order) {
        return classified(
            ChainCode::accepted_reclamation_refused_phase_order, true, parent.reclamation_safe,
            subjects, components, unique, true, publications, false, true, prefixes, false, false, false);
    }
    if (!prefixes) {
        return classified(
            ChainCode::accepted_reclamation_refused_prefix_gap, true, parent.reclamation_safe,
            subjects, components, unique, true, publications, true, true, false, complete, false, false);
    }
    return classified(
        ChainCode::accepted_chain_prefix_live_retained, true, parent.reclamation_safe,
        subjects, components, unique, true, publications, true, true, true, complete, false, false);
}

std::string_view chain_code_name(const ChainCode value) noexcept {
    switch (value) {
    case ChainCode::accepted_chain_complete: return "accepted_chain_complete";
    case ChainCode::accepted_chain_ready_live_retained: return "accepted_chain_ready_live_retained";
    case ChainCode::accepted_chain_prefix_live_retained: return "accepted_chain_prefix_live_retained";
    case ChainCode::accepted_reclamation_refused_exact_predecessor: return "accepted_reclamation_refused_exact_predecessor";
    case ChainCode::accepted_reclamation_refused_publication: return "accepted_reclamation_refused_publication";
    case ChainCode::accepted_reclamation_refused_phase_order: return "accepted_reclamation_refused_phase_order";
    case ChainCode::accepted_reclamation_refused_prefix_gap: return "accepted_reclamation_refused_prefix_gap";
    case ChainCode::accepted_equivocation_fail_stop: return "accepted_equivocation_fail_stop";
    case ChainCode::accepted_regression_fail_stop: return "accepted_regression_fail_stop";
    case ChainCode::parent_relation_rejected: return "parent_relation_rejected";
    case ChainCode::reclamation_request_mismatch: return "reclamation_request_mismatch";
    case ChainCode::receipt_shape_invalid: return "receipt_shape_invalid";
    case ChainCode::receipt_phase_mismatch: return "receipt_phase_mismatch";
    case ChainCode::receipt_subject_mismatch: return "receipt_subject_mismatch";
    case ChainCode::receipt_component_mismatch: return "receipt_component_mismatch";
    case ChainCode::receipt_digest_zero: return "receipt_digest_zero";
    case ChainCode::receipt_digest_duplicate: return "receipt_digest_duplicate";
    case ChainCode::trace_initial_state_invalid: return "trace_initial_state_invalid";
    case ChainCode::trace_deleted_and_live: return "trace_deleted_and_live";
    case ChainCode::trace_absent_without_deletion: return "trace_absent_without_deletion";
    }
    return "unknown";
}

std::string_view phase_name(const Phase value) noexcept {
    switch (value) {
    case Phase::witness_publication: return "witness_publication";
    case Phase::floor_publication: return "floor_publication";
    case Phase::join_publication: return "join_publication";
    case Phase::cold_reopen_receipt: return "cold_reopen_receipt";
    case Phase::deletion_authorization: return "deletion_authorization";
    }
    return "unknown";
}

std::string_view chain_cut_name(const std::size_t index) noexcept {
    constexpr std::array<std::string_view, chain_cut_count> names{
        "T0_live", "T1_first_component", "T2_second_component", "T3_join",
        "T4_cold_reopen", "T5_authorize", "T6_pre_delete", "T7_delete"};
    return index < names.size() ? names[index] : "unknown";
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::exact_predecessor_consumption
