
#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity.hpp"

#include <algorithm>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity {
namespace {

[[nodiscard]] bool nonzero(const Digest& value) noexcept {
    return std::any_of(value.begin(), value.end(), [](const std::uint8_t byte) {
        return byte != 0U;
    });
}

[[nodiscard]] ContinuityReport make_report(
    const ContinuityCode code,
    const bool accepted,
    const bool record_execution,
    const bool record_history,
    const bool witness_history,
    const bool floor_execution,
    const bool fail_stopped,
    const bool reclamation_requested) noexcept {
    const bool execution = !fail_stopped && (record_execution || floor_execution);
    const bool history = !fail_stopped && (record_history || witness_history);
    const bool continuity = execution && history;
    const bool reclamation_safe = continuity
        && reclamation_requested
        && floor_execution
        && witness_history;
    return ContinuityReport{
        code,
        accepted,
        record_execution,
        record_history,
        witness_history,
        floor_execution,
        execution,
        history,
        continuity,
        reclamation_safe,
        fail_stopped,
        false,
        false,
        false,
        false,
        false,
        false,
        false,
    };
}

[[nodiscard]] ContinuityReport reject(const ContinuityCode code) noexcept {
    return make_report(code, false, false, false, false, false, false, false);
}

[[nodiscard]] bool record_shape_valid(const ContinuityEvidence& value) noexcept {
    const bool dependent = value.terminal_record_authenticated
        || value.terminal_record_durable
        || value.terminal_record_serialized
        || value.terminal_record_single_view
        || value.terminal_record_retained_full_horizon
        || value.terminal_record_fences_pending
        || value.terminal_record_survives_restore
        || value.terminal_record_survives_succession
        || value.terminal_record_independently_reopenable;
    return value.terminal_record_present || !dependent;
}

[[nodiscard]] bool witness_shape_valid(const ContinuityEvidence& value) noexcept {
    const bool dependent = value.terminal_witness_authenticated
        || value.terminal_witness_binds_terminal
        || value.terminal_witness_durable
        || value.terminal_witness_independently_reopenable
        || value.terminal_witness_survives_restore
        || value.terminal_witness_survives_succession;
    return value.terminal_witness_present || !dependent;
}

[[nodiscard]] bool floor_shape_valid(const ContinuityEvidence& value) noexcept {
    const bool dependent = value.successor_floor_authenticated
        || value.successor_floor_monotone
        || value.successor_floor_outside_restore_domain
        || value.successor_floor_binds_request_namespace
        || value.old_incarnation_rejected
        || value.pending_invocations_fenced
        || value.restore_preserves_floor
        || value.succession_preserves_floor
        || value.successor_floor_single_view;
    return value.successor_floor_present || !dependent;
}

}  // namespace

ContinuityReport evaluate_candidate(
    const TerminalState& state,
    const ContinuityEvidence& evidence) noexcept {
    if (!nonzero(state.request_id)
        || !nonzero(state.transition_digest)
        || !nonzero(state.register_incarnation)
        || !nonzero(state.terminal_digest)) {
        return reject(ContinuityCode::invalid_state);
    }
    if (evidence.request_id != state.request_id) {
        return reject(ContinuityCode::request_id_mismatch);
    }
    if (evidence.transition_digest != state.transition_digest) {
        return reject(ContinuityCode::transition_digest_mismatch);
    }
    if (evidence.register_incarnation != state.register_incarnation) {
        return reject(ContinuityCode::register_incarnation_mismatch);
    }
    if (evidence.terminal_digest != state.terminal_digest) {
        return reject(ContinuityCode::terminal_digest_mismatch);
    }
    if (evidence.terminal_kind != state.terminal_kind) {
        return reject(ContinuityCode::terminal_kind_mismatch);
    }
    if (!record_shape_valid(evidence)) {
        return reject(ContinuityCode::terminal_record_shape_invalid);
    }
    if (!witness_shape_valid(evidence)) {
        return reject(ContinuityCode::terminal_witness_shape_invalid);
    }
    if (!floor_shape_valid(evidence)) {
        return reject(ContinuityCode::successor_floor_shape_invalid);
    }
    if (evidence.equivocation_observed) {
        return make_report(
            ContinuityCode::accepted_equivocation_fail_stop,
            true,
            false,
            false,
            false,
            false,
            true,
            evidence.reclamation_requested);
    }

    const bool common_record = evidence.terminal_record_present
        && evidence.terminal_record_authenticated
        && evidence.terminal_record_durable
        && evidence.terminal_record_single_view
        && evidence.terminal_record_retained_full_horizon
        && evidence.terminal_record_survives_restore
        && evidence.terminal_record_survives_succession;
    const bool record_execution = common_record
        && evidence.terminal_record_serialized
        && evidence.terminal_record_fences_pending;
    const bool record_history = common_record
        && evidence.terminal_record_independently_reopenable;
    const bool witness_history = evidence.terminal_witness_present
        && evidence.terminal_witness_authenticated
        && evidence.terminal_witness_binds_terminal
        && evidence.terminal_witness_durable
        && evidence.terminal_witness_independently_reopenable
        && evidence.terminal_witness_survives_restore
        && evidence.terminal_witness_survives_succession;
    const bool floor_execution = evidence.successor_floor_present
        && evidence.successor_floor_authenticated
        && evidence.successor_floor_monotone
        && evidence.successor_floor_outside_restore_domain
        && evidence.successor_floor_binds_request_namespace
        && evidence.old_incarnation_rejected
        && evidence.pending_invocations_fenced
        && evidence.restore_preserves_floor
        && evidence.succession_preserves_floor
        && evidence.successor_floor_single_view;

    const bool execution = record_execution || floor_execution;
    const bool history = record_history || witness_history;
    ContinuityCode code = ContinuityCode::accepted_neither;
    if (execution && history) {
        if (record_execution && record_history && !floor_execution && !witness_history) {
            code = ContinuityCode::accepted_live_record_continuity;
        } else if (floor_execution && witness_history && !record_execution && !record_history) {
            code = ContinuityCode::accepted_successor_witness_continuity;
        } else {
            code = ContinuityCode::accepted_hybrid_continuity;
        }
    } else if (execution) {
        code = ContinuityCode::accepted_execution_only;
    } else if (history) {
        code = ContinuityCode::accepted_history_only;
    }
    return make_report(
        code,
        true,
        record_execution,
        record_history,
        witness_history,
        floor_execution,
        false,
        evidence.reclamation_requested);
}

std::string_view terminal_kind_name(const TerminalKind value) noexcept {
    switch (value) {
    case TerminalKind::effect: return "effect";
    case TerminalKind::no_effect: return "no_effect";
    }
    return "invalid";
}

std::string_view continuity_code_name(const ContinuityCode value) noexcept {
    switch (value) {
    case ContinuityCode::accepted_live_record_continuity: return "accepted_live_record_continuity";
    case ContinuityCode::accepted_successor_witness_continuity: return "accepted_successor_witness_continuity";
    case ContinuityCode::accepted_hybrid_continuity: return "accepted_hybrid_continuity";
    case ContinuityCode::accepted_execution_only: return "accepted_execution_only";
    case ContinuityCode::accepted_history_only: return "accepted_history_only";
    case ContinuityCode::accepted_neither: return "accepted_neither";
    case ContinuityCode::accepted_equivocation_fail_stop: return "accepted_equivocation_fail_stop";
    case ContinuityCode::invalid_state: return "invalid_state";
    case ContinuityCode::request_id_mismatch: return "request_id_mismatch";
    case ContinuityCode::transition_digest_mismatch: return "transition_digest_mismatch";
    case ContinuityCode::register_incarnation_mismatch: return "register_incarnation_mismatch";
    case ContinuityCode::terminal_digest_mismatch: return "terminal_digest_mismatch";
    case ContinuityCode::terminal_kind_mismatch: return "terminal_kind_mismatch";
    case ContinuityCode::terminal_record_shape_invalid: return "terminal_record_shape_invalid";
    case ContinuityCode::terminal_witness_shape_invalid: return "terminal_witness_shape_invalid";
    case ContinuityCode::successor_floor_shape_invalid: return "successor_floor_shape_invalid";
    }
    return "invalid";
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity
