# External Premise Admission V1

## Status

Hosted Epoch Zero relation. Not a deployment profile and not an owner constitution.

## Parent

The sole parent state is `accepted_chain_ready_live_retained` from Reopen Receipt Chain V1. A completed/deleted parent, an inert live-basis parent, or a rejected parent cannot be refined by this relation.

## Objects

The trace binds seven external-premise objects to the exact parent authorization and target:

1. an owner constitution selected outside the candidate's rollback domain;
2. a complete mechanism annex;
3. an owner ratification receipt;
4. a role-separation matrix naming administrative and rollback roots;
5. an actually operated failure corpus over exact binaries and configuration;
6. an independently replayed appraisal receipt; and
7. an owner admission consuming the exact ratification, appraisal, parent authorization, and target.

All identities are content-bound digests. A label, process name, key count, or pathname is not an independence proof.

## Ten durable cuts

The chronology begins with a current constitution and the live terminal record. Each later fact must first appear strictly after its predecessor: annex closure, ratification publication, ratification reopen, rehearsal start, corpus completion, appraisal publication, appraisal reopen, owner-admission publication, and owner-admission reopen. Two phases becoming true in one cut are not predecessor consumption. The relation stops there: production reopen, receipt, and authorization require their own bound objects in a later theorem and are not represented as witnessless booleans.

No cut in this child authorizes deletion. Any disappearance of the live record is fail-stop.

## Admission laws

- A complete annex cannot nominate the owner root that ratifies it.
- Ratification is not operation.
- Operation is not independent appraisal.
- Appraisal is not owner admission.
- Distinct roles are not distinct administrative fate unless administrative, rollback, credential, and recovery roots are separated.
- Inclusion or publication is not non-equivocation without a shared-view/consistency premise.
- Synthetic examples are not an operated failure corpus.
- Owner admission must consume the exact predecessor identities; sibling-history receipts are rejected.
- A positive owner admission plus a complete hosted chronology produces only `external_premise_dossier_ready`.

## Mandatory nonclaims

The model never proves that the constitution exists outside the datacube, that any mechanism was operated, that custody is independent in the world, that the selected root is current, that an owner admitted the annex, that Epoch Zero has ended, or that authority exists.
