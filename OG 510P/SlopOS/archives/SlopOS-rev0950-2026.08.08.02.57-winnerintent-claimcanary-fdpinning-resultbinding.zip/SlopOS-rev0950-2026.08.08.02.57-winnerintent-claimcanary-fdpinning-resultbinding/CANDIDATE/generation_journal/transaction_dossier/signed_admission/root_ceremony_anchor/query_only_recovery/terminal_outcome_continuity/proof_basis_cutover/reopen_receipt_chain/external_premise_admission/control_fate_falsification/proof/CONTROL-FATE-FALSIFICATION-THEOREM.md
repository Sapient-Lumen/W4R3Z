# Control-Fate Falsification Theorem V1

Let `P` be an External Premise Admission trace whose candidate and reference judgments both accept `P` as dossier-ready while the complete live terminal record remains present. Let `G` be an externally supplied typed control graph that binds the exact separation digest and annex digest of `P`.

## Exact representation premise

Define `EncG(G)` as the fixed `SlopOS/cff/graph/v2` domain followed by the exact source closure, inventory scope, omitted-edge policy, counts, claim flags, counted nodes, counted edges, and ordered bindings specified in the profile. Acceptance requires:

`G.graph_digest = SHA256(EncG(G))`.

Unused array tails are zero and bindings occur in role order, so uncounted or reordered struct content cannot hide outside the committed preimage. Domain-separated publication and challenge preimages bind the graph digest and their exact propositions. Candidate and reference serialize these preimages independently; retained Python vectors independently re-hash every byte sequence.

This establishes exact subject binding only. It does not authenticate the graph sources, prove inventory completeness, or prove that publication or challenge occurred.

## Common-fate judgment

For a role `r` and capability `k`, define `U_G(r,k)` as the reflexive-transitive set of nodes that can control the role's bound leaf through edges carrying capability `k`. For every required pair `(a,b,k)`, the child searches for a witness:

`w ∈ U_G(a,k) ∩ U_G(b,k)`.

If a witness exists, the corresponding separation claim is mechanically refuted in the supplied graph. If no witness exists, the only permitted positive statement is that no common fate was found in the supplied closure.

## Monotonicity

For graphs `G ⊆ H` with identical bindings and with `H` obtained only by adding nodes or control edges, every witness in `G` remains a witness in `H`:

`refuted(G) ⇒ refuted(H)`.

The reverse implication does not hold, and `¬refuted(G)` does not imply independence. An incomplete inventory can omit the edge that would expose a common controller.

## Cross-layer binding

The administrative and rollback leaves for the mechanism operator, independent reopener, appraiser, and owner admitter must equal the corresponding leaf digests in the exact parent separation matrix. Substitution of a sibling separation, annex, graph, scope, policy, publication proposition, or challenge proposition is structural rejection.

## Nonclaims

The theorem does not establish inventory completeness, transitive independence in the world, owner constitution, currentness, external occurrence, operation, independent custody, epoch exit, authority, or safe reclamation. All accepted traces retain the live terminal record.
