#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/reopen_receipt_chain/external_premise_admission/control_fate_falsification.hpp"

#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <string>
#include <string_view>
#include <system_error>
#include <utility>
#include <vector>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification {
namespace {

[[nodiscard]] Digest digest(const std::uint8_t seed) noexcept {
    Digest value{};
    for (std::size_t index = 0U; index < value.size(); ++index) {
        value[index] = static_cast<std::uint8_t>(seed + static_cast<std::uint8_t>(index));
    }
    return value;
}

[[nodiscard]] TerminalState terminal(const TerminalKind kind = TerminalKind::effect) noexcept {
    return TerminalState{digest(0x11U), digest(0x31U), digest(0x51U), digest(0x71U), kind};
}

[[nodiscard]] ContinuityEvidence continuity(const TerminalState& state) noexcept {
    ContinuityEvidence value{};
    value.request_id = state.request_id;
    value.transition_digest = state.transition_digest;
    value.register_incarnation = state.register_incarnation;
    value.terminal_digest = state.terminal_digest;
    value.terminal_kind = state.terminal_kind;
    value.terminal_record_present = true;
    value.terminal_record_authenticated = true;
    value.terminal_record_durable = true;
    value.terminal_record_serialized = true;
    value.terminal_record_single_view = true;
    value.terminal_record_retained_full_horizon = true;
    value.terminal_record_fences_pending = true;
    value.terminal_record_survives_restore = true;
    value.terminal_record_survives_succession = true;
    value.terminal_record_independently_reopenable = true;
    value.terminal_witness_present = true;
    value.terminal_witness_authenticated = true;
    value.terminal_witness_binds_terminal = true;
    value.terminal_witness_durable = true;
    value.terminal_witness_independently_reopenable = true;
    value.terminal_witness_survives_restore = true;
    value.terminal_witness_survives_succession = true;
    value.successor_floor_present = true;
    value.successor_floor_authenticated = true;
    value.successor_floor_monotone = true;
    value.successor_floor_outside_restore_domain = true;
    value.successor_floor_binds_request_namespace = true;
    value.old_incarnation_rejected = true;
    value.pending_invocations_fenced = true;
    value.restore_preserves_floor = true;
    value.succession_preserves_floor = true;
    value.successor_floor_single_view = true;
    value.reclamation_requested = true;
    return value;
}

[[nodiscard]] JoinReceipt join(const CutoverTrace& trace) noexcept {
    JoinReceipt value{};
    value.cutover_id = trace.cutover_id;
    value.request_id = trace.state.request_id;
    value.transition_digest = trace.state.transition_digest;
    value.register_incarnation = trace.state.register_incarnation;
    value.terminal_digest = trace.state.terminal_digest;
    value.witness_digest = trace.witness_digest;
    value.floor_digest = trace.floor_digest;
    value.terminal_kind = trace.state.terminal_kind;
    value.present = true;
    value.authenticated = true;
    value.durable = true;
    value.single_view = true;
    value.independently_reopenable = true;
    value.survives_restore = true;
    value.survives_succession = true;
    return value;
}

[[nodiscard]] CutObservation pcut(
    const bool live, const bool witness, const bool floor, const bool joined,
    const bool authorized, const bool deleted, const bool reopened) noexcept {
    return CutObservation{live, witness, floor, joined, authorized, deleted, reopened};
}

[[nodiscard]] CutoverTrace parent_trace(const TerminalKind kind, const bool deleted) noexcept {
    CutoverTrace trace{};
    trace.state = terminal(kind);
    trace.continuity = continuity(trace.state);
    trace.cutover_id = digest(0x91U);
    trace.witness_digest = digest(0xB1U);
    trace.floor_digest = digest(0xD1U);
    trace.reclamation_requested = true;
    trace.join = join(trace);
    trace.cuts = {
        pcut(true, false, false, false, false, false, false),
        pcut(true, true, false, false, false, false, false),
        pcut(true, true, true, false, false, false, false),
        pcut(true, true, true, true, false, false, false),
        pcut(true, true, true, true, false, false, true),
        pcut(true, true, true, true, deleted, false, true),
        pcut(!deleted, true, true, true, deleted, deleted, true),
    };
    return trace;
}

[[nodiscard]] exact_predecessor_consumption::PhaseReceipt exact_receipt(
    const exact_predecessor_consumption::Phase phase,
    const std::uint8_t identity_seed,
    const exact_predecessor_consumption::ChainTrace& trace) noexcept {
    exact_predecessor_consumption::PhaseReceipt value{};
    value.phase = phase;
    value.record_digest = digest(identity_seed);
    value.cutover_id = trace.parent.cutover_id;
    value.request_id = trace.parent.state.request_id;
    value.transition_digest = trace.parent.state.transition_digest;
    value.register_incarnation = trace.parent.state.register_incarnation;
    value.terminal_digest = trace.parent.state.terminal_digest;
    value.witness_digest = trace.parent.witness_digest;
    value.floor_digest = trace.parent.floor_digest;
    value.terminal_kind = trace.parent.state.terminal_kind;
    switch (phase) {
    case exact_predecessor_consumption::Phase::witness_publication:
        value.basis_digest = trace.parent.witness_digest;
        break;
    case exact_predecessor_consumption::Phase::floor_publication:
        value.basis_digest = trace.parent.floor_digest;
        break;
    case exact_predecessor_consumption::Phase::join_publication:
        value.basis_digest = trace.parent.cutover_id;
        break;
    case exact_predecessor_consumption::Phase::cold_reopen_receipt:
        value.basis_digest = trace.parent.state.terminal_digest;
        break;
    case exact_predecessor_consumption::Phase::deletion_authorization:
        value.basis_digest = trace.parent.state.transition_digest;
        break;
    }
    value.present = true;
    value.authenticated = true;
    value.durable = true;
    value.single_view = true;
    value.independently_reopenable = true;
    value.survives_restore = true;
    value.survives_succession = true;
    value.published = true;
    return value;
}

[[nodiscard]] exact_predecessor_consumption::ChainCut exact_cut(
    const bool live,
    const std::array<bool, exact_predecessor_consumption::phase_count>& visible,
    const bool deleted = false) noexcept {
    return exact_predecessor_consumption::ChainCut{live, visible, deleted};
}

[[nodiscard]] exact_predecessor_consumption::ChainTrace exact_trace(
    const TerminalKind kind, const bool deleted) noexcept {
    using exact_predecessor_consumption::Phase;
    exact_predecessor_consumption::ChainTrace trace{};
    trace.parent = parent_trace(kind, deleted);
    trace.reclamation_requested = true;
    trace.receipts[0] = exact_receipt(Phase::witness_publication, 0x21U, trace);
    trace.receipts[1] = exact_receipt(Phase::floor_publication, 0x41U, trace);
    trace.receipts[2] = exact_receipt(Phase::join_publication, 0x61U, trace);
    trace.receipts[3] = exact_receipt(Phase::cold_reopen_receipt, 0x81U, trace);
    trace.receipts[4] = exact_receipt(Phase::deletion_authorization, 0xA1U, trace);
    trace.receipts[2].predecessor_a = trace.receipts[0].record_digest;
    trace.receipts[2].predecessor_b = trace.receipts[1].record_digest;
    trace.receipts[3].predecessor_a = trace.receipts[2].record_digest;
    trace.receipts[4].predecessor_a = trace.receipts[3].record_digest;
    trace.deletion_consumed_authorization_digest = trace.receipts[4].record_digest;
    const std::array<bool, exact_predecessor_consumption::phase_count> none{false, false, false, false, false};
    const std::array<bool, exact_predecessor_consumption::phase_count> witness{true, false, false, false, false};
    const std::array<bool, exact_predecessor_consumption::phase_count> components{true, true, false, false, false};
    const std::array<bool, exact_predecessor_consumption::phase_count> joined{true, true, true, false, false};
    const std::array<bool, exact_predecessor_consumption::phase_count> reopened{true, true, true, true, false};
    const std::array<bool, exact_predecessor_consumption::phase_count> authorized{true, true, true, true, true};
    trace.cuts = {
        exact_cut(true, none),
        exact_cut(true, witness),
        exact_cut(true, components),
        exact_cut(true, joined),
        exact_cut(true, reopened),
        exact_cut(true, authorized),
        exact_cut(true, authorized),
        exact_cut(!deleted, authorized, deleted),
    };
    return trace;
}

[[nodiscard]] SourceClosure source(const ReceiptChainTrace& trace) noexcept {
    SourceClosure value{};
    value.closure_digest = digest(0x15U);
    value.cutover_id = trace.predecessor.parent.cutover_id;
    value.join_digest = trace.join_digest;
    value.witness_digest = trace.predecessor.parent.witness_digest;
    value.floor_digest = trace.predecessor.parent.floor_digest;
    value.request_id = trace.predecessor.parent.state.request_id;
    value.transition_digest = trace.predecessor.parent.state.transition_digest;
    value.register_incarnation = trace.predecessor.parent.state.register_incarnation;
    value.terminal_digest = trace.predecessor.parent.state.terminal_digest;
    value.reopener_incarnation = digest(0x25U);
    value.verifier_id = digest(0x35U);
    value.verifier_policy_digest = digest(0x45U);
    value.terminal_kind = trace.predecessor.parent.state.terminal_kind;
    value.present = true;
    value.canonical = true;
    value.complete = true;
    value.independently_locatable = true;
    value.rollback_external = true;
    value.replacement_only = true;
    value.no_hidden_inputs = true;
    value.includes_live_terminal_record = false;
    return value;
}

[[nodiscard]] ReopenReceipt reopen(const ReceiptChainTrace& trace) noexcept {
    ReopenReceipt value{};
    value.receipt_digest = trace.predecessor.receipts[static_cast<std::size_t>(
        exact_predecessor_consumption::Phase::cold_reopen_receipt)].record_digest;
    value.closure_digest = trace.source.closure_digest;
    value.cutover_id = trace.predecessor.parent.cutover_id;
    value.join_digest = trace.join_digest;
    value.witness_digest = trace.predecessor.parent.witness_digest;
    value.floor_digest = trace.predecessor.parent.floor_digest;
    value.request_id = trace.predecessor.parent.state.request_id;
    value.transition_digest = trace.predecessor.parent.state.transition_digest;
    value.register_incarnation = trace.predecessor.parent.state.register_incarnation;
    value.terminal_digest = trace.predecessor.parent.state.terminal_digest;
    value.reopener_incarnation = trace.source.reopener_incarnation;
    value.verifier_id = trace.source.verifier_id;
    value.verifier_policy_digest = trace.source.verifier_policy_digest;
    value.terminal_kind = trace.predecessor.parent.state.terminal_kind;
    value.present = true;
    value.computed_from_closure = true;
    value.exact_result = true;
    value.authenticated = true;
    value.no_replace_published = true;
    value.durable = true;
    value.directory_entry_durable = true;
    value.single_view = true;
    value.independently_reopenable = true;
    return value;
}

[[nodiscard]] AuthorizationCapsule authorization(const ReceiptChainTrace& trace) noexcept {
    AuthorizationCapsule value{};
    value.authorization_digest = trace.predecessor.receipts[static_cast<std::size_t>(
        exact_predecessor_consumption::Phase::deletion_authorization)].record_digest;
    value.reopen_receipt_digest = trace.reopen.receipt_digest;
    value.cutover_id = trace.predecessor.parent.cutover_id;
    value.target_digest = trace.target_digest;
    value.owner_policy_digest = trace.owner_policy_digest;
    value.retention_policy_digest = trace.retention_policy_digest;
    value.present = true;
    value.authenticated = true;
    value.durable = true;
    value.no_replace_published = true;
    value.single_view = true;
    value.separately_governed = true;
    value.independently_reopenable = true;
    return value;
}

[[nodiscard]] DeletionReceipt deletion(const ReceiptChainTrace& trace) noexcept {
    DeletionReceipt value{};
    value.deletion_receipt_digest = digest(0x75U);
    value.authorization_digest = trace.authorization.authorization_digest;
    value.cutover_id = trace.predecessor.parent.cutover_id;
    value.target_digest = trace.target_digest;
    value.present = true;
    value.authenticated = true;
    value.durable = true;
    value.no_replace_published = true;
    value.single_view = true;
    value.target_absence_observed = true;
    return value;
}

[[nodiscard]] ReceiptCut rcut(
    const bool live, const bool started, const bool computed, const bool receipt,
    const bool receipt_reopened, const bool auth, const bool auth_reopened,
    const bool deleted, const bool deletion_receipt) noexcept {
    return ReceiptCut{live, true, started, computed, receipt, receipt_reopened,
        auth, auth_reopened, deleted, deletion_receipt};
}

[[nodiscard]] std::array<ReceiptCut, receipt_cut_count> complete_cuts() noexcept {
    return {
        rcut(true, false, false, false, false, false, false, false, false),
        rcut(true, true, false, false, false, false, false, false, false),
        rcut(true, true, true, false, false, false, false, false, false),
        rcut(true, true, true, true, false, false, false, false, false),
        rcut(true, true, true, true, true, false, false, false, false),
        rcut(true, true, true, true, true, true, false, false, false),
        rcut(true, true, true, true, true, true, true, false, false),
        rcut(false, true, true, true, true, true, true, true, false),
        rcut(false, true, true, true, true, true, true, true, true),
    };
}

[[nodiscard]] std::array<ReceiptCut, receipt_cut_count> ready_cuts() noexcept {
    auto cuts = complete_cuts();
    cuts[7] = rcut(true, true, true, true, true, true, true, false, false);
    cuts[8] = cuts[7];
    return cuts;
}

[[nodiscard]] ReceiptChainTrace base_trace(
    const bool deleted = false,
    const TerminalKind kind = TerminalKind::effect) noexcept {
    ReceiptChainTrace trace{};
    // The child owns the destructive extension.  Its embedded predecessor is
    // always the accepted still-live exact prefix, even for child-complete cases.
    trace.predecessor = exact_trace(kind, false);
    trace.join_digest = trace.predecessor.receipts[static_cast<std::size_t>(
        exact_predecessor_consumption::Phase::join_publication)].record_digest;
    trace.target_digest = digest(0x85U);
    trace.owner_policy_digest = digest(0x95U);
    trace.retention_policy_digest = digest(0xA5U);
    trace.source = source(trace);
    trace.reopen = reopen(trace);
    trace.authorization = authorization(trace);
    trace.deletion = deletion(trace);
    trace.cuts = deleted ? complete_cuts() : ready_cuts();
    trace.reclamation_requested = true;
    return trace;
}


[[nodiscard]] OwnerConstitution constitution(const AdmissionTrace& trace) noexcept {
    OwnerConstitution value{};
    value.constitution_digest = digest(0xC2U);
    value.project_id = trace.project_id;
    value.owner_root_digest = digest(0xC4U);
    value.constitution_policy_digest = digest(0xC6U);
    value.bootstrap_method_digest = digest(0xC8U);
    value.present = true;
    value.canonical = true;
    value.authenticated = true;
    value.threshold_satisfied = true;
    value.out_of_band_bootstrapped = true;
    value.current_root_selected = true;
    value.rollback_external = true;
    value.durable = true;
    value.single_view = true;
    value.independently_reopenable = true;
    return value;
}

[[nodiscard]] MechanismAnnex annex(const AdmissionTrace& trace) noexcept {
    MechanismAnnex value{};
    value.annex_digest = digest(0xCAU);
    value.project_id = trace.project_id;
    value.owner_constitution_digest = trace.constitution.constitution_digest;
    value.owner_root_digest = trace.constitution.owner_root_digest;
    value.parent_authorization_digest = trace.parent.authorization.authorization_digest;
    value.target_digest = trace.parent.target_digest;
    value.profile_id = digest(0xCCU);
    value.role_matrix_digest = digest(0xCEU);
    value.failure_corpus_spec_digest = digest(0xD0U);
    value.implementation_digest = digest(0xD2U);
    value.configuration_digest = digest(0xD4U);
    value.requirement_mask = required_profile_mask;
    value.present = true;
    value.canonical = true;
    value.complete = true;
    value.no_hidden_inputs = true;
    value.exact_mechanism_selected = true;
    value.bootstrap_method_declared = true;
    value.collision_fail_closed = true;
    value.non_equivocation_witness_required = true;
    return value;
}

[[nodiscard]] RatificationReceipt ratification(const AdmissionTrace& trace) noexcept {
    RatificationReceipt value{};
    value.ratification_digest = digest(0xD6U);
    value.annex_digest = trace.annex.annex_digest;
    value.owner_constitution_digest = trace.constitution.constitution_digest;
    value.owner_root_digest = trace.constitution.owner_root_digest;
    value.ratification_policy_digest = digest(0xD8U);
    value.present = true;
    value.authenticated = true;
    value.threshold_satisfied = true;
    value.owner_issued = true;
    value.durable = true;
    value.no_replace_published = true;
    value.single_view = true;
    value.independently_reopenable = true;
    value.current_root_observed = true;
    return value;
}

[[nodiscard]] RoleSeparation separation(const AdmissionTrace& trace) noexcept {
    RoleSeparation value{};
    value.separation_digest = digest(0xDAU);
    value.annex_digest = trace.annex.annex_digest;
    value.reopener_admin_digest = digest(0x10U);
    value.authorizer_admin_digest = digest(0x20U);
    value.appraiser_admin_digest = digest(0x30U);
    value.mechanism_admin_digest = digest(0x40U);
    value.reopener_rollback_digest = digest(0x50U);
    value.authorizer_rollback_digest = digest(0x60U);
    value.appraiser_rollback_digest = digest(0x70U);
    value.mechanism_rollback_digest = digest(0x80U);
    value.present = true;
    value.owner_ratified = true;
    value.distinct_administrative_roots = true;
    value.distinct_rollback_roots = true;
    value.distinct_credentials = true;
    value.recovery_roots_separate = true;
    value.appraiser_can_reopen_without_operator = true;
    value.collusion_model_declared = true;
    return value;
}

[[nodiscard]] OperatedCorpus corpus(const AdmissionTrace& trace) noexcept {
    OperatedCorpus value{};
    value.corpus_digest = digest(0xDCU);
    value.annex_digest = trace.annex.annex_digest;
    value.failure_corpus_spec_digest = trace.annex.failure_corpus_spec_digest;
    value.implementation_digest = trace.annex.implementation_digest;
    value.configuration_digest = trace.annex.configuration_digest;
    value.disposable_target_digest = digest(0xDEU);
    value.observed_scenario_mask = required_corpus_mask;
    value.present = true;
    value.canonical = true;
    value.complete = true;
    value.actual_not_synthetic = true;
    value.exact_binaries = true;
    value.exact_configuration = true;
    value.raw_traces_retained = true;
    value.independently_locatable = true;
    value.replayable = true;
    value.expected_outcomes_checked = true;
    value.disposable_target_separate = true;
    return value;
}

[[nodiscard]] AppraisalReceipt appraisal(const AdmissionTrace& trace) noexcept {
    AppraisalReceipt value{};
    value.appraisal_digest = digest(0xE0U);
    value.annex_digest = trace.annex.annex_digest;
    value.corpus_digest = trace.corpus.corpus_digest;
    value.separation_digest = trace.separation.separation_digest;
    value.appraiser_admin_digest = trace.separation.appraiser_admin_digest;
    value.appraisal_policy_digest = digest(0xE2U);
    value.present = true;
    value.authenticated = true;
    value.durable = true;
    value.no_replace_published = true;
    value.single_view = true;
    value.independently_reopenable = true;
    value.source_closed = true;
    value.independent_replay_performed = true;
    value.producer_not_appraiser = true;
    value.result_pass = true;
    return value;
}

[[nodiscard]] OwnerAdmission owner_admission(
    const AdmissionTrace& trace,
    const OwnerDecision decision = OwnerDecision::admit) noexcept {
    OwnerAdmission value{};
    value.admission_digest = digest(0xE4U);
    value.ratification_digest = trace.ratification.ratification_digest;
    value.appraisal_digest = trace.appraisal.appraisal_digest;
    value.parent_authorization_digest = trace.parent.authorization.authorization_digest;
    value.target_digest = trace.parent.target_digest;
    value.owner_root_digest = trace.constitution.owner_root_digest;
    value.decision = decision;
    value.present = true;
    value.authenticated = true;
    value.threshold_satisfied = true;
    value.durable = true;
    value.no_replace_published = true;
    value.single_view = true;
    value.independently_reopenable = true;
    value.current_root_observed = true;
    value.separately_governed = true;
    value.exact_predecessors_consumed = true;
    return value;
}

[[nodiscard]] AdmissionCut admission_cut(
    const std::size_t stage,
    const bool live = true,
    const bool deleted = false) noexcept {
    AdmissionCut value{};
    value.live_record_visible = live;
    value.owner_constitution_visible = true;
    value.annex_closed = stage >= 1U;
    value.ratification_visible = stage >= 2U;
    value.ratification_reopened = stage >= 3U;
    value.corpus_started = stage >= 4U;
    value.corpus_complete = stage >= 5U;
    value.appraisal_visible = stage >= 6U;
    value.appraisal_reopened = stage >= 7U;
    value.owner_admission_visible = stage >= 8U;
    value.owner_admission_reopened = stage >= 9U;
    value.record_deleted = deleted;
    return value;
}

[[nodiscard]] std::array<AdmissionCut, admission_cut_count> stopped_cuts(
    const std::size_t stage) noexcept {
    std::array<AdmissionCut, admission_cut_count> values{};
    for (std::size_t index = 0U; index < values.size(); ++index) {
        values[index] = admission_cut(std::min(index, stage));
    }
    return values;
}

[[nodiscard]] AdmissionTrace admission_trace(
    const OwnerDecision decision = OwnerDecision::admit,
    const TerminalKind kind = TerminalKind::effect) noexcept {
    AdmissionTrace trace{};
    trace.parent = base_trace(false, kind);
    trace.project_id = digest(0xC0U);
    trace.constitution = constitution(trace);
    trace.annex = annex(trace);
    trace.ratification = ratification(trace);
    trace.separation = separation(trace);
    trace.corpus = corpus(trace);
    trace.appraisal = appraisal(trace);
    trace.admission = owner_admission(trace, decision);
    trace.cuts = stopped_cuts(9U);
    trace.admission_requested = true;
    return trace;
}

struct TestCase final {
    std::string name;
    FateTrace trace;
    FateCode expected;
};

[[nodiscard]] ControlNode control_node(
    const Digest& identity,
    const NodeKind kind,
    const std::uint8_t evidence_seed) noexcept {
    ControlNode value{};
    value.node_digest = identity;
    value.evidence_digest = digest(evidence_seed);
    value.kind = kind;
    value.present = true;
    value.externally_identified = true;
    return value;
}

[[nodiscard]] GraphCut graph_cut(const std::size_t stage) noexcept {
    GraphCut value{};
    value.capsule_assembled = true;
    value.capsule_published = stage >= 1U;
    value.capsule_reopened = stage >= 2U;
    value.challenge_reopened = stage >= 3U;
    return value;
}

[[nodiscard]] std::array<GraphCut, graph_cut_count> stopped_graph_cuts(
    const std::size_t stage) noexcept {
    std::array<GraphCut, graph_cut_count> values{};
    for (std::size_t index = 0U; index < values.size(); ++index) {
        values[index] = graph_cut(std::min(index, stage));
    }
    return values;
}

[[nodiscard]] std::string hex_bytes(
    const std::array<std::uint8_t, max_canonical_binding_bytes>& bytes,
    const std::size_t size) {
    static constexpr char alphabet[] = "0123456789abcdef";
    std::string output;
    output.reserve(size * 2U);
    for (std::size_t index = 0U; index < size; ++index) {
        const auto value = bytes[index];
        output.push_back(alphabet[value >> 4U]);
        output.push_back(alphabet[value & 0x0FU]);
    }
    return output;
}

[[nodiscard]] std::string hex_digest(const Digest& value) {
    std::array<std::uint8_t, max_canonical_binding_bytes> bytes{};
    std::copy(value.begin(), value.end(), bytes.begin());
    return hex_bytes(bytes, value.size());
}

void seal_trace(FateTrace& trace) {
    trace.graph.graph_digest = canonical_graph_digest(trace.graph);
    trace.graph.publication_receipt_digest = trace.graph.no_replace_published
        ? publication_receipt_digest_for(trace.graph) : Digest{};
    trace.graph.challenge_receipt_digest = trace.graph.independently_challenged
        ? challenge_receipt_digest_for(trace.graph) : Digest{};
}

[[nodiscard]] FateTrace fate_trace() {
    FateTrace trace{};
    trace.parent = admission_trace();
    auto& graph = trace.graph;
    graph.parent_separation_digest = trace.parent.separation.separation_digest;
    graph.annex_digest = trace.parent.annex.annex_digest;
    graph.source_closure_digest = digest(0x07U);
    graph.inventory_scope_digest = digest(0x08U);
    graph.omitted_edge_policy_digest = digest(0x0AU);
    graph.present = true;
    graph.canonical = true;
    graph.complete_inventory_claim = true;
    graph.source_closed = true;
    graph.exact_parent_bound = true;
    graph.externally_supplied = true;
    graph.owner_ratified = true;
    graph.durable = true;
    graph.no_replace_published = true;
    graph.single_view = true;
    graph.independently_reopenable = true;
    graph.independently_challenged = true;
    graph.omitted_edge_policy_declared = true;

    const std::array<Digest, role_count> admin{{
        trace.parent.separation.mechanism_admin_digest,
        digest(0x91U),
        digest(0x94U),
        trace.parent.separation.reopener_admin_digest,
        trace.parent.separation.appraiser_admin_digest,
        trace.parent.separation.authorizer_admin_digest,
    }};
    const std::array<Digest, role_count> rollback{{
        trace.parent.separation.mechanism_rollback_digest,
        digest(0x92U),
        digest(0x95U),
        trace.parent.separation.reopener_rollback_digest,
        trace.parent.separation.appraiser_rollback_digest,
        trace.parent.separation.authorizer_rollback_digest,
    }};
    const std::array<Digest, role_count> view{{
        digest(0xA0U), digest(0xA1U), digest(0xA2U),
        digest(0xA3U), digest(0xA4U), digest(0xA5U),
    }};
    for (std::size_t role = 0U; role < role_count; ++role) {
        const std::size_t base = role * 3U;
        graph.nodes[base] = control_node(admin[role], NodeKind::role_leaf,
            static_cast<std::uint8_t>(0xB0U + role * 3U));
        graph.nodes[base + 1U] = control_node(rollback[role], NodeKind::role_leaf,
            static_cast<std::uint8_t>(0xB1U + role * 3U));
        graph.nodes[base + 2U] = control_node(view[role], NodeKind::role_leaf,
            static_cast<std::uint8_t>(0xB2U + role * 3U));
        graph.bindings[role] = RoleBinding{
            static_cast<Role>(role),
            static_cast<std::uint8_t>(base),
            static_cast<std::uint8_t>(base + 1U),
            static_cast<std::uint8_t>(base + 2U),
            digest(static_cast<std::uint8_t>(0xD0U + role)),
            true,
        };
    }
    graph.node_count = static_cast<std::uint8_t>(role_count * 3U);
    graph.binding_count = static_cast<std::uint8_t>(role_count);
    trace.cuts = stopped_graph_cuts(3U);
    seal_trace(trace);
    return trace;
}

[[nodiscard]] Digest controller_digest(const std::uint8_t seed) noexcept {
    Digest value = digest(seed);
    value.front() = static_cast<std::uint8_t>(value.front() ^ 0xA5U);
    value.back() = static_cast<std::uint8_t>(value.back() ^ 0x5AU);
    return value;
}

[[nodiscard]] std::uint8_t add_controller(
    FateTrace& trace,
    const NodeKind kind,
    const std::uint8_t seed) noexcept {
    const auto index = trace.graph.node_count;
    trace.graph.nodes[index] = control_node(controller_digest(seed), kind, static_cast<std::uint8_t>(seed + 0x21U));
    ++trace.graph.node_count;
    return index;
}

void add_edge(
    FateTrace& trace,
    const std::uint8_t controller,
    const std::uint8_t controlled,
    const std::uint8_t capability,
    const std::uint8_t seed) noexcept {
    auto& edge = trace.graph.edges[trace.graph.edge_count];
    edge.controller = controller;
    edge.controlled = controlled;
    edge.capability_mask = capability;
    edge.evidence_digest = digest(seed);
    edge.present = true;
    edge.externally_attested = true;
    ++trace.graph.edge_count;
}

[[nodiscard]] std::uint8_t leaf_for(
    const FateTrace& trace,
    const Role role,
    const std::uint8_t capability) noexcept {
    const auto& binding = trace.graph.bindings[static_cast<std::size_t>(role)];
    if (capability == administrative_capability) return binding.administrative_leaf;
    if (capability == rollback_capability) return binding.rollback_leaf;
    return binding.view_leaf;
}

void share_direct(
    FateTrace& trace,
    const Role left,
    const Role right,
    const std::uint8_t capability,
    const NodeKind kind,
    const std::uint8_t seed) noexcept {
    const auto controller = add_controller(trace, kind, seed);
    std::uint8_t edge_seed = static_cast<std::uint8_t>(seed + 1U);
    for (const auto bit : {administrative_capability, rollback_capability, shared_view_capability}) {
        if ((capability & bit) == 0U) continue;
        add_edge(trace, controller, leaf_for(trace, left, bit), bit, edge_seed++);
        add_edge(trace, controller, leaf_for(trace, right, bit), bit, edge_seed++);
    }
}

void share_transitive(
    FateTrace& trace,
    const Role left,
    const Role right,
    const std::uint8_t capability,
    const NodeKind kind,
    const std::uint8_t seed) noexcept {
    const auto root = add_controller(trace, kind, seed);
    const auto branch_left = add_controller(trace, NodeKind::external_controller,
        static_cast<std::uint8_t>(seed + 1U));
    const auto branch_right = add_controller(trace, NodeKind::external_controller,
        static_cast<std::uint8_t>(seed + 2U));
    add_edge(trace, root, branch_left, capability, static_cast<std::uint8_t>(seed + 3U));
    add_edge(trace, root, branch_right, capability, static_cast<std::uint8_t>(seed + 4U));
    add_edge(trace, branch_left, leaf_for(trace, left, capability), capability,
        static_cast<std::uint8_t>(seed + 5U));
    add_edge(trace, branch_right, leaf_for(trace, right, capability), capability,
        static_cast<std::uint8_t>(seed + 6U));
}

[[nodiscard]] bool accepted_code(const FateCode value) noexcept {
    return static_cast<std::uint8_t>(value)
        <= static_cast<std::uint8_t>(FateCode::accepted_refused_self_generated_capsule);
}

[[nodiscard]] std::string truth(const bool value) { return value ? "true" : "false"; }

[[nodiscard]] bool write_text(const std::filesystem::path& path, const std::string& text) {
    std::ofstream stream(path, std::ios::binary | std::ios::trunc);
    if (!stream) return false;
    stream.write(text.data(), static_cast<std::streamsize>(text.size()));
    return static_cast<bool>(stream);
}

[[nodiscard]] std::vector<TestCase> cases() {
    std::vector<TestCase> values;
    const auto add = [&values](std::string name, FateTrace trace, const FateCode expected) {
        seal_trace(trace);
        values.push_back(TestCase{std::move(name), std::move(trace), expected});
    };
    const auto add_raw = [&values](std::string name, FateTrace trace, const FateCode expected) {
        values.push_back(TestCase{std::move(name), std::move(trace), expected});
    };

    add("clean_minimal_supplied_closure", fate_trace(),
        FateCode::accepted_no_common_fate_found_in_supplied_closure);
    {
        auto trace = fate_trace();
        const auto controller = add_controller(trace, NodeKind::identity_root, 0x11U);
        add_edge(trace, controller, leaf_for(trace, Role::corpus_producer, administrative_capability),
            administrative_capability, 0x12U);
        add("clean_one_role_upstream_controller", trace,
            FateCode::accepted_no_common_fate_found_in_supplied_closure);
    }
    const std::array<std::pair<Role, Role>, 6U> allowed_pairs{{
        {Role::corpus_producer, Role::transparency_witness},
        {Role::corpus_producer, Role::independent_reopener},
        {Role::transparency_witness, Role::independent_reopener},
        {Role::transparency_witness, Role::appraiser},
        {Role::corpus_producer, Role::owner_admitter},
        {Role::independent_reopener, Role::owner_admitter},
    }};
    for (std::size_t index = 0U; index < allowed_pairs.size(); ++index) {
        auto trace = fate_trace();
        share_direct(trace, allowed_pairs[index].first, allowed_pairs[index].second,
            administrative_capability, NodeKind::policy_root,
            static_cast<std::uint8_t>(0x18U + index * 3U));
        add("clean_allowed_pair_admin_" + std::to_string(index), trace,
            FateCode::accepted_no_common_fate_found_in_supplied_closure);
    }
    {
        auto trace = fate_trace();
        const auto a = add_controller(trace, NodeKind::external_controller, 0x2AU);
        const auto b = add_controller(trace, NodeKind::external_controller, 0x2BU);
        add_edge(trace, a, b, administrative_capability, 0x2CU);
        add_edge(trace, b, a, administrative_capability, 0x2DU);
        add_edge(trace, a, leaf_for(trace, Role::corpus_producer, administrative_capability),
            administrative_capability, 0x2EU);
        add("clean_cycle_confined_to_one_role", trace,
            FateCode::accepted_no_common_fate_found_in_supplied_closure);
    }
    {
        auto trace = fate_trace();
        const auto controller = add_controller(trace, NodeKind::snapshot_authority, 0x35U);
        add_edge(trace, controller, leaf_for(trace, Role::mechanism_operator, administrative_capability),
            rollback_capability, 0x36U);
        add_edge(trace, controller, leaf_for(trace, Role::appraiser, administrative_capability),
            rollback_capability, 0x37U);
        add("clean_capability_does_not_jump_leaf_axis", trace,
            FateCode::accepted_no_common_fate_found_in_supplied_closure);
    }

    const std::array<std::pair<Role, Role>, required_pair_count> required{{
        {Role::mechanism_operator, Role::appraiser},
        {Role::corpus_producer, Role::appraiser},
        {Role::mechanism_operator, Role::owner_admitter},
        {Role::independent_reopener, Role::mechanism_operator},
        {Role::appraiser, Role::owner_admitter},
        {Role::transparency_witness, Role::owner_admitter},
    }};
    for (std::size_t index = 0U; index < required.size(); ++index) {
        auto direct = fate_trace();
        share_direct(direct, required[index].first, required[index].second,
            administrative_capability, NodeKind::identity_root,
            static_cast<std::uint8_t>(0x40U + index * 3U));
        add("admin_direct_required_pair_" + std::to_string(index), direct,
            FateCode::accepted_common_administrative_fate_detected);

        auto transitive = fate_trace();
        share_transitive(transitive, required[index].first, required[index].second,
            administrative_capability, NodeKind::cloud_control_plane,
            static_cast<std::uint8_t>(0x60U + index * 7U));
        add("admin_transitive_required_pair_" + std::to_string(index), transitive,
            FateCode::accepted_common_administrative_fate_detected);
    }
    const std::array<NodeKind, 6U> admin_kinds{{
        NodeKind::identity_root, NodeKind::policy_root, NodeKind::credential_recovery,
        NodeKind::deployment_controller, NodeKind::cloud_control_plane, NodeKind::owner_constitution_root,
    }};
    for (std::size_t index = 0U; index < admin_kinds.size(); ++index) {
        auto trace = fate_trace();
        share_direct(trace, Role::mechanism_operator, Role::appraiser,
            administrative_capability, admin_kinds[index],
            static_cast<std::uint8_t>(0x90U + index * 3U));
        add("admin_common_kind_" + std::to_string(index), trace,
            FateCode::accepted_common_administrative_fate_detected);
    }

    for (std::size_t index = 0U; index < required.size(); ++index) {
        auto direct = fate_trace();
        share_direct(direct, required[index].first, required[index].second,
            rollback_capability, NodeKind::snapshot_authority,
            static_cast<std::uint8_t>(0xC0U + index * 3U));
        add("rollback_direct_required_pair_" + std::to_string(index), direct,
            FateCode::accepted_common_rollback_fate_detected);

        auto transitive = fate_trace();
        share_transitive(transitive, required[index].first, required[index].second,
            rollback_capability, NodeKind::backup_authority,
            static_cast<std::uint8_t>(0xE0U + index * 7U));
        add("rollback_transitive_required_pair_" + std::to_string(index), transitive,
            FateCode::accepted_common_rollback_fate_detected);
    }

    for (std::size_t index = 0U; index < 4U; ++index) {
        auto trace = fate_trace();
        if ((index % 2U) == 0U) {
            share_direct(trace, Role::transparency_witness, Role::owner_admitter,
                shared_view_capability, index == 0U ? NodeKind::transparency_log : NodeKind::view_router,
                static_cast<std::uint8_t>(0x25U + index * 3U));
        } else {
            share_transitive(trace, Role::transparency_witness, Role::owner_admitter,
                shared_view_capability, NodeKind::view_router,
                static_cast<std::uint8_t>(0x25U + index * 7U));
        }
        add("view_common_fate_" + std::to_string(index), trace,
            FateCode::accepted_common_view_fate_detected);
    }

    for (std::size_t index = 0U; index < required.size(); ++index) {
        auto trace = fate_trace();
        share_direct(trace, required[index].first, required[index].second,
            administrative_capability, NodeKind::identity_root,
            static_cast<std::uint8_t>(0x51U + index * 5U));
        share_direct(trace, required[index].first, required[index].second,
            rollback_capability, NodeKind::snapshot_authority,
            static_cast<std::uint8_t>(0x53U + index * 5U));
        add("multiple_admin_rollback_pair_" + std::to_string(index), trace,
            FateCode::accepted_multiple_common_fates_detected);
    }
    {
        auto trace = fate_trace();
        share_direct(trace, Role::transparency_witness, Role::owner_admitter,
            administrative_capability | rollback_capability | shared_view_capability,
            NodeKind::cloud_control_plane, 0x79U);
        add("multiple_all_three_witness_owner", trace,
            FateCode::accepted_multiple_common_fates_detected);
    }
    {
        auto trace = fate_trace();
        share_direct(trace, Role::mechanism_operator, Role::appraiser,
            administrative_capability, NodeKind::identity_root, 0x7DU);
        share_direct(trace, Role::transparency_witness, Role::owner_admitter,
            shared_view_capability, NodeKind::transparency_log, 0x81U);
        add("multiple_different_pairs_different_fates", trace,
            FateCode::accepted_multiple_common_fates_detected);
    }

    const std::array<std::string, 7U> inventory_names{{
        "canonical_false", "complete_claim_false", "source_closed_false", "externally_supplied_false",
        "owner_ratified_false", "omitted_edge_policy_false", "source_claim_but_hidden_inputs",
    }};
    for (std::size_t index = 0U; index < inventory_names.size(); ++index) {
        auto trace = fate_trace();
        if (index == 0U) trace.graph.canonical = false;
        if (index == 1U) trace.graph.complete_inventory_claim = false;
        if (index == 2U || index == 6U) trace.graph.source_closed = false;
        if (index == 3U) trace.graph.externally_supplied = false;
        if (index == 4U) trace.graph.owner_ratified = false;
        if (index == 5U) trace.graph.omitted_edge_policy_declared = false;
        add("refuse_inventory_" + inventory_names[index], trace,
            FateCode::accepted_refused_inventory_open);
    }
    {
        auto trace = fate_trace();
        trace.graph.self_generated_by_candidate = true;
        trace.graph.externally_supplied = false;
        add("refuse_self_generated_capsule", trace,
            FateCode::accepted_refused_self_generated_capsule);
    }
    {
        auto trace = fate_trace(); trace.graph.durable = false;
        trace.graph.independently_reopenable = false; trace.graph.independently_challenged = false;
        trace.cuts = stopped_graph_cuts(0U);
        add("refuse_unpublished_not_durable", trace, FateCode::accepted_refused_capsule_unpublished);
    }
    {
        auto trace = fate_trace(); trace.graph.no_replace_published = false;
        trace.graph.independently_reopenable = false; trace.graph.independently_challenged = false;
        trace.cuts = stopped_graph_cuts(0U);
        add("refuse_unpublished_no_receipt", trace, FateCode::accepted_refused_capsule_unpublished);
    }
    {
        auto trace = fate_trace(); trace.graph.single_view = false;
        trace.graph.independently_reopenable = false; trace.graph.independently_challenged = false;
        trace.cuts = stopped_graph_cuts(0U);
        add("refuse_unpublished_split_view", trace, FateCode::accepted_refused_capsule_unpublished);
    }
    {
        auto trace = fate_trace(); trace.graph.independently_reopenable = false; trace.graph.independently_challenged = false;
        trace.cuts = stopped_graph_cuts(1U);
        add("refuse_not_independently_reopened", trace, FateCode::accepted_refused_capsule_not_reopened);
    }
    {
        auto trace = fate_trace(); trace.graph.independently_challenged = false; trace.cuts = stopped_graph_cuts(2U);
        add("refuse_not_independently_challenged", trace, FateCode::accepted_refused_capsule_unchallenged);
    }

    {
        auto trace = fate_trace(); trace.parent.project_id = digest(0xF1U);
        add("reject_parent_structural", trace, FateCode::parent_rejected);
    }
    {
        auto trace = fate_trace(); trace.parent = admission_trace(OwnerDecision::reject);
        trace.graph.parent_separation_digest = trace.parent.separation.separation_digest;
        trace.graph.annex_digest = trace.parent.annex.annex_digest;
        add("reject_parent_not_ready_owner_rejected", trace, FateCode::parent_not_ready_live);
    }
    {
        auto trace = fate_trace(); trace.graph.parent_separation_digest = digest(0xF2U);
        add("reject_parent_separation_binding", trace, FateCode::parent_separation_binding_mismatch);
    }
    {
        auto trace = fate_trace(); trace.graph.annex_digest = digest(0xF3U);
        add("reject_annex_binding", trace, FateCode::annex_binding_mismatch);
    }
    {
        auto trace = fate_trace(); trace.graph.present = false;
        add("reject_graph_absent", trace, FateCode::graph_shape_invalid);
    }
    {
        auto trace = fate_trace(); trace.graph.node_count = 0U;
        add("reject_graph_zero_nodes", trace, FateCode::graph_shape_invalid);
    }
    {
        auto trace = fate_trace(); trace.graph.nodes[0].present = false;
        add("reject_node_absent", trace, FateCode::node_shape_invalid);
    }
    {
        auto trace = fate_trace(); trace.graph.nodes[0].evidence_digest = Digest{};
        add("reject_node_evidence_zero", trace, FateCode::node_shape_invalid);
    }
    {
        auto trace = fate_trace(); trace.graph.nodes[1].node_digest = trace.graph.nodes[0].node_digest;
        add("reject_duplicate_node_digest", trace, FateCode::duplicate_node_digest);
    }
    {
        auto trace = fate_trace(); const auto c = add_controller(trace, NodeKind::identity_root, 0x16U);
        add_edge(trace, c, no_index, administrative_capability, 0x17U);
        add("reject_edge_endpoint", trace, FateCode::edge_shape_invalid);
    }
    {
        auto trace = fate_trace(); const auto c = add_controller(trace, NodeKind::identity_root, 0x19U);
        add_edge(trace, c, leaf_for(trace, Role::mechanism_operator, administrative_capability), 0U, 0x1AU);
        add("reject_edge_zero_capability", trace, FateCode::edge_shape_invalid);
    }
    {
        auto trace = fate_trace(); const auto c = add_controller(trace, NodeKind::identity_root, 0x1CU);
        add_edge(trace, c, leaf_for(trace, Role::mechanism_operator, administrative_capability), administrative_capability, 0x1DU);
        trace.graph.edges[0].externally_attested = false;
        add("reject_edge_unattested", trace, FateCode::edge_shape_invalid);
    }
    {
        auto trace = fate_trace(); const auto c = add_controller(trace, NodeKind::identity_root, 0x1FU);
        add_edge(trace, c, leaf_for(trace, Role::mechanism_operator, administrative_capability), administrative_capability, 0x20U);
        trace.graph.edges[1] = trace.graph.edges[0]; ++trace.graph.edge_count;
        add("reject_duplicate_edge", trace, FateCode::duplicate_edge);
    }
    {
        auto trace = fate_trace(); trace.graph.bindings[0].present = false;
        add("reject_binding_absent", trace, FateCode::binding_shape_invalid);
    }
    {
        auto trace = fate_trace(); trace.graph.bindings[0].administrative_leaf = no_index;
        add("reject_binding_out_of_range", trace, FateCode::binding_shape_invalid);
    }
    {
        auto trace = fate_trace(); trace.graph.nodes[0].kind = NodeKind::identity_root;
        add("reject_binding_nonleaf", trace, FateCode::binding_shape_invalid);
    }
    {
        auto trace = fate_trace(); trace.graph.bindings[1].role = Role::mechanism_operator;
        add("reject_binding_duplicate_role", trace, FateCode::binding_set_incomplete);
    }
    {
        auto trace = fate_trace(); trace.graph.nodes[0].node_digest = digest(0xF4U);
        add("reject_parent_leaf_mismatch", trace, FateCode::binding_leaf_mismatch);
    }
    {
        auto trace = fate_trace(); trace.graph.source_closure_digest = Digest{};
        add("reject_source_closure_digest_missing", trace, FateCode::source_closure_missing);
    }
    {
        auto trace = fate_trace(); trace.graph.publication_receipt_digest = Digest{};
        add_raw("reject_publication_receipt_missing", trace, FateCode::publication_receipt_missing);
    }
    {
        auto trace = fate_trace(); trace.graph.challenge_receipt_digest = Digest{};
        add_raw("reject_challenge_receipt_missing", trace, FateCode::challenge_receipt_missing);
    }
    {
        auto trace = fate_trace(); trace.graph.inventory_scope_digest = Digest{};
        add("reject_inventory_scope_digest_missing", trace, FateCode::inventory_scope_missing);
    }
    {
        auto trace = fate_trace(); trace.graph.omitted_edge_policy_digest = Digest{};
        add("reject_omitted_edge_policy_digest_missing", trace, FateCode::omitted_edge_policy_missing);
    }
    {
        auto trace = fate_trace(); std::swap(trace.graph.bindings[0], trace.graph.bindings[1]);
        add("reject_canonical_binding_order", trace, FateCode::canonical_binding_order_invalid);
    }
    {
        auto trace = fate_trace();
        trace.graph.nodes[trace.graph.node_count] = control_node(digest(0xE7U), NodeKind::external_controller, 0xE8U);
        add("reject_canonical_tail_hidden_node", trace, FateCode::canonical_tail_invalid);
    }
    {
        auto trace = fate_trace(); trace.graph.nodes[0].evidence_digest = digest(0xE9U);
        add_raw("reject_graph_digest_content_mutation", trace, FateCode::graph_digest_mismatch);
    }
    {
        auto trace = fate_trace(); trace.graph.complete_inventory_claim = false;
        add_raw("reject_graph_digest_claim_mutation", trace, FateCode::graph_digest_mismatch);
    }
    {
        auto trace = fate_trace(); trace.graph.publication_receipt_digest = digest(0xEAU);
        add_raw("reject_publication_receipt_subject_mismatch", trace,
            FateCode::publication_receipt_binding_mismatch);
    }
    {
        auto trace = fate_trace(); trace.graph.single_view = false; trace.cuts = stopped_graph_cuts(0U);
        add_raw("reject_publication_receipt_stale_after_flag_change", trace,
            FateCode::publication_receipt_binding_mismatch);
    }
    {
        auto trace = fate_trace(); trace.graph.challenge_receipt_digest = digest(0xEBU);
        add_raw("reject_challenge_receipt_subject_mismatch", trace,
            FateCode::challenge_receipt_binding_mismatch);
    }
    {
        auto trace = fate_trace(); trace.graph.single_view = false; trace.cuts = stopped_graph_cuts(0U);
        trace.graph.publication_receipt_digest = publication_receipt_digest_for(trace.graph);
        add_raw("reject_challenge_receipt_stale_after_publication_rebind", trace,
            FateCode::challenge_receipt_binding_mismatch);
    }
    {
        auto trace = fate_trace(); trace.cuts[1].capsule_reopened = true;
        add("reject_graph_cut_phase_collapse", trace, FateCode::graph_cut_order_invalid);
    }
    return values;
}

struct MonotoneCase final {
    std::string name;
    FateTrace base;
    FateTrace refuted;
    FateTrace extended;
};

[[nodiscard]] std::vector<MonotoneCase> monotone_cases() {
    std::vector<MonotoneCase> values;
    const std::array<std::pair<Role, Role>, required_pair_count> pairs{{
        {Role::mechanism_operator, Role::appraiser},
        {Role::corpus_producer, Role::appraiser},
        {Role::mechanism_operator, Role::owner_admitter},
        {Role::independent_reopener, Role::mechanism_operator},
        {Role::appraiser, Role::owner_admitter},
        {Role::transparency_witness, Role::owner_admitter},
    }};
    for (std::size_t index = 0U; index < pairs.size(); ++index) {
        for (const auto capability : {administrative_capability, rollback_capability}) {
            FateTrace base = fate_trace();
            FateTrace refuted = base;
            share_direct(refuted, pairs[index].first, pairs[index].second, capability,
                capability == administrative_capability ? NodeKind::identity_root : NodeKind::snapshot_authority,
                static_cast<std::uint8_t>(0x30U + index * 11U + capability));
            FateTrace extended = refuted;
            const auto extra = add_controller(extended, NodeKind::external_controller,
                static_cast<std::uint8_t>(0x32U + index * 11U + capability));
            add_edge(extended, extra, leaf_for(extended, Role::corpus_producer, shared_view_capability),
                shared_view_capability, static_cast<std::uint8_t>(0x33U + index * 11U + capability));
            seal_trace(base); seal_trace(refuted); seal_trace(extended);
            values.push_back(MonotoneCase{
                "pair_" + std::to_string(index) + (capability == administrative_capability ? "_admin" : "_rollback"),
                std::move(base), std::move(refuted), std::move(extended)});
        }
    }
    {
        FateTrace base = fate_trace(); FateTrace refuted = base;
        share_direct(refuted, Role::transparency_witness, Role::owner_admitter,
            shared_view_capability, NodeKind::transparency_log, 0xB8U);
        FateTrace extended = refuted;
        const auto extra = add_controller(extended, NodeKind::view_router, 0xBCU);
        add_edge(extended, extra, leaf_for(extended, Role::mechanism_operator, shared_view_capability),
            shared_view_capability, 0xBDU);
        seal_trace(base); seal_trace(refuted); seal_trace(extended);
        values.push_back(MonotoneCase{"witness_owner_view", std::move(base), std::move(refuted), std::move(extended)});
    }
    return values;
}

}  // namespace

FateTrace make_hosted_clean_fixture() {
    return fate_trace();
}

bool run_campaign(const std::filesystem::path& output_directory) {
    std::error_code error;
    std::filesystem::create_directories(output_directory, error);
    if (error) return false;

    const auto corpus = cases();
    std::string cases_tsv =
        "case\texpected\tcandidate\treference\tagreement\taccepted\tparent_ready\tgraph_valid\tscope_policy_bound\tcanonical_order_valid\tcanonical_tail_clear\tgraph_digest_bound\tpublication_receipt_bound\tchallenge_receipt_bound\tinventory_claim_closed\tpublication_valid\treopen_valid\tchallenge_valid\tcommon_admin\tcommon_rollback\tcommon_view\tany_common_fate\tno_common_fate_found\trequired_checks\trefuted_checks\tfirst_kind\tfirst_role_a\tfirst_role_b\tfirst_common_node\tmonotone_falsifier\tinventory_completeness_proved\ttransitive_independence_proved\tepoch_exit_proved\tauthority_granted\tlive_record_retained\n";
    std::string influence_tsv =
        "case\tjudgment\tfate_kind\trole_a\trole_b\tcommon_node\trefuted_checks\trequired_checks\n";
    std::string cuts_tsv =
        "case\tcut_index\tcut_name\tassembled\tpublished\treopened\tchallenged\n";
    std::string bindings_tsv =
        "case\tgraph_preimage_bytes\tgraph_preimage_hex\tgraph_recorded_sha256\tgraph_derived_sha256\tgraph_bound"
        "\tpublication_preimage_bytes\tpublication_preimage_hex\tpublication_recorded_sha256\tpublication_derived_sha256\tpublication_bound"
        "\tchallenge_preimage_bytes\tchallenge_preimage_hex\tchallenge_recorded_sha256\tchallenge_derived_sha256\tchallenge_bound\n";
    std::map<std::string, std::size_t> counts;
    std::size_t accepted = 0U;
    std::size_t disagreements = 0U;
    for (const auto& item : corpus) {
        const FateReport candidate = evaluate_candidate(item.trace);
        const FateReport reference = evaluate_reference(item.trace);
        const bool agreement = candidate == reference;
        if (!agreement) ++disagreements;
        if (!agreement || candidate.code != item.expected
            || candidate.accepted != accepted_code(item.expected)) {
            std::cerr << "CASE_MISMATCH name=" << item.name
                      << " expected=" << fate_code_name(item.expected)
                      << " candidate=" << fate_code_name(candidate.code)
                      << " reference=" << fate_code_name(reference.code)
                      << " agreement=" << truth(agreement) << '\n';
            return false;
        }
        if (candidate.accepted) ++accepted;
        ++counts[std::string(fate_code_name(candidate.code))];
        cases_tsv += item.name + "\t" + std::string(fate_code_name(item.expected)) + "\t"
            + std::string(fate_code_name(candidate.code)) + "\t"
            + std::string(fate_code_name(reference.code)) + "\t" + truth(agreement)
            + "\t" + truth(candidate.accepted) + "\t" + truth(candidate.parent_ready_live_retained)
            + "\t" + truth(candidate.graph_shape_valid)
            + "\t" + truth(candidate.scope_policy_bound)
            + "\t" + truth(candidate.canonical_order_valid)
            + "\t" + truth(candidate.canonical_tail_clear)
            + "\t" + truth(candidate.graph_digest_bound)
            + "\t" + truth(candidate.publication_receipt_bound)
            + "\t" + truth(candidate.challenge_receipt_bound)
            + "\t" + truth(candidate.inventory_claim_closed)
            + "\t" + truth(candidate.publication_valid) + "\t" + truth(candidate.reopen_valid)
            + "\t" + truth(candidate.challenge_valid) + "\t" + truth(candidate.common_administrative_fate_detected)
            + "\t" + truth(candidate.common_rollback_fate_detected) + "\t" + truth(candidate.common_view_fate_detected)
            + "\t" + truth(candidate.any_common_fate_detected)
            + "\t" + truth(candidate.no_common_fate_found_in_supplied_closure)
            + "\t" + std::to_string(candidate.required_checks) + "\t" + std::to_string(candidate.refuted_checks)
            + "\t" + std::string(fate_kind_name(candidate.first_fate_kind))
            + "\t" + std::string(role_name(candidate.first_role_a))
            + "\t" + std::string(role_name(candidate.first_role_b))
            + "\t" + std::to_string(candidate.first_common_node)
            + "\t" + truth(candidate.monotone_falsifier)
            + "\t" + truth(candidate.inventory_completeness_proved)
            + "\t" + truth(candidate.transitive_independence_proved)
            + "\t" + truth(candidate.epoch_exit_proved) + "\t" + truth(candidate.authority_granted)
            + "\t" + truth(candidate.live_record_must_be_retained) + "\n";
        influence_tsv += item.name + "\t" + std::string(fate_code_name(candidate.code))
            + "\t" + std::string(fate_kind_name(candidate.first_fate_kind))
            + "\t" + std::string(role_name(candidate.first_role_a))
            + "\t" + std::string(role_name(candidate.first_role_b))
            + "\t" + std::to_string(candidate.first_common_node)
            + "\t" + std::to_string(candidate.refuted_checks)
            + "\t" + std::to_string(candidate.required_checks) + "\n";
        const auto graph_preimage = canonical_graph_preimage(item.trace.graph);
        const auto publication_preimage = publication_receipt_preimage(item.trace.graph);
        const auto challenge_preimage = challenge_receipt_preimage(item.trace.graph);
        const auto graph_derived = canonical_graph_digest(item.trace.graph);
        const auto publication_derived = publication_receipt_digest_for(item.trace.graph);
        const auto challenge_derived = challenge_receipt_digest_for(item.trace.graph);
        bindings_tsv += item.name
            + "\t" + std::to_string(graph_preimage.size)
            + "\t" + hex_bytes(graph_preimage.bytes, graph_preimage.size)
            + "\t" + hex_digest(item.trace.graph.graph_digest)
            + "\t" + hex_digest(graph_derived)
            + "\t" + truth(item.trace.graph.graph_digest == graph_derived)
            + "\t" + std::to_string(publication_preimage.size)
            + "\t" + hex_bytes(publication_preimage.bytes, publication_preimage.size)
            + "\t" + hex_digest(item.trace.graph.publication_receipt_digest)
            + "\t" + hex_digest(publication_derived)
            + "\t" + truth(item.trace.graph.publication_receipt_digest == publication_derived)
            + "\t" + std::to_string(challenge_preimage.size)
            + "\t" + hex_bytes(challenge_preimage.bytes, challenge_preimage.size)
            + "\t" + hex_digest(item.trace.graph.challenge_receipt_digest)
            + "\t" + hex_digest(challenge_derived)
            + "\t" + truth(item.trace.graph.challenge_receipt_digest == challenge_derived)
            + "\n";
        for (std::size_t index = 0U; index < item.trace.cuts.size(); ++index) {
            const auto& cut = item.trace.cuts[index];
            cuts_tsv += item.name + "\t" + std::to_string(index) + "\t"
                + std::string(graph_cut_name(index)) + "\t" + truth(cut.capsule_assembled)
                + "\t" + truth(cut.capsule_published) + "\t" + truth(cut.capsule_reopened)
                + "\t" + truth(cut.challenge_reopened) + "\n";
        }
    }

    std::string monotonicity = "case\tbase_no_common\trefuted_detected\textended_detected\tadding_edges_repaired_refutation\tstatus\n";
    std::size_t monotone_rows = 0U;
    for (const auto& item : monotone_cases()) {
        const FateReport base = evaluate_candidate(item.base);
        const FateReport refuted = evaluate_candidate(item.refuted);
        const FateReport extended = evaluate_candidate(item.extended);
        const bool pass = base.no_common_fate_found_in_supplied_closure
            && refuted.any_common_fate_detected && extended.any_common_fate_detected;
        if (!pass) return false;
        ++monotone_rows;
        monotonicity += item.name + "\t" + truth(base.no_common_fate_found_in_supplied_closure)
            + "\t" + truth(refuted.any_common_fate_detected)
            + "\t" + truth(extended.any_common_fate_detected)
            + "\tfalse\tPASS\n";
    }

    const auto count = [&counts](const std::string_view name) -> std::size_t {
        const auto found = counts.find(std::string(name));
        return found == counts.end() ? 0U : found->second;
    };
    const std::size_t common_fate = count("accepted_common_administrative_fate_detected")
        + count("accepted_common_rollback_fate_detected")
        + count("accepted_common_view_fate_detected")
        + count("accepted_multiple_common_fates_detected");
    const std::size_t refused = count("accepted_refused_inventory_open")
        + count("accepted_refused_capsule_unpublished") + count("accepted_refused_capsule_not_reopened")
        + count("accepted_refused_capsule_unchallenged") + count("accepted_refused_self_generated_capsule");
    const std::string summary = "{\n"
        "  \"accepted_cases\": " + std::to_string(accepted) + ",\n"
        "  \"authority_granted\": false,\n"
        "  \"candidate_reference_disagreements\": " + std::to_string(disagreements) + ",\n"
        "  \"canonical_binding_vectors\": " + std::to_string(corpus.size()) + ",\n"
        "  \"cases\": " + std::to_string(corpus.size()) + ",\n"
        "  \"common_administrative_fate_cases\": " + std::to_string(count("accepted_common_administrative_fate_detected")) + ",\n"
        "  \"common_fate_detected_cases\": " + std::to_string(common_fate) + ",\n"
        "  \"common_rollback_fate_cases\": " + std::to_string(count("accepted_common_rollback_fate_detected")) + ",\n"
        "  \"common_view_fate_cases\": " + std::to_string(count("accepted_common_view_fate_detected")) + ",\n"
        "  \"epoch_exit_proved\": false,\n"
        "  \"external_occurrence_proved\": false,\n"
        "  \"fourth_semantic_island\": false,\n"
        "  \"graph_cuts\": " + std::to_string(corpus.size() * graph_cut_count) + ",\n"
        "  \"inventory_completeness_proved\": false,\n"
        "  \"monotonicity_rows\": " + std::to_string(monotone_rows) + ",\n"
        "  \"multiple_fate_cases\": " + std::to_string(count("accepted_multiple_common_fates_detected")) + ",\n"
        "  \"no_common_fate_found_cases\": " + std::to_string(count("accepted_no_common_fate_found_in_supplied_closure")) + ",\n"
        "  \"premise_refused_cases\": " + std::to_string(refused) + ",\n"
        "  \"canonical_binding_rejected_cases\": " + std::to_string(
            count("inventory_scope_missing") + count("omitted_edge_policy_missing")
            + count("canonical_binding_order_invalid") + count("canonical_tail_invalid")
            + count("graph_digest_mismatch") + count("publication_receipt_missing")
            + count("publication_receipt_binding_mismatch") + count("challenge_receipt_missing")
            + count("challenge_receipt_binding_mismatch")) + ",\n"
        "  \"rejected_cases\": " + std::to_string(corpus.size() - accepted) + ",\n"
        "  \"schema\": \"slopos.rev0921.control-fate-falsification-campaign.v2\",\n"
        "  \"status\": \"PASS\",\n"
        "  \"transitive_independence_proved\": false\n"
        "}\n";

    const std::string laws =
        "law\tstatement\tmechanical_status\n"
        "CFFL01\tpairwise-distinct leaf digests do not exclude a shared upstream controller\tENFORCED\n"
        "CFFL02\tcontrol influence is transitive over typed controller-to-controlled edges\tENFORCED\n"
        "CFFL03\tadministrative, rollback, and shared-view fate are separate capabilities\tENFORCED\n"
        "CFFL04\ta common upstream fate refutes the affected separation claim\tENFORCED\n"
        "CFFL05\tadding control edges cannot repair an already-refuted claim\tENFORCED\n"
        "CFFL06\tno common fate found means only no witness in the supplied closure\tENFORCED\n"
        "CFFL07\tinventory completeness remains an external premise\tENFORCED\n"
        "CFFL08\tthe graph must bind the exact parent separation and annex\tENFORCED\n"
        "CFFL09\tpublication, independent reopen, and independent challenge are ordered objects\tENFORCED\n"
        "CFFL10\tthe live terminal record remains retained\tENFORCED\n"
        "CFFL11\tthe falsifier grants no authority and proves no epoch exit\tENFORCED\n"
        "CFFL12\tprovider runtime and a fourth semantic island remain absent\tREPOSITORY_GATE\n"
        "CFFL13\tthe graph digest is SHA-256 over one domain-separated exact counted preimage\tENFORCED\n"
        "CFFL14\tbinding order and unused array tails fail closed before graph evaluation\tENFORCED\n"
        "CFFL15\tthe publication receipt binds graph scope policy and publication proposition\tENFORCED\n"
        "CFFL16\tthe challenge receipt binds graph publication scope policy and challenge proposition\tENFORCED\n";
    const std::string countermodels =
        "countermodel\thidden_common_root\told_leaf_test\tnew_falsifier\n"
        "CFM01\tfour distinct keys under one IAM tenant\tPASS\tREFUTE_ADMIN\n"
        "CFM02\tfour services restored by one snapshot controller\tPASS\tREFUTE_ROLLBACK\n"
        "CFM03\tseparate witnesses behind one view router\tPASS\tREFUTE_VIEW\n"
        "CFM04\tseparate process labels under one deployment controller\tPASS\tREFUTE_ADMIN\n"
        "CFM05\tseparate credentials recoverable by one escrow\tPASS\tREFUTE_ADMIN\n"
        "CFM06\tseparate databases under one backup authority\tPASS\tREFUTE_ROLLBACK\n"
        "CFM07\tseparate machines under one cloud control plane\tPASS\tREFUTE_MULTIPLE\n"
        "CFM08\tcomplete-looking graph omits the upstream edge\tPASS\tINVENTORY_PREMISE_OPEN\n"
        "CFM09\tnonzero graph digest copied from a different counted graph\tPASS\tREFUTE_GRAPH_BINDING\n"
        "CFM10\tclaim flag changed after graph sealing\tPASS\tREFUTE_GRAPH_BINDING\n"
        "CFM11\tpublication receipt reused after proposition change\tPASS\tREFUTE_PUBLICATION_BINDING\n"
        "CFM12\tchallenge receipt reused after publication rebind\tPASS\tREFUTE_CHALLENGE_BINDING\n";

    return disagreements == 0U
        && write_text(output_directory / "CASES.tsv", cases_tsv)
        && write_text(output_directory / "INFLUENCE.tsv", influence_tsv)
        && write_text(output_directory / "MONOTONICITY.tsv", monotonicity)
        && write_text(output_directory / "GRAPH-CUTS.tsv", cuts_tsv)
        && write_text(output_directory / "CANONICAL-BINDINGS.tsv", bindings_tsv)
        && write_text(output_directory / "LAWS.tsv", laws)
        && write_text(output_directory / "COUNTERMODELS.tsv", countermodels)
        && write_text(output_directory / "SUMMARY.json", summary);
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification
