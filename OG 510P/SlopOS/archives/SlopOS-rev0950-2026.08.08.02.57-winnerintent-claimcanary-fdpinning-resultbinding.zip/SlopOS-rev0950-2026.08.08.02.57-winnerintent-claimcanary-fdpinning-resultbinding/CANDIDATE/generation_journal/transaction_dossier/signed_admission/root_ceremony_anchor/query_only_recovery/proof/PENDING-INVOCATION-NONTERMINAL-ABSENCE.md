# Pending invocation: absence is not terminal no-effect

The counterhistory is a prefix-extension argument rather than a storage-format
claim.

```text
P0  compare_apply(request R) is invoked
P1  exact linearizable query reads no record for R
H0  R never commits
H1  the still-pending invocation for R commits after P1
```

`P0;P1` is the same observable prefix of `H0` and `H1`. Any classifier that
returns terminal `NO_EFFECT` at `P1` is wrong in `H1`. A deterministic request
ID prevents proposition drift but does not remove the pending invocation.
Durable duplicate-result retention helps after commit but does not make a
pre-commit absent read terminal.

The repair is not “query again until comfortable.” It is either:

- remain query-only until an exact committed result is durable; or
- execute an atomic retirement operation that serializes against the original
  compare/apply, durably records the exact negative result, and fences every
  possible late commit.

That retirement operation is an external premise. The hosted relation merely
states and differentially tests its minimum proof obligations.
