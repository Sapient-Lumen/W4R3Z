# Signed-admission countermodels

## C1 — coherent self-constitution

An attacker chooses three Ed25519 keys, writes a syntactically exact manifest,
sets its own project and constitution identifiers, signs a dossier-bound
statement with two keys, and supplies all bytes together. Every cryptographic
and structural check passes. No fact connects that manifest to SlopOS owners.
Therefore signature validity under a supplied manifest cannot imply owner
constitution or authority.

## C2 — same-custody threshold

One administrator or compromised process may control all three private keys.
Two distinct public keys and two valid signatures prove two mathematical key
relations, not two separately governed custody roots. Threshold count and
administrative independence are different predicates.

## C3 — valid but stale branch

A manifest and statement may remain cryptographically valid after a successor
root, revocation, compromise, or rollback. The encoded time window narrows one
claim but does not establish current trusted-root state. Currentness requires a
rooted succession/revocation relation outside the supplied bundle.

## C4 — replay into cloned histories

Two restored copies receive identical manifest, envelope, dossier, and observed
time. Each performs its local first validation and accepts the evidence. No
signature verification mutates a shared rejection fact. Global one-use remains
false.

## C5 — verifier/channel substitution

A library result or detached response can be copied or forged by a caller unless
the system owns executable identity, library identity, endpoints, process
lifecycle, exact request/response correlation, and one-use endorsement. The
capsule verifies signatures in-process and therefore claims none of those
custody facts.

## C6 — purpose confusion

A valid signature over different bytes or a different terminal statement is
invalid here because the signing domain, statement length, purpose, terminal
scope, and all exact statement bytes are signed. This closes a byte-substitution
class but does not close constitution, currentness, or spend.
