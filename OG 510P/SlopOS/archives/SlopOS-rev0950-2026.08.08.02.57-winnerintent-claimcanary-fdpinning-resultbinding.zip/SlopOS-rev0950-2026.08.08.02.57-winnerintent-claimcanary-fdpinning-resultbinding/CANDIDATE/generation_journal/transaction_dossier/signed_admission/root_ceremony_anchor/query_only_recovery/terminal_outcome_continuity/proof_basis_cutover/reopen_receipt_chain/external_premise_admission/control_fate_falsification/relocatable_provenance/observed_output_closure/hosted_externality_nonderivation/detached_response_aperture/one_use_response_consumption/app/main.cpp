#include "slopos/e0/detached_response_aperture/one_use_response_consumption.hpp"
#include <filesystem>
#include <iostream>
int main(int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "usage: slopos_one_use_response_consumption OUTPUT_DIRECTORY\n";
        return 2;
    }
    return slopos::e0::detached_response_aperture::one_use_response_consumption::run_campaign(std::filesystem::path(argv[1])) ? 0 : 1;
}
