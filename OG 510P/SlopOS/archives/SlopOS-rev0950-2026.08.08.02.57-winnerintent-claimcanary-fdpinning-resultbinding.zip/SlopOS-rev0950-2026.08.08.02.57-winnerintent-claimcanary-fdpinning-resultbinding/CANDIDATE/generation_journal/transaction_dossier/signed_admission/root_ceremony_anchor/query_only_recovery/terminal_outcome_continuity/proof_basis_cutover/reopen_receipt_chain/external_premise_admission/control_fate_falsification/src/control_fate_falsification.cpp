#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/reopen_receipt_chain/external_premise_admission/control_fate_falsification.hpp"
#include "slopos/e0/generation_journal/spend_record.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <span>
#include <string_view>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification {
namespace {

struct RequiredPair final {
    Role left;
    Role right;
    std::uint8_t capability_mask;
};

inline constexpr std::array<RequiredPair, required_pair_count> required_pairs{{
    {Role::mechanism_operator, Role::appraiser, administrative_capability | rollback_capability},
    {Role::corpus_producer, Role::appraiser, administrative_capability | rollback_capability},
    {Role::mechanism_operator, Role::owner_admitter, administrative_capability | rollback_capability},
    {Role::independent_reopener, Role::mechanism_operator, administrative_capability | rollback_capability},
    {Role::appraiser, Role::owner_admitter, administrative_capability | rollback_capability},
    {Role::transparency_witness, Role::owner_admitter,
        administrative_capability | rollback_capability | shared_view_capability},
}};

[[nodiscard]] bool nonzero(const Digest& value) noexcept {
    for (const auto byte : value) {
        if (byte != 0U) return true;
    }
    return false;
}

[[nodiscard]] constexpr std::size_t role_index(const Role value) noexcept {
    return static_cast<std::size_t>(value);
}

[[nodiscard]] const RoleBinding* binding_for(
    const ControlGraphCapsule& graph,
    const Role role) noexcept {
    for (std::size_t index = 0U; index < graph.binding_count; ++index) {
        if (graph.bindings[index].role == role) return &graph.bindings[index];
    }
    return nullptr;
}

[[nodiscard]] std::uint8_t leaf_for(
    const RoleBinding& binding,
    const std::uint8_t capability) noexcept {
    if (capability == administrative_capability) return binding.administrative_leaf;
    if (capability == rollback_capability) return binding.rollback_leaf;
    return binding.view_leaf;
}

[[nodiscard]] bool cuts_are_exact(const FateTrace& trace) noexcept {
    std::uint8_t final_stage = 0U;
    if (trace.graph.no_replace_published && trace.graph.durable && trace.graph.single_view) final_stage = 1U;
    if (final_stage == 1U && trace.graph.independently_reopenable) final_stage = 2U;
    if (final_stage == 2U && trace.graph.independently_challenged) final_stage = 3U;
    for (std::size_t index = 0U; index < trace.cuts.size(); ++index) {
        const std::uint8_t stage = static_cast<std::uint8_t>(index < final_stage ? index : final_stage);
        const GraphCut expected{
            true,
            stage >= 1U,
            stage >= 2U,
            stage >= 3U,
        };
        if (!(trace.cuts[index] == expected)) return false;
    }
    return true;
}

[[nodiscard]] bool unique_nodes(const ControlGraphCapsule& graph) noexcept {
    for (std::size_t left = 0U; left < graph.node_count; ++left) {
        for (std::size_t right = left + 1U; right < graph.node_count; ++right) {
            if (graph.nodes[left].node_digest == graph.nodes[right].node_digest) return false;
        }
    }
    return true;
}

[[nodiscard]] bool unique_edges(const ControlGraphCapsule& graph) noexcept {
    for (std::size_t left = 0U; left < graph.edge_count; ++left) {
        for (std::size_t right = left + 1U; right < graph.edge_count; ++right) {
            const auto& a = graph.edges[left];
            const auto& b = graph.edges[right];
            if (a.controller == b.controller && a.controlled == b.controlled
                && a.capability_mask == b.capability_mask) return false;
        }
    }
    return true;
}

[[nodiscard]] bool role_bindings_complete(const ControlGraphCapsule& graph) noexcept {
    std::array<bool, role_count> seen{};
    for (std::size_t index = 0U; index < graph.binding_count; ++index) {
        const auto role = role_index(graph.bindings[index].role);
        if (role >= seen.size() || seen[role]) return false;
        seen[role] = true;
    }
    for (const bool value : seen) {
        if (!value) return false;
    }
    return true;
}

[[nodiscard]] bool parent_leaf_bindings_match(
    const FateTrace& trace) noexcept {
    struct ParentLeaf final {
        Role role;
        Digest administrative;
        Digest rollback;
    };
    const std::array<ParentLeaf, 4U> expected{{
        {Role::mechanism_operator, trace.parent.separation.mechanism_admin_digest,
            trace.parent.separation.mechanism_rollback_digest},
        {Role::independent_reopener, trace.parent.separation.reopener_admin_digest,
            trace.parent.separation.reopener_rollback_digest},
        {Role::appraiser, trace.parent.separation.appraiser_admin_digest,
            trace.parent.separation.appraiser_rollback_digest},
        {Role::owner_admitter, trace.parent.separation.authorizer_admin_digest,
            trace.parent.separation.authorizer_rollback_digest},
    }};
    for (const auto& item : expected) {
        const auto* binding = binding_for(trace.graph, item.role);
        if (binding == nullptr) return false;
        if (trace.graph.nodes[binding->administrative_leaf].node_digest != item.administrative) return false;
        if (trace.graph.nodes[binding->rollback_leaf].node_digest != item.rollback) return false;
    }
    return true;
}

[[nodiscard]] std::array<bool, max_control_nodes> upstream_set(
    const ControlGraphCapsule& graph,
    const std::uint8_t leaf,
    const std::uint8_t capability) noexcept {
    std::array<bool, max_control_nodes> reached{};
    std::array<std::uint8_t, max_control_nodes> stack{};
    std::size_t stack_size = 0U;
    reached[leaf] = true;
    stack[stack_size++] = leaf;
    while (stack_size != 0U) {
        const auto controlled = stack[--stack_size];
        for (std::size_t index = 0U; index < graph.edge_count; ++index) {
            const auto& edge = graph.edges[index];
            if (edge.controlled != controlled || (edge.capability_mask & capability) == 0U) continue;
            if (!reached[edge.controller]) {
                reached[edge.controller] = true;
                stack[stack_size++] = edge.controller;
            }
        }
    }
    return reached;
}

[[nodiscard]] FateReport rejected(
    const FateCode code,
    const bool parent_accepted = false,
    const bool parent_ready = false) noexcept {
    FateReport report{};
    report.code = code;
    report.parent_accepted = parent_accepted;
    report.parent_ready_live_retained = parent_ready;
    return report;
}


[[nodiscard]] constexpr std::array<std::uint8_t, 32U> binding_domain(
    const std::string_view label) noexcept {
    std::array<std::uint8_t, 32U> output{};
    for (std::size_t index = 0U; index < label.size() && index < output.size(); ++index) {
        output[index] = static_cast<std::uint8_t>(label[index]);
    }
    return output;
}

inline constexpr auto graph_binding_domain = binding_domain("SlopOS/cff/graph/v2");
inline constexpr auto publication_binding_domain = binding_domain("SlopOS/cff/publish/v1");
inline constexpr auto challenge_binding_domain = binding_domain("SlopOS/cff/challenge/v1");

struct BindingWriter final {
    CanonicalBindingBytes output{};

    void byte(const std::uint8_t value) noexcept {
        if (output.size < output.bytes.size()) output.bytes[output.size++] = value;
    }

    void boolean(const bool value) noexcept { byte(value ? 1U : 0U); }

    template <std::size_t Extent>
    void bytes(const std::array<std::uint8_t, Extent>& value) noexcept {
        for (const auto item : value) byte(item);
    }
};

[[nodiscard]] bool binding_order_is_exact(const ControlGraphCapsule& graph) noexcept {
    for (std::size_t index = 0U; index < graph.binding_count; ++index) {
        if (static_cast<std::size_t>(graph.bindings[index].role) != index) return false;
    }
    return true;
}

template <typename Value, std::size_t Extent>
[[nodiscard]] bool unused_tail_is_clear(
    const std::array<Value, Extent>& values,
    const std::size_t count) noexcept {
    for (std::size_t index = count; index < values.size(); ++index) {
        if (!(values[index] == Value{})) return false;
    }
    return true;
}

[[nodiscard]] bool all_unused_tails_are_clear(const ControlGraphCapsule& graph) noexcept {
    return unused_tail_is_clear(graph.nodes, graph.node_count)
        && unused_tail_is_clear(graph.edges, graph.edge_count)
        && unused_tail_is_clear(graph.bindings, graph.binding_count);
}

}  // namespace

CanonicalBindingBytes canonical_graph_preimage(const ControlGraphCapsule& graph) {
    BindingWriter writer{};
    writer.bytes(graph_binding_domain);
    writer.bytes(graph.parent_separation_digest);
    writer.bytes(graph.annex_digest);
    writer.bytes(graph.source_closure_digest);
    writer.bytes(graph.inventory_scope_digest);
    writer.bytes(graph.omitted_edge_policy_digest);
    writer.byte(graph.node_count);
    writer.byte(graph.edge_count);
    writer.byte(graph.binding_count);
    writer.boolean(graph.present);
    writer.boolean(graph.canonical);
    writer.boolean(graph.complete_inventory_claim);
    writer.boolean(graph.source_closed);
    writer.boolean(graph.exact_parent_bound);
    writer.boolean(graph.externally_supplied);
    writer.boolean(graph.owner_ratified);
    writer.boolean(graph.omitted_edge_policy_declared);
    writer.boolean(graph.self_generated_by_candidate);
    const auto node_limit = std::min<std::size_t>(graph.node_count, graph.nodes.size());
    for (std::size_t index = 0U; index < node_limit; ++index) {
        const auto& node = graph.nodes[index];
        writer.bytes(node.node_digest);
        writer.bytes(node.evidence_digest);
        writer.byte(static_cast<std::uint8_t>(node.kind));
        writer.boolean(node.present);
        writer.boolean(node.externally_identified);
    }
    const auto edge_limit = std::min<std::size_t>(graph.edge_count, graph.edges.size());
    for (std::size_t index = 0U; index < edge_limit; ++index) {
        const auto& edge = graph.edges[index];
        writer.byte(edge.controller);
        writer.byte(edge.controlled);
        writer.byte(edge.capability_mask);
        writer.bytes(edge.evidence_digest);
        writer.boolean(edge.present);
        writer.boolean(edge.externally_attested);
    }
    const auto binding_limit = std::min<std::size_t>(graph.binding_count, graph.bindings.size());
    for (std::size_t index = 0U; index < binding_limit; ++index) {
        const auto& binding = graph.bindings[index];
        writer.byte(static_cast<std::uint8_t>(binding.role));
        writer.byte(binding.administrative_leaf);
        writer.byte(binding.rollback_leaf);
        writer.byte(binding.view_leaf);
        writer.bytes(binding.binding_digest);
        writer.boolean(binding.present);
    }
    return writer.output;
}

CanonicalBindingBytes publication_receipt_preimage(const ControlGraphCapsule& graph) {
    BindingWriter writer{};
    writer.bytes(publication_binding_domain);
    writer.bytes(graph.graph_digest);
    writer.bytes(graph.source_closure_digest);
    writer.bytes(graph.inventory_scope_digest);
    writer.bytes(graph.omitted_edge_policy_digest);
    writer.boolean(graph.durable);
    writer.boolean(graph.no_replace_published);
    writer.boolean(graph.single_view);
    return writer.output;
}

CanonicalBindingBytes challenge_receipt_preimage(const ControlGraphCapsule& graph) {
    BindingWriter writer{};
    writer.bytes(challenge_binding_domain);
    writer.bytes(graph.graph_digest);
    writer.bytes(graph.publication_receipt_digest);
    writer.bytes(graph.source_closure_digest);
    writer.bytes(graph.inventory_scope_digest);
    writer.bytes(graph.omitted_edge_policy_digest);
    writer.boolean(graph.independently_reopenable);
    writer.boolean(graph.independently_challenged);
    return writer.output;
}

Digest canonical_graph_digest(const ControlGraphCapsule& graph) {
    const auto preimage = canonical_graph_preimage(graph);
    return generation_journal::sha256(std::span<const std::uint8_t>(preimage.bytes.data(), preimage.size));
}

Digest publication_receipt_digest_for(const ControlGraphCapsule& graph) {
    const auto preimage = publication_receipt_preimage(graph);
    return generation_journal::sha256(std::span<const std::uint8_t>(preimage.bytes.data(), preimage.size));
}

Digest challenge_receipt_digest_for(const ControlGraphCapsule& graph) {
    const auto preimage = challenge_receipt_preimage(graph);
    return generation_journal::sha256(std::span<const std::uint8_t>(preimage.bytes.data(), preimage.size));
}

FateReport evaluate_candidate(const FateTrace& trace) {
    const auto parent = external_premise_admission::evaluate_candidate(trace.parent);
    if (!parent.accepted) return rejected(FateCode::parent_rejected);
    if (!parent.external_premise_dossier_ready || !parent.live_record_must_be_retained) {
        return rejected(FateCode::parent_not_ready_live, true, false);
    }
    if (!trace.graph.present || trace.graph.node_count == 0U
        || trace.graph.node_count > max_control_nodes || trace.graph.edge_count > max_control_edges
        || trace.graph.binding_count != role_count) {
        return rejected(FateCode::graph_shape_invalid, true, true);
    }
    if (!trace.graph.exact_parent_bound
        || trace.graph.parent_separation_digest != trace.parent.separation.separation_digest) {
        return rejected(FateCode::parent_separation_binding_mismatch, true, true);
    }
    if (trace.graph.annex_digest != trace.parent.annex.annex_digest) {
        return rejected(FateCode::annex_binding_mismatch, true, true);
    }
    for (std::size_t index = 0U; index < trace.graph.node_count; ++index) {
        const auto& node = trace.graph.nodes[index];
        if (!node.present || !node.externally_identified || !nonzero(node.node_digest)
            || !nonzero(node.evidence_digest)) {
            return rejected(FateCode::node_shape_invalid, true, true);
        }
    }
    if (!unique_nodes(trace.graph)) return rejected(FateCode::duplicate_node_digest, true, true);
    for (std::size_t index = 0U; index < trace.graph.edge_count; ++index) {
        const auto& edge = trace.graph.edges[index];
        if (!edge.present || !edge.externally_attested || edge.controller >= trace.graph.node_count
            || edge.controlled >= trace.graph.node_count || edge.controller == edge.controlled
            || edge.capability_mask == 0U || (edge.capability_mask & ~all_capabilities) != 0U
            || !nonzero(edge.evidence_digest)) {
            return rejected(FateCode::edge_shape_invalid, true, true);
        }
    }
    if (!unique_edges(trace.graph)) return rejected(FateCode::duplicate_edge, true, true);
    for (std::size_t index = 0U; index < trace.graph.binding_count; ++index) {
        const auto& binding = trace.graph.bindings[index];
        if (!binding.present || !nonzero(binding.binding_digest)
            || binding.administrative_leaf >= trace.graph.node_count
            || binding.rollback_leaf >= trace.graph.node_count
            || binding.view_leaf >= trace.graph.node_count
            || trace.graph.nodes[binding.administrative_leaf].kind != NodeKind::role_leaf
            || trace.graph.nodes[binding.rollback_leaf].kind != NodeKind::role_leaf
            || trace.graph.nodes[binding.view_leaf].kind != NodeKind::role_leaf) {
            return rejected(FateCode::binding_shape_invalid, true, true);
        }
    }
    if (!role_bindings_complete(trace.graph)) {
        return rejected(FateCode::binding_set_incomplete, true, true);
    }
    if (!parent_leaf_bindings_match(trace)) {
        return rejected(FateCode::binding_leaf_mismatch, true, true);
    }
    if (!nonzero(trace.graph.source_closure_digest)) {
        return rejected(FateCode::source_closure_missing, true, true);
    }
    if (!nonzero(trace.graph.inventory_scope_digest)) {
        return rejected(FateCode::inventory_scope_missing, true, true);
    }
    if (!nonzero(trace.graph.omitted_edge_policy_digest)) {
        return rejected(FateCode::omitted_edge_policy_missing, true, true);
    }
    if (!binding_order_is_exact(trace.graph)) {
        return rejected(FateCode::canonical_binding_order_invalid, true, true);
    }
    if (!all_unused_tails_are_clear(trace.graph)) {
        return rejected(FateCode::canonical_tail_invalid, true, true);
    }
    if (trace.graph.graph_digest != canonical_graph_digest(trace.graph)) {
        return rejected(FateCode::graph_digest_mismatch, true, true);
    }
    if (trace.graph.no_replace_published) {
        if (!nonzero(trace.graph.publication_receipt_digest)) {
            return rejected(FateCode::publication_receipt_missing, true, true);
        }
        if (trace.graph.publication_receipt_digest != publication_receipt_digest_for(trace.graph)) {
            return rejected(FateCode::publication_receipt_binding_mismatch, true, true);
        }
    }
    if (trace.graph.independently_challenged) {
        if (!nonzero(trace.graph.challenge_receipt_digest)) {
            return rejected(FateCode::challenge_receipt_missing, true, true);
        }
        if (trace.graph.challenge_receipt_digest != challenge_receipt_digest_for(trace.graph)) {
            return rejected(FateCode::challenge_receipt_binding_mismatch, true, true);
        }
    }
    if (!cuts_are_exact(trace)) return rejected(FateCode::graph_cut_order_invalid, true, true);

    FateReport report{};
    report.accepted = true;
    report.parent_accepted = true;
    report.parent_ready_live_retained = true;
    report.parent_exactly_bound = true;
    report.graph_shape_valid = true;
    report.scope_policy_bound = true;
    report.canonical_order_valid = true;
    report.canonical_tail_clear = true;
    report.graph_digest_bound = true;
    report.publication_receipt_bound = !trace.graph.no_replace_published
        || trace.graph.publication_receipt_digest == publication_receipt_digest_for(trace.graph);
    report.challenge_receipt_bound = !trace.graph.independently_challenged
        || trace.graph.challenge_receipt_digest == challenge_receipt_digest_for(trace.graph);
    report.inventory_claim_closed = trace.graph.canonical && trace.graph.complete_inventory_claim
        && trace.graph.source_closed && trace.graph.externally_supplied && trace.graph.owner_ratified
        && trace.graph.omitted_edge_policy_declared && !trace.graph.self_generated_by_candidate
        && report.scope_policy_bound && report.graph_digest_bound;
    report.publication_valid = trace.graph.durable && trace.graph.no_replace_published
        && trace.graph.single_view && report.publication_receipt_bound;
    report.reopen_valid = report.publication_valid && trace.graph.independently_reopenable;
    report.challenge_valid = report.reopen_valid && trace.graph.independently_challenged
        && report.challenge_receipt_bound;
    report.cuts_ordered = true;

    if (trace.graph.self_generated_by_candidate) {
        report.code = FateCode::accepted_refused_self_generated_capsule;
        return report;
    }
    if (!report.inventory_claim_closed) {
        report.code = FateCode::accepted_refused_inventory_open;
        return report;
    }
    if (!report.publication_valid) {
        report.code = FateCode::accepted_refused_capsule_unpublished;
        return report;
    }
    if (!report.reopen_valid) {
        report.code = FateCode::accepted_refused_capsule_not_reopened;
        return report;
    }
    if (!report.challenge_valid) {
        report.code = FateCode::accepted_refused_capsule_unchallenged;
        return report;
    }

    std::uint16_t required = 0U;
    std::uint16_t refuted = 0U;
    for (const auto& pair : required_pairs) {
        const auto* left = binding_for(trace.graph, pair.left);
        const auto* right = binding_for(trace.graph, pair.right);
        const std::array<std::uint8_t, 3U> capabilities{
            administrative_capability, rollback_capability, shared_view_capability};
        for (const auto capability : capabilities) {
            if ((pair.capability_mask & capability) == 0U) continue;
            ++required;
            const auto left_set = upstream_set(trace.graph, leaf_for(*left, capability), capability);
            const auto right_set = upstream_set(trace.graph, leaf_for(*right, capability), capability);
            for (std::size_t node = 0U; node < trace.graph.node_count; ++node) {
                if (!left_set[node] || !right_set[node]) continue;
                ++refuted;
                const FateKind kind = capability == administrative_capability
                    ? FateKind::administrative
                    : (capability == rollback_capability ? FateKind::rollback : FateKind::shared_view);
                if (kind == FateKind::administrative) report.common_administrative_fate_detected = true;
                if (kind == FateKind::rollback) report.common_rollback_fate_detected = true;
                if (kind == FateKind::shared_view) report.common_view_fate_detected = true;
                if (report.first_fate_kind == FateKind::none) {
                    report.first_fate_kind = kind;
                    report.first_role_a = pair.left;
                    report.first_role_b = pair.right;
                    report.first_common_node = static_cast<std::uint8_t>(node);
                }
                break;
            }
        }
    }
    report.required_checks = required;
    report.refuted_checks = refuted;
    report.any_common_fate_detected = refuted != 0U;
    report.no_common_fate_found_in_supplied_closure = refuted == 0U;
    const unsigned categories = static_cast<unsigned>(report.common_administrative_fate_detected)
        + static_cast<unsigned>(report.common_rollback_fate_detected)
        + static_cast<unsigned>(report.common_view_fate_detected);
    if (categories > 1U) {
        report.code = FateCode::accepted_multiple_common_fates_detected;
        report.first_fate_kind = FateKind::multiple;
    } else if (report.common_administrative_fate_detected) {
        report.code = FateCode::accepted_common_administrative_fate_detected;
    } else if (report.common_rollback_fate_detected) {
        report.code = FateCode::accepted_common_rollback_fate_detected;
    } else if (report.common_view_fate_detected) {
        report.code = FateCode::accepted_common_view_fate_detected;
    } else {
        report.code = FateCode::accepted_no_common_fate_found_in_supplied_closure;
    }
    return report;
}

std::string_view fate_code_name(const FateCode value) noexcept {
    switch (value) {
        case FateCode::accepted_no_common_fate_found_in_supplied_closure: return "accepted_no_common_fate_found_in_supplied_closure";
        case FateCode::accepted_common_administrative_fate_detected: return "accepted_common_administrative_fate_detected";
        case FateCode::accepted_common_rollback_fate_detected: return "accepted_common_rollback_fate_detected";
        case FateCode::accepted_common_view_fate_detected: return "accepted_common_view_fate_detected";
        case FateCode::accepted_multiple_common_fates_detected: return "accepted_multiple_common_fates_detected";
        case FateCode::accepted_refused_inventory_open: return "accepted_refused_inventory_open";
        case FateCode::accepted_refused_capsule_unpublished: return "accepted_refused_capsule_unpublished";
        case FateCode::accepted_refused_capsule_not_reopened: return "accepted_refused_capsule_not_reopened";
        case FateCode::accepted_refused_capsule_unchallenged: return "accepted_refused_capsule_unchallenged";
        case FateCode::accepted_refused_self_generated_capsule: return "accepted_refused_self_generated_capsule";
        case FateCode::parent_rejected: return "parent_rejected";
        case FateCode::parent_not_ready_live: return "parent_not_ready_live";
        case FateCode::parent_separation_binding_mismatch: return "parent_separation_binding_mismatch";
        case FateCode::annex_binding_mismatch: return "annex_binding_mismatch";
        case FateCode::graph_shape_invalid: return "graph_shape_invalid";
        case FateCode::node_shape_invalid: return "node_shape_invalid";
        case FateCode::duplicate_node_digest: return "duplicate_node_digest";
        case FateCode::edge_shape_invalid: return "edge_shape_invalid";
        case FateCode::duplicate_edge: return "duplicate_edge";
        case FateCode::binding_shape_invalid: return "binding_shape_invalid";
        case FateCode::binding_set_incomplete: return "binding_set_incomplete";
        case FateCode::binding_leaf_mismatch: return "binding_leaf_mismatch";
        case FateCode::source_closure_missing: return "source_closure_missing";
        case FateCode::inventory_scope_missing: return "inventory_scope_missing";
        case FateCode::omitted_edge_policy_missing: return "omitted_edge_policy_missing";
        case FateCode::canonical_binding_order_invalid: return "canonical_binding_order_invalid";
        case FateCode::canonical_tail_invalid: return "canonical_tail_invalid";
        case FateCode::graph_digest_mismatch: return "graph_digest_mismatch";
        case FateCode::publication_receipt_missing: return "publication_receipt_missing";
        case FateCode::publication_receipt_binding_mismatch: return "publication_receipt_binding_mismatch";
        case FateCode::challenge_receipt_missing: return "challenge_receipt_missing";
        case FateCode::challenge_receipt_binding_mismatch: return "challenge_receipt_binding_mismatch";
        case FateCode::graph_cut_order_invalid: return "graph_cut_order_invalid";
    }
    return "unknown";
}

std::string_view fate_kind_name(const FateKind value) noexcept {
    switch (value) {
        case FateKind::none: return "none";
        case FateKind::administrative: return "administrative";
        case FateKind::rollback: return "rollback";
        case FateKind::shared_view: return "shared_view";
        case FateKind::multiple: return "multiple";
    }
    return "unknown";
}

std::string_view role_name(const Role value) noexcept {
    switch (value) {
        case Role::mechanism_operator: return "mechanism_operator";
        case Role::corpus_producer: return "corpus_producer";
        case Role::transparency_witness: return "transparency_witness";
        case Role::independent_reopener: return "independent_reopener";
        case Role::appraiser: return "appraiser";
        case Role::owner_admitter: return "owner_admitter";
    }
    return "unknown";
}

std::string_view graph_cut_name(const std::size_t index) noexcept {
    constexpr std::array<std::string_view, graph_cut_count> names{
        "capsule_assembled", "capsule_published", "capsule_reopened", "challenge_reopened"};
    return index < names.size() ? names[index] : "invalid";
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification
