#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/reopen_receipt_chain.hpp"

#include <algorithm>
#include <array>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain {
namespace {

[[nodiscard]] bool nonzero(const Digest& value) noexcept {
    return std::any_of(value.cbegin(), value.cend(), [](const std::uint8_t byte) { return byte != 0U; });
}

[[nodiscard]] bool source_shape_valid(const SourceClosure& value) noexcept {
    const bool dependent = value.canonical || value.complete || value.independently_locatable
        || value.rollback_external || value.replacement_only || value.no_hidden_inputs
        || value.includes_live_terminal_record || nonzero(value.closure_digest)
        || nonzero(value.cutover_id) || nonzero(value.join_digest)
        || nonzero(value.witness_digest) || nonzero(value.floor_digest)
        || nonzero(value.request_id) || nonzero(value.transition_digest)
        || nonzero(value.register_incarnation) || nonzero(value.terminal_digest)
        || nonzero(value.reopener_incarnation) || nonzero(value.verifier_id)
        || nonzero(value.verifier_policy_digest);
    return value.present || !dependent;
}

[[nodiscard]] bool reopen_shape_valid(const ReopenReceipt& value) noexcept {
    const bool dependent = value.computed_from_closure || value.exact_result || value.authenticated
        || value.no_replace_published || value.durable || value.directory_entry_durable
        || value.single_view || value.independently_reopenable || nonzero(value.receipt_digest)
        || nonzero(value.closure_digest) || nonzero(value.cutover_id) || nonzero(value.join_digest)
        || nonzero(value.witness_digest) || nonzero(value.floor_digest) || nonzero(value.request_id)
        || nonzero(value.transition_digest) || nonzero(value.register_incarnation)
        || nonzero(value.terminal_digest) || nonzero(value.reopener_incarnation)
        || nonzero(value.verifier_id) || nonzero(value.verifier_policy_digest);
    return value.present || !dependent;
}

[[nodiscard]] bool authorization_shape_valid(const AuthorizationCapsule& value) noexcept {
    const bool dependent = value.authenticated || value.durable || value.no_replace_published
        || value.single_view || value.separately_governed || value.independently_reopenable
        || nonzero(value.authorization_digest) || nonzero(value.reopen_receipt_digest)
        || nonzero(value.cutover_id) || nonzero(value.target_digest)
        || nonzero(value.owner_policy_digest) || nonzero(value.retention_policy_digest);
    return value.present || !dependent;
}

[[nodiscard]] bool deletion_shape_valid(const DeletionReceipt& value) noexcept {
    const bool dependent = value.authenticated || value.durable || value.no_replace_published
        || value.single_view || value.target_absence_observed || nonzero(value.deletion_receipt_digest)
        || nonzero(value.authorization_digest) || nonzero(value.cutover_id) || nonzero(value.target_digest);
    return value.present || !dependent;
}

[[nodiscard]] ReceiptChainReport rejected(const ReceiptChainCode code, const bool predecessor = false) noexcept {
    ReceiptChainReport value{};
    value.code = code;
    value.exact_predecessor_accepted = predecessor;
    return value;
}

[[nodiscard]] ReceiptChainReport accepted(
    const ReceiptChainCode code,
    const bool parent_safe,
    const bool parent_ready,
    const bool source_valid,
    const bool reopen_core,
    const bool reopen_reopen,
    const bool auth_core,
    const bool auth_reopen,
    const bool deletion_valid,
    const bool ordered,
    const bool source_gap,
    const bool publication_gap,
    const bool receipt_reopen_gap,
    const bool authorization_gap,
    const bool authorization_reopen_gap,
    const bool deletion_gap,
    const bool phase_gap,
    const bool regression,
    const bool ready,
    const bool complete,
    const bool unauthorized,
    const bool fail_stop) noexcept {
    return ReceiptChainReport{
        code, true, true, parent_safe, parent_ready, source_valid, reopen_core,
        reopen_reopen, auth_core, auth_reopen, deletion_valid, ordered, source_gap,
        publication_gap, receipt_reopen_gap, authorization_gap,
        authorization_reopen_gap, deletion_gap, phase_gap, regression, ready,
        complete, unauthorized, fail_stop, false, false, false, false, false, false,
    };
}

}  // namespace

ReceiptChainReport evaluate_candidate(const ReceiptChainTrace& trace) noexcept {
    const auto predecessor = exact_predecessor_consumption::evaluate_candidate(trace.predecessor);
    if (!predecessor.accepted) {
        return rejected(ReceiptChainCode::exact_predecessor_rejected);
    }
    const bool predecessor_complete = predecessor.chain_complete && predecessor.deletion_safe;
    const bool predecessor_ready = predecessor.code
        == exact_predecessor_consumption::ChainCode::accepted_chain_ready_live_retained;
    // This child refines the still-live terminal prefix.  An already complete
    // predecessor has consumed deletion and cannot be replayed as a live R0 basis.
    if (!predecessor_ready || predecessor_complete
        || !predecessor.receipt_subjects_exact || !predecessor.receipt_components_exact
        || !predecessor.receipt_digests_unique || !predecessor.exact_predecessor_edges
        || !predecessor.durable_publications || !predecessor.strict_phase_order
        || !predecessor.monotone_visibility || !predecessor.every_prefix_covered) {
        return rejected(ReceiptChainCode::exact_predecessor_not_ready, true);
    }
    const auto& cutover = trace.predecessor.parent;
    const auto& exact_receipts = trace.predecessor.receipts;
    if (!nonzero(trace.join_digest)) return rejected(ReceiptChainCode::join_digest_zero, true);
    if (!nonzero(trace.target_digest)) return rejected(ReceiptChainCode::target_digest_zero, true);
    if (!nonzero(trace.owner_policy_digest)) return rejected(ReceiptChainCode::owner_policy_digest_zero, true);
    if (!nonzero(trace.retention_policy_digest)) return rejected(ReceiptChainCode::retention_policy_digest_zero, true);
    if (trace.join_digest != exact_receipts[static_cast<std::size_t>(
            exact_predecessor_consumption::Phase::join_publication)].record_digest) {
        return rejected(ReceiptChainCode::exact_join_receipt_digest_mismatch, true);
    }
    if (trace.reopen.present
        && trace.reopen.receipt_digest != exact_receipts[static_cast<std::size_t>(
            exact_predecessor_consumption::Phase::cold_reopen_receipt)].record_digest) {
        return rejected(ReceiptChainCode::exact_reopen_receipt_digest_mismatch, true);
    }
    if (trace.authorization.present
        && trace.authorization.authorization_digest != exact_receipts[static_cast<std::size_t>(
            exact_predecessor_consumption::Phase::deletion_authorization)].record_digest) {
        return rejected(ReceiptChainCode::exact_authorization_receipt_digest_mismatch, true);
    }
    if (trace.reclamation_requested != trace.predecessor.reclamation_requested
        || trace.reclamation_requested != cutover.reclamation_requested) {
        return rejected(ReceiptChainCode::reclamation_request_mismatch, true);
    }
    if (!source_shape_valid(trace.source)) return rejected(ReceiptChainCode::source_shape_invalid, true);
    if (trace.source.present) {
        if (trace.source.cutover_id != cutover.cutover_id) return rejected(ReceiptChainCode::source_cutover_id_mismatch, true);
        if (trace.source.join_digest != trace.join_digest) return rejected(ReceiptChainCode::source_join_digest_mismatch, true);
        if (trace.source.witness_digest != cutover.witness_digest) return rejected(ReceiptChainCode::source_witness_digest_mismatch, true);
        if (trace.source.floor_digest != cutover.floor_digest) return rejected(ReceiptChainCode::source_floor_digest_mismatch, true);
        if (trace.source.request_id != cutover.state.request_id) return rejected(ReceiptChainCode::source_request_id_mismatch, true);
        if (trace.source.transition_digest != cutover.state.transition_digest) return rejected(ReceiptChainCode::source_transition_digest_mismatch, true);
        if (trace.source.register_incarnation != cutover.state.register_incarnation) return rejected(ReceiptChainCode::source_register_incarnation_mismatch, true);
        if (trace.source.terminal_digest != cutover.state.terminal_digest) return rejected(ReceiptChainCode::source_terminal_digest_mismatch, true);
        if (trace.source.terminal_kind != cutover.state.terminal_kind) return rejected(ReceiptChainCode::source_terminal_kind_mismatch, true);
    }
    if (!reopen_shape_valid(trace.reopen)) return rejected(ReceiptChainCode::reopen_shape_invalid, true);
    if (trace.reopen.present) {
        if (trace.reopen.closure_digest != trace.source.closure_digest) return rejected(ReceiptChainCode::reopen_closure_digest_mismatch, true);
        if (trace.reopen.cutover_id != cutover.cutover_id) return rejected(ReceiptChainCode::reopen_cutover_id_mismatch, true);
        if (trace.reopen.join_digest != trace.join_digest) return rejected(ReceiptChainCode::reopen_join_digest_mismatch, true);
        if (trace.reopen.witness_digest != cutover.witness_digest) return rejected(ReceiptChainCode::reopen_witness_digest_mismatch, true);
        if (trace.reopen.floor_digest != cutover.floor_digest) return rejected(ReceiptChainCode::reopen_floor_digest_mismatch, true);
        if (trace.reopen.request_id != cutover.state.request_id) return rejected(ReceiptChainCode::reopen_request_id_mismatch, true);
        if (trace.reopen.transition_digest != cutover.state.transition_digest) return rejected(ReceiptChainCode::reopen_transition_digest_mismatch, true);
        if (trace.reopen.register_incarnation != cutover.state.register_incarnation) return rejected(ReceiptChainCode::reopen_register_incarnation_mismatch, true);
        if (trace.reopen.terminal_digest != cutover.state.terminal_digest) return rejected(ReceiptChainCode::reopen_terminal_digest_mismatch, true);
        if (trace.reopen.terminal_kind != cutover.state.terminal_kind) return rejected(ReceiptChainCode::reopen_terminal_kind_mismatch, true);
        if (trace.reopen.reopener_incarnation != trace.source.reopener_incarnation) return rejected(ReceiptChainCode::reopen_reopener_incarnation_mismatch, true);
        if (trace.reopen.verifier_id != trace.source.verifier_id) return rejected(ReceiptChainCode::reopen_verifier_id_mismatch, true);
        if (trace.reopen.verifier_policy_digest != trace.source.verifier_policy_digest) return rejected(ReceiptChainCode::reopen_policy_digest_mismatch, true);
    }
    if (!authorization_shape_valid(trace.authorization)) return rejected(ReceiptChainCode::authorization_shape_invalid, true);
    if (trace.authorization.present) {
        if (trace.authorization.reopen_receipt_digest != trace.reopen.receipt_digest) return rejected(ReceiptChainCode::authorization_receipt_digest_mismatch, true);
        if (trace.authorization.cutover_id != cutover.cutover_id) return rejected(ReceiptChainCode::authorization_cutover_id_mismatch, true);
        if (trace.authorization.target_digest != trace.target_digest) return rejected(ReceiptChainCode::authorization_target_digest_mismatch, true);
        if (trace.authorization.owner_policy_digest != trace.owner_policy_digest) return rejected(ReceiptChainCode::authorization_owner_policy_mismatch, true);
        if (trace.authorization.retention_policy_digest != trace.retention_policy_digest) return rejected(ReceiptChainCode::authorization_retention_policy_mismatch, true);
    }
    if (!deletion_shape_valid(trace.deletion)) return rejected(ReceiptChainCode::deletion_shape_invalid, true);
    if (trace.deletion.present) {
        if (trace.deletion.authorization_digest != trace.authorization.authorization_digest) return rejected(ReceiptChainCode::deletion_authorization_digest_mismatch, true);
        if (trace.deletion.cutover_id != cutover.cutover_id) return rejected(ReceiptChainCode::deletion_cutover_id_mismatch, true);
        if (trace.deletion.target_digest != trace.target_digest) return rejected(ReceiptChainCode::deletion_target_digest_mismatch, true);
    }

    if (!trace.cuts.front().live_record_visible || !trace.cuts.front().replacement_visible
        || trace.cuts.front().record_deleted) {
        return rejected(ReceiptChainCode::trace_initial_state_invalid, true);
    }
    for (const auto& cut : trace.cuts) {
        if (cut.live_record_visible && cut.record_deleted) return rejected(ReceiptChainCode::trace_deleted_and_live, true);
        if (!cut.live_record_visible && !cut.record_deleted) return rejected(ReceiptChainCode::trace_live_absent_without_deletion, true);
    }

    const bool source_valid = trace.source.present && nonzero(trace.source.closure_digest)
        && trace.source.canonical && trace.source.complete && trace.source.independently_locatable
        && trace.source.rollback_external && trace.source.replacement_only
        && trace.source.no_hidden_inputs && !trace.source.includes_live_terminal_record;
    const bool reopen_core = source_valid && trace.reopen.present && nonzero(trace.reopen.receipt_digest)
        && trace.reopen.computed_from_closure && trace.reopen.exact_result
        && trace.reopen.authenticated && trace.reopen.no_replace_published
        && trace.reopen.durable && trace.reopen.directory_entry_durable && trace.reopen.single_view;
    const bool reopen_reopen = reopen_core && trace.reopen.independently_reopenable;
    const bool auth_core = reopen_reopen && trace.authorization.present
        && nonzero(trace.authorization.authorization_digest) && trace.authorization.authenticated
        && trace.authorization.durable && trace.authorization.no_replace_published
        && trace.authorization.single_view && trace.authorization.separately_governed;
    const bool auth_reopen = auth_core && trace.authorization.independently_reopenable;
    const bool deletion_core = trace.deletion.present
        && nonzero(trace.deletion.deletion_receipt_digest) && trace.deletion.authenticated
        && trace.deletion.durable && trace.deletion.no_replace_published
        && trace.deletion.single_view && trace.deletion.target_absence_observed;
    const bool deletion_valid = auth_reopen && deletion_core;

    bool seen_start = false;
    bool seen_compute = false;
    bool seen_receipt = false;
    bool seen_receipt_reopen = false;
    bool seen_authorization = false;
    bool seen_authorization_reopen = false;
    bool seen_deletion = false;
    bool seen_deletion_receipt = false;
    bool live_was_absent = false;
    bool all_ordered = true;
    bool phase_gap = false;
    bool regression = false;
    bool source_gap = false;
    bool publication_gap = false;
    bool receipt_reopen_gap = false;
    bool authorization_gap = false;
    bool authorization_reopen_gap = false;
    bool deletion_gap = false;

    for (const auto& cut : trace.cuts) {
        const bool new_compute = cut.reconstruction_computed && !seen_compute;
        const bool new_receipt = cut.reopen_receipt_visible && !seen_receipt;
        const bool new_receipt_reopen = cut.reopen_receipt_reopened && !seen_receipt_reopen;
        const bool new_authorization = cut.authorization_visible && !seen_authorization;
        const bool new_authorization_reopen = cut.authorization_reopened && !seen_authorization_reopen;
        const bool new_deletion = cut.record_deleted && !seen_deletion;
        const bool new_deletion_receipt = cut.deletion_receipt_visible && !seen_deletion_receipt;
        const bool order_ok = (!new_compute || seen_start)
            && (!new_receipt || seen_compute)
            && (!new_receipt_reopen || seen_receipt)
            && (!new_authorization || seen_receipt_reopen)
            && (!new_authorization_reopen || seen_authorization)
            && (!new_deletion || seen_authorization_reopen)
            && (!new_deletion_receipt || seen_deletion);
        all_ordered = all_ordered && order_ok;
        phase_gap = phase_gap || !order_ok;

        source_gap = source_gap || (cut.reopener_started && !source_valid);
        publication_gap = publication_gap || (cut.reopen_receipt_visible && !reopen_core);
        receipt_reopen_gap = receipt_reopen_gap || (cut.reopen_receipt_reopened && !reopen_reopen);
        authorization_gap = authorization_gap || (cut.authorization_visible && !auth_core);
        authorization_reopen_gap = authorization_reopen_gap || (cut.authorization_reopened && !auth_reopen);
        deletion_gap = deletion_gap || (cut.deletion_receipt_visible && !deletion_valid);

        regression = regression
            || (seen_start && !cut.reopener_started)
            || (seen_compute && !cut.reconstruction_computed)
            || (seen_receipt && !cut.reopen_receipt_visible)
            || (seen_receipt_reopen && !cut.reopen_receipt_reopened)
            || (seen_authorization && !cut.authorization_visible)
            || (seen_authorization_reopen && !cut.authorization_reopened)
            || (seen_deletion && !cut.record_deleted)
            || (seen_deletion_receipt && !cut.deletion_receipt_visible)
            || (live_was_absent && cut.live_record_visible)
            || !cut.replacement_visible;

        seen_start = seen_start || cut.reopener_started;
        seen_compute = seen_compute || cut.reconstruction_computed;
        seen_receipt = seen_receipt || cut.reopen_receipt_visible;
        seen_receipt_reopen = seen_receipt_reopen || cut.reopen_receipt_reopened;
        seen_authorization = seen_authorization || cut.authorization_visible;
        seen_authorization_reopen = seen_authorization_reopen || cut.authorization_reopened;
        seen_deletion = seen_deletion || cut.record_deleted;
        seen_deletion_receipt = seen_deletion_receipt || cut.deletion_receipt_visible;
        live_was_absent = live_was_absent || !cut.live_record_visible;
    }

    const auto& last = trace.cuts.back();
    // Capability fields do not prove that a phase was durably consumed.  Once a
    // predecessor phase is visible, absence of its required successor at the
    // terminal cut is an explicit refusal gap rather than an inert live basis.
    publication_gap = publication_gap || (seen_compute && !seen_receipt);
    receipt_reopen_gap = receipt_reopen_gap || (seen_receipt && !seen_receipt_reopen);
    authorization_gap = authorization_gap || (seen_receipt_reopen && !seen_authorization);
    authorization_reopen_gap = authorization_reopen_gap || (seen_authorization && !seen_authorization_reopen);

    const bool ready = predecessor_ready && !trace.equivocation_observed && !regression && all_ordered
        && source_valid && reopen_reopen && auth_reopen && last.live_record_visible
        && !last.record_deleted && last.authorization_reopened && trace.reclamation_requested;
    const bool complete = predecessor_ready && !trace.equivocation_observed && !regression && all_ordered
        && source_valid && reopen_reopen && auth_reopen && deletion_valid
        && !last.live_record_visible && last.record_deleted && last.deletion_receipt_visible
        && trace.reclamation_requested;
    const bool unauthorized = last.record_deleted && !complete;

    if (trace.equivocation_observed) {
        return accepted(ReceiptChainCode::accepted_equivocation_fail_stop, predecessor_complete,
            predecessor_ready, source_valid, reopen_core, reopen_reopen, auth_core, auth_reopen,
            deletion_valid, all_ordered, source_gap, publication_gap, receipt_reopen_gap,
            authorization_gap, authorization_reopen_gap, deletion_gap, phase_gap, regression,
            false, false, unauthorized, true);
    }
    if (regression) {
        return accepted(ReceiptChainCode::accepted_regression_fail_stop, predecessor_complete,
            predecessor_ready, source_valid, reopen_core, reopen_reopen, auth_core, auth_reopen,
            deletion_valid, false, source_gap, publication_gap, receipt_reopen_gap,
            authorization_gap, authorization_reopen_gap, deletion_gap, phase_gap, true,
            false, false, unauthorized, true);
    }
    if (unauthorized) {
        const auto code = last.deletion_receipt_visible && !deletion_core
            ? ReceiptChainCode::accepted_deletion_receipt_gap_fail_stop
            : ReceiptChainCode::accepted_unauthorized_deletion_fail_stop;
        return accepted(code, predecessor_complete, predecessor_ready, source_valid,
            reopen_core, reopen_reopen, auth_core, auth_reopen, deletion_valid, all_ordered,
            source_gap, publication_gap, receipt_reopen_gap, authorization_gap,
            authorization_reopen_gap, !deletion_valid, phase_gap, false, false, false, true, true);
    }
    if (complete) {
        return accepted(ReceiptChainCode::accepted_chain_complete, predecessor_complete,
            predecessor_ready, true, true, true, true, true, true, true,
            false, false, false, false, false, false, false, false, false, true, false, false);
    }
    if (ready) {
        return accepted(ReceiptChainCode::accepted_chain_ready_live_retained, predecessor_complete,
            predecessor_ready, true, true, true, true, true, deletion_valid, true,
            false, false, false, false, false, false, false, false, true, false, false, false);
    }
    if (phase_gap) {
        return accepted(ReceiptChainCode::accepted_reclamation_refused_order_gap, predecessor_complete,
            predecessor_ready, source_valid, reopen_core, reopen_reopen, auth_core, auth_reopen,
            deletion_valid, false, source_gap, publication_gap, receipt_reopen_gap,
            authorization_gap, authorization_reopen_gap, deletion_gap, true, false,
            false, false, false, false);
    }
    if (!source_valid || source_gap) {
        return accepted(ReceiptChainCode::accepted_reclamation_refused_source_closure_gap, predecessor_complete,
            predecessor_ready, false, reopen_core, reopen_reopen, auth_core, auth_reopen,
            deletion_valid, all_ordered, true, publication_gap, receipt_reopen_gap,
            authorization_gap, authorization_reopen_gap, deletion_gap, false, false,
            false, false, false, false);
    }
    if (!reopen_core || publication_gap) {
        return accepted(ReceiptChainCode::accepted_reclamation_refused_publication_gap, predecessor_complete,
            predecessor_ready, source_valid, false, reopen_reopen, auth_core, auth_reopen,
            deletion_valid, all_ordered, false, true, receipt_reopen_gap,
            authorization_gap, authorization_reopen_gap, deletion_gap, false, false,
            false, false, false, false);
    }
    if (!reopen_reopen || receipt_reopen_gap) {
        return accepted(ReceiptChainCode::accepted_reclamation_refused_receipt_reopen_gap, predecessor_complete,
            predecessor_ready, source_valid, reopen_core, false, auth_core, auth_reopen,
            deletion_valid, all_ordered, false, false, true, authorization_gap,
            authorization_reopen_gap, deletion_gap, false, false, false, false, false, false);
    }
    if (!auth_core || authorization_gap) {
        return accepted(ReceiptChainCode::accepted_reclamation_refused_authorization_gap, predecessor_complete,
            predecessor_ready, source_valid, reopen_core, reopen_reopen, false, auth_reopen,
            deletion_valid, all_ordered, false, false, false, true,
            authorization_reopen_gap, deletion_gap, false, false, false, false, false, false);
    }
    if (!auth_reopen || authorization_reopen_gap) {
        return accepted(ReceiptChainCode::accepted_reclamation_refused_authorization_reopen_gap, predecessor_complete,
            predecessor_ready, source_valid, reopen_core, reopen_reopen, auth_core, false,
            deletion_valid, all_ordered, false, false, false, false, true,
            deletion_gap, false, false, false, false, false, false);
    }
    return accepted(ReceiptChainCode::accepted_live_basis_retained, predecessor_complete,
        predecessor_ready, source_valid, reopen_core, reopen_reopen, auth_core, auth_reopen,
        deletion_valid, all_ordered, false, false, false, false, false, deletion_gap,
        false, false, false, false, false, false);
}

std::string_view receipt_chain_code_name(const ReceiptChainCode value) noexcept {
    switch (value) {
    case ReceiptChainCode::accepted_chain_complete: return "accepted_chain_complete";
    case ReceiptChainCode::accepted_chain_ready_live_retained: return "accepted_chain_ready_live_retained";
    case ReceiptChainCode::accepted_live_basis_retained: return "accepted_live_basis_retained";
    case ReceiptChainCode::accepted_reclamation_refused_source_closure_gap: return "accepted_reclamation_refused_source_closure_gap";
    case ReceiptChainCode::accepted_reclamation_refused_publication_gap: return "accepted_reclamation_refused_publication_gap";
    case ReceiptChainCode::accepted_reclamation_refused_receipt_reopen_gap: return "accepted_reclamation_refused_receipt_reopen_gap";
    case ReceiptChainCode::accepted_reclamation_refused_authorization_gap: return "accepted_reclamation_refused_authorization_gap";
    case ReceiptChainCode::accepted_reclamation_refused_authorization_reopen_gap: return "accepted_reclamation_refused_authorization_reopen_gap";
    case ReceiptChainCode::accepted_reclamation_refused_order_gap: return "accepted_reclamation_refused_order_gap";
    case ReceiptChainCode::accepted_unauthorized_deletion_fail_stop: return "accepted_unauthorized_deletion_fail_stop";
    case ReceiptChainCode::accepted_deletion_receipt_gap_fail_stop: return "accepted_deletion_receipt_gap_fail_stop";
    case ReceiptChainCode::accepted_equivocation_fail_stop: return "accepted_equivocation_fail_stop";
    case ReceiptChainCode::accepted_regression_fail_stop: return "accepted_regression_fail_stop";
    case ReceiptChainCode::exact_predecessor_rejected: return "exact_predecessor_rejected";
    case ReceiptChainCode::exact_predecessor_not_ready: return "exact_predecessor_not_ready";
    case ReceiptChainCode::exact_join_receipt_digest_mismatch: return "exact_join_receipt_digest_mismatch";
    case ReceiptChainCode::exact_reopen_receipt_digest_mismatch: return "exact_reopen_receipt_digest_mismatch";
    case ReceiptChainCode::exact_authorization_receipt_digest_mismatch: return "exact_authorization_receipt_digest_mismatch";
    case ReceiptChainCode::join_digest_zero: return "join_digest_zero";
    case ReceiptChainCode::target_digest_zero: return "target_digest_zero";
    case ReceiptChainCode::owner_policy_digest_zero: return "owner_policy_digest_zero";
    case ReceiptChainCode::retention_policy_digest_zero: return "retention_policy_digest_zero";
    case ReceiptChainCode::reclamation_request_mismatch: return "reclamation_request_mismatch";
    case ReceiptChainCode::source_shape_invalid: return "source_shape_invalid";
    case ReceiptChainCode::source_cutover_id_mismatch: return "source_cutover_id_mismatch";
    case ReceiptChainCode::source_join_digest_mismatch: return "source_join_digest_mismatch";
    case ReceiptChainCode::source_witness_digest_mismatch: return "source_witness_digest_mismatch";
    case ReceiptChainCode::source_floor_digest_mismatch: return "source_floor_digest_mismatch";
    case ReceiptChainCode::source_request_id_mismatch: return "source_request_id_mismatch";
    case ReceiptChainCode::source_transition_digest_mismatch: return "source_transition_digest_mismatch";
    case ReceiptChainCode::source_register_incarnation_mismatch: return "source_register_incarnation_mismatch";
    case ReceiptChainCode::source_terminal_digest_mismatch: return "source_terminal_digest_mismatch";
    case ReceiptChainCode::source_terminal_kind_mismatch: return "source_terminal_kind_mismatch";
    case ReceiptChainCode::reopen_shape_invalid: return "reopen_shape_invalid";
    case ReceiptChainCode::reopen_closure_digest_mismatch: return "reopen_closure_digest_mismatch";
    case ReceiptChainCode::reopen_cutover_id_mismatch: return "reopen_cutover_id_mismatch";
    case ReceiptChainCode::reopen_join_digest_mismatch: return "reopen_join_digest_mismatch";
    case ReceiptChainCode::reopen_witness_digest_mismatch: return "reopen_witness_digest_mismatch";
    case ReceiptChainCode::reopen_floor_digest_mismatch: return "reopen_floor_digest_mismatch";
    case ReceiptChainCode::reopen_request_id_mismatch: return "reopen_request_id_mismatch";
    case ReceiptChainCode::reopen_transition_digest_mismatch: return "reopen_transition_digest_mismatch";
    case ReceiptChainCode::reopen_register_incarnation_mismatch: return "reopen_register_incarnation_mismatch";
    case ReceiptChainCode::reopen_terminal_digest_mismatch: return "reopen_terminal_digest_mismatch";
    case ReceiptChainCode::reopen_terminal_kind_mismatch: return "reopen_terminal_kind_mismatch";
    case ReceiptChainCode::reopen_reopener_incarnation_mismatch: return "reopen_reopener_incarnation_mismatch";
    case ReceiptChainCode::reopen_verifier_id_mismatch: return "reopen_verifier_id_mismatch";
    case ReceiptChainCode::reopen_policy_digest_mismatch: return "reopen_policy_digest_mismatch";
    case ReceiptChainCode::authorization_shape_invalid: return "authorization_shape_invalid";
    case ReceiptChainCode::authorization_receipt_digest_mismatch: return "authorization_receipt_digest_mismatch";
    case ReceiptChainCode::authorization_cutover_id_mismatch: return "authorization_cutover_id_mismatch";
    case ReceiptChainCode::authorization_target_digest_mismatch: return "authorization_target_digest_mismatch";
    case ReceiptChainCode::authorization_owner_policy_mismatch: return "authorization_owner_policy_mismatch";
    case ReceiptChainCode::authorization_retention_policy_mismatch: return "authorization_retention_policy_mismatch";
    case ReceiptChainCode::deletion_shape_invalid: return "deletion_shape_invalid";
    case ReceiptChainCode::deletion_authorization_digest_mismatch: return "deletion_authorization_digest_mismatch";
    case ReceiptChainCode::deletion_cutover_id_mismatch: return "deletion_cutover_id_mismatch";
    case ReceiptChainCode::deletion_target_digest_mismatch: return "deletion_target_digest_mismatch";
    case ReceiptChainCode::trace_initial_state_invalid: return "trace_initial_state_invalid";
    case ReceiptChainCode::trace_deleted_and_live: return "trace_deleted_and_live";
    case ReceiptChainCode::trace_live_absent_without_deletion: return "trace_live_absent_without_deletion";
    }
    return "invalid";
}

std::string_view receipt_cut_name(const std::size_t index) noexcept {
    switch (index) {
    case 0U: return "R0_live_joined";
    case 1U: return "R1_reopener_start";
    case 2U: return "R2_reconstruction";
    case 3U: return "R3_receipt_publish";
    case 4U: return "R4_receipt_reopen";
    case 5U: return "R5_authorization_publish";
    case 6U: return "R6_authorization_reopen";
    case 7U: return "R7_delete";
    case 8U: return "R8_deletion_receipt";
    }
    return "invalid";
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain
