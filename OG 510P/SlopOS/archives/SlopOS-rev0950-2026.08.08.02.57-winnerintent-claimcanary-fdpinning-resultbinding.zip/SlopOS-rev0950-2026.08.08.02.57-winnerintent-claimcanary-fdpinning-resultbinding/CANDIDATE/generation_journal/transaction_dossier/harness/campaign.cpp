#include "slopos/e0/transaction_dossier/dossier.hpp"

#include <algorithm>
#include <array>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <string>
#include <utility>
#include <vector>

namespace slopos::e0::transaction_dossier {
namespace {

struct Case final {
    std::string name;
    std::string path;
    std::vector<EncodedRecord> records;
    ValidationCode expected{ValidationCode::invalid_record};
    bool valid{false};
    bool structurally_complete{false};
    bool effect_bearing{false};
    bool coherent_nonauthority{false};
};

[[nodiscard]] RecordV1 decode_or_empty(const EncodedRecord& input) {
    RecordV1 record;
    const bool ok = decode_record(input, record);
    if (!ok) return RecordV1{};
    return record;
}

[[nodiscard]] EncodedRecord encode_or_empty(const RecordV1& input) {
    EncodedRecord record{};
    const bool ok = encode_record(input, record);
    if (!ok) record.fill(0U);
    return record;
}

[[nodiscard]] std::string keyed(const std::string_view seed,
                                const std::string_view field) {
    return std::string(seed) + "/" + std::string(field);
}

void set_predecessors(std::vector<EncodedRecord>& records) {
    for (std::size_t index = 1U; index < records.size(); ++index) {
        RecordV1 current = decode_or_empty(records[index]);
        current.predecessor = record_head(records[index - 1U]);
        records[index] = encode_or_empty(current);
    }
}

[[nodiscard]] std::vector<EncodedRecord> coherent_rewrite(
    const std::vector<EncodedRecord>& source) {
    std::vector<EncodedRecord> out = source;
    const Digest subject = labeled_digest("coherent-rewrite/subject");
    const Digest policy = labeled_digest("coherent-rewrite/policy");
    const std::uint64_t generation = 73U;
    const std::uint64_t nonce = 9901U;
    const Digest txid = transaction_id_for(subject, policy, generation, nonce);
    for (std::size_t index = 0U; index < out.size(); ++index) {
        RecordV1 record = decode_or_empty(out[index]);
        record.subject = subject;
        record.policy = policy;
        record.transaction_id = txid;
        record.generation_from = generation;
        record.nonce = nonce;
        record.actor = labeled_digest("coherent-rewrite/actor/" + std::to_string(index + 1U));
        if (index <= 3U) record.generation_to = generation + 1U;
        else record.generation_to = generation + 1U;
        if (index >= 1U) record.evidence = labeled_digest("coherent-rewrite/evidence");
        if (index >= 2U) record.appraisal = labeled_digest("coherent-rewrite/appraisal");
        if (index >= 3U) record.permit = labeled_digest("coherent-rewrite/permit");
        if (index >= 4U) {
            record.spend_receipt = labeled_digest("coherent-rewrite/spend");
            record.result = labeled_digest("coherent-rewrite/result");
        }
        if (index >= 5U) record.currentness = labeled_digest("coherent-rewrite/currentness");
        record.predecessor.fill(0U);
        out[index] = encode_or_empty(record);
    }
    set_predecessors(out);
    return out;
}

[[nodiscard]] bool write_records(const std::filesystem::path& path,
                                 const std::vector<EncodedRecord>& records) {
    std::filesystem::create_directories(path.parent_path());
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    if (!output) return false;
    for (const EncodedRecord& record : records) {
        output.write(reinterpret_cast<const char*>(record.data()),
                     static_cast<std::streamsize>(record.size()));
    }
    return static_cast<bool>(output);
}

[[nodiscard]] bool write_text(const std::filesystem::path& path,
                              const std::string& text) {
    std::filesystem::create_directories(path.parent_path());
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    output << text;
    return static_cast<bool>(output);
}

[[nodiscard]] std::string bool_text(const bool value) {
    return value ? "true" : "false";
}

[[nodiscard]] Case semantic_mutation(const std::string& name,
                                     const std::string& path,
                                     const std::vector<EncodedRecord>& source,
                                     const std::size_t index,
                                     const ValidationCode expected,
                                     const auto& mutate) {
    Case result{name, path, source, expected, false, false, false, false};
    RecordV1 record = decode_or_empty(result.records[index]);
    mutate(record);
    result.records[index] = encode_or_empty(record);
    set_predecessors(result.records);
    return result;
}

}  // namespace

std::vector<EncodedRecord> make_complete_fixture(const Terminal terminal,
                                                 const std::string_view seed) {
    const Digest subject = labeled_digest(keyed(seed, "subject"));
    const Digest policy = labeled_digest(keyed(seed, "policy"));
    const Digest evidence = labeled_digest(keyed(seed, "evidence"));
    const Digest appraisal = labeled_digest(keyed(seed, "appraisal"));
    const Digest permit = labeled_digest(keyed(seed, "permit"));
    const Digest spend = labeled_digest(keyed(seed, "spend"));
    const Digest result = labeled_digest(keyed(seed, "result"));
    const Digest currentness = labeled_digest(keyed(seed, "currentness"));
    const std::uint64_t generation = 40U;
    const std::uint64_t nonce = 9001U;
    const Digest txid = transaction_id_for(subject, policy, generation, nonce);

    std::vector<EncodedRecord> output;
    output.reserve(6U);
    for (std::size_t index = 0U; index < 6U; ++index) {
        RecordV1 record;
        record.kind = static_cast<Kind>(index + 1U);
        record.role = static_cast<Role>(index + 1U);
        record.transaction_id = txid;
        record.subject = subject;
        record.policy = policy;
        record.actor = labeled_digest(keyed(seed, "actor/" + std::to_string(index + 1U)));
        record.generation_from = generation;
        record.generation_to = generation + 1U;
        record.nonce = nonce;
        if (index >= 1U) record.evidence = evidence;
        if (index >= 2U) {
            record.appraisal = appraisal;
            record.decision = index == 2U ? Decision::pass : Decision::none;
        }
        if (index >= 3U) {
            record.permit = permit;
            record.flags = permit_scoped;
        }
        if (index >= 4U) {
            record.spend_receipt = spend;
            record.result = result;
            record.terminal = terminal;
            record.flags = permit_scoped | permit_spent;
            switch (terminal) {
                case Terminal::effect: record.generation_to = generation + 1U; break;
                case Terminal::no_effect: record.generation_to = generation; break;
                case Terminal::uncertain:
                    record.generation_to = 0U;
                    record.flags |= query_only;
                    break;
                case Terminal::fail_stop: record.generation_to = generation; break;
                case Terminal::none: break;
            }
        }
        if (index >= 5U) {
            record.currentness = currentness;
            record.flags |= reopened;
        }
        output.push_back(encode_or_empty(record));
    }
    set_predecessors(output);
    return output;
}

std::vector<EncodedRecord> make_appraisal_stop_fixture(const Decision decision,
                                                       const std::string_view seed) {
    std::vector<EncodedRecord> output = make_complete_fixture(Terminal::effect, seed);
    output.resize(3U);
    RecordV1 appraisal = decode_or_empty(output[2U]);
    appraisal.decision = decision;
    output[2U] = encode_or_empty(appraisal);
    set_predecessors(output);
    return output;
}

bool run_campaign(const std::filesystem::path& output_directory) {
    std::error_code ec;
    std::filesystem::remove_all(output_directory, ec);
    ec.clear();
    std::filesystem::create_directories(output_directory, ec);
    if (ec) return false;

    const auto effect = make_complete_fixture(Terminal::effect, "effect");
    const auto no_effect = make_complete_fixture(Terminal::no_effect, "no-effect");
    const auto uncertain = make_complete_fixture(Terminal::uncertain, "uncertain");
    const auto fail_stop = make_complete_fixture(Terminal::fail_stop, "fail-stop");
    std::vector<Case> cases{
        {"positive-effect", "positive/effect.dossier", effect,
         ValidationCode::effect, true, true, true, false},
        {"positive-no-effect", "positive/no-effect.dossier", no_effect,
         ValidationCode::no_effect, true, true, true, false},
        {"positive-uncertain", "positive/uncertain.dossier", uncertain,
         ValidationCode::uncertain, true, true, true, false},
        {"positive-fail-stop", "positive/fail-stop.dossier", fail_stop,
         ValidationCode::fail_stop, true, true, true, false},
        {"appraisal-reject-stop", "stops/reject.prefix",
         make_appraisal_stop_fixture(Decision::reject, "reject"),
         ValidationCode::reject_stop, true, false, false, false},
        {"appraisal-indeterminate-stop", "stops/indeterminate.prefix",
         make_appraisal_stop_fixture(Decision::indeterminate, "indeterminate"),
         ValidationCode::indeterminate_stop, true, false, false, false},
        {"coherent-rewrite-integrity-not-authority", "countermodels/coherent-rewrite.dossier",
         coherent_rewrite(effect), ValidationCode::effect, true, true, true, true},
    };

    {
        Case c{"reordered-r4-r5", "negative/01-reordered-r4-r5.bin", effect,
               ValidationCode::invalid_order, false, false, false, false};
        std::swap(c.records[3U], c.records[4U]);
        cases.push_back(std::move(c));
    }
    {
        Case c{"omitted-r4", "negative/02-omitted-r4.bin", effect,
               ValidationCode::invalid_count, false, false, false, false};
        c.records.erase(c.records.begin() + 3);
        cases.push_back(std::move(c));
    }
    {
        Case c{"duplicated-r3", "negative/03-duplicated-r3.bin", effect,
               ValidationCode::invalid_count, false, false, false, false};
        c.records.insert(c.records.begin() + 3, c.records[2U]);
        cases.push_back(std::move(c));
    }
    {
        Case c{"broken-predecessor", "negative/04-broken-predecessor.bin", effect,
               ValidationCode::invalid_chain, false, false, false, false};
        RecordV1 record = decode_or_empty(c.records[4U]);
        record.predecessor[0U] ^= 0x01U;
        c.records[4U] = encode_or_empty(record);
        cases.push_back(std::move(c));
    }
    cases.push_back(semantic_mutation("foreign-transaction", "negative/05-foreign-transaction.bin",
        effect, 3U, ValidationCode::invalid_binding, [](RecordV1& r) { r.transaction_id = labeled_digest("foreign/tx"); }));
    cases.push_back(semantic_mutation("subject-substitution", "negative/06-subject-substitution.bin",
        effect, 1U, ValidationCode::invalid_binding, [](RecordV1& r) { r.subject = labeled_digest("foreign/subject"); }));
    cases.push_back(semantic_mutation("policy-substitution", "negative/07-policy-substitution.bin",
        effect, 4U, ValidationCode::invalid_binding, [](RecordV1& r) { r.policy = labeled_digest("foreign/policy"); }));
    cases.push_back(semantic_mutation("generation-mismatch", "negative/08-generation-mismatch.bin",
        effect, 2U, ValidationCode::invalid_binding, [](RecordV1& r) { r.generation_from += 1U; }));
    cases.push_back(semantic_mutation("nonce-mismatch", "negative/09-nonce-mismatch.bin",
        effect, 5U, ValidationCode::invalid_binding, [](RecordV1& r) { r.nonce += 1U; }));
    {
        Case c = semantic_mutation("actor-collision", "negative/10-actor-collision.bin",
            effect, 5U, ValidationCode::invalid_profile, [effect](RecordV1& r) {
                const RecordV1 previous = decode_or_empty(effect[4U]);
                r.actor = previous.actor;
            });
        cases.push_back(std::move(c));
    }
    cases.push_back(semantic_mutation("reject-followed-by-permit", "negative/11-reject-followed-by-permit.bin",
        effect, 2U, ValidationCode::invalid_profile, [](RecordV1& r) { r.decision = Decision::reject; }));
    cases.push_back(semantic_mutation("unscoped-permit", "negative/12-unscoped-permit.bin",
        effect, 3U, ValidationCode::invalid_profile, [](RecordV1& r) { r.flags = 0U; }));
    cases.push_back(semantic_mutation("unspent-effect", "negative/13-unspent-effect.bin",
        effect, 4U, ValidationCode::invalid_profile, [](RecordV1& r) { r.flags = permit_scoped; }));
    cases.push_back(semantic_mutation("missing-result", "negative/14-missing-result.bin",
        effect, 4U, ValidationCode::invalid_profile, [](RecordV1& r) { r.result.fill(0U); }));
    cases.push_back(semantic_mutation("uncertain-not-query-only", "negative/15-uncertain-not-query-only.bin",
        uncertain, 4U, ValidationCode::invalid_profile, [](RecordV1& r) { r.flags = permit_scoped | permit_spent; }));
    cases.push_back(semantic_mutation("effect-wrong-generation", "negative/16-effect-wrong-generation.bin",
        effect, 4U, ValidationCode::invalid_profile, [](RecordV1& r) { r.generation_to = r.generation_from; }));
    cases.push_back(semantic_mutation("reopen-flag-missing", "negative/17-reopen-flag-missing.bin",
        effect, 5U, ValidationCode::invalid_profile, [](RecordV1& r) { r.flags &= ~reopened; }));
    cases.push_back(semantic_mutation("terminal-mismatch", "negative/18-terminal-mismatch.bin",
        effect, 5U, ValidationCode::invalid_profile, [](RecordV1& r) { r.terminal = Terminal::no_effect; }));
    {
        Case c{"integrity-bit-flip", "negative/19-integrity-bit-flip.bin", effect,
               ValidationCode::invalid_record, false, false, false, false};
        c.records[2U][200U] ^= 0x80U;
        cases.push_back(std::move(c));
    }
    {
        Case c{"magic-corruption", "negative/20-magic-corruption.bin", effect,
               ValidationCode::invalid_record, false, false, false, false};
        c.records[0U][0U] ^= 0x01U;
        cases.push_back(std::move(c));
    }
    {
        Case c{"truncated-two-record-history", "negative/21-truncated-two-record-history.bin", effect,
               ValidationCode::invalid_count, false, false, false, false};
        c.records.resize(2U);
        cases.push_back(std::move(c));
    }
    cases.push_back(semantic_mutation("permit-substitution", "negative/22-permit-substitution.bin",
        effect, 4U, ValidationCode::invalid_profile, [](RecordV1& r) { r.permit = labeled_digest("foreign/permit"); }));
    cases.push_back(semantic_mutation("missing-currentness", "negative/23-missing-currentness.bin",
        effect, 5U, ValidationCode::invalid_profile, [](RecordV1& r) { r.currentness.fill(0U); }));
    cases.push_back(semantic_mutation("r3-pass-prefix-only", "negative/24-r3-pass-prefix-only.bin",
        std::vector<EncodedRecord>(effect.begin(), effect.begin() + 3), 2U,
        ValidationCode::invalid_count, [](RecordV1& r) { r.decision = Decision::pass; }));

    std::size_t valid = 0U;
    std::size_t rejected = 0U;
    std::size_t disagreements = 0U;
    std::size_t structurally_complete = 0U;
    std::size_t effect_bearing = 0U;
    std::size_t epoch_exit_true = 0U;
    std::size_t authority_true = 0U;
    std::string table = "case\tpath\texpected_code\texpected_valid\texpected_structurally_complete\texpected_effect_bearing\tepoch_exit_proved\tcoherent_nonauthority\tauthority_granted\n";
    for (const Case& test : cases) {
        const ValidationReport candidate = validate_candidate(test.records);
        const ValidationReport reference = validate_reference(test.records);
        if (candidate != reference) ++disagreements;
        if (candidate.code != test.expected || candidate.valid != test.valid
            || candidate.structurally_complete != test.structurally_complete
            || candidate.effect_bearing != test.effect_bearing
            || candidate.epoch_exit_proved
            || candidate.authority_granted) {
            std::cerr << "case=" << test.name
                      << " candidate=" << validation_code_name(candidate.code)
                      << " reference=" << validation_code_name(reference.code)
                      << " expected=" << validation_code_name(test.expected)
                      << " valid=" << candidate.valid << "/" << test.valid
                      << " structurally_complete=" << candidate.structurally_complete << "/" << test.structurally_complete
                      << " effect_bearing=" << candidate.effect_bearing << "/" << test.effect_bearing
                      << " epoch_exit_proved=" << candidate.epoch_exit_proved
                      << " agreement=" << (candidate == reference) << "\n";
            return false;
        }
        if (candidate.valid) ++valid;
        else ++rejected;
        if (candidate.structurally_complete) ++structurally_complete;
        if (candidate.effect_bearing) ++effect_bearing;
        if (candidate.epoch_exit_proved) ++epoch_exit_true;
        if (candidate.authority_granted) ++authority_true;
        if (!write_records(output_directory / test.path, test.records)) return false;
        table += test.name + "\t" + test.path + "\t"
            + std::string(validation_code_name(test.expected)) + "\t"
            + bool_text(test.valid) + "\t" + bool_text(test.structurally_complete) + "\t"
            + bool_text(test.effect_bearing) + "\tfalse\t"
            + bool_text(test.coherent_nonauthority) + "\tfalse\n";
    }
    if (!write_text(output_directory / "cases.tsv", table)) return false;

    const std::string one_use =
        "{\n"
        "  \"schema\": \"slopos.rev0912.one-use-countermodel.v1\",\n"
        "  \"copyable_permit_instances\": 2,\n"
        "  \"clone_local_accepts\": 2,\n"
        "  \"shared_atomic_spend_accepts\": 1,\n"
        "  \"restored_shared_snapshot_accepts\": 2,\n"
        "  \"move_only_same_history_bound\": true,\n"
        "  \"global_at_most_once_proved\": false,\n"
        "  \"authority_granted\": false\n"
        "}\n";
    if (!write_text(output_directory / "one-use-audit.json", one_use)) return false;

    const std::string audit =
        "{\n"
        "  \"schema\": \"slopos.rev0912.transaction-dossier-campaign.v1\",\n"
        "  \"status\": \"PASS\",\n"
        "  \"record_bytes\": 448,\n"
        "  \"complete_records\": 6,\n"
        "  \"cases\": " + std::to_string(cases.size()) + ",\n"
        "  \"valid_histories\": " + std::to_string(valid) + ",\n"
        "  \"rejected_histories\": " + std::to_string(rejected) + ",\n"
        "  \"terminal_profiles\": 4,\n"
        "  \"appraisal_stop_profiles\": 2,\n"
        "  \"coherent_rewrite_countermodels\": 1,\n"
        "  \"structurally_complete_histories\": " + std::to_string(structurally_complete) + ",\n"
        "  \"effect_bearing_histories\": " + std::to_string(effect_bearing) + ",\n"
        "  \"candidate_reference_disagreements\": " + std::to_string(disagreements) + ",\n"
        "  \"epoch_exit_true_results\": " + std::to_string(epoch_exit_true) + ",\n"
        "  \"authority_true_results\": " + std::to_string(authority_true) + ",\n"
        "  \"integrity_is_authentication\": false,\n"
        "  \"global_one_use_proved\": false,\n"
        "  \"authority_granted\": false\n"
        "}\n";
    return write_text(output_directory / "audit.json", audit);
}

}  // namespace slopos::e0::transaction_dossier
