#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/reopen_receipt_chain.hpp"

#include <filesystem>
#include <iostream>

int main(const int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "usage: slopos_reopen_receipt_chain OUTPUT_DIRECTORY\n";
        return 2;
    }
    if (!slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::run_campaign(std::filesystem::path(argv[1]))) {
        std::cerr << "REOPEN_RECEIPT_CHAIN_CAMPAIGN=FAIL\n";
        return 1;
    }
    std::cout << "REOPEN_RECEIPT_CHAIN_CAMPAIGN=PASS authority=false\n";
    return 0;
}
