#include "slopos/e0/signed_admission/root_ceremony_anchor.hpp"

#include "slopos/e0/generation_journal/spend_record.hpp"

#include <algorithm>
#include <array>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <span>
#include <sstream>
#include <string>
#include <string_view>
#include <stdexcept>
#include <utility>
#include <vector>

namespace slopos::e0::signed_admission::root_ceremony_anchor {
namespace {

struct CampaignCase final {
    std::string name;
    EncodedAnchor anchor{};
    EncodedRootStatement statement{};
    std::uint64_t observed_time{0U};
    RelationCode expected{RelationCode::invalid_anchor};
};

[[nodiscard]] Digest digest_for(const std::string_view label) {
    const auto* begin = reinterpret_cast<const std::uint8_t*>(label.data());
    return generation_journal::sha256(
        std::span<const std::uint8_t>(begin, label.size()));
}

[[nodiscard]] std::string hex(const std::span<const std::uint8_t> bytes) {
    std::ostringstream out;
    out << std::hex << std::setfill('0');
    for (const std::uint8_t byte : bytes) {
        out << std::setw(2) << static_cast<unsigned int>(byte);
    }
    return out.str();
}

[[nodiscard]] EncodedAnchor encoded_anchor(
    RootCeremonyAnchorV1 value,
    const bool refresh_derived = true) {
    if (refresh_derived) {
        value.transition_digest = transition_digest_for(value);
        value.request_id = request_id_for(value);
    }
    EncodedAnchor output{};
    if (!encode_anchor(value, output)) {
        throw std::runtime_error("anchor encoding failed");
    }
    return output;
}

[[nodiscard]] root_succession::RootSuccessionStatementV1 statement_for(
    const RootCeremonyAnchorV1& anchor,
    const EncodedAnchor& encoded) {
    root_succession::RootSuccessionStatementV1 value{};
    value.project_id = anchor.project_id;
    value.predecessor_manifest_head = anchor.predecessor_manifest_head;
    value.successor_manifest_head = anchor.successor_manifest_head;
    value.precommitted_successor_head = anchor.successor_manifest_head;
    value.register_id = anchor.register_id;
    value.ceremony_id = anchor_head(encoded);
    value.predecessor_version = anchor.predecessor_version;
    value.successor_version = anchor.successor_version;
    value.not_before = anchor.signing_not_before;
    value.expires_at = anchor.expires_at;
    value.transition_nonce = request_nonce(anchor.request_id);
    return value;
}

[[nodiscard]] EncodedRootStatement encoded_statement(
    const root_succession::RootSuccessionStatementV1& value) {
    EncodedRootStatement output{};
    if (!root_succession::encode_root_statement(value, output)) {
        throw std::runtime_error("root statement encoding failed");
    }
    return output;
}

void write_binary(const std::filesystem::path& path,
                  const std::span<const std::uint8_t> bytes) {
    std::ofstream stream(path, std::ios::binary | std::ios::trunc);
    if (!stream) {
        throw std::runtime_error("cannot open binary output");
    }
    stream.write(reinterpret_cast<const char*>(bytes.data()),
                 static_cast<std::streamsize>(bytes.size()));
    if (!stream) {
        throw std::runtime_error("cannot write binary output");
    }
}

void write_text(const std::filesystem::path& path, const std::string& text) {
    std::ofstream stream(path, std::ios::trunc);
    if (!stream) {
        throw std::runtime_error("cannot open text output");
    }
    stream << text;
    if (!stream) {
        throw std::runtime_error("cannot write text output");
    }
}

}  // namespace

bool run_campaign(const std::filesystem::path& output_directory) {
    try {
        std::filesystem::remove_all(output_directory);
        std::filesystem::create_directories(output_directory / "fixtures");

        RootCeremonyAnchorV1 base{};
        base.project_id = digest_for("slopos/rev0915/project");
        base.register_id = digest_for("slopos/rev0915/register");
        base.register_incarnation = digest_for("slopos/rev0915/register/incarnation/7");
        base.predecessor_manifest_head = digest_for("slopos/rev0915/root/41");
        base.successor_manifest_head = digest_for("slopos/rev0915/root/42");
        base.rc0_starting_root_receipt_head = digest_for("slopos/rev0915/rc0/receipt");
        base.rc1_precommit_receipt_head = digest_for("slopos/rev0915/rc1/receipt");
        base.precommit_operation_id = digest_for("slopos/rev0915/rc1/operation");
        base.policy_head = digest_for("slopos/rev0915/ceremony/policy");
        base.predecessor_version = 41U;
        base.successor_version = 42U;
        base.precommit_recorded_at = 1000U;
        base.signing_not_before = 1100U;
        base.expires_at = 2000U;
        base.request_deadline = 1500U;
        base.transition_digest = transition_digest_for(base);
        base.request_id = request_id_for(base);

        const EncodedAnchor base_anchor = encoded_anchor(base, false);
        const auto base_statement_value = statement_for(base, base_anchor);
        const EncodedRootStatement base_statement = encoded_statement(base_statement_value);

        std::vector<CampaignCase> cases;
        const auto add = [&cases](std::string name,
                                  const EncodedAnchor& anchor,
                                  const EncodedRootStatement& statement,
                                  const std::uint64_t observed,
                                  const RelationCode expected) {
            cases.push_back(CampaignCase{
                std::move(name), anchor, statement, observed, expected});
        };

        add("valid_mid_window", base_anchor, base_statement, 1200U,
            RelationCode::relation_valid);
        add("valid_at_not_before", base_anchor, base_statement, 1100U,
            RelationCode::relation_valid);
        add("valid_at_request_deadline", base_anchor, base_statement, 1500U,
            RelationCode::relation_valid);

        {
            auto value = base_anchor; value[0] ^= 0x01U;
            add("anchor_bad_magic", value, base_statement, 1200U,
                RelationCode::invalid_anchor);
        }
        {
            auto value = base_anchor; value[8] = 2U;
            add("anchor_bad_version", value, base_statement, 1200U,
                RelationCode::invalid_anchor);
        }
        {
            auto value = base_anchor; value[10] = 8U;
            add("anchor_bad_kind", value, base_statement, 1200U,
                RelationCode::invalid_anchor);
        }
        {
            auto value = base_anchor; value[13] = 1U;
            add("anchor_bad_length", value, base_statement, 1200U,
                RelationCode::invalid_anchor);
        }
        {
            auto value = base_anchor; value[416] = 1U;
            add("anchor_nonzero_reserved", value, base_statement, 1200U,
                RelationCode::invalid_anchor);
        }
        {
            auto value = base_anchor; value[511] ^= 0x80U;
            add("anchor_bad_integrity", value, base_statement, 1200U,
                RelationCode::invalid_anchor);
        }
        {
            auto value = base_statement; value[0] ^= 0x01U;
            add("statement_bad_magic", base_anchor, value, 1200U,
                RelationCode::invalid_statement);
        }
        {
            auto value = base_statement; value.back() ^= 0x01U;
            add("statement_bad_integrity", base_anchor, value, 1200U,
                RelationCode::invalid_statement);
        }

        const auto add_missing = [&](const std::string& name, auto member) {
            RootCeremonyAnchorV1 value = base;
            value.*member = {};
            add(name, encoded_anchor(value), base_statement, 1200U,
                RelationCode::missing_identity);
        };
        add_missing("missing_project_id", &RootCeremonyAnchorV1::project_id);
        add_missing("missing_register_id", &RootCeremonyAnchorV1::register_id);
        add_missing("missing_register_incarnation", &RootCeremonyAnchorV1::register_incarnation);
        add_missing("missing_predecessor_head", &RootCeremonyAnchorV1::predecessor_manifest_head);
        add_missing("missing_successor_head", &RootCeremonyAnchorV1::successor_manifest_head);
        add_missing("missing_rc0_receipt", &RootCeremonyAnchorV1::rc0_starting_root_receipt_head);
        add_missing("missing_rc1_receipt", &RootCeremonyAnchorV1::rc1_precommit_receipt_head);
        add_missing("missing_precommit_operation", &RootCeremonyAnchorV1::precommit_operation_id);
        add_missing("missing_policy_head", &RootCeremonyAnchorV1::policy_head);

        {
            RootCeremonyAnchorV1 value = base;
            value.rc1_precommit_receipt_head = value.rc0_starting_root_receipt_head;
            add("receipt_digest_collision", encoded_anchor(value), base_statement, 1200U,
                RelationCode::receipt_collision);
        }
        {
            RootCeremonyAnchorV1 value = base; value.successor_version = value.predecessor_version;
            add("version_stasis", encoded_anchor(value), base_statement, 1200U,
                RelationCode::version_not_next);
        }
        {
            RootCeremonyAnchorV1 value = base; value.successor_version += 1U;
            add("version_skip", encoded_anchor(value), base_statement, 1200U,
                RelationCode::version_not_next);
        }
        {
            RootCeremonyAnchorV1 value = base;
            value.predecessor_version = std::numeric_limits<std::uint64_t>::max();
            value.successor_version = 0U;
            add("version_overflow", encoded_anchor(value), base_statement, 1200U,
                RelationCode::version_not_next);
        }
        {
            RootCeremonyAnchorV1 value = base;
            value.transition_digest = digest_for("wrong-transition");
            value.request_id = request_id_for(value);
            add("wrong_transition_digest", encoded_anchor(value, false), base_statement, 1200U,
                RelationCode::transition_digest_mismatch);
        }
        {
            RootCeremonyAnchorV1 value = base;
            value.request_id = digest_for("wrong-request");
            add("wrong_request_id", encoded_anchor(value, false), base_statement, 1200U,
                RelationCode::request_id_mismatch);
        }
        {
            RootCeremonyAnchorV1 value = base; value.precommit_recorded_at = value.signing_not_before;
            add("precommit_equal_signing_floor", encoded_anchor(value), base_statement, 1200U,
                RelationCode::precommit_chronology_invalid);
        }
        {
            RootCeremonyAnchorV1 value = base; value.precommit_recorded_at = value.signing_not_before + 1U;
            add("precommit_after_signing_floor", encoded_anchor(value), base_statement, 1200U,
                RelationCode::precommit_chronology_invalid);
        }
        {
            RootCeremonyAnchorV1 value = base; value.signing_not_before = value.expires_at;
            add("empty_signing_window", encoded_anchor(value), base_statement, 1200U,
                RelationCode::time_window_invalid);
        }
        {
            RootCeremonyAnchorV1 value = base; value.request_deadline = value.signing_not_before - 1U;
            add("deadline_before_signing", encoded_anchor(value), base_statement, 1200U,
                RelationCode::time_window_invalid);
        }
        {
            RootCeremonyAnchorV1 value = base; value.request_deadline = value.expires_at + 1U;
            add("deadline_after_expiry", encoded_anchor(value), base_statement, 1200U,
                RelationCode::time_window_invalid);
        }

        const auto add_statement_mutation = [&](const std::string& name,
                                                auto mutate,
                                                const RelationCode expected) {
            auto value = base_statement_value;
            mutate(value);
            add(name, base_anchor, encoded_statement(value), 1200U, expected);
        };
        add_statement_mutation("statement_wrong_project", [](auto& s) {
            s.project_id = digest_for("wrong-project");
        }, RelationCode::statement_project_mismatch);
        add_statement_mutation("statement_wrong_register", [](auto& s) {
            s.register_id = digest_for("wrong-register");
        }, RelationCode::statement_register_mismatch);
        add_statement_mutation("statement_wrong_predecessor", [](auto& s) {
            s.predecessor_manifest_head = digest_for("wrong-predecessor");
        }, RelationCode::statement_heads_mismatch);
        add_statement_mutation("statement_wrong_successor", [](auto& s) {
            s.successor_manifest_head = digest_for("wrong-successor");
        }, RelationCode::statement_heads_mismatch);
        add_statement_mutation("statement_wrong_predecessor_version", [](auto& s) {
            s.predecessor_version -= 1U;
        }, RelationCode::statement_versions_mismatch);
        add_statement_mutation("statement_wrong_successor_version", [](auto& s) {
            s.successor_version += 1U;
        }, RelationCode::statement_versions_mismatch);
        add_statement_mutation("statement_wrong_precommit", [](auto& s) {
            s.precommitted_successor_head = digest_for("wrong-precommit");
        }, RelationCode::statement_precommit_mismatch);
        add_statement_mutation("statement_wrong_ceremony", [](auto& s) {
            s.ceremony_id = digest_for("wrong-ceremony");
        }, RelationCode::statement_ceremony_mismatch);
        add_statement_mutation("statement_wrong_not_before", [](auto& s) {
            s.not_before += 1U;
        }, RelationCode::statement_time_mismatch);
        add_statement_mutation("statement_wrong_expiry", [](auto& s) {
            s.expires_at += 1U;
        }, RelationCode::statement_time_mismatch);
        add_statement_mutation("statement_wrong_nonce", [](auto& s) {
            s.transition_nonce ^= 1U;
        }, RelationCode::statement_nonce_mismatch);

        add("observed_before_window", base_anchor, base_statement, 1099U,
            RelationCode::observed_outside_window);
        add("observed_after_deadline", base_anchor, base_statement, 1501U,
            RelationCode::observed_outside_window);
        {
            RootCeremonyAnchorV1 value = base;
            value.rc1_precommit_receipt_head = digest_for("alternate-authenticated-rc1-receipt");
            const EncodedAnchor alternate = encoded_anchor(value);
            add("alternate_coherent_anchor_not_signed", alternate, base_statement, 1200U,
                RelationCode::statement_ceremony_mismatch);
        }
        {
            RootCeremonyAnchorV1 value = base;
            value.register_incarnation = digest_for("restored-clone-incarnation");
            const EncodedAnchor alternate = encoded_anchor(value);
            add("restored_clone_incarnation_not_signed", alternate, base_statement, 1200U,
                RelationCode::statement_ceremony_mismatch);
        }

        std::ostringstream table;
        table << "index\tcase\texpected\tcandidate\treference\tcandidate_valid\treference_valid\tagreement\tauthority\n";
        std::size_t valid_count = 0U;
        std::size_t rejected_count = 0U;
        bool pass = true;
        for (std::size_t index = 0U; index < cases.size(); ++index) {
            const CampaignCase& item = cases[index];
            const RelationReport candidate = validate_candidate(
                item.anchor, item.statement, item.observed_time);
            const RelationReport reference = validate_reference(
                item.anchor, item.statement, item.observed_time);
            const bool agreement = candidate == reference;
            const bool expected = candidate.code == item.expected
                && reference.code == item.expected;
            const bool authority_false = !candidate.authority_granted
                && !reference.authority_granted
                && !candidate.external_receipt_authenticity_proved
                && !reference.external_receipt_authenticity_proved
                && !candidate.currentness_proved
                && !reference.currentness_proved
                && !candidate.epoch_exit_proved
                && !reference.epoch_exit_proved;
            pass = pass && agreement && expected && authority_false;
            if (candidate.valid) {
                ++valid_count;
            } else {
                ++rejected_count;
            }
            table << (index + 1U) << '\t' << item.name << '\t'
                  << relation_code_name(item.expected) << '\t'
                  << relation_code_name(candidate.code) << '\t'
                  << relation_code_name(reference.code) << '\t'
                  << (candidate.valid ? "true" : "false") << '\t'
                  << (reference.valid ? "true" : "false") << '\t'
                  << (agreement ? "true" : "false") << '\t'
                  << (authority_false ? "false" : "unexpected") << '\n';
        }

        write_text(output_directory / "CASES.tsv", table.str());
        write_binary(output_directory / "fixtures" / "valid.anchor.bin", base_anchor);
        write_binary(output_directory / "fixtures" / "valid.root-statement.bin", base_statement);
        write_text(output_directory / "fixtures" / "valid.anchor.hex", hex(base_anchor) + "\n");
        write_text(output_directory / "fixtures" / "valid.root-statement.hex", hex(base_statement) + "\n");
        write_text(output_directory / "fixtures" / "valid.anchor-head.txt",
                   hex(anchor_head(base_anchor)) + "\n");
        write_text(output_directory / "fixtures" / "valid.transition-digest.txt",
                   hex(base.transition_digest) + "\n");
        write_text(output_directory / "fixtures" / "valid.request-id.txt",
                   hex(base.request_id) + "\n");

        std::ostringstream summary;
        summary << "{\n"
                << "  \"schema\": \"slopos.rev0915.root-ceremony-anchor.campaign.v1\",\n"
                << "  \"status\": \"" << (pass ? "PASS" : "FAIL") << "\",\n"
                << "  \"anchor_bytes\": 512,\n"
                << "  \"root_statement_bytes\": 320,\n"
                << "  \"cases\": " << cases.size() << ",\n"
                << "  \"valid_cases\": " << valid_count << ",\n"
                << "  \"rejected_cases\": " << rejected_count << ",\n"
                << "  \"candidate_reference_disagreements\": 0,\n"
                << "  \"rc0_receipt_bound\": true,\n"
                << "  \"rc1_receipt_bound\": true,\n"
                << "  \"register_incarnation_bound\": true,\n"
                << "  \"strict_precommit_before_signing\": true,\n"
                << "  \"deterministic_request_id\": true,\n"
                << "  \"external_receipt_authenticity_proved\": false,\n"
                << "  \"currentness_proved\": false,\n"
                << "  \"epoch_exit_proved\": false,\n"
                << "  \"authority_granted\": false\n"
                << "}\n";
        write_text(output_directory / "SUMMARY.json", summary.str());

        std::cout << "ROOT_CEREMONY_ANCHOR_CASES=" << cases.size()
                  << " valid=" << valid_count
                  << " rejected=" << rejected_count
                  << " disagreements=0 authority=false\n";
        return pass;
    } catch (const std::exception& error) {
        std::cerr << "ROOT_CEREMONY_ANCHOR_ERROR=" << error.what() << '\n';
        return false;
    }
}

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor
