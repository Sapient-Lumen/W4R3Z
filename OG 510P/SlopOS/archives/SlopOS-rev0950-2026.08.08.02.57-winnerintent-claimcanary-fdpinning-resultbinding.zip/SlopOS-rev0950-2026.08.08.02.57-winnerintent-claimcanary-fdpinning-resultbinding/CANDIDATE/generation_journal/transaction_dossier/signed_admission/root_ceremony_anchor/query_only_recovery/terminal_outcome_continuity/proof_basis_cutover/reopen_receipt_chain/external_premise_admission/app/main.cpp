#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/reopen_receipt_chain/external_premise_admission.hpp"

#include <filesystem>
#include <iostream>

int main(const int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "usage: slopos_external_premise_admission OUTPUT_DIRECTORY\n";
        return 2;
    }
    if (!slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::run_campaign(std::filesystem::path(argv[1]))) {
        std::cerr << "EXTERNAL_PREMISE_ADMISSION_CAMPAIGN=FAIL\n";
        return 1;
    }
    std::cout << "EXTERNAL_PREMISE_ADMISSION_CAMPAIGN=PASS authority=false epoch_exit=false\n";
    return 0;
}
