#pragma once

#include "slopos/e0/signed_admission/admission.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <string_view>

namespace slopos::e0::signed_admission::root_succession {

using signed_admission::Digest;
using signed_admission::EncodedManifest;
using signed_admission::OwnerManifestV1;
using signed_admission::SignatureSlotV1;

inline constexpr std::size_t kRootStatementBytes = 320U;
inline constexpr std::size_t kRootEnvelopeBytes = 1024U;
inline constexpr std::size_t kRootSigningMessageBytes = 360U;
inline constexpr std::size_t kRootReceiptBytes = 256U;

using EncodedRootStatement = std::array<std::uint8_t, kRootStatementBytes>;
using EncodedRootEnvelope = std::array<std::uint8_t, kRootEnvelopeBytes>;
using RootSigningMessage = std::array<std::uint8_t, kRootSigningMessageBytes>;
using EncodedRootReceipt = std::array<std::uint8_t, kRootReceiptBytes>;

struct RootSuccessionStatementV1 final {
    Digest project_id{};
    Digest predecessor_manifest_head{};
    Digest successor_manifest_head{};
    Digest precommitted_successor_head{};
    Digest register_id{};
    Digest ceremony_id{};
    std::uint64_t predecessor_version{0U};
    std::uint64_t successor_version{0U};
    std::uint64_t not_before{0U};
    std::uint64_t expires_at{0U};
    std::uint64_t transition_nonce{0U};

    [[nodiscard]] friend constexpr bool operator==(
        const RootSuccessionStatementV1&,
        const RootSuccessionStatementV1&) noexcept = default;
};

struct DualThresholdEnvelopeV1 final {
    EncodedRootStatement statement{};
    std::uint8_t predecessor_signature_count{0U};
    std::uint8_t successor_signature_count{0U};
    std::array<SignatureSlotV1, kMaximumKeys> predecessor_signatures{};
    std::array<SignatureSlotV1, kMaximumKeys> successor_signatures{};

    [[nodiscard]] friend constexpr bool operator==(
        const DualThresholdEnvelopeV1&,
        const DualThresholdEnvelopeV1&) noexcept = default;
};

enum class EvidenceCode : std::uint8_t {
    evidence_valid,
    invalid_predecessor_manifest,
    invalid_successor_manifest,
    invalid_envelope,
    invalid_statement,
    project_mismatch,
    predecessor_chain_mismatch,
    version_not_next,
    statement_binding_mismatch,
    statement_precommit_mismatch,
    time_window_mismatch,
    predecessor_unknown_signer,
    predecessor_duplicate_signer,
    predecessor_invalid_signature,
    predecessor_below_threshold,
    successor_unknown_signer,
    successor_duplicate_signer,
    successor_invalid_signature,
    successor_below_threshold,
};

struct EvidenceReport final {
    EvidenceCode code{EvidenceCode::invalid_predecessor_manifest};
    std::size_t predecessor_verified_signatures{0U};
    std::size_t successor_verified_signatures{0U};
    bool valid{false};
    bool predecessor_manifest_valid{false};
    bool successor_manifest_valid{false};
    bool statement_valid{false};
    bool exact_next_version{false};
    bool predecessor_threshold_met{false};
    bool successor_threshold_met{false};
    bool precommit_bound{false};
    bool time_window_match{false};
    bool owner_constitution_proved{false};
    bool currentness_proved{false};
    bool independent_custody_proved{false};
    bool protected_transition_proved{false};
    bool independent_reopen_proved{false};
    bool epoch_exit_proved{false};
    bool authority_granted{false};

    [[nodiscard]] friend constexpr bool operator==(
        const EvidenceReport&, const EvidenceReport&) noexcept = default;
};

struct CurrentRootRegisterV1 final {
    Digest register_id{};
    Digest current_manifest_head{};
    Digest precommitted_successor_head{};
    std::uint64_t current_version{0U};
    std::uint64_t transition_ordinal{0U};

    [[nodiscard]] friend constexpr bool operator==(
        const CurrentRootRegisterV1&,
        const CurrentRootRegisterV1&) noexcept = default;
};

enum class ReplyCut : std::uint8_t {
    reply_delivered = 1U,
    reply_lost_after_commit = 2U,
};

enum class ApplyCode : std::uint8_t {
    committed,
    already_current_query_only,
    uncertain_after_commit_query_only,
    invalid_evidence,
    register_id_mismatch,
    stale_current,
    register_precommit_mismatch,
};

enum class ReceiptDisposition : std::uint8_t {
    committed = 1U,
    already_current_query_only = 2U,
    uncertain_after_commit_query_only = 3U,
};

struct RootTransitionReceiptV1 final {
    ReceiptDisposition disposition{ReceiptDisposition::committed};
    bool query_only{false};
    Digest register_id{};
    Digest predecessor_manifest_head{};
    Digest successor_manifest_head{};
    Digest statement_head{};
    Digest ceremony_id{};
    std::uint64_t predecessor_version{0U};
    std::uint64_t successor_version{0U};
    std::uint64_t transition_ordinal{0U};
    std::uint64_t observed_time{0U};

    [[nodiscard]] friend constexpr bool operator==(
        const RootTransitionReceiptV1&,
        const RootTransitionReceiptV1&) noexcept = default;
};

struct ApplyReport final {
    ApplyCode code{ApplyCode::invalid_evidence};
    EvidenceReport evidence{};
    bool committed{false};
    bool query_only{false};
    bool receipt_present{false};
    EncodedRootReceipt receipt{};
    bool owner_constitution_proved{false};
    bool currentness_proved{false};
    bool independent_custody_proved{false};
    bool protected_transition_proved{false};
    bool independent_reopen_proved{false};
    bool epoch_exit_proved{false};
    bool authority_granted{false};

    [[nodiscard]] friend constexpr bool operator==(
        const ApplyReport&, const ApplyReport&) noexcept = default;
};

[[nodiscard]] Digest root_statement_head(const EncodedRootStatement& statement);
[[nodiscard]] bool encode_root_statement(
    const RootSuccessionStatementV1& value,
    EncodedRootStatement& output);
[[nodiscard]] bool decode_root_statement(
    const EncodedRootStatement& input,
    RootSuccessionStatementV1& output);
[[nodiscard]] bool encode_root_envelope(
    const DualThresholdEnvelopeV1& value,
    EncodedRootEnvelope& output);
[[nodiscard]] bool decode_root_envelope(
    const EncodedRootEnvelope& input,
    DualThresholdEnvelopeV1& output);
[[nodiscard]] RootSigningMessage root_signing_message_for(
    const EncodedRootStatement& statement);
[[nodiscard]] bool encode_root_receipt(
    const RootTransitionReceiptV1& value,
    EncodedRootReceipt& output);
[[nodiscard]] bool decode_root_receipt(
    const EncodedRootReceipt& input,
    RootTransitionReceiptV1& output);

[[nodiscard]] EvidenceReport validate_candidate(
    const EncodedManifest& predecessor_manifest,
    const EncodedManifest& successor_manifest,
    const EncodedRootEnvelope& envelope,
    std::uint64_t observed_time);
[[nodiscard]] EvidenceReport validate_reference(
    const EncodedManifest& predecessor_manifest,
    const EncodedManifest& successor_manifest,
    const EncodedRootEnvelope& envelope,
    std::uint64_t observed_time);

[[nodiscard]] ApplyReport apply_candidate(
    CurrentRootRegisterV1& root_register,
    const EncodedManifest& predecessor_manifest,
    const EncodedManifest& successor_manifest,
    const EncodedRootEnvelope& envelope,
    std::uint64_t observed_time,
    ReplyCut reply_cut);
[[nodiscard]] ApplyReport apply_reference(
    CurrentRootRegisterV1& root_register,
    const EncodedManifest& predecessor_manifest,
    const EncodedManifest& successor_manifest,
    const EncodedRootEnvelope& envelope,
    std::uint64_t observed_time,
    ReplyCut reply_cut);

[[nodiscard]] std::string_view evidence_code_name(EvidenceCode value) noexcept;
[[nodiscard]] std::string_view apply_code_name(ApplyCode value) noexcept;
[[nodiscard]] bool run_root_succession_campaign(
    const std::filesystem::path& output_directory);

}  // namespace slopos::e0::signed_admission::root_succession
