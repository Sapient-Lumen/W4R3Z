#pragma once

#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover.hpp"

#include <array>
#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <string_view>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::exact_predecessor_consumption {

inline constexpr std::size_t phase_count = 5U;
inline constexpr std::size_t chain_cut_count = 8U;

enum class Phase : std::uint8_t {
    witness_publication = 0U,
    floor_publication = 1U,
    join_publication = 2U,
    cold_reopen_receipt = 3U,
    deletion_authorization = 4U,
};

enum class ChainCode : std::uint8_t {
    accepted_chain_complete,
    accepted_chain_ready_live_retained,
    accepted_chain_prefix_live_retained,
    accepted_reclamation_refused_exact_predecessor,
    accepted_reclamation_refused_publication,
    accepted_reclamation_refused_phase_order,
    accepted_reclamation_refused_prefix_gap,
    accepted_equivocation_fail_stop,
    accepted_regression_fail_stop,
    parent_relation_rejected,
    reclamation_request_mismatch,
    receipt_shape_invalid,
    receipt_phase_mismatch,
    receipt_subject_mismatch,
    receipt_component_mismatch,
    receipt_digest_zero,
    receipt_digest_duplicate,
    trace_initial_state_invalid,
    trace_deleted_and_live,
    trace_absent_without_deletion,
};

struct PhaseReceipt final {
    Phase phase{Phase::witness_publication};
    Digest record_digest{};
    Digest cutover_id{};
    Digest request_id{};
    Digest transition_digest{};
    Digest register_incarnation{};
    Digest terminal_digest{};
    Digest witness_digest{};
    Digest floor_digest{};
    Digest basis_digest{};
    Digest predecessor_a{};
    Digest predecessor_b{};
    TerminalKind terminal_kind{TerminalKind::effect};

    bool present{false};
    bool authenticated{false};
    bool durable{false};
    bool single_view{false};
    bool independently_reopenable{false};
    bool survives_restore{false};
    bool survives_succession{false};
    bool published{false};

    [[nodiscard]] friend constexpr bool operator==(
        const PhaseReceipt&, const PhaseReceipt&) noexcept = default;
};

struct ChainCut final {
    bool live_record_visible{false};
    std::array<bool, phase_count> receipt_visible{};
    bool deletion_applied{false};

    [[nodiscard]] friend constexpr bool operator==(
        const ChainCut&, const ChainCut&) noexcept = default;
};

struct ChainTrace final {
    CutoverTrace parent{};
    std::array<PhaseReceipt, phase_count> receipts{};
    std::array<ChainCut, chain_cut_count> cuts{};
    Digest deletion_consumed_authorization_digest{};
    bool reclamation_requested{false};
    bool equivocation_observed{false};

    [[nodiscard]] friend constexpr bool operator==(
        const ChainTrace&, const ChainTrace&) noexcept = default;
};

struct ChainReport final {
    ChainCode code{ChainCode::parent_relation_rejected};
    bool accepted{false};
    bool parent_accepted{false};
    bool parent_reclamation_safe{false};
    bool receipt_subjects_exact{false};
    bool receipt_components_exact{false};
    bool receipt_digests_unique{false};
    bool exact_predecessor_edges{false};
    bool durable_publications{false};
    bool strict_phase_order{false};
    bool monotone_visibility{false};
    bool every_prefix_covered{false};
    bool chain_complete{false};
    bool deletion_safe{false};
    bool live_record_must_remain{true};
    bool fail_stopped{false};
    bool mere_prior_visibility_sufficient{false};
    bool external_occurrence_proved{false};
    bool currentness_proved{false};
    bool independent_custody_proved{false};
    bool epoch_exit_proved{false};
    bool authority_granted{false};

    [[nodiscard]] friend constexpr bool operator==(
        const ChainReport&, const ChainReport&) noexcept = default;
};

[[nodiscard]] ChainReport evaluate_candidate(const ChainTrace& trace) noexcept;
[[nodiscard]] ChainReport evaluate_reference(const ChainTrace& trace) noexcept;
[[nodiscard]] std::string_view chain_code_name(ChainCode value) noexcept;
[[nodiscard]] std::string_view phase_name(Phase value) noexcept;
[[nodiscard]] std::string_view chain_cut_name(std::size_t index) noexcept;
[[nodiscard]] bool run_campaign(const std::filesystem::path& output_directory);

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::exact_predecessor_consumption
