# Hosted Externality Nonderivation V1

## Input

One accepted, closure-ready Observed Output Closure trace; the exact linked rev0923 archive identity; a fifteen-claim catalogue; an owner-handoff policy; and a response profile.

## Relation

Let `O` be the 320-byte canonical hosted observation and let `P_i` be one of fifteen external predicates. For each requested `P_i`, the campaign constructs two modeled worlds `W0` and `W1` such that:

```text
encode(O(W0)) = encode(O(W1))
P_i(W0) != P_i(W1)
```

Therefore a deterministic function whose complete input is `encode(O)` cannot soundly derive `P_i` over both worlds. The witness establishes only this observational insufficiency. It does not establish that either world occurred.

## Durable order

1. parent closure;
2. exact hosted observation;
3. twin-world nonderivation witness;
4. request-only owner handoff subject;
5. premise-deficit certificate.

Every prefix is resumable. A later object may not precede its predecessor.

## Fail-closed boundary

The following remain false unless supplied through a separately governed channel whose trust root is not produced by the subject: source origin, dependency completeness, operated build, trusted builder control, external publication, independent exact reopen, administrative independence, custody independence, rollback independence, shared-view consistency, complete control inventory, valid owner constitution, current owner admission, authority, and Epoch-Zero exit.

The catalogue uses fifteen independent bits. In particular, `AUTHORITY_GRANTED` and `EPOCH_ZERO_EXITED` are not compressed into one conjunction-shaped bit.
