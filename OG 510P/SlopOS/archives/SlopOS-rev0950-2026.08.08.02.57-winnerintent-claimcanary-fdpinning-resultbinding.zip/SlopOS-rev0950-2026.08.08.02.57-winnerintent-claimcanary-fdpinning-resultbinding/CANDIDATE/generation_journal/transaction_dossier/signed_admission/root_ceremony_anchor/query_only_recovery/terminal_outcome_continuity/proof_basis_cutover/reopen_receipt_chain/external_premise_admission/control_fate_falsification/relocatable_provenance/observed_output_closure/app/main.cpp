#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover/reopen_receipt_chain/external_premise_admission/control_fate_falsification/relocatable_provenance/observed_output_closure.hpp"

#include <filesystem>
#include <iostream>

int main(int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "usage: slopos_observed_output_closure OUTPUT_DIRECTORY\n";
        return 64;
    }
    return slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::reopen_receipt_chain::external_premise_admission::control_fate_falsification::relocatable_provenance::observed_output_closure::run_campaign(std::filesystem::path(argv[1])) ? 0 : 1;
}
