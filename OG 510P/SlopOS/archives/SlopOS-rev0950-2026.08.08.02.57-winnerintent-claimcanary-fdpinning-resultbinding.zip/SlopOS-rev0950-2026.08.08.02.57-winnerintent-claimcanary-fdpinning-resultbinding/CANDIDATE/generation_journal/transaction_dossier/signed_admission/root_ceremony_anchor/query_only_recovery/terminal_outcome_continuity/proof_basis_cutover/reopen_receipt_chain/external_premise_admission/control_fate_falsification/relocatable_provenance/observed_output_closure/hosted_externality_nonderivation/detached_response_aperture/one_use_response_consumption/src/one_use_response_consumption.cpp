#include "slopos/e0/detached_response_aperture/one_use_response_consumption.hpp"

#include <openssl/evp.h>

#include <algorithm>
#include <array>
#include <cstring>
#include <string>
#include <vector>

#ifndef SLOPOS_OURC_PARENT_OUTPUT_SET_SHA256_HEX
#error "parent output set digest required"
#endif
#ifndef SLOPOS_OURC_PARENT_COMPOSITION_RECEIPT_SHA256_HEX
#error "parent composition receipt digest required"
#endif
#ifndef SLOPOS_OURC_PARENT_RESPONSE_SHA256_HEX
#error "parent response digest required"
#endif
#ifndef SLOPOS_OURC_PARENT_ACCEPTING_CONFIGURATION_SHA256_HEX
#error "parent accepting configuration digest required"
#endif
#ifndef SLOPOS_OURC_PARENT_APPRAISAL_WITNESS_SHA256_HEX
#error "parent appraisal witness digest required"
#endif
#ifndef SLOPOS_OURC_PARENT_CONSUMPTION_DEFICIT_SHA256_HEX
#error "parent consumption deficit digest required"
#endif
#ifndef SLOPOS_OURC_PARENT_ARCHIVE_SHA256_HEX
#error "parent archive digest required"
#endif
#ifndef SLOPOS_OURC_CONSUMPTION_POLICY_SHA256_HEX
#error "consumption policy digest required"
#endif
#ifndef SLOPOS_OURC_QUERY_POLICY_SHA256_HEX
#error "query policy digest required"
#endif
#ifndef SLOPOS_OURC_REOPEN_POLICY_SHA256_HEX
#error "reopen policy digest required"
#endif
#ifndef SLOPOS_OURC_REOPENER_IMPLEMENTATION_SHA256_HEX
#error "reopener implementation digest required"
#endif

namespace slopos::e0::detached_response_aperture::one_use_response_consumption {
namespace {

[[nodiscard]] constexpr std::uint8_t nybble(const char value) noexcept {
    if (value >= '0' && value <= '9') return static_cast<std::uint8_t>(value - '0');
    if (value >= 'a' && value <= 'f') return static_cast<std::uint8_t>(10 + value - 'a');
    return 0U;
}

[[nodiscard]] Digest exact_digest(const std::string_view hex) noexcept {
    Digest value{};
    if (hex.size() != 64U) return value;
    for (std::size_t index = 0U; index < value.size(); ++index) {
        value[index] = static_cast<std::uint8_t>((nybble(hex[index * 2U]) << 4U) | nybble(hex[index * 2U + 1U]));
    }
    return value;
}

[[nodiscard]] bool nonzero(const Digest& value) noexcept {
    return std::any_of(value.begin(), value.end(), [](const std::uint8_t byte) { return byte != 0U; });
}

template <std::size_t N>
class Writer final {
public:
    explicit Writer(std::array<std::uint8_t, N>& output) noexcept : output_(output) { output_.fill(0U); }
    void digest(const Digest& value) noexcept { bytes(value.data(), value.size()); }
    void u64(const std::uint64_t value) noexcept {
        for (std::size_t i = 0U; i < 8U; ++i) push(static_cast<std::uint8_t>((value >> (8U * i)) & 0xffU));
    }
    void u32(const std::uint32_t value) noexcept {
        for (std::size_t i = 0U; i < 4U; ++i) push(static_cast<std::uint8_t>((value >> (8U * i)) & 0xffU));
    }
    void u8(const std::uint8_t value) noexcept { push(value); }
    void flag(const bool value) noexcept { push(value ? 1U : 0U); }
    [[nodiscard]] bool okay() const noexcept { return okay_; }
private:
    void bytes(const std::uint8_t* data, const std::size_t size) noexcept {
        if (position_ + size > N) { okay_ = false; return; }
        std::copy_n(data, size, output_.begin() + static_cast<std::ptrdiff_t>(position_));
        position_ += size;
    }
    void push(const std::uint8_t value) noexcept {
        if (position_ >= N) { okay_ = false; return; }
        output_[position_++] = value;
    }
    std::array<std::uint8_t, N>& output_;
    std::size_t position_{0U};
    bool okay_{true};
};

template <std::size_t N, typename Fill>
[[nodiscard]] Digest identity_from(const std::string_view domain, Fill&& fill) noexcept {
    std::array<std::uint8_t, N> bytes{};
    Writer<N> writer(bytes);
    writer.digest(Digest{});
    fill(writer);
    if (!writer.okay()) return {};
    return sha256_domain(domain, bytes.data() + 32U, bytes.size() - 32U);
}

template <std::size_t N, typename Fill>
[[nodiscard]] bool encode_with_identity(
    const Digest& identity,
    const std::string_view domain,
    Fill&& fill,
    std::array<std::uint8_t, N>& output) noexcept {
    Writer<N> writer(output);
    writer.digest(identity);
    fill(writer);
    return writer.okay() && identity == sha256_domain(domain, output.data() + 32U, output.size() - 32U);
}

void fill_parent(const ParentBinding& v, auto& w) noexcept {
    w.digest(v.parent_output_set_digest); w.digest(v.parent_composition_receipt_digest);
    w.digest(v.response_digest); w.digest(v.accepting_configuration_digest);
    w.digest(v.appraisal_witness_digest); w.digest(v.consumption_deficit_digest);
    w.digest(v.parent_archive_digest); w.u64(v.parent_archive_bytes); w.u64(v.parent_manifest_rows);
    w.u32(v.schema); w.flag(v.present); w.flag(v.canonical); w.flag(v.parent_aperture_pass);
    w.flag(v.parent_external_response_present); w.flag(v.parent_authority_granted);
}
void fill_appraisal(const AppraisalCarrier& v, auto& w) noexcept {
    w.digest(v.parent_binding_digest); w.digest(v.response_digest); w.digest(v.accepting_configuration_digest);
    w.digest(v.appraisal_witness_digest); w.digest(v.owner_root_digest); w.digest(v.appraisal_policy_digest);
    w.digest(v.trusted_time_source_digest); w.u64(v.owner_root_version); w.u64(v.appraisal_time);
    w.u64(v.consume_not_after); w.u32(v.schema); w.flag(v.present); w.flag(v.canonical);
    w.flag(v.appraisal_accepted); w.flag(v.laboratory_carrier); w.flag(v.external_currentness_proved);
}
void fill_request(const ConsumeRequest& v, auto& w) noexcept {
    w.digest(v.parent_binding_digest); w.digest(v.response_digest); w.digest(v.appraisal_carrier_digest);
    w.digest(v.expected_predecessor_head); w.digest(v.operation_id); w.digest(v.journal_namespace_digest);
    w.digest(v.consumption_policy_digest); w.digest(v.request_payload_digest);
    w.u64(v.expected_generation); w.u64(v.requested_at); w.u32(v.schema);
    w.flag(v.present); w.flag(v.canonical); w.flag(v.fixed_payload); w.flag(v.blind_retry_forbidden);
}
void fill_invocation(const PendingInvocation& v, auto& w) noexcept {
    w.digest(v.request_digest); w.digest(v.operation_id); w.digest(v.expected_predecessor_head);
    w.digest(v.journal_namespace_digest); w.digest(v.submission_channel_digest); w.digest(v.query_policy_digest);
    w.u64(v.submitted_at); w.u32(v.schema); w.flag(v.present); w.flag(v.canonical);
    w.flag(v.response_returned); w.flag(v.query_only_after_loss);
}
void fill_query(const QueryObservation& v, auto& w) noexcept {
    w.digest(v.invocation_digest); w.digest(v.request_digest); w.digest(v.operation_id);
    w.digest(v.expected_predecessor_head); w.digest(v.observed_head); w.digest(v.journal_namespace_digest);
    w.digest(v.query_policy_digest); w.digest(v.query_role_digest);
    w.u64(v.observed_generation); w.u64(v.query_revision); w.u64(v.queried_at); w.u32(v.schema);
    w.u8(static_cast<std::uint8_t>(v.finding)); w.flag(v.present); w.flag(v.canonical);
    w.flag(v.durable); w.flag(v.query_only); w.flag(v.model_only);
    w.flag(v.terminal_no_effect_proved); w.flag(v.external_linearizable_read_proved);
}
void fill_commit(const JournalCommit& v, auto& w) noexcept {
    w.digest(v.request_digest); w.digest(v.response_digest); w.digest(v.appraisal_carrier_digest);
    w.digest(v.query_observation_digest); w.digest(v.predecessor_head); w.digest(v.successor_head);
    w.digest(v.operation_id); w.digest(v.journal_namespace_digest); w.digest(v.terminal_payload_digest);
    w.digest(v.compare_append_policy_digest); w.u64(v.predecessor_generation);
    w.u64(v.successor_generation); w.u64(v.commit_revision); w.u32(v.schema);
    w.u8(static_cast<std::uint8_t>(v.outcome)); w.flag(v.present); w.flag(v.canonical);
    w.flag(v.durable); w.flag(v.atomic_compare_append); w.flag(v.model_only);
}
void fill_terminal(const TerminalReceipt& v, auto& w) noexcept {
    w.digest(v.commit_digest); w.digest(v.request_digest); w.digest(v.response_digest);
    w.digest(v.predecessor_head); w.digest(v.successor_head); w.digest(v.operation_id);
    w.digest(v.terminal_payload_digest); w.digest(v.receipt_policy_digest);
    w.u64(v.commit_revision); w.u64(v.terminal_at); w.u32(v.schema);
    w.u8(static_cast<std::uint8_t>(v.outcome)); w.flag(v.present); w.flag(v.canonical);
    w.flag(v.durable); w.flag(v.exact_retry_equivalence);
}
void fill_reopen(const ReopenReceipt& v, auto& w) noexcept {
    w.digest(v.terminal_receipt_digest); w.digest(v.commit_digest); w.digest(v.request_digest);
    w.digest(v.response_digest); w.digest(v.reopener_implementation_digest); w.digest(v.reopener_role_digest);
    w.digest(v.reopen_policy_digest); w.u64(v.reopened_at); w.u32(v.schema);
    w.flag(v.present); w.flag(v.canonical); w.flag(v.durable); w.flag(v.exact_receipt_reopened);
    w.flag(v.separate_role_label); w.flag(v.administrative_independence_proved);
}

[[nodiscard]] Digest concat_digest(const std::string_view domain, const Digest& a, const Digest& b) noexcept {
    std::array<std::uint8_t, 64U> bytes{};
    std::copy(a.begin(), a.end(), bytes.begin());
    std::copy(b.begin(), b.end(), bytes.begin() + 32);
    return sha256_domain(domain, bytes.data(), bytes.size());
}

[[nodiscard]] bool parent_valid(const ParentBinding& v) noexcept {
    return v.present && v.canonical && v.parent_aperture_pass
        && !v.parent_external_response_present && !v.parent_authority_granted
        && v.schema == schema_version
        && v.parent_output_set_digest == exact_digest(SLOPOS_OURC_PARENT_OUTPUT_SET_SHA256_HEX)
        && v.parent_composition_receipt_digest == exact_digest(SLOPOS_OURC_PARENT_COMPOSITION_RECEIPT_SHA256_HEX)
        && v.response_digest == exact_digest(SLOPOS_OURC_PARENT_RESPONSE_SHA256_HEX)
        && v.accepting_configuration_digest == exact_digest(SLOPOS_OURC_PARENT_ACCEPTING_CONFIGURATION_SHA256_HEX)
        && v.appraisal_witness_digest == exact_digest(SLOPOS_OURC_PARENT_APPRAISAL_WITNESS_SHA256_HEX)
        && v.consumption_deficit_digest == exact_digest(SLOPOS_OURC_PARENT_CONSUMPTION_DEFICIT_SHA256_HEX)
        && v.parent_archive_digest == exact_digest(SLOPOS_OURC_PARENT_ARCHIVE_SHA256_HEX)
        && v.parent_archive_bytes == static_cast<std::uint64_t>(SLOPOS_OURC_PARENT_ARCHIVE_BYTES)
        && v.parent_manifest_rows == static_cast<std::uint64_t>(SLOPOS_OURC_PARENT_MANIFEST_ROWS)
        && v.binding_digest == parent_binding_identity(v);
}
[[nodiscard]] bool appraisal_valid(const AppraisalCarrier& v, const ParentBinding& p) noexcept {
    return v.present && v.canonical && v.appraisal_accepted && v.laboratory_carrier
        && !v.external_currentness_proved && v.schema == schema_version
        && v.parent_binding_digest == p.binding_digest && v.response_digest == p.response_digest
        && v.accepting_configuration_digest == p.accepting_configuration_digest
        && v.appraisal_witness_digest == p.appraisal_witness_digest
        && nonzero(v.owner_root_digest) && nonzero(v.appraisal_policy_digest) && nonzero(v.trusted_time_source_digest)
        && v.owner_root_version == 41U && v.appraisal_time == 1200U
        && v.consume_not_after > v.appraisal_time && v.consume_not_after <= 2000U
        && v.carrier_digest == appraisal_carrier_identity(v);
}
[[nodiscard]] bool request_valid(const ConsumeRequest& v, const ParentBinding& p, const AppraisalCarrier& a) noexcept {
    return v.present && v.canonical && v.fixed_payload && v.blind_retry_forbidden
        && v.schema == schema_version && v.parent_binding_digest == p.binding_digest
        && v.response_digest == p.response_digest && v.appraisal_carrier_digest == a.carrier_digest
        && nonzero(v.expected_predecessor_head) && nonzero(v.operation_id)
        && nonzero(v.journal_namespace_digest) && nonzero(v.request_payload_digest)
        && v.consumption_policy_digest == exact_digest(SLOPOS_OURC_CONSUMPTION_POLICY_SHA256_HEX)
        && v.expected_generation == 0U && v.requested_at >= a.appraisal_time
        && v.requested_at <= a.consume_not_after && v.request_digest == consume_request_identity(v);
}
[[nodiscard]] bool invocation_valid(const PendingInvocation& v, const ConsumeRequest& r) noexcept {
    return v.present && v.canonical && !v.response_returned && v.query_only_after_loss
        && v.schema == schema_version && v.request_digest == r.request_digest
        && v.operation_id == r.operation_id && v.expected_predecessor_head == r.expected_predecessor_head
        && v.journal_namespace_digest == r.journal_namespace_digest
        && nonzero(v.submission_channel_digest)
        && v.query_policy_digest == exact_digest(SLOPOS_OURC_QUERY_POLICY_SHA256_HEX)
        && v.submitted_at >= r.requested_at && v.invocation_digest == invocation_identity(v);
}
[[nodiscard]] bool query_valid(const QueryObservation& v, const PendingInvocation& i, const ConsumeRequest& r, const AppraisalCarrier& a) noexcept {
    const auto finding = static_cast<std::uint8_t>(v.finding);
    return v.present && v.canonical && v.durable && v.query_only && v.model_only
        && !v.terminal_no_effect_proved && !v.external_linearizable_read_proved
        && v.schema == schema_version && finding <= static_cast<std::uint8_t>(QueryFinding::unavailable)
        && v.finding == QueryFinding::exact_absence
        && v.invocation_digest == i.invocation_digest && v.request_digest == r.request_digest
        && v.operation_id == r.operation_id && v.expected_predecessor_head == r.expected_predecessor_head
        && v.observed_head == r.expected_predecessor_head
        && v.journal_namespace_digest == r.journal_namespace_digest
        && v.query_policy_digest == i.query_policy_digest
        && v.query_role_digest == exact_digest(SLOPOS_OURC_QUERY_OBSERVER_ROLE_SHA256_HEX)
        && v.observed_generation == r.expected_generation && v.query_revision == 1U
        && v.queried_at >= i.submitted_at && v.queried_at <= a.consume_not_after
        && v.observation_digest == query_observation_identity(v);
}
[[nodiscard]] bool commit_valid(const JournalCommit& v, const ConsumeRequest& r, const AppraisalCarrier& a, const QueryObservation& q) noexcept {
    const Digest expected_successor = concat_digest("slopos.ourc.successor-head.v2", r.expected_predecessor_head, r.request_digest);
    const Digest expected_payload = sha256_domain("slopos.ourc.terminal-payload.v1", r.request_payload_digest.data(), r.request_payload_digest.size());
    return v.present && v.canonical && v.durable && v.atomic_compare_append && v.model_only
        && v.schema == schema_version && v.outcome == Outcome::applied
        && v.request_digest == r.request_digest && v.response_digest == r.response_digest
        && v.appraisal_carrier_digest == a.carrier_digest
        && q.finding == QueryFinding::exact_absence
        && q.observed_head == r.expected_predecessor_head
        && q.observed_generation == r.expected_generation
        && v.query_observation_digest == q.observation_digest
        && v.predecessor_head == q.observed_head
        && v.successor_head == expected_successor && v.operation_id == r.operation_id
        && v.journal_namespace_digest == r.journal_namespace_digest
        && v.terminal_payload_digest == expected_payload
        && v.compare_append_policy_digest == exact_digest(SLOPOS_OURC_CONSUMPTION_POLICY_SHA256_HEX)
        && v.predecessor_generation == r.expected_generation && v.successor_generation == r.expected_generation + 1U
        && v.commit_revision == q.query_revision + 1U && v.commit_digest == journal_commit_identity(v);
}
[[nodiscard]] bool terminal_valid(const TerminalReceipt& v, const JournalCommit& c, const ConsumeRequest& r) noexcept {
    return v.present && v.canonical && v.durable && v.exact_retry_equivalence
        && v.schema == schema_version && v.outcome == Outcome::applied
        && v.commit_digest == c.commit_digest && v.request_digest == r.request_digest
        && v.response_digest == r.response_digest && v.predecessor_head == c.predecessor_head
        && v.successor_head == c.successor_head && v.operation_id == r.operation_id
        && v.terminal_payload_digest == c.terminal_payload_digest
        && v.receipt_policy_digest == exact_digest(SLOPOS_OURC_CONSUMPTION_POLICY_SHA256_HEX)
        && v.commit_revision == c.commit_revision && v.terminal_at >= r.requested_at
        && v.receipt_digest == terminal_receipt_identity(v);
}
[[nodiscard]] bool reopen_valid(const ReopenReceipt& v, const TerminalReceipt& t, const JournalCommit& c, const ConsumeRequest& r) noexcept {
    return v.present && v.canonical && v.durable && v.exact_receipt_reopened && v.separate_role_label
        && !v.administrative_independence_proved && v.schema == schema_version
        && v.terminal_receipt_digest == t.receipt_digest && v.commit_digest == c.commit_digest
        && v.request_digest == r.request_digest && v.response_digest == r.response_digest
        && v.reopener_implementation_digest == exact_digest(SLOPOS_OURC_REOPENER_IMPLEMENTATION_SHA256_HEX)
        && nonzero(v.reopener_role_digest)
        && v.reopen_policy_digest == exact_digest(SLOPOS_OURC_REOPEN_POLICY_SHA256_HEX)
        && v.reopened_at >= t.terminal_at && v.receipt_digest == reopen_receipt_identity(v);
}

[[nodiscard]] bool cuts_valid(const Trace& trace) noexcept {
    for (std::size_t i = 0U; i < cut_count; ++i) {
        Cut expected{};
        if (trace.parent.present) expected.parent_binding_digest = trace.parent.binding_digest;
        if (i >= 1U && trace.appraisal.present) expected.appraisal_carrier_digest = trace.appraisal.carrier_digest;
        if (i >= 2U && trace.request.present) expected.request_digest = trace.request.request_digest;
        if (i >= 3U && trace.invocation.present) expected.invocation_digest = trace.invocation.invocation_digest;
        if (i >= 4U && trace.query.present) expected.query_observation_digest = trace.query.observation_digest;
        if (i >= 5U && trace.commit.present) expected.commit_digest = trace.commit.commit_digest;
        if (i >= 6U && trace.terminal.present) expected.terminal_receipt_digest = trace.terminal.receipt_digest;
        if (i >= 7U && trace.reopen.present) expected.reopen_receipt_digest = trace.reopen.receipt_digest;
        if (trace.cuts[i] != expected) return false;
    }
    return true;
}


[[nodiscard]] bool transition_plan_valid(const Trace& trace) noexcept {
    return parent_valid(trace.parent)
        && appraisal_valid(trace.appraisal, trace.parent)
        && request_valid(trace.request, trace.parent, trace.appraisal)
        && invocation_valid(trace.invocation, trace.request)
        && query_valid(trace.query, trace.invocation, trace.request, trace.appraisal)
        && commit_valid(trace.commit, trace.request, trace.appraisal, trace.query)
        && terminal_valid(trace.terminal, trace.commit, trace.request);
}

[[nodiscard]] Report rejected(const Code code, const Report& partial) noexcept {
    Report report = partial;
    report.code = code;
    report.accepted = false;
    return report;
}

}  // namespace

Digest sha256_domain(const std::string_view domain, const std::uint8_t* data, const std::size_t size) noexcept {
    Digest output{};
    EVP_MD_CTX* context = EVP_MD_CTX_new();
    if (context == nullptr) return {};
    unsigned int digest_size = 0U;
    const std::uint8_t separator = 0U;
    const bool okay = EVP_DigestInit_ex(context, EVP_sha256(), nullptr) == 1
        && EVP_DigestUpdate(context, domain.data(), domain.size()) == 1
        && EVP_DigestUpdate(context, &separator, 1U) == 1
        && (size == 0U || EVP_DigestUpdate(context, data, size) == 1)
        && EVP_DigestFinal_ex(context, output.data(), &digest_size) == 1
        && digest_size == output.size();
    EVP_MD_CTX_free(context);
    return okay ? output : Digest{};
}

Digest text_digest(const std::string_view text) noexcept {
    return sha256_domain("slopos.ourc.text.v1", reinterpret_cast<const std::uint8_t*>(text.data()), text.size());
}

Digest parent_binding_identity(const ParentBinding& v) noexcept { return identity_from<parent_binding_bytes>("slopos.ourc.parent-binding.v1", [&](auto& w){ fill_parent(v,w); }); }
Digest appraisal_carrier_identity(const AppraisalCarrier& v) noexcept { return identity_from<appraisal_carrier_bytes>("slopos.ourc.appraisal-carrier.v1", [&](auto& w){ fill_appraisal(v,w); }); }
Digest consume_request_identity(const ConsumeRequest& v) noexcept { return identity_from<consume_request_bytes>("slopos.ourc.consume-request.v1", [&](auto& w){ fill_request(v,w); }); }
Digest invocation_identity(const PendingInvocation& v) noexcept { return identity_from<invocation_bytes>("slopos.ourc.invocation.v1", [&](auto& w){ fill_invocation(v,w); }); }
Digest query_observation_identity(const QueryObservation& v) noexcept { return identity_from<query_observation_bytes>("slopos.ourc.query-observation.v1", [&](auto& w){ fill_query(v,w); }); }
Digest journal_commit_identity(const JournalCommit& v) noexcept { return identity_from<journal_commit_bytes>("slopos.ourc.journal-commit.v1", [&](auto& w){ fill_commit(v,w); }); }
Digest terminal_receipt_identity(const TerminalReceipt& v) noexcept { return identity_from<terminal_receipt_bytes>("slopos.ourc.terminal-receipt.v1", [&](auto& w){ fill_terminal(v,w); }); }
Digest reopen_receipt_identity(const ReopenReceipt& v) noexcept { return identity_from<reopen_receipt_bytes>("slopos.ourc.reopen-receipt.v1", [&](auto& w){ fill_reopen(v,w); }); }

bool encode_parent_binding(const ParentBinding& v, EncodedParentBinding& output) noexcept { return encode_with_identity(v.binding_digest,"slopos.ourc.parent-binding.v1",[&](auto& w){fill_parent(v,w);},output); }
bool encode_appraisal_carrier(const AppraisalCarrier& v, EncodedAppraisalCarrier& output) noexcept { return encode_with_identity(v.carrier_digest,"slopos.ourc.appraisal-carrier.v1",[&](auto& w){fill_appraisal(v,w);},output); }
bool encode_consume_request(const ConsumeRequest& v, EncodedConsumeRequest& output) noexcept { return encode_with_identity(v.request_digest,"slopos.ourc.consume-request.v1",[&](auto& w){fill_request(v,w);},output); }
bool encode_invocation(const PendingInvocation& v, EncodedInvocation& output) noexcept { return encode_with_identity(v.invocation_digest,"slopos.ourc.invocation.v1",[&](auto& w){fill_invocation(v,w);},output); }
bool encode_query_observation(const QueryObservation& v, EncodedQueryObservation& output) noexcept { return encode_with_identity(v.observation_digest,"slopos.ourc.query-observation.v1",[&](auto& w){fill_query(v,w);},output); }
bool encode_journal_commit(const JournalCommit& v, EncodedJournalCommit& output) noexcept { return encode_with_identity(v.commit_digest,"slopos.ourc.journal-commit.v1",[&](auto& w){fill_commit(v,w);},output); }
bool encode_terminal_receipt(const TerminalReceipt& v, EncodedTerminalReceipt& output) noexcept { return encode_with_identity(v.receipt_digest,"slopos.ourc.terminal-receipt.v1",[&](auto& w){fill_terminal(v,w);},output); }
bool encode_reopen_receipt(const ReopenReceipt& v, EncodedReopenReceipt& output) noexcept { return encode_with_identity(v.receipt_digest,"slopos.ourc.reopen-receipt.v1",[&](auto& w){fill_reopen(v,w);},output); }

Report evaluate_candidate(const Trace& trace) noexcept {
    Report report{};
    if (!parent_valid(trace.parent)) return rejected(Code::parent_binding_invalid, report);
    report.parent_valid = true;
    if (!trace.appraisal.present) {
        if (trace.request.present || trace.invocation.present || trace.query.present || trace.commit.present || trace.terminal.present || trace.reopen.present) return rejected(Code::appraisal_without_parent, report);
        if (!cuts_valid(trace)) return rejected(Code::cut_order_invalid, report);
        report.code = Code::accepted_parent_bound; report.accepted = true; report.cuts_ordered = true; return report;
    }
    if (!appraisal_valid(trace.appraisal, trace.parent)) return rejected(Code::appraisal_invalid, report);
    report.appraisal_valid = true;
    if (trace.consume_under_successor_root_without_fresh_appraisal) return rejected(Code::stale_root_consumption_forbidden, report);
    if (!trace.request.present) {
        if (trace.invocation.present || trace.query.present || trace.commit.present || trace.terminal.present || trace.reopen.present) return rejected(Code::request_without_appraisal, report);
        if (!cuts_valid(trace)) return rejected(Code::cut_order_invalid, report);
        report.code = Code::accepted_appraisal_durable; report.accepted = true; report.cuts_ordered = true; return report;
    }
    if (!request_valid(trace.request, trace.parent, trace.appraisal)) {
        if (trace.request.requested_at < trace.appraisal.appraisal_time || trace.request.requested_at > trace.appraisal.consume_not_after) return rejected(Code::request_time_invalid, report);
        return rejected(Code::request_invalid, report);
    }
    report.request_valid = true;
    if (!trace.invocation.present) {
        if (trace.query.present || trace.commit.present || trace.terminal.present || trace.reopen.present) return rejected(Code::invocation_without_request, report);
        if (!cuts_valid(trace)) return rejected(Code::cut_order_invalid, report);
        report.code = Code::accepted_request_durable; report.accepted = true; report.cuts_ordered = true; return report;
    }
    if (!invocation_valid(trace.invocation, trace.request)) return rejected(Code::invocation_invalid, report);
    report.invocation_valid = true;
    if (!trace.query.present) {
        if (trace.commit.present || trace.terminal.present || trace.reopen.present) return rejected(Code::commit_without_query_observation, report);
        if (!cuts_valid(trace)) return rejected(Code::cut_order_invalid, report);
        report.code = Code::accepted_pending_query_only; report.accepted = true; report.cuts_ordered = true;
        report.query_only_required = true; return report;
    }
    if (!query_valid(trace.query, trace.invocation, trace.request, trace.appraisal)) return rejected(Code::query_invalid, report);
    report.query_valid = true;
    report.query_only_required = true;
    if (trace.declare_terminal_no_effect_from_absence) return rejected(Code::absent_query_promoted_to_no_effect, report);
    if (!trace.commit.present) {
        if (trace.terminal.present || trace.reopen.present) return rejected(Code::receipt_without_commit, report);
        if (!cuts_valid(trace)) return rejected(Code::cut_order_invalid, report);
        report.code = Code::accepted_absent_query_durable; report.accepted = true; report.cuts_ordered = true;
        return report;
    }
    if (!commit_valid(trace.commit, trace.request, trace.appraisal, trace.query)) {
        if (trace.commit.predecessor_head != trace.request.expected_predecessor_head || trace.commit.predecessor_generation != trace.request.expected_generation) return rejected(Code::commit_compare_mismatch, report);
        return rejected(Code::commit_invalid, report);
    }
    report.commit_valid = true;
    if (!trace.terminal.present) {
        if (trace.reopen.present) return rejected(Code::receipt_without_commit, report);
        if (!cuts_valid(trace)) return rejected(Code::cut_order_invalid, report);
        report.code = Code::accepted_commit_durable; report.accepted = true; report.cuts_ordered = true;
        report.exact_duplicate_excluded = true; report.one_use_within_coherent_history = true; return report;
    }
    if (!terminal_valid(trace.terminal, trace.commit, trace.request)) return rejected(Code::receipt_invalid, report);
    report.terminal_valid = true;
    if (!trace.reopen.present) {
        if (!cuts_valid(trace)) return rejected(Code::cut_order_invalid, report);
        report.code = Code::accepted_terminal_receipt_durable; report.accepted = true; report.cuts_ordered = true;
        report.exact_duplicate_excluded = true; report.one_use_within_coherent_history = true; return report;
    }
    if (!reopen_valid(trace.reopen, trace.terminal, trace.commit, trace.request)) return rejected(Code::reopen_invalid, report);
    report.reopen_valid = true;
    if (trace.promote_model_to_external_operation) return rejected(Code::hosted_operation_promotion_forbidden, report);
    if (trace.promote_receipt_to_owner_admission) return rejected(Code::owner_admission_promotion_forbidden, report);
    if (trace.grant_authority) return rejected(Code::authority_promotion_forbidden, report);
    if (!cuts_valid(trace)) return rejected(Code::cut_order_invalid, report);
    report.code = Code::accepted_reopen_durable;
    report.accepted = true;
    report.cuts_ordered = true;
    report.exact_duplicate_excluded = true;
    report.exact_terminal_reopenable = true;
    report.one_use_within_coherent_history = true;
    return report;
}

Attempt attempt_candidate(const LedgerState& state, const Trace& plan, const bool current_appraisal) noexcept {
    Attempt result{};
    if (!transition_plan_valid(plan)) { result.outcome = Outcome::fail_stop; return result; }
    result.plan_valid = true;
    const ConsumeRequest& request = plan.request;
    const bool empty_spent_shape = !state.response_spent
        && !nonzero(state.spent_response) && !nonzero(state.applied_request)
        && !nonzero(state.applied_commit) && !nonzero(state.spent_successor_head)
        && !nonzero(state.terminal_receipt) && state.spent_successor_generation == 0U
        && state.spent_commit_revision == 0U;
    const bool populated_spent_shape = state.response_spent
        && nonzero(state.spent_response) && nonzero(state.applied_request)
        && nonzero(state.applied_commit) && nonzero(state.spent_successor_head)
        && nonzero(state.terminal_receipt) && state.spent_successor_generation > 0U
        && state.spent_commit_revision > 0U
        && state.generation == state.spent_successor_generation
        && state.head == state.spent_successor_head;
    if (!empty_spent_shape && !populated_spent_shape) {
        result.outcome = Outcome::fail_stop;
        return result;
    }
    if (state.response_spent && state.spent_response == request.response_digest) {
        result.terminal_fact_precedes_currentness = true;
        if (state.applied_request != request.request_digest) {
            result.outcome = Outcome::response_spent;
            return result;
        }
        const bool exact_state = state.applied_commit == plan.commit.commit_digest
            && state.spent_successor_head == plan.commit.successor_head
            && state.terminal_receipt == plan.terminal.receipt_digest
            && state.spent_successor_generation == plan.commit.successor_generation
            && state.spent_commit_revision == plan.commit.commit_revision;
        if (!exact_state) {
            result.outcome = Outcome::fail_stop;
            return result;
        }
        result.outcome = Outcome::already_applied;
        result.commit_digest = state.applied_commit;
        result.successor_head = state.spent_successor_head;
        result.terminal_receipt = state.terminal_receipt;
        result.successor_generation = state.spent_successor_generation;
        result.commit_revision = state.spent_commit_revision;
        result.retry_equivalent = true;
        result.exact_receipt_match = true;
        result.exact_state_match = true;
        return result;
    }
    if (!current_appraisal) { result.outcome = Outcome::stale_currentness; return result; }
    if (state.head != request.expected_predecessor_head || state.generation != request.expected_generation) {
        result.outcome = Outcome::predecessor_conflict;
        return result;
    }
    result.outcome = Outcome::applied;
    result.commit_digest = plan.commit.commit_digest;
    result.successor_head = plan.commit.successor_head;
    result.terminal_receipt = plan.terminal.receipt_digest;
    result.successor_generation = plan.commit.successor_generation;
    result.commit_revision = plan.commit.commit_revision;
    result.state_changed = true;
    return result;
}

std::string_view code_name(const Code value) noexcept {
    switch (value) {
        case Code::accepted_parent_bound: return "accepted_parent_bound";
        case Code::accepted_appraisal_durable: return "accepted_appraisal_durable";
        case Code::accepted_request_durable: return "accepted_request_durable";
        case Code::accepted_pending_query_only: return "accepted_pending_query_only";
        case Code::accepted_absent_query_durable: return "accepted_absent_query_durable";
        case Code::accepted_commit_durable: return "accepted_commit_durable";
        case Code::accepted_terminal_receipt_durable: return "accepted_terminal_receipt_durable";
        case Code::accepted_reopen_durable: return "accepted_reopen_durable";
        case Code::parent_binding_invalid: return "parent_binding_invalid";
        case Code::appraisal_without_parent: return "appraisal_without_parent";
        case Code::appraisal_invalid: return "appraisal_invalid";
        case Code::appraisal_not_current: return "appraisal_not_current";
        case Code::request_without_appraisal: return "request_without_appraisal";
        case Code::request_invalid: return "request_invalid";
        case Code::request_binding_mismatch: return "request_binding_mismatch";
        case Code::request_time_invalid: return "request_time_invalid";
        case Code::invocation_without_request: return "invocation_without_request";
        case Code::invocation_invalid: return "invocation_invalid";
        case Code::query_without_invocation: return "query_without_invocation";
        case Code::query_invalid: return "query_invalid";
        case Code::commit_without_query_observation: return "commit_without_query_observation";
        case Code::commit_without_invocation: return "commit_without_invocation";
        case Code::commit_invalid: return "commit_invalid";
        case Code::commit_compare_mismatch: return "commit_compare_mismatch";
        case Code::receipt_without_commit: return "receipt_without_commit";
        case Code::receipt_invalid: return "receipt_invalid";
        case Code::receipt_binding_mismatch: return "receipt_binding_mismatch";
        case Code::reopen_without_receipt: return "reopen_without_receipt";
        case Code::reopen_invalid: return "reopen_invalid";
        case Code::reopen_binding_mismatch: return "reopen_binding_mismatch";
        case Code::absent_query_promoted_to_no_effect: return "absent_query_promoted_to_no_effect";
        case Code::stale_root_consumption_forbidden: return "stale_root_consumption_forbidden";
        case Code::hosted_operation_promotion_forbidden: return "hosted_operation_promotion_forbidden";
        case Code::owner_admission_promotion_forbidden: return "owner_admission_promotion_forbidden";
        case Code::authority_promotion_forbidden: return "authority_promotion_forbidden";
        case Code::cut_order_invalid: return "cut_order_invalid";
    }
    return "unknown";
}

std::string_view query_finding_name(const QueryFinding value) noexcept {
    switch (value) {
        case QueryFinding::none: return "none";
        case QueryFinding::exact_absence: return "exact_absence";
        case QueryFinding::exact_commit: return "exact_commit";
        case QueryFinding::conflicting_record: return "conflicting_record";
        case QueryFinding::unavailable: return "unavailable";
    }
    return "unknown";
}

std::string_view outcome_name(const Outcome value) noexcept {
    switch (value) {
        case Outcome::none: return "none";
        case Outcome::applied: return "applied";
        case Outcome::already_applied: return "already_applied";
        case Outcome::predecessor_conflict: return "predecessor_conflict";
        case Outcome::response_spent: return "response_spent";
        case Outcome::stale_currentness: return "stale_currentness";
        case Outcome::fail_stop: return "fail_stop";
    }
    return "unknown";
}

std::string_view cut_name(const std::size_t index) noexcept {
    constexpr std::array<std::string_view, cut_count> names{{"parent","appraisal","request","pending","absent_query","commit","terminal","reopen"}};
    return index < names.size() ? names[index] : std::string_view{"invalid"};
}

}  // namespace slopos::e0::detached_response_aperture::one_use_response_consumption
