#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import struct
from dataclasses import dataclass
from pathlib import Path

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

ZERO = b"\0" * 32
MANIFEST_BYTES = 384
STATEMENT_BYTES = 512
ENVELOPE_BYTES = 1024
RECORD_BYTES = 448
MANIFEST_MAGIC = b"SLOPOM01"
STATEMENT_MAGIC = b"SLOPAS01"
ENVELOPE_MAGIC = b"SLOPAE01"
RECORD_MAGIC = b"SLOPTX01"


def h(label: bytes, payload: bytes) -> bytes:
    return hashlib.sha256(label + b"\0" + payload).digest()


def key_id(public_key: bytes) -> bytes:
    return h(b"SlopOS/admission/key-id/v1", public_key)


def manifest_head(raw: bytes) -> bytes:
    return h(b"SlopOS/admission/manifest-head/v1", raw)


def statement_head(raw: bytes) -> bytes:
    return h(b"SlopOS/admission/statement-head/v1", raw)


def profile_digest() -> bytes:
    text = (
        b"SlopOS Epoch-Zero signed-admission evidence profile v1; fixed Ed25519 threshold; "
        b"exact R1-R6 binding; no owner constitution, currentness, global spend, authority, or epoch exit"
    )
    return h(b"SlopOS/admission/profile/v1", text)


@dataclass(frozen=True)
class Manifest:
    raw: bytes
    project_id: bytes
    constitution_id: bytes
    predecessor: bytes
    version: int
    threshold: int
    keys: tuple[tuple[bytes, bytes], ...]


@dataclass(frozen=True)
class Statement:
    raw: bytes
    purpose: int
    terminal_scope: int
    digests: tuple[bytes, ...]
    generation_from: int
    generation_to: int
    nonce: int
    not_before: int
    expires_at: int
    ceremony_nonce: int


@dataclass(frozen=True)
class Envelope:
    raw: bytes
    statement: bytes
    signatures: tuple[tuple[bytes, bytes], ...]


@dataclass(frozen=True)
class Record:
    raw: bytes
    kind: int
    flags: int
    transaction_id: bytes
    predecessor: bytes
    subject: bytes
    policy: bytes
    evidence: bytes
    appraisal: bytes
    permit: bytes
    spend: bytes
    result: bytes
    currentness: bytes
    actor: bytes
    generation_from: int
    generation_to: int
    nonce: int
    decision: int
    terminal: int
    role: int


@dataclass(frozen=True)
class Report:
    code: str
    valid: bool = False
    verified_signatures: int = 0
    signature_evidence_valid: bool = False
    threshold_met: bool = False
    dossier_bound: bool = False
    time_window_match: bool = False


def parse_manifest(raw: bytes) -> Manifest | None:
    if len(raw) != MANIFEST_BYTES or raw[:8] != MANIFEST_MAGIC:
        return None
    if (
        struct.unpack_from(">H", raw, 8)[0] != 1
        or struct.unpack_from(">H", raw, 10)[0] != 1
        or struct.unpack_from(">I", raw, 12)[0] != MANIFEST_BYTES
        or raw[16] != 1
        or raw[19] != 0
        or any(raw[20:32])
        or any(raw[136:160])
        or h(b"SlopOS/admission/manifest-integrity/v1", raw[:352]) != raw[352:384]
    ):
        return None
    threshold, count = raw[17], raw[18]
    project, constitution, predecessor = raw[32:64], raw[64:96], raw[96:128]
    version = struct.unpack_from(">Q", raw, 128)[0]
    if project == ZERO or constitution == ZERO or version == 0 or not (1 <= threshold <= count <= 3):
        return None
    keys: list[tuple[bytes, bytes]] = []
    for index in range(3):
        base = 160 + index * 64
        kid, public = raw[base : base + 32], raw[base + 32 : base + 64]
        if index < count:
            if kid == ZERO or public == ZERO or key_id(public) != kid:
                return None
            if keys and not keys[-1][0] < kid:
                return None
            keys.append((kid, public))
        elif kid != ZERO or public != ZERO:
            return None
    return Manifest(raw, project, constitution, predecessor, version, threshold, tuple(keys))


def parse_statement(raw: bytes) -> Statement | None:
    if len(raw) != STATEMENT_BYTES or raw[:8] != STATEMENT_MAGIC:
        return None
    if (
        struct.unpack_from(">H", raw, 8)[0] != 1
        or struct.unpack_from(">H", raw, 10)[0] != 2
        or struct.unpack_from(">I", raw, 12)[0] != STATEMENT_BYTES
        or raw[18] != 1
        or any(raw[19:32])
        or any(raw[464:480])
        or h(b"SlopOS/admission/statement-integrity/v1", raw[:480]) != raw[480:512]
    ):
        return None
    purpose, scope = raw[16], raw[17]
    digests = tuple(raw[offset : offset + 32] for offset in range(32, 416, 32))
    generation_from, generation_to, nonce, not_before, expires_at, ceremony_nonce = struct.unpack_from(
        ">QQQQQQ", raw, 416
    )
    if (
        purpose != 1
        or scope not in (1, 2, 3, 4)
        or ZERO in digests
        or generation_from in (0, 2**64 - 1)
        or nonce == 0
        or ceremony_nonce == 0
        or expires_at <= not_before
    ):
        return None
    expected_to = {1: generation_from + 1, 2: generation_from, 3: 0, 4: generation_from}[scope]
    if generation_to != expected_to:
        return None
    return Statement(
        raw,
        purpose,
        scope,
        digests,
        generation_from,
        generation_to,
        nonce,
        not_before,
        expires_at,
        ceremony_nonce,
    )


def parse_envelope(raw: bytes) -> Envelope | None:
    if len(raw) != ENVELOPE_BYTES or raw[:8] != ENVELOPE_MAGIC:
        return None
    if (
        struct.unpack_from(">H", raw, 8)[0] != 1
        or struct.unpack_from(">H", raw, 10)[0] != 3
        or struct.unpack_from(">I", raw, 12)[0] != ENVELOPE_BYTES
        or raw[17] != 1
        or any(raw[18:32])
        or any(raw[832:992])
        or h(b"SlopOS/admission/envelope-integrity/v1", raw[:992]) != raw[992:1024]
    ):
        return None
    count = raw[16]
    if count not in (1, 2, 3):
        return None
    signatures: list[tuple[bytes, bytes]] = []
    for index in range(3):
        base = 544 + index * 96
        kid, signature = raw[base : base + 32], raw[base + 32 : base + 96]
        if index < count:
            if kid == ZERO or signature == b"\0" * 64:
                return None
            signatures.append((kid, signature))
        elif kid != ZERO or signature != b"\0" * 64:
            return None
    return Envelope(raw, raw[32:544], tuple(signatures))


TX_INTEGRITY = b"SlopOS/transaction-dossier/v1/integrity\0"
TX_HEAD = b"SlopOS/transaction-dossier/v1/head\0"
TX_ID = b"SlopOS/transaction-dossier/v1/transaction\0"


def tx_digest(domain: bytes, payload: bytes) -> bytes:
    return hashlib.sha256(domain + payload).digest()


def record_head(raw: bytes) -> bytes:
    return tx_digest(TX_HEAD, raw)


def parse_record(raw: bytes) -> Record | None:
    if len(raw) != RECORD_BYTES or raw[:8] != RECORD_MAGIC:
        return None
    if (
        struct.unpack_from(">H", raw, 8)[0] != 1
        or struct.unpack_from(">I", raw, 12)[0] != RECORD_BYTES
        or raw[11] != 0
        or any(raw[20:32])
        or any(raw[411:416])
        or tx_digest(TX_INTEGRITY, raw[:416]) != raw[416:448]
    ):
        return None
    kind, decision, terminal, role = raw[10], raw[408], raw[409], raw[410]
    if kind not in range(1, 7) or decision not in range(4) or terminal not in range(5) or role not in range(1, 7):
        return None
    fields = [raw[offset : offset + 32] for offset in range(32, 384, 32)]
    return Record(
        raw,
        kind,
        struct.unpack_from(">I", raw, 16)[0],
        *fields,
        struct.unpack_from(">Q", raw, 384)[0],
        struct.unpack_from(">Q", raw, 392)[0],
        struct.unpack_from(">Q", raw, 400)[0],
        decision,
        terminal,
        role,
    )


def validate_dossier(raw_records: list[bytes]) -> tuple[bool, list[Record]]:
    if len(raw_records) != 6:
        return False, []
    records: list[Record] = []
    for index, raw in enumerate(raw_records):
        item = parse_record(raw)
        if item is None or item.kind != index + 1 or item.role != index + 1:
            return False, []
        if (index == 0 and item.predecessor != ZERO) or (
            index > 0 and item.predecessor != record_head(raw_records[index - 1])
        ):
            return False, []
        records.append(item)
    first = records[0]
    expected_tx = tx_digest(
        TX_ID,
        first.subject + first.policy + struct.pack(">QQ", first.generation_from, first.nonce),
    )
    if (
        ZERO in (first.transaction_id, first.subject, first.policy, first.actor)
        or first.generation_from in (0, 2**64 - 1)
        or first.nonce == 0
        or first.generation_to != first.generation_from + 1
        or first.transaction_id != expected_tx
    ):
        return False, []
    if any(
        item.transaction_id != first.transaction_id
        or item.subject != first.subject
        or item.policy != first.policy
        or item.generation_from != first.generation_from
        or item.nonce != first.nonce
        or item.actor == ZERO
        for item in records
    ) or len({item.actor for item in records}) != 6:
        return False, []
    r1, r2, r3, r4, r5, r6 = records
    if (
        r1.flags != 0
        or r1.decision != 0
        or r1.terminal != 0
        or any(x != ZERO for x in (r1.evidence, r1.appraisal, r1.permit, r1.spend, r1.result, r1.currentness))
    ):
        return False, []
    if (
        r2.flags != 0
        or r2.decision != 0
        or r2.terminal != 0
        or r2.evidence == ZERO
        or any(x != ZERO for x in (r2.appraisal, r2.permit, r2.spend, r2.result, r2.currentness))
        or r2.generation_to != r2.generation_from + 1
    ):
        return False, []
    if (
        r3.flags != 0
        or r3.decision != 1
        or r3.terminal != 0
        or r3.evidence != r2.evidence
        or r3.appraisal == ZERO
        or any(x != ZERO for x in (r3.permit, r3.spend, r3.result, r3.currentness))
        or r3.generation_to != r3.generation_from + 1
    ):
        return False, []
    if (
        r4.flags != 1
        or r4.decision != 0
        or r4.terminal != 0
        or r4.evidence != r3.evidence
        or r4.appraisal != r3.appraisal
        or r4.permit == ZERO
        or any(x != ZERO for x in (r4.spend, r4.result, r4.currentness))
        or r4.generation_to != r4.generation_from + 1
    ):
        return False, []
    terminal = {1: (r5.generation_from + 1, 3), 2: (r5.generation_from, 3), 3: (0, 7), 4: (r5.generation_from, 3)}.get(r5.terminal)
    if (
        terminal is None
        or r5.decision != 0
        or r5.evidence != r4.evidence
        or r5.appraisal != r4.appraisal
        or r5.permit != r4.permit
        or r5.spend == ZERO
        or r5.result == ZERO
        or r5.currentness != ZERO
        or r5.generation_to != terminal[0]
        or r5.flags != terminal[1]
    ):
        return False, []
    if (
        r6.flags != (r5.flags | 8)
        or r6.decision != 0
        or r6.terminal != r5.terminal
        or r6.generation_to != r5.generation_to
        or r6.evidence != r5.evidence
        or r6.appraisal != r5.appraisal
        or r6.permit != r5.permit
        or r6.spend != r5.spend
        or r6.result != r5.result
        or r6.currentness == ZERO
    ):
        return False, []
    return True, records


def read_records(path: Path) -> list[bytes]:
    raw = path.read_bytes()
    if len(raw) % RECORD_BYTES:
        return [raw]
    return [raw[offset : offset + RECORD_BYTES] for offset in range(0, len(raw), RECORD_BYTES)]


def signing_message(statement: bytes) -> bytes:
    domain = b"SlopOS/signed-admission/v1/PAE".ljust(32, b"\0")
    return domain + struct.pack(">Q", len(statement)) + statement


def validate(manifest_raw: bytes, envelope_raw: bytes, records_raw: list[bytes], observed_time: int) -> Report:
    manifest = parse_manifest(manifest_raw)
    if manifest is None:
        return Report("invalid_manifest")
    envelope = parse_envelope(envelope_raw)
    if envelope is None:
        return Report("invalid_envelope")
    statement = parse_statement(envelope.statement)
    if statement is None:
        return Report("invalid_statement")
    (
        project,
        owner_head,
        profile,
        transaction,
        prefix,
        subject,
        policy,
        evidence,
        appraisal,
        issuer,
        endpoint,
        reopener,
    ) = statement.digests
    if project != manifest.project_id or owner_head != manifest_head(manifest.raw):
        return Report("manifest_binding_mismatch")
    if profile != profile_digest():
        return Report("profile_mismatch")
    if not (statement.not_before <= observed_time < statement.expires_at):
        return Report("time_window_mismatch")
    dossier_valid, records = validate_dossier(records_raw)
    if not dossier_valid:
        return Report("invalid_dossier", time_window_match=True)
    r1, r2, r3, r4, r5, r6 = records
    prefix_actual = h(b"SlopOS/admission/dossier-prefix/v1", b"".join(records_raw[:3]))
    scope = {1: 1, 2: 2, 3: 3, 4: 4}[r5.terminal]
    if not (
        transaction == r1.transaction_id
        and prefix == prefix_actual
        and subject == r1.subject
        and policy == r1.policy
        and evidence == r2.evidence
        and appraisal == r3.appraisal
        and issuer == r4.actor
        and endpoint == r5.actor
        and reopener == r6.actor
        and statement.generation_from == r1.generation_from
        and statement.generation_to == r5.generation_to
        and statement.nonce == r1.nonce
        and statement.terminal_scope == scope
        and r4.permit == statement_head(statement.raw)
    ):
        return Report("dossier_binding_mismatch", dossier_bound=False, time_window_match=True)
    keys = dict(manifest.keys)
    seen: set[bytes] = set()
    verified = 0
    message = signing_message(statement.raw)
    for kid, signature in envelope.signatures:
        if kid in seen:
            return Report("duplicate_signer", verified_signatures=verified, dossier_bound=True, time_window_match=True)
        seen.add(kid)
        public = keys.get(kid)
        if public is None:
            return Report("unknown_signer", verified_signatures=verified, dossier_bound=True, time_window_match=True)
        try:
            Ed25519PublicKey.from_public_bytes(public).verify(signature, message)
        except (InvalidSignature, ValueError):
            return Report("invalid_signature", verified_signatures=verified, dossier_bound=True, time_window_match=True)
        verified += 1
    if verified < manifest.threshold:
        return Report(
            "below_threshold",
            verified_signatures=verified,
            signature_evidence_valid=True,
            dossier_bound=True,
            time_window_match=True,
        )
    return Report(
        "evidence_valid",
        valid=True,
        verified_signatures=verified,
        signature_evidence_valid=True,
        threshold_met=True,
        dossier_bound=True,
        time_window_match=True,
    )


def verify(root: Path) -> dict[str, object]:
    campaign = json.loads((root / "campaign-audit.json").read_text(encoding="utf-8"))
    replay = json.loads((root / "replay-audit.json").read_text(encoding="utf-8"))
    if campaign != {
        "schema": "slopos.rev0913.signed-admission-campaign.v1",
        "status": "PASS",
        "manifest_bytes": 384,
        "statement_bytes": 512,
        "envelope_bytes": 1024,
        "dossier_record_bytes": 448,
        "cases": 43,
        "valid_evidence_cases": 5,
        "rejected_cases": 38,
        "self_constituted_valid_countermodels": 1,
        "candidate_reference_disagreements": 0,
        "real_ed25519": True,
        "threshold_profile": "2-of-3",
        "dossier_bound": True,
        "signing_api_exposed": False,
        "owner_constitution_proved": False,
        "currentness_proved": False,
        "global_one_use_proved": False,
        "epoch_exit_true_results": 0,
        "authority_true_results": 0,
    }:
        raise ValueError("campaign audit")
    if replay != {
        "schema": "slopos.rev0913.signed-admission-replay-countermodel.v1",
        "identical_envelope_copies": 2,
        "identical_dossier_copies": 2,
        "same_root_local_accepts": 2,
        "signature_evidence_valid_in_each_copy": True,
        "owner_constitution_proved": False,
        "currentness_proved": False,
        "global_one_use_proved": False,
        "authority_granted": False,
    }:
        raise ValueError("replay audit")
    with (root / "cases.tsv").open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        expected_header = [
            "case", "path", "observed_time", "expected_code", "expected_valid", "self_constituted",
            "candidate_code", "reference_code", "verified_signatures", "signature_evidence_valid",
            "threshold_met", "dossier_bound", "time_window_match", "owner_constitution_proved",
            "currentness_proved", "global_one_use_proved", "epoch_exit_proved", "authority_granted",
        ]
        if reader.fieldnames != expected_header:
            raise ValueError("cases header")
        rows = list(reader)
    if len(rows) != 43:
        raise ValueError("case count")
    valid = rejected = self_constituted_valid = disagreements = 0
    for row in rows:
        base = root / row["path"]
        report = validate(
            (base / "manifest.bin").read_bytes(),
            (base / "envelope.bin").read_bytes(),
            read_records(base / "dossier.bin"),
            int(row["observed_time"]),
        )
        expected_valid = row["expected_valid"] == "true"
        if report.code != row["expected_code"] or report.valid != expected_valid:
            raise ValueError(f"case {row['case']} report={report}")
        if row["candidate_code"] != row["reference_code"]:
            disagreements += 1
        if any(row[key] != "false" for key in (
            "owner_constitution_proved", "currentness_proved", "global_one_use_proved",
            "epoch_exit_proved", "authority_granted",
        )):
            raise ValueError(f"authority projection {row['case']}")
        valid += int(report.valid)
        rejected += int(not report.valid)
        self_constituted_valid += int(report.valid and row["self_constituted"] == "true")
    if (valid, rejected, self_constituted_valid, disagreements) != (5, 38, 1, 0):
        raise ValueError("aggregate")
    return {
        "schema": "slopos.rev0913.signed-admission-python-verification.v1",
        "status": "PASS",
        "cases": 43,
        "valid_evidence_cases": valid,
        "rejected_cases": rejected,
        "self_constituted_valid_countermodels": self_constituted_valid,
        "candidate_reference_disagreements": disagreements,
        "real_ed25519": True,
        "independent_implementation": True,
        "owner_constitution_proved": False,
        "currentness_proved": False,
        "global_one_use_proved": False,
        "epoch_exit_proved": False,
        "authority_granted": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Independent signed-admission verifier")
    parser.add_argument("root", type=Path)
    parser.add_argument("--audit-out", type=Path)
    args = parser.parse_args()
    try:
        result = verify(args.root)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"SIGNED_ADMISSION_PYTHON=FAIL detail={exc}")
        return 1
    if args.audit_out is not None:
        args.audit_out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print("SIGNED_ADMISSION_PYTHON=PASS " + json.dumps(result, sort_keys=True, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
