
#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

FIELDS = [
    "case", "terminal_kind", "exact_request", "exact_transition", "exact_incarnation",
    "exact_terminal", "exact_kind", "record_present", "record_authenticated",
    "record_durable", "record_serialized", "record_single_view",
    "record_retained_full_horizon", "record_fences_pending", "record_survives_restore",
    "record_survives_succession", "record_independent_reopen", "witness_present",
    "witness_authenticated", "witness_binds_terminal", "witness_durable",
    "witness_independent_reopen", "witness_survives_restore", "witness_survives_succession",
    "floor_present", "floor_authenticated", "floor_monotone", "floor_outside_restore",
    "floor_binds_namespace", "old_incarnation_rejected", "pending_invocations_fenced",
    "restore_preserves_floor", "succession_preserves_floor", "floor_single_view",
    "reclamation_requested", "client_acknowledged", "ttl_expired", "equivocation_observed",
    "candidate_code", "reference_code", "agreement", "accepted", "record_execution_path",
    "record_history_path", "witness_history_path", "floor_execution_path",
    "duplicate_execution_excluded", "terminal_outcome_reopenable", "terminal_continuity",
    "reclamation_safe", "fail_stopped", "client_ack_sufficient", "ttl_sufficient", "authority",
]


def fail(detail: str) -> None:
    raise SystemExit(f"TERMINAL_OUTCOME_CONTINUITY_PY=FAIL detail={detail}")


def b(row: dict[str, str], key: str) -> bool:
    value = row[key]
    if value not in {"true", "false"}:
        fail(f"boolean={key}:{value}")
    return value == "true"


def reject(code: str) -> tuple:
    return (code, False, False, False, False, False, False, False, False, False, False)


def evaluate(row: dict[str, str]) -> tuple:
    if row["case"].startswith("zero_"):
        return reject("invalid_state")
    identities = [
        ("exact_request", "request_id_mismatch"),
        ("exact_transition", "transition_digest_mismatch"),
        ("exact_incarnation", "register_incarnation_mismatch"),
        ("exact_terminal", "terminal_digest_mismatch"),
        ("exact_kind", "terminal_kind_mismatch"),
    ]
    for key, code in identities:
        if not b(row, key):
            return reject(code)

    record_dependent = [
        "record_authenticated", "record_durable", "record_serialized", "record_single_view",
        "record_retained_full_horizon", "record_fences_pending", "record_survives_restore",
        "record_survives_succession", "record_independent_reopen",
    ]
    witness_dependent = [
        "witness_authenticated", "witness_binds_terminal", "witness_durable",
        "witness_independent_reopen", "witness_survives_restore", "witness_survives_succession",
    ]
    floor_dependent = [
        "floor_authenticated", "floor_monotone", "floor_outside_restore", "floor_binds_namespace",
        "old_incarnation_rejected", "pending_invocations_fenced", "restore_preserves_floor",
        "succession_preserves_floor", "floor_single_view",
    ]
    if not b(row, "record_present") and any(b(row, key) for key in record_dependent):
        return reject("terminal_record_shape_invalid")
    if not b(row, "witness_present") and any(b(row, key) for key in witness_dependent):
        return reject("terminal_witness_shape_invalid")
    if not b(row, "floor_present") and any(b(row, key) for key in floor_dependent):
        return reject("successor_floor_shape_invalid")
    if b(row, "equivocation_observed"):
        return (
            "accepted_equivocation_fail_stop", True,
            False, False, False, False, False, False, False, False, True,
        )

    common_record = all(b(row, key) for key in [
        "record_present", "record_authenticated", "record_durable", "record_single_view",
        "record_retained_full_horizon", "record_survives_restore", "record_survives_succession",
    ])
    record_execution = common_record and b(row, "record_serialized") and b(row, "record_fences_pending")
    record_history = common_record and b(row, "record_independent_reopen")
    witness_history = all(b(row, key) for key in [
        "witness_present", "witness_authenticated", "witness_binds_terminal", "witness_durable",
        "witness_independent_reopen", "witness_survives_restore", "witness_survives_succession",
    ])
    floor_execution = all(b(row, key) for key in [
        "floor_present", "floor_authenticated", "floor_monotone", "floor_outside_restore",
        "floor_binds_namespace", "old_incarnation_rejected", "pending_invocations_fenced",
        "restore_preserves_floor", "succession_preserves_floor", "floor_single_view",
    ])
    execution = record_execution or floor_execution
    history = record_history or witness_history
    continuity = execution and history
    reclamation_safe = continuity and b(row, "reclamation_requested") and witness_history and floor_execution
    if continuity:
        if record_execution and record_history and not witness_history and not floor_execution:
            code = "accepted_live_record_continuity"
        elif not record_execution and not record_history and witness_history and floor_execution:
            code = "accepted_successor_witness_continuity"
        else:
            code = "accepted_hybrid_continuity"
    elif execution:
        code = "accepted_execution_only"
    elif history:
        code = "accepted_history_only"
    else:
        code = "accepted_neither"
    return (
        code, True, record_execution, record_history, witness_history, floor_execution,
        execution, history, continuity, reclamation_safe, False,
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    root = args.output.resolve()
    with (root / "CASES.tsv").open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        if reader.fieldnames != FIELDS:
            fail(f"header={reader.fieldnames!r}")
        rows = list(reader)
    if len(rows) != 52 or len({row["case"] for row in rows}) != 52:
        fail("case cardinality")

    accepted = continuity = execution_only = history_only = neither = fail_stop = safe = 0
    for row in rows:
        expected = evaluate(row)
        observed = (
            row["candidate_code"], b(row, "accepted"), b(row, "record_execution_path"),
            b(row, "record_history_path"), b(row, "witness_history_path"),
            b(row, "floor_execution_path"), b(row, "duplicate_execution_excluded"),
            b(row, "terminal_outcome_reopenable"), b(row, "terminal_continuity"),
            b(row, "reclamation_safe"), b(row, "fail_stopped"),
        )
        if expected != observed:
            fail(f"evaluation={row['case']} expected={expected!r} observed={observed!r}")
        if row["candidate_code"] != row["reference_code"] or not b(row, "agreement"):
            fail(f"differential={row['case']}")
        if b(row, "client_ack_sufficient") or b(row, "ttl_sufficient") or b(row, "authority"):
            fail(f"forbidden projection={row['case']}")
        accepted += b(row, "accepted")
        continuity += b(row, "accepted") and b(row, "terminal_continuity")
        execution_only += b(row, "accepted") and b(row, "duplicate_execution_excluded") and not b(row, "terminal_outcome_reopenable")
        history_only += b(row, "accepted") and not b(row, "duplicate_execution_excluded") and b(row, "terminal_outcome_reopenable")
        neither += b(row, "accepted") and not b(row, "duplicate_execution_excluded") and not b(row, "terminal_outcome_reopenable") and not b(row, "fail_stopped")
        fail_stop += b(row, "accepted") and b(row, "fail_stopped")
        safe += b(row, "accepted") and b(row, "reclamation_safe")

    summary = json.loads((root / "SUMMARY.json").read_text(encoding="utf-8"))
    expected_summary = {
        "accepted_cases": 19,
        "authority_granted": False,
        "candidate_reference_disagreements": 0,
        "cases": 52,
        "client_ack_sufficient_cases": 0,
        "currentness_proved": False,
        "duplicate_execution_excluded_cases": 13,
        "epoch_exit_proved": False,
        "execution_only_cases": 4,
        "external_occurrence_proved": False,
        "fail_stopped_cases": 1,
        "history_only_cases": 3,
        "independent_custody_proved": False,
        "neither_cases": 2,
        "reclamation_safe_cases": 4,
        "rejected_cases": 33,
        "schema": "slopos.rev0917.terminal-outcome-continuity-campaign.v1",
        "terminal_continuity_cases": 9,
        "terminal_outcome_reopenable_cases": 12,
        "ttl_sufficient_cases": 0,
    }
    if summary != expected_summary:
        fail(f"summary={summary!r}")
    if (accepted, continuity, execution_only, history_only, neither, fail_stop, safe) != (19, 9, 4, 3, 2, 1, 4):
        fail("summary counts")

    quadrants = list(csv.DictReader((root / "QUADRANTS.tsv").open(newline="", encoding="utf-8"), delimiter="\t"))
    if [(row["duplicate_execution_excluded"], row["terminal_outcome_reopenable"]) for row in quadrants] != [
        ("true", "true"), ("true", "false"), ("false", "true"), ("false", "false")]:
        fail("quadrants")
    histories = list(csv.DictReader((root / "COUNTERHISTORIES.tsv").open(newline="", encoding="utf-8"), delimiter="\t"))
    if [row["row"] for row in histories] != ["E0", "E1", "H0", "H1", "T0", "T1", "S0", "S1"]:
        fail("counterhistories")
    if histories[1]["terminal_outcome_reopenable"] != "false" or histories[3]["duplicate_execution_excluded"] != "false":
        fail("counterhistory theorem")

    required = {
        "TERMINAL_CONTINUITY_EQUALS_EXECUTION_EXCLUDED_AND_OUTCOME_REOPENABLE=true",
        "EXECUTION_FENCE_DOES_NOT_IMPLY_HISTORY=true",
        "OUTCOME_WITNESS_DOES_NOT_IMPLY_EXECUTION_FENCE=true",
        "CLIENT_ACK_SUFFICIENT=false",
        "TTL_EXPIRY_SUFFICIENT=false",
        "SUCCESSOR_FLOOR_MUST_BIND_REQUEST_NAMESPACE=true",
        "SUCCESSOR_FLOOR_MUST_FENCE_PENDING_INVOCATIONS=true",
        "SUCCESSOR_FLOOR_MUST_SURVIVE_RESTORE_AND_SUCCESSION=true",
        "TERMINAL_WITNESS_MUST_BIND_EXACT_OUTCOME=true",
        "TERMINAL_WITNESS_MUST_BE_INDEPENDENTLY_REOPENABLE=true",
        "EQUIVOCATION_FAILS_STOP=true",
        "RECLAMATION_SAFE_REQUIRES_WITNESS_AND_SUCCESSOR_FLOOR=true",
        "EXTERNAL_OCCURRENCE_PROVED=false",
        "AUTHORITY_GRANTED=false",
    }
    if set((root / "INVARIANTS.txt").read_text(encoding="utf-8").splitlines()) != required:
        fail("invariants")

    print(
        "TERMINAL_OUTCOME_CONTINUITY_PY=PASS cases=52 accepted=19 rejected=33 "
        "continuity=9 execution_only=4 history_only=3 neither=2 fail_stop=1 "
        "reclamation_safe=4 disagreements=0 authority=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
