#pragma once

#include "slopos/e0/signed_admission/root_ceremony_anchor.hpp"

#include <cstdint>
#include <filesystem>
#include <string_view>

namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery {

enum class Phase : std::uint8_t {
    ready,
    query_only,
    terminal_effect,
    terminal_no_effect,
    fail_stopped,
};

enum class Command : std::uint8_t {
    submit_exact,
    query_exact,
    declare_no_effect,
    reopen,
    clear_latch,
    repair,
    none,
};

enum class Observation : std::uint8_t {
    commit_reply,
    no_reply,
    committed_record,
    absent_record,
    retired_record,
    unavailable,
    wrong_incarnation,
    split_view,
    reopen_event,
    none,
};

enum class Outcome : std::uint8_t {
    none,
    uncertain,
    effect,
    no_effect,
    fail_stop,
};

enum class RecoveryCode : std::uint8_t {
    accepted_submit_commit,
    accepted_submit_uncertain,
    accepted_query_commit,
    accepted_query_absent_unresolved,
    accepted_query_retired,
    accepted_query_unavailable,
    accepted_query_wrong_incarnation_fail_stop,
    accepted_query_split_view_fail_stop,
    accepted_reopen_query_only,
    accepted_reopen_terminal_effect,
    accepted_reopen_terminal_no_effect,
    accepted_reopen_fail_stop,
    invalid_state,
    request_id_mismatch,
    transition_digest_mismatch,
    register_incarnation_mismatch,
    invalid_command_for_phase,
    invalid_observation_for_command,
    authentication_required,
    linearizable_observation_required,
    single_view_required,
    durable_result_required,
    retention_horizon_required,
    retirement_record_required,
    late_commit_fence_required,
    absence_not_terminal,
    query_only_latched,
    terminal_immutable,
    fail_stop_immutable,
};

struct RecoveryState final {
    Phase phase{Phase::ready};
    Digest request_id{};
    Digest transition_digest{};
    Digest register_incarnation{};

    [[nodiscard]] friend constexpr bool operator==(
        const RecoveryState&, const RecoveryState&) noexcept = default;
};

struct RecoveryStep final {
    Command command{Command::none};
    Observation observation{Observation::none};
    Digest request_id{};
    Digest transition_digest{};
    Digest register_incarnation{};
    bool authenticated{false};
    bool linearizable{false};
    bool single_view{false};
    bool durable_result{false};
    bool retirement_serialized{false};
    bool late_commit_fenced{false};
    bool retention_covers_reopen{false};

    [[nodiscard]] friend constexpr bool operator==(
        const RecoveryStep&, const RecoveryStep&) noexcept = default;
};

struct RecoveryReport final {
    RecoveryCode code{RecoveryCode::invalid_state};
    bool accepted{false};
    Phase next_phase{Phase::fail_stopped};
    Outcome outcome{Outcome::fail_stop};
    bool query_only{false};
    bool terminal{false};
    bool terminal_no_effect_justified{false};
    bool absence_terminal{false};
    bool resubmit_allowed{false};
    bool recovery_mints_first_submit{false};
    bool external_occurrence_proved{false};
    bool currentness_proved{false};
    bool independent_custody_proved{false};
    bool independent_reopen_proved{false};
    bool epoch_exit_proved{false};
    bool authority_granted{false};

    [[nodiscard]] friend constexpr bool operator==(
        const RecoveryReport&, const RecoveryReport&) noexcept = default;
};

[[nodiscard]] RecoveryReport evaluate_candidate(
    const RecoveryState& state,
    const RecoveryStep& step) noexcept;
[[nodiscard]] RecoveryReport evaluate_reference(
    const RecoveryState& state,
    const RecoveryStep& step) noexcept;

[[nodiscard]] std::string_view phase_name(Phase value) noexcept;
[[nodiscard]] std::string_view command_name(Command value) noexcept;
[[nodiscard]] std::string_view observation_name(Observation value) noexcept;
[[nodiscard]] std::string_view outcome_name(Outcome value) noexcept;
[[nodiscard]] std::string_view recovery_code_name(RecoveryCode value) noexcept;

[[nodiscard]] bool run_campaign(const std::filesystem::path& output_directory);

}  // namespace slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery
