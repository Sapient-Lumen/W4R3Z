# Query-Only Recovery V1

## Status

Hosted Epoch-Zero proofwork. No external occurrence, selected current register,
protected transition, independent custody, independent reopen, epoch exit, or
authority claim.

## State law

```text
READY
  -- exact compare/apply returns durable committed result --> TERMINAL_EFFECT
  -- exact compare/apply does not return ------------------> QUERY_ONLY

QUERY_ONLY
  -- exact durable committed record ----------------------> TERMINAL_EFFECT
  -- exact linearizable absent observation ---------------> QUERY_ONLY
  -- unavailable observation -----------------------------> QUERY_ONLY
  -- exact serialized retirement + late-commit fence -----> TERMINAL_NO_EFFECT
  -- wrong incarnation or split view ---------------------> FAIL_STOP
```

`QUERY_ONLY`, `TERMINAL_EFFECT`, `TERMINAL_NO_EFFECT`, and `FAIL_STOP` are
monotone. Reopen and restore preserve the phase. Recovery has no first-submit,
resubmit, repair, latch-clear, or local-no-effect route.

## Pending-invocation theorem

Let `P` be a history prefix containing a compare/apply invocation with no
matching response. Suppose a linearizable query in `P` observes no committed
record. Two legal extensions remain possible:

1. the pending invocation never takes effect; and
2. the pending invocation linearizes after the query and commits the effect.

The query result is identical in both prefixes while the later effect differs.
Therefore `absent` cannot soundly imply terminal `NO_EFFECT` while the original
invocation remains eligible to commit.

## Terminal negative obligation

A terminal negative requires one operation at the same serialization point to
record the exact request as retired and make every later or already-pending
compare/apply for that request unable to commit. The record must bind exact
request ID, transition digest, and register incarnation; be authenticated,
linearizable, non-equivocal, durable, and retained for at least the full reopen
horizon; and survive admitted restore/succession rules.

A tombstone name, finite transport idempotency token, ordinary absent read,
client timeout, local cancellation, lease expiry, or restored local latch does
not satisfy this obligation by itself.
