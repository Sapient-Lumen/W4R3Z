#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import struct
import sys
from dataclasses import dataclass
from pathlib import Path

sys.dont_write_bytecode = True

try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
except Exception as exc:  # pragma: no cover - fail closed in the deployed lane
    raise SystemExit(f"DETACHED_RESPONSE_APERTURE_REOPEN=FAIL detail=cryptography:{exc}")

EXPECTED_SIZES = {
    "LAB-RESPONSE-FIXTURE.bin": 512,
    "MODELED-PUBLICATION-RECEIPT.bin": 256,
    "MODELED-REOPEN-RECEIPT.bin": 256,
    "ACCEPTING-CONFIGURATION.bin": 288,
    "POLICY-REJECT-CONFIGURATION.bin": 288,
    "SUCCESSOR-CONFIGURATION.bin": 288,
    "APPRAISAL-WITNESS.bin": 320,
    "CONSUMPTION-DEFICIT.bin": 320,
}
EXPECTED_PARENT_SHA256 = "408274cee2672108bff4aff62f72a5f7e7416bc92f63e76a15c766c8b3a4cd70"
EXPECTED_PARENT_BYTES = 13_452_209
EXPECTED_PARENT_MANIFEST_ROWS = 9_390
ALL_CLAIMS = 0x7FFF
HOSTED_CLAIMS = 0x07FF
GOVERNANCE_CLAIMS = 0x7800


def fail(detail: str) -> "NoReturn":
    raise SystemExit(f"DETACHED_RESPONSE_APERTURE_REOPEN=FAIL detail={detail}")


def sha256_bytes(data: bytes) -> bytes:
    return hashlib.sha256(data).digest()


def sha256_file(path: Path) -> bytes:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            h.update(block)
    return h.digest()


def read_exact(path: Path, expected: int) -> bytes:
    data = path.read_bytes()
    if len(data) != expected:
        fail(f"size:{path.name}:{len(data)}!={expected}")
    return data


def be16(data: bytes, offset: int) -> int:
    return struct.unpack_from(">H", data, offset)[0]


def be32(data: bytes, offset: int) -> int:
    return struct.unpack_from(">I", data, offset)[0]


def be64(data: bytes, offset: int) -> int:
    return struct.unpack_from(">Q", data, offset)[0]


def digest_at(data: bytes, offset: int) -> bytes:
    return data[offset : offset + 32]


def require_zero_padding(data: bytes, offset: int, label: str) -> None:
    if any(data[offset:]):
        fail(f"nonzero-padding:{label}")


def require_magic(data: bytes, expected: bytes, label: str) -> None:
    if data[:8] != expected:
        fail(f"magic:{label}:{data[:8]!r}")


def policy_digest(bindings: Path, name: str) -> bytes:
    path = bindings / name
    if not path.is_file():
        fail(f"missing-policy:{name}")
    return sha256_file(path)


@dataclass(frozen=True)
class Response:
    raw: bytes
    identity: bytes
    flags: int
    accepted: int
    rejected: int
    unresolved: int
    parent_bytes: int
    parent_rows: int
    root_version: int
    issued: int
    not_before: int
    expires: int
    request: bytes
    parent_archive: bytes
    parent_claim: bytes
    claim_catalogue: bytes
    response_profile: bytes
    constitution: bytes
    owner_root: bytes
    appraisal_policy: bytes
    target: bytes
    namespace: bytes
    public_key: bytes
    signature: bytes


def parse_response(data: bytes) -> Response:
    require_magic(data, b"DRARESP1", "response")
    if be32(data, 8) != 1:
        fail("response-schema")
    flags = be16(data, 12)
    if flags != 0x000F:
        fail(f"response-flags:{flags:#x}")
    accepted, rejected, unresolved = be16(data, 14), be16(data, 16), be16(data, 18)
    if accepted & rejected or accepted & unresolved or rejected & unresolved:
        fail("response-claim-overlap")
    if accepted | rejected | unresolved != ALL_CLAIMS:
        fail("response-claim-not-exhaustive")
    if (accepted, rejected, unresolved) != (HOSTED_CLAIMS, 0, GOVERNANCE_CLAIMS):
        fail("response-fixture-partition")
    values = [digest_at(data, 68 + 32 * index) for index in range(10)]
    public_key = data[388:420]
    require_zero_padding(data[:448], 420, "response-signing")
    signature = data[448:512]
    try:
        Ed25519PublicKey.from_public_bytes(public_key).verify(signature, data[:448])
    except Exception:
        fail("response-signature")
    result = Response(
        raw=data,
        identity=sha256_bytes(data),
        flags=flags,
        accepted=accepted,
        rejected=rejected,
        unresolved=unresolved,
        parent_bytes=be64(data, 20),
        parent_rows=be64(data, 28),
        root_version=be64(data, 36),
        issued=be64(data, 44),
        not_before=be64(data, 52),
        expires=be64(data, 60),
        request=values[0],
        parent_archive=values[1],
        parent_claim=values[2],
        claim_catalogue=values[3],
        response_profile=values[4],
        constitution=values[5],
        owner_root=values[6],
        appraisal_policy=values[7],
        target=values[8],
        namespace=values[9],
        public_key=public_key,
        signature=signature,
    )
    if result.parent_bytes != EXPECTED_PARENT_BYTES or result.parent_rows != EXPECTED_PARENT_MANIFEST_ROWS:
        fail("response-parent-counts")
    if result.parent_archive.hex() != EXPECTED_PARENT_SHA256:
        fail("response-parent-digest")
    if not (result.not_before <= result.issued < result.expires):
        fail("response-time-order")
    if result.root_version != 41:
        fail("response-root-version")
    if any(not value or not any(value) for value in values + [public_key, signature]):
        fail("response-zero-binding")
    return result


@dataclass(frozen=True)
class Publication:
    identity: bytes
    flags: int
    sequence: int
    carrier_bytes: int
    response: bytes
    request: bytes
    parent_archive: bytes
    namespace: bytes
    role: bytes
    carrier: bytes
    policy: bytes


def parse_publication(data: bytes) -> Publication:
    require_magic(data, b"DRAPUB01", "publication")
    if be32(data, 8) != 1:
        fail("publication-schema")
    flags = be16(data, 12)
    if flags != 0x001F:
        fail(f"publication-flags:{flags:#x}")
    values = [digest_at(data, 30 + 32 * index) for index in range(7)]
    require_zero_padding(data, 254, "publication")
    return Publication(sha256_bytes(data), flags, be64(data, 14), be64(data, 22), *values)


@dataclass(frozen=True)
class Reopen:
    identity: bytes
    flags: int
    carrier_bytes: int
    publication: bytes
    response: bytes
    request: bytes
    role: bytes
    implementation: bytes
    carrier: bytes
    policy: bytes


def parse_reopen(data: bytes) -> Reopen:
    require_magic(data, b"DRAREOP1", "reopen")
    if be32(data, 8) != 1:
        fail("reopen-schema")
    flags = be16(data, 12)
    if flags != 0x003F:
        fail(f"reopen-flags:{flags:#x}")
    values = [digest_at(data, 22 + 32 * index) for index in range(7)]
    require_zero_padding(data, 246, "reopen")
    return Reopen(sha256_bytes(data), flags, be64(data, 14), *values)


@dataclass(frozen=True)
class Configuration:
    identity: bytes
    flags: int
    required: int
    forbidden: int
    root_version: int
    evaluation_time: int
    constitution: bytes
    owner_root: bytes
    policy: bytes
    target: bytes
    namespace: bytes
    role: bytes
    public_key: bytes


def parse_configuration(data: bytes, label: str) -> Configuration:
    require_magic(data, b"DRACFG01", label)
    if be32(data, 8) != 1:
        fail(f"{label}-schema")
    flags = be16(data, 12)
    if flags != 0x0007:
        fail(f"{label}-flags:{flags:#x}")
    values = [digest_at(data, 34 + 32 * index) for index in range(6)]
    public_key = data[226:258]
    require_zero_padding(data, 258, label)
    return Configuration(
        sha256_bytes(data), flags, be16(data, 14), be16(data, 16),
        be64(data, 18), be64(data, 26), *values, public_key
    )


@dataclass(frozen=True)
class Appraisal:
    identity: bytes
    flags: int
    accepting_result: int
    policy_result: int
    successor_result: int
    appraisal_root_version: int
    successor_root_version: int
    response: bytes
    publication: bytes
    reopen: bytes
    accepting_config: bytes
    policy_config: bytes
    successor_config: bytes
    request: bytes
    policy: bytes


def parse_appraisal(data: bytes) -> Appraisal:
    require_magic(data, b"DRAAPP01", "appraisal")
    if be32(data, 8) != 1:
        fail("appraisal-schema")
    flags = be16(data, 12)
    if flags != 0x007F:
        fail(f"appraisal-flags:{flags:#x}")
    values = [digest_at(data, 33 + 32 * index) for index in range(8)]
    require_zero_padding(data, 289, "appraisal")
    return Appraisal(
        sha256_bytes(data), flags, data[14], data[15], data[16],
        be64(data, 17), be64(data, 25), *values
    )


@dataclass(frozen=True)
class Deficit:
    identity: bytes
    flags: int
    missing: int
    appraisal_root_version: int
    consumption_root_version: int
    appraisal_time: int
    consumption_time: int
    response: bytes
    appraisal: bytes
    accepting_config: bytes
    successor_config: bytes
    request: bytes
    appraised_root: bytes
    consumption_root: bytes
    policy: bytes


def parse_deficit(data: bytes) -> Deficit:
    require_magic(data, b"DRADEF01", "deficit")
    if be32(data, 8) != 1:
        fail("deficit-schema")
    flags = be16(data, 12)
    if flags != 0x007F:
        fail(f"deficit-flags:{flags:#x}")
    values = [digest_at(data, 48 + 32 * index) for index in range(8)]
    require_zero_padding(data, 304, "deficit")
    return Deficit(
        sha256_bytes(data), flags, be16(data, 14), be64(data, 16),
        be64(data, 24), be64(data, 32), be64(data, 40), *values
    )


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle, delimiter="\t"))


def main() -> int:
    parser = argparse.ArgumentParser(description="Independently reopen Detached Response Intake Aperture V1 outputs.")
    parser.add_argument("output", type=Path)
    parser.add_argument("bindings", type=Path)
    args = parser.parse_args()
    output, bindings = args.output.resolve(), args.bindings.resolve()
    if not output.is_dir() or not bindings.is_dir():
        fail("directory-input")

    raw = {name: read_exact(output / name, size) for name, size in EXPECTED_SIZES.items()}
    response = parse_response(raw["LAB-RESPONSE-FIXTURE.bin"])
    publication = parse_publication(raw["MODELED-PUBLICATION-RECEIPT.bin"])
    reopen = parse_reopen(raw["MODELED-REOPEN-RECEIPT.bin"])
    accepting = parse_configuration(raw["ACCEPTING-CONFIGURATION.bin"], "accepting-configuration")
    policy_reject = parse_configuration(raw["POLICY-REJECT-CONFIGURATION.bin"], "policy-reject-configuration")
    successor = parse_configuration(raw["SUCCESSOR-CONFIGURATION.bin"], "successor-configuration")
    appraisal = parse_appraisal(raw["APPRAISAL-WITNESS.bin"])
    deficit = parse_deficit(raw["CONSUMPTION-DEFICIT.bin"])

    response_policy = policy_digest(bindings, "RESPONSE-SHAPE-POLICY.txt")
    trust_policy = policy_digest(bindings, "TRUST-CONFIGURATION-POLICY.txt")
    consumption_policy = policy_digest(bindings, "CONSUMPTION-CURRENTNESS-FENCE-POLICY.txt")
    implementation = sha256_file(Path(__file__).resolve())

    if response.appraisal_policy != trust_policy:
        fail("response-trust-policy-binding")
    if publication.policy != response_policy or reopen.policy != response_policy:
        fail("response-shape-policy-binding")
    if reopen.implementation != implementation:
        fail("reopener-implementation-binding")
    if deficit.policy != consumption_policy:
        fail("consumption-policy-binding")

    if publication.sequence != 1 or publication.carrier_bytes != 512:
        fail("publication-coordinate")
    if publication.response != response.identity or publication.carrier != response.identity:
        fail("publication-response-binding")
    if publication.request != response.request or publication.parent_archive != response.parent_archive:
        fail("publication-parent-binding")
    if reopen.carrier_bytes != 512 or reopen.publication != publication.identity:
        fail("reopen-publication-binding")
    if reopen.response != response.identity or reopen.carrier != response.identity or reopen.request != response.request:
        fail("reopen-response-binding")

    configs = (accepting, policy_reject, successor)
    if len({item.identity for item in configs}) != 3:
        fail("configuration-identity-distinctness")
    for item in configs:
        if item.constitution != response.constitution or item.policy != response.appraisal_policy:
            fail("configuration-constitution-policy")
        if item.target != response.target or item.namespace != response.namespace:
            fail("configuration-target-namespace")
        if item.public_key != response.public_key:
            fail("configuration-signer")
        if item.forbidden != ALL_CLAIMS:
            fail("configuration-forbidden-mask")
    if (accepting.root_version, accepting.evaluation_time, accepting.required) != (41, 1200, HOSTED_CLAIMS):
        fail("accepting-configuration-semantics")
    if accepting.owner_root != response.owner_root:
        fail("accepting-root")
    if (policy_reject.root_version, policy_reject.evaluation_time, policy_reject.required) != (41, 1200, ALL_CLAIMS):
        fail("policy-reject-semantics")
    if policy_reject.owner_root != response.owner_root:
        fail("policy-reject-root")
    if (successor.root_version, successor.evaluation_time, successor.required) != (42, 1300, HOSTED_CLAIMS):
        fail("successor-configuration-semantics")
    if successor.owner_root == response.owner_root:
        fail("successor-root-not-advanced")
    if any(item.evaluation_time < response.issued or item.evaluation_time >= response.expires for item in configs):
        fail("configuration-evaluation-outside-issued-current-window")

    if (appraisal.accepting_result, appraisal.policy_result, appraisal.successor_result) != (0, 10, 5):
        fail("appraisal-results")
    if (appraisal.appraisal_root_version, appraisal.successor_root_version) != (41, 42):
        fail("appraisal-root-versions")
    if appraisal.response != response.identity or appraisal.publication != publication.identity or appraisal.reopen != reopen.identity:
        fail("appraisal-object-bindings")
    if (appraisal.accepting_config, appraisal.policy_config, appraisal.successor_config) != tuple(item.identity for item in configs):
        fail("appraisal-configuration-bindings")
    if appraisal.request != response.request or appraisal.policy != trust_policy:
        fail("appraisal-request-policy")

    if deficit.missing != 0x003F:
        fail("deficit-mask")
    if (deficit.appraisal_root_version, deficit.consumption_root_version) != (41, 42):
        fail("deficit-root-versions")
    if (deficit.appraisal_time, deficit.consumption_time) != (1200, 1300):
        fail("deficit-times")
    if deficit.response != response.identity or deficit.appraisal != appraisal.identity:
        fail("deficit-object-bindings")
    if deficit.accepting_config != accepting.identity or deficit.successor_config != successor.identity:
        fail("deficit-configuration-bindings")
    if deficit.request != response.request or deficit.appraised_root != response.owner_root:
        fail("deficit-parent-bindings")
    if deficit.consumption_root != successor.owner_root or deficit.consumption_root == deficit.appraised_root:
        fail("deficit-successor-root")

    identities = read_tsv(output / "IDENTITIES.tsv")
    expected_identity_rows = {
        name: (str(EXPECTED_SIZES[name]), sha256_bytes(raw[name]).hex()) for name in EXPECTED_SIZES
    }
    observed_identity_rows = {row["object"]: (row["bytes"], row["sha256"]) for row in identities}
    if observed_identity_rows != expected_identity_rows:
        fail("identity-table")

    summary = {row["metric"]: row["value"] for row in read_tsv(output / "SUMMARY.tsv")}
    expected_summary = {
        "cases": "121", "accepted_classifications": "7", "rejected_classifications": "114",
        "appraisal_witness_ready_cases": "20", "consumption_deficit_ready_cases": "1",
        "lifecycle_cut_rows": "847", "durable_stages": "7",
        "canonical_exact_object_bytes": "2528", "candidate_reference_disagreements": "0",
        "real_ed25519_fixture": "true", "external_response_present": "false",
        "external_trust_configuration_proved": "false", "owner_admission_proved": "false",
        "authority_granted": "false", "epoch_exit_proved": "false",
    }
    if summary != expected_summary:
        fail("summary-table")
    cases = read_tsv(output / "CASES.tsv")
    cuts = read_tsv(output / "CUTS.tsv")
    countermodels = read_tsv(output / "COUNTERMODELS.tsv")
    laws = read_tsv(output / "LAWS.tsv")
    if len(cases) != 121 or len(cuts) != 847 or len(countermodels) != 114 or len(laws) != 13:
        fail("campaign-row-counts")
    case_map = {row["case"]: row for row in cases}
    issuance_case = case_map.get("accepting_configuration_before_response_issuance")
    if not issuance_case or issuance_case.get("candidate") != "accepting_configuration_did_not_accept" or issuance_case.get("reference") != "accepting_configuration_did_not_accept" or issuance_case.get("accepted") != "false":
        fail("issued-at-counterexample")
    if any(row["candidate"] != row["reference"] for row in cases + cuts):
        fail("candidate-reference-disagreement")
    if sum(row["accepted"] == "true" for row in cases) != 7:
        fail("accepted-case-count")
    if any(row["result"] != "REJECTED" for row in countermodels):
        fail("countermodel-result")
    report = (output / "REPORT.txt").read_text(encoding="utf-8")
    required_report = (
        "DETACHED_RESPONSE_INTAKE_APERTURE=PASS", "cases=121 accepted=7 rejected=114 cuts=847",
        "candidate_reference_disagreements=0", "external_response=false", "authority=false",
    )
    if any(item not in report for item in required_report):
        fail("report")

    print(
        "DETACHED_RESPONSE_APERTURE_REOPEN=PASS "
        "objects=8 bytes=2528 cases=121 cuts=847 ed25519=true "
        "configured_trust=true external_trust=false owner_admission=false authority=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
