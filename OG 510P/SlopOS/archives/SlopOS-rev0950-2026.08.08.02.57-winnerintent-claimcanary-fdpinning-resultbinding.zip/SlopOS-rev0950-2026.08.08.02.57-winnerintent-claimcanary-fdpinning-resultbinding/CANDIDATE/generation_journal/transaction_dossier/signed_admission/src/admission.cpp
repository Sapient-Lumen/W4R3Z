#include "slopos/e0/signed_admission/admission.hpp"

#include <algorithm>
#include <array>
#include <limits>
#include <string_view>
#include <vector>

#include <openssl/evp.h>

namespace slopos::e0::signed_admission {
namespace {

constexpr std::array<std::uint8_t, 8U> kManifestMagic{{'S','L','O','P','O','M','0','1'}};
constexpr std::array<std::uint8_t, 8U> kStatementMagic{{'S','L','O','P','A','S','0','1'}};
constexpr std::array<std::uint8_t, 8U> kEnvelopeMagic{{'S','L','O','P','A','E','0','1'}};
constexpr std::uint16_t kVersion = 1U;
constexpr std::uint16_t kManifestKind = 1U;
constexpr std::uint16_t kStatementKind = 2U;
constexpr std::uint16_t kEnvelopeKind = 3U;
constexpr std::uint8_t kEd25519Suite = 1U;
constexpr std::string_view kKeyIdDomain = "SlopOS/admission/key-id/v1";
constexpr std::string_view kManifestIntegrityDomain = "SlopOS/admission/manifest-integrity/v1";
constexpr std::string_view kManifestHeadDomain = "SlopOS/admission/manifest-head/v1";
constexpr std::string_view kStatementIntegrityDomain = "SlopOS/admission/statement-integrity/v1";
constexpr std::string_view kStatementHeadDomain = "SlopOS/admission/statement-head/v1";
constexpr std::string_view kEnvelopeIntegrityDomain = "SlopOS/admission/envelope-integrity/v1";
constexpr std::string_view kDossierPrefixDomain = "SlopOS/admission/dossier-prefix/v1";
constexpr std::string_view kProfileDomain = "SlopOS/admission/profile/v1";
constexpr std::string_view kProfileText =
    "SlopOS Epoch-Zero signed-admission evidence profile v1; fixed Ed25519 threshold; "
    "exact R1-R6 binding; no owner constitution, currentness, global spend, authority, or epoch exit";
constexpr std::string_view kSigningDomain = "SlopOS/signed-admission/v1/PAE";

[[nodiscard]] bool all_zero(const std::span<const std::uint8_t> bytes) noexcept {
    return std::all_of(bytes.begin(), bytes.end(), [](const std::uint8_t byte) {
        return byte == 0U;
    });
}

[[nodiscard]] bool nonzero(const Digest& value) noexcept {
    return !all_zero(value);
}

[[nodiscard]] bool nonzero(const Signature& value) noexcept {
    return !all_zero(value);
}

template <std::size_t N>
void put_u16(std::array<std::uint8_t, N>& output, const std::size_t offset,
             const std::uint16_t value) noexcept {
    output[offset] = static_cast<std::uint8_t>(value >> 8U);
    output[offset + 1U] = static_cast<std::uint8_t>(value);
}

template <std::size_t N>
void put_u32(std::array<std::uint8_t, N>& output, const std::size_t offset,
             const std::uint32_t value) noexcept {
    output[offset] = static_cast<std::uint8_t>(value >> 24U);
    output[offset + 1U] = static_cast<std::uint8_t>(value >> 16U);
    output[offset + 2U] = static_cast<std::uint8_t>(value >> 8U);
    output[offset + 3U] = static_cast<std::uint8_t>(value);
}

template <std::size_t N>
void put_u64(std::array<std::uint8_t, N>& output, const std::size_t offset,
             const std::uint64_t value) noexcept {
    for (std::size_t index = 0U; index < 8U; ++index) {
        const unsigned int shift = static_cast<unsigned int>((7U - index) * 8U);
        output[offset + index] = static_cast<std::uint8_t>(value >> shift);
    }
}

template <std::size_t N>
[[nodiscard]] std::uint16_t get_u16(const std::array<std::uint8_t, N>& input,
                                    const std::size_t offset) noexcept {
    return static_cast<std::uint16_t>(
        (static_cast<std::uint16_t>(input[offset]) << 8U)
        | static_cast<std::uint16_t>(input[offset + 1U]));
}

template <std::size_t N>
[[nodiscard]] std::uint32_t get_u32(const std::array<std::uint8_t, N>& input,
                                    const std::size_t offset) noexcept {
    return (static_cast<std::uint32_t>(input[offset]) << 24U)
        | (static_cast<std::uint32_t>(input[offset + 1U]) << 16U)
        | (static_cast<std::uint32_t>(input[offset + 2U]) << 8U)
        | static_cast<std::uint32_t>(input[offset + 3U]);
}

template <std::size_t N>
[[nodiscard]] std::uint64_t get_u64(const std::array<std::uint8_t, N>& input,
                                    const std::size_t offset) noexcept {
    std::uint64_t value = 0U;
    for (std::size_t index = 0U; index < 8U; ++index) {
        value = (value << 8U) | static_cast<std::uint64_t>(input[offset + index]);
    }
    return value;
}

template <std::size_t N, std::size_t M>
void put_array(std::array<std::uint8_t, N>& output, const std::size_t offset,
               const std::array<std::uint8_t, M>& value) noexcept {
    std::copy(value.begin(), value.end(),
              output.begin() + static_cast<std::ptrdiff_t>(offset));
}

template <std::size_t M, std::size_t N>
[[nodiscard]] std::array<std::uint8_t, M> get_array(
    const std::array<std::uint8_t, N>& input, const std::size_t offset) noexcept {
    std::array<std::uint8_t, M> value{};
    std::copy_n(input.begin() + static_cast<std::ptrdiff_t>(offset), M, value.begin());
    return value;
}

[[nodiscard]] Digest digest_domain_payload(
    const std::string_view domain, const std::span<const std::uint8_t> payload) {
    std::vector<std::uint8_t> bytes;
    bytes.reserve(domain.size() + 1U + payload.size());
    bytes.insert(bytes.end(), domain.begin(), domain.end());
    bytes.push_back(0U);
    bytes.insert(bytes.end(), payload.begin(), payload.end());
    return generation_journal::sha256(bytes);
}

[[nodiscard]] bool terminal_scope_valid(const TerminalScope value) noexcept {
    const auto raw = static_cast<std::uint8_t>(value);
    return raw >= static_cast<std::uint8_t>(TerminalScope::effect)
        && raw <= static_cast<std::uint8_t>(TerminalScope::fail_stop);
}

[[nodiscard]] bool manifest_invariant(const OwnerManifestV1& value) {
    if (!nonzero(value.project_id) || !nonzero(value.constitution_id)
        || value.version == 0U || value.key_count == 0U
        || value.key_count > kMaximumKeys || value.threshold == 0U
        || value.threshold > value.key_count) {
        return false;
    }
    for (std::size_t index = 0U; index < kMaximumKeys; ++index) {
        const KeyV1& key = value.keys[index];
        if (index < value.key_count) {
            if (!nonzero(key.public_key) || !nonzero(key.key_id)
                || key.key_id != key_id_for(key.public_key)) {
                return false;
            }
            if (index > 0U && !(value.keys[index - 1U].key_id < key.key_id)) {
                return false;
            }
        } else if (!all_zero(key.key_id) || !all_zero(key.public_key)) {
            return false;
        }
    }
    return true;
}

[[nodiscard]] bool statement_invariant(const AdmissionStatementV1& value) noexcept {
    const std::array<const Digest*, 12U> digests{{
        &value.project_id, &value.owner_manifest_head, &value.profile_digest,
        &value.transaction_id, &value.prefix_digest, &value.subject,
        &value.policy, &value.evidence, &value.appraisal, &value.issuer_actor,
        &value.endpoint_actor, &value.reopener_actor,
    }};
    if (value.purpose != Purpose::effect_permit
        || !terminal_scope_valid(value.terminal_scope)
        || std::any_of(digests.begin(), digests.end(), [](const Digest* digest) {
            return !nonzero(*digest);
        })
        || value.generation_from == 0U
        || value.generation_from == std::numeric_limits<std::uint64_t>::max()
        || value.nonce == 0U || value.ceremony_nonce == 0U
        || value.expires_at <= value.not_before) {
        return false;
    }
    switch (value.terminal_scope) {
        case TerminalScope::effect:
            return value.generation_to == value.generation_from + 1U;
        case TerminalScope::no_effect:
        case TerminalScope::fail_stop:
            return value.generation_to == value.generation_from;
        case TerminalScope::uncertain:
            return value.generation_to == 0U;
    }
    return false;
}

[[nodiscard]] bool verify_ed25519(const PublicKey& public_key,
                                  const Signature& signature,
                                  const SigningMessage& message) noexcept {
    EVP_PKEY* raw_key = EVP_PKEY_new_raw_public_key(
        EVP_PKEY_ED25519, nullptr, public_key.data(), public_key.size());
    if (raw_key == nullptr) return false;
    EVP_MD_CTX* context = EVP_MD_CTX_new();
    if (context == nullptr) {
        EVP_PKEY_free(raw_key);
        return false;
    }
    const int initialized = EVP_DigestVerifyInit(context, nullptr, nullptr, nullptr, raw_key);
    const int verified = initialized == 1
        ? EVP_DigestVerify(context, signature.data(), signature.size(),
                           message.data(), message.size())
        : 0;
    EVP_MD_CTX_free(context);
    EVP_PKEY_free(raw_key);
    return verified == 1;
}

[[nodiscard]] TerminalScope scope_for(const transaction_dossier::Terminal value) noexcept {
    switch (value) {
        case transaction_dossier::Terminal::effect: return TerminalScope::effect;
        case transaction_dossier::Terminal::no_effect: return TerminalScope::no_effect;
        case transaction_dossier::Terminal::uncertain: return TerminalScope::uncertain;
        case transaction_dossier::Terminal::fail_stop: return TerminalScope::fail_stop;
        case transaction_dossier::Terminal::none: return static_cast<TerminalScope>(0U);
    }
    return static_cast<TerminalScope>(0U);
}

[[nodiscard]] ValidationReport stopped(const ValidationCode code,
                                       const ValidationReport& partial) noexcept {
    ValidationReport report = partial;
    report.code = code;
    report.valid = false;
    report.owner_constitution_proved = false;
    report.currentness_proved = false;
    report.global_one_use_proved = false;
    report.epoch_exit_proved = false;
    report.authority_granted = false;
    return report;
}

}  // namespace

Digest key_id_for(const PublicKey& public_key) {
    return digest_domain_payload(kKeyIdDomain, public_key);
}

Digest manifest_head(const EncodedManifest& manifest) {
    return digest_domain_payload(kManifestHeadDomain, manifest);
}

Digest statement_head(const EncodedStatement& statement) {
    return digest_domain_payload(kStatementHeadDomain, statement);
}

Digest dossier_prefix_digest(
    const std::span<const transaction_dossier::EncodedRecord> records) {
    if (records.size() < 3U) return {};
    std::vector<std::uint8_t> bytes;
    bytes.reserve(3U * transaction_dossier::kRecordBytes);
    for (std::size_t index = 0U; index < 3U; ++index) {
        bytes.insert(bytes.end(), records[index].begin(), records[index].end());
    }
    return digest_domain_payload(kDossierPrefixDomain, bytes);
}

Digest admitted_profile_digest() {
    const auto* begin = reinterpret_cast<const std::uint8_t*>(kProfileText.data());
    return digest_domain_payload(kProfileDomain,
        std::span<const std::uint8_t>(begin, kProfileText.size()));
}

bool encode_manifest(const OwnerManifestV1& value, EncodedManifest& output) {
    if (!manifest_invariant(value)) return false;
    output.fill(0U);
    std::copy(kManifestMagic.begin(), kManifestMagic.end(), output.begin());
    put_u16(output, 8U, kVersion);
    put_u16(output, 10U, kManifestKind);
    put_u32(output, 12U, static_cast<std::uint32_t>(kManifestBytes));
    output[16U] = kEd25519Suite;
    output[17U] = value.threshold;
    output[18U] = value.key_count;
    put_array(output, 32U, value.project_id);
    put_array(output, 64U, value.constitution_id);
    put_array(output, 96U, value.predecessor_manifest);
    put_u64(output, 128U, value.version);
    for (std::size_t index = 0U; index < kMaximumKeys; ++index) {
        const std::size_t base = 160U + index * 64U;
        put_array(output, base, value.keys[index].key_id);
        put_array(output, base + 32U, value.keys[index].public_key);
    }
    const Digest integrity = digest_domain_payload(
        kManifestIntegrityDomain,
        std::span<const std::uint8_t>(output.data(), 352U));
    put_array(output, 352U, integrity);
    return true;
}

bool decode_manifest(const EncodedManifest& input, OwnerManifestV1& output) {
    if (!std::equal(kManifestMagic.begin(), kManifestMagic.end(), input.begin())
        || get_u16(input, 8U) != kVersion
        || get_u16(input, 10U) != kManifestKind
        || get_u32(input, 12U) != kManifestBytes
        || input[16U] != kEd25519Suite
        || input[19U] != 0U
        || !all_zero(std::span<const std::uint8_t>(input.data() + 20U, 12U))
        || !all_zero(std::span<const std::uint8_t>(input.data() + 136U, 24U))) {
        return false;
    }
    const Digest expected = digest_domain_payload(
        kManifestIntegrityDomain,
        std::span<const std::uint8_t>(input.data(), 352U));
    if (get_array<32U>(input, 352U) != expected) return false;
    OwnerManifestV1 value;
    value.threshold = input[17U];
    value.key_count = input[18U];
    value.project_id = get_array<32U>(input, 32U);
    value.constitution_id = get_array<32U>(input, 64U);
    value.predecessor_manifest = get_array<32U>(input, 96U);
    value.version = get_u64(input, 128U);
    for (std::size_t index = 0U; index < kMaximumKeys; ++index) {
        const std::size_t base = 160U + index * 64U;
        value.keys[index].key_id = get_array<32U>(input, base);
        value.keys[index].public_key = get_array<32U>(input, base + 32U);
    }
    if (!manifest_invariant(value)) return false;
    output = value;
    return true;
}

bool encode_statement(const AdmissionStatementV1& value, EncodedStatement& output) {
    if (!statement_invariant(value)) return false;
    output.fill(0U);
    std::copy(kStatementMagic.begin(), kStatementMagic.end(), output.begin());
    put_u16(output, 8U, kVersion);
    put_u16(output, 10U, kStatementKind);
    put_u32(output, 12U, static_cast<std::uint32_t>(kStatementBytes));
    output[16U] = static_cast<std::uint8_t>(value.purpose);
    output[17U] = static_cast<std::uint8_t>(value.terminal_scope);
    output[18U] = kEd25519Suite;
    const std::array<const Digest*, 12U> digests{{
        &value.project_id, &value.owner_manifest_head, &value.profile_digest,
        &value.transaction_id, &value.prefix_digest, &value.subject,
        &value.policy, &value.evidence, &value.appraisal, &value.issuer_actor,
        &value.endpoint_actor, &value.reopener_actor,
    }};
    for (std::size_t index = 0U; index < digests.size(); ++index) {
        put_array(output, 32U + index * 32U, *digests[index]);
    }
    put_u64(output, 416U, value.generation_from);
    put_u64(output, 424U, value.generation_to);
    put_u64(output, 432U, value.nonce);
    put_u64(output, 440U, value.not_before);
    put_u64(output, 448U, value.expires_at);
    put_u64(output, 456U, value.ceremony_nonce);
    const Digest integrity = digest_domain_payload(
        kStatementIntegrityDomain,
        std::span<const std::uint8_t>(output.data(), 480U));
    put_array(output, 480U, integrity);
    return true;
}

bool decode_statement(const EncodedStatement& input, AdmissionStatementV1& output) {
    if (!std::equal(kStatementMagic.begin(), kStatementMagic.end(), input.begin())
        || get_u16(input, 8U) != kVersion
        || get_u16(input, 10U) != kStatementKind
        || get_u32(input, 12U) != kStatementBytes
        || input[18U] != kEd25519Suite
        || !all_zero(std::span<const std::uint8_t>(input.data() + 19U, 13U))
        || !all_zero(std::span<const std::uint8_t>(input.data() + 464U, 16U))) {
        return false;
    }
    const Digest expected = digest_domain_payload(
        kStatementIntegrityDomain,
        std::span<const std::uint8_t>(input.data(), 480U));
    if (get_array<32U>(input, 480U) != expected) return false;
    AdmissionStatementV1 value;
    value.purpose = static_cast<Purpose>(input[16U]);
    value.terminal_scope = static_cast<TerminalScope>(input[17U]);
    std::array<Digest*, 12U> digests{{
        &value.project_id, &value.owner_manifest_head, &value.profile_digest,
        &value.transaction_id, &value.prefix_digest, &value.subject,
        &value.policy, &value.evidence, &value.appraisal, &value.issuer_actor,
        &value.endpoint_actor, &value.reopener_actor,
    }};
    for (std::size_t index = 0U; index < digests.size(); ++index) {
        *digests[index] = get_array<32U>(input, 32U + index * 32U);
    }
    value.generation_from = get_u64(input, 416U);
    value.generation_to = get_u64(input, 424U);
    value.nonce = get_u64(input, 432U);
    value.not_before = get_u64(input, 440U);
    value.expires_at = get_u64(input, 448U);
    value.ceremony_nonce = get_u64(input, 456U);
    if (!statement_invariant(value)) return false;
    output = value;
    return true;
}

bool encode_envelope(const SignedAdmissionEnvelopeV1& value, EncodedEnvelope& output) {
    AdmissionStatementV1 decoded;
    if (value.signature_count == 0U || value.signature_count > kMaximumKeys
        || !decode_statement(value.statement, decoded)) {
        return false;
    }
    for (std::size_t index = 0U; index < kMaximumKeys; ++index) {
        if (index < value.signature_count) {
            if (!nonzero(value.signatures[index].key_id)
                || !nonzero(value.signatures[index].signature)) {
                return false;
            }
        } else if (!all_zero(value.signatures[index].key_id)
                   || !all_zero(value.signatures[index].signature)) {
            return false;
        }
    }
    output.fill(0U);
    std::copy(kEnvelopeMagic.begin(), kEnvelopeMagic.end(), output.begin());
    put_u16(output, 8U, kVersion);
    put_u16(output, 10U, kEnvelopeKind);
    put_u32(output, 12U, static_cast<std::uint32_t>(kEnvelopeBytes));
    output[16U] = value.signature_count;
    output[17U] = kEd25519Suite;
    put_array(output, 32U, value.statement);
    for (std::size_t index = 0U; index < kMaximumKeys; ++index) {
        const std::size_t base = 544U + index * 96U;
        put_array(output, base, value.signatures[index].key_id);
        put_array(output, base + 32U, value.signatures[index].signature);
    }
    const Digest integrity = digest_domain_payload(
        kEnvelopeIntegrityDomain,
        std::span<const std::uint8_t>(output.data(), 992U));
    put_array(output, 992U, integrity);
    return true;
}

bool decode_envelope(const EncodedEnvelope& input, SignedAdmissionEnvelopeV1& output) {
    if (!std::equal(kEnvelopeMagic.begin(), kEnvelopeMagic.end(), input.begin())
        || get_u16(input, 8U) != kVersion
        || get_u16(input, 10U) != kEnvelopeKind
        || get_u32(input, 12U) != kEnvelopeBytes
        || input[17U] != kEd25519Suite
        || !all_zero(std::span<const std::uint8_t>(input.data() + 18U, 14U))
        || !all_zero(std::span<const std::uint8_t>(input.data() + 832U, 160U))) {
        return false;
    }
    const Digest expected = digest_domain_payload(
        kEnvelopeIntegrityDomain,
        std::span<const std::uint8_t>(input.data(), 992U));
    if (get_array<32U>(input, 992U) != expected) return false;
    SignedAdmissionEnvelopeV1 value;
    value.signature_count = input[16U];
    value.statement = get_array<kStatementBytes>(input, 32U);
    if (value.signature_count == 0U || value.signature_count > kMaximumKeys) return false;
    for (std::size_t index = 0U; index < kMaximumKeys; ++index) {
        const std::size_t base = 544U + index * 96U;
        value.signatures[index].key_id = get_array<32U>(input, base);
        value.signatures[index].signature = get_array<64U>(input, base + 32U);
        if (index < value.signature_count) {
            if (!nonzero(value.signatures[index].key_id)
                || !nonzero(value.signatures[index].signature)) return false;
        } else if (!all_zero(value.signatures[index].key_id)
                   || !all_zero(value.signatures[index].signature)) return false;
    }
    output = value;
    return true;
}

SigningMessage signing_message_for(const EncodedStatement& statement) {
    SigningMessage message{};
    std::copy(kSigningDomain.begin(), kSigningDomain.end(), message.begin());
    put_u64(message, 32U, static_cast<std::uint64_t>(statement.size()));
    put_array(message, 40U, statement);
    return message;
}

ValidationReport validate_candidate(
    const EncodedManifest& manifest_bytes,
    const EncodedEnvelope& envelope_bytes,
    const std::span<const transaction_dossier::EncodedRecord> dossier,
    const std::uint64_t observed_time) {
    ValidationReport report;
    OwnerManifestV1 manifest;
    if (!decode_manifest(manifest_bytes, manifest)) {
        return stopped(ValidationCode::invalid_manifest, report);
    }
    report.manifest_valid = true;

    SignedAdmissionEnvelopeV1 envelope;
    if (!decode_envelope(envelope_bytes, envelope)) {
        return stopped(ValidationCode::invalid_envelope, report);
    }
    AdmissionStatementV1 statement;
    if (!decode_statement(envelope.statement, statement)) {
        return stopped(ValidationCode::invalid_statement, report);
    }
    report.statement_valid = true;

    if (statement.project_id != manifest.project_id
        || statement.owner_manifest_head != manifest_head(manifest_bytes)) {
        return stopped(ValidationCode::manifest_binding_mismatch, report);
    }
    if (statement.profile_digest != admitted_profile_digest()) {
        return stopped(ValidationCode::profile_mismatch, report);
    }
    if (observed_time < statement.not_before || observed_time >= statement.expires_at) {
        return stopped(ValidationCode::time_window_mismatch, report);
    }
    report.time_window_match = true;

    const transaction_dossier::ValidationReport dossier_report =
        transaction_dossier::validate_candidate(dossier);
    report.structurally_complete = dossier_report.structurally_complete;
    report.effect_bearing = dossier_report.effect_bearing;
    if (!dossier_report.valid || !dossier_report.structurally_complete
        || !dossier_report.effect_bearing || dossier.size() != 6U) {
        return stopped(ValidationCode::invalid_dossier, report);
    }

    std::array<transaction_dossier::RecordV1, 6U> records{};
    for (std::size_t index = 0U; index < records.size(); ++index) {
        if (!transaction_dossier::decode_record(dossier[index], records[index])) {
            return stopped(ValidationCode::invalid_dossier, report);
        }
    }
    const transaction_dossier::RecordV1& r1 = records[0U];
    const transaction_dossier::RecordV1& r2 = records[1U];
    const transaction_dossier::RecordV1& r3 = records[2U];
    const transaction_dossier::RecordV1& r4 = records[3U];
    const transaction_dossier::RecordV1& r5 = records[4U];
    const transaction_dossier::RecordV1& r6 = records[5U];
    if (statement.transaction_id != r1.transaction_id
        || statement.prefix_digest != dossier_prefix_digest(dossier)
        || statement.subject != r1.subject || statement.policy != r1.policy
        || statement.evidence != r2.evidence || statement.appraisal != r3.appraisal
        || statement.issuer_actor != r4.actor || statement.endpoint_actor != r5.actor
        || statement.reopener_actor != r6.actor
        || statement.generation_from != r1.generation_from
        || statement.generation_to != r5.generation_to
        || statement.nonce != r1.nonce
        || statement.terminal_scope != scope_for(r5.terminal)
        || r4.permit != statement_head(envelope.statement)) {
        return stopped(ValidationCode::dossier_binding_mismatch, report);
    }
    report.dossier_bound = true;

    const SigningMessage message = signing_message_for(envelope.statement);
    std::array<Digest, kMaximumKeys> observed_ids{};
    std::size_t verified = 0U;
    for (std::size_t index = 0U; index < envelope.signature_count; ++index) {
        const SignatureSlotV1& slot = envelope.signatures[index];
        for (std::size_t earlier = 0U; earlier < index; ++earlier) {
            if (observed_ids[earlier] == slot.key_id) {
                report.verified_signatures = verified;
                return stopped(ValidationCode::duplicate_signer, report);
            }
        }
        observed_ids[index] = slot.key_id;
        const auto key = std::find_if(
            manifest.keys.begin(), manifest.keys.begin()
                + static_cast<std::ptrdiff_t>(manifest.key_count),
            [&slot](const KeyV1& item) { return item.key_id == slot.key_id; });
        if (key == manifest.keys.begin() + static_cast<std::ptrdiff_t>(manifest.key_count)) {
            report.verified_signatures = verified;
            return stopped(ValidationCode::unknown_signer, report);
        }
        if (!verify_ed25519(key->public_key, slot.signature, message)) {
            report.verified_signatures = verified;
            return stopped(ValidationCode::invalid_signature, report);
        }
        ++verified;
    }
    report.verified_signatures = verified;
    report.signature_evidence_valid = verified == envelope.signature_count;
    if (verified < manifest.threshold) {
        return stopped(ValidationCode::below_threshold, report);
    }
    report.threshold_met = true;
    report.code = ValidationCode::evidence_valid;
    report.valid = true;
    report.owner_constitution_proved = false;
    report.currentness_proved = false;
    report.global_one_use_proved = false;
    report.epoch_exit_proved = false;
    report.authority_granted = false;
    return report;
}

std::string_view validation_code_name(const ValidationCode value) noexcept {
    switch (value) {
        case ValidationCode::evidence_valid: return "evidence_valid";
        case ValidationCode::invalid_manifest: return "invalid_manifest";
        case ValidationCode::invalid_envelope: return "invalid_envelope";
        case ValidationCode::invalid_statement: return "invalid_statement";
        case ValidationCode::manifest_binding_mismatch: return "manifest_binding_mismatch";
        case ValidationCode::profile_mismatch: return "profile_mismatch";
        case ValidationCode::time_window_mismatch: return "time_window_mismatch";
        case ValidationCode::invalid_dossier: return "invalid_dossier";
        case ValidationCode::dossier_binding_mismatch: return "dossier_binding_mismatch";
        case ValidationCode::unknown_signer: return "unknown_signer";
        case ValidationCode::duplicate_signer: return "duplicate_signer";
        case ValidationCode::invalid_signature: return "invalid_signature";
        case ValidationCode::below_threshold: return "below_threshold";
    }
    return "unknown";
}

}  // namespace slopos::e0::signed_admission
