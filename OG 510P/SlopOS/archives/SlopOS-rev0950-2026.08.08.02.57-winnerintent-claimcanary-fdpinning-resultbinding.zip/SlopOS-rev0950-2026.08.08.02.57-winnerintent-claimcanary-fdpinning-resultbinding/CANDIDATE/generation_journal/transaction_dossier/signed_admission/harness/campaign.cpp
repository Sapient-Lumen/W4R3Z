#include "slopos/e0/signed_admission/admission.hpp"

#include <algorithm>
#include <array>
#include <cstddef>
#include <cstdint>
#include <fstream>
#include <functional>
#include <iostream>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include <openssl/evp.h>

namespace slopos::e0::signed_admission {
namespace {

using transaction_dossier::Decision;
using transaction_dossier::EncodedRecord;
using transaction_dossier::RecordV1;
using transaction_dossier::Terminal;

constexpr std::uint64_t kObservedTime = 1'800'000'000U;
constexpr std::string_view kManifestIntegrityDomain = "SlopOS/admission/manifest-integrity/v1";
constexpr std::string_view kStatementIntegrityDomain = "SlopOS/admission/statement-integrity/v1";
constexpr std::string_view kEnvelopeIntegrityDomain = "SlopOS/admission/envelope-integrity/v1";

struct FixtureKey final {
    std::array<std::uint8_t, 32U> seed{};
    KeyV1 public_part{};
};

struct ManifestFixture final {
    OwnerManifestV1 logical{};
    EncodedManifest encoded{};
    std::array<FixtureKey, kMaximumKeys> keys{};
};

struct CompleteFixture final {
    ManifestFixture manifest{};
    EncodedStatement statement{};
    EncodedEnvelope envelope{};
    std::vector<EncodedRecord> dossier{};
    std::uint64_t observed_time{kObservedTime};
};

struct Case final {
    std::string name;
    EncodedManifest manifest{};
    EncodedEnvelope envelope{};
    std::vector<EncodedRecord> dossier{};
    std::uint64_t observed_time{kObservedTime};
    ValidationCode expected{ValidationCode::invalid_manifest};
    bool valid{false};
    bool self_constituted{false};
};

[[noreturn]] void stop(const std::string& detail) {
    throw std::runtime_error(detail);
}

void require(const bool condition, const std::string& detail) {
    if (!condition) stop(detail);
}

[[nodiscard]] Digest domain_digest(const std::string_view domain,
                                   const std::span<const std::uint8_t> payload) {
    std::vector<std::uint8_t> bytes;
    bytes.reserve(domain.size() + 1U + payload.size());
    bytes.insert(bytes.end(), domain.begin(), domain.end());
    bytes.push_back(0U);
    bytes.insert(bytes.end(), payload.begin(), payload.end());
    return generation_journal::sha256(bytes);
}

template <std::size_t N>
void put_digest(std::array<std::uint8_t, N>& bytes, const std::size_t offset,
                const Digest& digest) {
    std::copy(digest.begin(), digest.end(),
              bytes.begin() + static_cast<std::ptrdiff_t>(offset));
}

void rehash_manifest(EncodedManifest& bytes) {
    put_digest(bytes, 352U, domain_digest(
        kManifestIntegrityDomain,
        std::span<const std::uint8_t>(bytes.data(), 352U)));
}

void rehash_statement(EncodedStatement& bytes) {
    put_digest(bytes, 480U, domain_digest(
        kStatementIntegrityDomain,
        std::span<const std::uint8_t>(bytes.data(), 480U)));
}

void rehash_envelope(EncodedEnvelope& bytes) {
    put_digest(bytes, 992U, domain_digest(
        kEnvelopeIntegrityDomain,
        std::span<const std::uint8_t>(bytes.data(), 992U)));
}

void rehash_embedded_statement(EncodedEnvelope& bytes) {
    EncodedStatement statement{};
    std::copy_n(bytes.begin() + 32, kStatementBytes, statement.begin());
    rehash_statement(statement);
    std::copy(statement.begin(), statement.end(), bytes.begin() + 32);
    rehash_envelope(bytes);
}

[[nodiscard]] FixtureKey make_key(const std::string_view label) {
    FixtureKey result;
    const Digest seed = transaction_dossier::labeled_digest(
        std::string{"signed-admission/test-only-private-seed/"} + std::string{label});
    std::copy(seed.begin(), seed.end(), result.seed.begin());
    EVP_PKEY* pkey = EVP_PKEY_new_raw_private_key(
        EVP_PKEY_ED25519, nullptr, result.seed.data(), result.seed.size());
    require(pkey != nullptr, "fixture private key construction");
    std::size_t public_size = result.public_part.public_key.size();
    const int exported = EVP_PKEY_get_raw_public_key(
        pkey, result.public_part.public_key.data(), &public_size);
    EVP_PKEY_free(pkey);
    require(exported == 1 && public_size == result.public_part.public_key.size(),
            "fixture public key derivation");
    result.public_part.key_id = key_id_for(result.public_part.public_key);
    return result;
}

[[nodiscard]] Signature sign(const FixtureKey& key,
                             const SigningMessage& message) {
    Signature signature{};
    EVP_PKEY* pkey = EVP_PKEY_new_raw_private_key(
        EVP_PKEY_ED25519, nullptr, key.seed.data(), key.seed.size());
    require(pkey != nullptr, "sign private key");
    EVP_MD_CTX* context = EVP_MD_CTX_new();
    require(context != nullptr, "sign context");
    require(EVP_DigestSignInit(context, nullptr, nullptr, nullptr, pkey) == 1,
            "sign init");
    std::size_t signature_size = signature.size();
    const int signed_ok = EVP_DigestSign(
        context, signature.data(), &signature_size, message.data(), message.size());
    EVP_MD_CTX_free(context);
    EVP_PKEY_free(pkey);
    require(signed_ok == 1 && signature_size == signature.size(), "sign message");
    return signature;
}

[[nodiscard]] ManifestFixture make_manifest(const std::string_view label,
                                            const std::uint8_t threshold) {
    ManifestFixture fixture;
    for (std::size_t index = 0U; index < fixture.keys.size(); ++index) {
        fixture.keys[index] = make_key(
            std::string{label} + "/key-" + std::to_string(index + 1U));
    }
    std::sort(fixture.keys.begin(), fixture.keys.end(),
              [](const FixtureKey& lhs, const FixtureKey& rhs) {
                  return lhs.public_part.key_id < rhs.public_part.key_id;
              });
    fixture.logical.project_id = transaction_dossier::labeled_digest(
        std::string{label} + "/project-id");
    fixture.logical.constitution_id = transaction_dossier::labeled_digest(
        std::string{label} + "/self-stated-constitution-id");
    fixture.logical.version = 1U;
    fixture.logical.threshold = threshold;
    fixture.logical.key_count = static_cast<std::uint8_t>(kMaximumKeys);
    for (std::size_t index = 0U; index < fixture.keys.size(); ++index) {
        fixture.logical.keys[index] = fixture.keys[index].public_part;
    }
    require(encode_manifest(fixture.logical, fixture.encoded), "encode manifest");
    return fixture;
}

[[nodiscard]] TerminalScope scope_for(const Terminal terminal) {
    switch (terminal) {
        case Terminal::effect: return TerminalScope::effect;
        case Terminal::no_effect: return TerminalScope::no_effect;
        case Terminal::uncertain: return TerminalScope::uncertain;
        case Terminal::fail_stop: return TerminalScope::fail_stop;
        case Terminal::none: break;
    }
    stop("terminal scope");
}

[[nodiscard]] RecordV1 decode_record(const EncodedRecord& encoded) {
    RecordV1 record;
    require(transaction_dossier::decode_record(encoded, record), "decode dossier record");
    return record;
}

[[nodiscard]] EncodedRecord encode_record(const RecordV1& record) {
    EncodedRecord encoded{};
    require(transaction_dossier::encode_record(record, encoded), "encode dossier record");
    return encoded;
}

void bind_permit_and_rechain(std::vector<EncodedRecord>& dossier,
                             const Digest& permit) {
    require(dossier.size() == 6U, "six record dossier");
    RecordV1 r4 = decode_record(dossier[3U]);
    r4.permit = permit;
    dossier[3U] = encode_record(r4);
    RecordV1 r5 = decode_record(dossier[4U]);
    r5.predecessor = transaction_dossier::record_head(dossier[3U]);
    r5.permit = permit;
    dossier[4U] = encode_record(r5);
    RecordV1 r6 = decode_record(dossier[5U]);
    r6.predecessor = transaction_dossier::record_head(dossier[4U]);
    r6.permit = permit;
    dossier[5U] = encode_record(r6);
}

[[nodiscard]] EncodedEnvelope envelope_for(
    const EncodedStatement& statement,
    const ManifestFixture& manifest,
    const std::vector<std::size_t>& signer_indexes) {
    require(!signer_indexes.empty() && signer_indexes.size() <= kMaximumKeys,
            "signer count");
    SignedAdmissionEnvelopeV1 value;
    value.statement = statement;
    value.signature_count = static_cast<std::uint8_t>(signer_indexes.size());
    const SigningMessage message = signing_message_for(statement);
    for (std::size_t slot = 0U; slot < signer_indexes.size(); ++slot) {
        const FixtureKey& key = manifest.keys.at(signer_indexes[slot]);
        value.signatures[slot].key_id = key.public_part.key_id;
        value.signatures[slot].signature = sign(key, message);
    }
    EncodedEnvelope encoded{};
    require(encode_envelope(value, encoded), "encode envelope");
    return encoded;
}

[[nodiscard]] CompleteFixture make_complete(
    const std::string_view label, const Terminal terminal,
    const std::size_t signatures, const bool attacker) {
    CompleteFixture fixture;
    fixture.manifest = make_manifest(
        attacker ? std::string{"attacker-self-constituted/"} + std::string{label}
                 : std::string{"hosted-unratified/"} + std::string{label},
        2U);
    fixture.dossier = transaction_dossier::make_complete_fixture(terminal, label);
    require(fixture.dossier.size() == 6U, "fixture dossier length");
    const RecordV1 r1 = decode_record(fixture.dossier[0U]);
    const RecordV1 r2 = decode_record(fixture.dossier[1U]);
    const RecordV1 r3 = decode_record(fixture.dossier[2U]);
    const RecordV1 r4 = decode_record(fixture.dossier[3U]);
    const RecordV1 r5 = decode_record(fixture.dossier[4U]);
    const RecordV1 r6 = decode_record(fixture.dossier[5U]);

    AdmissionStatementV1 statement;
    statement.purpose = Purpose::effect_permit;
    statement.terminal_scope = scope_for(terminal);
    statement.project_id = fixture.manifest.logical.project_id;
    statement.owner_manifest_head = manifest_head(fixture.manifest.encoded);
    statement.profile_digest = admitted_profile_digest();
    statement.transaction_id = r1.transaction_id;
    statement.prefix_digest = dossier_prefix_digest(fixture.dossier);
    statement.subject = r1.subject;
    statement.policy = r1.policy;
    statement.evidence = r2.evidence;
    statement.appraisal = r3.appraisal;
    statement.issuer_actor = r4.actor;
    statement.endpoint_actor = r5.actor;
    statement.reopener_actor = r6.actor;
    statement.generation_from = r1.generation_from;
    statement.generation_to = r5.generation_to;
    statement.nonce = r1.nonce;
    statement.not_before = kObservedTime - 100U;
    statement.expires_at = kObservedTime + 100U;
    statement.ceremony_nonce = 9'001U;
    require(encode_statement(statement, fixture.statement), "encode statement");
    bind_permit_and_rechain(fixture.dossier, statement_head(fixture.statement));

    std::vector<std::size_t> indexes;
    for (std::size_t index = 0U; index < signatures; ++index) indexes.push_back(index);
    fixture.envelope = envelope_for(fixture.statement, fixture.manifest, indexes);
    return fixture;
}

[[nodiscard]] Case from_fixture(const std::string& name,
                                const CompleteFixture& fixture,
                                const ValidationCode expected,
                                const bool valid,
                                const bool self_constituted = false) {
    return Case{name, fixture.manifest.encoded, fixture.envelope, fixture.dossier,
                fixture.observed_time, expected, valid, self_constituted};
}

[[nodiscard]] Case mutate_statement(
    const std::string& name, const CompleteFixture& base,
    const ValidationCode expected,
    const std::function<void(AdmissionStatementV1&)>& mutation) {
    AdmissionStatementV1 statement;
    require(decode_statement(base.statement, statement), "decode statement mutation");
    mutation(statement);
    EncodedStatement encoded{};
    require(encode_statement(statement, encoded), "encode statement mutation");
    Case result = from_fixture(name, base, expected, false);
    result.envelope = envelope_for(encoded, base.manifest, {0U, 1U});
    return result;
}

[[nodiscard]] Case mutate_manifest_raw(
    const std::string& name, const CompleteFixture& base,
    const std::function<void(EncodedManifest&)>& mutation,
    const bool rehash) {
    Case result = from_fixture(name, base, ValidationCode::invalid_manifest, false);
    mutation(result.manifest);
    if (rehash) rehash_manifest(result.manifest);
    return result;
}

[[nodiscard]] Case mutate_envelope_raw(
    const std::string& name, const CompleteFixture& base,
    const ValidationCode expected,
    const std::function<void(EncodedEnvelope&)>& mutation,
    const bool rehash) {
    Case result = from_fixture(name, base, expected, false);
    mutation(result.envelope);
    if (rehash) rehash_envelope(result.envelope);
    return result;
}

void write_binary(const std::filesystem::path& path,
                  const std::span<const std::uint8_t> bytes) {
    std::filesystem::create_directories(path.parent_path());
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    require(output.good(), "open output " + path.string());
    output.write(reinterpret_cast<const char*>(bytes.data()),
                 static_cast<std::streamsize>(bytes.size()));
    require(output.good(), "write output " + path.string());
}

void write_dossier(const std::filesystem::path& path,
                   const std::vector<EncodedRecord>& records) {
    std::filesystem::create_directories(path.parent_path());
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    require(output.good(), "open dossier output");
    for (const EncodedRecord& record : records) {
        output.write(reinterpret_cast<const char*>(record.data()),
                     static_cast<std::streamsize>(record.size()));
    }
    require(output.good(), "write dossier output");
}

void write_text(const std::filesystem::path& path, const std::string& text) {
    std::filesystem::create_directories(path.parent_path());
    std::ofstream output(path, std::ios::binary | std::ios::trunc);
    require(output.good(), "open text output");
    output.write(text.data(), static_cast<std::streamsize>(text.size()));
    require(output.good(), "write text output");
}

[[nodiscard]] std::string bool_text(const bool value) {
    return value ? "true" : "false";
}

}  // namespace

bool run_campaign(const std::filesystem::path& output_directory) {
    try {
        std::filesystem::remove_all(output_directory);
        std::filesystem::create_directories(output_directory);

        const CompleteFixture effect = make_complete("canonical-effect", Terminal::effect, 2U, false);
        const CompleteFixture no_effect = make_complete("canonical-no-effect", Terminal::no_effect, 3U, false);
        const CompleteFixture uncertain = make_complete("canonical-uncertain", Terminal::uncertain, 2U, false);
        const CompleteFixture fail_stop = make_complete("canonical-fail-stop", Terminal::fail_stop, 2U, false);
        const CompleteFixture attacker = make_complete("coherent-attacker", Terminal::effect, 2U, true);

        std::vector<Case> cases{
            from_fixture("positive-effect-2of3", effect, ValidationCode::evidence_valid, true),
            from_fixture("positive-no-effect-3of3", no_effect, ValidationCode::evidence_valid, true),
            from_fixture("positive-uncertain-2of3", uncertain, ValidationCode::evidence_valid, true),
            from_fixture("positive-fail-stop-2of3", fail_stop, ValidationCode::evidence_valid, true),
            from_fixture("countermodel-self-constituted-attacker", attacker,
                         ValidationCode::evidence_valid, true, true),
        };

        cases.push_back(mutate_manifest_raw("negative-01-manifest-magic", effect,
            [](EncodedManifest& value) { value[0U] ^= 0x01U; }, false));
        cases.push_back(mutate_manifest_raw("negative-02-manifest-integrity", effect,
            [](EncodedManifest& value) { value[352U] ^= 0x80U; }, false));
        cases.push_back(mutate_manifest_raw("negative-03-manifest-keyid-mismatch", effect,
            [](EncodedManifest& value) { value[160U] ^= 0x01U; }, true));
        cases.push_back(mutate_manifest_raw("negative-04-manifest-duplicate-key", effect,
            [](EncodedManifest& value) {
                std::copy_n(value.begin() + 160, 64U, value.begin() + 224);
            }, true));
        cases.push_back(mutate_manifest_raw("negative-05-manifest-unsorted-keys", effect,
            [](EncodedManifest& value) {
                std::array<std::uint8_t, 64U> first{};
                std::copy_n(value.begin() + 160, 64U, first.begin());
                std::copy_n(value.begin() + 224, 64U, value.begin() + 160);
                std::copy(first.begin(), first.end(), value.begin() + 224);
            }, true));
        cases.push_back(mutate_manifest_raw("negative-06-manifest-threshold-zero", effect,
            [](EncodedManifest& value) { value[17U] = 0U; }, true));
        cases.push_back(mutate_manifest_raw("negative-07-manifest-threshold-above-count", effect,
            [](EncodedManifest& value) { value[17U] = 4U; }, true));

        cases.push_back(mutate_envelope_raw("negative-08-envelope-magic", effect,
            ValidationCode::invalid_envelope,
            [](EncodedEnvelope& value) { value[0U] ^= 0x01U; }, false));
        cases.push_back(mutate_envelope_raw("negative-09-envelope-integrity", effect,
            ValidationCode::invalid_envelope,
            [](EncodedEnvelope& value) { value[992U] ^= 0x01U; }, false));
        cases.push_back(mutate_envelope_raw("negative-10-envelope-reserved", effect,
            ValidationCode::invalid_envelope,
            [](EncodedEnvelope& value) { value[832U] = 1U; }, true));
        cases.push_back(mutate_envelope_raw("negative-11-statement-magic", effect,
            ValidationCode::invalid_statement,
            [](EncodedEnvelope& value) { value[32U] ^= 0x01U; }, true));
        cases.push_back(mutate_envelope_raw("negative-12-statement-integrity", effect,
            ValidationCode::invalid_statement,
            [](EncodedEnvelope& value) { value[32U + 480U] ^= 0x01U; }, true));
        {
            Case reserved = from_fixture("negative-13-statement-reserved", effect,
                                         ValidationCode::invalid_statement, false);
            reserved.envelope[32U + 464U] = 1U;
            rehash_embedded_statement(reserved.envelope);
            cases.push_back(std::move(reserved));
        }

        cases.push_back(mutate_statement("negative-14-project-substitution", effect,
            ValidationCode::manifest_binding_mismatch,
            [](AdmissionStatementV1& value) {
                value.project_id = transaction_dossier::labeled_digest("foreign/project");
            }));
        cases.push_back(mutate_statement("negative-15-manifest-head-substitution", effect,
            ValidationCode::manifest_binding_mismatch,
            [](AdmissionStatementV1& value) {
                value.owner_manifest_head = transaction_dossier::labeled_digest("foreign/manifest");
            }));
        cases.push_back(mutate_statement("negative-16-profile-substitution", effect,
            ValidationCode::profile_mismatch,
            [](AdmissionStatementV1& value) {
                value.profile_digest = transaction_dossier::labeled_digest("foreign/profile");
            }));
        cases.push_back(mutate_statement("negative-17-not-yet-valid", effect,
            ValidationCode::time_window_mismatch,
            [](AdmissionStatementV1& value) {
                value.not_before = kObservedTime + 1U;
                value.expires_at = kObservedTime + 101U;
            }));
        cases.push_back(mutate_statement("negative-18-expired", effect,
            ValidationCode::time_window_mismatch,
            [](AdmissionStatementV1& value) {
                value.not_before = kObservedTime - 101U;
                value.expires_at = kObservedTime;
            }));

        {
            Case invalid = from_fixture("negative-19-dossier-integrity", effect,
                                        ValidationCode::invalid_dossier, false);
            invalid.dossier[2U][200U] ^= 0x80U;
            cases.push_back(std::move(invalid));
        }
        {
            Case short_dossier = from_fixture("negative-20-dossier-five-records", effect,
                                              ValidationCode::invalid_dossier, false);
            short_dossier.dossier.pop_back();
            cases.push_back(std::move(short_dossier));
        }

        cases.push_back(mutate_statement("negative-21-transaction-substitution", effect,
            ValidationCode::dossier_binding_mismatch,
            [](AdmissionStatementV1& value) {
                value.transaction_id = transaction_dossier::labeled_digest("foreign/transaction");
            }));
        cases.push_back(mutate_statement("negative-22-prefix-substitution", effect,
            ValidationCode::dossier_binding_mismatch,
            [](AdmissionStatementV1& value) {
                value.prefix_digest = transaction_dossier::labeled_digest("foreign/prefix");
            }));
        cases.push_back(mutate_statement("negative-23-subject-substitution", effect,
            ValidationCode::dossier_binding_mismatch,
            [](AdmissionStatementV1& value) {
                value.subject = transaction_dossier::labeled_digest("foreign/subject");
            }));
        cases.push_back(mutate_statement("negative-24-policy-substitution", effect,
            ValidationCode::dossier_binding_mismatch,
            [](AdmissionStatementV1& value) {
                value.policy = transaction_dossier::labeled_digest("foreign/policy");
            }));
        cases.push_back(mutate_statement("negative-25-evidence-substitution", effect,
            ValidationCode::dossier_binding_mismatch,
            [](AdmissionStatementV1& value) {
                value.evidence = transaction_dossier::labeled_digest("foreign/evidence");
            }));
        cases.push_back(mutate_statement("negative-26-appraisal-substitution", effect,
            ValidationCode::dossier_binding_mismatch,
            [](AdmissionStatementV1& value) {
                value.appraisal = transaction_dossier::labeled_digest("foreign/appraisal");
            }));
        cases.push_back(mutate_statement("negative-27-issuer-substitution", effect,
            ValidationCode::dossier_binding_mismatch,
            [](AdmissionStatementV1& value) {
                value.issuer_actor = transaction_dossier::labeled_digest("foreign/issuer");
            }));
        cases.push_back(mutate_statement("negative-28-endpoint-substitution", effect,
            ValidationCode::dossier_binding_mismatch,
            [](AdmissionStatementV1& value) {
                value.endpoint_actor = transaction_dossier::labeled_digest("foreign/endpoint");
            }));
        cases.push_back(mutate_statement("negative-29-reopener-substitution", effect,
            ValidationCode::dossier_binding_mismatch,
            [](AdmissionStatementV1& value) {
                value.reopener_actor = transaction_dossier::labeled_digest("foreign/reopener");
            }));
        cases.push_back(mutate_statement("negative-30-generation-substitution", effect,
            ValidationCode::dossier_binding_mismatch,
            [](AdmissionStatementV1& value) {
                value.generation_from += 1U;
                value.generation_to += 1U;
            }));
        cases.push_back(mutate_statement("negative-31-nonce-substitution", effect,
            ValidationCode::dossier_binding_mismatch,
            [](AdmissionStatementV1& value) { value.nonce += 1U; }));
        cases.push_back(mutate_statement("negative-32-terminal-scope-substitution", effect,
            ValidationCode::dossier_binding_mismatch,
            [](AdmissionStatementV1& value) {
                value.terminal_scope = TerminalScope::no_effect;
                value.generation_to = value.generation_from;
            }));
        {
            Case permit = from_fixture("negative-33-permit-substitution", effect,
                                       ValidationCode::dossier_binding_mismatch, false);
            bind_permit_and_rechain(
                permit.dossier, transaction_dossier::labeled_digest("foreign/permit"));
            cases.push_back(std::move(permit));
        }
        {
            FixtureKey foreign = make_key("foreign-unknown-signer");
            SignedAdmissionEnvelopeV1 value;
            require(decode_envelope(effect.envelope, value), "decode unknown signer envelope");
            const SigningMessage message = signing_message_for(value.statement);
            value.signatures[0U].key_id = foreign.public_part.key_id;
            value.signatures[0U].signature = sign(foreign, message);
            EncodedEnvelope encoded{};
            require(encode_envelope(value, encoded), "encode unknown signer envelope");
            Case unknown = from_fixture("negative-34-unknown-signer", effect,
                                        ValidationCode::unknown_signer, false);
            unknown.envelope = encoded;
            cases.push_back(std::move(unknown));
        }
        {
            SignedAdmissionEnvelopeV1 value;
            require(decode_envelope(effect.envelope, value), "decode duplicate signer envelope");
            value.signatures[1U] = value.signatures[0U];
            EncodedEnvelope encoded{};
            require(encode_envelope(value, encoded), "encode duplicate signer envelope");
            Case duplicate = from_fixture("negative-35-duplicate-signer", effect,
                                          ValidationCode::duplicate_signer, false);
            duplicate.envelope = encoded;
            cases.push_back(std::move(duplicate));
        }
        cases.push_back(mutate_envelope_raw("negative-36-invalid-signature", effect,
            ValidationCode::invalid_signature,
            [](EncodedEnvelope& value) { value[544U + 32U] ^= 0x01U; }, true));
        {
            SignedAdmissionEnvelopeV1 value;
            require(decode_envelope(effect.envelope, value), "decode below threshold envelope");
            value.signature_count = 1U;
            value.signatures[1U] = {};
            EncodedEnvelope encoded{};
            require(encode_envelope(value, encoded), "encode below threshold envelope");
            Case below = from_fixture("negative-37-below-threshold", effect,
                                      ValidationCode::below_threshold, false);
            below.envelope = encoded;
            cases.push_back(std::move(below));
        }
        {
            SignedAdmissionEnvelopeV1 target;
            SignedAdmissionEnvelopeV1 donor;
            require(decode_envelope(effect.envelope, target), "decode target envelope");
            require(decode_envelope(no_effect.envelope, donor), "decode donor envelope");
            target.signatures[0U].signature = donor.signatures[0U].signature;
            EncodedEnvelope encoded{};
            require(encode_envelope(target, encoded), "encode cross-purpose signature envelope");
            Case mismatch = from_fixture("negative-38-signed-bytes-substitution", effect,
                                         ValidationCode::invalid_signature, false);
            mismatch.envelope = encoded;
            cases.push_back(std::move(mismatch));
        }

        std::size_t valid_count = 0U;
        std::size_t rejected_count = 0U;
        std::size_t disagreements = 0U;
        std::size_t self_constituted_valid = 0U;
        std::size_t authority_true = 0U;
        std::string table =
            "case\tpath\tobserved_time\texpected_code\texpected_valid\tself_constituted\t"
            "candidate_code\treference_code\tverified_signatures\tsignature_evidence_valid\t"
            "threshold_met\tdossier_bound\ttime_window_match\towner_constitution_proved\t"
            "currentness_proved\tglobal_one_use_proved\tepoch_exit_proved\tauthority_granted\n";

        for (std::size_t index = 0U; index < cases.size(); ++index) {
            const Case& test = cases[index];
            const ValidationReport candidate = validate_candidate(
                test.manifest, test.envelope, test.dossier, test.observed_time);
            const ValidationReport reference = validate_reference(
                test.manifest, test.envelope, test.dossier, test.observed_time);
            if (candidate != reference) ++disagreements;
            require(candidate == reference, "candidate/reference disagreement case=" + test.name);
            require(candidate.code == test.expected,
                    "unexpected code case=" + test.name + " actual="
                    + std::string{validation_code_name(candidate.code)} + " expected="
                    + std::string{validation_code_name(test.expected)});
            require(candidate.valid == test.valid, "unexpected validity case=" + test.name);
            require(!candidate.owner_constitution_proved && !candidate.currentness_proved
                    && !candidate.global_one_use_proved && !candidate.epoch_exit_proved
                    && !candidate.authority_granted,
                    "forbidden authority promotion case=" + test.name);
            if (candidate.valid) ++valid_count;
            else ++rejected_count;
            if (test.self_constituted && candidate.valid) ++self_constituted_valid;
            if (candidate.authority_granted) ++authority_true;

            const std::string ordinal = index < 9U ? "0" + std::to_string(index + 1U)
                                                  : std::to_string(index + 1U);
            const std::filesystem::path relative =
                std::filesystem::path{"cases"} / (ordinal + "-" + test.name);
            write_binary(output_directory / relative / "manifest.bin", test.manifest);
            write_binary(output_directory / relative / "envelope.bin", test.envelope);
            write_dossier(output_directory / relative / "dossier.bin", test.dossier);
            table += test.name + "\t" + relative.generic_string() + "\t"
                + std::to_string(test.observed_time) + "\t"
                + std::string{validation_code_name(test.expected)} + "\t"
                + bool_text(test.valid) + "\t" + bool_text(test.self_constituted) + "\t"
                + std::string{validation_code_name(candidate.code)} + "\t"
                + std::string{validation_code_name(reference.code)} + "\t"
                + std::to_string(candidate.verified_signatures) + "\t"
                + bool_text(candidate.signature_evidence_valid) + "\t"
                + bool_text(candidate.threshold_met) + "\t"
                + bool_text(candidate.dossier_bound) + "\t"
                + bool_text(candidate.time_window_match) + "\tfalse\tfalse\tfalse\tfalse\tfalse\n";
        }
        write_text(output_directory / "cases.tsv", table);

        const ValidationReport first = validate_candidate(
            effect.manifest.encoded, effect.envelope, effect.dossier, effect.observed_time);
        const ValidationReport clone = validate_candidate(
            effect.manifest.encoded, effect.envelope, effect.dossier, effect.observed_time);
        require(first.valid && clone.valid, "replay witness local acceptance");
        write_text(output_directory / "replay-audit.json",
            "{\n"
            "  \"schema\": \"slopos.rev0913.signed-admission-replay-countermodel.v1\",\n"
            "  \"identical_envelope_copies\": 2,\n"
            "  \"identical_dossier_copies\": 2,\n"
            "  \"same_root_local_accepts\": 2,\n"
            "  \"signature_evidence_valid_in_each_copy\": true,\n"
            "  \"owner_constitution_proved\": false,\n"
            "  \"currentness_proved\": false,\n"
            "  \"global_one_use_proved\": false,\n"
            "  \"authority_granted\": false\n"
            "}\n");

        const std::string audit =
            "{\n"
            "  \"schema\": \"slopos.rev0913.signed-admission-campaign.v1\",\n"
            "  \"status\": \"PASS\",\n"
            "  \"manifest_bytes\": 384,\n"
            "  \"statement_bytes\": 512,\n"
            "  \"envelope_bytes\": 1024,\n"
            "  \"dossier_record_bytes\": 448,\n"
            "  \"cases\": " + std::to_string(cases.size()) + ",\n"
            "  \"valid_evidence_cases\": " + std::to_string(valid_count) + ",\n"
            "  \"rejected_cases\": " + std::to_string(rejected_count) + ",\n"
            "  \"self_constituted_valid_countermodels\": "
                + std::to_string(self_constituted_valid) + ",\n"
            "  \"candidate_reference_disagreements\": "
                + std::to_string(disagreements) + ",\n"
            "  \"real_ed25519\": true,\n"
            "  \"threshold_profile\": \"2-of-3\",\n"
            "  \"dossier_bound\": true,\n"
            "  \"signing_api_exposed\": false,\n"
            "  \"owner_constitution_proved\": false,\n"
            "  \"currentness_proved\": false,\n"
            "  \"global_one_use_proved\": false,\n"
            "  \"epoch_exit_true_results\": 0,\n"
            "  \"authority_true_results\": " + std::to_string(authority_true) + "\n"
            "}\n";
        write_text(output_directory / "campaign-audit.json", audit);

        std::cout << "SIGNED_ADMISSION_CAMPAIGN=PASS cases=" << cases.size()
                  << " valid_evidence=" << valid_count
                  << " rejected=" << rejected_count
                  << " self_constituted_valid=" << self_constituted_valid
                  << " disagreements=" << disagreements
                  << " ed25519=true threshold=2-of-3 dossier_bound=true"
                  << " owner_constitution=false currentness=false global_one_use=false"
                  << " epoch_exit=false authority=false\n";
        return true;
    } catch (const std::exception& error) {
        std::cerr << "SIGNED_ADMISSION_CAMPAIGN=FAIL detail=" << error.what() << '\n';
        return false;
    }
}

}  // namespace slopos::e0::signed_admission
