#include "slopos/e0/signed_admission/admission.hpp"

#include <algorithm>
#include <array>

#include <openssl/evp.h>

namespace slopos::e0::signed_admission {
namespace {

[[nodiscard]] ValidationReport halt(const ValidationCode code,
                                    ValidationReport report) noexcept {
    report.code = code;
    report.valid = false;
    report.owner_constitution_proved = false;
    report.currentness_proved = false;
    report.global_one_use_proved = false;
    report.epoch_exit_proved = false;
    report.authority_granted = false;
    return report;
}

[[nodiscard]] bool verify_signature(const PublicKey& key,
                                    const Signature& signature,
                                    const SigningMessage& message) noexcept {
    EVP_PKEY* pkey = EVP_PKEY_new_raw_public_key(
        EVP_PKEY_ED25519, nullptr, key.data(), key.size());
    if (pkey == nullptr) return false;
    EVP_MD_CTX* context = EVP_MD_CTX_new();
    if (context == nullptr) {
        EVP_PKEY_free(pkey);
        return false;
    }
    bool accepted = false;
    if (EVP_DigestVerifyInit(context, nullptr, nullptr, nullptr, pkey) == 1) {
        accepted = EVP_DigestVerify(context, signature.data(), signature.size(),
                                    message.data(), message.size()) == 1;
    }
    EVP_MD_CTX_free(context);
    EVP_PKEY_free(pkey);
    return accepted;
}

[[nodiscard]] TerminalScope translate_terminal(
    const transaction_dossier::Terminal terminal) noexcept {
    if (terminal == transaction_dossier::Terminal::effect) return TerminalScope::effect;
    if (terminal == transaction_dossier::Terminal::no_effect) return TerminalScope::no_effect;
    if (terminal == transaction_dossier::Terminal::uncertain) return TerminalScope::uncertain;
    if (terminal == transaction_dossier::Terminal::fail_stop) return TerminalScope::fail_stop;
    return static_cast<TerminalScope>(0U);
}

}  // namespace

ValidationReport validate_reference(
    const EncodedManifest& manifest_bytes,
    const EncodedEnvelope& envelope_bytes,
    const std::span<const transaction_dossier::EncodedRecord> dossier,
    const std::uint64_t observed_time) {
    ValidationReport result;
    OwnerManifestV1 owner;
    if (!decode_manifest(manifest_bytes, owner)) {
        return halt(ValidationCode::invalid_manifest, result);
    }
    result.manifest_valid = true;

    SignedAdmissionEnvelopeV1 signed_value;
    if (!decode_envelope(envelope_bytes, signed_value)) {
        return halt(ValidationCode::invalid_envelope, result);
    }
    AdmissionStatementV1 statement;
    if (!decode_statement(signed_value.statement, statement)) {
        return halt(ValidationCode::invalid_statement, result);
    }
    result.statement_valid = true;

    const Digest exact_manifest_head = manifest_head(manifest_bytes);
    if (statement.project_id != owner.project_id
        || statement.owner_manifest_head != exact_manifest_head) {
        return halt(ValidationCode::manifest_binding_mismatch, result);
    }
    if (statement.profile_digest != admitted_profile_digest()) {
        return halt(ValidationCode::profile_mismatch, result);
    }
    if (!(statement.not_before <= observed_time && observed_time < statement.expires_at)) {
        return halt(ValidationCode::time_window_mismatch, result);
    }
    result.time_window_match = true;

    const transaction_dossier::ValidationReport dossier_result =
        transaction_dossier::validate_reference(dossier);
    result.structurally_complete = dossier_result.structurally_complete;
    result.effect_bearing = dossier_result.effect_bearing;
    if (dossier.size() != 6U || !dossier_result.valid
        || !dossier_result.structurally_complete || !dossier_result.effect_bearing) {
        return halt(ValidationCode::invalid_dossier, result);
    }

    std::array<transaction_dossier::RecordV1, 6U> record{};
    for (std::size_t index = 0U; index < record.size(); ++index) {
        if (!transaction_dossier::decode_record(dossier[index], record[index])) {
            return halt(ValidationCode::invalid_dossier, result);
        }
    }
    const bool relation =
        statement.transaction_id == record[0U].transaction_id
        && statement.prefix_digest == dossier_prefix_digest(dossier)
        && statement.subject == record[0U].subject
        && statement.policy == record[0U].policy
        && statement.evidence == record[1U].evidence
        && statement.appraisal == record[2U].appraisal
        && statement.issuer_actor == record[3U].actor
        && statement.endpoint_actor == record[4U].actor
        && statement.reopener_actor == record[5U].actor
        && statement.generation_from == record[0U].generation_from
        && statement.generation_to == record[4U].generation_to
        && statement.nonce == record[0U].nonce
        && statement.terminal_scope == translate_terminal(record[4U].terminal)
        && record[3U].permit == statement_head(signed_value.statement);
    if (!relation) return halt(ValidationCode::dossier_binding_mismatch, result);
    result.dossier_bound = true;

    const SigningMessage signed_bytes = signing_message_for(signed_value.statement);
    std::array<Digest, kMaximumKeys> seen{};
    std::size_t accepted = 0U;
    for (std::size_t slot_index = 0U;
         slot_index < signed_value.signature_count; ++slot_index) {
        const SignatureSlotV1& slot = signed_value.signatures[slot_index];
        for (std::size_t prior = 0U; prior < slot_index; ++prior) {
            if (seen[prior] == slot.key_id) {
                result.verified_signatures = accepted;
                return halt(ValidationCode::duplicate_signer, result);
            }
        }
        seen[slot_index] = slot.key_id;

        const KeyV1* selected = nullptr;
        for (std::size_t key_index = 0U; key_index < owner.key_count; ++key_index) {
            if (owner.keys[key_index].key_id == slot.key_id) {
                selected = &owner.keys[key_index];
                break;
            }
        }
        if (selected == nullptr) {
            result.verified_signatures = accepted;
            return halt(ValidationCode::unknown_signer, result);
        }
        if (!verify_signature(selected->public_key, slot.signature, signed_bytes)) {
            result.verified_signatures = accepted;
            return halt(ValidationCode::invalid_signature, result);
        }
        ++accepted;
    }
    result.verified_signatures = accepted;
    result.signature_evidence_valid = accepted == signed_value.signature_count;
    if (accepted < owner.threshold) {
        return halt(ValidationCode::below_threshold, result);
    }
    result.threshold_met = true;
    result.code = ValidationCode::evidence_valid;
    result.valid = true;
    result.owner_constitution_proved = false;
    result.currentness_proved = false;
    result.global_one_use_proved = false;
    result.epoch_exit_proved = false;
    result.authority_granted = false;
    return result;
}

}  // namespace slopos::e0::signed_admission
