#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path

CASE_FIELDS = [
    "case", "terminal_kind", "state_nonzero", "parent_accepted", "cutover_id_nonzero",
    "witness_digest_nonzero", "floor_digest_nonzero", "reclamation_request_match",
    "join_shape_valid", "join_cutover_match", "join_request_match",
    "join_transition_match", "join_incarnation_match", "join_terminal_digest_match",
    "join_terminal_kind_match", "join_witness_digest_match", "join_floor_digest_match",
    "trace_initial_valid", "trace_deleted_live_conflict", "trace_reopen_without_joined_basis",
    "trace_join_without_components", "trace_live_absent_without_deletion",
    "reclamation_requested", "equivocation", "parent_live_basis",
    "parent_witness_path", "parent_floor_path", "join_present", "join_authenticated",
    "join_durable", "join_single_view", "join_independent_reopen",
    "join_survives_restore", "join_survives_succession", "candidate_code",
    "reference_code", "agreement", "accepted", "join_core_valid", "join_reopen_valid",
    "all_cuts_covered", "execution_gap", "history_gap", "join_gap", "reopen_gap",
    "phase_order_gap", "regression", "cutover_ready", "reclamation_safe",
    "live_record_must_remain", "fail_stopped", "eventual_repair_sufficient",
    "external_occurrence", "authority",
]
CUT_FIELDS = [
    "case", "cut_index", "cut_name", "live_record_visible", "witness_visible",
    "floor_visible", "join_visible", "deletion_authorized", "record_deleted",
    "cold_reopen_observed", "execution_covered", "history_covered",
    "same_history_basis", "join_order_ok", "reopen_order_ok",
    "authorization_order_ok", "deletion_order_ok", "phase_order_ok",
    "deletion_protocol_ok", "cut_covered",
]
CUT_NAMES = [
    "T0_live", "T1_first_replacement", "T2_both_replacements", "T3_join",
    "T4_cold_reopen", "T5_authorize", "T6_delete",
]


def fail(detail: str) -> None:
    raise SystemExit(f"PROOF_BASIS_CUTOVER_PY=FAIL detail={detail}")


def boolean(row: dict[str, str], key: str) -> bool:
    value = row[key]
    if value not in {"true", "false"}:
        fail(f"boolean={key}:{value}")
    return value == "true"


def load_tsv(path: Path, fields: list[str]) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        if reader.fieldnames != fields:
            fail(f"header={path.name}:{reader.fieldnames!r}")
        return list(reader)


def rejected(code: str) -> dict[str, object]:
    return {
        "code": code,
        "accepted": False,
        "join_core_valid": False,
        "join_reopen_valid": False,
        "all_cuts_covered": False,
        "execution_gap": False,
        "history_gap": False,
        "join_gap": False,
        "reopen_gap": False,
        "phase_order_gap": False,
        "regression": False,
        "cutover_ready": False,
        "reclamation_safe": False,
        "live_record_must_remain": True,
        "fail_stopped": False,
    }


def validation_code(row: dict[str, str]) -> str | None:
    for key, code in [
        ("state_nonzero", "invalid_terminal_state"),
        ("parent_accepted", "parent_evidence_rejected"),
        ("cutover_id_nonzero", "cutover_id_zero"),
        ("witness_digest_nonzero", "witness_digest_zero"),
        ("floor_digest_nonzero", "floor_digest_zero"),
        ("reclamation_request_match", "reclamation_request_mismatch"),
        ("join_shape_valid", "join_receipt_shape_invalid"),
    ]:
        if not boolean(row, key):
            return code
    if boolean(row, "join_present"):
        for key, code in [
            ("join_cutover_match", "join_cutover_id_mismatch"),
            ("join_request_match", "join_request_id_mismatch"),
            ("join_transition_match", "join_transition_digest_mismatch"),
            ("join_incarnation_match", "join_register_incarnation_mismatch"),
            ("join_terminal_digest_match", "join_terminal_digest_mismatch"),
            ("join_terminal_kind_match", "join_terminal_kind_mismatch"),
            ("join_witness_digest_match", "join_witness_digest_mismatch"),
            ("join_floor_digest_match", "join_floor_digest_mismatch"),
        ]:
            if not boolean(row, key):
                return code
    if not boolean(row, "trace_initial_valid"):
        return "trace_initial_state_invalid"
    if boolean(row, "trace_deleted_live_conflict"):
        return "trace_deleted_and_live"
    if boolean(row, "trace_reopen_without_joined_basis"):
        return "trace_reopen_without_joined_basis"
    if boolean(row, "trace_join_without_components"):
        return "trace_join_without_components"
    if boolean(row, "trace_live_absent_without_deletion"):
        return "trace_live_absent_without_deletion"
    return None


def evaluate(row: dict[str, str], cuts: list[dict[str, str]]) -> dict[str, object]:
    validation = validation_code(row)
    if validation is not None:
        return rejected(validation)

    live_basis = boolean(row, "parent_live_basis")
    witness_path = boolean(row, "parent_witness_path")
    floor_path = boolean(row, "parent_floor_path")
    join_core = all(boolean(row, key) for key in [
        "join_present", "join_authenticated", "join_durable", "join_single_view",
    ])
    join_reopen = join_core and all(boolean(row, key) for key in [
        "join_independent_reopen", "join_survives_restore", "join_survives_succession",
    ])

    all_cuts = True
    execution_gap = False
    history_gap = False
    join_gap = False
    phase_order_gap = False
    regression = False
    seen = {
        "witness_visible": False,
        "floor_visible": False,
        "join_visible": False,
        "cold_reopen_observed": False,
        "deletion_authorized": False,
        "record_deleted": False,
    }
    live_was_absent = False

    for index, cut in enumerate(cuts):
        if int(cut["cut_index"]) != index or cut["cut_name"] != CUT_NAMES[index]:
            fail(f"cut-order={row['case']}:{cut['cut_index']}:{cut['cut_name']}")
        live = boolean(cut, "live_record_visible")
        witness = boolean(cut, "witness_visible")
        floor = boolean(cut, "floor_visible")
        join = boolean(cut, "join_visible")
        cold_reopen = boolean(cut, "cold_reopen_observed")
        authorized = boolean(cut, "deletion_authorized")
        deleted = boolean(cut, "record_deleted")

        execution = (live and live_basis) or (floor and floor_path)
        history = (live and live_basis) or (witness and witness_path)
        joined = witness and floor and join and join_core and witness_path and floor_path
        same_basis = (live and live_basis) or joined
        reopened = cold_reopen and joined and join_reopen

        new_join = join and not seen["join_visible"]
        new_reopen = cold_reopen and not seen["cold_reopen_observed"]
        new_authorization = authorized and not seen["deletion_authorized"]
        new_deletion = deleted and not seen["record_deleted"]
        join_order = (not new_join) or (
            seen["witness_visible"] and seen["floor_visible"]
        )
        reopen_order = (not new_reopen) or seen["join_visible"]
        authorization_order = (not new_authorization) or seen["cold_reopen_observed"]
        deletion_order = (not new_deletion) or seen["deletion_authorized"]
        order_ok = join_order and reopen_order and authorization_order and deletion_order
        authorization_ok = (not authorized) or (authorization_order and reopened)
        deletion_ok = authorization_ok and (
            (not deleted) or (authorized and deletion_order and reopened)
        )
        covered = execution and history and same_basis and order_ok and deletion_ok

        expected_derived = {
            "execution_covered": execution,
            "history_covered": history,
            "same_history_basis": same_basis,
            "join_order_ok": join_order,
            "reopen_order_ok": reopen_order,
            "authorization_order_ok": authorization_order,
            "deletion_order_ok": deletion_order,
            "phase_order_ok": order_ok,
            "deletion_protocol_ok": deletion_ok,
            "cut_covered": covered,
        }
        for key, expected in expected_derived.items():
            if boolean(cut, key) != expected:
                fail(f"cut-derived={row['case']}:{index}:{key}")

        all_cuts = all_cuts and covered
        execution_gap = execution_gap or not execution
        history_gap = history_gap or not history
        join_gap = join_gap or (execution and history and not same_basis)
        phase_order_gap = phase_order_gap or not order_ok

        for key in seen:
            now = boolean(cut, key)
            regression = regression or (seen[key] and not now)
            seen[key] = seen[key] or now
        regression = regression or (live_was_absent and live)
        live_was_absent = live_was_absent or not live

    last = cuts[-1]
    final_joined = all([
        boolean(last, "witness_visible"),
        boolean(last, "floor_visible"),
        boolean(last, "join_visible"),
        join_core,
        witness_path,
        floor_path,
    ])
    reclamation = boolean(row, "reclamation_requested")
    reopen_gap = reclamation and final_joined and (
        not join_reopen or not boolean(last, "cold_reopen_observed")
    )
    equivocation = boolean(row, "equivocation")
    ready = (
        not equivocation
        and not regression
        and not phase_order_gap
        and all_cuts
        and boolean(last, "live_record_visible")
        and not boolean(last, "record_deleted")
        and boolean(last, "cold_reopen_observed")
        and final_joined
        and join_reopen
    )
    safe = (
        not equivocation
        and not regression
        and not phase_order_gap
        and all_cuts
        and reclamation
        and boolean(last, "record_deleted")
        and not boolean(last, "live_record_visible")
        and boolean(last, "deletion_authorized")
        and boolean(last, "cold_reopen_observed")
        and final_joined
        and join_reopen
    )

    if equivocation:
        code = "accepted_equivocation_fail_stop"
        report = (False, execution_gap, history_gap, True, True, phase_order_gap,
                  regression, False, False, True)
    elif regression:
        code = "accepted_regression_fail_stop"
        report = (False, execution_gap, history_gap, join_gap, True, phase_order_gap,
                  True, False, False, True)
    elif safe:
        code = "accepted_cutover_complete"
        report = (True, False, False, False, False, False, False, False, True, False)
    elif ready:
        code = "accepted_cutover_ready_live_retained"
        report = (True, False, False, False, False, False, False, True, False, False)
    elif reopen_gap:
        code = "accepted_reclamation_refused_reopen_gap"
        report = (all_cuts, execution_gap, history_gap, join_gap, True,
                  phase_order_gap, False, False, False, False)
    elif all_cuts and boolean(last, "live_record_visible") and live_basis:
        code = "accepted_live_basis_retained"
        report = (True, False, False, False, False, False, False, False, False, False)
    elif execution_gap:
        code = "accepted_reclamation_refused_execution_gap"
        report = (False, True, history_gap, join_gap, reopen_gap,
                  phase_order_gap, False, False, False, False)
    elif history_gap:
        code = "accepted_reclamation_refused_history_gap"
        report = (False, False, True, join_gap, reopen_gap,
                  phase_order_gap, False, False, False, False)
    elif join_gap:
        code = "accepted_reclamation_refused_join_gap"
        report = (False, False, False, True, reopen_gap,
                  phase_order_gap, False, False, False, False)
    elif phase_order_gap:
        code = "accepted_reclamation_refused_order_gap"
        report = (False, False, False, False, reopen_gap,
                  True, False, False, False, False)
    else:
        code = "accepted_reclamation_refused_reopen_gap"
        report = (all_cuts, False, False, False, True,
                  False, False, False, False, False)

    (
        reported_all,
        reported_execution,
        reported_history,
        reported_join,
        reported_reopen,
        reported_order,
        reported_regression,
        reported_ready,
        reported_safe,
        fail_stopped,
    ) = report
    return {
        "code": code,
        "accepted": True,
        "join_core_valid": join_core,
        "join_reopen_valid": join_reopen,
        "all_cuts_covered": reported_all,
        "execution_gap": reported_execution,
        "history_gap": reported_history,
        "join_gap": reported_join,
        "reopen_gap": reported_reopen,
        "phase_order_gap": reported_order,
        "regression": reported_regression,
        "cutover_ready": reported_ready,
        "reclamation_safe": reported_safe,
        "live_record_must_remain": not reported_safe,
        "fail_stopped": fail_stopped,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    root = args.output.resolve()
    cases = load_tsv(root / "CASES.tsv", CASE_FIELDS)
    cuts = load_tsv(root / "CUTS.tsv", CUT_FIELDS)
    if len(cases) != 75 or len({row["case"] for row in cases}) != 75:
        fail("case-cardinality")
    if len(cuts) != 75 * 7:
        fail("cut-cardinality")
    by_case: dict[str, list[dict[str, str]]] = defaultdict(list)
    for cut in cuts:
        by_case[cut["case"]].append(cut)
    if set(by_case) != {row["case"] for row in cases}:
        fail("cut-case-set")

    codes: Counter[str] = Counter()
    for row in cases:
        if row["terminal_kind"] not in {"effect", "no_effect"}:
            fail(f"terminal-kind={row['case']}")
        expected = evaluate(row, by_case[row["case"]])
        observed = {
            "code": row["candidate_code"],
            "accepted": boolean(row, "accepted"),
            "join_core_valid": boolean(row, "join_core_valid"),
            "join_reopen_valid": boolean(row, "join_reopen_valid"),
            "all_cuts_covered": boolean(row, "all_cuts_covered"),
            "execution_gap": boolean(row, "execution_gap"),
            "history_gap": boolean(row, "history_gap"),
            "join_gap": boolean(row, "join_gap"),
            "reopen_gap": boolean(row, "reopen_gap"),
            "phase_order_gap": boolean(row, "phase_order_gap"),
            "regression": boolean(row, "regression"),
            "cutover_ready": boolean(row, "cutover_ready"),
            "reclamation_safe": boolean(row, "reclamation_safe"),
            "live_record_must_remain": boolean(row, "live_record_must_remain"),
            "fail_stopped": boolean(row, "fail_stopped"),
        }
        if expected != observed:
            fail(f"evaluation={row['case']} expected={expected!r} observed={observed!r}")
        if row["candidate_code"] != row["reference_code"] or not boolean(row, "agreement"):
            fail(f"differential={row['case']}")
        if any(boolean(row, key) for key in [
            "eventual_repair_sufficient", "external_occurrence", "authority",
        ]):
            fail(f"forbidden-projection={row['case']}")
        codes[row["candidate_code"]] += 1

    expected_codes = Counter({
        "accepted_cutover_complete": 8,
        "accepted_cutover_ready_live_retained": 4,
        "accepted_live_basis_retained": 4,
        "accepted_reclamation_refused_execution_gap": 2,
        "accepted_reclamation_refused_history_gap": 2,
        "accepted_reclamation_refused_join_gap": 4,
        "accepted_reclamation_refused_reopen_gap": 5,
        "accepted_reclamation_refused_order_gap": 6,
        "accepted_equivocation_fail_stop": 2,
        "accepted_regression_fail_stop": 5,
        "invalid_terminal_state": 4,
        "parent_evidence_rejected": 8,
        "cutover_id_zero": 1,
        "witness_digest_zero": 1,
        "floor_digest_zero": 1,
        "reclamation_request_mismatch": 2,
        "join_receipt_shape_invalid": 2,
        "join_cutover_id_mismatch": 1,
        "join_request_id_mismatch": 1,
        "join_transition_digest_mismatch": 1,
        "join_register_incarnation_mismatch": 1,
        "join_terminal_digest_mismatch": 1,
        "join_terminal_kind_mismatch": 1,
        "join_witness_digest_mismatch": 1,
        "join_floor_digest_mismatch": 1,
        "trace_initial_state_invalid": 1,
        "trace_deleted_and_live": 1,
        "trace_reopen_without_joined_basis": 1,
        "trace_join_without_components": 2,
        "trace_live_absent_without_deletion": 1,
    })
    if codes != expected_codes:
        fail(f"code-counts={dict(codes)!r}")

    expected_summary = {
        "accepted_cases": 42,
        "authority_granted": False,
        "candidate_reference_disagreements": 0,
        "cases": 75,
        "cutover_complete_cases": 8,
        "cutover_ready_live_retained_cases": 4,
        "epoch_exit_proved": False,
        "eventual_repair_sufficient_cases": 0,
        "external_occurrence_proved": False,
        "fail_stopped_cases": 7,
        "independent_custody_proved": False,
        "live_basis_retained_cases": 4,
        "phase_order_refused_cases": 6,
        "reclamation_refused_cases": 19,
        "reclamation_safe_cases": 8,
        "rejected_cases": 33,
        "schema": "slopos.rev0918.proof-basis-cutover-campaign.v1",
    }
    summary = json.loads((root / "SUMMARY.json").read_text(encoding="utf-8"))
    if summary != expected_summary:
        fail(f"summary={summary!r}")

    phases = load_tsv(root / "PHASES.tsv", [
        "cut_index", "name", "live_record_rule", "replacement_rule",
    ])
    if [(int(row["cut_index"]), row["name"]) for row in phases] != list(enumerate(CUT_NAMES)):
        fail("phases")
    counter = load_tsv(root / "COUNTERTRACES.tsv", [
        "row", "trace", "cut", "live", "witness", "floor", "join", "covered", "judgment",
    ])
    expected_counter_ids = ["L0", "E0", "E1", "H0", "H1", "J0", "J1", "D0", "R0", "O0", "O1", "S0"]
    if [row["row"] for row in counter] != expected_counter_ids:
        fail("countertraces")
    for bad, repaired in [(1, 2), (3, 4), (5, 6), (9, 10)]:
        if counter[bad]["covered"] != "false" or counter[repaired]["covered"] != "true":
            fail(f"countertrace-pair={bad}:{repaired}")

    required = {
        "EVERY_ADMITTED_CRASH_CUT_MUST_BE_COVERED=true",
        "FINAL_CONJUNCTION_DOES_NOT_ERASE_PRIOR_GAP=true",
        "LIVE_RECORD_IS_THE_BRIDGE_UNTIL_JOINED_REPLACEMENT=true",
        "WITNESS_WITHOUT_FLOOR_HAS_EXECUTION_GAP=true",
        "FLOOR_WITHOUT_WITNESS_HAS_HISTORY_GAP=true",
        "WITNESS_AND_FLOOR_WITHOUT_JOIN_HAVE_SAME_HISTORY_GAP=true",
        "DELETION_AUTHORIZATION_FOLLOWS_OBSERVED_COLD_REOPEN=true",
        "JOIN_REOPEN_AUTHORIZE_DELETE_REQUIRE_PRIOR_CUTS=true",
        "SAME_CUT_PHASE_COLLAPSE_IS_NOT_ATOMIC=true",
        "RECLAMATION_REQUEST_MUST_MATCH_PARENT=true",
        "JOIN_VISIBILITY_FOLLOWS_BOTH_COMPONENTS=true",
        "LIVE_ABSENCE_REQUIRES_RECORDED_DELETE=true",
        "CUTOVER_READY_REQUIRES_COLD_REOPEN=true",
        "REPLACEMENT_REGRESSION_FAILS_STOP=true",
        "LIVE_RECORD_RESURRECTION_FAILS_STOP=true",
        "EVENTUAL_REPAIR_SUFFICIENT=false",
        "EXTERNAL_OCCURRENCE_PROVED=false",
        "AUTHORITY_GRANTED=false",
    }
    if set((root / "INVARIANTS.txt").read_text(encoding="utf-8").splitlines()) != required:
        fail("invariants")

    print(
        "PROOF_BASIS_CUTOVER_PY=PASS cases=75 accepted=42 rejected=33 "
        "complete=8 ready=4 live_retained=4 refused=19 order_refused=6 "
        "fail_stop=7 cuts=525 disagreements=0 authority=false"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
