# Relocatable Provenance Closure V1

This child relation corrects a transport-breaking mistake in the forensic donor: retained build provenance treated the absolute extraction directory as source identity. A fresh extraction therefore failed despite byte-identical content.

The relation binds an exact **logical source root**, an ordered root-relative source closure, a complete hosted build plan, canonical build claims, two independent reopen receipts, and seven durable cuts. The first receipt is durable before the relocated claim; final possession of both objects is not accepted as a substitute for chronology. Physical workspace locators and raw path-bearing logs remain observations outside the canonical claim subject.

A successful hosted relocation witness establishes only this narrow fact: two modeled observations at distinct physical locators reopened one exact canonical subject and one exact output. It does **not** prove a generally reproducible build, source authenticity, a trusted builder, inventory completeness, external occurrence, transitive administrative independence, authority, or Epoch-Zero exit.

Build and run:

```sh
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build --target slopos_relocatable_provenance
./build/slopos_relocatable_provenance output
python3 -B proof/verify_relocatable_provenance.py output
```


## Hosted composition binding

The focused builder computes one exact root-relative `SOURCE-MANIFEST.tsv` from the current source closure before configuring any lane. It also emits exact build-plan, output-contract, parent-binding, logical-root, and claim-policy carriers. Their SHA-256 identities and byte counts are compile-time inputs to the C++ campaign and become the six ordered `SourceClosure` entries. The retained `COMPOSITION-RECEIPT.json` independently binds those entries to the actual three-lane CAS output set. Both exact reopen-receipt byte images are retained, and the reference evaluator owns a separate canonical encoder and path validator rather than reusing the candidate implementation. This repairs the earlier splits in which Python receipts named real source bytes while the C++ relation named invented labels, and candidate/reference agreement could pass through shared canonicalization. It still does not prove that the declared manifest is world-complete, that all environment inputs are known, or that an external trusted builder ran.
