#include "slopos/e0/signed_admission/root_ceremony_anchor/query_only_recovery/terminal_outcome_continuity/proof_basis_cutover.hpp"

#include <filesystem>
#include <iostream>

int main(const int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "usage: slopos_proof_basis_cutover OUTPUT_DIRECTORY\n";
        return 2;
    }
    const std::filesystem::path output(argv[1]);
    if (!slopos::e0::signed_admission::root_ceremony_anchor::query_only_recovery::terminal_outcome_continuity::proof_basis_cutover::run_campaign(output)) {
        std::cerr << "PROOF_BASIS_CUTOVER_CAMPAIGN=FAIL\n";
        return 1;
    }
    std::cout
        << "PROOF_BASIS_CUTOVER_CAMPAIGN=PASS cases=75 accepted=42 rejected=33 "
        << "complete=8 ready=4 live_retained=4 refused=19 order_refused=6 fail_stop=7 "
        << "disagreements=0 authority=false\n";
    return 0;
}
