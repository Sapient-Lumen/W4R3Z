# External Premise Admission — hosted C++20 child

This directory contains the rev0920 **External Premise Admission V1** construction. It is a strict child of one accepted `Reopen Receipt Chain V1` trace whose exact live terminal record is still present. It does not create a service, a provider adapter, a trust root, an operated ceremony, an owner decision, or an authority path.

The child asks a narrower question: **what exact provenance and chronology would make an externally supplied mechanism annex admissible as a premise for later work, without allowing the annex to ratify itself?**

The candidate and a structurally independent reference evaluator classify 132 traces across 1,320 crash cuts. The corpus includes complete dossiers, non-destructive partial stages, premise refusals, fail-stop histories, structural binding rejections, self-ratification, shared administrative fate, split views, synthetic rehearsal, self-appraisal, wrong-predecessor owner decisions, and same-cut phase collapse.

Build and run:

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build
./build/slopos_external_premise_admission /tmp/external-premise-campaign
python3 -B proof/verify_external_premise_admission.py /tmp/external-premise-campaign
```

The executable emits six canonical files. None is a production receipt. Every successful hosted case retains the live record, and every report keeps `external_occurrence_proved`, `owner_constitution_proved`, `currentness_proved`, `independent_custody_proved`, `mechanism_operated_proved`, `epoch_exit_proved`, and `authority_granted` false.
